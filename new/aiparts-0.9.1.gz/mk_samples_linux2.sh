#  Alternative way of building sample programs on a Linux system
#
#  This file is a guide to what aiParts software is used by
#  each sample program.  
#
#  Lines from this file may be copied and pasted to build only 
#  a particular sample program.

g++ -o samp_1_good samp_good.cpp aipGood.cpp

g++ -o samp_2_pandemonium samp_pandemonium.cpp aipPandemonium.cpp \
                        aipBase.cpp aipGood.cpp

g++ -o samp_3_decision samp_decision.cpp samp_deer_fear.cpp \
                      aipDecision.cpp aipEmotion.cpp \
                      aipPandemonium.cpp aipBase.cpp aipGood.cpp

g++ -o samp_4_a_to_b samp_a_to_b.cpp  samp_a2b.cpp \
                     aipHighHope.cpp \
                     aipProblem.cpp  aipDecision.cpp \
                     aipEmotion.cpp  aipPandemonium.cpp \
                     aipBase.cpp     aipGood.cpp

g++ -o samp_5_time samp_time.cpp aipTime.cpp aipBase.cpp

