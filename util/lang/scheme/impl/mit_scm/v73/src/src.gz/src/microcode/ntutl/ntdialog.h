/* -*- C -*- */

#define SCHEME_INPUT                700
#define SCHEME_INPUT_TEXT           701
#define SCHEME_INPUT_PROMPT         702
