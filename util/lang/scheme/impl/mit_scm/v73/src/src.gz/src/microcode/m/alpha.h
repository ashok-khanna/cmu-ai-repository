/* -*-C-*-
   Machine file for DEC Alpha computers.

$Id: alpha.h,v 1.4 1993/02/15 03:46:52 gjr Exp $

Copyright (c) 1992-1993 Digital Equipment Corporation

*/

#ifndef PROC_TYPE
#define PROC_TYPE PROC_TYPE_ALPHA
#endif /* PROC_TYPE */

#define LIB_DEBUG

#define C_SWITCH_MACHINE -Olimit 1800
