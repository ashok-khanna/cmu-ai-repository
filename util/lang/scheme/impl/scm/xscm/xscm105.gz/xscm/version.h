/*
 * The Imakefile depends on the format of the following definition.
 * Do not change it without updating the Imakefile.
 */

#define X_SCM_VERSION "x-scm version X1.05"
