#ifdef __STDC__
#define DEFINE_C_PROC(name) define_c_proc( #name, (long)name )
#else
#define DEFINE_C_PROC(name) define_c_proc( "name", (long)name )
#endif

extern void init_system_mem( /* cont */ );
extern long alloc_const_proc( /* len, name, obj */ );
extern long alloc_const_pair( /* obj */ );
extern long alloc_const_subtyped( /* len, subtype, obj */ );
extern long alloc_const_vector( /* len, obj */ );
extern long alloc_const_string( /* str, obj */ );
extern void define_c_proc( /* name, adr */ );

extern void init_processor_mem( /* cont */ );
extern long alloc_pair( /* obj */ );
extern long alloc_subtyped( /* len, subtype, obj */ );
extern long alloc_vector( /* len, obj */ );
extern long alloc_symbol( /* name, obj */ );
extern long alloc_global( /* name, index */ );
extern long alloc_global_from_symbol( /* sym, index */ );
extern long set_global( /* name, value */ );

extern char *local_malloc8( /* len */ );
extern char *local_mark();
extern void local_release( /* mark */ );
