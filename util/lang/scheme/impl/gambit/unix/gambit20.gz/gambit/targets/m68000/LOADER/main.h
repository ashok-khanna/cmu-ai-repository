extern long nb_processors;
extern long stack_len, heap_len, const_len;
extern long remote, remote_stack, remote_heap, remote_intr;
