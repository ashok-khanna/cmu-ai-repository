#include <stdio.h>

/* Note: This program should be linked with the object file that is to be   */
/*       converted to a .O file.  Running the program produces the .O file. */

extern char object_file_begin, object_file_end; /* limits of object file */

main()
{ fwrite( &object_file_begin, &object_file_end-&object_file_begin, 1, stdout );
  return 0;
}
