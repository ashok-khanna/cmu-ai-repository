extern long string_length( /* str */ );
extern char *string_extend( /* ptr, str */ );
extern char *string_append( /* str1, str2 */ );
extern char *string_copy( /* str */ );
extern long string_compare( /* str1, str2 */ );
extern long string_to_int( /* str */ );
extern char *string_to_c_str( /* str */ );
extern SCM_obj c_str_to_string( /* str */ );
extern char *c_id_to_symbol( /* str */ );
