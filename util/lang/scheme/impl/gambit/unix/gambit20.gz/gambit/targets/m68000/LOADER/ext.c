/* Operating system specific extensions */


#include "params.h"
#include "gambit.h"
#include "struct.h"


/*---------------------------------------------------------------------------*/

#ifdef unix
#include "ext_unix.c"
#else
#ifdef mac
#include "ext_mac.c"
#else
#include "ext_ansi.c"
#endif
#endif

/*---------------------------------------------------------------------------*/
