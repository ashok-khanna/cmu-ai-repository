extern void init_runtime();
extern void start_program();
extern void print_global_var( /* name */ );
extern char *global_name( /* index */ );
extern void barrier();
extern long barrier_call( /* proc, arg */ );
extern long barrier_service();
extern long do_return( /* id, arg */ );
