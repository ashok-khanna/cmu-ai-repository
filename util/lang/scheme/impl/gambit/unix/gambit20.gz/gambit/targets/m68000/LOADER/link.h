extern long link_const_length_in_k;
extern long link_heap_length_in_k;
extern long link_stack_length_in_k;
extern short *link_ofiles[];
extern long *link_sizeof_ofiles[];
extern long link_nb_ofiles;
