extern void init_stats();
extern long alloc_stat( /* index */ );
extern void stats_clear( /* index */ );
extern void stats_begin( /* index */ );
extern void stats_end( /* index */ );
extern void stats_start1( /* id */ );
extern void stats_start2();
extern long stats_stop1();
extern void stats_stop2();
