extern char *emul_code_alloc, *emul_code_top;

long emul_M68020_instr( /* code_ptr */ );
long emul_M68881_instr( /* code_ptr */ );
