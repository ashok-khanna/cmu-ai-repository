extern void init_ofile( /* ptr, len */ );
extern SCM_obj init_program( /* argc, argv, envp */ );
extern long load_ofile( /* name, init_proc */ );
