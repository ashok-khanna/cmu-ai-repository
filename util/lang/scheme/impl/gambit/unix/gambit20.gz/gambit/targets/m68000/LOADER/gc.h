extern long gc_report;

extern void gc();
