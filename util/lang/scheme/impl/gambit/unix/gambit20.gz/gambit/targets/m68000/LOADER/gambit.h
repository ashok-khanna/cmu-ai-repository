#ifdef THINK_C
#define mac
#define __STDC__
#undef MAX_NB_STATS
#define MAX_NB_STATS 1024
#undef MAX_NB_EVENTS
#define MAX_NB_EVENTS 8
#undef LOCAL_HEAP_LENGTH_IN_K
#define LOCAL_HEAP_LENGTH_IN_K 4
#undef ADDITIONAL_CONST_LENGTH_IN_K
#define ADDITIONAL_CONST_LENGTH_IN_K 0
#undef DEFAULT_STACK_LENGTH_IN_K
#define DEFAULT_STACK_LENGTH_IN_K MIN_STACK_LENGTH_IN_K
#define IEEE_FP64 short double
#define IEEE_FP80 double
#define OS_EVENT_SIZE 16
#else
#define IEEE_FP64 double
#define IEEE_FP80 double
#define OS_EVENT_SIZE 0
#endif

#ifdef NULL
#undef NULL
#endif

#define NULL 0L

#define K 1024
#define ceiling2(x) ((((long)(x)) + 1L) & -2L)
#define ceiling8(x) ((((long)(x)) + 7L) & -8L)

#define INTR_FLAG          0
#define LTQ_TAIL           1
#define LTQ_HEAD           2
#define DEQ_TAIL           3
#define DEQ_HEAD           4
#define Q_BOT              5
#define Q_TOP              6
#define STACK_LIM          7
#define STACK_PTR          8
#define STACK_BOT          9
#define STACK_TOP          10
#define HEAP_OLD           11
#define HEAP_LIM           12
#define HEAP_PTR           13
#define HEAP_BOT           14
#define HEAP_TOP           15
#define HEAP_MID           16
#define CLOSURE_LIM        17
#define CLOSURE_PTR        18
#define WORKQ_LOCKO        19
#define WORKQ_LOCKV        20
#define WORKQ_TAIL         21
#define WORKQ_HEAD         22
#define CURRENT_TASK       23
#define PARENT_RET         24
#define PARENT_FRAME       25
#define CURRENT_DYN_ENV    26
#define TEMP_TASK          27
#define BOS_RET            28
#define STEAL_SCAN         29
#define STEAL_LOCKO        30
#define STEAL_LOCKV        31
#define RESPONSE           32
#define THIEF              33
#define INTR_OTHER         34
#define INTR_BARRIER       35
#define INTR_TIMER         36
#define INTR_USER          37
#define INTR_IO            38
#define FLUSH_WRITES       39
#define TEMP1              40
#define TEMP2              41
#define HEAP_MARGIN        42
#define STACK_MARGIN       43
#define HEAP_MAX_MARGIN    44
#define STACK_MAX_MARGIN   45
#define COUNT1             46
#define COUNT2             47
#define ELOG_BOT           59
#define ELOG_TOP           60
#define ELOG_PTR           61
#define ID                 62
#define NB_PROCESSORS      63
#define PS                 64

#define SYMBOL_TABLE     0
#define GLOBAL_VAR_COUNT 1

#define PAIR_SIZE       2
#define PAIR_CAR        1
#define PAIR_CDR        0

#define SYMBOL_SIZE     3
#define SYMBOL_NAME     0
#define SYMBOL_PLIST    1
#define SYMBOL_GLOBAL   2

#define PH_SIZE         4
#define PH_VALUE        0
#define PH_QUEUE        1
#define PH_DELAY        2
#define PH_TASK         3

#define TASK_SIZE         9
#define TASK_CONT_FRAME   0
#define TASK_CONT_RET     1
#define TASK_CONT_DYN_ENV 2
#define TASK_LEGIT        3
#define TASK_VALUE        4
#define TASK_SYNC_PH      5
#define TASK_STATUS       6
#define TASK_LOCKO        7
#define TASK_LOCKV        8

#define QUEUE_SIZE 2
#define QUEUE_TAIL 0
#define QUEUE_HEAD 1

#define SEMAPHORE_SIZE  3
#define SEMAPHORE_TAIL  0
#define SEMAPHORE_HEAD  1
#define SEMAPHORE_COUNT 2

#define CACHE_LINE_LENGTH  16

#define PRIM_PROC_PREFIX   1
#define USER_PROC_PREFIX   2
#define PAIR_PREFIX        3

#define OFILE_VERSION_MAJOR 3
#define OFILE_VERSION_MINOR 0

#define OBJECT                  0xfffe0007
#define SYMBOL                  0xfffe8007
#define PRIM_PROC               0xffff0007

#define PADDING_TAG             0x0000
#define END_OF_CODE_TAG         0x8000
#define M68020_TAG              0x8001
#define M68881_TAG              0x8002
#define STAT_TAG                0x8003

#define PROC_REF_TAG            0x9000
#define GLOBAL_VAR_REF_TAG      0xa000
#define GLOBAL_VAR_SET_TAG      0xb000
#define GLOBAL_VAR_REF_JUMP_TAG 0xc000
#define PRIM_REF_TAG            0xd000

#define INDEX_MASK              0x0fff

#define PREDEFINED_STATS { \
"((profile 1 (###_kernel.gc 1)))", \
"((touch 1 (non-placeholder 1)))", \
"((touch 0 (non-placeholder -1) (determined-placeholder 1)))", \
"((touch 0 (determined-placeholder -1) (undetermined-placeholder 1)))" }

#define STAT_GC                          0
#define STAT_TOUCH_NON_PH                1
#define STAT_TOUCH_DET_PH                2
#define STAT_TOUCH_UNDET_PH              3
#define FIRST_AUTO_STAT STAT_TOUCH_NON_PH

#define EVENTS { \
"determine", \
"working", \
"task_switch", \
"idle", \
"interrupt", \
"stealing", \
"touch_undet", \
"touch_legit", \
"c_call" }

#define EVENT_DETERMINE     0
#define EVENT_WORKING       1
#define EVENT_TASK_SWITCH   2
#define EVENT_IDLE          3
#define EVENT_INTERRUPT     4
#define EVENT_STEALING      5
#define EVENT_TOUCH_UNDET   6
#define EVENT_TOUCH_LEGIT   7
#define EVENT_C_CALL        8

#define NB_TRAPS                  32
#define NB_TRAMPOLINE_TRAPS       24

#define global_jump_trap          0
#define TOUCH_trap                1
#define non_proc_jump_trap        6
#define rest_params_trap          7
#define rest_params_closed_trap   8
#define wrong_nb_arg1_trap        9
#define wrong_nb_arg1_closed_trap 10
#define wrong_nb_arg2_trap        11
#define wrong_nb_arg2_closed_trap 12
#define heap_alloc1_trap          13
#define heap_alloc2_trap          14
#define closure_alloc_trap        15
#define delay_future_trap         16
#define eager_future_trap         17
#define steal_conflict_trap       18
#define C_TRAP_trap               22
#define C_CALL_trap               23
#define intr_trap                 24

#define SCM_obj              long

#define SCM_int_to_obj(n)    ((n) * 8L)
#define SCM_obj_to_int(obj)  ((obj) >> 3)
#define SCM_str_to_obj(s)    ((SCM_obj)((s) - 1L))
#define SCM_obj_to_str(obj)  ((char *)((obj) + 1L))
#define SCM_vect_to_obj(v)   ((SCM_obj)(((long)(v)) - 1L))
#define SCM_obj_to_vect(obj) ((SCM_obj *)((obj) + 1L))
#define SCM_header(obj)      (*((long *)((obj) & ~7L)))
#define SCM_length(obj)      (SCM_header(obj) >> 8)
#define SCM_subtype(obj)     ((SCM_header(obj) & 0xFFL) >> 3)
#define SCM_encode(d,t)      (((d) * 8L) + (t))

#define SCM_type(obj)                   ((obj) & 7L)
#define SCM_add_type(obj, type)         (((long)(obj)) + type)
#define SCM_align(obj)                  ((((long)(obj)) + 7L) & ~7L)
#define SCM_make_header(length,subtype) (((length) * 256L) + ((subtype) * 8L))
#define SCM_header_subtype(header)      ((header & 0xFFL) >> 3)
#define SCM_header_length(header)       (header >> 8)
#define SCM_header_slots(header)        (header >> 10)
#define SCM_header_procedure(header)    (header < 0)
#define SCM_header_closure(header)      ((header & 0xFFFFL) == JSR_OP)
#define SCM_procedure_length(header)    ((header >> 16) + 0x8000)
#define SCM_closure_slots(header)       ((header >> 18) + 0x2000)
#define SCM_object_adr(obj)             ((SCM_obj *)((obj) & ~7L))
#define SCM_copied_no_header(slot0)     ((slot0) == (long)SCM_BH)
#define SCM_copied_header(slot0)        ((slot0) & 7L)
#define SCM_subtype_is_ovector(subtype) (((subtype) >= (long)SCM_subtype_ovector_min) &&\
                                        ((subtype) <= (long)SCM_subtype_ovector_max))

#define SCM_type_FIXNUM	       0
#define SCM_type_SPECIAL       7
#define SCM_type_PAIR	       4
#define SCM_type_WEAK_PAIR     1
#define SCM_type_PLACEHOLDER   5
#define SCM_type_SUBTYPED      3
#define SCM_type_PROCEDURE     2

#define SCM_subtype_VECTOR     0
#define SCM_subtype_SYMBOL     1
#define SCM_subtype_PORT       2
#define SCM_subtype_RATNUM     3
#define SCM_subtype_CPXNUM     4
#define SCM_subtype_FRAME      5
#define SCM_subtype_TASK       6
#define SCM_subtype_QUEUE      7
#define SCM_subtype_SEMAPHORE  8
#define SCM_subtype_STRING     16
#define SCM_subtype_BIGNUM     17
#define SCM_subtype_FLONUM     18
#define SCM_subtype_WEAK_PAIR  31

#define SCM_subtype_ovector_min 0
#define SCM_subtype_ovector_max 15

#define SCM_marker  -0x1
#define SCM_false   -0x10101011
#define SCM_null    -0x20202021
#define SCM_true    -0x09
#define SCM_undef   -0x11
#define SCM_unass   -0x19
#define SCM_unbound -0x21
#define SCM_eof     -0x29
#define SCM_BH      -0x31
