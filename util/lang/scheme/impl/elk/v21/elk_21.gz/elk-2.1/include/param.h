#ifndef PARAM_H
#define PARAM_H

#define INITFILE             "initscheme"

#define LOADPATH_ENV         "ELK_LOADPATH"  /* environ sym for loadpath */

#define OBARRAY_SIZE         1009      /* symbol hash table size */

#define STACK_MARGIN         (48*1024)  /* approx. stack_start - stkbase */

#define HEAP_MARGIN          (HEAP_SIZE/10*1024)

#define MAX_READ_SYMBOL      1024

#define MAX_READ_STRING      1024

#define STRING_GROW_SIZE     64

#define DEF_PRINT_DEPTH      20
#define DEF_PRINT_LEN        1000

#define FLONUM_FORMAT        "%.15g"

#ifdef CAN_DUMP
#  define INITIAL_STK_OFFSET   (20*1024)       /* 2*NCARGS */
#endif

#endif
