/* an empty fvector.c

   this is silly-- it is the result of trying to invoke 
   several different C compiler/flag combinations on fvector, 
   switched from the outside.

   this file gets compiled if we do *not* want vector features.

*/

