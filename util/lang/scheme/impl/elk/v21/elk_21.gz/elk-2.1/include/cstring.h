#ifndef CSTRING_H
#define CSTRING_H

#define Declare_C_Strings Alloca_Begin

#define Make_C_String(_from,_to) {\
    int _len;\
    if (TYPE(_from) == T_Symbol)\
	(_from) = SYMBOL(_from)->name;\
    else if (TYPE(_from) != T_String)\
	Wrong_Type_Combination ((_from), "string or symbol");\
    _len = STRING(_from)->size;\
    Alloca ((_to), char*, _len+1);\
    bcopy (STRING(_from)->data, (_to), _len);\
    (_to)[_len] = '\0';\
}

#define Dispose_C_Strings Alloca_End

#endif
