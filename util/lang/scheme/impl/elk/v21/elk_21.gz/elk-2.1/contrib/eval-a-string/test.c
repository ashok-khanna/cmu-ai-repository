extern char *Elk_Eval();

init_() {
    char *ret;

    ret = Elk_Eval("(define a 5)");
    ret = Elk_Eval("(+ a a)");
    printf("%s\n", ret);
    ret = Elk_Eval("foo-bar");
}
