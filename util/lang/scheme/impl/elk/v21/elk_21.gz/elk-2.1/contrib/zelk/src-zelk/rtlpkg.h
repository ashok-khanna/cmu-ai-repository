/* rtlpkg.h zilla oct91 - elkscheme foreign library include
 * rtl = run time load
 * c.f. zelk.h
 * modified
 * 14 nov
 */

#ifndef RTLPKG_H
#define RTLPKG_H

#ifndef THEUSUAL_H
# include <theusual.h>
#endif

/**** foreign function tables */
struct fordef {
    char *name;
    vfunction *ffunc;
    char *args;
};

/* version of fordef struct with optional usage msg */
struct fordef_usage {
    char *name;
    vfunction *ffunc;
    char *args;
    char *usage;
};


/* foreign library structure */
typedef struct {
    int structtype;
    int (*initfunc)();			/* initialization function */
    char *ssubs;                        /* scheme subrs-not implemented yet */
    struct fordef *fsubs;		/* c-linked */
    struct fordef_usage *fusubs;	/* c-linked+usage */
} FORPKG0;

typedef struct {
    int structtype;
} PKG_type;

#if ZILLAONLY
# include <rtlpkg-oldversion.h>
#endif
#endif /*RTLPKG_H%%%%%%%%%%%%%%%%*/
/*end of rtlpkg.h*/
