#include <dlfcn.h>
#include <string.h>
#include <stdlib.h>

Dlopen_File (fn) char *fn; {
    void *handle;
    SYM *sp;

    if (Verb_Load)
	printf ("[dlopen %s]\n", fn);
    if ((handle = dlopen (fn, RTLD_NOW)) == 0) {
	char *errstr = dlerror ();
	Primitive_Error ("dlopen failed:~%~s",
	    Make_String (errstr, strlen (errstr)));
    }
    if (The_Symbols)
	Free_Symbols (The_Symbols);
    The_Symbols = Open_File_And_Snarf_Symbols (fn);
    /*
     * dlsym() may fail for symbols not exported by object file;
     * this can be safely ignored.
     */
    for (sp = The_Symbols->first; sp; sp = sp->next)
	sp->value = (unsigned long)dlsym (handle, sp->name);
    Call_Initializers (The_Symbols, 0);
}

#define TMP_LEN 20

char *Temp_Name (seq) int seq; {
    static char fn[TMP_LEN];

    if (fn[0] == '\0') {
	strcpy (fn, "/tmp/ldXXXXXX");
	(void)mktemp (fn);
	strcat (fn, ".");
    }
    sprintf (fn+14, "%d", seq);
    return fn;
}

static Seq_Num;

Load_Object (names) Object names; {
    Object port, tail, fullnames, libs;
    char *lp, *buf, outfile[TMP_LEN];
    int len, liblen, i;
    GC_Node3;
    Alloca_Begin;

    port = tail = fullnames = Null;
    GC_Link3 (port, tail, fullnames);
    for (len = 0, tail = names; !Nullp (tail); tail = Cdr (tail)) {
	port = General_Open_File (Car (tail), P_INPUT, Var_Get (V_Load_Path));
	fullnames = Cons (PORT(port)->name, fullnames);
	len += STRING(Car (fullnames))->size + 1;
	(void)P_Close_Input_Port (port);
    }
    GC_Unlink;

    libs = Var_Get (V_Load_Libraries);
    if (TYPE(libs) == T_String) {
	liblen = STRING(libs)->size;
	lp = STRING(libs)->data;
    } else
	liblen = 0;

    strcpy (outfile, Temp_Name (Seq_Num));
    Seq_Num++;
    Alloca (buf, char*, len + liblen + Seq_Num*TMP_LEN + 100);
    sprintf (buf, "/usr/ccs/bin/ld -G -z text -o %s ", outfile);

    for (tail = fullnames; !Nullp (tail); tail = Cdr (tail)) {
	register struct S_String *str = STRING(Car (tail));
	strncat (buf, str->data, str->size);
	strcat (buf, " ");
    }
    for (i = 0; i < Seq_Num-1; i++) {
	strcat (buf, Temp_Name (i));
	strcat (buf, " ");
    }
    strncat (buf, lp, liblen);

    if (Verb_Load)
	printf ("[%s]\n", buf);
    if (system (buf) != 0) {
	Seq_Num--;
	(void)unlink (outfile);
	Primitive_Error ("system linker failed");
    }
    Dlopen_File (outfile);
    Alloca_End;
}

Finit_Load () {
    int i;

    for (i = 0; i < Seq_Num; i++)
	(void)unlink (Temp_Name (i));
}
