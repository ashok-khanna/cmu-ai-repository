/* This file may have been modified by DJ Delorie (Jan 1991).  If so,
** these modifications are Coyright (C) 1991 DJ Delorie, 24 Kirsten Ave,
** Rochester NH, 03867-2954, USA.
*/


#ifndef grp_h
#define grp_h 1

#include <stdio.h>

struct group
{
    char	*gr_name;
    char	*gr_passwd;
    int		gr_gid;
    char	**gr_mem;
};

#ifdef __cplusplus
extern "C" {
#endif

extern struct group	*getgrent(void);
extern struct group	*fgetgrent(FILE *);
extern struct group	*getgrgid(int);
extern struct group	*getgrnam(char *);
extern void		setgrent(void);
extern void		endgrent(void);

#ifdef __cplusplus
}
#endif

#endif
