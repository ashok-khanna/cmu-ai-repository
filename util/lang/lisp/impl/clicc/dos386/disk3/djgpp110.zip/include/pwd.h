/* This file may have been modified by DJ Delorie (Jan 1991).  If so,
** these modifications are Coyright (C) 1991 DJ Delorie, 24 Kirsten Ave,
** Rochester NH, 03867-2954, USA.
*/

#ifndef pwd_h
#define pwd_h 1

#include <stdio.h>

struct passwd
{
    char	*pw_name;
    char	*pw_passwd;
    int		pw_uid;
    int		pw_gid;
    char	*pw_age;
    char	*pw_comment;
    char	*pw_gecos;
    char	*pw_dir;
    char	*pw_shell;
    long	pw_audid;
    int		pw_audflg;
};

#ifdef __cplusplus
extern "C" {
#endif

extern struct passwd	*getpwent(void);
extern struct passwd	*fgetpwent(FILE *);
extern struct passwd	*getpwuid(int);
extern struct passwd	*getpwnam(char *);
extern void		setpwent(void);
extern void		endpwent(void);

#ifdef __cplusplus
}
#endif

#endif
