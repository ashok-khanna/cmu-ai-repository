
#include <cmpinclude.h>
#include "cmpvar.h"
init_cmpvar(){do_init(VV);}
/*	local entry for function MAKE-VAR	*/

static object LI1(va_alist)
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB1 VMS1 VMV1
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	narg= narg - 0;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +0,&LI1key,ap);
	V1=(Vcs[0]);
	V2=(Vcs[1]);
	V3=(Vcs[2]);
	V4=(Vcs[3]);
	V5=(Vcs[4]);
	if(Vcs[5]==0){
	V6= Ct;
	}else{
	V6=(Vcs[5]);}
	V7=(Vcs[6]);
	base[0]= VV[0];
	base[1]= (V1);
	base[2]= (V2);
	base[3]= (V3);
	base[4]= (V4);
	base[5]= (V5);
	base[6]= (V6);
	base[7]= (V7);
	vs_top=(vs_base=base+0)+8;
	(void) (*Lnk66)();
	vs_top=sup;
	{object V8 = vs_base[0];
	VMR1(V8)}}
	}}
/*	local entry for function C1MAKE-VAR	*/

static object LI2(V13,V14,V15,V16)

register object V13;object V14;object V15;object V16;
{	 VMB2 VMS2 VMV2
TTL:;
	{register object V17;
	V17= Cnil;
	{register object V18;
	V18= (VFUN_NARGS=2,(*(LnkLI67))(VV[1],(V13)));
	if(type_of((V13))==t_symbol){
	goto T12;}
	(void)((VFUN_NARGS=2,(*(LnkLI68))(VV[2],(V13))));
T12:;
	base[0]= (V13);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk69)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T15;}
	(void)((VFUN_NARGS=2,(*(LnkLI68))(VV[3],(V13))));
T15:;
	{register object x= (V13),V19= (V14);
	while(!endp(V19))
	if(eql(x,V19->c.c_car)){
	goto T20;
	}else V19=V19->c.c_cdr;}
	base[0]= (V13);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk70)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T21;}
T20:;
	(void)(structure_set((V18),VV[0],1,VV[4]));
	V20= (*(LnkLI71))((V13));
	(void)(structure_set((V18),VV[0],4,/* INLINE-ARGS */V20));
	{register object x= (V13),V21= (V16);
	while(!endp(V21))
	if(type_of(V21->c.c_car)==t_cons &&eql(x,V21->c.c_car->c.c_car)){
	V17= (V21->c.c_car);
	goto T32;
	}else V21=V21->c.c_cdr;
	V17= Cnil;}
T32:;
	if(((V17))==Cnil){
	goto T30;}
	(void)(structure_set((V18),VV[0],5,cdr((V17))));
	goto T28;
T30:;
	V17= get((V13),VV[5],Cnil);
	if(((V17))==Cnil){
	goto T28;}
	(void)(structure_set((V18),VV[0],5,(V17)));
T28:;
	setq(VV[6],Ct);
	goto T19;
T21:;
	{register object V22;
	register object V23;
	V22= (V16);
	V23= car((V22));
T41:;
	if(!(endp((V22)))){
	goto T42;}
	goto T37;
T42:;
	if(!((car((V23)))==((V13)))){
	goto T46;}
	{object V24= cdr((V23));
	if((V24!= VV[7]))goto T49;
	(void)(structure_set((V18),VV[0],4,VV[7]));
	goto T46;
T49:;
	if((V24!= VV[72]))goto T50;
	V25= structure_ref((V18),VV[0],6);
	V26= number_plus(/* INLINE-ARGS */V25,small_fixnum(100));
	(void)(structure_set((V18),VV[0],6,/* INLINE-ARGS */V26));
	goto T46;
T50:;
	(void)(structure_set((V18),VV[0],5,cdr((V23))));}
T46:;
	V22= cdr((V22));
	V23= car((V22));
	goto T41;}
T37:;
	base[0]= VV[8];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk73)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T57;}
	goto T56;
T57:;
	if(symbol_value(VV[8])==Cnil){
	goto T56;}{object V27;
	base[0]= structure_ref((V18),VV[0],5);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk74)();
	vs_top=sup;
	V27= vs_base[0];
	if(V27==Cnil)goto T62;
	if((V27)!=Cnil){
	goto T60;}
	goto T61;
T62:;}
	base[0]= Ct;
	base[1]= structure_ref((V18),VV[0],5);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk75)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T60;}
T61:;
	goto T56;
T60:;
	(void)(structure_set((V18),VV[0],4,VV[7]));
T56:;
	(void)(structure_set((V18),VV[0],1,VV[9]));
T19:;
	{register object x= (V13),V28= (V15);
	while(!endp(V28))
	if(eql(x,V28->c.c_car)){
	goto T69;
	}else V28=V28->c.c_cdr;
	goto T67;}
T69:;
	(void)(structure_set((V18),VV[0],2,VV[10]));
T67:;
	{object V29 = (V18);
	VMR2(V29)}}}
}
/*	local entry for function CHECK-VREF	*/

static object LI3(V31)

register object V31;
{	 VMB3 VMS3 VMV3
TTL:;
	V32= structure_ref((V31),VV[0],1);
	if(!((/* INLINE-ARGS */V32)==(VV[9]))){
	goto T71;}
	if((structure_ref((V31),VV[0],2))!=Cnil){
	goto T71;}
	if((structure_ref((V31),VV[0],3))!=Cnil){
	goto T71;}
	V33= structure_ref((V31),VV[0],0);
	{object V34 = (VFUN_NARGS=2,(*(LnkLI76))(VV[11],/* INLINE-ARGS */V33));
	VMR3(V34)}
T71:;
	{object V35 = Cnil;
	VMR3(V35)}
}
/*	local entry for function C1VAR	*/

static object LI4(V37)

object V37;
{	 VMB4 VMS4 VMV4
TTL:;
	{object V38;
	object V39;
	V38= (VFUN_NARGS=0,(*(LnkLI77))());
	V39= (*(LnkLI78))((V37));
	{object V41;
	V42= car((V39));
	V43= structure_ref(V38,VV[12],1);
	V41= make_cons(/* INLINE-ARGS */V42,/* INLINE-ARGS */V43);
	(void)(structure_set(V38,VV[12],1,(V41)));}
	V44= structure_ref(car((V39)),VV[0],5);
	(void)(structure_set((V38),VV[12],2,/* INLINE-ARGS */V44));
	{object V45 = list(3,VV[0],(V38),(V39));
	VMR4(V45)}}
}
/*	local entry for function C1VREF	*/

static object LI5(V47)

register object V47;
{	 VMB5 VMS5 VMV5
TTL:;
	{register object V48;
	register object V49;
	V48= Cnil;
	V49= Cnil;
	{register object V50;
	register object V51;
	V50= symbol_value(VV[13]);
	V51= car((V50));
T87:;
	if(!(endp((V50)))){
	goto T88;}
	{register object V52;
	V52= (*(LnkLI79))((V47));
	if(((V52))!=Cnil){
	goto T92;}
	base[1]= (V47);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk70)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T95;}
	(void)((*(LnkLI80))((V47)));
T95:;
	V53= (*(LnkLI71))((V47));{object V55;
	V55= get((V47),VV[5],Cnil);
	if(V55==Cnil)goto T102;
	V54= V55;
	goto T101;
T102:;}
	V54= Ct;
T101:;
	V52= (VFUN_NARGS=8,(*(LnkLI67))(VV[1],(V47),VV[14],VV[15],VV[16],/* INLINE-ARGS */V53,VV[17],V54));
	setq(VV[18],make_cons((V52),symbol_value(VV[18])));
T92:;
	{object V56 = list(2,(V52),(V48));
	VMR5(V56)}}
T88:;
	if(!(((V51))==(VV[19]))){
	goto T108;}
	V48= Ct;
	goto T106;
T108:;
	if(!(((V51))==(VV[20]))){
	goto T112;}
	V49= Ct;
	goto T106;
T112:;
	V57= structure_ref((V51),VV[0],0);
	if(!((/* INLINE-ARGS */V57)==((V47)))){
	goto T106;}
	V58= structure_ref((V51),VV[0],2);
	if(!((/* INLINE-ARGS */V58)==(VV[10]))){
	goto T117;}
	(void)((VFUN_NARGS=2,(*(LnkLI76))(VV[21],(V47))));
	(void)(structure_set((V51),VV[0],2,Ct));
T117:;
	if(((V48))==Cnil){
	goto T123;}
	(void)(structure_set((V51),VV[0],3,Ct));
	goto T121;
T123:;
	if(((V49))==Cnil){
	goto T126;}
	V59= structure_ref((V51),VV[0],1);
	if(!((/* INLINE-ARGS */V59)==(VV[9]))){
	goto T128;}
	(void)(structure_set((V51),VV[0],4,VV[22]));
T128:;
	(void)(structure_set((V51),VV[0],2,Ct));
	goto T121;
T126:;
	(void)(structure_set((V51),VV[0],2,Ct));
	{int V60= fix(structure_ref((V51),VV[0],6));
	V61 = make_fixnum((1)+(/* INLINE-ARGS */V60));
	(void)(structure_set((V51),VV[0],6,V61));}
T121:;
	{object V62 = list(2,(V51),(V48));
	VMR5(V62)}
T106:;
	V50= cdr((V50));
	V51= car((V50));
	goto T87;}}
}
/*	local entry for function C2VAR-KIND	*/

static object LI6(V64)

register object V64;
{	 VMB6 VMS6 VMV6
TTL:;
	V65= structure_ref((V64),VV[0],1);
	if(!((/* INLINE-ARGS */V65)==(VV[9]))){
	goto T138;}
	if((structure_ref((V64),VV[0],3))!=Cnil){
	goto T138;}
	V66= structure_ref((V64),VV[0],4);
	if((/* INLINE-ARGS */V66)==(VV[22])){
	goto T138;}
	V67= structure_ref((V64),VV[0],4);
	if(!((/* INLINE-ARGS */V67)==(VV[7]))){
	goto T145;}
	{object V68 = VV[7];
	VMR6(V68)}
T145:;
	{register object V69;
	V69= structure_ref((V64),VV[0],5);
	if(((*(LnkLI81))(VV[23],(V69)))==Cnil){
	goto T149;}
	{object V70 = VV[23];
	VMR6(V70)}
T149:;
	if(((*(LnkLI81))(VV[24],(V69)))==Cnil){
	goto T152;}
	{object V71 = VV[24];
	VMR6(V71)}
T152:;
	if(((*(LnkLI81))(VV[25],(V69)))==Cnil){
	goto T155;}
	{object V72 = VV[25];
	VMR6(V72)}
T155:;
	if(((*(LnkLI81))(VV[26],(V69)))==Cnil){
	goto T158;}
	{object V73 = VV[26];
	VMR6(V73)}
T158:;
	if(((*(LnkLI81))(VV[27],(V69)))==Cnil){
	goto T161;}
	{object V74 = VV[27];
	VMR6(V74)}
T161:;
	{object V75;
	base[0]= VV[8];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk73)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T164;}
	V75= Cnil;
	goto T163;
T164:;
	if(symbol_value(VV[8])==Cnil){
	V75= Cnil;
	goto T163;}
	V75= VV[7];
T163:;
	if(((V75))==Cnil){
	goto T168;}
	{object V76 = (V75);
	VMR6(V76)}
T168:;
	{object V77 = Cnil;
	VMR6(V77)}}}
T138:;
	{object V78 = Cnil;
	VMR6(V78)}
}
/*	local entry for function C2VAR	*/

static object LI7(V80)

object V80;
{	 VMB7 VMS7 VMV7
TTL:;
	V81= make_cons(VV[0],(V80));
	{object V82 = (VFUN_NARGS=3,(*(LnkLI82))(/* INLINE-ARGS */V81,Cnil,VV[28]));
	VMR7(V82)}
}
/*	local entry for function C2LOCATION	*/

static object LI8(V84)

object V84;
{	 VMB8 VMS8 VMV8
TTL:;
	{object V85 = (VFUN_NARGS=3,(*(LnkLI82))((V84),Cnil,VV[28]));
	VMR8(V85)}
}
/*	local entry for function CHECK-DOWNWARD	*/

static object LI9(V87)

object V87;
{	 VMB9 VMS9 VMV9
TTL:;
	{object V88;
	V88= Cnil;
	{register object V89;
	object V90;
	V89= symbol_value(VV[29]);
	V90= car((V89));
T175:;
	if(!(endp((V89)))){
	goto T176;}
	goto T171;
T176:;
	if(!((car((V90)))==(VV[30]))){
	goto T180;}
	V88= Ct;
	{register object V91;
	register object V92;
	V91= symbol_value(VV[29]);
	V92= car((V91));
T189:;
	if(!(endp((V91)))){
	goto T190;}
	goto T185;
T190:;
	if(!((car((V92)))==(VV[31]))){
	goto T194;}
	{register object V93;
	register object V94;
	V93= (V92);
	V94= VV[30];
	if(type_of((V93))!=t_cons)FEwrong_type_argument(Scons,(V93));
	((V93))->c.c_car = (V94);}
T194:;
	V91= cdr((V91));
	V92= car((V91));
	goto T189;}
T185:;
	goto T171;
T180:;
	V89= cdr((V89));
	V90= car((V89));
	goto T175;}
T171:;
	setq(VV[29],Cnil);
	if(((V88))==Cnil){
	goto T213;}
	{register object V95;
	object V96;
	V95= (V87);
	V96= car((V95));
T218:;
	if(!(endp((V95)))){
	goto T219;}
	{object V97 = Cnil;
	VMR9(V97)}
T219:;
	V98= structure_ref((V96),VV[0],1);
	if(!((/* INLINE-ARGS */V98)==(VV[32]))){
	goto T223;}
	(void)(structure_set((V96),VV[0],1,VV[9]));
T223:;
	V95= cdr((V95));
	V96= car((V95));
	goto T218;}
T213:;
	{object V99 = Cnil;
	VMR9(V99)}}
}
/*	local entry for function ASSIGN-DOWN-VARS	*/

static object LI10(V103,V104,V105)

object V103;object V104;object V105;
{	 VMB10 VMS10 VMV10
TTL:;
	{register object V106;
	V106= small_fixnum(0);
	{register object V107;
	register object V108;
	V107= (V103);
	V108= car((V107));
T236:;
	if(!(endp((V107)))){
	goto T237;}
	goto T232;
T237:;
	V109= structure_ref((V108),VV[0],1);
	if(!((/* INLINE-ARGS */V109)==(VV[32]))){
	goto T241;}
	V110= structure_ref((V108),VV[0],4);
	if(!(type_of(/* INLINE-ARGS */V110)==t_fixnum||type_of(/* INLINE-ARGS */V110)==t_bignum)){
	goto T245;}
	V111= structure_ref((V108),VV[0],4);
	V112= one_plus(/* INLINE-ARGS */V111);
	V106= (number_compare((V106),/* INLINE-ARGS */V112)>=0?((V106)):/* INLINE-ARGS */V112);
	V113= structure_ref((V108),VV[0],4);
	(void)(structure_set((V108),VV[0],2,/* INLINE-ARGS */V113));
	goto T241;
T245:;
	(void)(structure_set((V108),VV[0],2,(V106)));
	(void)(structure_set((V108),VV[0],4,(V106)));
	V106= number_plus((V106),small_fixnum(1));
T241:;
	V107= cdr((V107));
	V108= car((V107));
	goto T236;}
T232:;
	if(!(number_compare((V106),small_fixnum(0))>0)){
	goto T257;}
	if(!(((V105))==(VV[33]))){
	goto T260;}
	princ_str("\n	object base0[",VV[34]);
	(void)((*(LnkLI83))((V106)));
	princ_str("];",VV[34]);
T260:;
	setq(VV[35],make_cons(VV[36],symbol_value(VV[35])));
	princ_str("\n	DCnames",VV[34]);
	(void)((*(LnkLI83))((V104)));
	princ_str("",VV[34]);
T257:;
	{object V114 = (V106);
	VMR10(V114)}}
}
/*	local entry for function WT-DOWN	*/

static object LI11(V116)

object V116;
{	 VMB11 VMS11 VMV11
TTL:;{object V117;
	base[0]= (V116);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk84)();
	vs_top=sup;
	V117= vs_base[0];
	if(V117==Cnil)goto T272;
	goto T271;
T272:;}
	(void)((*(LnkLI85))());
T271:;
	princ_str("base0[",VV[34]);
	(void)((*(LnkLI83))((V116)));
	princ_char(93,VV[34]);
	{object V118 = Cnil;
	VMR11(V118)}
}
/*	local entry for function WT-VAR	*/

static object LI12(V121,V122)

register object V121;object V122;
{	 VMB12 VMS12 VMV12
TTL:;
	V124= structure_ref((V121),VV[0],1);
	{object V123= /* INLINE-ARGS */V124;
	if((V123!= VV[9]))goto T278;
	if(((V122))==Cnil){
	goto T280;}
	V125= structure_ref((V121),VV[0],3);
	{object V126 = (*(LnkLI86))(/* INLINE-ARGS */V125);
	VMR12(V126)}
T280:;
	if((structure_ref((V121),VV[0],3))==Cnil){
	goto T283;}
	V127= structure_ref((V121),VV[0],2);
	{object V128 = (*(LnkLI87))(/* INLINE-ARGS */V127);
	VMR12(V128)}
T283:;
	V129= structure_ref((V121),VV[0],2);
	if(!((Ct)==(/* INLINE-ARGS */V129))){
	goto T286;}
	V130= structure_ref((V121),VV[0],4);
	if(!(type_of(/* INLINE-ARGS */V130)==t_fixnum)){
	goto T286;}
	if((symbol_value(VV[8]))==Cnil){
	goto T286;}
	V131= structure_ref((V121),VV[0],5);
	if(!((Ct)==(/* INLINE-ARGS */V131))){
	goto T286;}
	(void)(structure_set((V121),VV[0],1,VV[7]));
	goto TTL;
T286:;
	V132= structure_ref((V121),VV[0],2);
	{object V133 = (*(LnkLI88))(/* INLINE-ARGS */V132);
	VMR12(V133)}
T278:;
	if((V123!= VV[4]))goto T298;
	princ_str("(VV[",VV[34]);
	V134= structure_ref((V121),VV[0],4);
	(void)((*(LnkLI83))(/* INLINE-ARGS */V134));
	princ_str("]->s.s_dbind)",VV[34]);
	{object V135 = Cnil;
	VMR12(V135)}
T298:;
	if((V123!= VV[89]))goto T302;
	V136= structure_ref((V121),VV[0],4);
	(void)((*(LnkLI83))(/* INLINE-ARGS */V136));
	{object V137 = Cnil;
	VMR12(V137)}
T302:;
	if((V123!= VV[32]))goto T304;
	V138= structure_ref((V121),VV[0],4);
	{object V139 = (*(LnkLI90))(/* INLINE-ARGS */V138);
	VMR12(V139)}
T304:;
	if((V123!= VV[15]))goto T305;
	if((symbol_value(VV[37]))==Cnil){
	goto T307;}
	princ_str("symbol_value(VV[",VV[34]);
	V140= structure_ref((V121),VV[0],4);
	(void)((*(LnkLI83))(/* INLINE-ARGS */V140));
	princ_str("])",VV[34]);
	{object V141 = Cnil;
	VMR12(V141)}
T307:;
	princ_str("(VV[",VV[34]);
	V142= structure_ref((V121),VV[0],4);
	(void)((*(LnkLI83))(/* INLINE-ARGS */V142));
	princ_str("]->s.s_dbind)",VV[34]);
	{object V143 = Cnil;
	VMR12(V143)}
T305:;
	V145= structure_ref((V121),VV[0],1);
	{object V144= /* INLINE-ARGS */V145;
	if((V144!= VV[23]))goto T316;
	if(!(number_compare(small_fixnum(0),symbol_value(VV[38]))==0)){
	goto T317;}
	princ_str("CMP",VV[34]);
T317:;
	princ_str("make_fixnum",VV[34]);
	goto T315;
T316:;
	if((V144!= VV[24]))goto T322;
	princ_str("make_integer",VV[34]);
	goto T315;
T322:;
	if((V144!= VV[25]))goto T324;
	princ_str("code_char",VV[34]);
	goto T315;
T324:;
	if((V144!= VV[26]))goto T326;
	princ_str("make_longfloat",VV[34]);
	goto T315;
T326:;
	if((V144!= VV[27]))goto T328;
	princ_str("make_shortfloat",VV[34]);
	goto T315;
T328:;
	if((V144!= VV[7]))goto T330;
	goto T315;
T330:;
	(void)((*(LnkLI91))());}
T315:;
	princ_str("(V",VV[34]);
	V146= structure_ref((V121),VV[0],4);
	(void)((*(LnkLI83))(/* INLINE-ARGS */V146));
	princ_char(41,VV[34]);
	{object V147 = Cnil;
	VMR12(V147)}}
}
/*	local entry for function SET-VAR	*/

static object LI13(V151,V152,V153)

register object V151;register object V152;object V153;
{	 VMB13 VMS13 VMV13
	bds_check;
TTL:;
	if(!(type_of((V151))==t_cons)){
	goto T334;}
	if(!((car((V151)))==(VV[0]))){
	goto T334;}
	if(!((cadr((V151)))==((V152)))){
	goto T334;}
	if((caddr((V151)))==((V153))){
	goto T335;}
T334:;
	V155= structure_ref((V152),VV[0],1);
	{object V154= /* INLINE-ARGS */V155;
	if((V154!= VV[9]))goto T343;
	princ_str("\n	",VV[34]);
	if(((V153))==Cnil){
	goto T347;}
	V156= structure_ref((V152),VV[0],3);
	(void)((*(LnkLI86))(/* INLINE-ARGS */V156));
	goto T345;
T347:;
	if((structure_ref((V152),VV[0],3))==Cnil){
	goto T350;}
	V157= structure_ref((V152),VV[0],2);
	(void)((*(LnkLI87))(/* INLINE-ARGS */V157));
	goto T345;
T350:;
	V158= structure_ref((V152),VV[0],2);
	(void)((*(LnkLI88))(/* INLINE-ARGS */V158));
T345:;
	princ_str("= ",VV[34]);
	(void)((*(LnkLI83))((V151)));
	princ_char(59,VV[34]);
	{object V159 = Cnil;
	VMR13(V159)}
T343:;
	if((V154!= VV[4]))goto T355;
	princ_str("\n	(VV[",VV[34]);
	V160= structure_ref((V152),VV[0],4);
	(void)((*(LnkLI83))(/* INLINE-ARGS */V160));
	princ_str("]->s.s_dbind)= ",VV[34]);
	(void)((*(LnkLI83))((V151)));
	princ_char(59,VV[34]);
	{object V161 = Cnil;
	VMR13(V161)}
T355:;
	if((V154!= VV[15]))goto T361;
	if((symbol_value(VV[37]))==Cnil){
	goto T363;}
	princ_str("\n	setq(VV[",VV[34]);
	V162= structure_ref((V152),VV[0],4);
	(void)((*(LnkLI83))(/* INLINE-ARGS */V162));
	princ_str("],",VV[34]);
	(void)((*(LnkLI83))((V151)));
	princ_str(");",VV[34]);
	{object V163 = Cnil;
	VMR13(V163)}
T363:;
	princ_str("\n	(VV[",VV[34]);
	V164= structure_ref((V152),VV[0],4);
	(void)((*(LnkLI83))(/* INLINE-ARGS */V164));
	princ_str("]->s.s_dbind)= ",VV[34]);
	(void)((*(LnkLI83))((V151)));
	princ_char(59,VV[34]);
	{object V165 = Cnil;
	VMR13(V165)}
T361:;
	if((V154!= VV[32]))goto T375;
	princ_str("\n	",VV[34]);
	V166= structure_ref((V152),VV[0],4);
	(void)((*(LnkLI90))(/* INLINE-ARGS */V166));
	princ_char(61,VV[34]);
	(void)((*(LnkLI83))((V151)));
	princ_char(59,VV[34]);
	{object V167 = Cnil;
	VMR13(V167)}
T375:;
	if((V154!= VV[24]))goto T382;
	{object V168;
	register object V169;
	base[0]= (V151);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk92)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T384;}
	V168= Cnil;
	goto T383;
T384:;
	V168= car((V151));
T383:;
	V169= structure_ref((V152),VV[0],4);
	{object V170= (V168);
	if((V170!= VV[93]))goto T389;
	princ_str("\n	ISETQ_FIX(V",VV[34]);
	(void)((*(LnkLI83))((V169)));
	princ_str(",V",VV[34]);
	(void)((*(LnkLI83))((V169)));
	princ_str("alloc,",VV[34]);
	base[0]= caddr((V151));
	base[1]= cadddr((V151));
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk94)();
	vs_top=sup;
	goto T388;
T389:;
	if((V170!= VV[95]))goto T398;
	princ_str("\n	ISETQ_FIX(V",VV[34]);
	(void)((*(LnkLI83))((V169)));
	princ_str(",V",VV[34]);
	(void)((*(LnkLI83))((V169)));
	princ_str("alloc,",VV[34]);
	(void)((*(LnkLI83))(caddr((V151))));
	goto T388;
T398:;
	if((V170!= VV[0]))goto T405;
	V172= structure_ref(cadr((V151)),VV[0],1);
	{object V171= /* INLINE-ARGS */V172;
	if((V171!= VV[24]))goto T406;
	princ_str("SETQ_II(V",VV[34]);
	(void)((*(LnkLI83))((V169)));
	princ_str(",V",VV[34]);
	(void)((*(LnkLI83))((V169)));
	princ_str("alloc,V",VV[34]);
	V173= structure_ref(cadr((V151)),VV[0],4);
	(void)((*(LnkLI83))(/* INLINE-ARGS */V173));
	goto T388;
T406:;
	if((V171!= VV[23]))goto T413;
	princ_str("ISETQ_FIX(V",VV[34]);
	(void)((*(LnkLI83))((V169)));
	princ_str(",V",VV[34]);
	(void)((*(LnkLI83))((V169)));
	princ_str("alloc,V",VV[34]);
	V174= structure_ref(cadr((V151)),VV[0],4);
	(void)((*(LnkLI83))(/* INLINE-ARGS */V174));
	goto T388;
T413:;
	princ_str("SETQ_IO(V",VV[34]);
	(void)((*(LnkLI83))((V169)));
	princ_str(",V",VV[34]);
	(void)((*(LnkLI83))((V169)));
	princ_str("alloc,",VV[34]);
	(void)((*(LnkLI83))((V151)));
	goto T388;}
T405:;
	if((V170!= VV[54]))goto T426;
	princ_str("SETQ_IO(V",VV[34]);
	(void)((*(LnkLI83))((V169)));
	princ_str(",V",VV[34]);
	(void)((*(LnkLI83))((V169)));
	princ_str("alloc,",VV[34]);
	(void)((*(LnkLI83))((V151)));
	goto T388;
T426:;
	bds_bind(VV[39],small_fixnum(0));
	bds_bind(VV[40],symbol_value(VV[40]));
	base[2]= VV[41];
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk96)();
	vs_top=sup;
	princ_str("\n	SETQ_II(V",VV[34]);
	(void)((*(LnkLI83))((V169)));
	princ_str(",V",VV[34]);
	(void)((*(LnkLI83))((V169)));
	princ_str("alloc,",VV[34]);
	base[2]= (V151);
	base[3]= make_cons(VV[42],(V152));
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk97)();
	vs_top=sup;
	princ_str(");",VV[34]);
	V175= (*(LnkLI98))();
	bds_unwind1;
	bds_unwind1;
	{object V176 = Cnil;
	VMR13(V176)}}
T388:;
	princ_str(");",VV[34]);
	{object V177 = Cnil;
	VMR13(V177)}}
T382:;
	princ_str("\n	V",VV[34]);
	V178= structure_ref((V152),VV[0],4);
	(void)((*(LnkLI83))(/* INLINE-ARGS */V178));
	princ_str("= ",VV[34]);
	V180= structure_ref((V152),VV[0],1);
	{object V179= /* INLINE-ARGS */V180;
	if((V179!= VV[23]))goto T453;
	base[0]= (V151);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk99)();
	vs_top=sup;
	goto T452;
T453:;
	if((V179!= VV[25]))goto T455;
	base[0]= (V151);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk100)();
	vs_top=sup;
	goto T452;
T455:;
	if((V179!= VV[26]))goto T457;
	base[0]= (V151);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk101)();
	vs_top=sup;
	goto T452;
T457:;
	if((V179!= VV[27]))goto T459;
	base[0]= (V151);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk102)();
	vs_top=sup;
	goto T452;
T459:;
	if((V179!= VV[7]))goto T461;
	base[0]= (V151);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk103)();
	vs_top=sup;
	goto T452;
T461:;
	(void)((*(LnkLI91))());}
T452:;
	princ_char(59,VV[34]);
	{object V181 = Cnil;
	VMR13(V181)}}
T335:;
	{object V182 = Cnil;
	VMR13(V182)}
}
/*	local entry for function SCH-GLOBAL	*/

static object LI14(V184)

register object V184;
{	 VMB14 VMS14 VMV14
TTL:;
	{register object V185;
	register object V186;
	V185= symbol_value(VV[18]);
	V186= car((V185));
T467:;
	if(!(endp((V185)))){
	goto T468;}
	{object V187 = Cnil;
	VMR14(V187)}
T468:;
	V188= structure_ref((V186),VV[0],0);
	if(!((/* INLINE-ARGS */V188)==((V184)))){
	goto T472;}
	{object V189 = (V186);
	VMR14(V189)}
T472:;
	V185= cdr((V185));
	V186= car((V185));
	goto T467;}
}
/*	local entry for function C1ADD-GLOBALS	*/

static object LI15(V191)

object V191;
{	 VMB15 VMS15 VMV15
TTL:;
	{register object V192;
	register object V193;
	V192= (V191);
	V193= car((V192));
T483:;
	if(!(endp((V192)))){
	goto T484;}
	{object V194 = Cnil;
	VMR15(V194)}
T484:;
	V195= (*(LnkLI71))((V193));
	{register object V197;
	V197= get((V193),VV[5],Cnil);
	if(((V197))==Cnil){
	goto T493;}
	V196= (V197);
	goto T490;
T493:;
	V196= Ct;}
T490:;
	V198= (VFUN_NARGS=8,(*(LnkLI67))(VV[1],(V193),VV[14],VV[15],VV[16],/* INLINE-ARGS */V195,VV[17],V196));
	setq(VV[13],make_cons(/* INLINE-ARGS */V198,symbol_value(VV[13])));
	V192= cdr((V192));
	V193= car((V192));
	goto T483;}
}
/*	local entry for function C1SETQ	*/

static object LI16(V200)

register object V200;
{	 VMB16 VMS16 VMV16
TTL:;
	if(!(endp((V200)))){
	goto T501;}
	{object V201 = (*(LnkLI104))();
	VMR16(V201)}
T501:;
	if(!(endp(cdr((V200))))){
	goto T504;}
	{object V202 = (*(LnkLI105))(VV[43],small_fixnum(2),small_fixnum(1));
	VMR16(V202)}
T504:;
	if(!(endp(cddr((V200))))){
	goto T507;}
	{object V203 = (*(LnkLI106))(car((V200)),cadr((V200)));
	VMR16(V203)}
T507:;
	{register object V204;
	register object V205;
	V204= (V200);
	V205= Cnil;
T510:;
	if(!(endp((V204)))){
	goto T511;}
	V206= reverse((V205));
	V207= make_cons(VV[44],/* INLINE-ARGS */V206);
	{object V208 = (*(LnkLI107))(/* INLINE-ARGS */V207);
	VMR16(V208)}
T511:;
	if(!(endp(cdr((V204))))){
	goto T515;}
	(void)((VFUN_NARGS=2,(*(LnkLI68))(VV[45],car((V204)))));
T515:;
	V209= list(3,VV[43],car((V204)),cadr((V204)));
	V205= make_cons(/* INLINE-ARGS */V209,(V205));
	V204= cddr((V204));
	goto T510;}
}
/*	local entry for function C1SETQ1	*/

static object LI17(V212,V213)

register object V212;object V213;
{	 VMB17 VMS17 VMV17
TTL:;
	{register object V214;
	register object V215;
	register object V216;
	register object V217;
	V214= (VFUN_NARGS=0,(*(LnkLI77))());
	V215= Cnil;
	V216= Cnil;
	V217= Cnil;
	if(type_of((V212))==t_symbol){
	goto T527;}
	(void)((VFUN_NARGS=2,(*(LnkLI68))(VV[46],(V212))));
T527:;
	base[1]= (V212);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk69)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T530;}
	(void)((VFUN_NARGS=2,(*(LnkLI68))(VV[47],(V212))));
T530:;
	V217= (*(LnkLI78))((V212));
	{object V219;
	V220= car((V217));
	V221= structure_ref(V214,VV[12],0);
	V219= make_cons(/* INLINE-ARGS */V220,/* INLINE-ARGS */V221);
	(void)(structure_set(V214,VV[12],0,(V219)));}
	V216= (*(LnkLI107))((V213));
	(void)((*(LnkLI108))((V214),cadr((V216))));
	V222= structure_ref(car((V217)),VV[0],5);
	V223= structure_ref(cadr((V216)),VV[12],2);
	V215= (*(LnkLI109))(/* INLINE-ARGS */V222,/* INLINE-ARGS */V223);
	if(((V215))!=Cnil){
	goto T543;}
	(void)((VFUN_NARGS=3,(*(LnkLI76))(VV[48],(V212),(V213))));
T543:;
	V224= structure_ref(cadr((V216)),VV[12],2);
	if(((V215))==(/* INLINE-ARGS */V224)){
	goto T546;}
	{object V225;
	base[1]= cadr((V216));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk110)();
	vs_top=sup;
	V225= vs_base[0];
	(void)(structure_set((V225),VV[12],2,(V215)));
	V216= listA(3,car((V216)),(V225),cddr((V216)));}
T546:;
	(void)(structure_set((V214),VV[12],2,(V215)));
	{object V226 = list(4,VV[43],(V214),(V217),(V216));
	VMR17(V226)}}
}
/*	local entry for function C2SETQ	*/

static object LI18(V229,V230)

object V229;object V230;
{	 VMB18 VMS18 VMV18
	bds_check;
TTL:;
	base[0]= make_cons(VV[0],(V229));
	bds_bind(VV[49],base[0]);
	V231= (*(LnkLI111))((V230));
	bds_unwind1;
	{object V232= car((V230));
	if((V232!= VV[112]))goto T556;
	{object V233 = (*(LnkLI113))(caddr((V230)));
	VMR18(V233)}
T556:;
	V234= make_cons(VV[0],(V229));
	{object V235 = (VFUN_NARGS=1,(*(LnkLI82))(/* INLINE-ARGS */V234));
	VMR18(V235)}}
}
/*	local entry for function C1PROGV	*/

static object LI19(V237)

register object V237;
{	 VMB19 VMS19 VMV19
TTL:;
	{object V238;
	object V239;
	register object V240;
	V238= Cnil;
	V239= Cnil;
	V240= (VFUN_NARGS=0,(*(LnkLI77))());
	if(endp((V237))){
	goto T561;}
	if(!(endp(cdr((V237))))){
	goto T560;}
T561:;
	V241 = make_fixnum(length((V237)));
	(void)((*(LnkLI105))(VV[50],small_fixnum(2),V241));
T560:;
	V238= (*(LnkLI114))(car((V237)),(V240));
	V239= (*(LnkLI114))(cadr((V237)),(V240));
	{object V242 = list(5,VV[50],(V240),(V238),(V239),(*(LnkLI115))(cddr((V237)),(V240)));
	VMR19(V242)}}
}
/*	local entry for function C2PROGV	*/

static object LI20(V246,V247,V248)

object V246;object V247;object V248;
{	 VMB20 VMS20 VMV20
	bds_check;
TTL:;
	{object V249;
	setq(VV[51],number_plus(symbol_value(VV[51]),small_fixnum(1)));
	V249= symbol_value(VV[51]);
	bds_bind(VV[52],symbol_value(VV[52]));
	princ_str("\n	{object symbols,values;",VV[34]);
	princ_str("\n	bds_ptr V",VV[34]);
	(void)((*(LnkLI83))((V249)));
	princ_str("=bds_top;",VV[34]);
	(VV[52]->s.s_dbind)= make_cons((V249),(VV[52]->s.s_dbind));
	bds_bind(VV[53],symbol_value(VV[53]));
	base[3]= list(2,VV[54],(*(LnkLI116))());
	bds_bind(VV[49],base[3]);
	(void)((*(LnkLI111))((V246)));
	princ_str("\n	symbols= ",VV[34]);
	(void)((*(LnkLI83))((VV[49]->s.s_dbind)));
	princ_char(59,VV[34]);
	bds_unwind1;
	base[3]= list(2,VV[54],(*(LnkLI116))());
	bds_bind(VV[49],base[3]);
	(void)((*(LnkLI111))((V247)));
	princ_str("\n	values= ",VV[34]);
	(void)((*(LnkLI83))((VV[49]->s.s_dbind)));
	princ_char(59,VV[34]);
	bds_unwind1;
	princ_str("\n	while(!endp(symbols)){",VV[34]);
	if((symbol_value(VV[37]))==Cnil){
	goto T594;}
	princ_str("\n	if(type_of(MMcar(symbols))!=t_symbol)",VV[34]);
	princ_str("\n	FEinvalid_variable(\"~s is not a symbol.\",MMcar(symbols));",VV[34]);
T594:;
	princ_str("\n	if(endp(values))bds_bind(MMcar(symbols),OBJNULL);",VV[34]);
	princ_str("\n	else{bds_bind(MMcar(symbols),MMcar(values));",VV[34]);
	princ_str("\n	values=MMcdr(values);}",VV[34]);
	princ_str("\n	symbols=MMcdr(symbols);}",VV[34]);
	bds_unwind1;
	base[2]= (V248);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk117)();
	vs_top=sup;
	princ_char(125,VV[34]);
	{object V250 = Cnil;
	bds_unwind1;
	VMR20(V250)}}
}
/*	local entry for function C1PSETQ	*/

static object LI21(V252)

object V252;
{	 VMB21 VMS21 VMV21
TTL:;
	{object V253;
	register object V254;
	object V255;
	V253= Cnil;
	V254= Cnil;
	V255= (VFUN_NARGS=2,(*(LnkLI77))(VV[17],VV[55]));
	{register object V256;
	V256= (V252);
T615:;
	if(!(endp((V256)))){
	goto T616;}
	goto T613;
T616:;
	if(type_of(car((V256)))==t_symbol){
	goto T620;}
	(void)((VFUN_NARGS=2,(*(LnkLI68))(VV[56],car((V256)))));
T620:;
	base[1]= car((V256));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk69)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T623;}
	(void)((VFUN_NARGS=2,(*(LnkLI68))(VV[57],car((V256)))));
T623:;
	if(!(endp(cdr((V256))))){
	goto T627;}
	(void)((VFUN_NARGS=2,(*(LnkLI68))(VV[58],car((V256)))));
T627:;
	{register object V257;
	register object V258;
	register object V259;
	V257= (*(LnkLI78))(car((V256)));
	V258= (*(LnkLI107))(cadr((V256)));
	V260= structure_ref(car((V257)),VV[0],5);
	V261= structure_ref(cadr((V258)),VV[12],2);
	V259= (*(LnkLI109))(/* INLINE-ARGS */V260,/* INLINE-ARGS */V261);
	V262= structure_ref(cadr((V258)),VV[12],2);
	if(equal((V259),/* INLINE-ARGS */V262)){
	goto T634;}
	{register object V263;
	base[4]= cadr((V258));
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk110)();
	vs_top=sup;
	V263= vs_base[0];
	(void)(structure_set((V263),VV[12],2,(V259)));
	V258= listA(3,car((V258)),(V263),cddr((V258)));}
T634:;
	V253= make_cons((V257),(V253));
	V254= make_cons((V258),(V254));
	{register object V264;
	object V265;
	V264= (V255);
	V266= car((V257));
	V267= structure_ref((V264),VV[12],0);
	V265= make_cons(/* INLINE-ARGS */V266,/* INLINE-ARGS */V267);
	(void)(structure_set((V264),VV[12],0,(V265)));}
	(void)((*(LnkLI108))((V255),cadar((V254))));}
	V256= cddr((V256));
	goto T615;}
T613:;
	V268= reverse((V253));
	{object V269 = list(4,VV[59],(V255),/* INLINE-ARGS */V268,reverse((V254)));
	VMR21(V269)}}
}
/*	local entry for function C2PSETQ	*/

static object LI22(V272,V273)

object V272;register object V273;
{	 VMB22 VMS22 VMV22
	bds_check;
TTL:;
	{register object V274;
	object V275;
	bds_bind(VV[53],symbol_value(VV[53]));
	V274= Cnil;
	V275= small_fixnum(0);
	{register object V276;
	register object V277;
	V276= (V272);
	V277= car((V276));
T657:;
	if(!(endp((V276)))){
	goto T658;}
	goto T653;
T658:;
	if(((*(LnkLI118))(car((V277)),cdr((V273))))!=Cnil){
	goto T663;}
	if(((*(LnkLI119))(car((V277)),cdr((V273))))==Cnil){
	goto T664;}
T663:;
	{object V278= caar((V273));
	if((V278!= VV[112]))goto T668;
	V279= make_cons((V277),caddar((V273)));
	V274= make_cons(/* INLINE-ARGS */V279,(V274));
	goto T662;
T668:;
	V281= structure_ref(car((V277)),VV[0],1);
	{register object x= /* INLINE-ARGS */V281,V280= VV[60];
	while(!endp(V280))
	if(eql(x,V280->c.c_car)){
	goto T672;
	}else V280=V280->c.c_cdr;
	goto T671;}
T672:;
	{object V282;
	object V283;
	object V284;
	V282= structure_ref(car((V277)),VV[0],1);
	setq(VV[51],number_plus(symbol_value(VV[51]),small_fixnum(1)));
	V283= symbol_value(VV[51]);
	V285= (VFUN_NARGS=4,(*(LnkLI67))(VV[14],(V282),VV[16],(V283)));
	V284= list(3,VV[0],/* INLINE-ARGS */V285,Cnil);
	princ_str("\n	{",VV[34]);
	(void)((*(LnkLI83))(symbol_value(VV[61])));
	V286= (*(LnkLI120))((V282));
	(void)((*(LnkLI83))(/* INLINE-ARGS */V286));
	princ_char(86,VV[34]);
	(void)((*(LnkLI83))((V283)));
	princ_char(59,VV[34]);
	V275= number_plus((V275),small_fixnum(1));
	bds_bind(VV[49],(V284));
	V287= (*(LnkLI111))(car((V273)));
	bds_unwind1;
	V288= make_cons((V277),(V284));
	V274= make_cons(/* INLINE-ARGS */V288,(V274));
	goto T662;}
T671:;
	base[2]= list(2,VV[54],(*(LnkLI116))());
	bds_bind(VV[49],base[2]);
	(void)((*(LnkLI111))(car((V273))));
	V289= make_cons((V277),(VV[49]->s.s_dbind));
	V274= make_cons(/* INLINE-ARGS */V289,(V274));
	bds_unwind1;
	goto T662;}
T664:;
	base[2]= make_cons(VV[0],(V277));
	bds_bind(VV[49],base[2]);
	V290= (*(LnkLI111))(car((V273)));
	bds_unwind1;
T662:;
	{object V291;
	V291= car((V273));
	V273= cdr((V273));}
	V276= cdr((V276));
	V277= car((V276));
	goto T657;}
T653:;
	{register object V292;
	register object V293;
	V292= (V274);
	V293= car((V292));
T705:;
	if(!(endp((V292)))){
	goto T706;}
	goto T701;
T706:;
	(void)((*(LnkLI42))(cdr((V293)),caar((V293)),cadar((V293))));
	V292= cdr((V292));
	V293= car((V292));
	goto T705;}
T701:;
	{object V295;
	V295= small_fixnum(0);
T719:;
	if(!(number_compare((V295),V275)>=0)){
	goto T720;}
	goto T716;
T720:;
	princ_char(125,VV[34]);
	V295= one_plus((V295));
	goto T719;}
T716:;
	{object V296 = (VFUN_NARGS=1,(*(LnkLI82))(Cnil));
	bds_unwind1;
	VMR22(V296)}}
}
/*	function definition for WT-VAR-DECL	*/

static L23()
{register object *base=vs_base;
	register object *sup=base+VM23; VC23
	vs_reserve(VM23);
	{register object V297;
	check_arg(1);
	V297=(base[0]);
	vs_top=sup;
TTL:;
	base[1]= (V297);
	base[2]= VV[0];
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk121)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T730;}
	{object V298;
	V298= structure_ref((V297),VV[0],4);
	V299= structure_ref((V297),VV[0],1);
	if(!((/* INLINE-ARGS */V299)==(VV[24]))){
	goto T735;}
	princ_str("IDECL(",VV[34]);
T735:;
	(void)((*(LnkLI83))(symbol_value(VV[61])));
	V300= (*(LnkLI72))((V297));
	(void)((*(LnkLI83))(/* INLINE-ARGS */V300));
	V301= structure_ref((V297),VV[0],1);
	V302= (*(LnkLI120))(/* INLINE-ARGS */V301);
	(void)((*(LnkLI83))(/* INLINE-ARGS */V302));
	princ_char(86,VV[34]);
	(void)((*(LnkLI83))((V298)));
	V303= structure_ref((V297),VV[0],1);
	if(!(eql(/* INLINE-ARGS */V303,VV[24]))){
	goto T745;}
	princ_str(",V",VV[34]);
	(void)((*(LnkLI83))((V298)));
	princ_str("space,V",VV[34]);
	(void)((*(LnkLI83))((V298)));
	princ_str("alloc)",VV[34]);
T745:;
	princ_char(59,VV[34]);
	base[1]= Cnil;
	vs_top=(vs_base=base+1)+1;
	return;}
T730:;
	base[1]= (*(LnkLI85))();
	vs_top=(vs_base=base+1)+1;
	return;
	}
}
static object  LnkTLI72(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[72],&LnkLI72,1,ap);} /* REGISTER */
static LnkT121(){ call_or_link(VV[121],&Lnk121);} /* STRUCTURE-SUBTYPE-P */
static object  LnkTLI42(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[42],&LnkLI42,3,ap);} /* SET-VAR */
static object  LnkTLI120(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[120],&LnkLI120,1,ap);} /* REP-TYPE */
static object  LnkTLI119(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[119],&LnkLI119,2,ap);} /* ARGS-INFO-REFERRED-VARS */
static object  LnkTLI118(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[118],&LnkLI118,2,ap);} /* ARGS-INFO-CHANGED-VARS */
static LnkT117(){ call_or_link(VV[117],&Lnk117);} /* C2EXPR */
static object  LnkTLI116(){return call_proc0(VV[116],&LnkLI116);} /* VS-PUSH */
static object  LnkTLI115(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[115],&LnkLI115,2,ap);} /* C1PROGN* */
static object  LnkTLI114(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[114],&LnkLI114,2,ap);} /* C1EXPR* */
static object  LnkTLI113(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[113],&LnkLI113,1,ap);} /* C2LOCATION */
static object  LnkTLI111(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[111],&LnkLI111,1,ap);} /* C2EXPR* */
static LnkT110(){ call_or_link(VV[110],&Lnk110);} /* COPY-INFO */
static object  LnkTLI109(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[109],&LnkLI109,2,ap);} /* TYPE-AND */
static object  LnkTLI108(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[108],&LnkLI108,2,ap);} /* ADD-INFO */
static object  LnkTLI107(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[107],&LnkLI107,1,ap);} /* C1EXPR */
static object  LnkTLI106(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[106],&LnkLI106,2,ap);} /* C1SETQ1 */
static object  LnkTLI105(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[105],&LnkLI105,3,ap);} /* TOO-FEW-ARGS */
static object  LnkTLI104(){return call_proc0(VV[104],&LnkLI104);} /* C1NIL */
static LnkT103(){ call_or_link(VV[103],&Lnk103);} /* WT-LOC */
static LnkT102(){ call_or_link(VV[102],&Lnk102);} /* WT-SHORT-FLOAT-LOC */
static LnkT101(){ call_or_link(VV[101],&Lnk101);} /* WT-LONG-FLOAT-LOC */
static LnkT100(){ call_or_link(VV[100],&Lnk100);} /* WT-CHARACTER-LOC */
static LnkT99(){ call_or_link(VV[99],&Lnk99);} /* WT-FIXNUM-LOC */
static object  LnkTLI98(){return call_proc0(VV[98],&LnkLI98);} /* CLOSE-INLINE-BLOCKS */
static LnkT97(){ call_or_link(VV[97],&Lnk97);} /* WT-INTEGER-LOC */
static LnkT96(){ call_or_link(VV[96],&Lnk96);} /* SAVE-AVMA */
static LnkT94(){ call_or_link(VV[94],&Lnk94);} /* WT-INLINE-LOC */
static LnkT92(){ call_or_link(VV[92],&Lnk92);} /* CONSP */
static object  LnkTLI91(){return call_proc0(VV[91],&LnkLI91);} /* BABOON */
static object  LnkTLI90(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[90],&LnkLI90,1,ap);} /* WT-DOWN */
static object  LnkTLI88(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[88],&LnkLI88,1,ap);} /* WT-VS */
static object  LnkTLI87(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[87],&LnkLI87,1,ap);} /* WT-VS* */
static object  LnkTLI86(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[86],&LnkLI86,1,ap);} /* WT-CCB-VS */
static object  LnkTLI85(){return call_proc0(VV[85],&LnkLI85);} /* WFS-ERROR */
static LnkT84(){ call_or_link(VV[84],&Lnk84);} /* FIXNUMP */
static object  LnkTLI83(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[83],&LnkLI83,1,ap);} /* WT1 */
static object  LnkTLI82(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[82],&LnkLI82,ap);} /* UNWIND-EXIT */
static object  LnkTLI81(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[81],&LnkLI81,2,ap);} /* TYPE>= */
static object  LnkTLI80(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[80],&LnkLI80,1,ap);} /* UNDEFINED-VARIABLE */
static object  LnkTLI79(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[79],&LnkLI79,1,ap);} /* SCH-GLOBAL */
static object  LnkTLI78(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[78],&LnkLI78,1,ap);} /* C1VREF */
static object  LnkTLI77(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[77],&LnkLI77,ap);} /* MAKE-INFO */
static object  LnkTLI76(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[76],&LnkLI76,ap);} /* CMPWARN */
static LnkT75(){ call_or_link(VV[75],&Lnk75);} /* EQ */
static LnkT74(){ call_or_link(VV[74],&Lnk74);} /* NULL */
static LnkT73(){ call_or_link(VV[73],&Lnk73);} /* BOUNDP */
static object  LnkTLI71(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[71],&LnkLI71,1,ap);} /* ADD-SYMBOL */
static LnkT70(){ call_or_link(VV[70],&Lnk70);} /* SPECIALP */
static LnkT69(){ call_or_link(VV[69],&Lnk69);} /* CONSTANTP */
static object  LnkTLI68(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[68],&LnkLI68,ap);} /* CMPERR */
static object  LnkTLI67(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[67],&LnkLI67,ap);} /* MAKE-VAR */
static LnkT66(){ call_or_link(VV[66],&Lnk66);} /* MAKE-STRUCTURE */
