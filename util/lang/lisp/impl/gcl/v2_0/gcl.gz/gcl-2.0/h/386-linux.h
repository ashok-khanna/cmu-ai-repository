#define BSD386
#include "bsd.h"
/* #include "386.h" */
#undef HAVE_SIGVEC
/* #define NEED_TO_REINSTALL_SIGNALS */
#define HAVE_SIGACTION
/* make this a noop */
#define SETUP_SIG_STACK
#define SV_ONSTACK 0

/* unblock signals m and n, and set val to signal_mask(m) | signal_mask(n)
   if they were set */
#define SIG_UNBLOCK_SIGNALS(val,m,n) \
    current_mask = sigblock(0);  \
    sigsetmask(~(sigmask(m)) & ~(sigmask(n)) & current_mask); \
    result = (current_mask & sigmask(m) ? signal_mask(m) : 0) \
      | (current_mask & sigmask(n) ? signal_mask(n) : 0);

#undef RUN_PROCESS

#define ADDITIONAL_FEATURES \
		     ADD_FEATURE("BSD386"); \
      	     ADD_FEATURE("MC68020")


#define	I386
#define	IEEEFLOAT
       

#undef HAVE_XDR

#ifdef IN_UNIXSAVE
#include <linux/user.h> 
#endif

#define USE_ULONG_

/*   How to check for input */
#undef LISTEN_FOR_INPUT

#define LISTEN_FOR_INPUT(fp) \
do { int c = 0; \
  if(((fp)->_IO_read_ptr >= (fp)->_IO_read_end) \
     && (ioctl((fp)->_fileno, FIONREAD, &c),c<=0)) \
     return 0;} while (0)

/* we dont need to worry about zeroing fp->_base , to prevent  */
#define FCLOSE_SETBUF_OK 

/* #define DATA_BEGIN((TXTRELOC+header.a_text+(SEGSIZ-1)) & ~(SEGSIZ-1)); */
#define DATA_BEGIN (char *)(char *)N_DATADDR(header);

/*
#undef   FILECPY_HEADER
#define FILECPY_HEADER \
	if (header.a_magic == ZMAGIC) \
		filecpy(save, original, PAGSIZ - sizeof(header)); \
	filecpy(save, original, header.a_text);
*/

#define RELOC_FILE "rel_sun3.c"



#define LITTLE_ENDIAN

#define	PAGSIZ		(NBPG)
#define	SEGSIZ		(NBPG * CLSIZE)
#define	TXTRELOC	0

#define USE_DIRENT
#define GETPATHNAME
#define PATHNAME_CACHE	10


/* try out the gnu malloc */
/* #define GNU_MALLOC */

/* #define SIGPROTV SIGBUS */
/* In my implementation I have put the address in code
   Doubtless this will change in Xinu code.
   
 */
#define GET_FAULT_ADDR(sig,code,sv,a) ((char *) code)

#define INSTALL_SEGMENTATION_CATCHER \
  	 (void) signal(SIGSEGV,segmentation_catcher)
/* if you are in an early version of linux without SIGBUS, uncomment
   the next line */
/* #define SIGBUS SIGSEGV */
#define SIGSYS SIGSEGV
#define SIGEMT SIGSEGV


/* get the fileno of a FILE* */
#define FILENO(x) fileno(x)

#define ULONG_DEFINED
#define NO_PROFILE

#define start_of_data() &etext
#define start_of_text() ( (char *) 0 )
#define A_TEXT_OFFSET(hdr) (N_MAGIC(hdr) == QMAGIC ? sizeof (struct exec) : 0)
#define A_TEXT_SEEK(hdr) (N_TXTOFF(hdr) + A_TEXT_OFFSET(hdr))
#define ADJUST_EXEC_HEADER \
  unexec_text_start = N_TXTADDR(ohdr) + A_TEXT_OFFSET(ohdr)

#define UNIXSAVE "unexec-19.27.c"

#undef LD_COMMAND
#define LD_COMMAND(command,main,start,input,ldarg,output) \
  sprintf(command, "ld -d -S -N -x -A %s -T %x %s %s -o %s", \
            main,start,input,ldarg,output)

#define SET_SESSION_ID() (setpgrp() ? -1 : 0)

/* Begin for cmpinclude */
/* yes we have alloca */
#define HAVE_ALLOCA


/* NOTE: If you don't have the system call mprotect DON'T
   define this.
   I have added it to my own kernel.
   */
   
/* #define SGC */

/* _setjmp and _longjmp exist on bsd and are more efficient
   and handle the C stack which is all we need. [I think!]
   
 */


/* End for cmpinclude */


