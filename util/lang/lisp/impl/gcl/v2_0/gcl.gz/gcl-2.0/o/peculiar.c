

#ifndef PECULIAR_MACHINE

#define BIGM    (int)((((unsigned int)(-1))/2))

int ONEM = -1;
int Bigm  = BIGM;
int Smallm = -BIGM-1;
int Seven = 7;
int Three = 3;

main()
{
#define BIGM    (int)((((unsigned int)(-1))/2))	 
	{ 
	  int ONEM = -1;
	  int Bixsgm  = BIGM;
	  int Smallm = -BIGM-1;
	  int Seven = 7;
	  int Three = 3;
	  if ( (Smallm / Seven)  < 0
	      && (Smallm / (-Seven))  > 0
	      && (Bigm / (-Seven)) < 0 
	      && ((-Seven) / Three) == -2
	      && (Seven / (-Three)) == -2
	      && ((-Seven)/ (-Three)) == 2)
	    {     printf("#define TRUNCATE_USE_C\n");
		  

		}
	  printf("%d\n",(Smallm/-1));
	}}
#endif
      
    
  

   
