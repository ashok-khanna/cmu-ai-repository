#ifndef _GUIS_H_
#define _GUIS_H_

#include <stdlib.h>

#define STRING_HEADER_FORMAT	"%4.4d"
#define CB_STRING_HEADER	(5)
/*
#define GET_STRING_SIZE_FROM_HEADER(__buf, __plgth)	\
sscanf(__buf, STRING_HEADER_FORMAT, __plgth);
*/

/* sscanf is braindead on SunOS */
#define GET_STRING_SIZE_FROM_HEADER(__buf, __plgth)	\
{\
   __buf[CB_STRING_HEADER - 1] = 0;\
   *__plgth = atoi(__buf);\
   __buf[4] = '';\
}

/* need to have opportunity to collapse message to reduce trafic */
#define MSG_STRAIGHT_TCL_CMD		0
#define MSG_CREATE_COMMAND	1
/*
#define MSG_
*/

typedef struct _guiMsg {

  pid_t pidSender;
  int vMajor;
  int vMinor;
  int idx;
  int fSignal;
  int fAck;
  int IdMsg;
  char *szData;
  char *szMsg;

} guiMsg;

#define MSG_IDX(__p)			(__p->idx)
#define MSG_COMMAND(__p)		(__p->IdMsg)
#define MSG_NEED_ACK(__p)		(__p->fAck)
#define MSG_NEED_SIGNAL_PARENT(__p)	(__p->fSignal)
#define MSG_TCL_STR(__p)		(__p->szData)
#define MSG_DATA_STR(__p)		(__p->szData)
/*
#define MSG_(__p)		(__p->)
*/

#include "sheader.h"
struct message_header * guiParseMsg1();


extern pid_t parent;

struct connection_state *
sock_connect_to_name( char *host_id, int name, int async );
void sock_close_connection( );
int sock_read_str(int connection, char *buffer, int max_len);

guiMsg *guiParseMsg(struct connection_state *sfd);
void guiFreeMsg(guiMsg *pgmsg);

void
guiCreateThenBindCallback(int idLispObject, int iSlot
			  , char *szTclObject, char *szModifier, char *arglist);
int guiBindCallback(char *szNameCmdProc, char *szTclObject, char *szModifier,char* arglist);

#endif
