
#include <cmpinclude.h>
#include "cmplam.h"
init_cmplam(){do_init(VV);}
/*	macro definition for CK-SPEC	*/

static L1()
{register object *base=vs_base;
	register object *sup=base+VM1; VC1
	vs_reserve(VM1);
	check_arg(2);
	vs_top=sup;
	{object V1=base[0]->c.c_cdr;
	if(endp(V1))invalid_macro_call();
	base[2]= (V1->c.c_car);
	V1=V1->c.c_cdr;
	if(!endp(V1))invalid_macro_call();}
	base[3]= list(3,VV[0],base[2],VV[1]);
	vs_top=(vs_base=base+3)+1;
	return;
}
/*	macro definition for CK-VL	*/

static L2()
{register object *base=vs_base;
	register object *sup=base+VM2; VC2
	vs_reserve(VM2);
	check_arg(2);
	vs_top=sup;
	{object V2=base[0]->c.c_cdr;
	if(endp(V2))invalid_macro_call();
	base[2]= (V2->c.c_car);
	V2=V2->c.c_cdr;
	if(!endp(V2))invalid_macro_call();}
	base[3]= list(3,VV[0],base[2],VV[2]);
	vs_top=(vs_base=base+3)+1;
	return;
}
/*	macro definition for DOWNWARD-FUNCTION	*/

static L3()
{register object *base=vs_base;
	register object *sup=base+VM3; VC3
	vs_reserve(VM3);
	check_arg(2);
	vs_top=sup;
	{object V3=base[0]->c.c_cdr;
	if(endp(V3))invalid_macro_call();
	base[2]= (V3->c.c_car);
	V3=V3->c.c_cdr;
	if(!endp(V3))invalid_macro_call();}
	base[3]= list(2,VV[3],base[2]);
	vs_top=(vs_base=base+3)+1;
	return;
}
/*	local entry for function C1DOWNWARD-FUNCTION	*/

static object LI4(V5)

register object V5;
{	 VMB4 VMS4 VMV4
TTL:;
	{register object V6;
	object V7;
	V8= list(2,VV[3],car((V5)));
	V6= (*(LnkLI79))(/* INLINE-ARGS */V8);
	V7= cadr((V6));
	if(!(type_of((V5))==t_cons)){
	goto T4;}
	if(!(type_of(car((V5)))==t_cons)){
	goto T4;}
	if(!((caar((V5)))==(VV[4]))){
	goto T4;}
	if((cadr(car((V5))))!=Cnil){
	goto T4;}
	{register object V9;
	register object V10;
	V9= structure_ref((V7),VV[5],1);
	V10= car((V9));
T16:;
	if(!(endp((V9)))){
	goto T17;}
	goto T12;
T17:;
	V11= structure_ref((V10),VV[6],1);
	if(!((/* INLINE-ARGS */V11)==(VV[7]))){
	goto T21;}
	if((structure_ref((V10),VV[6],3))==Cnil){
	goto T21;}
	(void)(structure_set((V10),VV[6],1,VV[8]));
T21:;
	V9= cdr((V9));
	V10= car((V9));
	goto T16;}
T12:;
	if(type_of(V6)!=t_cons)FEwrong_type_argument(Scons,V6);
	(V6)->c.c_car = VV[9];
	{object V14 = (V6);
	VMR4(V14)}
T4:;
	{object V15 = (V6);
	VMR4(V15)}}
}
/*	local entry for function WT-MAKE-DCLOSURE	*/

static object LI5(V18,V19)

register object V18;object V19;
{	 VMB5 VMS5 VMV5
TTL:;
	princ_str("\n	(DownClose",VV[10]);
	(void)((*(LnkLI80))((V18)));
	princ_str(".t=t_dclosure,DownClose",VV[10]);
	(void)((*(LnkLI80))((V18)));
	princ_str(".dc_self=LC",VV[10]);
	(void)((*(LnkLI80))((V18)));
	princ_char(44,VV[10]);
	princ_str("DownClose",VV[10]);
	(void)((*(LnkLI80))((V18)));
	princ_str(".dc_env=base0,(object)&DownClose",VV[10]);
	(void)((*(LnkLI80))((V18)));
	princ_char(41,VV[10]);
	{object V20 = Cnil;
	VMR5(V20)}
}
/*	local entry for function WFS-ERROR	*/

static object LI6()

{	 VMB6 VMS6 VMV6
TTL:;
	base[0]= VV[11];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk81)();
	vs_top=sup;
	{object V21 = vs_base[0];
	VMR6(V21)}
}
/*	local entry for function WT-DOWNWARD-CLOSURE-MACRO	*/

static object LI7(V23)

object V23;
{	 VMB7 VMS7 VMV7
TTL:;
	if((symbol_value(VV[12]))==Cnil){
	goto T49;}
	princ_str("\n#define DCnames",VV[13]);
	(void)((*(LnkLI82))((V23)));
	princ_char(32,VV[13]);
	setq(VV[12],(VFUN_NARGS=2,(*(LnkLI83))(VV[14],symbol_value(VV[12]))));
	if((symbol_value(VV[12]))==Cnil){
	goto T58;}
	(void)((*(LnkLI82))(VV[15]));
	{register object V24;
	V24= symbol_value(VV[12]);
T63:;
	if(((V24))!=Cnil){
	goto T64;}
	goto T61;
T64:;
	(void)((*(LnkLI82))(VV[16]));
	(void)((*(LnkLI82))(car((V24))));
	if((cdr((V24)))==Cnil){
	goto T70;}
	(void)((*(LnkLI82))(VV[17]));
T70:;
	V24= cdr((V24));
	goto T63;}
T61:;
	{object V25 = (*(LnkLI82))(VV[18]);
	VMR7(V25)}
T58:;
	{object V26 = Cnil;
	VMR7(V26)}
T49:;
	{object V27 = Cnil;
	VMR7(V27)}
}
/*	local entry for function C2DOWNWARD-FUNCTION	*/

static object LI8(V29)

object V29;
{	 VMB8 VMS8 VMV8
TTL:;
	{register object V30;
	setq(VV[22],number_plus(symbol_value(VV[22]),small_fixnum(1)));
	V30= (VFUN_NARGS=4,(*(LnkLI84))(VV[19],VV[20],VV[21],symbol_value(VV[22])));
	if((symbol_value(VV[25]))!=Cnil){
	goto T82;}
	V31= Cnil;
	goto T80;
T82:;
	V31= make_cons(small_fixnum(0),small_fixnum(0));
T80:;
	V32= list(5,VV[24],V31,symbol_value(VV[26]),(V30),(V29));
	setq(VV[23],make_cons(/* INLINE-ARGS */V32,symbol_value(VV[23])));
	setq(VV[27],make_cons((V30),symbol_value(VV[27])));
	V33= structure_ref((V30),VV[28],3);
	setq(VV[12],make_cons(/* INLINE-ARGS */V33,symbol_value(VV[12])));
	V34= list(3,VV[29],structure_ref((V30),VV[28],3),symbol_value(VV[25]));
	{object V35 = (VFUN_NARGS=1,(*(LnkLI85))(/* INLINE-ARGS */V34));
	VMR8(V35)}}
}
/*	local entry for function C1LAMBDA-EXPR	*/

static object LI9(V36,va_alist)
	object V36;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB9 VMS9 VMV9
	bds_check;
	{object V37;
	object V38;
	object V39;
	if(narg <1) too_few_arguments();
	V37= V36;
	narg = narg - 1;
	if (narg <= 0) goto T88;
	else {
	va_start(ap);
	V38= va_arg(ap,object);}
	V39= Ct;
	--narg; goto T89;
T88:;
	V38= Cnil;
	V39= Cnil;
T89:;
	{object V40;
	object V41;
	object V42;
	object V43;
	object V44;
	object V45;
	object V46;
	object V47;
	object V48;
	object V49;
	register object V50;
	register object V51;
	object V52;
	register object V53;
	register object V54;
	register object V55;
	object V56;
	register object V57;
	object V58;
	object V59;
	object V60;
	V40= Cnil;
	V41= Cnil;
	V42= Cnil;
	V43= Cnil;
	V44= Cnil;
	V45= Cnil;
	V46= Cnil;
	V47= Cnil;
	V48= Cnil;
	V49= Cnil;
	V50= Cnil;
	V51= Cnil;
	V52= Cnil;
	V53= Cnil;
	V54= Cnil;
	V55= Cnil;
	V56= Cnil;
	V57= Cnil;
	bds_bind(VV[30],symbol_value(VV[30]));
	V58= (VFUN_NARGS=0,(*(LnkLI86))());
	V59= Cnil;
	V60= symbol_value(VV[31]);
	if(!(endp((V37)))){
	goto T112;}
	V61= make_cons(VV[4],(V37));
	(void)((VFUN_NARGS=2,(*(LnkLI87))(VV[32],/* INLINE-ARGS */V61)));
T112:;
	base[2]= cdr((V37));
	base[3]= Ct;
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk88)();
	if(vs_base<vs_top){
	V52= vs_base[0];
	vs_base++;
	}else{
	V52= Cnil;}
	if(vs_base<vs_top){
	V53= vs_base[0];
	vs_base++;
	}else{
	V53= Cnil;}
	if(vs_base<vs_top){
	V55= vs_base[0];
	vs_base++;
	}else{
	V55= Cnil;}
	if(vs_base<vs_top){
	V54= vs_base[0];
	vs_base++;
	}else{
	V54= Cnil;}
	if(vs_base<vs_top){
	V56= vs_base[0];
	vs_base++;
	}else{
	V56= Cnil;}
	if(vs_base<vs_top){
	V49= vs_base[0];
	}else{
	V49= Cnil;}
	vs_top=sup;
	if(((V39))==Cnil){
	goto T119;}
	V62= listA(3,VV[33],(V38),(V52));
	V52= make_cons(/* INLINE-ARGS */V62,Cnil);
T119:;
	(void)((*(LnkLI89))((V53)));
	V50= car((V37));
T128:;
	if(((V50))!=Cnil){
	goto T134;}
	goto T126;
T134:;
	if(type_of((V50))==t_cons){
	goto T137;}
	(void)((VFUN_NARGS=2,(*(LnkLI87))(VV[34],(V50))));
T137:;
	{object V64;
	V64= car((V50));
	V50= cdr((V50));
	V51= (V64);}
	{object V63= (V51);
	if((V63!= VV[69]))goto T145;
	goto T129;
T145:;
	if((V63!= VV[68]))goto T146;
	goto T130;
T146:;
	if((V63!= VV[71]))goto T147;
	goto T131;
T147:;
	if((V63!= VV[73]))goto T148;
	goto T132;
T148:;}
	{object V65;
	V65= (*(LnkLI90))((V51),(V53),(V54),(V55));
	V57= make_cons((V51),(V57));
	(VV[30]->s.s_dbind)= make_cons((V65),(VV[30]->s.s_dbind));
	V40= make_cons((V65),(V40));}
	goto T128;
T129:;
	if(((V50))!=Cnil){
	goto T156;}
	goto T126;
T156:;
	if(type_of((V50))==t_cons){
	goto T159;}
	(void)((VFUN_NARGS=2,(*(LnkLI87))(VV[34],(V50))));
T159:;
	{object V67;
	V67= car((V50));
	V50= cdr((V50));
	V51= (V67);}
	{object V66= (V51);
	if((V66!= VV[68]))goto T167;
	goto T130;
T167:;
	if((V66!= VV[71]))goto T168;
	goto T131;
T168:;
	if((V66!= VV[73]))goto T169;
	goto T132;
T169:;}
	if(type_of((V51))==t_cons){
	goto T172;}
	{object V68;
	V68= (*(LnkLI90))((V51),(V53),(V54),(V55));
	V57= make_cons((V51),(V57));
	V69= structure_ref((V68),VV[6],5);
	V70= (*(LnkLI91))(/* INLINE-ARGS */V69);
	V71= list(3,(V68),/* INLINE-ARGS */V70,Cnil);
	V41= make_cons(/* INLINE-ARGS */V71,(V41));
	(VV[30]->s.s_dbind)= make_cons((V68),(VV[30]->s.s_dbind));
	goto T170;}
T172:;
	if(type_of(cdr((V51)))==t_cons){
	goto T181;}
	if((cdr((V51)))==Cnil){
	goto T183;}
	(void)((VFUN_NARGS=2,(*(LnkLI87))(VV[35],(V51))));
T183:;
	{object V72;
	V72= (*(LnkLI90))(car((V51)),(V53),(V54),(V55));
	V57= make_cons(car((V51)),(V57));
	V73= structure_ref((V72),VV[6],5);
	V74= (*(LnkLI91))(/* INLINE-ARGS */V73);
	V75= list(3,(V72),/* INLINE-ARGS */V74,Cnil);
	V41= make_cons(/* INLINE-ARGS */V75,(V41));
	(VV[30]->s.s_dbind)= make_cons((V72),(VV[30]->s.s_dbind));
	goto T170;}
T181:;
	if(type_of(cddr((V51)))==t_cons){
	goto T193;}
	if((cddr((V51)))==Cnil){
	goto T195;}
	(void)((VFUN_NARGS=2,(*(LnkLI87))(VV[35],(V51))));
T195:;
	{object V76;
	object V77;
	V76= (*(LnkLI92))(cadr((V51)),(V58));
	V77= (*(LnkLI90))(car((V51)),(V53),(V54),(V55));
	V57= make_cons(car((V51)),(V57));
	V78= structure_ref((V77),VV[6],5);
	V79= (*(LnkLI93))(/* INLINE-ARGS */V78,(V76),cadr((V51)));
	V80= list(3,(V77),/* INLINE-ARGS */V79,Cnil);
	V41= make_cons(/* INLINE-ARGS */V80,(V41));
	(VV[30]->s.s_dbind)= make_cons((V77),(VV[30]->s.s_dbind));
	goto T170;}
T193:;
	if((cdddr((V51)))==Cnil){
	goto T205;}
	(void)((VFUN_NARGS=2,(*(LnkLI87))(VV[35],(V51))));
T205:;
	{object V81;
	object V82;
	object V83;
	V81= (*(LnkLI92))(cadr((V51)),(V58));
	V82= (*(LnkLI90))(car((V51)),(V53),(V54),(V55));
	V83= (*(LnkLI90))(caddr((V51)),(V53),(V54),(V55));
	V57= make_cons(car((V51)),(V57));
	V57= make_cons(caddr((V51)),(V57));
	V84= structure_ref((V82),VV[6],5);
	V85= (*(LnkLI93))(/* INLINE-ARGS */V84,(V81),cadr((V51)));
	V86= list(3,(V82),/* INLINE-ARGS */V85,(V83));
	V41= make_cons(/* INLINE-ARGS */V86,(V41));
	(VV[30]->s.s_dbind)= make_cons((V82),(VV[30]->s.s_dbind));
	(VV[30]->s.s_dbind)= make_cons((V83),(VV[30]->s.s_dbind));}
T170:;
	goto T129;
T130:;
	if(type_of((V50))==t_cons){
	goto T220;}
	(void)((VFUN_NARGS=2,(*(LnkLI87))(VV[34],(V50))));
T220:;
	V57= make_cons(car((V50)),(V57));
	{object V88;
	V88= car((V50));
	V50= cdr((V50));
	V87= (V88);}
	V42= (*(LnkLI90))(V87,(V53),(V54),(V55));
	(VV[30]->s.s_dbind)= make_cons((V42),(VV[30]->s.s_dbind));
	if(((V50))!=Cnil){
	goto T233;}
	goto T126;
T233:;
	if(type_of((V50))==t_cons){
	goto T236;}
	(void)((VFUN_NARGS=2,(*(LnkLI87))(VV[34],(V50))));
T236:;
	{object V90;
	V90= car((V50));
	V50= cdr((V50));
	V51= (V90);}
	{object V89= (V51);
	if((V89!= VV[71]))goto T244;
	goto T131;
T244:;
	if((V89!= VV[73]))goto T245;
	goto T132;
T245:;}
	(void)((VFUN_NARGS=2,(*(LnkLI87))(VV[36],(V51))));
T131:;
	V44= Ct;
	if(((V50))!=Cnil){
	goto T248;}
	goto T126;
T248:;
	if(type_of((V50))==t_cons){
	goto T251;}
	(void)((VFUN_NARGS=2,(*(LnkLI87))(VV[34],(V50))));
T251:;
	{object V92;
	V92= car((V50));
	V50= cdr((V50));
	V51= (V92);}
	{object V91= (V51);
	if((V91!= VV[73]))goto T259;
	goto T132;
T259:;
	if((V91!= VV[72]))goto T260;
	V46= Ct;
	if(((V50))!=Cnil){
	goto T263;}
	goto T126;
T263:;
	if(type_of((V50))==t_cons){
	goto T266;}
	(void)((VFUN_NARGS=2,(*(LnkLI87))(VV[34],(V50))));
T266:;
	{object V94;
	V94= car((V50));
	V50= cdr((V50));
	V51= (V94);}
	{object V93= (V51);
	if((V93!= VV[73]))goto T274;
	goto T132;
T274:;}
	(void)((VFUN_NARGS=2,(*(LnkLI87))(VV[37],(V51))));
	goto T254;
T260:;}
T254:;
	if(type_of((V51))==t_cons){
	goto T275;}
	V51= make_cons((V51),Cnil);
T275:;
	if(!(type_of(car((V51)))==t_cons)){
	goto T281;}
	{object V95= caar((V51));
	if(!((type_of(V95)==t_symbol&&(V95)->s.s_hpack==keyword_package))){
	goto T284;}}
	if(!(type_of(cdar((V51)))==t_cons)){
	goto T284;}
	if((cddar((V51)))==Cnil){
	goto T283;}
T284:;
	(void)((VFUN_NARGS=2,(*(LnkLI87))(VV[35],(V51))));
T283:;
	V51= listA(3,caar((V51)),cadar((V51)),cdr((V51)));
	goto T279;
T281:;
	if(type_of(car((V51)))==t_symbol){
	goto T291;}
	(void)((VFUN_NARGS=2,(*(LnkLI87))(VV[35],(V51))));
T291:;
	base[2]= coerce_to_string(car((V51)));
	base[3]= VV[38];
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk94)();
	vs_top=sup;
	V96= vs_base[0];
	V51= listA(3,V96,car((V51)),cdr((V51)));
T279:;
	if(type_of(cddr((V51)))==t_cons){
	goto T300;}
	if((cddr((V51)))==Cnil){
	goto T302;}
	(void)((VFUN_NARGS=2,(*(LnkLI87))(VV[35],(V51))));
T302:;
	{object V97;
	V97= (*(LnkLI90))(cadr((V51)),(V53),(V54),(V55));
	V57= make_cons(cadr((V51)),(V57));
	V98= car((V51));
	V99= structure_ref((V97),VV[6],5);
	V100= (*(LnkLI91))(/* INLINE-ARGS */V99);
	V101= list(4,/* INLINE-ARGS */V98,(V97),/* INLINE-ARGS */V100,(VFUN_NARGS=2,(*(LnkLI95))(VV[39],VV[40])));
	V43= make_cons(/* INLINE-ARGS */V101,(V43));
	(VV[30]->s.s_dbind)= make_cons((V97),(VV[30]->s.s_dbind));
	goto T298;}
T300:;
	if(type_of(cdddr((V51)))==t_cons){
	goto T312;}
	if((cdddr((V51)))==Cnil){
	goto T314;}
	(void)((VFUN_NARGS=2,(*(LnkLI87))(VV[35],(V51))));
T314:;
	{object V102;
	object V103;
	V102= (*(LnkLI92))(caddr((V51)),(V58));
	V103= (*(LnkLI90))(cadr((V51)),(V53),(V54),(V55));
	V57= make_cons(cadr((V51)),(V57));
	V104= car((V51));
	V105= structure_ref((V103),VV[6],5);
	V106= (*(LnkLI93))(/* INLINE-ARGS */V105,(V102),caddr((V51)));
	V107= list(4,/* INLINE-ARGS */V104,(V103),/* INLINE-ARGS */V106,(VFUN_NARGS=2,(*(LnkLI95))(VV[39],VV[40])));
	V43= make_cons(/* INLINE-ARGS */V107,(V43));
	(VV[30]->s.s_dbind)= make_cons((V103),(VV[30]->s.s_dbind));
	goto T298;}
T312:;
	if((cddddr((V51)))==Cnil){
	goto T324;}
	(void)((VFUN_NARGS=2,(*(LnkLI87))(VV[35],(V51))));
T324:;
	{object V108;
	object V109;
	object V110;
	V108= (*(LnkLI92))(caddr((V51)),(V58));
	V109= (*(LnkLI90))(cadr((V51)),(V53),(V54),(V55));
	V110= (*(LnkLI90))(cadddr((V51)),(V53),(V54),(V55));
	V57= make_cons(cadr((V51)),(V57));
	V57= make_cons(cadddr((V51)),(V57));
	V111= car((V51));
	V112= structure_ref((V109),VV[6],5);
	V113= (*(LnkLI93))(/* INLINE-ARGS */V112,(V108),caddr((V51)));
	V114= list(4,/* INLINE-ARGS */V111,(V109),/* INLINE-ARGS */V113,(V110));
	V43= make_cons(/* INLINE-ARGS */V114,(V43));
	(VV[30]->s.s_dbind)= make_cons((V109),(VV[30]->s.s_dbind));
	(VV[30]->s.s_dbind)= make_cons((V110),(VV[30]->s.s_dbind));}
T298:;
	goto T131;
T132:;
	V59= (VFUN_NARGS=0,(*(LnkLI86))());
T133:;
	if(((V50))!=Cnil){
	goto T340;}
	(void)((*(LnkLI96))((V58),(V59)));
	goto T126;
T340:;
	if(type_of((V50))==t_cons){
	goto T344;}
	(void)((VFUN_NARGS=2,(*(LnkLI87))(VV[34],(V50))));
T344:;
	{object V115;
	V115= car((V50));
	V50= cdr((V50));
	V51= (V115);}
	if(!(type_of((V51))==t_cons)){
	goto T354;}
	if(type_of(cdr((V51)))==t_cons){
	goto T357;}
	if((cdr((V51)))==Cnil){
	goto T359;}
	(void)((VFUN_NARGS=2,(*(LnkLI87))(VV[35],(V51))));
T359:;
	{object V116;
	V116= (*(LnkLI90))(car((V51)),(V53),(V54),(V55));
	V57= make_cons(car((V51)),(V57));
	V117= structure_ref((V116),VV[6],5);
	V118= (*(LnkLI91))(/* INLINE-ARGS */V117);
	V48= make_cons(/* INLINE-ARGS */V118,(V48));
	V47= make_cons((V116),(V47));
	(VV[30]->s.s_dbind)= make_cons((V116),(VV[30]->s.s_dbind));
	goto T352;}
T357:;
	if((cddr((V51)))==Cnil){
	goto T370;}
	(void)((VFUN_NARGS=2,(*(LnkLI87))(VV[35],(V51))));
T370:;
	{object V119;
	object V120;
	V119= (*(LnkLI92))(cadr((V51)),(V59));
	V120= (*(LnkLI90))(car((V51)),(V53),(V54),(V55));
	V57= make_cons(car((V51)),(V57));
	V121= structure_ref((V120),VV[6],5);
	V122= (*(LnkLI93))(/* INLINE-ARGS */V121,(V119),cadr((V51)));
	V48= make_cons(/* INLINE-ARGS */V122,(V48));
	V47= make_cons((V120),(V47));
	(VV[30]->s.s_dbind)= make_cons((V120),(VV[30]->s.s_dbind));
	goto T352;}
T354:;
	{object V123;
	V123= (*(LnkLI90))((V51),(V53),(V54),(V55));
	V57= make_cons((V51),(V57));
	V124= structure_ref((V123),VV[6],5);
	V125= (*(LnkLI91))(/* INLINE-ARGS */V124);
	V48= make_cons(/* INLINE-ARGS */V125,(V48));
	V47= make_cons((V123),(V47));
	(VV[30]->s.s_dbind)= make_cons((V123),(VV[30]->s.s_dbind));}
T352:;
	goto T133;
T126:;
	V40= reverse((V40));
	V41= reverse((V41));
	V43= reverse((V43));
	V47= reverse((V47));
	V48= reverse((V48));
	(void)((*(LnkLI97))((V57),(V55),(V54)));
	V52= (*(LnkLI98))((V56),(V52));
	(void)((*(LnkLI96))((V58),cadr((V52))));
	{object V126;
	object V127;
	V126= (V40);
	V127= car((V126));
T409:;
	if(!(endp((V126)))){
	goto T410;}
	goto T405;
T410:;
	(void)((*(LnkLI99))((V127)));
	V126= cdr((V126));
	V127= car((V126));
	goto T409;}
T405:;
	{object V128;
	object V129;
	V128= (V41);
	V129= car((V128));
T424:;
	if(!(endp((V128)))){
	goto T425;}
	goto T420;
T425:;
	(void)((*(LnkLI99))(car((V129))));
	if((caddr((V129)))==Cnil){
	goto T430;}
	(void)((*(LnkLI99))(caddr((V129))));
T430:;
	V128= cdr((V128));
	V129= car((V128));
	goto T424;}
T420:;
	if(((V42))==Cnil){
	goto T438;}
	(void)((*(LnkLI99))((V42)));
T438:;
	{object V130;
	object V131;
	V130= (V43);
	V131= car((V130));
T445:;
	if(!(endp((V130)))){
	goto T446;}
	goto T441;
T446:;
	(void)((*(LnkLI99))(cadr((V131))));
	if((cadddr((V131)))==Cnil){
	goto T451;}
	(void)((*(LnkLI99))(cadddr((V131))));
T451:;
	V130= cdr((V130));
	V131= car((V130));
	goto T445;}
T441:;
	{object V132;
	object V133;
	V132= (V47);
	V133= car((V132));
T463:;
	if(!(endp((V132)))){
	goto T464;}
	goto T459;
T464:;
	(void)((*(LnkLI99))((V133)));
	V132= cdr((V132));
	V133= car((V132));
	goto T463;}
T459:;
	if(((V47))==Cnil){
	goto T474;}
	(void)((*(LnkLI96))((V59),cadr((V52))));
	V52= list(5,VV[41],(V59),(V47),(V48),(V52));{object V134;
	base[2]= (V60);
	base[3]= symbol_value(VV[31]);
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk100)();
	vs_top=sup;
	V134= vs_base[0];
	if(V134==Cnil)goto T480;
	goto T474;
T480:;}
	(void)(structure_set((V59),VV[5],4,Ct));
T474:;
	V52= (*(LnkLI101))((V40),(V52),(V38));
	V45= list(6,(V40),(V41),(V42),(V44),(V43),(V46));
	if(symbol_value(VV[42])==Cnil){
	goto T488;}
	(void)((*(LnkLI102))((V45)));
T488:;
	{object V135 = list(5,VV[4],(V58),(V45),(V49),(V52));
	bds_unwind1;
	VMR9(V135)}}}
	}
/*	local entry for function FIX-DOWN-ARGS	*/

static object LI10(V139,V140,V141)

object V139;object V140;object V141;
{	 VMB10 VMS10 VMV10
TTL:;
	{object V142;
	object V143;
	register object V144;
	register object V145;
	V142= Cnil;
	V143= Cnil;
	V144= Cnil;
	V145= Cnil;
	{object V146;
	object V147;
	V146= get((V141),VV[43],Cnil);
	V147= get((V141),VV[44],Cnil);
	{register object V148;
	register object V149;
	V148= (V139);
	V149= (V146);
T497:;
	if(((V148))!=Cnil){
	goto T498;}
	goto T495;
T498:;
	V145= car((V148));
	if(((V147))!=Cnil){
	goto T506;}
	if((car((V149)))==(Ct)){
	goto T506;}
	{object V150 = (V140);
	VMR10(V150)}
T506:;
	V151= structure_ref((V145),VV[6],1);
	if(!((/* INLINE-ARGS */V151)==(VV[8]))){
	goto T504;}
	V152= structure_ref((V145),VV[6],4);
	if(!((/* INLINE-ARGS */V152)==(VV[45]))){
	goto T504;}
	{register object V153;
	object V154;
	V155= structure_ref((V145),VV[6],0);
	V153= (*(LnkLI90))(/* INLINE-ARGS */V155,Cnil,Cnil,Cnil);
	if((V144)!=Cnil){
	V156= (V144);
	goto T516;}
	V144= (VFUN_NARGS=0,(*(LnkLI86))());
	V156= (V144);
T516:;
	V154= list(3,VV[6],V156,list(2,(V153),Cnil));
	V142= make_cons((V145),(V142));
	{register object V158;
	V158= (V153);
	if(type_of(V148)!=t_cons)FEwrong_type_argument(Scons,V148);
	(V148)->c.c_car = (V158);}
	{register object V159;
	object V160;
	V159= (V144);
	V161= structure_ref((V159),VV[5],1);
	V160= make_cons((V153),/* INLINE-ARGS */V161);
	(void)(structure_set((V159),VV[5],1,(V160)));}
	V143= make_cons((V154),(V143));}
T504:;
	V148= cdr((V148));
	V149= cdr((V149));
	goto T497;}
T495:;
	if(((V142))==Cnil){
	goto T532;}
	{object V162 = list(5,VV[41],(V144),(V142),(V143),(V140));
	VMR10(V162)}
T532:;
	{object V163 = (V140);
	VMR10(V163)}}}
}
/*	local entry for function THE-PARAMETER	*/

static object LI11(V165)

register object V165;
{	 VMB11 VMS11 VMV11
TTL:;
	if(type_of((V165))==t_symbol){
	goto T534;}
	(void)((VFUN_NARGS=2,(*(LnkLI87))(VV[46],(V165))));
T534:;
	base[0]= (V165);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk103)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T537;}
	(void)((VFUN_NARGS=2,(*(LnkLI87))(VV[47],(V165))));
T537:;
	{object V166 = (V165);
	VMR11(V166)}
}
/*	local entry for function C2LAMBDA-EXPR	*/

static object LI12(V168,V167,va_alist)
	object V168,V167;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB12 VMS12 VMV12
	bds_check;
	{register object V169;
	object V170;
	object V171;
	object V172;
	if(narg <2) too_few_arguments();
	V169= V168;
	V170= V167;
	narg = narg - 2;
	if (narg <= 0) goto T541;
	else {
	va_start(ap);
	V171= va_arg(ap,object);}
	V172= Ct;
	--narg; goto T542;
T541:;
	V171= Cnil;
	V172= Cnil;
T542:;
	if((symbol_value(VV[49]))==Cnil){
	goto T546;}
	if(((V172))==Cnil){
	goto T546;}
	{register object V173;
	register object V174;
	V173= car((V169));
	V174= car((V173));
T556:;
	if(!(endp((V173)))){
	goto T557;}
	goto T552;
T557:;
	if((structure_ref((V174),VV[6],3))==Cnil){
	goto T561;}
	goto T546;
T561:;
	V173= cdr((V173));
	V174= car((V173));
	goto T556;}
T552:;
	if((cadr((V169)))!=Cnil){
	goto T546;}
	if((caddr((V169)))!=Cnil){
	goto T546;}
	if((cadddr((V169)))!=Cnil){
	goto T546;}
	base[0]= make_cons((V171),car((V169)));
	goto T544;
T546:;
	base[0]= Cnil;
T544:;
	bds_bind(VV[48],base[0]);
	if((caddr((V169)))==Cnil){
	goto T576;}
	V175= structure_ref(caddr((V169)),VV[6],5);
	if(!((/* INLINE-ARGS */V175)==(VV[51]))){
	goto T576;}
	base[1]= Ct;
	goto T574;
T576:;
	base[1]= symbol_value(VV[50]);
T574:;
	bds_bind(VV[50],base[1]);
	if((cadddr((V169)))==Cnil){
	goto T581;}
	{object V176 = (*(LnkLI104))((V169),(V170));
	bds_unwind1;
	bds_unwind1;
	VMR12(V176)}
T581:;
	{object V177 = (*(LnkLI105))((V169),(V170));
	bds_unwind1;
	bds_unwind1;
	VMR12(V177)}}
	}
/*	local entry for function C2LAMBDA-EXPR-WITHOUT-KEY	*/

static object LI13(V180,V181)

object V180;object V181;
{	 VMB13 VMS13 VMV13
	bds_check;
TTL:;
	{object V182;
	object V183;
	object V184;
	register object V185;
	V182= car((V180));
	V183= cadr((V180));
	V184= caddr((V180));
	V185= Cnil;
	bds_bind(VV[52],symbol_value(VV[52]));
	bds_bind(VV[53],symbol_value(VV[53]));
	bds_bind(VV[25],symbol_value(VV[25]));
	bds_bind(VV[26],symbol_value(VV[26]));
	base[7]= Cnil;
	{register object V186;
	object V187;
	V186= (V182);
	V187= car((V186));
T592:;
	if(!(endp((V186)))){
	goto T593;}
	goto T588;
T593:;
	base[9]= (V187);
	vs_top=(vs_base=base+9)+1;
	L14(base);
	vs_top=sup;
	V186= cdr((V186));
	V187= car((V186));
	goto T592;}
T588:;
	{register object V188;
	object V189;
	V188= (V183);
	V189= car((V188));
T608:;
	if(!(endp((V188)))){
	goto T609;}
	goto T604;
T609:;
	base[9]= car((V189));
	vs_top=(vs_base=base+9)+1;
	L14(base);
	vs_top=sup;
	if((caddr((V189)))==Cnil){
	goto T615;}
	base[9]= caddr((V189));
	vs_top=(vs_base=base+9)+1;
	L14(base);
	vs_top=sup;
T615:;
	V188= cdr((V188));
	V189= car((V188));
	goto T608;}
T604:;
	if(((V184))==Cnil){
	goto T587;}
	base[8]= (V184);
	vs_top=(vs_base=base+8)+1;
	L14(base);
	vs_top=sup;
T587:;
	if((symbol_value(VV[55]))!=Cnil){
	goto T628;}
	if((symbol_value(VV[56]))==Cnil){
	goto T627;}
T628:;
	if(((V184))!=Cnil){
	goto T632;}
	if(((V183))==Cnil){
	goto T633;}
T632:;
	if(((V182))==Cnil){
	goto T637;}
	princ_str("\n	if(vs_top-vs_base<",VV[10]);
	V190 = make_fixnum(length((V182)));
	(void)((*(LnkLI80))(V190));
	princ_str(") too_few_arguments();",VV[10]);
T637:;
	if(((V184))!=Cnil){
	goto T627;}
	princ_str("\n	if(vs_top-vs_base>",VV[10]);
	V191 = make_fixnum(length((V182)));
	V192 = make_fixnum(length((V183)));
	V193= number_plus(V191,V192);
	(void)((*(LnkLI80))(/* INLINE-ARGS */V193));
	princ_str(") too_many_arguments();",VV[10]);
	goto T627;
T633:;
	princ_str("\n	check_arg(",VV[10]);
	V194 = make_fixnum(length((V182)));
	(void)((*(LnkLI80))(V194));
	princ_str(");",VV[10]);
T627:;
	{register object V195;
	object V196;
	V195= (V182);
	V196= car((V195));
T655:;
	if(!(endp((V195)))){
	goto T656;}
	goto T651;
T656:;
	V197= (*(LnkLI106))();
	(void)(structure_set((V196),VV[6],2,/* INLINE-ARGS */V197));
	V195= cdr((V195));
	V196= car((V195));
	goto T655;}
T651:;
	{register object V198;
	object V199;
	V198= (V183);
	V199= car((V198));
T670:;
	if(!(endp((V198)))){
	goto T671;}
	goto T666;
T671:;
	V200= car((V199));
	V201= (*(LnkLI106))();
	(void)(structure_set(/* INLINE-ARGS */V200,VV[6],2,/* INLINE-ARGS */V201));
	V198= cdr((V198));
	V199= car((V198));
	goto T670;}
T666:;
	if(((V184))==Cnil){
	goto T681;}
	V202= (*(LnkLI106))();
	(void)(structure_set((V184),VV[6],2,/* INLINE-ARGS */V202));
T681:;
	{register object V203;
	object V204;
	V203= (V183);
	V204= car((V203));
T688:;
	if(!(endp((V203)))){
	goto T689;}
	goto T684;
T689:;
	if((caddr((V204)))==Cnil){
	goto T693;}
	V205= caddr((V204));
	V206= (*(LnkLI106))();
	(void)(structure_set(/* INLINE-ARGS */V205,VV[6],2,/* INLINE-ARGS */V206));
T693:;
	V203= cdr((V203));
	V204= car((V203));
	goto T688;}
T684:;
	{register object V207;
	object V208;
	V207= (V182);
	V208= car((V207));
T705:;
	if(!(endp((V207)))){
	goto T706;}
	goto T701;
T706:;
	(void)((*(LnkLI107))((V208)));
	V207= cdr((V207));
	V208= car((V207));
	goto T705;}
T701:;
	if(((V183))!=Cnil){
	goto T718;}
	if(((V184))==Cnil){
	goto T716;}
T718:;
	if(((V182))==Cnil){
	goto T716;}
	princ_str("\n	vs_base=vs_base+",VV[10]);
	V209 = make_fixnum(length((V182)));
	(void)((*(LnkLI80))(V209));
	princ_char(59,VV[10]);
T716:;
	if(((V183))==Cnil){
	goto T728;}
	bds_bind(VV[25],(VV[25]->s.s_dbind));
	bds_bind(VV[52],(VV[52]->s.s_dbind));
	bds_bind(VV[26],(VV[26]->s.s_dbind));
	if(((V184))==Cnil){
	goto T731;}
	princ_str("\n	vs_top[0]=Cnil;",VV[10]);
	princ_str("\n	{object *p=vs_top, *q=vs_base+",VV[10]);
	V210 = make_fixnum(length((V183)));
	(void)((*(LnkLI80))(V210));
	princ_char(59,VV[10]);
	princ_str("\n	 for(;p>q;p--)p[-1]=MMcons(p[-1],p[0]);}",VV[10]);
T731:;
	{register object V211;
	V211= (V183);
T743:;
	if(!(endp((V211)))){
	goto T744;}
	goto T741;
T744:;
	setq(VV[57],number_plus(symbol_value(VV[57]),small_fixnum(1)));
	V212= make_cons(symbol_value(VV[57]),Cnil);
	V185= make_cons(/* INLINE-ARGS */V212,(V185));
	princ_str("\n	if(vs_base>=vs_top){",VV[10]);
	(void)((*(LnkLI108))());
	if(type_of(car((V185)))!=t_cons)FEwrong_type_argument(Scons,car((V185)));
	(car((V185)))->c.c_cdr = Ct;
	(void)(car((V185)));
	princ_str("goto T",VV[10]);
	(void)((*(LnkLI80))(car(car((V185)))));
	princ_char(59,VV[10]);
	princ_char(125,VV[10]);
	(void)((*(LnkLI107))(caar((V211))));
	if((caddar((V211)))==Cnil){
	goto T762;}
	(void)((*(LnkLI109))(caddar((V211)),Ct));
T762:;
	if((cdr((V211)))==Cnil){
	goto T765;}
	princ_str("\n	vs_base++;",VV[10]);
T765:;
	V211= cdr((V211));
	goto T743;}
T741:;
	if(((V184))==Cnil){
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	goto T730;}
	V213= (*(LnkLI107))((V184));
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
T730:;
	princ_str("\n	",VV[10]);
	(void)((*(LnkLI108))());
	{object V214;
	setq(VV[57],number_plus(symbol_value(VV[57]),small_fixnum(1)));
	V214= make_cons(symbol_value(VV[57]),Cnil);
	princ_str("\n	",VV[10]);
	if(type_of((V214))!=t_cons)FEwrong_type_argument(Scons,(V214));
	((V214))->c.c_cdr = Ct;
	princ_str("goto T",VV[10]);
	(void)((*(LnkLI80))(car((V214))));
	princ_char(59,VV[10]);
	V185= reverse((V185));
	{register object V215;
	register object V216;
	V215= (V183);
	V216= car((V215));
T790:;
	if(!(endp((V215)))){
	goto T791;}
	goto T786;
T791:;
	if((cdr(car((V185))))==Cnil){
	goto T795;}
	princ_str("\nT",VV[10]);
	(void)((*(LnkLI80))(car(car((V185)))));
	princ_str(":;",VV[10]);
T795:;
	{object V217;
	V217= car((V185));
	V185= cdr((V185));}
	(void)((*(LnkLI110))(car((V216)),cadr((V216))));
	if((caddr((V216)))==Cnil){
	goto T806;}
	(void)((*(LnkLI109))(caddr((V216)),Cnil));
T806:;
	V215= cdr((V215));
	V216= car((V215));
	goto T790;}
T786:;
	if(((V184))==Cnil){
	goto T814;}
	(void)((*(LnkLI109))((V184),Cnil));
T814:;
	if((cdr((V214)))==Cnil){
	goto T726;}
	princ_str("\nT",VV[10]);
	(void)((*(LnkLI80))(car((V214))));
	princ_str(":;",VV[10]);
	goto T726;}
T728:;
	if(((V184))==Cnil){
	goto T823;}
	princ_str("\n	vs_top[0]=Cnil;",VV[10]);
	princ_str("\n	{object *p=vs_top;",VV[10]);
	princ_str("\n	 for(;p>vs_base;p--)p[-1]=",VV[10]);
	if((symbol_value(VV[50]))==Cnil){
	goto T834;}
	V218= VV[58];
	goto T832;
T834:;
	V218= VV[59];
T832:;
	(void)((*(LnkLI80))(V218));
	princ_str("(p[-1],p[0]);}",VV[10]);
	(void)((*(LnkLI107))((V184)));
	princ_str("\n	",VV[10]);
	(void)((*(LnkLI108))());
	goto T726;
T823:;
	princ_str("\n	",VV[10]);
	(void)((*(LnkLI108))());
T726:;
	if((symbol_value(VV[48]))==Cnil){
	goto T840;}
	(VV[52]->s.s_dbind)= make_cons(VV[60],(VV[52]->s.s_dbind));
	princ_str("\nTTL:;",VV[10]);
T840:;
	base[8]= (V181);
	vs_top=(vs_base=base+8)+1;
	(void) (*Lnk111)();
	vs_top=sup;
	if((base[7])==Cnil){
	goto T849;}
	princ_str("\n	}",VV[10]);
	{object V219 = Cnil;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	VMR13(V219)}
T849:;
	{object V220 = Cnil;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	VMR13(V220)}}
}
/*	local entry for function C2LAMBDA-EXPR-WITH-KEY	*/

static object LI15(V223,V224)

object V223;object V224;
{	 VMB14 VMS14 VMV14
	bds_check;
TTL:;
	{object V225;
	object V226;
	object V227;
	object V228;
	object V229;
	register object V230;
	V225= car((V223));
	V226= cadr((V223));
	V227= caddr((V223));
	V228= car(cddddr((V223)));
	V229= cadr(cddddr((V223)));
	V230= Cnil;
	bds_bind(VV[52],symbol_value(VV[52]));
	bds_bind(VV[53],symbol_value(VV[53]));
	bds_bind(VV[25],symbol_value(VV[25]));
	bds_bind(VV[26],symbol_value(VV[26]));
	base[9]= Cnil;
	{register object V231;
	object V232;
	V231= (V225);
	V232= car((V231));
T863:;
	if(!(endp((V231)))){
	goto T864;}
	goto T859;
T864:;
	base[11]= (V232);
	vs_top=(vs_base=base+11)+1;
	L16(base);
	vs_top=sup;
	V231= cdr((V231));
	V232= car((V231));
	goto T863;}
T859:;
	{register object V233;
	object V234;
	V233= (V226);
	V234= car((V233));
T879:;
	if(!(endp((V233)))){
	goto T880;}
	goto T875;
T880:;
	base[11]= car((V234));
	vs_top=(vs_base=base+11)+1;
	L16(base);
	vs_top=sup;
	if((caddr((V234)))==Cnil){
	goto T886;}
	base[11]= caddr((V234));
	vs_top=(vs_base=base+11)+1;
	L16(base);
	vs_top=sup;
T886:;
	V233= cdr((V233));
	V234= car((V233));
	goto T879;}
T875:;
	if(((V227))==Cnil){
	goto T895;}
	base[10]= (V227);
	vs_top=(vs_base=base+10)+1;
	L16(base);
	vs_top=sup;
T895:;
	{register object V235;
	object V236;
	V235= (V228);
	V236= car((V235));
T902:;
	if(!(endp((V235)))){
	goto T903;}
	goto T858;
T903:;
	base[11]= cadr((V236));
	vs_top=(vs_base=base+11)+1;
	L16(base);
	vs_top=sup;
	if((cadddr((V236)))==Cnil){
	goto T909;}
	base[11]= cadddr((V236));
	vs_top=(vs_base=base+11)+1;
	L16(base);
	vs_top=sup;
T909:;
	V235= cdr((V235));
	V236= car((V235));
	goto T902;}
T858:;
	if((symbol_value(VV[55]))!=Cnil){
	goto T920;}
	if((symbol_value(VV[56]))==Cnil){
	goto T918;}
T920:;
	if(((V225))==Cnil){
	goto T918;}
	if(((V225))==Cnil){
	goto T918;}
	princ_str("\n	if(vs_top-vs_base<",VV[10]);
	V237 = make_fixnum(length((V225)));
	(void)((*(LnkLI80))(V237));
	princ_str(") too_few_arguments();",VV[10]);
T918:;
	{register object V238;
	object V239;
	V238= (V225);
	V239= car((V238));
T934:;
	if(!(endp((V238)))){
	goto T935;}
	goto T930;
T935:;
	V240= (*(LnkLI106))();
	(void)(structure_set((V239),VV[6],2,/* INLINE-ARGS */V240));
	V238= cdr((V238));
	V239= car((V238));
	goto T934;}
T930:;
	{register object V241;
	object V242;
	V241= (V226);
	V242= car((V241));
T949:;
	if(!(endp((V241)))){
	goto T950;}
	goto T945;
T950:;
	V243= car((V242));
	V244= (*(LnkLI106))();
	(void)(structure_set(/* INLINE-ARGS */V243,VV[6],2,/* INLINE-ARGS */V244));
	V241= cdr((V241));
	V242= car((V241));
	goto T949;}
T945:;
	if(((V227))==Cnil){
	goto T960;}
	V245= (*(LnkLI106))();
	(void)(structure_set((V227),VV[6],2,/* INLINE-ARGS */V245));
T960:;
	{register object V246;
	object V247;
	V246= (V228);
	V247= car((V246));
T967:;
	if(!(endp((V246)))){
	goto T968;}
	goto T963;
T968:;
	V248= cadr((V247));
	V249= (*(LnkLI106))();
	(void)(structure_set(/* INLINE-ARGS */V248,VV[6],2,/* INLINE-ARGS */V249));
	V246= cdr((V246));
	V247= car((V246));
	goto T967;}
T963:;
	{register object V250;
	object V251;
	V250= (V228);
	V251= car((V250));
T982:;
	if(!(endp((V250)))){
	goto T983;}
	goto T978;
T983:;
	V252= cadddr((V251));
	V253= (*(LnkLI106))();
	(void)(structure_set(/* INLINE-ARGS */V252,VV[6],2,/* INLINE-ARGS */V253));
	V250= cdr((V250));
	V251= car((V250));
	goto T982;}
T978:;
	{register object V254;
	object V255;
	V254= (V226);
	V255= car((V254));
T997:;
	if(!(endp((V254)))){
	goto T998;}
	goto T993;
T998:;
	if((caddr((V255)))==Cnil){
	goto T1002;}
	V256= caddr((V255));
	V257= (*(LnkLI106))();
	(void)(structure_set(/* INLINE-ARGS */V256,VV[6],2,/* INLINE-ARGS */V257));
T1002:;
	V254= cdr((V254));
	V255= car((V254));
	goto T997;}
T993:;
	princ_str("\n	parse_key(vs_base",VV[10]);
	if(((V225))!=Cnil){
	goto T1013;}
	if(((V226))==Cnil){
	goto T1012;}
T1013:;
	princ_char(43,VV[10]);
	V258 = make_fixnum(length((V225)));
	V259 = make_fixnum(length((V226)));
	V260= number_plus(V258,V259);
	(void)((*(LnkLI80))(/* INLINE-ARGS */V260));
T1012:;
	if(((V227))==Cnil){
	goto T1021;}
	princ_str(",TRUE,",VV[10]);
	goto T1019;
T1021:;
	princ_str(",FALSE,",VV[10]);
T1019:;
	if(((V229))==Cnil){
	goto T1027;}
	princ_str("TRUE,",VV[10]);
	goto T1025;
T1027:;
	princ_str("FALSE,",VV[10]);
T1025:;
	V261 = make_fixnum(length((V228)));
	(void)((*(LnkLI80))(V261));
	{register object V262;
	object V263;
	V262= (V228);
	V263= car((V262));
T1037:;
	if(!(endp((V262)))){
	goto T1038;}
	goto T1033;
T1038:;
	princ_str(",VV[",VV[10]);
	V264= (*(LnkLI112))(car((V263)));
	(void)((*(LnkLI80))(/* INLINE-ARGS */V264));
	princ_char(93,VV[10]);
	V262= cdr((V262));
	V263= car((V262));
	goto T1037;}
T1033:;
	princ_str(");",VV[10]);
	{register object V265;
	object V266;
	V265= (V225);
	V266= car((V265));
T1057:;
	if(!(endp((V265)))){
	goto T1058;}
	goto T1053;
T1058:;
	(void)((*(LnkLI107))((V266)));
	V265= cdr((V265));
	V266= car((V265));
	goto T1057;}
T1053:;
	if(((V226))==Cnil){
	goto T1068;}
	if(((V225))==Cnil){
	goto T1071;}
	princ_str("\n	vs_base += ",VV[10]);
	V267 = make_fixnum(length((V225)));
	(void)((*(LnkLI80))(V267));
	princ_char(59,VV[10]);
T1071:;
	bds_bind(VV[25],(VV[25]->s.s_dbind));
	bds_bind(VV[52],(VV[52]->s.s_dbind));
	bds_bind(VV[26],(VV[26]->s.s_dbind));
	{register object V268;
	V268= (V226);
T1079:;
	if(!(endp((V268)))){
	goto T1080;}
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	goto T1077;
T1080:;
	setq(VV[57],number_plus(symbol_value(VV[57]),small_fixnum(1)));
	V269= make_cons(symbol_value(VV[57]),Cnil);
	V230= make_cons(/* INLINE-ARGS */V269,(V230));
	princ_str("\n	if(vs_base>=vs_top){vs_top=sup;",VV[10]);
	if(type_of(car((V230)))!=t_cons)FEwrong_type_argument(Scons,car((V230)));
	(car((V230)))->c.c_cdr = Ct;
	(void)(car((V230)));
	princ_str("goto T",VV[10]);
	(void)((*(LnkLI80))(car(car((V230)))));
	princ_char(59,VV[10]);
	princ_char(125,VV[10]);
	(void)((*(LnkLI107))(caar((V268))));
	if((caddar((V268)))==Cnil){
	goto T1097;}
	(void)((*(LnkLI109))(caddar((V268)),Ct));
T1097:;
	if((cdr((V268)))==Cnil){
	goto T1100;}
	princ_str("\n	vs_base++;",VV[10]);
T1100:;
	V268= cdr((V268));
	goto T1079;}
T1077:;
	V230= reverse((V230));
T1068:;
	princ_str("\n	vs_top=sup;",VV[10]);
	if(((V226))==Cnil){
	goto T1110;}
	{object V270;
	setq(VV[57],number_plus(symbol_value(VV[57]),small_fixnum(1)));
	V270= make_cons(symbol_value(VV[57]),Cnil);
	if(type_of((V270))!=t_cons)FEwrong_type_argument(Scons,(V270));
	((V270))->c.c_cdr = Ct;
	princ_str("goto T",VV[10]);
	(void)((*(LnkLI80))(car((V270))));
	princ_char(59,VV[10]);
	{register object V271;
	register object V272;
	V271= (V226);
	V272= car((V271));
T1124:;
	if(!(endp((V271)))){
	goto T1125;}
	goto T1120;
T1125:;
	if((cdr(car((V230))))==Cnil){
	goto T1129;}
	princ_str("\nT",VV[10]);
	(void)((*(LnkLI80))(car(car((V230)))));
	princ_str(":;",VV[10]);
T1129:;
	{object V273;
	V273= car((V230));
	V230= cdr((V230));}
	(void)((*(LnkLI110))(car((V272)),cadr((V272))));
	if((caddr((V272)))==Cnil){
	goto T1140;}
	(void)((*(LnkLI109))(caddr((V272)),Cnil));
T1140:;
	V271= cdr((V271));
	V272= car((V271));
	goto T1124;}
T1120:;
	if((cdr((V270)))==Cnil){
	goto T1110;}
	princ_str("\nT",VV[10]);
	(void)((*(LnkLI80))(car((V270))));
	princ_str(":;",VV[10]);}
T1110:;
	if(((V227))==Cnil){
	goto T1153;}
	(void)((*(LnkLI107))((V227)));
T1153:;
	{register object V274;
	register object V275;
	V274= (V228);
	V275= car((V274));
T1160:;
	if(!(endp((V274)))){
	goto T1161;}
	goto T1156;
T1161:;
	if(!((caaddr((V275)))==(VV[61]))){
	goto T1167;}
	if((caddr(caddr((V275))))!=Cnil){
	goto T1167;}
	(void)((*(LnkLI107))(cadr((V275))));
	goto T1165;
T1167:;
	princ_str("\n	if(",VV[10]);
	V276= structure_ref(cadddr((V275)),VV[6],2);
	(void)((*(LnkLI113))(/* INLINE-ARGS */V276));
	princ_str("==Cnil){",VV[10]);
	bds_bind(VV[25],(VV[25]->s.s_dbind));
	bds_bind(VV[52],(VV[52]->s.s_dbind));
	bds_bind(VV[26],(VV[26]->s.s_dbind));
	V277= (*(LnkLI110))(cadr((V275)),caddr((V275)));
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	princ_str("\n	}else{",VV[10]);
	(void)((*(LnkLI107))(cadr((V275))));
	princ_char(125,VV[10]);
T1165:;
	V278= structure_ref(cadddr((V275)),VV[6],1);
	if((/* INLINE-ARGS */V278)==(VV[40])){
	goto T1181;}
	(void)((*(LnkLI107))(cadddr((V275))));
T1181:;
	V274= cdr((V274));
	V275= car((V274));
	goto T1160;}
T1156:;
	base[10]= (V224);
	vs_top=(vs_base=base+10)+1;
	(void) (*Lnk111)();
	vs_top=sup;
	if((base[9])==Cnil){
	goto T1192;}
	princ_str("\n	}",VV[10]);
	{object V279 = Cnil;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	VMR14(V279)}
T1192:;
	{object V280 = Cnil;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	VMR14(V280)}}
}
/*	local entry for function NEED-TO-SET-VS-POINTERS	*/

static object LI17(V282)

object V282;
{	 VMB15 VMS15 VMV15
TTL:;
	if(symbol_value(VV[55])!=Cnil){
	{object V283 = symbol_value(VV[55]);
	VMR15(V283)}}
	if(symbol_value(VV[56])!=Cnil){
	{object V284 = symbol_value(VV[56]);
	VMR15(V284)}}{object V285;
	V285= cadr((V282));
	if(V285==Cnil)goto T1195;
	{object V286 = V285;
	VMR15(V286)}
T1195:;}{object V287;
	V287= caddr((V282));
	if(V287==Cnil)goto T1197;
	{object V288 = V287;
	VMR15(V288)}
T1197:;}
	{object V289 = cadddr((V282));
	VMR15(V289)}
}
/*	local entry for function C1DM	*/

static object LI18(V293,V294,V295)

object V293;register object V294;register object V295;
{	 VMB16 VMS16 VMV16
	bds_check;
TTL:;
	{object V296;
	object V297;
	object V298;
	object V299;
	register object V300;
	register object V301;
	register object V302;
	object V303;
	object V304;
	bds_bind(VV[53],symbol_value(VV[53]));
	V296= Cnil;
	V297= Cnil;
	V298= symbol_value(VV[31]);
	bds_bind(VV[62],Cnil);
	bds_bind(VV[63],(VFUN_NARGS=0,(*(LnkLI86))()));
	bds_bind(VV[64],Cnil);
	V299= Cnil;
	V300= Cnil;
	V301= Cnil;
	V302= Cnil;
	V303= Cnil;
	V304= Cnil;
	base[4]= (V295);
	base[5]= Ct;
	vs_top=(vs_base=base+4)+2;
	(void) (*Lnk88)();
	if(vs_base<vs_top){
	V295= vs_base[0];
	vs_base++;
	}else{
	V295= Cnil;}
	if(vs_base<vs_top){
	V300= vs_base[0];
	vs_base++;
	}else{
	V300= Cnil;}
	if(vs_base<vs_top){
	V302= vs_base[0];
	vs_base++;
	}else{
	V302= Cnil;}
	if(vs_base<vs_top){
	V301= vs_base[0];
	vs_base++;
	}else{
	V301= Cnil;}
	if(vs_base<vs_top){
	V303= vs_base[0];
	vs_base++;
	}else{
	V303= Cnil;}
	if(vs_base<vs_top){
	V299= vs_base[0];
	}else{
	V299= Cnil;}
	vs_top=sup;
	V305= listA(3,VV[33],(V293),(V295));
	V295= make_cons(/* INLINE-ARGS */V305,Cnil);
	(void)((*(LnkLI89))((V300)));
	if(!(type_of((V294))==t_cons||((V294))==Cnil)){
	goto T1216;}
	if(!((car((V294)))==(VV[65]))){
	goto T1216;}
	(VV[62]->s.s_dbind)= make_cons(cadr((V294)),(VV[62]->s.s_dbind));
	V296= (*(LnkLI90))(cadr((V294)),(V300),(V301),(V302));
	(VV[64]->s.s_dbind)= make_cons((V296),(VV[64]->s.s_dbind));
	setq(VV[30],make_cons((V296),symbol_value(VV[30])));
	V294= cddr((V294));
T1216:;
	{register object V306;
	base[4]= (V294);
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk114)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T1232;}
	V306= Cnil;
	goto T1231;
T1232:;
	{register object V307;
	V307= (V294);
T1236:;
	if(type_of((V307))==t_cons){
	goto T1237;}
	V306= Cnil;
	goto T1231;
T1237:;
	if(!((VV[66])==(car((V307))))){
	goto T1241;}
	V306= (V307);
	goto T1231;
T1241:;
	V307= cdr((V307));
	goto T1236;}
T1231:;
	if(((V306))==Cnil){
	goto T1230;}
	(VV[62]->s.s_dbind)= make_cons(cadr((V306)),(VV[62]->s.s_dbind));
	V297= (*(LnkLI90))(cadr((V306)),(V300),(V301),(V302));
	(VV[64]->s.s_dbind)= make_cons((V297),(VV[64]->s.s_dbind));
	setq(VV[30],make_cons((V297),symbol_value(VV[30])));
	base[4]= (V294);
	base[5]= (V306);
	vs_top=(vs_base=base+4)+2;
	(void) (*Lnk115)();
	vs_top=sup;
	V308= vs_base[0];
	V294= append(V308,cddr((V306)));}
T1230:;
	base[4]= (V294);
	base[5]= (V300);
	base[6]= (V301);
	base[7]= (V302);
	vs_top=(vs_base=base+4)+4;
	(void) (*Lnk116)();
	if(vs_base<vs_top){
	V294= vs_base[0];
	vs_base++;
	}else{
	V294= Cnil;}
	if(vs_base<vs_top){
	V304= vs_base[0];
	}else{
	V304= Cnil;}
	vs_top=sup;
	(void)((*(LnkLI97))((VV[62]->s.s_dbind),(V302),(V301)));
	V295= (*(LnkLI98))((V303),(V295));{object V309;
	V309= (VV[63]->s.s_dbind);
	(void)((*(LnkLI96))(V309,cadr((V295))));}
	{object V310;
	base[4]= (V298);
	base[5]= symbol_value(VV[31]);
	vs_top=(vs_base=base+4)+2;
	(void) (*Lnk100)();
	vs_top=sup;
	V310= vs_base[0];
	if(((V310))==Cnil){
	goto T1276;}
	goto T1271;
T1276:;
	(void)(structure_set((VV[63]->s.s_dbind),VV[5],4,Ct));
	(void)(sputprop((V293),VV[67],Ct));}
T1271:;
	{register object V311;
	register object V312;
	V311= (VV[64]->s.s_dbind);
	V312= car((V311));
T1283:;
	if(!(endp((V311)))){
	goto T1284;}
	goto T1279;
T1284:;
	(void)((*(LnkLI99))((V312)));
	V311= cdr((V311));
	V312= car((V311));
	goto T1283;}
T1279:;
	{object V313 = list(7,(V299),(V304),(V296),(V297),(V294),(V295),(VV[63]->s.s_dbind));
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	VMR16(V313)}}
}
/*	function definition for C1DM-VL	*/

static L19()
{register object *base=vs_base;
	register object *sup=base+VM17; VC17
	vs_reserve(VM17);
	{register object V314;
	register object V315;
	register object V316;
	register object V317;
	check_arg(4);
	V314=(base[0]);
	V315=(base[1]);
	V316=(base[2]);
	V317=(base[3]);
	vs_top=sup;
TTL:;
	{register object V318;
	object V319;
	object V320;
	object V321;
	object V322;
	object V323;
	object V324;
	object V325;
	object V326;
	object V327;
	object V328;
	object V329;
	object V330;
	object V331;
	V318= Cnil;
	V319= Cnil;
	V320= Cnil;
	V321= Cnil;
	V322= Cnil;
	V323= Cnil;
	V324= Cnil;
	V325= Cnil;
	V326= Cnil;
	V327= Cnil;
	V328= Cnil;
	V329= Cnil;
	V330= small_fixnum(0);
	V331= Cnil;
T1295:;
	if(type_of((V314))==t_cons){
	goto T1296;}
	if(((V314))==Cnil){
	goto T1299;}
	if(((V319))==Cnil){
	goto T1302;}
	base[4]= VV[68];
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk117)();
	vs_top=sup;
T1302:;
	base[4]= (V314);
	base[5]= (V315);
	base[6]= (V316);
	base[7]= (V317);
	vs_top=(vs_base=base+4)+4;
	(void) (*Lnk118)();
	vs_top=sup;
	V325= vs_base[0];
T1299:;
	V332= reverse((V323));
	V333= reverse((V324));
	V334= reverse((V327));
	base[4]= list(7,/* INLINE-ARGS */V332,/* INLINE-ARGS */V333,(V325),(V326),/* INLINE-ARGS */V334,(V329),reverse((V328)));
	base[5]= (V331);
	vs_top=(vs_base=base+4)+2;
	return;
T1296:;
	{register object V335;
	V335= car((V314));
	if(!(((V335))==(VV[69]))){
	goto T1317;}
	if(((V318))==Cnil){
	goto T1319;}
	base[4]= VV[69];
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk117)();
	vs_top=sup;
T1319:;
	V318= Ct;
	{object V336;
	V336= car((V314));
	V314= cdr((V314));
	goto T1314;}
T1317:;
	if(((V335))==(VV[68])){
	goto T1328;}
	if(!(((V335))==(VV[70]))){
	goto T1329;}
T1328:;
	if(((V319))==Cnil){
	goto T1333;}
	base[4]= (V335);
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk117)();
	vs_top=sup;
T1333:;
	base[4]= cadr((V314));
	base[5]= (V315);
	base[6]= (V316);
	base[7]= (V317);
	vs_top=(vs_base=base+4)+4;
	(void) (*Lnk118)();
	vs_top=sup;
	V325= vs_base[0];
	V319= Ct;
	V318= Ct;
	V314= cddr((V314));
	if(!(((V335))==(VV[70]))){
	goto T1314;}
	V331= (V330);
	goto T1314;
T1329:;
	if(!(((V335))==(VV[71]))){
	goto T1353;}
	if(((V320))==Cnil){
	goto T1355;}
	base[4]= VV[71];
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk117)();
	vs_top=sup;
T1355:;
	V320= Ct;
	V319= Ct;
	V318= Ct;
	V326= Ct;
	{object V337;
	V337= car((V314));
	V314= cdr((V314));
	goto T1314;}
T1353:;
	if(!(((V335))==(VV[72]))){
	goto T1371;}
	if(((V320))==Cnil){
	goto T1374;}
	if(((V321))==Cnil){
	goto T1373;}
T1374:;
	base[4]= VV[72];
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk117)();
	vs_top=sup;
T1373:;
	V321= Ct;
	V329= Ct;
	{object V338;
	V338= car((V314));
	V314= cdr((V314));
	goto T1314;}
T1371:;
	if(!(((V335))==(VV[73]))){
	goto T1387;}
	if(((V322))==Cnil){
	goto T1389;}
	base[4]= VV[73];
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk117)();
	vs_top=sup;
T1389:;
	V322= Ct;
	V321= Ct;
	V320= Ct;
	V319= Ct;
	V318= Ct;
	{object V339;
	V339= car((V314));
	V314= cdr((V314));
	goto T1314;}
T1387:;
	if(((V322))==Cnil){
	goto T1407;}
	{object V340;
	object V341;
	V340= Cnil;
	V341= Cnil;
	if(!(type_of((V335))==t_symbol)){
	goto T1412;}
	V340= (V335);
	V341= (*(LnkLI119))();
	goto T1410;
T1412:;
	V340= car((V335));
	if(!(endp(cdr((V335))))){
	goto T1420;}
	V341= (*(LnkLI119))();
	goto T1410;
T1420:;
	V341= (*(LnkLI92))(cadr((V335)),symbol_value(VV[63]));
T1410:;
	base[4]= (V340);
	base[5]= (V315);
	base[6]= (V316);
	base[7]= (V317);
	vs_top=(vs_base=base+4)+4;
	(void) (*Lnk118)();
	vs_top=sup;
	V342= vs_base[0];
	V343= list(2,V342,(V341));
	V328= make_cons(/* INLINE-ARGS */V343,(V328));}
	{object V344;
	V344= car((V314));
	V314= cdr((V314));
	goto T1314;}
T1407:;
	if(((V320))==Cnil){
	goto T1434;}
	{object V345;
	object V346;
	object V347;
	object V348;
	V345= Cnil;
	V346= Cnil;
	V347= Cnil;
	V348= Cnil;
	if(!(type_of((V335))==t_symbol)){
	goto T1439;}
	V345= (V335);
	base[4]= coerce_to_string((V335));
	base[5]= VV[38];
	vs_top=(vs_base=base+4)+2;
	(void) (*Lnk94)();
	vs_top=sup;
	V346= vs_base[0];
	V347= (*(LnkLI119))();
	goto T1437;
T1439:;
	if(!(type_of(car((V335)))==t_symbol)){
	goto T1450;}
	V345= car((V335));
	base[4]= coerce_to_string(car((V335)));
	base[5]= VV[38];
	vs_top=(vs_base=base+4)+2;
	(void) (*Lnk94)();
	vs_top=sup;
	V346= vs_base[0];
	goto T1448;
T1450:;
	V345= cadar((V335));
	V346= caar((V335));
T1448:;
	if(!(endp(cdr((V335))))){
	goto T1461;}
	V347= (*(LnkLI119))();
	goto T1437;
T1461:;
	V347= (*(LnkLI92))(cadr((V335)),symbol_value(VV[63]));
	if(endp(cddr((V335)))){
	goto T1437;}
	V348= caddr((V335));
T1437:;
	base[4]= (V345);
	base[5]= (V315);
	base[6]= (V316);
	base[7]= (V317);
	vs_top=(vs_base=base+4)+4;
	(void) (*Lnk118)();
	vs_top=sup;
	V349= vs_base[0];
	if(((V348))==Cnil){
	goto T1477;}
	base[4]= (V348);
	base[5]= (V315);
	base[6]= (V316);
	base[7]= (V317);
	vs_top=(vs_base=base+4)+4;
	(void) (*Lnk118)();
	vs_top=sup;
	V350= vs_base[0];
	goto T1475;
T1477:;
	V350= Cnil;
T1475:;
	V351= list(4,(V346),V349,(V347),V350);
	V327= make_cons(/* INLINE-ARGS */V351,(V327));}
	{object V352;
	V352= car((V314));
	V314= cdr((V314));
	goto T1314;}
T1434:;
	if(((V318))==Cnil){
	goto T1487;}
	{object V353;
	object V354;
	object V355;
	V353= Cnil;
	V354= Cnil;
	V355= Cnil;
	if(!(type_of((V335))==t_symbol)){
	goto T1492;}
	V353= (V335);
	V354= (*(LnkLI119))();
	goto T1490;
T1492:;
	V353= car((V335));
	if(!(endp(cdr((V335))))){
	goto T1500;}
	V354= (*(LnkLI119))();
	goto T1490;
T1500:;
	V354= (*(LnkLI92))(cadr((V335)),symbol_value(VV[63]));
	if(endp(cddr((V335)))){
	goto T1490;}
	V355= caddr((V335));
T1490:;
	base[4]= (V353);
	base[5]= (V315);
	base[6]= (V316);
	base[7]= (V317);
	vs_top=(vs_base=base+4)+4;
	(void) (*Lnk118)();
	vs_top=sup;
	V356= vs_base[0];
	if(((V355))==Cnil){
	goto T1516;}
	base[4]= (V355);
	base[5]= (V315);
	base[6]= (V316);
	base[7]= (V317);
	vs_top=(vs_base=base+4)+4;
	(void) (*Lnk118)();
	vs_top=sup;
	V357= vs_base[0];
	goto T1514;
T1516:;
	V357= Cnil;
T1514:;
	V358= list(3,V356,(V354),V357);
	V324= make_cons(/* INLINE-ARGS */V358,(V324));}
	{object V359;
	V359= car((V314));
	V314= cdr((V314));}
	V330= number_plus((V330),small_fixnum(1));
	goto T1314;
T1487:;
	base[4]= (V335);
	base[5]= (V315);
	base[6]= (V316);
	base[7]= (V317);
	vs_top=(vs_base=base+4)+4;
	(void) (*Lnk118)();
	vs_top=sup;
	V360= vs_base[0];
	V323= make_cons(V360,(V323));
	{object V361;
	V361= car((V314));
	V314= cdr((V314));}
	V330= number_plus((V330),small_fixnum(1));}
T1314:;
	goto T1295;}
	}
}
/*	function definition for C1DM-V	*/

static L20()
{register object *base=vs_base;
	register object *sup=base+VM18; VC18
	vs_reserve(VM18);
	{register object V362;
	object V363;
	object V364;
	object V365;
	check_arg(4);
	V362=(base[0]);
	V363=(base[1]);
	V364=(base[2]);
	V365=(base[3]);
	vs_top=sup;
TTL:;
	if(!(type_of((V362))==t_symbol)){
	goto T1542;}
	setq(VV[62],make_cons((V362),symbol_value(VV[62])));
	V362= (*(LnkLI90))((V362),(V363),(V364),(V365));
	setq(VV[30],make_cons((V362),symbol_value(VV[30])));
	setq(VV[64],make_cons((V362),symbol_value(VV[64])));
	base[4]= (V362);
	vs_top=(vs_base=base+4)+1;
	return;
T1542:;
	base[4]= (V362);
	base[5]= (V363);
	base[6]= (V364);
	base[7]= (V365);
	vs_top=(vs_base=base+4)+4;
	(void) (*Lnk116)();
	return;
	}
}
/*	local entry for function C1DM-BAD-KEY	*/

static object LI21(V367)

object V367;
{	 VMB19 VMS19 VMV19
TTL:;
	{object V368 = (VFUN_NARGS=2,(*(LnkLI87))(VV[74],(V367)));
	VMR19(V368)}
}
/*	function definition for C2DM	*/

static L22()
{register object *base=vs_base;
	register object *sup=base+VM20; VC20
	vs_reserve(VM20);
	{register object V369;
	register object V370;
	object V371;
	object V372;
	check_arg(4);
	V369=(base[0]);
	V370=(base[1]);
	V371=(base[2]);
	V372=(base[3]);
	vs_top=sup;
TTL:;
	{object V373;
	setq(VV[54],number_plus(symbol_value(VV[54]),small_fixnum(1)));
	V373= symbol_value(VV[54]);
	if((symbol_value(VV[55]))!=Cnil){
	goto T1559;}
	if((symbol_value(VV[56]))==Cnil){
	goto T1558;}
T1559:;
	princ_str("\n	check_arg(2);",VV[10]);
T1558:;
	if(((V369))==Cnil){
	goto T1566;}
	V374= (*(LnkLI106))();
	(void)(structure_set((V369),VV[6],2,/* INLINE-ARGS */V374));
	goto T1564;
T1566:;
	(void)((*(LnkLI106))());
T1564:;
	if(((V370))==Cnil){
	goto T1570;}
	V375= (*(LnkLI106))();
	(void)(structure_set((V370),VV[6],2,/* INLINE-ARGS */V375));
	goto T1568;
T1570:;
	(void)((*(LnkLI106))());
T1568:;
	(void)((*(LnkLI120))((V371)));
	princ_str("\n	vs_top=sup;",VV[10]);
	if(((V369))==Cnil){
	goto T1575;}
	(void)((*(LnkLI107))((V369)));
T1575:;
	if(((V370))==Cnil){
	goto T1578;}
	(void)((*(LnkLI107))((V370)));
T1578:;
	princ_str("\n	{object V",VV[10]);
	(void)((*(LnkLI80))((V373)));
	princ_str("=base[0]->c.c_cdr;",VV[10]);
	(void)((*(LnkLI121))((V371),(V373)));
	princ_char(125,VV[10]);
	base[5]= (V372);
	vs_top=(vs_base=base+5)+1;
	(void) (*Lnk111)();
	return;}
	}
}
/*	local entry for function C2DM-RESERVE-VL	*/

static object LI23(V377)

object V377;
{	 VMB21 VMS21 VMV21
TTL:;
	{register object V378;
	object V379;
	V378= car((V377));
	V379= car((V378));
T1593:;
	if(!(endp((V378)))){
	goto T1594;}
	goto T1589;
T1594:;
	(void)((*(LnkLI122))((V379)));
	V378= cdr((V378));
	V379= car((V378));
	goto T1593;}
T1589:;
	{register object V380;
	register object V381;
	V380= cadr((V377));
	V381= car((V380));
T1608:;
	if(!(endp((V380)))){
	goto T1609;}
	goto T1604;
T1609:;
	(void)((*(LnkLI122))(car((V381))));
	if((caddr((V381)))==Cnil){
	goto T1614;}
	(void)((*(LnkLI122))(caddr((V381))));
T1614:;
	V380= cdr((V380));
	V381= car((V380));
	goto T1608;}
T1604:;
	if((caddr((V377)))==Cnil){
	goto T1622;}
	(void)((*(LnkLI122))(caddr((V377))));
T1622:;
	{register object V382;
	register object V383;
	V382= car(cddddr((V377)));
	V383= car((V382));
T1629:;
	if(!(endp((V382)))){
	goto T1630;}
	goto T1625;
T1630:;
	(void)((*(LnkLI122))(cadr((V383))));
	if((cadddr((V383)))==Cnil){
	goto T1635;}
	(void)((*(LnkLI122))(cadddr((V383))));
T1635:;
	V382= cdr((V382));
	V383= car((V382));
	goto T1629;}
T1625:;
	{register object V384;
	object V385;
	V384= caddr(cddddr((V377)));
	V385= car((V384));
T1646:;
	if(!(endp((V384)))){
	goto T1647;}
	{object V386 = Cnil;
	VMR21(V386)}
T1647:;
	(void)((*(LnkLI122))(car((V385))));
	V384= cdr((V384));
	V385= car((V384));
	goto T1646;}
}
/*	local entry for function C2DM-RESERVE-V	*/

static object LI24(V388)

object V388;
{	 VMB22 VMS22 VMV22
TTL:;
	if(!(type_of((V388))==t_cons)){
	goto T1658;}
	{object V389 = (*(LnkLI120))((V388));
	VMR22(V389)}
T1658:;
	V390= (*(LnkLI106))();
	{object V391 = structure_set((V388),VV[6],2,/* INLINE-ARGS */V390);
	VMR22(V391)}
}
/*	local entry for function C2DM-BIND-VL	*/

static object LI25(V394,V395)

object V394;register object V395;
{	 VMB23 VMS23 VMV23
	bds_check;
TTL:;
	{object V396;
	object V397;
	object V398;
	object V399;
	object V400;
	object V401;
	object V402;
	V396= car((V394));
	V397= cadr((V394));
	V398= caddr((V394));
	V399= cadddr((V394));
	V400= car(cddddr((V394)));
	V401= cadr(cddddr((V394)));
	V402= caddr(cddddr((V394)));
	{register object V403;
	V403= (V396);
T1669:;
	if(!(endp((V403)))){
	goto T1670;}
	goto T1667;
T1670:;
	if((symbol_value(VV[55]))!=Cnil){
	goto T1675;}
	if((symbol_value(VV[56]))==Cnil){
	goto T1674;}
T1675:;
	princ_str("\n	if(endp(V",VV[10]);
	(void)((*(LnkLI80))((V395)));
	princ_str("))invalid_macro_call();",VV[10]);
T1674:;
	V404= car((V403));
	V405= list(2,VV[75],(V395));
	(void)((*(LnkLI123))(/* INLINE-ARGS */V404,/* INLINE-ARGS */V405));
	if((cdr((V403)))!=Cnil){
	goto T1684;}
	if(((V397))!=Cnil){
	goto T1684;}
	if(((V398))!=Cnil){
	goto T1684;}
	if(((V399))!=Cnil){
	goto T1684;}
	if((symbol_value(VV[55]))!=Cnil){
	goto T1684;}
	if((symbol_value(VV[56]))==Cnil){
	goto T1683;}
T1684:;
	princ_str("\n	V",VV[10]);
	(void)((*(LnkLI80))((V395)));
	princ_str("=V",VV[10]);
	(void)((*(LnkLI80))((V395)));
	princ_str("->c.c_cdr;",VV[10]);
T1683:;
	V403= cdr((V403));
	goto T1669;}
T1667:;
	{register object V406;
	V406= (V397);
T1706:;
	if(!(endp((V406)))){
	goto T1707;}
	goto T1704;
T1707:;
	{register object V407;
	V407= car((V406));
	princ_str("\n	if(endp(V",VV[10]);
	(void)((*(LnkLI80))((V395)));
	princ_str(")){",VV[10]);
	bds_bind(VV[25],symbol_value(VV[25]));
	bds_bind(VV[52],symbol_value(VV[52]));
	bds_bind(VV[26],symbol_value(VV[26]));
	(void)((*(LnkLI124))(car((V407)),cadr((V407))));
	if((caddr((V407)))==Cnil){
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	goto T1717;}
	V408= (*(LnkLI123))(caddr((V407)),Cnil);
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
T1717:;
	princ_str("\n	} else {",VV[10]);
	V409= car((V407));
	V410= list(2,VV[75],(V395));
	(void)((*(LnkLI123))(/* INLINE-ARGS */V409,/* INLINE-ARGS */V410));
	if((caddr((V407)))==Cnil){
	goto T1711;}
	(void)((*(LnkLI123))(caddr((V407)),Ct));}
T1711:;
	if((cdr((V406)))!=Cnil){
	goto T1727;}
	if(((V398))!=Cnil){
	goto T1727;}
	if(((V399))!=Cnil){
	goto T1727;}
	if((symbol_value(VV[55]))!=Cnil){
	goto T1727;}
	if((symbol_value(VV[56]))==Cnil){
	goto T1726;}
T1727:;
	princ_str("\n	V",VV[10]);
	(void)((*(LnkLI80))((V395)));
	princ_str("=V",VV[10]);
	(void)((*(LnkLI80))((V395)));
	princ_str("->c.c_cdr;",VV[10]);
T1726:;
	princ_char(125,VV[10]);
	V406= cdr((V406));
	goto T1706;}
T1704:;
	if(((V398))==Cnil){
	goto T1747;}
	V411= list(2,VV[76],(V395));
	(void)((*(LnkLI123))((V398),/* INLINE-ARGS */V411));
T1747:;
	{object V412;
	register object V413;
	V412= (V400);
	V413= car((V412));
T1754:;
	if(!(endp((V412)))){
	goto T1755;}
	goto T1750;
T1755:;
	{object V414;
	setq(VV[54],number_plus(symbol_value(VV[54]),small_fixnum(1)));
	V414= symbol_value(VV[54]);
	princ_str("\n	{object V",VV[10]);
	(void)((*(LnkLI80))((V414)));
	princ_str("=getf(V",VV[10]);
	(void)((*(LnkLI80))((V395)));
	princ_str(",VV[",VV[10]);
	V415= (*(LnkLI112))(car((V413)));
	(void)((*(LnkLI80))(/* INLINE-ARGS */V415));
	princ_str("],OBJNULL);",VV[10]);
	princ_str("\n	if(V",VV[10]);
	(void)((*(LnkLI80))((V414)));
	princ_str("==OBJNULL){",VV[10]);
	bds_bind(VV[25],symbol_value(VV[25]));
	bds_bind(VV[52],symbol_value(VV[52]));
	bds_bind(VV[26],symbol_value(VV[26]));
	(void)((*(LnkLI124))(cadr((V413)),caddr((V413))));
	if((cadddr((V413)))==Cnil){
	goto T1776;}
	(void)((*(LnkLI123))(cadddr((V413)),Cnil));
T1776:;
	princ_str("\n	} else {",VV[10]);
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	V416= cadr((V413));
	V417= list(2,VV[76],(V414));
	(void)((*(LnkLI123))(/* INLINE-ARGS */V416,/* INLINE-ARGS */V417));
	if((cadddr((V413)))==Cnil){
	goto T1781;}
	(void)((*(LnkLI123))(cadddr((V413)),Ct));
T1781:;
	princ_str("}}",VV[10]);}
	V412= cdr((V412));
	V413= car((V412));
	goto T1754;}
T1750:;
	if((symbol_value(VV[55]))!=Cnil){
	goto T1792;}
	if((symbol_value(VV[56]))==Cnil){
	goto T1790;}
T1792:;
	if(((V398))!=Cnil){
	goto T1790;}
	if(((V399))!=Cnil){
	goto T1790;}
	princ_str("\n	if(!endp(V",VV[10]);
	(void)((*(LnkLI80))((V395)));
	princ_str("))invalid_macro_call();",VV[10]);
T1790:;
	if((symbol_value(VV[55]))!=Cnil){
	goto T1804;}
	if((symbol_value(VV[56]))==Cnil){
	goto T1802;}
T1804:;
	if(((V399))==Cnil){
	goto T1802;}
	if(((V401))!=Cnil){
	goto T1802;}
	princ_str("\n	check_other_key(V",VV[10]);
	(void)((*(LnkLI80))((V395)));
	princ_char(44,VV[10]);
	V418 = make_fixnum(length((V400)));
	(void)((*(LnkLI80))(V418));
	{object V419;
	object V420;
	V419= (V400);
	V420= car((V419));
T1820:;
	if(!(endp((V419)))){
	goto T1821;}
	goto T1816;
T1821:;
	princ_str(",VV[",VV[10]);
	V421= (*(LnkLI112))(car((V420)));
	(void)((*(LnkLI80))(/* INLINE-ARGS */V421));
	princ_char(93,VV[10]);
	V419= cdr((V419));
	V420= car((V419));
	goto T1820;}
T1816:;
	princ_str(");",VV[10]);
T1802:;
	{object V422;
	object V423;
	V422= (V402);
	V423= car((V422));
T1838:;
	if(!(endp((V422)))){
	goto T1839;}
	{object V424 = Cnil;
	VMR23(V424)}
T1839:;
	(void)((*(LnkLI124))(car((V423)),cadr((V423))));
	V422= cdr((V422));
	V423= car((V422));
	goto T1838;}}
}
/*	local entry for function C2DM-BIND-LOC	*/

static object LI26(V427,V428)

object V427;object V428;
{	 VMB24 VMS24 VMV24
TTL:;
	if(!(type_of((V427))==t_cons)){
	goto T1850;}
	{object V429;
	setq(VV[54],number_plus(symbol_value(VV[54]),small_fixnum(1)));
	V429= symbol_value(VV[54]);
	princ_str("\n	{object V",VV[10]);
	(void)((*(LnkLI80))((V429)));
	princ_str("= ",VV[10]);
	(void)((*(LnkLI80))((V428)));
	princ_char(59,VV[10]);
	(void)((*(LnkLI121))((V427),(V429)));
	princ_char(125,VV[10]);
	{object V430 = Cnil;
	VMR24(V430)}}
T1850:;
	{object V431 = (*(LnkLI109))((V427),(V428));
	VMR24(V431)}
}
/*	local entry for function C2DM-BIND-INIT	*/

static object LI27(V434,V435)

object V434;object V435;
{	 VMB25 VMS25 VMV25
	bds_check;
TTL:;
	if(!(type_of((V434))==t_cons)){
	goto T1863;}
	{object V436;
	object V437;
	bds_bind(VV[53],symbol_value(VV[53]));
	bds_bind(VV[77],small_fixnum(0));
	setq(VV[54],number_plus(symbol_value(VV[54]),small_fixnum(1)));
	V436= symbol_value(VV[54]);
	V438= make_cons((V435),Cnil);
	V439= (VFUN_NARGS=2,(*(LnkLI125))(/* INLINE-ARGS */V438,VV[78]));
	V437= car(/* INLINE-ARGS */V439);
	princ_str("\n	{object V",VV[10]);
	(void)((*(LnkLI80))((V436)));
	princ_str("= ",VV[10]);
	(void)((*(LnkLI80))((V437)));
	princ_char(59,VV[10]);
	(void)((*(LnkLI121))((V434),(V436)));
	princ_char(125,VV[10]);
	{object V440 = (*(LnkLI126))();
	bds_unwind1;
	bds_unwind1;
	VMR25(V440)}}
T1863:;
	{object V441 = (*(LnkLI110))((V434),(V435));
	VMR25(V441)}
}
/*	local function DO-DECL	*/

static L16(base0)
register object *base0;
{	register object *base=vs_base;
	register object *sup=base+VM26; VC26
	vs_reserve(VM26);
	{object V442;
	check_arg(1);
	V442=(base[0]);
	vs_top=sup;
TTL:;
	{object V443;
	V443= (*(LnkLI127))((V442));
	if(((V443))==Cnil){
	goto T1879;}
	{object V444;
	setq(VV[54],number_plus(symbol_value(VV[54]),small_fixnum(1)));
	V444= symbol_value(VV[54]);
	(void)(structure_set((V442),VV[6],1,(V443)));
	(void)(structure_set((V442),VV[6],4,(V444)));
	princ_str("\n	",VV[10]);
	if((base0[9])!=Cnil){
	goto T1886;}
	princ_char(123,VV[10]);
	base0[9]= Ct;
T1886:;
	base[1]= (V442);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk128)();
	return;}
T1879:;
	base[1]= Cnil;
	vs_top=(vs_base=base+1)+1;
	return;}
	}
}
/*	local function DO-DECL	*/

static L14(base0)
register object *base0;
{	register object *base=vs_base;
	register object *sup=base+VM27; VC27
	vs_reserve(VM27);
	{object V445;
	check_arg(1);
	V445=(base[0]);
	vs_top=sup;
TTL:;
	{object V446;
	V446= (*(LnkLI127))((V445));
	if(((V446))==Cnil){
	goto T1895;}
	{object V447;
	setq(VV[54],number_plus(symbol_value(VV[54]),small_fixnum(1)));
	V447= symbol_value(VV[54]);
	(void)(structure_set((V445),VV[6],1,(V446)));
	(void)(structure_set((V445),VV[6],4,(V447)));
	princ_str("\n	",VV[10]);
	if((base0[7])!=Cnil){
	goto T1902;}
	princ_char(123,VV[10]);
	base0[7]= Ct;
T1902:;
	base[1]= (V445);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk128)();
	return;}
T1895:;
	base[1]= Cnil;
	vs_top=(vs_base=base+1)+1;
	return;}
	}
}
static LnkT128(){ call_or_link(VV[128],&Lnk128);} /* WT-VAR-DECL */
static object  LnkTLI127(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[127],&LnkLI127,1,ap);} /* C2VAR-KIND */
static object  LnkTLI126(){return call_proc0(VV[126],&LnkLI126);} /* CLOSE-INLINE-BLOCKS */
static object  LnkTLI125(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[125],&LnkLI125,ap);} /* INLINE-ARGS */
static object  LnkTLI124(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[124],&LnkLI124,2,ap);} /* C2DM-BIND-INIT */
static object  LnkTLI123(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[123],&LnkLI123,2,ap);} /* C2DM-BIND-LOC */
static object  LnkTLI122(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[122],&LnkLI122,1,ap);} /* C2DM-RESERVE-V */
static object  LnkTLI121(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[121],&LnkLI121,2,ap);} /* C2DM-BIND-VL */
static object  LnkTLI120(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[120],&LnkLI120,1,ap);} /* C2DM-RESERVE-VL */
static object  LnkTLI119(){return call_proc0(VV[119],&LnkLI119);} /* C1NIL */
static LnkT118(){ call_or_link(VV[118],&Lnk118);} /* C1DM-V */
static LnkT117(){ call_or_link(VV[117],&Lnk117);} /* DM-BAD-KEY */
static LnkT116(){ call_or_link(VV[116],&Lnk116);} /* C1DM-VL */
static LnkT115(){ call_or_link(VV[115],&Lnk115);} /* LDIFF */
static LnkT114(){ call_or_link(VV[114],&Lnk114);} /* LISTP */
static object  LnkTLI113(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[113],&LnkLI113,1,ap);} /* WT-VS */
static object  LnkTLI112(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[112],&LnkLI112,1,ap);} /* ADD-SYMBOL */
static LnkT111(){ call_or_link(VV[111],&Lnk111);} /* C2EXPR */
static object  LnkTLI110(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[110],&LnkLI110,2,ap);} /* C2BIND-INIT */
static object  LnkTLI109(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[109],&LnkLI109,2,ap);} /* C2BIND-LOC */
static object  LnkTLI108(){return call_proc0(VV[108],&LnkLI108);} /* RESET-TOP */
static object  LnkTLI107(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[107],&LnkLI107,1,ap);} /* C2BIND */
static object  LnkTLI106(){return call_proc0(VV[106],&LnkLI106);} /* VS-PUSH */
static object  LnkTLI105(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[105],&LnkLI105,2,ap);} /* C2LAMBDA-EXPR-WITHOUT-KEY */
static object  LnkTLI104(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[104],&LnkLI104,2,ap);} /* C2LAMBDA-EXPR-WITH-KEY */
static LnkT103(){ call_or_link(VV[103],&Lnk103);} /* CONSTANTP */
static object  LnkTLI102(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[102],&LnkLI102,1,ap);} /* RECORD-ARG-INFO */
static object  LnkTLI101(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[101],&LnkLI101,3,ap);} /* FIX-DOWN-ARGS */
static LnkT100(){ call_or_link(VV[100],&Lnk100);} /* EQL */
static object  LnkTLI99(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[99],&LnkLI99,1,ap);} /* CHECK-VREF */
static object  LnkTLI98(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[98],&LnkLI98,2,ap);} /* C1DECL-BODY */
static object  LnkTLI97(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[97],&LnkLI97,3,ap);} /* CHECK-VDECL */
static object  LnkTLI96(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[96],&LnkLI96,2,ap);} /* ADD-INFO */
static object  LnkTLI95(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[95],&LnkLI95,ap);} /* MAKE-VAR */
static LnkT94(){ call_or_link(VV[94],&Lnk94);} /* INTERN */
static object  LnkTLI93(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[93],&LnkLI93,3,ap);} /* AND-FORM-TYPE */
static object  LnkTLI92(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[92],&LnkLI92,2,ap);} /* C1EXPR* */
static object  LnkTLI91(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[91],&LnkLI91,1,ap);} /* DEFAULT-INIT */
static object  LnkTLI90(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[90],&LnkLI90,4,ap);} /* C1MAKE-VAR */
static object  LnkTLI89(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[89],&LnkLI89,1,ap);} /* C1ADD-GLOBALS */
static LnkT88(){ call_or_link(VV[88],&Lnk88);} /* C1BODY */
static object  LnkTLI87(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[87],&LnkLI87,ap);} /* CMPERR */
static object  LnkTLI86(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[86],&LnkLI86,ap);} /* MAKE-INFO */
static object  LnkTLI85(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[85],&LnkLI85,ap);} /* UNWIND-EXIT */
static object  LnkTLI84(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[84],&LnkLI84,ap);} /* MAKE-FUN */
static object  LnkTLI83(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[83],&LnkLI83,ap);} /* DELETE */
static object  LnkTLI82(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[82],&LnkLI82,1,ap);} /* WT-H1 */
static LnkT81(){ call_or_link(VV[81],&Lnk81);} /* ERROR */
static object  LnkTLI80(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[80],&LnkLI80,1,ap);} /* WT1 */
static object  LnkTLI79(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[79],&LnkLI79,1,ap);} /* C1EXPR */
