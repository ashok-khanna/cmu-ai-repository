
#include <cmpinclude.h>
#include "trace.h"
init_trace(){do_init(VV);}
/*	macro definition for TRACE	*/

static L1()
{register object *base=vs_base;
	register object *sup=base+VM1; VC1
	vs_reserve(VM1);
	check_arg(2);
	vs_top=sup;
	{object V1=base[0]->c.c_cdr;
	base[2]= V1;}
	if((base[2])!=Cnil){
	goto T2;}
	base[3]= VV[0];
	vs_top=(vs_base=base+3)+1;
	return;
T2:;
	base[3]= list(3,VV[1],VV[2],list(3,VV[3],list(3,VV[4],list(3,VV[5],VV[6],list(2,VV[7],base[2])),VV[8]),VV[9]));
	vs_top=(vs_base=base+3)+1;
	return;
}
/*	macro definition for UNTRACE	*/

static L2()
{register object *base=vs_base;
	register object *sup=base+VM2; VC2
	vs_reserve(VM2);
	check_arg(2);
	vs_top=sup;
	{object V2=base[0]->c.c_cdr;
	base[2]= V2;}
	if((base[2])!=Cnil){
	goto T5;}
	base[3]= VV[10];
	vs_top=(vs_base=base+3)+1;
	return;
T5:;
	base[3]= list(3,VV[5],VV[11],list(2,VV[7],base[2]));
	vs_top=(vs_base=base+3)+1;
	return;
}
/*	local entry for function TRACE-ONE-PREPROCESS	*/

static object LI3(V4)

object V4;
{	 VMB3 VMS3 VMV3
TTL:;
	if(!(type_of((V4))==t_symbol)){
	goto T8;}
	V4= make_cons((V4),Cnil);
	goto TTL;
T8:;
	{register object V5;
	register object V6;
	object V7;
	object V8;
	register object V9;
	register object V10;
	register object V11;
	register object V12;
	register object V13;
	V5= cdr((V4));
	V7= list(3,VV[12],list(2,VV[7],car((V4))),VV[13]);
	V8= list(3,VV[12],list(2,VV[7],car((V4))),VV[14]);
	V6= Cnil;
	V9= Ct;
	V10= Ct;
	V11= Ct;
	V12= Cnil;
	V13= Cnil;
T16:;
	if(((V5))!=Cnil){
	goto T17;}
	if(((V12))==Cnil){
	goto T20;}
	vs_base=vs_top;
	(void) (*Lnk98)();
	vs_top=sup;
	V13= vs_base[0];
	if(!(((V9))==(Ct))){
	goto T27;}
	V9= list(3,VV[15],(V13),(V12));
	goto T25;
T27:;
	V9= list(4,VV[16],list(3,VV[15],(V13),(V12)),(V9),Cnil);
T25:;
	V14= make_cons((V13),small_fixnum(0));
	V6= make_cons(/* INLINE-ARGS */V14,(V6));
	V10= list(3,VV[17],list(3,VV[18],(V13),list(2,VV[19],(V13))),(V10));
	V11= list(3,VV[17],list(3,VV[18],(V13),list(2,VV[20],(V13))),(V11));
T20:;
	V15= car((V4));
	V16= list(2,VV[7],(V9));
	V17= list(2,VV[7],(V10));
	V18= list(2,VV[7],(V7));
	V19= list(2,VV[7],(V11));
	{object V20 = list(7,/* INLINE-ARGS */V15,(V6),/* INLINE-ARGS */V16,/* INLINE-ARGS */V17,/* INLINE-ARGS */V18,/* INLINE-ARGS */V19,list(2,VV[7],(V8)));
	VMR3(V20)}
T17:;
	{object V21= car((V5));
	if((V21!= VV[29]))goto T38;
	{register object V22;
	register object V23;
	V22= cadr((V5));
	V23= Cnil;
T42:;
	if(((V22))!=Cnil){
	goto T43;}
	V6= (V23);
	goto T39;
T43:;
	if(!(type_of(car((V22)))==t_symbol)){
	goto T51;}
	V24= make_cons(car((V22)),Cnil);
	goto T49;
T51:;
	V25= caar((V22));
	base[0]= cadar((V22));
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk99)();
	vs_top=sup;
	V26= vs_base[0];
	V24= make_cons(/* INLINE-ARGS */V25,V26);
T49:;
	V23= make_cons(V24,(V23));
	V22= cdr((V22));
	goto T42;}
T39:;
	goto T37;
T38:;
	if((V21!= VV[100]))goto T58;
	V9= cadr((V5));
	goto T37;
T58:;
	if((V21!= VV[101]))goto T60;
	V10= cadr((V5));
	goto T37;
T60:;
	if((V21!= VV[102]))goto T62;
	V7= cadr((V5));
	goto T37;
T62:;
	if((V21!= VV[103]))goto T64;
	V11= cadr((V5));
	goto T37;
T64:;
	if((V21!= VV[104]))goto T66;
	V8= cadr((V5));
	goto T37;
T66:;
	if((V21!= VV[28]))goto T68;
	V12= cadr((V5));
	goto T37;
T68:;}
T37:;
	V5= cddr((V5));
	goto T16;}
}
/*	local entry for function CHECK-TRACE-SPEC	*/

static object LI4(V28)

register object V28;
{	 VMB4 VMS4 VMV4
TTL:;{object V29;
	base[0]= (V28);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk105)();
	vs_top=sup;
	V29= vs_base[0];
	if(V29==Cnil)goto T73;
	{object V30 = V29;
	VMR4(V30)}
T73:;}
	if(!(type_of((V28))==t_cons)){
	goto T77;}
	base[0]= (V28);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk106)();
	vs_top=sup;
	V31= vs_base[0];
	if((cdr(V31))!=Cnil){
	goto T77;}
	{object V32 = (*(LnkLI107))((V28),cdr((V28)),Cnil);
	VMR4(V32)}
T77:;
	base[0]= VV[21];
	base[1]= (V28);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk108)();
	vs_top=sup;
	{object V33 = vs_base[0];
	VMR4(V33)}
}
/*	local entry for function CHECK-DECLARATIONS	*/

static object LI5(V35)

register object V35;
{	 VMB5 VMS5 VMV5
TTL:;
	{register object V36;
	V36= Cnil;
	if(!(type_of((V35))==t_cons)){
	goto T87;}
	if(!(type_of(car((V35)))==t_cons)){
	goto T92;}
	V36= car((V35));
	goto T90;
T92:;
	V36= list(2,car((V35)),Cnil);
T90:;
	if(type_of(car((V36)))==t_symbol){
	goto T94;}
	base[0]= VV[22];
	base[1]= car((V36));
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk108)();
	vs_top=sup;
T94:;
	if((cddr((V36)))==Cnil){
	goto T99;}
	base[0]= VV[23];
	base[1]= (V36);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk108)();
	vs_top=sup;
T99:;
	V38= car((V36));
	V39= (*(LnkLI109))();
	{register object x= /* INLINE-ARGS */V38,V37= /* INLINE-ARGS */V39;
	while(!endp(V37))
	if(type_of(V37->c.c_car)==t_cons &&eql(x,V37->c.c_car->c.c_car)){
	goto T106;
	}else V37=V37->c.c_cdr;
	goto T105;}
T106:;
	base[0]= VV[24];
	base[1]= car((V36));
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk108)();
	vs_top=sup;
	{object V40 = vs_base[0];
	VMR5(V40)}
T105:;
	{object V41 = Cnil;
	VMR5(V41)}
T87:;
	{object V42 = Cnil;
	VMR5(V42)}}
}
/*	local entry for function CHECK-TRACE-ARGS	*/

static object LI6(V46,V47,V48)

register object V46;register object V47;register object V48;
{	 VMB6 VMS6 VMV6
TTL:;
	if(((V47))==Cnil){
	goto T110;}
	if((cdr((V47)))!=Cnil){
	goto T113;}
	base[0]= VV[25];
	base[1]= (V46);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk108)();
	vs_top=sup;
	{object V49 = vs_base[0];
	VMR6(V49)}
T113:;
	{register object x= car((V47)),V50= (V48);
	while(!endp(V50))
	if(eql(x,V50->c.c_car)){
	goto T119;
	}else V50=V50->c.c_cdr;
	goto T118;}
T119:;
	base[0]= VV[26];
	base[1]= car((V47));
	base[2]= (V46);
	vs_top=(vs_base=base+0)+3;
	(void) (*Lnk108)();
	vs_top=sup;
	{object V51 = vs_base[0];
	VMR6(V51)}
T118:;
	{object V52= car((V47));
	if((V52!= VV[102])
	&& (V52!= VV[104])
	&& (V52!= VV[100])
	&& (V52!= VV[101])
	&& (V52!= VV[103]))goto T123;
	{object V53;
	V53= cddr((V47));
	V48= make_cons(car((V47)),(V48));
	V47= (V53);}
	goto TTL;
T123:;
	if((V52!= VV[28]))goto T128;
	{object V54= cadr((V47));
	if(!(type_of(V54)==t_fixnum||type_of(V54)==t_bignum)){
	goto T130;}}
	if(number_compare(cadr((V47)),small_fixnum(0))>0){
	goto T129;}
T130:;
	base[0]= VV[27];
	base[1]= cadr((V47));
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk108)();
	vs_top=sup;
T129:;
	V47= cddr((V47));
	V48= make_cons(VV[28],(V48));
	goto TTL;
T128:;
	if((V52!= VV[29]))goto T140;
	(void)((*(LnkLI110))(cadr((V47))));
	V47= cddr((V47));
	V48= make_cons(VV[29],(V48));
	goto TTL;
T140:;
	base[0]= VV[30];
	base[1]= (V46);
	base[2]= car((V47));
	vs_top=(vs_base=base+0)+3;
	(void) (*Lnk108)();
	vs_top=sup;
	{object V55 = vs_base[0];
	VMR6(V55)}}
T110:;
	{object V56 = Cnil;
	VMR6(V56)}
}
/*	local entry for function TRACE-ONE	*/

static object LI7(V58)

register object V58;
{	 VMB7 VMS7 VMV7
TTL:;
	{object V59;
	register object V60;
	V59= Cnil;
	if(!(type_of((V58))==t_cons)){
	goto T152;}
	V60= car((V58));
	goto T150;
T152:;
	V60= (V58);
T150:;
	base[1]= (V60);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk111)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T154;}
	base[1]= symbol_value(VV[31]);
	base[2]= VV[32];
	base[3]= (V60);
	vs_top=(vs_base=base+1)+3;
	(void) (*Lnk112)();
	vs_top=sup;
	{object V61 = Cnil;
	VMR7(V61)}
T154:;
	base[1]= (V60);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk113)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T162;}
	base[1]= symbol_value(VV[31]);
	base[2]= VV[33];
	base[3]= (V60);
	vs_top=(vs_base=base+1)+3;
	(void) (*Lnk112)();
	vs_top=sup;
	{object V62 = Cnil;
	VMR7(V62)}
T162:;
	base[1]= (V60);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk114)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T170;}
	base[1]= symbol_value(VV[31]);
	base[2]= VV[34];
	base[3]= (V60);
	vs_top=(vs_base=base+1)+3;
	(void) (*Lnk112)();
	vs_top=sup;
	{object V63 = Cnil;
	VMR7(V63)}
T170:;
	if((get((V60),VV[35],Cnil))==Cnil){
	goto T178;}
	(void)((*(LnkLI115))((V60)));
T178:;
	(void)((*(LnkLI116))((V58)));
	V58= (*(LnkLI117))((V58));
	vs_base=vs_top;
	(void) (*Lnk98)();
	vs_top=sup;
	V59= vs_base[0];
	base[1]= (V59);
	base[3]= (V60);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk118)();
	vs_top=sup;
	base[2]= vs_base[0];
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk119)();
	vs_top=sup;
	base[1]= list(4,VV[36],(V60),VV[37],listA(4,VV[38],list(2,VV[7],(V59)),VV[39],cddr((V58))));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk99)();
	vs_top=sup;
	(void)(putprop((V60),(V59),VV[35]));
	V64= make_cons((V60),cadr((V58)));
	setq(VV[40],make_cons(/* INLINE-ARGS */V64,symbol_value(VV[40])));
	{object V65 = make_cons((V60),Cnil);
	VMR7(V65)}}
}
/*	local entry for function RESET-TRACE-DECLARATIONS	*/

static object LI8(V67)

register object V67;
{	 VMB8 VMS8 VMV8
TTL:;
	if(((V67))==Cnil){
	goto T195;}
	base[0]= caar((V67));
	base[1]= cdar((V67));
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk120)();
	vs_top=sup;
	V67= cdr((V67));
	goto TTL;
T195:;
	{object V68 = Cnil;
	VMR8(V68)}
}
/*	local entry for function ALL-TRACE-DECLARATIONS	*/

static object LI9()

{	 VMB9 VMS9 VMV9
TTL:;
	{register object V69;
	V69= Cnil;
	{register object V70;
	register object V71;
	V70= symbol_value(VV[40]);
	V71= car((V70));
T207:;
	if(!(endp((V70)))){
	goto T208;}
	goto T203;
T208:;
	V69= append((V69),cdr((V71)));
	V70= cdr((V70));
	V71= car((V70));
	goto T207;}
T203:;
	{object V72 = (V69);
	VMR9(V72)}}
}
/*	function definition for TRACE-CALL	*/

static L10()
{register object *base=vs_base;
	register object *sup=base+VM10; VC10
	vs_reserve(VM10);
	bds_check;
	{object V73;
	register object V74;
	object V75;
	object V76;
	object V77;
	object V78;
	object V79;
	check_arg(7);
	V73=(base[0]);
	V74=(base[1]);
	V75=(base[2]);
	V76=(base[3]);
	V77=(base[4]);
	V78=(base[5]);
	V79=(base[6]);
	vs_top=sup;
TTL:;
	{register object V80;
	object V81;
	bds_bind(VV[41],symbol_value(VV[41]));
	V80= Cnil;
	V81= Cnil;
	if(!(number_compare((VV[41]->s.s_dbind),small_fixnum(0))==0)){
	goto T221;}
	V82= (*(LnkLI109))();
	(void)((*(LnkLI121))(/* INLINE-ARGS */V82));
T221:;
	V83= list(2,VV[13],list(2,VV[7],(V74)));
	base[8]= list(3,VV[1],make_cons(/* INLINE-ARGS */V83,Cnil),(V75));
	vs_top=(vs_base=base+8)+1;
	(void) (*Lnk99)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T225;}
	(VV[41]->s.s_dbind)= one_plus((VV[41]->s.s_dbind));
	V84= number_times((VV[41]->s.s_dbind),small_fixnum(2));
	V81= (number_compare(/* INLINE-ARGS */V84,small_fixnum(20))<=0?(/* INLINE-ARGS */V84):small_fixnum(20));
	base[8]= symbol_value(VV[31]);
	vs_top=(vs_base=base+8)+1;
	(void) (*Lnk122)();
	vs_top=sup;
	if(((V76))==(Ct)){
	goto T235;}
	V85= list(2,VV[13],list(2,VV[7],(V74)));
	base[8]= list(3,VV[1],make_cons(/* INLINE-ARGS */V85,Cnil),(V76));
	vs_top=(vs_base=base+8)+1;
	(void) (*Lnk99)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T234;}
T235:;
	base[8]= symbol_value(VV[31]);
	base[9]= VV[42];
	base[10]= (V81);
	base[11]= (VV[41]->s.s_dbind);
	vs_top=(vs_base=base+8)+4;
	(void) (*Lnk112)();
	vs_top=sup;
	base[8]= symbol_value(VV[31]);
	base[9]= VV[43];
	V86= list(2,VV[13],list(2,VV[7],(V74)));
	base[11]= list(3,VV[1],make_cons(/* INLINE-ARGS */V86,Cnil),(V77));
	vs_top=(vs_base=base+11)+1;
	(void) (*Lnk99)();
	vs_top=sup;
	base[10]= vs_base[0];
	vs_top=(vs_base=base+8)+3;
	(void) (*Lnk112)();
	vs_top=sup;
	base[8]= symbol_value(VV[31]);
	vs_top=(vs_base=base+8)+1;
	(void) (*Lnk122)();
	vs_top=sup;
T234:;
	base[8]=symbol_function(VV[123]);
	base[9]= (V73);
	{object V87;
	V87= (V74);
	 vs_top=base+10;
	 while(!endp(V87))
	 {vs_push(car(V87));V87=cdr(V87);}
	vs_base=base+10;}
	super_funcall_no_event(base[9]);
	(void) (*Lnk123)();
	vs_top=sup;
	V80= vs_base[0];
	if(((V78))==(Ct)){
	goto T257;}
	V88= list(2,VV[13],list(2,VV[7],(V74)));
	base[8]= list(3,VV[1],list(2,/* INLINE-ARGS */V88,list(2,VV[14],list(2,VV[7],(V80)))),(V78));
	vs_top=(vs_base=base+8)+1;
	(void) (*Lnk99)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T256;}
T257:;
	base[8]= symbol_value(VV[31]);
	base[9]= VV[44];
	base[10]= (V81);
	base[11]= (VV[41]->s.s_dbind);
	vs_top=(vs_base=base+8)+4;
	(void) (*Lnk112)();
	vs_top=sup;
	base[8]= symbol_value(VV[31]);
	base[9]= VV[45];
	V89= list(2,VV[13],list(2,VV[7],(V74)));
	base[11]= list(3,VV[1],list(2,/* INLINE-ARGS */V89,list(2,VV[14],list(2,VV[7],(V80)))),(V79));
	vs_top=(vs_base=base+11)+1;
	(void) (*Lnk99)();
	vs_top=sup;
	base[10]= vs_base[0];
	vs_top=(vs_base=base+8)+3;
	(void) (*Lnk112)();
	vs_top=sup;
T256:;
	(VV[41]->s.s_dbind)= one_minus((VV[41]->s.s_dbind));
	base[8]= (V80);
	vs_top=(vs_base=base+8)+1;
	(void) (*Lnk124)();
	bds_unwind1;
	return;
T225:;
	base[8]= (V73);
	{object V90;
	V90= (V74);
	 vs_top=base+9;
	 while(!endp(V90))
	 {vs_push(car(V90));V90=cdr(V90);}
	vs_base=base+9;}
	super_funcall_no_event(base[8]);
	bds_unwind1;
	return;}
	}
}
/*	local entry for function UNTRACE-ONE	*/

static object LI12(V92)

object V92;
{	 VMB11 VMS11 VMV11
TTL:;
	{object V93;
	base[0]=MMcons((V92),Cnil);
	V93= Cnil;
	V93= get((base[0]->c.c_car),VV[35],Cnil);
	if(((V93))==Cnil){
	goto T278;}
	(void)(remprop((base[0]->c.c_car),VV[35]));
	base[1]= (base[0]->c.c_car);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk111)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T284;}
	base[1]= symbol_value(VV[31]);
	base[2]= VV[46];
	base[3]= (base[0]->c.c_car);
	vs_top=(vs_base=base+1)+3;
	(void) (*Lnk112)();
	vs_top=sup;
	goto T282;
T284:;
	base[1]= (base[0]->c.c_car);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk118)();
	vs_top=sup;
	V94= vs_base[0];
	if(!(type_of(V94)==t_cons)){
	goto T291;}
	base[1]= (base[0]->c.c_car);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk118)();
	vs_top=sup;
	V95= vs_base[0];
	if(!(type_of(cadddr(V95))==t_cons)){
	goto T291;}
	base[1]= (base[0]->c.c_car);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk118)();
	vs_top=sup;
	V96= vs_base[0];
	if(!((car(cadddr(V96)))==(VV[38]))){
	goto T291;}
	base[1]= (base[0]->c.c_car);
	base[3]= (V93);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk118)();
	vs_top=sup;
	base[2]= vs_base[0];
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk119)();
	vs_top=sup;
	goto T282;
T291:;
	base[1]= symbol_value(VV[31]);
	base[2]= VV[47];
	base[3]= (base[0]->c.c_car);
	vs_top=(vs_base=base+1)+3;
	(void) (*Lnk112)();
	vs_top=sup;
T282:;
	V97= 
	make_cclosure_new(LC17,Cnil,base[0],Cdata);
	setq(VV[40],(VFUN_NARGS=4,(*(LnkLI125))(V97,symbol_value(VV[40]),VV[48],small_fixnum(1))));
	{object V98 = make_cons((base[0]->c.c_car),Cnil);
	VMR11(V98)}
T278:;
	base[1]= symbol_value(VV[31]);
	base[2]= VV[49];
	base[3]= (base[0]->c.c_car);
	vs_top=(vs_base=base+1)+3;
	(void) (*Lnk112)();
	vs_top=sup;
	{object V99 = Cnil;
	VMR11(V99)}}
}
/*	local entry for function STEP-READ-LINE	*/

static object LI13()

{	 VMB12 VMS12 VMV12
TTL:;
	{register object V100;
	base[0]= symbol_value(VV[50]);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk126)();
	vs_top=sup;
	V100= vs_base[0];
T319:;
	base[0]= (V100);
	base[1]= VV[51];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk127)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T321;}
	base[0]= (V100);
	base[1]= VV[52];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk127)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T320;}
T321:;
	{object V101 = Cnil;
	VMR12(V101)}
T320:;
	base[0]= symbol_value(VV[50]);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk126)();
	vs_top=sup;
	V100= vs_base[0];
	goto T319;}
}
/*	macro definition for IF-ERROR	*/

static L14()
{register object *base=vs_base;
	register object *sup=base+VM13; VC13
	vs_reserve(VM13);
	check_arg(2);
	vs_top=sup;
	{object V102=base[0]->c.c_cdr;
	if(endp(V102))invalid_macro_call();
	base[2]= (V102->c.c_car);
	V102=V102->c.c_cdr;
	if(endp(V102))invalid_macro_call();
	base[3]= (V102->c.c_car);
	V102=V102->c.c_cdr;
	if(!endp(V102))invalid_macro_call();}
	{object V103;
	object V104;
	object V105;
	vs_base=vs_top;
	(void) (*Lnk98)();
	vs_top=sup;
	V103= vs_base[0];
	vs_base=vs_top;
	(void) (*Lnk98)();
	vs_top=sup;
	V104= vs_base[0];
	vs_base=vs_top;
	(void) (*Lnk98)();
	vs_top=sup;
	V105= vs_base[0];
	V106= list(2,(V103),(V104));
	V107= list(5,VV[18],(V103),base[3],(V104),Ct);
	base[4]= list(3,VV[1],/* INLINE-ARGS */V106,list(3,VV[53],(V105),list(3,VV[3],/* INLINE-ARGS */V107,list(3,VV[54],(V105),list(4,VV[16],(V104),(V103),base[2])))));
	vs_top=(vs_base=base+4)+1;
	return;}
}
/*	macro definition for STEP	*/

static L15()
{register object *base=vs_base;
	register object *sup=base+VM14; VC14
	vs_reserve(VM14);
	check_arg(2);
	vs_top=sup;
	{object V108=base[0]->c.c_cdr;
	if(endp(V108))invalid_macro_call();
	base[2]= (V108->c.c_car);
	V108=V108->c.c_cdr;
	if(!endp(V108))invalid_macro_call();}
	base[3]= list(6,VV[55],VV[56],VV[57],VV[58],VV[59],list(3,VV[60],list(2,VV[7],base[2]),Cnil));
	vs_top=(vs_base=base+3)+1;
	return;
}
/*	function definition for STEPPER	*/

static L16()
{register object *VOL base=vs_base;
	register object *VOL sup=base+VM15; VC15
	vs_reserve(VM15);
	bds_check;
	{VOL object V109;
	VOL object V110;
	if(vs_top-vs_base<1) too_few_arguments();
	if(vs_top-vs_base>2) too_many_arguments();
	V109=(base[0]);
	vs_base=vs_base+1;
	if(vs_base>=vs_top){vs_top=sup;goto T337;}
	V110=(base[1]);
	vs_top=sup;
	goto T338;
T337:;
	V110= Cnil;
T338:;
	{VOL object V111;
	VOL object V112;
	V111= Cnil;
	bds_bind(VV[61],symbol_value(VV[61]));
	V112= Cnil;
	if(!((symbol_value(VV[62]))==(Ct))){
	goto T342;}
	base[3]= (V109);
	base[4]= Cnil;
	base[5]= Cnil;
	base[6]= (V110);
	vs_top=(vs_base=base+3)+4;
	(void) (*Lnk128)();
	bds_unwind1;
	return;
T342:;
	if(!(type_of(symbol_value(VV[62]))==t_fixnum||
type_of(symbol_value(VV[62]))==t_bignum||
type_of(symbol_value(VV[62]))==t_ratio||
type_of(symbol_value(VV[62]))==t_shortfloat||
type_of(symbol_value(VV[62]))==t_longfloat||
type_of(symbol_value(VV[62]))==t_complex)){
	goto T349;}
	V113= one_plus((VV[61]->s.s_dbind));
	if(!(number_compare(/* INLINE-ARGS */V113,symbol_value(VV[62]))>=0)){
	goto T353;}
	base[3]= (V109);
	base[4]= Cnil;
	base[5]= Cnil;
	base[6]= (V110);
	vs_top=(vs_base=base+3)+4;
	(void) (*Lnk128)();
	bds_unwind1;
	return;
T353:;
	setq(VV[62],Cnil);
T349:;
	if((symbol_value(VV[63]))==Cnil){
	goto T360;}
	if(!(type_of((V109))==t_cons)){
	goto T364;}
	if(!((car((V109)))==(symbol_value(VV[63])))){
	goto T364;}
	bds_bind(VV[63],Cnil);
	base[4]= (V109);
	base[5]= (V110);
	vs_top=(vs_base=base+4)+2;
	(void) (*Lnk60)();
	bds_unwind1;
	bds_unwind1;
	return;
T364:;
	base[3]= (V109);
	base[4]= symbol_function(VV[60]);
	base[5]= Cnil;
	base[6]= (V110);
	vs_top=(vs_base=base+3)+4;
	(void) (*Lnk128)();
	bds_unwind1;
	return;
T360:;
	(VV[61]->s.s_dbind)= one_plus((VV[61]->s.s_dbind));
	V114= number_times((VV[61]->s.s_dbind),small_fixnum(2));
	V112= (number_compare(/* INLINE-ARGS */V114,small_fixnum(20))<=0?(/* INLINE-ARGS */V114):small_fixnum(20));
T380:;
	base[3]= symbol_value(VV[50]);
	base[4]= VV[64];
	base[5]= (V112);
	base[6]= (V109);
	vs_top=(vs_base=base+3)+4;
	(void) (*Lnk112)();
	vs_top=sup;
	base[3]= symbol_value(VV[50]);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk129)();
	vs_top=sup;
	{register object V117;
	base[3]= symbol_value(VV[50]);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk126)();
	vs_top=sup;
	V117= vs_base[0];
T393:;
	base[3]= (V117);
	base[4]= VV[65];
	vs_top=(vs_base=base+3)+2;
	(void) (*Lnk130)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T394;}
	base[3]= (V117);
	base[4]= VV[66];
	vs_top=(vs_base=base+3)+2;
	(void) (*Lnk130)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T394;}
	V116= (V117);
	goto T389;
T394:;
	base[3]= symbol_value(VV[50]);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk126)();
	vs_top=sup;
	V117= vs_base[0];
	goto T393;}
T389:;
	{object V115= V116;
	if(!eql(V115,VV[51])
	&& !eql(V115,VV[52]))goto T408;
	base[3]=symbol_function(VV[123]);
	base[4]= (V109);
	base[5]= symbol_function(VV[60]);
	base[6]= Cnil;
	base[7]= (V110);
	vs_top=(vs_base=base+4)+4;
	(void) (*Lnk128)();
	(void) (*Lnk123)();
	vs_top=sup;
	V111= vs_base[0];
	goto T378;
T408:;
	if(!eql(V115,VV[67])
	&& !eql(V115,VV[68]))goto T416;
	(void)((*(LnkLI131))());
	base[3]=symbol_function(VV[123]);
	base[4]= (V109);
	base[5]= symbol_function(VV[60]);
	base[6]= Cnil;
	base[7]= (V110);
	vs_top=(vs_base=base+4)+4;
	(void) (*Lnk128)();
	(void) (*Lnk123)();
	vs_top=sup;
	V111= vs_base[0];
	goto T378;
T416:;
	if(!eql(V115,VV[69])
	&& !eql(V115,VV[70]))goto T425;
	(void)((*(LnkLI131))());
	base[3]=symbol_function(VV[123]);
	base[4]= (V109);
	base[5]= Cnil;
	base[6]= Cnil;
	base[7]= (V110);
	vs_top=(vs_base=base+4)+4;
	(void) (*Lnk128)();
	(void) (*Lnk123)();
	vs_top=sup;
	V111= vs_base[0];
	goto T378;
T425:;
	if(!eql(V115,VV[71])
	&& !eql(V115,VV[72]))goto T434;
	(void)((*(LnkLI131))());
	base[3]= (V109);
	base[4]= VV[73];
	base[5]= symbol_value(VV[50]);
	base[6]= VV[74];
	base[7]= Ct;
	base[8]= VV[75];
	base[9]= Cnil;
	base[10]= VV[76];
	base[11]= Cnil;
	vs_top=(vs_base=base+3)+9;
	(void) (*Lnk132)();
	vs_top=sup;
	princ_char(10,Cnil);
	goto T381;
T434:;
	if(!eql(V115,VV[77])
	&& !eql(V115,VV[78]))goto T446;
	base[4]= Cnil;
	base[5]= Cnil;
	{object tag;frame_ptr fr;object p;bool active;
	frs_push(FRS_PROTECT,Cnil);
	if(nlj_active){tag=nlj_tag;fr=nlj_fr;active=TRUE;}
	else{
	{object V118;
	base[7]= symbol_value(VV[50]);
	vs_top=(vs_base=base+7)+1;
	(void) (*Lnk133)();
	vs_top=sup;
	V118= vs_base[0];
	(void)((*(LnkLI131))());
	base[4]= (V118);}
	base[5]= Ct;
	base[7]= Ct;
	vs_top=(vs_base=base+7)+1;
	active=FALSE;}
	base[6]=Cnil;
	while(vs_base<vs_top)
	{base[6]=MMcons(vs_top[-1],base[6]);vs_top--;}
	vs_top=sup;
	nlj_active=FALSE;frs_pop();
	if((base[5])==Cnil){
	goto T457;}
	base[3]= base[4];
	goto T447;
T457:;
	base[3]= Cnil;
	goto T447;
	vs_base=vs_top=base+7;
	for(p= base[6];!endp(p);p=MMcdr(p))vs_push(MMcar(p));
	if(active)unwind(fr,tag);else{
	vs_top=sup;
	base[3]= vs_base[0];}}
T447:;
	bds_bind(VV[63],base[3]);
	base[4]=symbol_function(VV[123]);
	base[5]= (V109);
	base[6]= symbol_function(VV[60]);
	base[7]= Cnil;
	base[8]= (V110);
	vs_top=(vs_base=base+5)+4;
	(void) (*Lnk128)();
	(void) (*Lnk123)();
	vs_top=sup;
	V111= vs_base[0];
	bds_unwind1;
	goto T378;
T446:;
	if(!eql(V115,VV[79])
	&& !eql(V115,VV[80]))goto T466;
	(void)((*(LnkLI131))());
	setq(VV[62],Ct);
	base[3]=symbol_function(VV[123]);
	base[4]= (V109);
	base[5]= Cnil;
	base[6]= Cnil;
	base[7]= (V110);
	vs_top=(vs_base=base+4)+4;
	(void) (*Lnk128)();
	(void) (*Lnk123)();
	vs_top=sup;
	V111= vs_base[0];
	goto T378;
T466:;
	if(!eql(V115,VV[81])
	&& !eql(V115,VV[82]))goto T477;
	(void)((*(LnkLI131))());
	setq(VV[62],(VV[61]->s.s_dbind));
	base[3]=symbol_function(VV[123]);
	base[4]= (V109);
	base[5]= Cnil;
	base[6]= Cnil;
	base[7]= (V110);
	vs_top=(vs_base=base+4)+4;
	(void) (*Lnk128)();
	(void) (*Lnk123)();
	vs_top=sup;
	V111= vs_base[0];
	goto T378;
T477:;
	if(!eql(V115,VV[83])
	&& !eql(V115,VV[84]))goto T488;
	base[3]= (V110);
	{VOL object V119;
	VOL object V120;
	base[6]= Cnil;
	base[7]= Cnil;
	{object tag;frame_ptr fr;object p;bool active;
	frs_push(FRS_PROTECT,Cnil);
	if(nlj_active){tag=nlj_tag;fr=nlj_fr;active=TRUE;}
	else{
	base[9]=symbol_function(VV[123]);
	base[11]= Cnil;
	base[12]= Cnil;
	{object tag;frame_ptr fr;object p;bool active;
	frs_push(FRS_PROTECT,Cnil);
	if(nlj_active){tag=nlj_tag;fr=nlj_fr;active=TRUE;}
	else{
	{object V121;
	base[14]= symbol_value(VV[50]);
	vs_top=(vs_base=base+14)+1;
	(void) (*Lnk133)();
	vs_top=sup;
	V121= vs_base[0];
	(void)((*(LnkLI131))());
	base[11]= (V121);}
	base[12]= Ct;
	base[14]= Ct;
	vs_top=(vs_base=base+14)+1;
	active=FALSE;}
	base[13]=Cnil;
	while(vs_base<vs_top)
	{base[13]=MMcons(vs_top[-1],base[13]);vs_top--;}
	vs_top=sup;
	nlj_active=FALSE;frs_pop();
	if((base[12])==Cnil){
	goto T504;}
	base[10]= base[11];
	goto T494;
T504:;
	base[10]= Cnil;
	goto T494;
	vs_base=vs_top=base+14;
	for(p= base[13];!endp(p);p=MMcdr(p))vs_push(MMcar(p));
	if(active)unwind(fr,tag);else{
	vs_top=sup;
	base[10]= vs_base[0];}}
T494:;
	base[11]= Cnil;
	base[12]= Cnil;
	base[13]= base[3];
	vs_top=(vs_base=base+10)+4;
	(void) (*Lnk128)();
	(void) (*Lnk123)();
	vs_top=sup;
	base[6]= vs_base[0];
	base[7]= Ct;
	base[9]= Ct;
	vs_top=(vs_base=base+9)+1;
	active=FALSE;}
	base[8]=Cnil;
	while(vs_base<vs_top)
	{base[8]=MMcons(vs_top[-1],base[8]);vs_top--;}
	vs_top=sup;
	nlj_active=FALSE;frs_pop();
	if((base[7])==Cnil){
	goto T512;}
	V119= base[6];
	goto T489;
T512:;
	V119= Cnil;
	goto T489;
	vs_base=vs_top=base+9;
	for(p= base[8];!endp(p);p=MMcdr(p))vs_push(MMcar(p));
	if(active)unwind(fr,tag);else{
	vs_top=sup;
	V119= vs_base[0];}}
T489:;
	V120= car((V119));
T516:;
	if(!(endp((V119)))){
	goto T517;}
	goto T381;
T517:;
	base[6]= (V120);
	base[7]= VV[73];
	base[8]= symbol_value(VV[50]);
	base[9]= VV[75];
	base[10]= symbol_value(VV[85]);
	base[11]= VV[76];
	base[12]= symbol_value(VV[86]);
	vs_top=(vs_base=base+6)+7;
	(void) (*Lnk132)();
	vs_top=sup;
	princ_char(10,VV[50]);
	V119= cdr((V119));
	V120= car((V119));
	goto T516;}
T488:;
	if(!eql(V115,VV[87])
	&& !eql(V115,VV[88]))goto T535;
	base[3]= (V110);
	base[4]= Cnil;
	base[5]= Cnil;
	{object tag;frame_ptr fr;object p;bool active;
	frs_push(FRS_PROTECT,Cnil);
	if(nlj_active){tag=nlj_tag;fr=nlj_fr;active=TRUE;}
	else{
	base[7]=symbol_function(VV[123]);
	base[9]= Cnil;
	base[10]= Cnil;
	{object tag;frame_ptr fr;object p;bool active;
	frs_push(FRS_PROTECT,Cnil);
	if(nlj_active){tag=nlj_tag;fr=nlj_fr;active=TRUE;}
	else{
	{object V122;
	base[12]= symbol_value(VV[50]);
	vs_top=(vs_base=base+12)+1;
	(void) (*Lnk133)();
	vs_top=sup;
	V122= vs_base[0];
	(void)((*(LnkLI131))());
	base[9]= (V122);}
	base[10]= Ct;
	base[12]= Ct;
	vs_top=(vs_base=base+12)+1;
	active=FALSE;}
	base[11]=Cnil;
	while(vs_base<vs_top)
	{base[11]=MMcons(vs_top[-1],base[11]);vs_top--;}
	vs_top=sup;
	nlj_active=FALSE;frs_pop();
	if((base[10])==Cnil){
	goto T552;}
	base[8]= base[9];
	goto T542;
T552:;
	base[8]= Cnil;
	goto T542;
	vs_base=vs_top=base+12;
	for(p= base[11];!endp(p);p=MMcdr(p))vs_push(MMcar(p));
	if(active)unwind(fr,tag);else{
	vs_top=sup;
	base[8]= vs_base[0];}}
T542:;
	base[9]= Cnil;
	base[10]= Cnil;
	base[11]= base[3];
	vs_top=(vs_base=base+8)+4;
	(void) (*Lnk128)();
	(void) (*Lnk123)();
	vs_top=sup;
	base[4]= vs_base[0];
	base[5]= Ct;
	base[7]= Ct;
	vs_top=(vs_base=base+7)+1;
	active=FALSE;}
	base[6]=Cnil;
	while(vs_base<vs_top)
	{base[6]=MMcons(vs_top[-1],base[6]);vs_top--;}
	vs_top=sup;
	nlj_active=FALSE;frs_pop();
	if((base[5])==Cnil){
	goto T560;}
	V111= base[4];
	goto T537;
T560:;
	V111= Cnil;
	goto T537;
	vs_base=vs_top=base+7;
	for(p= base[6];!endp(p);p=MMcdr(p))vs_push(MMcar(p));
	if(active)unwind(fr,tag);else{
	vs_top=sup;
	V111= vs_base[0];}}
T537:;
	goto T378;
T535:;
	if(!eql(V115,VV[89])
	&& !eql(V115,VV[90]))goto T562;
	(void)((*(LnkLI131))());
	base[3]= one_plus(symbol_value(VV[92]));
	vs_base=vs_top;
	(void) (*Lnk134)();
	vs_top=sup;
	V123= vs_base[0];
	base[4]= one_minus(V123);
	base[5]= symbol_value(VV[92]);
	bds_bind(VV[91],base[3]);
	bds_bind(VV[92],base[4]);
	bds_bind(VV[93],base[5]);
	vs_base=vs_top;
	(void) (*Lnk135)();
	vs_top=sup;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	goto T381;
T562:;
	(void)((*(LnkLI131))());
	princ_char(10,Cnil);
	base[3]= symbol_value(VV[50]);
	base[4]= VV[94];
	vs_top=(vs_base=base+3)+2;
	(void) (*Lnk112)();
	vs_top=sup;
	princ_char(10,Cnil);}
T381:;
	goto T380;
T378:;
	base[3]= (V109);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk136)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T575;}
	if(!(type_of((V109))==t_cons)){
	goto T574;}
	if(!((car((V109)))==(VV[7]))){
	goto T574;}
T575:;
	base[3]= car((V111));
	vs_top=(vs_base=base+3)+1;
	bds_unwind1;
	return;
T574:;
	if(!(endp((V111)))){
	goto T584;}
	base[3]= symbol_value(VV[50]);
	base[4]= VV[95];
	base[5]= (V112);
	vs_top=(vs_base=base+3)+3;
	(void) (*Lnk112)();
	vs_top=sup;
	goto T582;
T584:;
	{object V124;
	object V125;
	V124= (V111);
	V125= Ct;
T590:;
	if(!(endp((V124)))){
	goto T591;}
	goto T582;
T591:;
	if(((V125))==Cnil){
	goto T597;}
	base[3]= symbol_value(VV[50]);
	base[4]= VV[96];
	base[5]= (V112);
	base[6]= car((V124));
	vs_top=(vs_base=base+3)+4;
	(void) (*Lnk112)();
	vs_top=sup;
	goto T595;
T597:;
	base[3]= symbol_value(VV[50]);
	base[4]= VV[97];
	base[5]= (V112);
	base[6]= car((V124));
	vs_top=(vs_base=base+3)+4;
	(void) (*Lnk112)();
	vs_top=sup;
T595:;
	V124= cdr((V124));
	V125= Cnil;
	goto T590;}
T582:;
	(VV[61]->s.s_dbind)= number_minus((VV[61]->s.s_dbind),small_fixnum(1));
	base[3]= (V111);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk124)();
	bds_unwind1;
	return;}
	}
}
/*	local function CLOSURE	*/

static LC17(base0)
register object *base0;
{	register object *base=vs_base;
	register object *sup=base+VM16; VC16
	vs_reserve(VM16);
	{object V126;
	check_arg(1);
	V126=(base[0]);
	vs_top=sup;
	base[1]= car((V126));
	base[2]= (base0[0]->c.c_car);
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk137)();
	return;
	}
}
static LnkT137(){ call_or_link(VV[137],&Lnk137);} /* EQ */
static LnkT136(){ call_or_link(VV[136],&Lnk136);} /* CONSTANTP */
static LnkT135(){ call_or_link(VV[135],&Lnk135);} /* SIMPLE-BACKTRACE */
static LnkT134(){ call_or_link(VV[134],&Lnk134);} /* IHS-TOP */
static LnkT133(){ call_or_link(VV[133],&Lnk133);} /* READ-PRESERVING-WHITESPACE */
static LnkT132(){ call_or_link(VV[132],&Lnk132);} /* WRITE */
static object  LnkTLI131(){return call_proc0(VV[131],&LnkLI131);} /* STEP-READ-LINE */
static LnkT130(){ call_or_link(VV[130],&Lnk130);} /* CHAR= */
static LnkT129(){ call_or_link(VV[129],&Lnk129);} /* FINISH-OUTPUT */
static LnkT60(){ call_or_link(VV[60],&Lnk60);} /* STEPPER */
static LnkT128(){ call_or_link(VV[128],&Lnk128);} /* EVALHOOK */
static LnkT127(){ call_or_link(VV[127],&Lnk127);} /* CHAR= */
static LnkT126(){ call_or_link(VV[126],&Lnk126);} /* READ-CHAR */
static object  LnkTLI125(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[125],&LnkLI125,ap);} /* DELETE-IF */
static LnkT124(){ call_or_link(VV[124],&Lnk124);} /* VALUES-LIST */
static LnkT123(){ call_or_link(VV[123],&Lnk123);} /* LIST */
static LnkT122(){ call_or_link(VV[122],&Lnk122);} /* FRESH-LINE */
static object  LnkTLI121(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[121],&LnkLI121,1,ap);} /* RESET-TRACE-DECLARATIONS */
static LnkT120(){ call_or_link(VV[120],&Lnk120);} /* SET */
static LnkT119(){ call_or_link(VV[119],&Lnk119);} /* FSET */
static LnkT118(){ call_or_link(VV[118],&Lnk118);} /* SYMBOL-FUNCTION */
static object  LnkTLI117(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[117],&LnkLI117,1,ap);} /* TRACE-ONE-PREPROCESS */
static object  LnkTLI116(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[116],&LnkLI116,1,ap);} /* CHECK-TRACE-SPEC */
static object  LnkTLI115(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[115],&LnkLI115,1,ap);} /* UNTRACE-ONE */
static LnkT114(){ call_or_link(VV[114],&Lnk114);} /* MACRO-FUNCTION */
static LnkT113(){ call_or_link(VV[113],&Lnk113);} /* SPECIAL-FORM-P */
static LnkT112(){ call_or_link(VV[112],&Lnk112);} /* FORMAT */
static LnkT111(){ call_or_link(VV[111],&Lnk111);} /* FBOUNDP */
static object  LnkTLI110(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[110],&LnkLI110,1,ap);} /* CHECK-DECLARATIONS */
static object  LnkTLI109(){return call_proc0(VV[109],&LnkLI109);} /* ALL-TRACE-DECLARATIONS */
static LnkT108(){ call_or_link(VV[108],&Lnk108);} /* ERROR */
static object  LnkTLI107(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[107],&LnkLI107,3,ap);} /* CHECK-TRACE-ARGS */
static LnkT106(){ call_or_link(VV[106],&Lnk106);} /* LAST */
static LnkT105(){ call_or_link(VV[105],&Lnk105);} /* SYMBOLP */
static LnkT99(){ call_or_link(VV[99],&Lnk99);} /* EVAL */
static LnkT98(){ call_or_link(VV[98],&Lnk98);} /* GENSYM */
