
#include <cmpinclude.h>
#include "cmptop.h"
init_cmptop(){do_init(VV);}
/*	function definition for T1EXPR	*/

static L1()
{register object *VOL base=vs_base;
	register object *VOL sup=base+VM1; VC1
	vs_reserve(VM1);
	bds_check;
	{VOL object V1;
	check_arg(1);
	V1=(base[0]);
	vs_top=sup;
TTL:;
	bds_bind(VV[0],(V1));
	bds_bind(VV[1],Ct);
	frs_push(FRS_CATCH,VV[2]);
	if(nlj_active)
	{nlj_active=FALSE;frs_pop();
	bds_unwind1;
	bds_unwind1;
	return;}
	else{
	if(!(type_of((V1))==t_cons)){
	goto T3;}
	{register object V2;
	object V3;
	register object V4;
	V2= car((V1));
	V3= cdr((V1));
	V4= Cnil;
	if(!(type_of((V2))==t_symbol)){
	goto T8;}
	if(!(((V2))==(VV[3]))){
	goto T11;}
	V5= (VFUN_NARGS=1,(*(LnkLI253))(VV[4]));
	frs_pop();
	base[3]= V5;
	vs_top=(vs_base=base+3)+1;
	bds_unwind1;
	bds_unwind1;
	return;
T11:;
	if((get((V2),VV[5],Cnil))==Cnil){
	goto T14;}
	if((symbol_value(VV[6]))==Cnil){
	goto T16;}
	(void)((VFUN_NARGS=2,(*(LnkLI254))(VV[7],(V1))));
T16:;
	(void)((*(LnkLI255))(Ct,(V1)));
	V6= (*(LnkLI256))((V1));
	frs_pop();
	base[3]= V6;
	vs_top=(vs_base=base+3)+1;
	bds_unwind1;
	bds_unwind1;
	return;
T14:;
	V4= get((V2),VV[8],Cnil);
	if(((V4))==Cnil){
	goto T21;}
	if((symbol_value(VV[9]))==Cnil){
	goto T24;}
	(void)((*(LnkLI257))());
T24:;
	base[3]= (V3);
	vs_top=(vs_base=base+3)+1;
	super_funcall_no_event((V4));
	frs_pop();
	bds_unwind1;
	bds_unwind1;
	return;
T21:;
	if((get((V2),VV[10],Cnil))==Cnil){
	goto T29;}
	if((symbol_value(VV[9]))==Cnil){
	goto T31;}
	(void)((*(LnkLI257))());
T31:;
	base[3]= (*(LnkLI258))((V1));
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk259)();
	frs_pop();
	bds_unwind1;
	bds_unwind1;
	return;
T29:;
	if((get((V2),VV[11],Cnil))==Cnil){
	goto T36;}
	V7= (*(LnkLI260))((V1));
	frs_pop();
	base[3]= V7;
	vs_top=(vs_base=base+3)+1;
	bds_unwind1;
	bds_unwind1;
	return;
T36:;
	base[3]= (V2);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk261)();
	vs_top=sup;
	V4= vs_base[0];
	if(((V4))==Cnil){
	goto T39;}
	{object V8;
	base[3]= cdr((V1));
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk263)();
	vs_top=sup;
	V9= vs_base[0];
	V8= (*(LnkLI262))((V4),(V2),V9);
	base[3]= (V8);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk259)();
	frs_pop();
	bds_unwind1;
	bds_unwind1;
	return;}
T39:;
	V10= (*(LnkLI260))((V1));
	frs_pop();
	base[3]= V10;
	vs_top=(vs_base=base+3)+1;
	bds_unwind1;
	bds_unwind1;
	return;
T8:;
	if(!(type_of((V2))==t_cons)){
	goto T48;}
	V11= (*(LnkLI260))((V1));
	frs_pop();
	base[3]= V11;
	vs_top=(vs_base=base+3)+1;
	bds_unwind1;
	bds_unwind1;
	return;
T48:;
	V12= (VFUN_NARGS=2,(*(LnkLI253))(VV[12],(V2)));
	frs_pop();
	base[3]= V12;
	vs_top=(vs_base=base+3)+1;
	bds_unwind1;
	bds_unwind1;
	return;}
T3:;
	frs_pop();
	base[3]= Cnil;
	vs_top=(vs_base=base+3)+1;
	bds_unwind1;
	bds_unwind1;
	return;}
	}
}
/*	local entry for function CTOP-WRITE	*/

static object LI2(V14)

object V14;
{	 VMB2 VMS2 VMV2
	bds_check;
TTL:;
	{object V15;
	V15= Cnil;
	bds_bind(VV[13],Cnil);
	bds_bind(VV[14],Cnil);
	bds_bind(VV[16],VV[15]);
	bds_bind(VV[17],Cnil);
	bds_bind(VV[18],small_fixnum(0));
	bds_bind(VV[19],Cnil);
	bds_bind(VV[0],Cnil);
	setq(VV[20],reverse(symbol_value(VV[20])));
	princ_str("\ninit_",VV[21]);
	(void)((*(LnkLI264))((V14)));
	princ_str("(){",VV[21]);
	princ_str("do_init(VV);",VV[21]);
	princ_char(125,VV[21]);
	{object V16;
	V16= symbol_value(VV[20]);
	bds_bind(VV[0],car((V16)));
T63:;
	if(!(endp((V16)))){
	goto T64;}
	bds_unwind1;
	goto T59;
T64:;
	setq(VV[1],Ct);
	V15= get(car((VV[0]->s.s_dbind)),VV[22],Cnil);
	if(((V15))==Cnil){
	goto T70;}
	base[8]= (V15);
	{object V17;
	V17= cdr((VV[0]->s.s_dbind));
	 vs_top=base+9;
	 while(!endp(V17))
	 {vs_push(car(V17));V17=cdr(V17);}
	vs_base=base+9;}
	super_funcall_no_event(base[8]);
	vs_top=sup;
T70:;
	V16= cdr((V16));
	(VV[0]->s.s_dbind)= car((V16));
	goto T63;}
T59:;
	{object V18;
	V18= symbol_value(VV[20]);
	bds_bind(VV[0],car((V18)));
T85:;
	if(!(endp((V18)))){
	goto T86;}
	bds_unwind1;
	goto T81;
T86:;
	setq(VV[1],Ct);
	V15= get(car((VV[0]->s.s_dbind)),VV[23],Cnil);
	if(((V15))==Cnil){
	goto T92;}
	base[8]= (V15);
	{object V19;
	V19= cdr((VV[0]->s.s_dbind));
	 vs_top=base+9;
	 while(!endp(V19))
	 {vs_push(car(V19));V19=cdr(V19);}
	vs_base=base+9;}
	super_funcall_no_event(base[8]);
	vs_top=sup;
T92:;
	V18= cdr((V18));
	(VV[0]->s.s_dbind)= car((V18));
	goto T85;}
T81:;
	{object V20;
	V20= Cnil;
T105:;
	if(!(endp(symbol_value(VV[24])))){
	goto T107;}
	goto T103;
T107:;
	V20= car(symbol_value(VV[24]));
	{object V21;
	V21= car(symbol_value(VV[24]));
	setq(VV[24],cdr(symbol_value(VV[24])));}
	{object V22;
	V22= (V20);
	 vs_top=base+7;
	 while(!endp(V22))
	 {vs_push(car(V22));V22=cdr(V22);}
	vs_base=base+7;}
	(void) (*Lnk245)();
	vs_top=sup;
	goto T105;}
T103:;
	{object V23;
	object V24;
	V23= symbol_value(VV[25]);
	V24= car((V23));
T122:;
	if(!(endp((V23)))){
	goto T123;}
	goto T118;
T123:;
	{object V25;
	V25= (V24);
	 vs_top=base+8;
	 while(!endp(V25))
	 {vs_push(car(V25));V25=cdr(V25);}
	vs_base=base+8;}
	(void) (*Lnk265)();
	vs_top=sup;
	V23= cdr((V23));
	V24= car((V23));
	goto T122;}
T118:;
	{object V26;
	object V27;
	V26= (VV[13]->s.s_dbind);
	V27= car((V26));
T138:;
	if(!(endp((V26)))){
	goto T139;}
	goto T134;
T139:;
	(void)((*(LnkLI266))((V27)));
	V26= cdr((V26));
	V27= car((V26));
	goto T138;}
T134:;
	{object V28;
	object V29;
	V28= symbol_value(VV[26]);
	V29= car((V28));
T153:;
	if(!(endp((V28)))){
	goto T154;}
	goto T149;
T154:;
	princ_str("\nstatic LC",VV[27]);
	V30= structure_ref((V29),VV[28],3);
	(void)((*(LnkLI267))(/* INLINE-ARGS */V30));
	princ_str("();",VV[27]);
	V28= cdr((V28));
	V29= car((V28));
	goto T153;}
T149:;
	{object V31;
	object V32;
	V31= symbol_value(VV[29]);
	V32= car((V31));
T171:;
	if(!(endp((V31)))){
	goto T172;}
	goto T167;
T172:;
	princ_str("\n#define VM",VV[27]);
	(void)((*(LnkLI267))(car((V32))));
	princ_char(32,VV[27]);
	(void)((*(LnkLI267))(cdr((V32))));
	V31= cdr((V31));
	V32= car((V31));
	goto T171;}
T167:;
	(void)((*(LnkLI268))(Cnil));
	{object V33;
	object V34;
	base[8]= (VV[18]->s.s_dbind);
	base[9]= symbol_value(VV[30]);
	base[10]= small_fixnum(1);
	vs_top=(vs_base=base+8)+3;
	(void) (*Lnk269)();
	vs_top=sup;
	V33= vs_base[0];
	V34= small_fixnum(0);
T194:;
	if(!(number_compare((V34),(V33))>=0)){
	goto T195;}
	goto T187;
T195:;
	(void)((*(LnkLI268))(Cnil));
	V34= one_plus((V34));
	goto T194;}
T187:;
	princ_str("\nstatic char * VVi[",VV[27]);
	V35= number_plus(small_fixnum(1),symbol_value(VV[30]));
	(void)((*(LnkLI267))(/* INLINE-ARGS */V35));
	princ_str("]={",VV[27]);
	princ_str("\n#define Cdata VV[",VV[27]);
	(void)((*(LnkLI267))(symbol_value(VV[30])));
	princ_char(93,VV[27]);
	if((VV[17]->s.s_dbind)!=Cnil){
	goto T211;}
	princ_char(10,VV[27]);
	(void)((*(LnkLI267))(small_fixnum(0)));
T211:;
	{register object V36;
	V36= nreverse((VV[17]->s.s_dbind));
T217:;
	if(((V36))!=Cnil){
	goto T218;}
	princ_str("\n};",VV[27]);
	goto T214;
T218:;
	princ_str("\n(char *)(",VV[27]);
	(void)((*(LnkLI267))(caar((V36))));
	(void)((*(LnkLI267))(cadar((V36))));
	if((cdr((V36)))==Cnil){
	goto T230;}
	V37= VV[31];
	goto T228;
T230:;
	V37= VV[32];
T228:;
	(void)((*(LnkLI267))(V37));
	V36= cdr((V36));
	goto T217;}
T214:;
	princ_str("\n#define VV ((object *)VVi)",VV[27]);
	vs_base=vs_top;
	(void) (*Lnk270)();
	vs_top=sup;
	{object V38;
	object V39;
	V38= (VV[13]->s.s_dbind);
	V39= car((V38));
T241:;
	if(!(endp((V38)))){
	goto T242;}
	{object V40 = Cnil;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	VMR2(V40)}
T242:;
	{register object V41;
	register object V42;
	V41= cadr((V39));
	V42= caddr((V39));
	if(!(((V42))==(VV[33]))){
	goto T251;}
	princ_str("\nstatic object *Lclptr",VV[27]);
	(void)((*(LnkLI267))((V41)));
	princ_char(59,VV[27]);
	V42= VV[34];
	goto T249;
T251:;
	if(((V42))==Cnil){
	goto T260;}
	V42= (*(LnkLI271))((V42));
	goto T258;
T260:;
	V42= VV[35];
T258:;
T249:;
	princ_str("\nstatic ",VV[27]);
	(void)((*(LnkLI267))((V42)));
	princ_str(" LnkT",VV[27]);
	(void)((*(LnkLI267))((V41)));
	princ_str("() ;",VV[27]);
	princ_str("\nstatic ",VV[27]);
	(void)((*(LnkLI267))((V42)));
	princ_str(" (*Lnk",VV[27]);
	(void)((*(LnkLI267))((V41)));
	princ_str(")() = LnkT",VV[27]);
	(void)((*(LnkLI267))((V41)));
	princ_char(59,VV[27]);}
	V38= cdr((V38));
	V39= car((V38));
	goto T241;}}
}
/*	local entry for function MAYBE-EVAL	*/

static object LI3(V45,V46)

object V45;register object V46;
{	 VMB3 VMS3 VMV3
TTL:;
	if((V45)!=Cnil){
	goto T280;}
	base[0]= car((V46));
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk272)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T281;}
	goto T280;
T281:;
	V45= get(car((V46)),VV[36],Cnil);
T280:;
	if(((V45))==Cnil){
	goto T287;}
	if((VV[37])==(symbol_value(VV[38]))){
	goto T285;}
T287:;
	if(!(type_of(symbol_value(VV[38]))==t_cons)){
	goto T286;}
	{register object x= VV[39],V47= symbol_value(VV[38]);
	while(!endp(V47))
	if(eql(x,V47->c.c_car)){
	goto T293;
	}else V47=V47->c.c_cdr;
	goto T286;}
T293:;
T285:;
	if(((V46))==Cnil){
	goto T294;}
	base[0]= (V46);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk273)();
	vs_top=sup;
T294:;
	{object V48 = Ct;
	VMR3(V48)}
T286:;
	{object V49 = Cnil;
	VMR3(V49)}
}
/*	function definition for T1EVAL-WHEN	*/

static L4()
{register object *base=vs_base;
	register object *sup=base+VM4; VC4
	vs_reserve(VM4);
	bds_check;
	{register object V50;
	check_arg(1);
	V50=(base[0]);
	vs_top=sup;
TTL:;
	{register object V51;
	register object V52;
	V51= Cnil;
	V52= Cnil;
	if(!(endp((V50)))){
	goto T300;}
	(void)((*(LnkLI274))(VV[40],small_fixnum(1),small_fixnum(0)));
T300:;
	{register object V53;
	register object V54;
	V53= car((V50));
	V54= car((V53));
T307:;
	if(!(endp((V53)))){
	goto T308;}
	goto T303;
T308:;
	{object V55= (V54);
	if((V55!= VV[275]))goto T313;
	V51= Ct;
	goto T312;
T313:;
	if((V55!= VV[39]))goto T315;
	V52= Ct;
	goto T312;
T315:;
	if((V55!= VV[276]))goto T317;
	goto T312;
T317:;
	(void)((VFUN_NARGS=2,(*(LnkLI253))(VV[41],(V54))));}
T312:;
	V53= cdr((V53));
	V54= car((V53));
	goto T307;}
T303:;
	base[1]= car((V50));
	bds_bind(VV[38],base[1]);
	if(((V51))==Cnil){
	goto T325;}
	base[2]= (*(LnkLI277))(cdr((V50)));
	vs_top=(vs_base=base+2)+1;
	bds_unwind1;
	return;
T325:;
	if(((V52))==Cnil){
	goto T328;}
	base[2]= make_cons(VV[42],cdr((V50)));
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk273)();
	bds_unwind1;
	return;
T328:;
	base[2]= Cnil;
	vs_top=(vs_base=base+2)+1;
	bds_unwind1;
	return;}
	}
}
/*	local entry for function T1PROGN	*/

static object LI5(V57)

object V57;
{	 VMB5 VMS5 VMV5
	bds_check;
TTL:;
	if(!(equal(car((V57)),VV[43]))){
	goto T332;}
	bds_bind(VV[44],Ct);
	{object V58 = (*(LnkLI277))(cdr((V57)));
	bds_unwind1;
	VMR5(V58)}
T332:;
	{register object V59;
	register object V60;
	V59= (V57);
	V60= car((V59));
T337:;
	if(!(endp((V59)))){
	goto T338;}
	{object V61 = Cnil;
	VMR5(V61)}
T338:;
	base[1]= (V60);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk259)();
	vs_top=sup;
	V59= cdr((V59));
	V60= car((V59));
	goto T337;}
}
/*	local entry for function CMPFIX-ARGS	*/

static object LI6(V64,V65)

object V64;object V65;
{	 VMB6 VMS6 VMV6
TTL:;
	{register object V66;
	register object V67;
	V66= Cnil;
	base[1]= cadr((V64));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk263)();
	vs_top=sup;
	V67= vs_base[0];
	{register object V68;
	register object V69;
	V68= (V65);
	V69= car((V68));
T356:;
	if(!(endp((V68)))){
	goto T357;}
	goto T352;
T357:;
	{register object x= car((V69)),V70= (V67);
	while(!endp(V70))
	if(eql(x,V70->c.c_car)){
	V66= V70;
	goto T362;
	}else V70=V70->c.c_cdr;
	V66= Cnil;}
T362:;
	if((V66)==Cnil){
	goto T363;}
	{register object V71;
	register object V72;
	V71= (V66);
	V72= cadr((V69));
	if(type_of((V71))!=t_cons)FEwrong_type_argument(Scons,(V71));
	((V71))->c.c_car = (V72);}
T363:;
	V68= cdr((V68));
	V69= car((V68));
	goto T356;}
T352:;
	{register object x= VV[45],V73= (V67);
	while(!endp(V73))
	if(eql(x,V73->c.c_car)){
	V66= V73;
	goto T376;
	}else V73=V73->c.c_cdr;
	V66= Cnil;}
T376:;
	if(((V66))==Cnil){
	goto T374;}
	{object V75;
	V75= append((V65),cdr((V66)));
	if(type_of(V66)!=t_cons)FEwrong_type_argument(Scons,V66);
	(V66)->c.c_cdr = (V75);
	goto T372;}
T374:;
	V76= make_cons(VV[45],(V65));
	V67= append((V67),/* INLINE-ARGS */V76);
T372:;
	{object V77 = listA(3,car((V64)),(V67),cddr((V64)));
	VMR6(V77)}}
}
/*	local entry for function T1DEFUN	*/

static object LI7(V79)

object V79;
{	 VMB7 VMS7 VMV7
	bds_check;
TTL:;
	{object V80;
	V80= symbol_value(VV[46]);
	bds_bind(VV[48],Cnil);
	if(endp((V79))){
	goto T382;}
	if(!(endp(cdr((V79))))){
	goto T381;}
T382:;
	V82 = make_fixnum(length((V79)));
	(void)((*(LnkLI274))(VV[47],small_fixnum(2),V82));
T381:;
	if(type_of(car((V79)))==t_symbol){
	goto T386;}
	(void)((VFUN_NARGS=2,(*(LnkLI253))(VV[49],car((V79)))));
T386:;
	V83= make_cons(VV[47],(V79));
	(void)((*(LnkLI255))(Cnil,/* INLINE-ARGS */V83));
T391:;
	setq(VV[6],Ct);
	setq(VV[50],Cnil);
	{register object V84;
	object V85;
	object V86;
	register object V87;{object V88;
	V88= get(car((V79)),VV[56],Cnil);
	if(V88==Cnil)goto T398;
	V85= V88;
	goto T397;
T398:;}
	setq(VV[57],number_plus(symbol_value(VV[57]),small_fixnum(1)));
	V85= symbol_value(VV[57]);
T397:;
	V87= car((V79));
	bds_bind(VV[51],Cnil);
	bds_bind(VV[52],Cnil);
	bds_bind(VV[53],Cnil);
	bds_bind(VV[54],Cnil);
	V84= Cnil;
	bds_bind(VV[55],Cnil);
	V86= Cnil;
	V84= (VFUN_NARGS=2,(*(LnkLI278))(cdr((V79)),(V87)));{object V89;
	base[6]= (V80);
	base[7]= symbol_value(VV[46]);
	vs_top=(vs_base=base+6)+2;
	(void) (*Lnk279)();
	vs_top=sup;
	V89= vs_base[0];
	if(V89==Cnil)goto T405;
	goto T404;
T405:;}
	(void)(structure_set(cadr((V84)),VV[58],4,Ct));
T404:;
	V90= structure_ref(cadr((V84)),VV[58],1);
	(void)((*(LnkLI280))(/* INLINE-ARGS */V90));
	if((get((V87),VV[59],Cnil))==Cnil){
	goto T410;}
	{object V91;
	V91= make_fixnum(length(car(caddr((V84)))));
	(void)(sputprop((V87),VV[59],(V91)));
	base[6]= (V91);
	base[7]= VV[61];
	base[8]= Ct;
	vs_top=(vs_base=base+6)+3;
	(void) (*Lnk282)();
	vs_top=sup;
	V92= vs_base[0];
	V93= list(4,VV[60],(V87),V92,Ct);
	(void)((*(LnkLI281))(/* INLINE-ARGS */V93));}
T410:;
	if((get((V87),VV[62],Cnil))==Cnil){
	goto T421;}
	{object V94;
	register object V95;
	V94= caddr((V84));
	V95= Cnil;
	base[6]= cadr((V94));
	vs_top=(vs_base=base+6)+1;
	(void) (*Lnk283)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T426;}
	goto T421;
T426:;
	base[6]= caddr((V94));
	vs_top=(vs_base=base+6)+1;
	(void) (*Lnk283)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T429;}
	goto T421;
T429:;
	base[6]= cadddr((V94));
	vs_top=(vs_base=base+6)+1;
	(void) (*Lnk283)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T432;}
	goto T421;
T432:;
	base[6]= make_fixnum(length(car((V94))));
	base[7]= small_fixnum(64);
	vs_top=(vs_base=base+6)+2;
	(void) (*Lnk284)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T435;}
	goto T421;
T435:;
	{register object V96;
	register object V97;
	object V98;
	V96= car((V94));
	V97= get((V87),VV[63],Cnil);
	V98= Cnil;
T444:;
	if(!(endp((V96)))){
	goto T445;}
	base[6]= (V97);
	vs_top=(vs_base=base+6)+1;
	(void) (*Lnk285)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T448;}
	goto T440;
T448:;
	if(((V95))==Cnil){
	goto T452;}
	V79= (*(LnkLI286))((V79),(V95));
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	goto T391;
T452:;
	base[6]= (V98);
	vs_top=(vs_base=base+6)+1;
	(void) (*Lnk287)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T439;}
	goto T440;
T445:;
	{register object V99;
	V99= car((V96));
	if(!(equal(car((V97)),VV[64]))){
	goto T460;}
	goto T440;
T460:;
	V100= structure_ref((V99),VV[65],1);
	if((/* INLINE-ARGS */V100)==(VV[66])){
	goto T466;}
	V101= structure_ref((V99),VV[65],1);
	if(!((/* INLINE-ARGS */V101)==(VV[67]))){
	goto T465;}
	if(!((car((V97)))==(Ct))){
	goto T465;}
T466:;
	if((structure_ref((V99),VV[65],3))!=Cnil){
	goto T465;}
	V102= structure_ref((V99),VV[65],4);
	if(!((/* INLINE-ARGS */V102)==(VV[68]))){
	goto T464;}
T465:;
	V103= structure_ref((V99),VV[65],0);
	vs_base=vs_top;
	(void) (*Lnk288)();
	vs_top=sup;
	V104= vs_base[0];
	V105= list(2,/* INLINE-ARGS */V103,V104);
	V95= make_cons(/* INLINE-ARGS */V105,(V95));
T464:;
	V106= car((V97));
	V107= structure_ref((V99),VV[65],5);
	if(((*(LnkLI289))(/* INLINE-ARGS */V106,/* INLINE-ARGS */V107))==Cnil){
	goto T463;}
	{register object x= car((V97)),V108= VV[69];
	while(!endp(V108))
	if(eql(x,V108->c.c_car)){
	goto T458;
	}else V108=V108->c.c_cdr;}
	V109= structure_ref((V99),VV[65],4);
	if((/* INLINE-ARGS */V109)==(VV[70])){
	goto T458;}
	if((symbol_value(VV[71]))!=Cnil){
	goto T458;}
	V111= structure_ref(cadr((V84)),VV[58],0);
	{register object x= (V99),V110= /* INLINE-ARGS */V111;
	while(!endp(V110))
	if(eql(x,V110->c.c_car)){
	goto T487;
	}else V110=V110->c.c_cdr;
	goto T458;}
T487:;
T463:;
	if(((V95))!=Cnil){
	goto T488;}
	V112= structure_ref((V99),VV[65],0);
	(void)((VFUN_NARGS=3,(*(LnkLI254))(VV[72],(V87),/* INLINE-ARGS */V112)));
T488:;
	V98= Ct;}
T458:;
	V96= cdr((V96));
	V97= cdr((V97));
	goto T444;}
T440:;
	goto T421;
T439:;
	base[6]= (V85);
	vs_top=(vs_base=base+6)+1;
	(void) (*Lnk290)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T421;}}
	V113= get((V87),VV[63],Cnil);
	V114= get((V87),VV[74],Cnil);
	V115= get((V87),VV[63],Cnil);
	V116= list(5,(V87),V113,V114,small_fixnum(3),(*(LnkLI291))((V85),V115));
	setq(VV[73],make_cons(/* INLINE-ARGS */V116,symbol_value(VV[73])));
	goto T419;
T421:;
	{object V117;
	base[6]= get((V87),VV[74],Cnil);
	base[7]= Ct;
	vs_top=(vs_base=base+6)+2;
	(void) (*Lnk292)();
	vs_top=sup;
	V117= vs_base[0];
	if(((V117))==Cnil){
	goto T419;}}
T419:;
	if((cadddr((V84)))==Cnil){
	goto T506;}
	V86= cadddr((V84));
T506:;
	(void)((*(LnkLI293))());
	V118= list(6,VV[47],(V87),(V85),(V84),(V86),(VV[55]->s.s_dbind));
	setq(VV[20],make_cons(/* INLINE-ARGS */V118,symbol_value(VV[20])));
	V119= make_cons((V87),(V85));
	setq(VV[75],make_cons(/* INLINE-ARGS */V119,symbol_value(VV[75])));
	V120= symbol_value(VV[75]);
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;}
	{object V121 = Cnil;
	bds_unwind1;
	VMR7(V121)}}
}
/*	local entry for function MAKE-INLINE-STRING	*/

static object LI8(V124,V125)

object V124;object V125;
{	 VMB8 VMS8 VMV8
TTL:;
	if(((V125))!=Cnil){
	goto T515;}
	base[0]= Cnil;
	base[1]= VV[76];
	base[2]= (V124);
	vs_top=(vs_base=base+0)+3;
	(void) (*Lnk294)();
	vs_top=sup;
	{object V126 = vs_base[0];
	VMR8(V126)}
T515:;
	{register object V127;
	V127= (VFUN_NARGS=7,(*(LnkLI295))(small_fixnum(100),VV[77],VV[78],VV[79],small_fixnum(0),VV[80],Ct));
	base[0]= (V127);
	base[1]= VV[81];
	base[2]= (V124);
	vs_top=(vs_base=base+0)+3;
	(void) (*Lnk294)();
	vs_top=sup;
	{register object V128;
	register int V129;
	V129= 0;
	V128= (V125);
T528:;
	if(!(endp(cdr((V128))))){
	goto T529;}
	base[0]= (V127);
	base[1]= VV[82];
	base[2]= make_fixnum(V129);
	vs_top=(vs_base=base+0)+3;
	(void) (*Lnk294)();
	vs_top=sup;
	goto T525;
T529:;
	base[0]= (V127);
	base[1]= VV[83];
	base[2]= make_fixnum(V129);
	vs_top=(vs_base=base+0)+3;
	(void) (*Lnk294)();
	vs_top=sup;
	V128= cdr((V128));
	V129= (V129)+1;
	goto T528;}
T525:;
	{object V130 = (V127);
	VMR8(V130)}}
}
/*	local entry for function CS-PUSH	*/

static object LI9(va_alist)
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB9 VMS9 VMV9
	{object V131;
	narg = narg - 0;
	if (narg <= 0) goto T544;
	else {
	va_start(ap);
	V131= va_arg(ap,object);}
	--narg; goto T545;
T544:;
	V131= Cnil;
T545:;
	{object V132;
	setq(VV[84],number_plus(symbol_value(VV[84]),small_fixnum(1)));
	V132= symbol_value(VV[84]);
	if(((V131))==Cnil){
	goto T553;}
	V133= make_cons((V131),(V132));
	goto T551;
T553:;
	V133= (V132);
T551:;
	setq(VV[14],make_cons(V133,symbol_value(VV[14])));
	{object V134 = (V132);
	VMR9(V134)}}}
	}
/*	local entry for function F-TYPE	*/

static int LI10(V136)

register object V136;
{	 VMB10 VMS10 VMV10
TTL:;
	base[0]= (V136);
	base[1]= VV[65];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk296)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T555;}
	V136= structure_ref((V136),VV[65],5);
T555:;
	if(((V136))==Cnil){
	goto T562;}
	base[0]= (V136);
	base[1]= VV[85];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk297)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T562;}
	{int V137 = 1;
	VMR10(V137)}
T562:;
	{int V138 = 0;
	VMR10(V138)}
}
/*	local entry for function PROCLAIMED-ARGD	*/

static int LI11(V141,V142)

register object V141;object V142;
{	 VMB11 VMS11 VMV11
TTL:;
	{register int V143;
	register int V144;
	register object V145;
	register object V146;
	V143= length((V141));
	V144= 8;
	V145= make_fixnum((*(LnkLI298))((V142)));
	V146= Ct;
T572:;
	if(eql(small_fixnum(0),(V145))){
	goto T574;}
	V143= (V143)+(((fix((V145))) << (V144)));
T574:;
	if(((V146))==Cnil){
	goto T578;}
	V144= 10;
	V146= Cnil;
T578:;
	if(((V141))!=Cnil){
	goto T584;}
	{int V147 = V143;
	VMR11(V147)}
T584:;
	V144= (V144)+(2);
	{register object V149;
	V149= car((V141));
	V141= cdr((V141));
	V148= (V149);}
	V145= make_fixnum((*(LnkLI298))(V148));
	goto T572;}
}
/*	local entry for function WT-IF-PROCLAIMED	*/

static object LI12(V153,V154,V155)

register object V153;object V154;object V155;
{	 VMB12 VMS12 VMV12
TTL:;
	if(((VFUN_NARGS=1,(*(LnkLI300))((V153))))==Cnil){
	goto T596;}
	{register object x= (V153),V156= symbol_value(VV[73]);
	while(!endp(V156))
	if(type_of(V156->c.c_car)==t_cons &&eql(x,V156->c.c_car->c.c_car)){
	goto T600;
	}else V156=V156->c.c_cdr;
	goto T599;}
T600:;
	V157= list(2,VV[87],(V153));
	V158= (*(LnkLI302))(VV[88],(V154));
	V159= get((V153),VV[63],Cnil);
	V160= get((V153),VV[74],Cnil);
	V161 = make_fixnum((*(LnkLI303))(V159,V160));
	V162= list(4,VV[86],/* INLINE-ARGS */V157,/* INLINE-ARGS */V158,V161);
	(void)((VFUN_NARGS=1,(*(LnkLI301))(/* INLINE-ARGS */V162)));
	{object V163 = Ct;
	VMR12(V163)}
T599:;
	{register object V164;
	register object V165;
	object V166;
	V164= make_fixnum(length(car(caddr((V155)))));
	V167= get((V153),VV[63],Cnil);
	V165= make_fixnum(length(V167));
	V169= get((V153),VV[63],Cnil);
	{register object x= VV[64],V168= V169;
	while(!endp(V168))
	if(eql(x,V168->c.c_car)){
	V166= V168;
	goto T608;
	}else V168=V168->c.c_cdr;
	V166= Cnil;}
T608:;
	if(((V166))==Cnil){
	goto T611;}{object V170;
	base[0]= (V164);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk304)();
	vs_top=sup;
	V170= vs_base[0];
	if(V170==Cnil)goto T613;
	goto T604;
T613:;}{object V171;
	V172 = make_fixnum(length((V166)));
	V171= number_minus((V165),V172);
	if(V171==Cnil)goto T616;
	goto T604;
T616:;}
	V173 = make_fixnum(length((V166)));
	V174= number_minus((V165),V173);
	(void)((VFUN_NARGS=4,(*(LnkLI254))(VV[89],(V153),/* INLINE-ARGS */V174,(V164))));
	goto T604;
T611:;
	if(eql((V164),(V165))){
	goto T619;}
	(void)((VFUN_NARGS=4,(*(LnkLI254))(VV[90],(V153),(V165),(V164))));
	goto T604;
T619:;
	(void)((VFUN_NARGS=2,(*(LnkLI254))(VV[91],(V153))));}
T604:;
	{object V175 = Cnil;
	VMR12(V175)}
T596:;
	{object V176 = Cnil;
	VMR12(V176)}
}
/*	local entry for function VOLATILE	*/

static object LI13(V178)

object V178;
{	 VMB13 VMS13 VMV13
TTL:;
	if((structure_ref((V178),VV[58],4))==Cnil){
	goto T622;}
	{object V179 = VV[92];
	VMR13(V179)}
T622:;
	{object V180 = VV[93];
	VMR13(V180)}
}
/*	local entry for function REGISTER	*/

static object LI14(V182)

object V182;
{	 VMB14 VMS14 VMV14
TTL:;
	if(!(equal(symbol_value(VV[16]),VV[94]))){
	goto T625;}
	{int V183= fix(structure_ref((V182),VV[65],6));
	if(!((/* INLINE-ARGS */V183)>=(fix(symbol_value(VV[95]))))){
	goto T625;}}
	{object V184 = VV[96];
	VMR14(V184)}
T625:;
	{object V185 = VV[97];
	VMR14(V185)}
}
/*	local entry for function VARARG-P	*/

static object LI15(V187)

object V187;
{	 VMB15 VMS15 VMV15
TTL:;
	base[0]= get((V187),VV[74],Cnil);
	base[1]= Ct;
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk305)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T629;}
	{object V188 = Cnil;
	VMR15(V188)}
T629:;
	{register object V189;
	V189= get((V187),VV[63],Cnil);
T635:;
	if(((V189))!=Cnil){
	goto T636;}
	{object V190 = Ct;
	VMR15(V190)}
T636:;{object V191;
	base[0]= (V189);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk306)();
	vs_top=sup;
	V191= vs_base[0];
	if(V191==Cnil)goto T641;
	goto T640;
T641:;}
	{object V192 = Cnil;
	VMR15(V192)}
T640:;{object V193;
	base[0]= car((V189));
	base[1]= Ct;
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk292)();
	vs_top=sup;
	V193= vs_base[0];
	if(V193==Cnil)goto T645;
	goto T644;
T645:;}{object V194;
	base[0]= car((V189));
	base[1]= VV[64];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk292)();
	vs_top=sup;
	V194= vs_base[0];
	if(V194==Cnil)goto T649;
	goto T644;
T649:;}
	{object V195 = Cnil;
	VMR15(V195)}
T644:;
	V189= cdr((V189));
	goto T635;}
}
/*	local entry for function MAXARGS	*/

static object LI16(V197)

register object V197;
{	 VMB16 VMS16 VMV16
TTL:;
	if((cadr(cddddr((V197))))!=Cnil){
	goto T656;}
	if((caddr((V197)))==Cnil){
	goto T657;}
T656:;
	{object V198 = small_fixnum(64);
	VMR16(V198)}
T657:;
	base[0]= make_fixnum(length(car((V197))));
	base[1]= make_fixnum(length(cadr((V197))));
	V199 = make_fixnum(length(car(cddddr((V197)))));
	base[2]= number_times(small_fixnum(2),V199);
	vs_top=(vs_base=base+0)+3;
	(void) (*Lnk307)();
	vs_top=sup;
	{object V200 = vs_base[0];
	VMR16(V200)}
}
/*	local entry for function ADD-ADDRESS	*/

static object LI17(V203,V204)

object V203;object V204;
{	 VMB17 VMS17 VMV17
TTL:;
	V205= list(2,(V203),(V204));
	setq(VV[17],make_cons(/* INLINE-ARGS */V205,symbol_value(VV[17])));
	{object V206;
	V206= symbol_value(VV[18]);
	setq(VV[18],number_plus(symbol_value(VV[18]),small_fixnum(1)));
	{object V207 = (V206);
	VMR17(V207)}}
}
/*	local entry for function T2DEFUN	*/

static object LI18(V213,V214,V215,V216,V217)

register object V213;register object V214;register object V215;object V216;object V217;
{	 VMB18 VMS18 VMV18
TTL:;
	if((get((V213),VV[98],Cnil))==Cnil){
	goto T668;}
	{object V218 = Cnil;
	VMR18(V218)}
T668:;
	if(((V216))==Cnil){
	goto T671;}
	V219= list(4,VV[99],list(2,VV[87],(V213)),(V216),VV[100]);
	(void)((VFUN_NARGS=1,(*(LnkLI301))(/* INLINE-ARGS */V219)));
T671:;
	{object V220;
	V220= (*(LnkLI308))((V213),(V214),(V215));
	if(((V220))==Cnil){
	goto T677;}
	goto T674;
T677:;
	if(((*(LnkLI309))((V213)))==Cnil){
	goto T680;}
	{object V221;
	V221= cadddr(caddr((V215)));
	princ_str("\nstatic object LI",VV[27]);
	(void)((*(LnkLI267))((V214)));
	princ_str("();",VV[27]);
	if(((V221))==Cnil){
	goto T688;}
	V222= list(2,VV[87],(V213));
	V223= (*(LnkLI302))(VV[102],(V214));
	V224 = make_fixnum(length(car(caddr((V215)))));
	V225= (*(LnkLI310))(caddr((V215)));
	V226= (*(LnkLI299))(/* INLINE-ARGS */V225,small_fixnum(8));
	V227= number_plus(V224,/* INLINE-ARGS */V226);
	base[0]= Cnil;
	base[1]= VV[103];
	base[2]= (V214);
	vs_top=(vs_base=base+0)+3;
	(void) (*Lnk294)();
	vs_top=sup;
	V228= vs_base[0];
	V229= list(5,VV[101],/* INLINE-ARGS */V222,/* INLINE-ARGS */V223,/* INLINE-ARGS */V227,(*(LnkLI302))(V228,VV[104]));
	(void)((VFUN_NARGS=1,(*(LnkLI301))(/* INLINE-ARGS */V229)));
	goto T674;
T688:;
	V230= list(2,VV[87],(V213));
	V231= (*(LnkLI302))(VV[106],(V214));
	V232 = make_fixnum(length(car(caddr((V215)))));
	V233= (*(LnkLI310))(caddr((V215)));
	V234= (*(LnkLI299))(/* INLINE-ARGS */V233,small_fixnum(8));
	V235= list(4,VV[105],/* INLINE-ARGS */V230,/* INLINE-ARGS */V231,number_plus(V232,/* INLINE-ARGS */V234));
	(void)((VFUN_NARGS=1,(*(LnkLI301))(/* INLINE-ARGS */V235)));
	goto T674;}
T680:;
	if(!(type_of((V214))==t_fixnum||
type_of((V214))==t_bignum||
type_of((V214))==t_ratio||
type_of((V214))==t_shortfloat||
type_of((V214))==t_longfloat||
type_of((V214))==t_complex)){
	goto T695;}
	princ_str("\nstatic L",VV[27]);
	(void)((*(LnkLI267))((V214)));
	princ_str("();",VV[27]);
	V236= list(2,VV[87],(V213));
	V237= list(3,VV[107],/* INLINE-ARGS */V236,(*(LnkLI302))(VV[108],(V214)));
	(void)((VFUN_NARGS=1,(*(LnkLI301))(/* INLINE-ARGS */V237)));
	goto T674;
T695:;
	princ_char(10,VV[27]);
	(void)((*(LnkLI267))((V214)));
	princ_str("();",VV[27]);
	V238= list(2,VV[87],(V213));
	V239= list(3,VV[107],/* INLINE-ARGS */V238,(*(LnkLI302))(VV[109],(V214)));
	(void)((VFUN_NARGS=1,(*(LnkLI301))(/* INLINE-ARGS */V239)));}
T674:;
	if(!(number_compare(symbol_value(VV[110]),small_fixnum(2))<0)){
	goto T706;}
	{object V240 = sputprop((V213),VV[111],Ct);
	VMR18(V240)}
T706:;
	{object V241 = Cnil;
	VMR18(V241)}
}
/*	local entry for function ADD-DEBUG	*/

static object LI19(V244,V245)

object V244;object V245;
{	 VMB19 VMS19 VMV19
TTL:;
	{object V246 = putprop((V244),(V245),VV[112]);
	VMR19(V246)}
}
/*	local entry for function T3DEFUN	*/

static object LI20(V252,V253,V254,V255,V256)

register object V252;register object V253;register object V254;object V255;object V256;
{	 VMB20 VMS20 VMV20
	bds_check;
TTL:;
	{register object V257;
	V257= Cnil;
	bds_bind(VV[0],list(2,VV[47],(V252)));
	bds_bind(VV[16],(*(LnkLI311))(cadr((V254))));
	bds_bind(VV[113],Cnil);
	{register object V258;
	register object V259;
	V258= symbol_value(VV[73]);
	V259= car((V258));
T718:;
	if(!(endp((V258)))){
	goto T719;}
	goto T713;
T719:;{object V260;
	base[4]= cadddr((V259));
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk312)();
	vs_top=sup;
	V260= vs_base[0];
	if(V260==Cnil)goto T724;
	goto T723;
T724:;}
	base[4]= VV[114];
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk313)();
	vs_top=sup;
T723:;
	base[4]= car((V259));
	base[5]= (V252);
	vs_top=(vs_base=base+4)+2;
	(void) (*Lnk292)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T729;}
	goto T728;
T729:;
	base[4]= cadr(cddddr((V259)));
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk287)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T733;}
	goto T728;
T733:;
	V257= (V259);
	if(((V257))==Cnil){
	goto T713;}
	goto T714;
T728:;
	V258= cdr((V258));
	V259= car((V258));
	goto T718;}
T714:;
	if(((VFUN_NARGS=1,(*(LnkLI300))((V252))))!=Cnil){
	goto T742;}
	V261= list(4,(V252),(V253),cadr((V257)),caddr((V257)));
	setq(VV[25],make_cons(/* INLINE-ARGS */V261,symbol_value(VV[25])));
T742:;
	V262= structure_ref(cadr((V254)),VV[58],1);
	(void)((*(LnkLI314))(/* INLINE-ARGS */V262,small_fixnum(0)));
	base[3]= VV[115];
	{object V263= caddr((V257));
	if((V263!= VV[85]))goto T749;
	base[4]= VV[116];
	goto T748;
T749:;
	if((V263!= VV[138]))goto T750;
	base[4]= VV[117];
	goto T748;
T750:;
	if((V263!= VV[139]))goto T751;
	base[4]= VV[118];
	goto T748;
T751:;
	if((V263!= VV[140]))goto T752;
	base[4]= VV[119];
	goto T748;
T752:;
	base[4]= VV[120];}
T748:;
	base[5]= (V252);
	base[6]= (V253);
	base[7]= (V254);
	base[8]= (V256);
	base[9]= (V257);
	vs_top=(vs_base=base+3)+7;
	(void) (*Lnk315)();
	vs_top=sup;
	goto T711;
T713:;
	if(((*(LnkLI309))((V252)))==Cnil){
	goto T759;}
	V264= structure_ref(cadr((V254)),VV[58],1);
	(void)((*(LnkLI314))(/* INLINE-ARGS */V264,small_fixnum(0)));
	base[3]= VV[121];
	base[4]= VV[120];
	base[5]= (V252);
	base[6]= (V253);
	base[7]= (V254);
	base[8]= (V256);
	vs_top=(vs_base=base+3)+6;
	(void) (*Lnk315)();
	vs_top=sup;
	goto T711;
T759:;
	V265= structure_ref(cadr((V254)),VV[58],1);
	(void)((*(LnkLI314))(/* INLINE-ARGS */V265,small_fixnum(2)));
	base[3]= VV[122];
	base[4]= VV[123];
	base[5]= (V252);
	base[6]= (V253);
	base[7]= (V254);
	base[8]= (V256);
	vs_top=(vs_base=base+3)+6;
	(void) (*Lnk315)();
	vs_top=sup;
T711:;
	(void)((*(LnkLI316))((V253)));
	{object V266 = (*(LnkLI317))((V252),(V254));
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	VMR20(V266)}}
}
/*	function definition for T3DEFUN-AUX	*/

static L21()
{register object *base=vs_base;
	register object *sup=base+VM21; VC21
	vs_reserve(VM21);
	bds_check;
	{object V267;
	object V268;
	if(vs_top-vs_base<2) too_few_arguments();
	V267=(base[0]);
	bds_bind(VV[124],base[1]);
	vs_base=vs_base+2;
	vs_top[0]=Cnil;
	{object *p=vs_top;
	 for(;p>vs_base;p--)p[-1]=MMcons(p[-1],p[0]);}
	V268=(base[2]);
	vs_top=sup;
	bds_bind(VV[14],Cnil);
	bds_bind(VV[125],small_fixnum(0));
	bds_bind(VV[126],small_fixnum(0));
	bds_bind(VV[127],small_fixnum(0));
	bds_bind(VV[128],small_fixnum(0));
	bds_bind(VV[129],Cnil);
	bds_bind(VV[130],make_cons((VV[124]->s.s_dbind),Cnil));
	bds_bind(VV[131],(VV[124]->s.s_dbind));
	setq(VV[133],number_plus(symbol_value(VV[133]),small_fixnum(1)));
	bds_bind(VV[132],symbol_value(VV[133]));
	bds_bind(VV[134],Cnil);
	bds_bind(VV[135],Cnil);
	bds_bind(VV[136],Cnil);
	bds_bind(VV[137],small_fixnum(0));
	base[16]= (V267);
	{object V269;
	V269= (V268);
	 vs_top=base+17;
	 while(!endp(V269))
	 {vs_push(car(V269));V269=cdr(V269);}
	vs_base=base+17;}
	super_funcall_no_event(base[16]);
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	return;
	}
}
/*	local entry for function T3DEFUN-LOCAL-ENTRY	*/

static object LI22(V275,V276,V277,V278,V279)

object V275;object V276;object V277;object V278;object V279;
{	 VMB22 VMS22 VMV22
	bds_check;
TTL:;
	{object V280;
	object V281;
	V280= Cnil;
	V281= caaddr((V277));
	{register object V282;
	object V283;
	V283= cadr((V279));
	V282= (V281);
T786:;
	if(!(endp((V282)))){
	goto T787;}
	goto T783;
T787:;
	V284= structure_ref(car((V282)),VV[65],1);
	if(!((/* INLINE-ARGS */V284)==(VV[67]))){
	goto T793;}
	V285= car((V282));
	V286= structure_ref(car((V282)),VV[65],4);
	V287= make_cons(/* INLINE-ARGS */V285,/* INLINE-ARGS */V286);
	V280= make_cons(/* INLINE-ARGS */V287,(V280));
	goto T791;
T793:;
	V288= car((V282));
	{object V290= car((V283));
	if((V290!= VV[85]))goto T797;
	V289= VV[85];
	goto T796;
T797:;
	if((V290!= VV[138]))goto T798;
	V289= VV[138];
	goto T796;
T798:;
	if((V290!= VV[139]))goto T799;
	V289= VV[139];
	goto T796;
T799:;
	if((V290!= VV[140]))goto T800;
	V289= VV[140];
	goto T796;
T800:;
	V289= VV[70];}
T796:;
	(void)(structure_set(/* INLINE-ARGS */V288,VV[65],1,V289));
T791:;
	V291= car((V282));
	setq(VV[84],number_plus(symbol_value(VV[84]),small_fixnum(1)));
	(void)(structure_set(/* INLINE-ARGS */V291,VV[65],4,symbol_value(VV[84])));
	V282= cdr((V282));
	V283= cdr((V283));
	goto T786;}
T783:;
	(void)((VFUN_NARGS=2,(*(LnkLI318))(VV[141],(V275))));
	princ_str("\nstatic ",VV[27]);
	V292= (*(LnkLI271))(caddr((V279)));
	(void)((*(LnkLI267))(/* INLINE-ARGS */V292));
	princ_str("LI",VV[27]);
	(void)((*(LnkLI267))((V276)));
	princ_str("();",VV[27]);
	princ_str("\nstatic ",VV[21]);
	V293= (*(LnkLI271))(caddr((V279)));
	(void)((*(LnkLI264))(/* INLINE-ARGS */V293));
	princ_str("LI",VV[21]);
	(void)((*(LnkLI264))((V276)));
	princ_char(40,VV[21]);
	(void)((*(LnkLI319))((V281),cadr((V279))));
	{object V294;
	V294= symbol_value(VV[132]);
	if((symbol_value(VV[143]))==Cnil){
	goto T824;}
	base[1]= make_cons((V275),(V281));
	goto T822;
T824:;
	base[1]= Cnil;
T822:;
	bds_bind(VV[142],base[1]);
	bds_bind(VV[130],symbol_value(VV[130]));
	princ_str("\n{	",VV[21]);
	V295= structure_ref(cadr((V277)),VV[58],1);
	(void)((*(LnkLI320))(/* INLINE-ARGS */V295,(V276),VV[144]));
	princ_str(" VMB",VV[21]);
	(void)((*(LnkLI264))((V294)));
	princ_str(" VMS",VV[21]);
	(void)((*(LnkLI264))((V294)));
	princ_str(" VMV",VV[21]);
	(void)((*(LnkLI264))((V294)));
	if(((V278))==Cnil){
	goto T836;}
	princ_str("\n	bds_check;",VV[21]);
T836:;
	if((symbol_value(VV[145]))==Cnil){
	goto T840;}
	princ_str("\n	ihs_check;",VV[21]);
T840:;
	if(((VV[142]->s.s_dbind))==Cnil){
	goto T844;}
	(VV[130]->s.s_dbind)= make_cons(VV[146],(VV[130]->s.s_dbind));
	princ_str("\nTTL:;",VV[21]);
T844:;
	{register object V296;
	register object V297;
	V296= (V280);
	V297= car((V296));
T854:;
	if(!(endp((V296)))){
	goto T855;}
	goto T850;
T855:;
	princ_str("\n	bds_bind(VV[",VV[21]);
	(void)((*(LnkLI264))(cdr((V297))));
	princ_str("],V",VV[21]);
	V298= structure_ref(car((V297)),VV[65],4);
	(void)((*(LnkLI264))(/* INLINE-ARGS */V298));
	princ_str(");",VV[21]);
	(VV[130]->s.s_dbind)= make_cons(VV[147],(VV[130]->s.s_dbind));
	(void)(structure_set(car((V297)),VV[65],1,VV[67]));
	(void)(structure_set(car((V297)),VV[65],4,cdr((V297))));
	V296= cdr((V296));
	V297= car((V296));
	goto T854;}
T850:;
	base[3]= caddr(cddr((V277)));
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk321)();
	vs_top=sup;
	princ_str("\n}",VV[21]);
	{object V299 = (*(LnkLI322))((V294),caddr((V279)));
	bds_unwind1;
	bds_unwind1;
	VMR22(V299)}}}
}
/*	local entry for function SET-UP-VAR-CVS	*/

static object LI23(V301)

object V301;
{	 VMB23 VMS23 VMV23
TTL:;
	if((symbol_value(VV[148]))==Cnil){
	goto T879;}
	V302= (*(LnkLI323))();
	{object V303 = structure_set((V301),VV[65],2,/* INLINE-ARGS */V302);
	VMR23(V303)}
T879:;
	V304= (*(LnkLI324))();
	{object V305 = structure_set((V301),VV[65],2,/* INLINE-ARGS */V304);
	VMR23(V305)}
}
/*	local entry for function T3DEFUN-VARARG	*/

static object LI24(V310,V311,V312,V313)

object V310;object V311;object V312;object V313;
{	 VMB24 VMS24 VMV24
	bds_check;
TTL:;
	{object V314;
	register object V315;
	object V316;
	object V317;
	object V318;
	object V319;
	object V320;
	object V321;
	V314= Cnil;
	bds_bind(VV[148],Cnil);
	base[1]= Cnil;
	V315= Cnil;
	V316= Ct;
	V317= Cnil;
	bds_bind(VV[149],small_fixnum(0));
	V318= Cnil;
	V319= caddr((V312));
	V320= Cnil;{object V322;
	V322= caddr((V319));
	if(V322==Cnil)goto T889;
	V321= V322;
	goto T888;
T889:;}{object V323;
	V323= cadr((V319));
	if(V323==Cnil)goto T891;
	V321= V323;
	goto T888;
T891:;}
	V321= cadddr((V319));
T888:;
	{object V324;
	register object V325;
	V324= car((V319));
	V325= car((V324));
T897:;
	if(!(endp((V324)))){
	goto T898;}
	goto T893;
T898:;
	setq(VV[84],number_plus(symbol_value(VV[84]),small_fixnum(1)));
	V326= list(2,VV[150],symbol_value(VV[84]));
	V314= make_cons(/* INLINE-ARGS */V326,(V314));
	V324= cdr((V324));
	V325= car((V324));
	goto T897;}
T893:;
	(void)((VFUN_NARGS=2,(*(LnkLI318))(VV[151],(V310))));
	princ_str("\nstatic object LI",VV[27]);
	(void)((*(LnkLI267))((V311)));
	princ_str("();",VV[27]);
	princ_str("\nstatic object LI",VV[21]);
	(void)((*(LnkLI264))((V311)));
	princ_char(40,VV[21]);
	(void)((*(LnkLI325))((V314)));
	if(((V321))==Cnil){
	goto T920;}
	if(((V314))==Cnil){
	goto T923;}
	princ_char(44,VV[21]);
T923:;
	princ_str("va_alist",VV[21]);
T920:;
	princ_char(41,VV[21]);
	if(((V314))==Cnil){
	goto T930;}
	princ_str("\n	object ",VV[21]);
	(void)((*(LnkLI325))((V314)));
	princ_char(59,VV[21]);
T930:;
	if(((V321))==Cnil){
	goto T937;}
	princ_str("\n	va_dcl ",VV[21]);
T937:;
	{object V327;
	V327= symbol_value(VV[132]);
	if(symbol_value(VV[143])==Cnil){
	base[5]= Cnil;
	goto T942;}
	base[7]= caddr((V319));
	vs_top=(vs_base=base+7)+1;
	(void) (*Lnk287)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T943;}
	base[5]= Cnil;
	goto T942;
T943:;
	{object V328;
	object V329;
	V328= car((V319));
	V329= car((V328));
T951:;
	if(!(endp((V328)))){
	goto T952;}
	goto T946;
T952:;
	if((structure_ref((V329),VV[65],3))==Cnil){
	goto T956;}
	goto T947;
T956:;
	V328= cdr((V328));
	V329= car((V328));
	goto T951;}
T947:;
	base[5]= Cnil;
	goto T942;
T946:;
	base[7]= cadr((V319));
	vs_top=(vs_base=base+7)+1;
	(void) (*Lnk283)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T964;}
	base[5]= Cnil;
	goto T942;
T964:;
	base[7]= car(cddddr((V319)));
	vs_top=(vs_base=base+7)+1;
	(void) (*Lnk283)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T967;}
	base[5]= Cnil;
	goto T942;
T967:;
	base[5]= make_cons((V310),car((V319)));
T942:;
	bds_bind(VV[142],base[5]);
	bds_bind(VV[130],symbol_value(VV[130]));
	princ_str("\n{	",VV[21]);
	if(((V321))==Cnil){
	goto T972;}
	princ_str("\n	va_list ap;",VV[21]);
T972:;
	princ_str("\n	int narg = VFUN_NARGS;",VV[21]);
	V330= structure_ref(cadr((V312)),VV[58],1);
	(void)((*(LnkLI320))(/* INLINE-ARGS */V330,(V311),VV[144]));
	princ_str(" VMB",VV[21]);
	(void)((*(LnkLI264))((V327)));
	princ_str(" VMS",VV[21]);
	(void)((*(LnkLI264))((V327)));
	princ_str(" VMV",VV[21]);
	(void)((*(LnkLI264))((V327)));
	if(((V313))==Cnil){
	goto T986;}
	princ_str("\n	bds_check;",VV[21]);
T986:;
	if((symbol_value(VV[145]))==Cnil){
	goto T990;}
	princ_str("\n	ihs_check;",VV[21]);
T990:;
	if((V321)!=Cnil){
	goto T994;}
	princ_str("\n	if ( narg!= ",VV[21]);
	V331 = make_fixnum(length((V314)));
	(void)((*(LnkLI264))(V331));
	princ_str(") vfun_wrong_number_of_args(small_fixnum(",VV[21]);
	V332 = make_fixnum(length((V314)));
	(void)((*(LnkLI264))(V332));
	princ_str("));",VV[21]);
T994:;
	{object V333;
	object V334;
	V333= car((V319));
	V334= car((V333));
T1005:;
	if(!(endp((V333)))){
	goto T1006;}
	goto T1001;
T1006:;
	base[9]= (V334);
	vs_top=(vs_base=base+9)+1;
	L25(base);
	vs_top=sup;
	V333= cdr((V333));
	V334= car((V333));
	goto T1005;}
T1001:;
	{object V335;
	object V336;
	V335= cadr((V319));
	V336= car((V335));
T1021:;
	if(!(endp((V335)))){
	goto T1022;}
	goto T1017;
T1022:;
	base[9]= car((V336));
	vs_top=(vs_base=base+9)+1;
	L25(base);
	vs_top=sup;
	if((caddr((V336)))==Cnil){
	goto T1028;}
	base[9]= caddr((V336));
	vs_top=(vs_base=base+9)+1;
	L25(base);
	vs_top=sup;
T1028:;
	V335= cdr((V335));
	V336= car((V335));
	goto T1021;}
T1017:;
	if((caddr((V319)))==Cnil){
	goto T1037;}
	base[7]= caddr((V319));
	vs_top=(vs_base=base+7)+1;
	L25(base);
	vs_top=sup;
T1037:;
	{object V337;
	object V338;
	V337= car(cddddr((V319)));
	V338= car((V337));
T1044:;
	if(!(endp((V337)))){
	goto T1045;}
	goto T1000;
T1045:;
	base[9]= cadr((V338));
	vs_top=(vs_base=base+9)+1;
	L25(base);
	vs_top=sup;
	if((cadddr((V338)))==Cnil){
	goto T1051;}
	base[9]= cadddr((V338));
	vs_top=(vs_base=base+9)+1;
	L25(base);
	vs_top=sup;
T1051:;
	V337= cdr((V337));
	V338= car((V337));
	goto T1044;}
T1000:;
	if((symbol_value(VV[152]))!=Cnil){
	goto T1062;}
	if((symbol_value(VV[153]))==Cnil){
	goto T1060;}
T1062:;
	if((car((V319)))==Cnil){
	goto T1060;}
	princ_str("\n	if(narg <",VV[21]);
	V339 = make_fixnum(length(car((V319))));
	(void)((*(LnkLI264))(V339));
	princ_str(") too_few_arguments();",VV[21]);
T1060:;
	{object V340;
	object V341;
	V340= car((V319));
	V341= car((V340));
T1074:;
	if(!(endp((V340)))){
	goto T1075;}
	goto T1070;
T1075:;
	(void)((*(LnkLI326))((V341)));
	V340= cdr((V340));
	V341= car((V340));
	goto T1074;}
T1070:;
	{object V342;
	object V343;
	V342= cadr((V319));
	V343= car((V342));
T1089:;
	if(!(endp((V342)))){
	goto T1090;}
	goto T1085;
T1090:;
	(void)((*(LnkLI326))(car((V343))));
	V342= cdr((V342));
	V343= car((V342));
	goto T1089;}
T1085:;
	if((caddr((V319)))==Cnil){
	goto T1100;}
	(void)((*(LnkLI326))(caddr((V319))));
T1100:;
	if(((VV[148]->s.s_dbind))==Cnil){
	goto T1106;}
	V317= symbol_value(VV[125]);
	goto T1104;
T1106:;
	V317= symbol_value(VV[137]);
T1104:;
	{object V344;
	object V345;
	V344= car(cddddr((V319)));
	V345= car((V344));
T1112:;
	if(!(endp((V344)))){
	goto T1113;}
	goto T1108;
T1113:;
	(void)((*(LnkLI326))(cadr((V345))));
	V344= cdr((V344));
	V345= car((V344));
	goto T1112;}
T1108:;
	{object V346;
	object V347;
	V346= car(cddddr((V319)));
	V347= car((V346));
T1127:;
	if(!(endp((V346)))){
	goto T1128;}
	goto T1123;
T1128:;
	(void)((*(LnkLI326))(cadddr((V347))));
	V346= cdr((V346));
	V347= car((V346));
	goto T1127;}
T1123:;
	{object V348;
	object V349;
	V349= car((V319));
	V348= (V314);
T1141:;
	if(((V348))!=Cnil){
	goto T1142;}
	goto T1138;
T1142:;
	(void)((*(LnkLI327))(car((V349)),car((V348))));
	V348= cdr((V348));
	V349= cdr((V349));
	goto T1141;}
T1138:;
	if((cadr((V319)))==Cnil){
	goto T1151;}
	bds_bind(VV[129],symbol_value(VV[129]));
	bds_bind(VV[130],(VV[130]->s.s_dbind));
	bds_bind(VV[128],symbol_value(VV[128]));
	princ_str("\n	narg = narg - ",VV[21]);
	V350 = make_fixnum(length((V314)));
	(void)((*(LnkLI264))(V350));
	princ_char(59,VV[21]);
	{object V351;
	object V352;
	V351= cadr((V319));
	V352= car((V351));
T1162:;
	if(!(endp((V351)))){
	goto T1163;}
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	goto T1154;
T1163:;
	setq(VV[154],number_plus(symbol_value(VV[154]),small_fixnum(1)));
	V353= make_cons(symbol_value(VV[154]),Cnil);
	V315= make_cons(/* INLINE-ARGS */V353,(V315));
	princ_str("\n	if (",VV[21]);
	if((cdr((V315)))==Cnil){
	goto T1175;}
	V354= VV[155];
	goto T1173;
T1175:;
	V354= VV[156];
T1173:;
	(void)((*(LnkLI264))(V354));
	princ_str("narg <= 0) ",VV[21]);
	if(type_of(car((V315)))!=t_cons)FEwrong_type_argument(Scons,car((V315)));
	(car((V315)))->c.c_cdr = Ct;
	(void)(car((V315)));
	princ_str("goto T",VV[21]);
	(void)((*(LnkLI264))(car(car((V315)))));
	princ_char(59,VV[21]);
	princ_str("\n	else {",VV[21]);
	if(((V320))!=Cnil){
	goto T1185;}
	V320= Ct;
	princ_str("\n	va_start(ap);",VV[21]);
T1185:;
	V355= car((V352));
	V356= make_cons(VV[157],Cnil);
	(void)((*(LnkLI327))(/* INLINE-ARGS */V355,/* INLINE-ARGS */V356));
	princ_char(125,VV[21]);
	if((caddr((V352)))==Cnil){
	goto T1194;}
	(void)((*(LnkLI327))(caddr((V352)),Ct));
T1194:;
	V351= cdr((V351));
	V352= car((V351));
	goto T1162;}
T1154:;
	V315= nreverse((V315));
	{object V357;
	setq(VV[154],number_plus(symbol_value(VV[154]),small_fixnum(1)));
	V357= make_cons(symbol_value(VV[154]),Cnil);
	princ_str("\n	--narg; ",VV[21]);
	if(type_of((V357))!=t_cons)FEwrong_type_argument(Scons,(V357));
	((V357))->c.c_cdr = Ct;
	princ_str("goto T",VV[21]);
	(void)((*(LnkLI264))(car((V357))));
	princ_char(59,VV[21]);
	{object V358;
	object V359;
	V358= cadr((V319));
	V359= car((V358));
T1217:;
	if(!(endp((V358)))){
	goto T1218;}
	goto T1213;
T1218:;
	if((cdr(car((V315))))==Cnil){
	goto T1222;}
	princ_str("\nT",VV[21]);
	(void)((*(LnkLI264))(car(car((V315)))));
	princ_str(":;",VV[21]);
T1222:;
	{object V360;
	V360= car((V315));
	V315= cdr((V315));}
	(void)((*(LnkLI328))(car((V359)),cadr((V359))));
	if((caddr((V359)))==Cnil){
	goto T1233;}
	(void)((*(LnkLI327))(caddr((V359)),Cnil));
T1233:;
	V358= cdr((V358));
	V359= car((V358));
	goto T1217;}
T1213:;
	if((cdr((V357)))==Cnil){
	goto T1151;}
	princ_str("\nT",VV[21]);
	(void)((*(LnkLI264))(car((V357))));
	princ_str(":;",VV[21]);}
T1151:;
	if((caddr((V319)))==Cnil){
	goto T1246;}
	V318= (VFUN_NARGS=0,(*(LnkLI329))());
	{object V361;
	V361= cadr((V319));
	if(((V361))==Cnil){
	goto T1254;}
	goto T1251;
T1254:;
	princ_str("\n	narg= narg - ",VV[21]);
	V362 = make_fixnum(length(car((V319))));
	(void)((*(LnkLI264))(V362));
	princ_char(59,VV[21]);}
T1251:;
	if(((V320))!=Cnil){
	goto T1259;}
	V320= Ct;
	princ_str("\n	va_start(ap);",VV[21]);
T1259:;
	princ_str("\n	V",VV[21]);
	(void)((*(LnkLI264))((V318)));
	princ_str(" = ",VV[21]);{object V363;
	base[8]= structure_ref(caddr((V319)),VV[65],5);
	base[9]= VV[159];
	vs_top=(vs_base=base+8)+2;
	(void) (*Lnk292)();
	vs_top=sup;
	V363= vs_base[0];
	if(V363==Cnil)goto T1270;
	base[7]= V363;
	goto T1269;
T1270:;}
	base[7]= symbol_value(VV[158]);
T1269:;
	bds_bind(VV[158],base[7]);
	if((cadddr((V319)))==Cnil){
	goto T1276;}
	if(((VV[158]->s.s_dbind))==Cnil){
	goto T1279;}
	princ_str("(ALLOCA_CONS(narg),ON_STACK_MAKE_LIST(narg));",VV[21]);
	goto T1274;
T1279:;
	princ_str("make_list(narg);",VV[21]);
	goto T1274;
T1276:;
	if(((VV[158]->s.s_dbind))==Cnil){
	goto T1284;}
	princ_str("(ALLOCA_CONS(narg),ON_STACK_LIST_VECTOR(narg,ap));",VV[21]);
	goto T1274;
T1284:;
	princ_str("list_vector(narg,ap);",VV[21]);
T1274:;
	V364= caddr((V319));
	V365= list(2,VV[150],(V318));
	V366= (*(LnkLI327))(/* INLINE-ARGS */V364,/* INLINE-ARGS */V365);
	bds_unwind1;
T1246:;
	if((cadddr((V319)))==Cnil){
	goto T1288;}
	{object V367;
	V367= caddr((V319));
	if(((V367))==Cnil){
	goto T1294;}
	goto T1291;
T1294:;
	{object V368;
	V368= cadr((V319));
	if(((V368))==Cnil){
	goto T1298;}
	goto T1291;
T1298:;
	princ_str("\n	narg= narg - ",VV[21]);
	V369 = make_fixnum(length(car((V319))));
	(void)((*(LnkLI264))(V369));
	princ_char(59,VV[21]);}}
T1291:;
	if(((V320))!=Cnil){
	goto T1303;}
	V320= Ct;
	princ_str("\n	va_start(ap);",VV[21]);
T1303:;
	base[8]=symbol_function(VV[330]);
	{object V370;
	object V371= car(cddddr((V319)));
	if(endp(V371)){
	V316= Cnil;
	goto T1310;}
	base[7]=V370=MMcons(Cnil,Cnil);
T1311:;
	base[9]= (V371->c.c_car);
	vs_top=(vs_base=base+9)+1;
	(void) (*Lnk330)();
	vs_top=sup;
	(V370->c.c_car)= vs_base[0];
	if(endp(V371=MMcdr(V371))){
	V316= base[7];
	goto T1310;}
	V370=MMcdr(V370)=MMcons(Cnil,Cnil);
	goto T1311;}
T1310:;
	{object V372;
	object V373;
	V373= make_fixnum(length(car(cddddr((V319)))));
	V372= Cnil;
	{register object V374;
	object V375;
	object V376;
	V374= (V316);
	V375= car(cddddr((V319)));
	V376= car((V375));
T1320:;
	if(((V374))!=Cnil){
	goto T1321;}
	goto T1315;
T1321:;
	if(!((caar((V374)))==(VV[160]))){
	goto T1326;}
	if((caddr(car((V374))))==(Cnil)){
	goto T1325;}
T1326:;
	V372= Ct;
T1325:;
	if(!((caar((V374)))==(VV[160]))){
	goto T1332;}
	{object V377;
	V377= caddr(car((V374)));{object V378;
	base[9]= (V377);
	base[10]= Cnil;
	vs_top=(vs_base=base+9)+2;
	(void) (*Lnk292)();
	vs_top=sup;
	V378= vs_base[0];
	if(V378==Cnil)goto T1338;
	if((V378)==Cnil){
	goto T1332;}
	goto T1336;
T1338:;}
	base[9]= (V377);
	vs_top=(vs_base=base+9)+1;
	(void) (*Lnk306)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T1342;}
	goto T1332;
T1342:;
	{register object x= car((V377)),V379= VV[161];
	while(!endp(V379))
	if(eql(x,V379->c.c_car)){
	goto T1336;
	}else V379=V379->c.c_cdr;
	goto T1332;}}
T1336:;
	V380= structure_ref(cadddr((V376)),VV[65],1);
	if((/* INLINE-ARGS */V380)==(VV[162])){
	goto T1331;}
T1332:;
	V372= Ct;
	if(type_of(V374)!=t_cons)FEwrong_type_argument(Scons,V374);
	(V374)->c.c_car = small_fixnum(0);
T1331:;
	V374= cdr((V374));
	V375= cdr((V375));
	V376= car((V375));
	goto T1320;}
T1315:;
	if(!((length((V316)))>(15))){
	goto T1356;}
	V372= Ct;
T1356:;
	princ_str("\n	{",VV[21]);
	vs_base=vs_top;
	(void) (*Lnk331)();
	vs_top=sup;
	bds_bind(VV[21],symbol_value(VV[27]));
	if(((V372))==Cnil){
	goto T1364;}
	princ_char(10,VV[27]);
	princ_str("static int VK",VV[21]);
	(void)((*(LnkLI264))((V311)));
	princ_str("defaults[",VV[21]);
	V383 = make_fixnum(length((V316)));
	(void)((*(LnkLI264))(V383));
	princ_str("]={",VV[21]);
	{object V384;
	register object V385;
	V384= (V316);
	V385= Cnil;
T1376:;
	if(((V384))!=Cnil){
	goto T1377;}
	goto T1374;
T1377:;
	if(!(eql(car((V384)),small_fixnum(0)))){
	goto T1383;}
	princ_str("-1",VV[21]);
	goto T1381;
T1383:;
	V385= caddr(car((V384)));
	if(!(((V385))==(Cnil))){
	goto T1387;}
	princ_str("-2",VV[21]);
	goto T1381;
T1387:;
	if(!(type_of((V385))==t_cons)){
	goto T1392;}
	if(!((car((V385)))==(VV[163]))){
	goto T1392;}
	(void)((*(LnkLI264))(cadr((V385))));
	goto T1381;
T1392:;
	if(!(type_of((V385))==t_cons)){
	goto T1398;}
	if(!((car((V385)))==(VV[164]))){
	goto T1398;}
	V386= (*(LnkLI332))(caddr((V385)));
	(void)((*(LnkLI264))(/* INLINE-ARGS */V386));
	goto T1381;
T1398:;
	(void)((*(LnkLI333))());
T1381:;
	if((cdr((V384)))==Cnil){
	goto T1403;}
	princ_char(44,VV[21]);
T1403:;
	V384= cdr((V384));
	goto T1376;}
T1374:;
	princ_str("};",VV[21]);
T1364:;
	princ_char(10,VV[27]);
	princ_str("static struct { short n,allow_other_keys;",VV[21]);
	princ_str("int *defaults;",VV[21]);
	princ_str("\n	 int keys[",VV[21]);
	(void)((*(LnkLI264))((V373)));
	princ_str("];",VV[21]);
	princ_str("} LI",VV[21]);
	(void)((*(LnkLI264))((V311)));
	princ_str("key=",VV[21]);
	princ_char(123,VV[21]);
	V387 = make_fixnum(length(car(cddddr((V319)))));
	(void)((*(LnkLI264))(V387));
	princ_char(44,VV[21]);
	if((cadr(cddddr((V319))))==Cnil){
	goto T1430;}
	V388= small_fixnum(1);
	goto T1428;
T1430:;
	V388= small_fixnum(0);
T1428:;
	(void)((*(LnkLI264))(V388));
	princ_char(44,VV[21]);
	if(((V372))==Cnil){
	goto T1435;}
	princ_str("VK",VV[21]);
	(void)((*(LnkLI264))((V311)));
	princ_str("defaults",VV[21]);
	goto T1433;
T1435:;
	princ_str("(int *)Cstd_key_defaults",VV[21]);
T1433:;
	if((car(cddddr((V319))))==Cnil){
	goto T1441;}
	princ_str(",{",VV[21]);
	{object V389;
	V389= reverse(car(cddddr((V319))));
T1449:;
	if(((V389))!=Cnil){
	goto T1450;}
	goto T1446;
T1450:;
	V390= (*(LnkLI334))(caar((V389)));
	(void)((*(LnkLI264))(/* INLINE-ARGS */V390));
	if((cdr((V389)))==Cnil){
	goto T1456;}
	princ_char(44,VV[21]);
T1456:;
	V389= cdr((V389));
	goto T1449;}
T1446:;
	princ_char(125,VV[21]);
T1441:;
	princ_str("};",VV[21]);
	bds_unwind1;
	if((caddr((V319)))==Cnil){
	goto T1467;}
	princ_str("\n	parse_key_rest(",VV[21]);
	V391= list(2,VV[150],(V318));
	(void)((*(LnkLI264))(/* INLINE-ARGS */V391));
	princ_char(44,VV[21]);
	goto T1465;
T1467:;
	princ_str("\n	parse_key_new(",VV[21]);
T1465:;
	if(!(eql(small_fixnum(0),symbol_value(VV[137])))){
	goto T1473;}
	setq(VV[137],small_fixnum(1));
T1473:;
	princ_str("narg,",VV[21]);
	if(((VV[148]->s.s_dbind))==Cnil){
	goto T1481;}
	V392= VV[165];
	goto T1479;
T1481:;
	V392= VV[166];
T1479:;
	(void)((*(LnkLI264))(V392));
	princ_char(43,VV[21]);
	(void)((*(LnkLI264))((V317)));
	princ_str(",&LI",VV[21]);
	(void)((*(LnkLI264))((V311)));
	princ_str("key,ap);",VV[21]);}
T1288:;
	{object V393;
	register object V394;
	V393= car(cddddr((V319)));
	V394= car((V393));
T1492:;
	if(!(endp((V393)))){
	goto T1493;}
	goto T1488;
T1493:;
	{object V396;
	V396= car((V316));
	V316= cdr((V316));
	V395= (V396);}
	if(eql(small_fixnum(0),V395)){
	goto T1499;}
	(void)((*(LnkLI335))(cadr((V394))));
	goto T1497;
T1499:;
	princ_str("\n	if(",VV[21]);
	V397= structure_ref(cadr((V394)),VV[65],2);
	(void)((*(LnkLI336))(/* INLINE-ARGS */V397));
	princ_str("==0){",VV[21]);
	bds_bind(VV[129],symbol_value(VV[129]));
	bds_bind(VV[130],(VV[130]->s.s_dbind));
	bds_bind(VV[128],symbol_value(VV[128]));
	V398= (*(LnkLI328))(cadr((V394)),caddr((V394)));
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	V399= structure_ref(cadddr((V394)),VV[65],1);
	if((/* INLINE-ARGS */V399)==(VV[162])){
	goto T1511;}
	(void)((*(LnkLI327))(cadddr((V394)),Cnil));
T1511:;
	princ_str("\n	}else{",VV[21]);
	(void)((*(LnkLI335))(cadr((V394))));
	V400= structure_ref(cadddr((V394)),VV[65],1);
	if((/* INLINE-ARGS */V400)==(VV[162])){
	goto T1517;}
	(void)((*(LnkLI327))(cadddr((V394)),Ct));
T1517:;
	princ_char(125,VV[21]);
T1497:;
	V393= cdr((V393));
	V394= car((V393));
	goto T1492;}
T1488:;
	if(((VV[142]->s.s_dbind))==Cnil){
	goto T1526;}
	(VV[130]->s.s_dbind)= make_cons(VV[146],(VV[130]->s.s_dbind));
	princ_str("\nTTL:;",VV[21]);
T1526:;
	base[7]= caddr(cddr((V312)));
	vs_top=(vs_base=base+7)+1;
	(void) (*Lnk321)();
	vs_top=sup;
	princ_char(125,VV[21]);
	if((base[1])==Cnil){
	goto T1536;}
	princ_str("\n	}",VV[21]);
T1536:;
	(void)((*(LnkLI337))());
	V401= get((V310),VV[74],Cnil);
	{object V402 = (*(LnkLI322))((V327),V401);
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	VMR24(V402)}}}
}
/*	local entry for function T3DEFUN-NORMAL	*/

static object LI26(V407,V408,V409,V410)

object V407;register object V408;object V409;object V410;
{	 VMB25 VMS25 VMV25
TTL:;
	(void)((VFUN_NARGS=2,(*(LnkLI318))(VV[167],(V407))));
	if(!(type_of((V408))==t_fixnum||
type_of((V408))==t_bignum||
type_of((V408))==t_ratio||
type_of((V408))==t_shortfloat||
type_of((V408))==t_longfloat||
type_of((V408))==t_complex)){
	goto T1545;}
	princ_str("\nstatic L",VV[21]);
	(void)((*(LnkLI264))((V408)));
	princ_str("()",VV[21]);
	goto T1543;
T1545:;
	princ_char(10,VV[21]);
	(void)((*(LnkLI264))((V408)));
	princ_str("()",VV[21]);
T1543:;
	princ_str("\n{",VV[21]);
	princ_str("register object *",VV[21]);
	(void)((*(LnkLI264))(symbol_value(VV[16])));
	princ_str("base=vs_base;",VV[21]);
	V411= structure_ref(cadr((V409)),VV[58],1);
	(void)((*(LnkLI320))(/* INLINE-ARGS */V411,(V408),VV[144]));
	princ_str("\n	register object *",VV[21]);
	(void)((*(LnkLI264))(symbol_value(VV[16])));
	princ_str("sup=base+VM",VV[21]);
	(void)((*(LnkLI264))(symbol_value(VV[132])));
	princ_char(59,VV[21]);
	princ_str(" VC",VV[21]);
	(void)((*(LnkLI264))(symbol_value(VV[132])));
	if((symbol_value(VV[152]))==Cnil){
	goto T1570;}
	princ_str("\n	vs_reserve(VM",VV[21]);
	(void)((*(LnkLI264))(symbol_value(VV[132])));
	princ_str(");",VV[21]);
	goto T1568;
T1570:;
	princ_str("\n	vs_check;",VV[21]);
T1568:;
	if(((V410))==Cnil){
	goto T1576;}
	princ_str("\n	bds_check;",VV[21]);
T1576:;
	if((symbol_value(VV[145]))==Cnil){
	goto T1580;}
	princ_str("\n	ihs_check;",VV[21]);
T1580:;
	(void)((VFUN_NARGS=3,(*(LnkLI338))(caddr((V409)),caddr(cddr((V409))),(V407))));
	princ_str("\n}",VV[21]);
	V412= make_cons(symbol_value(VV[132]),symbol_value(VV[126]));
	setq(VV[29],make_cons(/* INLINE-ARGS */V412,symbol_value(VV[29])));
	princ_str("\n#define VC",VV[27]);
	(void)((*(LnkLI267))(symbol_value(VV[132])));
	{object V413 = (*(LnkLI339))();
	VMR25(V413)}
}
/*	local entry for function WT-V*-MACROS	*/

static object LI27(V416,V417)

register object V416;object V417;
{	 VMB26 VMS26 VMV26
TTL:;
	V418= make_cons((V416),symbol_value(VV[126]));
	setq(VV[29],make_cons(/* INLINE-ARGS */V418,symbol_value(VV[29])));
	if(!(number_compare(small_fixnum(0),symbol_value(VV[126]))==0)){
	goto T1596;}
	if((symbol_value(VV[134]))!=Cnil){
	goto T1596;}
	if((symbol_value(VV[136]))!=Cnil){
	goto T1596;}
	princ_str("\n#define VMB",VV[27]);
	(void)((*(LnkLI267))((V416)));
	goto T1594;
T1596:;
	princ_str("\n#define VMB",VV[27]);
	(void)((*(LnkLI267))((V416)));
	princ_char(32,VV[27]);
	princ_str("register object *",VV[27]);
	(void)((*(LnkLI267))(symbol_value(VV[16])));
	princ_str("base=vs_top;",VV[27]);
T1594:;
	(void)((*(LnkLI339))());
	if((symbol_value(VV[134]))==Cnil){
	goto T1613;}
	princ_str("\n#define VMS",VV[27]);
	(void)((*(LnkLI267))((V416)));
	princ_char(32,VV[27]);
	princ_str(" register object *",VV[27]);
	(void)((*(LnkLI267))(symbol_value(VV[16])));
	princ_str("sup=vs_top+",VV[27]);
	(void)((*(LnkLI267))(symbol_value(VV[126])));
	princ_str(";vs_top=sup;",VV[27]);
	goto T1611;
T1613:;
	if(!(number_compare(small_fixnum(0),symbol_value(VV[126]))==0)){
	goto T1624;}
	princ_str("\n#define VMS",VV[27]);
	(void)((*(LnkLI267))((V416)));
	goto T1611;
T1624:;
	princ_str("\n#define VMS",VV[27]);
	(void)((*(LnkLI267))((V416)));
	princ_str(" vs_top += ",VV[27]);
	(void)((*(LnkLI267))(symbol_value(VV[126])));
	princ_char(59,VV[27]);
T1611:;
	if(!(number_compare(small_fixnum(0),symbol_value(VV[126]))==0)){
	goto T1635;}
	princ_str("\n#define VMV",VV[27]);
	(void)((*(LnkLI267))((V416)));
	goto T1633;
T1635:;
	if((symbol_value(VV[152]))==Cnil){
	goto T1640;}
	princ_str("\n#define VMV",VV[27]);
	(void)((*(LnkLI267))((V416)));
	princ_str(" vs_reserve(",VV[27]);
	(void)((*(LnkLI267))(symbol_value(VV[126])));
	princ_str(");",VV[27]);
	goto T1633;
T1640:;
	princ_str("\n#define VMV",VV[27]);
	(void)((*(LnkLI267))((V416)));
	princ_str(" vs_check;",VV[27]);
T1633:;
	if(!(number_compare(small_fixnum(0),symbol_value(VV[126]))==0)){
	goto T1651;}
	princ_str("\n#define VMR",VV[27]);
	(void)((*(LnkLI267))((V416)));
	princ_str("(VMT",VV[27]);
	(void)((*(LnkLI267))((V416)));
	princ_str(") return(VMT",VV[27]);
	(void)((*(LnkLI267))((V416)));
	princ_str(");",VV[27]);
	{object V419 = Cnil;
	VMR26(V419)}
T1651:;
	princ_str("\n#define VMR",VV[27]);
	(void)((*(LnkLI267))((V416)));
	princ_str("(VMT",VV[27]);
	(void)((*(LnkLI267))((V416)));
	princ_str(") vs_top=base ; return(VMT",VV[27]);
	(void)((*(LnkLI267))((V416)));
	princ_str(");",VV[27]);
	{object V420 = Cnil;
	VMR26(V420)}
}
/*	local entry for function WT-REQUIREDS	*/

static object LI28(V423,V424)

object V423;object V424;
{	 VMB27 VMS27 VMV27
TTL:;
	{register object V425;
	V425= (V423);
T1669:;
	if(!(endp((V425)))){
	goto T1670;}
	goto T1667;
T1670:;
	{register object V426;
	setq(VV[84],number_plus(symbol_value(VV[84]),small_fixnum(1)));
	V426= symbol_value(VV[84]);
	(void)(structure_set(car((V425)),VV[65],4,(V426)));
	princ_char(86,VV[21]);
	(void)((*(LnkLI264))((V426)));}
	if(endp(cdr((V425)))){
	goto T1680;}
	princ_char(44,VV[21]);
T1680:;
	V425= cdr((V425));
	goto T1669;}
T1667:;
	princ_str(")\n",VV[21]);
	if(((V423))==Cnil){
	goto T1690;}
	princ_char(10,VV[21]);
	{register object V427;
	register object V428;
	register object V429;
	V427= (V423);
	V428= (V424);
	V429= Cnil;
T1694:;
	if(!(endp((V427)))){
	goto T1695;}
	princ_char(59,VV[21]);
	{object V430 = Cnil;
	VMR27(V430)}
T1695:;
	if(((V429))==Cnil){
	goto T1700;}
	princ_char(59,VV[21]);
T1700:;
	(void)((*(LnkLI264))(symbol_value(VV[16])));
	V431= (*(LnkLI340))(car((V427)));
	(void)((*(LnkLI264))(/* INLINE-ARGS */V431));
	V432= (*(LnkLI271))(car((V428)));
	(void)((*(LnkLI264))(/* INLINE-ARGS */V432));
	V429= car((V428));
	princ_char(86,VV[21]);
	V433= structure_ref(car((V427)),VV[65],4);
	(void)((*(LnkLI264))(/* INLINE-ARGS */V433));
	V427= cdr((V427));
	V428= cdr((V428));
	goto T1694;}
T1690:;
	{object V434 = Cnil;
	VMR27(V434)}
}
/*	local entry for function ADD-DEBUG-INFO	*/

static object LI29(V437,V438)

object V437;object V438;
{	 VMB28 VMS28 VMV28
TTL:;
	{object V439;
	V439= Cnil;
	{object V440;
	base[0]= symbol_value(VV[110]);
	base[1]= small_fixnum(2);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk304)();
	vs_top=sup;
	V440= vs_base[0];
	if(((V440))==Cnil){
	goto T1722;}
	{object V441 = (V440);
	VMR28(V441)}
T1722:;
	if((get((V437),VV[111],Cnil))!=Cnil){
	goto T1725;}
	{object V442 = (VFUN_NARGS=2,(*(LnkLI341))(VV[168],(V437)));
	VMR28(V442)}
T1725:;
	(void)(remprop((V437),VV[111]));
	{register object V443;
	V443= small_fixnum(0);
	{register object V444;
	register object V445;
	V444= structure_ref(cadr((V438)),VV[58],1);
	V445= car((V444));
T1732:;
	if(!(endp((V444)))){
	goto T1733;}
	goto T1728;
T1733:;
	V446= structure_ref((V445),VV[65],2);
	if(!(type_of(/* INLINE-ARGS */V446)==t_cons)){
	goto T1737;}
	V447= structure_ref((V445),VV[65],2);
	if(!(type_of(cdr(/* INLINE-ARGS */V447))==t_fixnum)){
	goto T1737;}
	V448= structure_ref((V445),VV[65],2);
	{object V449= cdr(/* INLINE-ARGS */V448);
	V443= (number_compare((V443),V449)>=0?((V443)):V449);}
T1737:;
	V444= cdr((V444));
	V445= car((V444));
	goto T1732;}
T1728:;
	base[0]= one_plus((V443));
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk282)();
	vs_top=sup;
	V439= vs_base[0];
	{register object V450;
	register object V451;
	V450= structure_ref(cadr((V438)),VV[58],1);
	V451= car((V450));
T1755:;
	if(!(endp((V450)))){
	goto T1756;}
	goto T1751;
T1756:;
	V452= structure_ref((V451),VV[65],2);
	if(!(type_of(/* INLINE-ARGS */V452)==t_cons)){
	goto T1760;}
	V453= structure_ref((V451),VV[65],2);
	if(!(type_of(cdr(/* INLINE-ARGS */V453))==t_fixnum)){
	goto T1760;}
	{object V454;
	register object V456;
	V457= structure_ref((V451),VV[65],2);
	V454= cdr(/* INLINE-ARGS */V457);
	V456= structure_ref((V451),VV[65],0);
	if(type_of(nthcdr(fixint((V454)),V439))!=t_cons)FEwrong_type_argument(Scons,nthcdr(fixint((V454)),V439));
	(nthcdr(fixint((V454)),V439))->c.c_car = (V456);
	(void)(nthcdr(fixint((V454)),V439));}
T1760:;
	V450= cdr((V450));
	V451= car((V450));
	goto T1755;}
T1751:;
	(void)(sputprop((V437),VV[112],(V439)));
	{object V458;
	V458= get((V437),VV[112],Cnil);
	if(((V458))==Cnil){
	goto T1776;}
	if((cdr((V458)))!=Cnil){
	goto T1775;}
	if((car((V458)))==Cnil){
	goto T1776;}
T1775:;
	V459= list(2,VV[87],(V437));
	V460= list(3,VV[112],/* INLINE-ARGS */V459,list(2,VV[87],(V458)));
	{object V461 = (VFUN_NARGS=1,(*(LnkLI301))(/* INLINE-ARGS */V460));
	VMR28(V461)}
T1776:;
	{object V462 = Cnil;
	VMR28(V462)}}}}}
}
/*	local entry for function ANALYZE-REGS	*/

static int LI30(V465,V466)

object V465;object V466;
{	 VMB29 VMS29 VMV29
TTL:;
	{object V467;
	V467= number_minus(symbol_value(VV[169]),(V466));
	if(!(number_compare(small_fixnum(0),symbol_value(VV[170]))==0)){
	goto T1784;}
	V468= (VFUN_NARGS=1,(*(LnkLI343))((V465)));
	{int V469 = (*(LnkLI342))(/* INLINE-ARGS */V468,(V467));
	VMR29(V469)}
T1784:;
	{register object V470;
	register object V471;
	V470= Cnil;
	V471= Cnil;
	{register object V472;
	register object V473;
	V472= (V465);
	V473= car((V472));
T1790:;
	if(!(endp((V472)))){
	goto T1791;}
	goto T1786;
T1791:;
	V475= structure_ref((V473),VV[65],5);
	{register object x= /* INLINE-ARGS */V475,V474= VV[171];
	while(!endp(V474))
	if(x==(V474->c.c_car)){
	goto T1798;
	}else V474=V474->c.c_cdr;
	goto T1797;}
T1798:;{object V476;
	{register object x= (V473),V477= (V471);
	while(!endp(V477))
	if(eql(x,V477->c.c_car)){
	V476= V477;
	goto T1800;
	}else V477=V477->c.c_cdr;
	V476= Cnil;}
T1800:;
	if(V476==Cnil)goto T1799;
	goto T1795;
T1799:;}
	V471= make_cons((V473),(V471));
	goto T1795;
T1797:;{object V478;
	{register object x= (V473),V479= (V470);
	while(!endp(V479))
	if(x==(V479->c.c_car)){
	V478= V479;
	goto T1803;
	}else V479=V479->c.c_cdr;
	V478= Cnil;}
T1803:;
	if(V478==Cnil)goto T1802;
	goto T1795;
T1802:;}
	V471= make_cons((V473),(V471));
T1795:;
	V472= cdr((V472));
	V473= car((V472));
	goto T1790;}
T1786:;
	(void)((*(LnkLI342))((V470),(V467)));
	{int V480 = (*(LnkLI342))((V471),symbol_value(VV[170]));
	VMR29(V480)}}}
}
/*	local entry for function ANALYZE-REGS1	*/

static int LI31(V483,V484)

object V483;object V484;
{	 VMB30 VMS30 VMV30
TTL:;
	{register int V485;
	register int V486;
	int V487;
	int V488;
	register int V489;
	V485= 0;
	V486= 3;
	V487= 100000;
	V488= fix((V484));
	V489= 0;
	V483= (VFUN_NARGS=1,(*(LnkLI343))((V483)));
T1819:;
	{register object V490;
	object V491;
	V490= (V483);
	V491= car((V490));
T1825:;
	if(!(endp((V490)))){
	goto T1826;}
	goto T1821;
T1826:;
	V485= fix(structure_ref((V491),VV[65],6));
	if(!((V485)>=(V486))){
	goto T1832;}
	V489= (V489)+(1);
	if(!((V485)<(V487))){
	goto T1837;}
	V487= V485;
T1837:;
	if(!((V489)>(V488))){
	goto T1832;}
	goto T1820;
T1832:;
	V490= cdr((V490));
	V491= car((V490));
	goto T1825;}
T1821:;
	if(!((V489)<(V488))){
	goto T1848;}
	V486= (V486)-(1);
T1848:;
	{register object V492;
	register object V493;
	V492= (V483);
	V493= car((V492));
T1856:;
	if(!(endp((V492)))){
	goto T1857;}
	goto T1852;
T1857:;
	{int V494= fix(structure_ref((V493),VV[65],6));
	if(!((/* INLINE-ARGS */V494)<(V486))){
	goto T1861;}}
	(void)(structure_set((V493),VV[65],6,small_fixnum(0)));
T1861:;
	V492= cdr((V492));
	V493= car((V492));
	goto T1856;}
T1852:;
	{int V495 = V486;
	VMR30(V495)}
T1820:;
	V489= 0;
	V486= (V487)+(1);
	V487= 1000000;
	goto T1819;}
}
/*	local entry for function WT-GLOBAL-ENTRY	*/

static object LI32(V500,V501,V502,V503)

object V500;object V501;object V502;object V503;
{	 VMB31 VMS31 VMV31
TTL:;
	if((get((V500),VV[98],Cnil))==Cnil){
	goto T1876;}
	{object V504 = Cnil;
	VMR31(V504)}
T1876:;
	(void)((VFUN_NARGS=2,(*(LnkLI318))(VV[174],(V500))));
	princ_str("\nstatic L",VV[21]);
	(void)((*(LnkLI264))((V501)));
	princ_str("()",VV[21]);
	princ_str("\n{	register object *base=vs_base;",VV[21]);
	if((symbol_value(VV[152]))!=Cnil){
	goto T1887;}
	if((symbol_value(VV[153]))==Cnil){
	goto T1886;}
T1887:;
	princ_str("\n	check_arg(",VV[21]);
	V505 = make_fixnum(length((V502)));
	(void)((*(LnkLI264))(V505));
	princ_str(");",VV[21]);
T1886:;
	princ_str("\n	base[0]=",VV[21]);
	{object V507= (V503);
	if((V507!= VV[85]))goto T1898;
	if(!(number_compare(small_fixnum(0),symbol_value(VV[110]))==0)){
	goto T1900;}
	V506= VV[175];
	goto T1897;
T1900:;
	V506= VV[176];
	goto T1897;
T1898:;
	if((V507!= VV[138]))goto T1902;
	V506= VV[177];
	goto T1897;
T1902:;
	if((V507!= VV[139]))goto T1903;
	V506= VV[178];
	goto T1897;
T1903:;
	if((V507!= VV[140]))goto T1904;
	V506= VV[179];
	goto T1897;
T1904:;
	V506= VV[180];}
T1897:;
	(void)((*(LnkLI264))(V506));
	princ_str("(LI",VV[21]);
	(void)((*(LnkLI264))((V501)));
	princ_char(40,VV[21]);
	{register object V508;
	register int V509;
	V509= 0;
	V508= (V502);
T1911:;
	if(!(endp((V508)))){
	goto T1912;}
	goto T1908;
T1912:;
	{object V511= car((V508));
	if((V511!= VV[85]))goto T1919;
	V510= VV[181];
	goto T1918;
T1919:;
	if((V511!= VV[138]))goto T1920;
	V510= VV[182];
	goto T1918;
T1920:;
	if((V511!= VV[139]))goto T1921;
	V510= VV[183];
	goto T1918;
T1921:;
	if((V511!= VV[140]))goto T1922;
	V510= VV[184];
	goto T1918;
T1922:;
	V510= VV[185];}
T1918:;
	(void)((*(LnkLI264))(V510));
	princ_str("(base[",VV[21]);
	V512 = make_fixnum(V509);
	(void)((*(LnkLI264))(V512));
	princ_str("])",VV[21]);
	if(endp(cdr((V508)))){
	goto T1926;}
	princ_char(44,VV[21]);
T1926:;
	V508= cdr((V508));
	V509= (V509)+1;
	goto T1911;}
T1908:;
	princ_str("));",VV[21]);
	princ_str("\n	vs_top=(vs_base=base)+1;",VV[21]);
	princ_str("\n}",VV[21]);
	{object V513 = Cnil;
	VMR31(V513)}
}
/*	local entry for function REP-TYPE	*/

static object LI33(V515)

object V515;
{	 VMB32 VMS32 VMV32
TTL:;
	{object V516= (V515);
	if((V516!= VV[85]))goto T1939;
	{object V517 = VV[186];
	VMR32(V517)}
T1939:;
	if((V516!= VV[249]))goto T1940;
	{object V518 = VV[187];
	VMR32(V518)}
T1940:;
	if((V516!= VV[138]))goto T1941;
	{object V519 = VV[188];
	VMR32(V519)}
T1941:;
	if((V516!= VV[140]))goto T1942;
	{object V520 = VV[189];
	VMR32(V520)}
T1942:;
	if((V516!= VV[139]))goto T1943;
	{object V521 = VV[190];
	VMR32(V521)}
T1943:;
	{object V522 = VV[191];
	VMR32(V522)}}
}
/*	local entry for function T1DEFMACRO	*/

static object LI34(V524)

register object V524;
{	 VMB33 VMS33 VMV33
	bds_check;
TTL:;
	if(endp((V524))){
	goto T1945;}
	if(!(endp(cdr((V524))))){
	goto T1944;}
T1945:;
	V525 = make_fixnum(length((V524)));
	(void)((*(LnkLI274))(VV[192],small_fixnum(2),V525));
T1944:;
	if(type_of(car((V524)))==t_symbol){
	goto T1949;}
	(void)((VFUN_NARGS=2,(*(LnkLI253))(VV[193],car((V524)))));
T1949:;
	V526= make_cons(VV[192],(V524));
	(void)((*(LnkLI255))(Ct,/* INLINE-ARGS */V526));
	setq(VV[6],Ct);
	{register object V527;
	object V528;
	setq(VV[57],number_plus(symbol_value(VV[57]),small_fixnum(1)));
	V528= symbol_value(VV[57]);
	bds_bind(VV[51],Cnil);
	bds_bind(VV[52],Cnil);
	bds_bind(VV[53],Cnil);
	bds_bind(VV[54],Cnil);
	bds_bind(VV[48],Cnil);
	bds_bind(VV[55],Cnil);
	V527= Cnil;
	V527= (*(LnkLI344))(car((V524)),cadr((V524)),cddr((V524)));
	(void)((*(LnkLI293))());
	V529= list(7,VV[192],car((V524)),(V528),cddr((V527)),car((V527)),cadr((V527)),(VV[55]->s.s_dbind));
	setq(VV[20],make_cons(/* INLINE-ARGS */V529,symbol_value(VV[20])));
	{object V530 = symbol_value(VV[20]);
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	VMR33(V530)}}
}
/*	local entry for function T2DEFMACRO	*/

static object LI35(V537,V538,V539,V540,V541,V542)

object V537;object V538;object V539;object V540;object V541;object V542;
{	 VMB34 VMS34 VMV34
TTL:;
	if(((V540))==Cnil){
	goto T1961;}
	V543= list(4,VV[99],list(2,VV[87],(V537)),(V540),VV[194]);
	(void)((VFUN_NARGS=1,(*(LnkLI301))(/* INLINE-ARGS */V543)));
T1961:;
	if(((V541))==Cnil){
	goto T1964;}
	V544= list(2,VV[87],(V537));
	V545= list(4,VV[99],/* INLINE-ARGS */V544,list(2,VV[87],(V541)),VV[195]);
	(void)((VFUN_NARGS=1,(*(LnkLI301))(/* INLINE-ARGS */V545)));
T1964:;
	princ_str("\nstatic L",VV[27]);
	(void)((*(LnkLI267))((V538)));
	princ_str("();",VV[27]);
	V546= list(2,VV[87],(V537));
	V547= list(3,VV[196],/* INLINE-ARGS */V546,(*(LnkLI302))(VV[197],(V538)));
	{object V548 = (VFUN_NARGS=1,(*(LnkLI301))(/* INLINE-ARGS */V547));
	VMR34(V548)}
}
/*	local entry for function T3DEFMACRO	*/

static object LI36(V555,V556,V557,V558,V559,V560)

object V555;object V556;register object V557;object V558;object V559;object V560;
{	 VMB35 VMS35 VMV35
	bds_check;
TTL:;
	if((get((V555),VV[198],Cnil))==Cnil){
	goto T1973;}
	bds_bind(VV[16],VV[199]);
	goto T1971;
T1973:;
	bds_bind(VV[16],VV[200]);
T1971:;
	bds_bind(VV[124],VV[123]);
	bds_bind(VV[14],Cnil);
	bds_bind(VV[125],small_fixnum(0));
	bds_bind(VV[126],small_fixnum(0));
	bds_bind(VV[127],small_fixnum(0));
	bds_bind(VV[128],small_fixnum(0));
	bds_bind(VV[129],Cnil);
	bds_bind(VV[130],make_cons((VV[124]->s.s_dbind),Cnil));
	bds_bind(VV[131],(VV[124]->s.s_dbind));
	setq(VV[133],number_plus(symbol_value(VV[133]),small_fixnum(1)));
	bds_bind(VV[132],symbol_value(VV[133]));
	bds_bind(VV[134],Cnil);
	bds_bind(VV[135],Cnil);
	bds_bind(VV[136],Cnil);
	bds_bind(VV[137],small_fixnum(0));
	(void)((VFUN_NARGS=2,(*(LnkLI318))(VV[201],(V555))));
	princ_str("\nstatic L",VV[21]);
	(void)((*(LnkLI264))((V556)));
	princ_str("()",VV[21]);
	princ_str("\n{register object *",VV[21]);
	(void)((*(LnkLI264))((VV[16]->s.s_dbind)));
	princ_str("base=vs_base;",VV[21]);
	V561= structure_ref(car(cddddr((V557))),VV[58],1);
	(void)((*(LnkLI320))(/* INLINE-ARGS */V561,(V556),VV[144]));
	princ_str("\n	register object *",VV[21]);
	(void)((*(LnkLI264))((VV[16]->s.s_dbind)));
	princ_str("sup=base+VM",VV[21]);
	(void)((*(LnkLI264))((VV[132]->s.s_dbind)));
	princ_char(59,VV[21]);
	princ_str(" VC",VV[21]);
	(void)((*(LnkLI264))((VV[132]->s.s_dbind)));
	if((symbol_value(VV[152]))==Cnil){
	goto T1999;}
	princ_str("\n	vs_reserve(VM",VV[21]);
	(void)((*(LnkLI264))((VV[132]->s.s_dbind)));
	princ_str(");",VV[21]);
	goto T1997;
T1999:;
	princ_str("\n	vs_check;",VV[21]);
T1997:;
	if(((V560))==Cnil){
	goto T2005;}
	princ_str("\n	bds_check;",VV[21]);
T2005:;
	if((symbol_value(VV[145]))==Cnil){
	goto T2009;}
	princ_str("\n	ihs_check;",VV[21]);
T2009:;
	base[15]= car((V557));
	base[16]= cadr((V557));
	base[17]= caddr((V557));
	base[18]= cadddr((V557));
	vs_top=(vs_base=base+15)+4;
	(void) (*Lnk345)();
	vs_top=sup;
	princ_str("\n}",VV[21]);
	V562= make_cons((VV[132]->s.s_dbind),(VV[126]->s.s_dbind));
	setq(VV[29],make_cons(/* INLINE-ARGS */V562,symbol_value(VV[29])));
	princ_str("\n#define VC",VV[27]);
	(void)((*(LnkLI267))((VV[132]->s.s_dbind)));
	{object V563 = (*(LnkLI339))();
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	VMR35(V563)}
}
/*	local entry for function T1ORDINARY	*/

static object LI37(V565)

register object V565;
{	 VMB36 VMS36 VMV36
	bds_check;
TTL:;
	{register object V566;
	V566= Cnil;
	setq(VV[6],Ct);
	if((symbol_value(VV[44]))==Cnil){
	goto T2029;}
	(void)((*(LnkLI255))(Cnil,(V565)));
	{object V567;
	base[0]= VV[202];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk288)();
	vs_top=sup;
	V567= vs_base[0];
	V568= listA(3,VV[60],(V567),VV[203]);
	(void)((*(LnkLI281))(/* INLINE-ARGS */V568));
	base[0]= list(5,VV[47],(V567),Cnil,(V565),Cnil);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk259)();
	vs_top=sup;
	V569= list(2,VV[204],make_cons((V567),Cnil));
	setq(VV[20],make_cons(/* INLINE-ARGS */V569,symbol_value(VV[20])));
	{object V570 = symbol_value(VV[20]);
	VMR36(V570)}}
T2029:;
	{object V571;
	base[0]= (V565);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk306)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T2039;}
	V571= Cnil;
	goto T2038;
T2039:;
	base[0]= car((V565));
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk272)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T2042;}
	V571= Cnil;
	goto T2038;
T2042:;{object V572;
	base[0]= car((V565));
	base[1]= VV[205];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk292)();
	vs_top=sup;
	V572= vs_base[0];
	if(V572==Cnil)goto T2047;
	if((V572)!=Cnil){
	goto T2045;}
	goto T2046;
T2047:;}
	base[1]= car((V565));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk346)();
	vs_top=sup;
	base[0]= vs_base[0];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk287)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T2045;}
T2046:;
	V571= Cnil;
	goto T2038;
T2045:;
	{register object V573;
	register int V574;
	V573= cdr((V565));
	V574= 1;
T2056:;
	if((V574)>=(1000)){
	goto T2058;}
	if(type_of((V573))==t_cons){
	goto T2057;}
T2058:;
	V571= Cnil;
	goto T2038;
T2057:;
	if(!(type_of(car((V573)))==t_cons)){
	goto T2063;}
	if(!((caar((V573)))==(VV[60]))){
	goto T2063;}
	V566= cadr(car((V573)));
	if(!(type_of((V566))==t_cons)){
	goto T2063;}
	if(!((car((V566)))==(VV[206]))){
	goto T2063;}
	{register object V575;
	vs_base=vs_top;
	(void) (*Lnk288)();
	vs_top=sup;
	V575= vs_base[0];
	base[0]= listA(3,VV[47],(V575),cdr((V566)));
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk259)();
	vs_top=sup;
	base[1]= (V565);
	base[2]= small_fixnum(0);
	base[3]= make_fixnum(V574);
	vs_top=(vs_base=base+1)+3;
	(void) (*Lnk347)();
	vs_top=sup;
	base[0]= vs_base[0];
	V576= list(2,VV[207],list(2,VV[87],(V575)));
	base[1]= make_cons(/* INLINE-ARGS */V576,Cnil);
	V577 = make_fixnum(V574);
	V578= number_plus(small_fixnum(1),V577);
	base[2]= nthcdr(fixint(/* INLINE-ARGS */V578),(V565));
	vs_top=(vs_base=base+0)+3;
	(void) (*Lnk348)();
	vs_top=sup;
	V565= vs_base[0];
	goto TTL;}
T2063:;
	base[0]= (V573);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk306)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T2086;}
	V573= Cnil;
	goto T2085;
T2086:;
	V573= cdr((V573));
T2085:;
	V574= (1)+(V574);
	goto T2056;}
T2038:;
	if(((V571))==Cnil){
	goto T2092;}
	{object V579 = (V571);
	VMR36(V579)}
T2092:;
	(void)((*(LnkLI255))(Cnil,(V565)));
	bds_bind(VV[51],Cnil);
	bds_bind(VV[52],Cnil);
	bds_bind(VV[53],Cnil);
	bds_bind(VV[54],Cnil);
	bds_bind(VV[48],Cnil);
	V580= list(2,VV[204],(V565));
	setq(VV[20],make_cons(/* INLINE-ARGS */V580,symbol_value(VV[20])));
	{object V581 = Cnil;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	VMR36(V581)}}}
}
/*	local entry for function T2ORDINARY	*/

static object LI38(V583)

object V583;
{	 VMB37 VMS37 VMV37
TTL:;
	{object V584;
	base[0]= (V583);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk349)();
	vs_top=sup;
	V584= vs_base[0];
	if(((V584))==Cnil){
	goto T2100;}
	{object V585 = (V584);
	VMR37(V585)}
T2100:;
	{object V586;
	base[0]= (V583);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk350)();
	vs_top=sup;
	V586= vs_base[0];
	if(((V586))==Cnil){
	goto T2105;}
	{object V587 = (V586);
	VMR37(V587)}
T2105:;
	{object V588 = (VFUN_NARGS=1,(*(LnkLI301))((V583)));
	VMR37(V588)}}}
}
/*	local entry for function ADD-LOAD-TIME-SHARP-COMMA	*/

static object LI39()

{	 VMB38 VMS38 VMV38
TTL:;
	{register object V589;
	register object V590;
	V589= reverse(symbol_value(VV[48]));
	V590= car((V589));
T2110:;
	if(!(endp((V589)))){
	goto T2111;}
	{object V591 = Cnil;
	VMR38(V591)}
T2111:;
	if(!(type_of((V590))!=t_cons)){
	goto T2115;}
	(void)((*(LnkLI351))());
T2115:;
	V592= make_cons(VV[208],(V590));
	setq(VV[20],make_cons(/* INLINE-ARGS */V592,symbol_value(VV[20])));
	V589= cdr((V589));
	V590= car((V589));
	goto T2110;}
}
/*	local entry for function T2SHARP-COMMA	*/

static object LI40(V595,V596)

object V595;object V596;
{	 VMB39 VMS39 VMV39
TTL:;
	V597= list(3,VV[209],(V595),(V596));
	{object V598 = (VFUN_NARGS=1,(*(LnkLI301))(/* INLINE-ARGS */V597));
	VMR39(V598)}
}
/*	local entry for function T2DECLARE	*/

static object LI41(V600)

object V600;
{	 VMB40 VMS40 VMV40
TTL:;
	{object V601 = (*(LnkLI351))();
	VMR40(V601)}
}
/*	local entry for function T1DEFINE-STRUCTURE	*/

static object LI42(V603)

object V603;
{	 VMB41 VMS41 VMV41
TTL:;
	base[0]= (*(LnkLI255))(Cnil,Cnil);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk287)();
	vs_top=sup;
	V604= vs_base[0];
	V605= make_cons(V604,Cnil);
	V606= append((V603),/* INLINE-ARGS */V605);
	V607= make_cons(VV[210],/* INLINE-ARGS */V606);
	(void)((*(LnkLI255))(Ct,/* INLINE-ARGS */V607));
	V608= make_cons(VV[210],(V603));
	{object V609 = (*(LnkLI260))(/* INLINE-ARGS */V608);
	VMR41(V609)}
}
/*	local entry for function SET-DBIND	*/

static object LI43(V612,V613)

object V612;object V613;
{	 VMB42 VMS42 VMV42
TTL:;
	princ_str("\n	VV[",VV[21]);
	(void)((*(LnkLI264))((V613)));
	princ_str("]->s.s_dbind = ",VV[21]);
	(void)((*(LnkLI264))((V612)));
	princ_char(59,VV[21]);
	{object V614 = Cnil;
	VMR42(V614)}
}
/*	local entry for function T1CLINES	*/

static object LI44(V616)

object V616;
{	 VMB43 VMS43 VMV43
TTL:;
	{register object V617;
	register object V618;
	V617= (V616);
	V618= car((V617));
T2138:;
	if(!(endp((V617)))){
	goto T2139;}
	goto T2134;
T2139:;
	if(type_of((V618))==t_string){
	goto T2143;}
	(void)((VFUN_NARGS=2,(*(LnkLI253))(VV[211],(V618))));
T2143:;
	V617= cdr((V617));
	V618= car((V617));
	goto T2138;}
T2134:;
	V619= list(2,VV[212],(V616));
	setq(VV[20],make_cons(/* INLINE-ARGS */V619,symbol_value(VV[20])));
	{object V620 = symbol_value(VV[20]);
	VMR43(V620)}
}
/*	local entry for function T3CLINES	*/

static object LI45(V622)

object V622;
{	 VMB44 VMS44 VMV44
TTL:;
	{register object V623;
	register object V624;
	V623= (V622);
	V624= car((V623));
T2155:;
	if(!(endp((V623)))){
	goto T2156;}
	{object V625 = Cnil;
	VMR44(V625)}
T2156:;
	princ_char(10,VV[21]);
	(void)((*(LnkLI264))((V624)));
	V623= cdr((V623));
	V624= car((V623));
	goto T2155;}
}
/*	local entry for function T1DEFCFUN	*/

static object LI46(V627)

register object V627;
{	 VMB45 VMS45 VMV45
TTL:;
	{register object V628;
	V628= Cnil;
	if(endp((V627))){
	goto T2170;}
	if(!(endp(cdr((V627))))){
	goto T2169;}
T2170:;
	V629 = make_fixnum(length((V627)));
	(void)((*(LnkLI274))(VV[213],small_fixnum(2),V629));
T2169:;
	if(type_of(car((V627)))==t_string){
	goto T2174;}
	(void)((VFUN_NARGS=2,(*(LnkLI253))(VV[214],car((V627)))));
T2174:;
	{object V630= cadr((V627));
	if(type_of(V630)==t_fixnum||
type_of(V630)==t_bignum||
type_of(V630)==t_ratio||
type_of(V630)==t_shortfloat||
type_of(V630)==t_longfloat||
type_of(V630)==t_complex){
	goto T2177;}}
	(void)((VFUN_NARGS=2,(*(LnkLI253))(VV[215],cadr((V627)))));
T2177:;
	{register object V631;
	register object V632;
	V631= cddr((V627));
	V632= car((V631));
T2184:;
	if(!(endp((V631)))){
	goto T2185;}
	goto T2180;
T2185:;
	if(!(type_of((V632))==t_string)){
	goto T2191;}
	V628= make_cons((V632),(V628));
	goto T2189;
T2191:;
	if(!(type_of((V632))==t_cons)){
	goto T2195;}
	if(!(type_of(car((V632)))==t_symbol)){
	goto T2198;}
	base[2]= car((V632));
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk346)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T2200;}
	(void)((VFUN_NARGS=2,(*(LnkLI253))(VV[216],car((V632)))));
T2200:;
	V633= car((V632));
	V634= (*(LnkLI352))(cdr((V632)));
	V635= make_cons(/* INLINE-ARGS */V633,/* INLINE-ARGS */V634);
	V636= make_cons(/* INLINE-ARGS */V635,Cnil);
	V628= make_cons(/* INLINE-ARGS */V636,(V628));
	goto T2189;
T2198:;
	if(!(type_of(car((V632)))==t_cons)){
	goto T2206;}
	if(!(type_of(caar((V632)))==t_symbol)){
	goto T2206;}
	if(!((caar((V632)))==(VV[87]))){
	goto T2213;}{object V637;
	base[2]= cdar((V632));
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk285)();
	vs_top=sup;
	V637= vs_base[0];
	if(V637==Cnil)goto T2215;
	if((V637)!=Cnil){
	goto T2206;}
	goto T2211;
T2215:;}{object V638;
	base[3]= cddar((V632));
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk285)();
	vs_top=sup;
	base[2]= vs_base[0];
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk287)();
	vs_top=sup;
	V638= vs_base[0];
	if(V638==Cnil)goto T2218;
	if((V638)!=Cnil){
	goto T2206;}
	goto T2211;
T2218:;}{object V639;
	base[2]= cdr((V632));
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk285)();
	vs_top=sup;
	V639= vs_base[0];
	if(V639==Cnil)goto T2222;
	if((V639)!=Cnil){
	goto T2206;}
	goto T2211;
T2222:;}
	base[3]= cddr((V632));
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk285)();
	vs_top=sup;
	base[2]= vs_base[0];
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk287)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T2206;}
	goto T2211;
T2213:;
	base[2]= caar((V632));
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk346)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T2206;}
T2211:;
	V640= caar((V632));
	if(!((caar((V632)))==(VV[87]))){
	goto T2231;}
	V642= (*(LnkLI332))(cadar((V632)));
	V641= make_cons(/* INLINE-ARGS */V642,Cnil);
	goto T2229;
T2231:;
	V641= (*(LnkLI352))(cdar((V632)));
T2229:;
	V643= make_cons(/* INLINE-ARGS */V640,V641);
	V644= (*(LnkLI352))(cdr((V632)));
	V645= make_cons(/* INLINE-ARGS */V643,/* INLINE-ARGS */V644);
	V628= make_cons(/* INLINE-ARGS */V645,(V628));
	goto T2189;
T2206:;
	(void)((VFUN_NARGS=2,(*(LnkLI253))(VV[217],(V632))));
	goto T2189;
T2195:;
	(void)((VFUN_NARGS=2,(*(LnkLI253))(VV[218],(V632))));
T2189:;
	V631= cdr((V631));
	V632= car((V631));
	goto T2184;}
T2180:;
	V646= car((V627));
	V647= cadr((V627));
	V648= list(4,VV[213],/* INLINE-ARGS */V646,/* INLINE-ARGS */V647,reverse((V628)));
	setq(VV[20],make_cons(/* INLINE-ARGS */V648,symbol_value(VV[20])));
	{object V649 = symbol_value(VV[20]);
	VMR45(V649)}}
}
/*	local entry for function T3DEFCFUN	*/

static object LI47(V653,V654,V655)

object V653;object V654;object V655;
{	 VMB46 VMS46 VMV46
TTL:;
	{object V656;
	V656= Cnil;
	(void)((VFUN_NARGS=2,(*(LnkLI318))(VV[219],VV[213])));
	princ_char(10,VV[21]);
	(void)((*(LnkLI264))((V653)));
	princ_str("\n{",VV[21]);
	princ_str("\nobject *vs=vs_top;",VV[21]);
	princ_str("\nobject *old_top=vs_top+",VV[21]);
	(void)((*(LnkLI264))((V654)));
	princ_char(59,VV[21]);
	if(!(number_compare((V654),small_fixnum(0))>0)){
	goto T2252;}
	princ_str("\n	vs_top=old_top;",VV[21]);
T2252:;
	princ_str("\n{",VV[21]);
	{object V657;
	register object V658;
	V657= (V655);
	V658= car((V657));
T2262:;
	if(!(endp((V657)))){
	goto T2263;}
	goto T2258;
T2263:;
	if(!(type_of((V658))==t_string)){
	goto T2269;}
	princ_char(10,VV[21]);
	(void)((*(LnkLI264))((V658)));
	goto T2267;
T2269:;
	if(!((caar((V658)))==(VV[87]))){
	goto T2274;}
	princ_char(10,VV[21]);
	(void)((*(LnkLI264))(cadadr((V658))));
	{object V659= caadr((V658));
	if((V659!= VV[70]))goto T2279;
	princ_str("=VV[",VV[21]);
	(void)((*(LnkLI264))(cadar((V658))));
	princ_str("];",VV[21]);
	goto T2267;
T2279:;
	princ_str("=object_to_",VV[21]);
	base[1]= symbol_name(caadr((V658)));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk353)();
	vs_top=sup;
	V660= vs_base[0];
	(void)((*(LnkLI264))(V660));
	princ_str("(VV[",VV[21]);
	(void)((*(LnkLI264))(cadar((V658))));
	princ_str("]);",VV[21]);
	goto T2267;}
T2274:;
	princ_str("\n{vs_base=vs_top=old_top;",VV[21]);
	{register object V661;
	register object V662;
	V661= cdar((V658));
	V662= car((V661));
T2296:;
	if(!(endp((V661)))){
	goto T2297;}
	goto T2292;
T2297:;
	princ_str("\nvs_push(",VV[21]);
	{object V663= car((V662));
	if((V663!= VV[70]))goto T2304;
	(void)((*(LnkLI264))(cadr((V662))));
	goto T2303;
T2304:;
	if((V663!= VV[354]))goto T2306;
	princ_str("code_char((int)",VV[21]);
	(void)((*(LnkLI264))(cadr((V662))));
	princ_char(41,VV[21]);
	goto T2303;
T2306:;
	if((V663!= VV[355]))goto T2310;
	if(!(number_compare(small_fixnum(0),symbol_value(VV[110]))==0)){
	goto T2311;}
	princ_str("CMP",VV[21]);
T2311:;
	princ_str("make_fixnum((int)",VV[21]);
	(void)((*(LnkLI264))(cadr((V662))));
	princ_char(41,VV[21]);
	goto T2303;
T2310:;
	if((V663!= VV[356]))goto T2318;
	princ_str("make_shortfloat((double)",VV[21]);
	(void)((*(LnkLI264))(cadr((V662))));
	princ_char(41,VV[21]);
	goto T2303;
T2318:;
	if((V663!= VV[357]))goto T2322;
	princ_str("make_longfloat((double)",VV[21]);
	(void)((*(LnkLI264))(cadr((V662))));
	princ_char(41,VV[21]);
	goto T2303;
T2322:;}
T2303:;
	princ_str(");",VV[21]);
	V661= cdr((V661));
	V662= car((V661));
	goto T2296;}
T2292:;
	{register object x= caar((V658)),V664= symbol_value(VV[75]);
	while(!endp(V664))
	if(type_of(V664->c.c_car)==t_cons &&eql(x,V664->c.c_car->c.c_car)){
	V656= (V664->c.c_car);
	goto T2337;
	}else V664=V664->c.c_cdr;
	V656= Cnil;}
T2337:;
	if(((V656))==Cnil){
	goto T2335;}
	if((symbol_value(VV[145]))==Cnil){
	goto T2339;}
	princ_str("\nihs_push(VV[",VV[21]);
	V665= (*(LnkLI334))(caar((V658)));
	(void)((*(LnkLI264))(/* INLINE-ARGS */V665));
	princ_str("]);",VV[21]);
	princ_str("\nL",VV[21]);
	(void)((*(LnkLI264))(cdr((V656))));
	princ_str("();",VV[21]);
	princ_str("\nihs_pop();",VV[21]);
	goto T2333;
T2339:;
	princ_str("\nL",VV[21]);
	(void)((*(LnkLI264))(cdr((V656))));
	princ_str("();",VV[21]);
	goto T2333;
T2335:;
	if((symbol_value(VV[145]))==Cnil){
	goto T2354;}
	princ_str("\nsuper_funcall(VV[",VV[21]);
	V666= (*(LnkLI334))(caar((V658)));
	(void)((*(LnkLI264))(/* INLINE-ARGS */V666));
	princ_str("]);",VV[21]);
	goto T2333;
T2354:;
	if((symbol_value(VV[152]))==Cnil){
	goto T2360;}
	princ_str("\nsuper_funcall_no_event(VV[",VV[21]);
	V667= (*(LnkLI334))(caar((V658)));
	(void)((*(LnkLI264))(/* INLINE-ARGS */V667));
	princ_str("]);",VV[21]);
	goto T2333;
T2360:;
	princ_str("\nCMPfuncall(VV[",VV[21]);
	V668= (*(LnkLI334))(caar((V658)));
	(void)((*(LnkLI264))(/* INLINE-ARGS */V668));
	princ_str("]->s.s_gfdef);",VV[21]);
T2333:;
	if(endp(cdr((V658)))){
	goto T2368;}
	princ_char(10,VV[21]);
	(void)((*(LnkLI264))(cadadr((V658))));
	{object V669= caadr((V658));
	if((V669!= VV[70]))goto T2375;
	princ_str("=vs_base[0];",VV[21]);
	goto T2374;
T2375:;
	princ_str("=object_to_",VV[21]);
	base[1]= symbol_name(caadr((V658)));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk353)();
	vs_top=sup;
	V670= vs_base[0];
	(void)((*(LnkLI264))(V670));
	princ_str("(vs_base[0]);",VV[21]);}
T2374:;
	{register object V671;
	register object V672;
	V671= cddr((V658));
	V672= car((V671));
T2385:;
	if(!(endp((V671)))){
	goto T2386;}
	goto T2368;
T2386:;
	princ_str("\nvs_base++;",VV[21]);
	princ_char(10,VV[21]);
	(void)((*(LnkLI264))(cadr((V672))));
	{object V673= car((V672));
	if((V673!= VV[70]))goto T2396;
	princ_str("=(vs_base<vs_top?vs_base[0]:Cnil);",VV[21]);
	goto T2395;
T2396:;
	princ_str("=object_to_",VV[21]);
	base[3]= symbol_name(car((V672)));
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk353)();
	vs_top=sup;
	V674= vs_base[0];
	(void)((*(LnkLI264))(V674));
	princ_str("((vs_base<vs_top?vs_base[0]:Cnil));",VV[21]);}
T2395:;
	V671= cdr((V671));
	V672= car((V671));
	goto T2385;}
T2368:;
	princ_str("\n}",VV[21]);
T2267:;
	V657= cdr((V657));
	V658= car((V657));
	goto T2262;}
T2258:;
	princ_str("\n}",VV[21]);
	princ_str("\nvs_top=vs;",VV[21]);
	princ_str("\n}",VV[21]);
	{object V675 = Cnil;
	VMR46(V675)}}
}
/*	local entry for function T1DEFENTRY	*/

static object LI48(V677)

register object V677;
{	 VMB47 VMS47 VMV47
TTL:;
	{register object V678;
	register object V679;
	object V680;
	register object V681;
	V678= Cnil;
	V679= Cnil;
	setq(VV[57],number_plus(symbol_value(VV[57]),small_fixnum(1)));
	V680= symbol_value(VV[57]);
	V681= Cnil;
	if(endp((V677))){
	goto T2425;}
	if(endp(cdr((V677)))){
	goto T2425;}
	if(!(endp(cddr((V677))))){
	goto T2424;}
T2425:;
	V682 = make_fixnum(length((V677)));
	(void)((*(LnkLI274))(VV[220],small_fixnum(3),V682));
T2424:;
	if(type_of(car((V677)))==t_symbol){
	goto T2431;}
	(void)((VFUN_NARGS=2,(*(LnkLI253))(VV[221],car((V677)))));
T2431:;
	{register object V683;
	register object V684;
	V683= cadr((V677));
	V684= car((V683));
T2438:;
	if(!(endp((V683)))){
	goto T2439;}
	goto T2434;
T2439:;
	{register object x= (V684),V685= VV[222];
	while(!endp(V685))
	if(eql(x,V685->c.c_car)){
	goto T2443;
	}else V685=V685->c.c_cdr;}
	(void)((VFUN_NARGS=2,(*(LnkLI253))(VV[223],(V684))));
T2443:;
	V683= cdr((V683));
	V684= car((V683));
	goto T2438;}
T2434:;
	V681= caddr((V677));
	if(!(type_of((V681))==t_symbol)){
	goto T2455;}
	V678= VV[70];
	base[1]= symbol_name((V681));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk353)();
	vs_top=sup;
	V679= vs_base[0];
	goto T2453;
T2455:;
	if(!(type_of((V681))==t_string)){
	goto T2462;}
	V678= VV[70];
	V679= (V681);
	goto T2453;
T2462:;
	if(!(type_of((V681))==t_cons)){
	goto T2468;}
	{register object x= car((V681)),V686= VV[224];
	while(!endp(V686))
	if(eql(x,V686->c.c_car)){
	goto T2472;
	}else V686=V686->c.c_cdr;
	goto T2468;}
T2472:;
	if(!(type_of(cdr((V681)))==t_cons)){
	goto T2468;}
	if(type_of(cadr((V681)))==t_symbol){
	goto T2475;}
	if(!(type_of(cadr((V681)))==t_string)){
	goto T2468;}
T2475:;
	if(!(endp(cddr((V681))))){
	goto T2468;}
	if(!(type_of(cadr((V681)))==t_symbol)){
	goto T2483;}
	base[1]= symbol_name(cadr((V681)));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk353)();
	vs_top=sup;
	V679= vs_base[0];
	goto T2481;
T2483:;
	V679= cadr((V681));
T2481:;
	V678= car((V681));
	goto T2453;
T2468:;
	(void)((VFUN_NARGS=2,(*(LnkLI253))(VV[225],(V681))));
T2453:;
	V687= list(6,VV[220],car((V677)),(V680),cadr((V677)),(V678),(V679));
	setq(VV[20],make_cons(/* INLINE-ARGS */V687,symbol_value(VV[20])));
	V688= make_cons(car((V677)),(V680));
	setq(VV[75],make_cons(/* INLINE-ARGS */V688,symbol_value(VV[75])));
	{object V689 = symbol_value(VV[75]);
	VMR47(V689)}}
}
/*	local entry for function T2DEFENTRY	*/

static object LI49(V695,V696,V697,V698,V699)

object V695;object V696;object V697;object V698;object V699;
{	 VMB48 VMS48 VMV48
TTL:;
	princ_str("\nstatic L",VV[27]);
	(void)((*(LnkLI267))((V696)));
	princ_str("();",VV[27]);
	V700= list(2,VV[87],(V695));
	V701= list(3,VV[107],/* INLINE-ARGS */V700,(*(LnkLI302))(VV[226],(V696)));
	{object V702 = (VFUN_NARGS=1,(*(LnkLI301))(/* INLINE-ARGS */V701));
	VMR48(V702)}
}
/*	local entry for function T3DEFENTRY	*/

static object LI50(V708,V709,V710,V711,V712)

object V708;object V709;object V710;register object V711;object V712;
{	 VMB49 VMS49 VMV49
TTL:;
	(void)((VFUN_NARGS=2,(*(LnkLI318))(VV[227],(V708))));
	princ_str("\nstatic L",VV[21]);
	(void)((*(LnkLI264))((V709)));
	princ_str("()",VV[21]);
	princ_str("\n{	object *old_base=vs_base;",VV[21]);
	{object V713= (V711);
	if((V713!= VV[228]))goto T2502;
	goto T2501;
T2502:;
	if((V713!= VV[358]))goto T2503;
	princ_str("\n	char *x;",VV[21]);
	goto T2501;
T2503:;
	princ_str("\n	",VV[21]);
	base[0]= symbol_name((V711));
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk353)();
	vs_top=sup;
	V714= vs_base[0];
	(void)((*(LnkLI264))(V714));
	princ_str(" x;",VV[21]);}
T2501:;
	if((symbol_value(VV[152]))==Cnil){
	goto T2510;}
	princ_str("\n	check_arg(",VV[21]);
	V715 = make_fixnum(length((V710)));
	(void)((*(LnkLI264))(V715));
	princ_str(");",VV[21]);
T2510:;
	if(((V711))==(VV[228])){
	goto T2516;}
	princ_str("\n	x=",VV[21]);
T2516:;
	princ_str("\n	",VV[21]);
	(void)((*(LnkLI264))((V712)));
	princ_char(40,VV[21]);
	if(endp((V710))){
	goto T2524;}
	{register object V716;
	register int V717;
	V717= 0;
	V716= (V710);
T2529:;
	{object V718= car((V716));
	if((V718!= VV[70]))goto T2533;
	princ_str("\n	vs_base[",VV[21]);
	V719 = make_fixnum(V717);
	(void)((*(LnkLI264))(V719));
	princ_char(93,VV[21]);
	goto T2532;
T2533:;
	princ_str("\n	object_to_",VV[21]);
	base[0]= symbol_name(car((V716)));
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk353)();
	vs_top=sup;
	V720= vs_base[0];
	(void)((*(LnkLI264))(V720));
	princ_str("(vs_base[",VV[21]);
	V721 = make_fixnum(V717);
	(void)((*(LnkLI264))(V721));
	princ_str("])",VV[21]);}
T2532:;
	if(!(endp(cdr((V716))))){
	goto T2544;}
	goto T2524;
T2544:;
	princ_char(44,VV[21]);
	V716= cdr((V716));
	V717= (V717)+1;
	goto T2529;}
T2524:;
	princ_str(");",VV[21]);
	princ_str("\n	vs_top=(vs_base=old_base)+1;",VV[21]);
	princ_str("\n	vs_base[0]=",VV[21]);
	{object V722= (V711);
	if((V722!= VV[228]))goto T2560;
	princ_str("Cnil",VV[21]);
	goto T2559;
T2560:;
	if((V722!= VV[70]))goto T2562;
	princ_char(120,VV[21]);
	goto T2559;
T2562:;
	if((V722!= VV[354]))goto T2564;
	princ_str("code_char(x)",VV[21]);
	goto T2559;
T2564:;
	if((V722!= VV[355]))goto T2566;
	if(!(number_compare(small_fixnum(0),symbol_value(VV[110]))==0)){
	goto T2567;}
	princ_str("CMP",VV[21]);
T2567:;
	princ_str("make_fixnum(x)",VV[21]);
	goto T2559;
T2566:;
	if((V722!= VV[358]))goto T2572;
	princ_str("make_simple_string(x)",VV[21]);
	goto T2559;
T2572:;
	if((V722!= VV[356]))goto T2574;
	princ_str("make_shortfloat(x)",VV[21]);
	goto T2559;
T2574:;
	if((V722!= VV[357]))goto T2576;
	princ_str("make_longfloat(x)",VV[21]);
	goto T2559;
T2576:;}
T2559:;
	princ_char(59,VV[21]);
	princ_str("\n}",VV[21]);
	{object V723 = Cnil;
	VMR49(V723)}
}
/*	local entry for function T1DEFLA	*/

static object LI51(V725)

object V725;
{	 VMB50 VMS50 VMV50
TTL:;
	{object V726 = Cnil;
	VMR50(V726)}
}
/*	local entry for function PARSE-CVSPECS	*/

static object LI52(V728)

object V728;
{	 VMB51 VMS51 VMV51
TTL:;
	{register object V729;
	V729= Cnil;
	{register object V730;
	register object V731;
	V730= (V728);
	V731= car((V730));
T2585:;
	if(!(endp((V730)))){
	goto T2586;}
	{object V732 = reverse((V729));
	VMR51(V732)}
T2586:;
	if(!(type_of((V731))==t_symbol)){
	goto T2592;}
	base[1]= symbol_name((V731));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk353)();
	vs_top=sup;
	V733= vs_base[0];
	V734= list(2,VV[70],V733);
	V729= make_cons(/* INLINE-ARGS */V734,(V729));
	goto T2590;
T2592:;
	if(!(type_of((V731))==t_string)){
	goto T2598;}
	V735= list(2,VV[70],(V731));
	V729= make_cons(/* INLINE-ARGS */V735,(V729));
	goto T2590;
T2598:;
	if(!(type_of((V731))==t_cons)){
	goto T2602;}
	{register object x= car((V731)),V736= VV[229];
	while(!endp(V736))
	if(eql(x,V736->c.c_car)){
	goto T2605;
	}else V736=V736->c.c_cdr;
	goto T2602;}
T2605:;
	{register object V737;
	register object V738;
	V737= cdr((V731));
	V738= car((V737));
T2609:;
	if(!(endp((V737)))){
	goto T2610;}
	goto T2590;
T2610:;
	V739= car((V731));
	if(!(type_of((V738))==t_symbol)){
	goto T2618;}
	base[3]= symbol_name((V738));
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk353)();
	vs_top=sup;
	V740= vs_base[0];
	goto T2616;
T2618:;
	if(!(type_of((V738))==t_string)){
	goto T2622;}
	V740= (V738);
	goto T2616;
T2622:;
	V740= (VFUN_NARGS=2,(*(LnkLI253))(VV[230],(V738)));
T2616:;
	V741= list(2,/* INLINE-ARGS */V739,V740);
	V729= make_cons(/* INLINE-ARGS */V741,(V729));
	V737= cdr((V737));
	V738= car((V737));
	goto T2609;}
T2602:;
	(void)((VFUN_NARGS=2,(*(LnkLI253))(VV[231],(V731))));
T2590:;
	V730= cdr((V730));
	V731= car((V730));
	goto T2585;}}
}
/*	local entry for function T3LOCAL-DCFUN	*/

static object LI53(V747,V748,V749,V750,V751)

object V747;object V748;object V749;register object V750;register object V751;
{	 VMB52 VMS52 VMV52
	bds_check;
TTL:;
	{object V752;
	register object V753;
	object V754;
	if(((V747))==Cnil){
	goto T2636;}
	V752= small_fixnum(0);
	goto T2634;
T2636:;
	V752= structure_ref((V750),VV[28],4);
T2634:;
	V753= Cnil;
	bds_bind(VV[16],(*(LnkLI311))(cadr((V751))));
	bds_bind(VV[113],Cnil);
	V754= caaddr((V751));
	if((structure_ref((V750),VV[28],0))==Cnil){
	goto T2644;}
	V755= structure_ref((V750),VV[28],0);
	goto T2642;
T2644:;
	V755= Cnil;
T2642:;
	(void)((VFUN_NARGS=2,(*(LnkLI318))(VV[232],V755)));
	princ_str("\nstatic ",VV[21]);
	if(((V747))==Cnil){
	goto T2651;}
	V756= VV[233];
	goto T2649;
T2651:;
	V756= VV[234];
T2649:;
	(void)((*(LnkLI264))(V756));
	V757= structure_ref((V750),VV[28],3);
	(void)((*(LnkLI264))(/* INLINE-ARGS */V757));
	princ_char(40,VV[21]);
	princ_str("base0",VV[21]);
	if(((V754))==Cnil){
	goto T2660;}
	V758= VV[235];
	goto T2658;
T2660:;
	V758= VV[236];
T2658:;
	(void)((*(LnkLI264))(V758));
	V759= structure_ref(cadr((V751)),VV[58],1);
	(void)((*(LnkLI314))(/* INLINE-ARGS */V759,small_fixnum(2)));
	(void)((*(LnkLI319))(caaddr((V751)),Cnil));
	princ_str("register object *",VV[21]);
	(void)((*(LnkLI264))((VV[16]->s.s_dbind)));
	princ_str("base0;",VV[21]);
	bds_bind(VV[237],(V749));
	bds_bind(VV[124],VV[120]);
	bds_bind(VV[14],Cnil);
	bds_bind(VV[125],small_fixnum(0));
	bds_bind(VV[126],small_fixnum(0));
	bds_bind(VV[127],one_plus((V752)));
	bds_bind(VV[128],(V749));
	bds_bind(VV[129],(V748));
	bds_bind(VV[130],make_cons((VV[124]->s.s_dbind),Cnil));
	bds_bind(VV[131],(VV[124]->s.s_dbind));
	setq(VV[133],number_plus(symbol_value(VV[133]),small_fixnum(1)));
	bds_bind(VV[132],symbol_value(VV[133]));
	bds_bind(VV[134],Cnil);
	bds_bind(VV[135],Cnil);
	bds_bind(VV[136],Cnil);
	bds_bind(VV[137],small_fixnum(0));
	V753= (VV[132]->s.s_dbind);
	princ_str("\n{",VV[21]);
	V760= structure_ref(cadr((V751)),VV[58],1);
	V761= structure_ref((V750),VV[28],3);
	(void)((*(LnkLI320))(/* INLINE-ARGS */V760,/* INLINE-ARGS */V761,VV[238]));
	princ_str("\n	VMB",VV[21]);
	(void)((*(LnkLI264))((V753)));
	princ_str(" VMS",VV[21]);
	(void)((*(LnkLI264))((V753)));
	princ_str(" VMV",VV[21]);
	(void)((*(LnkLI264))((V753)));
	if((symbol_value(VV[145]))==Cnil){
	goto T2684;}
	princ_str("\n	ihs_check;",VV[21]);
T2684:;
	base[19]= caddr(cddr((V751)));
	vs_top=(vs_base=base+19)+1;
	(void) (*Lnk321)();
	vs_top=sup;
	princ_str("\n}",VV[21]);
	(void)((*(LnkLI322))((V753),Ct));
	V762= structure_ref((V750),VV[28],3);
	{object V763 = (*(LnkLI316))(/* INLINE-ARGS */V762);
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	VMR52(V763)}}
}
/*	local entry for function T3LOCAL-FUN	*/

static object LI54(V769,V770,V771,V772,V773)

object V769;object V770;object V771;object V772;object V773;
{	 VMB53 VMS53 VMV53
	bds_check;
TTL:;
	{int V774;
	if(((V769))==Cnil){
	goto T2695;}
	V774= 0;
	goto T2693;
T2695:;
	V774= fix(structure_ref((V772),VV[28],4));
T2693:;
	bds_bind(VV[16],(*(LnkLI311))(cadr((V773))));
	bds_bind(VV[113],Cnil);
	if(!(((V769))==(VV[239]))){
	goto T2698;}
	{object V775 = (*(LnkLI238))((V769),(V770),(V771),(V772),(V773));
	bds_unwind1;
	bds_unwind1;
	VMR53(V775)}
T2698:;
	if((structure_ref((V772),VV[28],0))==Cnil){
	goto T2704;}
	V776= structure_ref((V772),VV[28],0);
	goto T2702;
T2704:;
	V776= Cnil;
T2702:;
	(void)((VFUN_NARGS=2,(*(LnkLI318))(VV[240],V776)));
	princ_str("\nstatic ",VV[27]);
	if(((V769))==Cnil){
	goto T2711;}
	V777= VV[241];
	goto T2709;
T2711:;
	V777= VV[242];
T2709:;
	(void)((*(LnkLI267))(V777));
	V778= structure_ref((V772),VV[28],3);
	(void)((*(LnkLI267))(/* INLINE-ARGS */V778));
	princ_str("();",VV[27]);
	princ_str("\nstatic ",VV[21]);
	if(((V769))==Cnil){
	goto T2720;}
	V779= VV[243];
	goto T2718;
T2720:;
	V779= VV[244];
T2718:;
	(void)((*(LnkLI264))(V779));
	V780= structure_ref((V772),VV[28],3);
	(void)((*(LnkLI264))(/* INLINE-ARGS */V780));
	princ_char(40,VV[21]);
	{register object V781;
	register int V782;
	V781= make_fixnum(V774);
	V782= 0;
T2728:;
	V783 = make_fixnum(V782);
	if(!(number_compare(V783,(V781))>=0)){
	goto T2729;}
	princ_str("base",VV[21]);
	V784 = make_fixnum(V782);
	(void)((*(LnkLI264))(V784));
	princ_char(41,VV[21]);
	goto T2724;
T2729:;
	princ_str("base",VV[21]);
	V785 = make_fixnum(V782);
	(void)((*(LnkLI264))(V785));
	princ_char(44,VV[21]);
	V782= (V782)+1;
	goto T2728;}
T2724:;
	princ_str("\nregister object ",VV[21]);
	{register object V786;
	register int V787;
	V786= make_fixnum(V774);
	V787= 0;
T2749:;
	V788 = make_fixnum(V787);
	if(!(number_compare(V788,(V786))>=0)){
	goto T2750;}
	princ_char(42,VV[21]);
	(void)((*(LnkLI264))((VV[16]->s.s_dbind)));
	princ_str("base",VV[21]);
	V789 = make_fixnum(V787);
	(void)((*(LnkLI264))(V789));
	princ_char(59,VV[21]);
	goto T2745;
T2750:;
	princ_char(42,VV[21]);
	(void)((*(LnkLI264))((VV[16]->s.s_dbind)));
	princ_str("base",VV[21]);
	V790 = make_fixnum(V787);
	(void)((*(LnkLI264))(V790));
	princ_char(44,VV[21]);
	V787= (V787)+1;
	goto T2749;}
T2745:;
	V791= structure_ref(cadr((V773)),VV[58],1);
	(void)((*(LnkLI314))(/* INLINE-ARGS */V791,small_fixnum(2)));
	bds_bind(VV[124],VV[123]);
	bds_bind(VV[237],(V771));
	bds_bind(VV[14],Cnil);
	bds_bind(VV[125],small_fixnum(0));
	bds_bind(VV[126],small_fixnum(0));
	V792 = make_fixnum(V774);
	bds_bind(VV[127],one_plus(V792));
	bds_bind(VV[128],(V771));
	bds_bind(VV[129],(V770));
	bds_bind(VV[130],make_cons((VV[124]->s.s_dbind),Cnil));
	bds_bind(VV[131],(VV[124]->s.s_dbind));
	setq(VV[133],number_plus(symbol_value(VV[133]),small_fixnum(1)));
	bds_bind(VV[132],symbol_value(VV[133]));
	bds_bind(VV[134],Cnil);
	bds_bind(VV[135],Cnil);
	bds_bind(VV[136],Cnil);
	bds_bind(VV[137],small_fixnum(0));
	princ_str("\n{	register object *",VV[21]);
	(void)((*(LnkLI264))((VV[16]->s.s_dbind)));
	princ_str("base=vs_base;",VV[21]);
	princ_str("\n	register object *",VV[21]);
	(void)((*(LnkLI264))((VV[16]->s.s_dbind)));
	princ_str("sup=base+VM",VV[21]);
	(void)((*(LnkLI264))((VV[132]->s.s_dbind)));
	princ_char(59,VV[21]);
	V793= structure_ref(cadr((V773)),VV[58],1);
	V794= structure_ref((V772),VV[28],3);
	(void)((*(LnkLI320))(/* INLINE-ARGS */V793,/* INLINE-ARGS */V794,VV[245]));
	princ_str(" VC",VV[21]);
	(void)((*(LnkLI264))((VV[132]->s.s_dbind)));
	if((symbol_value(VV[152]))==Cnil){
	goto T2790;}
	princ_str("\n	vs_reserve(VM",VV[21]);
	(void)((*(LnkLI264))((VV[132]->s.s_dbind)));
	princ_str(");",VV[21]);
	goto T2788;
T2790:;
	princ_str("\n	vs_check;",VV[21]);
T2788:;
	if((symbol_value(VV[145]))==Cnil){
	goto T2796;}
	princ_str("\n	ihs_check;",VV[21]);
T2796:;
	if(((V769))==Cnil){
	goto T2802;}
	(void)((VFUN_NARGS=2,(*(LnkLI338))(caddr((V773)),caddr(cddr((V773))))));
	goto T2800;
T2802:;
	(void)((VFUN_NARGS=3,(*(LnkLI338))(caddr((V773)),caddr(cddr((V773))),(V772))));
T2800:;
	princ_str("\n}",VV[21]);
	V795= make_cons((VV[132]->s.s_dbind),(VV[126]->s.s_dbind));
	setq(VV[29],make_cons(/* INLINE-ARGS */V795,symbol_value(VV[29])));
	princ_str("\n#define VC",VV[27]);
	(void)((*(LnkLI267))((VV[132]->s.s_dbind)));
	V796= (*(LnkLI339))();
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	V797= structure_ref((V772),VV[28],3);
	{object V798 = (*(LnkLI316))(/* INLINE-ARGS */V797);
	bds_unwind1;
	bds_unwind1;
	VMR53(V798)}}
}
/*	local entry for function WT-CVARS	*/

static object LI55()

{	 VMB54 VMS54 VMV54
TTL:;
	{register object V799;
	V799= Cnil;
	{register object V800;
	register object V801;
	V800= symbol_value(VV[14]);
	V801= car((V800));
T2816:;
	if(!(endp((V800)))){
	goto T2817;}
	goto T2812;
T2817:;
	{register object V802;
	if(!(type_of((V801))==t_cons)){
	goto T2824;}
	{register object V803;
	V803= car((V801));
	V801= cdr((V801));
	V802= (V803);
	goto T2822;}
T2824:;
	V802= Ct;
T2822:;
	if(!(((V799))==((V802)))){
	goto T2831;}
	base[1]= symbol_value(VV[27]);
	base[2]= VV[246];
	base[3]= (V801);
	vs_top=(vs_base=base+1)+3;
	(void) (*Lnk294)();
	vs_top=sup;
	goto T2829;
T2831:;{object V804;
	base[1]= (V799);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk283)();
	vs_top=sup;
	V804= vs_base[0];
	if(V804==Cnil)goto T2837;
	goto T2836;
T2837:;}
	base[1]= symbol_value(VV[27]);
	base[2]= VV[247];
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk294)();
	vs_top=sup;
T2836:;
	V799= (V802);
	base[1]= symbol_value(VV[27]);
	base[2]= VV[248];
	base[3]= (*(LnkLI271))((V799));
	base[4]= (V801);
	vs_top=(vs_base=base+1)+4;
	(void) (*Lnk294)();
	vs_top=sup;
T2829:;
	if(!(((V799))==(VV[249]))){
	goto T2821;}
	base[1]= symbol_value(VV[27]);
	base[2]= VV[250];
	base[3]= (V801);
	vs_top=(vs_base=base+1)+3;
	(void) (*Lnk294)();
	vs_top=sup;}
T2821:;
	V800= cdr((V800));
	V801= car((V800));
	goto T2816;}
T2812:;
	if(symbol_value(VV[14])==Cnil){
	goto T2858;}
	base[0]= symbol_value(VV[27]);
	base[1]= VV[251];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk294)();
	vs_top=sup;
T2858:;
	if(eql(symbol_value(VV[137]),small_fixnum(0))){
	goto T2862;}
	base[0]= symbol_value(VV[27]);
	base[1]= VV[252];
	base[2]= symbol_value(VV[137]);
	vs_top=(vs_base=base+0)+3;
	(void) (*Lnk294)();
	vs_top=sup;
	{object V805 = vs_base[0];
	VMR54(V805)}
T2862:;
	{object V806 = Cnil;
	VMR54(V806)}}
}
/*	local function DO-DECL	*/

static L25(base0)
register object *base0;
{	register object *base=vs_base;
	register object *sup=base+VM55; VC55
	vs_reserve(VM55);
	{object V807;
	check_arg(1);
	V807=(base[0]);
	vs_top=sup;
TTL:;
	base[1]= structure_ref((V807),VV[65],4);
	base[2]= VV[68];
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk279)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T2868;}
	goto T2867;
T2868:;
	(VV[148]->s.s_dbind)= Ct;
T2867:;
	{object V808;
	V808= (*(LnkLI359))((V807));
	if(((V808))==Cnil){
	goto T2875;}
	{object V809;
	setq(VV[84],number_plus(symbol_value(VV[84]),small_fixnum(1)));
	V809= symbol_value(VV[84]);
	(void)(structure_set((V807),VV[65],1,(V808)));
	(void)(structure_set((V807),VV[65],4,(V809)));
	princ_str("\n	",VV[21]);
	if((base0[1])!=Cnil){
	goto T2882;}
	princ_char(123,VV[21]);
	base0[1]= Ct;
T2882:;
	base[1]= (V807);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk360)();
	return;}
T2875:;
	base[1]= Cnil;
	vs_top=(vs_base=base+1)+1;
	return;}
	}
}
static LnkT360(){ call_or_link(VV[360],&Lnk360);} /* WT-VAR-DECL */
static object  LnkTLI359(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[359],&LnkLI359,1,ap);} /* C2VAR-KIND */
static object  LnkTLI238(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[238],&LnkLI238,5,ap);} /* T3LOCAL-DCFUN */
static LnkT353(){ call_or_link(VV[353],&Lnk353);} /* STRING-DOWNCASE */
static object  LnkTLI352(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[352],&LnkLI352,1,ap);} /* PARSE-CVSPECS */
static object  LnkTLI351(){return call_proc0(VV[351],&LnkLI351);} /* WFS-ERROR */
static LnkT350(){ call_or_link(VV[350],&Lnk350);} /* CONSTANTP */
static LnkT349(){ call_or_link(VV[349],&Lnk349);} /* ATOM */
static LnkT348(){ call_or_link(VV[348],&Lnk348);} /* APPEND */
static LnkT347(){ call_or_link(VV[347],&Lnk347);} /* SUBSEQ */
static LnkT346(){ call_or_link(VV[346],&Lnk346);} /* SPECIAL-FORM-P */
static LnkT345(){ call_or_link(VV[345],&Lnk345);} /* C2DM */
static object  LnkTLI344(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[344],&LnkLI344,3,ap);} /* C1DM */
static object  LnkTLI343(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[343],&LnkLI343,ap);} /* REMOVE-DUPLICATES */
static int  LnkTLI342(va_alist)va_dcl{va_list ap;va_start(ap);return(int )call_proc(VV[342],&LnkLI342,258,ap);} /* ANALYZE-REGS1 */
static object  LnkTLI341(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[341],&LnkLI341,ap);} /* WARN */
static object  LnkTLI340(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[340],&LnkLI340,1,ap);} /* REGISTER */
static object  LnkTLI339(){return call_proc0(VV[339],&LnkLI339);} /* WT-CVARS */
static object  LnkTLI338(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[338],&LnkLI338,ap);} /* C2LAMBDA-EXPR */
static object  LnkTLI337(){return call_proc0(VV[337],&LnkLI337);} /* CLOSE-INLINE-BLOCKS */
static object  LnkTLI336(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[336],&LnkLI336,1,ap);} /* WT-VS */
static object  LnkTLI335(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[335],&LnkLI335,1,ap);} /* C2BIND */
static object  LnkTLI334(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[334],&LnkLI334,1,ap);} /* ADD-SYMBOL */
static object  LnkTLI333(){return call_proc0(VV[333],&LnkLI333);} /* BABOON */
static object  LnkTLI332(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[332],&LnkLI332,1,ap);} /* ADD-OBJECT */
static LnkT331(){ call_or_link(VV[331],&Lnk331);} /* INC-INLINE-BLOCKS */
static LnkT330(){ call_or_link(VV[330],&Lnk330);} /* CADDR */
static object  LnkTLI329(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[329],&LnkLI329,ap);} /* CS-PUSH */
static object  LnkTLI328(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[328],&LnkLI328,2,ap);} /* C2BIND-INIT */
static object  LnkTLI327(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[327],&LnkLI327,2,ap);} /* C2BIND-LOC */
static object  LnkTLI326(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[326],&LnkLI326,1,ap);} /* SET-UP-VAR-CVS */
static object  LnkTLI325(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[325],&LnkLI325,1,ap);} /* WT-LIST */
static object  LnkTLI324(){return call_proc0(VV[324],&LnkLI324);} /* CVS-PUSH */
static object  LnkTLI323(){return call_proc0(VV[323],&LnkLI323);} /* VS-PUSH */
static object  LnkTLI322(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[322],&LnkLI322,2,ap);} /* WT-V*-MACROS */
static LnkT321(){ call_or_link(VV[321],&Lnk321);} /* C2EXPR */
static object  LnkTLI320(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[320],&LnkLI320,3,ap);} /* ASSIGN-DOWN-VARS */
static object  LnkTLI319(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[319],&LnkLI319,2,ap);} /* WT-REQUIREDS */
static object  LnkTLI318(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[318],&LnkLI318,ap);} /* WT-COMMENT */
static object  LnkTLI317(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[317],&LnkLI317,2,ap);} /* ADD-DEBUG-INFO */
static object  LnkTLI316(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[316],&LnkLI316,1,ap);} /* WT-DOWNWARD-CLOSURE-MACRO */
static LnkT315(){ call_or_link(VV[315],&Lnk315);} /* T3DEFUN-AUX */
static int  LnkTLI314(va_alist)va_dcl{va_list ap;va_start(ap);return(int )call_proc(VV[314],&LnkLI314,258,ap);} /* ANALYZE-REGS */
static LnkT313(){ call_or_link(VV[313],&Lnk313);} /* ERROR */
static LnkT312(){ call_or_link(VV[312],&Lnk312);} /* FIXNUMP */
static object  LnkTLI311(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[311],&LnkLI311,1,ap);} /* VOLATILE */
static object  LnkTLI310(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[310],&LnkLI310,1,ap);} /* MAXARGS */
static object  LnkTLI309(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[309],&LnkLI309,1,ap);} /* VARARG-P */
static object  LnkTLI308(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[308],&LnkLI308,3,ap);} /* WT-IF-PROCLAIMED */
static LnkT307(){ call_or_link(VV[307],&Lnk307);} /* + */
static LnkT306(){ call_or_link(VV[306],&Lnk306);} /* CONSP */
static LnkT305(){ call_or_link(VV[305],&Lnk305);} /* EQUAL */
static LnkT304(){ call_or_link(VV[304],&Lnk304);} /* >= */
static int  LnkTLI303(va_alist)va_dcl{va_list ap;va_start(ap);return(int )call_proc(VV[303],&LnkLI303,258,ap);} /* PROCLAIMED-ARGD */
static object  LnkTLI302(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[302],&LnkLI302,2,ap);} /* ADD-ADDRESS */
static object  LnkTLI301(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[301],&LnkLI301,ap);} /* ADD-INIT */
static object  LnkTLI300(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[300],&LnkLI300,ap);} /* FAST-LINK-PROCLAIMED-TYPE-P */
static object  LnkTLI299(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[299],&LnkLI299,2,ap);} /* SHIFT<< */
static int  LnkTLI298(va_alist)va_dcl{va_list ap;va_start(ap);return(int )call_proc(VV[298],&LnkLI298,257,ap);} /* F-TYPE */
static LnkT297(){ call_or_link(VV[297],&Lnk297);} /* SUBTYPEP */
static LnkT296(){ call_or_link(VV[296],&Lnk296);} /* STRUCTURE-SUBTYPE-P */
static object  LnkTLI295(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[295],&LnkLI295,ap);} /* MAKE-ARRAY */
static LnkT294(){ call_or_link(VV[294],&Lnk294);} /* FORMAT */
static object  LnkTLI293(){return call_proc0(VV[293],&LnkLI293);} /* ADD-LOAD-TIME-SHARP-COMMA */
static LnkT292(){ call_or_link(VV[292],&Lnk292);} /* EQ */
static object  LnkTLI291(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[291],&LnkLI291,2,ap);} /* MAKE-INLINE-STRING */
static LnkT290(){ call_or_link(VV[290],&Lnk290);} /* NUMBERP */
static object  LnkTLI289(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[289],&LnkLI289,2,ap);} /* TYPE-AND */
static LnkT288(){ call_or_link(VV[288],&Lnk288);} /* GENSYM */
static LnkT287(){ call_or_link(VV[287],&Lnk287);} /* NOT */
static object  LnkTLI286(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[286],&LnkLI286,2,ap);} /* CMPFIX-ARGS */
static LnkT285(){ call_or_link(VV[285],&Lnk285);} /* ENDP */
static LnkT284(){ call_or_link(VV[284],&Lnk284);} /* < */
static LnkT283(){ call_or_link(VV[283],&Lnk283);} /* NULL */
static LnkT282(){ call_or_link(VV[282],&Lnk282);} /* MAKE-LIST */
static object  LnkTLI281(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[281],&LnkLI281,1,ap);} /* PROCLAIM */
static object  LnkTLI280(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[280],&LnkLI280,1,ap);} /* CHECK-DOWNWARD */
static LnkT279(){ call_or_link(VV[279],&Lnk279);} /* EQL */
static object  LnkTLI278(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[278],&LnkLI278,ap);} /* C1LAMBDA-EXPR */
static object  LnkTLI277(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[277],&LnkLI277,1,ap);} /* T1PROGN */
static object  LnkTLI274(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[274],&LnkLI274,3,ap);} /* TOO-FEW-ARGS */
static LnkT273(){ call_or_link(VV[273],&Lnk273);} /* CMP-EVAL */
static LnkT272(){ call_or_link(VV[272],&Lnk272);} /* SYMBOLP */
static object  LnkTLI271(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[271],&LnkLI271,1,ap);} /* REP-TYPE */
static LnkT270(){ call_or_link(VV[270],&Lnk270);} /* WT-DATA-FILE */
static LnkT269(){ call_or_link(VV[269],&Lnk269);} /* - */
static object  LnkTLI268(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[268],&LnkLI268,1,ap);} /* PUSH-DATA-INCF */
static object  LnkTLI267(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[267],&LnkLI267,1,ap);} /* WT-H1 */
static object  LnkTLI266(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[266],&LnkLI266,1,ap);} /* WT-FUNCTION-LINK */
static LnkT265(){ call_or_link(VV[265],&Lnk265);} /* WT-GLOBAL-ENTRY */
static LnkT245(){ call_or_link(VV[245],&Lnk245);} /* T3LOCAL-FUN */
static object  LnkTLI264(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[264],&LnkLI264,1,ap);} /* WT1 */
static LnkT263(){ call_or_link(VV[263],&Lnk263);} /* COPY-LIST */
static object  LnkTLI262(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[262],&LnkLI262,3,ap);} /* CMP-EXPAND-MACRO */
static LnkT261(){ call_or_link(VV[261],&Lnk261);} /* MACRO-FUNCTION */
static object  LnkTLI260(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[260],&LnkLI260,1,ap);} /* T1ORDINARY */
static LnkT259(){ call_or_link(VV[259],&Lnk259);} /* T1EXPR */
static object  LnkTLI258(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[258],&LnkLI258,1,ap);} /* CMP-MACROEXPAND-1 */
static object  LnkTLI257(){return call_proc0(VV[257],&LnkLI257);} /* PRINT-CURRENT-FORM */
static object  LnkTLI256(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[256],&LnkLI256,1,ap);} /* WT-DATA-PACKAGE-OPERATION */
static object  LnkTLI255(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[255],&LnkLI255,2,ap);} /* MAYBE-EVAL */
static object  LnkTLI254(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[254],&LnkLI254,ap);} /* CMPWARN */
static object  LnkTLI253(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[253],&LnkLI253,ap);} /* CMPERR */
