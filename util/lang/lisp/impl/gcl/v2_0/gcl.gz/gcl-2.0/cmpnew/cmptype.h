
static object LI1();
#define VMB1 register object *base=vs_top; object  V10 ,V8;
#define VMS1  register object *sup=vs_top+1;vs_top=sup;
#define VMV1 vs_reserve(1);
#define VMR1(VMT1) vs_top=base ; return(VMT1);
static object LI2();
#define VMB2 register object *base=vs_top; object  V34 ,V33;
#define VMS2  register object *sup=vs_top+2;vs_top=sup;
#define VMV2 vs_reserve(2);
#define VMR2(VMT2) vs_top=base ; return(VMT2);
static object LI3();
#define VMB3 register object *base=vs_top;
#define VMS3  register object *sup=vs_top+2;vs_top=sup;
#define VMV3 vs_reserve(2);
#define VMR3(VMT3) vs_top=base ; return(VMT3);
static object LI4();
#define VMB4 register object *base=vs_top;
#define VMS4  register object *sup=vs_top+2;vs_top=sup;
#define VMV4 vs_reserve(2);
#define VMR4(VMT4) vs_top=base ; return(VMT4);
static object LI5();
#define VMB5 register object *base=vs_top;
#define VMS5  register object *sup=vs_top+1;vs_top=sup;
#define VMV5 vs_reserve(1);
#define VMR5(VMT5) vs_top=base ; return(VMT5);
static object LI6();
#define VMB6 register object *base=vs_top; object  V130 ,V129;
#define VMS6  register object *sup=vs_top+1;vs_top=sup;
#define VMV6 vs_reserve(1);
#define VMR6(VMT6) vs_top=base ; return(VMT6);
static object LI7();
#define VMB7 object  V140;
#define VMS7
#define VMV7
#define VMR7(VMT7) return(VMT7);
static object LI8();
#define VMB8
#define VMS8
#define VMV8
#define VMR8(VMT8) return(VMT8);
#define VM8 0
#define VM7 0
#define VM6 1
#define VM5 1
#define VM4 2
#define VM3 2
#define VM2 2
#define VM1 1
static char * VVi[77]={
#define Cdata VV[76]
(char *)(LI1),
(char *)(LI2),
(char *)(LI3),
(char *)(LI4),
(char *)(LI5),
(char *)(LI6),
(char *)(LI7),
(char *)(LI8)
};
#define VV ((object *)VVi)
static object  LnkTLI75() ;
static object  (*LnkLI75)() = LnkTLI75;
static object  LnkTLI74() ;
static object  (*LnkLI74)() = LnkTLI74;
static  LnkT73() ;
static  (*Lnk73)() = LnkT73;
static  LnkT72() ;
static  (*Lnk72)() = LnkT72;
static object  LnkTLI71() ;
static object  (*LnkLI71)() = LnkTLI71;
static  LnkT64() ;
static  (*Lnk64)() = LnkT64;
static  LnkT63() ;
static  (*Lnk63)() = LnkT63;
static object  LnkTLI36() ;
static object  (*LnkLI36)() = LnkTLI36;
static  LnkT62() ;
static  (*Lnk62)() = LnkT62;
static object  LnkTLI61() ;
static object  (*LnkLI61)() = LnkTLI61;
static object  LnkTLI60() ;
static object  (*LnkLI60)() = LnkTLI60;
static object  LnkTLI58() ;
static object  (*LnkLI58)() = LnkTLI58;
static  LnkT53() ;
static  (*Lnk53)() = LnkT53;
static  LnkT51() ;
static  (*Lnk51)() = LnkT51;
