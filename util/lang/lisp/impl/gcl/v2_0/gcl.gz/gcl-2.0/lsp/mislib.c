
#include <cmpinclude.h>
#include "mislib.h"
init_mislib(){do_init(VV);}
/*	macro definition for TIME	*/

static L1()
{register object *base=vs_base;
	register object *sup=base+VM1; VC1
	vs_reserve(VM1);
	check_arg(2);
	vs_top=sup;
	{object V1=base[0]->c.c_cdr;
	if(endp(V1))invalid_macro_call();
	base[2]= (V1->c.c_car);
	V1=V1->c.c_cdr;
	if(!endp(V1))invalid_macro_call();}
	base[3]= listA(6,VV[0],VV[1],VV[2],VV[3],list(3,VV[4],VV[5],list(2,VV[6],base[2])),VV[7]);
	vs_top=(vs_base=base+3)+1;
	return;
}
/*	local entry for function LEAP-YEAR-P	*/

static object LI2(V3)

object V3;
{	 VMB2 VMS2 VMV2
TTL:;
	base[1]= (V3);
	base[2]= small_fixnum(4);
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk13)();
	vs_top=sup;
	base[0]= vs_base[0];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk14)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T1;}
	{object V4 = Cnil;
	VMR2(V4)}
T1:;{object V5;
	base[2]= (V3);
	base[3]= small_fixnum(100);
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk13)();
	vs_top=sup;
	base[1]= vs_base[0];
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk14)();
	vs_top=sup;
	base[0]= vs_base[0];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk15)();
	vs_top=sup;
	V5= vs_base[0];
	if(V5==Cnil)goto T6;
	{object V6 = V5;
	VMR2(V6)}
T6:;}
	base[1]= (V3);
	base[2]= small_fixnum(400);
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk13)();
	vs_top=sup;
	base[0]= vs_base[0];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk14)();
	vs_top=sup;
	{object V7 = vs_base[0];
	VMR2(V7)}
}
/*	local entry for function NUMBER-OF-DAYS-FROM-1900	*/

static object LI3(V9)

object V9;
{	 VMB3 VMS3 VMV3
TTL:;
	{object V10;
	V10= one_minus((V9));
	V11= number_minus((V9),VV[8]);
	base[0]= number_times(/* INLINE-ARGS */V11,small_fixnum(365));
	base[2]= (V10);
	base[3]= small_fixnum(4);
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk16)();
	vs_top=sup;
	base[1]= vs_base[0];
	base[3]= (V10);
	base[4]= small_fixnum(100);
	vs_top=(vs_base=base+3)+2;
	(void) (*Lnk16)();
	vs_top=sup;
	V12= vs_base[0];
	base[2]= number_negate(V12);
	base[4]= (V10);
	base[5]= small_fixnum(400);
	vs_top=(vs_base=base+4)+2;
	(void) (*Lnk16)();
	vs_top=sup;
	base[3]= vs_base[0];
	base[4]= small_fixnum(-460);
	vs_top=(vs_base=base+0)+5;
	(void) (*Lnk17)();
	vs_top=sup;
	{object V13 = vs_base[0];
	VMR3(V13)}}
}
/*	function definition for DECODE-UNIVERSAL-TIME	*/

static L4()
{register object *base=vs_base;
	register object *sup=base+VM4; VC4
	vs_reserve(VM4);
	{register object V14;
	object V15;
	if(vs_top-vs_base<1) too_few_arguments();
	if(vs_top-vs_base>2) too_many_arguments();
	V14=(base[0]);
	vs_base=vs_base+1;
	if(vs_base>=vs_top){vs_top=sup;goto T28;}
	V15=(base[1]);
	vs_top=sup;
	goto T29;
T28:;
	V15= symbol_value(VV[9]);
T29:;
	{object V16;
	object V17;
	object V18;
	register object V19;
	register object V20;
	register object V21;
	object V22;
	V16= Cnil;
	V17= Cnil;
	V18= Cnil;
	V19= Cnil;
	V20= Cnil;
	V21= Cnil;
	V22= Cnil;
	V23= number_times((V15),VV[10]);
	V14= number_minus((V14),/* INLINE-ARGS */V23);
	base[2]= (V14);
	base[3]= VV[11];
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk16)();
	if(vs_base<vs_top){
	V19= vs_base[0];
	vs_base++;
	}else{
	V19= Cnil;}
	if(vs_base<vs_top){
	V14= vs_base[0];
	}else{
	V14= Cnil;}
	vs_top=sup;
	base[2]= (V19);
	base[3]= small_fixnum(7);
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk13)();
	vs_top=sup;
	V22= vs_base[0];
	base[2]= (V14);
	base[3]= VV[10];
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk16)();
	if(vs_base<vs_top){
	V18= vs_base[0];
	vs_base++;
	}else{
	V18= Cnil;}
	if(vs_base<vs_top){
	V14= vs_base[0];
	}else{
	V14= Cnil;}
	vs_top=sup;
	base[2]= (V14);
	base[3]= small_fixnum(60);
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk16)();
	if(vs_base<vs_top){
	V17= vs_base[0];
	vs_base++;
	}else{
	V17= Cnil;}
	if(vs_base<vs_top){
	V16= vs_base[0];
	}else{
	V16= Cnil;}
	vs_top=sup;
	base[2]= (V19);
	base[3]= small_fixnum(366);
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk16)();
	vs_top=sup;
	V24= vs_base[0];
	V21= number_plus(VV[8],V24);
	{register object V25;
	V25= Cnil;
T56:;
	V26= (*(LnkLI18))((V21));
	V25= number_minus((V19),/* INLINE-ARGS */V26);
	if(((*(LnkLI19))((V21)))==Cnil){
	goto T63;}
	V27= small_fixnum(366);
	goto T61;
T63:;
	V27= small_fixnum(365);
T61:;
	if(!(number_compare((V25),V27)<0)){
	goto T57;}
	V19= one_plus((V25));
	goto T54;
T57:;
	V21= number_plus((V21),small_fixnum(1));
	goto T56;}
T54:;
	if(((*(LnkLI19))((V21)))==Cnil){
	goto T71;}
	if(!(number_compare((V19),small_fixnum(60))==0)){
	goto T74;}
	base[2]= (V16);
	base[3]= (V17);
	base[4]= (V18);
	base[5]= small_fixnum(29);
	base[6]= small_fixnum(2);
	base[7]= (V21);
	base[8]= (V22);
	base[9]= Cnil;
	base[10]= (V15);
	vs_top=(vs_base=base+2)+9;
	return;
T74:;
	if(!(number_compare((V19),small_fixnum(60))>0)){
	goto T71;}
	V19= number_minus((V19),small_fixnum(1));
T71:;
	{register object V28;
	V28= VV[12];
T91:;
	if(!(number_compare((V19),car((V28)))<=0)){
	goto T92;}
	V29 = make_fixnum(length((V28)));
	V20= number_minus(small_fixnum(13),V29);
	goto T89;
T92:;
	V19= number_minus((V19),car((V28)));
	V28= cdr((V28));
	goto T91;}
T89:;
	base[2]= (V16);
	base[3]= (V17);
	base[4]= (V18);
	base[5]= (V19);
	base[6]= (V20);
	base[7]= (V21);
	base[8]= (V22);
	base[9]= Cnil;
	base[10]= (V15);
	vs_top=(vs_base=base+2)+9;
	return;}
	}
}
/*	local entry for function ENCODE-UNIVERSAL-TIME	*/

static object LI5(V35,V34,V33,V32,V31,V30,va_alist)
	object V35,V34,V33,V32,V31,V30;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB5 VMS5 VMV5
	{object V36;
	object V37;
	object V38;
	object V39;
	object V40;
	register object V41;
	object V42;
	if(narg <6) too_few_arguments();
	V36= V35;
	V37= V34;
	V38= V33;
	V39= V32;
	V40= V31;
	V41= V30;
	narg = narg - 6;
	if (narg <= 0) goto T111;
	else {
	va_start(ap);
	V42= va_arg(ap,object);}
	--narg; goto T112;
T111:;
	V42= symbol_value(VV[9]);
T112:;
	V38= number_plus((V38),(V42));
	base[0]= small_fixnum(0);
	base[1]= (V41);
	base[2]= small_fixnum(99);
	vs_top=(vs_base=base+0)+3;
	(void) (*Lnk20)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T116;}
	{object V43;
	object V44;
	object V45;
	object V46;
	object V47;
	register object V48;
	object V49;
	object V50;
	object V51;
	vs_base=vs_top;
	(void) (*Lnk21)();
	if(vs_base>=vs_top){vs_top=sup;goto T123;}
	V43= vs_base[0];
	vs_base++;
	if(vs_base>=vs_top){vs_top=sup;goto T124;}
	V44= vs_base[0];
	vs_base++;
	if(vs_base>=vs_top){vs_top=sup;goto T125;}
	V45= vs_base[0];
	vs_base++;
	if(vs_base>=vs_top){vs_top=sup;goto T126;}
	V46= vs_base[0];
	vs_base++;
	if(vs_base>=vs_top){vs_top=sup;goto T127;}
	V47= vs_base[0];
	vs_base++;
	if(vs_base>=vs_top){vs_top=sup;goto T128;}
	V48= vs_base[0];
	vs_base++;
	if(vs_base>=vs_top){vs_top=sup;goto T129;}
	V49= vs_base[0];
	vs_base++;
	if(vs_base>=vs_top){vs_top=sup;goto T130;}
	V50= vs_base[0];
	vs_base++;
	if(vs_base>=vs_top){vs_top=sup;goto T131;}
	V51= vs_base[0];
	vs_top=sup;
	goto T132;
T123:;
	V43= Cnil;
T124:;
	V44= Cnil;
T125:;
	V45= Cnil;
T126:;
	V46= Cnil;
T127:;
	V47= Cnil;
T128:;
	V48= Cnil;
T129:;
	V49= Cnil;
T130:;
	V50= Cnil;
T131:;
	V51= Cnil;
T132:;
	base[0]= (V48);
	base[1]= small_fixnum(100);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk13)();
	vs_top=sup;
	V52= vs_base[0];
	V53= number_minus((V48),V52);
	V41= number_plus((V41),/* INLINE-ARGS */V53);
	V54= number_minus((V41),(V48));
	if(!(number_compare(/* INLINE-ARGS */V54,small_fixnum(-50))<0)){
	goto T139;}
	V41= number_plus((V41),small_fixnum(100));
	goto T116;
T139:;
	V55= number_minus((V41),(V48));
	if(!(number_compare(/* INLINE-ARGS */V55,small_fixnum(50))>=0)){
	goto T116;}
	V41= number_minus((V41),small_fixnum(100));}
T116:;
	if(((*(LnkLI19))((V41)))==Cnil){
	goto T146;}
	if(number_compare((V40),small_fixnum(2))>0){
	goto T145;}
T146:;
	V39= number_minus((V39),small_fixnum(1));
T145:;
	base[1]=symbol_function(VV[17]);
	base[2]= (V39);
	base[3]= (*(LnkLI18))((V41));
	{object V57;
	base[4]= VV[12];
	base[5]= number_minus(small_fixnum(13),(V40));
	vs_top=(vs_base=base+4)+2;
	(void) (*Lnk22)();
	vs_top=sup;
	V57= vs_base[0];
	 vs_top=base+4;
	 while(!endp(V57))
	 {vs_push(car(V57));V57=cdr(V57);}
	vs_base=base+2;}
	(void) (*Lnk17)();
	vs_top=sup;
	V56= vs_base[0];
	base[0]= number_times(V56,VV[11]);
	base[1]= number_times((V38),VV[10]);
	base[2]= number_times((V37),small_fixnum(60));
	base[3]= (V36);
	vs_top=(vs_base=base+0)+4;
	(void) (*Lnk17)();
	vs_top=sup;
	{object V58 = vs_base[0];
	VMR5(V58)}}
	}
static LnkT22(){ call_or_link(VV[22],&Lnk22);} /* BUTLAST */
static LnkT21(){ call_or_link(VV[21],&Lnk21);} /* GET-DECODED-TIME */
static LnkT20(){ call_or_link(VV[20],&Lnk20);} /* <= */
static object  LnkTLI19(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[19],&LnkLI19,1,ap);} /* LEAP-YEAR-P */
static object  LnkTLI18(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[18],&LnkLI18,1,ap);} /* NUMBER-OF-DAYS-FROM-1900 */
static LnkT17(){ call_or_link(VV[17],&Lnk17);} /* + */
static LnkT16(){ call_or_link(VV[16],&Lnk16);} /* FLOOR */
static LnkT15(){ call_or_link(VV[15],&Lnk15);} /* NOT */
static LnkT14(){ call_or_link(VV[14],&Lnk14);} /* ZEROP */
static LnkT13(){ call_or_link(VV[13],&Lnk13);} /* MOD */
