
#include <cmpinclude.h>
#include "seqlib.h"
init_seqlib(){do_init(VV);}
/*	local entry for function SEQTYPE	*/

static object LI1(V2)

register object V2;
{	 VMB1 VMS1 VMV1
TTL:;
	if(!(type_of((V2))==t_cons||((V2))==Cnil)){
	goto T2;}
	{object V3 = VV[0];
	VMR1(V3)}
T2:;
	if(!(type_of((V2))==t_string)){
	goto T5;}
	{object V4 = VV[1];
	VMR1(V4)}
T5:;
	if(!((type_of((V2))==t_bitvector))){
	goto T8;}
	{object V5 = VV[2];
	VMR1(V5)}
T8:;
	if(!(type_of((V2))==t_vector||
type_of((V2))==t_string||
type_of((V2))==t_bitvector)){
	goto T11;}
	base[0]= (V2);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk17)();
	vs_top=sup;
	V6= vs_base[0];
	{object V7 = list(2,VV[3],V6);
	VMR1(V7)}
T11:;
	base[0]= VV[4];
	base[1]= (V2);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk18)();
	vs_top=sup;
	{object V8 = vs_base[0];
	VMR1(V8)}
}
/*	local entry for function CALL-TEST	*/

static object LI2(V13,V14,V15,V16)

object V13;object V14;object V15;object V16;
{	 VMB2 VMS2 VMV2
TTL:;
	if(((V13))==Cnil){
	goto T18;}
	base[0]= (V15);
	base[1]= (V16);
	vs_top=(vs_base=base+0)+2;
	super_funcall_no_event((V13));
	vs_top=sup;
	{object V17 = vs_base[0];
	VMR2(V17)}
T18:;
	if(((V14))==Cnil){
	goto T23;}
	base[1]= (V15);
	base[2]= (V16);
	vs_top=(vs_base=base+1)+2;
	super_funcall_no_event((V14));
	vs_top=sup;
	base[0]= vs_base[0];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk19)();
	vs_top=sup;
	{object V18 = vs_base[0];
	VMR2(V18)}
T23:;
	base[0]= (V15);
	base[1]= (V16);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk20)();
	vs_top=sup;
	{object V19 = vs_base[0];
	VMR2(V19)}
}
/*	local entry for function CHECK-SEQ-START-END	*/

static object LI3(V22,V23)

object V22;object V23;
{	 VMB3 VMS3 VMV3
TTL:;
	if(!(type_of((V22))==t_fixnum)){
	goto T31;}
	if(type_of((V23))==t_fixnum){
	goto T30;}
T31:;
	base[0]= VV[5];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk18)();
	vs_top=sup;
T30:;
	if(!((fix((V22)))>(fix((V23))))){
	goto T37;}
	base[0]= VV[6];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk18)();
	vs_top=sup;
	{object V24 = vs_base[0];
	VMR3(V24)}
T37:;
	{object V25 = Cnil;
	VMR3(V25)}
}
/*	local entry for function TEST-ERROR	*/

static object LI4()

{	 VMB4 VMS4 VMV4
TTL:;
	base[0]= VV[7];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk18)();
	vs_top=sup;
	{object V26 = vs_base[0];
	VMR4(V26)}
}
/*	local entry for function BAD-SEQ-LIMIT	*/

static object LI5(V27,va_alist)
	object V27;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB5 VMS5 VMV5
	{object V28;
	object V29;
	if(narg <1) too_few_arguments();
	V28= V27;
	narg = narg - 1;
	if (narg <= 0) goto T41;
	else {
	va_start(ap);
	V29= va_arg(ap,object);}
	--narg; goto T42;
T41:;
	V29= Cnil;
T42:;
	base[0]= VV[8];
	if(((V29))==Cnil){
	goto T47;}
	base[1]= list(2,(V28),(V29));
	goto T45;
T47:;
	base[1]= (V28);
T45:;
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk18)();
	vs_top=sup;
	{object V30 = vs_base[0];
	VMR5(V30)}}
	}
/*	local entry for function THE-END	*/

static int LI6(V33,V34)

register object V33;object V34;
{	 VMB6 VMS6 VMV6
TTL:;
	if(!(type_of((V33))==t_fixnum)){
	goto T50;}{object V35;
	base[0]= (V33);
	base[1]= make_fixnum(length((V34)));
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk21)();
	vs_top=sup;
	V35= vs_base[0];
	if(V35==Cnil)goto T53;
	goto T52;
T53:;}
	(void)((VFUN_NARGS=1,(*(LnkLI22))((V33))));
T52:;
	{int V36 = fix((V33));
	VMR6(V36)}
T50:;
	if(((V33))!=Cnil){
	goto T58;}
	{int V37 = length((V34));
	VMR6(V37)}
T58:;
	{int V38 = fix((VFUN_NARGS=1,(*(LnkLI22))((V33))));
	VMR6(V38)}
}
/*	local entry for function THE-START	*/

static int LI7(V40)

register object V40;
{	 VMB7 VMS7 VMV7
TTL:;
	if(!(type_of((V40))==t_fixnum)){
	goto T61;}{object V41;
	base[0]= (V40);
	base[1]= small_fixnum(0);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk23)();
	vs_top=sup;
	V41= vs_base[0];
	if(V41==Cnil)goto T64;
	goto T63;
T64:;}
	(void)((VFUN_NARGS=1,(*(LnkLI22))((V40))));
T63:;
	{int V42 = fix((V40));
	VMR7(V42)}
T61:;
	if(((V40))!=Cnil){
	goto T69;}
	{int V43 = 0;
	VMR7(V43)}
T69:;
	{int V44 = fix((VFUN_NARGS=1,(*(LnkLI22))((V40))));
	VMR7(V44)}
}
/*	function definition for REDUCE	*/

static L8()
{register object *base=vs_base;
	register object *sup=base+VM8; VC8
	vs_reserve(VM8);
	{register object V45;
	register object V46;
	object V47;
	object V48;
	object V49;
	object V50;
	object V51;
	if(vs_top-vs_base<2) too_few_arguments();
	parse_key(vs_base+2,FALSE,FALSE,4,VV[10],VV[13],VV[14],VV[24]);
	V45=(base[0]);
	V46=(base[1]);
	vs_top=sup;
	V47=(base[2]);
	V48=(base[3]);
	V49=(base[4]);
	V50=(base[5]);
	V51=(base[9]);
	{register int V52;
	if(((V48))==Cnil){
	goto T73;}
	V52= (*(LnkLI25))((V48));
	goto T71;
T73:;
	V52= 0;
T71:;
	{register int V53;
	V53= (*(LnkLI26))((V49),(V46));{object V54;
	base[10]= make_fixnum(V52);
	base[11]= make_fixnum(V53);
	vs_top=(vs_base=base+10)+2;
	(void) (*Lnk21)();
	vs_top=sup;
	V54= vs_base[0];
	if(V54==Cnil)goto T77;
	goto T76;
T77:;}
	V55 = make_fixnum(V52);
	V56 = make_fixnum(V53);
	(void)((VFUN_NARGS=2,(*(LnkLI22))(V55,V56)));
T76:;
	if(((V47))!=Cnil){
	goto T82;}
	if(((V51))!=Cnil){
	goto T84;}
	if(!((V52)>=(V53))){
	goto T87;}
	vs_base=vs_top;
	super_funcall_no_event((V45));
	return;
T87:;
	V50= elt((V46),V52);
	V52= (1)+(V52);
T84:;
	{register object V57;
	V57= (V50);
T94:;
	if(!((V52)>=(V53))){
	goto T95;}
	base[10]= (V57);
	vs_top=(vs_base=base+10)+1;
	return;
T95:;
	{object V59;
	V59= elt((V46),V52);
	V52= (1)+(V52);
	V58= (V59);}
	V57= (
	(type_of((V45)) == t_sfun ?(*(object (*)())(((V45))->sfn.sfn_self)):
	(fcall.fun=((V45)),fcall.argd=2,fcalln))((V57),V58));
	goto T94;}
T82:;
	if(((V51))!=Cnil){
	goto T106;}
	if(!((V52)>=(V53))){
	goto T109;}
	vs_base=vs_top;
	super_funcall_no_event((V45));
	return;
T109:;
	V53= (V53)+(-1);
	V50= elt((V46),V53);
T106:;
	{register object V60;
	V60= (V50);
T116:;
	if(!((V52)>=(V53))){
	goto T117;}
	base[10]= (V60);
	vs_top=(vs_base=base+10)+1;
	return;
T117:;
	V53= (-1)+(V53);
	V61= elt((V46),V53);
	V60= (
	(type_of((V45)) == t_sfun ?(*(object (*)())(((V45))->sfn.sfn_self)):
	(fcall.fun=((V45)),fcall.argd=2,fcalln))(/* INLINE-ARGS */V61,(V60)));
	goto T116;}}}
	}
}
/*	local entry for function FILL	*/

static object LI9(V63,V62,va_alist)
	object V63,V62;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB9 VMS9 VMV9
	{register object V64;
	register object V65;
	object V66;
	object V67;
	if(narg <2) too_few_arguments();
	V64= V63;
	V65= V62;
	narg= narg - 2;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +2,&LI9key,ap);
	V66=(Vcs[2]);
	V67=(Vcs[3]);
	{int V68;
	if(((V66))==Cnil){
	goto T128;}
	V68= (*(LnkLI25))((V66));
	goto T126;
T128:;
	V68= 0;
T126:;
	{register int V69;
	V69= (*(LnkLI26))((V67),(V64));{object V70;
	base[0]= make_fixnum(V68);
	base[1]= make_fixnum(V69);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk21)();
	vs_top=sup;
	V70= vs_base[0];
	if(V70==Cnil)goto T132;
	goto T131;
T132:;}
	V71 = make_fixnum(V68);
	V72 = make_fixnum(V69);
	(void)((VFUN_NARGS=2,(*(LnkLI22))(V71,V72)));
T131:;
	{register int V73;
	V73= V68;
T138:;
	if(!((V73)>=(V69))){
	goto T139;}
	{object V74 = (V64);
	VMR9(V74)}
T139:;
	(void)(elt_set((V64),V73,(V65)));
	V73= (1)+(V73);
	goto T138;}}}}
	}}
/*	local entry for function REPLACE	*/

static object LI10(V76,V75,va_alist)
	object V76,V75;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB10 VMS10 VMV10
	{register object V77;
	object V78;
	object V79;
	object V80;
	object V81;
	object V82;
	if(narg <2) too_few_arguments();
	V77= V76;
	V78= V75;
	narg= narg - 2;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +2,&LI10key,ap);
	V79=(Vcs[2]);
	V80=(Vcs[3]);
	V81=(Vcs[4]);
	V82=(Vcs[5]);
	{int V83;
	if(((V79))==Cnil){
	goto T149;}
	V83= (*(LnkLI25))((V79));
	goto T147;
T149:;
	V83= 0;
T147:;
	{int V84;
	V84= (*(LnkLI26))((V80),(V77));{object V85;
	base[0]= make_fixnum(V83);
	base[1]= make_fixnum(V84);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk21)();
	vs_top=sup;
	V85= vs_base[0];
	if(V85==Cnil)goto T153;
	goto T152;
T153:;}
	V86 = make_fixnum(V83);
	V87 = make_fixnum(V84);
	(void)((VFUN_NARGS=2,(*(LnkLI22))(V86,V87)));
T152:;
	{int V88;
	if(((V81))==Cnil){
	goto T159;}
	V88= (*(LnkLI25))((V81));
	goto T157;
T159:;
	V88= 0;
T157:;
	{int V89;
	V89= (*(LnkLI26))((V82),(V78));{object V90;
	base[0]= make_fixnum(V88);
	base[1]= make_fixnum(V89);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk21)();
	vs_top=sup;
	V90= vs_base[0];
	if(V90==Cnil)goto T163;
	goto T162;
T163:;}
	V91 = make_fixnum(V88);
	V92 = make_fixnum(V89);
	(void)((VFUN_NARGS=2,(*(LnkLI22))(V91,V92)));
T162:;
	if(!(((V77))==((V78)))){
	goto T168;}
	if(!((V83)>(V88))){
	goto T168;}
	{register int V93;
	int V94;
	register int V95;
	register int V96;
	V93= 0;
	if(!(((V84)-(V83))<((V89)-(V88)))){
	goto T175;}
	V94= (V84)-(V83);
	goto T173;
T175:;
	V94= (V89)-(V88);
T173:;
	V95= (V83)+((-1)+(V94));
	V96= (V88)+((-1)+(V94));
T180:;
	if(!((V93)>=(V94))){
	goto T181;}
	{object V97 = (V77);
	VMR10(V97)}
T181:;
	V98= elt((V78),V96);
	(void)(elt_set((V77),V95,/* INLINE-ARGS */V98));
	V93= (1)+(V93);
	V95= (-1)+(V95);
	V96= (-1)+(V96);
	goto T180;}
T168:;
	{register int V99;
	int V100;
	register int V101;
	register int V102;
	V99= 0;
	if(!(((V84)-(V83))<((V89)-(V88)))){
	goto T196;}
	V100= (V84)-(V83);
	goto T194;
T196:;
	V100= (V89)-(V88);
T194:;
	V101= V83;
	V102= V88;
T201:;
	if(!((V99)>=(V100))){
	goto T202;}
	{object V103 = (V77);
	VMR10(V103)}
T202:;
	V104= elt((V78),V102);
	(void)(elt_set((V77),V101,/* INLINE-ARGS */V104));
	V99= (1)+(V99);
	V101= (1)+(V101);
	V102= (1)+(V102);
	goto T201;}}}}}}
	}}
/*	local entry for function REMOVE	*/

static object LI11(V106,V105,va_alist)
	object V106,V105;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB11 VMS11 VMV11
	{object V107;
	object V108;
	object V109;
	object V110;
	object V111;
	object V112;
	object V113;
	object V114;
	object V115;
	if(narg <2) too_few_arguments();
	V107= V106;
	V108= V105;
	narg= narg - 2;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +2,&LI11key,ap);
	V109=(Vcs[2]);
	V110=(Vcs[3]);
	V111=(Vcs[4]);
	V112=(Vcs[5]);
	V113=(Vcs[6]);
	V114=(Vcs[7]);
	if(Vcs[8]==0){
	V115= symbol_function(VV[31]);
	}else{
	V115=(Vcs[8]);}
	{int V116;
	if(((V112))==Cnil){
	goto T215;}
	V116= (*(LnkLI25))((V112));
	goto T213;
T215:;
	V116= 0;
T213:;
	{int V117;
	V117= (*(LnkLI26))((V113),(V108));{object V118;
	base[0]= make_fixnum(V116);
	base[1]= make_fixnum(V117);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk21)();
	vs_top=sup;
	V118= vs_base[0];
	if(V118==Cnil)goto T219;
	goto T218;
T219:;}
	V119 = make_fixnum(V116);
	V120 = make_fixnum(V117);
	(void)((VFUN_NARGS=2,(*(LnkLI22))(V119,V120)));
T218:;
	{int V121;
	if(((V114))!=Cnil){
	goto T225;}
	V121= 2147483647;
	goto T223;
T225:;
	V121= fix((V114));
T223:;
	if((V110)==Cnil){
	goto T228;}
	if((V111)==Cnil){
	goto T228;}
	(void)((*(LnkLI32))());
T228:;
	if(((V109))!=Cnil){
	goto T230;}
	if(!(type_of((V108))==t_cons||((V108))==Cnil)){
	goto T233;}
	{register object V122;
	register object V123;
	V122= (V108);
	V123= Cnil;
	{register int V124;
	V124= 0;
T238:;
	if(!((V124)>=(V116))){
	goto T239;}
	goto T235;
T239:;
	V123= make_cons(car((V122)),(V123));
	{register object V125;
	V125= car((V122));
	V122= cdr((V122));}
	V124= (1)+(V124);
	goto T238;}
T235:;
	{register int V126;
	register int V127;
	V126= V116;
	V127= 0;
T255:;
	if((V126)>=(V117)){
	goto T257;}
	if((V127)>=(V121)){
	goto T257;}
	if(!(endp((V122)))){
	goto T256;}
T257:;
	base[0]= (V123);
	base[1]= (V122);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk33)();
	vs_top=sup;
	{object V128 = vs_base[0];
	VMR11(V128)}
T256:;
	base[0]= car((V122));
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V115));
	vs_top=sup;
	V129= vs_base[0];
	if(((*(LnkLI34))((V110),(V111),(V107),V129))==Cnil){
	goto T268;}
	V127= (1)+(V127);
	{register object V130;
	V130= car((V122));
	V122= cdr((V122));
	goto T266;}
T268:;
	V123= make_cons(car((V122)),(V123));
	{register object V131;
	V131= car((V122));
	V122= cdr((V122));}
T266:;
	V126= (1)+(V126);
	goto T255;}}
T233:;
	V132 = make_fixnum(V116);
	V133 = make_fixnum(V117);
	V134 = make_fixnum(V121);
	{object V135 = (VFUN_NARGS=16,(*(LnkLI35))((V107),(V108),VV[10],(V109),VV[11],(V110),VV[12],(V111),VV[13],V132,VV[14],V133,VV[15],V134,VV[16],(V115)));
	VMR11(V135)}
T230:;
	V136 = make_fixnum(V116);
	V137 = make_fixnum(V117);
	V138 = make_fixnum(V121);
	{object V139 = (VFUN_NARGS=16,(*(LnkLI35))((V107),(V108),VV[10],(V109),VV[11],(V110),VV[12],(V111),VV[13],V136,VV[14],V137,VV[15],V138,VV[16],(V115)));
	VMR11(V139)}}}}}
	}}
/*	local entry for function REMOVE-IF	*/

static object LI12(V141,V140,va_alist)
	object V141,V140;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB12 VMS12 VMV12
	{object V142;
	object V143;
	object V144;
	object V145;
	object V146;
	object V147;
	object V148;
	if(narg <2) too_few_arguments();
	V142= V141;
	V143= V140;
	narg= narg - 2;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +2,&LI12key,ap);
	V144=(Vcs[2]);
	V145=(Vcs[3]);
	V146=(Vcs[4]);
	V147=(Vcs[5]);
	if(Vcs[6]==0){
	V148= symbol_function(VV[31]);
	}else{
	V148=(Vcs[6]);}
	V149= symbol_function(VV[37]);
	{object V150 = (VFUN_NARGS=14,(*(LnkLI36))((V142),(V143),VV[10],(V144),VV[11],V149,VV[13],(V145),VV[14],(V146),VV[15],(V147),VV[16],(V148)));
	VMR12(V150)}}
	}}
/*	local entry for function REMOVE-IF-NOT	*/

static object LI13(V152,V151,va_alist)
	object V152,V151;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB13 VMS13 VMV13
	{object V153;
	object V154;
	object V155;
	object V156;
	object V157;
	object V158;
	object V159;
	if(narg <2) too_few_arguments();
	V153= V152;
	V154= V151;
	narg= narg - 2;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +2,&LI13key,ap);
	V155=(Vcs[2]);
	V156=(Vcs[3]);
	V157=(Vcs[4]);
	V158=(Vcs[5]);
	if(Vcs[6]==0){
	V159= symbol_function(VV[31]);
	}else{
	V159=(Vcs[6]);}
	V160= symbol_function(VV[37]);
	{object V161 = (VFUN_NARGS=14,(*(LnkLI36))((V153),(V154),VV[10],(V155),VV[12],V160,VV[13],(V156),VV[14],(V157),VV[15],(V158),VV[16],(V159)));
	VMR13(V161)}}
	}}
/*	local entry for function DELETE	*/

static object LI14(V163,V162,va_alist)
	object V163,V162;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB14 VMS14 VMV14
	{object V164;
	register object V165;
	object V166;
	object V167;
	object V168;
	object V169;
	object V170;
	object V171;
	object V172;
	if(narg <2) too_few_arguments();
	V164= V163;
	V165= V162;
	narg= narg - 2;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +2,&LI14key,ap);
	V166=(Vcs[2]);
	V167=(Vcs[3]);
	V168=(Vcs[4]);
	V169=(Vcs[5]);
	V170=(Vcs[6]);
	V171=(Vcs[7]);
	if(Vcs[8]==0){
	V172= symbol_function(VV[31]);
	}else{
	V172=(Vcs[8]);}
	{int V173;
	V173= length((V165));
	{register int V174;
	if(((V169))==Cnil){
	goto T293;}
	V174= (*(LnkLI25))((V169));
	goto T291;
T293:;
	V174= 0;
T291:;
	{register int V175;
	V175= (*(LnkLI26))((V170),(V165));{object V176;
	base[0]= make_fixnum(V174);
	base[1]= make_fixnum(V175);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk21)();
	vs_top=sup;
	V176= vs_base[0];
	if(V176==Cnil)goto T297;
	goto T296;
T297:;}
	V177 = make_fixnum(V174);
	V178 = make_fixnum(V175);
	(void)((VFUN_NARGS=2,(*(LnkLI22))(V177,V178)));
T296:;
	{register int V179;
	if(((V171))!=Cnil){
	goto T303;}
	V179= 2147483647;
	goto T301;
T303:;
	V179= fix((V171));
T301:;
	if((V167)==Cnil){
	goto T306;}
	if((V168)==Cnil){
	goto T306;}
	(void)((*(LnkLI32))());
T306:;
	if(((V166))!=Cnil){
	goto T308;}
	if(!(type_of((V165))==t_cons||((V165))==Cnil)){
	goto T311;}
	{object V180;
	register object V181;
	V180= make_cons(Cnil,(V165));
	V181= (V180);
	{int V182;
	V182= 0;
T318:;
	if(!((V182)>=(V174))){
	goto T319;}
	goto T315;
T319:;
	{object V183;
	V183= car((V181));
	V181= cdr((V181));}
	V182= (1)+(V182);
	goto T318;}
T315:;
	{int V184;
	int V185;
	V184= V174;
	V185= 0;
T333:;
	if((V184)>=(V175)){
	goto T335;}
	if((V185)>=(V179)){
	goto T335;}
	if(!(endp(cdr((V181))))){
	goto T334;}
T335:;
	{object V186 = cdr((V180));
	VMR14(V186)}
T334:;
	base[1]= cadr((V181));
	vs_top=(vs_base=base+1)+1;
	super_funcall_no_event((V172));
	vs_top=sup;
	V187= vs_base[0];
	if(((*(LnkLI34))((V167),(V168),(V164),V187))==Cnil){
	goto T344;}
	V185= (1)+(V185);
	if(type_of((V181))!=t_cons)FEwrong_type_argument(Scons,(V181));
	((V181))->c.c_cdr = cddr((V181));
	goto T342;
T344:;
	V181= cdr((V181));
T342:;
	V184= (1)+(V184);
	goto T333;}}
T311:;
	{int V188;
	V189 = make_fixnum(V174);
	V190 = make_fixnum(V175);
	V191 = make_fixnum(V179);
	V188= fix((VFUN_NARGS=16,(*(LnkLI38))((V164),(V165),VV[10],(V166),VV[11],(V167),VV[12],(V168),VV[13],V189,VV[14],V190,VV[15],V191,VV[16],(V172))));
	if(!((V188)<(V179))){
	goto T355;}
	V179= V188;
T355:;
	{object V192;
	register int V193;
	int V194;
	int V195;
	V196= (*(LnkLI40))((V165));
	V197 = make_fixnum((V173)-(V179));
	V192= (VFUN_NARGS=2,(*(LnkLI39))(/* INLINE-ARGS */V196,V197));
	V193= 0;
	V194= 0;
	V195= 0;
T364:;
	if(!((V193)>=(V173))){
	goto T365;}
	{object V198 = (V192);
	VMR14(V198)}
T365:;
	if(!((V174)<=(V193))){
	goto T371;}
	if(!((V193)<(V175))){
	goto T371;}
	if(!((V195)<(V179))){
	goto T371;}
	base[0]= elt((V165),V193);
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V172));
	vs_top=sup;
	V199= vs_base[0];
	if(((*(LnkLI34))((V167),(V168),(V164),V199))==Cnil){
	goto T371;}
	V195= (1)+(V195);
	goto T369;
T371:;
	V200= elt((V165),V193);
	(void)(elt_set((V192),V194,/* INLINE-ARGS */V200));
	V194= (1)+(V194);
T369:;
	V193= (1)+(V193);
	goto T364;}}
T308:;
	{int V201;
	V202 = make_fixnum(V174);
	V203 = make_fixnum(V175);
	V204 = make_fixnum(V179);
	V201= fix((VFUN_NARGS=16,(*(LnkLI38))((V164),(V165),VV[10],(V166),VV[11],(V167),VV[12],(V168),VV[13],V202,VV[14],V203,VV[15],V204,VV[16],(V172))));
	if(!((V201)<(V179))){
	goto T388;}
	V179= V201;
T388:;
	{object V205;
	register int V206;
	int V207;
	int V208;
	V209= (*(LnkLI40))((V165));
	V210 = make_fixnum((V173)-(V179));
	V205= (VFUN_NARGS=2,(*(LnkLI39))(/* INLINE-ARGS */V209,V210));
	V206= (-1)+(V173);
	V207= ((-1)+(V175))-(V201);
	V208= 0;
T397:;
	if(!((V206)<(0))){
	goto T398;}
	{object V211 = (V205);
	VMR14(V211)}
T398:;
	if(!((V174)<=(V206))){
	goto T404;}
	if(!((V206)<(V175))){
	goto T404;}
	if(!((V208)<(V179))){
	goto T404;}
	base[0]= elt((V165),V206);
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V172));
	vs_top=sup;
	V212= vs_base[0];
	if(((*(LnkLI34))((V167),(V168),(V164),V212))==Cnil){
	goto T404;}
	V208= (1)+(V208);
	goto T402;
T404:;
	V213= elt((V165),V206);
	(void)(elt_set((V205),V207,/* INLINE-ARGS */V213));
	V207= (-1)+(V207);
T402:;
	V206= (-1)+(V206);
	goto T397;}}}}}}}
	}}
/*	local entry for function DELETE-IF	*/

static object LI15(V215,V214,va_alist)
	object V215,V214;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB15 VMS15 VMV15
	{object V216;
	object V217;
	object V218;
	object V219;
	object V220;
	object V221;
	object V222;
	if(narg <2) too_few_arguments();
	V216= V215;
	V217= V214;
	narg= narg - 2;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +2,&LI15key,ap);
	V218=(Vcs[2]);
	V219=(Vcs[3]);
	V220=(Vcs[4]);
	V221=(Vcs[5]);
	if(Vcs[6]==0){
	V222= symbol_function(VV[31]);
	}else{
	V222=(Vcs[6]);}
	V223= symbol_function(VV[37]);
	{object V224 = (VFUN_NARGS=14,(*(LnkLI35))((V216),(V217),VV[10],(V218),VV[11],V223,VV[13],(V219),VV[14],(V220),VV[15],(V221),VV[16],(V222)));
	VMR15(V224)}}
	}}
/*	local entry for function DELETE-IF-NOT	*/

static object LI16(V226,V225,va_alist)
	object V226,V225;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB16 VMS16 VMV16
	{object V227;
	object V228;
	object V229;
	object V230;
	object V231;
	object V232;
	object V233;
	if(narg <2) too_few_arguments();
	V227= V226;
	V228= V225;
	narg= narg - 2;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +2,&LI16key,ap);
	V229=(Vcs[2]);
	V230=(Vcs[3]);
	V231=(Vcs[4]);
	V232=(Vcs[5]);
	if(Vcs[6]==0){
	V233= symbol_function(VV[31]);
	}else{
	V233=(Vcs[6]);}
	V234= symbol_function(VV[37]);
	{object V235 = (VFUN_NARGS=14,(*(LnkLI35))((V227),(V228),VV[10],(V229),VV[12],V234,VV[13],(V230),VV[14],(V231),VV[15],(V232),VV[16],(V233)));
	VMR16(V235)}}
	}}
/*	local entry for function COUNT	*/

static object LI17(V237,V236,va_alist)
	object V237,V236;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB17 VMS17 VMV17
	{object V238;
	register object V239;
	object V240;
	register object V241;
	register object V242;
	object V243;
	object V244;
	object V245;
	if(narg <2) too_few_arguments();
	V238= V237;
	V239= V236;
	narg= narg - 2;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +2,&LI17key,ap);
	V240=(Vcs[2]);
	V241=(Vcs[3]);
	V242=(Vcs[4]);
	V243=(Vcs[5]);
	V244=(Vcs[6]);
	if(Vcs[7]==0){
	V245= symbol_function(VV[31]);
	}else{
	V245=(Vcs[7]);}
	{int V246;
	if(((V243))==Cnil){
	goto T427;}
	V246= (*(LnkLI25))((V243));
	goto T425;
T427:;
	V246= 0;
T425:;
	{int V247;
	V247= (*(LnkLI26))((V244),(V239));{object V248;
	base[0]= make_fixnum(V246);
	base[1]= make_fixnum(V247);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk21)();
	vs_top=sup;
	V248= vs_base[0];
	if(V248==Cnil)goto T431;
	goto T430;
T431:;}
	V249 = make_fixnum(V246);
	V250 = make_fixnum(V247);
	(void)((VFUN_NARGS=2,(*(LnkLI22))(V249,V250)));
T430:;
	if((V241)==Cnil){
	goto T435;}
	if((V242)==Cnil){
	goto T435;}
	(void)((*(LnkLI32))());
T435:;
	if(((V240))!=Cnil){
	goto T437;}
	{register int V251;
	register int V252;
	V251= V246;
	V252= 0;
T442:;
	if(!((V251)>=(V247))){
	goto T443;}
	{object V253 = make_fixnum(V252);
	VMR17(V253)}
T443:;
	base[0]= elt((V239),V251);
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V245));
	vs_top=sup;
	V254= vs_base[0];
	if(((*(LnkLI34))((V241),(V242),(V238),V254))==Cnil){
	goto T447;}
	V252= (1)+(V252);
T447:;
	V251= (1)+(V251);
	goto T442;}
T437:;
	{register int V255;
	register int V256;
	V255= (-1)+(V247);
	V256= 0;
T459:;
	if(!((V255)<(V246))){
	goto T460;}
	{object V257 = make_fixnum(V256);
	VMR17(V257)}
T460:;
	base[0]= elt((V239),V255);
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V245));
	vs_top=sup;
	V258= vs_base[0];
	if(((*(LnkLI34))((V241),(V242),(V238),V258))==Cnil){
	goto T464;}
	V256= (1)+(V256);
T464:;
	V255= (-1)+(V255);
	goto T459;}}}}
	}}
/*	local entry for function COUNT-IF	*/

static object LI18(V260,V259,va_alist)
	object V260,V259;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB18 VMS18 VMV18
	{object V261;
	object V262;
	object V263;
	object V264;
	object V265;
	object V266;
	if(narg <2) too_few_arguments();
	V261= V260;
	V262= V259;
	narg= narg - 2;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +2,&LI18key,ap);
	V263=(Vcs[2]);
	V264=(Vcs[3]);
	V265=(Vcs[4]);
	if(Vcs[5]==0){
	V266= symbol_function(VV[31]);
	}else{
	V266=(Vcs[5]);}
	V267= symbol_function(VV[37]);
	{object V268 = (VFUN_NARGS=12,(*(LnkLI41))((V261),(V262),VV[10],(V263),VV[11],V267,VV[13],(V264),VV[14],(V265),VV[16],(V266)));
	VMR18(V268)}}
	}}
/*	local entry for function COUNT-IF-NOT	*/

static object LI19(V270,V269,va_alist)
	object V270,V269;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB19 VMS19 VMV19
	{object V271;
	object V272;
	object V273;
	object V274;
	object V275;
	object V276;
	if(narg <2) too_few_arguments();
	V271= V270;
	V272= V269;
	narg= narg - 2;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +2,&LI19key,ap);
	V273=(Vcs[2]);
	V274=(Vcs[3]);
	V275=(Vcs[4]);
	if(Vcs[5]==0){
	V276= symbol_function(VV[31]);
	}else{
	V276=(Vcs[5]);}
	V277= symbol_function(VV[37]);
	{object V278 = (VFUN_NARGS=12,(*(LnkLI41))((V271),(V272),VV[10],(V273),VV[12],V277,VV[13],(V274),VV[14],(V275),VV[16],(V276)));
	VMR19(V278)}}
	}}
/*	local entry for function INTERNAL-COUNT	*/

static object LI20(V280,V279,va_alist)
	object V280,V279;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB20 VMS20 VMV20
	{object V281;
	register object V282;
	object V283;
	register object V284;
	register object V285;
	object V286;
	object V287;
	object V288;
	object V289;
	if(narg <2) too_few_arguments();
	V281= V280;
	V282= V279;
	narg= narg - 2;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +2,&LI20key,ap);
	V283=(Vcs[2]);
	V284=(Vcs[3]);
	V285=(Vcs[4]);
	V286=(Vcs[5]);
	V287=(Vcs[6]);
	V288=(Vcs[7]);
	if(Vcs[8]==0){
	V289= symbol_function(VV[31]);
	}else{
	V289=(Vcs[8]);}
	{int V290;
	if(((V286))==Cnil){
	goto T480;}
	V290= (*(LnkLI25))((V286));
	goto T478;
T480:;
	V290= 0;
T478:;
	{int V291;
	V291= (*(LnkLI26))((V287),(V282));{object V292;
	base[0]= make_fixnum(V290);
	base[1]= make_fixnum(V291);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk21)();
	vs_top=sup;
	V292= vs_base[0];
	if(V292==Cnil)goto T484;
	goto T483;
T484:;}
	V293 = make_fixnum(V290);
	V294 = make_fixnum(V291);
	(void)((VFUN_NARGS=2,(*(LnkLI22))(V293,V294)));
T483:;
	{int V295;
	if(((V288))!=Cnil){
	goto T490;}
	V295= 2147483647;
	goto T488;
T490:;
	V295= fix((V288));
T488:;
	if((V284)==Cnil){
	goto T493;}
	if((V285)==Cnil){
	goto T493;}
	(void)((*(LnkLI32))());
T493:;
	if(((V283))!=Cnil){
	goto T495;}
	{register int V296;
	register int V297;
	V296= V290;
	V297= 0;
T500:;
	if(!((V296)>=(V291))){
	goto T501;}
	{object V298 = make_fixnum(V297);
	VMR20(V298)}
T501:;
	if(!((V297)<(V295))){
	goto T505;}
	base[0]= elt((V282),V296);
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V289));
	vs_top=sup;
	V299= vs_base[0];
	if(((*(LnkLI34))((V284),(V285),(V281),V299))==Cnil){
	goto T505;}
	V297= (1)+(V297);
T505:;
	V296= (1)+(V296);
	goto T500;}
T495:;
	{register int V300;
	register int V301;
	V300= (-1)+(V291);
	V301= 0;
T519:;
	if(!((V300)<(V290))){
	goto T520;}
	{object V302 = make_fixnum(V301);
	VMR20(V302)}
T520:;
	if(!((V301)<(V295))){
	goto T524;}
	base[0]= elt((V282),V300);
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V289));
	vs_top=sup;
	V303= vs_base[0];
	if(((*(LnkLI34))((V284),(V285),(V281),V303))==Cnil){
	goto T524;}
	V301= (1)+(V301);
T524:;
	V300= (-1)+(V300);
	goto T519;}}}}}
	}}
/*	local entry for function INTERNAL-COUNT-IF	*/

static object LI21(V305,V304,va_alist)
	object V305,V304;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB21 VMS21 VMV21
	{object V306;
	object V307;
	object V308;
	object V309;
	object V310;
	object V311;
	object V312;
	if(narg <2) too_few_arguments();
	V306= V305;
	V307= V304;
	narg= narg - 2;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +2,&LI21key,ap);
	V308=(Vcs[2]);
	V309=(Vcs[3]);
	V310=(Vcs[4]);
	V311=(Vcs[5]);
	if(Vcs[6]==0){
	V312= symbol_function(VV[31]);
	}else{
	V312=(Vcs[6]);}
	V313= symbol_function(VV[37]);
	{object V314 = (VFUN_NARGS=14,(*(LnkLI38))((V306),(V307),VV[10],(V308),VV[11],V313,VV[13],(V309),VV[14],(V310),VV[15],(V311),VV[16],(V312)));
	VMR21(V314)}}
	}}
/*	local entry for function INTERNAL-COUNT-IF-NOT	*/

static object LI22(V316,V315,va_alist)
	object V316,V315;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB22 VMS22 VMV22
	{object V317;
	object V318;
	object V319;
	object V320;
	object V321;
	object V322;
	object V323;
	if(narg <2) too_few_arguments();
	V317= V316;
	V318= V315;
	narg= narg - 2;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +2,&LI22key,ap);
	V319=(Vcs[2]);
	V320=(Vcs[3]);
	V321=(Vcs[4]);
	V322=(Vcs[5]);
	if(Vcs[6]==0){
	V323= symbol_function(VV[31]);
	}else{
	V323=(Vcs[6]);}
	V324= symbol_function(VV[37]);
	{object V325 = (VFUN_NARGS=14,(*(LnkLI38))((V317),(V318),VV[10],(V319),VV[12],V324,VV[13],(V320),VV[14],(V321),VV[15],(V322),VV[16],(V323)));
	VMR22(V325)}}
	}}
/*	local entry for function SUBSTITUTE	*/

static object LI23(V328,V327,V326,va_alist)
	object V328,V327,V326;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB23 VMS23 VMV23
	{object V329;
	object V330;
	register object V331;
	object V332;
	object V333;
	object V334;
	object V335;
	object V336;
	object V337;
	object V338;
	if(narg <3) too_few_arguments();
	V329= V328;
	V330= V327;
	V331= V326;
	narg= narg - 3;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +3,&LI23key,ap);
	V332=(Vcs[3]);
	V333=(Vcs[4]);
	V334=(Vcs[5]);
	V335=(Vcs[6]);
	V336=(Vcs[7]);
	V337=(Vcs[8]);
	if(Vcs[9]==0){
	V338= symbol_function(VV[31]);
	}else{
	V338=(Vcs[9]);}
	{int V339;
	V339= length((V331));
	{int V340;
	if(((V335))==Cnil){
	goto T543;}
	V340= (*(LnkLI25))((V335));
	goto T541;
T543:;
	V340= 0;
T541:;
	{int V341;
	V341= (*(LnkLI26))((V336),(V331));{object V342;
	base[0]= make_fixnum(V340);
	base[1]= make_fixnum(V341);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk21)();
	vs_top=sup;
	V342= vs_base[0];
	if(V342==Cnil)goto T547;
	goto T546;
T547:;}
	V343 = make_fixnum(V340);
	V344 = make_fixnum(V341);
	(void)((VFUN_NARGS=2,(*(LnkLI22))(V343,V344)));
T546:;
	{int V345;
	if(((V337))!=Cnil){
	goto T553;}
	V345= 2147483647;
	goto T551;
T553:;
	V345= fix((V337));
T551:;
	if((V333)==Cnil){
	goto T556;}
	if((V334)==Cnil){
	goto T556;}
	(void)((*(LnkLI32))());
T556:;
	if(((V332))!=Cnil){
	goto T558;}
	{register object V346;
	register int V347;
	register int V348;
	V349= (*(LnkLI40))((V331));
	V350 = make_fixnum(V339);
	V346= (VFUN_NARGS=2,(*(LnkLI39))(/* INLINE-ARGS */V349,V350));
	V347= 0;
	V348= 0;
T564:;
	if(!((V347)>=(V339))){
	goto T565;}
	{object V351 = (V346);
	VMR23(V351)}
T565:;
	if(!((V340)<=(V347))){
	goto T571;}
	if(!((V347)<(V341))){
	goto T571;}
	if(!((V348)<(V345))){
	goto T571;}
	base[0]= elt((V331),V347);
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V338));
	vs_top=sup;
	V352= vs_base[0];
	if(((*(LnkLI34))((V333),(V334),(V330),V352))==Cnil){
	goto T571;}
	(void)(elt_set((V346),V347,(V329)));
	V348= (1)+(V348);
	goto T569;
T571:;
	V353= elt((V331),V347);
	(void)(elt_set((V346),V347,/* INLINE-ARGS */V353));
T569:;
	V347= (1)+(V347);
	goto T564;}
T558:;
	{register object V354;
	register int V355;
	register int V356;
	V357= (*(LnkLI40))((V331));
	V358 = make_fixnum(V339);
	V354= (VFUN_NARGS=2,(*(LnkLI39))(/* INLINE-ARGS */V357,V358));
	V355= (-1)+(V339);
	V356= 0;
T590:;
	if(!((V355)<(0))){
	goto T591;}
	{object V359 = (V354);
	VMR23(V359)}
T591:;
	if(!((V340)<=(V355))){
	goto T597;}
	if(!((V355)<(V341))){
	goto T597;}
	if(!((V356)<(V345))){
	goto T597;}
	base[0]= elt((V331),V355);
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V338));
	vs_top=sup;
	V360= vs_base[0];
	if(((*(LnkLI34))((V333),(V334),(V330),V360))==Cnil){
	goto T597;}
	(void)(elt_set((V354),V355,(V329)));
	V356= (1)+(V356);
	goto T595;
T597:;
	V361= elt((V331),V355);
	(void)(elt_set((V354),V355,/* INLINE-ARGS */V361));
T595:;
	V355= (-1)+(V355);
	goto T590;}}}}}}
	}}
/*	local entry for function SUBSTITUTE-IF	*/

static object LI24(V364,V363,V362,va_alist)
	object V364,V363,V362;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB24 VMS24 VMV24
	{object V365;
	object V366;
	object V367;
	object V368;
	object V369;
	object V370;
	object V371;
	object V372;
	if(narg <3) too_few_arguments();
	V365= V364;
	V366= V363;
	V367= V362;
	narg= narg - 3;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +3,&LI24key,ap);
	V368=(Vcs[3]);
	V369=(Vcs[4]);
	V370=(Vcs[5]);
	V371=(Vcs[6]);
	if(Vcs[7]==0){
	V372= symbol_function(VV[31]);
	}else{
	V372=(Vcs[7]);}
	V373= symbol_function(VV[37]);
	{object V374 = (VFUN_NARGS=15,(*(LnkLI42))((V365),(V366),(V367),VV[10],(V368),VV[11],V373,VV[13],(V369),VV[14],(V370),VV[15],(V371),VV[16],(V372)));
	VMR24(V374)}}
	}}
/*	local entry for function SUBSTITUTE-IF-NOT	*/

static object LI25(V377,V376,V375,va_alist)
	object V377,V376,V375;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB25 VMS25 VMV25
	{object V378;
	object V379;
	object V380;
	object V381;
	object V382;
	object V383;
	object V384;
	object V385;
	if(narg <3) too_few_arguments();
	V378= V377;
	V379= V376;
	V380= V375;
	narg= narg - 3;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +3,&LI25key,ap);
	V381=(Vcs[3]);
	V382=(Vcs[4]);
	V383=(Vcs[5]);
	V384=(Vcs[6]);
	if(Vcs[7]==0){
	V385= symbol_function(VV[31]);
	}else{
	V385=(Vcs[7]);}
	V386= symbol_function(VV[37]);
	{object V387 = (VFUN_NARGS=15,(*(LnkLI42))((V378),(V379),(V380),VV[10],(V381),VV[12],V386,VV[13],(V382),VV[14],(V383),VV[15],(V384),VV[16],(V385)));
	VMR25(V387)}}
	}}
/*	local entry for function NSUBSTITUTE	*/

static object LI26(V390,V389,V388,va_alist)
	object V390,V389,V388;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB26 VMS26 VMV26
	{object V391;
	object V392;
	register object V393;
	object V394;
	register object V395;
	register object V396;
	object V397;
	object V398;
	object V399;
	object V400;
	if(narg <3) too_few_arguments();
	V391= V390;
	V392= V389;
	V393= V388;
	narg= narg - 3;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +3,&LI26key,ap);
	V394=(Vcs[3]);
	V395=(Vcs[4]);
	V396=(Vcs[5]);
	V397=(Vcs[6]);
	V398=(Vcs[7]);
	V399=(Vcs[8]);
	if(Vcs[9]==0){
	V400= symbol_function(VV[31]);
	}else{
	V400=(Vcs[9]);}
	{int V401;
	if(((V397))==Cnil){
	goto T619;}
	V401= (*(LnkLI25))((V397));
	goto T617;
T619:;
	V401= 0;
T617:;
	{int V402;
	V402= (*(LnkLI26))((V398),(V393));{object V403;
	base[0]= make_fixnum(V401);
	base[1]= make_fixnum(V402);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk21)();
	vs_top=sup;
	V403= vs_base[0];
	if(V403==Cnil)goto T623;
	goto T622;
T623:;}
	V404 = make_fixnum(V401);
	V405 = make_fixnum(V402);
	(void)((VFUN_NARGS=2,(*(LnkLI22))(V404,V405)));
T622:;
	{int V406;
	if(((V399))!=Cnil){
	goto T629;}
	V406= 2147483647;
	goto T627;
T629:;
	V406= fix((V399));
T627:;
	if((V395)==Cnil){
	goto T632;}
	if((V396)==Cnil){
	goto T632;}
	(void)((*(LnkLI32))());
T632:;
	if(((V394))!=Cnil){
	goto T634;}
	{register int V407;
	register int V408;
	V407= V401;
	V408= 0;
T639:;
	if(!((V407)>=(V402))){
	goto T640;}
	{object V409 = (V393);
	VMR26(V409)}
T640:;
	if(!((V408)<(V406))){
	goto T644;}
	base[0]= elt((V393),V407);
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V400));
	vs_top=sup;
	V410= vs_base[0];
	if(((*(LnkLI34))((V395),(V396),(V392),V410))==Cnil){
	goto T644;}
	(void)(elt_set((V393),V407,(V391)));
	V408= (1)+(V408);
T644:;
	V407= (1)+(V407);
	goto T639;}
T634:;
	{register int V411;
	register int V412;
	V411= (-1)+(V402);
	V412= 0;
T659:;
	if(!((V411)<(V401))){
	goto T660;}
	{object V413 = (V393);
	VMR26(V413)}
T660:;
	if(!((V412)<(V406))){
	goto T664;}
	base[0]= elt((V393),V411);
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V400));
	vs_top=sup;
	V414= vs_base[0];
	if(((*(LnkLI34))((V395),(V396),(V392),V414))==Cnil){
	goto T664;}
	(void)(elt_set((V393),V411,(V391)));
	V412= (1)+(V412);
T664:;
	V411= (-1)+(V411);
	goto T659;}}}}}
	}}
/*	local entry for function NSUBSTITUTE-IF	*/

static object LI27(V417,V416,V415,va_alist)
	object V417,V416,V415;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB27 VMS27 VMV27
	{object V418;
	object V419;
	object V420;
	object V421;
	object V422;
	object V423;
	object V424;
	object V425;
	if(narg <3) too_few_arguments();
	V418= V417;
	V419= V416;
	V420= V415;
	narg= narg - 3;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +3,&LI27key,ap);
	V421=(Vcs[3]);
	V422=(Vcs[4]);
	V423=(Vcs[5]);
	V424=(Vcs[6]);
	if(Vcs[7]==0){
	V425= symbol_function(VV[31]);
	}else{
	V425=(Vcs[7]);}
	V426= symbol_function(VV[37]);
	{object V427 = (VFUN_NARGS=15,(*(LnkLI43))((V418),(V419),(V420),VV[10],(V421),VV[11],V426,VV[13],(V422),VV[14],(V423),VV[15],(V424),VV[16],(V425)));
	VMR27(V427)}}
	}}
/*	local entry for function NSUBSTITUTE-IF-NOT	*/

static object LI28(V430,V429,V428,va_alist)
	object V430,V429,V428;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB28 VMS28 VMV28
	{object V431;
	object V432;
	object V433;
	object V434;
	object V435;
	object V436;
	object V437;
	object V438;
	if(narg <3) too_few_arguments();
	V431= V430;
	V432= V429;
	V433= V428;
	narg= narg - 3;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +3,&LI28key,ap);
	V434=(Vcs[3]);
	V435=(Vcs[4]);
	V436=(Vcs[5]);
	V437=(Vcs[6]);
	if(Vcs[7]==0){
	V438= symbol_function(VV[31]);
	}else{
	V438=(Vcs[7]);}
	V439= symbol_function(VV[37]);
	{object V440 = (VFUN_NARGS=15,(*(LnkLI43))((V431),(V432),(V433),VV[10],(V434),VV[12],V439,VV[13],(V435),VV[14],(V436),VV[15],(V437),VV[16],(V438)));
	VMR28(V440)}}
	}}
/*	local entry for function FIND	*/

static object LI29(V442,V441,va_alist)
	object V442,V441;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB29 VMS29 VMV29
	{register object V443;
	register object V444;
	object V445;
	register object V446;
	register object V447;
	object V448;
	object V449;
	register object V450;
	if(narg <2) too_few_arguments();
	V443= V442;
	V444= V441;
	narg= narg - 2;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +2,&LI29key,ap);
	V445=(Vcs[2]);
	V446=(Vcs[3]);
	V447=(Vcs[4]);
	V448=(Vcs[5]);
	V449=(Vcs[6]);
	if(Vcs[7]==0){
	V450= symbol_function(VV[31]);
	}else{
	V450=(Vcs[7]);}
	{int V451;
	if(((V448))==Cnil){
	goto T683;}
	V451= (*(LnkLI25))((V448));
	goto T681;
T683:;
	V451= 0;
T681:;
	{int V452;
	V452= (*(LnkLI26))((V449),(V444));{object V453;
	base[0]= make_fixnum(V451);
	base[1]= make_fixnum(V452);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk21)();
	vs_top=sup;
	V453= vs_base[0];
	if(V453==Cnil)goto T687;
	goto T686;
T687:;}
	V454 = make_fixnum(V451);
	V455 = make_fixnum(V452);
	(void)((VFUN_NARGS=2,(*(LnkLI22))(V454,V455)));
T686:;
	if((V446)==Cnil){
	goto T691;}
	if((V447)==Cnil){
	goto T691;}
	(void)((*(LnkLI32))());
T691:;
	if(((V445))!=Cnil){
	goto T693;}
	{register int V456;
	V456= V451;
T697:;
	if(!((V456)>=(V452))){
	goto T698;}
	{object V457 = Cnil;
	VMR29(V457)}
T698:;
	base[0]= elt((V444),V456);
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V450));
	vs_top=sup;
	V458= vs_base[0];
	if(((*(LnkLI34))((V446),(V447),(V443),V458))==Cnil){
	goto T702;}
	{object V459 = elt((V444),V456);
	VMR29(V459)}
T702:;
	V456= (1)+(V456);
	goto T697;}
T693:;
	{register int V460;
	V460= (-1)+(V452);
T712:;
	if(!((V460)<(V451))){
	goto T713;}
	{object V461 = Cnil;
	VMR29(V461)}
T713:;
	base[0]= elt((V444),V460);
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V450));
	vs_top=sup;
	V462= vs_base[0];
	if(((*(LnkLI34))((V446),(V447),(V443),V462))==Cnil){
	goto T717;}
	{object V463 = elt((V444),V460);
	VMR29(V463)}
T717:;
	V460= (-1)+(V460);
	goto T712;}}}}
	}}
/*	local entry for function FIND-IF	*/

static object LI30(V465,V464,va_alist)
	object V465,V464;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB30 VMS30 VMV30
	{object V466;
	object V467;
	object V468;
	object V469;
	object V470;
	object V471;
	if(narg <2) too_few_arguments();
	V466= V465;
	V467= V464;
	narg= narg - 2;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +2,&LI30key,ap);
	V468=(Vcs[2]);
	V469=(Vcs[3]);
	V470=(Vcs[4]);
	if(Vcs[5]==0){
	V471= symbol_function(VV[31]);
	}else{
	V471=(Vcs[5]);}
	V472= symbol_function(VV[37]);
	{object V473 = (VFUN_NARGS=12,(*(LnkLI44))((V466),(V467),VV[10],(V468),VV[11],V472,VV[13],(V469),VV[14],(V470),VV[16],(V471)));
	VMR30(V473)}}
	}}
/*	local entry for function FIND-IF-NOT	*/

static object LI31(V475,V474,va_alist)
	object V475,V474;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB31 VMS31 VMV31
	{object V476;
	object V477;
	object V478;
	object V479;
	object V480;
	object V481;
	if(narg <2) too_few_arguments();
	V476= V475;
	V477= V474;
	narg= narg - 2;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +2,&LI31key,ap);
	V478=(Vcs[2]);
	V479=(Vcs[3]);
	V480=(Vcs[4]);
	if(Vcs[5]==0){
	V481= symbol_function(VV[31]);
	}else{
	V481=(Vcs[5]);}
	V482= symbol_function(VV[37]);
	{object V483 = (VFUN_NARGS=12,(*(LnkLI44))((V476),(V477),VV[10],(V478),VV[12],V482,VV[13],(V479),VV[14],(V480),VV[16],(V481)));
	VMR31(V483)}}
	}}
/*	local entry for function POSITION	*/

static object LI32(V485,V484,va_alist)
	object V485,V484;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB32 VMS32 VMV32
	{register object V486;
	register object V487;
	object V488;
	register object V489;
	register object V490;
	object V491;
	object V492;
	register object V493;
	if(narg <2) too_few_arguments();
	V486= V485;
	V487= V484;
	narg= narg - 2;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +2,&LI32key,ap);
	V488=(Vcs[2]);
	V489=(Vcs[3]);
	V490=(Vcs[4]);
	V491=(Vcs[5]);
	V492=(Vcs[6]);
	if(Vcs[7]==0){
	V493= symbol_function(VV[31]);
	}else{
	V493=(Vcs[7]);}
	{int V494;
	if(((V491))==Cnil){
	goto T732;}
	V494= (*(LnkLI25))((V491));
	goto T730;
T732:;
	V494= 0;
T730:;
	{int V495;
	V495= (*(LnkLI26))((V492),(V487));{object V496;
	base[0]= make_fixnum(V494);
	base[1]= make_fixnum(V495);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk21)();
	vs_top=sup;
	V496= vs_base[0];
	if(V496==Cnil)goto T736;
	goto T735;
T736:;}
	V497 = make_fixnum(V494);
	V498 = make_fixnum(V495);
	(void)((VFUN_NARGS=2,(*(LnkLI22))(V497,V498)));
T735:;
	if((V489)==Cnil){
	goto T740;}
	if((V490)==Cnil){
	goto T740;}
	(void)((*(LnkLI32))());
T740:;
	if(((V488))!=Cnil){
	goto T742;}
	{register int V499;
	V499= V494;
T746:;
	if(!((V499)>=(V495))){
	goto T747;}
	{object V500 = Cnil;
	VMR32(V500)}
T747:;
	base[0]= elt((V487),V499);
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V493));
	vs_top=sup;
	V501= vs_base[0];
	if(((*(LnkLI34))((V489),(V490),(V486),V501))==Cnil){
	goto T751;}
	{object V502 = make_fixnum(V499);
	VMR32(V502)}
T751:;
	V499= (1)+(V499);
	goto T746;}
T742:;
	{register int V503;
	V503= (-1)+(V495);
T761:;
	if(!((V503)<(V494))){
	goto T762;}
	{object V504 = Cnil;
	VMR32(V504)}
T762:;
	base[0]= elt((V487),V503);
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V493));
	vs_top=sup;
	V505= vs_base[0];
	if(((*(LnkLI34))((V489),(V490),(V486),V505))==Cnil){
	goto T766;}
	{object V506 = make_fixnum(V503);
	VMR32(V506)}
T766:;
	V503= (-1)+(V503);
	goto T761;}}}}
	}}
/*	local entry for function POSITION-IF	*/

static object LI33(V508,V507,va_alist)
	object V508,V507;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB33 VMS33 VMV33
	{object V509;
	object V510;
	object V511;
	object V512;
	object V513;
	object V514;
	if(narg <2) too_few_arguments();
	V509= V508;
	V510= V507;
	narg= narg - 2;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +2,&LI33key,ap);
	V511=(Vcs[2]);
	V512=(Vcs[3]);
	V513=(Vcs[4]);
	if(Vcs[5]==0){
	V514= symbol_function(VV[31]);
	}else{
	V514=(Vcs[5]);}
	V515= symbol_function(VV[37]);
	{object V516 = (VFUN_NARGS=12,(*(LnkLI45))((V509),(V510),VV[10],(V511),VV[11],V515,VV[13],(V512),VV[14],(V513),VV[16],(V514)));
	VMR33(V516)}}
	}}
/*	local entry for function POSITION-IF-NOT	*/

static object LI34(V518,V517,va_alist)
	object V518,V517;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB34 VMS34 VMV34
	{object V519;
	object V520;
	object V521;
	object V522;
	object V523;
	object V524;
	if(narg <2) too_few_arguments();
	V519= V518;
	V520= V517;
	narg= narg - 2;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +2,&LI34key,ap);
	V521=(Vcs[2]);
	V522=(Vcs[3]);
	V523=(Vcs[4]);
	if(Vcs[5]==0){
	V524= symbol_function(VV[31]);
	}else{
	V524=(Vcs[5]);}
	V525= symbol_function(VV[37]);
	{object V526 = (VFUN_NARGS=12,(*(LnkLI45))((V519),(V520),VV[10],(V521),VV[12],V525,VV[13],(V522),VV[14],(V523),VV[16],(V524)));
	VMR34(V526)}}
	}}
/*	local entry for function REMOVE-DUPLICATES	*/

static object LI35(V527,va_alist)
	object V527;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB35 VMS35 VMV35
	{register object V528;
	object V529;
	register object V530;
	register object V531;
	object V532;
	object V533;
	register object V534;
	if(narg <1) too_few_arguments();
	V528= V527;
	narg= narg - 1;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +1,&LI35key,ap);
	V529=(Vcs[1]);
	V530=(Vcs[2]);
	V531=(Vcs[3]);
	V532=(Vcs[4]);
	V533=(Vcs[5]);
	if(Vcs[6]==0){
	V534= symbol_function(VV[31]);
	}else{
	V534=(Vcs[6]);}
	if((V530)==Cnil){
	goto T779;}
	if((V531)==Cnil){
	goto T779;}
	(void)((*(LnkLI32))());
T779:;
	if(!(type_of((V528))==t_cons||((V528))==Cnil)){
	goto T780;}
	if(((V529))!=Cnil){
	goto T780;}
	if(((V532))!=Cnil){
	goto T780;}
	if(((V533))!=Cnil){
	goto T780;}
	if(!(endp((V528)))){
	goto T789;}
	{object V535 = Cnil;
	VMR35(V535)}
T789:;
	{register object V536;
	register object V537;
	V536= (V528);
	V537= Cnil;
T793:;
	if(!(endp(cdr((V536))))){
	goto T794;}
	base[0]= (V537);
	base[1]= (V536);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk33)();
	vs_top=sup;
	{object V538 = vs_base[0];
	VMR35(V538)}
T794:;
	base[0]= car((V536));
	base[1]= cdr((V536));
	base[2]= VV[11];
	base[3]= (V530);
	base[4]= VV[12];
	base[5]= (V531);
	base[6]= VV[16];
	base[7]= (V534);
	vs_top=(vs_base=base+0)+8;
	(void) (*Lnk46)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T800;}
	V537= make_cons(car((V536)),(V537));
T800:;
	V536= cdr((V536));
	goto T793;}
T780:;
	{object V539 = (VFUN_NARGS=13,(*(LnkLI47))((V528),VV[10],(V529),VV[11],(V530),VV[12],(V531),VV[13],(V532),VV[14],(V533),VV[16],(V534)));
	VMR35(V539)}}
	}}
/*	local entry for function DELETE-DUPLICATES	*/

static object LI36(V540,va_alist)
	object V540;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB36 VMS36 VMV36
	{register object V541;
	object V542;
	object V543;
	object V544;
	object V545;
	object V546;
	register object V547;
	if(narg <1) too_few_arguments();
	V541= V540;
	narg= narg - 1;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +1,&LI36key,ap);
	V542=(Vcs[1]);
	V543=(Vcs[2]);
	V544=(Vcs[3]);
	V545=(Vcs[4]);
	V546=(Vcs[5]);
	if(Vcs[6]==0){
	V547= symbol_function(VV[31]);
	}else{
	V547=(Vcs[6]);}
	{int V548;
	V548= length((V541));
	if((V543)==Cnil){
	goto T817;}
	if((V544)==Cnil){
	goto T817;}
	(void)((*(LnkLI32))());
T817:;
	if(!(type_of((V541))==t_cons||((V541))==Cnil)){
	goto T818;}
	if(((V542))!=Cnil){
	goto T818;}
	if(((V545))!=Cnil){
	goto T818;}
	if(((V546))!=Cnil){
	goto T818;}
	if(!(endp((V541)))){
	goto T827;}
	{object V549 = Cnil;
	VMR36(V549)}
T827:;
	{register object V550;
	V550= (V541);
T831:;
	if(!(endp(cdr((V550))))){
	goto T832;}
	{object V551 = (V541);
	VMR36(V551)}
T832:;
	base[0]= car((V550));
	base[1]= cdr((V550));
	base[2]= VV[11];
	base[3]= (V543);
	base[4]= VV[12];
	base[5]= (V544);
	base[6]= VV[16];
	base[7]= (V547);
	vs_top=(vs_base=base+0)+8;
	(void) (*Lnk46)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T838;}
	if(type_of((V550))!=t_cons)FEwrong_type_argument(Scons,(V550));
	((V550))->c.c_car = cadr((V550));
	if(type_of((V550))!=t_cons)FEwrong_type_argument(Scons,(V550));
	((V550))->c.c_cdr = cddr((V550));
	goto T836;
T838:;
	V550= cdr((V550));
T836:;
	goto T831;}
T818:;
	{register int V552;
	if(((V545))==Cnil){
	goto T854;}
	V552= (*(LnkLI25))((V545));
	goto T852;
T854:;
	V552= 0;
T852:;
	{register int V553;
	V553= (*(LnkLI26))((V546),(V541));{object V554;
	base[0]= make_fixnum(V552);
	base[1]= make_fixnum(V553);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk21)();
	vs_top=sup;
	V554= vs_base[0];
	if(V554==Cnil)goto T858;
	goto T857;
T858:;}
	V555 = make_fixnum(V552);
	V556 = make_fixnum(V553);
	(void)((VFUN_NARGS=2,(*(LnkLI22))(V555,V556)));
T857:;
	if(((V542))!=Cnil){
	goto T863;}
	{int V557;
	int V558;
	V557= 0;
	V558= V552;
T868:;
	if(!((V558)>=(V553))){
	goto T869;}
	{object V559;
	register int V560;
	int V561;
	V562= (*(LnkLI40))((V541));
	V563 = make_fixnum((V548)-(V557));
	V559= (VFUN_NARGS=2,(*(LnkLI39))(/* INLINE-ARGS */V562,V563));
	V560= 0;
	V561= 0;
T876:;
	if(!((V560)>=(V548))){
	goto T877;}
	{object V564 = (V559);
	VMR36(V564)}
T877:;
	{object V565;
	base[0]= make_fixnum(V552);
	base[1]= make_fixnum(V560);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk21)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T883;}
	V565= Cnil;
	goto T882;
T883:;
	base[0]= make_fixnum(V560);
	base[1]= make_fixnum(V553);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk48)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T887;}
	V565= Cnil;
	goto T882;
T887:;
	base[0]= elt((V541),V560);
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V547));
	vs_top=sup;
	V566= vs_base[0];
	V567 = make_fixnum((1)+(V560));
	V568 = make_fixnum(V553);
	V565= (VFUN_NARGS=12,(*(LnkLI45))(V566,(V541),VV[11],(V543),VV[12],(V544),VV[13],V567,VV[14],V568,VV[16],(V547)));
T882:;
	if(((V565))==Cnil){
	goto T894;}
	goto T881;
T894:;
	V569= elt((V541),V560);
	(void)(elt_set((V559),V561,/* INLINE-ARGS */V569));
	V561= (1)+(V561);}
T881:;
	V560= (1)+(V560);
	goto T876;}
T869:;
	base[0]= elt((V541),V558);
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V547));
	vs_top=sup;
	V570= vs_base[0];
	V571 = make_fixnum((1)+(V558));
	V572 = make_fixnum(V553);
	if(((VFUN_NARGS=12,(*(LnkLI45))(V570,(V541),VV[11],(V543),VV[12],(V544),VV[13],V571,VV[14],V572,VV[16],(V547))))==Cnil){
	goto T902;}
	V557= (1)+(V557);
T902:;
	V558= (1)+(V558);
	goto T868;}
T863:;
	{int V573;
	int V574;
	V573= 0;
	V574= (-1)+(V553);
T914:;
	if(!((V574)<(V552))){
	goto T915;}
	{object V575;
	register int V576;
	int V577;
	V578= (*(LnkLI40))((V541));
	V579 = make_fixnum((V548)-(V573));
	V575= (VFUN_NARGS=2,(*(LnkLI39))(/* INLINE-ARGS */V578,V579));
	V576= (-1)+(V548);
	V577= ((-1)+(V548))-(V573);
T922:;
	if(!((V576)<(0))){
	goto T923;}
	{object V580 = (V575);
	VMR36(V580)}
T923:;
	{object V581;
	base[0]= make_fixnum(V552);
	base[1]= make_fixnum(V576);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk21)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T929;}
	V581= Cnil;
	goto T928;
T929:;
	base[0]= make_fixnum(V576);
	base[1]= make_fixnum(V553);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk48)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T933;}
	V581= Cnil;
	goto T928;
T933:;
	base[0]= elt((V541),V576);
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V547));
	vs_top=sup;
	V582= vs_base[0];
	V583 = make_fixnum(V552);
	V584 = make_fixnum(V576);
	V581= (VFUN_NARGS=14,(*(LnkLI45))(V582,(V541),VV[10],Ct,VV[11],(V543),VV[12],(V544),VV[13],V583,VV[14],V584,VV[16],(V547)));
T928:;
	if(((V581))==Cnil){
	goto T940;}
	goto T927;
T940:;
	V585= elt((V541),V576);
	(void)(elt_set((V575),V577,/* INLINE-ARGS */V585));
	V577= (-1)+(V577);}
T927:;
	V576= (-1)+(V576);
	goto T922;}
T915:;
	base[0]= elt((V541),V574);
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V547));
	vs_top=sup;
	V586= vs_base[0];
	V587 = make_fixnum(V552);
	V588 = make_fixnum(V574);
	if(((VFUN_NARGS=14,(*(LnkLI45))(V586,(V541),VV[10],Ct,VV[11],(V543),VV[12],(V544),VV[13],V587,VV[14],V588,VV[16],(V547))))==Cnil){
	goto T948;}
	V573= (1)+(V573);
T948:;
	V574= (-1)+(V574);
	goto T914;}}}}}
	}}
/*	local entry for function MISMATCH	*/

static object LI37(V590,V589,va_alist)
	object V590,V589;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB37 VMS37 VMV37
	{object V591;
	object V592;
	object V593;
	object V594;
	object V595;
	register object V596;
	object V597;
	object V598;
	object V599;
	object V600;
	if(narg <2) too_few_arguments();
	V591= V590;
	V592= V589;
	narg= narg - 2;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +2,&LI37key,ap);
	V593=(Vcs[2]);
	V594=(Vcs[3]);
	V595=(Vcs[4]);
	if(Vcs[5]==0){
	V596= symbol_function(VV[31]);
	}else{
	V596=(Vcs[5]);}
	V597=(Vcs[6]);
	V598=(Vcs[7]);
	V599=(Vcs[8]);
	V600=(Vcs[9]);
	if((V594)==Cnil){
	goto T958;}
	if((V595)==Cnil){
	goto T958;}
	(void)((*(LnkLI32))());
T958:;
	{register int V601;
	if(((V597))==Cnil){
	goto T961;}
	V601= (*(LnkLI25))((V597));
	goto T959;
T961:;
	V601= 0;
T959:;
	{register int V602;
	V602= (*(LnkLI26))((V599),(V591));{object V603;
	base[0]= make_fixnum(V601);
	base[1]= make_fixnum(V602);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk21)();
	vs_top=sup;
	V603= vs_base[0];
	if(V603==Cnil)goto T965;
	goto T964;
T965:;}
	V604 = make_fixnum(V601);
	V605 = make_fixnum(V602);
	(void)((VFUN_NARGS=2,(*(LnkLI22))(V604,V605)));
T964:;
	{register int V606;
	if(((V598))==Cnil){
	goto T971;}
	V606= (*(LnkLI25))((V598));
	goto T969;
T971:;
	V606= 0;
T969:;
	{register int V607;
	V607= (*(LnkLI26))((V600),(V592));{object V608;
	base[0]= make_fixnum(V606);
	base[1]= make_fixnum(V607);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk21)();
	vs_top=sup;
	V608= vs_base[0];
	if(V608==Cnil)goto T975;
	goto T974;
T975:;}
	V609 = make_fixnum(V606);
	V610 = make_fixnum(V607);
	(void)((VFUN_NARGS=2,(*(LnkLI22))(V609,V610)));
T974:;
	if(((V593))!=Cnil){
	goto T980;}
	{register int V611;
	register int V612;
	V611= V601;
	V612= V606;
T985:;
	if((V611)>=(V602)){
	goto T987;}
	if(!((V612)>=(V607))){
	goto T986;}
T987:;
	if(!((V611)>=(V602))){
	goto T992;}
	if(!((V612)>=(V607))){
	goto T992;}
	{object V613 = Cnil;
	VMR37(V613)}
T992:;
	{object V614 = make_fixnum(V611);
	VMR37(V614)}
T986:;
	base[0]= elt((V591),V611);
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V596));
	vs_top=sup;
	V615= vs_base[0];
	base[0]= elt((V592),V612);
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V596));
	vs_top=sup;
	V616= vs_base[0];
	if(((*(LnkLI34))((V594),(V595),V615,V616))!=Cnil){
	goto T997;}
	{object V617 = make_fixnum(V611);
	VMR37(V617)}
T997:;
	V611= (1)+(V611);
	V612= (1)+(V612);
	goto T985;}
T980:;
	{register int V618;
	register int V619;
	V618= (-1)+(V602);
	V619= (-1)+(V607);
T1011:;
	if((V618)<(V601)){
	goto T1013;}
	if(!((V619)<(V606))){
	goto T1012;}
T1013:;
	if(!((V618)<(V601))){
	goto T1018;}
	if(!((V619)<(V606))){
	goto T1018;}
	{object V620 = Cnil;
	VMR37(V620)}
T1018:;
	{object V621 = make_fixnum((1)+(V618));
	VMR37(V621)}
T1012:;
	base[0]= elt((V591),V618);
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V596));
	vs_top=sup;
	V622= vs_base[0];
	base[0]= elt((V592),V619);
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V596));
	vs_top=sup;
	V623= vs_base[0];
	if(((*(LnkLI34))((V594),(V595),V622,V623))!=Cnil){
	goto T1023;}
	{object V624 = make_fixnum((1)+(V618));
	VMR37(V624)}
T1023:;
	V618= (-1)+(V618);
	V619= (-1)+(V619);
	goto T1011;}}}}}}
	}}
/*	local entry for function SEARCH	*/

static object LI38(V626,V625,va_alist)
	object V626,V625;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB38 VMS38 VMV38
	{object V627;
	object V628;
	object V629;
	object V630;
	object V631;
	register object V632;
	object V633;
	object V634;
	object V635;
	object V636;
	if(narg <2) too_few_arguments();
	V627= V626;
	V628= V625;
	narg= narg - 2;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +2,&LI38key,ap);
	V629=(Vcs[2]);
	V630=(Vcs[3]);
	V631=(Vcs[4]);
	if(Vcs[5]==0){
	V632= symbol_function(VV[31]);
	}else{
	V632=(Vcs[5]);}
	V633=(Vcs[6]);
	V634=(Vcs[7]);
	V635=(Vcs[8]);
	V636=(Vcs[9]);
	if((V630)==Cnil){
	goto T1035;}
	if((V631)==Cnil){
	goto T1035;}
	(void)((*(LnkLI32))());
T1035:;
	{int V637;
	if(((V633))==Cnil){
	goto T1038;}
	V637= (*(LnkLI25))((V633));
	goto T1036;
T1038:;
	V637= 0;
T1036:;
	{int V638;
	V638= (*(LnkLI26))((V635),(V627));{object V639;
	base[0]= make_fixnum(V637);
	base[1]= make_fixnum(V638);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk21)();
	vs_top=sup;
	V639= vs_base[0];
	if(V639==Cnil)goto T1042;
	goto T1041;
T1042:;}
	V640 = make_fixnum(V637);
	V641 = make_fixnum(V638);
	(void)((VFUN_NARGS=2,(*(LnkLI22))(V640,V641)));
T1041:;
	{register int V642;
	if(((V634))==Cnil){
	goto T1048;}
	V642= (*(LnkLI25))((V634));
	goto T1046;
T1048:;
	V642= 0;
T1046:;
	{int V643;
	V643= (*(LnkLI26))((V636),(V628));{object V644;
	base[0]= make_fixnum(V642);
	base[1]= make_fixnum(V643);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk21)();
	vs_top=sup;
	V644= vs_base[0];
	if(V644==Cnil)goto T1052;
	goto T1051;
T1052:;}
	V645 = make_fixnum(V642);
	V646 = make_fixnum(V643);
	(void)((VFUN_NARGS=2,(*(LnkLI22))(V645,V646)));
T1051:;
	if(((V629))!=Cnil){
	goto T1057;}
T1060:;
	{register int V647;
	register int V648;
	V647= V637;
	V648= V642;
T1066:;
	if(!((V647)>=(V638))){
	goto T1067;}
	{object V649 = make_fixnum(V642);
	VMR38(V649)}
T1067:;
	if(!((V648)>=(V643))){
	goto T1071;}
	{object V650 = Cnil;
	VMR38(V650)}
T1071:;
	base[0]= elt((V627),V647);
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V632));
	vs_top=sup;
	V651= vs_base[0];
	base[0]= elt((V628),V648);
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V632));
	vs_top=sup;
	V652= vs_base[0];
	if(((*(LnkLI34))((V630),(V631),V651,V652))!=Cnil){
	goto T1074;}
	goto T1062;
T1074:;
	V647= (1)+(V647);
	V648= (1)+(V648);
	goto T1066;}
T1062:;
	V642= (1)+(V642);
	goto T1060;
T1057:;
T1088:;
	{register int V653;
	register int V654;
	V653= (-1)+(V638);
	V654= (-1)+(V643);
T1094:;
	if(!((V653)<(V637))){
	goto T1095;}
	{object V655 = make_fixnum((1)+(V654));
	VMR38(V655)}
T1095:;
	if(!((V654)<(V642))){
	goto T1099;}
	{object V656 = Cnil;
	VMR38(V656)}
T1099:;
	base[0]= elt((V627),V653);
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V632));
	vs_top=sup;
	V657= vs_base[0];
	base[0]= elt((V628),V654);
	vs_top=(vs_base=base+0)+1;
	super_funcall_no_event((V632));
	vs_top=sup;
	V658= vs_base[0];
	if(((*(LnkLI34))((V630),(V631),V657,V658))!=Cnil){
	goto T1102;}
	goto T1090;
T1102:;
	V653= (-1)+(V653);
	V654= (-1)+(V654);
	goto T1094;}
T1090:;
	V643= (-1)+(V643);
	goto T1088;}}}}}
	}}
/*	function definition for SORT	*/

static L39()
{register object *base=vs_base;
	register object *sup=base+VM39; VC39
	vs_reserve(VM39);
	{register object V659;
	object V660;
	object V661;
	if(vs_top-vs_base<2) too_few_arguments();
	parse_key(vs_base+2,FALSE,FALSE,1,VV[16]);
	V659=(base[0]);
	V660=(base[1]);
	vs_top=sup;
	if(base[3]==Cnil){
	V661= symbol_function(VV[31]);
	}else{
	V661=(base[2]);}
	if(!(type_of((V659))==t_cons||((V659))==Cnil)){
	goto T1117;}
	base[4]= (V659);
	base[5]= (V660);
	base[6]= (V661);
	vs_top=(vs_base=base+4)+3;
	(void) (*Lnk49)();
	return;
T1117:;
	base[4]= (*(LnkLI50))((V659),0,length((V659)),(V660),(V661));
	vs_top=(vs_base=base+4)+1;
	return;
	}
}
/*	function definition for LIST-MERGE-SORT	*/

static L40()
{register object *base=vs_base;
	register object *sup=base+VM40; VC40
	vs_reserve(VM40);
	{object V662;
	check_arg(3);
	V662=(base[0]);
	vs_top=sup;
TTL:;
	base[3]= (V662);
	vs_top=(vs_base=base+3)+1;
	L41(base);
	return;
	}
}
/*	local entry for function QUICK-SORT	*/

static object LI42(V668,V669,V670,V671,V672)

register object V668;int V669;int V670;register object V671;register object V672;
{	 VMB41 VMS41 VMV41
TTL:;
	if(!((V670)<=((1)+(V669)))){
	goto T1124;}
	{object V673 = (V668);
	VMR41(V673)}
T1124:;
	{register int V674;
	register int V675;
	object V676;
	register object V677;
	V674= V669;
	V675= V670;
	V676= elt((V668),V669);
	V677= (
	(type_of((V672)) == t_sfun ?(*(object (*)())(((V672))->sfn.sfn_self)):
	(fcall.fun=((V672)),fcall.argd=1,fcalln))((V676)));
T1132:;
T1136:;
	V675= (-1)+(V675);
	if((V674)<(V675)){
	goto T1140;}
	goto T1130;
T1140:;
	base[3]= elt((V668),V675);
	vs_top=(vs_base=base+3)+1;
	super_funcall_no_event((V672));
	vs_top=sup;
	base[2]= vs_base[0];
	base[3]= (V677);
	vs_top=(vs_base=base+2)+2;
	super_funcall_no_event((V671));
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T1137;}
	goto T1134;
T1137:;
	goto T1136;
T1134:;
T1151:;
	V674= (1)+(V674);
	if((V674)<(V675)){
	goto T1155;}
	goto T1130;
T1155:;
	base[3]= elt((V668),V674);
	vs_top=(vs_base=base+3)+1;
	super_funcall_no_event((V672));
	vs_top=sup;
	base[2]= vs_base[0];
	base[3]= (V677);
	vs_top=(vs_base=base+2)+2;
	super_funcall_no_event((V671));
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T1152;}
	goto T1149;
T1152:;
	goto T1151;
T1149:;
	{object V678;
	V678= elt((V668),V674);
	V679= elt((V668),V675);
	(void)(elt_set((V668),V674,/* INLINE-ARGS */V679));
	(void)(elt_set((V668),V675,(V678)));}
	goto T1132;
T1130:;
	V680= elt((V668),V674);
	(void)(elt_set((V668),V669,/* INLINE-ARGS */V680));
	(void)(elt_set((V668),V674,(V676)));
	(void)((*(LnkLI50))((V668),V669,V674,(V671),(V672)));
	V669= (1)+(V674);
	goto TTL;}
}
/*	function definition for STABLE-SORT	*/

static L43()
{register object *base=vs_base;
	register object *sup=base+VM42; VC42
	vs_reserve(VM42);
	{register object V681;
	object V682;
	object V683;
	if(vs_top-vs_base<2) too_few_arguments();
	parse_key(vs_base+2,FALSE,FALSE,1,VV[16]);
	V681=(base[0]);
	V682=(base[1]);
	vs_top=sup;
	if(base[3]==Cnil){
	V683= symbol_function(VV[31]);
	}else{
	V683=(base[2]);}
	if(!(type_of((V681))==t_cons||((V681))==Cnil)){
	goto T1178;}
	base[4]= (V681);
	base[5]= (V682);
	base[6]= (V683);
	vs_top=(vs_base=base+4)+3;
	(void) (*Lnk49)();
	return;
T1178:;
	if(type_of((V681))==t_string){
	goto T1183;}
	if(!((type_of((V681))==t_bitvector))){
	goto T1184;}
T1183:;
	base[4]= (V681);
	base[5]= (V682);
	base[6]= VV[16];
	base[7]= (V683);
	vs_top=(vs_base=base+4)+4;
	(void) (*Lnk51)();
	return;
T1184:;
	base[4]= (*(LnkLI52))((V681),VV[0]);
	base[5]= (V682);
	base[6]= (V683);
	vs_top=(vs_base=base+4)+3;
	(void) (*Lnk49)();
	vs_top=sup;
	V684= vs_base[0];
	V685= (*(LnkLI40))((V681));
	base[4]= (*(LnkLI52))(V684,/* INLINE-ARGS */V685);
	vs_top=(vs_base=base+4)+1;
	return;
	}
}
/*	local entry for function MERGE	*/

static object LI44(V689,V688,V687,V686,va_alist)
	object V689,V688,V687,V686;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB43 VMS43 VMV43
	{object V690;
	register object V691;
	register object V692;
	object V693;
	object V694;
	if(narg <4) too_few_arguments();
	V690= V689;
	V691= V688;
	V692= V687;
	V693= V686;
	narg= narg - 4;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +4,&LI44key,ap);
	if(Vcs[4]==0){
	V694= symbol_function(VV[31]);
	}else{
	V694=(Vcs[4]);}
	{int V695;
	int V696;
	V695= length((V691));
	V696= length((V692));
	{register object V697;
	register int V698;
	register int V699;
	register int V700;
	V701 = make_fixnum((V695)+(V696));
	V697= (VFUN_NARGS=2,(*(LnkLI39))((V690),V701));
	V698= 0;
	V699= 0;
	V700= 0;
T1204:;
	if(!((V699)==(V695))){
	goto T1205;}
	if(!((V700)==(V696))){
	goto T1205;}
	{object V702 = (V697);
	VMR43(V702)}
T1205:;
	if(!((V699)<(V695))){
	goto T1213;}
	if(!((V700)<(V696))){
	goto T1213;}
	base[1]= elt((V691),V699);
	vs_top=(vs_base=base+1)+1;
	super_funcall_no_event((V694));
	vs_top=sup;
	base[0]= vs_base[0];
	base[2]= elt((V692),V700);
	vs_top=(vs_base=base+2)+1;
	super_funcall_no_event((V694));
	vs_top=sup;
	base[1]= vs_base[0];
	vs_top=(vs_base=base+0)+2;
	super_funcall_no_event((V693));
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T1218;}
	V703= elt((V691),V699);
	(void)(elt_set((V697),V698,/* INLINE-ARGS */V703));
	V699= (1)+(V699);
	goto T1211;
T1218:;
	base[1]= elt((V692),V700);
	vs_top=(vs_base=base+1)+1;
	super_funcall_no_event((V694));
	vs_top=sup;
	base[0]= vs_base[0];
	base[2]= elt((V691),V699);
	vs_top=(vs_base=base+2)+1;
	super_funcall_no_event((V694));
	vs_top=sup;
	base[1]= vs_base[0];
	vs_top=(vs_base=base+0)+2;
	super_funcall_no_event((V693));
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T1227;}
	V704= elt((V692),V700);
	(void)(elt_set((V697),V698,/* INLINE-ARGS */V704));
	V700= (1)+(V700);
	goto T1211;
T1227:;
	V705= elt((V691),V699);
	(void)(elt_set((V697),V698,/* INLINE-ARGS */V705));
	V699= (1)+(V699);
	goto T1211;
T1213:;
	if(!((V699)<(V695))){
	goto T1238;}
	V706= elt((V691),V699);
	(void)(elt_set((V697),V698,/* INLINE-ARGS */V706));
	V699= (1)+(V699);
	goto T1211;
T1238:;
	V707= elt((V692),V700);
	(void)(elt_set((V697),V698,/* INLINE-ARGS */V707));
	V700= (1)+(V700);
T1211:;
	V698= (1)+(V698);
	goto T1204;}}}
	}}
/*	local function SORT	*/

static L41(base0)
register object *base0;
{	register object *base=vs_base;
	register object *sup=base+VM44; VC44
	vs_reserve(VM44);
	{object V708;
	check_arg(1);
	V708=(base[0]);
	vs_top=sup;
TTL:;
	{int V709;
	register object V710;
	register object V711;
	object V712;
	register object V713;
	register object V714;
	register object V715;
	V709= 0;
	V710= Cnil;
	V711= Cnil;
	V712= Cnil;
	V713= Cnil;
	V714= Cnil;
	V715= Cnil;
	V709= length((V708));
	if(!((V709)<(2))){
	goto T1256;}
	base[1]= (V708);
	vs_top=(vs_base=base+1)+1;
	return;
T1256:;
	if(!((V709)==(2))){
	goto T1254;}
	V714= (
	(type_of(base0[2]) == t_sfun ?(*(object (*)())((base0[2])->sfn.sfn_self)):
	(fcall.fun=(base0[2]),fcall.argd=1,fcalln))(car((V708))));
	V715= (
	(type_of(base0[2]) == t_sfun ?(*(object (*)())((base0[2])->sfn.sfn_self)):
	(fcall.fun=(base0[2]),fcall.argd=1,fcalln))(cadr((V708))));
	base[1]= (V714);
	base[2]= (V715);
	vs_top=(vs_base=base+1)+2;
	super_funcall_no_event(base0[1]);
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T1265;}
	base[1]= (V708);
	vs_top=(vs_base=base+1)+1;
	return;
T1265:;
	base[1]= (V715);
	base[2]= (V714);
	vs_top=(vs_base=base+1)+2;
	super_funcall_no_event(base0[1]);
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T1270;}
	base[1]= nreverse((V708));
	vs_top=(vs_base=base+1)+1;
	return;
T1270:;
	base[1]= (V708);
	vs_top=(vs_base=base+1)+1;
	return;
T1254:;
	V709= (V709>=0&&(2)>0?(V709)/(2):ifloor(V709,2));
	{int V716;
	register object V717;
	V716= 1;
	V717= (V708);
T1279:;
	if(!((V716)>=(V709))){
	goto T1280;}
	V710= (V708);
	V711= cdr((V717));
	if(type_of((V717))!=t_cons)FEwrong_type_argument(Scons,(V717));
	((V717))->c.c_cdr = Cnil;
	goto T1276;
T1280:;
	V716= (1)+(V716);
	V717= cdr((V717));
	goto T1279;}
T1276:;
	base[1]= (V710);
	vs_top=(vs_base=base+1)+1;
	L41(base0);
	vs_top=sup;
	V710= vs_base[0];
	base[1]= (V711);
	vs_top=(vs_base=base+1)+1;
	L41(base0);
	vs_top=sup;
	V711= vs_base[0];
	if(!(endp((V710)))){
	goto T1300;}
	base[1]= (V711);
	vs_top=(vs_base=base+1)+1;
	return;
T1300:;
	if(!(endp((V711)))){
	goto T1298;}
	base[1]= (V710);
	vs_top=(vs_base=base+1)+1;
	return;
T1298:;
	V712= make_cons(Cnil,Cnil);
	V713= (V712);
	V714= (
	(type_of(base0[2]) == t_sfun ?(*(object (*)())((base0[2])->sfn.sfn_self)):
	(fcall.fun=(base0[2]),fcall.argd=1,fcalln))(car((V710))));
	V715= (
	(type_of(base0[2]) == t_sfun ?(*(object (*)())((base0[2])->sfn.sfn_self)):
	(fcall.fun=(base0[2]),fcall.argd=1,fcalln))(car((V711))));
T1249:;
	base[1]= (V714);
	base[2]= (V715);
	vs_top=(vs_base=base+1)+2;
	super_funcall_no_event(base0[1]);
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T1312;}
	goto T1250;
T1312:;
	base[1]= (V715);
	base[2]= (V714);
	vs_top=(vs_base=base+1)+2;
	super_funcall_no_event(base0[1]);
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T1317;}
	goto T1251;
T1317:;
	goto T1250;
T1250:;
	if(type_of((V713))!=t_cons)FEwrong_type_argument(Scons,(V713));
	((V713))->c.c_cdr = (V710);
	V713= cdr((V713));
	V710= cdr((V710));
	if(!(endp((V710)))){
	goto T1326;}
	if(type_of((V713))!=t_cons)FEwrong_type_argument(Scons,(V713));
	((V713))->c.c_cdr = (V711);
	base[1]= cdr((V712));
	vs_top=(vs_base=base+1)+1;
	return;
T1326:;
	V714= (
	(type_of(base0[2]) == t_sfun ?(*(object (*)())((base0[2])->sfn.sfn_self)):
	(fcall.fun=(base0[2]),fcall.argd=1,fcalln))(car((V710))));
	goto T1249;
T1251:;
	if(type_of((V713))!=t_cons)FEwrong_type_argument(Scons,(V713));
	((V713))->c.c_cdr = (V711);
	V713= cdr((V713));
	V711= cdr((V711));
	if(!(endp((V711)))){
	goto T1337;}
	if(type_of((V713))!=t_cons)FEwrong_type_argument(Scons,(V713));
	((V713))->c.c_cdr = (V710);
	base[1]= cdr((V712));
	vs_top=(vs_base=base+1)+1;
	return;
T1337:;
	V715= (
	(type_of(base0[2]) == t_sfun ?(*(object (*)())((base0[2])->sfn.sfn_self)):
	(fcall.fun=(base0[2]),fcall.argd=1,fcalln))(car((V711))));
	goto T1249;}
	}
}
static object  LnkTLI52(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[52],&LnkLI52,2,ap);} /* COERCE */
static LnkT51(){ call_or_link(VV[51],&Lnk51);} /* SORT */
static object  LnkTLI50(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[50],&LnkLI50,81925,ap);} /* QUICK-SORT */
static LnkT49(){ call_or_link(VV[49],&Lnk49);} /* LIST-MERGE-SORT */
static LnkT48(){ call_or_link(VV[48],&Lnk48);} /* < */
static object  LnkTLI47(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[47],&LnkLI47,ap);} /* DELETE-DUPLICATES */
static LnkT46(){ call_or_link(VV[46],&Lnk46);} /* MEMBER1 */
static object  LnkTLI45(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[45],&LnkLI45,ap);} /* POSITION */
static object  LnkTLI44(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[44],&LnkLI44,ap);} /* FIND */
static object  LnkTLI43(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[43],&LnkLI43,ap);} /* NSUBSTITUTE */
static object  LnkTLI42(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[42],&LnkLI42,ap);} /* SUBSTITUTE */
static object  LnkTLI41(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[41],&LnkLI41,ap);} /* COUNT */
static object  LnkTLI40(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[40],&LnkLI40,1,ap);} /* SEQTYPE */
static object  LnkTLI39(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[39],&LnkLI39,ap);} /* MAKE-SEQUENCE */
static object  LnkTLI38(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[38],&LnkLI38,ap);} /* INTERNAL-COUNT */
static object  LnkTLI36(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[36],&LnkLI36,ap);} /* REMOVE */
static object  LnkTLI35(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[35],&LnkLI35,ap);} /* DELETE */
static object  LnkTLI34(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[34],&LnkLI34,4,ap);} /* CALL-TEST */
static LnkT33(){ call_or_link(VV[33],&Lnk33);} /* NRECONC */
static object  LnkTLI32(){return call_proc0(VV[32],&LnkLI32);} /* TEST-ERROR */
static int  LnkTLI26(va_alist)va_dcl{va_list ap;va_start(ap);return(int )call_proc(VV[26],&LnkLI26,258,ap);} /* THE-END */
static int  LnkTLI25(va_alist)va_dcl{va_list ap;va_start(ap);return(int )call_proc(VV[25],&LnkLI25,257,ap);} /* THE-START */
static LnkT23(){ call_or_link(VV[23],&Lnk23);} /* >= */
static object  LnkTLI22(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[22],&LnkLI22,ap);} /* BAD-SEQ-LIMIT */
static LnkT21(){ call_or_link(VV[21],&Lnk21);} /* <= */
static LnkT20(){ call_or_link(VV[20],&Lnk20);} /* EQL */
static LnkT19(){ call_or_link(VV[19],&Lnk19);} /* NOT */
static LnkT18(){ call_or_link(VV[18],&Lnk18);} /* ERROR */
static LnkT17(){ call_or_link(VV[17],&Lnk17);} /* ARRAY-ELEMENT-TYPE */
