
#include <cmpinclude.h>
#include "debug.h"
init_debug(){do_init(VV);}
/*	function definition for SHOW-BREAK-VARIABLES	*/

static L1()
{register object *base=vs_base;
	register object *sup=base+VM1; VC1
	vs_reserve(VM1);
	{register object V1;
	if(vs_top-vs_base>1) too_many_arguments();
	if(vs_base>=vs_top){vs_top=sup;goto T1;}
	V1=(base[0]);
	vs_top=sup;
	goto T2;
T1:;
	V1= small_fixnum(1);
T2:;
T5:;
	{register object V2;
	register object V3;
	V2= reverse(car(symbol_value(VV[0])));
	V3= car((V2));
T11:;
	if(!(endp((V2)))){
	goto T12;}
	goto T7;
T12:;
	base[3]= symbol_value(VV[1]);
	base[4]= VV[2];
	base[5]= car((V3));
	base[6]= cadr((V3));
	vs_top=(vs_base=base+3)+4;
	(void) (*Lnk107)();
	vs_top=sup;
	V2= cdr((V2));
	V3= car((V2));
	goto T11;}
T7:;{object V4;
	V1= number_plus((V1),small_fixnum(-1));
	base[1]= (V1);
	base[2]= small_fixnum(0);
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk108)();
	vs_top=sup;
	V4= vs_base[0];
	if(V4==Cnil)goto T27;
	goto T26;
T27:;}
	vs_base=vs_top=base+1;
	vs_base[0]=Cnil;
	return;
T26:;
	vs_base=vs_top;
	(void) (*Lnk109)();
	vs_top=sup;
	goto T5;
	}
}
/*	local entry for function SHOW-ENVIRONMENT	*/

static object LI2(V6)

object V6;
{	 VMB2 VMS2 VMV2
TTL:;
	{object V7;
	base[1]= (V6);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk110)();
	vs_top=sup;
	base[0]= vs_base[0];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk111)();
	vs_top=sup;
	V7= vs_base[0];
	if(!(type_of((V7))==t_cons||((V7))==Cnil)){
	goto T37;}
	{register object V8;
	register object V9;
	base[3]= (V6);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk110)();
	vs_top=sup;
	base[2]= vs_base[0];
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk111)();
	vs_top=sup;
	V10= vs_base[0];
	V8= reverse(V10);
	V9= car((V8));
T45:;
	if(!(endp((V8)))){
	goto T46;}
	{object V11 = Cnil;
	VMR2(V11)}
T46:;
	base[2]= symbol_value(VV[1]);
	base[3]= VV[3];
	base[4]= car((V9));
	base[5]= cadr((V9));
	vs_top=(vs_base=base+2)+4;
	(void) (*Lnk107)();
	vs_top=sup;
	V8= cdr((V8));
	V9= car((V8));
	goto T45;}
T37:;
	{object V12 = Cnil;
	VMR2(V12)}}
}
/*	function definition for SEARCH-STACK	*/

static L3()
{register object *base=vs_base;
	register object *sup=base+VM3; VC3
	vs_reserve(VM3);
	{object V13;
	check_arg(1);
	V13=(base[0]);
	vs_top=sup;
TTL:;
	{object V14;
	V14= Cnil;
	if(!(type_of((V13))==t_symbol)){
	goto T64;}
	V14= symbol_name((V13));
	goto T62;
T64:;
	V14= (V13);
T62:;
	{register int V15;
	register int V16;
	{object V17;
	vs_base=vs_top;
	(void) (*Lnk112)();
	vs_top=sup;
	V17= vs_base[0];{object V18;
	V18= (type_of((V17))==t_fixnum?Ct:Cnil);
	if(V18==Cnil)goto T69;
	goto T68;
T69:;}
	(void)((*(LnkLI113))());
T68:;
	V15= fix((V17));}
	V16= 2;
	{register object V19;
	V19= Cnil;
	{register object V20;
	V20= Cnil;
T73:;
	base[1]= make_fixnum(V15);
	base[2]= make_fixnum(V16);
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk114)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T76;}
	goto T75;
T76:;
	goto T74;
T75:;
	{register object V21;
	base[1]= make_fixnum(V15);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk115)();
	vs_top=sup;
	V21= vs_base[0];
	V19= (V21);}
	base[1]= (V19);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk116)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T86;}
	base[1]= (V19);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk117)();
	vs_top=sup;
	V20= vs_base[0];
	goto T84;
T86:;
	if(!(type_of((V19))==t_symbol)){
	goto T92;}
	V20= (V19);
	goto T84;
T92:;
	if(!(type_of((V19))==t_cons||((V19))==Cnil)){
	goto T96;}
	{register object x= car((V19)),V22= VV[4];
	while(!endp(V22))
	if(eql(x,V22->c.c_car)){
	goto T99;
	}else V22=V22->c.c_cdr;
	goto T96;}
T99:;
	V20= cadr((V19));
	goto T84;
T96:;
	V20= VV[5];
T84:;
	V23= symbol_name((V20));
	if(((VFUN_NARGS=4,(*(LnkLI118))((V14),/* INLINE-ARGS */V23,VV[6],VV[7])))==Cnil){
	goto T102;}
	base[1]= make_fixnum(V15);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk119)();
	vs_top=sup;
	princ_char(10,Cnil);
	vs_base=vs_top;
	(void) (*Lnk120)();
	return;
T102:;
	V15= (V15)-(1);
	goto T73;
T74:;
	base[1]= symbol_value(VV[1]);
	base[2]= VV[8];
	base[3]= (V14);
	vs_top=(vs_base=base+1)+3;
	(void) (*Lnk107)();
	vs_top=sup;
	base[1]= Cnil;
	vs_top=(vs_base=base+1)+1;
	return;
	base[1]= Cnil;
	vs_top=(vs_base=base+1)+1;
	return;}}}}
	}
}
/*	function definition for BREAK-LOCALS	*/

static L4()
{register object *base=vs_base;
	register object *sup=base+VM4; VC4
	vs_reserve(VM4);
	bds_check;
	{object V24;
	if(vs_top-vs_base>1) too_many_arguments();
	if(vs_base>=vs_top){vs_top=sup;goto T115;}
	V24=(base[0]);
	vs_top=sup;
	goto T116;
T115:;
	V24= small_fixnum(1);
T116:;
	{object V25;
	object V26;
	object V27;
	object V28;
	object V29;
	object V30;
	V25= symbol_value(VV[9]);
	base[6]= (V25);
	vs_top=(vs_base=base+6)+1;
	(void) (*Lnk110)();
	vs_top=sup;
	V26= vs_base[0];
	bds_bind(VV[11],symbol_value(VV[10]));
	bds_bind(VV[12],Cnil);
	bds_bind(VV[13],symbol_value(VV[10]));
	V27= symbol_value(VV[9]);
	base[6]= (V25);
	vs_top=(vs_base=base+6)+1;
	(void) (*Lnk115)();
	vs_top=sup;
	V28= vs_base[0];
	V29= Cnil;
	V30= Cnil;
	if(!((fix((V24)))>(1))){
	goto T127;}
	{register int V31;
	int V32;
	V31= 0;{object V33;
	V33= (type_of((V24))==t_fixnum?Ct:Cnil);
	if(V33==Cnil)goto T132;
	goto T131;
T132:;}
	(void)((*(LnkLI113))());
T131:;
	V32= fix((V24));
	{register int V34;
	int V35;{object V36;
	V36= (type_of((V27))==t_fixnum?Ct:Cnil);
	if(V36==Cnil)goto T136;
	goto T135;
T136:;}
	(void)((*(LnkLI113))());
T135:;
	V34= fix((V27));
	V35= 2;
T140:;
	base[6]= make_fixnum(V34);
	base[7]= make_fixnum(V35);
	vs_top=(vs_base=base+6)+2;
	(void) (*Lnk114)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T143;}
	goto T142;
T143:;
	goto T141;
T142:;
	base[6]= make_fixnum(V31);
	base[7]= make_fixnum(V32);
	vs_top=(vs_base=base+6)+2;
	(void) (*Lnk121)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T148;}
	goto T147;
T148:;
	goto T141;
T147:;
	bds_bind(VV[9],make_fixnum(V34));
	vs_base=vs_top;
	(void) (*Lnk120)();
	vs_top=sup;
	princ_char(10,Cnil);
	princ_char(10,Cnil);
	bds_unwind1;
	V31= (V31)+(1);
	V34= (V34)-(1);
	goto T140;
T141:;
	base[6]= Cnil;
	vs_top=(vs_base=base+6)+1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	return;
	base[6]= Cnil;
	vs_top=(vs_base=base+6)+1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	return;}}
T127:;
	base[6]= (V28);
	vs_top=(vs_base=base+6)+1;
	(void) (*Lnk116)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T162;}
	base[6]= (V28);
	vs_top=(vs_base=base+6)+1;
	(void) (*Lnk117)();
	vs_top=sup;
	V29= vs_base[0];
	goto T160;
T162:;
	V29= (V28);
T160:;
	if(!(type_of((V29))==t_symbol)){
	goto T168;}
	V30= get((V29),VV[14],Cnil);
T168:;
	{object V37;
	base[6]= make_fixnum((1)+(fix(symbol_value(VV[9]))));
	vs_top=(vs_base=base+6)+1;
	(void) (*Lnk110)();
	vs_top=sup;
	V37= vs_base[0];
	if(((V37))==Cnil){
	goto T175;}
	base[6]= symbol_value(VV[1]);
	base[7]= VV[15];
	base[8]= (V29);
	vs_top=(vs_base=base+6)+3;
	(void) (*Lnk107)();
	vs_top=sup;
	if(!(type_of((V29))==t_symbol)){
	goto T182;}
	{register int V38;
	int V39;{object V40;
	V40= (type_of((V26))==t_fixnum?Ct:Cnil);
	if(V40==Cnil)goto T186;
	goto T185;
T186:;}
	(void)((*(LnkLI113))());
T185:;
	V38= fix((V26));{object V41;
	V41= (type_of((V37))==t_fixnum?Ct:Cnil);
	if(V41==Cnil)goto T190;
	goto T189;
T190:;}
	(void)((*(LnkLI113))());
T189:;
	V39= fix((V37));
	{register int V42;
	V42= 0;
	{register object V43;
	V43= Cnil;
T194:;
	base[6]= make_fixnum(V38);
	base[7]= make_fixnum(V39);
	vs_top=(vs_base=base+6)+2;
	(void) (*Lnk121)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T197;}
	goto T196;
T197:;
	goto T195;
T196:;
	V43= Cnil;
	{register object x= small_fixnum(0),V44= (V30);
	while(!endp(V44))
	if(eql(x,V44->c.c_car)){
	goto T206;
	}else V44=V44->c.c_cdr;
	goto T205;}
T206:;
	base[6]= (V30);
	base[7]= make_fixnum(V42);
	vs_top=(vs_base=base+6)+2;
	(void) (*Lnk122)();
	vs_top=sup;
	V43= vs_base[0];
	goto T203;
T205:;
	V43= nth(V42,(V30));
T203:;
	if(((V43))==Cnil){
	goto T213;}
	base[6]= Ct;
	base[7]= VV[16];
	base[8]= make_fixnum(V42);
	base[9]= (V43);
	base[11]= make_fixnum(V38);
	vs_top=(vs_base=base+11)+1;
	(void) (*Lnk111)();
	vs_top=sup;
	base[10]= vs_base[0];
	vs_top=(vs_base=base+6)+5;
	(void) (*Lnk107)();
	vs_top=sup;
	goto T211;
T213:;
	base[6]= symbol_value(VV[1]);
	base[7]= VV[17];
	base[8]= make_fixnum(V42);
	base[10]= make_fixnum(V38);
	vs_top=(vs_base=base+10)+1;
	(void) (*Lnk111)();
	vs_top=sup;
	base[9]= vs_base[0];
	vs_top=(vs_base=base+6)+4;
	(void) (*Lnk107)();
	vs_top=sup;
T211:;
	V38= (V38)+(1);{object V45;
	base[6]= make_fixnum(V42);
	base[7]= VV[18];
	vs_top=(vs_base=base+6)+2;
	(void) (*Lnk123)();
	vs_top=sup;
	V45= vs_base[0];
	if(V45==Cnil)goto T229;
	goto T228;
T229:;}
	(void)((*(LnkLI113))());
T228:;
	V42= (V42)+(1);
	goto T194;
T195:;
	base[6]= Cnil;
	vs_top=(vs_base=base+6)+1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	return;
	base[6]= Cnil;
	vs_top=(vs_base=base+6)+1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	return;}}}
T182:;
	if(!(type_of((V29))==t_cons||((V29))==Cnil)){
	goto T237;}
	base[6]= (*(LnkLI124))((V25));
	vs_top=(vs_base=base+6)+1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	return;
T237:;
	base[6]= symbol_value(VV[1]);
	base[7]= VV[19];
	vs_top=(vs_base=base+6)+2;
	(void) (*Lnk107)();
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	return;
T175:;
	base[6]= Cnil;
	vs_top=(vs_base=base+6)+1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	return;}}
	}
}
/*	function definition for LOC	*/

static L5()
{register object *base=vs_base;
	register object *sup=base+VM5; VC5
	vs_reserve(VM5);
	{object V46;
	if(vs_top-vs_base>1) too_many_arguments();
	if(vs_base>=vs_top){vs_top=sup;goto T241;}
	V46=(base[0]);
	vs_top=sup;
	goto T242;
T241:;
	V46= small_fixnum(0);
T242:;
	{object V47;
	base[1]= symbol_value(VV[9]);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk110)();
	vs_top=sup;
	V47= vs_base[0];
	if(!((fix((V46)))>=(0))){
	goto T247;}
	vs_base=vs_top;
	(void) (*Lnk112)();
	vs_top=sup;
	V49= vs_base[0];
	V50 = make_fixnum((1)+(fix(symbol_value(VV[9]))));
	base[1]= (number_compare(V49,V50)<=0?(V49):V50);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk110)();
	vs_top=sup;
	V48= vs_base[0];
	if((fix((V46)))<((fix(V48))-(fix((V47))))){
	goto T246;}
T247:;
	base[1]= VV[20];
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk125)();
	vs_top=sup;
T246:;
	base[1]= make_fixnum((fix((V46)))+(fix((V47))));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk111)();
	return;}
	}
}
/*	macro definition for MV-SETQ	*/

static L6()
{register object *base=vs_base;
	register object *sup=base+VM6; VC6
	vs_reserve(VM6);
	check_arg(2);
	vs_top=sup;
	{object V51=base[0]->c.c_cdr;
	if(endp(V51))invalid_macro_call();
	base[2]= (V51->c.c_car);
	V51=V51->c.c_cdr;
	if(endp(V51))invalid_macro_call();
	base[3]= (V51->c.c_car);
	V51=V51->c.c_cdr;
	if(!endp(V51))invalid_macro_call();}
	V52= list(3,VV[22],car(base[2]),base[3]);
	{register object V54;
	register object V55;
	register object V56;
	V54= cdr(base[2]);
	V55= small_fixnum(0);
	V56= Cnil;
T259:;
	if(((V54))!=Cnil){
	goto T260;}
	V53= reverse((V56));
	goto T256;
T260:;
	V57= car((V54));
	V58= list(3,VV[22],/* INLINE-ARGS */V57,list(2,VV[23],(V55)));
	V56= make_cons(/* INLINE-ARGS */V58,(V56));
	V54= cdr((V54));
	V55= one_plus((V55));
	goto T259;}
T256:;
	base[4]= listA(3,VV[21],/* INLINE-ARGS */V52,V53);
	vs_top=(vs_base=base+4)+1;
	return;
}
/*	macro definition for MV-VALUES	*/

static L7()
{register object *base=vs_base;
	register object *sup=base+VM7; VC7
	vs_reserve(VM7);
	check_arg(2);
	vs_top=sup;
	{object V59=base[0]->c.c_cdr;
	base[2]= V59;}
	V60= car(base[2]);
	{register object V62;
	register object V63;
	register object V64;
	V62= cdr(base[2]);
	V63= small_fixnum(0);
	V64= Cnil;
T273:;
	if(((V62))!=Cnil){
	goto T274;}
	V61= reverse((V64));
	goto T270;
T274:;
	V65= list(3,VV[24],(V63),car((V62)));
	V64= make_cons(/* INLINE-ARGS */V65,(V64));
	V62= cdr((V62));
	V63= one_plus((V63));
	goto T273;}
T270:;
	base[3]= listA(3,VV[21],/* INLINE-ARGS */V60,V61);
	vs_top=(vs_base=base+3)+1;
	return;
}
/*	function definition for DBL	*/

static L8()
{register object *base=vs_base;
	register object *sup=base+VM8; VC8
	vs_reserve(VM8);
	check_arg(0);
	vs_top=sup;
TTL:;
	base[0]= Cnil;
	base[1]= Cnil;
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk126)();
	return;
}
/*	function definition for MAKE-INSTREAM	*/

static L9()
{register object *base=vs_base;
	register object *sup=base+VM9; VC9
	vs_reserve(VM9);
	{object V66;
	object V67;
	object V68;
	parse_key(vs_base,FALSE,FALSE,3,VV[27],VV[36],VV[127]);
	vs_top=sup;
	V66=(base[0]);
	if(base[4]==Cnil){
	V67= small_fixnum(0);
	}else{
	V67=(base[1]);}
	V68=(base[2]);
	base[6]= VV[25];
	base[7]= (V66);
	base[8]= (V67);
	base[9]= (V68);
	vs_top=(vs_base=base+6)+4;
	(void) (*Lnk128)();
	return;
	}
}
/*	function definition for CLEANUP	*/

static L10()
{register object *base=vs_base;
	register object *sup=base+VM10; VC10
	vs_reserve(VM10);
	check_arg(0);
	vs_top=sup;
TTL:;
	{register object V69;
	register object V70;
	V69= symbol_value(VV[26]);
	V70= car((V69));
T294:;
	if(!(endp((V69)))){
	goto T295;}
	base[1]= Cnil;
	vs_top=(vs_base=base+1)+1;
	return;
T295:;
	base[1]= structure_ref((V70),VV[25],0);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk129)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T299;}
	setq(VV[26],(VFUN_NARGS=2,(*(LnkLI130))((V70),symbol_value(VV[26]))));
T299:;
	V69= cdr((V69));
	V70= car((V69));
	goto T294;}
}
/*	function definition for GET-INSTREAM	*/

static L11()
{register object *base=vs_base;
	register object *sup=base+VM11; VC11
	vs_reserve(VM11);
	{register object V71;
	check_arg(1);
	V71=(base[0]);
	vs_top=sup;
TTL:;{object V72;
	{register object V73;
	register object V74;
	V73= symbol_value(VV[26]);
	V74= car((V73));
T314:;
	if(!(endp((V73)))){
	goto T315;}
	V72= Cnil;
	goto T310;
T315:;
	V75= structure_ref((V74),VV[25],0);
	if(!(((V71))==(/* INLINE-ARGS */V75))){
	goto T319;}
	V72= (V74);
	goto T310;
T319:;
	V73= cdr((V73));
	V74= car((V73));
	goto T314;}
T310:;
	if(V72==Cnil)goto T309;
	base[1]= V72;
	vs_top=(vs_base=base+1)+1;
	return;
T309:;}
	base[1]= VV[27];
	base[2]= (V71);
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk131)();
	vs_top=sup;
	V76= vs_base[0];
	setq(VV[26],make_cons(V76,symbol_value(VV[26])));
	base[1]= car(symbol_value(VV[26]));
	vs_top=(vs_base=base+1)+1;
	return;
	}
}
/*	function definition for NEWLINE	*/

static L12()
{register object *base=vs_base;
	register object *sup=base+VM12; VC12
	vs_reserve(VM12);
	{object V77;
	object V78;
	check_arg(2);
	V77=(base[0]);
	V78=(base[1]);
	vs_top=sup;
TTL:;
	{object V79;
	base[2]= (V77);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk132)();
	vs_top=sup;
	V79= vs_base[0];
	{int V80= fix(structure_ref((V79),VV[25],1));
	V81 = make_fixnum((1)+(/* INLINE-ARGS */V80));
	(void)(structure_set((V79),VV[25],1,V81));}}
	base[2]= Cnil;
	base[3]= (V77);
	base[4]= Cnil;
	vs_top=(vs_base=base+2)+3;
	(void) (*Lnk133)();
	vs_top=sup;
	V82= vs_base[0];
	if(!(eql(V82,VV[29]))){
	goto T338;}
	setq(VV[28],VV[30]);
	goto T336;
T338:;
	setq(VV[28],Ct);
T336:;
	vs_base=vs_top=base+2;
	vs_base[0]=Cnil;
	return;
	}
}
/*	function definition for QUOTATION-READER	*/

static L13()
{register object *base=vs_base;
	register object *sup=base+VM13; VC13
	vs_reserve(VM13);
	{object V83;
	object V84;
	check_arg(2);
	V83=(base[0]);
	V84=(base[1]);
	vs_top=sup;
TTL:;
	{object V85;
	object V86;
	V85= (
	(type_of(symbol_value(VV[31])) == t_sfun ?(*(object (*)())((symbol_value(VV[31]))->sfn.sfn_self)):
	(fcall.fun=(symbol_value(VV[31])),fcall.argd=2,fcalln))((V83),(V84)));
	base[2]= (V83);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk132)();
	vs_top=sup;
	V86= vs_base[0];
	{object V88;
	V89= structure_ref(V86,VV[25],1);
	V90= (VFUN_NARGS=2,(*(LnkLI134))(VV[32],(V85)));
	V88= number_plus(/* INLINE-ARGS */V89,/* INLINE-ARGS */V90);
	(void)(structure_set(V86,VV[25],1,(V88)));}
	base[2]= (V85);
	vs_top=(vs_base=base+2)+1;
	return;}
	}
}
/*	function definition for NEW-SEMI-COLON-READER	*/

static L14()
{register object *base=vs_base;
	register object *sup=base+VM14; VC14
	vs_reserve(VM14);
	bds_check;
	{register object V91;
	object V92;
	check_arg(2);
	V91=(base[0]);
	V92=(base[1]);
	vs_top=sup;
TTL:;
	{register object V93;
	object V94;
	base[2]= (V91);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk132)();
	vs_top=sup;
	V93= vs_base[0];
	base[2]= Cnil;
	base[3]= (V91);
	base[4]= Cnil;
	base[5]= Cnil;
	vs_top=(vs_base=base+2)+4;
	(void) (*Lnk133)();
	vs_top=sup;
	V94= vs_base[0];
	{int V95= fix(structure_ref((V93),VV[25],1));
	V96 = make_fixnum((1)+(/* INLINE-ARGS */V95));
	(void)(structure_set((V93),VV[25],1,V96));}
	if(!(eql((V94),VV[33]))){
	goto T359;}
	base[2]= (V91);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk135)();
	vs_top=sup;
	{register object V97;
	bds_bind(VV[34],symbol_value(VV[35]));
	base[5]= (V91);
	base[6]= Cnil;
	base[7]= Cnil;
	vs_top=(vs_base=base+5)+3;
	(void) (*Lnk136)();
	vs_top=sup;
	base[4]= vs_base[0];
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk137)();
	vs_top=sup;
	V97= vs_base[0];
	if(!(type_of((V97))==t_cons)){
	bds_unwind1;
	goto T357;}
	if(!((car((V97)))==(VV[36]))){
	bds_unwind1;
	goto T357;}
	if(!(type_of(cadr((V97)))==t_string)){
	bds_unwind1;
	goto T357;}
	if(!(type_of(caddr((V97)))==t_fixnum)){
	bds_unwind1;
	goto T357;}
	(void)(structure_set((V93),VV[25],2,cadr((V97))));
	V98= structure_set((V93),VV[25],1,caddr((V97)));
	bds_unwind1;
	goto T357;}
T359:;
	(void)((
	(type_of(symbol_value(VV[37])) == t_sfun ?(*(object (*)())((symbol_value(VV[37]))->sfn.sfn_self)):
	(fcall.fun=(symbol_value(VV[37])),fcall.argd=2,fcalln))((V91),(V92))));
T357:;
	base[2]= Cnil;
	base[3]= (V91);
	base[4]= Cnil;
	vs_top=(vs_base=base+2)+3;
	(void) (*Lnk133)();
	vs_top=sup;
	V99= vs_base[0];
	if(!(eql(V99,VV[29]))){
	goto T380;}
	setq(VV[28],VV[30]);
	goto T378;
T380:;
	setq(VV[28],Ct);
T378:;
	vs_base=vs_top=base+2;
	vs_base[0]=Cnil;
	return;}
	}
}
/*	function definition for SETUP-LINEINFO	*/

static L15()
{register object *base=vs_base;
	register object *sup=base+VM15; VC15
	vs_reserve(VM15);
	check_arg(0);
	vs_top=sup;
TTL:;
	base[0]= VV[32];
	base[1]= symbol_function(VV[138]);
	base[2]= Cnil;
	base[3]= symbol_value(VV[38]);
	vs_top=(vs_base=base+0)+4;
	(void) (*Lnk139)();
	vs_top=sup;
	base[0]= VV[39];
	base[1]= symbol_function(VV[140]);
	base[2]= Cnil;
	base[3]= symbol_value(VV[38]);
	vs_top=(vs_base=base+0)+4;
	(void) (*Lnk139)();
	vs_top=sup;
	base[0]= VV[29];
	base[1]= VV[40];
	base[2]= Cnil;
	base[3]= symbol_value(VV[38]);
	vs_top=(vs_base=base+0)+4;
	(void) (*Lnk139)();
	vs_top=sup;
	base[0]= VV[41];
	base[1]= VV[42];
	base[2]= Cnil;
	base[3]= symbol_value(VV[38]);
	vs_top=(vs_base=base+0)+4;
	(void) (*Lnk139)();
	return;
}
/*	function definition for NLOAD	*/

static L16()
{register object *base=vs_base;
	register object *sup=base+VM16; VC16
	vs_reserve(VM16);
	bds_check;
	{object V100;
	object V101;
	if(vs_top-vs_base<1) too_few_arguments();
	V100=(base[0]);
	vs_base=vs_base+1;
	vs_top[0]=Cnil;
	{object *p=vs_top;
	 for(;p>vs_base;p--)p[-1]=MMcons(p[-1],p[0]);}
	V101=(base[1]);
	vs_top=sup;
	base[2]= symbol_value(VV[43]);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk141)();
	vs_top=sup;
	vs_base=vs_top;
	(void) (*Lnk142)();
	vs_top=sup;
	base[2]= (V100);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk143)();
	vs_top=sup;
	V100= vs_base[0];
	vs_base=vs_top;
	(void) (*Lnk144)();
	vs_top=sup;
	bds_bind(VV[34],symbol_value(VV[38]));
	base[3]=symbol_function(VV[145]);
	base[4]= (V100);
	{object V102;
	V102= (V101);
	 vs_top=base+5;
	 while(!endp(V102))
	 {vs_push(car(V102));V102=cdr(V102);}
	vs_base=base+4;}
	(void) (*Lnk145)();
	bds_unwind1;
	return;
	}
}
/*	function definition for LEFT-PARENTHESIS-READER	*/

static L17()
{register object *base=vs_base;
	register object *sup=base+VM17; VC17
	vs_reserve(VM17);
	{object V103;
	object V104;
	check_arg(2);
	V103=(base[0]);
	V104=(base[1]);
	vs_top=sup;
TTL:;
	{object V105;
	register object V106;
	V105= Cnil;
	V106= symbol_value(VV[28]);
	if(!((symbol_value(VV[28]))==(Ct))){
	goto T416;}
	setq(VV[28],Cnil);
T416:;
	if(((V106))==Cnil){
	goto T420;}
	base[2]= (V103);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk132)();
	vs_top=sup;
	V106= vs_base[0];
	V105= structure_ref((V106),VV[25],1);
T420:;
	{object V107;
	V107= (
	(type_of(symbol_value(VV[44])) == t_sfun ?(*(object (*)())((symbol_value(VV[44]))->sfn.sfn_self)):
	(fcall.fun=(symbol_value(VV[44])),fcall.argd=2,fcalln))((V103),(V104)));
	if(((V106))==Cnil){
	goto T428;}
	{object V109;
	object V110;
	V109= symbol_value(VV[43]);
	base[3]= (V106);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk146)();
	vs_top=sup;
	V111= vs_base[0];
	V110= make_cons(V111,(V105));
	base[3]= V107;
	base[4]= (V109);
	base[5]= (V110);
	vs_top=(vs_base=base+3)+3;
	(void) (*Lnk147)();
	vs_top=sup;}
T428:;
	base[2]= (V107);
	vs_top=(vs_base=base+2)+1;
	return;}}
	}
}
/*	function definition for WALK-THROUGH	*/

static L18()
{register object *base=vs_base;
	register object *sup=base+VM18; VC18
	vs_reserve(VM18);
	{register object V112;
	check_arg(1);
	V112=(base[0]);
	vs_top=sup;
TTL:;
	{register object V113;
	V113= Cnil;
T440:;
	if(!(type_of((V112))==t_cons)){
	goto T441;}
	base[1]= (V112);
	base[2]= symbol_value(VV[43]);
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk148)();
	vs_top=sup;
	V113= vs_base[0];
	if(((V113))==Cnil){
	goto T444;}
	if(!(type_of(car((V112)))==t_cons)){
	goto T451;}
	if((caar((V112)))==(VV[45])){
	goto T451;}
	base[1]= (V112);
	base[2]= symbol_value(VV[43]);
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk149)();
	vs_top=sup;
	{register object V114;
	register object V115;
	register object V116;
	V114= car((V112));
	V115= symbol_value(VV[43]);
	V116= (V113);
	base[2]= (V114);
	base[3]= (V115);
	base[4]= (V116);
	vs_top=(vs_base=base+2)+3;
	(void) (*Lnk147)();
	vs_top=sup;
	goto T444;}
T451:;
	V117= make_cons((V113),(V112));
	(void)((VFUN_NARGS=2,(*(LnkLI150))(/* INLINE-ARGS */V117,symbol_value(VV[46]))));
T444:;
	base[1]= car((V112));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk151)();
	vs_top=sup;
	V112= cdr((V112));
	goto T440;
T441:;
	base[1]= Cnil;
	vs_top=(vs_base=base+1)+1;
	return;}
	}
}
/*	function definition for COMPILER-DEF-HOOK	*/

static L19()
{register object *base=vs_base;
	register object *sup=base+VM19; VC19
	vs_reserve(VM19);
	{object V118;
	object V119;
	check_arg(2);
	V118=(base[0]);
	V119=(base[1]);
	vs_top=sup;
TTL:;
	{object V120;
	register int V121;
	int V122;
	V120= symbol_value(VV[46]);
	V121= 2147483647;
	V122= -1;
	if(!(type_of((V119))!=t_cons)){
	goto T472;}
	base[2]= remprop((V118),VV[48]);
	vs_top=(vs_base=base+2)+1;
	return;
T472:;
	if(!((symbol_value(VV[34]))==(symbol_value(VV[38])))){
	goto T475;}
	base[2]= symbol_value(VV[46]);
	base[3]= small_fixnum(0);
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk152)();
	vs_top=sup;
	base[2]= (V119);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk151)();
	vs_top=sup;
	{object V123;
	register int V124;
	V123= make_fixnum(length((V120)));
	V124= 0;
T486:;
	V125 = make_fixnum(V124);
	if(!(number_compare(V125,(V123))>=0)){
	goto T487;}
	goto T482;
T487:;
	{register int V126;
	V127= aref1((V120),V124);
	V126= fix(cdar(/* INLINE-ARGS */V127));
	if(!((V126)>(V122))){
	goto T493;}
	V122= V126;
T493:;
	if(!((V126)<(V121))){
	goto T491;}
	V121= V126;}
T491:;
	V124= (V124)+1;
	goto T486;}
T482:;
	if(!((length(symbol_value(VV[46])))>(0))){
	goto T504;}
	{object V128;
	object V129;
	V130 = make_fixnum(((V122)-(V121))+(2));
	V128= (VFUN_NARGS=3,(*(LnkLI153))(V130,VV[49],VV[50]));
	V129= get((V118),VV[48],Cnil);
	V131= aref1((V120),0);
	V132= caar(/* INLINE-ARGS */V131);
	V133 = make_fixnum(V121);
	V134= make_cons(/* INLINE-ARGS */V132,V133);
	(void)(aset1((V128),0,/* INLINE-ARGS */V134));
	V121= (V121)-(1);
	{object V135;
	register object V136;
	V135= make_fixnum(length((V120)));
	V136= small_fixnum(0);
T515:;
	if(!(number_compare((V136),(V135))>=0)){
	goto T516;}
	goto T511;
T516:;
	{object V137;
	V137= aref1((V120),fixint((V136)));
	(void)(aset1((V128),(fix(cdar((V137))))-(V121),cdr((V137))));}
	V136= one_plus((V136));
	goto T515;}
T511:;
	(void)(sputprop((V118),VV[48],(V128)));
	if(((V129))==Cnil){
	goto T527;}
	{object V138;
	object V139;
	V138= get((V118),VV[51],Cnil);
	V140= aref1((V129),0);
	V139= cdr(/* INLINE-ARGS */V140);
	{register object V141;
	object V142;
	V141= (V138);
	V142= car((V141));
T534:;
	if(!(endp((V141)))){
	goto T535;}
	base[3]= Cnil;
	vs_top=(vs_base=base+3)+1;
	return;
T535:;
	{object V143;
	object V144;
	object V145;
	V143= aref1(symbol_value(VV[52]),fixint((V142)));
	{object V146= cdr(cdr(cdr((V143))));
	if((type_of(V146)!=t_cons) && ((V143)!= Cnil))
	 FEwrong_type_argument(Scons,V146);
	V144= (V146->c.c_car);}
	{object V148= cdr(cdr((V143)));
	if((type_of(V148)!=t_cons) && ((V143)!= Cnil))
	 FEwrong_type_argument(Scons,V148);
	V147= fix((V148->c.c_car));}
	V145= make_fixnum((V147)-(fix((V139))));{object V149;
	V149= symbol_value(VV[52]);
	base[6]= (V144);
	base[7]= (V128);
	base[8]= (V145);
	vs_top=(vs_base=base+6)+3;
	(void) (*Lnk154)();
	vs_top=sup;
	V150= vs_base[0];
	(void)(aset1(V149,fixint((V142)),V150));}}
	V141= cdr((V141));
	V142= car((V141));
	goto T534;}}
T527:;
	base[2]= Cnil;
	vs_top=(vs_base=base+2)+1;
	return;}
T504:;
	{object V151;
	V151= get((V118),VV[51],Cnil);
	base[2]= (V151);
	base[3]= VV[53];
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk155)();
	return;}
T475:;
	base[2]= Cnil;
	vs_top=(vs_base=base+2)+1;
	return;}
	}
}
/*	function definition for INSTREAM-NAME	*/

static L20()
{register object *base=vs_base;
	register object *sup=base+VM20; VC20
	vs_reserve(VM20);
	{object V152;
	check_arg(1);
	V152=(base[0]);
	vs_top=sup;
TTL:;{object V153;
	V153= structure_ref((V152),VV[25],2);
	if(V153==Cnil)goto T556;
	base[1]= V153;
	vs_top=(vs_base=base+1)+1;
	return;
T556:;}
	base[1]= structure_ref((V152),VV[25],0);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk156)();
	return;
	}
}
static object stream_name(str) object str;{return str->sm.sm_object1; }
/*	function definition for STREAM-NAME	*/

static L21()
{	object *old_base=vs_base;
	object x;
	check_arg(1);
	x=
	stream_name(
	vs_base[0]);
	vs_top=(vs_base=old_base)+1;
	vs_base[0]=x;
}
static object closedp(str) object str;{return (str->sm.sm_fp==0 ? Ct :Cnil); }
/*	function definition for CLOSEDP	*/

static L22()
{	object *old_base=vs_base;
	object x;
	check_arg(1);
	x=
	closedp(
	vs_base[0]);
	vs_top=(vs_base=old_base)+1;
	vs_base[0]=x;
}
/*	function definition for FIND-LINE-IN-FUN	*/

static L23()
{register object *base=vs_base;
	register object *sup=base+VM21; VC21
	vs_reserve(VM21);
	{object V154;
	object V155;
	register object V156;
	register object V157;
	check_arg(4);
	V154=(base[0]);
	V155=(base[1]);
	V156=(base[2]);
	V157=(base[3]);
	vs_top=sup;
TTL:;
	{object V158;
	V158= Cnil;
	V158= get((V156),VV[48],Cnil);
	if(((V158))==Cnil){
	goto T563;}
	{register object V159;
	V159= (V158);
	if(((V159))==Cnil){
	goto T566;}
	{object V160;
	register object V161;
	V160= make_fixnum(length((V159)));
	V161= small_fixnum(0);
T571:;
	if(!(number_compare((V161),(V160))>=0)){
	goto T572;}
	base[5]= Cnil;
	vs_top=(vs_base=base+5)+1;
	return;
T572:;
	V162= aref1((V159),fixint((V161)));
	if(!(((V154))==(/* INLINE-ARGS */V162))){
	goto T576;}
	if(((V157))==Cnil){
	goto T579;}
	{register object V163;
	register object V164;
	V163= (V157);
	V164= number_minus(car((V163)),small_fixnum(1));
	if(type_of((V163))!=t_cons)FEwrong_type_argument(Scons,(V163));
	((V163))->c.c_car = (V164);}
	if(!((fix(car((V157))))>(0))){
	goto T579;}
	base[5]= VV[54];
	vs_top=(vs_base=base+5)+1;
	return;
T579:;
	base[6]= (V156);
	base[7]= (V159);
	base[8]= (V161);
	vs_top=(vs_base=base+6)+3;
	(void) (*Lnk154)();
	vs_top=sup;
	setq(VV[55],vs_base[0]);
	base[5]= symbol_value(VV[55]);
	base[6]= (V155);
	vs_top=(vs_base=base+5)+2;
	(void) (*Lnk126)();
	vs_top=sup;
	base[5]= VV[54];
	vs_top=(vs_base=base+5)+1;
	return;
T576:;
	V161= one_plus((V161));
	goto T571;}
T566:;
	base[4]= Cnil;
	vs_top=(vs_base=base+4)+1;
	return;}
T563:;
	base[4]= Cnil;
	vs_top=(vs_base=base+4)+1;
	return;}
	}
}
/*	function definition for CURRENT-STEP-FUN	*/

static L24()
{register object *base=vs_base;
	register object *sup=base+VM22; VC22
	vs_reserve(VM22);
	{object V165;
	if(vs_top-vs_base>1) too_many_arguments();
	if(vs_base>=vs_top){vs_top=sup;goto T598;}
	V165=(base[0]);
	vs_top=sup;
	goto T599;
T598:;
	vs_base=vs_top;
	(void) (*Lnk112)();
	vs_top=sup;
	V165= vs_base[0];
T599:;
	{register object V166;
	V166= one_minus((V165));
T603:;
	if(!((fix((V166)))<=(0))){
	goto T604;}
	base[1]= Cnil;
	vs_top=(vs_base=base+1)+1;
	return;
T604:;
	{register object V167;
	base[1]= (V166);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk157)();
	vs_top=sup;
	V167= vs_base[0];
	if((get((V167),VV[48],Cnil))==Cnil){
	goto T608;}
	base[1]= (V167);
	vs_top=(vs_base=base+1)+1;
	return;}
T608:;
	V166= make_fixnum((fix((V166)))-(1));
	goto T603;}
	}
}
/*	function definition for INIT-BREAK-POINTS	*/

static L25()
{register object *base=vs_base;
	register object *sup=base+VM23; VC23
	vs_reserve(VM23);
	check_arg(0);
	vs_top=sup;
TTL:;
	base[0]= symbol_value(VV[56]);
	base[1]= small_fixnum(0);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk152)();
	vs_top=sup;
	setq(VV[52],symbol_value(VV[56]));
	base[0]= symbol_value(VV[52]);
	vs_top=(vs_base=base+0)+1;
	return;
}
/*	function definition for STEP-INTO	*/

static L26()
{register object *base=vs_base;
	register object *sup=base+VM24; VC24
	vs_reserve(VM24);
	{object V168;
	if(vs_top-vs_base>1) too_many_arguments();
	if(vs_base>=vs_top){vs_top=sup;goto T620;}
	V168=(base[0]);
	vs_top=sup;
	goto T621;
T620:;
	V168= small_fixnum(1);
T621:;
	if(symbol_value(VV[52])!=Cnil){
	goto T623;}
	vs_base=vs_top;
	(void) (*Lnk158)();
	vs_top=sup;
T623:;
	setq(VV[57],VV[58]);
	base[1]= VV[59];
	vs_top=(vs_base=base+1)+1;
	return;
	}
}
/*	function definition for STEP-NEXT	*/

static L27()
{register object *base=vs_base;
	register object *sup=base+VM25; VC25
	vs_reserve(VM25);
	{object V169;
	if(vs_top-vs_base>1) too_many_arguments();
	if(vs_base>=vs_top){vs_top=sup;goto T626;}
	V169=(base[0]);
	vs_top=sup;
	goto T627;
T626:;
	V169= small_fixnum(1);
T627:;
	{object V170;
	vs_base=vs_top;
	(void) (*Lnk159)();
	vs_top=sup;
	V170= vs_base[0];
	setq(VV[60],make_cons((V169),(V170)));
	if(symbol_value(VV[52])!=Cnil){
	goto T632;}
	vs_base=vs_top;
	(void) (*Lnk158)();
	vs_top=sup;
T632:;
	setq(VV[57],VV[61]);
	base[1]= VV[59];
	vs_top=(vs_base=base+1)+1;
	return;}
	}
}
/*	function definition for MAYBE-BREAK	*/

static L28()
{register object *base=vs_base;
	register object *sup=base+VM26; VC26
	vs_reserve(VM26);
	{object V171;
	object V172;
	object V173;
	object V174;
	check_arg(4);
	V171=(base[0]);
	V172=(base[1]);
	V173=(base[2]);
	V174=(base[3]);
	vs_top=sup;
TTL:;
	{object V175;
	V175= Cnil;
	V175= (VFUN_NARGS=2,(*(LnkLI160))((V171),(V172)));
	if(((V175))==Cnil){
	goto T637;}
	setq(VV[57],Cnil);{object V176;
	base[4]= make_fixnum(length(symbol_value(VV[52])));
	base[5]= small_fixnum(0);
	vs_top=(vs_base=base+4)+2;
	(void) (*Lnk108)();
	vs_top=sup;
	V176= vs_base[0];
	if(V176==Cnil)goto T643;
	goto T642;
T643:;}
	setq(VV[52],Cnil);
T642:;
	base[5]= (V173);
	base[6]= (V172);
	base[7]= (V175);
	vs_top=(vs_base=base+5)+3;
	(void) (*Lnk154)();
	vs_top=sup;
	base[4]= vs_base[0];
	base[5]= (V174);
	vs_top=(vs_base=base+4)+2;
	(void) (*Lnk126)();
	vs_top=sup;
	base[4]= Ct;
	vs_top=(vs_base=base+4)+1;
	return;
T637:;
	base[4]= Cnil;
	vs_top=(vs_base=base+4)+1;
	return;}
	}
}
/*	function definition for BREAK-STEP-INTO	*/

static L29()
{register object *base=vs_base;
	register object *sup=base+VM27; VC27
	vs_reserve(VM27);
	{object V177;
	object V178;
	check_arg(2);
	V177=(base[0]);
	V178=(base[1]);
	vs_top=sup;
TTL:;
	{object V179;
	vs_base=vs_top;
	(void) (*Lnk159)();
	vs_top=sup;
	V179= vs_base[0];
	{object V180;
	V180= get((V179),VV[48],Cnil);
	base[2]= (V177);
	base[3]= (V180);
	base[4]= (V179);
	base[5]= (V178);
	vs_top=(vs_base=base+2)+4;
	(void) (*Lnk161)();
	return;}}
	}
}
/*	function definition for BREAK-STEP-NEXT	*/

static L30()
{register object *base=vs_base;
	register object *sup=base+VM28; VC28
	vs_reserve(VM28);
	{object V181;
	object V182;
	check_arg(2);
	V181=(base[0]);
	V182=(base[1]);
	vs_top=sup;
TTL:;
	{object V183;
	vs_base=vs_top;
	(void) (*Lnk159)();
	vs_top=sup;
	V183= vs_base[0];
	if(!(eql(cdr(symbol_value(VV[60])),(V183)))){
	goto T662;}
	{object V184;
	V184= get((V183),VV[48],Cnil);
	base[2]= (V181);
	base[3]= (V184);
	base[4]= (V183);
	base[5]= (V182);
	vs_top=(vs_base=base+2)+4;
	(void) (*Lnk161)();
	return;}
T662:;
	base[2]= Cnil;
	vs_top=(vs_base=base+2)+1;
	return;}
	}
}
/*	function definition for *BREAK-POINTS*	*/

static L31()
{register object *base=vs_base;
	register object *sup=base+VM29; VC29
	vs_reserve(VM29);
	{object V185;
	object V186;
	check_arg(2);
	V185=(base[0]);
	V186=(base[1]);
	vs_top=sup;
TTL:;
	{object V187;
	V187= (VFUN_NARGS=4,(*(LnkLI160))((V185),symbol_value(VV[52]),VV[62],VV[63]));
	base[2]= Ct;
	base[3]= VV[64];
	base[4]= (V187);
	vs_top=(vs_base=base+2)+3;
	(void) (*Lnk107)();
	vs_top=sup;
	base[2]= aref1(symbol_value(VV[52]),fixint((V187)));
	base[3]= (V186);
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk126)();
	return;}
	}
}
/*	function definition for DWIM	*/

static L32()
{register object *base=vs_base;
	register object *sup=base+VM30; VC30
	vs_reserve(VM30);
	{register object V188;
	check_arg(1);
	V188=(base[0]);
	vs_top=sup;
TTL:;
	{register object V189;
	register object V190;
	vs_base=vs_top;
	(void) (*Lnk162)();
	vs_top=sup;
	V189= vs_base[0];
	V190= car((V189));
T680:;
	if(!(endp((V189)))){
	goto T681;}
	goto T676;
T681:;
	{register object V191;
	register object V192;
	base[3]= symbol_name((V188));
	base[4]= (V190);
	vs_top=(vs_base=base+3)+2;
	(void) (*Lnk163)();
	if(vs_base>=vs_top){vs_top=sup;goto T689;}
	V191= vs_base[0];
	vs_base++;
	if(vs_base>=vs_top){vs_top=sup;goto T690;}
	V192= vs_base[0];
	vs_top=sup;
	goto T691;
T689:;
	V191= Cnil;
T690:;
	V192= Cnil;
T691:;
	if((get((V191),VV[48],Cnil))==Cnil){
	goto T693;}
	base[3]= (V191);
	vs_top=(vs_base=base+3)+1;
	return;
T693:;
	if((V192)!=Cnil){
	goto T685;}
	base[3]= (V191);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk164)();
	vs_top=sup;}
T685:;
	V189= cdr((V189));
	V190= car((V189));
	goto T680;}
T676:;
	base[1]= Ct;
	base[2]= VV[65];
	base[3]= (V188);
	vs_top=(vs_base=base+1)+3;
	(void) (*Lnk107)();
	return;
	}
}
/*	function definition for BREAK-FUNCTION	*/

static L33()
{register object *base=vs_base;
	register object *sup=base+VM31; VC31
	vs_reserve(VM31);
	{register object V193;
	register object V194;
	object V195;
	if(vs_top-vs_base<1) too_few_arguments();
	if(vs_top-vs_base>3) too_many_arguments();
	V193=(base[0]);
	vs_base=vs_base+1;
	if(vs_base>=vs_top){vs_top=sup;goto T704;}
	V194=(base[1]);
	vs_base++;
	if(vs_base>=vs_top){vs_top=sup;goto T705;}
	V195=(base[2]);
	vs_top=sup;
	goto T706;
T704:;
	V194= small_fixnum(1);
T705:;
	V195= Cnil;
T706:;
	{object V196;
	V196= Cnil;
	{register object V197;
	V197= get((V193),VV[48],Cnil);
	if(((V197))!=Cnil){
	goto T711;}
	base[3]= (V193);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk165)();
	vs_top=sup;
	V196= vs_base[0];
	if(((V196))==Cnil){
	goto T711;}
	base[3]= (V196);
	base[4]= (V194);
	base[5]= (V195);
	vs_top=(vs_base=base+3)+3;
	(void) (*Lnk166)();
	return;
T711:;{object V198;
	base[3]= (V197);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk167)();
	vs_top=sup;
	V198= vs_base[0];
	if(V198==Cnil)goto T723;
	goto T722;
T723:;}
	base[3]= Ct;
	base[4]= VV[66];
	base[5]= (V193);
	vs_top=(vs_base=base+3)+3;
	(void) (*Lnk107)();
	vs_top=sup;
	base[3]= Cnil;
	vs_top=(vs_base=base+3)+1;
	return;
T722:;
	{object V199;
	V200= aref1((V197),0);
	V199= cdr(/* INLINE-ARGS */V200);
	if(((V195))==Cnil){
	goto T731;}
	V194= make_fixnum((fix((V194)))-(fix((V199))));
T731:;{object V201;
	base[3]= (V194);
	base[4]= small_fixnum(1);
	vs_top=(vs_base=base+3)+2;
	(void) (*Lnk121)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T738;}
	V201= Cnil;
	goto T737;
T738:;
	base[3]= (V194);
	base[4]= make_fixnum(length((V197)));
	vs_top=(vs_base=base+3)+2;
	(void) (*Lnk123)();
	vs_top=sup;
	V201= vs_base[0];
T737:;
	if(V201==Cnil)goto T736;
	goto T735;
T736:;}{object V202;
	base[3]= Ct;
	base[4]= VV[67];
	base[5]= (V193);
	vs_top=(vs_base=base+3)+3;
	(void) (*Lnk107)();
	vs_top=sup;
	V202= vs_base[0];
	if(V202==Cnil)goto T744;
	goto T735;
T744:;}
	base[3]= Cnil;
	vs_top=(vs_base=base+3)+1;
	return;
T735:;
	if(!(eql((V194),small_fixnum(1)))){
	goto T749;}
	{object V203;
	base[3]= (V193);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk168)();
	vs_top=sup;
	V203= vs_base[0];
	if(!(type_of((V203))==t_cons)){
	goto T749;}
	if(!((car((V203)))==(VV[68]))){
	goto T749;}
	if((caddr((V203)))==Cnil){
	goto T749;}
	V194= small_fixnum(2);}
T749:;
	{register object V204;
	register object V205;
	V204= make_fixnum((length((V197)))-(fix((V194))));
	V205= small_fixnum(0);
T765:;
	if(!(number_compare((V205),(V204))>=0)){
	goto T766;}
	goto T761;
T766:;
	V206= aref1((V197),fixint((V205)));
	if((/* INLINE-ARGS */V206)==(VV[50])){
	goto T770;}
	base[6]= (V193);
	base[7]= (V197);
	base[8]= make_fixnum((fix((V194)))+(fix((V205))));
	vs_top=(vs_base=base+6)+3;
	(void) (*Lnk154)();
	vs_top=sup;
	base[5]= vs_base[0];
	vs_top=(vs_base=base+5)+1;
	(void) (*Lnk169)();
	vs_top=sup;
	base[4]= vs_base[0];
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk170)();
	vs_top=sup;
	vs_base=vs_top=base+4;
	vs_base[0]=Cnil;
	return;
T770:;
	V205= one_plus((V205));
	goto T765;}
T761:;
	base[3]= Ct;
	base[4]= VV[69];
	vs_top=(vs_base=base+3)+2;
	(void) (*Lnk107)();
	return;}}}
	}
}
/*	function definition for INSERT-BREAK-POINT	*/

static L34()
{register object *base=vs_base;
	register object *sup=base+VM32; VC32
	vs_reserve(VM32);
	{object V207;
	check_arg(1);
	V207=(base[0]);
	vs_top=sup;
TTL:;
	{register object V208;
	V208= Cnil;
	if(symbol_value(VV[52])!=Cnil){
	goto T785;}
	vs_base=vs_top;
	(void) (*Lnk158)();
	vs_top=sup;
T785:;{object V209;
	V209= (VFUN_NARGS=2,(*(LnkLI160))(Cnil,symbol_value(VV[52])));
	if(V209==Cnil)goto T788;
	V208= V209;
	goto T787;
T788:;}
	{object V210;
	V210= make_fixnum(length(symbol_value(VV[52])));
	(void)((VFUN_NARGS=2,(*(LnkLI150))(Cnil,symbol_value(VV[52]))));
	V208= (V210);}
T787:;
	{object V211;
	{object V212= cdr(cdr(cdr((V207))));
	if((type_of(V212)!=t_cons) && ((V207)!= Cnil))
	 FEwrong_type_argument(Scons,V212);
	V211= (V212->c.c_car);}
	{object V215;
	V216= get(V211,VV[51],Cnil);
	V215= make_cons((V208),V216);
	(void)(sputprop(V211,VV[51],(V215)));}}
	(void)(aset1(symbol_value(VV[52]),fixint((V208)),(V207)));
	base[1]= (V208);
	vs_top=(vs_base=base+1)+1;
	return;}
	}
}
/*	function definition for SHORT-NAME	*/

static L35()
{register object *base=vs_base;
	register object *sup=base+VM33; VC33
	vs_reserve(VM33);
	{object V217;
	check_arg(1);
	V217=(base[0]);
	vs_top=sup;
TTL:;
	{object V218;
	V218= (VFUN_NARGS=4,(*(LnkLI160))(VV[70],(V217),VV[71],Ct));
	if(((V218))==Cnil){
	goto T799;}
	base[1]= (V217);
	base[2]= make_fixnum((1)+(fix((V218))));
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk171)();
	return;
T799:;
	base[1]= (V217);
	vs_top=(vs_base=base+1)+1;
	return;}
	}
}
/*	function definition for SHOW-BREAK-POINT	*/

static L36()
{register object *base=vs_base;
	register object *sup=base+VM34; VC34
	vs_reserve(VM34);
	{object V219;
	check_arg(1);
	V219=(base[0]);
	vs_top=sup;
TTL:;
	{object V220;
	V220= Cnil;
	{register object V221;
	V221= aref1(symbol_value(VV[52]),fixint((V219)));
	if(((V221))==Cnil){
	goto T806;}
	if(!((car((V221)))==(Cnil))){
	goto T808;}
	V220= Ct;
	V221= cdr((V221));
T808:;
	base[1]= Ct;
	base[2]= VV[72];
	base[3]= (V219);
	base[5]= cadr((V221));
	vs_top=(vs_base=base+5)+1;
	(void) (*Lnk172)();
	vs_top=sup;
	base[4]= vs_base[0];
	base[5]= caddr((V221));
	base[6]= (V220);
	vs_top=(vs_base=base+1)+6;
	(void) (*Lnk107)();
	vs_top=sup;
	{object V222;
	V222= cadddr((V221));
	base[1]= Ct;
	base[2]= VV[73];
	base[4]= (V222);
	base[5]= caddr((V221));
	vs_top=(vs_base=base+4)+2;
	(void) (*Lnk173)();
	vs_top=sup;
	base[3]= vs_base[0];
	base[4]= (V222);
	vs_top=(vs_base=base+1)+4;
	(void) (*Lnk107)();
	return;}
T806:;
	base[1]= Cnil;
	vs_top=(vs_base=base+1)+1;
	return;}}
	}
}
/*	function definition for ITERATE-OVER-BKPTS	*/

static L37()
{register object *base=vs_base;
	register object *sup=base+VM35; VC35
	vs_reserve(VM35);
	{register object V223;
	register object V224;
	check_arg(2);
	V223=(base[0]);
	V224=(base[1]);
	vs_top=sup;
TTL:;
	{register object V225;
	register object V226;
	V225= make_fixnum(length(symbol_value(VV[52])));
	V226= small_fixnum(0);
T832:;
	if(!(number_compare((V226),(V225))>=0)){
	goto T833;}
	base[3]= Cnil;
	vs_top=(vs_base=base+3)+1;
	return;
T833:;
	{register object x= (V226),V227= (V223);
	while(!endp(V227))
	if(eql(x,V227->c.c_car)){
	goto T838;
	}else V227=V227->c.c_cdr;}
	if(((V223))!=Cnil){
	goto T837;}
T838:;
	{register object V228;
	V228= aref1(symbol_value(VV[52]),fixint((V226)));{object V229;
	V229= symbol_value(VV[52]);
	{object V231= (V224);
	if((V231!= VV[53]))goto T844;
	if(((V228))==Cnil){
	goto T845;}
	{object V233= cdr(cdr(cdr((V228))));
	if((type_of(V233)!=t_cons) && ((V228)!= Cnil))
	 FEwrong_type_argument(Scons,V233);
	V232= (V233->c.c_car);}
	{object V236= cdr(cdr(cdr((V228))));
	if((type_of(V236)!=t_cons) && ((V228)!= Cnil))
	 FEwrong_type_argument(Scons,V236);
	V235= (V236->c.c_car);}
	V234= get(V235,VV[51],Cnil);
	V237= (VFUN_NARGS=2,(*(LnkLI130))((V226),V234));
	(void)(sputprop(V232,VV[51],/* INLINE-ARGS */V237));
T845:;
	V230= Cnil;
	goto T843;
T844:;
	if((V231!= VV[174]))goto T851;
	if(!((car((V228)))==(Cnil))){
	goto T853;}
	V230= cdr((V228));
	goto T843;
T853:;
	V230= Cnil;
	goto T843;
T851:;
	if((V231!= VV[175]))goto T855;
	if(((V228))==Cnil){
	goto T857;}
	if((car((V228)))==(Cnil)){
	goto T857;}
	V230= make_cons(Cnil,(V228));
	goto T843;
T857:;
	V230= (V228);
	goto T843;
T855:;
	if((V231!= VV[176]))goto T861;
	if(((V228))==Cnil){
	goto T862;}
	base[3]= (V226);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk170)();
	vs_top=sup;
	princ_char(10,Cnil);
T862:;
	V230= (V228);
	goto T843;
T861:;
	V230= Cnil;}
T843:;
	(void)(aset1(V229,fixint((V226)),V230));}}
T837:;
	V226= one_plus((V226));
	goto T832;}
	}
}
/*	function definition for DISPLAY-ENV	*/

static L38()
{register object *base=vs_base;
	register object *sup=base+VM36; VC36
	vs_reserve(VM36);
	{register object V238;
	object V239;
	check_arg(2);
	V238=(base[0]);
	V239=(base[1]);
	vs_top=sup;
TTL:;
	{register object V240;
	V240= reverse((V239));
T872:;
	if(!(type_of((V240))==t_cons)){
	goto T874;}
	base[2]= symbol_value(VV[74]);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk177)();
	vs_top=sup;
	V241= vs_base[0];
	if(!((fix(V241))>(fix((V238))))){
	goto T873;}
T874:;
	base[2]= Cnil;
	vs_top=(vs_base=base+2)+1;
	return;
T873:;{object V242;
	base[2]= car((V240));
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk178)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T884;}
	V242= Cnil;
	goto T883;
T884:;
	base[2]= cdar((V240));
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk179)();
	vs_top=sup;
	V242= vs_base[0];
T883:;
	if(V242==Cnil)goto T882;
	goto T881;
T882:;}
	base[2]= Cnil;
	vs_top=(vs_base=base+2)+1;
	return;
T881:;
	base[2]= symbol_value(VV[74]);
	base[3]= VV[75];
	base[4]= caar((V240));
	base[5]= cadar((V240));
	base[6]= cdr((V240));
	vs_top=(vs_base=base+2)+5;
	(void) (*Lnk107)();
	vs_top=sup;
	V240= cdr((V240));
	goto T872;}
	}
}
/*	function definition for APPLY-DISPLAY-FUN	*/

static L39()
{register object *base=vs_base;
	register object *sup=base+VM37; VC37
	vs_reserve(VM37);
	bds_check;
	{object V243;
	object V244;
	object V245;
	check_arg(3);
	V243=(base[0]);
	V244=(base[1]);
	V245=(base[2]);
	vs_top=sup;
TTL:;
	bds_bind(VV[13],symbol_value(VV[10]));
	bds_bind(VV[11],symbol_value(VV[10]));
	bds_bind(VV[76],Cnil);
	bds_bind(VV[77],VV[78]);
	bds_bind(VV[12],Ct);
	base[8]= symbol_value(VV[74]);
	base[9]= small_fixnum(0);
	vs_top=(vs_base=base+8)+2;
	(void) (*Lnk152)();
	vs_top=sup;
	base[8]= symbol_value(VV[74]);
	base[9]= VV[79];
	vs_top=(vs_base=base+8)+2;
	(void) (*Lnk107)();
	vs_top=sup;
	(void)((
	(type_of((V243)) == t_sfun ?(*(object (*)())(((V243))->sfn.sfn_self)):
	(fcall.fun=((V243)),fcall.argd=2,fcalln))((V244),(V245))));
	base[8]= symbol_value(VV[74]);
	vs_top=(vs_base=base+8)+1;
	(void) (*Lnk177)();
	vs_top=sup;
	V246= vs_base[0];
	if(!((fix(V246))>(fix((V244))))){
	goto T905;}
	base[8]= symbol_value(VV[74]);
	base[9]= (V244);
	vs_top=(vs_base=base+8)+2;
	(void) (*Lnk152)();
	vs_top=sup;
	base[8]= symbol_value(VV[74]);
	base[9]= VV[80];
	vs_top=(vs_base=base+8)+2;
	(void) (*Lnk107)();
	vs_top=sup;
T905:;
	base[8]= symbol_value(VV[74]);
	base[9]= VV[81];
	vs_top=(vs_base=base+8)+2;
	(void) (*Lnk107)();
	vs_top=sup;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	base[3]= symbol_value(VV[74]);
	vs_top=(vs_base=base+3)+1;
	return;
	}
}
/*	function definition for GET-LINE-OF-FORM	*/

static L40()
{register object *base=vs_base;
	register object *sup=base+VM38; VC38
	vs_reserve(VM38);
	{object V247;
	object V248;
	check_arg(2);
	V247=(base[0]);
	V248=(base[1]);
	vs_top=sup;
TTL:;
	{object V249;
	V249= (VFUN_NARGS=2,(*(LnkLI160))((V247),(V248)));
	if(((V249))==Cnil){
	goto T919;}
	V250= aref1((V248),0);
	base[2]= make_fixnum((fix((V249)))+(fix(cdr(/* INLINE-ARGS */V250))));
	vs_top=(vs_base=base+2)+1;
	return;
T919:;
	base[2]= Cnil;
	vs_top=(vs_base=base+2)+1;
	return;}
	}
}
/*	function definition for GET-NEXT-VISIBLE-FUN	*/

static L41()
{register object *base=vs_base;
	register object *sup=base+VM39; VC39
	vs_reserve(VM39);
	{object V251;
	check_arg(1);
	V251=(base[0]);
	vs_top=sup;
TTL:;
	{register object V252;
	V252= (V251);
T922:;
	if(!((fix((V252)))<(fix(symbol_value(VV[82]))))){
	goto T923;}
	{register object V253;
	V253= Cnil;
	(void)((MVloc[(0)]=((V252))));
	base[1]= (V253);
	vs_top=(vs_base=base+1)+1;
	return;}
T923:;
	{register object V254;
	base[1]= (V252);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk157)();
	vs_top=sup;
	V254= vs_base[0];
	{register object V255;
	base[1]= (V254);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk180)();
	vs_top=sup;
	V255= vs_base[0];
	if(((V255))==Cnil){
	goto T934;}
	goto T928;
T934:;
	{register object V256;
	V256= get((V254),VV[83],Cnil);
	if(((V256))==Cnil){
	goto T938;}
	goto T928;
T938:;
	base[1]= (V254);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk181)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T928;}
	{register object V257;
	V257= (V254);
	(void)((MVloc[(0)]=((V252))));
	base[1]= (V257);
	vs_top=(vs_base=base+1)+1;
	return;}}}}
T928:;
	V252= make_fixnum((fix((V252)))-(1));
	goto T922;}
	}
}
/*	function definition for DBL-WHAT-FRAME	*/

static L42()
{register object *base=vs_base;
	register object *sup=base+VM40; VC40
	vs_reserve(VM40);
	{register int V258;
	check_arg(1);
	V258=fix(base[0]);
	vs_top=sup;
TTL:;
	{register int V259;
	register int V260;
	register object V261;
	V259= fix(symbol_value(VV[84]));
	V260= 0;
	V261= Cnil;
T951:;
	{register object V262;
	base[1]= make_fixnum(V259);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk182)();
	vs_top=sup;
	V261= vs_base[0];
	V262= (V261);
	V259= fix((MVloc[(0)]));}
	if(!((V259)<=(V258))){
	goto T959;}
	base[1]= make_fixnum(V260);
	vs_top=(vs_base=base+1)+1;
	return;
T959:;
	V260= (V260)+(1);
	V259= (V259)-(1);
	goto T951;}
	}
}
/*	function definition for DBL-UP	*/

static L43()
{register object *base=vs_base;
	register object *sup=base+VM41; VC41
	vs_reserve(VM41);
	{register object V263;
	object V264;
	check_arg(2);
	V263=(base[0]);
	V264=(base[1]);
	vs_top=sup;
TTL:;
	{object V265;
	object V266;
	object V267;
	object V268;
	object V269;
	V265= Cnil;
	V266= Cnil;
	V267= Cnil;
	V268= Cnil;
	V269= Cnil;
	base[2]= (V264);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk183)();
	vs_top=sup;
	V265= vs_base[0];
	if(!((fix((V263)))>=(0))){
	goto T975;}
	{object V270;
	base[2]= (V263);
	base[3]= (V264);
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk184)();
	vs_top=sup;
	setq(VV[9],vs_base[0]);
	V270= symbol_value(VV[9]);
	V263= (MVloc[(0)]);
	V266= (MVloc[(1)]);
	V267= (MVloc[(2)]);
	V268= (MVloc[(3)]);
	V269= (MVloc[(4)]);}
	(void)((*(LnkLI185))());
	base[2]= make_fixnum((fix((V265)))+(fix((V263))));
	base[3]= Ct;
	base[4]= symbol_value(VV[9]);
	base[5]= (V266);
	base[6]= (V267);
	base[7]= (V268);
	base[8]= (V269);
	vs_top=(vs_base=base+2)+7;
	(void) (*Lnk186)();
	return;
T975:;
	V263= make_fixnum((fix((V265)))+(fix((V263))));{object V271;
	base[2]= (V263);
	base[3]= small_fixnum(0);
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk121)();
	vs_top=sup;
	V271= vs_base[0];
	if(V271==Cnil)goto T1003;
	goto T1002;
T1003:;}
	V263= small_fixnum(0);
T1002:;
	V264= symbol_value(VV[84]);
	goto TTL;}
	}
}
/*	function definition for NEXT-STACK-FRAME	*/

static L44()
{register object *base=vs_base;
	register object *sup=base+VM42; VC42
	vs_reserve(VM42);
	{object V272;
	check_arg(1);
	V272=(base[0]);
	vs_top=sup;
TTL:;
	{register object V273;
	register object V274;
	register object V275;
	register object V276;
	object V277;
	V273= Cnil;
	V274= Cnil;
	V275= Cnil;
	V276= Cnil;
	V277= Cnil;
	if(!((fix((V272)))<(fix(symbol_value(VV[82]))))){
	goto T1017;}
	(void)((MVloc[(0)]=(Cnil)));
	(void)((MVloc[(1)]=(Cnil)));
	(void)((MVloc[(2)]=(Cnil)));
	(void)((MVloc[(3)]=(Cnil)));
	base[1]= Cnil;
	vs_top=(vs_base=base+1)+1;
	return;
T1017:;
	{object V279;
	V279= Cnil;
	{object V280;
	base[1]= (V272);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk182)();
	vs_top=sup;
	V279= vs_base[0];
	V280= (V279);
	V275= (MVloc[(0)]);}
	V277= (V279);
	{object V281;
	V273= get((V279),VV[48],Cnil);
	if(((V273))!=Cnil){
	goto T1032;}
	V281= Cnil;
	goto T1031;
T1032:;
	{register object V282;
	register object V283;
	V282= make_fixnum((fix((V272)))+(1));
	V283= Cnil;
T1037:;
	if(!(number_compare((V282),(V275))<=0)){
	goto T1038;}
	V281= Cnil;
	goto T1031;
T1038:;
	base[1]= (V282);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk115)();
	vs_top=sup;
	V283= vs_base[0];
	base[2]= (V282);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk115)();
	vs_top=sup;
	base[1]= vs_base[0];
	base[2]= (V273);
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk187)();
	vs_top=sup;
	V274= vs_base[0];
	if(((V274))==Cnil){
	goto T1045;}
	{register object V284;
	V284= (V275);
	(void)((MVloc[(0)]=((V279))));
	(void)((MVloc[(1)]=((V274))));
	V285= aref1((V273),0);
	(void)((MVloc[(2)]=(car(/* INLINE-ARGS */V285))));
	base[2]= (V282);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk110)();
	vs_top=sup;
	V276= vs_base[0];
	base[1]= (V276);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk111)();
	vs_top=sup;
	V286= vs_base[0];
	base[1]= one_plus((V276));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk111)();
	vs_top=sup;
	V287= vs_base[0];
	base[1]= number_plus((V276),small_fixnum(2));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk111)();
	vs_top=sup;
	V288= vs_base[0];
	V289= list(3,V286,V287,V288);
	(void)((MVloc[(3)]=(/* INLINE-ARGS */V289)));
	base[1]= (V284);
	vs_top=(vs_base=base+1)+1;
	return;}
T1045:;
	V282= make_fixnum((fix((V282)))-(1));
	goto T1037;}
T1031:;
	if(((V281))==Cnil){
	goto T1068;}
	base[1]= (V281);
	vs_top=(vs_base=base+1)+1;
	return;
T1068:;
	base[1]= (V277);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk180)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T1071;}
	base[1]= Cnil;
	vs_top=(vs_base=base+1)+1;
	return;
T1071:;
	{object V290;
	V290= get((V277),VV[83],Cnil);
	if(((V290))==Cnil){
	goto T1076;}
	base[1]= (V290);
	vs_top=(vs_base=base+1)+1;
	return;
T1076:;
	base[1]= (V277);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk181)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T1079;}
	(void)((MVloc[(0)]=((V277))));
	(void)((MVloc[(1)]=(Cnil)));
	(void)((MVloc[(2)]=(Cnil)));
	base[1]= (V275);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk188)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T1088;}
	V292= Cnil;
	goto T1086;
T1088:;
	{object V293;
	base[1]= (V275);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk110)();
	vs_top=sup;
	V293= vs_base[0];
	base[1]= (V293);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk111)();
	vs_top=sup;
	V294= vs_base[0];
	base[1]= one_plus((V293));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk111)();
	vs_top=sup;
	V295= vs_base[0];
	base[1]= make_fixnum((fix((V293)))+(2));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk111)();
	vs_top=sup;
	V296= vs_base[0];
	V292= list(3,V294,V295,V296);}
T1086:;
	(void)((MVloc[(3)]=(V292)));
	base[1]= V275;
	vs_top=(vs_base=base+1)+1;
	return;
T1079:;
	base[1]= Cnil;
	vs_top=(vs_base=base+1)+1;
	return;}}}}
	}
}
/*	function definition for NTH-STACK-FRAME	*/

static L45()
{register object *base=vs_base;
	register object *sup=base+VM43; VC43
	vs_reserve(VM43);
	{register object V297;
	register object V298;
	if(vs_top-vs_base<1) too_few_arguments();
	if(vs_top-vs_base>2) too_many_arguments();
	V297=(base[0]);
	vs_base=vs_base+1;
	if(vs_base>=vs_top){vs_top=sup;goto T1099;}
	V298=(base[1]);
	vs_top=sup;
	goto T1100;
T1099:;
	V298= symbol_value(VV[84]);
T1100:;
	{register object V299;
	object V300;
	object V301;
	object V302;
	register object V303;
	V299= Cnil;
	V300= Cnil;
	V301= Cnil;
	V302= Cnil;
	V303= Cnil;{object V304;
	base[2]= (V297);
	base[3]= small_fixnum(0);
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk121)();
	vs_top=sup;
	V304= vs_base[0];
	if(V304==Cnil)goto T1108;
	goto T1107;
T1108:;}
	V297= small_fixnum(0);
T1107:;
	{object V305;
	register object V306;
	V305= make_fixnum((fix((V297)))+(1));
	V306= small_fixnum(0);
T1117:;
	if(!(number_compare((V306),(V305))>=0)){
	goto T1118;}
	goto T1113;
T1118:;
	base[3]= (V298);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk189)();
	vs_top=sup;
	V303= vs_base[0];
	if(((V303))==Cnil){
	goto T1127;}
	{register object V307;
	V298= (V303);
	V307= (V298);
	V299= (MVloc[(0)]);
	V300= (MVloc[(1)]);
	V301= (MVloc[(2)]);
	V302= (MVloc[(3)]);}
	V298= make_fixnum((fix((V303)))-(1));
	goto T1125;
T1127:;
	V297= make_fixnum((fix((V306)))-(1));
	goto T1113;
T1125:;
	V306= one_plus((V306));
	goto T1117;}
T1113:;
	V298= make_fixnum((fix((V298)))+(1));
	base[2]= (V298);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk157)();
	vs_top=sup;
	V299= vs_base[0];
	(void)((MVloc[(0)]=((V297))));
	(void)((MVloc[(1)]=((V299))));
	(void)((MVloc[(2)]=((V300))));
	(void)((MVloc[(3)]=((V301))));
	(void)((MVloc[(4)]=((V302))));
	base[2]= V298;
	vs_top=(vs_base=base+2)+1;
	return;}
	}
}
/*	function definition for DBL-BACKTRACE	*/

static L46()
{register object *base=vs_base;
	register object *sup=base+VM44; VC44
	vs_reserve(VM44);
	{object V309;
	register object V310;
	if(vs_top-vs_base>2) too_many_arguments();
	if(vs_base>=vs_top){vs_top=sup;goto T1155;}
	V309=(base[0]);
	vs_base++;
	if(vs_base>=vs_top){vs_top=sup;goto T1156;}
	V310=(base[1]);
	vs_top=sup;
	goto T1157;
T1155:;
	V309= small_fixnum(1000);
T1156:;
	V310= symbol_value(VV[84]);
T1157:;
	{register object V311;
	register object V312;
	register object V313;
	register object V314;
	register object V315;
	V311= Cnil;
	V312= Cnil;
	V313= Cnil;
	V314= Cnil;
	V315= small_fixnum(0);
T1167:;
	{object V316;
	base[2]= (V310);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk189)();
	vs_top=sup;
	V310= vs_base[0];
	V316= (V310);
	V311= (MVloc[(0)]);
	V313= (MVloc[(1)]);
	V312= (MVloc[(2)]);
	V314= (MVloc[(3)]);}
	if((V311)!=Cnil){
	goto T1181;}
	goto T1165;
T1181:;
	base[2]= (V315);
	base[3]= Cnil;
	base[4]= (V310);
	base[5]= (V311);
	base[6]= (V313);
	base[7]= (V312);
	base[8]= (V314);
	vs_top=(vs_base=base+2)+7;
	(void) (*Lnk186)();
	vs_top=sup;
	V315= number_plus((V315),small_fixnum(1));
	if(!((fix((V315)))>=(fix((V309))))){
	goto T1192;}
	vs_base=vs_top=base+2;
	vs_base[0]=Cnil;
	vs_top=sup;
	goto T1165;
T1192:;
	V310= make_fixnum((fix((V310)))-(1));
	goto T1167;
T1165:;
	vs_base=vs_top=base+2;
	vs_base[0]=Cnil;
	return;}
	}
}
/*	function definition for DISPLAY-COMPILED-ENV	*/

static L47()
{register object *base=vs_base;
	register object *sup=base+VM45; VC45
	vs_reserve(VM45);
	{register object V317;
	object V318;
	check_arg(2);
	V317=(base[0]);
	V318=(base[1]);
	vs_top=sup;
TTL:;
	{register object V319;
	register object V320;
	base[4]= (V318);
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk110)();
	vs_top=sup;
	V319= vs_base[0];
	base[4]= one_plus((V318));
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk110)();
	vs_top=sup;
	V321= vs_base[0];
	vs_base=vs_top;
	(void) (*Lnk190)();
	vs_top=sup;
	V322= vs_base[0];
	V320= (number_compare(V321,V322)<=0?(V321):V322);
	base[4]= symbol_value(VV[74]);
	base[5]= VV[85];
	vs_top=(vs_base=base+4)+2;
	(void) (*Lnk107)();
	vs_top=sup;
	{register object V323;
	register object V324;
	base[4]= (V318);
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk157)();
	vs_top=sup;
	V325= vs_base[0];
	V324= get(V325,VV[14],Cnil);
	V323= (V319);
T1210:;
	if((fix((V323)))>=(fix((V320)))){
	goto T1212;}
	base[4]= symbol_value(VV[74]);
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk177)();
	vs_top=sup;
	V326= vs_base[0];
	if(!((fix(V326))>(fix((V317))))){
	goto T1211;}
T1212:;
	base[4]= Cnil;
	vs_top=(vs_base=base+4)+1;
	return;
T1211:;
	base[4]= symbol_value(VV[74]);
	base[5]= VV[86];{object V327;
	V327= car((V324));
	if(V327==Cnil)goto T1223;
	base[6]= V327;
	goto T1222;
T1223:;}
	base[6]= VV[87];
T1222:;
	if((car((V324)))!=Cnil){
	goto T1227;}
	base[7]= make_fixnum((fix((V323)))-(fix((V319))));
	goto T1225;
T1227:;
	base[7]= Cnil;
T1225:;
	base[9]= (V323);
	vs_top=(vs_base=base+9)+1;
	(void) (*Lnk111)();
	vs_top=sup;
	base[8]= vs_base[0];
	V323= make_fixnum((fix((V323)))+(1));
	base[10]= (V323);
	base[11]= (V320);
	vs_top=(vs_base=base+10)+2;
	(void) (*Lnk123)();
	vs_top=sup;
	base[9]= vs_base[0];
	vs_top=(vs_base=base+4)+6;
	(void) (*Lnk107)();
	vs_top=sup;
	V324= cdr((V324));
	goto T1210;}}
	}
}
/*	function definition for COMPUTING-ARGS-P	*/

static L48()
{register object *base=vs_base;
	register object *sup=base+VM46; VC46
	vs_reserve(VM46);
	{object V328;
	check_arg(1);
	V328=(base[0]);
	vs_top=sup;
TTL:;
	base[2]= (V328);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk115)();
	vs_top=sup;
	base[1]= vs_base[0];
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk178)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T1238;}
	base[1]= Cnil;
	vs_top=(vs_base=base+1)+1;
	return;
T1238:;
	base[1]= (V328);
	base[2]= small_fixnum(3);
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk108)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T1242;}
	base[1]= Cnil;
	vs_top=(vs_base=base+1)+1;
	return;
T1242:;
	base[2]= (V328);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk115)();
	vs_top=sup;
	V330= vs_base[0];
	{register object x= car(V330),V329= VV[88];
	while(!endp(V329))
	if(eql(x,V329->c.c_car)){
	base[1]= V329;
	goto T1246;
	}else V329=V329->c.c_cdr;
	base[1]= Cnil;}
T1246:;
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk191)();
	return;
	}
}
/*	function definition for PRINT-STACK-FRAME	*/

static L49()
{register object *base=vs_base;
	register object *sup=base+VM47; VC47
	vs_reserve(VM47);
	{object V331;
	object V332;
	register object V333;
	object V334;
	object V335;
	object V336;
	object V337;
	if(vs_top-vs_base<4) too_few_arguments();
	if(vs_top-vs_base>7) too_many_arguments();
	V331=(base[0]);
	V332=(base[1]);
	V333=(base[2]);
	V334=(base[3]);
	vs_base=vs_base+4;
	if(vs_base>=vs_top){vs_top=sup;goto T1249;}
	V335=(base[4]);
	vs_base++;
	if(vs_base>=vs_top){vs_top=sup;goto T1250;}
	V336=(base[5]);
	vs_base++;
	if(vs_base>=vs_top){vs_top=sup;goto T1251;}
	V337=(base[6]);
	vs_top=sup;
	goto T1252;
T1249:;
	V335= Cnil;
T1250:;
	V336= Cnil;
T1251:;
	V337= Cnil;
T1252:;
	if(((V332))==Cnil){
	goto T1256;}
	if(((V335))==Cnil){
	goto T1256;}
	base[7]= symbol_value(VV[1]);
	base[8]= VV[89];
	base[9]= (V336);
	base[10]= (V335);
	vs_top=(vs_base=base+7)+4;
	(void) (*Lnk107)();
	vs_top=sup;
T1256:;
	{object V338;
	base[7]= (V333);
	vs_top=(vs_base=base+7)+1;
	(void) (*Lnk192)();
	vs_top=sup;
	V338= vs_base[0];
	base[7]= symbol_value(VV[1]);
	base[8]= VV[90];
	base[9]= (V331);
	if((V338)==Cnil){
	base[10]= Cnil;
	goto T1271;}
	base[10]= VV[91];
T1271:;
	base[11]= (V334);
	base[13]= (V333);
	vs_top=(vs_base=base+13)+1;
	(void) (*Lnk188)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T1275;}
	base[13]= VV[92];
	base[14]= small_fixnum(80);
	base[17]= (V333);
	vs_top=(vs_base=base+17)+1;
	(void) (*Lnk110)();
	vs_top=sup;
	base[16]= vs_base[0];
	vs_top=(vs_base=base+16)+1;
	(void) (*Lnk111)();
	vs_top=sup;
	V339= vs_base[0];
	base[15]= car(V339);
	vs_top=(vs_base=base+13)+3;
	(void) (*Lnk193)();
	vs_top=sup;
	base[12]= vs_base[0];
	goto T1273;
T1275:;
	base[13]= VV[93];
	base[14]= small_fixnum(80);
	base[15]= (V333);
	vs_top=(vs_base=base+13)+3;
	(void) (*Lnk193)();
	vs_top=sup;
	base[12]= vs_base[0];
T1273:;
	vs_top=(vs_base=base+7)+6;
	(void) (*Lnk107)();
	vs_top=sup;
	if(((V336))==Cnil){
	goto T1287;}
	base[7]= symbol_value(VV[1]);
	base[8]= VV[94];
	base[9]= (V336);
	base[10]= (V335);
	vs_top=(vs_base=base+7)+4;
	(void) (*Lnk107)();
	vs_top=sup;
T1287:;
	base[7]= symbol_value(VV[1]);
	base[8]= VV[95];
	base[9]= (V333);
	vs_top=(vs_base=base+7)+3;
	(void) (*Lnk107)();
	return;}
	}
}
/*	function definition for MAKE-BREAK-POINT	*/

static L50()
{register object *base=vs_base;
	register object *sup=base+VM48; VC48
	vs_reserve(VM48);
	{object V340;
	object V341;
	object V342;
	check_arg(3);
	V340=(base[0]);
	V341=(base[1]);
	V342=(base[2]);
	vs_top=sup;
TTL:;
	V343= aref1((V341),fixint((V342)));
	V344= aref1((V341),0);
	V345= car(/* INLINE-ARGS */V344);
	V346= aref1((V341),0);
	V347 = make_fixnum((fix(cdr(/* INLINE-ARGS */V346)))+(fix((V342))));
	base[3]= list(4,/* INLINE-ARGS */V343,/* INLINE-ARGS */V345,V347,(V340));
	vs_top=(vs_base=base+3)+1;
	return;
	}
}
/*	function definition for RELATIVE-LINE	*/

static L51()
{register object *base=vs_base;
	register object *sup=base+VM49; VC49
	vs_reserve(VM49);
	{object V348;
	object V349;
	check_arg(2);
	V348=(base[0]);
	V349=(base[1]);
	vs_top=sup;
TTL:;
	{object V350;
	V350= get((V348),VV[48],Cnil);
	if(((V350))==Cnil){
	goto T1299;}
	V351= aref1((V350),0);
	base[2]= make_fixnum((fix((V349)))-(fix(cdr(/* INLINE-ARGS */V351))));
	vs_top=(vs_base=base+2)+1;
	return;
T1299:;
	base[2]= small_fixnum(0);
	vs_top=(vs_base=base+2)+1;
	return;}
	}
}
/*	function definition for SAFE-EVAL	*/

static L52()
{register object *base=vs_base;
	register object *sup=base+VM50; VC50
	vs_reserve(VM50);
	bds_check;
	{register object V352;
	object V353;
	check_arg(2);
	V352=(base[0]);
	V353=(base[1]);
	vs_top=sup;
TTL:;
	bds_bind(VV[96],Cnil);
	bds_bind(VV[97],symbol_value(VV[98]));
	bds_bind(VV[1],symbol_value(VV[98]));
	if(!(type_of((V352))==t_symbol)){
	goto T1301;}
	base[5]= (V352);
	vs_top=(vs_base=base+5)+1;
	(void) (*Lnk194)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T1301;}
	{register object x= (V352),V354= car((V353));
	while(!endp(V354))
	if(type_of(V354->c.c_car)==t_cons &&eql(x,V354->c.c_car->c.c_car)){
	goto T1301;
	}else V354=V354->c.c_cdr;}
	base[5]= VV[99];
	vs_top=(vs_base=base+5)+1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	return;
T1301:;
	{object V355;
	object V356;
	V357= list(2,VV[101],(V352));
	base[5]= list(5,VV[100],/* INLINE-ARGS */V357,Cnil,Cnil,list(2,VV[101],(V353)));
	vs_top=(vs_base=base+5)+1;
	(void) (*Lnk195)();
	if(vs_base>=vs_top){vs_top=sup;goto T1311;}
	V355= vs_base[0];
	vs_base++;
	if(vs_base>=vs_top){vs_top=sup;goto T1312;}
	V356= vs_base[0];
	vs_top=sup;
	goto T1313;
T1311:;
	V355= Cnil;
T1312:;
	V356= Cnil;
T1313:;
	if(((V355))==Cnil){
	goto T1315;}
	base[5]= VV[99];
	vs_top=(vs_base=base+5)+1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	return;
T1315:;
	base[5]= (V356);
	vs_top=(vs_base=base+5)+1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	return;}
	}
}
/*	function definition for SET-BACK	*/

static L53()
{register object *base=vs_base;
	register object *sup=base+VM51; VC51
	vs_reserve(VM51);
	{register object V358;
	register object V359;
	check_arg(2);
	V358=(base[0]);
	V359=(base[1]);
	vs_top=sup;
TTL:;
	{object V360;
	V360= symbol_value(VV[9]);
	setq(VV[102],Cnil);
	setq(VV[9],(V360));
	if(((V359))==Cnil){
	goto T1324;}
	setq(VV[0],(V359));
	goto T1322;
T1324:;
	base[3]= (V360);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk110)();
	vs_top=sup;
	base[2]= vs_base[0];
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk111)();
	vs_top=sup;
	V361= vs_base[0];
	(void)(make_cons(V361,Cnil));
T1322:;
	if(((V358))==Cnil){
	goto T1330;}
	base[2]= symbol_value(VV[1]);
	base[3]= VV[103];
	base[4]= cadr((V358));
	base[5]= caddr((V358));
	vs_top=(vs_base=base+2)+4;
	(void) (*Lnk107)();
	vs_top=sup;
	base[2]= symbol_value(VV[1]);
	base[3]= VV[104];
	base[4]= cadr((V358));
	base[5]= caddr((V358));
	vs_top=(vs_base=base+2)+4;
	(void) (*Lnk107)();
	vs_top=sup;
T1330:;
	{register object V362;
	register object V363;
	V362= symbol_value(VV[105]);
	V363= car((V362));
T1345:;
	if(!(endp((V362)))){
	goto T1346;}
	base[3]= Cnil;
	vs_top=(vs_base=base+3)+1;
	return;
T1346:;
	{register object V364;
	base[3]= (V363);
	base[4]= (V359);
	vs_top=(vs_base=base+3)+2;
	(void) (*Lnk196)();
	vs_top=sup;
	V364= vs_base[0];{object V365;
	base[3]= (V364);
	base[4]= VV[99];
	vs_top=(vs_base=base+3)+2;
	(void) (*Lnk197)();
	vs_top=sup;
	V365= vs_base[0];
	if(V365==Cnil)goto T1354;
	goto T1350;
T1354:;}
	base[3]= Ct;
	base[4]= VV[106];
	base[5]= (V363);
	base[6]= (V364);
	vs_top=(vs_base=base+3)+4;
	(void) (*Lnk107)();
	vs_top=sup;}
T1350:;
	V362= cdr((V362));
	V363= car((V362));
	goto T1345;}}
	}
}
static LnkT197(){ call_or_link(VV[197],&Lnk197);} /* EQ */
static LnkT196(){ call_or_link(VV[196],&Lnk196);} /* SAFE-EVAL */
static LnkT195(){ call_or_link(VV[195],&Lnk195);} /* ERROR-SET */
static LnkT194(){ call_or_link(VV[194],&Lnk194);} /* BOUNDP */
static LnkT193(){ call_or_link(VV[193],&Lnk193);} /* APPLY-DISPLAY-FUN */
static LnkT192(){ call_or_link(VV[192],&Lnk192);} /* COMPUTING-ARGS-P */
static LnkT191(){ call_or_link(VV[191],&Lnk191);} /* NOT */
static LnkT190(){ call_or_link(VV[190],&Lnk190);} /* VS-TOP */
static LnkT189(){ call_or_link(VV[189],&Lnk189);} /* NEXT-STACK-FRAME */
static LnkT188(){ call_or_link(VV[188],&Lnk188);} /* IHS-NOT-INTERPRETED-ENV */
static LnkT187(){ call_or_link(VV[187],&Lnk187);} /* GET-LINE-OF-FORM */
static LnkT186(){ call_or_link(VV[186],&Lnk186);} /* PRINT-STACK-FRAME */
static object  LnkTLI185(){return call_proc0(VV[185],&LnkLI185);} /* SET-ENV */
static LnkT184(){ call_or_link(VV[184],&Lnk184);} /* NTH-STACK-FRAME */
static LnkT183(){ call_or_link(VV[183],&Lnk183);} /* DBL-WHAT-FRAME */
static LnkT182(){ call_or_link(VV[182],&Lnk182);} /* GET-NEXT-VISIBLE-FUN */
static LnkT181(){ call_or_link(VV[181],&Lnk181);} /* FBOUNDP */
static LnkT180(){ call_or_link(VV[180],&Lnk180);} /* SPECIAL-FORM-P */
static LnkT179(){ call_or_link(VV[179],&Lnk179);} /* LISTP */
static LnkT178(){ call_or_link(VV[178],&Lnk178);} /* CONSP */
static LnkT177(){ call_or_link(VV[177],&Lnk177);} /* FILL-POINTER */
static LnkT173(){ call_or_link(VV[173],&Lnk173);} /* RELATIVE-LINE */
static LnkT172(){ call_or_link(VV[172],&Lnk172);} /* SHORT-NAME */
static LnkT171(){ call_or_link(VV[171],&Lnk171);} /* SUBSEQ */
static LnkT170(){ call_or_link(VV[170],&Lnk170);} /* SHOW-BREAK-POINT */
static LnkT169(){ call_or_link(VV[169],&Lnk169);} /* INSERT-BREAK-POINT */
static LnkT168(){ call_or_link(VV[168],&Lnk168);} /* SYMBOL-FUNCTION */
static LnkT167(){ call_or_link(VV[167],&Lnk167);} /* ARRAYP */
static LnkT166(){ call_or_link(VV[166],&Lnk166);} /* BREAK-FUNCTION */
static LnkT165(){ call_or_link(VV[165],&Lnk165);} /* DWIM */
static LnkT164(){ call_or_link(VV[164],&Lnk164);} /* UNINTERN */
static LnkT163(){ call_or_link(VV[163],&Lnk163);} /* INTERN */
static LnkT162(){ call_or_link(VV[162],&Lnk162);} /* LIST-ALL-PACKAGES */
static LnkT161(){ call_or_link(VV[161],&Lnk161);} /* MAYBE-BREAK */
static object  LnkTLI160(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[160],&LnkLI160,ap);} /* POSITION */
static LnkT159(){ call_or_link(VV[159],&Lnk159);} /* CURRENT-STEP-FUN */
static LnkT158(){ call_or_link(VV[158],&Lnk158);} /* INIT-BREAK-POINTS */
static LnkT157(){ call_or_link(VV[157],&Lnk157);} /* IHS-FNAME */
static LnkT156(){ call_or_link(VV[156],&Lnk156);} /* STREAM-NAME */
static LnkT155(){ call_or_link(VV[155],&Lnk155);} /* ITERATE-OVER-BKPTS */
static LnkT154(){ call_or_link(VV[154],&Lnk154);} /* MAKE-BREAK-POINT */
static object  LnkTLI153(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[153],&LnkLI153,ap);} /* MAKE-ARRAY */
static LnkT152(){ call_or_link(VV[152],&Lnk152);} /* FILL-POINTER-SET */
static LnkT151(){ call_or_link(VV[151],&Lnk151);} /* WALK-THROUGH */
static object  LnkTLI150(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[150],&LnkLI150,ap);} /* VECTOR-PUSH-EXTEND */
static LnkT149(){ call_or_link(VV[149],&Lnk149);} /* REMHASH */
static LnkT148(){ call_or_link(VV[148],&Lnk148);} /* GETHASH */
static LnkT147(){ call_or_link(VV[147],&Lnk147);} /* HASH-SET */
static LnkT146(){ call_or_link(VV[146],&Lnk146);} /* INSTREAM-NAME */
static LnkT145(){ call_or_link(VV[145],&Lnk145);} /* LOAD */
static LnkT144(){ call_or_link(VV[144],&Lnk144);} /* SETUP-LINEINFO */
static LnkT143(){ call_or_link(VV[143],&Lnk143);} /* TRUENAME */
static LnkT142(){ call_or_link(VV[142],&Lnk142);} /* CLEANUP */
static LnkT141(){ call_or_link(VV[141],&Lnk141);} /* CLRHASH */
static LnkT139(){ call_or_link(VV[139],&Lnk139);} /* SET-MACRO-CHARACTER */
static LnkT137(){ call_or_link(VV[137],&Lnk137);} /* READ-FROM-STRING */
static LnkT136(){ call_or_link(VV[136],&Lnk136);} /* READ-LINE */
static LnkT135(){ call_or_link(VV[135],&Lnk135);} /* READ-CHAR */
static object  LnkTLI134(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[134],&LnkLI134,ap);} /* COUNT */
static LnkT133(){ call_or_link(VV[133],&Lnk133);} /* PEEK-CHAR */
static LnkT132(){ call_or_link(VV[132],&Lnk132);} /* GET-INSTREAM */
static LnkT131(){ call_or_link(VV[131],&Lnk131);} /* MAKE-INSTREAM */
static object  LnkTLI130(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[130],&LnkLI130,ap);} /* DELETE */
static LnkT129(){ call_or_link(VV[129],&Lnk129);} /* CLOSEDP */
static LnkT128(){ call_or_link(VV[128],&Lnk128);} /* MAKE-STRUCTURE */
static LnkT126(){ call_or_link(VV[126],&Lnk126);} /* BREAK-LEVEL */
static LnkT125(){ call_or_link(VV[125],&Lnk125);} /* ERROR */
static object  LnkTLI124(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[124],&LnkLI124,1,ap);} /* SHOW-ENVIRONMENT */
static LnkT123(){ call_or_link(VV[123],&Lnk123);} /* < */
static LnkT122(){ call_or_link(VV[122],&Lnk122);} /* GETF */
static LnkT121(){ call_or_link(VV[121],&Lnk121);} /* >= */
static LnkT120(){ call_or_link(VV[120],&Lnk120);} /* BREAK-LOCALS */
static LnkT119(){ call_or_link(VV[119],&Lnk119);} /* BREAK-GO */
static object  LnkTLI118(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[118],&LnkLI118,ap);} /* SEARCH */
static LnkT117(){ call_or_link(VV[117],&Lnk117);} /* COMPILED-FUNCTION-NAME */
static LnkT116(){ call_or_link(VV[116],&Lnk116);} /* COMPILED-FUNCTION-P */
static LnkT115(){ call_or_link(VV[115],&Lnk115);} /* IHS-FUN */
static LnkT114(){ call_or_link(VV[114],&Lnk114);} /* <= */
static object  LnkTLI113(){return call_proc0(VV[113],&LnkLI113);} /* TYPE-ERROR */
static LnkT112(){ call_or_link(VV[112],&Lnk112);} /* IHS-TOP */
static LnkT111(){ call_or_link(VV[111],&Lnk111);} /* VS */
static LnkT110(){ call_or_link(VV[110],&Lnk110);} /* IHS-VS */
static LnkT109(){ call_or_link(VV[109],&Lnk109);} /* BREAK-PREVIOUS */
static LnkT108(){ call_or_link(VV[108],&Lnk108);} /* > */
static LnkT107(){ call_or_link(VV[107],&Lnk107);} /* FORMAT */
