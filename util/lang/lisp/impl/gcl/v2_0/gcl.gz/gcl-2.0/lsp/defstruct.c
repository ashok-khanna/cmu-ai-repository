
#include <cmpinclude.h>
#include "defstruct.h"
init_defstruct(){do_init(VV);}
/*	local entry for function MAKE-ACCESS-FUNCTION	*/

static object LI1(V11,V10,V9,V8,V7,V6,V5,V4,V3,V2,V1,va_alist)
	object V11,V10,V9,V8,V7,V6,V5,V4,V3,V2,V1;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB1 VMS1 VMV1
	{object V12;
	object V13;
	object V14;
	object V15;
	object V16;
	object V17;
	object V18;
	object V19;
	object V20;
	object V21;
	object V22;
	if(narg <11) too_few_arguments();
	V12= V11;
	V13= V10;
	V14= V9;
	V15= V8;
	V16= V7;
	V17= V6;
	V18= V5;
	V19= V4;
	V20= V3;
	V21= V2;
	Vcs[10]=MMcons(V1,Cnil);
	narg = narg - 11;
	if (narg <= 0) goto T1;
	else {
	va_start(ap);
	V22= va_arg(ap,object);}
	--narg; goto T2;
T1:;
	V22= Cnil;
T2:;
	{register object V23;
	register object V24;
	object V25;
	base[1]= coerce_to_string((V13));
	base[2]= coerce_to_string((V18));
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk106)();
	vs_top=sup;
	base[0]= vs_base[0];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk107)();
	vs_top=sup;
	V23= vs_base[0];
	V24= Cnil;
	V25= Cnil;
	{object V26= (V14);
	if((V26!= Cnil))goto T9;
	V24= symbol_value(VV[0]);
	goto T8;
T9:;
	if((V26!= VV[20]))goto T11;
	V24= symbol_value(VV[1]);
	goto T8;
T11:;
	if((V26!= VV[19]))goto T13;
	V24= symbol_value(VV[2]);
	goto T8;
T13:;
	FEerror("The ECASE key value ~s is illegal.",1,V26);}
T8:;{object V27;
	base[0]= make_fixnum(length((V24)));
	base[1]= (Vcs[10]->c.c_car);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk27)();
	vs_top=sup;
	V27= vs_base[0];
	if(V27==Cnil)goto T16;
	goto T15;
T16:;}
	V28= number_plus((Vcs[10]->c.c_car),small_fixnum(10));
	(void)((VFUN_NARGS=2,(*(LnkLI108))((V24),/* INLINE-ARGS */V28)));
T15:;
	if(((V25))!=Cnil){
	goto T20;}
	base[0]= (V23);
	base[1]= VV[3];
	base[2]= VV[4];
	base[3]= (V20);
	vs_top=(vs_base=base+0)+4;
	(void) (*Lnk109)();
	vs_top=sup;
	if((V17)!=Cnil){
	goto T20;}{object V29;
	base[0]= (V23);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk110)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T30;}
	V29= Cnil;
	goto T29;
T30:;
	base[0]= aref1((V24),fixint((Vcs[10]->c.c_car)));
	base[2]= (V23);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk111)();
	vs_top=sup;
	base[1]= vs_base[0];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk29)();
	vs_top=sup;
	V29= vs_base[0];
T29:;
	if(V29==Cnil)goto T28;
	goto T20;
T28:;}
	base[0]= (V23);{object V30;
	V30= aref1((V24),fixint((Vcs[10]->c.c_car)));
	if(V30==Cnil)goto T38;
	base[1]= V30;
	goto T37;
T38:;}
	if(!(((V24))==(symbol_value(VV[0])))){
	goto T42;}
	V31= 
	make_cclosure_new(LC16,Cnil,Vcs[10],Cdata);
	goto T40;
T42:;
	if(!(((V24))==(symbol_value(VV[1])))){
	goto T45;}
	V31= 
	make_cclosure_new(LC17,Cnil,Vcs[10],Cdata);
	goto T40;
T45:;
	if(!(((V24))==(symbol_value(VV[2])))){
	goto T48;}
	V31= 
	make_cclosure_new(LC18,Cnil,Vcs[10],Cdata);
	goto T40;
T48:;
	V31= Cnil;
T40:;
	base[1]= aset1((V24),fixint((Vcs[10]->c.c_car)),V31);
T37:;
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk112)();
	vs_top=sup;
T20:;
	if(((V21))==Cnil){
	goto T52;}
	(void)(remprop((V23),VV[6]));
	(void)(sputprop((V23),VV[7],Ct));
	goto T50;
T52:;
	(void)(remprop((V23),VV[8]));
	(void)(remprop((V23),VV[9]));
	(void)(remprop((V23),VV[10]));
	{object V32;
	V32= get((V23),VV[6],Cnil);
	if(!(type_of((V32))==t_cons)){
	goto T60;}
	if(((V16))==Cnil){
	goto T60;}
	base[0]= (V16);
	base[1]= car((V32));
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk113)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T60;}
	if(!(eql(cdr((V32)),(Vcs[10]->c.c_car)))){
	goto T60;}
	V25= Ct;
	goto T50;
T60:;
	if(((V14))==Cnil){
	goto T73;}
	V33= (V14);
	goto T71;
T73:;
	V33= (V12);
T71:;
	V34= make_cons(V33,(Vcs[10]->c.c_car));
	(void)(sputprop((V23),VV[6],/* INLINE-ARGS */V34));}
T50:;
	{object V35 = Cnil;
	VMR1(V35)}}}
	}
/*	local entry for function MAKE-CONSTRUCTOR	*/

static object LI2(V41,V42,V43,V44,V45)

object V41;object V42;object V43;object V44;object V45;
{	 VMB2 VMS2 VMV2
TTL:;
	{object V46;
	register object V47;
	{object V48;
	object V49= (V45);
	if(endp(V49)){
	V46= Cnil;
	goto T75;}
	base[0]=V48=MMcons(Cnil,Cnil);
T76:;
	if(((V49->c.c_car))!=Cnil){
	goto T79;}
	(V48->c.c_car)= Cnil;
	goto T77;
T79:;
	if((car((V49->c.c_car)))!=Cnil){
	goto T82;}
	(V48->c.c_car)= list(2,VV[11],cadr((V49->c.c_car)));
	goto T77;
T82:;
	(V48->c.c_car)= car((V49->c.c_car));
T77:;
	if(endp(V49=MMcdr(V49))){
	V46= base[0];
	goto T75;}
	V48=MMcdr(V48)=MMcons(Cnil,Cnil);
	goto T76;}
T75:;
	{object V51;
	object V52= (V45);
	if(endp(V52)){
	V47= Cnil;
	goto T84;}
	base[0]=V51=MMcons(Cnil,Cnil);
T85:;
	if(((V52->c.c_car))!=Cnil){
	goto T88;}
	(V51->c.c_cdr)= Cnil;
	goto T86;
T88:;
	if((car((V52->c.c_car)))!=Cnil){
	goto T91;}
	(V51->c.c_cdr)= Cnil;
	goto T86;
T91:;
	if((cadr((V52->c.c_car)))!=Cnil){
	goto T94;}
	(V51->c.c_cdr)= make_cons(car((V52->c.c_car)),Cnil);
	goto T86;
T94:;
	V54= list(2,car((V52->c.c_car)),cadr((V52->c.c_car)));
	(V51->c.c_cdr)= make_cons(/* INLINE-ARGS */V54,Cnil);
T86:;
	while(!endp(MMcdr(V51)))V51=MMcdr(V51);
	if(endp(V52=MMcdr(V52))){
	base[0]=base[0]->c.c_cdr;
	V47= base[0];
	goto T84;}
	goto T85;}
T84:;
	if(!(type_of((V42))==t_cons)){
	goto T98;}
	{register object V55;
	register object V56;
	register object V57;
	V55= cadr((V42));
	V56= Cnil;
	V57= Cnil;
T103:;
	if(!(endp((V55)))){
	goto T104;}
	base[0]= make_cons(VV[12],(V56));
	{object V58;
	object V59= (V47);
	if(endp(V59)){
	base[1]= Cnil;
	goto T109;}
	base[2]=V58=MMcons(Cnil,Cnil);
T110:;
	if(!(type_of((V59->c.c_car))!=t_cons)){
	goto T117;}
	V62= (V59->c.c_car);
	goto T115;
T117:;
	V62= car((V59->c.c_car));
T115:;
	{register object x= V62,V61= (V57);
	while(!endp(V61))
	if(eql(x,V61->c.c_car)){
	goto T114;
	}else V61=V61->c.c_cdr;
	goto T113;}
T114:;
	(V58->c.c_cdr)= Cnil;
	goto T111;
T113:;
	(V58->c.c_cdr)= make_cons((V59->c.c_car),Cnil);
T111:;
	while(!endp(MMcdr(V58)))V58=MMcdr(V58);
	if(endp(V59=MMcdr(V59))){
	base[2]=base[2]->c.c_cdr;
	base[1]= base[2];
	goto T109;}
	goto T110;}
T109:;
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk114)();
	vs_top=sup;
	V47= vs_base[0];
	goto T100;
T104:;
	{register object x= car((V55)),V63= VV[13];
	while(!endp(V63))
	if(eql(x,V63->c.c_car)){
	goto T122;
	}else V63=V63->c.c_cdr;
	goto T120;}
T122:;{object V64;
	base[0]= car((V55));
	base[1]= VV[14];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk29)();
	vs_top=sup;
	V64= vs_base[0];
	if(V64==Cnil)goto T123;
	goto T120;
T123:;}
	V55= make_cons(VV[14],(V55));
T120:;
	if(!((car((V55)))==(VV[14]))){
	goto T130;}
	V56= make_cons(VV[14],(V56));
	{register object V65;
	object V66;
	object V67;
	V65= cdr((V55));
	V66= Cnil;
	V67= Cnil;
T137:;
	if(!(endp((V65)))){
	goto T138;}
	base[0]= make_cons(VV[12],(V56));
	{object V68;
	object V69= (V47);
	if(endp(V69)){
	base[1]= Cnil;
	goto T144;}
	base[2]=V68=MMcons(Cnil,Cnil);
T145:;
	if(!(type_of((V69->c.c_car))!=t_cons)){
	goto T152;}
	V72= (V69->c.c_car);
	goto T150;
T152:;
	V72= car((V69->c.c_car));
T150:;
	{register object x= V72,V71= (V57);
	while(!endp(V71))
	if(eql(x,V71->c.c_car)){
	goto T149;
	}else V71=V71->c.c_cdr;
	goto T148;}
T149:;
	(V68->c.c_cdr)= Cnil;
	goto T146;
T148:;
	(V68->c.c_cdr)= make_cons((V69->c.c_car),Cnil);
T146:;
	while(!endp(MMcdr(V68)))V68=MMcdr(V68);
	if(endp(V69=MMcdr(V69))){
	base[2]=base[2]->c.c_cdr;
	base[1]= base[2];
	goto T144;}
	goto T145;}
T144:;
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk114)();
	vs_top=sup;
	V47= vs_base[0];
	goto T134;
T138:;
	{register object x= car((V65)),V73= VV[13];
	while(!endp(V73))
	if(eql(x,V73->c.c_car)){
	goto T157;
	}else V73=V73->c.c_cdr;
	goto T155;}
T157:;
	if(!((car((V65)))==(VV[15]))){
	goto T158;}
	V56= make_cons(VV[15],(V56));
	V65= cdr((V65));
	if(endp((V65))){
	goto T166;}
	if(type_of(car((V65)))==t_symbol){
	goto T165;}
T166:;
	(void)((*(LnkLI115))());
T165:;
	V57= make_cons(car((V65)),(V57));
	V56= make_cons(car((V65)),(V56));
	V65= cdr((V65));
	if(!(endp((V65)))){
	goto T158;}
	base[0]= make_cons(VV[12],(V56));
	{object V74;
	object V75= (V47);
	if(endp(V75)){
	base[1]= Cnil;
	goto T181;}
	base[2]=V74=MMcons(Cnil,Cnil);
T182:;
	if(!(type_of((V75->c.c_car))!=t_cons)){
	goto T189;}
	V78= (V75->c.c_car);
	goto T187;
T189:;
	V78= car((V75->c.c_car));
T187:;
	{register object x= V78,V77= (V57);
	while(!endp(V77))
	if(eql(x,V77->c.c_car)){
	goto T186;
	}else V77=V77->c.c_cdr;
	goto T185;}
T186:;
	(V74->c.c_cdr)= Cnil;
	goto T183;
T185:;
	(V74->c.c_cdr)= make_cons((V75->c.c_car),Cnil);
T183:;
	while(!endp(MMcdr(V74)))V74=MMcdr(V74);
	if(endp(V75=MMcdr(V75))){
	base[2]=base[2]->c.c_cdr;
	base[1]= base[2];
	goto T181;}
	goto T182;}
T181:;
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk114)();
	vs_top=sup;
	V47= vs_base[0];
	goto T134;
T158:;
	if((car((V65)))==(VV[12])){
	goto T191;}
	(void)((*(LnkLI115))());
T191:;
	V56= make_cons(VV[12],(V56));
	{register object V79;
	V79= cdr((V65));
T199:;
	if(!(endp((V79)))){
	goto T200;}
	goto T196;
T200:;
	V56= make_cons(car((V79)),(V56));
	if(!(type_of(car((V79)))!=t_cons)){
	goto T208;}
	if(!(type_of(car((V79)))==t_symbol)){
	goto T208;}
	V57= make_cons(car((V79)),(V57));
	goto T206;
T208:;
	if(!(type_of(caar((V79)))==t_symbol)){
	goto T214;}
	if(endp(cdar((V79)))){
	goto T213;}
	if(!(endp(cddar((V79))))){
	goto T214;}
T213:;
	V57= make_cons(caar((V79)),(V57));
	goto T206;
T214:;
	(void)((*(LnkLI115))());
T206:;
	V79= cdr((V79));
	goto T199;}
T196:;
	base[0]= (V56);
	{object V80;
	object V81= (V47);
	if(endp(V81)){
	base[1]= Cnil;
	goto T227;}
	base[2]=V80=MMcons(Cnil,Cnil);
T228:;
	if(!(type_of((V81->c.c_car))!=t_cons)){
	goto T235;}
	V84= (V81->c.c_car);
	goto T233;
T235:;
	V84= car((V81->c.c_car));
T233:;
	{register object x= V84,V83= (V57);
	while(!endp(V83))
	if(eql(x,V83->c.c_car)){
	goto T232;
	}else V83=V83->c.c_cdr;
	goto T231;}
T232:;
	(V80->c.c_cdr)= Cnil;
	goto T229;
T231:;
	(V80->c.c_cdr)= make_cons((V81->c.c_car),Cnil);
T229:;
	while(!endp(MMcdr(V80)))V80=MMcdr(V80);
	if(endp(V81=MMcdr(V81))){
	base[2]=base[2]->c.c_cdr;
	base[1]= base[2];
	goto T227;}
	goto T228;}
T227:;
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk114)();
	vs_top=sup;
	V47= vs_base[0];
	goto T134;
T155:;
	if(!(type_of(car((V65)))!=t_cons)){
	goto T243;}
	V66= car((V65));
	goto T241;
T243:;
	if(!(endp(cdar((V65))))){
	goto T248;}
	V66= caar((V65));
	goto T241;
T248:;
	goto T239;
T241:;
	base[0]= (V66);
	base[1]= (V47);
	base[2]= VV[16];
	base[3]= VV[116];
	vs_top=(vs_base=base+0)+4;
	(void) (*Lnk117)();
	vs_top=sup;
	V67= vs_base[0];
	if(((V67))==Cnil){
	goto T239;}
	V56= make_cons(car((V67)),(V56));
	goto T237;
T239:;
	V56= make_cons(car((V65)),(V56));
T237:;
	if(!(type_of(car((V65)))!=t_cons)){
	goto T262;}
	if(type_of(car((V65)))==t_symbol){
	goto T264;}
	(void)((*(LnkLI115))());
T264:;
	V57= make_cons(car((V65)),(V57));
	goto T260;
T262:;
	if(type_of(caar((V65)))==t_symbol){
	goto T269;}
	(void)((*(LnkLI115))());
	goto T260;
T269:;
	if(endp(cdar((V65)))){
	goto T271;}
	if(!(endp(cddar((V65))))){
	goto T272;}
T271:;
	V57= make_cons(caar((V65)),(V57));
	goto T260;
T272:;
	if(type_of(caddar((V65)))==t_symbol){
	goto T278;}
	(void)((*(LnkLI115))());
	goto T260;
T278:;
	if(endp(cdddar((V65)))){
	goto T281;}
	(void)((*(LnkLI115))());
	goto T260;
T281:;
	V57= make_cons(caar((V65)),(V57));
	V57= make_cons(caddar((V65)),(V57));
T260:;
	V65= cdr((V65));
	goto T137;}
T134:;
	goto T100;
T130:;
	if(type_of(car((V55)))==t_symbol){
	goto T289;}
	(void)((*(LnkLI115))());
T289:;
	V56= make_cons(car((V55)),(V56));
	V57= make_cons(car((V55)),(V57));
	V55= cdr((V55));
	goto T103;}
T100:;
	V42= car((V42));
	goto T96;
T98:;
	V47= make_cons(VV[17],(V47));
T96:;
	if(((V43))!=Cnil){
	goto T301;}
	{object V85 = list(4,VV[3],(V42),(V47),listA(3,VV[18],list(2,VV[11],(V41)),(V46)));
	VMR2(V85)}
T301:;
	if(((V43))==(VV[19])){
	goto T303;}
	if(!(type_of((V43))==t_cons)){
	goto T304;}
	if(!((car((V43)))==(VV[19]))){
	goto T304;}
T303:;
	{object V86 = list(4,VV[3],(V42),(V47),make_cons(VV[19],(V46)));
	VMR2(V86)}
T304:;
	if(!(((V43))==(VV[20]))){
	goto T311;}
	{object V87 = list(4,VV[3],(V42),(V47),make_cons(VV[20],(V46)));
	VMR2(V87)}
T311:;
	{object V88;
	base[0]= VV[21];
	base[1]= (V43);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk118)();
	vs_top=sup;
	V88= vs_base[0];
	if(((V88))==Cnil){
	goto T317;}
	{object V89 = (V88);
	VMR2(V89)}
T317:;
	{object V90 = Cnil;
	VMR2(V90)}}}
}
/*	local entry for function ILLEGAL-BOA	*/

static object LI3()

{	 VMB3 VMS3 VMV3
TTL:;
	base[0]= VV[22];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk118)();
	vs_top=sup;
	{object V91 = vs_base[0];
	VMR3(V91)}
}
/*	local entry for function MAKE-PREDICATE	*/

static object LI4(V97,V98,V99,V100,V101)

object V97;object V98;register object V99;object V100;register object V101;
{	 VMB4 VMS4 VMV4
TTL:;
	{object V102;
	base[0]= (V99);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk119)();
	vs_top=sup;
	V102= vs_base[0];
	if(((V102))==Cnil){
	goto T323;}
	{object V103 = (V102);
	VMR4(V103)}
T323:;
	if(((V99))==(VV[19])){
	goto T325;}
	if(!(type_of((V99))==t_cons)){
	goto T326;}
	if(!((car((V99)))==(VV[19]))){
	goto T326;}
T325:;
	if(((V100))!=Cnil){
	goto T332;}
	base[0]= VV[23];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk118)();
	vs_top=sup;
T332:;
	V104= list(3,VV[27],VV[28],(V101));
	V105= list(3,VV[30],VV[31],(V101));
	{object V106 = list(4,VV[3],(V98),VV[24],list(4,VV[25],VV[26],/* INLINE-ARGS */V104,list(3,VV[29],/* INLINE-ARGS */V105,list(2,VV[11],(V97)))));
	VMR4(V106)}
T326:;
	if(!(((V99))==(VV[20]))){
	goto T337;}
	if(((V100))!=Cnil){
	goto T339;}
	base[0]= VV[32];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk118)();
	vs_top=sup;
T339:;
	if(!(number_compare((V101),small_fixnum(0))==0)){
	goto T344;}
	{object V107 = list(4,VV[3],(V98),VV[33],list(3,VV[25],VV[34],list(3,VV[29],VV[35],list(2,VV[11],(V97)))));
	VMR4(V107)}
T344:;
	V108= list(2,list(3,VV[38],(V101),VV[39]),VV[40]);
	{object V109 = list(4,VV[3],(V98),VV[36],listA(4,VV[37],/* INLINE-ARGS */V108,list(2,VV[41],list(3,VV[25],VV[42],list(3,VV[29],VV[43],list(2,VV[11],(V97))))),VV[44]));
	VMR4(V109)}
T337:;
	{object V110;
	base[0]= VV[45];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk118)();
	vs_top=sup;
	V110= vs_base[0];
	if(((V110))==Cnil){
	goto T349;}
	{object V111 = (V110);
	VMR4(V111)}
T349:;
	{object V112 = Cnil;
	VMR4(V112)}}}
}
/*	local entry for function PARSE-SLOT-DESCRIPTION	*/

static object LI5(V115,V116)

register object V115;object V116;
{	 VMB5 VMS5 VMV5
TTL:;
	{object V117;
	object V118;
	register object V119;
	register object V120;
	V117= Cnil;
	V118= Cnil;
	V119= Cnil;
	V120= Cnil;
	if(!(type_of((V115))!=t_cons)){
	goto T353;}
	V117= (V115);
	goto T351;
T353:;
	if(!(endp(cdr((V115))))){
	goto T357;}
	V117= car((V115));
	goto T351;
T357:;
	V117= car((V115));
	V118= cadr((V115));
	{register object V121;
	register object V122;
	register object V123;
	V121= cddr((V115));
	V122= Cnil;
	V123= Cnil;
T366:;
	if(!(endp((V121)))){
	goto T367;}
	goto T351;
T367:;
	V122= car((V121));
	if(!(endp(cdr((V121))))){
	goto T373;}
	base[0]= VV[46];
	base[1]= (V121);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk118)();
	vs_top=sup;
T373:;
	V123= cadr((V121));
	{object V124= (V122);
	if((V124!= VV[74]))goto T381;
	V119= (V123);
	goto T380;
T381:;
	if((V124!= VV[120]))goto T383;
	V120= (V123);
	goto T380;
T383:;
	base[0]= VV[47];
	base[1]= (V121);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk118)();
	vs_top=sup;}
T380:;
	V121= cddr((V121));
	goto T366;}
T351:;
	{object V125 = list(5,(V117),(V118),(V119),(V120),(V116));
	VMR5(V125)}}
}
/*	local entry for function OVERWRITE-SLOT-DESCRIPTIONS	*/

static object LI6(V128,V129)

object V128;register object V129;
{	 VMB6 VMS6 VMV6
TTL:;
	if(((V129))!=Cnil){
	goto T391;}
	{object V130 = Cnil;
	VMR6(V130)}
T391:;
	{register object V131;
	base[0]= caar((V129));
	base[1]= (V128);
	base[2]= VV[16];
	base[3]= symbol_function(VV[121]);
	vs_top=(vs_base=base+0)+4;
	(void) (*Lnk117)();
	vs_top=sup;
	V131= vs_base[0];
	if(((V131))==Cnil){
	goto T399;}
	if((cadddr(car((V131))))!=Cnil){
	goto T401;}
	if((cadddr(car((V129))))==Cnil){
	goto T401;}
	base[0]= VV[48];
	base[1]= (V131);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk118)();
	vs_top=sup;
T401:;
	{object V132;
	object V133;
	V132= car((V131));
	V133= (*(LnkLI122))(caddr(car((V131))));
	if(type_of(cddr((V132)))!=t_cons)FEwrong_type_argument(Scons,cddr((V132)));
	(cddr((V132)))->c.c_car = (V133);
	(void)(cddr((V132)));}{object V135;
	V135= caddr(car((V131)));
	if(V135==Cnil)goto T416;
	V134= V135;
	goto T415;
T416:;}
	V134= Ct;
T415:;
	V136= (*(LnkLI123))(V134);{object V138;
	V138= caddr(car((V129)));
	if(V138==Cnil)goto T419;
	V137= V138;
	goto T418;
T419:;}
	V137= Ct;
T418:;
	V139= (*(LnkLI123))(V137);
	if(equal(/* INLINE-ARGS */V136,/* INLINE-ARGS */V139)){
	goto T412;}
	base[0]= VV[49];
	base[1]= car((V131));
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk118)();
	vs_top=sup;
T412:;
	V140= list(5,caar((V131)),cadar((V131)),caddar((V131)),cadddr(car((V131))),car(cddddr(car((V129)))));
	V141= (*(LnkLI124))((V128),cdr((V129)));
	{object V142 = make_cons(/* INLINE-ARGS */V140,/* INLINE-ARGS */V141);
	VMR6(V142)}
T399:;
	V143= car((V129));
	V144= (*(LnkLI124))((V128),cdr((V129)));
	{object V145 = make_cons(/* INLINE-ARGS */V143,/* INLINE-ARGS */V144);
	VMR6(V145)}}
}
/*	local entry for function MAKE-T-TYPE	*/

static object LI7(V149,V150,V151)

object V149;object V150;object V151;
{	 VMB7 VMS7 VMV7
TTL:;
	{object V152;
	V152= Cnil;
	{register object V153;
	V153= (VFUN_NARGS=5,(*(LnkLI125))((V149),VV[50],VV[51],VV[52],Ct));
	if(((V150))==Cnil){
	goto T425;}
	{object V154;
	object V155;
	V154= get((V150),VV[53],Cnil);
	V155= Cnil;
	if((V154)!=Cnil){
	goto T429;}
	base[0]= VV[54];
	base[1]= (V150);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk118)();
	vs_top=sup;
T429:;
	V155= structure_ref((V154),VV[53],2);
	{object V156;
	register object V157;
	V158 = make_fixnum(length((V155)));
	V156= (number_compare((V149),V158)<=0?((V149)):V158);
	V157= small_fixnum(0);
T437:;
	if(!(number_compare((V157),(V156))>=0)){
	goto T438;}
	goto T425;
T438:;
	V159= aref1((V155),fixint((V157)));
	(void)(aset1((V153),fixint((V157)),/* INLINE-ARGS */V159));
	V157= one_plus((V157));
	goto T437;}}
T425:;
	{register object V160;
	register object V161;
	V160= (V151);
	V161= car((V160));
T450:;
	if(!(endp((V160)))){
	goto T451;}
	goto T446;
T451:;
	V152= car(cddddr((V161)));
	{register object V162;
	V162= caddr((V161));
	base[1]= (V162);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk126)();
	vs_top=sup;
	V163= vs_base[0];
	if(!((fix(V163))<=(4))){
	goto T457;}
	base[1]= (V162);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk127)();
	vs_top=sup;
	V164= vs_base[0];
	(void)(aset1((V153),fixint((V152)),V164));}
T457:;
	V160= cdr((V160));
	V161= car((V160));
	goto T450;}
T446:;
	V165 = make_fixnum(length(symbol_value(VV[55])));
	if(!(number_compare((V149),V165)<0)){
	goto T471;}
	{register object V167;
	V167= small_fixnum(0);
T476:;
	if(!(number_compare((V167),V149)>=0)){
	goto T477;}
	goto T473;
T477:;
	{int V168= fix(aref1((V153),fixint((V167))));
	if((/* INLINE-ARGS */V168)==(0)){
	goto T481;}}
	{object V169 = (V153);
	VMR7(V169)}
T481:;
	V167= one_plus((V167));
	goto T476;}
T473:;
	{object V170 = symbol_value(VV[55]);
	VMR7(V170)}
T471:;
	{object V171 = (V153);
	VMR7(V171)}}}
}
/*	local entry for function ROUND-UP	*/

static int LI8(V174,V175)

int V174;int V175;
{	 VMB8 VMS8 VMV8
TTL:;
	base[0]= make_fixnum(V174);
	base[1]= make_fixnum(V175);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk128)();
	vs_top=sup;
	V174= fix(vs_base[0]);
	{int V176 = (V174)*(V175);
	VMR8(V176)}
}
/*	local entry for function GET-SLOT-POS	*/

static object LI9(V180,V181,V182)

object V180;object V181;object V182;
{	 VMB9 VMS9 VMV9
TTL:;
	{register object V183;
	object V184;
	object V185;
	V183= Cnil;
	V184= Cnil;
	V185= Cnil;
	{register object V186;
	register object V187;
	V186= (V182);
	V187= car((V186));
T499:;
	if(!(endp((V186)))){
	goto T500;}
	goto T495;
T500:;
	if(((V187))==Cnil){
	goto T504;}
	if((car((V187)))==Cnil){
	goto T504;}
	V183= (*(LnkLI122))(caddr((V187)));
	if(type_of(cddr(V187))!=t_cons)FEwrong_type_argument(Scons,cddr(V187));
	(cddr(V187))->c.c_car = V183;
	(void)(cddr(V187));
	{register object V190;
	V190= cadr((V187));
	base[1]= (V190);
	base[2]= (V183);
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk129)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T513;}
	if(!(type_of((V190))==t_symbol)){
	goto T519;}
	base[1]= (V190);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk130)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T519;}
	base[1]= (V190);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk131)();
	vs_top=sup;
	V190= vs_base[0];
T519:;
	base[1]= (V190);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk130)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T527;}
	goto T513;
T527:;
	{object V192;
	V192= (*(LnkLI132))((V190),(V183));
	if(type_of(cdr(V187))!=t_cons)FEwrong_type_argument(Scons,cdr(V187));
	(cdr(V187))->c.c_car = (V192);
	(void)(cdr(V187));}}
T513:;
	{register object x= (V183),V193= VV[57];
	while(!endp(V193))
	if(x==(V193->c.c_car)){
	goto T533;
	}else V193=V193->c.c_cdr;
	goto T504;}
T533:;
	V184= Ct;
T504:;
	V186= cdr((V186));
	V187= car((V186));
	goto T499;}
T495:;
	{object V194;
	base[0]= (V184);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk119)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T541;}
	V194= Cnil;
	goto T540;
T541:;
	base[0]= (V180);
	base[1]= make_fixnum(length(symbol_value(VV[56])));
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk133)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T544;}
	V194= Cnil;
	goto T540;
T544:;{object V195;
	V195= symbol_value(VV[56]);
	V194= list(3,V195,number_times((V180),small_fixnum(4)),Cnil);}
T540:;
	if(((V194))==Cnil){
	goto T549;}
	{object V196 = (V194);
	VMR9(V196)}
T549:;
	{object V197;
	register int V198;
	int V199;
	int V200;
	object V201;
	int V202;
	V197= (VFUN_NARGS=5,(*(LnkLI125))((V180),VV[50],VV[58],VV[52],Ct));
	V198= 0;
	V199= 0;
	V200= 0;
	V202= 0;
	V201= Cnil;
	{register object V203;
	register object V204;
	V203= (V182);
	V204= car((V203));
T560:;
	if(!(endp((V203)))){
	goto T561;}
	goto T556;
T561:;
	V201= caddr((V204));
	base[1]= (V201);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk126)();
	vs_top=sup;
	V200= fix(vs_base[0]);
	if((V200)<=(4)){
	goto T570;}
	V201= Ct;
	if(type_of(cddr(V204))!=t_cons)FEwrong_type_argument(Scons,cddr(V204));
	(cddr(V204))->c.c_car = Ct;
	(void)(cddr(V204));
	V200= 4;
	V204= nconc((V204),VV[59]);
T570:;
	V202= (*(LnkLI134))(V198,V200);{object V207;
	base[1]= make_fixnum(V198);
	base[2]= make_fixnum(V202);
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk135)();
	vs_top=sup;
	V207= vs_base[0];
	if(V207==Cnil)goto T583;
	goto T582;
T583:;}
	V185= Ct;
T582:;
	V198= V202;
	V208 = make_fixnum(V198);
	(void)(aset1((V197),V199,V208));
	V209 = make_fixnum(V198);
	base[1]= (V201);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk136)();
	vs_top=sup;
	V210= vs_base[0];
	V198= fix(number_plus(V209,V210));
	V199= (V199)+(1);
	V203= cdr((V203));
	V204= car((V203));
	goto T560;}
T556:;
	base[0]= Ct;
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk136)();
	vs_top=sup;
	V211= vs_base[0];
	V212 = make_fixnum((*(LnkLI134))(V198,fix(V211)));
	{object V213 = list(3,(V197),V212,(V185));
	VMR9(V213)}}}}
}
/*	local entry for function DEFINE-STRUCTURE	*/

static object LI10(V225,V224,V223,V222,V221,V220,V219,V218,V217,V216,V215,V214,va_alist)
	object V225,V224,V223,V222,V221,V220,V219,V218,V217,V216,V215,V214;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB10 VMS10 VMV10
	{object V226;
	register object V227;
	object V228;
	object V229;
	object V230;
	object V231;
	register object V232;
	object V233;
	object V234;
	object V235;
	object V236;
	object V237;
	register object V238;
	if(narg <12) too_few_arguments();
	Vcs[0]=MMcons(V225,Cnil);
	V226= V224;
	V227= V223;
	V228= V222;
	V229= V221;
	V230= V220;
	V231= V219;
	V232= V218;
	V233= V217;
	V234= V216;
	V235= V215;
	V236= V214;
	narg = narg - 12;
	if (narg <= 0) goto T604;
	else {
	va_start(ap);
	V237= va_arg(ap,object);}
	if (--narg <= 0) goto T605;
	else {
	V238= va_arg(ap,object);}
	--narg; goto T606;
T604:;
	V237= Cnil;
T605:;
	V238= Cnil;
T606:;
	{object V239;
	object V240;
	V239= Cnil;
	V240= Cnil;
	base[0]= (V227);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk137)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T612;}
	goto T611;
T612:;
	base[0]= car((V227));
	base[1]= VV[19];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk29)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T615;}
	goto T611;
T615:;
	V227= VV[19];
T611:;
	V240= make_fixnum(length((V229)));
	{register object V241;
	register object V242;
	V241= (V229);
	V242= car((V241));
T626:;
	if(!(endp((V241)))){
	goto T627;}
	goto T622;
T627:;
	if((V242)==Cnil){
	goto T631;}
	if((car((V242)))!=Cnil){
	goto T632;}
	goto T631;
T632:;
	base[1]= (Vcs[0]->c.c_car);
	base[2]= (V226);
	base[3]= (V227);
	base[4]= (V228);
	base[5]= (V232);
	base[6]= (V238);
	{object V243;
	V243= (V242);
	 vs_top=base+7;
	 while(!endp(V243))
	 {vs_push(car(V243));V243=cdr(V243);}
	vs_base=base+1;}
	(void) (*Lnk138)();
	vs_top=sup;
T631:;
	V241= cdr((V241));
	V242= car((V241));
	goto T626;}
T622:;
	if(((V230))==Cnil){
	goto T646;}
	if(((V238))!=Cnil){
	goto T646;}
	base[0]= (V230);
	{object V244= (V227);
	if((V244!= Cnil))goto T653;
	base[1]= symbol_function(VV[139]);
	goto T652;
T653:;
	if((V244!= VV[20]))goto T654;
	base[1]= symbol_function(VV[140]);
	goto T652;
T654:;
	if((V244!= VV[19]))goto T655;
	base[1]= symbol_function(VV[141]);
	goto T652;
T655:;
	FEerror("The ECASE key value ~s is illegal.",1,V244);}
T652:;
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk112)();
	vs_top=sup;
T646:;
	if(((V227))!=Cnil){
	goto T658;}
	if(!(((Vcs[0]->c.c_car))==(VV[53]))){
	goto T658;}
	base[0]= (VFUN_NARGS=5,(*(LnkLI125))((V240),VV[50],VV[60],VV[52],Ct));
	base[1]= (*(LnkLI142))((V240),Cnil,(V229));
	base[2]= symbol_value(VV[56]);
	base[3]= (V229);
	base[4]= Ct;
	vs_top=(vs_base=base+0)+5;
	(void) (*Lnk143)();
	vs_top=sup;
	V239= vs_base[0];
	goto T656;
T658:;
	{object V245;
	object V246;
	object V247;
	object V248;
	if((V232)==Cnil){
	V248= Cnil;
	goto T668;}
	V248= get((V232),VV[53],Cnil);
T668:;
	V245= Cnil;
	V246= small_fixnum(0);
	V247= Cnil;
	if(((V248))==Cnil){
	goto T669;}
	if((structure_ref((V248),VV[53],11))==Cnil){
	goto T672;}
	if((structure_ref((V248),VV[53],3))==Cnil){
	goto T673;}
	{object V249;
	V249= get((Vcs[0]->c.c_car),VV[53],Cnil);
	if((V249)==Cnil){
	goto T678;}
	base[0]= structure_ref((V249),VV[53],4);
	base[1]= (V248);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk29)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T672;}}
T678:;
T673:;
	(void)((VFUN_NARGS=2,(*(LnkLI144))(VV[61],(V232))));
T672:;
	{object V251;
	base[1]= (Vcs[0]->c.c_car);
	base[2]= structure_ref(V248,VV[53],3);
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk145)();
	vs_top=sup;
	V251= vs_base[0];
	(void)(structure_set(V248,VV[53],3,(V251)));}
T669:;
	if(((V227))!=Cnil){
	goto T685;}
	V245= (*(LnkLI146))((V240),(V232),(V229));
	V246= cadr((V245));
	V247= caddr((V245));
	V245= car((V245));
T685:;
	base[0]= (V227);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk119)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T697;}
	V252= Cnil;
	goto T696;
T697:;
	V252= (*(LnkLI142))((V240),(V232),(V229));
T696:;
	V239= (VFUN_NARGS=32,(*(LnkLI147))(VV[62],(Vcs[0]->c.c_car),VV[63],(V240),VV[64],V252,VV[65],(V245),VV[66],(V246),VV[67],(V247),VV[68],(V231),VV[69],(V248),VV[70],(V233),VV[71],(V229),VV[72],(V234),VV[73],(V235),VV[74],(V227),VV[75],(V228),VV[76],(V237),VV[77],(V226)));}
T656:;
	{object V253;
	V253= get((Vcs[0]->c.c_car),VV[53],Cnil);
	if(!(((Vcs[0]->c.c_car))==(VV[53]))){
	goto T704;}
	if(((V253))==Cnil){
	goto T706;}
	(void)((VFUN_NARGS=1,(*(LnkLI144))(VV[78])));
T706:;
	if((V253)!=Cnil){
	goto T702;}
	(void)(sputprop((Vcs[0]->c.c_car),VV[53],(V239)));
	goto T702;
T704:;
	if(((V253))==Cnil){
	goto T710;}
	(void)((*(LnkLI148))((V253),(V239),(Vcs[0]->c.c_car)));
	goto T702;
T710:;
	(void)(sputprop((Vcs[0]->c.c_car),VV[53],(V239)));
T702:;
	if(((V237))==Cnil){
	goto T712;}
	(void)(sputprop((Vcs[0]->c.c_car),VV[79],(V237)));
T712:;
	if(((V227))!=Cnil){
	goto T700;}
	if(((V236))==Cnil){
	goto T700;}
	base[0]= (V236);
	base[1]= VV[3];
	base[2]= VV[80];
	base[3]= Ct;
	vs_top=(vs_base=base+0)+4;
	(void) (*Lnk109)();
	vs_top=sup;
	if((V238)!=Cnil){
	goto T724;}
	base[0]= (V236);
	base[1]= 
	make_cclosure_new(LC20,Cnil,Vcs[0],Cdata);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk112)();
	vs_top=sup;
T724:;
	(void)(sputprop((V236),VV[81],VV[82]));
	(void)(sputprop((V236),VV[83],(Vcs[0]->c.c_car)));}
T700:;
	{object V254 = Cnil;
	VMR10(V254)}}}
	}
/*	macro definition for DEFSTRUCT	*/

static L11()
{register object *base=vs_base;
	register object *sup=base+VM11; VC11
	vs_reserve(VM11);
	check_arg(2);
	vs_top=sup;
	{object V255=base[0]->c.c_cdr;
	if(endp(V255))invalid_macro_call();
	base[2]= (V255->c.c_car);
	V255=V255->c.c_cdr;
	base[3]= V255;}
	{register object V256;
	object V257;
	register object V258;
	register object V259;
	register object V260;
	register object V261;
	register object V262;
	register object V263;
	register object V264;
	register object V265;
	register object V266;
	register object V267;
	register object V268;
	register object V269;
	register object V270;
	object V271;
	object V272;
	register object V273;
	V256= base[3];
	V257= Cnil;
	V258= Cnil;
	V259= Cnil;
	V260= Cnil;
	V261= Cnil;
	V262= Cnil;
	V263= Cnil;
	V264= Cnil;
	V265= Cnil;
	V266= Cnil;
	V267= Cnil;
	V268= Cnil;
	V269= Cnil;
	V270= Cnil;
	V271= Cnil;
	V272= Cnil;
	V273= Cnil;
	if(!(type_of(base[2])==t_cons)){
	goto T728;}
	V257= cdr(base[2]);
	base[2]= car(base[2]);
T728:;
	base[4]= coerce_to_string(base[2]);
	base[5]= VV[84];
	vs_top=(vs_base=base+4)+2;
	(void) (*Lnk106)();
	vs_top=sup;
	V258= vs_base[0];
	base[5]= VV[85];
	base[6]= coerce_to_string(base[2]);
	vs_top=(vs_base=base+5)+2;
	(void) (*Lnk106)();
	vs_top=sup;
	base[4]= vs_base[0];
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk107)();
	vs_top=sup;
	V260= vs_base[0];
	base[5]= VV[86];
	base[6]= coerce_to_string(base[2]);
	vs_top=(vs_base=base+5)+2;
	(void) (*Lnk106)();
	vs_top=sup;
	base[4]= vs_base[0];
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk107)();
	vs_top=sup;
	V262= vs_base[0];
	base[5]= coerce_to_string(base[2]);
	base[6]= VV[87];
	vs_top=(vs_base=base+5)+2;
	(void) (*Lnk106)();
	vs_top=sup;
	base[4]= vs_base[0];
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk107)();
	vs_top=sup;
	V263= vs_base[0];
	{register object V274;
	register object V275;
	register object V276;
	V274= (V257);
	V275= Cnil;
	V276= Cnil;
T755:;
	if(!(endp((V274)))){
	goto T756;}
	goto T753;
T756:;
	if(!(type_of(car((V274)))==t_cons)){
	goto T762;}
	if(endp(cdar((V274)))){
	goto T762;}
	V275= caar((V274));
	V276= cadar((V274));
	{object V277= (V275);
	if((V277!= VV[77]))goto T770;
	if(((V276))!=Cnil){
	goto T772;}
	V258= VV[88];
	goto T760;
T772:;
	V258= (V276);
	goto T760;
T770:;
	if((V277!= VV[149]))goto T776;
	if(((V276))!=Cnil){
	goto T778;}
	V261= Ct;
	goto T760;
T778:;
	if(!(endp(cddar((V274))))){
	goto T782;}
	V259= make_cons((V276),(V259));
	goto T760;
T782:;
	V259= make_cons(cdar((V274)),(V259));
	goto T760;
T776:;
	if((V277!= VV[150]))goto T786;
	V262= (V276);
	goto T760;
T786:;
	if((V277!= VV[52]))goto T788;
	V273= (V276);
	goto T760;
T788:;
	if((V277!= VV[151]))goto T790;
	V263= (V276);
	V264= Ct;
	goto T760;
T790:;
	if((V277!= VV[152]))goto T794;
	V265= cdar((V274));
	if((get((V276),VV[53],Cnil))!=Cnil){
	goto T760;}
	base[4]= VV[89];
	base[5]= (V276);
	vs_top=(vs_base=base+4)+2;
	(void) (*Lnk118)();
	vs_top=sup;
	goto T760;
T794:;
	if((V277!= VV[70]))goto T801;
	base[4]= (V276);
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk137)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T803;}
	goto T802;
T803:;
	base[4]= car((V276));
	base[5]= VV[90];
	vs_top=(vs_base=base+4)+2;
	(void) (*Lnk29)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T806;}
	goto T802;
T806:;
	V276= cadr((V276));
T802:;
	V266= (V276);
	goto T760;
T801:;
	if((V277!= VV[74]))goto T812;
	V267= (V276);
	goto T760;
T812:;
	if((V277!= VV[153]))goto T814;
	V269= (V276);
	goto T760;
T814:;
	base[4]= VV[91];
	base[5]= (V275);
	vs_top=(vs_base=base+4)+2;
	(void) (*Lnk118)();
	vs_top=sup;
	goto T760;}
T762:;
	if(!(type_of(car((V274)))==t_cons)){
	goto T820;}
	V275= caar((V274));
	goto T818;
T820:;
	V275= car((V274));
T818:;
	{object V278= (V275);
	if((V278!= VV[149]))goto T824;
	V259= make_cons((V260),(V259));
	goto T760;
T824:;
	if((V278!= VV[77])
	&& (V278!= VV[150])
	&& (V278!= VV[151])
	&& (V278!= VV[70]))goto T826;
	goto T760;
T826:;
	if((V278!= VV[75]))goto T827;
	V268= Ct;
	goto T760;
T827:;
	base[4]= VV[92];
	base[5]= (V275);
	vs_top=(vs_base=base+4)+2;
	(void) (*Lnk118)();
	vs_top=sup;}
T760:;
	V274= cdr((V274));
	goto T755;}
T753:;
	base[4]= coerce_to_string((V258));
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk107)();
	vs_top=sup;
	V258= vs_base[0];
	if((V265)==Cnil){
	goto T837;}
	base[4]= (V266);
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk154)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T838;}
	goto T837;
T838:;
	V279= get(car((V265)),VV[53],Cnil);
	V266= structure_ref(V279,VV[53],6);
T837:;
	if(endp((V256))){
	goto T843;}
	if(!(type_of(car((V256)))==t_string)){
	goto T843;}
	V272= car((V256));
	V256= cdr((V256));
T843:;
	if(((V265))==Cnil){
	goto T851;}
	V280= get(car((V265)),VV[53],Cnil);
	V281= structure_ref(V280,VV[53],16);
	if(equal((V267),/* INLINE-ARGS */V281)){
	goto T851;}
	base[4]= VV[93];
	base[5]= car((V265));
	vs_top=(vs_base=base+4)+2;
	(void) (*Lnk118)();
	vs_top=sup;
T851:;
	if(((V265))!=Cnil){
	goto T861;}
	V270= small_fixnum(0);
	goto T859;
T861:;
	V282= get(car((V265)),VV[53],Cnil);
	V270= structure_ref(V282,VV[53],14);
T859:;
	if(((V267))==Cnil){
	goto T866;}
	if(((V269))==Cnil){
	goto T866;}
	V270= number_plus((V270),(V269));
T866:;
	if(((V267))==Cnil){
	goto T872;}
	if(((V268))==Cnil){
	goto T872;}
	V271= (V270);
	V270= one_plus((V270));
T872:;
	{register object V283;
	register object V284;
	V283= (V256);
	V284= Cnil;
T882:;
	if(!(endp((V283)))){
	goto T883;}
	V256= nreverse((V284));
	goto T880;
T883:;
	V285= (*(LnkLI155))(car((V283)),(V270));
	V284= make_cons(/* INLINE-ARGS */V285,(V284));
	V270= one_plus((V270));
	V283= cdr((V283));
	goto T882;}
T880:;
	if(((V267))==Cnil){
	goto T895;}
	if(((V268))==Cnil){
	goto T895;}
	V286= list(2,Cnil,base[2]);
	V256= make_cons(/* INLINE-ARGS */V286,(V256));
T895:;
	if(((V267))==Cnil){
	goto T901;}
	if(((V269))==Cnil){
	goto T901;}
	base[4]= (V269);
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk156)();
	vs_top=sup;
	V287= vs_base[0];
	V256= append(V287,(V256));
T901:;
	{object V288;
	base[4]= (V265);
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk119)();
	vs_top=sup;
	V288= vs_base[0];
	if(((V288))==Cnil){
	goto T913;}
	goto T909;
T913:;
	if(!(endp(cdr((V265))))){
	goto T916;}
	V289= get(car((V265)),VV[53],Cnil);
	V290= structure_ref(V289,VV[53],7);
	V256= append(/* INLINE-ARGS */V290,(V256));
	goto T909;
T916:;
	{object V292;
	object V293= cdr((V265));
	if(endp(V293)){
	V291= Cnil;
	goto T921;}
	base[4]=V292=MMcons(Cnil,Cnil);
T922:;
	(V292->c.c_car)= (*(LnkLI155))((V293->c.c_car),small_fixnum(0));
	if(endp(V293=MMcdr(V293))){
	V291= base[4];
	goto T921;}
	V292=MMcdr(V292)=MMcons(Cnil,Cnil);
	goto T922;}
T921:;
	V295= get(car((V265)),VV[53],Cnil);
	V296= structure_ref(V295,VV[53],7);
	V297= (*(LnkLI124))(V291,/* INLINE-ARGS */V296);
	V256= append(/* INLINE-ARGS */V297,(V256));}
T909:;
	if(((V261))==Cnil){
	goto T927;}
	if(((V259))==Cnil){
	goto T925;}
	base[4]= VV[94];
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk118)();
	vs_top=sup;
	goto T925;
T927:;
	if(((V259))!=Cnil){
	goto T925;}
	V259= make_cons((V260),Cnil);
T925:;{object V298;
	base[5]=symbol_function(VV[157]);
	{object V301;
	object V302= (V259);
	if(endp(V302)){
	V300= Cnil;
	goto T938;}
	base[4]=V301=MMcons(Cnil,Cnil);
T939:;
	base[6]= (V302->c.c_car);
	vs_top=(vs_base=base+6)+1;
	(void) (*Lnk157)();
	vs_top=sup;
	(V301->c.c_car)= vs_base[0];
	if(endp(V302=MMcdr(V302))){
	V300= base[4];
	goto T938;}
	V301=MMcdr(V301)=MMcons(Cnil,Cnil);
	goto T939;}
T938:;
	{register object x= Ct,V299= V300;
	while(!endp(V299))
	if(eql(x,V299->c.c_car)){
	V298= V299;
	goto T937;
	}else V299=V299->c.c_cdr;
	V298= Cnil;}
T937:;
	if(V298==Cnil)goto T936;
	goto T935;
T936:;}
	base[5]= VV[95];
	base[6]= (V260);
	vs_top=(vs_base=base+5)+2;
	(void) (*Lnk106)();
	vs_top=sup;
	base[4]= vs_base[0];
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk107)();
	vs_top=sup;
	V303= vs_base[0];
	V259= make_cons(V303,(V259));
T935:;
	if(((V267))==Cnil){
	goto T947;}
	if(((V268))!=Cnil){
	goto T947;}
	if(((V264))==Cnil){
	goto T952;}
	base[4]= VV[96];
	base[5]= (V263);
	vs_top=(vs_base=base+4)+2;
	(void) (*Lnk118)();
	vs_top=sup;
T952:;
	V263= Cnil;
T947:;
	if(((V265))==Cnil){
	goto T958;}
	V265= car((V265));
T958:;
	if(((V266))==Cnil){
	goto T962;}
	if(((V267))==Cnil){
	goto T962;}
	base[4]= VV[97];
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk118)();
	vs_top=sup;
T962:;
	base[4]= VV[99];
	base[5]= list(2,VV[11],base[2]);
	base[6]= list(2,VV[11],(V258));
	base[7]= list(2,VV[11],(V267));
	base[8]= list(2,VV[11],(V268));
	base[9]= list(2,VV[11],(V256));
	base[10]= list(2,VV[11],(V262));
	base[11]= list(2,VV[11],(V273));
	base[12]= list(2,VV[11],(V265));
	base[13]= list(2,VV[11],(V266));
	base[14]= list(2,VV[11],(V259));
	base[15]= list(2,VV[11],(V270));
	base[16]= list(2,VV[11],(V263));
	base[17]= list(2,VV[11],(V272));
	vs_top=(vs_base=base+4)+14;
	(void) (*Lnk20)();
	vs_top=sup;
	V304= vs_base[0];
	{object V306;
	object V307= (V259);
	if(endp(V307)){
	base[4]= Cnil;
	goto T984;}
	base[5]=V306=MMcons(Cnil,Cnil);
T985:;
	(V306->c.c_car)= (*(LnkLI158))(base[2],(V307->c.c_car),(V267),(V268),(V256));
	if(endp(V307=MMcdr(V307))){
	base[4]= base[5];
	goto T984;}
	V306=MMcdr(V306)=MMcons(Cnil,Cnil);
	goto T985;}
T984:;
	if(((V267))==Cnil){
	goto T989;}
	if(((V263))==Cnil){
	goto T989;}
	V309= (*(LnkLI159))(base[2],(V263),(V267),(V268),(V271));
	base[5]= make_cons(/* INLINE-ARGS */V309,Cnil);
	goto T987;
T989:;
	base[5]= Cnil;
T987:;
	V310= list(2,VV[11],base[2]);
	base[6]= make_cons(/* INLINE-ARGS */V310,Cnil);
	vs_top=(vs_base=base+4)+3;
	(void) (*Lnk160)();
	vs_top=sup;
	V305= vs_base[0];
	base[4]= listA(3,VV[98],V304,V305);
	vs_top=(vs_base=base+4)+1;
	return;}
}
/*	local entry for function MAKE-S-DATA	*/

static object LI12(va_alist)
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB12 VMS12 VMV12
	{object V311;
	object V312;
	object V313;
	object V314;
	object V315;
	object V316;
	object V317;
	object V318;
	object V319;
	object V320;
	object V321;
	object V322;
	object V323;
	object V324;
	object V325;
	object V326;
	object V327;
	object V328;
	narg= narg - 0;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +0,&LI12key,ap);
	V311=(Vcs[0]);
	V312=(Vcs[1]);
	V313=(Vcs[2]);
	V314=(Vcs[3]);
	V315=(Vcs[4]);
	V316=(Vcs[5]);
	V317=(Vcs[6]);
	V318=(Vcs[7]);
	V319=(Vcs[8]);
	V320=(Vcs[9]);
	V321=(Vcs[10]);
	V322=(Vcs[11]);
	V323=(Vcs[12]);
	V324=(Vcs[13]);
	V325=(Vcs[14]);
	V326=(Vcs[15]);
	V327=(Vcs[16]);
	V328=(Vcs[17]);
	base[0]= VV[53];
	base[1]= (V311);
	base[2]= (V312);
	base[3]= (V313);
	base[4]= (V314);
	base[5]= (V315);
	base[6]= (V316);
	base[7]= (V317);
	base[8]= (V318);
	base[9]= (V319);
	base[10]= (V320);
	base[11]= (V321);
	base[12]= (V322);
	base[13]= (V323);
	base[14]= (V324);
	base[15]= (V325);
	base[16]= (V326);
	base[17]= (V327);
	base[18]= (V328);
	vs_top=(vs_base=base+0)+19;
	(void) (*Lnk18)();
	vs_top=sup;
	{object V329 = vs_base[0];
	VMR12(V329)}}
	}}
/*	local entry for function CHECK-S-DATA	*/

static object LI13(V333,V334,V335)

register object V333;register object V334;object V335;
{	 VMB13 VMS13 VMV13
TTL:;
	if((structure_ref((V333),VV[53],3))==Cnil){
	goto T1013;}
	V336= structure_ref((V333),VV[53],3);
	(void)(structure_set((V334),VV[53],3,/* INLINE-ARGS */V336));
T1013:;
	if((structure_ref((V333),VV[53],11))==Cnil){
	goto T1016;}
	(void)(structure_set((V334),VV[53],11,Ct));
T1016:;
	if(equalp((V334),(V333))){
	goto T1020;}
	(void)((VFUN_NARGS=2,(*(LnkLI144))(VV[100],(V335))));
	{object V337 = sputprop((V335),VV[53],(V334));
	VMR13(V337)}
T1020:;
	{object V338 = Cnil;
	VMR13(V338)}
}
/*	local entry for function FREEZE-DEFSTRUCT	*/

static object LI14(V340)

object V340;
{	 VMB14 VMS14 VMV14
TTL:;
	{object V341;
	base[0]= (V340);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk157)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T1024;}
	V341= Cnil;
	goto T1023;
T1024:;
	V341= get((V340),VV[53],Cnil);
T1023:;
	if(((V341))==Cnil){
	goto T1028;}
	{object V342 = structure_set((V341),VV[53],11,Ct);
	VMR14(V342)}
T1028:;
	{object V343 = Cnil;
	VMR14(V343)}}
}
/*	function definition for SHARP-S-READER	*/

static L15()
{register object *base=vs_base;
	register object *sup=base+VM15; VC15
	vs_reserve(VM15);
	{object V344;
	object V345;
	object V346;
	check_arg(3);
	V344=(base[0]);
	V345=(base[1]);
	V346=(base[2]);
	vs_top=sup;
TTL:;
	if(((V346))==Cnil){
	goto T1030;}
	if((symbol_value(VV[101]))!=Cnil){
	goto T1030;}
	base[3]= VV[102];
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk118)();
	vs_top=sup;
T1030:;
	{register object V347;
	register object V348;
	{object V349;
	base[5]= (V344);
	base[6]= Ct;
	base[7]= Cnil;
	base[8]= Ct;
	vs_top=(vs_base=base+5)+4;
	(void) (*Lnk164)();
	vs_top=sup;
	V349= vs_base[0];
	if((symbol_value(VV[101]))==Cnil){
	goto T1042;}
	base[5]= Cnil;
	vs_top=(vs_base=base+5)+1;
	return;
T1042:;
	V347= (V349);}{object V350;
	V350= get(car((V347)),VV[53],Cnil);
	if(V350==Cnil)goto T1046;
	V348= V350;
	goto T1045;
T1046:;}
	base[5]= VV[103];
	base[6]= car((V347));
	vs_top=(vs_base=base+5)+2;
	(void) (*Lnk118)();
	vs_top=sup;
	V348= vs_base[0];
T1045:;
	{register object V351;
	V351= cdr((V347));
T1052:;
	if(!(endp((V351)))){
	goto T1053;}
	{register object V352;
	V352= structure_ref((V348),VV[53],13);
T1058:;
	if(!(endp((V352)))){
	goto T1059;}
	base[5]= VV[104];
	base[6]= car((V347));
	vs_top=(vs_base=base+5)+2;
	(void) (*Lnk118)();
	return;
T1059:;
	if(!(type_of(car((V352)))==t_symbol)){
	goto T1065;}
	base[5]= car((V352));
	{object V353;
	V353= cdr((V347));
	 vs_top=base+6;
	 while(!endp(V353))
	 {vs_push(car(V353));V353=cdr(V353);}
	vs_base=base+6;}
	super_funcall_no_event(base[5]);
	return;
T1065:;
	V352= cdr((V352));
	goto T1058;}
T1053:;
	base[5]= coerce_to_string(car((V351)));
	base[6]= VV[105];
	vs_top=(vs_base=base+5)+2;
	(void) (*Lnk107)();
	vs_top=sup;
	V354= vs_base[0];
	if(type_of((V351))!=t_cons)FEwrong_type_argument(Scons,(V351));
	((V351))->c.c_car = V354;
	V351= cddr((V351));
	goto T1052;}}
	}
}
/*	local function CLOSURE	*/

static LC20(base0)
register object *base0;
{	register object *base=vs_base;
	register object *sup=base+VM16; VC16
	vs_reserve(VM16);
	{object V355;
	check_arg(1);
	V355=(base[0]);
	vs_top=sup;
	base[1]= (V355);
	base[2]= (base0[0]->c.c_car);
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk165)();
	return;
	}
}
/*	local function CLOSURE	*/

static LC19(base0)
register object *base0;
{	register object *base=vs_base;
	register object *sup=base+VM17; VC17
	vs_reserve(VM17);
	{object V356;
	check_arg(1);
	V356=(base[0]);
	vs_top=sup;
	if(!(type_of((V356))==t_cons)){
	goto T1084;}
	base[1]= car((V356));
	vs_top=(vs_base=base+1)+1;
	return;
T1084:;
	base[1]= Cnil;
	vs_top=(vs_base=base+1)+1;
	return;
	}
}
/*	local function CLOSURE	*/

static LC18(base0)
register object *base0;
{	register object *base=vs_base;
	register object *sup=base+VM18; VC18
	vs_reserve(VM18);
	{object V357;
	check_arg(1);
	V357=(base[0]);
	vs_top=sup;
	base[1]= aref1((V357),fixint((base0[0]->c.c_car)));
	vs_top=(vs_base=base+1)+1;
	return;
	}
}
/*	local function CLOSURE	*/

static LC17(base0)
register object *base0;
{	register object *base=vs_base;
	register object *sup=base+VM19; VC19
	vs_reserve(VM19);
	{object V358;
	check_arg(1);
	V358=(base[0]);
	vs_top=sup;
	base[1]= (base0[0]->c.c_car);
	base[2]= (V358);
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk166)();
	return;
	}
}
/*	local function CLOSURE	*/

static LC16(base0)
register object *base0;
{	register object *base=vs_base;
	register object *sup=base+VM20; VC20
	vs_reserve(VM20);
	{object V359;
	check_arg(1);
	V359=(base[0]);
	vs_top=sup;{object V360;
	base[1]= (V359);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk167)();
	vs_top=sup;
	V360= vs_base[0];
	if(V360==Cnil)goto T1089;
	goto T1088;
T1089:;}
	base[1]= VV[5];
	base[2]= (V359);
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk118)();
	vs_top=sup;
T1088:;
	base[1]= (V359);
	base[2]= (base0[0]->c.c_car);
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk168)();
	return;
	}
}
static LnkT168(){ call_or_link(VV[168],&Lnk168);} /* STRUCTURE-REF1 */
static LnkT167(){ call_or_link(VV[167],&Lnk167);} /* STRUCTUREP */
static LnkT166(){ call_or_link(VV[166],&Lnk166);} /* LIST-NTH */
static LnkT165(){ call_or_link(VV[165],&Lnk165);} /* STRUCTURE-SUBTYPE-P */
static LnkT164(){ call_or_link(VV[164],&Lnk164);} /* READ */
static LnkT18(){ call_or_link(VV[18],&Lnk18);} /* MAKE-STRUCTURE */
static LnkT160(){ call_or_link(VV[160],&Lnk160);} /* APPEND */
static object  LnkTLI159(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[159],&LnkLI159,5,ap);} /* MAKE-PREDICATE */
static object  LnkTLI158(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[158],&LnkLI158,5,ap);} /* MAKE-CONSTRUCTOR */
static LnkT20(){ call_or_link(VV[20],&Lnk20);} /* LIST */
static LnkT157(){ call_or_link(VV[157],&Lnk157);} /* SYMBOLP */
static LnkT156(){ call_or_link(VV[156],&Lnk156);} /* MAKE-LIST */
static object  LnkTLI155(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[155],&LnkLI155,2,ap);} /* PARSE-SLOT-DESCRIPTION */
static LnkT154(){ call_or_link(VV[154],&Lnk154);} /* NOT */
static object  LnkTLI148(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[148],&LnkLI148,3,ap);} /* CHECK-S-DATA */
static object  LnkTLI147(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[147],&LnkLI147,ap);} /* MAKE-S-DATA */
static object  LnkTLI146(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[146],&LnkLI146,3,ap);} /* GET-SLOT-POS */
static LnkT145(){ call_or_link(VV[145],&Lnk145);} /* ADJOIN */
static object  LnkTLI144(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[144],&LnkLI144,ap);} /* WARN */
static LnkT143(){ call_or_link(VV[143],&Lnk143);} /* MAKE-S-DATA-STRUCTURE */
static object  LnkTLI142(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[142],&LnkLI142,3,ap);} /* MAKE-T-TYPE */
static LnkT138(){ call_or_link(VV[138],&Lnk138);} /* MAKE-ACCESS-FUNCTION */
static LnkT137(){ call_or_link(VV[137],&Lnk137);} /* CONSP */
static LnkT136(){ call_or_link(VV[136],&Lnk136);} /* SIZE-OF */
static LnkT135(){ call_or_link(VV[135],&Lnk135);} /* EQL */
static int  LnkTLI134(va_alist)va_dcl{va_list ap;va_start(ap);return(int )call_proc(VV[134],&LnkLI134,20738,ap);} /* ROUND-UP */
static LnkT133(){ call_or_link(VV[133],&Lnk133);} /* < */
static object  LnkTLI132(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[132],&LnkLI132,2,ap);} /* COERCE */
static LnkT131(){ call_or_link(VV[131],&Lnk131);} /* SYMBOL-VALUE */
static LnkT130(){ call_or_link(VV[130],&Lnk130);} /* CONSTANTP */
static LnkT129(){ call_or_link(VV[129],&Lnk129);} /* TYPEP */
static LnkT128(){ call_or_link(VV[128],&Lnk128);} /* CEILING */
static LnkT127(){ call_or_link(VV[127],&Lnk127);} /* AET-TYPE */
static LnkT126(){ call_or_link(VV[126],&Lnk126);} /* ALIGNMENT */
static object  LnkTLI125(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[125],&LnkLI125,ap);} /* MAKE-ARRAY */
static object  LnkTLI124(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[124],&LnkLI124,2,ap);} /* OVERWRITE-SLOT-DESCRIPTIONS */
static object  LnkTLI123(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[123],&LnkLI123,1,ap);} /* NORMALIZE-TYPE */
static object  LnkTLI122(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[122],&LnkLI122,1,ap);} /* BEST-ARRAY-ELEMENT-TYPE */
static LnkT119(){ call_or_link(VV[119],&Lnk119);} /* NULL */
static LnkT118(){ call_or_link(VV[118],&Lnk118);} /* ERROR */
static LnkT117(){ call_or_link(VV[117],&Lnk117);} /* MEMBER */
static object  LnkTLI115(){return call_proc0(VV[115],&LnkLI115);} /* ILLEGAL-BOA */
static LnkT114(){ call_or_link(VV[114],&Lnk114);} /* NRECONC */
static LnkT113(){ call_or_link(VV[113],&Lnk113);} /* SUBTYPEP */
static LnkT112(){ call_or_link(VV[112],&Lnk112);} /* FSET */
static LnkT29(){ call_or_link(VV[29],&Lnk29);} /* EQ */
static LnkT111(){ call_or_link(VV[111],&Lnk111);} /* SYMBOL-FUNCTION */
static LnkT110(){ call_or_link(VV[110],&Lnk110);} /* FBOUNDP */
static LnkT109(){ call_or_link(VV[109],&Lnk109);} /* RECORD-FN */
static object  LnkTLI108(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[108],&LnkLI108,ap);} /* ADJUST-ARRAY */
static LnkT27(){ call_or_link(VV[27],&Lnk27);} /* > */
static LnkT107(){ call_or_link(VV[107],&Lnk107);} /* INTERN */
static LnkT106(){ call_or_link(VV[106],&Lnk106);} /* STRING-CONCATENATE */
