
#include <cmpinclude.h>
#include "cmptype.h"
init_cmptype(){do_init(VV);}
/*	local entry for function OBJECT-TYPE	*/

static object LI1(V2)

object V2;
{	 VMB1 VMS1 VMV1
TTL:;
	{object V3;
	base[0]= (V2);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk51)();
	vs_top=sup;
	V3= vs_base[0];
	{object V4= (V3);
	if((V4!= VV[10])
	&& (V4!= VV[12])
	&& (V4!= VV[3]))goto T3;
	{object V5 = (V3);
	VMR1(V5)}
T3:;
	if((V4!= VV[38])
	&& (V4!= VV[52])
	&& (V4!= VV[0]))goto T4;
	{object V6 = VV[0];
	VMR1(V6)}
T4:;
	if((V4!= VV[5])
	&& (V4!= VV[6]))goto T5;
	{object V7 = (V3);
	VMR1(V7)}
T5:;
	if((V4!= VV[1]))goto T6;
	base[0]= (V2);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk53)();
	vs_top=sup;
	V8= vs_base[0];
	{object V9 = list(2,VV[1],V8);
	VMR1(V9)}
T6:;
	if((V4!= VV[2]))goto T9;
	base[0]= (V2);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk53)();
	vs_top=sup;
	V10= vs_base[0];
	{object V11 = list(2,VV[2],V10);
	VMR1(V11)}
T9:;
	{object V12 = Ct;
	VMR1(V12)}}}
}
/*	local entry for function TYPE-FILTER	*/

static object LI2(V14)

object V14;
{	 VMB2 VMS2 VMV2
TTL:;
	{object V15= (V14);
	if((V15!= VV[10])
	&& (V15!= VV[0])
	&& (V15!= VV[12])
	&& (V15!= VV[3]))goto T12;
	{object V16 = (V14);
	VMR2(V16)}
T12:;
	if((V15!= VV[54]))goto T13;
	{object V17 = VV[3];
	VMR2(V17)}
T13:;
	if((V15!= VV[4]))goto T14;
	{object V18 = VV[4];
	VMR2(V18)}
T14:;
	if((V15!= VV[55]))goto T15;
	{object V19 = VV[3];
	VMR2(V19)}
T15:;
	if((V15!= VV[56])
	&& (V15!= VV[5]))goto T16;
	{object V20 = VV[5];
	VMR2(V20)}
T16:;
	if((V15!= VV[57])
	&& (V15!= VV[6]))goto T17;
	{object V21 = VV[6];
	VMR2(V21)}
T17:;
	if((V15!= Cnil)
	&& (V15!= Ct))goto T18;
	{object V22 = Ct;
	VMR2(V22)}
T18:;
	{register object V23;
	register object V24;
	V23= (*(LnkLI58))((V14));
	V24= Cnil;
	{object V25= car((V23));
	if((V25!= VV[59])
	&& (V25!= VV[2]))goto T20;
	if(endp(cdr((V23)))){
	goto T21;}
	if(!((VV[7])==(cadr((V23))))){
	goto T28;}
	V24= Cnil;
	goto T26;
T28:;
	{object V26;
	V26= (*(LnkLI60))(cadr((V23)));
	if(((V26))==Cnil){
	goto T32;}
	V24= (V26);
	goto T26;
T32:;
	V24= Ct;}
T26:;
	if(((V24))!=Cnil){
	goto T22;}
T21:;
	{object V27 = Ct;
	VMR2(V27)}
T22:;
	if(endp(cddr((V23)))){
	goto T35;}
	if((caddr((V23)))==(VV[7])){
	goto T35;}
	if(eql(caddr((V23)),small_fixnum(1))){
	goto T34;}
	if(!(type_of(caddr((V23)))==t_cons)){
	goto T35;}
	if(!((length(caddr((V23))))==(1))){
	goto T35;}
T34:;
	{object V28= (V24);
	if((V28!= VV[38]))goto T45;
	{object V29 = VV[5];
	VMR2(V29)}
T45:;
	if((V28!= VV[39]))goto T46;
	{object V30 = VV[6];
	VMR2(V30)}
T46:;
	{object V31 = list(2,VV[1],(V24));
	VMR2(V31)}}
T35:;
	{object V32 = list(2,VV[2],(V24));
	VMR2(V32)}
T20:;
	if((V25!= VV[11]))goto T47;
	V33= cdr((V23));
	V34= list(2,VV[8],VV[9]);
	if(((*(LnkLI61))(/* INLINE-ARGS */V33,/* INLINE-ARGS */V34))==Cnil){
	goto T49;}
	{object V35 = VV[10];
	VMR2(V35)}
T49:;
	{object V36 = VV[11];
	VMR2(V36)}
T47:;
	if((V25!= VV[12]))goto T51;
	{object V37 = VV[12];
	VMR2(V37)}
T51:;
	if((V25!= VV[3])
	&& (V25!= VV[55])
	&& (V25!= VV[54]))goto T52;
	{object V38 = VV[3];
	VMR2(V38)}
T52:;
	if((V25!= VV[13]))goto T53;
	{object V39 = VV[13];
	VMR2(V39)}
T53:;
	base[0]= (V23);
	base[1]= VV[10];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk62)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T55;}
	{object V40 = VV[10];
	VMR2(V40)}
T55:;
	base[0]= (V23);
	base[1]= VV[11];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk62)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T60;}
	{object V41 = VV[11];
	VMR2(V41)}
T60:;
	base[0]= (V23);
	base[1]= VV[0];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk62)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T65;}
	{object V42 = VV[0];
	VMR2(V42)}
T65:;
	base[0]= (V23);
	base[1]= VV[12];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk62)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T70;}
	{object V43 = VV[12];
	VMR2(V43)}
T70:;
	base[0]= (V23);
	base[1]= VV[3];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk62)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T75;}
	{object V44 = VV[3];
	VMR2(V44)}
T75:;
	base[0]= (V23);
	base[1]= VV[14];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk62)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T80;}
	{object V45 = VV[15];
	VMR2(V45)}
T80:;
	base[0]= (V23);
	base[1]= VV[5];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk62)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T85;}
	{object V46 = VV[5];
	VMR2(V46)}
T85:;
	base[0]= (V23);
	base[1]= VV[6];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk62)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T90;}
	{object V47 = VV[6];
	VMR2(V47)}
T90:;
	base[0]= (V23);
	base[1]= VV[16];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk62)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T95;}
	{object V48 = VV[17];
	VMR2(V48)}
T95:;
	base[0]= (V23);
	base[1]= VV[18];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk62)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T100;}
	{object V49 = VV[19];
	VMR2(V49)}
T100:;
	base[0]= (V23);
	base[1]= VV[20];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk62)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T105;}
	{object V50 = VV[21];
	VMR2(V50)}
T105:;
	base[0]= (V23);
	base[1]= VV[22];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk62)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T110;}
	{object V51 = VV[23];
	VMR2(V51)}
T110:;
	base[0]= (V23);
	base[1]= VV[24];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk62)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T115;}
	{object V52 = VV[25];
	VMR2(V52)}
T115:;
	base[0]= (V23);
	base[1]= VV[26];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk62)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T120;}
	{object V53 = VV[27];
	VMR2(V53)}
T120:;
	base[0]= (V23);
	base[1]= VV[28];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk62)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T125;}
	{object V54 = VV[29];
	VMR2(V54)}
T125:;
	base[0]= (V23);
	base[1]= VV[30];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk62)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T130;}
	{object V55 = VV[31];
	VMR2(V55)}
T130:;
	base[0]= (V23);
	base[1]= VV[32];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk62)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T135;}
	{object V56 = VV[33];
	VMR2(V56)}
T135:;
	if(!((car((V23)))==(VV[34]))){
	goto T140;}
	if((cddr((V23)))!=Cnil){
	goto T143;}
	{object V57 = list(2,VV[34],(*(LnkLI36))(cadr((V23))));
	VMR2(V57)}
T143:;
	{object V58 = Ct;
	VMR2(V58)}
T140:;
	{object V59;
	base[0]= car((V23));
	base[1]= VV[35];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk63)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T146;}
	V59= Cnil;
	goto T145;
T146:;
	base[0]= cadr((V23));
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk64)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T150;}
	V59= Cnil;
	goto T145;
T150:;
	V59= get(cadr((V23)),VV[36],Cnil);
T145:;
	if(((V59))==Cnil){
	goto T154;}
	{object V60 = (V59);
	VMR2(V60)}
T154:;
	{object V61 = Ct;
	VMR2(V61)}}}}}
}
/*	local entry for function TYPE-AND	*/

static object LI3(V64,V65)

register object V64;register object V65;
{	 VMB3 VMS3 VMV3
TTL:;
	if(!(equal((V64),(V65)))){
	goto T157;}
	{object V66 = (V64);
	VMR3(V66)}
T157:;
	if(!(((V64))==(Ct))){
	goto T160;}
	{object V67 = (V65);
	VMR3(V67)}
T160:;
	if(!(((V64))==(VV[7]))){
	goto T163;}
	{object V68 = (V65);
	VMR3(V68)}
T163:;
	if(!(((V64))==(VV[37]))){
	goto T166;}
	{object V69 = (V65);
	VMR3(V69)}
T166:;
	if(!(((V65))==(VV[37]))){
	goto T169;}
	{object V70 = (V64);
	VMR3(V70)}
T169:;
	if(!(((V65))==(Ct))){
	goto T172;}
	{object V71 = (V64);
	VMR3(V71)}
T172:;
	if(!(((V65))==(VV[7]))){
	goto T175;}
	{object V72 = (V64);
	VMR3(V72)}
T175:;
	if(!(type_of((V65))==t_cons)){
	goto T178;}
	if(!((car((V65)))==(VV[34]))){
	goto T178;}
	V65= cadr((V65));
	goto TTL;
T178:;
	if(!(type_of((V64))==t_cons)){
	goto T186;}
	{object V73= car((V64));
	if((V73!= VV[2]))goto T188;
	{object V74= cadr((V64));
	if((V74!= VV[38]))goto T189;
	if(!(((V65))==(VV[5]))){
	goto T191;}
	{object V75 = (V65);
	VMR3(V75)}
T191:;
	{object V76 = Cnil;
	VMR3(V76)}
T189:;
	if((V74!= VV[39]))goto T193;
	if(!(((V65))==(VV[6]))){
	goto T195;}
	{object V77 = (V65);
	VMR3(V77)}
T195:;
	{object V78 = Cnil;
	VMR3(V78)}
T193:;
	if(!(type_of((V65))==t_cons)){
	goto T198;}
	if(!((car((V65)))==(VV[1]))){
	goto T198;}
	if(!((cadr((V64)))==(cadr((V65))))){
	goto T198;}
	{object V79 = (V65);
	VMR3(V79)}
T198:;
	{object V80 = Cnil;
	VMR3(V80)}}
T188:;
	if((V73!= VV[1]))goto T204;
	if(!(type_of((V65))==t_cons)){
	goto T206;}
	if(!((car((V65)))==(VV[2]))){
	goto T206;}
	if(!((cadr((V64)))==(cadr((V65))))){
	goto T206;}
	{object V81 = (V64);
	VMR3(V81)}
T206:;
	{object V82 = Cnil;
	VMR3(V82)}
T204:;
	if((V73!= VV[34]))goto T212;
	V64= cadr((V64));
	goto TTL;
T212:;
	{object V83 = Cnil;
	VMR3(V83)}}
T186:;
	{object V84= (V64);
	if((V84!= VV[5]))goto T216;
	if(!(type_of((V65))==t_cons)){
	goto T218;}
	if(!((car((V65)))==(VV[2]))){
	goto T218;}
	if(!((cadr((V65)))==(VV[38]))){
	goto T218;}
	{object V85 = (V64);
	VMR3(V85)}
T218:;
	{object V86 = Cnil;
	VMR3(V86)}
T216:;
	if((V84!= VV[6]))goto T224;
	if(!(type_of((V65))==t_cons)){
	goto T226;}
	if(!((car((V65)))==(VV[2]))){
	goto T226;}
	if(!((cadr((V65)))==(VV[39]))){
	goto T226;}
	{object V87 = (V64);
	VMR3(V87)}
T226:;
	{object V88 = Cnil;
	VMR3(V88)}
T224:;
	if((V84!= VV[65]))goto T232;
	{register object x= (V65),V89= VV[40];
	while(!endp(V89))
	if(eql(x,V89->c.c_car)){
	goto T235;
	}else V89=V89->c.c_cdr;
	goto T234;}
T235:;
	{object V90 = (V65);
	VMR3(V90)}
T234:;
	{object V91 = Cnil;
	VMR3(V91)}
T232:;
	if((V84!= VV[66]))goto T236;
	{register object x= (V65),V92= VV[41];
	while(!endp(V92))
	if(eql(x,V92->c.c_car)){
	goto T239;
	}else V92=V92->c.c_cdr;
	goto T238;}
T239:;
	{object V93 = (V65);
	VMR3(V93)}
T238:;
	{object V94 = Cnil;
	VMR3(V94)}
T236:;
	if((V84!= VV[3])
	&& (V84!= VV[12]))goto T240;
	{register object x= (V65),V95= VV[42];
	while(!endp(V95))
	if(eql(x,V95->c.c_car)){
	goto T243;
	}else V95=V95->c.c_cdr;
	goto T242;}
T243:;
	{object V96 = (V64);
	VMR3(V96)}
T242:;
	{object V97 = Cnil;
	VMR3(V97)}
T240:;
	if((V84!= VV[67])
	&& (V84!= VV[68])
	&& (V84!= VV[69]))goto T244;
	if(!(((V65))==(VV[10]))){
	goto T246;}
	{object V98 = (V64);
	VMR3(V98)}
T246:;
	{object V99 = Cnil;
	VMR3(V99)}
T244:;
	if((V84!= VV[70]))goto T248;
	base[0]= (V64);
	base[1]= (V65);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk62)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T250;}
	{object V100 = (V64);
	VMR3(V100)}
T250:;
	{object V101 = Cnil;
	VMR3(V101)}
T248:;
	if((V84!= VV[11]))goto T254;
	{object V102= (V65);
	if((V102!= VV[10]))goto T255;
	{object V103 = (V65);
	VMR3(V103)}
T255:;
	{object V104 = Cnil;
	VMR3(V104)}}
T254:;
	if((V84!= VV[10]))goto T256;
	{object V105= (V65);
	if((V105!= VV[11])
	&& (V105!= VV[65]))goto T257;
	{object V106 = VV[10];
	VMR3(V106)}
T257:;
	if((V105!= VV[67])
	&& (V105!= VV[68])
	&& (V105!= VV[69])
	&& (V105!= VV[39]))goto T258;
	{object V107 = (V65);
	VMR3(V107)}
T258:;
	if((V105!= VV[70]))goto T259;
	base[0]= (V65);
	base[1]= (V64);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk62)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T261;}
	{object V108 = (V65);
	VMR3(V108)}
T261:;
	{object V109 = Cnil;
	VMR3(V109)}
T259:;
	{object V110 = Cnil;
	VMR3(V110)}}
T256:;
	{object V111 = Cnil;
	VMR3(V111)}}
}
/*	local entry for function TYPE>=	*/

static object LI4(V114,V115)

object V114;object V115;
{	 VMB4 VMS4 VMV4
TTL:;
	base[0]= (*(LnkLI71))((V114),(V115));
	base[1]= (V115);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk72)();
	vs_top=sup;
	{object V116 = vs_base[0];
	VMR4(V116)}
}
/*	local entry for function RESET-INFO-TYPE	*/

static object LI5(V118)

object V118;
{	 VMB5 VMS5 VMV5
TTL:;
	if((structure_ref((V118),VV[43],2))==Cnil){
	goto T268;}
	{object V119;
	base[0]= (V118);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk73)();
	vs_top=sup;
	V119= vs_base[0];
	(void)(structure_set((V119),VV[43],2,Ct));
	{object V120 = (V119);
	VMR5(V120)}}
T268:;
	{object V121 = (V118);
	VMR5(V121)}
}
/*	local entry for function AND-FORM-TYPE	*/

static object LI6(V125,V126,V127)

object V125;register object V126;object V127;
{	 VMB6 VMS6 VMV6
TTL:;
	{register object V128;
	V128= Cnil;
	V129= structure_ref(cadr((V126)),VV[43],2);
	V128= (*(LnkLI71))((V125),/* INLINE-ARGS */V129);
	if(((V128))!=Cnil){
	goto T276;}
	(void)((VFUN_NARGS=3,(*(LnkLI74))(VV[44],(V127),(V125))));
T276:;
	V130= structure_ref(cadr((V126)),VV[43],2);
	if(!(((V128))==(/* INLINE-ARGS */V130))){
	goto T280;}
	{object V131 = (V126);
	VMR6(V131)}
T280:;
	{object V132;
	base[0]= cadr((V126));
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk73)();
	vs_top=sup;
	V132= vs_base[0];
	(void)(structure_set((V132),VV[43],2,(V128)));
	{object V133 = listA(3,car((V126)),(V132),cddr((V126)));
	VMR6(V133)}}}
}
/*	local entry for function CHECK-FORM-TYPE	*/

static object LI7(V137,V138,V139)

object V137;object V138;object V139;
{	 VMB7 VMS7 VMV7
TTL:;
	V140= structure_ref(cadr((V138)),VV[43],2);
	if(((*(LnkLI71))((V137),/* INLINE-ARGS */V140))!=Cnil){
	goto T286;}
	{object V141 = (VFUN_NARGS=3,(*(LnkLI74))(VV[45],(V139),(V137)));
	VMR7(V141)}
T286:;
	{object V142 = Cnil;
	VMR7(V142)}
}
/*	local entry for function DEFAULT-INIT	*/

static object LI8(V144)

object V144;
{	 VMB8 VMS8 VMV8
TTL:;
	{object V145= (V144);
	if((V145!= VV[10]))goto T289;
	(void)((VFUN_NARGS=1,(*(LnkLI74))(VV[46])));
	goto T288;
T289:;
	if((V145!= VV[0]))goto T290;
	(void)((VFUN_NARGS=1,(*(LnkLI74))(VV[47])));
	goto T288;
T290:;
	if((V145!= VV[3]))goto T291;
	(void)((VFUN_NARGS=1,(*(LnkLI74))(VV[48])));
	goto T288;
T291:;
	if((V145!= VV[12]))goto T292;
	(void)((VFUN_NARGS=1,(*(LnkLI74))(VV[49])));
	goto T288;
T292:;
	if((V145!= VV[11]))goto T293;
	(void)((VFUN_NARGS=1,(*(LnkLI74))(VV[50])));
	goto T288;
T293:;}
T288:;
	{object V146 = (*(LnkLI75))();
	VMR8(V146)}
}
static object  LnkTLI75(){return call_proc0(VV[75],&LnkLI75);} /* C1NIL */
static object  LnkTLI74(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[74],&LnkLI74,ap);} /* CMPWARN */
static LnkT73(){ call_or_link(VV[73],&Lnk73);} /* COPY-INFO */
static LnkT72(){ call_or_link(VV[72],&Lnk72);} /* EQUAL */
static object  LnkTLI71(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[71],&LnkLI71,2,ap);} /* TYPE-AND */
static LnkT64(){ call_or_link(VV[64],&Lnk64);} /* SYMBOLP */
static LnkT63(){ call_or_link(VV[63],&Lnk63);} /* EQ */
static object  LnkTLI36(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[36],&LnkLI36,1,ap);} /* TYPE-FILTER */
static LnkT62(){ call_or_link(VV[62],&Lnk62);} /* SUBTYPEP */
static object  LnkTLI61(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[61],&LnkLI61,2,ap);} /* SUB-INTERVAL-P */
static object  LnkTLI60(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[60],&LnkLI60,1,ap);} /* BEST-ARRAY-ELEMENT-TYPE */
static object  LnkTLI58(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[58],&LnkLI58,1,ap);} /* NORMALIZE-TYPE */
static LnkT53(){ call_or_link(VV[53],&Lnk53);} /* ARRAY-ELEMENT-TYPE */
static LnkT51(){ call_or_link(VV[51],&Lnk51);} /* TYPE-OF */
