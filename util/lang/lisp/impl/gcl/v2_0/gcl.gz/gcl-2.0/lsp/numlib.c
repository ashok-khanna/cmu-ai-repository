
#include <cmpinclude.h>
#include "numlib.h"
init_numlib(){do_init(VV);}
/*	local entry for function ISQRT	*/

static object LI1(V2)

register object V2;
{	 VMB1 VMS1 VMV1
TTL:;
	if(!(type_of((V2))==t_fixnum||type_of((V2))==t_bignum)){
	goto T2;}
	if(number_compare((V2),small_fixnum(0))>=0){
	goto T1;}
T2:;
	base[0]= VV[0];
	base[1]= (V2);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk9)();
	vs_top=sup;
T1:;
	if(!(number_compare(small_fixnum(0),(V2))==0)){
	goto T9;}
	{object V3 = small_fixnum(0);
	VMR1(V3)}
T9:;
	{object V4;
	base[0]= (V2);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk10)();
	vs_top=sup;
	V4= vs_base[0];
	{register object V5;
	register object V6;
	base[0]= small_fixnum(1);
	base[2]= (V4);
	base[3]= small_fixnum(2);
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk11)();
	vs_top=sup;
	base[1]= vs_base[0];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk12)();
	vs_top=sup;
	V5= vs_base[0];
	V6= Cnil;
T19:;
	base[0]= (V2);
	base[1]= (V5);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk13)();
	vs_top=sup;
	V6= vs_base[0];
	if(!(number_compare((V5),(V6))<=0)){
	goto T26;}
	{object V7 = (V5);
	VMR1(V7)}
T26:;
	base[0]= number_plus((V5),(V6));
	base[1]= small_fixnum(2);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk13)();
	vs_top=sup;
	V5= vs_base[0];
	goto T19;}}
}
/*	local entry for function ABS	*/

static object LI2(V9)

register object V9;
{	 VMB2 VMS2 VMV2
TTL:;
	base[0]= (V9);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk14)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T36;}
	base[1]= (V9);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk15)();
	vs_top=sup;
	V10= vs_base[0];
	base[1]= (V9);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk15)();
	vs_top=sup;
	V11= vs_base[0];
	V12= number_times(V10,V11);
	base[1]= (V9);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk16)();
	vs_top=sup;
	V13= vs_base[0];
	base[1]= (V9);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk16)();
	vs_top=sup;
	V14= vs_base[0];
	V15= number_times(V13,V14);
	base[0]= number_plus(/* INLINE-ARGS */V12,/* INLINE-ARGS */V15);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk17)();
	vs_top=sup;
	{object V16 = vs_base[0];
	VMR2(V16)}
T36:;
	if(!(number_compare(small_fixnum(0),(V9))>0)){
	goto T49;}
	{object V17 = number_negate((V9));
	VMR2(V17)}
T49:;
	{object V18 = (V9);
	VMR2(V18)}
}
/*	local entry for function PHASE	*/

static object LI3(V20)

object V20;
{	 VMB3 VMS3 VMV3
TTL:;
	base[1]= (V20);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk16)();
	vs_top=sup;
	base[0]= vs_base[0];
	base[2]= (V20);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk15)();
	vs_top=sup;
	base[1]= vs_base[0];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk18)();
	vs_top=sup;
	{object V21 = vs_base[0];
	VMR3(V21)}
}
/*	local entry for function SIGNUM	*/

static object LI4(V23)

register object V23;
{	 VMB4 VMS4 VMV4
TTL:;
	if(!(number_compare(small_fixnum(0),(V23))==0)){
	goto T56;}
	{object V24 = (V23);
	VMR4(V24)}
T56:;
	base[0]= (V23);
	base[1]= (*(LnkLI19))((V23));
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk20)();
	vs_top=sup;
	{object V25 = vs_base[0];
	VMR4(V25)}
}
/*	local entry for function CIS	*/

static object LI5(V27)

object V27;
{	 VMB5 VMS5 VMV5
TTL:;
	base[0]= number_times(VV[1],(V27));
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk21)();
	vs_top=sup;
	{object V28 = vs_base[0];
	VMR5(V28)}
}
/*	local entry for function ASIN	*/

static object LI6(V30)

register object V30;
{	 VMB6 VMS6 VMV6
TTL:;
	{object V31;
	V33= number_times(VV[1],(V30));
	V35= number_times((V30),(V30));
	base[1]= number_minus(VV[2],/* INLINE-ARGS */V35);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk17)();
	vs_top=sup;
	V34= vs_base[0];
	base[0]= number_plus(/* INLINE-ARGS */V33,V34);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk22)();
	vs_top=sup;
	V32= vs_base[0];
	V36= number_times(VV[1],V32);
	V31= number_negate(/* INLINE-ARGS */V36);
	base[0]= (V30);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk14)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T68;}
	if(!(number_compare((V30),VV[2])<=0)){
	goto T68;}
	if(number_compare((V30),VV[3])>=0){
	goto T66;}
T68:;
	base[0]= (V31);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk16)();
	vs_top=sup;
	V37= vs_base[0];
	if(!(number_compare(small_fixnum(0),V37)==0)){
	goto T67;}
T66:;
	base[0]= (V31);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk15)();
	vs_top=sup;
	{object V38 = vs_base[0];
	VMR6(V38)}
T67:;
	{object V39 = (V31);
	VMR6(V39)}}
}
/*	local entry for function ACOS	*/

static object LI7(V41)

register object V41;
{	 VMB7 VMS7 VMV7
TTL:;
	{object V42;
	V45= number_times((V41),(V41));
	base[1]= number_minus(VV[2],/* INLINE-ARGS */V45);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk17)();
	vs_top=sup;
	V44= vs_base[0];
	V46= number_times(VV[1],V44);
	base[0]= number_plus((V41),/* INLINE-ARGS */V46);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk22)();
	vs_top=sup;
	V43= vs_base[0];
	V47= number_times(VV[1],V43);
	V42= number_negate(/* INLINE-ARGS */V47);
	base[0]= (V41);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk14)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T86;}
	if(!(number_compare((V41),VV[2])<=0)){
	goto T86;}
	if(number_compare((V41),VV[3])>=0){
	goto T84;}
T86:;
	base[0]= (V42);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk16)();
	vs_top=sup;
	V48= vs_base[0];
	if(!(number_compare(small_fixnum(0),V48)==0)){
	goto T85;}
T84:;
	base[0]= (V42);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk15)();
	vs_top=sup;
	{object V49 = vs_base[0];
	VMR7(V49)}
T85:;
	{object V50 = (V42);
	VMR7(V50)}}
}
/*	local entry for function SINH	*/

static object LI8(V52)

object V52;
{	 VMB8 VMS8 VMV8
TTL:;
	base[1]= (V52);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk21)();
	vs_top=sup;
	V53= vs_base[0];
	base[1]= number_negate((V52));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk21)();
	vs_top=sup;
	V54= vs_base[0];
	base[0]= number_minus(V53,V54);
	base[1]= VV[4];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk20)();
	vs_top=sup;
	{object V55 = vs_base[0];
	VMR8(V55)}
}
/*	local entry for function COSH	*/

static object LI9(V57)

object V57;
{	 VMB9 VMS9 VMV9
TTL:;
	base[1]= (V57);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk21)();
	vs_top=sup;
	V58= vs_base[0];
	base[1]= number_negate((V57));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk21)();
	vs_top=sup;
	V59= vs_base[0];
	base[0]= number_plus(V58,V59);
	base[1]= VV[4];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk20)();
	vs_top=sup;
	{object V60 = vs_base[0];
	VMR9(V60)}
}
/*	local entry for function TANH	*/

static object LI10(V62)

object V62;
{	 VMB10 VMS10 VMV10
TTL:;
	base[0]= (*(LnkLI23))((V62));
	base[1]= (*(LnkLI24))((V62));
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk20)();
	vs_top=sup;
	{object V63 = vs_base[0];
	VMR10(V63)}
}
/*	local entry for function ASINH	*/

static object LI11(V65)

object V65;
{	 VMB11 VMS11 VMV11
TTL:;
	V67= number_times((V65),(V65));
	base[1]= number_plus(VV[2],/* INLINE-ARGS */V67);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk17)();
	vs_top=sup;
	V66= vs_base[0];
	base[0]= number_plus((V65),V66);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk22)();
	vs_top=sup;
	{object V68 = vs_base[0];
	VMR11(V68)}
}
/*	local entry for function ACOSH	*/

static object LI12(V70)

register object V70;
{	 VMB12 VMS12 VMV12
TTL:;
	V71= one_plus((V70));
	base[2]= one_minus((V70));
	base[3]= one_plus((V70));
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk20)();
	vs_top=sup;
	base[1]= vs_base[0];
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk17)();
	vs_top=sup;
	V72= vs_base[0];
	V73= number_times(/* INLINE-ARGS */V71,V72);
	base[0]= number_plus((V70),/* INLINE-ARGS */V73);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk22)();
	vs_top=sup;
	{object V74 = vs_base[0];
	VMR12(V74)}
}
/*	local entry for function ATANH	*/

static object LI13(V76)

register object V76;
{	 VMB13 VMS13 VMV13
TTL:;
	if(number_compare((V76),VV[2])==0){
	goto T120;}
	if(!(number_compare((V76),VV[3])==0)){
	goto T119;}
T120:;
	base[0]= VV[5];
	base[1]= (V76);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk9)();
	vs_top=sup;
T119:;
	base[1]= one_plus((V76));
	V77= number_times((V76),(V76));
	base[3]= number_minus(VV[2],/* INLINE-ARGS */V77);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk17)();
	vs_top=sup;
	base[2]= vs_base[0];
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk20)();
	vs_top=sup;
	base[0]= vs_base[0];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk22)();
	vs_top=sup;
	{object V78 = vs_base[0];
	VMR13(V78)}
}
/*	local entry for function RATIONAL	*/

static object LI14(V80)

register object V80;
{	 VMB14 VMS14 VMV14
TTL:;
	{register object V81;
	V81= (V80);
	if(!(type_of((V81))==t_shortfloat||type_of((V81))==t_longfloat)){
	goto T131;}
	{object V82;
	object V83;
	object V84;
	base[0]= (V80);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk25)();
	if(vs_base>=vs_top){vs_top=sup;goto T135;}
	V82= vs_base[0];
	vs_base++;
	if(vs_base>=vs_top){vs_top=sup;goto T136;}
	V83= vs_base[0];
	vs_base++;
	if(vs_base>=vs_top){vs_top=sup;goto T137;}
	V84= vs_base[0];
	vs_top=sup;
	goto T138;
T135:;
	V82= Cnil;
T136:;
	V83= Cnil;
T137:;
	V84= Cnil;
T138:;
	if(!(number_compare((V84),small_fixnum(0))>=0)){
	goto T140;}
	base[0]= (V80);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk26)();
	vs_top=sup;
	V85= vs_base[0];
	V86= number_expt(V85,(V83));
	{object V87 = number_times((V82),/* INLINE-ARGS */V86);
	VMR14(V87)}
T140:;
	base[0]= (V80);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk26)();
	vs_top=sup;
	V88= vs_base[0];
	V89= number_expt(V88,(V83));
	V90= number_times((V82),/* INLINE-ARGS */V89);
	{object V91 = number_negate(/* INLINE-ARGS */V90);
	VMR14(V91)}}
T131:;
	base[0]= (V81);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk27)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T147;}
	{object V92 = (V80);
	VMR14(V92)}
T147:;
	base[0]= (*(LnkLI28))(VV[6],(V81),VV[7]);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk9)();
	vs_top=sup;
	{object V93 = vs_base[0];
	VMR14(V93)}}
}
/*	function definition for FFLOOR	*/

static L15()
{register object *base=vs_base;
	register object *sup=base+VM15; VC15
	vs_reserve(VM15);
	{object V94;
	object V95;
	if(vs_top-vs_base<1) too_few_arguments();
	if(vs_top-vs_base>2) too_many_arguments();
	V94=(base[0]);
	vs_base=vs_base+1;
	if(vs_base>=vs_top){vs_top=sup;goto T151;}
	V95=(base[1]);
	vs_top=sup;
	goto T152;
T151:;
	V95= VV[8];
T152:;
	{object V96;
	object V97;
	base[3]= (V94);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk29)();
	vs_top=sup;
	base[2]= vs_base[0];
	base[4]= (V95);
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk29)();
	vs_top=sup;
	base[3]= vs_base[0];
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk13)();
	if(vs_base>=vs_top){vs_top=sup;goto T159;}
	V96= vs_base[0];
	vs_base++;
	if(vs_base>=vs_top){vs_top=sup;goto T160;}
	V97= vs_base[0];
	vs_top=sup;
	goto T161;
T159:;
	V96= Cnil;
T160:;
	V97= Cnil;
T161:;
	base[3]= (V96);
	base[4]= (V97);
	vs_top=(vs_base=base+3)+2;
	(void) (*Lnk29)();
	vs_top=sup;
	base[2]= vs_base[0];
	base[3]= (V97);
	vs_top=(vs_base=base+2)+2;
	return;}
	}
}
/*	function definition for FCEILING	*/

static L16()
{register object *base=vs_base;
	register object *sup=base+VM16; VC16
	vs_reserve(VM16);
	{object V98;
	object V99;
	if(vs_top-vs_base<1) too_few_arguments();
	if(vs_top-vs_base>2) too_many_arguments();
	V98=(base[0]);
	vs_base=vs_base+1;
	if(vs_base>=vs_top){vs_top=sup;goto T166;}
	V99=(base[1]);
	vs_top=sup;
	goto T167;
T166:;
	V99= VV[8];
T167:;
	{object V100;
	object V101;
	base[3]= (V98);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk29)();
	vs_top=sup;
	base[2]= vs_base[0];
	base[4]= (V99);
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk29)();
	vs_top=sup;
	base[3]= vs_base[0];
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk11)();
	if(vs_base>=vs_top){vs_top=sup;goto T174;}
	V100= vs_base[0];
	vs_base++;
	if(vs_base>=vs_top){vs_top=sup;goto T175;}
	V101= vs_base[0];
	vs_top=sup;
	goto T176;
T174:;
	V100= Cnil;
T175:;
	V101= Cnil;
T176:;
	base[3]= (V100);
	base[4]= (V101);
	vs_top=(vs_base=base+3)+2;
	(void) (*Lnk29)();
	vs_top=sup;
	base[2]= vs_base[0];
	base[3]= (V101);
	vs_top=(vs_base=base+2)+2;
	return;}
	}
}
/*	function definition for FTRUNCATE	*/

static L17()
{register object *base=vs_base;
	register object *sup=base+VM17; VC17
	vs_reserve(VM17);
	{object V102;
	object V103;
	if(vs_top-vs_base<1) too_few_arguments();
	if(vs_top-vs_base>2) too_many_arguments();
	V102=(base[0]);
	vs_base=vs_base+1;
	if(vs_base>=vs_top){vs_top=sup;goto T181;}
	V103=(base[1]);
	vs_top=sup;
	goto T182;
T181:;
	V103= VV[8];
T182:;
	{object V104;
	object V105;
	base[3]= (V102);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk29)();
	vs_top=sup;
	base[2]= vs_base[0];
	base[4]= (V103);
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk29)();
	vs_top=sup;
	base[3]= vs_base[0];
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk30)();
	if(vs_base>=vs_top){vs_top=sup;goto T189;}
	V104= vs_base[0];
	vs_base++;
	if(vs_base>=vs_top){vs_top=sup;goto T190;}
	V105= vs_base[0];
	vs_top=sup;
	goto T191;
T189:;
	V104= Cnil;
T190:;
	V105= Cnil;
T191:;
	base[3]= (V104);
	base[4]= (V105);
	vs_top=(vs_base=base+3)+2;
	(void) (*Lnk29)();
	vs_top=sup;
	base[2]= vs_base[0];
	base[3]= (V105);
	vs_top=(vs_base=base+2)+2;
	return;}
	}
}
/*	function definition for FROUND	*/

static L18()
{register object *base=vs_base;
	register object *sup=base+VM18; VC18
	vs_reserve(VM18);
	{object V106;
	object V107;
	if(vs_top-vs_base<1) too_few_arguments();
	if(vs_top-vs_base>2) too_many_arguments();
	V106=(base[0]);
	vs_base=vs_base+1;
	if(vs_base>=vs_top){vs_top=sup;goto T196;}
	V107=(base[1]);
	vs_top=sup;
	goto T197;
T196:;
	V107= VV[8];
T197:;
	{object V108;
	object V109;
	base[3]= (V106);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk29)();
	vs_top=sup;
	base[2]= vs_base[0];
	base[4]= (V107);
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk29)();
	vs_top=sup;
	base[3]= vs_base[0];
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk31)();
	if(vs_base>=vs_top){vs_top=sup;goto T204;}
	V108= vs_base[0];
	vs_base++;
	if(vs_base>=vs_top){vs_top=sup;goto T205;}
	V109= vs_base[0];
	vs_top=sup;
	goto T206;
T204:;
	V108= Cnil;
T205:;
	V109= Cnil;
T206:;
	base[3]= (V108);
	base[4]= (V109);
	vs_top=(vs_base=base+3)+2;
	(void) (*Lnk29)();
	vs_top=sup;
	base[2]= vs_base[0];
	base[3]= (V109);
	vs_top=(vs_base=base+2)+2;
	return;}
	}
}
/*	local entry for function LOGNAND	*/

static object LI19(V112,V113)

object V112;object V113;
{	 VMB19 VMS19 VMV19
TTL:;
	base[0]= small_fixnum(14);
	base[1]= (V112);
	base[2]= (V113);
	vs_top=(vs_base=base+0)+3;
	(void) (*Lnk32)();
	vs_top=sup;
	{object V114 = vs_base[0];
	VMR19(V114)}
}
/*	local entry for function LOGNOR	*/

static object LI20(V117,V118)

object V117;object V118;
{	 VMB20 VMS20 VMV20
TTL:;
	base[0]= small_fixnum(8);
	base[1]= (V117);
	base[2]= (V118);
	vs_top=(vs_base=base+0)+3;
	(void) (*Lnk32)();
	vs_top=sup;
	{object V119 = vs_base[0];
	VMR20(V119)}
}
/*	local entry for function LOGANDC1	*/

static object LI21(V122,V123)

object V122;object V123;
{	 VMB21 VMS21 VMV21
TTL:;
	base[0]= small_fixnum(4);
	base[1]= (V122);
	base[2]= (V123);
	vs_top=(vs_base=base+0)+3;
	(void) (*Lnk32)();
	vs_top=sup;
	{object V124 = vs_base[0];
	VMR21(V124)}
}
/*	local entry for function LOGANDC2	*/

static object LI22(V127,V128)

object V127;object V128;
{	 VMB22 VMS22 VMV22
TTL:;
	base[0]= small_fixnum(2);
	base[1]= (V127);
	base[2]= (V128);
	vs_top=(vs_base=base+0)+3;
	(void) (*Lnk32)();
	vs_top=sup;
	{object V129 = vs_base[0];
	VMR22(V129)}
}
/*	local entry for function LOGORC1	*/

static object LI23(V132,V133)

object V132;object V133;
{	 VMB23 VMS23 VMV23
TTL:;
	base[0]= small_fixnum(13);
	base[1]= (V132);
	base[2]= (V133);
	vs_top=(vs_base=base+0)+3;
	(void) (*Lnk32)();
	vs_top=sup;
	{object V134 = vs_base[0];
	VMR23(V134)}
}
/*	local entry for function LOGORC2	*/

static object LI24(V137,V138)

object V137;object V138;
{	 VMB24 VMS24 VMV24
TTL:;
	base[0]= small_fixnum(11);
	base[1]= (V137);
	base[2]= (V138);
	vs_top=(vs_base=base+0)+3;
	(void) (*Lnk32)();
	vs_top=sup;
	{object V139 = vs_base[0];
	VMR24(V139)}
}
/*	local entry for function LOGNOT	*/

static object LI25(V141)

object V141;
{	 VMB25 VMS25 VMV25
TTL:;
	base[0]= small_fixnum(-1);
	base[1]= (V141);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk33)();
	vs_top=sup;
	{object V142 = vs_base[0];
	VMR25(V142)}
}
/*	local entry for function LOGTEST	*/

static object LI26(V145,V146)

object V145;object V146;
{	 VMB26 VMS26 VMV26
TTL:;
	base[2]= (V145);
	base[3]= (V146);
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk34)();
	vs_top=sup;
	base[1]= vs_base[0];
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk35)();
	vs_top=sup;
	base[0]= vs_base[0];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk36)();
	vs_top=sup;
	{object V147 = vs_base[0];
	VMR26(V147)}
}
/*	local entry for function BYTE	*/

static object LI27(V150,V151)

object V150;object V151;
{	 VMB27 VMS27 VMV27
TTL:;
	{object V152 = make_cons((V150),(V151));
	VMR27(V152)}
}
/*	local entry for function BYTE-SIZE	*/

static object LI28(V154)

object V154;
{	 VMB28 VMS28 VMV28
TTL:;
	{object V155 = car((V154));
	VMR28(V155)}
}
/*	local entry for function BYTE-POSITION	*/

static object LI29(V157)

object V157;
{	 VMB29 VMS29 VMV29
TTL:;
	{object V158 = cdr((V157));
	VMR29(V158)}
}
/*	local entry for function LDB	*/

static object LI30(V161,V162)

object V161;object V162;
{	 VMB30 VMS30 VMV30
TTL:;
	base[0]= (V162);
	V164= (*(LnkLI38))((V161));
	base[1]= number_negate(/* INLINE-ARGS */V164);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk12)();
	vs_top=sup;
	V163= vs_base[0];
	base[0]= small_fixnum(1);
	base[1]= (*(LnkLI39))((V161));
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk12)();
	vs_top=sup;
	V165= vs_base[0];
	V166= number_negate(V165);
	{object V167 = (*(LnkLI37))(V163,/* INLINE-ARGS */V166);
	VMR30(V167)}
}
/*	local entry for function LDB-TEST	*/

static object LI31(V170,V171)

object V170;object V171;
{	 VMB31 VMS31 VMV31
TTL:;
	base[1]= (*(LnkLI40))((V170),(V171));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk35)();
	vs_top=sup;
	base[0]= vs_base[0];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk36)();
	vs_top=sup;
	{object V172 = vs_base[0];
	VMR31(V172)}
}
/*	local entry for function MASK-FIELD	*/

static object LI32(V175,V176)

object V175;object V176;
{	 VMB32 VMS32 VMV32
TTL:;
	base[0]= (*(LnkLI40))((V175),(V176));
	base[1]= (*(LnkLI38))((V175));
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk12)();
	vs_top=sup;
	{object V177 = vs_base[0];
	VMR32(V177)}
}
/*	local entry for function DPB	*/

static object LI33(V181,V182,V183)

object V181;object V182;object V183;
{	 VMB33 VMS33 VMV33
TTL:;
	base[0]= (V183);
	base[1]= (*(LnkLI41))((V182),(V183));
	base[4]= small_fixnum(1);
	base[5]= (*(LnkLI39))((V182));
	vs_top=(vs_base=base+4)+2;
	(void) (*Lnk12)();
	vs_top=sup;
	V184= vs_base[0];
	V185= number_negate(V184);
	base[3]= (*(LnkLI37))((V181),/* INLINE-ARGS */V185);
	base[4]= (*(LnkLI38))((V182));
	vs_top=(vs_base=base+3)+2;
	(void) (*Lnk12)();
	vs_top=sup;
	base[2]= vs_base[0];
	vs_top=(vs_base=base+0)+3;
	(void) (*Lnk33)();
	vs_top=sup;
	{object V186 = vs_base[0];
	VMR33(V186)}
}
/*	local entry for function DEPOSIT-FIELD	*/

static object LI34(V190,V191,V192)

object V190;object V191;object V192;
{	 VMB34 VMS34 VMV34
TTL:;
	base[0]= (V190);
	V194= (*(LnkLI38))((V191));
	base[1]= number_negate(/* INLINE-ARGS */V194);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk12)();
	vs_top=sup;
	V193= vs_base[0];
	{object V195 = (*(LnkLI42))(V193,(V191),(V192));
	VMR34(V195)}
}
static object  LnkTLI42(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[42],&LnkLI42,3,ap);} /* DPB */
static object  LnkTLI41(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[41],&LnkLI41,2,ap);} /* MASK-FIELD */
static object  LnkTLI40(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[40],&LnkLI40,2,ap);} /* LDB */
static object  LnkTLI39(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[39],&LnkLI39,1,ap);} /* BYTE-SIZE */
static object  LnkTLI38(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[38],&LnkLI38,1,ap);} /* BYTE-POSITION */
static object  LnkTLI37(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[37],&LnkLI37,2,ap);} /* LOGANDC2 */
static LnkT36(){ call_or_link(VV[36],&Lnk36);} /* NOT */
static LnkT35(){ call_or_link(VV[35],&Lnk35);} /* ZEROP */
static LnkT34(){ call_or_link(VV[34],&Lnk34);} /* LOGAND */
static LnkT33(){ call_or_link(VV[33],&Lnk33);} /* LOGXOR */
static LnkT32(){ call_or_link(VV[32],&Lnk32);} /* BOOLE3 */
static LnkT31(){ call_or_link(VV[31],&Lnk31);} /* ROUND */
static LnkT30(){ call_or_link(VV[30],&Lnk30);} /* TRUNCATE */
static LnkT29(){ call_or_link(VV[29],&Lnk29);} /* FLOAT */
static object  LnkTLI28(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[28],&LnkLI28,3,ap);} /* TYPECASE-ERROR-STRING */
static LnkT27(){ call_or_link(VV[27],&Lnk27);} /* RATIONALP */
static LnkT26(){ call_or_link(VV[26],&Lnk26);} /* FLOAT-RADIX */
static LnkT25(){ call_or_link(VV[25],&Lnk25);} /* INTEGER-DECODE-FLOAT */
static object  LnkTLI24(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[24],&LnkLI24,1,ap);} /* COSH */
static object  LnkTLI23(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[23],&LnkLI23,1,ap);} /* SINH */
static LnkT22(){ call_or_link(VV[22],&Lnk22);} /* LOG */
static LnkT21(){ call_or_link(VV[21],&Lnk21);} /* EXP */
static LnkT20(){ call_or_link(VV[20],&Lnk20);} /*  */
static object  LnkTLI19(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[19],&LnkLI19,1,ap);} /* ABS */
static LnkT18(){ call_or_link(VV[18],&Lnk18);} /* ATAN */
static LnkT17(){ call_or_link(VV[17],&Lnk17);} /* SQRT */
static LnkT16(){ call_or_link(VV[16],&Lnk16);} /* IMAGPART */
static LnkT15(){ call_or_link(VV[15],&Lnk15);} /* REALPART */
static LnkT14(){ call_or_link(VV[14],&Lnk14);} /* COMPLEXP */
static LnkT13(){ call_or_link(VV[13],&Lnk13);} /* FLOOR */
static LnkT12(){ call_or_link(VV[12],&Lnk12);} /* ASH */
static LnkT11(){ call_or_link(VV[11],&Lnk11);} /* CEILING */
static LnkT10(){ call_or_link(VV[10],&Lnk10);} /* INTEGER-LENGTH */
static LnkT9(){ call_or_link(VV[9],&Lnk9);} /* ERROR */
