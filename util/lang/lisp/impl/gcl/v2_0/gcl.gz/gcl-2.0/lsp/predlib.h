
static L1();
static L2();
static L3();
static L4();
static L5();
static L6();
static L7();
static L8();
static L9();
static L10();
static L11();
static L12();
static L13();
static L14();
static L15();
static L16();
static L18();
static L21();
static L26();
#define VC1 object  V14 ,V13 ,V12 ,V11 ,V10 ,V9 ,V8 ,V6;
#define VC2
#define VC3
#define VC4
#define VC5 object  V21 ,V20 ,V19 ,V18 ,V17;
#define VC6 object  V23;
#define VC7
#define VC8
#define VC9
#define VC10
#define VC11
#define VC12
#define VC13
#define VC14
#define VC15
#define VC16
static object LI17();
#define VMB17 register object *base=vs_top; object  V38 ,V36 ,V34;
#define VMS17  register object *sup=vs_top+1;vs_top=sup;
#define VMV17 vs_reserve(1);
#define VMR17(VMT17) vs_top=base ; return(VMT17);
#define VC18 object  V66 ,V65 ,V64 ,V63 ,V62 ,V61 ,V60 ,V59 ,V58 ,V57 ,V56 ,V55 ,V54 ,V53 ,V52 ,V51 ,V48;
static object LI19();
#define VMB19 register object *base=vs_top;
#define VMS19  register object *sup=vs_top+1;vs_top=sup;
#define VMV19 vs_reserve(1);
#define VMR19(VMT19) vs_top=base ; return(VMT19);
static object LI20();
#define VMB20
#define VMS20
#define VMV20
#define VMR20(VMT20) return(VMT20);
#define VC21
static object LI22();
#define VMB22
#define VMS22
#define VMV22
#define VMR22(VMT22) return(VMT22);
static object LI23();
#define VMB23
#define VMS23
#define VMV23
#define VMR23(VMT23) return(VMT23);
static object LI24();
#define VMB24
#define VMS24
#define VMV24
#define VMR24(VMT24) return(VMT24);
static object LI25();
#define VMB25 register object *base=vs_top; object  V190 ,V189 ,V183 ,V181 ,V177 ,V175;
#define VMS25  register object *sup=vs_top+3;vs_top=sup;
#define VMV25 vs_reserve(3);
#define VMR25(VMT25) vs_top=base ; return(VMT25);
#define VC26
#define VM26 6
#define VM25 3
#define VM24 0
#define VM23 0
#define VM22 0
#define VM21 5
#define VM20 0
#define VM19 1
#define VM18 4
#define VM17 1
#define VM16 2
#define VM15 2
#define VM14 2
#define VM13 2
#define VM12 2
#define VM11 3
#define VM10 1
#define VM9 1
#define VM8 1
#define VM7 1
#define VM6 2
#define VM5 2
#define VM4 2
#define VM3 1
#define VM2 1
#define VM1 7
static char * VVi[101]={
#define Cdata VV[100]
(char *)(L1),
(char *)(L2),
(char *)(L3),
(char *)(L4),
(char *)(L5),
(char *)(L6),
(char *)(L7),
(char *)(L8),
(char *)(L9),
(char *)(L10),
(char *)(L11),
(char *)(L12),
(char *)(L13),
(char *)(L14),
(char *)(L15),
(char *)(L16),
(char *)(LI17),
(char *)(L18),
(char *)(LI19),
(char *)(LI20),
(char *)(L21),
(char *)(LI22),
(char *)(LI23),
(char *)(LI24),
(char *)(LI25),
(char *)(L26)
};
#define VV ((object *)VVi)
static object  LnkTLI99() ;
static object  (*LnkLI99)() = LnkTLI99;
static object  LnkTLI97() ;
static object  (*LnkLI97)() = LnkTLI97;
static object  LnkTLI96() ;
static object  (*LnkLI96)() = LnkTLI96;
static object  LnkTLI95() ;
static object  (*LnkLI95)() = LnkTLI95;
static  LnkT94() ;
static  (*Lnk94)() = LnkT94;
static object  LnkTLI93() ;
static object  (*LnkLI93)() = LnkTLI93;
static  LnkT92() ;
static  (*Lnk92)() = LnkT92;
static object  LnkTLI91() ;
static object  (*LnkLI91)() = LnkTLI91;
static object  LnkTLI90() ;
static object  (*LnkLI90)() = LnkTLI90;
static object  LnkTLI85() ;
static object  (*LnkLI85)() = LnkTLI85;
static object  LnkTLI84() ;
static object  (*LnkLI84)() = LnkTLI84;
static  LnkT80() ;
static  (*Lnk80)() = LnkT80;
static object  LnkTLI79() ;
static object  (*LnkLI79)() = LnkTLI79;
static  LnkT76() ;
static  (*Lnk76)() = LnkT76;
static  LnkT75() ;
static  (*Lnk75)() = LnkT75;
static object  LnkTLI74() ;
static object  (*LnkLI74)() = LnkTLI74;
