
#include <cmpinclude.h>
#include "cmpmulti.h"
init_cmpmulti(){do_init(VV);}
/*	local entry for function C1MULTIPLE-VALUE-CALL	*/

static object LI1(V2)

register object V2;
{	 VMB1 VMS1 VMV1
TTL:;
	{object V3;
	object V4;
	V3= Cnil;
	V4= Cnil;
	if(!(endp((V2)))){
	goto T3;}
	(void)((*(LnkLI38))(VV[0],small_fixnum(1),small_fixnum(0)));
T3:;
	if(!(endp(cdr((V2))))){
	goto T7;}
	{object V5 = (*(LnkLI39))((V2));
	VMR1(V5)}
T7:;
	V4= (*(LnkLI40))(car((V2)));
	base[0]= cadr((V4));
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk41)();
	vs_top=sup;
	V3= vs_base[0];
	V2= (*(LnkLI42))(cdr((V2)),(V3));
	{object V6 = list(4,VV[0],(V3),(V4),(V2));
	VMR1(V6)}}
}
/*	local entry for function C2MULTIPLE-VALUE-CALL	*/

static object LI2(V9,V10)

register object V9;object V10;
{	 VMB2 VMS2 VMV2
	bds_check;
TTL:;
	{register object V11;
	register object V12;
	bds_bind(VV[1],symbol_value(VV[1]));
	V11= Cnil;
	V12= Cnil;
	if(!(endp(cdr((V10))))){
	goto T19;}
	V11= (*(LnkLI43))((V9));
	bds_bind(VV[2],VV[3]);
	V13= (*(LnkLI44))(car((V10)));
	bds_unwind1;
	{object V14 = (VFUN_NARGS=3,(*(LnkLI45))((V9),VV[4],(V11)));
	bds_unwind1;
	VMR2(V14)}
T19:;
	setq(VV[5],number_plus(symbol_value(VV[5]),small_fixnum(1)));
	V12= symbol_value(VV[5]);
	V11= (*(LnkLI43))((V9));
	princ_str("\n	{object *V",VV[6]);
	(void)((*(LnkLI46))((V12)));
	princ_str("=base+",VV[6]);
	(void)((*(LnkLI46))((VV[1]->s.s_dbind)));
	princ_char(59,VV[6]);
	setq(VV[7],Ct);
	{register object V15;
	register object V16;
	V15= (V10);
	V16= car((V15));
T41:;
	if(!(endp((V15)))){
	goto T42;}
	goto T37;
T42:;
	bds_bind(VV[2],VV[3]);
	V17= (*(LnkLI47))((V16),(V12));
	bds_unwind1;
	princ_str("\n	while(vs_base<vs_top)",VV[6]);
	princ_str("\n	{V",VV[6]);
	(void)((*(LnkLI46))((V12)));
	princ_str("[0]=vs_base[0];V",VV[6]);
	(void)((*(LnkLI46))((V12)));
	princ_str("++;vs_base++;}",VV[6]);
	V15= cdr((V15));
	V16= car((V15));
	goto T41;}
T37:;
	princ_str("\n	vs_base=base+",VV[6]);
	(void)((*(LnkLI46))((VV[1]->s.s_dbind)));
	princ_str(";vs_top=V",VV[6]);
	(void)((*(LnkLI46))((V12)));
	princ_char(59,VV[6]);
	setq(VV[7],Ct);
	(void)((VFUN_NARGS=3,(*(LnkLI45))((V9),VV[4],(V11))));
	princ_char(125,VV[6]);
	{object V18 = Cnil;
	bds_unwind1;
	VMR2(V18)}}
}
/*	local entry for function C1MULTIPLE-VALUE-PROG1	*/

static object LI3(V20)

register object V20;
{	 VMB3 VMS3 VMV3
TTL:;
	{object V21;
	object V22;
	V21= (VFUN_NARGS=0,(*(LnkLI48))());
	V22= Cnil;
	if(!(endp((V20)))){
	goto T72;}
	(void)((*(LnkLI38))(VV[8],small_fixnum(1),small_fixnum(0)));
T72:;
	V22= (*(LnkLI49))(car((V20)),(V21));
	V20= (*(LnkLI42))(cdr((V20)),(V21));
	{object V23 = list(4,VV[8],(V21),(V22),(V20));
	VMR3(V23)}}
}
/*	local entry for function C2MULTIPLE-VALUE-PROG1	*/

static object LI4(V26,V27)

object V26;object V27;
{	 VMB4 VMS4 VMV4
	bds_check;
TTL:;
	{object V28;
	register object V29;
	object V30;
	setq(VV[5],number_plus(symbol_value(VV[5]),small_fixnum(1)));
	V28= symbol_value(VV[5]);
	setq(VV[5],number_plus(symbol_value(VV[5]),small_fixnum(1)));
	V29= symbol_value(VV[5]);
	V30= Cnil;
	bds_bind(VV[2],VV[3]);
	bds_bind(VV[9],Cnil);
	(void)((*(LnkLI44))((V26)));
	V30= (VV[9]->s.s_dbind);
	bds_unwind1;
	bds_unwind1;
	princ_str("\n	{object *V",VV[6]);
	(void)((*(LnkLI46))((V29)));
	princ_str("=vs_top;object *V",VV[6]);
	(void)((*(LnkLI46))((V28)));
	princ_str("=vs_base; vs_base=V",VV[6]);
	(void)((*(LnkLI46))((V29)));
	princ_char(59,VV[6]);
	{register object V31;
	register object V32;
	V31= (V27);
	V32= car((V31));
T99:;
	if(!(endp((V31)))){
	goto T100;}
	goto T95;
T100:;
	bds_bind(VV[2],VV[10]);
	V33= (*(LnkLI47))((V32),(V29));
	bds_unwind1;
	V31= cdr((V31));
	V32= car((V31));
	goto T99;}
T95:;
	princ_str("\n	vs_base=V",VV[6]);
	(void)((*(LnkLI46))((V28)));
	princ_str(";vs_top=V",VV[6]);
	(void)((*(LnkLI46))((V29)));
	princ_str(";}",VV[6]);
	if(((V30))==Cnil){
	goto T118;}
	V34= car((V30));
	goto T116;
T118:;
	V34= Cnil;
T116:;
	{object V35 = (VFUN_NARGS=3,(*(LnkLI50))(VV[11],Cnil,V34));
	VMR4(V35)}}
}
/*	local entry for function C1VALUES	*/

static object LI5(V37)

register object V37;
{	 VMB5 VMS5 VMV5
TTL:;
	{object V38;
	V38= (VFUN_NARGS=0,(*(LnkLI48))());
	if(((V37))==Cnil){
	goto T122;}
	if((cdr((V37)))!=Cnil){
	goto T122;}
	if(!(type_of(car((V37)))==t_cons)){
	goto T121;}
	if(!(type_of(caar((V37)))==t_symbol)){
	goto T122;}
	{register object V39;
	V39= (*(LnkLI51))(caar((V37)));
	if((V39)==Cnil){
	goto T122;}{object V40;
	base[1]= (V39);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk52)();
	vs_top=sup;
	V40= vs_base[0];
	if(V40==Cnil)goto T133;
	if((V40)==Cnil){
	goto T122;}
	goto T131;
T133:;}
	base[1]= (V39);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk53)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T136;}
	goto T122;
T136:;
	base[1]= cdr((V39));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk54)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T139;}
	goto T122;
T139:;
	base[2]= VV[12];
	base[3]= car((V39));
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk55)();
	vs_top=sup;
	base[1]= vs_base[0];
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk56)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T122;}}
T131:;
T121:;
	{object V41 = (*(LnkLI57))(car((V37)));
	VMR5(V41)}
T122:;
	V37= (*(LnkLI42))((V37),(V38));
	{object V42 = list(3,VV[13],(V38),(V37));
	VMR5(V42)}}
}
/*	local entry for function C2VALUES	*/

static object LI6(V44)

register object V44;
{	 VMB6 VMS6 VMV6
	bds_check;
TTL:;
	{object V45;
	V45= symbol_value(VV[1]);
	bds_bind(VV[1],symbol_value(VV[1]));
	if(!((symbol_value(VV[2]))==(VV[14]))){
	goto T148;}
	if((cdr((V44)))==Cnil){
	goto T148;}
	if(!(type_of(symbol_value(VV[15]))==t_cons)){
	goto T148;}
	if(!((VV[16])==(car(symbol_value(VV[15]))))){
	goto T148;}
	(void)((VFUN_NARGS=2,(*(LnkLI58))(VV[17],cadr(symbol_value(VV[15])))));
T148:;
	if(((V44))!=Cnil){
	goto T159;}
	princ_str("\n	vs_base=vs_top=base+",VV[6]);
	(void)((*(LnkLI46))((V45)));
	princ_char(59,VV[6]);
	setq(VV[7],Ct);
	princ_str("\n	vs_base[0]=Cnil;",VV[6]);
	goto T157;
T159:;
	{register object V46;
	register object V47;
	V46= (V44);
	V47= car((V46));
T172:;
	if(!(endp((V46)))){
	goto T173;}
	goto T168;
T173:;
	base[2]= list(2,VV[18],(*(LnkLI59))());
	bds_bind(VV[2],base[2]);
	V48= (*(LnkLI44))((V47));
	bds_unwind1;
	V46= cdr((V46));
	V47= car((V46));
	goto T172;}
T168:;
	princ_str("\n	vs_top=(vs_base=base+",VV[6]);
	(void)((*(LnkLI46))((V45)));
	princ_str(")+",VV[6]);
	V49= number_minus((VV[1]->s.s_dbind),(V45));
	(void)((*(LnkLI46))(/* INLINE-ARGS */V49));
	princ_char(59,VV[6]);
	setq(VV[7],Ct);
T157:;
	V50 = make_fixnum(length((V44)));
	V51= make_cons(VV[13],V50);
	{object V52 = (VFUN_NARGS=3,(*(LnkLI50))(VV[11],Cnil,/* INLINE-ARGS */V51));
	bds_unwind1;
	VMR6(V52)}}
}
/*	local entry for function C1MULTIPLE-VALUE-SETQ	*/

static object LI7(V54)

object V54;
{	 VMB7 VMS7 VMV7
TTL:;
	{register object V55;
	register object V56;
	V55= (VFUN_NARGS=0,(*(LnkLI48))());
	V56= Cnil;
	if(endp((V54))){
	goto T194;}
	if(!(endp(cdr((V54))))){
	goto T193;}
T194:;
	(void)((*(LnkLI38))(VV[19],small_fixnum(2),small_fixnum(0)));
T193:;
	if(endp(cddr((V54)))){
	goto T198;}
	V57 = make_fixnum(length((V54)));
	(void)((*(LnkLI60))(VV[19],small_fixnum(2),V57));
T198:;
	{register object V58;
	register object V59;
	V58= car((V54));
	V59= car((V58));
T205:;
	if(!(endp((V58)))){
	goto T206;}
	goto T201;
T206:;
	if(type_of((V59))==t_symbol){
	goto T210;}
	(void)((VFUN_NARGS=2,(*(LnkLI61))(VV[20],(V59))));
T210:;
	base[3]= (V59);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk62)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T213;}
	(void)((VFUN_NARGS=2,(*(LnkLI61))(VV[21],(V59))));
T213:;
	V59= (*(LnkLI63))((V59));
	V56= make_cons((V59),(V56));
	{register object V60;
	register object V61;
	V60= (V55);
	V62= car((V59));
	V63= structure_ref((V60),VV[22],0);
	V61= make_cons(/* INLINE-ARGS */V62,/* INLINE-ARGS */V63);
	(void)(structure_set((V60),VV[22],0,(V61)));}
	V58= cdr((V58));
	V59= car((V58));
	goto T205;}
T201:;
	V64= reverse((V56));
	{object V65 = list(4,VV[19],(V55),/* INLINE-ARGS */V64,(*(LnkLI49))(cadr((V54)),(V55)));
	VMR7(V65)}}
}
/*	local entry for function MULTIPLE-VALUE-CHECK	*/

static object LI8(V68,V69)

object V68;object V69;
{	 VMB8 VMS8 VMV8
TTL:;
	if((cdr((V68)))!=Cnil){
	goto T229;}
	{object V70 = Cnil;
	VMR8(V70)}
T229:;
	base[0]= car((V69));
	base[1]= VV[23];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk55)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T231;}
	{object V71 = Cnil;
	VMR8(V71)}
T231:;
	{object V72;
	V72= caddr((V69));
	if(!(type_of((V72))==t_symbol)){
	goto T237;}
	{register object V73;
	V73= get((V72),VV[24],Cnil);
	if((V73)==Cnil){
	goto T237;}
	base[0]= (V73);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk53)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T242;}
	goto T237;
T242:;
	base[1]= (V73);
	base[2]= VV[25];
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk64)();
	vs_top=sup;
	base[0]= vs_base[0];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk56)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T245;}
	goto T237;
T245:;
	base[0]= cdr((V73));
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk54)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T237;}}
	{object V74 = (VFUN_NARGS=2,(*(LnkLI58))(VV[26],(V72)));
	VMR8(V74)}
T237:;
	{object V75 = Cnil;
	VMR8(V75)}}
}
/*	local entry for function C2MULTIPLE-VALUE-SETQ	*/

static object LI9(V78,V79)

register object V78;object V79;
{	 VMB9 VMS9 VMV9
	bds_check;
TTL:;
	{object V80;
	V80= Cnil;
	(void)((*(LnkLI65))((V78),(V79)));
	bds_bind(VV[2],VV[3]);
	bds_bind(VV[9],Cnil);
	(void)((*(LnkLI44))((V79)));
	V80= (VV[9]->s.s_dbind);
	bds_unwind1;
	bds_unwind1;
	if(symbol_value(VV[27])==Cnil){
	goto T256;}
	(void)((*(LnkLI66))(Cnil,car((V80))));
T256:;
	{register object V81;
	V81= (V78);
T259:;
	if(!(endp((V81)))){
	goto T260;}
	goto T257;
T260:;
	{register object V82;
	V82= car((V81));
	princ_str("\n	if(vs_base<vs_top){",VV[6]);
	(void)((*(LnkLI67))(VV[11],car((V82)),cadr((V82))));
	if(endp(cdr((V81)))){
	goto T269;}
	princ_str("\n	vs_base++;",VV[6]);
T269:;
	princ_str("\n	}else{",VV[6]);
	(void)((*(LnkLI67))(Cnil,car((V82)),cadr((V82))));
	princ_char(125,VV[6]);}
	V81= cdr((V81));
	goto T259;}
T257:;
	if(((V78))!=Cnil){
	goto T281;}
	princ_str("\n	if(vs_base=vs_top){vs_base[0]=Cnil;vs_top=vs_base+1;}",VV[6]);
	{object V83 = (VFUN_NARGS=1,(*(LnkLI50))(VV[11]));
	VMR9(V83)}
T281:;
	if((symbol_value(VV[28]))==(VV[29])){
	goto T285;}
	princ_str("\n	",VV[6]);
	(void)((*(LnkLI68))());
T285:;
	V84= make_cons(VV[30],car((V78)));
	{object V85 = (VFUN_NARGS=1,(*(LnkLI50))(/* INLINE-ARGS */V84));
	VMR9(V85)}}
}
/*	local entry for function C1MULTIPLE-VALUE-BIND	*/

static object LI10(V87)

object V87;
{	 VMB10 VMS10 VMV10
	bds_check;
TTL:;
	{object V88;
	register object V89;
	register object V90;
	object V91;
	object V92;
	object V93;
	object V94;
	object V95;
	object V96;
	V88= (VFUN_NARGS=0,(*(LnkLI48))());
	V89= Cnil;
	V90= Cnil;
	V91= Cnil;
	V92= Cnil;
	V93= Cnil;
	V94= Cnil;
	V95= Cnil;
	V96= Cnil;
	bds_bind(VV[31],symbol_value(VV[31]));
	if(endp((V87))){
	goto T299;}
	if(!(endp(cdr((V87))))){
	goto T298;}
T299:;
	V97 = make_fixnum(length((V87)));
	(void)((*(LnkLI38))(VV[32],small_fixnum(2),V97));
T298:;
	base[2]= cddr((V87));
	base[3]= Cnil;
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk69)();
	if(vs_base<vs_top){
	V95= vs_base[0];
	vs_base++;
	}else{
	V95= Cnil;}
	if(vs_base<vs_top){
	V92= vs_base[0];
	vs_base++;
	}else{
	V92= Cnil;}
	if(vs_base<vs_top){
	V94= vs_base[0];
	vs_base++;
	}else{
	V94= Cnil;}
	if(vs_base<vs_top){
	V93= vs_base[0];
	vs_base++;
	}else{
	V93= Cnil;}
	if(vs_base<vs_top){
	V96= vs_base[0];
	}else{
	V96= Cnil;}
	vs_top=sup;
	(void)((*(LnkLI70))((V92)));
	{register object V98;
	register object V99;
	V98= car((V87));
	V99= car((V98));
T312:;
	if(!(endp((V98)))){
	goto T313;}
	goto T308;
T313:;
	{object V100;
	V100= (*(LnkLI71))((V99),(V92),(V93),(V94));
	V90= make_cons((V99),(V90));
	V89= make_cons((V100),(V89));}
	V98= cdr((V98));
	V99= car((V98));
	goto T312;}
T308:;
	V91= (*(LnkLI49))(cadr((V87)),(V88));
	{register object V101;
	object V102;
	V101= reverse((V89));
	V102= car((V101));
T333:;
	if(!(endp((V101)))){
	goto T334;}
	goto T329;
T334:;
	(VV[31]->s.s_dbind)= make_cons((V102),(VV[31]->s.s_dbind));
	V101= cdr((V101));
	V102= car((V101));
	goto T333;}
T329:;
	(void)((*(LnkLI72))((V90),(V94),(V93)));
	V95= (*(LnkLI73))((V96),(V95));
	(void)((*(LnkLI74))((V88),cadr((V95))));
	V103= structure_ref(cadr((V95)),VV[22],2);
	(void)(structure_set((V88),VV[22],2,/* INLINE-ARGS */V103));
	{register object V104;
	object V105;
	V104= (V89);
	V105= car((V104));
T354:;
	if(!(endp((V104)))){
	goto T355;}
	goto T350;
T355:;
	(void)((*(LnkLI75))((V105)));
	V104= cdr((V104));
	V105= car((V104));
	goto T354;}
T350:;
	{object V106 = list(5,VV[32],(V88),reverse((V89)),(V91),(V95));
	bds_unwind1;
	VMR10(V106)}}
}
/*	local entry for function C2MULTIPLE-VALUE-BIND	*/

static object LI11(V110,V111,V112)

object V110;object V111;object V112;
{	 VMB11 VMS11 VMV11
	bds_check;
TTL:;
	{object V113;
	register object V114;
	object V115;
	V113= Cnil;
	V114= Cnil;
	bds_bind(VV[33],symbol_value(VV[33]));
	bds_bind(VV[1],symbol_value(VV[1]));
	bds_bind(VV[34],symbol_value(VV[34]));
	bds_bind(VV[35],symbol_value(VV[35]));
	V115= Cnil;
	(void)((*(LnkLI65))((V110),(V111)));
	{register object V116;
	register object V117;
	V116= (V110);
	V117= car((V116));
T373:;
	if(!(endp((V116)))){
	goto T374;}
	goto T369;
T374:;
	{object V118;
	V118= (*(LnkLI76))((V117));
	if(((V118))==Cnil){
	goto T381;}
	{object V119;
	setq(VV[5],number_plus(symbol_value(VV[5]),small_fixnum(1)));
	V119= symbol_value(VV[5]);
	(void)(structure_set((V117),VV[30],1,(V118)));
	(void)(structure_set((V117),VV[30],4,(V119)));
	princ_str("\n	",VV[6]);
	if(((V113))!=Cnil){
	goto T388;}
	princ_char(123,VV[6]);
	V113= Ct;
T388:;
	base[5]= (V117);
	vs_top=(vs_base=base+5)+1;
	(void) (*Lnk77)();
	vs_top=sup;
	goto T378;}
T381:;
	V120= (*(LnkLI59))();
	(void)(structure_set((V117),VV[30],2,/* INLINE-ARGS */V120));}
T378:;
	V116= cdr((V116));
	V117= car((V116));
	goto T373;}
T369:;
	bds_bind(VV[2],VV[3]);
	bds_bind(VV[9],Cnil);
	(void)((*(LnkLI44))((V111)));
	V115= (VV[9]->s.s_dbind);
	bds_unwind1;
	bds_unwind1;
	if(symbol_value(VV[27])==Cnil){
	goto T403;}
	(void)((*(LnkLI66))(Cnil,car((V115))));
T403:;
	bds_bind(VV[34],(VV[34]->s.s_dbind));
	bds_bind(VV[33],(VV[33]->s.s_dbind));
	bds_bind(VV[35],(VV[35]->s.s_dbind));
	{register object V121;
	V121= (V110);
T406:;
	if(!(endp((V121)))){
	goto T407;}
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	goto T404;
T407:;
	setq(VV[36],number_plus(symbol_value(VV[36]),small_fixnum(1)));
	V122= make_cons(symbol_value(VV[36]),Cnil);
	V114= make_cons(/* INLINE-ARGS */V122,(V114));
	princ_str("\n	if(vs_base>=vs_top){",VV[6]);
	(void)((*(LnkLI68))());
	if(type_of(car((V114)))!=t_cons)FEwrong_type_argument(Scons,car((V114)));
	(car((V114)))->c.c_cdr = Ct;
	(void)(car((V114)));
	princ_str("goto T",VV[6]);
	(void)((*(LnkLI46))(car(car((V114)))));
	princ_char(59,VV[6]);
	princ_char(125,VV[6]);
	(void)((*(LnkLI78))(car((V121)),VV[37]));
	if(endp(cdr((V121)))){
	goto T425;}
	princ_str("\n	vs_base++;",VV[6]);
T425:;
	V121= cdr((V121));
	goto T406;}
T404:;
	princ_str("\n	",VV[6]);
	(void)((*(LnkLI68))());
	{object V123;
	setq(VV[36],number_plus(symbol_value(VV[36]),small_fixnum(1)));
	V123= make_cons(symbol_value(VV[36]),Cnil);
	princ_str("\n	",VV[6]);
	if(type_of((V123))!=t_cons)FEwrong_type_argument(Scons,(V123));
	((V123))->c.c_cdr = Ct;
	princ_str("goto T",VV[6]);
	(void)((*(LnkLI46))(car((V123))));
	princ_char(59,VV[6]);
	V114= reverse((V114));
	{register object V124;
	object V125;
	V124= (V110);
	V125= car((V124));
T449:;
	if(!(endp((V124)))){
	goto T450;}
	goto T445;
T450:;
	if((cdr(car((V114))))==Cnil){
	goto T454;}
	princ_str("\nT",VV[6]);
	(void)((*(LnkLI46))(car(car((V114)))));
	princ_str(":;",VV[6]);
T454:;
	{object V126;
	V126= car((V114));
	V114= cdr((V114));}
	(void)((*(LnkLI78))((V125),Cnil));
	V124= cdr((V124));
	V125= car((V124));
	goto T449;}
T445:;
	if((cdr((V123)))==Cnil){
	goto T434;}
	princ_str("\nT",VV[6]);
	(void)((*(LnkLI46))(car((V123))));
	princ_str(":;",VV[6]);}
T434:;
	base[4]= (V112);
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk79)();
	vs_top=sup;
	if(((V113))==Cnil){
	goto T478;}
	princ_char(125,VV[6]);
	{object V127 = Cnil;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	VMR11(V127)}
T478:;
	{object V128 = Cnil;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	VMR11(V128)}}
}
static LnkT79(){ call_or_link(VV[79],&Lnk79);} /* C2EXPR */
static object  LnkTLI78(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[78],&LnkLI78,2,ap);} /* C2BIND-LOC */
static LnkT77(){ call_or_link(VV[77],&Lnk77);} /* WT-VAR-DECL */
static object  LnkTLI76(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[76],&LnkLI76,1,ap);} /* C2VAR-KIND */
static object  LnkTLI75(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[75],&LnkLI75,1,ap);} /* CHECK-VREF */
static object  LnkTLI74(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[74],&LnkLI74,2,ap);} /* ADD-INFO */
static object  LnkTLI73(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[73],&LnkLI73,2,ap);} /* C1DECL-BODY */
static object  LnkTLI72(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[72],&LnkLI72,3,ap);} /* CHECK-VDECL */
static object  LnkTLI71(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[71],&LnkLI71,4,ap);} /* C1MAKE-VAR */
static object  LnkTLI70(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[70],&LnkLI70,1,ap);} /* C1ADD-GLOBALS */
static LnkT69(){ call_or_link(VV[69],&Lnk69);} /* C1BODY */
static object  LnkTLI68(){return call_proc0(VV[68],&LnkLI68);} /* RESET-TOP */
static object  LnkTLI67(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[67],&LnkLI67,3,ap);} /* SET-VAR */
static object  LnkTLI66(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[66],&LnkLI66,2,ap);} /* RECORD-CALL-INFO */
static object  LnkTLI65(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[65],&LnkLI65,2,ap);} /* MULTIPLE-VALUE-CHECK */
static LnkT64(){ call_or_link(VV[64],&Lnk64);} /* EQUAL */
static object  LnkTLI63(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[63],&LnkLI63,1,ap);} /* C1VREF */
static LnkT62(){ call_or_link(VV[62],&Lnk62);} /* CONSTANTP */
static object  LnkTLI61(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[61],&LnkLI61,ap);} /* CMPERR */
static object  LnkTLI60(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[60],&LnkLI60,3,ap);} /* TOO-MANY-ARGS */
static object  LnkTLI59(){return call_proc0(VV[59],&LnkLI59);} /* VS-PUSH */
static object  LnkTLI58(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[58],&LnkLI58,ap);} /* CMPWARN */
static object  LnkTLI57(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[57],&LnkLI57,1,ap);} /* C1EXPR */
static LnkT56(){ call_or_link(VV[56],&Lnk56);} /* NOT */
static LnkT55(){ call_or_link(VV[55],&Lnk55);} /* EQ */
static LnkT54(){ call_or_link(VV[54],&Lnk54);} /* NULL */
static LnkT53(){ call_or_link(VV[53],&Lnk53);} /* CONSP */
static LnkT52(){ call_or_link(VV[52],&Lnk52);} /* ATOM */
static object  LnkTLI51(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[51],&LnkLI51,1,ap);} /* GET-RETURN-TYPE */
static object  LnkTLI50(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[50],&LnkLI50,ap);} /* UNWIND-EXIT */
static object  LnkTLI49(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[49],&LnkLI49,2,ap);} /* C1EXPR* */
static object  LnkTLI48(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[48],&LnkLI48,ap);} /* MAKE-INFO */
static object  LnkTLI47(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[47],&LnkLI47,2,ap);} /* C2EXPR-TOP* */
static object  LnkTLI46(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[46],&LnkLI46,1,ap);} /* WT1 */
static object  LnkTLI45(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[45],&LnkLI45,ap);} /* C2FUNCALL */
static object  LnkTLI44(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[44],&LnkLI44,1,ap);} /* C2EXPR* */
static object  LnkTLI43(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[43],&LnkLI43,1,ap);} /* SAVE-FUNOB */
static object  LnkTLI42(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[42],&LnkLI42,2,ap);} /* C1ARGS */
static LnkT41(){ call_or_link(VV[41],&Lnk41);} /* COPY-INFO */
static object  LnkTLI40(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[40],&LnkLI40,1,ap);} /* C1FUNOB */
static object  LnkTLI39(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[39],&LnkLI39,1,ap);} /* C1FUNCALL */
static object  LnkTLI38(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[38],&LnkLI38,3,ap);} /* TOO-FEW-ARGS */
