
static object LI1();
static object LI10();
static L11();
static object LI12();
static L15();
static object LI1();
#define VMB1 register object *base=vs_top; object  V34 ,V33 ,V31 ,V28; object Vcs[12];
#define VMS1  register object *sup=vs_top+4;vs_top=sup;
#define VMV1 vs_reserve(4);
#define VMR1(VMT1) vs_top=base ; return(VMT1);
static object LI2();
#define VMB2 register object *base=vs_top; object  V84 ,V78 ,V72 ,V62 ,V54;
#define VMS2  register object *sup=vs_top+4;vs_top=sup;
#define VMV2 vs_reserve(4);
#define VMR2(VMT2) vs_top=base ; return(VMT2);
static object LI3();
#define VMB3 register object *base=vs_top;
#define VMS3  register object *sup=vs_top+1;vs_top=sup;
#define VMV3 vs_reserve(1);
#define VMR3(VMT3) vs_top=base ; return(VMT3);
static object LI4();
#define VMB4 register object *base=vs_top; object  V108 ,V105 ,V104;
#define VMS4  register object *sup=vs_top+1;vs_top=sup;
#define VMV4 vs_reserve(1);
#define VMR4(VMT4) vs_top=base ; return(VMT4);
static object LI5();
#define VMB5 register object *base=vs_top;
#define VMS5  register object *sup=vs_top+2;vs_top=sup;
#define VMV5 vs_reserve(2);
#define VMR5(VMT5) vs_top=base ; return(VMT5);
static object LI6();
#define VMB6 register object *base=vs_top; object  V144 ,V143 ,V141 ,V140 ,V139 ,V137 ,V136 ,V134;
#define VMS6  register object *sup=vs_top+4;vs_top=sup;
#define VMV6 vs_reserve(4);
#define VMR6(VMT6) vs_top=base ; return(VMT6);
static object LI7();
#define VMB7 register object *base=vs_top; object  V165 ,V164 ,V163 ,V159 ,V158;
#define VMS7  register object *sup=vs_top+2;vs_top=sup;
#define VMV7 vs_reserve(2);
#define VMR7(VMT7) vs_top=base ; return(VMT7);
static int LI8();
#define VMB8 register object *base=vs_top;
#define VMS8  register object *sup=vs_top+2;vs_top=sup;
#define VMV8 vs_reserve(2);
#define VMR8(VMT8) vs_top=base ; return(VMT8);
static object LI9();
#define VMB9 register object *base=vs_top; object  V212 ,V211 ,V210 ,V209 ,V208;
#define VMS9  register object *sup=vs_top+3;vs_top=sup;
#define VMV9 vs_reserve(3);
#define VMR9(VMT9) vs_top=base ; return(VMT9);
static object LI10();
#define VMB10 register object *base=vs_top; object  V252; object Vcs[14];
#define VMS10  register object *sup=vs_top+7;vs_top=sup;
#define VMV10 vs_reserve(7);
#define VMR10(VMT10) vs_top=base ; return(VMT10);
#define VC11 object  V310 ,V309 ,V305 ,V304 ,V303 ,V300 ,V297 ,V296 ,V295 ,V291 ,V290 ,V289 ,V287 ,V286 ,V285 ,V282 ,V281 ,V280 ,V279;
static object LI12();
static int VK12defaults[18]={-2,161,-2,-2,-2,-2,-2,-2,-2,161,-2,-2,-2,-2,-2,-2,-2,-2};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[18];} LI12key={18,0,VK12defaults,{77,74,75,73,72,76,162,67,66,65,71,70,68,69,163,64,63,62}};
#define VMB12 register object *base=vs_top; object Vcs[36];
#define VMS12  register object *sup=vs_top+19;vs_top=sup;
#define VMV12 vs_reserve(19);
#define VMR12(VMT12) vs_top=base ; return(VMT12);
static object LI13();
#define VMB13 object  V336;
#define VMS13
#define VMV13
#define VMR13(VMT13) return(VMT13);
static object LI14();
#define VMB14 register object *base=vs_top;
#define VMS14  register object *sup=vs_top+1;vs_top=sup;
#define VMV14 vs_reserve(1);
#define VMR14(VMT14) vs_top=base ; return(VMT14);
#define VC15 object  V354;
static LC20();
#define VC16
static LC19();
#define VC17
static LC18();
#define VC18
static LC17();
#define VC19
static LC16();
#define VC20
static LC20();
static LC19();
static LC18();
static LC17();
static LC16();
#define VM20 3
#define VM19 3
#define VM18 2
#define VM17 2
#define VM16 3
#define VM15 9
#define VM14 1
#define VM13 0
#define VM12 19
#define VM11 18
#define VM10 7
#define VM9 3
#define VM8 2
#define VM7 2
#define VM6 4
#define VM5 2
#define VM4 1
#define VM3 1
#define VM2 4
#define VM1 4
static char * VVi[170]={
#define Cdata VV[169]
(char *)(LI1),
(char *)(LI2),
(char *)(LI3),
(char *)(LI4),
(char *)(LI5),
(char *)(LI6),
(char *)(LI7),
(char *)(LI8),
(char *)(LI9),
(char *)(LI10),
(char *)(L11),
(char *)(LI12),
(char *)(&LI12key),
(char *)(LI13),
(char *)(LI14),
(char *)(L15),
(char *)(&LC19)
};
#define VV ((object *)VVi)
static  LnkT168() ;
static  (*Lnk168)() = LnkT168;
static  LnkT167() ;
static  (*Lnk167)() = LnkT167;
static  LnkT166() ;
static  (*Lnk166)() = LnkT166;
static  LnkT165() ;
static  (*Lnk165)() = LnkT165;
static  LnkT164() ;
static  (*Lnk164)() = LnkT164;
static  LnkT18() ;
static  (*Lnk18)() = LnkT18;
static  LnkT160() ;
static  (*Lnk160)() = LnkT160;
static object  LnkTLI159() ;
static object  (*LnkLI159)() = LnkTLI159;
static object  LnkTLI158() ;
static object  (*LnkLI158)() = LnkTLI158;
static  LnkT20() ;
static  (*Lnk20)() = LnkT20;
static  LnkT157() ;
static  (*Lnk157)() = LnkT157;
static  LnkT156() ;
static  (*Lnk156)() = LnkT156;
static object  LnkTLI155() ;
static object  (*LnkLI155)() = LnkTLI155;
static  LnkT154() ;
static  (*Lnk154)() = LnkT154;
static object  LnkTLI148() ;
static object  (*LnkLI148)() = LnkTLI148;
static object  LnkTLI147() ;
static object  (*LnkLI147)() = LnkTLI147;
static object  LnkTLI146() ;
static object  (*LnkLI146)() = LnkTLI146;
static  LnkT145() ;
static  (*Lnk145)() = LnkT145;
static object  LnkTLI144() ;
static object  (*LnkLI144)() = LnkTLI144;
static  LnkT143() ;
static  (*Lnk143)() = LnkT143;
static object  LnkTLI142() ;
static object  (*LnkLI142)() = LnkTLI142;
static  LnkT138() ;
static  (*Lnk138)() = LnkT138;
static  LnkT137() ;
static  (*Lnk137)() = LnkT137;
static  LnkT136() ;
static  (*Lnk136)() = LnkT136;
static  LnkT135() ;
static  (*Lnk135)() = LnkT135;
static int  LnkTLI134() ;
static int  (*LnkLI134)() = LnkTLI134;
static  LnkT133() ;
static  (*Lnk133)() = LnkT133;
static object  LnkTLI132() ;
static object  (*LnkLI132)() = LnkTLI132;
static  LnkT131() ;
static  (*Lnk131)() = LnkT131;
static  LnkT130() ;
static  (*Lnk130)() = LnkT130;
static  LnkT129() ;
static  (*Lnk129)() = LnkT129;
static  LnkT128() ;
static  (*Lnk128)() = LnkT128;
static  LnkT127() ;
static  (*Lnk127)() = LnkT127;
static  LnkT126() ;
static  (*Lnk126)() = LnkT126;
static object  LnkTLI125() ;
static object  (*LnkLI125)() = LnkTLI125;
static object  LnkTLI124() ;
static object  (*LnkLI124)() = LnkTLI124;
static object  LnkTLI123() ;
static object  (*LnkLI123)() = LnkTLI123;
static object  LnkTLI122() ;
static object  (*LnkLI122)() = LnkTLI122;
static  LnkT119() ;
static  (*Lnk119)() = LnkT119;
static  LnkT118() ;
static  (*Lnk118)() = LnkT118;
static  LnkT117() ;
static  (*Lnk117)() = LnkT117;
static object  LnkTLI115() ;
static object  (*LnkLI115)() = LnkTLI115;
static  LnkT114() ;
static  (*Lnk114)() = LnkT114;
static  LnkT113() ;
static  (*Lnk113)() = LnkT113;
static  LnkT112() ;
static  (*Lnk112)() = LnkT112;
static  LnkT29() ;
static  (*Lnk29)() = LnkT29;
static  LnkT111() ;
static  (*Lnk111)() = LnkT111;
static  LnkT110() ;
static  (*Lnk110)() = LnkT110;
static  LnkT109() ;
static  (*Lnk109)() = LnkT109;
static object  LnkTLI108() ;
static object  (*LnkLI108)() = LnkTLI108;
static  LnkT27() ;
static  (*Lnk27)() = LnkT27;
static  LnkT107() ;
static  (*Lnk107)() = LnkT107;
static  LnkT106() ;
static  (*Lnk106)() = LnkT106;
