
static object LI1();
static object LI5();
static object LI6();
static L9();
static object LI15();
static object LI1();
#define VMB1 register object *base=vs_top; object Vcs[2];
#define VMS1  register object *sup=vs_top+4;vs_top=sup;
#define VMV1 vs_reserve(4);
#define VMR1(VMT1) vs_top=base ; return(VMT1);
static object LI2();
#define VMB2 register object *base=vs_top;
#define VMS2  register object *sup=vs_top+1;vs_top=sup;
#define VMV2 vs_reserve(1);
#define VMR2(VMT2) vs_top=base ; return(VMT2);
static object LI3();
#define VMB3 register object *base=vs_top; object  V41 ,V40 ,V36 ,V35 ,V33;
#define VMS3  register object *sup=vs_top+4;vs_top=sup;
#define VMV3 vs_reserve(4);
#define VMR3(VMT3) vs_top=base ; return(VMT3);
static object LI4();
#define VMB4 register object *base=vs_top;
#define VMS4 vs_top += 4;
#define VMV4 vs_reserve(4);
#define VMR4(VMT4) vs_top=base ; return(VMT4);
static object LI5();
#define VMB5 register object *base=vs_top; object  V66 ,V64; object Vcs[4];
#define VMS5 vs_top += 2;
#define VMV5 vs_reserve(2);
#define VMR5(VMT5) vs_top=base ; return(VMT5);
static object LI6();
#define VMB6 register object *base=vs_top; object  V74 ,V73 ,V70; object Vcs[1];
#define VMS6 vs_top += 3;
#define VMV6 vs_reserve(3);
#define VMR6(VMT6) vs_top=base ; return(VMT6);
static object LI7();
#define VMB7 register object *base=vs_top; object  V84;
#define VMS7  register object *sup=vs_top+3;vs_top=sup;
#define VMV7 vs_reserve(3);
#define VMR7(VMT7) vs_top=base ; return(VMT7);
static object LI8();
#define VMB8 register object *base=vs_top; object  V99 ,V98;
#define VMS8  register object *sup=vs_top+2;vs_top=sup;
#define VMV8 vs_reserve(2);
#define VMR8(VMT8) vs_top=base ; return(VMT8);
#define VC9
static object LI10();
#define VMB10 register object *base=vs_top; object  V127 ,V126 ,V122 ,V117;
#define VMS10  register object *sup=vs_top+5;vs_top=sup;
#define VMV10 vs_reserve(5);
#define VMR10(VMT10) vs_top=base ; return(VMT10);
static object LI11();
#define VMB11 register object *base=vs_top; object  V162 ,V160 ,V159 ,V158 ,V157 ,V155 ,V149;
#define VMS11  register object *sup=vs_top+5;vs_top=sup;
#define VMV11 vs_reserve(5);
#define VMR11(VMT11) vs_top=base ; return(VMT11);
static object LI12();
#define VMB12 object  V177 ,V176 ,V175 ,V174 ,V173 ,V170;
#define VMS12
#define VMV12
#define VMR12(VMT12) return(VMT12);
static object LI13();
#define VMB13 register object *base=vs_top;
#define VMS13  register object *sup=vs_top+1;vs_top=sup;
#define VMV13 vs_reserve(1);
#define VMR13(VMT13) vs_top=base ; return(VMT13);
static object LI14();
#define VMB14 register object *base=vs_top; object  V201 ,V198 ,V197 ,V196 ,V195;
#define VMS14  register object *sup=vs_top+7;vs_top=sup;
#define VMV14 vs_reserve(7);
#define VMR14(VMT14) vs_top=base ; return(VMT14);
static object LI15();
#define VMB15 object Vcs[4];
#define VMS15
#define VMV15
#define VMR15(VMT15) return(VMT15);
static object LI16();
#define VMB16 register object *base=vs_top; object  V218 ,V217;
#define VMS16 vs_top += 2;
#define VMV16 vs_reserve(2);
#define VMR16(VMT16) vs_top=base ; return(VMT16);
static object LI17();
#define VMB17 register object *base=vs_top; object  V231 ,V230;
#define VMS17 vs_top += 3;
#define VMV17 vs_reserve(3);
#define VMR17(VMT17) vs_top=base ; return(VMT17);
static object LI18();
#define VMB18 register object *base=vs_top; object  V239;
#define VMS18 vs_top += 2;
#define VMV18 vs_reserve(2);
#define VMR18(VMT18) vs_top=base ; return(VMT18);
static object LI19();
#define VMB19 object  V267 ,V266 ,V265 ,V263 ,V262 ,V259 ,V258 ,V257 ,V255 ,V254 ,V253 ,V249 ,V248;
#define VMS19
#define VMV19
#define VMR19(VMT19) return(VMT19);
static LC20();
#define VC20 object  V270;
static LC20();
#define VM20 3
#define VM19 0
#define VM18 2
#define VM17 3
#define VM16 2
#define VM15 0
#define VM14 7
#define VM13 1
#define VM12 0
#define VM11 5
#define VM10 5
#define VM9 3
#define VM8 2
#define VM7 3
#define VM6 3
#define VM5 2
#define VM4 4
#define VM3 4
#define VM2 1
#define VM1 4
static char * VVi[163]={
#define Cdata VV[162]
(char *)(LI1),
(char *)(LI2),
(char *)(LI3),
(char *)(LI4),
(char *)(LI5),
(char *)(LI6),
(char *)(LI7),
(char *)(LI8),
(char *)(L9),
(char *)(LI10),
(char *)(LI11),
(char *)(LI12),
(char *)(LI13),
(char *)(LI14),
(char *)(LI15),
(char *)(LI16),
(char *)(LI17),
(char *)(LI18),
(char *)(LI19)
};
#define VV ((object *)VVi)
static  LnkT161() ;
static  (*Lnk161)() = LnkT161;
static object  LnkTLI160() ;
static object  (*LnkLI160)() = LnkTLI160;
static  LnkT158() ;
static  (*Lnk158)() = LnkT158;
static object  LnkTLI157() ;
static object  (*LnkLI157)() = LnkTLI157;
static object  LnkTLI156() ;
static object  (*LnkLI156)() = LnkTLI156;
static int  LnkTLI155() ;
static int  (*LnkLI155)() = LnkTLI155;
static object  LnkTLI154() ;
static object  (*LnkLI154)() = LnkTLI154;
static object  LnkTLI153() ;
static object  (*LnkLI153)() = LnkTLI153;
static  LnkT152() ;
static  (*Lnk152)() = LnkT152;
static  LnkT151() ;
static  (*Lnk151)() = LnkT151;
static  LnkT150() ;
static  (*Lnk150)() = LnkT150;
static  LnkT149() ;
static  (*Lnk149)() = LnkT149;
static  LnkT75() ;
static  (*Lnk75)() = LnkT75;
static object  LnkTLI148() ;
static object  (*LnkLI148)() = LnkTLI148;
static object  LnkTLI147() ;
static object  (*LnkLI147)() = LnkTLI147;
static object  LnkTLI146() ;
static object  (*LnkLI146)() = LnkTLI146;
static object  LnkTLI145() ;
static object  (*LnkLI145)() = LnkTLI145;
static  LnkT144() ;
static  (*Lnk144)() = LnkT144;
static object  LnkTLI143() ;
static object  (*LnkLI143)() = LnkTLI143;
static object  LnkTLI142() ;
static object  (*LnkLI142)() = LnkTLI142;
static object  LnkTLI141() ;
static object  (*LnkLI141)() = LnkTLI141;
static  LnkT140() ;
static  (*Lnk140)() = LnkT140;
static object  LnkTLI139() ;
static object  (*LnkLI139)() = LnkTLI139;
static object  LnkTLI138() ;
static object  (*LnkLI138)() = LnkTLI138;
static object  LnkTLI137() ;
static object  (*LnkLI137)() = LnkTLI137;
static object  LnkTLI136() ;
static object  (*LnkLI136)() = LnkTLI136;
static object  LnkTLI135() ;
static object  (*LnkLI135)() = LnkTLI135;
static object  LnkTLI134() ;
static object  (*LnkLI134)() = LnkTLI134;
static  LnkT133() ;
static  (*Lnk133)() = LnkT133;
static  LnkT132() ;
static  (*Lnk132)() = LnkT132;
static object  LnkTLI131() ;
static object  (*LnkLI131)() = LnkTLI131;
static object  LnkTLI130() ;
static object  (*LnkLI130)() = LnkTLI130;
static object  LnkTLI129() ;
static object  (*LnkLI129)() = LnkTLI129;
static  LnkT128() ;
static  (*Lnk128)() = LnkT128;
static object  LnkTLI127() ;
static object  (*LnkLI127)() = LnkTLI127;
static object  LnkTLI126() ;
static object  (*LnkLI126)() = LnkTLI126;
static object  LnkTLI125() ;
static object  (*LnkLI125)() = LnkTLI125;
static object  LnkTLI124() ;
static object  (*LnkLI124)() = LnkTLI124;
static object  LnkTLI123() ;
static object  (*LnkLI123)() = LnkTLI123;
static object  LnkTLI122() ;
static object  (*LnkLI122)() = LnkTLI122;
static object  LnkTLI121() ;
static object  (*LnkLI121)() = LnkTLI121;
static object  LnkTLI120() ;
static object  (*LnkLI120)() = LnkTLI120;
static object  LnkTLI119() ;
static object  (*LnkLI119)() = LnkTLI119;
static object  LnkTLI118() ;
static object  (*LnkLI118)() = LnkTLI118;
static object  LnkTLI117() ;
static object  (*LnkLI117)() = LnkTLI117;
static object  LnkTLI116() ;
static object  (*LnkLI116)() = LnkTLI116;
static object  LnkTLI115() ;
static object  (*LnkLI115)() = LnkTLI115;
static object  LnkTLI114() ;
static object  (*LnkLI114)() = LnkTLI114;
static object  LnkTLI113() ;
static object  (*LnkLI113)() = LnkTLI113;
static object  LnkTLI112() ;
static object  (*LnkLI112)() = LnkTLI112;
static object  LnkTLI111() ;
static object  (*LnkLI111)() = LnkTLI111;
static object  LnkTLI110() ;
static object  (*LnkLI110)() = LnkTLI110;
static  LnkT109() ;
static  (*Lnk109)() = LnkT109;
static object  LnkTLI108() ;
static object  (*LnkLI108)() = LnkTLI108;
static object  LnkTLI107() ;
static object  (*LnkLI107)() = LnkTLI107;
static  LnkT106() ;
static  (*Lnk106)() = LnkT106;
static  LnkT105() ;
static  (*Lnk105)() = LnkT105;
static object  LnkTLI104() ;
static object  (*LnkLI104)() = LnkTLI104;
static object  LnkTLI103() ;
static object  (*LnkLI103)() = LnkTLI103;
static  LnkT102() ;
static  (*Lnk102)() = LnkT102;
static object  LnkTLI101() ;
static object  (*LnkLI101)() = LnkTLI101;
static  LnkT100() ;
static  (*Lnk100)() = LnkT100;
static  LnkT99() ;
static  (*Lnk99)() = LnkT99;
static  LnkT98() ;
static  (*Lnk98)() = LnkT98;
static  LnkT97() ;
static  (*Lnk97)() = LnkT97;
static  LnkT96() ;
static  (*Lnk96)() = LnkT96;
