
static object LI1();
static L19();
static L20();
static object LI1();
static struct { short n,allow_other_keys;int *defaults;
	 int keys[8];} LI1key={8,0,(int *)Cstd_key_defaults,{41,42,43,44,7,8,6,5}};
#define VMB1 register object *base=vs_top; object Vcs[16];
#define VMS1  register object *sup=vs_top+9;vs_top=sup;
#define VMV1 vs_reserve(9);
#define VMR1(VMT1) vs_top=base ; return(VMT1);
static object LI2();
#define VMB2 register object *base=vs_top;
#define VMS2  register object *sup=vs_top+2;vs_top=sup;
#define VMV2 vs_reserve(2);
#define VMR2(VMT2) vs_top=base ; return(VMT2);
static object LI3();
#define VMB3 register object *base=vs_top; object  V23;
#define VMS3  register object *sup=vs_top+2;vs_top=sup;
#define VMV3 vs_reserve(2);
#define VMR3(VMT3) vs_top=base ; return(VMT3);
static object LI4();
#define VMB4 register object *base=vs_top;
#define VMS4  register object *sup=vs_top+2;vs_top=sup;
#define VMV4 vs_reserve(2);
#define VMR4(VMT4) vs_top=base ; return(VMT4);
static object LI5();
#define VMB5 register object *base=vs_top; object  V59 ,V58 ,V57 ,V56 ,V55 ,V54 ,V52 ,V51;
#define VMS5  register object *sup=vs_top+5;vs_top=sup;
#define VMV5 vs_reserve(5);
#define VMR5(VMT5) vs_top=base ; return(VMT5);
static object LI6();
#define VMB6
#define VMS6
#define VMV6
#define VMR6(VMT6) return(VMT6);
static object LI7();
#define VMB7 register object *base=vs_top; object  V74;
#define VMS7  register object *sup=vs_top+4;vs_top=sup;
#define VMV7 vs_reserve(4);
#define VMR7(VMT7) vs_top=base ; return(VMT7);
static object LI8();
#define VMB8 register object *base=vs_top; object  V90 ,V89 ,V88 ,V87 ,V83 ,V82 ,V81;
#define VMS8  register object *sup=vs_top+5;vs_top=sup;
#define VMV8 vs_reserve(5);
#define VMR8(VMT8) vs_top=base ; return(VMT8);
static object LI9();
#define VMB9 register object *base=vs_top; object  V100 ,V99 ,V98 ,V97;
#define VMS9  register object *sup=vs_top+6;vs_top=sup;
#define VMV9 vs_reserve(6);
#define VMR9(VMT9) vs_top=base ; return(VMT9);
static object LI10();
#define VMB10 register object *base=vs_top; object  V112 ,V111 ,V110 ,V109;
#define VMS10  register object *sup=vs_top+8;vs_top=sup;
#define VMV10 vs_reserve(8);
#define VMR10(VMT10) vs_top=base ; return(VMT10);
static object LI11();
#define VMB11 object  V124 ,V116;
#define VMS11
#define VMV11
#define VMR11(VMT11) return(VMT11);
static object LI12();
#define VMB12
#define VMS12
#define VMV12
#define VMR12(VMT12) return(VMT12);
static object LI13();
#define VMB13 object  V140 ,V139 ,V138;
#define VMS13
#define VMV13
#define VMR13(VMT13) return(VMT13);
static object LI14();
#define VMB14 object  V146 ,V145 ,V144;
#define VMS14
#define VMV14
#define VMR14(VMT14) return(VMT14);
static object LI15();
#define VMB15 object  V152 ,V151 ,V150;
#define VMS15
#define VMV15
#define VMR15(VMT15) return(VMT15);
static object LI16();
#define VMB16 object  V156;
#define VMS16
#define VMV16
#define VMR16(VMT16) return(VMT16);
static object LI17();
#define VMB17 register object *base=vs_top; object  V176 ,V175 ,V173 ,V172 ,V166;
#define VMS17  register object *sup=vs_top+6;vs_top=sup;
#define VMV17 vs_reserve(6);
#define VMR17(VMT17) vs_top=base ; return(VMT17);
static object LI18();
#define VMB18 register object *base=vs_top; object  V187;
#define VMS18  register object *sup=vs_top+4;vs_top=sup;
#define VMV18 vs_reserve(4);
#define VMR18(VMT18) vs_top=base ; return(VMT18);
#define VC19 object  V198 ,V197 ,V195 ,V194 ,V193 ,V192;
#define VC20
#define VM20 3
#define VM19 8
#define VM18 4
#define VM17 6
#define VM16 0
#define VM15 0
#define VM14 0
#define VM13 0
#define VM12 0
#define VM11 0
#define VM10 8
#define VM9 6
#define VM8 5
#define VM7 4
#define VM6 0
#define VM5 5
#define VM4 2
#define VM3 2
#define VM2 2
#define VM1 9
static char * VVi[89]={
#define Cdata VV[88]
(char *)(LI1),
(char *)(&LI1key),
(char *)(LI2),
(char *)(LI3),
(char *)(LI4),
(char *)(LI5),
(char *)(LI6),
(char *)(LI7),
(char *)(LI8),
(char *)(LI9),
(char *)(LI10),
(char *)(LI11),
(char *)(LI12),
(char *)(LI13),
(char *)(LI14),
(char *)(LI15),
(char *)(LI16),
(char *)(LI17),
(char *)(LI18),
(char *)(L19),
(char *)(L20)
};
#define VV ((object *)VVi)
static  LnkT87() ;
static  (*Lnk87)() = LnkT87;
static object  LnkTLI86() ;
static object  (*LnkLI86)() = LnkTLI86;
static  LnkT85() ;
static  (*Lnk85)() = LnkT85;
static object  LnkTLI84() ;
static object  (*LnkLI84)() = LnkTLI84;
static object  LnkTLI83() ;
static object  (*LnkLI83)() = LnkTLI83;
static object  LnkTLI82() ;
static object  (*LnkLI82)() = LnkTLI82;
static  LnkT81() ;
static  (*Lnk81)() = LnkT81;
static object  LnkTLI80() ;
static object  (*LnkLI80)() = LnkTLI80;
static object  LnkTLI79() ;
static object  (*LnkLI79)() = LnkTLI79;
static object  LnkTLI78() ;
static object  (*LnkLI78)() = LnkTLI78;
static object  LnkTLI77() ;
static object  (*LnkLI77)() = LnkTLI77;
static object  LnkTLI76() ;
static object  (*LnkLI76)() = LnkTLI76;
static object  LnkTLI75() ;
static object  (*LnkLI75)() = LnkTLI75;
static object  LnkTLI72() ;
static object  (*LnkLI72)() = LnkTLI72;
static object  LnkTLI71() ;
static object  (*LnkLI71)() = LnkTLI71;
static object  LnkTLI70() ;
static object  (*LnkLI70)() = LnkTLI70;
static object  LnkTLI69() ;
static object  (*LnkLI69)() = LnkTLI69;
static object  LnkTLI68() ;
static object  (*LnkLI68)() = LnkTLI68;
static object  LnkTLI67() ;
static object  (*LnkLI67)() = LnkTLI67;
static object  LnkTLI66() ;
static object  (*LnkLI66)() = LnkTLI66;
static object  LnkTLI65() ;
static object  (*LnkLI65)() = LnkTLI65;
static object  LnkTLI64() ;
static object  (*LnkLI64)() = LnkTLI64;
static  LnkT63() ;
static  (*Lnk63)() = LnkT63;
static object  LnkTLI62() ;
static object  (*LnkLI62)() = LnkTLI62;
static object  LnkTLI61() ;
static object  (*LnkLI61)() = LnkTLI61;
static object  LnkTLI60() ;
static object  (*LnkLI60)() = LnkTLI60;
static object  LnkTLI59() ;
static object  (*LnkLI59)() = LnkTLI59;
static object  LnkTLI58() ;
static object  (*LnkLI58)() = LnkTLI58;
static object  LnkTLI57() ;
static object  (*LnkLI57)() = LnkTLI57;
static object  LnkTLI56() ;
static object  (*LnkLI56)() = LnkTLI56;
static object  LnkTLI55() ;
static object  (*LnkLI55)() = LnkTLI55;
static object  LnkTLI54() ;
static object  (*LnkLI54)() = LnkTLI54;
static object  LnkTLI53() ;
static object  (*LnkLI53)() = LnkTLI53;
static object  LnkTLI52() ;
static object  (*LnkLI52)() = LnkTLI52;
static object  LnkTLI51() ;
static object  (*LnkLI51)() = LnkTLI51;
static object  LnkTLI50() ;
static object  (*LnkLI50)() = LnkTLI50;
static object  LnkTLI49() ;
static object  (*LnkLI49)() = LnkTLI49;
static object  LnkTLI48() ;
static object  (*LnkLI48)() = LnkTLI48;
static  LnkT47() ;
static  (*Lnk47)() = LnkT47;
static  LnkT46() ;
static  (*Lnk46)() = LnkT46;
static  LnkT45() ;
static  (*Lnk45)() = LnkT45;
