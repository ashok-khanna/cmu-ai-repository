
#include <cmpinclude.h>
#include "cmpcall.h"
init_cmpcall(){do_init(VV);}
/*	local entry for function FAST-LINK-PROCLAIMED-TYPE-P	*/

static object LI1(V1,va_alist)
	object V1;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB1 VMS1 VMV1
	{register object V2;
	object V3;
	if(narg <1) too_few_arguments();
	V2= V1;
	narg = narg - 1;
	if (narg <= 0) goto T1;
	else {
	va_start(ap);
	V3= va_arg(ap,object);}
	--narg; goto T2;
T1:;
	V3= Cnil;
T2:;
	base[0]= (V2);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk96)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T4;}
	{object V4 = Cnil;
	VMR1(V4)}
T4:;
	base[0]= make_fixnum(length((V3)));
	base[1]= small_fixnum(64);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk97)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T7;}
	{object V5 = Cnil;
	VMR1(V5)}
T7:;{object V6;
	if((get((V2),VV[0],Cnil))!=Cnil){
	goto T13;}
	V6= Cnil;
	goto T12;
T13:;
	base[0]= (V3);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk98)();
	vs_top=sup;
	V6= vs_base[0];
T12:;
	if(V6==Cnil)goto T11;
	{object V7 = V6;
	VMR1(V7)}
T11:;}
	if((get((V2),VV[1],Cnil))!=Cnil){
	goto T16;}
	{object V8 = Cnil;
	VMR1(V8)}
T16:;
	{object V9;
	V9= get((V2),VV[2],Cnil);
	{register object x= (V9),V10= VV[3];
	while(!endp(V10))
	if(eql(x,V10->c.c_car)){
	base[0]= V10;
	goto T21;
	}else V10=V10->c.c_cdr;
	base[0]= Cnil;}
T21:;
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk99)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T18;}}
	{object V11 = Cnil;
	VMR1(V11)}
T18:;
	{register object V12;
	register object V13;
	V12= get((V2),VV[4],Cnil);
	V13= car((V12));
T25:;
	if(!(endp((V12)))){
	goto T26;}
	{object V14 = Ct;
	VMR1(V14)}
T26:;{object V15;
	base[2]= (V13);
	base[3]= VV[5];
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk100)();
	vs_top=sup;
	V15= vs_base[0];
	if(V15==Cnil)goto T31;
	goto T30;
T31:;}{object V16;
	{register object V17;
	V17= (V13);
	{register object x= (V17),V18= VV[3];
	while(!endp(V18))
	if(eql(x,V18->c.c_car)){
	base[2]= V18;
	goto T37;
	}else V18=V18->c.c_cdr;
	base[2]= Cnil;}
T37:;
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk99)();
	vs_top=sup;
	V16= vs_base[0];}
	if(V16==Cnil)goto T35;
	goto T30;
T35:;}
	{object V19 = Cnil;
	VMR1(V19)}
T30:;
	V12= cdr((V12));
	V13= car((V12));
	goto T25;}}
	}
/*	local entry for function CMP-MACRO-FUNCTION	*/

static object LI2(V21)

object V21;
{	 VMB2 VMS2 VMV2
TTL:;
	{object V22;
	V22= Cnil;
	V22= (*(LnkLI101))((V21));
	if(((V22))==Cnil){
	goto T45;}
	if(!((car((V22)))==(VV[6]))){
	goto T49;}
	{object V23 = Cnil;
	VMR2(V23)}
T49:;
	{object V24 = (V22);
	VMR2(V24)}
T45:;
	base[0]= (V21);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk102)();
	vs_top=sup;
	{object V25 = vs_base[0];
	VMR2(V25)}}
}
/*	local entry for function C1FUNOB	*/

static object LI3(V27)

register object V27;
{	 VMB3 VMS3 VMV3
	bds_check;
TTL:;
	{register object V28;
	V28= Cnil;
	if(!(type_of((V27))==t_cons)){
	goto T53;}
	if(!(type_of(car((V27)))==t_symbol)){
	goto T53;}
	if(((*(LnkLI103))(car((V27))))==Cnil){
	goto T53;}
	V27= (*(LnkLI104))((V27));
T53:;{object V29;
	base[0]= (V27);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk105)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T63;}
	V29= Cnil;
	goto T62;
T63:;{object V30;
	base[0]= car((V27));
	base[1]= VV[7];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk100)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T68;}
	V30= Cnil;
	goto T67;
T68:;
	base[1]= cdr((V27));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk106)();
	vs_top=sup;
	base[0]= vs_base[0];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk99)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T72;}
	V30= Cnil;
	goto T67;
T72:;
	base[0]= cddr((V27));
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk106)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T76;}
	V30= Cnil;
	goto T67;
T76:;{object V31;
	base[0]= cadr((V27));
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk105)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T81;}
	V31= Cnil;
	goto T80;
T81:;
	base[1]= cdadr((V27));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk106)();
	vs_top=sup;
	base[0]= vs_base[0];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk99)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T84;}
	V31= Cnil;
	goto T80;
T84:;
	base[0]= caadr((V27));
	base[1]= VV[8];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk100)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T88;}
	V31= Cnil;
	goto T80;
T88:;
	bds_bind(VV[9],Cnil);
	bds_bind(VV[10],Cnil);
	bds_bind(VV[11],Cnil);
	bds_bind(VV[12],Cnil);
	{object V32;
	V32= (VFUN_NARGS=1,(*(LnkLI107))(cdadr((V27))));
	V33= list(3,VV[13],cadr((V32)),(V32));
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	V31= V33;}
T80:;
	if(V31==Cnil)goto T79;
	V30= V31;
	goto T67;
T79:;}
	base[0]= cadr((V27));
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk96)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T93;}
	V30= Cnil;
	goto T67;
T93:;{object V34;
	V28= (*(LnkLI101))(cadr((V27)));
	if(((V28))!=Cnil){
	goto T98;}
	V34= Cnil;
	goto T97;
T98:;
	base[0]= car((V28));
	base[1]= VV[6];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk100)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T101;}
	V34= Cnil;
	goto T97;
T101:;
	V34= (V28);
T97:;
	if(V34==Cnil)goto T96;
	V30= V34;
	goto T67;
T96:;}
	base[0]= get(cadr((V27)),VV[16],Cnil);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk109)();
	vs_top=sup;
	V35= vs_base[0];
	V36= (VFUN_NARGS=2,(*(LnkLI108))(VV[15],V35));
	V30= list(3,VV[14],/* INLINE-ARGS */V36,cadr((V27)));
T67:;
	if(V30==Cnil)goto T66;
	V29= V30;
	goto T62;
T66:;}
	base[0]= car((V27));
	base[1]= VV[17];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk100)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T107;}
	V29= Cnil;
	goto T62;
T107:;
	base[1]= cdr((V27));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk106)();
	vs_top=sup;
	base[0]= vs_base[0];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk99)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T111;}
	V29= Cnil;
	goto T62;
T111:;
	base[0]= cddr((V27));
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk106)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T115;}
	V29= Cnil;
	goto T62;
T115:;{object V37;
	base[0]= cadr((V27));
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk105)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T120;}
	V37= Cnil;
	goto T119;
T120:;
	base[0]= caadr((V27));
	base[1]= VV[8];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk100)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T123;}
	V37= Cnil;
	goto T119;
T123:;
	base[1]= cdadr((V27));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk106)();
	vs_top=sup;
	base[0]= vs_base[0];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk99)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T127;}
	V37= Cnil;
	goto T119;
T127:;
	{object V38;
	V38= (VFUN_NARGS=1,(*(LnkLI107))(cdadr((V27))));
	V37= list(3,VV[13],cadr((V38)),(V38));}
T119:;
	if(V37==Cnil)goto T118;
	V29= V37;
	goto T62;
T118:;}
	base[0]= cadr((V27));
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk96)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T132;}
	V29= Cnil;
	goto T62;
T132:;{object V39;
	V28= (*(LnkLI101))(cadr((V27)));
	if(((V28))!=Cnil){
	goto T137;}
	V39= Cnil;
	goto T136;
T137:;
	base[0]= car((V28));
	base[1]= VV[6];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk100)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T140;}
	V39= Cnil;
	goto T136;
T140:;
	V39= (V28);
T136:;
	if(V39==Cnil)goto T135;
	V29= V39;
	goto T62;
T135:;}
	base[0]= get(cadr((V27)),VV[16],Cnil);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk109)();
	vs_top=sup;
	V40= vs_base[0];
	V41= (VFUN_NARGS=2,(*(LnkLI108))(VV[15],V40));
	V29= list(3,VV[14],/* INLINE-ARGS */V41,cadr((V27)));
T62:;
	if(V29==Cnil)goto T61;
	{object V42 = V29;
	VMR3(V42)}
T61:;}
	{object V43;
	object V44;
	V43= (*(LnkLI110))((V27));
	V44= (VFUN_NARGS=2,(*(LnkLI108))(VV[15],Ct));
	(void)((*(LnkLI111))((V44),cadr((V43))));
	{object V45 = list(3,VV[18],(V44),(V43));
	VMR3(V45)}}}
}
/*	local entry for function C2FUNCALL-AUX	*/

static object LI4(V47)

register object V47;
{	 VMB4 VMS4 VMV4
TTL:;
	{object V48;
	object V49;
	object V50;
	object V51;
	V48= cadr((V47));
	V49= caddr((V47));
	V50= cadddr((V47));
	V51= car(cddddr((V47)));
	{object V52 = (VFUN_NARGS=4,(*(LnkLI112))((V49),(V50),(V51),(V48)));
	VMR4(V52)}}
}
/*	local entry for function C2FUNCALL	*/

static object LI5(V54,V53,va_alist)
	object V54,V53;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB5 VMS5 VMV5
	bds_check;
	{register object V55;
	register object V56;
	register object V57;
	object V58;
	if(narg <2) too_few_arguments();
	V55= V54;
	V56= V53;
	narg = narg - 2;
	if (narg <= 0) goto T153;
	else {
	va_start(ap);
	V57= va_arg(ap,object);}
	if (--narg <= 0) goto T154;
	else {
	V58= va_arg(ap,object);}
	--narg; goto T155;
T153:;
	V57= Cnil;
T154:;
	V58= Cnil;
T155:;
	{object V59= car((V55));
	if((V59!= VV[14]))goto T158;
	{object V60 = (*(LnkLI113))(caddr((V55)),(V56),(V57),Ct);
	VMR5(V60)}
T158:;
	if((V59!= VV[6]))goto T159;
	{object V61 = (*(LnkLI114))(cddr((V55)),(V56));
	VMR5(V61)}
T159:;
	if((V59!= VV[13]))goto T160;
	{object V62 = (*(LnkLI115))(caddr((V55)),(V56));
	VMR5(V62)}
T160:;
	if((V59!= VV[18]))goto T161;
	{register object V63;
	base[0]= symbol_value(VV[19]);
	V63= caddr((V55));
	bds_bind(VV[19],base[0]);
	if(!(type_of((V56))==t_cons||((V56))==Cnil)){
	goto T164;}
	if((symbol_value(VV[20]))==Cnil){
	goto T164;}
	if((symbol_value(VV[21]))==(VV[22])){
	goto T165;}
	if(!(type_of(symbol_value(VV[21]))==t_cons)){
	goto T172;}
	if((car(symbol_value(VV[21])))==(VV[23])){
	goto T165;}
T172:;
	if(((V58))==Cnil){
	goto T164;}
	V64= structure_ref((V58),VV[24],2);
	if(!(equal(/* INLINE-ARGS */V64,VV[25]))){
	goto T164;}
T165:;
	(void)((*(LnkLI116))((V63),(V56),(V58)));
	{object V65 = Cnil;
	bds_unwind1;
	VMR5(V65)}
T164:;
	if(((V57))!=Cnil){
	goto T180;}
	if(type_of((V56))==t_cons||((V56))==Cnil){
	goto T183;}
	(void)((*(LnkLI117))());
T183:;
	if(!((car((V63)))==(VV[26]))){
	goto T187;}
	V57= caddr((V63));
	goto T180;
T187:;
	if(!((car((V63)))==(VV[23]))){
	goto T191;}
	if(((*(LnkLI118))(caaddr((V63)),(V56)))!=Cnil){
	goto T191;}
	V57= make_cons(VV[23],caddr((V63)));
	goto T180;
T191:;
	V57= list(2,VV[27],(*(LnkLI119))());
	bds_bind(VV[21],(V57));
	V66= (*(LnkLI120))(caddr((V55)));
	bds_unwind1;
T180:;
	(void)((*(LnkLI121))((V56)));
	if((symbol_value(VV[28]))==Cnil){
	goto T201;}
	princ_str("\n	super_funcall(",VV[29]);
	(void)((*(LnkLI122))((V57)));
	princ_str(");",VV[29]);
	goto T199;
T201:;
	if((symbol_value(VV[30]))==Cnil){
	goto T207;}
	(void)((
	(type_of(symbol_value(VV[30])) == t_sfun ?(*(object (*)())((symbol_value(VV[30]))->sfn.sfn_self)):
	(fcall.fun=(symbol_value(VV[30])),fcall.argd=1,fcalln))((V57))));
	goto T199;
T207:;
	princ_str("\n	super_funcall_no_event(",VV[29]);
	(void)((*(LnkLI122))((V57)));
	princ_str(");",VV[29]);
T199:;
	{object V67 = (VFUN_NARGS=1,(*(LnkLI123))(VV[31]));
	bds_unwind1;
	VMR5(V67)}}
T161:;
	{object V68 = (*(LnkLI117))();
	VMR5(V68)}}}
	}
/*	local entry for function FCALLN-INLINE	*/

static object LI6(va_alist)
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB6 VMS6 VMV6
	{register object V69;
	narg= narg - 0;
	va_start(ap);
	V70 = list_vector(narg,ap);
	V69= V70;
	{register object V71;
	object V72;
	V71= car((V69));
	V72= Cnil;
	(void)((*(LnkLI122))(VV[32]));
	if(!(type_of((V71))==t_cons)){
	goto T217;}
	if((car((V71)))==(VV[23])){
	goto T216;}
T217:;
	V71= list(2,VV[33],(VFUN_NARGS=0,(*(LnkLI124))()));
	princ_str("\n	",VV[29]);
	(void)((*(LnkLI122))((V71)));
	princ_str(" = ",VV[29]);
	(void)((*(LnkLI122))(car((V69))));
	princ_char(44,VV[29]);
T216:;
	princ_str("\n	(type_of(",VV[29]);
	(void)((*(LnkLI122))((V71)));
	princ_str(") == t_sfun ?",VV[29]);
	princ_str("(*(object (*)())((",VV[29]);
	(void)((*(LnkLI122))((V71)));
	princ_str(")->sfn.sfn_self)):",VV[29]);
	if(!(number_compare(symbol_value(VV[34]),small_fixnum(3))<0)){
	goto T235;}
	V72= Ct;
	princ_str("\n	(fcall.argd=",VV[29]);
	V73 = make_fixnum(length(cdr((V69))));
	(void)((*(LnkLI122))(V73));
	princ_str(",type_of(",VV[29]);
	(void)((*(LnkLI122))((V71)));
	princ_str(")==t_vfun) ?",VV[29]);
	princ_str("\n	(*(object (*)())((",VV[29]);
	(void)((*(LnkLI122))((V71)));
	princ_str(")->sfn.sfn_self)):",VV[29]);
T235:;
	princ_str("\n	(fcall.fun=(",VV[29]);
	(void)((*(LnkLI122))((V71)));
	princ_str("),",VV[29]);
	if(((V72))!=Cnil){
	goto T253;}
	princ_str("fcall.argd=",VV[29]);
	V74 = make_fixnum(length(cdr((V69))));
	(void)((*(LnkLI122))(V74));
	princ_char(44,VV[29]);
T253:;
	princ_str("fcalln))(",VV[29]);
	if((cdr((V69)))==Cnil){
	goto T261;}
	(void)((*(LnkLI122))(cadr((V69))));
	{register object V75;
	register object V76;
	V75= cddr((V69));
	V76= car((V75));
T269:;
	if(!(endp((V75)))){
	goto T270;}
	goto T261;
T270:;
	(void)((*(LnkLI122))(VV[35]));
	(void)((*(LnkLI122))((V76)));
	V75= cdr((V75));
	V76= car((V75));
	goto T269;}
T261:;
	(void)((*(LnkLI122))(VV[36]));
	(void)((*(LnkLI122))(VV[36]));
	{object V77 = Cnil;
	VMR6(V77)}}}
	}
/*	local entry for function C2CALL-LAMBDA	*/

static object LI7(V80,V81)

object V80;register object V81;
{	 VMB7 VMS7 VMV7
	bds_check;
TTL:;
	{register object V82;
	V82= caddr((V80));
	if((cadr((V82)))!=Cnil){
	goto T285;}
	if((caddr((V82)))!=Cnil){
	goto T285;}
	if((cadddr((V82)))!=Cnil){
	goto T285;}
	if(type_of((V81))==t_cons||((V81))==Cnil){
	goto T286;}
T285:;
	if(!(type_of((V81))==t_cons||((V81))==Cnil)){
	goto T294;}
	{object V83;
	V83= symbol_value(VV[19]);
	bds_bind(VV[19],symbol_value(VV[19]));
	(void)((*(LnkLI125))((V81)));
	if(((*(LnkLI126))((V82)))==Cnil){
	bds_unwind1;
	goto T294;}
	princ_str("\n	vs_top=(vs_base=base+",VV[29]);
	(void)((*(LnkLI122))((V83)));
	princ_str(")+",VV[29]);
	V84= number_minus((VV[19]->s.s_dbind),(V83));
	(void)((*(LnkLI122))(/* INLINE-ARGS */V84));
	princ_char(59,VV[29]);
	setq(VV[37],Ct);
	bds_unwind1;}
T294:;
	{object V85 = (VFUN_NARGS=2,(*(LnkLI127))((V82),caddr(cddr((V80)))));
	VMR7(V85)}
T286:;
	{object V86;
	object V87;
	V86= make_fixnum(length(car((V82))));
	V87= make_fixnum(length((V81)));{object V88;
	base[1]= (V87);
	base[2]= (V86);
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk128)();
	vs_top=sup;
	V88= vs_base[0];
	if(V88==Cnil)goto T311;
	goto T308;
T311:;}
	(void)((VFUN_NARGS=3,(*(LnkLI129))(VV[38],(V87),(V86))));}
T308:;
	{object V89 = (*(LnkLI130))(car((V82)),(V81),caddr(cddr((V80))));
	VMR7(V89)}}
}
/*	local entry for function CHECK-FNAME-ARGS	*/

static object LI8(V92,V93)

object V92;object V93;
{	 VMB8 VMS8 VMV8
TTL:;
	{register object V94;
	V94= get((V92),VV[39],Ct);
	base[0]= Ct;
	base[1]= (V94);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk100)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T317;}
	goto T316;
T317:;
	if((get((V92),VV[40],Cnil))!=Cnil){
	goto T321;}
	goto T316;
T321:;
	V94= VV[41];
T316:;
	if(!(type_of((V94))==t_cons||((V94))==Cnil)){
	goto T325;}
	if(!(type_of((V93))==t_cons||((V93))==Cnil)){
	goto T325;}
	{register object x= VV[5],V95= (V94);
	while(!endp(V95))
	if(eql(x,V95->c.c_car)){
	goto T325;
	}else V95=V95->c.c_cdr;}{object V96;
	base[0]= make_fixnum(length((V94)));
	base[1]= make_fixnum(length((V93)));
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk128)();
	vs_top=sup;
	V96= vs_base[0];
	if(V96==Cnil)goto T331;
	{object V97 = V96;
	VMR8(V97)}
T331:;}
	V98 = make_fixnum(length((V93)));
	V99 = make_fixnum(length((V94)));
	{object V100 = (VFUN_NARGS=4,(*(LnkLI131))(VV[42],(V92),V98,V99));
	VMR8(V100)}
T325:;
	{object V101 = Cnil;
	VMR8(V101)}}
}
/*	function definition for SAVE-AVMA	*/

static L9()
{register object *base=vs_base;
	register object *sup=base+VM9; VC9
	vs_reserve(VM9);
	{object V102;
	check_arg(1);
	V102=(base[0]);
	vs_top=sup;
TTL:;
	if((symbol_value(VV[43]))!=Cnil){
	goto T336;}{object V103;
	{register object x= VV[44],V104= car((V102));
	while(!endp(V104))
	if(eql(x,V104->c.c_car)){
	V103= V104;
	goto T342;
	}else V104=V104->c.c_cdr;
	V103= Cnil;}
T342:;
	if(V103==Cnil)goto T341;
	setq(VV[43],V103);
	goto T340;
T341:;}{object V105;
	base[1]= cadr((V102));
	base[2]= VV[44];
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk100)();
	vs_top=sup;
	V105= vs_base[0];
	if(V105==Cnil)goto T343;
	setq(VV[43],V105);
	goto T340;
T343:;}
	base[1]= small_fixnum(4);
	base[2]= caddr((V102));
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk132)();
	vs_top=sup;
	setq(VV[43],vs_base[0]);
T340:;
	if((symbol_value(VV[43]))==Cnil){
	goto T336;}
	princ_str("\n	{ save_avma;",VV[29]);
	vs_base=vs_top;
	(void) (*Lnk133)();
	vs_top=sup;{object V106;
	base[1]= symbol_value(VV[45]);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk105)();
	vs_top=sup;
	V106= vs_base[0];
	if(V106==Cnil)goto T352;
	base[1]= V106;
	vs_top=(vs_base=base+1)+1;
	return;
T352:;}
	setq(VV[45],make_cons(symbol_value(VV[45]),VV[46]));
	base[1]= symbol_value(VV[45]);
	vs_top=(vs_base=base+1)+1;
	return;
T336:;
	base[1]= Cnil;
	vs_top=(vs_base=base+1)+1;
	return;
	}
}
/*	local entry for function C2CALL-GLOBAL	*/

static object LI10(V111,V112,V113,V114)

register object V111;register object V112;object V113;object V114;
{	 VMB10 VMS10 VMV10
	bds_check;
TTL:;
	{register object V115;
	V115= Cnil;
	bds_bind(VV[19],symbol_value(VV[19]));
	if(((*(LnkLI134))((V111)))==Cnil){
	goto T358;}
	if(!(type_of((V112))==t_cons||((V112))==Cnil)){
	goto T361;}
	if((symbol_value(VV[47]))==Cnil){
	goto T361;}
	if((symbol_value(VV[48]))==Cnil){
	goto T361;}
	if(!((car(symbol_value(VV[48])))==((V111)))){
	goto T361;}
	{register object x= symbol_value(VV[49]),V116= VV[50];
	while(!endp(V116))
	if(eql(x,V116->c.c_car)){
	goto T371;
	}else V116=V116->c.c_cdr;
	goto T361;}
T371:;
	if(((*(LnkLI135))())==Cnil){
	goto T361;}
	if(!((length((V112)))==(length(cdr(symbol_value(VV[48])))))){
	goto T361;}
	bds_bind(VV[21],VV[22]);
	setq(VV[51],number_plus(symbol_value(VV[51]),small_fixnum(1)));
	bds_bind(VV[49],make_cons(symbol_value(VV[51]),Cnil));
	bds_bind(VV[52],make_cons((VV[49]->s.s_dbind),symbol_value(VV[52])));
	{object V118;
	object V119= cdr(symbol_value(VV[48]));
	if(endp(V119)){
	V117= Cnil;
	goto T380;}
	base[4]=V118=MMcons(Cnil,Cnil);
T381:;
	(V118->c.c_car)= list(2,(V119->c.c_car),Cnil);
	if(endp(V119=MMcdr(V119))){
	V117= base[4];
	goto T380;}
	V118=MMcdr(V118)=MMcons(Cnil,Cnil);
	goto T381;}
T380:;
	(void)((*(LnkLI136))(V117,(V112)));
	if((cdr((VV[49]->s.s_dbind)))==Cnil){
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	goto T375;}
	princ_str("\nT",VV[29]);
	(void)((*(LnkLI122))(car((VV[49]->s.s_dbind))));
	princ_str(":;",VV[29]);
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
T375:;
	(void)((*(LnkLI137))(VV[53]));
	princ_str("\n	goto TTL;",VV[29]);
	{object V121 = (VFUN_NARGS=2,(*(LnkLI138))(VV[54],(V111)));
	bds_unwind1;
	VMR10(V121)}
T361:;
	if(!(type_of((V112))==t_cons||((V112))==Cnil)){
	goto T392;}
	if(((V113))!=Cnil){
	goto T392;}
	V115= (*(LnkLI139))((V111),(V112),(V114));
	if(((V115))==Cnil){
	goto T392;}
	bds_bind(VV[45],small_fixnum(0));
	bds_bind(VV[43],symbol_value(VV[43]));
	base[3]= (V115);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk140)();
	vs_top=sup;
	V122= (*(LnkLI141))((V115),(V112));
	(void)((VFUN_NARGS=3,(*(LnkLI123))(/* INLINE-ARGS */V122,Cnil,(V111))));
	{object V123 = (*(LnkLI142))();
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	VMR10(V123)}
T392:;{object V124;
	V124= get((V111),VV[55],Cnil);
	if(V124==Cnil)goto T406;
	V115= V124;
	goto T405;
T406:;}
	V115= get((V111),VV[56],Cnil);
T405:;
	if(((V115))==Cnil){
	goto T403;}
	(void)((*(LnkLI143))((V111),(V112)));
	(void)((*(LnkLI121))((V112)));
	princ_str("\n	",VV[29]);
	(void)((*(LnkLI122))((V115)));
	princ_str("();",VV[29]);
	{object V125 = (VFUN_NARGS=3,(*(LnkLI123))(VV[31],Cnil,(V111)));
	bds_unwind1;
	VMR10(V125)}
T403:;
	if(!(type_of((V112))==t_cons||((V112))==Cnil)){
	goto T415;}
	if(!((length((V112)))<(10))){
	goto T415;}
	if((symbol_value(VV[57]))!=Cnil){
	goto T420;}
	if((get((V111),VV[58],Cnil))==Cnil){
	goto T415;}
T420:;
	if(!((symbol_value(VV[21]))==(VV[59]))){
	goto T426;}
	base[1]= Ct;
	base[2]= VV[60];
	base[3]= (V111);
	vs_top=(vs_base=base+1)+3;
	(void) (*Lnk144)();
	vs_top=sup;
T426:;
	if((VV[59])==(symbol_value(VV[21]))){
	goto T415;}
	if(((V113))!=Cnil){
	goto T415;}
	bds_bind(VV[45],small_fixnum(0));
	V126= (*(LnkLI145))((V111),(V112));
	V127= (*(LnkLI141))(/* INLINE-ARGS */V126,(V112));
	(void)((VFUN_NARGS=3,(*(LnkLI123))(/* INLINE-ARGS */V127,Cnil,(V111))));
	{object V128 = (*(LnkLI142))();
	bds_unwind1;
	bds_unwind1;
	VMR10(V128)}
T415:;
	(void)((*(LnkLI121))((V112)));
	{object V129;
	V129= (*(LnkLI146))((V111),Cnil,(V112));
	princ_str("\n	(void) (*Lnk",VV[29]);
	(void)((*(LnkLI122))((V129)));
	princ_str(")(",VV[29]);
	if((get((V111),VV[61],Cnil))==Cnil){
	goto T442;}
	princ_str("Lclptr",VV[29]);
	(void)((*(LnkLI122))((V129)));
T442:;
	princ_str(");",VV[29]);
	{object V130 = (VFUN_NARGS=3,(*(LnkLI123))(VV[31],Cnil,(V111)));
	bds_unwind1;
	VMR10(V130)}}
T358:;
	{object V131 = (*(LnkLI147))((V111),(V112),(V113),Cnil);
	bds_unwind1;
	VMR10(V131)}}
}
/*	local entry for function ADD-FAST-LINK	*/

static object LI11(V135,V136,V137)

register object V135;object V136;object V137;
{	 VMB11 VMS11 VMV11
TTL:;
	{object V138;
	object V139;
	object V140;
	register object V141;
	V140= (*(LnkLI148))((V135));
	V138= Cnil;
	V139= Cnil;
	V141= Cnil;
	if(((V136))==Cnil){
	goto T452;}
	{object V142;
	object V143;
	object V144;
	base[0]=MMcons(Cnil,Cnil);
	V142= Cnil;
	V143= Cnil;
	base[2]= (V137);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk98)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T457;}
	V144= Cnil;
	goto T456;
T457:;
	V144= make_fixnum(length((V137)));
T456:;
	if((get((V135),VV[1],Cnil))==Cnil){
	goto T463;}
	V143= get((V135),VV[4],Cnil);
	goto T461;
T463:;
	V142= get((V135),VV[0],Cnil);
	if(((V142))==Cnil){
	goto T466;}
	if(!(type_of((V142))==t_fixnum)){
	goto T471;}{object V145;
	base[2]= (V144);
	base[3]= (V142);
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk75)();
	vs_top=sup;
	V145= vs_base[0];
	if(V145==Cnil)goto T473;
	goto T469;
T473:;}
	(void)((VFUN_NARGS=2,(*(LnkLI131))(VV[62],(V135))));
	goto T469;
T471:;
	(void)(sputprop((V135),VV[0],(V144)));
T469:;
	base[2]= (V144);
	base[3]= VV[63];
	base[4]= Ct;
	vs_top=(vs_base=base+2)+3;
	(void) (*Lnk149)();
	vs_top=sup;
	V143= vs_base[0];
	goto T461;
T466:;
	V143= Cnil;
T461:;
	if((V144)==Cnil){
	goto T480;}{object V146;
	base[2]= (V144);
	base[3]= make_fixnum(length((V143)));
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk128)();
	vs_top=sup;
	V146= vs_base[0];
	if(V146==Cnil)goto T481;
	goto T480;
T481:;}{object V147;
	{register object x= VV[5],V148= (V143);
	while(!endp(V148))
	if(eql(x,V148->c.c_car)){
	V147= V148;
	goto T486;
	}else V148=V148->c.c_cdr;
	V147= Cnil;}
T486:;
	if(V147==Cnil)goto T485;
	goto T480;
T485:;}
	V149 = make_fixnum(length((V143)));
	(void)((VFUN_NARGS=4,(*(LnkLI131))(VV[64],(V135),(V144),V149)));
T480:;
	{register object x= (V135),V150= symbol_value(VV[65]);
	while(!endp(V150))
	if(type_of(V150->c.c_car)==t_cons &&eql(x,V150->c.c_car->c.c_car)){
	V139= (V150->c.c_car);
	goto T489;
	}else V150=V150->c.c_cdr;
	V139= Cnil;}
T489:;
	if((cddr((V139)))!=Cnil){
	goto T450;}
	{register object V151;
	vs_base=vs_top;
	(void) (*Lnk150)();
	vs_top=sup;
	V151= vs_base[0];
	base[2]= (V151);
	base[3]= VV[66];
	base[4]= (V140);
	vs_top=(vs_base=base+2)+3;
	(void) (*Lnk144)();
	vs_top=sup;
	{register object V152;
	register object V153;
	register object V154;
	V152= Cnil;
	V153= (V143);
	V154= small_fixnum(0);
T499:;
	if(((V153))!=Cnil){
	goto T500;}
	goto T497;
T500:;
	if(!((car((V153)))==(VV[5]))){
	goto T506;}
	V141= Ct;
	(void)(princ(VV[67],(V151)));
	goto T504;
T506:;
	if(((V152))==Cnil){
	goto T512;}
	(void)(princ(VV[68],(V151)));
	goto T510;
T512:;
	V152= Ct;
T510:;
	base[2]= (V151);
	base[3]= VV[69];
	base[4]= (V154);
	vs_top=(vs_base=base+2)+3;
	(void) (*Lnk144)();
	vs_top=sup;
T504:;
	V153= cdr((V153));
	V154= number_plus(small_fixnum(1),(V154));
	goto T499;}
T497:;
	(void)(princ(VV[70],(V151)));
	base[2]= (V151);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk151)();
	vs_top=sup;
	(base[0]->c.c_car)= vs_base[0];}
	if(((V141))==Cnil){
	goto T524;}
	V138= 
	make_cclosure_new(LC20,Cnil,base[0],Cdata);
T524:;{object V156;
	V156= get((V135),VV[2],Cnil);
	if(V156==Cnil)goto T531;
	V155= V156;
	goto T530;
T531:;}
	V155= Ct;
T530:;
	if((V138)!=Cnil){
	V157= (V138);
	goto T533;}
	V157= (base[0]->c.c_car);
T533:;
	V158= list(6,(V135),(V143),V155,small_fixnum(3),V157,VV[72]);
	setq(VV[71],make_cons(/* INLINE-ARGS */V158,symbol_value(VV[71])));
	base[2]= Cnil;
	base[3]= VV[73];
	base[4]= (V140);
	vs_top=(vs_base=base+2)+3;
	(void) (*Lnk144)();
	vs_top=sup;
	V159= vs_base[0];{object V161;
	V161= get((V135),VV[2],Cnil);
	if(V161==Cnil)goto T540;
	V160= V161;
	goto T539;
T540:;}
	V160= Ct;
T539:;
	V139= list(4,(V135),V159,V160,(V143));
	goto T450;}
T452:;
	(void)((*(LnkLI143))((V135),(V137)));
	if((get((V135),VV[61],Cnil))==Cnil){
	goto T546;}
	V162= VV[61];
	goto T544;
T546:;
	V162= Cnil;
T544:;
	V139= list(3,(V135),(V140),V162);
T450:;
	base[0]= (V139);
	base[1]= symbol_value(VV[65]);
	base[2]= VV[74];
	base[3]= VV[75];
	vs_top=(vs_base=base+0)+4;
	(void) (*Lnk152)();
	vs_top=sup;
	setq(VV[65],vs_base[0]);
	{object V163 = (V140);
	VMR11(V163)}}
}
/*	local entry for function WT-FUNCTION-LINK	*/

static object LI12(V165)

register object V165;
{	 VMB12 VMS12 VMV12
TTL:;
	{register object V166;
	register object V167;
	register object V168;
	object V169;
	V166= car((V165));
	V167= cadr((V165));
	V168= caddr((V165));
	V169= cadddr((V165));
	if(((V168))!=Cnil){
	goto T560;}
	princ_str("\nstatic LnkT",VV[29]);
	(void)((*(LnkLI122))((V167)));
	princ_str("(){ call_or_link(VV[",VV[29]);
	(void)((*(LnkLI122))((V167)));
	princ_str("],&Lnk",VV[29]);
	(void)((*(LnkLI122))((V167)));
	princ_str(");}",VV[29]);
	goto T558;
T560:;
	if(!(eql((V168),VV[61]))){
	goto T570;}
	princ_str("\nstatic LnkT",VV[29]);
	(void)((*(LnkLI122))((V167)));
	princ_str("(ptr) object *ptr;{ call_or_link_closure(VV[",VV[29]);
	(void)((*(LnkLI122))((V167)));
	princ_str("],&Lnk",VV[29]);
	(void)((*(LnkLI122))((V167)));
	princ_str(",&Lclptr",VV[29]);
	(void)((*(LnkLI122))((V167)));
	princ_str(");}",VV[29]);
	goto T558;
T570:;
	princ_str("\nstatic ",VV[29]);
	V170= (*(LnkLI153))((V168));
	(void)((*(LnkLI122))(/* INLINE-ARGS */V170));
	princ_str(" LnkT",VV[29]);
	(void)((*(LnkLI122))((V167)));
	if(((V169))!=Cnil){
	goto T586;}
	if((Ct)==((V168))){
	goto T587;}
T586:;
	{object V171;
	{register object x= VV[5],V172= (V169);
	while(!endp(V172))
	if(eql(x,V172->c.c_car)){
	V171= V172;
	goto T591;
	}else V172=V172->c.c_cdr;
	V171= Cnil;}
T591:;
	princ_str("(va_alist)va_dcl{va_list ap;va_start(ap);return(",VV[29]);
	V173= (*(LnkLI153))((V168));
	(void)((*(LnkLI122))(/* INLINE-ARGS */V173));
	princ_str(")call_",VV[29]);
	if(((V171))==Cnil){
	goto T599;}
	V174= VV[76];
	goto T597;
T599:;
	V174= VV[77];
T597:;
	(void)((*(LnkLI122))(V174));
	princ_str("proc(VV[",VV[29]);
	V175= (*(LnkLI154))((V166));
	(void)((*(LnkLI122))(/* INLINE-ARGS */V175));
	princ_str("],&Lnk",VV[29]);
	(void)((*(LnkLI122))((V167)));
	if((V171)!=Cnil){
	goto T605;}
	princ_char(44,VV[29]);
	V176 = make_fixnum((*(LnkLI155))((V169),(V168)));
	(void)((*(LnkLI122))(V176));
T605:;
	princ_str(",ap);}",VV[29]);
	goto T558;}
T587:;
	princ_str("(){return call_proc0(VV[",VV[29]);
	V177= (*(LnkLI154))((V166));
	(void)((*(LnkLI122))(/* INLINE-ARGS */V177));
	princ_str("],&Lnk",VV[29]);
	(void)((*(LnkLI122))((V167)));
	princ_str(");}",VV[29]);
T558:;
	V166= symbol_name((V166));
	if(((VFUN_NARGS=2,(*(LnkLI156))(VV[78],(V166))))==Cnil){
	goto T616;}
	V166= (VFUN_NARGS=2,(*(LnkLI157))(VV[78],(V166)));
T616:;
	princ_str(" /* ",VV[29]);
	(void)((*(LnkLI122))((V166)));
	princ_str(" */",VV[29]);
	{object V178 = Cnil;
	VMR12(V178)}}
}
/*	local entry for function WT-FUNCALL-C	*/

static object LI13(V180)

register object V180;
{	 VMB13 VMS13 VMV13
	bds_check;
TTL:;
	{object V181;
	object V182;
	register object V183;
	V181= car((V180));
	V182= cdr((V180));
	V183= Cnil;
	if(!(eql(car((V181)),VV[23]))){
	goto T628;}
	{object V184;
	V184= make_cons(car((V181)),caddr((V181)));
	if((symbol_value(VV[79]))==Cnil){
	goto T631;}
	princ_str("\n	(type_of(",VV[29]);
	base[0]= (V184);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk158)();
	vs_top=sup;
	princ_str(")==t_cfun)||FEinvalid_function(",VV[29]);
	base[0]= (V184);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk158)();
	vs_top=sup;
	princ_str(");",VV[29]);
T631:;
	(void)((*(LnkLI121))((V182)));
	princ_str("\n	(",VV[29]);
	base[0]= (V184);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk158)();
	vs_top=sup;
	goto T626;}
T628:;
	setq(VV[80],number_plus(symbol_value(VV[80]),small_fixnum(1)));
	V183= list(2,VV[33],symbol_value(VV[80]));
	bds_bind(VV[21],(V183));
	princ_str("\n	{object V",VV[29]);
	(void)((*(LnkLI122))(cadr((V183))));
	princ_char(59,VV[29]);
	(void)((*(LnkLI120))(car((V180))));
	(void)((*(LnkLI121))(cdr((V180))));
	princ_str("(V",VV[29]);
	(void)((*(LnkLI122))(cadr((V183))));
	bds_unwind1;
T626:;
	princ_str(")->cf.cf_self ();",VV[29]);
	if((V183)==Cnil){
	goto T623;}
	princ_char(125,VV[29]);}
T623:;
	{object V185 = (VFUN_NARGS=1,(*(LnkLI123))(VV[31]));
	VMR13(V185)}
}
/*	local entry for function INLINE-PROC	*/

static object LI14(V188,V189)

object V188;object V189;
{	 VMB14 VMS14 VMV14
TTL:;
	{register object V190;
	register object V191;
	object V192;
	V190= make_fixnum(length((V189)));
	V191= Cnil;
	V192= (*(LnkLI154))((V188));
	base[2]= Ct;
	base[3]= VV[81];
	base[4]= (V188);
	vs_top=(vs_base=base+2)+3;
	(void) (*Lnk144)();
	vs_top=sup;
	{object V193;
	{object V194= (V190);
	if(!eql(V194,VV[82]))goto T669;
	base[2]= Cnil;
	base[3]= VV[84];
	base[4]= (V192);
	vs_top=(vs_base=base+2)+3;
	(void) (*Lnk144)();
	vs_top=sup;
	V195= vs_base[0];
	V193= list(5,VV[83],Ct,small_fixnum(3),V195,VV[58]);
	goto T668;
T669:;
	if(!eql(V194,VV[85]))goto T674;
	base[2]= Cnil;
	base[3]= VV[87];
	base[4]= (V192);
	vs_top=(vs_base=base+2)+3;
	(void) (*Lnk144)();
	vs_top=sup;
	V196= vs_base[0];
	V193= list(5,VV[86],Ct,small_fixnum(3),V196,VV[58]);
	goto T668;
T674:;
	base[2]= (V190);
	base[3]= VV[63];
	base[4]= Ct;
	vs_top=(vs_base=base+2)+3;
	(void) (*Lnk149)();
	vs_top=sup;
	V197= vs_base[0];
	base[2]= Cnil;
	base[3]= VV[88];
	base[4]= (V192);
	base[5]= (V190);
	{register object V199;
	register object V200;
	V199= (V190);
	V200= small_fixnum(0);
T692:;
	if(!(number_compare((V200),(V199))>=0)){
	goto T693;}
	base[6]= nreverse((V191));
	goto T688;
T693:;
	V191= make_cons((V200),(V191));
	V200= one_plus((V200));
	goto T692;}
T688:;
	vs_top=(vs_base=base+2)+5;
	(void) (*Lnk144)();
	vs_top=sup;
	V198= vs_base[0];
	V193= list(5,V197,Ct,small_fixnum(3),V198,VV[58]);}
T668:;
	V201= make_cons((V188),(V193));
	setq(VV[71],make_cons(/* INLINE-ARGS */V201,symbol_value(VV[71])));
	{object V202 = (V193);
	VMR14(V202)}}}
}
/*	local entry for function WT-SIMPLE-CALL	*/

static object LI15(V205,V204,V203,va_alist)
	object V205,V204,V203;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB15 VMS15 VMV15
	{object V206;
	object V207;
	object V208;
	object V209;
	if(narg <3) too_few_arguments();
	V206= V205;
	V207= V204;
	V208= V203;
	narg = narg - 3;
	if (narg <= 0) goto T704;
	else {
	va_start(ap);
	V209= va_arg(ap,object);}
	--narg; goto T705;
T704:;
	V209= Cnil;
T705:;
	princ_str("simple_",VV[29]);
	(void)((*(LnkLI122))((V206)));
	princ_char(40,VV[29]);
	if(((V209))==Cnil){
	goto T711;}
	princ_str("VV[",VV[29]);
	(void)((*(LnkLI122))((V209)));
	princ_str("],",VV[29]);
T711:;
	princ_str("base+",VV[29]);
	(void)((*(LnkLI122))((V207)));
	princ_char(44,VV[29]);
	(void)((*(LnkLI122))((V208)));
	princ_char(41,VV[29]);
	setq(VV[37],Ct);
	{object V210 = Ct;
	VMR15(V210)}}
	}
/*	local entry for function SAVE-FUNOB	*/

static object LI16(V212)

register object V212;
{	 VMB16 VMS16 VMV16
	bds_check;
TTL:;
	{object V213= car((V212));
	if((V213!= VV[13])
	&& (V213!= VV[159])
	&& (V213!= VV[6]))goto T724;
	{object V214 = Cnil;
	VMR16(V214)}
T724:;
	if((V213!= VV[14]))goto T725;
	if(((*(LnkLI134))(caddr((V212))))==Cnil){
	goto T726;}
	if((get(caddr((V212)),VV[55],Cnil))!=Cnil){
	goto T727;}
	if((get(caddr((V212)),VV[56],Cnil))!=Cnil){
	goto T727;}
	{register object x= caddr((V212)),V215= symbol_value(VV[89]);
	while(!endp(V215))
	if(type_of(V215->c.c_car)==t_cons &&eql(x,V215->c.c_car->c.c_car)){
	goto T727;
	}else V215=V215->c.c_cdr;}
T726:;
	{object V216;
	V216= list(2,VV[27],(*(LnkLI119))());
	if((symbol_value(VV[79]))==Cnil){
	goto T738;}
	princ_str("\n	",VV[29]);
	(void)((*(LnkLI122))((V216)));
	princ_str("=symbol_function(VV[",VV[29]);
	V217= (*(LnkLI148))(caddr((V212)));
	(void)((*(LnkLI122))(/* INLINE-ARGS */V217));
	princ_str("]);",VV[29]);
	goto T736;
T738:;
	princ_str("\n	",VV[29]);
	(void)((*(LnkLI122))((V216)));
	princ_str("=VV[",VV[29]);
	V218= (*(LnkLI148))(caddr((V212)));
	(void)((*(LnkLI122))(/* INLINE-ARGS */V218));
	princ_str("]->s.s_gfdef;",VV[29]);
T736:;
	{object V219 = (V216);
	VMR16(V219)}}
T727:;
	{object V220 = Cnil;
	VMR16(V220)}
T725:;
	if((V213!= VV[18]))goto T750;
	{object V221;
	V221= list(2,VV[27],(*(LnkLI119))());
	bds_bind(VV[21],(V221));
	(void)((*(LnkLI120))(caddr((V212))));
	{object V222 = (V221);
	bds_unwind1;
	VMR16(V222)}}
T750:;
	{object V223 = (*(LnkLI117))();
	VMR16(V223)}}
}
/*	local entry for function PUSH-ARGS	*/

static object LI17(V225)

object V225;
{	 VMB17 VMS17 VMV17
	bds_check;
TTL:;
	if(((V225))!=Cnil){
	goto T754;}
	princ_str("\n	vs_base=vs_top;",VV[29]);
	{object V226 = Cnil;
	VMR17(V226)}
T754:;
	if(!(type_of((V225))==t_cons)){
	goto T758;}
	{object V227;
	V227= symbol_value(VV[19]);
	bds_bind(VV[19],symbol_value(VV[19]));
	{register object V228;
	register object V229;
	V228= (V225);
	V229= car((V228));
T765:;
	if(!(endp((V228)))){
	goto T766;}
	goto T761;
T766:;
	base[2]= list(2,VV[27],(*(LnkLI119))());
	bds_bind(VV[21],base[2]);
	V230= (*(LnkLI120))((V229));
	bds_unwind1;
	V228= cdr((V228));
	V229= car((V228));
	goto T765;}
T761:;
	princ_str("\n	vs_top=(vs_base=base+",VV[29]);
	(void)((*(LnkLI122))((V227)));
	princ_str(")+",VV[29]);
	V231= number_minus((VV[19]->s.s_dbind),(V227));
	(void)((*(LnkLI122))(/* INLINE-ARGS */V231));
	princ_char(59,VV[29]);
	setq(VV[37],Ct);
	{object V232 = Ct;
	bds_unwind1;
	VMR17(V232)}}
T758:;
	{object V233 = Cnil;
	VMR17(V233)}
}
/*	local entry for function PUSH-ARGS-LISPCALL	*/

static object LI18(V235)

object V235;
{	 VMB18 VMS18 VMV18
	bds_check;
TTL:;
	{register object V236;
	register object V237;
	V236= (V235);
	V237= car((V236));
T787:;
	if(!(endp((V236)))){
	goto T788;}
	{object V238 = Cnil;
	VMR18(V238)}
T788:;
	base[1]= list(2,VV[27],(*(LnkLI119))());
	bds_bind(VV[21],base[1]);
	V239= (*(LnkLI120))((V237));
	bds_unwind1;
	V236= cdr((V236));
	V237= car((V236));
	goto T787;}
}
/*	local entry for function C2CALL-UNKNOWN-GLOBAL	*/

static object LI19(V244,V245,V246,V247)

register object V244;register object V245;register object V246;register object V247;
{	 VMB19 VMS19 VMV19
TTL:;
	if((symbol_value(VV[28]))==Cnil){
	goto T800;}
	if(((V246))!=Cnil){
	goto T802;}
	V246= list(2,VV[27],(*(LnkLI119))());
	princ_str("\n	",VV[29]);
	(void)((*(LnkLI122))((V246)));
	princ_str("=symbol_function(VV[",VV[29]);
	V248= (*(LnkLI148))((V244));
	(void)((*(LnkLI122))(/* INLINE-ARGS */V248));
	princ_str("]);",VV[29]);
T802:;
	(void)((*(LnkLI121))((V245)));
	princ_str("\n	funcall_with_catcher(VV[",VV[29]);
	V249= (*(LnkLI148))((V244));
	(void)((*(LnkLI122))(/* INLINE-ARGS */V249));
	princ_str("],",VV[29]);
	(void)((*(LnkLI122))((V246)));
	princ_str(");",VV[29]);
	{object V250 = (VFUN_NARGS=3,(*(LnkLI123))(VV[31],Cnil,(V244)));
	VMR19(V250)}
T800:;
	if(((V246))==Cnil){
	goto T820;}
	(void)((*(LnkLI121))((V245)));
	if(((V247))==Cnil){
	goto T825;}
	if((symbol_value(VV[79]))==Cnil){
	goto T828;}
	princ_str("\n	funcall_no_event(",VV[29]);
	(void)((*(LnkLI122))((V246)));
	princ_str(");",VV[29]);
	goto T823;
T828:;
	princ_str("\n	CMPfuncall(",VV[29]);
	(void)((*(LnkLI122))((V246)));
	princ_str(");",VV[29]);
	goto T823;
T825:;
	princ_str("\n	funcall(",VV[29]);
	(void)((*(LnkLI122))((V246)));
	princ_str(");",VV[29]);
T823:;
	{object V251 = (VFUN_NARGS=1,(*(LnkLI123))(VV[31]));
	VMR19(V251)}
T820:;
	if(((*(LnkLI160))((V245)))==Cnil){
	goto T840;}
	{object V252;
	V252= symbol_value(VV[19]);
	V246= list(2,VV[27],(*(LnkLI119))());
	if((symbol_value(VV[79]))==Cnil){
	goto T846;}
	princ_str("\n	",VV[29]);
	(void)((*(LnkLI122))((V246)));
	princ_str("=symbol_function(VV[",VV[29]);
	V253= (*(LnkLI148))((V244));
	(void)((*(LnkLI122))(/* INLINE-ARGS */V253));
	princ_str("]);",VV[29]);
	goto T844;
T846:;
	princ_str("\n	",VV[29]);
	(void)((*(LnkLI122))((V246)));
	princ_str("=(VV[",VV[29]);
	V254= (*(LnkLI148))((V244));
	(void)((*(LnkLI122))(/* INLINE-ARGS */V254));
	princ_str("]->s.s_gfdef);",VV[29]);
T844:;
	(void)((*(LnkLI125))((V245)));
	if((symbol_value(VV[21]))==(VV[90])){
	goto T859;}
	if(!((symbol_value(VV[21]))==(VV[59]))){
	goto T860;}
T859:;
	princ_str("\n	lispcall",VV[29]);
	if(((V247))==Cnil){
	goto T866;}
	princ_str("_no_event",VV[29]);
T866:;
	princ_str("(base+",VV[29]);
	(void)((*(LnkLI122))((V252)));
	princ_char(44,VV[29]);
	V255 = make_fixnum(length((V245)));
	(void)((*(LnkLI122))(V255));
	princ_str(");",VV[29]);
	setq(VV[37],Ct);
	{object V256 = (VFUN_NARGS=1,(*(LnkLI123))(VV[31]));
	VMR19(V256)}
T860:;
	if(((V247))==Cnil){
	goto T880;}
	V257= VV[92];
	goto T878;
T880:;
	V257= VV[93];
T878:;
	V258 = make_fixnum(length((V245)));
	V259= list(4,VV[91],V257,(V252),V258);
	{object V260 = (VFUN_NARGS=1,(*(LnkLI123))(/* INLINE-ARGS */V259));
	VMR19(V260)}}
T840:;
	{object V261;
	V261= symbol_value(VV[19]);
	(void)((*(LnkLI125))((V245)));
	if((symbol_value(VV[21]))==(VV[90])){
	goto T883;}
	if(!((symbol_value(VV[21]))==(VV[59]))){
	goto T884;}
T883:;
	princ_str("\n	symlispcall",VV[29]);
	if(((V247))==Cnil){
	goto T890;}
	princ_str("_no_event",VV[29]);
T890:;
	princ_str("(VV[",VV[29]);
	V262= (*(LnkLI148))((V244));
	(void)((*(LnkLI122))(/* INLINE-ARGS */V262));
	princ_str("],base+",VV[29]);
	(void)((*(LnkLI122))((V261)));
	princ_char(44,VV[29]);
	V263 = make_fixnum(length((V245)));
	(void)((*(LnkLI122))(V263));
	princ_str(");",VV[29]);
	setq(VV[37],Ct);
	{object V264 = (VFUN_NARGS=3,(*(LnkLI123))(VV[31],Cnil,(V244)));
	VMR19(V264)}
T884:;
	if(((V247))==Cnil){
	goto T906;}
	V265= VV[94];
	goto T904;
T906:;
	V265= VV[95];
T904:;
	V266 = make_fixnum(length((V245)));
	V267= list(5,VV[91],V265,(V261),V266,(*(LnkLI148))((V244)));
	{object V268 = (VFUN_NARGS=3,(*(LnkLI123))(/* INLINE-ARGS */V267,Cnil,(V244)));
	VMR19(V268)}}
}
/*	local function CLOSURE	*/

static LC20(base0)
register object *base0;
{	register object *base=vs_base;
	register object *sup=base+VM20; VC20
	vs_reserve(VM20);
	{object V269;
	vs_top[0]=Cnil;
	{object *p=vs_top;
	 for(;p>vs_base;p--)p[-1]=MMcons(p[-1],p[0]);}
	V269=(base[0]);
	vs_top=sup;
	princ_str("(VFUN_NARGS=",VV[29]);
	V270 = make_fixnum(length((V269)));
	(void)((*(LnkLI122))(V270));
	princ_char(44,VV[29]);
	base[1]= (base0[0]->c.c_car);
	base[2]= (V269);
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk161)();
	vs_top=sup;
	princ_char(41,VV[29]);
	base[1]= Cnil;
	vs_top=(vs_base=base+1)+1;
	return;
	}
}
static LnkT161(){ call_or_link(VV[161],&Lnk161);} /* WT-INLINE-LOC */
static object  LnkTLI160(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[160],&LnkLI160,1,ap);} /* ARGS-CAUSE-SIDE-EFFECT */
static LnkT158(){ call_or_link(VV[158],&Lnk158);} /* WT-LOC */
static object  LnkTLI157(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[157],&LnkLI157,ap);} /* REMOVE */
static object  LnkTLI156(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[156],&LnkLI156,ap);} /* FIND */
static int  LnkTLI155(va_alist)va_dcl{va_list ap;va_start(ap);return(int )call_proc(VV[155],&LnkLI155,258,ap);} /* PROCLAIMED-ARGD */
static object  LnkTLI154(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[154],&LnkLI154,1,ap);} /* ADD-OBJECT */
static object  LnkTLI153(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[153],&LnkLI153,1,ap);} /* REP-TYPE */
static LnkT152(){ call_or_link(VV[152],&Lnk152);} /* ADJOIN */
static LnkT151(){ call_or_link(VV[151],&Lnk151);} /* GET-OUTPUT-STREAM-STRING */
static LnkT150(){ call_or_link(VV[150],&Lnk150);} /* MAKE-STRING-OUTPUT-STREAM */
static LnkT149(){ call_or_link(VV[149],&Lnk149);} /* MAKE-LIST */
static LnkT75(){ call_or_link(VV[75],&Lnk75);} /* EQUAL */
static object  LnkTLI148(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[148],&LnkLI148,1,ap);} /* ADD-SYMBOL */
static object  LnkTLI147(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[147],&LnkLI147,4,ap);} /* C2CALL-UNKNOWN-GLOBAL */
static object  LnkTLI146(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[146],&LnkLI146,3,ap);} /* ADD-FAST-LINK */
static object  LnkTLI145(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[145],&LnkLI145,2,ap);} /* INLINE-PROC */
static LnkT144(){ call_or_link(VV[144],&Lnk144);} /* FORMAT */
static object  LnkTLI143(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[143],&LnkLI143,2,ap);} /* CHECK-FNAME-ARGS */
static object  LnkTLI142(){return call_proc0(VV[142],&LnkLI142);} /* CLOSE-INLINE-BLOCKS */
static object  LnkTLI141(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[141],&LnkLI141,2,ap);} /* GET-INLINE-LOC */
static LnkT140(){ call_or_link(VV[140],&Lnk140);} /* SAVE-AVMA */
static object  LnkTLI139(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[139],&LnkLI139,3,ap);} /* GET-INLINE-INFO */
static object  LnkTLI138(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[138],&LnkLI138,ap);} /* CMPNOTE */
static object  LnkTLI137(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[137],&LnkLI137,1,ap);} /* UNWIND-NO-EXIT */
static object  LnkTLI136(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[136],&LnkLI136,2,ap);} /* C2PSETQ */
static object  LnkTLI135(){return call_proc0(VV[135],&LnkLI135);} /* TAIL-RECURSION-POSSIBLE */
static object  LnkTLI134(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[134],&LnkLI134,1,ap);} /* INLINE-POSSIBLE */
static LnkT133(){ call_or_link(VV[133],&Lnk133);} /* INC-INLINE-BLOCKS */
static LnkT132(){ call_or_link(VV[132],&Lnk132);} /* LOGBITP */
static object  LnkTLI131(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[131],&LnkLI131,ap);} /* CMPWARN */
static object  LnkTLI130(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[130],&LnkLI130,3,ap);} /* C2LET */
static object  LnkTLI129(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[129],&LnkLI129,ap);} /* CMPERR */
static LnkT128(){ call_or_link(VV[128],&Lnk128);} /* EQL */
static object  LnkTLI127(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[127],&LnkLI127,ap);} /* C2LAMBDA-EXPR */
static object  LnkTLI126(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[126],&LnkLI126,1,ap);} /* NEED-TO-SET-VS-POINTERS */
static object  LnkTLI125(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[125],&LnkLI125,1,ap);} /* PUSH-ARGS-LISPCALL */
static object  LnkTLI124(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[124],&LnkLI124,ap);} /* CS-PUSH */
static object  LnkTLI123(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[123],&LnkLI123,ap);} /* UNWIND-EXIT */
static object  LnkTLI122(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[122],&LnkLI122,1,ap);} /* WT1 */
static object  LnkTLI121(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[121],&LnkLI121,1,ap);} /* PUSH-ARGS */
static object  LnkTLI120(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[120],&LnkLI120,1,ap);} /* C2EXPR* */
static object  LnkTLI119(){return call_proc0(VV[119],&LnkLI119);} /* VS-PUSH */
static object  LnkTLI118(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[118],&LnkLI118,2,ap);} /* ARGS-INFO-CHANGED-VARS */
static object  LnkTLI117(){return call_proc0(VV[117],&LnkLI117);} /* BABOON */
static object  LnkTLI116(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[116],&LnkLI116,3,ap);} /* C2FUNCALL-SFUN */
static object  LnkTLI115(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[115],&LnkLI115,2,ap);} /* C2CALL-LAMBDA */
static object  LnkTLI114(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[114],&LnkLI114,2,ap);} /* C2CALL-LOCAL */
static object  LnkTLI113(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[113],&LnkLI113,4,ap);} /* C2CALL-GLOBAL */
static object  LnkTLI112(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[112],&LnkLI112,ap);} /* C2FUNCALL */
static object  LnkTLI111(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[111],&LnkLI111,2,ap);} /* ADD-INFO */
static object  LnkTLI110(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[110],&LnkLI110,1,ap);} /* C1EXPR */
static LnkT109(){ call_or_link(VV[109],&Lnk109);} /* NULL */
static object  LnkTLI108(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[108],&LnkLI108,ap);} /* MAKE-INFO */
static object  LnkTLI107(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[107],&LnkLI107,ap);} /* C1LAMBDA-EXPR */
static LnkT106(){ call_or_link(VV[106],&Lnk106);} /* ENDP */
static LnkT105(){ call_or_link(VV[105],&Lnk105);} /* CONSP */
static object  LnkTLI104(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[104],&LnkLI104,1,ap);} /* CMP-MACROEXPAND */
static object  LnkTLI103(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[103],&LnkLI103,1,ap);} /* CMP-MACRO-FUNCTION */
static LnkT102(){ call_or_link(VV[102],&Lnk102);} /* MACRO-FUNCTION */
static object  LnkTLI101(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[101],&LnkLI101,1,ap);} /* C1LOCAL-FUN */
static LnkT100(){ call_or_link(VV[100],&Lnk100);} /* EQ */
static LnkT99(){ call_or_link(VV[99],&Lnk99);} /* NOT */
static LnkT98(){ call_or_link(VV[98],&Lnk98);} /* LISTP */
static LnkT97(){ call_or_link(VV[97],&Lnk97);} /* < */
static LnkT96(){ call_or_link(VV[96],&Lnk96);} /* SYMBOLP */
