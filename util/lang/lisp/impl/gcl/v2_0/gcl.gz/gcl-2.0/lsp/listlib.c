
#include <cmpinclude.h>
#include "listlib.h"
init_listlib(){do_init(VV);}
/*	local entry for function UNION	*/

static object LI1(V2,V1,va_alist)
	object V2,V1;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB1 VMS1 VMV1
	{object V3;
	register object V4;
	register object V5;
	V3= V2;
	V4= V1;
	narg= narg - 2;
	va_start(ap);
	V6 = list_vector(narg,ap);
	V5= V6;
	{register object V7;
	register object V8;
	V7= Cnil;
	V8= Cnil;
	{register object V9;
	V9= (V3);
T4:;
	if(((V9))!=Cnil){
	goto T5;}
	if(((V8))==Cnil){
	goto T8;}
	((V8))->c.c_cdr = (V4);
T8:;
	if((V7)!=Cnil){
	{object V10 = (V7);
	VMR1(V10)}}
	{object V11 = (V4);
	VMR1(V11)}
T5:;{object V12;
	base[0]= (V9);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk8)();
	vs_top=sup;
	V12= vs_base[0];
	if(V12==Cnil)goto T13;
	goto T12;
T13:;}
	base[0]= VV[0];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk9)();
	vs_top=sup;
T12:;
	base[0]=VV[10]->s.s_gfdef;
	base[1]= CMPcar((V9));
	base[2]= (V4);
	{object V13;
	V13= (V5);
	 vs_top=base+3;
	 while(V13!=Cnil)
	 {vs_push((V13)->c.c_car);V13=(V13)->c.c_cdr;}
	vs_base=base+1;}
	(void) (*Lnk10)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T17;}
	if(((V8))==Cnil){
	goto T24;}
	V14= make_cons(CMPcar((V9)),Cnil);
	((V8))->c.c_cdr = /* INLINE-ARGS */V14;
	V8= CMPcdr((V8));
	goto T17;
T24:;
	V7= make_cons(CMPcar((V9)),Cnil);
	V8= (V7);
T17:;
	V9= CMPcdr((V9));
	goto T4;}}}
	}
/*	local entry for function NUNION	*/

static object LI2(V16,V15,va_alist)
	object V16,V15;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB2 VMS2 VMV2
	{object V17;
	register object V18;
	register object V19;
	V17= V16;
	V18= V15;
	narg= narg - 2;
	va_start(ap);
	V20 = list_vector(narg,ap);
	V19= V20;
	{register object V21;
	register object V22;
	V21= Cnil;
	V22= Cnil;
	{register object V23;
	V23= (V17);
T37:;
	if(((V23))!=Cnil){
	goto T38;}
	if(((V22))==Cnil){
	goto T41;}
	((V22))->c.c_cdr = (V18);
T41:;
	if((V21)!=Cnil){
	{object V24 = (V21);
	VMR2(V24)}}
	{object V25 = (V18);
	VMR2(V25)}
T38:;{object V26;
	base[0]= (V23);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk8)();
	vs_top=sup;
	V26= vs_base[0];
	if(V26==Cnil)goto T46;
	goto T45;
T46:;}
	base[0]= VV[1];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk9)();
	vs_top=sup;
T45:;
	base[0]=VV[10]->s.s_gfdef;
	base[1]= CMPcar((V23));
	base[2]= (V18);
	{object V27;
	V27= (V19);
	 vs_top=base+3;
	 while(V27!=Cnil)
	 {vs_push((V27)->c.c_car);V27=(V27)->c.c_cdr;}
	vs_base=base+1;}
	(void) (*Lnk10)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T50;}
	if(((V22))==Cnil){
	goto T58;}
	((V22))->c.c_cdr = (V23);
	goto T56;
T58:;
	V21= (V23);
T56:;
	V22= (V23);
T50:;
	V23= CMPcdr((V23));
	goto T37;}}}
	}
/*	local entry for function INTERSECTION	*/

static object LI3(V29,V28,va_alist)
	object V29,V28;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB3 VMS3 VMV3
	{object V30;
	register object V31;
	register object V32;
	V30= V29;
	V31= V28;
	narg= narg - 2;
	va_start(ap);
	V33 = list_vector(narg,ap);
	V32= V33;
	{register object V34;
	V34= Cnil;
	{register object V35;
	V35= (V30);
T67:;
	if(((V35))!=Cnil){
	goto T68;}
	{object V36 = (V34);
	VMR3(V36)}
T68:;{object V37;
	base[0]= (V35);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk8)();
	vs_top=sup;
	V37= vs_base[0];
	if(V37==Cnil)goto T73;
	goto T72;
T73:;}
	base[0]= VV[2];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk9)();
	vs_top=sup;
T72:;
	base[0]=VV[10]->s.s_gfdef;
	base[1]= CMPcar((V35));
	base[2]= (V31);
	{object V38;
	V38= (V32);
	 vs_top=base+3;
	 while(V38!=Cnil)
	 {vs_push((V38)->c.c_car);V38=(V38)->c.c_cdr;}
	vs_base=base+1;}
	(void) (*Lnk10)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T77;}
	V34= make_cons(CMPcar((V35)),(V34));
T77:;
	V35= CMPcdr((V35));
	goto T67;}}}
	}
/*	local entry for function NINTERSECTION	*/

static object LI4(V40,V39,va_alist)
	object V40,V39;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB4 VMS4 VMV4
	{object V41;
	register object V42;
	register object V43;
	V41= V40;
	V42= V39;
	narg= narg - 2;
	va_start(ap);
	V44 = list_vector(narg,ap);
	V43= V44;
	{register object V45;
	register object V46;
	V45= Cnil;
	V46= Cnil;
	{register object V47;
	V47= (V41);
T90:;
	if(((V47))!=Cnil){
	goto T91;}
	if(((V46))==Cnil){
	goto T94;}
	((V46))->c.c_cdr = Cnil;
T94:;
	{object V48 = (V45);
	VMR4(V48)}
T91:;{object V49;
	base[0]= (V47);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk8)();
	vs_top=sup;
	V49= vs_base[0];
	if(V49==Cnil)goto T99;
	goto T98;
T99:;}
	base[0]= VV[3];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk9)();
	vs_top=sup;
T98:;
	base[0]=VV[10]->s.s_gfdef;
	base[1]= CMPcar((V47));
	base[2]= (V42);
	{object V50;
	V50= (V43);
	 vs_top=base+3;
	 while(V50!=Cnil)
	 {vs_push((V50)->c.c_car);V50=(V50)->c.c_cdr;}
	vs_base=base+1;}
	(void) (*Lnk10)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T103;}
	if(((V46))==Cnil){
	goto T111;}
	((V46))->c.c_cdr = (V47);
	goto T109;
T111:;
	V45= (V47);
T109:;
	V46= (V47);
T103:;
	V47= CMPcdr((V47));
	goto T90;}}}
	}
/*	local entry for function SET-DIFFERENCE	*/

static object LI5(V52,V51,va_alist)
	object V52,V51;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB5 VMS5 VMV5
	{object V53;
	register object V54;
	register object V55;
	V53= V52;
	V54= V51;
	narg= narg - 2;
	va_start(ap);
	V56 = list_vector(narg,ap);
	V55= V56;
	{register object V57;
	V57= Cnil;
	{register object V58;
	V58= (V53);
T120:;
	if(((V58))!=Cnil){
	goto T121;}
	{object V59 = (V57);
	VMR5(V59)}
T121:;{object V60;
	base[0]= (V58);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk8)();
	vs_top=sup;
	V60= vs_base[0];
	if(V60==Cnil)goto T126;
	goto T125;
T126:;}
	base[0]= VV[4];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk9)();
	vs_top=sup;
T125:;
	base[0]=VV[10]->s.s_gfdef;
	base[1]= CMPcar((V58));
	base[2]= (V54);
	{object V61;
	V61= (V55);
	 vs_top=base+3;
	 while(V61!=Cnil)
	 {vs_push((V61)->c.c_car);V61=(V61)->c.c_cdr;}
	vs_base=base+1;}
	(void) (*Lnk10)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T130;}
	V57= make_cons(CMPcar((V58)),(V57));
T130:;
	V58= CMPcdr((V58));
	goto T120;}}}
	}
/*	local entry for function NSET-DIFFERENCE	*/

static object LI6(V63,V62,va_alist)
	object V63,V62;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB6 VMS6 VMV6
	{object V64;
	register object V65;
	register object V66;
	V64= V63;
	V65= V62;
	narg= narg - 2;
	va_start(ap);
	V67 = list_vector(narg,ap);
	V66= V67;
	{register object V68;
	register object V69;
	V68= Cnil;
	V69= Cnil;
	{register object V70;
	V70= (V64);
T143:;
	if(((V70))!=Cnil){
	goto T144;}
	if(((V69))==Cnil){
	goto T147;}
	((V69))->c.c_cdr = Cnil;
T147:;
	{object V71 = (V68);
	VMR6(V71)}
T144:;{object V72;
	base[0]= (V70);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk8)();
	vs_top=sup;
	V72= vs_base[0];
	if(V72==Cnil)goto T152;
	goto T151;
T152:;}
	base[0]= VV[5];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk9)();
	vs_top=sup;
T151:;
	base[0]=VV[10]->s.s_gfdef;
	base[1]= CMPcar((V70));
	base[2]= (V65);
	{object V73;
	V73= (V66);
	 vs_top=base+3;
	 while(V73!=Cnil)
	 {vs_push((V73)->c.c_car);V73=(V73)->c.c_cdr;}
	vs_base=base+1;}
	(void) (*Lnk10)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T156;}
	if(((V69))==Cnil){
	goto T164;}
	((V69))->c.c_cdr = (V70);
	goto T162;
T164:;
	V68= (V70);
T162:;
	V69= (V70);
T156:;
	V70= CMPcdr((V70));
	goto T143;}}}
	}
/*	local entry for function SET-EXCLUSIVE-OR	*/

static object LI7(V75,V74,va_alist)
	object V75,V74;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB7 VMS7 VMV7
	{object V76;
	object V77;
	object V78;
	object V79;
	object V80;
	object V81;
	V76= V75;
	V77= V74;
	narg= narg - 2;
	va_start(ap);
	V82 = make_list(narg);
	V78= V82;
	{
	parse_key_rest(V82,narg,Vcs +3,&LI7key,ap);
	V79=(Vcs[3]);
	V80=(Vcs[4]);
	V81=(Vcs[5]);
	base[0]= (V76);
	base[1]= (V77);
	{object V84;
	V84= (V78);
	 vs_top=base+2;
	 while(V84!=Cnil)
	 {vs_push((V84)->c.c_car);V84=(V84)->c.c_cdr;}
	vs_base=base+0;}
	(void) (*Lnk14)();
	vs_top=sup;
	V83= vs_base[0];
	base[0]= (V77);
	base[1]= (V76);
	{object V86;
	V86= (V78);
	 vs_top=base+2;
	 while(V86!=Cnil)
	 {vs_push((V86)->c.c_car);V86=(V86)->c.c_cdr;}
	vs_base=base+0;}
	(void) (*Lnk14)();
	vs_top=sup;
	V85= vs_base[0];
	{object V87 = nconc(V83,V85);
	VMR7(V87)}}
	}}
/*	local entry for function NSET-EXCLUSIVE-OR	*/

static object LI8(V89,V88,va_alist)
	object V89,V88;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB8 VMS8 VMV8
	{object V90;
	register object V91;
	register object V92;
	V90= V89;
	V91= V88;
	narg= narg - 2;
	va_start(ap);
	V93 = list_vector(narg,ap);
	V92= V93;
	{object V94;
	register object V95;
	register object V96;
	register object V97;
	V94= Cnil;
	V95= Cnil;
	V96= Cnil;
	V97= Cnil;
	{register object V98;
	V98= (V90);
T184:;
	if(((V98))!=Cnil){
	goto T185;}
	if(((V97))==Cnil){
	goto T188;}
	((V97))->c.c_cdr = Cnil;
T188:;
	if(((V95))==Cnil){
	goto T192;}
	base[0]= (V91);
	base[1]= (V96);
	{object V100;
	V100= (V92);
	 vs_top=base+2;
	 while(V100!=Cnil)
	 {vs_push((V100)->c.c_car);V100=(V100)->c.c_cdr;}
	vs_base=base+0;}
	(void) (*Lnk15)();
	vs_top=sup;
	V99= vs_base[0];
	((V95))->c.c_cdr = V99;
	{object V101 = (V94);
	VMR8(V101)}
T192:;
	base[0]= (V91);
	base[1]= (V96);
	{object V102;
	V102= (V92);
	 vs_top=base+2;
	 while(V102!=Cnil)
	 {vs_push((V102)->c.c_car);V102=(V102)->c.c_cdr;}
	vs_base=base+0;}
	(void) (*Lnk15)();
	vs_top=sup;
	{object V103 = vs_base[0];
	VMR8(V103)}
T185:;{object V104;
	base[0]= (V98);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk8)();
	vs_top=sup;
	V104= vs_base[0];
	if(V104==Cnil)goto T204;
	goto T203;
T204:;}
	base[0]= VV[6];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk9)();
	vs_top=sup;
T203:;
	base[0]=VV[10]->s.s_gfdef;
	base[1]= CMPcar((V98));
	base[2]= (V91);
	{object V105;
	V105= (V92);
	 vs_top=base+3;
	 while(V105!=Cnil)
	 {vs_push((V105)->c.c_car);V105=(V105)->c.c_cdr;}
	vs_base=base+1;}
	(void) (*Lnk10)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T210;}
	if(((V97))==Cnil){
	goto T217;}
	((V97))->c.c_cdr = (V98);
	goto T215;
T217:;
	V96= (V98);
T215:;
	V97= (V98);
	goto T208;
T210:;
	if(((V95))==Cnil){
	goto T223;}
	((V95))->c.c_cdr = (V98);
	goto T221;
T223:;
	V94= (V98);
T221:;
	V95= (V98);
T208:;
	V98= CMPcdr((V98));
	goto T184;}}}
	}
/*	local entry for function SUBSETP	*/

static object LI9(V107,V106,va_alist)
	object V107,V106;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB9 VMS9 VMV9
	{object V108;
	register object V109;
	register object V110;
	object V111;
	object V112;
	object V113;
	V108= V107;
	V109= V106;
	narg= narg - 2;
	va_start(ap);
	V114 = make_list(narg);
	V110= V114;
	{
	parse_key_rest(V114,narg,Vcs +3,&LI9key,ap);
	V111=(Vcs[3]);
	V112=(Vcs[4]);
	V113=(Vcs[5]);
	{register object V115;
	V115= (V108);
T231:;
	if(((V115))!=Cnil){
	goto T232;}
	{object V116 = Ct;
	VMR9(V116)}
T232:;{object V117;
	base[0]= (V115);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk8)();
	vs_top=sup;
	V117= vs_base[0];
	if(V117==Cnil)goto T237;
	goto T236;
T237:;}
	base[0]= VV[7];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk9)();
	vs_top=sup;
T236:;
	base[0]=VV[10]->s.s_gfdef;
	base[1]= CMPcar((V115));
	base[2]= (V109);
	{object V118;
	V118= (V110);
	 vs_top=base+3;
	 while(V118!=Cnil)
	 {vs_push((V118)->c.c_car);V118=(V118)->c.c_cdr;}
	vs_base=base+1;}
	(void) (*Lnk10)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T241;}
	{object V119 = Cnil;
	VMR9(V119)}
T241:;
	V115= CMPcdr((V115));
	goto T231;}}
	}}
static LnkT15(){ call_or_link(VV[15],&Lnk15);} /* NSET-DIFFERENCE */
static LnkT14(){ call_or_link(VV[14],&Lnk14);} /* SET-DIFFERENCE */
static LnkT10(){ call_or_link(VV[10],&Lnk10);} /* MEMBER1 */
static LnkT9(){ call_or_link(VV[9],&Lnk9);} /* ERROR */
static LnkT8(){ call_or_link(VV[8],&Lnk8);} /* CONSP */
