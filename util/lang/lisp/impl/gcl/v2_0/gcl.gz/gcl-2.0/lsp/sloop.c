
#include <cmpinclude.h>
#include "sloop.h"
init_sloop(){do_init(VV);}
/*	macro definition for LCASE	*/

static L1()
{register object *base=vs_base;
	register object *sup=base+VM1; VC1
	vs_reserve(VM1);
	check_arg(2);
	vs_top=sup;
	{object V1=base[0]->c.c_cdr;
	if(endp(V1))invalid_macro_call();
	base[2]= (V1->c.c_car);
	V1=V1->c.c_cdr;
	base[3]= V1;}
	{register object V2;
	register object V3;
	register object V4;
	V2= Cnil;
	V3= Cnil;
	V4= Cnil;
	{register object V5;
	register object V6;
	V5= base[3];
	V6= Cnil;
T3:;
	if(((V3))!=Cnil){
	goto T5;}
	if(((V5))!=Cnil){
	goto T4;}
T5:;
	goto T1;
T4:;
	V6= car((V5));
	if(!(eql(car((V6)),Ct))){
	goto T16;}
	V3= Ct;
	V7= (V6);
	goto T14;
T16:;
	if(!(eql(car((V6)),VV[0]))){
	goto T21;}
	V7= make_cons(VV[1],cdr((V6)));
	goto T14;
T21:;
	if(!(eql(car((V6)),VV[2]))){
	goto T24;}
	V7= make_cons(VV[3],cdr((V6)));
	goto T14;
T24:;
	{register object x= car((V6)),V8= VV[4];
	while(!endp(V8))
	if(eql(x,V8->c.c_car)){
	V4= V8;
	goto T29;
	}else V8=V8->c.c_cdr;
	V4= Cnil;}
T29:;
	if(((V4))==Cnil){
	goto T27;}
	V9= list(3,VV[5],VV[6],list(3,VV[7],VV[8],car((V4))));
	V7= make_cons(/* INLINE-ARGS */V9,cdr((V6)));
	goto T14;
T27:;
	V10= list(3,VV[9],VV[8],list(2,VV[10],car((V6))));
	V7= make_cons(/* INLINE-ARGS */V10,cdr((V6)));
T14:;
	V2= make_cons(V7,(V2));
	V5= cdr((V5));
	goto T3;}
T1:;
	if((V3)!=Cnil){
	goto T33;}
	V2= make_cons(VV[11],(V2));
T33:;
	V11= list(2,VV[8],list(2,VV[13],base[2]));
	V12= make_cons(/* INLINE-ARGS */V11,Cnil);
	V13= nreverse((V2));
	base[4]= list(3,VV[12],/* INLINE-ARGS */V12,make_cons(VV[14],/* INLINE-ARGS */V13));
	vs_top=(vs_base=base+4)+1;
	return;}
}
/*	local entry for function DESETQ1	*/

static object LI2(V16,V17)

register object V16;register object V17;
{	 VMB2 VMS2 VMV2
TTL:;
	if(!(type_of((V16))==t_symbol)){
	goto T36;}
	if((V16)==Cnil){
	{object V18 = Cnil;
	VMR2(V18)}}
	{object V19 = list(3,VV[15],(V16),(V17));
	VMR2(V19)}
T36:;
	if(!(type_of((V16))==t_cons)){
	goto T39;}
	V20= car((V16));
	V21= list(2,VV[17],(V17));
	V22= (*(LnkLI246))(/* INLINE-ARGS */V20,/* INLINE-ARGS */V21);
	if(!(type_of(cdr((V16)))==t_cons)){
	goto T43;}
	V24= cdr((V16));
	V25= list(2,VV[18],(V17));
	V26= (*(LnkLI246))(/* INLINE-ARGS */V24,/* INLINE-ARGS */V25);
	V23= make_cons(/* INLINE-ARGS */V26,Cnil);
	goto T41;
T43:;
	if((cdr((V16)))!=Cnil){
	goto T45;}
	V23= Cnil;
	goto T41;
T45:;
	V27= cdr((V16));
	V28= list(3,VV[15],/* INLINE-ARGS */V27,list(2,VV[18],(V17)));
	V23= make_cons(/* INLINE-ARGS */V28,Cnil);
T41:;
	{object V29 = listA(3,VV[16],/* INLINE-ARGS */V22,V23);
	VMR2(V29)}
T39:;
	base[0]= VV[19];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk247)();
	vs_top=sup;
	{object V30 = vs_base[0];
	VMR2(V30)}
}
/*	macro definition for DESETQ	*/

static L3()
{register object *base=vs_base;
	register object *sup=base+VM3; VC3
	vs_reserve(VM3);
	check_arg(2);
	vs_top=sup;
	{object V31=base[0]->c.c_cdr;
	if(endp(V31))invalid_macro_call();
	base[2]= (V31->c.c_car);
	V31=V31->c.c_cdr;
	if(endp(V31))invalid_macro_call();
	base[3]= (V31->c.c_car);
	V31=V31->c.c_cdr;
	if(!endp(V31))invalid_macro_call();}
	if(!(type_of(base[3])!=t_cons)){
	goto T49;}
	base[4]= (*(LnkLI246))(base[2],base[3]);
	vs_top=(vs_base=base+4)+1;
	return;
T49:;
	{object V32;
	vs_base=vs_top;
	(void) (*Lnk248)();
	vs_top=sup;
	V32= vs_base[0];
	V33= list(2,(V32),base[3]);
	V34= make_cons(/* INLINE-ARGS */V33,Cnil);
	base[4]= list(3,VV[12],/* INLINE-ARGS */V34,(*(LnkLI246))(base[2],(V32)));
	vs_top=(vs_base=base+4)+1;
	return;}
}
/*	macro definition for LOOP-RETURN	*/

static L4()
{register object *base=vs_base;
	register object *sup=base+VM4; VC4
	vs_reserve(VM4);
	check_arg(2);
	vs_top=sup;
	{object V35=base[0]->c.c_cdr;
	base[2]= V35;}
	if(!((length(base[2]))<=(1))){
	goto T53;}
	base[3]= make_cons(VV[20],base[2]);
	vs_top=(vs_base=base+3)+1;
	return;
T53:;
	base[3]= list(2,VV[20],make_cons(VV[21],base[2]));
	vs_top=(vs_base=base+3)+1;
	return;
}
/*	macro definition for LOOP-FINISH	*/

static L5()
{register object *base=vs_base;
	register object *sup=base+VM5; VC5
	vs_reserve(VM5);
	check_arg(2);
	vs_top=sup;
	{object V36=base[0]->c.c_cdr;
	if(!endp(V36))invalid_macro_call();}
	base[2]= VV[22];
	vs_top=(vs_base=base+2)+1;
	return;
}
/*	macro definition for LOCAL-FINISH	*/

static L6()
{register object *base=vs_base;
	register object *sup=base+VM6; VC6
	vs_reserve(VM6);
	check_arg(2);
	vs_top=sup;
	{object V37=base[0]->c.c_cdr;
	if(!endp(V37))invalid_macro_call();}
	base[2]= VV[23];
	vs_top=(vs_base=base+2)+1;
	return;
}
/*	macro definition for SLOOP	*/

static L7()
{register object *base=vs_base;
	register object *sup=base+VM7; VC7
	vs_reserve(VM7);
	check_arg(2);
	vs_top=sup;
	{object V38=base[0]->c.c_cdr;
	base[2]= V38;}
	base[3]= (*(LnkLI249))(base[2]);
	vs_top=(vs_base=base+3)+1;
	return;
}
/*	macro definition for DEF-LOOP-MAP	*/

static L8()
{register object *base=vs_base;
	register object *sup=base+VM8; VC8
	vs_reserve(VM8);
	check_arg(2);
	vs_top=sup;
	{object V39=base[0]->c.c_cdr;
	if(endp(V39))invalid_macro_call();
	base[2]= (V39->c.c_car);
	V39=V39->c.c_cdr;
	if(endp(V39))invalid_macro_call();
	base[3]= (V39->c.c_car);
	V39=V39->c.c_cdr;
	base[4]= V39;}
	base[5]= (VFUN_NARGS=4,(*(LnkLI250))(base[2],base[3],base[4],VV[24]));
	vs_top=(vs_base=base+5)+1;
	return;
}
/*	macro definition for DEF-LOOP-FOR	*/

static L9()
{register object *base=vs_base;
	register object *sup=base+VM9; VC9
	vs_reserve(VM9);
	check_arg(2);
	vs_top=sup;
	{object V40=base[0]->c.c_cdr;
	if(endp(V40))invalid_macro_call();
	base[2]= (V40->c.c_car);
	V40=V40->c.c_cdr;
	if(endp(V40))invalid_macro_call();
	base[3]= (V40->c.c_car);
	V40=V40->c.c_cdr;
	base[4]= V40;}
	base[5]= (VFUN_NARGS=6,(*(LnkLI250))(base[2],base[3],base[4],VV[25],Cnil,small_fixnum(1)));
	vs_top=(vs_base=base+5)+1;
	return;
}
/*	macro definition for DEF-LOOP-MACRO	*/

static L10()
{register object *base=vs_base;
	register object *sup=base+VM10; VC10
	vs_reserve(VM10);
	check_arg(2);
	vs_top=sup;
	{object V41=base[0]->c.c_cdr;
	if(endp(V41))invalid_macro_call();
	base[2]= (V41->c.c_car);
	V41=V41->c.c_cdr;
	if(endp(V41))invalid_macro_call();
	base[3]= (V41->c.c_car);
	V41=V41->c.c_cdr;
	base[4]= V41;}
	base[5]= (VFUN_NARGS=4,(*(LnkLI250))(base[2],base[3],base[4],VV[26]));
	vs_top=(vs_base=base+5)+1;
	return;
}
/*	macro definition for DEF-LOOP-COLLECT	*/

static L11()
{register object *base=vs_base;
	register object *sup=base+VM11; VC11
	vs_reserve(VM11);
	check_arg(2);
	vs_top=sup;
	{object V42=base[0]->c.c_cdr;
	if(endp(V42))invalid_macro_call();
	base[2]= (V42->c.c_car);
	V42=V42->c.c_cdr;
	if(endp(V42))invalid_macro_call();
	base[3]= (V42->c.c_car);
	V42=V42->c.c_cdr;
	base[4]= V42;}
	base[5]= (VFUN_NARGS=7,(*(LnkLI250))(base[2],base[3],base[4],VV[27],VV[28],small_fixnum(2),small_fixnum(2)));
	vs_top=(vs_base=base+5)+1;
	return;
}
/*	macro definition for SLOOP-SWAP	*/

static L12()
{register object *base=vs_base;
	register object *sup=base+VM12; VC12
	vs_reserve(VM12);
	check_arg(2);
	vs_top=sup;
	{object V43=base[0]->c.c_cdr;
	if(!endp(V43))invalid_macro_call();}
	base[2]= VV[29];
	vs_top=(vs_base=base+2)+1;
	return;
}
/*	local entry for function L-EQUAL	*/

static object LI13(V46,V47)

object V46;register object V47;
{	 VMB13 VMS13 VMV13
TTL:;
	base[0]= (V46);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk251)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T55;}
	{object V48 = Cnil;
	VMR13(V48)}
T55:;
	if(!(type_of((V47))==t_symbol)){
	goto T59;}
	base[0]= symbol_name((V46));
	base[1]= symbol_name((V47));
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk113)();
	vs_top=sup;
	{object V49 = vs_base[0];
	VMR13(V49)}
T59:;
	if(!(type_of((V47))==t_cons||((V47))==Cnil)){
	goto T64;}
	base[0]= (V46);
	base[1]= (V47);
	base[2]= VV[30];
	base[3]= VV[9];
	vs_top=(vs_base=base+0)+4;
	(void) (*Lnk252)();
	vs_top=sup;
	{object V50 = vs_base[0];
	VMR13(V50)}
T64:;
	{object V51 = Cnil;
	VMR13(V51)}
}
/*	local entry for function LOOP-COLLECT-KEYWORD-P	*/

static object LI14(V53)

object V53;
{	 VMB14 VMS14 VMV14
TTL:;{object V54;
	base[0]= (V53);
	base[1]= VV[31];
	base[2]= VV[30];
	base[3]= VV[9];
	vs_top=(vs_base=base+0)+4;
	(void) (*Lnk252)();
	vs_top=sup;
	V54= vs_base[0];
	if(V54==Cnil)goto T70;
	{object V55 = V54;
	VMR14(V55)}
T70:;}
	{object V56 = (VFUN_NARGS=4,(*(LnkLI253))((V53),symbol_value(VV[28]),VV[30],VV[9]));
	VMR14(V56)}
}
/*	local entry for function TRANSLATE-NAME	*/

static object LI15(V58)

object V58;
{	 VMB15 VMS15 VMV15
TTL:;
	{object V59;
	base[0]= (V58);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk251)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T77;}
	V59= Cnil;
	goto T76;
T77:;
	base[0]= (V58);
	base[1]= symbol_value(VV[32]);
	base[2]= VV[30];
	base[3]= VV[9];
	base[4]= VV[33];
	base[5]= VV[17];
	vs_top=(vs_base=base+0)+6;
	(void) (*Lnk252)();
	vs_top=sup;
	V60= vs_base[0];
	V59= cdar(V60);
T76:;
	if(((V59))==Cnil){
	goto T88;}
	{object V61 = (V59);
	VMR15(V61)}
T88:;
	{object V62 = (V58);
	VMR15(V62)}}
}
/*	local entry for function LOOP-POP	*/

static object LI16()

{	 VMB16 VMS16 VMV16
TTL:;
	if((symbol_value(VV[34]))==Cnil){
	goto T91;}
	{object V63;
	V63= car(symbol_value(VV[34]));
	setq(VV[34],cdr(symbol_value(VV[34])));
	setq(VV[35],(V63));}
	{object V64 = symbol_value(VV[35]);
	VMR16(V64)}
T91:;
	setq(VV[35],VV[36]);
	{object V65 = Cnil;
	VMR16(V65)}
}
/*	local entry for function LOOP-UN-POP	*/

static object LI17()

{	 VMB17 VMS17 VMV17
TTL:;
	{object V66= symbol_value(VV[35]);
	if((V66!= VV[36]))goto T99;
	{object V67 = Cnil;
	VMR17(V67)}
T99:;
	if((V66!= VV[254]))goto T100;
	base[0]= VV[37];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk247)();
	vs_top=sup;
	{object V68 = vs_base[0];
	VMR17(V68)}
T100:;
	setq(VV[34],make_cons(symbol_value(VV[35]),symbol_value(VV[34])));
	setq(VV[35],VV[38]);
	{object V69 = VV[38];
	VMR17(V69)}}
}
/*	local entry for function LOOP-PEEK	*/

static object LI18()

{	 VMB18 VMS18 VMV18
TTL:;
	{object V70 = car(symbol_value(VV[34]));
	VMR18(V70)}
}
/*
	local entry for function LOOP-LET-BINDINGS	*/

static object LI19(V72)

register object V72;
{	 VMB19 VMS19 VMV19
TTL:;
	{register object V73;
	V73= car((V72));
T107:;
	if(((V73))!=Cnil){
	goto T108;}
	{object V74 = nreverse(car((V72)));
	VMR19(V74)}
T108:;{object V75;
	V75= cdar((V73));
	if(V75==Cnil)goto T113;
	goto T112;
T113:;}
	{register object V76;
	register object V77;
	V76= (V73);
	V77= caar((V73));
	if(type_of((V76))!=t_cons)FEwrong_type_argument(Scons,(V76));
	((V76))->c.c_car = (V77);}
T112:;
	V73= cdr((V73));
	goto T107;}
}
/*	local entry for function PARSE-LOOP	*/

static object LI20(V79)

object V79;
{	 VMB20 VMS20 VMV20
	bds_check;
TTL:;
	{register object V80;
	V80= Cnil;
	{register object V81;
	register object V82;
	bds_bind(VV[34],(V79));
	bds_bind(VV[54],symbol_value(VV[54]));
	bds_bind(VV[35],Cnil);
	bds_bind(VV[53],Cnil);
	bds_bind(VV[49],Cnil);
	bds_bind(VV[51],Cnil);
	bds_bind(VV[48],Cnil);
	bds_bind(VV[50],Cnil);
	bds_bind(VV[43],Cnil);
	bds_bind(VV[42],Cnil);
	bds_bind(VV[52],Cnil);
	bds_bind(VV[44],Cnil);
	bds_bind(VV[45],Cnil);
	bds_bind(VV[47],Cnil);
	bds_bind(VV[41],Cnil);
	bds_bind(VV[46],Cnil);
	bds_bind(VV[40],Cnil);
	bds_bind(VV[39],Cnil);
	V81= Cnil;
	V82= VV[55];
	if(!(type_of(car((VV[34]->s.s_dbind)))==t_symbol)){
	goto T123;}
	if((car((VV[34]->s.s_dbind)))!=Cnil){
	goto T122;}
T123:;
	(VV[34]->s.s_dbind)= make_cons(VV[56],(VV[34]->s.s_dbind));
T122:;
	(void)((*(LnkLI255))());
	if(((VV[53]->s.s_dbind))!=Cnil){
	goto T130;}
	if(((VV[40]->s.s_dbind))==Cnil){
	goto T129;}
T130:;
	if((VV[51]->s.s_dbind)!=Cnil){
	goto T134;}
	base[18]= VV[57];
	vs_top=(vs_base=base+18)+1;
	(void) (*Lnk248)();
	vs_top=sup;
	(VV[51]->s.s_dbind)= vs_base[0];
T134:;
	base[18]= VV[55];
	base[19]= (V82);
	vs_top=(vs_base=base+18)+2;
	(void) (*Lnk256)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T137;}
	goto T129;
T137:;
	base[18]= VV[58];
	vs_top=(vs_base=base+18)+1;
	(void) (*Lnk248)();
	vs_top=sup;
	V82= vs_base[0];
T129:;
	V83= list(3,VV[59],VV[60],list(4,VV[61],VV[62],list(2,VV[10],(VV[51]->s.s_dbind)),VV[63]));
	V81= make_cons(/* INLINE-ARGS */V83,(V81));
	V84= list(3,VV[64],Cnil,list(3,VV[61],VV[65],list(2,VV[10],(V82))));
	V81= make_cons(/* INLINE-ARGS */V84,(V81));
	V85= list(3,VV[66],Cnil,list(3,VV[61],VV[67],list(2,VV[10],(V82))));
	V81= make_cons(/* INLINE-ARGS */V85,(V81));
	if((VV[45]->s.s_dbind)==Cnil){
	goto T149;}
	V86= list(3,VV[68],(VV[51]->s.s_dbind),(VV[45]->s.s_dbind));
	(VV[43]->s.s_dbind)= make_cons(/* INLINE-ARGS */V86,(VV[43]->s.s_dbind));
T149:;
	base[18]= (VV[41]->s.s_dbind);
	base[19]= nreverse((VV[49]->s.s_dbind));
	base[20]= nreverse((VV[42]->s.s_dbind));
	vs_top=(vs_base=base+18)+3;
	(void) (*Lnk114)();
	vs_top=sup;
	V80= vs_base[0];
	if(((VV[53]->s.s_dbind))==Cnil){
	goto T158;}
	V80= (*(LnkLI257))((V80));
	goto T156;
T158:;
	V87= append((V80),VV[70]);
	V80= make_cons(VV[69],/* INLINE-ARGS */V87);
T156:;
	{register object V88;{object V89;
	V89= (VV[51]->s.s_dbind);
	base[18]= nreverse((VV[48]->s.s_dbind));
	base[19]= (V80);
	base[20]= make_cons((V82),Cnil);
	base[21]= nreverse((VV[43]->s.s_dbind));
	base[22]= VV[74];
	vs_top=(vs_base=base+18)+5;
	(void) (*Lnk114)();
	vs_top=sup;
	V90= vs_base[0];
	V88= list(3,VV[71],(V81),list(3,VV[72],V89,make_cons(VV[73],V90)));}
	if(eql(symbol_value(VV[75]),symbol_value(VV[76]))){
	goto T169;}
	base[18]= (V88);
	vs_top=(vs_base=base+18)+1;
	(void) (*Lnk258)();
	vs_top=sup;
	V88= vs_base[0];
T169:;
	{register object V91;
	register object V92;
	V91= (VV[46]->s.s_dbind);
	V92= car((V91));
T178:;
	if(!(endp((V91)))){
	goto T179;}
	goto T174;
T179:;
	V93= (*(LnkLI259))((V92));
	if((cdr((V92)))!=Cnil){
	goto T186;}
	V94= Cnil;
	goto T185;
T186:;
	V95= make_cons(VV[77],cdr((V92)));
	V94= make_cons(/* INLINE-ARGS */V95,Cnil);
T185:;
	V96= make_cons((V88),Cnil);
	V88= listA(3,VV[12],/* INLINE-ARGS */V93,append(V94,/* INLINE-ARGS */V96));
	V91= cdr((V91));
	V92= car((V91));
	goto T178;}
T174:;
	{object V97 = (V88);
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	VMR20(V97)}}}}
}
/*	local entry for function PARSE-LOOP1	*/

static object LI21()

{	 VMB21 VMS21 VMV21
TTL:;
	{object V98;
	V99= (*(LnkLI260))();
	V98= (*(LnkLI13))(/* INLINE-ARGS */V99);
	if(((*(LnkLI9))((V98),VV[78]))==Cnil){
	goto T193;}
	(void)((*(LnkLI261))());
	setq(VV[51],(*(LnkLI261))());}
T193:;
	{register object V100;
	V100= (*(LnkLI261))();
T201:;
	if(((V100))!=Cnil){
	goto T202;}
	if((symbol_value(VV[34]))!=Cnil){
	goto T202;}
	{object V101 = Cnil;
	VMR21(V101)}
T202:;
	{register object V102;
	V102= (*(LnkLI13))((V100));
	{register object V103;
	V103= (*(LnkLI262))((V102));
	if(((V103))==Cnil){
	goto T212;}
	goto T208;
T212:;
	if(((*(LnkLI9))((V102),VV[25]))==Cnil){
	goto T215;}
	(void)((*(LnkLI263))());
	goto T208;
T215:;
	if(((*(LnkLI9))((V102),VV[79]))==Cnil){
	goto T218;}
	V104= (*(LnkLI261))();
	V105= list(3,VV[80],/* INLINE-ARGS */V104,VV[81]);
	setq(VV[49],make_cons(/* INLINE-ARGS */V105,symbol_value(VV[49])));
	goto T208;
T218:;
	if(((*(LnkLI9))((V102),VV[82]))==Cnil){
	goto T222;}
	V106= (*(LnkLI261))();
	V107= list(3,VV[5],/* INLINE-ARGS */V106,VV[83]);
	setq(VV[49],make_cons(/* INLINE-ARGS */V107,symbol_value(VV[49])));
	goto T208;
T222:;
	if(((*(LnkLI9))((V102),VV[56]))==Cnil){
	goto T226;}
	V108= (*(LnkLI264))();
	setq(VV[49],append(/* INLINE-ARGS */V108,symbol_value(VV[49])));
	goto T208;
T226:;
	if(((*(LnkLI9))((V102),VV[84]))==Cnil){
	goto T230;}
	V109= (*(LnkLI265))();
	setq(VV[49],append(/* INLINE-ARGS */V109,symbol_value(VV[49])));
	goto T208;
T230:;
	if(((*(LnkLI266))((V102)))==Cnil){
	goto T234;}
	V110= (*(LnkLI267))();
	setq(VV[49],append(/* INLINE-ARGS */V110,symbol_value(VV[49])));
	goto T208;
T234:;
	base[0]= VV[85];
	base[1]= (V102);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk247)();
	vs_top=sup;}}
T208:;
	V100= (*(LnkLI261))();
	goto T201;}
}
/*	local entry for function PARSE-NO-BODY	*/

static object LI22(V112)

object V112;
{	 VMB22 VMS22 VMV22
TTL:;
	{register object V113;
	register object V114;
	V113= Ct;
	V114= Ct;
	{register object V115;
	V115= (V112);
T246:;
	if(((V114))!=Cnil){
	goto T247;}
	if((symbol_value(VV[34]))!=Cnil){
	goto T247;}
	goto T244;
T247:;
	{register object V116;
	V116= (*(LnkLI13))((V115));
	if(((*(LnkLI9))((V116),VV[86]))==Cnil){
	goto T256;}
	(void)((*(LnkLI268))((V115)));
	goto T253;
T256:;
	if(((*(LnkLI9))((V116),Cnil))==Cnil){
	goto T259;}
	goto T253;
T259:;
	if(((*(LnkLI9))((V116),VV[87]))==Cnil){
	goto T262;}
	(void)((VFUN_NARGS=0,(*(LnkLI269))()));
	goto T253;
T262:;
	if(((*(LnkLI9))((V116),VV[77]))==Cnil){
	goto T265;}
	V117= (*(LnkLI261))();
	(void)((VFUN_NARGS=2,(*(LnkLI270))(/* INLINE-ARGS */V117,Ct)));
	goto T253;
T265:;
	if(((*(LnkLI9))((V116),VV[88]))==Cnil){
	goto T268;}
	setq(VV[47],(*(LnkLI261))());
	goto T253;
T268:;
	if(((*(LnkLI9))((V116),VV[89]))==Cnil){
	goto T272;}
	V118= (*(LnkLI264))();
	setq(VV[42],append(/* INLINE-ARGS */V118,symbol_value(VV[42])));
	goto T253;
T272:;
	if(((*(LnkLI9))((V116),VV[90]))==Cnil){
	goto T276;}
	V119= (*(LnkLI264))();
	setq(VV[41],append(/* INLINE-ARGS */V119,symbol_value(VV[41])));
	goto T253;
T276:;
	if(((*(LnkLI9))((V116),VV[91]))==Cnil){
	goto T280;}
	(void)((VFUN_NARGS=2,(*(LnkLI269))(Cnil,Ct)));
	goto T253;
T280:;
	if(!(type_of((V116))==t_symbol)){
	goto T283;}
	if((get((V116),VV[92],Cnil))==Cnil){
	goto T283;}
	(void)((VFUN_NARGS=2,(*(LnkLI271))((V115),VV[92])));
	goto T253;
T283:;
	if(((V114))==Cnil){
	goto T289;}
	V113= Cnil;
	goto T287;
T289:;
	(void)((*(LnkLI272))());
T287:;
	goto T244;}
T253:;
	V114= Cnil;
	V115= (*(LnkLI261))();
	goto T246;}
T244:;
	{object V120 = (V113);
	VMR22(V120)}}
}
/*	local entry for function PARSE-LOOP-WITH	*/

static object LI23(va_alist)
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB23 VMS23 VMV23
	{object V121;
	object V122;
	narg = narg - 0;
	if (narg <= 0) goto T297;
	else {
	va_start(ap);
	V121= va_arg(ap,object);}
	if (--narg <= 0) goto T298;
	else {
	V122= va_arg(ap,object);}
	--narg; goto T299;
T297:;
	V121= Cnil;
T298:;
	V122= Cnil;
T299:;
	{register object V123;
	V123= (*(LnkLI261))();
	{object V124;
	V125= (*(LnkLI260))();
	V124= (*(LnkLI13))(/* INLINE-ARGS */V125);
	if(((*(LnkLI9))((V124),VV[94]))==Cnil){
	goto T306;}
	(void)((*(LnkLI261))());{object V126;
	base[0]= (V123);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk251)();
	vs_top=sup;
	V126= vs_base[0];
	if(V126==Cnil)goto T310;
	goto T309;
T310:;}
	base[0]= VV[95];
	base[1]= (V123);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk247)();
	vs_top=sup;
T309:;
	V127= (*(LnkLI261))();
	base[0]= (V121);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk105)();
	vs_top=sup;
	V128= vs_base[0];
	(void)((VFUN_NARGS=7,(*(LnkLI273))((V123),/* INLINE-ARGS */V127,V128,Cnil,Cnil,Ct,(V122))));
	goto T303;
T306:;
	base[0]= (V121);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk105)();
	vs_top=sup;
	V129= vs_base[0];
	(void)((VFUN_NARGS=5,(*(LnkLI274))((V123),Cnil,Cnil,V129,(V122))));}
T303:;
	{object V130;
	V131= (*(LnkLI260))();
	V130= (*(LnkLI13))(/* INLINE-ARGS */V131);
	if(((*(LnkLI9))((V130),VV[5]))==Cnil){
	goto T321;}
	(void)((*(LnkLI261))());
	{object V132;
	V133= (*(LnkLI261))();
	V132= (*(LnkLI13))(/* INLINE-ARGS */V133);
	if(((*(LnkLI9))((V132),VV[87]))==Cnil){
	goto T326;}
	{object V134 = (VFUN_NARGS=1,(*(LnkLI269))(Ct));
	VMR23(V134)}
T326:;
	if(((*(LnkLI9))((V132),VV[91]))==Cnil){
	goto T329;}
	{object V135 = (VFUN_NARGS=2,(*(LnkLI269))(Ct,Ct));
	VMR23(V135)}
T329:;
	(void)((*(LnkLI272))());
	{object V136 = (VFUN_NARGS=1,(*(LnkLI269))(Ct));
	VMR23(V136)}}
T321:;
	{object V137 = Cnil;
	VMR23(V137)}}}}
	}
/*	local entry for function PARSE-LOOP-DO	*/

static object LI24()

{	 VMB24 VMS24 VMV24
TTL:;
	{register object V138;
	V138= Cnil;
	{register object V139;
	V139= (*(LnkLI261))();
T336:;
	if(!(type_of((V139))==t_cons||((V139))==Cnil)){
	goto T341;}
	V138= make_cons((V139),(V138));
	if(symbol_value(VV[34])!=Cnil){
	goto T339;}
	goto T333;
T341:;
	(void)((*(LnkLI272))());
	goto T333;
T339:;
	V139= (*(LnkLI261))();
	goto T336;}
T333:;
	if((V138)!=Cnil){
	goto T349;}
	base[0]= VV[96];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk247)();
	vs_top=sup;
T349:;
	{object V140 = (V138);
	VMR24(V140)}}
}
/*	local entry for function PARSE-LOOP-INITIALLY	*/

static object LI25(V142)

object V142;
{	 VMB25 VMS25 VMV25
TTL:;
	{object V143;
	V143= (*(LnkLI13))((V142));
	if(((*(LnkLI9))((V143),VV[97]))==Cnil){
	goto T353;}
	{object V144;
	V144= (*(LnkLI264))();
	{register object V145;
	register object V146;
	V145= nreverse((V144));
	V146= car((V145));
T359:;
	if(!(endp((V145)))){
	goto T360;}
	{object V147 = Cnil;
	VMR25(V147)}
T360:;
	{register object V148;
	base[2]= (V146);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk275)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T366;}
	V148= Cnil;
	goto T365;
T366:;
	{register object x= car((V146)),V149= VV[98];
	while(!endp(V149))
	if(eql(x,V149->c.c_car)){
	goto T369;
	}else V149=V149->c.c_cdr;}
	V148= Cnil;
	goto T365;
T369:;
	base[2]= make_fixnum(length((V146)));
	base[3]= small_fixnum(3);
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk256)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T371;}
	V148= Cnil;
	goto T365;
T371:;
	base[2]= cadr((V146));
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk251)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T375;}
	V148= Cnil;
	goto T365;
T375:;
	base[2]= caddr((V146));
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk276)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T378;}
	V148= Cnil;
	goto T365;
T378:;
	{register object x= cadr((V146)),V150= caar(symbol_value(VV[46]));
	while(!endp(V150))
	if(type_of(V150->c.c_car)==t_cons &&eql(x,V150->c.c_car->c.c_car)){
	goto T381;
	}else V150=V150->c.c_cdr;}
	V148= Cnil;
	goto T365;
T381:;
	V148= (VFUN_NARGS=7,(*(LnkLI273))(cadr((V146)),caddr((V146)),Cnil,Cnil,Cnil,Ct,Ct));
T365:;
	if(((V148))==Cnil){
	goto T384;}
	goto T364;
T384:;
	setq(VV[48],make_cons((V146),symbol_value(VV[48])));}
T364:;
	V145= cdr((V145));
	V146= car((V145));
	goto T359;}}
T353:;
	if(((*(LnkLI9))((V143),VV[99]))==Cnil){
	goto T393;}
	V151= (*(LnkLI264))();
	setq(VV[43],append(/* INLINE-ARGS */V151,symbol_value(VV[43])));
	{object V152 = symbol_value(VV[43]);
	VMR25(V152)}
T393:;
	base[0]= VV[85];
	base[1]= (V143);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk247)();
	vs_top=sup;
	{object V153 = vs_base[0];
	VMR25(V153)}}
}
/*	local entry for function PARSE-ONE-WHEN-CLAUSE	*/

static object LI26()

{	 VMB26 VMS26 VMV26
TTL:;
	{register object V154;
	register object V155;
	register object V156;
	V154= Cnil;
	V155= VV[100];
	V156= Cnil;
T403:;
	base[0]= symbol_value(VV[34]);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk140)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T406;}
	goto T405;
T406:;
	goto T401;
T405:;
	V156= (*(LnkLI261))();
	{register object V157;
	V157= (*(LnkLI13))((V156));
	{register object V158;
	V158= (*(LnkLI262))((V157));
	if(((V158))==Cnil){
	goto T415;}
	goto T411;
T415:;
	if(((*(LnkLI266))((V157)))==Cnil){
	goto T418;}{object V159;
	base[0]= VV[100];
	base[1]= (V155);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk256)();
	vs_top=sup;
	V159= vs_base[0];
	if(V159==Cnil)goto T421;
	goto T420;
T421:;}
	goto T404;
T420:;
	V160= (*(LnkLI267))();
	V154= append(/* INLINE-ARGS */V160,(V154));
	V155= VV[5];
	goto T411;
T418:;
	if(((*(LnkLI9))((V157),VV[101]))==Cnil){
	goto T429;}{object V161;
	base[0]= VV[100];
	base[1]= (V155);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk256)();
	vs_top=sup;
	V161= vs_base[0];
	if(V161==Cnil)goto T432;
	goto T431;
T432:;}
	goto T404;
T431:;
	V162= (*(LnkLI265))();
	V154= append(/* INLINE-ARGS */V162,(V154));
	V155= VV[5];
	goto T411;
T429:;
	if(((*(LnkLI9))((V157),VV[56]))==Cnil){
	goto T440;}{object V163;
	base[0]= VV[100];
	base[1]= (V155);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk256)();
	vs_top=sup;
	V163= vs_base[0];
	if(V163==Cnil)goto T443;
	goto T442;
T443:;}
	goto T404;
T442:;
	V164= (*(LnkLI264))();
	V154= append(/* INLINE-ARGS */V164,(V154));
	V155= VV[5];
	goto T411;
T440:;
	if(((*(LnkLI9))((V157),VV[5]))==Cnil){
	goto T451;}{object V165;
	base[0]= VV[5];
	base[1]= (V155);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk256)();
	vs_top=sup;
	V165= vs_base[0];
	if(V165==Cnil)goto T454;
	goto T453;
T454:;}
	base[0]= VV[102];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk247)();
	vs_top=sup;
T453:;
	V155= VV[100];
	goto T411;
T451:;
	(void)((*(LnkLI272))());
	goto T401;}}
T411:;
	goto T403;
T404:;
	(void)((*(LnkLI272))());
	goto T401;
T401:;
	if((V154)!=Cnil){
	goto T462;}
	base[0]= VV[103];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk247)();
	vs_top=sup;
T462:;
	{object V166 = (V154);
	VMR26(V166)}}
}
/*	local entry for function PARSE-LOOP-WHEN	*/

static object LI27()

{	 VMB27 VMS27 VMV27
TTL:;
	{object V167;
	object V168;
	object V169;
	V167= Cnil;
	V168= Cnil;
	V169= Cnil;
	{object V170;
	if(((*(LnkLI9))(symbol_value(VV[35]),VV[104]))==Cnil){
	goto T469;}
	V170= list(2,VV[105],(*(LnkLI261))());
	goto T467;
T469:;
	V170= (*(LnkLI261))();
T467:;
	V167= (*(LnkLI277))();
	{object V171;
	V172= (*(LnkLI260))();
	V171= (*(LnkLI13))(/* INLINE-ARGS */V172);
	if(((*(LnkLI9))((V171),VV[106]))==Cnil){
	goto T473;}
	(void)((*(LnkLI261))());
	V168= Ct;
	V169= (*(LnkLI277))();}
T473:;
	V173= nreverse((V167));
	V174= make_cons((V170),/* INLINE-ARGS */V173);
	if((V168)==Cnil){
	V175= Cnil;
	goto T481;}
	V176= nreverse((V169));
	V177= make_cons(Ct,/* INLINE-ARGS */V176);
	V175= make_cons(/* INLINE-ARGS */V177,Cnil);
T481:;
	V178= listA(3,VV[14],/* INLINE-ARGS */V174,V175);
	{object V179 = make_cons(/* INLINE-ARGS */V178,Cnil);
	VMR27(V179)}}}
}
/*	local entry for function POINTER-FOR-COLLECT	*/

static object LI28(V181)

object V181;
{	 VMB28 VMS28 VMV28
TTL:;{object V182;
	{register object x= (V181),V184= symbol_value(VV[52]);
	while(!endp(V184))
	if(type_of(V184->c.c_car)==t_cons &&eql(x,V184->c.c_car->c.c_car)){
	V183= (V184->c.c_car);
	goto T484;
	}else V184=V184->c.c_cdr;
	V183= Cnil;}
T484:;
	V182= cdr(V183);
	if(V182==Cnil)goto T482;
	{object V185 = V182;
	VMR28(V185)}
T482:;}
	{object V186;
	base[0]= VV[107];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk248)();
	vs_top=sup;
	V187= vs_base[0];
	V186= (VFUN_NARGS=4,(*(LnkLI273))(V187,Cnil,Cnil,VV[0]));
	V188= make_cons((V181),(V186));
	setq(VV[52],make_cons(/* INLINE-ARGS */V188,symbol_value(VV[52])));
	{object V189 = (V186);
	VMR28(V189)}}
}
/*	local entry for function PARSE-LOOP-COLLECT	*/

static object LI29()

{	 VMB29 VMS29 VMV29
TTL:;
	{register object V190;
	register object V191;
	register object V192;
	V190= Cnil;
	V191= Cnil;
	V192= Cnil;
	if(symbol_value(VV[50])==Cnil){
	goto T493;}
	{frame_ptr fr;
	fr=frs_sch_catch(VV[27]);
	if(fr==NULL) FEerror("The tag ~s is undefined.",1,VV[27]);
	base[0]= Cnil;
	vs_top=(vs_base=base+0)+1;
	unwind(fr,VV[27]);}
T493:;
	{register object V193;
	register object V194;
	V193= symbol_value(VV[35]);
	V194= (*(LnkLI261))();
	{object V195;
	V196= (*(LnkLI261))();
	V195= (*(LnkLI13))(/* INLINE-ARGS */V196);
	if(((*(LnkLI9))((V195),VV[108]))==Cnil){
	goto T500;}
	V190= (*(LnkLI261))();
	(void)((VFUN_NARGS=6,(*(LnkLI273))((V190),Cnil,Cnil,Ct,Cnil,Ct)));
	goto T497;
T500:;
	(void)((*(LnkLI272))());
	if((symbol_value(VV[45]))==Cnil){
	goto T505;}
	V190= symbol_value(VV[45]);
	goto T497;
T505:;
	base[0]= VV[109];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk248)();
	vs_top=sup;
	V197= vs_base[0];
	setq(VV[45],(VFUN_NARGS=2,(*(LnkLI273))(V197,Cnil)));
	V190= symbol_value(VV[45]);}
T497:;
	{object V198;
	V198= (*(LnkLI13))((V193));
	if(((*(LnkLI9))((V198),VV[110]))==Cnil){
	goto T512;}
	V191= (*(LnkLI278))((V190));
	if((symbol_value(VV[111]))==Cnil){
	goto T518;}
	base[0]= list(3,VV[15],(V191),list(2,VV[112],(V190)));
	base[1]= symbol_value(VV[48]);
	base[2]= VV[30];
	base[3]= VV[113];
	vs_top=(vs_base=base+0)+4;
	(void) (*Lnk279)();
	vs_top=sup;
	setq(VV[48],vs_base[0]);
T518:;
	{object V199;
	V199= (*(LnkLI13))((V193));
	if(((*(LnkLI9))((V199),VV[114]))==Cnil){
	goto T512;}
	if(!(type_of((V194))==t_cons||((V194))==Cnil)){
	goto T529;}
	if(eql(car((V194)),VV[61])){
	goto T512;}
T529:;
	V194= list(2,VV[115],(V194));}}
T512:;
	if(!(type_of((V194))==t_cons||((V194))==Cnil)){
	goto T536;}
	if((symbol_value(VV[111]))!=Cnil){
	goto T536;}
	base[0]= VV[116];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk248)();
	vs_top=sup;
	V200= vs_base[0];
	V192= (VFUN_NARGS=3,(*(LnkLI273))(V200,Cnil,Cnil));
	goto T534;
T536:;
	V192= (V194);
T534:;
	{object V201;
	{object V202;
	V202= (*(LnkLI13))((V193));
	if(((*(LnkLI9))((V202),VV[117]))==Cnil){
	goto T547;}
	{object V203;
	V204= list(3,VV[15],list(2,VV[18],(V191)),(V192));
	V203= list(3,VV[5],/* INLINE-ARGS */V204,list(3,VV[15],(V191),list(2,VV[118],list(2,VV[18],(V191)))));
	if((symbol_value(VV[111]))==Cnil){
	goto T551;}
	V201= make_cons((V203),Cnil);
	goto T544;
T551:;
	V205= list(2,(V191),(V203));
	V206= list(3,VV[14],/* INLINE-ARGS */V205,list(2,Ct,list(3,VV[15],(V191),list(2,VV[118],list(3,VV[15],(V190),(V192))))));
	V201= make_cons(/* INLINE-ARGS */V206,Cnil);
	goto T544;}
T547:;
	if(((*(LnkLI9))((V202),VV[27]))==Cnil){
	goto T554;}
	if((symbol_value(VV[111]))==Cnil){
	goto T557;}
	V207= list(2,VV[18],(V191));
	V208= list(3,VV[15],/* INLINE-ARGS */V207,list(3,VV[15],(V191),list(3,VV[119],(V192),Cnil)));
	V201= make_cons(/* INLINE-ARGS */V208,Cnil);
	goto T544;
T557:;
	V209= list(2,VV[18],(V191));
	V210= list(2,(V191),list(3,VV[15],/* INLINE-ARGS */V209,list(3,VV[15],(V191),list(3,VV[119],(V192),Cnil))));
	V211= list(3,VV[14],/* INLINE-ARGS */V210,list(2,Ct,list(3,VV[15],(V190),list(3,VV[15],(V191),list(3,VV[119],(V192),Cnil)))));
	V201= make_cons(/* INLINE-ARGS */V211,Cnil);
	goto T544;
T554:;
	V193= (*(LnkLI13))((V193));
	if(((VFUN_NARGS=4,(*(LnkLI253))((V193),symbol_value(VV[28]),VV[30],VV[9])))==Cnil){
	goto T562;}
	V201= (*(LnkLI280))((V193),(V190),(V192));
	goto T544;
T562:;
	base[0]= VV[120];
	base[1]= (V193);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk247)();
	vs_top=sup;
	V201= vs_base[0];}
T544:;
	if(!(eql((V192),(V194)))){
	goto T567;}
	{object V212 = (V201);
	VMR29(V212)}
T567:;
	V213= list(3,VV[15],(V192),(V194));
	V214= make_cons(/* INLINE-ARGS */V213,Cnil);
	{object V215 = nconc((V201),/* INLINE-ARGS */V214);
	VMR29(V215)}}}}
}
/*	local entry for function LOOP-PARSE-ADDITIONAL-COLLECTIONS	*/

static object LI30(V219,V220,V221)

object V219;object V220;object V221;
{	 VMB30 VMS30 VMV30
	bds_check;
TTL:;
	{register object V222;
	V222= Cnil;
	{object V223;
	object V224;
	V223= (VFUN_NARGS=4,(*(LnkLI253))((V219),symbol_value(VV[28]),VV[30],VV[9]));
	V224= get((V223),VV[121],Cnil);
	{object V225;
	V225= (
	(type_of((V224)) == t_sfun ?(*(object (*)())(((V224))->sfn.sfn_self)):
	(fcall.fun=((V224)),fcall.argd=2,fcalln))((V220),(V221)));
	bds_bind(VV[34],(V225));
	bds_bind(VV[35],Cnil);
	{register object V226;
	V226= (*(LnkLI261))();
T576:;
	if(((VV[34]->s.s_dbind))!=Cnil){
	goto T577;}
	goto T573;
T577:;
	{register object V227;
	V227= (*(LnkLI13))((V226));
	{register object V228;
	V228= (*(LnkLI262))((V227));
	if(((V228))==Cnil){
	goto T585;}
	goto T581;
T585:;
	if(((*(LnkLI9))((V227),VV[56]))==Cnil){
	goto T588;}
	V222= (*(LnkLI264))();
	goto T581;
T588:;
	base[4]= VV[85];
	base[5]= (V227);
	vs_top=(vs_base=base+4)+2;
	(void) (*Lnk247)();
	vs_top=sup;}}
T581:;
	V226= (*(LnkLI261))();
	goto T576;}
T573:;
	{object V229 = (V222);
	bds_unwind1;
	bds_unwind1;
	VMR30(V229)}}}}
}
/*	local entry for function THE-TYPE	*/

static object LI31(V232,V233)

object V232;register object V233;
{	 VMB31 VMS31 VMV31
TTL:;
	if(symbol_value(VV[47])==Cnil){
	goto T596;}
	V233= Cnil;
T596:;
	if((V233)==Cnil){
	goto T598;}{object V234;
	base[0]= symbol_value(VV[54]);
	base[1]= (V233);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk281)();
	vs_top=sup;
	V234= vs_base[0];
	if(V234==Cnil)goto T600;
	V233= V234;
	goto T599;
T600:;}
	base[1]= (V233);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk282)();
	vs_top=sup;
	base[0]= vs_base[0];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk105)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T604;}
	V233= Cnil;
	goto T599;
T604:;
T599:;
T598:;
	base[0]= (V233);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk283)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T609;}
	goto T608;
T609:;
	base[0]= car((V233));
	base[1]= VV[122];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk284)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T612;}
	goto T608;
T612:;
	V233= cadr((V233));
T608:;
	if(((V233))==Cnil){
	goto T618;}
	{object V235 = list(3,VV[123],(V233),(V232));
	VMR31(V235)}
T618:;
	{object V236 = (V232);
	VMR31(V236)}
}
/*	local entry for function TYPE-ERROR	*/

static object LI32()

{	 VMB32 VMS32 VMV32
TTL:;
	base[0]= VV[124];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk247)();
	vs_top=sup;
	{object V237 = vs_base[0];
	VMR32(V237)}
}
/*	local entry for function MAKE-VALUE	*/

static object LI33(V240,V241)

register object V240;object V241;
{	 VMB33 VMS33 VMV33
TTL:;
	{register object V242;
	V242= Cnil;
	if((symbol_value(VV[47]))!=Cnil){
	goto T623;}
	if((symbol_value(VV[125]))==Cnil){
	goto T623;}
	if(!(((V241))==(VV[126]))){
	goto T623;}
	base[0]= symbol_value(VV[54]);
	base[1]= (V241);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk281)();
	vs_top=sup;
	V242= vs_base[0];
	if(((V242))==Cnil){
	goto T623;}
	if(!(type_of((V242))==t_cons)){
	goto T637;}
	if(!((car((V242)))==(VV[122]))){
	goto T637;}
	V242= cadr((V242));
	goto T635;
T637:;
T635:;
	base[0]= (V240);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk276)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T642;}
	{object V243;
	if((symbol_value(VV[39]))==Cnil){
	goto T647;}
	base[1]= (V240);
	base[2]= VV[127];
	base[3]= symbol_value(VV[39]);
	vs_top=(vs_base=base+1)+3;
	(void) (*Lnk285)();
	vs_top=sup;
	base[0]= vs_base[0];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk286)();
	vs_top=sup;
	V243= vs_base[0];
	goto T645;
T647:;
	base[0]= (V240);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk286)();
	vs_top=sup;
	V243= vs_base[0];
T645:;{object V244;
	base[0]= (V243);
	base[1]= (V242);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk129)();
	vs_top=sup;
	V244= vs_base[0];
	if(V244==Cnil)goto T655;
	goto T654;
T655:;}
	base[0]= VV[128];
	base[1]= (V240);
	base[2]= (V242);
	vs_top=(vs_base=base+0)+3;
	(void) (*Lnk247)();
	vs_top=sup;
T654:;
	{object V245 = make_cons((V240),Cnil);
	VMR33(V245)}}
T642:;
	{register object V246;
	V246= Cnil;
	if(!(type_of((V240))!=t_cons)){
	goto T664;}
	V247= Cnil;
	goto T662;
T664:;
	vs_base=vs_top;
	(void) (*Lnk248)();
	vs_top=sup;
	V246= vs_base[0];
	V248= list(2,(V246),(V240));
	V247= make_cons(/* INLINE-ARGS */V248,Cnil);
T662:;
	if((symbol_value(VV[39]))==Cnil){
	goto T669;}
	if((V246)!=Cnil){
	base[0]= (V246);
	goto T671;}
	base[0]= (V240);
T671:;
	base[1]= VV[127];
	base[2]= symbol_value(VV[39]);
	vs_top=(vs_base=base+0)+3;
	(void) (*Lnk285)();
	vs_top=sup;
	V249= vs_base[0];
	goto T667;
T669:;
	if((V246)!=Cnil){
	V249= (V246);
	goto T667;}
	V249= (V240);
T667:;
	V250= list(3,VV[80],list(3,VV[129],V249,list(2,VV[10],(V242))),VV[130]);
	if((V246)!=Cnil){
	V251= (V246);
	goto T674;}
	V251= (V240);
T674:;
	V252= list(4,VV[12],V247,/* INLINE-ARGS */V250,V251);
	{object V253 = make_cons(/* INLINE-ARGS */V252,Cnil);
	VMR33(V253)}}
T623:;
	{object V254 = make_cons((V240),Cnil);
	VMR33(V254)}}
}
/*	local entry for function LOOP-ADD-BINDING	*/

static object LI34(V256,V255,va_alist)
	object V256,V255;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB34 VMS34 VMV34
	{object V257;
	register object V258;
	object V259;
	object V260;
	object V261;
	object V262;
	object V263;
	if(narg <2) too_few_arguments();
	V257= V256;
	V258= V255;
	narg = narg - 2;
	if (narg <= 0) goto T675;
	else {
	va_start(ap);
	V259= va_arg(ap,object);}
	if (--narg <= 0) goto T676;
	else {
	V260= va_arg(ap,object);}
	if (--narg <= 0) goto T677;
	else {
	V261= va_arg(ap,object);}
	if (--narg <= 0) goto T678;
	else {
	V262= va_arg(ap,object);}
	if (--narg <= 0) goto T679;
	else {
	V263= va_arg(ap,object);}
	--narg; goto T680;
T675:;
	V259= Ct;
T676:;
	V260= Cnil;
T677:;
	V261= Cnil;
T678:;
	V262= Ct;
T679:;
	V263= Cnil;
T680:;
	{register object V264;
	V264= Cnil;
	if(((V259))!=Cnil){
	goto T688;}
	if((symbol_value(VV[46]))!=Cnil){
	goto T687;}
T688:;
	V265= make_cons(Cnil,Cnil);
	setq(VV[46],make_cons(/* INLINE-ARGS */V265,symbol_value(VV[46])));
T687:;
	{register object x= (V257),V266= caar(symbol_value(VV[46]));
	while(!endp(V266))
	if(type_of(V266->c.c_car)==t_cons &&eql(x,V266->c.c_car->c.c_car)){
	V264= (V266->c.c_car);
	goto T697;
	}else V266=V266->c.c_cdr;
	V264= Cnil;}
T697:;
	if(((V264))==Cnil){
	goto T695;}
	if((V262)==Cnil){
	goto T693;}
	{object V268;
	if((V258)==Cnil){
	V268= Cnil;
	goto T698;}
	V268= (*(LnkLI287))((V258),(V260));
T698:;
	if(type_of(V264)!=t_cons)FEwrong_type_argument(Scons,V264);
	(V264)->c.c_cdr = (V268);
	goto T693;}
T695:;
	{object V269;
	if((V263)!=Cnil){
	if(((V263))!=Cnil){
	goto T701;}
	goto T702;}
	base[1]= (V257);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk288)();
	vs_top=sup;
	base[0]= vs_base[0];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk140)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T703;}
	goto T702;
T703:;
	base[0]= (V258);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk276)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T701;}
T702:;
	V269= Cnil;
	goto T700;
T701:;
	{register object V270;
	register object V271;
	V270= cdr(symbol_value(VV[46]));
	V271= car((V270));
T711:;
	if(!(endp((V270)))){
	goto T712;}
	V269= Cnil;
	goto T700;
T712:;
	{register object x= (V257),V272= car((V271));
	while(!endp(V272))
	if(type_of(V272->c.c_car)==t_cons &&eql(x,V272->c.c_car->c.c_car)){
	V264= (V272->c.c_car);
	goto T719;
	}else V272=V272->c.c_cdr;
	V264= Cnil;}
T719:;
	if(((V264))==Cnil){
	goto T716;}
	if((V262)==Cnil){
	goto T720;}
	{register object V273;
	register object V274;
	V273= (V264);
	if((V258)==Cnil){
	V274= Cnil;
	goto T722;}
	V274= (*(LnkLI287))((V258),(V260));
T722:;
	if(type_of((V273))!=t_cons)FEwrong_type_argument(Scons,(V273));
	((V273))->c.c_cdr = (V274);}
T720:;
	V269= Ct;
	goto T700;
T716:;
	V270= cdr((V270));
	V271= car((V270));
	goto T711;}
T700:;
	if(((V269))==Cnil){
	goto T730;}
	goto T693;
T730:;
	{object V275;
	object V276;
	V275= symbol_value(VV[46]);
	if((V258)==Cnil){
	V277= Cnil;
	goto T734;}
	V277= (*(LnkLI287))((V258),(V260));
T734:;
	V278= make_cons((V257),V277);
	V276= make_cons(/* INLINE-ARGS */V278,caar((V275)));
	if(type_of(car((V275)))!=t_cons)FEwrong_type_argument(Scons,car((V275)));
	(car((V275)))->c.c_car = (V276);
	(void)(car((V275)));}}
T693:;
	if((V260)==Cnil){
	goto T736;}
	(void)((VFUN_NARGS=3,(*(LnkLI289))((V257),(V260),(V261))));
T736:;
	{object V279 = (V257);
	VMR34(V279)}}}
	}
/*	local entry for function LOOP-DECLARE-BINDING	*/

static object LI35(V282,V281,V280,va_alist)
	object V282,V281,V280;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB35 VMS35 VMV35
	{register object V283;
	register object V284;
	object V285;
	object V286;
	if(narg <3) too_few_arguments();
	V283= V282;
	V284= V281;
	V285= V280;
	narg = narg - 3;
	if (narg <= 0) goto T737;
	else {
	va_start(ap);
	V286= va_arg(ap,object);}
	--narg; goto T738;
T737:;
	V286= Cnil;
T738:;
	{object V287;
	V287= Cnil;
	if((V284)==Cnil){
	goto T742;}
	{register object x= (V284),V288= symbol_value(VV[131]);
	while(!endp(V288))
	if(eql(x,V288->c.c_car)){
	goto T743;
	}else V288=V288->c.c_cdr;}
	goto T742;
T743:;
	base[0]= symbol_value(VV[54]);
	base[1]= (V284);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk281)();
	vs_top=sup;
	V284= vs_base[0];
	if(((V284))!=Cnil){
	goto T745;}
	goto T742;
T745:;
	if(symbol_value(VV[132])==Cnil){
	goto T742;}
	(void)((VFUN_NARGS=3,(*(LnkLI289))((V283),VV[133],(V285))));
T742:;
	if(((V284))==Cnil){
	goto T750;}
	if(((V285))!=Cnil){
	goto T751;}
	if((symbol_value(VV[47]))!=Cnil){
	goto T750;}
T751:;
	{register object V289;
	register object V290;
	V289= symbol_value(VV[46]);
	V290= car((V289));
T761:;
	if(!(endp((V289)))){
	goto T762;}
	goto T757;
T762:;
	{register object x= (V283),V291= car((V290));
	while(!endp(V291))
	if(type_of(V291->c.c_car)==t_cons &&eql(x,V291->c.c_car->c.c_car)){
	goto T768;
	}else V291=V291->c.c_cdr;
	goto T766;}
T768:;
	V287= Ct;
	{register object V292;
	register object V293;
	V292= (V290);
	if(!(type_of((V284))==t_cons)){
	goto T776;}
	if(!((car((V284)))==(VV[122]))){
	goto T776;}
	base[2]= list(3,VV[122],cadr((V284)),(V283));
	goto T774;
T776:;
	if(((V286))==Cnil){
	goto T781;}
	base[2]= list(3,VV[122],(V284),(V283));
	goto T774;
T781:;
	base[2]= list(2,(V284),(V283));
T774:;
	base[3]= cdr((V292));
	base[4]= VV[30];
	base[5]= VV[113];
	vs_top=(vs_base=base+2)+4;
	(void) (*Lnk279)();
	vs_top=sup;
	V293= vs_base[0];
	if(type_of((V292))!=t_cons)FEwrong_type_argument(Scons,(V292));
	((V292))->c.c_cdr = (V293);}
	goto T757;
T766:;
	V289= cdr((V289));
	V290= car((V289));
	goto T761;}
T757:;
	if((V287)!=Cnil){
	goto T750;}
	if(symbol_value(VV[53])!=Cnil){
	goto T750;}
	base[0]= VV[134];
	base[1]= (V283);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk247)();
	vs_top=sup;
T750:;
	{object V294 = (V283);
	VMR35(V294)}}}
	}
/*	local entry for function PARSE-LOOP-DECLARE	*/

static object LI36(va_alist)
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB36 VMS36 VMV36
	{register object V295;
	register object V296;
	narg = narg - 0;
	if (narg <= 0) goto T794;
	else {
	va_start(ap);
	V295= va_arg(ap,object);}
	if (--narg <= 0) goto T795;
	else {
	V296= va_arg(ap,object);}
	--narg; goto T796;
T794:;
	V295= (*(LnkLI261))();
T795:;
	V296= Ct;
T796:;
	{object V297;
	register object V298;
	V297= car((V295));
	V298= Cnil;
	if(!(((V297))==(VV[122]))){
	goto T800;}
	V295= cdr((V295));
	V297= car((V295));
	V298= Ct;
T800:;
	{register object V299;
	register object V300;
	V299= cdr((V295));
	V300= car((V299));
T811:;
	if(!(endp((V299)))){
	goto T812;}
	{object V301 = Cnil;
	VMR36(V301)}
T812:;
	(void)((VFUN_NARGS=4,(*(LnkLI289))((V300),car((V295)),(V296),(V298))));
	V299= cdr((V299));
	V300= car((V299));
	goto T811;}}}
	}
/*	local entry for function LOOP-ADD-TEMPS	*/

static object LI37(V302,va_alist)
	object V302;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB37 VMS37 VMV37
	{register object V303;
	object V304;
	object V305;
	object V306;
	object V307;
	if(narg <1) too_few_arguments();
	V303= V302;
	narg = narg - 1;
	if (narg <= 0) goto T822;
	else {
	va_start(ap);
	V304= va_arg(ap,object);}
	if (--narg <= 0) goto T823;
	else {
	V305= va_arg(ap,object);}
	if (--narg <= 0) goto T824;
	else {
	V306= va_arg(ap,object);}
	if (--narg <= 0) goto T825;
	else {
	V307= va_arg(ap,object);}
	--narg; goto T826;
T822:;
	V304= Cnil;
T823:;
	V305= Cnil;
T824:;
	V306= Cnil;
T825:;
	V307= Cnil;
T826:;
	{object V308;
	base[0]= (V303);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk140)();
	vs_top=sup;
	V308= vs_base[0];
	if(((V308))==Cnil){
	goto T834;}
	{object V309 = (V308);
	VMR37(V309)}
T834:;
	if(!(type_of((V303))==t_symbol)){
	goto T837;}
	{object V310 = (VFUN_NARGS=7,(*(LnkLI273))((V303),(V304),(V306),(V305),Cnil,Ct,(V307)));
	VMR37(V310)}
T837:;
	if(!(type_of((V303))==t_cons||((V303))==Cnil)){
	goto T840;}
	(void)((VFUN_NARGS=1,(*(LnkLI274))(car((V303)))));
	{object V311 = (VFUN_NARGS=1,(*(LnkLI274))(cdr((V303))));
	VMR37(V311)}
T840:;
	{object V312 = Cnil;
	VMR37(V312)}}}
	}
/*	local entry for function ADD-FROM-DATA	*/

static object LI38(V313,va_alist)
	object V313;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB38 VMS38 VMV38
	{register object V314;
	object V315;
	if(narg <1) too_few_arguments();
	V314= V313;
	narg= narg - 1;
	va_start(ap);
	V316 = list_vector(narg,ap);
	V315= V316;
	if((V314)!=Cnil){
	goto T843;}
	base[0]= VV[135];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk115)();
	vs_top=sup;
	V314= vs_base[0];
T843:;
	{register object V317;
	register object V318;
	V317= (V314);
	V318= (V315);
T848:;
	if(((V318))!=Cnil){
	goto T849;}
	goto T846;
T849:;
	if((car((V318)))!=Cnil){
	goto T854;}
	goto T853;
T854:;
	{register object V319;
	register object V320;
	V319= (V317);
	V320= car((V318));
	if(type_of((V319))!=t_cons)FEwrong_type_argument(Scons,(V319));
	((V319))->c.c_car = (V320);}
T853:;
	V317= cdr((V317));
	V318= cdr((V318));
	goto T848;}
T846:;
	{object V321 = (V314);
	VMR38(V321)}}
	}
/*	local entry for function PARSE-LOOP-FOR	*/

static object LI39()

{	 VMB39 VMS39 VMV39
	bds_check;
TTL:;
	{register object V322;
	register object V323;
	V322= Cnil;
	V323= Cnil;
	{register object V324;
	object V325;
	register object V326;
	V324= (*(LnkLI261))();
	V325= Cnil;
	V326= Cnil;
	{object V327;
	V327= (*(LnkLI261))();
T871:;
	{register object V328;
	V328= (*(LnkLI13))((V327));
	if(((*(LnkLI9))((V328),VV[136]))==Cnil){
	goto T877;}
	{object V329;
	base[1]= VV[137];
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk248)();
	vs_top=sup;
	V329= vs_base[0];
	(void)((VFUN_NARGS=4,(*(LnkLI274))((V324),Cnil,VV[138],Ct)));
	V330= (*(LnkLI261))();
	(void)((VFUN_NARGS=3,(*(LnkLI273))((V329),/* INLINE-ARGS */V330,Cnil)));
	V331= list(3,VV[139],(V324),list(2,VV[17],(V329)));
	setq(VV[49],make_cons(/* INLINE-ARGS */V331,symbol_value(VV[49])));
	V326= list(3,VV[15],(V329),list(2,VV[18],(V329)));
	V325= list(2,VV[140],(V329));
	goto T874;}
T877:;
	if(((*(LnkLI9))((V328),VV[141]))==Cnil){
	goto T889;}
	{register object V332;
	if(!(type_of((V324))==t_symbol)){
	goto T893;}
	V332= (V324);
	goto T891;
T893:;
	base[1]= VV[142];
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk248)();
	vs_top=sup;
	V332= vs_base[0];
T891:;
	(void)((VFUN_NARGS=4,(*(LnkLI274))((V324),Cnil,VV[138],Ct)));
	V333= (*(LnkLI261))();
	(void)((VFUN_NARGS=3,(*(LnkLI273))((V332),/* INLINE-ARGS */V333,Cnil)));
	V326= list(3,VV[15],(V332),list(2,VV[18],(V332)));
	if(eql((V332),(V324))){
	goto T900;}
	V334= list(3,VV[139],(V324),(V332));
	setq(VV[49],make_cons(/* INLINE-ARGS */V334,symbol_value(VV[49])));
T900:;
	V325= list(2,VV[140],(V332));
	goto T874;}
T889:;
	if(((*(LnkLI9))((V328),VV[143]))==Cnil){
	goto T906;}
	V335= (*(LnkLI261))();
	V323= (VFUN_NARGS=6,(*(LnkLI290))((V323),(V324),/* INLINE-ARGS */V335,Cnil,Cnil,VV[144]));
	goto T874;
T906:;
	if(((*(LnkLI9))((V328),VV[145]))==Cnil){
	goto T910;}
	V336= (*(LnkLI261))();
	V323= (VFUN_NARGS=6,(*(LnkLI290))((V323),(V324),/* INLINE-ARGS */V336,Cnil,Cnil,VV[146]));
	goto T874;
T910:;
	if(((*(LnkLI9))((V328),VV[147]))==Cnil){
	goto T914;}
	V322= (*(LnkLI261))();
	if(((V323))==Cnil){
	goto T919;}
	V323= (VFUN_NARGS=5,(*(LnkLI290))((V323),Cnil,Cnil,Cnil,(V322)));
	goto T874;
T919:;
	bds_bind(VV[148],small_fixnum(4));
	bds_bind(VV[149],small_fixnum(4));
T924:;
	if(!((car(caddr((V326))))==(VV[18]))){
	goto T925;}
	bds_unwind1;
	bds_unwind1;
	goto T922;
T925:;
	base[3]= VV[150];
	base[4]= VV[151];
	base[5]= VV[152];
	vs_top=(vs_base=base+3)+3;
	(void) (*Lnk291)();
	vs_top=sup;
	base[3]= symbol_value(VV[153]);
	base[4]= VV[154];
	vs_top=(vs_base=base+3)+2;
	(void) (*Lnk292)();
	vs_top=sup;
	goto T924;
T922:;
	V337= cadr((V326));
	if(!(type_of((V322))==t_cons)){
	goto T941;}
	{register object x= car((V322)),V339= VV[155];
	while(!endp(V339))
	if(eql(x,V339->c.c_car)){
	goto T944;
	}else V339=V339->c.c_cdr;
	goto T941;}
T944:;
	V338= list(2,cadr((V322)),cadr((V326)));
	goto T939;
T941:;
	V338= list(3,VV[156],(V322),cadr((V326)));
T939:;
	V326= list(3,VV[15],/* INLINE-ARGS */V337,V338);
	goto T874;
T914:;
	if(((*(LnkLI9))((V328),VV[157]))==Cnil){
	goto T946;}
	V340= (*(LnkLI261))();
	V323= (VFUN_NARGS=6,(*(LnkLI290))((V323),(V324),Cnil,/* INLINE-ARGS */V340,Cnil,VV[144]));
	goto T874;
T946:;
	if(((*(LnkLI9))((V328),VV[158]))==Cnil){
	goto T950;}
	V341= (*(LnkLI261))();
	V323= (VFUN_NARGS=6,(*(LnkLI290))((V323),(V324),Cnil,/* INLINE-ARGS */V341,Cnil,VV[146]));
	goto T874;
T950:;
	if(((*(LnkLI9))((V328),VV[159]))==Cnil){
	goto T954;}
	V342= (*(LnkLI261))();
	V323= (VFUN_NARGS=7,(*(LnkLI290))((V323),(V324),Cnil,/* INLINE-ARGS */V342,Cnil,Cnil,Ct));
	goto T874;
T954:;
	if(!(type_of((V328))==t_symbol)){
	goto T958;}
	if((get((V328),VV[160],Cnil))==Cnil){
	goto T958;}
	V343= (*(LnkLI13))((V327));
	(void)((VFUN_NARGS=3,(*(LnkLI271))(/* INLINE-ARGS */V343,VV[160],(V324))));
	goto T868;
T958:;
	if(!(type_of((V328))==t_symbol)){
	goto T964;}
	if((get((V328),VV[161],Cnil))==Cnil){
	goto T964;}
	V344= (*(LnkLI13))((V327));
	(void)((*(LnkLI293))(/* INLINE-ARGS */V344,(V324)));
	goto T868;
T964:;
	(void)((*(LnkLI272))());
	goto T868;}
T874:;
	V327= (*(LnkLI261))();
	goto T871;}
T868:;
	if(((V323))==Cnil){
	goto T973;}
	{object V345;
	object V346;
	object V347;
	object V348;
	object V349;
	object V350;
	V345= car(cddddr((V323)));
	V346= cadr(cddddr((V323)));
	V347= car((V323));
	V348= caddr((V323));
	V349= cadddr((V323));
	V350= Cnil;
	(void)((VFUN_NARGS=4,(*(LnkLI273))((V347),cadr((V323)),Ct,VV[126])));{object V351;
	base[1]= (V349);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk276)();
	vs_top=sup;
	V351= vs_base[0];
	if(V351==Cnil)goto T983;
	goto T982;
T983:;}
	setq(VV[47],Ct);
T982:;
	V352= list(3,(V345),(V347),(V349));
	V326= list(3,VV[15],(V347),(*(LnkLI294))(/* INLINE-ARGS */V352,VV[126]));
	if(((V348))==Cnil){
	goto T990;}
	{object V353;
	base[2]= VV[162];
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk248)();
	vs_top=sup;
	V353= vs_base[0];
	if(!(eql((V349),small_fixnum(1)))){
	goto T996;}
	if((cadr(cddddr((V323))))!=Cnil){
	goto T996;}
	base[1]= Cnil;
	goto T994;
T996:;
	base[1]= list(3,(V345),VV[127],(V349));
T994:;
	bds_bind(VV[39],base[1]);
	(void)((VFUN_NARGS=6,(*(LnkLI273))((V353),(V348),Cnil,VV[126],Cnil,Cnil)));
	if(((V346))==Cnil){
	goto T1004;}
	if(!(((V345))==(VV[144]))){
	goto T1007;}
	V354= VV[163];
	goto T1002;
T1007:;
	V354= VV[164];
	goto T1002;
T1004:;
	if(!(((V345))==(VV[144]))){
	goto T1010;}
	V354= VV[165];
	goto T1002;
T1010:;
	V354= VV[166];
T1002:;
	V325= list(3,V354,(V347),(V353));
	bds_unwind1;
	goto T973;}
T990:;
	if((symbol_value(VV[47]))!=Cnil){
	goto T973;}
	if((symbol_value(VV[125]))==Cnil){
	goto T973;}
	base[1]= symbol_value(VV[54]);
	base[2]= VV[126];
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk281)();
	vs_top=sup;
	V350= vs_base[0];
	if(((V350))==Cnil){
	goto T973;}
	if(!(type_of((V350))==t_cons)){
	goto T1023;}
	if(!((car((V350)))==(VV[122]))){
	goto T1023;}
	V350= cadr((V350));
T1023:;
	base[1]= (V350);
	base[2]= VV[167];
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk295)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T973;}{object V355;
	base[1]= (V349);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk276)();
	vs_top=sup;
	V355= vs_base[0];
	if(V355==Cnil)goto T1032;
	goto T1031;
T1032:;}
	base[1]= VV[168];
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk247)();
	vs_top=sup;
T1031:;
	if(!(((V345))==(VV[144]))){
	goto T1039;}
	if((V349)!=Cnil){
	V357= (V349);
	goto T1041;}
	V357= small_fixnum(1);
T1041:;
	V356= list(3,VV[164],(V347),number_minus(VV[169],V357));
	goto T1037;
T1039:;
	if((V349)!=Cnil){
	V358= (V349);
	goto T1042;}
	V358= small_fixnum(1);
T1042:;
	V356= list(3,VV[163],(V347),number_plus(VV[170],V358));
T1037:;
	V359= list(3,VV[80],V356,VV[171]);
	setq(VV[42],make_cons(/* INLINE-ARGS */V359,symbol_value(VV[42])));}
T973:;
	if((V325)==Cnil){
	goto T1043;}
	base[1]= list(3,VV[5],(V325),VV[172]);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk258)();
	vs_top=sup;
	V360= vs_base[0];
	setq(VV[41],make_cons(V360,symbol_value(VV[41])));
T1043:;
	if((V326)==Cnil){
	{object V361 = Cnil;
	VMR39(V361)}}
	setq(VV[42],make_cons((V326),symbol_value(VV[42])));
	{object V362 = symbol_value(VV[42]);
	VMR39(V362)}}}
}
/*	local entry for function PARSE-LOOP-MACRO	*/

static object LI40(V364,V363,va_alist)
	object V364,V363;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB40 VMS40 VMV40
	{object V365;
	object V366;
	object V367;
	if(narg <2) too_few_arguments();
	V365= V364;
	V366= V363;
	narg = narg - 2;
	if (narg <= 0) goto T1048;
	else {
	va_start(ap);
	V367= va_arg(ap,object);}
	--narg; goto T1049;
T1048:;
	V367= Cnil;
T1049:;
	{register object V368;
	V368= Cnil;
	{object V369;
	object V370;
	V369= get((V365),(V366),Cnil);
	V370= Cnil;
	{object V371= (V366);
	if((V371!= VV[160]))goto T1055;
	{object V372;
	V372= get((V365),VV[173],Cnil);{object V373;
	V373= cdr((V372));
	if(V373==Cnil)goto T1058;
	goto T1057;
T1058:;}
	base[0]= VV[174];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk247)();
	vs_top=sup;
T1057:;
	V370= cdr((V372));
	goto T1054;}
T1055:;
	if((V371!= VV[92]))goto T1061;
	V370= get((V365),VV[175],Cnil);
	goto T1054;
T1061:;
	FEerror("The ECASE key value ~s is illegal.",1,V371);}
T1054:;
	{object V374;
	{register object x= VV[176],V375= (V370);
	while(!endp(V375))
	if(eql(x,V375->c.c_car)){
	goto T1065;
	}else V375=V375->c.c_cdr;
	goto T1064;}
T1065:;
	{object V376;
	V376= symbol_value(VV[34]);
	setq(VV[34],Cnil);
	V374= (V376);
	goto T1062;}
T1064:;
	{register object V377;
	register object V378;
	V377= make_fixnum(length((V370)));
	V378= small_fixnum(0);
T1071:;
	if(!(number_compare((V378),(V377))>=0)){
	goto T1072;}
	V374= nreverse((V368));
	goto T1062;
T1072:;
	V368= make_cons(car(symbol_value(VV[34])),(V368));
	setq(VV[34],cdr(symbol_value(VV[34])));
	V378= one_plus((V378));
	goto T1071;}
T1062:;
	{object V380= (V366);
	if((V380!= VV[160]))goto T1085;
	base[0]= (V369);
	base[1]= (V367);
	{object V381;
	V381= (V374);
	 vs_top=base+2;
	 while(!endp(V381))
	 {vs_push(car(V381));V381=cdr(V381);}
	vs_base=base+1;}
	super_funcall_no_event(base[0]);
	vs_top=sup;
	V379= vs_base[0];
	goto T1084;
T1085:;
	if((V380!= VV[92]))goto T1089;
	base[0]= (V369);
	{object V382;
	V382= (V374);
	 vs_top=base+1;
	 while(!endp(V382))
	 {vs_push(car(V382));V382=cdr(V382);}
	vs_base=base+1;}
	super_funcall_no_event(base[0]);
	vs_top=sup;
	V379= vs_base[0];
	goto T1084;
T1089:;
	V379= Cnil;}
T1084:;
	setq(VV[34],append(V379,symbol_value(VV[34])));
	{object V383 = symbol_value(VV[34]);
	VMR40(V383)}}}}}
	}
/*	local entry for function PARSE-LOOP-MAP	*/

static object LI41(V386,V387)

object V386;object V387;
{	 VMB41 VMS41 VMV41
TTL:;
	if(symbol_value(VV[53])==Cnil){
	goto T1092;}
	base[0]= VV[177];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk247)();
	vs_top=sup;
T1092:;
	{object V388;
	object V389;
	V388= get((V386),VV[161],Cnil);
	V389= get((V386),VV[178],Cnil);
	if((V389)!=Cnil){
	goto T1096;}
	base[0]= VV[179];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk247)();
	vs_top=sup;
T1096:;
	{register object x= VV[176],V390= (V389);
	while(!endp(V390))
	if(eql(x,V390->c.c_car)){
	goto T1100;
	}else V390=V390->c.c_cdr;
	goto T1098;}
T1100:;
	base[0]= VV[180];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk247)();
	vs_top=sup;
T1098:;
	{register object V391;
	object V392;
	V391= Cnil;
	{register object V393;
	register object V394;
	V395 = make_fixnum(length((V389)));
	V393= one_minus(V395);
	V394= small_fixnum(0);
T1107:;
	if(!(number_compare((V394),(V393))>=0)){
	goto T1108;}
	V392= nreverse((V391));
	goto T1103;
T1108:;
	V391= make_cons(car(symbol_value(VV[34])),(V391));
	setq(VV[34],cdr(symbol_value(VV[34])));
	V394= one_plus((V394));
	goto T1107;}
T1103:;
	{register object V396;
	register object V397;
	V396= (*(LnkLI261))();
	V397= Cnil;
T1123:;
	if(((*(LnkLI9))((V396),VV[77]))!=Cnil){
	goto T1124;}
	(void)((*(LnkLI272))());
	if((V397)==Cnil){
	setq(VV[44],Cnil);
	goto T1120;}
	setq(VV[44],make_cons(VV[77],(V397)));
	goto T1120;
T1124:;
	V398= (*(LnkLI261))();
	V397= make_cons(/* INLINE-ARGS */V398,(V397));
	V396= (*(LnkLI261))();
	goto T1123;}
T1120:;
	base[1]= (V388);
	base[2]= (V387);
	{object V399;
	V399= (V392);
	 vs_top=base+3;
	 while(!endp(V399))
	 {vs_push(car(V399));V399=cdr(V399);}
	vs_base=base+2;}
	super_funcall_no_event(base[1]);
	vs_top=sup;
	setq(VV[53],vs_base[0]);
	{object V400 = Cnil;
	VMR41(V400)}}}
}
/*	local entry for function SUBSTITUTE-SLOOP-BODY	*/

static object LI42(V402)

register object V402;
{	 VMB42 VMS42 VMV42
TTL:;
	if((symbol_value(VV[53]))==Cnil){
	goto T1139;}
	base[0]= make_cons(VV[16],(V402));
	base[1]= VV[181];
	base[2]= symbol_value(VV[53]);
	vs_top=(vs_base=base+0)+3;
	(void) (*Lnk285)();
	vs_top=sup;
	V403= vs_base[0];
	V402= make_cons(V403,Cnil);
	if(symbol_value(VV[44])==Cnil){
	goto T1139;}
	base[0]= symbol_value(VV[44]);
	base[1]= VV[182];
	base[2]= (V402);
	vs_top=(vs_base=base+0)+3;
	(void) (*Lnk285)();
	vs_top=sup;
	V402= vs_base[0];
T1139:;
	{object V404 = (V402);
	VMR42(V404)}
}
/*	local entry for function DEF-LOOP-INTERNAL	*/

static object LI43(V408,V407,V406,V405,va_alist)
	object V408,V407,V406,V405;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB43 VMS43 VMV43
	bds_check;
	{register object V409;
	register object V410;
	object V411;
	object V412;
	object V413;
	object V414;
	object V415;
	if(narg <4) too_few_arguments();
	V409= V408;
	V410= V407;
	V411= V406;
	V412= V405;
	narg = narg - 4;
	if (narg <= 0) goto T1152;
	else {
	va_start(ap);
	V413= va_arg(ap,object);}
	if (--narg <= 0) goto T1153;
	else {
	V414= va_arg(ap,object);}
	if (--narg <= 0) goto T1154;
	else {
	V415= va_arg(ap,object);}
	--narg; goto T1155;
T1152:;
	V413= Cnil;
T1153:;
	V414= Cnil;
T1154:;
	V415= Cnil;
T1155:;
	{object V416;
	bds_bind(VV[184],VV[183]);
	base[3]= Cnil;
	base[4]= VV[185];
	base[5]= (V409);
	base[6]= (V412);
	vs_top=(vs_base=base+3)+4;
	(void) (*Lnk292)();
	vs_top=sup;
	base[2]= vs_base[0];
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk296)();
	vs_top=sup;
	V416= vs_base[0];
	if((V414)==Cnil){
	goto T1165;}{object V417;
	base[2]= make_fixnum(length((V410)));
	base[3]= (V414);
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk165)();
	vs_top=sup;
	V417= vs_base[0];
	if(V417==Cnil)goto T1166;
	goto T1165;
T1166:;}
	base[2]= VV[186];
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk247)();
	vs_top=sup;
T1165:;
	if((V415)==Cnil){
	goto T1171;}{object V418;
	base[2]= make_fixnum(length((V410)));
	base[3]= (V415);
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk166)();
	vs_top=sup;
	V418= vs_base[0];
	if(V418==Cnil)goto T1172;
	goto T1171;
T1172:;}
	base[2]= VV[187];
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk247)();
	vs_top=sup;
T1171:;
	V419= listA(4,VV[190],(V416),(V410),(V411));
	if((V413)==Cnil){
	V420= Cnil;
	goto T1177;}
	V421= list(3,VV[191],list(2,VV[10],(V409)),(V413));
	V420= make_cons(/* INLINE-ARGS */V421,Cnil);
T1177:;
	V422= list(2,VV[10],(V409));
	base[3]= Cnil;
	base[4]= VV[192];
	base[5]= (V412);
	vs_top=(vs_base=base+3)+3;
	(void) (*Lnk292)();
	vs_top=sup;
	base[2]= vs_base[0];
	base[4]= VV[193];
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk217)();
	vs_top=sup;
	base[3]= vs_base[0];
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk296)();
	vs_top=sup;
	V423= vs_base[0];
	V424= list(3,VV[7],/* INLINE-ARGS */V422,V423);
	V425= list(3,VV[15],/* INLINE-ARGS */V424,list(2,VV[10],(V416)));
	V426= list(2,VV[10],(V409));
	base[3]= Cnil;
	base[4]= VV[194];
	base[5]= (V412);
	vs_top=(vs_base=base+3)+3;
	(void) (*Lnk292)();
	vs_top=sup;
	base[2]= vs_base[0];
	base[4]= VV[193];
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk217)();
	vs_top=sup;
	base[3]= vs_base[0];
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk296)();
	vs_top=sup;
	V427= vs_base[0];
	V428= list(3,VV[7],/* INLINE-ARGS */V426,V427);
	V429= list(2,/* INLINE-ARGS */V425,list(3,VV[15],/* INLINE-ARGS */V428,list(2,VV[10],(V410))));
	{object V430 = listA(4,VV[188],VV[189],/* INLINE-ARGS */V419,append(V420,/* INLINE-ARGS */V429));
	bds_unwind1;
	VMR43(V430)}}}
	}
/*	local entry for function SUM-SLOOP-COLLECT	*/

static object LI44(V433,V434)

object V433;object V434;
{	 VMB44 VMS44 VMV44
TTL:;
	V435= list(3,VV[195],(V433),small_fixnum(0));
	{object V436 = list(4,VV[97],/* INLINE-ARGS */V435,VV[56],list(3,VV[195],(V433),list(3,VV[144],(V433),(V434))));
	VMR44(V436)}
}
/*	local entry for function LOGXOR-SLOOP-COLLECT	*/

static object LI45(V439,V440)

register object V439;object V440;
{	 VMB45 VMS45 VMV45
TTL:;
	V441= list(3,VV[15],(V439),small_fixnum(0));
	V442= list(3,VV[15],(V439),list(3,VV[196],(V439),(V440)));
	{object V443 = list(6,VV[97],/* INLINE-ARGS */V441,VV[56],/* INLINE-ARGS */V442,VV[77],list(3,VV[167],(V439),(V440)));
	VMR45(V443)}
}
/*	local entry for function MAXIMIZE-SLOOP-COLLECT	*/

static object LI46(V446,V447)

register object V446;object V447;
{	 VMB46 VMS46 VMV46
TTL:;
	V448= list(3,VV[195],(V446),Cnil);
	V449= list(3,VV[15],(V446),list(3,VV[198],(V446),(V447)));
	{object V450 = list(4,VV[97],/* INLINE-ARGS */V448,VV[56],list(4,VV[197],(V446),/* INLINE-ARGS */V449,list(3,VV[15],(V446),(V447))));
	VMR46(V450)}
}
/*	local entry for function MINIMIZE-SLOOP-COLLECT	*/

static object LI47(V453,V454)

register object V453;object V454;
{	 VMB47 VMS47 VMV47
TTL:;
	V455= list(3,VV[195],(V453),Cnil);
	V456= list(3,VV[15],(V453),list(3,VV[199],(V453),(V454)));
	{object V457 = list(4,VV[97],/* INLINE-ARGS */V455,VV[56],list(4,VV[197],(V453),/* INLINE-ARGS */V456,list(3,VV[15],(V453),(V454))));
	VMR47(V457)}
}
/*	local entry for function COUNT-SLOOP-COLLECT	*/

static object LI48(V460,V461)

object V460;object V461;
{	 VMB48 VMS48 VMV48
TTL:;
	V462= list(3,VV[195],(V460),small_fixnum(0));
	{object V463 = list(4,VV[97],/* INLINE-ARGS */V462,VV[56],list(3,VV[5],(V461),list(3,VV[15],(V460),list(2,VV[200],(V460)))));
	VMR48(V463)}
}
/*	local entry for function THEREIS-SLOOP-COLLECT	*/

static object LI49(V466,V467)

object V466;object V467;
{	 VMB49 VMS49 VMV49
TTL:;
	{object V468 = list(2,VV[56],list(3,VV[197],(V467),list(2,VV[59],(V467))));
	VMR49(V468)}
}
/*	local entry for function ALWAYS-SLOOP-COLLECT	*/

static object LI50(V471,V472)

object V471;object V472;
{	 VMB50 VMS50 VMV50
TTL:;
	V473= list(3,VV[195],(V471),Ct);
	{object V474 = list(4,VV[97],/* INLINE-ARGS */V473,VV[56],list(3,VV[5],list(2,VV[140],(V472)),VV[201]));
	VMR50(V474)}
}
/*	local entry for function NEVER-SLOOP-COLLECT	*/

static object LI51(V477,V478)

object V477;object V478;
{	 VMB51 VMS51 VMV51
TTL:;
	V479= list(3,VV[195],(V477),Ct);
	{object V480 = list(4,VV[97],/* INLINE-ARGS */V479,VV[56],list(3,VV[5],(V478),VV[202]));
	VMR51(V480)}
}
/*	local entry for function AVERAGING-SLOOP-MACRO	*/

static object LI52(V482)

object V482;
{	 VMB52 VMS52 VMV52
TTL:;
	base[0]= VV[91];
	base[1]= VV[203];
	base[2]= VV[94];
	base[3]= VV[204];
	base[4]= VV[5];
	base[5]= VV[91];
	base[6]= VV[205];
	base[7]= VV[94];
	base[8]= small_fixnum(0);
	base[9]= VV[77];
	base[10]= VV[206];
	base[11]= VV[77];
	base[12]= VV[207];
	base[13]= VV[56];
	base[14]= list(3,VV[15],VV[203],list(3,VV[208],list(3,VV[144],VV[209],(V482)),VV[210]));
	base[15]= VV[211];
	vs_top=(vs_base=base+0)+16;
	(void) (*Lnk297)();
	vs_top=sup;
	{object V483 = vs_base[0];
	VMR52(V483)}
}
/*	local entry for function REPEAT-SLOOP-MACRO	*/

static object LI53(V485)

object V485;
{	 VMB53 VMS53 VMV53
TTL:;
	{object V486;
	vs_base=vs_top;
	(void) (*Lnk248)();
	vs_top=sup;
	V486= vs_base[0];
	{object V487 = list(4,VV[25],(V486),VV[157],(V485));
	VMR53(V487)}}
}
/*	local entry for function RETURN-SLOOP-MACRO	*/

static object LI54(V489)

register object V489;
{	 VMB54 VMS54 VMV54
TTL:;
	if(!(type_of((V489))==t_cons)){
	goto T1211;}
	if(!((car((V489)))==(VV[21]))){
	goto T1211;}
	V490= cdr((V489));
	goto T1209;
T1211:;
	V490= make_cons((V489),Cnil);
T1209:;
	{object V491 = list(2,VV[56],make_cons(VV[59],V490));
	VMR54(V491)}
}
/*	local entry for function IN-TABLE-SLOOP-MAP	*/

static object LI55(V494,V495)

object V494;object V495;
{	 VMB55 VMS55 VMV55
TTL:;
	{object V496 = list(3,VV[212],list(2,VV[213],listA(3,VV[214],(V494),VV[215])),(V495));
	VMR55(V496)}
}
/*	local entry for function IN-PACKAGE-SLOOP-MAP	*/

static object LI56(V499,V500)

object V499;object V500;
{	 VMB56 VMS56 VMV56
TTL:;
	{object V501 = list(3,VV[216],list(2,(V499),list(2,VV[217],(V500))),VV[181]);
	VMR56(V501)}
}
/*	local entry for function IN-ARRAY-SLOOP-FOR	*/

static object LI57(V503,V502,va_alist)
	object V503,V502;
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB57 VMS57 VMV57
	{object V504;
	object V505;
	register object V506;
	if(narg <2) too_few_arguments();
	V504= V503;
	V505= V502;
	narg= narg - 2;
	va_start(ap);
	V507 = list_vector(narg,ap);
	V506= V507;
	{object V508;
	object V509;
	object V510;
	V508= Cnil;
	V509= Cnil;
	V510= Cnil;
	if(!(type_of((V504))==t_cons||((V504))==Cnil)){
	goto T1217;}
	V508= car((V504));
	V509= cadr((V504));
	goto T1215;
T1217:;
	V508= (V504);
	base[0]= VV[218];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk248)();
	vs_top=sup;
	V509= vs_base[0];
T1215:;
	{object V511;
	{register object V512;
	register object V513;
	V512= (V506);
	V513= Cnil;
T1228:;
	{register object V514;
	V514= (*(LnkLI13))(car((V512)));
	{register object V515;
	V515= (*(LnkLI9))((V514),VV[219]);
	if(((V515))==Cnil){
	goto T1235;}
	goto T1231;
T1235:;
	if(((*(LnkLI9))((V514),VV[220]))==Cnil){
	goto T1238;}
	V510= Ct;
	goto T1231;
T1238:;
	{register object V516;
	V516= (*(LnkLI9))((V514),VV[147]);
	if(((V516))==Cnil){
	goto T1243;}
	goto T1231;
T1243:;
	base[0]= (V512);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk115)();
	vs_top=sup;
	V506= vs_base[0];
	V511= nreverse((V513));
	goto T1226;}}}
T1231:;
	V513= make_cons(car((V512)),(V513));
	V513= make_cons(cadr((V512)),(V513));
	V512= cddr((V512));
	goto T1228;}
T1226:;
	if((V510)!=Cnil){
	goto T1255;}
	V517= list(2,VV[157],list(2,VV[221],(V505)));
	V511= nconc(/* INLINE-ARGS */V517,(V511));
T1255:;
	V518= listA(5,VV[87],(V508),VV[56],list(3,VV[15],(V508),list(3,VV[222],(V505),(V509))),(V506));
	{object V519 = listA(3,VV[25],(V509),append((V511),/* INLINE-ARGS */V518));
	VMR57(V519)}}}}
	}
/*	local entry for function =-SLOOP-FOR	*/

static object LI58(V522,V523)

register object V522;object V523;
{	 VMB58 VMS58 VMV58
TTL:;
	{object V524;
	V525= (*(LnkLI260))();
	V524= (*(LnkLI13))(/* INLINE-ARGS */V525);
	if(((*(LnkLI9))((V524),VV[223]))==Cnil){
	goto T1259;}
	(void)((*(LnkLI261))());
	V526= list(3,VV[139],(V522),(V523));
	{object V527 = list(6,VV[87],(V522),VV[97],/* INLINE-ARGS */V526,VV[89],list(3,VV[139],(V522),(*(LnkLI261))()));
	VMR58(V527)}
T1259:;
	{object V528 = list(4,VV[87],(V522),VV[56],list(3,VV[139],(V522),(V523)));
	VMR58(V528)}}
}
/*	local entry for function SLOOP-SLOOP-MACRO	*/

static object LI59(V530)

VOL object V530;
{	 VMB59 VMS59 VMV59
	bds_check;
TTL:;
	{object V531;
	V531= (*(LnkLI13))(car((V530)));
	{object V532;
	V532= (*(LnkLI9))((V531),VV[25]);
	if(((V532))==Cnil){
	goto T1266;}
	goto T1262;
T1266:;
	base[0]= VV[85];
	base[1]= (V531);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk247)();
	vs_top=sup;}}
T1262:;
	{VOL object V533;
	VOL object V534;
	VOL object V535;
	VOL object V536;
	VOL object V537;
	VOL object V538;
	VOL object V539;
	base[4]= VV[224];
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk248)();
	vs_top=sup;
	V534= vs_base[0];
	bds_bind(VV[50],Cnil);
	bds_bind(VV[49],Cnil);
	bds_bind(VV[53],Cnil);
	V533= Cnil;
	V535= Cnil;
	V536= Cnil;
	V537= Cnil;
	V538= Cnil;
	V539= Cnil;
	bds_bind(VV[34],(V530));
	setq(VV[40],Ct);
	(void)((*(LnkLI261))());
	{object V540;
	object V541;
	V540= symbol_value(VV[46]);
	V541= (V535);
	V535= (V540);
	setq(VV[46],(V541));}
	{object V542;
	object V543;
	V542= symbol_value(VV[48]);
	V543= (V536);
	V536= (V542);
	setq(VV[48],(V543));}
	{object V544;
	object V545;
	V544= symbol_value(VV[43]);
	V545= (V537);
	V537= (V544);
	setq(VV[43],(V545));}
	{object V546;
	object V547;
	V546= symbol_value(VV[41]);
	V547= (V538);
	V538= (V546);
	setq(VV[41],(V547));}
	{object V548;
	object V549;
	V548= symbol_value(VV[42]);
	V549= (V539);
	V539= (V548);
	setq(VV[42],(V549));}
	base[4]= (VV[50]->s.s_dbind);
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk105)();
	vs_top=sup;
	(VV[50]->s.s_dbind)= vs_base[0];
	(void)((*(LnkLI263))());
	{object V550;
	object V551;
	V550= symbol_value(VV[46]);
	V551= (V535);
	V535= (V550);
	setq(VV[46],(V551));}
	{object V552;
	object V553;
	V552= symbol_value(VV[48]);
	V553= (V536);
	V536= (V552);
	setq(VV[48],(V553));}
	{object V554;
	object V555;
	V554= symbol_value(VV[43]);
	V555= (V537);
	V537= (V554);
	setq(VV[43],(V555));}
	{object V556;
	object V557;
	V556= symbol_value(VV[41]);
	V557= (V538);
	V538= (V556);
	setq(VV[41],(V557));}
	{object V558;
	object V559;
	V558= symbol_value(VV[42]);
	V559= (V539);
	V539= (V558);
	setq(VV[42],(V559));}
	base[4]= (VV[50]->s.s_dbind);
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk105)();
	vs_top=sup;
	(VV[50]->s.s_dbind)= vs_base[0];
T1354:;
	if(((VV[34]->s.s_dbind))!=Cnil){
	goto T1355;}
	goto T1352;
T1355:;
	{VOL object V560;
	frs_push(FRS_CATCH,VV[27]);
	if(nlj_active)
	{nlj_active=FALSE;frs_pop();
	vs_top=sup;
	V560= vs_base[0];
	goto T1360;}
	else{
	V561= (*(LnkLI255))();
	frs_pop();
	V560= V561;}
T1360:;
	if(((V560))==Cnil){
	goto T1363;}
	goto T1359;
T1363:;
	if(((VV[34]->s.s_dbind))!=Cnil){
	goto T1366;}
	goto T1352;
T1366:;
	(void)(print((VV[34]->s.s_dbind),Cnil));
	{object V562;
	object V563;
	V562= symbol_value(VV[46]);
	V563= (V535);
	V535= (V562);
	setq(VV[46],(V563));}
	{object V564;
	object V565;
	V564= symbol_value(VV[48]);
	V565= (V536);
	V536= (V564);
	setq(VV[48],(V565));}
	{object V566;
	object V567;
	V566= symbol_value(VV[43]);
	V567= (V537);
	V537= (V566);
	setq(VV[43],(V567));}
	{object V568;
	object V569;
	V568= symbol_value(VV[41]);
	V569= (V538);
	V538= (V568);
	setq(VV[41],(V569));}
	{object V570;
	object V571;
	V570= symbol_value(VV[42]);
	V571= (V539);
	V539= (V570);
	setq(VV[42],(V571));}
	base[4]= (VV[50]->s.s_dbind);
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk105)();
	vs_top=sup;
	(VV[50]->s.s_dbind)= vs_base[0];
	(void)((*(LnkLI267))());
	{object V572;
	object V573;
	V572= symbol_value(VV[46]);
	V573= (V535);
	V535= (V572);
	setq(VV[46],(V573));}
	{object V574;
	object V575;
	V574= symbol_value(VV[48]);
	V575= (V536);
	V536= (V574);
	setq(VV[48],(V575));}
	{object V576;
	object V577;
	V576= symbol_value(VV[43]);
	V577= (V537);
	V537= (V576);
	setq(VV[43],(V577));}
	{object V578;
	object V579;
	V578= symbol_value(VV[41]);
	V579= (V538);
	V538= (V578);
	setq(VV[41],(V579));}
	{object V580;
	object V581;
	V580= symbol_value(VV[42]);
	V581= (V539);
	V539= (V580);
	setq(VV[42],(V581));}
	base[4]= (VV[50]->s.s_dbind);
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk105)();
	vs_top=sup;
	(VV[50]->s.s_dbind)= vs_base[0];
	(void)(print((VV[34]->s.s_dbind),Cnil));}
T1359:;
	goto T1354;
T1352:;
	{object V582;
	object V583;
	V582= symbol_value(VV[46]);
	V583= (V535);
	V535= (V582);
	setq(VV[46],(V583));}
	{object V584;
	object V585;
	V584= symbol_value(VV[48]);
	V585= (V536);
	V536= (V584);
	setq(VV[48],(V585));}
	{object V586;
	object V587;
	V586= symbol_value(VV[43]);
	V587= (V537);
	V537= (V586);
	setq(VV[43],(V587));}
	{object V588;
	object V589;
	V588= symbol_value(VV[41]);
	V589= (V538);
	V538= (V588);
	setq(VV[41],(V589));}
	{object V590;
	object V591;
	V590= symbol_value(VV[42]);
	V591= (V539);
	V539= (V590);
	setq(VV[42],(V591));}
	base[4]= (VV[50]->s.s_dbind);
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk105)();
	vs_top=sup;
	(VV[50]->s.s_dbind)= vs_base[0];
	V533= nreverse((VV[49]->s.s_dbind));
	if((VV[53]->s.s_dbind)==Cnil){
	goto T1488;}
	V533= (*(LnkLI257))((V533));
T1488:;
	{object V592;
	V593= list(3,VV[66],Cnil,list(3,VV[61],VV[225],list(2,VV[10],(V534))));
	V594= make_cons(/* INLINE-ARGS */V593,Cnil);
	base[4]= nreverse(symbol_value(VV[48]));
	base[6]= (VV[53]->s.s_dbind);
	vs_top=(vs_base=base+6)+1;
	(void) (*Lnk140)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T1494;}
	base[5]= Cnil;
	goto T1493;
T1494:;
	base[5]= VV[226];
T1493:;
	base[6]= nreverse(symbol_value(VV[41]));
	base[7]= (V533);
	base[8]= nreverse(symbol_value(VV[42]));
	base[10]= (VV[53]->s.s_dbind);
	vs_top=(vs_base=base+10)+1;
	(void) (*Lnk140)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T1501;}
	base[9]= Cnil;
	goto T1500;
T1501:;
	base[9]= VV[227];
T1500:;
	V596= nreverse(symbol_value(VV[43]));
	base[10]= make_cons((V534),/* INLINE-ARGS */V596);
	vs_top=(vs_base=base+4)+7;
	(void) (*Lnk114)();
	vs_top=sup;
	V595= vs_base[0];
	V592= list(3,VV[71],/* INLINE-ARGS */V594,make_cons(VV[73],V595));
	{object V597;
	object V598;
	V597= symbol_value(VV[46]);
	V598= car((V597));
T1509:;
	if(!(endp((V597)))){
	goto T1510;}
	goto T1505;
T1510:;
	V599= (*(LnkLI259))((V598));
	if((cdr((V598)))!=Cnil){
	goto T1517;}
	V600= Cnil;
	goto T1516;
T1517:;
	V601= make_cons(VV[77],cdr((V598)));
	V600= make_cons(/* INLINE-ARGS */V601,Cnil);
T1516:;
	V602= make_cons((V592),Cnil);
	V592= listA(3,VV[12],/* INLINE-ARGS */V599,append(V600,/* INLINE-ARGS */V602));
	V597= cdr((V597));
	V598= car((V597));
	goto T1509;}
T1505:;
	{object V603;
	object V604;
	V603= symbol_value(VV[46]);
	V604= (V535);
	V535= (V603);
	setq(VV[46],(V604));}
	{object V605;
	object V606;
	V605= symbol_value(VV[48]);
	V606= (V536);
	V536= (V605);
	setq(VV[48],(V606));}
	{object V607;
	object V608;
	V607= symbol_value(VV[43]);
	V608= (V537);
	V537= (V607);
	setq(VV[43],(V608));}
	{object V609;
	object V610;
	V609= symbol_value(VV[41]);
	V610= (V538);
	V538= (V609);
	setq(VV[41],(V610));}
	{object V611;
	object V612;
	V611= symbol_value(VV[42]);
	V612= (V539);
	V539= (V611);
	setq(VV[42],(V612));}
	base[4]= (VV[50]->s.s_dbind);
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk105)();
	vs_top=sup;
	(VV[50]->s.s_dbind)= vs_base[0];
	{object V613 = list(2,VV[56],(V592));
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	VMR59(V613)}}}
}
/*	local entry for function IN-CAREFULLY-SLOOP-FOR	*/

static object LI60(V616,V617)

object V616;object V617;
{	 VMB60 VMS60 VMV60
TTL:;
	{register object V618;
	base[0]= VV[228];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk248)();
	vs_top=sup;
	V618= vs_base[0];
	base[0]= VV[87];
	base[1]= (V618);
	base[2]= VV[5];
	base[3]= VV[87];
	base[4]= (V616);
	base[5]= VV[97];
	base[6]= list(3,VV[15],(V618),(V617));
	base[7]= VV[56];
	base[8]= list(3,VV[139],(V616),list(2,VV[17],(V618)));
	base[9]= VV[90];
	base[10]= list(3,VV[5],list(2,VV[229],(V618)),VV[230]);
	base[11]= VV[89];
	base[12]= list(3,VV[15],(V618),list(2,VV[18],(V618)));
	vs_top=(vs_base=base+0)+13;
	(void) (*Lnk61)();
	vs_top=sup;
	{object V619 = vs_base[0];
	VMR60(V619)}}
}
/*	local entry for function FIRST-USE-SLOOP-FOR	*/

static object LI61(V624,V625,V626,V627)

object V624;object V625;object V626;object V627;
{	 VMB61 VMS61 VMV61
TTL:;{object V628;
	V628= (*(LnkLI9))((V626),VV[223]);
	if(V628==Cnil)goto T1578;
	goto T1577;
T1578:;}
	base[0]= VV[231];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk247)();
	vs_top=sup;
T1577:;
	V629= list(3,VV[139],(V624),(V625));
	{object V630 = list(6,VV[87],(V624),VV[97],/* INLINE-ARGS */V629,VV[89],list(3,VV[139],(V624),(V627)));
	VMR61(V630)}
}
/*	local entry for function FIRST-SLOOP-FOR	*/

static object LI62(V635,V636,V637,V638)

register object V635;object V636;object V637;object V638;
{	 VMB62 VMS62 VMV62
TTL:;{object V639;
	V639= (*(LnkLI9))((V637),VV[223]);
	if(V639==Cnil)goto T1582;
	goto T1581;
T1582:;}
	base[0]= VV[232];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk247)();
	vs_top=sup;
T1581:;
	if((symbol_value(VV[42]))!=Cnil){
	goto T1586;}
	V640= list(3,VV[139],(V635),(V636));
	{object V641 = list(6,VV[87],(V635),VV[97],/* INLINE-ARGS */V640,VV[89],list(3,VV[139],(V635),(V638)));
	VMR62(V641)}
T1586:;
	{object V642;
	vs_base=vs_top;
	(void) (*Lnk248)();
	vs_top=sup;
	V642= vs_base[0];
	V643= list(2,(V642),list(3,VV[139],(V635),(V638)));
	V644= list(3,VV[14],/* INLINE-ARGS */V643,list(2,Ct,list(3,VV[139],(V635),(V636))));
	{object V645 = list(8,VV[87],(V635),VV[87],(V642),VV[56],/* INLINE-ARGS */V644,VV[89],list(3,VV[139],(V642),Ct));
	VMR62(V645)}}
}
/*	function definition for FIND-IN-ORDERED-LIST	*/

static L63()
{register object *base=vs_base;
	register object *sup=base+VM63; VC63
	vs_reserve(VM63);
	{register object V646;
	object V647;
	register object V648;
	if(vs_top-vs_base<2) too_few_arguments();
	if(vs_top-vs_base>3) too_many_arguments();
	V646=(base[0]);
	V647=(base[1]);
	vs_base=vs_base+2;
	if(vs_base>=vs_top){vs_top=sup;goto T1589;}
	V648=(base[2]);
	vs_top=sup;
	goto T1590;
T1589:;
	V648= symbol_value(VV[233]);
T1590:;
	{register object V649;
	V649= Cnil;
	{register object V650;
	V650= (V647);
T1594:;
	if(((V650))!=Cnil){
	goto T1595;}
	base[3]= (V649);
	base[4]= Cnil;
	vs_top=(vs_base=base+3)+2;
	return;
T1595:;
	if(!(eql(car((V650)),(V646)))){
	goto T1603;}
	base[3]= (V650);
	base[4]= Ct;
	vs_top=(vs_base=base+3)+2;
	return;
T1603:;
	base[3]= (V646);
	base[4]= car((V650));
	vs_top=(vs_base=base+3)+2;
	super_funcall_no_event((V648));
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T1601;}
	base[3]= (V649);
	base[4]= Cnil;
	vs_top=(vs_base=base+3)+2;
	return;
T1601:;
	V649= (V650);
	V650= cdr((V650));
	goto T1594;}}
	}
}
/*	local entry for function COLLATE-SLOOP-COLLECT	*/

static object LI64(V653,V654)

object V653;object V654;
{	 VMB64 VMS64 VMV64
TTL:;
	V655= list(3,VV[236],(V654),(V653));
	V656= list(2,VV[238],list(3,VV[15],VV[239],list(3,VV[119],(V654),VV[240])));
	{object V657 = list(2,VV[56],list(4,VV[234],VV[235],/* INLINE-ARGS */V655,list(3,VV[104],VV[237],list(3,VV[14],/* INLINE-ARGS */V656,list(2,Ct,list(3,VV[15],(V653),list(3,VV[119],(V654),(V653))))))));
	VMR64(V657)}
}
/*	local entry for function IN-FRINGE-SLOOP-MAP	*/

static object LI65(V660,V661)

register object V660;object V661;
{	 VMB65 VMS65 VMV65
TTL:;
	{register object V662;
	vs_base=vs_top;
	(void) (*Lnk248)();
	vs_top=sup;
	V662= vs_base[0];
	V663= make_cons((V660),Cnil);
	V664= list(2,(V662),VV[244]);
	V665= make_cons(/* INLINE-ARGS */V664,Cnil);
	V666= list(2,VV[140],(V662));
	V667= make_cons(/* INLINE-ARGS */V666,Cnil);
	V668= list(2,VV[229],(V662));
	V669= list(3,VV[15],(V660),(V662));
	V670= list(3,/* INLINE-ARGS */V668,/* INLINE-ARGS */V669,list(3,VV[15],(V662),Cnil));
	V671= list(3,VV[15],(V660),list(2,VV[17],(V662)));
	V672= list(3,VV[14],/* INLINE-ARGS */V670,list(3,Ct,/* INLINE-ARGS */V671,list(3,VV[15],(V662),list(2,VV[18],(V662)))));
	V673= list(2,VV[140],(V660));
	V674= make_cons(/* INLINE-ARGS */V673,Cnil);
	V675= list(2,VV[229],(V660));
	V676= make_cons(/* INLINE-ARGS */V675,VV[245]);
	V677= list(3,VV[242],VV[243],list(5,VV[56],/* INLINE-ARGS */V665,/* INLINE-ARGS */V667,/* INLINE-ARGS */V672,list(4,VV[14],/* INLINE-ARGS */V674,/* INLINE-ARGS */V676,list(2,Ct,list(2,VV[242],(V660))))));
	V678= make_cons(/* INLINE-ARGS */V677,Cnil);
	{object V679 = list(3,VV[12],/* INLINE-ARGS */V663,list(3,VV[241],/* INLINE-ARGS */V678,list(2,VV[242],(V661))));
	VMR65(V679)}}
}
static LnkT61(){ call_or_link(VV[61],&Lnk61);} /* LIST */
static LnkT297(){ call_or_link(VV[297],&Lnk297);} /* LIST* */
static LnkT217(){ call_or_link(VV[217],&Lnk217);} /* FIND-PACKAGE */
static LnkT166(){ call_or_link(VV[166],&Lnk166);} /* <= */
static LnkT165(){ call_or_link(VV[165],&Lnk165);} /* >= */
static LnkT296(){ call_or_link(VV[296],&Lnk296);} /* INTERN */
static LnkT295(){ call_or_link(VV[295],&Lnk295);} /* SUBTYPEP */
static object  LnkTLI294(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[294],&LnkLI294,2,ap);} /* THE-TYPE */
static object  LnkTLI293(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[293],&LnkLI293,2,ap);} /* PARSE-LOOP-MAP */
static LnkT292(){ call_or_link(VV[292],&Lnk292);} /* FORMAT */
static LnkT291(){ call_or_link(VV[291],&Lnk291);} /* CERROR */
static object  LnkTLI290(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[290],&LnkLI290,ap);} /* ADD-FROM-DATA */
static LnkT115(){ call_or_link(VV[115],&Lnk115);} /* COPY-LIST */
static object  LnkTLI289(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[289],&LnkLI289,ap);} /* LOOP-DECLARE-BINDING */
static LnkT288(){ call_or_link(VV[288],&Lnk288);} /* SYMBOL-PACKAGE */
static object  LnkTLI287(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[287],&LnkLI287,2,ap);} /* MAKE-VALUE */
static LnkT129(){ call_or_link(VV[129],&Lnk129);} /* TYPEP */
static LnkT286(){ call_or_link(VV[286],&Lnk286);} /* EVAL */
static LnkT285(){ call_or_link(VV[285],&Lnk285);} /* SUBST */
static LnkT284(){ call_or_link(VV[284],&Lnk284);} /* EQ */
static LnkT283(){ call_or_link(VV[283],&Lnk283);} /* CONSP */
static LnkT282(){ call_or_link(VV[282],&Lnk282);} /* KEYWORDP */
static LnkT281(){ call_or_link(VV[281],&Lnk281);} /* GETF */
static object  LnkTLI280(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[280],&LnkLI280,3,ap);} /* LOOP-PARSE-ADDITIONAL-COLLECTIONS */
static LnkT279(){ call_or_link(VV[279],&Lnk279);} /* ADJOIN */
static object  LnkTLI278(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[278],&LnkLI278,1,ap);} /* POINTER-FOR-COLLECT */
static object  LnkTLI277(){return call_proc0(VV[277],&LnkLI277);} /* PARSE-ONE-WHEN-CLAUSE */
static LnkT140(){ call_or_link(VV[140],&Lnk140);} /* NULL */
static LnkT276(){ call_or_link(VV[276],&Lnk276);} /* CONSTANTP */
static LnkT275(){ call_or_link(VV[275],&Lnk275);} /* LISTP */
static object  LnkTLI274(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[274],&LnkLI274,ap);} /* LOOP-ADD-TEMPS */
static LnkT105(){ call_or_link(VV[105],&Lnk105);} /* NOT */
static object  LnkTLI273(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[273],&LnkLI273,ap);} /* LOOP-ADD-BINDING */
static object  LnkTLI272(){return call_proc0(VV[272],&LnkLI272);} /* LOOP-UN-POP */
static object  LnkTLI271(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[271],&LnkLI271,ap);} /* PARSE-LOOP-MACRO */
static object  LnkTLI270(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[270],&LnkLI270,ap);} /* PARSE-LOOP-DECLARE */
static object  LnkTLI269(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[269],&LnkLI269,ap);} /* PARSE-LOOP-WITH */
static object  LnkTLI268(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[268],&LnkLI268,1,ap);} /* PARSE-LOOP-INITIALLY */
static object  LnkTLI267(){return call_proc0(VV[267],&LnkLI267);} /* PARSE-LOOP-COLLECT */
static object  LnkTLI266(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[266],&LnkLI266,1,ap);} /* LOOP-COLLECT-KEYWORD-P */
static object  LnkTLI265(){return call_proc0(VV[265],&LnkLI265);} /* PARSE-LOOP-WHEN */
static object  LnkTLI264(){return call_proc0(VV[264],&LnkLI264);} /* PARSE-LOOP-DO */
static object  LnkTLI263(){return call_proc0(VV[263],&LnkLI263);} /* PARSE-LOOP-FOR */
static object  LnkTLI262(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[262],&LnkLI262,1,ap);} /* PARSE-NO-BODY */
static object  LnkTLI261(){return call_proc0(VV[261],&LnkLI261);} /* LOOP-POP */
static object  LnkTLI9(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[9],&LnkLI9,2,ap);} /* L-EQUAL */
static object  LnkTLI260(){return call_proc0(VV[260],&LnkLI260);} /* LOOP-PEEK */
static object  LnkTLI13(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[13],&LnkLI13,1,ap);} /* TRANSLATE-NAME */
static object  LnkTLI259(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[259],&LnkLI259,1,ap);} /* LOOP-LET-BINDINGS */
static LnkT258(){ call_or_link(VV[258],&Lnk258);} /* COPY-TREE */
static object  LnkTLI257(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[257],&LnkLI257,1,ap);} /* SUBSTITUTE-SLOOP-BODY */
static LnkT114(){ call_or_link(VV[114],&Lnk114);} /* APPEND */
static LnkT256(){ call_or_link(VV[256],&Lnk256);} /* EQL */
static object  LnkTLI255(){return call_proc0(VV[255],&LnkLI255);} /* PARSE-LOOP1 */
static object  LnkTLI253(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[253],&LnkLI253,ap);} /* FIND */
static LnkT252(){ call_or_link(VV[252],&Lnk252);} /* MEMBER */
static LnkT113(){ call_or_link(VV[113],&Lnk113);} /* EQUAL */
static LnkT251(){ call_or_link(VV[251],&Lnk251);} /* SYMBOLP */
static object  LnkTLI250(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[250],&LnkLI250,ap);} /* DEF-LOOP-INTERNAL */
static object  LnkTLI249(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[249],&LnkLI249,1,ap);} /* PARSE-LOOP */
static LnkT248(){ call_or_link(VV[248],&Lnk248);} /* GENSYM */
static LnkT247(){ call_or_link(VV[247],&Lnk247);} /* ERROR */
static object  LnkTLI246(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[246],&LnkLI246,2,ap);} /* DESETQ1 */
