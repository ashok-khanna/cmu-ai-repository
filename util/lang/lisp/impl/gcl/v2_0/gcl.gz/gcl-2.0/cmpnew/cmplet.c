
#include <cmpinclude.h>
#include "cmplet.h"
init_cmplet(){do_init(VV);}
/*	local entry for function C1LET	*/

static object LI1(V2)

object V2;
{	 VMB1 VMS1 VMV1
	bds_check;
TTL:;
	{object V3;
	object V4;
	register object V5;
	register object V6;
	register object V7;
	object V8;
	object V9;
	object V10;
	object V11;
	object V12;
	V3= (VFUN_NARGS=0,(*(LnkLI39))());
	V4= symbol_value(VV[0]);
	V5= Cnil;
	V6= Cnil;
	V7= Cnil;
	V8= Cnil;
	V9= Cnil;
	V10= Cnil;
	V11= Cnil;
	V12= Cnil;
	bds_bind(VV[1],symbol_value(VV[1]));
	if(!(endp((V2)))){
	goto T11;}
	(void)((*(LnkLI40))(VV[2],small_fixnum(1),small_fixnum(0)));
T11:;
	base[2]= cdr((V2));
	base[3]= Cnil;
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk41)();
	if(vs_base<vs_top){
	V11= vs_base[0];
	vs_base++;
	}else{
	V11= Cnil;}
	if(vs_base<vs_top){
	V8= vs_base[0];
	vs_base++;
	}else{
	V8= Cnil;}
	if(vs_base<vs_top){
	V10= vs_base[0];
	vs_base++;
	}else{
	V10= Cnil;}
	if(vs_base<vs_top){
	V9= vs_base[0];
	vs_base++;
	}else{
	V9= Cnil;}
	if(vs_base<vs_top){
	V12= vs_base[0];
	}else{
	V12= Cnil;}
	vs_top=sup;
	(void)((*(LnkLI42))((V8)));
	{register object V13;
	register object V14;
	V13= car((V2));
	V14= car((V13));
T23:;
	if(!(endp((V13)))){
	goto T24;}
	goto T19;
T24:;
	if(!(type_of((V14))==t_symbol)){
	goto T30;}
	{object V15;
	V15= (*(LnkLI43))((V14),(V8),(V9),(V10));
	V7= make_cons((V14),(V7));
	V6= make_cons((V15),(V6));
	V16= structure_ref((V15),VV[3],5);
	V17= (*(LnkLI44))(/* INLINE-ARGS */V16);
	V5= make_cons(/* INLINE-ARGS */V17,(V5));
	goto T28;}
T30:;
	if(!(type_of((V14))==t_cons)){
	goto T39;}
	if(endp(cdr((V14)))){
	goto T38;}
	if(endp(cddr((V14)))){
	goto T38;}
T39:;
	(void)((VFUN_NARGS=2,(*(LnkLI45))(VV[4],(V14))));
T38:;
	{object V18;
	V18= (*(LnkLI43))(car((V14)),(V8),(V9),(V10));
	V7= make_cons(car((V14)),(V7));
	V6= make_cons((V18),(V6));
	if(!(endp(cdr((V14))))){
	goto T53;}
	V20= structure_ref((V18),VV[3],5);
	V19= (*(LnkLI44))(/* INLINE-ARGS */V20);
	goto T51;
T53:;
	V21= structure_ref((V18),VV[3],5);
	V22= (*(LnkLI47))(cadr((V14)),(V3));
	V19= (*(LnkLI46))(/* INLINE-ARGS */V21,/* INLINE-ARGS */V22,cadr((V14)));
T51:;
	V5= make_cons(V19,(V5));}
T28:;
	V13= cdr((V13));
	V14= car((V13));
	goto T23;}
T19:;
	{register object V23;
	object V24;
	V23= reverse((V6));
	V24= car((V23));
T64:;
	if(!(endp((V23)))){
	goto T65;}
	goto T60;
T65:;
	(VV[1]->s.s_dbind)= make_cons((V24),(VV[1]->s.s_dbind));
	V23= cdr((V23));
	V24= car((V23));
	goto T64;}
T60:;
	(void)((*(LnkLI48))((V7),(V10),(V9)));
	V11= (*(LnkLI49))((V12),(V11));
	(void)((*(LnkLI50))((V3),cadr((V11))));
	V25= structure_ref(cadr((V11)),VV[5],2);
	(void)(structure_set((V3),VV[5],2,/* INLINE-ARGS */V25));
	{register object V26;
	object V27;
	V26= (V6);
	V27= car((V26));
T85:;
	if(!(endp((V26)))){
	goto T86;}
	goto T81;
T86:;
	(void)((*(LnkLI51))((V27)));
	V26= cdr((V26));
	V27= car((V26));
	goto T85;}
T81:;{object V28;
	base[2]= (V4);
	base[3]= symbol_value(VV[0]);
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk52)();
	vs_top=sup;
	V28= vs_base[0];
	if(V28==Cnil)goto T97;
	goto T96;
T97:;}
	(void)(structure_set((V3),VV[5],4,Ct));
T96:;
	V29= reverse((V6));
	{object V30 = list(5,VV[2],(V3),/* INLINE-ARGS */V29,reverse((V5)),(V11));
	bds_unwind1;
	VMR1(V30)}}
}
/*	local entry for function C2LET	*/

static object LI2(V34,V35,V36)

object V34;object V35;object V36;
{	 VMB2 VMS2 VMV2
	bds_check;
TTL:;
	{object V37;
	register object V38;
	register object V39;
	V37= Cnil;
	V38= Cnil;
	V39= Cnil;
	bds_bind(VV[6],symbol_value(VV[6]));
	bds_bind(VV[7],symbol_value(VV[7]));
	bds_bind(VV[8],symbol_value(VV[8]));
	bds_bind(VV[9],symbol_value(VV[9]));
	{object V40;
	object V41;
	object V42;
	V40= (V34);
	V41= (V35);
	V42= Cnil;
T106:;
	if(!(endp((V40)))){
	goto T107;}
	goto T104;
T107:;
	{register object V43;
	register object V44;
	object V45;
	V43= car((V41));
	V44= car((V40));
	V45= (*(LnkLI53))((V44));
	if(((V45))==Cnil){
	goto T117;}
	(void)(structure_set((V44),VV[3],1,(V45)));
	setq(VV[10],number_plus(symbol_value(VV[10]),small_fixnum(1)));
	(void)(structure_set((V44),VV[3],4,symbol_value(VV[10])));
	goto T115;
T117:;
	V46= structure_ref((V44),VV[3],1);
	if(!((/* INLINE-ARGS */V46)==(VV[11]))){
	goto T122;}{object V47;
	base[7]= structure_ref((V44),VV[3],4);
	vs_top=(vs_base=base+7)+1;
	(void) (*Lnk54)();
	vs_top=sup;
	V47= vs_base[0];
	if(V47==Cnil)goto T124;
	goto T115;
T124:;}
	(void)((*(LnkLI55))());
	goto T115;
T122:;
	V48= (*(LnkLI56))();
	(void)(structure_set((V44),VV[3],2,/* INLINE-ARGS */V48));
T115:;
	V50= structure_ref((V44),VV[3],1);
	{object V49= /* INLINE-ARGS */V50;
	if((V49!= VV[57])
	&& (V49!= VV[58])
	&& (V49!= VV[59])
	&& (V49!= VV[60])
	&& (V49!= VV[61]))goto T128;
	V51= list(3,VV[12],list(3,VV[3],(V44),Cnil),(V43));
	V39= make_cons(/* INLINE-ARGS */V51,(V39));
	goto T127;
T128:;
	{object V52= car((V43));
	if((V52!= VV[62]))goto T130;
	if(((*(LnkLI63))((V44),(V36)))==Cnil){
	goto T132;}
	(void)(structure_set((V44),VV[3],1,VV[13]));
	(void)(structure_set((V44),VV[3],4,caddr((V43))));
	goto T127;
T132:;
	V53= list(2,(V44),caddr((V43)));
	V38= make_cons(/* INLINE-ARGS */V53,(V38));
	goto T127;
T130:;
	if((V52!= VV[3]))goto T136;
	{register object V54;
	V54= caaddr((V43));
	if(((*(LnkLI64))((V54),cdr((V41))))!=Cnil){
	goto T138;}
	V56= structure_ref((V54),VV[3],1);
	{register object x= /* INLINE-ARGS */V56,V55= VV[14];
	while(!endp(V55))
	if(eql(x,V55->c.c_car)){
	goto T143;
	}else V55=V55->c.c_cdr;
	goto T139;}
T143:;
	V58= structure_ref((V54),VV[3],0);
	{register object x= /* INLINE-ARGS */V58,V57= (V42);
	while(!endp(V57))
	if(eql(x,V57->c.c_car)){
	goto T144;
	}else V57=V57->c.c_cdr;
	goto T139;}
T144:;
T138:;
	V60= structure_ref((V44),VV[3],1);
	if(!((/* INLINE-ARGS */V60)==(VV[15]))){
	goto T148;}
	V59= list(3,VV[3],(V44),Cnil);
	goto T146;
T148:;
	V61= structure_ref((V44),VV[3],1);
	if(!((/* INLINE-ARGS */V61)==(VV[11]))){
	goto T151;}
	V59= list(2,VV[11],structure_ref((V44),VV[3],4));
	goto T146;
T151:;
	V62= make_cons((V44),Cnil);
	V38= make_cons(/* INLINE-ARGS */V62,(V38));
	V59= list(2,VV[16],structure_ref((V44),VV[3],2));
T146:;
	V63= list(3,VV[12],V59,(V43));
	V39= make_cons(/* INLINE-ARGS */V63,(V39));
	goto T127;
T139:;
	if(((*(LnkLI63))((V44),(V36)))==Cnil){
	goto T156;}
	V65= structure_ref((V54),VV[3],1);
	{register object x= /* INLINE-ARGS */V65,V64= VV[17];
	while(!endp(V64))
	if(eql(x,V64->c.c_car)){
	goto T160;
	}else V64=V64->c.c_cdr;
	goto T156;}
T160:;
	if((structure_ref((V54),VV[3],3))!=Cnil){
	goto T156;}
	V67= structure_ref(cadr((V36)),VV[5],0);
	{register object x= (V54),V66= /* INLINE-ARGS */V67;
	while(!endp(V66))
	if(eql(x,V66->c.c_car)){
	goto T156;
	}else V66=V66->c.c_cdr;}
	(void)(structure_set((V44),VV[3],1,VV[13]));
	V70= structure_ref((V54),VV[3],1);
	{object V69= /* INLINE-ARGS */V70;
	if((V69!= VV[28]))goto T166;
	V68= list(2,VV[16],structure_ref((V54),VV[3],2));
	goto T165;
T166:;
	if((V69!= VV[13]))goto T167;
	V68= structure_ref((V54),VV[3],4);
	goto T165;
T167:;
	if((V69!= VV[15]))goto T168;
	V68= list(2,VV[18],structure_ref((V54),VV[3],4));
	goto T165;
T168:;
	V68= (*(LnkLI65))();}
T165:;
	(void)(structure_set((V44),VV[3],4,V68));
	goto T127;
T156:;
	V71= list(2,(V44),list(3,VV[3],(V54),cadr(caddr((V43)))));
	V38= make_cons(/* INLINE-ARGS */V71,(V38));
	goto T127;}
T136:;
	V73= structure_ref((V44),VV[3],1);
	if(!((/* INLINE-ARGS */V73)==(VV[15]))){
	goto T173;}
	V72= list(3,VV[3],(V44),Cnil);
	goto T171;
T173:;
	V74= structure_ref((V44),VV[3],1);
	if(!((/* INLINE-ARGS */V74)==(VV[11]))){
	goto T176;}
	V72= list(2,VV[11],structure_ref((V44),VV[3],4));
	goto T171;
T176:;
	V75= make_cons((V44),Cnil);
	V38= make_cons(/* INLINE-ARGS */V75,(V38));
	V72= list(2,VV[16],structure_ref((V44),VV[3],2));
T171:;
	V76= list(3,VV[12],V72,(V43));
	V39= make_cons(/* INLINE-ARGS */V76,(V39));}}
T127:;
	V77= structure_ref((V44),VV[3],1);
	if(!((/* INLINE-ARGS */V77)==(VV[19]))){
	goto T111;}
	V78= structure_ref((V44),VV[3],0);
	V42= make_cons(/* INLINE-ARGS */V78,(V42));}
T111:;
	V40= cdr((V40));
	V41= cdr((V41));
	goto T106;}
T104:;
	V37= (*(LnkLI66))((V34));
	{object V79;
	object V80;
	V79= reverse((V39));
	V80= car((V79));
T193:;
	if(!(endp((V79)))){
	goto T194;}
	goto T189;
T194:;
	base[6]= cadr((V80));
	bds_bind(VV[20],base[6]);
	V81= (*(LnkLI12))(caddr((V80)));
	bds_unwind1;
	V79= cdr((V79));
	V80= car((V79));
	goto T193;}
T189:;
	{object V82;
	object V83;
	V82= reverse((V38));
	V83= car((V82));
T209:;
	if(!(endp((V82)))){
	goto T210;}
	goto T205;
T210:;
	if((cdr((V83)))==Cnil){
	goto T216;}
	(void)((*(LnkLI67))(car((V83)),cadr((V83))));
	goto T214;
T216:;
	(void)((*(LnkLI68))(car((V83))));
T214:;
	V82= cdr((V82));
	V83= car((V82));
	goto T209;}
T205:;
	base[4]= (V36);
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk69)();
	vs_top=sup;
	if(((V37))==Cnil){
	goto T226;}
	princ_char(125,VV[21]);
	{object V84 = Cnil;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	VMR2(V84)}
T226:;
	{object V85 = Cnil;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	VMR2(V85)}}
}
/*	local entry for function C1LET*	*/

static object LI3(V87)

object V87;
{	 VMB3 VMS3 VMV3
	bds_check;
TTL:;
	{register object V88;
	register object V89;
	register object V90;
	object V91;
	object V92;
	object V93;
	object V94;
	object V95;
	object V96;
	object V97;
	V88= Cnil;
	V89= Cnil;
	V90= Cnil;
	V91= symbol_value(VV[0]);
	V92= Cnil;
	V93= Cnil;
	V94= Cnil;
	V95= Cnil;
	V96= Cnil;
	V97= (VFUN_NARGS=0,(*(LnkLI39))());
	bds_bind(VV[1],symbol_value(VV[1]));
	if(!(endp((V87)))){
	goto T239;}
	(void)((*(LnkLI40))(VV[22],small_fixnum(1),small_fixnum(0)));
T239:;
	base[2]= cdr((V87));
	base[3]= Cnil;
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk41)();
	if(vs_base<vs_top){
	V95= vs_base[0];
	vs_base++;
	}else{
	V95= Cnil;}
	if(vs_base<vs_top){
	V92= vs_base[0];
	vs_base++;
	}else{
	V92= Cnil;}
	if(vs_base<vs_top){
	V94= vs_base[0];
	vs_base++;
	}else{
	V94= Cnil;}
	if(vs_base<vs_top){
	V93= vs_base[0];
	vs_base++;
	}else{
	V93= Cnil;}
	if(vs_base<vs_top){
	V96= vs_base[0];
	}else{
	V96= Cnil;}
	vs_top=sup;
	(void)((*(LnkLI42))((V92)));
	{register object V98;
	register object V99;
	V98= car((V87));
	V99= car((V98));
T251:;
	if(!(endp((V98)))){
	goto T252;}
	goto T247;
T252:;
	if(!(type_of((V99))==t_symbol)){
	goto T258;}
	{object V100;
	V100= (*(LnkLI43))((V99),(V92),(V93),(V94));
	V90= make_cons((V99),(V90));
	V101= structure_ref((V100),VV[3],5);
	V102= (*(LnkLI44))(/* INLINE-ARGS */V101);
	V88= make_cons(/* INLINE-ARGS */V102,(V88));
	V89= make_cons((V100),(V89));
	(VV[1]->s.s_dbind)= make_cons((V100),(VV[1]->s.s_dbind));
	goto T256;}
T258:;
	if(!(type_of((V99))==t_cons)){
	goto T268;}
	if(endp(cdr((V99)))){
	goto T269;}
	if(endp(cddr((V99)))){
	goto T269;}
T268:;
	(void)((VFUN_NARGS=2,(*(LnkLI45))(VV[23],(V99))));
	goto T256;
T269:;
	{register object V103;
	V103= (*(LnkLI43))(car((V99)),(V92),(V93),(V94));
	V90= make_cons(car((V99)),(V90));
	if(!(endp(cdr((V99))))){
	goto T282;}
	V105= structure_ref((V103),VV[3],5);
	V104= (*(LnkLI44))(/* INLINE-ARGS */V105);
	goto T280;
T282:;
	V106= structure_ref((V103),VV[3],5);
	V107= (*(LnkLI47))(cadr((V99)),(V97));
	V104= (*(LnkLI46))(/* INLINE-ARGS */V106,/* INLINE-ARGS */V107,cadr((V99)));
T280:;
	V88= make_cons(V104,(V88));
	V89= make_cons((V103),(V89));
	(VV[1]->s.s_dbind)= make_cons((V103),(VV[1]->s.s_dbind));}
T256:;
	V98= cdr((V98));
	V99= car((V98));
	goto T251;}
T247:;
	(void)((*(LnkLI48))((V90),(V94),(V93)));
	V95= (*(LnkLI49))((V96),(V95));
	(void)((*(LnkLI50))((V97),cadr((V95))));
	V108= structure_ref(cadr((V95)),VV[5],2);
	(void)(structure_set((V97),VV[5],2,/* INLINE-ARGS */V108));
	{register object V109;
	object V110;
	V109= (V89);
	V110= car((V109));
T301:;
	if(!(endp((V109)))){
	goto T302;}
	goto T297;
T302:;
	(void)((*(LnkLI51))((V110)));
	V109= cdr((V109));
	V110= car((V109));
	goto T301;}
T297:;{object V111;
	base[2]= (V91);
	base[3]= symbol_value(VV[0]);
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk52)();
	vs_top=sup;
	V111= vs_base[0];
	if(V111==Cnil)goto T313;
	goto T312;
T313:;}
	(void)(structure_set((V97),VV[5],4,Ct));
T312:;
	V112= reverse((V89));
	{object V113 = list(5,VV[22],(V97),/* INLINE-ARGS */V112,reverse((V88)),(V95));
	bds_unwind1;
	VMR3(V113)}}
}
/*	local entry for function C2LET*	*/

static object LI4(V117,V118,V119)

object V117;object V118;object V119;
{	 VMB4 VMS4 VMV4
	bds_check;
TTL:;
	{object V120;
	V120= Cnil;
	bds_bind(VV[6],symbol_value(VV[6]));
	bds_bind(VV[7],symbol_value(VV[7]));
	bds_bind(VV[8],symbol_value(VV[8]));
	bds_bind(VV[9],symbol_value(VV[9]));
	{object V121;
	register object V122;
	V121= (V117);
	V122= (V118);
T320:;
	if(!(endp((V121)))){
	goto T321;}
	goto T318;
T321:;
	{object V123;
	register object V124;
	object V125;
	V123= car((V122));
	V124= car((V121));
	V125= (*(LnkLI53))((V124));
	if(((V125))==Cnil){
	goto T329;}
	(void)(structure_set((V124),VV[3],1,(V125)));
	setq(VV[10],number_plus(symbol_value(VV[10]),small_fixnum(1)));
	(void)(structure_set((V124),VV[3],4,symbol_value(VV[10])));
T329:;
	V127= structure_ref((V124),VV[3],1);
	{register object x= /* INLINE-ARGS */V127,V126= VV[24];
	while(!endp(V126))
	if(eql(x,V126->c.c_car)){
	goto T336;
	}else V126=V126->c.c_cdr;
	goto T335;}
T336:;
	goto T325;
T335:;
	{object V128= car((V123));
	if((V128!= VV[62]))goto T337;
	if(((*(LnkLI70))((V124),(V119),cdr((V122))))==Cnil){
	goto T339;}
	(void)(structure_set((V124),VV[3],1,VV[13]));
	(void)(structure_set((V124),VV[3],4,caddr((V123))));
	goto T325;
T339:;
	{object V129;
	base[7]= structure_ref((V124),VV[3],1);
	base[8]= VV[15];
	vs_top=(vs_base=base+7)+2;
	(void) (*Lnk71)();
	vs_top=sup;
	V129= vs_base[0];
	if(((V129))==Cnil){
	goto T346;}
	goto T325;
T346:;
	V130= structure_ref((V124),VV[3],1);
	if(!((/* INLINE-ARGS */V130)==(VV[11]))){
	goto T349;}{object V131;
	base[7]= structure_ref((V124),VV[3],4);
	vs_top=(vs_base=base+7)+1;
	(void) (*Lnk54)();
	vs_top=sup;
	V131= vs_base[0];
	if(V131==Cnil)goto T351;
	goto T325;
T351:;}
	(void)((*(LnkLI65))());
	goto T325;
T349:;
	V132= (*(LnkLI56))();
	(void)(structure_set((V124),VV[3],2,/* INLINE-ARGS */V132));
	goto T325;}
T337:;
	if((V128!= VV[3]))goto T354;
	{register object V133;
	V133= caaddr((V123));
	if(((*(LnkLI70))((V124),(V119),cdr((V122))))==Cnil){
	goto T357;}
	V135= structure_ref((V133),VV[3],1);
	{register object x= /* INLINE-ARGS */V135,V134= VV[25];
	while(!endp(V134))
	if(eql(x,V134->c.c_car)){
	goto T361;
	}else V134=V134->c.c_cdr;
	goto T357;}
T361:;
	if((structure_ref((V133),VV[3],3))!=Cnil){
	goto T357;}
	if(((*(LnkLI64))((V133),cdr((V122))))!=Cnil){
	goto T357;}
	V137= structure_ref(cadr((V119)),VV[5],0);
	{register object x= (V133),V136= /* INLINE-ARGS */V137;
	while(!endp(V136))
	if(eql(x,V136->c.c_car)){
	goto T357;
	}else V136=V136->c.c_cdr;}
	(void)(structure_set((V124),VV[3],1,VV[13]));
	V140= structure_ref((V133),VV[3],1);
	{object V139= /* INLINE-ARGS */V140;
	if((V139!= VV[28]))goto T369;
	V138= list(2,VV[16],structure_ref((V133),VV[3],2));
	goto T368;
T369:;
	if((V139!= VV[13]))goto T370;
	V138= structure_ref((V133),VV[3],4);
	goto T368;
T370:;
	if((V139!= VV[15]))goto T371;
	V138= list(2,VV[18],structure_ref((V133),VV[3],4));
	goto T368;
T371:;
	V138= (*(LnkLI65))();}
T368:;
	(void)(structure_set((V124),VV[3],4,V138));
	goto T325;
T357:;
	{object V141;
	base[7]= structure_ref((V124),VV[3],1);
	base[8]= VV[15];
	vs_top=(vs_base=base+7)+2;
	(void) (*Lnk71)();
	vs_top=sup;
	V141= vs_base[0];
	if(((V141))==Cnil){
	goto T376;}
	goto T325;
T376:;
	V142= (*(LnkLI56))();
	(void)(structure_set((V124),VV[3],2,/* INLINE-ARGS */V142));
	goto T325;}}
T354:;
	if((V128!= VV[71])
	&& !eql(V128,VV[26])
	&& !eql(V128,VV[27]))goto T378;
	goto T325;
T378:;
	V143= (*(LnkLI56))();
	(void)(structure_set((V124),VV[3],2,/* INLINE-ARGS */V143));}}
T325:;
	V121= cdr((V121));
	V122= cdr((V122));
	goto T320;}
T318:;
	V120= (*(LnkLI66))((V117));
	{object V144;
	object V145;
	register object V146;
	register object V147;
	V144= (V117);
	V145= (V118);
	V146= Cnil;
	V147= Cnil;
T387:;
	if(((V144))!=Cnil){
	goto T388;}
	goto T385;
T388:;
	V146= car((V144));
	V147= car((V145));
	V149= structure_ref((V146),VV[3],1);
	{object V148= /* INLINE-ARGS */V149;
	if((V148== VV[57])
	|| (V148== VV[58])
	|| (V148== VV[59])
	|| (V148== VV[60])
	|| (V148== VV[15]))goto T398;
	if((V148!= VV[61]))goto T397;
T398:;
	base[4]= list(3,VV[3],(V146),Cnil);
	bds_bind(VV[20],base[4]);
	V150= (*(LnkLI12))((V147));
	bds_unwind1;
	goto T396;
T397:;
	if((V148!= VV[13]))goto T400;
	goto T396;
T400:;
	{object V151= car((V147));
	if((V151!= VV[62]))goto T401;
	(void)((*(LnkLI67))((V146),caddr((V147))));
	goto T396;
T401:;
	if((V151!= VV[3]))goto T402;
	V152= list(3,VV[3],caaddr((V147)),cadr(caddr((V147))));
	(void)((*(LnkLI67))((V146),/* INLINE-ARGS */V152));
	goto T396;
T402:;
	(void)((*(LnkLI72))((V146),(V147)));}}
T396:;
	V144= cdr((V144));
	V145= cdr((V145));
	goto T387;}
T385:;
	base[4]= (V119);
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk69)();
	vs_top=sup;
	if(((V120))==Cnil){
	goto T410;}
	princ_char(125,VV[21]);
	{object V153 = Cnil;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	VMR4(V153)}
T410:;
	{object V154 = Cnil;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	VMR4(V154)}}
}
/*	local entry for function CAN-BE-REPLACED	*/

static object LI5(V157,V158)

register object V157;object V158;
{	 VMB5 VMS5 VMV5
TTL:;{object V159;
	base[0]= structure_ref((V157),VV[3],1);
	base[1]= VV[28];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk71)();
	vs_top=sup;
	V159= vs_base[0];
	if(V159==Cnil)goto T415;
	if((V159)!=Cnil){
	goto T413;}
	goto T414;
T415:;}
	base[0]= structure_ref((V157),VV[3],1);
	base[1]= VV[15];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk71)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T419;}
	goto T414;
T419:;
	base[0]= structure_ref((V157),VV[3],6);
	base[1]= symbol_value(VV[29]);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk73)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T413;}
T414:;
	{object V160 = Cnil;
	VMR5(V160)}
T413:;
	base[0]= structure_ref((V157),VV[3],3);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk74)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T425;}
	{object V161 = Cnil;
	VMR5(V161)}
T425:;
	base[1]= structure_ref((V157),VV[3],4);
	base[2]= VV[30];
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk71)();
	vs_top=sup;
	base[0]= vs_base[0];
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk75)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T428;}
	{object V162 = Cnil;
	VMR5(V162)}
T428:;
	V164= structure_ref(cadr((V158)),VV[5],0);
	{register object x= (V157),V163= /* INLINE-ARGS */V164;
	while(!endp(V163))
	if(eql(x,V163->c.c_car)){
	base[0]= V163;
	goto T433;
	}else V163=V163->c.c_cdr;
	base[0]= Cnil;}
T433:;
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk75)();
	vs_top=sup;
	{object V165 = vs_base[0];
	VMR5(V165)}
}
/*	local entry for function CAN-BE-REPLACED*	*/

static object LI6(V169,V170,V171)

register object V169;object V170;object V171;
{	 VMB6 VMS6 VMV6
TTL:;
	if(((*(LnkLI63))((V169),(V170)))!=Cnil){
	goto T434;}
	{object V172 = Cnil;
	VMR6(V172)}
T434:;
	{register object V173;
	register object V174;
	V173= (V171);
	V174= car((V173));
T439:;
	if(!(endp((V173)))){
	goto T440;}
	{object V175 = Ct;
	VMR6(V175)}
T440:;
	V177= structure_ref(cadr((V174)),VV[5],0);
	{register object x= (V169),V176= /* INLINE-ARGS */V177;
	while(!endp(V176))
	if(eql(x,V176->c.c_car)){
	goto T446;
	}else V176=V176->c.c_cdr;
	goto T444;}
T446:;
	{object V178 = Cnil;
	VMR6(V178)}
T444:;
	V173= cdr((V173));
	V174= car((V173));
	goto T439;}
}
/*	local entry for function WRITE-BLOCK-OPEN	*/

static object LI7(V180)

object V180;
{	 VMB7 VMS7 VMV7
TTL:;
	{register object V181;
	V181= Cnil;
	{register object V182;
	register object V183;
	V182= (V180);
	V183= car((V182));
T456:;
	if(!(endp((V182)))){
	goto T457;}
	goto T452;
T457:;
	{register object V184;
	V184= structure_ref((V183),VV[3],1);
	{register object x= (V184),V185= VV[31];
	while(!endp(V185))
	if(eql(x,V185->c.c_car)){
	goto T464;
	}else V185=V185->c.c_cdr;
	goto T461;}
T464:;
	princ_str("\n	",VV[21]);
	if(((V181))!=Cnil){
	goto T466;}
	princ_char(123,VV[21]);
	V181= Ct;
T466:;
	base[1]= (V183);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk76)();
	vs_top=sup;}
T461:;
	V182= cdr((V182));
	V183= car((V182));
	goto T456;}
T452:;
	{object V186 = (V181);
	VMR7(V186)}}
}
/*	macro definition for STACK-LET	*/

static L8()
{register object *base=vs_base;
	register object *sup=base+VM8; VC8
	vs_reserve(VM8);
	check_arg(2);
	vs_top=sup;
	{object V187=base[0]->c.c_cdr;
	base[2]= V187;}
	base[3]= make_cons(VV[2],base[2]);
	vs_top=(vs_base=base+3)+1;
	return;
}
/*	local entry for function C1STACK-LET	*/

static object LI9(V189)

object V189;
{	 VMB9 VMS9 VMV9
TTL:;
	{object V190;
	register object V191;
	V190= Cnil;
	V191= Cnil;
	{object V192;
	V192= car((V189));
	{register object V193;
	register object V194;
	V193= (V192);
	V194= car((V193));
T485:;
	if(!(endp((V193)))){
	goto T486;}
	goto T481;
T486:;
	if(!(type_of((V194))!=t_cons)){
	goto T494;}
	V195= (V194);
	goto T492;
T494:;
	{register object V196;
	{object V197;
	register object V198;
	V197= car((V194));
	V198= cadr((V194));
	base[1]= (V198);
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk77)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T499;}
	V196= Cnil;
	goto T496;
T499:;{object V199;
	base[1]= car((V198));
	base[2]= VV[32];
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk71)();
	vs_top=sup;
	V199= vs_base[0];
	if(V199==Cnil)goto T504;
	if((V199)!=Cnil){
	goto T502;}
	goto T503;
T504:;}
	base[1]= car((V198));
	base[2]= VV[33];
	vs_top=(vs_base=base+1)+2;
	(void) (*Lnk71)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T508;}
	goto T503;
T508:;
	base[1]= cddr((V198));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk74)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T512;}
	goto T503;
T512:;
	V198= list(3,VV[32],cadr((V198)),Cnil);
	if(((V198))!=Cnil){
	goto T502;}
T503:;
	V196= Cnil;
	goto T496;
T502:;
	setq(VV[10],number_plus(symbol_value(VV[10]),small_fixnum(1)));
	V191= make_cons(symbol_value(VV[10]),(V191));
	V196= list(2,(V197),listA(3,VV[34],car((V191)),cdr((V198))));}
T496:;
	if(((V196))==Cnil){
	goto T520;}
	V195= (V196);
	goto T492;
T520:;
	(void)((VFUN_NARGS=3,(*(LnkLI78))(VV[35],(V194),cdr((V189)))));
	V195= (V194);}
T492:;
	V190= make_cons(V195,(V190));
	V193= cdr((V193));
	V194= car((V193));
	goto T485;}
T481:;
	{object V200;
	V201= nreverse((V190));
	V202= listA(3,VV[2],/* INLINE-ARGS */V201,cdr((V189)));
	V200= (*(LnkLI79))(/* INLINE-ARGS */V202);
	{object V203 = list(4,VV[36],cadr((V200)),(V191),(V200));
	VMR9(V203)}}}}
}
/*	local entry for function C2STACK-LET	*/

static object LI10(V206,V207)

object V206;object V207;
{	 VMB10 VMS10 VMV10
TTL:;
	{object V208;
	setq(VV[10],number_plus(symbol_value(VV[10]),small_fixnum(1)));
	V208= symbol_value(VV[10]);
	princ_str("\n	{Cons_Macro",VV[21]);
	(void)((*(LnkLI80))((V208)));
	princ_char(59,VV[21]);
	base[0]= (V207);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk69)();
	vs_top=sup;
	princ_char(125,VV[21]);
	princ_str("\n#define Cons_Macro",VV[37]);
	(void)((*(LnkLI81))((V208)));
	base[0]= Cnil;
	base[1]= VV[38];
	base[2]= (V206);
	vs_top=(vs_base=base+0)+3;
	(void) (*Lnk82)();
	vs_top=sup;
	V209= vs_base[0];
	(void)((*(LnkLI81))(V209));
	{object V210 = Cnil;
	VMR10(V210)}}
}
static LnkT82(){ call_or_link(VV[82],&Lnk82);} /* FORMAT */
static object  LnkTLI81(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[81],&LnkLI81,1,ap);} /* WT-H1 */
static object  LnkTLI80(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[80],&LnkLI80,1,ap);} /* WT1 */
static object  LnkTLI79(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[79],&LnkLI79,1,ap);} /* C1EXPR */
static object  LnkTLI78(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[78],&LnkLI78,ap);} /* CMPWARN */
static LnkT77(){ call_or_link(VV[77],&Lnk77);} /* CONSP */
static LnkT76(){ call_or_link(VV[76],&Lnk76);} /* WT-VAR-DECL */
static LnkT75(){ call_or_link(VV[75],&Lnk75);} /* NOT */
static LnkT74(){ call_or_link(VV[74],&Lnk74);} /* NULL */
static LnkT73(){ call_or_link(VV[73],&Lnk73);} /* < */
static object  LnkTLI72(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[72],&LnkLI72,2,ap);} /* C2BIND-INIT */
static LnkT71(){ call_or_link(VV[71],&Lnk71);} /* EQ */
static object  LnkTLI70(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[70],&LnkLI70,3,ap);} /* CAN-BE-REPLACED* */
static LnkT69(){ call_or_link(VV[69],&Lnk69);} /* C2EXPR */
static object  LnkTLI68(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[68],&LnkLI68,1,ap);} /* C2BIND */
static object  LnkTLI67(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[67],&LnkLI67,2,ap);} /* C2BIND-LOC */
static object  LnkTLI12(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[12],&LnkLI12,1,ap);} /* C2EXPR* */
static object  LnkTLI66(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[66],&LnkLI66,1,ap);} /* WRITE-BLOCK-OPEN */
static object  LnkTLI65(){return call_proc0(VV[65],&LnkLI65);} /* BABOON */
static object  LnkTLI64(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[64],&LnkLI64,2,ap);} /* ARGS-INFO-CHANGED-VARS */
static object  LnkTLI63(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[63],&LnkLI63,2,ap);} /* CAN-BE-REPLACED */
static object  LnkTLI56(){return call_proc0(VV[56],&LnkLI56);} /* VS-PUSH */
static object  LnkTLI55(){return call_proc0(VV[55],&LnkLI55);} /* WFS-ERROR */
static LnkT54(){ call_or_link(VV[54],&Lnk54);} /* FIXNUMP */
static object  LnkTLI53(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[53],&LnkLI53,1,ap);} /* C2VAR-KIND */
static LnkT52(){ call_or_link(VV[52],&Lnk52);} /* EQL */
static object  LnkTLI51(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[51],&LnkLI51,1,ap);} /* CHECK-VREF */
static object  LnkTLI50(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[50],&LnkLI50,2,ap);} /* ADD-INFO */
static object  LnkTLI49(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[49],&LnkLI49,2,ap);} /* C1DECL-BODY */
static object  LnkTLI48(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[48],&LnkLI48,3,ap);} /* CHECK-VDECL */
static object  LnkTLI47(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[47],&LnkLI47,2,ap);} /* C1EXPR* */
static object  LnkTLI46(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[46],&LnkLI46,3,ap);} /* AND-FORM-TYPE */
static object  LnkTLI45(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[45],&LnkLI45,ap);} /* CMPERR */
static object  LnkTLI44(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[44],&LnkLI44,1,ap);} /* DEFAULT-INIT */
static object  LnkTLI43(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[43],&LnkLI43,4,ap);} /* C1MAKE-VAR */
static object  LnkTLI42(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[42],&LnkLI42,1,ap);} /* C1ADD-GLOBALS */
static LnkT41(){ call_or_link(VV[41],&Lnk41);} /* C1BODY */
static object  LnkTLI40(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[40],&LnkLI40,3,ap);} /* TOO-FEW-ARGS */
static object  LnkTLI39(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[39],&LnkLI39,ap);} /* MAKE-INFO */
