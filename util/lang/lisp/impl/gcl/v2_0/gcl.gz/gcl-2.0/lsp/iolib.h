
static L1();
static L2();
static L3();
static L4();
static L5();
static L6();
static L7();
static L8();
static object LI9();
static object LI10();
static object LI12();
#define VC1 object  V9 ,V8 ,V7 ,V6 ,V5;
#define VC2 object  V22 ,V21 ,V20 ,V19 ,V18 ,V17;
#define VC3 object  V29 ,V28 ,V27 ,V26 ,V25;
#define VC4
#define VC5
#define VC6
#define VC7
#define VC8 object  V63 ,V62 ,V61 ,V60 ,V59;
static object LI9();
#define VMB9 register object *base=vs_top; object  V66; object Vcs[2];
#define VMS9  register object *sup=vs_top+4;vs_top=sup;
#define VMV9 vs_reserve(4);
#define VMR9(VMT9) vs_top=base ; return(VMT9);
static object LI10();
#define VMB10 register object *base=vs_top; object  V72; object Vcs[2];
#define VMS10  register object *sup=vs_top+4;vs_top=sup;
#define VMV10 vs_reserve(4);
#define VMR10(VMT10) vs_top=base ; return(VMT10);
static object LI11();
#define VMB11 register object *base=vs_top; object  V89 ,V87;
#define VMS11  register object *sup=vs_top+4;vs_top=sup;
#define VMV11 vs_reserve(4);
#define VMR11(VMT11) vs_top=base ; return(VMT11);
static object LI12();
#define VMB12 register object *base=vs_top; object Vcs[2];
#define VMS12  register object *sup=vs_top+11;vs_top=sup;
#define VMV12 vs_reserve(11);
#define VMR12(VMT12) vs_top=base ; return(VMT12);
#define VM12 11
#define VM11 4
#define VM10 4
#define VM9 4
#define VM8 6
#define VM7 3
#define VM6 3
#define VM5 27
#define VM4 13
#define VM3 6
#define VM2 9
#define VM1 6
static char * VVi[68]={
#define Cdata VV[67]
(char *)(L1),
(char *)(L2),
(char *)(L3),
(char *)(L4),
(char *)(L5),
(char *)(L6),
(char *)(L7),
(char *)(L8),
(char *)(LI9),
(char *)(LI10),
(char *)(LI11),
(char *)(LI12)
};
#define VV ((object *)VVi)
static  LnkT66() ;
static  (*Lnk66)() = LnkT66;
static  LnkT65() ;
static  (*Lnk65)() = LnkT65;
static  LnkT64() ;
static  (*Lnk64)() = LnkT64;
static  LnkT63() ;
static  (*Lnk63)() = LnkT63;
static  LnkT11() ;
static  (*Lnk11)() = LnkT11;
static  LnkT62() ;
static  (*Lnk62)() = LnkT62;
static  LnkT3() ;
static  (*Lnk3)() = LnkT3;
static object  LnkTLI61() ;
static object  (*LnkLI61)() = LnkTLI61;
static  LnkT60() ;
static  (*Lnk60)() = LnkT60;
static object  LnkTLI59() ;
static object  (*LnkLI59)() = LnkTLI59;
static  LnkT58() ;
static  (*Lnk58)() = LnkT58;
static  LnkT57() ;
static  (*Lnk57)() = LnkT57;
static  LnkT9() ;
static  (*Lnk9)() = LnkT9;
static  LnkT56() ;
static  (*Lnk56)() = LnkT56;
static  LnkT55() ;
static  (*Lnk55)() = LnkT55;
static  LnkT44() ;
static  (*Lnk44)() = LnkT44;
static  LnkT6() ;
static  (*Lnk6)() = LnkT6;
static  LnkT43() ;
static  (*Lnk43)() = LnkT43;
static  LnkT4() ;
static  (*Lnk4)() = LnkT4;
static  LnkT38() ;
static  (*Lnk38)() = LnkT38;
