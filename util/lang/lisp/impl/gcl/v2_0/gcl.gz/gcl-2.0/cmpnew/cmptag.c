
#include <cmpinclude.h>
#include "cmptag.h"
init_cmptag(){do_init(VV);}
/*	local entry for function MAKE-TAG	*/

static object LI1(va_alist)
	va_dcl 
{	
	va_list ap;
	int narg = VFUN_NARGS; VMB1 VMS1 VMV1
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	narg= narg - 0;
	va_start(ap);
	{
	parse_key_new(narg,Vcs +0,&LI1key,ap);
	V1=(Vcs[0]);
	V2=(Vcs[1]);
	V3=(Vcs[2]);
	V4=(Vcs[3]);
	V5=(Vcs[4]);
	V6=(Vcs[5]);
	V7=(Vcs[6]);
	V8=(Vcs[7]);
	base[0]= VV[0];
	base[1]= (V1);
	base[2]= (V2);
	base[3]= (V3);
	base[4]= (V4);
	base[5]= (V5);
	base[6]= (V6);
	base[7]= (V7);
	base[8]= (V8);
	vs_top=(vs_base=base+0)+9;
	(void) (*Lnk45)();
	vs_top=sup;
	{object V9 = vs_base[0];
	VMR1(V9)}}
	}}
/*	local entry for function JUMPS-TO-P	*/

static object LI2(V12,V13)

register object V12;object V13;
{	 VMB2 VMS2 VMV2
TTL:;
	{object V14;
	V14= Cnil;
	if(!(type_of((V12))!=t_cons)){
	goto T12;}
	{object V15 = Cnil;
	VMR2(V15)}
T12:;
	{object V16;
	base[0]= car((V12));
	base[1]= VV[1];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk46)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T15;}
	V16= Cnil;
	goto T14;
T15:;
	V14= cadddr(cdr((V12)));
	base[0]= (V14);
	base[1]= VV[0];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk47)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T19;}
	V16= Cnil;
	goto T14;
T19:;
	base[0]= structure_ref((V14),VV[0],0);
	base[1]= (V13);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk46)();
	vs_top=sup;
	V16= vs_base[0];
T14:;
	if(((V16))==Cnil){
	goto T27;}
	{object V17 = (V16);
	VMR2(V17)}
T27:;{object V18;
	V18= (*(LnkLI48))(car((V12)),(V13));
	if(V18==Cnil)goto T29;
	{object V19 = V18;
	VMR2(V19)}
T29:;}
	V12= cdr((V12));
	goto TTL;}}
}
/*	local entry for function ADD-REG1	*/

static object LI3(V21)

register object V21;
{	 VMB3 VMS3 VMV3
TTL:;
	if(!(type_of((V21))!=t_cons)){
	goto T35;}
	base[0]= (V21);
	base[1]= VV[2];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk47)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T38;}
	{int V22= fix(structure_ref((V21),VV[2],6));
	V23 = make_fixnum((/* INLINE-ARGS */V22)+(fix(symbol_value(VV[3]))));
	{object V24 = structure_set((V21),VV[2],6,V23);
	VMR3(V24)}}
T38:;
	{object V25 = Cnil;
	VMR3(V25)}
T35:;
	(void)((*(LnkLI49))(car((V21))));
	V21= cdr((V21));
	goto TTL;
}
/*	local entry for function ADD-LOOP-REGISTERS	*/

static object LI4(V27)

object V27;
{	 VMB4 VMS4 VMV4
TTL:;
	{register object V28;
	register object V29;
	register object V30;
	V28= (V27);
	V29= Cnil;
	V30= Cnil;
T46:;
	if(((V28))!=Cnil){
	goto T47;}
	{register object V31;
	V31= (V30);
T51:;
	if(!(((V31))==((V29)))){
	goto T52;}
	{object V32 = (*(LnkLI49))(car((V31)));
	VMR4(V32)}
T52:;
	(void)((*(LnkLI49))(car((V31))));
	V31= cdr((V31));
	goto T51;}
T47:;
	base[0]= car((V28));
	base[1]= VV[0];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk47)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T61;}
	if((V30)!=Cnil){
	goto T66;}
	V30= (V28);
T66:;
	{register object V33;
	register object V34;
	V33= cdr((V28));
	V34= structure_ref(car((V28)),VV[0],0);
T71:;
	if(((V33))!=Cnil){
	goto T72;}
	goto T61;
T72:;
	if(((*(LnkLI48))(car((V33)),(V34)))==Cnil){
	goto T76;}
	V29= (V33);
T76:;
	V33= cdr((V33));
	goto T71;}
T61:;
	V28= cdr((V28));
	goto T46;}
}
/*	local entry for function C1TAGBODY	*/

static object LI5(V36)

object V36;
{	 VMB5 VMS5 VMV5
	bds_check;
TTL:;
	{register object V37;
	bds_bind(VV[4],symbol_value(VV[4]));
	V37= (VFUN_NARGS=0,(*(LnkLI50))());
	{object V38;
	object V39= (V36);
	if(endp(V39)){
	V36= Cnil;
	goto T88;}
	base[2]=V38=MMcons(Cnil,Cnil);
T89:;
	if(type_of((V39->c.c_car))==t_symbol){
	goto T91;}
	if(!(type_of((V39->c.c_car))==t_fixnum||type_of((V39->c.c_car))==t_bignum)){
	goto T92;}
T91:;
	{object V41;
	V41= (VFUN_NARGS=8,(*(LnkLI51))(VV[5],(V39->c.c_car),VV[6],Cnil,VV[7],Cnil,VV[8],Cnil));
	(VV[4]->s.s_dbind)= make_cons((V41),(VV[4]->s.s_dbind));
	(V38->c.c_car)= (V41);
	goto T90;}
T92:;
	(V38->c.c_car)= (V39->c.c_car);
T90:;
	if(endp(V39=MMcdr(V39))){
	V36= base[2];
	goto T88;}
	V38=MMcdr(V38)=MMcons(Cnil,Cnil);
	goto T89;}
T88:;
	{object V42;
	object V43= (V36);
	if(endp(V43)){
	V36= Cnil;
	goto T100;}
	base[2]=V42=MMcons(Cnil,Cnil);
T101:;
	base[3]= (V43->c.c_car);
	base[4]= VV[0];
	vs_top=(vs_base=base+3)+2;
	(void) (*Lnk47)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T104;}
	(V42->c.c_car)= (V43->c.c_car);
	goto T102;
T104:;
	(V42->c.c_car)= (*(LnkLI52))((V43->c.c_car),(V37));
T102:;
	if(endp(V43=MMcdr(V43))){
	V36= base[2];
	goto T100;}
	V42=MMcdr(V42)=MMcons(Cnil,Cnil);
	goto T101;}
T100:;
	{register object V45;
	register object V46;
	register object V47;
	register object V48;
	register object V49;
	V45= (V36);
	V46= Cnil;
	V47= Cnil;
	V48= Cnil;
	V49= Cnil;
T109:;
	if(!(endp((V45)))){
	goto T110;}
	if(((V49))!=Cnil){
	goto T113;}
	if(((V48))!=Cnil){
	goto T113;}
	if(((V47))==Cnil){
	goto T114;}
T113:;
	V46= reverse((V46));
	if(((V48))!=Cnil){
	goto T123;}
	if(((V49))==Cnil){
	goto T124;}
T123:;
	setq(VV[9],number_plus(symbol_value(VV[9]),small_fixnum(1)));
	goto T122;
T124:;
	(void)((*(LnkLI53))((V46)));
T122:;
	{object V50 = list(5,VV[10],(V37),(V48),(V49),(V46));
	bds_unwind1;
	VMR5(V50)}
T114:;
	V51= (*(LnkLI54))();
	V52= make_cons(/* INLINE-ARGS */V51,(V46));
	{object V53 = list(3,VV[11],(V37),reverse(/* INLINE-ARGS */V52));
	bds_unwind1;
	VMR5(V53)}
T110:;
	base[2]= car((V45));
	base[3]= VV[0];
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk47)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T132;}
	if((structure_ref(car((V45)),VV[0],3))==Cnil){
	goto T137;}
	V46= make_cons(car((V45)),(V46));
	V54= car((V45));
	V55= structure_ref(car((V45)),VV[0],0);
	V56= (*(LnkLI55))(/* INLINE-ARGS */V55);
	(void)(structure_set(/* INLINE-ARGS */V54,VV[0],6,/* INLINE-ARGS */V56));
	V49= Ct;
	goto T130;
T137:;
	if((structure_ref(car((V45)),VV[0],2))==Cnil){
	goto T144;}
	V46= make_cons(car((V45)),(V46));
	V57= car((V45));
	V58= structure_ref(car((V45)),VV[0],0);
	V59= (*(LnkLI55))(/* INLINE-ARGS */V58);
	(void)(structure_set(/* INLINE-ARGS */V57,VV[0],6,/* INLINE-ARGS */V59));
	V48= Ct;
	goto T130;
T144:;
	if((structure_ref(car((V45)),VV[0],1))==Cnil){
	goto T130;}
	V46= make_cons(car((V45)),(V46));
	V47= Ct;
	goto T130;
T132:;
	V46= make_cons(car((V45)),(V46));
T130:;
	V45= cdr((V45));
	goto T109;}}
}
/*	local entry for function C2TAGBODY	*/

static object LI6(V63,V64,V65)

object V63;object V64;object V65;
{	 VMB6 VMS6 VMV6
TTL:;
	if(((V64))==Cnil){
	goto T160;}
	{object V66 = (*(LnkLI56))((V65));
	VMR6(V66)}
T160:;
	if(((V63))==Cnil){
	goto T163;}
	{object V67 = (*(LnkLI57))((V65));
	VMR6(V67)}
T163:;
	{object V68 = (*(LnkLI58))((V65));
	VMR6(V68)}
}
/*	local entry for function C2TAGBODY-LOCAL	*/

static object LI7(V70)

object V70;
{	 VMB7 VMS7 VMV7
	bds_check;
TTL:;
	{register object V71;
	setq(VV[12],number_plus(symbol_value(VV[12]),small_fixnum(1)));
	V71= make_cons(symbol_value(VV[12]),Cnil);
	{register object V72;
	register object V73;
	V72= (V70);
	V73= car((V72));
T171:;
	if(!(endp((V72)))){
	goto T172;}
	goto T167;
T172:;
	base[2]= (V73);
	base[3]= VV[0];
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk47)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T176;}
	setq(VV[12],number_plus(symbol_value(VV[12]),small_fixnum(1)));
	V74= make_cons(symbol_value(VV[12]),Ct);
	(void)(structure_set((V73),VV[0],4,/* INLINE-ARGS */V74));
	(void)(structure_set((V73),VV[0],5,(V71)));
T176:;
	V72= cdr((V72));
	V73= car((V72));
	goto T171;}
T167:;
	base[1]= make_cons((V71),symbol_value(VV[13]));
	bds_bind(VV[13],base[1]);
	{object V75 = (*(LnkLI59))((V70));
	bds_unwind1;
	VMR7(V75)}}
}
/*	local entry for function C2TAGBODY-BODY	*/

static object LI8(V77)

object V77;
{	 VMB8 VMS8 VMV8
	bds_check;
TTL:;
	{register object V78;
	register object V79;
	V78= (V77);
	V79= Cnil;
T190:;
	if(!(endp(cdr((V78))))){
	goto T191;}
	if(((V79))==Cnil){
	goto T195;}
	{object V80 = (VFUN_NARGS=1,(*(LnkLI60))(Cnil));
	VMR8(V80)}
T195:;
	base[0]= car((V78));
	base[1]= VV[0];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk47)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T198;}
	V81= structure_ref(car((V78)),VV[0],7);
	(void)((*(LnkLI61))(/* INLINE-ARGS */V81));
	V82= structure_ref(car((V78)),VV[0],4);
	if((cdr(/* INLINE-ARGS */V82))==Cnil){
	goto T203;}
	princ_str("\nT",VV[14]);
	V83= structure_ref(car((V78)),VV[0],4);
	(void)((*(LnkLI62))(car(/* INLINE-ARGS */V83)));
	princ_str(":;",VV[14]);
T203:;
	{object V84 = (VFUN_NARGS=1,(*(LnkLI60))(Cnil));
	VMR8(V84)}
T198:;
	setq(VV[12],number_plus(symbol_value(VV[12]),small_fixnum(1)));
	bds_bind(VV[15],make_cons(symbol_value(VV[12]),Cnil));
	bds_bind(VV[13],make_cons((VV[15]->s.s_dbind),symbol_value(VV[13])));
	bds_bind(VV[16],VV[17]);
	base[3]= car((V78));
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk63)();
	vs_top=sup;
	if((cdr((VV[15]->s.s_dbind)))==Cnil){
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	goto T209;}
	princ_str("\nT",VV[14]);
	(void)((*(LnkLI62))(car((VV[15]->s.s_dbind))));
	princ_str(":;",VV[14]);
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
T209:;
	if((caar((V78)))==(VV[1])){
	goto T221;}
	{object V85 = (VFUN_NARGS=1,(*(LnkLI60))(Cnil));
	VMR8(V85)}
T221:;
	{object V86 = Cnil;
	VMR8(V86)}
T191:;
	if(((V79))==Cnil){
	goto T226;}
	V79= Cnil;
	goto T224;
T226:;
	base[0]= car((V78));
	base[1]= VV[0];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk47)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T230;}
	V87= structure_ref(car((V78)),VV[0],7);
	(void)((*(LnkLI61))(/* INLINE-ARGS */V87));
	V88= structure_ref(car((V78)),VV[0],4);
	if((cdr(/* INLINE-ARGS */V88))==Cnil){
	goto T224;}
	princ_str("\nT",VV[14]);
	V89= structure_ref(car((V78)),VV[0],4);
	(void)((*(LnkLI62))(car(/* INLINE-ARGS */V89)));
	princ_str(":;",VV[14]);
	goto T224;
T230:;
	base[3]= cadr((V78));
	base[4]= VV[0];
	vs_top=(vs_base=base+3)+2;
	(void) (*Lnk47)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T242;}
	V79= Ct;
	bds_bind(VV[15],structure_ref(cadr((V78)),VV[0],4));
	goto T240;
T242:;
	setq(VV[12],number_plus(symbol_value(VV[12]),small_fixnum(1)));
	bds_bind(VV[15],make_cons(symbol_value(VV[12]),Cnil));
T240:;
	bds_bind(VV[13],make_cons((VV[15]->s.s_dbind),symbol_value(VV[13])));
	bds_bind(VV[16],VV[17]);
	base[3]= car((V78));
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk63)();
	vs_top=sup;
	base[3]= cadr((V78));
	base[4]= VV[0];
	vs_top=(vs_base=base+3)+2;
	(void) (*Lnk47)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T253;}
	goto T252;
T253:;
	V90= structure_ref(cadr((V78)),VV[0],7);
	(void)((*(LnkLI61))(/* INLINE-ARGS */V90));
T252:;
	if((cdr((VV[15]->s.s_dbind)))==Cnil){
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	goto T224;}
	princ_str("\nT",VV[14]);
	(void)((*(LnkLI62))(car((VV[15]->s.s_dbind))));
	princ_str(":;",VV[14]);
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
T224:;
	V78= cdr((V78));
	goto T190;}
}
/*	local entry for function C2TAGBODY-CLB	*/

static object LI9(V92)

object V92;
{	 VMB9 VMS9 VMV9
	bds_check;
TTL:;
	{register object V93;
	setq(VV[12],number_plus(symbol_value(VV[12]),small_fixnum(1)));
	V93= make_cons(symbol_value(VV[12]),Cnil);
	bds_bind(VV[18],symbol_value(VV[18]));
	{register object V94;
	base[2]= make_cons(VV[19],symbol_value(VV[13]));
	V94= (*(LnkLI64))();
	bds_bind(VV[13],base[2]);
	princ_str("\n	",VV[14]);
	(void)((*(LnkLI65))((V94)));
	princ_str("=alloc_frame_id();",VV[14]);
	princ_str("\n	frs_push(FRS_CATCH,",VV[14]);
	(void)((*(LnkLI65))((V94)));
	princ_str(");",VV[14]);
	princ_str("\n	if(nlj_active){",VV[14]);
	princ_str("\n	nlj_active=FALSE;",VV[14]);
	{register object V95;
	register object V96;
	V95= (V92);
	V96= car((V95));
T286:;
	if(!(endp((V95)))){
	goto T287;}
	goto T282;
T287:;
	base[4]= (V96);
	base[5]= VV[0];
	vs_top=(vs_base=base+4)+2;
	(void) (*Lnk47)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T291;}
	setq(VV[12],number_plus(symbol_value(VV[12]),small_fixnum(1)));
	V97= make_cons(symbol_value(VV[12]),Ct);
	(void)(structure_set((V96),VV[0],4,/* INLINE-ARGS */V97));
	(void)(structure_set((V96),VV[0],5,(V93)));
	if((structure_ref((V96),VV[0],2))==Cnil){
	goto T291;}
	(void)(structure_set((V96),VV[0],2,(V94)));
	princ_str("\n	if(eql(nlj_tag,VV[",VV[14]);
	V98= structure_ref((V96),VV[0],6);
	(void)((*(LnkLI62))(/* INLINE-ARGS */V98));
	princ_str("]))",VV[14]);
	V99= structure_ref((V96),VV[0],4);
	if(type_of(/* INLINE-ARGS */V99)!=t_cons)FEwrong_type_argument(Scons,/* INLINE-ARGS */V99);
	(/* INLINE-ARGS */V99)->c.c_cdr = Ct;
	princ_str("goto T",VV[14]);
	V100= structure_ref((V96),VV[0],4);
	(void)((*(LnkLI62))(car(/* INLINE-ARGS */V100)));
	princ_char(59,VV[14]);
T291:;
	V95= cdr((V95));
	V96= car((V95));
	goto T286;}
T282:;
	princ_str("\n	FEerror(\"The GO tag ~s is not established.\",1,nlj_tag);",VV[14]);
	princ_str("\n	}",VV[14]);
	base[3]= make_cons((V93),(VV[13]->s.s_dbind));
	bds_bind(VV[13],base[3]);
	{object V101 = (*(LnkLI59))((V92));
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	VMR9(V101)}}}
}
/*	local entry for function C2TAGBODY-CCB	*/

static object LI10(V103)

object V103;
{	 VMB10 VMS10 VMV10
	bds_check;
TTL:;
	{register object V104;
	setq(VV[12],number_plus(symbol_value(VV[12]),small_fixnum(1)));
	V104= make_cons(symbol_value(VV[12]),Cnil);
	bds_bind(VV[18],symbol_value(VV[18]));
	bds_bind(VV[20],symbol_value(VV[20]));
	bds_bind(VV[21],symbol_value(VV[21]));
	{register object V105;
	register object V106;
	base[4]= make_cons(VV[19],symbol_value(VV[13]));
	V105= (*(LnkLI64))();
	bds_bind(VV[13],base[4]);
	V106= Cnil;
	princ_str("\n	",VV[14]);
	(void)((*(LnkLI65))((V105)));
	princ_str("=alloc_frame_id();",VV[14]);
	princ_str("\n	",VV[14]);
	(void)((*(LnkLI65))((V105)));
	princ_str("=MMcons(",VV[14]);
	(void)((*(LnkLI65))((V105)));
	princ_char(44,VV[14]);
	(void)((VFUN_NARGS=0,(*(LnkLI66))()));
	princ_str(");",VV[14]);
	(void)((*(LnkLI67))((V105)));
	V106= (*(LnkLI68))();
	princ_str("\n	frs_push(FRS_CATCH,",VV[14]);
	(void)((*(LnkLI69))((V105)));
	princ_str(");",VV[14]);
	princ_str("\n	if(nlj_active){",VV[14]);
	princ_str("\n	nlj_active=FALSE;",VV[14]);
	{register object V107;
	register object V108;
	V107= (V103);
	V108= car((V107));
T354:;
	if(!(endp((V107)))){
	goto T355;}
	goto T350;
T355:;
	base[6]= (V108);
	base[7]= VV[0];
	vs_top=(vs_base=base+6)+2;
	(void) (*Lnk47)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T359;}
	setq(VV[12],number_plus(symbol_value(VV[12]),small_fixnum(1)));
	V109= make_cons(symbol_value(VV[12]),Ct);
	(void)(structure_set((V108),VV[0],4,/* INLINE-ARGS */V109));
	(void)(structure_set((V108),VV[0],5,(V104)));
	if((structure_ref((V108),VV[0],2))!=Cnil){
	goto T367;}
	if((structure_ref((V108),VV[0],3))==Cnil){
	goto T359;}
T367:;
	(void)(structure_set((V108),VV[0],2,(V105)));
	if((structure_ref((V108),VV[0],3))==Cnil){
	goto T372;}
	(void)(structure_set((V108),VV[0],3,(V106)));
T372:;
	princ_str("\n	if(eql(nlj_tag,VV[",VV[14]);
	V110= structure_ref((V108),VV[0],6);
	(void)((*(LnkLI62))(/* INLINE-ARGS */V110));
	princ_str("]))",VV[14]);
	V111= structure_ref((V108),VV[0],4);
	if(type_of(/* INLINE-ARGS */V111)!=t_cons)FEwrong_type_argument(Scons,/* INLINE-ARGS */V111);
	(/* INLINE-ARGS */V111)->c.c_cdr = Ct;
	princ_str("goto T",VV[14]);
	V112= structure_ref((V108),VV[0],4);
	(void)((*(LnkLI62))(car(/* INLINE-ARGS */V112)));
	princ_char(59,VV[14]);
T359:;
	V107= cdr((V107));
	V108= car((V107));
	goto T354;}
T350:;
	princ_str("\n	FEerror(\"The GO tag ~s is not established.\",1,nlj_tag);",VV[14]);
	princ_str("\n	}",VV[14]);
	base[5]= make_cons((V104),(VV[13]->s.s_dbind));
	bds_bind(VV[13],base[5]);
	{object V113 = (*(LnkLI59))((V103));
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	VMR10(V113)}}}
}
/*	local entry for function C1GO	*/

static object LI11(V115)

object V115;
{	 VMB11 VMS11 VMV11
TTL:;
	if(!(endp((V115)))){
	goto T395;}
	(void)((*(LnkLI70))(VV[1],small_fixnum(1),small_fixnum(0)));
	goto T393;
T395:;
	if(endp(cdr((V115)))){
	goto T398;}
	V116 = make_fixnum(length((V115)));
	(void)((*(LnkLI71))(VV[1],small_fixnum(1),V116));
	goto T393;
T398:;
	if(type_of(car((V115)))==t_symbol){
	goto T393;}
	{object V117= car((V115));
	if(type_of(V117)==t_fixnum||type_of(V117)==t_bignum){
	goto T393;}}
	(void)(car((V115)));
T393:;
	{register object V118;
	register object V119;
	register object V120;
	register object V121;
	V118= symbol_value(VV[4]);
	V119= car((V115));
	V120= Cnil;
	V121= Cnil;
T408:;
	if(!(endp((V118)))){
	goto T409;}
	{object V122 = (VFUN_NARGS=2,(*(LnkLI72))(VV[23],(V119)));
	VMR11(V122)}
T409:;
	{object V123= car((V118));
	if((V123!= VV[73]))goto T414;
	V120= Ct;
	goto T413;
T414:;
	if((V123!= VV[74]))goto T416;
	V121= Ct;
	goto T413;
T416:;
	V124= structure_ref(car((V118)),VV[0],0);
	if(!((/* INLINE-ARGS */V124)==((V119)))){
	goto T413;}
	{register object V125;
	V125= car((V118));
	if(((V120))==Cnil){
	goto T423;}
	(void)(structure_set((V125),VV[0],3,Ct));
	goto T421;
T423:;
	if(((V121))==Cnil){
	goto T426;}
	(void)(structure_set((V125),VV[0],2,Ct));
	goto T421;
T426:;
	(void)(structure_set((V125),VV[0],1,Ct));
T421:;
	{object V126 = list(5,VV[1],symbol_value(VV[24]),(V121),(V120),(V125));
	VMR11(V126)}}}
T413:;
	V118= cdr((V118));
	goto T408;}
}
/*	local entry for function C2GO	*/

static object LI12(V130,V131,V132)

object V130;object V131;object V132;
{	 VMB12 VMS12 VMV12
TTL:;
	if(((V131))==Cnil){
	goto T432;}
	{object V133 = (*(LnkLI75))((V132));
	VMR12(V133)}
T432:;
	if(((V130))==Cnil){
	goto T435;}
	{object V134 = (*(LnkLI76))((V132));
	VMR12(V134)}
T435:;
	{object V135 = (*(LnkLI77))((V132));
	VMR12(V135)}
}
/*	local entry for function C2GO-LOCAL	*/

static object LI13(V137)

object V137;
{	 VMB13 VMS13 VMV13
TTL:;
	V138= structure_ref((V137),VV[0],5);
	(void)((*(LnkLI78))(/* INLINE-ARGS */V138));
	princ_str("\n	",VV[14]);
	V139= structure_ref((V137),VV[0],4);
	if(type_of(/* INLINE-ARGS */V139)!=t_cons)FEwrong_type_argument(Scons,/* INLINE-ARGS */V139);
	(/* INLINE-ARGS */V139)->c.c_cdr = Ct;
	princ_str("goto T",VV[14]);
	V140= structure_ref((V137),VV[0],4);
	(void)((*(LnkLI62))(car(/* INLINE-ARGS */V140)));
	princ_char(59,VV[14]);
	{object V141 = Cnil;
	VMR13(V141)}
}
/*	local entry for function C2GO-CLB	*/

static object LI14(V143)

register object V143;
{	 VMB14 VMS14 VMV14
TTL:;
	princ_str("\n	vs_base=vs_top;",VV[14]);
	princ_str("\n	unwind(frs_sch(",VV[14]);
	if((structure_ref((V143),VV[0],3))==Cnil){
	goto T449;}
	V144= structure_ref((V143),VV[0],2);
	(void)((*(LnkLI69))(/* INLINE-ARGS */V144));
	goto T447;
T449:;
	V145= structure_ref((V143),VV[0],2);
	(void)((*(LnkLI65))(/* INLINE-ARGS */V145));
T447:;
	princ_str("),VV[",VV[14]);
	V146= structure_ref((V143),VV[0],6);
	(void)((*(LnkLI62))(/* INLINE-ARGS */V146));
	princ_str("]);",VV[14]);
	{object V147 = Cnil;
	VMR14(V147)}
}
/*	local entry for function C2GO-CCB	*/

static object LI15(V149)

object V149;
{	 VMB15 VMS15 VMV15
TTL:;
	princ_str("\n	{frame_ptr fr;",VV[14]);
	princ_str("\n	fr=frs_sch(",VV[14]);
	V150= structure_ref((V149),VV[0],3);
	(void)((*(LnkLI79))(/* INLINE-ARGS */V150));
	princ_str(");",VV[14]);
	princ_str("\n	if(fr==NULL)FEerror(\"The GO tag ~s is missing.\",1,VV[",VV[14]);
	V151= structure_ref((V149),VV[0],6);
	(void)((*(LnkLI62))(/* INLINE-ARGS */V151));
	princ_str("]);",VV[14]);
	princ_str("\n	vs_base=vs_top;",VV[14]);
	princ_str("\n	unwind(fr,VV[",VV[14]);
	V152= structure_ref((V149),VV[0],6);
	(void)((*(LnkLI62))(/* INLINE-ARGS */V152));
	princ_str("]);}",VV[14]);
	{object V153 = Cnil;
	VMR15(V153)}
}
/*	local entry for function WT-SWITCH-CASE	*/

static object LI16(V155)

register object V155;
{	 VMB16 VMS16 VMV16
TTL:;
	if(((V155))==Cnil){
	goto T471;}
	princ_str("\n	",VV[14]);
	if(!(type_of((V155))==t_fixnum)){
	goto T477;}
	V156= VV[25];
	goto T475;
T477:;
	V156= VV[26];
T475:;
	(void)((*(LnkLI62))(V156));
	(void)((*(LnkLI62))((V155)));
	princ_char(58,VV[14]);
	{object V157 = Cnil;
	VMR16(V157)}
T471:;
	{object V158 = Cnil;
	VMR16(V158)}
}
/*	local entry for function C1SWITCH	*/

static object LI17(V160)

object V160;
{	 VMB17 VMS17 VMV17
	bds_check;
TTL:;
	bds_bind(VV[4],symbol_value(VV[4]));
	{object V161;
	register object V162;
	object V163;
	V161= car((V160));
	V162= cdr((V160));
	V163= (*(LnkLI80))((V161));
	base[4]= cadr((V163));
	base[5]= VV[27];
	vs_top=(vs_base=base+4)+2;
	(void) (*Lnk47)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T485;}
	base[4]= structure_ref(cadr((V163)),VV[27],2);
	base[5]= VV[28];
	vs_top=(vs_base=base+4)+2;
	(void) (*Lnk81)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T485;}{object V164;
	{register object x= Ct,V165= (V162);
	while(!endp(V165))
	if(eql(x,V165->c.c_car)){
	V164= V165;
	goto T495;
	}else V165=V165->c.c_cdr;
	V164= Cnil;}
T495:;
	if(V164==Cnil)goto T494;
	goto T493;
T494:;}
	V166= make_cons(Ct,Cnil);
	V162= append((V162),/* INLINE-ARGS */V166);
T493:;
	{object V167;
	object V168= (V162);
	if(endp(V168)){
	V162= Cnil;
	goto T498;}
	base[4]=V167=MMcons(Cnil,Cnil);
T499:;
	{register object V169;
	V169= (V168->c.c_car);
	if(type_of((V169))==t_symbol){
	goto T501;}
	if(!(type_of((V169))==t_fixnum||type_of((V169))==t_bignum)){
	goto T502;}
T501:;
	{register object V170;
	V170= (VFUN_NARGS=8,(*(LnkLI51))(VV[5],(V169),VV[6],Cnil,VV[7],Cnil,VV[8],Cnil));
	if(!(type_of((V169))==t_fixnum)){
	goto T509;}
	(void)(structure_set((V170),VV[0],1,Ct));
	(void)(structure_set((V170),VV[0],7,(V169)));
	goto T507;
T509:;
	if(!((Ct)==((V169)))){
	goto T507;}
	(void)(structure_set((V170),VV[0],1,Ct));
	(void)(structure_set((V170),VV[0],7,VV[29]));
T507:;
	(V167->c.c_car)= (V170);
	goto T500;}
T502:;
	(V167->c.c_car)= (V169);}
T500:;
	if(endp(V168=MMcdr(V168))){
	V162= base[4];
	goto T498;}
	V167=MMcdr(V167)=MMcons(Cnil,Cnil);
	goto T499;}
T498:;
	{object V171;
	V172= append((V162),VV[30]);
	V171= (*(LnkLI82))(/* INLINE-ARGS */V172);
	V173= list(3,VV[31],cadr((V171)),(V163));
	{object V174 = nconc(/* INLINE-ARGS */V173,cddr((V171)));
	bds_unwind1;
	VMR17(V174)}}
T485:;
	V175= make_cons(VV[31],(V160));
	V176= (*(LnkLI83))(/* INLINE-ARGS */V175);
	{object V177 = (*(LnkLI80))(/* INLINE-ARGS */V176);
	bds_unwind1;
	VMR17(V177)}}
}
/*	local entry for function C2SWITCH	*/

static object LI18(V182,V183,V184,V185)

object V182;object V183;object V184;object V185;
{	 VMB18 VMS18 VMV18
	bds_check;
TTL:;
	bds_bind(VV[32],small_fixnum(0));
	bds_bind(VV[18],symbol_value(VV[18]));
	{object V186;
	V187= make_cons((V182),Cnil);
	V186= (VFUN_NARGS=2,(*(LnkLI84))(/* INLINE-ARGS */V187,VV[33]));
	base[2]= VV[34];
	base[3]= (V186);
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk85)();
	vs_top=sup;
	if(((V184))==Cnil){
	goto T522;}
	(void)((*(LnkLI56))((V185)));
	goto T520;
T522:;
	if(((V183))==Cnil){
	goto T525;}
	(void)((*(LnkLI57))((V185)));
	goto T520;
T525:;
	(void)((*(LnkLI58))((V185)));
T520:;
	princ_char(125,VV[14]);
	(void)((VFUN_NARGS=1,(*(LnkLI60))(Cnil)));
	{object V188 = (*(LnkLI86))();
	bds_unwind1;
	bds_unwind1;
	VMR18(V188)}}
}
/*	macro definition for SWITCH	*/

static L19()
{register object *base=vs_base;
	register object *sup=base+VM19; VC19
	vs_reserve(VM19);
	check_arg(2);
	vs_top=sup;
	{object V189=base[0]->c.c_cdr;
	if(endp(V189))invalid_macro_call();
	base[2]= (V189->c.c_car);
	V189=V189->c.c_cdr;
	base[3]= V189;
	base[4]= Cnil;}
	{register object V190;
	register object V191;
	V190= base[3];
	V191= car((V190));
T535:;
	if(!(endp((V190)))){
	goto T536;}
	goto T531;
T536:;
	if(!(type_of((V191))==t_fixnum||type_of((V191))==t_bignum)){
	goto T540;}
	V192= list(3,VV[36],(V191),base[2]);
	V193= list(4,VV[35],/* INLINE-ARGS */V192,list(2,VV[1],(V191)),Cnil);
	base[4]= make_cons(/* INLINE-ARGS */V193,base[4]);
T540:;
	V190= cdr((V190));
	V191= car((V190));
	goto T535;}
T531:;
	V194= nreverse(base[4]);
	base[5]= base[3];
	{register object x= Ct,V196= base[3];
	while(!endp(V196))
	if(eql(x,V196->c.c_car)){
	goto T554;
	}else V196=V196->c.c_cdr;
	goto T553;}
T554:;
	base[6]= Cnil;
	goto T551;
T553:;
	base[6]= VV[38];
T551:;
	base[7]= VV[39];
	vs_top=(vs_base=base+5)+3;
	(void) (*Lnk87)();
	vs_top=sup;
	V195= vs_base[0];
	V197= make_cons(VV[37],V195);
	V198= append(/* INLINE-ARGS */V194,/* INLINE-ARGS */V197);
	base[5]= make_cons(VV[10],/* INLINE-ARGS */V198);
	vs_top=(vs_base=base+5)+1;
	return;
}
/*	macro definition for SWITCH-FINISH	*/

static L20()
{register object *base=vs_base;
	register object *sup=base+VM20; VC20
	vs_reserve(VM20);
	check_arg(2);
	vs_top=sup;
	{object V199=base[0]->c.c_cdr;
	if(!endp(V199))invalid_macro_call();}
	base[2]= VV[40];
	vs_top=(vs_base=base+2)+1;
	return;
}
static LnkT87(){ call_or_link(VV[87],&Lnk87);} /* APPEND */
static object  LnkTLI86(){return call_proc0(VV[86],&LnkLI86);} /* CLOSE-INLINE-BLOCKS */
static LnkT85(){ call_or_link(VV[85],&Lnk85);} /* WT-INLINE-LOC */
static object  LnkTLI84(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[84],&LnkLI84,ap);} /* INLINE-ARGS */
static object  LnkTLI83(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[83],&LnkLI83,1,ap);} /* CMP-MACROEXPAND-1 */
static object  LnkTLI82(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[82],&LnkLI82,1,ap);} /* C1TAGBODY */
static LnkT81(){ call_or_link(VV[81],&Lnk81);} /* SUBTYPEP */
static object  LnkTLI80(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[80],&LnkLI80,1,ap);} /* C1EXPR */
static object  LnkTLI79(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[79],&LnkLI79,1,ap);} /* WT-CCB-VS */
static object  LnkTLI78(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[78],&LnkLI78,1,ap);} /* UNWIND-NO-EXIT */
static object  LnkTLI77(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[77],&LnkLI77,1,ap);} /* C2GO-LOCAL */
static object  LnkTLI76(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[76],&LnkLI76,1,ap);} /* C2GO-CLB */
static object  LnkTLI75(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[75],&LnkLI75,1,ap);} /* C2GO-CCB */
static object  LnkTLI72(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[72],&LnkLI72,ap);} /* CMPERR */
static object  LnkTLI71(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[71],&LnkLI71,3,ap);} /* TOO-MANY-ARGS */
static object  LnkTLI70(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[70],&LnkLI70,3,ap);} /* TOO-FEW-ARGS */
static object  LnkTLI69(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[69],&LnkLI69,1,ap);} /* WT-VS* */
static object  LnkTLI68(){return call_proc0(VV[68],&LnkLI68);} /* CCB-VS-PUSH */
static object  LnkTLI67(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[67],&LnkLI67,1,ap);} /* CLINK */
static object  LnkTLI66(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[66],&LnkLI66,ap);} /* WT-CLINK */
static object  LnkTLI65(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[65],&LnkLI65,1,ap);} /* WT-VS */
static object  LnkTLI64(){return call_proc0(VV[64],&LnkLI64);} /* VS-PUSH */
static LnkT63(){ call_or_link(VV[63],&Lnk63);} /* C2EXPR */
static object  LnkTLI62(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[62],&LnkLI62,1,ap);} /* WT1 */
static object  LnkTLI61(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[61],&LnkLI61,1,ap);} /* WT-SWITCH-CASE */
static object  LnkTLI60(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[60],&LnkLI60,ap);} /* UNWIND-EXIT */
static object  LnkTLI59(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[59],&LnkLI59,1,ap);} /* C2TAGBODY-BODY */
static object  LnkTLI58(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[58],&LnkLI58,1,ap);} /* C2TAGBODY-LOCAL */
static object  LnkTLI57(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[57],&LnkLI57,1,ap);} /* C2TAGBODY-CLB */
static object  LnkTLI56(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[56],&LnkLI56,1,ap);} /* C2TAGBODY-CCB */
static object  LnkTLI55(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[55],&LnkLI55,1,ap);} /* ADD-OBJECT */
static object  LnkTLI54(){return call_proc0(VV[54],&LnkLI54);} /* C1NIL */
static object  LnkTLI53(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[53],&LnkLI53,1,ap);} /* ADD-LOOP-REGISTERS */
static object  LnkTLI52(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[52],&LnkLI52,2,ap);} /* C1EXPR* */
static object  LnkTLI51(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[51],&LnkLI51,ap);} /* MAKE-TAG */
static object  LnkTLI50(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[50],&LnkLI50,ap);} /* MAKE-INFO */
static object  LnkTLI49(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[49],&LnkLI49,1,ap);} /* ADD-REG1 */
static object  LnkTLI48(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[48],&LnkLI48,2,ap);} /* JUMPS-TO-P */
static LnkT47(){ call_or_link(VV[47],&Lnk47);} /* STRUCTURE-SUBTYPE-P */
static LnkT46(){ call_or_link(VV[46],&Lnk46);} /* EQ */
static LnkT45(){ call_or_link(VV[45],&Lnk45);} /* MAKE-STRUCTURE */
