#define ARG_LIMIT 63

#define ARG_LIMIT 63
#ifndef DONT_DEFINE_DEFUN
#define DEFUN(string,ret,fname,pack,min,max, flags, ret0a0,a12,a34,a56,doc) ret fname
/* eg.
   A function taking from 2 to 8 args
   returning obj the first args is obj, the next 6 int, and last defaults to obj.
   note the return type must also be put in the signature.
  DEFUN("AREF",obj,fSaref,SI,2,8,NONE,oo,ii,ii,ii,
  "takes ARRAY and returns NTH element")
*/
  /* for keeping an old style one around too:
       DEFUN("AREF",obj,fSaref,SI,2,8,NONE,oo,ii,ii,ii,Laref,"")
*/
/* for defining old style */
#define DEFUNO(string,ret,fname,pack,min,max, flags, ret0a0,a12,a34,a56,old) \
  ret fname (); \
old() \
{   Iinvoke_c_function_from_value_stack(fname,F_ARGD(min,max,flags,ARGTYPES(ret0a0,a12,a34,a56))); \
    return;} \
  ret fname

  /* these will come later */
#define DO_INIT(x)   
#define DEFUNL DEFUN
  /* these are needed to be linked in to be called by incrementally
   loaded code */
#define DEFCOMP(type,fun,doc) type fun

#endif


