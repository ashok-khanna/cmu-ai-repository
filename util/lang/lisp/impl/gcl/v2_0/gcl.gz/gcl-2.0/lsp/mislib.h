
static L1();
static L4();
static object LI5();
#define VC1
static object LI2();
#define VMB2 register object *base=vs_top;
#define VMS2  register object *sup=vs_top+4;vs_top=sup;
#define VMV2 vs_reserve(4);
#define VMR2(VMT2) vs_top=base ; return(VMT2);
static object LI3();
#define VMB3 register object *base=vs_top; object  V12 ,V11;
#define VMS3  register object *sup=vs_top+6;vs_top=sup;
#define VMV3 vs_reserve(6);
#define VMR3(VMT3) vs_top=base ; return(VMT3);
#define VC4 object  V29 ,V27 ,V26 ,V24 ,V23;
static object LI5();
#define VMB5 register object *base=vs_top; object  V56 ,V55 ,V54 ,V53 ,V52; object Vcs[7];
#define VMS5  register object *sup=vs_top+6;vs_top=sup;
#define VMV5 vs_reserve(6);
#define VMR5(VMT5) vs_top=base ; return(VMT5);
#define VM5 6
#define VM4 11
#define VM3 6
#define VM2 4
#define VM1 4
static char * VVi[24]={
#define Cdata VV[23]
(char *)(L1),
(char *)(LI2),
(char *)(LI3),
(char *)(L4),
(char *)(LI5)
};
#define VV ((object *)VVi)
static  LnkT22() ;
static  (*Lnk22)() = LnkT22;
static  LnkT21() ;
static  (*Lnk21)() = LnkT21;
static  LnkT20() ;
static  (*Lnk20)() = LnkT20;
static object  LnkTLI19() ;
static object  (*LnkLI19)() = LnkTLI19;
static object  LnkTLI18() ;
static object  (*LnkLI18)() = LnkTLI18;
static  LnkT17() ;
static  (*Lnk17)() = LnkT17;
static  LnkT16() ;
static  (*Lnk16)() = LnkT16;
static  LnkT15() ;
static  (*Lnk15)() = LnkT15;
static  LnkT14() ;
static  (*Lnk14)() = LnkT14;
static  LnkT13() ;
static  (*Lnk13)() = LnkT13;
