
bzero(b, length)
    char *b;
    int length;
{while(length-->0)
   *b++ = 0;
}
