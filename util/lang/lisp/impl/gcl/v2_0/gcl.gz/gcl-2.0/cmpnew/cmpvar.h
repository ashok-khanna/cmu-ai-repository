
static object LI1();
static L23();
static object LI1();
static int VK1defaults[7]={-2,-2,-2,-2,-2,-1,62};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[7];} LI1key={7,0,VK1defaults,{63,17,16,64,65,14,1}};
#define VMB1 register object *base=vs_top; object Vcs[14];
#define VMS1  register object *sup=vs_top+8;vs_top=sup;
#define VMV1 vs_reserve(8);
#define VMR1(VMT1) vs_top=base ; return(VMT1);
static object LI2();
#define VMB2 register object *base=vs_top; object  V26 ,V25 ,V20;
#define VMS2  register object *sup=vs_top+2;vs_top=sup;
#define VMV2 vs_reserve(2);
#define VMR2(VMT2) vs_top=base ; return(VMT2);
static object LI3();
#define VMB3 object  V33 ,V32;
#define VMS3
#define VMV3
#define VMR3(VMT3) return(VMT3);
static object LI4();
#define VMB4 register object *base=vs_top; object  V44 ,V43 ,V42;
#define VMS4 vs_top += 1;
#define VMV4 vs_reserve(1);
#define VMR4(VMT4) vs_top=base ; return(VMT4);
static object LI5();
#define VMB5 register object *base=vs_top; object  V61 ,V59 ,V58 ,V57 ,V54 ,V53;
#define VMS5  register object *sup=vs_top+2;vs_top=sup;
#define VMV5 vs_reserve(2);
#define VMR5(VMT5) vs_top=base ; return(VMT5);
static object LI6();
#define VMB6 register object *base=vs_top; object  V67 ,V66 ,V65;
#define VMS6  register object *sup=vs_top+1;vs_top=sup;
#define VMV6 vs_reserve(1);
#define VMR6(VMT6) vs_top=base ; return(VMT6);
static object LI7();
#define VMB7 object  V81;
#define VMS7
#define VMV7
#define VMR7(VMT7) return(VMT7);
static object LI8();
#define VMB8
#define VMS8
#define VMV8
#define VMR8(VMT8) return(VMT8);
static object LI9();
#define VMB9 register object *base=vs_top; object  V98;
#define VMS9 vs_top += 2;
#define VMV9 vs_reserve(2);
#define VMR9(VMT9) vs_top=base ; return(VMT9);
static object LI10();
#define VMB10 register object *base=vs_top; object  V113 ,V112 ,V111 ,V110 ,V109;
#define VMS10 vs_top += 1;
#define VMV10 vs_reserve(1);
#define VMR10(VMT10) vs_top=base ; return(VMT10);
static object LI11();
#define VMB11 register object *base=vs_top;
#define VMS11  register object *sup=vs_top+1;vs_top=sup;
#define VMV11 vs_reserve(1);
#define VMR11(VMT11) vs_top=base ; return(VMT11);
static object LI12();
#define VMB12 object  V146 ,V145 ,V142 ,V140 ,V138 ,V136 ,V134 ,V132 ,V131 ,V130 ,V129 ,V127 ,V125 ,V124;
#define VMS12
#define VMV12
#define VMR12(VMT12) return(VMT12);
static object LI13();
#define VMB13 register object *base=vs_top; object  V180 ,V178 ,V175 ,V174 ,V173 ,V172 ,V166 ,V164 ,V162 ,V160 ,V158 ,V157 ,V156 ,V155;
#define VMS13  register object *sup=vs_top+4;vs_top=sup;
#define VMV13 vs_reserve(4);
#define VMR13(VMT13) vs_top=base ; return(VMT13);
static object LI14();
#define VMB14 register object *base=vs_top; object  V188;
#define VMS14 vs_top += 1;
#define VMV14 vs_reserve(1);
#define VMR14(VMT14) vs_top=base ; return(VMT14);
static object LI15();
#define VMB15 register object *base=vs_top; object  V198 ,V196 ,V195;
#define VMS15 vs_top += 1;
#define VMV15 vs_reserve(1);
#define VMR15(VMT15) vs_top=base ; return(VMT15);
static object LI16();
#define VMB16 object  V209 ,V207 ,V206;
#define VMS16
#define VMV16
#define VMR16(VMT16) return(VMT16);
static object LI17();
#define VMB17 register object *base=vs_top; object  V224 ,V223 ,V222 ,V221 ,V220;
#define VMS17  register object *sup=vs_top+2;vs_top=sup;
#define VMV17 vs_reserve(2);
#define VMR17(VMT17) vs_top=base ; return(VMT17);
static object LI18();
#define VMB18 register object *base=vs_top; object  V234 ,V231;
#define VMS18 vs_top += 1;
#define VMV18 vs_reserve(1);
#define VMR18(VMT18) vs_top=base ; return(VMT18);
static object LI19();
#define VMB19 register object *base=vs_top; object  V241;
#define VMS19 vs_top += 1;
#define VMV19 vs_reserve(1);
#define VMR19(VMT19) vs_top=base ; return(VMT19);
static object LI20();
#define VMB20 register object *base=vs_top;
#define VMS20  register object *sup=vs_top+4;vs_top=sup;
#define VMV20 vs_reserve(4);
#define VMR20(VMT20) vs_top=base ; return(VMT20);
static object LI21();
#define VMB21 register object *base=vs_top; object  V268 ,V267 ,V266 ,V262 ,V261 ,V260;
#define VMS21  register object *sup=vs_top+5;vs_top=sup;
#define VMV21 vs_reserve(5);
#define VMR21(VMT21) vs_top=base ; return(VMT21);
static object LI22();
#define VMB22 register object *base=vs_top; object  V290 ,V289 ,V288 ,V287 ,V286 ,V285 ,V281 ,V279;
#define VMS22 vs_top += 6;
#define VMV22 vs_reserve(6);
#define VMR22(VMT22) vs_top=base ; return(VMT22);
#define VC23 object  V303 ,V302 ,V301 ,V300 ,V299;
#define VM23 3
#define VM22 6
#define VM21 5
#define VM20 4
#define VM19 1
#define VM18 1
#define VM17 2
#define VM16 0
#define VM15 1
#define VM14 1
#define VM13 4
#define VM12 0
#define VM11 1
#define VM10 1
#define VM9 2
#define VM8 0
#define VM7 0
#define VM6 1
#define VM5 2
#define VM4 1
#define VM3 0
#define VM2 2
#define VM1 8
static char * VVi[123]={
#define Cdata VV[122]
(char *)(LI1),
(char *)(&LI1key),
(char *)(LI2),
(char *)(LI3),
(char *)(LI4),
(char *)(LI5),
(char *)(LI6),
(char *)(LI7),
(char *)(LI8),
(char *)(LI9),
(char *)(LI10),
(char *)(LI11),
(char *)(LI12),
(char *)(LI13),
(char *)(LI14),
(char *)(LI15),
(char *)(LI16),
(char *)(LI17),
(char *)(LI18),
(char *)(LI19),
(char *)(LI20),
(char *)(LI21),
(char *)(LI22),
(char *)(L23)
};
#define VV ((object *)VVi)
static object  LnkTLI72() ;
static object  (*LnkLI72)() = LnkTLI72;
static  LnkT121() ;
static  (*Lnk121)() = LnkT121;
static object  LnkTLI42() ;
static object  (*LnkLI42)() = LnkTLI42;
static object  LnkTLI120() ;
static object  (*LnkLI120)() = LnkTLI120;
static object  LnkTLI119() ;
static object  (*LnkLI119)() = LnkTLI119;
static object  LnkTLI118() ;
static object  (*LnkLI118)() = LnkTLI118;
static  LnkT117() ;
static  (*Lnk117)() = LnkT117;
static object  LnkTLI116() ;
static object  (*LnkLI116)() = LnkTLI116;
static object  LnkTLI115() ;
static object  (*LnkLI115)() = LnkTLI115;
static object  LnkTLI114() ;
static object  (*LnkLI114)() = LnkTLI114;
static object  LnkTLI113() ;
static object  (*LnkLI113)() = LnkTLI113;
static object  LnkTLI111() ;
static object  (*LnkLI111)() = LnkTLI111;
static  LnkT110() ;
static  (*Lnk110)() = LnkT110;
static object  LnkTLI109() ;
static object  (*LnkLI109)() = LnkTLI109;
static object  LnkTLI108() ;
static object  (*LnkLI108)() = LnkTLI108;
static object  LnkTLI107() ;
static object  (*LnkLI107)() = LnkTLI107;
static object  LnkTLI106() ;
static object  (*LnkLI106)() = LnkTLI106;
static object  LnkTLI105() ;
static object  (*LnkLI105)() = LnkTLI105;
static object  LnkTLI104() ;
static object  (*LnkLI104)() = LnkTLI104;
static  LnkT103() ;
static  (*Lnk103)() = LnkT103;
static  LnkT102() ;
static  (*Lnk102)() = LnkT102;
static  LnkT101() ;
static  (*Lnk101)() = LnkT101;
static  LnkT100() ;
static  (*Lnk100)() = LnkT100;
static  LnkT99() ;
static  (*Lnk99)() = LnkT99;
static object  LnkTLI98() ;
static object  (*LnkLI98)() = LnkTLI98;
static  LnkT97() ;
static  (*Lnk97)() = LnkT97;
static  LnkT96() ;
static  (*Lnk96)() = LnkT96;
static  LnkT94() ;
static  (*Lnk94)() = LnkT94;
static  LnkT92() ;
static  (*Lnk92)() = LnkT92;
static object  LnkTLI91() ;
static object  (*LnkLI91)() = LnkTLI91;
static object  LnkTLI90() ;
static object  (*LnkLI90)() = LnkTLI90;
static object  LnkTLI88() ;
static object  (*LnkLI88)() = LnkTLI88;
static object  LnkTLI87() ;
static object  (*LnkLI87)() = LnkTLI87;
static object  LnkTLI86() ;
static object  (*LnkLI86)() = LnkTLI86;
static object  LnkTLI85() ;
static object  (*LnkLI85)() = LnkTLI85;
static  LnkT84() ;
static  (*Lnk84)() = LnkT84;
static object  LnkTLI83() ;
static object  (*LnkLI83)() = LnkTLI83;
static object  LnkTLI82() ;
static object  (*LnkLI82)() = LnkTLI82;
static object  LnkTLI81() ;
static object  (*LnkLI81)() = LnkTLI81;
static object  LnkTLI80() ;
static object  (*LnkLI80)() = LnkTLI80;
static object  LnkTLI79() ;
static object  (*LnkLI79)() = LnkTLI79;
static object  LnkTLI78() ;
static object  (*LnkLI78)() = LnkTLI78;
static object  LnkTLI77() ;
static object  (*LnkLI77)() = LnkTLI77;
static object  LnkTLI76() ;
static object  (*LnkLI76)() = LnkTLI76;
static  LnkT75() ;
static  (*Lnk75)() = LnkT75;
static  LnkT74() ;
static  (*Lnk74)() = LnkT74;
static  LnkT73() ;
static  (*Lnk73)() = LnkT73;
static object  LnkTLI71() ;
static object  (*LnkLI71)() = LnkTLI71;
static  LnkT70() ;
static  (*Lnk70)() = LnkT70;
static  LnkT69() ;
static  (*Lnk69)() = LnkT69;
static object  LnkTLI68() ;
static object  (*LnkLI68)() = LnkTLI68;
static object  LnkTLI67() ;
static object  (*LnkLI67)() = LnkTLI67;
static  LnkT66() ;
static  (*Lnk66)() = LnkT66;
