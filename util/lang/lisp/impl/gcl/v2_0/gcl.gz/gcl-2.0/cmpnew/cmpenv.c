
#include <cmpinclude.h>
#include "cmpenv.h"
init_cmpenv(){do_init(VV);}
/*	local entry for function INIT-ENV	*/

static object LI1()

{	 VMB1 VMS1 VMV1
TTL:;
	setq(VV[0],small_fixnum(0));
	setq(VV[1],small_fixnum(0));
	setq(VV[2],small_fixnum(-1));
	setq(VV[3],small_fixnum(0));
	setq(VV[4],small_fixnum(0));
	setq(VV[5],Cnil);
	setq(VV[6],Cnil);
	setq(VV[7],Cnil);
	setq(VV[8],Cnil);
	setq(VV[9],Cnil);
	setq(VV[10],Cnil);
	setq(VV[11],Cnil);
	setq(VV[12],Cnil);
	setq(VV[13],Cnil);
	setq(VV[14],Cnil);
	setq(VV[15],Cnil);
	setq(VV[16],Cnil);
	setq(VV[17],small_fixnum(0));
	setq(VV[18],Cnil);
	{object V1 = Cnil;
	VMR1(V1)}
}
/*	macro definition for NEXT-CFUN	*/

static L2()
{register object *base=vs_base;
	register object *sup=base+VM2; VC2
	vs_reserve(VM2);
	check_arg(2);
	vs_top=sup;
	{object V2=base[0]->c.c_cdr;
	if(!endp(V2))invalid_macro_call();}
	base[2]= VV[19];
	vs_top=(vs_base=base+2)+1;
	return;
}
/*	local entry for function ADD-SYMBOL	*/

static object LI3(V4)

object V4;
{	 VMB3 VMS3 VMV3
TTL:;
	{object V5;
	{register object x= (V4),V6= symbol_value(VV[5]);
	while(!endp(V6))
	if(type_of(V6->c.c_car)==t_cons &&eql(x,V6->c.c_car->c.c_car)){
	V5= (V6->c.c_car);
	goto T38;
	}else V6=V6->c.c_cdr;
	V5= Cnil;}
T38:;
	if(((V5))==Cnil){
	goto T40;}
	{object V7 = cadr((V5));
	VMR3(V7)}
T40:;
	(void)((*(LnkLI113))((V4)));
	V8= list(2,(V4),symbol_value(VV[2]));
	setq(VV[5],make_cons(/* INLINE-ARGS */V8,symbol_value(VV[5])));
	{object V9 = symbol_value(VV[2]);
	VMR3(V9)}}
}
/*	function definition for WT-TO-STRING	*/

static L4()
{register object *base=vs_base;
	register object *sup=base+VM4; VC4
	vs_reserve(VM4);
	bds_check;
	{object V10;
	check_arg(1);
	V10=(base[0]);
	vs_top=sup;
TTL:;
	vs_base=vs_top;
	(void) (*Lnk114)();
	vs_top=sup;
	bds_bind(VV[20],vs_base[0]);
	bds_bind(VV[21],Cnil);
	(void)((*(LnkLI115))((V10)));
	base[3]= (VV[20]->s.s_dbind);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk116)();
	bds_unwind1;
	bds_unwind1;
	return;
	}
}
/*	local entry for function ADD-OBJECT	*/

static object LI5(V12)

register object V12;
{	 VMB5 VMS5 VMV5
TTL:;
	{object V13;
	V13= Cnil;
	base[0]= (V12);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk117)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T50;}
	if(!(type_of((V12))==t_cons)){
	goto T55;}
	if(!((car((V12)))==(VV[22]))){
	goto T55;}
	base[0]= cdr((V12));
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk117)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T55;}
	V12= cdr((V12));
	goto T53;
T55:;
	base[0]= (V12);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk118)();
	vs_top=sup;
	V14= vs_base[0];
	V12= list(2,VV[23],V14);
T53:;
	(void)((*(LnkLI113))(Cnil));
	V15= list(2,symbol_value(VV[2]),(V12));
	setq(VV[24],make_cons(/* INLINE-ARGS */V15,symbol_value(VV[24])));
	{object V16 = symbol_value(VV[2]);
	VMR5(V16)}
T50:;
	{register object x= (V12),V17= symbol_value(VV[5]);
	while(!endp(V17))
	if(type_of(V17->c.c_car)==t_cons &&eql(x,V17->c.c_car->c.c_car)){
	V13= (V17->c.c_car);
	goto T72;
	}else V17=V17->c.c_cdr;
	V13= Cnil;}
T72:;
	if(((V13))==Cnil){
	goto T70;}
	{object V18 = cadr((V13));
	VMR5(V18)}
T70:;
	base[0]= (V12);
	base[1]= VV[25];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk119)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T74;}
	(void)((*(LnkLI113))(Cnil));{object V19;
	V19= symbol_value(VV[2]);{object V21;
	base[0]= (V12);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk120)();
	vs_top=sup;
	V21= vs_base[0];
	if(V21==Cnil)goto T82;
	V20= V21;
	goto T81;
T82:;}
	V20= (VFUN_NARGS=1,(*(LnkLI121))(VV[27]));
T81:;
	V22= list(2,V19,list(2,VV[26],V20));
	setq(VV[24],make_cons(/* INLINE-ARGS */V22,symbol_value(VV[24])));}
	{object V23 = symbol_value(VV[2]);
	VMR5(V23)}
T74:;
	(void)((*(LnkLI113))((V12)));
	V24= list(2,(V12),symbol_value(VV[2]));
	setq(VV[5],make_cons(/* INLINE-ARGS */V24,symbol_value(VV[5])));
	{object V25 = symbol_value(VV[2]);
	VMR5(V25)}}
}
/*	local entry for function ADD-CONSTANT	*/

static object LI6(V27)

object V27;
{	 VMB6 VMS6 VMV6
TTL:;
	{object V28;
	V28= Cnil;
	{register object x= (V27),V29= symbol_value(VV[6]);
	while(!endp(V29))
	if(type_of(V29->c.c_car)==t_cons &&eql(x,V29->c.c_car->c.c_car)){
	V28= (V29->c.c_car);
	goto T92;
	}else V29=V29->c.c_cdr;
	V28= Cnil;}
T92:;
	if(((V28))==Cnil){
	goto T90;}
	{object V30 = cadr((V28));
	VMR6(V30)}
T90:;
	(void)((*(LnkLI113))(Cnil));
	V31= list(2,symbol_value(VV[2]),(V27));
	setq(VV[24],make_cons(/* INLINE-ARGS */V31,symbol_value(VV[24])));
	V32= list(2,(V27),symbol_value(VV[2]));
	setq(VV[6],make_cons(/* INLINE-ARGS */V32,symbol_value(VV[6])));
	{object V33 = symbol_value(VV[2]);
	VMR6(V33)}}
}
/*	macro definition for NEXT-CVAR	*/

static L7()
{register object *base=vs_base;
	register object *sup=base+VM7; VC7
	vs_reserve(VM7);
	check_arg(2);
	vs_top=sup;
	{object V34=base[0]->c.c_cdr;
	if(!endp(V34))invalid_macro_call();}
	base[2]= VV[28];
	vs_top=(vs_base=base+2)+1;
	return;
}
/*	macro definition for NEXT-CMACRO	*/

static L8()
{register object *base=vs_base;
	register object *sup=base+VM8; VC8
	vs_reserve(VM8);
	check_arg(2);
	vs_top=sup;
	{object V35=base[0]->c.c_cdr;
	if(!endp(V35))invalid_macro_call();}
	base[2]= VV[29];
	vs_top=(vs_base=base+2)+1;
	return;
}
/*	local entry for function FUNCTION-ARG-TYPES	*/

static object LI9(V37)

object V37;
{	 VMB9 VMS9 VMV9
TTL:;
	{object V38;
	register object V39;
	object V40;
	V38= Cnil;
	V39= Cnil;
	V40= Cnil;
	{register object V41;
	register int V42;
	V42= 0;
	V41= (V37);
T105:;
	if(!(endp((V41)))){
	goto T106;}
	V40= reverse((V39));
	goto T102;
T106:;
	{register object x= car((V41)),V43= VV[30];
	while(!endp(V43))
	if(eql(x,V43->c.c_car)){
	goto T111;
	}else V43=V43->c.c_cdr;}
	if(!(equal(car((V41)),VV[31]))){
	goto T110;}
T111:;
	V38= Ct;
	V44= make_cons(VV[31],(V39));
	V40= reverse(/* INLINE-ARGS */V44);
	goto T102;
T110:;
	if(!((V42)<(9))){
	goto T121;}
	{register object V46;
	V46= (*(LnkLI122))(car((V41)));
	if(!((VV[32])==((V46)))){
	goto T125;}
	V45= Ct;
	goto T119;
T125:;
	V45= (V46);
	goto T119;}
T121:;
	if(!((car((V41)))==(VV[31]))){
	goto T128;}
	V45= VV[31];
	goto T119;
T128:;
	V45= Ct;
T119:;
	V39= make_cons(V45,(V39));
	V41= cdr((V41));
	V42= (1)+(V42);
	goto T105;}
T102:;
	if(((V38))==Cnil){
	goto T134;}
	{register object V47;
	V47= (V40);
T138:;
	if(((V47))!=Cnil){
	goto T139;}
	goto T134;
T139:;
	{register object V49;
	if(!((car((V47)))==(VV[31]))){
	goto T146;}
	V49= VV[31];
	goto T144;
T146:;
	V49= Ct;
T144:;
	if(type_of(V47)!=t_cons)FEwrong_type_argument(Scons,V47);
	(V47)->c.c_car = (V49);}
	V47= cdr((V47));
	goto T138;}
T134:;
	{object V50 = (V40);
	VMR9(V50)}}
}
/*	local entry for function FUNCTION-RETURN-TYPE	*/

static object LI10(V52)

register object V52;
{	 VMB10 VMS10 VMV10
TTL:;
	base[0]= car((V52));
	base[1]= VV[33];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk123)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T153;}
	goto T152;
T153:;
	V52= cdr((V52));
T152:;
	if(!(endp((V52)))){
	goto T159;}
	{object V53 = Cnil;
	VMR10(V53)}
T159:;
	if(!(type_of(car((V52)))==t_cons)){
	goto T162;}
	if(!((caar((V52)))==(VV[33]))){
	goto T162;}
	V52= cdr(car((V52)));
	goto TTL;
T162:;
	{register object V54;
	register object V55;
	V54= (V52);
	V55= Cnil;
T169:;
	if(!(endp((V54)))){
	goto T170;}{object V56;
	base[0]= (V54);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk124)();
	vs_top=sup;
	V56= vs_base[0];
	if(V56==Cnil)goto T174;
	goto T173;
T174:;}
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[34],(V52))));
T173:;
	{object V57 = nreverse((V55));
	VMR10(V57)}
T170:;
	{register object V58;
	if(!((car((V54)))==(VV[31]))){
	goto T181;}
	V58= VV[31];
	goto T179;
T181:;
	V58= (*(LnkLI122))(car((V54)));
T179:;
	if(!(((V58))==(VV[32]))){
	goto T183;}
	V58= Ct;
T183:;
	V55= make_cons((V58),(V55));}
	V54= cdr((V54));
	goto T169;}
}
/*	local entry for function ADD-FUNCTION-PROCLAMATION	*/

static object LI11(V62,V63,V64)

object V62;register object V63;register object V64;
{	 VMB11 VMS11 VMV11
TTL:;
	{register object V65;
	register object V66;
	register object V67;
	V65= Ct;
	V66= Cnil;
	V67= Cnil;
	if(!(type_of((V62))==t_symbol)){
	goto T195;}
	if(!(type_of((V63))==t_cons||((V63))==Cnil)){
	goto T195;}
	{object V68= cdr((V63));
	if(!(type_of(V68)==t_cons||(V68)==Cnil)){
	goto T195;}}
	if(((V63))==Cnil){
	goto T202;}
	if(!((car((V63)))==(VV[31]))){
	goto T203;}
T202:;
	V66= VV[35];
	goto T201;
T203:;
	V66= (*(LnkLI126))(car((V63)));
T201:;
	V67= (*(LnkLI127))(cdr((V63)));
	if(!(type_of((V67))==t_cons)){
	goto T213;}
	if(!(endp(cdr((V67))))){
	goto T213;}
	if((car((V67)))==(VV[31])){
	goto T213;}
	base[0]= (V66);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk128)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T224;}
	V70= Cnil;
	goto T223;
T224:;
	V70= (V66);
T223:;
	{register object x= VV[31],V69= V70;
	while(!endp(V69))
	if(eql(x,V69->c.c_car)){
	goto T222;
	}else V69=V69->c.c_cdr;
	goto T221;}
T222:;
	V67= Ct;
	goto T219;
T221:;
	V67= car((V67));
T219:;
	goto T211;
T213:;
	V65= Cnil;
T211:;
	{object V71;
	base[0]= (V66);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk129)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T230;}
	V71= Cnil;
	goto T229;
T230:;
	base[0]= make_fixnum(length((V66)));
	base[1]= small_fixnum(64);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk130)();
	vs_top=sup;
	V71= vs_base[0];
T229:;
	if(((V71))==Cnil){
	goto T236;}
	goto T228;
T236:;
	V65= Cnil;}
T228:;
	{register object V72;
	V72= (V62);
T240:;{object V73;
	base[0]= (V72);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk131)();
	vs_top=sup;
	V73= vs_base[0];
	if(V73==Cnil)goto T244;
	goto T243;
T244:;}
	V62= (V72);
	V64= Cnil;
	goto TTL;
T243:;
	if(!(((V66))==(VV[31]))){
	goto T253;}
	(void)(remprop((V72),VV[36]));
	goto T251;
T253:;
	(void)(putprop((V72),(V66),VV[36]));
T251:;
	(void)(putprop((V72),(V67),VV[37]));
	if(((V65))==Cnil){
	goto T258;}
	(void)(putprop((V72),Ct,VV[38]));
	goto T256;
T258:;
	(void)(remprop((V72),VV[38]));
T256:;
	V64= cdr((V64));{object V74;
	base[0]= (V64);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk128)();
	vs_top=sup;
	V74= vs_base[0];
	if(V74==Cnil)goto T263;
	goto T262;
T263:;}
	{object V75 = VV[39];
	VMR11(V75)}
T262:;
	V72= car((V64));
	goto T240;}
T195:;
	{object V76 = (VFUN_NARGS=3,(*(LnkLI125))(VV[40],(V62),(V63)));
	VMR11(V76)}}
}
/*	local entry for function ADD-FUNCTION-DECLARATION	*/

static object LI12(V80,V81,V82)

object V80;object V81;object V82;
{	 VMB12 VMS12 VMV12
TTL:;
	if(!(type_of((V80))==t_symbol)){
	goto T270;}
	V83= (*(LnkLI132))((V80));
	V84= (*(LnkLI126))((V81));
	V85= list(3,/* INLINE-ARGS */V83,/* INLINE-ARGS */V84,(*(LnkLI127))((V82)));
	setq(VV[15],make_cons(/* INLINE-ARGS */V85,symbol_value(VV[15])));
	{object V86 = symbol_value(VV[15]);
	VMR12(V86)}
T270:;
	{object V87 = (VFUN_NARGS=2,(*(LnkLI125))(VV[41],(V80)));
	VMR12(V87)}
}
/*	local entry for function GET-ARG-TYPES	*/

static object LI13(V89)

object V89;
{	 VMB13 VMS13 VMV13
TTL:;
	{object V90;
	V90= Cnil;
	{register object x= (V89),V91= symbol_value(VV[15]);
	while(!endp(V91))
	if(type_of(V91->c.c_car)==t_cons &&eql(x,V91->c.c_car->c.c_car)){
	V90= (V91->c.c_car);
	goto T277;
	}else V91=V91->c.c_cdr;
	V90= Cnil;}
T277:;
	if(((V90))==Cnil){
	goto T275;}
	{object V92 = cadr((V90));
	VMR13(V92)}
T275:;
	{object V93 = get((V89),VV[36],Cnil);
	VMR13(V93)}}
}
/*	local entry for function GET-RETURN-TYPE	*/

static object LI14(V95)

register object V95;
{	 VMB14 VMS14 VMV14
TTL:;
	{object V96;
	object V97;
	register object V98;
	{register object x= (V95),V99= symbol_value(VV[15]);
	while(!endp(V99))
	if(type_of(V99->c.c_car)==t_cons &&eql(x,V99->c.c_car->c.c_car)){
	V96= (V99->c.c_car);
	goto T278;
	}else V99=V99->c.c_cdr;
	V96= Cnil;}
T278:;
	if(((V96))==Cnil){
	goto T281;}
	V97= caddr((V96));
	goto T279;
T281:;
	V97= get((V95),VV[37],Cnil);
T279:;
	if((get((V95),VV[42],Cnil))==Cnil){
	goto T285;}
	V98= VV[43];
	goto T283;
T285:;
	V98= get((V95),VV[44],Cnil);
T283:;
	if(((V97))==Cnil){
	goto T288;}
	if(((V98))==Cnil){
	goto T291;}
	V98= (*(LnkLI133))((V98),(V97));
	if(((V98))==Cnil){
	goto T294;}
	{object V100 = (V98);
	VMR14(V100)}
T294:;
	{object V101 = (VFUN_NARGS=2,(*(LnkLI134))(VV[45],(V95)));
	VMR14(V101)}
T291:;
	{object V102 = (V97);
	VMR14(V102)}
T288:;
	{object V103 = (V98);
	VMR14(V103)}}
}
/*	local entry for function GET-LOCAL-ARG-TYPES	*/

static object LI15(V105)

object V105;
{	 VMB15 VMS15 VMV15
TTL:;
	{object V106;
	V106= Cnil;
	{register object x= (V105),V107= symbol_value(VV[15]);
	while(!endp(V107))
	if(type_of(V107->c.c_car)==t_cons &&eql(x,V107->c.c_car->c.c_car)){
	V106= (V107->c.c_car);
	goto T301;
	}else V107=V107->c.c_cdr;
	V106= Cnil;}
T301:;
	if(((V106))==Cnil){
	goto T299;}
	{object V108 = cadr((V106));
	VMR15(V108)}
T299:;
	{object V109 = Cnil;
	VMR15(V109)}}
}
/*	local entry for function GET-LOCAL-RETURN-TYPE	*/

static object LI16(V111)

object V111;
{	 VMB16 VMS16 VMV16
TTL:;
	{object V112;
	V112= Cnil;
	{register object x= (V111),V113= symbol_value(VV[15]);
	while(!endp(V113))
	if(type_of(V113->c.c_car)==t_cons &&eql(x,V113->c.c_car->c.c_car)){
	V112= (V113->c.c_car);
	goto T306;
	}else V113=V113->c.c_cdr;
	V112= Cnil;}
T306:;
	if(((V112))==Cnil){
	goto T304;}
	{object V114 = caddr((V112));
	VMR16(V114)}
T304:;
	{object V115 = Cnil;
	VMR16(V115)}}
}
/*	local entry for function RESET-TOP	*/

static object LI17()

{	 VMB17 VMS17 VMV17
TTL:;
	princ_str("vs_top=sup;",VV[46]);
	setq(VV[47],Ct);
	{object V116 = Ct;
	VMR17(V116)}
}
/*	macro definition for BASE-USED	*/

static L18()
{register object *base=vs_base;
	register object *sup=base+VM18; VC18
	vs_reserve(VM18);
	check_arg(2);
	vs_top=sup;
	{object V117=base[0]->c.c_cdr;
	if(!endp(V117))invalid_macro_call();}
	base[2]= VV[48];
	vs_top=(vs_base=base+2)+1;
	return;
}
/*	local entry for function INLINE-POSSIBLE	*/

static object LI19(V119)

object V119;
{	 VMB19 VMS19 VMV19
TTL:;
	if(symbol_value(VV[49])!=Cnil){
	base[0]= symbol_value(VV[49]);
	goto T310;}{object V120;
	{register object x= (V119),V121= symbol_value(VV[18]);
	while(!endp(V121))
	if(eql(x,V121->c.c_car)){
	V120= V121;
	goto T312;
	}else V121=V121->c.c_cdr;
	V120= Cnil;}
T312:;
	if(V120==Cnil)goto T311;
	base[0]= V120;
	goto T310;
T311:;}
	base[0]= get((V119),VV[50],Cnil);
T310:;
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk135)();
	vs_top=sup;
	{object V122 = vs_base[0];
	VMR19(V122)}
}
/*	local entry for function PROCLAIM	*/

static object LI20(V124)

object V124;
{	 VMB20 VMS20 VMV20
TTL:;
	{object V125= car((V124));
	if((V125!= VV[136]))goto T314;
	{register object V126;
	object V127;
	V126= cdr((V124));
	V127= car((V126));
T318:;
	if(!(endp((V126)))){
	goto T319;}
	goto T313;
T319:;
	if(!(type_of((V127))==t_symbol)){
	goto T325;}
	base[2]= (V127);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk137)();
	vs_top=sup;
	goto T323;
T325:;
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[51],(V127))));
T323:;
	V126= cdr((V126));
	V127= car((V126));
	goto T318;}
T314:;
	if((V125!= VV[138]))goto T333;
	{register object V128;
	register object V129;
	V128= cdr((V124));
	V129= car((V128));
T337:;
	if(!(endp((V128)))){
	goto T338;}
	goto T313;
T338:;
	if(!(type_of((V129))==t_symbol)){
	goto T342;}
	V129= list(2,(V129),small_fixnum(3));
T342:;
	if(!(type_of((V129))==t_cons)){
	goto T347;}
	if(!(type_of(cdr((V129)))==t_cons)){
	goto T347;}
	{object V130= cadr((V129));
	if(!(type_of(V130)==t_fixnum||
type_of(V130)==t_bignum||
type_of(V130)==t_ratio||
type_of(V130)==t_shortfloat||
type_of(V130)==t_longfloat||
type_of(V130)==t_complex)){
	goto T347;}}
	base[2]= small_fixnum(0);
	base[3]= cadr((V129));
	base[4]= small_fixnum(3);
	vs_top=(vs_base=base+2)+3;
	(void) (*Lnk139)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T348;}
T347:;
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[52],(V129))));
	goto T346;
T348:;
	{object V131= car((V129));
	if((V131!= VV[85]))goto T359;
	base[2]= cadr((V129));
	base[3]= small_fixnum(1);
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk140)();
	vs_top=sup;
	setq(VV[53],vs_base[0]);
	base[2]= cadr((V129));
	base[3]= small_fixnum(2);
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk140)();
	vs_top=sup;
	setq(VV[54],vs_base[0]);
	base[2]= cadr((V129));
	base[3]= small_fixnum(3);
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk140)();
	vs_top=sup;
	setq(VV[49],vs_base[0]);
	goto T346;
T359:;
	if((V131!= VV[86]))goto T371;
	setq(VV[55],cadr((V129)));
	goto T346;
T371:;
	if((V131!= VV[141]))goto T373;
	setq(VV[56],cadr((V129)));
	goto T346;
T373:;
	if((V131!= VV[142]))goto T375;
	setq(VV[56],number_minus(small_fixnum(3),cadr((V129))));
	goto T346;
T375:;
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[57],car((V129)))));}
T346:;
	V128= cdr((V128));
	V129= car((V128));
	goto T337;}
T333:;
	if((V125!= VV[143]))goto T382;
	if(!(type_of(cdr((V124)))==t_cons)){
	goto T384;}
	(void)((*(LnkLI144))(cadr((V124)),cddr((V124))));
	goto T313;
T384:;
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[58],(V124))));
	goto T313;
T382:;
	if((V125!= VV[145])
	&& (V125!= VV[146])
	&& (V125!= VV[147])
	&& (V125!= VV[148]))goto T386;
	(void)((*(LnkLI144))(car((V124)),cdr((V124))));
	goto T313;
T386:;
	if((V125!= VV[149]))goto T387;
	if(!(type_of(cdr((V124)))==t_cons)){
	goto T389;}
	if(!(type_of(cadr((V124)))==t_cons)){
	goto T389;}
	if(!((caadr((V124)))==(VV[26]))){
	goto T389;}
	(void)((*(LnkLI150))(caddr((V124)),cdr(cadr((V124))),cddr((V124))));
	goto T313;
T389:;
	(void)((VFUN_NARGS=2,(*(LnkLI134))(VV[59],(V124))));
	goto T313;
T387:;
	if((V125!= VV[26]))goto T395;
	if(!(type_of(cdr((V124)))==t_cons)){
	goto T397;}
	(void)((*(LnkLI150))(cadr((V124)),cddr((V124)),Cnil));
	goto T313;
T397:;
	(void)((VFUN_NARGS=2,(*(LnkLI134))(VV[60],(V124))));
	goto T313;
T395:;
	if((V125!= VV[90]))goto T399;
	{register object V132;
	object V133;
	V132= cdr((V124));
	V133= car((V132));
T403:;
	if(!(endp((V132)))){
	goto T404;}
	goto T313;
T404:;
	if(!(type_of((V133))==t_symbol)){
	goto T410;}
	(void)(remprop((V133),VV[50]));
	goto T408;
T410:;
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[61],(V133))));
T408:;
	V132= cdr((V132));
	V133= car((V132));
	goto T403;}
T399:;
	if((V125!= VV[92]))goto T417;
	{register object V134;
	object V135;
	V134= cdr((V124));
	V135= car((V134));
T421:;
	if(!(endp((V134)))){
	goto T422;}
	goto T313;
T422:;
	if(!(type_of((V135))==t_symbol)){
	goto T428;}
	(void)(putprop((V135),Ct,VV[50]));
	goto T426;
T428:;
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[62],(V135))));
T426:;
	V134= cdr((V134));
	V135= car((V134));
	goto T421;}
T417:;
	if((V125!= VV[79])
	&& (V125!= VV[151]))goto T435;
	{register object V136;
	object V137;
	V136= cdr((V124));
	V137= car((V136));
T439:;
	if(!(endp((V136)))){
	goto T440;}
	goto T313;
T440:;
	if(type_of((V137))==t_symbol){
	goto T444;}
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[63],(V137))));
T444:;
	V136= cdr((V136));
	V137= car((V136));
	goto T439;}
T435:;
	if((V125!= VV[152]))goto T452;
	{register object V138;
	register object V139;
	V138= cdr((V124));
	V139= car((V138));
T456:;
	if(!(endp((V138)))){
	goto T457;}
	goto T313;
T457:;
	if(!(type_of((V139))==t_symbol)){
	goto T463;}
	{register object x= (V139),V140= symbol_value(VV[64]);
	while(!endp(V140))
	if(eql(x,V140->c.c_car)){
	goto T461;
	}else V140=V140->c.c_cdr;}
	setq(VV[64],make_cons((V139),symbol_value(VV[64])));
	goto T461;
T463:;
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[65],(V139))));
T461:;
	V138= cdr((V138));
	V139= car((V138));
	goto T456;}
T452:;
	if((V125== VV[153])
	|| (V125== VV[154])
	|| (V125== VV[155])
	|| (V125== VV[156])
	|| (V125== VV[157]))goto T474;
	if((V125== VV[146])
	|| (V125== VV[158])
	|| (V125== VV[25])
	|| (V125== VV[159])
	|| (V125== VV[160]))goto T474;
	if((V125== VV[161])
	|| (V125== VV[145])
	|| (V125== VV[162])
	|| (V125== VV[163])
	|| (V125== VV[32]))goto T474;
	if((V125== VV[164])
	|| (V125== VV[165])
	|| (V125== VV[148])
	|| (V125== Cnil)
	|| (V125== VV[124]))goto T474;
	if((V125== VV[166])
	|| (V125== VV[167])
	|| (V125== VV[168])
	|| (V125== VV[169])
	|| (V125== VV[170]))goto T474;
	if((V125== VV[171])
	|| (V125== VV[172])
	|| (V125== VV[173])
	|| (V125== VV[147])
	|| (V125== VV[174]))goto T474;
	if((V125== VV[175])
	|| (V125== VV[176])
	|| (V125== VV[177])
	|| (V125== VV[178])
	|| (V125== VV[179]))goto T474;
	if((V125== VV[180])
	|| (V125== VV[181])
	|| (V125== VV[182])
	|| (V125== VV[183])
	|| (V125== Ct))goto T474;
	if((V125!= VV[184])
	&& (V125!= VV[185])
	&& (V125!= VV[186]))goto T473;
T474:;
	(void)((*(LnkLI144))(car((V124)),cdr((V124))));
	goto T313;
T473:;
	{register object x= car((V124)),V141= symbol_value(VV[64]);
	while(!endp(V141))
	if(eql(x,V141->c.c_car)){
	goto T475;
	}else V141=V141->c.c_cdr;}
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[66],car((V124)))));
T475:;
	base[0]= get(car((V124)),VV[67],Cnil);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk187)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T478;}
	goto T313;
T478:;
	{register object V142;
	object V143;
	V142= cdr((V124));
	V143= car((V142));
T484:;
	if(!(endp((V142)))){
	goto T485;}
	goto T313;
T485:;
	V144= get(car((V124)),VV[67],Cnil);
	(void)((
	V145 = V144,
	(type_of(V145) == t_sfun ?(*(object (*)())((V145)->sfn.sfn_self)):
	(fcall.fun=(V145),fcall.argd=1,fcalln))((V143))));
	V142= cdr((V142));
	V143= car((V142));
	goto T484;}}
T313:;
	{object V146 = Cnil;
	VMR20(V146)}
}
/*	local entry for function PROCLAIM-VAR	*/

static object LI21(V149,V150)

register object V149;object V150;
{	 VMB21 VMS21 VMV21
TTL:;
	V149= (*(LnkLI122))((V149));
	{register object V151;
	register object V152;
	V151= (V150);
	V152= car((V151));
T501:;
	if(!(endp((V151)))){
	goto T502;}
	{object V153 = Cnil;
	VMR21(V153)}
T502:;
	if(!(type_of((V152))==t_symbol)){
	goto T508;}
	{register object V154;
	register object V155;
	V154= get((V152),VV[68],Cnil);
	V155= (*(LnkLI188))((V152));
	if(((V154))==Cnil){
	goto T515;}
	V154= (*(LnkLI133))((V154),(V149));
	goto T513;
T515:;
	V154= (V149);
T513:;
	if(((V155))==Cnil){
	goto T517;}
	V156= structure_ref((V155),VV[69],5);
	V154= (*(LnkLI133))((V154),/* INLINE-ARGS */V156);
T517:;
	if(((V154))!=Cnil){
	goto T521;}
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[70],(V152))));
T521:;
	(void)(putprop((V152),(V154),VV[68]));
	if(((V155))==Cnil){
	goto T506;}
	(void)(structure_set((V155),VV[69],5,(V154)));
	goto T506;}
T508:;
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[71],(V152))));
T506:;
	V151= cdr((V151));
	V152= car((V151));
	goto T501;}
}
/*	function definition for C1BODY	*/

static L22()
{register object *base=vs_base;
	register object *sup=base+VM22; VC22
	vs_reserve(VM22);
	{object V157;
	object V158;
	check_arg(2);
	V157=(base[0]);
	V158=(base[1]);
	vs_top=sup;
TTL:;
	{object V159;
	object V160;
	register object V161;
	object V162;
	object V163;
	object V164;
	V159= Cnil;
	V160= Cnil;
	V161= Cnil;
	V162= Cnil;
	V163= Cnil;
	V164= Cnil;
T540:;
	if(!(endp((V157)))){
	goto T542;}
	goto T538;
T542:;
	V164= (*(LnkLI189))(car((V157)));
	if(!(type_of((V164))==t_string)){
	goto T549;}
	if(((V158))==Cnil){
	goto T552;}
	if(endp(cdr((V157)))){
	goto T552;}
	if(((V163))==Cnil){
	goto T551;}
T552:;
	goto T538;
T551:;
	V163= (V164);
	goto T547;
T549:;
	if(!(type_of((V164))==t_cons)){
	goto T560;}
	if(!((car((V164)))==(VV[72]))){
	goto T560;}
	{object V165;
	register object V166;
	V165= cdr((V164));
	V166= car((V165));
T567:;
	if(!(endp((V165)))){
	goto T568;}
	goto T547;
T568:;
	if(!(type_of((V166))==t_cons)){
	goto T573;}
	if(type_of(car((V166)))==t_symbol){
	goto T572;}
T573:;
	(void)((VFUN_NARGS=2,(*(LnkLI121))(VV[73],(V166))));
T572:;
	{object V167= car((V166));
	if((V167!= VV[136]))goto T578;
	{register object V168;
	object V169;
	V168= cdr((V166));
	V169= car((V168));
T582:;
	if(!(endp((V168)))){
	goto T583;}
	goto T577;
T583:;
	if(type_of((V169))==t_symbol){
	goto T587;}
	(void)((VFUN_NARGS=3,(*(LnkLI121))(VV[74],(V166),(V169))));
T587:;
	V159= make_cons((V169),(V159));
	V168= cdr((V168));
	V169= car((V168));
	goto T582;}
T578:;
	if((V167!= VV[151]))goto T597;
	{register object V170;
	object V171;
	V170= cdr((V166));
	V171= car((V170));
T601:;
	if(!(endp((V170)))){
	goto T602;}
	goto T577;
T602:;
	if(type_of((V171))==t_symbol){
	goto T606;}
	(void)((VFUN_NARGS=3,(*(LnkLI121))(VV[75],(V166),(V171))));
T606:;
	V160= make_cons((V171),(V160));
	V170= cdr((V170));
	V171= car((V170));
	goto T601;}
T597:;
	if((V167!= VV[143]))goto T616;
	if(!(endp(cdr((V166))))){
	goto T617;}
	(void)((VFUN_NARGS=2,(*(LnkLI121))(VV[76],(V166))));
T617:;
	{object V172;
	V172= (*(LnkLI122))(cadr((V166)));
	if(((V172))==Cnil){
	goto T577;}
	{register object V173;
	object V174;
	V173= cddr((V166));
	V174= car((V173));
T626:;
	if(!(endp((V173)))){
	goto T627;}
	goto T577;
T627:;
	if(type_of((V174))==t_symbol){
	goto T631;}
	(void)((VFUN_NARGS=3,(*(LnkLI121))(VV[77],(V166),(V174))));
T631:;
	V175= make_cons((V174),(V172));
	V161= make_cons(/* INLINE-ARGS */V175,(V161));
	V173= cdr((V173));
	V174= car((V173));
	goto T626;}}
T616:;
	if((V167!= VV[79]))goto T641;
	{register object V176;
	object V177;
	V176= cdr((V166));
	V177= car((V176));
T645:;
	if(!(endp((V176)))){
	goto T646;}
	goto T577;
T646:;
	if(type_of((V177))==t_symbol){
	goto T650;}
	(void)((VFUN_NARGS=3,(*(LnkLI121))(VV[78],(V166),(V177))));
T650:;
	V178= make_cons((V177),VV[79]);
	V161= make_cons(/* INLINE-ARGS */V178,(V161));
	V176= cdr((V176));
	V177= car((V176));
	goto T645;}
T641:;
	if((V167!= VV[190]))goto T660;
	{register object V179;
	object V180;
	V179= cdr((V166));
	V180= car((V179));
T664:;
	if(!(endp((V179)))){
	goto T665;}
	goto T577;
T665:;
	if(type_of((V180))==t_symbol){
	goto T669;}
	(void)((VFUN_NARGS=3,(*(LnkLI121))(VV[80],(V166),(V180))));
T669:;
	V181= make_cons((V180),VV[81]);
	V161= make_cons(/* INLINE-ARGS */V181,(V161));
	V179= cdr((V179));
	V180= car((V179));
	goto T664;}
T660:;
	if((V167== VV[145])
	|| (V167== VV[146])
	|| (V167== VV[161])
	|| (V167== VV[147])
	|| (V167== VV[153]))goto T680;
	if((V167== VV[154])
	|| (V167== VV[155])
	|| (V167== VV[156])
	|| (V167== VV[157])
	|| (V167== VV[158]))goto T680;
	if((V167== VV[25])
	|| (V167== VV[159])
	|| (V167== VV[160])
	|| (V167== VV[162])
	|| (V167== VV[163]))goto T680;
	if((V167== VV[32])
	|| (V167== VV[164])
	|| (V167== VV[165])
	|| (V167== VV[148])
	|| (V167== Cnil))goto T680;
	if((V167== VV[124])
	|| (V167== VV[166])
	|| (V167== VV[167])
	|| (V167== VV[168])
	|| (V167== VV[169]))goto T680;
	if((V167== VV[170])
	|| (V167== VV[171])
	|| (V167== VV[172])
	|| (V167== VV[173])
	|| (V167== VV[174]))goto T680;
	if((V167== VV[175])
	|| (V167== VV[176])
	|| (V167== VV[177])
	|| (V167== VV[178])
	|| (V167== VV[179]))goto T680;
	if((V167== VV[180])
	|| (V167== VV[181])
	|| (V167== VV[182])
	|| (V167== VV[183])
	|| (V167== Ct))goto T680;
	if((V167!= VV[184])
	&& (V167!= VV[185])
	&& (V167!= VV[186])
	&& (V167!= VV[82]))goto T679;
T680:;
	{object V182;
	if(!((car((V166)))==(VV[82]))){
	goto T683;}
	V182= car((V166));
	goto T681;
T683:;
	V182= (*(LnkLI122))(car((V166)));
T681:;
	if(((V182))==Cnil){
	goto T577;}
	{register object V183;
	object V184;
	V183= cdr((V166));
	V184= car((V183));
T690:;
	if(!(endp((V183)))){
	goto T691;}
	goto T577;
T691:;
	if(type_of((V184))==t_symbol){
	goto T695;}
	(void)((VFUN_NARGS=3,(*(LnkLI121))(VV[83],(V166),(V184))));
T695:;
	V185= make_cons((V184),(V182));
	V161= make_cons(/* INLINE-ARGS */V185,(V161));
	V183= cdr((V183));
	V184= car((V183));
	goto T690;}}
T679:;
	V162= make_cons((V166),(V162));}
T577:;
	V165= cdr((V165));
	V166= car((V165));
	goto T567;}
T560:;
	goto T538;
T547:;
	{object V186;
	V186= car((V157));
	V157= cdr((V157));}
	goto T540;
T538:;
	base[2]= (V157);
	base[3]= (V159);
	base[4]= (V161);
	base[5]= (V160);
	base[6]= (V162);
	base[7]= (V163);
	vs_top=(vs_base=base+2)+6;
	return;}
	}
}
/*	local entry for function C1DECL-BODY	*/

static object LI23(V189,V190)

object V189;object V190;
{	 VMB23 VMS23 VMV23
	bds_check;
TTL:;
	{register object V191;
	V191= Cnil;
	if(((V189))!=Cnil){
	goto T723;}
	{object V192 = (*(LnkLI191))((V190));
	VMR23(V192)}
T723:;
	bds_bind(VV[15],symbol_value(VV[15]));
	bds_bind(VV[64],symbol_value(VV[64]));
	bds_bind(VV[18],symbol_value(VV[18]));
	bds_bind(VV[55],symbol_value(VV[55]));
	bds_bind(VV[54],symbol_value(VV[54]));
	{object V193;
	register object V194;
	V193= (V189);
	V194= car((V193));
T729:;
	if(!(endp((V193)))){
	goto T730;}
	goto T725;
T730:;
	{object V195= car((V194));
	if((V195!= VV[138]))goto T735;
	{object V196;
	register object V197;
	V196= cdr((V194));
	V197= car((V196));
T739:;
	if(!(endp((V196)))){
	goto T740;}
	goto T734;
T740:;
	if(!(type_of((V197))==t_symbol)){
	goto T744;}
	V197= list(2,(V197),small_fixnum(3));
T744:;
	if(!(type_of((V197))==t_cons)){
	goto T749;}
	if(!(type_of(cdr((V197)))==t_cons)){
	goto T749;}
	{object V198= cadr((V197));
	if(!(type_of(V198)==t_fixnum||
type_of(V198)==t_bignum||
type_of(V198)==t_ratio||
type_of(V198)==t_shortfloat||
type_of(V198)==t_longfloat||
type_of(V198)==t_complex)){
	goto T749;}}
	base[8]= small_fixnum(0);
	base[9]= cadr((V197));
	base[10]= small_fixnum(3);
	vs_top=(vs_base=base+8)+3;
	(void) (*Lnk139)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T750;}
T749:;
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[84],(V197))));
	goto T748;
T750:;
	{object V199= car((V197));
	if((V199!= VV[85]))goto T761;
	base[8]= cadr((V197));
	base[9]= small_fixnum(2);
	vs_top=(vs_base=base+8)+2;
	(void) (*Lnk140)();
	vs_top=sup;
	(VV[54]->s.s_dbind)= vs_base[0];
	V200= list(2,VV[85],cadr((V197)));
	V191= make_cons(/* INLINE-ARGS */V200,(V191));
	goto T748;
T761:;
	if((V199!= VV[86]))goto T767;
	(VV[55]->s.s_dbind)= cadr((V197));
	V201= list(2,VV[86],cadr((V197)));
	V191= make_cons(/* INLINE-ARGS */V201,(V191));
	goto T748;
T767:;
	if((V199!= VV[141])
	&& (V199!= VV[142]))goto T771;
	goto T748;
T771:;
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[87],car((V197)))));}
T748:;
	V196= cdr((V196));
	V197= car((V196));
	goto T739;}
T735:;
	if((V195!= VV[149]))goto T777;
	if(endp(cdr((V194)))){
	goto T778;}
	if(!(type_of(cadr((V194)))==t_cons)){
	goto T778;}
	if(!((caadr((V194)))==(VV[26]))){
	goto T778;}
	if(!(endp(cdadr((V194))))){
	goto T779;}
T778:;
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[88],(V194))));
	goto T734;
T779:;
	{object V202;
	object V203;
	V202= cddr((V194));
	V203= car((V202));
T790:;
	if(!(endp((V202)))){
	goto T791;}
	goto T734;
T791:;
	(void)((*(LnkLI192))((V203),cadadr((V194)),cddadr((V194))));
	V202= cdr((V202));
	V203= car((V202));
	goto T790;}
T777:;
	if((V195!= VV[26]))goto T801;
	if(endp(cdr((V194)))){
	goto T802;}
	if(endp(cddr((V194)))){
	goto T802;}
	if(type_of(cadr((V194)))==t_symbol){
	goto T803;}
T802:;
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[89],(V194))));
	goto T734;
T803:;
	(void)((*(LnkLI192))(cadr((V194)),caddr((V194)),cdddr((V194))));
	goto T734;
T801:;
	if((V195!= VV[90]))goto T809;
	{object V204;
	register object V205;
	V204= cdr((V194));
	V205= car((V204));
T813:;
	if(!(endp((V204)))){
	goto T814;}
	goto T734;
T814:;
	if(!(type_of((V205))==t_symbol)){
	goto T820;}
	V206= list(2,VV[90],(V205));
	V191= make_cons(/* INLINE-ARGS */V206,(V191));
	(VV[18]->s.s_dbind)= (VFUN_NARGS=2,(*(LnkLI193))((V205),(VV[18]->s.s_dbind)));
	goto T818;
T820:;
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[91],(V205))));
T818:;
	V204= cdr((V204));
	V205= car((V204));
	goto T813;}
T809:;
	if((V195!= VV[92]))goto T830;
	{object V207;
	register object V208;
	V207= cdr((V194));
	V208= car((V207));
T834:;
	if(!(endp((V207)))){
	goto T835;}
	goto T734;
T835:;
	if(!(type_of((V208))==t_symbol)){
	goto T841;}
	V209= list(2,VV[92],(V208));
	V191= make_cons(/* INLINE-ARGS */V209,(V191));
	(VV[18]->s.s_dbind)= make_cons((V208),(VV[18]->s.s_dbind));
	goto T839;
T841:;
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[93],(V208))));
T839:;
	V207= cdr((V207));
	V208= car((V207));
	goto T834;}
T830:;
	if((V195!= VV[152]))goto T851;
	{object V210;
	register object V211;
	V210= cdr((V194));
	V211= car((V210));
T855:;
	if(!(endp((V210)))){
	goto T856;}
	goto T734;
T856:;
	if(!(type_of((V211))==t_symbol)){
	goto T862;}
	{register object x= (V211),V212= (VV[64]->s.s_dbind);
	while(!endp(V212))
	if(eql(x,V212->c.c_car)){
	goto T860;
	}else V212=V212->c.c_cdr;}
	(VV[64]->s.s_dbind)= make_cons((V211),(VV[64]->s.s_dbind));
	goto T860;
T862:;
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[94],(V211))));
T860:;
	V210= cdr((V210));
	V211= car((V210));
	goto T855;}
T851:;
	{register object x= car((V194)),V213= (VV[64]->s.s_dbind);
	while(!endp(V213))
	if(eql(x,V213->c.c_car)){
	goto T734;
	}else V213=V213->c.c_cdr;}
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[95],car((V194)))));}
T734:;
	V193= cdr((V193));
	V194= car((V193));
	goto T729;}
T725:;
	V190= (*(LnkLI191))((V190));
	{object V214 = list(4,VV[96],cadr((V190)),(V191),(V190));
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	VMR23(V214)}}
}
/*	function definition for C2DECL-BODY	*/

static L24()
{register object *base=vs_base;
	register object *sup=base+VM24; VC24
	vs_reserve(VM24);
	bds_check;
	{object V215;
	object V216;
	check_arg(2);
	V215=(base[0]);
	V216=(base[1]);
	vs_top=sup;
TTL:;
	bds_bind(VV[53],symbol_value(VV[53]));
	bds_bind(VV[54],symbol_value(VV[54]));
	bds_bind(VV[49],symbol_value(VV[49]));
	bds_bind(VV[18],symbol_value(VV[18]));
	bds_bind(VV[55],symbol_value(VV[55]));
	{register object V217;
	register object V218;
	V217= (V215);
	V218= car((V217));
T885:;
	if(!(endp((V217)))){
	goto T886;}
	goto T881;
T886:;
	{object V219= car((V218));
	if((V219!= VV[85]))goto T891;
	{register int V220;
	V220= fix(cadr((V218)));
	base[8]= make_fixnum(V220);
	base[9]= small_fixnum(1);
	vs_top=(vs_base=base+8)+2;
	(void) (*Lnk140)();
	vs_top=sup;
	(VV[53]->s.s_dbind)= vs_base[0];
	base[8]= make_fixnum(V220);
	base[9]= small_fixnum(2);
	vs_top=(vs_base=base+8)+2;
	(void) (*Lnk140)();
	vs_top=sup;
	(VV[54]->s.s_dbind)= vs_base[0];
	base[8]= make_fixnum(V220);
	base[9]= small_fixnum(3);
	vs_top=(vs_base=base+8)+2;
	(void) (*Lnk140)();
	vs_top=sup;
	(VV[49]->s.s_dbind)= vs_base[0];
	goto T890;}
T891:;
	if((V219!= VV[86]))goto T904;
	(VV[55]->s.s_dbind)= cadr((V218));
	goto T890;
T904:;
	if((V219!= VV[92]))goto T906;
	(VV[18]->s.s_dbind)= make_cons(cadr((V218)),(VV[18]->s.s_dbind));
	goto T890;
T906:;
	if((V219!= VV[90]))goto T908;
	(VV[18]->s.s_dbind)= (VFUN_NARGS=2,(*(LnkLI193))(cadr((V218)),(VV[18]->s.s_dbind)));
	goto T890;
T908:;
	(void)((*(LnkLI194))());}
T890:;
	V217= cdr((V217));
	V218= car((V217));
	goto T885;}
T881:;
	base[7]= (V216);
	vs_top=(vs_base=base+7)+1;
	(void) (*Lnk195)();
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	return;
	}
}
/*	local entry for function CHECK-VDECL	*/

static object LI25(V224,V225,V226)

register object V224;object V225;object V226;
{	 VMB25 VMS25 VMV25
TTL:;
	{register object V227;
	register object V228;
	V227= (V225);
	V228= car((V227));
T920:;
	if(!(endp((V227)))){
	goto T921;}
	goto T916;
T921:;
	{register object x= car((V228)),V229= (V224);
	while(!endp(V229))
	if(eql(x,V229->c.c_car)){
	goto T925;
	}else V229=V229->c.c_cdr;}
	(void)((VFUN_NARGS=2,(*(LnkLI134))(VV[97],car((V228)))));
T925:;
	V227= cdr((V227));
	V228= car((V227));
	goto T920;}
T916:;
	{register object V230;
	register object V231;
	V230= (V226);
	V231= car((V230));
T936:;
	if(!(endp((V230)))){
	goto T937;}
	{object V232 = Cnil;
	VMR25(V232)}
T937:;
	{register object x= (V231),V233= (V224);
	while(!endp(V233))
	if(eql(x,V233->c.c_car)){
	goto T941;
	}else V233=V233->c.c_cdr;}
	(void)((VFUN_NARGS=2,(*(LnkLI134))(VV[98],(V231))));
T941:;
	V230= cdr((V230));
	V231= car((V230));
	goto T936;}
}
/*	local entry for function PROCLAMATION	*/

static object LI26(V235)

object V235;
{	 VMB26 VMS26 VMV26
TTL:;
	{object V236= car((V235));
	if((V236!= VV[136]))goto T949;
	{register object V237;
	object V238;
	V237= cdr((V235));
	V238= car((V237));
T953:;
	if(!(endp((V237)))){
	goto T954;}
	{object V239 = Ct;
	VMR26(V239)}
T954:;
	if(!(type_of((V238))==t_symbol)){
	goto T960;}
	base[2]= (V238);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk196)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T958;}
	{object V240 = Cnil;
	VMR26(V240)}
T960:;
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[99],(V238))));
T958:;
	V237= cdr((V237));
	V238= car((V237));
	goto T953;}
T949:;
	if((V236!= VV[138]))goto T970;
	{register object V241;
	register object V242;
	V241= cdr((V235));
	V242= car((V241));
T974:;
	if(!(endp((V241)))){
	goto T975;}
	{object V243 = Ct;
	VMR26(V243)}
T975:;
	if(!(type_of((V242))==t_symbol)){
	goto T979;}
	V242= list(2,(V242),small_fixnum(3));
T979:;
	if(!(type_of((V242))==t_cons)){
	goto T984;}
	if(!(type_of(cdr((V242)))==t_cons)){
	goto T984;}
	{object V244= cadr((V242));
	if(!(type_of(V244)==t_fixnum||
type_of(V244)==t_bignum||
type_of(V244)==t_ratio||
type_of(V244)==t_shortfloat||
type_of(V244)==t_longfloat||
type_of(V244)==t_complex)){
	goto T984;}}
	base[2]= small_fixnum(0);
	base[3]= cadr((V242));
	base[4]= small_fixnum(3);
	vs_top=(vs_base=base+2)+3;
	(void) (*Lnk139)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T985;}
T984:;
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[100],(V242))));
	goto T983;
T985:;
	{object V245= car((V242));
	if((V245!= VV[85]))goto T996;
	V246= cadr((V242));
	if((symbol_value(VV[53]))!=Cnil){
	goto T1001;}
	V247= small_fixnum(0);
	goto T999;
T1001:;
	if((symbol_value(VV[54]))!=Cnil){
	goto T1004;}
	V247= small_fixnum(1);
	goto T999;
T1004:;
	if((symbol_value(VV[49]))!=Cnil){
	goto T1007;}
	V247= small_fixnum(2);
	goto T999;
T1007:;
	V247= small_fixnum(3);
T999:;
	if(number_compare(/* INLINE-ARGS */V246,V247)==0){
	goto T983;}
	{object V248 = Cnil;
	VMR26(V248)}
T996:;
	if((V245!= VV[86]))goto T1009;
	if(number_compare(cadr((V242)),symbol_value(VV[55]))==0){
	goto T983;}
	{object V249 = Cnil;
	VMR26(V249)}
T1009:;
	if((V245!= VV[141]))goto T1012;
	if(number_compare(cadr((V242)),symbol_value(VV[56]))==0){
	goto T983;}
	{object V250 = Cnil;
	VMR26(V250)}
T1012:;
	if((V245!= VV[142]))goto T1015;
	V251= number_minus(small_fixnum(3),cadr((V242)));
	if(number_compare(/* INLINE-ARGS */V251,symbol_value(VV[56]))==0){
	goto T983;}
	{object V252 = Cnil;
	VMR26(V252)}
T1015:;
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[101],car((V242)))));}
T983:;
	V241= cdr((V241));
	V242= car((V241));
	goto T974;}
T970:;
	if((V236!= VV[143]))goto T1023;
	if(!(type_of(cdr((V235)))==t_cons)){
	goto T1025;}
	{object V253;
	object V254;
	V253= (*(LnkLI122))(cadr((V235)));
	V254= Cnil;
	{register object V255;
	object V256;
	V255= cddr((V235));
	V256= car((V255));
T1031:;
	if(!(endp((V255)))){
	goto T1032;}
	{object V257 = Ct;
	VMR26(V257)}
T1032:;
	if(!(type_of((V256))==t_symbol)){
	goto T1038;}
	V254= get((V256),VV[68],Cnil);
	if(((V254))==Cnil){
	goto T1040;}
	if(equal((V254),(V253))){
	goto T1036;}
T1040:;
	{object V258 = Cnil;
	VMR26(V258)}
T1038:;
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[102],(V256))));
T1036:;
	V255= cdr((V255));
	V256= car((V255));
	goto T1031;}}
T1025:;
	{object V259 = (VFUN_NARGS=2,(*(LnkLI125))(VV[103],(V235)));
	VMR26(V259)}
T1023:;
	if((V236!= VV[145])
	&& (V236!= VV[146])
	&& (V236!= VV[147])
	&& (V236!= VV[148]))goto T1050;
	{object V260;
	object V261;
	V260= (*(LnkLI122))(car((V235)));
	V261= Cnil;
	{register object V262;
	object V263;
	V262= cdr((V235));
	V263= car((V262));
T1055:;
	if(!(endp((V262)))){
	goto T1056;}
	{object V264 = Ct;
	VMR26(V264)}
T1056:;
	if(!(type_of((V263))==t_symbol)){
	goto T1062;}
	V261= get((V263),VV[68],Cnil);
	if(((V261))==Cnil){
	goto T1064;}
	if(equal((V261),(V260))){
	goto T1060;}
T1064:;
	{object V265 = Cnil;
	VMR26(V265)}
T1062:;
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[104],(V263))));
T1060:;
	V262= cdr((V262));
	V263= car((V262));
	goto T1055;}}
T1050:;
	if((V236!= VV[149]))goto T1074;
	if(endp(cdr((V235)))){
	goto T1075;}
	if(!(type_of(cadr((V235)))==t_cons)){
	goto T1075;}
	if(!((caadr((V235)))==(VV[26]))){
	goto T1075;}
	if(!(endp(cdadr((V235))))){
	goto T1076;}
T1075:;
	{object V266 = (VFUN_NARGS=2,(*(LnkLI125))(VV[105],(V235)));
	VMR26(V266)}
T1076:;
	{register object V267;
	object V268;
	V267= cddr((V235));
	V268= car((V267));
T1087:;
	if(!(endp((V267)))){
	goto T1088;}
	{object V269 = Ct;
	VMR26(V269)}
T1088:;
	if((get((V268),VV[38],Cnil))==Cnil){
	goto T1093;}
	V270= (*(LnkLI126))(cadadr((V235)));
	V271= get((V268),VV[36],Cnil);
	if(!(equal(/* INLINE-ARGS */V270,V271))){
	goto T1093;}
	V272= (*(LnkLI127))(cddadr((V235)));
	V273= get((V268),VV[37],Cnil);
	if(equal(/* INLINE-ARGS */V272,V273)){
	goto T1092;}
T1093:;
	{object V274 = Cnil;
	VMR26(V274)}
T1092:;
	V267= cdr((V267));
	V268= car((V267));
	goto T1087;}
T1074:;
	if((V236!= VV[26]))goto T1106;
	if(endp(cdr((V235)))){
	goto T1107;}
	if(!(endp(cddr((V235))))){
	goto T1108;}
T1107:;
	{object V275 = (VFUN_NARGS=2,(*(LnkLI125))(VV[106],(V235)));
	VMR26(V275)}
T1108:;
	if((get(cadr((V235)),VV[38],Cnil))!=Cnil){
	goto T1112;}
	{object V276 = Cnil;
	VMR26(V276)}
T1112:;
	base[0]= (*(LnkLI126))(caddr((V235)));
	base[1]= get(cadr((V235)),VV[36],Cnil);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk197)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T1114;}
	{object V277 = Cnil;
	VMR26(V277)}
T1114:;
	base[0]= (*(LnkLI127))(cdddr((V235)));
	base[1]= get(cadr((V235)),VV[37],Cnil);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk197)();
	vs_top=sup;
	{object V278 = vs_base[0];
	VMR26(V278)}
T1106:;
	if((V236!= VV[90]))goto T1120;
	{register object V279;
	object V280;
	V279= cdr((V235));
	V280= car((V279));
T1124:;
	if(!(endp((V279)))){
	goto T1125;}
	{object V281 = Ct;
	VMR26(V281)}
T1125:;
	if(!(type_of((V280))==t_symbol)){
	goto T1131;}
	if((get((V280),VV[50],Cnil))==Cnil){
	goto T1129;}
	{object V282 = Cnil;
	VMR26(V282)}
T1131:;
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[107],(V280))));
T1129:;
	V279= cdr((V279));
	V280= car((V279));
	goto T1124;}
T1120:;
	if((V236!= VV[92]))goto T1140;
	{register object V283;
	object V284;
	V283= cdr((V235));
	V284= car((V283));
T1144:;
	if(!(endp((V283)))){
	goto T1145;}
	{object V285 = Ct;
	VMR26(V285)}
T1145:;
	if(!(type_of((V284))==t_symbol)){
	goto T1151;}
	if((get((V284),VV[50],Cnil))!=Cnil){
	goto T1149;}
	{object V286 = Cnil;
	VMR26(V286)}
T1151:;
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[108],(V284))));
T1149:;
	V283= cdr((V283));
	V284= car((V283));
	goto T1144;}
T1140:;
	if((V236!= VV[79])
	&& (V236!= VV[151]))goto T1160;
	{register object V287;
	object V288;
	V287= cdr((V235));
	V288= car((V287));
T1164:;
	if(!(endp((V287)))){
	goto T1165;}
	{object V289 = Ct;
	VMR26(V289)}
T1165:;
	if(type_of((V288))==t_symbol){
	goto T1169;}
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[109],(V288))));
T1169:;
	V287= cdr((V287));
	V288= car((V287));
	goto T1164;}
T1160:;
	if((V236!= VV[152]))goto T1177;
	{register object V290;
	object V291;
	V290= cdr((V235));
	V291= car((V290));
T1181:;
	if(!(endp((V290)))){
	goto T1182;}
	{object V292 = Ct;
	VMR26(V292)}
T1182:;
	if(!(type_of((V291))==t_symbol)){
	goto T1188;}
	{register object x= (V291),V293= symbol_value(VV[64]);
	while(!endp(V293))
	if(eql(x,V293->c.c_car)){
	goto T1186;
	}else V293=V293->c.c_cdr;}
	{object V294 = Cnil;
	VMR26(V294)}
T1188:;
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[110],(V291))));
T1186:;
	V290= cdr((V290));
	V291= car((V290));
	goto T1181;}
T1177:;
	if((V236== VV[153])
	|| (V236== VV[154])
	|| (V236== VV[155])
	|| (V236== VV[156])
	|| (V236== VV[157]))goto T1198;
	if((V236== VV[146])
	|| (V236== VV[158])
	|| (V236== VV[25])
	|| (V236== VV[159])
	|| (V236== VV[160]))goto T1198;
	if((V236== VV[161])
	|| (V236== VV[145])
	|| (V236== VV[162])
	|| (V236== VV[163])
	|| (V236== VV[32]))goto T1198;
	if((V236== VV[164])
	|| (V236== VV[165])
	|| (V236== VV[148])
	|| (V236== Cnil)
	|| (V236== VV[124]))goto T1198;
	if((V236== VV[166])
	|| (V236== VV[167])
	|| (V236== VV[168])
	|| (V236== VV[169])
	|| (V236== VV[170]))goto T1198;
	if((V236== VV[171])
	|| (V236== VV[172])
	|| (V236== VV[173])
	|| (V236== VV[147])
	|| (V236== VV[174]))goto T1198;
	if((V236== VV[175])
	|| (V236== VV[176])
	|| (V236== VV[177])
	|| (V236== VV[178])
	|| (V236== VV[179]))goto T1198;
	if((V236== VV[180])
	|| (V236== VV[181])
	|| (V236== VV[182])
	|| (V236== VV[183])
	|| (V236== Ct))goto T1198;
	if((V236!= VV[184])
	&& (V236!= VV[185])
	&& (V236!= VV[186]))goto T1197;
T1198:;
	{object V295;
	V295= (*(LnkLI122))(car((V235)));
	{register object V296;
	object V297;
	V296= cdr((V235));
	V297= car((V296));
T1203:;
	if(!(endp((V296)))){
	goto T1204;}
	{object V298 = Ct;
	VMR26(V298)}
T1204:;
	if(!(type_of((V297))==t_symbol)){
	goto T1210;}
	V299= get((V297),VV[68],Cnil);
	if(equal(V299,(V295))){
	goto T1208;}
	{object V300 = Cnil;
	VMR26(V300)}
T1210:;
	(void)((VFUN_NARGS=2,(*(LnkLI125))(VV[111],(V297))));
T1208:;
	V296= cdr((V296));
	V297= car((V296));
	goto T1203;}}
T1197:;
	{register object x= car((V235)),V301= symbol_value(VV[64]);
	while(!endp(V301))
	if(eql(x,V301->c.c_car)){
	goto T1221;
	}else V301=V301->c.c_cdr;}
	{object V302 = (VFUN_NARGS=2,(*(LnkLI125))(VV[112],car((V235))));
	VMR26(V302)}
T1221:;
	{object V303 = Cnil;
	VMR26(V303)}}
}
static LnkT197(){ call_or_link(VV[197],&Lnk197);} /* EQUAL */
static LnkT196(){ call_or_link(VV[196],&Lnk196);} /* SPECIALP */
static LnkT195(){ call_or_link(VV[195],&Lnk195);} /* C2EXPR */
static object  LnkTLI194(){return call_proc0(VV[194],&LnkLI194);} /* BABOON */
static object  LnkTLI193(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[193],&LnkLI193,ap);} /* REMOVE */
static object  LnkTLI192(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[192],&LnkLI192,3,ap);} /* ADD-FUNCTION-DECLARATION */
static object  LnkTLI191(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[191],&LnkLI191,1,ap);} /* C1PROGN */
static object  LnkTLI189(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[189],&LnkLI189,1,ap);} /* CMP-MACROEXPAND */
static object  LnkTLI188(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[188],&LnkLI188,1,ap);} /* SCH-GLOBAL */
static LnkT187(){ call_or_link(VV[187],&Lnk187);} /* FUNCTIONP */
static object  LnkTLI150(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[150],&LnkLI150,3,ap);} /* ADD-FUNCTION-PROCLAMATION */
static object  LnkTLI144(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[144],&LnkLI144,2,ap);} /* PROCLAIM-VAR */
static LnkT140(){ call_or_link(VV[140],&Lnk140);} /* >= */
static LnkT139(){ call_or_link(VV[139],&Lnk139);} /* <= */
static LnkT137(){ call_or_link(VV[137],&Lnk137);} /* *MAKE-SPECIAL */
static LnkT135(){ call_or_link(VV[135],&Lnk135);} /* NOT */
static object  LnkTLI134(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[134],&LnkLI134,ap);} /* CMPWARN */
static object  LnkTLI133(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[133],&LnkLI133,2,ap);} /* TYPE-AND */
static object  LnkTLI132(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[132],&LnkLI132,1,ap);} /* SCH-LOCAL-FUN */
static LnkT131(){ call_or_link(VV[131],&Lnk131);} /* SYMBOLP */
static LnkT130(){ call_or_link(VV[130],&Lnk130);} /* < */
static LnkT129(){ call_or_link(VV[129],&Lnk129);} /* LISTP */
static LnkT128(){ call_or_link(VV[128],&Lnk128);} /* CONSP */
static object  LnkTLI127(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[127],&LnkLI127,1,ap);} /* FUNCTION-RETURN-TYPE */
static object  LnkTLI126(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[126],&LnkLI126,1,ap);} /* FUNCTION-ARG-TYPES */
static object  LnkTLI125(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[125],&LnkLI125,ap);} /* WARN */
static LnkT124(){ call_or_link(VV[124],&Lnk124);} /* NULL */
static LnkT123(){ call_or_link(VV[123],&Lnk123);} /* EQ */
static object  LnkTLI122(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[122],&LnkLI122,1,ap);} /* TYPE-FILTER */
static object  LnkTLI121(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[121],&LnkLI121,ap);} /* CMPERR */
static LnkT120(){ call_or_link(VV[120],&Lnk120);} /* COMPILED-FUNCTION-NAME */
static LnkT119(){ call_or_link(VV[119],&Lnk119);} /* TYPEP */
static LnkT118(){ call_or_link(VV[118],&Lnk118);} /* WT-TO-STRING */
static LnkT117(){ call_or_link(VV[117],&Lnk117);} /* CONTAINS-SHARP-COMMA */
static LnkT116(){ call_or_link(VV[116],&Lnk116);} /* GET-OUTPUT-STREAM-STRING */
static object  LnkTLI115(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[115],&LnkLI115,1,ap);} /* WT-DATA1 */
static LnkT114(){ call_or_link(VV[114],&Lnk114);} /* MAKE-STRING-OUTPUT-STREAM */
static object  LnkTLI113(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[113],&LnkLI113,1,ap);} /* PUSH-DATA-INCF */
