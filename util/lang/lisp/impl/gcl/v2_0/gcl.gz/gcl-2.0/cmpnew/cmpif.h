
static L4();
static L8();
static L10();
static object LI15();
static object LI1();
#define VMB1 object  V13 ,V12 ,V11 ,V6 ,V5;
#define VMS1
#define VMV1
#define VMR1(VMT1) return(VMT1);
static object LI2();
#define VMB2 register object *base=vs_top; object  V31;
#define VMS2  register object *sup=vs_top+1;vs_top=sup;
#define VMV2 vs_reserve(1);
#define VMR2(VMT2) vs_top=base ; return(VMT2);
static object LI3();
#define VMB3 register object *base=vs_top; object  V64 ,V62 ,V55 ,V47;
#define VMS3 vs_top += 1;
#define VMV3 vs_reserve(1);
#define VMR3(VMT3) vs_top=base ; return(VMT3);
#define VC4 object  V74 ,V73;
static object LI5();
#define VMB5 register object *base=vs_top;
#define VMS5 vs_top += 2;
#define VMV5 vs_reserve(2);
#define VMR5(VMT5) vs_top=base ; return(VMT5);
static object LI6();
#define VMB6 register object *base=vs_top;
#define VMS6 vs_top += 2;
#define VMV6 vs_reserve(2);
#define VMR6(VMT6) vs_top=base ; return(VMT6);
static object LI7();
#define VMB7
#define VMS7
#define VMV7
#define VMR7(VMT7) return(VMT7);
#define VC8 object  V119;
static object LI9();
#define VMB9
#define VMS9
#define VMV9
#define VMR9(VMT9) return(VMT9);
#define VC10 object  V135 ,V134 ,V132 ,V130;
static object LI11();
#define VMB11 register object *base=vs_top;
#define VMS11  register object *sup=vs_top+2;vs_top=sup;
#define VMV11 vs_reserve(2);
#define VMR11(VMT11) vs_top=base ; return(VMT11);
static object LI12();
#define VMB12 register object *base=vs_top;
#define VMS12  register object *sup=vs_top+2;vs_top=sup;
#define VMV12 vs_reserve(2);
#define VMR12(VMT12) vs_top=base ; return(VMT12);
static object LI13();
#define VMB13
#define VMS13
#define VMV13
#define VMR13(VMT13) return(VMT13);
static object LI14();
#define VMB14 register object *base=vs_top; object  V172 ,V171 ,V170 ,V167;
#define VMS14  register object *sup=vs_top+4;vs_top=sup;
#define VMV14 vs_reserve(4);
#define VMR14(VMT14) vs_top=base ; return(VMT14);
static object LI15();
#define VMB15 register object *base=vs_top; object  V194 ,V193 ,V192 ,V191 ,V185 ,V180; object Vcs[2];
#define VMS15  register object *sup=vs_top+7;vs_top=sup;
#define VMV15 vs_reserve(7);
#define VMR15(VMT15) vs_top=base ; return(VMT15);
static object LI16();
#define VMB16 register object *base=vs_top; object  V216 ,V213 ,V204 ,V203;
#define VMS16  register object *sup=vs_top+8;vs_top=sup;
#define VMV16 vs_reserve(8);
#define VMR16(VMT16) vs_top=base ; return(VMT16);
#define VM16 8
#define VM15 7
#define VM14 4
#define VM13 0
#define VM12 2
#define VM11 2
#define VM10 6
#define VM9 0
#define VM8 4
#define VM7 0
#define VM6 2
#define VM5 2
#define VM4 6
#define VM3 1
#define VM2 1
#define VM1 0
static char * VVi[81]={
#define Cdata VV[80]
(char *)(LI1),
(char *)(LI2),
(char *)(LI3),
(char *)(L4),
(char *)(LI5),
(char *)(LI6),
(char *)(LI7),
(char *)(L8),
(char *)(LI9),
(char *)(L10),
(char *)(LI11),
(char *)(LI12),
(char *)(LI13),
(char *)(LI14),
(char *)(LI15),
(char *)(LI16)
};
#define VV ((object *)VVi)
static object  LnkTLI79() ;
static object  (*LnkLI79)() = LnkTLI79;
static object  LnkTLI78() ;
static object  (*LnkLI78)() = LnkTLI78;
static object  LnkTLI77() ;
static object  (*LnkLI77)() = LnkTLI77;
static object  LnkTLI76() ;
static object  (*LnkLI76)() = LnkTLI76;
static object  LnkTLI75() ;
static object  (*LnkLI75)() = LnkTLI75;
static object  LnkTLI73() ;
static object  (*LnkLI73)() = LnkTLI73;
static object  LnkTLI72() ;
static object  (*LnkLI72)() = LnkTLI72;
static  LnkT71() ;
static  (*Lnk71)() = LnkT71;
static  LnkT70() ;
static  (*Lnk70)() = LnkT70;
static  LnkT69() ;
static  (*Lnk69)() = LnkT69;
static object  LnkTLI68() ;
static object  (*LnkLI68)() = LnkTLI68;
static  LnkT51() ;
static  (*Lnk51)() = LnkT51;
static  LnkT67() ;
static  (*Lnk67)() = LnkT67;
static  LnkT66() ;
static  (*Lnk66)() = LnkT66;
static object  LnkTLI65() ;
static object  (*LnkLI65)() = LnkTLI65;
static object  LnkTLI64() ;
static object  (*LnkLI64)() = LnkTLI64;
static object  LnkTLI63() ;
static object  (*LnkLI63)() = LnkTLI63;
static object  LnkTLI62() ;
static object  (*LnkLI62)() = LnkTLI62;
static object  LnkTLI61() ;
static object  (*LnkLI61)() = LnkTLI61;
static object  LnkTLI60() ;
static object  (*LnkLI60)() = LnkTLI60;
static object  LnkTLI59() ;
static object  (*LnkLI59)() = LnkTLI59;
static object  LnkTLI58() ;
static object  (*LnkLI58)() = LnkTLI58;
static  LnkT57() ;
static  (*Lnk57)() = LnkT57;
static object  LnkTLI56() ;
static object  (*LnkLI56)() = LnkTLI56;
static object  LnkTLI55() ;
static object  (*LnkLI55)() = LnkTLI55;
static object  LnkTLI54() ;
static object  (*LnkLI54)() = LnkTLI54;
static  LnkT53() ;
static  (*Lnk53)() = LnkT53;
static  LnkT52() ;
static  (*Lnk52)() = LnkT52;
static object  LnkTLI50() ;
static object  (*LnkLI50)() = LnkTLI50;
static object  LnkTLI49() ;
static object  (*LnkLI49)() = LnkTLI49;
static object  LnkTLI48() ;
static object  (*LnkLI48)() = LnkTLI48;
static object  LnkTLI47() ;
static object  (*LnkLI47)() = LnkTLI47;
static object  LnkTLI46() ;
static object  (*LnkLI46)() = LnkTLI46;
static object  LnkTLI45() ;
static object  (*LnkLI45)() = LnkTLI45;
static object  LnkTLI44() ;
static object  (*LnkLI44)() = LnkTLI44;
static object  LnkTLI43() ;
static object  (*LnkLI43)() = LnkTLI43;
