
static object LI5();
static L8();
static object LI9();
static object LI10();
static object LI11();
static object LI12();
static object LI13();
static object LI14();
static object LI15();
static object LI16();
static object LI17();
static object LI18();
static object LI19();
static object LI20();
static object LI21();
static object LI22();
static object LI23();
static object LI24();
static object LI25();
static object LI26();
static object LI27();
static object LI28();
static object LI29();
static object LI30();
static object LI31();
static object LI32();
static object LI33();
static object LI34();
static object LI35();
static object LI36();
static object LI37();
static object LI38();
static L39();
static L40();
static L43();
static object LI44();
static object LI1();
#define VMB1 register object *base=vs_top; object  V6;
#define VMS1  register object *sup=vs_top+2;vs_top=sup;
#define VMV1 vs_reserve(2);
#define VMR1(VMT1) vs_top=base ; return(VMT1);
static object LI2();
#define VMB2 register object *base=vs_top;
#define VMS2  register object *sup=vs_top+3;vs_top=sup;
#define VMV2 vs_reserve(3);
#define VMR2(VMT2) vs_top=base ; return(VMT2);
static object LI3();
#define VMB3 register object *base=vs_top;
#define VMS3  register object *sup=vs_top+1;vs_top=sup;
#define VMV3 vs_reserve(1);
#define VMR3(VMT3) vs_top=base ; return(VMT3);
static object LI4();
#define VMB4 register object *base=vs_top;
#define VMS4  register object *sup=vs_top+1;vs_top=sup;
#define VMV4 vs_reserve(1);
#define VMR4(VMT4) vs_top=base ; return(VMT4);
static object LI5();
#define VMB5 register object *base=vs_top; object Vcs[2];
#define VMS5  register object *sup=vs_top+2;vs_top=sup;
#define VMV5 vs_reserve(2);
#define VMR5(VMT5) vs_top=base ; return(VMT5);
static int LI6();
#define VMB6 register object *base=vs_top;
#define VMS6  register object *sup=vs_top+2;vs_top=sup;
#define VMV6 vs_reserve(2);
#define VMR6(VMT6) vs_top=base ; return(VMT6);
static int LI7();
#define VMB7 register object *base=vs_top;
#define VMS7  register object *sup=vs_top+2;vs_top=sup;
#define VMV7 vs_reserve(2);
#define VMR7(VMT7) vs_top=base ; return(VMT7);
#define VC8 object  V61 ,V58 ,V56 ,V55;
static object LI9();
static struct { short n,allow_other_keys;int *defaults;
	 int keys[2];} LI9key={2,0,(int *)Cstd_key_defaults,{14,13}};
#define VMB9 register object *base=vs_top; object  V72 ,V71; object Vcs[6];
#define VMS9  register object *sup=vs_top+2;vs_top=sup;
#define VMV9 vs_reserve(2);
#define VMR9(VMT9) vs_top=base ; return(VMT9);
static object LI10();
static struct { short n,allow_other_keys;int *defaults;
	 int keys[4];} LI10key={4,0,(int *)Cstd_key_defaults,{27,28,29,30}};
#define VMB10 register object *base=vs_top; object  V104 ,V98 ,V92 ,V91 ,V87 ,V86; object Vcs[10];
#define VMS10  register object *sup=vs_top+2;vs_top=sup;
#define VMV10 vs_reserve(2);
#define VMR10(VMT10) vs_top=base ; return(VMT10);
static object LI11();
static int VK11defaults[7]={-2,-2,-2,-2,-2,-2,-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[7];} LI11key={7,0,VK11defaults,{16,15,14,13,12,11,10}};
#define VMB11 register object *base=vs_top; object  V138 ,V137 ,V136 ,V134 ,V133 ,V132 ,V129 ,V120 ,V119; object Vcs[16];
#define VMS11  register object *sup=vs_top+2;vs_top=sup;
#define VMV11 vs_reserve(2);
#define VMR11(VMT11) vs_top=base ; return(VMT11);
static object LI12();
static int VK12defaults[5]={-2,-2,-2,-2,-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[5];} LI12key={5,0,VK12defaults,{16,15,14,13,10}};
#define VMB12 object  V149; object Vcs[12];
#define VMS12
#define VMV12
#define VMR12(VMT12) return(VMT12);
static object LI13();
static int VK13defaults[5]={-2,-2,-2,-2,-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[5];} LI13key={5,0,VK13defaults,{16,15,14,13,10}};
#define VMB13 object  V160; object Vcs[12];
#define VMS13
#define VMV13
#define VMR13(VMT13) return(VMT13);
static object LI14();
static int VK14defaults[7]={-2,-2,-2,-2,-2,-2,-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[7];} LI14key={7,0,VK14defaults,{16,15,14,13,12,11,10}};
#define VMB14 register object *base=vs_top; object  V213 ,V212 ,V210 ,V209 ,V204 ,V203 ,V202 ,V200 ,V199 ,V197 ,V196 ,V191 ,V190 ,V189 ,V187 ,V178 ,V177; object Vcs[16];
#define VMS14  register object *sup=vs_top+2;vs_top=sup;
#define VMV14 vs_reserve(2);
#define VMR14(VMT14) vs_top=base ; return(VMT14);
static object LI15();
static int VK15defaults[5]={-2,-2,-2,-2,-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[5];} LI15key={5,0,VK15defaults,{16,15,14,13,10}};
#define VMB15 object  V223; object Vcs[12];
#define VMS15
#define VMV15
#define VMR15(VMT15) return(VMT15);
static object LI16();
static int VK16defaults[5]={-2,-2,-2,-2,-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[5];} LI16key={5,0,VK16defaults,{16,15,14,13,10}};
#define VMB16 object  V234; object Vcs[12];
#define VMS16
#define VMV16
#define VMR16(VMT16) return(VMT16);
static object LI17();
static int VK17defaults[6]={-2,-2,-2,-2,-2,-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[6];} LI17key={6,0,VK17defaults,{16,14,13,12,11,10}};
#define VMB17 register object *base=vs_top; object  V258 ,V254 ,V250 ,V249; object Vcs[14];
#define VMS17  register object *sup=vs_top+2;vs_top=sup;
#define VMV17 vs_reserve(2);
#define VMR17(VMT17) vs_top=base ; return(VMT17);
static object LI18();
static int VK18defaults[4]={-2,-2,-2,-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[4];} LI18key={4,0,VK18defaults,{16,14,13,10}};
#define VMB18 object  V267; object Vcs[10];
#define VMS18
#define VMV18
#define VMR18(VMT18) return(VMT18);
static object LI19();
static int VK19defaults[4]={-2,-2,-2,-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[4];} LI19key={4,0,VK19defaults,{16,14,13,10}};
#define VMB19 object  V277; object Vcs[10];
#define VMS19
#define VMV19
#define VMR19(VMT19) return(VMT19);
static object LI20();
static int VK20defaults[7]={-2,-2,-2,-2,-2,-2,-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[7];} LI20key={7,0,VK20defaults,{16,15,14,13,12,11,10}};
#define VMB20 register object *base=vs_top; object  V303 ,V299 ,V294 ,V293; object Vcs[16];
#define VMS20  register object *sup=vs_top+2;vs_top=sup;
#define VMV20 vs_reserve(2);
#define VMR20(VMT20) vs_top=base ; return(VMT20);
static object LI21();
static int VK21defaults[5]={-2,-2,-2,-2,-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[5];} LI21key={5,0,VK21defaults,{16,15,14,13,10}};
#define VMB21 object  V313; object Vcs[12];
#define VMS21
#define VMV21
#define VMR21(VMT21) return(VMT21);
static object LI22();
static int VK22defaults[5]={-2,-2,-2,-2,-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[5];} LI22key={5,0,VK22defaults,{16,15,14,13,10}};
#define VMB22 object  V324; object Vcs[12];
#define VMS22
#define VMV22
#define VMR22(VMT22) return(VMT22);
static object LI23();
static int VK23defaults[7]={-2,-2,-2,-2,-2,-2,-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[7];} LI23key={7,0,VK23defaults,{16,15,14,13,12,11,10}};
#define VMB23 register object *base=vs_top; object  V361 ,V360 ,V358 ,V357 ,V353 ,V352 ,V350 ,V349 ,V344 ,V343; object Vcs[17];
#define VMS23  register object *sup=vs_top+2;vs_top=sup;
#define VMV23 vs_reserve(2);
#define VMR23(VMT23) vs_top=base ; return(VMT23);
static object LI24();
static int VK24defaults[5]={-2,-2,-2,-2,-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[5];} LI24key={5,0,VK24defaults,{16,15,14,13,10}};
#define VMB24 object  V373; object Vcs[13];
#define VMS24
#define VMV24
#define VMR24(VMT24) return(VMT24);
static object LI25();
static int VK25defaults[5]={-2,-2,-2,-2,-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[5];} LI25key={5,0,VK25defaults,{16,15,14,13,10}};
#define VMB25 object  V386; object Vcs[13];
#define VMS25
#define VMV25
#define VMR25(VMT25) return(VMT25);
static object LI26();
static int VK26defaults[7]={-2,-2,-2,-2,-2,-2,-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[7];} LI26key={7,0,VK26defaults,{16,15,14,13,12,11,10}};
#define VMB26 register object *base=vs_top; object  V414 ,V410 ,V405 ,V404; object Vcs[17];
#define VMS26  register object *sup=vs_top+2;vs_top=sup;
#define VMV26 vs_reserve(2);
#define VMR26(VMT26) vs_top=base ; return(VMT26);
static object LI27();
static int VK27defaults[5]={-2,-2,-2,-2,-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[5];} LI27key={5,0,VK27defaults,{16,15,14,13,10}};
#define VMB27 object  V426; object Vcs[13];
#define VMS27
#define VMV27
#define VMR27(VMT27) return(VMT27);
static object LI28();
static int VK28defaults[5]={-2,-2,-2,-2,-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[5];} LI28key={5,0,VK28defaults,{16,15,14,13,10}};
#define VMB28 object  V439; object Vcs[13];
#define VMS28
#define VMV28
#define VMR28(VMT28) return(VMT28);
static object LI29();
static int VK29defaults[6]={-2,-2,-2,-2,-2,-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[6];} LI29key={6,0,VK29defaults,{16,14,13,12,11,10}};
#define VMB29 register object *base=vs_top; object  V462 ,V458 ,V455 ,V454; object Vcs[14];
#define VMS29  register object *sup=vs_top+2;vs_top=sup;
#define VMV29 vs_reserve(2);
#define VMR29(VMT29) vs_top=base ; return(VMT29);
static object LI30();
static int VK30defaults[4]={-2,-2,-2,-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[4];} LI30key={4,0,VK30defaults,{16,14,13,10}};
#define VMB30 object  V472; object Vcs[10];
#define VMS30
#define VMV30
#define VMR30(VMT30) return(VMT30);
static object LI31();
static int VK31defaults[4]={-2,-2,-2,-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[4];} LI31key={4,0,VK31defaults,{16,14,13,10}};
#define VMB31 object  V482; object Vcs[10];
#define VMS31
#define VMV31
#define VMR31(VMT31) return(VMT31);
static object LI32();
static int VK32defaults[6]={-2,-2,-2,-2,-2,-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[6];} LI32key={6,0,VK32defaults,{16,14,13,12,11,10}};
#define VMB32 register object *base=vs_top; object  V505 ,V501 ,V498 ,V497; object Vcs[14];
#define VMS32  register object *sup=vs_top+2;vs_top=sup;
#define VMV32 vs_reserve(2);
#define VMR32(VMT32) vs_top=base ; return(VMT32);
static object LI33();
static int VK33defaults[4]={-2,-2,-2,-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[4];} LI33key={4,0,VK33defaults,{16,14,13,10}};
#define VMB33 object  V515; object Vcs[10];
#define VMS33
#define VMV33
#define VMR33(VMT33) return(VMT33);
static object LI34();
static int VK34defaults[4]={-2,-2,-2,-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[4];} LI34key={4,0,VK34defaults,{16,14,13,10}};
#define VMB34 object  V525; object Vcs[10];
#define VMS34
#define VMV34
#define VMR34(VMT34) return(VMT34);
static object LI35();
static int VK35defaults[6]={-2,-2,-2,-2,-2,-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[6];} LI35key={6,0,VK35defaults,{16,14,13,12,11,10}};
#define VMB35 register object *base=vs_top; object Vcs[13];
#define VMS35  register object *sup=vs_top+8;vs_top=sup;
#define VMV35 vs_reserve(8);
#define VMR35(VMT35) vs_top=base ; return(VMT35);
static object LI36();
static int VK36defaults[6]={-2,-2,-2,-2,-2,-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[6];} LI36key={6,0,VK36defaults,{16,14,13,12,11,10}};
#define VMB36 register object *base=vs_top; object  V588 ,V587 ,V586 ,V585 ,V584 ,V583 ,V582 ,V579 ,V578 ,V572 ,V571 ,V570 ,V569 ,V568 ,V567 ,V566 ,V563 ,V562 ,V556 ,V555; object Vcs[13];
#define VMS36  register object *sup=vs_top+8;vs_top=sup;
#define VMV36 vs_reserve(8);
#define VMR36(VMT36) vs_top=base ; return(VMT36);
static object LI37();
static int VK37defaults[8]={-2,-2,-2,-1,-2,-2,-2,-2};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[8];} LI37key={8,0,VK37defaults,{27,29,28,30,16,12,11,10}};
#define VMB37 register object *base=vs_top; object  V623 ,V622 ,V616 ,V615 ,V610 ,V609 ,V605 ,V604; object Vcs[18];
#define VMS37  register object *sup=vs_top+2;vs_top=sup;
#define VMV37 vs_reserve(2);
#define VMR37(VMT37) vs_top=base ; return(VMT37);
static object LI38();
static int VK38defaults[8]={-2,-2,-2,-1,-2,-2,-2,-2};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[8];} LI38key={8,0,VK38defaults,{27,29,28,30,16,12,11,10}};
#define VMB38 register object *base=vs_top; object  V658 ,V657 ,V652 ,V651 ,V646 ,V645 ,V641 ,V640; object Vcs[18];
#define VMS38  register object *sup=vs_top+2;vs_top=sup;
#define VMV38 vs_reserve(2);
#define VMR38(VMT38) vs_top=base ; return(VMT38);
#define VC39
#define VC40
static object LI42();
#define VMB41 register object *base=vs_top; object  V680 ,V679;
#define VMS41  register object *sup=vs_top+4;vs_top=sup;
#define VMV41 vs_reserve(4);
#define VMR41(VMT41) vs_top=base ; return(VMT41);
#define VC42 object  V685 ,V684;
static object LI44();
static int VK44defaults[1]={-1};
static struct { short n,allow_other_keys;int *defaults;
	 int keys[1];} LI44key={1,0,VK44defaults,{16}};
#define VMB43 register object *base=vs_top; object  V707 ,V706 ,V705 ,V704 ,V703 ,V701; object Vcs[6];
#define VMS43  register object *sup=vs_top+3;vs_top=sup;
#define VMV43 vs_reserve(3);
#define VMR43(VMT43) vs_top=base ; return(VMT43);
static L41();
#define VC44
#define VM44 3
#define VM43 3
#define VM42 8
#define VM41 4
#define VM40 4
#define VM39 7
#define VM38 2
#define VM37 2
#define VM36 8
#define VM35 8
#define VM34 0
#define VM33 0
#define VM32 2
#define VM31 0
#define VM30 0
#define VM29 2
#define VM28 0
#define VM27 0
#define VM26 2
#define VM25 0
#define VM24 0
#define VM23 2
#define VM22 0
#define VM21 0
#define VM20 2
#define VM19 0
#define VM18 0
#define VM17 2
#define VM16 0
#define VM15 0
#define VM14 2
#define VM13 0
#define VM12 0
#define VM11 2
#define VM10 2
#define VM9 2
#define VM8 12
#define VM7 2
#define VM6 2
#define VM5 2
#define VM4 1
#define VM3 1
#define VM2 3
#define VM1 2
static char * VVi[74]={
#define Cdata VV[73]
(char *)(LI1),
(char *)(LI2),
(char *)(LI3),
(char *)(LI4),
(char *)(LI5),
(char *)(LI6),
(char *)(LI7),
(char *)(L8),
(char *)(LI9),
(char *)(&LI9key),
(char *)(LI10),
(char *)(&LI10key),
(char *)(LI11),
(char *)(&LI11key),
(char *)(LI12),
(char *)(&LI12key),
(char *)(LI13),
(char *)(&LI13key),
(char *)(LI14),
(char *)(&LI14key),
(char *)(LI15),
(char *)(&LI15key),
(char *)(LI16),
(char *)(&LI16key),
(char *)(LI17),
(char *)(&LI17key),
(char *)(LI18),
(char *)(&LI18key),
(char *)(LI19),
(char *)(&LI19key),
(char *)(LI20),
(char *)(&LI20key),
(char *)(LI21),
(char *)(&LI21key),
(char *)(LI22),
(char *)(&LI22key),
(char *)(LI23),
(char *)(&LI23key),
(char *)(LI24),
(char *)(&LI24key),
(char *)(LI25),
(char *)(&LI25key),
(char *)(LI26),
(char *)(&LI26key),
(char *)(LI27),
(char *)(&LI27key),
(char *)(LI28),
(char *)(&LI28key),
(char *)(LI29),
(char *)(&LI29key),
(char *)(LI30),
(char *)(&LI30key),
(char *)(LI31),
(char *)(&LI31key),
(char *)(LI32),
(char *)(&LI32key),
(char *)(LI33),
(char *)(&LI33key),
(char *)(LI34),
(char *)(&LI34key),
(char *)(LI35),
(char *)(&LI35key),
(char *)(LI36),
(char *)(&LI36key),
(char *)(LI37),
(char *)(&LI37key),
(char *)(LI38),
(char *)(&LI38key),
(char *)(L39),
(char *)(L40),
(char *)(LI42),
(char *)(L43),
(char *)(LI44),
(char *)(&LI44key)
};
#define VV ((object *)VVi)
static object  LnkTLI52() ;
static object  (*LnkLI52)() = LnkTLI52;
static  LnkT51() ;
static  (*Lnk51)() = LnkT51;
static object  LnkTLI50() ;
static object  (*LnkLI50)() = LnkTLI50;
static  LnkT49() ;
static  (*Lnk49)() = LnkT49;
static  LnkT48() ;
static  (*Lnk48)() = LnkT48;
static object  LnkTLI47() ;
static object  (*LnkLI47)() = LnkTLI47;
static  LnkT46() ;
static  (*Lnk46)() = LnkT46;
static object  LnkTLI45() ;
static object  (*LnkLI45)() = LnkTLI45;
static object  LnkTLI44() ;
static object  (*LnkLI44)() = LnkTLI44;
static object  LnkTLI43() ;
static object  (*LnkLI43)() = LnkTLI43;
static object  LnkTLI42() ;
static object  (*LnkLI42)() = LnkTLI42;
static object  LnkTLI41() ;
static object  (*LnkLI41)() = LnkTLI41;
static object  LnkTLI40() ;
static object  (*LnkLI40)() = LnkTLI40;
static object  LnkTLI39() ;
static object  (*LnkLI39)() = LnkTLI39;
static object  LnkTLI38() ;
static object  (*LnkLI38)() = LnkTLI38;
static object  LnkTLI36() ;
static object  (*LnkLI36)() = LnkTLI36;
static object  LnkTLI35() ;
static object  (*LnkLI35)() = LnkTLI35;
static object  LnkTLI34() ;
static object  (*LnkLI34)() = LnkTLI34;
static  LnkT33() ;
static  (*Lnk33)() = LnkT33;
static object  LnkTLI32() ;
static object  (*LnkLI32)() = LnkTLI32;
static int  LnkTLI26() ;
static int  (*LnkLI26)() = LnkTLI26;
static int  LnkTLI25() ;
static int  (*LnkLI25)() = LnkTLI25;
static  LnkT23() ;
static  (*Lnk23)() = LnkT23;
static object  LnkTLI22() ;
static object  (*LnkLI22)() = LnkTLI22;
static  LnkT21() ;
static  (*Lnk21)() = LnkT21;
static  LnkT20() ;
static  (*Lnk20)() = LnkT20;
static  LnkT19() ;
static  (*Lnk19)() = LnkT19;
static  LnkT18() ;
static  (*Lnk18)() = LnkT18;
static  LnkT17() ;
static  (*Lnk17)() = LnkT17;
