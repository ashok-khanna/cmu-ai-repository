
#include <cmpinclude.h>
#include "cmpeval.h"
init_cmpeval(){do_init(VV);}
/*	local entry for function C1EXPR*	*/

static object LI1(V3,V4)

register object V3;object V4;
{	 VMB1 VMS1 VMV1
TTL:;
	V3= (*(LnkLI123))((V3));
	(void)((*(LnkLI124))((V4),cadr((V3))));
	{object V5 = (V3);
	VMR1(V5)}
}
/*	local entry for function C1EXPR	*/

static object LI2(V7)

VOL object V7;
{	 VMB2 VMS2 VMV2
TTL:;
	frs_push(FRS_CATCH,VV[0]);
	if(nlj_active)
	{nlj_active=FALSE;frs_pop();
	vs_top=sup;
	V7= vs_base[0];
	goto T5;}
	else{
	if(!(type_of((V7))==t_symbol)){
	goto T8;}
	if(!(((V7))==(Cnil))){
	goto T11;}
	V8= (*(LnkLI125))();
	frs_pop();
	V7= V8;
	goto T5;
T11:;
	if(!(((V7))==(Ct))){
	goto T14;}
	V9= (*(LnkLI126))();
	frs_pop();
	V7= V9;
	goto T5;
T14:;
	if(!((type_of((V7))==t_symbol&&((V7))->s.s_hpack==keyword_package))){
	goto T17;}
	V10= (*(LnkLI128))((V7));
	V11= (VFUN_NARGS=2,(*(LnkLI127))(VV[2],/* INLINE-ARGS */V10));
	V12= list(3,VV[1],/* INLINE-ARGS */V11,list(2,VV[3],(*(LnkLI129))((V7))));
	frs_pop();
	V7= V12;
	goto T5;
T17:;
	base[0]= (V7);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk130)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T20;}
	{object V13;
	base[0]= (V7);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk131)();
	vs_top=sup;
	V13= vs_base[0];{object V14;
	V14= (*(LnkLI132))((V13),Cnil);
	if(V14==Cnil)goto T25;
	frs_pop();
	V7= V14;
	goto T5;
T25:;}
	V15= (*(LnkLI128))((V13));
	V16= (VFUN_NARGS=2,(*(LnkLI127))(VV[2],/* INLINE-ARGS */V15));
	V17= list(3,VV[1],/* INLINE-ARGS */V16,list(2,VV[3],(*(LnkLI133))((V7))));
	frs_pop();
	V7= V17;
	goto T5;}
T20:;
	V18= (*(LnkLI134))((V7));
	frs_pop();
	V7= V18;
	goto T5;
T8:;
	if(!(type_of((V7))==t_cons)){
	goto T28;}
	{register object V19;
	V19= car((V7));
	if(!(type_of((V19))==t_symbol)){
	goto T32;}
	base[0]= (V19);
	base[1]= cdr((V7));
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk135)();
	vs_top=sup;
	frs_pop();
	V7= vs_base[0];
	goto T5;
T32:;
	if(!(type_of((V19))==t_cons)){
	goto T37;}
	if(!((car((V19)))==(VV[4]))){
	goto T37;}
	V20= (*(LnkLI136))(cdr((V19)),cdr((V7)));
	frs_pop();
	V7= V20;
	goto T5;
T37:;
	if(!(type_of((V19))==t_cons)){
	goto T42;}
	if(!((car((V19)))==(VV[5]))){
	goto T42;}
	V21= (VFUN_NARGS=1,(*(LnkLI137))(VV[6]));
	frs_pop();
	V7= V21;
	goto T5;
T42:;
	V22= (VFUN_NARGS=2,(*(LnkLI137))(VV[7],(V19)));
	frs_pop();
	V7= V22;
	goto T5;}
T28:;
	V23= (*(LnkLI132))((V7),Ct);
	frs_pop();
	V7= V23;}
T5:;
	if(!(((V7))==(VV[8]))){
	goto T47;}
	{object V24 = (*(LnkLI125))();
	VMR2(V24)}
T47:;
	{object V25 = (V7);
	VMR2(V25)}
}
/*	local entry for function C1SHARP-COMMA	*/

static object LI3(V27)

object V27;
{	 VMB3 VMS3 VMV3
TTL:;
	V28= make_cons(VV[5],(V27));
	{object V29 = (*(LnkLI132))(/* INLINE-ARGS */V28,Ct);
	VMR3(V29)}
}
/*	local entry for function C1DEFINE-STRUCTURE	*/

static object LI4(V31)

object V31;
{	 VMB4 VMS4 VMV4
	bds_check;
TTL:;
	bds_bind(VV[9],Cnil);
	base[1]= make_cons(VV[10],(V31));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk138)();
	vs_top=sup;
	V32= listA(3,VV[5],VV[10],(V31));
	(void)((*(LnkLI132))(/* INLINE-ARGS */V32,Ct));
	(void)((*(LnkLI139))());
	{object V33 = Cnil;
	bds_unwind1;
	VMR4(V33)}
}
/*	local entry for function C1NIL	*/

static object LI5()

{	 VMB5 VMS5 VMV5
TTL:;
	{object V34 = symbol_value(VV[11]);
	VMR5(V34)}
}
/*	local entry for function C1T	*/

static object LI6()

{	 VMB6 VMS6 VMV6
TTL:;
	{object V35 = symbol_value(VV[12]);
	VMR6(V35)}
}
/*	function definition for FLAGS-POS	*/

static L7()
{register object *base=vs_base;
	register object *sup=base+VM7; VC7
	vs_reserve(VM7);
	{register object V36;
	check_arg(1);
	V36=(base[0]);
	vs_top=sup;
TTL:;
	{register int V37;
	V37= 0;
	{register object V38;
	register object V39;
	V38= VV[13];
	V39= car((V38));
T58:;
	if(!(endp((V38)))){
	goto T59;}
	goto T54;
T59:;
	{register object x= (V36),V40= (V39);
	while(!endp(V40))
	if(x==(V40->c.c_car)){
	goto T65;
	}else V40=V40->c.c_cdr;
	goto T63;}
T65:;
	base[2]= make_fixnum(V37);
	vs_top=(vs_base=base+2)+1;
	return;
T63:;
	V37= (V37)+(1);
	V38= cdr((V38));
	V39= car((V38));
	goto T58;}
T54:;
	base[1]= VV[14];
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk140)();
	return;}
	}
}
/*	macro definition for FLAG-P	*/

static L8()
{register object *base=vs_base;
	register object *sup=base+VM8; VC8
	vs_reserve(VM8);
	check_arg(2);
	vs_top=sup;
	{object V41=base[0]->c.c_cdr;
	if(endp(V41))invalid_macro_call();
	base[2]= (V41->c.c_car);
	V41=V41->c.c_cdr;
	if(endp(V41))invalid_macro_call();
	base[3]= (V41->c.c_car);
	V41=V41->c.c_cdr;
	if(!endp(V41))invalid_macro_call();}
	base[4]= base[3];
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk141)();
	vs_top=sup;
	V42= vs_base[0];
	base[4]= list(3,VV[15],V42,base[2]);
	vs_top=(vs_base=base+4)+1;
	return;
}
/*	function definition for FIX-OPT	*/

static L9()
{register object *base=vs_base;
	register object *sup=base+VM9; VC9
	vs_reserve(VM9);
	{register object V43;
	check_arg(1);
	V43=(base[0]);
	vs_top=sup;
TTL:;
	{register object V44;
	V44= cddr((V43));
	if(type_of(car((V44)))==t_fixnum){
	goto T77;}
	if((symbol_value(VV[16]))==Cnil){
	goto T80;}
	(void)((VFUN_NARGS=2,(*(LnkLI142))(VV[17],(V43))));
T80:;
	{object V46;
	if((car((V44)))==Cnil){
	goto T87;}
	base[2]= small_fixnum(2);
	goto T85;
T87:;
	base[2]= small_fixnum(0);
T85:;
	if((cadr((V44)))==Cnil){
	goto T91;}
	base[3]= small_fixnum(1);
	goto T89;
T91:;
	base[3]= small_fixnum(0);
T89:;
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk143)();
	vs_top=sup;
	V47= vs_base[0];
	V46= make_cons(V47,cddr((V44)));
	if(type_of(cdr(V43))!=t_cons)FEwrong_type_argument(Scons,cdr(V43));
	(cdr(V43))->c.c_cdr = (V46);
	(void)(cdr(V43));}
T77:;
	base[1]= (V43);
	vs_top=(vs_base=base+1)+1;
	return;}
	}
}
/*	function definition for RESULT-TYPE-FROM-ARGS	*/

static L10()
{register object *base=vs_base;
	register object *sup=base+VM10; VC10
	vs_reserve(VM10);
	{object V48;
	register object V49;
	check_arg(2);
	V48=(base[0]);
	V49=(base[1]);
	vs_top=sup;
TTL:;
	{object V50;
	V50= Cnil;
	V50= get((V48),VV[18],Cnil);
	if(((V50))==Cnil){
	goto T96;}
	if(((V50))==(VV[19])){
	goto T96;}
	if(type_of((V50))==t_cons){
	goto T96;}
	{register object V51;
	object V52;
	V51= VV[20];
	V52= car((V51));
T106:;
	if(!(endp((V51)))){
	goto T107;}
	base[3]= Cnil;
	vs_top=(vs_base=base+3)+1;
	return;
T107:;
	{register object V53;
	register object V54;
	V53= get((V48),(V52),Cnil);
	V54= car((V53));
T115:;
	if(!(endp((V53)))){
	goto T116;}
	goto T111;
T116:;
	base[5]= (V54);
	vs_top=(vs_base=base+5)+1;
	(void) (*Lnk144)();
	vs_top=sup;
	base[5]= small_fixnum(3);
	base[6]= caddr((V54));
	vs_top=(vs_base=base+5)+2;
	(void) (*Lnk15)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T122;}
	if(!((length((V49)))==(length(car((V54)))))){
	goto T122;}
	{register object V55;
	register object V56;
	V56= car((V54));
	V55= (V49);
T133:;
	if(((V55))!=Cnil){
	goto T134;}
	goto T130;
T134:;
	if((car((V55)))==(car((V56)))){
	goto T138;}
	if(((*(LnkLI145))(car((V56)),car((V55))))!=Cnil){
	goto T138;}
	goto T122;
T138:;
	V55= cdr((V55));
	V56= cdr((V56));
	goto T133;}
T130:;
	base[5]= cadr((V54));
	vs_top=(vs_base=base+5)+1;
	return;
T122:;
	V53= cdr((V53));
	V54= car((V53));
	goto T115;}
T111:;
	V51= cdr((V51));
	V52= car((V51));
	goto T106;}
T96:;
	base[2]= Cnil;
	vs_top=(vs_base=base+2)+1;
	return;}
	}
}
/*	macro definition for FLAGS	*/

static L11()
{register object *base=vs_base;
	register object *sup=base+VM11; VC11
	vs_reserve(VM11);
	check_arg(2);
	vs_top=sup;
	{object V57=base[0]->c.c_cdr;
	base[2]= V57;
	base[3]= small_fixnum(0);}
	{register object V58;
	register object V59;
	V58= base[2];
	V59= car((V58));
T162:;
	if(!(endp((V58)))){
	goto T163;}
	goto T158;
T163:;
	base[5]= base[3];
	base[7]= small_fixnum(1);
	base[9]= (V59);
	vs_top=(vs_base=base+9)+1;
	(void) (*Lnk141)();
	vs_top=sup;
	base[8]= vs_base[0];
	vs_top=(vs_base=base+7)+2;
	(void) (*Lnk146)();
	vs_top=sup;
	base[6]= vs_base[0];
	vs_top=(vs_base=base+5)+2;
	(void) (*Lnk143)();
	vs_top=sup;
	base[3]= vs_base[0];
	V58= cdr((V58));
	V59= car((V58));
	goto T162;}
T158:;
	vs_top=(vs_base=base+3)+1;
	return;
}
/*	function definition for C1SYMBOL-FUN	*/

static L12()
{register object *base=vs_base;
	register object *sup=base+VM12; VC12
	vs_reserve(VM12);
	{object V60;
	register object V61;
	check_arg(2);
	V60=(base[0]);
	V61=(base[1]);
	vs_top=sup;
TTL:;
	{object V62;
	V62= Cnil;
	V62= get((V60),VV[21],Cnil);
	if(((V62))==Cnil){
	goto T181;}
	base[2]= (V61);
	vs_top=(vs_base=base+2)+1;
	super_funcall_no_event((V62));
	return;
T181:;
	{object V63;
	V62= get((V60),VV[22],Cnil);
	if(((V62))!=Cnil){
	goto T186;}
	V63= Cnil;
	goto T185;
T186:;
	V63= (
	(type_of((V62)) == t_sfun ?(*(object (*)())(((V62))->sfn.sfn_self)):
	(fcall.fun=((V62)),fcall.argd=2,fcalln))((V60),(V61)));
T185:;
	if(((V63))==Cnil){
	goto T190;}
	base[2]= (V63);
	vs_top=(vs_base=base+2)+1;
	return;
T190:;
	V62= (*(LnkLI147))((V60));
	if(((V62))==Cnil){
	goto T193;}
	if(!((car((V62)))==(VV[23]))){
	goto T197;}
	{object V64;
	object V65;
	V64= (VFUN_NARGS=2,(*(LnkLI127))(VV[24],Ct));
	V65= (*(LnkLI148))((V61),(V64));
	{object V66;
	V66= (*(LnkLI149))(caddr((V62)));
	if(((V66))==Cnil){
	goto T201;}
	(void)(structure_set((V64),VV[25],2,(V66)));}
T201:;
	{register object V67;
	V67= (*(LnkLI150))(caddr((V62)));
	if(((V67))==Cnil){
	goto T205;}
	{object V68;
	V68= Cnil;
	{object V69;
	object V70;
	V69= (V65);
	V70= car((V69));
T213:;
	if(!(endp((V69)))){
	goto T214;}
	goto T209;
T214:;
	if(!(endp((V67)))){
	goto T220;}
	V68= make_cons((V70),(V68));
	goto T218;
T220:;
	V71= (*(LnkLI151))(car((V67)),(V70),car((V61)));
	V68= make_cons(/* INLINE-ARGS */V71,(V68));
	{object V72;
	V72= car((V67));
	V67= cdr((V67));}
	{object V73;
	V73= car((V61));
	V61= cdr((V61));}
T218:;
	V69= cdr((V69));
	V70= car((V69));
	goto T213;}
T209:;
	V65= reverse((V68));}}
T205:;
	base[4]= list(4,VV[23],(V64),cddr((V62)),(V65));
	vs_top=(vs_base=base+4)+1;
	return;}
T197:;
	V74= (*(LnkLI152))((V62),(V60),(V61));
	base[2]= (*(LnkLI123))(/* INLINE-ARGS */V74);
	vs_top=(vs_base=base+2)+1;
	return;
T193:;
	{object V75;
	V62= get((V60),VV[26],Cnil);
	if(((V62))!=Cnil){
	goto T239;}
	V75= Cnil;
	goto T238;
T239:;
	if(((*(LnkLI153))((V60)))!=Cnil){
	goto T242;}
	V75= Cnil;
	goto T238;
T242:;
	V75= (
	(type_of((V62)) == t_sfun ?(*(object (*)())(((V62))->sfn.sfn_self)):
	(fcall.fun=((V62)),fcall.argd=2,fcalln))((V60),(V61)));
T238:;
	if(((V75))==Cnil){
	goto T245;}
	base[2]= (V75);
	vs_top=(vs_base=base+2)+1;
	return;
T245:;
	V62= get((V60),VV[27],Cnil);
	if(((V62))==Cnil){
	goto T248;}
	if(((*(LnkLI153))((V60)))==Cnil){
	goto T248;}
	base[2]= (V61);
	vs_top=(vs_base=base+2)+1;
	super_funcall_no_event((V62));
	return;
T248:;
	V62= get((V60),VV[28],Cnil);
	if(((V62))==Cnil){
	goto T255;}
	if(((*(LnkLI153))((V60)))==Cnil){
	goto T255;}
	base[2]= car((V62));
	base[3]= (V61);
	vs_top=(vs_base=base+3)+1;
	super_funcall_no_event(base[2]);
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T255;}
	base[2]= cdr((V62));
	base[3]= (V61);
	vs_top=(vs_base=base+3)+1;
	super_funcall_no_event(base[2]);
	return;
T255:;
	{object V76;
	base[3]= (V60);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk154)();
	vs_top=sup;
	base[2]= vs_base[0];
	base[4]= VV[29];
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk154)();
	vs_top=sup;
	base[3]= vs_base[0];
	vs_top=(vs_base=base+2)+2;
	(void) (*Lnk155)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T268;}
	goto T267;
T268:;
	base[3]= (V60);
	vs_top=(vs_base=base+3)+1;
	(void) (*Lnk156)();
	vs_top=sup;
	base[2]= vs_base[0];
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk157)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T274;}
	goto T267;
T274:;
	(void)((VFUN_NARGS=2,(*(LnkLI142))(VV[30],(V60))));
T267:;
	if(symbol_value(VV[31])==Cnil){
	goto T278;}
	(void)((*(LnkLI32))(VV[32],(V60)));
T278:;
	V76= Cnil;
	if(((V76))==Cnil){
	goto T280;}
	base[2]= (V76);
	vs_top=(vs_base=base+2)+1;
	return;
T280:;
	base[2]= (V60);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk158)();
	vs_top=sup;
	V62= vs_base[0];
	if(((V62))==Cnil){
	goto T283;}
	V77= (*(LnkLI152))((V62),(V60),(V61));
	base[2]= (*(LnkLI123))(/* INLINE-ARGS */V77);
	vs_top=(vs_base=base+2)+1;
	return;
T283:;
	V62= get((V60),VV[33],Cnil);
	if(((V62))==Cnil){
	goto T288;}
	V79= list(2,VV[35],(V62));
	base[2]= list(4,VV[34],/* INLINE-ARGS */V79,list(2,VV[35],make_cons((V60),(V61))),Cnil);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk159)();
	vs_top=sup;
	V78= vs_base[0];
	base[2]= (*(LnkLI123))(V78);
	vs_top=(vs_base=base+2)+1;
	return;
T288:;
	V62= get((V60),VV[36],Cnil);
	if(((V62))==Cnil){
	goto T294;}
	if(((*(LnkLI153))((V60)))==Cnil){
	goto T294;}
	if(!(type_of((V62))==t_cons)){
	goto T294;}
	if(!(type_of(cdr((V62)))==t_fixnum)){
	goto T294;}
	if(endp((V61))){
	goto T294;}
	if(!(endp(cdr((V61))))){
	goto T294;}
	{object V80= car((V62));
	if((V80!= VV[46]))goto T307;
	V81= list(3,VV[37],car((V61)),cdr((V62)));
	base[2]= (*(LnkLI123))(/* INLINE-ARGS */V81);
	vs_top=(vs_base=base+2)+1;
	return;
T307:;
	if((V80!= VV[113]))goto T308;
	V82= list(3,VV[38],cdr((V62)),car((V61)));
	base[2]= (*(LnkLI123))(/* INLINE-ARGS */V82);
	vs_top=(vs_base=base+2)+1;
	return;
T308:;
	base[2]= (*(LnkLI160))(car((V61)),car((V62)),cdr((V62)));
	vs_top=(vs_base=base+2)+1;
	return;}
T294:;
	if(!(((V60))==(VV[5]))){
	goto T310;}
	base[2]= (VFUN_NARGS=1,(*(LnkLI137))(VV[39]));
	vs_top=(vs_base=base+2)+1;
	return;
T310:;
	{object V83;
	object V84;
	base[4]= get((V60),VV[40],Cnil);
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk161)();
	vs_top=sup;
	V85= vs_base[0];
	V83= (VFUN_NARGS=2,(*(LnkLI127))(VV[24],V85));
	V84= (*(LnkLI148))((V61),(V83));
	{object V86;
	V86= (*(LnkLI162))((V60));
	if(((V86))==Cnil){
	goto T316;}
	if(!(equal((V86),VV[41]))){
	goto T321;}
	V86= Cnil;
	goto T316;
T321:;
	(void)(structure_set((V83),VV[25],2,(V86)));}
T316:;
	{register object V87;
	V87= (*(LnkLI163))((V60));
	if(((V87))==Cnil){
	goto T324;}
	{register object V88;
	register object V89;
	object V90;
	V88= (V84);
	V89= Cnil;
	V90= (V61);
T329:;
	if(!(endp((V88)))){
	goto T330;}
	V84= reverse((V89));
	goto T324;
T330:;
	if(!(endp((V87)))){
	goto T337;}
	V89= make_cons(car((V88)),(V89));
	goto T335;
T337:;
	V91= (*(LnkLI151))(car((V87)),car((V88)),car((V90)));
	V89= make_cons(/* INLINE-ARGS */V91,(V89));
	{object V92;
	V92= car((V87));
	V87= cdr((V87));}
T335:;
	V88= cdr((V88));
	V90= cdr((V90));
	goto T329;}}
T324:;
	{register object V93;
	V93= get((V60),VV[42],Cnil);
	if(((V93))==Cnil){
	goto T349;}
	{object V94;
	object V95;
	V94= (V84);
	V95= (V61);
T354:;
	if(endp((V93))){
	goto T356;}
	if(!(endp((V94)))){
	goto T355;}
T356:;
	goto T349;
T355:;
	(void)((*(LnkLI164))(car((V93)),car((V94)),car((V95))));
	{object V96;
	V96= car((V93));
	V93= cdr((V93));}
	V94= cdr((V94));
	V95= cdr((V95));
	goto T354;}}
T349:;
	{object V97= (V60);
	if((V97!= VV[165]))goto T371;
	{object V98;
	V98= structure_ref(cadar((V84)),VV[25],2);
	if(!(((V98))==(VV[43]))){
	goto T374;}
	V98= VV[44];
	if((VV[44])!=Cnil){
	goto T373;}
T374:;
	if(!(type_of((V98))==t_cons)){
	goto T370;}
	if((car((V98)))==(VV[45])){
	goto T381;}
	if(!((car((V98)))==(VV[46]))){
	goto T370;}
T381:;
	V98= cadr((V98));
	if(((V98))==Cnil){
	goto T370;}
T373:;
	V99= structure_ref((V83),VV[25],2);
	V98= (*(LnkLI166))(/* INLINE-ARGS */V99,(V98));
	if(((V98))!=Cnil){
	goto T389;}
	V100= make_cons((V60),(V61));
	(void)((VFUN_NARGS=2,(*(LnkLI142))(VV[47],/* INLINE-ARGS */V100)));
T389:;
	(void)(structure_set((V83),VV[25],2,(V98)));
	goto T370;}
T371:;
	if((V97!= VV[167]))goto T392;
	{object V101;
	V101= structure_ref(cadar((V84)),VV[25],2);
	if(!(((V101))==(VV[43]))){
	goto T395;}
	V101= VV[44];
	if((VV[44])!=Cnil){
	goto T394;}
T395:;
	if(!(type_of((V101))==t_cons)){
	goto T370;}
	if((car((V101)))==(VV[45])){
	goto T402;}
	if(!((car((V101)))==(VV[46]))){
	goto T370;}
T402:;
	V101= cadr((V101));
	if(((V101))==Cnil){
	goto T370;}
T394:;
	V102= structure_ref((V83),VV[25],2);
	base[4]= (V84);
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk168)();
	vs_top=sup;
	V103= vs_base[0];
	V104= structure_ref(cadar(V103),VV[25],2);
	V105= (*(LnkLI166))(/* INLINE-ARGS */V104,(V101));
	V101= (*(LnkLI166))(/* INLINE-ARGS */V102,/* INLINE-ARGS */V105);
	if(((V101))!=Cnil){
	goto T412;}
	V106= make_cons((V60),(V61));
	(void)((VFUN_NARGS=2,(*(LnkLI142))(VV[48],/* INLINE-ARGS */V106)));
T412:;
	(void)(structure_set((V83),VV[25],2,(V101)));
	base[4]= (V84);
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk168)();
	vs_top=sup;
	V107= vs_base[0];
	(void)(structure_set(cadar(V107),VV[25],2,(V101)));
	goto T370;}
T392:;}
T370:;
	{object V108;
	base[4]= (V60);
	{object V109;
	object V110= (V84);
	if(endp(V110)){
	base[5]= Cnil;
	goto T421;}
	base[6]=V109=MMcons(Cnil,Cnil);
T422:;
	(V109->c.c_car)= structure_ref(cadr((V110->c.c_car)),VV[25],2);
	if(endp(V110=MMcdr(V110))){
	base[5]= base[6];
	goto T421;}
	V109=MMcdr(V109)=MMcons(Cnil,Cnil);
	goto T422;}
T421:;
	vs_top=(vs_base=base+4)+2;
	(void) (*Lnk169)();
	vs_top=sup;
	V108= vs_base[0];
	if(((V108))==Cnil){
	goto T418;}
	V112= structure_ref((V83),VV[25],2);
	V108= (*(LnkLI166))((V108),/* INLINE-ARGS */V112);
	(void)(structure_set((V83),VV[25],2,(V108)));}
T418:;
	base[4]= list(4,VV[49],(V83),(V60),(V84));
	vs_top=(vs_base=base+4)+1;
	return;}}}}}
	}
}
/*	local entry for function REPLACE-CONSTANT	*/

static object LI13(V114)

object V114;
{	 VMB13 VMS13 VMV13
TTL:;
	{register object V115;
	register object V116;
	V115= Cnil;
	V116= Cnil;
	{register object V117;
	V117= (V114);
T431:;
	if(((V117))!=Cnil){
	goto T432;}
	{object V118 = (V115);
	VMR13(V118)}
T432:;
	base[0]= car((V117));
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk130)();
	vs_top=sup;
	if((vs_base[0])==Cnil){
	goto T436;}
	base[0]= car((V117));
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk138)();
	vs_top=sup;
	V116= vs_base[0];
	if(type_of((V116))==t_fixnum||
type_of((V116))==t_bignum||
type_of((V116))==t_ratio||
type_of((V116))==t_shortfloat||
type_of((V116))==t_longfloat||
type_of((V116))==t_complex){
	goto T437;}
	if(!(type_of((V116))==t_character)){
	goto T436;}
T437:;
	V115= Ct;
	{register object V119;
	register object V120;
	V119= (V117);
	V120= (V116);
	if(type_of((V119))!=t_cons)FEwrong_type_argument(Scons,(V119));
	((V119))->c.c_car = (V120);}
T436:;
	V117= cdr((V117));
	goto T431;}}
}
/*	local entry for function C1LAMBDA-FUN	*/

static object LI14(V123,V124)

register object V123;object V124;
{	 VMB14 VMS14 VMV14
TTL:;
	{object V125;
	V125= (VFUN_NARGS=2,(*(LnkLI127))(VV[24],Ct));
	V124= (*(LnkLI148))((V124),(V125));
	V123= (VFUN_NARGS=1,(*(LnkLI170))((V123)));
	(void)((*(LnkLI124))((V125),cadr((V123))));
	{object V126 = list(4,VV[50],(V125),(V123),(V124));
	VMR14(V126)}}
}
/*	function definition for C2EXPR	*/

static L15()
{register object *base=vs_base;
	register object *sup=base+VM15; VC15
	vs_reserve(VM15);
	bds_check;
	{register object V127;
	check_arg(1);
	V127=(base[0]);
	vs_top=sup;
TTL:;
	if(!((car((V127)))==(VV[49]))){
	goto T461;}
	V128= caddr((V127));
	V129= cadddr((V127));
	V130= structure_ref(cadr((V127)),VV[25],2);
	base[1]= (*(LnkLI171))(/* INLINE-ARGS */V128,/* INLINE-ARGS */V129,Cnil,/* INLINE-ARGS */V130);
	vs_top=(vs_base=base+1)+1;
	return;
T461:;
	if((car((V127)))==(VV[51])){
	goto T463;}
	if(!((car((V127)))==(VV[52]))){
	goto T464;}
T463:;
	base[1]= (*(LnkLI172))(cadr((V127)));
	bds_bind(VV[53],base[1]);
	base[2]= get(car((V127)),VV[54],Cnil);
	{object V131;
	V131= cddr((V127));
	 vs_top=base+3;
	 while(!endp(V131))
	 {vs_push(car(V131));V131=cdr(V131);}
	vs_base=base+3;}
	super_funcall_no_event(base[2]);
	bds_unwind1;
	return;
T464:;
	{register object V132;
	V132= get(car((V127)),VV[54],Cnil);
	if(((V132))==Cnil){
	goto T473;}
	base[1]= (V132);
	{object V133;
	V133= cddr((V127));
	 vs_top=base+2;
	 while(!endp(V133))
	 {vs_push(car(V133));V133=cdr(V133);}
	vs_base=base+2;}
	super_funcall_no_event(base[1]);
	return;
T473:;
	V132= get(car((V127)),VV[55],Cnil);
	if(((V132))==Cnil){
	goto T478;}
	base[1]= (V127);
	vs_top=(vs_base=base+1)+1;
	super_funcall_no_event((V132));
	return;
T478:;
	base[1]= (*(LnkLI173))();
	vs_top=(vs_base=base+1)+1;
	return;}
	}
}
/*	local entry for function C2FUNCALL-SFUN	*/

static object LI16(V137,V138,V139)

object V137;object V138;object V139;
{	 VMB16 VMS16 VMV16
	bds_check;
TTL:;
	{object V140;
	object V141;
	V140= Cnil;
	V141= make_cons((V137),(V138));
	bds_bind(VV[56],small_fixnum(0));
	base[2]= make_fixnum(length((V141)));
	base[3]= VV[57];
	base[4]= Ct;
	vs_top=(vs_base=base+2)+3;
	(void) (*Lnk175)();
	vs_top=sup;
	V142= vs_base[0];
	V143= list(4,V142,Ct,small_fixnum(3),VV[58]);
	V140= (*(LnkLI174))(/* INLINE-ARGS */V143,(V141));
	(void)((VFUN_NARGS=1,(*(LnkLI176))((V140))));
	{object V144 = (*(LnkLI177))();
	bds_unwind1;
	VMR16(V144)}}
}
/*	local entry for function C2EXPR*	*/

static object LI17(V146)

object V146;
{	 VMB17 VMS17 VMV17
	bds_check;
TTL:;
	setq(VV[60],number_plus(symbol_value(VV[60]),small_fixnum(1)));
	bds_bind(VV[59],make_cons(symbol_value(VV[60]),Cnil));
	bds_bind(VV[61],make_cons((VV[59]->s.s_dbind),symbol_value(VV[61])));
	base[2]= (V146);
	vs_top=(vs_base=base+2)+1;
	(void) (*Lnk178)();
	vs_top=sup;
	if((cdr((VV[59]->s.s_dbind)))==Cnil){
	goto T498;}
	princ_str("\nT",VV[62]);
	(void)((*(LnkLI179))(car((VV[59]->s.s_dbind))));
	princ_str(":;",VV[62]);
	{object V147 = Cnil;
	bds_unwind1;
	bds_unwind1;
	VMR17(V147)}
T498:;
	{object V148 = Cnil;
	bds_unwind1;
	bds_unwind1;
	VMR17(V148)}
}
/*	local entry for function C2EXPR-TOP	*/

static object LI18(V151,V152)

object V151;object V152;
{	 VMB18 VMS18 VMV18
	bds_check;
TTL:;
	bds_bind(VV[63],small_fixnum(0));
	bds_bind(VV[64],small_fixnum(0));
	bds_bind(VV[65],one_plus(symbol_value(VV[65])));
	setq(VV[66],number_plus(symbol_value(VV[66]),small_fixnum(1)));
	bds_bind(VV[67],symbol_value(VV[66]));
	princ_str("\n	{register object *base",VV[62]);
	V153= one_minus((VV[65]->s.s_dbind));
	(void)((*(LnkLI179))(/* INLINE-ARGS */V153));
	princ_str("=base;",VV[62]);
	setq(VV[68],Ct);
	princ_str("\n	{register object *base=V",VV[62]);
	(void)((*(LnkLI179))((V152)));
	princ_char(59,VV[62]);
	princ_str("\n	register object *sup=vs_base+VM",VV[62]);
	(void)((*(LnkLI179))((VV[67]->s.s_dbind)));
	princ_char(59,VV[62]);
	if((symbol_value(VV[69]))==Cnil){
	goto T522;}
	princ_str("\n	vs_reserve(VM",VV[62]);
	(void)((*(LnkLI179))((VV[67]->s.s_dbind)));
	princ_str(");",VV[62]);
	goto T520;
T522:;
	princ_str("\n	vs_check;",VV[62]);
T520:;
	princ_str("\n	",VV[62]);
	(void)((*(LnkLI180))());
	base[4]= (V151);
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk178)();
	vs_top=sup;
	V154= make_cons((VV[67]->s.s_dbind),(VV[64]->s.s_dbind));
	setq(VV[70],make_cons(/* INLINE-ARGS */V154,symbol_value(VV[70])));
	princ_str("\n	}}",VV[62]);
	{object V155 = Cnil;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	VMR18(V155)}
}
/*	local entry for function C2EXPR-TOP*	*/

static object LI19(V158,V159)

object V158;object V159;
{	 VMB19 VMS19 VMV19
	bds_check;
TTL:;
	setq(VV[60],number_plus(symbol_value(VV[60]),small_fixnum(1)));
	bds_bind(VV[59],make_cons(symbol_value(VV[60]),Cnil));
	bds_bind(VV[61],make_cons((VV[59]->s.s_dbind),symbol_value(VV[61])));
	(void)((*(LnkLI181))((V158),(V159)));
	if((cdr((VV[59]->s.s_dbind)))==Cnil){
	goto T540;}
	princ_str("\nT",VV[62]);
	(void)((*(LnkLI179))(car((VV[59]->s.s_dbind))));
	princ_str(":;",VV[62]);
	{object V160 = Cnil;
	bds_unwind1;
	bds_unwind1;
	VMR19(V160)}
T540:;
	{object V161 = Cnil;
	bds_unwind1;
	bds_unwind1;
	VMR19(V161)}
}
/*	local entry for function C1PROGN	*/

static object LI20(V163)

register object V163;
{	 VMB20 VMS20 VMV20
TTL:;
	{register object V164;
	V164= Cnil;
	if(!(endp((V163)))){
	goto T547;}
	{object V165 = (*(LnkLI125))();
	VMR20(V165)}
T547:;
	if(!(endp(cdr((V163))))){
	goto T550;}
	{object V166 = (*(LnkLI123))(car((V163)));
	VMR20(V166)}
T550:;
	{register object V167;
	V167= (VFUN_NARGS=0,(*(LnkLI127))());
	{register object V168;
	register object V169;
	V168= (V163);
	V169= car((V168));
T557:;
	if(!(endp((V168)))){
	goto T558;}
	goto T553;
T558:;
	V169= (*(LnkLI123))((V169));
	V164= make_cons((V169),(V164));
	(void)((*(LnkLI124))((V167),cadr((V169))));
	V168= cdr((V168));
	V169= car((V168));
	goto T557;}
T553:;
	V170= structure_ref(cadar((V164)),VV[25],2);
	(void)(structure_set((V167),VV[25],2,/* INLINE-ARGS */V170));
	{object V171 = list(3,VV[71],(V167),reverse((V164)));
	VMR20(V171)}}}
}
/*	local entry for function C1PROGN*	*/

static object LI21(V174,V175)

register object V174;object V175;
{	 VMB21 VMS21 VMV21
TTL:;
	V174= (*(LnkLI182))((V174));
	(void)((*(LnkLI124))((V175),cadr((V174))));
	{object V176 = (V174);
	VMR21(V176)}
}
/*	function definition for C2PROGN	*/

static L22()
{register object *base=vs_base;
	register object *sup=base+VM22; VC22
	vs_reserve(VM22);
	bds_check;
	{object V177;
	check_arg(1);
	V177=(base[0]);
	vs_top=sup;
TTL:;
	{register object V178;
	V178= (V177);
T577:;
	if(!(endp(cdr((V178))))){
	goto T578;}
	base[1]= car((V178));
	vs_top=(vs_base=base+1)+1;
	(void) (*Lnk178)();
	return;
T578:;
	bds_bind(VV[72],VV[73]);
	setq(VV[60],number_plus(symbol_value(VV[60]),small_fixnum(1)));
	bds_bind(VV[59],make_cons(symbol_value(VV[60]),Cnil));
	bds_bind(VV[61],make_cons((VV[59]->s.s_dbind),symbol_value(VV[61])));
	base[4]= car((V178));
	vs_top=(vs_base=base+4)+1;
	(void) (*Lnk178)();
	vs_top=sup;
	if((cdr((VV[59]->s.s_dbind)))==Cnil){
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	goto T583;}
	princ_str("\nT",VV[62]);
	(void)((*(LnkLI179))(car((VV[59]->s.s_dbind))));
	princ_str(":;",VV[62]);
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
T583:;
	V178= cdr((V178));
	goto T577;}
	}
}
/*	local entry for function C1ARGS	*/

static object LI23(V181,V182)

object V181;object V182;
{	 VMB23 VMS23 VMV23
TTL:;
	{object V183;
	object V184= (V181);
	if(endp(V184)){
	{object V185 = Cnil;
	VMR23(V185)}}
	base[0]=V183=MMcons(Cnil,Cnil);
T597:;
	(V183->c.c_car)= (*(LnkLI183))((V184->c.c_car),(V182));
	if(endp(V184=MMcdr(V184))){
	{object V187 = base[0];
	VMR23(V187)}}
	V183=MMcdr(V183)=MMcons(Cnil,Cnil);
	goto T597;}
}
/*	local entry for function C1STRUCTURE-REF	*/

static object LI24(V189)

register object V189;
{	 VMB24 VMS24 VMV24
TTL:;
	if((symbol_value(VV[69]))!=Cnil){
	goto T600;}
	if(endp((V189))){
	goto T600;}
	if(endp(cdr((V189)))){
	goto T600;}
	if(!(type_of(cadr((V189)))==t_cons)){
	goto T600;}
	if(!((caadr((V189)))==(VV[35]))){
	goto T600;}
	if(endp(cdadr((V189)))){
	goto T600;}
	if(!(type_of(cadadr((V189)))==t_symbol)){
	goto T600;}
	if(!(endp(cddadr((V189))))){
	goto T600;}
	if(endp(cddr((V189)))){
	goto T600;}
	if(!(type_of(caddr((V189)))==t_fixnum)){
	goto T600;}
	if(!(endp(cdddr((V189))))){
	goto T600;}
	{object V190 = (*(LnkLI160))(car((V189)),cadadr((V189)),caddr((V189)));
	VMR24(V190)}
T600:;
	{object V191;
	V191= (VFUN_NARGS=0,(*(LnkLI127))());
	{object V192 = list(4,VV[49],(V191),VV[74],(*(LnkLI148))((V189),(V191)));
	VMR24(V192)}}
}
/*	local entry for function C1STRUCTURE-REF1	*/

static object LI25(V196,V197,V198)

object V196;object V197;object V198;
{	 VMB25 VMS25 VMV25
TTL:;
	{object V199;
	V199= (VFUN_NARGS=0,(*(LnkLI127))());
	if((symbol_value(VV[69]))==Cnil){
	goto T625;}
	V200= list(4,VV[74],(V196),list(2,VV[35],(V197)),(V198));
	{object V201 = (*(LnkLI123))(/* INLINE-ARGS */V200);
	VMR25(V201)}
T625:;
	{object V202;
	object V203;
	V202= get((V197),VV[76],Cnil);
	V204= structure_ref((V202),VV[76],2);
	V203= aref1(/* INLINE-ARGS */V204,fixint((V198)));
	V205= aref1(symbol_value(VV[75]),fixint((V203)));
	V206= (*(LnkLI184))(/* INLINE-ARGS */V205);
	(void)(structure_set((V199),VV[25],2,/* INLINE-ARGS */V206));
	V207= (*(LnkLI183))((V196),(V199));
	V208= (*(LnkLI185))((V197));
	{object V209 = list(6,VV[77],(V199),/* INLINE-ARGS */V207,/* INLINE-ARGS */V208,(V198),(V202));
	VMR25(V209)}}}
}
/*	local entry for function COERCE-LOC-STRUCTURE-REF	*/

static object LI26(V212,V213)

object V212;object V213;
{	 VMB26 VMS26 VMV26
TTL:;
	{object V214;
	V214= cdr((V212));
	{object V215;
	object V216;
	V215= cadddr((V214));
	V216= caddr((V214));
	if(((V215))==Cnil){
	goto T634;}
	{object V217;
	register object V218;
	V219= structure_ref((V215),VV[76],2);
	V217= aref1(/* INLINE-ARGS */V219,fixint((V216)));
	V218= aref1(symbol_value(VV[75]),fixint((V217)));
	V220= (*(LnkLI184))((V218));
	V221= (*(LnkLI186))(/* INLINE-ARGS */V220);
	if(!((/* INLINE-ARGS */V221)==(VV[78]))){
	goto T638;}{object V222;
	base[5]= (V217);
	base[6]= small_fixnum(0);
	vs_top=(vs_base=base+5)+2;
	(void) (*Lnk187)();
	vs_top=sup;
	V222= vs_base[0];
	if(V222==Cnil)goto T641;
	goto T638;
T641:;}
	base[5]= VV[79];
	base[6]= (V218);
	vs_top=(vs_base=base+5)+2;
	(void) (*Lnk140)();
	vs_top=sup;
T638:;
	V223= car((V212));
	V224= (*(LnkLI184))((V218));
	(void)(structure_set(/* INLINE-ARGS */V223,VV[25],2,/* INLINE-ARGS */V224));
	V225= (*(LnkLI184))((V218));
	V226= (*(LnkLI186))(/* INLINE-ARGS */V225);
	V227= make_cons(car((V214)),Cnil);
	V228= (VFUN_NARGS=2,(*(LnkLI189))(/* INLINE-ARGS */V227,VV[81]));
	V229= list(4,/* INLINE-ARGS */V226,small_fixnum(0),VV[80],list(4,car(/* INLINE-ARGS */V228),VV[82],(V216),(V215)));
	V230= (*(LnkLI184))((V213));
	{object V231 = (*(LnkLI188))(/* INLINE-ARGS */V229,/* INLINE-ARGS */V230);
	VMR26(V231)}}
T634:;
	{object V232 = (*(LnkLI190))();
	VMR26(V232)}}}
}
/*	local entry for function C2STRUCTURE-REF	*/

static object LI27(V237,V238,V239,V240)

object V237;object V238;object V239;object V240;
{	 VMB27 VMS27 VMV27
	bds_check;
TTL:;
	bds_bind(VV[63],symbol_value(VV[63]));
	bds_bind(VV[56],small_fixnum(0));
	{object V241;
	object V242;
	V243= make_cons((V237),Cnil);
	V244= (VFUN_NARGS=2,(*(LnkLI189))(/* INLINE-ARGS */V243,VV[83]));
	V241= car(/* INLINE-ARGS */V244);{object V245;
	V245= symbol_value(VV[75]);
	V246= structure_ref((V240),VV[76],2);
	V247= aref1(/* INLINE-ARGS */V246,fixint((V239)));
	V242= aref1(V245,fixint(/* INLINE-ARGS */V247));}
	V248= (*(LnkLI184))((V242));
	V249= (*(LnkLI186))(/* INLINE-ARGS */V248);
	V250= list(4,/* INLINE-ARGS */V249,small_fixnum(0),VV[80],list(4,(V241),(V238),(V239),(V240)));
	(void)((VFUN_NARGS=1,(*(LnkLI176))(/* INLINE-ARGS */V250)));}
	{object V251 = (*(LnkLI177))();
	bds_unwind1;
	bds_unwind1;
	VMR27(V251)}
}
/*	local entry for function MY-CALL	*/

static object LI28(V256,V257,V258,V259)

object V256;object V257;object V258;object V259;
{	 VMB28 VMS28 VMV28
TTL:;
	{object V260;
	object V261;
	V260= structure_ref((V259),VV[76],2);
	V261= structure_ref((V259),VV[76],8);
	if((symbol_value(VV[69]))==Cnil){
	goto T655;}
	{object V262 = (*(LnkLI190))();
	VMR28(V262)}
T655:;
	princ_str("STREF(",VV[62]);{object V263;
	V263= symbol_value(VV[75]);
	V264= aref1((V260),fixint((V258)));
	V265= aref1(V263,fixint(/* INLINE-ARGS */V264));
	V266= (*(LnkLI191))(/* INLINE-ARGS */V265);
	(void)((*(LnkLI179))(/* INLINE-ARGS */V266));}
	princ_char(44,VV[62]);
	(void)((*(LnkLI179))((V256)));
	princ_char(44,VV[62]);
	V267= aref1((V261),fixint((V258)));
	(void)((*(LnkLI179))(/* INLINE-ARGS */V267));
	princ_char(41,VV[62]);
	{object V268 = Cnil;
	VMR28(V268)}}
}
/*	local entry for function C1STRUCTURE-SET	*/

static object LI29(V270)

register object V270;
{	 VMB29 VMS29 VMV29
TTL:;
	{register object V271;
	V271= (VFUN_NARGS=0,(*(LnkLI127))());
	if(endp((V270))){
	goto T666;}
	if((symbol_value(VV[69]))!=Cnil){
	goto T666;}
	if(endp(cdr((V270)))){
	goto T666;}
	if(!(type_of(cadr((V270)))==t_cons)){
	goto T666;}
	if(!((caadr((V270)))==(VV[35]))){
	goto T666;}
	if(endp(cdadr((V270)))){
	goto T666;}
	if(!(type_of(cadadr((V270)))==t_symbol)){
	goto T666;}
	if(!(endp(cddadr((V270))))){
	goto T666;}
	if(endp(cddr((V270)))){
	goto T666;}
	if(!(type_of(caddr((V270)))==t_fixnum)){
	goto T666;}
	if(endp(cdddr((V270)))){
	goto T666;}
	if(!(endp(cddddr((V270))))){
	goto T666;}
	{object V272;
	object V273;
	V272= (*(LnkLI123))(car((V270)));
	V273= (*(LnkLI123))(cadddr((V270)));
	(void)((*(LnkLI124))((V271),cadr((V272))));
	(void)((*(LnkLI124))((V271),cadr((V273))));
	V274= structure_ref(cadr((V273)),VV[25],2);
	(void)(structure_set((V271),VV[25],2,/* INLINE-ARGS */V274));
	V275= (*(LnkLI185))(cadadr((V270)));
	V276= caddr((V270));
	V277= get(cadadr((V270)),VV[76],Cnil);
	{object V278 = list(7,VV[84],(V271),(V272),/* INLINE-ARGS */V275,/* INLINE-ARGS */V276,(V273),V277);
	VMR29(V278)}}
T666:;
	{object V279 = list(4,VV[49],(V271),VV[85],(*(LnkLI148))((V270),(V271)));
	VMR29(V279)}}
}
/*	local entry for function C2STRUCTURE-SET	*/

static object LI30(V285,V286,V287,V288,V289)

object V285;object V286;object V287;object V288;object V289;
{	 VMB30 VMS30 VMV30
	bds_check;
TTL:;
	{object V290;
	V290= Cnil;
	bds_bind(VV[63],symbol_value(VV[63]));
	bds_bind(VV[56],small_fixnum(0));
	{object V291;
	object V292;
	object V293;
	object V294;
	object V295;
	object V296;
	V291= structure_ref((V289),VV[76],2);{object V297;
	V297= symbol_value(VV[75]);
	V298= aref1((V291),fixint((V287)));
	V292= aref1(V297,fixint(/* INLINE-ARGS */V298));}
	V293= structure_ref((V289),VV[76],8);
	V294= (*(LnkLI184))((V292));
	V295= Cnil;
	V296= Cnil;
	V299= (VFUN_NARGS=0,(*(LnkLI127))());
	V300= list(3,(V285),(V288),list(4,VV[49],/* INLINE-ARGS */V299,VV[86],Cnil));
	if(!(((V292))==(Ct))){
	goto T708;}
	V301= VV[87];
	goto T706;
T708:;
	V301= list(3,Ct,(V294),Ct);
T706:;
	V290= (VFUN_NARGS=2,(*(LnkLI189))(/* INLINE-ARGS */V300,V301));
	V295= car((V290));
	V296= cadr((V290));
	if((symbol_value(VV[69]))==Cnil){
	goto T714;}
	(void)((*(LnkLI190))());
T714:;
	princ_str("\n	STSET(",VV[62]);
	V302= (*(LnkLI191))((V292));
	(void)((*(LnkLI179))(/* INLINE-ARGS */V302));
	princ_char(44,VV[62]);
	(void)((*(LnkLI179))((V295)));
	princ_char(44,VV[62]);
	V303= aref1((V293),fixint((V287)));
	(void)((*(LnkLI179))(/* INLINE-ARGS */V303));
	princ_str(", ",VV[62]);
	(void)((*(LnkLI179))((V296)));
	princ_str(");",VV[62]);
	V304= (*(LnkLI186))((V294));
	V305= list(4,/* INLINE-ARGS */V304,small_fixnum(0),VV[88],make_cons((V296),Cnil));
	(void)((VFUN_NARGS=1,(*(LnkLI176))(/* INLINE-ARGS */V305)));
	{object V306 = (*(LnkLI177))();
	bds_unwind1;
	bds_unwind1;
	VMR30(V306)}}}
}
/*	local entry for function C1CONSTANT-VALUE	*/

static object LI31(V309,V310)

register object V309;object V310;
{	 VMB31 VMS31 VMV31
TTL:;
	if(!(((V309))==(Cnil))){
	goto T729;}
	{object V311 = (*(LnkLI125))();
	VMR31(V311)}
T729:;
	if(!(((V309))==(Ct))){
	goto T732;}
	{object V312 = (*(LnkLI126))();
	VMR31(V312)}
T732:;
	if(!(type_of((V309))==t_fixnum)){
	goto T735;}
	V313= (VFUN_NARGS=2,(*(LnkLI127))(VV[2],VV[89]));
	base[0]= (*(LnkLI192))((V309));
	base[1]= VV[91];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk193)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T738;}
	V314= Cnil;
	goto T737;
T738:;
	V314= (*(LnkLI129))((V309));
T737:;
	{object V315 = list(3,VV[1],/* INLINE-ARGS */V313,list(3,VV[90],V314,(V309)));
	VMR31(V315)}
T735:;
	if(!(type_of((V309))==t_character)){
	goto T743;}
	V316= (VFUN_NARGS=2,(*(LnkLI127))(VV[2],VV[44]));
	V317= (*(LnkLI129))((V309));
	base[0]= (V309);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk194)();
	vs_top=sup;
	V318= vs_base[0];
	{object V319 = list(3,VV[1],/* INLINE-ARGS */V316,list(3,VV[92],/* INLINE-ARGS */V317,V318));
	VMR31(V319)}
T743:;
	if(!(type_of((V309))==t_longfloat)){
	goto T748;}
	{object V320;
	object V321;
	V320= Cnil;
	V321= Cnil;
	{register object x= (V309),V323= symbol_value(VV[93]);
	while(!endp(V323))
	if(type_of(V323->c.c_car)==t_cons &&eql(x,V323->c.c_car->c.c_car)){
	V322= (V323->c.c_car);
	goto T754;
	}else V323=V323->c.c_cdr;
	V322= Cnil;}
T754:;
	V320= cadr(V322);
	if(((V320))!=Cnil){
	goto T750;}
	V321= (*(LnkLI192))((V309));
	base[0]= VV[94];
	base[1]= small_fixnum(2);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk195)();
	vs_top=sup;
	V324= vs_base[0];
	if(!(number_compare((V321),V324)>0)){
	goto T756;}
	base[0]= (V309);
	base[1]= VV[94];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk195)();
	vs_top=sup;
	V325= vs_base[0];
	V326= list(4,VV[5],VV[19],V325,VV[95]);
	if(((*(LnkLI123))(/* INLINE-ARGS */V326))!=Cnil){
	goto T755;}
T756:;
	V327= number_times(VV[96],VV[97]);
	if(!(number_compare((V321),/* INLINE-ARGS */V327)<0)){
	goto T750;}
	base[0]= (V309);
	base[1]= VV[96];
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk195)();
	vs_top=sup;
	V328= vs_base[0];
	V329= list(4,VV[5],VV[19],V328,VV[98]);
	if(((*(LnkLI123))(/* INLINE-ARGS */V329))==Cnil){
	goto T750;}
T755:;
	V320= symbol_value(VV[99]);
	V330= list(2,(V309),(V320));
	setq(VV[93],make_cons(/* INLINE-ARGS */V330,symbol_value(VV[93])));
T750:;
	V331= (VFUN_NARGS=2,(*(LnkLI127))(VV[2],VV[100]));
	if((V320)!=Cnil){
	V332= (V320);
	goto T775;}
	V332= (*(LnkLI129))((V309));
T775:;
	{object V333 = list(3,VV[1],/* INLINE-ARGS */V331,list(3,VV[101],V332,(V309)));
	VMR31(V333)}}
T748:;
	if(!(type_of((V309))==t_shortfloat)){
	goto T777;}
	V334= (VFUN_NARGS=2,(*(LnkLI127))(VV[2],VV[102]));
	V335= (*(LnkLI129))((V309));
	{object V336 = list(3,VV[1],/* INLINE-ARGS */V334,list(3,VV[103],/* INLINE-ARGS */V335,(V309)));
	VMR31(V336)}
T777:;
	if(((V310))==Cnil){
	goto T780;}
	V337= (*(LnkLI128))((V309));
	V338= (VFUN_NARGS=2,(*(LnkLI127))(VV[2],/* INLINE-ARGS */V337));
	{object V339 = list(3,VV[1],/* INLINE-ARGS */V338,list(2,VV[3],(*(LnkLI129))((V309))));
	VMR31(V339)}
T780:;
	{object V340 = Cnil;
	VMR31(V340)}
}
/*	macro definition for DEFINE-COMPILER-MACRO	*/

static L32()
{register object *base=vs_base;
	register object *sup=base+VM32; VC32
	vs_reserve(VM32);
	check_arg(2);
	vs_top=sup;
	{object V341=base[0]->c.c_cdr;
	if(endp(V341))invalid_macro_call();
	base[2]= (V341->c.c_car);
	V341=V341->c.c_cdr;
	if(endp(V341))invalid_macro_call();
	base[3]= (V341->c.c_car);
	V341=V341->c.c_cdr;
	base[4]= V341;}
	V342= list(2,VV[35],base[2]);
	V343= list(2,VV[35],base[2]);
	V344= list(2,VV[35],base[3]);
	V345= list(4,VV[104],/* INLINE-ARGS */V342,list(2,VV[105],list(4,VV[106],/* INLINE-ARGS */V343,/* INLINE-ARGS */V344,list(2,VV[35],base[4]))),VV[107]);
	base[5]= list(3,VV[71],/* INLINE-ARGS */V345,list(2,VV[35],base[2]));
	vs_top=(vs_base=base+5)+1;
	return;
}
/*	local entry for function UNDEF-COMPILER-MACRO	*/

static object LI33(V347)

object V347;
{	 VMB33 VMS33 VMV33
TTL:;
	{object V348 = remprop((V347),VV[33]);
	VMR33(V348)}
}
/*	macro definition for DEFINE-INLINE-FUNCTION	*/

static L34()
{register object *base=vs_base;
	register object *sup=base+VM34; VC34
	vs_reserve(VM34);
	bds_check;
	check_arg(2);
	vs_top=sup;
	{object V349=base[0]->c.c_cdr;
	if(endp(V349))invalid_macro_call();
	base[2]= (V349->c.c_car);
	V349=V349->c.c_cdr;
	if(endp(V349))invalid_macro_call();
	base[3]= (V349->c.c_car);
	V349=V349->c.c_cdr;
	base[4]= V349;}
	{register object V350;
	V350= Cnil;
	bds_bind(VV[108],symbol_value(VV[108]));
	{register object V351;
	register object V352;
	V351= base[3];
	V352= car((V351));
T786:;
	if(!(endp((V351)))){
	goto T787;}
	goto T782;
T787:;
	if(!(type_of((V352))==t_symbol)){
	goto T793;}
	{register object x= (V352),V353= VV[109];
	while(!endp(V353))
	if(x==(V353->c.c_car)){
	goto T793;
	}else V353=V353->c.c_cdr;}{object V355;
	{register object V356;
	V356= car((VV[108]->s.s_dbind));
	(VV[108]->s.s_dbind)= cdr((VV[108]->s.s_dbind));
	V355= (V356);}
	if(V355==Cnil)goto T799;
	V354= V355;
	goto T798;
T799:;}
	base[7]= VV[110];
	base[9]= VV[111];
	vs_top=(vs_base=base+9)+1;
	(void) (*Lnk196)();
	vs_top=sup;
	base[8]= vs_base[0];
	vs_top=(vs_base=base+7)+2;
	(void) (*Lnk197)();
	vs_top=sup;
	V354= vs_base[0];
T798:;
	V350= make_cons(V354,(V350));
	goto T791;
T793:;
	base[7]= VV[112];
	base[8]= (V352);
	base[9]= base[2];
	vs_top=(vs_base=base+7)+3;
	(void) (*Lnk140)();
	vs_top=sup;
T791:;
	V351= cdr((V351));
	V352= car((V351));
	goto T786;}
T782:;
	{object V357;
	{object V359;
	object V360= base[3];
	object V361= (V350);
	if(endp(V360)||endp(V361)){
	V358= Cnil;
	goto T816;}
	base[6]=V359=MMcons(Cnil,Cnil);
T817:;
	(V359->c.c_car)= list(3,VV[113],list(2,VV[35],(V360->c.c_car)),(V361->c.c_car));
	if(endp(V360=MMcdr(V360))||endp(V361=MMcdr(V361))){
	V358= base[6];
	goto T816;}
	V359=MMcdr(V359)=MMcons(Cnil,Cnil);
	goto T817;}
T816:;
	V357= make_cons(VV[113],V358);
	V364= listA(4,VV[114],base[2],base[3],base[4]);
	base[6]= list(3,VV[71],/* INLINE-ARGS */V364,list(4,VV[115],base[2],(V350),list(4,VV[116],VV[117],(V357),list(2,VV[35],base[4]))));
	vs_top=(vs_base=base+6)+1;
	bds_unwind1;
	return;}}
}
/*	local entry for function NAME-TO-SD	*/

static object LI35(V366)

object V366;
{	 VMB35 VMS35 VMV35
TTL:;
	{object V367;
	V367= Cnil;{object V368;
	base[0]= (V366);
	vs_top=(vs_base=base+0)+1;
	(void) (*Lnk198)();
	vs_top=sup;
	if((vs_base[0])!=Cnil){
	goto T823;}
	V368= Cnil;
	goto T822;
T823:;
	V367= get((V366),VV[76],Cnil);
	V368= (V367);
T822:;
	if(V368==Cnil)goto T821;
	goto T820;
T821:;}
	base[0]= VV[118];
	base[1]= (V366);
	vs_top=(vs_base=base+0)+2;
	(void) (*Lnk140)();
	vs_top=sup;
T820:;
	{object V369 = (V367);
	VMR35(V369)}}
}
/*	local entry for function NAME-SD1	*/

static object LI36(V371)

object V371;
{	 VMB36 VMS36 VMV36
TTL:;{object V372;
	V372= get((V371),VV[119],Cnil);
	if(V372==Cnil)goto T829;
	{object V373 = V372;
	VMR36(V373)}
T829:;}
	V374= list(3,VV[5],VV[119],list(2,VV[35],(V371)));
	{object V375 = sputprop((V371),VV[120],/* INLINE-ARGS */V374);
	VMR36(V375)}
}
/*	local entry for function CO1STRUCTURE-PREDICATE	*/

static object LI37(V378,V379)

object V378;object V379;
{	 VMB37 VMS37 VMV37
TTL:;
	{object V380;
	V380= Cnil;
	if(!(type_of((V378))==t_symbol)){
	goto T833;}
	V380= get((V378),VV[121],Cnil);
	if(((V380))==Cnil){
	goto T833;}
	V381= car((V379));
	V382= list(3,VV[122],/* INLINE-ARGS */V381,list(2,VV[35],(V380)));
	{object V383 = (*(LnkLI123))(/* INLINE-ARGS */V382);
	VMR37(V383)}
T833:;
	{object V384 = Cnil;
	VMR37(V384)}}
}
static LnkT198(){ call_or_link(VV[198],&Lnk198);} /* SYMBOLP */
static LnkT197(){ call_or_link(VV[197],&Lnk197);} /* GENTEMP */
static LnkT196(){ call_or_link(VV[196],&Lnk196);} /* FIND-PACKAGE */
static LnkT195(){ call_or_link(VV[195],&Lnk195);} /*  */
static LnkT194(){ call_or_link(VV[194],&Lnk194);} /* CHAR-CODE */
static LnkT193(){ call_or_link(VV[193],&Lnk193);} /* >= */
static object  LnkTLI192(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[192],&LnkLI192,1,ap);} /* ABS */
static object  LnkTLI191(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[191],&LnkLI191,1,ap);} /* AET-C-TYPE */
static object  LnkTLI190(){return call_proc0(VV[190],&LnkLI190);} /* WFS-ERROR */
static object  LnkTLI189(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[189],&LnkLI189,ap);} /* INLINE-ARGS */
static object  LnkTLI188(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[188],&LnkLI188,2,ap);} /* COERCE-LOC */
static LnkT187(){ call_or_link(VV[187],&Lnk187);} /* EQL */
static object  LnkTLI186(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[186],&LnkLI186,1,ap);} /* INLINE-TYPE */
static object  LnkTLI185(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[185],&LnkLI185,1,ap);} /* ADD-SYMBOL */
static object  LnkTLI184(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[184],&LnkLI184,1,ap);} /* TYPE-FILTER */
static object  LnkTLI183(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[183],&LnkLI183,2,ap);} /* C1EXPR* */
static object  LnkTLI182(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[182],&LnkLI182,1,ap);} /* C1PROGN */
static object  LnkTLI181(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[181],&LnkLI181,2,ap);} /* C2EXPR-TOP */
static object  LnkTLI180(){return call_proc0(VV[180],&LnkLI180);} /* RESET-TOP */
static object  LnkTLI179(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[179],&LnkLI179,1,ap);} /* WT1 */
static LnkT178(){ call_or_link(VV[178],&Lnk178);} /* C2EXPR */
static object  LnkTLI177(){return call_proc0(VV[177],&LnkLI177);} /* CLOSE-INLINE-BLOCKS */
static object  LnkTLI176(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[176],&LnkLI176,ap);} /* UNWIND-EXIT */
static LnkT175(){ call_or_link(VV[175],&Lnk175);} /* MAKE-LIST */
static object  LnkTLI174(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[174],&LnkLI174,2,ap);} /* GET-INLINE-LOC */
static object  LnkTLI173(){return call_proc0(VV[173],&LnkLI173);} /* BABOON */
static object  LnkTLI172(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[172],&LnkLI172,1,ap);} /* VOLATILE */
static object  LnkTLI171(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[171],&LnkLI171,4,ap);} /* C2CALL-GLOBAL */
static object  LnkTLI170(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[170],&LnkLI170,ap);} /* C1LAMBDA-EXPR */
static LnkT169(){ call_or_link(VV[169],&Lnk169);} /* RESULT-TYPE-FROM-ARGS */
static LnkT168(){ call_or_link(VV[168],&Lnk168);} /* LAST */
static object  LnkTLI166(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[166],&LnkLI166,2,ap);} /* TYPE-AND */
static object  LnkTLI164(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[164],&LnkLI164,3,ap);} /* CHECK-FORM-TYPE */
static object  LnkTLI163(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[163],&LnkLI163,1,ap);} /* GET-ARG-TYPES */
static object  LnkTLI162(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[162],&LnkLI162,1,ap);} /* GET-RETURN-TYPE */
static LnkT161(){ call_or_link(VV[161],&Lnk161);} /* NULL */
static object  LnkTLI160(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[160],&LnkLI160,3,ap);} /* C1STRUCTURE-REF1 */
static LnkT159(){ call_or_link(VV[159],&Lnk159);} /* CMP-EVAL */
static LnkT158(){ call_or_link(VV[158],&Lnk158);} /* MACRO-FUNCTION */
static object  LnkTLI32(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[32],&LnkLI32,2,ap);} /* RECORD-CALL-INFO */
static LnkT157(){ call_or_link(VV[157],&Lnk157);} /* NOT */
static LnkT156(){ call_or_link(VV[156],&Lnk156);} /* FBOUNDP */
static LnkT155(){ call_or_link(VV[155],&Lnk155);} /* EQ */
static LnkT154(){ call_or_link(VV[154],&Lnk154);} /* SYMBOL-PACKAGE */
static object  LnkTLI153(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[153],&LnkLI153,1,ap);} /* INLINE-POSSIBLE */
static object  LnkTLI152(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[152],&LnkLI152,3,ap);} /* CMP-EXPAND-MACRO */
static object  LnkTLI151(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[151],&LnkLI151,3,ap);} /* AND-FORM-TYPE */
static object  LnkTLI150(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[150],&LnkLI150,1,ap);} /* GET-LOCAL-ARG-TYPES */
static object  LnkTLI149(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[149],&LnkLI149,1,ap);} /* GET-LOCAL-RETURN-TYPE */
static object  LnkTLI148(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[148],&LnkLI148,2,ap);} /* C1ARGS */
static object  LnkTLI147(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[147],&LnkLI147,1,ap);} /* C1LOCAL-FUN */
static LnkT146(){ call_or_link(VV[146],&Lnk146);} /* ASH */
static object  LnkTLI145(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[145],&LnkLI145,2,ap);} /* TYPE>= */
static LnkT15(){ call_or_link(VV[15],&Lnk15);} /* LOGBITP */
static LnkT144(){ call_or_link(VV[144],&Lnk144);} /* FIX-OPT */
static LnkT143(){ call_or_link(VV[143],&Lnk143);} /* LOGIOR */
static object  LnkTLI142(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[142],&LnkLI142,ap);} /* CMPWARN */
static LnkT141(){ call_or_link(VV[141],&Lnk141);} /* FLAGS-POS */
static LnkT140(){ call_or_link(VV[140],&Lnk140);} /* ERROR */
static object  LnkTLI139(){return call_proc0(VV[139],&LnkLI139);} /* ADD-LOAD-TIME-SHARP-COMMA */
static LnkT138(){ call_or_link(VV[138],&Lnk138);} /* EVAL */
static object  LnkTLI137(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[137],&LnkLI137,ap);} /* CMPERR */
static object  LnkTLI136(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[136],&LnkLI136,2,ap);} /* C1LAMBDA-FUN */
static LnkT135(){ call_or_link(VV[135],&Lnk135);} /* C1SYMBOL-FUN */
static object  LnkTLI134(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[134],&LnkLI134,1,ap);} /* C1VAR */
static object  LnkTLI133(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[133],&LnkLI133,1,ap);} /* ADD-CONSTANT */
static object  LnkTLI132(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[132],&LnkLI132,2,ap);} /* C1CONSTANT-VALUE */
static LnkT131(){ call_or_link(VV[131],&Lnk131);} /* SYMBOL-VALUE */
static LnkT130(){ call_or_link(VV[130],&Lnk130);} /* CONSTANTP */
static object  LnkTLI129(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[129],&LnkLI129,1,ap);} /* ADD-OBJECT */
static object  LnkTLI128(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[128],&LnkLI128,1,ap);} /* OBJECT-TYPE */
static object  LnkTLI127(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_vproc(VV[127],&LnkLI127,ap);} /* MAKE-INFO */
static object  LnkTLI126(){return call_proc0(VV[126],&LnkLI126);} /* C1T */
static object  LnkTLI125(){return call_proc0(VV[125],&LnkLI125);} /* C1NIL */
static object  LnkTLI124(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[124],&LnkLI124,2,ap);} /* ADD-INFO */
static object  LnkTLI123(va_alist)va_dcl{va_list ap;va_start(ap);return(object )call_proc(VV[123],&LnkLI123,1,ap);} /* C1EXPR */
