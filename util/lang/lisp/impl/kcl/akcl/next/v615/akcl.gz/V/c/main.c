Changes file for /local/src/kcl/c/main.c
Usage \n@s[Original text\n@s|Replacement Text\n@s]
See the file rascal.ics.utexas.edu:/usr2/ftp/merge.c
for a program to merge change files.  Anything not between
 "\n@s[" and  "\n@s]" is a simply a comment.
This file was constructed using emacs and  merge.el
 by (Bill Schelter)  wfs@carl.ma.utexas.edu 


****Change:(orig (11 11 a))
@s[	IMPLEMENTATION-DEPENDENT
*/


@s|	IMPLEMENTATION-DEPENDENT
*/

#define IN_MAIN

#ifdef KCLOVM
#include <ovm/ovm.h>
void change_contexts();
int ovm_process_created; 
void initialize_process();
#endif


@s]


****Change:(orig (12 12 a))
@s[#include "include.h"

@s|#include "include.h"
#ifdef UNIX
#include <signal.h>
#ifdef NeXT
#include <fcntl.h>
#include <sys/stat.h>
#endif

@s]


****Change:(orig (13 13 a))
@s[

@s|
int segmentation_catcher();
#endif
#include "page.h"


@s]


****Change:(orig (17 17 a))
@s[#ifdef BSD
#include <sys/time.h>

@s|#ifdef BSD
#include <sys/time.h>
#ifndef SGI

@s]


****Change:(orig (19 19 a))
@s[#include <sys/resource.h>
#endif

@s|#include <sys/resource.h>
#endif
#endif

@s]


****Change:(orig (30 33 d))
@s[object siVsystem_directory;
#ifdef UNIX
char *kcl_self;
#endif

@s|
@s]


****Change:(orig (34 34 a))
@s[

@s|
int page_multiple=1;


@s]


****Change:(orig (48 52 d))
@s[int ARGC;
char **ARGV;
#ifdef UNIX
char **ENVP;

@s,#endif

@s|
@s]


****Change:(orig (57 57 a))
@s[static object module_data;

@s|static object module_data;
static object siLmultiply_stacks;
int stack_multiple=1;
static object stack_space;

@s]


****Change:(orig (63 63 c))
@s[int cssize;

#ifdef UNIX

@s|int cssize;

int sgc_enabled;
void install_segmentation_catcher();
#ifdef NeXT
char *find_executable();
#endif

#define SIG_STACK_SIZE 2000
#if defined(HAVE_SIGACTION) || defined(HAVE_SIGVEC)
        struct sigstack estack;
#endif
 

@s]


****Change:(orig (67 71 d))
@s[#else
main(argc, argv)
int argc;
char **argv;

@s,#endif

@s|
@s]


****Change:(orig (74 74 a))
@s[{
	FILE *i;
#ifdef BSD

@s|{
	FILE *i;
#ifdef BSD
#ifndef SGI

@s]


****Change:(orig (77 80 d))
@s[	struct rlimit rl;
#endif
#ifdef AOSVS




@s|	struct rlimit rl;
#endif

@s]


****Change:(orig (81 81 a))
@s[#endif

@s|#endif
#if defined(HAVE_SIGACTION) || defined(HAVE_SIGVEC)

@s]


****Change:(orig (82 82 a))
@s[

@s|
#ifdef SETJMP_ONE_DIRECTION
	static
#endif	  
	int estack_buf[SIG_STACK_SIZE];
#endif

@s]


****Change:(orig (96 96 a))
@s[		error("can't get the program name");
*/

@s|		error("can't get the program name");
*/
#ifndef NeXT

@s]


****Change:(orig (97 97 a))
@s[	kcl_self = argv[0];

@s|	kcl_self = argv[0];
#else
	kcl_self = find_executable(argv[0]);
#endif

@s]


****Change:(orig (139 139 a))
@s[	}

	GBC_enable = FALSE;


@s|	}

	GBC_enable = FALSE;

	/* if stack_space not zero we have grown the stack space */
	if (stack_space == 0)
	  {
	    vs_org = value_stack;
	    vs_limit = &vs_org[VSSIZE];
	    frs_org = frame_stack;
	    frs_limit = &frs_org[FRSSIZE];
	    bds_org = bind_stack;
	    bds_limit = &bds_org[BDSSIZE];
#ifdef KCLOVM
	    bds_save_org = save_bind_stack;
	    bds_save_top = bds_save_org - 1;
	    bds_save_limit = &bds_save_org[BDSSIZE];
#endif
	    ihs_org = ihs_stack;
	    ihs_limit = &ihs_org[IHSSIZE];}


@s]


****Change:(orig (141 143 c))
@s[	vs_limit = &vs_org[VSSIZE];
	frs_top = frs_org-1;
	frs_limit = &frs_org[FRSSIZE];

@s|	clear_stack(vs_top,vs_limit);
	ihs_top = ihs_org-1;

@s]


****Change:(orig (145 147 c))
@s[	bds_limit = &bds_org[BDSSIZE];
  	ihs_top = ihs_org-1;
	ihs_limit = &ihs_org[IHSSIZE];

@s|	frs_top = frs_org-1;

@s]


****Change:(orig (150 150 a))
@s[	cs_org = &argc;

	cssize = CSSIZE;

@s|	cs_org = &argc;

	cssize = CSSIZE;
	install_segmentation_catcher();

@s]


****Change:(orig (152 152 a))
@s[
#ifdef BSD

@s|
#ifdef BSD
#ifdef RLIMIT_STACK

@s]


****Change:(orig (154 154 a))
@s[	cssize = rl.rlim_cur/4 - 4*CSGETA;

@s|	cssize = rl.rlim_cur/4 - 4*CSGETA;
#endif	

@s]


****Change:(orig (163 163 c))
@s[#endif
#ifdef MV

#endif


@s|#endif
#ifdef MV

#endif
        

@s]


****Change:(orig (164 164 a))
@s[	set_maxpage();

@s|	set_maxpage();
#if defined(HAVE_SIGACTION) || defined(HAVE_SIGVEC)
	bzero(estack_buf,sizeof(estack_buf));
	estack.ss_sp = (char *) &estack_buf[SIG_STACK_SIZE-1];
	estack.ss_onstack=0;
	sigstack(&estack,0);
#endif	
	

@s]


****Change:(orig (187 187 a))
@s[		siVlisp_maxpages->s.s_dbind = make_fixnum(real_maxpage);
		initflag = TRUE;

@s|		siVlisp_maxpages->s.s_dbind = make_fixnum(real_maxpage);
		initflag = TRUE;
#ifdef KCLOVM
		ovm_user_context_change = change_contexts;
		ovm_user_context_initialize = initialize_process;

		v_init_processes();
		ovm_process_created = 1;
#endif
	      again:

@s]


****Change:(orig (188 188 a))
@s[		super_funcall(siStop_level);

@s|		super_funcall(siStop_level);
		if (type_of(siLmultiply_stacks->s.s_dbind)==t_fixnum)
		  {multiply_stacks(fix(siLmultiply_stacks->s.s_dbind));
		   goto  again;}


@s]


****Change:(orig (197 197 c))
@s[	fflush(stdout);

	init();

@s|	fflush(stdout);

	initlisp();

@s]


****Change:(orig (258 258 c))
@s[	super_funcall(siStop_level);

}

init()

@s|	super_funcall(siStop_level);

}


void
akcl_signal(signo,handler)
     int signo;
     void (*handler)();
{
#ifdef HAVE_SIGACTION
  struct sigaction action;
  action.sa_handler = handler;
  action.sa_flags = SA_RESTART | (signo == SIGSEGV || signo == SIGBUS ? SV_ONSTACK : 0);
  sigemptyset(&action.sa_mask);
  sigaddset(&action.sa_mask,signo);
  sigaction(signo,&action,0);
#else
#ifdef HAVE_SIGVEC
  struct sigvec vec;
  vec.sv_handler =  handler;
  vec.sv_flags =  (signo == SIGSEGV || signo == SIGBUS ? SV_ONSTACK : 0);
  vec.sv_mask = sigmask(signo);
  sigvec(signo,&vec,0);
#else
  signal(signo,handler);
#endif
#endif  
}


/* catch certain signals */
void install_segmentation_catcher()
{
#ifdef INSTALL_SEGMENTATION_CATCHER
  INSTALL_SEGMENTATION_CATCHER;
#else
#ifdef SIGSEGV
       (void) akcl_signal(SIGSEGV,segmentation_catcher);
#endif
#endif
       }



initlisp()

@s]


****Change:(orig (313 313 a))
@s[	enter_mark_origin(&Sspecial);

	init_typespec();

@s|	enter_mark_origin(&Sspecial);

	init_typespec();
	init_pari();

@s]


****Change:(orig (335 340 d))
@s[#ifdef AOSVS



#endif


@s|
@s]


****Change:(orig (351 351 a))
@s[	init_sequence_function();

@s|	init_sequence_function();
#if  defined(KCLOVM) || defined(RUN_PROCESS)
	init_socket_function();
#endif	

@s]


****Change:(orig (363 367 d))
@s[#endif
#ifdef AOSVS


#endif


@s|#endif

@s]


****Change:(orig (389 390 c))
@s[	init_format();

#ifdef AOSVS

@s|	init_format();
	init_links();

@s]


****Change:(orig (392 392 c))
@s[
#endif

@s|
	init_fat_string();
#ifdef CMAC
	init_cmac();
#endif	

@s]


****Change:(orig (450 450 c))
@s[	if (vs_limit > vs_org + VSSIZE)

@s|	if (vs_limit > vs_org + stack_multiple *  VSSIZE)

@s]


****Change:(orig (455 455 a))
@s[	FEerror("Value stack overflow.", 0);
}


@s|	FEerror("Value stack overflow.", 0);
}



@s]


****Change:(orig (459 459 c))
@s[	if (bds_limit > bds_org + BDSSIZE)

@s|	if (bds_limit > bds_org + stack_multiple *  BDSSIZE)

@s]


****Change:(orig (468 468 c))
@s[	if (frs_limit > frs_org + FRSSIZE)

@s|	if (frs_limit > frs_org + stack_multiple *  FRSSIZE)

@s]


****Change:(orig (477 477 c))
@s[	if (ihs_limit > ihs_org + IHSSIZE)

@s|	if (ihs_limit > ihs_org + stack_multiple *  IHSSIZE)

@s]


****Change:(orig (482 482 a))
@s[	FEerror("Invocation history stack overflow.", 0);
}


@s|	FEerror("Invocation history stack overflow.", 0);
}

segmentation_catcher()
{int x;
#ifndef SIG_STACK_SIZE 
 if (&x < cs_limit)
	cs_overflow();
 else 
  {printf("Segmentation violation: c stack ok:signalling error");
	}
#endif
  error("Segmentation violation.");
}


@s]


****Change:(orig (502 502 a))
@s[	error("end of file");
}


@s|	error("end of file");
}


int catch_fatal=1;

@s]


****Change:(orig (504 504 a))
@s[error(s)
{

@s|error(s)
{
        if (catch_fatal>0 && interrupt_enable )
	  {catch_fatal = -1;
	   if (sgc_enabled)
	     { sgc_quit();}
	   if (sgc_enabled==0)
	     { install_segmentation_catcher() ;}
	   FEerror("Caught fatal error [memory may be damaged]"); }

@s]


****Change:(orig (621 621 a))
@s[		FEerror("Value stack is flawed.", 0);
	vs_base[0] = Cnil;
}


@s|		FEerror("Value stack is flawed.", 0);
	vs_base[0] = Cnil;
}

object
siLcatch_fatal(i)
{catch_fatal=i;
 return Cnil;}



@s]


****Change:(orig (625 626 c))
@s[	if (vs_top < vs_org + VSSIZE)
		vs_limit = vs_org + VSSIZE;

@s|	if(catch_fatal <0) catch_fatal=1;
#ifdef SGC	
	{extern int fault_count ; fault_count = 0;}
#endif 
	if (vs_top < vs_org + stack_multiple *  VSSIZE)
		vs_limit = vs_org + stack_multiple *  VSSIZE;

@s]


****Change:(orig (629 630 c))
@s[	if (bds_top < bds_org + BDSSIZE)
		bds_limit = bds_org + BDSSIZE;

@s|	if (bds_top < bds_org + stack_multiple *  BDSSIZE)
		bds_limit = bds_org + stack_multiple *  BDSSIZE;

@s]


****Change:(orig (633 634 c))
@s[	if (frs_top < frs_org + FRSSIZE)
		frs_limit = frs_org + FRSSIZE;

@s|	if (frs_top < frs_org + stack_multiple *  FRSSIZE)
		frs_limit = frs_org + stack_multiple *  FRSSIZE;

@s]


****Change:(orig (637 638 c))
@s[	if (ihs_top < ihs_org + IHSSIZE)
		ihs_limit = ihs_org + IHSSIZE;

@s|	if (ihs_top < ihs_org + stack_multiple *  IHSSIZE)
		ihs_limit = ihs_org + stack_multiple *  IHSSIZE;

@s]


****Change:(orig (645 648 d))
@s[#endif
#ifdef MV


#endif

@s|#endif

@s]


****Change:(orig (653 653 a))
@s[		error("can't reset cs_limit");
	vs_base[0] = Cnil;
}


@s|		error("can't reset cs_limit");
	vs_base[0] = Cnil;
}

#define COPYSTACK(org,p,typ,lim,top,geta,size) \
 do{int leng,topl;      \
  bcopy(org,p,leng=(stack_multiple*size*sizeof(typ))); \
  topl= top - org; \
  org=(typ *)p; top = org +topl;\
  p=p+leng+2*geta*sizeof(typ); \
  lim = ((typ *)p) - 2*geta;   \
  }while (0)

multiply_stacks(m)
     int m;
{  int n;
   object x;
   object gc_pro=stack_space;
   char *p;
   int vs,bd,frs,ihs;
   stack_multiple=stack_multiple*m;
#define ELTSIZE(x) (((char *)((x)+1)) - ((char *) x))
   vs  = (stack_multiple*VSSIZE  + 2*VSGETA)* ELTSIZE(vs_org);
   bd  = (stack_multiple*BDSSIZE + 2*BDSGETA)*ELTSIZE(bds_org);
   frs = (stack_multiple*FRSSIZE + 2*FRSGETA)*ELTSIZE(frs_org);
   ihs = (stack_multiple*IHSSIZE + 2*IHSGETA)*ELTSIZE(ihs_org);
   if (stack_space==0) {enter_mark_origin(&stack_space);}
   stack_space = alloc_simple_string(vs+bd+frs+ihs);
   array_allocself(stack_space,1,code_char(0));
   p=stack_space->st.st_self;
   COPYSTACK(vs_org,p,object,vs_limit,vs_top,VSGETA,VSSIZE);
   COPYSTACK(bds_org,p,struct bds_bd,bds_limit,bds_top,BDSGETA,BDSSIZE);
   COPYSTACK(frs_org,p,struct frame,frs_limit,frs_top,FRSGETA,FRSSIZE);
   COPYSTACK(ihs_org,p,struct invocation_history,ihs_limit,ihs_top,
	     IHSGETA,IHSSIZE);
   vs_base=vs_top;
   return stack_multiple;
 }






 
  


@s]


****Change:(orig (691 691 a))
@s[	vs_push(make_simple_string(lisp_implementation_version));
	vs_base[0] = Cnil;
}


@s|	vs_push(make_simple_string(lisp_implementation_version));
	vs_base[0] = Cnil;
}



@s]


****Change:(orig (696 697 c))
@s[{
	int i;

#ifdef AOSVS


@s|{
	int i;

#ifdef HAVE_YP_UNBIND
	extern object truename(),namestring();
	check_arg(1);
	/* prevent subsequent consultation of yp by getting
	   truename now*/
	vs_base[0]=namestring(truename(vs_base[0]));
	{char name[200];
	 char *dom = name;
	 if (0== getdomainname(dom,sizeof(name)))
	   yp_unbind(dom);}

@s]


****Change:(orig (698 698 a))
@s[#endif

@s|#endif
	

@s]


****Change:(orig (702 702 c))
@s[	GBC(t_contiguous);

#ifdef BSD

@s|	GBC(t_contiguous);



#if defined(BSD) || defined(ATT)  

@s]


****Change:(orig (703 703 a))
@s[	brk(core_end);

@s|	brk(core_end);
  /* printf( "(breaking at core_end = %x in main ,)",core_end); */

@s]


****Change:(orig (767 837 c))
@s[
	make_special("*FEATURES*",
		     make_cons(make_ordinary("COMMON"),
		     make_cons(make_ordinary("KCL"), Cnil)));

@s,



#endif

#ifdef SEQ


@s|	{object features;

@s]


****Change:(orig (838 838 a))
@s[

@s|
#define ADD_FEATURE(name) \
	 features=  make_cons(make_ordinary(name),features)

@s]


****Change:(orig (839 839 a))
@s[

@s|
	   features=    make_cons(make_ordinary("COMMON"),
		     make_cons(make_ordinary("KCL"), Cnil));
	 ADD_FEATURE("AKCL");	 
	 ADD_FEATURE("TURBO-CLOSURE");
	 ADD_FEATURE("TURBO-CLOSURE-ENV-SIZE");

@s]


****Change:(orig (841 863 c))
@s[



#endif

#ifdef IBMRT

@s,		     make_cons(make_ordinary("KCL"), Cnil)))))));

@s|#ifdef UNIX
	ADD_FEATURE("UNIX");

@s]


****Change:(orig (865 872 c))
@s[
#ifdef S3000
	make_special("*FEATURES*",
		     make_cons(make_ordinary("S3300"),

@s,		     make_cons(make_ordinary("KCL"), Cnil))))));

@s|#ifdef IEEEFLOAT
       ADD_FEATURE("IEEE-FLOATING-POINT");

@s]


****Change:(orig (874 883 c))
@s[
#ifdef E15
	make_special("*FEATURES*",
		     make_cons(make_ordinary("E15"),

@s,		     make_cons(make_ordinary("KCL"), Cnil))))))));

@s|#ifdef SGC
       ADD_FEATURE("SGC");
#endif	 
#ifdef  ADDITIONAL_FEATURES
     	             ADDITIONAL_FEATURES;
#endif
#ifdef  BSD
	ADD_FEATURE("BSD");

@s]


****Change:(orig (886 887 d))
@s[#endif

#ifdef DGUX


@s|#endif


@s]


****Change:(orig (888 888 a))
@s[

@s|
#ifndef PECULIAR_MACHINE
#define BIGM    (int)((((unsigned int)(-1))/2))	 
	{ 
	  int ONEM = -1;
	  int Bigm  = BIGM;
	  int Smallm = -BIGM-1;
	  int Seven = 7;
	  int Three = 3;
	  if ( (Smallm / Seven)  < 0
	      && (Smallm / (-Seven))  > 0
	      && (Bigm / (-Seven)) < 0 
	      && ((-Seven) / Three) == -2
	      && (Seven / (-Three)) == -2
	      && ((-Seven)/ (-Three)) == 2)
	    { ADD_FEATURE("TRUNCATE_USE_C");
	    }  }
#endif	 

@s]


****Change:(orig (890 890 a))
@s[


@s|

	 
	make_special("*FEATURES*",features);}

@s]


****Change:(orig (892 898 c))
@s[
#endif

#ifdef AOSVS



@s,

@s|	make_si_function("SAVE-SYSTEM", siLsave_system);
	make_si_sfun("CATCH-FATAL",siLcatch_fatal,ARGTYPE1(f_fixnum));
	siLmultiply_stacks=make_si_special("*MULTIPLY-STACKS*",Cnil);
	
}

@s]


****Change:(orig (899 899 a))
@s[

@s|
#ifdef NeXT
static int
is_executable(fn)
    char *fn;
{
    struct stat s;

@s]


****Change:(orig (901 901 c))
@s[
#endif

@s|
    return stat (fn, &s) != -1 && (s.st_mode & S_IFMT) == S_IFREG
	    && access (fn, X_OK) != -1;
}

@s]


****Change:(orig (903 903 c))
@s[	make_si_function("SAVE-SYSTEM", siLsave_system);

@s|char *
find_executable(fn)
    char *fn;
{
    char *path, *getenv();
    static char buf[MAXPATHLEN+1];
    static char msg[100];
    register char *p;

    for (p = fn; *p; p++) {
	if (*p == '/') {
	    if (is_executable (fn))
		return fn;
	    else {
		sprintf(msg, "%s is not executable", fn);
		error(msg);
	    }
	}
    }
    if ((path = getenv ("PATH")) == 0)
	error("PATH is undefined");
    do {
	p = buf;
	while (*path && *path != ':')
	    *p++ = *path++;
	if (*path)
	    ++path;
	if (p > buf)
	    *p++ = '/';
	strcpy (p, fn);
	if (is_executable (buf))
	    return buf;
    } while (*path);
    sprintf(msg, "cannot find pathname of %s", fn);
    error(msg);

@s]


****Change:(orig (904 904 a))
@s[}

@s|}
#endif

@s]

