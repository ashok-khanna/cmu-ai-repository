#define NUMBER 257
#define STRING 258
#define SYMBOL 259
#define ERROR 260
typedef union {
    lispobj *bu_lispobj;
} YYSTYPE;
extern YYSTYPE yylval;
