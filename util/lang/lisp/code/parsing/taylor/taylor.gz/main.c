#include <stdio.h>
#include "lisp.h"

FILE *input_stream;

main(argc, argv)
    int argc;
    char *argv[];
{

    input_stream = stdin;	/* for testing purposes */

    Finitialize();

#if 0
    printf("calling yyparse...\n");

    while (!yyparse()) {

	printf("...success\ns-exp read:\n");
	Fprint(Qsexp_read);
	if (Qsexp_read == Qeof)
	    break;

	Ffree(Qsexp_read);
	Qsexp_read = NULL;

	printf("calling yyparse...\n");
    }
    if (Qsexp_read == Qeof)
	printf("Done\n");
    else
	printf("Error encountered\n");
#endif

    while (1) {

	printf("calling yyparse...\n");
	if (!yyparse()) {
	    printf("...success\ns-exp read:\n");
	    Fprint(Qsexp_read);
	    if (Qsexp_read == Qeof)
		break;
	} else
	    printf("...Error encountered\n");

	Ffree(Qsexp_read);
	Qsexp_read = NULL;
    }

    printf("Done\n");
}
