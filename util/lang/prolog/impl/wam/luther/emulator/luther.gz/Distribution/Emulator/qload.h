/*    File:	 qload.h  
 *    Author:	 Johan Bevemyr
 *    Created:	 Tue Jun 11 11:18:03 1991
 */ 

typedef enum {
    QLOAD_END_MARKER = 0,
    QLOAD_PRED_START,
    QLOAD_WORD,
    QLOAD_N_BYTECODE,
    QLOAD_DEF,
    QLOAD_ATOM,
    QLOAD_FUNCTOR,
    QLOAD_FLOAT,
    QLOAD_INTEGER,
    QLOAD_START_TABLE,
    QLOAD_END_TABLE,
    QLOAD_PRED_END
} qload_codes;


extern char *qload_opcode_names[QLOAD_PRED_END+1];

extern BOOL quickload PROTO((FILE *,worker *));    
extern BOOL luther_qload PROTO((Argproto));
