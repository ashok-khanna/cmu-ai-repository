/*    File:	 array.h  (~bevemyr/Luther2/WorkerEmulator/array.h)
 *    Author:	 Johan Bevemyr
 *    Created:	 Tue Apr  7 15:18:57 1992
 *    Purpose:   
 */ 

#define ARRAY_BASE_SIZE    2

#define GetArraySize(A)    (Generic(RemoveTag(A,GEN))->data[0])
#define IsArray(A)         (IsGEN(A) && (GetGenTag(A) == &array_method_table))
#define GetArrayArg(A,N)   (Generic(RemoveTag(A,GEN))->data[N*VARSIZE+1])

BOOL luther_array_elt PROTO((Argproto));
BOOL luther_array_size_2 PROTO((Argproto));
BOOL luther_array_reduce PROTO((Argproto));
BOOL luther_array_setref PROTO((Argproto));

extern method array_method_table;

