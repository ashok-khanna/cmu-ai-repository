/*    File:	 sequential-main.c  
 *    Author:	 Johan Bevemyr
 *    Created:	 Fri Sep 13 15:41:59 1991
 */ 

#include "include.h"
#include "wam-main.h"

#ifdef THINK_C
#include "think.h"

#define ARGS 3
char *Argv[ARGS] = {
    "luther",
    "-wam", "Luther Library" };
char buf[255];

#endif /* THINK_C */

void main(argc,argv)
     int argc;
     char **argv;
{
#ifdef THINK_C
    argc = ARGS;
    argv = Argv;

#if 1 /* Turn this of if you want to run the program inside THINK_C */
    argv[2] = get_application_name(buf);
#endif    

#endif /* THINK_C */

    wam_main(argc,argv);
}
