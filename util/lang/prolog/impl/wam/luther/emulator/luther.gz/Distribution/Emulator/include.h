/*    File:	 include.h  
 *    Author:	 Johan Bevemyr
 *    Created:	 Thu May 23 18:06:11 1991
 *    Purpose:   
 */ 

#include "config.h"

#include "c.h"

#ifdef SUN
#include "sun.h"
#endif

#ifdef SEQUENT
#include "sequent.h"
#endif

#if defined(BSD_UNIX) || defined(HP_UX) || defined(APOLLO)
#include <sys/param.h>
#endif 

#include <stdio.h>

#ifdef __STDC__

#ifndef SEQUENT

#include <stdlib.h>
#include <string.h> 

#endif /* SEQUENT */

#endif /* __STDC__ */

#include "constants.h"
#include "instrdef.h"
#include "term.h"
#include "gc.h"
#include "lock.h"
#include "statistics.h"

#include "atom_table.h"
#include "error.h"
#include "storage.h"
#include "initial.h"

#include "event.h"
#include "database.h"
#include "semaphore.h"
#include "inout.h"
#include "time.h"
#include "signal.h"
