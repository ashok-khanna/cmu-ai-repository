/*    File:	 display_code.h 
 *    Author:	 Johan Bevemyr
 *    Created:	 Wed Jun  5 13:13:19 1991
 */ 

extern void display_code PROTO((code *, worker *));
extern code *display_code_inc PROTO((code *, worker *));

