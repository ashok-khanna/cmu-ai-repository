/*    File:	 wam-main.h  
 *    Author:	 Johan Bevemyr
 *    Created:	 Thu Sep 12 15:36:03 1991
 *    Purpose:   
 */ 

extern void wam_main PROTO((int, char **));
