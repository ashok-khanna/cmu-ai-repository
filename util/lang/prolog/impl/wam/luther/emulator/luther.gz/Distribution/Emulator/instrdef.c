/*    File:	 instrdef.c  (~bevemyr/Luther2/WorkerEmulator/instrdef.c)
 *    Author:	 Johan Bevemyr
 *    Created:	 Mon Feb 17 17:41:17 1992
 *    Purpose:   
 */ 

#include "include.h"

#ifdef Inst_Def
#undef Inst_Def
#endif

#define Inst_Def(X,Y,Z) Z,

char *instruction_table[END_OF_PRED+1] = {
#include "instructions.h"
} ;
