/*    File:	 labelsort.h  
 *    Author:	 Johan Bevemyr
 *    Created:	 Wed Feb 19 12:25:24 1992
 */ 

typedef struct labelt {
    TAGGED constant;
    s32 offset;
} labelt;

extern void labelsort PROTO((code *, int));
    
