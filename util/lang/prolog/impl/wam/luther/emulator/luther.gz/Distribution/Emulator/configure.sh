#!/bin/sh

TOPDIR=`cd ..; pwd` 

cat Makefile.orig | sed "s:TOPDIR= .*:TOPDIR= ${TOPDIR}:1" > Makefile.tmp

case `arch` in 
	sun4) 
		cat Makefile.tmp | \
		sed "s:^OS_TYPE=.*:OS_TYPE= -DSUN:1" |\
		sed "s:^MAKE=.*:MAKE= gnu-make -j 4:1" > Makefile;;
	sequent) 
		cat Makefile.tmp | \
		sed "s:^OS_TYPE=.*:OS_TYPE= -DSEQUENT:1" |\
		sed "s:^MAKE=.*:MAKE= gmake:1" > Makefile;;
	hp9000s700)
		cat Makefile.tmp | \
		sed "s:^OS_TYPE=.*:OS_TYPE= -DHP_UX:1" |\
		sed "s:^MAKE=.*:MAKE= gmake:1" > Makefile;;
	*)
	  	echo "using default configuration";
		cat Makefile.tmp | \
		sed "s:^OS_TYPE=.*:OS_TYPE= -DSUN:1" |\
		sed "s:^MAKE=.*:MAKE= make:1" > Makefile;;
esac
