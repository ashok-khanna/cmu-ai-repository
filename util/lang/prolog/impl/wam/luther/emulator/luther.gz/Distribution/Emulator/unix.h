/*    File:	 unix.h  (~bevemyr/Luther2/SharedEmulator/unix.h)
 *    Author:	 Johan Bevemyr
 *    Created:	 Tue Oct  6 10:20:20 1992
 */ 


#ifdef SHARED
extern void get_mmap_filename PROTO((char *, long));

#endif
