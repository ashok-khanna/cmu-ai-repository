/*    File:	 c.h  
 *    Author:	 Johan Bevemyr
 *    Created:	 Fri Jun  7 12:04:50 1991
 *    See Also:  semaphore.c semaphore.h expand_file_name.c leaf.h
 */ 



#define SAME 0  /* strcmp => same */

#define ANY 1                   /* Number of elements in dummy array. */
#ifndef __STDC__
#define NULL 0
#endif

typedef unsigned short u16;
typedef short s16;

typedef unsigned long u32;
typedef long s32;

#ifdef ANSI_C

#define VOLATILE volatile
#define PROTO(argl) argl

#else

#define VOLATILE
#define PROTO(ignore) ()

#endif
