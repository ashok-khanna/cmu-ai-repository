/*    File:	 builtin.h 
 *    Author:	 Johan Bevemyr
 *    Created:	 Wed Jun  5 15:22:03 1991
 */ 

extern BOOL luther_fail PROTO((Argproto));
extern BOOL luther_true PROTO((Argproto));
extern BOOL luther_name PROTO((Argproto));
extern BOOL luther_number_chars PROTO((Argproto));
extern BOOL luther_atom_chars PROTO((Argproto));
extern BOOL luther_halt PROTO((Argproto));
extern BOOL luther_version PROTO((Argproto));
extern BOOL luther_debug PROTO((Argproto));
extern BOOL luther_prolog_debug PROTO((Argproto));
extern BOOL luther_par_debug PROTO((Argproto));
extern BOOL luther_nodebug PROTO((Argproto));
extern BOOL luther_topchoice PROTO((Argproto));
extern BOOL luther_unique_name PROTO((Argproto));
extern BOOL luther_setarg PROTO((Argproto));
extern BOOL luther_assert_delete_other PROTO((Argproto));
extern BOOL luther_asserta PROTO((Argproto));
extern BOOL luther_assertz PROTO((Argproto));
extern BOOL luther_clause PROTO((Argproto));
extern BOOL luther_clause_noref PROTO((Argproto));
extern BOOL luther_erase PROTO((Argproto));
extern BOOL luther_retry_choice PROTO((Argproto));
extern BOOL luther_retry_cut PROTO((Argproto));
extern BOOL luther_set_spy PROTO((Argproto));
extern BOOL luther_remove_spy PROTO((Argproto));
extern BOOL luther_d_trace PROTO((Argproto));
extern BOOL luther_trace PROTO((Argproto));
extern BOOL luther_notrace PROTO((Argproto));
extern BOOL luther_get_trace_level PROTO((Argproto));
extern BOOL luther_set_inc_trace_level PROTO((Argproto));
extern BOOL luther_set_dec_trace_level PROTO((Argproto));
extern BOOL luther_save_choice PROTO((Argproto));
extern BOOL luther_get_saved_choice PROTO((Argproto));
extern BOOL luther_current_predicate PROTO((Argproto));
extern BOOL luther_curr_pred PROTO((Argproto));
extern BOOL luther_file_mod_time PROTO((Argproto));
extern BOOL luther_set_module PROTO((Argproto));
extern BOOL luther_public PROTO((Argproto));
extern BOOL luther_reduce PROTO((Argproto));
extern BOOL luther_predicate_property PROTO((Argproto));
extern BOOL luther_copy_term PROTO((Argproto));
extern BOOL luther_atom_mode PROTO((Argproto));
extern BOOL luther_test_deref PROTO((Argproto));
extern BOOL luther_test_deref_bind PROTO((Argproto));
extern BOOL luther_trailtest PROTO((Argproto));
extern BOOL luther_trailtest2 PROTO((Argproto));
extern BOOL luther_inittest PROTO((Argproto));
extern BOOL luther_nr_workers PROTO((Argproto));
extern BOOL luther_random PROTO((Argproto));
extern BOOL luther_srandom PROTO((Argproto));
extern BOOL luther_scheduling PROTO((Argproto));
extern BOOL luther_collect_garbage PROTO((Argproto));
extern BOOL luther_prolog_flag_gc_verbose PROTO((Argproto));
extern BOOL luther_prolog_flag_load_verbose PROTO((Argproto));

extern void initialize_flags PROTO((worker *));
extern void init_backtrackable_c PROTO((worker *));

extern void luther_copy_args PROTO((int,TAGGED *,TAGGED *,TAGGED *,worker *));

