/*    File:	 display.h 
 *    Author:	 Johan Bevemyr
 *    Created:	 Tue Jun  4 18:37:58 1991
 */ 

/* functions declared in display.c */

extern void display_term PROTO((FILE *, TAGGED, worker *));
extern void write_term PROTO((FILE *, TAGGED, worker *));

