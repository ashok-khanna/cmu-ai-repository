/*    File:	 engine_threaded.c  
 *    Author:	 Johan Bevemyr
 *    Created:	 Wed Apr 14 15:52:24 1993
 *    Purpose:   Threaded code support.
 */ 

#ifdef THREADED_CODE /* ---------------------------------------- */

#undef Inst_Def
#define Inst_Def(X,Y,Z) &&Y,

  /* define label table */

  static c_address label_table[]=
  {
#include "instructions.h"
  };
  
  int writemode = FALSE;

  if(w == NULL) {
      lab_table = label_table;
      return;
  }
#endif /* THREADED_CODE ---------------------------------------- */
