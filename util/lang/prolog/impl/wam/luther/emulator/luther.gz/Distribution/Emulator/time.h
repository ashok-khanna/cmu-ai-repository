/*    File:	 time.h 
 *    Author:	 Johan Bevemyr
 *    Created:	 Mon Jun 10 12:05:33 1991
 */ 

extern long usertime PROTO((void));
extern long systime PROTO((void));
extern long pagefaults_no_io PROTO((void));
extern long pagefaults_ph_io PROTO((void));
extern long file_mod_time PROTO((char *));
extern double walltime PROTO((void));
