/*    File:	 parallel.h  (~bevemyr/Luther2/SharedEmulator/parallel.h)
 *    Author:	 Johan Bevemyr
 *    Created:	 Wed Apr 14 16:24:29 1993
 *    Purpose:   
 */ 


#ifdef PARALLEL /* ---------------------------------------- */

#define Report_Global_Fail w->global->global_fail = TRUE

#else /* PARALLEL  ---------------------------------------- */

#define Report_Global_Fail 

#endif /* PARALLEL ---------------------------------------- */
