/*    File:	 think.h
 *    Author:	 Jonas Barklund
 *    Created:	 Thu Sep 3 08:46 1992
 *    Purpose: To provide Think C specific things, or kludges.
 */ 

#ifdef THINK_C
extern long usertime PROTO((void));
extern long systime PROTO((void));
extern char *get_application_name PROTO((char *));
#endif
