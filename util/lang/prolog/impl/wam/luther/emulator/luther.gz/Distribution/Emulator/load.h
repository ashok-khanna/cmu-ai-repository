/*    File:	 load.h 
 *    Author:	 Johan Bevemyr
 *    Created:	 Sun Jun  2 17:42:14 1991
 */ 

extern void load PROTO((FILE *, worker *));
extern BOOL luther_load PROTO((Argproto));
