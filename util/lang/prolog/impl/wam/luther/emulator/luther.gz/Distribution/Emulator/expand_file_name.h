/*    File:	 expand_file_name.h  
 *    Author:	 Johan Bevemyr
 *    Created:	 Thu Jul  4 13:15:22 1991
 */ 

BOOL expand_file_name PROTO((char *, char *));
