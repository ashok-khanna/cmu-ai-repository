/*    File:	 initial.h  
 *    Author:	 Johan Bevemyr
 *    Created:	 Tue Jun  4 17:43:33 1991
 */ 

extern int tracing;

extern int verbose;

extern float ticks_per_msecond;

extern TAGGED atom_nil;		        /* "[]"     */
extern TAGGED atom_list;		/* "."      */
extern TAGGED functor_list;             /* "."/2    */
extern TAGGED atom_user_input;		/* "user_input"  */ 
extern TAGGED atom_user_output;	        /* "user_output" */
extern TAGGED atom_user_error;		/* "user_error"  */
extern TAGGED atom_user;		/* "user"   */
extern TAGGED atom_r;			/* "r"      */
extern TAGGED atom_w;			/* "w"      */
extern TAGGED atom_fail;		/* "fail"   */
extern TAGGED atom_true;		/* "true"   */
extern TAGGED atom_equal;               /* "="      */
extern TAGGED atom_less;                /* "<"      */
extern TAGGED atom_greater;             /* ">"      */
extern TAGGED default_prefix;           /* "$new"   */
extern TAGGED prompt;                   /* "|: "    */
extern TAGGED functor_d_stream;         /* "$stream/1 */ 
extern TAGGED functor_d_ref;            /* "$ref/2" */

extern TAGGED module_prolog;            /* "prolog" */
extern TAGGED module_public;            /* "public" */
extern TAGGED module_user;              /* "user"   */

extern int orig_nr_of_workers;

extern worker *initialize PROTO((int));
extern void init_predefined_atoms PROTO((void));
extern void initialize_builtin PROTO((worker *));
extern void init_wam PROTO((worker *));
extern void reinitialize_stack PROTO((worker *));
extern void reinitialize PROTO((worker *));
