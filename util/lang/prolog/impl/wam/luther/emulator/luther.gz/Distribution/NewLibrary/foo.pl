
query :-
	'$choice'(C),
	init_trace(C),
	'$prompt'(Old,'| ?- '),
	read_with_dictionary(Query,Vars),
	'$prompt'(_,Old),
	'$topchoice'(Ch),
	trace_body(Query,Ch),
	write_vars(Vars),
	get_more(Vars),
	nl,
	write('yes'),nl,
	!,fail.

query :- nl, write('no'), nl, fail.
