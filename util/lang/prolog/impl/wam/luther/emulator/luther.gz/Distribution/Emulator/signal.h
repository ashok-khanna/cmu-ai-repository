/*    File:	 signal.h  (~bevemyr/Luther2/SharedEmulator/signal.h)
 *    Author:	 Johan Bevemyr
 *    Created:	 Tue Jun 29 12:38:53 1993
 *    Purpose:   Signal handeling.
 */ 


extern void install_sigvec PROTO((int, void (*func)()));
extern void interrupt_handler PROTO((int));
extern void init_my_getchar PROTO((void));
extern int my_getchar PROTO((void));
extern void readstring PROTO((char *));
