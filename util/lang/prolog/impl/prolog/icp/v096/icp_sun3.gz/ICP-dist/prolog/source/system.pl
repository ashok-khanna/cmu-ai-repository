/* Copyright (C) 1992 Imperial College */
/* Note that all files loaded by boot*.pl are system anyway */

:- dynamic system_file/1.

system_file(make).
system_file(tracer).
system_file(tcp).
system_file(mailbox).
