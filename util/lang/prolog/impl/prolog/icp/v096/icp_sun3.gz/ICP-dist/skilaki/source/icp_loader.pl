%** icp_loader
/*******************************************************************************
Copyright (C) 1992, Yannis Cosmadopoulos and Marek Sergot. All rights reserved.
*******************************************************************************/

skilaki_files(pi, [
	ask,
	builtins,
	explain_failure,
	lemmas,
	negation,
	pi_compiler,
	query,
	residue,
	runtime,
	stubs,
	translator,
	utilities

]).

skilaki_files(icp, [
	icp_compat,
	icp_tty,
	icp_comp
]).

skilaki_files(demo, [
	chan,
	drugs
]).

load_files :-
	skilaki_files(pi, F),
	load_files(F),
	skilaki_files(icp, FP),
	load_files(FP).

load_files([]).
load_files([File|R]) :-
	load(File),
	load_files(R).

load_eg_files :-
	load(meta_decl),
	skilaki_files(demo, FD),
	load_files(FD).

init :-
	% setCompilerOptions([error_handler], [off], _),
	resetCompiler.

?- load_files.
?- init.
?- load_eg_files.
%?- menu.
