%** builtins
/*******************************************************************************
Copyright (C) 1992, Yannis Cosmadopoulos and Marek Sergot. All rights reserved.
*******************************************************************************/

do_builtin(on, Test, Goal, assumed(Goal), q(PQi-NQi,Qo)) :-
	call(Test), !,
	reduceResidue(qualification, [builtin(Goal)|PQi]-NQi, Qo).
do_builtin(_, _, Goal, builtin(Goal), q(Q,Q)) :-
	call(Goal).

builtinResidue(A<B, (var(A);var(B))).
builtinResidue(A>B, (var(A);var(B))).
builtinResidue(A>=B, (var(A);var(B))).
builtinResidue(A=<B, (var(A);var(B))).
builtinResidue(A@<B, (var(A);var(B))).
builtinResidue(A@>B, (var(A);var(B))).
builtinResidue(A@>=B, (var(A);var(B))).
builtinResidue(A@=<B, (var(A);var(B))).
builtinResidue(A=B, (\+ (A==B), \+ \+ (A=B))).
builtinResidue(A==B, (\+ (A==B), (A=B))).
builtinResidue(is(_,B), (\+ varsin(B,[]))).
builtinResidue(var(A), var(A)).

