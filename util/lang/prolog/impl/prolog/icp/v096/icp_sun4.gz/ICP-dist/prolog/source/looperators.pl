/*****************************************************************************
LOGIC & OBJECTS ------------- IC PROLOG ][ version

written by F.G.McCabe (fgm@doc.ic.ac.uk)
modified for IC PROLOG ][ by Z.Bobolakis (zb@doc.ic.ac.uk)
last modified: 25 Jan 1993

Logic Programming Section
Dept. of Computing
Imperial College
London
******************************************************************************/

% L&O File

?-op(699,xfx,':').   % labelled call operator
?-op(699,fx,':').    % super synonym
?-op(699,xfx,&^).    % filter broadcast
?-op(700,xfx,'&:').  % and_cast operator
?-op(700,xfx,\:).  % or_cast operator
?-op(700,xfx,':=').  % assignment operator
?-op(1200,yfy,'. '). % clause separator in a class body.
?-op(1200,xfy,'..'). % alternative clause separator in a class body.
?-op(1199,xfx,(':-')). % redefine the arrow operator to avoid operator clashes
?-op(1199,fx,(':-')).
?-op(1198,xfx,'<='). % class rule operator
?-op(1198,xfx,'<<'). % class rule operator
?-op(700,xfx,on).
?-op(698,fx,`).	     % back-quote used for escaping functional interpretation
?-op(698,fx,#).	     % anti-quote operator
?-op(698,fx,`#).     % quote-hash quote the function symbol only
?-op(1198,xf,'=?').  % evaluate an expression
?-op(1198,xfx,'=?'). % binary version of it
?-op(10,yf,s).     % used to display seconds in a nice way
