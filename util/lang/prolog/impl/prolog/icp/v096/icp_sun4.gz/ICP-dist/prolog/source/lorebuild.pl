?- make(lorebuild).

?- make(looperators).
?- load(looperators).

?- make(lo).

?- make(lodynamic).

?- make(loenv).

?- make(loexpressions).

?- make(lolow_level).

?- make(lotop).

?- make(lotracing).

?- make(lotranslator).

?- make(gnu).
