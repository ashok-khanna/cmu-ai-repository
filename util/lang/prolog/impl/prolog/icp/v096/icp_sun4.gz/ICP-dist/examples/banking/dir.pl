dir_put(S,M,P) :-
%	set_prop(dir, S, M(P)).
	asserta(dir(S, M, P)).

dir_get(S,M,P) :-
%	get_prop(dir, S, Val), Val = M(P).
	dir(S, M, P).

dir_del(S) :-
%	del_prop(dir, S).
	retract(dir(S, _, _)).

dir_save.
%dir_save :-
%	save(dir/3, banks).

dir_load.
%dir_load :-
%	unix('touch banks.icp'),
%	load(banks).

dir_list :-
	listing(dir/3).
