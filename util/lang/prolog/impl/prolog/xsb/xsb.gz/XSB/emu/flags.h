/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/
/*======================================================================
  File			:  flags.h
  Author(s)		:  Jiyang Xu
  Last modification	:  April 1993
========================================================================*/

/* --------system flags ---------------------------------------------------*/

/*	used by interpreter ->  Y/N ; read only -> R/W/N (no access)	   */
#define PIL_TRACE 	0	/* 0 = pil trace off, 1 = on		YW */
#define HITRACE		1	/* 0 = hitrace off, 1 = on		YW */
#define OVERFLOW_F	2	/* 1 = ignore stack overflow		YW */
#define TRACE_STA	3	/* 1 = keep max stack size stats	YW */
#define DEBUG_ON	4	/* 1 = debug on; 0 = off 		YW */
#define HIDE_STATE	5	/* 0 = no hide, >0 = hide level 	YW */
#define TRACE		6	/* 1 = trace on, 0 = trace off	    	YW */
#define INVOKE_NUM	7	/* debugger, the ordinal invoke number 	NW */
#define SKIPPING	8	/* debugger, 1 = skip, 0 = not	   	NW */
#define QUASI_SKIPPING	9	/*   debugger, 1 = quasi skip		NW */
#define CURRENT_INPUT	10	/* current input file descripter	NW */
#define CURRENT_OUTPUT	11	/* current output file descripter	NW */
#define CURRENT_MODULE	12	/* current module			YW */
#define MOD_LIST	13	/* the list of module (Psc) entries	YR */
#define RELOC_TABLE	14	/* relocation table			YR */
#define HASH_TABLE	15	/* hash_table				YR */
#define VERSION_MAJOR	16	/* the major version number	    	YR */
#define VERSION_MINOR	17	/* the minor version number	    	YR */
#define VERSION_WORD	18	/* 1-single, 2-one&half, 3-double	YR */
#define VERSION_MODE	19	/* 1-optimal, 2-debug, 3-measure	YR */
#define VERSION_PARA	20	/* 1-seqtl, 2-uniprocr, 3-multiprocr  	YR */
#define VERSION_PROCR	21	/* Number of processors		    	YR */
#define VERSION_DATE	22	/* emulator creation date (0xyyyymmdd)	YR */
#define INSTALL_DIR	23	/* directory of the current PSB-Prolog	YR */
#define CLAUSE_INT	24	/* for clause interrupt			YW */
/* #define GET_WORKER	24	 private!	Not used		   */
#define WOKEN_DELAY	25	/* Woken delayed goals: private/writable!  */
#define DELAY_HEAD_PTR	26	/* the list of delayed goals		YR */
#define MACHINE		27	/* 1-sun, 2-sequent 3-NeXT      	YR */
#define PIL_STEP	28	/* 0-no stop on pil trace 1-stop	YN */
#define CALL_STEP	29	/* 0-no stop on call trace 1-stop	YN */
#define THREAD_STEP	30	/* 0-no stop on thread trace 1-stop	YN */
#define SHOWTHREAD	31	/* internal debugging			YN */

/* 
 * Added 
 */
#define USER_HOME	49	/* User's home directory		YR */
#define LIBS_LOADED	50	/* 0=default libpath, 1=user+def libpathYW */
#define XTRACEFLAG      51
#define PROFFLAG        52

extern byte disassem;	/* command line option */
extern byte call_intercept; /* hitrace or trace_sta for efficiency */

extern word flags[];		/* System flags + user flags */
