/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File			:  xinst_fun.c
  Author(s)		:  Terrance Swift
  Last modification	:  July 1993
======================================================================*/

#include <stdio.h>
#include "config_make.h"
#include "aux.h"
#include "cell.h"
#include "register.h"
#include "binding.h"
#include "memory.h"
#include "choice.h"
#include "deref.h"
#include "psc.h"
#include "flags.h"
#include "xmacro.h"
#include "subinst.h"

extern int variant_check_num, macroprint, ctr;
extern CPtr threg1, pdlreg1, hreg1, xtemp12;
extern CPtr * xtrbase;
extern int  subinstprofile;


savecallinfo_fun1(arity,from_addr)
CPtr from_addr;
{
  int i,j;
  register CPtr xtemp1;
  Cell xtemp4;

  saveinfo(arity,from_addr,tabreg,+,pcreg);
}
