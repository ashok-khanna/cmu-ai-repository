/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File                  :  inst.c
  Author(s)		:  Terrance Swift
  Last modification	:  Aug 1993
======================================================================*/

#define LOAD_SOLUTION 0
#define SAVEINFO 1
#define VARIANT  2
#define HQS      3
#define RECVARIANT 4
#define QS       5
#define RECLOAD  6

extern subinst_table[256][2];


