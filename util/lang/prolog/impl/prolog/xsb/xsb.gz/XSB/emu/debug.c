/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File                  :  debug.c
  Author(s)		:  Terrance Swift, Jiyang Xu
  Modified by		:  Kostis Sagonas
  Last modification	:  July, 1993
========================================================================*/

#include "config_make.h"
#include "aux.h"
#include <stdio.h>
#include "binding.h"
#include "cell.h"
#include "psc.h"
#include "memory.h"
#include "flags.h"
#include "register.h"
#include "deref.h"
#include "xmacro.h"
#include "choice.h"
#include "inst.h"

int pil_step = 1;
int call_step = 0;
int debug_ctr = 0;
int hitrace_suspend = 0;
int print_hide = 0;
int register_watch_flag = 0;
int memory_watch_flag = 0;

extern int table_num;
extern int level_num;
extern int xctr;

#define STRIDESIZE 50
#define OVERLAP 20
#define CAR 	      1
#define CDR	      0
/*define TRACEFILE */

#ifdef TRACEFILE
FILE *tracefile;
#define outfile tracefile
#else
#define outfile stdout
#endif


/*======================================================================*/
/*  The following are possibly used both for tracing and by XSB		*/
/*  developers during debugging.					*/
/*======================================================================*/

#if (defined(TRACING) || defined(DEBUG))

/* used only for prints */
#define printderef(op) while (isref(op) && op > 0) { \
			if (op==follow(op)) break; op=follow(op); }

debug_call(psc)
Psc psc;
{
#ifdef TRACEFILE
    print_call(psc);
#else
    if (call_step || get_spy(psc)) {
	print_call(psc);
#ifdef DEBUG
	debug_interact();
#endif
    } else if (!hitrace_suspend) print_call(psc);
#endif
}

print_call(psc)
Psc psc;
{
  int i;
  fprintf(outfile, "(w1) call: %s(", get_name(psc));
  for (i=1; i <= get_arity(psc); i++) {
    printterm(cell(reg+i), 1, 3);
    if (i < get_arity(psc)) fprintf(outfile, ",");
  }
  fprintf(outfile, ")\n");
  fflush(outfile);
}

printterm(term, car, level)
Cell term;
byte car;
{
    unsigned short i, arity1;
    struct psc_rec *psc_ptr1;
    CPtr cptr1;
    if (level-- < 0) { fprintf(outfile, "..."); return; }
      printderef(term);
      switch (cell_tag(term)) {
      case FREE:  case REF1: case REF2: case REF3: 
	fprintf(outfile, "_%x", vptr(term));
	return;
      case DELAY:
	fprintf(outfile, "DELAY");
	return;
      case CS: case TABSTRCT:
	psc_ptr1 = get_str_psc(term);
	fflush(outfile); 
	fprintf(outfile, "%s", get_name(psc_ptr1));
	if ( get_arity(psc_ptr1) == 0 ) return;   /* constant */
	/* structure */
	fprintf(outfile, "(");
	arity1 = ( get_arity(psc_ptr1) );
	    cptr1 = (CPtr)cs_val(term);
	    for ( i = 1; i <= arity1; i++ ) {
		printterm(cell(cptr1+i), CAR, level);
                if (i<arity1) fprintf(outfile, ",");
	    }
	    fprintf(outfile, ")");
            /* fflush(outfile); */
            return;
	case STRING:
	    if (string_val(term)) fprintf(outfile, "\"%s\"", string_val(term));
	    else fprintf(outfile, "\"\"");
	    break;
	case INT:
	    fprintf(outfile, "%d", int_val(term));
	    return;
	case FLOAT:
	    fprintf(outfile, "%f", float_val(term));
	    return;
	case DVAR:
#ifdef DOMAIN
	    if (cell((CPtr)domain_val(term))!=term) {
	      term = cell((CPtr)domain_val(term));
	      goto ptd;
	    }
	    dom_print(outfile, domain_val(term));
	    break;
#else
	    printf("DVAR\n"); exit(0);
#endif
      case LIST: case TABLIST:
	    cptr1 = clref_val(term);
	    if ( car ) fprintf(outfile, "[");
	    printterm(cell(cptr1), CAR, level);
	    term = cell(cptr1+1);
	    DEREF(term, ldp)		/* term is not in register */
		/* case FREE: */
	            goto vertbar;
		    break;
		case DELAY:
		    goto vertbar;
		    break;
                case LIST: case TABLIST:
		    fprintf(outfile, ",");
		    printterm(term, CDR, level);
		    return;
	        case STRING:
		    if (string_val(term)) goto vertbar;
		    else { fprintf(outfile, "]"); return; }
		    break;
                case CS: case TABSTRCT:
		    if (isnil(term)) {    /* term is the 'nil' constant */
			fprintf(outfile, "]");
			/* fflush(outfile); */
			return;
		    }     /* else fall through to the vert bar case */
	        case INT:
		case FLOAT:
		    vertbar:
		    fprintf(outfile, "|");
		    printterm(term, CAR, level);
		    fprintf(outfile, "]");
		    /* fflush(outfile); */
		    return;
		case DVAR:
		    if (cell((CPtr)domain_val(term))!=term) {
		      term = cell((CPtr)domain_val(term));
		      goto ldp;
		    }
		    goto vertbar;
      }
    }
}

#endif /* defined(TRACING) || defined(DEBUG)) */

/*======================================================================*/
/*  The following till the end of file are used only by XSB developers	*/
/*  during debugging.							*/
/*======================================================================*/

#ifdef DEBUG

struct watch_struct {
  int heap_flag;
  CPtr heap_val;
  int stack_flag;
  CPtr stack_val;
  int choice_flag;
  CPtr choice_val;
  int trail_flag;
  CPtr trail_val;
} reg_watch,mem_watch;

/*======================================================================*/
print_help()
{
  printf("      a r/v/d/a/i <addr>: inspect the content of the address\n");
  printf("      b <module> <name> <arity>: spy the predicate\n");
  printf("      c: print top of choice point stacks\n");
  printf("      e: print top of environment stack\n");
  printf("      f: print choice point stacks (around bfreg)\n");
  printf("      h: help\n");
  printf("      k <int>: print and skip <int> lines\n");
  printf("      K <int>: skip <int> lines\n");
  printf("      i: print top of table index\n");
  printf("      l: leap to the next spy point\n");
  printf("      n: leap to the next call\n");
  printf("      p print top of heap");
  printf("      P print PDLSTK");
  printf("      q: quit\n");
  printf("      r <num>: print register <num> as term\n");
  printf("      R <num>: print register <num> as ptr\n");
  printf("      s: single instruction\n");
  printf("      t: print top of trail\n");
  printf("      u <name> <arity>: unspy the predicate\n");
  printf("      v <num>: print variable <num>\n");
  printf("      w <num>: change to worker <num>\n");
  printf("      L: same as 'l', but does not print intermediate info\n");
  printf("      N: nodebugging, continue to the end\n");
  printf("      S: print status registers\n");
  printf("      1: print top of (persistant) table stack\n");
  printf("      2: print top of table heap\n");
  printf("      3 <num> print val of table pointer\n");
}
/*======================================================================*/

debug_inst(lpcreg, le_reg)
byte *lpcreg;
CPtr le_reg;
{
#ifdef TRACEFILE
  print_inst(outfile, lpcreg);
#else
  if (!print_hide) {
        printf("xctr %d ",xctr);
	print_inst(outfile, lpcreg);
      }
  if (register_watch_flag) monitor_register_watch();
  if (memory_watch_flag) monitor_memory_watch();
  if (pil_step && debug_ctr == 0) {
    print_hide = 0;
    pcreg = lpcreg; ereg = le_reg;
    debug_interact();
  }
  else { 
    if (debug_ctr > 0) debug_ctr--;
    else 
      if (call_step == 1 && *lpcreg == call) {
	pil_step = 1;
	debug_interact();
      }
  }
#endif
}

xdebug_inst(lpcreg, le_reg)
byte *lpcreg;
CPtr le_reg;
{
  if (!print_hide) {
    printf("xctr %d ",xctr);
    print_inst(outfile, lpcreg);
    printf("rwf %d\n",register_watch_flag);
  }
  if (register_watch_flag) monitor_register_watch();
  if (memory_watch_flag) monitor_memory_watch();
  if (pil_step && debug_ctr == 0) {
    print_hide = 0;
    pcreg = lpcreg; ereg = le_reg;
    debug_interact();
  }
  else { 
    if (debug_ctr > 0) debug_ctr--;
    else if (call_step == 1 && *lpcreg == call) {
      pil_step = 1;
      debug_interact();
    }
  }
}

debug_subinst(lpcreg, le_reg,Inst, arg1, arg2)
char *Inst;
byte *lpcreg;
CPtr le_reg, arg1, arg2;
{
  if (!print_hide) {
        printf("xctr %d ",xctr);
	printf("%s, %x, %x\n",Inst,arg1,arg2);
      }
  if (register_watch_flag) monitor_register_watch();
  if (memory_watch_flag) monitor_memory_watch();
  if (pil_step && debug_ctr == 0) {
    print_hide = 0;
    pcreg = lpcreg; 
    ereg = le_reg;
    debug_interact();
  }
  else { 
    if (debug_ctr > 0) debug_ctr--;
    else 
      if (call_step == 1 && *lpcreg == call) {
	pil_step = 1;
	debug_interact();
      }
  }
}

debug_interact()
{
  char c, mod[32], name[32];
  int num, num1, *nptr;
  Cell term;
  Pair sym;

  again:
    fflush(outfile);
    scanf("%c", &c);
    switch (c) {
    case 'a': scanf("%s %x", name, &num); skip_line();  
      switch (name[0]) {
        case 'a': printf("0x%x: 0x%x\n", num, *(int *)num); break;
	case 'r': print_cell("Reg", num, cell(reg+num)); break;
	case 'v': print_cell("Var", num, cell(ereg-num)); break;
	case 'd': print_cell("Addr", num, cell((CPtr)(num))); break;
	}
      goto again;
    case 'b': scanf("%s %s %d", mod, name, &num); skip_line();
      sym = (Pair)insert_module(0, mod);
      sym = (Pair)insert(name,num, sym->psc_ptr, &num);
      set_spy(sym->psc_ptr, 0x80);
      goto again;
    case 'c': print_choice_points();
      skip_line(); 
      goto again;
    case 'C': print_freeze_choice_points();
      skip_line(); 
      goto again;
    case 'd': dis(1);
      skip_line();
      goto again;
    case 'e': print_local_stack();
      skip_line();
      goto again;
    case 'h': print_help(); skip_line();
      goto again;
    case 'k': scanf("%d", &num); skip_line();  
      debug_ctr = num;
      break;
    case 'K': scanf("%d", &num); skip_line();  
      debug_ctr = num; print_hide = 1;
      break;
    case 'l': pil_step = 0; call_step = 0; skip_line();  
      hitrace_suspend = 0; break;
    case 'L': skip_line(); pil_step = 0; flags[PIL_TRACE] = 0; call_step = 0; 
      hitrace_suspend = 1; break;
    case 'n': pil_step = 0; call_step = 1; hitrace_suspend = 0;
      skip_line(); break;
    case 'N': pil_step = 0; flags[PIL_TRACE] = 0; flags[HITRACE]= 0; 
      call_step = 0; skip_line(); break;
    case 'o': print_opentables();
      skip_line();
      goto again;
    case 'p': i_print_heap();
      skip_line();
      goto again;
    case 'P': print_pdlstack();
      skip_line();
      goto again;
    case 'q': quit("Aborted by the user"); break;
    case 'r': scanf("%d", &num); skip_line(); printf("Reg[%d] = ", num);
      printterm(cell(reg+num), 1, 8); printf("\n"); 
      printf("%x\n",*(reg+num));goto again;
    case 'R': scanf("%d", &num); skip_line(); 
      printf("Reg[%d] = %x\n",num,*(reg+num));goto again;
    case 's': pil_step = 1; flags[PIL_TRACE] = 1; skip_line(); 
          hitrace_suspend = 0; break;
    case 'S': print_status();
      skip_line(); 
      goto again;
    case 'v': scanf("%d", &num); skip_line();  printf("Var[%d] = ", num);
      printterm(cell(ereg-num), 1, 8); printf("\n"); goto again;
    case 't': print_trail();
      skip_line();
      goto again;
    case 'u': scanf("%s %s %d", mod, name, &num); skip_line();
      sym = (Pair)insert_module(0, mod);
      sym = (Pair)insert(name,num, sym->psc_ptr, &num);
      set_spy(sym->psc_ptr, 0x00);
      goto again;
    case '\n': break;
    case 'w':
      scanf("%d %x", &num1,&num); 
      set_register_watch(num1,num);
      skip_line();
      goto again;      
    case 'W':
      scanf("%x %x", &num1,&num); 
      set_memory_watch(num1,num);
      skip_line();
      goto again;      
#ifdef XWAM
    case '1': i_print_tables();
      skip_line();
      goto again;
    case '2': print_table_heap();
      skip_line();
      goto again;
    case '3': scanf("%d",&num);
      skip_line();
      printf("tabptr: 0x%x tabptrval: 0x%x\n",
	         ((CPtr) (main_thread->memory)) + num,
	         *(((CPtr) main_thread->memory) + num));
      goto again;
#endif
    default: printf("Unknown command\n"); skip_line(); goto again;
    }
  return;
}

set_register_watch(num1,num2)
int num1;
CPtr num2;
{
  register_watch_flag = 1;
  switch (num1) {
    case 1: 
      reg_watch.heap_flag = 1;
      reg_watch.heap_val = num2;
      break;
    case 2: 
      reg_watch.stack_flag = 1;
      reg_watch.stack_val = num2;
      break;
    case 3: 
      reg_watch.choice_flag = 1;
      reg_watch.choice_val = num2;
      break;
    case 4: 
      reg_watch.trail_flag = 1;
      reg_watch.trail_val = num2;
      break;
    }
}

monitor_register_watch()
{
  if (reg_watch.heap_flag) 
    if (reg_watch.heap_val == hreg)
      printf("!!! hreg == %x, %d\n",hreg,xctr);
  if (reg_watch.stack_flag) 
    if (reg_watch.stack_val == ereg)
      printf("!!! ereg == %x, %d\n",ereg,xctr);
  if (reg_watch.choice_flag) 
    if (reg_watch.choice_val == breg)
      printf("!!! choice == %x, %d\n",breg,xctr);
  if (reg_watch.trail_flag) 
    if ((CPtr *) reg_watch.trail_val == trreg)
      printf("!!! trreg == %x, %d\n",trreg,xctr);
}

set_memory_watch(num1,num2)
int num1;
int num2;
{
  memory_watch_flag = 1;
  switch (num1) {
    case 1: 
      mem_watch.heap_flag = num2;
      mem_watch.heap_val = *(CPtr *) num2;
      break;
    case 2: 
      mem_watch.stack_flag = num2;
      mem_watch.stack_val = *(CPtr *) num2;
      break;
    case 3: 
      mem_watch.choice_flag = num2;
      mem_watch.choice_val = *(CPtr *) num2;
      break;
    case 4: 
      mem_watch.trail_flag = num2;
      mem_watch.trail_val = *(CPtr *) num2;
      break;
    }
}

monitor_memory_watch()
{
  if (mem_watch.heap_flag)
  if (*(CPtr *) mem_watch.heap_flag != mem_watch.heap_val) {
    printf("Heap watch val %x was %x is now %x, xctr %d\n",
	     mem_watch.heap_flag,mem_watch.heap_val,
	     *(CPtr) mem_watch.heap_flag,xctr);
    mem_watch.heap_val = *(CPtr *) mem_watch.heap_flag;
  }
  if (mem_watch.stack_flag)
  if (*(CPtr *) mem_watch.stack_flag != mem_watch.stack_val) {
    printf("Stack watch val %x was %x is now %x, xctr %d\n",
	     mem_watch.stack_flag,mem_watch.stack_val,
	     *(CPtr) mem_watch.stack_flag,xctr);
    mem_watch.stack_val = *(CPtr *) mem_watch.stack_flag;
  }
  if (mem_watch.choice_flag)
  if (*(CPtr *) mem_watch.choice_flag != mem_watch.choice_val) {
    printf("Choice watch val %x was %x is now %x, xctr %d\n",
	     mem_watch.choice_flag,mem_watch.choice_val,
	     *(CPtr) mem_watch.choice_flag,xctr);
    mem_watch.choice_val = *(CPtr *) mem_watch.choice_flag;
  }
  if (mem_watch.trail_flag)
  if (*(CPtr *) mem_watch.trail_flag != mem_watch.trail_val) {
    printf("Trail watch val %x was %x is now %x, xctr %d\n",
	     mem_watch.trail_flag,mem_watch.trail_val,
	     *(CPtr) mem_watch.trail_flag,xctr);
    mem_watch.trail_val = *(CPtr *) mem_watch.trail_flag;
  }
}

skip_line()
{
  char c;

  do c = getchar(); while (c != '\n');
}

print_cell(addrtype, addr, term)
char *addrtype;
Cell term;
{
  switch (cell_tag(term) ) {
  case REF: printf("%s %x: REF, value=0x%x\n", addrtype, addr, ref_val(term));
    break;
  case CS: case TABSTRCT:
    printf("%s %x: CS, value=0x%x  hexval = 0x%x\n", 
	   addrtype, addr, cs_val(term),ref_val(term));break;
  case INT: printf("%s %x: INT, value=%d  hexval = 0x%x\n", addrtype, addr, 
		   int_val(term),ref_val(term)); break;
/*  case STRING: printf("%s %x: STRING, hexval = 0x%x,  value=%s\n", 
		      addrtype, addr,ref_val(term),string_val(term)); break;*/
  case STRING: printf("%s %x: STRING, hexval = 0x%x\n", 
		      addrtype, addr,ref_val(term)); break;
  case FLOAT: printf("%s %x: FLOAT, value=%f hexval = 0x%x\n", 
		     addrtype, addr, float_val(term),term); break;
  case LIST: case TABLIST:
    printf("%s %x: LIST, clref=%x, hex = %x\n", addrtype, addr, 
		     clref_val(term),ref_val(term)); break;
  default:
    printf("%s %x: tag=%d, hex=0x%x, cval = %x\n", 
	   addrtype, addr, cell_tag(term), ref_val(term),int_val(term));
    break;
  }
}

print_cp_cell(addrtype, addr, term)
char *addrtype;
Cell term;
{
  switch (cell_tag(term) ) {
  case REF: printf("%s %x: REF, value=0x%x\n", addrtype, addr, ref_val(term));
    break;
  case CS:printf("%s %x: CS, value=0x%x  hexval = 0x%x\n", 
		 addrtype, addr, cs_val(term),ref_val(term));break;
  case INT: printf("%s %x: INT, value=%d  hexval = 0x%x\n", addrtype, addr, 
		   int_val(term),ref_val(term)); break;
  case STRING: printf("%s %x: STRING, hexval = 0x%x\n", 
		      addrtype, addr,ref_val(term)); break;
  case FLOAT: printf("%s %x: FLOAT, value=%f hexval = 0x%x\n", 
		     addrtype, addr, float_val(term),string_val(term)); break;
  case LIST: printf("%s %x: LIST, value=%x\n", addrtype, addr, 
		     ref_val(term)); break;
  default:
    printf("%s %x: tag=%d, value=0x%x\n", 
	   addrtype, addr, cell_tag(term), ref_val(term));
    break;
  }
}

/* stack grows down */
#ifdef XWAM
print_local_stack()
{
  int i, offset =0;
  CPtr temp;
  char ans = 'y';

  if (ereg_on_top(ereg)) {
    temp = ereg;
    printf("ereg on top\n");
  }
  else {
    temp = ebreg;
    printf("ebreg on top\n");
  }
  for (i = -OVERLAP; (i < 0 ) ; i++ )
    {
      if ( temp+i == efreg ) printf("efreg\n");
      print_cp_cell("Stack",temp+i,cell(temp+i));
    }
  printf("top\n");
  while (ans == 'y' && temp+offset  <= (CPtr) main_thread->trail) { 
  for (i = 0; (i <= STRIDESIZE && 
	       temp+offset+i <= (CPtr )main_thread->lstack) ; i++ )
    {
      if ( temp+offset+i == ebreg ) printf("ebreg\n");
      if ( temp+offset+i == ereg ) printf("ereg\n");
      if ( temp+offset+i == efreg ) printf("efreg\n");
      print_cp_cell("Stack",temp+offset+i,cell(temp+offset+i));
      if ( temp+offset+i == (CPtr) main_thread->lstack ) printf("EOS\n");
    }
      offset += STRIDESIZE;
      printf("more?\n");
      scanf("%s",&ans);      
}
}

emb_print_local_stack(limit)
int limit;
{
  int i;
  CPtr temp;

  if (ereg_on_top(ereg)) {
    temp = ereg;
    printf("ereg on top\n");
  }
  else {
    temp = ebreg;
    printf("ebreg on top\n");
  }
  for (i = -OVERLAP; (i < 0 ) ; i++ )
    {
      if ( temp+i == efreg ) printf("efreg\n");
      print_cp_cell("Stack",temp+i,cell(temp+i));
    }
  printf("top\n");
  for (i = 0; (i <= limit && temp+i <= (CPtr )main_thread->lstack) ; i++ )
   {
      if ( temp+i == ebreg ) printf("ebreg\n");
      if ( temp+i == ereg ) printf("ereg\n");
      if ( temp+i == efreg ) printf("efreg\n");
      print_cp_cell("Stack",temp+i,cell(temp+i));
      if ( temp+i == (CPtr) main_thread->lstack ) printf("EOS\n");
    }
}
#else 
/* print local stack for non-XWAM taken out -- tls */
#endif

/* trail grows up */
print_trail()
{
  int i,offset=0;
  char ans = 'y';
  CPtr * temp;

  if ( trfreg > trreg) temp = trfreg;  else temp = trreg;
    for (i = OVERLAP; (i > 0 ) ; i-- )
      {
	if (  (temp + i)  == trreg ) printf("trreg\n");
	if (  (temp + i)  == trfreg ) printf("tfrreg\n");
	print_cell("Trail",temp + i,cell(temp + i));
       }
    while (ans == 'y' && temp-(offset)  >= (CPtr *) main_thread->trail) { 
      for (i = 0
	   ; (i <= STRIDESIZE && temp-(offset+i) >= (CPtr *)main_thread->trail)
	   ; i++ )      {
	if ( (temp - (offset+i)) == trreg ) printf("trreg\n");
	if (  (temp - (offset + i))  == trfreg ) printf("tfrreg\n");
	print_cell("Trail",(temp -(offset+i)),cell(temp - (offset+i)));
	if ( (temp - (offset+i))  == (CPtr *) main_thread->trail ) 
	  printf("bottom\n");
      }
      offset += STRIDESIZE;
      printf("more?\n");
      scanf("%s",&ans);      
    }
}

/* CPs grow down */
print_freeze_choice_points()
{
  int i,last = 0;
   char ans = 'y';
 
  for (i = -OVERLAP; (i < 0 ) ; i++ )
    {
      print_cp_cell("CP stack",bfreg + i,cell(bfreg + i));
	if (  (bfreg + i)  == breg ) printf("breg\n");
    }
  printf("bfreg\n");
  for (i = 0; (i <= STRIDESIZE && bfreg+i<=(CPtr)main_thread->opentable); i++){
    if (  (bfreg + i)  == breg ) printf("breg\n");
    print_cp_cell("CP stack",bfreg + i,*(bfreg + i));
    if (  (bfreg + i)  == (CPtr ) main_thread->opentable  ) printf("EOS\n");
    }
  printf("more?\n");
  printf("%c\n",ans);
  scanf("%s",&ans);
  while (ans == 'y' && bfreg+last < (CPtr) main_thread->opentable ) { 
  last = last+STRIDESIZE;
  for (i = last
       ; (i <= last+STRIDESIZE && bfreg+i  <= (CPtr) main_thread->opentable) 
       ; i++ ) {
    if (  (bfreg + i)  == breg ) printf("breg\n");
    print_cp_cell("CP stack",bfreg + i,*(bfreg + i));
    if (  (bfreg + i)  == (CPtr ) main_thread->opentable  ) printf("EOS\n");
    }
    printf("more?\n");
    printf("%c\n",ans);
    scanf("%s\n",&ans);
}
}

print_choice_points()
{
  int i,last =0;
   char ans = 'y';
 
  for (i = - OVERLAP ; (i < 0 ) ; i++ )
    {
	if (  (breg + i)  == bfreg ) printf("bfreg\n");
      print_cp_cell("CP stack",breg + i,cell(breg + i));
    }
  printf("breg\n");
  for (i = 0; (i <= STRIDESIZE && breg+i <= (CPtr)main_thread->opentable)
            ; i++) {
    if (  (breg + i)  == bfreg ) printf("bfreg\n");
    print_cp_cell("CP stack",breg + i,*(breg + i));
    if ( (breg + i) == (CPtr ) main_thread->opentable ) printf("EOS\n");
    }
  printf("more?\n");
  printf("%c\n",ans);
  scanf("%s",&ans);
  while (ans == 'y' && breg+last < (CPtr) main_thread->opentable ) { 
    last = last + STRIDESIZE;
    for (i = last
	 ; (i <= last+STRIDESIZE && breg+i <= (CPtr) main_thread->opentable)
	 ; i++ ) {
      if ( (breg + i)  == bfreg ) printf("bfreg\n");
      print_cp_cell("CP stack",breg + i,*(breg + i));
      if ( (breg + i)  == (CPtr) main_thread->opentable ) printf("EOS\n");
    }
    printf("more?\n");
    printf("%c\n",ans);
    scanf("%s",&ans);

  }
}

emb_print_choice_points(words)
int words;
{
  int i;
 
  for (i = -OVERLAP; (i < 0 ) ; i++ )    {
      if (  (breg + i)  == bfreg ) printf("bfreg\n");
      print_cp_cell("CP stack",breg + i,cell(breg + i));
    }
  printf("breg\n");
  for (i = 0; i <= words ; i++ ) {
    if ( (breg + i)  == bfreg ) printf("bfreg\n");
    print_cp_cell("CP stack",breg + i,*(breg + i));
    if ( (breg + i) == (CPtr ) main_thread->opentable ) printf("EOS\n");
    }
}

/* heap grows up */
/* Needs to change when new xwam stacks are introduced.  */
i_print_heap()
{
  int i, offset = 0;
   char ans = 'y';

  for (i = OVERLAP; (i > 0) ; i-- ) {
      print_cell("Heap",hreg + i,cell(hreg + i));
  }
  printf("hreg\n");
  while (ans == 'y' && hreg - i > (CPtr) main_thread->maxsusp) {
    for (i = 0
	 ;(i <= STRIDESIZE && hreg-(offset+i) >= (CPtr ) main_thread->maxsusp) 
	 ; i++ ) {
      if ( (hreg - (offset+i))  == hfreg ) printf("hfreg\n");
      if ( (hreg - (offset+i))  == hbreg ) printf("hbreg\n");
      print_cell("Heap",hreg - (offset+i),cell(hreg - (offset+i)));
      if ( (hreg-(offset+i))  == (CPtr ) main_thread->maxsusp ) 
	printf("bottom\n");
    }
    if ( (hreg-(offset+i)) != (CPtr ) main_thread->maxsusp ) {
      offset +=STRIDESIZE;
      printf("more?\n");
      scanf("%s",&ans);
    }
  }
}

print_heap()
{
  int i;

  for (i = OVERLAP; (i > 0) ; i-- ) {
      print_cell("Heap",hreg + i,cell(hreg + i));
  }
  printf("hreg\n");
  for (i = 0
       ; (i <= STRIDESIZE && hreg-i >= (CPtr) main_thread->maxsusp)
       ; i++ ) {
      if (  (hreg - i)  == hfreg ) printf("hfreg\n");
      print_cell("Heap",hreg - i,cell(hreg - i));
      if (  (hreg - i)  == (CPtr ) main_thread->maxsusp ) printf("bottom\n");
  }
}

#ifdef XWAM
 
print_opentables()
{
  CPtr temp;
  temp = openreg;
  while (temp <= OPENSTACKBOTTOM) {
      printf("opentable %x: %x\n",temp,*temp);
      temp++;
  }
}

print_pdlstack()
{
  CPtr temp;
  temp = pdlreg;
  while (temp <= (CPtr) (main_thread->pdl) -1) {
      printf("pdlstk %x: %x\n",temp,*temp);
      temp++;
  }
}
 
/* tables grow down (changed)*/
/*
print_tables()
{
  int i;

  printf("tabreg\n");
  for (i = 0; i < 1001 && tabreg+i <= (CPtr) (main_thread->maxsusp)-1; i++) {
    print_cell("Tabstk", tabreg + i, cell(tabreg+i));
    if (  (tabreg + i)  == ((CPtr ) main_thread->maxsusp) -1  ) printf("EOS\n");
  }  
}
*/

i_print_tables()
{
  int i,offset=0;
  char ans = 'y';

  printf("tabreg\n");
  while (ans == 'y' && tabreg + offset <= (CPtr) (main_thread->maxsusp)-1) {
    for (i=0
	 ; i <= 10*STRIDESIZE && threg+(offset+i) <=(CPtr)(main_thread->maxsusp)-1
	 ; i++) {
      print_cell("Tabstk", tabreg + (offset+i), cell(tabreg+(offset+i)));
      if (tabreg + (offset+i) == (CPtr)(main_thread->maxsusp)-1) 
	printf("EOS\n");
    }    
      if (  (tabreg-(offset+i)) != (CPtr) (main_thread->maxsusp)-1) {
	offset += 10*STRIDESIZE;
	printf("more?\n");
	scanf("%s",&ans);
      }
  }   
}

/* table heap grows up */
print_table_heap()
{
  int i,offset=0;
  char ans = 'y';

  printf("threg\n");
  while (ans == 'y' && threg - offset > (CPtr) main_thread->pdl) {
    for (i=0
	 ; i <= STRIDESIZE && threg-(offset+i) >= (CPtr) main_thread->pdl
	 ; i++) {
      print_cell("tableheap", threg - (offset+i), cell(threg-(offset+i)));
      if (threg - (offset+i) == (CPtr) main_thread->pdl) printf("EOS\n");
    }    
      if (  (threg-(offset+i)) != (CPtr) main_thread->pdl ) {
	offset += STRIDESIZE;
	printf("more?\n");
	scanf("%s",&ans);
      }
  }   
}

#endif

print_status()
{
  int i;

  printf("ereg: 0x%x\n", ereg);
  printf("ebreg: 0x%x\n", ebreg);
  printf("breg: 0x%x\n", breg);
  printf("hreg: 0x%x\n", hreg);
  printf("hbreg: 0x%x\n", hbreg);
  printf("trreg: 0x%x\n", trreg);
  printf("cpreg: 0x%x\n", cpreg);
  printf("pcreg: 0x%x\n", pcreg);
#ifdef XWAM
  printf("efreg: 0x%x\n",efreg);
  printf("bfreg: 0x%x\n",bfreg);
  printf("hfreg: 0x%x\n",hfreg);
  printf("trfreg: 0x%x\n",trfreg);
  printf("tabreg: 0x%x\n",tabreg);
  printf("threg: 0x%x\n",threg);
  printf("pdlreg: 0x%x\n",pdlreg);
  printf("level_num: 0x%d\n",level_num);
#endif
}

init_tracefile(nprocs)
{
#ifdef TRACEFILE
    tracefile = fopen("tracefile", "w");
#endif
}

pofsprint(base,arity)
int arity;
CPtr base;
{     
  CPtr arg_ptr = base;
  Cell temp_arg_ptr;
  int varnum,i;

  printf("( ");
  for ( arg_ptr = base - 1; arg_ptr >= base - arity; arg_ptr--) {
    printterm((Cell) arg_ptr,(byte) 1,8);
    if (arg_ptr != base - arity )
      printf(",");
  }
    printf(")\n");
}

nofsprint(base,arity)
int arity;
CPtr base;
{     
  CPtr arg_ptr = base;
  Cell temp_arg_ptr;
  int varnum,i;

  printf("( ");
  for ( arg_ptr = base + 1 ; arg_ptr <= base + arity; arg_ptr++) {
    printterm((Cell) arg_ptr,(byte) 1,8);
    if (arg_ptr != base + arity )
      printf(",");
  }
    printf(")\n");
}

/***************************/
/*scaffolding*/

/* O(N*N) ! */
check_dups(ptr)
CPtr ptr;
{
CPtr ptr1;
  ptr--;
  while (ptr > hreg) {
    for (ptr1 = ptr ; ptr1 > hreg; ptr1--) {
      if (*ptr1 == *ptr) {
	printf("way too much trail\n");
	pil_step = 1;
      }
    }
    ptr--;
  }
}

#endif	/* DEBUG */

