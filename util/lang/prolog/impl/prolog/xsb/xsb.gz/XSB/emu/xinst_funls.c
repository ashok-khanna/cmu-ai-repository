/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File			:  xinst_fun.c
  Author(s)		:  Terrance Swift
  Last modification	:  July 1993
======================================================================*/

#include <stdio.h>
#include "config_make.h"
#include "aux.h"
#include "cell.h"
#include "register.h"
#include "binding.h"
#include "memory.h"
#include "choice.h"
#include "deref.h"
#include "psc.h"
#include "flags.h"
#include "xmacro.h"
#include "subinst.h"
#include "deref.h"

extern int variant_check_num, macroprint, ctr;
extern CPtr threg1, pdlreg1, hreg1, xtemp12;
extern CPtr * xtrbase;
extern int  subinstprofile;

load_solution_fun1(arity,cptr,tptr)
CPtr cptr,tptr;
{
  int i,j;
  register CPtr xtemp1, xtemp2;

   for (i =1 ; i <= (int) arity ; i++) {
     if (subinstprofile) 
       subinst_table[LOAD_SOLUTION][1] = subinst_table[LOAD_SOLUTION][1] + 1; 
     xtemp1 = (CPtr) (cptr-i);
     xtemp2 = (CPtr) (tptr - i);	
     cptr_deref(xtemp1);
     cptr_deref(xtemp2);
     switch (cell_tag(xtemp1)) { 
       case FREE: case REF1: case REF2: case REF3: 
        switch(cell_tag(xtemp2)) {
	  case FREE: case REF1: case REF2: case REF3: 
            if (xtemp2 > TableStackBarrier - 1) {
              pushtrail(xtemp1,*xtemp2);
   	      *xtemp1 = *xtemp2;
            }
            else {
              tabpushtrail0(xtemp2,*xtemp2);
              *(xtemp2) = (Cell) xtemp1;
	    }
	    break;
	  case LIST:
	    bind_list(xtemp1,hreg);
	    xtemp12 = pdlreg;
	    pdlreg1 = xtemp12;
            pdlpush(cell(clref_val(xtemp2)));
            pdlpush(cell(clref_val(xtemp2) +1));
	    hreg1 = hreg + 2;
            heap_queue_structcpy(pdlreg1,xtemp2,hreg1,pcreg);
	    pdlreg = xtemp12;
	  break;
	  case TABLIST:
	    bind_list(xtemp1,clref_val(xtemp2));
	  break;
          case STRING: case INT:
            pushtrail(xtemp1,xtemp2);
	    *(xtemp1) = (Cell)(xtemp2);
            break;
          case CS:
	    bind_cs(xtemp1,hreg);
	    xtemp12 = pdlreg;
	    pdlreg1 = xtemp12;
            pdlpush(((Cell) xtemp2 | 8));
	    for(j = 1; 
		j <= get_arity(get_str_psc(xtemp2));
		j++) {
  	    pdlpush(cell(clref_val(xtemp2) +j));
	    }
	    hreg1 = hreg+1+
            get_arity(get_str_psc(xtemp2));
            heap_queue_structcpy(pdlreg1,xtemp2,hreg1,pcreg);
	    pdlreg = xtemp12;
	     break;
	  case TABSTRCT:
	    bind_cs(xtemp1,clref_val(xtemp2));
	}
        break;
      case INT: case STRING:
	 if ( xtemp1 != xtemp2 ) {
	   printf("i: %d\n",i);
	   return_abort(xtemp1,xtemp2,"ls-int-string");
	 }
	 break;
      case LIST: 
	 if ( islist(xtemp2)) {
	   pdlpush( cell(clref_val(xtemp1)+1) );
	   pdlpush( cell(clref_val(xtemp2)+1) );
	   pdlpush( cell(clref_val(xtemp1)) );
	   pdlpush( cell(clref_val(xtemp2)) );
	   recload_solution(pcreg);
	 }
	 else {
	   if ( istablist(xtemp2)) {
	     if (clref_val(xtemp2) != clref_val(xtemp1)) {
  	       pdlpush( cell(clref_val(xtemp1)+1) );
	       pdlpush( cell(clref_val(xtemp2)+1) );
	       pdlpush( cell(clref_val(xtemp1)) );
	       pdlpush( cell(clref_val(xtemp2)) );
	       recload_solution(pcreg);
	     } 
	   }
	   else return_abort(xtemp1,xtemp2,"ls-list");
	 }
	 break; 
      case CS:
	 if ( get_str_psc(xtemp1) == get_str_psc(xtemp2)) {
	      if ( isconstr(xtemp2) ) {
		for(j=get_arity(get_str_psc(xtemp1));
		        j>=1 ; j--) {
  	           pdlpush(cell(clref_val(xtemp1) +j));
  	           pdlpush(cell(clref_val(xtemp2) +j));
		}
		recload_solution(pcreg);
	      }
	  else if ( istabstrct(xtemp2) ) {
	    if( clref_val(xtemp1) != clref_val(xtemp2) ) {
		for(j=get_arity(get_str_psc(xtemp1));
		        j>=1 ; j--) {
  	           pdlpush(cell(clref_val(xtemp1) +j));
  	           pdlpush(cell(clref_val(xtemp2) +j));
		 }
		recload_solution(pcreg);
	      }
	    }
	  }
	  else return_abort(xtemp1,xtemp2,"ls-cs");
	  break;
      case FLOAT: 
	 float_unification_exception(pcreg);
	 break;
/*	 if ( floval(xtemp1) != floval(xtemp2) ) \
	   quit("float return not loaded  Going down\n");*/ 
      case TABSTRCT:
	    bind_cs(xtemp1,clref_val(xtemp2));
      default: 
	 return_abort(xtemp1,xtemp2,"bad tag in ls");
	 break; 
     }
     }
     resetpdl;
     undo_load_solution_bindings
}
 
