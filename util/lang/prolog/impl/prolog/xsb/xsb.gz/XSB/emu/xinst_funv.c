/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File			:  xinst_fun.c
  Author(s)		:  Terrance Swift
  Last modification	:  July 1993
======================================================================*/

#include <stdio.h>
#include "config_make.h"
#include "aux.h"
#include "cell.h"
#include "register.h"
#include "binding.h"
#include "memory.h"
#include "choice.h"
#include "deref.h"
#include "psc.h"
#include "flags.h"
#include "xmacro.h"
#include "subinst.h"

extern int variant_check_num, macroprint, ctr;
extern CPtr threg1, pdlreg1, hreg1, xtemp12;
extern CPtr * xtrbase;
extern int  subinstprofile;

traverse_call_bucket(curcall_ptr,init_addr,arity,flag_ptr)
CPtr * curcall_ptr, init_addr;
int * flag_ptr;
{
  int i,j,flag;
  register CPtr curcall, xtemp1, xtemp2;

  curcall = * curcall_ptr;
  flag = 0;
  while (*curcall != 0 && !flag) {
    curcall = (CPtr) (*curcall);     
    variant(arity,init_addr,curcall-CALLSTRUCTSIZE,flag,+,pcreg);
    }                   
  * flag_ptr = flag;
  * curcall_ptr = curcall;
}
