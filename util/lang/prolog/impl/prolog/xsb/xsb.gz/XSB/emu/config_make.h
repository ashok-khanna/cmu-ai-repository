/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File                  :  config_make.h
  Author(s)		:  Kostis Sagonas
  Last modification	:  August 5, 1993
========================================================================*/

#ifndef CONFIG_INCLUDED
#define CONFIG_INCLUDED
#endif

#if (defined(SUN) || defined(SOLARIS) || defined(linux))
#define FOREIGN
#endif

#if (defined(linux) || defined(DECstation) || defined(AMIGA) || defined(IBM))
#define NO_IOB
#endif

#if (defined(SGI) || defined(DECstation))
#define MIPS_BASED
#endif

#if (defined(SOLARIS))
#define bcopy(A,B,L) memcpy(A,B,L)
#endif
