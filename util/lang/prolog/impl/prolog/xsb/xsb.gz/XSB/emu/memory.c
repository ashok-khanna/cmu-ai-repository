/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File			:  memory.c
  Author(s)		:  Swift,  Xu
  Last modification	:  April 1993
======================================================================*/

/*======================================================================*/
/* This module provides abstractions of memory management functions	*/
/* for the abstract machine. The following interface routines are	*/
/* exported:								*/
/*	Program area handling:						*/
/*	    init_pspace():	initialization				*/
/*	    mem_alloc(size):	alloc size bytes (on 8 byte boundary)	*/
/*	    mem_dealloc(addr, size):  dealloc space			*/
/*======================================================================*/

#include "config_make.h"
#include "aux.h"

extern int pp_memsize, pp_tcsize, pspacesize;
extern word *pspace;

/*======================================================*/

static int stack_used;
extern int maxstack_used;

struct mem_block {
  struct mem_block *next;
  int size;
};

 static struct mem_block *free_mem = 0;
 static struct mem_block *free_stack = 0;
 static struct mem_block *free_page = 0;

/* === alloc permanent memory ==================================*/
#define NEWSPACESIZE 16*1024

#ifdef XWAM
byte *mem_alloc(size)
{
byte * ptr;

     size = (size+7) & 0xfffffff8;	      /* truncate to 8 */
     pspacesize += size;
#ifdef MEMTRACE
     malloc_debug(2);
#endif
     ptr = (byte *) malloc(size);
     return ptr;
}
#else
byte *mem_alloc(size)
{
  struct mem_block **ptr, *tmp, *tmp2;

  size = (size+7) & 0xfffffff8;	      /* truncate to 8 */
  ptr = &free_mem;
  while (*ptr) {
    if ((*ptr)->size > size) {
      tmp = *ptr;
      tmp2 = tmp + size / sizeof(struct mem_block);
      tmp2->next = tmp->next;
      tmp2->size = tmp->size - size;
      *ptr = tmp2;
      return (byte *)tmp;
    } else if ((*ptr)->size == size) {
      tmp = *ptr;
      *ptr = tmp->next;
      return (byte *)tmp;
    } else ptr = &((*ptr)->next);
  }
  if (size >= NEWSPACESIZE) {
      pspacesize += size/1024;
      printf("big malloc-ing %d\n",size);
      return (byte *)malloc(size);
  } else {
      tmp = (struct mem_block *)malloc(NEWSPACESIZE);
      pspacesize += NEWSPACESIZE/1024;
      printf("little malloc-ing %d\n");
      tmp2 = tmp + size / sizeof(struct mem_block);
/*      tmp2->next = tmp->next;*/
      tmp2->next = 0;
      tmp2->size = NEWSPACESIZE - size;
      *ptr = tmp2;
      return (byte *)tmp;
  }
}
#endif
/* === dealloc permanent memory ==================================*/
#ifdef XWAM
mem_dealloc(addr, size)
byte *addr;
{
  pspacesize -= size;
/*  printf("%x zfree: size %x \n",addr,size);*/
  return free(addr);
}
#else
mem_dealloc(addr, size)
byte *addr;
{
  struct mem_block *tmp;

  if (size >= 8) {
    tmp = (struct mem_block *)addr;
    tmp->size = (size+7) & 0xfffffff8;		/* trancate to 8*  */
    tmp->next = free_mem;
    free_mem = tmp;
    printf("mem_dealloc called\n");
  }
}
#endif
/*=== other routines  =================================================*/

#ifndef XWAM
pspace_used()
{
  int size = 0;
  struct mem_block *ptr;

  ptr = free_mem;
  while (ptr) {
    size += ptr->size;
    printf("ptr %d next %x size %d %x\n",ptr,ptr->next,ptr->size,ptr->size);
    ptr = ptr->next;
  }
  return pspacesize*1024-size;
}
#endif

init_pspace()
{
	int i;

	free_mem = (struct mem_block *)(pspace);
	free_mem->next = 0;
	free_mem->size = pspacesize * 1024;
}
