/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File			:  psc.h
  Author(s)		:  Xu, Swift, Sagonas
  Last modification	:  April 1993
======================================================================*/


/* The abstract module for the symbol table (PSC table) */

/*======================================================================*/
/* Type definitions: Psc						*/
/*======================================================================*/

struct psc_rec {
    byte env;			/* 0 - visible; 1 - local; 2 - unloaded */
    byte entry_type;		/* see below */
    byte arity;
    byte length;
    char *nameptr;
    byte *ep;      /* entry point, various meaning */
};

typedef struct psc_rec *Psc;

/* --- Pair    -------------------------------------------- */

struct psc_pair {
    Psc psc_ptr;
    struct psc_pair *next;
};

typedef struct psc_pair *Pair;

/* === env definition: (env) ======================================*/

#define T_VISIBLE	0
#define T_HIDDEN	1
#define T_UNLOADED	2

/* === type definition: (entry_type) ===============================*/

#define T_ORDI  0	/* constant-type: no ep definition, may be set later */
#define T_DYNA	1	/* constant-type: dynamic, code in buffer */
#define T_PRED  2	/* constant-type: ep points to compiled code */
#define T_PEXI  3	/* existential pred, globalseted only, old T_BUFF */
#define T_MODU  4	/* ep field is used to hold psc-list */
#define T_FILE  5	/* ep field could be file descriptor (not now) */
#define T_CONS  6	/* pure constant, cannot be reset (may no ep) */
#define T_STRU  7	/* pure structure symbol, can't be reset (may no ep)*/
#define T_CSET  8	/* used for conset and convalue; not used in C code */
#define T_STRG	9	/* string, only used in byte code and before loading */
#define T_RKEY 10	/* record key, not directly used by the emulator */
#define T_ALIA 11	/* alias. The prop field is a term */
#define T_UDEF 12	/* unloaded T_PRED */
#define T_FORN 13	/* predicate in foreign language */
#define T_FUNC 14	/* functions */
#define T_UFUN 15	/* unloaded T_FUN */

/*======================================================================*/
/* Interface routines							*/
/*======================================================================*/

/* in the following macros , "psc" is typed "Psc" */

#define  get_type(psc)		((psc)->entry_type)
#define  get_env(psc)		((psc)->env & 0x0f)
#define  get_spy(psc)		((psc)->env & 0xf0)
#define  get_arity(psc)		((psc)->arity)
/* #define  get_length(psc)	((psc)->length) */
#define  get_ep(psc)		((psc)->ep)
#define  get_name(psc)		((psc)->nameptr)

#define  set_type(psc, type)	(psc)->entry_type = type
#define  set_env(psc, envir)	(psc)->env = get_spy(psc) | envir
#define  set_spy(psc, spy)	(psc)->env = get_env(psc) | spy
#define  set_arity(psc, ari)	((psc)->arity = ari)
#define  set_length(psc, len)	((psc)->length = len)
#define  set_ep(psc, val)	((psc)->ep = val)
#define  set_name(psc, name)	((psc)->nameptr = name)

#define  pair_psc(pair)		(pair)->psc_ptr
#define  pair_next(pair)	(pair)->next

extern Pair insert(), insert_module(), link_sym();

/*======================================================================*/
/*  Special instance (0-arity interface functions)			*/
/*======================================================================*/

shapri extern Psc global_mod;			/* PSC for "global" */
shapri extern Psc list_psc;
shapri extern Psc comma_psc;
shapri extern Pair nil_sym;
shapri extern Pair list_str;

