/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  Author(s)		:  David S. Warren, Jiyang Xu
  Modified by		:  Jiyang Xu
  Last modification	:  August 13, 1990
======================================================================*/

/* heap.h */

/*---- The followings are macros for setting heap values ----------------*/

#define new_heap_free(sh_reg) bld_free(sh_reg); sh_reg++
/* make a free variable on the top of the heap */

#define new_heap_con(sh_reg, pair) bld_cs(sh_reg, pair); sh_reg++
/* make a new con node on the heap, with a psc_pair "pair" */

#define new_heap_string(sh_reg, str) bld_string(sh_reg, str); sh_reg++
/* make a new string node on the heap, with a psc_pair "pair" */

#define new_heap_num(sh_reg, val) bld_int(sh_reg, val); sh_reg++
/* make a new num node on the heap, with value val */

#define new_heap_float(sh_reg, val) bld_float(sh_reg, val); sh_reg++
/* make a new float node on the heap, with value val */

#define new_heap_functor(sh_reg, psc) bld_functor(sh_reg++, psc)
/* make a new functor node in heap */

#define new_heap_node(sh_reg, x) bld_copy0(sh_reg++, x)
/* make a new heap node with value x (one word type ) */

