/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File                  :  inst.c
  Author(s)		:  David S. Warren, Terrance Swift, Jiyang Xu
  Last modification	:  August 1993
======================================================================*/

#include "aux.h"
#include "inst.h"
#include "subinst.h"

int subinst_table[256][2];

#ifdef PROFILE
int builtin_table[256][2];

int inst_table[256][6];

#define set_inst(inst, instr, op1type, op2type, op3type,op4type) \
        inst_table[inst][0] = (int)(instr); \
	inst_table[inst][1] = op1type; \
	inst_table[inst][2] = op2type; \
	inst_table[inst][3] = op3type; \
	inst_table[inst][4] = op4type; \
	inst_table[inst][5] = 0

#define profile_inst(inst) \
       inst_table[inst][5] = inst_table[inst][5] + 1

#define set_subinst_table(inst) \
        subinst_table[inst][0] = (int)("inst"); \
	subinst_table[inst][1] = 0

#define set_builtin_table(inst) \
        builtin_table[inst][0] = (int)("inst");
#else
int inst_table[256][5];

#define set_inst(inst, instr, op1type, op2type, op3type,op4type) \
        inst_table[inst][0] = (int)(instr); \
	inst_table[inst][1] = op1type; \
	inst_table[inst][2] = op2type; \
	inst_table[inst][3] = op3type; \
	inst_table[inst][4] = op4type
#endif


init_inst_table()
{
    init_inst_table_1();
    init_inst_table_2();
    init_inst_table_3();
    init_inst_table_4();
#ifdef PROFILE
    init_builtin_table();
    init_subinst_table();
#endif
}

init_inst_table_1()
{
    set_inst(getpvar, "getpvar",            P,  V, R,X);
    set_inst(getpval, "getpval",            P,  V, R,X);
    set_inst(getstrv, "getstrv",            PP, V, S,X);
    set_inst(gettval, "gettval",            P,  R, R,X);
    set_inst(getcon, "getcon",             PP, R, C,X);
    set_inst(getnil, "getnil",             PP, R, X,X);
    set_inst(getstr, "getstr",             PP, R, S,X);
    set_inst(getlist, "getlist",            PP, R, X,X);
    set_inst(unipvar, "unipvar",            PP, V, X,X);
    set_inst(unipval, "unipval",            PP, V, X,X);
    set_inst(unitvar, "unitvar",            PP, R, X,X);
    set_inst(unitval, "unitval",            PP, R, X,X);
    set_inst(unicon, "unicon",             PPP,C, X,X);
    set_inst(uninil, "uninil",             PPP,X, X,X);
    set_inst(getnumcon, "getnumcon",          PP, R, N,X);
    set_inst(putnumcon, "putnumcon",          PP, R, N,X);
    set_inst(putpvar, "putpvar",            P,  V, R,X);
    set_inst(putpval, "putpval",            P,  V, R,X);
    set_inst(puttvar, "puttvar",            P,  R, R,X);
    set_inst(putstrv, "putstrv",            PP, V, S,X);
    set_inst(putcon, "putcon",             PP, R, C,X);
    set_inst(putnil, "putnil",             PP, R, X,X);
    set_inst(putstr, "putstr",             PP, R, S,X);
    set_inst(putlist, "putlist",            PP, R, X,X);
    set_inst(bldpvar, "bldpvar",            PP, V, X,X);
    set_inst(bldpval, "bldpval",            PP, V, X,X);
}

init_inst_table_2()
{
    set_inst(bldtvar, "bldtvar",            PP, R, X,X);
    set_inst(bldtval, "bldtval",            PP, R, X,X);
    set_inst(bldcon, "bldcon",             PPP,C, X,X);
    set_inst(bldnil, "bldnil",             PPP,X, X,X);
    set_inst(uninumcon, "uninumcon",          PPP,N, X,X);
    set_inst(bldnumcon, "bldnumcon",          PPP,N, X,X);
    set_inst(getlist_tvar_tvar, "getlist_tvar_tvar",  R,  R, R,X);
    set_inst(getcomma, "getcomma",           PP, R, X,X);
    set_inst(getcomma_tvar_tvar, "getcomma_tvar_tvar", R,  R, R,X);
    set_inst(getfloat, "getfloat",           PP, R, N,X);
    set_inst(putfloat, "putfloat",           PP, R, N,X);
    set_inst(unifloat, "unifloat",           PPP,N, X,X);
    set_inst(bldfloat, "bldfloat",           PPP,N, X,X);
/*  keep profiles clean
    set_inst(trys, "trys",               PP, A, L,X);
    set_inst(retrys, "retrys",             PP, A, L,X);
    set_inst(trusts, "trusts",             PP, A, L,X);
    set_inst(neck, "neck",               PP, A, X,X);
    set_inst(neck_putpbreg, "neck_putpbreg",      P,  A, V,X);
    set_inst(neck_puttbreg, "neck_puttbreg",      P,  A, R,X);
*/
    set_inst(trymeelse, "trymeelse",          PP, A, L,X);
    set_inst(retrymeelse, "retrymeelse",        PP, A, L,X);
    set_inst(trustmeelsefail, "trustmeelsefail",    PP, A, X,X);
    set_inst(try, "try",                PP, A, L,X);
    set_inst(retry, "retry",              PP, A, L,X);
    set_inst(trust, "trust",              PP, A, L,X);
    set_inst(getpbreg, "getpbreg",           PP, V, X,X);
}

init_inst_table_3()
{
    set_inst(gettbreg, "gettbreg",           PP, R, X,X);
    set_inst(putpbreg, "putpbreg",           PP, V, X,X);
    set_inst(puttbreg, "puttbreg",           PP, R, X,X);
    set_inst(jumptbreg, "jumptbreg",          PP, R, L,X);
    set_inst(getarg_proceed, "getarg_proceed",     PP, A, X,X);
    set_inst(getstring, "getstring",          PP, R, G,X);
    set_inst(putstring, "putstring",          PP, R, G,X);
    set_inst(unistring, "unistring",          PPP,G, X,X);
    set_inst(bldstring, "bldstring",          PPP,G, X,X);
    set_inst(switchonterm, "switchonterm",       PPR,L, L,X);
    set_inst(switchonbound, "switchonbound",      PPR,I, I,X);
    set_inst(switchon3bound, "switchon3bound",      RRR,I, I,X);
/*  keep profiles clean
    set_inst(switchoncon, "switchoncon",        PPP,L, X,X);
    set_inst(switchonstr, "switchonstr",        PPP,L, X,X);
    set_inst(suspend, "suspend",            PPP,X, X,X);
    set_inst(partry, "partry",             PP, A, N,X);
    set_inst(terminate, "terminate",          PPP,X, X,X);
*/
    set_inst(dyntrustmeelsefail, "dyntrustmeelsefail", PP, A, L,X); 
    set_inst(tableretry, "tableretry",         PP, A, L,X);
    set_inst(tabletry, "tabletry",           PP, A, L,T); 
    set_inst(addtotable, "addtotable",         P,  A, R,X);
    set_inst(tabletrust, "tabletrust",         PP, A, L,X); 
    set_inst(tabconfig, "tabconfig",          PPP,I, I,X); /* used by loader*/
    set_inst(comptabletry, "comptabletry",       PP, A, L,T); 
    set_inst(complete_call, "complete_call",      PP, A, S,X);
    set_inst(tabletryfail, "tabletryfail",       PP, A, L,T); 
    set_inst(comptabletryfail, "comptabletryfail",   PP, A, L,T); 
    set_inst(new_lookup, "new_lookup",         PPP,X, X,X); 
    set_inst(return_solution, "return_solution",    PPP,X, X,X); 
    set_inst(check_complete, "check_complete",     PPP,X, X,X); 
    set_inst(return_completion, "return_completion",  PPP,X, X,X); 
    set_inst(complete_execute, "complete_execute",   PPP,S, X,X);
    set_inst(use_table, "use_table",          PPP,X, X,X);
    set_inst(movreg, "movreg",             P,  R, R,X);
    set_inst(negate, "negate",             PP, R, X,X);
    set_inst(and, "and",                P,  R, R,X);
    set_inst(or, "or",                 P,  R, R,X);
    set_inst(lshiftl, "lshiftl",            P,  R, R,X);
    set_inst(lshiftr, "lshiftr",            P,  R, R,X);
    set_inst(addreg, "addreg",             P,  R, R,X);
    set_inst(subreg, "subreg",             P,  R, R,X);
    set_inst(mulreg, "mulreg",             P,  R, R,X);
    set_inst(divreg, "divreg",             P,  R, R,X);
}

init_inst_table_4()
{
    set_inst(idivreg, "idivreg",            P,  R, R,X);
    set_inst(putdval, "putdval",            P,  V, R,X);
    set_inst(putuval, "putuval",            P,  V, R,X);
    set_inst(getival, "getival",            PP, A, S,X);  /* unchanged yet */
    set_inst(unexec, "unexec",             P, S, S,X);  /* unchanged yet */
    set_inst(call, "call",               PP, A, S,X);
    set_inst(allocate, "allocate",           PPP,X, X,X);
    set_inst(deallocate, "deallocate",         PPP,X, X,X);
    set_inst(proceed, "proceed",            PPP,X, X,X);
    set_inst(execute, "execute",            PPP,S, X,X);
    set_inst(unexeci, "unexeci",            PPP,S, S,X);  /* unchanged yet */
    set_inst(executev, "executev",           PPP,X, X,X);  /* unchanged yet */
    set_inst(calld, "calld",              PP, A, L,X); /* diff from compiler */
    set_inst(jump, "jump",               PPP,L, X,X);
    set_inst(jumpz, "jumpz",              PP, R, L,X);
    set_inst(jumpnz, "jumpnz",             PP, R, L,X);
    set_inst(jumplt, "jumplt",             PP, R, L,X);
    set_inst(jumple, "jumple",             PP, R, L,X);
    set_inst(jumpgt, "jumpgt",             PP, R, L,X);
    set_inst(jumpge, "jumpge",             PP, R, L,X);
    set_inst(cases, "cases",              A,  N, N,X); /* not used in emulator */
    set_inst(fail, "fail",               PPP,X, X,X);
    set_inst(noop, "noop",               PP, A, X,X);
    set_inst(halt, "halt",               PPP,X, X,X);
    set_inst(builtin, "builtin",            PP, A, X,X);
    set_inst(unifunc, "unifunc",		 PPP,X, X,X);
/*  set_inst(straight_noop, "straight_noop",      PPP,X, X,X); */
    set_inst(userfunc, "userfunc",           PP, A, S,X);
/*  set_inst(endfile, "endfile",            PPP,N, X,X); */
}

#ifdef PROFILE /* for profiling only */
init_subinst_table()
{
   set_subinst_table(LOAD_SOLUTION);
   set_subinst_table(SAVEINFO);
   set_subinst_table(VARIANT);
   set_subinst_table(HQS);
   set_subinst_table(RECVARIANT);
   set_subinst_table(QS);
   set_subinst_table(RECLOAD);
 }

init_builtin_table()
{
  int i;

  for (i = 0; i < 256 ; i++) builtin_table[i][1] = 0; /*so bs can be added */
  set_builtin_table(PSC_NAME);
  set_builtin_table(PSC_ARITY);
  set_builtin_table(PSC_TYPE);
  set_builtin_table(PSC_PROP);
  set_builtin_table(PSC_SET_TYPE);
  set_builtin_table(PSC_SET_PROP);
  set_builtin_table(FILE_OPEN);
  set_builtin_table(FILE_CLOSE);
  set_builtin_table(FILE_GET);
  set_builtin_table(FILE_PUT);
  set_builtin_table(TERM_PSC);
  set_builtin_table(TERM_TYPE);
  set_builtin_table(TERM_COMPARE);
  set_builtin_table(TERM_NEW);
  set_builtin_table(TERM_ARG);
  set_builtin_table(TERM_SET_ARG);
  set_builtin_table(STAT_FLAG);
  set_builtin_table(STAT_SET_FLAG);
  set_builtin_table(BUFF_ALLOC);
  set_builtin_table(BUFF_WORD);
  set_builtin_table(BUFF_SET_WORD);
  set_builtin_table(BUFF_BYTE);
  set_builtin_table(BUFF_SET_BYTE);
  set_builtin_table(CODE_CALL);
  set_builtin_table(STR_LEN);
  set_builtin_table(STR_CPY);
  set_builtin_table(STR_CAT);
  set_builtin_table(STR_CMP);
  set_builtin_table(STR_HSH);
  set_builtin_table(STR_INSERT);
  set_builtin_table(STAT_STA);
  set_builtin_table(STAT_CPUTIME);
  set_builtin_table(CODE_LOAD);
  set_builtin_table(BUFF_SET_VAR);
  set_builtin_table(BUFF_DEALLOC);
  set_builtin_table(BUFF_CELL);
  set_builtin_table(BUFF_SET_CELL);
  set_builtin_table(FILE_GETWORD);
  set_builtin_table(FILE_PUTWORD);
  set_builtin_table(PSC_INSERT);
  set_builtin_table(PSC_IMPORT);
  set_builtin_table(FILE_GETBUF);
  set_builtin_table(FILE_PUTBUF);
  set_builtin_table(PSC_INSERTMOD);
  set_builtin_table(LOAD_SEG);
  set_builtin_table(FILE_GETTOKEN);
  set_builtin_table(FILE_PUTTOKEN);
  set_builtin_table(TERM_HASH);
  set_builtin_table(UNLOAD_SEG);
  set_builtin_table(LOAD_OBJ);
  set_builtin_table(EXPAND_FILE_NAME);
  set_builtin_table(GETENV);
  set_builtin_table(SYS_SYSCALL);
  set_builtin_table(SYS_SYSTEM);
  set_builtin_table(SYS_GETHOST);
  set_builtin_table(SYS_ERRNO);
  set_builtin_table(SYS_BROCALL);
  set_builtin_table(DOM_SIZE);
  set_builtin_table(DOM_TYPE);
  set_builtin_table(DOM_RANGE);
  set_builtin_table(DOM_ELEM);
  set_builtin_table(DOM_DIFF);
  set_builtin_table(DOM_PLUS);
  set_builtin_table(DOM_TIMES);
  set_builtin_table(DOM_MIN);
  set_builtin_table(DOM_ENUM);
  set_builtin_table(DOM_ESIZE);
  set_builtin_table(BUFF_ASSIGN_WORD);
  set_builtin_table(PSC_ENV);
  set_builtin_table(PSC_SPY);
  set_builtin_table(PSC_TABLED);
  set_builtin_table(TIP_PROP);
  set_builtin_table(IS_INCOMPLETE);
  set_builtin_table(GET_OSP_BREG);
  set_builtin_table(CUT_IF_LEADER);
  set_builtin_table(PAIR_PSC);
  set_builtin_table(PAIR_NEXT);
  set_builtin_table(NEXT_BUCKET);
  set_builtin_table(SUSPEND);
  set_builtin_table(INCOMPLETE);
  set_builtin_table(HEAP_COPYTERM);
  set_builtin_table(TAB_INTERN);
  set_builtin_table(IS_XWAMMODE);
  set_builtin_table(CLOSE_OPEN_TABLES);
  set_builtin_table(CALL_HASH);
  set_builtin_table(PRINT_PREDICATE_TABLE);
  set_builtin_table(ANALYZE_PREDICATE_TABLE);
  set_builtin_table(COMP_CODE_CALL);
  set_builtin_table(ABOLISH_TABLE_INFO);
  set_builtin_table(ZERO_OUT_PROFILE);
  set_builtin_table(WRITE_OUT_PROFILE);
  set_builtin_table(ASSERT_CODE_TO_BUFF);
  set_builtin_table(ASSERT_BUFF_TO_CLREF);
  set_builtin_table(FMT_WRITE);
  set_builtin_table(FMT_READ);
}
#endif

