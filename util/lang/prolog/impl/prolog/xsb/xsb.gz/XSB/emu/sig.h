/************************************************************************/
/*									*/
/* PSB-Prolog System							*/
/* Copyrigth (C) SUNY at Stony Brook, 1986; ECRC, 1990			*/
/*									*/
/* Everyone is granted permission to copy, modify and redistribute	*/
/* PSB-Prolog, but only under the conditions described in the		*/
/* PSB-Prolog License Agreement.  A copy of this license is supposed to	*/
/* have been given to you along with PSB-Prolog so you can know your	*/
/* rights and responsibilities.  It should be in a file named LICENSE. 	*/
/* Among other things, this notice must be preserved on all copies.	*/
/************************************************************************/

/*======================================================================
  Author(s)		:  Jiyang Xu
  Modified by		:  Jiyang Xu
  Last modification	:  August 13, 1990
======================================================================*/

/* sig.h */

/* signals 1 and 8-15 are asynchronous. They are flaged by the variable */
/* *asynint_ptr, which can be 8-15 and maybe OR'ed with KEYINT_MARK.	*/
/* At some interval (currently at the entry of "call", etc), a check is  */
/* made to see if there is an asynchronous interrupt occurred. If yes,	*/
/* the procedure "interrupt_proc" is invoked. The rest of signals (0 and */
/* 2-4) are synchronous. The procedure "interrupt_proc" is invoked      */
/* directly.								*/

#define MYSIG_UNDEF 0			/* undefined predicate */
#define MYSIG_KEYB 1			/* keyboard interrupt (^C) */
#define MYSIG_OFMEM 2			/* global/local stack overflow */
#define MYSIG_SPY 3			/* spy point */
#define MYSIG_TRACE 4			/* trace point */
#define MYSIG_OFTC 5			/* trail/CP stack overflow */
#define MYSIG_KILLED 6			/* response to MYSIG_KILL */
#define MYSIG_STAT 7			/* gather statistics */
#define MYSIG_TERM 8			/* termination of child */
#define MYSIG_CUT 9			/* send by child to parent */
#define MYSIG_KILL 10			/* send by parent to child */
#define MYSIG_DELAY 11			/* delayed goal awaking */
#define MYSIG_QJOB 12			/* request for job; not used now */
#define MYSIG_RJOB 13			/* response for job; not used now */
#define MYSIG_GJOB 14			/* get a job */
#define MYSIG_SJOB 15			/* send a job */
#define MYSIG_CLAUSE 16			/* clause interrupt */

#define KEYINT_MARK 0x80		/* keyboard interrupt ^C */
#define DELAYINT_MARK 0x40		/* delayed goal awaken interrupt */
#define MSGINT_MARK 0x20		/* software message interrupt */

private extern int *asynint_ptr;  /* 0 - no interrupt (or being processed) */
