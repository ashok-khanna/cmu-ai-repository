/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File			:  dis.c
  Author(s)		:  Warren, Swift, Xu, Sagonas
  Last modification	:  July 21, 1993
======================================================================*/

#include <stdio.h>
#include "config_make.h"
#include "aux.h"
#include "psc.h"
#include "loader.h"
#include "cell.h"
#include "inst.h"
#include "memory.h"
#include "flags.h"
#include "xmacro.h"
/* followings are working variables; shared to save space */

extern tab_inf_ptr get_tip();

/*shapri static FILE *filedes ;*/
#define filedes stdout

/* Include these so that the Gnu C Compiler does not complain */
static dis_data();
static dis_data_sub();
static dis_text();

dis(distext)
{  
/*   filedes = fopen("stdout","w"); */
   dis_data();
   if (distext) dis_text();
/*   fflush(filedes);
   fclose(filedes); */
}

static dis_data()
{
	int i;
	struct psc_pair **temp_ptr;
	struct psc_rec *psc_ptr;
	char *modname;

	temp_ptr = (Pair *)(&flags[MOD_LIST]);
	while(*temp_ptr) {
	   psc_ptr = (*temp_ptr)->psc_ptr;
	   modname = get_name(psc_ptr);
	   if (get_type(psc_ptr))	/* 00000100 */
	        fprintf(filedes, "/* module %s : LOADED. */\n\n", modname);
	   else fprintf(filedes, "/* module %s : UNLOADED. */\n\n", modname);
	   if (strcmp(modname,"global")==0)
	   	for(i=0;i<MAXBUCKET;i++) {
		  if ( (int) *(hash_table+i)) {
		    fprintf(filedes, "... ... BUCKET NO. %d\n", i);
		    dis_data_sub(hash_table+i);
		  }
		}
	   else if (strcmp(modname,"usermod")==0) 
		fprintf(filedes, "\t\t/* Same as module global*/\n");
	   else dis_data_sub(&get_ep(psc_ptr));
	   fprintf(filedes, "\n");
	   temp_ptr = &((*temp_ptr)->next);
	}
}

static dis_data_sub(chain_ptr)
struct psc_pair **chain_ptr;
{
   struct psc_rec *temp;
   while (*chain_ptr) {
	temp = (*chain_ptr)->psc_ptr;
	fprintf(filedes, "%x: ", temp);
	fflush(filedes);
	fprintf(filedes, "%s", get_name(temp));
	fprintf(filedes, "/%d,\t", get_arity(temp));
	switch(get_type(temp)) {
	    case T_PRED: fprintf(filedes, "PRED,\t"); break;
	    case T_DYNA: fprintf(filedes, "DYNA,\t"); break;
	    case T_ORDI: fprintf(filedes, "ORDI,\t"); break;
	    case T_CONS: fprintf(filedes, "CONS,\t"); break;
	    case T_STRU: fprintf(filedes, "STRU,\t"); break;
	    case T_FILE: fprintf(filedes, "FILE,\t"); break;
	    case T_MODU: fprintf(filedes, "MODU,\t"); break;
	    case T_FORN: fprintf(filedes, "FORN,\t"); break;
	    case T_FUNC: fprintf(filedes, "FUNC,\t"); break;
	    case T_UDEF: fprintf(filedes, "UDEF,\t"); break;
	    case T_UFUN: fprintf(filedes, "UFUN,\t"); break;
	    default:	 fprintf(filedes, "????"); break;
	}
	switch(get_env(temp)) {
	    case T_VISIBLE:   fprintf(filedes, "VISIBLE	"); break;
	    case T_HIDDEN:   fprintf(filedes, "HIDDEN	 "); break;
	    case T_UNLOADED:   fprintf(filedes, "UNLOADED"); break;
	    default:   fprintf(filedes, "(error env)"); break;
	}
	if (get_type(temp) == T_PRED) {
	  if (get_tip(temp) == (tab_inf_ptr) 0)
	      fprintf(filedes, "UNTABLED  "); 
	  else
	    fprintf(filedes, "TABLED chs %d rhs %d",
		    get_chs(get_tip(temp)),get_chs(get_tip(temp)));
	}
	fprintf(filedes, ",  %x\n", get_ep(temp));
	chain_ptr = &((*chain_ptr)->next);
   } /* while */
}

byte *print_inst(fd, inst_ptr)
FILE *fd;
byte *inst_ptr;
{
    byte *lpcreg; /* local pc register for macros to use */
    byte opcode; 
    int i;
    struct psc_rec *psc;

    lpcreg = inst_ptr;
    fprintf(fd,"%x\t",lpcreg);
    opcode = *lpcreg++;
/* We want the instruction string printed out below.  
 * Someday we should ANSI-fy it. 
 */
    fprintf(fd,(char *)inst_table[opcode][0]);
    for (i=1; i<=4; i++) {
	 switch (inst_table[opcode][i]) {
	 case A:
	   fprintf(fd, "\t%d", *lpcreg++);
	   break;
	 case V:
	   fprintf(fd, "\tv%d", *lpcreg++);
	   break;
	 case R:
	   fprintf(fd, "\tr%d", *lpcreg++);
	   break;
	 case T:
	   fprintf(fd, "\t%x", *(word *)lpcreg);
	   lpcreg+=4;
	   break;
	 case P:
	   lpcreg++;
	   break;
	 case S:
	   if (opcode == (byte) call) {
	     psc = (Psc) *(int *) lpcreg;
	     fprintf(fd, "\t0x%x", *(word *)lpcreg);
	     fprintf(fd,"\t(%s)",get_name(psc));
	   }
	   else if (opcode == (byte) execute) {
	     fprintf(fd, "\t0x%x", *(word *)lpcreg);
	     psc = (Psc) *(int *) lpcreg;
	     fprintf(fd,"\t(%s)",get_name(psc));
	   }
	   else
	     fprintf(fd, "\t0x%x", *(word *)lpcreg);
	   lpcreg += 4;
	   break;
	 case C:
	 case L:
	 case G:
	 case I:
	 case N:
	   fprintf(fd, "\t0x%x", *(word *)lpcreg);
	   lpcreg += 4;
	   break;
	 case PP:
	   lpcreg+=2;
	   break;
	 case PPP:
	   lpcreg+=3;
	   break;
	 case PPR:
	   lpcreg+=2;
	   fprintf(fd, "\tr%d", *lpcreg++);
	   break;
	 case RRR:
	   fprintf(fd, "\tr%d", *lpcreg++);
	   fprintf(fd, "\tr%d", *lpcreg++);
	   fprintf(fd, "\tr%d", *lpcreg++);
	   break;
	 case X:
	   break;
	 default:
	   break;
	 }  /* switch */
	 if (opcode == noop) lpcreg += 2 * *(lpcreg-1);
    } /* for */
    fprintf(fd, "\n");
    fflush(fd);
    return lpcreg;
} /* print_inst */


static dis_text()
{
   byte *endaddr, *this_seg, *index_seg, *inst_addr2;

   fprintf(filedes, "\n/*text below\t\t*/\n\n");
   this_seg = inst_begin;
   while (this_seg) {		/* repeat for all text segment */
      fprintf(filedes, "\nNew segment below \n\n");
      endaddr = this_seg + *(int *)(this_seg-4) - 16;
      inst_addr2 = this_seg;
      while (inst_addr2<endaddr) inst_addr2 = print_inst(filedes, inst_addr2);
      index_seg = *(byte **)(this_seg-8);
      while (index_seg) {
	inst_addr2 = index_seg+8;
	endaddr = index_seg + *(int *)(index_seg+4);
	if (*(index_seg+8)==try || *(index_seg+8) == tabletry
	    || *(index_seg+8) == tabletryfail) {	
	                                           /* is try/retry/trust */
	  while (inst_addr2<endaddr) 
	    inst_addr2 = print_inst(filedes, inst_addr2);
	} else {					/* is hash table */
	  fprintf(filedes, "hash table.... \n");
	  while (inst_addr2<endaddr) {
	    fprintf(filedes, "%x:    %x\n", inst_addr2, *((pw)inst_addr2));
	    inst_addr2 += 4;
	  }
	  fprintf(filedes, "    end.... \n");
	}
	index_seg = *(byte **)(index_seg);
      }
      this_seg = *(byte **)(this_seg-16);
   }  
}


