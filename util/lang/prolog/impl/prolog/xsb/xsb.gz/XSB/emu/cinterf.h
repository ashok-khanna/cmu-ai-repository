/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/
 
/*======================================================================
  Author(s)             :  Jiyang Xu
  Modified by           :  Jiyang Xu
  Last modification     :  Nov. 23, 1992
======================================================================*/

/* cinterf.h */

#ifdef COMMENT

PSB-Prolog provides three different levels of C interfaces.

(1) Minimal Interface

This is a simple interface that can be described by the   
following specifications:

	types:	reg_num ( integer)

	functions:
	   Prolog (register) to C:
		ptoc_int:	reg_num -> int
		ptoc_float:	reg_num -> double
		ptoc_string:	reg_num -> string
		ptoc_abs:	reg_num -> abstract pointer
	   C  to Prolog:
		ctop_int:	reg_num x int -> void
		ctop_float:	reg_num x double -> void
		ctop_string:	reg_num x string -> void
		ctop_abs:	reg_num x abstract pointer -> void

The procedures assume correct modes and types being passed down by
Prolog level.

(2) Low level interface

Low level interface does not assume types and modes, and allows
user to access prolog term structures.
Both the minimal interface above and the high level interface below
can be implemented by this set of low level interface routines.

	types:	prolog_term
		reg_num  ( integer )

	functions:
	    Register to Prolog term:
		reg_term:	reg_num -> prolog_term
	    C to Prolog:		
		c2p_int:	int x prolog_term -> bool
		c2p_float: 	double x prolog_term -> bool
		c2p_string:	string x prolog_term -> bool
		c2p_list: 	prolog_term -> bool
		c2p_functor:	string x int x prolog_term -> bool
		c2p_nil:	prolog_term -> bool
		c2p_setfree:	prolog_term -> void  !! Dangerous
	    Prolog to C:
		p2c_int:	prolog_term -> int
		p2c_float:	prolog_term -> double
		p2c_string:	prolog_term -> string
		p2c_functor:	prolog_term -> string
		p2c_arity:	prolog_term -> int
	    Prolog to Prolog:
		p2p_arg:	prolog_term x int -> prolog_term
		p2p_car:	prolog_term -> prolog_term
		p2p_cdr:	prolog_term -> prolog_term
		p2p_new:	void -> prolog_term
		p2p_unify:	prolog_term x prolog_term -> bool
		p2p_call:	prolog_term -> bool
 		p2p_funtrail:	val x fun -> void
		p2p_deref:	prolot_term -> prolog_term   !! uncommon
	    Type/Mode checking:
		is_var:		prolog_term -> bool
		is_int:		prolog_term -> bool
		is_float:	prolog_term -> bool
		is_string:	prolog_term -> bool
		is_list:	prolog_term -> bool
		is_nil:		prolog_term -> bool
		is_functor:	prolog_term -> bool

(3) High level Interface
   This can be viewed as an extention of the minimal interface above.

	types:	reg_num  ( integer )
		format ( string )
		caddr ( C data address )
		errno ( int )

	functions:
		ctop_term:	format x caddr x reg_num -> errno
		ptoc_term:	format x caddr x reg_num -> errno
		c2p_term:	format x caddr x prolog_term -> errno
		p2c_term:	format x caddr x prolog_term -> errno

where format (similar to that of printf/scanf) is a string controlling the 
the conversion. The interface is so general that you can even convert
recursive data structure between C and Prolog with a single function call.
The format is a string containing a format descriptor (fmt) which can
be of the following forms (fmts is a sequence of fmt; # is a digit in
0-9):

	fmt			Prolog term type	C data type
	----------		----------------	-----------
	%i			integer			int
	%c			integer			char
	%f			float			float
	%d			float			double
	%s			constant		string
	%[fmts] 		structure		nested struct
	%t#(fmts)		structure		pointer to struct
	%l#(fmt fmt)		list			pointer to struct
	%#			recursive structure	pointer to struct

(4) other facilities:

   type:  vfile (char *, opaque pointer)

	vfile_open:  obj x v_fprintf x v_fclose x v_putc x v_getc 
			x v_ungetc -> vfile
	vfile_obj:  vfile -> obj		
		both file and obj are opaque pointers of type char* */
#endif /* COMMENT */


/*======================================================================*/
/* High level C interface						*/
/*======================================================================*/

#ifndef TRUE
#define FALSE 0
#define TRUE 1
#endif

#ifndef bool
#define bool int
#endif

typedef int reg_num;

extern int   ptoc_int(/* reg_num */);		/* defined in builtin.c */
extern float ptoc_float(/* reg_num */);		/* defined in builtin.c */
extern char* ptoc_string(/* reg_num */);	/* defined in builtin.c */
extern char* ptoc_abs(/* reg_num */);

extern int   ctop_int( /* reg_num, int */ );	/* defined in builtin.c */
extern int   ctop_float(/* reg_num, float */);	/* defined in builtin.c */
extern int   ctop_string(/* reg_num, char* */);	/* defined in builtin.c */
extern int   ctop_abs(/* reg_num, char* */);

extern int   ctop_term(/* char* fmt, char* cdata, reg_num reg*/);
extern int   ptoc_term(/* char* fmt, char* cdata, reg_num reg*/);

/*======================================================================*/
/* Low level C interface						*/
/*======================================================================*/

typedef int prolog_term;	/* opaque type definition */
/* typedef int reg_num; */	/* already defined in high level interface */

extern prolog_term reg_term(/* reg_num */);

extern bool c2p_int(/* int, prolog_term var */);
extern bool c2p_float(/* double, prolog_term var */);
extern bool c2p_string(/* double, prolog_term var */);
extern bool c2p_list(/* prolog_term var */);
extern bool c2p_nil(/* prolog_term var */);
extern bool c2p_functor(/* char *functor, int arity, prolog_term var */);
extern void c2p_setfree(/* prolog_term addr */);



extern int    p2c_int(/* prolog_term */);
extern double p2c_float(/* prolog_term */);
extern char*  p2c_string(/* prolog_term */);
extern char*  p2c_functor(/* prolog_term */);
extern int    p2c_arity(/* prolog_term */);

extern prolog_term p2p_arg(/* prolog_term, int argno */);
extern prolog_term p2p_car(/* prolog_term */);
extern prolog_term p2p_cdr(/* prolog_term */);
extern prolog_term p2p_new(/* void */);
extern bool        p2p_unify(/* prolog_term, prolog_term */);
extern bool        p2p_call(/* prolog_term */);
extern void	   p2p_funtrail(/*val, fun*/);
extern prolog_term p2p_deref(/* prolog_term */);

extern bool is_var(/* prolog_term */);
extern bool is_int(/* prolog_term */);
extern bool is_float(/* prolog_term */);
extern bool is_string(/* prolog_term */);
extern bool is_list(/* prolog_term */);
extern bool is_nil(/* prolog_term */);
extern bool is_functor(/* prolog_term */);

extern int   c2p_term(/* char* fmt, char* cdata, prolog_term reg*/);
extern int   p2c_term(/* char* fmt, char* cdata, prolog_term reg*/);

/*======================================================================*/
/* Other utilities							*/
/*======================================================================*/

typedef char *vfile;

extern char *vfile_open(/* vfile, func, func, func, func, func */);
extern char *vfile_obj(/* vfile */);
