/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File			:  register.h
  Author(s)		:  Warren, Swift,  Xu
  Last modification	:  April 1993
======================================================================*/

#define maxregs       257

/* special registers -----------------------------------------------*/

 extern CPtr ereg;                /* last activation record       */
 extern CPtr breg;                /* last choice point            */
 extern CPtr hreg;                /* top of heap                  */
 extern CPtr *trreg;               /* top of trail stack           */
 extern CPtr hbreg;               /* heap back track point        */
 extern CPtr sreg;                /* current build or unify field */
 extern byte *cpreg;      /* return point register        */
 extern byte *pcreg;    /* program counter              */

#ifdef XWAM
extern comptableflag;
extern level_num;
extern CPtr pdlreg1;
extern CPtr threg1;
extern int  xwammode;
extern CPtr efreg;
extern CPtr bfreg;
extern CPtr hfreg;
extern CPtr *trfreg;
extern CPtr tabreg;
extern CPtr pdlreg;
extern CPtr threg;
extern CPtr *tabtrreg;
extern CPtr openreg;
#endif

/* for splitting stack mode */
 extern CPtr ebreg;		/* breg into environment stack */
 extern int  dreg;		/* deep backtracking flag      */

 extern CellStr  reg[maxregs];     /* registers */

