/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File                  :  builtin.c
  Author(s)		:  Xu, Warren, Sagonas, Swift
  Last modification	:  September 1993
========================================================================*/

/* for XWAM, term_set_args, buff_assign_word not implemented 
   dom_xxx stuff taken out 
   sys_brocall
*/

#include <sys/file.h>
#include <stdio.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <string.h>
#include <pwd.h>
#include <setjmp.h>	/* for assert */

#include "config_make.h"
#include "aux.h"
#include "cinterf.h"	/* for assert, (should clean so it's not needed?) */
#include "psc.h"
#include "cell.h"
#include "choice.h"
#include "deref.h"
#include "memory.h"
#include "heap.h"
#include "register.h"
#include "flags.h"
#include "loader.h"
#include "binding.h"
#include "token.h"
#include "hashindex.h"
#include "xmacro.h"
#include "inst.h"
#include "subinst.h"

/* For tip hacking */
#define CALL_NEXT_TIP 0
#define CALL_HASH_ADDR 1
#define CALL_HASH_SIZE 2
#define RET_HASH_SIZE 3
#define FIRST_TIP 4


extern comptableflag, can_reclaim;
extern level_num, num_unwinds;
extern double cpu_time();
extern CPtr get_call_ep();
extern tab_inf_ptr get_tip();
extern tab_inf_ptr first_tip;
extern remove_open_tables_reset_freezes();
extern int macroprint;
extern CPtr xtemp3, xtemp5;

char *expand_file_name();
word flags[64];		/* System flags + user flags */
Pair hash_table[MAXBUCKET];

/*== working variables for the procedure "builtin_call"==================*/

static FILE* fptr;			/* working variable */
static float float_temp;		/* working variable */
static struct hostent *hp;		/* working variable */
static int (*proc_ptr)();		/* working variable */

static struct stat stat_buff;

/* The following definition may not be the correct way to handle files!!! */

#ifdef NO_IOB
#define fileptr(fileno) (fileno > 2 ? (FILE *)fileno : \
		  (fileno == 0 ? stdin : (fileno == 1 ? stdout : \
		  stderr)))
#elif SOLARIS
#define fileptr(fileno) (&__iob[fileno])
#else
#define fileptr(fileno) (&_iob[fileno])
#endif

/* --- utility routines ---------------------------------------------*/
/* change tls -- not needed without domain */
Cell ptoc_tag(regnum)
{
	register Cell addr;

	addr = cell(reg+regnum);
	deref(addr);
        return addr;
}

int ptoc_int(regnum)
{
	register Cell addr;

	addr = cell(reg+regnum);
	DEREF(addr, lbl_li)
	/* case FREE: */
	case CS:
	case LIST:
	case DELAY:
	case FLOAT: printf("Wrong arg in ptoc_int\n"); return 0; break;
	case DVAR:
	  if (cell((CPtr)domain_val(addr))!=addr) {
	    addr = cell((CPtr)domain_val(addr));
	    goto lbl_li;
	  } 
	  printf("Wrong arg in ptoc_int\n"); return 0; break;
	case STRING: return (int)string_val(addr); break;	/* dsw */
	case INT:  return int_val(addr); break;
	DREND
}

float ptoc_float(regnum)
{
	register Cell addr;

	addr = cell(reg+regnum);
	DEREF(addr, lbl_lf)
	/* case FREE: */
	case CS:  
	case LIST:
	case INT:
	case DELAY:
	case STRING:  printf("Wrong arg in ptoc_float\n"); break;
	case DVAR:
	  if (cell((CPtr)domain_val(addr))!=addr) {
	    addr = cell((CPtr)domain_val(addr));
	    goto lbl_lf;
	  } 
	  printf("Wrong arg in ptoc_float\n"); break;
	case FLOAT:  break;
	DREND
	return float_val(addr);
}

char *ptoc_string(regnum)
{
	register Cell addr;

	addr = cell(reg+regnum);
	DEREF(addr, lbl_ls)
	/* case FREE: */
	case CS:  
	case LIST:
	case DELAY:
	case FLOAT:  printf("Wrong arg in ptoc_string\n"); return 0; break;
	case DVAR:
	  if (cell((CPtr)domain_val(addr))!=addr) {
	    addr = cell((CPtr)domain_val(addr));
	    goto lbl_ls;
	  } 
	  return string_val(addr); break;
	case INT: return (char *)int_val(addr); break;
	case STRING:  return string_val(addr); break;
	DREND
}

ctop_int(regnum, value)		/* from int value form an int node */
{
	register Cell addr;

	addr = cell(reg+regnum);
	IFTHENELSE_DEREF(addr, lbl_lli)
	     bind_int(vptr(addr), value);
	}
	else printf("Wrong arg in ctop_int %x (%d)\n", addr, regnum);
}

ctop_float(regnum, value)	/* from float value form an int node */
float value;
{
	register Cell addr;

	addr = cell(reg+regnum);
	IFTHENELSE_DEREF(addr, lbl_llf)
       	     bind_float(vptr(addr), value);
	}
	else printf("Wrong arg in ctop_float %x\n", addr);
}

ctop_string(regnum, value)	/* from string form a string node */
char *value;
{
	register Cell addr;

	addr = cell(reg+regnum);
	IFTHENELSE_DEREF(addr, lbl_lls)
	     bind_string(vptr(addr), value);
	}
	else {
	     printf("Wrong arg in ctop_string %x\n", addr); return 0;
	}
}

ctop_ref(regnum, value)		/* from address form a reference node */
CPtr value;
{
	register Cell addr;

	addr = cell(reg+regnum);
	IFTHENELSE_DEREF(addr, lbl_llr)
	     bind_ref(vptr(addr), value);
	}
	else printf("Wrong arg in ctop_ref %x\n", addr);
}

ctop_constr(regnum, psc_pair)	/* from psc_pair ptr form an constr node */
Pair psc_pair;
{
	register Cell addr;

	addr = cell(reg+regnum);
	IFTHENELSE_DEREF(addr, lbl_llc)
	     bind_cs(vptr(addr), psc_pair);
	}
	else printf("Wrong arg in ctop_constr %x\n", addr);
}

ctop_tag(regnum, term)		/* set var to the term */
Cell term;
{
	register Cell addr;

	addr = cell(reg+regnum);
	IFTHENELSE_DEREF(addr, lbl_llt)
	     bind_copy(vptr(addr), term);
        }
	else printf("Wrong arg in ctop_tag %x\n", addr);
}

val_to_hash(term)
Cell term;
{
    int value;

    switch(cell_tag(term)) {
	case INT:
	case FLOAT:  /* Yes, use int_val to avoid conversion problem */
		value = int_val(term);
	        break;
	case LIST:
	        value = (int)(list_str);
		break;
	case CS:
	        value = (int)get_str_psc(term);
	        break;
	case STRING:
		value = (int)string_val(term);
		break;
	default: quit("Indexing on illegal argument");
		break;
    }
    return value;
}

#ifdef MEMTRACE
#define m_verr_bi() \
	if (malloc_verify() == 0) {\
	  printf("bi %d\n",number);\
	  abort();\
	}
#else
#define m_verr_bi() 
#endif


/* --- built in predicates --------------------------------------- */

builtin_call(number)
{
    char *addr;
    int value, disp, arity, tmpval;
    Cell term;
    struct psc_rec *psc;
    tab_inf_ptr tip;
    struct psc_pair *sym;
#ifdef SOLARIS
    int (*my_fptr)(void);
#endif
    
    switch (number) {
	case PSC_NAME:		/* reg 1: +PSC; reg 2: -String */
	    psc = (struct psc_rec *)ptoc_string(1);
	    ctop_string(2, get_name(psc));
	    break;
	case PSC_ARITY:		/* reg 1: +PSC; reg 2: -int */
	    psc = (struct psc_rec *)ptoc_string(1);
	    ctop_int(2, (int)get_arity(psc));
	    break;
	case PSC_TYPE:		/* reg 1: +PSC; reg 2: +int */
				/* type: see FORMAT */
	    psc = (struct psc_rec *)ptoc_string(1);
	    ctop_int(2, (int)get_type(psc));
	    break;
	case PSC_PROP:		/* reg 1: +PSC reg 2: -term */
				/* prop: as a buffer pointer */
	    psc = (struct psc_rec *)ptoc_string(1);
	    if (get_type(psc)==T_ALIA) ctop_tag(2, get_ep(psc));
	    else ctop_int(2, (int)get_ep(psc));
	    break;
	case PSC_SET_TYPE:	/* reg 1: +PSC; reg 2: int; reg 3: +Perm */
				/* reg 3 is currently ignored*/
				/* type: See FORMAT */
	    psc = (struct psc_rec *)ptoc_string(1);
	    set_type(psc, ptoc_int(2));
	    break;
	case PSC_SET_PROP:	/* reg 1: +PSC; reg 2: int; reg 3: +Perm */
				/* reg 3 is currently ignored */
	    psc = (struct psc_rec *)ptoc_string(1);
	    if (get_type(psc)==T_ALIA) set_ep(psc, (pb)ptoc_tag(2));
	    else set_ep(psc, (pb)ptoc_int(2));
	    break;
        case FILE_OPEN:         /* r1: file name (+string);   */
                                /* r2: mode (+int); r3: -file */
                                /* When read, mode=0; when write, mode = 1 */
            addr = expand_file_name(ptoc_string(1));
            switch (ptoc_int(2)) {
                case 0: fptr = fopen(addr, "r"); break;
                case 1: fptr = fopen(addr, "w"); break;
                case 2: fptr = fopen(addr, "a"); break;
                default: printf("Unknown open file mode\n");
            }
            if (fptr)  /* HERE WE MUST PUT sthing TO ENSURE THAT fptr
			  IS NOT A DIRECTORY */   
#ifdef NO_IOB
		ctop_int(3, (int) fptr);
#else
                ctop_int(3, fileno(fptr));
#endif
            else
                ctop_int(3, -1);
            break;
	case FILE_CLOSE:	/* r1: +file */
	    tmpval = ptoc_int(1);
	    fclose(fileptr(tmpval));
	    break;
	case FILE_GET:		/* r1: +file; r2: char (-int) */
	    tmpval = ptoc_int(1);
	    ctop_int(2, getc(fileptr(tmpval)));
	    break;
	case FILE_PUT:		/* r1: +file; r2: char (+int) */
	    tmpval = ptoc_int(1);
	    putc(ptoc_int(2), fileptr(tmpval));
	    break;
	case TERM_PSC:		/* r1: +term; r2: -PSC */
	    psc = get_str_psc(ptoc_tag(1));
	    ctop_int(2, (int)psc);
	    break;
	case TERM_TYPE:		/* r1: +term; r2: tag (-int)		*/
				/* <0 - var, 1 - cs, 2 - int, 3 - list>	*/
	    term = ptoc_tag(1);
#ifdef DW
	    ctop_int(2, cell_tag(term));
#else /* SW, HW */
	    if (!isnonvar(term)) ctop_int(2, 0);
	    else ctop_int(2, cell_tag(term));
#endif
	    break;
	case TERM_COMPARE:	/* r1, r2: +term; rs: res (-int) */
	    ctop_int(3, compare(ptoc_tag(1), ptoc_tag(2)));
	    break;
	case TERM_NEW:		/* r1: +PSC, r2: -term */
	    psc = (struct psc_rec *)ptoc_string(1);
/* should we treat constants differently? Seems unnecessary. */
	    sreg = hreg;
	    hreg += get_arity(psc) + 1;
	    ctop_constr(2, sreg);
	    new_heap_functor(sreg, psc);
	    for (disp=0; disp<get_arity(psc); sreg++,disp++) {bld_free(sreg);}
	    break;
	case TERM_ARG:		/* r1 : +term; r2: index (+int); */
				/* r3: arg (-term) */
	    disp = ptoc_int(2);
	    term = ptoc_tag(1);
	    ctop_tag(3, cell(clref_val(term)+disp));
	    break;
	case TERM_SET_ARG:	/* r1: +term; r2: index (+int) */
				/* r3: newarg (+term); r4: +perm(not used) */
	    /* used in file_read.P, array.P, array1.P */
/* change to pushtrailv -- tls 
	    disp = ptoc_int(2);
	    term = ptoc_tag(1);
	    if (!ptoc_int(4)) { pushtrailv(clref_val(term)+disp); }
	    bld_copy0(clref_val(term)+disp, cell(reg+3));
	    break;
	    change back -- tls*/
	    disp = ptoc_int(2);
	    term = ptoc_tag(1);
	    if (!ptoc_int(4)) { pushtrail(clref_val(term)+disp,cell(reg+3));}
	    bld_copy0(clref_val(term)+disp, cell(reg+3));
	    break;
	case STAT_FLAG:		/* R1: flagname(+int); R2: value(-int) */
	    ctop_int(2, flags[ptoc_int(1)]);
	    break;
	case STAT_SET_FLAG:	/* R1: flagname(+int); R2: value(+int); */
				/* R3: +Perm (ignored) */
	    flags[ptoc_int(1)] = ptoc_int(2);
	    call_intercept = flags[DEBUG_ON]|flags[TRACE_STA]|flags[HITRACE]
	    	|flags[CLAUSE_INT];
	    break;
	case BUFF_ALLOC:	/* r1: size (+integer); r2: -buffer; */
				/* r3: 1=>perm, 0=>heap, */
				/* the length of the buffer is also stored */
				/* at 0 position initially */
	    value = ((ptoc_int(1)+7)>>3)<<3;
	    if (ptoc_int(3)) addr = (char *)mem_alloc(value);
	    else { 
	        addr = (char *)hreg;
	        hreg = (CPtr)((int)hreg+value);
	    }
	    *(int *)addr = value;	/* store the size of the buffer at 0 */
	    ctop_int(2, addr);		/* use "integer" type now! */
	    break;
	case BUFF_DEALLOC:	/* r1: +buffer; r2: +oldsize; */
				/* r3: +newsize; r4: +perm/temp */
	    addr = ptoc_string(1);
	    disp = ((ptoc_int(2)+7)>>3)<<3;
	    value = ((ptoc_int(3)+7)>>3)<<3;	/* alignment */
	    if (value > disp) {
	      printf("New Buffer Size Cannot exceed the old one!!\n");
	      break;
	    }
	    if (ptoc_int(4)==1) {
	      mem_dealloc(addr+value, disp-value);
	    }
	    else /* perm == 0, in heap */ {
	      if ((int)hreg == (int)(addr+disp)) 
		if ((CPtr) (addr + value) >= hfreg)
		  hreg = (CPtr)(addr + value);
	    }
	    break;
	case BUFF_WORD:		/* R1: +buffer; r2: displacement(+integer); */
				/* R3: value (-integer) */
	    addr = ptoc_string(1);
	    disp = ptoc_int(2);
	    ctop_int(3, *(int *)(addr+disp));
	    break;
	case BUFF_SET_WORD:	/* R1: +buffer; r2: displacement(+integer); */
				/* R3: value (+integer) */
	    addr = ptoc_string(1);
	    disp = ptoc_int(2);
	    *(pw)(addr+disp) = ptoc_int(3);
	    break;
	case BUFF_BYTE:		/* R1: +buffer; r2: displacement(+integer);*/
				/* R3: value (-integer) */
	    addr = ptoc_string(1);
	    disp = ptoc_int(2);
	    ctop_int(3, (int)(*(byte *)(addr+disp)));
	    break;
	case BUFF_SET_BYTE:	/* R1: +buffer; r2: displacement(+integer);*/
				/* r3: value (+integer) */
	    addr = ptoc_string(1);
	    disp = ptoc_int(2);
	    *(pb)(addr+disp) = ptoc_int(3);
	    break;
	case BUFF_CELL:	/* R1: +buffer; r2: displacement(+integer);*/
			/* r3: -Cell at that location */
	    addr = ptoc_string(1);
	    disp = ptoc_int(2);
	    ctop_tag(3, addr+disp);
	    break;
	case BUFF_SET_CELL:	/* R1: +buffer; r2: displacement(+integer);*/
				/* r3: type (+integer); r4: +term */
			/* When disp<0, set the type of the buff itself */
			/* The last function is not implemented */
	    addr = ptoc_string(1);
	    disp = ptoc_int(2);
	    value = ptoc_int(3);
	    switch (value) {
	    case REF: 
	      bld_ref(vptr(addr+disp), (CPtr)ptoc_int(4)); break;
	    case INT:
	      tmpval = ptoc_int(4);
	      bld_int(vptr(addr+disp), tmpval); break;
	    case FLOAT:
	      bld_float(vptr(addr+disp), ptoc_float(4)); break;
	    case CS: 
	      bld_cs(vptr(addr+disp), (Pair)ptoc_int(4)); break;
	    case STRING:
	      bld_string(vptr(addr+disp), (char *)ptoc_int(4)); break;
	    case LIST:
	      bld_list(vptr(addr+disp), (CPtr)ptoc_int(4)); break;
/* dsw stuff */
            case STRUCT:
              bld_copy(vptr(addr+disp), ptoc_tag(4)); break;
	    default: printf("Type %d is not implemented by buff_set_cell\n",
			    value);
	    }
	    break;
	case BUFF_SET_VAR:
		/* This procedure is used in copyterm and make an external 
		variable pointing to the buffer. The linkage inside the buffer
		will not be trailed so remains after backtracking. */
		/* R1: +buffer; R2: +disp; */
		/* R3: +buffer length; R4: External var */

	    addr = ptoc_string(1);
	    disp = ptoc_int(2);
	    term = ptoc_tag(4);
	    bld_free(vptr(addr+disp));
	    if ((int)term < (int)addr || 
		(int)term > (int)addr+ptoc_int(3)) {
				/* var not in buffer, trail */
	      bind_ref(vptr(term), (CPtr)(addr+disp));
	    } else {		/* already in buffer */
	      bld_ref(vptr(term), (CPtr)(addr+disp));	
	    }
	    break;

	case CODE_CALL:		/* R1: +Code (addr), the code address */
				/* R2: +Term, the call to be made */
				/* R3: +Type, code type (same as psc->type)  */
				/* may need to resume interrupt testing here */
	    /* Note: this procedure does not save cpreg, hence is more like */
	    /* an "execute" instruction, and must be used as the last goal!!!*/
	    term = ptoc_tag(2);
	    value = ptoc_int(3);  /* Cannot be delayed! R3 may be reused */
	    pcreg = (byte *)ptoc_int(1);
	    if (isconstr(term)) {
	      psc = get_str_psc(term);
	      addr = (char *)(clref_val(term));
	      for (disp = 1; disp <= get_arity(psc); ++disp) {
		bld_copy(reg+disp, cell((CPtr)(addr)+disp));
	      }
	    bld_int(reg+get_arity(psc)+1,value);
	    }
	    if (value==T_FORN) {
#ifdef SOLARIS
		my_fptr = (PFI) get_ep(psc);
		if ((*my_fptr)()) pcreg = cpreg;
#else
		proc_ptr = (PFI) pcreg;
		if (proc_ptr()) pcreg = cpreg;		/* "proceed" */
#endif
		else pcreg = &fail_inst;		/* "fail" */
	    }
#ifdef TRACING
	    else if (value==T_PRED || value==T_FUNC || value == T_DYNA);
	    else { fprintf(stderr, "++Error: Undefined predicate/function %s/%d\n",
			   get_name(psc), get_arity(psc));
		   pcreg = &fail_inst;
		 }
#endif
	    break;
	case STR_LEN:		/* R1: +String; R2: -Length */
	    addr = ptoc_string(1);
	    if (addr) ctop_int(2, strlen(addr));
	    else ctop_int(2, 2);   /* need so in assembler; elsewhere?? */
	    break;
	case STR_CPY:		/* R1: +String; R2: +Buff */
	    strcpy(ptoc_string(2), ptoc_string(1));
	    break;
	case STR_CAT:		/* R1: +Str1; R2: +Str2: R3: -Str3 */
	    addr = (char *)hreg;	/* use global stack as temp space */
	    strcpy(addr, ptoc_string(1));
	    strcat(addr, ptoc_string(2));
	    ctop_string(3, (char *)string_find(addr, 1));
	    break;
	case STR_CMP:		/* R1: +Str1; R2: +Str2: R3: -Res*/
	    ctop_int(3, strcmp(ptoc_string(1), ptoc_string(2)));
	    break;
	case STR_HSH:		/* R1: +String; R2: +Arity;
				   R3: +HashSize: R4: -Value */
	    value = hash(ptoc_string(1), ptoc_int(2), ptoc_int(3));
	    ctop_int(4, value);
	    break;
	case STR_INSERT:	/* R1: +InString; R2: -OutString */
	    ctop_string(2, string_find(ptoc_string(1), 1));
	    break;
	case STAT_STA:		/* R1: +Amount */
	    value = ptoc_int(1);
	    print_statistics(value);
	    break;
	case STAT_CPUTIME:	/* R1: -cputime, in miliseconds */	
	    value =  cpu_time() * 1000;
	    ctop_int(1, value);
	    break;
	case CODE_LOAD:		/* R1: +FileName, bytecode file to be loaded */
				/* R2: -int, addr of 1st instruction;	*/
				/* R3 = 1 if exports to be exported, 0 otw*/
				/*	0 indicates an error */
	    ctop_int(2, (int)loader(ptoc_string(1), ptoc_int(3)));
	    break;
	case FILE_GETWORD:		/* r1: +file; r2: word (-int) */
	    tmpval = ptoc_int(1);
	    value = getw(fileptr(tmpval));
	    fix_bb((byte *)&value);
	    ctop_int(2, value);
	    break;
	case FILE_PUTWORD:		/* r1: +file; r2: word (+int) */
	    value = ptoc_int(2);
    	    fix_bb((byte *)&value);
	    tmpval = ptoc_int(1);
	    putw(value, fileptr(tmpval));
	    break;
	case PSC_INSERT:	/* R1: +String, symbol name; R2: +Arity; */
				/* R3: -PSC, the new PSC  */
	                        /* R4: +String, module to be inserted */
		/* insert or find a symbol in the given module.	 */
	        /* When the given module is 0 (null string), current module */
	        /* is used;                                       */
	    addr = ptoc_string(4);
	    if (addr) {
	        sym = (Pair)insert_module(0, addr);
		psc = sym->psc_ptr;
	    } else psc = (Psc)flags[CURRENT_MODULE];
	    sym = (Pair)insert(ptoc_string(1), ptoc_int(2), psc, &value);
	    ctop_string(3, (int)(sym->psc_ptr));
	    break;
	case PSC_IMPORT:      /* R1: +String, Predicate name to be imported */
	                      /* R2: +Arity, */
	                      /* R3: +String, Module name */
/* R1 is the psc record (ptr) to be imported */
	    addr = ptoc_string(3);
	    sym = (Pair)insert_module(0, addr);
	    addr = ptoc_string(1);
	    psc = sym->psc_ptr;
	    sym = (Pair)insert(addr, ptoc_int(2), psc, &value);
	    if (value) set_ep(sym->psc_ptr, (byte *)(psc));
	    env_type_set(sym->psc_ptr, T_IMPORTED, T_ORDI, value);
            link_sym(sym->psc_ptr, (Psc)flags[CURRENT_MODULE]);
	    break;
	case FILE_GETBUF:	 /* r1: +file; r2: +byte count (int) */
					/* r3: +buff (int); r4: +offset */
	    addr = ptoc_string(3);
	    disp = ptoc_int(4);
	    tmpval = ptoc_int(1);
	    fread(addr+disp, 1, ptoc_int(2), fileptr(tmpval));
	    break;
	case FILE_PUTBUF:	 /* r1: +file; r2: +byte count (int) */
					/* r3: +buff (int); r4: +offset */
	    addr = ptoc_string(3);
	    disp = ptoc_int(4);
	    tmpval = ptoc_int(1);
	    fwrite(addr+disp, 1, ptoc_int(2), fileptr(tmpval));
	    break;
        case FILE_GETTOKEN:     /* R1: +File, R2: +PrevCh, R3: -Type; */
                                /* R4: -Value, R5: -NextCh */
	    tmpval = ptoc_int(1);
            token = GetToken(fileptr(tmpval), ptoc_int(2));
	    if (token->type == TK_ERROR) {
		pcreg = &fail_inst;
	    }
            else {
		ctop_int(3, token->type);
		ctop_int(5, token->nextch);
		switch (token->type)     /* Modified for HiLog. (KFS) */
		{
		  case TK_PUNC	   : ctop_int(4, *(token->value)); break;
		  case TK_VARFUNC  : ctop_string(4, token->value); break;
		  case TK_VAR	   : ctop_string(4, token->value); break;
		  case TK_FUNC	   : ctop_string(4, token->value); break;
		  case TK_INT	   : ctop_int(4, *(int *)(token->value)); break;
		  case TK_ATOM	   : ctop_string(4, token->value); break;
		  case TK_EOC	   : ctop_int(4, 0); break;
		  case TK_VVAR	   : ctop_string(4, token->value); break;
		  case TK_VVARFUNC : ctop_string(4, token->value); break;
		  case TK_REAL	   : 
			float_temp = (float) *(double *)(token->value);
			ctop_float(4, float_temp); break;
		  case TK_EOF	   : ctop_int(4, 0); break;
		  case TK_STR	   : ctop_string(4, token->value); break;
		  case TK_LIST	   : ctop_string(4, token->value); break;
		  case TK_HPUNC	   : ctop_int(4, *(token->value)); break;
		  case TK_INTFUNC  : ctop_int(4, *(int *)(token->value)); break;
		  case TK_REALFUNC : 
			float_temp = (float) *(double *)(token->value);
                 	ctop_float(4, float_temp); break;
		}   
	    }
            break;
	case FILE_PUTTOKEN:	/* R1: +File, R2: +Type, R3: Value; */
	    tmpval = ptoc_int(1);
	    fptr = fileptr(tmpval);
	    switch (ptoc_int(2)) {
	    case FREE : fprintf(fptr, "_%d", ptoc_tag(3)); break;
	    case INT  : fprintf(fptr, "%d", ptoc_int(3)); break;
	    case STRING : fprintf(fptr, "%s", ptoc_string(3)); break;
	    case FLOAT : fprintf(fptr, "%.5g", ptoc_float(3)); break;

/* change tls
	    case DVAR: dom_print(fptr, ptoc_string(3)); break;*/
	    case TK_INT_0: value = ptoc_int(3); fix_bb((byte *)&value);
	      putw(value, fptr); break;
#ifdef DW
	    case TK_FLOAT_0: value = ptoc_int(3); fix_bb((byte *)&value);
#else
#endif
/*	    case TK_FLOAT_0: value = ptoc_int(3)<<4; fix_bb((byte *)&value);
	      putw(value, fptr); break;
*/	    case TK_FLOAT_0: float_temp = ptoc_float(3);
	      	        fwrite(&float_temp, 4, 1, fptr); break;
	    case TK_PREOP: print_op(fptr, ptoc_string(3), 1); break;
	    case TK_INOP : print_op(fptr, ptoc_string(3), 2); break;
	    case TK_POSTOP:print_op(fptr, ptoc_string(3), 3); break;
	    case TK_QATOM: print_qatom(fptr, ptoc_string(3)); break;
	    case TK_QSTR: fprintf(fptr, "\"%s\"", ptoc_string(3)); break;
	    default: printf("Unknown token type for file_puttoken\n");
	    }
	    break;
	case PSC_INSERTMOD:   /* R1: +String, Module name */
	                      /* R2: +Def (4 - is a definition; 0 -not) */
	                      /* R3: -PSC of the Module entry */
	    sym = (Pair)insert_module(ptoc_int(2), ptoc_string(1));
	    ctop_string(3, (int)(sym->psc_ptr));
	    break;
	case LOAD_SEG:		/* R1: +segment number */
				/* R2: +text bytes */
				/* R3: +index bytes */
				/* R4: +File name */
				/* R5: -Initial address */	  
	    tmpval = ptoc_int(4);
	    value = (int)load_seg(ptoc_int(1), ptoc_int(2),
		     ptoc_int(3), fileptr(tmpval));
	    ctop_int(5, value);
	    break;
	case TERM_HASH:		/* R1: +Term	*/
				/* R2: +Size (of hash table) */
				/* R3: -HashVal */
	    ctop_int(3, ihash(val_to_hash(ptoc_tag(1)),ptoc_int(2)));
	    break;
	case UNLOAD_SEG:	/* R1: -Code buffer */
	    unload_seg(ptoc_int(1));
	    break;
	case LOAD_OBJ:		/* R1: +FileName, R2: +Module (Psc) */
	    			/* R3: +ld option, R4: -InitAddr */
#ifdef FOREIGN
	    ctop_int(4, load_obj(ptoc_string(1), ptoc_int(2), ptoc_int(3)));
#else
	    quit("Loading foreign object files is not available for this machine\n");
#endif
	    break;
	case EXPAND_FILE_NAME:	/* R1: +FileName, R2: -ExpandedFileName */
	    ctop_string(2, expand_file_name(ptoc_string(1)));
	    break;
	case GETENV:		/* R1: +environment variable */
				/* R2: -value of that environment variable */
	    ctop_string(2, getenv(ptoc_string(1)));
	    break;
	case SYS_SYSCALL:	/* R1: +int (call #, see <syscall.h> */
				/* R2: -int, returned value */
	    			/* R3, ...: Arguments */
	    ctop_int(2, sys_syscall(ptoc_int(1)));
	    break;
	case SYS_SYSTEM:	/* R1: +String (of command), R2: -Int (res) */
	    ctop_int(2, system(ptoc_string(1)));
	    break;
	case SYS_GETHOST:
	    /* +R1: a string indicating the host name  */
	    /* +R2: a buffer (of length 16) for returned structure */
#ifndef AMIGA
	    hp = gethostbyname(ptoc_string(1));
	    bcopy(hp->h_addr, ptoc_string(2), hp->h_length);
	    break;
#else
	    quit("sys_gethost is not available for this machine\n");
#endif
	case SYS_ERRNO:			/* R1: -Int (errno) */
	    ctop_int(1, errno);
	    break;
	case SYS_BROCALL:	/* R1: +int (call #, see <syscall.h> */
			/* R2: buffer containing args in 4 byte fields */
			/* R3: buffer to put return value in. */
#ifdef NETWORK
	    sys_brocall(ptoc_int(1), ptoc_string(2), ptoc_string(3));
	    break;
#else
	    quit("sys_brocall");
#endif
	case FILE_TIME:		/* R1: +FileName (it should exist!!), */
				/* R2: -int (Modification Time)*/
	    if (!stat(ptoc_string(1), &stat_buff)) 
	      /* Time now takes 30 bits!!!, so take bottom 27, and hope! */
		 ctop_int(2, (0x7FFFFFF & stat_buff.st_mtime));
	    else ctop_int(2, 0);
	    break;
#ifdef XWAM
	case DOM_SIZE:
	case DOM_ESIZE:
	case DOM_TYPE:
	case DOM_RANGE:
	case DOM_ELEM:
	case DOM_DIFF:
	case DOM_PLUS:
	case DOM_TIMES:
	case DOM_MIN:
	case DOM_ENUM:
	    quit("builtin dom operation called");
#else
	case DOM_SIZE:
	    ctop_int(2, dom_size(ptoc_string(1))); 
	    break;
	case DOM_ESIZE:
	    ctop_int(2, dom_esize(ptoc_string(1))); 
	    break;
	case DOM_TYPE:
	    ctop_int(2, dom_type(ptoc_string(1))); 
	    break;
	case DOM_RANGE:
	    value = dom_range(ptoc_int(2), ptoc_int(3));
	    if (value) ctop_ref(1, value);
	    else return 0;
	    break;
	case DOM_ELEM:
	    return dom_elem(ptoc_string(1), ptoc_int(2)); 
	    break;
	case DOM_DIFF:
	    return dom_diff(ptoc_tag(1),ptoc_tag(2), ptoc_int(3));
	    break;
	case DOM_PLUS:
	    return dom_plus(ptoc_tag(1),ptoc_tag(2),ptoc_tag(3));
	    break;
	case DOM_TIMES:
	    return dom_times(ptoc_tag(1),ptoc_tag(2),ptoc_tag(3));
	    break;
	case DOM_MIN:
	    ctop_int(2, dom_min(ptoc_string(1))); 
	    break;
	case DOM_ENUM:
	    value = dom_enum(ptoc_int(2));
	    if (value) ctop_ref(1, value);
	    else return 0;
	    break;
#endif
	case BUFF_ASSIGN_WORD:	/* R1: +buffer; r2: displacement(+integer); */
				/* R3: value (+integer) */
	    /* backtrackable version of buff_set_word */
	    /* used in delaylib.P change tls */
	    addr = ptoc_string(1);
	    disp = ptoc_int(2);
	    /* back to pushtrail -- tls */
	    pushtrail((CPtr)(addr+disp),ptoc_int(3));
	    *(pw)(addr+disp) = ptoc_int(3);
	    break;
	case PSC_ENV:	       /* reg 1: +PSC; reg 2: -int */
			       /* env: 0 = exported, 1 = local, 2 = imported */
	    psc = (struct psc_rec *)ptoc_string(1);
	    ctop_int(2, (int)get_env(psc));
	    break;
	case PSC_SPY:		/* reg 1: +PSC; reg 2: -int */
				/* env: 0 = non-spied else spied */
	    psc = (struct psc_rec *)ptoc_string(1);
	    ctop_int(2, (int)get_spy(psc));
	    break;
	case PSC_TABLED:	/* reg 1: +PSC; reg 2: -int */
	    psc = (struct psc_rec *)ptoc_string(1);
	    ctop_int(2, (int)get_tip(psc));
	    break; 
	case TIP_PROP: /*reg1: +TIP; reg2: +field; reg3: +get/set; reg4: ?val*/
	    tip = (tab_inf_ptr) ptoc_string(1);
	    disp = ptoc_int(3);
	    switch (ptoc_int(2)) {
	      case CALL_NEXT_TIP:
	        if (disp == 1) get_next_tip(tip) = (CPtr) ptoc_int(4);
	        else if (disp == 0) ctop_int(4, get_next_tip(tip));
	        break;
	      case CALL_HASH_ADDR:
	        if (disp == 1) get_tab_entry(tip) = (CPtr) ptoc_int(4);
		else if (disp == 0) ctop_int(4, get_tab_entry(tip));
	        break;
	      case CALL_HASH_SIZE:
	        if (disp == 1)  get_chs(tip) = (long) ptoc_int(4);
		else if (disp == 0) ctop_int(4, get_chs(tip));
	        break;
	      case RET_HASH_SIZE:
	        if (disp == 1)  get_rhs(tip) = (long) ptoc_int(4);
		else if (disp == 0) ctop_int(4, get_rhs(tip));
	        break;
	      case FIRST_TIP:
	        if (disp == 1) first_tip = (tab_inf_ptr) ptoc_int(4);
		else if (disp == 0) ctop_int(4, first_tip);
		break;
	    }
	    break; 
	case IS_INCOMPLETE:   /* R1 is tabptr */
	                      /* R2 is complete */
	                      /* trying to save speed by ignoring ptoc stuff */
	                      /* infact, may be promoted to an instruction */
	  { int chs, i;
	    CPtr ep, prevsusrec, call_base;
	    tab_inf_ptr tip;

	    term = ptoc_tag(1);
	    if (cell_tag(term) == 1)
	      psc = get_str_psc(term);
	    else {
	      if (cell_tag(term) == 5) {
		psc = (Psc)flags[CURRENT_MODULE];
		sym = (Pair)insert(ptoc_string(1), ptoc_int(2), psc, &value);
	        psc = sym->psc_ptr;
	      }
	      else 
		quit("Improper Term Type\n");
	    }
	    arity = get_arity(psc);
	    tip =get_tip(psc);
	    chs = get_chs(tip);
	    ep = get_tab_entry(tip);
	    hash_call(term,arity,&ep,chs);
	    ctop_int(2, (int) call_str_retptr( ep));
	    if ((int)  *(call_str_susptr((CPtr) ep)) < 0) {
	      return 1;
	    }
	    else {
	      call_base = (CPtr) *(reg+1);
	      printf("*(reg+1) %x\n",*(reg+1));
	      cptr_deref(call_base);
	      prevsusrec = (CPtr) *(call_str_comp_susptr(ep));
	      printf("prevsusrev: %x term %x call_base %x \n",prevsusrec,term,call_base);
	      save_find_locx(ereg);
	      efreg = ebreg;
	      if (trreg > trfreg) trfreg = trreg;
	      if (hfreg < hreg) hfreg = hreg;
	      if (bfreg > breg) bfreg = breg;
/*	check_stack_overflow(bfreg, pcreg, (byte *)pcreg);*/
	      save_registers(bfreg, arity, i,(CPtr) cs_val(call_base));
	      save_lookup_rc_choicepoint(bfreg,ereg,ep,prevsusrec,cpreg);
	      printf("!suspending %x %x\n",bfreg,pcreg);
	      printf("cpreg %x\n",cpreg);
	      printf("pcreg %x\n",pcreg);
	      *(call_str_comp_susptr(ep)) = (Cell) bfreg; 
						  /* new susp into front */
	      return 0;
	    }
	  }
	    break;
	case GET_OSP_BREG:
/*	    printf("gob -- nb %x no %x\n",breg, openreg);*/
	    ctop_int(1,(int)openreg);
	    ctop_int(2,(int)breg);
	    break;
	case CUT_IF_LEADER:
	  { int chs, i;
	    CPtr ep, call_base, os_ptr, next_breg, next_openreg;
	    tab_inf_ptr tip;
	    register CPtr xtemp1, xtemp2;

	    term = ptoc_tag(1);
/*	    printf("term %x\n",term);*/
	    if (cell_tag(term) == 1)
	      psc = get_str_psc(term);
	    else {
	      if (cell_tag(term) == 5) {
		psc = (Psc)flags[CURRENT_MODULE];
		sym = (Pair)insert(ptoc_string(1), ptoc_int(2), psc, &value);
	        psc = sym->psc_ptr;
	      }
	      else 
		quit("Improper Term Type\n");
	    }
	    arity = get_arity(psc);
/*	    printf("arity %d\n",arity);*/
	    tip =get_tip(psc);
	    chs = get_chs(tip);
	    ep = get_tab_entry(tip);
	    hash_call(term,arity,&ep,chs);	    
            os_ptr = (CPtr) *call_str_openstackptr(ep);
/*	    if (os_ptr + OTFRAMESIZE <= (CPtr) OPENSTACKBOTTOM)
		printf("tl %d ntl %d\n",tab_level(ep),next_tab_level(ep));*/
	    if (os_ptr + OTFRAMESIZE > (CPtr) OPENSTACKBOTTOM || 
		 tab_level(ep) > next_tab_level(ep)) {
	      next_openreg = (CPtr) ptoc_int(2);
	      next_breg = (CPtr) ptoc_int(3);
/*	      printf("nb %x no %x\n",next_breg, next_openreg);*/
	      breg = next_breg;
	      cut_restore_trail_condition_registers(breg);
	      openreg = next_openreg;
	      remove_open_tables_loop(openreg);
	    }
	  }
	    break;
	case PAIR_PSC:
	    sym = (Pair)ptoc_string(1);
	    ctop_string(2, (int)pair_psc(sym));
	    break;
	case PAIR_NEXT:
	    sym = (Pair)ptoc_string(1);
	    ctop_int(2, (int)pair_next(sym));
	    break;
	case NEXT_BUCKET:      /* R1: +Address of Hash Table Pair Bucket. */
		    	       /* R2: -Next Address (O if end of Hash Table) */
	    if ((value = ptoc_int(1)+sizeof(Pair)) != 
				(int)(hash_table+(MAXBUCKET-1)))
		ctop_int(2, value);
	    else 
		ctop_int(2, 0);
	    break;
	case SUSPEND:      /* R1 is tabptr */
	                      /* trying to save speed by ignoring ptoc stuff */
	                      /* infact, may be promoted to an instruction */
{ 
  CPtr xcurcall, prevsusrec, call_base;
  int arity, i;

	tmpval = *(reg+1);
        call_base = (CPtr) int_val(tmpval);
/*	xcurcall = (CPtr) (ptoc_tag(2) >> 4) ; dsw ?? */
	xcurcall = (CPtr) (clref_val(ptoc_tag(2))) ;
        arity = ptoc_int(3);
	prevsusrec = (CPtr) *(call_str_comp_susptr(xcurcall)); 
	save_find_locx(ereg);
        efreg = ebreg;
	if (trreg > trfreg) trfreg = trreg;
	if (hfreg < hreg) hfreg = hreg;
	if (bfreg > breg) bfreg = breg;
/*	check_stack_overflow(bfreg, pcreg, (byte *)pcreg);*/
	save_registers(bfreg, arity, i, call_base);
        save_lookup_rc_choicepoint(bfreg,ereg,xcurcall,prevsusrec,cpreg);
	*(call_str_comp_susptr(xcurcall)) = (Cell) bfreg; 
						  /* new susp into front */
	return 0;
}
	case INCOMPLETE:      /* R1 is tabptr */
	                      /* R2 is complete */
	                      /* trying to save speed by ignoring ptoc stuff */
	                      /* infact, may be promoted to an instruction */
        { 
	  CPtr cptr_value;
/*	    term = ptoc_tag(1) ;*/
	    term = ptoc_int(1) ;
	    cptr_value = (reg + 2);
	    cptr_deref(cptr_value);
/*	    if ((int)  *(call_str_susptr((CPtr) (term >> 4))) < 0)
	    fprintf(stderr,"in INCOMPLETE\n");*/
	    if ((int)  *(call_str_susptr((CPtr) term)) < 0)
		bld_int(cptr_value, 0);
	    else bld_int(cptr_value, 1);
	}
	    break;
        case HEAP_COPYTERM:              /* R1: Pointer from which to copy */  
	                                 /* R2: Pointer of place to copy */
	    tmpval = *(reg+1);
	    term = (Cell) int_val(tmpval);
	    tmpval = *(reg+2);
	    value = int_val(tmpval);
	    if (macroprint) printf("buff copyterm %x %x\n",term,value);
	    if (macroprint) printf("buff copyterm %x %x\n",*(reg+1),*(reg+2));
	    heap_copyarg(term,value);
	    break;
        case TAB_INTERN:       /* R1: +List/Structure to intern */  
	                       /* R2: -Ptr to interned List/Structure */  
	    term = (Cell) *(reg+1);
	    if (macroprint) printf("table intern %x\n",term);
	    table_intern(term,threg,xtemp3,xtemp5,reg+2);
	    break;
        case IS_XWAMMODE:     /* R1: -int flag for xwammode */  
	    if (xwammode) ctop_int(1,1);
	    else ctop_int(1,0);
	    break;
        case CLOSE_OPEN_TABLES:       /* No registers needed*/
	    remove_open_tables_reset_freezes();
	    break;
	case CALL_HASH:       /* R1: +ptr to call on heap */
                              /* R2: +ptr to call hash table*/
	                      /* R3: +arity R4: +hashsize */
	                      /* R5: -ptr to call str in table */
            disp = ptoc_int(2);	
	    arity = ptoc_int(3);  value = ptoc_int(4);
	    hash_call(*(reg+1),arity,&disp,value);
	    ctop_int(5,disp);
	    break;
	case PRINT_PREDICATE_TABLE:		/* reg 1: +PSC;*/
#ifdef DEBUG
	    psc = (struct psc_rec *)ptoc_string(1);
	    if( (int) get_tip(psc) == 0) 
	      printf("%s/%d is not tabled\n",get_name(psc),get_arity(psc));
	    else {
	      print_predicate_table(get_name(psc),get_arity(psc),
				    (int) get_tip(psc));
	    }
#else
	    quit("print_predicate_table is only available for debug mode\n");
#endif
	    break;
	case ANALYZE_PREDICATE_TABLE:		/* reg 1: +PSC;*/
	    psc = (struct psc_rec *)ptoc_string(1);
	    if( (int) get_tip(psc) == 0) 
	      printf("%s/%d is not tabled\n",get_name(psc),get_arity(psc));
	    else {
	      analyze_predicate_table(get_name(psc),get_arity(psc),
				    (int) get_tip(psc));
	    }
	    break;
	case COMP_CODE_CALL:	/* R1: +Code (addr), the code address */
				/* R2: +Term, the call to be made */
				/* may need to resume interrupt testing here */
	    /* Note: this procedure does not save cpreg, hence is more like */
	    /* an "execute" instruction, and must be used as the last goal!!!*/
	    term = ptoc_tag(2);
	    psc = (struct psc_rec *)ptoc_string(1);
	    pcreg = (byte *) get_ep(psc);
	    comptableflag = 1;
	    if (isconstr(term)) {
	      psc = get_str_psc(term);
	      addr = (char *)(clref_val(term));
	      for (disp = 1; disp <= get_arity(psc); ++disp) {
		bld_copy(reg+disp, cell((CPtr)(addr)+disp));
	      }
	    bld_int(reg+get_arity(psc)+1,value);
	    }
	    break;
	  case ABOLISH_TABLE_INFO:
	    abolish_table_info();
	    break;
#ifdef PROFILE
	  case ZERO_OUT_PROFILE:
	    { int i;
	    for (i = 0 ; i <= 256 ; i++) {
	      inst_table[i][5] = 0;
	      builtin_table[i][1] = 0;
	      subinst_table[i][1] = 0;
	    }
	    }
	    break;
	  case WRITE_OUT_PROFILE:
	    write_out_profile();
	    break;
#endif
	  case ASSERT_CODE_TO_BUFF:
	    assert_code_to_buff();
	    break;
	  case ASSERT_BUFF_TO_CLREF:
	    assert_buff_to_clref();
	    break;
	  case FMT_WRITE:
	    return fmt_write();
	  case FMT_READ:
	    return fmt_read();
	  default:
	    ("Builtin #%d is not implemented.\n", number);
	    quit("Abnormal termination");
	    break;
	  }
    m_verr_bi();
    return 1;
}

/*------------------------- Auxiliary functions -----------------------------*/

/* Expands the initial ~ of a Unix filename and returns the absolute path 
 * name of the file.  Returns the input unchanged if no initial ~ 
 */
char *expand_file_name(file_name)
char * file_name;
{
int tlen, lose;
struct passwd *pw_struct;
char expanded_file_name[1024];  /* max filename length, LIMIT */
register char *new_dir, *p;
char user_name[64];  /* max username length, LIMIT */

   /* If file_name is absolute, flush ...// and detect /./ and /../.
      If no /./ or /../ we can return right away. */

   if (file_name[0] == '/')
   {
	p = file_name; lose = 0;
	while (*p)
	{
	    if (p[0] == '/' && p[1] == '/')
		file_name = p + 1;
	    if (p[0] == '/' && p[1] == '~')
		file_name = p + 1, lose = 1;
	    if (p[0] == '/' && p[1] == '.'
		&& (p[2] == '/' || p[2] == 0
		    || (p[2] == '.' && (p[3] == '/' || p[3] == 0))))
		lose = 1;
	    p++;
	}
	if (!lose)
	{
	    return file_name;
	}
   }

   /* Now determine directory to start with and put it in new_dir */

   new_dir = 0;

   if (file_name[0] == '~') 
   {
	if (file_name[1] == '/' || file_name[1] == 0)	/* prefix ~/ or single ~ */
	{
	    if (!(new_dir = (char *)getenv("HOME")))
	        new_dir = "";
	    file_name++;
	}
	else		/* prefix  ~username/ */
	{
	    for (p = file_name; *p && (*p != '/'); p++);
/*	    user_name = (char *)alloca((p - file_name) + 1); */
	    bcopy (file_name, user_name, p - file_name);
	    user_name[p - file_name] = 0;

	    pw_struct = (struct passwd *) getpwnam(user_name + 1);
	    if (!pw_struct)
	    {
		fprintf(stderr, "++Error: \"%s\" is not a registered user\n", 
				user_name + 1);
		return file_name;   /* return the input file name unchanged */
	    }
 
	    file_name = p;
	    new_dir = pw_struct -> pw_dir;
	}

        /* Now concatenate the directory name and the file name to new space 
	   in the stack */

	tlen = (new_dir ? strlen(new_dir) + 1 : 0) + strlen(file_name) + 1;
/*	expanded_file_name = (char *)alloca(tlen); */
	if (new_dir) strcpy(expanded_file_name, new_dir);
	strcat(expanded_file_name, file_name);

	return ((char *)string_find(expanded_file_name, 1));
   }
   else /* if the file_name does not begin with a ~ return it unchanged */
	return file_name;
}

#ifdef DEBUG
print_predicate_table(name,arity,tip)
char * name;
tab_inf_ptr tip;
{
  CPtr current_pred,call_ptr,call_hash_ptr,call_hash_ptr_return;
  CPtr call_hash_return_hash_ptr;
  long CHS,RHS;

  current_pred = (CPtr) get_tab_entry(tip);
  if (get_tab_entry(tip) == 0)
    printf("\t No calls for %s/%d\n",name,arity);
  else {
    CHS = get_chs(tip);
    RHS = get_rhs(tip);
    for ( call_ptr = current_pred ; call_ptr > current_pred - CHS; call_ptr--)
      if ( (Cell) *call_ptr > 0) {
	call_hash_ptr = (CPtr) *call_ptr;
	while (call_hash_ptr != 0 ) {
	  table_print_call(1,name,call_hash_ptr-CALLSTRUCTSIZE -1,arity);
	  if ( (int) *(call_hash_ptr-1) > 0) 
	  for ( call_hash_ptr_return = ((CPtr) *(call_hash_ptr-1)) ; 
	       call_hash_ptr_return > 
	           ((CPtr) *(call_hash_ptr-1)) - RHS; 
	       call_hash_ptr_return--) {
	    if ( (Cell) *(call_hash_ptr_return) > 0) {
	      call_hash_return_hash_ptr = (CPtr) *(call_hash_ptr_return);
	      while ((int) call_hash_return_hash_ptr > 0) {
		table_print_call(2,name,call_hash_return_hash_ptr -2,arity);
		call_hash_return_hash_ptr = (CPtr) *call_hash_return_hash_ptr;
	      }
	    }
	  }
	  call_hash_ptr = (CPtr) *call_hash_ptr;
	}	
      }
  }
}

/* printterm is in debug.c */
table_print_call(tabnum,name,base,arity)
char * name;
CPtr base;
{     
  CPtr arg_ptr = base;
  Cell temp_arg_ptr;
  int varnum,i;

  for ( i = 0 ; i < tabnum; i++) printf("  ");
  printf(" %s(",name);
  for ( arg_ptr = base; arg_ptr > base - arity; arg_ptr--) {
    printterm((Cell) arg_ptr,(byte) 1,24);
    if (arg_ptr != base - arity + 1)
      printf(",");
  }
    printf(")\n");
}
#endif /* DEBUG */

analyze_predicate_table(name,arity,tip)
char * name;
tab_inf_ptr tip;

{
  CPtr current_pred,call_ptr,call_hash_ptr,call_hash_ptr_return,
       call_hash_return_hash_ptr;
  int hash_full = 0,call_bucket_length, ret_bucket_length = 0,
      max_call_bucket_length = 0,max_ret_bucket_length = 0,
      ret_hash_full=0;
  double tot_ret_bucket_length =0, tot_call_bucket_length=0;
  long CHS,RHS;

  current_pred = (CPtr) get_tab_entry(tip);
  if (get_tab_entry(tip) == 0)
    printf("\t No calls for %s/%d\n",name,arity);
  else {
    CHS = get_chs(tip);
    RHS = get_rhs(tip);
     for ( call_ptr = current_pred ; call_ptr > current_pred - CHS; call_ptr--)
      if ( (Cell) *call_ptr > 0) {
	hash_full++;
	call_hash_ptr = (CPtr) *call_ptr;
	call_bucket_length = 0;
	while (call_hash_ptr != 0 ) {
	  call_bucket_length++;
	  if ( (int) *(call_hash_ptr-1) > 0)
	  for ( call_hash_ptr_return = ((CPtr) *(call_hash_ptr-1)) ; 
	       call_hash_ptr_return > 
	           ((CPtr) *(call_hash_ptr-1)) - RHS; 
	       call_hash_ptr_return--) {
	    ret_bucket_length = 0;
	    if ( (int) *(call_hash_ptr_return) > 0) {
	      ret_hash_full++;
	      call_hash_return_hash_ptr = (CPtr) *(call_hash_ptr_return);
	      while ((int) call_hash_return_hash_ptr > 0) {
		ret_bucket_length++;
		call_hash_return_hash_ptr = (CPtr) *call_hash_return_hash_ptr;
	      }
	      tot_ret_bucket_length = tot_ret_bucket_length+ret_bucket_length;
	      if (ret_bucket_length > max_ret_bucket_length)
		max_ret_bucket_length = ret_bucket_length;
	    }
	  }
	  call_hash_ptr = (CPtr) *call_hash_ptr;
	}	
	tot_call_bucket_length = tot_call_bucket_length + call_bucket_length;
	if (call_bucket_length > max_call_bucket_length)
	  max_call_bucket_length = call_bucket_length;
      }
    printf("\t\t %d hash buckets full out of %d\n",hash_full,CHS);
    printf("\t\t avg call bucket length (of filled) %.2f\n",
                               tot_call_bucket_length/hash_full);
    printf("\t\t max call bucket length %d\n",max_call_bucket_length);
    printf("\t\t ret buckets used %d out of %d\n",ret_hash_full,RHS);
    printf("\t\t avg return bucket length %.2f\n",
	                (tot_ret_bucket_length/ret_hash_full));
    printf("\t\t max ret bucket length %d\n",max_ret_bucket_length);
#ifdef OLDTPROFILE
    printf("====GLOBAL INFO====\n");
    printf("\t number of suspensions %d\n",suspension_num);
    printf("\t number of use_tables %d\n",use_table_num);
    printf("\t number of new_lookups %d\n",new_lookup_num);
    printf("\t number of return_solutions %d\n",return_solution_num);
    printf("\t number of return_completions %d\n",return_completion_num);
    printf("\t number of (poss duplicate) solutions entered %d\n",
	   all_solutions);
    printf("\t number of variant checks %d\n",variant_check_num);
#endif
  }
}

abolish_table_info()
{
  tab_inf_ptr temp;

  temp = first_tip;
  while (temp != 0) {
    get_tab_entry(temp) = 0;
    temp = (tab_inf_ptr) get_next_tip(temp);
  }
  while (tabreg < (CPtr) (main_thread->maxsusp) -1)
          *tabreg++ = 0;
  *tabreg = 0;
  threg = (CPtr) main_thread->pdl;
  reset_freeze_registers;
  openreg = OPENSTACKBOTTOM;
#ifdef OLDTPROFILE
  suspension_num = all_solutions = variant_check_num = 0;
  new_lookup_num = use_table_num = 0;
  return_solution_num = return_completion_num = 0;
#endif
}

hash_call(term,arity,hash_tab_addr_ptr,hashsize)
CPtr term,hash_tab_addr_ptr;
{
  CPtr temp1,temp2,temp,bucket;
  int flag;

  cptr_deref(term);
  term = (CPtr) cs_val(term);
  tabhash((term +1),hashsize,bucket,temp1,temp2); 
  *(CPtr *) hash_tab_addr_ptr = 
                             (*(CPtr *)hash_tab_addr_ptr) - (unsigned) bucket;
  temp = (CPtr) *hash_tab_addr_ptr;
  traverse_call_bucket(&temp,term,arity,&flag);
  if (flag)   * (CPtr *)hash_tab_addr_ptr = temp;
  else  *(int *) hash_tab_addr_ptr = 0;
}

/* assumed to be ground, so no trailing needed */
table_intern(ptr,tptr,temp1,temp2,output)
CPtr ptr, tptr;
Cell temp1, temp2,output;
{
  int j, temp3;
  Cell holder, resetval;

     temp1 =  (Cell) ptr;
     scaffolded_deref(temp1);
     scaffolded_deref(output);
     holder = (Cell) tptr;
     if (macroprint) printf("cell tag %x\n",cell_tag(temp1));
     switch (cell_tag(temp1)) { 
       case INT: case STRING: /*case FLOAT:*/ 
         break;
       case LIST:
	 if (macroprint)  printf("ti list copy pdlreg: %x\n",pdlreg);
	 if (macroprint)  printf("*tptr: %x\n",*tptr);
       	 pdlpush(cell(clref_val(temp1)));
	 if (macroprint)  printf("*pdlreg: %x\n",*(pdlreg+1));
	 pdlpush(cell(clref_val(temp1) +1));
         if (macroprint)  printf("*pdlreg: %x\n",*(pdlreg+1));
	 threg1 = threg + 2;
	 quick_tabcopy(temp1);
         if (macroprint) printf("q_st done for list&&&&&&&&&&&&&&&&&& \n");
	 bind_list((CPtr) * (CPtr) output,holder);
         break;
       case CS:
	 if (macroprint) printf("ti CS copy pdlreg: %xn",pdlreg);
	 bld_ref(threg, cell(clref_val(temp1))); threg++;
         for (j=1 ; j <= get_arity(get_str_psc(temp1))
	          ;  j++) {
  	   pdlpush(cell(clref_val(temp1) +j));
	   if (macroprint) printf("*pdlreg: %x\n",*(pdlreg+1));
	 }
	 threg1 = threg + j - 1;
	 quick_tabcopy(temp1);
	 bind_cs((CPtr) * (CPtr) output,holder);
	 if (macroprint) printf("q_st done for struct&&&&&&&&&&&&&&&&&&&n");
         break; 
       }
     resetpdl;
}

#ifdef PROFILE
write_out_profile()
{ 
  int i, isum, ssum, tot;
  double rat1,rat2;

  isum = ssum = tot = 0;
  for (i = 0 ; i < 256 ; i++) {
    if (inst_table[i][0] != 0) isum = isum + inst_table[i][5];
  }
  for (i = 0 ; i < 256 ; i++) {
    if (subinst_table[i][0] != 0) ssum = ssum + subinst_table[i][1];
  }
  tot = isum + ssum;
  rat1 = isum / tot;
  rat2 = ssum / tot;
  if (tot!=0)
    fprintf(stdout,"total: %d inst: %d pct %g subinst: %d pct %g\n",
	    tot,isum,rat1,ssum,rat2);
  for (i = 0 ; i < 256 ; i++) {
    if (inst_table[i][0] != 0) {
      isum = inst_table[i][5];
      rat1 = isum / tot;
      fprintf(stdout,"-- %s %x %d %g\n",inst_table[i][0],i,
	      inst_table[i][5],rat1);
    }
  }
  fprintf(stdout,"_______________subinsts_______________\n");
  for (i = 0 ; i < 256 ; i++) {
    if (subinst_table[i][0] != 0) {
      ssum = subinst_table[i][1];
      rat1 = ssum/tot;
      fprintf(stdout,"-- %s %x %d %g \n",subinst_table[i][0],i,
	      subinst_table[i][1],rat1);
    }
  }
  fprintf(stdout,"_______________builtins_______________\n");
  for (i = 0 ; i < 256 ; i++)
    if (builtin_table[i][1] > 0 && builtin_table[i][0] != 0)
      fprintf(stdout,"%s %d %d \n",builtin_table[i][0],i,builtin_table[i][1]);
  fprintf(stdout,"====GLOBAL INFO====\n");
  fprintf(stdout,"\t number of suspensions %d\n",suspension_num);
  fprintf(stdout,"\t number of new_lookups %d\n",new_lookup_num);
  fprintf(stdout,"\t number of return_solutions %d\n",return_solution_num);
  fprintf(stdout,"\t number of return_completions %d\n",return_completion_num);
  fprintf(stdout,"\t number of (poss duplicate) solutions entered %d\n",
	   all_solutions);
  fprintf(stdout,"\t number of variant checks %d\n",variant_check_num);
}
#endif

/*======================================================================*/
/* db_cmpl(+Clause, +Buffer, +Index, -Size)                             */
/*      Clause is a fact or rule.                                       */
/*      Buffer is the buffer where the code is put.                     */
/*      Index is the argument to index on (0 if none).                  */
/*      Size is the size of the compiled code                           */
/* The predicate will generate code for the given clause in the Buffer. */
/* The first 8 bytes are reserved for general chain.  If index is       */
/* requested, the 2nd 8 bytes are used for the buckete chain. See Code  */
/* below.                                                               */
/*======================================================================*/


static jmp_buf assertcmp_env;

struct flatten_elt {
	union {
		prolog_term term;
		int opcode;
	} v;
	int reg;
};

struct instruction {
	int opcode;
	int arg1;
	int arg2;
};

static struct flatten_elt flatten_stack[512];
static struct instruction inst_queue[1024];
static int flatten_stack_top;
static int inst_queue_top;
static int inst_queue_bottom;

#define write_byte(Buff,b) { *(Buff + (*Loc)) = b; *Loc += 1; }
#define write_word(Buff,w) { *(int *)(Buff + (*Loc)) = (int)(w); *Loc += 4; }

static assertcmp_throw(num)
int num;
{
    longjmp(assertcmp_env, num);
}

#define ERR_FUNCTOR 1
#define ERR_REGISTER 2

static assertcmp_printerror(num)
{
    switch (num) {
    case ERR_FUNCTOR: fprintf(stderr, "Assert: functor expected\n");
	break;
    case ERR_REGISTER:
	fprintf(stderr, "Assert: need too many registers\n");
	break;
    default:  fprintf(stderr, "error occured in assert_cmp\n");
    }
}

/* db_cmpl(Clause, Buff, Index, Size) */

static p2c_psc(T0)
prolog_term T0;
{
    int *addr;
    addr = (int *)int_val(T0);
    return *addr;
}

static int p2c_float_as_int(T0)
prolog_term T0;
{
    union float_conv {
	float f;
	int i;
    } float_conv;
    float_conv.f = float_val(T0);
    return float_conv.i;
}

static int is_frozen_var(T0)
prolog_term T0;
{
    if (is_functor(T0) && strcmp(p2c_functor(T0), "$assertVAR")==0 &&
	p2c_arity(T0) == 1) {
	T0 = p2p_arg(T0, 1);
	return int_val(T0);
    } else return 0;
}

static flatten_stack_init(flatten_stack)
struct flatten_elt *flatten_stack;
{
    flatten_stack_top = 0;
}

static flatten_stack_empty(flatten_stack)
struct flatten_elt *flatten_stack;
{
    return (flatten_stack_top == 0);
}

static int flatten_stack_size(flatten_stack)
struct flatten_elt *flatten_stack;
{
    return flatten_stack_top;
}

static flatten_stack_push(flatten_stack, argno, term)
struct flatten_elt *flatten_stack;
{
    flatten_stack[flatten_stack_top].reg = argno;
    flatten_stack[flatten_stack_top].v.opcode = term;
    flatten_stack_top++;
}

static flatten_stack_pop(flatten_stack, argnop, termp)
struct flatten_elt *flatten_stack;
int *argnop, *termp;
{
    flatten_stack_top--;
    *argnop = flatten_stack[flatten_stack_top].reg;
    *termp = flatten_stack[flatten_stack_top].v.opcode;
}

static inst_queue_init(inst_queue)
struct instruction *inst_queue;
{
    inst_queue_top = 0;
    inst_queue_bottom = 0;
}

static inst_queue_empty(inst_queue)
struct instruction *inst_queue;
{
    return (inst_queue_top == inst_queue_bottom);
}

static inst_queue_push(inst_queue, opcode, arg1, arg2)
struct instruction *inst_queue;
{
    inst_queue[inst_queue_top].opcode = opcode;
    inst_queue[inst_queue_top].arg1 = arg1;
    inst_queue[inst_queue_top].arg2 = arg2;
    inst_queue_top++;
}

static inst_queue_pop(inst_queue, opcodep, arg1p, arg2p)
struct instruction *inst_queue;
int *opcodep, *arg1p, *arg2p;
{
    *opcodep = inst_queue[inst_queue_bottom].opcode;
    *arg1p = inst_queue[inst_queue_bottom].arg1;
    *arg2p = inst_queue[inst_queue_bottom].arg2;
    inst_queue_bottom++;
}

typedef int *RegStat;
	/* 0 - all rest registers are free */
	/* >0 - next free register */
	/* -1 used for real var */
	/* -2 used for introduced var */

#define RVAR -1
#define TVAR -2

static int RegArray[256];
static int FreeReg;

static RegStat reg_init(Size)
{
    int i;

    FreeReg = Size+1;
    for (i=0; i<FreeReg; i++) RegArray[i] = RVAR;
    RegArray[FreeReg] = 0;
    return RegArray;
}

/* Type: RVAR=-1 - used for real var; TVAR=-2 - used for introduced var */
static int reg_get(Reg, Type)
RegStat Reg;
{
    int new_reg;

    new_reg = FreeReg;
    if (RegArray[FreeReg]==0) {
	FreeReg++;
	if (FreeReg > 255) {
	    fprintf(stderr, "Assert: need too many registers\n");
	    assertcmp_throw(ERR_REGISTER);
	}
	RegArray[FreeReg] = 0;
    } else FreeReg = RegArray[FreeReg];
    RegArray[new_reg] = Type;
    return new_reg;
}

static reg_release(R0)
int R0;
{
    if (RegArray[R0]==TVAR) {
	RegArray[R0] = FreeReg;
	FreeReg = R0;
    }
}

#define max(p1,p2) (p1>=p2?p1:p2)
static char Buff[65536];
static int Size;

/*======================================================================*/
/* The following code compiles a clause into a local buffer. It treats	*/
/* all rules as though they had a single literal on the			*/
/* right-hand-side. Thus it compiles a clause with more than one 	*/
/* literal on the right-hand-side as a call to the predicate ,/2	*/
/*======================================================================*/

assert_code_to_buff(/* Clause,Size */)
{
  prolog_term Clause;
  int Index;
  prolog_term Head, Body;
  int Location;
  int *Loc;
  RegStat Reg;
  int Arity;
  int has_body;
  int Argno;
  int v; Pair sym;
  
  Clause = reg_term(1);
  /* set catcher */
  if (Argno = setjmp(assertcmp_env)) {
    assertcmp_printerror(Argno);
    return FALSE;
  }
  if (isconstr(Clause) && strcmp(p2c_functor(Clause),":-")==0 &&
      get_arity(get_str_psc(Clause))==2) {

    Head = p2p_arg(Clause, 1);
    Body = p2p_arg(Clause, 2);
    if (isstring(Body)) {
      if (isnil(Body)) {
	fprintf(stderr,"***Error: [] cannot be body of assert\n");
	return FALSE;
      }
      sym = (Pair)insert(string_val(Body),0,
			 (Psc)flags[CURRENT_MODULE],&v);
      Body = makecs(hreg);
      new_heap_functor(hreg,sym->psc_ptr);
    }
    has_body = 1;
  } else {
    Head = Clause;
    has_body = 0;
  }
  Arity = arity(Head);
  Location = 0;
  Loc = &Location;
  if (has_body) Reg = reg_init(max(Arity,get_arity(get_str_psc(Body))));
  else Reg = reg_init(Arity);
  for (Argno = 1; Argno <= Arity; Argno++) {
    db_gentopinst(p2p_arg(Head,Argno),Argno,Reg,Buff,Loc);
  }
  if (has_body) {
    inst_queue_init(inst_queue);
    for (Argno=1; Argno<=arity(Body); Argno++) {
      db_genaput(p2p_arg(Body,Argno),Argno,inst_queue,Reg,Buff,Loc);
    }
    db_genmvs(inst_queue,Reg,Buff,Loc);
    dbgen_inst(execute, get_str_psc(Body), 0, Buff, Loc);
  } else dbgen_inst(proceed, 0, 0, Buff, Loc);
  Size = *Loc;
  ctop_int(2,Size);
  return TRUE;
}

db_gentopinst(T0,Argno,Reg,Buff,Loc)
     RegStat Reg; int *Loc;
     prolog_term T0;
     char *Buff;
{
  int Rt;
  
  if (is_var(T0)) {
    c2p_functor("$assertVAR", 1, T0);
    T0 = p2p_arg(T0, 1);
    c2p_int(Argno, T0);
  } else if (is_nil(T0)) {
    dbgen_inst(getnil, Argno, 0, Buff, Loc);              /* getnil */
  } else if (is_string(T0)) {
    dbgen_inst(getcon, Argno, (int)string_val(T0), Buff, Loc);  /* getcon */
  } else if (is_int(T0)) {
    dbgen_inst(getnumcon, Argno, int_val(T0), Buff, Loc); /* getnumcon */
  } else if (is_float(T0)) {
    dbgen_inst(getfloat, Argno, p2c_float_as_int(T0),Buff, Loc);  /* getfloat */
  } else if (Rt=is_frozen_var(T0)) {
    dbgen_inst(gettval, Rt, Argno, Buff, Loc);  	/* gettval */
  } else {
    inst_queue_init(inst_queue);
    inst_queue_push(inst_queue, Argno, T0, 0);
    db_genterms(inst_queue,Reg,Buff,Loc);
  }
}

db_genterms(inst_queue, Reg, Buff, Loc)
     RegStat Reg; int *Loc;
     char *Buff;
     struct instruction *inst_queue;
{
  prolog_term T0, T1, T2;
  int Argno;
  
  while (!inst_queue_empty(inst_queue)) {
    inst_queue_pop(inst_queue, &Argno, &T0, &T1);
    if (is_list(T0)) {
      T1 = p2p_car(T0);
      T2 = p2p_cdr(T0);
      if (is_var(T1) && is_var(T2) && T1!=T2 /* not same var */) {
	int Rt1, Rt2;
	c2p_functor("$assertVAR", 1, T1);
	T1 = p2p_arg(T1, 1);
	Rt1 = reg_get(Reg, RVAR);
	c2p_int(Rt1, T1);
	c2p_functor("$assertVAR", 1, T2);
	T2 = p2p_arg(T2, 1);
	Rt2 = reg_get(Reg, RVAR);
	c2p_int(Rt2, T2);
	dbgen_inst3(getlist_tvar_tvar, Argno, Rt1, Rt2, Buff, Loc);
	reg_release(Argno);
      } else {
	dbgen_inst(getlist, Argno, 0, Buff, Loc);    /* getlist */
	reg_release(Argno);
	db_geninst(p2p_car(T0), Reg, inst_queue, Buff,Loc);
	db_geninst(p2p_cdr(T0), Reg, inst_queue, Buff,Loc);
      }
    } else {
      dbgen_inst(getstr, Argno, get_str_psc(T0), Buff, Loc);   /* getstr */
      reg_release(Argno);
      for (Argno=1;Argno<=get_arity(get_str_psc(T0)); Argno++) {
	db_geninst(p2p_arg(T0,Argno), Reg, inst_queue, Buff,Loc);
      }
    }
  }
}

db_geninst(Sub,Reg,inst_queue,Buff,Loc)
     RegStat Reg; int *Loc;
     prolog_term Sub;
     char *Buff;
     struct instruction *inst_queue;
{
  int Rt;
  
  if (is_var(Sub)) {
    c2p_functor("$assertVAR", 1, Sub);
    Sub = p2p_arg(Sub, 1);
    Rt = reg_get(Reg, RVAR);
    c2p_int(Rt, Sub);
    dbgen_inst(unitvar, Rt, 0, Buff, Loc);          /* unitvar */
  } else if (is_nil(Sub)) {
    dbgen_inst(uninil, 0, 0, Buff, Loc);	 /* uninil */
  } else if (is_string(Sub)) {
    dbgen_inst(unicon, (int)p2c_string(Sub), 0, Buff, Loc);  /* unicon */
  } else if (is_int(Sub)) {
    dbgen_inst(uninumcon, int_val(Sub), 0, Buff, Loc);   /* uninumcon */
  } else if (is_float(Sub)) {
    dbgen_inst(unifloat, p2c_float_as_int(Sub), 0, Buff, Loc);    /* unifloat */
  } else if (Rt=is_frozen_var(Sub)) {
    dbgen_inst(unitval, Rt, 0, Buff, Loc);       /* unitval */
  } else {
    Rt = reg_get(Reg, TVAR);
    dbgen_inst(unitvar, Rt, 0, Buff, Loc);   /* unitvar */
    inst_queue_push(inst_queue, Rt, Sub, 0);
  }
}

db_genaput(T0,Argno,inst_queue,Reg,Buff,Loc)
     prolog_term T0;
     RegStat Reg; int *Loc;
     struct instruction *inst_queue;
     char *Buff;
{
  int Rt;
  
  if (is_var(T0)) {
    c2p_functor("$assertVAR", 1, T0);
    T0 = p2p_arg(T0, 1);
    Rt = reg_get(Reg, RVAR);
    c2p_int(Rt, T0);  /* used to be TempVar???? */
    dbgen_inst(puttvar, Rt, Rt, Buff, Loc);
    inst_queue_push(inst_queue, movreg, Rt, Argno);
  } else if (Rt=is_frozen_var(T0)) {
    inst_queue_push(inst_queue, movreg, Rt, Argno);
  } else if (is_int(T0)) {
    inst_queue_push(inst_queue, putnumcon, int_val(T0), Argno);
  } else if (is_float(T0)) {
    inst_queue_push(inst_queue, putnumcon, p2c_float_as_int(T0), Argno);
  } else if (is_nil(T0)) {
    inst_queue_push(inst_queue, putnil, 0, Argno);
  } else if (is_string(T0)) {
    inst_queue_push(inst_queue, putcon, (int)p2c_string(T0), Argno);
  } else {  /* structure */
    Rt = reg_get(Reg, TVAR);
    inst_queue_push(inst_queue, movreg, Rt, Argno);
    flatten_stack_init(flatten_stack);
    db_putterm(Rt,T0,Reg,Buff,Loc);
  }
}

db_putterm(Rt,T0,Reg,Buff,Loc)
     prolog_term T0;
     RegStat Reg; int *Loc;
     char *Buff;
{
  int Argno;
  int BldOpcode, Arg1;
  int stack_size;
  
  stack_size = flatten_stack_size(flatten_stack);
  if (is_list(T0)) {
    db_bldsubs(p2p_cdr(T0),Reg,flatten_stack,Buff,Loc);
    db_bldsubs(p2p_car(T0),Reg,flatten_stack,Buff,Loc);
    dbgen_inst(putlist, Rt, 0, Buff, Loc);			/* putlist */
  } else { /* structure */
    for (Argno=get_arity(get_str_psc(T0)); Argno>=1; Argno--)
      db_bldsubs(p2p_arg(T0,Argno),Reg,flatten_stack,Buff,Loc);
    dbgen_inst(putstr, Rt, get_str_psc(T0), Buff, Loc);	/* putstr */
  }
  while (flatten_stack_size(flatten_stack)>stack_size) {
    flatten_stack_pop(flatten_stack, &BldOpcode, &Arg1);	
    /* be careful about order!!*/
    dbgen_inst(BldOpcode, Arg1, 0, Buff, Loc);
    if (BldOpcode==bldtval) reg_release(Arg1);
  }
}

db_bldsubs(Sub,Reg,flatten_stack,Buff,Loc)
     prolog_term Sub;
     RegStat Reg; int *Loc;
     char *Buff;
     struct flatten_elt *flatten_stack;
{
  int Rt;
  
  if (is_var(Sub)) {
    c2p_functor("$assertVAR", 1, Sub);
    Sub = p2p_arg(Sub, 1);
    Rt = reg_get(Reg, RVAR);
    c2p_int(Rt, Sub);
    flatten_stack_push(flatten_stack, bldtvar, Rt);    /* bldtvar(Ri) */
  } else if (is_nil(Sub)) {
    flatten_stack_push(flatten_stack, bldnil, 0);      /* bldnil */
  } else if (is_string(Sub)) {
    flatten_stack_push(flatten_stack,bldcon,(int)string_val(Sub)); /* bldcon */
  } else if (is_int(Sub)) {               /* bldnumcon(Sub) */
    flatten_stack_push(flatten_stack, bldnumcon, int_val(Sub));
  } else if (is_float(Sub)) {             /* bldfloat(Sub) */
    flatten_stack_push(flatten_stack, bldfloat, p2c_float_as_int(Sub));
  } else if (Rt = is_frozen_var(Sub)) {
    flatten_stack_push(flatten_stack, bldtval, Rt);     /* bldtval(R) */
  } else {
    Rt = reg_get(Reg, TVAR);
    flatten_stack_push(flatten_stack, bldtval, Rt);     /* bldtval(R) */
    db_putterm(Rt,Sub,Reg,Buff,Loc);
  }
}

static int target_is_not_source(Reg)
{
  int i;
  
  for (i=inst_queue_bottom; i<inst_queue_top; i++) {
    if (inst_queue[i].opcode==movreg && inst_queue[i].arg1 == Reg)
      return FALSE;
  }
  return TRUE;
}

static int source_is_not_target(Reg)
{
  int i;
  
  for (i=inst_queue_bottom; i<inst_queue_top; i++) {
    if (inst_queue[i].arg2 == Reg) return FALSE;
  }
  return TRUE;
}

/* this is a simple routine to generate  a series  of instructions to
   load a series of  registers with  constants or  from other registers.
   It is  given a  list of  Source,Target pairs.   Target  is always a
   register  number.    Source  may  be  a  putcon(con), putnumcon(num),
   puttvar(reg),  puttvar(Var),  or  movreg(reg).    The  registers  can
   overlap in any way.  db_genmvs tries to generate  a reasonably efficient
   series  of  instructions  to  load  the indicated  registers with the
   indicated values.  */ 

db_genmvs(inst_queue, Reg, Buff, Loc)
     RegStat Reg; int *Loc;
     struct instruction *inst_queue;
     char *Buff;
{
  int Opcode, Arg, T0, R0;
  
  /* pay attention to the ordering !!!!! */
  while (!inst_queue_empty(inst_queue)) {
    inst_queue_pop(inst_queue, &Opcode, &Arg, &T0);	/* T0: target reg */
    switch (Opcode) {
    case puttvar:  
      dbgen_inst(Opcode, Arg, T0, Buff, Loc);
      break;
    case putnil:
    case putcon:
    case putnumcon:
      if (target_is_not_source(T0))
	dbgen_inst(Opcode, T0, Arg, Buff, Loc);
      else inst_queue_push(inst_queue, Opcode, Arg, T0);
      break;
    case movreg:
      if (Arg==T0) break;
      else if (target_is_not_source(T0)) {
	dbgen_inst(movreg, Arg, T0, Buff, Loc); /* movreg */
	reg_release(Arg);
      } else if (source_is_not_target(Arg)) /* assume target is source */
	inst_queue_push(inst_queue, movreg, Arg, T0);
      /* delay the instruction at the end */
      /* else if (Arg>T0) dbgen_inst(movreg,Arg,T0,Buff,Loc); movreg */
      else {
	R0 = reg_get(Reg, TVAR);
	dbgen_inst(movreg, Arg, R0, Buff, Loc); /* movreg */
	reg_release(Arg);
	inst_queue_push(inst_queue, movreg, R0, T0);
	/* dbgen_inst(movreg, R0, T0, Buff,Loc); */ /* movreg */
      }
      break;
    }
  }
}

/*======================================================================*/
/* New! dbgen_inst: Generate an instruction in the buffer               */
/*======================================================================*/

/* #define ASSERTDEBUG */

dbgen_inst3(Opcode, Arg1, Arg2, Arg3, Buff, Loc)
     int *Loc;
     char *Buff;
{
#ifdef ASSERTDEBUG
  /* dbgen_printinst */
  dbgen_printinst3("%s %d %d %d\n", Opcode Arg1, Arg2, Arg3);
#endif /* ASSERTDEBUG */
  write_byte(Buff, Opcode);
  switch (Opcode) {
  case getlist_tvar_tvar:
    write_byte(Buff, Arg1);
    write_byte(Buff, Arg2);
    write_byte(Buff, Arg3);
    break;
  case switchonbound:	/* PPR,I,I */
    write_byte(Buff, 0);
    write_byte(Buff, 0);
    write_byte(Buff,Arg1);
    write_word(Buff,Arg2);
    write_word(Buff,Arg3);
    break;
  case switchon3bound:	/* RRR,I,I */
    write_byte(Buff, Arg1>>16);
    write_byte(Buff, (Arg1>>8) & 0xff);
    write_byte(Buff,Arg1 & 0xff);
    write_word(Buff,Arg2);
    write_word(Buff,Arg3);
    break;
  }
}

dbgen_inst(Opcode, Arg1, Arg2, Buff, Loc)
     int *Loc;
     char *Buff;
{
  
#ifdef ASSERTDEBUG
  dbgen_printinst(Opcode, Arg1, Arg2);
#endif /* ASSERTDEBUG */
  write_byte(Buff, Opcode);
  switch (Opcode) {
  case getpvar:	/* PRV */
  case getpval:	/* PRV */
  case putpvar:	/* PRV */
  case putpval:	/* PRV */
  case gettval:	/* PRR */
  case puttvar:	/* PRR */
  case movreg:	/* PRR */	    
    write_byte(Buff, 0);
    write_byte(Buff, Arg1);
    write_byte(Buff, Arg2);
    break;
  case unipvar:	/* PPV */
  case unipval:	/* PPV */
  case bldpvar:	/* PPV */
  case bldpval:	/* PPV */
  case unitvar:	/* PPR */
  case unitval:	/* PPR */
  case bldtvar:	/* PPR */
  case bldtval:	/* PPR */
  case putlist:	/* PPR */
  case getlist:	/* PPR */	    
  case noop:		/* PPA */
    write_byte(Buff, 0);
    write_byte(Buff, 0);
    write_byte(Buff, Arg1);
    break;
  case putcon:
  case putnumcon:
  case putfloat:
  case getcon:
  case getnumcon:
  case getfloat:
  case putstr:
  case getstr:
  case jumptbreg:
  case dyntrustmeelsefail:
  case retrymeelse:
  case trymeelse:
    write_byte(Buff, 0);
    write_byte(Buff, 0);
    write_byte(Buff, Arg1);	
    write_word(Buff, Arg2);
    break;
  case putnil:
  case getnil:
    write_byte(Buff, 0);
    write_byte(Buff, 0);
    write_byte(Buff, Arg1);	
    break;
  case bldcon:
  case bldnumcon:
  case bldfloat:
  case unicon:
  case uninumcon:
  case unifloat:
  case execute:
  case jump:
    write_byte(Buff, 0);
    write_byte(Buff, 0);
    write_byte(Buff, 0);
    write_word(Buff, Arg1);
    break;
  case bldnil:
  case uninil:
  case proceed:
  case fail:
    write_byte(Buff, 0);
    write_byte(Buff, 0);
    write_byte(Buff, 0);
    break;
  default: fprintf(stderr, "Unknown instruction in assert %d\n",
		   Opcode);
  }
}


#ifdef ASSERTDEBUG
dbgen_printinst3(Opcode, Arg1, Arg2, Arg3)
{
  switch (Opcode) {
  case getlist_tvar_tvar:
    printf("getlist_tvar_tvar - %d %d %d\n",Arg1,Arg2,Arg3); break;
  case switchonbound:
    printf("switchonbound - %d %d %d\n",Arg1,Arg2,Arg3); break;
  case switchon3bound:
    printf("switchon3bound - %d %d %d\n",Arg1,Arg2,Arg3); break;
  default: fprintf(stderr, "Unknown instruction in assert %d\n",
		   Opcode);
  }
}

dbgen_printinst(Opcode, Arg1, Arg2)
{
  switch (Opcode) {
  case getpvar:	/* PRV */
    printf("getpvar - %d %d\n", Arg1, Arg2); break;
  case getpval:	/* PRV */
    printf("getpval - %d %d\n", Arg1, Arg2); break;
  case putpvar:	/* PRV */
    printf("putpvar - %d %d\n", Arg1, Arg2); break;
  case putpval:	/* PRV */
    printf("putpval - %d %d\n", Arg1, Arg2); break;
  case gettval:	/* PRR */
    printf("gettval - %d %d\n", Arg1, Arg2); break;
  case puttvar:	/* PRR */
    printf("puttvar - %d %d\n", Arg1, Arg2); break;
  case movreg:	/* PRR */
    printf("movreg - %d %d\n", Arg1, Arg2); break;
  case unipvar:	/* PPV */
    printf("unipvar - - %d\n", Arg1); break;
  case unipval:	/* PPV */
    printf("unipval - - %d\n", Arg1); break;
  case bldpvar:	/* PPV */
    printf("bldpvar - - %d\n", Arg1); break;
  case bldpval:	/* PPV */
    printf("bldpval - - %d\n", Arg1); break;
  case unitvar:	/* PPR */
    printf("unitvar - - %d\n", Arg1); break;
  case unitval:	/* PPR */
    printf("unitval - - %d\n", Arg1); break;
  case bldtvar:	/* PPR */
    printf("bldtvar - - %d\n", Arg1); break;
  case bldtval:	/* PPR */
    printf("bldtval - - %d\n", Arg1); break;
  case putlist:	/* PPR */
    printf("putlist - - %d\n", Arg1); break;
  case getlist:	/* PPR */
    printf("getlist - - %d\n", Arg1); break;
  case putcon:
    printf("putcon - - %d 0x%x\n", Arg1, Arg2); break;
  case putnumcon:
    printf("putnumcon - - %d 0x%x\n", Arg1, Arg2); break;
  case putfloat:
    printf("putfloat - - %d %f (0x%x)\n", Arg1, Arg2, Arg2); break;
  case getcon:
    printf("getcon - - %d 0x%x\n", Arg1, Arg2); break;
  case getnumcon:
    printf("getnumcon - - %d 0x%x\n", Arg1, Arg2); break;
  case getfloat:
    printf("getfloat - - %d %f (0x%x)\n", Arg1, Arg2, Arg2); break;
  case putstr:
    printf("putstr - - %d 0x%x\n", Arg1, Arg2); break;
  case getstr:
    printf("getstr - - %d 0x%x\n", Arg1, Arg2); break;
  case putnil:
    printf("putnil - - %d\n", Arg1); break;
  case getnil:
    printf("getnil - - %d\n", Arg1); break;
  case bldcon:
    printf("bldcon - - - 0x%x\n", Arg1); break;
  case bldnumcon:
    printf("bldnumcon - - - 0x%x\n", Arg1); break;
  case bldfloat:
    printf("bldfloat - - - 0x%x\n", Arg1); break;
  case unicon:
    printf("unicon - - - 0x%x\n", Arg1); break;
  case uninumcon:
    printf("uninumcon - - - 0x%x\n", Arg1); break;
  case unifloat:
    printf("unifloat - - - 0x%x\n", Arg1); break;
  case execute:
    printf("execute - - - 0x%x\n", Arg1); break;
  case bldnil:
    printf("bldnil - - -\n"); break;
  case uninil:
    printf("uninil - - -\n"); break;
  case proceed:
    printf("proceed - - -\n"); break;
  case noop:
    printf("noop - - -\n"); break;
  case jumptbreg;
    printf("jumptbreg - - %d 0x%x\n", Arg1, Arg2); break;
  case dyntrustmeelsefail;
    printf("dyntrustmeelsefail - - %d 0x%x\n", Arg1, Arg2); break;
  case retrymeelse;
    printf("retrymeelse - - %d 0x%x\n", Arg1, Arg2); break;
  case trymeelse;
    printf("trymeelse - - %d 0x%x\n", Arg1, Arg2); break;
  case jump;
    printf("jump - - - 0x%x\n", Arg1); break;
  case fail;
    printf("fail - - -\n"); break;
  default: fprintf(stderr, "Unknown instruction in assert %d\n",
		   Opcode);
  }
}
#endif /* ASSERTDEBUG */


int arity(T0)
     prolog_term T0;
{
  if (is_functor(T0)) return p2c_arity(T0);
  else if (is_list(T0)) return 2;
  else if (is_string(T0)) return 0;
  else assertcmp_throw(ERR_FUNCTOR);
  return -1;
}

/*======================================================================*/
/* assert_buff_to_clref(+Arg,+Arity,+Prref,+AZ,+Index,+HashTabSize,	*/
/*	-Clref)								*/
/*	allocactes a Clref, copies the byte-code for the clause from	*/
/*	an internal buffer into it, and adds to to the chains.		*/
/*	The arguments are:						*/
/*	Arg:   The argument value of the indexed arg (ignored if no ind)*/
/*	Arity: the number of registers to save in a choice point.	*/
/*		Note the Arity is one more than the original arity, to  */
/*		hold the cut address.					*/
/*	Prref: predicate reference to which to add the asserted fact	*/
/*	AZ:   0 - inserted as the first clause; 1 - as the last clause	*/
/*	Index:  0 if no index is to be built, or n if an index		*/
/*		on the nth argument of the fact is to be used		*/
/*	HashTabSize:  The size of the hash table to create if one must	*/
/*		be created for this clause (the SOB record)		*/
/*	Clref:  the clause reference of the asserted fact, returned.	*/
/*======================================================================*/

/*======================================================================*/
/* Formats for dynamic code:						*/
/* PSC rec point to:							*/
/*	PrRef:								*/
/*		0: BC instruction: fail (if empty),			*/
/*			jump and save breg (if nonempty)		*/
/*		4: Addr of first Clref on ALL chain			*/
/*		8: Addr of last Clref on ALL chain			*/
/*									*/
/* PrRef's point to chain of ClRef's (one of 3 types):			*/
/* (the -8 location stores length of buff + flag indicating ClRef type	*/
/*	ClRef2 (for compiled code):					*/
/*		-8: length of buffer (+2)				*/
/*		-4: Addr of previous ClRef (or PrRef)			*/
/*		0: Try-type instruction, for chain			*/
/*		4: (cont) Addr of next ClRef on chain			*/
/*		8: jump							*/
/*		12: Addr of compiled code				*/
/*	ClRef0 (for unindexed asserted code):				*/
/*		-8: length of buffer (+0)				*/
/*		-4: Addr of previous ClRef (or PrRef)			*/
/*		0: Try-type instruction, for chain			*/
/*		4: (cont) Addr of next ClRef on chain			*/
/*		8+: BC for asserted clause				*/
/*	ClRef1 (for group of indexed clauses, aka SOB record):		*/
/*		-8: length of buffer (+1)				*/
/*		-4: Addr of previous ClRef (or PrRef)			*/
/*		0: Try-type instruction, for chain			*/
/*		4: (cont) Addr of next ClRef on chain			*/
/*		8: BC switch-on-bound instruction (drop thru if var)	*/
/*		11: (cont) arg to index on				*/
/*		12: (cont) address of Hash Table			*/
/*		16: (cont) size of Hash Table				*/
/*		20: BC jump to	(or fail if empty)			*/
/*		24: (cont) Addr of first ClRefI on all subchain		*/
/*		28: Addr of last ClRefI on all subchain			*/
/*		32+: Hash Table						*/
/*									*/
/* ClRef1's point to indexed clauses, each represented by a ClRefI:	*/
/*	ClRefI (for an indexed clause):					*/
/*		-8: length of buffer (+3)				*/
/*		-4: Addr of previous ClRefI on all chain		*/
/*		0: Try-type instruction, for all subchain		*/
/*		4: (cont) Addr of next ClRefI on all subchain		*/
/*            For each index we have the following four fields:         */
/*		8: BC noop(14) to skip next NI*16-4 bytes		*/
/*		12: Addr of previous ClRefI on bucket chain		*/
/*		16: Try-type instruction, for hash bucket subchain	*/
/*		20: (cont) Addr of next ClRefI in bucket		*/
/*		24: BC noop(6) to skip next (NI-1)*16-4 bytes		*/
/*		28: Addr of previous ClRefI on bucket chain		*/
/*		32: Try-type instruction, for hash bucket subchain	*/
/*		34: (cont) Addr of next ClRefI in bucket		*/
/*		24+: BC for asserted code				*/
/*									*/
/*======================================================================*/

assert_buff_to_clref(/*Head,Arity,Prref,AZ,Indexes,HashTabSize,Clref*/)
{
  prolog_term Head, Indexes;
  byte Arity;
  int AZ, BuffLen, Index[20], HashTabSize;
  byte *Prref;
  byte *RBuff, *Clref;
  int Location, *Loc, NI, Inum;
  
  Head = reg_term(1);
  Arity = ptoc_int(2);
  Prref = (byte *)ptoc_int(3);
  AZ = ptoc_int(4);
  Indexes = reg_term(5);
  if (is_int(Indexes)) {
    Index[1] = int_val(Indexes);
    if (Index[1] == 0) NI = 0;
    else NI = 1;
  } else {
    for (NI = 0; !is_nil(Indexes); Indexes = p2p_cdr(Indexes)) {
      NI++;
      Index[NI] = int_val(p2p_car(Indexes));
    }
  }
  
  HashTabSize = ptoc_int(6);
  
  BuffLen = ((Size+8+8+NI*16)+15) & 0xfffffff8;
  RBuff = (byte *)mem_alloc(BuffLen);
  if (NI > 0) *(int *)RBuff = BuffLen | 3;
  else *(int *)RBuff = BuffLen;
  Clref = RBuff+8;
  Location = 0; Loc = &Location;
  dbgen_inst(noop,2,0,Clref,Loc);    /* will become try */
  write_word(Clref,0);
  for (Inum = NI; Inum > 0; Inum--) {
    /* put template code for chaining buffers from hash tables  */
    dbgen_inst(noop,Inum*8-2,0,Clref,Loc);             /* noop(6) */
    write_word(Clref,0);
    dbgen_inst(noop,2,0,Clref,Loc);             /* noop(2) */
    write_word(Clref,0); 
  }
  
  bcopy(Buff,Clref+Location,Size);
  ctop_int(7,Clref);
  
  if (NI <= 0) db_addbuff(Arity,Clref,Prref,AZ,1);
  else db_addbuff_i(Arity,Clref,Prref,AZ,Index,NI,Head,HashTabSize);
  return TRUE;
}

#define b_word(Buff,Loc) (*(int *)(Buff+(Loc)))
#define b_ptr(Buff,Loc) ((byte *)(*(int *)(Buff+(Loc))))
#define b_byte(Buff,Loc) (*(Buff+(Loc)))
#define bs_word(Buff,Loc,Val) { *(int *)(Buff+(Loc)) = (int)(Val); }
/*#define bs_ptr(Buff,Loc,Val) { (byte *)*(int *)(Buff+(Loc)) = (byte *)(Val); }*/
#define bs_ptr(Buff,Loc,Val) { *(byte **)(Buff+(Loc)) = (byte *)(Val); }
#define bs_byte(Buff,Loc,Val) { *(Buff+(Loc)) = (byte)(Val); }

/* add Clref to end of Prref */
db_addbuff(Arity,Clref,Prref,AZ,Inum) 
     byte Arity, *Clref, *Prref; int AZ, Inum;
{
  int Loc; byte *Lbuff;
  
  if (b_byte(Prref,0) == fail) {
    Loc = 0;
    if (Inum > 1) dbgen_inst(jump,Clref,0,Prref,&Loc);
    else dbgen_inst(jumptbreg,Arity,Clref,Prref,&Loc);
    bs_ptr(Prref,8,Clref);
    bs_ptr(Clref,-4,Prref);
    Loc = 0;
    dbgen_inst(noop,2,0,Clref,&Loc);
    bs_ptr(Clref,4,Prref);
  } else if ((b_byte(Prref,0) == jumptbreg) || (b_byte(Prref,0) == jump)) {
    if (AZ == 0) {
      prefix_to_chain(Arity, b_word(Prref,4), Clref);
      bs_ptr(Prref,4,Clref);
      bs_ptr(Clref,-4,Prref);
    } else {
      Lbuff = b_ptr(Prref,8);
      append_to_chain(Arity,Lbuff,Clref);
      bs_ptr(Clref,-4,Lbuff);
      bs_ptr(Prref,8,Clref);
    }
  } else fprintf(stderr,"***Error 3 in assert\n");
}

/* add Clref to beginning of try-retry chain beginning with Ofbuff */
prefix_to_chain(Arity, Ofbuff, Clref)
     byte Arity; byte *Ofbuff; byte *Clref;
{
  int Loc;
  
  Loc = 0;
  if (b_byte(Ofbuff,0) == noop)
    dbgen_inst(dyntrustmeelsefail,Arity,b_ptr(Ofbuff,4),Ofbuff,&Loc);
  else if (b_byte(Ofbuff,0) == trymeelse)
    dbgen_inst(retrymeelse,Arity,b_ptr(Ofbuff,4),Ofbuff,&Loc);
  else fprintf(stderr,"***Error 1 in assert: 0x%x\n",b_byte(Ofbuff,0));
  bs_ptr(Clref,-4,b_ptr(Ofbuff,-4));
  bs_ptr(Ofbuff,-4,Clref);
  Loc = 0;
  dbgen_inst(trymeelse,Arity,Ofbuff,Clref,&Loc);
}


/* add NewBuff after LastBuff on try-retry chain */
append_to_chain(Arity, LastBuff, NewBuff)
     byte Arity; byte *LastBuff, *NewBuff;
{
  int Loc;
  
  Loc = 0;
  if (b_byte(LastBuff,0) == noop)
    dbgen_inst(trymeelse,Arity,b_ptr(LastBuff,4),LastBuff,&Loc);
  else if (b_byte(LastBuff,0) == dyntrustmeelsefail)
    dbgen_inst(retrymeelse,Arity,b_ptr(LastBuff,4),LastBuff,&Loc);
  else fprintf(stderr,"***Error 2 in assert: 0x%x\n",b_byte(LastBuff,0));
  Loc = 0;
  dbgen_inst(dyntrustmeelsefail,Arity,b_ptr(LastBuff,4),NewBuff,&Loc);
  bs_ptr(LastBuff,4,NewBuff);
  bs_ptr(NewBuff,-4,LastBuff);
}

/* adds an indexed buffer to an index chain */
db_addbuff_i(Arity,Clref,Prref,AZ,Index,NI,Head,HashTabSize)
     byte Arity; byte *Clref, *Prref; int AZ; int *Index, NI; prolog_term Head;
     int HashTabSize;
{
  byte *Sbuff, *Lbuff, *Fbuff, *Sbuffa, *FailAddr;
  int Ind, Loc, i, j, Size, Inum;
  int ThisTabSize, Hashval, Bucket;
  byte *Addr, *Faddr, *Bucketaddr, *NBuff;
  prolog_term Arg;
  
  for (Inum = 1; Inum <= NI; Inum++) {
    /* Initialize and add SOB buffer to its chain */
    /* ????? Index may be > 256.....*/
    Hashval = 0;
    ThisTabSize = HashTabSize;
    Ind = Index[Inum];
    if (Ind < 256) {  /* handle usual case specially */
      Arg = p2p_arg(Head,Ind);
      if (is_var(Arg)) ThisTabSize = 1;
      else Hashval = ihash(val_to_hash(Arg), ThisTabSize);
    } else {   /* handle joint indexes */
      for (i = 2; i >= 0; i--) {
	j = (Ind >> (i*8)) & 0xff;
	if (j > 0) {
	  Arg = p2p_arg(Head,j);
	  if (is_var(Arg)) {
	    ThisTabSize = 1;
	    Hashval = 0;
	    break;
	  } else Hashval = (Hashval<<1) + ihash(val_to_hash(Arg), ThisTabSize);
	  if (i == 0) Hashval = Hashval % ThisTabSize;
	}
      }
    }

    if (AZ == 0) Sbuff = b_ptr(Prref,4);
    else Sbuff = b_ptr(Prref,8);

    if ((b_byte(Prref,0) == fail) || (b_word(Sbuff,16) != ThisTabSize) 
	|| ((b_word(Sbuff,8) & 0xffffff) != Ind)) {
      /* get NEW SOB block */
      Size = 8 + 32 + 4 * ThisTabSize + 4;
      Sbuffa = (byte *)mem_alloc(Size);
      Sbuff = Sbuffa + 8;
      bs_word(Sbuffa,0,(Size | 1));
      Loc = 8;
      dbgen_inst3((Ind>255) ? switchon3bound : switchonbound,
		  Ind,Sbuff+32,ThisTabSize,Sbuff,&Loc);
      dbgen_inst(fail,0,0,Sbuff,&Loc);
      
      bs_word(Sbuff,24,Sbuff+20); bs_word(Sbuff,28,Sbuff+20);
      
      /* Initialize hash table */
      Loc = 32 + 4 * ThisTabSize;
      FailAddr = Sbuff + Loc;
      dbgen_inst(fail,0,0,Sbuff,&Loc);
      for (i = 0; i < ThisTabSize; i++) {
	bs_ptr(Sbuff,32+4*i,FailAddr);
      }
      
      /* add new SOB block */
      db_addbuff(Arity,Sbuff,Prref,AZ,Inum);
      
    }
    
    Prref = Sbuff + 20;    /* set so Prref points to SOB's jump 
			      for next index */

    /* add code buff to hash chain */
    Bucket = 32 + (Hashval << 2);
    Bucketaddr = Sbuff + Bucket;
    Addr = b_ptr(Sbuff, Bucket);
    Faddr = Sbuff + 32 +  (ThisTabSize << 2);
    NBuff = Clref + Inum * 16;
    if (AZ == 0) {  /* add at beginning */
      bs_ptr(Sbuff,Bucket,NBuff);
      bs_ptr(NBuff,-4,Bucketaddr);
      if (Addr == Faddr) {	/* empty bucket */
	bs_ptr(NBuff,4,Bucketaddr);
      } else {
	if (b_byte(Addr,0) == noop) {
	  Loc = 0;
	  dbgen_inst(dyntrustmeelsefail,Arity,b_ptr(Addr,4),Addr,&Loc);
	} else {
	  Loc = 0;
	  dbgen_inst(retrymeelse,Arity,b_ptr(Addr,4),Addr,&Loc);
	}
	Loc = 0;
	dbgen_inst(trymeelse,Arity,Addr,NBuff,&Loc);
	bs_ptr(Addr,-4,NBuff);
      }
    } else {  /* add at end */
      if (Addr == Faddr) { /* empty bucket */
	bs_ptr(Sbuff,Bucket,NBuff);
	bs_ptr(NBuff,-4,Bucketaddr);
	bs_ptr(NBuff,4,Bucketaddr);
      } else {
	if (b_byte(Addr,0) == noop) {
	  Loc = 0;
	  dbgen_inst(trymeelse,Arity,0,Addr,&Loc);
	} else {
	  while (b_byte(Addr,0) != dyntrustmeelsefail) {
	    Addr = b_ptr(Addr,4);
	  }
	  Loc = 0;
	  dbgen_inst(retrymeelse,Arity,0,Addr,&Loc);
	}
	Loc = 0;
	dbgen_inst(dyntrustmeelsefail,Arity,Bucketaddr,NBuff,&Loc);
	bs_ptr(Addr,4,NBuff);
	bs_ptr(NBuff,-4,Addr);
      }
    }
  }
  
  /* add code buff to all chain */
  if (b_byte(Sbuff,20) == fail) { /* insert first clrefI into SOB buff */
    Loc = 20;
    dbgen_inst(jump,Clref,0,Sbuff,&Loc);
    bs_ptr(Sbuff,Loc,Clref);
    bs_ptr(Clref,-4,Sbuff);
    Loc = 0;
    dbgen_inst(noop,2,0,Clref,&Loc);
    bs_ptr(Clref,Loc,Sbuff);
  }
  else {
    if (AZ == 0) {  /* add at beginning */
      Fbuff = b_ptr(Sbuff,24);
      prefix_to_chain(Arity,Fbuff,Clref);
      bs_ptr(Fbuff,-4,Clref);
      bs_ptr(Sbuff,24,Clref);
    } else {  /* add at end */
      Lbuff = b_ptr(Sbuff,28);
      append_to_chain(Arity, Lbuff, Clref);
      bs_ptr(Clref, -4, Lbuff);
      bs_ptr(Sbuff, 28, Clref);
    }
/*??    HashTabSize = b_word(Sbuff,16);*/
  }
}


/* like fprintf:
   R1: +File 
   R2: +Format, fprintf format as atom;
   R3: +Vals, term whose args are values */
#define MAX_FMT_ARGS 20
fmt_write()
{
  long args[MAX_FMT_ARGS*2];
  char *Fmt;
  prolog_term ValTerm, Arg;
  int i, Arity;
  
  i = ptoc_int(1);
  fptr = fileptr(i);
  Fmt = ptoc_string(2);
  ValTerm = reg_term(3);
  Arity = get_arity(get_str_psc(ValTerm));
  if (Arity >= MAX_FMT_ARGS) {
    fprintf(stderr,"Too many fields for FMT_WRITE\n");
    return 0;
  }
  
  /* ASSUMES THAT DOUBLE IS TWICE AS LONG AS INT AND CHAR* */
  for (i = 1; (i <= Arity); i++) {
    Arg = p2p_arg(ValTerm,i);
    if (is_string(Arg)) ((char **)args)[i<<1] = string_val(Arg);
    else if (is_int(Arg)) args[i<<1] = int_val(Arg);
    else if (is_float(Arg)) ((double *)args)[i] = float_val(Arg);
    else {
      fprintf(stderr,"Illegal argument to FMT_WRITE\n");
      return 0;
    }
  }
  if (Arity <= 5)
    fprintf(fptr,Fmt,args[2],args[4],args[6],args[8],args[10]);
  else if (Arity <= 10)
    fprintf(fptr,Fmt,args[2],args[4],args[6],args[8],args[10],args[12],
	    args[14],args[16],args[18],args[20]);
  else
    fprintf(fptr,Fmt,args[2],args[4],args[6],args[8],args[10],args[12],
	    args[14],args[16],args[18],args[20],args[22],args[24],args[26],
	    args[28],args[30],args[32],args[34],args[36],args[38]);
  
  return 1;
}

/* like scanf,
   R1: +File
   R2: +Format, fscanf format as atom;
   R3: +Types, Term whos aregs are types to expect;
   R4: -ValsVar, Term whose args are vars to receive values returned.
   R5: -Ret: 0 OK, -1 eof */
fmt_read()
{
  char *args[MAX_FMT_ARGS];
  char space[MAX_FMT_ARGS<<8];
  char *Fmt;
  prolog_term TypeTerm, AnsTerm, Arg;
  int i, nf, CArg, Arity;
  
  i = ptoc_int(1);
  fptr = fileptr(i);
  Fmt = ptoc_string(2);
  TypeTerm = reg_term(3);
  AnsTerm = reg_term(4);
  Arity = is_string(TypeTerm) ? 0 : get_arity(get_str_psc(TypeTerm));
  if (Arity >= MAX_FMT_ARGS) {
    fprintf(stderr,"Too many fields for FMT_READ\n");
    return 0;
  }
  for (i=1; i<=Arity; i++) args[i] = &(space[i<<8]);
  
  if (Arity <= 5)
    nf = fscanf(fptr,Fmt,args[1],args[2],args[3],args[4],args[5]);
  else if (Arity <= 10)
    nf = fscanf(fptr,Fmt,args[1],args[2],args[3],args[4],args[5],
		args[6],args[7],args[8],args[9],args[10]);
  else
    nf = fscanf(fptr,Fmt,args[1],args[2],args[3],args[4],args[5],
		args[6],args[7],args[8],args[9],args[10],args[11],args[12],
		args[13],args[14],args[15],args[16],args[17],args[18],args[19]);
  
  for (i = 1; (i <= nf); i++) {
    Arg = p2p_arg(AnsTerm,i);
    CArg = int_val(p2p_arg(TypeTerm,i));
    if (CArg == 1) {
      if (is_var(Arg)) c2p_string(*((char **)args + i),Arg);
      else if (strcmp(*((char **)args+i),string_val(Arg))) return 0;
    }
    else if (CArg == 2) {
      if (is_var(Arg)) c2p_int(**((long **)args + i),Arg);
      else if (**((long **)args + i) != int_val(Arg)) return 0;
    }
    else if (CArg == 3) {
      c2p_float(**((float **)args + i),Arg);
    }
    else {
      fprintf(stderr,"Illegal argument to FMT_READ\n");
      return 0;
    }
  }
  ctop_int(5,nf);
  return 1;
}
