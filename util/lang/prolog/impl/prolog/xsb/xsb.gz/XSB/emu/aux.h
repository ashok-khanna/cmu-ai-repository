/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File                  :  aux.h
  Author(s)		:  David S. Warren, Jiyang Xu, Terrance Swift
  Last modification	:  August, 1993
========================================================================*/

#define FALSE	0
#define TRUE	(!FALSE)
#define bool int

typedef unsigned char byte;
typedef unsigned long word;
typedef byte *pb;
typedef word *pw;
typedef int (*PFI)();
typedef int *int_ptr;

#define ihash(val, size) (unsigned)(val) % (size)

#define private
#define shared
#define shapri
#define MAXWORKER 1

#define CONASSTRING
#define CPSTACK

#ifdef SOLARIS
#ifndef PAGESIZE
#define PAGESIZE 128
#endif
#else
#define PAGESIZE 128
#endif

extern int new_lookup_num, return_solution_num, variant_check_num;
extern int use_table_num, suspension_num, all_solutions, return_completion_num;

struct trace_str {		/* for tracing purpose below */
    int maxlstack_count,maxgstack_count,maxtrail_count,maxcpstack_count;
    int maxopenstack_count, maxlevel_num;
#ifdef MEASURE
    int  temp_count; /* used in domain, tls */
#ifdef MEASURE2
    int pil_count, deref_count, call_count, try_count, retry_count;
#endif
#endif
    double time_count;
};


extern struct trace_str tds[];
extern int wid;
extern byte * exception_handler();

#define arithmetic_exception(t_pcreg) \
 t_pcreg =  \
   exception_handler("Arithmetic Exception: returning to top level.\n")

#define local_global_exception(t_pcreg) \
 t_pcreg = \
  exception_handler("Local/Global Stack Overflow: returning to top level.\n")

#define float_unification_exception(t_pcreg) \
 t_pcreg = \
  exception_handler("Float Unification Exception: returning to top level.\n")

#define unify_float_unification_exception \
  exception_handler("Float Unification Exception: returning to top level.\n")

#define bitop_exception(t_pcreg) \
 t_pcreg = \
  exception_handler("Bitop Exception: returning to top level.\n")

#define tso_exception(t_pcreg) \
 t_pcreg = \
  exception_handler("Table Stack Overflow: returning to top level.\n")

#define ot_exception(t_pcreg) \
 t_pcreg = \
  exception_handler("Opentable Stack Overflow: returning to top level.\n")

#define trail_cp_exception(t_pcreg) \
 t_pcreg  = \
  exception_handler("Trail/CP Stack Overflow: returning to top level.\n")


