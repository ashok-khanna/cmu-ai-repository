/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File			:  loader.c
  Author(s)		:  David S. Warren, Jiyang Xu, 
			   Kostis Sagonas, Terrance Swift
  Last modification	:  April 1993
========================================================================*/


/************************************************************************/
/*
	The file loader.c contains routines for loading a byte code file
	into the emulator's permanent work space (pspace).
	It uses routines in load_work.c to access pspace.

	The only exported procedure is "loader". No export types or vars.
*/
/************************************************************************/

#include <stdio.h>
#include "config_make.h"
#include "aux.h"
#include "psc.h"
#include "loader.h"
#include "flags.h"
#include "cell.h"

/* In the following, y is the number of bytes we want to read from fd */
#define get_data(x,y) fread((char *)x, 1, y, fd)

shapri Psc  global_mod;	/* points to "global", whose ep is globallist */
shared Pair hash_table[MAXBUCKET];

/*pw * reloc_table;*/
pw reloc_table[8914];

static unsigned long psc_count;
static FILE *fd;

/****************************************************************************/
/*									    */
/* fix_bb: fixes the byte-backwards problem. It is passed a pointer to a    */
/* sequence of 4 bytes read in from a file as bytes. It then converts those */
/* bytes to represent a number. This code works for any machine, and makes  */
/* the byte-code machine independent.                                       */
/*									    */
/****************************************************************************/

fix_bb(lptr)
byte *lptr;
{
    unsigned long *numptr;

    numptr = (unsigned long *)lptr;
    *numptr = (((((*lptr << 8) | *(lptr+1))
		    << 8) | *(lptr+2))
			<< 8) | *(lptr+3);
}


/****************************************************************************/
/*    Load the file into permanent space.				    */
/* Data segment first (mixed psc entries and name strings), then text       */
/* segment.								    */
/*    Return the address of first instruction; if error, return 0.          */
/*									    */
/****************************************************************************/

byte *loader(file, exp)
char *file; int exp;
{
	byte *loader1(), *loader_foreign();
	byte *first_inst;
	int magic_num;

	fd = fopen(file, "r");
	if (!fd) return 0;
	if (flags[HITRACE]) printf("\n     ...... loading file %s\n", file);
	magic_num = read_magic();
	if (magic_num == 0x11121304) first_inst = loader1(fd,exp);
	else if (magic_num == 0x11121308) {
#ifdef FOREIGN
		first_inst = loader_foreign(file, fd, exp);
#else
		printf("Trying to load in foreign file: %s\n", file);
#endif
	      }
	else {
		printf("Not a byte code file\n");
		first_inst = 0;
	}
	fclose(fd);
	return first_inst;
} /* loader */

byte *loader1(fd, exp)
FILE *fd; int exp;
{
    char name_len, name[64], arity;
    int  new, text_bytes, index_bytes;
    byte *seg_first_inst, *first_inst;
    struct psc_rec *cur_mod;
    Pair ptr;
    int seg_count;
    int this_file_table_num = 0;
     
	seg_count = 0;
        get_data(&name_len, 1);
        if (name_len < 64)
          get_data(name, name_len);
        else quit("module name %s too long\n");
	name[name_len] = 0;
        if (name_len==0) cur_mod = global_mod;
	else {
	    ptr = (Pair)insert_module(T_MODU, name);
	    cur_mod = ptr->psc_ptr;
	}
    	get_data(&psc_count, 4);
	fix_bb((byte *)&psc_count);
	if (!load_syms(fd, psc_count, 0, cur_mod, exp, &this_file_table_num)) 
	  return 0;
/*	  printf("symbol table loaded %s \n",name); */
        do {
/*		printf("Seg count: %d\n",seg_count); */
		if (read_magic() != 0x11121306) break;
		seg_count++;
/*		printf("Seg count: %d",seg_count); */
           /* get the header of the segment */
		get_data(&arity, 1);
		get_data(&name_len, 1);
                if (name_len < 64)
                  get_data(name, name_len);
                else quit("name %s too long\n");
		name[name_len] = 0;
		get_data(&text_bytes, 4);
		fix_bb((byte *)&text_bytes);
/*		printf("Text Bytes %x %d\n",text_bytes,text_bytes);*/
		get_data(&index_bytes, 4);
		fix_bb((byte *)&index_bytes);
           /* load the text-index segment */
		seg_first_inst = 
		  (byte *)load_seg(seg_count, text_bytes, index_bytes, fd, 
				                          this_file_table_num);
		if (!seg_first_inst) return 0;
		if (seg_count == 1) first_inst = seg_first_inst;
				/* 1st inst of file */
	   /* set the entry point of the predicate */
		ptr = (Pair)insert(name, arity, cur_mod, &new);
		switch (get_type(ptr->psc_ptr)) {
		  case T_ORDI:
		  case T_UDEF:
		    set_type(ptr->psc_ptr, T_PRED);
		    set_ep(ptr->psc_ptr, seg_first_inst);
		    break;
		  case T_PRED:
		  case T_FUNC:
		    if (strcmp(name, "_$main")!=0)
		      unload_seg(get_ep(ptr->psc_ptr));
		    set_ep(ptr->psc_ptr, seg_first_inst);
		    break;
		  case T_UFUN:
		    set_type(ptr->psc_ptr, T_FUNC);
		    set_ep(ptr->psc_ptr, seg_first_inst);
		    break;
		  default:
		    printf("Error: the predicate %s/%d cannot be loaded\n", 
			   name, arity);
		    unload_seg(seg_first_inst);
		    return 0;
		  }
	} while (1==1);
/*	printf("first instruction of module %s is %d \n", name, first_inst); */
	return first_inst;
} /* loader1 */

/************************************************************************
*                                                                       *
* Load_syms is a function which loads a symbol table given in a byte    *
* code file into an appropriate format in the pcs table.  As part of    *
* its function it resolves entry points for byte code intructions (call *
* to relloc_addr), and maintains a tableau so that instructions         *
* with indexes into the psc table may have those indexes resolved before*
* loading them in the intruction array (byte code program space).  The  *
* intructions are loaded by a separate function.                        *
*                                                                       *
* The number of symbols is returned .
*
* Format see ../FORMAT
************************************************************************/

load_syms(fd, psc_count, count, cur_mod, exp, this_file_table_num)
FILE *fd;
Psc cur_mod;
int * this_file_table_num;

{
/*  Why in the world is this recursive???
   if (count >= psc_count) return 1;
   if (!load_sym1(fd, cur_mod, count, exp)) return 0;
   return load_syms(fd, psc_count, count+1, cur_mod, exp); */

    int	    i;
/*	reloc_table = (pw *) calloc( (psc_count),sizeof(pw));*/
/*        printf("reloc_table %x,psc_count %d\n",reloc_table,psc_count);*/
    for (i = count; i < psc_count; i++)
    {
	if (!load_sym1(fd, cur_mod, i, exp, this_file_table_num)) return 0;
    }
    return (1);
}

load_sym1(fd, cur_mod, count, exp, this_file_table_num)
FILE *fd;
Psc cur_mod;
int *this_file_table_num;
{
   char    name[256], modname[256];
   int     new;
   byte    t_arity, t_type, t_env, t_len, t_modlen;
   Pair temp_pair, temp2;
   Psc  mod;

	get_data(&t_env,1);
	get_data(&t_type,1);
	get_data(&t_arity,1);
	get_data(&t_len,1);
	get_data(name, t_len);
	name[t_len] = 0;
/*        printf(" name %s\n",name); */
    /* For backward compatibility; can be deleted in next version !!!! */
    /* Note C-Version of the loader does not have this. All testing files */
    /* must be recompiled under the new compiler */
	if (t_type==T_PRED) t_type = T_UDEF;
	if (t_type==T_FUNC) t_type = T_UFUN;
	if (t_type==T_MODU) temp_pair = (Pair)insert_module(0, name);
	else if (t_type==T_CONS) 
	  temp_pair = (Pair)(string_find(name,1)|0x80000000);
	else {
	  if (t_env == T_IMPORTED) {
	    get_data(&t_modlen,1);
	    get_data(modname, t_modlen);
	    modname[t_modlen] = 0;
	    temp_pair = (Pair)insert_module(0, modname);
	    mod = temp_pair->psc_ptr;
	  } else if (t_env == T_GLOBAL) mod = global_mod;
	  else mod = cur_mod;
	  temp_pair = (Pair)insert(name, t_arity, mod, &new);
	  if (new && t_env==T_IMPORTED)
		set_ep(temp_pair->psc_ptr, (byte *)(mod));
		/* set ep to the psc record of the module name */
	  env_type_set(temp_pair->psc_ptr, t_env, t_type, new);
	  /* dsw added following */
	  if (exp && t_env == T_EXPORTED) {
	    /* printf("exporting: %s from: %s\n",name,cur_mod->nameptr);*/
	    if (new) set_ep(temp_pair->psc_ptr, (byte*)(mod));
	    link_sym(temp_pair->psc_ptr, (Psc)flags[CURRENT_MODULE]);
	  }
       	}
	if (!temp_pair) return 0;
/*
	if (count >= REL_TAB_SIZE) {
	    printf("Reloc_table overflow\n");
	    return 0;
	}
*/
	reloc_table[count] = (pw)temp_pair;
/*        printf("reloc_tab %d acc\n",count);*/
	return 1;
}  /* load_sym1 */

#define T_NEW 3
#define E_HIDDEN -1
#define E_NOUSE -2


static int env_check[4][5] = {
/*		   T_EXPORT   T_LOCAL   T_IMPORTED   T_IMEX    T_GLOBAL	*/
/*======================================================================*/
/* T_VISIBLE   */  T_VISIBLE, T_HIDDEN, T_VISIBLE,  E_NOUSE,  T_VISIBLE,
/* T_HIDDEN    */  T_HIDDEN,  T_HIDDEN,	E_HIDDEN,   E_NOUSE,  T_VISIBLE,
/* T_UNLOADED  */  T_VISIBLE, E_HIDDEN, T_UNLOADED, E_NOUSE,  T_UNLOADED,
/* T_NEW       */  T_VISIBLE, T_HIDDEN, T_UNLOADED, E_NOUSE,  T_VISIBLE
};

env_type_set(psc, t_env, t_type, new)
byte t_env, t_type;
Psc psc;
{
    int env;
    byte type;
    Psc new_psc;

    if (new) {
	set_env(psc, env_check[T_NEW][t_env]);
	set_type(psc, t_type);
    } else {
	env = env_check[get_env(psc)][t_env];
	if (env < 0) {
	    printf("++Error: Environment conflict in the use of %s/%d !\n", 
		   get_name(psc), get_arity(psc));
	/* In the following I am not sure whether setting the environment */
	/* in the presense of an environment conflict error is the right  */
	/* thing to do!  But an "imported_from" vs "local" (non-exported) */
	/* symbol conflict must definitely be resolved in favour of the   */
	/* "local" declaration.						  */
	    if (env == E_HIDDEN) {
		if (t_env == T_IMPORTED) 
	/* Here the psc record of the symbol has already been created by  */
	/* another module that imported (mistakenly) this symbol.	  */
		    set_env(psc, T_LOCAL);	
		else /* We are trying to load a module
			that imports sth not exported. */
		    printf("module imports something not exported\n");
	    }
	}
	else set_env(psc, env);
	type = get_type(psc);
	if (t_type && type && t_type != type) {
	  if (t_type==T_UDEF && (type==T_PRED || type==T_DYNA || type==T_FORN)) ;
	  else if (t_type==T_UFUN && type==T_FUNC) ;
	  else if (t_type==T_FORN && type==T_UDEF) set_type(psc, T_FORN);
	  else fprintf(stderr, 
		       "++Error: incompatible types in the use of %s (%x with %x)\n",
		       get_name(psc), type, t_type);
	} else set_type(psc, type | t_type);
	
    }
}

read_magic()
{
 	int num;

	if (get_data(&num, 4) < 4) return 0;
	fix_bb((byte *)&num);
	return  num;
}

#ifdef FOREIGN
shapri char ldoption[256];		/* working variable */

byte *loader_foreign(filename, fd, exp) /* changed (kostis) */
char *filename;
FILE *fd;
{
    unsigned char name_len, ldoption_len; 
    char name[64];
    struct psc_rec *cur_mod;
    Pair ptr;

	get_data(&name_len, 1);
	get_data(name, name_len);
	name[name_len] = 0;
	get_data(&ldoption_len, 1);
	get_data(ldoption, ldoption_len);
	if (ldoption_len >= 255) {
	    fprintf(stderr, 
		    "++Error: ldoption is too long for foreign module %s\n",
		    name);
	    return 0;
	}
	ldoption[ldoption_len] = 0;
	ptr = (Pair)insert_module(T_MODU, name);
	cur_mod = ptr->psc_ptr;
	get_data(&psc_count, 4);
	fix_bb((byte *)&psc_count);
	if (!load_syms(fd, psc_count, 0, cur_mod, exp)) return 0;
	return (byte *)load_obj(filename, cur_mod, ldoption);
} /* loader_foreign */
#endif

