/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File			:  load_seg.c
  Author(s)		:  David S. Warren, Jiyang Xu, Swift, Sagonas
  Last modification	:  April 1993
========================================================================*/

#include <stdio.h>
#include "config_make.h"
#include "aux.h"
#include "inst.h"
#include "cell.h"
#include "memory.h"
#include "register.h"
#include "psc.h"
#include "loader.h"
#include "xmacro.h"

/************************************************************************
*                                                                       *
*  Load_text loads the byte code intruction from a byte code file to	*
*  the byte code program space.  References to indexes to the pcs table	*
*  are resolved with the use of the macro st_index.  New index  relies  *
*  on the symbol table array which is assigned values by load_sms.	*
*  The routine assumes the current length 8/18/84 of byte code		*
*  intructions when reading from the byte code file.			*
*                                                                       *
************************************************************************/

/* === cross session variables ==========================================*/
extern int table_num;
static struct tab_info *tab_info_ptr;

tab_inf_ptr first_tip = 0, last_tip = 0;
static byte *last_text = 0;	/* permanent var, chain of text seg */
/*shapri extern pw * reloc_table;*/
extern pw  reloc_table[]; /* passed in parameter, but valid only once */

/*== local declarations =================================================*/

struct hrec {
	long l;
	word  *link;
} ;

/* === working variables valid only in  one call to load_seg ==============*/

static byte *inst_addr;		/* working pointer */
static long tab_config_hold;		/* working pointer */
static byte *seg_first_inst;	/* starting address -- used for relocation */
static int current_opcode; 	/* current opcode in processing */
static pw index_reloc[8194];
static byte *hptr;
static struct hrec indextab[8194];
static FILE *fd;			/* file descripter */
static int *index_block_chain;	/* index block chain pointer */

int tabflag=0;

/* === macros =======================================================*/

#define get_data(x,y) fread((char *)x, 1, y, fd)

#define st_ptrptrpsc(i_addr)  *((pw *)i_addr) = reloc_table[*(pw)i_addr];
#define st_ptrpsc(i_addr)  *((pw)i_addr) = *reloc_table[*(pw)i_addr];

#define st_pscname(i_addr) \
	if ((int)(reloc_table[*(pw)i_addr])<0) 				\
	   *((pw)i_addr) = (word)reloc_table[*(pw)i_addr] & 0x7fffffff;	\
	else *((pw)i_addr) = 						\
		(word)get_name((struct psc_rec *)(*reloc_table[*(pw)i_addr]));

#define gentabletry(opcode, arg1, arg2, arg3, ep)	\
	*(ep++) = opcode;	         \
	*(ep++) = 0;		         \
	*(ep++) = 0;		         \
	*(ep++) = arg1;		         \
        *(pw) ep = arg2;                 \
        ep = ep + sizeof(word);          \
        *((pw)ep) =  (word) arg3;        \
        ep = ep + sizeof(word)

#define gentry(opcode, arg1, arg2, ep)	\
	*(ep++) = opcode;		\
	*(ep++) = 0;		        \
	*(ep++) = 0;		        \
	*(ep++) = arg1;		        \
        *(pw) ep = arg2;                \
        ep = ep + sizeof(word)
 
#define reloc_addr(offset, base) (offset)<0 ? &fail_inst : (base)+(offset)

/*== Make Gnu C Compiler silent ======================================*/

static gen_index();
static gen_table_index();

/*== the entry procedure =============================================*/
/* Some debugging stuff in here.  I'll take it out when I'm sure 
   that I'm done with the changes */

byte *load_seg(seg_num, text_bytes, index_bytes, file, this_file_table_num)
FILE *file;
int this_file_table_num;
{
   byte endseg_check;
   int current_tab = -1;

   seg_first_inst = mem_alloc(text_bytes+16);
/* SCAFFOLD */
   if ((int) seg_first_inst %4 != 0)
     printf("non-aligned seg_first_inst!/n");
		/* alloc space, include 16 bytes header */
   seg_first_inst += 16;
   *(int *)(seg_first_inst-16) = 0;		/* next = 0 */
   *(int *)(seg_first_inst-12) = (int)last_text;  /* prev = last_text */
   *(int *)(seg_first_inst-8) = 0;		/* pointer to index blocks */
   *(int *)(seg_first_inst-4) = text_bytes+16;
   fd = file;
   if (!load_text(seg_num, text_bytes,this_file_table_num,&current_tab)) {
     mem_dealloc(seg_first_inst-16, text_bytes+16);
     return 0;
   }
   index_block_chain = (int *)(seg_first_inst-8);
   load_index(index_bytes,current_tab);
/* set text-index segment chain */
   if (last_text) *(int *)(last_text-16) = (int)seg_first_inst;
   last_text = seg_first_inst;
   return seg_first_inst;
}


load_text (seg_num, text_bytes,this_file_table_num,current_tab)
   int this_file_table_num;
   int * current_tab;
{
   byte *end_addr;
   int oprand;
   int tempind;

   *current_tab = -1;
   inst_addr = seg_first_inst;
   end_addr = seg_first_inst + text_bytes;
   while ( inst_addr<end_addr && get_data(inst_addr, 4) ) {
       current_opcode = *inst_addr;
/*       if (current_opcode == tabletry)
	 	   tabflag = 1;
       if (tabflag) {
           printf("current_opcode: %x \n",current_opcode);
	   printf("inst_addr %x *inst_addr, %x \n",
	           inst_addr,* (int *) inst_addr);
	 }*/
       inst_addr += 4;
       for (oprand=1; oprand<=4; oprand++) {
	 switch (inst_table[current_opcode][oprand]) {
	 case A:
	 case V:
	 case R:
	 case P:
	 case PP:
	 case PPP:
	 case PPR:
	 case RRR:
	   break;
	 case S:
	   get_data(inst_addr, 4);
	   fix_bb(inst_addr);
	   st_ptrpsc(inst_addr);
	   inst_addr += 4;
	   break;
	 case C:
	   get_data(inst_addr, 4);
	   fix_bb(inst_addr);
#ifdef CONASSTRING
	   st_pscname(inst_addr);
#else
	   st_ptrptrpsc(inst_addr);
#endif
	   inst_addr += 4;
	   break;
	 case L:
	   get_data(inst_addr, 4);
	   fix_bb(inst_addr);
	   *(pb *)inst_addr = reloc_addr(*(int *)inst_addr, seg_first_inst);
/*	   if (current_opcode == tabletry || current_opcode == tabletrust)
	     *(int *) (inst_addr) = *((int *) (inst_addr)) -8;*/
	   inst_addr += 4;
	   break;
	 case G:
	   get_data(inst_addr, 4);
	   fix_bb(inst_addr);
	   st_pscname(inst_addr);
	   inst_addr += 4;
	   break;
	 case N:
	   get_data(inst_addr, 4);
	   fix_bb(inst_addr);
	   inst_addr += 4;
	   break;
	 case I:
	   get_data(inst_addr, 4);
	   fix_bb(inst_addr);
	   if (oprand==2)	/* second operand of switchonbound */
	     index_reloc[*((int *)inst_addr)] = (pw)(inst_addr);
	   else 		/* third operand of switchonbound */
	     *(int *)inst_addr = hsize(*(int *)inst_addr);
	   inst_addr += 4;
	   break;
	 case X:
	   break;
	 case T:	  
           *current_tab = 1;                          /*flag for load index */
	   if (current_opcode == tabletry || current_opcode == tabletryfail) {
	     tab_info_ptr = 
	       (struct tab_info*)mem_alloc(sizeof(struct tab_info));
   	     get_next_tip(tab_info_ptr) = 0;
   	     get_tab_entry(tab_info_ptr) = 0;
	     if (first_tip == 0) first_tip = tab_info_ptr;
	     else get_next_tip(last_tip) = (CPtr) tab_info_ptr;
	     last_tip = tab_info_ptr;
	   }
           get_data((byte *) &tab_config_hold, 4);          /* space holder */
           *(CPtr) inst_addr = (Cell) tab_info_ptr;
	   inst_addr += 4;
	   if (current_opcode == tabletry || 
	              current_opcode == tabletryfail) {  /* tabconfig */
	     get_data((byte *) &tab_config_hold, 4);
	     get_data((byte *) &tab_config_hold, 4);
	     fix_bb((byte *) &tab_config_hold);
	     tab_info_ptr->call_hash_size = tab_config_hold;
	     get_data((byte *) &tab_config_hold, 4);
	     fix_bb((byte *) &tab_config_hold);
	     tab_info_ptr->ret_hash_size = tab_config_hold;
	   }
	   break;
	 default:
	   break;
	 }  /* switch */
       } /* for */
   }
   if (inst_addr != end_addr) {
     printf("inst_addr %x, end_addr %x \n",inst_addr,end_addr);
     return 0;
   }
   else return 1;
}  /* load_text */

load_index(index_bytes,table_num)
  int table_num;
{
  int  index_bno, clause_no, t_len;
  char index_inst,arity;
  int  count = 0;
  pw sob_arg_p;

  while ( (count < index_bytes) ) {
      get_data(&index_inst, 1);
      get_data(&arity, 1);
      get_data(&index_bno, 4);
      fix_bb((byte *)&index_bno);
      sob_arg_p = index_reloc[index_bno];
      get_data(&clause_no, 4);
      fix_bb((byte *)&clause_no);
      /* bad = */ get_index_tab(clause_no, &t_len);
      if (table_num > 0) 
	gen_table_index(clause_no, sob_arg_p, arity, table_num);
      else gen_index(clause_no, sob_arg_p, arity);
      count += 10 + t_len;
  }
}

get_index_tab(clause_no, lenptr)
int clause_no, *lenptr;
{
  long hashval, size, j;
  long count = 0;
  byte  type, *label;
  int val;

  hptr = (pb)hreg;
  size = hsize(clause_no);
  for (j = 0; j < size; j++) {
      indextab[j].l = 0;
      indextab[j].link = (pw)&(indextab[j].link);
  }
  for (j = 0; j< clause_no; j++) {
         get_data(&type, 1);
         switch (type) {
	    case 'i': get_data(&val, 4);
		      fix_bb((byte *)&val); count += 9;
		      break;
	    case 'l': val = (int)(list_str); 
		      count += 5;
		      break;
#ifdef CONASSTRING
            case 'n': val = 0;
#else
            case 'n': val = (int)(nil_sym->psc_ptr);
#endif
		      count += 5;
		      break;
	    case 'c': 
#ifdef CONASSTRING
	      	      get_data(&val, 4);
		      fix_bb((byte *)&val); count += 9;
		      st_pscname(&val);
		      break;
#endif
	    case 's': get_data(&val, 4);
		      fix_bb((byte *)&val); count += 9;
		      st_ptrpsc(&val);
/*		      val = *reloc_table[val]; */
		      break; 
	 }
         get_data(&label, 4);
	 fix_bb((byte *)&label);
         label = reloc_addr((int)label, seg_first_inst);
         hashval = ihash(val, size);
         inserth(label, &indextab[hashval]);
  }
  *lenptr = count;
}

static gen_index(clause_no, sob_arg_p, arity)
char arity;
pw sob_arg_p;
{
  pb  ep1, ep2;
  long j, size;
  pw temp;

  size = hsize(clause_no);
  ep1 = mem_alloc(8+4*size);		/* 8 bytes chain */
  *index_block_chain = (int)ep1;
  index_block_chain = (int *)ep1;
  *(int *)(ep1) = 0;			/* next = 0 */
  *(int *)(ep1+4) = 8+4*size;		/* buffer size */
  ep1 += 8;
  *sob_arg_p = (word)ep1;
  for (j = 0; j < size; j++) {
      if (indextab[j].l == 0) *((pb *)ep1) = &fail_inst;
      else  if (indextab[j].l == 1) *((pw)ep1) = *(indextab[j].link);
      else {
	  /* otherwise create try/retry/trust instruction */
	  ep2 = mem_alloc(8*indextab[j].l+8);	/* 8 bytes header */
	  *index_block_chain = (int)ep2;
	  index_block_chain = (int *)ep2;
	  *(int *)(ep2) = 0;			/* next = 0 */
	  *(int *)(ep2+4) = 8*indextab[j].l+8;	/* buffer size */
	  ep2 += 8;
	  *((pb *)ep1) = ep2; 
	  temp = (indextab[j].link);
	  gentry(try, arity, (*temp++), ep2);		/* generate "try" */
	  while (*temp != (word)temp) {
              temp = (pw)(*temp);
              gentry(retry, arity, *temp++, ep2);	/* generate "retry" */
          }
          *(ep2 - 8) = trust;		/* change last "retry" to "trust" */
      }
      ep1 += 4;
  }
}

static gen_table_index(clause_no, sob_arg_p, arity,table_num)
char arity;
pw sob_arg_p;
int table_num;
{
  pb  ep1, ep2;
  long j, size;
  pw temp;

  size = hsize(clause_no);
  ep1 = mem_alloc(8+4*size);		/* 8 bytes chain */
  *index_block_chain = (int)ep1;
  index_block_chain = (int *)ep1;
  *(int *)(ep1) = 0;			/* next = 0 */
  *(int *)(ep1+4) = 8+4*size;		/* buffer size */
  ep1 += 8;
  *sob_arg_p = (word)ep1;
  for (j = 0; j < size; j++) {
      if (indextab[j].l == 0)  *((pb *)ep1) = &fail_inst; 
      else  if (indextab[j].l == 1) {  /* create tabletryfail */
	   *((pw)ep1) = *(indextab[j].link);
	  ep2 = mem_alloc(20);	/* 8 bytes header */
	  *index_block_chain = (int)ep2;
	  index_block_chain = (int *)ep2;
	  *(int *)(ep2) = 0;			/* next = 0 */
	  *(int *)(ep2+4) = 20;	/* buffer size */
	  ep2 += 8;
	  *((pb *)ep1) = ep2; 
	  temp = (indextab[j].link);
	  gentabletry(tabletryfail, arity, *temp++, tab_info_ptr, ep2);
/*	  gentabletry(comptabletryfail, arity, *temp++, tab_info_ptr, ep2);*/
	 }
      else {  /* otherwise create try/retry/trust instruction */
	   *((pw)ep1) = *(indextab[j].link);
	  ep2 = mem_alloc(8*indextab[j].l+12);	/* 8 bytes header */
	  *index_block_chain = (int)ep2;
	  index_block_chain = (int *)ep2;
	  *(int *)(ep2) = 0;			/* next = 0 */
	  *(int *)(ep2+4) = 8*indextab[j].l+12;	/* buffer size */
	  ep2 += 8;
	  *((pb *)ep1) = ep2; 
	  temp = (indextab[j].link);
	  gentabletry(tabletry, arity, *temp++, tab_info_ptr, ep2);
/*	  gentabletry(comptabletry, arity, *temp++, tab_info_ptr, ep2);*/
	  while (*temp != (word)temp) {
              temp = (pw)(*temp);
              gentry(tableretry, arity, *temp++, ep2);	/* generate "retry" */
          }
          *(ep2 - 8) = tabletrust;        /* change last "retry" to "trust" */
      }
      ep1 += 4;
  }
}


/* use heap top as temp place of hash link and entries; */
/* heap top pointer is not alterred so nothing affect later heap use */
inserth(label, bucket) 
  byte *label;
  struct hrec *bucket;
{ 
  pw temp;

  bucket->l++;
  temp = (pw)&(bucket->link);
  if (bucket->l > 1) {
       temp = (pw)*temp;
       while ((pw)*temp != temp) 
          temp = (pw)*(++temp);
  }
  *temp = (word)hptr;
  *((pb *)hptr) = label; hptr +=4;
  *((pb *)hptr) = hptr; hptr += 4;
}

int hsize(numentry)	/* return an appropriate hash table size */
int numentry;
{  int i, j, temp;

/*  Weidong set the start point to be numentry+1; I change it as follows */
      if (numentry > 64) temp = numentry / 2;
      else if (numentry > 16) temp = numentry;
      else temp = 2 * numentry + 1;
      j = temp / 2 + 1;
      for (i = 2; i <= j; i++) {
	if ((i != temp) && ((temp % i) == 0)) { temp++; j = temp/2+1;}
      }
      return ( temp );
}

/*== unload a segment   =============================================*/

unload_seg(addr)
byte *addr;
{
  byte *index_seg, *ptr2, *ptr3;

  index_seg = *(byte **)(addr-8);
  while (index_seg) {
    ptr2 = *(byte **)(index_seg);
    mem_dealloc(index_seg, *(int *)(index_seg+4));
    index_seg = ptr2;
  }
  /* process program segment chain */
  ptr2 = *(byte **)(addr-16);	/* next program segment */
  ptr3 = *(byte **)(addr-12);	/* prev program segment */
  if (ptr2) *(byte **)(ptr2-12) = ptr3;		/* next->prev := prev */
  if (ptr3) *(byte **)(ptr3-16) = ptr2;		/* prev->next := next */
  if (last_text==addr) last_text = ptr3;
  mem_dealloc(addr-16,  *(int *)(addr-4));
}





	
