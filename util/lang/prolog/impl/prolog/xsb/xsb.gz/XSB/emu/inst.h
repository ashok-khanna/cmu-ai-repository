/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File                  :  inst.h
  Author(s)		:  David S. Warren, Terrance Swift, Jiyang Xu
  Last modification	:  April 1993
======================================================================*/

/* The followings are operand types of instructions. After these will 
   be the set of all instructions. */

#define A 1	/* a byte of integer (for arity, size, builtin-num, etc) */
#define V 2	/* variable offset */
#define R 3	/* register number */
#define S 4	/* structure symbol */
#define C 5	/* constant symbol */
#define L 6	/* label (address) */
#define G 7	/* string */
#define N 8	/* number (integer and float) */
#define I 9	/* 2nd & 3rd arguments of switchonbound */
#define P 10	/* pad */
#define X 11	/* not present */
#define PP 12	/* double pad */
#define PPP 13	/* triple pad */
#define PPR 14  /* = PP + R; for switchonterm and switchonbound */
#define T 15    /* tabletry */
#define RRR 16  /* = R + R + R; for switchon3bound */

#ifdef PROFILE
extern int inst_table[256][6];
extern int builtin_table[256][2];
#else
extern int inst_table[256][5];
#endif

/**************************************************************************/
/*    The followings are the set of all instructions.                     */
/**************************************************************************/

/* Basic term instructions */

#define getpvar         0x00
#define getpval         0x01
#define getstrv         0x02
#define gettval         0x03
#define getcon          0x04
#define getnil          0x05
#define getstr          0x06
#define getlist         0x07
#define unipvar         0x08
#define unipval         0x09
#define unitvar         0x0a
#define unitval         0x0b
#define unicon          0x0c
#define uninil          0x0d
#define getnumcon	0x0e
#define putnumcon	0x0f
#define putpvar         0x10
#define putpval         0x11
#define puttvar         0x12
#define putstrv         0x13
#define putcon          0x14
#define putnil          0x15
#define putstr          0x16
#define putlist         0x17
#define bldpvar         0x18
#define bldpval         0x19
#define bldtvar         0x1a
#define bldtval         0x1b
#define bldcon          0x1c
#define bldnil          0x1d
#define uninumcon	0x1e
#define bldnumcon	0x1f
#define getlist_tvar_tvar	0x48
#define getcomma	0x49
#define getcomma_tvar_tvar	0x4a
#define getfloat	0x80
#define putfloat	0x81
#define unifloat	0x82
#define bldfloat	0x83

/* Non-determinism instructions */

#define trys            0x9a
#define retrys          0x9b
#define trusts          0x9c
#define neck		0x9d
#define neck_putpbreg	0x9e
#define neck_puttbreg	0x9f
#define trymeelse       0xa0
#define retrymeelse     0xa1
#define trustmeelsefail 0xa2
#define try             0xa3
#define retry           0xa4
#define trust           0xa5
#define getpbreg        0xa6
#define gettbreg	0xa7
#define putpbreg	0xa8
#define puttbreg	0xa9
#define jumptbreg	0xaa
#define getarg_proceed	0xab

/* string instructions */

#define getstring       0xac
#define putstring       0xad
#define unistring       0xae
#define bldstring       0xaf

/* Indexing instructions */

#define switchonterm    0xb0
#define switchoncon     0xb1
#define switchonstr     0xb2
#define switchonbound	0xb3
#define switchon3bound	0xb4

/* Dynamic trust instruction */

#define dyntrustmeelsefail	0xba

/* Tabling instructions */

#define tableretry      0xbd
#define tabletry        0xbe
#define addtotable      0xbf
#define tabletrust      0xc1
/*(loader directive).*/
#define tabconfig       0xc2  
#define complete_call   0xc3
#define comptabletry    0xc4
#define tabletryfail    0xc5
#define comptabletryfail 0xc6

#define new_lookup      0xc7
#define return_solution 0xc8
#define check_complete  0xc9
#define return_completion 0xca
#define complete_execute  0xcb

#define error_instruction_1 0xcc
#define use_table 0xcd
/* Numeric instructions */
#define movreg          0xd1
#define negate		0xd2
#define and 		0xd3
#define or 		0xd4
#define lshiftl		0xd5
#define lshiftr		0xd6
#define addreg          0xd7
#define subreg          0xd8
#define mulreg          0xd9
#define divreg          0xda
#define idivreg          0xdb


/* Unsafe term instructions */

#define putdval         0xe0
#define putuval         0xe1

#define getival         0xe2

/* Procedure instructions */

#define unexec          0xe7
#define call            0xe8
#define allocate        0xe9
#define deallocate      0xea
#define proceed         0xeb
#define execute         0xec
#define unexeci         0xed
#define executev        0xee
#define calld           0xef



/* Branching instructions */

#define jump            0xf0
#define jumpz           0xf1
#define jumpnz          0xf2
#define jumplt          0xf3
#define jumple          0xf4
#define jumpgt          0xf5
#define jumpge          0xf6



/* Miscellaneous instructions */

#define cases		0xf7
#define fail            0xf8
#define noop            0xf9
#define halt            0xfa
#define builtin         0xfb
#define unifunc		0xfc
/* #define straight_noop	0xfc */
#define userfunc	0xfd
#define endfile         0xff
    /* virtual instruction, used for disassembler to link different segs */

#define PSC_NAME  1
#define PSC_ARITY  2
#define PSC_TYPE  3
#define PSC_PROP  4
#define PSC_SET_TYPE  5
#define PSC_SET_PROP  6
#define FILE_OPEN  7
#define FILE_CLOSE  8
#define FILE_GET  9
#define FILE_PUT 10
#define TERM_PSC 11
#define TERM_TYPE 12
#define TERM_COMPARE 13
#define TERM_NEW 14
#define TERM_ARG 15
#define TERM_SET_ARG 16
#define STAT_FLAG 17
#define STAT_SET_FLAG 18
#define BUFF_ALLOC 19
#define BUFF_WORD 20
#define BUFF_SET_WORD 21
#define BUFF_BYTE 22
#define BUFF_SET_BYTE 23

#define CODE_CALL 24
#define STR_LEN 25
#define STR_CPY 26
#define STR_CAT 27
#define STR_CMP 28
#define STR_HSH 29
#define STR_INSERT 30

/* some other builtins that might need hard implementation */
#define STAT_STA 32
#define STAT_CPUTIME 33
#define CODE_LOAD 34
#define BUFF_SET_VAR 35		/* The followings are not implemented */
#define BUFF_DEALLOC 36		/* in the compiler yet */
#define BUFF_CELL 37
#define BUFF_SET_CELL 38

/* for efficiency reasons, the following predicates are also implemented */
#define FILE_GETWORD 40
#define FILE_PUTWORD 41
#define PSC_INSERT 42
#define PSC_IMPORT 43
#define FILE_GETBUF 44
#define FILE_PUTBUF 45
#define PSC_INSERTMOD 46
#define LOAD_SEG 47
#define FILE_GETTOKEN 48
#define FILE_PUTTOKEN 49
#define TERM_HASH 50
#define UNLOAD_SEG 51
#define LOAD_OBJ 52

#define EXPAND_FILE_NAME 	53
#define GETENV		54

#define SYS_SYSCALL 55
#define SYS_SYSTEM  56
#define SYS_GETHOST 57
#define SYS_ERRNO 58
#define SYS_BROCALL 59
#define FILE_TIME 60

/* commented out of XWAM for now */
#define DOM_SIZE 80
#define DOM_TYPE 81
#define DOM_RANGE 82
#define DOM_ELEM 83
#define DOM_DIFF 84
#define DOM_PLUS 85
#define DOM_TIMES 86
#define DOM_MIN 87
#define DOM_ENUM 88
#define DOM_ESIZE 89

#define BUFF_ASSIGN_WORD 96

#define PSC_ENV		100
#define PSC_SPY		101
#define PSC_TABLED	102
#define TIP_PROP	103
#define IS_INCOMPLETE   104
#define GET_OSP_BREG    105
#define CUT_IF_LEADER   106

#define PAIR_PSC	110
#define PAIR_NEXT	111
#define NEXT_BUCKET	112

#define SUSPEND                  113
#define INCOMPLETE               114
#define HEAP_COPYTERM            115
#define TAB_INTERN               116
#define IS_XWAMMODE              117
#define CLOSE_OPEN_TABLES        118
#define CALL_HASH                119
#define PRINT_PREDICATE_TABLE    120
#define ANALYZE_PREDICATE_TABLE  124
#define COMP_CODE_CALL           125
#define ABOLISH_TABLE_INFO       126
#define ZERO_OUT_PROFILE         127
#define WRITE_OUT_PROFILE        128
#define ASSERT_CODE_TO_BUFF	 129
#define ASSERT_BUFF_TO_CLREF	 130
#define FMT_WRITE		 131
#define FMT_READ		 132

