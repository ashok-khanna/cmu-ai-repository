/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File                  :  cell.h
  Author(s)		:  Jiyang Xu, Terrance Swift
  Modified by		:  David S. Warren, Kostis Sagonas
  Last modification	:  July 19, 1993
========================================================================*/

#ifndef CONFIG_INCLUDED
 ERROR: config_make.h must be included before this file
#endif

/*======================================================================*/
/* CELL: an element in the local stack or global stack (heap).		*/
/* Interface routines							*/
/*	They are put in the different files indicated below, according  */
/*	to the tagging scheme you used.					*/
/* The functions (macros, indeed) include:				*/
/*	cell_tag(cell):		give any cell, return its tag		*/
/*	isnonvar(dcell):	check if the cell is a ref or a var.	*/
/*				(an index in VARASINDEX)		*/
/*				when used with derefed cell, check if	*/
/*				the cell is instanciated 		*/
/*	int_val(dcell):		assume derefed integer cell, return its */
/*				value in machine format			*/
/*	clref_val(dcell):	assume derefed cs or list cell, return  */
/*				a CPtr to the address it points to.	*/
/*	cs_val(dcell):		assume derefed cs cell, return Pair	*/
/*	bld_int(addr, val):	build a new integer cell		*/
/*	bld_float(addr, val):	build a new float cell			*/
/*	bld_ref(addr, val):	build a new reference cell		*/
/*	bld_cs(addr, str):	build a new cs cell			*/
/*	bld_string(addr, str):	build a new string cell			*/
/*	bld_list(addr, list):	build a new list cell			*/
/*	bld_functor(addr, psc):	build a functor cell for a new structure*/
/*	bld_free(addr):		build a new free variable 		*/
/*	bld_copy(dest, source): build a copy of the given cell.		*/
/*			if the source is a free var, the copy is indeed */
/*			a ref cell. Need special checking when free var */
/*			is not a pointer to itself but a special tag.	*/
/*	bld_copy0(dest, src):   the same as bld_copy except assume      */
/*                    non-var, or where semantics is to resume/set.	*/
/*                    (in set CP and resume CP)				*/
/*                    For variable as selfpointer, no differnce.    	*/
/*======================================================================*/

/* ==== types of cells =================================================*/

#define FREE	0x0	/* Free varailble */
#define REF	0x0	/* Reference */
#define CS	0x1	/* Constant and Structure */
#define INT     0x2	/* integer */
#define LIST	0x3	/* List */
#define REF1	0x4	/* REF */
#define STRING  0x5	/* String */
#define FLOAT	0x6	/* Floating number */
#define STRUCT	0x7	/* Structure tag, not used yet */
#define REF2	0x8	/* REF */
#define UnUsed2 0x9
#define TABLIST	0xa	/* index to binding array */
#define TABSTRCT 0xb
#define REF3	0xc	/* REF */
#define DELAY	0xd	/* Delayed variable */
#define DVAR	0xe	/* Domain variable (typed variable) */
#define ESCAPE	0xf	/* Extended tags, used for INVALID, ... */

#define INVALID   0x1f

/* cell_sw.i */
/*======================================================================*/
/* CELL: an element in the local stack or global stack (heap).		*/
/*======================================================================*/

typedef unsigned long CellStr;
typedef unsigned long Cell;
typedef Cell *CPtr;

#define cell(cptr) *(cptr)
#define follow(cell) (*(CPtr)(cell))

extern float asfloat();
extern float getfloatval();
extern int makefloat();

#define cell_tag(cell) ((word)(cell)&0xf)
#define cell_escape_tag(cell) (16+((word)(cell)&0xf0)>>4)

#define isref(cell) (!((word)(cell)&0x3))

#define isnonvar(dcell) ((word)(dcell)&0x3)		/* dcell -> bool */

#if defined(IBM)  /* for IBM machines (like RS-6000) take bits 0-1, 27, 30-31 */
#define enc_int(val) ( ((int)(val) & 0xc8000003) ?\
			(((int)(val) << 5) | 0x10) :\
			(((int)(val) << 2) & 0xc0000000) |\
			(((int)(val) << 3) & 0x3fffffe0) )
#define dec_int(dcell) ( ((int)(dcell) & 0x10) ?\
			((int)(dcell) >> 5) :\
			(((int)(dcell) >> 2) & 0x30000000) |\
			(((int)(dcell) >> 3) & 0x07fffffc) )
/* Fewer bit representation of pointers */
#define enc_addr(addr) ((Cell)(addr) << 2)
#define dec_addr(dcell) (((Cell)(dcell) >> 2) & 0x3ffffffc)

#elif defined(MIPS_BASED) /* for Mips take bits 0-1, 29-31 */
/* Encoded integers/addresses */
#define enc_int(val) ( ((int)(val) & 0xe0000003) ?\
	(((int)(val) << 5) | 0x10) :\
	((int)(val) << 3) )
#define dec_int(dcell) ( ((int)(dcell) & 0x10) ?\
	((int)(dcell) >> 5) :\
	(((int)(dcell) >> 3) & 0x1ffffffc) )

/* Fewer bit representation of pointers */
#define enc_addr(addr) ((Cell)(addr) << 2)
#define dec_addr(dcell) (((Cell)(dcell) >> 2) & 0x3ffffffc)
#else
/* standard representation of integers */
#define enc_int(val) ((int)(val) << 4)
#define dec_int(val) ((int)(val) >> 4)

/* standard encoding of pointers */
#define enc_addr(addr) ((Cell)(addr) << 4)
#define dec_addr(dcell) ((Cell)(dcell) >> 4)
#endif

/* integer manipulation */
#define int_val(dcell) (int)dec_int(dcell)
#define makeint(val) (Cell)((enc_int(val)) | INT)

/* string manipulation */
#define string_val(dcell) (char *)dec_addr(dcell)
#define makestring(str) (Cell)(enc_addr(str) | STRING)

/* pointer manipulation */
#define cs_val(dcell) (Pair)dec_addr(dcell)
#define makecs(str) (Cell)(enc_addr(str) | CS)
#define clref_val(dcell) (CPtr)dec_addr(dcell)
#define makelist(list) (Cell)(enc_addr(list) | LIST)
#define bld_tablist(addr, list) cell(addr) = (Cell)(enc_addr(list) | TABLIST)
#define bld_tabstrct(addr, list) cell(addr) = (Cell)(enc_addr(list)|TABSTRCT)
#define makeunused2(val) (Cell)(enc_addr(val) | UnUsed2)

/* representation of domain variables (?) */
#define domain_val(dcell) dec_addr(dcell)
#define bld_domain(addr, val) cell(addr) = (enc_addr(val) | DVAR)

/* common representations */
#define vptr(dcell) (CPtr)(dcell)
#define float_val(dcell) getfloatval(dcell)
#define ref_val(dcell) (CPtr)(dcell)
#define bld_string(addr, str) cell(addr) = makestring(str)
#define bld_int(addr, val) cell(addr) = makeint(val)
#define bld_float(addr, val) cell(addr) = makefloat(val)
#define bld_ref(addr, val) cell(addr) = (Cell)(val)
#define bld_cs(addr, str) cell(addr) = makecs(str)
#define bld_list(addr, list) cell(addr) = makelist(list)
#define bld_functor(addr, psc) cell(addr) = (word)psc
#define bld_copy0(addr, val) cell(addr) = val
#define bld_copy(addr, val) cell(addr) = val
/* tls -- this bld_copy wont work for VARASINDEX */
#define bld_free(addr) cell(addr) = (Cell)(addr) /* CPtr => FREE cell */


#define isinteger(dcell) (cell_tag(dcell)==INT)	/* dcell -> bool */
#define isfloat(dcell) (cell_tag(dcell)==FLOAT)	/* dcell -> bool */
#define isconstr(dcell) (cell_tag(dcell)==CS)		/* dcell -> bool */
#define istabstrct(dcell) (cell_tag(dcell)==TABSTRCT)
#define islist(dcell) (cell_tag(dcell)==LIST)		/* dcell -> bool */
#define istablist(dcell) (cell_tag(dcell)==TABLIST)

#define isindex(dcell) (cell_tag(dcell)==INDEX)
#define isstring(dcell) (cell_tag(dcell)==STRING)
#define isdomain(dcell) (cell_tag(dcell)==DVAR)
#define isdelay(dcell) (cell_tag(dcell)==DELAY)
#define numequal(num1, num2) num1 == num2

#ifdef CONASSTRING
#define isnil(dcell) (isstring(dcell) &&string_val(dcell) == 0)
#else
#define isnil(dcell) (cs_val(dcell) == nil_sym)		/* dcell -> bool */
#endif

#define get_str_psc(dcell) ((cs_val(dcell))->psc_ptr)


