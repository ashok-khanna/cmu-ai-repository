/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File                  :  main.c
  Author(s)		:  Warren, Swift, Xu, Sagonas
  Last modification	:  July, 1993
========================================================================*/

#define COMP_RECLAIM
/*
#define XPIL1
#define COMPPIL
#define XPIL
#define PROFILE
#define XTRACE
#define OLDTTRACE

*/

#ifdef XPIL1 
int macroprint1 = 1;
int macroprint = 0;
#else
int macroprint = 0;
int macroprint1 = 0;
#endif

#ifdef PROFILE
int subinstprofile = 1;
#else
int subinstprofile = 0;
#endif

#ifdef MEMTRACE
#include <malloc.h>
#endif

#include <stdio.h>
#include "config_make.h"
#include "aux.h"
#include "inst.h"
#include "cell.h"
#include "psc.h"
#include "deref.h"
#include "memory.h"
#include "heap.h"
#include "choice.h"
#include "register.h"
#include "sig.h"
#include "emudef.h"
#include "loader.h"
#include "binding.h"
#include "flags.h"
#include "hashindex.h"
#include "xmacro.h"
#include "subinst.h"

/* change tls 3/20/91 sequent stuff out */
#define m_myid 0

#define pad		lpcreg++
#define ppad		lpcreg+=2
#define pppad		lpcreg+=3
#define opregaddr	(rreg+(*lpcreg++))
#define opvaraddr	(ereg+(-(unsigned int)(*lpcreg++)))

#define opreg		cell(opregaddr)
#define opvar		cell(opvaraddr)
#define op1byte		op1 = (Cell)(*lpcreg++)
#define op2word		op2 = (Cell)(*(int *)lpcreg); lpcreg+=4
#define op3word		op3 = *(int *)lpcreg; lpcreg+=4

/* Be sure that flag only has the following two values.	*/

#define WRITE		1
#define READFLAG	0

#define Fail1 lpcreg = cp_pcreg(breg); 
/* works for all cps*/

/*
#define restore_trail_condition_registers(breg,temp) \
      temp = breg; \
      if ((CPtr) * temp >= (CPtr) pspace || \
	       *temp == (Cell) &use_table_inst || \
	       *temp == (Cell) &new_lookup_inst || \
	       *temp == (Cell) &return_completion_inst || \
	       *temp == (Cell) &return_solution_inst) { \
	ebreg = cp_ebreg(temp); \
	hbreg = cp_hreg(temp); \
       }
*/
/*
#define restore_trail_condition_registers(present,past) \
      if (present <= bfreg) { \
	ebreg = cp_ebreg(present); \
	hbreg = cp_hreg(present); \
       } 

      else {
	if (cp_ebreg(present) < ebreg) { \
	ebreg = efreg; \
	hbreg = hfreg; \
	}
*/

/* works for all cps */
#define restore_trail_condition_registers(breg,temp) \
      if (*breg != (Cell) &check_complete_inst) { \
	ebreg = cp_ebreg(breg); \
	hbreg = cp_hreg(breg); \
       } 

/*
#define restore_trail_condition_registers(breg,temp) \
      temp = breg; \
      while (*temp == (Cell) &check_complete_inst) { \
	temp = cp_prevbreg(temp); \
	printf("!! check_complete %x %x\n",temp,*temp);\
	}\
      ebreg = cp_ebreg(temp); \
      hbreg = cp_hreg(temp)
*/

/*
#define restore_trail_condition_registers(breg,temp) \
      temp = breg; \
      if (*temp == (Cell) &check_complete_inst) { \
	temp = cp_prevbreg(temp); \
	printf("!! check_complete %x %x\n",temp,*temp);\
	}\
      ebreg = cp_ebreg(temp); \
      hbreg = cp_hreg(temp)
*/

extern int synint_proc();
extern int is_interpreter;
extern byte * exception_handler();

int (*dyn_pred)();

#ifdef XWAM
int comptableflag = 0 /*,can_reclaim = 1*/;
int num_unwinds = 0;
int xwammode, timestamp, ctr, level_num, xctr;
CPtr xcurcall, pdlreg1, threg1, xtemp3, xtemp5,xtemp6,xtemp12,hreg1,xtemp14,
     xtemp15,xtemp16;
CPtr * xtrbase;
#ifdef OLDTPROFILE
int suspension_num = 0, new_lookup_num = 0, return_solution_num = 0, 
    use_table_num = 0,
    comp_suspension_num = 0, return_completion_num = 0, all_solutions = 0;
#endif
int variant_check_num = 0;   /* because used in macro */
#endif

main(argc, argv)
int argc;
char *argv[];
{ 
   char *input_file;
   FILE *fd;
   int magic;
   double realtime;
   extern double cpu_time(), real_time();
   
   realtime = real_time();
   setbuf(stdout,NULL);
   init_flags();
   input_file = (char *)init_para(argc, argv);	/* init parameters */
   init_machine();		/* init space, regs, stacks */
   init_inst_table();		/* init table of instruction types */
   init_symbols();		/* preset a few symbols in PSC table */
   init_interrupt();		/* catch ^C interrupt signal */
/* change tls 3/20/91 init_delay taken out */

   fd = fopen(input_file, "r");
   if (!fd) quit0("The input file not found");
   fread(&magic, 4, 1, fd);
   fix_bb((byte *)&magic);
   fclose(fd);
   if (magic == 0x11121304) inst_begin = loader(input_file,0);

   else quit0("Incorrect input file format");
   if (!inst_begin) quit0("Error in loading input file\n");

   if (disassem) {
	dis(1);
/*	printf("The byte code file is dumped in the file dump.pil\n");*/
	exit(0);
   }


#ifdef DEBUG   
   init_tracefile(flags[VERSION_PROCR]);
#endif
  emuloop(inst_begin);

   realtime = real_time() - realtime;
   printf("\nEnd XSB (Beta) (cputime %.2fs, elapsetime ", cpu_time());
   if (realtime<600.0) printf("%.2fs)\n", realtime);
   else printf("%.2f min)\n", realtime/60.0);
   exit(0);
}  /* end of main */

/*======================================================================*/
/* the main emulator loop.						*/
/*======================================================================*/
emuloop(startaddr)
byte *startaddr;
{
struct psc_rec *psc;
register byte *lpcreg;
/*register CPtr ereg;*/
RChoice printbreg;
register CPtr rreg; /* for SUN */
register Cell op1, op2;/*  (*Cptr) */
CPtr op3;
byte flag;  			 /* read/write mode flag            */
Cell opa[3];
int count;

int i, j, arity;  /* to unify subfields of op1 and op2 */  

int restore_type;	/* 0 for retry restore; 1 for trust restore */

#ifdef XWAM
int xflag;
unsigned int xtemp9, xtemp10;
CPtr * xtemp11;
register CPtr xtemp1, xtemp2;
Cell xtemp4, xnewtemp4;
#endif

    rreg = reg; /* for SUN */
    lpcreg = startaddr;

    while (!exitcode) {		/* the main loop */

contcase:

#ifdef XTRACE
    if (xwammode) {
      xctr++;
      if (xctr > 0) xdebug_inst(lpcreg, ereg);
    }      
#else
#ifdef DEBUG
    if (flags[PIL_TRACE]) debug_inst(lpcreg, ereg);
    xctr++;
#endif
#endif
#ifdef PROFILE
    if (flags[PROFFLAG]) {
      inst_table[(int) *(lpcreg)][5] = inst_table[(int) *(lpcreg)][5] +1;
      if (flags[PROFFLAG] > 1 && (int) *lpcreg == builtin) 
	builtin_table[(int) *(lpcreg+3)][1] = 
	  builtin_table[(int) *(lpcreg+3)][1] +1;
    }
#endif

switch (*lpcreg++ ) {

 case getpvar:  /* PVR */
    pad;
    op1 = (Cell)(opvaraddr);
    /* tls 12/8/92 */
    bld_copy0((CPtr)op1, opreg);
    goto contcase;

 case getpval: /* PVR */
    pad; op1 = opvar; op2 = opreg;
    goto nunify;

 case getstrv: /* PPV-S */
    ppad; op1 = opvar; op2word;
    goto nunify_with_str;

 case gettval: /* PRR */
    pad; op1 = opreg; op2 = opreg;
    goto nunify;

 case getcon: /* PPR-C */
    ppad; op1 = opreg; op2word;
    goto nunify_with_con;

 case getnil: /* PPR */
    ppad; op1 = opreg;
    goto nunify_with_nil;

 case getstr: /* PPR-S */
    ppad; op1 = opreg; op2word;
    goto nunify_with_str;

 case getlist: /* PPR */
    ppad; op1 = opreg;
    goto nunify_with_list_sym;

/* tls 12/8/92 */
 case unipvar: /* PPV */
    ppad; op1 = (Cell)(opvaraddr);
    if (flag) {	/* if (flag == WRITE) */
	bind_ref((CPtr)op1, hreg);
	new_heap_free(hreg);
    }
    else {
	bld_copy0((CPtr)op1, *(sreg++));
    }
    goto contcase;

 case unipval: /* PPV */
    ppad; op1 = opvar;
    if (flag)	/* if (flag == WRITE) */
	goto nbldval;
    else {
	op2 = *(sreg++);
	goto nunify;
    } 

 case unitvar: /* PPR */
    ppad; op1 = (Cell)(opregaddr);
    if (flag) {	/* if (flag == WRITE) */
	bld_ref((CPtr)op1, hreg);
	new_heap_free(hreg);
    }
    else {
	bld_copy0((CPtr)op1, *(sreg++));
        /* * (CPtr) op1 = *(sreg++) */
    }
    goto contcase;

 case unitval: /* PPR */
    ppad; op1 = opreg;
    if (flag)	/* if (flag == WRITE) */
	goto nbldval;
    else {
	op2 = *(sreg++);
	goto nunify;
    } 

 case unicon: /* PPP-C */
    pppad; op2word;
    if (flag) {	/* if (flag == WRITE) */
	new_heap_string(hreg, (char *)op2);
    }
    else {  /* op2 already set */
	    op1 = *(sreg++);
	    goto nunify_with_con;
    }
    goto contcase;

 case uninil: /* PPP */
    pppad;
    if (flag) {	/* if (flag == WRITE) */
	new_heap_string(hreg, 0);
    }
    else {
	op1 = *(sreg++);
	goto nunify_with_nil;
    }
    goto contcase;

 case getnumcon: /* PPR-N */
 case getstring: /* PPR-G */
    ppad; op1 = opreg; op2word;
    goto nunify_with_num;

 case getfloat: /* PPR-N */
    ppad; op1 = opreg; op2word;
        goto nunify_with_float;

 case putnumcon: /* PPR-N */
 case putstring: /* PPR-G */
    ppad; op1 = (Cell)(opregaddr);
    op2 = *(pw)lpcreg; lpcreg+=4;
    bld_int((CPtr)op1, op2);
    goto contcase;

 case putfloat: /* PPR-N */
    ppad; op1 = (Cell)(opregaddr);
    bld_float((CPtr)op1, asfloat(*(pw)lpcreg));
    lpcreg+=4;
    goto contcase;

 case putpvar: /* PVR */
    pad;
    op1 = (Cell)(opvaraddr);
    bld_free((CPtr)op1);
    op2 = (Cell)(opregaddr);
    bld_ref((CPtr)op2, (CPtr)op1);
    goto contcase;

 case putpval: /* PVR */
    pad; op1 = (Cell)(opvaraddr);
    bld_copy0(opregaddr, *((CPtr)op1));
    goto contcase;

 case puttvar: /* PRR */
    pad; op1 = (Cell)(opregaddr); op2 = (Cell)(opregaddr);
    bld_ref((CPtr)op1, hreg);
    bld_ref((CPtr)op2, hreg);
    new_heap_free(hreg); 
    goto contcase;

/* tls 12/8/92 */
 case putstrv: /*  PPV-S */
    ppad; op1 = (Cell)(opvaraddr);
    bind_cs((CPtr)op1, (Pair)hreg);
    new_heap_functor(hreg, *(Psc *)lpcreg); lpcreg+=4;
    goto contcase;

 case putcon: /* PPR-C */
    ppad; op1 = (Cell)(opregaddr);
    bld_string((CPtr)op1, *(char **)lpcreg); lpcreg+=4;
    goto contcase;

 case putnil: /* PPR */
    ppad; op1 = (Cell)(opregaddr);
    bld_string((CPtr)op1, 0);
    goto contcase;

/* doc tls -- differs from putstrv since it pulls from a register */
 case putstr: /* PPR-S */
    ppad; op1 = (Cell)(opregaddr);
    bld_cs((CPtr)op1, (Pair)hreg);
    new_heap_functor(hreg, *(Psc *)lpcreg); lpcreg+=4;
    goto contcase;

 case putlist: /* PPR */
    ppad; op1 = (Cell)(opregaddr);
    bld_list((CPtr)op1, hreg);
    goto contcase;

 case bldpvar: /* PPV */
    ppad; op1 = (Cell)(opvaraddr);
    /* tls 12/8/92 */
    bind_ref((CPtr)op1, hreg);
    new_heap_free(hreg);
    goto contcase;

 case bldpval: /* PPV */
    ppad; op1 = opvar;
    goto nbldval;

 case bldtvar: /* PPR */
    ppad; op1 = (Cell)(opregaddr);
    bld_ref((CPtr)op1, hreg);
    new_heap_free(hreg);
    goto contcase;

 case bldtval: /* PPR */
    ppad; op1 = opreg;
    goto nbldval;

 case bldcon: /* PPP-C */
    pppad;
    new_heap_string(hreg, *(char **)lpcreg);
    lpcreg+=4;
    goto contcase;

 case bldnil: /* PPP */
    pppad;
    new_heap_string(hreg, 0);
    goto contcase;

 case getlist_tvar_tvar: /* RRR */
    op1 = opreg;
    IFTHENELSE_DEREF(op1, glrr)
	/* op1 is FREE: change tls for value trail */
	    bind_list((CPtr)(op1), hreg);
	    op1 = (Cell)(opregaddr);
	    bld_ref((CPtr)op1, hreg);
	    new_heap_free(hreg);
	    op1 = (Cell)(opregaddr);
            bld_ref((CPtr)op1, hreg);
	    new_heap_free(hreg);
    }
    else if (islist(op1)) {
	    sreg = clref_val(op1);
	    op1 = (Cell)(opregaddr);
	    bld_ref((CPtr)op1, *(sreg));
	    op1 = (Cell)(opregaddr);
	    bld_ref((CPtr)op1, *(sreg+1));
	 }
	 else Fail1;
    goto contcase;	/* end getlist_tvar_tvar */

 case getcomma: /* PPR */
    ppad; op1 = opreg;
    op2 = (Cell)(comma_psc);
    goto nunify_with_str;

 case getcomma_tvar_tvar: /* RRR */
    op1 = opreg;
    IFTHENELSE_DEREF(op1, gcrr)
	/* op1 is FREE: */
	    bind_cs((CPtr)(op1), (Pair)hreg);
	    new_heap_functor(hreg, comma_psc);
	    op1 = (Cell)(opregaddr);
	    bld_ref((CPtr)op1, hreg);
	    new_heap_free(hreg);
            op1 = (Cell)(opregaddr);
            bld_ref((CPtr)op1, hreg);
	    new_heap_free(hreg);
    }
    else if (isconstr(op1)) {	/* or DELAY */
		/* tls: clref_val = constant list ref val. Untags the word */
	    op2 = (Cell)(clref_val(op1));
	    if (((Pair)(CPtr)op2)->psc_ptr == comma_psc) {
		sreg = (CPtr)op2 + 1;
		op1 = (Cell)(opregaddr);
		bld_ref((CPtr)op1, *(sreg)); sreg++;
		op1 = (Cell)(opregaddr);
		bld_ref((CPtr)op1, *(sreg));
	    }
	  }
	 else Fail1;
    goto contcase;	/* end getcomma_tvar_tvar */

 case uninumcon: /* PPP-N */
 case unistring: /* PPP-G */
    pppad; op2word; /* num in op2 */
    if (flag) {	/* if (flag == WRITE) */
	new_heap_num(hreg, (int)op2);
    }
    else {  /* op2 set */
	op1 = *(sreg++);
	goto nunify_with_num;
    }
    goto contcase;

 case unifloat: /* PPPN */
    pppad; op2word; /* num in op2 */
    if (flag) {	/* if (flag == WRITE) */
	new_heap_float(hreg, asfloat(op2));
    }
    else {  /* op2 set */
	op1 = cell(sreg++);
	goto nunify_with_float;
    }
    goto contcase;
    
 case bldnumcon: /* PPP-N */
 case bldstring: /* PPP-G */
    pppad; op2word; /* num to op2 */
    new_heap_num(hreg, (int)op2);
    goto contcase;

 case bldfloat: /* PPP-N */
    pppad; op2word; /* num to op2 */
    new_heap_float(hreg, asfloat(op2));
    goto contcase;

/* change tls - taken out for now */
 case trys: /* PPA-L */
    printf("trys\n");exit(0);

/* change tls - taken out for now */
 case retrys: /* PPA-L */
    printf("retrys\n");exit(0);

/* change tls - taken out for now */
 case trusts: /* PPA-L */
    printf("trusts\n");exit(0);

/* change tls - taken out for now */
 case neck: /* A */
    quit("neck_putpbreg\n");

/* change tls - taken out for now */
 case neck_putpbreg: /* PAV */
    quit("neck_putpbreg\n");

/* change tls - taken out for now */
 case neck_puttbreg: /* PAR */
    quit("neck_putpbreg\n");

 case trymeelse: /* PPA-L */
    ppad; op1byte; op2word;
    goto subtryme;

 case retrymeelse: /* PPA-L */
    ppad; op1byte;
    cp_pcreg(breg) = *(byte **)lpcreg;
    lpcreg+=4;
    restore_type = 0;
    goto restore_sub;

 case trustmeelsefail: /* PPA */
    ppad; op1byte;
    restore_type = 1;
    goto restore_sub;

 case try: /* PPA-L */
    ppad; op1byte;
    op2 = (Cell)((int)lpcreg + 4);
    lpcreg = *(pb *)lpcreg; /* = *(pointer to byte pointer ) */
    goto subtryme;

 case retry: /* PPA-L */
    ppad; op1byte;
    cp_pcreg(breg) = lpcreg+4;
    lpcreg = *(pb *)lpcreg;
    restore_type = 0;
    goto restore_sub;

 case trust: /* PPA-L */
    ppad; op1byte;
    lpcreg = *(pb *)lpcreg;
    restore_type = 1;
    goto restore_sub;

 case getpbreg: /* PPV */
    ppad; op1 = (Cell)(opvaraddr);
    bld_int((CPtr)op1, (int)breg);
    goto contcase;

 case gettbreg: /* PPR */
/* doc tls op1 = rreg+*lpcreg++ */
    ppad; op1 = (Cell)(opregaddr);
    bld_int((CPtr)op1, (int)breg);
    goto contcase;

 case putpbreg: /* PPV */
    ppad; op1 = opvar;
    deref(op1);
    breg = (CPtr)int_val(op1);
    cut_restore_trail_condition_registers(breg);
    goto contcase;

 case puttbreg: /* PPR */
    ppad; op1 = opreg;
    deref(op1);
    breg = (CPtr)int_val(op1);
    cut_restore_trail_condition_registers(breg);
    goto contcase;

/* also see arith_exception in subp.c -- tls */

 case jumptbreg: /* PPR-L */	/* ??? */
    ppad; op1 = (Cell)(opregaddr);
    bld_int((CPtr)op1, (int)breg);
    lpcreg = *(byte **)lpcreg;
    goto contcase;

 case getarg_proceed: /* PPA */
    ppad; op1byte;
    lpcreg = cpreg;
    goto contcase;

 case switchonterm: /* PPR-L-L */
    ppad; op1 = opreg;
    DEREF(op1, sotd)
	/* case FREE: */
		lpcreg += 8; break;
	/* case DELAY: */
	case INT:
	case STRING:
	case FLOAT:
	    lpcreg = *(pb *)lpcreg;	    
	    break;
	case DVAR:
	    if (*((CPtr)domain_val(op1))!=op1) {
	      op1 = *((CPtr)domain_val(op1));
	      goto sotd;
	    }
	    lpcreg += 8;
	    break;
	case CS:
	    if (get_arity(get_str_psc(op1)) == 0) {
		lpcreg = *(pb *)lpcreg;
		break;
		}
	case LIST:      /* include structure case here */
	    lpcreg += 4; lpcreg = *(pb *)lpcreg; 
	    break;
    DREND
    goto contcase;

 case switchonbound: /* PPR-L-L */
    /* op1 is register, op2 is hash table offset, op3 is modulus */
    ppad; op1 = opreg;
    DEREF(op1, sotd1)
	/* case FREE: */
		lpcreg += 8; goto sotd2;
	/* case DELAY: */
	case INT: 
	case FLOAT:	/* Yes, use int_val to avoid conversion problem */
		op1 = (Cell)int_val(op1);
		break;
	case LIST:
		op1 = (Cell)(list_str); 
		break;
	case CS:
		op1 = (Cell)get_str_psc(op1);
        	break;
	case STRING:
		op1 = (Cell)string_val(op1);
		break;
	case DVAR:
		if (*((CPtr)domain_val(op1))!=op1) {
		  op1 = *((CPtr)domain_val(op1));
		  goto sotd1;
		}
		lpcreg += 8; goto sotd2;
		break;
    DREND
    op2 = (Cell)(*(byte **)(lpcreg)); lpcreg += 4;
    op3 = (CPtr)(*(int *)(lpcreg));
    /* doc tls -- op2 + (op1%size)*4 */
    lpcreg = *(byte **)((byte *)op2 + ihash((int)op1, (int)op3) * 4);
    sotd2: goto contcase;

 case switchon3bound: /* RRR-L-L */
    /* op1 is register, op2 is hash table offset, op3 is modulus */
    if (*lpcreg == 0) { lpcreg++; opa[0] = 0; }
    else opa[0] = (Cell)opreg;
    opa[1] = (Cell)opreg;
    opa[2] = (Cell)opreg;
    op2 = (Cell)(*(byte **)(lpcreg)); lpcreg += 4;
    op3 = (CPtr)(*(int *)(lpcreg)); 
/* This is not a good way to do this, but until we put retract into C,
or add new builtins, it will have to do. */
    j = 0;
    for (i = 0; i <= 2; i++) {
      if (opa[i] != 0) {
	op1 = opa[i];
        DEREF(op1, sob3d1)
	  /* case FREE: */
	        lpcreg += 4;
	        goto sob3d2;
            case INT: 
	    case FLOAT:	/* Yes, use int_val to avoid conversion problem */
		op1 = (Cell)int_val(op1);
		break;
	    case LIST:
		op1 = (Cell)(list_str); 
		break;
	    case CS:
		op1 = (Cell)get_str_psc(op1);
        	break;
	    case STRING:
		op1 = (Cell)string_val(op1);
		break;
	    default:
               fprintf(stderr,"Illegal operand in switchon3bound\n");
	       break;
        DREND
	j = (j<<1) + ihash((int)op1, (int)op3);
      }
    }
    lpcreg = *(byte **)((byte *)op2 + ((j % (int)op3) << 2));
    sob3d2: goto contcase;

 case switchoncon: pppad; op2word;
   printf("Switchoncon not implemented\n");
    goto contcase;

 case switchonstr: pppad; op2word;
   printf("Switchonstr not implemented\n");
    goto contcase;

 case dyntrustmeelsefail: /* PPA-L, second word ignored*/
    ppad; op1byte; lpcreg+=4;
    restore_type = 1;
    goto restore_sub;

#include "xinst_macros.i"

 case complete_call: /* PPA-S */
    pppad; op2word;		/* the first arg is used later by alloc */
    cpreg = lpcreg;
    psc = (Psc)op2;
    goto complete_call_sub;

 case complete_execute:  /* PPP-S */
    pppad; op2word;
    psc = (Psc)op2;
    goto complete_call_sub;

 case movreg: /* PRR */
    pad;
    op1 = (Cell)(opregaddr);
    bld_copy0(opregaddr, *((CPtr)op1));
    goto contcase;

#define ARITHPROC(OP) \
    pad;								\
    op1 = opreg;							\
    op3 = opregaddr;							\
    op2 = *(op3);							\
    deref(op1);								\
    deref(op2);								\
    if (isinteger(op1)) {						\
	if (isinteger(op2)) {						\
	    op2 = int_val(op2) OP int_val(op1);				\
	    bld_int(op3, op2); }					\
	else if (isfloat(op2)) {					\
	    bld_float(op3, float_val(op2) OP (float)int_val(op1)); }	\
	else {arithmetic_exception(lpcreg);}				\
    } else if (isfloat(op1)) {						\
	if (isfloat(op2)) {						\
	    bld_float(op3, float_val(op2) OP float_val(op1)); }		\
	else if (isinteger(op2)) {					\
	    op2 = int_val(op2);						\
	    bld_float(op3, (float)op2 OP float_val(op1)); }		\
	else {arithmetic_exception(lpcreg);}			\
    } else {arithmetic_exception(lpcreg);}

 case addreg: /* PRR */
    ARITHPROC(+);
    goto contcase; 

 case subreg: /* PRR */
/*    ARITHPROC(-); */
    pad;							
    op1 = opreg;							
    op3 = opregaddr;							
    op2 = *(op3);							
    deref(op1);								
    deref(op2);								
    if (isinteger(op1)) {						
	if (isinteger(op2)) {
	    op2 = int_val(op2) - int_val(op1);
	    bld_int(op3, op2); }
	else if (isfloat(op2)) {
	    op1 = int_val(op1);
	    bld_float(op3, float_val(op2) - (float)op1); }
	else {arithmetic_exception(lpcreg);}
    } else if (isfloat(op1)) {
	if (isfloat(op2)) {
	    bld_float(op3, float_val(op2) - float_val(op1)); }
	else if (isinteger(op2)) {
	    op2 = int_val(op2);
	    bld_float(op3, (float)op2 - float_val(op1)); }
	else arithmetic_exception(lpcreg);
    } 
    else arithmetic_exception(lpcreg);
    goto contcase; 

 case mulreg: /* PRR */
    ARITHPROC(*);
    goto contcase; 

 case divreg: /* PRR */
    pad;
    op1 = opreg;
    op3 = opregaddr;
    op2 = *(op3);
    deref(op1);
    deref(op2);
    if (isinteger(op1)) {
	if (isinteger(op2)) {
	    op2 = int_val(op2); op1 = int_val(op1);
	    bld_float(op3, (float)op2/(float)op1); }
	else if (isfloat(op2)) {
	    op1 = int_val(op1);
	    bld_float(op3, float_val(op2)/(float)op1); }
	else {arithmetic_exception(lpcreg);}
    } else if (isfloat(op1)) {
	if (isfloat(op2)) {
	    bld_float(op3, float_val(op2)/float_val(op1)); }
	else if (isinteger(op2)) {
	    op2 = int_val(op2);
	    bld_float(op3, (float)op2/float_val(op1)); }
	else {arithmetic_exception(lpcreg);}
    } else {arithmetic_exception(lpcreg);}
    goto contcase; 

 case idivreg: /* PRR */
    pad;
    op1 = opreg;
    op3 = opregaddr;
    op2 = *(op3);
    deref(op1);
    deref(op2);
    if (isinteger(op1) && isinteger(op2))
	 {  op2 = int_val(op2) / int_val(op1);
	    bld_int(op3, op2); }
    else {arithmetic_exception(lpcreg); }
    goto contcase; 

 case putdval: /* PVR */
    pad;
    op1 = opvar;
    deref(op1);
    op2 = (Cell)(opregaddr);
    bld_copy0((CPtr)op2, op1);
    goto contcase;

 case putuval: /* PVR */
    pad;
    op1 = opvar; op2 = (Cell)(opregaddr);
    deref(op1);
/*    if (isnonvar(op1) || ((CPtr)(op1) < hreg) || ((CPtr)(op1) >= ereg)) {*/
    if (isnonvar(op1) || ((CPtr)(op1) < hreg) || ((CPtr)(op1) >= ereg)) {
	bld_copy0((CPtr)op2, op1);
    } else {
	bld_ref((CPtr)op2, hreg);
	bind_ref((CPtr)(op1), hreg);
	new_heap_free(hreg);
    } 
    goto contcase;

 case call: /* PPA-S */
    pppad; op2word;		/* the first arg is used later by alloc */
    cpreg = lpcreg;
    psc = (Psc)op2;
    goto call_sub;

 case allocate: /* PPP */
    pppad; 
    if (efreg_on_top(ereg))
      op1 = (Cell) (efreg -1);
/*	op1 = (Cell)(efreg -*(cp_cpreg(bfreg) -5));*/
    else {
      if (ereg_on_top(ereg)) op1 = (Cell)(ereg - *(cpreg-5));
      else op1 = (Cell)(ebreg-1);
    }
    if ((int)op1 < (int)hreg+OFMARGIN) {
	printf("Stack overflow in allocate: %x hreg: %x\n",op1,hreg);
	printf("op1 %x ereg %x efreg %x ebreg %x\n",op1,ereg,efreg,ebreg);
/*   	if (!flags[OVERFLOW_F] ) {
	    flags[OVERFLOW_F] = 1;
	    synint_proc(0, MYSIG_OFMEM, lpcreg-4);*/
	    local_global_exception(lpcreg);
	    goto contcase;
/*	}*/
    } 
    *(CPtr *)((CPtr) op1) = ereg;
    *((byte **) (CPtr)op1-1) = cpreg;
    ereg = (CPtr)op1; 
    goto contcase;

 case deallocate: /* PPP */
    pppad; 
    cpreg = *((byte **)ereg-1);
    ereg = *(CPtr *)ereg;
    goto contcase;

 case proceed:  /* PPP */
    pppad; 
    lpcreg = cpreg;
    goto contcase;

 case execute:  /* PPP-S */
    pppad; op2word;
    psc = (Psc)op2;
    goto call_sub;

 case unexec: /* PPPWW, builds str on heap, and executes 2nd arg 
		simulates exec(op2(op1(A1,A2,..,An)) 
		for intercepting calls */
    pppad; op2word;
    op3 = hreg;			/* save addr of new structure rec */
    new_heap_functor(hreg, (Psc)op2); /* set str psc ptr */
    for ( i=1; i<=get_arity((Psc)op2); i++) {
	op1 = *(rreg+i);
	deref(op1);
	if (isnonvar(op1)) {new_heap_node(hreg, op1);}
	else {
	    bind_ref((CPtr)(op1), hreg);
	    new_heap_free(hreg);
	}
    }
    bld_cs(rreg+1, (Pair)op3); /* ptr to new structure on heap */
    op2word;
    psc = (Psc)op2;
    goto call_sub;

 case unexeci: /* PWW, builds str on heap with last arg a var, 
		and executes 2nd arg; for interpreting;
		simulates exec(op2(op1(A1,A2,..,An-1,B),B) */
    pad; op2word;
    op3 = hreg;			/* save addr of new structure rec */
    new_heap_functor(hreg, (Psc)op2); /* set str psc ptr */
    for ( i=1; i<get_arity((Psc)op2); i++) {
	op1 = *(rreg+i);
	deref(op1);
	if (isnonvar(op1)) {new_heap_node(hreg, op1);}
	else {
	    bind_ref((CPtr)(op1), hreg);
	    new_heap_free(hreg);
	    }
    }
    bld_cs(rreg+1, (Pair)op3); /* ptr to new structure on heap */
    bld_ref(rreg+2, hreg);
    new_heap_free(hreg); /* add last field to rec */
    op2word;
    psc = (Psc)op2;
    goto call_sub;

 case executev:	/* PPP-W */
    printf("executev called, complain to tls.\n");
    quit("Abnormal Termination\n");

 case jump:   /* PPP-L */
    pppad;
    lpcreg = *(byte **)lpcreg;
    goto contcase;

 case jumpz:   /* PPR-L */
    ppad; op1 = opreg;
    if (int_val(op1) == 0)
	lpcreg = *(byte **)lpcreg;
    else lpcreg+=4;
    goto contcase;

 case jumpnz:    /* PPR-L */
    ppad; op1 = opreg;
    if (int_val(op1) != 0)
	lpcreg = *(byte **)lpcreg;
    else lpcreg+=4;
    goto contcase;

 case jumplt:    /* PPR-L */
    ppad; op1 = opreg;
    if (int_val(op1) < 0)
	lpcreg = *(byte **)lpcreg;
    else lpcreg+=4;
    goto contcase; 

 case jumple:    /* PPR-L */
    ppad; op1 = opreg;
    if (int_val(op1) <= 0)
	lpcreg = *(byte **)lpcreg;
    else lpcreg+=4;
    goto contcase; 

 case jumpgt:    /* PPR-L */
    ppad; op1 = opreg;
    if (int_val(op1) > 0)
	lpcreg = *(byte **)lpcreg;
    else lpcreg+=4;
    goto contcase;

 case jumpge:    /* PPR-L */
    ppad; op1 = opreg;
    if (int_val(op1) >= 0)
	lpcreg = *(byte **)lpcreg;
    else lpcreg+=4;
    goto contcase; 

 case fail:    /* PPP */
    pppad;
    Fail1; 
    goto contcase;

 case noop:  /* PPA */
    ppad; op1byte;
    lpcreg += (int)op1;
    lpcreg += (int)op1;
    goto contcase;

 case halt:  /* PPP */
    pppad;
    pcreg = lpcreg; 
    exitcode = 1;
    break;	/* not "goto contcase"! */

 case builtin:   
    ppad; op1byte; pcreg=lpcreg; 
    if (builtin_call((int)(op1))) {lpcreg=pcreg;}
    else Fail1;
    goto contcase;

 case unifunc:   /* PAR */
    pad;
    op1byte;
    if (unifunc_call((int)(op1), opregaddr)==0)
	{printf("Error in unary function call\n"); Fail1; }
    goto contcase;

/* Commented because of unifunc
 case straight_noop:   
    pppad;
    op1 = op2;
    goto contcase;
 */

 case userfunc:	/* PPA-S */	/* The same as "call" now */
    pppad; op2word;		/* the first arg is used later by alloc */
    cpreg = lpcreg;
    psc = (Psc)op2;
    goto call_sub;

 case calld:   /* PPA-L */
    ppad; pad;
    cpreg = lpcreg+4; 
    lpcreg = *(pb *)lpcreg;
    goto contcase;

 case lshiftr:  /* PRR */
    pad;
    op1 = opreg;
    op3 = opregaddr;
    op2 = *(op3);
    deref(op1); 
    deref(op2);
    if (!isinteger(op1) || !isinteger(op2)) 
	{printf("Integer required\n"); Fail1;}
    else { op2 = int_val(op2) >> int_val(op1);
	    bld_int(op3, op2); }
    goto contcase; 

 case lshiftl:   /* PRR */
    pad;
    op1 = opreg;
    op3 = opregaddr;
    op2 = *(op3);
    deref(op1); 
    deref(op2);
    if (!isinteger(op1) || !isinteger(op2)) 
	{bitop_exception(lpcreg);}
    else { op2 = int_val(op2) << int_val(op1);
	   bld_int(op3, op2); }
    goto contcase; 

 case or:   /* PRR */
    pad;
    op1 = opreg;
    op3 = opregaddr;
    op2 = *(op3);
    deref(op1); 
    deref(op2);
    if (!isinteger(op1) || !isinteger(op2)) 
	{bitop_exception(lpcreg);}
    else { op2 = int_val(op2) | int_val(op1);
	    bld_int(op3, op2); }
    goto contcase; 

 case and:   /* PRR */
    pad;
    op1 = opreg;
    op3 = opregaddr;
    op2 = *(op3);
    deref(op1); 
    deref(op2);
    if (!isinteger(op1) || !isinteger(op2)) 
	{bitop_exception(lpcreg);}
    else { op2 = int_val(op2) & int_val(op1);
	    bld_int(op3, op2); }
    goto contcase; 

 case negate:   /* PPR */
    ppad; op3 = opregaddr;
    op2 = *(op3);
    deref(op2);
    if (!isinteger(op2)) 
	{bitop_exception(lpcreg);}
    else { op2 = ~(int_val(op2)); bld_int(op3, op2); }
    goto contcase; 

 case endfile:   /*  */

 default: 
    printf("\nIllegal opcode hex %x at %x\n", *--lpcreg, lpcreg); 
    quit("Abnormal termination");
	} /* end switch */

    }  /*  end main instruction loop */
    return;

/*======================================================================*/
/* unification routines							*/
/*======================================================================*/

#define SUCCEED		break
#define IFTHEN_SUCCEED
#define FAILED		Fail1; break
#define IFTHEN_FAILED	Fail1

nunify: /* ( op1, op2 ) */
/* word op1, op2 */
#include "unify.i"

    goto contcase;  /* end of nunify */

/*======================================================================*/
/* Special unification routines						*/
/*======================================================================*/

#include "emusubs.i"


/*======================================================================*/

/*======================================================================*/
subtryme:
{
  register CPtr tbreg;

  save_find_locx(ereg);
  /* doc tls save find loc sets ebreg to the top of the E-stack */
  /* doc tls -- tbreg only needed for efficiency */
  if (bfreg < breg) tbreg = bfreg;
  else tbreg = breg;
  check_stack_overflow(tbreg, lpcreg, (byte *)op2);
  save_registers(tbreg, (int)op1, i, rreg);
  save_choicepoint(tbreg, ereg, (byte *)op2,breg);
  breg = tbreg;
  hbreg = hreg;
  goto contcase; /* end of subtryme */
}

restore_sub:
{
  register CPtr tbreg;
  CPtr *oldtr;

  tbreg = breg;
  switch_envs(tbreg);
  restore_some_wamregs(tbreg, ereg);
  restore_registers(tbreg, (int)op1, i, rreg);
  if (restore_type == 1) { /* trust */
     xtemp1 = breg;
     breg = cp_prevbreg(breg); 
#ifdef XPIL
    if (*breg == (Cell) &check_complete_inst) 
      printf("trust !! cc %x\n",xtemp1);
#endif
     restore_trail_condition_registers(breg,xtemp1);
   }
}
  goto contcase;

table_restore_sub:
{
  register CPtr tbreg;
  CPtr *oldtr;

  tbreg = breg;
  switch_envs(tbreg);
  restore_some_wamregs(tbreg, ereg);
  table_restore_registers(tbreg, (int)op1, i, rreg);
  if (restore_type == 1) { 
    xtemp1 = tcp_prevbreg(breg); 
#ifdef XPIL
    if (*xtemp1 == (Cell) &check_complete_inst) 
      printf("tabtrust !! cc %x\n",xtemp1);
#endif
    restore_trail_condition_registers(xtemp1,breg);
  }

}
  goto contcase;

} /* end emuloop */

