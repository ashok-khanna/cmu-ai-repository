/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File                  :  xmacro.h
  Author(s)		:  Swift 
  Last modification	:  August, 1993
======================================================================*/

typedef struct tab_info {
  CPtr next_tip;
  CPtr call_hash_addr;
  long call_hash_size;
  long ret_hash_size;      
} *tab_inf_ptr;

#define get_next_tip(ptr) ((tab_inf_ptr)ptr)->next_tip
#define get_tab_entry(ptr) ((tab_inf_ptr)ptr)->call_hash_addr
#define get_chs(ptr) ((tab_inf_ptr)ptr)->call_hash_size
#define get_rhs(ptr) ((tab_inf_ptr)ptr)->ret_hash_size

typedef struct opentable_stack_frame {
  CPtr call_structure_susp_ptr;
  int  level_num;
} *OTSFrame;

#define ots_susp_ptr(b) ((OTSFrame)(b))->call_structure_susp_ptr
#define ots_level(b) ((OTSFrame)(b))->level_num

#define OTFRAMESIZE 2

#define	push_opentable_frame(temp) \
  check_opentable_stack_overflow;\
  level_num++; \
  openreg -= (OTFRAMESIZE -1); \
  ots_susp_ptr(openreg) = temp; \
  ots_level(openreg) = level_num;\
  openreg--

#define RETSTRUCTSIZE 2

#define RS_RET xtemp5
#define RS_ENV xtemp3
	    
/* Not yet used */
typedef struct call_structure_frame {
  CPtr next_cs;
  CPtr retptr;
  CPtr suspptr;
  CPtr tipptr;
  CPtr openstackptr;
  CPtr comp_suspptr;
} *CSFrame;

#define cs_nextcs(b) ((CSFrame)(b))->nextcs
#define cs_retptr(b) ((CSFrame)(b))->retptr
#define cs_suspptr(b) ((CSFrame)(b))->suspptr
#define cs_tipptr(b) ((CSFrame)(b))-> tipptr
#define cs_openstackptr(b) ((CSFrame)(b))->openstackptr
#define cs_comp_suspptr(b) ((CSFrame)(b))->comp_suspptr

#ifdef NOT_RETURN_HASHING
#define CALLSTRUCTSIZE 6
#define call_str_retptr(PTR)  (PTR - 1)
#define call_str_susptr(PTR) (PTR - 2)
#define call_str_tipptr(PTR) (PTR - 3)
#define call_str_openstackptr(PTR) (PTR - 4)
#define call_str_comp_susptr(PTR) (PTR - 5)
#define call_str_retindexptr(PTR)  (PTR - 6)

#define tab_level(PTR) ots_level(*call_str_openstackptr(PTR))
#define next_tab_level(PTR) ots_level((((CPtr) *(call_str_openstackptr(PTR))) + OTFRAMESIZE))

#define create_call_structure(tabreg,TIP) \
      *tabreg-- = (Cell) 0;                /* ptr to nextcall */ \
      *tabreg-- = (Cell) -1;               /* will be ptr to return */ \
      *tabreg-- = 0;                      /* will be ptr to suspension */ \
      *tabreg-- = (Cell) TIP;                                           \
      *tabreg-- = (Cell) (openreg - OTFRAMESIZE +1) ; \
      *tabreg-- = (Cell) 0;                /* will be ptr to comp_susps */
      *tabreg-- = (Cell) 0                /* will be ptr to ret_index */

#else

#define CALLSTRUCTSIZE 5
#define call_str_retptr(PTR)  (PTR - 1)
#define call_str_susptr(PTR) (PTR - 2)
#define call_str_tipptr(PTR) (PTR - 3)
#define call_str_openstackptr(PTR) (PTR - 4)
#define call_str_comp_susptr(PTR) (PTR - 5)

#define tab_level(PTR) ots_level(*(PTR -4))
#define next_tab_level(PTR) ots_level(((CPtr) *(call_str_openstackptr(PTR))) + OTFRAMESIZE)

#define create_call_structure(tabreg,TIP) \
      *tabreg-- = (Cell) 0;                /* ptr to nextcall */ \
      *tabreg-- = (Cell) -1;               /* will be ptr to return */ \
      *tabreg-- = 0;                      /* will be ptr to suspension */ \
      *tabreg-- = (Cell) TIP;                                           \
      *tabreg-- = (Cell) (openreg - OTFRAMESIZE +1) ; \
      *tabreg-- = (Cell) 0                /* will be ptr to comp_susps */

#endif

#ifdef COMPPIL
#define adjust_level(openregptr) \
  printf("adjust level openregptr %x \n",openregptr); \
  print_opentables(); \
  printf("this level %x level_num %d\n",ots_level(openregptr),level_num);\
  xtemp2 = (CPtr) ots_level(openregptr); \
  if ( (long) xtemp2 < level_num) {\
      printf("first decrement \n"); \
/* today      for (xtemp1 = (CPtr) openregptr -1; */  \
      for (xtemp1 = (CPtr) openregptr +1;   \
	   *xtemp1 >= (Cell) xtemp2 && xtemp1 < ((CPtr) OPENSTACKBOTTOM)-1;\
	   xtemp1 = xtemp1 + OTFRAMESIZE) { \
	     printf("adj: xtemp1 %x *xtemp1 %x \n",xtemp1,*xtemp1);\
	     *xtemp1 = (Cell) xtemp2; } \
      printf("now increment \n"); \
/* today      for (xtemp1 = (CPtr) openregptr -1; */  \
      for (xtemp1 = (CPtr) openregptr +1;   \
	   *xtemp1 >= (Cell) xtemp2 && xtemp1 > openreg;\
	   xtemp1 = xtemp1 - OTFRAMESIZE) { \
	     printf("adj: xtemp1 %x *xtemp1 %x \n",xtemp1,*xtemp1);\
	     *xtemp1 = (Cell) xtemp2; } \
    } 
#else
#define adjust_level(openregptr) \
  xtemp2 = (CPtr) ots_level(openregptr); \
  if ( (long) xtemp2 < level_num) {\
      for (xtemp1 = (CPtr) openregptr -1;  \
	   *xtemp1 >= (Cell) xtemp2 && xtemp1 < ((CPtr) OPENSTACKBOTTOM)-1;\
	   xtemp1 = xtemp1 + OTFRAMESIZE) { \
	     *xtemp1 = (Cell) xtemp2; } \
      for (xtemp1 = openregptr -1;  \
	   *xtemp1 >= (Cell) xtemp2 && xtemp1 > openreg;\
	   xtemp1 = xtemp1 - OTFRAMESIZE) { \
	     *xtemp1 = (Cell) xtemp2; } \
    } 
#endif

#define reset_freeze_registers \
  bfreg = (CPtr)(main_thread->opentable - sizeof(struct choice_point) ); \
  trfreg = (CPtr *)(main_thread->trail); \
  hfreg = (CPtr)(main_thread->maxsusp); \
  efreg = (CPtr)(main_thread->lstack); \
/*  can_reclaim = 1;*/\
  level_num = 0; \
  xwammode = 0

#define spew_out_registers \
    printf("CHS: %x RHS: %x\n",CHS,RHS); \
    printf("breg %x bfreg %x\n",breg,bfreg); \
    printf("hreg %x hfreg %x\n",hreg,hfreg); \
    printf("ereg %x efreg %x ebreg %x\n",ereg,efreg,ebreg); \
    printf("trreg %x trfreg %x\n",trreg,trfreg); \
    printf("before vchk xcurcall %x get_tab_entry(xcurcall) %x\n",xcurcall,get_tab_entry(xcurcall))


/*
#define check_consistency_of_tables\
  for ( xtemp1 = threg ; xtemp1 >= main_thread->pdl ; xtemp1--) {
    if (isref(xtemp1) && xtemp1 > 0)
    if ( main_thread->pdl <= *xtemp1 && *xtemp1 < hreg)
       printf("in threg: %x bound to %x\n",xtemp1,*xtemp1);
*/

#define floval(cell) ((Cell) cell & 0xfffffff0)
	
#define pdlpush(cell)   *(pdlreg) = cell;  pdlreg--

#define pdlpop  *(++pdlreg)

#define pdlempty (pdlreg == (CPtr) (main_thread->pdl) -1)

#define resetpdl \
   if (pdlreg < (CPtr) main_thread->memory) \
     quit("pdlreg grew too much"); \
   else (pdlreg = (CPtr) (main_thread->pdl) -1)


#define tracetabhash(addr,size,result,temp1,temp2) \
  temp1 = (CPtr) * addr;\
  printf("tth addr %x, temp1 %x\n",addr,temp1);\
  cptr_deref(temp1);\
  switch (cell_tag(temp1)) {\
    case FREE: case REF1: case REF2: case REF3: \
      temp2 = (CPtr) 1;\
      break;\
    case LIST:\
      temp2 = (CPtr) 2;\
      break;\
    case CS:\
      temp2 =(CPtr) follow(cs_val(temp1));\
      break;\
    default:\
      temp2 = temp1;\
      }\
   result = (CPtr) ((unsigned) (temp2) % (size));\
   printf("tth res %x, temp1 %x\n",result,temp1)

#define excepthash(addr,size,result,temp1,temp2) \
  temp1 = (CPtr) * addr;\
  switch (cell_tag(temp1)) {\
    case FREE: case REF1: case REF2: case REF3: \
      temp2 = (CPtr) 1;\
      break;\
    case LIST:\
      temp2 = (CPtr) 2;\
      break;\
    case CS:\
      temp2 =(CPtr) follow(cs_val(temp1));\
      break;\
    default:\
      temp2 = temp1;\
      }\
   result = (CPtr) ((unsigned) (temp2) % (size))

#ifdef MMLARGE
#define load_solution_switch(one,two,three) \
  load_solution(one,two,three,lpcreg)
#else
#define load_solution_switch(one,two,three) \
  load_solution_fun(one,two,three)
#endif

/* lpcreg stuff for exceptions */
#define savecallinfo_fun(arity,from_addr) \
      pcreg = lpcreg; \
      savecallinfo_fun1(ARITY,from_addr); \
      if (pcreg != lpcreg) goto contcase;

#define load_solution_fun(ARITY,reg,tptr) \
      pcreg = lpcreg; \
      load_solution_fun1(ARITY,reg,tptr); \
      if (pcreg != lpcreg) goto contcase;

#ifdef XPIL1
/*
#define scaffolded_deref(op) printf("begin deref\n"); while (isref(op)) { \
			printf("op %x follow %x\n",op,*(CPtr) (op));\
			if (op==follow(op)) break; op=follow(op); }
*/
#define scaffolded_deref(op) deref(op)
#define scaffolded_cptr_deref(op) cptr_deref(op)
#else
#define scaffolded_deref(op) deref(op)
#define scaffolded_cptr_deref(op) cptr_deref(op)
#endif

/* second arg is just a temporary variable */
#ifdef SCAFFOLD
#define table_undo_bindings(old_trreg, traddr) \
  if ( ( (int) trreg - (int) old_trreg) % 3 != 0) {\
	   quit("trail off in tabinst");\
	   }\
   while (trreg > old_trreg) {\
     traddr = *(trreg-2);\
     untrail(traddr);\
     trreg = (CPtr *) *trreg;\
     }
#else
#define table_undo_bindings(old_trreg, traddr) \
   while (trreg > old_trreg) {\
     traddr = *(trreg-2);\
     untrail(traddr);\
     trreg = (CPtr *) *trreg;\
     }
#endif

/* OLDT PROFILE MUST BE DEFINED */
#define variant(arity,cptr,ptr,flag,op,t_pcreg) \
        variant_check_num++;\
	flag = 1;   xtrbase = trreg;\
        ctr = 0;\
	for (i = 1 ; i <= (int) arity && flag; i++) {\
	if (subinstprofile) \
	  subinst_table[VARIANT][1] = subinst_table[VARIANT][1] + 1; \
	  xtemp1 = (CPtr) (ptr-i);\
	  xtemp2 = (CPtr) (cptr op i);	\
	  scaffolded_cptr_deref(xtemp1);\
	  scaffolded_cptr_deref(xtemp2);\
	  switch (cell_tag(xtemp1)) { \
	    case FREE: case REF1: case REF2: case REF3: \
	      if (isref(cell_tag(xtemp2))) {\
		dbind_ref(xtemp2,makeunused2(ctr));\
		dbind_ref(xtemp1,makeunused2(ctr));\
		ctr++;\
	      }\
	      else flag = 0;\
	      break;  \
	    case STRING: case INT: case UnUsed2:\
	      if ( xtemp1 != xtemp2 ) flag = 0;\
	      break;\
	    case LIST: \
	      if ( islist(xtemp2)) {\
	        pdlpush( cell(clref_val(xtemp1)+1) );\
	        pdlpush( cell(clref_val(xtemp2)+1) );\
	        pdlpush( cell(clref_val(xtemp1)) );\
	        pdlpush( cell(clref_val(xtemp2)) );\
	        recvariant(flag,t_pcreg);\
	      }\
	      else flag = 0;\
              break;\
	    case TABLIST: \
	      if ( islist(xtemp2)) {\
		if (clref_val(xtemp1) != clref_val(xtemp2)) {\
	          pdlpush( cell(clref_val(xtemp1)+1) );\
	          pdlpush( cell(clref_val(xtemp2)+1) );\
	          pdlpush( cell(clref_val(xtemp1)) );\
	          pdlpush( cell(clref_val(xtemp2)) );\
	          recvariant(flag,t_pcreg);\
		} \
	      }\
	      else flag = 0;\
              break;\
	    case TABSTRCT:\
	      if (clref_val(xtemp1) != clref_val(xtemp2)) {\
 	        if ( isconstr(xtemp2) && \
		     follow(cs_val(xtemp1)) == follow(cs_val(xtemp2)) ) {\
		  for(j=get_arity((struct psc_rec *)follow(cs_val(xtemp1)));\
		        j>=1 ; j--) {\
  	             pdlpush(cell(clref_val(xtemp1) +j));\
  	             pdlpush(cell(clref_val(xtemp2) +j));\
		  }\
		  recvariant(flag,t_pcreg);\
		}\
	      else flag = 0;\
	      } \
	      break;\
	    case CS:\
	      if ( isconstr(xtemp2) && \
		  follow(cs_val(xtemp1)) == follow(cs_val(xtemp2)) ) {\
		  for(j=get_arity((struct psc_rec *)follow(cs_val(xtemp1)));\
		        j>=1 ; j--) {\
  	             pdlpush(cell(clref_val(xtemp1) +j));\
  	             pdlpush(cell(clref_val(xtemp2) +j));\
		  }\
		  recvariant(flag,t_pcreg);\
		  }\
	      else flag = 0;\
	      break;\
  	    case FLOAT:\
/*	      if (floval(xtemp1) != floval(xtemp2)) flag = 0;*/ \
	      float_unification_exception(t_pcreg);\
	      break;\
	  }\
	  }\
        resetpdl;\
	table_undo_bindings(xtrbase, xtemp1);
/* differs from undo bindings in that end is known. 
   xtemp1 is just a temporary variable */

/* cptr is choice point stack */
#define saveinfo(arity,cptr,tptr,op,t_pcreg)\
   xtrbase = trreg;\
   for (i =1 ; i <= (int) arity ; i++) {\
     if (subinstprofile) \
       subinst_table[SAVEINFO][1] = subinst_table[SAVEINFO][1] + 1; \
     xtemp4 = *(cptr op i);\
     scaffolded_deref(xtemp4);\
     switch (cell_tag(xtemp4)) { \
       case FREE: case REF1: case REF2: case REF3: \
         if (xtemp4 > ((Cell) TableStackBarrier) - 1) {\
           bld_free(tptr);\
           dpushtrail((CPtr) xtemp4,*((CPtr) xtemp4));\
           bld_ref((CPtr)xtemp4, tptr);\
         }\
         else {\
	   bld_ref(tptr, xtemp4);\
         }\
         break;\
       case INT: case STRING: /*case FLOAT:*/ \
	 bld_copy(tptr, xtemp4);\
         break;\
       case FLOAT:\
         float_unification_exception(t_pcreg);\
	 break;\
       case LIST:\
         if (clref_val(xtemp4) < (CPtr) main_thread->maxsusp) \
            bld_tablist(tptr,clref_val(xtemp4));\
	 else {\
	 bld_list(tptr,(Cell)threg);\
	 pdlpush(cell(clref_val(xtemp4)));\
	 pdlpush(cell(clref_val(xtemp4) +1));\
	 threg1 = threg + 2;\
	 queue_structcpy(xtemp4,t_pcreg);\
	 } \
         break;\
       case CS:\
         if (clref_val(xtemp4) < (CPtr) main_thread->maxsusp) \
            bld_tabstrct(tptr,(Cell)clref_val(xtemp4));\
	 else {\
	 bld_cs(tptr,(Cell)threg);\
	 bld_ref(threg, follow(cs_val(xtemp4))); threg++;\
         for (j=1 ; j <= get_arity((struct psc_rec *)follow(cs_val(xtemp4)))\
	          ;  j++) {\
  	   pdlpush(cell(clref_val(xtemp4) +j));\
	 }\
	 threg1 = threg + j - 1;\
	 queue_structcpy(xtemp4,t_pcreg);\
         break; \
	 }\
     }\
     tptr--; \
     }\
   resetpdl;\
   table_undo_bindings(xtrbase,xtemp1)

#define load_solution(arity,cptr,tptr,t_pcreg)\
   for (i =1 ; i <= (int) arity ; i++) {\
     if (subinstprofile) \
       subinst_table[LOAD_SOLUTION][1] = subinst_table[LOAD_SOLUTION][1] + 1; \
     xtemp1 = (CPtr) (cptr-i);\
     xtemp2 = (CPtr) (tptr - i);\
     cptr_deref(xtemp1);\
     cptr_deref(xtemp2);\
     switch (cell_tag(xtemp1)) { \
       case FREE: case REF1: case REF2: case REF3: \
        switch(cell_tag(xtemp2)) {\
          case FREE: case REF1: case REF2: case REF3: \
            if (xtemp2 > TableStackBarrier - 1) {\
              bind_ref(xtemp1, *xtemp2);\
            }\
            else {\
              tabpushtrail0(xtemp2,*xtemp2);\
              bld_ref(xtemp2,xtemp1);\
	    }\
	    break;\
	  case LIST:\
	    bind_list(xtemp1,hreg);\
	    xtemp12 = pdlreg;\
	    pdlreg1 = xtemp12;\
            pdlpush(cell(clref_val(xtemp2)));\
            pdlpush(cell(clref_val(xtemp2) +1));\
	    hreg1 = hreg + 2;\
            heap_queue_structcpy(pdlreg1,xtemp2,hreg1,t_pcreg);\
	    pdlreg = xtemp12;\
            break;\
	  case TABLIST:\
	    bind_list(xtemp1,clref_val(xtemp2));\
	    break;\
          case STRING: case INT:\
            bind_ref(xtemp1,xtemp2);\
            break;\
          case CS:\
	    bind_cs(xtemp1,hreg);\
	    xtemp12 = pdlreg;\
	    pdlreg1 = xtemp12;\
            pdlpush(((Cell) xtemp2 | 8));\
	    for(j = 1; \
		j <= get_arity((struct psc_rec *)follow(cs_val(xtemp2)));\
		j++) {\
  	    pdlpush(cell(clref_val(xtemp2) +j));\
	    }\
	    hreg1 = hreg+1+\
	      get_arity((struct psc_rec*)follow(cs_val(xtemp2)));\
            heap_queue_structcpy(pdlreg1,xtemp2,hreg1,t_pcreg);\
	    pdlreg = xtemp12;\
            break;\
	  case TABSTRCT:\
	    bind_cs(xtemp1,clref_val(xtemp2));\
	}\
        break;\
       case INT: case STRING:\
	 if ( xtemp1 != xtemp2 ) return_abort(xtemp1,xtemp2,"ls-int-string");\
	 break;\
       case LIST: \
	 if ( islist(xtemp2)) {\
	   pdlpush( cell(clref_val(xtemp1)+1) );\
	   pdlpush( cell(clref_val(xtemp2)+1) );\
	   pdlpush( cell(clref_val(xtemp1)) );\
	   pdlpush( cell(clref_val(xtemp2)) );\
	   recload_solution(t_pcreg);\
	 }\
	 else {\
	   if ( istablist(xtemp2)) {\
	     if (clref_val(xtemp2) != clref_val(xtemp1)) {\
  	       pdlpush( cell(clref_val(xtemp1)+1) );\
	       pdlpush( cell(clref_val(xtemp2)+1) );\
	       pdlpush( cell(clref_val(xtemp1)) );\
	       pdlpush( cell(clref_val(xtemp2)) );\
	       recload_solution(pcreg);\
	     } \
	   }\
	 else return_abort(xtemp1,xtemp2,"ls-list");\
	}\
	 break; \
       case CS:\
	     if (follow(cs_val(xtemp1)) == follow(cs_val(xtemp2))) {\
	      if ( isconstr(xtemp2)) {\
		for(j=get_arity((struct psc_rec *)follow(cs_val(xtemp1)));\
		        j>=1 ; j--) {\
  	           pdlpush(cell(clref_val(xtemp1) +j));\
  	           pdlpush(cell(clref_val(xtemp2) +j));\
		}\
		recload_solution(t_pcreg);\
	      }\
	  else if ( istabstrct(xtemp2) ) {\
	    if( clref_val(xtemp1) != clref_val(xtemp2) ) {\
		for(j=get_arity((struct psc_rec *)follow(cs_val(xtemp1)));\
		        j>=1 ; j--) {\
  	           pdlpush(cell(clref_val(xtemp1) +j));\
  	           pdlpush(cell(clref_val(xtemp2) +j));\
		 }\
		recload_solution(pcreg);\
	      }\
	    }\
	  }\
	else return_abort(xtemp1,xtemp2,"ls-cs");\
	      break;\
       case FLOAT: \
	 float_unification_exception(lpcreg);\
	 break;\
/*	 if ( floval(xtemp1) != floval(xtemp2) ) \
	   quit("float return not loaded  Going down\n");*/ \
      default: \
	 return_abort(xtemp1,xtemp2,"bad tag in ls");\
	 break; \
     }\
     }\
     resetpdl;\
     undo_load_solution_bindings

#define recload_solution(t_pcreg)\
  while (!pdlempty) {\
    xtemp2 = (CPtr) pdlpop;\
    xtemp1 = (CPtr) pdlpop;\
    cptr_deref(xtemp1);\
    cptr_deref(xtemp2);\
    if (subinstprofile) \
	  subinst_table[RECLOAD][1] = subinst_table[RECLOAD][1] + 1; \
    switch(cell_tag(xtemp1)) {\
      case FREE: case REF1: case REF2: case REF3: \
        switch(cell_tag(xtemp2)) {\
          case FREE: case REF1: case REF2: case REF3: \
            if (xtemp2 > TableStackBarrier - 1) {\
              bind_ref(xtemp1,*xtemp2);\
            }\
            else {\
              tabpushtrail0(xtemp2,*xtemp2);\
              bld_ref(xtemp2,xtemp1);\
	    }\
	    break;\
	  case LIST:\
	    bind_list(xtemp1,hreg);\
	    xtemp12 = pdlreg;\
	    pdlreg1 = xtemp12;\
            pdlpush(cell(clref_val(xtemp2) ));\
            pdlpush(cell(clref_val(xtemp2) +1));\
	    hreg1 = hreg + 2;\
            heap_queue_structcpy(pdlreg1,xtemp2,hreg1,t_pcreg);\
	    pdlreg = xtemp12;\
            break;\
          case STRING: case INT: /*case FLOAT:*/ \
            bind_ref(xtemp1,xtemp2);\
            break;\
          case FLOAT:\
	    float_unification_exception(t_pcreg);\
	    break;\
          case CS:\
	    bind_cs(xtemp1,hreg);\
	    xtemp12 = pdlreg;\
	    pdlreg1 = xtemp12;\
            pdlpush(((Cell) xtemp2 | 8));\
	    for(j = 1; \
		j <= get_arity((struct psc_rec *)follow(cs_val(xtemp2)));\
		j++) {\
  	    pdlpush(cell(clref_val(xtemp2) +j));\
	    }\
	    hreg1 = hreg+1+\
	      get_arity((struct psc_rec*)follow(cs_val(xtemp2)));\
            heap_queue_structcpy(pdlreg1,xtemp2,hreg1,t_pcreg);\
	    pdlreg = xtemp12;\
            break;\
	}\
	break;\
      case STRING: case INT:\
	if (xtemp2 != xtemp1) return_abort(xtemp1,xtemp2,"rls-string/int");\
	 break;\
      case LIST:\
	 if ( islist(xtemp2)) {\
	   pdlpush( cell(clref_val(xtemp1)+1) );\
	   pdlpush( cell(clref_val(xtemp2)+1) );\
	   pdlpush( cell(clref_val(xtemp1)) );\
	   pdlpush( cell(clref_val(xtemp2)) );\
	 }\
	 else {\
	   if ( istablist(xtemp2)) {\
	     if (clref_val(xtemp2) != clref_val(xtemp1)) {\
  	       pdlpush( cell(clref_val(xtemp1)+1) );\
	       pdlpush( cell(clref_val(xtemp2)+1) );\
	       pdlpush( cell(clref_val(xtemp1)) );\
	       pdlpush( cell(clref_val(xtemp2)) );\
	     } \
	   }\
	   else return_abort(xtemp1,xtemp2,"ls-list");\
	 }\
        break;\
      case CS:\
	 if (isconstr(xtemp2)) { \
	   if ( follow(cs_val(xtemp1)) == follow(cs_val(xtemp2)) ) {\
	     for(j=get_arity((struct psc_rec *)follow(cs_val(xtemp1)));\
		        j>=1 ; j--) {\
  	       pdlpush(cell(clref_val(xtemp1) +j));\
  	       pdlpush(cell(clref_val(xtemp2) +j));\
	     }\
	   }\
	 }\
	 else  if (istabstrct(xtemp2)) { \
	   if (clref_val(xtemp2) != clref_val(xtemp1)) {\
	     if ( follow(cs_val(xtemp1)) == follow(cs_val(xtemp2)) ) {\
	       for(j=get_arity((struct psc_rec *)follow(cs_val(xtemp1)));\
		        j>=1 ; j--) {\
  	         pdlpush(cell(clref_val(xtemp1) +j));\
  	         pdlpush(cell(clref_val(xtemp2) +j));\
	       }\
	     }\
	   }\
	 }\
	 else return_abort(xtemp1,xtemp2,"cs");\
	 break;\
       case FLOAT: \
	 float_unification_exception(t_pcreg);\
	 break;\
/*	 if ( floval(xtemp1) != floval(xtemp2) ) \
	   quit("return not loaded  Going down\n");*/ \
       default:\
	 return_abort(xtemp1,xtemp2,"rls-bad-tag");\
     }\
     }\
     resetpdl;

#define queue_structcpy(temp,t_pcreg)\
        pdlreg1 = ((CPtr) main_thread->pdl) -1;\
	while ( pdlreg1 > pdlreg) {\
	if (subinstprofile) \
	  subinst_table[QS][1] = subinst_table[QS][1] + 1; \
	  temp = *(pdlreg1--);\
	  scaffolded_deref(temp);\
	  switch(cell_tag(temp)) {\
	    case FREE: case REF1: case REF2: case REF3:\
              if (temp > ((Cell) TableStackBarrier) - 1) {\
                bld_ref((CPtr)temp,threg);\
                bld_free(threg);\
		threg++;\
                dpushtrail((CPtr) temp,*((CPtr) temp));\
              }\
              else {\
	        bld_ref(threg++,temp);\
              }\
	      break;\
	    case STRING: case INT: /*case FLOAT:*/ \
	      bld_copy(threg++, temp);\
	      break;\
	    case FLOAT:\
	      float_unification_exception(t_pcreg);\
	      break;\
	    case LIST:\
              if (clref_val(temp) < (CPtr) main_thread->maxsusp) \
                {bld_tablist(threg,(Cell)clref_val(temp)); threg++;}\
    	      else {\
                bld_list(threg,(Cell)threg1); threg++;\
	        threg1 += 2;\
	        pdlpush(cell(clref_val(temp)));\
	        pdlpush(cell(clref_val(temp) +1));\
	      }\
	      break;\
            case CS:\
              if (clref_val(temp) < (CPtr) main_thread->maxsusp) \
                {bld_tabstrct(threg, (Cell)clref_val(temp)); threg++;}\
    	      else {\
 	       bld_cs(threg,(Cell)threg1); threg++;\
	        pdlpush((temp | 8));\
      	        threg1 =threg1+1+get_arity((struct psc_rec *)follow(cs_val(temp)));\
  	        for (j=1; j <= get_arity((struct psc_rec *)follow(cs_val(temp))) ;\
	           j++) {\
  	          pdlpush(cell(clref_val(temp) +j));\
	        }\
	      }\
              break;\
	    case UnUsed2:\
	      bld_ref(threg++,cell(clref_val(temp)));\
	      break;\
	  }\
	  }\
          resetpdl

#define recvariant(flag,t_pcreg)\
	while (!pdlempty && flag) {\
	if (subinstprofile) \
	  subinst_table[RECVARIANT][1] = subinst_table[RECVARIANT][1] + 1; \
	  xtemp2 = (CPtr) pdlpop;\
	  xtemp1 = (CPtr) pdlpop;\
	  scaffolded_cptr_deref(xtemp1);\
	  scaffolded_cptr_deref(xtemp2);\
	  switch(cell_tag(xtemp1)) {\
	    case FREE: case REF1: case REF2: case REF3: \
	      if (isref(cell_tag(xtemp2))) {\
		dbind_ref(xtemp2,makeunused2(ctr));\
		dbind_ref(xtemp1,makeunused2(ctr));\
		  ctr++;\
	      }\
	      else {\
		flag = 0;\
		}\
	      break;\
	    case STRING: case INT: case UnUsed2:\
	      if (xtemp2 != xtemp1) flag = 0;\
	      break;\
	    case LIST:\
	      if (islist(xtemp2)) {\
	        pdlpush( cell(clref_val(xtemp1)+1) );\
                pdlpush( cell(clref_val(xtemp2)+1) );\
	        pdlpush( cell(clref_val(xtemp1)) );\
	        pdlpush( cell(clref_val(xtemp2)) );\
	      }\
	      else flag = 0;\
	      break;\
	    case TABLIST:\
	      if (islist(xtemp2)) {\
		if (clref_val(xtemp1) != clref_val(xtemp2)) {\
	          pdlpush( cell(clref_val(xtemp1)+1) );\
                  pdlpush( cell(clref_val(xtemp2)+1) );\
  	          pdlpush( cell(clref_val(xtemp1)) );\
	          pdlpush( cell(clref_val(xtemp2)) );\
	        }\
	      }\
	      else flag = 0;\
	      break;\
	    case TABSTRCT:\
	      if ( clref_val(xtemp1) != clref_val(xtemp2) ) {\
 	        if ( isconstr(xtemp2) && \
		    follow(cs_val(xtemp1)) == follow(cs_val(xtemp2)) ) {\
		  for(j=get_arity((struct psc_rec *)follow(cs_val(xtemp1)));\
		        j>=1 ; j--) {\
  	            pdlpush(cell(clref_val(xtemp1) +j));\
  	            pdlpush(cell(clref_val(xtemp2) +j));\
		  }\
		}\
	      else flag = 0;\
	      } \
	      break;\
	    case CS:\
	      if ( isconstr(xtemp2) && \
		  follow(cs_val(xtemp1)) == follow(cs_val(xtemp2)) ) {\
		for(j=get_arity((struct psc_rec *)follow(cs_val(xtemp1)));\
		        j>=1 ; j--) {\
  	           pdlpush(cell(clref_val(xtemp1) +j));\
  	           pdlpush(cell(clref_val(xtemp2) +j));\
		}\
	      }\
	      else flag = 0;\
	      break;\
	    case FLOAT: \
	      float_unification_exception(t_pcreg);\
/*	      if (floval(xtemp1) != floval(xtemp2)) flag = 0;*/ \
	      break;\
	  }\
	  }\
        resetpdl

#define heap_queue_structcpy(pdlreg1,temp,hreg1,t_pcreg)\
  while ( pdlreg1 > pdlreg) {\
  if (subinstprofile) \
      subinst_table[HQS][1] = subinst_table[HQS][1] + 1; \
  temp = (CPtr) *(pdlreg1--);\
  scaffolded_cptr_deref(temp);\
  switch(cell_tag(temp)) {\
    case FREE: case REF1: case REF2: case REF3:\
      if (temp >= TableStackBarrier - 1) {\
        bind_copy(hreg,(*temp)); hreg++;\
        }\
      else {\
        tabpushtrail0(temp,*temp);\
	pushtrail(hreg,hreg);\
	bld_free(hreg);\
        bld_ref(temp, hreg++);\
      }\
	break;\
    case STRING: case INT: /*case FLOAT:*/ \
      bind_copy(hreg,(Cell) temp); hreg++;\
      break;\
    case FLOAT:\
      float_unification_exception(t_pcreg);\
      break;\
    case LIST:\
      bind_list(hreg,hreg1); hreg++;\
      hreg1 += 2;\
      pdlpush(cell(clref_val(temp)));\
      pdlpush(cell(clref_val(temp) +1));\
      break;\
    case TABLIST:\
      bind_list(hreg,clref_val(temp)); hreg++;\
      break;\
    case CS:\
      if ( hreg == hreg1) \
      bind_cs(hreg,hreg1); hreg++;\
      pdlpush(((Cell) temp | 8));\
      hreg1 =hreg1+1+get_arity((struct psc_rec *)follow(cs_val(temp)));\
      for (j=1; \
           j <= get_arity((struct psc_rec*)follow(cs_val(temp))) \
           ; j++) {\
         pdlpush(cell(clref_val(temp) +j));\
	 }\
      break;\
    case TABSTRCT:\
      bind_cs(hreg,clref_val(temp)); hreg++;\
      break;\
    case UnUsed2:\
      bind_ref(hreg,cell(clref_val(temp))); hreg++;\
      break;\
    }\
    }


#define quick_tabcopy(temp)\
        pdlreg1 = ((CPtr) main_thread->pdl) -1;\
	while ( pdlreg1 > pdlreg) {\
	  temp = *(pdlreg1--);\
	  scaffolded_deref(temp);\
	  switch(cell_tag(temp)) {\
	    case STRING: case INT: /*case FLOAT:*/ \
	      bld_copy(threg++,temp);\
	      break;\
/*	    case FLOAT:\
	      float_unification_exception(t_pcreg);\
	      break;*/ \
	    case LIST:\
              bld_list(threg,(Cell)threg1); threg++;\
	      threg1 += 2;\
	      pdlpush(cell(clref_val(temp)));\
	      pdlpush(cell(clref_val(temp) +1));\
	      break;\
            case CS:\
 	      bld_cs(threg,(Cell)threg1); threg++;\
	      pdlpush((temp | 8));\
      	      threg1 =threg1+1+get_arity((struct psc_rec *)follow(cs_val(temp)));\
	      for (j=1; j <= get_arity((struct psc_rec *)follow(cs_val(temp)));\
	           j++) {\
  	        pdlpush(cell(clref_val(temp) +j));\
	      }\
              break;\
	    case UnUsed2:\
/*	      *threg++ = cell(clref_val(temp));*/ \
	      bld_ref(threg++,cell(clref_val(temp)));\
	      break;\
	  }\
	  }\
          resetpdl

#define remove_open_tables_loop(Endpoint) \
{ \
  CPtr osptr; \
  CPtr tip_ptr, curcall, init_addr, result, last_call, base_addr; \
  int i,j, flag, size; \
  register CPtr xtemp1,xtemp2; \
 \
  while (openreg < Endpoint) { \
    osptr = openreg+1; \
    tip_ptr = ots_susp_ptr(osptr); \
    base_addr = tip_ptr + 2; \
    init_addr = tip_ptr - 4; \
    tip_ptr = (CPtr) *(tip_ptr -1); \
    curcall = get_tab_entry(tip_ptr);    \
    size = get_chs(tip_ptr); \
    result = (CPtr) xcepthash(init_addr,size,xtemp1,xtemp2); \
    curcall = curcall - (int) result; \
    flag = 0; \
    while (curcall != 0 && !flag) { \
      last_call = curcall; \
      curcall = (CPtr) (*curcall);   \
      if (curcall == base_addr) {  \
	flag = 1; \
	*last_call = *curcall; \
      } \
    } \
    if (!flag) { \
      printf("curcall %x last_call %x\n",curcall,last_call); \
      flags[PIL_TRACE] = 1; \
    } \
  openreg = openreg + OTFRAMESIZE; \
  }\
  }

#define cut_restore_trail_condition_registers(temp) \
      if ((CPtr) * temp >= (CPtr) pspace || \
	   *temp == (Cell) &use_table_inst || \
	   *temp == (Cell) &new_lookup_inst ) { \
	ebreg = cp_ebreg(temp); \
	hbreg = cp_hreg(temp); \
        unwind_trail(temp,xtemp1, xtemp2); \
	} \
      else if (*temp == (Cell) &return_completion_inst || \
	       *temp == (Cell) &return_solution_inst) { \
	ebreg = cp_ebreg(temp); \
	hbreg = cp_hreg(temp); \
       }

#define unwind_trail(tbreg,temp_trreg,free) \
  if ( trreg > cp_trreg(tbreg) && cp_trreg(tbreg) >= trfreg) {\
    temp_trreg = (CPtr) trreg; \
    trreg = cp_trreg(tbreg); \
    free = (CPtr) trreg+3; \
    while ( (CPtr) trreg < temp_trreg ) { \
      trreg +=3; \
      if ( (*(trreg-2) <= hbreg || *(trreg-2) >= ebreg\
	     || *(trreg-2) <= hfreg || *(trreg-2) >= efreg)) { \
/*      if ( *(trreg-2) <= hbreg || *(trreg-2) >= ebreg) { */\
	if (free != (CPtr) trreg) { \
	  *(free) = (Cell) (free-3); \
	  *(free-1) = (Cell) *(trreg - 1); \
	  *(free-2) = (Cell) *(trreg-2); \
	} \
	free +=3;\
        num_unwinds++;\
      } \
    } \
    trreg = (CPtr *) free-3; \
    } \
  else if (cp_trreg(tbreg) < trfreg) { \
    if (cp_trreg(tbreg) > trreg) { \
/*!!!*/ \
	 printf("unwnd 1. cp_tr %x, temptr %x\n",cp_trreg(tbreg),temp_trreg);\
	 flags[PIL_TRACE] = 1; \
    }\
    while (trreg >= trfreg && \
	        trreg != (CPtr *) main_thread->trail &&\
         !(*(trreg-2) <= hbreg || *(trreg-2) >= ebreg\
	     || *(trreg-2) <= hfreg || *(trreg-2) >= efreg)) { \
         trreg = (CPtr *) * trreg; \
      }\
    temp_trreg = (CPtr) trreg;\
    while (temp_trreg >= (CPtr) trfreg && \
	        temp_trreg != (CPtr) main_thread->trail){\
      if ( !((CPtr) *(temp_trreg-2) <= hbreg \
	     || (CPtr) *(temp_trreg-2) >= ebreg\
	     || (CPtr) *(temp_trreg-2) <= hfreg \
	     || (CPtr) *(temp_trreg-2) >= efreg)) { \
        *(temp_trreg -1)	= *(temp_trreg-2);  \
/*	 printf("unwnd 1. trail %x addr %x\n",temp_trreg,*(temp_trreg-1));*/\
      }\
       temp_trreg = * (CPtr *) temp_trreg; \
    }\
  }





