/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File                  :  emudef.h
  Author(s)		:  David S. Warren, Terrance Swift, Jiyang Xu
			   Kostis F. Sagonas
  Last modification	:  July 1993
======================================================================*/

shapri word *pspace;	/* psc records, instructions, p-names */
CellStr reg[maxregs];	/* registers */

shapri byte *inst_begin;	/* ptr to the beginning of inst. array */ 

 CPtr ereg;		/* last activation record       */
 CPtr breg;		/* last choice point            */
 CPtr hreg;		/* top of heap                  */
 CPtr *trreg;		/* top of trail stack           */
 CPtr hbreg;		/* heap back track point        */
 CPtr sreg;		/* current build or unify field */
 byte *cpreg;		/* return point register        */
 byte *pcreg;		/* program counter              */
 CPtr ebreg;		/* breg into environment stack	*/
 int  dreg;		/* deep backtracking flag	*/

#ifdef XWAM 
CPtr efreg;
CPtr bfreg;
CPtr hfreg;
CPtr *trfreg;
CPtr tabreg;
CPtr pdlreg;
CPtr threg;
CPtr *tabtrreg;
CPtr openreg;
CPtr root_address;
#else
#endif

shapri byte disassem = 0;
#ifdef MEASURE
shared byte call_intercept=1;	/* hitrace or trace_sta for efficiency */
#else
shared byte call_intercept=0;	/* hitrace or trace_sta for efficiency */
#endif

shapri Pair nil_sym, list_str;

shapri Psc list_psc;
shapri Psc comma_psc;

shapri int asynint_val = 0;
int *asynint_ptr = &asynint_val;

shared int exitcode = 0;

int wid;

