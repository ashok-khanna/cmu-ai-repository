/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File                  :  binding.h
  Author(s)		:  Jiyang Xu, Terrance Swift
  Last modification	:  April, 1993
======================================================================*/

/* binding.h */

/* --- trailing --------------------------------------------------------*/

#define NM_TRTAG  0x00000000
#define VL_TRTAG  0x80000000
#define BA_TRTAG  0x80000001
#define TR_MSK    0x7ffffffc

/* change tls */
/* *(trreg++) = (CPtr) trfreg;*/
/* CPtr, Cell */

#define pushtrail0(addr,val)  \
   if ( trfreg > trreg) {\
     *(trfreg+3) = (CPtr) trreg;\
     trreg = trfreg + 3;\
     *(trreg-1) = (CPtr) val;\
     *(trreg-2) = addr;\
     }\
   else {\
     trreg = trreg+3;\
     *trreg = (CPtr) trreg-3;\
     *(trreg-1) = (CPtr) val;\
     *(trreg-2) = addr;\
     }

#define tabpushtrail0(addr,val)  \
     tabtrreg = tabtrreg+3;\
     *tabtrreg = (CPtr) tabtrreg-3;\
     *(tabtrreg-1) = (CPtr) val;\
     *(tabtrreg-2) = addr;\

/* should not be needed when functions are taken out 
/*define pushtrailv0(val) 
  quit("Error: using value trail for fns in XWAM mode") */
#define pushtrailb0(val) quit("Error: using binding array in SW mode")

/*define conditional(a) ((a) >= ebreg || (a) <= hbreg)*/

#define  conditional(a) ( ((a) >= ebreg || (a) >= efreg) || \
			   ((a) <= hbreg || (a) <= hfreg) )

#define pushtrail(a,v)  if (conditional(a)) pushtrail0(a,v)
#define dpushtrail(a,v) pushtrail0(a,v)\

/* non-xwam
#define pushtrail(a)  if (conditional(a)) pushtrail0(a)
#define pushtrailv(a) if (conditional(a)) pushtrailv0(a)
#define pushtrailb(a) if (conditional(a)) pushtrailb0(a)
*/

#define efreg_on_top(t_ereg) efreg < ebreg  && efreg < t_ereg

/* --- binding -------------------------------------------------------*/

/* note: bind_ref for double word mode has a redundant tag-set operation */
/* but due to we are not interested too much in double word version, I */
/* trade the efficiency (slightly) with modularity.			*/
/*d efine bind_int(addr, val)  pushtrail(addr,val); \
                             *(addr) = ((val) << 4) | INT */

/* no bind_domain */
#define bind_int(addr, val)  pushtrail(addr,makeint(val));\
	  bld_int(addr, val)

#define bind_float(addr, val)  pushtrail(addr,(Cell) makefloat(val)); \
                               bld_float(addr, val)

#define bind_ref(addr, val)  pushtrail(addr,val);\
	bld_ref(addr, val)

#define dbind_ref(addr, val)  dpushtrail(addr,val);\
        bld_ref(addr, val)

#define bind_cs(addr, str) \
  pushtrail(addr, makecs(str));\
  bld_cs(addr, str)

#define bind_string(addr, str)  pushtrail(addr,makestring(str));\
				bld_string(addr,str)

#define bind_list(addr, list)  pushtrail(addr,makelist(list));\
                               bld_list(addr, list)

#define bind_copy0(addr, val)  pushtrail(addr,val); *(addr) = val

#define bind_copy(addr, val)  pushtrail(addr,val); *(addr) = val

/* value trail MUST be used because first CP cell has cp_trreg = 0 !!!!
   doc tls */
/*#define VALUETRAIL*/
#ifdef VALUETRAIL
#define untrail(addr) if ((int)(addr)>0) {bld_free(addr);} \
		else {*((CPtr)((word)(addr)&TR_MSK)) = *(--(CPtr)(trreg));\
                printf("zero value called\n");}
#else
#define untrail(addr) bld_free(addr)
#endif

/* --- destructive assignment ---------------------------------- */

#define assign_value(addr, value) { pushtrailv(addr); *(int *)(addr) = value; }

/* --- testing location of variable --------------------------- */

#define ereg_on_top(t_ereg) t_ereg < ebreg
