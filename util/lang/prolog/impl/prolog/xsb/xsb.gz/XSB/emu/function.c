/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File			:  function.c
  Author(s)		:  Jiyang Xu
  Modified by		:  Jiyang Xu
  Last modification	:  August 13, 1990
========================================================================*/


#include <math.h>
#include "config_make.h"
#include "aux.h"
#include "cell.h"
#include "register.h"
#include "memory.h"
#include "deref.h"

#define FUN_PLUS   1
#define FUN_MINUS  2
#define FUN_TIMES  3
#define FUN_DIVIDE 4
#define FUN_AND    5
#define FUN_OR     6
#define FUN_sin    9
#define FUN_cos   10
#define FUN_tan   11

#define FUN_float 13
#define FUN_floor 14
#define FUN_exp   15
#define FUN_log   16
#define FUN_log10 17
#define FUN_sqrt  18
#define FUN_asin  19
#define FUN_acos  20
#define FUN_atan  21

/* return 1 when succeeds, and return 0 when there is an error */

unifunc_call(funcnum, regaddr)
CPtr regaddr;
{
  Cell value;
  float fvalue; 
  int ivalue;

  value = cell(regaddr);
  deref(value);
  switch (funcnum) {
      case FUN_float:
	  if (isinteger(value)) fvalue = int_val(value);
	  else if (isfloat(value)) fvalue = float_val(value);
	  else return 0;
	  bld_float(regaddr, fvalue);
	  break;
      case FUN_floor:
	  if (isinteger(value)) fvalue = int_val(value);
	  else if (isfloat(value)) fvalue = float_val(value);
	  else return 0;
	  bld_float(regaddr, floor(fvalue));
	  break;
      case FUN_PLUS:
      case FUN_MINUS:
      case FUN_TIMES:
      case FUN_DIVIDE:
      case FUN_AND:
      case FUN_OR:
	  return 0;		/* should not come here */
	  break;
      case FUN_sin:
	  if (isinteger(value)) fvalue = int_val(value);
	  else if (isfloat(value)) fvalue = float_val(value);
	  else return 0;
	  bld_float(regaddr, sin(fvalue));
	  break;
      case FUN_cos:
	  if (isinteger(value)) fvalue = int_val(value);
	  else if (isfloat(value)) fvalue = float_val(value);
	  else return 0;
	  bld_float(regaddr, cos(fvalue));
	  break;
      case FUN_tan:
	  if (isinteger(value)) fvalue = int_val(value);
	  else if (isfloat(value)) fvalue = float_val(value);
	  else return 0;
	  bld_float(regaddr, tan(fvalue));
	  break;
      case FUN_exp:
	  if (isinteger(value)) fvalue = int_val(value);
	  else if (isfloat(value)) fvalue = float_val(value);
	  else return 0;
	  bld_float(regaddr, exp(fvalue));
	  break;
      case FUN_log:
	  if (isinteger(value)) fvalue = int_val(value);
	  else if (isfloat(value)) fvalue = float_val(value);
	  else return 0;
	  bld_float(regaddr, log(fvalue));
	  break;
      case FUN_log10:
	  if (isinteger(value)) fvalue = int_val(value);
	  else if (isfloat(value)) fvalue = float_val(value);
	  else return 0;
	  bld_float(regaddr, log10(fvalue));
	  break;
      case FUN_sqrt:
	  if (isinteger(value)) fvalue = int_val(value);
	  else if (isfloat(value)) fvalue = float_val(value);
	  else return 0;
	  bld_float(regaddr, sqrt(fvalue));
	  break;
      case FUN_asin:
	  if (isinteger(value)) fvalue = int_val(value);
	  else if (isfloat(value)) fvalue = float_val(value);
	  else return 0;
	  bld_float(regaddr, asin(fvalue));
	  break;
      case FUN_acos:
	  if (isinteger(value)) fvalue = int_val(value);
	  else if (isfloat(value)) fvalue = float_val(value);
	  else return 0;
	  bld_float(regaddr, asin(fvalue));
	  break;
      case FUN_atan:
	  if (isinteger(value)) fvalue = int_val(value);
	  else if (isfloat(value)) fvalue = float_val(value);
	  else return 0;
	  bld_float(regaddr, atan(fvalue));
	  break;
      default:  return 0;
		break;
  }
  return 1;
}
