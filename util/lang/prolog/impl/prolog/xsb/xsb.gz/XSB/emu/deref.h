/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File                  :  deref.h
  Author(s)		:   Xu,  Swift, Sagonas
  Last modification	:  July, 1993
========================================================================*/


#ifdef MEASURE2
#define inc_d_count() tds[m_myid].deref_count++
#else
#define inc_d_count()
#endif

/* deref expects argument of type Cell */
#define deref(op) while (isref(op)) { \
		if (op == follow(op)) break; op = follow(op); }

#define cptr_deref(op) while (isref(op)) { \
		if (op == (CPtr) cell(op)) break; op = (CPtr) cell(op); }

#define DEREF(op, labl) \
	labl: switch (cell_tag(op)) { \
	    case FREE: case REF1: case REF2: case REF3: \
		if (op != follow(op)) {op = follow(op); goto labl;}

#define IFTHENELSE_DEREF(op, labl) \
	labl: if (isref(op)) { \
		if (op != follow(op)) {op = follow(op); goto labl;}

/* parallel removed -- tls */

#define DREND }

