/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File			:  init.c
  Author(s)		:  Warren, Swift, Xu, Sagonas
  Last modification	:  April 1993
========================================================================*/

#include <stdio.h>
#include "config_make.h"
#include "aux.h"
#include "cell.h"
#include "inst.h"
#include "psc.h"
#include "memory.h"
#include "register.h"
#include "choice.h"
#include "flags.h"
#include "loader.h"
#include "xmacro.h"

int pspacesize = 1;	/*  384 K, dynamically expanded (was 256) */
int memsize = 768;	/*  768 K, for local/global stacks */
/*  int tcsize = 256;	  256 K, for trail/cp stacks -- non-tabled setting*/
int tcsize = 768;	/*  768 K, for trail/cp stacks (was 256) */

#ifdef XWAM
int maxsuspsize = 512;
int pdlsize = 64;
int maxopentablesize = 64;
#endif

extern int xwammode;
extern int level_num;

/* Not needed for sequential */
int pp_memsize = 96;	/*  128 Kbytes for per-PE memory */
int pp_tcsize = 32;

byte version_major = 1;
	 /* the major version number; this line can be modified by sed	*/
byte version_minor = 3;
	 /* the minor version number; this line can be modified by sed	*/

char *install_dir, *make_date, *user_home;

/* real_alloc uses malloc only to keep pspacesize straight. */
#define real_alloc(X) malloc(X) 

static struct mem_str main_thread_str;
struct mem_str *main_thread;
struct mem_str *cur_thread;

byte new_lookup_inst = new_lookup;
byte return_solution_inst = return_solution;
byte return_completion_inst = return_completion;
byte check_complete_inst = check_complete;
byte error_instruction_1_inst = error_instruction_1;
byte use_table_inst = use_table;
byte fail_inst = fail;
byte halt_inst = halt;
/* byte suspend_inst = suspend;
byte terminate_inst = terminate;	used for parallel child processes */
byte proceed_inst = proceed;         /* returned by load_obj */

int is_interpreter = 0;

private extern double realtime_count;
extern double real_time();
extern pw reloc_table[];

/* Version message */

 char *debug_mode[3] = {
  "optimal mode",
  "debug mode",
  "profile mode"
  };

 char *word_mode[3] = {
  "single word",
  "one & half word",
  "double word"
  };

 char *par_mode[3] = {
  "sequential",
  "parallel"
  };

 char interp_loadfile[128];

/****************************************************************************/

char *init_para(argc, argv)
int argc;
char *argv[];
{
   int i;
   char *charp, *input_file = 0, c;
#ifdef AMIGA
   static char *Amiga_home = "XSB:";
#endif

#ifdef DEBUG
   flags[VERSION_MODE] = 2;
#else
#ifdef PROFILE
   flags[VERSION_MODE] = 3;
#else
   flags[VERSION_MODE] = 1;
#endif
#endif

#ifdef SW
   flags[VERSION_WORD] = 1;
#else
#ifdef HW
   flags[VERSION_WORD] = 2;
#else
   flags[VERSION_WORD] = 3;
#endif
#endif

#ifdef SEQUENTIAL
   flags[VERSION_PARA] = 1;
#else
   flags[VERSION_PARA] = 2;
#endif

#if defined(SUN)
   flags[MACHINE] =  1;
#elif defined(SOLARIS)
   flags[MACHINE] =  2;
#elif defined(NeXT)
   flags[MACHINE] =  3;
#elif defined(linux)
   flags[MACHINE] =  4;
#elif defined(SGI)
   flags[MACHINE] =  5;
#elif defined(HP300)
   flags[MACHINE] =  6;
#elif defined(DECstation)
   flags[MACHINE] =  7;
#elif defined(AMIGA)
   flags[MACHINE] =  8;
#elif defined(IBM)
   flags[MACHINE] =  9;
#elif defined(SEQUENT)
   flags[MACHINE] = 10;
#endif

   flags[VERSION_DATE] = DATE;
   install_dir = DIR;
   flags[INSTALL_DIR] = (int)(install_dir);

#ifdef AMIGA
   if ((char *)getenv("HOME")==NULL) user_home = Amiga_home;
   else {
       user_home = (char *)malloc(strlen((char *)getenv("HOME"))+1);
       strcpy(user_home, (char *)getenv("HOME"));
   }
#else
/* In the following I make a copy of the user's home directory because on the
   Sparc the getenv("HOME") returns a very high address that cannot be accessed
   with the single word Prolog representation. */
   user_home = (char *)malloc(strlen((char *)getenv("HOME"))+1); 
   strcpy(user_home, (char *)getenv("HOME"));
#endif
   flags[USER_HOME] = (int)(user_home);

/* reset these parameters from the command line options */
   if (argc == 1) version_message();		/* exit the program */
   for (i=1; i<argc; i++) {
        if (*argv[i] != '-') {
		if (!input_file) input_file = argv[i];
		continue;
	}
        charp = argv[i];
        while (c = *++charp) switch(c) {
	    case 'u': i++;
#ifdef XWAM
	      sscanf(argv[i], "%d", &pdlsize);
#else
              printf("-u option unavailable for this executable (NON-XWAM)\n");
#endif
	      break;
	    case 'p': i++;
#ifdef XWAM
              printf("-p option unavailable for this executable (XWAM)\n");
#else
	      sscanf(argv[i], "%d", &pspacesize);
#endif
	      break;
	    case 'm': i++;
	      sscanf(argv[i], "%d", &memsize);
	      break;
	    case 'c': i++;
	      sscanf(argv[i], "%d", &tcsize);
	      break;
	    case 'o': i++;
#ifdef XWAM
	      sscanf(argv[i], "%d", &maxopentablesize);
#else
              printf("-o option unavailable for this executable (NON-XWAM)\n");
#endif
	      break;
	    case 'x': i++;
#ifdef XWAM
	      sscanf(argv[i], "%d", &maxsuspsize);
#else
              printf("-x option unavailable for this executable (NON-XWAM)\n");
#endif
	      break;
	    case 'D': i++;
	      install_dir = argv[i];
	      flags[INSTALL_DIR] = (int)(install_dir);
	      break;
	    case 's': flags[TRACE_STA] = call_intercept = 1;
	      break;
	    case 'd': disassem = 1;
	      break;
	    case 'T': 
#ifdef TRACING
	      flags[HITRACE] = call_intercept = 1; 
	      flags[CALL_STEP] = 1;
#else
              quit("-T option unavailable for this executable (non-tracing mode)");
#endif
	      break;
	    case 't': 
#ifdef DEBUG
	      flags[PIL_TRACE] = flags[HITRACE] = call_intercept = 1;
#else
              quit("-t option unavailable for this executable (non-debug mode)");
#endif
	      break;
	    case 'i':
	      is_interpreter = 1;
	      break;
	    default: printf("Unknown option %c\n", c);
          } /* while and switch */
   } /* for */
   if (is_interpreter) {
       sprintf(interp_loadfile, "%s/syslib/loader.O", install_dir);
       input_file = interp_loadfile;
   } else if (!input_file) version_message();		/* exit the program */
   return input_file;
}

init_machine()
{
	int i;
	byte *memory;

/* allocate spaces */
	pspace = (pw) (real_alloc(pspacesize*1024));
	if (!pspace) quit0("Not enough core for pspace!\n");
	memory = (byte *) 
	  (real_alloc((memsize+tcsize+pdlsize+maxsuspsize+
		               maxopentablesize)*1024));
	if (!memory) quit0("Not enough core for stacks!\n");
/* set boundary parameters */
	main_thread = &main_thread_str;
	cur_thread = main_thread;	/* for consistency w. parallel mode */
	main_thread->memory = memory;
	main_thread->pdl = memory + pdlsize*1024;
	main_thread->maxsusp = memory + (pdlsize+maxsuspsize)*1024;
	main_thread->lstack = memory + (memsize+pdlsize+maxsuspsize)*1024;
	main_thread->trail =  memory + (memsize+pdlsize+maxsuspsize)*1024;
	main_thread->opentable = memory + 
	                           (memsize+tcsize+pdlsize+maxsuspsize)*1024;
	main_thread->memend 
	  = memory + (memsize+tcsize+pdlsize+maxsuspsize
		      +maxopentablesize)*1024;
/* main_thread-> memory
   tptrs   |
           \/
           /\
   pdl     |
   main_thread-> pdl
   threg |
          \/
          /\
   tabreg  |
   main_thread-> maxsusp
   hreg |
        \/
        /\
   ereg |
   main_thread->lstack main_thread->trail
   trreg |
        \/
        /\
   breg |
   main_thread->opentable
   tabtrreg  |
            \/
            /\
   opentab  |
   main_thread-> memend */
	threg = (CPtr) (main_thread->pdl);
	tabreg = (CPtr) (main_thread->maxsusp) -1;
	pdlreg = (CPtr) (main_thread->pdl) - 1;
	hbreg = hreg = (CPtr)(main_thread->maxsusp);
	tabtrreg = (CPtr *) (main_thread->opentable) + 1;
	trfreg = trreg = (CPtr *)(main_thread->trail);
	*(trreg) = (CPtr) trreg;
	breg = (CPtr)(main_thread->opentable - sizeof(struct choice_point) );
	ebreg = (CPtr)(main_thread->lstack);
	openreg = (CPtr) (main_thread->memend) -1; 
	ereg = ebreg - 1; 
	reset_freeze_registers;
	openreg = (CPtr) (main_thread->memend) -1; 
/* set halt instruction, and let the last failure/sucess to the halt */
	cpreg = &halt_inst;		/* halt on final success */
	*(ereg-1) = (Cell) cpreg;
	cp_pcreg(breg) = &halt_inst; 	/* halt on last failure */
	cp_hreg(breg) = hreg;		/* need for cut.  */
	cp_trreg(breg) = trreg;		/* need for cut.  */
	cp_prevlookup(breg) = 	        /* need for cut.  */
	  (CPtr)(main_thread->opentable - sizeof(struct choice_point) );
	cp_ebreg(breg) = ebreg;		/* need for cut.  */
/* other basic initializations */
#ifndef XWAM
	init_pspace();
#endif
	realtime_count = real_time();
	inst_begin = 0;
	for (i=0;i<MAXBUCKET;i++) hash_table[i] = 0;
/*	printf("ut %x nl %x cc %x rs %x rc %x err %x f %x h %x\n",
	       &use_table_inst, &new_lookup_inst, &check_complete_inst,
	       &return_solution_inst, &return_completion_inst,
	       &error_instruction_1_inst,&fail_inst, &halt_inst);
*/
}

init_flags()
{
    int i;

    for (i=0; i<64; i++) flags[i] = 0;
    flags[RELOC_TABLE] = (int)reloc_table;
    flags[HASH_TABLE] = (int)hash_table;
/*    flags[CURRENT_OUTPUT] = 1; */
    flags[VERSION_PROCR] = 1;
    flags[VERSION_MAJOR] = version_major;
    flags[VERSION_MINOR] = version_minor;
#ifdef MEASURE
    flags[TRACE_STA] = 1;
#endif
}

init_symbols()
{
	Pair temp, tp;
	int new;

/* insert mod name global */
	tp = (Pair)insert_module(T_MODU, "global");	/* loaded */
	get_ep(pair_psc(tp)) = (byte *)1;	/* 1 stands for global mod */
	global_mod = pair_psc(tp);
/* insert "[]" into global list */
	nil_sym = (Pair)insert("[]", 0, global_mod, &new);
/* insert  "." into global list */
	temp = (Pair)insert(".", 2, global_mod, &new);
	list_str = temp;
	list_psc = temp->psc_ptr;
/* insert symbol ","/2 */
	temp = (Pair)insert(",", 2, global_mod, &new);
	comma_psc = temp->psc_ptr;
/* make another reference to global module -- "usermod */
	tp = (Pair)insert_module(T_MODU, "usermod");		/* loaded */
	get_ep(pair_psc(tp)) = get_ep(global_mod);
}  /* init_sym */

version_message()
{
  printf("XSB (Beta) Version %d.%d, %s, %s, %s (%d/%d/%d)\n", 
	 flags[VERSION_MAJOR], flags[VERSION_MINOR],
	 word_mode[flags[VERSION_WORD]-1],  par_mode[flags[VERSION_PARA]-1],
	 debug_mode[flags[VERSION_MODE]-1], flags[VERSION_DATE]>>16, 
	 (flags[VERSION_DATE]>>8)&0xff, flags[VERSION_DATE]&0xff);
  printf("Usage: %s [-c tcsize] [-m memsize] [-o otabsize] [-u pdlsize]\n",
	      EXECUTABLE);
  printf("           [-x tabsize] [-D path] [-s] [-d] ");
#ifdef TRACING
  printf("[-T] ");
#endif
#ifdef DEBUG
  printf("[-t] ");
#endif
  printf(" -i | byte_code_file\n");
  printf("       -i : brings up the XSB interpreter\n");
  printf("     -c # : allocates # KBytes for the trail/choice-point stack\n");
  printf("     -m # : allocates # KBytes for the local/global stack\n");
  printf("     -o # : allocates # KBytes for the open table area\n");
  printf("     -u # : allocates # KBytes for the unification (table copy) stack\n");
  printf("     -x # : allocates # KBytes for the table area\n");
  printf("  -D path : specifies path as the installation directory of XSB\n");
  printf("       -s : maintains statistical information\n");
  printf("       -d : disassembles file byte_code_file\n");
#ifdef TRACING
  printf("       -T : prints a trace of each called predicate\n");
#endif
#ifdef DEBUG
  printf("       -t : traces code at the XWAM instruction level\n");
#endif
  exit(0);
}

