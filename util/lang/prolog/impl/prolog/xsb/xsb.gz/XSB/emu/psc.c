/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File                  :  psc.c
  Author(s)		:  Xu, Sagonas, Swift
  Last modification	:  April 1993
======================================================================*/

#include "config_make.h"
#include "aux.h"
#include "cell.h"
#include "psc.h"
#include "loader.h"
#include "flags.h"
#include "inst.h"
#include "hashindex.h"
#include "xmacro.h"

/* === string table =============================================*/

char *string_table[MAXBUCKET];

char *string_find(str, insert)
char *str;
{
  char **ptr, *str0, length;

  ptr = string_table + hash(str, 0, 0);
  while (*ptr) {
    str0 = *ptr + 4;
    if (strcmp(str, str0)==0) return str0;
    ptr = (char **)(*ptr);
  }
  if (insert) {
      str0 = (char *)mem_alloc(strlen(str)+5);
      *ptr = str0;
      *((int *)(str0)) = 0;
      str0 = str0 + sizeof(int_ptr);
      strcpy(str0, str);
      return str0;
  } else return 0;
}

static Psc make_psc_rec(name, arity)
char *name, arity;
{
	Psc temp;
	char *name_p, length;

	length = strlen(name);
	temp = (struct psc_rec *)mem_alloc(sizeof(struct psc_rec));
	set_env(temp, 0);
	set_type(temp, 0);
	set_spy(temp, 0);
	set_arity(temp, arity);
	set_length(temp, length);
/* 	set_tabptr(temp,0);*/
	set_ep(temp,0);
#ifdef CONASSTRING
	set_name(temp, string_find(name, 1));
#else
	name_p = (char *)mem_alloc(length+1); /* name string space */
	set_name(temp, name_p);
	while (*name) *name_p++ = *name++;
	*name_p = 0;
#endif
	return temp;
}  /* make_psc_rec */

static Pair make_psc_pair(psc_ptr, link_ptr)
Psc psc_ptr;
Pair *link_ptr;
{
	Pair new_pair;

	new_pair = (Pair)mem_alloc(sizeof(Pair));
	new_pair->psc_ptr = psc_ptr;	/* set 1st to point to psc_rec */
	new_pair->next = *link_ptr;	/* set 2nd to old head */
	*link_ptr = new_pair;		/* new symbol is in the head! */
	return new_pair;
}  /* make_psc_pair */


CPtr  get_comp_ep(temp) 
Psc temp;
{
byte * temp1;

  temp1 = get_ep(temp);
  if (temp1 != 0) {
    switch ((int) * temp1) {
      case tabletry:
      case tabletryfail:
        return (CPtr) (temp1 +12);
	break;
      case switchon3bound:
      case switchonbound:
      case switchonterm:
	if ( (int) (temp1 +12) == tabletry 
	    || (int) (temp1 +12) == tabletryfail) 
	  return (CPtr) (temp1 + 24);
	else return (CPtr) 0;
	break;
      default:
	return (CPtr) 0;
	break;
      }
  }
  else return 0;
}

tab_inf_ptr  get_tip(temp) 
Psc temp;
{
byte * temp1;
int type;

  type = get_type(temp);
  switch (type) {
  case T_DYNA:
  case T_PRED:
  temp1 = get_ep(temp);
  if (temp1 != 0) {
    switch ((int) * temp1) {
      case tabletry:
      case tabletryfail:
        return (tab_inf_ptr) *(CPtr) (temp1 +8);
	break;
      case switchon3bound:
      case switchonbound:
      case switchonterm:
	if ( (int) *(byte *) (temp1 +12) == tabletry 
	    || (int) *(byte *) (temp1 +12) == tabletryfail) 
	  return (tab_inf_ptr) *(CPtr) (temp1 + 20);
	else return (tab_inf_ptr) 0;
	break;
      default:
	return (tab_inf_ptr) 0;
	break;
      }
  }
  else return 0;
  default: 
	return (tab_inf_ptr) 0;
	break;
}
}

/*
CPtr get_call_ep(init_addr)
CPtr init_addr;
{
  int arity, chs, flag;
  Psc psc;
  tab_inf_ptr tip;
  CPtr temp, temp1, temp2, curcall;

  psc = get_str_psc(init_addr);
  arity = get_arity(psc);
  tip = get_tip(psc);
  if ( get_tab_entry(tip) == 0) return 0;
  tabhash((init_addr + 1),chs,temp,temp1,temp2); 
  curcall =  (CPtr) get_tab_entry(tip) - (unsigned) temp;
  traverse_call_bucket(&curcall,init_addr,arity,&flag);
  if (flag && ((int) *(call_str_susptr(curcall))  < 0)) 
    return curcall;
  else return 0;
}
*/

/* ==== search: search in a given chain ======================== */

Pair search(arity, name, search_ptr)
char *name, arity;
Pair *search_ptr;
{
	Psc psc_ptr;

	while (*search_ptr) {
		psc_ptr = (*search_ptr)->psc_ptr;
		if ( strcmp(name, get_name(psc_ptr)) == 0
		       && arity == get_arity(psc_ptr) )
		    return (*search_ptr);
		else search_ptr  = &((*search_ptr)->next);
	}
	return 0;
} /* search */


/*=== insert0: search/insert to a given chain ======================*/

Pair insert0(name, arity, search_ptr, new)
char *name, arity;
int *new;
Pair *search_ptr;
{
	Pair new_pair;

	new_pair = search(arity, name, search_ptr);
	if (!new_pair) {
	    *new = 1;
	    new_pair = make_psc_pair(make_psc_rec(name,arity), search_ptr);
	} else *new = 0;
	return new_pair;
} /* insert0 */

/*=== insert: search/insert to a given module ======================*/

Pair insert(name, arity, mod_psc, new)
char *name, arity;
int *new;
Psc mod_psc;
{
	Pair *search_ptr;

	if (is_globalmod(mod_psc)) 
		search_ptr = hash_table+hash(name, arity, 0);
	else search_ptr = (Pair *)&(get_ep(mod_psc));
	return insert0(name, arity, search_ptr, new);
} /* insert */


is_globalmod(mod_psc)
Psc mod_psc;
{
/* 
 * The modules considered global are the ones that have the value 1 in their
 * entry point field of the module's psc record.  The modules I know that 
 * have this property are the modules "global" and "usermod".
 */
  if (mod_psc) return (int)get_ep(mod_psc) == 1;
  else return 1;
}

/*=== insert: search/insert to a given module ======================*/

Pair insert_module(type, name)
char *name;
{
	Pair new_pair;
	int new;

	new_pair = insert0(name, 0, (Pair *)&flags[MOD_LIST], &new);
	if (new) {
	    get_type(new_pair->psc_ptr) = type;
	    get_ep(new_pair->psc_ptr) = 0;
	} else get_type(new_pair->psc_ptr) |= type;
		/* set loading bit: T_MODU - loaded; 0 - unloaded */
	return new_pair;
} /* insert_module */

/* make a psc pair in module mod_pair pointing to psc record sym_pair */
Pair link_sym(psc, mod_psc)
Psc psc, mod_psc;
{
	Pair *search_ptr, new_pair;
	char *name;
	int arity;

	name = get_name(psc);
	arity = get_arity(psc);
	if (is_globalmod(mod_psc)) 
	      search_ptr = hash_table+hash(name, arity, 0);
	else search_ptr = (struct psc_pair **)&(mod_psc->ep);
	if (new_pair = search(arity, name, search_ptr)) {
	  if (new_pair->psc_ptr != psc) {
	    if (get_type(new_pair->psc_ptr) != 0)
		/* invalidate the old name!! It is no longer accessible
		   through the global chain */
	      printf("++Warning: %s/%d (type %d) was defined in another module!\n",       
		name, arity, get_type(new_pair->psc_ptr));
	    new_pair->psc_ptr = psc;
	  }
	} else new_pair = make_psc_pair(psc, search_ptr);
	return new_pair;
} /* link_sym */

/* === hash ======================================================*/

hash(name, arity, size)  /* hashing function on name,returning a 
                        bucket number in the hash table       */
char *name;
{
      int bucknum, length;

      length = strlen(name);
      if (size==0) size = MAXBUCKET;
  
      bucknum = arity+1;
      if (length > 0) {   /* first */
          bucknum = bucknum + *name; 
          if (length > 1) {   /* last */
              bucknum = (bucknum << 2) + *(name+length-1);
              if (length > 2) {   /* middle */
                  bucknum = (bucknum << 2) + *(name+length/2);
                  if (length > 3) 
                      bucknum = (bucknum << 2) + *(name+(length/2)-1);
              }
          }
      }
      return abs(bucknum % size);
}  /* hash */

