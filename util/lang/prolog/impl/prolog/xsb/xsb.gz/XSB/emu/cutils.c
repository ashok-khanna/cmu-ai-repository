/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File                  :  cutils.c
  Author(s)		:  Terrance Swift
  Last modification	:  August, 1993
======================================================================*/

#include <stdio.h>
#include "config_make.h"
#include "aux.h"
#include "cell.h"
#include "register.h"
#include "binding.h"
#include "memory.h"
#include "choice.h"
#include "deref.h"
#include "psc.h"
#include "flags.h"
#include "xmacro.h"

extern CPtr xtemp3, xtemp12;
extern int macroprint, macroprint1;

#define rec_heap_copyarg(temp,to)\
  while ( pdlreg1 > pdlreg) {\
    temp = (CPtr) *(pdlreg1--);\
  if (macroprint1) printf("hqs1 temp: %x \n",temp);\
  scaffolded_cptr_deref(temp);\
  if (macroprint1) printf("hqs1 temp: %x \n",temp);\
  switch(cell_tag(temp)) {\
    case FREE: case REF1: case REF2: case REF3:\
      if (temp > barrier) {\
        if (macroprint1) printf("hqs trailed binding: tptr %x\n",temp);\
        bind_copy(hreg,(*temp)); hreg++;\
        }\
      else {\
        if (macroprint1) printf("hqs tabtrailed binding: tptr %x\n",temp);\
        tabpushtrail0(temp,*temp);\
	pushtrail(hreg,hreg);\
	bld_free(hreg);\
        *(temp) = (Cell) hreg++;\
      }\
      break;\
    case STRING: case INT: \
      bld_copy(hreg,(Cell) temp); hreg++;\
      break;\
/*    case FLOAT:\
      float_unification_exception(t_pcreg);\
      break;*/ \
    case LIST:\
      bld_list(hreg,hreg1); hreg++;\
      hreg1 += 2;\
      pdlpush(cell(clref_val(temp)));\
      pdlpush(cell(clref_val(temp) +1));\
      break;\
    case TABLIST:\
      bld_list(hreg,clref_val(temp)); hreg++;\
      break;\
    case CS:\
      if ( hreg == hreg1) \
	if (macroprint1) printf("hqs CS eq %x hreg %x hreg1 %x \n",*(pdlreg+1),hreg,hreg1);\
      bld_cs(hreg,hreg1); hreg++;\
      pdlpush(((Cell) temp | 8));\
      if (macroprint1) printf("hqs CS step 2 %x %x\n",temp,*hreg);\
      hreg1 =hreg1+1+get_arity(get_str_psc(temp));\
      for (j=1; \
           j <= get_arity(get_str_psc(temp)) \
           ; j++) {\
         pdlpush(cell(clref_val(temp) +j));\
         if (macroprint1) printf("@pdlreg: %x:\n",*(pdlreg+1));\
	 }\
      break;\
    case TABSTRCT:\
      bld_list(hreg,clref_val(temp)); hreg++;\
      break;\
    case UnUsed2:\
      bind_ref(hreg,cell(clref_val(temp)));\
      hreg++;\
      break;\
    }\
    }

/* copies term from table onto heap */
heap_copyarg(from,to)
CPtr from, to;
{
  CPtr hreg1,xtemp1,barrier;
  int j;

#ifdef DEBUG
   if (flags[PIL_TRACE]) debug_subinst(pcreg,ereg,"Heap Copyarg",from,to);
#endif
   barrier = to;
   xtemp3 = (CPtr) from;
   scaffolded_cptr_deref(xtemp3);
   switch (cell_tag(xtemp3)) { 
     case FREE: case REF1: case REF2: case REF3: 
       if (xtemp3 > barrier) {
         if (macroprint1) printf("ct trailed binding: %x %x\n",xtemp3,barrier);
         pushtrail((CPtr) to,*((CPtr) xtemp3));
         *((CPtr) to) = *xtemp3;
       }
       else {
      	 if (macroprint1) printf("non-trailed binding: to %x\n",to);
	 tabpushtrail0(xtemp3,(Cell) xtemp3);
	 *xtemp3 = (Cell) to;
       }
       break;
     case INT: case STRING:
         if (macroprint1) printf("ct: int-string binding: to %x\n",to);
         bind_copy(to,(Cell)xtemp3); 
         break;
/*   case FLOAT:
         float_unification_exception(t_pcreg);
	 break;*/
     case LIST:
       if (macroprint1) printf("cpt list copy pdlreg: %x\n",pdlreg);
       xtemp12 = pdlreg;
       pdlreg1 = xtemp12;
       bind_list(to,hreg);
       pdlpush(cell(clref_val(xtemp3)));
       pdlpush(cell(clref_val(xtemp3) +1));
       hreg1 = hreg + 2;
       rec_heap_copyarg(xtemp1,hreg);
       if (macroprint1) printf("q_st done for list&&&&&&&&&&&&&&&&&& \n");
       xtemp12 = pdlreg;
       break;
     case TABLIST:
       if (macroprint1) printf("cpt tablist copy pdlreg: %x\n",pdlreg);
       bind_list(to,xtemp3);
       break;
     case CS:
       if (macroprint1) printf("cpt CS copy pdlreg: %x\n",pdlreg);
       xtemp12 = pdlreg;
       pdlreg1 = xtemp12;
       bind_cs(to,hreg);
       bld_ref(hreg,cell(clref_val(xtemp3)));
       hreg++;
       for (j=1 ; j <= get_arity(get_str_psc(xtemp3))
	          ;  j++) {
  	 pdlpush(cell(clref_val(xtemp3) +j));
	 if (macroprint1) printf("*pdlreg: %x\n",*(pdlreg+1));
       }
       hreg1 = hreg + j - 1;
       rec_heap_copyarg(xtemp1,hreg);
       if (macroprint1) printf("q_st done for struct&&&&&&&&&&&&&&&&&&&\n");
       xtemp12 = pdlreg;
       break; 
     case TABSTRCT:
       if (macroprint1) printf("cpt tabstrct copy pdlreg: %x\n",pdlreg);
       bind_cs(to,xtemp3);
       break;
   }
   resetpdl;
   undo_load_solution_bindings;
   }
