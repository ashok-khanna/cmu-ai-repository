/************************************************************************/
/*									*/
/* PSB-Prolog System							*/
/* Copyrigth (C) SUNY at Stony Brook, 1986; ECRC, 1990			*/
/*									*/
/* Everyone is granted permission to copy, modify and redistribute	*/
/* PSB-Prolog, but only under the conditions described in the		*/
/* PSB-Prolog License Agreement.  A copy of this license is supposed to	*/
/* have been given to you along with PSB-Prolog so you can know your	*/
/* rights and responsibilities.  It should be in a file named LICENSE. 	*/
/* Among other things, this notice must be preserved on all copies.	*/
/************************************************************************/

/*======================================================================
  Author(s)		:  David S. Warren, Jiyang Xu
  Modified by		:  Jiyang Xu
  Last modification	:  August 13, 1990
======================================================================*/

/* loader.h*/

#define MAXBUCKET 97

shared extern Pair hash_table[];

#define T_EXPORTED 0
#define T_LOCAL    1
#define T_IMPORTED 2
#define T_IMEX     3      /* not used */
#define T_GLOBAL   4

extern byte *loader();
extern byte *load_seg();
