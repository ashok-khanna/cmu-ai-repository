/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File                  :  choice.c
  Author(s)		:  Xu, Swift
  Last modification	:  April, 1993
======================================================================*/

/* type definitions ------------------------------------------------ */
#ifdef XWAM
typedef struct choice_point {
       byte *next_clause;  /* the entry of next choice */
       CPtr ebreg;         /* environment backtrack -- top of env stack */
       CPtr hreg;          /* current top of heap */
       CPtr *trreg;        /* current top of trail stack */
       byte *cpreg;        /* return point of the call to the procedure*/
       CPtr ereg;          /* current top of stack */
       CPtr prev;          /*lookup: previous susp 
                        solution: previous choicepoint */
} *Choice;

#define CPSIZE 7

#define cp_pcreg(b) ((Choice)(b))->next_clause
#define cp_ebreg(b) ((Choice)(b))->ebreg
#define cp_breg(b)  ((Choice)(b))->breg
#define cp_hreg(b)  ((Choice)(b))->hreg
#define cp_trreg(b) ((Choice)(b))->trreg
#define cp_cpreg(b) ((Choice)(b))->cpreg
#define cp_ereg(b)  ((Choice)(b))->ereg
#define cp_tabreg(b) ((Choice)(b))->tabreg
#define cp_prevbreg(b) ((Choice)(b))->prev

/* used for lookup cps */
#define cp_prevlookup(b) ((Choice)(b))->prev

#define save_choicepoint(t_breg, t_ereg, next_clause,prev) \
  t_breg -= sizeof(struct choice_point) / sizeof(CellStr); \
  cp_ereg(t_breg) = t_ereg; \
  cp_cpreg(t_breg) = cpreg; \
  cp_trreg(t_breg) = trreg; \
  cp_hreg(t_breg) = hreg; \
  cp_ebreg(t_breg) = ebreg; \
  cp_prevlookup(t_breg) = prev; \
  cp_pcreg(t_breg) = next_clause

typedef struct table_choice_point {
       byte *next_clause;  /* the entry of next choice */
       CPtr ebreg;         /* environment backtrack -- top of env stack */
       CPtr hreg;          /* current top of heap */
       CPtr *trreg;        /* current top of trail stack */
       byte *cpreg;        /* return point of the call to the procedure*/
       CPtr ereg;          /* current top of stack */
       CPtr tabreg;
       CPtr prev;          /*lookup: previous susp 
                        solution: previous choicepoint */
       CPtr bfreg;          
       CPtr hfreg;          
       CPtr *trfreg;        
       CPtr efreg;          
} *TChoice;

#define TCPSIZE 12

#define tcp_pcreg(b) ((TChoice)(b))->next_clause
#define tcp_ebreg(b) ((TChoice)(b))->ebreg
#define tcp_breg(b)  ((TChoice)(b))->breg
#define tcp_hreg(b)  ((TChoice)(b))->hreg
#define tcp_trreg(b) ((TChoice)(b))->trreg
#define tcp_cpreg(b) ((TChoice)(b))->cpreg
#define tcp_ereg(b)  ((TChoice)(b))->ereg
#define tcp_tabreg(b) ((TChoice)(b))->tabreg
#define tcp_prevbreg(b) ((TChoice)(b))->prev
#define tcp_efreg(b) ((TChoice)(b))->efreg
#define tcp_bfreg(b)  ((TChoice)(b))->bfreg
#define tcp_hfreg(b)  ((TChoice)(b))->hfreg
#define tcp_trfreg(b) ((TChoice)(b))->trfreg

/* used for lookup cps */
#define tcp_prevlookup(b) ((TChoice)(b))->prev

#define save_singleclause_choicepoint(t_breg,t_ereg,tbreg,prev) \
  t_breg -= sizeof(struct table_choice_point) / sizeof(CellStr); \
  tcp_bfreg(t_breg) = bfreg; \
  tcp_efreg(t_breg) = efreg; \
  tcp_trfreg(t_breg) = trfreg; \
  tcp_hfreg(t_breg) = hfreg; \
  tcp_ereg(t_breg) = t_ereg; \
  tcp_cpreg(t_breg) = cpreg; \
  tcp_trreg(t_breg) = trreg; \
  tcp_hreg(t_breg) = hreg; \
  tcp_ebreg(t_breg) = ebreg; \
  tcp_tabreg(t_breg) = tbreg; \
  tcp_prevlookup(t_breg) = prev; \
  tcp_pcreg(t_breg) = &check_complete_inst;

/* save solution & save lookup are the same */
#define save_solution_choicepoint(t_breg,t_ereg,tbreg,prev) \
  t_breg -= sizeof(struct table_choice_point) / sizeof(CellStr); \
  tcp_bfreg(t_breg) = bfreg; \
  tcp_efreg(t_breg) = efreg; \
  tcp_trfreg(t_breg) = trfreg; \
  tcp_hfreg(t_breg) = hfreg; \
  tcp_ereg(t_breg) = t_ereg; \
  tcp_cpreg(t_breg) = cpreg; \
  tcp_trreg(t_breg) = trreg; \
  tcp_hreg(t_breg) = hreg; \
  tcp_ebreg(t_breg) = ebreg; \
  tcp_tabreg(t_breg) = tbreg; \
  tcp_prevlookup(t_breg) = prev; \
  tcp_pcreg(t_breg) = lpcreg

/* ctt */
#define save_lookup_choicepoint(t_breg,t_ereg,tbreg,prev) \
  t_breg -= sizeof(struct table_choice_point) / sizeof(CellStr); \
  tcp_bfreg(t_breg) = bfreg; \
  tcp_efreg(t_breg) = efreg; \
  tcp_trfreg(t_breg) = trfreg; \
  tcp_hfreg(t_breg) = hfreg; \
  tcp_prevlookup(t_breg) = prev; \
  tcp_tabreg(t_breg) = tbreg; \
  tcp_ereg(t_breg) = t_ereg; \
  tcp_cpreg(t_breg) = cpreg; \
  tcp_trreg(t_breg) = trreg; \
  tcp_hreg(t_breg) = hreg; \
  tcp_ebreg(t_breg) = ebreg; \
  tcp_pcreg(t_breg) = &error_instruction_1_inst

#define save_lookup_rc_choicepoint(t_breg,t_ereg,tbreg,prev,cpr) \
  t_breg -= sizeof(struct table_choice_point) / sizeof(CellStr); \
  tcp_bfreg(t_breg) = bfreg; \
  tcp_efreg(t_breg) = efreg; \
  tcp_trfreg(t_breg) = trfreg; \
  tcp_hfreg(t_breg) = hfreg; \
  tcp_prevlookup(t_breg) = prev; \
  tcp_tabreg(t_breg) = tbreg; \
  tcp_ereg(t_breg) = t_ereg; \
  tcp_cpreg(t_breg) = cpr; \
  tcp_trreg(t_breg) = trreg; \
  tcp_hreg(t_breg) = hreg; \
  tcp_ebreg(t_breg) = ebreg; \
  tcp_pcreg(t_breg) = &error_instruction_1_inst

typedef struct reuse_choice_point {
       byte *next_clause;  /* the entry of next choice */
       CPtr ebreg;         /* environment backtrack -- top of env stack */
       CPtr hreg;          /* current top of heap */
       CPtr *trreg;        /* current top of trail stack */
       byte *cpreg;        /* return point of the call to the procedure*/
       CPtr ereg;          /* current top of stack */
       CPtr tabreg;
       CPtr retrn;
       Cell marker;
       int  arity;
       CPtr prev;          /*lookup: previous susp 
                             solution: previous choicepoint */
} *RChoice;

#define REUSECPSIZE 11

#define rcp_pcreg(b) ((RChoice)(b))->next_clause
#define rcp_ebreg(b) ((RChoice)(b))->ebreg
#define rcp_breg(b)  ((RChoice)(b))->breg
#define rcp_hreg(b)  ((RChoice)(b))->hreg
#define rcp_trreg(b) ((RChoice)(b))->trreg
#define rcp_cpreg(b) ((RChoice)(b))->cpreg
#define rcp_ereg(b)  ((RChoice)(b))->ereg
#define rcp_tabreg(b) ((RChoice)(b))->tabreg
#define rcp_return(b) ((RChoice)(b))->retrn
#define rcp_marker(b) ((RChoice)(b))->marker
#define rcp_arity(b) ((RChoice)(b))->arity
#define rcp_prevbreg(b) ((RChoice)(b))->prev

#define save_reuse_choicepoint(t_breg,t_ereg,tbreg,prev,arity) \
  t_breg -= sizeof(struct reuse_choice_point) / sizeof(CellStr); \
  rcp_prevbreg(t_breg) = prev; \
  rcp_arity(t_breg) = (int) arity; \
  rcp_tabreg(t_breg) = tbreg; \
  rcp_ereg(t_breg) = t_ereg; \
  rcp_cpreg(t_breg) = cpreg; \
  rcp_trreg(t_breg) = trreg; \
  rcp_hreg(t_breg) = hreg; \
  rcp_ebreg(t_breg) = ebreg; \
  rcp_pcreg(t_breg) = &use_table_inst


typedef struct nl_choice_point {
       byte *next_clause;  /* the entry of next choice */
       CPtr ebreg;         /* environment backtrack -- top of env stack */
       CPtr hreg;          /* current top of heap */
       CPtr *trreg;        /* current top of trail stack */
       byte *cpreg;        /* return point of the call to the procedure*/
       CPtr ereg;          /* current top of stack */
       CPtr tabreg;
       CPtr retrn;
       Cell marker;
       int  arity;
       int timestamp;
       CPtr prevlookup;      
       CPtr prev;      
} *NLChoice;

#define NLCPSIZE 13

#define nlcp_pcreg(b) ((NLChoice)(b))->next_clause
#define nlcp_ebreg(b) ((NLChoice)(b))->ebreg
#define nlcp_breg(b)  ((NLChoice)(b))->breg
#define nlcp_hreg(b)  ((NLChoice)(b))->hreg
#define nlcp_trreg(b) ((NLChoice)(b))->trreg
#define nlcp_cpreg(b) ((NLChoice)(b))->cpreg
#define nlcp_ereg(b)  ((NLChoice)(b))->ereg
#define nlcp_tabreg(b) ((NLChoice)(b))->tabreg
#define nlcp_timestamp(b) ((NLChoice)(b))->timestamp
#define nlcp_return(b) ((NLChoice)(b))->retrn
#define nlcp_marker(b) ((NLChoice)(b))->marker
#define nlcp_arity(b) ((NLChoice)(b))->arity
#define nlcp_prevbreg(b) ((NLChoice)(b))->prev
#define nlcp_prevlookup(b) ((NLChoice)(b))->prevlookup

#define save_nl_choicepoint(t_breg,t_ereg,tbreg,prevlookup,prevbreg,arity) \
  t_breg -= sizeof(struct nl_choice_point) / sizeof(CellStr); \
  nlcp_prevlookup(t_breg) = prevlookup; \
  nlcp_prevbreg(t_breg) = prevbreg; \
  nlcp_arity(t_breg) = (int) arity; \
  nlcp_tabreg(t_breg) = tbreg; \
  nlcp_ereg(t_breg) = t_ereg; \
  nlcp_cpreg(t_breg) = cpreg; \
  nlcp_trreg(t_breg) = trreg; \
  nlcp_hreg(t_breg) = hreg; \
  nlcp_ebreg(t_breg) = ebreg; \
  nlcp_pcreg(t_breg) = &new_lookup_inst

#define save_nlcp_aux_info(t_breg,bucket,timestamp,retrn) \
  nlcp_marker(t_breg) = bucket; \
  nlcp_timestamp(t_breg) = timestamp; \
  nlcp_return(t_breg) = retrn

typedef struct rs_choice_point {
       byte *next_clause;  /* the entry of next choice */
       CPtr ebreg;         /* environment backtrack -- top of env stack */
       CPtr hreg;          /* current top of heap */
       int  arity;
       CPtr suspptr;
       CPtr retrn;
       CPtr prev;          /*lookup: previous choicepoint */
} *RSChoice;

#define RSCPSIZE 7

#define rs_pcreg(b) ((RSChoice)(b))->next_clause
#define rs_ebreg(b) ((RSChoice)(b))-> ebreg
#define rs_hreg(b) ((RSChoice)(b))->hreg
#define rs_return(b) ((RSChoice)(b))->retrn
#define rs_arity(b) ((RSChoice)(b))->arity
#define rs_suspptr(b) ((RSChoice)(b))->suspptr
#define rs_prevbreg(b) ((RSChoice)(b))->prev


#define save_rs_choicepoint(t_breg,prev,arity,retrn,suspptr) \
  t_breg -= sizeof(struct rs_choice_point) / sizeof(CellStr); \
  rs_prevbreg(t_breg) = prev; \
  rs_suspptr(t_breg) = suspptr;\
  rs_arity(t_breg) = (int) arity; \
  rs_return(t_breg) = retrn;\
  rs_hreg(t_breg) = hreg; \
  rs_ebreg(t_breg) = ebreg; \
  rs_pcreg(t_breg) = &return_solution_inst

typedef struct rc_choice_point {
       byte *next_clause;  /* the entry of next choice */
       CPtr ebreg;         /* environment backtrack -- top of env stack */
       CPtr hreg;          /* current top of heap */
       CPtr compsuspptr;
       CPtr prev;          /*lookup: previous choicepoint */
} *RCChoice;

#define RCCPSIZE 5

#define rc_pcreg(b) ((RCChoice)(b))->next_clause
#define rc_ebreg(b) ((RCChoice)(b))-> ebreg
#define rc_hreg(b) ((RCChoice)(b))->hreg
#define rc_compsuspptr(b) ((RCChoice)(b))->compsuspptr
#define rc_prevbreg(b) ((RCChoice)(b))->prev

#define save_rc_choicepoint(t_breg,prev,compsuspptr) \
  t_breg -= sizeof(struct rc_choice_point) / sizeof(CellStr); \
  rc_prevbreg(t_breg) = prev; \
  rc_compsuspptr(t_breg) = (CPtr) compsuspptr;\
  rc_hreg(t_breg) = hreg; \
  rc_ebreg(t_breg) = ebreg; \
  rc_pcreg(t_breg) = &return_completion_inst

#else
typedef struct choice_point {
       CellStr pad;        /* a data cell, not part of CP */
       byte *next_clause;  /* the entry of next choice */
       CPtr ebreg;         /* environment backtrack -- top of env stack */
       CPtr hreg;          /* current top of heap */
       CPtr *trreg;        /* current top of trail stack */
       byte *cpreg;        /* return point of the call to the procedure*/
       CPtr ereg;          /* current top of stack */
} *Choice;
#endif

#define save_registers(t_breg, arity, ii, regbase) \
  for (ii = 1; ii <= arity; ii++) bld_copy0(--t_breg, cell(regbase+ii))

#define restore_registers(t_breg, arity, ii, regbase) \
  t_breg += sizeof(struct choice_point) / sizeof(CellStr); \
  for (ii = arity; ii >= 1; ii--) bld_copy0(regbase+ii, cell(t_breg++))

#define table_restore_registers(t_breg, arity, ii, regbase) \
  t_breg += sizeof(struct table_choice_point) / sizeof(CellStr); \
  for (ii = arity; ii >= 1; ii--) bld_copy0(regbase+ii, cell(t_breg++))

/* Structure of trail frame is

   |   ptr to last
   |   old val
   \/  traddr
*/

#define undo_load_solution_bindings\
  while (tabtrreg > ((CPtr *) main_thread->opentable) + 1 ) { \
  *(CPtr *) *(tabtrreg - 2) = *(tabtrreg - 1);\
  tabtrreg = (CPtr *) *tabtrreg;\
  }

#define STARTTRREG xtemp1
#define ENDTRREG xtemp2

#define freeze_and_switch_envs(tbreg)\
  if (bfreg > breg) {\
    bfreg = breg + RSCPSIZE;\
    if (trfreg < trreg)  trfreg = trreg;  \
    if (hfreg < hreg)  hfreg = hreg; \
    xtemp1 = ereg;\
    top_of_stack(xtemp1);\
    if (efreg > xtemp1 ) efreg = xtemp1;\
  }\
  switch_envs(tbreg)

#define rcfreeze_and_switch_envs(tbreg)\
  if (bfreg > breg) {\
    bfreg = breg + RCCPSIZE;\
    if (trfreg < trreg)  trfreg = trreg;  \
    if (hfreg < hreg)  hfreg = hreg; \
    xtemp1 = ereg;\
    top_of_stack(xtemp1);\
    if (efreg > xtemp1 ) efreg = xtemp1;\
  }\
  switch_envs(tbreg)

#define tracefreeze_and_switch_envs(tbreg)\
  if (bfreg > breg) {\
    bfreg = breg + RSCPSIZE;\
    if (trfreg < trreg) {\
      printf("trreg trouncing\n");\
      trfreg = trreg;\
      }\
    if (hfreg < hreg) {\
      printf("hreg trouncing\n");\
      hfreg = hreg;\
      }\
    top_of_stack(xtemp1);\
    if (efreg > xtemp1)\
      {printf("top of stack trouncing\n");\
       efreg = xtemp1;}\
  }\
  switch_envs(tbreg)

#define tracercfreeze_and_switch_envs(tbreg)\
    if (bfreg > tbreg) {\
      printf("!@# breg trouncing\n");\
      bfreg = breg;\
      }\
  if (bfreg > breg) {\
    bfreg = breg + RCCPSIZE;\
    if (trfreg < trreg) {\
      printf("trreg trouncing\n");\
      trfreg = trreg;\
      }\
    if (trfreg < nlcp_trreg(tbreg)) {\
      printf("!@# trreg trouncing %x %x %x\n",trfreg,trreg,nlcp_trreg(tbreg));\
	flags[PIL_TRACE] = 1;\
      trfreg = nlcp_trreg(tbreg);\
      }\
    if (hfreg < nlcp_hreg(tbreg)) {\
      printf("!@# hreg trouncing\n");\
      hfreg = hreg;\
      }\
    if (hfreg < hreg) {\
      printf("hreg trouncing\n");\
      hfreg = hreg;\
      }\
    top_of_stack(xtemp1);\
    if (efreg > nlcp_ereg(tbreg) || efreg > nlcp_ebreg(tbreg) ) {\
      printf("!@# trreg trouncing\n");\
      efreg = xtemp1;\
      }\
    if (efreg > xtemp1)\
      {printf("top of stack trouncing\n");\
       efreg = xtemp1;}\
  }\
  switch_envs(tbreg)

#ifdef SCAFFOL
  if ((CPtr) tbreg < breg && (CPtr) tbreg < bfreg) {\
    printf("breg %x bfreg %x tbreg %x\n",breg,bfreg,tbreg);\
    quit("forgot to freeze something");\
    }
#endif
#define switch_envs(tbreg)\
  STARTTRREG = (CPtr) trreg;\
  ENDTRREG = (CPtr) cp_trreg(tbreg);\
  xtemp14 = hreg;\
  trreg = cp_trreg(tbreg);\
  while (STARTTRREG != ENDTRREG) {\
    while (STARTTRREG > ENDTRREG) {\
      untrail( (CPtr) *(STARTTRREG-2));\
      STARTTRREG = (CPtr) *(STARTTRREG);\
    }\
    while (ENDTRREG > STARTTRREG) {\
      *xtemp14++ = (Cell) ENDTRREG;\
      ENDTRREG = (CPtr) *ENDTRREG;\
      }\
  }\
  ENDTRREG = (CPtr) cp_trreg(tbreg);\
  while (xtemp14 > hreg) {\
    xtemp15 = (CPtr) *--xtemp14;\
/*    printf("var %x val %x\n",*(xtemp15 -2),*(xtemp15 -1));*/\
    * (CPtr) *(xtemp15-2) = *(xtemp15 -1);\
  }

#define save_find_locx(t_ereg) \
  if (efreg_on_top(t_ereg) ) ebreg = efreg;\
  else if (ereg_on_top(t_ereg)) ebreg = t_ereg - *(cpreg-5) + 1;

#define top_of_stack(t_ereg) \
  if (efreg_on_top(t_ereg) ) t_ereg = efreg;\
  else {\
    if (ereg < ebreg) t_ereg = t_ereg - *(cpreg-5) + 1; \
      else t_ereg = ebreg;\
      }

#define restore_some_wamregs(t_breg, t_ereg) \
  if (hbreg >=  hfreg) hreg = hbreg; \
  cpreg = cp_cpreg(t_breg); \
  t_ereg = cp_ereg(t_breg)

/*
#define check_stack_overflow(t_breg, t_pcreg, next_clause) \
  if ((int)t_breg < (int)trreg+OFMARGIN) { \
   printf("CP stack overflow Breg: %x\n",t_breg);\
   if (!flags[OVERFLOW_F]) {\
    flags[OVERFLOW_F] = 1; \
    if (*(next_clause)==retry)  synint_proc(0, MYSIG_OFTC, next_clause-8); \
    else if (*(next_clause)==trust) synint_proc(0, MYSIG_OFTC, next_clause-8);\
    else synint_proc(0, MYSIG_OFTC, t_pcreg-8); \
    t_pcreg = pcreg; \
    goto contcase; \
   } \
  }
*/

#define check_stack_overflow(t_breg, t_pcreg, next_clause) \
  if ((int)t_breg < (int)trreg+OFMARGIN) { \
   printf("CP stack overflow Breg: %x\n",t_breg);\
   if (!flags[OVERFLOW_F]) {\
    flags[OVERFLOW_F] = 1; \
    trail_cp_exception(lpcreg);\
    goto contcase; \
   } \
}

#define check_table_stack_overflow(t_tabreg, t_threg) \
  if ((int)t_tabreg < (int)threg+OFMARGIN) {\
    print_statistics(3);\
    tso_exception(lpcreg);\
    goto contcase; \
  }\

#define check_opentable_stack_overflow \
  if ((int)openreg < (int)tabtrreg+OFMARGIN) {\
    print_statistics(3);\
    ot_exception(lpcreg);\
    goto contcase; \
  }\

