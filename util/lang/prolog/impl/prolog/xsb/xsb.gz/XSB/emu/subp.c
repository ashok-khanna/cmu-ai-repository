/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File			:  subp.c
  Author(s)		:  Warren, Swift, Xu, Sagonas
  Last modification	:  May 18, 1993
========================================================================*/

#include <signal.h>
#include <stdio.h>
#include "config_make.h"
#include "aux.h"
#include "psc.h"
#include "cell.h"
#include "memory.h"
#include "register.h"
#include "heap.h"
#include "deref.h"
#include "flags.h"
#include "binding.h"
#include "choice.h"
#include "token.h"
#include "sig.h"
#include "inst.h"
#include "xmacro.h"

/* struct sigvec vec; */

/*======================================================================*/
/*======================================================================*/

#define FAILED		return 0
#define IFTHEN_FAILED	return 0
#define SUCCEED		return 1
#define IFTHEN_SUCCEED	return 1

byte inst_buff[16];
double realtime_count;

#ifdef DEBUG
extern print_status();
#endif
extern double real_time();
extern int xctr;
extern int level_num;
extern int xwammode;
extern int num_unwinds;
extern int macroprint, ctr;
extern CPtr * xtrbase;

#ifdef linux
struct sigaction act, oact;
#endif

unify(rop1, rop2)
Cell rop1, rop2;
{ /* begin unify */
  register Cell op1, op2;
  long arity, i;
  byte * lpcreg;

  lpcreg = pcreg;
  op1 = rop1; op2 = rop2;

#include "unify.i"

  pcreg = lpcreg;
}  /* unify */

/*======================================================================*/
/* set interrupt code in reg 2 and return ep of interrupt handler	*/
/* the returned value is normally assigned to pcreg, so this is like	*/
/* raising a trap.							*/
/*======================================================================*/
synint_proc(psc, intcode, cur_inst)
Psc psc;
byte *cur_inst;
{
  if (!flags[intcode+32]) {		/* default hard handler */
    default_inthandler(intcode, cur_inst);
  } else {				/* call Prolog handler */
    if (psc) { bld_cs(reg+1, (Pair)build_call(psc)); }
    psc = (Psc)flags[intcode+32];
    bld_int(reg+2, intcode);
    pcreg = get_ep(psc);
  }
}

void keyint_proc()
{
    if (*asynint_ptr & KEYINT_MARK) quit("Aborted by user");
		/* already detect a ^C */
    else *asynint_ptr |= KEYINT_MARK;
		/* for sequential case, asynint_ptr can only be */
		/* 0 or KEYINT_MARK */
}

init_interrupt()
{
#ifdef linux
  act.sa_handler = keyint_proc;
  act.sa_mask = 0;
  act.sa_flags = 0;
  sigaction(SIGINT, &act, &oact);
#else
  signal(SIGINT, keyint_proc); 
#endif
}

/*======================================================================*/
/* builds the current call onto the heap and return a pointer to it.	*/
/*======================================================================*/

build_call(psc)
struct psc_rec *psc;
{
    register Cell arg;
    register Pair callstr;
    register int i;

    callstr = (Pair)hreg;	/* save addr of new structure rec */
    new_heap_functor(hreg, psc); /* set str psc ptr */
    for ( i=1; i<=get_arity(psc); i++) {
	arg = cell(reg+i);
	deref(arg);
	if (isnonvar(arg)) {new_heap_node(hreg, arg);}
	else {
	    bind_ref((CPtr)(arg), hreg);
	    new_heap_free(hreg);
	}
    }
    return (int)(callstr);
}

intercept(psc)
struct psc_rec *psc;
{
      int i;

      if (flags[CLAUSE_INT]) synint_proc(psc, MYSIG_CLAUSE, pcreg-8);
      else
      if (flags[DEBUG_ON] && !flags[HIDE_STATE]) {
	    if (get_spy(psc)) {
	    			/* spy'ed pred, interrupted */
		synint_proc(psc, MYSIG_SPY, pcreg-8);
		flags[HIDE_STATE]++;		/* hide interrupt handler */
	    } else if (flags[TRACE]) {
		synint_proc(psc, MYSIG_TRACE, pcreg-8);
		flags[HIDE_STATE]++;		/* hide interrupt handler */
	    }
      }
#ifdef TRACING
      if (flags[HITRACE]) debug_call(psc);
#endif
      if (flags[TRACE_STA]) {
	if ((int)hreg-(int)(cur_thread->pdl) > tds[wid].maxgstack_count)
	  tds[wid].maxgstack_count = (int)hreg-(int)(cur_thread->pdl);
	if ((int)ereg < (int)(cur_thread->lstack)
	    && (int)ereg > (int)(cur_thread->memory)
	    && (int)(cur_thread->lstack)-(int)ereg > tds[wid].maxlstack_count)
	  tds[wid].maxlstack_count = (int)(cur_thread->lstack) - (int)ereg;
	if ((int)trreg - (int)(cur_thread->trail) > tds[wid].maxtrail_count)
	  tds[wid].maxtrail_count = (int)trreg - (int)(cur_thread->trail);
	if ((int)(cur_thread->opentable)-(int)breg > tds[wid].maxcpstack_count)
	  tds[wid].maxcpstack_count = (int)(cur_thread->opentable) - (int)breg;
	if ((int)(OPENSTACKBOTTOM)-(int)openreg > tds[wid].maxopenstack_count)
	  tds[wid].maxopenstack_count = (int)(OPENSTACKBOTTOM) - (int)openreg;
	if (level_num > tds[wid].maxlevel_num)
	  tds[wid].maxlevel_num = level_num;
      }
}

/*======================================================================*/
/* floating point conversions						*/
/*======================================================================*/

static union float_conv {
    float f;
    unsigned long   i;
} float_conv;

#ifndef DW /* SW and HW */

float getfloatval(w)
{

  float_conv.i = w & 0xfffffff0;
  return float_conv.f;
}

makefloat(f)
float f;
{
  float_conv.f = f;
  return ( float_conv.i & 0xfffffff0 ) | FLOAT;
}

#endif

float asfloat(w)
int w;
{
  float_conv.i = w;
  return float_conv.f;
}


/*======================================================================*/
/* compare(V1, V2)							*/
/*	compares two terms; returns zero if V1=V2, a positive value	*/
/*	if V1>V2 and a negative value if V1<V2.  Term comparison is	*/
/*	done according to the standard total order of Prolog terms,	*/
/*	which has as follows:						*/
/*									*/
/*	    variables < floats < integers < atoms < compound terms	*/
/*									*/
/*	A list is compared as an ordinary compound term with arity	*/
/*	2 and functor '.'.						*/
/*									*/
/*	This function was rewritten from scratch by Kostis so that	*/
/*	it is independent of the relative order of tag encoding.	*/
/*	However, it should ONLY be used to compare terms that appear	*/
/*	in the above ordering list.					*/
/*======================================================================*/

int compare(val1, val2)
Cell val1, val2;
{
	int arity1, arity2, comp;
	struct psc_rec *ptr1, *ptr2;
	CPtr cptr1, cptr2;

	deref(val2);		/* val2 is not in register! */
	deref(val1);		/* val1 is not in register! */
	if (val1 == val2) return 0;
	switch(cell_tag(val1)) {
	  case FREE:
	  case REF1:
	  case REF2:
	  case REF3:
	    if (isnonvar(val2)) return -1;
	    else return vptr(val1) - vptr(val2);
	    break;
	  case FLOAT:
	    if (!isnonvar(val2)) return 1;
	    else if (isfloat(val2)) 
	           return sign(float_val(val1) - float_val(val2));
	    else return -1;
	    break;
	  case INT:
	    if (!isnonvar(val2) || isfloat(val2)) return 1;
	    else if (isinteger(val2)) 
		   return int_val(val1) - int_val(val2);
	    else return -1;
	    break;
	  case STRING:
	    if (!isnonvar(val2) || isfloat(val2) || isinteger(val2)) 
		 return 1;
	    else if (isstring(val2)) {
		   if (isnil(val1)) return strcmp("[]", string_val(val2));
		   else if (isnil(val2)) return strcmp(string_val(val1), "[]");
		   else return strcmp(string_val(val1), string_val(val2));
		 }
	    else return -1;
	    break;
	  case CS:
	    if (cell_tag(val2) != CS && cell_tag(val2) != LIST) return 1;
	    else { 
		   ptr1 = get_str_psc(val1);
		   ptr2 = get_str_psc(val2);
	           arity1 = get_arity(ptr1);
	           if (islist(val2)) arity2 = 2; 
		   else arity2 = get_arity(ptr2);
		   if (arity1 != arity2) return arity1-arity2;
		   if (islist(val2)) comp = strcmp(get_name(ptr1), ".");
		   else comp = strcmp(get_name(ptr1), get_name(ptr2));
		   if (comp || (arity1 == 0)) return comp;
		   cptr1 = clref_val(val1);
		   cptr2 = clref_val(val2);
		   for (arity2 = 1; arity2 <= arity1; arity2++) {
		      if (islist(val2))
			comp = compare(cell(cptr1+arity2), cell(cptr2+arity2-1));  
		      else
			comp = compare(cell(cptr1+arity2), cell(cptr2+arity2));
		      if (comp) break;
		   }
		   return comp;
	    }
	    break;
	  case LIST:
	    if (cell_tag(val2) != CS && cell_tag(val2) != LIST) return 1;
	    else if (isconstr(val2)) return -(compare(val2, val1));
	    else {	/* Here we are comparing two list structures. */
		   cptr1 = clref_val(val1);
		   cptr2 = clref_val(val2);
		   comp = compare(cell(cptr1), cell(cptr2));
		   if (comp) return comp;
		   return compare(cell(cptr1+1), cell(cptr2+1));
	    }
	    break;
	  default:
	    fprintf(stderr, 
		    "++Error: Compare (unknown tag %d); returning 0\n", 
		    cell_tag(val1));
	    return 0;
	}
}

/*======================================================================*/
/* print an operator.							*/
/*======================================================================*/

print_op(file, string, pos)
FILE *file;
char *string;
{
  char *s;
  int need_blank = 0;

  s = string;
  while (*s) { 
    if (intype(*s) != SIGN) { need_blank = 1; break;} 
    s++;
  }
  if (need_blank) {
    switch (pos) {
    case 1: print_qatom(file, string); putc(' ', file); break;
    case 2: putc(' ', file); print_qatom(file, string); putc(' ', file); break;
    case 3: putc(' ', file); print_qatom(file, string); break;
    }
  } else fprintf(file, "%s", string);
}

/*======================================================================*/
/* print an atom, quote it if necessary.				*/
/*======================================================================*/

print_qatom(file, string)
FILE *file;
char *string;
{
  char *s;
  int need_quote = 0, type;

  if (intype(*string) != LOWER ) need_quote = 1;
  else {
    s = string;    
    while (*s) {
      type = intype(*s);
      if (type != LOWER && type != UPPER && type != DIGIT && type != BREAK) {
	need_quote = 1; break; 
      }
      s++;
    }
  }
  if (need_quote) fprintf(file, "'%s'", string);
  else fprintf(file, "%s", string);
}

/*======================================================================*/
/* print statistics and measurement.					*/
/*======================================================================*/

print_statistics(amount)
{
    int i;

    switch (amount) {
    case 0:			/* reset parameters */
    case 2:
      realtime_count = real_time();
#ifdef PARALLEL
      for (i=0; i<flags[VERSION_PROCR]; i++) {
	if (i == wid) perproc_reset_stat();
	else msg_send(i, MYSIG_STAT, 0, 0);
      }
#endif
#ifdef SEQUENTIAL
      perproc_reset_stat();
#endif
      reset_stat_total();
      printf("Statistics is reset.\n");
      break;
    case 1:			/* print stack usage and cputime */
    case 3:			/* print parallel measurement result */
      start_trace();
#ifdef PARALLEL
      for (i=0; i<flags[VERSION_PROCR]; i++) {
	if (i == wid) perproc_stat(i);
	else msg_send(i, MYSIG_STAT, 0, 1);
      }
#endif
#ifdef SEQUENTIAL
      perproc_stat(0);
#endif
      wait_trace(flags[VERSION_PROCR]);
      total_stat(flags[VERSION_PROCR], real_time()-realtime_count);
      reset_stat_total();
      break;
    case 5:  dis(0); break;	/* output memory image; for debugging */
    case 6:  dis(1); break;	/* output memory image; for debugging */
    }
    
}

#ifdef PARALLEL
#ifdef CPSTACK
#define AUTOEXPAND
#endif
#endif

default_inthandler(intcode, cur_inst)
byte *cur_inst;
{
  switch (intcode) {
  case MYSIG_UNDEF:
    printf("Undefined predicate, quit by the default handler\n");
    quit("Abnormal termination");
    break;
  case MYSIG_KEYB:
    printf("Keyboard interrupt, quit by the default handler\n");
    quit("Abnormal termination");
    break;
  case MYSIG_OFMEM:
#ifdef AUTOEXPAND
    printf("[Global/local stack overflow, automatically resolved]\n");
    mem_overflow_handler(cur_inst);
#else
    printf("Global/local stack overflow, quit by the default handler\n");
    print_statistics(3);
    quit("Abnormal termination");
#endif
    break;
  case MYSIG_OFTC:
#ifdef AUTOEXPAND
    printf("[Trail/CP stack overflow, automatically resolved]\n");
    mem_overflow_handler(cur_inst);
#else
    printf("Trail/CP stack overflow, quit by the default handler\n");
    print_statistics(3);
    quit("Abnormal termination");
#endif
    break;
  case MYSIG_DELAY:
    printf("Delay interrupt, quit by the default handler\n");
    quit("Abnormal termination");
    break;
  default:
    printf("Unknow interrupt (%d) occured, quit by the default handler\n", 
	   intcode);
    quit("Abnormal termination");
    break;
  }
}

#ifdef AUTOEXPAND
mem_overflow_handler(cur_inst)
byte *cur_inst;
/* detected in an "allocate" or an "try" instruction */
{
  byte *ptr;

  switch (*cur_inst) {
  case allocate:
  case try:
  case trymeelse:
    ptr = inst_buff;		/* make an inst "partry 0 1" */
    *(ptr++) = partry;
    ptr += 2;
    *(ptr++) = 0;
    *((int *)(ptr))++ = 1;	/* make an inst "trust 0 cur_inst" */
    *(ptr++) = trust;
    ptr += 2;
    *(ptr++) = 0;
    *(byte **)ptr = cur_inst;
    pcreg = (byte *)(inst_buff);
    break;
  case partry:  
    break;	/* do nothing, till next time stack overflow is detected */
  default: printf("Unknown instruction (0x%x=%d) during memory overflow\n", 
	cur_inst, *cur_inst);
    quit("Abnormal termination");
    break;
  }
}
#endif

sign(num)
float num;
{
  if (num==0.0) return 0;
  else if (num>0.0) return 1;
  else return -1;
}

CPtr get_interp_cp()
{
  int temp;
  Pair temppair;
  Psc interp_mod;

  temppair = insert("_$abort_cutpoint",0,global_mod , &temp);
  if (temp == 1) { /* new */
    printf("interpreter choice point not found\n");
    abort();
  }
  else return (CPtr) get_ep(temppair->psc_ptr);
}

/* ----- C level exception handlers -------- */

byte * exception_handler(string)
char * string;
{
  CPtr * xtemp1;
  CPtr * xtemp2;

  fprintf(stderr, "%s\n", string);
/*  printf("exception breg %x %d\n",breg,breg);*/
  breg =  get_interp_cp();
  hbreg = cp_hreg(breg);
  ebreg = cp_ebreg(breg); 
  if (xwammode) {
    remove_open_tables();
    reset_freeze_registers;
  }
  return cp_pcreg(breg); 
}

/* Called from Prolog level */
remove_open_tables_reset_freezes()
{
  if (xwammode) {
    remove_open_tables();
    reset_freeze_registers;
  }
}

return_abort(ptr1,ptr2,msg)
CPtr ptr1, ptr2;
char * msg;
{
  printf("%s ptr1: %x, ptr2 %x \n",msg,ptr1,ptr2);
#ifdef DEBUG
  printf("xctr %d\n",xctr);
#endif
  flags[PIL_TRACE] = 1;
  printf("return not loaded\n");
#ifdef DEBUG
  print_status();
#endif
/*  quit("return not loaded  Going down\n");*/
}

xcepthash(adr,size,temp1,temp2) 
CPtr adr, temp1, temp2;
int size;
{
  temp1 = (CPtr) * adr;
  switch (cell_tag(temp1)) {
    case FREE: case REF1: case REF2: case REF3: 
      temp2 = (CPtr) 1;
      break;
    case LIST:
      temp2 = (CPtr) 2;
      break;
    case CS:
      temp2 =(CPtr) cell(clref_val(temp1));
      break;
    default:
      temp2 = temp1;
      }
   return (int) ((unsigned) (temp2) % size);
   }


remove_open_tables()
{
  CPtr osptr;
  CPtr tip_ptr, curcall, init_addr, result, last_call, base_addr;
  int i,j, flag, size;
  register CPtr xtemp1,xtemp2;

  if (openreg < OPENSTACKBOTTOM)  printf("Removing open tables.\n");
  while (openreg < OPENSTACKBOTTOM) {
    osptr = openreg+1;
    tip_ptr = ots_susp_ptr(osptr);
    base_addr = tip_ptr + 2;
    init_addr = tip_ptr - 4;
#ifdef IPIL
    printf("base_addr %x \n",base_addr);
#endif
    tip_ptr = (CPtr) *(tip_ptr -1);
    curcall = get_tab_entry(tip_ptr);   
#ifdef IPIL
    printf("1curcall %x \n",curcall);
#endif
    size = get_chs(tip_ptr);
    result = (CPtr) xcepthash(init_addr,size,xtemp1,xtemp2);
    curcall = curcall - (int) result;
#ifdef IPIL
    printf("2curcall %x \n",curcall);
#endif
    flag = 0;
    while (curcall != 0 && !flag) {
      last_call = curcall;
      curcall = (CPtr) (*curcall);  
#ifdef IPIL
      printf("3curcall %x \n",curcall);
#endif
      if (curcall == base_addr) { 
	flag = 1;
	*last_call = *curcall;
      }
    }
    if (!flag) {
      printf("curcall %x last_call %x\n",curcall,last_call);
      flags[PIL_TRACE] = 1;
    }
  openreg = openreg + OTFRAMESIZE;
  }
}

