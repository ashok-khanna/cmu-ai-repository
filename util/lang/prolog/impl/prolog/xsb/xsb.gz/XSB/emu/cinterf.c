/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/
 
/*======================================================================
  Author(s)             :  Jiyang Xu
  Modified by           :  Jiyang Xu
  Last modification     :  Nov. 23, 1992
======================================================================*/

/* cinterf.c */

#include "config_make.h"
#include "aux.h"
#include "cell.h"
#include "register.h"
#include "psc.h"
#include "flags.h"
#include "deref.h"
#include "heap.h"
#include "binding.h"
#include "choice.h"
#include "cinterf.h"

extern byte halt1_inst_addr[];
extern byte halt2_inst_addr[];

/*======================================================================*/
/* Low level C interface						*/
/*======================================================================*/

bool is_var(term)
prolog_term term;
{
    Cell t = (Cell)term;
    return isref(t);
}

bool is_int(term)
prolog_term term;
{
    Cell t = (Cell)term;
    return isinteger(t);
}

bool is_float(term)
prolog_term term;
{
    Cell t = (Cell)term;
    return isfloat(t);
}

bool is_string(term)
prolog_term term;
{
    Cell t = (Cell)term;
    return isstring(t);
}

bool is_list(term)
prolog_term term;
{
    Cell t = (Cell)term;
    return islist(t);
}

bool is_nil(term)
prolog_term term;
{
    Cell t = (Cell)term;
    return (isstring(t) && isnil(t));
}

bool is_functor(term)
prolog_term term;
{
    Cell t = (Cell)term;
    return isconstr(t);
}

prolog_term reg_term(regnum)
reg_num regnum;
{
    register Cell addr;

    addr = cell(reg+regnum);
    deref(addr);
    return (prolog_term)addr;
}

bool c2p_int(val, var)
int val;
prolog_term var;
{
    Cell v = (Cell)var;
    if (is_var(v)) {
	bind_int(vptr(v), val);
	return TRUE;
    } else {
	printf("Non-variable in c2p_*\n");
	return FALSE;
    }
}

bool c2p_float(val, var)
double val;
prolog_term var;
{
    Cell v = (Cell)var;
    if (is_var(v)) {
	bind_float(vptr(v), (float)(val));
	return TRUE;
    } else {
	printf("Non-variable in c2p_*\n");
	return FALSE;
    }
}

bool c2p_string(val, var)
char* val;
prolog_term var;
{
    Cell v = (Cell)var;
    if (is_var(v)) {
	bind_string(vptr(v), (char *)string_find(val, 1));
	return TRUE;
    } else {
	printf("Non-variable in c2p_*\n");
	return FALSE;
    }
}

bool c2p_list(var)
prolog_term var;
{
    Cell v = (Cell)var;
    if (is_var(v)) {
	sreg = hreg;
	new_heap_free(hreg);
	new_heap_free(hreg);
	bind_list(vptr(v), sreg);
	return TRUE;
    } else {
	printf("Non-variable in c2p_*\n");
	return FALSE;
    }
}

bool c2p_nil(var)
prolog_term var;
{
    Cell v = (Cell)var;
    if (is_var(v)) {
#ifdef CONASSTRING
       bind_string(vptr(v), 0);
#else
       bind_cs(vptr(v), nil_sym);
#endif
       return TRUE;
    } else {
	printf("Non-variable in c2p_*\n");
	return FALSE;
    }
}

void c2p_setfree(var)
prolog_term var;
{
    CPtr v = (CPtr)var;
    bld_free(v);
}

bool c2p_functor(functor, arity, var)
char *functor;
int arity;
prolog_term var;
{
    Cell v = (Cell)var;
    Pair sym;
    int i;
    if (is_var(v)) {
	sym = (Pair)insert(functor, arity, (Psc)flags[CURRENT_MODULE], &i);
	sreg = hreg;
	hreg += arity + 1;
	bind_cs(vptr(v), sreg);
	new_heap_functor(sreg, sym->psc_ptr);
	for (i=0; i<arity; sreg++,i++) { bld_free(sreg); }
	return TRUE;
    } else {
	printf("Non-variable in c2p_*\n");
	return FALSE;
    }
}

int p2c_int(term)
prolog_term term;
{
    Cell t = (Cell)term;
    return int_val(t);
}

double p2c_float(term)
prolog_term term;
{
    Cell t = (Cell)term;
    return (double)(float_val(t));
}

char *p2c_string(term)
prolog_term term;
{
    Cell t = (Cell)term;
    return string_val(t);
}

char *p2c_functor(term)
prolog_term term;
{
    Cell t = (Cell)term;
    return get_name(get_str_psc(t));
}

int p2c_arity(term)
prolog_term term;
{
    Cell t = (Cell)term;
    return get_arity(get_str_psc(t));
}

prolog_term p2p_arg(term, argno)
prolog_term term;
int argno;
{
    Cell t = (Cell)term;
    deref(t);
    t = cell(clref_val(t)+argno);
    deref(t);
    return (prolog_term)t;
}

prolog_term p2p_car(term)
prolog_term term;
{
    Cell t = (Cell)term;
    deref(t);
    t = cell(clref_val(t));
    deref(t);
    return (prolog_term)t;
}

prolog_term p2p_cdr(term)
prolog_term term;
{
    Cell t = (Cell)term;
    deref(t);
    t = cell(clref_val(t)+1);
    deref(t);
    return (prolog_term)t;
}

prolog_term p2p_new()
{
    CPtr t = hreg;
    new_heap_free(hreg);
    return (prolog_term)(cell(t));
}

bool p2p_unify(term1, term2)
prolog_term term1, term2;
{
    return unify(term1, term2);
}

prolog_term p2p_deref(term)
prolog_term term;
{
    Cell t = (Cell)term;
    deref(t);
    return (prolog_term)t;
}


/*
** Constaints and internal data structures
**
*/

#include <setjmp.h>

#define MAXARITY 255
#define MAXFMTLENGTH 128

static char *subformat[10];
static char *c_dataptr_rest;
static jmp_buf env;

/*
** internal procedure declarations
**
*/

static char *ctop_term0();
static char *ptoc_term0();
static char *skip_subfmt();
static int count_arity();
static int count_csize();
static void cppc_error();

/*
** procedure cppc_error
**
*/

static void cppc_error(num)
int num;
{
    longjmp(env, num);
}

/*
** procedure skip_subfmt
**
*/

static char *skip_subfmt(ptr, quote)
char *ptr;
char quote;
{
    while (*ptr) {
	if (*ptr == quote) return ++ptr;
	else if (*ptr == '[') ptr = skip_subfmt(++ptr, ']');
	else if (*ptr == '(') ptr = skip_subfmt(++ptr, ')');
	else ptr++;
    }
    cppc_error(6);
    return ptr;	/* never reach here */
}

/*
** procedure count_arity
**
** count Prolog term size (arity). Ignored fields are not counted
*/

static int count_arity(ptr, quote)
char *ptr;
int quote;
{
    int arity = 0;

    while (*ptr && arity <= MAXARITY) {
	if (*ptr == quote) return arity;
	else if (*ptr == '%') {
	    if (*(++ptr)!='*') arity++;
	} else if (*ptr == '[') ptr = skip_subfmt(++ptr, ']');
	else if (*ptr == '(') ptr = skip_subfmt(++ptr, ')');
	else ptr++;
    }
    cppc_error(5);
    return -1;	/* never reach here */
}

/*
** procedure count_fields
**
** count number of fields in the primary structure.
** should be the same as arity + ignored fields.
*/

static int count_fields(ptr, quote)
char *ptr;
int quote;
{
    int fields = 0;

    while (*ptr && fields <= MAXARITY) {
	if (*ptr == quote) return fields;
	else if (*ptr == '%') { fields++; ptr++; }
	else if (*ptr == '[') ptr = skip_subfmt(++ptr, ']');
	else if (*ptr == '(') ptr = skip_subfmt(++ptr, ')');
	else ptr++;
    }
    cppc_error(5);
    return -1;	/* never reach here */
}

/*
** procedure count_csize
**
** count C struct size (number of bytes). Ignored fields are also counted
*/

static int count_csize(ptr, quote)
char *ptr;
int quote;
{
    int size = 0;

    while (*ptr) {
	if (*ptr == quote) return size;
	else if (*ptr == '%') {
	    if (*(++ptr)=='*') ptr++;
	    switch (*ptr) {
		case 'f': size += sizeof(float); ptr++; break;
		case 'd': size += sizeof(double); ptr++; break;
		case 'i': size += sizeof(int); ptr++; break;
		case 'c': size += 1; ptr++; break;
		case 's': size += sizeof(char *); ptr++; break;
		case 'z': ptr++; size += 4 * (*ptr-'0'); ptr++; break;
		case 't': size += sizeof(int *);
		    ptr += 2;
		    skip_subfmt(ptr, ')');
		    break;
		case 'l': size += sizeof(int *);
		    ptr += 2;
		    skip_subfmt(ptr, ')');
		    break;
		case '[': 
		    size += count_csize(++ptr, ']');
		    skip_subfmt(ptr, ']');
		    break;
		case '0':
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
		case '6':
		case '7':
		case '8':
		case '9':
		    size += sizeof(int *); ptr++; break;
		default: cppc_error(7); break;
	    }
	}
    }
    cppc_error(8);
    return -1;	/* never reach here */
}

/*
** procedure ctop_term0
**
*/

static char *ctop_term0(ptr, c_dataptr, variable, ignore)
char *ptr, *c_dataptr;
prolog_term variable;
int ignore;
{
    char ch;
    int fmtnum;
    char *cdptr2;
    int  argno, fields, i;
    int ignore1;

    if (*ptr++!= '%') cppc_error(1);
    ch = *ptr++;
    if (ch=='*') ch = *ptr++;
    switch (ch) {
	case 'i':			/* int */
	
	if (!ignore) c2p_int(*((int *)(c_dataptr)), variable);
	c_dataptr_rest = c_dataptr + sizeof(int);
	break;

	case 'c':

	if (!ignore) c2p_int((int)(*(char *)(c_dataptr)), variable);
	c_dataptr_rest = c_dataptr + 1;
	break;

	case 's':

	if (!ignore) c2p_string(*(char **)(c_dataptr), variable);
	c_dataptr_rest = c_dataptr + 4;
	break;

	case 'z':

	if (!ignore) c2p_string(c_dataptr, variable);
	ch = *ptr++;
	c_dataptr_rest = c_dataptr + (ch -'0')*4;
	break;

	case 'f':

	if (!ignore) c2p_float((double)(*((float *)(c_dataptr))), variable);
	c_dataptr_rest = c_dataptr + sizeof(float);
	break;

	case 'd':

	if (!ignore) c2p_float(*((double *)(c_dataptr)), variable);
	c_dataptr_rest = c_dataptr + sizeof(double);
	break;

	case '[':

	fields = count_fields(ptr, ']');
	if (!ignore) {
	    argno = count_arity(ptr, ']');
	    c2p_functor("c2p", argno, variable);
	}
	argno = 0;
	for (i = 1; i <= fields; i++) {
	    if (*(ptr+1)=='*') ignore1 = 1;
	    else { ignore1 = ignore; argno++; }
	    ptr = ctop_term0(ptr,c_dataptr,p2p_arg(variable,argno),ignore1);
	    c_dataptr = c_dataptr_rest;
	}
	ptr = skip_subfmt(ptr, ']');
	break;

	case 't':

	if (!ignore) {
	    if (*(char **)(c_dataptr)) {
		fmtnum = (int)(*ptr-'0');
		subformat[fmtnum] = ptr-2;
		ptr++;
		if (*(ptr++) !='(') cppc_error(2);
		argno = count_arity(ptr, ')');
		fields = count_fields(ptr, ')');
		c2p_functor("c2p", argno, variable);
		cdptr2 = * (char **)(c_dataptr);
		argno = 0;
		for (i = 1; i <= fields; i++) {
		    if (*(ptr+1)=='*') ignore = 1;
		    else { ignore = 0; argno++; }
		    ptr = ctop_term0(ptr,cdptr2,p2p_arg(variable,argno),ignore);
		    cdptr2 = c_dataptr_rest;
		}
	    } else c2p_nil(variable);
	}
	ptr = skip_subfmt(ptr, ')');
	c_dataptr_rest = c_dataptr + 4;
	break;

	case 'l':
	if (!ignore) {
	    if (*(char **)(c_dataptr)) {
		fmtnum = (int)(*ptr-'0');
		subformat[fmtnum] = ptr-2;
		ptr++;
		if (*(ptr++) != '(') cppc_error(3);
		argno = count_arity(ptr, ')');
		fields = count_fields(ptr, ')');
		c2p_list(variable);
		cdptr2 = * (char **)(c_dataptr);
		argno = 0;
		for (i = 1; i <= fields; i++) {
		    if (*(ptr+1)=='*') ignore = 1;
		    else { ignore = 0; argno++; }
		    if (argno==1) 
		       ptr = ctop_term0(ptr,cdptr2,p2p_car(variable),ignore);
		    else if (argno==2)
		       ptr = ctop_term0(ptr,cdptr2,p2p_cdr(variable),ignore);
		    else if (argno==0)
		       ptr = ctop_term0(ptr,cdptr2,p2p_car(variable),ignore);
		       /* always ignored */
		    else cppc_error(30);
		    cdptr2 = c_dataptr_rest;
		}
	    } else c2p_nil(variable);
	}
	ptr = skip_subfmt(ptr, ')');
	c_dataptr_rest = c_dataptr + 4;
	break;

	case '0':
	case '1':
	case '2':
	case '3':
	case '4':
	case '5':
	case '6':
	case '7':
	case '8':
	case '9':

	if (!ignore) {
	    if (*(char **)(c_dataptr)) {
		ctop_term0(subformat[ch-'0'], c_dataptr, variable, 0);
	    } else c2p_nil(variable);
	}
	c_dataptr_rest = c_dataptr + 4;
	break;

	default: cppc_error(4);
    }
    return ptr;
}

/*
** procedure ptoc_term0
**
*/

static char *ptoc_term0(ptr, c_dataptr, variable, ignore)
char *ptr, *c_dataptr;
prolog_term variable;
int ignore;
{
    char ch;
    int fmtnum;
    char *cdptr2;
    int  argno, fields, i, size;
    int ignore1;

    if (*ptr++!= '%') cppc_error(9);
    ch = *ptr++;
    if (ch=='*') ch = *ptr++;
    switch (ch) {
	case 'i':			/* int */

	if (!ignore) {
	    if (is_int(variable)) *((int *)(c_dataptr)) = p2c_int(variable);
	    else cppc_error(10);
	}
	c_dataptr_rest = c_dataptr + sizeof(int);
	break;

	case 'c':

	if (!ignore) {
	    if (is_int(variable)) *((char *)(c_dataptr)) = 
	       (char)p2c_int(variable);
	    else cppc_error(11);
	}
	c_dataptr_rest = c_dataptr + 1;
	break;

	case 's':

	if (!ignore) {
	    if (is_string(variable)) *((char **)(c_dataptr)) =
	       p2c_string(variable);		/* should make a copy??? */
	    else cppc_error(12);
	}
	c_dataptr_rest = c_dataptr + 4;
	break;

	case 'z':

	ch = *ptr++;
	size = 4 * (ch - '0');
	if (!ignore) {
	    if (is_string(variable)) 
	       strncpy(c_dataptr, p2c_string(variable), size);
	    else cppc_error(12);
	}
	c_dataptr_rest = c_dataptr + size;
	break;

	case 'f':

	if (!ignore) {
	    if (is_float(variable)) *((float *)(c_dataptr)) =
	       p2c_float(variable);
	    else cppc_error(13);
	}
	c_dataptr_rest = c_dataptr + sizeof(float);
	break;

	case 'd':

	if (!ignore) {
	    if (is_float(variable)) *((double *)(c_dataptr)) =
	       p2c_float(variable);
	    else cppc_error(14);
	}
	c_dataptr_rest = c_dataptr + sizeof(double);
	break;

	case '[':

	fields = count_fields(ptr, ']');
	argno = 0;
	for (i = 1; i <= fields; i++) {
	    if (*(ptr+1)=='*') ignore1 = 1;
	    else { ignore1 = ignore; argno++; }
	    ptr = ptoc_term0(ptr, c_dataptr,p2p_arg(variable,argno),ignore1);
	    c_dataptr = c_dataptr_rest;
	}
	ptr = skip_subfmt(ptr, ']');
	break;

	case 't':

	if (!ignore) {
	    fmtnum = (int)(*ptr-'0');
	    subformat[fmtnum] = ptr-2;
	    ptr++;
	    if (*(ptr++) != '(') cppc_error(15);
	    fields = count_fields(ptr, ')');
	    size = count_csize(ptr, ')');
	    cdptr2 = (char *)malloc(size);
	    *((char **)c_dataptr) = cdptr2;
	    argno = 0;
	    for (i = 1; i <= fields; i++) {
		if (*(ptr+1)=='*') ignore = 1;
		else { ignore = 0; argno++; }
		ptr = ptoc_term0(ptr,cdptr2,p2p_arg(variable,argno),ignore);
		cdptr2 = c_dataptr_rest;
	    }
	}
	ptr = skip_subfmt(ptr, ')');
	c_dataptr_rest = c_dataptr + 4;
	break;

	case 'l':
	if (!ignore) {
	    fmtnum = (int)(*ptr-'0');
	    subformat[fmtnum] = ptr-2;
	    ptr++;
	    if (*(ptr++)!='(') cppc_error(16);
	    fields = count_fields(ptr, ')');
	    size = count_csize(ptr, ')');
	    cdptr2 = (char *)malloc(size);
	    *((char **)c_dataptr) = cdptr2;
	    argno = 0;
	    for (i = 1; i <= fields; i++) {
		if (*(ptr+1)=='*') ignore = 1;
		else { ignore = 0; argno++; }
		if (argno==1)
		   ptr = ptoc_term0(ptr,cdptr2,p2p_car(variable),ignore);
		else if (argno==2)
		   ptr = ptoc_term0(ptr,cdptr2,p2p_cdr(variable),ignore);
		else cppc_error(31);
		cdptr2 = c_dataptr_rest;
	    }
	}
	ptr = skip_subfmt(ptr, ')');
	c_dataptr_rest = c_dataptr + 4;
	break;

	case '0':
	case '1':
	case '2':
	case '3':
	case '4':
	case '5':
	case '6':
	case '7':
	case '8':
	case '9':

	if (!ignore) {
	    if (!is_nil(variable)) {
		ptoc_term0(subformat[ch-'0'], c_dataptr, variable, 0);
	    } else *(int *)(c_dataptr) = 0;
	}
	c_dataptr_rest = c_dataptr + 4;
	break;

	default: cppc_error(17);
    }
    return ptr;
}

/*
** procedure ctop_term
**
*/

int   ctop_term(fmt, c_dataptr, regnum)
char* fmt;
char* c_dataptr;
reg_num regnum;
{
    prolog_term variable;
    int errno;

    variable = reg_term(regnum);
    if (errno = setjmp(env)) return errno;	/* catch an exception */
    ctop_term0(fmt, c_dataptr, variable, 0);
    return 0;
}

/*
** procedure ptoc_term
**
*/

int ptoc_term(fmt, c_dataptr, regnum)
char *fmt, *c_dataptr;
reg_num regnum;
{
    prolog_term variable;
    int errno;

    variable = reg_term(regnum);
    if (errno = setjmp(env)) return errno;	/* catch an exception */
    ptoc_term0(fmt, c_dataptr, variable, 0);
    return 0;
}

/*
** procedure c2p_term
**
*/

int   c2p_term(fmt, c_dataptr, variable)
char* fmt;
char* c_dataptr;
prolog_term variable;
{
    int errno;

    if (errno = setjmp(env)) return errno;	/* catch an exception */
    ctop_term0(fmt, c_dataptr, variable, 0);
    return 0;
}

/*
** procedure p2c_term
**
*/

int p2c_term(fmt, c_dataptr, variable)
char *fmt, *c_dataptr;
prolog_term variable;
{
    int errno;

    if (errno = setjmp(env)) return errno;	/* catch an exception */
    ptoc_term0(fmt, c_dataptr, variable, 0);
    return 0;
}
