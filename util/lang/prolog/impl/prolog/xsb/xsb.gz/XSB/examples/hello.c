#include <stdio.h>

hello()
{
	printf("Hello XSB world\n");
}

