/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File                  :  trace.c
  Author(s)		:  Jiyang Xu, Terrance Swift
  Last modification	:  April, 1993
======================================================================*/

#include <stdio.h>
#include "config_make.h"
#include "aux.h"
#include "inst.h"
#include "cell.h"
#include "memory.h"
#include "register.h"
#include "choice.h"
#include "flags.h"

static int trace_collected;
extern double cpu_time();
extern int num_unwinds;
extern int level_num;

int maxstack_used;
private double time_start;

struct trace_str tds[MAXWORKER];	/* trace datastructure per worker */
struct trace_str ttt;		/* trace total */
struct trace_str trace_init = {	/* initial value for a trace str */
    0, 0, 0, 0, 0, 0,
#ifdef MEASURE
    0,
#ifdef MEASURE2
    0, 0, 0, 0, 0,
#endif
#endif
    0.0
   };

/*======================================================================*/
/* perproc_stat(worker)							*/
/*======================================================================*/
perproc_stat(procid)
{

  tds[wid].time_count = cpu_time() - time_start;
  if (ttt.maxgstack_count < tds[wid].maxgstack_count) 
     ttt.maxgstack_count = tds[wid].maxgstack_count;
  if (ttt.maxlstack_count < tds[wid].maxlstack_count) 
     ttt.maxlstack_count = tds[wid].maxlstack_count;
  if (ttt.maxtrail_count < tds[wid].maxtrail_count)
     ttt.maxtrail_count = tds[wid].maxtrail_count;
  if (ttt.maxcpstack_count < tds[wid].maxcpstack_count)
     ttt.maxcpstack_count = tds[wid].maxcpstack_count;
  if (ttt.maxopenstack_count < tds[wid].maxopenstack_count)
     ttt.maxopenstack_count = tds[wid].maxopenstack_count;
  if (ttt.maxlevel_num < tds[wid].maxlevel_num)
     ttt.maxlevel_num = tds[wid].maxlevel_num;
#ifdef MEASURE
  ttt.temp_count += tds[wid].temp_count;
#ifdef MEASURE2
  ttt.pil_count += tds[wid].pil_count;
  ttt.deref_count += tds[wid].deref_count;
  ttt.call_count += tds[wid].call_count;
  ttt.try_count += tds[wid].try_count;
  ttt.retry_count += tds[wid].retry_count;
#endif
#endif
  ttt.time_count += tds[wid].time_count;
  trace_collected++;
}

total_stat(numprocs, elapstime)
double elapstime;
{
int  lstktop;

#ifdef CPSTACK
      lstktop = (int)ereg;
#else
      if (breg < ereg) lstktop = (int)breg;
      else lstktop = (int)(ereg - *(cpreg-5));
#endif
printf("== Statistics ===      \n");
#ifdef XWAM
printf("Permanent space: %d allocated.\n",pspacesize);
#else
printf("Permanent space: %d used %dK allocated.\n",pspace_used(),pspacesize);
#endif
printf("Stack space allocated: %dK+%dK+%dK+%dK+%dK\n",
       pdlsize,maxsuspsize,memsize, tcsize,maxopentablesize);
printf("Stacks in use : global %d, local %d, trail %d, cp %d\n",
       (int)hreg-(int)(cur_thread->maxsusp),
       (int)(cur_thread->lstack)-(int)lstktop,
       (int)trreg - (int)(cur_thread->trail),
       (int)(cur_thread->opentable)-(int)breg	);
printf("OLDT Stacks in use : table %d, tab_heap %d opentables %d\n",
       (int)(cur_thread->maxsusp)-(int)tabreg -4,
       (int)threg-(int)(cur_thread->pdl),
       (int)(OPENSTACKBOTTOM -openreg));
printf("num unwinds: %d\n",num_unwinds);
printf("level num: %d\n",level_num);
if (flags[TRACE_STA]) {
printf("Max stack used: global %d, local %d, trail %d, cp %d\n",
	 ttt.maxgstack_count, ttt.maxlstack_count, 
       ttt.maxtrail_count, ttt.maxcpstack_count);
printf("Max stack used: opentable %d, level %d\n",
	 ttt.maxopenstack_count, ttt.maxlevel_num);
     }
#ifdef MEASURE
printf(" tmp count %d\n", ttt.temp_count);
#ifdef MEASURE2
printf("  I(nstr.) %d; D(eref) %d; C(all) %d; O(R-node) %d; R(e)t(ry) %d\n",
        ttt.pil_count, ttt.deref_count,ttt.call_count,
       ttt.try_count, ttt.retry_count);
#endif
#endif
printf("TIME: cputime: %.2f*%d sec, elapsetime %.2f sec\n",
       ttt.time_count/numprocs, numprocs, elapstime);
}

start_trace()
{
  trace_collected = 0;
}

wait_trace(num)
{
  while (trace_collected < num);
}

perproc_reset_stat()
{
    tds[wid] = trace_init;
    time_start = cpu_time();
}

reset_stat_total()
{
    maxstack_used = 0;
    ttt = trace_init;
}
