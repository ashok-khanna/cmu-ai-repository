/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File                  :  aux.c
  Author(s)		:  Warren, Sagonas, Xu
  Last modification	:  July 21, 1993
======================================================================*/

#include "config_make.h"
#include <sys/time.h>
#include <sys/resource.h>

#ifdef HP300
#include <sys/syscall.h>
#define getrusage(T, USAGE)     syscall(SYS_getrusage, T, USAGE);
#endif

#ifdef SOLARIS
#include <sys/times.h>
#include <limits.h>
#endif

quit0(s)
char *s;
{
    printf("%s\n", s);
    exit(0);
}

quit(s)
char *s;
{
  printf("%s\n", s);
  exit(0); 
}

#ifndef SOLARIS
double cpu_time()
{
  struct rusage usage;
  float time_sec;
    
  getrusage(0, &usage);
  time_sec = (float)usage.ru_utime.tv_sec + 
		(float)usage.ru_utime.tv_usec / 1000000.0;
  return time_sec;
}
#else
double cpu_time()
{
  struct tms time_buffer;
  float time_sec;
    
  times( &time_buffer );
  time_sec = ((float)time_buffer.tms_utime +
		(float)time_buffer.tms_stime) / 100.0;

  return time_sec;
}
#endif

get_date()
{
  struct tm *value;
  struct timeval tvs;

  gettimeofday(&tvs, 0);
  value = localtime(&(tvs.tv_sec));
  return ((value->tm_year)<<16) + ((value->tm_mon+1)<<8) + value->tm_mday;
}

double real_time()
{
  struct timeval tvs;
  double value;

  gettimeofday(&tvs, 0);
  value = tvs.tv_sec + 0.000001 * tvs.tv_usec;
  return value;
}
