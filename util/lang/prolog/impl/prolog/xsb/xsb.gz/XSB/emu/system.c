/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File			:  system.c
  Author(s)		:  David S. Warren, Jiyang Xu, Kostis F. Sagonas
  Last modification	:  May 18, 1993
========================================================================*/

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/un.h>
#include <stdio.h>
#include "config_make.h"
#include "mysyscall.h"

sys_syscall(callno)
{
  int result;

  switch (callno) {
  case SYS_link: result = link(ptoc_string(3), ptoc_string(4)); break;
  case SYS_unlink: result = unlink(ptoc_string(3)); break;
  case SYS_chdir: result = chdir(ptoc_string(3)); break;
  case SYS_access: result = access(ptoc_string(3), ptoc_int(4)); break;
  case SYS_stat: result = stat(ptoc_string(3),ptoc_int(4)); break;
  case SYS_rename: 
	result = rename((char *)ptoc_string(3), (char *)ptoc_string(4)); break;
  default: fprintf(stderr, "Unknown system call number %d\n", callno);
    result = -1;
  }
  return result;
}

#ifdef NETWORK
sys_brocall(callno, argbuff, resbuff) 
int *argbuff, *resbuff;
{
    switch (callno) {

	case 2:	*resbuff = getenv(*argbuff); break;

/* Communication subsystem system calls. Have not included byteorder (ntohl,
   ntohs, htonl, htons). Each call is from manual entry 3N,  except 
   getpeername,  which is from 2.
   NOTE: Whereever you see dsw, David commented them for the NeXT.
	 Kostis casted by (char *) the arguments of the following functions:
	 gethostbyname(), getnetbyname(), getprotobyname(), inet_network()
	 for the NeXT.
*/

	case 21: *resbuff = (int)gethostent(); break;
	case 22: *resbuff = (int)gethostbyname((char *)argbuff); break;
/*dsw	case 23: *resbuff = (int)gethostbyaddr(*argbuff); break;*/
/*dsw	case 24: *resbuff = (int)sethostent(*argbuff); break;*/
/*dsw	case 25: *resbuff = (int)endhostent(); break;*/

	case 26: *resbuff = (int)getnetent(); break;
	case 27: *resbuff = (int)getnetbyname((char *)argbuff); break;
/*dsw	case 28: *resbuff = (int)getnetbyaddr(*argbuff); break;*/
/*dsw	case 29: *resbuff = (int)setnetent(*argbuff); break;*/
/*dsw	case 30: *resbuff = (int)endnetent(); break;*/

	case 31: *resbuff = (int)getprotoent(); break;
	case 32: *resbuff = (int)getprotobyname((char *)argbuff); break;
	case 33: *resbuff = (int)getprotobynumber(*argbuff); break;
/*dsw	case 34: *resbuff = (int)setprotoent(*argbuff); break;*/
/*dsw	case 35: *resbuff = (int)endprotoent(); break;*/

	case 36: *resbuff = (int)getservent(); break;
/*dsw	case 37: *resbuff = (int)getservbyname(*argbuff); break;*/
/*dsw	case 38: *resbuff = (int)getservbyport(*argbuff); break;*/
/*dsw	case 39: *resbuff = (int)setservent(*argbuff); break;*/
/*dsw	case 40: *resbuff = (int)endservent(); break;*/

/*	case 41: *resbuff = (int)inet_addr(*argbuff); break; */
	case 42: *resbuff = (int)inet_network((char *)argbuff); break;
/*dsw	case 43: *resbuff = (int)inet_ntoa(*argbuff); break;*/
/*	case 44: *resbuff = (int)inet_makeaddr(*argbuff); break; */
/*	case 45: *resbuff = (int)inet_lnaof(*argbuff); break; */
/*	case 46: *resbuff = (int)inet_netof(*argbuff); break; */

/*	case 47: *resbuff = (int)get_peername(*argbuff); break; */
/*dsw	case 50: *resbuff = (int)perror(*argbuff); break;*/

	default: fprintf(stderr, "Illegal brocall number\n");
    }
}
#endif
