/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*==================================================================
  File                  :  hashindex.h
  Author(s)		:  Swift 
  Last modification	:  April, 1993
====================================================================*/

/*==================================================================
Permanent variables are xtemp... which are used all over the place,
in the probably vain hope that they will stay in the cache.

xtemp1, xtemp2 have been declared as registers in emuloop()
(need to declare as registers in xinst_funs).
====================================================================*/


/*==================================================================
====================================================================

The indexing routines themseves
tabhash is used for Indexing Call Tables
rettabhash is used for Indexing Returns

====================================================================
====================================================================*/

#define tabhash(addr,size,result,temp1,temp2) \
  temp1 = (CPtr) * addr;\
  cptr_deref(temp1); \
  switch (cell_tag(temp1)) {\
    case FREE: case REF1: case REF2: case REF3: \
      temp2 = (CPtr) 1;\
      break;\
    case LIST:\
      temp2 = (CPtr) 2;\
      break;\
    case CS:\
      temp2 =(CPtr) cell(clref_val(temp1));\
      break;\
    default:\
      temp2 = temp1;\
      }\
   result = (CPtr) ((unsigned) (temp2) % (size))

#define rettabhash(addr,size,result,arity) \
  result = 0;\
  for ( i = 0 ; i < (int) arity ; i++) {\
    xtemp1 = addr-i;\
    cptr_deref(xtemp1);\
    switch (cell_tag(xtemp1)) {\
      case FREE: case REF1: case REF2: case REF3: \
        xtemp2 = (CPtr) 0;\
        break;\
      case LIST:\
        xtemp2 = (CPtr) 1;\
        break;\
      case CS:\
        xtemp2 = (CPtr) cell(clref_val(xtemp1));\
        break;\
      default:\
        xtemp2 = xtemp1;\
      }\
    result = result + ((unsigned) (xtemp2) << i) ;\
/* needs to be improved */ \
    }\
    result = result % size


/*==================================================================
====================================================================

Routines for Accessing Call Hash Buckets.

====================================================================
====================================================================*/

/*==================================================================
get_first_call_bucket(curcall,CHS,temp,ARITY)
	CPtr curcall -- a pointer to the call bucket.
	unsigned int CHS -- the size of the call hash table; forms 
	the modulus of the hash.
====================================================================*/

#define get_first_call_bucket(curcall,chs,temp,arity) \
    if ( get_tab_entry(curcall) == 0) { \
      if (macroprint) printf("new index block\n"); \
      get_tab_entry(curcall) = (CPtr) tabreg; \
      tabreg = tabreg - chs; \
    } \
    if ((int) arity != 0) {tabhash((reg +1),chs,temp,xtemp1,xtemp2);} \
    else   temp = (CPtr) 1; \
    if (macroprint) printf("tab hash val %d\n",temp); \
    curcall = (CPtr) get_tab_entry(curcall) - (unsigned) temp

/*==================================================================
traverse_call_bucket(&xcurcall,reg,ARITY,&xflag);
At the end of these routines, xcurcall points to the call structure,
if any, and xflag indicates whether a variant call is indeed in the table.
(in xinst_fun.c)
====================================================================*/

/*==================================================================
create_call_structure(cs_addr,xtemp12);

cs_addr is the call structure address
(currently tabreg)
in xmacro.h
====================================================================*/

/*==================================================================
savecallinfo_fun(ARITY,from_addr,to_addr);

copy call into table
to_addr is address of where the call is to be copied.
currently tabreg, as part of call structure
in xmacro.h
====================================================================*/


/*==================================================================
====================================================================

Routines for Accessing Returns

====================================================================
====================================================================*/
#ifdef NOT_RETURN_HASHING
#else
/*Old Version*/
#define determine_if_return_exists(xcurcall,op2,temp,flag,RHS,NEWRETPTR,ARITY)\
    if ( (int)  *xcurcall <= 0) { \
      *xcurcall = (Cell) tabreg; \
      tabreg -= RHS; \
    }      \
      rettabhash(call_str_retptr(NEWRETPTR),RHS,temp,ARITY); \
      if (macroprint) printf("xcurcall %x *xcurcall %x\n",xcurcall,*xcurcall);\
        op2 = (Cell) ((CPtr) *xcurcall - (unsigned) temp);\
        xcurcall = (CPtr) *xcurcall - (unsigned) temp;\
   /* xcurcall and xtemp4 now both point to beginning of hash bucket */\
      if (macroprint) printf("xcurcall %x *xcurcall %x\n",xcurcall,*xcurcall);\
      while ((int) *(xcurcall) > 0 && !flag) { \
        xcurcall = (CPtr) *xcurcall; \
        variant(ARITY,NEWRETPTR,xcurcall-1,flag,-,lpcreg);\
      }

#endif

#ifdef NOT_RETURN_HASHING
#define add_new_solution(NEXTDIRPTR,NEXTRETPTR,ARITY,NEWRETPTR) \
      *tabreg = * NEXTDIRPTR; \
      *NEXTDIRPTR = (Cell) (tabreg--); \
      tabreg--;\
      *tabreg-- = tabreg -1; \
      *tabreg-- = NEXTRETPTR
      if (macroprint) printf("adding retrn: xcurcall %x at NEWRETPTR %x\n",xcurcall,NEWRETPTR); \
      saveinfo(ARITY,NEWRETPTR,tabreg,-,lpcreg)
#else
#define add_new_solution(NEXTRETPTR,ARITY,NEWRETPTR) \
      timestamp++; \
      *tabreg = * NEXTRETPTR; \
      *NEXTRETPTR = (Cell) tabreg; \
      tabreg--;\
/*      *tabreg-- = (timestamp << 4) | INT; BUG--DON'T TAG*/ \
      *tabreg-- = timestamp; \
      if (macroprint) printf("adding retrn: xcurcall %x at NEWRETPTR %x\n",xcurcall,NEWRETPTR); \
      saveinfo(ARITY,NEWRETPTR,tabreg,-,lpcreg)
#endif
/*===================================================================
Used in reuse_table, lay_down_lookup
====================================================================*/
#define get_very_first_solution(bucket_index,flag,return_ptr,call_ptr,CHS) \
         flag = 1;\
         bucket_index = (Cell) CHS;\
         while (flag && return_ptr <= (CPtr) *(call_ptr-1)) {\
            if ((int) *return_ptr == 0) {\
	      bucket_index--;\
  	      return_ptr++;\
	    }	\
            else flag = 0;\
          }

/*===================================================================
get_next_solution_ts(bucket_index,flag,return_ptr,call_ptr,ts,CHS)
Used in return_solution: timestamp needed.
	unsigned CHS -- the size of the call hash table; forms 
        the modulue of the hash.
====================================================================*/
#define get_next_solution_ts(bucket_index,flag,return_ptr,call_ptr,ts,CHS) \
    while (flag) {\
      while ( (int) return_ptr > 0 && *(return_ptr - 1) > ts) \
        return_ptr =  (CPtr) * return_ptr;\
      if ( (int) return_ptr > 0) flag = 0;\
      while ((int) return_ptr == 0 && flag) {\
	bucket_index = bucket_index - 1;\
	if ((int) bucket_index > 0)\
    	  return_ptr = call_ptr - bucket_index +1;\
        else flag = 0;\
        if (return_ptr >  call_ptr - CHS) \
	  return_ptr = (CPtr) * return_ptr;\
      }\
    }


/*===================================================================
No timestamp needed;
used in reuse_table; lay_down_lookup (to set up choice point)
====================================================================*/

#define get_next_solution_nts(bucket_index,flag,return_ptr,call_ptr) \
      if ( (int) return_ptr > 0 ) return_ptr =  (CPtr) *return_ptr;\
      if ((int) return_ptr == 0) {\
        flag = 1;\
	bucket_index = bucket_index - 1;\
	if ((int) bucket_index > 0) \
    	  return_ptr = ((CPtr) *(call_ptr-1)) - bucket_index + 1;\
        else flag = 0;\
	while (flag && return_ptr <= (CPtr) *(call_ptr-1)) {\
	  if ((int) *return_ptr == 0) {\
	    bucket_index--; return_ptr++;\
	  }\
	  else flag=0;\
	  }\
      }

/*===================================================================
slightly optimized from get_next_solution_ts; used in use_table.
====================================================================*/

#define new_get_next_solution_nts(bucket_index,flag,return_ptr,call_ptr) \
   return_ptr =  (CPtr) * return_ptr;\
   if ( (int) return_ptr == 0) { \
     bucket_index = bucket_index - 1;\
     return_ptr = call_ptr - bucket_index +1;\
     while ((int) bucket_index > 0 && *return_ptr == 0) {\
       bucket_index = bucket_index - 1;\
       return_ptr = call_ptr - bucket_index +1;\
     }\
   }
