/************************************************************************/
/*                                                                      */
/* XSB System                                                           */
/* Copyright SUNY at Stony Brook, 1986, ECRC 1990                       */
/* Copyright (C) SUNY at Stony Brook, 1993                              */
/*                                                                      */
/* Everyone is granted permission to copy, modify and redistribute XSB, */
/* but only under the conditions described in the XSB Licence Agreement.*/
/* A copy of this license is supposed to have been given to you along   */
/* with XSB so you can know your rights and responsibilities.           */
/* It should be in a file named LICENSE.                                */
/* Among other things, this notice must be preserved on all copies.     */
/*                                                                      */
/************************************************************************/

/*======================================================================
  File			:  memory.c
  Author(s)		:  Xu , Swift
  Last modification	:  April 1993
======================================================================*/

#define maxtraps      4

#define OFMARGIN  1024

extern int *pbreg;
extern int pbshared;

/* memory space ----------------------------------------------------*/

extern int memsize, tcsize, pspacesize;
#ifdef XWAM
extern int pdlsize, maxsuspsize,maxopentablesize;
#endif
extern int pp_memsize, pp_tcsize;
extern byte *pp_memory, *pp_lstack;
extern word     *pspace; /* psc records, instructions, p-names */
extern byte new_lookup_inst, return_solution_inst, check_complete_inst,
        use_table_inst,
        error_instruction_1_inst, return_completion_inst, fail_inst, 
        halt_inst, suspend_inst, terminate_inst, proceed_inst;
/* boundaries ------------------------------------------------------*/

/* change tls -- new stuff for XWAM */
struct mem_str {
  byte *memory;
#ifdef XWAM
  byte *pdl;
  byte *maxsusp;
#endif
  byte *lstack;
  byte *trail;
#ifdef XWAM
  byte *opentable;
#endif
  byte *memend;
};

#define OPENSTACKBOTTOM ((CPtr) main_thread->memend) -1
#define TableStackBarrier ((CPtr) main_thread->maxsusp) 

extern struct mem_str *main_thread;
extern struct mem_str *cur_thread;

/* other machine parameters -------------------------------------*/

extern byte *inst_begin; /* ptr to the beginning of inst. array */
extern int exitcode;

extern byte *mem_alloc();
extern int mem_dealloc();

