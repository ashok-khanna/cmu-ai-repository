/* This file has been automatically generated
   by make_simple_interface/1
*/

#include	"external.h"

extern char *	malloc();

p_pxVectorXFree()
{

	(void) pxVectorXFree();
	Succeed;
}

p_pxPrecisionGet(val1, tag1)
value	val1;
type	tag1;
{
	long		out1;

	Check_Output_Integer(tag1);
	(void) pxPrecisionGet(&out1);
	Return_Unify_Integer(val1, tag1, out1);
}

p_pxPrecisionSet(val1, tag1, val2, tag2)
value	val1, val2;
type	tag1, tag2;
{
	long		out2;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	out2 = (long	) pxPrecisionSet(val1 . nint);
	Return_Unify_Integer(val2, tag2, out2);
}

p_pxUnsignedPut1(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out4;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxUnsignedPut1(val1 . nint, val2 . nint, val3 . nint);
	Return_Unify_Integer(val4, tag4, out4);
}

p_pxUnsignedPut2(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out4;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxUnsignedPut2(val1 . nint, val2 . nint, val3 . nint);
	Return_Unify_Integer(val4, tag4, out4);
}

p_pxVectorAlloc(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxVectorAlloc(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxVectorGet(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out1;
	long		out2;
	long		out3;
	Prepare_Requests;

	Check_Output_Integer(tag1);
	Check_Output_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxVectorGet(&out1, &out2);
	Request_Unify_Integer(val1, tag1, out1);
	Request_Unify_Integer(val2, tag2, out2);
	Request_Unify_Integer(val3, tag3, out3);
	Return_Unify;
}

p_pxVectorPut(val1, tag1, val2, tag2)
value	val1, val2;
type	tag1, tag2;
{
	long		out2;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	out2 = (long	) pxVectorPut(val1 . nint);
	Return_Unify_Integer(val2, tag2, out2);
}

p_pxSplitGet(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out1;
	long		out2;
	long		out3;
	long		out4;
	Prepare_Requests;

	Check_Output_Integer(tag1);
	Check_Output_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxSplitGet(&out1, &out2, &out3);
	Request_Unify_Integer(val1, tag1, out1);
	Request_Unify_Integer(val2, tag2, out2);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Return_Unify;
}

p_pxSplitGetOne(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out1;
	long		out2;
	long		out3;
	Prepare_Requests;

	Check_Output_Integer(tag1);
	Check_Output_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxSplitGetOne(&out1, &out2);
	Request_Unify_Integer(val1, tag1, out1);
	Request_Unify_Integer(val2, tag2, out2);
	Request_Unify_Integer(val3, tag3, out3);
	Return_Unify;
}

p_pxSplitPut(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxSplitPut(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxStringAlloc(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out4;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxStringAlloc(val1 . nint, val2 . nint, val3 . nint);
	Return_Unify_Integer(val4, tag4, out4);
}

p_pxStringDealloc(val1, tag1)
value	val1;
type	tag1;
{
	long		out1;

	Check_Output_Integer(tag1);
	out1 = (long	) pxStringDealloc();
	Return_Unify_Integer(val1, tag1, out1);
}

p_pxStringGet(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	char *	out1;
	long		out2;
	long		out3;
	Prepare_Requests;

	Check_Output_Atom(tag1);
	Check_Output_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxStringGet(&out1, &out2);
	Request_Unify_Atom(val1, tag1, in_dict(out1, 0));
	Request_Unify_Integer(val2, tag2, out2);
	Request_Unify_Integer(val3, tag3, out3);
	Return_Unify;
}

p_pxStringPutOne(val1, tag1)
value	val1;
type	tag1;
{

	Check_Atom_Or_Nil(val1, tag1);
	(void) pxStringPutOne(DidName(val1 . did));
	Succeed;
}

p_pxTextAlloc(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out4;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxTextAlloc(val1 . nint, val2 . nint, val3 . nint);
	Return_Unify_Integer(val4, tag4, out4);
}

p_pxTextPut(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6)
value	val1, val2, val3, val4, val5, val6;
type	tag1, tag2, tag3, tag4, tag5, tag6;
{
	long		out6;

	Check_Integer(tag1);
	Check_Atom_Or_Nil(val2, tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Output_Integer(tag6);
	out6 = (long	) pxTextPut(val1 . nint, DidName(val2 . did), val3 . nint, val4 . nint, val5 . nint);
	Return_Unify_Integer(val6, tag6, out6);
}

p_pxColorGet(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5)
value	val1, val2, val3, val4, val5;
type	tag1, tag2, tag3, tag4, tag5;
{
	long		out1;
	long		out2;
	long		out3;
	long		out4;
	long		out5;
	Prepare_Requests;

	Check_Output_Integer(tag1);
	Check_Output_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	Check_Output_Integer(tag5);
	out5 = (long	) pxColorGet(&out1, &out2, &out3, &out4);
	Request_Unify_Integer(val1, tag1, out1);
	Request_Unify_Integer(val2, tag2, out2);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Request_Unify_Integer(val5, tag5, out5);
	Return_Unify;
}

p_pxColorPut(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6)
value	val1, val2, val3, val4, val5, val6;
type	tag1, tag2, tag3, tag4, tag5, tag6;
{
	long		out6;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Output_Integer(tag6);
	out6 = (long	) pxColorPut(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint);
	Return_Unify_Integer(val6, tag6, out6);
}

p_pxListGet(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out1;
	long		out2;
	long		out3;
	Prepare_Requests;

	Check_Output_Integer(tag1);
	Check_Output_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxListGet(&out1, &out2);
	Request_Unify_Integer(val1, tag1, out1);
	Request_Unify_Integer(val2, tag2, out2);
	Request_Unify_Integer(val3, tag3, out3);
	Return_Unify;
}

p_pxGetEnvironment(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	char *	out2;
	long		out3;
	Prepare_Requests;

	Check_Atom_Or_Nil(val1, tag1);
	Check_Output_Atom(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxGetEnvironment(DidName(val1 . did), &out2);
	Request_Unify_Atom(val2, tag2, in_dict(out2, 0));
	Request_Unify_Integer(val3, tag3, out3);
	Return_Unify;
}

p_pxOpenConnection(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out2;
	long		out3;
	Prepare_Requests;

	Check_Atom_Or_Nil(val1, tag1);
	Check_Output_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxOpenConnection(DidName(val1 . did), &out2);
	Request_Unify_Integer(val2, tag2, out2);
	Request_Unify_Integer(val3, tag3, out3);
	Return_Unify;
}

p_pxCloseConnection(val1, tag1, val2, tag2)
value	val1, val2;
type	tag1, tag2;
{
	long		out2;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	out2 = (long	) pxCloseConnection(val1 . nint);
	Return_Unify_Integer(val2, tag2, out2);
}

p_pxConnections(val1, tag1)
value	val1;
type	tag1;
{
	long		out1;

	Check_Output_Integer(tag1);
	(void) pxConnections(&out1);
	Return_Unify_Integer(val1, tag1, out1);
}

p_pxGetConnectionAttribute(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6)
value	val1, val2, val3, val4, val5, val6;
type	tag1, tag2, tag3, tag4, tag5, tag6;
{
	char *	out3;
	long		out4;
	long		out5;
	long		out6;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Atom(tag3);
	Check_Output_Integer(tag4);
	Check_Output_Integer(tag5);
	Check_Output_Integer(tag6);
	out6 = (long	) pxGetConnectionAttribute(val1 . nint, val2 . nint, &out3, &out4, &out5);
	Request_Unify_Atom(val3, tag3, in_dict(out3, 0));
	Request_Unify_Integer(val4, tag4, out4);
	Request_Unify_Integer(val5, tag5, out5);
	Request_Unify_Integer(val6, tag6, out6);
	Return_Unify;
}

p_pxFormats(val1, tag1)
value	val1;
type	tag1;
{
	long		out1;

	Check_Output_Integer(tag1);
	(void) pxFormats(&out1);
	Return_Unify_Integer(val1, tag1, out1);
}

p_pxGetFormatAttribute(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out3;
	long		out4;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxGetFormatAttribute(val1 . nint, val2 . nint, &out3);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Return_Unify;
}

p_pxScreens(val1, tag1)
value	val1;
type	tag1;
{
	long		out1;

	Check_Output_Integer(tag1);
	(void) pxScreens(&out1);
	Return_Unify_Integer(val1, tag1, out1);
}

p_pxGetScreenAttribute(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out3;
	long		out4;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxGetScreenAttribute(val1 . nint, val2 . nint, &out3);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Return_Unify;
}

p_pxDepths(val1, tag1)
value	val1;
type	tag1;
{
	long		out1;

	Check_Output_Integer(tag1);
	(void) pxDepths(&out1);
	Return_Unify_Integer(val1, tag1, out1);
}

p_pxGetDepthAttribute(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out3;
	long		out4;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxGetDepthAttribute(val1 . nint, val2 . nint, &out3);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Return_Unify;
}

p_pxVisuals(val1, tag1)
value	val1;
type	tag1;
{
	long		out1;

	Check_Output_Integer(tag1);
	(void) pxVisuals(&out1);
	Return_Unify_Integer(val1, tag1, out1);
}

p_pxGetVisualAttribute(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out3;
	long		out4;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxGetVisualAttribute(val1 . nint, val2 . nint, &out3);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Return_Unify;
}

p_pxCreateWindow(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8, val9, tag9, val10, tag10, val11, tag11, val12, tag12)
value	val1, val2, val3, val4, val5, val6, val7, val8, val9, val10, val11, val12;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8, tag9, tag10, tag11, tag12;
{
	long		out11;
	long		out12;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Integer(tag6);
	Check_Integer(tag7);
	Check_Integer(tag8);
	Check_Integer(tag9);
	Check_Integer(tag10);
	Check_Output_Integer(tag11);
	Check_Output_Integer(tag12);
	out12 = (long	) pxCreateWindow(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint, val6 . nint, val7 . nint, val8 . nint, val9 . nint, val10 . nint, &out11);
	Request_Unify_Integer(val11, tag11, out11);
	Request_Unify_Integer(val12, tag12, out12);
	Return_Unify;
}

p_pxDestroyWindow(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxDestroyWindow(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxDestroySubwindows(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxDestroySubwindows(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxGetWindowAttribute(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out2;
	long		out3;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxGetWindowAttribute(val1 . nint, &out2);
	Request_Unify_Integer(val2, tag2, out2);
	Request_Unify_Integer(val3, tag3, out3);
	Return_Unify;
}

p_pxSetWindowAttribute(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxSetWindowAttribute(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxQueryWindow(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxQueryWindow(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxSetWindow(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxSetWindow(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxSetWMWindow(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out4;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxSetWMWindow(val1 . nint, val2 . nint, val3 . nint);
	Return_Unify_Integer(val4, tag4, out4);
}

p_pxQueryTree(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6)
value	val1, val2, val3, val4, val5, val6;
type	tag1, tag2, tag3, tag4, tag5, tag6;
{
	long		out3;
	long		out4;
	long		out5;
	long		out6;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	Check_Output_Integer(tag5);
	Check_Output_Integer(tag6);
	out6 = (long	) pxQueryTree(val1 . nint, val2 . nint, &out3, &out4, &out5);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Request_Unify_Integer(val5, tag5, out5);
	Request_Unify_Integer(val6, tag6, out6);
	Return_Unify;
}

p_pxTranslateCoordinates(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8, val9, tag9)
value	val1, val2, val3, val4, val5, val6, val7, val8, val9;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8, tag9;
{
	long		out6;
	long		out7;
	long		out8;
	long		out9;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Output_Integer(tag6);
	Check_Output_Integer(tag7);
	Check_Output_Integer(tag8);
	Check_Output_Integer(tag9);
	out9 = (long	) pxTranslateCoordinates(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint, &out6, &out7, &out8);
	Request_Unify_Integer(val6, tag6, out6);
	Request_Unify_Integer(val7, tag7, out7);
	Request_Unify_Integer(val8, tag8, out8);
	Request_Unify_Integer(val9, tag9, out9);
	Return_Unify;
}

p_pxMapWindow(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxMapWindow(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxMapSubwindows(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxMapSubwindows(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxUnmapWindow(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxUnmapWindow(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxUnmapSubwindows(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxUnmapSubwindows(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxCirculateSubwindows(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out4;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxCirculateSubwindows(val1 . nint, val2 . nint, val3 . nint);
	Return_Unify_Integer(val4, tag4, out4);
}

p_pxInternAtom(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5)
value	val1, val2, val3, val4, val5;
type	tag1, tag2, tag3, tag4, tag5;
{
	long		out4;
	long		out5;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Atom_Or_Nil(val2, tag2);
	Check_Integer(tag3);
	Check_Output_Integer(tag4);
	Check_Output_Integer(tag5);
	out5 = (long	) pxInternAtom(val1 . nint, DidName(val2 . did), val3 . nint, &out4);
	Request_Unify_Integer(val4, tag4, out4);
	Request_Unify_Integer(val5, tag5, out5);
	Return_Unify;
}

p_pxGetAtomName(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	char *	out3;
	long		out4;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Atom(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxGetAtomName(val1 . nint, val2 . nint, &out3);
	Request_Unify_Atom(val3, tag3, in_dict(out3, 0));
	Request_Unify_Integer(val4, tag4, out4);
	Return_Unify;
}

p_pxWindowProperties(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out3;
	long		out4;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxWindowProperties(val1 . nint, val2 . nint, &out3);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Return_Unify;
}

p_pxGetProperty(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8, val9, tag9, val10, tag10, val11, tag11, val12, tag12, val13, tag13, val14, tag14)
value	val1, val2, val3, val4, val5, val6, val7, val8, val9, val10, val11, val12, val13, val14;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8, tag9, tag10, tag11, tag12, tag13, tag14;
{
	long		out9;
	long		out10;
	long		out11;
	char *	out12;
	long		out13;
	long		out14;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Integer(tag6);
	Check_Integer(tag7);
	Check_Integer(tag8);
	Check_Output_Integer(tag9);
	Check_Output_Integer(tag10);
	Check_Output_Integer(tag11);
	Check_Output_Atom(tag12);
	Check_Output_Integer(tag13);
	Check_Output_Integer(tag14);
	out14 = (long	) pxGetProperty(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint, val6 . nint, val7 . nint, val8 . nint, &out9, &out10, &out11, &out12, &out13);
	Request_Unify_Integer(val9, tag9, out9);
	Request_Unify_Integer(val10, tag10, out10);
	Request_Unify_Integer(val11, tag11, out11);
	Request_Unify_Atom(val12, tag12, in_dict(out12, 0));
	Request_Unify_Integer(val13, tag13, out13);
	Request_Unify_Integer(val14, tag14, out14);
	Return_Unify;
}

p_pxSetProperty(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8)
value	val1, val2, val3, val4, val5, val6, val7, val8;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8;
{
	long		out8;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Integer(tag6);
	Check_Atom_Or_Nil(val7, tag7);
	Check_Output_Integer(tag8);
	out8 = (long	) pxSetProperty(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint, val6 . nint, DidName(val7 . did));
	Return_Unify_Integer(val8, tag8, out8);
}

p_pxDeleteProperty(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out4;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxDeleteProperty(val1 . nint, val2 . nint, val3 . nint);
	Return_Unify_Integer(val4, tag4, out4);
}

p_pxRotateProperties(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out4;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxRotateProperties(val1 . nint, val2 . nint, val3 . nint);
	Return_Unify_Integer(val4, tag4, out4);
}

p_pxGetSelectionOwner(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out3;
	long		out4;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxGetSelectionOwner(val1 . nint, val2 . nint, &out3);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Return_Unify;
}

p_pxSetSelectionOwner(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out4;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxSetSelectionOwner(val1 . nint, val2 . nint, val3 . nint);
	Return_Unify_Integer(val4, tag4, out4);
}

p_pxConvertSelection(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6)
value	val1, val2, val3, val4, val5, val6;
type	tag1, tag2, tag3, tag4, tag5, tag6;
{
	long		out6;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Output_Integer(tag6);
	out6 = (long	) pxConvertSelection(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint);
	Return_Unify_Integer(val6, tag6, out6);
}

p_pxCreatePixmap(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7)
value	val1, val2, val3, val4, val5, val6, val7;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7;
{
	long		out6;
	long		out7;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Output_Integer(tag6);
	Check_Output_Integer(tag7);
	out7 = (long	) pxCreatePixmap(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint, &out6);
	Request_Unify_Integer(val6, tag6, out6);
	Request_Unify_Integer(val7, tag7, out7);
	Return_Unify;
}

p_pxDestroyPixmap(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxDestroyPixmap(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxGetPixmapAttribute(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out2;
	long		out3;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxGetPixmapAttribute(val1 . nint, &out2);
	Request_Unify_Integer(val2, tag2, out2);
	Request_Unify_Integer(val3, tag3, out3);
	Return_Unify;
}

p_pxQueryPixmap(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxQueryPixmap(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxCreateColormap(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6)
value	val1, val2, val3, val4, val5, val6;
type	tag1, tag2, tag3, tag4, tag5, tag6;
{
	long		out5;
	long		out6;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Output_Integer(tag5);
	Check_Output_Integer(tag6);
	out6 = (long	) pxCreateColormap(val1 . nint, val2 . nint, val3 . nint, val4 . nint, &out5);
	Request_Unify_Integer(val5, tag5, out5);
	Request_Unify_Integer(val6, tag6, out6);
	Return_Unify;
}

p_pxDestroyColormap(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxDestroyColormap(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxMoveToNewColormap(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out3;
	long		out4;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxMoveToNewColormap(val1 . nint, val2 . nint, &out3);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Return_Unify;
}

p_pxLoadedColormaps(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out3;
	long		out4;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxLoadedColormaps(val1 . nint, val2 . nint, &out3);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Return_Unify;
}

p_pxLoadColormap(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxLoadColormap(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxUnloadColormap(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxUnloadColormap(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxParseColor(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7)
value	val1, val2, val3, val4, val5, val6, val7;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7;
{
	long		out4;
	long		out5;
	long		out6;
	long		out7;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Atom_Or_Nil(val3, tag3);
	Check_Output_Integer(tag4);
	Check_Output_Integer(tag5);
	Check_Output_Integer(tag6);
	Check_Output_Integer(tag7);
	out7 = (long	) pxParseColor(val1 . nint, val2 . nint, DidName(val3 . did), &out4, &out5, &out6);
	Request_Unify_Integer(val4, tag4, out4);
	Request_Unify_Integer(val5, tag5, out5);
	Request_Unify_Integer(val6, tag6, out6);
	Request_Unify_Integer(val7, tag7, out7);
	Return_Unify;
}

p_pxQueryColor(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8, val9, tag9, val10, tag10)
value	val1, val2, val3, val4, val5, val6, val7, val8, val9, val10;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8, tag9, tag10;
{
	long		out4;
	long		out5;
	long		out6;
	long		out7;
	long		out8;
	long		out9;
	long		out10;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Atom_Or_Nil(val3, tag3);
	Check_Output_Integer(tag4);
	Check_Output_Integer(tag5);
	Check_Output_Integer(tag6);
	Check_Output_Integer(tag7);
	Check_Output_Integer(tag8);
	Check_Output_Integer(tag9);
	Check_Output_Integer(tag10);
	out10 = (long	) pxQueryColor(val1 . nint, val2 . nint, DidName(val3 . did), &out4, &out5, &out6, &out7, &out8, &out9);
	Request_Unify_Integer(val4, tag4, out4);
	Request_Unify_Integer(val5, tag5, out5);
	Request_Unify_Integer(val6, tag6, out6);
	Request_Unify_Integer(val7, tag7, out7);
	Request_Unify_Integer(val8, tag8, out8);
	Request_Unify_Integer(val9, tag9, out9);
	Request_Unify_Integer(val10, tag10, out10);
	Return_Unify;
}

p_pxGetColors(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxGetColors(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxRequestColor(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8, val9, tag9, val10, tag10)
value	val1, val2, val3, val4, val5, val6, val7, val8, val9, val10;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8, tag9, tag10;
{
	long		out6;
	long		out7;
	long		out8;
	long		out9;
	long		out10;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Output_Integer(tag6);
	Check_Output_Integer(tag7);
	Check_Output_Integer(tag8);
	Check_Output_Integer(tag9);
	Check_Output_Integer(tag10);
	out10 = (long	) pxRequestColor(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint, &out6, &out7, &out8, &out9);
	Request_Unify_Integer(val6, tag6, out6);
	Request_Unify_Integer(val7, tag7, out7);
	Request_Unify_Integer(val8, tag8, out8);
	Request_Unify_Integer(val9, tag9, out9);
	Request_Unify_Integer(val10, tag10, out10);
	Return_Unify;
}

p_pxRequestNamedColor(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8, val9, tag9, val10, tag10, val11, tag11)
value	val1, val2, val3, val4, val5, val6, val7, val8, val9, val10, val11;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8, tag9, tag10, tag11;
{
	long		out4;
	long		out5;
	long		out6;
	long		out7;
	long		out8;
	long		out9;
	long		out10;
	long		out11;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Atom_Or_Nil(val3, tag3);
	Check_Output_Integer(tag4);
	Check_Output_Integer(tag5);
	Check_Output_Integer(tag6);
	Check_Output_Integer(tag7);
	Check_Output_Integer(tag8);
	Check_Output_Integer(tag9);
	Check_Output_Integer(tag10);
	Check_Output_Integer(tag11);
	out11 = (long	) pxRequestNamedColor(val1 . nint, val2 . nint, DidName(val3 . did), &out4, &out5, &out6, &out7, &out8, &out9, &out10);
	Request_Unify_Integer(val4, tag4, out4);
	Request_Unify_Integer(val5, tag5, out5);
	Request_Unify_Integer(val6, tag6, out6);
	Request_Unify_Integer(val7, tag7, out7);
	Request_Unify_Integer(val8, tag8, out8);
	Request_Unify_Integer(val9, tag9, out9);
	Request_Unify_Integer(val10, tag10, out10);
	Request_Unify_Integer(val11, tag11, out11);
	Return_Unify;
}

p_pxFreeColors(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out4;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxFreeColors(val1 . nint, val2 . nint, val3 . nint);
	Return_Unify_Integer(val4, tag4, out4);
}

p_pxAllocColorCells(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6)
value	val1, val2, val3, val4, val5, val6;
type	tag1, tag2, tag3, tag4, tag5, tag6;
{
	long		out6;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Output_Integer(tag6);
	out6 = (long	) pxAllocColorCells(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint);
	Return_Unify_Integer(val6, tag6, out6);
}

p_pxAllocColorPlanes(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8, val9, tag9, val10, tag10, val11, tag11)
value	val1, val2, val3, val4, val5, val6, val7, val8, val9, val10, val11;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8, tag9, tag10, tag11;
{
	long		out8;
	long		out9;
	long		out10;
	long		out11;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Integer(tag6);
	Check_Integer(tag7);
	Check_Output_Integer(tag8);
	Check_Output_Integer(tag9);
	Check_Output_Integer(tag10);
	Check_Output_Integer(tag11);
	out11 = (long	) pxAllocColorPlanes(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint, val6 . nint, val7 . nint, &out8, &out9, &out10);
	Request_Unify_Integer(val8, tag8, out8);
	Request_Unify_Integer(val9, tag9, out9);
	Request_Unify_Integer(val10, tag10, out10);
	Request_Unify_Integer(val11, tag11, out11);
	Return_Unify;
}

p_pxSetColors(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxSetColors(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxSetNamedColor(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6)
value	val1, val2, val3, val4, val5, val6;
type	tag1, tag2, tag3, tag4, tag5, tag6;
{
	long		out6;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Atom_Or_Nil(val3, tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Output_Integer(tag6);
	out6 = (long	) pxSetNamedColor(val1 . nint, val2 . nint, DidName(val3 . did), val4 . nint, val5 . nint);
	Return_Unify_Integer(val6, tag6, out6);
}

p_pxGCs(val1, tag1)
value	val1;
type	tag1;
{
	long		out1;

	Check_Output_Integer(tag1);
	(void) pxGCs(&out1);
	Return_Unify_Integer(val1, tag1, out1);
}

p_pxCreateGC(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out3;
	long		out4;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxCreateGC(val1 . nint, val2 . nint, &out3);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Return_Unify;
}

p_pxDestroyGC(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxDestroyGC(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxCopyGC(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5)
value	val1, val2, val3, val4, val5;
type	tag1, tag2, tag3, tag4, tag5;
{
	long		out5;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Output_Integer(tag5);
	out5 = (long	) pxCopyGC(val1 . nint, val2 . nint, val3 . nint, val4 . nint);
	Return_Unify_Integer(val5, tag5, out5);
}

p_pxGetGCAttribute(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out3;
	long		out4;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxGetGCAttribute(val1 . nint, val2 . nint, &out3);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Return_Unify;
}

p_pxQueryBestSize(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8)
value	val1, val2, val3, val4, val5, val6, val7, val8;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8;
{
	long		out6;
	long		out7;
	long		out8;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Output_Integer(tag6);
	Check_Output_Integer(tag7);
	Check_Output_Integer(tag8);
	out8 = (long	) pxQueryBestSize(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint, &out6, &out7);
	Request_Unify_Integer(val6, tag6, out6);
	Request_Unify_Integer(val7, tag7, out7);
	Request_Unify_Integer(val8, tag8, out8);
	Return_Unify;
}

p_pxSetGCAttribute(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxSetGCAttribute(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxSetGC(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxSetGC(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxSetClips(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6)
value	val1, val2, val3, val4, val5, val6;
type	tag1, tag2, tag3, tag4, tag5, tag6;
{
	long		out6;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Output_Integer(tag6);
	out6 = (long	) pxSetClips(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint);
	Return_Unify_Integer(val6, tag6, out6);
}

p_pxSetDashes(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out4;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxSetDashes(val1 . nint, val2 . nint, val3 . nint);
	Return_Unify_Integer(val4, tag4, out4);
}

p_pxClearArea(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8)
value	val1, val2, val3, val4, val5, val6, val7, val8;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8;
{
	long		out8;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Integer(tag6);
	Check_Integer(tag7);
	Check_Output_Integer(tag8);
	out8 = (long	) pxClearArea(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint, val6 . nint, val7 . nint);
	Return_Unify_Integer(val8, tag8, out8);
}

p_pxCopyArea(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8, val9, tag9, val10, tag10, val11, tag11)
value	val1, val2, val3, val4, val5, val6, val7, val8, val9, val10, val11;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8, tag9, tag10, tag11;
{
	long		out11;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Integer(tag6);
	Check_Integer(tag7);
	Check_Integer(tag8);
	Check_Integer(tag9);
	Check_Integer(tag10);
	Check_Output_Integer(tag11);
	out11 = (long	) pxCopyArea(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint, val6 . nint, val7 . nint, val8 . nint, val9 . nint, val10 . nint);
	Return_Unify_Integer(val11, tag11, out11);
}

p_pxCopyPlane(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8, val9, tag9, val10, tag10, val11, tag11, val12, tag12)
value	val1, val2, val3, val4, val5, val6, val7, val8, val9, val10, val11, val12;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8, tag9, tag10, tag11, tag12;
{
	long		out12;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Integer(tag6);
	Check_Integer(tag7);
	Check_Integer(tag8);
	Check_Integer(tag9);
	Check_Integer(tag10);
	Check_Integer(tag11);
	Check_Output_Integer(tag12);
	out12 = (long	) pxCopyPlane(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint, val6 . nint, val7 . nint, val8 . nint, val9 . nint, val10 . nint, val11 . nint);
	Return_Unify_Integer(val12, tag12, out12);
}

p_pxDrawPoints(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5)
value	val1, val2, val3, val4, val5;
type	tag1, tag2, tag3, tag4, tag5;
{
	long		out5;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Output_Integer(tag5);
	out5 = (long	) pxDrawPoints(val1 . nint, val2 . nint, val3 . nint, val4 . nint);
	Return_Unify_Integer(val5, tag5, out5);
}

p_pxDrawLines(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5)
value	val1, val2, val3, val4, val5;
type	tag1, tag2, tag3, tag4, tag5;
{
	long		out5;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Output_Integer(tag5);
	out5 = (long	) pxDrawLines(val1 . nint, val2 . nint, val3 . nint, val4 . nint);
	Return_Unify_Integer(val5, tag5, out5);
}

p_pxDrawSegments(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out4;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxDrawSegments(val1 . nint, val2 . nint, val3 . nint);
	Return_Unify_Integer(val4, tag4, out4);
}

p_pxDrawRectangles(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out4;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxDrawRectangles(val1 . nint, val2 . nint, val3 . nint);
	Return_Unify_Integer(val4, tag4, out4);
}

p_pxDrawArcs(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out4;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxDrawArcs(val1 . nint, val2 . nint, val3 . nint);
	Return_Unify_Integer(val4, tag4, out4);
}

p_pxFillRectangles(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out4;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxFillRectangles(val1 . nint, val2 . nint, val3 . nint);
	Return_Unify_Integer(val4, tag4, out4);
}

p_pxFillPolygon(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6)
value	val1, val2, val3, val4, val5, val6;
type	tag1, tag2, tag3, tag4, tag5, tag6;
{
	long		out6;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Output_Integer(tag6);
	out6 = (long	) pxFillPolygon(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint);
	Return_Unify_Integer(val6, tag6, out6);
}

p_pxFillArcs(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out4;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxFillArcs(val1 . nint, val2 . nint, val3 . nint);
	Return_Unify_Integer(val4, tag4, out4);
}

p_pxImages(val1, tag1)
value	val1;
type	tag1;
{
	long		out1;

	Check_Output_Integer(tag1);
	(void) pxImages(&out1);
	Return_Unify_Integer(val1, tag1, out1);
}

p_pxCreateImage(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8, val9, tag9, val10, tag10, val11, tag11)
value	val1, val2, val3, val4, val5, val6, val7, val8, val9, val10, val11;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8, tag9, tag10, tag11;
{
	long		out10;
	long		out11;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Integer(tag6);
	Check_Integer(tag7);
	Check_Integer(tag8);
	Check_Integer(tag9);
	Check_Output_Integer(tag10);
	Check_Output_Integer(tag11);
	out11 = (long	) pxCreateImage(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint, val6 . nint, val7 . nint, val8 . nint, val9 . nint, &out10);
	Request_Unify_Integer(val10, tag10, out10);
	Request_Unify_Integer(val11, tag11, out11);
	Return_Unify;
}

p_pxDestroyImage(val1, tag1, val2, tag2)
value	val1, val2;
type	tag1, tag2;
{
	long		out2;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	out2 = (long	) pxDestroyImage(val1 . nint);
	Return_Unify_Integer(val2, tag2, out2);
}

p_pxGetImageAttribute(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out3;
	long		out4;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxGetImageAttribute(val1 . nint, val2 . nint, &out3);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Return_Unify;
}

p_pxGetImage(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8, val9, tag9, val10, tag10, val11, tag11)
value	val1, val2, val3, val4, val5, val6, val7, val8, val9, val10, val11;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8, tag9, tag10, tag11;
{
	long		out11;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Integer(tag6);
	Check_Integer(tag7);
	Check_Integer(tag8);
	Check_Integer(tag9);
	Check_Integer(tag10);
	Check_Output_Integer(tag11);
	out11 = (long	) pxGetImage(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint, val6 . nint, val7 . nint, val8 . nint, val9 . nint, val10 . nint);
	Return_Unify_Integer(val11, tag11, out11);
}

p_pxPutImage(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8, val9, tag9, val10, tag10, val11, tag11)
value	val1, val2, val3, val4, val5, val6, val7, val8, val9, val10, val11;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8, tag9, tag10, tag11;
{
	long		out11;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Integer(tag6);
	Check_Integer(tag7);
	Check_Integer(tag8);
	Check_Integer(tag9);
	Check_Integer(tag10);
	Check_Output_Integer(tag11);
	out11 = (long	) pxPutImage(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint, val6 . nint, val7 . nint, val8 . nint, val9 . nint, val10 . nint);
	Return_Unify_Integer(val11, tag11, out11);
}

p_pxSubImage(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7)
value	val1, val2, val3, val4, val5, val6, val7;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7;
{
	long		out6;
	long		out7;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Output_Integer(tag6);
	Check_Output_Integer(tag7);
	out7 = (long	) pxSubImage(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint, &out6);
	Request_Unify_Integer(val6, tag6, out6);
	Request_Unify_Integer(val7, tag7, out7);
	Return_Unify;
}

p_pxAddPixel(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxAddPixel(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxGetPixel(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5)
value	val1, val2, val3, val4, val5;
type	tag1, tag2, tag3, tag4, tag5;
{
	long		out4;
	long		out5;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Output_Integer(tag4);
	Check_Output_Integer(tag5);
	out5 = (long	) pxGetPixel(val1 . nint, val2 . nint, val3 . nint, &out4);
	Request_Unify_Integer(val4, tag4, out4);
	Request_Unify_Integer(val5, tag5, out5);
	Return_Unify;
}

p_pxSetPixel(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5)
value	val1, val2, val3, val4, val5;
type	tag1, tag2, tag3, tag4, tag5;
{
	long		out5;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Output_Integer(tag5);
	out5 = (long	) pxSetPixel(val1 . nint, val2 . nint, val3 . nint, val4 . nint);
	Return_Unify_Integer(val5, tag5, out5);
}

p_pxOpenFont(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out3;
	long		out4;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Atom_Or_Nil(val2, tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxOpenFont(val1 . nint, DidName(val2 . did), &out3);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Return_Unify;
}

p_pxCloseFont(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxCloseFont(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxLoadedFonts(val1, tag1)
value	val1;
type	tag1;
{
	long		out1;

	Check_Output_Integer(tag1);
	(void) pxLoadedFonts(&out1);
	Return_Unify_Integer(val1, tag1, out1);
}

p_pxLoadFont(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out3;
	long		out4;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxLoadFont(val1 . nint, val2 . nint, &out3);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Return_Unify;
}

p_pxUnloadFont(val1, tag1, val2, tag2)
value	val1, val2;
type	tag1, tag2;
{
	long		out2;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	out2 = (long	) pxUnloadFont(val1 . nint);
	Return_Unify_Integer(val2, tag2, out2);
}

p_pxGetFontPath(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out2;
	long		out3;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxGetFontPath(val1 . nint, &out2);
	Request_Unify_Integer(val2, tag2, out2);
	Request_Unify_Integer(val3, tag3, out3);
	Return_Unify;
}

p_pxSetFontPath(val1, tag1, val2, tag2)
value	val1, val2;
type	tag1, tag2;
{
	long		out2;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	out2 = (long	) pxSetFontPath(val1 . nint);
	Return_Unify_Integer(val2, tag2, out2);
}

p_pxListFonts(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5)
value	val1, val2, val3, val4, val5;
type	tag1, tag2, tag3, tag4, tag5;
{
	long		out4;
	long		out5;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Atom_Or_Nil(val2, tag2);
	Check_Integer(tag3);
	Check_Output_Integer(tag4);
	Check_Output_Integer(tag5);
	out5 = (long	) pxListFonts(val1 . nint, DidName(val2 . did), val3 . nint, &out4);
	Request_Unify_Integer(val4, tag4, out4);
	Request_Unify_Integer(val5, tag5, out5);
	Return_Unify;
}

p_pxGetFontAttribute(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out3;
	long		out4;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxGetFontAttribute(val1 . nint, val2 . nint, &out3);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Return_Unify;
}

p_pxGetFontProperty(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out3;
	long		out4;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxGetFontProperty(val1 . nint, val2 . nint, &out3);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Return_Unify;
}

p_pxGetCharInfo(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8, val9, tag9)
value	val1, val2, val3, val4, val5, val6, val7, val8, val9;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8, tag9;
{
	long		out3;
	long		out4;
	long		out5;
	long		out6;
	long		out7;
	long		out8;
	long		out9;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	Check_Output_Integer(tag5);
	Check_Output_Integer(tag6);
	Check_Output_Integer(tag7);
	Check_Output_Integer(tag8);
	Check_Output_Integer(tag9);
	out9 = (long	) pxGetCharInfo(val1 . nint, val2 . nint, &out3, &out4, &out5, &out6, &out7, &out8);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Request_Unify_Integer(val5, tag5, out5);
	Request_Unify_Integer(val6, tag6, out6);
	Request_Unify_Integer(val7, tag7, out7);
	Request_Unify_Integer(val8, tag8, out8);
	Request_Unify_Integer(val9, tag9, out9);
	Return_Unify;
}

p_pxTextExtents(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8, val9, tag9)
value	val1, val2, val3, val4, val5, val6, val7, val8, val9;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8, tag9;
{
	long		out4;
	long		out5;
	long		out6;
	long		out7;
	long		out8;
	long		out9;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Atom_Or_Nil(val3, tag3);
	Check_Output_Integer(tag4);
	Check_Output_Integer(tag5);
	Check_Output_Integer(tag6);
	Check_Output_Integer(tag7);
	Check_Output_Integer(tag8);
	Check_Output_Integer(tag9);
	out9 = (long	) pxTextExtents(val1 . nint, val2 . nint, DidName(val3 . did), &out4, &out5, &out6, &out7, &out8);
	Request_Unify_Integer(val4, tag4, out4);
	Request_Unify_Integer(val5, tag5, out5);
	Request_Unify_Integer(val6, tag6, out6);
	Request_Unify_Integer(val7, tag7, out7);
	Request_Unify_Integer(val8, tag8, out8);
	Request_Unify_Integer(val9, tag9, out9);
	Return_Unify;
}

p_pxDrawText(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6)
value	val1, val2, val3, val4, val5, val6;
type	tag1, tag2, tag3, tag4, tag5, tag6;
{
	long		out6;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Output_Integer(tag6);
	out6 = (long	) pxDrawText(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint);
	Return_Unify_Integer(val6, tag6, out6);
}

p_pxImageText(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8)
value	val1, val2, val3, val4, val5, val6, val7, val8;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8;
{
	long		out8;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Integer(tag6);
	Check_Atom_Or_Nil(val7, tag7);
	Check_Output_Integer(tag8);
	out8 = (long	) pxImageText(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint, val6 . nint, DidName(val7 . did));
	Return_Unify_Integer(val8, tag8, out8);
}

p_pxCreateFontCursor(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out3;
	long		out4;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxCreateFontCursor(val1 . nint, val2 . nint, &out3);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Return_Unify;
}

p_pxCreateGlyphCursor(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8, val9, tag9, val10, tag10, val11, tag11, val12, tag12, val13, tag13)
value	val1, val2, val3, val4, val5, val6, val7, val8, val9, val10, val11, val12, val13;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8, tag9, tag10, tag11, tag12, tag13;
{
	long		out12;
	long		out13;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Integer(tag6);
	Check_Integer(tag7);
	Check_Integer(tag8);
	Check_Integer(tag9);
	Check_Integer(tag10);
	Check_Integer(tag11);
	Check_Output_Integer(tag12);
	Check_Output_Integer(tag13);
	out13 = (long	) pxCreateGlyphCursor(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint, val6 . nint, val7 . nint, val8 . nint, val9 . nint, val10 . nint, val11 . nint, &out12);
	Request_Unify_Integer(val12, tag12, out12);
	Request_Unify_Integer(val13, tag13, out13);
	Return_Unify;
}

p_pxCreatePixmapCursor(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8, val9, tag9, val10, tag10, val11, tag11, val12, tag12, val13, tag13)
value	val1, val2, val3, val4, val5, val6, val7, val8, val9, val10, val11, val12, val13;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8, tag9, tag10, tag11, tag12, tag13;
{
	long		out12;
	long		out13;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Integer(tag6);
	Check_Integer(tag7);
	Check_Integer(tag8);
	Check_Integer(tag9);
	Check_Integer(tag10);
	Check_Integer(tag11);
	Check_Output_Integer(tag12);
	Check_Output_Integer(tag13);
	out13 = (long	) pxCreatePixmapCursor(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint, val6 . nint, val7 . nint, val8 . nint, val9 . nint, val10 . nint, val11 . nint, &out12);
	Request_Unify_Integer(val12, tag12, out12);
	Request_Unify_Integer(val13, tag13, out13);
	Return_Unify;
}

p_pxDestroyCursor(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxDestroyCursor(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxRecolorCursor(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8, val9, tag9)
value	val1, val2, val3, val4, val5, val6, val7, val8, val9;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8, tag9;
{
	long		out9;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Integer(tag6);
	Check_Integer(tag7);
	Check_Integer(tag8);
	Check_Output_Integer(tag9);
	out9 = (long	) pxRecolorCursor(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint, val6 . nint, val7 . nint, val8 . nint);
	Return_Unify_Integer(val9, tag9, out9);
}

p_pxPointerState(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8, val9, tag9, val10, tag10)
value	val1, val2, val3, val4, val5, val6, val7, val8, val9, val10;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8, tag9, tag10;
{
	long		out3;
	long		out4;
	long		out5;
	long		out6;
	long		out7;
	long		out8;
	long		out9;
	long		out10;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	Check_Output_Integer(tag5);
	Check_Output_Integer(tag6);
	Check_Output_Integer(tag7);
	Check_Output_Integer(tag8);
	Check_Output_Integer(tag9);
	Check_Output_Integer(tag10);
	out10 = (long	) pxPointerState(val1 . nint, val2 . nint, &out3, &out4, &out5, &out6, &out7, &out8, &out9);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Request_Unify_Integer(val5, tag5, out5);
	Request_Unify_Integer(val6, tag6, out6);
	Request_Unify_Integer(val7, tag7, out7);
	Request_Unify_Integer(val8, tag8, out8);
	Request_Unify_Integer(val9, tag9, out9);
	Request_Unify_Integer(val10, tag10, out10);
	Return_Unify;
}

p_pxWarpPointer(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8, val9, tag9, val10, tag10)
value	val1, val2, val3, val4, val5, val6, val7, val8, val9, val10;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8, tag9, tag10;
{
	long		out10;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Integer(tag6);
	Check_Integer(tag7);
	Check_Integer(tag8);
	Check_Integer(tag9);
	Check_Output_Integer(tag10);
	out10 = (long	) pxWarpPointer(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint, val6 . nint, val7 . nint, val8 . nint, val9 . nint);
	Return_Unify_Integer(val10, tag10, out10);
}

p_pxGetPointerAttribute(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out2;
	long		out3;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxGetPointerAttribute(val1 . nint, &out2);
	Request_Unify_Integer(val2, tag2, out2);
	Request_Unify_Integer(val3, tag3, out3);
	Return_Unify;
}

p_pxSetPointerAttribute(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxSetPointerAttribute(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxQueryPointer(val1, tag1, val2, tag2)
value	val1, val2;
type	tag1, tag2;
{
	long		out2;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	out2 = (long	) pxQueryPointer(val1 . nint);
	Return_Unify_Integer(val2, tag2, out2);
}

p_pxSetPointer(val1, tag1, val2, tag2)
value	val1, val2;
type	tag1, tag2;
{
	long		out2;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	out2 = (long	) pxSetPointer(val1 . nint);
	Return_Unify_Integer(val2, tag2, out2);
}

p_pxGetPointerMapping(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxGetPointerMapping(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxSetPointerMapping(val1, tag1, val2, tag2)
value	val1, val2;
type	tag1, tag2;
{
	long		out2;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	out2 = (long	) pxSetPointerMapping(val1 . nint);
	Return_Unify_Integer(val2, tag2, out2);
}

p_pxDownKeymap(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out2;
	long		out3;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxDownKeymap(val1 . nint, &out2);
	Request_Unify_Integer(val2, tag2, out2);
	Request_Unify_Integer(val3, tag3, out3);
	Return_Unify;
}

p_pxGetKeyboardAttribute(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out2;
	long		out3;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxGetKeyboardAttribute(val1 . nint, &out2);
	Request_Unify_Integer(val2, tag2, out2);
	Request_Unify_Integer(val3, tag3, out3);
	Return_Unify;
}

p_pxSetKeyboardAttribute(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxSetKeyboardAttribute(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxQueryKeyboard(val1, tag1, val2, tag2)
value	val1, val2;
type	tag1, tag2;
{
	long		out2;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	out2 = (long	) pxQueryKeyboard(val1 . nint);
	Return_Unify_Integer(val2, tag2, out2);
}

p_pxSetKeyboard(val1, tag1, val2, tag2)
value	val1, val2;
type	tag1, tag2;
{
	long		out2;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	out2 = (long	) pxSetKeyboard(val1 . nint);
	Return_Unify_Integer(val2, tag2, out2);
}

p_pxGetKeyboardMapping(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6)
value	val1, val2, val3, val4, val5, val6;
type	tag1, tag2, tag3, tag4, tag5, tag6;
{
	long		out4;
	long		out5;
	long		out6;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Output_Integer(tag4);
	Check_Output_Integer(tag5);
	Check_Output_Integer(tag6);
	out6 = (long	) pxGetKeyboardMapping(val1 . nint, val2 . nint, val3 . nint, &out4, &out5);
	Request_Unify_Integer(val4, tag4, out4);
	Request_Unify_Integer(val5, tag5, out5);
	Request_Unify_Integer(val6, tag6, out6);
	Return_Unify;
}

p_pxSetKeyboardMapping(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5)
value	val1, val2, val3, val4, val5;
type	tag1, tag2, tag3, tag4, tag5;
{
	long		out5;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Output_Integer(tag5);
	out5 = (long	) pxSetKeyboardMapping(val1 . nint, val2 . nint, val3 . nint, val4 . nint);
	Return_Unify_Integer(val5, tag5, out5);
}

p_pxGetModifierMapping(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out2;
	long		out3;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxGetModifierMapping(val1 . nint, &out2);
	Request_Unify_Integer(val2, tag2, out2);
	Request_Unify_Integer(val3, tag3, out3);
	Return_Unify;
}

p_pxSetModifierMapping(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out3;
	long		out4;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxSetModifierMapping(val1 . nint, val2 . nint, &out3);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Return_Unify;
}

p_pxBell(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxBell(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxKeycodeToKeysym(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5)
value	val1, val2, val3, val4, val5;
type	tag1, tag2, tag3, tag4, tag5;
{
	long		out4;
	long		out5;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Output_Integer(tag4);
	Check_Output_Integer(tag5);
	out5 = (long	) pxKeycodeToKeysym(val1 . nint, val2 . nint, val3 . nint, &out4);
	Request_Unify_Integer(val4, tag4, out4);
	Request_Unify_Integer(val5, tag5, out5);
	Return_Unify;
}

p_pxKeysymToKeycode(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out3;
	long		out4;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxKeysymToKeycode(val1 . nint, val2 . nint, &out3);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Return_Unify;
}

p_pxRefreshMapping(val1, tag1)
value	val1;
type	tag1;
{
	long		out1;

	Check_Output_Integer(tag1);
	out1 = (long	) pxRefreshMapping();
	Return_Unify_Integer(val1, tag1, out1);
}

p_pxSetSaveSet(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out4;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxSetSaveSet(val1 . nint, val2 . nint, val3 . nint);
	Return_Unify_Integer(val4, tag4, out4);
}

p_pxReparentWindow(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6)
value	val1, val2, val3, val4, val5, val6;
type	tag1, tag2, tag3, tag4, tag5, tag6;
{
	long		out6;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Output_Integer(tag6);
	out6 = (long	) pxReparentWindow(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint);
	Return_Unify_Integer(val6, tag6, out6);
}

p_pxSetCloseDownMode(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxSetCloseDownMode(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxKillClient(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxKillClient(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxGetInputFocus(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out2;
	long		out3;
	long		out4;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxGetInputFocus(val1 . nint, &out2, &out3);
	Request_Unify_Integer(val2, tag2, out2);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Return_Unify;
}

p_pxSetInputFocus(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out4;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxSetInputFocus(val1 . nint, val2 . nint, val3 . nint);
	Return_Unify_Integer(val4, tag4, out4);
}

p_pxGrabPointer(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8, val9, tag9, val10, tag10)
value	val1, val2, val3, val4, val5, val6, val7, val8, val9, val10;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8, tag9, tag10;
{
	long		out9;
	long		out10;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Integer(tag6);
	Check_Integer(tag7);
	Check_Integer(tag8);
	Check_Output_Integer(tag9);
	Check_Output_Integer(tag10);
	out10 = (long	) pxGrabPointer(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint, val6 . nint, val7 . nint, val8 . nint, &out9);
	Request_Unify_Integer(val9, tag9, out9);
	Request_Unify_Integer(val10, tag10, out10);
	Return_Unify;
}

p_pxUngrabPointer(val1, tag1, val2, tag2)
value	val1, val2;
type	tag1, tag2;
{
	long		out2;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	out2 = (long	) pxUngrabPointer(val1 . nint);
	Return_Unify_Integer(val2, tag2, out2);
}

p_pxSetActivePointer(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out4;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxSetActivePointer(val1 . nint, val2 . nint, val3 . nint);
	Return_Unify_Integer(val4, tag4, out4);
}

p_pxGrabButton(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8, val9, tag9, val10, tag10, val11, tag11)
value	val1, val2, val3, val4, val5, val6, val7, val8, val9, val10, val11;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8, tag9, tag10, tag11;
{
	long		out11;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Integer(tag6);
	Check_Integer(tag7);
	Check_Integer(tag8);
	Check_Integer(tag9);
	Check_Integer(tag10);
	Check_Output_Integer(tag11);
	out11 = (long	) pxGrabButton(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint, val6 . nint, val7 . nint, val8 . nint, val9 . nint, val10 . nint);
	Return_Unify_Integer(val11, tag11, out11);
}

p_pxUngrabButton(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5)
value	val1, val2, val3, val4, val5;
type	tag1, tag2, tag3, tag4, tag5;
{
	long		out5;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Output_Integer(tag5);
	out5 = (long	) pxUngrabButton(val1 . nint, val2 . nint, val3 . nint, val4 . nint);
	Return_Unify_Integer(val5, tag5, out5);
}

p_pxGrabKeyboard(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7)
value	val1, val2, val3, val4, val5, val6, val7;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7;
{
	long		out6;
	long		out7;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Output_Integer(tag6);
	Check_Output_Integer(tag7);
	out7 = (long	) pxGrabKeyboard(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint, &out6);
	Request_Unify_Integer(val6, tag6, out6);
	Request_Unify_Integer(val7, tag7, out7);
	Return_Unify;
}

p_pxUngrabKeyboard(val1, tag1, val2, tag2)
value	val1, val2;
type	tag1, tag2;
{
	long		out2;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	out2 = (long	) pxUngrabKeyboard(val1 . nint);
	Return_Unify_Integer(val2, tag2, out2);
}

p_pxGrabKey(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8)
value	val1, val2, val3, val4, val5, val6, val7, val8;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8;
{
	long		out8;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Integer(tag6);
	Check_Integer(tag7);
	Check_Output_Integer(tag8);
	out8 = (long	) pxGrabKey(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint, val6 . nint, val7 . nint);
	Return_Unify_Integer(val8, tag8, out8);
}

p_pxUngrabKey(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5)
value	val1, val2, val3, val4, val5;
type	tag1, tag2, tag3, tag4, tag5;
{
	long		out5;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Output_Integer(tag5);
	out5 = (long	) pxUngrabKey(val1 . nint, val2 . nint, val3 . nint, val4 . nint);
	Return_Unify_Integer(val5, tag5, out5);
}

p_pxAllowEvents(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxAllowEvents(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxGrabServer(val1, tag1, val2, tag2)
value	val1, val2;
type	tag1, tag2;
{
	long		out2;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	out2 = (long	) pxGrabServer(val1 . nint);
	Return_Unify_Integer(val2, tag2, out2);
}

p_pxUngrabServer(val1, tag1, val2, tag2)
value	val1, val2;
type	tag1, tag2;
{
	long		out2;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	out2 = (long	) pxUngrabServer(val1 . nint);
	Return_Unify_Integer(val2, tag2, out2);
}

p_pxGetScreenSaver(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6)
value	val1, val2, val3, val4, val5, val6;
type	tag1, tag2, tag3, tag4, tag5, tag6;
{
	long		out2;
	long		out3;
	long		out4;
	long		out5;
	long		out6;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	Check_Output_Integer(tag5);
	Check_Output_Integer(tag6);
	out6 = (long	) pxGetScreenSaver(val1 . nint, &out2, &out3, &out4, &out5);
	Request_Unify_Integer(val2, tag2, out2);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Request_Unify_Integer(val5, tag5, out5);
	Request_Unify_Integer(val6, tag6, out6);
	Return_Unify;
}

p_pxSetScreenSaver(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6)
value	val1, val2, val3, val4, val5, val6;
type	tag1, tag2, tag3, tag4, tag5, tag6;
{
	long		out6;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Output_Integer(tag6);
	out6 = (long	) pxSetScreenSaver(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint);
	Return_Unify_Integer(val6, tag6, out6);
}

p_pxScreenSaver(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxScreenSaver(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxQueryAccess(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out2;
	long		out3;
	long		out4;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxQueryAccess(val1 . nint, &out2, &out3);
	Request_Unify_Integer(val2, tag2, out2);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Return_Unify;
}

p_pxSetAccess(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxSetAccess(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxSetHostAccess(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out4;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Atom_Or_Nil(val3, tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxSetHostAccess(val1 . nint, val2 . nint, DidName(val3 . did));
	Return_Unify_Integer(val4, tag4, out4);
}

p_pxEventsQueued(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out3;
	long		out4;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxEventsQueued(val1 . nint, val2 . nint, &out3);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Return_Unify;
}

p_pxNextEvent(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out3;
	long		out4;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxNextEvent(val1 . nint, val2 . nint, &out3);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Return_Unify;
}

p_pxGetEvent(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8)
value	val1, val2, val3, val4, val5, val6, val7, val8;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8;
{
	long		out7;
	long		out8;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Integer(tag5);
	Check_Integer(tag6);
	Check_Output_Integer(tag7);
	Check_Output_Integer(tag8);
	out8 = (long	) pxGetEvent(val1 . nint, val2 . nint, val3 . nint, val4 . nint, val5 . nint, val6 . nint, &out7);
	Request_Unify_Integer(val7, tag7, out7);
	Request_Unify_Integer(val8, tag8, out8);
	Return_Unify;
}

p_pxSelectEvent(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6, val7, tag7, val8, tag8, val9, tag9, val10, tag10)
value	val1, val2, val3, val4, val5, val6, val7, val8, val9, val10;
type	tag1, tag2, tag3, tag4, tag5, tag6, tag7, tag8, tag9, tag10;
{
	long		out5;
	long		out6;
	long		out7;
	long		out8;
	long		out9;
	long		out10;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Output_Integer(tag5);
	Check_Output_Integer(tag6);
	Check_Output_Integer(tag7);
	Check_Output_Integer(tag8);
	Check_Output_Integer(tag9);
	Check_Output_Integer(tag10);
	out10 = (long	) pxSelectEvent(val1 . nint, val2 . nint, val3 . nint, val4 . nint, &out5, &out6, &out7, &out8, &out9);
	Request_Unify_Integer(val5, tag5, out5);
	Request_Unify_Integer(val6, tag6, out6);
	Request_Unify_Integer(val7, tag7, out7);
	Request_Unify_Integer(val8, tag8, out8);
	Request_Unify_Integer(val9, tag9, out9);
	Request_Unify_Integer(val10, tag10, out10);
	Return_Unify;
}

p_pxPutBackEvent(val1, tag1, val2, tag2)
value	val1, val2;
type	tag1, tag2;
{
	long		out2;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	out2 = (long	) pxPutBackEvent(val1 . nint);
	Return_Unify_Integer(val2, tag2, out2);
}

p_pxSendEvent(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5)
value	val1, val2, val3, val4, val5;
type	tag1, tag2, tag3, tag4, tag5;
{
	long		out5;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Integer(tag3);
	Check_Integer(tag4);
	Check_Output_Integer(tag5);
	out5 = (long	) pxSendEvent(val1 . nint, val2 . nint, val3 . nint, val4 . nint);
	Return_Unify_Integer(val5, tag5, out5);
}

p_pxFlush(val1, tag1, val2, tag2)
value	val1, val2;
type	tag1, tag2;
{
	long		out2;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	out2 = (long	) pxFlush(val1 . nint);
	Return_Unify_Integer(val2, tag2, out2);
}

p_pxSync(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxSync(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxSynchronize(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out3;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxSynchronize(val1 . nint, val2 . nint);
	Return_Unify_Integer(val3, tag3, out3);
}

p_pxNormalMotion(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5)
value	val1, val2, val3, val4, val5;
type	tag1, tag2, tag3, tag4, tag5;
{
	long		out1;
	long		out2;
	long		out3;
	long		out4;
	long		out5;
	Prepare_Requests;

	Check_Output_Integer(tag1);
	Check_Output_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	Check_Output_Integer(tag5);
	out5 = (long	) pxNormalMotion(&out1, &out2, &out3, &out4);
	Request_Unify_Integer(val1, tag1, out1);
	Request_Unify_Integer(val2, tag2, out2);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Request_Unify_Integer(val5, tag5, out5);
	Return_Unify;
}

p_pxSplitMotion(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6)
value	val1, val2, val3, val4, val5, val6;
type	tag1, tag2, tag3, tag4, tag5, tag6;
{
	long		out1;
	long		out2;
	long		out3;
	long		out4;
	long		out5;
	long		out6;
	Prepare_Requests;

	Check_Output_Integer(tag1);
	Check_Output_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	Check_Output_Integer(tag5);
	Check_Output_Integer(tag6);
	out6 = (long	) pxSplitMotion(&out1, &out2, &out3, &out4, &out5);
	Request_Unify_Integer(val1, tag1, out1);
	Request_Unify_Integer(val2, tag2, out2);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Request_Unify_Integer(val5, tag5, out5);
	Request_Unify_Integer(val6, tag6, out6);
	Return_Unify;
}

p_pxGetMotionEvents(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	long		out3;
	long		out4;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxGetMotionEvents(val1 . nint, val2 . nint, &out3);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Return_Unify;
}

p_pxResourceDatabases(val1, tag1)
value	val1;
type	tag1;
{
	long		out1;

	Check_Output_Integer(tag1);
	(void) pxResourceDatabases(&out1);
	Return_Unify_Integer(val1, tag1, out1);
}

p_pxOpenResourceDatabase(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6)
value	val1, val2, val3, val4, val5, val6;
type	tag1, tag2, tag3, tag4, tag5, tag6;
{
	long		out5;
	long		out6;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Atom_Or_Nil(val2, tag2);
	Check_Atom_Or_Nil(val3, tag3);
	Check_Integer(tag4);
	Check_Output_Integer(tag5);
	Check_Output_Integer(tag6);
	out6 = (long	) pxOpenResourceDatabase(val1 . nint, DidName(val2 . did), DidName(val3 . did), val4 . nint, &out5);
	Request_Unify_Integer(val5, tag5, out5);
	Request_Unify_Integer(val6, tag6, out6);
	Return_Unify;
}

p_pxCloseResourceDatabase(val1, tag1, val2, tag2)
value	val1, val2;
type	tag1, tag2;
{
	long		out2;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	out2 = (long	) pxCloseResourceDatabase(val1 . nint);
	Return_Unify_Integer(val2, tag2, out2);
}

p_pxQueryResourceDatabase(val1, tag1, val2, tag2, val3, tag3, val4, tag4)
value	val1, val2, val3, val4;
type	tag1, tag2, tag3, tag4;
{
	char *	out3;
	long		out4;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Integer(tag2);
	Check_Output_Atom(tag3);
	Check_Output_Integer(tag4);
	out4 = (long	) pxQueryResourceDatabase(val1 . nint, val2 . nint, &out3);
	Request_Unify_Atom(val3, tag3, in_dict(out3, 0));
	Request_Unify_Integer(val4, tag4, out4);
	Return_Unify;
}

p_pxListExtensions(val1, tag1, val2, tag2, val3, tag3)
value	val1, val2, val3;
type	tag1, tag2, tag3;
{
	long		out2;
	long		out3;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	Check_Output_Integer(tag3);
	out3 = (long	) pxListExtensions(val1 . nint, &out2);
	Request_Unify_Integer(val2, tag2, out2);
	Request_Unify_Integer(val3, tag3, out3);
	Return_Unify;
}

p_pxQueryExtension(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6)
value	val1, val2, val3, val4, val5, val6;
type	tag1, tag2, tag3, tag4, tag5, tag6;
{
	long		out3;
	long		out4;
	long		out5;
	long		out6;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Atom_Or_Nil(val2, tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	Check_Output_Integer(tag5);
	Check_Output_Integer(tag6);
	out6 = (long	) pxQueryExtension(val1 . nint, DidName(val2 . did), &out3, &out4, &out5);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Request_Unify_Integer(val5, tag5, out5);
	Request_Unify_Integer(val6, tag6, out6);
	Return_Unify;
}

p_pxGetDefault(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5)
value	val1, val2, val3, val4, val5;
type	tag1, tag2, tag3, tag4, tag5;
{
	char *	out4;
	long		out5;
	Prepare_Requests;

	Check_Integer(tag1);
	Check_Atom_Or_Nil(val2, tag2);
	Check_Atom_Or_Nil(val3, tag3);
	Check_Output_Atom(tag4);
	Check_Output_Integer(tag5);
	out5 = (long	) pxGetDefault(val1 . nint, DidName(val2 . did), DidName(val3 . did), &out4);
	Request_Unify_Atom(val4, tag4, in_dict(out4, 0));
	Request_Unify_Integer(val5, tag5, out5);
	Return_Unify;
}

p_pxParseGeometry(val1, tag1, val2, tag2, val3, tag3, val4, tag4, val5, tag5, val6, tag6)
value	val1, val2, val3, val4, val5, val6;
type	tag1, tag2, tag3, tag4, tag5, tag6;
{
	long		out2;
	long		out3;
	long		out4;
	long		out5;
	long		out6;
	Prepare_Requests;

	Check_Atom_Or_Nil(val1, tag1);
	Check_Output_Integer(tag2);
	Check_Output_Integer(tag3);
	Check_Output_Integer(tag4);
	Check_Output_Integer(tag5);
	Check_Output_Integer(tag6);
	(void) pxParseGeometry(DidName(val1 . did), &out2, &out3, &out4, &out5, &out6);
	Request_Unify_Integer(val2, tag2, out2);
	Request_Unify_Integer(val3, tag3, out3);
	Request_Unify_Integer(val4, tag4, out4);
	Request_Unify_Integer(val5, tag5, out5);
	Request_Unify_Integer(val6, tag6, out6);
	Return_Unify;
}

p_pxGetHostName(val1, tag1, val2, tag2)
value	val1, val2;
type	tag1, tag2;
{
	char *	out1;
	long		out2;
	Prepare_Requests;

	Check_Output_Atom(tag1);
	Check_Output_Integer(tag2);
	out2 = (long	) pxGetHostName(&out1);
	Request_Unify_Atom(val1, tag1, in_dict(out1, 0));
	Request_Unify_Integer(val2, tag2, out2);
	Return_Unify;
}

p_pxNoOp(val1, tag1, val2, tag2)
value	val1, val2;
type	tag1, tag2;
{
	long		out2;

	Check_Integer(tag1);
	Check_Output_Integer(tag2);
	out2 = (long	) pxNoOp(val1 . nint);
	Return_Unify_Integer(val2, tag2, out2);
}

p_pxOk(val1, tag1)
value	val1;
type	tag1;
{
	long		out1;

	Check_Output_Integer(tag1);
	out1 = (long	) pxOk();
	Return_Unify_Integer(val1, tag1, out1);
}

