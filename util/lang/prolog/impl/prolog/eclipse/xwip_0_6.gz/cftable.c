/*
 * Copyright (C) 1990, 1993 by Ted Kim.
 *
 * This software work was developed at UCLA with support in part from
 * DARPA Contract F29601-87-C-0072.
 */

/*
 * preprocessor for cursorfont table
 */

#include <stdio.h>

#define COLS 2

main()
{
  char buf[256];
  char buf2[256];
  int value = 0;

  scanf("%*[^\n]");

  while (scanf(" #define XC_%s %*d\n", buf2) == 1) {
    convert(buf2, buf);
    value = value + 1;
    if (value == COLS) {
      printf("%s \\\\\n", buf);
      value = 0;
    } else
      printf("%s & ", buf);
  }
  if  (value == 0)
    exit(0);
  value = value + 1;
  while (value < COLS) {
    printf("& ");
    value++;
  }
  printf("\\\\\n");
  exit(0);
}

convert(src,dest)
     char *src, *dest;
{
  while (*src != '\0')
    if (*src == '_') {
      *dest++ = '\\';
      *dest++ = '_';
      src++;
    }
    else
      *dest++ = *src++;
  *dest = '\0';
}

/*
 * eof
 */

