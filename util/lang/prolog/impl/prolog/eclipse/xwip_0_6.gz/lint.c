/*
 * prevents plint from complaining about "defined, but never used"
 */

extern void PROLOG();

main()
{
  PROLOG();
}

/*
 * eof
 */
