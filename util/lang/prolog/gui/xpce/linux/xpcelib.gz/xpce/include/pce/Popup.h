/*  $Id: Popup.h,v 1.1 1993/12/15 17:14:54 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_POPUP_H
#define _PCE_POPUP_H

extern Any ClassPopup;
class PcePopup :public PceObject
{
public:
  PcePopup() :
    PceObject(ClassPopup)
  {
  }
  PcePopup(PceArg name) :
    PceObject(ClassPopup, name)
  {
  }
  PcePopup(PceArg name, PceArg message) :
    PceObject(ClassPopup, name, message)
  {
  }
};

#endif /*!_PCE_POPUP_H*/
