/*  $Id: Colour.h,v 1.1 1993/12/15 17:13:58 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_COLOUR_H
#define _PCE_COLOUR_H

extern Any ClassColour;
class PceColour :public PceObject
{
public:
  PceColour(PceArg name) :
    PceObject(ClassColour, name)
  {
  }
  PceColour(PceArg name, PceArg red) :
    PceObject(ClassColour, name, red)
  {
  }
  PceColour(PceArg name, PceArg red, PceArg green) :
    PceObject(ClassColour, name, red, green)
  {
  }
  PceColour(PceArg name, PceArg red, PceArg green, PceArg blue) :
    PceObject(ClassColour, name, red, green, blue)
  {
  }
};

#endif /*!_PCE_COLOUR_H*/
