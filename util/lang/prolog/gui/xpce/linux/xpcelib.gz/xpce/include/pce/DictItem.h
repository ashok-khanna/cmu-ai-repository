/*  $Id: DictItem.h,v 1.1 1993/12/15 17:14:06 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_DICTITEM_H
#define _PCE_DICTITEM_H

extern Any ClassDictItem;
class PceDictItem :public PceObject
{
public:
  PceDictItem(PceArg key) :
    PceObject(ClassDictItem, key)
  {
  }
  PceDictItem(PceArg key, PceArg label) :
    PceObject(ClassDictItem, key, label)
  {
  }
  PceDictItem(PceArg key, PceArg label, PceArg object) :
    PceObject(ClassDictItem, key, label, object)
  {
  }
  PceDictItem(PceArg key, PceArg label, PceArg object, PceArg style) :
    PceObject(ClassDictItem, key, label, object, style)
  {
  }
};

#endif /*!_PCE_DICTITEM_H*/
