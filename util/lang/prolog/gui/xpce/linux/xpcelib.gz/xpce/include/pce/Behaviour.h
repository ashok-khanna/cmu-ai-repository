/*  $Id: Behaviour.h,v 1.1 1993/12/15 17:13:41 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_BEHAVIOUR_H
#define _PCE_BEHAVIOUR_H

extern Any ClassBehaviour;
class PceBehaviour :public PceObject
{
public:
  PceBehaviour(PceArg name) :
    PceObject(ClassBehaviour, name)
  {
  }
  PceBehaviour(PceArg name, PceArg context) :
    PceObject(ClassBehaviour, name, context)
  {
  }
};

#endif /*!_PCE_BEHAVIOUR_H*/
