/*  interface.h,v 1.4 1992/11/11 16:02:28 jan Exp

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1992 University of Amsterdam. All rights reserved.
*/

#include <stdio.h>
#include <assert.h>
#include <string.h>
#ifdef __STDC__
#include <stdarg.h>
#else
#include <varargs.h>
#endif

#ifndef __GNUC__
#define inline
#endif

#ifndef index
extern char *index(), *rindex();
#endif

#ifndef MD				/* can be provided via make */
#define MD "../../src/md.h"
#endif
#include MD				/* TBD: how to include machine/os? */
#include "../../src/itf-interface.h"	/* PCE interface include file */

#define LINESIZE 1024			/* Max identifier size */

#ifndef bool
#define bool int
#endif

#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif

#ifndef EOS
#define EOS '\0'
#endif

#ifndef streq
#define streq(s, q)	(!strcmp(s, q))
#endif

#define succeed		return TRUE
#define fail		return FALSE
#define Test(g)		{ if (!(g)) fail; }

typedef void (*VoidFunc)();		/* pointer to void function */

