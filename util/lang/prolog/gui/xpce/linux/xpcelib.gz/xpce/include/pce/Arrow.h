/*  $Id: Arrow.h,v 1.1 1993/12/15 17:13:39 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_ARROW_H
#define _PCE_ARROW_H

extern Any ClassArrow;
class PceArrow :public PceObject
{
public:
  PceArrow() :
    PceObject(ClassArrow)
  {
  }
  PceArrow(PceArg length) :
    PceObject(ClassArrow, length)
  {
  }
  PceArrow(PceArg length, PceArg wing) :
    PceObject(ClassArrow, length, wing)
  {
  }
};

#endif /*!_PCE_ARROW_H*/
