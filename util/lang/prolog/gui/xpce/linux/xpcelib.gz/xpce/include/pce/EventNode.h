/*  $Id: EventNode.h,v 1.1 1993/12/15 17:14:12 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_EVENTNODE_H
#define _PCE_EVENTNODE_H

extern Any ClassEventNode;
class PceEventNode :public PceObject
{
public:
  PceEventNode(PceArg value) :
    PceObject(ClassEventNode, value)
  {
  }
  PceEventNode(PceArg value, PceArg parent) :
    PceObject(ClassEventNode, value, parent)
  {
  }
};

#endif /*!_PCE_EVENTNODE_H*/
