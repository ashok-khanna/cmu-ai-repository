/*  $Id: Handler.h,v 1.1 1993/12/15 17:14:23 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_HANDLER_H
#define _PCE_HANDLER_H

extern Any ClassHandler;
class PceHandler :public PceObject
{
public:
  PceHandler(PceArg event, PceArg message) :
    PceObject(ClassHandler, event, message)
  {
  }
  PceHandler(PceArg event, PceArg message, PceArg restrict_to) :
    PceObject(ClassHandler, event, message, restrict_to)
  {
  }
};

#endif /*!_PCE_HANDLER_H*/
