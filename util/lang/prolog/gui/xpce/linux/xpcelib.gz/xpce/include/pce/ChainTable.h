/*  $Id: ChainTable.h,v 1.1 1993/12/15 17:13:53 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_CHAINTABLE_H
#define _PCE_CHAINTABLE_H

extern Any ClassChainTable;
class PceChainTable :public PceObject
{
public:
  PceChainTable() :
    PceObject(ClassChainTable)
  {
  }
  PceChainTable(PceArg buckets) :
    PceObject(ClassChainTable, buckets)
  {
  }
};

#endif /*!_PCE_CHAINTABLE_H*/
