/*  $Id: Resource.h,v 1.1 1993/12/15 17:15:02 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_RESOURCE_H
#define _PCE_RESOURCE_H

extern Any ClassResource;
class PceResource :public PceObject
{
public:
  PceResource(PceArg name) :
    PceObject(ClassResource, name)
  {
  }
  PceResource(PceArg name, PceArg cl) :
    PceObject(ClassResource, name, cl)
  {
  }
  PceResource(PceArg name, PceArg cl, PceArg type) :
    PceObject(ClassResource, name, cl, type)
  {
  }
  PceResource(PceArg name, PceArg cl, PceArg type, PceArg def) :
    PceObject(ClassResource, name, cl, type, def)
  {
  }
  PceResource(PceArg name, PceArg cl, PceArg type, PceArg def, PceArg context) :
    PceObject(ClassResource, name, cl, type, def, context)
  {
  }
  PceResource(PceArg name, PceArg cl, PceArg type, PceArg def, PceArg context, PceArg summary) :
    PceObject(ClassResource, name, cl, type, def, context, summary)
  {
  }
};

#endif /*!_PCE_RESOURCE_H*/
