/*  $Id: Divide.h,v 1.1 1993/12/15 17:14:08 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_DIVIDE_H
#define _PCE_DIVIDE_H

extern Any ClassDivide;
class PceDivide :public PceObject
{
public:
  PceDivide(PceArg left, PceArg right) :
    PceObject(ClassDivide, left, right)
  {
  }
};

#endif /*!_PCE_DIVIDE_H*/
