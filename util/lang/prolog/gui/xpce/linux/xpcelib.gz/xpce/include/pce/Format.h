/*  $Id: Format.h,v 1.1 1993/12/15 17:14:17 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_FORMAT_H
#define _PCE_FORMAT_H

extern Any ClassFormat;
class PceFormat :public PceObject
{
public:
  PceFormat() :
    PceObject(ClassFormat)
  {
  }
  PceFormat(PceArg orientation) :
    PceObject(ClassFormat, orientation)
  {
  }
  PceFormat(PceArg orientation, PceArg width) :
    PceObject(ClassFormat, orientation, width)
  {
  }
  PceFormat(PceArg orientation, PceArg width, PceArg columns) :
    PceObject(ClassFormat, orientation, width, columns)
  {
  }
};

#endif /*!_PCE_FORMAT_H*/
