/*  $Id: identify.C,v 1.1 1993/12/15 17:12:44 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#include <pce/Pce.h>

void
identifyPce()
{ TheDisplay.send("inform", "I am XPCE version %s",
		  ThePce.get("version"));
}
