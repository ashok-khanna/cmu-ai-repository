/*  $Id: WindowDecorator.h,v 1.1 1993/12/15 17:15:23 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_WINDOWDECORATOR_H
#define _PCE_WINDOWDECORATOR_H

extern Any ClassWindowDecorator;
class PceWindowDecorator :public PceObject
{
public:
  PceWindowDecorator(PceArg window) :
    PceObject(ClassWindowDecorator, window)
  {
  }
  PceWindowDecorator(PceArg window, PceArg scrollbars) :
    PceObject(ClassWindowDecorator, window, scrollbars)
  {
  }
  PceWindowDecorator(PceArg window, PceArg scrollbars, PceArg label) :
    PceObject(ClassWindowDecorator, window, scrollbars, label)
  {
  }
};

#endif /*!_PCE_WINDOWDECORATOR_H*/
