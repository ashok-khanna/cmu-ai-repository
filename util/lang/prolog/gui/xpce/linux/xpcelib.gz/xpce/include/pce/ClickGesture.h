/*  $Id: ClickGesture.h,v 1.1 1993/12/15 17:13:56 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_CLICKGESTURE_H
#define _PCE_CLICKGESTURE_H

extern Any ClassClickGesture;
class PceClickGesture :public PceObject
{
public:
  PceClickGesture() :
    PceObject(ClassClickGesture)
  {
  }
  PceClickGesture(PceArg button) :
    PceObject(ClassClickGesture, button)
  {
  }
  PceClickGesture(PceArg button, PceArg modifier) :
    PceObject(ClassClickGesture, button, modifier)
  {
  }
  PceClickGesture(PceArg button, PceArg modifier, PceArg multiple) :
    PceObject(ClassClickGesture, button, modifier, multiple)
  {
  }
  PceClickGesture(PceArg button, PceArg modifier, PceArg multiple, PceArg message) :
    PceObject(ClassClickGesture, button, modifier, multiple, message)
  {
  }
  PceClickGesture(PceArg button, PceArg modifier, PceArg multiple, PceArg message, PceArg preview) :
    PceObject(ClassClickGesture, button, modifier, multiple, message, preview)
  {
  }
  PceClickGesture(PceArg button, PceArg modifier, PceArg multiple, PceArg message, PceArg preview, PceArg cancel) :
    PceObject(ClassClickGesture, button, modifier, multiple, message, preview, cancel)
  {
  }
};

#endif /*!_PCE_CLICKGESTURE_H*/
