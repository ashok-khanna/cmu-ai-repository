/*  $Id: Button.h,v 1.1 1993/12/15 17:13:50 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_BUTTON_H
#define _PCE_BUTTON_H

extern Any ClassButton;
class PceButton :public PceObject
{
public:
  PceButton(PceArg name) :
    PceObject(ClassButton, name)
  {
  }
  PceButton(PceArg name, PceArg message) :
    PceObject(ClassButton, name, message)
  {
  }
  PceButton(PceArg name, PceArg message, PceArg label) :
    PceObject(ClassButton, name, message, label)
  {
  }
};

#endif /*!_PCE_BUTTON_H*/
