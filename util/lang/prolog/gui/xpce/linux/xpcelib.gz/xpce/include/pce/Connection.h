/*  $Id: Connection.h,v 1.1 1993/12/15 17:13:59 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_CONNECTION_H
#define _PCE_CONNECTION_H

extern Any ClassConnection;
class PceConnection :public PceObject
{
public:
  PceConnection(PceArg from, PceArg to) :
    PceObject(ClassConnection, from, to)
  {
  }
  PceConnection(PceArg from, PceArg to, PceArg link) :
    PceObject(ClassConnection, from, to, link)
  {
  }
  PceConnection(PceArg from, PceArg to, PceArg link, PceArg handle_from) :
    PceObject(ClassConnection, from, to, link, handle_from)
  {
  }
  PceConnection(PceArg from, PceArg to, PceArg link, PceArg handle_from, PceArg handle_to) :
    PceObject(ClassConnection, from, to, link, handle_from, handle_to)
  {
  }
};

#endif /*!_PCE_CONNECTION_H*/
