/*  $Id: help.pl,v 1.1 1993/12/15 17:18:55 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

:- module(emacs_help,
	  [ emacs_help/0
	  ]).
:- use_module(library(pce)).
:- use_module(library(emacs), [emacs/1]).

:- dynamic
	help_file/1.

:- absolute_file_name('emacs.hlp', File),
   asserta(help_file(File)).

emacs_help :-
	help_file(HelpFile),
	emacs(HelpFile).
	
