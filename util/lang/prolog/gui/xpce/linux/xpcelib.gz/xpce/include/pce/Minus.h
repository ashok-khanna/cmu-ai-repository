/*  $Id: Minus.h,v 1.1 1993/12/15 17:14:39 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_MINUS_H
#define _PCE_MINUS_H

extern Any ClassMinus;
class PceMinus :public PceObject
{
public:
  PceMinus(PceArg left) :
    PceObject(ClassMinus, left)
  {
  }
  PceMinus(PceArg left, PceArg right) :
    PceObject(ClassMinus, left, right)
  {
  }
};

#endif /*!_PCE_MINUS_H*/
