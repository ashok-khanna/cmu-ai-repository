/*  $Id: Real.h,v 1.1 1993/12/15 17:14:57 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_REAL_H
#define _PCE_REAL_H

extern Any ClassReal;
class PceReal :public PceObject
{
public:
  PceReal() :
    PceObject(ClassReal)
  {
  }
  PceReal(PceArg value) :
    PceObject(ClassReal, value)
  {
  }
};

#endif /*!_PCE_REAL_H*/
