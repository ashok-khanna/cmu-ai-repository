/*  $Id: MenuBar.h,v 1.1 1993/12/15 17:14:35 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_MENUBAR_H
#define _PCE_MENUBAR_H

extern Any ClassMenuBar;
class PceMenuBar :public PceObject
{
public:
  PceMenuBar() :
    PceObject(ClassMenuBar)
  {
  }
  PceMenuBar(PceArg name) :
    PceObject(ClassMenuBar, name)
  {
  }
};

#endif /*!_PCE_MENUBAR_H*/
