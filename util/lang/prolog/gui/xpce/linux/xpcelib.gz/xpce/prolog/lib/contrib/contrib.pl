/*  $Id: contrib.pl,v 1.1 1993/07/23 11:41:41 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

contribution('Rubiks Cube',			% Name
	     'The Rubiks Cube Game',		% Summary
	     'Christian Schlichtherle',		% Author
	     library('contrib/rubik/rubikpce'),	% Library to load
	     rubikpce).				% Toplevel goal
