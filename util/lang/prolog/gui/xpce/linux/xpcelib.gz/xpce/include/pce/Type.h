/*  $Id: Type.h,v 1.1 1993/12/15 17:15:18 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_TYPE_H
#define _PCE_TYPE_H

extern Any ClassType;
class PceType :public PceObject
{
public:
  PceType(PceArg name) :
    PceObject(ClassType, name)
  {
  }
  PceType(PceArg name, PceArg kind) :
    PceObject(ClassType, name, kind)
  {
  }
  PceType(PceArg name, PceArg kind, PceArg context) :
    PceObject(ClassType, name, kind, context)
  {
  }
  PceType(PceArg name, PceArg kind, PceArg context, PceArg supers) :
    PceObject(ClassType, name, kind, context, supers)
  {
  }
};

#endif /*!_PCE_TYPE_H*/
