/*  $Id: SourceLocation.h,v 1.1 1993/12/15 17:15:07 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_SOURCELOCATION_H
#define _PCE_SOURCELOCATION_H

extern Any ClassSourceLocation;
class PceSourceLocation :public PceObject
{
public:
  PceSourceLocation(PceArg file) :
    PceObject(ClassSourceLocation, file)
  {
  }
  PceSourceLocation(PceArg file, PceArg line) :
    PceObject(ClassSourceLocation, file, line)
  {
  }
};

#endif /*!_PCE_SOURCELOCATION_H*/
