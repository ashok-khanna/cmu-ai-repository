/*  $Id: TextItem.h,v 1.1 1993/12/15 17:15:14 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_TEXTITEM_H
#define _PCE_TEXTITEM_H

extern Any ClassTextItem;
class PceTextItem :public PceObject
{
public:
  PceTextItem(PceArg name) :
    PceObject(ClassTextItem, name)
  {
  }
  PceTextItem(PceArg name, PceArg def) :
    PceObject(ClassTextItem, name, def)
  {
  }
  PceTextItem(PceArg name, PceArg def, PceArg message) :
    PceObject(ClassTextItem, name, def, message)
  {
  }
};

#endif /*!_PCE_TEXTITEM_H*/
