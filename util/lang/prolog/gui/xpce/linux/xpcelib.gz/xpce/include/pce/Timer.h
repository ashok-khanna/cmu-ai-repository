/*  $Id: Timer.h,v 1.1 1993/12/15 17:15:16 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_TIMER_H
#define _PCE_TIMER_H

extern Any ClassTimer;
class PceTimer :public PceObject
{
public:
  PceTimer(PceArg interval, PceArg message) :
    PceObject(ClassTimer, interval, message)
  {
  }
};

#endif /*!_PCE_TIMER_H*/
