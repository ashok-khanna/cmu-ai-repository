/*  $Id: HashTable.h,v 1.1 1993/12/15 17:14:24 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_HASHTABLE_H
#define _PCE_HASHTABLE_H

extern Any ClassHashTable;
class PceHashTable :public PceObject
{
public:
  PceHashTable() :
    PceObject(ClassHashTable)
  {
  }
  PceHashTable(PceArg buckets) :
    PceObject(ClassHashTable, buckets)
  {
  }
};

#endif /*!_PCE_HASHTABLE_H*/
