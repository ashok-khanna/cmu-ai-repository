/*  $Id: ResizeOutlineGesture.h,v 1.1 1993/12/15 17:15:01 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_RESIZEOUTLINEGESTURE_H
#define _PCE_RESIZEOUTLINEGESTURE_H

extern Any ClassResizeOutlineGesture;
class PceResizeOutlineGesture :public PceObject
{
public:
  PceResizeOutlineGesture() :
    PceObject(ClassResizeOutlineGesture)
  {
  }
  PceResizeOutlineGesture(PceArg button) :
    PceObject(ClassResizeOutlineGesture, button)
  {
  }
  PceResizeOutlineGesture(PceArg button, PceArg modifier) :
    PceObject(ClassResizeOutlineGesture, button, modifier)
  {
  }
};

#endif /*!_PCE_RESIZEOUTLINEGESTURE_H*/
