/*  $Id: Modifier.h,v 1.1 1993/12/15 17:14:40 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_MODIFIER_H
#define _PCE_MODIFIER_H

extern Any ClassModifier;
class PceModifier :public PceObject
{
public:
  PceModifier() :
    PceObject(ClassModifier)
  {
  }
  PceModifier(PceArg shift) :
    PceObject(ClassModifier, shift)
  {
  }
  PceModifier(PceArg shift, PceArg control) :
    PceObject(ClassModifier, shift, control)
  {
  }
  PceModifier(PceArg shift, PceArg control, PceArg meta) :
    PceObject(ClassModifier, shift, control, meta)
  {
  }
};

#endif /*!_PCE_MODIFIER_H*/
