/*  $Id: Ellipse.h,v 1.1 1993/12/15 17:14:09 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_ELLIPSE_H
#define _PCE_ELLIPSE_H

extern Any ClassEllipse;
class PceEllipse :public PceObject
{
public:
  PceEllipse() :
    PceObject(ClassEllipse)
  {
  }
  PceEllipse(PceArg width) :
    PceObject(ClassEllipse, width)
  {
  }
  PceEllipse(PceArg width, PceArg height) :
    PceObject(ClassEllipse, width, height)
  {
  }
};

#endif /*!_PCE_ELLIPSE_H*/
