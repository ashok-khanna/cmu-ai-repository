/*  $Id: Point.h,v 1.1 1993/12/15 17:14:53 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_POINT_H
#define _PCE_POINT_H

extern Any ClassPoint;
class PcePoint :public PceObject
{
public:
  PcePoint() :
    PceObject(ClassPoint)
  {
  }
  PcePoint(PceArg x) :
    PceObject(ClassPoint, x)
  {
  }
  PcePoint(PceArg x, PceArg y) :
    PceObject(ClassPoint, x, y)
  {
  }
};

#endif /*!_PCE_POINT_H*/
