/*  $Id: string.C,v 1.1 1993/12/15 17:12:49 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#include <pce/Pce.h>
#include <pce/String.h>
#include <stdio.h>

PceStatus
pceInitApplication(int argc, char *argv[])
{ printf("%s\n", PceObject("string", "Edit person").pp());


  return SUCCEED;
}
