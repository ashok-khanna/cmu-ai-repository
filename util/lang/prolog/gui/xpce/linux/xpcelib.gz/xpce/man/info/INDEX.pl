/*  $Id: autoload.pl,v 1.2 1992/09/10 19:42:52 jan Exp $

    Creator: make/0

    Purpose: Provide index for autoload
*/

index((card_to_asci), 1, asciman, 'asciman.pl').
index((module_to_asci), 1, asciman, 'asciman.pl').
index((space_to_asci), 0, asciman, 'asciman.pl').
index((update_cards), 1, asciman, 'asciman.pl').
index((spell_module), 1, asciman, 'asciman.pl').
index((spell_manual), 0, asciman, 'asciman.pl').
index((dialog), 1, dialog, 'dialog.pl').
index((texinfo_open), 0, texinfo, 'texinfo.pl').
index((texinfo_open), 1, texinfo, 'texinfo.pl').
index((texinfo_close), 0, texinfo, 'texinfo.pl').
index((texinfo_class), 1, texinfo, 'texinfo.pl').
index((texi), 0, texinfo, 'texinfo.pl').
index((texi), 1, texinfo, 'texinfo.pl').
