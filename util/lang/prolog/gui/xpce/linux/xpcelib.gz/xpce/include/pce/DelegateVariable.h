/*  $Id: DelegateVariable.h,v 1.1 1993/12/15 17:14:03 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_DELEGATEVARIABLE_H
#define _PCE_DELEGATEVARIABLE_H

extern Any ClassDelegateVariable;
class PceDelegateVariable :public PceObject
{
public:
  PceDelegateVariable(PceArg name) :
    PceObject(ClassDelegateVariable, name)
  {
  }
  PceDelegateVariable(PceArg name, PceArg type) :
    PceObject(ClassDelegateVariable, name, type)
  {
  }
  PceDelegateVariable(PceArg name, PceArg type, PceArg access) :
    PceObject(ClassDelegateVariable, name, type, access)
  {
  }
  PceDelegateVariable(PceArg name, PceArg type, PceArg access, PceArg wrapper) :
    PceObject(ClassDelegateVariable, name, type, access, wrapper)
  {
  }
  PceDelegateVariable(PceArg name, PceArg type, PceArg access, PceArg wrapper, PceArg summary) :
    PceObject(ClassDelegateVariable, name, type, access, wrapper, summary)
  {
  }
  PceDelegateVariable(PceArg name, PceArg type, PceArg access, PceArg wrapper, PceArg summary, PceArg group) :
    PceObject(ClassDelegateVariable, name, type, access, wrapper, summary, group)
  {
  }
};

#endif /*!_PCE_DELEGATEVARIABLE_H*/
