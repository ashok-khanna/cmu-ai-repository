/*  $Id: Menu.h,v 1.1 1993/12/15 17:14:34 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_MENU_H
#define _PCE_MENU_H

extern Any ClassMenu;
class PceMenu :public PceObject
{
public:
  PceMenu() :
    PceObject(ClassMenu)
  {
  }
  PceMenu(PceArg name) :
    PceObject(ClassMenu, name)
  {
  }
  PceMenu(PceArg name, PceArg kind) :
    PceObject(ClassMenu, name, kind)
  {
  }
  PceMenu(PceArg name, PceArg kind, PceArg message) :
    PceObject(ClassMenu, name, kind, message)
  {
  }
};

#endif /*!_PCE_MENU_H*/
