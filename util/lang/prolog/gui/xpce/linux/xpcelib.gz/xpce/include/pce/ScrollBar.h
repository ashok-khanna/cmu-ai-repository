/*  $Id: ScrollBar.h,v 1.1 1993/12/15 17:15:03 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_SCROLLBAR_H
#define _PCE_SCROLLBAR_H

extern Any ClassScrollBar;
class PceScrollBar :public PceObject
{
public:
  PceScrollBar() :
    PceObject(ClassScrollBar)
  {
  }
  PceScrollBar(PceArg object) :
    PceObject(ClassScrollBar, object)
  {
  }
  PceScrollBar(PceArg object, PceArg orientation) :
    PceObject(ClassScrollBar, object, orientation)
  {
  }
  PceScrollBar(PceArg object, PceArg orientation, PceArg message) :
    PceObject(ClassScrollBar, object, orientation, message)
  {
  }
};

#endif /*!_PCE_SCROLLBAR_H*/
