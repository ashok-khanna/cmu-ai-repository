/*  $Id: Not.h,v 1.1 1993/12/15 17:14:46 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_NOT_H
#define _PCE_NOT_H

extern Any ClassNot;
class PceNot :public PceObject
{
public:
  PceNot(PceArg test) :
    PceObject(ClassNot, test)
  {
  }
};

#endif /*!_PCE_NOT_H*/
