/*  $Id: When.h,v 1.1 1993/12/15 17:15:22 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_WHEN_H
#define _PCE_WHEN_H

extern Any ClassWhen;
class PceWhen :public PceObject
{
public:
  PceWhen(PceArg condition) :
    PceObject(ClassWhen, condition)
  {
  }
  PceWhen(PceArg condition, PceArg thn) :
    PceObject(ClassWhen, condition, thn)
  {
  }
  PceWhen(PceArg condition, PceArg thn, PceArg els) :
    PceObject(ClassWhen, condition, thn, els)
  {
  }
};

#endif /*!_PCE_WHEN_H*/
