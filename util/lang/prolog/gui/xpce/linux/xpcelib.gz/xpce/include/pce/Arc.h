/*  $Id: Arc.h,v 1.1 1993/12/15 17:13:38 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_ARC_H
#define _PCE_ARC_H

extern Any ClassArc;
class PceArc :public PceObject
{
public:
  PceArc() :
    PceObject(ClassArc)
  {
  }
  PceArc(PceArg radius) :
    PceObject(ClassArc, radius)
  {
  }
  PceArc(PceArg radius, PceArg start) :
    PceObject(ClassArc, radius, start)
  {
  }
  PceArc(PceArg radius, PceArg start, PceArg size) :
    PceObject(ClassArc, radius, start, size)
  {
  }
};

#endif /*!_PCE_ARC_H*/
