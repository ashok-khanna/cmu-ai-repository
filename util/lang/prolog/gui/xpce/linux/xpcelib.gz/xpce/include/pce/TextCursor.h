/*  $Id: TextCursor.h,v 1.1 1993/12/15 17:15:13 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_TEXTCURSOR_H
#define _PCE_TEXTCURSOR_H

extern Any ClassTextCursor;
class PceTextCursor :public PceObject
{
public:
  PceTextCursor(PceArg width, PceArg heigth) :
    PceObject(ClassTextCursor, width, heigth)
  {
  }
};

#endif /*!_PCE_TEXTCURSOR_H*/
