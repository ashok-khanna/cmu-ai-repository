/*  $Id: Plus.h,v 1.1 1993/12/15 17:14:52 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_PLUS_H
#define _PCE_PLUS_H

extern Any ClassPlus;
class PcePlus :public PceObject
{
public:
  PcePlus(PceArg left, PceArg right) :
    PceObject(ClassPlus, left, right)
  {
  }
};

#endif /*!_PCE_PLUS_H*/
