/*  $Id: Socket.h,v 1.1 1993/12/15 17:15:06 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_SOCKET_H
#define _PCE_SOCKET_H

extern Any ClassSocket;
class PceSocket :public PceObject
{
public:
  PceSocket(PceArg address) :
    PceObject(ClassSocket, address)
  {
  }
  PceSocket(PceArg address, PceArg domain) :
    PceObject(ClassSocket, address, domain)
  {
  }
};

#endif /*!_PCE_SOCKET_H*/
