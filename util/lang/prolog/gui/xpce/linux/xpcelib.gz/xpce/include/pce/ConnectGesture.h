/*  $Id: ConnectGesture.h,v 1.1 1993/12/15 17:13:59 jan Exp $

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1993 University of Amsterdam. All rights reserved.
*/

#ifndef _PCE_CONNECTGESTURE_H
#define _PCE_CONNECTGESTURE_H

extern Any ClassConnectGesture;
class PceConnectGesture :public PceObject
{
public:
  PceConnectGesture() :
    PceObject(ClassConnectGesture)
  {
  }
  PceConnectGesture(PceArg button) :
    PceObject(ClassConnectGesture, button)
  {
  }
  PceConnectGesture(PceArg button, PceArg modifier) :
    PceObject(ClassConnectGesture, button, modifier)
  {
  }
  PceConnectGesture(PceArg button, PceArg modifier, PceArg link) :
    PceObject(ClassConnectGesture, button, modifier, link)
  {
  }
};

#endif /*!_PCE_CONNECTGESTURE_H*/
