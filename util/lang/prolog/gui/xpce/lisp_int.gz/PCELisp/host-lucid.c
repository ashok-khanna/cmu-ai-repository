/*  $Id: host-lucid.c,v 1.2 1993/01/07 10:38:11 anjo Exp $

    File	host-lucid.c
    Part of	PCE/Lisp interface
    Author	Anjo Anjewierden, anjo@swi.psy.uva.nl
    Purpose	Replacement for XPCE/Lisp read
    Works with	PCE 4.0, SCL 3.0, SCL 4.0,  gcc 2.2
    Notice	Copyright (c) 1991 University of Amsterdam

    History	26/08/91  (Created)
   		14/12/91  (Last Modified)
*/


#include <stdio.h>
#include <sys/syscall.h>
#include <fcntl.h>
#include "itf-interface.h"


static int	blocking = 1;


int
read(fd, buf, n)
int fd;
char *buf;
int n;
{ if (fd == 0 && blocking)
    while (pceDispatch(0, 0) != PCE_DISPATCH_INPUT);
  return syscall(SYS_read, fd, buf, n);
}
    

int
fcntl(fd, cmd, arg)
int fd, cmd, arg;
{ if (fd == 0 && cmd == F_SETFL)
    blocking = !(arg & FNDELAY);
  return syscall(SYS_fcntl, fd, cmd, arg);
}
    
