/*  $Id: host-lispworks.c,v 1.2 1993/01/07 10:38:08 anjo Exp $

    File	host-lispworks.c
    Part of	PCE/Lisp interface
    Author	Anjo Anjewierden, anjo@swi.psy.uva.nl
    Purpose	LispWorks specific functions (on top of pce-lisp.c)
    Works with	LispWorks 3.1, PCE 4.4, gcc 2.2
    Notice	Copyright (c) 1992  University of Amsterdam

    History	26/11/92  (Created)
   		03/12/92  (Last Modified)
*/

#include <stdio.h>
#include "itf-interface.h"


void		*context;		/* Value of Xt application context */

void pce_lispworks_initialise(void);	/* Initialise PCE itself */


void
pce_lispworks_initialise()
{ if (pceInitialise(2, 0, NULL) != PCE_SUCCEED)
  { fprintf(stderr, "Failed to initialise PCE...\nAborted\n");
    exit(0);
  }
  context = pceXtAppContext(NULL);
}
