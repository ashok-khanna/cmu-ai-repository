%
% Copyright (C) 1990, 1993 by Ted Kim.
%
% This software work was developed at UCLA with support in part from
% DARPA Contract F29601-87-C-0072.
%

%
% Sicstus XWIP, interpreted version
%

% load foreign functions
:- consult(ff).

% load
:- load_foreign_files(['xwip.o'], ['-lX11']).

% load tables
:- consult(table).
:- consult(cfont).
:- consult(xatom).

% load predicates
:- consult(util).
:- consult(pred).

% cleanup
:- garbage_collect.
% :- trimcore.

% version
:- consult(version).

%
% eof
%
