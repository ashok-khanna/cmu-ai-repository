%
% Copyright (C) 1990, 1993 by Ted Kim.
%
% This software work was developed at UCLA with support in part from
% DARPA Contract F29601-87-C-0072
%

%
% X Window Interface for Prolog (XWIP)
%

% version
:- version('X Window Interface for Prolog (XWIP) - Version 0.6 (patch 1)
Copyright (C) 1990, 1993 by Ted Kim.
This software work was developed at UCLA with support in part from
DARPA Contract F29601-87-C-0072.').

%
% eof
%
