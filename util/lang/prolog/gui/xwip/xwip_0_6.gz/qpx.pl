%
% Copyright (C) 1990, 1993 by Ted Kim.
%
% This software work was developed at UCLA with support in part from
% DARPA Contract F29601-87-C-0072.
%

%
% Quintus XWIP Package
%

% load foreign functions
:- consult(ff).

% load, libX11.a is assumed to be in /usr/lib
:- load_foreign_files(['xwip.o'], ['-lX11']).
:- abolish([foreign_file/2,foreign/2,foreign/3]).

% load tables
:- compile(table).
:- compile(cfont).
:- compile(xatom).

% load predicates
:- compile(util).
:- compile(pred).

% cleanup
:- garbage_collect.
:- trimcore.

% version
:- consult(version).

% precision
:- xPrecision(29).

% must be done by hand, since doing it here will cause problems with open files
% save_program(qpx)
:- format("~n--->>> please type: save_program(qpx).~n~n", []).

%
% eof
%
