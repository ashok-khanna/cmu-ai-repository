/*
 * Copyright (C) 1990, 1993 by Ted Kim.
 *
 * This software work was developed at UCLA with support in part from
 * DARPA Contract F29601-87-C-0072.
 */

/*
 * preprocessor for cursorfont table
 */

#include <stdio.h>

main()
{
  char buf[256];
  int value;

  scanf("%*[^\n]");

  while (scanf(" #define XC_%s", buf) == 1) {
    scanf(" %d\n", &value);
    if ((buf[0] >= 'A') && (buf[0] <= 'Z'))
      printf("pxCursorFont('%s', %d).\n", buf, value);
    else
      printf("pxCursorFont(%s, %d).\n", buf, value);
  }
  exit(0);
}

/*
 * eof
 */

