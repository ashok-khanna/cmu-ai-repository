/*

   keyword.h

   Copyright, 1993, Brent Benson.  All Rights Reserved.

   Permission to use, copy, and modify this software and its
   documentation is hereby granted only under the following terms and
   conditions.  Both the above copyright notice and this permission
   notice must appear in all copies of the software, derivative works
   or modified version, and both notices must appear in supporting
   documentation.  Users of this software agree to the terms and
   conditions set forth in this notice and agree to inform the author,
   Brent Benson, of any noteworthy uses of this software.

*/

#ifndef KEYWORD_H
#define KEYWORD_H

#include "object.h"

void init_keyword_prims (void);
Object keyword_to_symbol (Object keyword);
Object symbol_to_keyword (Object symbol);
Object find_keyword_val (Object keyword, Object lst);
Object all_keywords (Object lst);

#endif
