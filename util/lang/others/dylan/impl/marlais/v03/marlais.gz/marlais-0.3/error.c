/*

   error.c

   Copyright, 1993, Brent Benson.  All Rights Reserved.

   Permission to use, copy, and modify this software and its
   documentation is hereby granted only under the following terms and
   conditions.  Both the above copyright notice and this permission
   notice must appear in all copies of the software, derivative works
   or modified version, and both notices must appear in supporting
   documentation.  Users of this software agree to the terms and
   conditions set forth in this notice and agree to inform the author,
   Brent Benson, of any noteworthy uses of this software.

*/

#include <stdio.h>
#include "error.h"
#include "print.h"

/* primitives */

static Object dylan_error (Object msg_str, Object rest);

static struct primitive error_prims[] =
{
  {"%error", prim_1_rest, dylan_error},
};

/* function definitions */

void
init_error_prims (void)
{
  int num;

  num = sizeof (error_prims) / sizeof (struct primitive);
  init_prims (num, error_prims);
}

static Object 
dylan_error (Object msg_str, Object rest)
{
  fprintf (stdout, "error: %s", BYTESTRVAL (msg_str));
  if (! NULLP (rest))
    {
      fprintf (stdout, ": ");
    }
  while (! NULLP (rest))
    {
      print_object (stdout, CAR (rest), 0);
      rest = CDR (rest);
      if (! NULLP (rest))
	{
	  fprintf (stdout, ", ");
	}
    }
  fprintf (stdout, ".\n");
  longjmp (error_return, 1);
}

void 
fatal (char *msg)
{
  fprintf (stdout, "%s.\n", msg);
  exit (-1);
}

void 
error (char *msg, ...)
{
  va_list args;
  Object obj;

  va_start (args, msg);
  fprintf (stdout, "error: %s", msg);
  obj = va_arg (args, Object);
  if ( obj )
    {
      fprintf (stdout, ": ");
    }
  while ( obj )
    {
      print_object (stdout, obj, 0);
      obj = va_arg (args, Object);
      if ( obj )
	{
	  fprintf (stdout, ", ");
	}
    }
  fprintf (stdout, ".\n");
  longjmp (error_return, 1);
}

void 
warning (char *msg, ...)
{
  va_list args;
  Object obj;

  va_start (args, msg);
  fprintf (stdout, "warning: %s", msg);
  obj = va_arg (args, Object);
  if ( obj )
    {
      fprintf (stdout, ": ");
    }
  while ( obj )
    {
      print_object (stdout, obj, 0);
      obj = va_arg (args, Object);
      if ( obj )
	{
	  fprintf (stdout, ", ");
	}
    }
  fprintf (stdout, ".\n");
}
