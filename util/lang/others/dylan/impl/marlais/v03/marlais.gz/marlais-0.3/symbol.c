/*
   
   symbol.c

   Copyright, 1993, Brent Benson.  All Rights Reserved.

   Permission to use, copy, and modify this software and its
   documentation is hereby granted only under the following terms and
   conditions.  Both the above copyright notice and this permission
   notice must appear in all copies of the software, derivative works
   or modified version, and both notices must appear in supporting
   documentation.  Users of this software agree to the terms and
   conditions set forth in this notice and agree to inform the author,
   Brent Benson, of any noteworthy uses of this software.

*/

#include <string.h>
#include <ctype.h>
#include "symbol.h"
#include "alloc.h"
#include "string.h"

/* local function prototypes 
*/
static Object intern_symbol (char *name);

/* local data 
*/
#define SYMTAB_SIZE 1024
struct symtab *symbol_table[SYMTAB_SIZE];

/* function definitions 
*/
Object 
make_symbol (char *name)
{
  Object obj;

  obj = intern_symbol (name);
  return (obj);
}

Object 
make_keyword (char *name)
{
  Object obj;

  obj = intern_symbol (name);
  SYMBOLTYPE (obj) = Keyword;
  return (obj);
}


Object 
make_setter_symbol (Object sym)
{
  char *name;

  name = (char *) 
    checking_malloc (sizeof(char)*(strlen(SYMBOLNAME(sym)) + strlen("-setter")));
  strcpy (name, SYMBOLNAME(sym));
  strcat (name, "-setter");
  return (make_symbol (name));
}

static Object 
intern_symbol (char *name)
{
  int h, i;
  struct symtab *entry;
  Object sym;
  char *lower_name;

  lower_name = checking_strdup (name);
  while ( *lower_name )
    {
      *lower_name = tolower (*lower_name);
      lower_name++;
    }

  h = i = 0;
  while (name[i])
    {
      h += name[i++];
    }
  h = h % SYMTAB_SIZE;

  entry = symbol_table[h];
  while ( entry )
    {
      if (strcmp (name, SYMBOLNAME(entry->sym)) == 0)
	{
	  return (entry->sym);
	}
      entry = entry->next;
    }
  sym = allocate_object (sizeof (struct symbol));
  SYMBOLTYPE (sym) = Symbol;
  SYMBOLNAME (sym) = checking_strdup (name);
  entry = (struct symtab *) allocate_symtab ();
  entry->sym = sym;
  entry->next = symbol_table[h];
  symbol_table[h] = entry;
  return (sym);
}

