/*

   array.c

   Copyright, 1993, Brent Benson.  All Rights Reserved.

   Permission to use, copy, and modify this software and its
   documentation is hereby granted only under the following terms and
   conditions.  Both the above copyright notice and this permission
   notice must appear in all copies of the software, derivative works
   or modified version, and both notices must appear in supporting
   documentation.  Users of this software agree to the terms and
   conditions set forth in this notice and agree to inform the author,
   Brent Benson, of any noteworthy uses of this software.

*/

#include "array.h"
#include "prim.h"
#include "number.h"
#include "symbol.h"

static Object array_element (Object arr, Object indexes);
static Object array_element_setter (Object arr, Object indexes, Object new_val);
static Object array_dimensions (Object arr);
static Object array_initial_state (Object arr);
static Object array_next_state (Object arr, Object state);
static Object array_current_element (Object arr, Object state);

static struct primitive array_prims[] =
{
  {"%array-element", prim_2, array_element},
  {"%array-element-setter", prim_3, array_element_setter},
  {"%array-dimensions", prim_1, array_dimensions},
  {"%array-initial-state", prim_1, array_initial_state},
  {"%array-next-state", prim_2, array_next_state},
  {"%array-current-element", prim_2, array_current_element},
};

void 
init_array_prims (void)
{
  int num;
  
  num = sizeof (array_prims) / sizeof (struct primitive);
  init_prims (num, array_prims);
}

Object 
make_array (Object dims, Object fill)
{
  Object obj, dl, val;
  unsigned int size, i;

  obj = allocate_object (sizeof (struct array));
  ARRTYPE (obj) = Array;
  ARRDIMS (obj) = dims;
  dl = dims;
  size = 1;
  while (! NULLP (dl))
    {
      val = CAR (dl);
      if (! INTEGERP (val))
	{
	  error ("make: array dimensions must be integers", dims, NULL);
	}
      size *= INTVAL (val);
      dl = CDR (dl);
    }
  ARRELS (obj) = (Object *) checking_malloc (sizeof (Object) * size);
  for ( i=0 ; i < size ; ++i )
    {
      ARRELS(obj)[i] = fill;
    }
  return (obj);
}

Object
make_array_driver (Object args)
{
  int size, i;
  Object dim_obj, fill_obj, res;
  Object dim_keyword, fill_keyword;

  size = 0;
  dim_obj = NULL;
  fill_obj = NULL;
  dim_keyword = make_keyword ("dimensions:");
  fill_keyword = make_keyword ("fill:");
  while (! NULLP (args))
    {
      if (FIRST (args) == dim_keyword)
	{
	  dim_obj = SECOND (args);
	}
      else if (FIRST (args) == fill_keyword)
	{
	  fill_obj = SECOND (args);
	}
      else
	{
	  error ("make: unsupported keyword for <array> class", FIRST (args), NULL);
	}
      args = CDR (CDR (args));
    }
  if (dim_obj)
    {
      if (! PAIRP (dim_obj))
	{
	  error ("make: value of dimensions: "
		 "argument must be a list of integers", dim_obj, NULL);
	}
    }
  else
    {
      error ("make: dimensions: must be specified for <array>", args, NULL);
    }
  if (! fill_obj)
    {
      fill_obj = false_object;
    }
  
  /* actually fabricate the array */
  res = make_array (dim_obj, fill_obj);
  return (res);
}

/* static functions */

static Object 
array_element (Object arr, Object indexes)
{
  Object dims, inds, ind, dim;
  unsigned int offset, dim_val, ind_val, last_dim_val;
  
  dims = ARRDIMS (arr);
  inds = indexes;
  offset = 0;
  last_dim_val = 1;

  while (!NULLP(dims) && !NULLP(inds))
    {
      if (NULLP(dims))
	{
	  error ("element: too many indexes for array", arr, indexes, NULL);
	}
      if (NULLP(inds))
	{
	  error ("element: not enough indexes given", arr, indexes, NULL);
	}
      dim = CAR (dims);
      ind = CAR (inds);
      if (! INTEGERP (ind))
	{
	  error ("element: array indexes must be integers", ind, NULL);
	}
      dim_val = INTVAL (dim);
      ind_val = INTVAL (ind);
      if ((ind_val < 0) || (ind_val >= dim_val))
	{
	  error ("element: array index out of range", ind, NULL);
	}
      offset += (ind_val * last_dim_val);
      last_dim_val = dim_val;
      dims = CDR (dims);
      inds = CDR (inds);
    }
  if (! NULLP(dims))
    {
      error ("element: not enough indexes for array", arr, indexes, NULL);
    }
  if (! NULLP(inds))
    {
      error ("element: too many indexes given", arr, indexes, NULL);
    }
  return (ARRELS(arr)[offset]);
}

static Object 
array_element_setter (Object arr, Object indexes, Object new_val)
{
  Object dims, inds, ind, dim;
  unsigned int offset, dim_val, ind_val, last_dim_val;
  
  dims = ARRDIMS (arr);
  inds = indexes;
  offset = 0;
  last_dim_val = 1;

  while (!NULLP(dims) && !NULLP(inds))
    {
      if (NULLP(dims))
	{
	  error ("element: too many indexes for array", arr, indexes, NULL);
	}
      if (NULLP(inds))
	{
	  error ("element: not enough indexes given", arr, indexes, NULL);
	}
      dim = CAR (dims);
      ind = CAR (inds);
      if (! INTEGERP (ind))
	{
	  error ("element: array indexes must be integers", ind, NULL);
	}
      dim_val = INTVAL (dim);
      ind_val = INTVAL (ind);
      if ((ind_val < 0) || (ind_val >= dim_val))
	{
	  error ("element: array index out of range", ind, NULL);
	}
      offset += (ind_val * last_dim_val);
      last_dim_val = dim_val;
      dims = CDR (dims);
      inds = CDR (inds);
    }
  if (! NULLP(dims))
    {
      error ("element: not enough indexes for array", arr, indexes, NULL);
    }
  if (! NULLP(inds))
    {
      error ("element: too many indexes given", arr, indexes, NULL);
    }
  ARRELS(arr)[offset] = new_val;
  return (unspecified_object);
}

static Object 
array_dimensions (Object arr)
{
  return (ARRDIMS (arr));
}

static Object 
array_initial_state (Object arr)
{
  return (make_integer (0));
}

static Object 
array_next_state (Object arr, Object state)
{
  Object dims, dim;
  unsigned int total_size, state_val;

  total_size = 0;
  dims = ARRDIMS (arr);
  while (! NULLP (dims))
    {
      dim = CAR (dims);
      total_size += INTVAL (dim);
      dims = CDR (dims);
    }
  state_val = INTVAL (state);
  state_val++;
  if (state_val >= total_size)
    {
      return (false_object);
    }
  else
    {
      return (make_integer (state_val));
    }
}

static Object 
array_current_element (Object arr, Object state)
{
  return (ARRELS(arr)[INTVAL(state)]);
}
