/*

   apply.c

   Copyright, 1993, Brent Benson.  All Rights Reserved.

   Permission to use, copy, and modify this software and its
   documentation is hereby granted only under the following terms and
   conditions.  Both the above copyright notice and this permission
   notice must appear in all copies of the software, derivative works
   or modified version, and both notices must appear in supporting
   documentation.  Users of this software agree to the terms and
   conditions set forth in this notice and agree to inform the author,
   Brent Benson, of any noteworthy uses of this software.

*/

#include "apply.h"
#include "eval.h"
#include "print.h"
#include "prim.h"
#include "env.h"
#include "class.h"
#include "function.h"
#include "keyword.h"
#include "values.h"
#include "symbol.h"
#include "error.h"

/* global data */
int trace_functions = 0;
int trace_only_user_funs = 0;
int trace_level = 0;

/* local function prototypes and data */

static Object apply_method (Object meth, Object args, Object rest_methods);
static Object apply_generic (Object gen, Object args);
static Object apply_exit (Object exit_proc, Object args);
static Object apply_next_method (Object next_method, Object args);
static Object set_trace (Object bool);

/* primitives */

static struct primitive apply_prims[] =
{
  {"%apply", prim_2, apply},
  {"%trace", prim_1, set_trace},
};

/* function definitions */

void
init_apply_prims (void)
{
  int num;

  num = sizeof (apply_prims) / sizeof (struct primitive);
  init_prims (num, apply_prims);
}

Object 
apply (Object fun, Object args)
{
  Object ret;

  if ( trace_functions )
    {
      int i;
      
      if ((! trace_only_user_funs) || (! PRIMP(fun)))
	{
	  printf ("; ");
	  for ( i=0 ; i < trace_level ; ++i )
	    {
	      printf ("-");
	    }
	  print_object (stdout, fun, 1);
	  printf (" called with ");
	  print_object (stdout, args, 1);
	  printf ("\n");
	  trace_level++;
	}
    }
#ifdef SMALL_OBJECTS
  if (! POINTERP (fun))
    {
      error ("apply: cannot apply this object", fun, NULL);
    }
#endif
  switch (POINTERTYPE(fun))
    {
    case Primitive:
      ret = apply_prim (fun, args);
      break;
    case Method:
      ret = apply_method (fun, args, NULL);
      break;
    case GenericFunction:
      ret = apply_generic (fun, args);
      break;
    case NextMethod:
      ret = apply_next_method (fun, args);
      break;
    case Exit:
      ret = apply_exit (fun, args);
      break;
    default:
      error ("apply: cannot apply this object", fun, NULL);
    }
  if ( trace_functions && trace_level )
    {
      int i;

      if ((! trace_only_user_funs) || (! PRIMP(fun)))
	{
	  trace_level--;
	  printf ("; ");
	  for ( i=0 ; i < trace_level ; ++i )
	    {
	      printf ("-");
	    }
	  printf ("returned: ");
	  print_object (stdout, ret, 1);
	  printf ("\n");
	}
    }
  return (ret);
}

/* local functions */

static Object
apply_method (Object meth, Object args, Object rest_methods)
{
  Object params, param, sym, val, body, ret;
  Object rest_var, class, keyword, keys, key_decl;
  int hit_rest, hit_key;
  struct frame *old_env;

  params = METHPARAMS (meth);
  body = METHBODY (meth);

  /* remember current environment and subsitute with
     environment present at method creation time */
  old_env = the_env;
  the_env = METHENV (meth);

  push_scope ();

  /* install of next method object if there are next methods */
  if ( rest_methods )
    {
      Object next_method;

      next_method = make_next_method (rest_methods, args);
      push_scope ();
      add_binding (next_method_symbol, next_method);
    }

  hit_rest = hit_key = 0;

  /* first process required parameters */
  while ((! NULLP (params)) && (! hit_rest) && (! hit_key))
    {
      param = CAR (params);
      if (param == rest_symbol)
	{
	  hit_rest = 1;
	}
      else if (param == key_symbol)
	{
	  hit_key = 1;
	}
      else
	{
	  val = CAR (args);
	  if (SYMBOLP (param))
	    {
	      sym = param;
	    }
	  else
	    {
	      sym = FIRST (param);
	      class = eval (SECOND (param));
	      if (instance_p (val, class) == false_object)
		{
		  error ("apply: argument doesn't match method specializer", 
			 val, class, meth, NULL);
		}
	    }
	  add_binding (sym, val);
	  args = CDR (args);
	  params = CDR (params);
	}
    }

  /* now process #rest and #key parameters */
  if (! NULLP (params))
    {
      rest_var = NULL;
      if (CAR (params) == rest_symbol)
	{
	  params = CDR (params);
	  rest_var = CAR (params);
	  add_binding (rest_var, args);
	  params = CDR (params);
	}
      if ((! NULLP (params)) && (CAR (params) == key_symbol))
	{
	  /* provide default values for keywords if present */
	  params = CDR (params);
	  keys = params;
	  while (! NULLP (keys))
	    {
	      key_decl = CAR (keys);
	      if (! SYMBOLP (key_decl))
		{
		  if (SYMBOLP (CAR (key_decl)))
		    {
		      add_binding (CAR (key_decl), eval (SECOND (key_decl)));
		    }
		  else
		    {
		      error ("apply: cannot handle keywords with different parameter names", 
			     meth, NULL);
		    }
		}
	      else
		{
		  add_binding (key_decl, false_object);
		}
	      keys = CDR (keys);
	    }

	  while (! NULLP (args))
	    {
	      keyword = FIRST (args);
	      if (!KEYWORDP (keyword))
		{
		  error ("apply: argument to method must be keyword", meth, keyword, NULL);
		}
	      val = SECOND (args);
	      if (!rest_var)
		{
		  if (! change_binding (keyword_to_symbol (keyword), val))
		    {
		      error ("apply: method does not accept keyword", meth, keyword, NULL);
		    }
		}
	      else
		{
#if 0
		  /* warning: this is wrong */
		  warning ("apply: #rest and #key do not interact properly", meth);
#endif
		  add_binding (keyword, val);
		}
	      args = CDR (CDR (args));
	    }
	}
    }
  /* fixme: provide default values for #key parameters not specified */

  while (! NULLP (body))
    {
      ret = eval (CAR (body));
      body = CDR (body);
    }
  pop_scope();

  /* re-assert environment present at the beginning of this function
   */
  the_env = old_env;

  return (ret);
}

static Object
apply_generic (Object gen, Object args)
{
  Object methods, sorted_methods;

  methods = GFMETHODS (gen);
  sorted_methods = sorted_applicable_methods (gen, args);
  return (apply_method (CAR (sorted_methods), args, CDR (sorted_methods)));
}

static Object 
apply_exit (Object exit_proc, Object args)
{
  Object vals;

  unwind_to_exit (EXITSYM (exit_proc));
  if (NULLP (args))
    {
      longjmp (*EXITRET(exit_proc), (int)args);
    }
  else
    {
      longjmp (*EXITRET(exit_proc), (int)(values (args)));
    }
}

static Object
apply_next_method (Object next_method, Object args)
{
  Object rest_methods, real_args;

  rest_methods = NMREST (next_method);
  if (NULLP (args))
    {
      real_args = NMARGS (next_method);
    }
  else
    {
      real_args = args;
    }
  return (apply_method (CAR (rest_methods), real_args, CDR (rest_methods)));
}

static Object 
set_trace (Object flag)
{
  if (flag == false_object)
    {
      trace_functions = 0;
      trace_only_user_funs = 0;
    }
  else
    {
      trace_functions = 1;
      if (flag == make_keyword("user:"))
	{
	  trace_only_user_funs = 1;
	}
    }
  return (flag);
}
