/*

   syntax.c

   Copyright, 1993, Brent Benson.  All Rights Reserved.

   Permission to use, copy, and modify this software and its
   documentation is hereby granted only under the following terms and
   conditions.  Both the above copyright notice and this permission
   notice must appear in all copies of the software, derivative works
   or modified version, and both notices must appear in supporting
   documentation.  Users of this software agree to the terms and
   conditions set forth in this notice and agree to inform the author,
   Brent Benson, of any noteworthy uses of this software.

*/

#include <string.h>
#include "syntax.h"
#include "eval.h"
#include "list.h"
#include "class.h"
#include "function.h"
#include "symbol.h"
#include "values.h"
#include "apply.h"
#include "boolean.h"
#include "number.h"
#include "misc.h"
#include "error.h"

/* data structures */

struct syntax_entry
{
  Object sym;
  syntax_fun fun;
  struct syntax_entry *next;
};
#define SYNTAX_TABLE_SIZE 1024
struct syntax_entry *syntax_table[SYNTAX_TABLE_SIZE];

/* local variables and functions */

void install_syntax_entry (char *name, syntax_fun fun);

/* functions emobodying evaluation rules for forms */

static Object and_eval (Object form);
static Object begin_eval (Object form);
static Object bind_eval (Object form);
static Object bind_exit_eval (Object form);
static Object bind_methods_eval (Object form);
static Object case_eval (Object form);
static Object cond_eval (Object form);
static Object define_eval (Object form);
static Object define_class_eval (Object form);
static Object define_generic_function_eval (Object form);
static Object define_method_eval (Object form);
static Object dotimes_eval (Object form);
static Object for_eval (Object form);
static Object for_each_eval (Object form);
static Object if_eval (Object form);
static Object method_eval (Object form);
static Object or_eval (Object form);
static Object quasiquote_eval (Object form);
static Object quote_eval (Object form);
static Object select_eval (Object form);
static Object set_eval (Object form);
static Object unless_eval (Object form);
static Object until_eval (Object form);
static Object unwind_protect_eval (Object form);
static Object when_eval (Object form);
static Object while_eval (Object form);

static char *syntax_operators[] =
{
  "and",
  "begin",
  "bind",
  "bind-exit",
  "bind-methods",
  "case",
  "cond",
  "define",
  "define-class",
  "define-generic-function",
  "define-method",
  "dotimes",
  "for",
  "for-each",
  "if",
  "method",
  "or",
  "quasiquote",
  "quote",
  "select",
  "set!",
  "unless",
  "until",
  "unwind-protect",
  "when",
  "while",
};

static syntax_fun syntax_functions[] =
{
  and_eval,
  begin_eval,
  bind_eval,
  bind_exit_eval,
  bind_methods_eval,
  case_eval,
  cond_eval,
  define_eval,
  define_class_eval,
  define_generic_function_eval,
  define_method_eval,
  dotimes_eval,
  for_eval,
  for_each_eval,
  if_eval,
  method_eval,
  or_eval,
  quasiquote_eval,
  quote_eval,
  select_eval,
  set_eval,
  unless_eval,
  until_eval,
  unwind_protect_eval,
  when_eval,
  while_eval,
};

void
init_syntax_table (void)
{
  int numops, i;
  Object symbol;

  numops = sizeof (syntax_operators) / sizeof (char *);
  for ( i=0 ; i < numops ; ++i )
    {
      install_syntax_entry (syntax_operators[i],
			    syntax_functions[i]);
    }
}

syntax_fun 
syntax_function (Object sym)
{
  struct syntax_entry *entry;
  int h;

  h = ((int)sym) % SYNTAX_TABLE_SIZE;
  entry = syntax_table[h];
  while ( entry )
    {
      if (entry->sym == sym)
	{
	  return (entry->fun);
	}
      entry = entry->next;
    }
  return (NULL);
}

void 
install_syntax_entry (char *name, syntax_fun fun)
{
  struct syntax_entry *entry;
  Object sym;
  int h;

  sym = make_symbol (name);
  h = ((int)sym) % SYNTAX_TABLE_SIZE;
  entry = (struct syntax_entry *) 
    checking_malloc (sizeof (struct syntax_entry));
  entry->sym = sym;
  entry->fun = fun;
  entry->next = syntax_table[h];
  syntax_table[h] = entry;
}

/* functions that perform the special evaluation
   rules for syntax forms. */

static Object
and_eval (Object form)
{
  Object clauses, ret;

  clauses = CDR (form);
  while (! NULLP (clauses))
    {
      ret = eval (CAR (clauses));
      if (ret == false_object)
	{
	  return (false_object);
	}
      clauses = CDR (clauses);
    }
  return (ret);
}

static Object 
begin_eval (Object form)
{
  Object res;

  form = CDR (form);
  while (! NULLP (form))
    {
      res = eval (CAR (form));
      form = CDR (form);
    }
  return (res);
}

static Object
bind_eval (Object form)
{
  Object bindings, body, binding, var, val, res;
  Object first, last, new, type;
  int value_count, i;
  
  if (NULLP (CDR (form)))
    {
      error ("malformed bind form", form, NULL);
    }
  bindings = SECOND (form);
  body = CDR (CDR (form));

  push_scope ();
  while (! NULLP (bindings))
    {
      binding = CAR (bindings);
      if (! PAIRP (binding))
	{
	  error ("bind: bad binding", binding, NULL);
	}
      while (! NULLP (CDR (binding)))
	{
	  binding = CDR (binding);
	}
      val = eval (CAR (binding));
      if (VALUESP (val))
	{
	  value_count = 0;
	  binding = CAR (bindings);
	  while (! PAIRP (CAR (binding)))
	    {
	      var = CAR (binding);
	      if (var == rest_symbol)
		{
		  var = CAR (CDR (binding));
		  last = NULL;
		  first = empty_list;
		  for ( i=value_count ; i < VALUESNUM (val) ; ++i )
		    {
		      new = cons (VALUESELS(val)[i], empty_list);
		      if ( last )
			{
			  CDR (last) = new;
			}
		      else
			{
			  first = new;
			}
		      last = new;
		    }
		  add_binding (var, first);
		}
	      else
		{
		  new = VALUESELS(val)[value_count];
		  add_binding (var, new);
		  value_count++;
		}
	      binding = CDR (binding);
	    }
	}
      else
	{
	  binding = CAR (bindings);
	  var = CAR (binding);
	  if (PAIRP (var))
	    {
	      type = eval (SECOND (var));
	      if (! CLASSP (type))
		{
		  error ("bind: badly formed binding", binding, NULL);
		}
	      if (instance_p (val, type) == false_object)
		{
		  error ("bind: value does not satisfy type constraint", val, type, NULL);
		}
	      var = FIRST (var);
	    }
	  add_binding (var, val);
	}
      bindings = CDR (bindings);
    }
  
  /* evaluate forms in body */
  while (! NULLP (body))
    {
      res = eval (CAR (body));
      body = CDR (body);
    }
  pop_scope ();
  return (res);

}

static Object 
bind_exit_eval (Object form)
{
  Object exit_obj, sym, body, ret, val, sec;
  jmp_buf buf;

  if (NULLP (CDR (form)))
    {
      error ("malformed bind-exit form", form, NULL);
    }
  sec = SECOND (form);
  if (! PAIRP (sec))
    {
      error ("bind-exit: second argument must be a list containing a symbol", sec, NULL);
    }
  sym = CAR (sec);
  body = CDR (CDR (form));
  if (! SYMBOLP (sym))
    {
      error ("bind-exit: bad exit procedure name", sym, NULL);
    }
  exit_obj = make_exit (sym);
  ret = (Object) setjmp (*EXITRET(exit_obj));
  push_scope ();
  add_binding (sym, exit_obj);
  if (! ret )
    {
      while (! NULLP (body))
	{
	  ret = eval (CAR (body));
	  body = CDR (body);
	}
      pop_scope ();
      return (ret);
    }
  else
    {
      pop_scope ();
      return (ret);
    }
}

static Object 
bind_methods_eval (Object form)
{
  Object specs, body, spec, ret;
  Object name, params, method_body, method;

  if (NULLP (CDR (form)))
    {
      error ("bind-methods: bad form", form, NULL);
    }
  specs = SECOND (form);
  body = CDR (CDR (form));
  
  push_scope ();
  /* first bind method names to dummy values */
  while (! NULLP (specs))
    {
      spec = CAR (specs);
      name = FIRST (spec);
      add_binding (name, false_object);
      specs = CDR (specs);
    }

  /* now, actually make the methods */
  specs = SECOND (form);
  while (! NULLP (specs))
    {
      spec = CAR (specs);
      name = FIRST (spec);
      params = SECOND (spec);
      method_body = CDR (CDR (spec));
      method = make_method (name, params, method_body, the_env, 0);
      modify_value (name, method);
      specs = CDR (specs);
    }

  /* evaluate the body forms */
  while (! NULLP (body))
    {
      ret = eval (CAR (body));
      body = CDR (body);
    }
  pop_scope ();
  return (ret);
}

static Object
case_eval (Object form)
{
  Object target_form, branches, branch;
  Object match_list, consequents, ret;

  if (NULLP (CDR (form)))
    {
      error ("malformed case", form, NULL);
    }
  target_form = eval (CAR (CDR (form)));

  if (NULLP (CDR (CDR (form))))
    {
      error ("malformed case", form, NULL);
    }
  branches = CDR (CDR (form));
  while (! NULLP (branches))
    {
      branch = CAR (branches);
      if (! PAIRP (branch))
	{
	  error ("case: malformed branch", branch, NULL);
	}
      match_list = CAR (branch);
      if ((match_list == true_object) || (match_list == else_keyword))
	{
	  consequents = CDR (branch);
	  ret = false_object;
	  while (! NULLP (consequents))
	    {
	      ret = eval (CAR (consequents));
	      consequents = CDR (consequents);
	    }
	  return (ret);
	}
      if (! PAIRP (match_list))
	{
	  error ("select: malformed test expression", match_list, NULL);
	}
      while (! NULLP (match_list))
	{
	  if (id_p (CAR (match_list), target_form, empty_list) != false_object)
	    {
	      consequents = CDR (branch);
	      ret = false_object;
	      while (! NULLP (consequents))
		{
		  ret = eval (CAR (consequents));
		  consequents = CDR (consequents);
		}
	      return (ret);
	    }
	  match_list = CDR (match_list);
	}
      branches = CDR (branches);
    }
  error ("case: no matching clause", target_form, NULL);
}

static Object
cond_eval (Object form)
{
  Object clauses, clause, test, ret;

  clauses = CDR (form);
  while (! NULLP (clauses))
    {
      clause = CAR (clauses);
      test = CAR (clause);
      if (eval (test) != false_object)
	{
	  clause = CDR (clause);
	  while (! NULLP (clause))
	    {
	      ret = eval (CAR (clause));
	      clause = CDR (clause);
	    }
	  return (ret);
	}
      clauses = CDR (clauses);
    }
  return (false_object);
}

static Object 
define_eval (Object form)
{
  Object sym, val;

  if (NULLP (CDR (form)))
    {
      error ("DEFINE form requires two args: (define <var> <val>)", form, NULL);
    }
  sym = SECOND (form);
  if (NULLP (CDR (CDR (form))))
    {
      error ("DEFINE form requires two args: (define <var> <val>)", form, NULL);
    }
  val = eval (THIRD (form));

  add_top_level_binding (sym, val);
  return (unspecified_object);
}

static Object 
define_class_eval (Object form)
{
  Object name, supers, slots, class;

  if (NULLP (CDR (form)))
    {
      error ("malfored define-class", form, NULL);
    }
  name = SECOND (form);
  if (NULLP (CDR (CDR (form))))
    {
      error ("malformed define-class", form, NULL);
    }
  supers = map (eval, THIRD (form));
  slots = CDR (CDR (CDR (form)));
  class = make_class (SYMBOLNAME(name), supers, slots);
  add_top_level_binding (name, class);
  return (unspecified_object);
}

static Object 
define_generic_function_eval (Object form)
{
  Object name, params, gf;
  
  if (NULLP (CDR (form)))
    {
      error ("define-generic-function: missing name", form, NULL);
    }
  name = SECOND (form);
  if (NULLP (CDR (CDR (form))))
    {
      error ("define-generic-function: missing parameters", form, NULL);
    }
  params = THIRD (form);

  gf = make_generic_function (name, params, empty_list);
  add_top_level_binding (name, gf);
  return (unspecified_object);
}

static Object 
define_method_eval (Object form)
{
  Object name, params, body, method, gf;

  if (NULLP (CDR (form)))
    {
      error ("define-method: missing name", form, NULL);
    }
  name = SECOND (form);
  if (! SYMBOLP (name))
    {
      error ("define-method: first argument must be a symbol", name, NULL);
    }
  if (NULLP (CDR (CDR (form))))
    {
      error ("define-method: missing parameter list", form, NULL);
    }
  params = THIRD (form);
  if (! LISTP (params))
    {
      error ("define-method: second argument must be a parameter list", params, NULL);
    }
  body = CDR (CDR (CDR (form)));
  method = make_method (name, params, body, the_env, 1);
  return (unspecified_object);
}

static Object 
dotimes_eval (Object form)
{
  Object clause, var, intval, resform, body, res;
  int i;

  if (NULLP (CDR (form)))
    {
      error ("malformed dotimes expression", form, NULL);
    }
  clause = CAR (CDR (form));
  if (! PAIRP (clause))
    {
      error ("second arg to dotimes must be a list", clause, NULL);
    }
  var = CAR (clause);
  if (! SYMBOLP (var))
    {
      error ("dotimes: first value in spec clause must be a symbol", var, NULL);
    }
  if (NULLP (CDR (clause)))
    {
      error ("dotimes: must specifiy an upper bound", form, NULL);
    }
  intval = eval (CAR (CDR (clause)));
  if (! INTEGERP (intval))
    {
      error ("dotimes: upper bound must an integer", intval, NULL);
    }
  if (! NULLP (CDR (CDR (clause))))
    {
      resform = CAR (CDR (CDR (clause)));
    }
  else
    {
      resform = NULL;
    }

  push_scope ();
  add_binding (var, false_object);
  for ( i=0 ; i < INTVAL (intval) ; ++i )
    {
      change_binding (var, make_integer (i));
      body = CDR (CDR (form));
      while (! NULLP (body))
	{
	  res = eval (CAR (body));
	  body = CDR (body);
	}
    }
  if (resform)
    {
      res = eval (resform);
    }
  else
    {
      res = false_object;
    }
  pop_scope ();
  return (res);
}

/*

  (for ((var-form init-form step-form)
        ...)
       (test-form return-form)
    form1 form2 ...)

*/
static Object 
for_eval (Object form)
{
  Object var_forms, var_form, test_form, return_forms;
  Object var, vars, inits, body, ret, new_vals;

  if (NULLP (CDR (form)))
    {
      error ("malformed FOR", form, NULL);
    }
  if (NULLP (CDR (CDR (form))))
    {
      error ("malformed FOR", form, NULL);
    }
  test_form = FIRST (THIRD (form));
  return_forms = CDR (THIRD (form));

  var_forms = SECOND (form);
  vars = map (car, var_forms);
  inits = map (second, var_forms);
  inits = map (eval, inits);

  push_scope ();
  add_bindings (vars, inits);

  /* now loop until exit */
  while (eval (test_form) == false_object)
    {
      body = CDR (CDR (CDR (form)));
      while (! NULLP (body))
	{
	  eval (CAR (body));
	  body = CDR (body);
	}

      var_forms = SECOND (form);
      vars = map (car, var_forms);
      new_vals = map (third, var_forms);
      new_vals = map (eval, new_vals);

      while (! NULLP (vars))
	{
	  modify_value (CAR (vars), CAR (new_vals));
	  vars = CDR (vars);
	  new_vals = CDR (new_vals);
	}
    }
  if (NULLP (return_forms))
    {
      ret = false_object;
    }
  else
    {
      while (! NULLP (return_forms))
	{
	  ret = eval (CAR (return_forms));
	  return_forms = CDR (return_forms);
	}
    }
  pop_scope ();
  return (ret);
}


/*
   The iteration is terminated if any collection is exhausted 
   (in which case #f is returned) or if the end-test evaluates 
   to #t (in which case the result forms are evaluated and the
   value of the last is returned).
*/
static Object 
for_each_eval (Object form)
{
  Object test_form, return_forms, var_forms;
  Object vars, collections, states, vals, body, ret, temp_vars;
  Object init_state_fun, next_state_fun, cur_el_fun;

  init_state_fun = symbol_value (make_symbol ("initial-state"));
  if (! init_state_fun)
    {
      error ("for-each: no initial-state function defined", NULL);
    }
  next_state_fun = symbol_value (make_symbol ("next-state"));
  if (! next_state_fun)
    {
      error ("for-each: no next-state function defined", NULL);
    }
  cur_el_fun = symbol_value (make_symbol ("current-element"));
  if (! cur_el_fun)
    {
      error ("for-each: no current-element function defined", NULL);
    }

  if (NULLP (CDR (form)))
    {
      error ("malformed FOR-EACH", form, NULL);
    }
  if (NULLP (CDR (CDR (form))))
    {
      error ("malformed FOR-EACH", form, NULL);
    }
  test_form = FIRST (THIRD (form));
  return_forms = CDR (THIRD (form));

  var_forms = SECOND (form);
  vars = map (car, var_forms);
  collections = map (second, var_forms);
  collections = map (eval, collections);
  states = list_map1 (init_state_fun, collections);

  if (member_p (false_object, states, NULL) != false_object)
    {
      return (false_object);
    }
  vals = list_map2 (cur_el_fun, collections, states);
  push_scope ();
  add_bindings (vars, vals);

  while (eval (test_form) == false_object)
    {
      body = CDR (CDR (CDR (form)));
      while (! NULLP (body))
	{
	  eval (CAR (body));
	  body = CDR (body);
	}
      states = list_map2 (next_state_fun, collections, states);
      if (member_p (false_object, states, NULL) != false_object)
	{
	  pop_scope ();
	  return (false_object);
	}
      vals = list_map2 (cur_el_fun, collections, states);

      /* modify bindings */
      temp_vars = vars;
      while (! NULLP (temp_vars))
	{
	  modify_value (CAR (temp_vars), CAR (vals));
	  temp_vars = CDR (temp_vars);
	  vals = CDR (vals);
	}
    }

  if (NULLP (return_forms))
    {
      return (false_object);
    }
  else
    {
      while (! NULLP (return_forms))
	{
	  ret = eval (CAR (return_forms));
	  return_forms = CDR (return_forms);
	}
    }
  pop_scope ();
  return (ret);
}

static Object 
if_eval (Object form)
{
  Object testval, thenform, elseform;

  if (NULLP (CDR (form)))
    {
      error ("malformed if expression", form, NULL);
    }
  testval = SECOND (form);
  if (NULLP (CDR (CDR (form))))
    {
      error ("malformed if expression", form, NULL);
    }
  thenform = THIRD (form);
  if (NULLP (CDR (CDR (CDR (form)))))
    {
      error ("if expression must have else clause", form, NULL);
    }
  elseform = FOURTH (form);
  if (! NULLP (CDR (CDR (CDR (CDR (form))))))
    {
      error ("if: too many arguments", NULL);
    }
  
  if (eval(testval) == false_object)
    {
      return (eval (elseform));
    }
  else
    {
      return (eval (thenform));
    }
}

static Object 
method_eval (Object form)
{
  Object params, body, method;

  if (NULLP (CDR (form)))
    {
      error ("method: missing parameters", form, NULL);
    }
  params = SECOND (form);
  body = CDR (CDR (form));
  method = make_method (NULL, params, body, the_env, 0);
  return (method);
}

static Object
or_eval (Object form)
{
  Object clauses, ret;

  clauses = CDR (form);
  while (! NULLP (clauses))
    {
      ret = eval (CAR (clauses));
      if (ret != false_object)
	{
	  return (ret);
	}
      clauses = CDR (clauses);
    }
  return (false_object);
}

/* The quasiquote code here is pretty kludgy, inefficient, and
   should be replaced.  It is a translation from some Scheme
   code.  I just needed quasiquote real fast.
*/

static Object qq_help (Object skel);
static Object combine_skels (Object lft, Object rgt, Object skel);
static int is_const (Object obj);

static Object 
quasiquote_eval (Object form)
{
  return (eval (qq_help (SECOND (form))));
}

static Object
qq_help (Object skel)
{
  if (NULLP (skel))
    {
      return (empty_list);
    }
  else
    {
      if (SYMBOLP (skel))
	{
	  return (listem (quote_symbol, skel, NULL));
	}
      else
	{
	  if (! PAIRP (skel))
	    {
	      return (skel);
	    }
	  else
	    {
	      if (CAR (skel) == unquote_symbol)
		{
		  return (SECOND (skel));
		}
	      else if (CAR (skel) == quasiquote_symbol)
		{
		  return (qq_help (qq_help (SECOND (skel))));
		}
	      else if (PAIRP(CAR(skel)) && (CAR(CAR(skel)) == unquote_splicing_symbol))
		{
		  return (listem (make_symbol("concatenate"), CAR(CDR(CAR(skel))), qq_help(CDR(skel))));
		}
	      else
		{
		  return (combine_skels (qq_help(CAR(skel)), 
					 (NULLP(CDR(skel)) ? empty_list : qq_help (CDR(skel))),
					 skel));
		}
	    }
	}
    }
}

static Object 
combine_skels (Object lft, Object rgt, Object skel)
{
  Object list_symbol;

  list_symbol = make_symbol ("list");
  if (is_const (lft) && is_const (rgt))
    {
      return (listem (quote_symbol, skel));
    }
  else
    {
      if (NULLP (rgt))
	{
	  return (listem (list_symbol, lft));
	}
      else
	{
	  if (PAIRP (rgt) && (CAR (rgt) == list_symbol))
	    {
	      return (cons (list_symbol, cons (lft, (CDR (rgt)))));
	    }
	  else
	    {
	      return (listem (make_symbol("pair"), lft, rgt));
	    }
	}
    }
}

static int
is_const (Object obj)
{
  if (PAIRP(obj))
    {
      return (CAR(obj) == quote_symbol);
    }
  else
    {
      return (0);
    }
}

static Object 
quote_eval (Object form)
{
  return (SECOND (form));
}

static Object 
select_eval (Object form)
{
  Object target_form, test, branches, branch;
  Object match_list, consequents, ret;

  if (NULLP (CDR (form)))
    {
      error ("malformed select", form, NULL);
    }
  target_form = eval (CAR (CDR (form)));

  if (NULLP (CDR (CDR (form))))
    {
      error ("malformed select", form, NULL);
    }
  test = eval (CAR (CDR (CDR (form))));

  if (NULLP (CDR (CDR (CDR (form)))))
    {
      error ("malformed select", form, NULL);
    }
  branches = CDR (CDR (CDR (form)));
  while (! NULLP (branches))
    {
      branch = CAR (branches);
      if (! PAIRP (branch))
	{
	  error ("select: malformed branch", branch, NULL);
	}
      match_list = CAR (branch);
      if ((match_list == true_object) || (match_list == else_keyword))
	{
	  consequents = CDR (branch);
	  while (! NULLP (consequents))
	    {
	      ret = eval (CAR (consequents));
	      consequents = CDR (consequents);
	    }
	  return (ret);
	}
      if (! PAIRP (match_list))
	{
	  error ("select: malformed test expression", match_list, NULL);
	}
      while (! NULLP (match_list))
	{
	  if (apply (test, listem (target_form, eval (CAR (match_list)), NULL)) != false_object)
	    {
	      consequents = CDR (branch);
	      while (! NULLP (consequents))
		{
		  ret = eval (CAR (consequents));
		  consequents = CDR (consequents);
		}
	      return (ret);
	    }
	  match_list = CDR (match_list);
	}
      branches = CDR (branches);
    }
  return (unspecified_object);
}

static Object 
set_eval (Object form)
{
  Object sym, val, setter_sym;

  if (NULLP (CDR (form)))
    {
      error ("set!: missing forms", form, NULL);
    }
  sym = SECOND (form);
  
  if (PAIRP(sym))
    {
      setter_sym = make_setter_symbol (CAR (sym));
      eval (cons (setter_sym, 
		  append (CDR (sym), CDR (CDR (form)))));
      return (unspecified_object);
      
    }
  if (NULLP (CDR (CDR (form))))
    {
      error ("set!: missing forms", form, NULL);
    }
  val = eval (THIRD (form));
  modify_value (sym, val);
  return (unspecified_object);
}

static Object 
unless_eval (Object form)
{
  Object test, body, ret;

  if (NULLP (CDR (form)))
    {
      error ("unless: missing forms", form, NULL);
    }
  test = SECOND (form);
  body = CDR (CDR (form));
  if (eval (test) == false_object)
    {
      while (! NULLP (body))
	{
	  ret = eval (CAR (body));
	  body = CDR (body);
	}
      return (ret);
      
    }
  return (false_object);
}

static Object 
until_eval (Object form)
{
  Object test, body, ret, forms;

  if (NULLP (CDR (form)))
    {
      error ("malformed until statment", form, NULL);
    }
  test = CAR (CDR (form));
  body = CDR (CDR (form));

  while (eval (test) == false_object)
    {
      forms = body;
      while (! NULLP (forms))
	{
	  ret = eval (CAR (forms));
	  forms = CDR (forms);
	}
    }
  return (ret);
}

static Object 
unwind_protect_eval (Object form)
{
  Object protected, cleanups, unwind, ret;

  if (NULLP (CDR (form)))
    {
      error ("unwind-protect: missing forms", form, NULL);
    }
  protected = SECOND (form);
  cleanups = CDR (CDR (form));
  unwind = make_unwind (cleanups);

  push_scope ();
  add_binding (unwind_symbol, unwind);
  ret = eval (protected);
  pop_scope ();
  return (ret);
}

static Object 
when_eval (Object form)
{
  Object test, body, ret;

  if (NULLP (CDR (form)))
    {
      error ("when: missing forms", form, NULL);
    }
  test = SECOND (form);
  body = CDR (CDR (form));
  if (eval (test) != false_object)
    {
      while (! NULLP (body))
	{
	  ret = eval (CAR (body));
	  body = CDR (body);
	}
      return (ret);
      
    }
  return (false_object);
}

static Object 
while_eval (Object form)
{
  Object test, body, ret, forms;

  if (NULLP (CDR (form)))
    {
      error ("malformed while statment", form, NULL);
    }
  test = CAR (CDR (form));
  body = CDR (CDR (form));

  while (eval (test) != false_object)
    {
      forms = body;
      while (! NULLP (forms))
	{
	  ret = eval (CAR (forms));
	  forms = CDR (forms);
	}
    }
  return (ret);
}

