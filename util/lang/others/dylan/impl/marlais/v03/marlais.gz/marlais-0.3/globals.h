/*

   globals.h

   Copyright, 1993, Brent Benson.  All Rights Reserved.

   Permission to use, copy, and modify this software and its
   documentation is hereby granted only under the following terms and
   conditions.  Both the above copyright notice and this permission
   notice must appear in all copies of the software, derivative works
   or modified version, and both notices must appear in supporting
   documentation.  Users of this software agree to the terms and
   conditions set forth in this notice and agree to inform the author,
   Brent Benson, of any noteworthy uses of this software.

*/

/* This file should only be included once in main.c.
*/

/* globals */
jmp_buf error_return;

/* important objects */
Object true_object, false_object, empty_list;
Object eof_object, unspecified_object, uninit_slot_object;
Object key_symbol, rest_symbol, next_symbol;
Object quote_symbol;
Object getter_keyword, setter_keyword, else_keyword;
Object type_keyword, init_value_keyword, init_function_keyword;
Object init_keyword_keyword, required_init_keyword_keyword, allocation_keyword;
Object unwind_symbol, next_method_symbol, initialize_symbol;
Object equal_hash_symbol;
Object quasiquote_symbol, unquote_symbol, unquote_splicing_symbol;

/* builtin classes */
Object object_class; 
Object boolean_class;
Object number_class, real_class, integer_class, ratio_class; 
Object single_float_class, double_float_class;
Object collection_class, sequence_class, mutable_sequence_class;
Object mutable_collection_class;
Object list_class, empty_list_class, pair_class, string_class;
Object byte_string_class, vector_class, simple_object_vector_class;
Object explicit_key_collection_class, mutable_explicit_key_collection_class;
Object table_class, deque_class, array_class;
Object condition_class;
Object symbol_class, keyword_class;
Object character_class;
Object function_class, primitive_class, generic_function_class, method_class;
Object class_class, stream_class, table_entry_class, deque_entry_class;
