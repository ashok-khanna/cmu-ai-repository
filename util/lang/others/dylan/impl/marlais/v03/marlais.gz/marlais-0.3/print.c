/*

   print.c

   Copyright, 1993, Brent Benson.  All Rights Reserved.

   Permission to use, copy, and modify this software and its
   documentation is hereby granted only under the following terms and
   conditions.  Both the above copyright notice and this permission
   notice must appear in all copies of the software, derivative works
   or modified version, and both notices must appear in supporting
   documentation.  Users of this software agree to the terms and
   conditions set forth in this notice and agree to inform the author,
   Brent Benson, of any noteworthy uses of this software.

*/

#include <stdio.h>
#include "print.h"
#include "list.h"
#include "error.h"

/* local function prototypes */

static Object print_obj_escaped (Object obj);
static void print_pair (FILE *fp, Object pair, int escaped);
static void print_character (FILE *fp, Object c, int escaped);
static void print_vector (FILE *fp, Object vec, int escaped);
static void print_values (FILE *fp, Object vals, int escaped);
static void print_string (FILE *fp, Object str, int escaped);
static void print_instance (FILE *fp, Object inst, int escaped);
static void print_method (FILE *fp, Object method, int escaped);
static void print_array (FILE *fp, Object array, int escaped);
static Object format (Object stream, Object str, Object rest);
static void print_stream (FILE *fp, Object stream);
static Object write_char (Object ch, Object stream_list);

/* primitives */

static struct primitive print_prims[] =
{
  {"%print", prim_1, print_obj},
  {"%princ", prim_1, print_obj_escaped},
  {"%format", prim_3, format},
  {"%write-char", prim_2, write_char},
};

/* function definitions */

void
init_print_prims (void)
{
  int num;

  num = sizeof (print_prims) / sizeof (struct primitive);
  init_prims (num, print_prims);
}

void 
print_object (FILE *fp, Object obj, int escaped)
{
  switch (TYPE (obj))
    {
    case True:
      fprintf (fp, "#t");
      break;
    case False:
      fprintf (fp, "#f");
      break;
    case EmptyList:
      fprintf (fp, "()");
      break;
    case Integer:
      fprintf (fp, "%d", INTVAL(obj));
      break;
    case DoubleFloat:
      fprintf (fp, "%f", DFLOATVAL(obj));
      break;
    case Symbol:
      fprintf (fp, "%s", SYMBOLNAME(obj));
      break;
    case Keyword:
      fprintf (fp, "%s", KEYNAME(obj));
      break;
    case Pair:
      print_pair (fp, obj, escaped);
      break;
    case Character:
      print_character (fp, obj, escaped);
      break;
    case SimpleObjectVector:
      print_vector (fp, obj, escaped);
      break;
    case ByteString:
      print_string (fp, obj, escaped);
      break;
    case Table:
      fprintf (fp, "{table}");
      break;
    case Deque:
      fprintf (fp, "{deque}");
      break;
    case Array:
      print_array (fp, obj, escaped);
      break;
    case Primitive:
      fprintf (fp, "{primitive function %s}", PRIMNAME(obj));
      break;
    case GenericFunction:
      fprintf (fp, "{the generic function %s}", SYMBOLNAME(GFNAME(obj)));
      break;
    case Method:
      print_method (fp, obj, escaped);
      break;
    case Class:
      fprintf (fp, "{the class %s}", SYMBOLNAME(CLASSNAME(obj)));
      break;
    case Instance:
      print_instance (fp, obj, escaped);
      break;
    case Singleton:
      fprintf (fp, "{the singleton ");
      print_object (fp, SINGLEVAL (obj), escaped);
      fprintf (fp, "}");
      break;
    case EndOfFile:
      fprintf (fp, "{end of file}");
      break;
    case Values:
      print_values (fp, obj, escaped);
      break;
    case Unspecified:
      break;
    case Exit:
      fprintf (fp, "{exit procedure}");
      break;
    case Unwind:
      fprintf (fp, "{unwind protect}");
      break;
    case Stream:
      print_stream (fp, obj);
      break;
    case TableEntry:
      fprintf (fp, "{table entry}");
      break;
    case UninitializedSlotValue:
      fprintf (fp, "{uninitialized slot value}");
      break;
    case DequeEntry:
      fprintf (fp, "{deque entry ", DEVALUE (obj));
      print_object (fp, DEVALUE (obj), escaped);
      fprintf (fp, "}");
      break;
    default:
      error ("print: unknown object type", NULL);
    }
}

Object
print_obj (Object obj)
{
  print_object (stdout, obj, 1);
  if (obj != unspecified_object)
    {
      printf ("\n");
    }
  return (unspecified_object);
}

static Object
print_obj_escaped (Object obj)
{
  print_object (stdout, obj, 0);
  if (obj != unspecified_object)
    {
      printf ("\n");
    }
  return (unspecified_object);
}

void
print_err (Object obj)
{
  print_object (stderr, obj, 1);
  fflush (stderr);
}

static void
print_pair (FILE *fp, Object pair, int escaped)
{
  Object cdr;

  fprintf (fp, "(");
  print_object (fp, CAR (pair), escaped);
  cdr = CDR (pair);
  while ((cdr != empty_list) && PAIRP(cdr))
    {
      fprintf (fp, " ");
      print_object (fp, CAR (cdr), escaped);
      cdr = CDR (cdr);
    }
  if (cdr != empty_list)
    {
      fprintf (fp, " . ");
      print_object (fp, cdr, escaped);
    }
  fprintf (fp, ")");
}

static void 
print_character (FILE *fp, Object c, int escaped)
{
  char ch;

  ch = CHARVAL(c);
  if ( escaped )
    {
      switch (ch)
	{
	case '\n':
	  fprintf (fp, "#\\newline");
	  break;
	case ' ':
	  fprintf (fp, "#\\space");
	  break;
	case 0x7f:
	  fprintf (fp, "#\\rubout");
	  break;
	case '\f':
	  fprintf (fp, "#\\page");
	  break;
	case '\t':
	  fprintf (fp, "#\\tab");
	  break;
	case '\b':
	  fprintf (fp, "#\\backspace");
	  break;
	case '\r':
	  fprintf (fp, "#\\return");
	  break;
	default:
	  fprintf (fp, "#\\%c", ch);
	}
    }
  else
    {
      fprintf (fp, "%c", ch);
    }
}

static void 
print_vector (FILE *fp, Object vec, int escaped)
{
  int i;

  fprintf (fp, "#(");
  for ( i=0 ; i < SOVSIZE(vec) ; ++i )
    {
      print_object (fp, SOVELS(vec)[i], escaped);
      if (i < (SOVSIZE(vec) - 1))
	{
	  fprintf (fp, " ");
	}
    }
  fprintf (fp, ")");
}

static void 
print_instance (FILE *fp, Object inst, int escaped)
{
  Object slots, slot;

  fprintf (fp, "{instance of class %s", SYMBOLNAME(CLASSNAME(INSTCLASS(inst))));
  slots = INSTSLOTS (inst);
  while (! NULLP (slots))
    {
      slot = CAR (slots);
      fprintf (fp, " ");
      print_object (fp, CAR (slot), escaped);
      fprintf (fp, "=");
      print_object (fp, CDR (slot), escaped);
      if (! NULLP (CDR (slots)))
	{
	  fprintf (fp, " ");
	}
      slots = CDR (slots);
    }
  fprintf (fp, "}");
}

static void 
print_values (FILE *fp, Object vals, int escaped)
{
  int i, num;

  num = VALUESNUM (vals);
  for ( i=0 ; i < num ; ++i )
    {
      print_object (fp, VALUESELS(vals)[i], escaped);
      if (i < (num - 1))
	{
	  fprintf (fp, "\n");
	}
    }
}

static void 
print_method (FILE *fp, Object method, int escaped)
{
  if (METHNAME (method))
    {
      fprintf (fp, "{method %s ", SYMBOLNAME(METHNAME(method)));
      print_object (fp, METHPARAMS (method), escaped);
      fprintf (fp, "}");
    }
  else
    {
      fprintf (fp, "{an anonymous method ");
      print_object (fp, METHPARAMS (method), escaped);
      fprintf (fp, "}");
    }
}

#if 0
static void 
print_array (FILE *fp, Object array, int escaped)
{
  fprintf (fp, "{array ");
  print_object (fp, ARRDIMS(array), escaped);
  fprintf (fp, "}");
}
#endif

static int cur_el;
static void print_array_help (FILE *fp, Object dims, Object *els, int escaped);

static void
print_array (FILE *fp, Object array, int escaped)
{
  Object dims, *els;

  dims = ARRDIMS (array);
  els = ARRELS (array);

  cur_el = 0;
  fprintf (fp, "#%da", list_length (dims));
  print_array_help (fp, dims, els, escaped);
}

static void
print_array_help (FILE *fp, Object dims, Object *els, int escaped)
{
  int dim_val, i;

  fprintf (fp, "(");
  dim_val = INTVAL (CAR (dims));
  if (NULLP (CDR (dims)))
    {
      for ( i=0 ; i < dim_val ; ++i )
	{
	  print_object (fp, els[cur_el++], escaped);
	  if (i < (dim_val - 1))
	    {
	      fprintf (fp, " ");
	    }
	}
    }
  else
    {
      for ( i=0 ; i < dim_val ; ++i )
	{
	  print_array_help (fp, CDR (dims), els, escaped);
	}
    }
  fprintf (fp, ")");
}



#if 0
static void 
print_array (FILE *fp, Object array, int escaped)
{
  Object dims;
  unsigned int dim_val, offset, i;
  int rank;

  dims = ARRDIMS (array);
  rank = list_length (dims);
  fprintf (fp, "#%da", rank);
  offset = 0;
  while (! NULLP (dims))
    {
      fprintf (fp, "(");
      if (NULLP (CDR (dims)))
	{
	  dim_val = INTVAL (CAR (dims));
	  for ( i=0 ; i < dim_val ; ++i )
	    {
	      print_object (fp, ARRELS(array)[offset], escaped);
	      offset++;
	    }
	}
     dims = CDR (dims);
    }

  while (! NULLP (dims))
    {
      fprintf (fp, "(");
      if (NULLP (CDR (dims)))
	{
	  dim_val = INTVAL (CAR (dims));
	  for ( i=0 ; i < dim_val ; ++i )
	    {
	      print_object (fp, ARRELS(array)[offset], escaped);
	      offset++;
	    }
	}
     dims = CDR (dims);
    }
}
#endif

static void 
print_string (FILE *fp, Object str, int escaped)
{
  if ( escaped )
    {
      fprintf (fp, "\"%s\"", BYTESTRVAL(str));
    }
  else
    {
      fprintf (fp, "%s", BYTESTRVAL(str));
    }
}

static Object
format (Object stream, Object str, Object rest)
{
  Object obj;
  FILE *fp;
  char *cstr;
  int i;

  if (stream == true_object)
    {
      fp = stdout;
    }
  else if (OUTPUTSTREAMP (stream))
    {
      fp = STREAMFP (stream);
    }
  else
    {
      error ("format: cannot send output to non-stream", stream, NULL);
    }
  cstr = BYTESTRVAL (str);

  i = 0;
  while ( cstr[i] )
    {
      if ( cstr[i] == '~' )
	{
	  i++;
	  switch ( cstr[i] )
	    {
	    case 'a':
	    case 'A':
	      if (NULLP (rest))
		{
		  error ("format: not enough args for format string", str, NULL);
		}
	      obj = CAR (rest);
	      rest = CDR (rest);
	      print_object (fp, obj, 0);
	      break;
	    case 'd':
	    case 'D':
	      if (NULLP (rest))
		{
		  error ("format: not enough args for format string", str, NULL);
		}
	      obj = CAR (rest);
	      if (! INTEGERP (obj))
		{
		  error ("format: argument to ~d must be an integer", obj, NULL); 
		}
	      rest = CDR (rest);
#if 0
	      if (isdigit (cstr[i-1]))
		{
		  j = i - 1;
		  while (isdigit(cstr[j]))
		    {
		      j--;
		    }
		  j++;
		  sscanf (cstr[j], "%d", &arg);
		  fprintf (fp, "%");
		}
	      else
#endif
		{
		  fprintf (fp, "%d", INTVAL(obj));
		}
	      break;
	    case 's':
	    case 'S':
	      if (NULLP (rest))
		{
		  error ("format: not enough args for format string", str, NULL);
		}
	      obj = CAR (rest);
	      rest = CDR (rest);
	      print_object (fp, obj, 1);
	      break;
	    case '%':
	      fprintf (fp, "\n");
	      break;
	    case '~':
	      fprintf (fp, "~");
	      break;
	    default:
	      /* skip over digits.  individuals branches
		 handle there own arguments. */
	      if (isdigit (cstr[i]))
		{
		  while (isdigit(cstr[i]))
		    {
		      i++;
		    }
		  break;
		}
	      error ("format: bad escape character", make_character (cstr[i]), NULL);
	    }
	}
      else
	{
	  fprintf (fp, "%c", cstr[i]);
	}
      i++;
    }
  if (! NULLP (rest))
    {
      error ("format: too many arguments for format string", CAR (rest), NULL);
    }
  return (unspecified_object);
}

static void 
print_stream (FILE *fp, Object stream)
{
  switch (STREAMSTYPE (stream))
    {
    case Input:
      fprintf (fp, "{input stream}");
      break;
    case Output:
      fprintf (fp, "{output stream}");
      break;
    default:
      error ("trying to print stream of unknown type", NULL);
    }
}

static Object
write_char (Object ch, Object stream_list)
{
  char the_char;
  FILE *fp;

  if (NULLP (stream_list))
    {
      fp = stdout;
    }
  else
    {
      fp = STREAMFP (CAR (stream_list));
    }
  the_char = CHARVAL (ch);
  fwrite (&the_char, 1, sizeof (char), fp);
  return (unspecified_object);
}
