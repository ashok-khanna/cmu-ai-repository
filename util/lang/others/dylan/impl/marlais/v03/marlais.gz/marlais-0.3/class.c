/*

   class.c

   Copyright, 1993, Brent Benson.  All Rights Reserved.

   Permission to use, copy, and modify this software and its
   documentation is hereby granted only under the following terms and
   conditions.  Both the above copyright notice and this permission
   notice must appear in all copies of the software, derivative works
   or modified version, and both notices must appear in supporting
   documentation.  Users of this software agree to the terms and
   conditions set forth in this notice and agree to inform the author,
   Brent Benson, of any noteworthy uses of this software.

*/

#include <string.h>
#include "class.h"
#include "list.h"
#include "keyword.h"
#include "slot.h"
#include "apply.h"
#include "symbol.h"
#include "function.h"
#include "eval.h"
#include "vector.h"
#include "string.h"
#include "boolean.h"
#include "table.h"
#include "deque.h"
#include "array.h"
#include "env.h"
#include "error.h"

/* primitives */

static struct primitive class_prims[] =
{
  {"make", prim_1_rest, make},
  {"%instance?", prim_2, instance_p},
  {"subclass?", prim_2, subclass_p},
  {"object-class", prim_1, objectclass},
  {"singleton", prim_1, singleton},
};

/* local function prototypes */

static void make_getters_setters (Object class);
static Object make_getter_method (Object slot, Object getter_name, Object class);
static Object make_setter_method (Object slot, Object setter_name, Object class);

/* function definitions */

void
init_class_prims (void)
{
  int num;

  num = sizeof (class_prims) / sizeof (struct primitive);
  init_prims (num, class_prims);
}

void
init_class_hierarchy (void)
{
  object_class = make_class ("<object>", empty_list, NULL);
  boolean_class = make_class ("<boolean>", object_class, NULL);
  number_class = make_class ("<number>", object_class, NULL);
  real_class = make_class ("<real>", number_class, NULL);
  integer_class = make_class ("<integer>", real_class, NULL);
  ratio_class = make_class ("<ratio>", real_class, NULL);
  single_float_class = make_class ("<single-float>", real_class, NULL);
  double_float_class = make_class ("<double-float>", real_class, NULL);
  collection_class = make_class ("<collection>", object_class, NULL);
  explicit_key_collection_class = make_class ("<explicit-key-collection>", collection_class, NULL);
  mutable_collection_class = make_class ("<mutable-collection>", collection_class, NULL);
  sequence_class = make_class ("<sequence>", collection_class, NULL);
  mutable_explicit_key_collection_class = make_class ("<mutable-explicit-key-collection>",
						      listem (explicit_key_collection_class,
							      mutable_collection_class,
							      NULL),
						      NULL);
  mutable_sequence_class = make_class ("<mutable-sequence>", 
				       listem (mutable_collection_class, sequence_class, NULL),
				       NULL);
  table_class = make_class ("<table>", mutable_explicit_key_collection_class, NULL);
  deque_class = make_class ("<deque>", mutable_sequence_class, NULL);
  array_class = make_class ("<array>", mutable_explicit_key_collection_class, NULL);
  list_class = make_class ("<list>", mutable_sequence_class, NULL);
  empty_list_class = make_class ("<empty-list>", list_class, NULL);
  pair_class = make_class ("<pair>", list_class, NULL);
  string_class = make_class ("<string>", mutable_sequence_class, NULL);
  byte_string_class = make_class ("<byte-string>", string_class, NULL);
  vector_class = make_class ("<vector>", mutable_sequence_class, NULL);
  simple_object_vector_class = make_class ("<simple-object-vector>", vector_class, NULL);
  condition_class = make_class ("<condition>", object_class, NULL);
  symbol_class = make_class ("<symbol>", object_class, NULL);
  keyword_class = make_class ("<keyword>", object_class, NULL);
  character_class = make_class ("<character>", object_class, NULL);
  function_class = make_class ("<function>", object_class, NULL);
  primitive_class = make_class ("<primitive>", function_class, NULL);
  generic_function_class = make_class ("<generic-function>", function_class, NULL);
  method_class = make_class ("<method>", function_class, NULL);
  class_class = make_class ("<class>", object_class, NULL);
  stream_class = make_class ("<stream>", object_class, NULL);
  table_entry_class = make_class ("<table-entry>", object_class, NULL);
  deque_entry_class = make_class ("<deque-entry>", object_class, NULL);

  add_top_level_binding (make_symbol ("<object>"), object_class);
  add_top_level_binding (make_symbol ("<boolean>"), boolean_class);
  add_top_level_binding (make_symbol ("<number>"), number_class);
  add_top_level_binding (make_symbol ("<real>"), real_class);
  add_top_level_binding (make_symbol ("<integer>"), integer_class);
  add_top_level_binding (make_symbol ("<ratio>"), ratio_class);
  add_top_level_binding (make_symbol ("<single-float>"), single_float_class);
  add_top_level_binding (make_symbol ("<double-float>"), double_float_class);
  add_top_level_binding (make_symbol ("<collection>"), collection_class);
  add_top_level_binding (make_symbol ("<explicit-key-collection>"), explicit_key_collection_class);
  add_top_level_binding (make_symbol ("<mutable-collection>"), mutable_collection_class);
  add_top_level_binding (make_symbol ("<sequence>"), sequence_class);
  add_top_level_binding (make_symbol ("<mutable-explicit-key-collection>"), mutable_explicit_key_collection_class);
  add_top_level_binding (make_symbol ("<mutable-sequence>"), mutable_sequence_class);
  add_top_level_binding (make_symbol ("<table>"), table_class);
  add_top_level_binding (make_symbol ("<deque>"), deque_class);
  add_top_level_binding (make_symbol ("<array>"), array_class);
  add_top_level_binding (make_symbol ("<list>"), list_class);
  add_top_level_binding (make_symbol ("<empty-list>"), empty_list_class);
  add_top_level_binding (make_symbol ("<pair>"), pair_class);
  add_top_level_binding (make_symbol ("<string>"), string_class);
  add_top_level_binding (make_symbol ("<byte-string>"), byte_string_class);
  add_top_level_binding (make_symbol ("<vector>"), vector_class);
  add_top_level_binding (make_symbol ("<simple-object-vector>"), simple_object_vector_class);
  add_top_level_binding (make_symbol ("<condition>"), condition_class);
  add_top_level_binding (make_symbol ("<symbol>"), symbol_class);
  add_top_level_binding (make_symbol ("<keyword>"), keyword_class);
  add_top_level_binding (make_symbol ("<character>"), character_class);
  add_top_level_binding (make_symbol ("<function>"), function_class);
  add_top_level_binding (make_symbol ("<primitive>"), primitive_class);
  add_top_level_binding (make_symbol ("<generic-function>"), generic_function_class);
  add_top_level_binding (make_symbol ("<method>"), method_class);
  add_top_level_binding (make_symbol ("<class>"), class_class);
  add_top_level_binding (make_symbol ("<stream>"), stream_class);
  add_top_level_binding (make_symbol ("<table-entry>"), table_entry_class);
  add_top_level_binding (make_symbol ("<deque-entry>"), deque_entry_class);
}

Object 
make_class (char *name, Object supers, Object slots)
{
  Object obj, super_slots;

  obj = allocate_object (sizeof (struct class));
  CLASSTYPE (obj) = Class;
  CLASSNAME (obj) = make_symbol (name);

  /* allow a single value for supers, make it into a list 
   */
  if (!LISTP(supers))
    {
      CLASSSUPERS (obj) = cons (supers, empty_list);
    }
  else
    {
      CLASSSUPERS (obj) = supers;
    }
  
  /* add the slots of the superclasses 
   */
  supers = CLASSSUPERS (obj);
  while (! NULLP (supers))
    {
      super_slots = CLASSSLOTS (CAR (supers));
      if ( super_slots )
	{
	  if ( slots )
	    {
	      slots = append (slots, super_slots);
	    }
	  else
	    {
	      slots = super_slots;
	    }
	}
      supers = CDR (supers);
    }
  CLASSSLOTS (obj) = slots;

  /* kludge alert:  We eventually call method_specializers in
     add_method while making getters and setters which needs
     to evaluate the class name to obtain the class value.  Therefore, 
     we need to establish the binding here, rather than in the function
     that is getting called. */
  add_top_level_binding (CLASSNAME (obj), obj);

  if ( slots )
    {
      make_getters_setters (obj);
    }
  return (obj);
}

Object
make_instance (Object class, Object slots)
{
  Object obj;

  obj = allocate_object (sizeof (struct instance));
  INSTTYPE (obj) = Instance;
  INSTCLASS (obj) = class;
  INSTSLOTS (obj) = slots;
  return (obj);
}

Object
make_singleton (Object val)
{
  Object obj;

  obj = allocate_object (sizeof (struct singleton));
  SINGLETYPE (obj) = Singleton;
  SINGLEVAL (obj) = val;
  return (obj);
}

Object 
make (Object class, Object rest)
{
  Object slot, slots, type, init_key, val;
  Object init_fun, name, values, ret, initialize_fun;

  /* special case the builtin classes */
  if ((class == pair_class) || (class == list_class))
    {
      ret = make_list_driver (rest);
    }
  else if ((class == vector_class) || (class == simple_object_vector_class))
    {
      ret = make_vector_driver (rest);
    }
  else if ((class == string_class) || (class == byte_string_class))
    {
      ret = make_string_driver (rest);
    }
  else if (class == generic_function_class)
    {
      ret = make_generic_function_driver (rest);
    }
  else if (class == table_class)
    {
      ret = make_table_driver (rest);
    }
  else if (class == deque_class)
    {
      ret = make_deque_driver (rest);
    }
  else if (class == array_class)
    {
      ret = make_array_driver (rest);
    }  
  else
    {
      values = empty_list;
      slots = CLASSSLOTS (class);
      while (! NULLP (slots))
	{
	  slot = CAR (slots);
	  name = slot_name (slot);
	  type = slot_type (slot);
	  if ( ! type )
	    {
	      type = object_class;
	    }
	  else
	    {
	      type = eval (type);
	    }
	  init_key = slot_init_keyword (slot);
	  if (init_key && (val = find_keyword_val (init_key, rest)))
	    {
	      if (instance_p (val, type) == false_object)
		{
		  error ("make: object is not of required type", val, type, NULL);
		}
	      values = cons (cons (name, val), values);
	      slots = CDR (slots);
	      continue;
	    }
	  val = slot_init_value (slot);
	  if ( val )
	    {
	      values = cons (cons (name, val), values);
	      slots = CDR (slots);
	      continue;
	    }
	  init_fun = slot_init_function (slot);
	  if ( init_fun )
	    {
	      val = apply (init_fun, empty_list);
	      values = cons (cons (name, val), values);
	      slots = CDR (slots);
	      continue;
	    }
	  val = uninit_slot_object;
	  values = cons (cons (name, val), values);
	  slots = CDR (slots);
	}
      ret = make_instance (class, values);
    }
  initialize_fun = symbol_value (initialize_symbol);
  if ( initialize_fun )
    {
      apply (initialize_fun, cons (ret, empty_list));
    }
  else
    {
      warning ("make: no `initialize' generic function", class, NULL);
    }
  return (ret);
}

Object 
instance_p (Object obj, Object class)
{
  Object objclass, supers;

  if (SINGLETONP (class))
    {
      if (id_p (obj, SINGLEVAL (class), empty_list) != false_object)
	{
	  return (true_object);
	}
      else
	{
	  return (false_object);
	}
    }

  objclass = objectclass (obj);
  if (objclass == class)
    {
      return (true_object);
    }
  else
    {
      return (subclass_p (objclass, class));
    }
}

Object 
subclass_p (Object class1, Object class2)
{
  Object supers;

  if (class1 == class2)
    {
      return (true_object);
    }
  else if (SINGLETONP (class1))
    {
      if (instance_p (SINGLEVAL (class1), class2) == false_object)
	{
	  return (false_object);
	}
      else
	{
	  return (true_object);
	}
    }
  else
    {
      supers = CLASSSUPERS (class1);
      if ( ! supers )
	{
	  return (false_object);
	}
      while (! NULLP (supers))
	{
	  if (subclass_p (CAR(supers), class2) != false_object)
	    {
	      return (true_object);
	    }
	  supers = CDR (supers);
	}
      return (false_object);
    }
}

Object 
objectclass (Object obj)
{
  switch (TYPE (obj))
    {
    case Integer: 
      return (integer_class);
      break;
    case True:
    case False:
      return (boolean_class);
      break;
    case Ratio: return (ratio_class);
    case SingleFloat: return (single_float_class);
    case DoubleFloat: return (double_float_class);
    case EmptyList: return (empty_list_class);
    case Pair: return (pair_class);
    case ByteString: return (byte_string_class);
    case SimpleObjectVector: return (simple_object_vector_class);
    case Table: return (table_class);
    case Deque: return (deque_class);
    case Array: return (array_class);
    case Condition: return (condition_class);
    case Symbol: return (symbol_class);
    case Keyword: return (keyword_class);
    case Character: return (character_class);
    case Class: return (class_class);
    case Instance:
      return (INSTCLASS (obj));
    case Primitive: return (primitive_class);
    case GenericFunction: return (generic_function_class);
    case Method: return (method_class);
    case EndOfFile: return (object_class);
    case Stream: return (stream_class);
    case TableEntry: return (table_entry_class);
    case DequeEntry: return (deque_entry_class);
    case Singleton:
    default:
      error ("object-class: don't know class of object", obj, NULL);
    }
}

Object 
singleton (Object val)
{
  return (make_singleton (val));
}

Object 
same_class_p (Object class1, Object class2)
{
  if (class1 == class2)
    {
      return (true_object);
    }
  else if ((POINTERTYPE (class1) == Singleton) &&
	   (POINTERTYPE (class2) == Singleton))
    {
      if (id_p (SINGLEVAL (class1), SINGLEVAL (class2), empty_list) == false_object)
	{
	  return (false_object);
	}
      else
	{
	  return (true_object);
	}
    }
  else
    {
      return (false_object);
    }
}

/* local functions */

static void
make_getters_setters (Object class)
{
  Object slots, slot, getter, setter;
  Object getter_name, setter_name;
  Object sname;

  slots = CLASSSLOTS (class);
  while (!NULLP(slots))
    {
      slot = CAR (slots);
      sname = slot_name (slot);
      getter_name = find_keyword_val (getter_keyword, slot);
      if ( ! getter_name )
	{
	  getter_name = sname;
	}
      add_top_level_binding (getter_name, make_getter_method (sname, getter_name, class));

      setter_name = find_keyword_val (setter_keyword, slot);
      if ( ! setter_name )
	{
	  setter_name = make_setter_symbol (sname);
	}
      add_top_level_binding (setter_name, make_setter_method (sname, setter_name, class));

      slots = CDR (slots);
    }
}

/*

   params = ((obj <class>))
   body = (slot-value obj 'slot)

*/
static Object
make_getter_method (Object slot, Object getter_name, Object class)
{
  Object params, body, obj_sym, slot_val_sym;

  obj_sym = make_symbol ("obj");
  slot_val_sym = make_symbol ("slot-value");

  params = listem (listem (obj_sym, CLASSNAME (class), NULL),
		   NULL);
  body = listem (listem (slot_val_sym, 
			 obj_sym, 
			 listem (quote_symbol, slot, NULL), 
			 NULL), 
		 NULL);
  return (make_method (getter_name, params, body, the_env, 1));
}

/*

   params = ((obj <class>) val)
   body = (set-slot-value! obj 'slot val)

*/
static Object
make_setter_method (Object slot, Object setter_name, Object class)
{
  Object params, body, obj_sym, set_sym, val_sym;

  obj_sym = make_symbol ("obj");
  set_sym = make_symbol ("set-slot-value!");
  val_sym = make_symbol ("val");

  params = listem (listem (obj_sym, CLASSNAME (class), NULL),
		   val_sym, NULL);
  body = listem (listem (set_sym, 
			 obj_sym, 
			 listem (quote_symbol, slot, NULL), 
			 val_sym, 
			 NULL), 
		 NULL);
  return (make_method (setter_name, params, body, the_env, 1));
}

