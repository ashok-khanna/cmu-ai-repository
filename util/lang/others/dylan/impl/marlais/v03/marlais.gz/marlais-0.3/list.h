/*

   list.h

   Copyright, 1993, Brent Benson.  All Rights Reserved.

   Permission to use, copy, and modify this software and its
   documentation is hereby granted only under the following terms and
   conditions.  Both the above copyright notice and this permission
   notice must appear in all copies of the software, derivative works
   or modified version, and both notices must appear in supporting
   documentation.  Users of this software agree to the terms and
   conditions set forth in this notice and agree to inform the author,
   Brent Benson, of any noteworthy uses of this software.

*/

#ifndef LIST_H
#define LIST_H

#include <stdarg.h>
#include "object.h"

void init_list_prims (void);
Object make_empty_list (void);
Object make_list_driver (Object args);
Object cons (Object car, Object cdr);
Object car (Object lst);
Object cdr (Object lst);
Object second (Object lst);
Object third (Object lst);
Object map (Object (*fun)(Object), Object lst);
Object map2 (Object (*fun)(Object, Object), Object l1, Object l2);
Object list_map1 (Object fun, Object lst);
Object list_map2 (Object fun, Object l1, Object l2);
Object append (Object l1, Object l2);
Object member_p (Object obj, Object lst, Object test);
Object listem (Object car, ...);
Object list_reduce (Object fun, Object init, Object lst);
Object list_reduce1 (Object fun, Object lst);
int list_length (Object lst);
int list_equal (Object l1, Object l2);

#endif
