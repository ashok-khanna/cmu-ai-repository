/*

   error.h

   Copyright, 1993, Brent Benson.  All Rights Reserved.
   0.4 Revisions Copyright 1994, Joseph N. Wilson.  All Rights Reserved.
   
   Permission to use, copy, and modify this software and its
   documentation is hereby granted only under the following terms and
   conditions.  Both the above copyright notice and this permission
   notice must appear in all copies of the software, derivative works
   or modified version, and both notices must appear in supporting
   documentation.  Users of this software agree to the terms and
   conditions set forth in this notice.

*/

#ifndef ERROR_H
#define ERROR_H

#include <stdarg.h>
#include "object.h"

void init_error_prims (void);
void fatal (char *msg);
void error (char *msg, ...);
void warning (char *msg, ...);

#endif
