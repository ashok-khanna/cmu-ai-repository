/*
   
   symbol.h

   Copyright, 1993, Brent Benson.  All Rights Reserved.
   0.4 Revisions Copyright 1994, Joseph N. Wilson.  All Rights Reserved.
   
   Permission to use, copy, and modify this software and its
   documentation is hereby granted only under the following terms and
   conditions.  Both the above copyright notice and this permission
   notice must appear in all copies of the software, derivative works
   or modified version, and both notices must appear in supporting
   documentation.  Users of this software agree to the terms and
   conditions set forth in this notice.

*/

#ifndef SYMBOL_H
#define SYMBOL_H

#include "object.h"

struct symtab
{
  Object sym;
  struct symtab *next;
};

Object make_symbol (char *name);
Object make_keyword (char *name);
Object make_setter_symbol (Object sym);
void init_symbol_prims (void);
#endif
