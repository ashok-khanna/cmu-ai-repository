/*

   table.h

   Copyright, 1993, Brent Benson.  All Rights Reserved.
   0.4 Revisions Copyright 1994, Joseph N. Wilson.  All Rights Reserved.
   
   Permission to use, copy, and modify this software and its
   documentation is hereby granted only under the following terms and
   conditions.  Both the above copyright notice and this permission
   notice must appear in all copies of the software, derivative works
   or modified version, and both notices must appear in supporting
   documentation.  Users of this software agree to the terms and
   conditions set forth in this notice.

*/

#ifndef TABLE_H
#define TABLE_H

#include "object.h"

#define DEFAULT_TABLE_SIZE 101

void init_table_prims (void);
Object make_table (int size);
Object make_table_entry (int row, Object key, Object value, Object next);
Object make_table_driver (Object rest);

#endif
