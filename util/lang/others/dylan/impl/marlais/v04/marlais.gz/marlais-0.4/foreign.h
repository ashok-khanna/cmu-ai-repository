/*
   
   foreign.h - foreign function interface

   Copyright, 1993, Brent Benson.  All Rights Reserved.
   
   Permission to use, copy, and modify this software and its
   documentation is hereby granted only under the following terms and
   conditions.  Both the above copyright notice and this permission
   notice must appear in all copies of the software, derivative works
   or modified version, and both notices must appear in supporting
   documentation.  Users of this software agree to the terms and
   conditions set forth in this notice.

*/

#ifndef FOREIGN_H
#define FOREIGN_H

#include "object.h"

void init_foreign_prims (void); 

#endif
