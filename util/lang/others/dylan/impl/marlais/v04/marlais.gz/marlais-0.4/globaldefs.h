/*

   globaldefs.h

   Copyright, 1993, Brent Benson.  All Rights Reserved.
   0.4 Revisions Copyright 1994, Joseph N. Wilson.  All Rights Reserved.
   
   Permission to use, copy, and modify this software and its
   documentation is hereby granted only under the following terms and
   conditions.  Both the above copyright notice and this permission
   notice must appear in all copies of the software, derivative works
   or modified version, and both notices must appear in supporting
   documentation.  Users of this software agree to the terms and
   conditions set forth in this notice.

*/

/* This file should only be included once in main.c.
*/

/* globals */
extern jmp_buf error_return;
extern int definition_level;

/* important objects */
extern Object true_object, false_object;
extern Object eof_object, unspecified_object, uninit_slot_object;
extern Object key_symbol, allkeys_symbol, rest_symbol, next_symbol;
extern Object all_symbol;
extern Object values_symbol;
extern Object quote_symbol;
extern Object getter_keyword, setter_keyword, else_keyword;
extern Object type_keyword, init_value_keyword, init_function_keyword;
extern Object init_keyword_keyword, required_init_keyword_keyword, allocation_keyword;
extern Object unwind_symbol, next_method_symbol, initialize_symbol;
extern Object equal_hash_symbol, object_class_symbol;
extern Object quasiquote_symbol, unquote_symbol, unquote_splicing_symbol;
extern Object super_classes_keyword, slots_keyword, debug_name_keyword;
extern Object size_keyword, fill_keyword, dim_keyword, fill_keyword;
extern Object min_keyword, max_keyword;
extern Object default_object;

extern Object  instance_symbol, class_symbol, each_subclass_symbol;
extern Object  constant_symbol, virtual_symbol, obj_sym, slot_val_sym;
extern Object  set_slot_value_sym, val_sym;
extern Object  initial_state_sym, next_state_sym, current_element_sym;
extern Object  element_symbol, element_setter_symbol;
extern Object  signal_symbol;

/* builtin classes */
extern Object object_class; 
extern Object boolean_class;
extern Object number_class, complex_class, real_class, rational_class;
extern Object integer_class, ratio_class;
extern Object float_class, single_float_class, double_float_class;
extern Object collection_class, mutable_sequence_class;
extern Object list_class, empty_list_class, pair_class, string_class;
extern Object byte_string_class, unicode_string_class;
extern Object vector_class, simple_object_vector_class;
extern Object explicit_key_collection_class;
extern Object mutable_explicit_key_collection_class;
extern Object stretchy_collection_class;
extern Object mutable_collection_class;
extern Object sequence_class;
extern Object table_class, deque_class, array_class;
extern Object condition_class;
extern Object serious_condition_class, error_class, simple_error_class;
extern Object type_error_class, sealed_object_error_class;
extern Object warning_class, simple_warning_class;
extern Object restart_class, simple_restart_class, abort_class;
extern Object symbol_class, keyword_class;
extern Object character_class;
extern Object function_class, primitive_class, generic_function_class;
extern Object method_class, exit_function_class;
extern Object class_class, stream_class, table_entry_class, deque_entry_class;
extern Object limited_int_class;
extern Object singleton_class, type_class;
extern Object instance_slots_symbol, class_slots_symbol;
extern Object each_subclass_slots_symbol;
