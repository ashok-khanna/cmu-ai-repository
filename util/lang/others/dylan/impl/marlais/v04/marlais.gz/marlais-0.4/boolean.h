/*

   boolean.h

   Copyright, 1993, Brent Benson.  All Rights Reserved.
   0.4 Revisions Copyright 1994, Joseph N. Wilson.  All Rights Reserved.
   
   Permission to use, copy, and modify this software and its
   documentation is hereby granted only under the following terms and
   conditions.  Both the above copyright notice and this permission
   notice must appear in all copies of the software, derivative works
   or modified version, and both notices must appear in supporting
   documentation.  Users of this software agree to the terms and
   conditions set forth in this notice.

*/

#ifndef BOOLEAN_H
#define BOOLEAN_H

#include "object.h"

void init_boolean_prims (void);
Object make_true (void);
Object make_false (void);
Object id_p (Object obj1, Object obj2, Object rest);
int id (Object obj1, Object obj2);

#endif
