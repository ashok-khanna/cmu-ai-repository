/*
  macintosh.h

  Dylan primitives for Macintosh
  
  Copyright, 1994, Patrick C. Beard.  All Rights Reserved.
  

  Permission to use, copy, and modify this software and its
  documentation is hereby granted only under the following terms and
  conditions.  Both the above copyright notice and this permission
  notice must appear in all copies of the software, derivative works
  or modified version, and both notices must appear in supporting
  documentation.  Users of this software agree to the terms and
  conditions set forth in this notice.
  
 */

#pragma once

#include "object.h"

void init_mac_prims(void);
Object get_file(void);
Object put_file(Object defaultNameObj, Object promptObj);
