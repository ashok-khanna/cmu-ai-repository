/*

   prim.c

   Copyright, 1993, Brent Benson.  All Rights Reserved.

   Permission to use, copy, and modify this software and its
   documentation is hereby granted only under the following terms and
   conditions.  Both the above copyright notice and this permission
   notice must appear in all copies of the software, derivative works
   or modified version, and both notices must appear in supporting
   documentation.  Users of this software agree to the terms and
   conditions set forth in this notice and agree to inform the author,
   Brent Benson, of any noteworthy uses of this software.

*/

#include <string.h>
#include "prim.h"
#include "symbol.h"
#include "string.h"
#include "alloc.h"

void 
init_prims (int num, struct primitive prims[])
{
  int i;
  Object sym, prim;

  for ( i=0 ; i < num ; ++i )
    {
      sym = make_symbol (prims[i].name);
      prim = make_primitive (prims[i].name, prims[i].prim_type, prims[i].fun);
      add_top_level_binding (sym, prim);
    }
}

Object 
make_primitive (char *name, enum primtype type, Object(*fun)())
{
  Object obj;

#ifndef SMALL_OBJECTS
  obj = allocate_object (sizeof (struct primitive));
#else
  obj = allocate_object (sizeof (struct prim));
#endif
  PRIMTYPE (obj) = Primitive;
  PRIMNAME (obj) = checking_strdup (name);
  PRIMPTYPE (obj) = type;
  PRIMFUN (obj) = fun;
  return (obj);
}

Object 
apply_prim (Object prim, Object args)
{
  Object (*fun)();

  fun = PRIMFUN (prim);
  switch (PRIMPTYPE (prim))
    {
    case prim_0:
      return (*fun)();
    case prim_1:
      return (*fun)(FIRST(args));
    case prim_2:
      return (*fun)(FIRST(args), SECOND(args));
    case prim_3:
      return (*fun)(FIRST(args), SECOND(args), THIRD(args));
    case prim_0_1:
      switch (list_length (args))
	{
	case 0:
	  return (*fun)(NULL);
	case 1:
	  return (*fun)(FIRST(args));
	default:
	  error ("incorrect number of args to primitive", prim, NULL);
	}
    case prim_0_3:
      switch (list_length (args))
	{
	case 0:
	  return (*fun)(NULL, NULL, NULL);
	case 1:
	  return (*fun)(FIRST(args), NULL, NULL);
	case 2:
	  return (*fun)(FIRST(args), SECOND(args), NULL);
	case 3:
	  return (*fun)(FIRST(args), SECOND(args), THIRD(args));
	default:
	  error ("incorrect number of args to primitive", prim, NULL);
	}
    case prim_1_1:
      switch (list_length (args))
	{
	case 1:
	  return (*fun)(FIRST(args), NULL);
	case 2:
	  return (*fun)(FIRST(args), SECOND(args));
	default:
	  error ("incorrect number of args to primitive", prim, NULL);
	}
    case prim_2_1:
      switch (list_length (args))
	{
	case 2:
	  return (*fun)(FIRST(args), SECOND(args), NULL);
	case 3:
	  return (*fun)(FIRST(args), SECOND(args), THIRD(args));
	default:
	  error ("incorrect number of args to primitive", prim, NULL);
	}
    case prim_0_rest:
      return (*fun)(args);
    case prim_1_rest:
      return (*fun)(CAR(args), CDR(args));
    case prim_2_rest:
      return (*fun)(FIRST(args), SECOND(args), CDR (CDR (args)));
    default:
      error ("cannot handle primitive type", prim, NULL);
    } 
}
