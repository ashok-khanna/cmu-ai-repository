/*

   alloc.h

   Copyright, 1993, Brent Benson.  All Rights Reserved.

   Permission to use, copy, and modify this software and its
   documentation is hereby granted only under the following terms and
   conditions.  Both the above copyright notice and this permission
   notice must appear in all copies of the software, derivative works
   or modified version, and both notices must appear in supporting
   documentation.  Users of this software agree to the terms and
   conditions set forth in this notice and agree to inform the author,
   Brent Benson, of any noteworthy uses of this software.

*/

#ifndef ALLOC_H
#define ALLOC_H

#include "object.h"
#include "env.h"

void initialize_gc (void);
Object allocate_object (size_t size); 
struct frame *allocate_frame (void);
struct binding *allocate_binding (void);
struct symtab *allocate_symtab (void);
void *checking_malloc (size_t size);
void *checking_realloc (void *ptr, size_t size);
char *checking_strdup (char *str);

#endif
