/*

   function.c

   Copyright, 1993, Brent Benson.  All Rights Reserved.

   Permission to use, copy, and modify this software and its
   documentation is hereby granted only under the following terms and
   conditions.  Both the above copyright notice and this permission
   notice must appear in all copies of the software, derivative works
   or modified version, and both notices must appear in supporting
   documentation.  Users of this software agree to the terms and
   conditions set forth in this notice and agree to inform the author,
   Brent Benson, of any noteworthy uses of this software.

*/

#include <string.h>
#include "function.h"
#include "symbol.h"
#include "env.h"
#include "list.h"
#include "number.h"
#include "values.h"
#include "keyword.h"
#include "class.h"
#include "eval.h"
#include "vector.h"

/* local function prototypes */

static Object add_method (Object method, Object generic);
static Object generic_function_methods (Object gen);
static Object method_specializers (Object meth);
static Object method_specializers_help (Object params);
static Object function_arguments (Object fun);
static Object applicable_method_p (Object fun, Object sample_args);
static Object sort_methods (Object methods);
static int sort_driver (Object *pmeth1, Object *pmeth2);
static int same_specializers (Object s1, Object s2);
static int specializer_less_than (Object spec1, Object spec2);
static Object find_method (Object generic, Object spec_list);
static Object remove_method (Object generic, Object method);
static Object debug_name_setter (Object method, Object name);

/* primitives */

static struct primitive function_prims[]=
{
  {"%generic-function-methods", prim_1, generic_function_methods},
  {"%method-specializers", prim_1, method_specializers},
  {"%function-arguments", prim_1, function_arguments},
  {"%applicable-method?", prim_1_rest, applicable_method_p},
  {"%sorted-applicable-methods", prim_1_rest, sorted_applicable_methods},
  {"%find-method", prim_2, find_method},
  {"%remove-method", prim_2, remove_method},
  {"%debug-name-setter", prim_2, debug_name_setter},
};

/* function definitions */

void
init_function_prims (void)
{
  int num;

  num = sizeof (function_prims) / sizeof (struct primitive);
  init_prims (num, function_prims);
}

Object 
make_generic_function (Object name, Object params, Object methods)
{
  Object obj;

  obj = allocate_object (sizeof (struct generic_function));
  GFTYPE (obj) = GenericFunction;
  GFNAME (obj) = name;
  GFPARAMS (obj) = params;
  GFMETHODS (obj) = methods;
  return (obj);
}

Object 
make_method (Object name, Object params, Object body, struct frame *env, int do_generic)
{
  Object obj, gf;

  obj = allocate_object (sizeof (struct method));
  METHTYPE (obj) = Method;
  if ( name )
    {
      METHNAME (obj) = name;
    }
  else
    {
      METHNAME (obj) = NULL;
    }
  METHPARAMS (obj) = params;
  METHBODY (obj) = body;
  METHENV (obj) = env;
  if ( do_generic && name )
    {
      gf = symbol_value (name);
      if ( ! gf )
	{
	  gf = make_generic_function (name, params, empty_list);
	  add_top_level_binding (name, gf);
	}
      add_method (obj, gf);
      return (gf);
    }
  else
    {
      return (obj);
    }
}

Object
make_next_method (Object rest_methods, Object args)
{
  Object obj;

  obj = allocate_object (sizeof (struct next_method));
  NMTYPE (obj) = NextMethod;
  NMREST (obj) = rest_methods;
  NMARGS (obj) = args;
  return (obj);
}

Object 
make_generic_function_driver (Object args)
{
  error ("make: not implemented for generic functions", NULL);
}

/* local functions */

/* add a method, replacing one with matching parameters
   if it's already there */
static Object
add_method (Object method, Object generic)
{
  Object new_specs, old_specs, methods, last;

  new_specs = method_specializers (method);
  methods = GFMETHODS (generic);
  last = NULL;
  while (! NULLP (methods))
    {
      old_specs = method_specializers (CAR (methods));
      if (same_specializers (new_specs, old_specs))
	{
	  if (! last)
	    {
	      GFMETHODS (generic) = cons (method, CDR (methods));
	      return (generic);
	    }
	  else
	    {
	      CDR (last) = cons (method, CDR (methods));
	      return (generic);
	    }
	}
      last = methods;
      methods = CDR (methods);
    }
  GFMETHODS (generic) = cons (method, GFMETHODS (generic));
  return (generic);
}

static Object 
generic_function_methods (Object gen)
{
  if (! GFUNP (gen))
    {
      error ("generic-function-methods: argument must be a generic function", gen, NULL);
    }
  return (GFMETHODS (gen));
}

static Object 
method_specializers (Object meth)
{
  Object params, specs;

  if (! METHODP (meth))
    {
      error ("method-specializers: argument must be a method", meth, NULL);
    }
  specs = method_specializers_help (METHPARAMS (meth));
  return (specs);
}

static Object
method_specializers_help (Object params)
{
  Object param;

  if (NULLP (params) ||
      (CAR(params) == rest_symbol) ||
      (CAR(params) == key_symbol))
    {
      return (empty_list);
    }
  else if (PAIRP (CAR (params)))
    {
      return (cons (eval (SECOND (CAR (params))), 
		    method_specializers_help (CDR (params))));
    }
  else
    {
      return (cons (object_class, 
		    method_specializers_help (CDR (params))));
    }
}

/* 
   returns three values:
      1) number of required parameters
      2) #t if takes rest, #f otherwise
      3) sequence of keywords or #f if no keywords
*/
   
static Object
function_arguments (Object fun)
{
  Object params, obj, keyword;
  Object num_req, has_rest, keywords;
  int req, seen_rest, seen_key;

  switch (POINTERTYPE (fun))
    {
    case GenericFunction:
      params = GFPARAMS (fun);
      break;
    case Method:
      params = METHPARAMS (fun);
      break;
    case Primitive:
      error ("function-arguments: cannot query arguments of a primitive", fun, NULL);
    default:
      error ("function-arguments: bad argument", fun, NULL);
    }
  req = 0;
  has_rest = false_object;
  keywords = empty_list;
  seen_rest = seen_key = 0;
  while (! NULLP (params))
    {
      obj = CAR (params);
      if (seen_key)
	{
	  if (PAIRP (obj))
	    {
	      if (KEYWORDP (CAR (obj)))
		keyword = CAR (obj);
	      else
		keyword = symbol_to_keyword (CAR (obj));
	    }
	  else
	    {
	      keyword = symbol_to_keyword (obj);
	    }
	  keywords = cons (keyword, keywords);
	}
      else if (obj == rest_symbol)
	{
	  seen_rest = 1;
	}
      else if (obj == key_symbol)
	{
	  seen_key = 1;
	}
      else if (! seen_rest)
	{
	  req++;
	}
      params = CDR (params);
    }
  if (! seen_key)
    keywords = false_object;
  if (seen_rest)
    has_rest = true_object;
  num_req = make_integer (req);
  return (construct_values (3, num_req, has_rest, keywords));
}

static Object 
applicable_method_p (Object fun, Object sample_args)
{
  Object args, specs, samples, theargs, keywords, sample_keys;
  int num_required, i, no_rest_param;

  if (! METHODP (fun))
    {
      error ("applicable-method?: first argument must be a generic function", fun, NULL);
    }
  args = function_arguments (fun);
  specs = method_specializers (fun);

  /* Are there more sample args than required args?
   */
  num_required = INTVAL (FIRSTVAL (args));
  if (list_length (sample_args) < num_required)
    {
      return (false_object);
    }

  /* Do the types of the required args match the
     types of the sample args?
  */
  samples = sample_args;
  for ( i=0 ; i < num_required ; ++i )
    {
      if (instance_p (CAR (samples), CAR (specs)) == false_object)
	{
	  return (false_object);
	}
      samples = CDR (samples);
      specs = CDR (specs);
    }

  /* If no rest parameter, all the keywords must be accounted for.
  */
  no_rest_param = (SECONDVAL(args) == false_object);
  if ( no_rest_param )
    {
      keywords = THIRDVAL (args);
      sample_keys = all_keywords (sample_args);
      if ((keywords == false_object) && (sample_keys != empty_list))
	{
	  return (false_object);
	}
      while (! NULLP (sample_keys))
	{
	  if (member_p (CAR (sample_keys), keywords, NULL) == false_object)
	    {
	      return (false_object);
	    }
	  sample_keys = CDR (sample_keys);
	}
    }

  /* We passed all of the tests.
   */
  return (true_object);
}

Object 
sorted_applicable_methods (Object fun, Object sample_args)
{
  Object methods, app_methods, sorted_methods, method;

  methods = GFMETHODS (fun);
  app_methods = empty_list;
  while (! NULLP (methods))
    {
      method = CAR (methods);
      if (applicable_method_p (method, sample_args) != false_object)
	{
	  app_methods = cons (method, app_methods);
	}
      methods = CDR (methods);
    }
  if (NULLP (app_methods))
    {
      error ("no applicable methods", fun, sample_args, NULL);
    }
  sorted_methods = sort_methods (app_methods);
  return (sorted_methods);
}

static Object
sort_methods (Object methods)
{
  Object method_vector;
  typedef int (*sortfun)();


  method_vector = make_sov (methods);
  qsort (SOVELS(method_vector), 
	 SOVSIZE(method_vector),
	 sizeof (Object),
	 (sortfun)sort_driver);
  return (vector_to_list (method_vector));
}

static int
sort_driver (Object *pmeth1, Object *pmeth2)
{
  Object specs1, specs2;

  specs1 = method_specializers (*pmeth1);
  specs2 = method_specializers (*pmeth2);
  return (specializer_less_than (specs1, specs2));
}

/* It is assumed that s1 and s2 have the same length.
*/
static int
same_specializers (Object s1, Object s2)
{
  while (! NULLP (s1) && ! NULLP (s2))
    {
      if (same_class_p (CAR (s1), CAR (s2)) == false_object)
	{
	  return (0);
	}
      s1 = CDR (s1);
      s2 = CDR (s2);
    }
  return (1);
}

static int
specializer_less_than (Object s1, Object s2)
{
  Object spec1, spec2, specs1, specs2;
  
  specs1 = s1;
  specs2 = s2;
  while (! NULLP (specs1))
    {
      spec1 = CAR (specs1);
      spec2 = CAR (specs2);

      if (spec1 == spec2)
	{
	  specs1 = CDR (specs1);
	  specs2 = CDR (specs2);
	  continue;
	}
      if (subclass_p (spec1, spec2) == false_object)
	{
	  return (1);
	}
      else
	{
	  return (0);
	}
    }
  error ("specializer-less-than?: specializers for generic functions are the same", s1, s2, NULL);
}

static Object 
find_method (Object generic, Object spec_list)
{
  error ("find-method: not implemented", NULL);
}

static Object 
remove_method (Object generic, Object method)
{
  error ("remove-method: not implemented", NULL);
}

static Object 
debug_name_setter (Object method, Object name)
{
  METHNAME(method) = name;
  return (name);
}
