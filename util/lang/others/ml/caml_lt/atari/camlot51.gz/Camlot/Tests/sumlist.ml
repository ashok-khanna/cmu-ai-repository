let rec sumlist = function
    [] -> 0
  | a::L -> a + sumlist L
;;

let rec interval n =
  if n <= 0 then [] else n :: interval (n-1)
;;

let rec repeat n =
  if n <= 0 then 0 else (repeat (n-1); sumlist(interval 10000))
;;

print_int (repeat 100); print_string "\n"
;;
