(* sys.ml *)
(* version 0.5 *)
(* Regis Cridlig 1993 *)

let raise_break_exn () = raise(Break)
;;

let s_irusr = 0o400
and s_iwusr = 0o200
and s_ixusr = 0o100
and s_irgrp = 0o040
and s_iwgrp = 0o020
and s_ixgrp = 0o010
and s_iroth = 0o004
and s_iwoth = 0o002
and s_ixoth = 0o001
and s_isuid =0o4000
and s_isgid =0o2000
and s_irall = 0o444
and s_iwall = 0o222
and s_ixall = 0o111
;;
