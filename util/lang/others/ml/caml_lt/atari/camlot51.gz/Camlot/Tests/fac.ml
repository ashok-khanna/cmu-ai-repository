(* fac.ml *)

let rec fac = function
   0 -> 1
| n -> n*fac(n-1)
;;

print_int (fac 10); print_newline ()
;;
