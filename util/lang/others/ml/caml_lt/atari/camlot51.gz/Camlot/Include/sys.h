/* sys.h */
/* version 0.5 */
/* Regis Cridlig 1993 */

#ifndef _sys_
#define _sys_

extern void sys_error (void);
extern void raise_pending_signal (void);
extern void sys_init (int argc, char *argv[]);
extern obj_t sys_exit (obj_t);

extern obj_t sys_command_line;

#endif /* _sys_ */
