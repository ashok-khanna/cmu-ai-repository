#include "lib.h"

obj_t __ContinueValue;

int print(obj_t n)
{
     printf("%d\n", n);
     return n;
}
