(* globals.ml : les informations sur les valeurs globales  *)

#open "constants";;

let little_name_of_global g = g.qualid.id
;;

let generic = (-1)
and notgeneric = 0;;

let int_of_constr_kind = function
    Constr_constant tag -> int_of_constr_tag tag
  | Constr_regular(tag,_,_) -> int_of_constr_tag tag
;;
