#open "int";;
#open "exc";;
#open "eq";;

let rec length_aux n = function
     []  -> n
  | _::l -> length_aux (succ n) l
;;
