#open "float";;

let integrale f a b n =
  let h = (b-a)/(float_of_int n) in
  let rec integ x =
    if x >= b then 0.0 else f x + integ (x + h) in
  integ a * h
;;

let poly x = x * x
;;

#close "float";;

let rec repeat n =
  if n <= 0 then 0.0 else (repeat (n-1); integrale poly 0.0 1.0 10000)
;;

print_float (repeat 100);
print_string "\n"
;;

