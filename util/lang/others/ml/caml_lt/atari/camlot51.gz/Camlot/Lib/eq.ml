(* Les egalites polymorphes *)

#open "bool";;

let prefix <> x y = not (x = y)
;;
