
/*  A Bison parser, made from forms.y  */

#define YYBISON 1  /* Identify Bison output.  */

#define	WRONG	258
#define	DEFUN	259
#define	DEFVAR	260
#define	DECLARATION	261
#define	DECLARE	262
#define	STATIC	263
#define	EXTERN	264
#define	INLINE	265
#define	TEXT	266
#define	VAR	267
#define	UNIN_KEYWORD	268
#define	KEYWORD	269
#define	BLOCK	270
#define	CASE	271
#define	CONTINUE	272
#define	EXPRESSION	273
#define	FLET	274
#define	FUNCALL	275
#define	FUNCTION	276
#define	IF	277
#define	LABELS	278
#define	LET	279
#define	OTHERWISE	280
#define	PROGN	281
#define	RETURN_FROM	282
#define	SETQ	283
#define	STATEMENT	284
#define	TEST	285
#define	THE_CONTINUATION	286
#define	VARIABLE	287
#define	APPLICATION	288

#line 61 "forms.y"


#include <stdlib.h>
#include <stdio.h>
#include <setjmp.h>
#include "util.h"
#include "objects.h"
#include "yystype.h"
#include "atoms.h"
#include "forms.h"
#include "k2.h"

#define YYMAXDEPTH 3000		/* Moins ridicule que le 150 par defaut. */


static void DeclareExpression(char *, char *);
static void DeclareTest(char *, char *);
static void DeclareStatement(char *, char *);
static void DeclareKeyword(int, char *, char *);

static struct variable_ref *Variable_ref(struct lex_variable *);
static struct function_ref *Function_ref(struct lex_variable *);
static struct block_ref *Block_ref(struct lex_variable *);

static struct definition *Definition(void);
static struct definition *SetDefinition(struct definition *, 
					struct function_ref *, list, form *);
static struct binding *Binding(struct variable_ref *, form *);
static struct clause *Clause(list, form *);

static form *Form(void);
static form *BlockForm(form *, struct block_ref *, form *);
static form *CaseForm(form *, form *, list, form *);
static form *ContinueForm(form *, form *, form *);
static form *ExpressionForm(form *, char *, list);
static form *FletForm(form *, list, form *);
static form *FuncallForm(form *, form *, list);
static form *FunctionForm(form *, struct function_ref *);
static form *IfForm(form *, form *, form *, form *);
static form *LabelsForm(form *, list, form *);
static form *LetForm(form *, list, form *);
static form *PrognForm(form *, list);
static form *Return_FromForm(form *, struct block_ref *, form *);
static form *SetqForm(form *, struct variable_ref *, form *);
static form *StatementForm(form *, char *, list);
static form *TestForm(form *, char *, list);
static form *The_ContinuationForm(form *);
static form *KeywordForm(form *, struct keyword *, list);
static form *ApplicationForm(form *, struct function_ref *, list);

static form *VariableForm(struct variable_ref *);

static int vcount;		/* Pour compter les arguments d'un */
				/* prototype... */

#ifndef YYLTYPE
typedef
  struct yyltype
    {
      int timestamp;
      int first_line;
      int first_column;
      int last_line;
      int last_column;
      char *text;
   }
  yyltype;

#define YYLTYPE yyltype
#endif

#ifndef YYSTYPE
#define YYSTYPE int
#endif
#include <stdio.h>

#ifndef __STDC__
#define const
#endif



#define	YYFINAL		187
#define	YYFLAG		-32768
#define	YYNTBASE	36

#define YYTRANSLATE(x) ((unsigned)(x) <= 288 ? yytranslate[x] : 105)

static const char yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,    34,
    35,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     2,     3,     4,     5,
     6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
    16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
    26,    27,    28,    29,    30,    31,    32,    33
};

#if YYDEBUG != 0
static const short yyprhs[] = {     0,
     0,     2,     4,     6,     7,     8,    12,    15,    19,    23,
    28,    32,    36,    40,    44,    51,    58,    65,    69,    73,
    74,    77,    78,    79,    83,    87,    88,    95,    96,   100,
   102,   107,   112,   115,   117,   118,   121,   123,   124,   127,
   129,   130,   133,   135,   136,   139,   141,   142,   145,   147,
   148,   151,   153,   157,   159,   161,   163,   165,   167,   169,
   171,   173,   175,   177,   179,   181,   183,   185,   187,   189,
   191,   193,   194,   199,   200,   206,   207,   212,   213,   218,
   219,   226,   227,   232,   233,   237,   238,   244,   245,   252,
   253,   260,   263,   264,   269,   270,   275,   276,   281,   282,
   287,   289,   290,   294,   295
};

#endif

static const short yyrhs[] = {    12,
     0,    12,     0,    12,     0,     0,     0,    39,    40,    41,
     0,    34,    42,     0,     4,    49,    35,     0,     5,    36,
    35,     0,     6,    11,    59,    35,     0,     7,    43,    35,
     0,    18,    13,    11,     0,    30,    13,    11,     0,    29,
    13,    11,     0,     8,     4,    12,    34,    44,    35,     0,
     9,     4,    12,    34,    44,    35,     0,    10,     4,    12,
    34,    44,    35,     0,     8,     5,    12,     0,     9,     5,
    12,     0,     0,    45,    46,     0,     0,     0,    46,    47,
    12,     0,    34,    49,    35,     0,     0,    50,    37,    34,
    59,    35,    51,     0,     0,    52,    69,    61,     0,    61,
     0,    34,    36,    69,    35,     0,    34,    67,    51,    35,
     0,    25,    51,     0,    58,     0,     0,    58,    48,     0,
    60,     0,     0,    60,    36,     0,    62,     0,     0,    62,
    69,     0,    64,     0,     0,    64,    54,     0,    66,     0,
     0,    66,    55,     0,    68,     0,     0,    68,    11,     0,
    36,     0,    34,    70,    35,     0,    71,     0,    73,     0,
    75,     0,    77,     0,    79,     0,    81,     0,    83,     0,
    85,     0,    87,     0,    89,     0,    91,     0,    92,     0,
    94,     0,    96,     0,    98,     0,   100,     0,   101,     0,
   103,     0,     0,    15,    72,    38,    51,     0,     0,    16,
    74,    69,    65,    56,     0,     0,    17,    76,    69,    69,
     0,     0,    18,    78,    11,    53,     0,     0,    19,    80,
    34,    57,    35,    51,     0,     0,    20,    82,    69,    53,
     0,     0,    21,    84,    37,     0,     0,    22,    86,    69,
    69,    69,     0,     0,    23,    88,    34,    57,    35,    51,
     0,     0,    24,    90,    34,    63,    35,    51,     0,    26,
    51,     0,     0,    27,    93,    38,    69,     0,     0,    28,
    95,    36,    69,     0,     0,    29,    97,    11,    53,     0,
     0,    30,    99,    11,    53,     0,    31,     0,     0,    14,
   102,    53,     0,     0,   104,    37,    53,     0
};

#if YYDEBUG != 0
static const short yyrline[] = { 0,
   155,   159,   163,   173,   174,   174,   178,   182,   183,   186,
   189,   197,   198,   199,   200,   203,   206,   209,   212,   217,
   218,   221,   222,   223,   230,   234,   234,   239,   239,   244,
   248,   252,   256,   265,   265,   265,   266,   266,   266,   267,
   267,   267,   268,   268,   268,   269,   269,   269,   270,   270,
   270,   278,   279,   283,   284,   285,   286,   287,   288,   289,
   290,   291,   292,   293,   294,   295,   296,   297,   298,   299,
   300,   304,   304,   309,   309,   314,   314,   319,   319,   324,
   324,   329,   329,   334,   335,   339,   339,   344,   344,   349,
   349,   354,   358,   358,   363,   363,   368,   368,   373,   373,
   378,   383,   384,   387,   387
};

static const char * const yytname[] = {   "$","error","$illegal.","WRONG","DEFUN",
"DEFVAR","DECLARATION","DECLARE","STATIC","EXTERN","INLINE","TEXT","VAR","UNIN_KEYWORD",
"KEYWORD","BLOCK","CASE","CONTINUE","EXPRESSION","FLET","FUNCALL","FUNCTION",
"IF","LABELS","LET","OTHERWISE","PROGN","RETURN_FROM","SETQ","STATEMENT","TEST",
"THE_CONTINUATION","VARIABLE","APPLICATION","'('","')'","var","fun","blk","file",
"@1","mform","mform_body","declaration","VARs","@2","VARs_list","@3","def","def_body",
"@4","body","@5","args","bind","clause","default_clause","defs","defs_list",
"vars","vars_list","forms","forms_list","binds","binds_list","clauses","clauses_list",
"texts","texts_list","form","form_switch","block","@6","case","@7","continue",
"@8","expression","@9","flet","@10","funcall","@11","function","@12","if","@13",
"labels","@14","let","@15","progn","return_from","@16","setq","@17","statement",
"@18","test","@19","the_continuation","keyword","@20","application","@21",""
};
#endif

static const short yyr1[] = {     0,
    36,    37,    38,    39,    40,    39,    41,    42,    42,    42,
    42,    43,    43,    43,    43,    43,    43,    43,    43,    45,
    44,    46,    47,    46,    48,    50,    49,    52,    51,    53,
    54,    55,    56,    57,    58,    58,    59,    60,    60,    61,
    62,    62,    63,    64,    64,    65,    66,    66,    67,    68,
    68,    69,    69,    70,    70,    70,    70,    70,    70,    70,
    70,    70,    70,    70,    70,    70,    70,    70,    70,    70,
    70,    72,    71,    74,    73,    76,    75,    78,    77,    80,
    79,    82,    81,    84,    83,    86,    85,    88,    87,    90,
    89,    91,    93,    92,    95,    94,    97,    96,    99,    98,
   100,   102,   101,   104,   103
};

static const short yyr2[] = {     0,
     1,     1,     1,     0,     0,     3,     2,     3,     3,     4,
     3,     3,     3,     3,     6,     6,     6,     3,     3,     0,
     2,     0,     0,     3,     3,     0,     6,     0,     3,     1,
     4,     4,     2,     1,     0,     2,     1,     0,     2,     1,
     0,     2,     1,     0,     2,     1,     0,     2,     1,     0,
     2,     1,     3,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     0,     4,     0,     5,     0,     4,     0,     4,     0,
     6,     0,     4,     0,     3,     0,     5,     0,     6,     0,
     6,     2,     0,     4,     0,     4,     0,     4,     0,     4,
     1,     0,     3,     0,     3
};

static const short yydefact[] = {     4,
     5,     0,     0,     6,    26,     0,     0,     0,     7,     0,
     0,     1,     0,    38,     0,     0,     0,     0,     0,     0,
     0,     8,     2,     0,     9,     0,    37,     0,     0,     0,
     0,     0,     0,     0,     0,    11,    38,    10,    39,     0,
    18,     0,    19,     0,    12,    14,    13,     0,    20,    20,
    20,    28,     0,    22,     0,     0,    27,     0,    15,    21,
    16,    17,   104,    52,    41,     0,   102,    72,    74,    76,
    78,    80,    82,    84,    86,    88,    90,    28,    93,    95,
    97,    99,   101,     0,    54,    55,    56,    57,    58,    59,
    60,    61,    62,    63,    64,    65,    66,    67,    68,    69,
    70,    71,     0,    29,    40,    24,    41,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,    92,     0,     0,
     0,     0,    53,    41,    42,   103,    30,     3,    28,    47,
     0,    41,    35,    41,    85,     0,    35,    44,     0,     0,
    41,    41,   105,    73,     0,    46,    77,    79,     0,    34,
    83,     0,     0,     0,    43,    94,    96,    98,   100,    28,
    75,    50,    48,    28,    26,    36,    87,    28,    28,     0,
    45,    33,    28,    49,    81,     0,    89,    91,     0,     0,
    51,    25,     0,    32,    31,     0,     0
};

static const short yydefgoto[] = {    64,
    24,   129,     1,     2,     4,     9,    21,    53,    54,    60,
    66,   166,    10,    11,    57,    58,   126,   171,   163,   161,
   149,   150,    26,    27,   127,   105,   154,   155,   145,   146,
   173,   174,    65,    84,    85,   108,    86,   109,    87,   110,
    88,   111,    89,   112,    90,   113,    91,   114,    92,   115,
    93,   116,    94,   117,    95,    96,   119,    97,   120,    98,
   121,    99,   122,   100,   101,   107,   102,   103
};

static const short yypact[] = {-32768,
    16,   -14,    34,-32768,-32768,     6,    12,    -5,-32768,     7,
    17,-32768,     8,-32768,    10,    27,    40,    32,    33,    35,
    15,-32768,-32768,    13,-32768,    29,     6,    59,    60,    61,
    62,    63,    66,    67,    68,-32768,-32768,-32768,-32768,    46,
-32768,    47,-32768,    48,-32768,-32768,-32768,    49,-32768,-32768,
-32768,-32768,    50,-32768,    51,    53,-32768,    -4,-32768,    77,
-32768,-32768,    39,-32768,-32768,    78,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,    58,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,    17,-32768,    -4,-32768,-32768,    82,    -4,    -4,
    84,    64,    -4,    17,    -4,    65,    69,-32768,    82,     6,
    86,    89,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
    -4,-32768,-32768,-32768,-32768,    -4,-32768,-32768,    -4,    -4,
-32768,-32768,-32768,-32768,    26,    70,-32768,-32768,    71,    73,
-32768,    -4,    74,    75,    79,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,     6,
-32768,-32768,-32768,    90,-32768,    76,-32768,-32768,    -4,    80,
-32768,-32768,    81,-32768,-32768,   102,-32768
};

static const short yypgoto[] = {    -6,
   -92,   -11,-32768,-32768,-32768,-32768,-32768,   -16,-32768,-32768,
-32768,-32768,   -60,-32768,   -77,-32768,  -115,-32768,-32768,-32768,
   -25,-32768,    83,-32768,    52,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,  -103,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768
};


#define	YYLAST		164


static const short yytable[] = {    13,
   118,   125,    15,    16,    17,   130,   131,    12,   143,   134,
   124,   136,    18,    28,    29,   186,   148,    12,   151,     3,
    39,   135,    14,    19,    20,   158,   159,   147,    23,    63,
    30,    31,   152,    55,    56,   156,   157,     5,     6,     7,
     8,    22,    25,    32,    33,    34,    37,    35,   167,    36,
   160,   144,    67,    68,    69,    70,    71,    72,    73,    74,
    75,    76,    77,    38,    78,    79,    80,    81,    82,    83,
    40,    41,    42,    43,    44,   183,    45,    46,    47,    49,
    50,    51,   172,    52,    59,    61,   175,    62,   -23,   106,
   177,   178,   123,   128,   132,   180,   141,   133,   137,   142,
   181,   187,   138,   162,   176,   164,   165,   139,   168,   169,
   182,   153,   170,   140,   184,   185,   104,     0,     0,    48,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,   179
};

static const short yycheck[] = {     6,
    78,   105,     8,     9,    10,   109,   110,    12,   124,   113,
   103,   115,    18,     4,     5,     0,   132,    12,   134,    34,
    27,   114,    11,    29,    30,   141,   142,   131,    12,    34,
     4,     5,   136,    50,    51,   139,   140,     4,     5,     6,
     7,    35,    35,     4,    13,    13,    34,    13,   152,    35,
    25,   129,    14,    15,    16,    17,    18,    19,    20,    21,
    22,    23,    24,    35,    26,    27,    28,    29,    30,    31,
    12,    12,    12,    12,    12,   179,    11,    11,    11,    34,
    34,    34,   160,    35,    35,    35,   164,    35,    12,    12,
   168,   169,    35,    12,    11,   173,    11,    34,    34,    11,
    11,     0,    34,    34,   165,    35,    34,   119,    35,    35,
    35,   137,    34,   120,    35,    35,    65,    -1,    -1,    37,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,   170
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "bison.simple"

/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Bob Corbett and Richard Stallman

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */


#ifndef alloca
#ifdef __GNUC__
#define alloca __builtin_alloca
#else /* not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__)
#include <alloca.h>
#else /* not sparc */
#if defined (MSDOS) && !defined (__TURBOC__)
#include <malloc.h>
#else /* not MSDOS, or __TURBOC__ */
#if defined(_AIX)
#include <malloc.h>
 #pragma alloca
#endif /* not _AIX */
#endif /* not MSDOS, or __TURBOC__ */
#endif /* not sparc.  */
#endif /* not GNU C.  */
#endif /* alloca not defined.  */

/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

/* Note: there must be only one dollar sign in this file.
   It is replaced by the list of actions, each action
   as one case of the switch.  */

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	return(0)
#define YYABORT 	return(1)
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(token, value) \
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    { yychar = (token), yylval = (value);			\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { yyerror ("syntax error: cannot back up"); YYERROR; }	\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

#ifndef YYPURE
#define YYLEX		yylex()
#endif

#ifdef YYPURE
#ifdef YYLSP_NEEDED
#define YYLEX		yylex(&yylval, &yylloc)
#else
#define YYLEX		yylex(&yylval)
#endif
#endif

/* If nonreentrant, generate the variables here */

#ifndef YYPURE

int	yychar;			/*  the lookahead symbol		*/
YYSTYPE	yylval;			/*  the semantic value of the		*/
				/*  lookahead symbol			*/

#ifdef YYLSP_NEEDED
YYLTYPE yylloc;			/*  location data for the lookahead	*/
				/*  symbol				*/
#endif

int yynerrs;			/*  number of parse errors so far       */
#endif  /* not YYPURE */

#if YYDEBUG != 0
int yydebug;			/*  nonzero means print parse trace	*/
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/

#ifndef	YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

#if __GNUC__ > 1		/* GNU C and GNU C++ define this.  */
#define __yy_bcopy(FROM,TO,COUNT)	__builtin_memcpy(TO,FROM,COUNT)
#else				/* not GNU C or C++ */
#ifndef __cplusplus

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_bcopy (from, to, count)
     char *from;
     char *to;
     int count;
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#else /* __cplusplus */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_bcopy (char *from, char *to, int count)
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#endif
#endif

#line 169 "bison.simple"
int
yyparse()
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YYSTYPE *yyvsp;
  int yyerrstatus;	/*  number of tokens to shift before error messages enabled */
  int yychar1;		/*  lookahead token as an internal (translated) token number */

  short	yyssa[YYINITDEPTH];	/*  the state stack			*/
  YYSTYPE yyvsa[YYINITDEPTH];	/*  the semantic value stack		*/

  short *yyss = yyssa;		/*  refer to the stacks thru separate pointers */
  YYSTYPE *yyvs = yyvsa;	/*  to allow yyoverflow to reallocate them elsewhere */

#ifdef YYLSP_NEEDED
  YYLTYPE yylsa[YYINITDEPTH];	/*  the location stack			*/
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
#define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  int yystacksize = YYINITDEPTH;

#ifdef YYPURE
  int yychar;
  YYSTYPE yylval;
  int yynerrs;
#ifdef YYLSP_NEEDED
  YYLTYPE yylloc;
#endif
#endif

  YYSTYPE yyval;		/*  the variable used to return		*/
				/*  semantic values from the action	*/
				/*  routines				*/

  int yylen;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Starting parse\n");
#endif

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.  */

  yyssp = yyss - 1;
  yyvsp = yyvs;
#ifdef YYLSP_NEEDED
  yylsp = yyls;
#endif

/* Push a new state, which is found in  yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
yynewstate:

  *++yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
      YYSTYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;
#ifdef YYLSP_NEEDED
      YYLTYPE *yyls1 = yyls;
#endif

      /* Get the current used size of the three stacks, in elements.  */
      int size = yyssp - yyss + 1;

#ifdef yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
#ifdef YYLSP_NEEDED
		 &yyls1, size * sizeof (*yylsp),
#endif
		 &yystacksize);

      yyss = yyss1; yyvs = yyvs1;
#ifdef YYLSP_NEEDED
      yyls = yyls1;
#endif
#else /* no yyoverflow */
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	{
	  yyerror("parser stack overflow");
	  return 2;
	}
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;
      yyss = (short *) alloca (yystacksize * sizeof (*yyssp));
      __yy_bcopy ((char *)yyss1, (char *)yyss, size * sizeof (*yyssp));
      yyvs = (YYSTYPE *) alloca (yystacksize * sizeof (*yyvsp));
      __yy_bcopy ((char *)yyvs1, (char *)yyvs, size * sizeof (*yyvsp));
#ifdef YYLSP_NEEDED
      yyls = (YYLTYPE *) alloca (yystacksize * sizeof (*yylsp));
      __yy_bcopy ((char *)yyls1, (char *)yyls, size * sizeof (*yylsp));
#endif
#endif /* no yyoverflow */

      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;
#ifdef YYLSP_NEEDED
      yylsp = yyls + size - 1;
#endif

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Stack size increased to %d\n", yystacksize);
#endif

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Entering state %d\n", yystate);
#endif

 yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Reading a token: ");
#endif
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      yychar1 = YYTRANSLATE(yychar);

#if YYDEBUG != 0
      if (yydebug)
	{
	  fprintf (stderr, "Next token is %d (%s", yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise meaning
	     of a token, for further debugging info.  */
#ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
#endif
	  fprintf (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting token %d (%s), ", yychar, yytname[yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* count tokens shifted since error; after three, turn off error status.  */
  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;

/* Do the default action for the current state.  */
yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;

/* Do a reduction.  yyn is the number of a rule to reduce with.  */
yyreduce:
  yylen = yyr2[yyn];
  yyval = yyvsp[1-yylen]; /* implement default value of the action */

#if YYDEBUG != 0
  if (yydebug)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       yyn, yyrline[yyn]);

      /* Print the symboles being reduced, and their result.  */
      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", yytname[yyrhs[i]]);
      fprintf (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif


  switch (yyn) {

case 1:
#line 155 "forms.y"
{ yyval = Variable_ref(yyvsp[0]); ;
    break;}
case 2:
#line 159 "forms.y"
{ yyval = Function_ref(yyvsp[0]); ;
    break;}
case 3:
#line 163 "forms.y"
{ yyval = Block_ref(yyvsp[0]); ;
    break;}
case 5:
#line 174 "forms.y"
{ InitPre(); ;
    break;}
case 6:
#line 174 "forms.y"
{ InitPost(); ;
    break;}
case 8:
#line 182 "forms.y"
{ CompileDefun(yyvsp[-1]); ;
    break;}
case 9:
#line 183 "forms.y"
{ CompileDefvar(yyvsp[-1], Lineno,
							VirtualLineno,
							VirtualInName); ;
    break;}
case 10:
#line 186 "forms.y"
{ CompileDeclaration(yyvsp[-2], yyvsp[-1], Lineno, 
							     VirtualLineno,
							     VirtualInName); ;
    break;}
case 12:
#line 197 "forms.y"
{ DeclareExpression(yyvsp[-1], yyvsp[0]); ;
    break;}
case 13:
#line 198 "forms.y"
{ DeclareTest(yyvsp[-1], yyvsp[0]); ;
    break;}
case 14:
#line 199 "forms.y"
{ DeclareStatement(yyvsp[-1], yyvsp[0]); ;
    break;}
case 15:
#line 200 "forms.y"
{ FunPrototype(yyvsp[-3], vcount, STATIC,
						       Lineno, VirtualLineno,
						       VirtualInName); ;
    break;}
case 16:
#line 203 "forms.y"
{ FunPrototype(yyvsp[-3], vcount, EXTERN,
						       Lineno, VirtualLineno,
						       VirtualInName); ;
    break;}
case 17:
#line 206 "forms.y"
{ FunPrototype(yyvsp[-3], vcount, INLINE,
						       Lineno, VirtualLineno,
						       VirtualInName); ;
    break;}
case 18:
#line 209 "forms.y"
{ VarPrototype(yyvsp[0], STATIC,
						       Lineno, VirtualLineno,
						       VirtualInName); ;
    break;}
case 19:
#line 212 "forms.y"
{ VarPrototype(yyvsp[0], EXTERN,
						       Lineno, VirtualLineno,
						       VirtualInName); ;
    break;}
case 20:
#line 217 "forms.y"
{ vcount = 0; ;
    break;}
case 23:
#line 222 "forms.y"
{ vcount++; ;
    break;}
case 25:
#line 230 "forms.y"
{ yyval = yyvsp[-1]; ;
    break;}
case 26:
#line 234 "forms.y"
{ yyval = Definition(); ;
    break;}
case 27:
#line 235 "forms.y"
{ yyval = SetDefinition(yyvsp[-5], yyvsp[-4], yyvsp[-2], yyvsp[0]); ;
    break;}
case 28:
#line 239 "forms.y"
{ yyval = Form(); ;
    break;}
case 29:
#line 240 "forms.y"
{ yyval = PrognForm(yyvsp[-2], cons(yyvsp[-1], yyvsp[0])); ;
    break;}
case 30:
#line 244 "forms.y"
{ yyval = yyvsp[0]; ;
    break;}
case 31:
#line 248 "forms.y"
{ yyval = Binding(yyvsp[-2], yyvsp[-1]); ;
    break;}
case 32:
#line 252 "forms.y"
{ yyval = Clause(yyvsp[-2], yyvsp[-1]); ;
    break;}
case 33:
#line 256 "forms.y"
{ yyval = yyvsp[0]; ;
    break;}
case 34:
#line 265 "forms.y"
{ yyval = qlist(yyvsp[0]); ;
    break;}
case 35:
#line 265 "forms.y"
{ yyval = emptyq(); ;
    break;}
case 36:
#line 265 "forms.y"
{ yyval = addq(yyvsp[0], yyvsp[-1]); ;
    break;}
case 37:
#line 266 "forms.y"
{ yyval = qlist(yyvsp[0]); ;
    break;}
case 38:
#line 266 "forms.y"
{ yyval = emptyq(); ;
    break;}
case 39:
#line 266 "forms.y"
{ yyval = addq(yyvsp[0], yyvsp[-1]); ;
    break;}
case 40:
#line 267 "forms.y"
{ yyval = qlist(yyvsp[0]); ;
    break;}
case 41:
#line 267 "forms.y"
{ yyval = emptyq(); ;
    break;}
case 42:
#line 267 "forms.y"
{ yyval = addq(yyvsp[0], yyvsp[-1]); ;
    break;}
case 43:
#line 268 "forms.y"
{ yyval = qlist(yyvsp[0]); ;
    break;}
case 44:
#line 268 "forms.y"
{ yyval = emptyq(); ;
    break;}
case 45:
#line 268 "forms.y"
{ yyval = addq(yyvsp[0], yyvsp[-1]); ;
    break;}
case 46:
#line 269 "forms.y"
{ yyval = qlist(yyvsp[0]); ;
    break;}
case 47:
#line 269 "forms.y"
{ yyval = emptyq(); ;
    break;}
case 48:
#line 269 "forms.y"
{ yyval = addq(yyvsp[0], yyvsp[-1]); ;
    break;}
case 49:
#line 270 "forms.y"
{ yyval = qlist(yyvsp[0]); ;
    break;}
case 50:
#line 270 "forms.y"
{ yyval = emptyq(); ;
    break;}
case 51:
#line 270 "forms.y"
{ yyval = addq(yyvsp[0], yyvsp[-1]); ;
    break;}
case 52:
#line 278 "forms.y"
{ yyval = VariableForm(yyvsp[0]); ;
    break;}
case 53:
#line 279 "forms.y"
{ yyval = yyvsp[-1]; ;
    break;}
case 72:
#line 304 "forms.y"
{ yyval = Form(); ;
    break;}
case 73:
#line 305 "forms.y"
{ yyval = BlockForm(yyvsp[-2], yyvsp[-1], yyvsp[0]); ;
    break;}
case 74:
#line 309 "forms.y"
{ yyval = Form(); ;
    break;}
case 75:
#line 310 "forms.y"
{ yyval = CaseForm(yyvsp[-3], yyvsp[-2], yyvsp[-1], yyvsp[0]); ;
    break;}
case 76:
#line 314 "forms.y"
{ yyval = Form(); ;
    break;}
case 77:
#line 315 "forms.y"
{ yyval = ContinueForm(yyvsp[-2], yyvsp[-1], yyvsp[0]); ;
    break;}
case 78:
#line 319 "forms.y"
{ yyval = Form(); ;
    break;}
case 79:
#line 320 "forms.y"
{ yyval = ExpressionForm(yyvsp[-2], yyvsp[-1], yyvsp[0]); ;
    break;}
case 80:
#line 324 "forms.y"
{ yyval = Form(); ;
    break;}
case 81:
#line 325 "forms.y"
{ yyval = FletForm(yyvsp[-4], yyvsp[-2], yyvsp[0]); ;
    break;}
case 82:
#line 329 "forms.y"
{ yyval = Form(); ;
    break;}
case 83:
#line 330 "forms.y"
{ yyval = FuncallForm(yyvsp[-2], yyvsp[-1], yyvsp[0]); ;
    break;}
case 84:
#line 334 "forms.y"
{ yyval = Form(); ;
    break;}
case 85:
#line 335 "forms.y"
{ yyval = FunctionForm(yyvsp[-1], yyvsp[0]); ;
    break;}
case 86:
#line 339 "forms.y"
{ yyval = Form(); ;
    break;}
case 87:
#line 340 "forms.y"
{ yyval = IfForm(yyvsp[-3], yyvsp[-2], yyvsp[-1], yyvsp[0]); ;
    break;}
case 88:
#line 344 "forms.y"
{ yyval = Form(); ;
    break;}
case 89:
#line 345 "forms.y"
{ yyval = LabelsForm(yyvsp[-4], yyvsp[-2], yyvsp[0]); ;
    break;}
case 90:
#line 349 "forms.y"
{ yyval = Form(); ;
    break;}
case 91:
#line 350 "forms.y"
{ yyval = LetForm(yyvsp[-4], yyvsp[-2], yyvsp[0]); ;
    break;}
case 92:
#line 354 "forms.y"
{ yyval = yyvsp[0]; ;
    break;}
case 93:
#line 358 "forms.y"
{ yyval = Form(); ;
    break;}
case 94:
#line 359 "forms.y"
{ yyval = Return_FromForm(yyvsp[-2], yyvsp[-1], yyvsp[0]); ;
    break;}
case 95:
#line 363 "forms.y"
{ yyval = Form(); ;
    break;}
case 96:
#line 364 "forms.y"
{ yyval = SetqForm(yyvsp[-2], yyvsp[-1], yyvsp[0]); ;
    break;}
case 97:
#line 368 "forms.y"
{ yyval = Form(); ;
    break;}
case 98:
#line 369 "forms.y"
{ yyval = StatementForm(yyvsp[-2], yyvsp[-1], yyvsp[0]); ;
    break;}
case 99:
#line 373 "forms.y"
{ yyval = Form(); ;
    break;}
case 100:
#line 374 "forms.y"
{ yyval = TestForm(yyvsp[-2], yyvsp[-1], yyvsp[0]); ;
    break;}
case 101:
#line 379 "forms.y"
{ yyval = The_ContinuationForm(Form()); ;
    break;}
case 102:
#line 383 "forms.y"
{ yyval =  Form(); ;
    break;}
case 103:
#line 384 "forms.y"
{ yyval = KeywordForm(yyvsp[-1], yyvsp[-2], yyvsp[0]); ;
    break;}
case 104:
#line 387 "forms.y"
{ yyval = Form(); ;
    break;}
case 105:
#line 388 "forms.y"
{ yyval = ApplicationForm(yyvsp[-2], yyvsp[-1], yyvsp[0]); ;
    break;}
}
   /* the action file gets copied in in place of this dollarsign */
#line 440 "bison.simple"

  yyvsp -= yylen;
  yyssp -= yylen;
#ifdef YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;

#ifdef YYLSP_NEEDED
  yylsp++;
  if (yylen == 0)
    {
      yylsp->first_line = yylloc.first_line;
      yylsp->first_column = yylloc.first_column;
      yylsp->last_line = (yylsp-1)->last_line;
      yylsp->last_column = (yylsp-1)->last_column;
      yylsp->text = 0;
    }
  else
    {
      yylsp->last_line = (yylsp+yylen-1)->last_line;
      yylsp->last_column = (yylsp+yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;

yyerrlab:   /* here on detecting error */

  if (! yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  for (x = 0; x < (sizeof(yytname) / sizeof(char *)); x++)
	    if (yycheck[x + yyn] == x)
	      size += strlen(yytname[x]) + 15, count++;
	  msg = (char *) malloc(size + 15);
	  if (msg != 0)
	    {
	      strcpy(msg, "parse error");

	      if (count < 5)
		{
		  count = 0;
		  for (x = 0; x < (sizeof(yytname) / sizeof(char *)); x++)
		    if (yycheck[x + yyn] == x)
		      {
			strcat(msg, count == 0 ? ", expecting `" : " or `");
			strcat(msg, yytname[x]);
			strcat(msg, "'");
			count++;
		      }
		}
	      yyerror(msg);
	      free(msg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exceeded");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror("parse error");
    }

yyerrlab1:   /* here on error raised explicitly by an action */

  if (yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Discarding token %d (%s).\n", yychar, yytname[yychar1]);
#endif

      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;

yyerrdefault:  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  yyn = yydefact[yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (yyn) goto yydefault;
#endif

yyerrpop:   /* pop the current state because it cannot handle the error token */

  if (yyssp == yyss) YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#ifdef YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting error token, ");
#endif

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;
}
#line 393 "forms.y"



/**********************************************************************
 *
 * Declaration d'un mot-clef abreviation
 *
 **********************************************************************
 *
 * Fonction :
 *
 * 	DeclareKeyword	enregistre la declaration d'une abreviation
 *
 **********************************************************************/

static void DeclareExpression(char *id, char *text)
{
     DeclareKeyword(EXPRESSION, id, text);
}

static void DeclareTest(char *id, char *text)
{
     DeclareKeyword(TEST, id, text);
}

static void DeclareStatement(char *id, char *text)
{
     DeclareKeyword(STATEMENT, id, text);
}

static void DeclareKeyword(int token, char *id, char *text)
{
     struct hash_cell *c;
     struct keyword *k = PNEW(struct keyword);
     
     k->token = token;
     k->text = pscopy(text);
     
     c = find_create(KeywordsTable, id);
     c->contents = k;
}




/**********************************************************************
 *
 * Internement des formes et des sous-formes
 *
 **********************************************************************
 *
 * Fonctions :
 *
 *	Variable_ref	construit une reference a une variable.
 *	Function_ref	construit une reference a une fonction.
 *	Block_ref	construit une reference a un bloc lexical.
 *
 *	Form		construit une forme en n'initialisant que
 * 			les champs concernant sa position dans le source.
 *	XXXForm		construit la forme XXX.
 *
 **********************************************************************/


/*
 * References aux variables et fonctions.
 */

static struct variable_ref *Variable_ref(struct lex_variable *lexvar)
{
     struct variable_ref *vref = NEW(struct variable_ref);
     
     vref->lexvar = lexvar;
     vref->origin.lineno = Lineno;
     vref->origin.vlineno = VirtualLineno;
     vref->origin.vname = VirtualInName;
     vref->var = NULL;
     return vref;
}

static struct function_ref *Function_ref(struct lex_variable *lexvar)
{
     struct function_ref *fref = NEW(struct function_ref);
     
     fref->lexvar = lexvar;
     fref->origin.lineno = Lineno;
     fref->origin.vlineno = VirtualLineno;
     fref->origin.vname = VirtualInName;
     fref->fun = NULL;
     return fref;
}

static struct block_ref *Block_ref(struct lex_variable *lexvar)
{
     struct block_ref *bref = NEW(struct block_ref);

     bref->lexvar = lexvar;
     bref->origin.lineno = Lineno;
     bref->origin.vlineno = VirtualLineno;
     bref->origin.vname = VirtualInName;
     return bref;
}


/*
 * Sous-formes.
 */

static struct definition *Definition(void)
{
     struct definition *def = NEW(struct definition);
     
     def->origin.lineno = Lineno;
     def->origin.vlineno = VirtualLineno;
     def->origin.vname = VirtualInName;
     
     return def;
}
     
static 
struct definition *SetDefinition(struct definition *def,
				 struct function_ref *fref,
				 list vrefs, form *body)
{
     def->fref = fref;
     def->vrefs = vrefs;
     def->body = body;

     return def;
}

static struct binding *Binding(struct variable_ref *vref, form *val)
{
     struct binding *b = NEW(struct binding);
     
     b->vref = vref;
     b->val = val;

     return b;
}

static struct clause *Clause(list texts, form *body)
{
     struct clause *c = NEW(struct clause);
     
     c->texts = texts;
     c->body = body;
     return c;
}


/*
 * Formes.
 */

static form *Form(void)
{
     form *f = NEW(form);
     
     f->origin.lineno = Lineno;
     f->origin.vlineno = VirtualLineno;
     f->origin.vname = VirtualInName;

     return f;
}

static form *BlockForm(form *f, struct block_ref *bref, form *body)
{
     f->tag = BLOCK;
     f->node.block_i.bref = bref;
     f->node.block_i.body = body;
     return f;
}


static form *CaseForm(form *f, form *val, list clauses, form *def)
{
     if (clauses == NIL) return def;
     else
       {
	    
	    f->tag = CASE;
	    f->node.case_i.val = val;
	    f->node.case_i.clauses = clauses;
	    f->node.case_i.def = def;
	    
	    return f;
       };
}

static form *ContinueForm(form *f, form *c, form *val)
{
     f->tag = CONTINUE;
     f->node.continue_i.cont = c;
     f->node.continue_i.val = val;
     
     return f;
}

static form *ExpressionForm(form *f, char *text, list args)
{
     f->tag = EXPRESSION;
     f->node.expression_i.text = text;
     f->node.expression_i.args = args;
     
     return f;
}

static form *FletForm(form *f, list defs, form *body)
{

     if (defs == NIL) return body;
     else
       {
	    f->tag = FLET;
	    f->node.flet_i.defs = defs;
	    f->node.flet_i.body = body;
	    
	    return f;
       };
}

static form *FuncallForm(form *f, form *fun, list args)
{
     f->tag = FUNCALL;
     f->node.funcall_i.fun = fun;
     f->node.funcall_i.args = args;
	    
     return f;
}

static form *FunctionForm(form *f, struct function_ref *fref)
{
     f->tag = FUNCTION;
     f->node.function_i = fref;
     
     return f;
}

static form *IfForm(form *f, form *test, form *iftrue, form *iffalse)
{
     f->tag = IF;
     f->node.if_i.test = test;
     f->node.if_i.iftrue = iftrue;
     f->node.if_i.iffalse = iffalse;
     
     return f;
}

static form *LabelsForm(form *f, list defs, form *body)
{
     if (defs == NIL) return body; /* Aucun interet... mais bof... */
     else
       {
	    f->tag = LABELS;
	    f->node.labels_i.defs = defs;
	    f->node.labels_i.body = body;
	    
	    return f;
       };
}

static form *LetForm(form *f, list binds, form *body)
{
     if (binds == NULL) return body; /* Idem */
     else
       {
	    f->tag = LET;
	    f->node.let_i.binds = binds;
	    f->node.let_i.body = body;
	    
	    return f;
       };
}

static form *PrognForm(form *f, list body)
{

     if (CDR(body) == NIL) return (form *)CAR(body); /* Ibidem */
     else
       {
	    f->tag = PROGN;
	    f->node.progn_i.body = body;
	    
	    return f;
       };
}

static form *Return_FromForm(form *f, struct block_ref *bref, form *val)
{
     f->tag = RETURN_FROM;
     f->node.return_from_i.bref = bref;
     f->node.return_from_i.val = val;
     return f;
}

static form *SetqForm(form *f, struct variable_ref *vref, form *val)
{
     f->tag = SETQ;
     f->node.setq_i.vref = vref;
     f->node.setq_i.val = val;
     
     return f;
}

static form *StatementForm(form *f, char *text, list args)
{
     f->tag = STATEMENT;
     f->node.statement_i.text = text;
     f->node.statement_i.args = args;
     
     return f;
}

static form *TestForm(form *f, char *text, list args)
{
     f->tag = TEST;
     f->node.test_i.text = text;
     f->node.test_i.args = args;
     
     return f;
}

static form *The_ContinuationForm(form *f)
{
     f->tag = THE_CONTINUATION;
     f->node.the_continuation_i.contvar = NULL;
     return f;
}

static form *KeywordForm(form *f, struct keyword *key, list args)
{
     switch (key->token)
       {
       case EXPRESSION:
	    f->tag = EXPRESSION;
	    f->node.expression_i.text = key->text;
	    f->node.expression_i.args = args;
	    break;

       case TEST:
	    f->tag = TEST;
	    f->node.test_i.text = key->text;
	    f->node.test_i.args = args;
	    break;

       case STATEMENT:
	    f->tag = STATEMENT;
	    f->node.statement_i.text = key->text;
	    f->node.statement_i.args = args;
	    break;
       }
     
     return f;
}

static form *ApplicationForm(form *f, struct function_ref *fref, list args)
{
     f->tag = APPLICATION;
     f->node.application_i.fref = fref;
     f->node.application_i.args = args;
     
     return f;
}

static form *VariableForm(struct variable_ref *n)
{
     form *f = Form();
     
     f->tag = VARIABLE;
     f->node.variable_i = n;
     
     return f;
}
