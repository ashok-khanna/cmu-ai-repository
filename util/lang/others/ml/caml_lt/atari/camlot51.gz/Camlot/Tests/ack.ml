(* ack *)

let main () =
 let rec ack m =
  let ackm1 n = ack (m-1) n in
  let rec ackm n =
    if m=0 then n+1
    else ackm1 (if n=0 then 1
                       else (ackm (n-1)))
  in ackm
in print_int (ack 3 5); print_newline ();;

main();;
