#ifndef YYSTYPE
#define YYSTYPE int
#endif
#define	WRONG	258
#define	DEFUN	259
#define	DEFVAR	260
#define	DECLARATION	261
#define	DECLARE	262
#define	STATIC	263
#define	EXTERN	264
#define	INLINE	265
#define	TEXT	266
#define	VAR	267
#define	UNIN_KEYWORD	268
#define	KEYWORD	269
#define	BLOCK	270
#define	CASE	271
#define	CONTINUE	272
#define	EXPRESSION	273
#define	FLET	274
#define	FUNCALL	275
#define	FUNCTION	276
#define	IF	277
#define	LABELS	278
#define	LET	279
#define	OTHERWISE	280
#define	PROGN	281
#define	RETURN_FROM	282
#define	SETQ	283
#define	STATEMENT	284
#define	TEST	285
#define	THE_CONTINUATION	286
#define	VARIABLE	287
#define	APPLICATION	288


extern YYSTYPE yylval;
