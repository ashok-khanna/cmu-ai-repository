let double f = fun x -> f(f x);;
let quad f = double (double f);;
let rec interval n =
  if n <= 0 then [] else n :: interval (n-1)
;;
let rec map_rec = fun
    _   []   -> []
  | f (a::L) -> f a :: (map_rec f L)
;;
map_rec (quad quad succ) (interval 10000)
;;
