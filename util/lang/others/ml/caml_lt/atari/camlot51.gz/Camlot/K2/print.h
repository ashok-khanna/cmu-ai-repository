/***************************************************************************
  Copyright (C) Nitsan Seniak 1989, 1990

  This file is part of the K2 compiler.
  Permission to copy this software, in whole or in part, to use this
  software for any lawful noncommercial purpose, and to redistribute
  this software is granted subject to the restriction that all copies
  made of this software must include this copyright notice in full.
  The author(s) makes no warranties or representations of any kind, either
  express or implied, including but not limited to implied warranties
  of merchantability or fitness for any particular purpose.
  All materials developed as a consequence of the use of this
  software shall duly acknowledge such use, in accordance with the usual
  standards of acknowledging credit in research.
 ***************************************************************************/ 

/**********************************************************************
 *                                                                    *
 *           IMPRESSION DE LEXEMES ET DE FORMES SYNTAXIQUES           *
 *                                                                    *
 **********************************************************************/

/*
 * $Log:	print.h,v $
 * Revision 1.2  89/09/05  17:42:14  seniak
 * *** empty log message ***
 * 
 * Revision 1.1  89/08/29  15:54:01  seniak
 * Initial revision
 * 
 */

extern void PrintLex(int, void*);
extern void PrintForm(form *);
extern void PrintDefinition(struct definition *);
extern void PrintVariableRef(struct variable_ref *);
extern void PrintVariableRefsList(list);
extern void PrintFunctionRef(struct function_ref *);
extern void PrintFunction(function *);
extern void PrintFunctions(list);
extern void PrintVariable(variable *);
extern void PrintVariables(list);
