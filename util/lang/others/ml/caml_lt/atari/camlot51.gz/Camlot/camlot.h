#!/bin/sh
# Camlot Launcher
# version 0.5
# Regis Cridlig 1993

