let Double = function f -> function x -> f (f x);;
let Quad  = Double Double  ;;
let Oct = Quad Quad;;
let Succ x = x + 1;;
print_int (Double Oct Succ 1); print_newline();;
