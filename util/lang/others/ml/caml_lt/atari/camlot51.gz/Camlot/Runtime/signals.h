/* signals.h */
/* version 0.5 */
/* Regis Cridlig 1991-1993 */

#ifndef _signals_
#define _signals_

extern volatile int signal_is_pending;
extern int in_blocking_section;
extern volatile obj_t signal_handler;
extern volatile int signal_number;

extern void execute_signal(void);
extern void enter_blocking_section(void);
extern void leave_blocking_section(void);

#endif

