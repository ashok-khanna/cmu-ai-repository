/* Identificateurs libres du code K2 */

#include <setjmp.h>

typedef int obj_t;

extern obj_t __ContinueValue;

#define KTRUE 1
#define KFALSE 0
#define KCONT(x) ((obj_t)x)
#define CCONT(x) (*(jmp_buf *)x)
#define KFUN(x) ((obj_t)x)
#define CFUN(x) (*(obj_t (*)())x)


/* Fonctions de librairie */

extern int print(obj_t);
