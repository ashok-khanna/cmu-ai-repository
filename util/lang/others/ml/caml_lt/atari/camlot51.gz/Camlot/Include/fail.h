/* fail.h */
/* version 0.5 */
/* Regis Cridlig 1991-1993 */

#ifndef _fail_
#define _fail_

#define OUT_OF_MEMORY_EXN   MLINT(8894219)   /* "exc","Out_of_memory" */
#define SYS_ERROR_EXN       MLINT(8750561)   /* "sys","Sys_error" */
#define FAILURE_EXN         MLINT(8873873)   /* "exc","Failure" */
#define INVALID_EXN         MLINT(1009200)   /* "exc","Invalid_argument" */
#define END_OF_FILE_EXN     MLINT(7190268)   /* "io","End_of_file" */
#define ZERO_DIVIDE_EXN     MLINT(6327108)   /* "int","Division_by_zero" */
#define BREAK_EXN           MLINT(2503673)   /* "sys","Break" */
#define NOT_FOUND_EXN       MLINT(1888770)   /* "exc","Not_found" */
#define UNIX_ERROR_EXN      MLINT(4865675)   /* "unix","Unix_error" */
#define GRAPHIC_FAILURE_EXN MLINT(5875768)   /* "graphics","Graphic_failure"*/
#define PARSE_FAILURE_EXN   MLINT(9271767)   /* "stream","Parse_failure" */

#ifdef __STDC__
extern void mlraise(obj_t);
extern void raise_with_tag(obj_t);
extern void raise_with_arg(obj_t tag,obj_t arg);
extern inline void raise_with_string(obj_t,unsigned char *);
extern void failwith(unsigned char*);
extern void invalid_argument(unsigned char *);
extern void raise_out_of_memory(void);
/*extern void os_error(void);*/
/*extern obj_t division_by_zero(void);*/ /* appele par Pccall */
#else
extern void mlraise();
extern void raise_with_tag();
extern void raise_with_arg();
extern inline void raise_with_string();
extern void failwith();
extern void invalid_argument();
extern void raise_out_of_memory();
/*extern void os_error(void);*/
/*extern obj_t division_by_zero(void);*/ /* appele par Pccall */
#endif

#endif /* _fail_ */
