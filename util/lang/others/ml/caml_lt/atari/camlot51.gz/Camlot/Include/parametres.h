/* $Header: /Nfs/radyr/usr11/rc136/Projet/GC/RCS/parametres.h,v 1.1 1992/09/03 21:14:21 rc136 Exp rc136 $ */
/* Auteur: Vincent Delacour (delacour@poly.polytechnique.fr) */

/* #define MONITOR_GC 
   #define DEBUG */

/* #define _GC_MONITOR_LOCALITY */

/**********************************************************************
 *                Parametres du gestionnaire memoire
 **********************************************************************/

#define PagePower 11  /* pages de 8K */

/* 
 * Strategie expansion & GC
 */


#define INITIAL_NPAGES           50   /* valait 50 */

#define MINIMUM_EXPANSION        50   /* valait 50 */
#define EXPANSION_FACTOR         1.4   /* valait 1.4 */
#define GCTHRESHOLD             250    /* valait 250 */

#ifndef USHRT_MAX
#      define USHRT_MAX 65535 
#endif
