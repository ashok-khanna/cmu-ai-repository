char version_string[] =
  "The Caml Light runtime system, version 0.6\n";
