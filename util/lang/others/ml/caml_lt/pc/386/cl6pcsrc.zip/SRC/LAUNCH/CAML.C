#include <stdio.h>
#include "driver.h"

char * stdlib;
char * opt = "";

main(argc, argv)
     int argc;
     char ** argv;
{
  int i;
  char * a;
  extern char * getenv();
  char * cmd;
  int status;

  stdlib = getenv("CAMLLIB");
  if (stdlib == NULL) {
    fprintf(stderr, "Variable CAMLLIB is undefined.\n");
    exit(2);
  }

  for (i = 1; i < argc; i++) {
    a = argv[i];
    if (eq(a, "-g") || eq(a, "-debug")) {
      reformat(&opt, "%s %s", opt, a);
    } else
    if (eq(a, "-I") || eq(a, "-include") || eq(a, "-O") || eq(a, "-open")) {
      reformat(&opt, "%s %s %s", opt, a, argv[++i]);
    } else
    if (eq(a, "-stdlib")) {
      stdlib = argv[++i];
    } else
    if (prefix(a, "-")) {
      fprintf(stderr, "Unknown option \"%s\", ignored\n", a);
    } else {
      fprintf(stderr, "I don't know what to do with file \"%s\", ignored\n",
              a);
    }
  }
  
  format(&cmd, "%s\\camltop -stdlib %s %s", stdlib, stdlib, opt);
  terminate("camlrun.exe", cmd);
  return 0;
}
