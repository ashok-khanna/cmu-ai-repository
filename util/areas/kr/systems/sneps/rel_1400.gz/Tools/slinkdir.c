/*
 * slinkdir.c - program to print out the directory a symbolic link points to
 *
 * $Author: snwiz $
 *
 * $Date: 1993/06/03 04:19:27 $
 *
 * $Log: slinkdir.c,v $
Revision 1.1  1993/06/03  04:19:27  snwiz
Initial revision

 * Revision 1.1  91/05/02  00:12:00  kensmith
 * Initial revision
 * 
 */

static char rcsid[] = "$Id: slinkdir.c,v 1.1 1993/06/03 04:19:27 snwiz Exp $";

#include <stdio.h>
#include <sys/param.h>

char *name, *rindex(), buf[MAXPATHLEN];
int i;

main(argc, argv)
	int argc;
	char *argv[];
{
	if ((name = rindex(argv[0], '/')) == NULL)
		name = argv[0];
	else
		name++;
	for (i = 1; i < argc; i++){
		if (readlink(argv[i], buf, MAXPATHLEN) < 0)
			perror(argv[i]);
		else
			printf("%s\n", buf);
	}
}

/*
 * usage() - print usage message
 */

usage()
{
	fprintf(stderr, "usage: %s slink [slink ...]\n", name);
	exit(1);
}
