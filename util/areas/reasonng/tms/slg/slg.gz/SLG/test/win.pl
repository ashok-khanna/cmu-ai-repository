
:- tabled win/1.

win(X) :- move(X,Y), \+win(Y).

move(a,a).
move(a,b).
move(b,a).
move(b,c).

