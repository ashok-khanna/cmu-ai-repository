:- default(tabled).
:- prolog same/2, e2/2.

p2(X,Y) :- e2(X,Y), \+dp2(X,Y).
dp2(X,Y) :- p2(X,Z), \+same(Y,Z).

same(X,X).

e2(1,a). e2(1,b). e2(1,c). e2(1,d).
e2(2,a). e2(2,b). e2(2,c). e2(2,d).
