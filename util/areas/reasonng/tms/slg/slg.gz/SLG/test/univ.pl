
:- tabled f/1, founded/1.

f(X) :- node(X), founded(X).
founded(X) <-- \+move(X,Y); founded(Y).

node(a). node(b). node(c).
move(a,b).
move(b,a).
move(b,c).

:- tabled col/1, color/1.

col(X) :- vertex(X), color(X).
color(X) <-- \+edge(X,Y); \+color(Y).

vertex(a). vertex(b). vertex(c). vertex(d).

edge(a,c). edge(a,d). edge(c,a). edge(c,b). edge(d,b).
