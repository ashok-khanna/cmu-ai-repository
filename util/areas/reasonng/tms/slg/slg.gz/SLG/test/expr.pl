
:- default (tabled).

expr --> term.
expr --> expr, ['+'], term.
expr --> expr, ['-'], term.

term --> factor.
term --> term, ['*'], factor.
term --> term, ['/'], factor.

factor --> [N], { number(N) }.
factor --> ['('], expr, [')'].
