
:- default (tabled).

s :- \+p, \+q, \+r.
p :- \+s, \+r, q.
q :- \+p, r.
r :- \+q, p.
