/*  PSBUG1.PL  */


resolve [p,s,r].

stm [].

holding(+)      => exec([use]).
over(+)         => exec([grab]).
can_see(+)      => move_towards(+).
