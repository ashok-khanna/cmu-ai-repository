/*  L1.PL  */


resolve [p,s,r].


stm [ likes(mary,wine) ].


stm_predicates all.


likes(mary,wine) => loves(john,mary).
likes(mary,beer) => loves(bill,mary).
loves(_,_) => exec([forward]), exec([right]).
