wander :-
    random_element( [[[left]],[[forward],[forward],[forward],[forward]]], E ),
    exec_list( E ).


exec_list( [] ) :- !.

exec_list( [A1|An] ) :-
    exec( A1 ),
    exec_list( An ).
