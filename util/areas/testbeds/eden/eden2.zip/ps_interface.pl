/*  PS_INTERFACE.PL  */


:- module ps_interface.


/*
SPECIFICATION
-------------
*/


/*
IMPLEMENTATION
--------------
*/


/*
Converting perceptions to STM.
------------------------------
*/


perceptions_to_stm( Vision, Inventory, Energy, FoodDirection, STM ) :-
    vision_to_list( Vision, VisionList ),
    (
        Inventory \= ' '
    ->
        List1 = [ hold(Inventory) | VisionList ]
    ;
        List1 = VisionList
    ),
    List = [ energy(Energy), smell(FoodDirection) | List1 ],
    list_to_stm( List, STM ).


:- endmodule.
