/*  MANUAL_BUG.PL  */


/*
This is the ``manual bug''. It has no intelligence of its own, but
simply reads and performs actions as you type them.

The prompts for actions are self-explanatory. All replies are one letter
long, and you must not hit RETURN after them.
*/


:- prolog_language(pop11).
needs manual_bug;
:- prolog_language(prolog).


manual_bug :-
    prolog_eval(apply(valof(manual_bug))).


/*
bugdead( _, rerun ).
*/
