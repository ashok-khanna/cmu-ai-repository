/*  TERMS.PL  */


:- library(record).


% copy(+Old,-New)
% Makes a fresh copy of the term Old. A bit hacky...

copy(Old, New) :-           % Altered to use data base
    recorda(copy,Old,Key),       % KJ  21-5-87
    recorded(copy,Mid,Key),
    erase(Key),
    !,
    New = Mid.
