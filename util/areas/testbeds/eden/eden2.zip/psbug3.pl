/*  PSBUG3.PL  */


resolve [p,s,r].

stm [].

holding(+)      => exec([use]).
over(+)         => exec([grab]).
can_see(+)      => move_towards(+).

1 prio thirst(T),T>20,can_see(w) => move_towards(w).
1 prio thirst(T),T>20,over(w)    => exec([use]).
