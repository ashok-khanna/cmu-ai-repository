/*  gbug5.PL  */


resolve [p,r].

stm [].

stm_predicates [].


heard( S )
=>
exec( S ).

not(heard(S))
=>
reply([please,type,something]),
exec([wait]).
