/*  AWM.PL  */


:- pop_load('awm_pl.p').

prolog.
