/*  PSBUG2.PL  */


resolve [p,s,r].

stm [].

holding(+)      => exec([use]).
over(+)         => exec([grab]).
can_see(+)      => move_towards(+).

can_see('1')    => move_towards('1').
over('1')       => exec([grab]).

can_see('S'), holding('1') => move_towards('S').
next_to('S'), holding('1') => turn_towards('S').
facing('S'), holding('1')  => exec([use]).
