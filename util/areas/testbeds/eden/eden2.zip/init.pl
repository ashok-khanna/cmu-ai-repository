:- prolog_language(pop11).


define ADD( dir, list );
    lvars dir, list;
    if not( member(dir,valof(list)) ) then
        dir :: valof(list) -> valof(list);
    endif;
enddefine;


ADD( 'eden$src:', "vedteachlist" );
ADD( 'eden$src:', "vedhelplist" );
ADD( 'eden$src:', "prologliblist" );
ADD( 'eden$src:', "prologliblist" );
ADD( 'eden$src:', "popliblist" );
ADD( 'eden$src:', "popuseslist" );
ADD( 'eden$src:', "vedteachlist" );
ADD( 'eden$src:', "vedhelplist" );

cancel ADD;


5000000 -> popmemlim;

vedvt100( false );

:- prolog_language(prolog).
