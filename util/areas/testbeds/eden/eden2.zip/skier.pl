/*  SKIER.PL  */


resolve [r].


stm [ wants(eddie,fun),
      had_lessons(eddie,178),
      max_pressups(eddie,50)
    ].


stm_predicates all.


is_a(Skier, beginner), wants(Skier, fun)
=>
suits(Skier, st_sartre).

is_a(Skier, beginner), wants(Skier, serious)
=>
suits(Skier, schloss_heidegger).

is_a(Skier, advanced), wants(Skier, serious)
=>
suits(Skier, chateau_derrida).

is_a(Skier, advanced), wants(Skier, fun)
=>
suits(Skier, wittgenstein_gladbach).

had_lessons(Skier, L), L < 30
=>
is_a(Skier, beginner).

had_lessons(Skier, L), L >= 30, has_fitness(Skier, poor)
=>
is_a(Skier, beginner).

had_lessons(Skier, L), L >= 30, has_fitness(Skier, good)
=>
is_a(Skier, advanced).

max_pressups(Skier, P), P < 10
=>
has_fitness(Skier, poor).

max_pressups(Skier, P), P >= 10
=>
has_fitness(Skier, good).

suits( _, _ ) => exec( [forward] ), exec( [right] ).
