/*  HOLIDAYBUG.PL  */                   


resolve [p,s,r].


stm [ mp,
      hot
    ].


@computer_hacker => @rich.
@management_consultant => @rich.
@mp => @rich.

@hairdresser => @poor.
@teacher => @poor.
@toilet_cleaner => @poor.

@poor => @near.
@rich => @far.

@near, @hot => @costa_del_sol, @done.
@near, @cold => @aberdeen, @done.
@far, @hot => @egypt, @done.
@far, @cold => @switzerland, @done.

@done => exec([forward]), exec([wait]).
