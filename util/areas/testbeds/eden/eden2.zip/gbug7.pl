/*  gbug7.PL  */


resolve [p,r].

stm [ goal(obey),
      reverse(right,left),
      reverse(left,right),
      reverse(forward,back),
      reverse(back,forward),

    ].

stm_predicates [stack,goal,reverse].


goal(obey),
heard([home])
=>
erase(goal(obey)),
goal(home).

goal(obey),
not(heard([home])),
heard([X])
=>
exec([X]),
stack(X)
.

goal(obey),
not(heard(_))
=>
reply([please,type,something]),
exec([wait]).


goal(home),
stack(S),
reverse(S,Rev)
=>
exec([Rev]).

goal(home),
not(stack(_))
=>
reply([i,am,home,!]),
exit_eden.
