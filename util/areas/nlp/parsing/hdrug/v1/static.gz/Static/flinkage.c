typedef unsigned long int TAGGED;
typedef long SP_INTEGER;
typedef double SP_FLOAT;

static __stub_0(t0)
   TAGGED t0;
{
  long arg0;
  int retval = 0;
  if(!SP_get_string(t0,&arg0)) goto fail;
  tk_init(arg0);
  retval = 1;
 fail:
  return retval;
}

static __stub_1(t0, t1)
   TAGGED t0, t1;
{
  long arg0;
  long arg1;
  int retval = 0;
  if(!SP_get_string(t0,&arg0)) goto fail;
  if(!SP_get_string(t1,&arg1)) goto fail;
  tk_option(arg0, arg1);
  retval = 1;
 fail:
  return retval;
}

static __stub_2(t0, t1)
   TAGGED t0, t1;
{
  long arg0;
  long arg1;
  int retval = 0;
  if(!SP_get_string(t0,&arg0)) goto fail;
  SP_show_term(&t1);
  arg1 = tcl_eval_string(arg0);
  if(!glue_make_integer(&t1,arg1)) goto fail;
  retval = 1;
 fail:
  SP_hide_term(&t1);
  return retval;
}

static __stub_3(t0)
   TAGGED t0;
{
  long arg0;
  int retval = 0;
  SP_show_term(&t0);
  arg0 = tk_num_main_windows();
  if(!glue_make_integer(&t0,arg0)) goto fail;
  retval = 1;
 fail:
  SP_hide_term(&t0);
  return retval;
}

static __stub_4(t0, t1)
   TAGGED t0, t1;
{
  long arg0;
  long arg1;
  int retval = 0;
  if(!SP_get_integer(t0,&arg0)) goto fail;
  SP_show_term(&t1);
  arg1 = Tk_DoOneEvent(arg0);
  if(!glue_make_integer(&t1,arg1)) goto fail;
  retval = 1;
 fail:
  SP_hide_term(&t1);
  return retval;
}

static __stub_5(t0, t1)
   TAGGED t0, t1;
{
  long arg0;
  long arg1;
  int retval = 0;
  if(!SP_get_integer(t0,&arg0)) goto fail;
  SP_show_term(&t1);
  arg1 = input_ready(arg0);
  if(!glue_make_integer(&t1,arg1)) goto fail;
  retval = 1;
 fail:
  SP_hide_term(&t1);
  return retval;
}

static __stub_6()
{
  int retval = 0;
  init();
  retval = 1;
 fail:
  return retval;
}

int (*(sp_pre_linkage[]))() = {
	__stub_0,
	__stub_1,
	__stub_2,
	__stub_3,
	__stub_4,
	__stub_5,
	__stub_6,
0};
char *sp_pre_map[] = {
	"tk_init",
	"tk_option",
	"tcl_eval_string",
	"tk_num_main_windows",
	"Tk_DoOneEvent",
	"input_ready",
	"init",
0};
