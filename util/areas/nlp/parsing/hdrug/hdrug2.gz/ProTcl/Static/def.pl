%% assumes that tk_path/1 and charsio_path/1 are defined

% from $(PROTCL)/foreign.pl
foreign(tk_init, c, tk_init(+string)).
foreign(tk_clear_options, c, tk_clear_options).
foreign(tk_option, c, tk_option(+string, +string)).
foreign(tcl_eval_string, c, tcl_eval_string(+string, -string, [-integer])).
foreign(tk_num_main_windows, c, tk_num_main_windows([-integer])).
foreign('Tk_DoOneEvent', c, tk_do_one_event(+integer, [-integer])).
foreign(input_ready, c, input_ready(+integer, [-integer])).

% from library(charsio)
% (redundant for Linux, neccessary for HP-UX)
foreign(init,init).

% from $(PROTCL)/foreign.pl
:- tk_path(Ofile), assertz(foreign_file(Ofile,
	[ tk_init,
	  tk_clear_options,
	  tk_option,
	  tcl_eval_string,
	  tk_num_main_windows,
	  'Tk_DoOneEvent',
	  input_ready
	] )).

% from library(charsio)
:- charsio_path(Ofile), assertz(foreign_file(Ofile,[init])).

	 
