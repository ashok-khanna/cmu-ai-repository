tcl_library('/usr/lib/X11R5.supplement').
tk_library('/usr/lib/X11R5.supplement').
tcl_tests('').
tk_tests('').
protcl_source('/users1/vannoord/src/ProTcl').
xlibsw('-L/usr/lib/X11R5 -lX11').
