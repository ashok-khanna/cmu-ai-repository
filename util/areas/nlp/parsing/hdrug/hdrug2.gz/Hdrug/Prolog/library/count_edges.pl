:- module( count_edges, [ count_edges/2,
	                  report_count_edges/1 ] ).

report_count_edges(Pred) :-
	count_edges(Pred,I),
	format("~w : ~w~n",[Pred,I]).

count_edges(Pred0,Int):-
	( Pred0=M:Pred -> true ; Pred0=Pred, M=user),
	findall(_A,M:Pred,As),
	length(As,Int).

