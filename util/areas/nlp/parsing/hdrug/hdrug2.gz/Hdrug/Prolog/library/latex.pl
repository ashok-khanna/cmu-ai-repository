%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                         %
% written by Gertjan van Noord                            %
% (C) 1993  all rights reserved                           %
%                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% auxiliaries for latex output
% used in fs_latex, tree_latex, term_latex, st_latex

:- module(latex,[ xdvi/0,
	          files/5,
		  start_docu/1,
		  end_docu/0,
		  latex_and_xdvi/0,
		  latex_cmd/0,
		  latex_and_dctree_and_latex_and_xdvi/0,

		  tex_tab/1,
		  tex_nl/0,
		  tex_end_line/0,
		  tex_begin_line/0,
		  tex_variable/1,
		  tex_dots/0,
		  tex_atom/1,
		  tx_atom/1,
		  tex_var/1,
		  tex_if/0
]).

:- use_module( library(concat), [ concat/3,
	                          concat_all/2,
	                          concat_all/3,
				  term_atom/2]).

:- use_module( library(flags) ).
:- use_module( library(lists),  [ 
	                          append/3 ]).
:- use_module( library(decons), [ prolog_conjunction/2 ] ).

:- use_module( library(env),    [ get_env_var/2 ]).

%%%%%%%%%%%%%%%%%%%
% main predicates %
%%%%%%%%%%%%%%%%%%%

% files used as input/output for latex and xdvi

dir(TmpDir) :-
	get_env_var('TMPDIR',TmpDir),!.
dir('/tmp').

dir0(Tmp) :-
	dir(Tmp0),
	concat(Tmp0,'/',Tmp).

files(A,B,C,D,E) :-
	files0(A,B,C,D,E),!.

files(Tex,Dvi,Tree,Tex0,Lab) :-
	dir0(Tmp),
	concat(Tmp,'hdrugaXXXXXX',First0),
	concat(Tmp,'hdrugbXXXXXX',Sec0),
	concat(Tmp,'hdrugcXXXXXX',Third0),
	unix(mktemp(First0,First)),
	unix(mktemp(Sec0,Sec)),
	unix(mktemp(Third0,Third)),
	concat(First,'.tex',Tex),
	concat(First,'.dvi',Dvi),
	concat(First,'.tree',Tree),
	concat(Sec,'.tex',Tex0),
	concat(Third,'.tex',Lab),
	asserta(files0(Tex,Dvi,Tree,Tex0,Lab)).

% the structures are embedded in a document, hence we set up the
% document:
start_docu(Tree) :-
        write('\documentstyle[matrix,12pt]{article}'),nl,
	(Tree == tree -> write('\input{tmaker}'),nl ; true ),
	write('\setlength{\parindent}{-100pt}'),nl,
        write('\addtolength{\textheight}{1000ex}'),nl,
	write('\begin{document}'),nl,
	write('\thispagestyle{empty}'),nl,
	write('\topmargin -100pt'),nl,
%%	write('\oddsidemargin -50pt'),nl,
	nl.

% and finish the document:
end_docu :-
        nl,write('\end{document}'),nl.

% starts xdvi 
xdvi :-
	flag(window,_,off),
	start_window_up.

shell_call0(Cmds) :-
	append([xterm,'-iconic','-e','sh -c "'],Cmds,Cmds1),
	append(Cmds1,['" &'],Cmds2),
	concat_all(Cmds2,Cmd,' '),
	unix(shell(Cmd)).


% starts xdvi if not started yet
start_window_up :-
	flag(window,on),!.
start_window_up :-
	files(_,Dvi,_,_,_),
	concat_all([xdvi,'-geometry 800x480+100+800','-paper a1',Dvi,' &'],
	           Cmd,' '),
	unix(shell(Cmd)),
	flag(window,_,on).

% starts latex and xdvi in one command to be sure that the dvi file exists!
latex_and_xdvi :-
	flag(window,on),
	!,
	latex_cmd.

latex_and_xdvi :-
	dir(Dir),
	files(Tex,Dvi,_,_,_),
	shell_call0(['( cd ',Dir,' ; ',latex,Tex,' );',
                    xdvi,'-geometry 800x480+100+800','-paper a1',Dvi]),
        flag(window,_,on).

latex_cmd :-
	dir(Dir),
	files(Tex,_,_,_,_),
	shell_call0(['( cd ',Dir,' ; ',latex,Tex,' )']).

latex_and_dctree_and_latex_and_xdvi :-
	flag(window,on),!,
	dir(Dir),
	files(Tex,_,_,Tex0,_),
	shell_call0(['( cd ',Dir,' ; ',
                    latex,Tex0,';',
                    dctree,Tex0,';',
                    latex,Tex,' )']).

latex_and_dctree_and_latex_and_xdvi :-
	files(Tex,Dvi,_,Tex0,_),
	dir(Dir),
	shell_call0(['( cd ',Dir,' ; ',
                    latex,Tex0,';',
                    dctree,Tex0,';',
                    latex,Tex,';',
		    xdvi,'-geometry 800x480+100+800','-paper a1',Dvi, ')']),
        flag(window,_,on).

%%% these are all supposed to be in mathematical mode !
tex_tab(0) :-
	!.
tex_tab(N0) :-
	write('~'),
	N is N0-1,
	tex_tab(N).

tex_nl :-
	tex_end_line,
	tex_begin_line.

tex_end_line :-
	(  flag(vspace,on) 
        -> write('$\\')
        ;  write('$')
        ),nl.

tex_begin_line :-
	write('$'),nl.

tex_variable(Term) :-
	write(Term), 
	nl.  % added for long lines

tex_dots :-
	write('\dots ').

tex_atom([]) :-
	!,
	write('[~]').
tex_atom(A) :-
	write(' \mbox{'),  % removed \it
	tx_atom(A),
	write('} '),
	nl.           % added to make lines not too long..

tx_atom(A) :-
	escape_chars(A,A2),
	write(A2).

escape_chars(A,A2):-
	term_atom(A,A1),
	name(A1,Chars),
	escape_l(Chars,Chars2),
	name(A2,Chars2).

escape_l([],[]).
escape_l([H|T],Out):-
	escape_c(H,Rest,Out),
	escape_l(T,Rest).

% 38: &
% 95: _
% 94: ^ replaced by $\uparrow$
% 92: \ replaced by $\backslash$
% 35: # replaced by \#
% 60: <
% 62: > replaced by $<$ and $>$   ($=36)
% 36: $ replaced by \$

% 92: \
escape_c(60,R,[36,60,36|R]) :- !.
escape_c(62,R,[36,62,36|R]) :- !.
escape_c(36,R,[92,36|R]) :- !.
escape_c(38,R,[92,38|R]) :- !.
escape_c(92,R,[36,92,98,97,99,107,115,108,97,115,104,36|R]) :-!.
escape_c(94,R,[36,92,117,112,97,114,114,111,119,36|R]) :- !.
escape_c(95,R,[92,95|R]) :- !.
escape_c(35,R,[92,35|R]) :- !.

% catch all:
escape_c(C,R,[C|R]).

tex_var(N) :-
	Letter is N mod 26 + 0'A,
	write('\mbox{'),put(Letter),write('}'),
	(   N>=26 ->
	    Rest is N//26, write('_{'),write(Rest),write('}')
	;   true
	).

tex_if :-
	write('{\mbox{\tt :-}}').

