%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                         %
% written by Gertjan van Noord                            %
% (C) 1993  all rights reserved                           %
%                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- module(latex_term, [ latex_term/1,
	                latex_term_clause/1,
                        latex_term_listing/1,
			tex_term/1
		      ]).

:- use_module([
	       library(prettyvars)    % to know what variables are single
	      ]).

:- use_module( library(concat), [ concat/3,
	                          concat_all/2,
	                          concat_all/3,
				  term_atom/2]).

:- use_module( library(flags) ).
:- use_module( library(lists),  [ member/2,
	                          append/3 ]).

:- use_module( library(env),    [ get_env_var/2 ]).

:- use_module( library(latex) ).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% latex output for ordinary prolog terms %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% latex_term/1,
% latex_term_clause/1,
% latex_term_listing/1

latex_term([H|T]) :-
	!,
	print_latex_term([H|T]).

latex_term(clause(H)) :-
	!,
	print_latex_term(clause(H)).

latex_term(clause(H,B)) :-
	!,
	print_latex_term(clause(H,B)).

latex_term(term(H)) :-
	!,
	print_latex_term(term(H)).

latex_term(listing(H)) :-
	!,
	print_latex_term(listing(H)).

latex_term(T) :-
	print_latex_term(term(T)).

latex_term_clause((H:-B)) :-
	!,
	print_latex_term(clause(H,B)).
latex_term_clause(H) :-
	print_latex_term(clause(H)).

latex_term_listing([L0|L]) :-
	print_latex_term(listing([L0|L])).

print_latex_term(Thing) :-
	flag(vspace,_,on),
	files(Tex,_,_,_,_),
	telling(Old), tell(Tex),
        start_docu(_),
        ( print_it(Thing), fail ; true ),   % no side effects.
        end_docu,
        told, tell(Old),
	latex_and_xdvi.

print_it([]).
print_it([H|T]) :-
	print_it(H),
	print_it(T).

print_it(term(T0)) :-
	write('\begin{flushleft}'),nl,       % added 21/7/94
	call_residue(copy_term(T0,T),_),
	prettyvars(T),
	tex_begin_line,
	write_goal(T, 1199, 0, Co),
	write_fullstop(Co),
	tex_end_line,
	write('\end{flushleft}').       % added 21/7/94

print_it(fs(T0)) :-
	write('\begin{flushleft}'),nl,       % added 21/7/94
	call_residue(copy_term(T0,T),_),
	prettyvars(T),
	tex_begin_line,
	write_goal(T, 1199, 0, Co),
	write_fullstop(Co),
	tex_end_line,
	write('\end{flushleft}').       % added 21/7/94

print_it(clause(H0)) :-
	write('\begin{flushleft}'),nl,       % added 21/7/94
	call_residue(copy_term(H0,H),_),
	prettyvars(H),
	tex_begin_line,
	portray_clause1(H, Co),
	write_fullstop(Co),
	tex_end_line,
	write('\end{flushleft}').       % added 21/7/94

print_it(clause(H0,B0)) :-
	write('\begin{flushleft}'),nl,       % added 21/7/94
	call_residue(copy_term(H0/B0,H/B1),_),
	ensure_prolog_conjunction(B,B1),
	prettyvars((H:-B)),
	tex_begin_line,
	portray_clause1((H:-B), Co),
	write_fullstop(Co),
	tex_end_line,
	write('\end{flushleft}').       % added 21/7/94

print_it(listing([H|T])) :-
	( H = (B:-C) -> print_it(clause(B,C)) ; print_it(clause(H))),
%%	nl,   %extra newline to make sure that a paragraph is started    removed 21/7/94
	print_it(listing(T)).

% This must be careful not to bind any variables in Clause.
portray_clause_l([]).
portray_clause_l([Clause|_]) :-
	prettyvars(Clause),
	tex_begin_line,
	portray_clause1(Clause, Co),
	write_fullstop(Co),
	tex_end_line,
	fail.
portray_clause_l([_|T]) :-
	portray_clause_l(T).

%%% changed the following so as to generate latex code...
%%% buggy.
%%% 

%% ADAPTED FROM:
%   File   : WRITE.PL
%   Author : Richard A. O'Keefe
%   Updated: 22 October 1984
%   Purpose: Portable definition of write/1 and friends.

% Priority 999 is o.k. if printed e.g. as elements of a list. /MC

%   maybe_paren(P, Prio, Char, Ci, Co)
%   writes a parenthesis if the context demands it.
%   Context = 2'000 for alpha
%   Context = 2'001 for quote
%   Context = 2'010 for other
%   Context = 2'100 for punct

maybe_paren(P, Prio, Lpar, '(', _, 2'100) :-
	P > Prio, !,
	prolog:'$display'(Lpar).
maybe_paren(_, _, Lpar, Lpar, C, C).

maybe_paren(P, Prio, _, 2'100) :-
	P > Prio, !,
	prolog:'$display'(')').
maybe_paren(_, _, C, C).

%   maybe_space(LeftContext, TypeOfToken)
%   generates spaces as needed to ensure that two successive
%   tokens won't run into each other.

maybe_space(Ci, Co) :-
	(   Ci\/Co<2'100, Ci#Co<2'010 -> tex_tab(1)  %%put(0' )
	;   true
	).

/*
sticky_contexts(alpha, alpha).
sticky_contexts(quote, quote).
sticky_contexts(other, other).
sticky_contexts(alpha, quote).
sticky_contexts(quote, alpha).
*/

%   write_out(Term, SynStyle, LexStyle, Prio, PrePrio, Depth, Lpar, Ci, Co)
%   writes out a Term in given SynStyle, LexStyle
%   at nesting depth Depth
%   in a context of priority Priority (that is, expressions with
%   greater priority must be parenthesized), 
%   and prefix operators =< PrePrio must be parenthesized,
%   where the last token to be
%   written was of type Ci, and reports that the last token it wrote
%   was of type Co.

write_out(Term, _, _, _, _, _, _, Ci, 2'000) :-
	var(Term), !,
	maybe_space(Ci, 2'000),
	tex_variable(Term).
write_out('$VAR'(N), SynStyle, LexStyle, _, _, Depth, _, Ci, Co) :- !,
	Depth1 is Depth+1,
	write_VAR(N, SynStyle, LexStyle, Depth1, Ci, Co).
write_out(_, print(Limit), _, _, _, Depth, _, Ci, 2'010) :-
	Depth >= Limit, !,
	maybe_space(Ci, 2'010),
	tex_dots.
/*
write_out(Term, print(_), _, _, _, _, _, _, 2'000) :-
	(   \+call_user_def(portray(Term), user) ->
	    fail		 % portray might bind variables
	;   true
	), !.
*/
write_out(Atom, _, LexStyle, _, PrePrio, _, Lpar, _, 2'100) :-
	atom(Atom),
	prolog:current_prefixop(Atom, P, _),
	P =< PrePrio, !,
	prolog:'$display'(Lpar),
	write_atom(LexStyle, Atom, 2'100, _),
	put(0')).
write_out(Atom, _, LexStyle, _, _, _, _, Ci, Co) :-
	atom(Atom), !,
	write_atom(LexStyle, Atom, Ci, Co).
write_out(N, _, _, _, _, _, _, Ci, 2'000) :-
	number(N), !,
	(   N < 0 -> maybe_space(Ci, 2'010)
	;   maybe_space(Ci, 2'000)
	),
	write(N).
write_out(Term, noop, LexStyle, _, _, Depth, _, Ci, 2'100) :-
	functor(Term, Atom, Arity), !,
	write_atom(LexStyle, Atom, Ci, _),
	Depth1 is Depth+1,
	write_args(0, Arity, Term, noop, LexStyle, Depth1).
write_out({Term}, SynStyle, LexStyle, _, _, Depth, _, _, 2'100) :- !,
%%	put(0'{),
        write('\{ '),
	Depth1 is Depth+1,
	write_out(Term, SynStyle, LexStyle, 1200, 0, Depth1, '(', 2'100, _),
	write('\} ').
%%	put(0'}).
write_out([Head|Tail], SynStyle, LexStyle, _, _, Depth, _, _, 2'100) :- !,
	put(0'[),
	Depth1 is Depth+1,
	write_out(Head, SynStyle, LexStyle, 999, 0, Depth1, '(', 2'100, _),
	write_tail(Tail, SynStyle, LexStyle, Depth1).
write_out((A,B), SynStyle, LexStyle, Prio, _, Depth, Lpar, Ci, Co) :- !,
	%  This clause stops writeq quoting commas.
	Depth1 is Depth+1,
	maybe_paren(1000, Prio, Lpar, Lpar1, Ci, C1),
	write_out(A, SynStyle, LexStyle, 999, 0, Depth1, Lpar1, C1, _),
	put(0',),
	write_out(B, SynStyle, LexStyle, 1000, 1000, Depth1, '(', 2'100, C2),
	maybe_paren(1000, Prio, C2, Co).
write_out(Term, SynStyle, LexStyle, Prio, PrePrio, Depth, Lpar, Ci, Co) :-
	functor(Term, F, N),
	Depth1 is Depth+1,
	write_out(N, F, Term, SynStyle, LexStyle, Prio, PrePrio, Depth1, Lpar, Ci, Co).

write_out(1, F, Term, SynStyle, LexStyle, Prio, _, Depth, Lpar, Ci, Co) :-
	prolog:current_postfixop(F, P, O), !,
	(prolog:current_infixop(F, _, _, _) -> O1=1200; O1=O),
	maybe_paren(O1, Prio, Lpar, Lpar1, Ci, C1),
	arg(1, Term, A),
	write_out(A, SynStyle, LexStyle, P, 1200, Depth, Lpar1, C1, C2),
	write_atom(LexStyle, F, C2, C3),
	maybe_paren(O1, Prio, C3, Co).
write_out(1, F, Term, SynStyle, LexStyle, Prio, PrePrio, Depth, Lpar, Ci, Co) :-
	F \== -,
        prolog:current_prefixop(F, O, P), !,
	(PrePrio=1200 -> O1 is P+1; O1=O),	% for "fy X yf" etc. cases
	maybe_paren(O1, Prio, Lpar, _, Ci, C1),
	write_atom(LexStyle, F, C1, C2),
	arg(1, Term, A),
	write_out(A, SynStyle, LexStyle, P, P, Depth, ' (', C2, C3),
	maybe_paren(O1, Prio, C3, Co).
write_out(2, F, Term, SynStyle, LexStyle, Prio, PrePrio, Depth, Lpar, Ci, Co) :-
        prolog:current_infixop(F, P, O, Q), !,
	(PrePrio=1200 -> O1 is Q+1; O1=O),	% for "U xfy X yf" etc. cases
	maybe_paren(O1, Prio, Lpar, Lpar1, Ci, C1),
	arg(1, Term, A),
	write_out(A, SynStyle, LexStyle, P, 1200, Depth, Lpar1, C1, C2),
	write_atom(LexStyle, F, C2, C3),
	arg(2, Term, B),
	write_out(B, SynStyle, LexStyle, Q, Q, Depth, '(', C3, C4),
	maybe_paren(O1, Prio, C4, Co).
write_out(N, F, Term, SynStyle, LexStyle, _, _, Depth, _, Ci, 2'100) :-
	write_atom(LexStyle, F, Ci, _),
	write_args(0, N, Term, SynStyle, LexStyle, Depth).

write_VAR(N, SynStyle, _, _, Ci, 2'000) :-
	integer(N), N >= 0,
	SynStyle \== noop, !,
	maybe_space(Ci, 2'000),
	tex_var(N).

write_VAR(String, SynStyle, _, _, Ci, Co) :-
	nonvar(String),
	(   prolog:'$atom_chars'(Atom, String) -> true
	;   Atom = String
	),
	atom(Atom),
	SynStyle \== noop, !,
	write_atom(noquote,Atom,Ci,Co).
write_VAR(X, SynStyle, LexStyle, Depth, Ci, 2'100) :-
	write_atom(LexStyle, '$VAR', Ci, _),
	write_args(0, 1, '$VAR'(X), SynStyle, LexStyle, Depth).

write_atom(noquote, Atom, Ci, Co) :-
	prolog:'$atom_mode'(Atom, Co),
	maybe_space(Ci, Co),
	tex_atom(Atom).
write_atom(quote, Atom, Ci, Co) :-
	prolog:'$atom_mode'(Atom, Co),
	maybe_space(Ci, Co),
	tex_atom(Atom).

%   write_args(DoneSoFar, Arity, Term, SynStyle, LexStyle, Depth)
%   writes the remaining arguments of a Term with Arity arguments
%   all told in SynStyle, LexStyle, given that DoneSoFar have already been written.

write_args(N, N, _, _, _, _) :- !,
	put(0')).
write_args(I, _, _, print(Limit), _, Depth) :-
	Depth >= Limit, !,
	write_args(I, Depth),
	tex_dots,
	put(0')).
write_args(I, N, Term, SynStyle, LexStyle, Depth) :-
	write_args(I, Depth),
	J is I+1,
	arg(J, Term, A),
	write_out(A, SynStyle, LexStyle, 999, 0, Depth, '(', 2'100, _),
	write_args(J, N, Term, SynStyle, LexStyle, Depth).

write_args(0, _) :- !, put(0'().
write_args(_, 0) :- !, prolog:'$display'(', ').
write_args(_, _) :- put(0',).



%   write_tail(Tail, SynStyle, LexStyle, Depth)
%   writes the tail of a list of a given SynStyle, LexStyle, Depth.

write_tail(Var, _, _, _) :-			%  |var]
	var(Var), !,
	put(0'|),
	prolog:'$write'(Var),
	put(0']).
write_tail([], _, _, _) :- !,			%  ]
	put(0']).
write_tail(_, print(Limit), _, Depth) :-
	Depth >= Limit, !,
	put(0'|),
	tex_dots,
	put(0']).
write_tail([Head|Tail], SynStyle, LexStyle, Depth) :- !, %  ,Head tail
	put(0',),
	write_out(Head, SynStyle, LexStyle, 999, 0, Depth, '(', 2'100, _),
	Depth1 is Depth+1,
	write_tail(Tail, SynStyle, LexStyle, Depth1).
write_tail(Other, SynStyle, LexStyle, Depth) :-	%  |junk]
	put(0'|),
	write_out(Other, SynStyle, LexStyle, 999, 0, Depth, '(', 2'100, _),
	put(0']).

portray_clause1(:-(Command), Co) :-
	functor(Command, Key, 1),
	current_op(_, fx, Key), !,
	arg(1, Command, Body),
	'list clauses'(Body, :-(Key), 8, Co).
portray_clause1((Pred:-true), Co) :- !,	
	 write_goal(Pred, 1199, 0, Co).
portray_clause1((Pred:-Body), Co) :- !,	
	write_goal(Pred, 1199, 1200, _),
	'list clauses'(Body, 0, 8, Co).
portray_clause1((Pred-->Body), Co) :- !,
	write_goal(Pred, 1199, 1200, _),
	'list clauses'(Body, 2, 8, Co).
portray_clause1(Pred, Co) :-
	write_goal(Pred, 1199, 0, Co).


write_goal(M:Goal, Prio, PrePrio, C) :- !,
	write_out(M:Goal, op, quote, Prio, PrePrio, -2, '(', 2'100, C).
write_goal(Goal, Prio, PrePrio, C) :-
	write_out(Goal, op, quote, Prio, PrePrio, -1, '(', 2'100, C).

write_fullstop(Ci) :-
	maybe_space(Ci, 2'010),
	put(0'.), tex_nl.


'list clauses'((A,B), L, D, Co) :- !,
	'list clauses'(A, L, D, _),
	'list clauses'(B, 1, D, Co).
'list clauses'((A;B), L, D, 2'100) :- !,
	'list magic'(L, D),
	'list disj'(A, 3, D),
	'list disj'(B, D).
'list clauses'((A->B), L, D, 2'100) :- !,
	'list magic'(L, D),
	E is D+4,
	'list clauses'(A, 3, E, _),
	'list clauses'(B, 5, E, _),
	tex_nl, tex_tab(D),
	put(0')).
'list clauses'(!, 0, _, 2'100) :- !,
	prolog:'$display'(' :- !').
'list clauses'(!, 1, _, 2'100) :- !,
	prolog:'$display'(', !').
'list clauses'(!, 2, _, 2'100) :- !,
	prolog:'$display'(' --> !').
'list clauses'(Goal, L, D, Co) :- !,
	'list magic'(L, D),
	write_goal(Goal, 999, 0, Co).


'list magic'(0, D) :-
	tex_if,
	tex_nl, tex_tab(D).
'list magic'(1, D) :-
	put(0',),
	tex_nl, tex_tab(D).
'list magic'(2, D) :-
	prolog:'$display'(' -->'),
	tex_nl, tex_tab(D).
'list magic'(3, _) :-
	prolog:'$display'('(   ').
'list magic'(4, _) :-
	prolog:'$display'(';   ').
'list magic'(5, D) :-
	prolog:'$display'(' ->'),
	tex_nl, tex_tab(D).
'list magic'(:-(Key), D) :-
	tex_if,
	prolog:'$write'(Key),
	tex_nl, tex_tab(D).

'list disj'((A;B), D) :- !,
	'list disj'(A, 4, D),
	'list disj'(B, D).
'list disj'(Conj, D) :-
	'list disj'(Conj, 4, D),
	put(0')).

'list disj'((A->B), L, D) :- !,
	E is D+4,
	'list clauses'(A, L, E, _),
	'list clauses'(B, 5, E, _),
	tex_nl, tex_tab(D).
'list disj'(A, L, D) :-
	E is D+4,
	'list clauses'(A, L, E, _),
	tex_nl, tex_tab(D).


% convert only if not already converted..
ensure_prolog_conjunction(A,B) :-
	prolog_conjunction(A,B),
	!.
ensure_prolog_conjunction(A,A).

tex_term(Val) :-
	latex_term:write_goal(Val,1199,0,_Co).    % cf below!
