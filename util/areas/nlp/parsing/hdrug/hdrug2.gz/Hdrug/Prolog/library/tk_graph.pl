:- module(tk_graph, [ tk_graph/1,
	              tk_graph/2 ]).

:- use_module(library(concat)).



tk_graph(List) :-
	tk_graph(List,[]).

tk_graph(List,Options) :-
	concat(start_graph,' .graph',Cmd),
	user:tcl_eval(Cmd),
	tk_graph_options(Options,'.graph.g'),
	tk_graph0(List,'.graph.g',1).

tk_graph_options([],_).
tk_graph_options([H|T],W) :-
	concat_all([W,' ',H],Cmd),
	user:tcl_eval(Cmd),
	tk_graph_options(T,W).

tk_graph0([],_,_).
tk_graph0([H|T],W,I) :-
	tk_graph1(H,W,I),
	I2 is I + 1,
	tk_graph0(T,W,I2).

tk_graph1(t(Name,List),W,I) :-
	show_ith(I,Affix),
	concat_all(['catch {',W,' element create ',Name,Affix,'}'],Cmd1),
	user:tcl_eval(Cmd1),
	concat_pairs(List,'',Pairs),
	concat_all([W,element,append,Name,'{',Pairs,'}'],Cmd2,' '),
	user:tcl_eval(Cmd2).

show_ith(1,' -symbol line -dashes 4').
show_ith(2,' -symbol square').
show_ith(3,' -symbol circle').
show_ith(4,' -symbol diamond').
show_ith(5,' -symbol plus').
show_ith(6,' -symbol cross').
show_ith(7,' -symbol splus').
show_ith(8,' -symbol scross').

show_ith(N,' -symbol line') :-
	N > 8.

/*
test0 :-
	tk_graph([t(a,[1/1,2/3,3/8,4/25]),
                  t(b,[1/1,2/3,3/4,4/5])]).


test :-
	tk_graph([t(a,[1/1,2/3,3/8,4/25]),
                  t(b,[1/1,2/3,3/4,4/5]),
		  t(c,[0/2,2/4,4/6,6/8,8/10]),
		  t(d,[1/2,2/2,3/2,4/2,5/2])]).
*/

concat_pairs([],A,A).
concat_pairs([X/Y|T],A0,A) :-
	concat_all([A0,X,Y],A1,' '),
	concat_pairs(T,A1,A).
