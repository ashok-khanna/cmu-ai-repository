%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                         %
% written by Gertjan van Noord                            %
% (C) 1993  all rights reserved                           %
%                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- module(latex_tree, [ latex_tree/2
		      ]).

:- use_module(library(latex)).

:- use_module(library(latex_term),[tex_term/1]).

:- use_module([
               library(gen_sym),
	       library(prettyvars)    % to know what variables are single
	      ]).

:- use_module( library(concat), [ concat/3,
	                          concat_all/2,
	                          concat_all/3,
				  term_atom/2]).

:- use_module( library(feature) ).

:- use_module( library(flags) ).
:- use_module( library(lists),  [ member/2,
	                          append/3 ]).

:- use_module( library(p_tree), [tree_def_to_tree/3]).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% T R E E S  with   T R E E M A K E R %%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% for the Treemaker package we need to do more complex things:
%  - write mother file that calls .tdf file and defines new commands
%  - latex mother file
%  - dctree
%  - write mother file that calls .tex file
%  - latex mother file again
%  - xdvi it

% tree(Label,_,ListOfDs)
%
%
%
% latex_tree(+Mode,+Tree)

:- initialize_flag(nodeskip,90).

% you can play around with this flag if your trees don't look nice,
% or if latex even fails. Larger numbers allow for more complex nodes,
% i.e. nodes with more vertical height
% If you're nodes are simple atoms, then 30 or 45 is a good choice.

latex_tree(Kind,Tree0) :-
	user:graphic_path(Kind,Tree0,Tree1),
	tree_def_to_tree(Kind,Tree1,Tree),
	latex_tree0(Kind,Tree),
	!.  % cut, because otherwise never ending
            % series of shells, if there is a bug in 
            % tree_def_to_tree (i.e. in graphic tree
            % definitions).

latex_tree0(Kind,Tree0) :-
	(  Kind = matrix(_)
        -> shorten_tree(Tree0,Tree1),
	   prettyvars(Tree1,0,No),
 	   feature:change(Tree1,Tree2,[],_,No,_)
        ;  true
        ),
	flag(vspace,_,off),
	files(TexFile,_,TreeFile,TexFile0,LabelFile),
	telling(Old), 

        tell(LabelFile),
	(  Kind = matrix(_)
        -> define_labels_fs(Tree2,Tree)
        ;  define_labels(Tree0,Tree)
        ),
	told, 

	tell(TexFile),
	input_cmd(LabelFile),
        start_docu(tree), 
        print_tree_second(TreeFile), 
        end_docu,
	told, 

	tell(TexFile0),
	input_cmd(LabelFile),
        start_docu(tree),
        print_tree_first(Tree,TreeFile),
        end_docu,
	told, 

	tell(Old),
        latex_and_dctree_and_latex_and_xdvi.

input_cmd(File) :-
	write('\input{'),write(File),write('}'),nl.

gen_cmd_name(Name) :-
	gen_atom(Name0),
	concat('\',Name0,Name).

% each label is defined as a seperate command - in order to get no errors
define_labels(tree(L0,_,Ds0),tree(L,_,Ds)) :-
	define_label(L0,L),
	define_label_ds(Ds0,Ds).

define_label_ds([],[]).
define_label_ds([H0|T0],[H|T]) :-
	define_labels(H0,H),
	define_label_ds(T0,T).

define_label(L,Cmd) :-
	gen_cmd_name(Cmd),
	write('\long\def'),
	write(Cmd),
	write('{'),
	tree_label(L),      % eg turn into feature structure...
	write('}'),nl.

define_labels_fs(_/_=[a('TREE',_,L0,Ds0)],tree(L,_,Ds)) :-
	define_label_fs(L0,L),
	define_label_ds_fs(Ds0,Ds).

define_label_ds_fs([],[]).
define_label_ds_fs([H0|T0],[H|T]) :-
	define_labels_fs(H0,H),
	define_label_ds_fs(T0,T).

define_label_fs(L,Cmd) :-
	gen_cmd_name(Cmd),
	write('\long\def'),
	write(Cmd),
	write('{'),
	tree_label_fs(L),      % eg turn into feature structure...
	write('}'),nl.

tree_label(A) :-
	user:tree_label(A),
	!.
tree_label(A) :-
	write('$ '), tex_term(A), write(' $'), nl.

tree_label_fs(A) :-
	feature:write_it_fs_latex(fs(A)).

print_tree_first(Tree,File0) :-
	latex:dir0(Path),
	name(Path,PathStr),
	name(File0,File0Str),
	append(PathStr,FileStr,File0Str),
	name(File,FileStr),
	flag(nodeskip,NodeSkip),
	write('\nodeskip{'),
	write(NodeSkip),
	write('pt}'),nl,
	write('\outputquality{low}'),nl,
        write('\opentree{'),write(File),write('}'),nl,
	print_tree(Tree).

print_tree(tree(L,_,[])) :-
	write('\leaf{'),
	write('\noexpand'),write(L),
	write('}'),nl.

print_tree(tree(L,_,[H|T])) :-
	write('\tree{'),
	write('\noexpand'),write(L),
	write('}'),nl,
	print_tree_ds([H|T]),
	write('\endtree'),
	nl.

print_tree_ds([]).
print_tree_ds([H|T]) :-
	print_tree(H),
	print_tree_ds(T).

print_tree_second(File) :-
	write('\input{'),
	write(File),
	write('}'),
	nl.

tt :-
	latex_tree(tree(s,_,[ tree(np,_,[]), tree(vp,_,[tree(v,_,[])])  ])).




shorten_tree(tree(L0,M,Ds0),tree(L,M,Ds)) :-
	shorten_label(L0,L),
	shorten_ds(Ds0,Ds).

shorten_ds([],[]).
shorten_ds([H0|T0],[H|T]) :-
	shorten_tree(H0,H),
	shorten_ds(T0,T).

shorten_label(V0,V) :-
	var(V0),
	!,
	V0=V.
shorten_label(V0,V) :-
	user:shorten_label(V0,V),
	!.
shorten_label(L,L).

