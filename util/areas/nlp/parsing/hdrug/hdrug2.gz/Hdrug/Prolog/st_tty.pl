:- module(st_tty, [ print_table/0,
	            print_table_add/0,
		    add_info/1
		  ]).

:- use_module(library(lists), [member/2]).
:- use_module(library(flags)).

print_table :-
	setof(table_entry(A,B,C,D,E,F),user:table_entry(A,B,C,D,E,F),Table),
	( member(El,Table),
	  write(El),nl,
	  fail
        ; true).

print_table_add :-
	setof(T,add_info(T),Table),
	( member(El,Table),
	  write(El),nl,
	  fail
        ; true).

add_info(t(Length,Av,Parser)):-
	member_flag(parser_mode,Parser),
	setof(Time,Nm^Am^Ed^(user:table_entry(Nm,Length,Am,Time,Parser,Ed),\+Am=space_out),Times),
	sum_list(Times,0,Sum),
	length(Times,Len),
	Av is Sum/Len.

sum_list([],T,T).
sum_list([H|T],C0,C):-
	C1 is H + C0,
	sum_list(T,C1,C).

