%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                         %
% written by Gertjan van Noord                            %
% (C) 1994                                                %
%                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%						          %
% TK Printer of terms representing feature structures, as %
% defined in package feature.pl / c_feature.pl            %
%                                                         %
% added: trees of such animals for ftag                   %
%                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



:- use_module(library(prettyvars)).
:- use_module(library(decons), [ prolog_conjunction/2 ] ).
:- use_module(library(lists),  [ member/2,
	                         append/3 ]).

:- use_module(library(concat)).
% tk_fs/1

tk_fs(Thing0) :-
	call_residue(copy_term(Thing0,Thing1),Cons0),
	user:rewrite_body(Cons0,[],Cons,[]),  % note: from link_clause.pl!!
	add_cons_tk(Thing1,Cons,Thing2),
	prettyvars(Thing2,0,No),
	change_it_tk(Thing2,Thing,No),
	write_it_tk(Thing).

add_cons_tk(fs(X),_,fs(X)).
add_cons_tk(fs(X,_),_,fs(X)).

change_it_tk(fs(FS0),fs(FS),No) :-
	change(FS0,FS,[],_Out,No,_OutNo).

write_it_tk(fs(_/n=FS)) :-
	user:tcl_eval('start_fs .v'),  % gives back .v.fs.f
	ppl_tk(FS,'.v.fs.f','').

pp_tk(_Var/n=FS,W,Aff):-
	!,
        ppl_tk(FS,W,Aff).

pp_tk(Var/_='R',W,Aff):-
        !,
        write_var_tk(Var,W,Aff).

pp_tk(Var/y=[],W,Aff):-
        !,
        write_var_tk(Var,W,Aff).

pp_tk(Var/y='$VAR'(_),W,Aff):-
	!,
        write_var_tk(Var,W,Aff).

pp_tk(Var/y=FS,W,Aff):-
        write_var_tk(Var,W,Aff),
	ppl_tk(FS,W,Aff).

%% defined in p_feature:
%% do_not_print(_Var/n='$VAR'(_)).

ppl_tk([a(_Att,Thing)|Rest],W,Aff):-
	do_not_print(Thing),!,
	ppl_tk(Rest,W,Aff).

ppl_tk([a(type,Types)|T],W,Aff):-
	all_empty(T),
	!,
	write_as_conj(Types,PTypes),
	write_constant_tk(PTypes,W,Aff).

ppl_tk([a('BOOLEAN',_Type,Val)|T],W,Aff):-
	all_empty(T),
	!,
	give_boolean_type(Val,Exp),
	write_constant_tk(Exp,W,Aff).

ppl_tk([a('UNTYPED',_Att,Val)|T],W,Aff):-
	all_empty(T),!,
	write_constant_tk(Val,W,Aff).

ppl_tk([a(type,['.']),a(_,Head),a(_,Tail)],W,Aff) :-
	ppl_list(Head,Tail,W,Aff).

ppl_tk([a(type,Types)|T],W,Aff):-
	!,
	write_as_conj(Types,PTypes),
	write_type_tk(PTypes,W,W2,Aff),
	ppl_tk2(T,W2,Aff).

ppl_tk([a('BOOLEAN',_Type,Val)|T],W,Aff):-
	!,
	give_boolean_type(Val,Exp),
	write_type_tk(Exp,W,W2,Aff),
	ppl_tk2(T,W2,Aff).

ppl_tk([a('UNTYPED',_Att,Val)|T],W,Aff):-
	!,
	write_type_tk(Val,W,W2,Aff),
	ppl_tk2(T,W2,Aff).

%ppl_tk([a('UNTYPED',_,_Val)|T],Tab):-
%	!,      % should have been catched by catch_print_error
%	write(' (error....)'),
%	ppl2_tk(T,Tab).

ppl_tk([a(Att,FS)|T],W,Aff):-
        !,
        write_att_tk(Att,W,NewW,Aff),
        pp_tk(FS,NewW,''),
        ppl2_tk(T,W,Aff).

%%ppl_tk([a('TREE',Mark,Cat,Ds)|T],Tab):-
%	append(Tab,['/'],Tabt),
%	mrk_t(Tabt,Mark,Tab2),
%	pp_tk(Cat,Tab2),
%	ppl_tkist(Ds,1,Tab2),
%	ppl2_tk(T,Tab).

ppl_tk([],_,_).

%% ??
%% ppl_tk('$VAR'(No),W) :- write('$VAR'(No)).  % changed gj 21/7/93 5/11/93


ppl_tk2([a(_Att,Thing)|Rest],W,Aff):-
	do_not_print(Thing),!,
	ppl_tk2(Rest,W,Aff).

ppl_tk2([a(Att,FS)|T],W,Aff):-
        !,
        write_att_tk(Att,W,W2,Aff),
        pp_tk(FS,W2,''),
        ppl_tk2(T,W,Aff).

ppl_tk2([],_W,_).


ppl_list(Head,Tail,W,Aff) :-
	write_start_list_tk(W,W2,Aff),
	ppx(Head,W2,1),
	ppl_list0(Tail,W2,2),
	write_end_list_tk(W2).

ppl_list0(V/y='R',W,No) :-
	!,
	write_bar_list_tk(W),
	ppx(V/y='R',W,No).

ppl_list0(V/YN='$VAR'(_),W,No) :-
	!,
	write_bar_list_tk(W),
	ppx(V/YN='$VAR'(_),W,No).
	
ppl_list0(_Var/_YN=[a(type,[[]])],_,_) :-
	!.

ppl_list0(_Var/_YN=[a(type,['.']),a(_,Head),a(_,Tail)],W,No0) :-
	write_comma_list_tk(W,No0),
	ppx(Head,W,No0),
	No is No0 + 1,
	ppl_list0(Tail,W,No).

ppx(ListEl,W,No) :-
%%	concat_all([W0,'.',No],W),
	pp_tk(ListEl,W,No),!.

ppx(_,W,No) :-
	write_underscore_tk(W,No).

write_att_tk(Att0,W,NewW,Aff) :-
        % frame W.Att
        % pack W.Att
	% label W.Att.attl -text Att
	% pack W.Att.attl -side left
	tk_atom(Att0,Att),
	concat(Att,':',AttText),
	concat_all([W,'.',Att,Aff],NewW),
	concat('frame ',NewW,Cmd1),
	concat_all(['pack ',NewW,' -anchor w'],Cmd2),
	concat_all(['label ',NewW,'.attl -text ',AttText],Cmd3),
	concat_all(['pack ',NewW,'.attl -side left'],Cmd4),
	user:tcl_eval(Cmd1),
	user:tcl_eval(Cmd2),
	user:tcl_eval(Cmd3),
	user:tcl_eval(Cmd4).

write_end_list_tk(W) :-
	% label W.rr -text ]
	% pack W.rr -side left
	tk_atom(' ]',Text),
	concat_all(['label ',W,'.rr -text ',Text],Cmd1),
	user:tcl_eval(Cmd1),
	concat_all(['pack ',W,'.rr -side left'],Cmd2),
	user:tcl_eval(Cmd2).

write_bar_list_tk(W) :-
	% label W.bb -text |
	% pack W.bb -side left
	tk_atom(' | ',Text),
	concat_all(['label ',W,'.bb -text ',Text],Cmd1),
	user:tcl_eval(Cmd1),
	concat_all(['pack ',W,'.bb -side left'],Cmd2),
	user:tcl_eval(Cmd2).

write_comma_list_tk(W,No) :-
	% label W.ccNo -text |
	% pack W.ccNo -side left
	tk_atom(' , ',Text),
	concat_all(['label ',W,'.cc',No,' -text ',Text],Cmd1),
	user:tcl_eval(Cmd1),
	concat_all(['pack ',W,'.cc',No,' -side left'],Cmd2),
	user:tcl_eval(Cmd2).

write_underscore_tk(W,No) :-
	% label W.uuNo -text _
	% pack W.uuNo -side left
	tk_atom(' _ ',Text),
	concat_all(['label ',W,'.uu',No,' -text ',Text],Cmd1),
	user:tcl_eval(Cmd1),
	concat_all(['pack ',W,'.uu',No,' -side left'],Cmd2),
	user:tcl_eval(Cmd2).

write_start_list_tk(W,W2,Aff) :-
	% frame W.val
        % pack W.val -side left
        % label W.val.ll -text [
	% pack W.val.ll -side left
	concat_all([W,'.v_a_l',Aff],W2),
	tk_atom('[ ',Text),
	concat_all(['frame ',W2,' -relief flat'],Cmd1),
	user:tcl_eval(Cmd1),
	concat_all(['pack ',W2,' -side left'],Cmd2),
	user:tcl_eval(Cmd2),
	concat_all(['label ',W2,'.ll -text ',Text],Cmd3),
	user:tcl_eval(Cmd3),
	concat_all(['pack ',W2,'.ll -side left'],Cmd4),
	user:tcl_eval(Cmd4).

write_type_tk(Type0,W,W2,Aff) :-
        % frame W.val
        % pack W.val -side left
	% label W.val.typel -text Type
	% pack W.val.typel
	tk_atom(Type0,Type),
	concat_all([W,'.v_a_l',Aff],W2),
	concat_all(['frame ',W2,' -relief ridge -bd 4'],Cmd1),
	user:tcl_eval(Cmd1),
	concat_all(['pack ',W2,' -side left'],Cmd2),
	user:tcl_eval(Cmd2),
	concat_all(['label ',W2,'.typel -text ',Type],Cmd3),
	user:tcl_eval(Cmd3),
	concat_all(['pack ',W2,'.typel -anchor w'],Cmd4),
	user:tcl_eval(Cmd4).

%write_var_tk(No):-
%	write('$VAR'(No)).

write_var_tk(No,W,Aff) :-
	%% label W.varl -text Atom
        %% pack W.varl -side left
	tk_atom('$VAR'(No),Atom),    % works!!
	concat_all([W,'.varl',Aff],NW),
	concat_all(['label ',NW,' -text ',Atom],Cmd1),
	concat_all(['pack ',NW,' -side left'],Cmd2),
	user:tcl_eval(Cmd1),
	user:tcl_eval(Cmd2).

write_constant_tk(Val,W,Aff) :-
	%% label W.vall -text Atom
        %% pack W.vall -side left
	tk_atom(Val,Atom),
	concat_all([W,'.v_a_ll',Aff],NW),
	concat_all(['label ',NW,' -text ',Atom],Cmd1),
	concat_all(['pack ',NW,' -side left'],Cmd2),
	user:tcl_eval(Cmd1),
	user:tcl_eval(Cmd2).


all_empty([]).
all_empty([a(_,H)|T]):-
	do_not_print(H),
	all_empty(T).

tk_atom(A0,A) :-
	term_atom(A0,A1),
	name(A1,Chars1),
	tk_escape_l(Chars1,Chars),!,
	name(A,Chars).

tk_escape_l([],[]).
tk_escape_l([H|T],Out):-
	tk_escape_c(H,Rest,Out),
	tk_escape_l(T,Rest).

% 92: \

% 59: ;
% 32: <SPACE>
% 34: "
% 91: [
% 93: ]
% 123 {
% 125 }

tk_escape_c(34,R,[92,34|R]).
tk_escape_c(59,R,[92,59|R]).
tk_escape_c(91,[93|R],[92,91,92,32,92,93|R]).
tk_escape_c(91,R,[92,91|R]).
tk_escape_c(92,R,[92,92|R]).
tk_escape_c(93,R,[92,93|R]).
tk_escape_c(32,R,[92,32|R]).
tk_escape_c(123,R,[92,123|R]).
tk_escape_c(125,R,[92,125|R]).

% catch all:
tk_escape_c(C,R,[C|R]).

