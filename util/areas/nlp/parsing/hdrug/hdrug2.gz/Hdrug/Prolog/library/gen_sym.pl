:- module(gen_sym, [gen_sym/1,
                    gen_sym/2,
		    gen_atom/1
		   ]).


:- use_module( library(concat), [ concat/3 ]).

% gen_sym(-Atom)

gen_sym(Atom) :-
	(  recorded(gen_sym,Integer,Ref)
        -> number_chars(Integer,Chars),
           atom_chars(Atom,Chars),
	   erase(Ref),
	   Integer2 is Integer + 1,
	   recordz(gen_sym,Integer2,_)
        ;  recordz(gen_sym,1,_),
	   Atom = '0'
        ).

%gen_sym(-Sym,+Prefix) 
gen_sym(Sym,Prefix) :-
	(  recorded(gen_sym,Prefix/Integer,Ref)
        -> number_chars(Integer,Chars),
           atom_chars(Atom,Chars),
	   erase(Ref),
	   Integer2 is Integer + 1,
	   concat(Prefix,Atom,Sym),
	   recordz(gen_sym,Prefix/Integer2,_)
        ;  concat(Prefix,'0',Sym),
	   recordz(gen_sym,Prefix/1,_)
        ).

% this is complicated because TeX doesn't allow integers
% as part of an atom. Therefore we encode the integers..
prefix(X) :-
	(  prefix0(X)
        -> true
        ;  unix(mktemp('hdrugatomXXXXXX',X0)),
	   encode_prefix(X0,X,hdrugatom),
	   assertz(prefix0(X))
        ).

encode_prefix(X0,X,P) :-
	concat(P,ProcId0,X0),
	encode_id(ProcId0,ProcId),
	concat(P,ProcId,X).

encode_id(Atom0,Atom) :-
	name(Atom0,List0),
	encode_list(List0,List),
	name(Atom,List).

encode_list([],[]).
encode_list([I|T0],[J|T]) :-
	(  I > 47, I < 58 
        -> J is I + 49
	;  J is I
        ), % so 0 -> a, 1 -> b, ..
	encode_list(T0,T).

gen_atom(Atom) :-
	(  recorded(gen_atom,Str,Ref)
        -> erase(Ref)
        ;  Str = [97]
        ),
	add1(Str,Str2),
	recordz(gen_atom,Str2,_),
	name(Atom0,Str),
	prefix(Prefix),
	concat(Prefix,Atom0,Atom).

add1(L0,L) :-
	add1(L0,L1,Rest),
	( Rest =:= 0 -> L1 = L ; L = [97|L1]).

add1([],[],1).
add1([H|T],[NH|NT],Rest) :-
	add1(T,NT,Rest0),
	( Rest0 =:= 0 -> H = NH, Rest = 0 
        ; H2 is H + 1,
          ( H2 > 122 -> NH is 97, Rest = 1
          ; NH = H2, Rest=0 ) ).




	
