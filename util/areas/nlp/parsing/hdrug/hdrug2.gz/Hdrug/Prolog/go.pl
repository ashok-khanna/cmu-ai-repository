%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                         %
% written by Gertjan van Noord                            %
% (C) 1989 - 1994                                         %
%                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% GO.PL: calls the parsers/translaters/generators, defines
% path loops, create objects etc.
% cf. also interpreters.pl

:- use_module( library(equi)).
:- use_module( library(concat),      [ concat_all/3 ]).
:- use_module( library(flags)).
:- use_module( library(between),     [ between/3 ]).
:- use_module( library(gen_sym),     [ gen_sym/2 ]).
:- use_module( library(count_edges), [ count_edges/2]).
:- use_module( library(lists),       [ member/2,
	                               append/3 ]).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% simple PARSE and GENERATE  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% generate(+ExternSem)
generate(X):-
	try_extern_sem(X,Sem),
        translate(generate,o(_Node,_Phon,Sem),_).

% parse(+ListOfWords)
parse(X):-
	extern_phon(X,Phon),
        translate(parse,o(_Node,Phon,_Sem),_).

% generate_obj(+Oterm)
generate_obj(o(_,_,Sem)):-	% only take Sem into account
	translate(generate,o(_Node,_Phon,Sem),_).

% wr_module(PG,Module)
% note: parse =/= parser
%       generate =/= generator
wr_module(parse,Module) :-
	wr_flag(parser,Module).
wr_module(generate,Module) :-
	wr_flag(generator,Module).

% translate(+ParseGenerate,?OTerm,?TotalTime)
translate(ParGen,Obj,Total):-
	wr_module(ParGen,Module),
	start_hook(ParGen,Module,Obj,Start,CNo,UserOpt),
	functor(Call,ParGen,1),
	arg(1,Call,Obj),
	( call_residue(Module:Call,Cons), 
	  (   Cons = [_|_] 
          ->  write('pending constraints: '),nl,
              print(Cons),nl
          ;   true
	  ),
	  result_hook(ParGen,Module,Obj,Start,CNo,UserOpt),
	  fail
	; true 
	),
	end_hook(ParGen,Module,Obj,Start,Total,UserOpt).

% called before parser/generator starts
start_hook(ParGen,Module,Obj,Start,CNo,UserOpt) :-
	init_object(ParGen,Obj),
	statistics(runtime,[Start,_]),
	instantiate_top(Obj),
	(  flag(object_saving,semi)
	-> flag(current_no,No,1),
	   CNo = 1,
	   retract_objects(No)
	;  find_current_no(CNo)
	),
	format("~w: ",[ParGen]),
	short_before(ParGen,Obj),
	try_hook(Module:clean),
	remember(ParGen,before,Obj),
	try_hook(start_hook(ParGen,Module,Obj,UserOpt)).

% called for each parser/generator result
result_hook(ParGen,Module,Obj,Start,CNo,UserOpt) :-
	fin_object(ParGen,Obj),
	remember(ParGen,after,Obj),
	statistics(runtime,[Now,_]),
	Total is (Now - Start),
        format("cputime passed ~w msec~n",[Total]),
	create_new_object(_No,Obj,CNo),
	short_after(ParGen,Obj),
	try_hook(result_hook(ParGen,Module,Obj,UserOpt)).

% called after parser/generator fails
end_hook(ParGen,Module,Obj,Start,Total,UserOpt) :-
	try_hook(Module:count),
	wr_module(ParGen,Module),
	statistics(runtime,[End,_]),
	Total is (End - Start),
        format("cputime total ~w msec~n",[Total]),
	try_hook(end_hook(ParGen,Module,Obj,UserOpt)).

init_object(parse,o(Node,Phon,_Sem)):-
	try_hook(phonology(Node,Phon)).

init_object(generate,o(Node,_Phon,Sem)):-
	try_hook(semantics(Node,Sem)).

fin_object(generate,o(Node,Phon,_Sem)):-
	try_hook(phonology(Node,Phon)).

fin_object(parse,o(Node,_Phon,Sem)):-
	try_hook(semantics(Node,Sem)).

%% this is were parser/generator are called proper:
%% cf. interpreters.pl
% is overridden by some applications
remember(parse,before,_).
remember(generate,after,o(_,String,_)):-
	tk_send_a_sentence(String).

remember(generate,before,_).
remember(parse,after,o(_,_,Lf)):-
	tk_send_a_lf(Lf).

available :-
	write('currently supports:'),nl,
	( write(parsers),nl,
	  member_flag(parser_mode,P),
	  tab(5),write(P),nl,
	  fail
        ; true
        ),
	( write(generators),nl,
          member_flag(generator_mode,P),
          tab(5),write(P), nl,
	  fail
        ; true
        ),
	write('currently disabled:'),nl,
	( write(parsers),nl,
          flag(off(parser_mode),Val),
	  member(P,Val),
	  tab(5),write(P), nl,
	  fail
        ; true
        ),
	( write(generators),nl,
	  flag(off(generator_mode),Val),
	  member(P,Val),
	  tab(5),write(P),nl,
	  fail
        ; true
        ).

% SHORT/2
% short(ParseGenerate,Obj)

short_after(parse,o(_Obj,_,Sem)):-
	try_extern_sem(ExtSem,Sem),
        print(ExtSem),nl.

short_after(generate,o(_,Phon,_)):-
	extern_phon(ExtPhon,Phon),
	concat_all(ExtPhon,Atom,' '),
	write(Atom),nl.

short_before(parse,o(_,Phon,_)):-
	extern_phon(ExtPhon,Phon),
	concat_all(ExtPhon,Atom,' '),
	write(Atom),nl.

short_before(generate,o(_,_,Sem)):-
	try_extern_sem(ExtSem,Sem),
	print(ExtSem),nl.

%%%%%%%%%%%%%%%%%%%%%%
%                    %
% CREATE NEW OBJECT  %
%                    %
%%%%%%%%%%%%%%%%%%%%%%

% test for existence of object only if object exists as a result of the
% same parse/generate goal

create_new_object(_No,_Val):-
	flag(object_saving,off),!.

create_new_object(No,Obj_val):-
        new_no(No),
        assert_object(No,Obj_val),
	format("created object: ~w~n",[No]).

create_new_object(_No,_Val,_MinNo):-
	flag(object_saving,off),!.

create_new_object(No,Obj_val,MinNo) :-
        object_does_not_exist(Obj_val,MinNo),
        new_no(No),
        assert_object(No,Obj_val),
	format("created object: ~w~n",[No]).

object_does_not_exist(Obj,MinNo):-
        find_current_no(Cur),
        between(MinNo,Cur,No),
        object(No,Obj2),
        equal(Obj,Obj2),
        !,
	format("(Found object identical to: ~w)~n",[No]),
        fail.

object_does_not_exist(_,_).

new_no(No) :-
	find_current_no(No),
	No2 is No + 1,
	flag(current_no,_,No2).

find_current_no(No):-
	flag(current_no,N),
	(   integer(N) 
        ->  No = N
	;   No is 1
	).

retract_objects(No) :-
	tk_retract_objects(No),
	( recorded(object,_,Ref),
	  erase(Ref),
	fail
        ; true).

assert_object(No,Val):-
	tk_assert_object(No),
	recordz(object,object(No,Val),_).

object(No,Val):-
	recorded(object,object(No,Val),_).

correct_id(I):-
	find_current_no(I2),
	I1 is I2 - 1,
	between(1,I1,I).

%%%%%%%%%%%%%%%%%%%%
%%% TOP CATEGORY %%%
%%%%%%%%%%%%%%%%%%%%

instantiate_top(o(Cat,_,_)):-
	flag(top_features,Name),
	(  Name = undefined
	-> true 
	;  top(Name,Cat)
	),
	wr_flag(top_features,Name).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% parsing sets of sentences with sets of parsers %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

reset_table :-
	retractall(table_entry(_Name,_Length,_Amb,_Time,_Parser,_Edges)).

go_l([]).
go_l([H|T]):-
	hdrug_go(H),
	go_l(T).

hdrug_go :-
	statistics_run(_).

hdrug_go(X) :-
	statistics_run(X).

% if Ref uninstantiated, then use all sentences upon backtracking
statistics_run(Ref) :-
	( a_sentence(Ref,Max,Sentence),
	  parse_compare_st(Ref,Max,Sentence),
	  fail
        ; true
	).

% sentences are given as
% sentence(Key,MaxMilliSec,Sentence) or
% sentence(Key,Sentence) 
% in the latter case the maximum is computed by number of words
% times maximum_per_word
% dyn_sentences are sentences asserted (previous parse goals or
% previous generation results)

a_sentence(Ref,Max,Sentence):-
	( sentence(Ref,Max,Sentence)
        ; dyn_sentence(Ref,Max,Sentence)
        ).

a_sentence(Ref,Max,Sentence):-
	( sentence(Ref,Sentence)
	; dyn_sentence(Ref,Sentence)
        ),
	length(Sentence,Length),
	maximum_per_word(Length,Max).

sentences :-
	( a_sentence(A,B,C),
          write(sentence(A,B,C)),nl,
	  fail
        ; true
        ).

% this e.g. gives:
%  3 words   12700
%  8         29200
% 16         86800
% 25        197500
maximum_per_word(L,Max) :-
	(  user_max(L,Max)
	-> true
	;  Max is 10000 + (L * L * 300)
	).

% fails if a parse with same length or longer for this parser timed out
:- initialize_flag(useful_try_check,on).

useful_try(Parser,Ref,_Sentence):-
	table_entry(Ref,_,_,_,Parser,_),
	!,
	format("already done ~w for ~w~n",[Ref,Parser]),
	fail.
useful_try(Parser,Ref,Sentence):-
	flag(useful_try_check,on),
	length(Sentence,Length),
	table_entry(Name,Length2,time_out,_,Parser,_),
	Length >= Length2,
	!,
        format("not doing ~w for ~w because of time-out of ~w~n",[Ref,Parser,Name]),
	fail.
useful_try(_,_,_).

parse_compare(Sentence):-
	gen_sym(Sym,'$'),
	assertz(dyn_sentence(Sym,Sentence)),
	statistics_run(Sym).

parse_compare(Max,Sentence):-
	gen_sym(Sym,'$'),
	assertz(dyn_sentence(Sym,Max,Sentence)),
	statistics_run(Sym).

parse_compare_st(Ref,Max,Sentence):-
	length(Sentence,Len),
	flag(ask,_,off),
	flag(object_saving,_,semi),
	( member_flag(parser_mode,Parser),
	  flag(parser,_,Parser),
	  useful_try(Parser,Ref,Sentence),
	  time_out(parse2(Ref,Sentence),Max,Succ),
	  (  Succ=time_out 
          -> format("timed out after ~w msec~n",[Max]),
	     flag(parser,P),
	     try_hook(P:count(NoItems),NoItems=0),
	     try_hook(P:clean),
	     assertz(table_entry(Ref,Len,time_out,Max,Parser,NoItems))
          ;  true),
	  fail
        ; true
        ).

parse2(Ref,Sentence):-
	length(Sentence,Len),
	extern_phon(Sentence,Phon),
        translate(parse,o(_Node,Phon,_Sem),Total),
	flag(parser,Parser),
	try_hook(Parser:count(NoEdges),NoEdges=0),
	try_hook(Parser:clean),
	count_edges(object(_,_),NoAnalyses),
	assertz(table_entry(Ref,Len,NoAnalyses,Total,Parser,NoEdges)).

%%%%%%%%%%%%%%
% generation %
%%%%%%%%%%%%%%

generate_compare_object(No) :-
	object(No,o(_,_,Sem)),
	try_extern_sem(X,Sem),
	init_object(generate,o(Node,Phon,Sem)),
	generate_compare1(o(Node,Phon,Sem),X).

generate_compare(X):-
	try_extern_sem(X,Sem),
	generate_compare1(o(_Node,_Phon,Sem),X).

generate_compare1(Obj,Ex) :-
	gen_sym(Ref,'g'),
	flag(ask,_,off),
	flag(object_saving,_,semi),
	( member_flag(generator_mode,Generator),
	  flag(generator,_,Generator),
          translate(generate,Obj,Total),
	  try_hook(Generator:count(NoEdges),NoEdges=0),
	  try_hook(Generator:clean),
	  count_edges(object(_,_),NoAnalyses),
	  assertz(table_entry(Ref,Ex,NoAnalyses,Total,Generator,NoEdges)),
	  fail
	; true
        ).


%%%%%%%%%%%%%
%%% hooks %%%
%%%%%%%%%%%%%

try_hook(Call) :-
	try_hook(Call,true).
try_hook(Call,Alt) :-
	if(Call,true,Alt).


try_extern_sem(A,B) :-
	try_hook(extern_sem(A,B),A=B).

% extern_sem/2
% phonology/2
% ParserGenerator:clean/0
% ParserGenerator:count/0
% ParserGenerator:count/1
% end_hook/4
% result_hook/4
% start_hook/4
% semantics/2
