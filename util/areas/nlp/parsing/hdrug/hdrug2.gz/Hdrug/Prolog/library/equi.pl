%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                         %
% written by Gertjan van Noord                            %
% (C) 1989                                                %
%                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% equivalent
%
%
% defines predicate equal(A,B) to test whether two
% terms are alphabetic variants
%
% seems to be faster than double subsumption check!
% May not be true for Prologs with built-in subsumption check
%
% works with coinstantiated variables between A and B
% whereas double subsumption check does not..!

:- module(equal,[equal/2]).

equal(A,B) :-
	subsumes_chk(A,B),
	subsumes_chk(B,A).




