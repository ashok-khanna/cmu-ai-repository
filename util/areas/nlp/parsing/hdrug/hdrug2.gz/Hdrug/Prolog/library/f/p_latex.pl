%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                         %
% written by Gertjan van Noord                            %
% (C) 1993  all rights reserved                           %
%                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- use_module(library(latex)).

:- use_module(library(latex_term),[ tex_term/1 ]).

:- use_module([
	       library(prettyvars)    % to know what variables are single
	      ]).

:- use_module( library(concat), [ concat/3,
	                          concat_all/2,
	                          concat_all/3,
				  term_atom/2]).

:- use_module( library(flags) ).
:- use_module( library(lists),  [ member/2,
	                          append/3 ]).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% prolog terms as feature structures %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% First: prolog terms / clauses / listing where the terms that
%% occur might represent feature-structures.
%%
%% cf. library(feature) & library p_feature
%%
%% note that the file library(p_feature) defines similar predicates for tty output

latex_fs(fs(FS)) :-
	!,
	print_latex_fs(fs(FS)).

latex_fs(clause(FS)) :-
	!,
	print_latex_fs(clause(FS)).

latex_fs(clause(FS,Body)) :-
	!,
	print_latex_fs(clause(FS,Body)).

latex_fs([H|T]) :-
	!,
	print_latex_fs([H|T]).

latex_fs(listing(X)) :-
	!,
	print_latex_fs(listing(X)).

latex_fs(FS) :-
	print_latex_fs(fs(FS)).

latex_fs_clause((H:-B0)) :-
	!,
	ensure_prolog_conjunction(B0,B),
	print_latex_fs(clause(H,B)).

latex_fs_clause(Unit) :-
	print_latex_fs(clause(Unit)).

latex_fs_listing([H|T]) :-
	print_latex_fs(listing([H|T])).

print_latex_fs(Thing) :-
	flag(vspace,_,on),
	files(Tex,_,_,_,_),
	telling(Old), tell(Tex),
        start_docu(_),
        print_it_fs(Thing),
        end_docu,
	told, telling(Old),
	latex_and_xdvi.

print_it_fs(listing(L)) :-
	!,
	( member(Thing,L),
	  (   Thing = (H:-B0) 
%          ->  ensure_convert_to_list(B0,B),
	  ->  ensure_prolog_conjunction(B0,B),
	      print_it_fs(clause(H,B))
          ;   print_it_fs(clause(Thing))
          ),
	  fail
        ; true ).

print_it_fs([]).
print_it_fs([H|T]) :-
	print_it_fs(H),
	print_it_fs(T).

print_it_fs(Thing0) :-
	write('\begin{flushleft}'),nl,
%%	shorten_it(Thing0,Thing1),
	call_residue(copy_term(Thing0,Thing1),Cons0),
	user:rewrite_body(Cons0,[],Cons,[]),            % note: from link_clause.pl!!
	add_cons(Thing1,Cons,Thing2),
	shorten_it(Thing2,Thing3),
	prettyvars(Thing3,0,No),
	change_it_fs(Thing3,Thing,No),
	write_it_fs_latex(Thing),
	write('\end{flushleft}').

shorten_it(clause(H0,B0),clause(H,B)) :-
	shorten_goal(H0,H),
	shorten_goals(B0,B).
shorten_it(clause(H0),clause(H)) :-
	shorten_goal(H0,H).
shorten_it(fs(X0),fs(X)) :-
	shorten_label(X0,X).
shorten_it(fs(X0,Y0),fs(X,Y)) :-
	shorten_label(X0,X),
	shorten_goals(Y0,Y).

write_it_fs_latex(fs(FS,C)) :-
	tex_begin_line,
	pp(FS),tex_if,
	tex_end_line,
	write_pretty_constraint_latexs(C).

write_it_fs_latex(fs(FS)) :-
	tex_begin_line,
	pp(FS),
	tex_end_line.

write_it_fs_latex(clause(H)) :-
	tex_begin_line,
	write_pretty_constraint_latex(H),
	put(0'.), tab(1), tex_end_line.

write_it_fs_latex(clause(H,B)) :-
	tex_begin_line, 
	write_pretty_constraint_latex(H), 
	tex_if,
	tex_end_line, 
	write_pretty_constraint_latexs(B).

write_pretty_constraint_latexs([H|T]) :-
	tex_begin_line, 
	write('~~~~'),
	write_pretty_constraint_latex(H),
	write_pretty_constraint_latexs0(T).

write_pretty_constraint_latexs0([]) :-
	put(0'.), tab(1), tex_end_line.
write_pretty_constraint_latexs0([H|T]) :-
	write(','),tab(1),
	tex_end_line,
	tex_begin_line, 
	write('~~~~'),
	write_pretty_constraint_latex(H),nl,
	write_pretty_constraint_latexs0(T).

write_pretty_constraint_latex(H) :-
	H =.. [F|Args],
	write_relation(F),
	write_begin_functor_latex(Args),
	write_pretty_argument_latexs0(Args),
	write_end_functor_latex(Args).

write_begin_functor_latex([]).
write_begin_functor_latex([_|_]):-
	write('(').

write_end_functor_latex([]).
write_end_functor_latex([_|_]) :-
	write(')').

write_pretty_argument_latexs0([H|T]):-
	pp(H),
	write_pretty_argument_latexs(T).

write_pretty_argument_latexs([]).
write_pretty_argument_latexs([H|T]):-
	write(','),
	pp(H),
	write_pretty_argument_latexs(T).

fs :-
    write('\avm{'),nl.
fs(Var):-
    write('\avm[{'),
    tex_var(Var),
    write('}]{').
fsfs :-
    write('}').

pp(_Var/n=FS):-
	!,
        ppl_latex(FS,no).

pp(Var/_='R'):-
        !,
	tex_var(Var).

pp(Var/y=[]):-
        !,
	tex_var(Var).

pp(Var/y='$VAR'(_)):-
	!,
	tex_var(Var).

pp(Var/y=FS):-
%	tex_var(Var),
        ppl_latex(FS,yes(Var)).

pp(lex(W)) :-
	write(W).

ppl_latex([a(_Att,Thing)|Rest],Tab):-
	do_not_print(Thing),!,
	ppl_latex(Rest,Tab).

ppl_latex([a(type,['.']),a(_,Head),a(_,Tail)],no) :-
	!,
	ppl_list(Head,Tail).

ppl_latex([a(type,['.']),a(_,Head),a(_,Tail)],yes(Var)) :-
	!,
	tex_var(Var),write('~'),
	ppl_list(Head,Tail).

ppl_latex([a(type,[[]])],_) :-
	!,
	write('\langle\rangle').

ppl_latex([a(type,Types)|T],no):-
	all_empty(T),
	!,
%	write(' \{ '),
	write_as_conj(Types,PTypes),
	write_type_latex(PTypes).
%	write(' \} ').

ppl_latex([a(type,Types)|T],yes(Var)):-
	all_empty(T),
	!,
	tex_var(Var),write('~'),
%	write(' \{ '),
	write_as_conj(Types,PTypes),
	write_type_latex(PTypes).
%	write(' \} ').

ppl_latex([a(type,Types)|T],no):-
	!,
	fs,
%	write(' \{ '),
	write_as_conj(Types,PTypes),
	write_type_latex(PTypes),
%	write(' \} '),
	ppl2_latex(T,_Tab),
	fsfs.

ppl_latex([a(type,Types)|T],yes(Var)):-
	!,
	fs(Var),
%	write(' \{ '),
	write_as_conj(Types,PTypes),
	write_type_latex(PTypes),
%	write(' \} '),
	ppl2_latex(T,_Tab),
	fsfs.

ppl_latex([a('BOOLEAN',_Type,Val)|T],no):-
	all_empty(T),
	!,
	give_boolean_type(Val,Exp),
%	write(' \{ '),
	write_type_latex(Exp).
%	write(' \} ').

ppl_latex([a('BOOLEAN',_Type,Val)|T],yes(Var)):-
	all_empty(T),
	!,
	tex_var(Var),write('~'),
	give_boolean_type(Val,Exp),
%	write(' \{ '),
	write_type_latex(Exp).
%	write(' \} ').


ppl_latex([a('BOOLEAN',_Type,Val)|T],no):-
	give_boolean_type(Val,Exp),
	fs,
	write_type_latex(Exp),
	ppl2_latex(T,_Tab),
	fsfs.

ppl_latex([a('BOOLEAN',_Type,Val)|T],yes(Var)):-
	give_boolean_type(Val,Exp),
	fs(Var),
	write_type_latex(Exp),
	ppl2_latex(T,_Tab),
	fsfs.

ppl_latex([a('UNTYPED',_Att,Val)|T],no):-
	tex_term(Val),
	ppl2_latex(T,_Tab).

ppl_latex([a('UNTYPED',_Att,Val)|T],yes(Var)):-
	tex_var(Var),write('~'),
        tex_term(Val),
	ppl2_latex(T,_Tab).

ppl_latex([a('TREE',Mark0,Cat,Ds)|T],_) :-
	mrk_t(Mark0,Mark),
	write(Mark),tab(1),
	pp_ds([Cat|Ds],0),
	ppl2_latex(T,_).

ppl_latex([a(Att,FS)|T],no):-
        !,
	fs,
	write_attribute(Att),
	write(':'),
        pp(FS),
        ppl2_latex(T,_Tab),
	fsfs.

ppl_latex([a(Att,FS)|T],yes(Var)):-
        !,
	fs(Var),
	write_attribute(Att),
	write(':'),
        pp(FS),
        ppl2_latex(T,_Tab),
	fsfs.

ppl_latex([],_).

ppl_latex('$VAR'(_),_) :-
	write('\_').
%%	write('$VAR'(X)).

pp_ds([H],_) :-
	!,
	pp(H).

pp_ds([H|T],I0) :-
	fs,
	pp_ds1([H|T],I0),
	fsfs.

pp_ds1([],_).
pp_ds1([H|T],I0) :-
	write(I0),
	write(':'),
	pp(H),
	I is I0 + 1,
	pp_ds2(T,I).

pp_ds2([],_) :- 
	!.
pp_ds2([H|T],I0) :-
	!,
	write('\\'),
	write(I0),
	write(':'),
	pp(H),
	I is I0 + 1,
	pp_ds2(T,I).
pp_ds2('$VAR'(_),_) :-
	write('\_').

mrk_t(foot,'=') :- 
	!.
mrk_t(subs,'*') :- 
	!.
mrk_t(_,'').

pplist_latex(atom(X),I,_Tab):-
	write(' \\ '),
	nl,
%	write_list(Tab),
	write(I),
	write(X).
pplist_latex([],_,_).
pplist_latex([H|T],I,Tab):-
%	append(Tab,[I],Tab2),
	write(' \\ '),
	nl,
%	write_list(Tab2),
	fs,
	pp(H),
	fsfs,
	I2 is I + 1,
	pplist_latex(T,I2,Tab).
pplist_latex('$VAR'(_),_,_).

ppl2_latex([a(_Att,Thing)|Rest],Tab):-
	do_not_print(Thing),!,
	ppl2_latex(Rest,Tab).

ppl2_latex([a(Att,FS)|T],Tab):-
        !,
	write(' \\ '),
	nl,
        write_attribute(Att),
	write(':'),
        pp(FS),
        ppl2_latex(T,Tab).

ppl2_latex([],_).
ppl2_latex('$VAR'(_),_).

ppl_list(Head,Tail) :-
	write('\langle '),
	ppx(Head),
	ppl_list(Tail),
	write('\rangle ').

ppl_list(V/y='R') :-
	!,
	write(' | '),
	ppx(V/y='R').

ppl_list(V/YN='$VAR'(_)) :-
	!,
	write(' | '),
	ppx(V/YN='$VAR'(_)).
	
ppl_list(_Var/_YN=[a(type,[[]])]) :-
	!.

ppl_list(_Var/_YN=[a(type,['.']),a(_,Head),a(_,Tail)]) :-
	write(' , '),
	ppx(Head),
	ppl_list(Tail).

ppx(ListEl) :-
	pp(ListEl),!.

ppx(_) :-
	write(' \_ ').

write_attribute(A) :-
	write(' \mbox{\it '),
	tx_atom(A),
	write('} ').

write_relation(A) :-
%%	write(' \mbox{\it '),
	tex_atom(A).
%%	write('} ').

write_type_latex(A) :-
	write(' \mbox{\sc '),
	tx_atom(A),
	write('} ').


shorten_goal(M:G0,M:G) :-
	!,
	shorten_goal(G0,G).

shorten_goal(when(C,G0),when(C,G)) :-
	!,
	shorten_goal(G0,G).

shorten_goal(G0,G) :-
	G0 =.. [F|T0],
	 shorten_labels(T0,T),
	 G =.. [F|T].

shorten_goals([],[]).
shorten_goals([H0|T0],[H|T]) :-
	shorten_goal(H0,H),
	shorten_goals(T0,T).

shorten_labels([],[]).
shorten_labels([H0|T0],[H|T]) :-
	shorten_label(H0,H),
	shorten_labels(T0,T).

shorten_label(V0,V) :-
	var(V0),
	!,
	V0=V.
shorten_label(V0,V) :-
	user:shorten_label(V0,V),
	!.
shorten_label(L,L).
