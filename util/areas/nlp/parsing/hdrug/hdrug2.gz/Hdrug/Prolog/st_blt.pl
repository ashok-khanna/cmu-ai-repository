%% new version of st_tk using blt graph widget

:- module(st_tk, [ go_and_table_tk/0,
                   go_and_table_tk_add/0,
		   sts/0, 
		   sts/1,
		   sts_add/0,
		   sts_add/1 ]).

:- use_module( library(lists),       [ member/2,
	                               append/3 ]).

:- use_module( library(tk) ).
:- use_module( library(tk_graph) ).
:- use_module( library(flags)).
:- use_module( st_tty,[ add_info/1 ]).

go_and_table_tk :-
	( setof(Nr,X^Y^(user:a_sentence(Nr,X,Y)),Nrs),
	  member(N,Nrs),
	  user:hdrug_go(N),
	  sts,
	  tcl_eval(update),
	  fail
        ; true 
        ).

go_and_table_tk_add :-
	( setof(Nr,X^Y^(user:a_sentence(Nr,X,Y)),Nrs),
	  member(N,Nrs),
	  user:hdrug_go(N),
	  sts_add,
	  tcl_eval(update),
	  fail
        ; true 
        ).

tk_it(List) :-
	tk_it(List,[]).

tk_it(List,Options) :-
	tk_graph(List,
	          ['configure -title Results',
		   'configure -width 600 -height 600',
		   'xaxis configure -title "Sentence Length"',
		   'yaxis configure -title "Time in Millisecs."' |
		  Options
		  ]).

sts :-
	findall(P,member_flag(parser_mode,P),Parsers),
	sts(Parsers).

sts(Parsers):-
	findall(t(P,L),(member(P,Parsers),
                        get_table(P,L)),List),
	tk_it(List).

get_table(Parser,List):-
	setof(Len/Time,
              Name^Amb^Edges^(user:table_entry(Name,Len,Amb,Time,Parser,Edges),
                              number(Len), 
			      number(Time)),
              List).

sts_add :-
	findall(P,member_flag(parser_mode,P),Parsers),
	sts_add(Parsers).

sts_add(Parsers):-
	findall(t(P,L),(member(P,Parsers),
                        get_table_add(P,L)),List),
	tk_it(List).

get_table_add(Parser,List):-
	setof(X/Y,table_element_add(Parser,X/Y),List).

table_element_add(Parser,X/Y):-
	setof(T,add_info(T),Table),
	member(t(X,Y,Parser),Table).

