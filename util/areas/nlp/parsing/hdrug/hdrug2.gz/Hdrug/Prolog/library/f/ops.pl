:- op(402,xfy,(:)).                          % paths
:- op(800,xfy,['=>', '==>', '<=>', '=*>']).  % equations
:- op(300,fx,['@','`','=']).                 % functional expressions
:- op(400,xfy,&).                            % boolean expressions
:- op(390,fx,~).                             % boolean expressions
