:- ensure_loaded( compilation ).
:- ensure_loaded( [
%%	            'PG/rcp3',
		    'PG/rcp3_d',
		    'PG/rcp3_dtrs',
		    'PG/approx',
%%		    'PG/hc',
		    'PG/hc_d',
		    'PG/hc_dtrs',
		    'PG/right_chart',
		    'PG/shift_reduce',
		    'PG/bug_dd'
		  ]).

:- initialize_flag(top_features,main).

:- initialize_flag(parser,rcp3_dtrs).

:- initialize_flag(generator,bug_dd).

:- compile_grammar.

:- version('Grammar based on the paper:
The Scope of Adjuncts and the Processing of Lexical Rules').

:- use_module( library(concat), [ concat/3 ] ).
:- use_module( library(tk) ).

gram_startup_hook_begin :-
	update_unary_preds.
gram_startup_hook_end :-
	tcl_eval('source $hdrug_library/SP_lr.tcl').

:- ensure_loaded(suite).
