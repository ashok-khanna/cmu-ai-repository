%%%%%%%%%%%%%%%%%%%%%%%%% io etc. %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- use_module(library(lists), [ nth/3 ]).

%%%% check_and_display_result/1 is called by the parser	  

%check_and_display_result(t(Sign,Ds)) :-
%	startsymbol(Sign),
%	display_tree(t(Sign,Ds),0),
%	display_semantics(Sign),
%	ttyflush.

:- del_graphic(gp,gl,gd).

gp(syn,Obj,Obj).

gl(syn,tree(Sign,_,[_|_]),Label) :-
	cat_symbol(Sign,Label).
gl(syn,tree(W,_,[]),W).

gd(syn,No,tree(_,_,[H|T]),D) :-
	nth(No,[H|T],D).

show_node(syn,tree(Sign,[_|_],_)) :-
	tk_fs(fs(Sign)).

show_node(sem,tree(Sign,[_|_],_)) :-
	tk_fs(fs(Sign)).

%

gp(sem,Obj,Obj).
gl(sem,tree(Sign,_,[_|_]),Label) :-
	semantics(tree(Sign,_,_),Label).
gl(sem,tree(W,_,[]),W).

gd(sem,No,tree(_,_,[H|T]),D) :-
	nth(No,[H|T],D).

:- add_graphic(gp,gl,gd).

cat_symbol(Sign,Sym) :-
	( Sign:gap ==> empty -> cat_symbol0(Sign,Sym)
	; cat_symbol0(Sign,Sym0),
	  Sign:gap <=> Gap,
	  cat_symbol0(Gap,GapSym),
	  Sym = Sym0-GapSym
	).
	
cat_symbol0(Sign,Cat) :-
	Sign:cat <=> Var,
	var(Var),!,
	Var = Cat.
cat_symbol0(Sign,Cat) :-
	( Sign:cat ==> n
        ; Sign:cat ==> np
	; Sign:cat ==> pref
	; Sign:cat ==> pp
	; Sign:cat ==> adj
	),
	Sign:cat <=> Cat.
cat_symbol0(Sign,s) :-
	Sign:cat ==> sent.
cat_symbol0(Sign,Symbol) :-
	( Sign <=> Val/Arg -> Symbol = ValSym/ArgSym
	; Sign <=> Arg\Val,
	  Symbol = ArgSym\ValSym
	),
	cat_symbol0(Val,ValSym),
	cat_symbol0(Arg,ArgSym).


%display_semantics(Sign) :-
%	Sign:sem <=> Sem,
%	\+ \+ ( prolog:prettyvars(Sem),
%		nl, write(Sem)
%	      ).
	      
	 
/*portray(fvt(F,V,T)) :-
	cat_symbol(fvt(F,V,T),Cat),
	write(Cat).	      
portray(t(Sign,_Ds)) :-
	portray(Sign).
*/	

%%%%%%%%%%%%%%%% grammar compilation (for efficiency only) %%%%%%%%%%%%%%%%
:- dynamic lex/2, rule0/4.

compile_lexicon :-
	retractall(lex(_,_)),
	( lexic(Word,Sign), assert(lex(Word,Sign)), 
	  write(Word), write(', '), ttyflush, fail
	; true
	).

compile_rules :-
	retractall(rule0(_,_,_,_)),
	( rule(Name,Lhs,Rhs,Head), assert(rule0(Name,Lhs,Rhs,Head)), fail
	; true
	).

