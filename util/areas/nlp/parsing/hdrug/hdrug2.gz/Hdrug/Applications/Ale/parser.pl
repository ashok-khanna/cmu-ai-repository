:- module(parser,[]).

parse(o(ale(Tag,SVs,Iqs),Str,_)) :-
	user:rec(Str,Tag,SVs,Iqs).

