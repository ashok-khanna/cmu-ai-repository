% first define a compiler from ALE terms to the kind of terms
% that library(p_feature), library(latex), library(p_tk) know
% about
%
% 
% these terms look like
% X/Y=Z where
%
% Integer/YesNo = Term
% Integer is some index
% YesNo if yes then it is an index which some other substructure refers to
% Term is a term, or special symbol 'R' when it should be skipped because
% already printed...
% Term is a list of a(Att,Val) terms, where Val is a term as described.

change_fs(FS,Iqs,Changed,ChangedIqs) :-
	duplicates(FS,Iqs,[],_,[],_,0,_),   % ale
	change_pp_fs(FS,Changed,[],VisOut),
	pp_change_iqs(Iqs,ChangedIqs,VisOut,_).

pp_change_iqs([],[],_,_).
pp_change_iqs([_|_],[],_,_) :-
	tk_warning('Ignoring inequalities (not yet implemented)').

% same structure as pp_fs from ale, but does not write output,
% instead builds up a term of the specified format above
change_pp_fs(FS,Ix/YN=Rest,VisIn,VisOut) :-
  deref_pp(FS,Ref,SVs),
  ( var(Ref), YN=n                  % print ref if shared (nonvar)
  ; nonvar(Ref), %% write('['), write(Ref), write(']'),
    Ref=Ix, YN=y,
    ( member_eq(Ref,VisIn), !
    ; true         %%write(' ')
    )
  ),
  ( member_eq(Ref,VisIn), !, VisOut = VisIn, Rest='R'
  ; SVs =.. [Type|Vs],              % print FS if not already visited
    approps(Type,FRs),
    ( no_write_type_flag(Type),
      !, change_pp_vs(FRs,Rest1,Vs,[Ref|VisIn],VisOut),
      Rest=Rest1
    ; %%write(Type),
      Rest = [a(type,[Type])|Rest1],
      change_pp_vs(FRs,Rest1,Vs,[Ref|VisIn],VisOut) 
    )
  ).

change_pp_vs([],[],[],Vis,Vis).
change_pp_vs([F:_|FRs],Result,[V|Vs],VisIn,VisOut):-
  ( no_write_feat_flag(F),
    VisMid = VisIn, !,
    Result=Rest
  ; %%nl, tab(Col),
    %%write_feature(F,LengthF), 
    %%NewCol is Col + LengthF +1,
    change_pp_fs(V,AttVal,VisIn,VisMid),
    Result = [a(F,AttVal)|Rest]
  ),
  change_pp_vs(FRs,Rest,Vs,VisMid,VisOut).

/*
test(O) :-
	object(O,o(ale(X,Y,Ins),_,_)),
	change_fs(X-Y,Ins,A,_InsOut),
	feature:write_it_fs(fs(A)).

latex_test(O) :-
	object(O,o(ale(X,Y,Ins),_,_)),
	latex_ale(X-Y,Ins).

tk_test(O) :-
	object(O,o(ale(X,Y,Ins),_,_)),
	tk_ale(X-Y,Ins).
*/

latex_ale(FS,Ineqs) :-
	change_fs(FS,Ineqs,A,_InsOut),
	flag(vspace,_,on),
	latex:files(Tex,_,_,_,_),
	telling(Old), tell(Tex),
        latex:start_docu(_),
	write('\begin{flushleft}'),nl,
	feature:write_it_fs_latex(fs(A)),
	write('\end{flushleft}'),
        latex:end_docu,
	told, telling(Old),
	latex:latex_and_xdvi.

tk_ale(FS,Ineqs) :-
	change_fs(FS,Ineqs,A,_InsOut),
	feature:write_it_tk(fs(A)).
	
%% show_latex(Type,Thing).
%% show_tk(Type,Thing).

show_latex(lexs,Word) :-
	lex(Word,Tag,SVs,IqsIn),
	extensionalise(Tag,SVs,IqsIn),
	check_inequal(IqsIn,IqsOut),
	latex_ale(Tag-SVs,IqsOut).

show_latex(object,No) :-
	object(No,o(ale(X,Y,Ins),_,_)),
	latex_ale(X-Y,Ins).
	
show_tk(lexs,Word) :-
	lex(Word,Tag,SVs,IqsIn),
	extensionalise(Tag,SVs,IqsIn),
	check_inequal(IqsIn,IqsOut),
	tk_ale(Tag-SVs,IqsOut).

show_tk(object,No) :-
	object(No,o(ale(X,Y,Ins),_,_)),
	tk_ale(X-Y,Ins).

	