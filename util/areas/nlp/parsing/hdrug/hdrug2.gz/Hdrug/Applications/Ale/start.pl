freload:-
  ensure_loaded(
          ['.sub_type',
           '.unify_type',
           '.approp',
           '.extensional',
           '.iso_sub_seq',
           '.check_sub_seq',
           '.ucons',
           '.add_to_typecons',
           '.add_to_type',
           '.add_to_type3',
           '.featval',
           '.featval4',
           '.u',
           '.empty_cat',
           '.lex',
           '.rule',
           '.solve']).

:- ensure_loaded(ale).
:- prolog_flag(redefine_warnings,Val,off),
   compile(overwrite),
   compile(hpsg),   % because:
   %% The procedure cons/2 is being redefined.
   %%     Old file: /users1/vannoord/src/Hdrug/Applications/Ale/ale.pl
   %%     New file: /users1/vannoord/src/Hdrug/Applications/Ale/hpsg.pl
   prolog_flag(redefine_warnings,_,Val).
:- freload.
:- ensure_loaded(decl).
:- ensure_loaded(show).
:- ensure_loaded(parser).
:- ensure_loaded(suite).
