% parsers and generators
:- add_flag(parser_mode,parser).
:- add_flag(generator_mode,generator).

:- initialize_flag(parser,parser).
:- initialize_flag(generator,generator).

% top_features
top(s,node(s,_)).

:- initialize_flag(top_features,s).

% grammar compilation
compile_grammar :-
	compile(gram).

reconsult_grammar :-
	reconsult(gram).

compile_grammar_file(File) :-
	compile(File).

reconsult_grammar_file(File) :-
	reconsult(File).

:- version('Simple DCG').

semantics(node(_,Sem),Sem).

% Trees
:- del_graphic(gp,gl,gd).

gp(s,node(_,S),S).

gl(s,Term,Label) :-
	functor(Term,Label,_).

gd(s,1,Term,D) :-
	arg(1,Term,D).

gd(s,2,Term,D) :-
	arg(2,Term,D).

:- add_graphic(gp,gl,gd).

% Extending GUI
gram_startup_hook_end :-
	tcl_eval('source $hdrug_library/SP_dcg.tcl').

