:- reconsult(library('f/ops')).


:- op(500,xfy,\).
:- op(600, xfx, <=> ).

