%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (c) 1992 - 1994 Gertjan van Noord RUG %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- compile(ops).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% declarations needed by Hdrug: %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

semantics(tree(S,_,_),Sem):-
	user_sem(S,Sem).

top(Name,tree(Cat,_,_)):-
	user_top_category(Name,Cat).

:- ensure_loaded([ pretty,
	           compile,
		   parse
	         ]).

compile_parsers :-
	ensure_loaded([ 
%		  'PG/mm',
		  'PG/mm_d',
		  'PG/mm_tree',
%		  'PG/pack',
		  'PG/pack_d',
		  'PG/pack_tree',
%		  'PG/bt',
	          'PG/bt_d',
		  'PG/bt_tree'
	        ] ).


:- compile(gram).
% grammar first, because that allows partial evaluation for
% some of the predicates in the parser..

:- compile_parsers.

:- version('Tree Adjoining Grammar v1').

gram_startup_hook_end :-
	tcl_eval('source $hdrug_library/SP_tag.tcl').

:- ensure_loaded(suite).
