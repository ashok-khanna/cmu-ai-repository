:- module(td,[]).
:- use_module(library(flags)).
:- add_flag(parser_mode,td).
:- add_flag(generator_mode,td).

parse(o(Cat,_,_)) :-
	user:Cat.

