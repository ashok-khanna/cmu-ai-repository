:- ensure_loaded(xg).
:- ensure_loaded(td).

compile_grammar :- 
	compile_grammar_file(dutch).

reconsult_grammar :-
	reconsult_grammar_file(dutch).

compile_grammar_file(File) :-
	compile(File).

reconsult_grammar_file(File) :-
	reconsult(File).

:- initialize_flag(top_features,main).
:- initialize_flag(parser,td).
:- initialize_flag(generator,td).

:- version('F. Pereira''s Extraposition Grammars').

:- compile_grammar.




