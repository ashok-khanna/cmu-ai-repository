query_proceed :-
	tcl_eval('SP_more'),
	flag(proceed,off).

