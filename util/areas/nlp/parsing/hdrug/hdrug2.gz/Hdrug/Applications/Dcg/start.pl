:- compile(decl).
:- compile(gram).
:- compile(suite).
:- compile(parser).
:- compile(generator).


