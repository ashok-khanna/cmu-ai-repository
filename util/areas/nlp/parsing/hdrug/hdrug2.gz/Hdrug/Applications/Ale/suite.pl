/*
?- setof(X,B^C^D^lex(X,B,C,D),All).

All = [a,be,believe,believed,believes,book,bother,bothered,bothers,can,every,give,given,gives,he,her,him,i,is,it,kim,me,my,person,persuade,persuaded,persuades,red,s,sandy,see,seems,seen,sees,she,tend,tends,that,the,them,there,they,to,tries,try,us,walk,walks,we,who,whom,you] ?
*/

sentence(1,[she,walks]).
sentence(2,[sandy,sees,kim]).
sentence(3,[she,gives,every,person,a,book]).
sentence(4,[sandy,is,seen]).
sentence(5,[it,bothers,sandy,that,she,walks]).
sentence(6,[she,tries,to,see,kim]).
sentence(7,[we,walk]).
sentence(8,[every,person,can,persuade,me,to,walk]).
sentence(9,[can,every,person,walk]).
sentence(10,[i,see,a,person,that,walks]).
sentence(11,[every,person,can,persuade,me,to,try,to,walk]).
sentence(12,[i,see,sandy,s,book]).


user_max(L,Max) :-
	Max is 60000 + (L * L * 1000).

