:- use_module( library(concat)).

% parsers and generators
:- add_flag(parser_mode,parser).
:- initialize_flag(parser,parser).

:- version('Ale 2.0 - Hpsg Grammar').

:- initialize_flag(ale_portray,on).

:- del_portray(ale_portray).
ale_portray(X-Y) :-
	flag(ale_portray,on),
	pp_fs(X-Y,[]).

:- add_portray(ale_portray).

semantics(ale(A,B,C),Sem) :-
	add_to(synsem:loc:cont:Sem,Tag,bot,[],Iqs),
	append(C,Iqs,Niqs),
	ud(A-B,Tag-bot,Niqs,_).

% Extending GUI
gram_startup_hook_end :-
	initialize_ale_flags,
	update_ale_flags,
	tcl_eval('source ale.tcl').

start_hook(parse,_,o(_,W,_),_) :-
	length(W,L),
        concat('set chartlength ',L,Cmd),
	tcl_eval(Cmd).

result_hook(parse,_,o(Obj,_,_),_) :-
	semantics(Obj,Sem),
	tk_ale(Sem-bot,[]),
	query_proceed.

% ALE does not have a top category, but I don't want
% to see the value `undefined', as this looks like something
% goes wrong.

top(bot,_).

:- initialize_flag(top_features,bot).

initialize_ale_flags :-
	initialize_ale_flag(lexs),
	initialize_ale_flag(macros),
	initialize_ale_flag(lex_rules),
	initialize_ale_flag(types),
	initialize_ale_flag(clauses),
	initialize_ale_flag(rules),
	tcl_eval('set chartlength 0').

initialize_ale_flag(Key) :-
	% set ale(Key) {}
	concat_all(['set ale(',Key,') {}'],Cmd),
	tcl_eval(Cmd).

update_ale_flags :-
	update_ale_lexs,
	update_ale_macros,
	update_ale_lex_rules,
	update_ale_types,
	update_ale_clauses,
	update_ale_rules,
	update_ale_empty,
	update_chartlength.

update_chartlength :-
	(  parsing(W)
	-> length(W,L),
           concat('set chartlength ',L,Cmd),
	   tcl_eval(Cmd)
	;  true
	).

update_ale_empty :-
	(  empty(_)
	-> tcl_eval('set ale(empty) 1')
	;  tcl_eval('set ale(empty) 0')
	).
	

update_ale_types :-
	write('Updating types...'),ttyflush,
	setof(Name,type(Name),Names),
	( reverse(Names,RNames),
	  member(N,RNames),
          add_ale_array_flag(types,N),
	  fail
        ; true
        ),
	write('Done.'),nl.

update_ale_rules :-
	write('Updating rules...'),ttyflush,
	setof(Name,X^rule(Name,X),Names),
	( reverse(Names,RNames),
	  member(N,RNames),
          add_ale_array_flag(rules,N),
	  fail
        ; true
        ),
	write('Done.'),nl.

update_ale_clauses :-
	write('Updating clauses...'),ttyflush,
	setof(Name,a_clause(Name),Names),
	( reverse(Names,RNames),
	  member(N,RNames),
          add_ale_array_flag(clauses,N),
	  fail
        ; true
        ),
	write('Done.'),nl.

a_clause(F/A) :-
	if(Head,_Body),
	Head =.. [F|Tail],
	length(Tail,A).

update_ale_lexs :-
	write('Updating lexical entries...'),ttyflush,
	setof(Name,A^B^C^lex(Name,A,B,C),Names),
	( reverse(Names,RNames),
	  member(N,RNames),
          add_ale_array_flag(lexs,N),
	  fail
        ; true
        ),
	write('Done.'),nl.

update_ale_lex_rules :-
	write('Updating lexical rules...'),ttyflush,
	setof(Name,A^lex_rule(Name,A),Names),
	( reverse(Names,RNames),
	  member(N,RNames),
          add_ale_array_flag(lex_rules,N),
	  fail
        ; true
        ),
	write('Done.'),nl.

update_ale_macros :-
	write('Updating macro names...'),ttyflush,
	setof(Name,V^macro(Name,V),Names),
	( reverse(Names,RNames),
	  member(N,RNames),
          add_ale_array_flag(macros,N),
	  fail
        ; true
        ),
	write('Done.'),nl.

add_ale_array_flag(Key,Val0) :-
	term_atom(Val0,Val),
	concat_all(['set ale(',Key,') [linsert $ale(',Key,') 0 ',Val,' ]'],Atom),
	tcl_eval(Atom).


show_it(Output,Type,Thing0) :-
	atom_term(Thing0,Thing),
	show_it0(Output,Type,Thing).

show_it0(ale,Type,Thing) :-
	( show_ale(Type,Thing)
	; true
        ),
	nl, write('| ?- '),ttyflush.  % succeeds after all have been shown..

show_it0(tk,Type,Thing) :-
	show_tk(Type,Thing).

show_it0(latex,Type,Thing) :-
	show_latex(Type,Thing).

show_ale(rules,X) :-
	rule(X).

show_ale(clauses,X) :-
	show_clause(X).

show_ale(lexs,X) :-
	lex(X).

show_ale(macros,X) :-
	macro(X).

show_ale(lex_rules,X) :-
	lex_rule(X).

show_ale(types,X) :-
	show_type(X).

show_ale(object,X) :-
	object(X,o(ale(A,B,C),_,_)),
	pp_fs(A-B,C).

% predicate not defined..???
% extensionalise_list([],_).
% extensionalise_list([A-B|T],Iqs) :-
% 	extensionalise(A,B,Iqs),
% 	extensionalise_list(T,Iqs).

show_edge(Kind,L0,R0) :-
	atom_chars(L0,Lstr),
	number_chars(L,Lstr),
	atom_chars(R0,Rstr),
	number_chars(R,Rstr),
	show_edge0(Kind,L,R).

show_edge0(ale,M,N) :-
	(   nl, write('COMPLETED CATEGORIES SPANNING: '),
            write_out(M,N),
            nl, edge(I,M,N,Tag,SVs,Iqs,Dtrs,RuleName),
            nl, edge_act(I,M,N,Tag,SVs,Iqs,Dtrs,RuleName), 
            tcl_eval('SP_sub_more .edge.end.more'),
	    flag(proceed,off)
        ; true
        ),
	nl, write('| ?- '), ttyflush.

show_edge0(tk,L,R) :-
	( edge(_I,L,R,Tag,SVs,Iqs,_Dtrs,_RuleName),
	  tk_ale(Tag-SVs,Iqs),
	  tcl_eval('SP_sub_more .edge.end.more'),
	  flag(proceed,off)
        ; true
        ).

show_edge0(latex,L,R) :-
	( edge(_I,L,R,Tag,SVs,Iqs,_Dtrs,_RuleName),
	  latex_ale(Tag-SVs,Iqs),
	  tcl_eval('SP_sub_more .edge.end.more'),
	  flag(proceed,off)
        ; true
        ).


%%%%%%%%%%%%% defaults to print / not print types and features %%%%%%%%%


:- no_write_feat(conx).

