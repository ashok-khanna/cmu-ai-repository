:- use_module( library(decons),  [ prolog_conjunction/2 ]).
:- use_module( library(concat)).

top(s,tree(X,_,_)) :-
	X <=> s,
	X <=> vsecond,
	X:gap ==> empty.

top(q,tree(X,_,_)) :-
	X <=> s,
	X <=> vfirst,
	X:gap ==> empty.

% SEMANTICS/2
% semantics(Node,Sem)
% defines the semantics Sem of node Node. Is used: 
% 
% 1. in order to determine the semantic-head of a rule 
%    (for head-driven generation).
% 2. to instantiate the semantics of a node, at the
%    start of generation. 
% 3. to print the result of parsing.

semantics(tree(Sign,_,_),Sem) :-
	Sign:sem <=> Sem.


user_clause(rule(A,B,C,D),Body) :-
	call_residue(rule(A,B,C,D),Cons),
	rewrite_body(Cons,[],Body,[]).

user_clause(Head,Body) :-
	clause(lex(A,B),Body0),
	(   atomic(A) 
        ->  Head =.. [A,B]
        ;   A = [te,X],
	    concat('te_',X,F),
	    Head =.. [F,B]
	),
	prolog_conjunction(Body0,Body).

