sentence(a,[john,sleeps]).
sentence(b,[john,kisses,mary]).
sentence(c,[mary,kisses,john]).
