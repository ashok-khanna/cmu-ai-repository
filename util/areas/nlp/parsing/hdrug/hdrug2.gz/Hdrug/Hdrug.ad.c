! colors

*background:		burlywood3
*activeBackground:	burlywood1
*foreground:		Black

! canvas
*Canvas*background:	khaki3

! scrollbar
*Scrollbar*foreground:  burlywood3
*Scrollbar*background:  burlywood3
*Scrollbar*activeForeground: burlywood1

! listbox
*Listbox*foreground: black
*Listbox*background: burlywood3
*Listbox*selectBackground: burlywood1

! fonts
*Font:		-adobe-helvetica-bold-r-normal--14-140-*-*-*-*-iso8859-*
*Listbox*font:	-adobe-times-bold-r-normal-*-14-*-*-*-*-*-*-*

! entries
*Entry*foreground: black
*Entry*background: white

*t*Label*font:  -adobe-helvetica-bold-o-normal--14-140-*-*-*-*-iso8859-*
