:
# FindCommon -- Copyright 1990 Liam R. Quin.  All Rights Reserved.
# This code is NOT in the public domain.
# See the file COPYRIGHT for full details.
#
# $Id: FindCommon.sh,v 1.2 90/10/06 00:50:31 lee Rel1-10 $

# Find the most common words in the database.
# usage is % n, where n is the n most comon words to find

lqword -a | sed -e 's/^......................\(.........\)..\(..*\)$/\1	\2/' |
sort -nr | sed ${1-500}q

exit $?

#         1 |       0 |       2 | pcpaintbrush
#         2 |       0 |       2 | escape
#         3 |       0 |       1 | durham
#         4 |   60928 |      12 | making
#         5 |       0 |       1 | ethical
#         6 |       0 |       1 | committing

# $Log:	FindCommon.sh,v $
# Revision 1.2  90/10/06  00:50:31  lee
# Prepared for first beta release.
# 
#
