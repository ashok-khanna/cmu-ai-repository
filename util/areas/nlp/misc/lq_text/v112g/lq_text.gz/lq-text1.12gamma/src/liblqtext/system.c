/* system.c -- Copyright 1989 Liam R. Quin.  All Rights Reserved.
 * This code is NOT in the public domain.
 * See the file COPYRIGHT for full details.
 *
 * This is not a very portable way of doing things... and certainly not
 * a very fast one.  MUST be re-written.
 * Only for use from within curses.
 *
 * Lee
 *
 * $Id: system.c,v 1.4 92/02/22 23:31:50 lee Exp $
 */

#ifdef ultrix
# include <cursesX.h>
#else
# include <curses.h>
#endif

#ifndef echo
extern int echo();
#endif
#ifndef wmove
extern int wmove();
#endif
#ifndef nl
extern int nl();
#endif
#ifndef noecho
extern int noecho();
#endif
#ifndef nonl
extern int nonl();
#endif
#ifndef wrefresh
extern int wrefresh();
#endif
#ifndef waddstr
extern int waddstr();
#endif
#ifndef wclear
extern int wclear();
#endif

int
MySystem(string)
    char *string;
{
    int val;

    clearok(stdscr, TRUE);
    clear();
    refresh();
    noraw();
    echo();
    nl();
#ifdef SYSV
    val = system("stty opost icanon onlcr icrnl echo");
#else
    val = system("stty cooked sane");
#endif
    (void) system(string);
    fprintf(stderr, "\n[press  return  to continue] ");
    raw();
    noecho();
    nonl();
    (void) getch();
    clearok(stdscr, TRUE);
    mvwaddstr(stdscr, 10, 10, "                        "); /* ???!?? */

    return val;
}

