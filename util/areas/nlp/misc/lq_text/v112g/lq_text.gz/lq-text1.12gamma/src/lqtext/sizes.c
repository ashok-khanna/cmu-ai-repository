/* sizes.c -- Copyright 1990 Liam R. Quin.  All Rights Reserved.
 * This code is NOT in the public domain.
 * See the file COPYRIGHT for full details.
 */

#ifndef lint
 static char *Rcs = "$Id: sizes.c,v 1.3 90/10/06 00:51:03 lee Rel1-10 $";
#endif

#include "globals.h" /* defines and declarations for database filenames */

#include <stdio.h>
#include <sys/types.h>
#include "fileinfo.h"
#include "wordinfo.h"
#include "pblock.h"
#include "wordrules.h"
#include "wordindex.h"

main()
{
    printf("FileInfo  %u bytes\n", sizeof(t_FileInfo));
    printf("WordInfo  %u bytes\n", sizeof(t_WordInfo));
    printf("WordPlace %u bytes\n", sizeof(t_WordPlace));
    printf("pblock    %u bytes\n", sizeof(t_pblock));
}
