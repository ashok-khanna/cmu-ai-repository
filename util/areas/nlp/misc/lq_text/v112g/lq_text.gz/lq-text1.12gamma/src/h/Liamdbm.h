/* Liamdbm.h -- Copyright 1989 Liam R. Quin.  All Rights Reserved.
 * This code is NOT in the public domain.
 * See the file COPYRIGHT for full details.
 */

/* $Id: Liamdbm.h,v 1.2 90/10/06 02:18:14 lee Rel1-10 $
 *
 * This is used with gdbm.  I have not linked with gdbm, and, if you
 * wish to do so, you must be careful not to voilate any copyright
 * notices... (sigh)
 *
 * The version of gdbm for which I had a manual is rather old and had no
 * ndbm compatibility.
 */

#include "gdbm.h"
extern datum gdbm_fetch();
extern datum gdbm_firstkey();
extern datum gdbm_nextkey();

typedef char DBM;

#define dbm_store(db, key, data, mode) gdbm_store(db, key, data)
/* gdbm_open is stupder than ndbm_open.... */
#define dbm_open(FileName, Mode, m) gdbm_open(FileName, 512, Mode, 0)
#define dbm_fetch gdbm_fetch
#define dbm_close gdbm_close
#define dbm_firstkey gdbm_firstkey
#define dbm_nextkey gdbm_nextkey

/*
 * $Log:	Liamdbm.h,v $
 * Revision 1.2  90/10/06  02:18:14  lee
 * Prepared for first beta release.
 * 
 *
 */
