#! /bin/sh

LQTEXTDIR=test$$
export LQTEXTDIR

trap 'echo "**** INTERRUPTED"; /bin/rm -rf $LQTEXTDIR; exit' 0 1 2 3 15

mkdir $LQTEXTDIR

# tests that do not need lq-text to be built
testbin/dbmtry 1000
testbin/dbmtry 5000

# tests that need only the libraries
testbin/NumberTest 1000

# tests that use the clients
