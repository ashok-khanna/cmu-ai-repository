/* wpstream.h -- Copyright 1989 Liam R. Quin.  All Rights Reserved.
 * This code is NOT in the public domain.
 * See the file COPYRIGHT for full details.
 */

/* $Id: wpstream.h,v 1.1 92/08/24 00:38:35 lee Exp $
 */

#ifndef WSTREAM_H

# define WSTREAM_H
typedef struct {
    t_WID WID;
    unsigned char *Buffer;
    unsigned char *BufferPointer;
    unsigned long BlockOffset; /* offset into Data dfile */
    unsigned long NextOffset;
    int BlockLength;
    int NextBlockLength;
} t_WordStream;

#endif WSTREAM_H
