/* wordindex.h -- Copyright 1989 Liam R. Quin.  All Rights Reserved.
 * This code is NOT in the public domain.
 * See the file COPYRIGHT for full details.
 */

/* (this file is currently empty, but might return...) */

/*
 * $Id: wordindex.h,v 1.2 90/10/06 02:18:38 lee Rel1-10 $
 *
 * $Log:	wordindex.h,v $
 * Revision 1.2  90/10/06  02:18:38  lee
 * Prepared for first beta release.
 * 
 * Revision 1.1  90/08/09  19:16:02  lee
 * Initial revision
 * 
 * Revision 2.1  89/10/02  01:16:06  lee
 * New index format, with Block/WordInBlock/Flags/BytesSkipped info.
 * 
 * Revision 1.2  89/09/16  21:15:47  lee
 * First demonstratable version.
 * 
 * Revision 1.1  89/09/07  21:06:13  lee
 * Initial revision
 * 
 *
 */
