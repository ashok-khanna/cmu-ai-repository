// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <stream.h>
#include <math.h>
#include "coordinate.h"
#include "../matrix/amino.h"
#include "local.h"

double LengthFactor;

void c_a::input(char* BuffLine)
{
  char AminoTriplet[4];
  double X,Y,Z;
  sscanf(
	 BuffLine,"%d %s %s %lf %lf %lf",
	 &Position,PositionID,AminoTriplet,
	 &X,&Y,&Z
	 );
  Amino = amino(AminoTriplet);
  Coordinate.input(X,Y,Z);
}

main(int ArgCnt,char** ArgVal)
{
  if(ArgCnt<3)
    {
      cerr << "Usage: bury [CA file] [Radius]\n";
      exit(1);
    }
  double BuriedRadius = atof(ArgVal[2]);

  FILE* CAFile;
  if(NULL==(CAFile=fopen(ArgVal[1],"r")))
    {
      cerr << "Can't open CA File!!\n";
      exit(1);
    }

  c_a* Cas = new c_a[2048];
  int LineCnt = 0;
  char BuffLine[1024];
  while(fgets(BuffLine,1023,CAFile))
    {
      Cas[LineCnt  ].buriedRadius(BuriedRadius);
      Cas[LineCnt++].input(BuffLine);

    }
  for(int I=0;I<LineCnt-1;++I)
    {
      for(int J=I+1;J<LineCnt;++J)
	Cas[I].buryCnt(Cas[J]);
    }

  printf("#Begin %s Buried Radius %10.5lf\n",ArgVal[2],BuriedRadius);

  for(    I=0;I<LineCnt;++I)
    {
      printf("%4d\n",Cas[I].buryCnt());
    }
}
