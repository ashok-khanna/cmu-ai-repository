// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <ctype.h>
#include <string.h>
#include "field.h"

int getField(char* Buff,String Field[])
{
  int BuffStart = 0;
  while(isspace(Buff[BuffStart++])){}
  BuffStart--;
  String Line = Buff+BuffStart;
  int NW = split(Line, Field, 32, RXwhite);
  return NW;
}

int beginCheck(void)
{
  char    Buff[1024];
  int Width;

  if(NULL==gets(Buff))
    return 0;
  if(0==strncmp(Buff,"#Width",6))
    {
      sscanf(Buff+8,"%d",&Width);
    }
  else
    {
      return 0;
    }
  if(NULL==gets(Buff))
    return 0;
  if(0!=strncmp(Buff,"#Begin",6))
    return 0;
  return Width;
}
