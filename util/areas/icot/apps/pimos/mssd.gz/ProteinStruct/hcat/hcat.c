// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

main(int argc,char** argv)
{
  int    N = argc-1;
  FILE*  File[N];

  for(int I=0;I<N;++I)
    {
      if(NULL==(File[I]=fopen(argv[I+1],"r")))
	{
	  printf("Can't open file \"%s\"\n",argv[I+1]);
	  exit(1);
	}
    }

  int    EndFlag[N];

  for(I=0;I<N;++I)
    {
      EndFlag[I] = 1;
    }

  char   Buff[1024];
  int EndOfFiles = 1;

  while(EndOfFiles)
    {
      EndOfFiles = 0;
      for(int I=0;I<N;++I)
	{
	  if(0==EndFlag[I])
	    continue;
	  else
	    {
	      if(NULL==fgets(Buff,1023,File[I]))
		{
		  EndFlag[I] = 0;
		}
	      else
		{
		  Buff[strlen(Buff)-1] = '\0';
		  printf(Buff);
		}
	    }
	  EndOfFiles += EndFlag[I];
	}
      if(EndOfFiles) printf("\n");
    }
}
