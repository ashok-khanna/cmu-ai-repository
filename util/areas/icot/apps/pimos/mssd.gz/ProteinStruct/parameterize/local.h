// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

class c_a
{
  int         Position;
  char        PositionID[5];       
  amino       Amino;
  coordinate  Coordinate;
  double      BuriedRadius;
  int         BuryCnt;
 public:
  inline c_a(void)
    {
      Position = -1;
      BuryCnt  =  1;
    }
  inline c_a(double BR)
    {
      Position     = -1;
      BuriedRadius = BR;
      BuryCnt      =  1;
    }
  inline void buriedRadius(double BR)
    {
      BuriedRadius = BR;
    }
  inline int position(void)
    {
      return Position;
    }
  inline char* positionID(void)
    {
      return PositionID;
    }
  inline coordinate d3position(void)
    {
      return Coordinate;
    }
  inline char aminoChar(void)
    {
      return Amino.single();
    }
  inline double aminoHpathy(void)
    {
      return Amino.hpathy();
    }
  inline double aminoCharge(void)
    {
      return Amino.charge();
    }
  inline double aminoVolume(void)
    {
      return Amino.volume();
    }
  inline double aminoWeight(void)
    {
      return Amino.weight();
    }
  void input(char* BuffLine);
  inline void buryCnt(c_a& C_A)
    {
      double Distance  = (Coordinate - C_A.Coordinate).length();
      if(Distance < BuriedRadius)
	{
	  BuryCnt++;
	  C_A.BuryCnt++;
	}
    }
  inline int buryCnt(void)
    {
      return BuryCnt;
    }
};

