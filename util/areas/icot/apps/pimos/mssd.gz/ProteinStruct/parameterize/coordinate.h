// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

class coordinate
{
  double X,Y,Z;
 public:
  inline coordinate(void)
    {
      X = Y = Z = 0.0;
    }
  inline coordinate(double Xi,double Yi,double Zi)
    {
      X = Xi;
      Y = Yi;
      Z = Zi;
    }
  inline input(double Xi,double Yi,double Zi)
    {
      X = Xi;
      Y = Yi;
      Z = Zi;
    }
  inline double length(void)
    {
      return sqrt(X*X+Y*Y+Z*Z);
    }
  inline normalize(void)
    {
      double L = length();
      X/=L;
      Y/=L;
      Z/=L;
    }
  inline coordinate normal(void)
    {
      double L=length();
      return coordinate(X/L,Y/L,Z/L);
    }
  inline double x(void)     {return X;}
  inline double y(void)     {return Y;}
  inline double z(void)     {return Z;}
  inline void   print(void)
    {
      printf("%10.5lf %10.5lf %10.5lf\n",Z,Y,X);
    }
  inline void   x(double Xn){X = Xn;}
  inline void   y(double Yn){Y = Yn;}
  inline void   z(double Zn){Z = Zn;}
  inline void   set(double Xn, double Yn, double Zn){X=Xn;Y=Yn;Z=Zn;}

  friend void       operator=(coordinate& A,coordinate& B);
  friend double     operator*(coordinate& A,coordinate& B);//scalar
  friend coordinate operator%(coordinate& A,coordinate& B);//vector
  friend coordinate operator+(coordinate& A,coordinate& B);
  friend coordinate operator-(coordinate& A,coordinate& B);
  friend coordinate operator-(coordinate& A);
  friend coordinate operator*(double K,coordinate& A);
  friend coordinate operator*(coordinate& A,double K);
  friend coordinate operator/(coordinate& A,double K);
};

inline void operator=(coordinate& A,coordinate& B)
{
  A.X = B.X;
  A.Y = B.Y;
  A.Z = B.Z;
}

inline double operator*(coordinate& A,coordinate& B)
{
  return A.X*B.X + A.Y*B.Y + A.Z*B.Z;
}

inline coordinate operator%(coordinate& A,coordinate& B)
{
  coordinate C;
  C.X = A.Y*B.Z - A.Z*B.Y;
  C.Y = A.Z*B.X - A.X*B.Z;
  C.Z = A.X*B.Y - A.Y*B.X;
  return C;
}

inline coordinate operator+(coordinate& A,coordinate& B)
{
  return coordinate(A.X+B.X,A.Y+B.Y,A.Z+B.Z);
}

inline coordinate operator-(coordinate& A,coordinate& B)
{
  return coordinate(A.X-B.X,A.Y-B.Y,A.Z-B.Z);
}

inline coordinate operator-(coordinate& A)
{
  return coordinate(-A.X,-A.Y,-A.Z);
}

inline coordinate operator*(double K,coordinate& A)
{
  return coordinate(K*A.X,K*A.Y,K*A.Z);
}

inline coordinate operator*(coordinate& A,double K)
{
  return K*A;
}

inline coordinate operator/(coordinate& A,double K)
{
  return coordinate(A.X/K,A.Y/K,A.Z/K);
}

class unitVectors
{
  coordinate I;
  coordinate J;
  coordinate K;
 public:
  inline unitVectors(void){}
  inline unitVectors(coordinate& A,coordinate& B)
    {
      K = A.normal();
      J = (A%B).normal();
      I = (J%A).normal();
    }
  inline coordinate toLocalCoordinate(coordinate& A)
    {
      return coordinate(I*A,J*A,K*A);
    }
  inline coordinate fromLocalCoordinate(coordinate& A)
    {
      return A.x()*I+A.y()*J+A.z()*K;
    }
  inline print(void)
    {
      printf("I= ");I.print();
      printf("J= ");J.print();
      printf("K= ");K.print();
    }
};
      
