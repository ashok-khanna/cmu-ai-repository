// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <stream.h>
#include <math.h>
#include "coordinate.h"
#include "../amino/amino.h"
#include "../wavelet/wavelet.h"
#include "local.h"

void c_a::input(char* BuffLine)
{
  char AminoTriplet[4];
  double X,Y,Z;
  sscanf(
	 BuffLine,"%d %s %s %lf %lf %lf",
	 &Position,PositionID,AminoTriplet,
	 &X,&Y,&Z
	 );
  Amino = amino(AminoTriplet);
  Coordinate.input(X,Y,Z);
}


main(int ArgCnt,char** ArgVal)
{
  if(ArgCnt<3)
    {
      cerr << "Usage: local -[wpsbt] [CA file] [Width]\n";
      exit(1);
    }
  int WaveFlag = 0;
  int PropFlag = 0;
  int SeqsFlag = 0;
  int BuryFlag = 0;
  int StrnFlag = 0;

  if(ArgVal[1][0] == '-')
    {
      for(int I=1;I<strlen(ArgVal[1]);++I)
	{
	  switch(ArgVal[1][I])
	    {
	    case 'w':WaveFlag = 1;break;
	    case 'p':PropFlag = 1;break;
	    case 's':SeqsFlag = 1;break;
	    case 'b':BuryFlag = 1;break;
	    case 't':StrnFlag = 1;break;
	    }
	}
    }
  if(StrnFlag)
    {
      WaveFlag = 0;
      PropFlag = 0;
      SeqsFlag = 0;
      BuryFlag = 0;
    }

  FILE* CAFile;
  if(NULL==(CAFile=fopen(ArgVal[2],"r")))
    {
      cerr << "Can't open CA File!!\n";
      exit(1);
    }

  c_a* Cas = new c_a[2048];
  int LineCnt = 0;
  char BuffLine[1024];
  while(fgets(BuffLine,1023,CAFile))
    {
      Cas[LineCnt++].input(BuffLine);
    }
  if(PropFlag)
    initProperty();

  int Width = 2;
  if(!StrnFlag)
    {
      if(ArgCnt < 4)
	{
	  cerr << "Too few arguments!\n";
	  exit(1);
	}
      Width = atoi(ArgVal[3]);
    }

  double BuriedRadius = 10.0;
  double MaxNumberOfResidues = pow(BuriedRadius,2.45)*0.15;
  
  if(BuryFlag)
    {
      for(int I=0;I<LineCnt-1;++I)
	{
	  Cas[I].buriedRadius(BuriedRadius);
	  for(int J=I+1;J<LineCnt;++J)
	    Cas[I].buryCnt(Cas[J]);
	}
    }

  wavelet* Wavelet = waveletDB(5,Width);
  int P = 0;
  if(StrnFlag)
    printf("<");
  else
    printf("#Begin %s Width %4d\n",ArgVal[2],Width);

  char      AminoSeq[Width+1];
  double NF = sqrt(double(Width));
  while(P<LineCnt)
    {
      coordinate TVector[5];
      double     Hpathy [5];
      double     Charge [5];
      double     Volume [5];
      double     Weight [5];
      double     Bury   [5];
      if(PropFlag || BuryFlag)
	for(int I=0;I<5;++I)
	  {
	    Hpathy[I] = 0.0;
	    Charge[I] = 0.0;
	    Volume[I] = 0.0;
	    Weight[I] = 0.0;
	    Bury  [I] = 0.0;
	  }
      AminoSeq[Width] = '\0';
      for(int Offset=0;Offset<Width;++Offset)
	{
	  if(P+Offset >= LineCnt)
	    break;
	  if( Offset!=0)
	    {
	      if(Cas[P+Offset-1].position()+1<Cas[P+Offset].position())
		{
		  cerr <<
		    form("Data inconsistency detected in %s\n",ArgVal[2]);
		  break;
		}
	      else if(Cas[P+Offset-1].position()+1>Cas[P+Offset].position())
		{
		  cerr <<
		    form("Invalid data! probably data duplicated in  %s\n",
			 ArgVal[2]);
		  printf("Data duplicated Here!\n");
		  break;
		}
	      else if
		(
		 (
		  Cas[P+Offset-1].d3position()-
		  Cas[P+Offset].d3position()).length()
		   >5.0
		 )
		  {
		    cerr << form("Distance too long in %s\n",ArgVal[2]);
		    break;
		  }
	    }
	  for(int Order=0;Order<5;++Order)
	    {
	      if(WaveFlag)
		TVector[Order] = TVector[Order]+
		    Cas[P+Offset].d3position()*Wavelet->position(Order,Offset);
	      if(PropFlag)
		{
		  Hpathy[Order]+= Cas[P+Offset].aminoHpathy()
		    *Wavelet->position(Order,Offset);
		  Charge[Order]+= Cas[P+Offset].aminoCharge()
		    *Wavelet->position(Order,Offset);
		  Volume[Order]+= Cas[P+Offset].aminoVolume()
		      *Wavelet->position(Order,Offset);
		  Weight[Order]+= Cas[P+Offset].aminoWeight()
		    *Wavelet->position(Order,Offset);
		}
	      if(BuryFlag)
		{
		  double BuriedDepth =
		    (double(Cas[P+Offset].buryCnt())-MaxNumberOfResidues/2.0)
		      /(MaxNumberOfResidues/2.0)*BuriedRadius;
		  Bury[Order]+=
		     BuriedDepth*Wavelet->position(Order,Offset);
		}
	    }
	  if(SeqsFlag||StrnFlag)
	    AminoSeq[Offset] = Cas[P+Offset].aminoChar();
	}
      if(Offset==Width)
	{
	  if(StrnFlag)
	    printf("%c",AminoSeq[0]);
	  else
	    printf("%4d ",Cas[P].position());
	  if(WaveFlag)
	    {
	      double SL = double(Width)*0.7;
              double Parity =
		     ((TVector[1]-TVector[2])%(TVector[2]-TVector[3]))*
		     (TVector[3]-TVector[4])/SL/SL;

	      printf("%10.5lf %10.5lf %10.5lf %10.5lf ",
		     TVector[1].length()/NF,
		     TVector[2].length()/NF,
		     TVector[3].length()/NF,
		     TVector[4].length()/NF
		     );
	      printf("%10.5lf %10.5lf %10.5lf %10.5lf",
		     (TVector[1]-TVector[2]).length()/NF,
		     (TVector[2]-TVector[3]).length()/NF,
		     (TVector[3]-TVector[4]).length()/NF,
		     (TVector[4]-TVector[1]).length()/NF
		     );
	      printf("%10.5lf %10.5lf ",
		     (TVector[1]-TVector[3]).length()/NF,
		     (TVector[2]-TVector[4]).length()/NF
		     );
	      printf("%10.5lf ",Parity/NF);

	    }
	  if(PropFlag)
	    {
	      for(int O=0;O<5;++O)
		{
		  printf("%10.5lf ",Hpathy[O]/NF);
		  printf("%10.5lf ",Charge[O]/NF);
		  printf("%10.5lf ",Volume[O]/NF);
		  printf("%10.5lf ",Weight[O]/NF);
		}
	    }
	  if(BuryFlag)
	    {
	      for(int O=0;O<5;++O)
		{
		  printf("%10.5lf ",Bury[O]/2.0);
		}
	    }
	  if(SeqsFlag)
	    {
	      printf("%s",AminoSeq);
	    }
	  if(!StrnFlag)
	    printf("\n");
	  P++;
	}
      else if(P+Offset == LineCnt)
	{
	  break;
	}
      else
	{
	  if(StrnFlag)
	    {
	      printf("%c><",AminoSeq[1]);
	    }
	  else
	    {
	      printf("#End   Flagment\n");
	      printf("#Begin Flagment\n");
	    }
	  P+=Offset;
	}
    }
  if(StrnFlag)
    printf("%c>\n",AminoSeq[1]);
  else
    printf("#End\n");
}



