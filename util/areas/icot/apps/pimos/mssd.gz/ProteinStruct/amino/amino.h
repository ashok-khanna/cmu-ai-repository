// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <string.h>
#include <stream.h>

extern double AminoHpathy[];
extern double AminoCharge[];
extern double AminoVolume[];
extern double AminoWeight[];

void initProperty(void);

class amino
{
  char Triplet[4];
  char Single;
  int  ID;
 public:
  amino(void);
  amino(char*);
  amino(char);
  amino(int);
  void input(char*);
  void input(char);
  void input(int);
  inline char*  triplet(void){return Triplet;}
  inline char   single(void) {return Single;}
  inline int    id(void)     {return ID;}
  inline double hpathy(void) {return AminoHpathy[ID];}
  inline double charge(void) {return AminoCharge[ID];}
  inline double volume(void) {return AminoVolume[ID];}
  inline double weight(void) {return AminoWeight[ID];}
  friend amino operator=(amino&,amino&);
};


