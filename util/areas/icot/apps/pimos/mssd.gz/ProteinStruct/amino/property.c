// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdio.h>
#include <stream.h>
#include <stdlib.h>
#include <math.h>

#include "../wavelet/wavelet.h"
#include "../matrix/amino.h"

main(int ArgCnt, char** ArgVal)
{
  if(ArgCnt<2)
    {
      cerr << "Too few arguments\n";
      exit(1);
    }
  initProperty();
  char BuffLine[1024];
  int Width = atoi(ArgVal[1]);
  wavelet Wavelets(5,Width);
  double HpathyD[5];
  double ChargeD[5];
  double VolumeD[5];
  double WeightD[5];

  while(gets(BuffLine))
    {
      int Length = strlen(BuffLine);
      printf("# Length = %d,  Width = %d\n#Begin\n",Length,Width);
      for(int I=0;I<Length-Width+1;++I)
	{
	  for(int K=0;K<5;++K)
	    {
	      HpathyD[K]=0;
	      ChargeD[K]=0;
	      VolumeD[K]=0;
	      WeightD[K]=0;
	    }
	  for(int J=0;J<Width;++J)
	    {
	      amino Amino(BuffLine[I+J]);
	      for(int K=0;K<5;++K)
		{
		  HpathyD[K] += Amino.hpathy()*Wavelets.position(K,J);
		  ChargeD[K] += Amino.charge()*Wavelets.position(K,J);
		  VolumeD[K] += Amino.volume()*Wavelets.position(K,J);
		  WeightD[K] += Amino.weight()*Wavelets.position(K,J);
		}
	    }
	  printf("%4d ",I);
	  for(    K=0;K<5;++K)
	    {
	      printf("%10.5lf %10.5lf %10.5lf %10.5lf ",
			   HpathyD[K],ChargeD[K],VolumeD[K],WeightD[K]);
	    }
	  printf("\n");
	}
      printf("#End\n");
    }
}


