// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdlib.h>
#include <stream.h>
#include <math.h>
#include "wavelet.h"

const int NumberOfLevels   = 12;
const int NumberOfWavelets = 5;
const int LevelWidth[]     = {5,9,13,17,25,33,49,65,97,129,193,257};
main()
{
  wavelet* Wavelets[6];

  for(int L=0;L<6;++L)
    {
      Wavelets[L] = waveletDB(NumberOfWavelets,LevelWidth[L]);
      for(int I=0;I<Wavelets[L]->numberOfWavelets();++I)
	{
	  cout <<form("get_wavelet(%d,%d,Wavelet) :- true| \n",L,I);
	  cout << "    Wavelet = {";
	  for(int J=0;J<Wavelets[L]->width()-1;++J)
	    {
	      if(J%5==0)
		cout << "\n        ";
	      cout << form("%10.5lf,",Wavelets[L]->position(I,J));
	    }
	  cout <<
	    form("%10.5lf\n",Wavelets[L]->position(I,Wavelets[L]->width()-1));
	  cout << "    }.\n\n";
	}
    }
}
