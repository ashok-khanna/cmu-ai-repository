// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <stream.h>
#include <string.h>
#include <ctype.h>
#include "../amino/amino.h"
#include "../mssd/mssd.h"
#include "astar.h"
#include "alignInverse.h"

const int MaxProfileLength = 900;
const int MaxSeqLength     = 900;

main(int ArgCnt, char** ArgVal)
{
  if(ArgCnt<4)
    {
      cerr <<
	form("Too few arguments!\nUsage\n%s [profile file] [gap cost] [slide cost]\n",
	     ArgVal[0]);
      exit(1);
    }
  double GapPenalty   = atof(ArgVal[2]);
  double SlidePenalty = atof(ArgVal[3]);

  FILE* ProfileFile;
  if(NULL==(ProfileFile=fopen(ArgVal[1],"r")))
    {
      cerr << form("Can't open file %s.\n",ArgVal[1]);
      exit(1);
    }
  char BuffLine[1024];
  if(NULL==gets(BuffLine))
    {
      cerr << "Invalid input of sequence!\n";
    }

  printf("GapPenalty    : %10.5lf\n",GapPenalty);
  printf("SlidePenalty  : %10.5lf\n",SlidePenalty);


  char PDBEntName[8];
  int I = 0;
  while(BuffLine[I] != ':')
    {
      PDBEntName[I] = BuffLine[I++];
    }
  PDBEntName[I] = '\0';
  cerr << PDBEntName << '\n';

  int Length = strlen(BuffLine+I+1);
  int Size = MaxProfileLength*Length;

  initFreeMapPosition(Size);
  initFreeNode(Size);

  for(;;)
    {
      alignProfile Align(ProfileFile,BuffLine+I+1,GapPenalty,SlidePenalty);
      node* GoalNode = Align.astarSearch();
      double ScoreWithoutGaps = Align.showAlignment(GoalNode);
      Align.showNodeCntMap();
      printf("%s: %10.5lf %10.5lf\n",Align.structId(),
	     Align.actualScore(GoalNode),ScoreWithoutGaps);
      freeNode(GoalNode);
    }
}
