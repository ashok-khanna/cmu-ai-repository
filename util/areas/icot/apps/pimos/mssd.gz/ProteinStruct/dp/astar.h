// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

// This is for Two-Dimensional Dynamic Programming.
// For 3D DP, this class must have three parameters X,Y,Z
// denoting the node position in the 3D DP network.


class mapPosition
{
  int X,Y;
  mapPosition* NextFree;
 public:
  inline init(void)
    {
      X = Y = 0;
      NextFree = NULL;
    }
  inline init(int PositionX, int PositionY)
    {
      X = PositionX;
      Y = PositionY;
      NextFree = NULL;
    }
  inline mapPosition(void)
    {
      init();
    }
  inline mapPosition(int PositionX, int PositionY)
    {
      init(PositionX,PositionY);
    }
  inline mapPosition* nextFree(void)
    {
      return NextFree;
    }
  inline void nextFree(mapPosition* NF)
    {
      NextFree = NF;
    }
  inline int x(void)
    {
      return X;
    }
  inline int y(void)
    {
      return Y;
    }
  inline void print(void)
    {
      printf("Map Position:    (%d,%d)\n",X,Y);
    }
  inline int operator ==(mapPosition& MapPosition)
    {
      if(X == MapPosition.X && Y == MapPosition.Y)
	return 1;
      else
	return 0;
    }
};

extern mapPosition* FreeMapPosition;
extern int          FreeMapPositionCnt;

inline void initFreeMapPosition(int Size)
{
  mapPosition* MapPosition = new mapPosition[Size];
  FreeMapPosition = &(MapPosition[0]);
  for(int I=1;I<Size;++I)
    MapPosition[I-1].nextFree(&(MapPosition[I]));
}

inline void freeMapPosition(mapPosition* MapPosition)
{
  MapPosition->nextFree(FreeMapPosition);
  FreeMapPosition = MapPosition;
}

inline mapPosition* newMapPosition(void)
{
  if(FreeMapPosition==NULL)
    {
      return new mapPosition();
    }
  else
    {
      mapPosition* New = FreeMapPosition;
      FreeMapPosition  = New->nextFree();
      New->init();
      return New;
    }
}

inline mapPosition* newMapPosition(int X,int Y)
{
  if(FreeMapPosition==NULL)
    {
      return new mapPosition(X,Y);
    }
  else
    {
      mapPosition* New = FreeMapPosition;
      FreeMapPosition  = New->nextFree();
      New->init(X,Y);
      return New;
    }
}

class node
{
  mapPosition* MapPosition;
  int          HeapPosition;
  double       Score;
  double       ScoreToHere;
  double       ScoreFromHere;
  node*        Path;
  node*        NextFree;
 public:
  inline init(void)
    {
      MapPosition    = newMapPosition();
      HeapPosition   =   0;
      Score          = 0.0;
      ScoreToHere    = 0.0;
      ScoreFromHere  = 0.0;
      Path           = NULL;
      NextFree       = NULL;
    }
  inline init(mapPosition* MP, double ScoreOfNode)
    {
      MapPosition    = MP;
      HeapPosition   =  0;
      Score          = ScoreOfNode;
      ScoreToHere    = 0.0;
      ScoreFromHere  = 0.0;
      Path           = NULL;
      NextFree       = NULL;
    }
  inline init
    (
     mapPosition* MP,
     double       ScoreOfNode,
     double       ScoreToHereNow,
     double       ScoreFromHereNow,
     node*        LastNodeToHere
     )
    {
      MapPosition    = MP;
      HeapPosition   =  0;
      Score          = ScoreOfNode;
      ScoreToHere    = ScoreToHereNow;
      ScoreFromHere  = ScoreFromHereNow;
      Path           = LastNodeToHere;
      NextFree       = NULL;
    }
  inline node(void)
    {
      init();
    }
  inline node(mapPosition* MP, double ScoreOfNode)
    {
      init(MP,ScoreOfNode);
    }  
  inline node
    (
     mapPosition* MP,
     double       ScoreOfNode,
     double       ScoreToHereNow,
     double       ScoreFromHereNow,
     node*        LastNodeToHere
     )
    {
      init(MP,ScoreOfNode,ScoreToHereNow,ScoreFromHereNow,LastNodeToHere);
    }
  inline node* nextFree(void)
    {
      return NextFree;
    }
  inline void  nextFree(node* NF)
    {
      NextFree = NF;
    }
  inline freeNode(void)
    {
      freeMapPosition(MapPosition);
    }
  inline mapPosition* positionInMap(void)
    {
      return MapPosition;
    }
  inline int positionInHeap(void)
    {
      return HeapPosition;
    }
  inline void  positionInHeap(int HeapPositionNew)
    {
      HeapPosition = HeapPositionNew;
    }
  inline double score(void)
    {
      return ScoreToHere + Score;
    }
  inline double totalScore(void)
    {
      return ScoreToHere + Score + ScoreFromHere;
    }
  inline node* path(void)
    {
      return Path;
    }
  inline void print(void)
    {
      MapPosition->print();
      printf("Heap Position:   %d\n", HeapPosition);
      printf("Score:           %lf\n",Score);
      printf("Score to here:   %lf\n",ScoreToHere);
      printf("Score from here: %lf\n",ScoreFromHere);
      printf("Path from ");
      if(Path!=NULL)
	Path->positionInMap()->print();
      else
	puts("Path is NULL");
      puts("");
    }
};

extern node* FreeNode;
extern int   FreeNodeCnt;

inline void initFreeNode(int Size)
{
  node* Node = new node[Size];
  FreeNode = &(Node[0]);
  for(int I=1;I<Size;++I)
    Node[I-1].nextFree(&(Node[I]));
}

inline void freeNode(node* Node)
{
  Node->freeNode();
  Node->nextFree(FreeNode);
  FreeNode = Node;
}

inline node* newNode(void)
{
  if(FreeNode==NULL)
    {
      return new node();
    }
  else
    {
      node* New = FreeNode;
      FreeNode  = New->nextFree();
      New->init();
      return New;
    }
}

inline node* newNode(mapPosition* MP, double ScoreOfNode)
{
  if(FreeNode==NULL)
    {
      return new node(MP,ScoreOfNode);
    }
  else
    {
      node* New = FreeNode;
      FreeNode  = New->nextFree();
      New->init(MP,ScoreOfNode);
      return New;
    }
}

inline node* newNode
  (
   mapPosition* MP,
   double       ScoreOfNode,
   double       ScoreToHereNow,
   double       ScoreFromHereNow,
   node*        LastNodeToHere
   )
{
  if(FreeNode==NULL)
    {
      return new 
	node(MP,ScoreOfNode,ScoreToHereNow,ScoreFromHereNow,LastNodeToHere);
    }
  else
    {
      node* New = FreeNode;
      FreeNode  = New->nextFree();
      New->init(MP,ScoreOfNode,ScoreToHereNow,ScoreFromHereNow,LastNodeToHere);
      return New;
    }
}

// For some C++ Compilers, this definition is required
//  in order to make a pointer array of an object class.

typedef node* nodeP;

// Nodes are managed using a binary heap.

class nodeHeap
{
  nodeP* Heap;
  int    Size;
  int    LastPosition;
 public:
  inline nodeHeap(int MaxSize)
    {
      Size = MaxSize+1;
      Heap = new nodeP[Size];
      for(int I=0;I<Size;++I)
	Heap[I] = NULL;
      LastPosition = 0;
    }
  inline init(void)
    {
      for(int I=0;I<Size;++I)
	Heap[I] = NULL;
      LastPosition = 0;
    }
  inline ~nodeHeap(void)
    {
      delete Heap;
    }

// When the new node at a map position has a better score
// than the node at that position, the old node is discarded
// and the new node is added in the heap.
// So this method is used in such a case.

  void   replace(node* NewNode, node* OldNode);
  void   add    (node* NewNode);
  node*  best   (void);
};

// This definition is for 2D DP. 

class nodeMap
{
  int          SizeX,SizeY;
  nodeP*       Map;
  nodeHeap*    NodeHeap;
 public:
  inline nodeMap(int MaxSizeX,int MaxSizeY)
    {
      SizeX      = MaxSizeX;
      SizeY      = MaxSizeY;
      Map        = new nodeP[SizeX*SizeY];
      for(int I=0;I<SizeX;++I)
	for(int J=0;J<SizeY;++J)
	  Map[I*SizeY+J] = NULL;
      NodeHeap   = new nodeHeap(SizeX*SizeY);
    }
  inline init(void)
    {
      for(int I=0;I<SizeX;++I)
	for(int J=0;J<SizeY;++J)
	  Map[I*SizeY+J] = NULL;
      NodeHeap->init();
    }
  inline ~nodeMap(void)
    {
      for(int I=0;I<SizeX;++I)
	for(int J=0;J<SizeY;++J)
	  if(Map[I*SizeY+J] != NULL)
	    freeNode(Map[I*SizeY+J]);
      delete Map;
      delete NodeHeap;
    }
  inline node* nodeAt(int PositionX, int PositionY)
    {
      if(
	 PositionX >= 0 || PositionX < SizeX ||
	 PositionY >= 0 || PositionX < SizeY
	 )
	return Map[PositionX*SizeY+PositionY];
      else
	return NULL;
    }
  inline void nodeAt(node* Node,int PositionX, int PositionY)
    {
      if(
	 PositionX >= 0 || PositionX < SizeX ||
	 PositionY >= 0 || PositionX < SizeY
	 )
	Map[PositionX*SizeY+PositionY] = Node;
      else
	{
	  cerr << "Out of range in adding a new node to the map!\n";
	  exit(1);
	}
    }
  inline node* best(void)
    {
      return NodeHeap->best();
    }
  void  add(node* NewNode);
  void  generatePath(void);
};

