// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <stream.h>
#include <string.h>
#include <ctype.h>
#include "astar.h"

// In order for the score of each arc to take positive value, the bottom
// score is added to the actual score.
// We add BottomScore to each diagonal arc, and BottomScore/2 to each
// horizontal or virtical arc.

const double BottomScore = 20.0;

// The program for the pairwise alignment of amino-acid sequences
// with Linear Gap Penalty, where the gap penalty is proportional
// to the length of gaps.

class alignLinearGap
{
  char*         SeqA;
  char*         SeqB;
  int           SeqLengthA;
  int           SeqLengthB;
  double        GapPenalty;
  mapPosition*  GoalNodePosition;
  nodeMap*      NodeMap;
  double*       MinimalScoreA;
  double*       MinimalScoreB;
  int*          NodeCntMap;
 public:
  alignLinearGap(char* A,char* B, double GP);
  inline ~alignLinearGap(void)
    {
      freeMapPosition(GoalNodePosition);
      delete MinimalScoreA;
      delete MinimalScoreB;
      delete NodeCntMap;
    }
  double estimatedScoreFrom(mapPosition* MapPositionNow);
  inline double bottomScore(node* Node)
    {
      return (Node->positionInMap()->x()+Node->positionInMap()->y())
	  *BottomScore/2.0;
    }
  inline int nodeCntMap(int X,int Y)
    {
      return NodeCntMap[(SeqLengthB+1)*X+Y];
    }
  inline void nodeCntMapCnt(int X,int Y)
    {
      NodeCntMap[(SeqLengthB+1)*X+Y]++;
    }
  inline void nodeCntMapPath(int X,int Y)
    {
      NodeCntMap[(SeqLengthB+1)*X+Y]=-1;
    }

// This is quite easy way to show the path and how frequenty each position
// is searched for.

  inline void showNodeCntMap(void)
    {
      printf("     ");
      for(int I=0;I<=SeqLengthA;++I)
	{
	  printf("%1d",I%10);
	}
      printf("\n");
      for(int J=0;J<=SeqLengthB;++J)
	{
	  printf(" %3d ",J);
	  for(int I=0;I<=SeqLengthA;++I)
	    {
	      switch(NodeCntMap[(SeqLengthB+1)*I+J])
		{
		case -1:

// The path is denoted by *'s.

		  printf("*");
		  break;
		case 0:
		  printf(".");
		  break;
		default:

// The number of search is shown as below.

		  printf("%1d",NodeCntMap[(SeqLengthB+1)*I+J]);
		}
	    }
	  printf("\n");
	}
    }
  inline double actualScore(node* Node)
    {
      return Node->score()-bottomScore(Node);
    }
  node*  generateNode(node* Node);
  node*  astarSearch(void);
  void   showPath(node* GoalNode);
};

// The Dayhoff's odd matrix is provided as a include file.

#include "dayhoff.c"

alignLinearGap::alignLinearGap(char* A,char* B,double GP)
{
  SeqA = A;
  SeqB = B;
  for(int I=0;isalpha(SeqA[I]);++I){}
  SeqLengthA = I;
  for(    I=0;isalpha(SeqB[I]);++I){}
  SeqLengthB = I;
  GapPenalty       = GP + BottomScore/2.0;

  GoalNodePosition = newMapPosition(SeqLengthA,SeqLengthB);
  NodeMap          = new nodeMap(SeqLengthA+1,SeqLengthB+1);

  NodeCntMap       = new int[(SeqLengthA+1)*(SeqLengthB+1)];
  for(    I=0;I<=SeqLengthA;++I)
    {
      for(int J=0;J<=SeqLengthB;++J)
	NodeCntMap[(SeqLengthB+1)*I+J] = 0;
    }
  MinimalScoreA    = new double[SeqLengthA+1];
  MinimalScoreB    = new double[SeqLengthB+1];

  MinimalScoreA[SeqLengthA] = MinimalScoreB[SeqLengthB] = 0.0;
  for(    I=SeqLengthA-1;I>=0;--I)
    {
      MinimalScoreA[I] =
	MinimalScoreA[I+1]+BottomScore+ScoreMatrix[SeqA[I]-'A'][SeqA[I]-'A']-3;

// I don't quite understand why this function does not work.
// And why "-3 " is important.

    }
  for(    I=SeqLengthB-1;I>=0;--I)
    {
      MinimalScoreB[I] =
	MinimalScoreB[I+1]+BottomScore+ScoreMatrix[SeqB[I]-'A'][SeqB[I]-'A']-3;

// I don't quite understand why this function does not work.
// And why "-3 " is important.

    }
}

double alignLinearGap::estimatedScoreFrom(mapPosition* MapPositionNow)
{
  int DistanceToEndX = GoalNodePosition->x()-MapPositionNow->x();
  int DistanceToEndY = GoalNodePosition->y()-MapPositionNow->y();

  if(DistanceToEndX == 1)
    {  
      if(DistanceToEndY == 1 )
	return BottomScore
	  +ScoreMatrix[SeqA[SeqLengthA-1]-'A'][SeqB[SeqLengthB-1]-'A'];
      else if(DistanceToEndY == 0)
	return GapPenalty;
    }
  else if(DistanceToEndY == 1)
    {
      if(DistanceToEndX == 0)
	return GapPenalty;
    }

  if(DistanceToEndX < DistanceToEndY)
    {
      return MinimalScoreA[MapPositionNow->x()]
	+(DistanceToEndY-DistanceToEndX)*GapPenalty;
    }
  else if(DistanceToEndX == DistanceToEndY)
    {
      return
	MinimalScoreA[MapPositionNow->x()]>MinimalScoreB[MapPositionNow->y()]?
	MinimalScoreA[MapPositionNow->x()]:MinimalScoreB[MapPositionNow->y()];
    }
  else
    {
      return MinimalScoreB[MapPositionNow->y()]
	+(DistanceToEndX-DistanceToEndY)*GapPenalty;
    }
}

node* alignLinearGap::generateNode(node* Node)
{
  int PathX = Node->positionInMap()->x();
  int PathY = Node->positionInMap()->y();
  if(PathX+1<=SeqLengthA)
    {

// Generating a new node right to the "Node."

      mapPosition* MapPosition = newMapPosition(PathX+1,PathY);
      nodeCntMapCnt(PathX+1,PathY);

      if(*GoalNodePosition==*MapPosition)
	return newNode(MapPosition,0.0,Node->score()+GapPenalty,0.0,Node);
      NodeMap->add(
		   newNode(
			    MapPosition,
			    0.0,
			    Node->score()+GapPenalty,
			    estimatedScoreFrom(MapPosition),
			    Node
			    )
		   );
      if(PathY+1<=SeqLengthB)
	{

// Generating a new node right down to the "Node."

	  mapPosition* MapPosition = newMapPosition(PathX+1,PathY+1);
	  nodeCntMapCnt(PathX+1,PathY+1);

	  int  SeqPositionA   = Node->positionInMap()->x();
	  int  SeqPositionB   = Node->positionInMap()->y();
	  int  AminoTypeA     = SeqA[SeqPositionA]-'A';
	  int  AminoTypeB     = SeqB[SeqPositionB]-'A';
	  double DayhoffScore =
	    ScoreMatrix[AminoTypeA][AminoTypeB]+BottomScore;
	  if(*GoalNodePosition==*MapPosition)
	    return
	      newNode(MapPosition,0.0,Node->score()+DayhoffScore,0.0,Node);
	  NodeMap->add(
		       newNode(
				MapPosition,
				0.0,
				Node->score()+DayhoffScore,
				estimatedScoreFrom(MapPosition),
				Node
				)
		       );
	}
    }
  if(PathY+1<=SeqLengthB)
    {

// Generating a new node down to the "Node."

      mapPosition* MapPosition = newMapPosition(PathX,PathY+1);
      nodeCntMapCnt(PathX,PathY+1);

      if(*GoalNodePosition==*MapPosition)
	return newNode(MapPosition,0.0,Node->score()+GapPenalty,0.0,Node);
      NodeMap->add(
		   newNode(
			    MapPosition,
			    0.0,
			    Node->score()+GapPenalty,
			    estimatedScoreFrom(MapPosition),
			    Node
			    )
		   );
    }
  return NULL;
}

node* alignLinearGap::astarSearch(void)
{
  mapPosition* StartPosition = newMapPosition(0,0);
  node* StartNode =
    newNode(StartPosition,0.0,0.0,estimatedScoreFrom(StartPosition),NULL);
  nodeCntMapCnt(0,0);
  NodeMap->add(StartNode);
  if(StartNode->positionInMap()==GoalNodePosition)
    {  
      cerr << "Start Node is GoalNode!\n";
      return NULL;
    }
  node* GoalNode;

// The statement below is main part of A* algorithm.

  while(NULL==(GoalNode=generateNode(NodeMap->best()))){}
  return GoalNode;
}

// This function analyzes the links between nodes and generate the
// path from the start node to the goal node.

void alignLinearGap::showPath(node* GoalNode)
{
  mapPosition* PathPositionArray[SeqLengthA+SeqLengthB+2];
  int PathLength = 0;
  for(node* NodeNow = GoalNode; NodeNow!=NULL; NodeNow=NodeNow->path())
    {
      nodeCntMapPath
	(
	 NodeNow->positionInMap()->x(),
	 NodeNow->positionInMap()->y()
	 );
      PathPositionArray[PathLength++] = NodeNow->positionInMap();
    }

// Now the aligned sequences are generated.

  char SeqAlignedA[PathLength];
  char SeqAlignedB[PathLength];
  for(int I=PathLength-2,P=0;I>=0;--I,++P)
    {
      int PrevX = PathPositionArray[I+1]->x();
      int PrevY = PathPositionArray[I+1]->y();
      int X     = PathPositionArray[I  ]->x();
      int Y     = PathPositionArray[I  ]->y();

      if(X==PrevX)
	{
	  SeqAlignedA[P] = '-';
	  SeqAlignedB[P] = SeqB[PrevY];
	}
      else if(Y==PrevY)
	{
	  SeqAlignedA[P] = SeqA[PrevX];
	  SeqAlignedB[P] = '-';
	}
      else
	{
	  SeqAlignedA[P] = SeqA[PrevX];
	  SeqAlignedB[P] = SeqB[PrevY];
	}
    }
  SeqAlignedA[P] = SeqAlignedB[P] = '\0';
  showNodeCntMap();
  puts("\nAlignment Result");
  puts(SeqAlignedA);
  puts(SeqAlignedB);
}

main(int ArgCnt, char** ArgVal)
{
  if(ArgCnt<3)
    {
      cerr << form("Too few arguments!\nUsage\n%s [sequence file] [gap cost]\n",ArgVal[0]);
      exit(1);
    }
  FILE* SeqFile;
  if(NULL==(SeqFile=fopen(ArgVal[1],"r")))
    {
      cerr << form("Can't open file %s.\n",ArgVal[1]);
      exit(1);
    }
  char BuffLineA[1024];
  char BuffLineB[1024];
  if(NULL==fgets(BuffLineA,1023,SeqFile))
    {
      cerr << "Can't read the File!\n";
      exit(1);
    }
  if(NULL==fgets(BuffLineB,1023,SeqFile))
    {
      cerr << "Can't read the File!\n";
      exit(1);
    }
  double GapPenalty = atof(ArgVal[2]);

  int Size = strlen(BuffLineA)*strlen(BuffLineB);
  initFreeMapPosition(Size);
  initFreeNode(Size);

  alignLinearGap* Align = new alignLinearGap(BuffLineA,BuffLineB,GapPenalty);
  node* GoalNode = Align->astarSearch();
  Align->showPath(GoalNode);
  puts("\nSequences:");
  printf(BuffLineA);
  printf(BuffLineB);
  printf("\nGapPenalty: %10.4lf\n",GapPenalty);
  printf("Score:      %10.4lf\n",Align->actualScore(GoalNode));
}
