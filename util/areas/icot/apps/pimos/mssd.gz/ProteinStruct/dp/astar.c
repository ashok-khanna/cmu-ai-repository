// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <stream.h>
#include "astar.h"

mapPosition* FreeMapPosition    = NULL;
int          FreeMapPositionCnt = 0;
node*        FreeNode           = NULL;
int          FreeNodeCnt        = 0;

void nodeHeap::replace(node* NewNode,node* OldNode)
{
  int Position   = OldNode->positionInHeap();
  int PositionSuper;
  Heap[Position] = NewNode;
  for(; Position>1; Position = PositionSuper)
    {
      PositionSuper = Position/2;
      if(NewNode->totalScore()>Heap[PositionSuper]->totalScore())
	{
	  break;
	}
      else
	{
	  Heap[Position]      = Heap[PositionSuper];
	  Heap[Position]-> positionInHeap(Position);
	  Heap[PositionSuper] = NewNode;
	}
    }
  NewNode->positionInHeap(Position);
  freeNode(OldNode);
}

void nodeHeap::add(node* NewNode)
{
  if(LastPosition == 0)
    {
      LastPosition = 1;
      Heap[LastPosition] = NewNode;
      NewNode->positionInHeap(LastPosition);
    }
  else
    {
      if(++LastPosition==Size)
	{
	  cerr << "Too much node generated!\n";
	  exit(1);
	}
      Heap[LastPosition] = NewNode;
      int PositionSuper;
      for(int Position = LastPosition; Position>1; Position = PositionSuper)
	{
	  PositionSuper = Position/2;
	  if(NewNode->totalScore()>Heap[PositionSuper]->totalScore())
	    {
	      break;
	    }
	  else
	    {
	      Heap[Position]      = Heap[PositionSuper];
	      Heap[Position]-> positionInHeap(Position);
	      Heap[PositionSuper] = NewNode;
	    }
	}
      NewNode->positionInHeap(Position);
    }
}

node* nodeHeap::best(void)
{
  node* BestNode = Heap[1];
  Heap[1] = Heap[LastPosition--];

  for(int Position = 1;;)
    {
      if(Position*2==LastPosition)
	{
	  if(Heap[Position]->totalScore()>Heap[Position*2]->totalScore())
	    {
	      node* Tmp = Heap[Position*2];
	      Heap[Position*2] = Heap[Position];
	      Heap[Position*2]-> positionInHeap(Position*2);
	      Heap[Position  ] = Tmp;
	      Heap[Position  ]-> positionInHeap(Position  );
	      return BestNode;
	    }
	}
      else if(Position*2 > LastPosition)
	{
	  return BestNode;
	}
      if(Heap[Position*2]->totalScore()<Heap[Position*2+1]->totalScore())
	{
	  if(Heap[Position]->totalScore()<Heap[Position*2]->totalScore())
	    return BestNode;
	  else
	    {
	      node* Tmp = Heap[Position*2];
	      Heap[Position*2] = Heap[Position];
	      Heap[Position*2]-> positionInHeap(Position*2);
	      Heap[Position  ] = Tmp;
	      Heap[Position  ]-> positionInHeap(Position  );
	      Position = Position*2;
	    }
	}
      else
	{
	  if(Heap[Position]->totalScore()<Heap[Position*2+1]->totalScore())
	    return BestNode;
	  else
	    {
	      node* Tmp = Heap[Position*2+1];
	      Heap[Position*2+1] = Heap[Position];
	      Heap[Position*2+1]-> positionInHeap(Position*2+1);
	      Heap[Position    ] = Tmp;
	      Heap[Position    ]-> positionInHeap(Position  );
	      Position = Position*2+1;
	    }
	}
    }
  return BestNode;
}

void nodeMap::add(node* NewNode)
{
  int X = NewNode->positionInMap()->x();
  int Y = NewNode->positionInMap()->y();
  node* OldNode = nodeAt(X,Y);
  if(OldNode!=NULL)
    {
      if(OldNode->totalScore()>NewNode->totalScore())
	{
	  NodeHeap->replace(NewNode,OldNode);
	  nodeAt(NewNode,X,Y);
	}
      else
	freeNode(NewNode);
    }
  else
    {
      nodeAt(NewNode,X,Y);
      NodeHeap->add(NewNode);
    }
}

