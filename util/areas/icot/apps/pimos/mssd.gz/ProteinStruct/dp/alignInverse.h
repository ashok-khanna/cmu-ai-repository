// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

// In order for the score of each arc to take positive value, the bottom
// score is added to the actual score.
// We add BottomScore to each diagonal arc, and BottomScore/2 to each
// horizontal or virtical arc.
// In the alignment for the inverse folding problem, the bottom score cannot
// be determined before the data input.

double BottomScore;

// The program for the inverse folding problem with Linear Gap
// Penalty, where the gap penalty is proportional to the length of gaps.
// A given amino-acid sequence is aligned to the sequence profile derived
// from the 3D structure of a protein.

class alignProfile
{
  double*       Profile[NumberOfAminoTypes];
  int           ProfileLength;
  char          StructID[20];
  int           StructPartNum;
  char*         SeqStruct;
  double        MeanScore;
  double        Deviation;
  int*          Seq;
  int           SeqLength;
  double        GapPenalty;
  double        SlidePenalty;
  mapPosition*  GoalNodePosition;
  nodeMap*      NodeMap;
  double*       MinimalProfileScore;
  int*          NodeCntMap;
 public:
  void init(FILE* ProfileFile, double GP, double SP);
  void init(FILE* ProfileFile, char* Sequence, double GP, double SP);
  inline alignProfile(int MaxProfileLength,int MaxSeqLength)
    {
      for(int I=0;I<NumberOfAminoTypes;++I)
	Profile[I]        = new double[MaxProfileLength];
      SeqStruct           = new char  [MaxProfileLength];
      Seq                 = new int   [MaxSeqLength];
      GoalNodePosition    = NULL;
      NodeMap             = new nodeMap(MaxProfileLength+1,MaxSeqLength+1);
      MinimalProfileScore = new double[MaxProfileLength+1];
      NodeCntMap          = new int   [(MaxProfileLength+1)*(MaxSeqLength+1)];
    }
  inline alignProfile(FILE* ProfileFile, double GP, double SP)
    {
      for(int I=0;I<NumberOfAminoTypes;++I)
	Profile[I]        = NULL;
      SeqStruct           = NULL;
      Seq                 = NULL;
      GoalNodePosition    = NULL;
      NodeMap             = NULL;
      MinimalProfileScore = NULL;
      NodeCntMap          = NULL;
      init(ProfileFile,GP,SP);
    }
  inline alignProfile(FILE* ProfileFile, char* Sequence, double GP, double SP)
    {
      for(int I=0;I<NumberOfAminoTypes;++I)
	Profile[I]        = NULL;
      SeqStruct           = NULL;
      Seq                 = NULL;
      GoalNodePosition    = NULL;
      NodeMap             = NULL;
      MinimalProfileScore = NULL;
      NodeCntMap          = NULL;
      init(ProfileFile,Sequence,GP,SP);
    }
  inline ~alignProfile(void)
    {
      freeMapPosition(GoalNodePosition);
      for(int I=0;I<NumberOfAminoTypes;++I)
	{
	  delete Profile[I];
	}
      delete SeqStruct;
      delete Seq;
      delete MinimalProfileScore;
      if(GoalNodePosition!=NULL)
	{
	  freeMapPosition(GoalNodePosition);
	  GoalNodePosition = NULL;
	}
      delete NodeMap;
      delete NodeCntMap;
    }
  inline int profileLength(void)
    {
      return ProfileLength;
    }
  void   sequence(char* Sequence);
  double estimatedScoreFrom(mapPosition* MapPositionNow);
  inline double bottomScore(node* Node)
    {
      return (Node->positionInMap()->x()+Node->positionInMap()->y())
	  *BottomScore/2.0;
    }
  inline int nodeCntMap(int X,int Y)
    {
      return NodeCntMap[(SeqLength+1)*X+Y];
    }
  inline void nodeCntMapCnt(int X,int Y)
    {
      NodeCntMap[(SeqLength+1)*X+Y]++;
    }
  inline void nodeCntMapPath(int X,int Y)
    {
      NodeCntMap[(SeqLength+1)*X+Y]=-1;
    }
  inline double estimatedPenalty(void)
    {
      return (GapPenalty<SlidePenalty? GapPenalty:SlidePenalty);
    }
// This is quite easy way to show the path and how frequenty each position
// is searched for.

  inline void showNodeCntMap(void)
    {
      printf("    ");
      for(int I=0;I<=ProfileLength;++I)
	{
	  printf("%1d",I%10);
	}
      printf("\n");
      for(int J=0;J<=SeqLength;++J)
	{
	  printf(" %3d ",J);
	  for(int I=0;I<=ProfileLength;++I)
	    {
	      switch(NodeCntMap[(SeqLength+1)*I+J])
		{
		case -1:

// The path is denoted by *'s.

		  printf("*");
		  break;
		case 0:
		  printf(".");
		  break;
		default:

// The number of search is shown as below.
                    if(NodeCntMap[(SeqLength+1)*I+J]>9)
                      printf("!");
                    else
		      printf("%d",NodeCntMap[(SeqLength+1)*I+J]);
		}
	    }
	  printf("\n");
	}
    }
  inline void showNodeCntMap(mapPosition* MapPosition)
    {
      printf("     ");
      for(int I=0;I<=ProfileLength;++I)
	{
	  printf("%1d",I%10);
	}
      printf("\n");
      for(int J=0;J<=SeqLength;++J)
	{
	  printf(" %3d ",J);
	  for(int I=0;I<=ProfileLength;++I)
	    {
              if(MapPosition->x()==I && MapPosition->y()==J)
                printf("@");
              else
	        switch(NodeCntMap[(SeqLength+1)*I+J])
		  {
		  case 0:
		    printf(".");
		    break;
		  default:

// The number of search is shown as below.
                    if(NodeCntMap[(SeqLength+1)*I+J]>9)
                      printf("!");
                    else
		      printf("%d",NodeCntMap[(SeqLength+1)*I+J]);
		  }
	    }
	  printf("\n");
	}
    }
  inline double actualScore(node* Node)
    {
      return Node->score()-bottomScore(Node);
    }
  inline double meanScore(void)
    {
      return MeanScore;
    }
  inline double deviation(void)
    {
      return Deviation;
    }
  inline char*  structId(void)
    {
      return StructID;
    }
  node*  generateNode(node* Node);
  node*  astarSearch(void);
  double showAlignment(node* GoalNode);
};

