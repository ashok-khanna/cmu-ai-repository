// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <stream.h>
#include <string.h>
#include <ctype.h>
#include "../amino/amino.h"
#include "../mssd/mssd.h"
#include "astar.h"
#include "alignInverse.h"

const int MaxProfileLength = 900;
const int MaxSeqLength     = 900;

main(int ArgCnt, char** ArgVal)
{
  if(ArgCnt<4)
    {
      cerr << form("Too few arguments!\nUsage\n%s [sequence file] [gap cost] [slide cost]\n",ArgVal[0]);
      exit(1);
    }
  FILE* SeqFile;
  if(NULL==(SeqFile=fopen(ArgVal[1],"r")))
    {
      cerr << form("Can't open file %s.\n",ArgVal[1]);
      exit(1);
    }
  char BuffLine[1024];

  double GapPenalty   = atof(ArgVal[2]);
  double SlidePenalty = atof(ArgVal[3]);

  alignProfile Align(MaxProfileLength,MaxSeqLength);
  Align.init(stdin,GapPenalty,SlidePenalty);
  printf("GapPenalty    : %10.5lf\n",GapPenalty);
  printf("SlidePenalty  : %10.5lf\n",SlidePenalty);

  int Size = (Align.profileLength()+1)*MaxSeqLength;
  initFreeMapPosition(Size);
  initFreeNode(Size);

  while(NULL!=fgets(BuffLine,1023,SeqFile))
    {
      char PDBEntName[8];
      int I = 0;
      while(BuffLine[I] != ':')
	{
	  PDBEntName[I] = BuffLine[I++];
	}
      PDBEntName[I] = '\0';
      cerr << PDBEntName << '\n';
      Align.sequence(BuffLine+I+1);
      node* GoalNode = Align.astarSearch();
      double ScoreWithoutGaps = Align.showAlignment(GoalNode);
      printf("%s: %10.5lf %10.5lf %10.5lf\n",PDBEntName,
	     Align.actualScore(GoalNode),
	     ScoreWithoutGaps,
	     (ScoreWithoutGaps-Align.meanScore())/Align.deviation()
	     );
    }
}
