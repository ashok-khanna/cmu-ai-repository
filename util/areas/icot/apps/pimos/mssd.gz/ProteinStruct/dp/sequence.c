// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdio.h>
#include <stream.h>
#include <ctype.h>
#include <stdlib.h>

main(int ArgCnt, char** ArgVal)
{
  if(ArgCnt<2)
    {
      cerr << "Too few argument!\n";
      exit(1);
    }

  FILE* MSSDFile;
  if(NULL==(MSSDFile=fopen(ArgVal[1],"r")))
    {
      cerr << "Can't open MSSD File!\n";
      exit(1);
    }
  char BuffLine[1024];
  if(NULL==fgets(BuffLine,1023,MSSDFile))
    {
      cerr << "Invalid MSSD File!\n";
      exit(1);
    }
  cerr << BuffLine;
  int I=0;
  while(BuffLine[I]!='\n'){I++;}
  BuffLine[I] = '\0';
  cout << BuffLine << ':';
  if(NULL==fgets(BuffLine,1023,MSSDFile))
    {
      cerr << "Invalid MSSD File!\n";
      exit(1);
    }
  char Sequence[1024];
  I=0;
  int J=0;
  while(BuffLine[I]!='\0')
    {
      if(isalpha(BuffLine[I]))
	Sequence[J++]=BuffLine[I];
      I++;
    }
  Sequence[J++] = '\n';
  Sequence[J  ] = '\0';
  cout << Sequence;
}
