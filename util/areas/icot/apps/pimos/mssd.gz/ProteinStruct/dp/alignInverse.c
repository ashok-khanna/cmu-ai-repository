// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <stream.h>
#include <string.h>
#include <ctype.h>
#include "../amino/amino.h"
#include "../mssd/mssd.h"
#include "astar.h"
#include "alignInverse.h"

void alignProfile::init
  (
    FILE*  ProfileFile,
    double GP,
    double SP
   )
{
  char BuffLine[1024];
  if(NULL==fgets(BuffLine,1023,ProfileFile))
    {
      cerr << "Profile File End!\n";
      exit(0);
    }
  int I=0;
  while(BuffLine[I]!='\n' && BuffLine[I]!='\0')
    {
      StructID[I] = BuffLine[I];
      I++;
    }
  StructID[I] = '\0';
  if(NULL==fgets(BuffLine,1023,ProfileFile))
    {
      cerr << "Invalid Profile File!\n";
      exit(1);
    }
  if(0!=strncmp(BuffLine,"Length",6))
    {
      cerr << "Invalid Profile File!\n";
      exit(1);
    }
  sscanf(BuffLine+10,"%d",&ProfileLength);
  if(NULL==fgets(BuffLine,1023,ProfileFile))
    {
      cerr << "Profile File End!\n";
      exit(0);
    }
  if(SeqStruct == NULL)
    SeqStruct = new char[ProfileLength+1];
  for(    I=0;I<ProfileLength;++I)
    {
      SeqStruct[I] = BuffLine[I];
    }
  SeqStruct[ProfileLength] = '\0';

  for(int T=0;T<NumberOfAminoTypes;++T)
    {
      if(Profile[T]==NULL)
	Profile[T] = new double[ProfileLength];
    }
  double MinimalScore[ProfileLength];
  double MinimalScoreAll = 0;
  for(    I=0;I<ProfileLength;++I)
    {
      if(NULL==fgets(BuffLine,1023,ProfileFile))
	{
	  cerr << "Invalid ProfileFile!\n";
	  exit(1);
	}
      char* BuffTmp = BuffLine;
      double MinimalScoreTmp = 0.0;
      for(int T=0;T<NumberOfAminoTypes;++T)
	{
	  while(isspace(*BuffTmp)) BuffTmp++;
	  double ProfTmp;
	  sscanf(BuffTmp,"%lf",&ProfTmp);
	  Profile[T][I] = - ProfTmp;
	  if(Profile[T][I] < MinimalScoreTmp)
	    MinimalScoreTmp = Profile[T][I];
	  while(!isspace(*BuffTmp)) BuffTmp++;
	}
      MinimalScore[I] = MinimalScoreTmp;
      if(MinimalScoreAll > MinimalScoreTmp)
	MinimalScoreAll = MinimalScoreTmp;
    }

  BottomScore = - MinimalScoreAll*2.0;
  if(NULL==fgets(BuffLine,1023,ProfileFile))
    {
      cerr << "Profile File End!\n";
      exit(0);
    }
  double MinusMeanScore;
  sscanf(BuffLine+10,"%lf",&MinusMeanScore);
  MeanScore = -MinusMeanScore;
  if(NULL==fgets(BuffLine,1023,ProfileFile))
    {
      cerr << "Profile File End!\n";
      exit(0);
    }
  sscanf(BuffLine+10,"%lf",&Deviation);

  GapPenalty       = GP + BottomScore/2.0;
  SlidePenalty     = SP + BottomScore/2.0;
  if(MinimalProfileScore==NULL)
    MinimalProfileScore  = new double[ProfileLength+1];
  MinimalProfileScore[ProfileLength] = 0.0;
  for(    I=ProfileLength-1;I>=0;--I)
    {
      MinimalProfileScore[I] = MinimalProfileScore[I+1]+
	(BottomScore+MinimalScore[I]<estimatedPenalty()?
	 BottomScore+MinimalScore[I]:estimatedPenalty());
    }
  if(GoalNodePosition!=NULL)
    freeMapPosition(GoalNodePosition);
  GoalNodePosition = NULL;
}

void alignProfile::init
  (
    FILE*  ProfileFile,
    char*  Sequence,
    double GP,
    double SP
   )
{
  char BuffLine[1024];
  if(NULL==fgets(BuffLine,1023,ProfileFile))
    {
      cerr << "Profile File End!\n";
      exit(0);
    }
  int I=0;
  while(BuffLine[I]!='\n' && BuffLine[I]!='\0')
    {
      StructID[I] = BuffLine[I];
      I++;
    }
  StructID[I] = '\0';
  if(NULL==fgets(BuffLine,1023,ProfileFile))
    {
      cerr << "Invalid Profile File!\n";
      exit(1);
    }
  if(0!=strncmp(BuffLine,"Length",6))
    {
      cerr << "Invalid Profile File!\n";
      exit(1);
    }
  sscanf(BuffLine+10,"%d",&ProfileLength);
  if(NULL==fgets(BuffLine,1023,ProfileFile))
    {
      cerr << "Profile File End!\n";
      exit(0);
    }
  if(SeqStruct==NULL)
    SeqStruct = new char[ProfileLength+1];
  for(    I=0;I<ProfileLength;++I)
    {
      SeqStruct[I] = BuffLine[I];
    }
  SeqStruct[ProfileLength] = '\0';
  for(int T=0;T<NumberOfAminoTypes;++T)
    {
      if(Profile[T]==NULL)
	Profile[T] = new double[ProfileLength];
    }
  double MinimalScore[ProfileLength];
  double MinimalScoreAll = 0;
  for(    I=0;I<ProfileLength;++I)
    {
      if(NULL==fgets(BuffLine,1023,ProfileFile))
	{
	  cerr << "Invalid ProfileFile!\n";
	  exit(1);
	}
      char* BuffTmp = BuffLine;
      double MinimalScoreTmp = 0.0;
      for(int T=0;T<NumberOfAminoTypes;++T)
	{
	  while(isspace(*BuffTmp)) BuffTmp++;
	  double ProfTmp;
	  sscanf(BuffTmp,"%lf",&ProfTmp);
	  Profile[T][I] = - ProfTmp;
//	  printf("%6.2lf ",Profile[T][I]);
	  printf("");
	  if(Profile[T][I] < MinimalScoreTmp)
	    MinimalScoreTmp = Profile[T][I];
	  while(!isspace(*BuffTmp)) BuffTmp++;
	}
//      printf("");
      MinimalScore[I] = MinimalScoreTmp;
      if(MinimalScoreAll > MinimalScoreTmp)
	MinimalScoreAll = MinimalScoreTmp;
    }

  BottomScore = - MinimalScoreAll*2.0;
  if(NULL==fgets(BuffLine,1023,ProfileFile))
    {
      cerr << "Profile File End!\n";
      exit(0);
    }
  sscanf(BuffLine+10,"%lf",&MeanScore);
  
  if(NULL==fgets(BuffLine,1023,ProfileFile))
    {
      cerr << "Profile File End!\n";
      exit(0);
    }
  sscanf(BuffLine+10,"%lf",&Deviation);
  for(    I=0;isalpha(Sequence[I]);++I){}
  SeqLength = I;
  if(Seq==NULL)
    Seq = new int[SeqLength];
  for(    I=0;I<SeqLength;++I)
    {
      amino Amino(Sequence[I]);
      Seq[I] = Amino.id();
    }

  GapPenalty       = GP + BottomScore/2.0;
  SlidePenalty     = SP + BottomScore/2.0;
  GoalNodePosition = newMapPosition(ProfileLength,SeqLength);
  if(NodeMap==NULL)
    NodeMap = new nodeMap(ProfileLength+1,SeqLength+1);
  else
    NodeMap->init();
  if(NodeCntMap==NULL)
    NodeCntMap = new int[(ProfileLength+1)*(SeqLength+1)];
  for(    I=0;I<=ProfileLength;++I)
    {
      for(int J=0;J<=SeqLength;++J)
	NodeCntMap[(SeqLength+1)*I+J] = 0;
    }
  if(MinimalProfileScore==NULL)
    MinimalProfileScore = new double[ProfileLength+1];

  MinimalProfileScore[ProfileLength] = 0.0;
  for(    I=ProfileLength-1;I>=0;--I)
    {
      MinimalProfileScore[I] = MinimalProfileScore[I+1]+
	(BottomScore+MinimalScore[I]<estimatedPenalty()?
	 BottomScore+MinimalScore[I]:estimatedPenalty());
    }
}

void alignProfile::sequence(char* Sequence)
{
  for(int I=0;isalpha(Sequence[I]);++I){}

  SeqLength = I;

  if(Seq==NULL)
    Seq = new int[SeqLength];
  for(    I=0;I<SeqLength;++I)
    {
      amino Amino(Sequence[I]);
      Seq[I] = Amino.id();
    }
  if(GoalNodePosition!=NULL)
    freeMapPosition(GoalNodePosition);
  GoalNodePosition = newMapPosition(ProfileLength,SeqLength);

  if(NodeMap==NULL)
    NodeMap = new nodeMap(ProfileLength+1,SeqLength+1);
  else
    NodeMap->init();

  if(NodeCntMap==NULL)
    NodeCntMap = new int[(ProfileLength+1)*(SeqLength+1)];
  for(    I=0;I<=ProfileLength;++I)
    {
      for(int J=0;J<=SeqLength;++J)
	NodeCntMap[(SeqLength+1)*I+J] = 0;
    }
}

double alignProfile::estimatedScoreFrom(mapPosition* MapPositionNow)
{
  int DistanceToEndX = GoalNodePosition->x()-MapPositionNow->x();
  int DistanceToEndY = GoalNodePosition->y()-MapPositionNow->y();

  if(DistanceToEndX == 1)
    {  
      if(DistanceToEndY == 1 )
	return BottomScore +Profile[Seq[SeqLength-1]][ProfileLength-1];
      else if(DistanceToEndY == 0)
	return SlidePenalty;
    }
  else if(DistanceToEndY == 1)
    {
      if(DistanceToEndX == 0)
	return SlidePenalty;
    }

  if(DistanceToEndX < DistanceToEndY)
    {
      return MinimalProfileScore[MapPositionNow->x()]
	+(DistanceToEndY-DistanceToEndX)*estimatedPenalty();
    }
  else 
    {
      return MinimalProfileScore[MapPositionNow->x()];
    }
}

node* alignProfile::generateNode(node* Node)
{
  int PathX = Node->positionInMap()->x();
  int PathY = Node->positionInMap()->y();
  if(PathX+1<=ProfileLength)
    {

// Generating a new node right to the "Node."

      mapPosition* MapPosition = newMapPosition(PathX+1,PathY);
      nodeCntMapCnt(PathX+1,PathY);

      if(*GoalNodePosition==*MapPosition)
	return newNode(MapPosition,0.0,Node->score()+SlidePenalty,0.0,Node);
      NodeMap->add(
		   newNode(
			   MapPosition,
			   0.0,
			   Node->score()+
			   (PathY==SeqLength || PathY == 0?
			    SlidePenalty:GapPenalty),
			   estimatedScoreFrom(MapPosition),
			   Node
			   )
		   );
      if(PathY+1<=SeqLength)
	{

// Generating a new node right down to the "Node."

	  mapPosition* MapPosition = newMapPosition(PathX+1,PathY+1);
	  nodeCntMapCnt(PathX+1,PathY+1);

	  double InverseScore  =
	    Profile[Seq[PathY]][PathX]+BottomScore;
	  if(*GoalNodePosition==*MapPosition)
	    return
	      newNode(MapPosition,0.0,Node->score()+InverseScore,0.0,Node);
	  NodeMap->add(
		       newNode(
				MapPosition,
				0.0,
				Node->score()+InverseScore,
				estimatedScoreFrom(MapPosition),
				Node
				)
		       );
	}
    }
  if(PathY+1<=SeqLength)
    {

// Generating a new node down to the "Node."

      mapPosition* MapPosition = newMapPosition(PathX,PathY+1);
      nodeCntMapCnt(PathX,PathY+1);

      if(*GoalNodePosition==*MapPosition)
	return newNode(MapPosition,0.0,Node->score()+SlidePenalty,0.0,Node);
      NodeMap->add(
		   newNode(
			    MapPosition,
			    0.0,
			    Node->score()+
			      (PathX==ProfileLength || PathX==0?
			       SlidePenalty:GapPenalty),
			    estimatedScoreFrom(MapPosition),
			    Node
			    )
		   );
    }
  return NULL;
}

node* alignProfile::astarSearch(void)
{
  mapPosition* StartPosition = newMapPosition(0,0);
  node* StartNode =
    newNode(StartPosition,0.0,0.0,estimatedScoreFrom(StartPosition),NULL);
  nodeCntMapCnt(0,0);
  NodeMap->add(StartNode);
  if(StartNode->positionInMap()==GoalNodePosition)
    {  
      cerr << "Start Node is GoalNode!\n";
      return NULL;
    }
  node* GoalNode;

// The statement below is main part of A* algorithm.
  node* NodeNow;
  while(NULL==(GoalNode=generateNode(NodeNow=NodeMap->best())))
    {
//      showNodeCntMap(NodeNow->positionInMap());
    }
  return GoalNode;
}

// This function analyzes the links between nodes and generate the
// path from the start node to the goal node.

double alignProfile::showAlignment(node* GoalNode)
{
  mapPosition* PathPositionArray[ProfileLength+SeqLength+2];
  int PathLength = 0;
  for(node* NodeNow = GoalNode; NodeNow!=NULL; NodeNow=NodeNow->path())
    {
      nodeCntMapPath
	(
	 NodeNow->positionInMap()->x(),
	 NodeNow->positionInMap()->y()
	 );
      PathPositionArray[PathLength++] = NodeNow->positionInMap();
    }

// Now the aligned sequences are generated.

  double ScoreWithoutGaps = 0.0;
  char SeqAlignedA[PathLength];
  char SeqAlignedB[PathLength];
  for(int I=PathLength-2,P=0;I>=0;--I,++P)
    {
      int PrevX = PathPositionArray[I+1]->x();
      int PrevY = PathPositionArray[I+1]->y();
      int X     = PathPositionArray[I  ]->x();
      int Y     = PathPositionArray[I  ]->y();

      if(X==PrevX)
	{
	  SeqAlignedA[P] = '-';
	  amino Amino(Seq[PrevY]);
	  SeqAlignedB[P] = Amino.single();
	}
      else if(Y==PrevY)
	{
	  SeqAlignedA[P] = SeqStruct[PrevX];
	  SeqAlignedB[P] = '-';
	}
      else
	{
	  SeqAlignedA[P] = SeqStruct[PrevX];
	  amino Amino(Seq[PrevY]);
	  SeqAlignedB[P] = Amino.single();
	  ScoreWithoutGaps+=Profile[Seq[PrevY]][PrevX];
	}
    }
  SeqAlignedA[P] = SeqAlignedB[P] = '\0';
  puts(SeqAlignedA);
  puts(SeqAlignedB);
  return ScoreWithoutGaps;
}
