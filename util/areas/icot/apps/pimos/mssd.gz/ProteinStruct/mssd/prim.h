// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

enum {SEQUENCE,STRUCTURE,BOTH2};


class aminoFreq
{
  wavelet* Wavelets;
  int      NumberOfCoefs;
  int      Width;
  double*  FreqCoef;
 public:
  inline aminoFreq(void)
    {
      FreqCoef = NULL;
    }
  inline ~aminoFreq(void)
    {
      delete FreqCoef;
    }
  inline init(int W,int NCoefs)
    {
      NumberOfCoefs = NCoefs;
      Width         = W;
      FreqCoef = new double[NCoefs];
      for(int I=0;I<NumberOfCoefs;++I)
	FreqCoef[I] = 0.0;
      Wavelets = waveletDB(NumberOfCoefs,Width);
    }
  inline push(int Position)
    {
      if(Position < 0 || Position>=Width)
	{
	  cerr << "Out of range in aminoFreq push!\n";
	  exit(1);
	}
      for(int I=0;I<NumberOfCoefs;++I)
	FreqCoef[I]+= (*Wavelets)(I,Position);
    }
  inline void freqCoef(int Order,double Freq)
    {
      FreqCoef[Order] = Freq;
    }
  inline double freqCoef(int Order)
    {
      return FreqCoef[Order];
    }
  inline double freq(int Position)
    {
      if(Position < 0 || Position>=Width)
	{
	  cerr << "Out of range in aminoFreq push!\n";
	  exit(1);
	}
      double Freq = 0;
      for(int I=0;I<NumberOfCoefs;++I)
	Freq += FreqCoef[I]*(*Wavelets)(I,Position);
      return (Freq>1.0? Freq: 1.0);
    }
};

class structProf
{
  int        Width;
  int        NumberOfCoefs;
  aminoFreq* AminoFreq;
  int        TotalFreq;
 public:
  inline structProf(void)
    {
      Width        = 0;
      NumberOfCoefs = 0;
      TotalFreq    = 0;
      AminoFreq    = new aminoFreq[NumberOfAminoTypes];
    }
  inline structProf(int W,int NCoefs)
    {
      init(W,NCoefs);
    }
  inline void init(int W,int NCoefs)
    {
      Width         = W;
      NumberOfCoefs = NCoefs;
      TotalFreq     = 0;
      AminoFreq     = new aminoFreq[NumberOfAminoTypes];
      for(int I=0;I<NumberOfAminoTypes;++I)
	{
	  AminoFreq[I].init(Width,NumberOfCoefs);
	}
    }
  inline void push(int AminoType,int Position)
    {
      AminoFreq[AminoType].push(Position);
    }
  inline void totalFreqCnt(void)
    {
      TotalFreq++;
    }
  inline void totalFreq(int FreqClass)
    {
      TotalFreq = FreqClass;
    }
  inline int totalFreq(void)
    {
      return TotalFreq;
    }
  inline double freq(int AminoType,int Position)
    {
      double Freq = AminoFreq[AminoType].freq(Position);
      return (Freq == 1.0 ? 0.01: Freq);
    }
  inline double freqCoef(int AminoType,int Order)
    {
      return AminoFreq[AminoType].freqCoef(Order);
    }
  inline void   freqCoef(int AminoType,int Order,double Freq)
    {
      AminoFreq[AminoType].freqCoef(Order,Freq);
    }
};

class primStat
{
  int         Level;
  int         Width;
  int         NumberOfClasses;
  int         NumberOfCoefs;
  aminoFreq*  AminoFreq;
  structProf* StructProf;
  int         TotalAminoFreq[NumberOfAminoTypes];
  int         TotalFreq;
 public:
  inline primStat(void)
    {
      Level           = -1;
      Width           =  0;
      NumberOfClasses =  0;
      NumberOfCoefs   =  0;
      TotalFreq       =  0;
      for(int T=0;T<NumberOfAminoTypes;++T)
	TotalAminoFreq[T] = 0;
      AminoFreq       =  NULL;
      StructProf      =  NULL;
    }
  inline primStat(int L,int NClasses)
    {
      init(L,NClasses);
    }
  inline ~primStat(void)
    {
      delete AminoFreq;
      delete StructProf;
    }
  void init(int L,int NClasses);
  void init(FILE* PrimStatFile);
  void push(mssd* MSSD);
  inline int totalFreq(void)
    {
      return TotalFreq;
    }
  inline int aminoFreq(int AminoType)
    {
      return TotalAminoFreq[AminoType];
    }
  inline void print(void)
    {
      fprint(stdout);
    }
  void fprint(FILE* PrimStatFile);
  void probability(int* AminoSeq,    double* Probabilities, int Mode);
  void probability
    (
     int     StructClass,
     int     Position,
     double* AminoProfs,
     int     Mode
     );
  void score(int* AminoSeq,    double* Probabilities, int Mode);
  void printProfile(int StructClass, int Mode);
};
