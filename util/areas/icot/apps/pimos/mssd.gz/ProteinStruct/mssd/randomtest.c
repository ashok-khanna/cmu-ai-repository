// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdio.h>
#include <stream.h>

extern "C"{
  double drand48(void);
}

main()
{
  double X,Y;
  int    Total = 1000000;
  int    Hit   = 0;
  for(int I=0;I<Total;++I)
    {
      X = drand48()*2.0-1.0;
      Y = drand48()*2.0-1.0;
      if(X*X+Y*Y < 1.0) Hit++;
    }
  double Area = double(Hit)/double(Total);
  printf("Area = %10.5lf\n",Area*4.0);
}
