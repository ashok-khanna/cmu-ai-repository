// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdio.h>
#include <stream.h>

extern "C"{
  double drand48(void);
}

int selection(int NumberOfItems,double* Probabilities)
{
  double Total = 0.0;
  for(int I=0;I<NumberOfItems;++I)
    {
      Total+= Probabilities[I];
    }
  int Selection;
  double R = drand48();
  double SubTotal = Probabilities[0]/Total;
  for(    I=0;I<NumberOfItems-1;++I)
    {
      if(SubTotal>R)
	break;
      SubTotal += Probabilities[I+1]/Total;
    }
  return I;
}

main()
{
  int    Total = 1000000;
  double Prob[4];
  int    Cnt[4];
  for(int I=0;I<4;++I)
    {
      Prob[I] = I+1;
      Cnt [I] = 0;
    }
  for(int T=0;T<Total;++T)
    {
      Cnt[selection(4,Prob)]++;
    }
  printf("%10d %10d %10d %10d\n",Cnt[0],Cnt[1],Cnt[2],Cnt[3]);

}

