// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stream.h>
#include "../wavelet/wavelet.h"
#include "mssd.h"
#include "geom.h"

void hyperGeomStat::push(mssd* MSSD)
{
  int LevelLengthI = MSSD->levelLength(StructSetI.level());
  int LevelLengthJ = MSSD->levelLength(StructSetJ.level());
  int LevelLengthK = MSSD->levelLength(StructSetK.level());
  for(int Pi=0;Pi<LevelLengthI;++Pi)
    {
      int Pj = Pi+StructSetJ.offset();
      int Pk = Pi+StructSetK.offset();
      if(Pj >= 0 && Pk >= 0 
	 && Pj < MSSD->levelLength(StructSetJ.level())
	 && Pk < MSSD->levelLength(StructSetK.level())
	 )
	{
	  TotalFreq++;
	  int ClassI = MSSD->conformationClass(StructSetI.level(),Pi);
	  int ClassJ = MSSD->conformationClass(StructSetJ.level(),Pj);
	  int ClassK = MSSD->conformationClass(StructSetK.level(),Pk);
	  StructSetI.structFreqCnt(ClassI);
	  StructSetJ.structFreqCnt(ClassJ);
	  StructSetK.structFreqCnt(ClassK);
	  Coocurrence[ClassI][ClassJ][ClassK]++;
	}
    }
  if(MSSD->next()!= NULL)
    push(MSSD->next());
}
void hyperGeomStat::init  (FILE* HyperGeomStatFile)
{
  char BuffLine[2048];
  GeomWeight = 0.0;
  if(NULL==fgets(BuffLine,2047,HyperGeomStatFile))
    {
      cerr << "Invalid Geometric statistic data file!\n";
      exit(1);
    }
  int LevelI;
  int LevelJ;
  int LevelK;
  int OffsetI;
  int OffsetJ;
  int OffsetK;
  if(NULL==fgets(BuffLine,2047,HyperGeomStatFile))
    {
      cerr << "Invalid Hyper Geometric statistic data file!\n";
      exit(1);
    }
  sscanf(BuffLine+22,"%d",&LevelI);
  if(NULL==fgets(BuffLine,2047,HyperGeomStatFile))
    {
      cerr << "Invalid Hyper Geometric statistic data file!\n";
      exit(1);
    }
  sscanf(BuffLine+22,"%d",&LevelJ);
  if(NULL==fgets(BuffLine,2047,HyperGeomStatFile))
    {
      cerr << "Invalid Hyper Geometric statistic data file!\n";
      exit(1);
    }
  sscanf(BuffLine+22,"%d",&LevelK);
  if(NULL==fgets(BuffLine,2047,HyperGeomStatFile))
    {
      cerr << "Invalid Hyper Geometric statistic data file!\n";
      exit(1);
    }
  sscanf(BuffLine+22,"%d",&OffsetI);
  if(NULL==fgets(BuffLine,2047,HyperGeomStatFile))
    {
      cerr << "Invalid Hyper Geometric statistic data file!\n";
      exit(1);
    }
  sscanf(BuffLine+22,"%d",&OffsetJ);
  if(NULL==fgets(BuffLine,2047,HyperGeomStatFile))
    {
      cerr << "Invalid Hyper Geometric statistic data file!\n";
      exit(1);
    }
  sscanf(BuffLine+22,"%d",&OffsetK);

  if(NULL==fgets(BuffLine,2047,HyperGeomStatFile))
    {
      cerr << "Invalid Hyper Geometric statistic data file!\n";
      exit(1);
    }
  sscanf(BuffLine+22,"%d",&TotalFreq);
  StructSetI.init(LevelI,OffsetI);
  StructSetJ.init(LevelJ,OffsetJ);
  StructSetK.init(LevelK,OffsetK);

  if(NULL==fgets(BuffLine,2047,HyperGeomStatFile))
    {
      cerr << "Invalid Hyper Geometric statistic data file!\n";
      exit(1);
    }
  if(NULL==fgets(BuffLine,2047,HyperGeomStatFile))
    {
      cerr << "Invalid Hyper Geometric statistic data file!\n";
      exit(1);
    }
  if(NULL==fgets(BuffLine,2047,HyperGeomStatFile))
    {
      cerr << "Invalid Hyper Geometric statistic data file!\n";
      exit(1);
    }
  int ClassFreqs[NumberOfClasses];
  int P=1;
  int ClassCnt = 0;
  while(ClassCnt<NumberOfClasses)
    {
      while(isspace(BuffLine[P++])){}
      sscanf(BuffLine+P-1,"%d",&ClassFreqs[ClassCnt++]);
      while(isdigit(BuffLine[P++])){}
    }
  StructSetI.structFreq(ClassFreqs);
  if(NULL==fgets(BuffLine,2047,HyperGeomStatFile))
    {
      cerr << "Invalid Hyper Geometric statistic data file!\n";
      exit(1);
    }
  P=1;
  ClassCnt = 0;
  while(ClassCnt<NumberOfClasses)
    {
      while(isspace(BuffLine[P++])){}
      sscanf(BuffLine+P-1,"%d",&ClassFreqs[ClassCnt++]);
      while(isdigit(BuffLine[P++])){}
    }
  StructSetJ.structFreq(ClassFreqs);
  if(NULL==fgets(BuffLine,2047,HyperGeomStatFile))
    {
      cerr << "Invalid Hyper Geometric statistic data file!\n";
      exit(1);
    }
  P=1;
  ClassCnt = 0;
  while(ClassCnt<NumberOfClasses)
    {
      while(isspace(BuffLine[P++])){}
      sscanf(BuffLine+P-1,"%d",&ClassFreqs[ClassCnt++]);
      while(isdigit(BuffLine[P++])){}
    }
  StructSetK.structFreq(ClassFreqs);
  for(int I=0;I<NumberOfClasses;++I)
    {
      if(NULL==fgets(BuffLine,2047,HyperGeomStatFile))
	{
	  cerr << "Invalid Hyper Geometric statistic data file!\n";
	  exit(1);
	}
      for(int K=0;K<NumberOfClasses;++K)
	{
	  if(NULL==fgets(BuffLine,2047,HyperGeomStatFile))
	    {
	      cerr << "Invalid Hyper Geometric statistic data file!\n";
	      exit(1);
	    }
	  int P=2;
	  int J = 0;
	  while(J<NumberOfClasses)
	    {
	      while(isspace(BuffLine[P++])){}
	      sscanf(BuffLine+P-1,"%d",&Coocurrence[I][J++][K]);
	      while(isdigit(BuffLine[P++])){}
	    }
	}
    }
}

void hyperGeomStat::fprint(FILE* HyperGeomStatFile)
{
  fprintf(HyperGeomStatFile,"Number of Classes    :%6d\n",NumberOfClasses);
  fprintf(HyperGeomStatFile,"Level  I             :%6d\n",StructSetI.level());
  fprintf(HyperGeomStatFile,"Level  J             :%6d\n",StructSetJ.level());
  fprintf(HyperGeomStatFile,"Level  K             :%6d\n",StructSetK.level());
  fprintf(HyperGeomStatFile,"Offset I             :%6d\n",StructSetI.offset());
  fprintf(HyperGeomStatFile,"Offset J             :%6d\n",StructSetJ.offset());
  fprintf(HyperGeomStatFile,"Offset K             :%6d\n",StructSetK.offset());
  fprintf(HyperGeomStatFile,"Total Frequency      :%6d\n",TotalFreq);
  fprintf(HyperGeomStatFile,"Frequencies of Class :\n ");
  for(int Class=0;Class<NumberOfClasses;++Class)
    {
      fprintf(HyperGeomStatFile,"      %c",Class+'A');
    }
  fprintf(HyperGeomStatFile,"\nI ");
  for(    Class=0;Class<NumberOfClasses;++Class)
    {
      fprintf(HyperGeomStatFile,"%6d ",StructSetI.structFreq(Class));
    }
  fprintf(HyperGeomStatFile,"\nJ ");
  for(    Class=0;Class<NumberOfClasses;++Class)
    {
      fprintf(HyperGeomStatFile,"%6d ",StructSetJ.structFreq(Class));
    }
  fprintf(HyperGeomStatFile,"\nK ");
  for(    Class=0;Class<NumberOfClasses;++Class)
    {
      fprintf(HyperGeomStatFile,"%6d ",StructSetK.structFreq(Class));
    }

  fprintf(HyperGeomStatFile,"\n");
  for(int I=0;I<NumberOfClasses;++I)
    {
      fprintf(HyperGeomStatFile,"%c\n",I+'A');
      for(int K=0;K<NumberOfClasses;++K)
	{
	  fprintf(HyperGeomStatFile," %c",K+'A');
	  for(int J=0;J<NumberOfClasses;++J)
	    {
	      fprintf(HyperGeomStatFile,"%6d ",
		      Coocurrence[I][J][K]
		      );
	    }
	  fprintf(HyperGeomStatFile,"\n");
	}
    }
  fflush(HyperGeomStatFile);
}


void hyperGeomStat::expand(void)
{
  double GMean  = 0.0;
  double GMean2 = 0.0;

  int Ci,Cj,Ck;
  for(Ci=0;Ci<NumberOfClasses;++Ci)
    {
      for(Cj=0;Cj<NumberOfClasses;++Cj)
	{
	  for(Ck=0;Ck<NumberOfClasses;++Ck)
	    {
	      double CO = (
			   Coocurrence[Ci][Cj][Ck]==0? 1.0:
			   Coocurrence[Ci][Cj][Ck]
			   );
	      double CONS = 
		Constraint[Ci][Cj][Ck] =
		  -log(CO/double(StructSetI.structFreq(Ci))
		    /double(StructSetJ.structFreq(Cj))
		      /double(StructSetK.structFreq(Ck))
			*double(TotalFreq)*double(TotalFreq));
//		    /double(LevelWidth[StructSetI.level()]);
	      GMean   =  CONS;
	      GMean2 +=  CONS*CONS;
	    }
	}
    }

  double GeomMean  = GMean /NumberOfClasses/NumberOfClasses/NumberOfClasses;
  double GeomMean2 = GMean2/NumberOfClasses/NumberOfClasses/NumberOfClasses;
  GeomWeight = GeomMean2-GeomMean*GeomMean;
//GeomWeight = (GeomMean<0?-GeomMean:GeomMean);
/*
  for(Ci=0;Ci<NumberOfClasses;++Ci)
    {
      for(Cj=0;Cj<NumberOfClasses;++Cj)
	{
	  for(Ck=0;Ck<NumberOfClasses;++Ck)
	    {
	      Constraint[Ci][Cj][Ck] =
		(Constraint[Ci][Cj][Ck]-GeomMean)/GeomWeight;
//	         Constraint[Ci][Cj][Ck]/GeomWeight;
	    }
	}
    }
*/
}

void hyperGeomStat::aneal(void)
{
}

