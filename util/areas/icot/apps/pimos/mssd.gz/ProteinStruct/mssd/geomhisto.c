// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stream.h>
#include "../wavelet/wavelet.h"
#include "mssd.h"
#include "geom.h"

main(int ArgCnt,char** ArgVal)
{
  if(ArgCnt<6)
    {
      cerr << "Too few Arguments!\n";
      cerr << "Usage:\ngeom-histo [Geom Stat File] Level Level Type Type\n";
      exit(1);
    }
  int PL  = atoi(ArgVal[2]);
  int FL  = atoi(ArgVal[3]);

  probabilityMode Mode;
  if(ArgCnt==7 && ArgVal[6][0] == '-')
    {
      switch(ArgVal[6][1])
	{
	case 'p':
	  Mode = PRECEDE;
	  break;
	case 'f':
	  Mode = FOLLOW;
	  break;
	case 'b':
	  Mode = BOTH;
	  break;
	otherwise:
	  Mode = UNKNOWN;
	  break;
	}
    }
  else
    {
      Mode = UNKNOWN;
    }

  FILE* GeomStatFile;
  if(NULL==(GeomStatFile=fopen(ArgVal[1],"r")))
    {
      cerr << "Can't open Geom Stat File!\n";
      exit(1);
    }

  geomStat HomoGeomStats   [NumberOfLevels];
  geomStat HeteroGeomStats1[NumberOfLevels-1];
  geomStat HeteroGeomStats2[NumberOfLevels-1];

  for(int L=0;L<NumberOfLevels;++L)
    {
      HomoGeomStats[L].init(GeomStatFile);
    }
  for(    L=0;L<NumberOfLevels-1;++L)
    {
      HeteroGeomStats1[L].init(GeomStatFile);
    }
  for(    L=0;L<NumberOfLevels-2;++L)
    {
      HeteroGeomStats2[L].init(GeomStatFile);
    }

  int PLC = *ArgVal[4]-'A';
  int FLC = *ArgVal[5]-'A';
  if(PL>FL)
    {
      if(PL==FL+1)
	{
	  HeteroGeomStats1[FL].print(PLC,FLC,Mode);
	}
      else if(PL==FL+2)
	{
	  HeteroGeomStats2[FL].print(PLC,FLC,Mode);
	}
      else
	{
	  cerr << "Invalid Levels\n";
	  exit(1);
	}
    }
  else if(PL==FL)
    {
      HomoGeomStats[FL].print(PLC,FLC,Mode);
    }
  else
    {
      cerr << "Invalid Levels\n";
    }
}

