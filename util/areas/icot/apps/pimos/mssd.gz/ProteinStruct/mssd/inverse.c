// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stream.h>
#include <math.h>
#include "../wavelet/wavelet.h"
#include "../amino/amino.h"
#include "mssd.h"
#include "prim.h"

main(int ArgCnt,char** ArgVal)
{
  if(ArgCnt<3)
    {
      cerr << "Too few Arguments!\n";
      cerr << 
	form("Usage:\n%s [Primary Constraints File] [MaxLevel] -[stb]\n",
	     ArgVal[0]);
      exit(1);
    }

  FILE* PrimStatFile;
  if(NULL==(PrimStatFile=fopen(ArgVal[1],"r")))
    {
      cerr << "Can't open Primary Constraints File!\n";
      exit(1);
    }

  int MaxLevel = atoi(ArgVal[2]);
  int Mode = BOTH2;

  if(ArgCnt >= 4 && ArgVal[3][0] == '-')
    {
      switch(ArgVal[3][1])
	{
	case 's':
	  Mode = SEQUENCE;
	  break;
	case 't':
	  Mode = STRUCTURE;
	  break;
	case 'b':
	  Mode = BOTH2;
	  break;
	}
    }

  primStat PrimStat  [NumberOfLevels];

  for(int L=0;L<NumberOfLevels;++L)
    {
      PrimStat[L].init(PrimStatFile);
    }

  int    TotalAminoFreq = 0;
  for(int T=0;T<NumberOfAminoTypes;++T)
    {
      TotalAminoFreq+=PrimStat[0].aminoFreq(T);
    }

  double AminoFreq[NumberOfAminoTypes];
  for(    T=0;T<NumberOfAminoTypes;++T)
    {
      AminoFreq[T] =
	log(double(PrimStat[0].aminoFreq(T))/double(TotalAminoFreq));
    }
  while(1)
    {
      mssd MSSD;
      if(0==MSSD.read(stdin))
	break;

      for(mssd* MSSDNow = &MSSD;MSSDNow!=NULL;MSSDNow = MSSDNow->next())
	{
	  int    SeqLength = MSSDNow->seqLength();
	  int    ConstraintCnt[SeqLength];
	  double InverseProfile   [NumberOfAminoTypes][SeqLength];
	  for(int I=0;I<SeqLength;++I)
	    {
	      for(int T=0;T<NumberOfAminoTypes;++T)
		{
		  InverseProfile[T][I] = 0.0;
		}
	    }
	  for(int L=0;L<=MaxLevel && MSSDNow->levelLength(L)>0;++L)
	    {
	      double InverseProfileTmp[NumberOfAminoTypes][SeqLength];
	      for(int I=0;I<SeqLength;++I)
		{
		  ConstraintCnt[I] = 0;
		  for(int T=0;T<NumberOfAminoTypes;++T)
		    {
		      InverseProfileTmp[T][I] = 0.0;
		    }
		}
	      for(    I=0;I<MSSDNow->levelLength(L);++I)
		{
		  int ConformationClass = MSSDNow->conformationClass(L,I);
		  for(int J=0;J<LevelWidth[L];++J)
		    {
		      ConstraintCnt[I+J] ++;
		      double AminoProfile[NumberOfAminoTypes];
		      PrimStat[L].probability
			(
			 ConformationClass,
			 J,
			 AminoProfile,
			 Mode
			 );
		      for(int T=0;T<NumberOfAminoTypes;++T)
			{
			  InverseProfileTmp[T][I+J] += log(AminoProfile[T]);
			}
		    }
		}

	      for(    I=0;I<SeqLength;++I)
		{
		  for(int T=0;T<NumberOfAminoTypes;++T)
		    {
		      InverseProfile[T][I] +=
			InverseProfileTmp[T][I]/ConstraintCnt[I];
		    }
		}
	    }
	  double MeanScore = 0.0;
	  double Variance  = 0.0;
	  for(    I=0;I<SeqLength;++I)
	    {
	      double MeanScoreNow  = 0.0;
	      double Mean2ScoreNow = 0.0;
	      for(int T=0;T<NumberOfAminoTypes;++T)
		{
		  printf("%5.1lf ",InverseProfile[T][I]);
		  double ScoreNow = InverseProfile[T][I]*exp(AminoFreq[T]);
		  MeanScoreNow  += ScoreNow;
		  Mean2ScoreNow += ScoreNow*ScoreNow;
		}
	      printf("\n");
	      MeanScoreNow  /= NumberOfAminoTypes;
	      Mean2ScoreNow /= NumberOfAminoTypes;
	      MeanScore += MeanScoreNow;
	      Variance  += Mean2ScoreNow - MeanScoreNow;
	    }
	  printf("MeanScore: %10.5lf\n",MeanScore);
	  printf("Deviation: %10.5lf\n",sqrt(Variance));


	  int* AminoSequence = MSSDNow->aminoSequence();
	  double Score = 0.0;
	  printf("Native    :");
	  for(   I=0;I<SeqLength;++I)
	    {
	      amino Amino(AminoSequence[I]);
	      Score += InverseProfile[AminoSequence[I]][I];
	      printf("%c",Amino.single());
	    }
	  printf("\nPredicted :");
	  for(   I=0;I<SeqLength;++I)
	    {
	      double ProbMax = -100000.0;
	      int MaxLikelyAminoType = -1;
	      for(int T=0;T<NumberOfAminoTypes;++T)
		{
		  if(InverseProfile[T][I]>ProbMax)
		    {
		      ProbMax = InverseProfile[T][I];
		      MaxLikelyAminoType = T;
		    }
		}
	      amino Amino(MaxLikelyAminoType);
	      printf("%c",Amino.single());
	    }
	  printf("\n");
	  printf("Score : %10.5lf\n",Score);
	  double ZScore = (Score-MeanScore)/sqrt(Variance>0?Variance:1.0);
	  printf("ZScore: %10.5lf\n",ZScore);
	}
    }
}

