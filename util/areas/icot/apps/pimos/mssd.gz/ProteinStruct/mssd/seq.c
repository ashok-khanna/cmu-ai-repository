// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdio.h>
#include <stream.h>

main()
{
  char BuffLine[1024];
  while(gets(BuffLine))
    {
      for(int I = 0;BuffLine[I]!='\0';++I)
	putchar(BuffLine[I]);
      putchar(':');
      putchar(' ');
      gets(BuffLine);
      for(    I = 0;BuffLine[I]!='\0';++I)
	putchar(BuffLine[I]);
      putchar('\n');
      gets(BuffLine);
      gets(BuffLine);
      gets(BuffLine);
      gets(BuffLine);
      gets(BuffLine);
      gets(BuffLine);
      gets(BuffLine);
      gets(BuffLine);
      gets(BuffLine);
      gets(BuffLine);
      gets(BuffLine);
      gets(BuffLine);
    }
}
