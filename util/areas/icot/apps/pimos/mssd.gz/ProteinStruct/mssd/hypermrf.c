// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stream.h>
#include <math.h>
#include "../wavelet/wavelet.h"
#include "../amino/amino.h"
#include "mssd.h"
#include "prim.h"
#include "geom.h"
#include "predict.h"

double PrimaryWeight;
double LeftRightWeightA;
double LeftRightWeightB;
double Down1Weight;
double Up1Weight;
double Down2Weight;
double Up2Weight;

main(int ArgCnt,char** ArgVal)
{
  if(ArgCnt<4)
    {
      cerr << "Too few Arguments!\n";
      cerr << 
	form("Usage:\n%s [Primary Stat File] [Geometric Stat File]",ArgVal[0])
	  << " -[stb] -[osOSMC]\n";
      exit(1);
    }
  FILE* WeightFile;
  if(NULL==(WeightFile=fopen(ArgVal[1],"r")))
    {
      cerr << "Can't open Wight File!\n";
      exit(1);
    }

  double TempFactor;

  fscanf(WeightFile,"%lf %lf %lf %lf %lf %lf %lf %lf",
	 &PrimaryWeight,&LeftRightWeightA,&LeftRightWeightB,
	 &Down1Weight,&Up1Weight,
	 &Down2Weight,&Up2Weight,
	 &TempFactor);

  printf("Prim Weight      %10.5lf\n",PrimaryWeight);
  printf("LeftRight WeightA%10.5lf\n",LeftRightWeightA);
  printf("LeftRight WeightB%10.5lf\n",LeftRightWeightB);
  printf("Down1 Weight     %10.5lf\n",Down1Weight);
  printf("Up1 Weight       %10.5lf\n",Up1Weight);
  printf("Down2 Weight     %10.5lf\n",Down2Weight);
  printf("Up2 Weight       %10.5lf\n",Up2Weight);
  printf("Temp Factor      %10.5lf\n",TempFactor);

  double TotalWeight =
	 PrimaryWeight+LeftRightWeightA+LeftRightWeightB+
	 Down1Weight+Up1Weight+Down2Weight+Up2Weight;

  PrimaryWeight    = PrimaryWeight    /TotalWeight *TempFactor;
  LeftRightWeightA = LeftRightWeightA /TotalWeight *TempFactor;
  LeftRightWeightB = LeftRightWeightB /TotalWeight *TempFactor;
  Down1Weight      = Down1Weight      /TotalWeight *TempFactor;
  Up1Weight        = Up1Weight        /TotalWeight *TempFactor;
  Down2Weight      = Down2Weight      /TotalWeight *TempFactor;
  Up2Weight        = Up2Weight        /TotalWeight *TempFactor;
  

  FILE* PrimStatFile;
  if(NULL==(PrimStatFile=fopen(ArgVal[2],"r")))
    {
      cerr << "Can't open Primary Constraints File!\n";
      exit(1);
    }
  int ProbabilityMode = BOTH2;
  if(ArgCnt >= 5 && ArgVal[4][0] == '-')
    {
      switch(ArgVal[4][1])
	{
	case 's':
	  ProbabilityMode = SEQUENCE;
	  break;
	case 't':
	  ProbabilityMode = STRUCTURE;
	  break;
	case 'b':
	  ProbabilityMode = BOTH2;
	  break;
	}
    }
  int MutationModeI= RANDOM;
  int MutationMode = STOCHASTIC;
  if(ArgCnt >= 6 && ArgVal[5][0] == '-')
    {
      switch(ArgVal[5][1])
	{
	case 'o':
	  MutationModeI = OPTIMAL;
	  MutationMode  = OPTIMAL;
	  break;
	case 's':
	  MutationModeI = STOCHASTIC;
	  MutationMode  = STOCHASTIC;
	  break;
	case 'O':
	  MutationModeI = RANDOM;
	  MutationMode  = OPTIMAL;
	  break;
	case 'S':
	  MutationModeI = RANDOM;
	  MutationMode  = STOCHASTIC;
	  break;
	case 'M':
	  MutationModeI = OPTIMAL;
	  MutationMode  = STOCHASTIC;
	  break;
	case 'C':
	  MutationModeI = COPY;
	  MutationMode  = OPTIMAL;
	  break;
	}
    }
  int ExternalIteration = 64;
  if(ArgCnt >=7)
    ExternalIteration = atoi(ArgVal[6]);
  int InternalIteration = 1024;
  if(ArgCnt >=8)
    InternalIteration = atoi(ArgVal[7]);

  primStat* PrimStats = new primStat[NumberOfLevels];

  FILE* HyperGeomStatsFile;
  if(NULL==(HyperGeomStatsFile=fopen(ArgVal[3],"r")))
    {
      cerr << "Can't open HyperGeomStatsFile!\n";
      exit(1);
    }

  hyperGeomStat* HyperGeomStatsA = new hyperGeomStat[NumberOfLevels];
  hyperGeomStat* HyperGeomStatsB = new hyperGeomStat[NumberOfLevels];
  hyperGeomStat* HyperGeomStats1 = new hyperGeomStat[NumberOfLevels-1];
  hyperGeomStat* HyperGeomStats2 = new hyperGeomStat[NumberOfLevels-2];

  int Total[NumberOfLevels];
  int Hit  [NumberOfLevels];
  int GeomPitch[NumberOfLevels];

  for(int L=0;L<NumberOfLevels;++L)
    {
      Total[L] = 0;
      Hit  [L] = 0;
      PrimStats[L].init(PrimStatFile);
      HyperGeomStatsA[L].init(HyperGeomStatsFile);
      HyperGeomStatsA[L].expand();
      printf("Level %3d GeomWeightA %10.5lf\n",L,HyperGeomStatsA[L].weight());
    }
  for(    L=0;L<NumberOfLevels;++L)
    {
      HyperGeomStatsB[L].init(HyperGeomStatsFile);
      HyperGeomStatsB[L].expand();
      printf("Level %3d GeomWeightB %10.5lf\n",L,HyperGeomStatsB[L].weight());
    }
  for(    L=0;L<NumberOfLevels-1;++L)
    {
      HyperGeomStats1[L].init(HyperGeomStatsFile);
      HyperGeomStats1[L].expand();
      printf("Level %3d GeomWeight1 %10.5lf\n",L,HyperGeomStats1[L].weight());
    }
  for(    L=0;L<NumberOfLevels-2;++L)
    {
      HyperGeomStats2[L].init(HyperGeomStatsFile);
      HyperGeomStats2[L].expand();
      printf("Level %3d GeomWeight2 %10.5lf\n",L,HyperGeomStats2[L].weight());
    }

  while(1)
    {
      mssdState MSSDState;
      if(0==MSSDState.read(stdin))
	break;
      MSSDState.initialize
	(
	 PrimStats,
	 HyperGeomStatsA,
	 HyperGeomStatsB,
	 HyperGeomStats1,
	 HyperGeomStats2,
	 MutationModeI,
	 ProbabilityMode,
	 GeomPitch
	 );
      double OriginalScore = MSSDState.hyperCost(ORIGINAL);
      double Score         = MSSDState.hyperCost(PREDICTED);
	  cerr <<
	    form("Original Socre %10.5lf Score %10.5lf\n",OriginalScore,Score);
      int TotalNow[NumberOfLevels];
      int HitNow  [NumberOfLevels];
      for(int L=0;L<NumberOfLevels;++L)
	{
	  TotalNow[L] = 0;
	  HitNow  [L] = 0;
	}
      MSSDState.accuracy(TotalNow,HitNow);
      MSSDState.changeMode(MutationMode,ProbabilityMode);
      for(int I=0;I<ExternalIteration;++I)
	{
	  for(int J=0;J<InternalIteration;++J)
	    {
	      MSSDState.hyperMutate(1+2+4+8+16+32+64+128+256);
	    }
	  Score = MSSDState.hyperCost(PREDICTED);
	  cerr <<
	    form("Original Socre %10.5lf Score %10.5lf\n",OriginalScore,Score);
	  for(int L=0;L<NumberOfLevels;++L)
	    {
	      TotalNow[L] = 0;
	      HitNow  [L] = 0;
	    }
	  MSSDState.accuracy(TotalNow,HitNow);
	}
      MSSDState.accuracy(Total,Hit);
    }
  for(   L=0;L<NumberOfLevels;++L)
    {
      printf("Level %3d Total %5d Hit %5d  Ratio %10.5lf \n",
	     L,Total[L],Hit[L],
	     (Total[L]>0?double(Hit[L])/double(Total[L]):0));
    }
}




