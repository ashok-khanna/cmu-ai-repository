// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stream.h>
#include <math.h>
#include "../wavelet/wavelet.h"
#include "../amino/amino.h"
#include "mssd.h"
#include "prim.h"
#include "geom.h"
#include "predict.h"

double PrimaryWeight;
double LeftRightWeightA;
double LeftRightWeightB;
double Down1Weight;
double Up1Weight;
double Down2Weight;
double Up2Weight;

main(int ArgCnt,char** ArgVal)
{
  if(ArgCnt<4)
    {
      cerr << "Too few Arguments!\n";
      cerr << 
	form("Usage:\n%s [Primary Stat File] [Geometric Stat File]",ArgVal[0])
	  << " -[stb] -[osrc]\n";
      exit(1);
    }
  FILE* WeightFile;
  if(NULL==(WeightFile=fopen(ArgVal[1],"r")))
    {
      cerr << "Can't open Wight File!\n";
      exit(1);
    }

  double TempFactor;

  fscanf(WeightFile,"%lf %lf %lf %lf %lf %lf %lf %lf",
	 &PrimaryWeight,&LeftRightWeightA,&LeftRightWeightB,
	 &Down1Weight,&Up1Weight,
	 &Down2Weight,&Up2Weight,
	 &TempFactor);

  cerr << form("Prim Weight      %10.5lf\n",PrimaryWeight);
  cerr << form("LeftRight WeightA%10.5lf\n",LeftRightWeightA);
  cerr << form("LeftRight WeightB%10.5lf\n",LeftRightWeightB);
  cerr << form("Down1 Weight     %10.5lf\n",Down1Weight);
  cerr << form("Up1 Weight       %10.5lf\n",Up1Weight);
  cerr << form("Down2 Weight     %10.5lf\n",Down2Weight);
  cerr << form("Up2 Weight       %10.5lf\n",Up2Weight);
  cerr << form("Temp Factor      %10.5lf\n",TempFactor);

  double TotalWeight =
	 PrimaryWeight+LeftRightWeightA+LeftRightWeightB+
	 Down1Weight+Up1Weight+Down2Weight+Up2Weight;

  PrimaryWeight    = PrimaryWeight    /TotalWeight *TempFactor;
  LeftRightWeightA = LeftRightWeightA /TotalWeight *TempFactor;
  LeftRightWeightB = LeftRightWeightB /TotalWeight *TempFactor;
  Down1Weight      = Down1Weight      /TotalWeight *TempFactor;
  Up1Weight        = Up1Weight        /TotalWeight *TempFactor;
  Down2Weight      = Down2Weight      /TotalWeight *TempFactor;
  Up2Weight        = Up2Weight        /TotalWeight *TempFactor;

  FILE* PrimStatFile;
  if(NULL==(PrimStatFile=fopen(ArgVal[2],"r")))
    {
      cerr << "Can't open Primary Constraints File!\n";
      exit(1);
    }
  int ProbabilityMode = BOTH2;
  if(ArgCnt >= 5 && ArgVal[4][0] == '-')
    {
      switch(ArgVal[4][1])
	{
	case 's':
	  ProbabilityMode = SEQUENCE;
	  break;
	case 't':
	  ProbabilityMode = STRUCTURE;
	  break;
	case 'b':
	  ProbabilityMode = BOTH2;
	  break;
	}
    }


  int MutationModeI= RANDOM;
  int MutationMode = STOCHASTIC;
  if(ArgCnt >= 6 && ArgVal[5][0] == '-')
    {
      switch(ArgVal[5][1])
	{
	case 'o':
	  MutationModeI = OPTIMAL;
	  MutationMode  = RANDOM;
	  break;
	case 's':
	  MutationModeI = STOCHASTIC;
	  MutationMode  = RANDOM;
	  break;
	case 'r':
	  MutationModeI = RANDOM;
	  MutationMode  = RANDOM;
	  break;
	case 'c':
	  MutationModeI = COPY;
	  MutationMode  = RANDOM;
	  break;
	}
    }
  int ExternalIteration = 64;
  if(ArgCnt >=7)
    ExternalIteration = atoi(ArgVal[6]);
  int InternalIteration = 1024;
  if(ArgCnt >=8)
    InternalIteration = atoi(ArgVal[7]);

  primStat* PrimStats = new primStat[NumberOfLevels];

  FILE* HyperGeomStatsFile;
  if(NULL==(HyperGeomStatsFile=fopen(ArgVal[3],"r")))
    {
      cerr << "Can't open HyperGeomStatsFile!\n";
      exit(1);
    }

  hyperGeomStat* HyperGeomStatsA = new hyperGeomStat[NumberOfLevels];
  hyperGeomStat* HyperGeomStatsB = new hyperGeomStat[NumberOfLevels];
  hyperGeomStat* HyperGeomStats1 = new hyperGeomStat[NumberOfLevels-1];
  hyperGeomStat* HyperGeomStats2 = new hyperGeomStat[NumberOfLevels-2];

  int GeomPitch[NumberOfLevels];

  for(int L=0;L<NumberOfLevels;++L)
    {
      PrimStats[L].init(PrimStatFile);
      HyperGeomStatsA[L].init(HyperGeomStatsFile);
      HyperGeomStatsA[L].expand();
    }
  for(    L=0;L<NumberOfLevels;++L)
    {
      HyperGeomStatsB[L].init(HyperGeomStatsFile);
      HyperGeomStatsB[L].expand();
    }
  for(    L=0;L<NumberOfLevels-1;++L)
    {
      HyperGeomStats1[L].init(HyperGeomStatsFile);
      HyperGeomStats1[L].expand();
    }
  for(    L=0;L<NumberOfLevels-2;++L)
    {
      HyperGeomStats2[L].init(HyperGeomStatsFile);
      HyperGeomStats2[L].expand();
    }

  while(1)
    {
      mssdState MSSDState;
      if(0==MSSDState.read(stdin))
	break;
      MSSDState.initialize
	(
	 PrimStats,
	 HyperGeomStatsA,
	 HyperGeomStatsB,
	 HyperGeomStats1,
	 HyperGeomStats2,
	 MutationModeI,
	 ProbabilityMode,
	 GeomPitch
	 );
      MSSDState.hyperCost(ORIGINAL);
      MSSDState.hyperCost(PREDICTED);
      MSSDState.changeMode(MutationMode,ProbabilityMode);
      for(int I=0;I<ExternalIteration;++I)
	{
	  for(int J=0;J<InternalIteration;++J)
	    {
	      MSSDState.hyperMutate(1+2+4+8+16+32+64+128+256);
	    }
	  MSSDState.hyperCost(PREDICTED);
	}
    }
}



