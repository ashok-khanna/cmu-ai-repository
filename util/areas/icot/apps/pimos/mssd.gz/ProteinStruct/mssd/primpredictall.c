// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stream.h>
#include "../wavelet/wavelet.h"
#include "../amino/amino.h"
#include "mssd.h"
#include "prim.h"

main(int ArgCnt,char** ArgVal)
{
  if(ArgCnt<2)
    {
      cerr << "Too few Arguments!\n";
      cerr << 
	form("Usage:\n%s [Primary Constraints File] -[stb]\n",
	     ArgVal[0]);
      exit(1);
    }

  FILE* PrimStatFile;
  if(NULL==(PrimStatFile=fopen(ArgVal[1],"r")))
    {
      cerr << "Can't open Primary Constraints File!\n";
      exit(1);
    }
  int Mode  = BOTH;

  if(ArgCnt >= 3 && ArgVal[2][0] == '-')
    {
      switch(ArgVal[2][1])
	{
	case 's':
	  Mode = SEQUENCE;
	  break;
	case 't':
	  Mode = STRUCTURE;
	  break;
	case 'b':
	  Mode = BOTH2;
	  break;
	}
    }

  primStat PrimStat  [NumberOfLevels];

  for(int L=0;L<NumberOfLevels;++L)
    {
      PrimStat[L].init(PrimStatFile);
    }

  int Accuracy[NumberOfLevels];
  int Total[NumberOfLevels];

  for(int K=0;K<NumberOfLevels;++K)
    {
      Accuracy[K] = Total[K] = 0;
    }

  char BuffLine[1024];
  while(gets(BuffLine))
    {
      printf("%s\n",BuffLine);
      gets(BuffLine);
      int  SeqLen   = strlen(BuffLine);
      int* Sequence = new int[SeqLen+1];
      Sequence[SeqLen] = -3;
      for(int I=0;I<SeqLen;++I)
	{
	  if      (BuffLine[I] == '<')
	    Sequence[I] = -1;
	  else if (BuffLine[I] == '>')
	    Sequence[I] = -2;
	  else
	    {
	      amino Amino(BuffLine[I]);
	      Sequence[I] = Amino.id();
	    }
	}
      for(    L=0;L<NumberOfLevels;++L)
	{
	  gets(BuffLine);
	  int P = 0;
	  int* SequenceTmp = Sequence;
	  double Probabilities[NumberOfClasses];
	  while(*SequenceTmp == -1)
	    {
	      printf("<");
	      P++;
	      SequenceTmp++;
	      int SeqLenTmp = 0;
	      while(*(SequenceTmp+SeqLenTmp)!= -2)
		{
		  SeqLenTmp++;
		}
	      if(SeqLenTmp>=LevelWidth[L])
		{
		  for(I=0;I<SeqLenTmp-LevelWidth[L]+1;++I)
		    {
		      PrimStat[L].probability
			(SequenceTmp+I,Probabilities,Mode);
		      int BestClass = -1;
		      double Prob   = 0.0;
		      for(int T=0;T<NumberOfClasses;++T)
			{
			  if(Probabilities[T] > Prob)
			    {
			      Prob = Probabilities[T];
			      BestClass = T;
			    }
			}
		      printf("%c",BestClass+'A');
		      if(*(BuffLine+P)-'A' == BestClass)
			{
			  Accuracy[L] ++;
			}
		      Total[L] ++;
		      P++;
		    }
		}
	      while(*SequenceTmp!= -2)
		{
		  SequenceTmp++;
		}
	      SequenceTmp++;
	      printf(">");
	      P++;
	    }
	  printf("\n");
	}
    }
  for(   K=0;K<NumberOfLevels;++K)
    {
      printf("Level %4d: Total %5d Hit %5d  Accuracy %10.5lf\n",
	     K,Total[K],Accuracy[K],
	     (Total[K]==0? 0.0 :double(Accuracy[K])/double(Total[K])));
    }

}
