// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stream.h>
#include "../wavelet/wavelet.h"
#include "mssd.h"
#include "prim.h"

main(int ArgCnt,char** ArgVal)
{
  if(ArgCnt<4)
    {
      cerr << "Too few Arguments!\n";
      cerr << 
	form("Usage:\n%s [Primary Constraints File] Level Class -[stb]\n",
	     ArgVal[0]);
      exit(1);
    }

  FILE* PrimStatFile;
  if(NULL==(PrimStatFile=fopen(ArgVal[1],"r")))
    {
      cerr << "Can't open Primary Constraints File!\n";
      exit(1);
    }
  int Level = atoi(ArgVal[2]);
  int Class = *(ArgVal[3]) - 'A';
  int Mode  = BOTH2;

  if(ArgCnt >= 5 && ArgVal[4][0] == '-')
    {
      switch(ArgVal[4][1])
	{
	case 's':
	  Mode = SEQUENCE;
	  break;
	case 't':
	  Mode = STRUCTURE;
	  break;
	case 'b':
	  Mode = BOTH2;
	  break;
	}
    }

  primStat PrimStat  [NumberOfLevels];

  for(int L=0;L<NumberOfLevels;++L)
    {
      PrimStat[L].init(PrimStatFile);
    }

  PrimStat[Level].printProfile(Class,Mode);
}
