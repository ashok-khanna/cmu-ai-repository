// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stream.h>
#include "../wavelet/wavelet.h"
#include "mssd.h"
#include "geom.h"

main(int ArgCnt,char** ArgVal)
{
  if(ArgCnt<2)
    {
      cerr << "Too few Arguments!\n";
      cerr << form("Usage:\n%s [MSSDData]\n",ArgVal[0]);
      exit(1);
    }

  FILE* MSSDFile;
  if(NULL==(MSSDFile=fopen(ArgVal[1],"r")))
    {
      cerr << "Can't open MSSDData File!\n";
      exit(1);
    }

  geomStat HomoGeomStats   [NumberOfLevels];
  geomStat HeteroGeomStats1[NumberOfLevels-1];
  geomStat HeteroGeomStats2[NumberOfLevels-1];

  for(int L=0;L<NumberOfLevels;++L)
    {
      HomoGeomStats[L].init(L,L,NumberOfClasses);
    }
  for(    L=0;L<NumberOfLevels-1;++L)
    {
      HeteroGeomStats1[L].init(L+1,L,NumberOfClasses);
    }
  for(    L=0;L<NumberOfLevels-2;++L)
    {
      HeteroGeomStats2[L].init(L+2,L,NumberOfClasses);
    }

  while(1)
    {
      mssd MSSD;
      if(0==MSSD.read(MSSDFile))
	break;
      for(L=0;L<NumberOfLevels;++L)
	{
	  HomoGeomStats[L].push(&MSSD);
	}
      for(L=0;L<NumberOfLevels-1;++L)
	{
	  HeteroGeomStats1[L].push(&MSSD);
	}
      for(L=0;L<NumberOfLevels-2;++L)
	{
	  HeteroGeomStats2[L].push(&MSSD);
	}
    }
  fclose(MSSDFile);
  for(    L=0;L<NumberOfLevels;++L)
    {
      cerr << form("Level %d\n",L);
      HomoGeomStats[L].print();
    }
  for(    L=0;L<NumberOfLevels-1;++L)
    {
      cerr << form("Level %d\n",L);
      HeteroGeomStats1[L].print();
    }
  for(    L=0;L<NumberOfLevels-2;++L)
    {
      cerr << form("Level %d\n",L);
      HeteroGeomStats2[L].print();
    }
}
