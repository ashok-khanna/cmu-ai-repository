// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stream.h>
#include "../wavelet/wavelet.h"
#include "mssd.h"
#include "geom.h"

main(int ArgCnt,char** ArgVal)
{
  if(ArgCnt<2)
    {
      cerr << "Too few Arguments!\n";
      cerr << form("Usage:\n%s [HyperGeomStatsFileName]\n",ArgVal[0]);
      exit(1);
    }

  FILE* HyperGeomStatsFile;
  if(NULL==(HyperGeomStatsFile=fopen(ArgVal[1],"r")))
    {
      cerr << "Can't open HyperGeomStatsFile!\n";
      exit(1);
    }

  hyperGeomStat* HyperGeomStatsA = new hyperGeomStat[NumberOfLevels];
  hyperGeomStat* HyperGeomStatsB = new hyperGeomStat[NumberOfLevels];
  hyperGeomStat* HyperGeomStats1 = new hyperGeomStat[NumberOfLevels-1];
  hyperGeomStat* HyperGeomStats2 = new hyperGeomStat[NumberOfLevels-2];

  for(int L=0;L<NumberOfLevels;++L)
    {
      HyperGeomStatsA[L].init(HyperGeomStatsFile);
    }
  for(int L=0;L<NumberOfLevels;++L)
    {
      HyperGeomStatsB[L].init(HyperGeomStatsFile);
    }
  for(    L=0;L<NumberOfLevels-1;++L)
    {
      HyperGeomStats1[L].init(HyperGeomStatsFile);
    }
  for(    L=0;L<NumberOfLevels-2;++L)
    {
      HyperGeomStats2[L].init(HyperGeomStatsFile);
    }
  for(    L=0;L<NumberOfLevels;++L)
    {
      HyperGeomStatsA[L].print();
    }
  for(    L=0;L<NumberOfLevels;++L)
    {
      HyperGeomStatsB[L].print();
    }
  for(    L=0;L<NumberOfLevels-1;++L)
    {
      HyperGeomStats1[L].print();
    }
  for(    L=0;L<NumberOfLevels-2;++L)
    {
      HyperGeomStats2[L].print();
    }
}
