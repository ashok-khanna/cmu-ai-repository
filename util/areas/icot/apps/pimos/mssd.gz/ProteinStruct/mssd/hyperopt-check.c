// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stream.h>
#include <math.h>
#include "../wavelet/wavelet.h"
#include "../amino/amino.h"
#include "mssd.h"
#include "prim.h"
#include "geom.h"
#include "predict.h"

double PrimaryWeight;
double LeftRightWeightA;
double LeftRightWeightB;
double Down1Weight;
double Up1Weight;
double Down2Weight;
double Up2Weight;

main(int ArgCnt,char** ArgVal)
{
  if(ArgCnt<3)
    {
      cerr << "Too few Arguments!\n";
      cerr << 
	form("Usage:\n%s [Primary Stat File] [Geometric Stat File] -[stb]\n",
	     ArgVal[0]);
      exit(1);
    }

  FILE* PrimStatFile;
  if(NULL==(PrimStatFile=fopen(ArgVal[1],"r")))
    {
      cerr << "Can't open Primary Constraints File!\n";
      exit(1);
    }
  int ProbabilityMode;
  if(ArgCnt >= 4 && ArgVal[3][0] == '-')
    {
      switch(ArgVal[3][1])
	{
	case 's':
	  ProbabilityMode = SEQUENCE;
	  break;
	case 't':
	  ProbabilityMode = STRUCTURE;
	  break;
	case 'b':
	  ProbabilityMode = BOTH2;
	  break;
	}
    }

  FILE* GeomStatFile;
  if(NULL==(GeomStatFile=fopen(ArgVal[2],"r")))
    {
      cerr << "Can't open Geom Stat File!\n";
      exit(1);
    }

  primStat* PrimStats            = new primStat[NumberOfLevels];
  hyperGeomStat* HyperGeomStatsA = new hyperGeomStat[NumberOfLevels];
  hyperGeomStat* HyperGeomStatsB = new hyperGeomStat[NumberOfLevels];
  hyperGeomStat* HyperGeomStats1 = new hyperGeomStat[NumberOfLevels-1];
  hyperGeomStat* HyperGeomStats2 = new hyperGeomStat[NumberOfLevels-2];

  int Total[NumberOfLevels];
  int Hit  [NumberOfLevels];
  int GeomPitch[NumberOfLevels];

  for(int L=0;L<NumberOfLevels;++L)
    {
      Total[L] = 0;
      Hit  [L] = 0;
      GeomPitch[L] = 1; //LevelWidth[L]/4;
      PrimStats[L].init(PrimStatFile);
      HyperGeomStatsA[L].init(GeomStatFile);
      HyperGeomStatsA[L].expand();
    }
  for(    L=0;L<NumberOfLevels;++L)
    {
      HyperGeomStatsB[L].init(GeomStatFile);
      HyperGeomStatsB[L].expand();
    }
  for(    L=0;L<NumberOfLevels-1;++L)
    {
      HyperGeomStats1[L].init(GeomStatFile);
      HyperGeomStats1[L].expand();
    }
  for(    L=0;L<NumberOfLevels-2;++L)
    {
      HyperGeomStats2[L].init(GeomStatFile);
      HyperGeomStats2[L].expand();
    }

  while(1)
    {
      mssdState MSSDState;
      if(0==MSSDState.read(stdin))
	break;
      MSSDState.initialize
	(
	 PrimStats,
	 HyperGeomStatsA,
	 HyperGeomStatsB,
	 HyperGeomStats1,
	 HyperGeomStats2,
	 OPTIMAL,
	 ProbabilityMode,
	 GeomPitch
	 );
      MSSDState.optimalCheck(1+2+4+8+16+32+64+128+256);
      MSSDState.accuracy(Total,Hit);
    }
  for(   L=0;L<NumberOfLevels;++L)
    {
      printf("Level %3d Total %5d Hit %5d  Ratio %10.5lf \n",
	     L,Total[L],Hit[L],
	     (Total[L]>0?double(Hit[L])/double(Total[L]):0));
    }
}
