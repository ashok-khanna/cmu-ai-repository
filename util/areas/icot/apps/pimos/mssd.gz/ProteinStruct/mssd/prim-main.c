// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stream.h>
#include "../wavelet/wavelet.h"
#include "mssd.h"
#include "prim.h"

main(int ArgCnt,char** ArgVal)
{
  if(ArgCnt<2)
    {
      cerr << "Too few Arguments!\n";
      cerr << form("Usage:\n%s [MSSDData]\n",ArgVal[0]);
      exit(1);
    }

  FILE* MSSDFile;
  if(NULL==(MSSDFile=fopen(ArgVal[1],"r")))
    {
      cerr << "Can't open MSSDData File!\n";
      exit(1);
    }

  primStat PrimStat  [NumberOfLevels];

  for(int L=0;L<NumberOfLevels;++L)
    {
      PrimStat[L].init(L,NumberOfClasses);
    }

  while(1)
    {
      mssd MSSD;
      if(0==MSSD.read(MSSDFile))
	break;
      for(L=0;L<NumberOfLevels;++L)
	{
	  PrimStat[L].push(&MSSD);
	}
    }

  for(    L=0;L<NumberOfLevels;++L)
    {
      PrimStat[L].print();
    }
}
