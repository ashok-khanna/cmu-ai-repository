// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <math.h>
const  int NumberOfClasses    = 24;
const  int NumberOfLevels     = 12;
const  int LevelWidth[]       =
  {5,7,9,13,17,25,33,49,65,97,129,193,257,385,513};
// LevelWidth[L] should be an odd number.
const  int MaxNumberOfCoefs   = 5;
const  int NumberOfAminoTypes = 21;

enum  probabilityMode
{
  PRECEDE,
  FOLLOW,
  BOTH,
  UNKNOWN
};


class mssd
{
 protected:
  char* PDBEntName;
  int   Length;
  int   LevelLength     [NumberOfLevels];
  int*  AminoSequence;
  int*  LevelDescription[NumberOfLevels];
  mssd* Next;
 public:
  inline mssd(void)
    {
      PDBEntName    = NULL;
      AminoSequence = NULL;
      for(int L=0;L<NumberOfLevels;++L)
	{
	  LevelLength     [L] = -1;
	  LevelDescription[L] = NULL;
	}
      Next       = NULL;
    }
  inline mssd(char* pdbEntName)
    {
      PDBEntName    = pdbEntName;
      AminoSequence = NULL;
      for(int L=0;L<NumberOfLevels;++L)
	{
	  LevelLength     [L] = -1;
	  LevelDescription[L] = NULL;
	}
      Next       = NULL;
    }
  virtual ~mssd(void);
  virtual  mssd* nextMssd(void);
  virtual  mssd* nextMssd(char*);
  virtual  void init(int Len);
  inline char* pdbEntName(void)
    {
      return PDBEntName;
    }
  inline int seqLength(void)
    {
      return Length;
    }
  inline int levelLength(int Level)
    {
      if(Level>=NumberOfLevels)
	return 0;
      else
	return LevelLength[Level];
    }
  inline int* aminoSequence(void)
    {
      return AminoSequence;
    }
  inline int aminoType(int Position)
    {
      return AminoSequence[Position];
    }
  inline int conformationClass(int Level,int Position)
    {
      return LevelDescription[Level][Position];
    }
  inline void next(mssd* N)
    {
      Next = N;
    }
  inline mssd* next(void)
    {
      return Next;
    }
  int read(FILE* MSSDFile);
  int input(char* AminoSeq,char** LevelSeqs);
  void print(void);
  void printExPrim(void);
};


