// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stream.h>
#include <math.h>
#include "../wavelet/wavelet.h"
#include "../amino/amino.h"
#include "mssd.h"
#include "prim.h"


void primStat::init(int L,int NClasses)
{
  Level = L;
  Width = LevelWidth[Level];
  NumberOfClasses = NClasses;
  NumberOfCoefs   = (Width<MaxNumberOfCoefs?Width:MaxNumberOfCoefs);
  AminoFreq = new aminoFreq[NumberOfAminoTypes];
  for(int I=0;I<NumberOfAminoTypes;++I)
    {
      AminoFreq[I].init(Width,NumberOfCoefs);
    }
  StructProf = new structProf[NumberOfClasses];
  for(    I=0;I<NumberOfClasses;++I)
    {
      StructProf[I].init(Width,NumberOfCoefs);
    }
}

void primStat::init(FILE* PrimStatFile)
{
  if(AminoFreq!=NULL)
    delete AminoFreq;
  if(StructProf!=NULL)
    delete StructProf;

  char BuffLine[2048];
  if(NULL==fgets(BuffLine,2047,PrimStatFile))
    {
      cerr << "Invalid Primary statistic data file!\n";
      exit(1);
    }
  sscanf(BuffLine+22,"%d",&NumberOfClasses);
  if(NULL==fgets(BuffLine,2047,PrimStatFile))
    {
      cerr << "Invalid Primary statistic data file!\n";
      exit(1);
    }
  sscanf(BuffLine+22,"%d",&NumberOfCoefs);
  if(NULL==fgets(BuffLine,2047,PrimStatFile))
    {
      cerr << "Invalid Primary statistic data file!\n";
      exit(1);
    }
  sscanf(BuffLine+22,"%d",&Level);
  Width = LevelWidth[Level];
  AminoFreq = new aminoFreq[NumberOfAminoTypes];
  for(int I=0;I<NumberOfAminoTypes;++I)
    {
      AminoFreq[I].init(Width,NumberOfCoefs);
    }
  StructProf = new structProf[NumberOfClasses];
  for(    I=0;I<NumberOfClasses;++I)
    {
      StructProf[I].init(Width,NumberOfCoefs);
    }
  if(NULL==fgets(BuffLine,2047,PrimStatFile))
    {
      cerr << "Invalid Primary statistic data file!\n";
      exit(1);
    }
  if(0!=strncmp("Total Frequency      :",BuffLine,22))
    {
      cerr << "Invalid Geometric statistic data file!\n";
      exit(1);
    }
  sscanf(BuffLine+22,"%d",&TotalFreq);
  if(NULL==fgets(BuffLine,2047,PrimStatFile))
    {
      cerr << "Invalid Primary statistic data file!\n";
      exit(1);
    }
  if(0!=strncmp("Total Frequency Coefs:",BuffLine,22))
    {
      cerr << "Invalid Geometric statistic data file!\n";
      exit(1);
    }
  if(NULL==fgets(BuffLine,2047,PrimStatFile))
    {
      cerr << "Invalid Primary statistic data file!\n";
      exit(1);
    }
  if(NULL==fgets(BuffLine,2047,PrimStatFile))
    {
      cerr << "Invalid Primary statistic data file!\n";
      exit(1);
    }
  int K = 0;
  for(int T=0;T<NumberOfAminoTypes;++T)
    {
      while(isspace(BuffLine[K])){K++;}
      sscanf(BuffLine+K,"%d",&TotalAminoFreq[T]);
      while(!isspace(BuffLine[K])){K++;}
    }
  for(int J=0;J<NumberOfCoefs;++J)
    {
      if(NULL==fgets(BuffLine,2047,PrimStatFile))
	{
	  cerr << "Invalid Primary statistic data file!\n";
	  exit(1);
	}
      int K=0;
      for(int I=0;I<NumberOfAminoTypes;++I)
	{
	  double AminoFreqCoef;
	  while(isspace(BuffLine[K])){K++;}
	  sscanf(BuffLine+K,"%lf",&AminoFreqCoef);
	  while(!isspace(BuffLine[K])){K++;}
	  AminoFreq[I].freqCoef(J,AminoFreqCoef);
	}
    }
  for(    T=0;T<NumberOfClasses;++T)
    {
      if(NULL==fgets(BuffLine,2047,PrimStatFile))
	{
	  cerr << "Invalid Primary statistic data file!\n";
	  exit(1);
	}
      int ClassFreq;
      sscanf(BuffLine+2,"%d",&ClassFreq);
      StructProf[T].totalFreq(ClassFreq);
      for(int J=0;J<NumberOfCoefs;++J)
	{
	  if(NULL==fgets(BuffLine,2047,PrimStatFile))
	    {
	      cerr << "Invalid Primary statistic data file!\n";
	      exit(1);
	    }
	  int K=0;
	  for(int I=0;I<NumberOfAminoTypes;++I)
	    {
	      double AminoFreqCoef;
	      while(isspace(BuffLine[K])){K++;}
	      sscanf(BuffLine+K,"%lf",&AminoFreqCoef);
	      while(!isspace(BuffLine[K])){K++;}
	      StructProf[T].freqCoef(I,J,AminoFreqCoef);
	    }
	}
    }
}

void primStat::push(mssd* MSSD)
{
  int LevelLength = MSSD->levelLength(Level);
  for(int I=0;I<LevelLength;++I)
    {
      int StructType = MSSD->conformationClass(Level,I);
      StructProf[StructType].totalFreqCnt();
      TotalFreq++;
      for(int J=0;J<Width;++J)
	{
	  int AminoType = MSSD->aminoType(I+J);
	  if(J==0 || I==LevelLength-1)
	    {
	      TotalAminoFreq[AminoType]++;
	    }
	  AminoFreq[AminoType].push(J);
	  StructProf[StructType].push(AminoType,J);
	}
    }
}

void primStat::fprint(FILE* PrimStatFile)
{
  fprintf(PrimStatFile,"Number of Classes    :%8d\n",NumberOfClasses);
  fprintf(PrimStatFile,"Number of Coeficients:%8d\n",NumberOfCoefs);
  fprintf(PrimStatFile,"Level                :%8d\n",Level);
  fprintf(PrimStatFile,"Total Frequency      :%8d\n",TotalFreq);
  fprintf(PrimStatFile,"Total Frequency Coefs:\n");
  for(int J=0;J<NumberOfAminoTypes;++J)
    {
      amino Amino(J);
      fprintf(PrimStatFile," %c  %s  ",Amino.single(),Amino.triplet());
    }
  fprintf(PrimStatFile,"\n");
  for(    J=0;J<NumberOfAminoTypes;++J)
    {
      fprintf(PrimStatFile,"%8d ",TotalAminoFreq[J]);
    }
  fprintf(PrimStatFile,"\n");
  for(int I=0;I<NumberOfCoefs;++I)
    {
      for(J=0;J<NumberOfAminoTypes;++J)
	{
	  fprintf(PrimStatFile,"%8.2lf ",AminoFreq[J].freqCoef(I));
	}
      fprintf(PrimStatFile,"\n");
    }
  for(int T=0;T<NumberOfClasses;++T)
    {
      fprintf(PrimStatFile,"%c %5d\n",T+'A',StructProf[T].totalFreq());
      for(J=0;J<NumberOfCoefs;++J)
	{
	  for(I=0;I<NumberOfAminoTypes;++I)
	    {
	      fprintf(PrimStatFile,"%8.2lf ",
		      StructProf[T].freqCoef(I,J));
	      fflush(PrimStatFile);
	    }
	  fprintf(PrimStatFile,"\n");
	}
    }
}

void primStat::probability(int* AminoSeq, double* Probabilities, int Mode)
{
  for(int T=0;T<NumberOfClasses;++T)
    {
      Probabilities[T] = 1.0;
    }
  for(int P=0;P<Width;++P)
    {
      int AminoType = AminoSeq[P];
      for(    T=0;T<NumberOfClasses;++T)
	{
	  double Freq = StructProf[T].freq(AminoType,P);
	  switch(Mode)
	    {
	    case STRUCTURE:
	      Probabilities[T] *=
		Freq/(StructProf[T].totalFreq());
	      break;
	    case SEQUENCE:
	      Probabilities[T] *= 
		Freq/(AminoFreq[AminoType].freq(P));
	    case BOTH:
	      Probabilities[T] *= 
		Freq
		  /(AminoFreq[AminoType].freq(P))
		  /(StructProf[T].totalFreq())
		  *TotalFreq;
	      break;
	    }
	}
    }
  for(   T=0;T<NumberOfClasses;++T)
    {
      Probabilities[T] = pow(Probabilities[T],1.0/double(Width));
    }
}

void primStat::probability
  (
   int     StructClass,
   int     Position,
   double* AminoProf,
   int     Mode
   )
{
  for(int AminoType=0;AminoType<NumberOfAminoTypes;++AminoType)
    {
      double Freq = StructProf[StructClass].freq(AminoType,Position);
      double Profile;
      switch(Mode)
	{
	case SEQUENCE:
	  AminoProf[AminoType] = Freq/(AminoFreq[AminoType].freq(Position));
	  break;
	case STRUCTURE:
	  AminoProf[AminoType] = Freq/(StructProf[StructClass].totalFreq());
	  break;
	case BOTH:
	  AminoProf[AminoType] = 
	    Freq/(AminoFreq[AminoType].freq(Position))
	      /(StructProf[StructClass].totalFreq())
		*TotalFreq;
	  break;
	}
    }
}

void primStat::score(int* AminoSeq, double* Scores, int Mode)
{
  for(int T=0;T<NumberOfClasses;++T)
    {
      Scores[T] = 1.0;
    }
  for(int P=0;P<Width;++P)
    {
      int AminoType = AminoSeq[P];
      for(    T=0;T<NumberOfClasses;++T)
	{
	  double Freq = StructProf[T].freq(AminoType,P);
	  if(
	     Freq
	     < 
	     (AminoFreq[AminoType].freq(P))
	     *(StructProf[T].totalFreq())
	     /double(TotalFreq)
	     /double(NumberOfClasses)/double(NumberOfAminoTypes)
	     )
	    Freq = 
	      (AminoFreq[AminoType].freq(P))
	     *(StructProf[T].totalFreq())
	     /double(TotalFreq)
	     /double(NumberOfClasses)/double(NumberOfAminoTypes);
	  switch(Mode)
	    {
	    case STRUCTURE:
	      Scores[T] *=
		Freq/(StructProf[T].totalFreq());
	      break;
	    case SEQUENCE:
	      Scores[T] *= 
		Freq/(AminoFreq[AminoType].freq(P));
	    case BOTH:
	      Scores[T] *= 
		Freq
		  /(AminoFreq[AminoType].freq(P))
		  /(StructProf[T].totalFreq())
		  *TotalFreq;
	      break;
	    }
	}
    }
  for(   T=0;T<NumberOfClasses;++T)
    {
      Scores[T] = -log(Scores[T]);
    }
}

void   primStat::printProfile(int StructClass, int Mode)
{
  for(int P=0;P<Width;++P)
    {
      double AminoProf[NumberOfAminoTypes];
      probability(StructClass,P,AminoProf,Mode);
      for(int I=0;I<NumberOfAminoTypes;++I)
	{
	  printf("%8.4lf ",AminoProf[I]);
	}
      printf("\n");
    }
}

