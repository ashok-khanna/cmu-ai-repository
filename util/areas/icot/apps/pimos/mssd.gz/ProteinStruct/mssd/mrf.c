// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stream.h>
#include <math.h>
#include "../wavelet/wavelet.h"
#include "../amino/amino.h"
#include "mssd.h"
#include "prim.h"
#include "geom.h"
#include "predict.h"

main(int ArgCnt,char** ArgVal)
{
  if(ArgCnt<3)
    {
      cerr << "Too few Arguments!\n";
      cerr << 
	form("Usage:\n%s [Primary Stat File] [Geometric Stat File]",ArgVal[0])
	  << " -[stb] -[osOSMC]\n";
      exit(1);
    }

  FILE* PrimStatFile;
  if(NULL==(PrimStatFile=fopen(ArgVal[1],"r")))
    {
      cerr << "Can't open Primary Constraints File!\n";
      exit(1);
    }
  int ProbabilityMode = BOTH2;
  if(ArgCnt >= 4 && ArgVal[3][0] == '-')
    {
      switch(ArgVal[3][1])
	{
	case 's':
	  ProbabilityMode = SEQUENCE;
	  break;
	case 't':
	  ProbabilityMode = STRUCTURE;
	  break;
	case 'b':
	  ProbabilityMode = BOTH2;
	  break;
	}
    }
  int MutationModeI= RANDOM;
  int MutationMode = STOCHASTIC;
  if(ArgCnt >= 5 && ArgVal[4][0] == '-')
    {
      switch(ArgVal[4][1])
	{
	case 'o':
	  MutationModeI = OPTIMAL;
	  MutationMode  = OPTIMAL;
	  break;
	case 's':
	  MutationModeI = STOCHASTIC;
	  MutationMode  = STOCHASTIC;
	  break;
	case 'O':
	  MutationModeI = RANDOM;
	  MutationMode  = OPTIMAL;
	  break;
	case 'S':
	  MutationModeI = RANDOM;
	  MutationMode  = STOCHASTIC;
	  break;
	case 'M':
	  MutationModeI = OPTIMAL;
	  MutationMode  = STOCHASTIC;
	  break;
	case 'C':
	  MutationModeI = COPY;
	  MutationMode  = OPTIMAL;
	  break;
	}
    }
  int ExternalIteration = 64;
  if(ArgCnt >=6)
    ExternalIteration = atoi(ArgVal[5]);
  int InternalIteration = 1024;
  if(ArgCnt >=7)
    InternalIteration = atoi(ArgVal[6]);

  primStat* PrimStats = new primStat[NumberOfLevels];
  FILE* GeomStatFile;
  if(NULL==(GeomStatFile=fopen(ArgVal[2],"r")))
    {
      cerr << "Can't open Geom Stat File!\n";
      exit(1);
    }

  geomStat* HomoGeomStats    = new geomStat[NumberOfLevels];
  geomStat* HeteroGeomStats1 = new geomStat[NumberOfLevels-1];
  geomStat* HeteroGeomStats2 = new geomStat[NumberOfLevels-2];

  int Total[NumberOfLevels];
  int Hit  [NumberOfLevels];
  int GeomPitch[NumberOfLevels];

  for(int L=0;L<NumberOfLevels;++L)
    {
      Total[L] = 0;
      Hit  [L] = 0;
      GeomPitch[L] = LevelWidth[L]/4;
      PrimStats[L].init(PrimStatFile);
      HomoGeomStats[L].init(GeomStatFile);
      HomoGeomStats[L].expand(BOTH);
    }
  for(    L=0;L<NumberOfLevels-1;++L)
    {
      HeteroGeomStats1[L].init(GeomStatFile);
      HeteroGeomStats1[L].expand(BOTH);
    }
  for(    L=0;L<NumberOfLevels-2;++L)
    {
      HeteroGeomStats2[L].init(GeomStatFile);
      HeteroGeomStats2[L].expand(BOTH);
    }

  while(1)
    {
      mssdState MSSDState;
      if(0==MSSDState.read(stdin))
	break;
      MSSDState.initialize
	(
	 PrimStats,
	 HomoGeomStats,
	 HeteroGeomStats1,
	 HeteroGeomStats2,
	 MutationModeI,
	 ProbabilityMode,
	 GeomPitch
	 );
      double OriginalScore = MSSDState.cost(ORIGINAL);
      double Score         = MSSDState.cost(PREDICTED);
	  cerr <<
	    form("Original Socre %10.5lf Score %10.5lf\n",OriginalScore,Score);
      MSSDState.changeMode(MutationMode,ProbabilityMode);
      for(int I=0;I<ExternalIteration;++I)
	{
	  int TotalNow[NumberOfLevels];
	  int HitNow  [NumberOfLevels];
	  for(int L=0;L<NumberOfLevels;++L)
	    {
	      TotalNow[L] = 0;
	      HitNow  [L] = 0;
	    }
	  MSSDState.accuracy(TotalNow,HitNow);
	  for(int J=0;J<InternalIteration;++J)
	    {
	      MSSDState.mutate(1+2+4+8+16+32+64);
	    }
	  Score = MSSDState.cost(PREDICTED);
	  cerr <<
	    form("Original Socre %10.5lf Score %10.5lf\n",OriginalScore,Score);
	  for(    L=0;L<NumberOfLevels;++L)
	    {
	      TotalNow[L] = 0;
	      HitNow  [L] = 0;
	    }
	  MSSDState.accuracy(TotalNow,HitNow);
/*
	  for(    J=0;J<InternalIteration;++J)
	    {
	      MSSDState.mutate(1+8+16);
	    }
	  Score = MSSDState.cost(PREDICTED);
	  cerr <<
	    form("Original Socre %10.5lf Score %10.5lf\n",OriginalScore,Score);
	  for(    L=0;L<NumberOfLevels;++L)
	    {
	      TotalNow[L] = 0;
	      HitNow  [L] = 0;
	    }
	  MSSDState.accuracy(TotalNow,HitNow);
	  for(    J=0;J<InternalIteration;++J)
	    {
	      MSSDState.mutate(1+2+4);
	    }
	  Score = MSSDState.cost(PREDICTED);
	  cerr <<
	    form("Original Socre %10.5lf Score %10.5lf\n",OriginalScore,Score);
	  for(    L=0;L<NumberOfLevels;++L)
	    {
	      TotalNow[L] = 0;
	      HitNow  [L] = 0;
	    }
	  MSSDState.accuracy(TotalNow,HitNow);
	  for(    J=0;J<InternalIteration;++J)
	    {
	      MSSDState.mutate(2+4+8+16+32+64);
	    }
	  Score = MSSDState.cost(PREDICTED);
	  cerr <<
	    form("Original Socre %10.5lf Score %10.5lf\n",OriginalScore,Score);
	  for(    L=0;L<NumberOfLevels;++L)
	    {
	      TotalNow[L] = 0;
	      HitNow  [L] = 0;
	    }
	  MSSDState.accuracy(TotalNow,HitNow);
*/
	}
      MSSDState.accuracy(Total,Hit);
    }
  for(   L=0;L<NumberOfLevels;++L)
    {
      printf("Level %3d Total %5d Hit %5d  Ratio %10.5lf \n",
	     L,Total[L],Hit[L],
	     (Total[L]>0?double(Hit[L])/double(Total[L]):0));
    }
}



