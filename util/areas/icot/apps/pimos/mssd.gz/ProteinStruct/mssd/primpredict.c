// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stream.h>
#include "../wavelet/wavelet.h"
#include "../amino/amino.h"
#include "mssd.h"
#include "prim.h"

main(int ArgCnt,char** ArgVal)
{
  if(ArgCnt<2)
    {
      cerr << "Too few Arguments!\n";
      cerr << 
	form("Usage:\n%s [Primary Constraints File] -[stb]\n",
	     ArgVal[0]);
      exit(1);
    }

  FILE* PrimStatFile;
  if(NULL==(PrimStatFile=fopen(ArgVal[1],"r")))
    {
      cerr << "Can't open Primary Constraints File!\n";
      exit(1);
    }
  int Mode  = BOTH;

  if(ArgCnt >= 3 && ArgVal[2][0] == '-')
    {
      switch(ArgVal[2][1])
	{
	case 's':
	  Mode = SEQUENCE;
	  break;
	case 't':
	  Mode = STRUCTURE;
	  break;
	case 'b':
	  Mode = BOTH2;
	  break;
	}
    }

  primStat PrimStat  [NumberOfLevels];

  for(int L=0;L<NumberOfLevels;++L)
    {
      PrimStat[L].init(PrimStatFile);
    }

  char BuffLine[1024];
  gets(BuffLine);
  int  SeqLen   = strlen(BuffLine);
  int* Sequence = new int[SeqLen];
  for(int I=0;I<SeqLen;++I)
    {
      amino Amino(BuffLine[I]);
      Sequence[I] = Amino.id();
    }
  for(    L=0;L<NumberOfLevels;++L)
    {
      double Probabilities[NumberOfClasses];
      if(SeqLen<LevelWidth[L])
	break;
      for(I=0;I<SeqLen-LevelWidth[L]+1;++I)
	{
	  PrimStat[L].probability(Sequence+I,Probabilities,Mode);
	  int BestClass = -1;
	  double Prob = 0.0;
	  for(int T=0;T<NumberOfClasses;++T)
	    {
	      if(Probabilities[T] > Prob)
		{
		  Prob = Probabilities[T];
		  BestClass = T;
		}
	    }
	  printf("%c",BestClass+'A');
	}
      printf("\n");
    }
}
