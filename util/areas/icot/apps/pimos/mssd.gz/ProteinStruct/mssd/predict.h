// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

extern "C"{
  double drand48(void);
};

enum mutationMode
{
  OPTIMAL,
  STOCHASTIC,
  RANDOM,
  COPY
};

enum CostMode
{
  ORIGINAL,
  PREDICTED
};

typedef double*  doubleP;
typedef double** doublePP;

extern double PrimaryWeight;
extern double LeftRightWeightA;
extern double LeftRightWeightB;
extern double Down1Weight;
extern double Up1Weight;
extern double Down2Weight;
extern double Up2Weight;

class mssdState: public mssd
{
  primStat* PrimStats;
  geomStat* HomoGeomStats;
  geomStat* HeteroGeomStats1;
  geomStat* HeteroGeomStats2;
  hyperGeomStat* HyperGeomStatsA;
  hyperGeomStat* HyperGeomStatsB;
  hyperGeomStat* HyperGeomStats1;
  hyperGeomStat* HyperGeomStats2;
  int       MutationMode;
  int       ProbabilityMode;
  int       GeomPitch           [NumberOfLevels];
  doublePP  PrimaryConstraints  [NumberOfLevels];
  int*      PredictedDescription[NumberOfLevels];
  double    PrimWeight          [NumberOfLevels];
  double    GeomWeightA         [NumberOfLevels];
  double    GeomWeightB         [NumberOfLevels];
  double    GeomWeight1         [NumberOfLevels];
  double    GeomWeight2         [NumberOfLevels];
 public:
  mssdState(void):mssd()
    {
      PrimStats        = NULL;
      HomoGeomStats    = NULL;
      HeteroGeomStats1 = NULL;
      HeteroGeomStats2 = NULL;
      HyperGeomStatsA  = NULL;
      HyperGeomStatsB  = NULL;
      HyperGeomStats1  = NULL;
      HyperGeomStats2  = NULL;
      for(int L=0;L<NumberOfLevels;++L)
	{
	  GeomPitch           [L] = 0;
	  PrimaryConstraints  [L] = NULL;
	  PredictedDescription[L] = NULL;
	  PrimWeight          [L] = 0.0;
	  GeomWeightA         [L] = 0.0;
	  GeomWeightB         [L] = 0.0;
	  GeomWeight1         [L] = 0.0;
	  GeomWeight2         [L] = 0.0;
	}
    }
  mssdState
    (
     char* SeqID,
     FILE* PrimStatFile,
     FILE* GeomStatFile,
     char* AminoSeq
     );
  mssdState
    (
     char*     SeqID,
     primStat* PS,
     geomStat* HomoGS,
     geomStat* HeteroGS1,
     geomStat* HeteroGS2,
     char*     AminoSeq
     );
  mssdState
    (
     primStat* PS,
     geomStat* HomoGS,
     geomStat* HeteroGS1,
     geomStat* HeteroGS2,
     char*     AminoSeq
     );
  mssdState
    (
     primStat* PS,
     geomStat* HomoGS,
     geomStat* HeteroGS1,
     geomStat* HeteroGS2
     );
  mssdState
    (
     char*     SeqID,
     primStat* PS,
     hyperGeomStat* HyperGSA,
     hyperGeomStat* HyperGSB,
     hyperGeomStat* HyperGS1,
     hyperGeomStat* HyperGS2,
     char*     AminoSeq
     );
  mssdState
    (
     primStat* PS,
     hyperGeomStat* HyperGSA,
     hyperGeomStat* HyperGSB,
     hyperGeomStat* HyperGS1,
     hyperGeomStat* HyperGS2,
     char*     AminoSeq
     );
  mssdState
    (
     primStat* PS,
     hyperGeomStat* HyperGSA,
     hyperGeomStat* HyperGSB,
     hyperGeomStat* HyperGS1,
     hyperGeomStat* HyperGS2
     );
  virtual ~mssdState(void);
  virtual  mssd* nextMssd(void);
  virtual  void  init(int Len);
  void     init
    (
     primStat* PS,
     geomStat* HomoGS,
     geomStat* HeteroGS1,
     geomStat* HeteroGS2,
     char*     AminoSeq
     );
  void     init
    (
     primStat* PS,
     hyperGeomStat* HyperGSA,
     hyperGeomStat* HyperGSB,
     hyperGeomStat* HyperGS1,
     hyperGeomStat* HyperGS2,
     char*     AminoSeq
     );
  void     initialize(int MutationMode,int ProbabilityMode,int* GeomPitch);
  void     initialize
    (
     primStat* PS,
     geomStat* HomoGS,
     geomStat* HeteroGS1,
     geomStat* HeteroGS2,
     int       MutationMode,
     int       ProbabilityMode,
     int*      GeomPitch
     );
  void     initialize
    (
     primStat* PS,
     hyperGeomStat* HyperGSA,
     hyperGeomStat* HyperGSB,
     hyperGeomStat* HyperGS1,
     hyperGeomStat* HyperGS2,
     int       MutationMode,
     int       ProbabilityMode,
     int*      GeomPitch
     );
  double   probLeft (int Level,int Position,int StructClass,int CostMode);
  double   probRight(int Level,int Position,int StructClass,int CostMode);
  double   probUp1  (int Level,int Position,int StructClass,int CostMode);
  double   probDown1(int Level,int Position,int StructClass,int CostMode);
  double   probUp2  (int Level,int Position,int StructClass,int CostMode);
  double   probDown2(int Level,int Position,int StructClass,int CostMode);
  void     probability
    (
     int     Level,
     int     Position,
     double* Probability,
     int     CostMode,
     int     ConstraintMode
     );
  double   mutate(int ConstraintMode);
  double   mutate(int Level,int ConstraintMode);
  double   mutate(int Level,int Position,int ConstraintMode);
  void     optimalCheck(int ConstraintMode);
  void     accuracy(int* Total,int* Hit);
  double   cost(int CostMode);
  inline   changeMode(int MM,int PM)
    {
      MutationMode    = MM;
      ProbabilityMode = PM;
    }
  double   hyperProbLeftRightA
    (
     int Level,
     int Position,
     int StructClass,
     int CostMode
     );
  double   hyperProbLeftRightB
    (
     int Level,
     int Position,
     int StructClass,
     int CostMode
     );
  double   hyperProbLeftDown1
    (
     int Level,
     int Position,
     int StructClass,
     int CostMode
     );
  double   hyperProbRightDown1
    (
     int Level,
     int Position,
     int StructClass,
     int CostMode
     );
  double   hyperProbLeftDown2
    (
     int Level,
     int Position,
     int StructClass,
     int CostMode
     );
  double   hyperProbRightDown2
    (
     int Level,
     int Position,
     int StructClass,
     int CostMode
     );
  double   hyperProbUp1
    (
     int Level,
     int Position,
     int StructClass,
     int CostMode
     );
  double   hyperProbUp2
    (
     int Level,
     int Position,
     int StructClass,
     int CostMode
     );
  void     hyperProbability
    (
     int     Level,
     int     Position,
     double* Probability,
     int     CostMode,
     int     ConstraintMode
     );
  double   hyperMutate(int ConstraintMode);
  double   hyperMutate(int Level,int ConstraintMode);
  double   hyperMutate(int Level,int Position,int ConstraintMode);
  void     hyperOptimalCheck(int ConstraintMode);
  double   hyperCost(int CostMode);
};


int optimalSelect   (int NumberOfItems,double* Probabilities);
int stochasticSelect(int NumberOfItems,double* Probabilities);
int randomSelect    (int NumberOfItems);

inline int select
  (
   int     NumberOfItems,
   double* Probabilities,
   int     Mode
   )
{
  switch(Mode)
    {
    case OPTIMAL:
      return optimalSelect   (NumberOfItems, Probabilities);
    case STOCHASTIC:
      return stochasticSelect(NumberOfItems, Probabilities);
    case RANDOM:
      return randomSelect    (NumberOfItems);
    }
}
