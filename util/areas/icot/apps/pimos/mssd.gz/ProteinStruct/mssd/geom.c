// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stream.h>
#include <math.h>
#include "../wavelet/wavelet.h"
#include "mssd.h"
#include "geom.h"

void geomStat::init(FILE* GeomStatFile)
{
  if(PrecedeClassFreq  != NULL)
    delete PrecedeClassFreq;
  if(FollowClassFreq   != NULL)
    delete FollowClassFreq;
  if(Coeficients       != NULL)
    delete Coeficients;
  if(CoefFreq          != NULL)
    delete CoefFreq;

  char BuffLine[2048];
  if(NULL==fgets(BuffLine,2047,GeomStatFile))
    {
      cerr << "Invalid Geometric statistic data file!\n";
      exit(1);
    }
  sscanf(BuffLine+22,"%d",&NumberOfClasses);
  if(NULL==fgets(BuffLine,2047,GeomStatFile))
    {
      cerr << "Invalid Geometric statistic data file!\n";
      exit(1);
    }
  sscanf(BuffLine+22,"%d",&NumberOfCoefs);
  if(NULL==fgets(BuffLine,2047,GeomStatFile))
    {
      cerr << "Invalid Geometric statistic data file!\n";
      exit(1);
    }
  sscanf(BuffLine+22,"%d",&PrecedeLevel);
  if(NULL==fgets(BuffLine,2047,GeomStatFile))
    {
      cerr << "Invalid Geometric statistic data file!\n";
      exit(1);
    }
  sscanf(BuffLine+22,"%d",&FollowLevel);
  if(NULL==fgets(BuffLine,2047,GeomStatFile))
    {
      cerr << "Invalid Geometric statistic data file!\n";
      exit(1);
    }
  if(0!=strncmp("Frequency Coeffs     :",BuffLine,22))
    {
      cerr << "Invalid Geometric statistic data file!\n";
      exit(1);
    }
  CoefFreq = new double[NumberOfCoefs];
  for(int I=0;I<NumberOfCoefs;++I)
    {
      if(NULL==fgets(BuffLine,2047,GeomStatFile))
	{
	  cerr << "Invalid Geometric statistic data file!\n";
	  exit(1);
	}
      sscanf(BuffLine,"%lf",&CoefFreq[I]);
    }
  if(NULL==fgets(BuffLine,2047,GeomStatFile))
    {
      cerr << "Invalid Geometric statistic data file!\n";
      exit(1);
    }
  PrecedeClassFreq = new int[NumberOfClasses];
  FollowClassFreq  = new int[NumberOfClasses];

  int FieldStart[NumberOfClasses];
  int J=0;
  for(    I=0;I<NumberOfClasses;++I)
    {
      while(BuffLine[J]!=I+'A'){J++;}
      FieldStart[I] = J;
      sscanf(BuffLine+J+1,"%d",&FollowClassFreq[I]);
    }


  Coeficients   = new double[NumberOfClasses*NumberOfClasses*NumberOfCoefs];

  for(int PC=0;PC<NumberOfClasses;++PC)
    {
      if(NULL==fgets(BuffLine,2047,GeomStatFile))
	{
	  cerr << "Invalid Geometric statistic data file!\n";
	  exit(1);
	}
      sscanf(BuffLine+1,"%d",&PrecedeClassFreq[PC]);
      for(int Order=0;Order<NumberOfCoefs;++Order)
	{
	  if(NULL==fgets(BuffLine,2047,GeomStatFile))
	    {
	      cerr << "Invalid Geometric statistic data file!\n";
	      exit(1);
	    }
	  for(int FC=0;FC<NumberOfClasses;++FC)
	    {
	      sscanf(BuffLine+FieldStart[FC],"%lf",
		     &Coeficients
		     [
		      PC*NumberOfClasses*NumberOfCoefs
		      +FC*NumberOfCoefs
		      +Order
		      ]);
	    }
	}
    }
  if(PrecedeLevel == FollowLevel)
    {
      MaxOffset = LevelWidth[PrecedeLevel];
    }
  else
    {
      MaxOffset = LevelWidth[PrecedeLevel] - LevelWidth[FollowLevel]+1;
    }
  TotalFreq        = 0;
  for(    I=0;I<NumberOfClasses;++I)
    {
      TotalFreq+=PrecedeClassFreq[I];
    }
  Wavelets = waveletDB(NumberOfCoefs,MaxOffset);
}
  

void geomStat::init(int PL,int FL,int NClass)
{
  if(Wavelets          != NULL)
    delete Wavelets;
  if(PrecedeClassFreq  != NULL)
    delete PrecedeClassFreq;
  if(FollowClassFreq   != NULL)
    delete FollowClassFreq;
  if(Coeficients       != NULL)
    delete Coeficients;
  if(CoefFreq          != NULL)
    delete CoefFreq;

  if(PL < FL)
    {
      cerr << "Invalid combination of levels!\n";
      exit(1);
    }
  if(PL < NumberOfLevels)
    PrecedeLevel  = PL;
  else
    {
      cerr << "Invalid Level\n";
      exit(1);
    }
  if(FL < NumberOfLevels)
    FollowLevel   = FL;
  else
    {
      cerr << "Invalid Level\n";
      exit(1);
    }
  NumberOfClasses = NClass;

  if(PrecedeLevel == FollowLevel)
    {
      MaxOffset = LevelWidth[PrecedeLevel];
    }
  else
    {
      MaxOffset = LevelWidth[PrecedeLevel] - LevelWidth[FollowLevel]+1;
    }
  NumberOfCoefs   = (MaxOffset<MaxNumberOfCoefs?MaxOffset:MaxNumberOfCoefs);
  Coeficients     = new double[NumberOfClasses*NumberOfClasses*NumberOfCoefs];
  for(int I=0;I<NumberOfClasses;++I)
    for(int J=0;J<NumberOfClasses;++J)
      for(int K=0;K<NumberOfCoefs;++K)
	Coeficients[I*NumberOfClasses*NumberOfCoefs+J*NumberOfCoefs+K]=0.0;

  PrecedeClassFreq = new int [NumberOfClasses];
  FollowClassFreq  = new int [NumberOfClasses];
  for(    I=0;I<NumberOfClasses;++I)
    {
      PrecedeClassFreq[I] = 0;
      FollowClassFreq [I] = 0;
    }
  CoefFreq         = new double[NumberOfCoefs];
  for(    I=0;I<NumberOfCoefs;++I)
    {
      CoefFreq[I] = 0.0;
    }
  Wavelets = new wavelet(NumberOfCoefs,MaxOffset);
}


void geomStat::fprint(FILE* GeomStatFile)
{
  fprintf(GeomStatFile,"Number of Classes    :%3d\n",NumberOfClasses);
  fprintf(GeomStatFile,"Number of Coeficients:%3d\n",NumberOfCoefs);
  fprintf(GeomStatFile,"Preceding Level      :%3d\n",PrecedeLevel);
  fprintf(GeomStatFile,"Following Level      :%3d\n",FollowLevel);
  fprintf(GeomStatFile,"Frequency Coeffs     :\n");
  for(int I=0;I<NumberOfCoefs;++I)
    fprintf(GeomStatFile,"%10.5lf\n",CoefFreq[I]);

  for(    I=0;I<NumberOfClasses;++I)
    fprintf(GeomStatFile,"%c %5d ",I+'A',FollowClassFreq[I]);
  fprintf(GeomStatFile,"\n");
  for(int PC=0;PC<NumberOfClasses;++PC)
    {
      fprintf(GeomStatFile,"%c %5d\n",PC+'A',PrecedeClassFreq[PC]);
      for(int Order=0;Order<NumberOfCoefs;++Order)
	{
	  for(int FC=0;FC<NumberOfClasses;++FC)
	    {
	      fprintf(GeomStatFile,"%7.2lf ",
		      Coeficients
		      [
		       PC*NumberOfClasses*NumberOfCoefs
		       +FC*NumberOfCoefs
		       +Order
		       ]
		      );
	    }
	  fprintf(GeomStatFile,"\n");
	}
    }
  fflush(GeomStatFile);
}

void geomStat::printKL1(void)
{
  printf("geometric_constraint(%d,%d,",PrecedeLevel,FollowLevel);
  printf("PrecedeFreq,FollowFreq,GeometricConstraint) :- true|\n");
  printf("    PrecedeFreq = {");
  for(int I=0;I<NumberOfClasses-1;++I)
    {
      if(I%5==0)
	printf("\n        ");
      printf("%8d,",PrecedeClassFreq[I]);
    }
  printf("%8d\n    },\n",PrecedeClassFreq[NumberOfClasses-1]);

  printf("    FollowFreq = {");
  for(    I=0;I<NumberOfClasses-1;++I)
    {
      if(I%5==0)
	printf("\n        ");
      printf("%8d,",FollowClassFreq[I]);
    }
  printf("%8d\n    },\n",FollowClassFreq[NumberOfClasses-1]);

  printf("    GeometricConstraint = {\n");
  for(int PC=0;PC<NumberOfClasses;++PC)
    {
      printf("        {\n");
      for(int FC=0;FC<NumberOfClasses;++FC)
	{
	  printf("            {");
	  for(int Order=0;Order<NumberOfCoefs;++Order)
	    {
	      printf("%10.2lf",
		      Coeficients
		      [
		       PC*NumberOfClasses*NumberOfCoefs
		       +FC*NumberOfCoefs
		       +Order
		       ]
		      );
	      if(Order != NumberOfCoefs-1)
		printf(",");
	    }
	  if(FC==NumberOfClasses-1)
	    printf("}\n");
	  else
	    printf("},\n");
	}
      if(PC==NumberOfClasses-1)
	printf("        }\n");
      else
	printf("        },\n");
    }
  printf("    }.\n");
}


double geomStat::probability(int PC,int FC,int Offset,probabilityMode Mode)
{
  double P=0.0;
  double FreqAtOffset = 0.0;
  for(int  Order=0;Order<NumberOfCoefs;++Order)
    {
      P+=
	Coeficients
	  [
	   PC*NumberOfClasses*NumberOfCoefs
	   +FC*NumberOfCoefs
	   +Order
	   ]*Wavelets->position(Order,Offset);
      FreqAtOffset+= CoefFreq[Order]*Wavelets->position(Order,Offset);
    }
  double Freq;
  Freq = (P>exp(-256)? P: exp(-256));
  switch(Mode)
    {
    case PRECEDE:
      Freq /= double(PrecedeClassFreq[PC]);
      break;
    case FOLLOW:
      Freq /= double(FollowClassFreq[FC]);
      break;
    case BOTH:
      Freq /= double(PrecedeClassFreq[PC])
	     *double(FollowClassFreq [FC])
	     /FreqAtOffset;
      break;
    default:
      break;
    }
  return Freq;
}

void geomStat::print(int PLC,int FLC,probabilityMode Mode)
{ 
  cerr<<form("Preceding Class:\t %c%d\n",PLC+'A',LevelWidth[PrecedeLevel]);
  cerr<<form("Following Class:\t %c%d\n",FLC+'A',LevelWidth[ FollowLevel]);
  cerr<<form("Frequency of Preceding Class is %d\n",PrecedeClassFreq[PLC]);
  cerr<<form("Frequency of Following Class is %d\n",FollowClassFreq [FLC]);
  for(int Offset=0;Offset<MaxOffset;++Offset)
    {
      printf("%10.5lf\n",probability(PLC,FLC,Offset,Mode));
    }
}

void geomStat::print(probabilityMode Mode)
{
  printf("Preceding Level %3d\n",PrecedeLevel);
  printf("Following Level %3d\nOffset", FollowLevel);
  for(int C=0;C<NumberOfClasses;++C)
    {
      printf("         %c ",C+'A');
    }
  printf("\n");
  for(int PLC=0;PLC<NumberOfClasses;++PLC)
    {
      printf("Preceding Class %c\n",PLC+'A');
      for(int Offset=0;Offset<MaxOffset;++Offset)
	{
	  printf(" %4d ",Offset);
	  for(int FLC=0;FLC<NumberOfClasses;++FLC)
	    {
	      printf("%10.5lf ",probability(PLC,FLC,Offset,Mode));
	    }
	  printf("\n");
	}
    }
}


void geomStat::push(mssd* MSSD)
{
  int PrecedeLevelLength = MSSD->levelLength(PrecedeLevel);
  int FollowLevelLength  = MSSD->levelLength( FollowLevel);
  for(int I=0;I<PrecedeLevelLength;++I)
    {
      int PrecedeClass = MSSD->conformationClass(PrecedeLevel,I);
      PrecedeClassFreq[PrecedeClass]++;
      for(int Offset=0;Offset<MaxOffset && I+Offset<FollowLevelLength;++Offset)
	{
	  int FollowClass = MSSD->conformationClass(FollowLevel,I+Offset);
	  if(I==0)
	    {
	      FollowClassFreq[FollowClass]++;
	    }
	  else if(Offset == MaxOffset-1)
	    {
	      FollowClassFreq[FollowClass]++;
	    }
	  for(int Order=0;Order<NumberOfCoefs;++Order)
	    {
	      Coeficients
		[
		 PrecedeClass*NumberOfClasses*NumberOfCoefs
		 +FollowClass*NumberOfCoefs
		 +Order
		 ] += Wavelets->position(Order,Offset);

	      CoefFreq[Order]+= Wavelets->position(Order,Offset);
	    }
	}
    }
  if(MSSD->next()!= NULL)
    push(MSSD->next());
}


void geomStat::expand(probabilityMode Mode)
{
  for(int PC=0;PC<NumberOfClasses;++PC)
    {
      for(int FC=0;FC<NumberOfClasses;++FC)
	{
	  Expansion[PC][FC] = new double[MaxOffset];
	  for(int Offset = 0;Offset<MaxOffset;++Offset)
	    {
	      Expansion[PC][FC][Offset] =
		probability(PC,FC,Offset,Mode);
	    }
	}
    }
}

