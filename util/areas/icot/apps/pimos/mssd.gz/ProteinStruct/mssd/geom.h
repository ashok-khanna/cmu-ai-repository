// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

class geomStat
{
  int      PrecedeLevel;
  int      FollowLevel;
  int      NumberOfClasses;
  int      NumberOfCoefs;
  int      MaxOffset;
  wavelet* Wavelets;
  int*     PrecedeClassFreq;
  int*     FollowClassFreq;
  int      TotalFreq;
  double*  CoefFreq;
  double*  Coeficients;
  double*  Expansion[NumberOfClasses][NumberOfClasses];
 public:
  inline geomStat(void)
    {
      PrecedeLevel     = 0;
      FollowLevel      = 0;
      NumberOfClasses  = 0;
      NumberOfCoefs    = 0;
      MaxOffset        = 0;
      Wavelets         = NULL;
      PrecedeClassFreq = NULL;
      FollowClassFreq  = NULL;
      TotalFreq        = 0;
      CoefFreq         = NULL;
      Coeficients      = NULL;
      for(int PC=0;PC<NumberOfClasses;++PC)
	for(int FC=0;FC<NumberOfClasses;++FC)
	  Expansion[PC][FC] = NULL;
    }
  inline geomStat(int PL,int FL,int NClass)
    {
      PrecedeLevel     = 0;
      FollowLevel      = 0;
      NumberOfClasses  = 0;
      NumberOfCoefs    = 0;
      MaxOffset        = 0;
      Wavelets         = NULL;
      PrecedeClassFreq = NULL;
      FollowClassFreq  = NULL;
      TotalFreq        = 0;
      CoefFreq         = NULL;
      Coeficients      = NULL;
      init(PL,FL,NClass);
      for(int PC=0;PC<NumberOfClasses;++PC)
	for(int FC=0;FC<NumberOfClasses;++FC)
	  Expansion[PC][FC] = NULL;
    }
  inline geomStat(FILE* GeomStatFile)
    {
      PrecedeLevel     = 0;
      FollowLevel      = 0;
      NumberOfClasses  = 0;
      NumberOfCoefs    = 0;
      MaxOffset        = 0;
      Wavelets         = NULL;
      PrecedeClassFreq = NULL;
      FollowClassFreq  = NULL;
      TotalFreq        = 0;
      CoefFreq         = NULL;
      Coeficients      = NULL;
      init(GeomStatFile);
      for(int PC=0;PC<NumberOfClasses;++PC)
	for(int FC=0;FC<NumberOfClasses;++FC)
	  Expansion[PC][FC] = NULL;
    }      
  inline ~geomStat(void)
    {
      delete PrecedeClassFreq;
      delete FollowClassFreq;
      delete CoefFreq;
      delete Coeficients;
      for(int PC=0;PC<NumberOfClasses;++PC)
	{
	  for(int FC=0;FC<NumberOfClasses;++FC)
	    {
	      if(Expansion[PC][FC]!=NULL)
		delete Expansion[PC][FC];
	    }
	}
    }
  void init(int PL,int FL,int NClass);
  void init(FILE* GeomStatFile);
  inline double& operator()(int I,int J,int K)
    {
      return Coeficients[I*NumberOfClasses*NumberOfCoefs+J*NumberOfCoefs+K];
    }
  inline void coef(double* Coef, int I,int J)
    {
      for(int K=0;K<NumberOfCoefs;++K)
	{
	  Coef[K] =
	    Coeficients[I*NumberOfClasses*NumberOfCoefs+J*NumberOfCoefs+K];
	}
    }
  inline int totalFreq(void)
    {
      return TotalFreq;
    }
  inline int precedeClassFreq(int Class)
    {
      return PrecedeClassFreq[Class];
    }
  inline int followClassFreq(int Class)
    {
      return FollowClassFreq[Class];
    }
  void push(mssd* MSSD);
  inline void calc(void)
    {
      TotalFreq        = 0;
      for(int I=0;I<NumberOfClasses;++I)
	{
	  TotalFreq+=PrecedeClassFreq[I]+FollowClassFreq[I];
	}
      TotalFreq /= 2;
    }
  void expand(probabilityMode Mode);
  double probability(int PC,int FC,int Offset,probabilityMode Mode);
  inline double probability(int PC,int FC,int Offset)
    {
      return Expansion[PC][FC][Offset];
    }
  inline void print(void)
    {
      fprint(stdout);
    }
  void fprint(FILE* GeomStatFile);
  void printKL1(void);
  void print(int PLC,int FLC,probabilityMode Mode);
  void print(probabilityMode Mode);
};

class hyperStructSet
{
  int Level;
  int Offset;
  int StructFreqs[NumberOfClasses];
 public:
  inline hyperStructSet(void)
    {
      init();
    }
  inline hyperStructClass(int L,int O)
    {
      init(L,O);
    }
  inline void init(void)
    {
      Level  = 0;
      Offset = 0;
      for(int Class=0;Class<NumberOfClasses;++Class)
	StructFreqs[Class] = 0;
    }
  inline void init(int L,int O)
    {
      Level  = L;
      Offset = O;
      for(int Class=0;Class<NumberOfClasses;++Class)
	StructFreqs[Class] = 0;
    }
  inline int level(void)
    {
      return Level;
    }
  inline void offset(int O)
    {
      Offset = O;
    }
  inline int offset(void)
    {
      return Offset;
    }
  inline void structFreq(int Class,int F)
    {
      StructFreqs[Class] = F;
    }
  inline void structFreq(int* SFs)
    {
      for(int Class=0;Class<NumberOfClasses;++Class)
	StructFreqs[Class] = SFs[Class];
    }
  inline int structFreq(int Class)
    {
      return StructFreqs[Class];
    }
  inline void structFreqCnt(int Class)
    {
      StructFreqs[Class]++;
    }
};

class hyperGeomStat
{
  hyperStructSet StructSetI;
  hyperStructSet StructSetJ;
  hyperStructSet StructSetK;
  int    Coocurrence[NumberOfClasses][NumberOfClasses][NumberOfClasses];
  double Constraint [NumberOfClasses][NumberOfClasses][NumberOfClasses];
  double GeomWeight;
  int TotalFreq;
 public:
  inline hyperGeomStat(void)
    {
      StructSetI.init();
      StructSetJ.init();
      StructSetK.init();
      for(int Ci=0;Ci<NumberOfClasses;++Ci)
	for(int Cj=0;Cj<NumberOfClasses;++Cj)
	  for(int Ck=0;Ck<NumberOfClasses;++Ck)
	    Coocurrence[Ci][Cj][Ck] = 0;
      GeomWeight = 0.0;
    }
  inline hyperGeomStat(int Li,int Lj,int Lk,int Oi,int Oj,int Ok)
    {
      GeomWeight = 0.0;
      init(Li,Lj,Lk,Oi,Oj,Ok);
    }
  inline double weight(void)
    {
      return GeomWeight;
    }
  inline void init(int Li,int Lj,int Lk,int Oi,int Oj,int Ok)
    {
      GeomWeight = 0.0;
      StructSetI.init(Li,Oi);
      StructSetJ.init(Lj,Oj);
      StructSetK.init(Lk,Ok);
      for(int Ci=0;Ci<NumberOfClasses;++Ci)
	for(int Cj=0;Cj<NumberOfClasses;++Cj)
	  for(int Ck=0;Ck<NumberOfClasses;++Ck)
	    Coocurrence[Ci][Cj][Ck] = 0;
    }
  void init(FILE* HyperGeomStatFile);
  void push(mssd* MSSD);
  inline void print(void)
    {
      fprint(stdout);
    }
  void fprint(FILE* HyperGeomStatFile);
  void aneal(void);
  void expand(void);
  inline double probability(int Ci,int Cj,int Ck)
    {
      return Constraint[Ci][Cj][Ck];
    }
  inline int levelI(void)
    {
      return StructSetI.level();
    }
  inline int levelJ(void)
    {
      return StructSetJ.level();
    }
  inline int levelK(void)
    {
      return StructSetK.level();
    }
  inline int offsetI(void)
    {
      return StructSetI.offset();
    }
  inline int offsetJ(void)
    {
      return StructSetJ.offset();
    }
  inline int offsetK(void)
    {
      return StructSetK.offset();
    }
};




