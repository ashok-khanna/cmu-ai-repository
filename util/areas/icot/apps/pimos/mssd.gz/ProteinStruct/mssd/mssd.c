// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stream.h>
#include <math.h>
#include "../wavelet/wavelet.h"
#include "../amino/amino.h"
#include "mssd.h"

mssd:: ~mssd(void)
{
  if(PDBEntName!=NULL)
    delete PDBEntName;
  if(AminoSequence!=NULL)
    delete AminoSequence;
  for(int L=0;L<NumberOfLevels;++L)
    {
      if(NULL!=LevelDescription[L])
	delete LevelDescription[L];
    }
  if(Next!=NULL)
    delete Next;
}

mssd* mssd::nextMssd(void)
{
  return new mssd;
}

mssd* mssd::nextMssd(char* pdbEntName)
{
  return new mssd(pdbEntName);
}

void  mssd::init(int Len)
{
  Length   = Len;
  AminoSequence = new int[Length];
  for(int L=0;L<NumberOfLevels;++L)
    {
      LevelLength[L]      = (
			     Length-LevelWidth[L]+1>0?
			     Length-LevelWidth[L]+1:
			     0
			     );
      LevelDescription[L] = new int[LevelLength[L]];
    }
}

int mssd::read(FILE* MSSDFile)
{
  char BuffLine[2048];
  if(NULL==fgets(BuffLine,2047,MSSDFile))
    {
      return 0;
    }
  PDBEntName = new char[strlen(BuffLine)+1];
  strcpy(PDBEntName,BuffLine);
  PDBEntName[strlen(BuffLine)-1] = '\0';
  cerr << PDBEntName << '\n';
  if(NULL==fgets(BuffLine,2047,MSSDFile))
    {
      return 0;
    }
  char* AminoSeq = new char[strlen(BuffLine)+1];
  strcpy(AminoSeq,BuffLine);
  char* LevelSeqs[NumberOfLevels];

  for(int L=0;L<NumberOfLevels;++L)
    {
      if(NULL==fgets(BuffLine,2047,MSSDFile))
	{
	  return 0;
	}
      LevelSeqs[L] = new char[strlen(BuffLine)+1];
      strcpy(LevelSeqs[L],BuffLine);
    }
  return input(AminoSeq,LevelSeqs);
}

int mssd::input(char* AminoSeq,char** LevelSeqs)
{
  AminoSeq++;
  for(int L=0;L<NumberOfLevels;++L)
    {
      LevelSeqs[L]++;
    }

  int SeqLength=0;
  while(*(AminoSeq+SeqLength)!='>')
    {
      SeqLength++;
    }
  init(SeqLength);
  int P = 0;
  while(*AminoSeq!='>')
    {
      amino Amino(*(AminoSeq++));
      AminoSequence[P++] = Amino.id();
    }

  for(    L=0;L<NumberOfLevels;++L)
    {
      int P = 0;
      while(*(LevelSeqs[L])!='>')
	{
	  LevelDescription[L][P++] = 
	    (*(LevelSeqs[L])-'A');
	  LevelSeqs[L]++;
	}
      if(P!=(0<SeqLength-LevelWidth[L]+1?SeqLength-LevelWidth[L]+1:0))
	{
	  cerr << "Invalid MSSD File!\n";
	  exit(1);
	}
    }
  AminoSeq++;
  for(    L=0;L<NumberOfLevels;++L)
    {
      LevelSeqs[L]++;
    }
  if(*AminoSeq=='<')
    {
      Next = nextMssd(PDBEntName);
      return Next->input(AminoSeq,LevelSeqs);
    }
  else
    return 1;
}

void mssd::print(void)
{
  if(NULL!=PDBEntName)
    printf("%s\n",PDBEntName);
  else
    printf("\n");
  for(int L=0;L<NumberOfLevels;++L)
    {
      printf("%3d-residue Level: ",LevelWidth[L]);
      for(int I=0;I<LevelLength[L];++I)
	printf("%c",LevelDescription[L][I]+'A');
      printf("\n");
    }
  
  if(Next!=NULL)
    Next->print();
}

void mssd::printExPrim(void)
{
  printf("#SeqenceLength: %4d\n",Length);
  for(int L=0;L<NumberOfLevels;++L)
    {
      printf("#Begin Level %3d\n",L);
      for(int I=0;I<LevelLength[L];++I)
	{
	  for(int Class=0;Class<NumberOfClasses;++Class)
	    {
	      if(Class==LevelDescription[L][I])
		printf("%0.8f ",0.065);
	      else
		printf("%0.8f ",0.060);
	    }
	  printf("\n");
	}
      printf("#End\n");
    }
}

