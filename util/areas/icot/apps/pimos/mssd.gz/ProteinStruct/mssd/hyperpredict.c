// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stream.h>
#include <math.h>
#include "../wavelet/wavelet.h"
#include "../amino/amino.h"
#include "mssd.h"
#include "prim.h"
#include "geom.h"
#include "predict.h"

mssdState::mssdState
  (
   char*     SeqID,
   primStat* PS,
   hyperGeomStat* HyperGSA,
   hyperGeomStat* HyperGSB,
   hyperGeomStat* HyperGS1,
   hyperGeomStat* HyperGS2,
   char*     AminoSeq
   ): mssd()
{
  PrimStats        = PS;
  HyperGeomStatsA  = HyperGSA;
  HyperGeomStatsB  = HyperGSB;
  HyperGeomStats1  = HyperGS1;
  HyperGeomStats2  = HyperGS2;
  MutationMode     = RANDOM;
  ProbabilityMode  = BOTH2;
  PDBEntName       = new char[strlen(SeqID)+1];
  strcpy(PDBEntName,SeqID);
  for(int L=0;L<NumberOfLevels;++L)
    {
      GeomPitch           [L] = 0;
      PrimaryConstraints  [L] = NULL;
      PredictedDescription[L] = NULL;
      PrimWeight          [L] = 0.0;
      GeomWeightA         [L] = 0.0;
      GeomWeightB         [L] = 0.0;
      GeomWeight1         [L] = 0.0;
      GeomWeight2         [L] = 0.0;
    }
  init
    (
     PrimStats,
     HyperGeomStatsA,
     HyperGeomStatsB,
     HyperGeomStats1,
     HyperGeomStats2,
     AminoSeq
     );
}

mssdState::mssdState
  (
   primStat* PS,
   hyperGeomStat* HyperGSA,
   hyperGeomStat* HyperGSB,
   hyperGeomStat* HyperGS1,
   hyperGeomStat* HyperGS2,
   char*     AminoSeq
   ): mssd()
{
  PrimStats        = PS;
  HyperGeomStatsA  = HyperGSA;
  HyperGeomStatsB  = HyperGSB;
  HyperGeomStats1  = HyperGS1;
  HyperGeomStats2  = HyperGS2;
  MutationMode     = RANDOM;
  ProbabilityMode  = BOTH2;
  PDBEntName       = NULL;
  for(int L=0;L<NumberOfLevels;++L)
    {
      GeomPitch           [L] = 0;
      PrimaryConstraints  [L] = NULL;
      PredictedDescription[L] = NULL;
      PrimWeight          [L] = 0.0;
      GeomWeightA         [L] = 0.0;
      GeomWeightB         [L] = 0.0;
      GeomWeight1         [L] = 0.0;
      GeomWeight2         [L] = 0.0;
    }
  init
    (
     PrimStats,
     HyperGeomStatsA,
     HyperGeomStatsB,
     HyperGeomStats1,
     HyperGeomStats2,
     AminoSeq
     );
}


mssdState::mssdState
  (
   primStat* PS,
   hyperGeomStat* HyperGSA,
   hyperGeomStat* HyperGSB,
   hyperGeomStat* HyperGS1,
   hyperGeomStat* HyperGS2
   ): mssd()
{
  PrimStats        = PS;
  HyperGeomStatsA  = HyperGSA;
  HyperGeomStatsB  = HyperGSB;
  HyperGeomStats1  = HyperGS1;
  HyperGeomStats2  = HyperGS2;
  MutationMode     = RANDOM;
  ProbabilityMode  = BOTH2;
  PDBEntName       = NULL;
  for(int L=0;L<NumberOfLevels;++L)
    {
      GeomPitch           [L] = 0;
      PrimaryConstraints  [L] = NULL;
      PredictedDescription[L] = NULL;
      PrimWeight          [L] = 0.0;
      GeomWeightA         [L] = 0.0;
      GeomWeightB         [L] = 0.0;
      GeomWeight1         [L] = 0.0;
      GeomWeight2         [L] = 0.0;
    }  
}

void mssdState::init
  (
   primStat* PS,
   hyperGeomStat* HyperGSA,
   hyperGeomStat* HyperGSB,
   hyperGeomStat* HyperGS1,
   hyperGeomStat* HyperGS2,
   char*     AminoSeq
   )
{
  AminoSeq++;
  int SeqLength=0;
  int P = 0;
  while(*(AminoSeq+SeqLength)!='>')
    {
      SeqLength++;
    }
  init(SeqLength);
  while(*AminoSeq!='>')
    {
      amino Amino(*(AminoSeq++));
      AminoSequence[P++] = Amino.id();
    }
  AminoSeq++;
  if(*AminoSeq=='<')
    {
      if(Next!=NULL)
	delete Next;
      Next =
	new mssdState
	  (
	   PrimStats,
	   HyperGeomStatsA,
	   HyperGeomStatsB,
	   HyperGeomStats1,
	   HyperGeomStats2,
	   AminoSeq
	   );
    }
}

void mssdState::initialize
  (
   primStat* PS,
   hyperGeomStat* HyperGSA,
   hyperGeomStat* HyperGSB,
   hyperGeomStat* HyperGS1,
   hyperGeomStat* HyperGS2,
   int       MM,
   int       PM,
   int*      GP
   )
{
  PrimStats        = PS;
  HyperGeomStatsA  = HyperGSA;
  HyperGeomStatsB  = HyperGSB;
  HyperGeomStats1  = HyperGS1;
  HyperGeomStats2  = HyperGS2;
  MutationMode     = MM;
  ProbabilityMode  = PM;
  for(int L=0;L<NumberOfLevels;++L)
    {
      GeomPitch[L] = GP[L];
      if(LevelLength[L] == 0)
	break;
      double PMean  = 0.0;
      double PMean2 = 0.0;

      for(int I=0;I<LevelLength[L];++I)
	{
	  if(PredictedDescription[L]!=NULL)
	    delete PredictedDescription[L];
	  PredictedDescription[L] = new int[LevelLength[L]];
	  if(PrimaryConstraints[L][I]!=NULL)
	    delete PrimaryConstraints[L][I];
	  double* Scores
	    = PrimaryConstraints[L][I]
	    = new double[NumberOfClasses];
	  PrimStats[L].score(AminoSequence+I,Scores,PM);
	  for(int Class=0;Class<NumberOfClasses;++Class)
	    {
	      PMean  +=  Scores[Class];
	      PMean2 += (Scores[Class]*Scores[Class]);
	    }
	  if(MM == COPY)
	    PredictedDescription[L][I] = LevelDescription[L][I];
	  else
	    {
	      double Probabilities[NumberOfClasses];
	      for(int Class=0;Class<NumberOfClasses;++Class)
		Probabilities[Class] = exp(-Scores[Class]);
	      PredictedDescription[L][I] =
		select(NumberOfClasses,Probabilities,MM);
	    }
	}
      PMean  /= double(LevelLength[L])*double(NumberOfClasses);
      PMean2 /= double(LevelLength[L])*double(NumberOfClasses);
      PrimWeight[L] = PMean2-PMean*PMean;
//    PrimWeight[L] = (PMean<0?-PMean:PMean);
      printf("Level %3d PrimWeight %10.5lf\n",L,PrimWeight[L]);
/*
      for(    I=0;I<LevelLength[L];++I)
	{
	  for(int Class=0;Class<NumberOfClasses;++Class)
	    {
	      PrimaryConstraints[L][I][Class] =
		(PrimaryConstraints[L][I][Class]-PMean)/PrimWeight[L];
//	      PrimaryConstraints[L][I][Class]/PrimWeight[L];
	    }
	}
*/
      GeomWeightA[L] = HyperGeomStatsA[L].weight();
      GeomWeightB[L] = HyperGeomStatsB[L].weight();
      if(L<NumberOfLevels-1)
	GeomWeight1[L] = HyperGeomStats1[L].weight();
      if(L<NumberOfLevels-2)
	GeomWeight2[L] = HyperGeomStats2[L].weight();
    }
  if(Next!=NULL)
    ((mssdState*)Next)->initialize
      (PS,HyperGSA,HyperGSB,HyperGS1,HyperGS2,MM,PM,GP);
}


double   mssdState::hyperProbLeftRightA
  (
   int Level,
   int Position,
   int StructClass,
   int CostMode
   )
{
  double Geom  = 0.0;
  int**  Description = (CostMode==PREDICTED?
		        PredictedDescription:
			LevelDescription);
  int OffsetJ = HyperGeomStatsA[Level].offsetJ();
  int OffsetK = HyperGeomStatsA[Level].offsetK();
  if(
       LevelLength[Level]>0
     &&
       Position+OffsetJ<LevelLength[Level]
     &&
       Position+OffsetK<LevelLength[Level]
     &&
       Position+OffsetJ>=0
     &&
       Position+OffsetK>=0
     )
    {
      Geom += HyperGeomStatsA[Level].probability
	(
	 StructClass,
	 Description[Level][Position+OffsetJ],
	 Description[Level][Position+OffsetK]
	 );
    }
//return Geom/double(LevelLength[Level]-2);
  return Geom;
}

double   mssdState::hyperProbLeftRightB
  (
   int Level,
   int Position,
   int StructClass,
   int CostMode
   )
{
  double Geom  = 0.0;
  int**  Description = (CostMode==PREDICTED?
		        PredictedDescription:
			LevelDescription);
  int OffsetJ = HyperGeomStatsB[Level].offsetJ();
  int OffsetK = HyperGeomStatsB[Level].offsetK();
  if(
       LevelLength[Level]>0
     &&
       Position+OffsetJ<LevelLength[Level]
     &&
       Position+OffsetK<LevelLength[Level]
     &&
       Position+OffsetJ>=0
     &&
       Position+OffsetK>=0
     )
    {
      Geom += HyperGeomStatsB[Level].probability
	(
	 StructClass,
	 Description[Level][Position+OffsetJ],
	 Description[Level][Position+OffsetK]
	 );
    }
//return Geom/double(LevelLength[Level]-OffsetK*2);
  return Geom;
}

double   mssdState::hyperProbLeftDown1
  (
   int Level,
   int Position,
   int StructClass,
   int CostMode
   )
{
  double Geom  = 0.0;
  if(Level>=NumberOfLevels-1)
    return Geom;
  int**  Description = (CostMode==PREDICTED?
		        PredictedDescription:
			LevelDescription);
  int OffsetK = HyperGeomStats1[Level].offsetK();
  if(
       LevelLength[Level+1]>0
     &&
       Position-OffsetK>=0
     )
    {
      Geom += HyperGeomStats1[Level].probability
	(
	 Description[Level+1][Position-OffsetK],
	 Description[Level]  [Position-OffsetK],
	 StructClass
	 );
    }
  else
    {
      return 0.0;
    }
//return Geom/double(LevelLength[Level+1]);
  return Geom;
}
double   mssdState::hyperProbRightDown1
  (
   int Level,
   int Position,
   int StructClass,
   int CostMode
   )
{
  double Geom  = 0.0;
  if(Level>=NumberOfLevels-1)
    return Geom;
  int**  Description = (CostMode==PREDICTED?
		        PredictedDescription:
			LevelDescription);
  int OffsetK = HyperGeomStats1[Level].offsetK();
  if(
       LevelLength[Level+1]>0
     &&
       Position+OffsetK<LevelLength[Level]
     &&
       Position<LevelLength[Level+1]
     )
    {
      Geom += HyperGeomStats1[Level].probability
	(
	 Description[Level+1][Position],
	 StructClass,
	 Description[Level][Position+OffsetK]
	 );
    }
  else
    {
      return 0.0;
    }
//return Geom/double(LevelLength[Level+1]);
  return Geom;
}
double   mssdState::hyperProbLeftDown2
  (
   int Level,
   int Position,
   int StructClass,
   int CostMode
   )
{
  double Geom  = 0.0;
  if(Level>=NumberOfLevels-2)
    return Geom;
  int**  Description = (CostMode==PREDICTED?
		        PredictedDescription:
			LevelDescription);
  int OffsetK = HyperGeomStats2[Level].offsetK();
  if(
       LevelLength[Level+2]>0
     &&
       Position-OffsetK>=0
     )
    {
      Geom += HyperGeomStats2[Level].probability
	(
	 Description[Level+2][Position-OffsetK],
	 Description[Level][Position-OffsetK],
	 StructClass
	 );
    }
  else
    {
      return 0.0;
    }
//return Geom/double(LevelLength[Level+2]);
  return Geom;
}
double   mssdState::hyperProbRightDown2
  (
   int Level,
   int Position,
   int StructClass,
   int CostMode
   )
{
  double Geom  = 0.0;
  if(Level>=NumberOfLevels-2)
    return Geom;
  int**  Description = (CostMode==PREDICTED?
		        PredictedDescription:
			LevelDescription);
  int OffsetK = HyperGeomStats2[Level].offsetK();
  if(
       LevelLength[Level+2]>0
     &&
       Position+OffsetK<LevelLength[Level]
     &&
       Position<LevelLength[Level+2]
     )
    {
      Geom += HyperGeomStats2[Level].probability
	(
	 Description[Level+2][Position],
	 StructClass,
	 Description[Level][Position+OffsetK]
	 );
    }
  else
    {
      return 0.0;
    }
//return Geom/double(LevelLength[Level+2]);
  return Geom;
}

double   mssdState::hyperProbUp1
  (
   int Level,
   int Position,
   int StructClass,
   int CostMode
   )
{
  double Geom  = 0.0;
  if(Level<1)
    return Geom;
  int**  Description = (CostMode==PREDICTED?
		        PredictedDescription:
			LevelDescription);
  int OffsetK = HyperGeomStats1[Level-1].offsetK();
  if(
       LevelLength[Level]>0
     &&
       Position+OffsetK<LevelLength[Level-1]
     )
    {
      Geom += HyperGeomStats1[Level-1].probability
	(
	 StructClass,
	 Description[Level-1][Position],
	 Description[Level-1][Position+OffsetK]
	 );
    }
  else
    {
      return 0.0;
    }
//return Geom/double(LevelLength[Level]);
  return Geom;
}
double   mssdState::hyperProbUp2
  (
   int Level,
   int Position,
   int StructClass,
   int CostMode
   )
{
  double Geom  = 0.0;
  if(Level<2)
    return Geom;
  int**  Description = (CostMode==PREDICTED?
		        PredictedDescription:
			LevelDescription);
  int OffsetK = HyperGeomStats1[Level-2].offsetK();
  if(
       LevelLength[Level]>0
     &&
       Position+OffsetK<LevelLength[Level-2]
     )
    {
      Geom += HyperGeomStats1[Level-2].probability
	(
	 StructClass,
	 Description[Level-2][Position],
	 Description[Level-2][Position+OffsetK]
	 );
    }
  else
    {
      return 0.0;
    }
//return Geom/double(LevelLength[Level]);
  return Geom;
}

void    mssdState::hyperProbability
  (
   int     Level,
   int     Position,
   double* Probability,
   int     CostMode,
   int     ConstraintMode
   )
{
  if(Position< 0 || Position>=LevelLength[Level])
    {
      cerr << "Invalid Position! at mutation!\n";
      exit(1);
    }
  for(int C=0;C<NumberOfClasses;++C)
    {
      double Constraint = 0.0;

      if(ConstraintMode&1)
	Constraint += PrimaryConstraints[Level][Position][C]
	  *PrimaryWeight;
      if(ConstraintMode&2)
	Constraint += hyperProbLeftRightA(Level,Position,C,CostMode)
	  *LeftRightWeightA;
      if(ConstraintMode&4)
	Constraint += hyperProbLeftRightB(Level,Position,C,CostMode)
	  *LeftRightWeightB;
      if(Level<NumberOfLevels-1)
	{
	  if(ConstraintMode&8)
	    Constraint += hyperProbLeftDown1 (Level,Position,C,CostMode)
	      *Down1Weight;
	  if(ConstraintMode&16)
	    Constraint += hyperProbRightDown1(Level,Position,C,CostMode)
	      *Down1Weight;
	}
      if(Level<NumberOfLevels-2)
	{
	  if(ConstraintMode&32)
	    Constraint += hyperProbLeftDown2 (Level,Position,C,CostMode)
	      *Down2Weight;
	  if(ConstraintMode&64)
	    Constraint += hyperProbRightDown2(Level,Position,C,CostMode)
	      *Down2Weight;
	}
      if(Level>0)
	{
	  if(ConstraintMode&128)
	    Constraint += hyperProbUp1       (Level,Position,C,CostMode)
	      *Up1Weight;
	}
      if(Level>1)
	{
	  if(ConstraintMode&256)
	    Constraint += hyperProbUp2       (Level,Position,C,CostMode)
	      *Up2Weight;
	}
      Probability[C] = exp(-Constraint);
    }
}

double mssdState::hyperMutate(int Level,int Position,int ConstraintMode)
{
  if(LevelLength[Level]== 0)
    return 0.0;
  double Probabilities[NumberOfClasses];
  if(MutationMode!=RANDOM)
    hyperProbability(Level,Position,Probabilities,PREDICTED,ConstraintMode);
  double Pprev = Probabilities[PredictedDescription[Level][Position]];
  PredictedDescription[Level][Position] = 
    select(NumberOfClasses,Probabilities,MutationMode);  
  double Pnow  = Probabilities[PredictedDescription[Level][Position]];
  return log(Pprev)-log(Pnow);
}

double  mssdState::hyperMutate(int Level,int ConstraintMode)
{
  int Position = randomSelect(LevelLength[Level]);
  return hyperMutate(Level,Position,ConstraintMode)
    +(Next==NULL? 0.0:((mssdState*)Next)->hyperMutate(Level));
}

double  mssdState::hyperMutate(int ConstraintMode)
{
  double LevelSize[NumberOfLevels];
  for(int L=0;L<NumberOfLevels;++L)
    LevelSize[L] = double(LevelLength[L]);
  int Level = stochasticSelect(NumberOfLevels,LevelSize);
  return hyperMutate(Level,ConstraintMode)
    +(Next==NULL? 0.0:((mssdState*)Next)->hyperMutate(ConstraintMode));
}


void mssdState::hyperOptimalCheck(int ConstraintMode)
{
  for(int L=0;L<NumberOfLevels;++L)
    {
      for(int I=0;I<LevelLength[L];++I)
	{
	  double Probabilities[NumberOfClasses];
	  hyperProbability(L,I,Probabilities,ORIGINAL,ConstraintMode);
	  PredictedDescription[L][I] =
	    optimalSelect(NumberOfClasses,Probabilities);
	}
    }
  if(Next!=NULL)
    ((mssdState*)Next)->hyperOptimalCheck(ConstraintMode);
}

double  mssdState::hyperCost(int CostMode)
{
  double CostPrim       = 0.0;
  double CostLeftRightA = 0.0;
  double CostLeftRightB = 0.0;
  double CostUp1        = 0.0;
  double CostUp2        = 0.0;
  int**  Description = (CostMode==PREDICTED?
		        PredictedDescription:
			LevelDescription);
  for(int L=0;L<NumberOfLevels;++L)
    {
      double LevelCostPrim       = 0.0;
      double LevelCostLeftRightA = 0.0;
      double LevelCostLeftRightB = 0.0;
      double LevelCostUp1        = 0.0;
      double LevelCostUp2        = 0.0;
      for(int I=0;I<LevelLength[L];++I)
	{
	  int StructClass = Description [L][I];
	  CostPrim            += PrimaryConstraints[L][I][StructClass]
	    *PrimaryWeight;
	  LevelCostPrim       += PrimaryConstraints[L][I][StructClass]
	    *PrimaryWeight;
	  CostLeftRightA      += hyperProbLeftRightA(L,I,StructClass,CostMode)
	    *LeftRightWeightA;
	  LevelCostLeftRightA += hyperProbLeftRightA(L,I,StructClass,CostMode)
	    *LeftRightWeightA;
	  CostLeftRightB      += hyperProbLeftRightB(L,I,StructClass,CostMode)
	    *LeftRightWeightB;
	  LevelCostLeftRightB += hyperProbLeftRightB(L,I,StructClass,CostMode)
	    *LeftRightWeightB;
	  if(L>0)
	    {
	      CostUp1         += hyperProbUp1       (L,I,StructClass,CostMode)
		*Up1Weight;
	      LevelCostUp1    += hyperProbUp1       (L,I,StructClass,CostMode)
		*Up1Weight;
	    }
	  if(L>1)
	    {
	      CostUp2         += hyperProbUp2       (L,I,StructClass,CostMode)
		*Up2Weight;
	      LevelCostUp2    += hyperProbUp2       (L,I,StructClass,CostMode)
		*Up2Weight;
	    }
	}
      printf("L %3d P %10.4lf HomoA %10.4lf HomoB %10.4lf Hetero1 %10.4lf Hetero2 %10.4lf\n",
	     L,LevelCostPrim,LevelCostLeftRightA,LevelCostLeftRightB,
	     LevelCostUp1,LevelCostUp2);
    }
  printf(    "Total P %10.4lf HomoA %10.4lf HomoB %10.4lf Hetero1 %10.4lf Hetero2 %10.4lf\n",
	 CostPrim,CostLeftRightA,CostLeftRightB,CostUp1,CostUp2);
  return CostPrim + CostLeftRightA + CostLeftRightB + CostUp1 + CostUp2
	  +(Next==NULL?0.0:((mssdState*)Next)->hyperCost(CostMode));
}



