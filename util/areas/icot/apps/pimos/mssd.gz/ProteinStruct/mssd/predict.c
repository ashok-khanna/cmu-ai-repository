// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stream.h>
#include <math.h>
#include "../wavelet/wavelet.h"
#include "../amino/amino.h"
#include "mssd.h"
#include "prim.h"
#include "geom.h"
#include "predict.h"

int optimalSelect(int NumberOfItems,double* Probabilities)
{
  int    Optimal = -1;
  double Max     =  -100000.0;
  for(int I=0;I<NumberOfItems;++I)
    {
      if(Probabilities[I]>Max)
	{
	  Optimal = I;
	  Max = Probabilities[I];
	}
    }
  return Optimal;
}

int stochasticSelect(int NumberOfItems,double* Probabilities)
{
  double Total = 0.0;
  for(int I=0;I<NumberOfItems;++I)
    {
      Total+= Probabilities[I];
    }
  double R = drand48();
  double SubTotal = Probabilities[0]/Total;
  for(    I=0;I<NumberOfItems-1;++I)
    {
      if(SubTotal>R)
	break;
      SubTotal += Probabilities[I+1]/Total;
    }
  return I;
}

int randomSelect(int NumberOfItems)
{
  return int(drand48()*double(NumberOfItems));
}


mssdState::mssdState
  (
   char* SeqID,
   FILE* PrimStatFile,
   FILE* GeomStatFile,
   char* AminoSeq
   ): mssd()
{
  PrimStats        = new primStat[NumberOfLevels];
  HomoGeomStats    = new geomStat[NumberOfLevels];
  HeteroGeomStats1 = new geomStat[NumberOfLevels-1];
  HeteroGeomStats2 = new geomStat[NumberOfLevels-2];
  MutationMode     = RANDOM;
  ProbabilityMode  = BOTH2;
  for(int L=0;L<NumberOfLevels;++L)
    {
      PrimStats    [L].init(PrimStatFile);
      HomoGeomStats[L].init(GeomStatFile);
      HomoGeomStats[L].expand(BOTH);
    }
  for(    L=0;L<NumberOfLevels-1;++L)
    {
      HeteroGeomStats1[L].init(GeomStatFile);
      HeteroGeomStats1[L].expand(BOTH);
    }
  for(    L=0;L<NumberOfLevels-2;++L)
    {
      HeteroGeomStats2[L].init(GeomStatFile);
      HeteroGeomStats2[L].expand(BOTH);
    }
  PDBEntName = new char[strlen(SeqID)+1];
  strcpy(PDBEntName,SeqID);
  for(    L=0;L<NumberOfLevels;++L)
    {
      GeomPitch           [L] = 0;
      PrimaryConstraints  [L] = NULL;
      PredictedDescription[L] = NULL;
    }
  init(PrimStats,HomoGeomStats,HeteroGeomStats1,HeteroGeomStats2,AminoSeq);
}

mssdState::mssdState
  (
   char*     SeqID,
   primStat* PS,
   geomStat* HomoGS,
   geomStat* HeteroGS1,
   geomStat* HeteroGS2,
   char*     AminoSeq
   ): mssd()
{
  PrimStats        = PS;
  HomoGeomStats    = HomoGS;
  HeteroGeomStats1 = HeteroGS1;
  HeteroGeomStats2 = HeteroGS2;
  MutationMode     = RANDOM;
  ProbabilityMode  = BOTH2;
  PDBEntName       = new char[strlen(SeqID)+1];
  strcpy(PDBEntName,SeqID);
  for(int L=0;L<NumberOfLevels;++L)
    {
      GeomPitch           [L] = 0;
      PrimaryConstraints  [L] = NULL;
      PredictedDescription[L] = NULL;
    }
  init(PrimStats,HomoGeomStats,HeteroGeomStats1,HeteroGeomStats2,AminoSeq);
}

mssdState::mssdState
  (
   primStat* PS,
   geomStat* HomoGS,
   geomStat* HeteroGS1,
   geomStat* HeteroGS2,
   char*     AminoSeq
   ): mssd()
{
  PrimStats        = PS;
  HomoGeomStats    = HomoGS;
  HeteroGeomStats1 = HeteroGS1;
  HeteroGeomStats2 = HeteroGS2;
  MutationMode     = RANDOM;
  ProbabilityMode  = BOTH2;
  PDBEntName       = NULL;
  for(int L=0;L<NumberOfLevels;++L)
    {
      GeomPitch           [L] = 0;
      PrimaryConstraints  [L] = NULL;
      PredictedDescription[L] = NULL;
    }
  init(PrimStats,HomoGeomStats,HeteroGeomStats1,HeteroGeomStats2,AminoSeq);
}


mssdState::mssdState
  (
   primStat* PS,
   geomStat* HomoGS,
   geomStat* HeteroGS1,
   geomStat* HeteroGS2
   ): mssd()
{
  PrimStats        = PS;
  HomoGeomStats    = HomoGS;
  HeteroGeomStats1 = HeteroGS1;
  HeteroGeomStats2 = HeteroGS2;
  MutationMode     = RANDOM;
  ProbabilityMode  = BOTH2;
  PDBEntName       = NULL;
  for(int L=0;L<NumberOfLevels;++L)
    {
      GeomPitch           [L] = 0;
      PrimaryConstraints  [L] = NULL;
      PredictedDescription[L] = NULL;
    }  
}

mssdState::~mssdState(void)
{
  if(PDBEntName!=NULL)
    delete PDBEntName;
  if(AminoSequence!=NULL)
    delete AminoSequence;
  for(int L=0;L<NumberOfLevels;++L)
    {
      if(NULL!=LevelDescription[L])
	delete LevelDescription[L];
    }
  for(    L=0;L<NumberOfLevels;++L)
    {
      if(NULL!=PrimaryConstraints[L])
	{
	  for(int I=0;I<LevelLength[L];++I)
	    {
	      if(PrimaryConstraints[L][I]!=NULL)
		delete PrimaryConstraints[L][I];
	    }
	  delete PrimaryConstraints[L];
	}
      if(NULL!=PredictedDescription[L])
	delete PredictedDescription[L];
    }
  if(Next!=NULL)
    delete Next;
}

mssd* mssdState::nextMssd(void)
{
  mssdState* New =
    new mssdState(PrimStats,HomoGeomStats,HeteroGeomStats1,HeteroGeomStats2);
  return (mssd*)New;
}

void mssdState::init
  (
   primStat* PS,
   geomStat* HomoGS,
   geomStat* HeteroGS1,
   geomStat* HeteroGS2,
   char*     AminoSeq
   )
{
  AminoSeq++;
  int SeqLength=0;
  int P = 0;
  while(*(AminoSeq+SeqLength)!='>')
    {
      SeqLength++;
    }
  init(SeqLength);
  while(*AminoSeq!='>')
    {
      amino Amino(*(AminoSeq++));
      AminoSequence[P++] = Amino.id();
    }
  AminoSeq++;
  if(*AminoSeq=='<')
    {
      if(Next!=NULL)
	delete Next;
      Next =
	new mssdState
	  (
	   PrimStats,
	   HomoGeomStats,
	   HeteroGeomStats1,
	   HeteroGeomStats2,
	   AminoSeq
	   );
    }
}

void  mssdState::init(int Len)
{
  Length   = Len;
  AminoSequence = new int[Length];
  for(int L=0;L<NumberOfLevels;++L)
    {
      LevelLength[L] = (
			Length-LevelWidth[L]+1>0?
			Length-LevelWidth[L]+1:
			0
			);
      if(LevelDescription[L]!=NULL)
	delete LevelDescription    [L];
      LevelDescription    [L] = new int[LevelLength[L]];
      if(PredictedDescription[L]!=NULL)
	delete PredictedDescription[L];
      PredictedDescription[L] = new int[LevelLength[L]];
      if(PrimaryConstraints  [L]!=NULL)
	delete PrimaryConstraints  [L];
      PrimaryConstraints  [L] = new doubleP[LevelLength[L]];
      for(int I=0;I<LevelLength[L];++I)
	PrimaryConstraints[L][I] = NULL;
    }
}

void    mssdState::initialize(int MM,int PM,int* GP)
{
  MutationMode    = MM;
  ProbabilityMode = PM;
  for(int L=0;L<NumberOfLevels;++L)
    {
      GeomPitch[L] = GP[L];
      if(LevelLength[L] == 0)
	break;
      for(int I=0;I<LevelLength[L];++I)
	{
	  if(PrimaryConstraints[L][I] != NULL)
	    delete PrimaryConstraints[L][I];
	  double* Probabilities
	    = PrimaryConstraints[L][I]
	    = new double[NumberOfClasses];
	  PrimStats[L].probability(AminoSequence+I,Probabilities,PM);
	  PredictedDescription[L][I] =
	    select(NumberOfClasses,Probabilities,MM);
	}
    }
  if(Next!=NULL)
    ((mssdState*)Next)->initialize(MM,PM,GP);
}

void mssdState::initialize
  (
   primStat* PS,
   geomStat* HomoGS,
   geomStat* HeteroGS1,
   geomStat* HeteroGS2,
   int       MM,
   int       PM,
   int*      GP
   )
{
  PrimStats        = PS;
  HomoGeomStats    = HomoGS;
  HeteroGeomStats1 = HeteroGS1;
  HeteroGeomStats2 = HeteroGS2;
  MutationMode     = MM;
  ProbabilityMode  = PM;
  for(int L=0;L<NumberOfLevels;++L)
    {
      GeomPitch[L] = GP[L];
      if(LevelLength[L] == 0)
	break;
      for(int I=0;I<LevelLength[L];++I)
	{
	  if(PredictedDescription[L]!=NULL)
	    delete PredictedDescription[L];
	  PredictedDescription[L] = new int[LevelLength[L]];
	  if(PrimaryConstraints[L][I]!=NULL)
	    delete PrimaryConstraints[L][I];
	  double* Probabilities
	    = PrimaryConstraints[L][I]
	    = new double[NumberOfClasses];
	  PrimStats[L].probability(AminoSequence+I,Probabilities,PM);
	  if(MM == COPY)
	    PredictedDescription[L][I] = LevelDescription[L][I];
	  else
	    {
	      PredictedDescription[L][I] =
		select(NumberOfClasses,Probabilities,MM);
	    }
	}
    }
  if(Next!=NULL)
    ((mssdState*)Next)->initialize(PS,HomoGS,HeteroGS1,HeteroGS2,MM,PM,GP);
}

double   mssdState::probLeft
  (
   int Level,
   int Position,
   int StructClass,
   int CostMode
   )
{
  double GeomLeft  = 0.0;
  int**  Description = (CostMode==PREDICTED?
		        PredictedDescription:
			LevelDescription);
  int Offset = GeomPitch[Level];
  if(LevelWidth[Level] > Offset && Position >= Offset)
    {
      GeomLeft += log(HomoGeomStats[Level].probability
	(
	 Description[Level][Position-Offset],
	 StructClass,
	 Offset
	 ));
    }
  return GeomLeft;
}

double   mssdState::probRight
  (
   int Level,
   int Position,
   int StructClass,
   int CostMode
   )
{
  double GeomRight = 0.0;
  int**  Description = (CostMode==PREDICTED?
		        PredictedDescription:
			LevelDescription);
  int Offset = GeomPitch[Level];
  if(LevelWidth[Level] > Offset && Position+Offset < LevelLength[Level])
    {
      GeomRight += log(HomoGeomStats[Level].probability
	(
	 StructClass,
	 Description[Level][Position+Offset],
	 Offset
	 ));
    }
  return GeomRight;
}

double   mssdState::probUp1
  (
   int Level,
   int Position,
   int StructClass,
   int CostMode
   )
{
  double GeomUp    = 0.0;
  int**  Description = (CostMode==PREDICTED?
		        PredictedDescription:
			LevelDescription);
  if(Level-1>=0)
    {
      GeomUp += log(HeteroGeomStats1[Level-1].probability
		    (
		     StructClass,
		     Description[Level-1][Position],
		     0
		     ));
      int Offset = LevelWidth[Level]-LevelWidth[Level-1];
      GeomUp += log(HeteroGeomStats1[Level-1].probability
		    (
		     StructClass,
		     Description[Level-1][Position+Offset],
		     Offset
		     ));
    }
  return GeomUp;
}

double   mssdState::probDown1
  (
   int Level,
   int Position,
   int StructClass,
   int CostMode
   )
{
  double GeomDown  = 0.0;
  int**  Description = (CostMode==PREDICTED?
		        PredictedDescription:
			LevelDescription);
  if(Level+1 <NumberOfLevels)
    {
      int Offset = LevelWidth[Level+1]-LevelWidth[Level];
      if(Position-Offset>0)
	{
	  GeomDown += log(HeteroGeomStats1[Level].probability
			  (
			   Description[Level+1][Position-Offset],
			   StructClass,
			   Offset
			   ));
	}
      if(Position<LevelLength[Level+1])
	{
	  GeomDown += log(HeteroGeomStats1[Level].probability
			  (
			   Description[Level+1][Position],
			   StructClass,
			   0
			   ));
	}
    }
  return GeomDown;
}

double   mssdState::probUp2
  (
   int Level,
   int Position,
   int StructClass,
   int CostMode
   )
{
  double GeomUp    = 0.0;
  int**  Description = (CostMode==PREDICTED?
		        PredictedDescription:
			LevelDescription);
  if(Level-2 >= 0)
    {
      GeomUp += log(HeteroGeomStats2[Level-2].probability
		    (
		     StructClass,
		     Description[Level-2][Position],
		     0
		     ));
      int Offset = LevelWidth[Level]-LevelWidth[Level-1];
      GeomUp += log(HeteroGeomStats2[Level-2].probability
		    (
		     StructClass,
		     Description[Level-2][Position+Offset],
		     Offset
		     ));
    }
  return GeomUp;
}

double   mssdState::probDown2
  (
   int Level,
   int Position,
   int StructClass,
   int CostMode
   )
{
  double GeomDown  = 0.0;
  int**  Description = (CostMode==PREDICTED?
		        PredictedDescription:
			LevelDescription);
  if(Level+2<NumberOfLevels)
    {
      int Offset = LevelWidth[Level+2]-LevelWidth[Level];
      if(Position-Offset>0)
	{
	  GeomDown += log(HeteroGeomStats2[Level].probability
			  (
			   Description[Level+2][Position-Offset],
			   StructClass,
			   Offset
			   ));
	}
      if(Position < LevelLength[Level+2])
	 {
	   GeomDown += log(HeteroGeomStats2[Level].probability
			   (
			    Description[Level+2][Position],
			    StructClass,
			    0
			    ));
	 }
    }
  return GeomDown;
}

void    mssdState::probability
  (
   int     Level,
   int     Position,
   double* Probability,
   int     CostMode,
   int     ConstraintMode
   )
{
  if(Position< 0 || Position>=LevelLength[Level])
    {
      cerr << "Invalid Position! at mutation!\n";
      exit(1);
    }
  for(int C=0;C<NumberOfClasses;++C)
    {
      double Constraint = 0;
      if(ConstraintMode&1)
	Constraint+= log(PrimaryConstraints[Level][Position][C]);
      if(ConstraintMode&2)
	Constraint+= probLeft (Level,Position,C,CostMode);
      if(ConstraintMode&4)
	Constraint+= probRight(Level,Position,C,CostMode);
      if(ConstraintMode&8)
	Constraint+= probUp1  (Level,Position,C,CostMode);
      if(ConstraintMode&16)
	Constraint+= probDown1(Level,Position,C,CostMode);
      if(ConstraintMode&32)
	Constraint+= probUp2  (Level,Position,C,CostMode);
      if(ConstraintMode&64)
	Constraint+= probDown2(Level,Position,C,CostMode);
      Probability[C] = exp(Constraint);
    }
}


double mssdState::mutate(int Level,int Position,int ConstraintMode)
{
  if(LevelLength[Level]== 0)
    return 0.0;
  double Probabilities[NumberOfClasses];
  probability(Level,Position,Probabilities,PREDICTED,ConstraintMode);
  double Pprev = Probabilities[PredictedDescription[Level][Position]];
  PredictedDescription[Level][Position] = 
    select(NumberOfClasses,Probabilities,MutationMode);  
  double Pnow  = Probabilities[PredictedDescription[Level][Position]];
  return log(Pprev)-log(Pnow);
}

double  mssdState::mutate(int Level,int ConstraintMode)
{
  int Position = randomSelect(LevelLength[Level]);
  return mutate(Level,Position,ConstraintMode)
    +(Next==NULL? 0.0:((mssdState*)Next)->mutate(Level));
}

double  mssdState::mutate(int ConstraintMode)
{
  double LevelSize[NumberOfLevels];
  for(int L=0;L<NumberOfLevels;++L)
    LevelSize[L] = double(LevelLength[L]);
  int Level = stochasticSelect(NumberOfLevels,LevelSize);
  return mutate(Level,ConstraintMode)
    +(Next==NULL? 0.0:((mssdState*)Next)->mutate(ConstraintMode));
}

void mssdState::optimalCheck(int ConstraintMode)
{
  for(int L=0;L<NumberOfLevels;++L)
    {
      for(int I=0;I<LevelLength[L];++I)
	{
	  double Probabilities[NumberOfClasses];
	  probability(L,I,Probabilities,ORIGINAL,ConstraintMode);
	  PredictedDescription[L][I] =
	    optimalSelect(NumberOfClasses,Probabilities);
	}
    }
  if(Next!=NULL)
    ((mssdState*)Next)->optimalCheck(ConstraintMode);
}

void mssdState::accuracy(int* Total,int* Hit)
{
  if(PDBEntName!=NULL)
    printf("%s\n",PDBEntName);
  for(int L=0;L<NumberOfLevels;++L)
    {
      int LevelTotal = 0;
      int LevelHit   = 0;
      printf("Level %2d Width %4d\n<",L,LevelWidth[L]);
      for(int I=0;I<LevelLength[L];++I)
	{
	  printf("%c",LevelDescription[L][I] +'A');
	  if(PredictedDescription[L][I] == LevelDescription[L][I])
	    {
	      Hit[L]++;
	      LevelHit++;
	    }
	  Total[L]++;
	  LevelTotal++;
	}
      printf(">\n<");
      for(    I=0;I<LevelLength[L];++I)
	{
	  printf("%c",PredictedDescription[L][I]+'A');
	}
      printf(">\n<");
      for(    I=0;I<LevelLength[L];++I)
	{
	  printf("%c",(
		       PredictedDescription[L][I]==LevelDescription[L][I]?
		       '*':' '
		       )
		 );
	}
      printf(">\nTotal %4d Hit %4d Accuracy %10.5lf\n",
	     LevelTotal,LevelHit,(LevelHit==0? 0.0:
				  double(LevelHit)/double(LevelTotal)
				  )
	     );
    }
  if(Next!=NULL)
    ((mssdState*)Next)->accuracy(Total,Hit);
}

double  mssdState::cost(int CostMode)
{
  double CostPrim  = 0.0;
  double CostLeft  = 0.0;
  double CostRight = 0.0;
  double CostUp1   = 0.0;
  double CostDown1 = 0.0;
  double CostUp2   = 0.0;
  double CostDown2 = 0.0;
  for(int L=0;L<NumberOfLevels;++L)
    {
      double LevelCostPrim  = 0.0;
      double LevelCostLeft  = 0.0;
      double LevelCostRight = 0.0;
      double LevelCostUp1   = 0.0;
      double LevelCostDown1 = 0.0;
      double LevelCostUp2   = 0.0;
      double LevelCostDown2 = 0.0;
      for(int I=0;I<LevelLength[L];++I)
	{
	  int StructClass = (
			     CostMode==ORIGINAL?
			     LevelDescription    [L][I]:
			     PredictedDescription[L][I]
			     );
	  CostPrim  -= log(PrimaryConstraints[L][I][StructClass]);
	  CostLeft  -= probLeft (L,I,StructClass,CostMode);
	  CostRight -= probRight(L,I,StructClass,CostMode);
	  CostUp1   -= probUp1  (L,I,StructClass,CostMode);
	  CostDown1 -= probDown1(L,I,StructClass,CostMode);
	  CostUp2   -= probUp2  (L,I,StructClass,CostMode);
	  CostDown2 -= probDown2(L,I,StructClass,CostMode);

	  LevelCostPrim  -= log(PrimaryConstraints[L][I][StructClass]);
	  LevelCostLeft  -= probLeft (L,I,StructClass,CostMode);
	  LevelCostRight -= probRight(L,I,StructClass,CostMode);
	  LevelCostUp1   -= probUp1  (L,I,StructClass,CostMode);
	  LevelCostDown1 -= probDown1(L,I,StructClass,CostMode);
	  LevelCostUp2   -= probUp2  (L,I,StructClass,CostMode);
	  LevelCostDown2 -= probDown2(L,I,StructClass,CostMode);
	}
      cerr <<
	form("Level %3d Prim %10.5lf Left%10.5lf Right %10.5lf Up1 %10.5lf Down1 %10.5lf Up2 %10.5lf Down2 %10.5lf\n",
	     L,LevelCostPrim,LevelCostLeft,LevelCostRight,LevelCostUp1,LevelCostDown1,LevelCostUp2,LevelCostDown2);

    }
  cerr <<
    form("Prim %10.5lf Left%10.5lf Right %10.5lf Up1 %10.5lf Down1 %10.5lf Up2 %10.5lf Down2 %10.5lf\n",
	 CostPrim,CostLeft,CostRight,CostUp1,CostDown1,CostUp2,CostDown2);
  return CostPrim+CostLeft+CostRight+CostUp1+CostDown1+CostUp2+CostDown2
    -(Next==NULL?0.0:((mssdState*)Next)->cost(CostMode));
}


