// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <ctype.h>
#include <stdio.h>
#include <stream.h>
#include <string.h>
#include "data-set.h"

void dataSetProperty::readLine(char* BufferLine,double* Data)
{
  int    FieldCnt     = 0;
  int    ComponentCnt = 0;
  char*  Buff = BufferLine;
  while(*Buff!='\0' && ComponentCnt < NumberOfComponents)
    {
      while(isspace(*Buff)) Buff++;
      if(Components[ComponentCnt].fieldId() == FieldCnt)
	{
	  sscanf(Buff,"%lf",&Data[ComponentCnt]);
	  ComponentCnt++;
	}
      FieldCnt++;
      while(!isspace(*Buff)) Buff++;
    }
}  

void dataSetProperty::principalPosition
  (
   double* Data,
   double* PrincipalPosition
   )
{
  for(int I=0;I<NumberOfComponents;++I)
    PrincipalPosition[I] = 0.0;

  for(    I=0;I<NumberOfComponents;++I)
    {
      for(int J=0;J<NumberOfComponents;++J)
	{
	  PrincipalPosition[I] +=
	    (Data[J]-Components[J].mean())*PrincipalComponents[I].axis(J);
	}
    }
  for(    I=0;I<NumberOfComponents;++I)
    PrincipalPosition[I] /= sqrt(TotalVariance);
}

void dataSetProperty::digitize
  (
   double* Data,
   int*    DigitalPosition,
   double  DivConst
   )
{
  double PrincipalPosition[NumberOfComponents];
  principalPosition(Data,PrincipalPosition);
  for(int I=0;I<NumberOfComponents;++I)
    {
      DigitalPosition[I] = (
			    PrincipalPosition[I]>0?
			     int( PrincipalPosition[I]*DivConst+0.5):
			    -int(-PrincipalPosition[I]*DivConst+0.5)
			    );
      }
}
//                    0123456789012345678901234567
const char Plus [] = " ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const char Minus[] = " abcdefghijklmnopqrstuvwxyz";

void dataSetProperty::quantize
(
 double* Data,
 char*   QuantizedData,
 double DivConst
)
{
  int    DigitalPosition[NumberOfComponents];
  digitize(Data,DigitalPosition,DivConst);
  for(int I=0;I<NumberOfComponents;++I)
    {
      if(DigitalPosition[I]==0)
	  QuantizedData[I] =  '.';
      else if(DigitalPosition[I]>0)
	{
	  if(DigitalPosition[I]>26)
	    QuantizedData[I] = '+';
	  else
	    QuantizedData[I] = Plus [ DigitalPosition[I]];
	}
      else 
	{
	  if(DigitalPosition[I]<-26)
	   QuantizedData[I] = '-';
	  else
	    QuantizedData[I] = Minus[-DigitalPosition[I]];
	}
    }
  QuantizedData[NumberOfComponents] = '\0';
}

double dataSetProperty::probability(double* Data)
{
  double PValue[NumberOfComponents];
  principalPosition(Data,PValue);
  double Distance = 0.0;
  for(int I=0;I<NumberOfComponents;++I)
    {
      Distance +=
	PValue[I]*PValue[I]/(PrincipalComponents[I].contributionRatio());
    }
  return exp(-Distance)*double(NumberOfData);
}  

double dataSetProperty::distributionDistance(double* Data)
{
  double PValue[NumberOfComponents];
  for(int I=0;I<NumberOfComponents;++I)
    PValue[I] = 0.0;

  for(    I=0;I<NumberOfComponents;++I)
    {
      for(int J=0;J<NumberOfComponents;++J)
	{
	  PValue[I] +=
	    (Data[J]-Components[J].mean())*PrincipalComponents[I].axis(J);
	}
    }
  double Distance = 0.0;
  for(I=0;I<NumberOfComponents;++I)
    {
      Distance +=
	PValue[I]*PValue[I]/(PrincipalComponents[I].contributionRatio());
    }
  return sqrt(Distance);
}  
  

double dataSetProperty::distance(double* Data)
{
  double Distance = 0.0;
  for(int I=0;I<NumberOfComponents;++I)
    {
      double Position = Data[I]-Components[I].mean();
      Distance += Position*Position;
    }
  return sqrt(Distance);
}  

dataSet* dataSetProperty::readDataFile(void)
{
  dataSet* DataSets = new dataSet[NumberOfData];
  for(int I=0;I<NumberOfData;++I)
    DataSets[I].init(NumberOfComponents);

  FILE* DataFile;
  if(NULL == (DataFile = fopen(FileName,"r")))
    {
      cerr << form("Can't open Data File \"%s\"\n",FileName);
      exit(1);
    }
  int DataCnt = 0;
  char BufferLine[1024];
  while(fgets(BufferLine,1023,DataFile))
    {
      if(BufferLine[0] == '#')
	continue;
      double* Data = new double[NumberOfComponents];
      readLine(BufferLine,Data);
      DataSets[DataCnt++].data(Data);
    }
  fclose(DataFile);
  return DataSets;
}

