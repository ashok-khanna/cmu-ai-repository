// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <ctype.h>
#include <stdio.h>
#include <stream.h>
#include <string.h>
#include "data-set.h"


int dataSetProperty::getFileName(FILE* DataSetPropertyFile)
{
  char BufferLine[1024];
  if(0==strncmp
     (fgets(BufferLine,1023,DataSetPropertyFile),"Data File Name      :",21))
    {
      char FileNameTmp[256];
      sscanf(BufferLine+21,"%s",FileNameTmp);
      if(NULL!=FileName)
	delete FileName;
      FileName = new char[strlen(FileNameTmp)+1];
      strcpy(FileName,FileNameTmp);
      return 1;
    }    
  else
    {
      cerr << "Invalid Data Set Property File\n";
      return 0;
    }
}

int dataSetProperty::getNumberOfComponents(FILE* DataSetPropertyFile)
{
  char BufferLine[1024];
  if(0==strncmp
     (fgets(BufferLine,1023,DataSetPropertyFile),"Number of Components:",21))
    {
      sscanf(BufferLine+21,"%d",&NumberOfComponents);
      Components          = new          component[NumberOfComponents];
      PrincipalComponents = new principalComponent[NumberOfComponents];
      for(int I=0;I<NumberOfComponents;++I)
	PrincipalComponents[I].init(NumberOfComponents);
      return 1;
    }    
  else
    {
      cerr << "Invalid Data Set Property File\n";
      return 0;
    }
}

int dataSetProperty::getNumberOfData(FILE* DataSetPropertyFile)
{
  char BufferLine[1024];
 if(0==strncmp
    (fgets(BufferLine,1023,DataSetPropertyFile),"Number of Data Sets :",21))
    {
      sscanf(BufferLine+21,"%d",&NumberOfData);
      return 1;
    }    
  else
    {
      cerr << "Invalid Data Set Property File\n";
      return 0;
    }
}

int dataSetProperty::getTotalVariance(FILE* DataSetPropertyFile)
{
  char BufferLine[1024];
  if( 0==strncmp
     (fgets(BufferLine,1023,DataSetPropertyFile),"Total Variance      :",21))
    {
      sscanf(BufferLine+21,"%lf",&TotalVariance);
      return 1;
    }    
  else
    {
      cerr << "Invalid Data Set Property File\n";
      return 0;
    }
}

int dataSetProperty::getFieldNumber(FILE* DataSetPropertyFile)
{
  char BufferLine[1024];
  if(0==strncmp
     (fgets(BufferLine,1023,DataSetPropertyFile),"Field Number        :",21))
    {
      char* Buff = BufferLine+21;
      int FieldCnt = 0;
      while(*Buff!='\0')
	{
	  while(isspace(*Buff)) Buff++;
	  if(*Buff=='\0') break;
	  int FieldIdTmp;
	  sscanf(Buff,"%d",&FieldIdTmp);
	  Components[FieldCnt++].fieldId(FieldIdTmp);
	  while(!isspace(*Buff)) Buff++;
	}
      return 1;
    }    
  else
    {
      cerr << "Invalid Data Set Property File\n";
      return 0;
    }
}

int dataSetProperty::getMean(FILE* DataSetPropertyFile)
{
  char BufferLine[1024];
  if(0==strncmp
     (fgets(BufferLine,1023,DataSetPropertyFile),"Mean                :",21))
    {
      char* Buff = BufferLine+21;
      int FieldCnt = 0;
      while(*Buff!='\0'&&FieldCnt<NumberOfComponents)
	{
	  while(isspace(*Buff)) Buff++;
	  double MeanTmp;
	  sscanf(Buff,"%lf",&MeanTmp);
	  Components[FieldCnt++].mean(MeanTmp);
	  while(!isspace(*Buff)) Buff++;
	}
      return 1;
    }    
  else
    {
      cerr << "Invalid Data Set Property File\n";
      return 0;
    }
}

int dataSetProperty::getMinimum(FILE* DataSetPropertyFile)
{
  char BufferLine[1024];
  if(0==strncmp
     (fgets(BufferLine,1023,DataSetPropertyFile),"Minimum             :",21))
    {
      char* Buff = BufferLine+21;
      int FieldCnt = 0;
      while(*Buff!='\0'&&FieldCnt<NumberOfComponents)
	{
	  while(isspace(*Buff)) Buff++;
	  double MinimumTmp;
	  sscanf(Buff,"%lf",&MinimumTmp);
	  Components[FieldCnt++].minimum(MinimumTmp);
	  while(!isspace(*Buff)) Buff++;
	}
      return 1;
    }    
  else
    {
      cerr << "Invalid Data Set Property File\n";
      return 0;
    }
}

int dataSetProperty::getMaximum(FILE* DataSetPropertyFile)
{
  char BufferLine[1024];
  if(0==strncmp
     (fgets(BufferLine,1023,DataSetPropertyFile),"Maximum             :",21))
    {
      char* Buff = BufferLine+21;
      int FieldCnt = 0;
      while(*Buff!='\0'&&FieldCnt<NumberOfComponents)
	{
	  while(isspace(*Buff)) Buff++;
	  double MaximumTmp;
	  sscanf(Buff,"%lf",&MaximumTmp);
	  Components[FieldCnt++].maximum(MaximumTmp);
	  while(!isspace(*Buff)) Buff++;
	}
      return 1;
    }    
  else
    {
      cerr << "Invalid Data Set Property File\n";
      return 0;
    }
}

int dataSetProperty::getStandardDeviation(FILE* DataSetPropertyFile)
{
  char BufferLine[1024];
  if(0==strncmp
     (fgets(BufferLine,1023,DataSetPropertyFile),"Standard Deviation  :",21))
    {
      char* Buff = BufferLine+21;
      int FieldCnt = 0;
      while(*Buff!='\0'&&FieldCnt<NumberOfComponents)
	{
	  while(isspace(*Buff)) Buff++;
	  double StandardDeviationTmp;
	  sscanf(Buff,"%lf",&StandardDeviationTmp);
	  Components[FieldCnt++].standardDeviation(StandardDeviationTmp);
	  while(!isspace(*Buff)) Buff++;
	}
      return 1;
    }    
  else
    {
      cerr << "Invalid Data Set Property File\n";
      return 0;
    }
}

int dataSetProperty::getAxisNumber(FILE* DataSetPropertyFile)
{
  char BufferLine[1024];
  if(0==strncmp
     (fgets(BufferLine,1023,DataSetPropertyFile),"Axis Number         :",21))
    {
      return 1;
    }    
  else
    {
      cerr << "Invalid Data Set Property File\n";
      return 0;
    }
}

int dataSetProperty::getContributionRatio(FILE* DataSetPropertyFile)
{
  char BufferLine[1024];
  if(0==strncmp
     (fgets(BufferLine,1023,DataSetPropertyFile),"Contribution Ratio  :",21))
    {
      char* Buff = BufferLine+21;
      int AxisCnt = 0;
      while(*Buff!='\0'&&AxisCnt<NumberOfComponents)
	{
	  while(isspace(*Buff)) Buff++;
	  double ContributionRatioTmp;
	  sscanf(Buff,"%lf",&ContributionRatioTmp);
	  PrincipalComponents[AxisCnt++]
	    .contributionRatio(ContributionRatioTmp);
	  while(!isspace(*Buff)) Buff++;
	}
      return 1;
    }    
  else
    {
      cerr << "Invalid Data Set Property File\n";
      return 0;
    }
}

int dataSetProperty::getVectorElements(FILE* DataSetPropertyFile)
{
  char BufferLine[1024];
  while(fgets(BufferLine,1023,DataSetPropertyFile))
    {
      if(0==strncmp(BufferLine,"Vector Element",14))
	{
	  char* Buff = BufferLine+14;
	  int J;
	  sscanf(Buff,"%d",&J);
	  Buff = BufferLine+21;
	  int AxisCnt = 0;
	  while(*Buff!='\0'&&AxisCnt<NumberOfComponents)
	    {
	      while(isspace(*Buff)) Buff++;
	      double VectorElementTmp;
	      sscanf(Buff,"%lf",&VectorElementTmp);
	      PrincipalComponents[AxisCnt++].axis(J,VectorElementTmp);
	      while(!isspace(*Buff)) Buff++;
	    }
	}
      else
	{
	  cerr << "Invalid Data Set Property File\n";
	  return 0;
	}
    }
  return 1;
}

int dataSetProperty::get(char* DataSetPropetyFileName)
{
  FILE* DataSetPropertyFile;
  if(NULL == (DataSetPropertyFile = fopen(DataSetPropetyFileName,"r")))
    {
      cerr << 
	form(
	     "Can't open Data Set Property File \"%s\"\n",
	     DataSetPropetyFileName
	     );
      fclose(DataSetPropertyFile);
      return 0;
    }
  if(0==getFileName(DataSetPropertyFile))
    {
      fclose(DataSetPropertyFile);
      return 0;
    }
   if(0==getNumberOfComponents(DataSetPropertyFile))
    {
      fclose(DataSetPropertyFile);
      return 0;
    }
   if(0==getNumberOfData(DataSetPropertyFile))
    {
      fclose(DataSetPropertyFile);
      return 0;
    }
   if(0==getTotalVariance(DataSetPropertyFile))
    {
      fclose(DataSetPropertyFile);
      return 0;
    }
   if(0==getFieldNumber(DataSetPropertyFile))
    {
      fclose(DataSetPropertyFile);
      return 0;
    }
   if(0==getMean(DataSetPropertyFile))
    {
      fclose(DataSetPropertyFile);
      return 0;
    }
   if(0==getMinimum(DataSetPropertyFile))
    {
      fclose(DataSetPropertyFile);
      return 0;
    }
   if(0==getMaximum(DataSetPropertyFile))
    {
      fclose(DataSetPropertyFile);
      return 0;
    }
   if(0==getStandardDeviation(DataSetPropertyFile))
    {
      fclose(DataSetPropertyFile);
      return 0;
    }
   if(0==getAxisNumber(DataSetPropertyFile))
    {
      fclose(DataSetPropertyFile);
      return 0;
    }
   if(0==getContributionRatio(DataSetPropertyFile))
    {
      fclose(DataSetPropertyFile);
      return 0;
    }
   if(0==getVectorElements(DataSetPropertyFile))
    {
      fclose(DataSetPropertyFile);
      return 0;
    }
  
  fclose(DataSetPropertyFile);
  return 1;
}
