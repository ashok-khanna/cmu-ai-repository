// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdlib.h>
#include <stream.h>
#include "data-set.h"
#include "cluster.h"

main(int ArgCnt,char** ArgVal)
{
  if(ArgCnt<2)
    {
      cerr << "Too few arguments!\n";
      exit(1);
    }

  dataSetProperty* DataSetProperty = new dataSetProperty(ArgVal[1]);
  dataSet*         DataSets        = DataSetProperty->readDataFile();
  clusterSet       ClusterSet(DataSetProperty,DataSets);
}
