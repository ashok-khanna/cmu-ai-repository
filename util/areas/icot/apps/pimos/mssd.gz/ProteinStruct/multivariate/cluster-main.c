// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdlib.h>
#include <stream.h>
#include <string.h>
#include "data-set.h"
#include "cluster.h"

double MFactor    = 4.0;

main(int ArgCnt,char** ArgVal)
{
  if(ArgCnt<3)
    {
      cerr << "Too few arguments!\n";
      cerr <<
	"Usage:\n cluster [DSP file name] [Number of clusters]\n";
      exit(1);
    }
  dataSetProperty* DataSetProperty = new dataSetProperty(ArgVal[1]);
  dataSet*         DataSets        = DataSetProperty->readDataFile();
  clusterSet ClusterSet(DataSetProperty,DataSets,atoi(ArgVal[2]));
}
