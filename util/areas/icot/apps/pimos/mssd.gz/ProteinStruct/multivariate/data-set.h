// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <ctype.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "../matrix/matrix.h"
#include "../matrix/eigenvalue.h"

class component
{
  int     FieldId;
  double  Minimum;
  double  Maximum;
  double  Mean;
  double  StandardDeviation;
 public:
  inline component(void)
    {
      FieldId =   0;
      Minimum = 0.0;
      Maximum = 0.0;
      Mean    = 0.0;
      StandardDeviation = 0.0;
    }
  inline void   clear()
    {
      Minimum = Maximum = 0.0;
    }
  inline void   fieldId(int    FI  ){FieldId =  FI;}
  inline void   data   (double Data)
    {
      if(Minimum!=0)
	{
	  if(Data < Minimum)
	    Minimum = Data;
	  else if(Data > Maximum)
	    Maximum = Data;
	}
      else
	{
	  Minimum = Data;
	  Maximum = Data;
	}
    }
  inline void   mean   (double M)  {Mean    = M;}
  inline void   minimum(double M)  {Minimum = M;}
  inline void   maximum(double M)  {Maximum = M;}
  inline void   standardDeviation  (double SD)
    {StandardDeviation = SD;}

  inline int    fieldId(void)      {return FieldId;}
  inline double minimum(void)      {return Minimum;}
  inline double maximum(void)      {return Maximum;}
  inline double mean   (void)      {return Mean;}
  inline double standardDeviation  (void)
    {return StandardDeviation;}
};

class principalComponent
{
  double  ContributionRatio;
  matrix  Axis;
 public:
  inline principalComponent(void)
    {
      ContributionRatio = 0.0;
    }

  inline ~principalComponent(void)
    {
      Axis.zap();
    }

  inline void zap(void)
    {
      Axis.zap();
    }
  inline void init(int NumberOfComponents)
    {
      ContributionRatio = 0.0;
      Axis = matrix(NumberOfComponents,1);
    }
  inline void clear()
    {
      ContributionRatio = 0.0;
    }
  inline void contributionRatio(double CR)
    {
      ContributionRatio = CR;
    }
  inline double contributionRatio(void)
    {
      return ContributionRatio;
    }
  inline void    axis(int I,double Elem){Axis(I,0) = Elem;}
  inline double  axis(int I)            {return Axis(I,0);}
  inline matrix& axis(void)             {return Axis;}
};

class dataSet
{
  int     ClusterId;
  int     NumberOfComponents;
  double* Data;
 public:
  inline dataSet(void)
    {
      ClusterId          = -1;
      NumberOfComponents = 0;
      Data               = NULL;
    }
  inline dataSet(int CId,int NC)
    {
      ClusterId          = CId;
      NumberOfComponents = NC;
      Data               = NULL;
    }      
  inline dataSet(int NC)
    {
      ClusterId          = -1;
      NumberOfComponents = NC;
      Data               = NULL;
    }      
  inline init(int CId,int NC)
    {
      ClusterId          = CId;
      NumberOfComponents = NC;
    }
  inline init(int NC)
    {
      ClusterId          = -1;
      NumberOfComponents = NC;
    }      
  inline ~dataSet(void)
    {
      delete Data;
    }
  inline void clusterId(int CId)
    {
      ClusterId = CId;
    }
  inline int  clusterId(void)
    {
      return ClusterId;
    }
  inline void data(int I,double DataNew)
    {
      if(I<0||I>=NumberOfComponents)
	{
	  cerr << "Out of range!\n";
	  exit(1);
	}
      Data[I] = DataNew;
    }
  inline void   data(double* D)
    {
      if(Data!=NULL)
	{
	  cerr << "Data Overwritten\n";
	  delete Data;
	}
      Data = D;
    }
  inline double data(int I)
    {
      if(I<0||I>=NumberOfComponents)
	{
	  cerr << "Out of range!\n";
	  exit(1);
	}
      return Data[I];
    }
  inline double* data(void)
    {
      return Data;
    }
  inline void fprint(FILE* File)
    {
      for(int I=0;I<NumberOfComponents;++I)
	fprintf(File,"%10.5lf ",Data[I]);
      fprintf(File,"\n");
    }
};

class dataSetProperty
{
  char*               FileName;
  int                 NumberOfComponents;
  int                 NumberOfData;
  int                 DataCnt;
  double              TotalVariance;
  component*          Components;
  principalComponent* PrincipalComponents;
  matrix              CovarianceMatrix;
  matrix              MeanOfComponents;
 public:
  inline dataSetProperty(void)
    {
      FileName            = NULL;
      NumberOfComponents  = 0;
      NumberOfData        = 0;
      DataCnt             = 0;
      TotalVariance       = 0.0;
      Components          = NULL;
      PrincipalComponents = NULL;
    }
  inline dataSetProperty(char* DataSetFileName)
    {
      FileName            = NULL;
      NumberOfComponents  = 0;
      NumberOfData        = 0;
      DataCnt             = 0;
      TotalVariance       = 0.0;
      Components          = NULL;
      PrincipalComponents = NULL;
      get(DataSetFileName);
    }
  inline dataSetProperty(int NumberOfField, int* FieldId)
    {
      FileName            = NULL;
      NumberOfComponents  = NumberOfField;
      NumberOfData        = 0;
      DataCnt             = 0;
      TotalVariance       = 0.0;
      CovarianceMatrix    = matrix(NumberOfComponents,NumberOfComponents);
      MeanOfComponents    = matrix(NumberOfComponents,1);
      Components          = new component[NumberOfComponents];
      PrincipalComponents = new principalComponent[NumberOfComponents];
      for(int I=0;I<NumberOfComponents;++I)
	{
	  Components[I].fieldId(FieldId[I]);
	}
      for(    I=0;I<NumberOfComponents;++I)
	{
	  PrincipalComponents[I].init(NumberOfComponents);
	}
    }
  inline init(int NumberOfField, int* FieldId)
    {
      NumberOfComponents  = NumberOfField;
      NumberOfData        = 0;
      DataCnt             = 0;
      TotalVariance       = 0.0;
      CovarianceMatrix    = matrix(NumberOfComponents,NumberOfComponents);
      MeanOfComponents    = matrix(NumberOfComponents,1);
      Components          = new component[NumberOfComponents];
      PrincipalComponents = new principalComponent[NumberOfComponents];
      for(int I=0;I<NumberOfComponents;++I)
	{
	  Components[I].fieldId(FieldId[I]);
	}
      for(    I=0;I<NumberOfComponents;++I)
	{
	  PrincipalComponents[I].init(NumberOfComponents);
	}
    }
      
  dataSetProperty(char*   DataFileName, int NumberOfField, int* FieldId);
  dataSetProperty(matrix& DataMatrix     );
  dataSetProperty(dataSetProperty& A,dataSetProperty& B);

  inline ~dataSetProperty(void)
    {
      if(FileName           !=NULL) delete FileName;
      if(Components         !=NULL) delete Components;
      if(PrincipalComponents!=NULL)
	{
	  for(int I=0;I<NumberOfComponents;++I)
	    {
	      PrincipalComponents[I].zap();
	    }
	  delete PrincipalComponents;
	}
    }

  inline void clear(void)
    {
      DataCnt = 0;
      for(int I=0;I<NumberOfComponents;++I)
	{
	  Components[I].clear();
	  MeanOfComponents(I,0) = 0.0;
	  for(int J=0;J<NumberOfComponents;++J)
	    {
	      CovarianceMatrix(I,J) = 0.0;
	    }
	}
    }
  int  getFileName          (FILE* DataSetPropertyFile);
  int  getNumberOfComponents(FILE* DataSetPropertyFile);
  int  getNumberOfData      (FILE* DataSetPropertyFile);
  int  getTotalVariance     (FILE* DataSetPropertyFile);
  int  getFieldNumber       (FILE* DataSetPropertyFile);
  int  getMean              (FILE* DataSetPropertyFile);
  int  getMinimum           (FILE* DataSetPropertyFile);
  int  getMaximum           (FILE* DataSetPropertyFile);
  int  getStandardDeviation (FILE* DataSetPropertyFile);
  int  getAxisNumber        (FILE* DataSetPropertyFile);
  int  getContributionRatio (FILE* DataSetPropertyFile);
  int  getVectorElements    (FILE* DataSetPropertyFile);
  int  get                  (char*   DataSetFileName);
  void readLine             (char* BufferLine,double* Data);
  dataSet* readDataFile     (void);
  dataSet* readClusterFile  (void);
  void calculate (void);
  int  put       (void);
  int  fprint    (FILE* DataSetFile);
  void principalPosition(double* Data,double* PrincipalCoordinates);
  void digitize         (double* Data,int*    DigitalPosition,double DivConst);
  void quantize         (double* Data,char*   QuantizedData,  double DivConst);
  double probability         (double* Data);
  double distance            (double* Data);
  double distributionDistance(double* Data);
  inline double firstPrincipalPosition(double* Data)
    {
      double FirstPrincipalPosition = 0.0;
      for(int J=0;J<NumberOfComponents;++J)
	{
	  FirstPrincipalPosition +=
	    (Data[J]-Components[J].mean())*PrincipalComponents[0].axis(J);
	}
      return FirstPrincipalPosition/sqrt(TotalVariance);
    }
  inline void  fprintData(FILE* File,double* Data)
    {
      int Field       = 0;
      for(int CI=0;CI<NumberOfComponents;++CI)
	{
	  while(fieldId(CI)>Field)
	    {
	      fprintf(File," %10.5lf",0.0);
	      Field++;
	    }
	  fprintf(File," %10.5lf",Data[CI]);
	  Field++;
	}
      fprintf(File,"\n");
    }
  inline void  fprintMean(FILE* File)
    {
      int Field       = 0;
      for(int CI=0;CI<NumberOfComponents;++CI)
	{
	  while(fieldId(CI)>Field)
	    {
	      fprintf(File," %10.5lf",0.0);
	      Field++;
	    }
	  fprintf(File," %10.5lf",mean(CI));
	  Field++;
	}
      fprintf(File,"\n");
    }
  inline void input(double* Data)
    {
      for(int I=0;I<NumberOfComponents;++I)
	{
	  Components[I].data(Data[I]);
	  MeanOfComponents(I,0) += Data[I];
	  for(int J=0;J<NumberOfComponents;++J)
	    {
	      CovarianceMatrix(I,J) += Data[I]*Data[J];
	    }
	}
      DataCnt++;
    }
  inline void input(char* BufferLine)
    {
      double Data[NumberOfComponents];
      readLine(BufferLine,Data);
      input(Data);
    }
  inline int    print             (void){return fprint(stdout);    }
  inline char*  dataFileName      (void){return FileName;          }
  inline void   dataFileName      (char* DFN)
    {
      if(FileName!=NULL) delete FileName;
      FileName = new char[strlen(DFN)+1];
      strcpy(FileName,DFN);
    }
  inline int    fieldId           (int I)
    {
      return Components[I].fieldId();
    }
  inline double mean(int I)
    {
      return Components[I].mean();
    }
  inline double standardDeviation(int I)
    {
      return Components[I].standardDeviation();
    }
  inline double minimum(int I)
    {
      return Components[I].minimum();
    }
  inline double maximum(int I)
    {
      return Components[I].maximum();
    }
  inline int    numberOfComponents(void ){return NumberOfComponents;}
  inline void   numberOfData      (int N){NumberOfData  = N;        }
  inline int    numberOfData      (void ){return NumberOfData;      }
  inline double totalVariance     (void ){return TotalVariance;     }
};

