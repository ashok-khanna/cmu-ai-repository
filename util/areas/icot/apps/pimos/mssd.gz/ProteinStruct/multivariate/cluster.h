// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include "gsort.h"

extern int prime(int Base);

class clusterCentroid
{
  int               Dimension;
  int               NumberOfData;
  int               OldNumberOfData;
  int               DataCnt;
  double*           DataMean;
  double*           DataMeanTmp;
  int               ClusterID;
 public:
  inline clusterCentroid(void)
    {
      Dimension       = 0;
      NumberOfData    = 0;
      OldNumberOfData = 0;
      DataCnt         = 0;
      DataMean        = NULL;
      DataMeanTmp     = NULL;
      ClusterID       = -1;
    }
  inline clusterCentroid(int D)
    {
      Dimension       = D;
      NumberOfData    = 0;
      OldNumberOfData = 0;
      DataCnt         = 0;
      DataMean        = new double[Dimension];
      DataMeanTmp     = new double[Dimension];
      ClusterID       = -1;
      for(int I=0;I<Dimension;++I)
	{
	  DataMean   [I] = 0.0;
	  DataMeanTmp[I] = 0.0;
	}	  
    }
  inline clusterCentroid(int D,double* Data)
    {
      Dimension       = D;
      NumberOfData    = -1;
      OldNumberOfData = 0;
      DataCnt         = 0;
      DataMean        = new double[Dimension];
      DataMeanTmp     = NULL;
      ClusterID       = -1;
      for(int I=0;I<Dimension;++I)
	{
	  DataMean[I] = Data[I];
	}	  
    }
  inline init(int D)
    {
      Dimension       = D;
      NumberOfData    = 0;
      OldNumberOfData = 0;
      DataCnt         = 0;
      DataMean        = new double[Dimension];
      DataMeanTmp     = new double[Dimension];
      ClusterID       = -1;
      for(int I=0;I<Dimension;++I)
	{
	  DataMean   [I] = 0.0;
	  DataMeanTmp[I] = 0.0;
	}	  
    }
  inline init(int D,double* Data)
    {
      Dimension       = D;
      NumberOfData    = -1;
      OldNumberOfData = 0;
      DataCnt         = 0;
      DataMean        = new double[Dimension];
      DataMeanTmp     = new double[Dimension];
      ClusterID       = -1;
      for(int I=0;I<Dimension;++I)
	{
	  DataMean[I] = Data[I];
	}	  
    }
  ~clusterCentroid(void)
    {
      delete DataMean;
      delete DataMeanTmp;
    }
  inline int clusterID(void)
    {
      return ClusterID;
    }
  inline int numberOfData(void)
    {
      return NumberOfData;
    }
  inline int oldNumberOfData(void)
    {
      return OldNumberOfData;
    }
  inline void clusterID(int CID)
    {
      ClusterID = CID;
    }
  inline void numberOfData(int ND)
    {
      NumberOfData = ND;
    }
  inline void oldNumberOfData(int ND)
    {
      OldNumberOfData = ND;
    }
  inline void input(double* Data)
    {
      for(int I=0;I<Dimension;++I)
	DataMeanTmp[I] += Data[I];
      DataCnt++;
    }
  inline void set(double* Data)
    {
      for(int I=0;I<Dimension;++I)
	{
	  DataMean[I] += Data[I];
	}
    }
  inline void reset(void)
    {
      DataCnt      = 0;
      OldNumberOfData = NumberOfData;
      for(int I=0;I<Dimension;++I)
	{
	  DataMeanTmp[I] = 0.0;
	}
    }
  inline double* position(void)
    {
      return DataMean;
    }
  inline void fprint(FILE* ClusterFile)
    {
      for(int I=0;I<Dimension;++I)
	{
	  fprintf(ClusterFile,"%10.5lf ",DataMean[I]);
	}
      fprintf(ClusterFile,"\n");
    }
  inline void print(void)
    {
      for(int I=0;I<Dimension;++I)
	{
	  cerr << form("%10.5lf ",DataMean[I]);
	}
      cerr << '\n';
    }
  void   calculate(int MeanNumberOfData);
  void   calculate(void);
  double distance(double* Data);
};

class clusterDistance
{
  double Distance;
  clusterCentroid* CentroidA;
  clusterCentroid* CentroidB;
 public:
  inline clusterDistance(clusterCentroid* A,clusterCentroid* B)
    {
      CentroidA = A;
      CentroidB = B;
      Distance = CentroidA->distance(CentroidB->position());
    }
  inline double distance(void)
    {
      return Distance;
    }
  inline clusterCentroid* centroidA(void)
    {
      return CentroidA;
    }
  inline clusterCentroid* centroidB(void)
    {
      return CentroidB;
    }
};

typedef clusterDistance* clusterDistanceP;

int clusterDistanceCompare(clusterDistance* A,clusterDistance* B);

class clusterSet
{  
  int               NumberOfData;
  int               NumberOfClusters;
  int               Dimension;
  int*              FieldId;
  dataSet*          DataSets;
  dataSetProperty*  DataSetProperty;
  clusterCentroid*  ClusterCentroids;
  dataSetProperty*  ClusterProperties;
 public:
  clusterSet(dataSetProperty* DSP);
  clusterSet(dataSetProperty* DSP, int NC);
  clusterSet(dataSetProperty* DSP, dataSet* DS,int NC);
  clusterSet(dataSetProperty* DSP, dataSet* DS);
  void initialCentroids(void);
  void calculateProperty(void);
  void writeData        (void);
  void writeData        (char* FileName);
  int  discriminate(double* Data);
  void calc(void);
  inline dataSetProperty* property(void)
    {
      return DataSetProperty;
    }
  inline int numberOfData(void)
    {
      return NumberOfData;
    }
  inline int numberOfClusters(void)
    {
      return NumberOfClusters;
    }
  inline clusterCentroid* centroid(int I)
    {
      return ClusterCentroids+I;
    }
  inline void input(int ClusterID,double* Data)
    {
      ClusterCentroids[ClusterID].input(Data);
    }
};

class pcompsort
{
  int    ClusterID;
  double PComp;
 public:
  inline pcompsort(int CID,double PC)
    {
      ClusterID = CID;
      PComp     = PC;
    }
  inline pcompsort(void)
    {
      ClusterID = -1;
      PComp     =  0.0;
    }
  inline int    clusterId(void)
    {
      return ClusterID;
    }
  inline double pcomp(void)
    {
      return PComp;
    }
};

typedef pcompsort* pcompsortP;

int clusterCmp(void* A,void* B);
void sortcluster(pcompsortP* Clusters, int NClusters);
