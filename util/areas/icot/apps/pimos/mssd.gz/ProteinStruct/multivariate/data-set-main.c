// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stream.h>
#include "data-set.h"

main(int ArgCnt,char** ArgVal)
{
  if(ArgCnt<2)
    {
      cerr << form("Too fiew arguments\nUsage\n%s DataSetPropertyFile",
		   ArgVal[0]);
      exit(1);
    }
  dataSetProperty DataSetProperty;
  DataSetProperty.get(ArgVal[1]);
  DataSetProperty.print();
}
