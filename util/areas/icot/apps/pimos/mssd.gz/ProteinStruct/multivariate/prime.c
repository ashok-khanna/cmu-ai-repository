// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stream.h>
#include <stdlib.h>

int prime(int Base)
{
  int PS = Base/2;
  char Prime[PS];
    int I, J, P;
    for (I = 0;I < PS; ++I)
      {
	Prime[I] = 1;
      }
  Prime[0] = 0;
  int PrimeBase;
  for (I = 0; I < PS; ++I)
    {
	if (Prime[I]) {
	    P = I * 2 + 1;
	    PrimeBase = P;
	    for (J = I; J < PS; J += P) {
		Prime[J] = 0;
	    }
	}
    }
  return PrimeBase;
}



main(int ArgCnt,char** ArgVal)
{
  if(ArgCnt<2)
    {
      cerr << "Too Fiew Arguments!\n";
      exit(1);
    }
  int Base = atoi(ArgVal[1]);
  cout << form("Base = %10d\tPrime Number = %10d\n",Base,prime(Base));
}
