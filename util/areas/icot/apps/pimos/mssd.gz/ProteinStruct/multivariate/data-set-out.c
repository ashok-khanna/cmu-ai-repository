// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <ctype.h>
#include <stdio.h>
#include <stream.h>
#include <string.h>
#include "data-set.h"

int dataSetProperty::put(void)
{
  char DataSetFileName[256];
  strcpy(DataSetFileName,FileName);
  strcat(DataSetFileName,".dsp");
  FILE* DataSetFile;
  if(NULL==(DataSetFile=fopen(DataSetFileName,"w")))
    {
      cerr << 
	form("Can't open Data Set Property File \"%s\"\n",DataSetFileName);
      return 0;
    }
  fprint(DataSetFile);
  fclose(DataSetFile);
  return 1;
}

int dataSetProperty::fprint(FILE* DataSetFile)
{
  fprintf(DataSetFile,"Data File Name      : %s\n",FileName);
  fprintf(DataSetFile,"Number of Components: %10d\n",NumberOfComponents);
  fprintf(DataSetFile,"Number of Data Sets : %10d\n",NumberOfData);
  fprintf(DataSetFile,"Total Variance      : %10.5lf\n",TotalVariance);
  fprintf(DataSetFile,"Field Number        :");
  for(int I=0;I<NumberOfComponents;++I)
    fprintf(DataSetFile," %10d",Components[I].fieldId());
  fprintf(DataSetFile,"\nMean                :");
  for(    I=0;I<NumberOfComponents;++I)
    fprintf(DataSetFile," %10lf",Components[I].mean());
  fprintf(DataSetFile,"\nMinimum             :");
  for(    I=0;I<NumberOfComponents;++I)
    fprintf(DataSetFile," %10lf",Components[I].minimum());
  fprintf(DataSetFile,"\nMaximum             :");
  for(    I=0;I<NumberOfComponents;++I)
    fprintf(DataSetFile," %10lf",Components[I].maximum());
  fprintf(DataSetFile,"\nStandard Deviation  :");
  for(    I=0;I<NumberOfComponents;++I)
    fprintf(DataSetFile," %10lf",Components[I].standardDeviation());
  fprintf(DataSetFile,"\nAxis Number         :");
  for(    I=0;I<NumberOfComponents;++I)
    fprintf(DataSetFile," %10d",I);
  fprintf(DataSetFile,"\nContribution Ratio  :");
  for(    I=0;I<NumberOfComponents;++I)
    fprintf(DataSetFile," %10.5lf",PrincipalComponents[I].contributionRatio());
  for(    I=0;I<NumberOfComponents;++I)
    {
      fprintf(DataSetFile,"\nVector Element %5d:",I);
      for(int J=0;J<NumberOfComponents;++J)
	fprintf(DataSetFile," %10.5lf",PrincipalComponents[J].axis(I));
    }
  fprintf(DataSetFile,"\n");
  return 1;
}
