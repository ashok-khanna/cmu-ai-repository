// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <stream.h>
#include <string.h>
#include "data-set.h"

main(int ArgCnt, char** ArgVal)
{
  if(ArgCnt<2)
    {
      cerr << form("Too fiew arguments\nUsage\n%s DataFilePropertyFile",
		   ArgVal[0]);
      exit(1);
    }
  dataSetProperty* DataSetProperty = new dataSetProperty(ArgVal[1]);
  int StdInFlag = 0;
  if(ArgCnt == 3)
    {
      if(0==strncmp(ArgVal[2],"-s",2))
	StdInFlag = 1;
    }

  FILE* DataFile;
  if(StdInFlag)
    DataFile = stdin;
  else
    {
      if(NULL==(DataFile=fopen(DataSetProperty->dataFileName(),"r")))
	{
	  cerr << form("Can't open Data File %s\n",
		       DataSetProperty->dataFileName());
	  exit(1);
	}
    }
  char BufferLine[1024];
  
  double Data [DataSetProperty->numberOfComponents()];
  double PComp[DataSetProperty->numberOfComponents()];
  while(fgets(BufferLine,1023,DataFile))
    {
      if(BufferLine[0]=='#') continue;
      DataSetProperty->readLine(BufferLine,Data);
      DataSetProperty->principalPosition(Data,PComp);
      for(int I=0;I<DataSetProperty->numberOfComponents();++I)
	{
	  printf(" %10.5lf",PComp[I]);
	}
      printf("\n");
    }
  fclose(DataFile);
  delete DataSetProperty;
}
