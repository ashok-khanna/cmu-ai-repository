// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdio.h>
#include <stream.h>
#include "data-set.h"

main(int ArgCnt,char** ArgVal)
{
  if(ArgCnt < 3)
    {
      cerr << form("Too fiew arguments\nUsage\n%s DataFile fied fied ...",
		   ArgVal[0]);
      exit(1);
    }

  int FieldId[ArgCnt-2];

  for(int I=0;I<ArgCnt-2;++I)
    FieldId[I] = atoi(ArgVal[I+2]);

  dataSetProperty* DataSetProperty
    = new dataSetProperty(ArgVal[1],ArgCnt-2,FieldId);
  DataSetProperty->put();
  delete DataSetProperty;
}
