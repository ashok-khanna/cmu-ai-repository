// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <stream.h>
#include "data-set.h"

main(int ArgCnt, char** ArgVal)
{
  if(ArgCnt<3)
    {
      cerr << form("Too fiew arguments\nUsage\n%s DataFilePropertyFile",
		   ArgVal[0]);
      exit(1);
    }
  dataSetProperty* DataSetProperty = new dataSetProperty(ArgVal[1]);
  FILE* DataFile;
  if(NULL==(DataFile=fopen(DataSetProperty->dataFileName(),"r")))
    {
      cerr << form("Can't open Data File %s\n",
		   DataSetProperty->dataFileName());
      exit(1);
    }
  double DivConst = atof(ArgVal[2]);
  char BufferLine[1024];
  
  double Data[DataSetProperty->numberOfComponents()];
  char   QuantizedData[DataSetProperty->numberOfComponents()+1];
  while(fgets(BufferLine,1023,DataFile))
    {
      if(BufferLine[0]=='#') continue;
      DataSetProperty->readLine(BufferLine,Data);
      DataSetProperty->quantize(Data,QuantizedData,DivConst);
      cout << QuantizedData << '\n';
    }
  delete DataSetProperty;
}
