// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <ctype.h>
#include <stdio.h>
#include <stream.h>
#include <string.h>
#include "data-set.h"

dataSetProperty::dataSetProperty
(
 char* DataFileName,
 int   NumberOfField,
 int*  FieldId
)
{
  FileName = new char[strlen(DataFileName)+1];
  strcpy(FileName,DataFileName);

  NumberOfComponents  = NumberOfField;
  NumberOfData        = 0;
  DataCnt             = 0;
  TotalVariance       = 0.0;
  CovarianceMatrix    = matrix(NumberOfComponents,NumberOfComponents);
  MeanOfComponents    = matrix(NumberOfComponents,1);
  Components          = new component[NumberOfComponents];
  PrincipalComponents = new principalComponent[NumberOfComponents];
  for(int I=0;I<NumberOfComponents;++I)
    {
      Components[I].fieldId(FieldId[I]);
    }
  for(    I=0;I<NumberOfComponents;++I)
    {
      PrincipalComponents[I].init(NumberOfComponents);
    }
  FILE* DataFile;
  if(NULL == (DataFile = fopen(FileName,"r")))
    {
      cerr << form("Can't open Data File \"%s\"\n",FileName);
      exit(1);
    }
  char BufferLine[1024];
  while(fgets(BufferLine,1023,DataFile))
    {
      if(BufferLine[0] == '#')
	continue;
      input(BufferLine);
    }
  fclose(DataFile);
  calculate();
}

void dataSetProperty::calculate(void)
{
  TotalVariance = 0.0;
  for(int I=0;I<NumberOfComponents;++I)
    PrincipalComponents[I].clear();
  NumberOfData = DataCnt;
  double ND    = double(DataCnt);
  matrix SS    =
    CovarianceMatrix/ND-MeanOfComponents*(MeanOfComponents.tr())/ND/ND;
  eigenvalue Eigen;
  Eigen = SS.eigen();
  for(    I=0;I<NumberOfComponents;++I)
    {
      TotalVariance += SS(I,I);
      Components[I].mean(MeanOfComponents(I,0)/ND);
      Components[I].standardDeviation(sqrt(SS(I,I)));
    }
  for(    I=0;I<NumberOfComponents;++I)
    {
      PrincipalComponents[I].contributionRatio(Eigen.value(I)/TotalVariance);
      double Parity = (Eigen(I,I)>0? 1.0:-1.0);
      for(int J=0;J<NumberOfComponents;++J)
	{
	  PrincipalComponents[I].axis(J,Parity*Eigen(I,J));
	}
    }
}

dataSetProperty::dataSetProperty(dataSetProperty& A, dataSetProperty& B)
{
  if(A.NumberOfComponents!=B.NumberOfComponents)
    {
      cerr << "Can't merge two Data Set Properties!\n";
      exit(1);
    }
  NumberOfComponents  = A.NumberOfComponents;
  NumberOfData        = A.NumberOfData + B.NumberOfData;
  TotalVariance       = 0.0;
  CovarianceMatrix    = A.CovarianceMatrix+B.CovarianceMatrix;
  MeanOfComponents    = A.MeanOfComponents+B.MeanOfComponents;
  Components          = new component[NumberOfComponents];
  PrincipalComponents = new principalComponent[NumberOfComponents];

  for(int I=0;I<NumberOfComponents;++I)
    {
      if(A.Components[I].fieldId()!=B.Components[I].fieldId())
	{
	  cerr << "Can't merge two Data Set Properties!\n";
	  exit(1);
	}
      Components[I].fieldId(A.Components[I].fieldId());
      Components[I].data(A.Components[I].minimum());
      Components[I].data(A.Components[I].maximum());
      Components[I].data(B.Components[I].minimum());
      Components[I].data(B.Components[I].maximum());
    }
  for(    I=0;I<NumberOfComponents;++I)
    {
      PrincipalComponents[I].init(NumberOfComponents);
    }
  calculate();
}
