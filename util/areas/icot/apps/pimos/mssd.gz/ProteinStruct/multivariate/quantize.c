// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stream.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "data-set.h"
#include "cluster.h"

main(int ArgCnt,char**ArgVal)
{
  if(ArgCnt<2)
    {
      cerr << "Too few arguments!\n";
      cerr <<
	"Usage:\n cluster [DSP file name]\n";
      exit(1);
    }

  dataSetProperty* DataSetProperty = new dataSetProperty(ArgVal[1]);
  clusterSet       ClusterSet(DataSetProperty);
  char   BufferLine[1024];
  double Data[DataSetProperty->numberOfComponents()];
  while(NULL!=gets(BufferLine))
    {
      if(BufferLine[0] != '#')
	{
	  DataSetProperty->readLine(BufferLine,Data);
	  printf("%c",ClusterSet.discriminate(Data)+'A');
	}
      else
	{
	  if(0==strncmp(BufferLine,"#Begin",6))
	    printf("<");
	  if(0==strncmp(BufferLine,"#End",4))
	    printf(">");
	}
    }
  printf("\n");
  delete DataSetProperty;
}
