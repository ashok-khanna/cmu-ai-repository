// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdlib.h>
#include <stream.h>
#include <string.h>
#include "data-set.h"
#include "cluster.h"

void clusterCentroid::calculate(void)
{
  NumberOfData = DataCnt;
  if(NumberOfData!=0)
    {
      for(int I=0;I<Dimension;++I)
	{
	  DataMean[I] = DataMeanTmp[I]/double(NumberOfData);
	}
      DataCnt      = 0;
    }
  for(int I=0;I<Dimension;++I)
    {
      DataMeanTmp[I] = 0.0;
    }
}

double clusterCentroid::distance(double* Data)
{
  double Distance2 = 0.0;
  for(int I=0;I<Dimension;++I)
    {
      double D   = DataMean[I] - Data[I];
      Distance2 += D*D;
    }
  return sqrt(Distance2);
}

int clusterDistanceCompare(clusterDistance* A,clusterDistance* B)
{
  return A->distance() > B->distance()?
    1:(A->distance() ==B->distance()?0:-1);
}

clusterSet::clusterSet(dataSetProperty* DSP)
{
  DataSetProperty = DSP;
  NumberOfData    = DataSetProperty->numberOfData();
  Dimension       = DataSetProperty->numberOfComponents();
  FieldId         = new int[Dimension];
  for(int I=0;I<Dimension;++I)
    FieldId[I] = DataSetProperty->fieldId(I);
  FILE*  ClusterCentroidsFile;
  char   ClusterCentroidsFileName[256];
  strcpy(ClusterCentroidsFileName,DataSetProperty->dataFileName());
  strcat(ClusterCentroidsFileName,".clust");
  if(NULL==(ClusterCentroidsFile=fopen(ClusterCentroidsFileName,"r")))
    {
      cerr <<
	form
	  (
	   "Can't open Cluster Centroids File %s\n",
	   ClusterCentroidsFileName
	   );
      exit(1);
    }
  char BufferLine[1024];
  if(NULL==fgets(BufferLine,1023,ClusterCentroidsFile))
    {
      cerr << "Can't read Cluster Centroids File\n";
      exit(1);
    }
  NumberOfClusters  = atoi(BufferLine+22);
  ClusterCentroids    = new clusterCentroid  [NumberOfClusters];
  for(    I=0;I<NumberOfClusters;++I)
    {

      if(NULL==fgets(BufferLine,1023,ClusterCentroidsFile))
	{
	  cerr << "Can't read Cluster Centroids File\n";
	  exit(1);
	}
      double Data[Dimension];
      int ComponentCnt = 0;
      DataSetProperty->readLine(BufferLine,Data);
      ClusterCentroids[I].init(Dimension,Data);
    }
  fclose(ClusterCentroidsFile);
}

clusterSet::clusterSet(dataSetProperty* DSP,int NC)
{
  DataSetProperty = DSP;
  NumberOfData    = DataSetProperty->numberOfData();
  Dimension       = DataSetProperty->numberOfComponents();
  NumberOfClusters= NC;
  FieldId         = new int[Dimension];
  for(int I=0;I<Dimension;++I)
    FieldId[I] = DataSetProperty->fieldId(I);
  ClusterCentroids= new clusterCentroid[NumberOfClusters];
  for(    I=0;I<NumberOfClusters;++I)
    ClusterCentroids[I].init(Dimension);
}


void clusterSet::calc(void)
{
  for(int I=0;I<NumberOfClusters;++I)
    ClusterCentroids[I].calculate();
  char   ClusterCentroidsFileName[256];
  strcpy(ClusterCentroidsFileName,DataSetProperty->dataFileName());
  strcat(ClusterCentroidsFileName,".reclust");
  cerr << form("File Name is %s\n",ClusterCentroidsFileName);
  writeData(ClusterCentroidsFileName);
}

clusterSet::clusterSet(dataSetProperty* DSP,dataSet* DS,int NC)
{
  DataSetProperty = DSP;
  DataSets        = DS;
  NumberOfData    = DataSetProperty->numberOfData();
  Dimension       = DataSetProperty->numberOfComponents();
  NumberOfClusters= NC;
  FieldId         = new int[Dimension];
  for(int I=0;I<Dimension;++I)
    FieldId[I] = DataSetProperty->fieldId(I);
  cerr << "NumberOfData =" << NumberOfData << '\n';
  ClusterCentroids= new clusterCentroid[NumberOfClusters];
  initialCentroids();
  int TotalDifference;

  for(    I=0;I<NumberOfClusters;++I)
    {
      ClusterCentroids[I].numberOfData(1);
      ClusterCentroids[I].reset();
    }
  do
    {
      for(int I=0;I<NumberOfClusters;++I)
	ClusterCentroids[I].reset();
      for(    I=0;I<NumberOfData;++I)
	{
	  double* Data      = DataSets[I].data();
	  int     ClusterId = discriminate(Data);
	  DataSets[I].clusterId(ClusterId);
	  ClusterCentroids[ClusterId].input(Data);
	}
      for(    I=0;I<NumberOfClusters;++I)
	{
	  ClusterCentroids[I].calculate();
	}
      TotalDifference = 0;
      for(    I=0;I<NumberOfClusters;++I)
	{
	  cerr << form
	    (
	     "Number of Data in Cluster %4d is %5d\n",
	     I,ClusterCentroids[I].numberOfData()
	     );
	  double Difference = 
	    double(
		   ClusterCentroids[I].oldNumberOfData()-
		   ClusterCentroids[I].numberOfData()
		   )*50.0/double(ClusterCentroids[I].numberOfData());
	  TotalDifference += (Difference*Difference>1.0? 1:0);
	}
      cerr << form("Converge %d\n",TotalDifference);
    }while(TotalDifference > NumberOfClusters/16);
  cerr << "Cluster centroids refined\n";
  writeData();
}

clusterSet::clusterSet(dataSetProperty* DSP,dataSet* DS)
{
  DataSetProperty = DSP;
  NumberOfData    = DataSetProperty->numberOfData();
  Dimension       = DataSetProperty->numberOfComponents();
  FieldId         = new int[Dimension];
  for(int I=0;I<Dimension;++I)
    FieldId[I] = DataSetProperty->fieldId(I);
  FILE*  ClusterCentroidsFile;
  char   ClusterCentroidsFileName[256];
  strcpy(ClusterCentroidsFileName,DataSetProperty->dataFileName());
  strcat(ClusterCentroidsFileName,".clust");
  if(NULL==(ClusterCentroidsFile=fopen(ClusterCentroidsFileName,"r")))
    {
      cerr <<
	form
	  (
	   "Can't open Cluster Centroids File %s\n",
	   ClusterCentroidsFileName
	   );
      exit(1);
    }
  char BufferLine[1024];
  if(NULL==fgets(BufferLine,1023,ClusterCentroidsFile))
    {
      cerr << "Can't read Cluster Centroids File\n";
      exit(1);
    }
  NumberOfClusters  = atoi(BufferLine+22);
  ClusterCentroids    = new clusterCentroid  [NumberOfClusters];
  for(    I=0;I<NumberOfClusters;++I)
    {

      if(NULL==fgets(BufferLine,1023,ClusterCentroidsFile))
	{
	  cerr << "Can't read Cluster Centroids File\n";
	  exit(1);
	}
      double Data[Dimension];
      int ComponentCnt = 0;
      DataSetProperty->readLine(BufferLine,Data);
      ClusterCentroids   [I].init(Dimension,Data);
    }
  fclose(ClusterCentroidsFile);
  for(    I=0;I<DataSetProperty->numberOfData();++I)
    {
      double*  Data = DataSets[I].data();
      int ClusterId = discriminate(Data);
      ClusterProperties[ClusterId].input(Data);
    }
  for(    I=0;I<NumberOfClusters;++I)
    {
      ClusterProperties[I].calculate();
      ClusterProperties[I].print();
    }
}

void clusterSet::writeData(void)
{
  char   ClusterCentroidsFileName[256];
  strcpy(ClusterCentroidsFileName,DataSetProperty->dataFileName());
  strcat(ClusterCentroidsFileName,".clust");
  writeData(ClusterCentroidsFileName);
}

void clusterSet::writeData(char* FileName)
{
  FILE*  File;
  if(NULL==(File=fopen(FileName,"w")))
    {
      cerr <<
	form
	  (
	   "Can't open Cluster Centroids File %s\n",
	   FileName
	   );
      exit(1);
    }
  fprintf(File,"# Number of Clusters = %d\n",NumberOfClusters);

  pcompsortP PCompSort[NumberOfClusters];
  for(int I=0;I<NumberOfClusters;++I)
    {
      double PC[DataSetProperty->numberOfComponents()];
      DataSetProperty->principalPosition(ClusterCentroids[I].position(),PC);
      PCompSort[I] = new pcompsort(I,PC[0]);
    }
  sortcluster(PCompSort,NumberOfClusters);

  for(    I=0;I<NumberOfClusters;++I)
    {
      int K = PCompSort[I]->clusterId();
      DataSetProperty->
	fprintData(File,ClusterCentroids[K].position());
    }
  fclose(File);
}

int clusterSet::discriminate(double* Data)
{
  double DistanceMin = -1.0;
  int    ClusterId   = -1;
  for(int I=0;I<NumberOfClusters;++I)
    {
      double Distance;
      Distance = ClusterCentroids[I].distance(Data);
      if(DistanceMin>=0.0)
	{
	  if(Distance < DistanceMin)
	    {
	      DistanceMin = Distance;
	      ClusterId   = I;
	    }
	}
      else
	{
	  DistanceMin = Distance;
	  ClusterId   = I;
	}
    }
  return ClusterId;
}

void clusterSet::initialCentroids(void)
{
  double InitialDiv = 1.0;

  double InitDistance  =
    sqrt(DataSetProperty->totalVariance())
      /pow(NumberOfClusters,1.0/Dimension)/InitialDiv;

  cerr << "InitDistance =" << InitDistance << '\n';

  while(1)
    {
      int     K = 0;
      int     NumberOfClustersFound = 0;
      for(int I=0;I<NumberOfClusters;++I)
	{
	  double* DataNow;
	  while(K < NumberOfData)
	    {
	      double* DataNow     = DataSets[K].data();
	      double  DistanceMin = InitDistance*2.0;
	      for(int J=0;J<I;++J)
		{
		  double  DistanceNow = ClusterCentroids[J].distance(DataNow);
		  if(DistanceMin > DistanceNow)
		    DistanceMin = DistanceNow;
		  if(DistanceMin < InitDistance)
		    break;
		}
	      if(DistanceMin > InitDistance)
		{
		  ClusterCentroids[I].init(Dimension,DataNow);
		  ClusterCentroids[I].numberOfData(1);
		  NumberOfClustersFound++;
		  K++;
		  break;
		}
	      else
		{
		  K++;
		}
	    }
	  cerr << "ClusterID = " << I <<'\n';
	}
      if(NumberOfClustersFound == NumberOfClusters)
	break;
      else
	cerr << "no more clusters!\n";
      InitDistance*=sqrt(1.0/2.0);
    }
  cerr << "Initial clusters generated.\n";
}

int clusterCmp(void* A,void* B)
{
  if(((pcompsort*)A)->pcomp()<((pcompsort*)B)->pcomp())
    return -1;
  else if(((pcompsort*)A)->pcomp()==((pcompsort*)B)->pcomp())
    return 0;
  else
    return 1;
}

void sortcluster(pcompsortP* Clusters, int NClusters)
{
  gsort((void**)Clusters,NClusters,clusterCmp);
}
