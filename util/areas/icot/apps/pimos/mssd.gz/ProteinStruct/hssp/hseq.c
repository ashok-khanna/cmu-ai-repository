// ---------------------------------------------------------- 
//  (C)1994 Institute for New Generation Computer Technology 
//      (Read COPYRIGHT for detailed information.) 
//-----------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <stream.h>

main()
{
  char BuffLine [1024];
  char ID[7];
  char ChainID = '_';
  char AminoSeq [1024];
  char Secondary[1024];

  int I;
  while(gets(BuffLine))
    {
      if(BuffLine[0] != 'B')
	{
	  cerr << "Invalid Data!\n";
	  exit(1);
	}
      else if(BuffLine[0] == 'E')
	continue;
      strncpy(ID,BuffLine+6,4);
      ID[4] = '_';
      ID[5] = '\0';
      gets(BuffLine);
      ChainID = BuffLine[12];
      I = 0;
      AminoSeq [I]  = '<';
      Secondary[I++]= '<';
      AminoSeq [I]  = (islower(BuffLine[14])?'C':BuffLine[14]);
      Secondary[I++]= tolower(BuffLine[17]);
      while(gets(BuffLine))
	{
	  if(BuffLine[0] == 'E')
	    {
	      AminoSeq [I]  = '>';
	      Secondary[I++]= '>';
	      AminoSeq [I] = '\0';
	      Secondary[I] = '\0';
	      printf("%s",ID);
	      if(ChainID == ' ')
		{
		  printf("#_Seq:");
		}
	      else
		{
		  printf("%c_Seq:",ChainID);
		}
	      puts(AminoSeq);
	      printf("%s",ID);
	      if(ChainID == ' ')
		{
		  printf("#_2nd:");
		}
	      else
		{
		  printf("%c_2nd:",ChainID);
		}
	      puts(Secondary);
	      I = 0;
	      break;
	    }
	  if(BuffLine[14]=='!')
	    {
	      gets(BuffLine);
	      if(BuffLine[12]!=ChainID)
		{
		  AminoSeq [I]  = '>';
		  Secondary[I++]= '>';
		  AminoSeq [I] = '\0';
		  Secondary[I] = '\0';
		  printf("%s",ID);
		  if(ChainID == ' ')
		    {
		      printf("#_Seq:");
		    }
		  else
		    {
		      printf("%c_Seq:",ChainID);
		    }
		  puts(AminoSeq);
		  printf("%s",ID);
		  if(ChainID == ' ')
		    {
		      printf("#_2nd:");
		    }
		  else
		    {
		      printf("%c_2nd:",ChainID);
		    }
		  puts(Secondary);
		  ChainID = BuffLine[12];
		  I = 0;
		  AminoSeq [I]  = '<';
		  Secondary[I++]= '<';
		  AminoSeq [I]  = (islower(BuffLine[14])?'C':BuffLine[14]);
		  Secondary[I++]= tolower(BuffLine[17]);
		  continue;
		}
	      else
		{
		  AminoSeq [I]  = '>';
		  Secondary[I++]= '>';
		  AminoSeq [I]  = '<';
		  Secondary[I++]= '<';
		}
	    }
	  else if(BuffLine[12]!=ChainID)
	    {
	      AminoSeq [I]  = '>';
	      Secondary[I++]= '>';
	      AminoSeq [I] = '\0';
	      Secondary[I] = '\0';
	      printf("%s",ID);
	      if(ChainID == ' ')
		{
		  printf("#_Seq:");
		}
	      else
		{
		  printf("%c_Seq:",ChainID);
		}
	      puts(AminoSeq);
	      printf("%s",ID);
	      if(ChainID == ' ')
		{
		  printf("#_2nd:");
		}
	      else
		{
		  printf("%c_2nd:",ChainID);
		}
	      puts(Secondary);
	      ChainID = BuffLine[12];
	      I = 0;
	      AminoSeq [I]  = '<';
	      Secondary[I++]= '<';
	      AminoSeq [I]  = (islower(BuffLine[14])?'C':BuffLine[14]);
	      Secondary[I++]= tolower(BuffLine[17]);
	      continue;
	    }
	  AminoSeq [I]   = (islower(BuffLine[14])?'C':BuffLine[14]);
	  Secondary[I++] = tolower(BuffLine[17]);
	}
    }
}

/*
0123456789012345678901234567890123456789012345678901234567890123456789
BEGIN 1AAI
     1    1 A I              0   0  160    3   14  I I   V
     2    2 A F        +     0   0   39    3   69  F F   A
     3    3 A P        +     0   0  102    3   42  P P   T
     4    4 A K  S    S-     0   0  132    3   38  K K   N
     5    5 A Q        -     0   0  152    4    0  Q Q   QQ
     6    6 A Y        -     0   0   14    4   68  Y Y   DD
     7    7 A P        -     0   0   53    4   43  P P   QR
     8    8 A I  E     +a   59   0A  99    4   39  I I   VP
     9    9 A I  E     -a   60   0A  14   11   10  I I   IIVVVVVVI
    10   10 A N  E     -a   61   0A  92   11   40  N N   KKSSNSRST
    11   11 A F  E     -a   62   0A  11   11    0  F F   FFFFFFFFF
*/
