/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
/* -*- C++ -*- */
#ifndef _prtalk_h_
#define  _prtalk_h_

#include <string.h>

/* prtalk.h */
#ifndef _object_h_
#include "../3dview/object.h"
#endif

#ifndef _node_h_
#include "../3dview/node.h"
#endif

#ifndef _pdb_h_
#include "pdb.h"
#endif
#ifndef _atom_h_
#include "atom.h"
#endif
#ifndef _method_h_
#include "method.h"
#endif
/* ������褹�륪�֥������� */
/* Begin Class Definition sphere */
#define SPHERE_WORD_SIZE 2

class globe  : public object
{
 protected:
  char* chainNo;
  int aminoNo;
  int sphereFlag;
  node obj[SPHERE_WORD_SIZE];
 public:
/* Function Defined At object.c */
  globe();
  virtual void Close();
  virtual header* Reference(int id);
  void Draw();
  virtual void CopySplitMember();
};
/* End Class Definition sphere */

extern int sphere_depth;
#define DEFAULT_DEPTH 10
#endif /* _prtalk_h_ */


