/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#ifndef _method_h_
#define _method_h_
#include "pdb.h"

int  ObjectExistence(char*);
void MakeGroupObject(char*);
void MakeSphereObject(char*);
void MakePipe0Object(char*);
void MakeLineObject(char*);
void MakePolygonObject(char*);
void MakeListObject(char*);
void MakeTextObject(char*);
void InsertList(char*, coodinate A, coodinate B);
void MoveObject(char*, double, double, double);
void FromObject(char*, double, double, double);
void ToObject(char*, double, double, double);
void RadiusObject(char*, const char*);
void DepthObject(char*, const char*);
void BottomObject(char*, char*);
void TopObject(char*, char*);
void ColorObject(char*, const char*);
void StringObject(char*, char*);
void PointsObject(char*, char*);
void DrawAll(char*);
void HideAll(char*);
void DrawObject(char*);
void HideObject(char*);
void IntoGroup(char*);
void PushGroup(char*);
void PopGroup(void);
void NurbsObject(char*);

#ifdef MOTIF
void GroupList(char *name, int flag);
ObjectTypeTag GetObjectType(char *name);
void InGroup(char* name);
char* OutGroup(void);
void LocationValue(char* cname, char* x, char* y, char* z);
void RotationValue(char* cname, char* x, char* y, char* z);
void SphereValue(char* cname, char* x, char* y);
void ColorValue(char* cname, char* x, char* y, char* z);
void SpecularValue(char* cname, char* red, char* green, char* blue);
float AlphaValue(char* cname);
float ShinessValue(char* cname);
float FloatValue(char* cname);
int IntegerValue(char* cname);
char* StringValue(char* cname);
#endif

#endif 
