/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#ifndef _sheet_h_
#define _sheet_h_

#include "pdb.h"
#include "atom.h"

#ifndef _header_h_
#include "../3dview/header.h"
#endif _header_h_
#ifndef _location_h_
#include "../3dview/location.h"
#endif _location_h_
#ifndef _node_h_
#include "../3dview/node.h"
#endif

class sheet :public object
{
 public:
  sheet(void);
  virtual void Close();
  header* Reference(int id);
  void Draw();
  virtual void CopySplitMember();
};
#endif /* eof ifndef _sheet_h_ */
