/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#ifndef _bond_h_
#define _bond_h_

#include "pdb.h"
#include "atom.h"

#ifndef _header_h_
#include "../3dview/header.h"
#endif _header_h_
#ifndef _location_h_
#include "../3dview/location.h"
#endif _location_h_
#ifndef _node_h_
#include "../3dview/node.h"
#endif

class bond :public object
{
  double dx,dy,dz, xtheta,ytheta, cx,cy,cz;
  coodinate first, second;
 public:
  bond(void);
  virtual void Close();
  header* Reference(int id);
  void Draw();
  virtual void CopySplitMember();
  void From(location* O);
  void To(location* O);
};
#endif /* eof ifndef _bond_h_ */
