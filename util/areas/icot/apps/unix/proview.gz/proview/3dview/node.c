/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#include <stdio.h>
#include <stdlib.h>
#include "node.h"
#include "hash.h"
#include "symbol.h"
/* node.c */
#define TRUE 1
#define FALSE 0
//hash hash_table(2014,2179,(48*1024));
hash hash_table(4096,4096,(48*1024));

header*  node::Parent()
{
  return parent;
}

void  node::Parent(header* p)
{
  parent = p;
}
int  node::IsUpdate()
{
  return update_flag;
}

header* node::Value()
/* Refer node object's value */
{ 
  update_flag = FALSE;
  return value_object;
}

int node::IsGroup()
{
  return group_flag;
}

void node::Value(header* h)
// {}
// void node::Value(header* h)
// {}
{
  value_object = h;
  update_flag = TRUE;
  if (h == NULL) {
    group_flag = FALSE;
    return;
  }

  if(h->Type()== GROUP_OBJ) group_flag = TRUE;
  else group_flag = FALSE;
}

 void  node::Close()
{
  ref_c--;
  if (ref_c == 0) {
    value_object->Close();
    free(this);
  }
}
 node::node() 
// {}
// void node::node() 
// {}
{
  type = NODE_OBJ;
  name = (char*)0;
  value_object = (header*)0;
  parent = (header*)0;
  update_flag = FALSE;
  sym_id = sym_node;
  group_flag = FALSE;
}

const char* node::Name()
// {}
// const char* node::Name()
// {}
{
  return name;
}

int node::Id() 
{
  return id;
}

void node::Id(int i) 
{
  id = i;
  name = (hash_table.idWord(id));
}

void node::Name(const char* n)
// {}
// void node::Name(const char* n)
// {}
{
  id = hash_table.wordId((char*)n);
  name = (hash_table.idWord(id));
}
