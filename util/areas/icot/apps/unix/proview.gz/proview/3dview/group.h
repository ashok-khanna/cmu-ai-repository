/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#ifndef _group_h_
#define _group_h_

#ifndef _object_h_
#include "object.h"
#endif

/* Begin Class Definition group  */
class group : public object
{
  int no_of_obj;
  header*  first_object;
  header*  last_object;
  header*  before;
  header* parent;
  public:
/* Function Defined At object.c */
  group();
  header* Search_and_Create(char* n);
  header* Search_and_Create(int id);
  header* First();
  header* Last();
  header* Parent();
  void  DrawStateAll(DrawStatus t);
  void  First(header* f);
  void  Last(header* l);
  void  Parent(header* p);
  int   NoOfObjects();
  object* Element(int n);
  void Copy(header* obj);
  void Close();
  void Draw();

/* virtual Function. Look object.h */
  void Scale(double s);

#ifdef _UN_USE_YACC_
#include "accept.h"
#include "reduce.h"
#endif
};

#define GROUP_STACK_SIZE 96

/* End Class Definition group */
#endif
