/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#ifndef _messagetag_h_
#define _messagetag_h_

typedef unsigned int MethodID;

#define METHOD_ALPHA        0
#define METHOD_INSERT       1
#define METHOD_CAR          2
#define METHOD_CDR          3
#define METHOD_ELEMENT      4
#define METHOD_APPEND       5
#define METHOD_QUIT         6
#define METHOD_VALUE        7
#define METHOD_IS           8
#define METHOD_BIND         9
#define METHOD_SHINES       10
#define METHOD_SPECULER     11
#define METHOD_COLOR        12
#define METHOD_TO           13
#define METHOD_FROM         14
#define METHOD_ANTIALIASES  15
#define METHOD_SMOOTHS      16
#define METHOD_NURBS        17
#define METHOD_DELETE       18
#define METHOD_MOVE         19
#define METHOD_LOCATION     20
#define METHOD_ROTATION     21
#define METHOD_ROTATE       22
#define METHOD_DRAW         23
#define METHOD_DRAW_ALL     24
#define METHOD_HIDE         25
#define METHOD_HIDE_ALL     26
#define METHOD_WIRE         27
#define METHOD_WIRE_ALL     28
#define METHOD_COPY         29
#define METHOD_SCALE        30
#define METHOD_INTO         31
#define METHOD_PUSH         32
#define METHOD_POP          33
#define METHOD_UP           34
#define METHOD_SYNC         35
#define METHOD_TRANSFORM    36

#ifdef _DISABLE_GL_
#define METHOD_RIBBON_ALL   37
#define METHOD_DIVIDE       38
#define METHOD_GLOBE        39
#define METHOD_RIBBON_SHEET 40
#define METHOD_RIBBON_TURN  41
#define METHOD_RIBBON_HELIX 42
#define METHOD_WIRED        43
#define METHOD_SEQ_NO       44
#define METHOD_C_ALPHA      45
#define METHOD_END          (METHOD_C_ALPHA+1)
#else
#define METHOD_END          (METHOD_TRANSFORM+1)
#endif

#endif /* _messagetag_h_ */
