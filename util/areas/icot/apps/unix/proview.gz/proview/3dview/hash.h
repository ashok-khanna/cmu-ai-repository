/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#ifndef _hash_h_
#define _hash_h_
class wordTable
{
  int Offset;
  int Next ;
 public:
  wordTable();
  inline void offset(int OS){Offset = OS;}
  inline void next  (int N) {Next   =  N;}
  inline int  offset(void)  {return Offset;}
  inline int  next  (void)  {return Next;}
};

class hash
{
  wordTable* WordTable;
  int*       HashTable;
  char*      String;
  int        WordIdNew;
  int        OffsetNew;
  int        HashMax;
  int        WordMax;
  int        StrgMax;
 public:
  virtual int        hashFn(char* Word);
  hash(int WMax,int HMax,int SMax);
  hash();
  virtual ~hash(void);
  char* idWord(int Id);
  inline int wordLast(void) {return WordIdNew-1;}
  int   wordId(char*);
  void init();
};

extern hash hash_table;
#endif
