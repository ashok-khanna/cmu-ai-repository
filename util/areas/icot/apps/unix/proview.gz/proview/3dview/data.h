/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#ifndef _data_h_
#define  _data_h_
#ifndef _header_h_
#include "header.h"
#endif 

/*************************************************************************

��ƥ�륪�֥������ȥ��饹

�������¿���ʸ����cons(�ꥹ��)�Υǡ�����¤�Ǥ��롣

�Ѿ��ط�
                        |class header   |
                              |
                              +
         +--------------------+----------------------+-------------+
 |class fixed_number |  |class float_number |  |class string| |class cons|

*************************************************************************/

class fixed_number :public header {
  int val;
 public:
  void Close();
  fixed_number();
  void Print();
  void Value(int v);
  int  Value();
};

class float_number :public header {
  double val;
 public:
  void Close();
  float_number();
  void Print();
  void Value(double v);
  double Value();
};

class string :public header {
  int id;
  char* val;
 public:
  string();
  void Close();
  void Id(int i);
  int Id();
  void Print();
  char*  Value();
};

class cons :public header {
  header* car;
  header* cdr;
 public:
  cons();
  void Print();
  void Close();
  header* Car();
  header* Cdr();
  void  Car(header* t);
  void  Cdr(header* l);
#ifdef _UN_USE_YACC_
#include "accept.h"
#include "reduce.h"
#endif
};

inline header* create_integer(int i)
// {}
// �������֥������Ȥ�����
// {}
{
  fixed_number* fxp;
  fxp = new fixed_number [1];
  fxp->Next((header*)0);
  fxp->Value(i);
  return (header*)fxp;
}

inline header* create_float(float f)
// {}
// �¿����֥������Ȥ�����
// {}
{
  float_number* flp;
  flp = new float_number [1];
  flp->Next((header*)0);
  flp->Value(f);
  return (header*)flp;
}

inline header* create_string(int sval)
// {}
// ʸ���󥪥֥������Ȥ�����
// {}
/* sval is hash code*/
{
  string* sp;
  sp = new string [1];
  sp->Next((header*)0);
  sp->Id(sval);
  return (header*)sp;
}

extern header* minus(header* a);
extern header* mul(header* a,header* b);
extern header* sub(header* a,header* b);
extern header* add(header* a,header* b);
extern header* dev(header* a,header* b);
extern float numerical2float(header* obj,char* err_msg_str);
extern int numerical2int(header* obj,char* err_msg_str);
extern char* string2cstr(header* obj,char* err_msg_str);

#endif /* _data_h_*/
