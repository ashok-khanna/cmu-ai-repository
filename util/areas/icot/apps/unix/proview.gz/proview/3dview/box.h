/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
/* -*-C++-*- */

#ifndef _box_h_
#define _box_h_
/* box.h */
#ifndef _object_h_
#include "object.h"
#endif
/* Ȣ���������֥������� */
/* Begin Class Definition box */

class box  : public object
{
 private:
  float   dx,dy,dz;
 public:
  box();
  void Close();
  void From(location* l);
  void To(location* l);

/* virtual Function. Look object.h */
  void Scale(double s);
  void Draw();

#ifdef _UN_USE_YACC_
#include "accept.h"
#include "reduce.h"
#endif
} ;

/* End Class Definition box */
#endif /* _box_h_ */
