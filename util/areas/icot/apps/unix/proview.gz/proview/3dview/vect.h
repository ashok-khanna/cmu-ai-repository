/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#ifndef _vect_h_
#define _vect_h_

extern void vcross(const float *, const float *, float *);
extern float vlength(const float *);
extern void vnormal(float *);
extern void vcopy(const float *v1, float *v2);
extern void vset(float *v, float x, float y, float z);

#endif 

