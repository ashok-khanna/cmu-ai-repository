/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
extern int group_sp;
extern void initialize_primitive();
extern void initialize_object();
extern void initialize_cylinder();
extern void initialize_sphere();
extern void initialize_material();
extern void initialize_symbol();
extern void initialize_text_font();

void initialize()
{
  group_sp = 0;
  initialize_symbol();
  initialize_object();
  initialize_cylinder();
  initialize_sphere();
  initialize_material();
  initialize_primitive();
  initialize_text_font();
}
