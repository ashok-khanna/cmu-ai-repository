/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#ifndef _symbol_h_
#define _symbol_h_
#ifndef _data_h_
#include "data.h"
#endif

extern header* (*new_instance[])(void);

/* This header file is the link header to hash value of strings
for preengagement words.
�ܥإå��ϡ�ͽ���Ȥʤ�ʸ����Υϥå����ͤΥ�󥯥إå��Ǥ��롣 */

/* Object name */
extern int sym_notinit;
extern int sym_location;
extern int sym_integer;
extern int sym_float;
extern int sym_string;
extern int sym_list;
extern int sym_group;
extern int sym_sphere;
extern int sym_line;
extern int sym_dot;
extern int sym_box;
extern int sym_pipe0;
extern int sym_pipe1;
extern int sym_mesh;
extern int sym_cylinder0;
extern int sym_cylinder1;
extern int sym_conic;
extern int sym_cone;
extern int sym_pillar0;
extern int sym_pillar1;
extern int sym_segment;
extern int sym_light;
extern int sym_text;
extern int sym_material;
extern int sym_group;
extern int sym_node;

/* Message name to an object */
extern int sym_m_alpha;
extern int sym_m_value;
extern int sym_m_element;
extern int sym_m_car;
extern int sym_m_cdr;
extern int sym_m_insert;
extern int sym_m_append;
extern int sym_m_moves;
extern int sym_m_antialiases;
extern int sym_m_smooths;
extern int sym_m_is;
extern int sym_m_bind;
extern int sym_m_sync;
extern int sym_m_quit;
extern int sym_m_nurbs;
extern int sym_m_delete;
extern int sym_m_shines;
extern int sym_m_speculer;
extern int sym_m_colors;
extern int sym_m_rotate;
extern int sym_m_rotation;
extern int sym_m_draw;
extern int sym_m_hide;
extern int sym_m_wire;
extern int sym_m_scale;
extern int sym_m_location;
extern int sym_m_to;
extern int sym_m_from;
extern int sym_m_copy;
extern int sym_m_transform;
extern int sym_m_push;
extern int sym_m_pop;
extern int sym_m_into;
extern int sym_m_up;
extern int sym_m_drawall;
extern int sym_m_hideall;
extern int sym_m_wireall;

#ifdef _DISABLE_GL_
/* Protein-Talk message name */
extern int sym_atom;
extern int sym_bond;
extern int sym_helix;
extern int sym_sheet;
extern int sym_m_ribbon;
//extern int sym_m_helix;
//extern int sym_m_sheet;
extern int sym_m_turn;
extern int sym_m_wired;
extern int sym_m_calpha;
extern int sym_m_seqno;
extern int sym_m_divide;
#endif

/* Function name to a number object */
extern int sym_f_sin;
extern int sym_f_asin;
extern int sym_f_cos;
extern int sym_f_acos;
extern int sym_f_tan;
extern int sym_f_atan;
extern int sym_f_log;
extern int sym_f_exp;
extern int sym_f_int;

/* Member name of an object */
extern char* object_member_color;
extern char* object_member_radius;
extern char* object_member_depth;
extern int sym_om_color;
extern int sym_om_radius;
extern int sym_om_depth;

extern char*  object_member_width;
extern char*  object_member_style;
extern char*  object_member_points;

extern int  sym_om_width;
extern int  sym_om_style;
extern int  sym_om_points;

extern char* object_member_top;
extern char* object_member_bottom;
extern char* object_member_height;
extern char* object_member_division;
extern int  sym_om_top;
extern int  sym_om_bottom;
extern int  sym_om_height;
extern int  sym_om_division;

extern char* object_member_string;
extern int  sym_om_string;
extern int  sym_om_font;
extern int  sym_om_size;
extern int  sym_om_string;

#ifdef _DISABLE_GL_
extern char* object_member_resID;
extern int  sym_om_resID;
#endif

/* argument parameter */

extern char*  param_on;
extern char*  param_off;
extern int sym_param_on;
extern int sym_param_off;
extern int sym_new0;
extern int sym_new1;
extern string* string_obj_on;
extern string* string_obj_off;

#endif
