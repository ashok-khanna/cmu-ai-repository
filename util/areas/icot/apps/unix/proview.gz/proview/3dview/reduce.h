/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
/*global prottype macro for class x */
#define PReduce(x) virtual header* x::Reduce(MethodID mid,header* args) 
/*internal prottype*/
virtual header* Reduce(MethodID mid,header* args);
