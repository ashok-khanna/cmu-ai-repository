/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#ifndef _sphere_h_
#define  _sphere_h_

/* sphere.h */
#ifndef _object_h_
#include "object.h"
#endif

#ifndef _node_h_
#include "node.h"
#endif
/* ������褹�륪�֥������� */
/* Begin Class Definition sphere */
#define SPHERE_WORD_SIZE 2

class sphere  : public object
{
 protected:
  int depth;
  float radius;
  node obj[SPHERE_WORD_SIZE];
 public:
  sphere();
  inline void Depth(int a){depth = a;}
  inline void Radius(float a){radius = a;}
  int Depth(void);
  float Radius(void);

/* Function Defined At object.c */
  void Close();
  header* Reference(int id);
  void CopySplitMember();

/* virtual Function. Look object.h */
  void Scale(double s);
  void Draw();

#ifdef _UN_USE_YACC_
#include "accept.h"
#include "reduce.h"
#endif
};
/* End Class Definition sphere */

inline int sphere::Depth(void){
  return depth;
}
inline float sphere::Radius(void){
  return radius;
}
extern int sphere_depth;
#define DEFAULT_DEPTH 10
#endif /* _sphere_h_ */

