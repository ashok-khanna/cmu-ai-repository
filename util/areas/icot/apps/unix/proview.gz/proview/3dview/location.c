/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#include <stdio.h>
#include <sys/types.h>
#include "location.h"
#include "symbol.h"
extern "C" {
#include <malloc.h>
};

location::location()  :rotation()
{
#ifdef DEBUG
  fprintf(stderr,"this (%x) rc %d void location::location()\n",(unsigned int) this,ref_c);
#endif
 type = DAT_LOCATION;
 sym_id = sym_location;
}

location::location(double a,double b,double c) :rotation(a,b,c)
{
#ifdef DEBUG
  fprintf(stderr,"this (%x) rc %d void location::location(double %f,double %f,double %f)\n",
	  (unsigned int) this,ref_c,a,b,c);
#endif
 type = DAT_LOCATION;
 sym_id = sym_location;
}

void location::Print()
{
  fprintf(stderr,"{%f,%f,%f}",value[0],value[1],value[2]);
}
void location::Close()
{
#ifdef DEBUG
  fprintf(stderr,"this (%x) rc %d void location::Close()\n",(unsigned int) this,ref_c);
#endif
  header::Close();
  if (header::Ref() == 0) {
    free(this);
  }
}










