/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
/*global prottype macro for class x */
#define PAccept(x) virtual int x::Accept(int lex_code,MethodID mid)
/*internal prottype*/
virtual int Accept(int lex_code,MethodID mid);
