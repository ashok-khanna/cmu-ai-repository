/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#ifndef _trackball_h_
#define _trackball_h_

extern void trackball(float q[4], float p1x, float p1y, float p2x, float p2y);
extern void add_quats(float *q1, float *q2, float *dest);
extern void build_rotmatrix(float m[4][4], float q[4]);
extern void axis_to_quat(float a[3], float angle, float q[4]);

#define add_eulers add_quats
#define axis_to_euler axis_to_quat
#endif
