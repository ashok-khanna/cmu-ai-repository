/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#ifndef _message_h_
#define _message_h_
#ifndef _header_h_
#include "header.h"
#endif

#ifndef _messagetag_h_
#include "messagetag.h"
#endif


class message {
  MethodID msg;
  header* arg;
  message* next;
 public:
  message();
   void Type(MethodID m);
   MethodID Type();
   void Arg(header* h);
   header* Arg();
   void Next(message* m);
   message* Next();
};
extern char* MsgId_2_str(MethodID id);
#endif /* _message_h_ */
