/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#include <stdlib.h>
#include <stdio.h>
#ifndef _DISABLE_GL_
#include <gl.h>
#endif

#include "exit.h"

extern char line_buffer[BUFSIZ];

int line_number;
void yyerror(const char* str)
{
  fprintf(stderr,"%s\n",line_buffer);
  fprintf(stderr,"%s : %d\n",str,line_number);
  error_exit();
}
