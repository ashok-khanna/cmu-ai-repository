/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
typedef enum  {
  Not_Initialized,
  Device_Opened
} LexInputStatus;

class lex_input {
  char buff[BUFSIZ];
  int file_discript;
  LexInputStatus state;
 public:
  int open ();
  read ();
}
