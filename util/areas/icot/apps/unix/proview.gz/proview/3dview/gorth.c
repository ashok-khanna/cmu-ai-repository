/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#include <stdio.h>
#include "gorth.h"
#include "color_obj.h"

#ifndef _DISABLE_GL_
#include <gl/gl.h>
#endif

void graphic_orth::Orth()
{
#ifndef _DISABLE_GL_
  ortho(left,right,bottom,top,near,far);
#endif
}
void  graphic_orth::Transform(float l,float r,float b,float t,float n,float f)
{
  left =  l;
  right =  r;
  bottom =  b;
  top =   t;
  near  =  n;
  far  =  f;
}
 graphic_orth::graphic_orth()
{
  type = GORTH_OBJ;
  left =  (-1.0);
  right =  (1.0);
  bottom =  (-1.0);
  top =   (1.0);
  near  =  (-5.0);
  far  =  (5.0);
}
