/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#ifndef _ui_h_
#define _ui_h_

#ifndef _event_h_
#include "event.h"
#endif

#ifndef _trackball_h_
#include "trackball.h"
#endif

#ifndef _vect_h_
#include "vect.h"
#endif

extern void ui(void (*fn)(float *, float *));
extern void ui_active(int);
extern void ui_exit(long event,short val);
extern int ui_noisy, ui_quiet;
#endif
