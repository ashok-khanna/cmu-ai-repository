/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
/* -*- C++ -*- */
#ifndef _location_h_
#define _location_h_

#ifndef _header_h_
#include "header.h"
#endif
#ifndef _rotation_h_
#include "rotation.h"
#endif

/* Begin Type Definition location */

class location : public rotation
{
 public:
  void Close();
  location();
  void Print();
  location(double a,double b,double c);
#ifdef _UN_USE_YACC_
#include "accept.h"
#include "reduce.h"
#endif
};

/* End Type Definition location */
#endif
