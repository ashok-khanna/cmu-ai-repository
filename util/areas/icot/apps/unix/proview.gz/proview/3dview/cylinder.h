/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
/* -*- C++ -*- */
#ifndef _cylinder_h_
#define _cylinder_h_
/* cylinder.h */
#ifndef _node_h_
#include "node.h"
#endif
/* ���졢�������ͳѿ����߿����ѿ��ʤɤ����褹�륪�֥������� */

/* Begin Class Definition cylinder */
#define CYLINDER_WORD_SIZE 4

class cylinder : public object
{
 protected:
  int  division;
  double  dx,dy,dz,xtheta,ytheta,cx,cy,cz;
  node obj[CYLINDER_WORD_SIZE];
  float v_top,v_bottom,full_height;
 public:
  cylinder();
  void Close();
  void From(location* l);
  void To(location* l);
  header* Reference(int id);

/* virtual Function. Look object.h */
  void Scale(double s);
  void Draw();

  void CopySplitMember();
  void PushTranslation();
  void PopTranslation();
  void PushRotation();
  void PopRotation();
#ifdef _UN_USE_YACC_
#include "accept.h"
#include "reduce.h"
#endif
};
/* End Class Definition cylinder */

class cylinder1 : public cylinder
{
 public:
  cylinder1();
};

class pipe0 : public cylinder
{
 public:
  pipe0();
  void Draw();
};

class pipe1 : public pipe0
{
 public:
  pipe1();
};

class pillar0 : public cylinder
{
 public:
  pillar0();
  void Draw();
};

class pillar1 : public pillar0
{
 public:
  pillar1();
};

class conic : public cylinder
{
 public:
  conic();
  void Draw();
};

class cone : public cylinder
{
 public:
  cone();
  void Draw();
};
#endif /* _cylinder_h_ */

