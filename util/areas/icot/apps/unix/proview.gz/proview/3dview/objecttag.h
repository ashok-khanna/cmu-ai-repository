/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
/* -*- C++ -*- */
#ifndef _objecttag_h_
#define _objecttag_h_

/* Begin Type Definition object type tag */

typedef enum  {
  NOT_INITIALIZE,	// 0
  DAT_INTEGER,		// 1
  DAT_FLOAT,		// 2
  DAT_STRING,		// 3
  DAT_LOCATION,		// 4
  DAT_LIST,		// 5
  POL_SPHERE,		// 6
  POL_BOX,		// 7
  POL_PIPE0,		// 8
  POL_PIPE1,		// 9
  POL_CYLINDER0,	// 10
  POL_CYLINDER1,	// 11
  POL_CONE,		// 12
  POL_CONIC,		// 13
  POL_PYRAMID,		// 14
  POL_PILLAR0,		// 15
  POL_PILLAR1,		// 16
  POL_MESH,		// 17
  PR_SEGMENT,		// 18
  PR_DOT,		// 19
  PR_LINE,		// 20
  PR_TEXT,		// 21
  GROUP_OBJ,		// 22
  NODE_OBJ,		// 23
  MATERIAL_OBJ,		// 24
  GORTH_OBJ,		// 25
  LIGHT_OBJ		// 26
#ifdef _DISABLE_GL_
  , POL_ATOM, POL_BOND, POL_HELIX, POL_SHEET
#endif
}  ObjectTypeTag;

/* End Type Definition object type tag */

#endif

