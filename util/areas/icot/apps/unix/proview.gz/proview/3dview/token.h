/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#ifndef _token_h_

typedef struct {
  int retvalue;  /* Type */
  YYSTYPE value;
} reserve_word;

#endif
