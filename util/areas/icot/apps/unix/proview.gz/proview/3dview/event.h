/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#ifndef _event_h_
#define _event_h_

#define ANY	-1
#define UP	0
#define DOWN	1

extern void add_event(int window, int device, int state, void (*func)(void *, int), void *arg);
extern void add_update(int *, void (*fn)(), void *);
extern void event(void);
extern int context, state, device;
#endif
