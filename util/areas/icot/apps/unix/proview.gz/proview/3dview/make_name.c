/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#include <stdio.h>
#include "node.h"
#include "hash.h"
#include "group.h"
#define NODE_STACK_SIZE (256)

extern char* strapp (char* s1,const char* s2);

node* node_stack[NODE_STACK_SIZE];

void make_name(char* str,node* np)
{
  int id ;
  id = hash_table.wordId(":");
  int sp;
  sp = NODE_STACK_SIZE;
  for (;id != (np->Id());) {
    sp--;
    node_stack[sp] = np;
    group* gp;
    gp = (group*)(np->Parent());
    np = (node*)(gp->Parent());
  }
  str = strapp(str," ");
  for (;sp < (NODE_STACK_SIZE);sp++) {
    str = strapp(str,node_stack[sp]->Name());
    if (sp <(NODE_STACK_SIZE-1))
      str = strapp(str," ");
  }
}
