/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */

typedef union  {
  int ival;
  int sval;
  double fval;
  MethodID midval;
  FunctionID fidval;
  header* oval;
  message* mval;
} YYSTYPE;

extern YYSTYPE yylval;

# define FLOAT 257
# define INTEGER 258
# define STRING 259
# define MEMBER 260
# define MATH_FUNC 261
# define METHOD_ONLY_NAME 262
# define METHOD_NAME 263
# define OBJECT_TYPE 264
# define COMMA 265
# define ENDARGS 266
# define BGNARGS 267
# define ENDLIST 268
# define BGNLIST 269
# define PLUS 270
# define MINUS 271
# define TE 272
# define NEW 273
# define QS 274
# define BGNSTR 275
# define ENDSTR 276
# define ENDFILE 277
# define DIV 278
# define MU 279
# define MUL 280
# define SYMBOL 281
# define SWSYM 282

#define ArgNext if(structerd){\
	  wp = (container*)wp->Next();\
	  continue; \
	}else{ \
	  return; \
	}

