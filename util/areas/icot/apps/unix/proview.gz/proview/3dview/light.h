/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#ifndef _light_h_

#ifndef _object_h_
#include "object.h"
#endif

/* �饤�ȥ��֥������Ȥ�������뤿��Υ��֥������� */

class light : object {
 protected:
  int light_id;
  float tc_red;
  float tc_green;
  float tc_blue;
 public:
  light();
  inline float Red();
  inline float Green();
  inline float Blue();
  inline void Red(float r);
  inline void Green(float g);
  inline void Blue(float b);
  void RgbSet(float r,float g,float b);
  void Bind();
#ifdef _UN_USE_YACC_
#include "accept.h"
#include "reduce.h"
#endif
};
inline float light::Red()
{
  return tc_red;
}
inline float light::Green()
{
  return tc_green;
}
inline float light::Blue()
{
  return tc_blue;
}
inline void light::Red(float r)
{
  tc_red = r;
}
inline void light::Green(float g)
{
  tc_green = g;
}
inline void light::Blue(float b)
{
  tc_blue = b;
}
#endif
