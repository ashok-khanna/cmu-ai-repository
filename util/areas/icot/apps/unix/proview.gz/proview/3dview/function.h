/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
/**/
#ifndef _function_h_
#define _function_h_

typedef enum {
  FUNCTION_SQRT,
  FUNCTION_INT,
  FUNCTION_SIN,
  FUNCTION_TAN,
  FUNCTION_COS,
  FUNCTION_ASIN,
  FUNCTION_ATAN,
  FUNCTION_ACOS,
  FUNCTION_EXP,
  FUNCTION_LOG
}FunctionID;

#endif
