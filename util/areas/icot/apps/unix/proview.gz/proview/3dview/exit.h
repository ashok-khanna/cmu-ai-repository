/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#ifndef _exit_h_
#define _exit_h_
inline void error_exit() 
{
#ifndef _DISABLE_GL_
  gexit();
  exit(-1);
#endif
}
inline void normal_exit() 
{
#ifndef _DISABLE_GL_
  gexit();
#endif
  exit(0);
}
#endif
