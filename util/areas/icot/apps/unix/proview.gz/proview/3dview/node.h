/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#ifndef _node_h_
#define _node_h_

#ifndef _header_h_
#include "header.h"
#endif
#ifndef _data_h_
#include "data.h"
#endif

/* Begin Class Definition node  */
class node : public header
{
  header* value_object;
  header* parent;
  char* name;
  int id;
  int update_flag ;
  int group_flag ;
  public:
  node();
  void Name(const char* n);
  const char* Name();
  int Id();
  void Id(int i);
  int  IsUpdate();
  int  IsGroup();
  void  Parent(header* p);
  header* Parent();
  header* Value();
/* Function Defined At object.c */
  void Close();
  void Value(header* h);
#ifdef _UN_USE_YACC_
#include "accept.h"
#include "reduce.h"
#endif
};
extern header* copy_object(header* h);
/* End Class Definition node */
#endif


