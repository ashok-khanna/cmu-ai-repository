/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
/* -*-C++-*- */

#ifndef _text_h_
#define _text_h_

#ifndef _node_h_
#include "node.h"
#endif
#ifndef _object_h_
#include "object.h"
#endif
#define TEXT_WORD_SIZE 3

/* ʸ����������Ԥʤ����֥������� */

/* Begin Class Definition text  */
class text : public object
{
  node obj[TEXT_WORD_SIZE];
  public:
/* Function Defined At object.c */
  text();
  header* Reference(int id);

/* virtual Function. Look object.h */
  void Scale(double s);
  void Draw();

  void Close();
  void CopySplitMember();
#ifdef _UN_USE_YACC_
#include "accept.h"
#include "reduce.h"
#endif
};

/* End Class Definition text */
#endif
