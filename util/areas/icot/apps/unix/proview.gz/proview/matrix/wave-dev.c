/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#include <math.h>
#include <stream.h>

main()
{
  int Width=4001;

  double* A;
  double* B;

  A = new double[Width];
  B = new double[Width];

  for(int I=0;I<Width;++I)
    {
      A[I] = 0.0;
    }
  A[Width/2] = 1.0;
    
  for(int W=1;W<Width/2;++W)
    {
      double M =0.0;
      double M2=0.0;
      
      B[0] = A[0]/2.0 + A[1]/4.0;
      M +=B[0];
      M2+=B[0]*(Width/2)*(Width/2);
      for(I=1;I<Width-1;++I)
	{
	  B[I] = A[I]/2.0+A[I-1]/4.0+A[I+1]/4.0;
	  M +=B[I];
	  M2+=B[I]*(I-Width/2)*(I-Width/2);
	}
      B[Width-1]=A[Width-1]/2.0+A[Width-2]/4.0;
      M +=B[Width-1];
      M2+=B[Width-1]*(Width/2)*(Width/2);
      double Dev = M2/M;
      cout << form("%8d\t%25.16lf\t%25.16lf\n",W,Dev,Dev/W);
      double* C;
      C = A;
      A = B;
      B = C;
    }
}
