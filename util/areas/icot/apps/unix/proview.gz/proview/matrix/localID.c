/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#include <stream.h>
#include "localID.h"

void localID::hrule(void)
{
  int P = (FullCnt<Width?FullCnt-1:Width-1);
  if(Width==3)
    {
      for(int I=0;I<P;++I)
	{
	  cout << form(" %s( %4d, %X, %4d, %X).\n",
		       RuleName,Width,name(I),(P-I-1),name(P));
	}
    }
  else
    {
      for(int I=0;I<P;++I)
	{
	  cout << form(" %s( %4d, %X, %4d, %X).\n",
		       RuleName,Width,name(I),(P-I-1)/(Width/4),name(P));
	}
    }
}

void localID::vrule(int LargeWidth, int LargeName)
{
  if(Width==3)
    {
      for(int I=0;I<Width;++I)
	{
	  cout << form(" %s( %4d, %4d, %X, %4d, %X).\n",
		       RuleName,LargeWidth,Width,
		       LargeName,I,name(I));
	}
    }
  else
    {
      for(int I=0;I<Width;++I)
	{
	  cout << form(" %s( %4d, %4d, %X, %4d, %X).\n",
		       RuleName,LargeWidth,Width,
		       LargeName,I/(Width/4),name(I));
	}
    }
}

