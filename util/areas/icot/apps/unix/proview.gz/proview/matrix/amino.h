/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#include <string.h>
#include <stream.h>

extern double AminoCharge[];
extern double AminoHPhobe[];
extern double AminoVolume[];

class amino
{
  char Triplet[4];
  char Single;
  int  ID;
 public:
  amino(void);
  amino(char*);
  amino(char);
  amino(int);
  void input(char*);
  void input(char);
  void input(int);
  inline char*  triplet(void){return Triplet;}
  inline char   single(void) {return Single;}
  inline int    id(void)     {return ID;}
  inline double sidePK(void) {return AminoCharge[ID];}
  inline double hphobe(void) {return AminoHPhobe[ID];}
  inline double volume(void) {return AminoVolume[ID];}
  friend amino operator=(amino&,amino&);
};


