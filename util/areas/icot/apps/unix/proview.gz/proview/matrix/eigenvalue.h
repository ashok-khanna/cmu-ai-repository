/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#ifndef _eigenvalue_h_
#define _eigenvalue_h_

#ifndef _matrix_h_
#include "matrix.h"
#endif

class eigenvalue : public matrix {
  double* val;
 public:
  eigenvalue(int);
  eigenvalue(void);
  eigenvalue(matrix& A,double* d);
  virtual void print();
  virtual void copy(eigenvalue& A);
  double value(int d);
  virtual ~eigenvalue(void);
};

extern eigenvalue eigen(matrix& A);
extern void   operator=(eigenvalue& A, eigenvalue& B);

#endif /* eof ifndef _eigenvalue_h_ */
