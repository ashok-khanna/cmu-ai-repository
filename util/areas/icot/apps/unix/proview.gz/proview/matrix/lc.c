/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#include <stdio.h>
#include <stream.h>

main(void)
{
  char BuffNew[1024];
  char BuffOld[1024];
  int Cnt      = 1;
  int CCnt     = 1;
  int TotalCnt = 0;
  gets(BuffOld);
  while(gets(BuffNew))
    {
      if(0==strcmp(BuffOld,BuffNew))
	{
	  Cnt ++;
	}
      else
	{
	  CCnt ++;
	  printf("%8d %s\n",Cnt,BuffOld);
	  TotalCnt += Cnt;
	  Cnt = 1;
	  strcpy(BuffOld,BuffNew);
	}
    }
  printf("%8d Numbur of different lines.\n",CCnt);
  printf("%8d Number of lines.\n",TotalCnt);
}
