/* ---------------------------------------------------------- 
%   (C)1992 Institute for New Generation Computer Technology 
%       (Read COPYRIGHT for detailed information.) 
----------------------------------------------------------- */
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stream.h>
#include "field.h"
#include "localID.h"

int hruleCalc(int FieldID,char* RuleName)
{
  char   Buff[1024];
  String Field[32];

  int Width = beginCheck();
  if(Width == 0)
    {
      return 0;
    }
  if(NULL==gets(Buff))
    {
      return 0;
    }
  if(0==strncmp(Buff,"#End",4))
    {
      return 1;
    }
  localID  LocalID(Width,RuleName);
  int NW = getField(Buff,Field);
  LocalID.input(atoi(Field[0]),(int)strtol(Field[FieldID],(char**)NULL,16));
  while(gets(Buff))
    {
      if(0==strncmp(Buff,"#End",4))
	{
	  return 1;
	}
      NW = getField(Buff,Field);
      LocalID.input(atoi(Field[0]),
		    (int)strtol(Field[FieldID],(char**)NULL,16));
      LocalID.hrule();
    }
  return 0;
}


main(int argc, char** argv)
{
  if(argc<3)
    {
      cerr << "Usage:\nhrule FieldID RuleName\n";
      exit(1);
    }
  int FieldID = atoi(argv[1]);
  char RuleName[128];
  strcpy(RuleName,argv[2]);
  while(hruleCalc(FieldID,RuleName)){}
}
