
/****************************************************************************
 *                      CREDITS
 *Simple credits box using XmCreateMessageDialog()
 ***********************************************************************/

#include "animator.h"

void make_credits ()
{
Widget		credlabel;
Arg             wargs[5];
int             i;
XmString        message;
int credit_line = 26;       /* the number of lines in the credit header */
static char *text[] = { "                                        ",
 "                              >> HYPERPLANE ANIMATOR <<                   ",
 "                                      VER 1.01                            ",
 "              > A 2-dimensional Hyperplane Animator for Neural Networks < ",
 "                                                                          ",
 "    Designers:                Dr. Lori Pratt, Vincent Sgro, Mick Noordewier",
 "    Programmers:              Steve Nicodemus, Harry Walker               ",
 "                              Ported engine to operate under Motif.       ",
 "    Current Version: 1.01     1.01 June 1993 IBM RS-6000                  ",
 "    Previous Programmer:      Paul Hoeper                                 ",
 "    Original Concept:         Paul Munro                                  ",
 "    Previous Programmers:     Matt Dismukes, Vincent Sgro, Abbey Dy       ",
 "    Previous Version 1.0      1.0  April 1992 SUN IV platform             ",
 "                                                                          ",
 "     This is a demonstration copy of an incomplete version of this progam,",
 "and is distributed as-is, with no software support. This program is public",
 "domain; copies may be made for demonstration purposes. Please acknowledge ",
 "Pratt et. al. when using it. Questions / comments and suggestions should  ",
 "directed to:                                                              ",
 "                      Dr. Lori Pratt                                      ",
 "          Dept. of Mathmatics and Computer Science                        ",
 "                  Colorado School of Mines                                ",
 "                      Golden, Colorado                                    ",
 "      or                                                                  ",
 "                 lpratt@mines.colorado.edu                                ",
 "                                                                          "};
{



creditshell =  XmCreateBulletinBoardDialog(toplevel, "CREDITS", NULL, 0);

credlabel =    XtCreateManagedWidget("CREDITS", xmLabelWidgetClass, creditshell, NULL, 0);

message = XmStringCreate(text[0], XmSTRING_DEFAULT_CHARSET);

for (i=1; i < credit_line ; i++)
    {
    message = XmStringConcat(message, XmStringSeparatorCreate());
    message = XmStringConcat(message, XmStringCreate(text[i], XmSTRING_DEFAULT_CHARSET));
    }
/*
XtSetArg(wargs[0], XmNmessageString, message);
XtSetValues(creditshell, wargs, 1);
*/

XtSetArg(wargs[0], XmNlabelString, message);
XtSetValues(credlabel, wargs, 1);

XtManageChild(credlabel);
return;

}
}

