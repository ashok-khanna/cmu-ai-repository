/* Two simple routines.  The first is the only one used in the Animator.  It was taken
 * straight from Douglas A. Young book on X Windows programming.  (See animator.h file)
 */

#include <varargs.h>
#include <stdio.h>
#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <X11/cursorfont.h>
#include <X11/Shell.h>
#include <X11/Xutil.h>
#include <X11/Core.h>
#include <X11/Xlib.h>
#include <Xm/Xm.h>
#include <Xm/Text.h>
#include <Xm/PushB.h>
#include <Xm/BulletinB.h>
#include <Xm/DrawingA.h>
#include <Xm/Form.h>
#include <Xm/RowColumn.h>
#include <sys/time.h>
#include <limits.h>
#include <math.h>
#include <Xm/MessageB.h>




/***************************************************************************/
void    xs_wprintf(va_alist)    /*We really don't understand how this functions.
                                 *It was typed straight from Young, used in
                                 *update_showepoch() in animator.c & update_color() in coloredit.c
                                 */
va_dcl
{
   Widget       w;
   char         *format;
   va_list      args;
   char         str[1000];      /* potential for overflow situation */
   Arg          wargs[10];
   XmString     xmstr;

   /* Init the variable length args list */

   va_start(args);

   /* Extract the destination widget.
       Make sure it is a subclass of XmLabel. */

   w = va_arg(args, Widget);
   if ( !XtIsSubclass(w, xmLabelWidgetClass))
    XtError("xs_wprintf() requires a Label Widget");

   /* Extract format to be used  */

   format = va_arg(args, char *);

   /* use vsprintf to format the stringto be the display in the
   XmLabel widget, then convert it to a compound string */

   vsprintf (str, format, args);
   xmstr = XmStringLtoRCreate(str, XmSTRING_DEFAULT_CHARSET);
   XtSetArg(wargs[0], XmNlabelString, xmstr);
   XtSetValues(w, wargs, 1);

   va_end(args);
   }


/************************************************************************
 *concatenates an array of strings into a single compound XmString
 ************************************************************************/
XmString xs_concat_words (n, words)             /*not used yet, but handy!*/
int     n;
char    *words[];
{
 XmString       xmstr;
 int            i, lin=0;

   /*if ther are no words just return an empty string */

   if (n <= 0) return (XmStringCreate ("",
                XmSTRING_DEFAULT_CHARSET));
   xmstr = (XmString) NULL;

   for (i = 0; i < n; i++)
   {
      XmString tmp;
      if (i > 0)
      {
         tmp = XmStringCreate(" ", XmSTRING_DEFAULT_CHARSET);
         xmstr = XmStringConcat(xmstr, tmp);
      }
      tmp = XmStringCreate (words[i], XmSTRING_DEFAULT_CHARSET);
      xmstr = XmStringConcat (xmstr, tmp);
   }
   return (xmstr);
}


