/* This file #included in both prefchanges.c, which contains all callback routines for changing
 * user preferences, and animator.c which has the draw routines.
 */


                        /*Vars set through user choices in preferences */
float   ScreenSize = (float) SCREEN;
float   y_offset = 0.0;
float   x_offset = 0.0;
float   compress = 1.0;
int     pointsize = 4;
int     beginskip = 1;
int     skipinterval = 1;

Boolean Pause;
Boolean DemoMode = FALSE;       /*in demo mode, if true */
Boolean ShowPoints=TRUE;        /*show TP as points if true, show TP labels if false */
Boolean ShowLine[MaxHu];
int            updatenext;
