#include "animator.h"

void show_credits();
void show_color();
void show_prefs();
void show_more();
void show_epochs();

void close_color();
void close_prefs();


/************************************************************************
 *           SHOW PREFS,CREDITS, COLOR and MORE PREFS
 ************************************************************************/
void show_credits(w, data, call_data)
        Widget          w;
        line_data            *data;
        XmAnyCallbackStruct  *call_data;
{
XtManageChild(creditshell, 0);
XSetWindowColormap(XtDisplay(creditshell), XtWindow(creditshell), my_colormap);
}

void show_color(w, data, call_data)
        Widget          w;
        line_data            *data;
        XmAnyCallbackStruct  *call_data;
{
int     i;

XtPopup(colorshell, NULL);
XRaiseWindow(XtDisplay(colorshell),XtWindow(colorshell));
XSetWindowColormap(XtDisplay(colorshell), XtWindow(colorshell), my_colormap);

for (i=0; i< totalHU; i++)
{
        XtManageChild(linetoggle[i]);
        XtManageChild(legend[i]);
}
for (i=MaxHu; i< MaxHu+totalClasses; i++)
        XtManageChild(legend[i]);
}

void show_prefs(w, data, call_data)
        Widget          w;
        line_data               *data;
        XmAnyCallbackStruct  *call_data;
{
  XtPopup(prefshell, NULL);
  XRaiseWindow(XtDisplay(prefshell),XtWindow(prefshell));
}
void show_more(w, data, call_data)
        Widget                  w;
        line_data               *data;
        XmAnyCallbackStruct     *call_data;
{
  XtManageChild(moreprefshell);
  XSetWindowColormap(XtDisplay(moreprefshell), XtWindow(moreprefshell), my_colormap);
}

void show_epochs(w, data, call_data)
        Widget          w;
        line_data               *data;
        XmAnyCallbackStruct  *call_data;
{
  XtManageChild(epshell);
  XSetWindowColormap(XtDisplay(epshell), XtWindow(epshell), my_colormap);
}

/************************************************************************
 *  CLOSE routines for Widgets
 ************************************************************************/
void close_color(w, data, call_data)
        Widget          w;
        line_data       *data;
        XmAnyCallbackStruct *call_data;
{
	int i;
for (i=0; i< MaxHu; i++)
{
        XtUnmanageChild(linetoggle[i]);
        XtUnmanageChild(legend[i]);
}
for (i=MaxHu; i< MaxHu+MaxClasses; i++)
        XtUnmanageChild(legend[i]);

XtPopdown(colorshell);
}

void close_prefs(w, data, call_data)
        Widget          w;
        line_data       *data;
        XmAnyCallbackStruct *call_data;
{
XtUnmanageChild(moreprefshell);
XtPopdown(prefshell);
}

