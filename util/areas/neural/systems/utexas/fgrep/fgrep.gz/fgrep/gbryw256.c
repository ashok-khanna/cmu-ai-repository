/* generating colormaps

   First two entries are specified separately 
   Rest of the colors are spread out over the whole map
   Change the indeces according to # of bit planes

   This program generates a scale green->black->red->yellow->white

   Risto Miikkulainen 7/2/87

*/

#include <stdio.h>
main()
{
  register int i;
  /* 0 = red in color, black in bw */
  /* 1 = green in color, black in bw */
  printf("%f %f %f\n%f %f %f\n", 1.0, 0.0, 0.0, 0.0, 1.0, 0.0);
  for (i=2; i<65; i++) /* from white to yellow */
    printf("%f %f %f\n", 1.0, 1.0, (65.0-i)/63);
  for (i=65; i<128; i++) /* from yellow to red */
    printf("%f %f %f\n", 1.0, (128.0-i)/63, 0.0);
  for (i=128; i<191; i++) /* from red to black */
    printf("%f %f %f\n", (191.0-i)/63, 0.0, 0.0);
  for (i=191; i<255; i++) /* from black to green */
    printf("%f %f %f\n", 0.0, (i-191.0)/63, 0.0);
  printf("%f %f %f\n", 0.0, 0.0, 0.0); /* black */
}
