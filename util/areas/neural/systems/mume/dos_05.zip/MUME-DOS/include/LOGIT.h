/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       LOGIT.h (%M%): version %I%            
|       Author(s): Laurens Leerink
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: 
|                 
|___________________________________________________________________________*/
#ifndef LOGIT_H
#define LOGIT_H

#define  LOGITCLASS "logit"

extern void PrintLOGITRec();
extern void RCReadLOGIT();
extern void OrganiseLOGIT();
extern void RelaxLOGIT();
extern void PropLOGITErr();


#endif /* LOGIT_H */
