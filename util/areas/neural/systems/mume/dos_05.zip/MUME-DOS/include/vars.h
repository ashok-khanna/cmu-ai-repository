/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       vars.h (%M%): version %I%            
|       Author(s): Marwan Jabri
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: 
|                 
|___________________________________________________________________________*/
#ifndef VARS_H
#define VARS_H


extern char 
    RCFileName[],
    *RCBuffer;

extern int 
    RCLineNo,
    RCBufferLen,
    RCBufferPos,
    RCBufferPosLast,
    RCErrorFlagOn;

extern FILE 
    *RCfp;

extern nn_class_t **NetClasses;

#endif /* VARS_H */
