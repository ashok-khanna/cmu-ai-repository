/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       LOGITP.h (%M%): version %I%            
|       Author(s): Laurens Leerink
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: 
|                 
|___________________________________________________________________________*/
#ifndef LOGITP_H
#define LOGITP_H

#define NOITOKEN 		"noi"
#define LOGRELAXTOKEN 		"logrelax"
#define LOGPROPERRTOKEN		"logproperr"
#define LOGDOASCTOKEN		"doasc"
#define LOGNSOURCESTOKEN	"nsources"

typedef  struct logit_rec {
    int	LogRelax;
    int	LogPropErr;
    int DoAsc;
    int NSources;
} logit_t;


#endif /* LOGITP_H */
