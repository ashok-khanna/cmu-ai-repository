/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       OPT.h (%M%): version %I%            
|       Author(s): Edward Tinker
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: OPT private data
|                 
|___________________________________________________________________________*/
#ifndef OPT_H
#define OPT_H

#define OPTCLASS           "opt"

extern void PrintOPTRec();
extern void RCReadOPT();
extern void OrganiseOPT();
extern void InitOPTState();
extern void ReadOPTState();
extern void SaveOPTState();
extern void RelaxOPT();
extern void PropOPTErr();
extern void AccOPTDw();
extern void UpdateOPTWeights();
extern void ResetOPTDw();
extern void ComputeOPTMSE();
#endif /* OPT_H */
