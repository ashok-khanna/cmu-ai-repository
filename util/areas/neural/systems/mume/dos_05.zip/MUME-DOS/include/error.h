/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       error.h (%M%): version %I%            
|       Author(s): Marwan Jabri
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: 
|                 
|___________________________________________________________________________*/
#ifndef ERROR_H
#define ERROR_H


/* error messages */

#define PREMATURE_END		0
#define INCOMPLETE_END		1
#define INCOMPLETE_REC		2
#define UNRECOGNISED_BEGIN	3
#define UNRECOGNISED_STATEMENT	4
#define EXPECTING_BEGIN		5


static char *RCErrorMes[] = {
    "Premature end of input." ,
    "Incomplete \"end\" statement." ,
    "Incomplete record." ,
    "Unrecognised \"begin\" statement.",
    "Unrecognised statement.",
    "Expecting a \"begin\" statement."
};



#endif /* ERROR_H */
