/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       LMWP.h (%M%): version %I%            
|       Author(s): Marwan Jabri
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: 
|                 
|___________________________________________________________________________*/
#ifndef LMWP_H
#define LMWP_H

#define ANDMASKTYPE 0		/* default */
#define ORMASKTYPE  1
#define XORMASKTYPE 2
#define SHIFTMASKTYPE 3
#define NEURONORMASKTYPE 4
#define NOMASKTYPE 5

#define MASKTYPETOKEN      "masktype" /* and, xor, or, shift, nomask*/


typedef struct lmw_rec {
    int   MaskType;	      /* mask type */
} lmw_t;



#endif /* LMWP_H */
