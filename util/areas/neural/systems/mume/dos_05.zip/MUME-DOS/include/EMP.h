/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       EMP.h (%M%): version %I%            
|       Author(s): Laurens Leerink
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: 
|                 
|___________________________________________________________________________*/
#ifndef EMP_H
#define EMP_H

#define NOITOKEN 	"noi"
#define NOOTOKEN 	"noo"
#define EMLSHTOKEN 	"lsh-msh"

typedef  struct em_rec {
    int	lshmsh;
} em_t;


#endif /* EMP_H */
