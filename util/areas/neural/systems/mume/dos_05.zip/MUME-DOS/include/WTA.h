/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       WTA.h (%M%): version %I%            
|       Author(s): Marwan Jabri
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: winner take all net
|                 
|___________________________________________________________________________*/
#ifndef WTA_H
#define WTA_H

#define  WTACLASS "wta"

extern void PrintWTARec();
extern void RCReadWTA();
extern void OrganiseWTA();
extern void RelaxWTA();
extern void PropWTAErr();

#endif /* WTA_H */
