/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       RBPTT.h (%M%): version %I%            
|       Author(s): Ming Zhao
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: 
|                 
|___________________________________________________________________________*/
#ifndef RBPTT_H
#define RBPTT_H

#define RBPTTCLASS "rbptt"

extern void RCReadRBPTT();
extern void PrintRBPTTRec();
extern void OrganiseRBPTT();

extern void InitRBPTTState();
extern void ReadRBPTTState();
extern void SaveRBPTTState();

extern void RelaxRBPTT();
extern void PropRBPTTErr();
extern void AccRBPTTDw();
extern void UpdateRBPTTWeights();

extern void ResetRBPTTDw();
extern void ComputeRBPTTMSE();

#endif /* RBPTT_H */

