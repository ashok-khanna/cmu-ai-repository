/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       KAKADU.h (%M%): version %I%            
|       Author(s): Marwan Jabri
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: KAKADU private data
|                 
|___________________________________________________________________________*/
#ifndef KAKADU_H
#define KAKADU_H

#define KAKADUCLASS           "kakadu"


extern void PrintKAKADURec();
extern void RCReadKAKADU();
extern void OrganiseKAKADU();
extern void ReadKAKADUState();
extern void SaveKAKADUState();
extern void InitKAKADUState();
extern void RelaxKAKADU();
extern void PropKAKADUErr();
extern void ComputeKAKADUDw();
extern void UpdateKAKADUWeights();
extern void ResetKAKADUDw();
extern void ComputeKAKADUMSE();
extern double KAKADUQuantise();
#endif /* KAKADU_H */
