/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       XOFYP.h (%M%): version %I%            
|       Author(s): Marwan Jabri
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: 
|                 
|___________________________________________________________________________*/
#ifndef XOFYP_H
#define XOFYP_H

#define NOITOKEN "noi"
#define NOFXTOKEN "nx"
#define NOFYTOKEN "ny"

typedef  struct xofy_rec {
    int   Mode;		        /* active or not for now */
    int   nx;			/* number x */
    int   ny;			/* number yy */
    int   InLine;		/* number of decisions in line */
    double **DelayLine;		/* delay line with decisions */
} xofy_t;


#endif /* XOFYP_H */
