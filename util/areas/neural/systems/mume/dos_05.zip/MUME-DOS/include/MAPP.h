/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       MAPP.h (%M%): version %I%            
|       Author(s): Marwan Jabri
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: 
|                 
|___________________________________________________________________________*/
#ifndef MAPP_H
#define MAPP_H

#include "net.h"


typedef struct map_rec {
    struct  map_rec *r_next;
    char    *Name;		    /* name of map */
    iface_t *IfaceFrom, *IfaceTo;   /* interfaces */
    nn_t    *NetFrom, *NetTo;	    /* nets involved */
    int     Delay;		    /* delay between From & To */
    int     RBufIndex;		    /* present position in delay buffer */
    int     PBufIndex;		    /* take a guess */
    double  **RBuf;		    /* buffer for RelaxMAP info */
    double  **PBuf;		    /* buffer for PropMAPErr info */
} map_t;



#endif /* MAPP_H */
