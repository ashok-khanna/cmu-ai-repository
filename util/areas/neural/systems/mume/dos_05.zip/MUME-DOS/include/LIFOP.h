/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       LIFOP.h (%M%): version %I%            
|       Author(s): Laurens Leerink
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: 
|                 
|___________________________________________________________________________*/
#ifndef LIFOP_H
#define LIFOP_H

#define NOITOKEN 		"noi"
#define LIFOBUFSIZETOKEN	"bufsize"

typedef  struct lifo_rec {
    int	    BufSize;
    int     BufIndex;		    /* present position in buffer */
    double  **Buf;
} lifo_t;


#endif /* LIFOP_H */
