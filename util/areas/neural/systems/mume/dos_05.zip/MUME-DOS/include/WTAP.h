/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       WTAP.h (%M%): version %I%            
|       Author(s): Marwan Jabri
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: 
|                 
|___________________________________________________________________________*/
#ifndef WTAP_H
#define WTAP_H

#define WTAACTIVE 1

#define NOITOKEN "noi"
#define MAXWTATOKEN "max"
#define MINWTATOKEN "min"

typedef  struct wta_rec {
    double MaxWTA;		/* value to produce for winner */
    double MinWTA;		/* value to produce for loosers */
} wta_t;

#endif /* WTAP_H */
