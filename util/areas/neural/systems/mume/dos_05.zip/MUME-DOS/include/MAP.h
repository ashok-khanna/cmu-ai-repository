/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       MAP.h (%M%): version %I%            
|       Author(s): Marwan Jabri
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: 
|                 
|___________________________________________________________________________*/
#ifndef MAP_H
#define MAP_H

#include "MAPP.h"


#define  MAPCLASS "map"

extern void PrintMAPRec();
extern void RCReadMAP();
extern void OrganiseMAP();
extern void RelaxMAP();
extern void PropMAPErr();

#endif /* MAP_H */
