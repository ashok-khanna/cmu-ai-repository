/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       iface.h (%M%): version %I%            
|       Author(s): Marwan Jabri
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: 
|                 
|___________________________________________________________________________*/
#ifndef IFACE_H
#define IFACE_H

typedef struct iface_rec {
    struct iface_rec *r_next;
    char *Name;			/* name of interface */
    int  *Neurons;	        /* neuron indices */
    int  NumNeurons;		/* number of neurons in interface */
} iface_t;
 
#endif /* IFACE_H */
