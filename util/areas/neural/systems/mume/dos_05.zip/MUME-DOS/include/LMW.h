/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       LMW.h (%M%): version %I%            
|       Author(s): Marwan Jabri
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: LMW interface
|                 
|___________________________________________________________________________*/
#ifndef LMW_H
#define LMW_H

#define LMWCLASS           "lmw"

extern void PrintLMWRec();
extern void RCReadLMW();
extern void OrganiseLMW();
extern void ReadLMWState();
extern void SaveLMWState();
extern void RelaxLMW();
extern void PropLMWErr();
extern void ComputeLMWDw();
extern void ComputeLMWMSE();
extern double LMWQuantise();
#endif /* LMW_H */
