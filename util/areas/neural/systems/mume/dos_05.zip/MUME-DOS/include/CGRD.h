/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       CGRD.h (%M%): version %I%            
|       Author(s): Edward Tinker
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: 
|                 
|___________________________________________________________________________*/
#ifndef CGRD_H
#define CGRD_H

extern double CGRD();
extern void CGRDWtoMUMEW();
extern void MUMEWtoCGRDW();

#endif /* CGRD_H */
