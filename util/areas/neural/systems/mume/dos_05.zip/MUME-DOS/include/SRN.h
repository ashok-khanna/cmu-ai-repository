/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       SRN.h (%M%): version %I%            
|       Author(s): Marwan Jabri
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: SRN private data
|                 
|___________________________________________________________________________*/
#ifndef SRN_H
#define SRN_H

#define SRNCLASS           "srn"

extern void PrintSRNRec();
extern void RCReadSRN();
extern void OrganiseSRN();
extern void InitSRNState();
extern void ReadSRNState();
extern void SaveSRNState();
extern void RelaxSRN();
extern void PropSRNErr();
extern void ComputeSRNDw();
extern void UpdateSRNWeights();
extern void ResetSRNDw();
extern void ComputeSRNMSE();
extern void AccSRNXtraIn();
extern void GetSRNXtraErr();
extern void SRNDie();
#endif /* SRN_H */
