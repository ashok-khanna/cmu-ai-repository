/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       WZ.h (%M%): version %I%            
|       Author(s): Marwan Jabri
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: 
|                 
|___________________________________________________________________________*/
#ifndef WZ_H
#define WZ_H

#define WZCLASS "wz"

extern void   RCReadWZ(),   PrintWZRec(),  OrganiseWZ(),
    InitWZState(), ReadWZState(), SaveWZState(),
    RelaxWZ(), PropWZErr(), AccWZDw(), UpdateWZWeights(),
    ResetWZDw(), ComputeWZMSE();

#endif /* WZ_H */
