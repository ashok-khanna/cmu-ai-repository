/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       FREC.h (%M%): version %I%            
|       Author(s): Alain Dutech
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: 
|
|                 
|___________________________________________________________________________*/
#ifndef FREC_H
#define FREC_H

/* Data structure is now in FRECP.h (P for private) */

#define FRECCLASS	   "frec"

extern void PrintFRECRec();
extern void RCReadFREC();
extern void OrganiseFREC();
extern void InitFRECState();
extern void ReadFRECState();
extern void WriteFRECState();
extern void RelaxFREC();
extern void PropFRECErr();
extern void ComputeFRECDw();
extern void UpdateFRECWeights();
extern void ResetFRECDw();
extern void ComputeFRECMSE();
extern void AccFRECXtraIn();
extern void GetFRECXtraErr();
extern void FRECDie();

#endif /* FREC_H */




