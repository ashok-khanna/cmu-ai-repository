/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       obs.h (%M%): version %I%            
|       Author(s): Marwan Jabri
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: 
|                 
|___________________________________________________________________________*/
#ifndef OBS_H
#define OBS_H

typedef struct pdata_rec {
    struct pdata_rec *r_next;
    double *Idata;
    double *Odata;
} pdata_t;

typedef struct obs_rec {
    struct obs_rec *r_next;
    char *Name;		    /* name of data set */
    char *file;             /* file name  */
    int  N;		    /* number of patterns */
    int  ftype;             /* file type: asc, ni */
    pdata_t *data;	    /* data pattern list */
} obs_t;


#define NOISE_UNIFORM        1

#endif /* OBS_H */








