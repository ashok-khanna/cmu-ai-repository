/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       LIFO.h (%M%): version %I%            
|       Author(s): Laurens Leerink
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: 
|                 
|___________________________________________________________________________*/
#ifndef LIFO_H
#define LIFO_H

#define  LIFOCLASS "lifo"

extern void PrintLIFORec();
extern void RCReadLIFO();
extern void OrganiseLIFO();
extern void RelaxLIFO();
extern void PropLIFOErr();


#endif /* LIFO_H */
