/* $Id: THDP.h,v 1.1 1992/12/07 04:58:54 mume Exp $ */
/***************************************************************************

         Authors: Marwan Jabri

Copyright 1992 by Marwan Jabri and the Systems Engineering and Design
Automation Laboratory, the University of Sydney.

The material in this file is subject to copyright. It may not
be used, copied or transferred by any means without the prior written
approval of the Systems Engineering and Design Automation Laboratory at
Sydney University Electrical Engineering, NSW 2006, Australia. 
It is provided under a license and under the terms and the 
conditions described in an agreement (see the LICENSE file). 

SYDNEY UNIVERSITY DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
EVENT SHALL SYDNEY UNIVERSITY BE LIABLE FOR ANY SPECIAL, INDIRECT OR
CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF
USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
****************************************************************************/
#ifndef THDP_H
#define THDP_H

#define NOITOKEN "noi"
#define MAXTHDTOKEN "max"
#define MINTHDTOKEN "min"
#define THDTOKEN    "threshold"

typedef  struct thd_rec {
    double MaxTHD;		/* value to produce for winner */
    double MinTHD;		/* value to produce for loosers */
    double Threshold;           /* threshold value */
} thd_t;


#endif /* THDP_H */
