/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       XOFY.h (%M%): version %I%            
|       Author(s): Marwan Jabri
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: 
|                 
|___________________________________________________________________________*/
#ifndef XOFY_H
#define XOFY_H

#define  XOFYCLASS "xofy"
#define  XOFYACTIVE 1

extern void PrintXOFYRec();
extern void RCReadXOFY();
extern void OrganiseXOFY();
extern void RelaxXOFY();
extern void PropXOFYErr();


#endif /* XOFY_H */
