/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       ENV.h (ENV.h): version 1.23            
|       Author(s): Marwan Jabri
|       delta date 92/08/23 19:53:45  
|       obtained 92/08/23 19:54:12    
|	Synopsis: 
|                 
|___________________________________________________________________________*/
#ifndef ENV_H
#define ENV_H

#include "obs.h"

#define ENVCLASS "env"
/* class procedures */
extern void PrintENVRec();
extern void RCReadENV();
extern void OrganiseENV();
extern void InitENVWeights();
extern void ReadENVWeights();
extern void WriteENVWeights();
extern void RelaxENV();
extern void PropENVErr();
extern void ComputeENVDw();
extern void UpdateENVWeights();
extern void ResetENVDw();
extern void ComputeENVMSE();
extern void ResetENVErrors();
extern void ResetENVXtraIn();
extern void AccENVXtraIn();
extern void GetENVXtraErr();

/* utilities */

extern obs_t *EnvSetData();
extern obs_t *AttachData();
extern obs_t *EnvDataSetFromName();

#endif /* ENV_H */
