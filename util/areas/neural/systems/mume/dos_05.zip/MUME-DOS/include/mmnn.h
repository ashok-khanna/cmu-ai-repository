/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       mmnn.h (%M%): version %I%            
|       Author(s): Marwan Jabri
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: 
|                 
|___________________________________________________________________________*/
#ifndef MMNN_H
#define MMNN_H

#include        <stdio.h>
#include        <malloc.h>
#include        <strings.h>
#include        <math.h>
#include        <sys/types.h>
#include        <time.h>

#include        "tokens.h"
#include        "defs.h"
#include        "net.h"
#include        "nnsys.h"
#include        "externs.h"
#include        "vars.h"
#include        "error.h"

#endif /* MMNN_H */

