/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       MLP.h (%M%): version %I%            
|       Author(s): Marwan Jabri
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: MLP private data
|                 
|___________________________________________________________________________*/
#ifndef MLP_H
#define MLP_H

#define MLPCLASS           "mlp"

extern void PrintMLPRec();
extern void RCReadMLP();
extern void OrganiseMLP();
extern void InitMLPState(); 
extern void ReadMLPState();
extern void SaveMLPState();
extern void RelaxMLP();
extern void PropMLPErr();
extern void AccMLPDw();
extern void UpdateMLPWeights();
extern void ResetMLPDw();
extern void ComputeMLPMSE();
#endif /* MLP_H */
