/* $Id: LEVELP.h,v 1.1 1992/12/07 04:58:34 mume Exp $ */
/***************************************************************************

         Authors: Edward Tinker

Copyright 1992 by Marwan Jabri and the Systems Engineering and Design
Automation Laboratory, the University of Sydney.

The material in this file is subject to copyright. It may not
be used, copied or transferred by any means without the prior written
approval of the Systems Engineering and Design Automation Laboratory at
Sydney University Electrical Engineering, NSW 2006, Australia. 
It is provided under a license and under the terms and the 
conditions described in an agreement (see the LICENSE file). 

SYDNEY UNIVERSITY DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
EVENT SHALL SYDNEY UNIVERSITY BE LIABLE FOR ANY SPECIAL, INDIRECT OR
CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF
USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
****************************************************************************/
#ifndef LEVELP_H
#define LEVELP_H

#define NOITOKEN "noi"
#define NOOTOKEN "noo"
#define MAXLEVELTOKEN "max"
#define MINLEVELTOKEN "min"
#define SETTOKEN      "set"
#define MAXLEVELS     20

typedef struct levels_rec{
    double gtrthd;
    double lsnthd;
    char gtr;
    char lsn;
    int node;
} levels_t;


typedef  struct LEVEL_rec {
    double MaxLEVEL;		/* value to produce for winner */
    double MinLEVEL;		/* value to produce for loosers */
    levels_t Levels[MAXLEVELS]; /* threshold/level settings */
} level_t;


#endif /* LEVELP_H */







