/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       externs.h (%M%): version %I%            
|       Author(s): Marwan Jabri
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: 
|                 
|___________________________________________________________________________*/
#ifndef EXTERNS_H
#define EXTERNS_H


extern nn_t *PointerFromName();
extern nnsys_t *NewSysRec();
extern nn_t *NewNNRec();
extern nfun_t *NewNFunRec();
extern nnsys_t *NewSysRec();
extern nnsys_t *ReadRC();
extern nnf_t *CheckNFunName();
extern char *strdup();
extern iface_t *NewIFaceRec();
extern nn_class_t *CopyClassProc();
extern nn_t *NameToNet();
extern void NamesToNetList();
extern double RandUniform();
extern double GetRandom();
extern double fabs();
extern char *MakeFileExt();
extern FILE *xfopen();

extern void AllocPublicMem();
extern void ResetErrors();
extern void ResetXtraIn();
extern void AccXtraIn();
extern void GetXtraErr();
extern void Die();
extern char ** ParseConnMatrix();
extern list_t *NewListRec();
extern list_t *ListFromName();
#endif /* EXTERNS_H */
