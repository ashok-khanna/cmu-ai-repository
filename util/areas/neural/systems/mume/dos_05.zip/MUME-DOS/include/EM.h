/*----------------------------------------------------------------------------
|	
|	Copyright (C) 1992 by SEDAL, 
|	Sydney University Electrical Engineering
|	The material in this file is subject to copyright and may not
|       be used or copied without the prior approval of Sydney University
|       Electrical Engineering
|
|       EM.h (%M%): version %I%            
|       Author(s): Laurens Leerink
|       delta date %E% %U%  
|       obtained %D% %T%    
|	Synopsis: 
|                 
|___________________________________________________________________________*/
#ifndef EM_H
#define EM_H

#define  EMCLASS "em"

extern void PrintEMRec();
extern void RCReadEM();
extern void OrganiseEM();
extern void RelaxEM();
extern void PropEMErr();


#endif /* EM_H */
