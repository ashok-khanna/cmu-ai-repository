/************************************************************************
 *                                                                      *
 *  Program package 'som_pak':                                          *
 *                                                                      *
 *  vfind.c                                                             *
 *  - find best map with many trials                                    *
 *                                                                      *
 *  Version 1.0                                                         *
 *  Date: 9 Oct 1992                                                    *
 *                                                                      *
 *  NOTE: This program package is copyrighted in the sense that it      *
 *  may be used for scientific purposes. The package as a whole, or     *
 *  parts thereof, cannot be included or used in any commercial         *
 *  application without written permission granted by its producents.   *
 *  No programs contained in this package may be copied for commercial  *
 *  distribution.                                                       *
 *                                                                      *
 *  All comments  concerning this program package may be sent to the    *
 *  e-mail address 'lvq@cochlea.hut.fi'.                                *
 *                                                                      *
 ************************************************************************/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <float.h>
#include <math.h>
#include "lvq_pak.h"
#ifndef max
#define max(x,y) ((x)<(y) ? (y):(x))
#endif


/*---------------------------------------------------------------------------*/

void print_description()
{
  printf("This program will repeatedly run the initialization, training\n");
  printf("and testing cycle for Self-Organizing Map algorithm.\n");
  printf("\n");
  printf("In the following the training file name, the test file name\n");
  printf("(that can be the same) and the map save file name are asked.\n");
  printf("After them the type of map topology is asked, as well as\n");
  printf("the type of neighborhood function. The x- and y-dimension\n");
  printf("of the map should be integers and prefereably x-dimension\n");
  printf("should be larger than y-dimension.\n");
  printf("\n");
  printf("The training is done in two parts. First an ordering phase\n");
  printf("that is usually shorter than the following converging phase.\n");
  printf("The number of training cycles, the training rates and\n");
  printf("the radius of the adaptation area are asked separately for\n");
  printf("both phases. The fixed point qualifiers and weighting qualifiers\n");
  printf("are used if the corresponding parameters were given.\n");
  printf("\n");
  printf("The quantization error is computed for each map and\n");
  printf("the best map (smallest quantization error) is saved to\n");
  printf("the given file. If the verbose parameter allows the quantization\n");
  printf("error is given for each separate trial.\n");
  printf("\n");
  printf("After the answers have been given the training begins\n");
  printf("and depending on the size of problem it may take a long time.\n");
  printf("\n");
}

int get_int(char *ch, int no)
{
  int len = 100;
  char *tstr;
  char str[100];

  printf("%s: ", ch);

  tstr = fgets(str, len, stdin);
  if (tstr == NULL)
    return(no);

  return(oatoi(str, no));
}

float get_float(char *ch, float no)
{
  int len = 100;
  char *tstr;
  char str[100];

  printf("%s: ", ch);

  tstr = fgets(str, len, stdin);
  if (tstr == NULL)
    return(no);

  return(atof(str));
}

char *get_str(char *ch)
{
  int len = 100;
  char *tstr, *tmp;
  char str[100];

  printf("%s: ", ch);

  tstr = fgets(str, len, stdin);
  if (tstr == NULL) {
    printf("Can't read required data\n");
    exit(1);
  }

  tstr = ostrdup(str);
  tmp = strchr(tstr, ' ');
  if (tmp != (char) NULL)
    tmp[0] = '\0';
  tmp = strchr(tstr, '\n');
  if (tmp != (char) NULL)
    tmp[0] = '\0';

  return(tstr);
}

int main(int argc, char **argv)
{
  int not, bnot;
  int noc, nod;
  int xdim, ydim;
  int topol, neigh;
  int length1;
  float alpha1, radius1;
  int length2;
  int fixed, weights;
  float alpha2, radius2;
  float qerror, qerrorb;
  char *in_data_file;
  char *in_test_file;
  char *out_code_file;
  struct entries *data;
  struct entries *tmpdata;
  struct entries *testdata;
  struct entries *codes;
  struct entries *codess;
  struct entries *tmp;
  
  print_description();

  not = get_int("Give the number of trials", 0);
  in_data_file = get_str("Give the input data file name");
  in_test_file = get_str("Give the input test file name");
  out_code_file = get_str("Give the output map file name");

  topol = topol_type(get_str("Give the topology type"));
  if (topol < 0) {
    if (verbose(-1) > 0)
      printf("Unknown topology type, using hexagonal\n");
    topol = topol_type("hexa");
  }
  neigh = neigh_type(get_str("Give the neighborhood type"));
  if (neigh < 0) {
    if (verbose(-1) > 0)
      printf("Unknown neighborhood type, using bubble\n");
    neigh = neigh_type("bubble");
  }

  xdim = get_int("Give the x-dimension", 0);
  ydim = get_int("Give the y-dimension", 0);

  length1 = (long) get_int("Give the training length of first part", 0);
  alpha1 = get_float("Give the training rate of first part", 0.0);
  radius1 = get_float("Give the radius in first part", 0.0);
  length2 = (long) get_int("Give the training length of second part", 0);
  alpha2 = get_float("Give the training rate of second part", 0.0);
  radius2 = get_float("Give the radius in second part", 0.0);

  printf("\n");

  verbose((int) oatoi(extract_parameter(argc, argv, VERBOSE, OPTION), 1));
  fixed = (int) oatoi(extract_parameter(argc, argv, FIXPOINTS, OPTION), 0);
  weights = (int) oatoi(extract_parameter(argc, argv, WEIGHTS, OPTION), 0);

  use_fixed(fixed);
  use_weights(weights);

  label_not_needed(1);
  if (verbose(-1) > 1)
    fprintf(stdout, "Input entries are read from file %s\n", in_data_file);
  data = read_entries(in_data_file);
  if (verbose(-1) > 1)
    fprintf(stdout, "Test entries are read from file %s\n", in_test_file);
  testdata = read_entries(in_test_file);

  noc = xdim * ydim;
  if (noc <= 0) {
    printf("Dimensions of map (%d %d) are incorrect\n", xdim, ydim);
    exit(1);
  }
  if (xdim < 0) {
    printf("Dimensions of map (%d %d) are incorrect\n", xdim, ydim);
    exit(1);
  }

  nod = 0;
  tmpdata = testdata;
  while (tmpdata != NULL) {
    nod++;
    tmpdata = tmpdata->next;
  }
  

  codess = NULL;
  qerrorb = FLT_MAX;
  bnot = 0;
  while (not) {
    init_random(not);

    codes = randinit_codes(noc, data, topol, neigh, xdim, ydim);
    
    codes = som_training(data, codes, length1, alpha1, radius1);
    codes = som_training(data, codes, length2, alpha2, radius2);

    qerror = find_qerror(testdata, codes);

    if (qerror < qerrorb) {
      qerrorb = qerror;
      bnot = not;

      tmp = codess;
      codess = codes;
      codes = tmp;
    }

    efree(codes);
    if (verbose(-1) > 0)
      fprintf(stdout, "%3d: %f\n", not, qerror/(float) nod);
    not--;
  }

  if (codess != NULL) {
  }

  if (verbose(-1) > 1)
    fprintf(stdout, "Codebook entries are saved to file %s\n", out_code_file);
  save_entries(codess, out_code_file);
  if (verbose(-1) > 0)
    fprintf(stdout, "Smallest error with random seed %3d: %f\n",
                bnot, qerrorb/(float) nod);

  return(0);
}



