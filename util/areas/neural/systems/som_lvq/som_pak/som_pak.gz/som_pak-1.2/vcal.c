/************************************************************************
 *                                                                      *
 *  Program package 'som_pak':                                          *
 *                                                                      *
 *  vcal.c                                                              *
 *  -sets the labels of entries by the majority voting                  *
 *                                                                      *
 *  Version 1.0                                                         *
 *  Date: 9 Oct 1992                                                    *
 *                                                                      *
 *  NOTE: This program package is copyrighted in the sense that it      *
 *  may be used for scientific purposes. The package as a whole, or     *
 *  parts thereof, cannot be included or used in any commercial         *
 *  application without written permission granted by its producents.   *
 *  No programs contained in this package may be copied for commercial  *
 *  distribution.                                                       *
 *                                                                      *
 *  All comments  concerning this program package may be sent to the    *
 *  e-mail address 'lvq@cochlea.hut.fi'.                                *
 *                                                                      *
 ************************************************************************/

#include <stdio.h>
#include <float.h>
#include "lvq_pak.h"

struct entries *find_labels(struct entries *data, struct entries *codes)
{
  int *res, *cod;
  int *labs;
  int nol, noc, nos, i, j;
  int index, ind;
  int best, bnum;
  float diff, difference, diffsf;
  struct entries *codetmp;
  struct entries *datatmp;

  /* Number of data vectors */
  nol = 0;
  datatmp = data;
  while (datatmp != NULL) {
    nol++;
    datatmp = datatmp->next;
  }
  nos = nol;

  res = (int *) oalloc(sizeof(int)*nol);
  cod = (int *) oalloc(sizeof(int)*nol);

  /* Initialize all tables */
  for (i = 0; i < nol; i++) {
    res[i] = 0;
    cod[i] = 0;
  }

  /* Scan all data entries */
  datatmp = data;
  ind = 0;
  while (datatmp != NULL) {

    cod[ind] = datatmp->index;
    codetmp = codes;
    index = 0;
    diffsf = FLT_MAX;

    /* Compare data entry against the codebook entries */
    while (codetmp != NULL) {

      difference = 0.0;

      /* Compute the distance between codebook and input entry */
      for (i = 0; i < data->dimension; i++) {
	diff = codetmp->points[i] - datatmp->points[i];
	difference += diff * diff;
        if (difference > diffsf) break;
      }

      /* If distance is smaller than previous distances */
      if (difference < diffsf) {
        res[ind] = index;
        diffsf = difference;
      }

      /* Take the next code entry */
      codetmp = codetmp->next;
      index++;
    }

    /* Take the next data entry */
    datatmp = datatmp->next;
    ind++;

    if (verbose(-1) > 0)
      mprint((long) nol--);
  }
  if (verbose(-1) > 0)
    mprint((long) 0);
  if (verbose(-1) > 0)
    fprintf(stdout, "\n");

  /* Set the label of codebook entries according the selections */
  noc = number_of_labels();
  labs = (int *) oalloc(sizeof(int)*noc);
  codetmp = codes;
  index = 0;

  while (codetmp != NULL) {
    for (i = 0; i < noc; i++) {
      labs[i] = 0;
    }

    for (i = 0; i < nos; i++) {
      if (res[i] == index) {
        labs[cod[i]]++;
      }
    }

    best = -1;
    bnum = 0;
    for (i = 0; i < noc; i++) {
      if (labs[i] > bnum) {
        bnum = labs[i];
        best = i;
      }
    }

    if (best != -1) {
      codetmp->index = best;
    }

    codetmp = codetmp->next;
    index++;
  }

  return(codes);
}

main(int argc, char **argv)
{
  char *in_data_file;
  char *in_code_file;
  char *out_code_file;
  struct entries *data, *codes;

  in_data_file = extract_parameter(argc, argv, IN_DATA_FILE, ALWAYS);
  in_code_file = extract_parameter(argc, argv, IN_CODE_FILE, ALWAYS);
  out_code_file = extract_parameter(argc, argv, OUT_CODE_FILE, ALWAYS);
  verbose((int) oatoi(extract_parameter(argc, argv, VERBOSE, OPTION), 1));

  if (verbose(-1) > 1)
    fprintf(stdout, "Input entries are read from file %s\n", in_data_file);
  data = read_entries(in_data_file);

  label_not_needed(1);
  if (verbose(-1) > 1)
    fprintf(stdout, "Codebook entries are read from file %s\n", in_code_file);
  codes = read_entries(in_code_file);

  if (codes->topol < topol_type("hexa")) {
    printf("File %s is not a map file\n", in_code_file);
    exit(0);
  }

  if (data->dimension != codes->dimension) {
    errormsg("Data and codebook vectors have different dimensions");
    exit(0);
  }

  codes = find_labels(data, codes);

  if (verbose(-1) > 1)
    fprintf(stdout, "Codebook entries are saved to file %s\n", out_code_file);
  save_entries(codes, out_code_file);

  return(0);
}
