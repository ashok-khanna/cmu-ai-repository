/************************************************************************
 *                                                                      *
 *  Program package 'som_pak':                                          *
 *                                                                      *
 *  gvisual.c                                                           *
 *  -draw the values of one weight plane to graphics (in SGI-machines)  *
 *   and the trajectory (if there is data)                              *
 *                                                                      *
 *  Version 1.0                                                         *
 *  Date: 9 Oct 1992                                                    *
 *                                                                      *
 *  NOTE: This program package is copyrighted in the sense that it      *
 *  may be used for scientific purposes. The package as a whole, or     *
 *  parts thereof, cannot be included or used in any commercial         *
 *  application without written permission granted by its producents.   *
 *  No programs contained in this package may be copied for commercial  *
 *  distribution.                                                       *
 *                                                                      *
 *  All comments  concerning this program package may be sent to the    *
 *  e-mail address 'lvq@cochlea.hut.fi'.                                *
 *                                                                      *
 ************************************************************************/

#include <stdio.h>
#include <float.h>
#include <math.h>
#include <gl/gl.h>
#include <gl/device.h>
#include "lvq_pak.h"

void draw_plane(struct entries *data, struct entries *codes, int plane)
{
  short val;
  int cv;
  int i;
  int xsize, ysize;
  int xp, yp;
  int index;
  int offset = 0;
  int oplane = 0;
  long gwin;
  float maxval, minval;
  float diff, diffsf, difference;
  struct entries *codetmp;
  struct entries *datatmp;
  Device dev;
  short reds[64], greens[64], blues[64];

  if (codes->topol = topol_type("hexa"))
    offset = 25;

  xsize = 50 * codes->xdim + offset;
  ysize = 50 * codes->ydim;

  foreground();
  prefsize(xsize, ysize);
  /* Open the graphics window */
  gwin = winopen("");

  /* Change the coordinate (0,0) to upper left corner */
  translate(0, ysize, 0);
  scale(1.0, -1.0, 0.0);

  /* Get mouse for quit detection */
  qdevice(LEFTMOUSE);

  for (i = 0; i < 64; i++) {
    cv = 255 * (float) i / 64.0;
    getmcolor((long) (i + 64), &reds[i], &greens[i], &blues[i]);
    mapcolor((long) (i + 64), cv, cv, cv);
  }

  /* indexing the tables by plane-1 */
  plane--;

  dev = LEFTMOUSE;
  do {
    if (plane < 0) plane = 0;
    if (plane >= codes->dimension) plane = codes->dimension-1;

    if (dev != REDRAW)

    /* Find the lower and upper limits for gray level scaling */
    minval = FLT_MAX;
    maxval = FLT_MIN;
    codetmp = codes;
    while (codetmp != NULL) {
      if (maxval < codetmp->points[plane])
	maxval = codetmp->points[plane];
      if (minval > codetmp->points[plane])
	minval = codetmp->points[plane];
      codetmp = codetmp->next;
    }
  
    /* Show plane in window bar */
    {
      char str[100];

      sprintf(str, "plane %d", plane+1);
      wintitle(str);
    }
    color(WHITE);
    clear();
  
    /* Show the gray level circles */
    index = 0;
    codetmp = codes;
    while (codetmp != NULL) {
      xp = 50 * (index % codes->xdim) + 25;
      yp = 50 * (index / codes->xdim) + 25;
      if (((index / codes->xdim) % 2)) xp += offset;
  
      cv = (int) (52 * (codetmp->points[plane] - minval) /
				(maxval - minval));
      color(cv + 70);
      circfi(xp, yp, 22);
  
      /* If there is label then show it */
      if (codetmp->index != find_conv_to_ind(nolab())) {
	int len;
  
	len = strwidth(find_conv_to_lab(codetmp->index));
	cmov2i((int) (xp - len/2.0), yp);
	color(GREEN);
	charstr(find_conv_to_lab(codetmp->index));
      }
  
      codetmp = codetmp->next;
      index++;
    }
  
    /* If data values are present, draw trajectory */
    if (data != NULL) {
      long bel[2], cul[2];
      int bpos;
      int ind;
      int first = 1;
  
      datatmp = data;
      /* Scan all input entries */
      while (datatmp != NULL) {
    
	codetmp = codes;
	diffsf = FLT_MAX;
	ind = 0;
    
	/* Compare all codebook entries against the input entry */
	while (codetmp != NULL) {
    
	  difference = 0.0;
    
	  /* Compute the distance between the input and codebook entries */
	  for (i = 0; i < datatmp->dimension; i++) {
	    diff = datatmp->points[i] - codetmp->points[i];
	    difference += diff * diff;
            if (difference > diffsf) break;
	  }
    
	  /* If distance is smaller than the previous distances */
	  if (difference < diffsf) {
	    diffsf = difference;
	    bpos = ind;
	  }
    
	  /* Take the next codebook entry */
	  codetmp = codetmp->next;
	  ind++;
	}
  
	/* Draw the trajectory */
	if (first) {
	  first = 0;
	  color(YELLOW);
	  linewidth(3);
	  cul[0] = 50 * (bpos % codes->xdim) + 25;
	  cul[1] = 50 * (bpos / codes->xdim) + 25;
	  if (((bpos / codes->xdim) % 2)) cul[0] += offset;
	}
	else {
	  bel[0] = cul[0]; bel[1] = cul[1];
	  cul[0] = 50 * (bpos % codes->xdim) + 25;
	  cul[1] = 50 * (bpos / codes->xdim) + 25;
	  if (((bpos / codes->xdim) % 2)) cul[0] += offset;
	  bgnline();
	    v2i(bel);
	    v2i(cul);
	  endline();
	}
    
	/* Take the next input entry */
	datatmp = datatmp->next;
      }
    }

  }
  while ((dev = qread(&val)) != LEFTMOUSE);

  for (i = 0; i < 64; i++) {
    mapcolor((long) (i + 64), reds[i], greens[i], blues[i]);
  }

  gexit();
}

main(int argc, char **argv)
{
  int plane;
  char *in_code_file;
  char *in_data_file = NULL;
  struct entries *codes;
  struct entries *data = NULL;

  in_code_file = extract_parameter(argc, argv, IN_CODE_FILE, ALWAYS);
  in_data_file = extract_parameter(argc, argv, IN_DATA_FILE, OPTION);
  plane = (int) oatoi(extract_parameter(argc, argv, PLANE, OPTION), 1);
  verbose((int) oatoi(extract_parameter(argc, argv, VERBOSE, OPTION), 1));

  label_not_needed(1);
  if (verbose(-1) > 1)
    fprintf(stdout, "Codebook entries are read from file %s\n", in_code_file);
  codes = read_entries(in_code_file);

  if (codes->topol < topol_type("hexa")) {
    printf("File %s is not a map file\n", in_code_file);
    exit(0);
  }

  if (in_data_file != NULL) {
    if (verbose(-1) > 1)
      fprintf(stdout, "Data entries are read from file %s\n", in_data_file);
    data = read_entries(in_data_file);

    if (data->dimension > codes->dimension) {
      errormsg("Dimensions in data and codebook files are different");
      exit(0);
    }
  }

  if (plane > codes->dimension) {
    errormsg("Required plane is bigger than codebook vector dimension");
    exit(0);
  }

  draw_plane(data, codes, plane);

  return(0);
}
