/************************************************************************
 *                                                                      *
 *  Program package 'som_pak':                                          *
 *                                                                      *
 *  lininit.c                                                           *
 *  -initializes the codebook vectors fom SOM learning                  *
 *                                                                      *
 *  Version 1.0                                                         *
 *  Date: 9 Oct 1992                                                    *
 *                                                                      *
 *  NOTE: This program package is copyrighted in the sense that it      *
 *  may be used for scientific purposes. The package as a whole, or     *
 *  parts thereof, cannot be included or used in any commercial         *
 *  application without written permission granted by its producents.   *
 *  No programs contained in this package may be copied for commercial  *
 *  distribution.                                                       *
 *                                                                      *
 *  All comments  concerning this program package may be sent to the    *
 *  e-mail address 'lvq@cochlea.hut.fi'.                                *
 *                                                                      *
 ************************************************************************/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "lvq_pak.h"


main(int argc, char **argv)
{
  int number_of_codes;
  int randomize;
  int xdim, ydim;
  int topol;
  int neigh;
  char *in_data_file;
  char *out_code_file;
  struct entries *data, *codes;

  in_data_file = extract_parameter(argc, argv, IN_DATA_FILE, ALWAYS);
  out_code_file = extract_parameter(argc, argv, OUT_CODE_FILE, ALWAYS);

  verbose((int) oatoi(extract_parameter(argc, argv, VERBOSE, OPTION), 1));
  randomize = (int) oatoi(extract_parameter(argc, argv, RANDOM, OPTION), 0);

  topol = topol_type(extract_parameter(argc, argv, TOPOLOGY, ALWAYS));
  if (topol < 0) {
    if (verbose(-1) > 0)
      printf("Unknown topology type, using hexagonal\n");
    topol = topol_type("hexa");
  }
  neigh = neigh_type(extract_parameter(argc, argv, NEIGHBORHOOD, ALWAYS));
  if (neigh < 0) {
    if (verbose(-1) > 0)
      printf("Unknown neighborhood type, using bubble\n");
    neigh = neigh_type("bubble");
  }

  xdim = (int) oatoi(extract_parameter(argc, argv, XDIM, ALWAYS), 0);
  ydim = (int) oatoi(extract_parameter(argc, argv, YDIM, ALWAYS), 0);

  label_not_needed(1);
  if (verbose(-1) > 1)
    fprintf(stdout, "Input entries are read from file %s\n", in_data_file);
  data = read_entries(in_data_file);

  init_random(randomize);

  number_of_codes = xdim * ydim;
  if (number_of_codes <= 0) {
    printf("Dimensions of map (%d %d) are incorrect\n", xdim, ydim);
    exit(1);
  }
  if (xdim < 0) {
    printf("Dimensions of map (%d %d) are incorrect\n", xdim, ydim);
    exit(1);
  }

  codes = lininit_codes(number_of_codes, data, topol, neigh, xdim, ydim);

  if (verbose(-1) > 1)
    fprintf(stdout, "Codebook entries are saved to file %s\n", out_code_file);
  save_entries(codes, out_code_file);

  return(0);
}
