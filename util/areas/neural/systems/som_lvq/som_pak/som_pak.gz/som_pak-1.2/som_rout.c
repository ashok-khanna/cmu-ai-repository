/************************************************************************
 *                                                                      *
 *  Program package 'som_pak':                                          *
 *                                                                      *
 *  som_rout.c                                                          *
 *  -routines needed in some programs                                   *
 *                                                                      *
 *  Version 1.2                                                         *
 *  Date: 2 Nov 1992                                                    *
 *                                                                      *
 *  NOTE: This program package is copyrighted in the sense that it      *
 *  may be used for scientific purposes. The package as a whole, or     *
 *  parts thereof, cannot be included or used in any commercial         *
 *  application without written permission granted by its producents.   *
 *  No programs contained in this package may be copied for commercial  *
 *  distribution.                                                       *
 *                                                                      *
 *  All comments  concerning this program package may be sent to the    *
 *  e-mail address 'lvq@cochlea.hut.fi'.                                *
 *                                                                      *
 ************************************************************************/

#include <stdio.h>
#include <float.h>
#include <math.h>
#include <stdlib.h>
#include "lvq_pak.h"


/*---------------------------------------------------------------------*/

struct entries *randinit_codes(int number_of_codes, struct entries *data,
              int topol, int neigh, int xdim, int ydim)
{
  int i;
  struct entries tmp;
  struct entries *entr;
  struct entries *maval, *mival;

  tmp.next = NULL;
  entr = &tmp;

  for (i = 0; i < number_of_codes; i++) {
    entr->next = ecopy(data);
    entr = entr->next;
  }

  /* Find the maxim and minim values of data */
  maval = ecopy(data);
  mival = ecopy(data);
  for (i = 0; i < data->dimension; i++) {
    maval->points[i] = FLT_MIN;
    mival->points[i] = FLT_MAX;
  }
  entr = data;
  while (entr != NULL) {
    for (i = 0; i < entr->dimension; i++) {
      if (maval->points[i] < entr->points[i])
        maval->points[i] = entr->points[i];
      if (mival->points[i] > entr->points[i])
        mival->points[i] = entr->points[i];
    }

    entr = entr->next;
  }

  /* Randomize the vector values */
  entr = tmp.next;
  while (entr != NULL) {
    for (i = 0; i < entr->dimension; i++) {
      entr->points[i] = mival->points[i] +
          (maval->points[i] - mival->points[i]) * ((float) orand() / 32768.0);
    }
    entr->index = find_conv_to_ind(nolab());
    entr->topol = topol;
    entr->neigh = neigh;
    entr->xdim = xdim;
    entr->ydim = ydim;

    entr = entr->next;
  }

  entr = tmp.next;

  return(entr);
}

/*---------------------------------------------------------------------*/

void normalize(float *v, int n)
{
  float sum=0.0;
  int j;

  for (j=0; j<n; j++) sum+=v[j]*v[j];
  sum=sqrt(sum);
  for (j=0; j<n; j++) v[j]/=sum;
}


float dotprod(float *v, float *w, int n)
{
  float sum=0.0;
  int j;

  for (j=0; j<n; j++) sum+=v[j]*w[j];
  return (sum);
}


void gram_schmidt(float *v, int n, int e)
{
  int i, j, p, t;
  float sum, *w=(float*)malloc(n*e*sizeof(float));

  for (i=0; i<e; i++) {
    for (t=0; t<n; t++) {
      sum=v[i*n+t];
      for (j=0; j<i; j++)
	for (p=0; p<n; p++)
	  sum-=w[j*n+t]*w[j*n+p]*v[i*n+p];
      w[i*n+t]=sum;
    }
    normalize(w+i*n, n);
  }
  memcpy(v, w, n*e*sizeof(float));
  free(w);
}


struct entries *find_eigenvectors(struct entries *data)
{
  int n=data->dimension;
  float *r=(float*)malloc(n*n*sizeof(float));
  float *m=(float*)malloc(n*sizeof(float));
  float *u=(float*)malloc(2*n*sizeof(float));
  float *v=(float*)malloc(2*n*sizeof(float));
  float mu[2];
  struct entries *ptr, *tmp;
  float sum;
  int i, j, k;

  if (r==NULL || m==NULL || u==NULL || v==NULL ) goto everror;

  for (i=0; i<n*n/2; i++) r[i]=0.0;
  for (i=0; i<n; i++) m[i]=0.0;

  for (k=0, ptr=data; ptr!=NULL; k++, ptr=ptr->next)
    for (i=0; i<n; i++)
      m[i]+=ptr->points[i];
    
  if (k<3) goto everror;

  for (i=0; i<n; i++)
    m[i]/=k;

  for (ptr=data; ptr!=NULL; ptr=ptr->next)
    for (i=0; i<n; i++)
      for (j=i; j<n; j++)
	r[i*n+j]+=(ptr->points[i]-m[i])*(ptr->points[j]-m[j]);
  
  for (i=0; i<n; i++)
    for (j=i; j<n; j++)
      r[j*n+i]=r[i*n+j]/=k;

  for (i=0; i<2; i++) {
    for (j=0; j<n; j++) u[i*n+j]=orand()/16384.0-1.0;
    normalize(u+i*n, n);
    mu[i]=1.0;
  }

  for (k=0; k<10; k++) {
    for (i=0; i<2; i++)
      for (j=0; j<n; j++)
	v[i*n+j]=mu[i]*dotprod(r+j*n, u+i*n, n)+u[i*n+j];

    gram_schmidt(v, n, 2);

    sum=0.0;
    for (i=0; i<2; i++) {
      for (j=0; j<n; j++)
	sum+=fabs(v[i*n+j]/dotprod(r+j*n, v+i*n, n));

      mu[i]=sum/n;
    }

    memcpy(u, v, 2*n*sizeof(float));
  }

  if (mu[0]==0.0 || mu[1]==0.0) goto everror;
  
  tmp=ptr=ecopy(data);
  memcpy(ptr->points, m, n*sizeof(float));

  for (i=0; i<2; i++) {
    tmp->next=ecopy(data);
    tmp=tmp->next;

    memcpy(tmp->points, u+n*i, n*sizeof(float));
    for (j=0; j<n; j++)
      tmp->points[j]/=sqrt(mu[i]);
  }

  free(v);
  free(u);
  free(m);
  free(r);
  return (ptr);

 everror:
  if (v!=NULL) free(v);
  if (u!=NULL) free(u);
  if (m!=NULL) free(m);
  if (r!=NULL) free(r);
  return (NULL);

}

struct entries *lininit_codes(int number_of_codes, struct entries *data,
                   int topol, int neigh, int xdim, int ydim)
{
  int i;
  int index;
  float xf, yf;
  struct entries tmp;
  struct entries *mean;
  struct entries *eigen1;
  struct entries *eigen2;
  struct entries *entr;

  tmp.next = NULL;
  entr = &tmp;

  for (i = 0; i < number_of_codes; i++) {
    entr->next = ecopy(data);
    entr = entr->next;
  }

  /* Find the middle point and two eigenvectors of the data */
  mean = find_eigenvectors(data);
  if (mean == NULL) {
    printf("Can't find eigenvectors\n");
    exit(-1);
  }
  eigen1 = mean->next;
  eigen2 = eigen1->next;

  /* Initialize the units */
  entr = tmp.next;
  index = 0;
  while (entr != NULL) {
    xf = 4.0 * (float) (index % xdim) / (xdim - 1.0) - 2.0;
    yf = 4.0 * (float) (index / xdim) / (ydim - 1.0) - 2.0;

    for (i = 0; i < entr->dimension; i++) {
      entr->points[i] = mean->points[i] 
                + xf * eigen1->points[i] + yf * eigen2->points[i];
    }
    entr->index = find_conv_to_ind(nolab());
    entr->topol = topol;
    entr->neigh = neigh;
    entr->xdim = xdim;
    entr->ydim = ydim;

    entr = entr->next;
    index++;
  }

  entr = tmp.next;

  return(entr);
}

/*---------------------------------------------------------------------*/

float hexa_dist(int bx, int by, int tx, int ty)
{
  float ret, diff;

  diff = bx - tx;

  if (((by - ty) % 2) != 0) {
    if ((by % 2) == 0) {
      diff -= 0.5;
    }
    else {
      diff += 0.5;
    }
  }

  ret = diff * diff;
  diff = by - ty;
  ret += 0.75 * diff * diff;
  ret = (float) sqrt((double) ret);

  return(ret);
}

float rect_dist(int bx, int by, int tx, int ty)
{
  float ret, diff;

  diff = bx - tx;
  ret = diff * diff;
  diff = by - ty;
  ret += diff * diff;
  ret = (float) sqrt((double) ret);

  return(ret);
}

void bubble_adapt(struct entries *codes, struct entries *sample,
                     int bx, int by, float radius, float alpha)
{
  int i;
  int index;
  int tx, ty;
  float (*dist)(int x, int y, int tx, int ty);
  struct entries *codetmp;

  if (verbose(-1) > 2)
    printf("Best match in %d, %d\n", bx, by);

  if (codes->topol == topol_type("hexa")) {
    dist = hexa_dist;
  }
  else if (codes->topol == topol_type("rect")) {
    dist = rect_dist;
  }
  else {
    if (verbose(-1) > 1)
      printf("Unknown topology type, using hexagonal\n");
    dist = hexa_dist;
  }

  codetmp = codes;
  index = 0;

  while (codetmp != NULL) {
    tx = index % codetmp->xdim;
    ty = index / codetmp->xdim;

    if (dist(bx, by, tx, ty) <= radius) {
      if (verbose(-1) > 3)
        printf("Adapt unit %d, %d\n", tx, ty);

      for (i = 0; i < codes->dimension; i++) {
        codetmp->points[i] += alpha *
                   (sample->points[i] - codetmp->points[i]);
      }
    }

    codetmp = codetmp->next;
    index++;
  }
}

void gaussian_adapt(struct entries *codes, struct entries *sample,
                     int bx, int by, float radius, float alpha)
{
  int i;
  int index;
  int tx, ty;
  float (*dist)(int x, int y, int tx, int ty);
  float dd;
  float alp;
  struct entries *codetmp;

  if (verbose(-1) > 2)
    printf("Best match in %d, %d\n", bx, by);

  if (codes->topol == topol_type("hexa")) {
    dist = hexa_dist;
  }
  else if (codes->topol == topol_type("rect")) {
    dist = rect_dist;
  }
  else {
    if (verbose(-1) > 1)
      printf("Unknown topology type, using hexagonal\n");
    dist = hexa_dist;
  }

  codetmp = codes;
  index = 0;

  while (codetmp != NULL) {
    tx = index % codetmp->xdim;
    ty = index / codetmp->xdim;

    if (verbose(-1) > 3)
      printf("Adapt unit %d, %d\n", tx, ty);
    dd = dist(bx, by, tx, ty);

    alp = alpha *
           (float) exp((double) (-dd * dd / (2.0 * radius * radius)));

    for (i = 0; i < codes->dimension; i++) {
      codetmp->points[i] += alp *
		 (sample->points[i] - codetmp->points[i]);
    }

    codetmp = codetmp->next;
    index++;
  }
}

struct entries *som_training(struct entries *data, struct entries *codes,
                       long length, float alpha, float radius)
{
  void (*adapt)(struct entries *codes, struct entries *sample,
           int bx, int by, float radius, float alpha);
  int i;
  int bxind, byind;
  int index;
  int le;
  float weight;
  float diffsf, difference, diff;
  float trad, talp;
  struct entries *sample;
  struct entries *codetmp;

  if (codes->neigh == neigh_type("bubble")) {
    adapt = bubble_adapt;
  }
  else if (codes->neigh == neigh_type("gaussian")) {
    adapt = gaussian_adapt;
  }
  else {
    if (verbose(-1) > 1)
      printf("Unknown neighborhood type, using bubble\n");
    adapt = bubble_adapt;
  }

  sample = data;

  for (le = 0; le < length; le++) {
    /* Get the next sample */
    /* The straight next in list is implemented */
    sample = sample->next;
    if (sample == NULL) {
      sample = data;
    }
    weight = sample->weight;

    /* Radius decreases linearly to one */
    trad = 1.0 + (radius - 1.0) * (float) (length - le) / (float) length;
    /* Alpha decreases linearly to zero */
    talp = alpha * (float) (length - le) / (float) length;

    /* If the sample is weighted, we
       modify the training rate so that we achieve the same effect as
       repeating the sample 'weight' times */
    if ((weight > 0.0) && (use_weights(-1))) {
      talp = 1.0 - (float) pow((double) (1.0 - talp), (double) weight);
    }

    /* Find the best match */
    /* If fixed point and is allowed then use that value */
    if ((sample->fixed != NULL) && (use_fixed(-1))) {
      /* Get the values from fixed-structure */
      bxind = sample->fixed->xfix;
      byind = sample->fixed->yfix;
    }
    else {
      /* Go through all code vectors */
      codetmp = codes;
      diffsf = FLT_MAX;
      index = 0;
      while (codetmp != NULL) {
	difference = 0.0;
  
	/* Compute the distance between codebook and input entry */
	for (i = 0; i < sample->dimension; i++) {
	  diff = codetmp->points[i] - sample->points[i];
	  difference += diff * diff;
          if (difference > diffsf) break;
	}
  
	/* If distance is smaller than previous distances */
	if (difference < diffsf) {
	  bxind = index % codetmp->xdim;
	  byind = index / codetmp->xdim;
	  diffsf = difference;
	}
  
	codetmp = codetmp->next;
	index++;
      }
    }

    /* Adapt the units */
    adapt(codes, sample, bxind, byind, trad, talp);

    if (verbose(-1) > 0)
      mprint((long) (length-le));
  }
  if (verbose(-1) > 0)
    mprint((long) 0);
  if (verbose(-1) > 0)
    fprintf(stdout, "\n");

  return(codes);
}

/*---------------------------------------------------------------------*/

float find_qerror(struct entries *data, struct entries *codes)
{
  int i;
  int nol;
  float diff, difference, diffsf;
  float qerror;
  struct entries *codetmp;
  struct entries *datatmp;

  /* The number of data entries */
  datatmp = data;
  nol = 0;
  while (datatmp != NULL) {
    datatmp = datatmp->next;
    nol++;
  }

  /* Scan all data entries */
  datatmp = data;
  qerror = 0.0;

  while (datatmp != NULL) {

    codetmp = codes;
    diffsf = FLT_MAX;

    /* Compare data entry against the codebook entries */
    while (codetmp != NULL) {

      difference = 0.0;

      /* Compute the distance between codebook and input entry */
      for (i = 0; i < data->dimension; i++) {
	diff = codetmp->points[i] - datatmp->points[i];
	difference += diff * diff;
        if (difference > diffsf) break;
      }

      /* If distance is smaller than previous distances */
      if (difference < diffsf) {
        diffsf = difference;
      }

      /* Take the next code entry */
      codetmp = codetmp->next;
    }

    /* Take the next data entry */
    datatmp = datatmp->next;
    qerror += sqrt((double) diffsf);

    if (verbose(-1) > 0)
      mprint((long) nol--);
  }
  if (verbose(-1) > 0)
    mprint((long) 0);
  if (verbose(-1) > 0)
    fprintf(stdout, "\n");

  return(qerror);
}

/*---------------------------------------------------------------------*/

/*---------------------------------------------------------------------*/




