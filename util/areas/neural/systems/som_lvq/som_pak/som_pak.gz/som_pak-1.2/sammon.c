/************************************************************************
 *                                                                      *
 *  Program packages 'lvq_pak' and 'som_pak' :                          *
 *                                                                      *
 *  sammon.c                                                            *
 *  -generates a Sammon mapping from a given list                       *
 *                                                                      *
 *  Version 2.1                                                         *
 *  Date: 9 Oct 1992                                                    *
 *                                                                      *
 *  NOTE: This program package is copyrighted in the sense that it      *
 *  may be used for scientific purposes. The package as a whole, or     *
 *  parts thereof, cannot be included or used in any commercial         *
 *  application without written permission granted by its producents.   *
 *  No programs contained in this package may be copied for commercial  *
 *  distribution.                                                       *
 *                                                                      *
 *  All comments  concerning this program package may be sent to the    *
 *  e-mail address 'lvq@cochlea.hut.fi'.                                *
 *                                                                      *
 ************************************************************************/

#include <stdio.h>
#include <math.h>
#include "lvq_pak.h"
  
#define TRUE  1
#define FALSE 0
#define MAGIC 0.2
  
#define max(x,y) ((x) > (y) ? (x) : (y))
#define min(x,y) ((x) < (y) ? (x) : (y))


float distance(struct entries *ind1, struct entries *ind2)
{
  int i;
  float sum = 0.0;	/* sum of all components */
  float x;		/* subsidiary variable */
  
  for (i = 0; i < ind1->dimension; i++) {
    x = ind1->points[i] - ind2->points[i];
    sum += x * x;
  }

  sum = (float) sqrt((double) sum);
  
  return(sum);
}

struct entries *remove_identicals(struct entries *codes)
{
  struct entries *entr, *entr1;
  struct entries *tmp;

  /* Compute the mutual distances between entries */
  /* Remove the identical entries from the list */
  entr = codes->next;
  while (entr != NULL) {
    entr1 = codes;
    while (entr1 != entr) {
      if (distance(entr, entr1) == 0.0) {
	printf("Identical entries in codebook, removing one\n");
	tmp = codes;
	while (tmp->next != entr)
	  tmp = tmp->next;
	tmp->next = entr->next;
	entr1 = entr;
      }
      else {
        entr1 = entr1->next;
      }
    }
    entr = entr->next;
  }
  
  return(codes);
}

struct entries *sammon_iterate(struct entries *codes, int length)
{
  int i, j, k;
  int noc = 0;
  float e1x, e1y, e2x, e2y;
  float dpj;
  float dq, dr, dt;
  struct entries *entr, *entr1;
  float *x, *y;
  float *xu, *yu, *dd;
  float xd, yd;
  float xx, yy;
  float e, tot;
  int mutual;
  float d, ee;

  /* How many entries? */
  entr = codes;
  while (entr != NULL) {
    entr = entr->next;
    noc++;
  }
  if (verbose(-1) > 2)
    fprintf(stdout, "%d entries in codebook\n", noc);

  /* Allocate dynamical memory */
  x = (float *) oalloc(sizeof(float) * noc);
  y = (float *) oalloc(sizeof(float) * noc);
  xu = (float *) oalloc(sizeof(float) * noc);
  yu = (float *) oalloc(sizeof(float) * noc);
  dd = (float *) oalloc(sizeof(float) * (noc * (noc - 1) / 2));

  /* Initialize the tables */
  for (i = 0; i < noc; i++) {
    x[i] = (float) (orand() % noc) / noc;
    y[i] = (float) (i) / noc;
  }

  /* Compute the mutual distances between entries */
  mutual = 0;
  entr = codes->next;
  for (j = 1; j < noc; j++) {
    entr1 = codes;
    for (k = 0; k < j; k++) {
      dd[mutual] = distance(entr, entr1);
      if (dd[mutual] == 0.0) {
	printf("Identical entries in codebook\n");
      }
      mutual++;
      entr1 = entr1->next;
    }
    entr = entr->next;
  }
  
  /* Iterate */
  for (i = 0; i < length; i++) {
    for (j = 0; j < noc; j++) {
      e1x = e1y = e2x = e2y = 0.0;
      for (k = 0; k < noc; k++) {
	if (j == k)
	  continue;
	xd = x[j] - x[k];
	yd = y[j] - y[k];
	dpj = (float) sqrt((double) xd * xd + yd * yd);

	/* Calculate derivatives */
	if (k > j)
	  dt = dd[k * (k - 1) / 2 + j];
	else
	  dt = dd[j * (j - 1) / 2 + k];
	dq = dt - dpj;
	dr = dt * dpj;
	e1x += xd * dq / dr;
	e1y += yd * dq / dr;
	e2x += (dq - xd * xd * (1.0 + dq / dpj) / dpj) / dr;
	e2y += (dq - yd * yd * (1.0 + dq / dpj) / dpj) / dr;
      }
      /* Correction */
      xu[j] = x[j] + MAGIC * e1x / fabs(e2x);
      yu[j] = y[j] + MAGIC * e1y / fabs(e2y);
    }
    
    /* Move the center of mass to the center of picture */
    xx = yy = 0.0;
    for (j = 0; j < noc; j ++) { 
      xx += xu[j];
      yy += yu[j];
    }
    xx /= noc;
    yy /= noc;
    for (j = 0; j < noc; j ++) {
      x[j] = xu[j] - xx;
      y[j] = yu[j] - yy;
    }
    
    /* Error in distances */
    e = tot = 0.0;
    mutual = 0;
    for (j = 1; j < noc; j ++)
      for (k = 0; k < j; k ++) {
	d = dd[mutual];
	tot += d;
	xd = x[j] - x[k];
	yd = y[j] - y[k];
	ee = d - (float) sqrt((double) xd * xd + yd * yd);
	e += (ee * ee / d);
	mutual++;
      }
    e /= tot;
    if (verbose(-1) > 1)
      fprintf(stdout, "Mapping error: %7.3f\n", e);
    if (verbose(-1) == 1)
      mprint((long) (length-i));
  }
  if (verbose(-1) == 1)
    mprint((long) 0);
  if (verbose(-1) == 1)
    fprintf(stdout, "\n");

  /* Copy the data to return variable */
  entr = (struct entries *) oalloc(sizeof(struct entries));
  entr->points = (float *) oalloc(sizeof(float) * 2);
  entr->points[0] = x[0];
  entr->points[1] = y[0];
  entr->index = codes->index;
  entr->dimension = 2;
  entr1 = entr;
  for (i = 1; i < noc; i++) {
    entr1->next = ecopy(entr);
    entr1 = entr1->next;
    codes = codes->next;
    entr1->points[0] = x[i];
    entr1->points[1] = y[i];
    entr1->index = codes->index;
    entr1->dimension = 2;
    entr->xdim = codes->xdim;
    entr->ydim = codes->ydim;
  }

  return(entr);
}

main(int argc, char **argv)
{
  int length;
  int randomize;
  char *in_code_file;
  char *out_code_file;
  struct entries *codes;
  struct entries *spics;
  
  in_code_file = extract_parameter(argc, argv, IN_CODE_FILE, ALWAYS);
  out_code_file = extract_parameter(argc, argv, OUT_CODE_FILE, ALWAYS);
  length = (int) oatoi(extract_parameter(argc, argv, RUNNING_LENGTH, ALWAYS),
                       1);
  verbose((int) oatoi(extract_parameter(argc, argv, VERBOSE, OPTION), 1));
  randomize = (int) oatoi(extract_parameter(argc, argv, RANDOM, OPTION), 0);
  
  label_not_needed(1);
  if (verbose(-1) > 1)
    fprintf(stdout, "Code entries from file %s\n", in_code_file);
  codes = read_entries(in_code_file);

  init_random(randomize);

  /* Remove identical entries from the codebook */
  codes = remove_identicals(codes);
  
  spics = sammon_iterate(codes, length);
  
  if (verbose(-1) > 1)
    fprintf(stdout, "Save code entries to file %s\n", out_code_file);
  save_entries(spics, out_code_file);

  return(0);
}


