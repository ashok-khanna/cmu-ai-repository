/************************************************************************
 *                                                                      *
 *  Program package 'som_pak':                                          *
 *                                                                      *
 *  visual.c                                                            *
 *  -finds out the best matching unit in map and produces a file        *
 *   containing a line for each input sample, in each line the          *
 *   coordinates of the best macth and the quantization error           *
 *   are given as well as the label if there is any                     *
 *                                                                      *
 *  Version 1.0                                                         *
 *  Date: 9 Oct 1992                                                    *
 *                                                                      *
 *  NOTE: This program package is copyrighted in the sense that it      *
 *  may be used for scientific purposes. The package as a whole, or     *
 *  parts thereof, cannot be included or used in any commercial         *
 *  application without written permission granted by its producents.   *
 *  No programs contained in this package may be copied for commercial  *
 *  distribution.                                                       *
 *                                                                      *
 *  All comments  concerning this program package may be sent to the    *
 *  e-mail address 'lvq@cochlea.hut.fi'.                                *
 *                                                                      *
 ************************************************************************/

#include <stdio.h>
#include <float.h>
#include <math.h>
#include "lvq_pak.h"

struct entries *compute_visual_data(struct entries *data, struct entries *codes)
{
  int *res;
  int *tot;
  int nol, i, noc;
  int index;
  int ind, bpos;
  float diff, difference, diffsf;
  struct entries *codetmp;
  struct entries *datatmp;

  /* Number of data vectors */
  noc = 0;
  datatmp = data;
  while (datatmp != NULL) {
    noc++;
    datatmp = datatmp->next;
  }

  datatmp = data;
  /* Scan all input entries */
  while (datatmp != NULL) {

    codetmp = codes;
    diffsf = FLT_MAX;
    ind = 0;

    /* Compare all codebook entries against the input entry */
    while (codetmp != NULL) {

      difference = 0.0;

      /* Compute the distance between the input and codebook entries */
      for (i = 0; i < datatmp->dimension; i++) {
	diff = datatmp->points[i] - codetmp->points[i];
	difference += diff * diff;
        if (difference > diffsf) break;
      }

      /* If distance is smaller than the previous distances */
      if (difference < diffsf) {
	diffsf = difference;
	index = codetmp->index;
        bpos = ind;
      }

      /* Take the next codebook entry */
      codetmp = codetmp->next;
      ind++;
    }

    /* Save the classification and coordinates */
    datatmp->index = index;
    datatmp->points[0] = bpos % codes->xdim;
    datatmp->points[1] = bpos / codes->xdim;
    /* And the quantization error */
    datatmp->points[2] = sqrt((double) diffsf);
    /* Modify the dimension also */
    datatmp->dimension = 3;

    /* Take the next input entry */
    datatmp = datatmp->next;

    if (verbose(-1) > 0)
      mprint((long) noc--);
  }
  if (verbose(-1) > 0)
    mprint((long) 0);
  if (verbose(-1) > 0)
    fprintf(stdout, "\n");

  return(data);
}

main(int argc, char **argv)
{
  char *in_data_file;
  char *out_data_file;
  char *in_code_file;
  struct entries *data, *codes;

  in_data_file = extract_parameter(argc, argv, IN_DATA_FILE, ALWAYS);
  in_code_file = extract_parameter(argc, argv, IN_CODE_FILE, ALWAYS);
  out_data_file = extract_parameter(argc, argv, OUT_DATA_FILE, ALWAYS);
  verbose((int) oatoi(extract_parameter(argc, argv, VERBOSE, OPTION), 1));

  label_not_needed(1);
  if (verbose(-1) > 1)
    fprintf(stdout, "Input entries are read from file %s\n", in_data_file);
  data = read_entries(in_data_file);

  if (verbose(-1) > 1)
    fprintf(stdout, "Codebook entries are read from file %s\n", in_code_file);
  codes = read_entries(in_code_file);

  if (codes->topol < topol_type("hexa")) {
    printf("File %s is not a map file\n", in_code_file);
    exit(0);
  }

  if (data->dimension != codes->dimension) {
    errormsg("Data and codebook vectors have different dimensions");
    exit(0);
  }

  data = compute_visual_data(data, codes);

  data->topol = codes->topol;
  data->neigh = codes->neigh;
  data->xdim = codes->xdim;
  data->ydim = codes->ydim;

  if (verbose(-1) > 1)
    fprintf(stdout, "Output entries are saved to file %s\n", out_data_file);
  save_entries(data, out_data_file);

  return(0);
}
