/************************************************************************
 *                                                                      *
 *  Program package 'som_pak':                                          *
 *                                                                      *
 *  qerror.c                                                            *
 *  -give the quantization error for the data entries                   *
 *                                                                      *
 *  Version 1.0                                                         *
 *  Date: 9 Oct 1992                                                    *
 *                                                                      *
 *  NOTE: This program package is copyrighted in the sense that it      *
 *  may be used for scientific purposes. The package as a whole, or     *
 *  parts thereof, cannot be included or used in any commercial         *
 *  application without written permission granted by its producents.   *
 *  No programs contained in this package may be copied for commercial  *
 *  distribution.                                                       *
 *                                                                      *
 *  All comments  concerning this program package may be sent to the    *
 *  e-mail address 'lvq@cochlea.hut.fi'.                                *
 *                                                                      *
 ************************************************************************/

#include <stdio.h>
#include <float.h>
#include <math.h>
#include "lvq_pak.h"

main(int argc, char **argv)
{
  int nod;
  float qerror;
  char *in_data_file;
  char *in_code_file;
  struct entries *data, *codes;
  struct entries *datatmp;

  in_data_file = extract_parameter(argc, argv, IN_DATA_FILE, ALWAYS);
  in_code_file = extract_parameter(argc, argv, IN_CODE_FILE, ALWAYS);
  verbose((int) oatoi(extract_parameter(argc, argv, VERBOSE, OPTION), 1));

  label_not_needed(1);
  if (verbose(-1) > 1)
    fprintf(stdout, "Input entries are read from file %s\n", in_data_file);
  data = read_entries(in_data_file);

  if (verbose(-1) > 1)
    fprintf(stdout, "Codebook entries are read from file %s\n", in_code_file);
  codes = read_entries(in_code_file);

  if (codes->topol < topol_type("hexa")) {
    printf("File %s is not a map file\n", in_code_file);
    exit(0);
  }

  if (data->dimension != codes->dimension) {
    errormsg("Data and codebook vectors have different dimensions");
    exit(0);
  }

  /* Find the number of data points */
  datatmp = data;
  nod = 0;
  while (datatmp != NULL) {
    nod++;
    datatmp = datatmp->next;
  }

  qerror = find_qerror(data, codes);

  if (verbose(-1) > 0)
    fprintf(stdout, "Quantization error of %s with map %s is ",
             in_data_file, in_code_file);
  fprintf(stdout, "%f per sample\n", qerror / (float) nod);

  return(0);
}
