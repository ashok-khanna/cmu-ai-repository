/**********************************************************************
 * $Id: utils.h,v 1.1 93/01/26 10:46:13 drew Exp $
 * 
 * Cascade Correlation Module
 *
 * Originally written by:
 * 	Brion Dolenko
 * 	The University of Manitoba
 * 	Winnipeg, Manitoba, Canada
 *
 * Modified by: 
 *	Drew van Camp
 **********************************************************************/

/**********************************************************************
 *   Copyright 1990,1991,1992,1993 by The University of Toronto,
 *		      Toronto, Ontario, Canada.
 * 
 *			 All Rights Reserved
 * 
 * Permission to use, copy, modify, distribute, and sell this software
 * and its  documentation for  any purpose is  hereby granted  without
 * fee, provided that the above copyright notice appears in all copies
 * and  that both the  copyright notice  and   this  permission notice
 * appear in   supporting documentation,  and  that the  name  of  The
 * University  of Toronto  not  be  used in  advertising or  publicity
 * pertaining   to  distribution   of  the  software without specific,
 * written prior  permission.   The  University of   Toronto makes  no
 * representations  about  the  suitability of  this software  for any
 * purpose.  It  is    provided   "as is"  without express or  implied
 * warranty.
 *
 * THE UNIVERSITY OF TORONTO DISCLAIMS  ALL WARRANTIES WITH REGARD  TO
 * THIS SOFTWARE,  INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS, IN NO EVENT SHALL THE UNIVERSITY OF TORONTO  BE LIABLE
 * FOR ANY  SPECIAL, INDIRECT OR CONSEQUENTIAL  DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR  PROFITS, WHETHER IN
 * AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING
 * OUT  OF  OR  IN  CONNECTION WITH  THE  USE  OR PERFORMANCE  OF THIS
 * SOFTWARE.
 *
 **********************************************************************/

#ifndef __cascor_utils_h
#define __cascor_utils_h

/*
 * These routines connect a unit to another unit, or another unit to
 * a unit. The other unit is passed in as data
 */
extern void	connectTo   ARGS((Unit, void *)) ;
extern void	connectFrom ARGS((Unit, void *)) ;

/*
 * All of these routines act on either the INCOMING or OUTGOING 
 * links of a unit. The mask is passed as the data. They do not act
 * on both masks at once.
 */
extern void	freezeLinks	ARGS((Unit unit, void *data));
extern void	unfreezeLinks	ARGS((Unit unit, void *data));
extern void	randomizeLinks	ARGS((Unit unit, void *data));
extern void	zeroLinks	ARGS((Unit unit, void *data));

/* routine to compute unit activations */ 
extern Proc	unitForward	ARGS((Unit));

/* routine to calculate output unit error */
extern Real	unitError	ARGS((Unit	unit));

/* zero derivative fields in a unit */
extern void	zeroUnitDerivs	ARGS((Unit unit, void *data)) ;

/* 
 * zero the sum and example number fields, plus partial scores
 * scores in candidate unit outgoing links
 */
extern void	zeroSums	ARGS((Unit unit, void *data));

/* return the x^2 */
extern Real	square		ARGS((double x));

#endif				/*  __cascor_utils_h */
