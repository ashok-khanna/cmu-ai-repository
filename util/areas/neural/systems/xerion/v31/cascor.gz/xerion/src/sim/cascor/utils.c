/**********************************************************************
 * $Id: utils.c,v 1.1 93/01/26 10:46:12 drew Exp $
 * 
 * Cascade Correlation Module
 *
 * Originally written by:
 * 	Brion Dolenko
 * 	The University of Manitoba
 * 	Winnipeg, Manitoba, Canada
 *
 * Modified by: 
 *	Drew van Camp
 **********************************************************************/

/**********************************************************************
 *   Copyright 1990,1991,1992,1993 by The University of Toronto,
 *		      Toronto, Ontario, Canada.
 * 
 *			 All Rights Reserved
 * 
 * Permission to use, copy, modify, distribute, and sell this software
 * and its  documentation for  any purpose is  hereby granted  without
 * fee, provided that the above copyright notice appears in all copies
 * and  that both the  copyright notice  and   this  permission notice
 * appear in   supporting documentation,  and  that the  name  of  The
 * University  of Toronto  not  be  used in  advertising or  publicity
 * pertaining   to  distribution   of  the  software without specific,
 * written prior  permission.   The  University of   Toronto makes  no
 * representations  about  the  suitability of  this software  for any
 * purpose.  It  is    provided   "as is"  without express or  implied
 * warranty.
 *
 * THE UNIVERSITY OF TORONTO DISCLAIMS  ALL WARRANTIES WITH REGARD  TO
 * THIS SOFTWARE,  INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS, IN NO EVENT SHALL THE UNIVERSITY OF TORONTO  BE LIABLE
 * FOR ANY  SPECIAL, INDIRECT OR CONSEQUENTIAL  DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR  PROFITS, WHETHER IN
 * AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING
 * OUT  OF  OR  IN  CONNECTION WITH  THE  USE  OR PERFORMANCE  OF THIS
 * SOFTWARE.
 *
 **********************************************************************/

#include <stdio.h>
#include <math.h>

#include <xerion/useful.h>
#include <xerion/simulator.h>
#include <xerion/sigmoid.h>
#include "cascor.h"
#include "utils.h"

#ifdef __osf__
#define srandom(x)	srand((unsigned int)x)
#define random()	rand()
#define MAXINT		RAND_MAX
#else
#ifndef MAXINT
#define MAXINT	(~(int)(1 << sizeof(int)*8 - 1))
#endif
#endif

static Real	randReal ARGS((double centre, double field));

/***********************************************************************
 *	Name:		unitForward
 *	Description:	Standard neuron activation function.
 *			Sum the inputs and pass the result through a
 *			sigmoid.
 *	Parameters:	
 *		Unit	unit - the unit of concern
 *	Return Value:	
 *		NONE
 ************************************************************************/
void	unitForward(unit)
  Unit	unit ;
{
  Net	net	    = unit->net ;
  int	numIncoming = unit->numIncoming ;
  Link	*incoming   = unit->incomingLink ;
  Real	totalInput  = 0.0 ;
  int	idx ;

  for (idx = 0 ; idx < numIncoming ; ++idx) {
    Link        link = incoming[idx] ;
    totalInput += link->weight * link->preUnit->output;
  }
  unit->totalInput = totalInput ;
  unit->output	   = MSsigmoid(Msigmoid(net), totalInput) ;

  /* update net error */
  if ((unit->group->type & OUTPUT) && MtrainingOutputs(net))
    unit->net->error += square(unitError(unit));
}
/*********************************************************************/


/***********************************************************************
 *	Name:		unitError
 *	Description:	calculates the error value of a unit assuming
 *			a zeroErrorRadius
 *	Parameters:	
 *		const Unit	unit - the unit to calclate the error of
 *	Return Value:	
 *		Real		unitError - the error of the unit
 ***********************************************************************/
Real		unitError(unit)
  const Unit	unit ;
{
  Real	target = unit->target ;
  Real	radius = MzeroErrorRadius(unit->net) ;

  if (radius > 0.0) {
    Real	upper = target + radius ;
    Real	lower = target - radius ;
    if (unit->output > upper)
      target = upper ;
    else if (unit->output < lower)
      target = lower ;
    else
      target = unit->output ;
  } 

  return unit->output - target ;
}
/*********************************************************************/


/*********************************************************************
 *	Name:		zeroUnitDerivs
 *	Description:	zeroes the deriv fields in a unit
 *	Parameters:
 *	  Unit		unit  - the unit to zero
 *	  void		*data - UNUSED
 *	Return Value:
 *	  void	zeroUnitDerivs - NONE
 **********************************************************************/
void	zeroUnitDerivs(unit, data)
  Unit	unit ;
  void	*data ;
{
  unit->inputDeriv  = 0.0 ;
  unit->outputDeriv = 0.0 ;
}
/*********************************************************************/


/*********************************************************************
 *	Name:		zeroSums
 *	Description:	zeroes the sum and example number fields in 
 *			a unit and it's outgoing links if it is
 *			a candidate unit
 *	Parameters:
 *	  Unit		unit  - the unit whose fields are to be zeroed
 *	  void		*data - UNUSED
 *	Return Value:
 *	  static void	zeroSums - NONE
 *********************************************************************/
void	zeroSums(unit, data)
  Unit	unit ;
  void	*data ;
{
  MactivationSum(unit)	= 0.0;
  MactivationAvg(unit)	= 0.0;
  MerrorSum(unit)	= 0.0;
  MerrorAvg(unit)	= 0.0;
  McorrScore(unit)	= 0.0;
  MnumExamples(unit)	= 0;

  if (unit->group->type & CANDIDATE) {
    Link	*link	 = unit->outgoingLink;
    int		numLinks = unit->numOutgoing;
    int		idx;

    /* zero partial correlation scores, stored in the outgoing links */
    for (idx = 0; idx < numLinks ; ++idx)
      MpartialCorrScore(link[idx]) = 0.0;
  }
}
/********************************************************************/


/*********************************************************************
*	Name:		square
*	Description:	squares a real valued number
*	Parameters:
*	  double	x - the number to square
*	Return Value:
*	  Real	square - x^2
**********************************************************************/
Real	 square(x)
  double x ;
{
  return (Real) (x * x) ;
}
/********************************************************************/

/*********************************************************************
 *	Name:		connectTo/connectFrom
 *	Description:	connects a unit to/from another unit passed
 *			in as data.
 *	Parameters:
 *	  Unit 		unit - the unit
 *	  void		*data - the other unit
 *	Return Value:
 *	  void	connectTo - NONE
 *********************************************************************/
void	connectTo(unit, data)
  Unit	unit ;
  void	*data ;
{
  if (unit != (Unit)data)
    connectUnits(unit, (Unit)data, NULL) ;
}
/********************************************************************/
void	connectFrom(unit, data)
  Unit	unit ;
  void	*data ;
{
  if (unit != (Unit)data)
    connectUnits((Unit)data, unit, NULL) ;
}
/********************************************************************/

/*********************************************************************
 *	Name:		freezeLinks/unfreezeLinks
 *	Description:	freezes/unfreezes INCOMING or OUTGOING links
 *			of a unit (mask passed in as data)
 *	Parameters:
 *	  Unit 		unit  - the unit
 *	  void		*data - INCOMING or OUTGOING
 *	Return Value:
 *	  void		freezeLinks/unfreezeLinks - NONE
 *********************************************************************/
void	freezeLinks(unit, data)
  Unit	unit ;
  void	*data ;
{
  Link	*link ;
  int	numLinks, idx ;

  if ((int)data & INCOMING) {
    numLinks = unit->numIncoming;
    link     = unit->incomingLink;
  } else {
    numLinks = unit->numOutgoing;
    link     = unit->outgoingLink;
  }

  for (idx = 0; idx < numLinks; ++idx) {
    if (!(link[idx]->type & FROZEN))
      netFreezeLink(unit->net, link[idx]) ;
  }
}
/********************************************************************/
void	unfreezeLinks(unit, data)
  Unit	unit ;
  void	*data ;
{
  Link	*link ;
  int	numLinks, idx ;

  if ((int)data & INCOMING) {
    numLinks = unit->numIncoming;
    link     = unit->incomingLink;
  } else {
    numLinks = unit->numOutgoing;
    link     = unit->outgoingLink;
  }

  for (idx = 0 ; idx < numLinks ; ++idx) {
    if (link[idx]->type & FROZEN)
      netUnfreezeLink(unit->net, link[idx]);
  }
}
/********************************************************************/

/*********************************************************************
 *	Name:		randomizeLinks
 *	Description:	randomizes all the INCOMING or OUTGOING links
 *			of a unit (mask passed in as data
 *	Parameters:
 *	  Unit 		unit  - the unit
 *	  void		*data - INCOMING or OUTGOING. *not* both
 *	Return Value:
 *	  void		randomizeLinks - NONE
 *********************************************************************/
void	randomizeLinks(unit, data)
  Unit	unit ;
  void	*data ;
{
  Real	magnitude = McandWeightInitMag(unit->net) ;
  Link	*link ;
  int	numLinks, idx ;

  if ((int)data & INCOMING) {
    numLinks = unit->numIncoming;
    link     = unit->incomingLink;
  } else {
    numLinks = unit->numOutgoing;
    link     = unit->outgoingLink;
  }

  for (idx = 0 ; idx < numLinks ; ++idx)
    linkSetWeight(link[idx], randReal(0.0, magnitude)) ;
}
/*********************************************************************
*	Name:		randReal
*	Description:	returns a random number in the range 
*			(centre+field, centre-field).
*	Parameters:
*	  Real	centre - centre of the (uniform) random distribution
*	  Real	field - maximum deviation of random number from centre
*	Return Value:
*	  static Real	randReal
**********************************************************************/
static Real	 randReal(centre, field)
  double centre;
  double field;
{
  return (((((Real)random())/MAXINT)-0.5) * 2 * field) + centre;
}
/********************************************************************/


/*********************************************************************
 *	Name:		zeroLinks
 *	Description:	zeros all the INCOMING or OUTGOING links
 *			of a unit (mask passed in as data)
 *	Parameters:
 *	  Unit 		unit  - the unit
 *	  void		*data - INCOMING or OUTGOING. *not* both
 *	Return Value:
 *	  void		zeroLinks - NONE
 *********************************************************************/
void	zeroLinks(unit, data)
  Unit	unit ;
  void	*data ;
{
  Real	magnitude = McandWeightInitMag(unit->net) ;
  Link	*link ;
  int	numLinks, idx ;

  if ((int)data & INCOMING) {
    numLinks = unit->numIncoming;
    link     = unit->incomingLink;
  } else {
    numLinks = unit->numOutgoing;
    link     = unit->outgoingLink;
  }

  for (idx = 0 ; idx < numLinks ; ++idx)
    linkSetWeight(link[idx], 0.0) ;
}
/********************************************************************/
