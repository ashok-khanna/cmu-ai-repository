
/**********************************************************************
 * $Id: help.h,v 1.1 93/01/26 11:14:02 drew Exp $
 **********************************************************************/

/**********************************************************************
 *   Copyright 1990,1991,1992,1993 by The University of Toronto,
 *		      Toronto, Ontario, Canada.
 * 
 *			 All Rights Reserved
 * 
 * Permission to use, copy, modify, distribute, and sell this software
 * and its  documentation for  any purpose is  hereby granted  without
 * fee, provided that the above copyright notice appears in all copies
 * and  that both the  copyright notice  and   this  permission notice
 * appear in   supporting documentation,  and  that the  name  of  The
 * University  of Toronto  not  be  used in  advertising or  publicity
 * pertaining   to  distribution   of  the  software without specific,
 * written prior  permission.   The  University of   Toronto makes  no
 * representations  about  the  suitability of  this software  for any
 * purpose.  It  is    provided   "as is"  without express or  implied
 * warranty.
 *
 * THE UNIVERSITY OF TORONTO DISCLAIMS  ALL WARRANTIES WITH REGARD  TO
 * THIS SOFTWARE,  INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS, IN NO EVENT SHALL THE UNIVERSITY OF TORONTO  BE LIABLE
 * FOR ANY  SPECIAL, INDIRECT OR CONSEQUENTIAL  DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR  PROFITS, WHETHER IN
 * AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING
 * OUT  OF  OR  IN  CONNECTION WITH  THE  USE  OR PERFORMANCE  OF THIS
 * SOFTWARE.
 *
 **********************************************************************/

/**********************************************************************
 * These help strings will be automatically registered 
 * and made available to the "whatis" command and "Help"
 * buttons on the GUI
 *
 * THIS FILE SHOULD ONLY BE INCLUDED BY THE FILE "bp.c"
 * ANY OTHER FILE INCLUDING IT WILL CAUSE NAME CONFLICTS
 *
 **********************************************************************/

#ifndef bp_help_h
#define bp_help_h

/*********************************************************************/
char	*helpString_weightCost[] = {
  "Cost associated with magnitude of weights.  It is sometimes useful",
  "to limit the absolute magnitude of weights in this way, in order to",
  "improve the trained net's \"generalization\" capabilities.",
  NULL } ;
/*********************************************************************/
char	*helpString_zeroErrorRadius[] = {
  "Interval of acceptance for agreement between desired output and",
  "actual output of a unit.  The degree to which a \"near miss\" will",
  "count as a \"hit\" (ignored by units that use cross entropy error).",
  NULL } ;
/*********************************************************************/
char	*helpString_maxCC_HiddenUnits[] = {
  "The maximum number of hidden units to add to the network. Training",
  "stops when this many units have been added (default: 20).",
  NULL } ;
/*********************************************************************/
char	*helpString_candidates[] = {
  "The number of candidate units in the network. Hidden units are chosen",
  "from this pool of units (default: 4).",
  NULL } ;
/*********************************************************************/
char	*helpString_hiddenUnits[] = {
  "The current number of hidden units in the network.",
  NULL } ;
/*********************************************************************/
char	*helpString_initialMaxIterations[] = {
  "The maximum number of iterations to use when training the output units",
  "of a network with no hidden units.",
  NULL } ;
/*********************************************************************/
char	*helpString_initialMaxFuncEvals[] = {
  "The maximum number of function evaluations to use when training the",
  "output units of a network with no hidden units.",
  NULL } ;
/*********************************************************************/
char	*helpString_initialRepetitionCount[] = {
  "The repetition count to use when training the output units of a network",
  "with no hidden units.",
  NULL } ;
/*********************************************************************/
char	*helpString_candWeightInitMag[] = {
  "The maximum magnitude to use when randomizing the candidate weights",
  "before training them (default: 0.5).",
  NULL } ;
/*********************************************************************/
char	*helpString_cascade[] = {
  "If cascade is 1, then cascade the hidden units (connect each new",
  "hidden unit to all previous hidden units). If it is 0, then do not",
  "cascade the hidden units (default: 1).",
  NULL } ;
/*********************************************************************/
char	*helpString_sigmoidMax[] = {
  "The maximum value for the sigmoid activation function. Set to 1 for",
  "logistic and tanh (default: 1).",
  NULL } ;
/*********************************************************************/
char	*helpString_sigmoidMin[] = {
  "The minimum value for the sigmoid activation function. Set to 0 for",
  "logistic and -1 for tanh (default: 0).",
  NULL } ;
/*********************************************************************/
char	*helpString_sigmoidGain[] = {
  "The gain for the sigmoid activation function. Set to 1 for logistic",
  "and 2 for tanh (default: 1).",
  NULL } ;
/*********************************************************************/
char	*helpString_showCandidateMz[] = {
  "If 1, show the candidate minimize record in the \"Learning Methods\"",
  "display. If 0, then show the default (output unit) minimize record",
  "(default: 0).",
  NULL } ;
/*********************************************************************/
char	*helpString_trainingOutputs[] = {
  "An internal flag set to 1 one training the output units, 0 when",
  "training the candidate units.",
  NULL } ;
/*********************************************************************/
char	*helpString_candidateMz[] = {
  "The minimize record used to train the candidate units.",
  NULL } ;
/*********************************************************************/
char	*helpString_activationSum[] = {
  "The sum of a candidate unit's activations over an entire example set.",
  NULL } ;
/*********************************************************************/
char	*helpString_activationAvg[] = {
  "The average of a candidate unit's activations over an entire example set.",
  NULL } ;
/*********************************************************************/
char	*helpString_errorSum[] = {
  "The sum of an output unit's errors over an entire example set.",
  NULL } ;
/*********************************************************************/
char	*helpString_errorAvg[] = {
  "The average of an output unit's errors over an entire example set.",
  NULL } ;
/*********************************************************************/
char	*helpString_corrScore[] = {
  "A candidate unit's correlation score (the correlation of a candidate's",
  "activations with the output units' errors).",
  NULL } ;
/*********************************************************************/
char	*helpString_numExamples[] = {
  "The number of examples a unit has seen. Used in calculating activation",
  "and error averages.",
  NULL } ;
/*********************************************************************/
char	*helpString_corrSign[] = {
  "The sign of a candidate unit's correlation with the output unit's",
  "error.",
  NULL } ;
/*********************************************************************/
char	*helpString_partialCorrScore[] = {
  "A term in the correlation calculation.",
  NULL } ;
/*********************************************************************/

#endif				/* bp_help_h */
