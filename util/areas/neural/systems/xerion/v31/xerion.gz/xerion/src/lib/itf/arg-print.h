/*
 * $Id: arg-print.h,v 1.2 92/11/30 11:39:32 drew Exp $
 * 
 */

/**********************************************************************
 *   Copyright 1990,1991,1992,1993 by The University of Toronto,
 *		      Toronto, Ontario, Canada.
 * 
 *			 All Rights Reserved
 * 
 * Permission to use, copy, modify, distribute, and sell this software
 * and its documentation for any purpose is hereby granted without fee, 
 * provided that the above copyright notice appears in all copies and that 
 * both the copyright notice and this permission notice appear in 
 * supporting documentation, and that the name of University of Toronto 
 * not be used in advertising or publicity pertaining to distribution 
 * of the software without specific, written prior permission.  
 * University of Toronto makes no representations about the suitability 
 * of this software for any purpose. It is provided "as is" without 
 * express or implied warranty. 
 *
 * UNIVERSITY OF TORONTO DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS 
 * SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
 * FITNESS, IN NO EVENT SHALL UNIVERSITY OF TORONTO BE LIABLE FOR ANY 
 * SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER 
 * RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF 
 * CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN 
 * CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 **********************************************************************/

void PrintArgHelp ARGS((struct ARG_DESC *, FILE *file, int));
void PrintArgTree ARGS((struct ARG_DESC *, FILE *file));
void PrintArgUsage ARGS((struct ARG_DESC *, FILE *file, int));
void PrintArgValues ARGS((struct ARG_DESC *, FILE *file));

void PrintArgDesc ARGS((struct ARG_DESC *, int, int, FILE *));

extern char * SprintArgDesc ARGS((char*, struct ARG_DESC*, int, int));
extern char * SprintArgList ARGS((char*, struct ARG_LIST*, int, int));
extern char * SprintArgGroup ARGS((char*, struct ARG_GROUP*, int, int));
extern char * SprintArgOption ARGS((char*, struct ARG_OPTION*, int, int));
extern char * SprintArgSimple ARGS((char*, struct ARG_SIMPLE*, int, int));
extern char * SprintArgJoin ARGS((char*, enum ARG_JOIN, int, int));
extern char * SprintArgValue ARGS((char*, enum ARG_TYPE, generic *, int));
extern char * InitBuf ARGS((char *));
extern char * FlagPrefix ARGS((int));

#define INSIDE_GROUP		0x1
#define PRINT_ADDRESSES		0x2
#define PRINT_BRIEF		0x4
#define PRINT_NESTED		0x8
#define PRINT_VALUES		0x10
#define PRINT_HELP		0x20
#define PRINT_PARENS		0x40
#define PRINT_BRACKETS		0x80
#define PRINT_PERCENTS		0x100
#define PRINT_SEQS		0x200
#define PRINT_ONEPERLINE	0x400
#define PRINT_ACTUALS		0x800
#define PRINT_SPECIFIERS	0x1000
#define PRINT_STRUCTS		0x2000
#define PRINT_TYPES		0x4000
#define PRINT_SIMPLES		0x8000
#define PRINT_LITERALS		0x10000
#define PRINT_OPTIONS		0x20000
#define PRINT_OPTION_DASH	0x40000
#define PRINT_NOT_INDENT	0x80000
#define PRINT_OPTION_SIGN	0x100000
#define PRINT_NOT_NEWLINE	0x200000
#define PRINT_ACTUAL_STATUS	0x400000
#define PRINT_GROUPPERLINE	0x800000
#define	PRINT_OBJECTS (PRINT_LITERALS|PRINT_SIMPLES|PRINT_OPTIONS|PRINT_OPTION_DASH)
#define PRINT_BRIEF_LINE (PRINT_OBJECTS|PRINT_BRACKETS|PRINT_NOT_NEWLINE)
