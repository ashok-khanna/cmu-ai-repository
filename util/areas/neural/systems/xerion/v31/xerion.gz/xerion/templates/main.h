
/**********************************************************************
 * $Id: main.h,v 1.3 92/11/30 11:33:11 drew Exp $
 **********************************************************************/

/**********************************************************************
 *   Copyright 1990,1991,1992,1993 by The University of Toronto,
 *		       Toronto, Ontario, Canada.
 * 
 *			 All Rights Reserved
 * 
 * Permission to use, copy, modify, distribute,  and sell this software
 * and its documentation for any purpose is hereby granted without fee,
 * provided  that the above copyright notice  appears in all copies and
 * that both the copyright notice and this permission notice  appear in
 * supporting documentation, and  that  the  name of The University  of
 * Toronto  not  be used  in advertising   or publicity pertaining   to
 * distribution  of   the software   without  specific, written   prior
 * permission.  The  University  of Toronto  makes   no representations
 * about the  suitability  of  this software  for  any purpose.   It is
 * provided "as is" without express or implied warranty.
 *
 * THE  UNIVERSITY OF  TORONTO DISCLAIMS ALL WARRANTIES  WITH REGARD TO
 * THIS SOFTWARE,  INCLUDING ALL  IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS, IN NO EVENT  SHALL THE UNIVERSITY  OF TORONTO BE LIABLE
 * FOR ANY SPECIAL,  INDIRECT OR CONSEQUENTIAL  DAMAGES  OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF  USE, DATA OR PROFITS,  WHETHER IN
 * AN ACTION OF CONTRACT, NEGLIGENCE  OR OTHER TORTIOUS ACTION, ARISING
 * OUT  OF OR  IN  CONNECTION   WITH  THE  USE OR  PERFORMANCE  OF THIS
 * SOFTWARE.
 **********************************************************************/

#ifndef __xerion_main_h
#define __xerion_main_h

/* The following structures can be defined, if you don't need them in
 * your simulator, either leave them in, or delete them . Insert any
 * extensions that you need in them. The comment 'netParam:' in a
 * NetExtensionRec marks that field as a network training parameter.
 * (shows up in the learning methods "Misc. Paramaters" list")
 */

typedef struct NetExtensionRec {	/* BIND */
  Real	zeroErrorRadius ;		/* netParam: */
} NetExtensionRec ;

typedef struct GroupExtensionRec {	/* BIND */
  int	foo ;
} GroupExtensionRec ;

typedef struct UnitExtensionRec {	/* BIND */
  int	foo ;
} UnitExtensionRec ;

typedef struct LinkExtensionRec {	/* BIND */
  int	foo ;
} LinkExtensionRec ;

typedef struct ExampleExtensionRec {	/* BIND */
  int	foo ;
} ExampleExtensionRec ;

/* Insert anything else in here */

#endif /* __xerion_main_h */
