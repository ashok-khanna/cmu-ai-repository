
/***********************************************************************
 *	$Id: dummy.c,v 1.2 92/06/25 15:44:03 drew Exp $
 *	This is a dummy file that can be compiled if you do not have
 *	the necessary libraries to compile the X routines. They replace
 *	the exported routines in display.c
 *	COMPILE EITHER THIS  FILE OR ALL THE OTHERS IN THIS DIRECTORY.
 *	NOT BOTH.
 ***********************************************************************/
#include <stdio.h>

int	initGraphics(argc, argv)
  int	*argc ;
  char	**argv ;
{
  return 0 ;
}

int	buildGraphics()
{
  return 0 ;
}

int	destroyGraphics()
{
  return 0 ;
}

int	markToRebuildDisplay(which)
  int	which ;
{
  return 0 ;
}

int	delayDisplayResets() 
{
  return 0 ;
}

int	catchupOnDisplayResets()
{
  return 0 ;
}

int	graphicsLoop(inStream, outStream)
  FILE	*inStream ;
  FILE	*outStream ;
{
  return 0 ;
}
/********************************************************************/

