
/**********************************************************************
 * $Id: help.h,v 1.4 93/03/09 12:14:04 drew Exp $
 **********************************************************************/

/**********************************************************************
 *   Copyright 1990,1991,1992,1993 by The University of Toronto,
 *		      Toronto, Ontario, Canada.
 * 
 *			 All Rights Reserved
 * 
 * Permission to use, copy, modify, distribute, and sell this software
 * and its  documentation for  any purpose is  hereby granted  without
 * fee, provided that the above copyright notice appears in all copies
 * and  that both the  copyright notice  and   this  permission notice
 * appear in   supporting documentation,  and  that the  name  of  The
 * University  of Toronto  not  be  used in  advertising or  publicity
 * pertaining   to  distribution   of  the  software without specific,
 * written prior  permission.   The  University of   Toronto makes  no
 * representations  about  the  suitability of  this software  for any
 * purpose.  It  is    provided   "as is"  without express or  implied
 * warranty.
 *
 * THE UNIVERSITY OF TORONTO DISCLAIMS  ALL WARRANTIES WITH REGARD  TO
 * THIS SOFTWARE,  INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS, IN NO EVENT SHALL THE UNIVERSITY OF TORONTO  BE LIABLE
 * FOR ANY  SPECIAL, INDIRECT OR CONSEQUENTIAL  DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR  PROFITS, WHETHER IN
 * AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING
 * OUT  OF  OR  IN  CONNECTION WITH  THE  USE  OR PERFORMANCE  OF THIS
 * SOFTWARE.
 *
 **********************************************************************/

/**********************************************************************
 * These help strings will be automatically registered 
 * and made available to the "whatis" command and "Help"
 * buttons on the GUI
 *
 * THIS FILE SHOULD ONLY BE INCLUDED BY THE FILE "itf.c"
 * ANY OTHER FILE INCLUDING IT WILL CAUSE NAME CONFLICTS
 *
 **********************************************************************/

#ifndef itf_help_h
#define itf_help_h

/**********************************************************************/
char	*helpString_HOME[] = {
  "The default home directory of the user (imported from the invoking",
  "shell).",
  NULL } ;
/**********************************************************************/
char	*helpString_PAGER[] = {
  "The default pager used to show command output (imported from the",
  "invoking shell).",
  NULL } ;
/**********************************************************************/
char	*helpString_TERM[] = {
  "The terminal type the shell is running in (imported from the",
  "invoking shell).",
  NULL } ;
/**********************************************************************/
char	*helpString_XERIONDIR[] = {
  "The top level directory for the xerion files (imported from the",
  "invoking shell).",
  NULL } ;
/**********************************************************************/
char	*helpString_alias_enabled[] = {
  "If true, alias substitution is enabled. If false, alias substitution",
  "is disabled. By default, it is false. This is because alias substitution",
  "introduces a bug in escaped quotes. This is a minor bug, but very hard",
  "to fix.",
  NULL } ;
/**********************************************************************/
char	*helpString_automore[] = {
  "If set to true, pass all command output through the \"$PAGER\".",
  NULL } ;
/**********************************************************************/
char	*helpString_echo[] = {
  "If \"true\", echo commands before executing them.",
  NULL } ;
/**********************************************************************/
char	*helpString_help_automore[] = {
  "If set to \"true\", pass output from \"help\" through \"$PAGER\".",
  NULL } ;
/**********************************************************************/
char	*helpString_noclobber[] = {
  "If set to \"true\", return an error when redirection will overwrite an",
  "existing file.",
  NULL } ;
/**********************************************************************/
char	*helpString_plus_minus_options[] = {
  "If this is \"false\", then commands will not accept options preceded",
  "by \"+\" (default: \"false\").",
  NULL } ;
/**********************************************************************/
char	*helpString_printstatus[] = {
  "If set to \"true\", print exit status of each command list after it",
  "completes.",
  NULL } ;
/**********************************************************************/
char	*helpString_prompt[] = {
 "Primary prompt string (default \"xerion->\").",
  NULL } ;
/**********************************************************************/
char	*helpString_read_echo[] = {
  "If both \"echo\" and \"read-echo\" are true, echo commands from",
  "read-files before executing them.",
  NULL } ;
/**********************************************************************/
char	*helpString_readpath[] = {
  "A list of space or colon separated directories to search for",
  "read-files.  This variable is used by all commands which take input",
  "from files.",
  NULL } ;
/**********************************************************************/
char	*helpString_redirection[] = {
  "If \"true\" allow output redirection.",
  NULL } ;
/**********************************************************************/
char	*helpString_status[] = {
  "The exit status of the last completed command list.",
  NULL } ;
/**********************************************************************/
char	*helpString_unset_error[] = {
  "If true, treat unset (uncreated) variables as an error when",
  "substituting.",
  NULL } ;
/**********************************************************************/

#endif				/* itf_help_h */
