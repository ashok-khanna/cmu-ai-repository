
void steepestDescent
  ARGS((Minimize, int, Real *, Real *, double *));

void momentumDirection
  ARGS((Minimize, int, Real *, Real *, double *)); 

void quickPropDirection
  ARGS((Minimize, int, Real *, Real *, Real *, double *));

void deltaBarDeltaDirection
  ARGS((Minimize, int, Real *, Real *, Real *, Real *, double *));

void conjugateGradient
  ARGS((Minimize, int, Real *, Real *, Real *, double *));

void rudisConjugateGradient
  ARGS((Minimize, int, double, Real *, Real *, Real *, double *));

void conjugateGradientRestart
   ARGS((Minimize, int, double,
	 Real *, Real *, Real *, Real *, Real *, Real *,
	 double *, double));
