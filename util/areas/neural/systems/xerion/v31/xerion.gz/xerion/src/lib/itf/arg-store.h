/*
 * $Id: arg-store.h,v 1.2 92/11/30 11:39:34 drew Exp $
 * 
 */

/**********************************************************************
 *   Copyright 1990,1991,1992,1993 by The University of Toronto,
 *		      Toronto, Ontario, Canada.
 * 
 *			 All Rights Reserved
 * 
 * Permission to use, copy, modify, distribute, and sell this software
 * and its documentation for any purpose is hereby granted without fee, 
 * provided that the above copyright notice appears in all copies and that 
 * both the copyright notice and this permission notice appear in 
 * supporting documentation, and that the name of University of Toronto 
 * not be used in advertising or publicity pertaining to distribution 
 * of the software without specific, written prior permission.  
 * University of Toronto makes no representations about the suitability 
 * of this software for any purpose. It is provided "as is" without 
 * express or implied warranty. 
 *
 * UNIVERSITY OF TORONTO DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS 
 * SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
 * FITNESS, IN NO EVENT SHALL UNIVERSITY OF TORONTO BE LIABLE FOR ANY 
 * SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER 
 * RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF 
 * CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN 
 * CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 **********************************************************************/

extern Boolean argBoolean
  ARGS((struct ARG_SIMPLE *, char *, int, struct GLOBAL *));
extern Boolean argString
  ARGS((struct ARG_SIMPLE *, char *, int, struct GLOBAL *));
extern Boolean argChar
  ARGS((struct ARG_SIMPLE *, char *, int, struct GLOBAL *));
extern Boolean argNatural
  ARGS((struct ARG_SIMPLE *, char *, int, struct GLOBAL *));
extern Boolean argInteger
  ARGS((struct ARG_SIMPLE *, char *, int, struct GLOBAL *));
extern Boolean argShort
  ARGS((struct ARG_SIMPLE *, char *, int, struct GLOBAL *));
extern Boolean argLong
  ARGS((struct ARG_SIMPLE *, char *, int, struct GLOBAL *));
extern Boolean argReal
  ARGS((struct ARG_SIMPLE *, char *, int, struct GLOBAL *));
extern Boolean argFloat
  ARGS((struct ARG_SIMPLE *, char *, int, struct GLOBAL *));
extern Boolean argDouble
  ARGS((struct ARG_SIMPLE *, char *, int, struct GLOBAL *));
extern Boolean argFormatStr
  ARGS((struct ARG_SIMPLE *, char *, int, struct GLOBAL *));
extern Boolean argAreaFormatStr
  ARGS((struct ARG_SIMPLE *, char *, int, struct GLOBAL *));
extern Boolean argRangeStr
  ARGS((struct ARG_SIMPLE *, char *, int, struct GLOBAL *));
extern Boolean argVarName
  ARGS((struct ARG_SIMPLE *, char *, int, struct GLOBAL *));
extern Boolean argMemberName
  ARGS((struct ARG_SIMPLE *, char *, int, struct GLOBAL *));
extern Boolean argFileIn
  ARGS((struct ARG_SIMPLE *, char *, int, struct GLOBAL *));
extern Boolean argFileOut
  ARGS((struct ARG_SIMPLE *, char *, int, struct GLOBAL *));

#define NUMBER_ARG_TYPES	20
#define COPYSTR		0x1
#define	ONLYCHECK	0x2
#define	OPTIONAL	0x4

typedef Boolean (*ArgStoreFunction)
  ARGS((struct ARG_SIMPLE *, char *, int, struct GLOBAL *));

extern enum ARG_TYPE arg_type_by_char[128];
extern ArgStoreFunction arg_store_function_by_type[NUMBER_ARG_TYPES];
extern char* arg_type_name[NUMBER_ARG_TYPES];
extern char arg_type_char[NUMBER_ARG_TYPES];
extern int arg_types_initialized;
