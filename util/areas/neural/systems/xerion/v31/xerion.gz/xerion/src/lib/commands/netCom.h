
/**********************************************************************
 * $Id: netCom.h,v 1.4 92/11/30 11:27:44 drew Exp $
 **********************************************************************/

/**********************************************************************
 *   Copyright 1990,1991,1992,1993 by The University of Toronto,
 *		       Toronto, Ontario, Canada.
 * 
 *			 All Rights Reserved
 * 
 * Permission to use, copy, modify, distribute,  and sell this software
 * and its documentation for any purpose is hereby granted without fee,
 * provided  that the above copyright notice  appears in all copies and
 * that both the copyright notice and this permission notice  appear in
 * supporting documentation, and  that  the  name of The University  of
 * Toronto  not  be used  in advertising   or publicity pertaining   to
 * distribution  of   the software   without  specific, written   prior
 * permission.  The  University  of Toronto  makes   no representations
 * about the  suitability  of  this software  for  any purpose.   It is
 * provided "as is" without express or implied warranty.
 *
 * THE  UNIVERSITY OF  TORONTO DISCLAIMS ALL WARRANTIES  WITH REGARD TO
 * THIS SOFTWARE,  INCLUDING ALL  IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS, IN NO EVENT  SHALL THE UNIVERSITY  OF TORONTO BE LIABLE
 * FOR ANY SPECIAL,  INDIRECT OR CONSEQUENTIAL  DAMAGES  OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF  USE, DATA OR PROFITS,  WHETHER IN
 * AN ACTION OF CONTRACT, NEGLIGENCE  OR OTHER TORTIOUS ACTION, ARISING
 * OUT  OF OR  IN  CONNECTION   WITH  THE  USE OR  PERFORMANCE  OF THIS
 * SOFTWARE.
 **********************************************************************/

#ifndef NET_COMMAND_H
#define NET_COMMAND_H

extern Net	currentNet ; 		/* BIND */

extern int	command_createNet ARGS((int	tokc, char	*tokv[])) ;
extern int	command_addNet    ARGS((int	tokc, char	*tokv[])) ;
extern int	command_useNet    ARGS((int	tokc, char	*tokv[])) ;
extern int	command_deleteNet ARGS((int	tokc, char	*tokv[])) ;
extern int	command_deleteNets ARGS((int	tokc, char	*tokv[])) ;
extern int	command_train     ARGS((int	tokc, char	*tokv[])) ;
extern int	command_test      ARGS((int	tokc, char	*tokv[])) ;
extern int	command_validate  ARGS((int	tokc, char	*tokv[])) ;

extern Net	addNet ARGS((char *name, int mask, int timeSlices)) ;
extern Net	getNet ARGS((char *name)) ;
extern Net	useNet ARGS((char *name)) ;
extern int	delNet ARGS((char *name)) ;
extern char	**listNets ARGS(()) ;

#endif	/* NET_COMMAND_H */
