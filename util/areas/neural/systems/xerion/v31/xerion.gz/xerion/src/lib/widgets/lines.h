#define lines_width 1
#define lines_height 3
static char lines_bits[] = {
   0x00, 0x01, 0x00};
