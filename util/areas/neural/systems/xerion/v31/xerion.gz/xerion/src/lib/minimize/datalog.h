extern void logInitialStepData
  ARGS((Minimize, double, double, double, double, double, double, double));
extern void logLineSearchData ARGS((Minimize));
extern void logParameters ARGS((Minimize));
