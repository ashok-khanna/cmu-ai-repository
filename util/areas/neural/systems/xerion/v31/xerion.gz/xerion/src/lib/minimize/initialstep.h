extern double shootStep ARGS((Minimize, double, double, double));
extern double dRatioStep ARGS((double, double, double));
extern double sLenStep ARGS((double));
extern double askStep
  ARGS((Minimize, double, double, double, double, double, double, double));
extern double newStep
  ARGS((Minimize, double, double, double, double, double, double, double));
