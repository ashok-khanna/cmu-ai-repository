
/**********************************************************************
 * $Id: Controller.h,v 1.3 92/11/30 11:28:23 drew Exp $
 **********************************************************************/

/**********************************************************************
 *   Copyright 1990,1991,1992,1993 by The University of Toronto,
 *		      Toronto, Ontario, Canada.
 * 
 *			 All Rights Reserved
 * 
 * Permission to use, copy, modify, distribute, and sell this software
 * and its  documentation for  any purpose is  hereby granted  without
 * fee, provided that the above copyright notice appears in all copies
 * and  that both the  copyright notice  and   this  permission notice
 * appear in   supporting documentation,  and  that the  name  of  The
 * University  of Toronto  not  be  used in  advertising or  publicity
 * pertaining   to  distribution   of  the  software without specific,
 * written prior  permission.   The  University of   Toronto makes  no
 * representations  about  the  suitability of  this software  for any
 * purpose.  It  is    provided   "as is"  without express or  implied
 * warranty.
 *
 * THE UNIVERSITY OF TORONTO DISCLAIMS  ALL WARRANTIES WITH REGARD  TO
 * THIS SOFTWARE,  INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS, IN NO EVENT SHALL THE UNIVERSITY OF TORONTO  BE LIABLE
 * FOR ANY  SPECIAL, INDIRECT OR CONSEQUENTIAL  DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR  PROFITS, WHETHER IN
 * AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING
 * OUT  OF  OR  IN  CONNECTION WITH  THE  USE  OR PERFORMANCE  OF THIS
 * SOFTWARE.
 *
 **********************************************************************/

#ifndef _Controller_h
#define _Controller_h

#include <xerion/config.h>

/***********************************************************************
 *
 * Controller Widget
 *
 ***********************************************************************/

/***********************************************************************
 Parameters:

 Name		     Class		RepType		Default Value
 ----		     -----		-------		-------------
 background	     Background		Pixel		XtDefaultBackground
 border		     BorderColor	Pixel		XtDefaultForeground
 borderWidth	     BorderWidth	Dimension	1
 callback	     Callback		Pointer		NULL
 destroyCallback     Callback		Pointer		NULL
 height		     Height		Dimension	computed at realize
 mappedWhenManaged   MappedWhenManaged	Boolean		True
 quitCallback	     Callback		Pointer		NULL
 sensitive	     Sensitive		Boolean		True
 width		     Width		Dimension	computed at realize
 x		     Position		Position	0
 y		     Position		Position	0

 ***********************************************************************/

#define XtNquitCallback	"quitCallback"

extern WidgetClass controllerWidgetClass;

typedef struct _ControllerClassRec	*ControllerWidgetClass;
typedef struct _ControllerRec		*ControllerWidget;

typedef void	(*DisplayCreateProc) ARGS((Widget)) ;

extern Widget	controllerAddDisplay ARGS((Widget, String,
					   WidgetClass, DisplayCreateProc)) ;
extern void	controllerRemoveDisplay ARGS((Widget, Widget display)) ;

extern void	controllerUnblockInput	ARGS((Widget, Widget)) ;
extern void	controllerBlockInput	ARGS((Widget, Widget)) ;

extern void	controllerTriggerCallbacks ARGS((Widget, XtPointer)) ;

#endif				/* _Controller_h */
