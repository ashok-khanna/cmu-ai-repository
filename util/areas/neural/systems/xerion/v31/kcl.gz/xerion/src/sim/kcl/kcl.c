
/**********************************************************************
 * $Id: kcl.c,v 1.3 92/11/30 11:57:56 drew Exp $
 **********************************************************************/

/**********************************************************************
 *   Copyright 1990,1991,1992,1993 by The University of Toronto,
 *		       Toronto, Ontario, Canada.
 * 
 *			 All Rights Reserved
 * 
 * Permission to use, copy, modify, distribute,  and sell this software
 * and its documentation for any purpose is hereby granted without fee,
 * provided  that the above copyright notice  appears in all copies and
 * that both the copyright notice and this permission notice  appear in
 * supporting documentation, and  that  the  name of The University  of
 * Toronto  not  be used  in advertising   or publicity pertaining   to
 * distribution  of   the software   without  specific, written   prior
 * permission.  The  University  of Toronto  makes   no representations
 * about the  suitability  of  this software  for  any purpose.   It is
 * provided "as is" without express or implied warranty.
 *
 * THE  UNIVERSITY OF  TORONTO DISCLAIMS ALL WARRANTIES  WITH REGARD TO
 * THIS SOFTWARE,  INCLUDING ALL  IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS, IN NO EVENT  SHALL THE UNIVERSITY  OF TORONTO BE LIABLE
 * FOR ANY SPECIAL,  INDIRECT OR CONSEQUENTIAL  DAMAGES  OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF  USE, DATA OR PROFITS,  WHETHER IN
 * AN ACTION OF CONTRACT, NEGLIGENCE  OR OTHER TORTIOUS ACTION, ARISING
 * OUT  OF OR  IN  CONNECTION   WITH  THE  USE OR  PERFORMANCE  OF THIS
 * SOFTWARE.
 *
 **********************************************************************/

 /*********************************************************************
 *
 *  KCL/SCL/HCL competitive learning modules written by Sue Becker
 *                                           Dept. of Computer Science
 *  November 1991                            Univ. of Toronto
 *
 **********************************************************************/

#include <stdio.h>
#include <math.h>

#include <xerion/useful.h>
#include <xerion/version.h>
#include <xerion/simulator.h>
#include <xerion/commands.h>
#include <xerion/minimize.h>

#include "kcl.h"
#include "help.h"

static void	initNet                ARGS((Net   net)) ;
static void	deinitNet              ARGS((Net   net)) ;
static Proc     winnerTakeAllNetActivityUpdate ARGS((Net net)) ;
static Proc     winnerTakeAllNetGradientUpdate ARGS((Net net)) ;
static void	calculateNetErrorDeriv ARGS((Net   net,ExampleSet exampleSet));
static void	calculateNetError      ARGS((Net   net,ExampleSet exampleSet));
static void	resetNeighborhoods     ARGS((Net   net));
static void	decayNeighborhoods     ARGS((Net   net));
static void	decayLearningRate      ARGS((Net   net));
static void	setNetNeighborhoodProc ARGS((Net   net, int funcNumber));
static void	calculateNetUniformNeighborhoods ARGS((Net net));
static void	calculateNetLinearNeighborhoods ARGS((Net net));
static void	calculateNetGaussianNeighborhoods ARGS((Net net));
static void	calculateNumCompetingUnits   ARGS((Net net));

static void	initGroup              ARGS((Group group)) ;

static void	initUnit               ARGS((Unit  unit)) ;
static void	initKohonenUnit        ARGS((Unit  unit)) ;
static void     setUnitTotalInput      ARGS((Unit  unit, void *data)) ;
static Real	winningUnitError       ARGS((Unit  unit)) ;
static Proc	winningUnitGradUpdate  ARGS((Unit  unit)) ;
static Proc	gradUpdate             ARGS((Unit  unit, double neighbWeight));
static Proc	calculateUnitUniformNeighborhood ARGS((Unit unit,void *data));
static Proc	calculateUnitLinearNeighborhood ARGS((Unit unit,void *data));
static Proc	calculateUnitGaussianNeighborhood ARGS((Unit unit,void *data));
static Proc	zeroLinks              ARGS((Unit  unit, void *data)) ;
static Proc	setUnitCoords          ARGS((Unit  unit, void *data)) ;
static Proc	initUnitNeighborhood   ARGS((Unit  unit, void *data)) ;
static Proc	incNetUnitCount        ARGS((Unit  unit, void *data)) ;
static Proc	showUnitNeighbors      ARGS((Unit  unit, void *data)) ;
static Proc	interpolateWeights     ARGS((Unit  unit, void *data)) ;

static Real	square                 ARGS((double  x)) ;

int command_configureKohonenNet        ARGS((int tokc, char *tokv[])) ;
int command_interpolateWeights         ARGS((int tokc, char *tokv[])) ;
int command_showNeighbors              ARGS((int tokc, char *tokv[])) ;

/***********************************************************************
 *	Name:		main 
 *	Description:	the main function, used for the xerion simulator
 *	Parameters:	
 *		int	argc	- the number of input args
 *		char	**argv  - array of argument strings from command 
 *				  line
 *	Return Value:	
 *		int	main	- 0
 ***********************************************************************/
int main (argc, argv)
  int	argc ;
  char	**argv ;
{
  extern void	createScatterDisplay() ;
  extern int	addUserDisplay() ;

  authors = "Sue Becker" ;

  addUserDisplay("scatter", createScatterDisplay) ;

  /* Perform initialization of the simulator */
  IStandardInit(&argc, argv);

  /* Insert any private initialization routines here */
  setCreateNetHook  (initNet) ;
  setDestroyNetHook (deinitNet) ;
  setCreateGroupHook(initGroup) ;
  setCreateUnitHook(initUnit) ;

  /* Enter loop that reads commands and handles graphics */
  ICommandLoop(stdin, stdout, NULL);

  return 0 ;
}
/**********************************************************************/


/***********************************************************************
 *	Name:		initNet 
 *	Description:	allocates the memory for the net extension record
 *			and initializes some net parameters.
 *	Parameters:	
 *		Net	net - the net to act on
 *	Return Value:	NONE
 ***********************************************************************/
static void	initNet (net)
  Net	net ;
{

  net->calculateErrorDerivProc = calculateNetErrorDeriv ;
  net->calculateErrorProc      = calculateNetError ;
  net->activityUpdateProc      = winnerTakeAllNetActivityUpdate;
  net->gradientUpdateProc      = winnerTakeAllNetGradientUpdate;

  net->extension = (NetExtension)calloc(1, sizeof(NetExtensionRec)) ;

  MunitCounter(net) = 0;
  
  /* learning rate parameters:
   */
  Mepsilon(net) =
    MinitialLearningRate(net) = 0.005 ;
  MlearningRateDecayFunction(net) = EXPONENTIAL;
  MlearningRateDecay(net) = 1.0 ;       /* If learningRateDecayFunction is
					 * EXPONENTIAL, multiply learning rate 
					 * by this factor after each epoch
					 */
  Mtau(net) = HUGE_VAL;
  Mmomentum(net) = 0.0 ;

  /* neighborhood parameters:
   */
  MprevNeighborhoodFunction(net) = 
    MneighborhoodFunction(net) = UNIFORM; /* can be UNIFORM (no falloff),
					   * LINEAR falloff, or
					   * GAUSSIAN falloff
					   */
  setNetNeighborhoodProc(net, MneighborhoodFunction(net));

  Mradius(net) = 0.05; 
  MprevVariance(net) =
    Mvariance(net) = 0.2 ;              /* variance of gaussian neighborhood
					 */
  MinitialVariance(net) = 0.2 ;
  MminVariance(net) = 0.05 ;

  MneighborhoodDecayFunction(net) = ONE_OVER_T;
                                        /* can be EXPONENTIAL or ONE_OVER_T.
					 * The latter decays neighborhood size
					 * and variance as 1/(1+epoch/tau)
					 */
  MneighborhoodDecayRate(net) = 1.0;   /* If neighborhoodFunction = 1,
					* multiply neighborhood size by this
					* value after each epoch
					*/
  MprevMaxDistance(net) = MmaxDistance(net) =
  MinitialMaxDistance(net) = 3.0;      /* Minimium Euclidean distance between
                                        * units which are in the same
					* neighborhood
					*/

  MminDistance(net) = 1.0;
  MdirectionMethod(net) = MZSTEEPEST;
  MstepMethod(net) = MZFIXEDSTEP;

  MmaxXIndex(net) = 0;
  MmaxYIndex(net) = 0;
  Mconfigured(net) = 0;                /* must call configureKohoneneNet
					* before doing any learning
					*/
}

/**********************************************************************/
static void	deinitNet (net)
  Net	net ;
{
  if (net->extension != NULL)
    free(net->extension) ;
}
/**********************************************************************/


/***********************************************************************
 *	Name:		initGroup 
 *	Description:	sets the update procedures for the units in
 *			a group. 
 *	Parameters:	
 *		Group	group - the group to set the procedures for
 *	Return Value:	NONE
 ***********************************************************************/
static void	initGroup (group)
  Group	group ;
{
  group->groupActivityUpdateProc = NULL;
  group->unitActivityUpdateProc = NULL ;
  group->unitGradientUpdateProc = NULL ;
  group->extension = (GroupExtension)calloc(1, sizeof(GroupExtensionRec)) ;
}
/**********************************************************************/

/***********************************************************************
 *	Name:		initUnit
 *	Description:	allocates space for unit extension fields.
 *	Parameters:	
 *		Unit	unit - the unit to allocate the space for
 *	Return Value:	NONE
 ***********************************************************************/
static void	initUnit (unit)
  Unit	unit ;
{
  unit->extension = (UnitExtension)calloc(1, sizeof(UnitExtensionRec));
}
/**********************************************************************/

/***********************************************************************
 *	Name:		initKohonenUnit
 *	Description:	allocates space for unit array extension fields.
 *                      This is called by configureKohonenNet and can't be
 *                      called until the whole net has been built.
 *	Parameters:	
 *		Unit	unit - the unit to allocate the space for
 *	Return Value:	NONE
 ***********************************************************************/
static void	initKohonenUnit (unit)
  Unit	unit ;
{
  int nNeighbors = MunitCounter(unit->net);
  UnitExtensionRec *ext = unit->extension;

  ext->neighbor = (Unit*)calloc(nNeighbors, sizeof(ext->neighbor));
  ext->distance =  (Real*)calloc(nNeighbors, sizeof(Real));
  ext->neighbWeight = (Real*)calloc(nNeighbors, sizeof(Real));
  ext->numNeighbors = nNeighbors;
  ext->lastNeighborIndex = nNeighbors - 1;
}
/**********************************************************************/


/***********************************************************************
 *	Name:		winnerTakeAllNetActivityUpdate
 *	Description:
 *             Sets each unit's totalInput to the squared difference
 *	         between its weight vector and input vector
 *             Unit with the least total input is the winner.
 *             Winner's output is 1, rest are 0.
 *             The global error is decremented by the sum of the errors
 *               (total inputs) of unit's in the winner's neighborhood,
 *               weighted by their distance to the winner.
 *      Parameters:
 *		Net	net - the net object ;
 *	Return Value:	
 *		NONE
 ***********************************************************************/
static void	winnerTakeAllNetActivityUpdate (net)
  Net		net ;
{
  MminTotalInput(net) = HUGE_VAL;
  netForAllUnits(net, ~(INPUT | BIAS), setUnitTotalInput, net);
  Mwinner(net)->output = 1.0;

  net->error += winningUnitError(Mwinner(net)); 
}
/**********************************************************************/


/***********************************************************************
 *	Name:		winnerTakeAllNetGradientUpdate
 *	Description:
 *             Update the weights for winning unit and all units within 
 *                 its neighborhood (within maxDistance)
 *      Parameters:
 *		Net	net - the net object ;
 *	Return Value:	
 *		NONE
 ***********************************************************************/
static void	winnerTakeAllNetGradientUpdate (net)
  Net		net ;
{
  winningUnitGradUpdate(Mwinner(net));

}
/**********************************************************************/

/***********************************************************************
 *	Name:	     setUnitTotalInput
 *	Description:
 *              Set the following unit fields:
 *                totalInput = squared difference between 
 *                             weight vector and current input vector
 *                output   =  0
 *              If unit's total input < net->extension->minTotalInput,
 *                  set net->extension->winner = unit.
 *	Parameters:	
 *		Unit   unit - the unit to set the totalInput for
 *		Data   *void - a pointer to the net
 *	Return Value:	NONE
 ***********************************************************************/
static void setUnitTotalInput (unit, data)
  Unit unit;
  void *data;
{
  Net   net = (Net)data;
  Real  totalInput = 0.0 ;
  int	numIncoming = unit->numIncoming ;
  Link	*incoming   = unit->incomingLink ;
  int	linkIndex ;

  for (linkIndex = 0 ; linkIndex < numIncoming ; ++linkIndex) {
     Link	link = incoming[linkIndex] ;
     totalInput += square(link->weight - (link->preUnit->output));
  }
  unit->totalInput = totalInput;
  unit->output = 0.0;
  if (totalInput < MminTotalInput(net)) {
    MminTotalInput(net) = totalInput;
    Mwinner(net) = unit;
  }
}


/***********************************************************************
 *	Name:		winningUnitError
 *	Description:	calculates the error value of the winning unit as
 *                      the sum of errors of this unit and its neighbors,
 *                      each error (totalInput) weighted by teh distance to
 *                      the winner.
 *	Parameters:	
 *		const Unit	unit - the unit to calclate the error of
 *	Return Value:	
 *		Real		winningUnitError - the error of the unit
 ***********************************************************************/
static Real	winningUnitError(unit)
  Unit	unit ;
{
  Real		     error ;
  UnitExtensionRec   *ext = unit->extension;
  Unit               *neighbor = ext->neighbor;
  int	             neighbNum,
                     numNeighbs = ext->lastNeighborIndex + 1;
  Real               *neighbWeight = ext->neighbWeight;

  error = 0.0;

  for (neighbNum = 0; neighbNum < numNeighbs; ++neighbNum)
     error += neighbor[neighbNum]->totalInput * neighbWeight[neighbNum];

  return error ;
}
/**********************************************************************/

/***********************************************************************
 *	Name:		winningUnitGradUpdate
 *	Description:	sets the deriv field on incoming links of 
 *                      all units within neighborhood of winner
 *	Parameters:	
 *		Unit	unit - the winning unit
 *	Return Value:	NONE
 ***********************************************************************/
static Proc	winningUnitGradUpdate(unit)
  Unit	unit ;
{
  UnitExtensionRec   *ext = unit->extension;
  Unit               *neighbor = ext->neighbor;
  int	             neighbNum,
                     numNeighbs = ext->lastNeighborIndex + 1;
  Real               *neighbWeight = ext->neighbWeight;

  for (neighbNum = 0; neighbNum < numNeighbs; ++neighbNum)
    gradUpdate(neighbor[neighbNum],   (double)neighbWeight[neighbNum]);
}
/**********************************************************************/

/***********************************************************************
 *	Name:		gradUpdate
 *	Description:	sets the deriv field on incoming links of unit
 *	Parameters:	
 *		Unit	unit - the unit to set the grads for
 *              Real    neighbWeight - the neighborhood weight from 
 *                         winning unit to this unit
 *	Return Value:	NONE
 ***********************************************************************/
static Proc	gradUpdate(unit, neighbWeight)
  Unit	unit ;
  double  neighbWeight ;
{
  int                numIncoming = unit->numIncoming ;
  Link	             *incoming   = unit->incomingLink ;
  int	             idx ;
  
  for (idx = 0 ; idx < numIncoming ; ++idx) {
    Link	link  = incoming[idx] ;

    link->deriv -= (Real)neighbWeight * (link->preUnit->output - link->weight);
  }
}
/**********************************************************************/

/***********************************************************************
 *	Name:		calculateNetErrorDeriv
 *	Description:	gradient calculation procedure for scl net
 *			It processes 'MbatchSize(net)' examples
 *	Parameters:	
 *		Net		net - the net to use
 *		ExampleSet	exampleSet - the examples to use
 *	Return Value:	
 *		NONE
 ***********************************************************************/
static void	calculateNetErrorDeriv(net, exampleSet)
  Net		net ;
  ExampleSet	exampleSet ;
{
  int		numExamples ;

  if (!Mconfigured(net)) {
    fprintf(stdout, "This net has not yet been configured.\n");
    fprintf(stdout, "To configure the net, run\n");
    fprintf(stdout, "configureKohonenNet <netName> <xdim> <ydim> [<old net name> ]\n");
    return; }

  /* zero the net error and link derivative fields
   */
  net->error = 0.0 ;
  netForAllUnits(net, ~(INPUT | BIAS), zeroLinks, NULL) ;

  /* If its the first epoch - initialize the learning rate
   *                        - initialize the neighborhood stuff
   */
  if (net->currentEpoch == 0) {
    Mepsilon(net) = MinitialLearningRate(net); 
    resetNeighborhoods(net);
  }
  /* otherwise - decay the neighborhood size
   *           - decay the learning rate
   */
  else {
    decayNeighborhoods(net);
    decayLearningRate(net);
    }

  /* For each example	- do a forward pass updating the activities
   *			- update the derivatives
   */
  for (numExamples = 0 ; numExamples < MbatchSize(net) ; ++numExamples) {
    MgetNext(exampleSet) ;
    MupdateNetActivities(net) ;
    MupdateNetGradients(net) ;
  }

  if (numExamples <= 0)
    IErrorAbort("calculateNetErrorDeriv: no examples processed") ;

  /* update the cost after everything else is done */
  MevaluateCostAndDerivs(net) ;

}
/**********************************************************************/


/***********************************************************************
 *	Name:		calculateNetError
 *	Description:	error calculation procedure for scl net
 *			It processes 'MbatchSize(net)' examples
 *	Parameters:	
 *		Net		net - the net to use
 *		ExampleSet	exampleSet - the examples to use
 *	Return Value:	
 *		NONE
 ***********************************************************************/
static void	calculateNetError(net, exampleSet)
  Net		net ;
  ExampleSet	exampleSet ;
{
  int		numExamples ;

  if (!Mconfigured(net)) {
    fprintf(stdout, "This net has not yet been configured.\n");
    fprintf(stdout, "To configure the net, run\n");
    fprintf(stdout, "configureKohonenNet <netName> <xdim> <ydim> [<old net name> ]\n");
    return; }

  net->error = 0.0 ;

  /* If its the first epoch - initialize the learning rate
   *                        - initialize the neighborhood stuff
   */
  if (net->currentEpoch == 0) {
    Mepsilon(net) = MinitialLearningRate(net); 
    resetNeighborhoods(net);
  }
  /* Otherwise, check whether user has changed the neighborhood parameters
   */
  else if (MprevNeighborhoodFunction(net) != MneighborhoodFunction(net)
	   || MprevMaxDistance(net) != MmaxDistance(net))
    resetNeighborhoods(net);
  else if (MneighborhoodFunction(net) == GAUSSIAN 
	   && MprevVariance(net) != Mvariance(net))
    McalculateNeighborhoodDistanceProc(net); 

  for (numExamples = 0 ; numExamples < MbatchSize(net) ; ++numExamples) {
    MgetNext(exampleSet) ;
    MupdateNetActivities(net) ;
  }
  if (numExamples <= 0)
    IErrorAbort("calculateNetError: no examples processed") ;

  /* update the cost after everything else is done */
  MevaluateCost(net) ;
}
/**********************************************************************/

/***********************************************************************
 *	Name:		resetNeighborhoods
 *	Description:	Initialize the neighborhood calucation procedure,
 *                      maxDistance and variance, and compute neighbWeight 
 *                      field of all units accordingly.
 *	Parameters:	
 *		Net		net - the net to use
 *	Return Value:	
 *		NONE
 ***********************************************************************/
static void	resetNeighborhoods(net)
  Net		net ;
{
    MprevVariance(net) = Mvariance(net) = MinitialVariance(net); 
    MprevMaxDistance(net) = MmaxDistance(net) = MinitialMaxDistance(net);
    setNetNeighborhoodProc(net, MneighborhoodFunction(net));
    MprevNeighborhoodFunction(net) = MneighborhoodFunction(net);
    McalculateNeighborhoodDistanceProc(net); 
}

/**********************************************************************/

/***********************************************************************
 *	Name:		decayNeighborhoods
 *	Description:	Decay neighborhood weights according to
 *                      neighborhoodFunction and neighborhoodDecayFunction.
 *	Parameters:	
 *		Net		net - the net to use
 *	Return Value:	
 *		NONE
 ***********************************************************************/
static void	decayNeighborhoods(net)
  Net		net ;
{
  Real          decay;
  Real          minVar = MminVariance(net);

  if (MprevNeighborhoodFunction(net) != MneighborhoodFunction(net))
    resetNeighborhoods(net);
  else {
    switch(MneighborhoodDecayFunction(net)) {
    case EXPONENTIAL:
      decay = MneighborhoodDecayRate(net);
      break;
    case ONE_OVER_T:
      if (Mtau(net) < HUGE_VAL)
         decay = 1.0 / (1.0 + (Real)McurrentEpoch(net) / Mtau(net));
      else decay = 1.0;
      break;
    }
    MmaxDistance(net) = MAX(MmaxDistance(net) - MminDistance(net),0.0)
                        * decay + MminDistance(net);
    MprevMaxDistance(net) = MmaxDistance(net);

    if (MneighborhoodFunction(net) == GAUSSIAN && Mvariance(net) > minVar) 
      MprevVariance(net) =  Mvariance(net) =
	MAX(Mvariance(net) - minVar, 0.0) * decay + MminVariance(net);

    McalculateNeighborhoodDistanceProc(net); 
  }
}

/**********************************************************************/

/***********************************************************************
 *	Name:		decayLearningRate
 *	Description:	Decay learning rate (epsilon) according to
 *                      learningRateDecayFunction.
 *	Parameters:	
 *		Net		net - the net to use
 *	Return Value:	
 *		NONE
 ***********************************************************************/
static void	decayLearningRate(net)
  Net		net ;
{
  Real          decay;

    switch(MlearningRateDecayFunction(net)) {
    case EXPONENTIAL:
      decay = MlearningRateDecay(net);
      break;
    case ONE_OVER_T:
      decay = 1.0 / (1.0 + (Real)McurrentEpoch(net) / Mtau(net));
      break;
    }

  Mepsilon(net) *= decay;

}
/**********************************************************************/

/***********************************************************************
 *	Name:		setNetNeighborhoodProc
 *	Description:	set net->extension->calculateNeighborhoodDistanceProc
 *                          according to funcNumber.
 *                      funcNumber = UNIFORM (no falloff up to maxDistance)
 *                                   LINEAR falloff 
 *                                or GAUSSIAN falloff
 *	Parameters:	
 *		Net		net - the net to use
 *		ExampleSet	funcNumber - tells which neighborhood metric
 *	Return Value:	
 *		NONE
 ***********************************************************************/
static void	setNetNeighborhoodProc(net, funcNumber)
  Net		net ;
  int           funcNumber ;
{
  switch(funcNumber) {
  case UNIFORM: 
    net->extension->calculateNeighborhoodDistanceProc =
      calculateNetUniformNeighborhoods;
    break;
  case LINEAR:
    net->extension->calculateNeighborhoodDistanceProc =
      calculateNetLinearNeighborhoods;
    break; 
  case GAUSSIAN:
    net->extension->calculateNeighborhoodDistanceProc =
      calculateNetGaussianNeighborhoods;
    break;
  }
}
/**********************************************************************/

/***********************************************************************
 *	Name:		calculateNetUniformNeighborhoods
 *	Description:	set neighbWeight field of all units to be 1 if 
 *                      neighbors within maxDistance units, 0 otherwise
 *	Parameters:	
 *		Net		net - the net to use
 *	Return Value:	
 *		NONE
 ***********************************************************************/
static void	calculateNetUniformNeighborhoods(net)
  Net		net ;
{
  netForAllUnits(net, ~(INPUT | BIAS), calculateUnitUniformNeighborhood,NULL);
}

/**********************************************************************/

/***********************************************************************
 *	Name:		calculateNetLinearNeighborhoods
 *	Description:	set neighbWeight field of all units to fall off
 *                      linear with distance to neighbor, up to maxDistance
 *                      units away, beyond which neighbWeight is zero.
 *	Parameters:	 
 *		Net		net - the net to use
 *	Return Value:	
 *		NONE
 ***********************************************************************/
static void	calculateNetLinearNeighborhoods(net)
  Net		net ;
{
  netForAllUnits(net, ~(INPUT | BIAS), calculateUnitLinearNeighborhood,NULL);
}

/**********************************************************************/

/***********************************************************************
 *	Name:		calculateNetGaussianNeighborhoods
 *	Description:	set neighbWeight field of all units to fall off as a
 *                      Gaussian function of distance to neighbor, up to 
 *                      maxDistance units away, beyond which neighbWeight
 *                      is zero.
 *	Parameters:	
 *		Net		net - the net to use
 *	Return Value:	
 *		NONE
 ***********************************************************************/
static void	calculateNetGaussianNeighborhoods(net)
  Net		net ;
{
  netForAllUnits(net, ~(INPUT | BIAS), calculateUnitGaussianNeighborhood,NULL);
}

/**********************************************************************/

/**********************************************************************/
static Proc	calculateUnitUniformNeighborhood(unit, data)
  Unit	unit ;
  void	*data ;
{
  UnitExtensionRec *ext = unit->extension;
  int	neighbNum,
        numNeighbs = ext->numNeighbors;
  Real  maxDistance = MmaxDistance(unit->net),
        *distance = ext->distance,
        *neighbWeight = unit->extension->neighbWeight;

  for (neighbNum = 0;
       (neighbNum < numNeighbs && distance[neighbNum] <= maxDistance);
       ++neighbNum) {
      neighbWeight[neighbNum] =  1.0;
      ext->lastNeighborIndex = neighbNum;
    }
}

/**********************************************************************/
static Proc	calculateUnitLinearNeighborhood(unit, data)
  Unit	unit ;
  void	*data ;
{
  UnitExtensionRec *ext = unit->extension;
  int	neighbNum,
        numNeighbs = ext->numNeighbors;
  Real  maxDistance = MmaxDistance(unit->net),
        *distance = ext->distance,
        slope, intercept,
        *neighbWeight = unit->extension->neighbWeight;

  slope = - 1.0 / (maxDistance + 1.0);
  intercept = 1.0;
  for (neighbNum = 0;
       (neighbNum < numNeighbs && distance[neighbNum] <= maxDistance);
       ++neighbNum) {
    neighbWeight[neighbNum] = slope * distance[neighbNum] + intercept;
    ext->lastNeighborIndex = neighbNum;
  }
}

/**********************************************************************/
static Proc	calculateUnitGaussianNeighborhood(unit, data)
  Unit	unit ;
  void	*data ;
{
  UnitExtensionRec *ext = unit->extension;
  int	neighbNum,
        numNeighbs = ext->numNeighbors,
        uX = ext->x,
        uY = ext->y;
  Real  *neighbWeight = ext->neighbWeight,
        twoVariance = 2.0 * Mvariance(unit->net),
        *distance = ext->distance,
        maxDistance = MmaxDistance(unit->net);

  for (neighbNum = 0;
       (neighbNum < numNeighbs && distance[neighbNum] <= maxDistance);
       ++neighbNum) {
      neighbWeight[neighbNum] =  1.0 / (sqrt(PI * twoVariance) *
              exp(square(distance[neighbNum]) / twoVariance));
      ext->lastNeighborIndex = neighbNum;
    }
}
/**********************************************************************/
static Proc	zeroLinks(unit, data)
  Unit	unit ;
  void	*data ;
{
  int	numIncoming = unit->numIncoming ;
  Link	*incoming   = unit->incomingLink ;
  int	idx ;

  for (idx = 0 ; idx < numIncoming ; ++idx)
    incoming[idx]->deriv  = 0.0;
}

/**********************************************************************/


/***********************************************************************
 *	Name:		setUnitCoords
 *	Description:	sets the x and y extension fields according to 
 *                      the global variables curXIndex and curYIndex,
 *                      and increments these indices.
 *	Parameters:	
 *		Unit	unit - the unit to set the coords for
 *	Return Value:	NONE
 ***********************************************************************/

static Proc   setUnitCoords(unit, data)
  Unit	unit ;
  void	*data;
{
  Net   net = (Net)data ;
  int   x = McurXIndex(net),
        y = McurYIndex(net);
  unit->extension->x = x;
  unit->extension->y = y;
  ++(McurYIndex(net));
  if (McurYIndex(net) > MmaxYIndex(net)) {
    McurYIndex(net) = 0;
    ++(McurXIndex(net));
  }
  Munit(net)[x][y] = unit; 
}
/**********************************************************************/


/***********************************************************************
 *	Name:		initUnitNeighborhood
 *	Description:	Set the following unit fields:
 *                         lastNeighborIndex
 *                         numNeighbors
 *                      and for each neighbor, i, in order of increasing 
 *                      distance from unit:
 *                         neighbor[i] = pointer to the ith unit
 *                         distance[i] = euclidean distance to unit
 *	Parameters:	
 *		Unit	unit - the unit to set the coords for
 *	Return Value:	NONE
 ***********************************************************************/

static Proc	initUnitNeighborhood(unit, data)
  Unit	unit ;
  void	*data;
{
  Net   net = (Net)data ;
  UnitExtensionRec *ext = unit->extension;
  int   distance, maxDist, twoDist, x, y, neighborNum,
        dist1, dist2, offset1[2], offset2[2], nOffset2s,
        nOffset1s, xOffset, yOffset, rep, i, j,
        maxX = MmaxXIndex(net),
        maxY = MmaxYIndex(net),
        uX = ext->x,
        uY = ext->y;

  Real  maxDistance = MmaxDistance(net);

  maxDist = MAX(maxX, maxY);
  
  neighborNum = 0;
  /* traverse neighbors in order of increasing Euclidean distance 
   * from unit, and store in unit's lists of pointers to neighbors
   */
  for (dist1 = 0; dist1 <= maxDist; dist1++)
    for (dist2 = 0; dist2 <= dist1; dist2++) {
      nOffset1s = 1;
      offset1[0] = -dist1;
      if (dist1 != 0) offset1[nOffset1s++] = dist1;
      nOffset2s = 1;
      offset2[0] = -dist2;
      if (dist2 != 0) offset2[nOffset2s++] = dist2;
      for (i = 0; i < nOffset1s; i++) for (j = 0; j < nOffset2s; j++) {
	for (rep = 1; rep <= 2; rep++) {
	  if (rep == 1) {
	    xOffset = offset1[i];
	    yOffset = offset2[j];
	    if (dist1 == dist2) ++rep;
	  } else {
	    yOffset = offset1[i];
	    xOffset = offset2[j]; }
	  x = uX + xOffset;
	  y = uY + yOffset;
	  if (x >= 0 && x <= maxX && y >= 0 && y <= maxY) {
	    ext->neighbor[neighborNum] = Munit(net)[x][y];
	    ext->distance[neighborNum] = sqrt((Real)square(xOffset) +
					      (Real)square(yOffset));
            if (ext->distance[neighborNum] <= maxDistance)
	      ext->lastNeighborIndex = neighborNum;
	    neighborNum++;
	  }
	}}}
}

/**********************************************************************/

static Proc	incNetUnitCount(unit, data)
  Unit	unit ;
  void	*data;
{
  Net   net = (Net)data ;
  ++(MunitCounter(net));
}

/**********************************************************************/
static Real	square(x)
  double	x ;
{
  return (Real) (x * x) ;
}
/**********************************************************************/

int command_configureKohonenNet(tokc, tokv)
int tokc;
char *tokv[];
{ int  xDim, yDim, i, idx;
  Net  newNet,
       oldNet = NULL;
  char *newNetName,
       *oldNetName; 
  Unit *pUnit;

  IUsage("<name> <xdim> <ydim> [ <old net name> ]");
  if (GiveHelp(tokc)) {
    ISynopsis("Initialize a 2-dimensional Kohonen net of dim1 x dim2 units");
    IHelp(IHelpArgs,
	  "xdim: the number of units along the x dimesion",
	  "ydim: the number of units along the y dimesion",
	  "If <old net name> is provided, the weights for the new net",
          "will be interpolated from those of the old net; this allows",
          "one to increase the resolution of the current net without",
	  "losing the weights. Otherwise, weights are randomly initialized.",
 	  NULL);
    return 1;
  }

  if (tokc < 3 || tokc > 5)
    IErrorAbort(IPrintUsage(tokv[0], usage)) ;

  newNetName = tokv[1];
  if ((newNet = getNet(newNetName)) == NULL)
     IErrorAbort("Net not found.") ;
  xDim = atoi(tokv[2]);
  yDim = atoi(tokv[3]);
  if (tokc == 5) {
    oldNetName = tokv[4];
    if ((oldNet = getNet(oldNetName)) == NULL)
       IErrorAbort("Old net not found.") ;
  }

  if (Mconfigured(newNet)) {
    fprintf(stdout, "This net has already been configured.\n");
    fprintf(stdout, "To change the architecture, create a new\n");
    fprintf(stdout, "net and destroy this one.\n");
    return 1; }

  setNetNeighborhoodProc(newNet, MneighborhoodFunction(newNet));
  MprevNeighborhoodFunction(newNet) = MneighborhoodFunction(newNet);
  MunitCounter(newNet) = 0;
  netForAllUnits(newNet, ~(INPUT | BIAS), incNetUnitCount, newNet) ;
  if (xDim * yDim != MunitCounter(newNet)) {
    fprintf(stderr, "error: xDim * yDim must = number of output units (%d)\n",
	    MunitCounter(newNet));
    IErrorAbort();
  }
  /* allocate space for 2 d array of pointers to units
   */
  Munit(newNet) = (Unit **)calloc(xDim, sizeof(Munit(newNet)));
  for (i = 0; i < xDim; i++)
    Munit(newNet)[i] = (Unit*)calloc(yDim, sizeof(pUnit));

  netForAllUnits(newNet, ~(INPUT | BIAS), initKohonenUnit, NULL) ;
  MmaxXIndex(newNet) = xDim - 1;
  MmaxYIndex(newNet) = yDim - 1;
  McurXIndex(newNet) = 0;
  McurYIndex(newNet) = 0;
  netForAllUnits(newNet, ~(INPUT | BIAS), setUnitCoords, newNet) ;
  netForAllUnits(newNet, ~(INPUT | BIAS), initUnitNeighborhood, newNet) ;
  McalculateNeighborhoodDistanceProc(newNet); 
  
  Mconfigured(newNet) = 1;

  if (oldNet != NULL)
     netForAllUnits(newNet,  ~(INPUT | BIAS), interpolateWeights, oldNet);
  
  return 1;
}

/**********************************************************************/

int command_interpolateWeights(tokc, tokv)
int tokc;
char *tokv[];
{ int  xDim, yDim, i, idx;
  Net  newNet,
       oldNet = NULL;
  char *newNetName,
       *oldNetName; 
  Unit *pUnit;

  IUsage("<new net name> <old net name>");
  if (GiveHelp(tokc)) {
    ISynopsis("Interpolate the weights of one Kohonen net from another");
    IHelp(IHelpArgs,
          "<new net name> is the new network whose weights are to be",
	  "computed from those in the network <old net name>.",
 	  NULL);
    return 1;
  }

  if (tokc < 3 || tokc > 5)
    IErrorAbort(IPrintUsage(tokv[0], usage)) ;

  newNetName = tokv[1];
  if ((newNet = getNet(newNetName)) == NULL)
      IErrorAbort("Net not found.") ;
  oldNetName = tokv[2];
  if ((oldNet = getNet(oldNetName)) == NULL)
    IErrorAbort("Old net not found.") ;

  if (!Mconfigured(newNet)) {
    fprintf(stdout, "This net has not yet been configured.\n");
    fprintf(stdout, "To configure the network, call the\n");
    fprintf(stdout, "command configureKohonenNet\n");
    return 1; }

  netForAllUnits(newNet,  ~(INPUT | BIAS), interpolateWeights, oldNet);
  
  return 1;
}

/***************************************************************************
 * Interpolate weights of new network from old network:
 *
 * Transform unit's coordinates (uX,uY) into coordinate system of old net,
 * (oldX, oldY).
 * Find the nearest 4 neighbors of (oldX,oldY) to left, right, up and down 
 * in old net. 
 * Bilinearly interpolate the new weigths at (oldX,oldY) from the weights of
 * units at the 4 corners.
 *
 *   xL,yU --------- xR,yU
 *      |             |            
 *      |             |
 *      | oldX,oldY   |
 *      |             |
 *      |             |
 *      |             |
 *   xL,yD --------- xR,yD
 *
 ****************************************************************************/

static Proc	interpolateWeights(unit, data)
  Unit	unit ;
  void	*data;
{
  Net   oldNet = (Net)data ,
        newNet = unit->net;
  UnitExtensionRec *ext = unit->extension;
  int   xL, xR, yU, yD,
        oldMaxX = MmaxXIndex(oldNet),
        oldMaxY = MmaxYIndex(oldNet),
        maxX =  MmaxXIndex(newNet),
        maxY = MmaxYIndex(newNet),
        uX = ext->x,
        uY = ext->y,
        numIncoming = unit->numIncoming,
        idx;
  Link *incoming   = unit->incomingLink ,
       *linkLD, *linkLU, *linkRD, *linkRU;
  Real mult1, mult2, mult3, mult4, div, oldX, oldY;

  if (maxX == 0) oldX = 0;
  else oldX = (Real)(uX * oldMaxX) / (Real)maxX;
  if (maxY == 0) oldY = 0;
  else oldY = (Real)(uY * oldMaxY) / (Real)maxY;

  if (maxX == 0 || oldMaxX == 0)
    { xL = 0; xR = 0; }
  else if (uX == 0)
    { xL = 0; xR = 1; }
  else if (uX == maxX) 
    { xR = oldMaxX; xL = xR - 1; }
  else {
    xL = floor(oldX);
    xR = MIN(xL + 1,oldMaxX);
  }
  if (maxY == 0 || oldMaxY == 0)
    { yU = 0; yD = 0; }
  else if (uY == 0)
    { yU = 0; yD = 1; }
  else if (uY == maxY) 
    { yD = oldMaxY; yU = yD - 1; }
  else {
    yU = (int)floor(oldY);
    yD = MIN(yU + 1,oldMaxY);
  }

  linkLD = Munit(oldNet)[xL][yD]->incomingLink;
  linkLU = Munit(oldNet)[xL][yU]->incomingLink;
  linkRD = Munit(oldNet)[xR][yD]->incomingLink;
  linkRU = Munit(oldNet)[xR][yU]->incomingLink;

  /* check if old net has only 1 unit along
   * x or y dimension or both, and treat as
   * special cases
   */
  if (yU == yD && xL == xR) {
    /* Old net is a single unit.
     * Copy its weights to all new units.
     */
    for (idx = 0 ; idx < numIncoming ; ++idx) {
      Link	link  = incoming[idx] ;

      link->weight = linkRU[idx]->weight;
    }
  } else if (yU == yD || xL == xR) {
    /* Old net is 1-dimensional.
     */
    if (yU == yD) {
      div = xR - xL;
      mult1 = (xR - oldX) / div;
      mult2 = (oldX - xL) / div;
    } else {
      div = yD - yU;
      mult1 = (oldY - yU) / div;
      mult2 = (yD - oldY) / div;
    }
    for (idx = 0 ; idx < numIncoming ; ++idx) {
      Link	link  = incoming[idx] ;

      link->weight =   (mult1 * linkLD[idx]->weight
			+ mult2 * linkRU[idx]->weight);
    }
  } else {	
    /* Old net is 2-dimensional.
     */
    div = (xR - xL) * (yD - yU);
    mult1 = (xR - oldX) * (oldY - yU) / div;
    mult2 = (xR - oldX) * (yD - oldY) / div;
    mult3 = (oldX - xL) * (oldY - yU) / div;
    mult4 = (oldX - xL) * (yD - oldY) / div;
    for (idx = 0 ; idx < numIncoming ; ++idx) {
      Link	link  = incoming[idx] ;

      link->weight =   (mult1 * linkLD[idx]->weight
			+ mult2 * linkLU[idx]->weight
			+ mult3 * linkRD[idx]->weight
			+ mult4 * linkRU[idx]->weight);
    }
  }
}

/**********************************************************************/

/**********************************************************************/

static Proc	showUnitNeighbors(unit, data)
  Unit	unit ;
  void	*data;
{
  UnitExtensionRec *ext = unit->extension;
  int   neighborNum,
        uX = ext->x,
        uY = ext->y;

  for (neighborNum = 0; neighborNum <= ext->lastNeighborIndex; neighborNum++) 
    fprintf(stdout, "u[%d][%d]->u[%d][%d] Euclidean distance = %g, neighborhood weight = %g\n",
	    uX, uY,
	    (ext->neighbor[neighborNum])->extension->x,
	    (ext->neighbor[neighborNum])->extension->y, 
	    ext->distance[neighborNum], ext->neighbWeight[neighborNum]);
}
/**********************************************************************/

int command_showNeighbors(tokc, tokv)
int tokc;
char *tokv[];
{
  int x, y;
  IUsage("[ <unit-x> <unit-y> ]");
  if (GiveHelp(tokc)) {
    ISynopsis("Show the neighborhood distances to all other units in the net");
    IHelp(IHelpArgs,
	  "If x,y given, only show distances for unit at position (x,y),",
	  "otherwise show distances for all pairs of units.",
 	  NULL);
    return 1;
  }
  if (tokc != 1 && tokc != 3)
    IErrorAbort(IPrintUsage(tokv[0], usage)) ;

  if (tokc == 1)
     netForAllUnits(currentNet, ~(INPUT | BIAS), showUnitNeighbors, NULL) ;
  else {
     x = atoi(tokv[1]);
     y = atoi(tokv[2]);
     if (x < 0 || x > MmaxXIndex(currentNet) ||
	 y < 0 || y > MmaxYIndex(currentNet)) {
       fprintf(stdout,"error: (unit-x, unit-y) must lie within [0..%d, 0..%d]",
	        MmaxXIndex(currentNet), MmaxYIndex(currentNet));
       return 0; }
     showUnitNeighbors(Munit(currentNet)[x][y], NULL);
   }
  return 1;
}

/**********************************************************************/

