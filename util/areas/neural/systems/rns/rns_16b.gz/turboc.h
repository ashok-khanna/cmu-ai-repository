/*  $Id$  */

/*  Part of RNS -- Recurrent Network Simulator
 *
 *     by R. Kooijman
 *        T.U. Delft
 *        Faculteit Elektrotechniek
 *        Vakgroep Computerarchitectuur
 *        Sectie Neurale Netwerken
 */


/*  $Log$
 *   */



/*  extra definities voor Turbo C  */


#ifndef _TURBOC_H
#define _TURBOC_H        /*  beveilig tegen herhaalde '#include <turboc.h>'  */


/*  Turbo C's 'srand()' en 'random()' functie  */
#define Srand(seed)     srand(seed)
#define Random(num)     random(num)


#endif  /*  _TURBOC_H  */

