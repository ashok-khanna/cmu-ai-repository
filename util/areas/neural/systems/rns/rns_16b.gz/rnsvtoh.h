/*  $Id: rnsvtoh.h,v 1.1 1991/10/10 16:43:08 richard Exp richard $  */

/*  Part of RNS -- Recurrent Network Simulator
 *
 *     by R. Kooijman
 *        T.U. Delft
 *        Faculteit Elektrotechniek
 *        Vakgroep Computerarchitectuur
 *        Sectie Neurale Netwerken
 */


/*  $Log: rnsvtoh.h,v $
 * Revision 1.1  1991/10/10  16:43:08  richard
 * Initial revision
 *  */



/*  functies voor het aanmaken en behandelen van random bitpatronen  */


#ifndef _RNSVTOH_H
#define _RNSVTOH_H


#define MAXVTOHRETRIES   500


typedef struct Vtohhd_struct  *Vtohhdptr;

typedef struct Vtoh_struct  *Vtohptr;


typedef struct Vtohhd_struct
{
   int  nrbits;
   int  distance;

   Vtohptr  list;

} Vtohhd;


typedef struct Vtoh_struct
{
   unsigned long  value;
   unsigned long  randomvalue;

   Vtohptr  next;

} Vtoh;


#endif  /*  _RNSVTOH_H  */

