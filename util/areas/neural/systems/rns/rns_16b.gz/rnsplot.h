/*  $Id$  */

/*  Part of RNS -- Recurrent Network Simulator
 *
 *     by R. Kooijman
 *        T.U. Delft
 *        Faculteit Elektrotechniek
 *        Vakgroep Computerarchitectuur
 *        Sectie Neurale Netwerken
 */


/*  $Log$  */



/*  functies voor het opbouwen van plot files  */


#ifndef _RNSPLOT_H
#define _RNSPLOT_H


#ifdef __TURBOC__
#define TURBOC           /*  definieer TURBOC als __TURBOC__  */
#endif

#ifdef UNIX
#undef TURBOC            /*  maak TURBOC definitie ongedaan als UNIX  */
#endif


#ifdef TURBOC
#else
#endif



#endif  /*  _RNSVTOH_H  */

