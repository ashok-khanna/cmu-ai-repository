/*--- timer declaration for SDL system DemonGame ---*/

#ifndef __SDLSystem_DemonGame_Timers_h
#define __SDLSystem_DemonGame_Timers_h
#include"SDLSystem_DemonGame_Signals.h"

enum System_DemonGame_Timers
{
	T=End_of_Signallist+1,
	End_of_Timerlist
};

#endif /*__SDLSystem_DemonGame_Timers_h */