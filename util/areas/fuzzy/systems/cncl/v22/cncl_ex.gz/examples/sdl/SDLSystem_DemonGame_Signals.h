/*--- signal declaration for SDL system DemonGame ---*/

#ifndef __SDLSystem_DemonGame_Signals_h 
#define __SDLSystem_DemonGame_Signals_h

enum System_DemonGame_Signals 
{ 
   INIT=0,
   Newgame, 
   Bump, 
   Score, 
   Lose, 
   Win, 
   Endgame, 
   Result, 
   Probe, 
   GameOver, 
   End_of_Signallist
}; 

#endif /* __SDLSystem_DemonGame_Signals_h */