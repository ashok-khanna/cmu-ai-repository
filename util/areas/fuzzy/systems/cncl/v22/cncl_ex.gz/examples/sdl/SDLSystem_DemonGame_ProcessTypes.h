/*--- process type declaration for SDL system DemonGame ---*/

#ifndef __SDLSystem_DemonGame_ProcessType_h 
#define __SDLSystem_DemonGame_ProcessType_h

enum System_DemonGame_ProcessType 
{ 
	Demon = 4,
	Game = 3,
	Main = 2,
	End_of_ProcessTypelist
}; 

#endif /* __SDLSystem_DemonGame_ProcessType_h */