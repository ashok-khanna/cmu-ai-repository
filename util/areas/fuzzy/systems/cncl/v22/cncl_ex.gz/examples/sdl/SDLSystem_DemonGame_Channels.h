/*--- channel declaration for SDL system DemonGame---*/

#ifndef __SDLSystem_DemonGame_Channel_h 
#define __SDLSystem_DemonGame_Channel_h 

enum System_Channel 
{ 
   C1 = 1, 
   C3, 
   C2, 
   End_of_Channellist
}; 

#endif /* __SDLSystem_DemonGame_Channel_h */