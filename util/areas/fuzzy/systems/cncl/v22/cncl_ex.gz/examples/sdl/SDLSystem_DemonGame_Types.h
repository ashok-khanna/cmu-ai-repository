#ifndef __SDLSystem_DemonGame_Types_h 
#define __SDLSystem_DemonGame_Types_h 


#endif /* SDLSystem_DemonGame_Types_h */
