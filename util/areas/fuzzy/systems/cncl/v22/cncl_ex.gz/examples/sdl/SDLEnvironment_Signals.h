#ifndef __SDLEnvironmentSignals_h_
#define __SDLEnvironmentSignals_h_

enum EnvironmentSignals {
    Dummy = -1
};

#endif /** __SDLEnvironmentSignals_h_ **/
