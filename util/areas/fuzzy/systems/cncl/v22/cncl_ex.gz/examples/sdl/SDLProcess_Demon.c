#include "SDLProcess_Demon.h"

SDLProcess_Demon::SDLProcess_Demon(char *name,CNSDLManager *system, int process_type):CNSDLProcess(name, system, process_type)
{}


virtual int SDLProcess_Demon::process(int signal)
{
	switch(state()){

	case INIT:
				System->set(now()+1,T);
				state(Generate);
				return 0;

	case Generate: switch(signal) {

				case T:
				System->output(Bump,3,System->channel(C3));
				System->set(now()+1,T);
				state(Generate);
				return 0;

				default: return 0;
			}

	default: error("illegal state");
			return 0;
	}
}


/***** Default I/O member function for CNCL classes **************************/

// Normal output
void SDLProcess_Demon::print(ostream &strm) const
{
	strm << "..." << endl;
}

// Debug output
void SDLProcess_Demon::dump(ostream &strm) const
{
	strm << "SDLProcess_Demon { $Revision$ ..."
	<< " }" << endl;
}

/***** CNCL stuff for type information ***************************************/

// Describing object for class SDLProcess_Demon
static CNClass SDLProcess_Demon_desc("SDLProcess_Demon", "$Revision$",
			SDLProcess_Demon::new_object);

// "Type" for type checking functions
CNClassDesc CN_SDLPROCESS_Demon = &SDLProcess_Demon_desc;