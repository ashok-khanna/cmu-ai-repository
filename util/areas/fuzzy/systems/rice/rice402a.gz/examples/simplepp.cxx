// File:   simplepp.cxx
// Author: Rene' Jager
// Update: June 11, 1992
// Info:   simple C++ example for RICE

// Use of `xx' instead of `pp' for Gnu (Unix-like) compiler.

#include "simplepp.cpp"



