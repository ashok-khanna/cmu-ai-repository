//   file : hmm.cc
// authors: Richard Myers and Jim Whitson
// version: a0.01 [May 21, 1994]

#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>
#include <fstream.h>
#include <string.h>
#include "hmm.h"

main(int argc, char* argv[])
{
  // check args
  if (argc < 3) {
    cerr << "ERROR: Too few arguments.\n\n" << 
    "Usage: "<< argv[0]<<" <test_file> <initial_model>\n";
    exit (-1);
  }
  
  // get command line parms
  char* train_file=argv[1];
  char* initial_model=argv[2];

  hmm *new_hmm;
  // initialize model from model file
  new_hmm = new hmm(initial_model);
  // test model on data
  new_hmm->batch_test(train_file);
}

