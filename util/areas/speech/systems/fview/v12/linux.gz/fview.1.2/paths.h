/*
  title:   paths.h
  purpose: Paths to system utilities (used by fview.c and src/ascii.c).
  
  authors:  Gareth Lee.
  date:     28-06-94
  modified: 

  Copyright (C) 1994 Gareth Lee.
     
  This program is free software; you can redistribute it and/or
  modify it under the terms of the GNU General Public License
  as published by the Free Software Foundation; either version 2
  of the License, or (at your option) any later version.
  
  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.
  
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

  changes:
*/

/* extension and path of the unix uncompress utility */
#define UNCOMPRESS_EXTN ".Z"
#define UNCOMPRESS      "/usr/bin/uncompress -c"

/* extension and path of the GNU gunzip utility */
#define GUNZIP_EXTN      ".gz"
#define GUNZIP           "/usr/bin/gunzip -c"

/* end of paths.h */
