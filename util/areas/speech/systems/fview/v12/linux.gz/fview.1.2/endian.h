/*
  title: endian.h
  purpose: To provide byte ordering information to programs within the fview
    package.

  author:   Gareth Lee.
  date:     05-05-94
  modified: 

  changes:
*/
#ifndef ENDIAN_H
#define ENDIAN_H

#define LITTLE_ENDIAN (1234)
#define BIG_ENDIAN    (4321)

#if defined SUNOS
#define BYTE_ORDER BIG_ENDIAN
#elif defined LINUX
#define BYTE_ORDER LITTLE_ENDIAN
#else
#error Byte ordering unclear for this achitecture.
#endif

#endif
