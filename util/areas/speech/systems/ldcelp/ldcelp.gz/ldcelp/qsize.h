#ifndef QSIZE_H
#define QSIZE_H

/* Size of the queue (I/O buffer) */

#define QSIZE 60

#endif /*QSIZE_H*/
