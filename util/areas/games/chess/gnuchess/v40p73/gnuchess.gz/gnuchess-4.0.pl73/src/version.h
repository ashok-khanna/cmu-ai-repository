/*
 * This is GNU Chess.
 * Copyright (c) 1986-1992 Free Software Foundation.
 *
 */
CHAR *version = "4.00";
CHAR *patchlevel = "73";
