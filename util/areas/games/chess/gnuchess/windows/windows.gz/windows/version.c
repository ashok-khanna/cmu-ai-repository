char Version[]="Thu Dec 27 19:52:33 1990";
