//			GSTREAM.HPP
// DESCRIPTIONS: class that turns gnuplot into a stream, into which you can print
// as any other

// CAVEATS: Only for UNIX!!!!

// LOG :
// 11-May-94	: Creacion
// 19-may-94	: alteracion de los nombres de los ficheros; y correccion del
//		    error, lo dejaba todo perdido de gnus...
// 20-May-94	:   Aniadida restart...
//		    Faltaba algun void...
//		    Poder pintar con lineas o puntos


#ifndef __GSTREAM_HPP
#define __GSTREAM_HPP

#include <fstream.h>

typedef enum plotType { LINES, DOTS, POINTS };

#include <stdio.h>

class gstream {
    FILE *gnuFile;
    fstream tempF;			// to contain output file
    char tempGnu[17];
    char plType;
    bool flush;
    
    friend gstream& operator << ( gstream&, float );
    friend gstream& operator << ( gstream&, float* );
    friend gstream& operator << ( gstream&, char* );
    void rePlot();				// private func
    
public:
    gstream( char* _initStr, plotType _plType = LINES, bool _flush = TRUE );
    ~gstream();
    
    const char* getTemp() const { return tempGnu; };
    void    reStart( void );
    
};

#endif
