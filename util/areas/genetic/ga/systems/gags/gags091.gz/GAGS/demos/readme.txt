There are 4 .ga files, which are simple examples of how functions-to-optimize
should be written. 
	*minsqu.ga   tries to minimize the minimum square error of a cloud of
	points included in the file "nube" (spanish for cloud).
	*minsqu2.ga  does the same, but without using loops.
	*1pt.ga      tries to minimize the distance to 1 2d point, x=
	0.5, y = 0.5
	*smplfile.ga measures the distance to another simple file,
	smplfile.tra ( the name is longer than the contents), which
	contains 3 1-dimensional points, 0, 1 and 2.

gags.pl uses the environment variables GAGSLIB and GAGSINC; if you
have placed headers and library in a reasonable place, you won't need
to set them, otherwise, you will have to do it. The makefile does this
for you, but if you execute gags.pl, you'll have to bear this in mind.
