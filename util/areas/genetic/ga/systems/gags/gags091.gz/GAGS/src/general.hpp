// ------------------------------ GENERAL.HPP	----------------------
// Includes #defs and whatnots used from everywhere in the program
// Historia:
// 18-Mar-94	: Creacion del fichero de cabecera
// 20-Mar-94	: inclusion de los ficheros math.h y time.h, debido
//		  a un error del compilador
// 22-Mar-94	: Definicion de SEP
//  5-May-94	:   Aniadido IOSTREAM.H, para utilizar funciones C++ de
//		    i/o
//		    Aniadido un template para intercambiar dos valores


#ifndef _GENERAL_HPP
#define _GENERAL_HPP

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>

#include <iostream.h>


// general type definition
typedef enum bool { FALSE=0, TRUE };
typedef char fileName[100];

// portable definition of a random generation function
#ifdef __BCPLUSPLUS__
#define myrand( x ) random( x )
#else
#define myrand( x ) ((int) lrand48() % (x))
#endif

// portable definition of random seed generator
#ifdef __BCPLUSPLUS__
#define mysrand()	srand( (unsigned) time( (time_t) 0 ) )
#else
#define mysrand()	srand48( (unsigned) time( (time_t) 0) )
#endif


// portable definition of the directory separator
#ifdef __MSDOS__
#define SEP '\\'
#else
#define SEP '/'
#endif


// templates galore

// ---------------------------------------------
template <class swapType>
void swap( swapType& _s1, swapType& _s2 ) {
// -- swaps contents of the two variables
// -----------------------------------------------
    swapType tmp = _s1;
    _s1 = _s2;
    _s2 = tmp;
}

#endif // _GENERAL_HPP
