/*
* portlayr.h
*
*
* Copyright (c) 1991, 1992 by Marc W. Cygnus and Virtual Life
* All Rights Reserved.
*
*/

#ifndef __PORTLAYR_H
#define __PORTLAYR_H


#ifdef ANSI
# define	P_(A)	A
#else
# define	P_(A)	()
#endif


#endif  /* ifndef __PORTLAYR_H; Add nothing past this point */
