/* Buffer I/O for sockets: read/write length of buffer, then buffer itself.
 */
#ifndef _buffer_io_h_
#define _buffer_io_h_

#ifdef __STDC__
extern int write_buffer(int fd, char *buf, int nbyte);
extern int read_buffer(int fd, char *buf, int maxbytes);
extern int read_malloc(int fd, char **pbuf);
#else
extern int write_buffer();
extern int read_buffer();
extern int read_malloc();
#endif

#endif  _buffer_io_h_
