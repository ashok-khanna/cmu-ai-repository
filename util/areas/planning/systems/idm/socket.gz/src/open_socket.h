/* open_socket.h: external declarations of open_socket and fopen_socket.
 *
 * Leonard Dickens  3/28/91
 */
#ifndef _open_socket_h_
#define _open_socket_h_

#ifdef __STDC__

extern int open_socket(char *host_name, char *port_num) ;

#else

extern int open_socket();

#endif
#endif
