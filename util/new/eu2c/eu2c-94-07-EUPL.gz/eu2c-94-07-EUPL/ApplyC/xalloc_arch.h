/*
This code was developed in the joint research project APPLY funded by
the German Ministry of Research and Technology under the project code
ITW9102D5.

Copyright 1994-2010 Fraunhofer ISST

Licensed under the EUPL, Version 1.1 or � as soon they will be approved by the European Commission - subsequent 
versions of the EUPL (the "Licence");

You may not use this work except in compliance with the Licence.
You may obtain a copy of the Licence at:
http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
Unless required by applicable law or agreed to in
writing, software distributed under the Licence is distributed on an "AS IS" basis,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

See the Licence for the specific language governing permissions and limitations under the Licence.




--------------------------------------------------------------------------------TITLE: architecture dependent xalloc definitions
--------------------------------------------------------------------------------File:    xalloc_arch.h
Version: 1.0 (last modification on Mon Feb  7 09:18:44 1994)
State:   published


DESCRIPTION:


DOCUMENTATION:

NOTES:

REQUIRES:

PROBLEMS:

AUTHOR:
j.bimberg

CONTACT: 
j.bimberg
HISTORY: 
Log for /export/home/saturn/ukriegel/Eu2C/ApplyC/xalloc_arch.h[1.0]:
  contains all the machine/architecture dependent stuff
  included by trace.c 

--------------------------------------------------------------------------------
*/

#ifndef machdep_h
#define machdep_h

#ifdef	__sparc__	/* SPARC ELC, SPARC 2, SPARC 10 */

#define STACK_GROWS_DOWN
#define PTR_ALIGN	4

#define DATASTART	(long *)&etext

#define	SAVE_REGS()	asm("t	3")	/* ST_FLUSH_WINDOWS */	

#define ARCH_KNOWN
#endif	__sparc__

#ifdef	__hp9000s700	/* HP 9000 S 700 */

#define STACK_GROWS_UP
#define PTR_ALIGN	4

#define DATASTART	(long *)0x40001000

#define SAVE_REGS()	save_registers()	/* an extern assembler function,
						   hp doesn't support inline */
#define NB_REGS		29

#define ARCH_KNOWN
#endif	__hp9000s700


#if defined DOS386 || defined __NT__	/* DOS/Windows 32 bit extender */

#define STACK_GROWS_DOWN
#define PTR_ALIGN	4

#define SAVE_REGS()	save_registers()	/* a C-function with inline
						   assembly statements */
#define NB_REGS		6

#define ARCH_KNOWN
#endif DOS386 || __NT__


#ifndef ARCH_KNOWN
	--> unsupported machine, sorry
#endif

#endif

