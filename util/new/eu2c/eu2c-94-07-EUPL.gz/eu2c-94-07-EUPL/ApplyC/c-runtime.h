/*
This code was developed in the joint research project APPLY funded by
the German Ministry of Research and Technology under the project code
ITW9102D5.

Copyright 1994-2010 Fraunhofer ISST

Licensed under the EUPL, Version 1.1 or � as soon they will be approved by the European Commission - subsequent 
versions of the EUPL (the "Licence");

You may not use this work except in compliance with the Licence.
You may obtain a copy of the Licence at:
http://www.osor.eu/eupl/european-union-public-licence-eupl-v.1.1
Unless required by applicable law or agreed to in
writing, software distributed under the Licence is distributed on an "AS IS" basis,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

See the Licence for the specific language governing permissions and limitations under the Licence.
-----------------------------------------------------------------------------------
TITLE: Initialization of c runtime constants
-----------------------------------------------------------------------------------
File:    c-runtime.h
Version: 1.4 (last modification on Fri Jan 28 12:50:53 1994)
State:   published

DESCRIPTION:
Initialization of runtime environment for EuLisp/Apply

DOCUMENTATION:

NOTES:

REQUIRES:

PROBLEMS:

AUTHOR:
Ingo Mohr

CONTACT: 
ulrich.kriegel@isst.fhg.de

HISTORY: 
Log for /export/home/saturn/ukriegel/Eu2C/ApplyC/c-runtime.h[1.4]:
  header file for c-runtime.c
[1.1] Tue Jan 11 13:35:17 1994 ukriegel@isst proposed
  [Tue Jan 11 13:30:04 1994] Intention for change:
  std ...
  done
[1.2] Tue Jan 11 14:16:44 1994 ukriegel@isst proposed
  [Tue Jan 11 14:14:36 1994] Intention for change:
  HeapBegin,HEAPEND
  done
[1.3] Wed Jan 12 13:56:39 1994 ukriegel@isst proposed
  [Wed Jan 12 13:51:56 1994] Intention for change:
  claen up
  done
[1.4] Fri Jan 28 12:51:09 1994 jbimberg@isst published
  [Fri Jan 28 12:50:26 1994] Intention for change:
  remove signal and timer
  done

-----------------------------------------------------------------------------------
*/

extern long	*HEAPBEGIN, *HEAPEND;

void gc_init();

void c_runtime_init();

/*EOF c-runtime.h*/







