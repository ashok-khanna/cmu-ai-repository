/*
 Copyright (C) Johan Ceuppens 2009,2010,2011,2012 
*/
#ifndef _STORAGE_H_
#define _STORAGE_H_
#define FUNCSTACKSIZE 1024
typedef struct functionstackelt {int (*f)(char *, char *); char *arg1; char *arg2;} FunctionstackElt;  
typedef FunctionstackElt *Functionstack[FUNCSTACKSIZE]; 
int functionstackpointer_global;
Functionstack functionstack_global;

int store_function(int (*f)(char *, char *), char *, char *);
int emit_functions();

#endif
