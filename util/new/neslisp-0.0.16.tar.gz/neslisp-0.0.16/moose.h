/*
 Copyright (C) Johan Ceuppens 2009,2010,2011,2012 
*/
#ifndef _MOOSE_H_
#define _MOOSE_H_

#define BUFSIZE 1024
#include "stack.h"

#define LOOP "loop"
#define WHEN "when"
#define DEFUN "defun"
#define IF "if"
#define IFELSE "0ifelse"
#define IFTHIRD "2ifelse"
#define WHENELSE "1whenelse"

Stack *stack_global;
int labelcounter;
#endif
