./neslisp
#cat test.lisp | ./nescc
