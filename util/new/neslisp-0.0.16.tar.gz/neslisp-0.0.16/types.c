/*
 Copyright (C) Johan Ceuppens 2009,2010,2011,2012 
*/
#include <stdio.h>
#include <stdlib.h>
#include "symboltable.h"

int make_integer(SymtabElt **se, int value)
{

	(*se)->type = INTEGER;
	(*se)->Integer = value;	
	(*se)->Float = value;	
	(*se)->Character = 0;	
	(*se)->Null = NULL;
	(*se)->String = (char *)malloc(1024);//FIXME fixed value	
	sprintf((*se)->String, "%d\0", value);

}
