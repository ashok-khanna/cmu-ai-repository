/*
 Copyright (C) Johan Ceuppens 2009,2010,2011,2012 
*/
#include "storage.h"

int store_function(int (*f)(char *, char *), char *argstr1, char *argstr2)
{
	FunctionstackElt *e = (FunctionstackElt *)malloc(sizeof(FunctionstackElt));
	e->f = f;
	e->arg1 = argstr1;
	e->arg2 = argstr2;
	functionstack_global[functionstackpointer_global++] = e;
}

int emit_functions()
{
	int i = 0;
	for (i = 0; i < functionstackpointer_global; i++) {	
		FunctionstackElt *e = functionstack_global[0];
		(e->f)(e->arg1,e->arg2);
	}
}


