/*
# Copyright (C) Johan Ceuppens 2009,2010 
*/
#ifndef _NESCC_SYMTAB_H_
#define _NESCC_SYMTAB_H_

/* list */

typedef struct list { int length; } List; 

/* symboltable.c */
enum symtabtypes { INTEGER = 100, CHAR = 201, STRING = 302, FLOAT = 403, NIL = 504, FUNC = 605, LIST = 707, FUNCARG = 808, LOOPARG = 909, }; 
typedef struct symtabelt { int pn /*pointername*/; int address; int type; int Integer; float Float; char Character; char *String; List *List; void *Null;} SymtabElt;

typedef SymtabElt *Symtab;

typedef struct symtabnameelt { char *name; int address; } SymtabNameElt;
typedef SymtabNameElt *SymtabName;

//#define HEAPSIZE 1024
#define HEAPSIZE 65665

Symtab symtab_global[HEAPSIZE];
SymtabName symtabname_global[HEAPSIZE];
int heappointername_global;
int heapmaxname_global;
int heappointer_global;
int heapmax_global;
int make_symtab ();

/* gets */

char *get1(char *str);

#endif
