/*
 Copyright (C) Johan Ceuppens 2009,2010,2011,2012 
*/
#ifndef _STACK_H_
#define _STACK_H_

typedef struct stackel { char *elt; char *name; struct stackel *next; } StackElt;
typedef struct stack { int length; StackElt *stack; } Stack; 



#endif
