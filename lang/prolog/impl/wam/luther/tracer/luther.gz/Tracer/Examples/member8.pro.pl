start :- member(a(b(X)), [a(1), a(b(2))]), halt.

member(H, [H | T]).
member(X, [H | T]) :- member(X, T).
