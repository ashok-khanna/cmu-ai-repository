start :- member(d, [a,b,c]), halt.

member(H, [H | T]).
member(X, [H | T]) :- member(X, T).
