
start:-append(A,B,[a,b,c,d,e]),append(C,[D|E],A),halt.

append([],A,A).
append([A|B],C,[A|D]):-append(B,C,D).


