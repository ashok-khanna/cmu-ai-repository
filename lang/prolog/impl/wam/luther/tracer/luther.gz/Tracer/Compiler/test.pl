start :- append([a,b,c],[],D), p(D), halt.

append([],X,X).
append([X|Xs], Ys, [X|Zs]) :- append(Xs,Ys,Zs).

p([a,b,c]).
