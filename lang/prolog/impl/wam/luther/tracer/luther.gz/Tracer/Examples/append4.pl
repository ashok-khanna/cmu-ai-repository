
start:-append(A,[e|B],C),halt.

append([],A,A).
append([A|B],C,[A|D]):-append(B,C,D).


