start :- member(X, Y), halt.

member(H, [H | T]).
member(X, [H | T]) :- member(X, T).
