
start:-append(A,B,[a,b]),halt.

append([],A,A).
append([A|B],C,[A|D]):-append(B,C,D).


