:- compilef(['../Examples2/append1','../Examples2/append2',
     '../Examples2/append3','../Examples2/append4',
     '../Examples2/classify.pro','../Examples2/flatten.pro',
     '../Examples2/gp.pro','../Examples2/member1.pro',
     '../Examples2/member2.pro','../Examples2/member3.pro',
     '../Examples2/member4.pro','../Examples2/member5.pro',
     '../Examples2/member6.pro','../Examples2/member7.pro',
     '../Examples2/member8.pro','../Examples2/nrev.pro',
     '../Examples2/queue.pro','../Examples2/sublist.pro']).
