start :- member(X, Y), write(X), halt.

member(H, [H | T]).
member(X, [H | T]) :- member(X, T).
