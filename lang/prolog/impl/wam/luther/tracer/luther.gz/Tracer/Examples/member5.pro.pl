start :- member(X, [a,b,c]), member(X, [b,c]), halt.

member(H, [H | T]).
member(X, [H | T]) :- member(X, T).
