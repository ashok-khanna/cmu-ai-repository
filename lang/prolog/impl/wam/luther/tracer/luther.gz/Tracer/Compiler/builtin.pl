% -*- Prolog -*- 
%    File:	builtin.pl  (/home/bast/bevemyr/Andorra/c/compiler/builtin.pl)
%    Author:	Johan Bevemyr
%    Created:	Fri Aug 10 13:44:07 1990
%    Purpose:   
 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%
%%% builtin(Name/Arity)
%%%

builtin('$display'/1).
%builtin(nl/0).
builtin(functor/3).
builtin(arg/3).
builtin(name/2).
builtin(halt/0).

builtin(garbage_collect/0).

builtin(true/0).
builtin(data/1).
builtin(atomic/1).
builtin(integer/1).
builtin(atom/1).
builtin(compound/1).
builtin(greater/2).
builtin(less/2).
builtin(equal/2).
builtin('$notequal'/2).

builtin('$plus'/3).
builtin('$splus'/3).
builtin('$minus'/3).
builtin('$times'/3).
builtin('$div'/3).


% I/O

builtin(get0/1).
builtin(get/1).
builtin(put/1).
builtin(tell/1).
builtin(told/0).
builtin(see/1).
builtin(seen/0).
