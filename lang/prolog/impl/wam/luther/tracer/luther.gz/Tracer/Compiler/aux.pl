%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%
%%%	File: aux.pl
%%%	Author: olin (Peter Olin)
%%%	Date:		
%%%     Modified: 18 July, 1990 for Andorra by Johan Bevemyr
%%%	Purpouse:	
%%%
%%% HISTORY
%%% Author	Date		Description
%%% PO		7/10-89		Created
%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%
%%%  compiler_version(Version).
%%%

compiler_version('v1.2b').

%%%
%%% head(Clause,Head)
%%%

head(clause(_,_,hb(head(Head,_),_)), Head).


%%%
%%% body(Clause,Guard)
%%%

body(clause(_,_,hb(_,body(Body))), Body).

%%%
%%% label(Clause,Label)
%%%

label(clause(_,L,_),L).


%%%
%%% permvars(Clause,Permvars)
%%%

permvars(clause(NrPermVars,_,_), NrPermVars).

