start :- member(a(X), [a(1)]), halt.

member(H, [H | T]).
member(X, [H | T]) :- member(X, T).
