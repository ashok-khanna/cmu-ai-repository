/*  Copyright (C) 1990, Jim Crammond, Imperial College. All rights reserved.  */

/*
 *  return codes
 */
#define FAIL			0
#define SUCCESS			1
#define SUSPEND			2
#define REQUEUE			3
/* S vjb 28/2/92 */
#define SUSPEND_FOR_EVENT	4
/* E vjb 28/2/92 */


/*
 *  arguments to c predicates
 */
#define	A0	Args[0]
#define	A1	Args[1]
#define	A2	Args[2]
#define	A3	Args[3]
#define	A4	Args[4]
#define	A5	Args[5]
#define	A6	Args[6]
#define	A7	Args[7]
