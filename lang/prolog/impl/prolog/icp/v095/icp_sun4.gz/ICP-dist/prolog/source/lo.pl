/*****************************************************************************
LOGIC & OBJECTS ------------- IC PROLOG ][ version

written by F.G.McCabe (fgm@doc.ic.ac.uk)
modified for IC PROLOG ][ by Z.Bobolakis (zb@doc.ic.ac.uk)
last modified: 25 Jan 1993

Logic Programming Section
Dept. of Computing
Imperial College
London
******************************************************************************/

% L&O File

?- consult(looperators).
?- load(loenv).
?- load(lolow_level).
?- load(lodynamic).
?- load(lotranslator).
?- load(lotracing).
?- load(loexpressions).
?- load(lotop).
?- lo_notrace.
?- dynamic '?local_pred?'/4, '?dynamic?'/4, '?::?'/3.
