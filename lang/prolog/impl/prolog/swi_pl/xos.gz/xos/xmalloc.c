/*  $Id$

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1994 University of Amsterdam. All rights reserved.
*/

#ifdef MD
#include MD
#endif

#ifdef __WINDOWS__
#include <windows.h>
#endif

#define __XMALLOC_KERNEL__
#include <stdio.h>
#include <stdlib.h>
#include "xmalloc.h"


		 /*******************************
		 *	    ALLOCATION		*
		 *******************************/

void *
_xos_malloc(size_t bytes)
{ void *mem;

  if ( !(mem = malloc(bytes)) && bytes > 0 )
  { MessageBox(NULL, "Not enough memory", "Error", MB_OK);
    exit(1);
  }
  
  return mem;
}


void *
_xos_realloc(void *mem, size_t bytes)
{ void *newmem;

  if ( !(newmem = realloc(mem, bytes)) && bytes > 0 )
  { MessageBox(NULL, "Not enough memory", "Error", MB_OK);
    exit(1);
  }
  
  return newmem;
}
