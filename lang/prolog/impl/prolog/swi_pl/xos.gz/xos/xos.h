/*  $Id$

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1994 University of Amsterdam. All rights reserved.
*/

#ifndef XOS_INCLUDED
#define XOS_INCLUDED

#ifndef __XOS__
#define __XOS__ 1
#endif

#include <xos/xfile.h>
#include <xos/xmalloc.h>

#endif /*XOS_INCLUDED*/
