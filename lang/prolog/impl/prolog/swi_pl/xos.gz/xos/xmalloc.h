/*  $Id$

    Part of XPCE
    Designed and implemented by Anjo Anjewierden and Jan Wielemaker
    E-mail: jan@swi.psy.uva.nl

    Copyright (C) 1994 University of Amsterdam. All rights reserved.
*/

#ifndef XMALLOC_INCLUDED
#define XMALLOC_INCLUDED

#ifndef __XMALLOC__
#define __XMALLOC__ 1
#endif

#include <direct.h>

#ifndef __XMALLOC_KERNEL__
#define malloc(size)		_xos_malloc(size)
#define realloc(buf, size)	_xos_realloc(buf, size)
#endif

void *		_xos_malloc(size_t bytes);
void *		_xos_realloc(void *mem, size_t bytes);

#endif /*XMALLOC_INCLUDED*/
