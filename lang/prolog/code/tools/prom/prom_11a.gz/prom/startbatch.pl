/* This is startup.pl
**
** Purpose: Initial settings for ``batch'' PROM
**
** (c) T.Kielmann, 92-04-15
**
*/

init_ops :-
        op(1200,fy,[default,depend,create,search]),
        op(1100,xfx,:),
        op(1100,fy,[define,include]).


:- init_ops,
   recorda(file,'promfile').


