/*
this is a sample program for testing prom

try:
	prom -I "'Search'" "exe(tst)"


This should compile a simple ``hello, world'' program...

T. Kielmann, 92-05-14
*/

#include <stdio.h>

int main ()
{

printf("hello, world\n");
exit(0);
}


