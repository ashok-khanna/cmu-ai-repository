/* This is startup.pl
**
** Purpose: Initial settings for PROM
**
** (c) T.Kielmann, 92-04-15
**
*/

init_ops :-
        op(1200,fy,[default,depend,create,search]),
        op(1100,xfx,:),
        op(1100,fy,[define,include]).

load_modules :-
        consult(scanner),
        consult(main),
        consult(make),
        consult(expand),
        consult(debug).


:- init_ops,
   load_modules,
   recorda(file,'promfile').


