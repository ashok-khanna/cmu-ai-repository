
:- module(dialog_box,[]).

:- ensure_loaded(library(ytoolkit)).
:- ensure_loaded(library('behaviors/bully')).


default(border,1).
default(line_width,3).

layout :-	draw(rectangle(5,5,width-10,height-10)).

behavior(Event,Window) :- bully(Event,Window).

