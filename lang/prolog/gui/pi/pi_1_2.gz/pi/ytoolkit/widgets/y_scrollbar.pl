

:- module(y_scrollbar,[]).

:- ensure_loaded(tools,[draw/1,get_attr/2]).
:- ensure_loaded(scrollable).

default(bkg_pixmap,["# "," #"]).
default(background,1).
default(foreground,0).
default(border,1).
default(border_pixel,1).
default(cursor,sb_v_double_arrow).
default(y,-1).
default(width,10).
default(py,0).
default(ph,100).
default(layout,y_scrollbar:layout).

layout :- 
	get_attr(scrollable,B),
	draw(frectangle(
		0,
		-B~y*height/B~height,
		width,
		height^2/B~height)).
	

behavior(Event,Window) :- scrollable(Event,Window).


