

:- module(scrollbar_y,[]).


:- ensure_loaded(library(ytoolkit)).
:- ensure_loaded(library(edipo)).
:- ensure_loaded(library('behaviors/y_scrollable')).

default(y,-1).
default(width,15).
default(border,1).
default(cursor,sb_v_double_arrow).
default(foreground,black).

default(pos,0).
default(part,0.2).


layout :- true.

behavior(Event,Window) :- y_scrollable(Event,Window).


