
:- module(item,[]).
:- ensure_loaded(library(ytoolkit)).
:- ensure_loaded(library('behaviors/pressable')).


:- ytoolkit:super_class(item:label).

default(align,left).

behavior(A,B) :- pressable(A,B).
