%-----------------------------------------------------------------------%
%									%
%			       Ytoolkit					%
%									%
%					April 90 Ze' Paulo Leal		%
%									%
%-----------------------------------------------------------------------%
%									%
%	File: 		init_file.yap					%
%	Version:	2.0						%
%	Purpose:	init file for Quintus compilation 		%
%									%
%-----------------------------------------------------------------------%
%									%
%	Last change:	93/05/24					%
%	Bugs & Com.:							%
%									%
%-----------------------------------------------------------------------%

:- ensure_loaded('../../pi_paths').
:- ensure_loaded('../manip').
:- ensure_loaded('../quintus').
:- asserta((ytoolkit:(super_class(P) :- user:'$super_class'(P)))).
