

:- module(scrollbar_x,[]).

:- ensure_loaded(library(ytoolkit)).
:- ensure_loaded(library(edipo)).
:- ensure_loaded(library('behaviors/x_scrollable')).

default(y,-1).
default(height,15).
default(border,1).
default(cursor,sb_h_double_arrow).
default(foreground,black).

default(pos,0).
default(part,0.2).


layout :- true.

behavior(Event,Window) :- x_scrollable(Event,Window).


