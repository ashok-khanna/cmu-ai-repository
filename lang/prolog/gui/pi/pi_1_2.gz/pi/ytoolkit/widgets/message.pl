
:- module(message,[]).

:- ensure_loaded(library(ytoolkit)).

:- ytoolkit:super_class(message:dialog_box).

default(width,300).
default(height,80).

sub_widgets(Name) :-
	get_attr(Name,text,T),
	writebox(T,WT,_),
	new_widget(label,[
		x=20,
		y=(Name~height-25)>>1,
		width=WT+10,
		height=25,
		parent=Name,
		text=T
	],_),
	new_widget(button,[
		x=Name~width-100,
		y=(Name~height-25)>>1,
		width=80,
		height=25,
		parent=Name,
		text='Proceed',
		callback=ytoolkit:kill_widget(_,[],Name)
	],_).
