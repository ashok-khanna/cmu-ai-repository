%-----------------------------------------------------------------------%
%									%
%			       Ytoolkit					%
%									%
%					April 90 Ze' Paulo Leal		%
%									%
%-----------------------------------------------------------------------%
%									%
%	File: 		quintus.yap					%
%	Version:	2.0						%
%	Purpose:	predicates needed by Quintus	 		%
%									%
%-----------------------------------------------------------------------%
%									%
%	Last change:	93/04/05					%
%	Bugs & Com.:							%
%									%
%-----------------------------------------------------------------------%


yt_coord(N,I) :- I is integer(N).

:- prolog_flag(multiple,_,off).
:- prolog_flag(discontiguous,_,off).
:- unknown(_,fail).
:- nofileerrors.
