

foreign_file('teste.o',[c_teste1,c_teste2]).
foreign_file('/usr/big6/src/sicstus1.8/Emulator/lsp.o',[]).

foreign(c_teste1,c,teste(+integer)).
/*foreign(c_teste2,c,teste(+integer,-address(int))). */
foreign(c_teste2,c,teste(+atom,-atom)).

:- load_foreign_files(['teste.o'],[]),
	abolish(foreign,3),
	abolish(foreign_file,2).


