
/*----------------------------------------------------------------------*
*									*
*			Edipo - sicstus/quintus version			*
*									*
*						August 90		*
*						Ze' Paulo Leal		*
*						Universidade do Porto	*
*									*
*-----------------------------------------------------------------------*
*									*
*	file :		event.h						*
*	purpose : 	event definitions				*
*	creation	91/09/27					*
*	last changes :	91/09/27					*
*	bugs :								*
*	comments :							*
*									*
*----------------------------------------------------------------------*/


extern unsigned long int
  keyPress_atom,
  keyRelease_atom,
  buttonPress_atom,
  buttonRelease_atom,
  motionNotify_atom,
  enterNotify_atom,
  leaveNotify_atom,
  expose_atom,
  visibilityNotify_atom,
  createNotify_atom,
  configureNotify_atom,
  destroyNotify_atom,
  mapNotify_atom,
  unmapNotify_atom;
