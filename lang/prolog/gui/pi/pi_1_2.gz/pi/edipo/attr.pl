%-----------------------------------------------------------------------%
%									%
%			Edipo - sicstus/quintus version			%
%									%
%						August 90		%
%						Ze' Paulo Leal		%
%						Universidade do Porto	%
%									%
%-----------------------------------------------------------------------%
%									%
%	file :		attr.pl						%
%	purpose : 	some predicates for attributes			%
%	creation	90/08/01					%
%	last changes :	92/05/12					%
%	bugs :								%
%	comments :							%
%									%
%-----------------------------------------------------------------------%



edipo_attr(window,Attr) :- edipo_on, atom(Attr), x_window_attr(Attr,true).
edipo_attr(gc,Attr) :- atom(Attr), x_gc_attr(Attr,true).
edipo_attr(Type,Attr) :- atom(Type), var(Attr),
	format('[[edipo: not implemented~n]]',[]), abort.


get_window_attr(Name,Attr,Value) :-
	recorded('$window','$window'(Name,Display,Window,_),_),
	get_window_attr(Attr,Display,Window,Name,Value).

current_window_attr(display).
current_window_attr(parent).
current_window_attr(x).
current_window_attr(y).
current_window_attr(width).
current_window_attr(height).
current_window_attr(border).

current_gc_attr(function).
current_gc_attr(line_width).
current_gc_attr(line_style).
current_gc_attr(cap).
current_gc_attr(join).
current_gc_attr(fill_style).
current_gc_attr(fill_rule).
current_gc_attr(arc_mode).
current_gc_attr(font).
current_gc_attr(plane_mask).
current_gc_attr(foreground).
current_gc_attr(background).
