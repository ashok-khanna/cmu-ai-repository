


#include </usr/big6/src/sicstus1.8/Emulator/sicstus.h>

main()
{
  int i=2;
  printf("i=%d\n",i);
  printf("i=%d\n",i+=3);
  printf("i=%d\n",i);
}
/*
c_teste1(a)
     long int a;
{
  printf("a=%d\n",a);
  return 1;
}

c_teste2(a,b)
     long int a;
     long int *b;
{
  *b=SP_atom_from_string("ola");
  printf("a=%s\n",SP_string_from_atom(a));
  printf("b=%s\n",SP_string_from_atom(*b));
  if(a==*b)
    printf("igual\n");
  else
    printf("diff\n");
  return 1;
}

*/
