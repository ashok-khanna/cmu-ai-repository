%-----------------------------------------------------------------------%
%									%
%			Edipo - sicstus/quintus version			%
%									%
%						August 90		%
%						Ze' Paulo Leal		%
%						Universidade do Porto	%
%									%
%-----------------------------------------------------------------------%
%									%
%	file :		init.pl						%
%	purpose : 	initialization predicates			%
%	creation	91/03/15					%
%	last changes :	91/03/15					%
%	bugs :								%
%	comments :							%
%									%
%									%
%-----------------------------------------------------------------------%

init_edipo.
	


edipo_on :- 
	(recorded('$display','$display'(_,_),_) -> 
	    true
	; 
	    get_display('',_)
	).
