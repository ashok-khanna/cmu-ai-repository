/*----------------------------------------------------------------------*
*									*
*			Edipo - sicstus/quintus version			*
*									*
*						August 90		*
*						Ze' Paulo Leal		*
*						Universidade do Porto	*
*									*
*-----------------------------------------------------------------------*
*									*
*	file :		draw.c						*
*	purpose :							*
*	creation	90/08/03					*
*	last changes :	90/08/03					*
*	bugs :								*
*	commennts :							*
*									*
*----------------------------------------------------------------------*/

#include "callx.h"

XPoint *points, *pt;

x_my_init_poly(n) long int n;
{ 
  pt = points = (XPoint *) malloc(n*sizeof(XPoint));
}

x_my_poly_point(x,y) long int x, y;
{
  pt->x= (short) x;
  pt->y= (short) y;
  pt++;
}

x_my_polygon(display,window,gc,type,n)
     Display *display;
     Window window;
     GC gc;
     long int type, n;
{
  if(type==0)
    XDrawLines(display,window,gc,points,n,CoordModeOrigin);
  else
    XFillPolygon(display,window,gc,points,n,Complex,CoordModeOrigin);
  free(points);
}

