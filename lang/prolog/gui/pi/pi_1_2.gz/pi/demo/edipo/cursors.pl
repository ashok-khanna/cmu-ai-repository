
:- ensure_loaded(library(edipo)).

:- write('*****			try this 	? - cursors.'), nl.

cursors :-
	(current_window(cursors,[])-> window(cursors,[]), destroy;true),
	size(L), W is 7*L,H is 11*L>>1,
	window(cursors,[width=W,height=H]),
	wait_for_window,
	row(10).

size(120).

wait_for_window :-
	repeat,
	event(cursors,visibilityNotify(unobscured)), !.

row(-1) :- !.
row(R) :- 
	S is R-1,
	row(S),
	column(R,6).

column(_,-1) :- !.
column(R,C) :-
	size(L), K is L>>1,
	D is C-1,
	column(R,D),
	Name is	2*(R*7+C),
	X is C*L, Y is R * K,
	edipo:cursor_number(Cursor,Name),
	window(Name,[x=X,y=Y,width=L,height=K,
			border=1,border_pixel=black,
			bkg_pixel=white,
			parent=cursors,cursor=Cursor]),
	gc(Name,[background=white,foreground=black]),
	writebox(Cursor,W,H),
	XS is (L-W)>>1,
	YS is (K-H)>>1+H,
	writeterm(XS,YS,Cursor).

