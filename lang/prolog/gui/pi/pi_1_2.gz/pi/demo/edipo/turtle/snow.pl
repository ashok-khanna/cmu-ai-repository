
:- ensure_loaded(turtle).

:- write('*****			try this 	? - snow(5,100).'), nl.

snow(N,S) :-
	home, clear,
	side(N,S),
	rt(120),
	side(N,S),
	rt(120),	
	side(N,S).

side(0,S) :- !, fd(S).
side(N,S) :- 
	N1 is N-1, S3 is S/3,
	side(N1,S3), rt(-60),
	side(N1,S3), rt(120),
	side(N1,S3), rt(-60),
	side(N1,S3).



snow_all :-
	int(N),
	snow(N,100),
	fail.


int(0).
int(N) :- int(M), N is M+1.
