
:- module(random,[random/1,init_random/0]).

init_random :- getpid(P), srandom(P).

foreign_file('random.o',[random,srandom,getpid]).

foreign(random,c,random([-integer])).

foreign(srandom,c,srandom(+integer)).

foreign(getpid,c,getpid([-integer])).

:- load_foreign_files(['random.o'],[]),
	abolish(foreign,3),
	abolish(foreign_file,2).
	
