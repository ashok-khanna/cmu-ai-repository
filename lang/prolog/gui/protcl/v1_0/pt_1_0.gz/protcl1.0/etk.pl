%
% ECLiPSe version of the Prolog Tk interface
%
% Author: Micha Meier
% Date:   September 93
%

:- module_interface(tk).

:- export
	tcl_eval/1,
	tk_demo/0,
	tk_test/0,
	tk_file/1,
	tk/1,
	tk_do_one_event/1,
	tk_main_loop/0.

:- begin_module(tk).

:- compile(files).

:-
	tk_installation(I),
	concat_string(["tk.o -lg -L/usr/openwin/lib -L", I, "/lib -ltk -ltcl -lX11 -lm"], Load),
	load(Load),
	external(tk_init/1, p_tk_init),
	external(tk_option/2, p_tk_option),
	external(tk_do_one_event/1, p_tk_do_one_event),
	external(tcl_eval_string/1, p_tcl_eval_string),
	external(tk_num_main_windows/1, p_tk_num_main_windows).

:- compile(tk_common).

:- import
	sepia_toplevel_prompt/2		% default 153 handler
    from sepia_kernel.

tcl_eval(S) :-
    (atom(S); string(S)),
    !,
    tcl_eval_string(S).
tcl_eval(List) :-
    concat_string(List, S),
    tcl_eval_string(S).

tk(Opts) :-
    tk_init('', Opts),
    tcl_eval(update),
    set_error_handler(153, tk_prompt/2).

% The new handler for the prompt event - until there is data to read,
%  we serve Tk events. Unfortunately this does not help when we block
%  in a read which is not issued from the top-level loop.
tk_prompt(_, M) :-
    sepia_toplevel_prompt(_, M),
    tk_loop.

tk_loop :-
    tk_do_one_event(0),
    (tk_num_main_windows(0) ->
	reset_error_handler(153)
    ;
	(select([toplevel_input], 0, [_]) ->
	    true				% there is something to read
	;
	    tk_loop				% nothing, wait for next event
	)
    ).
