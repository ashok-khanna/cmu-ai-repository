%
% Quintus version of ProTcl
%
% Author: Micha Meier
% Date:   September 93
%

:- module(tk, [
	tcl_eval/1,
	tk_demo/0,
	tk_test/0,
	tk_file/1,
%	tk/1,
	tk_do_one_event/1,
	tk_main_loop/0]).

:- compile(tk_common).
:- compile(foreign).
