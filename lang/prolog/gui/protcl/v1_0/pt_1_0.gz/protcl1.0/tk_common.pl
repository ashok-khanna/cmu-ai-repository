%
% ProTcl 1.0
%
%	Definitions common to all Prologs
%
% Author: Micha Meier
% Date:   September 93
%

tk_demo :-
    tk_file('$tk_library/demos/widget', []).

tk_test :-
    tk([]),
    tk_source(S),
    concat_atoms('cd ', S, CDS),
    concat_atoms(CDS, '/tests', CDT),
    tcl_eval(CDT),
    tcl_eval('source all'),
    tcl_eval('exit').

tk_init(File, Opts) :-
    tk_options(Opts),
    tk_init(File).

tk_options([]).
tk_options([Opt|List]) :-
    Opt =.. [Name|Args],
    (Args = [Val|_] ->
	true
    ;
	Val = ''
    ),
    tk_option(Name, Val),
    tk_options(List).

tk_file(File, Options) :-
    tk_init(File, Options),
    concat_atoms('source ', File, InitFile),
    tcl_eval(InitFile),
    tcl_eval(update),
    tk_main_loop.

tk_main_loop :-
    tk_do_one_event(0),
    tk_num_main_windows(X), X > 0 ->
	tk_main_loop
    ;
	true.
