/* $Header: regnames.c,v 1.1 92/07/28 20:15:27 wlott Exp $ */

#include "lispregs.h"

char *lisp_register_names[] = { REGNAMES, 0 };
