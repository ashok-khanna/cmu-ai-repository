/* $Header: monitor.h,v 1.1 92/07/28 20:15:08 wlott Exp $ */

extern void ldb_monitor(void);
extern void throw_to_monitor(void);
