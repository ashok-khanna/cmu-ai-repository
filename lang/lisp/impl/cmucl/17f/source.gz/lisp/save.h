/*
 * $Header: save.h,v 1.2 93/04/28 01:58:37 wlott Exp $
 */

#ifndef _SAVE_H_
#define _SAVE_H_

#include "core.h"

extern boolean save(char *filename, lispobj initfun);

#endif
