/* $Header: version.c,v 1.1 92/07/28 20:15:40 wlott Exp $ */
int version = VERSION;
