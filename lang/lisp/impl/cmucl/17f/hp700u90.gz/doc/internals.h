/*
 * Machine generated header file.  Do not edit.
 */

#ifndef _INTERNALS_H_
#define _INTERNALS_H_

#define type_EvenFixnum 0
#define type_FunctionPointer 1
#define type_OtherImmediate0 2
#define type_ListPointer 3
#define type_OddFixnum 4
#define type_InstancePointer 5
#define type_OtherImmediate1 6
#define type_OtherPointer 7
#define type_Bignum 10
#define type_Ratio 14
#define type_SingleFloat 18
#define type_DoubleFloat 22
#define type_Complex 26
#define type_SimpleArray 30
#define type_SimpleString 34
#define type_SimpleBitVector 38
#define type_SimpleVector 42
#define type_SimpleArrayUnsignedByte2 46
#define type_SimpleArrayUnsignedByte4 50
#define type_SimpleArrayUnsignedByte8 54
#define type_SimpleArrayUnsignedByte16 58
#define type_SimpleArrayUnsignedByte32 62
#define type_SimpleArraySingleFloat 66
#define type_SimpleArrayDoubleFloat 70
#define type_ComplexString 74
#define type_ComplexBitVector 78
#define type_ComplexVector 82
#define type_ComplexArray 86
#define type_CodeHeader 90
#define type_FunctionHeader 94
#define type_ClosureHeader 98
#define type_FuncallableInstanceHeader 102
#define type_ByteCodeFunction 106
#define type_ByteCodeClosure 110
#define type_DylanFunctionHeader 114
#define type_ClosureFunctionHeader 118
#define type_ReturnPcHeader 122
#define type_ValueCellHeader 126
#define type_SymbolHeader 130
#define type_BaseChar 134
#define type_Sap 138
#define type_UnboundMarker 142
#define type_WeakPointer 146
#define type_InstanceHeader 150
#define type_Fdefn 154

#define trap_Halt 8
#define trap_PendingInterrupt 9
#define trap_Error 10
#define trap_Cerror 11
#define trap_Breakpoint 12
#define trap_FunctionEndBreakpoint 13
#define trap_SingleStepBreakpoint 14

#define subtype_VectorNormal 0
#define subtype_VectorValidHashing 2
#define subtype_VectorMustRehash 3

#define tracetab_Normal 0
#define tracetab_CallSite 1
#define tracetab_FunctionPrologue 2
#define tracetab_FunctionEpilogue 3

#define sc_Constant 0
#define sc_Zero 1
#define sc_Null 2
#define sc_FpSingleZero 3
#define sc_FpDoubleZero 4
#define sc_Immediate 5
#define sc_ControlStack 6
#define sc_SignedStack 7
#define sc_UnsignedStack 8
#define sc_BaseCharStack 9
#define sc_SapStack 10
#define sc_SingleStack 11
#define sc_DoubleStack 12
#define sc_AnyReg 13
#define sc_DescriptorReg 14
#define sc_BaseCharReg 15
#define sc_SapReg 16
#define sc_SignedReg 17
#define sc_UnsignedReg 18
#define sc_NonDescriptorReg 19
#define sc_InteriorReg 20
#define sc_SingleReg 21
#define sc_DoubleReg 22
#define sc_CatchBlock 23

#define ERRORS { \
    "Unknown.  System lossage.", \
    "Object is not of type FUNCTION.", \
    "Object is not of type LIST.", \
    "Object is not of type BIGNUM.", \
    "Object is not of type RATIO.", \
    "Object is not of type SINGLE-FLOAT.", \
    "Object is not of type DOUBLE-FLOAT.", \
    "Object is not of type SIMPLE-STRING.", \
    "Object is not of type SIMPLE-BIT-VECTOR.", \
    "Object is not of type SIMPLE-VECTOR.", \
    "Object is not of type FIXNUM.", \
    "Object is not of type FUNCTION or SYMBOL.", \
    "Object is not of type VECTOR.", \
    "Object is not of type STRING.", \
    "Object is not of type BIT-VECTOR.", \
    "Object is not of type ARRAY.", \
    "Object is not of type NUMBER.", \
    "Object is not of type RATIONAL.", \
    "Object is not of type FLOAT.", \
    "Object is not of type REAL.", \
    "Object is not of type INTEGER.", \
    "Object is not of type CONS.", \
    "Object is not of type SYMBOL.", \
    "Undefined symbol.", \
    "Object is not coercable to type FUNCTION.", \
    "Invalid argument count.", \
    "Bogus argument to VALUES-LIST.", \
    "Unbound symbol.", \
    "unused", \
    "Object is not a System Area Pointer (SAP).", \
    "Attempt to RETURN-FROM a block that no longer exists.", \
    "Attempt to THROW to a non-existent tag.", \
    "Attempt to divide by zero.", \
    "Object is of the wrong type.", \
    "Odd number of keyword arguments.", \
    "Unknown keyword.", \
    "unused", \
    "unused", \
    "Invalid array index.", \
    "Wrong number of indices.", \
    "Object is not of type SIMPLE-ARRAY.", \
    "Object is not of type (SIGNED-BYTE 32).", \
    "Object is not of type (UNSIGNED-BYTE 32).", \
    "Object is not of type (SIMPLE-ARRAY (UNSIGNED-BYTE 2) (*)).", \
    "Object is not of type (SIMPLE-ARRAY (UNSIGNED-BYTE 4) (*)).", \
    "Object is not of type (SIMPLE-ARRAY (UNSIGNED-BYTE 8) (*)).", \
    "Object is not of type (SIMPLE-ARRAY (UNSIGNED-BYTE 16) (*)).", \
    "Object is not of type (SIMPLE-ARRAY (UNSIGNED-BYTE 32) (*)).", \
    "Object is not of type (SIMPLE-ARRAY SINGLE-FLOAT (*)).", \
    "Object is not of type (SIMPLE-ARRAY DOUBLE-FLOAT (*)).", \
    "Object is not of type COMPLEX.", \
    "Object is not a WEAK-POINTER.", \
    "Object is not a INSTANCE.", \
    "Object is not of type BASE-CHAR.", \
    "Function with declared result type NIL returned.", \
    "Layout is invalid (instance obsolete.)", \
    NULL \
}

#ifndef LANGUAGE_ASSEMBLY

#define LISPOBJ(x) ((lispobj)x)

struct array {
    lispobj header;
    lispobj fill_pointer;
    lispobj fill_pointer_p;
    lispobj elements;
    lispobj data;
    lispobj displacement;
    lispobj displaced_p;
    lispobj dimensions[1];
};

struct bignum {
    lispobj header;
    long digits[1];
};

struct binding {
    lispobj value;
    lispobj symbol;
};

struct catch_block {
    struct unwind_block * current_uwp;
    lispobj * current_cont;
    lispobj current_code;
    lispobj entry_pc;
    lispobj tag;
    struct catch_block * previous_catch;
    lispobj size;
};

struct closure {
    lispobj header;
    lispobj function;
    lispobj info[1];
};

struct code {
    lispobj header;
    lispobj code_size;
    lispobj entry_points;
    lispobj debug_info;
    lispobj trace_table_offset;
    lispobj constants[1];
};

struct complex {
    lispobj header;
    lispobj real;
    lispobj imag;
};

struct cons {
    lispobj car;
    lispobj cdr;
};

struct double_float {
    lispobj header;
    lispobj filler;
    double value;
};

struct fdefn {
    lispobj header;
    lispobj name;
    lispobj function;
    char * raw_addr;
};

struct funcallable_instance {
    lispobj header;
    lispobj function;
    lispobj lexenv;
    lispobj layout;
    lispobj info[1];
};

struct function {
    lispobj header;
    lispobj self;
    lispobj next;
    lispobj name;
    lispobj arglist;
    lispobj type;
    unsigned char code[1];
};

struct instance {
    lispobj header;
    lispobj slots[1];
};

struct ratio {
    lispobj header;
    lispobj numerator;
    lispobj denominator;
};

struct return_pc {
    lispobj header;
    unsigned char return_point[1];
};

struct sap {
    lispobj header;
    char * pointer;
};

struct single_float {
    lispobj header;
    float value;
};

struct symbol {
    lispobj header;
    lispobj value;
    lispobj unused;
    lispobj plist;
    lispobj name;
    lispobj package;
};

struct unwind_block {
    struct unwind_block * current_uwp;
    lispobj * current_cont;
    lispobj current_code;
    lispobj entry_pc;
};

struct value_cell {
    lispobj header;
    lispobj value;
};

struct vector {
    lispobj header;
    lispobj length;
    unsigned long data[1];
};

struct weak_pointer {
    lispobj header;
    lispobj value;
    lispobj broken;
    struct weak_pointer * next;
};

#else /* LANGUAGE_ASSEMBLY */

#define LISPOBJ(thing) thing

#define ARRAY_FILL_POINTER_OFFSET -3
#define ARRAY_FILL_POINTER_P_OFFSET 1
#define ARRAY_ELEMENTS_OFFSET 5
#define ARRAY_DATA_OFFSET 9
#define ARRAY_DISPLACEMENT_OFFSET 13
#define ARRAY_DISPLACED_P_OFFSET 17
#define ARRAY_DIMENSIONS_OFFSET 21

#define BIGNUM_DIGITS_OFFSET -3

#define CLOSURE_FUNCTION_OFFSET 3
#define CLOSURE_INFO_OFFSET 7

#define CODE_CODE_SIZE_OFFSET -3
#define CODE_ENTRY_POINTS_OFFSET 1
#define CODE_DEBUG_INFO_OFFSET 5
#define CODE_TRACE_TABLE_OFFSET_OFFSET 9
#define CODE_CONSTANTS_OFFSET 13

#define COMPLEX_REAL_OFFSET -3
#define COMPLEX_IMAG_OFFSET 1

#define CONS_CAR_OFFSET -3
#define CONS_CDR_OFFSET 1

#define DOUBLE_FLOAT_FILLER_OFFSET -3
#define DOUBLE_FLOAT_VALUE_OFFSET 1

#define FDEFN_NAME_OFFSET -3
#define FDEFN_FUNCTION_OFFSET 1
#define FDEFN_RAW_ADDR_OFFSET 5

#define FUNCALLABLE_INSTANCE_FUNCTION_OFFSET 3
#define FUNCALLABLE_INSTANCE_LEXENV_OFFSET 7
#define FUNCALLABLE_INSTANCE_LAYOUT_OFFSET 11
#define FUNCALLABLE_INSTANCE_INFO_OFFSET 15

#define FUNCTION_SELF_OFFSET 3
#define FUNCTION_NEXT_OFFSET 7
#define FUNCTION_NAME_OFFSET 11
#define FUNCTION_ARGLIST_OFFSET 15
#define FUNCTION_TYPE_OFFSET 19
#define FUNCTION_CODE_OFFSET 23

#define INSTANCE_SLOTS_OFFSET -1

#define RATIO_NUMERATOR_OFFSET -3
#define RATIO_DENOMINATOR_OFFSET 1

#define RETURN_PC_RETURN_POINT_OFFSET -3

#define SAP_POINTER_OFFSET -3

#define SINGLE_FLOAT_VALUE_OFFSET -3

#define SYMBOL_VALUE_OFFSET -3
#define SYMBOL_UNUSED_OFFSET 1
#define SYMBOL_PLIST_OFFSET 5
#define SYMBOL_NAME_OFFSET 9
#define SYMBOL_PACKAGE_OFFSET 13

#define VALUE_CELL_VALUE_OFFSET -3

#define VECTOR_LENGTH_OFFSET -3
#define VECTOR_DATA_OFFSET 1

#define WEAK_POINTER_VALUE_OFFSET -3
#define WEAK_POINTER_BROKEN_OFFSET 1
#define WEAK_POINTER_NEXT_OFFSET 5

#endif /* LANGUAGE_ASSEMBLY */

#define NIL LISPOBJ(0x2800000B)
#define T LISPOBJ(0x28000027)
#define LISP_ENVIRONMENT_LIST LISPOBJ(0x2800003F)
#define LISP_COMMAND_LINE_LIST LISPOBJ(0x28000057)
#define INITIAL_FDEFN_OBJECTS LISPOBJ(0x2800006F)
#define INITIAL_FUNCTION LISPOBJ(0x28000087)
#define MAYBE_GC LISPOBJ(0x2800009F)
#define INTERNAL_ERROR LISPOBJ(0x280000B7)
#define HANDLE_BREAKPOINT LISPOBJ(0x280000CF)
#define HANDLE_FUNCTION_END_BREAKPOINT LISPOBJ(0x280000E7)
#define FDEFINITION_OBJECT LISPOBJ(0x280000FF)
#define READ_ONLY_SPACE_FREE_POINTER LISPOBJ(0x28000117)
#define STATIC_SPACE_FREE_POINTER LISPOBJ(0x2800012F)
#define INITIAL_DYNAMIC_SPACE_FREE_POINTER LISPOBJ(0x28000147)
#define CURRENT_CATCH_BLOCK LISPOBJ(0x2800015F)
#define CURRENT_UNWIND_PROTECT_BLOCK LISPOBJ(0x28000177)
#define EVAL_STACK_TOP LISPOBJ(0x2800018F)
#define FREE_INTERRUPT_CONTEXT_INDEX LISPOBJ(0x280001A7)
#define INTERRUPTS_ENABLED LISPOBJ(0x280001BF)
#define INTERRUPT_PENDING LISPOBJ(0x280001D7)

#endif
