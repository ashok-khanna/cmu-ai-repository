#include <sys/types.h>

struct timeb
{
    time_t		time;		/* Seconds since the epoch	*/
    unsigned short	millitm;
    short		timezone;
    short		dstflag;
};

extern int	ftime(struct timeb *);
