#include <graphics.h>
#include <stdlib.h>
#include <pc.h>
#include "Task.h"

int X;
int Y;

void lines1()
{
  for (int i=0; i<GrMaxX(); i++)
  {
    GrLine(X, Y, i, GrMaxY(), i | GrXOR);
    GrLine(X, Y, i, 0, i | GrXOR);
    Yield();
  }
}

void lines2()
{
  for (int i=0; i<GrMaxY(); i++)
  {
    GrLine(X, Y, GrMaxX(), i, i | GrXOR);
    GrLine(X, Y, 0, i, i | GrXOR);
    Yield();
  }
}

void setup()
{
  int i;
  for (i=2; i<256; i++)
  {
    GrSetColor(i, random()%50, random()%50, random()%50);
    Yield();
  }
  int t_r, t_g, t_b;
  int o_r=0, o_g=0, o_b=0;
  int j=0;
  while(!kbhit())
  {
    if (j == 0)
    {
      t_r = (random()%256000 - o_r) / 1000;
      t_g = (random()%256000 - o_g) / 1000;
      t_b = (random()%256000 - o_b) / 1000;
      j = 1000;
    }
    for (i=0; i<8; i++)
      GrSetColor(1<<i, o_r/1000, o_g/1000, o_b/1000);
    o_r += t_r;
    o_g += t_g;
    o_b += t_b;
    j--;
    Yield();
  }
}

main()
{
  srandom(time(0));
  GrSetMode(GR_default_graphics);

  X = GrMaxX()/3;
  Y = GrMaxY()/3;

  new Task(); // this task

  new Task((TaskProc *)lines1);
  new Task((TaskProc *)lines2);

  new Task((TaskProc *)setup);
  Wait();

  getkey();
  GrSetMode(GR_default_text);
}

