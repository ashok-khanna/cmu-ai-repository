/* "@(#)$Header: vfs.h,v 1.0 92/07/19 12:07:30 ericb Rel $" */

/*
  (c) Copyright 1992 Eric Backus

  This software may be used freely so long as this copyright notice is
  left intact.  There is no warrantee on this software.
*/

typedef long	fsid_t[2];

#define	MOUNT_UFS	0
#define	MOUNT_NFS	1	/* Not possible on DOS */
#define	MOUNT_CDFS	2	/* Not possible on DOS */

#define	FS_MAGIC	0x11954	/* Taken from HP-UX */

struct statfs
{
    long	f_type;
    long	f_bsize;
    long	f_blocks;
    long	f_bfree;
    long	f_bavail;
    long	f_files;
    long	f_ffree;
    fsid_t	f_fsid;
    long	f_magic;
};

extern int	statfs(const char *, struct statfs *);
extern int	fstatfs(int, struct statfs *);
