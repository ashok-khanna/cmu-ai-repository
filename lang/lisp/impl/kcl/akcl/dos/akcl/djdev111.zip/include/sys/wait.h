/*
  (c) Copyright 1992 Eric Backus

  This software may be used freely so long as this copyright notice is
  left intact.  There is no warrantee on this software.
*/

/* Needed only for waitpid() and wait3() */
/* #define	WNOHANG		1 */
/* #define	WUNTRACED	2 */
/* #define	_WAITMASK	(WNOHANG | WUNTRACED) */

/* Needed for wait() */
#define	WIFEXITED(_x)	(((int) (_x) & 0xff) == 0)
#define	WIFSTOPPED(_x)	(((int) (_x) & 0xff) == 0x7f)
#define	WIFSIGNALED(_x)	((((int) (_x) & 0xff) != 0) &&\
			 (((int) (_x) & 0xff) != 0x7f))
#define	WEXITSTATUS(_x)	(((int) (_x) >> 8) & 0xff)
#define	WTERMSIG(_x)	((int) (_x) & 0x7f)
#define	WSTOPSIG(_x)	(((int) (_x) >> 8) & 0xff)

#include <std.h>
