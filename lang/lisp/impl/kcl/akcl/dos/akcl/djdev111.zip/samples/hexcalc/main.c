#include "hc.h"

main(int argc, char **argv)
{
  int i;
  for (i=0; i<MAX_ID; i++)
  {
    id_name[i] = 0;
    id_val[i] = 0;
  }
  yyparse();
}
