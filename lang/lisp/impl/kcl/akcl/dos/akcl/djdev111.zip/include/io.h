#ifndef _IO_H_
#define _IO_H_

int setmode(int handle, int mode);

#endif

