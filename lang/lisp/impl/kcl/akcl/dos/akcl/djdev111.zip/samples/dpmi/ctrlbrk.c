#include <stdio.h>
#include <pc.h>
#include <go32.h>

int main()
{
  printf("waiting and polling - press Ctrl-Break to\n");
  printf("trigger handler, any other key to go on\n");
  while (!kbhit())
  {
    if (_go32_was_ctrl_break_hit())
      printf("ctrl-break detected in program\n");
  }
  printf("the key was %x\n", getkey());

  printf("releasing ctrl-break now\n");
  _go32_want_ctrl_break(0);
  
  printf("waiting and polling - Pressing Ctrl-Break now\n");
  printf("should cause an exception.\n");
  while (!kbhit())
  {
  }
  printf("the key was %x\n", getkey());
  printf("exiting\n");
  return 0;
}
