#define MAX_ID	200
char *id_name[MAX_ID];
double id_val[MAX_ID];
