#define MONO_NORMAL	0x07
#define MONO_BOLD	0x0f

extern int screen_seg;
extern int mono_attr;
extern int use_mono;

extern int redir_1_mono;
extern int redir_2_mono;
extern int redir_2_1;
extern int redir_1_2;

