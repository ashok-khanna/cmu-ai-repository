main()
{
  system("mem /program");
}
