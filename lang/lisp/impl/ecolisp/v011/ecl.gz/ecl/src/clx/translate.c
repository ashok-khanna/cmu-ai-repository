
#include "translate.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	VV[0]->s.s_stype=(short)stp_special;
	if(VV[0]->s.s_dbind == OBJNULL){
	(VV[0]->s.s_dbind)= Cnil;}
	MF0(VV[39],L1);
	(void)putprop(VV[39],VV[Vdeb39],VV[40]);
	MF0(VV[41],L2);
	(void)putprop(VV[41],VV[Vdeb41],VV[40]);
	MM0(VV[42],L3);
	VV[7]->s.s_stype=(short)stp_special;
	if(VV[7]->s.s_dbind == OBJNULL){
	VALUES(0) = (VV[43]->s.s_gfdef);
	Lmake_hash_table(4,VV[5],VALUES(0),VV[6],MAKE_FIXNUM(400))/*  MAKE-HASH-TABLE*/;
	(VV[7]->s.s_dbind)= VALUES(0);}
	MM0(VV[44],L4);
	MM0(VV[45],L5);
	MM0(VV[46],L6);
	MM0(VV[47],L7);
	MM0(VV[48],L8);
	VV[15]->s.s_stype=(short)stp_special;
	if(VV[15]->s.s_dbind == OBJNULL){
	funcall(2,VV[49]->s.s_gfdef,VV[14])       /*  MAKE-STATE-MASK */;
	funcall(2,VV[50]->s.s_gfdef,VALUES(0))    /*  LOGNOT          */;
	Llogand(2,MAKE_FIXNUM(255),VALUES(0))     /*  LOGAND          */;
	(VV[15]->s.s_dbind)= VALUES(0);}
	(void)putprop(VV[15],VV[13],siSvariable_documentation);
	
	VV[19]=string_to_object(VV[19]);
	MF0key(VV[51],L9,5,L9keys);
	(void)putprop(VV[51],VV[Vdeb51],VV[40]);
	MF0key(VV[52],L12,2,L12keys);
	(void)putprop(VV[52],VV[Vdeb52],VV[40]);
	MF0(VV[53],L14);
	(void)putprop(VV[53],VV[Vdeb53],VV[40]);
	MF0(VV[54],L15);
	(void)putprop(VV[54],VV[Vdeb54],VV[40]);
	MF0(VV[55],L16);
	(void)putprop(VV[55],VV[Vdeb55],VV[40]);
	siLAmake_constant(2,VV[21],MAKE_FIXNUM(65406))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[22],MAKE_FIXNUM(65505))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[23],MAKE_FIXNUM(65506))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[24],MAKE_FIXNUM(65507))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[25],MAKE_FIXNUM(65508))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[26],MAKE_FIXNUM(65509))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[27],MAKE_FIXNUM(65510))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[28],MAKE_FIXNUM(65511))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[29],MAKE_FIXNUM(65512))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[30],MAKE_FIXNUM(65513))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[31],MAKE_FIXNUM(65514))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[32],MAKE_FIXNUM(65515))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[33],MAKE_FIXNUM(65516))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[34],MAKE_FIXNUM(65517))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[35],MAKE_FIXNUM(65518))/*  *MAKE-CONSTANT*/;
	MF0(VV[56],L18);
	(void)putprop(VV[56],VV[Vdeb56],VV[40]);
	MF0(VV[57],L19);
	(void)putprop(VV[57],VV[Vdeb57],VV[40]);
	MF0(VV[58],L20);
	(void)putprop(VV[58],VV[Vdeb58],VV[40]);
	MF0(VV[59],L21);
	(void)putprop(VV[59],VV[Vdeb59],VV[40]);
	MF0(VV[60],L23);
	(void)putprop(VV[60],VV[Vdeb60],VV[40]);
	MF0key(VV[61],L24,2,L24keys);
	(void)putprop(VV[61],VV[Vdeb61],VV[40]);
	MF0key(VV[62],L25,2,L25keys);
	(void)putprop(VV[62],VV[Vdeb62],VV[40]);
	MF0(VV[63],L26);
	(void)putprop(VV[63],VV[Vdeb63],VV[40]);
	MF0(VV[64],L28);
	(void)putprop(VV[64],VV[Vdeb64],VV[40]);
	MF0(VV[65],L29);
	(void)putprop(VV[65],VV[Vdeb65],VV[40]);
	MF0(VV[66],L30);
	(void)putprop(VV[66],VV[Vdeb66],VV[40]);
	MF0(VV[67],L31);
	(void)putprop(VV[67],VV[Vdeb67],VV[40]);
	MF0(VV[68],L32);
	(void)putprop(VV[68],VV[Vdeb68],VV[40]);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	function definition for DEFINE-KEYSYM-SET                     */
static L1(int narg, object V1, object V2, object V3)
{ VT3 VLEX3 CLSR3
TTL:
	if(!(number_compare((V2),(V3))>0)){
	goto L37;}
	{object V4;
	object V5;
	V4= (V3);
	V5= (V2);
	V2= (V4);
	V3= (V5);
	}
L37:
	{object V4= (VV[0]->s.s_dbind);
	VALUES(0) = (VV[69]->s.s_gfdef);
	(*LK0)(4,(V1),V4,VV[1],VALUES(0))         /*  DELETE          */;
	(VV[0]->s.s_dbind)= VALUES(0);}
	{volatile object V4;
	volatile object V5;                       /*  SET             */
	V4= (VV[0]->s.s_dbind);
	V5= Cnil;
L53:
	if(!((V4)==Cnil)){
	goto L54;}
	goto L49;
L54:
	V5= CAR((V4));
	{register object V7;                      /*  FIRST           */
	register object V8;                       /*  LAST            */
	V7= CADR((V5));
	V8= CADDR((V5));
	Lmonotonically_nondecreasing(3,(V7),(V2),(V8))/*  <=          */;
	if(VALUES(0)!=Cnil){
	goto L62;}
	Lmonotonically_nondecreasing(3,(V7),(V3),(V8))/*  <=          */;
	if(VALUES(0)==Cnil){
	goto L59;}
L62:
	Lerror(2,VV[2],(V5))                      /*  ERROR           */;
	}
L59:
	V4= CDR((V4));
	goto L53;
	}
L49:
	(VV[0]->s.s_dbind)= CONS(list(3,(V1),(V2),(V3)),(VV[0]->s.s_dbind));
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for KEYSYM-SET                            */
static L2(int narg, object V1)
{ VT4 VLEX4 CLSR4
TTL:
	{volatile object V2;
	volatile object V3;                       /*  SET             */
	V2= (VV[0]->s.s_dbind);
	V3= Cnil;
L74:
	if(!((V2)==Cnil)){
	goto L75;}
	VALUES(0) = Cnil;
	RETURN(1);
L75:
	V3= CAR((V2));
	{register object V5;                      /*  FIRST           */
	register object V6;                       /*  LAST            */
	V5= CADR((V3));
	V6= CADDR((V3));
	Lmonotonically_nondecreasing(3,(V5),(V1),(V6))/*  <=          */;
	if(VALUES(0)==Cnil){
	goto L80;}
	VALUES(0) = CAR((V3));
	RETURN(1);
	}
L80:
	V2= CDR((V2));
	goto L74;
	}
}
/*	macro definition for KEYSYM                                   */
static L3(int narg, object V1, object V2)
{ VT5 VLEX5 CLSR5
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= V3;
	{volatile object V6;
	V6= (V4);
	(*LK1)(2,(V6),VV[3])                      /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L89;}
	{volatile object V7;
	volatile object V8;                       /*  B               */
	V7= (V5);
	V8= Cnil;
L94:
	if(!((V7)==Cnil)){
	goto L95;}
	VALUES(0) = (V4);
	RETURN(1);
L95:
	V8= CAR((V7));
	Lash(2,(V4),MAKE_FIXNUM(8))               /*  SHIFT<<         */;
	V4= number_plus(VALUES(0),(V8));
	V7= CDR((V7));
	goto L94;
	}
L89:
	L16(1,(V4))                               /*  CHARACTER->KEYSYMS*/;
	VALUES(0) = CAR(VALUES(0));
	if(VALUES(0)==Cnil)goto L106;
	RETURN(1);
L106:
	RETURN(Lerror(2,VV[4],(V4))               /*  ERROR           */);
	}}
}
/*	macro definition for KEYSYM-MAPPING-OBJECT                    */
static L4(int narg, object V1, object V2)
{ VT6 VLEX6 CLSR6
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(2,VV[8],(V4));
	RETURN(1);}
}
/*	macro definition for KEYSYM-MAPPING-TRANSLATE                 */
static L5(int narg, object V1, object V2)
{ VT7 VLEX7 CLSR7
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(2,VV[9],(V4));
	RETURN(1);}
}
/*	macro definition for KEYSYM-MAPPING-LOWERCASE                 */
static L6(int narg, object V1, object V2)
{ VT8 VLEX8 CLSR8
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(2,VV[10],(V4));
	RETURN(1);}
}
/*	macro definition for KEYSYM-MAPPING-MODIFIERS                 */
static L7(int narg, object V1, object V2)
{ VT9 VLEX9 CLSR9
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(2,VV[11],(V4));
	RETURN(1);}
}
/*	macro definition for KEYSYM-MAPPING-MASK                      */
static L8(int narg, object V1, object V2)
{ VT10 VLEX10 CLSR10
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(2,VV[12],(V4));
	RETURN(1);}
}
/*	function definition for DEFINE-KEYSYM                         */
static L9(int narg, object V1, object V2, ...)
{ VT11 VLEX11 CLSR11
	{volatile object V3;
	volatile object V4;
	volatile object V5;
	volatile object V6;
	volatile object V7;
	va_list args; va_start(args, V2);
	narg -=2;
	{ object keyvars[10];
	parse_key(narg,args,5,L9keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	V7= keyvars[4];
	}
	{object V8;                               /*  ENTRY           */
	if(((V6))==Cnil){
	goto L112;}
	if(((V6))==(VV[16])){
	goto L114;}
	LC11(1,(V6))                              /*  MASK-CHECK      */;
L114:
	if(((V5))==Cnil){
	goto L118;}
	if(!(numberp((V5)))){
	goto L117;}
	if(!(number_compare(MAKE_FIXNUM(0),(V5))==0)){
	goto L117;}
L118:
	Lerror(1,VV[17])                          /*  ERROR           */;
L117:
	V8= list(5,(V1),(V4),(V3),(V5),(V6));
	goto L110;
L112:
	if(((V5))==Cnil){
	goto L125;}
	LC11(1,(V5))                              /*  MASK-CHECK      */;
	V8= list(4,(V1),(V4),(V3),(V5));
	goto L110;
L125:
	if(((V3))==Cnil){
	goto L129;}
	V8= list(3,(V1),(V4),(V3));
	goto L110;
L129:
	if(((V4))==Cnil){
	goto L132;}
	V8= list(2,(V1),(V4));
	goto L110;
L132:
	V8= CONS((V1),Cnil);
L110:
	if(((V7))==Cnil){
	goto L135;}
	{object V9;                               /*  PREVIOUS        */
	V9= assql((V2),((V7))->in.in_slots[55]);
	if(((V9))==Cnil){
	goto L139;}
	{object V10;
	LC10(2,(V8),CDR((V9)))                    /*  MERGE-KEYSYM-MAPPINGS*/;
	V10= VALUES(0);
	CDR((V9)) = (V10);
	goto L109;
	}
L139:
	{object V11;
	V11= CONS(list(2,(V2),(V8)),((V7))->in.in_slots[55]);
	((V7))->in.in_slots[55]= (V11);
	goto L109;
	}
	}
L135:
	{object V12;
	V12= (VV[7]->s.s_dbind);
	Lgethash(2,(V2),(VV[7]->s.s_dbind))       /*  GETHASH         */;
	LC10(2,(V8),VALUES(0))                    /*  MERGE-KEYSYM-MAPPINGS*/;
	siLhash_set(3,(V2),(V12),VALUES(0))       /*  HASH-SET        */;
	}
	}
L109:
	VALUES(0) = (V1);
	RETURN(1);
	}
}
/*	local function MERGE-KEYSYM-MAPPINGS                          */
static LC10(int narg, object V1, object V2)
{ VT12 VLEX12 CLSR12
TTL:
	{object V3;                               /*  KEY             */
	object V4;                                /*  MERGE           */
	V3= CADDDR((V1));
	T0= (VV[79]->s.s_gfdef);
	VALUES(0) = (VV[80]->s.s_gfdef);
	(*LK0)(6,(V3),(V2),VV[1],T0,VV[5],VALUES(0))/*  DELETE        */;
	V4= VALUES(0);
	if(((V3))==Cnil){
	goto L152;}
	VALUES(0) = nconc((V4),CONS((V1),Cnil));
	RETURN(1);
L152:
	VALUES(0) = CONS((V1),(V4));
	RETURN(1);
	}
}
/*	local function MASK-CHECK                                     */
static LC11(int narg, object V1)
{ VT13 VLEX13 CLSR13
TTL:
	if(numberp((V1))){
	goto L155;}
	{volatile object V2;
	volatile object V3;                       /*  ELEMENT         */
	V2= (V1);
	V3= Cnil;
L162:
	if(!((V2)==Cnil)){
	goto L163;}
	goto L155;
L163:
	V3= CAR((V2));
	(*LK2)(2,(V3),VV[19])                     /*  FIND            */;
	if(VALUES(0)!=Cnil){
	goto L168;}
	Lgethash(2,(V3),(VV[7]->s.s_dbind))       /*  GETHASH         */;
	if(VALUES(0)!=Cnil){
	goto L168;}
	goto L158;
L168:
	V2= CDR((V2));
	goto L162;
	}
L158:
	RETURN((*LK3)(2,(V1),VV[20])              /*  X-TYPE-ERROR    */);
L155:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for UNDEFINE-KEYSYM                       */
static L12(int narg, object V1, object V2, ...)
{ VT14 VLEX14 CLSR14
	{object V3;
	object V4;
	va_list args; va_start(args, V2);
	narg -=2;
	{ object keyvars[4];
	parse_key(narg,args,2,L12keys,keyvars,OBJNULL,TRUE);
	V3= keyvars[0];
	V4= keyvars[1];
	}
	{ object V5;
	V5= make_cfun(LC13,Cnil,&Cblock);
	{object V6;                               /*  ENTRY           */
	register object V7;                       /*  PREVIOUS        */
	object V8;                                /*  KEY             */
	V6= Cnil;
	if(((V3))==Cnil){
	goto L179;}
	V6= assql((V2),((V3))->in.in_slots[55]);
	V7= CDR((V6));
	goto L177;
L179:
	Lgethash(2,(V2),(VV[7]->s.s_dbind))       /*  GETHASH         */;
	V7= VALUES(0);
L177:
	V8= CONS((V1),(V4));
	if(((V7))==Cnil){
	goto L184;}
	(*LK2)(4,(V8),(V7),VV[5],(V5))            /*  FIND            */;
	if(VALUES(0)==Cnil){
	goto L184;}
	(*LK0)(4,(V8),(V7),VV[5],(V5))            /*  DELETE          */;
	V7= VALUES(0);
	if(((V3))==Cnil){
	goto L191;}
	CDR((V6)) = (V7);
	VALUES(0) = (V7);
	RETURN(1);
L191:
	RETURN(siLhash_set(3,(V2),(VV[7]->s.s_dbind),(V7))/*  HASH-SET*/);
L184:
	VALUES(0) = Cnil;
	RETURN(1);
	}
	}
	}
}
/*	local function MATCH                                          */
static LC13(int narg, object V1, object V2)
{ VT15 VLEX15 CLSR15
TTL:
	{object V3;                               /*  OBJECT          */
	object V4;                                /*  MODIFIERS       */
	V3= CAR((V1));
	V4= CDR((V1));
	if(!(eql((V3),CAR((V2))))){
	goto L196;}
	VALUES(0) = Ct;
	RETURN(1);
L196:
	VALUES(0) = (equal((V4),CADDDR((V2)))?Ct:Cnil);
	RETURN(1);
	}
}
/*	function definition for KEYSYM-DOWNCASE                       */
static L14(int narg, object V1)
{ VT16 VLEX16 CLSR16
TTL:
	{object V2;                               /*  TRANSLATIONS    */
	Lgethash(2,(V1),(VV[7]->s.s_dbind))       /*  GETHASH         */;
	V2= VALUES(0);
	if((V2)==Cnil){
	VALUES(0) = Cnil;
	goto L200;}
	VALUES(0) = CADDR(CAR((V2)));
L200:
	if(VALUES(0)==Cnil)goto L199;
	RETURN(1);
L199:
	VALUES(0) = (V1);
	RETURN(1);
	}
}
/*	function definition for KEYSYM-UPPERCASE-ALPHABETIC-P         */
static L15(int narg, object V1)
{ VT17 VLEX17 CLSR17
TTL:
	{object V2;                               /*  TRANSLATIONS    */
	Lgethash(2,(V1),(VV[7]->s.s_dbind))       /*  GETHASH         */;
	V2= VALUES(0);
	if((V2)==Cnil){
	VALUES(0) = Cnil;
	RETURN(1);}
	VALUES(0) = CADDR(CAR((V2)));
	RETURN(1);
	}
}
/*	function definition for CHARACTER->KEYSYMS                    */
static L16(int narg, object V1, ...)
{ VT18 VLEX18 CLSR18
	{int i=1;
	volatile object V2;
	va_list args; va_start(args, V1);
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(V1,env0));            /*  CHARACTER       */
	if (i==narg) goto L202;
	V2= va_arg(args, object);
	i++;
	goto L203;
L202:
	V2= Cnil;
L203:
	CLV1=&CAR(env0=CONS(Cnil,env0));          /*  RESULT          */
	if(((V2))==Cnil){
	goto L205;}
	{volatile object V3;
	volatile object V4;                       /*  MAPPING         */
	V3= ((V2))->in.in_slots[55];
	V4= Cnil;
L211:
	if(!((V3)==Cnil)){
	goto L212;}
	goto L205;
L212:
	V4= CAR((V3));
	if(!(eql(*CLV0,CADR((V4))))){
	goto L217;}
	*CLV1= CONS(CAR((V4)),*CLV1);
L217:
	V3= CDR((V3));
	goto L211;
	}
L205:
	VALUES(0) = make_cclosure(LC17,env0,&Cblock);
	Lmaphash(2,VALUES(0),(VV[7]->s.s_dbind))  /*  MAPHASH         */;
	VALUES(0) = *CLV1;
	RETURN(1);
	}
}
/*	closure CLOSURE                                               */
static LC17(int narg, object env0, object V1, object V2)
{ VT19 VLEX19 CLSR19
	narg--;
	{object scan=env0;
	CLV1= &CAR(scan);                         /*  RESULT          */ scan=CDR(scan);
	CLV0= &CAR(scan);                         /*  CHARACTER       */}
	{volatile object V3;
	volatile object V4;                       /*  MAPPING         */
	V3= (V2);
	V4= Cnil;
L229:
	if(!((V3)==Cnil)){
	goto L230;}
	VALUES(0) = Cnil;
	RETURN(1);
L230:
	V4= CAR((V3));
	if(!(eql(CAR((V4)),*CLV0))){
	goto L235;}
	Ladjoin(2,(V1),*CLV1)                     /*  ADJOIN          */;
	*CLV1= VALUES(0);
L235:
	V3= CDR((V3));
	goto L229;
	}
}
/*	function definition for DISPLAY-KEYBOARD-MAPPING              */
static L18(int narg, object V1)
{ VT20 VLEX20 CLSR20
TTL:
	VALUES(0) = ((V1))->in.in_slots[53];
	if(VALUES(0)==Cnil)goto L242;
	RETURN(1);
L242:
	(*LK4)(1,(V1))                            /*  KEYBOARD-MAPPING*/;
	((V1))->in.in_slots[53]= VALUES(0);
	VALUES(0) = VALUES(0);
	RETURN(1);
}
/*	function definition for KEYCODE->KEYSYM                       */
static L19(int narg, object V1, object V2, object V3)
{ VT21 VLEX21 CLSR21
	{int V4;
	int V5;
	V4= fix(V2);
	V5= fix(V3);
TTL:
	{object V6;                               /*  MAPPING         */
	object V7;                                /*  KEYSYM          */
	L18(1,(V1))                               /*  DISPLAY-KEYBOARD-MAPPING*/;
	V6= VALUES(0);
	V7= ((V6))->a.a_self[V4*((V6))->a.a_dims[1]+V5];
	if(!((V5)==0)){
	goto L248;}
	RETURN(L14(1,(V7))                        /*  KEYSYM-DOWNCASE */);
L248:
	if(!(number_compare(MAKE_FIXNUM(0),(V7))==0)){
	goto L251;}
	if(!((V5)>0)){
	goto L251;}
	VALUES(0) = ((V6))->a.a_self[V4*((V6))->a.a_dims[1]+0];
	RETURN(1);
L251:
	VALUES(0) = (V7);
	RETURN(1);
	}
	}
}
/*	function definition for KEYSYM->CHARACTER                     */
static L20(int narg, object V1, object V2, ...)
{ VT22 VLEX22 CLSR22
	{int i=2;
	volatile int V3;
	va_list args; va_start(args, V2);
	if (i==narg) goto L255;
	V3= fix(va_arg(args, object));
	i++;
	goto L256;
L255:
	V3= 0;
L256:
	{volatile object V4;                      /*  DISPLAY-MAPPINGS*/
	volatile object V5;                       /*  MAPPING         */
	VALUES(0) = assql((V2),((V1))->in.in_slots[55]);
	V4= CDR(VALUES(0));
	{volatile object V6;
	volatile object V7;                       /*  MAPPING         */
	V6= (V4);
	V7= Cnil;
L266:
	if(!((V6)==Cnil)){
	goto L267;}
	VALUES(0) = Cnil;
	goto L262;
L267:
	V7= CAR((V6));
	L21(3,(V1),MAKE_FIXNUM(V3),(V7))          /*  MAPPING-MATCHES-P*/;
	if(VALUES(0)==Cnil){
	goto L272;}
	VALUES(0) = (V7);
	goto L262;
L272:
	V6= CDR((V6));
	goto L266;
	}
L262:
	if(VALUES(0)==Cnil)goto L261;
	V5= VALUES(0);
	goto L260;
L261:
	{volatile object V6;
	volatile object V7;                       /*  MAPPING         */
	Lgethash(2,(V2),(VV[7]->s.s_dbind))       /*  GETHASH         */;
	V6= VALUES(0);
	V7= Cnil;
L281:
	if(!((V6)==Cnil)){
	goto L282;}
	V5= Cnil;
	goto L260;
L282:
	V7= CAR((V6));
	L21(3,(V1),MAKE_FIXNUM(V3),(V7))          /*  MAPPING-MATCHES-P*/;
	if(VALUES(0)==Cnil){
	goto L287;}
	V5= (V7);
	goto L260;
L287:
	V6= CDR((V6));
	goto L281;
	}
L260:
	if(((V5))==Cnil){
	goto L294;}
	{object V6;
	V6= CADR((V5));
	if(((V6))==Cnil){
	goto L299;}
	T0= (V6);
	goto L296;
L299:
	T0= VV[36];
	}
L296:
	RETURN(funcall(4,T0,(V1),MAKE_FIXNUM(V3),CAR((V5))));
L294:
	VALUES(0) = Cnil;
	RETURN(1);
	}
	}
}
/*	function definition for MAPPING-MATCHES-P                     */
static L21(int narg, object V1, object V2, object V3)
{ VT23 VLEX23 CLSR23
TTL:
	{object V4;                               /*  DISPLAY-MAPPING */
	object V5;                                /*  MAPPING-MODIFIERS*/
	int V6;                                   /*  MODIFIERS       */
	object V7;                                /*  MAPPING-MASK    */
	L26(1,(V1))                               /*  GET-DISPLAY-MODIFIER-MAPPING*/;
	V4= VALUES(0);
	V5= CADDDR((V3));
	if((V5)!=Cnil){
	VALUES(0) = (V5);
	goto L306;}
	VALUES(0) = MAKE_FIXNUM(0);
L306:
	LC22(3,(V4),VALUES(0),Ct)                 /*  MODIFIERS->MASK */;
	if(VALUES(0)==Cnil)goto L304;
	V6= fix(VALUES(0));
	goto L303;
L304:
	VALUES(0) = Cnil;
	RETURN(1);
L303:
	Lfifth(1,(V3))                            /*  FIFTH           */;
	if(VALUES(0)==Cnil)goto L308;
	V7= VALUES(0);
	goto L307;
L308:
	if(((V5))==Cnil){
	goto L311;}
	V7= (VV[15]->s.s_dbind);
	goto L307;
L311:
	V7= MAKE_FIXNUM(0);
L307:
	if(!(((V7))==(VV[16]))){
	goto L315;}
	VALUES(0) = MAKE_FIXNUM(V6);
	goto L313;
L315:
	LC22(3,(V4),(V7),Cnil)                    /*  MODIFIERS->MASK */;
L313:
	VALUES(0) = ((((fix((V2))) & (fix(VALUES(0)))))==(V6)?Ct:Cnil);
	RETURN(1);
	}
}
/*	local function MODIFIERS->MASK                                */
static LC22(int narg, object V1, object V2, object V3)
{ VT24 VLEX24 CLSR24
TTL:
	{register int V4;                         /*  MASK            */
	V4= 0;
	if(!(numberp((V2)))){
	goto L319;}
	VALUES(0) = (V2);
	RETURN(1);
L319:
	{volatile object V5;
	volatile object V6;                       /*  MODIFIER        */
	V5= (V2);
	V6= Cnil;
L324:
	if(!((V5)==Cnil)){
	goto L325;}
	VALUES(0) = MAKE_FIXNUM(V4);
	RETURN(1);
L325:
	V6= CAR((V5));
	{register object V8;                      /*  BIT             */
	VALUES(0) = (VV[92]->s.s_gfdef);
	(*LK5)(4,(V6),VV[19],VV[5],VALUES(0))     /*  POSITION        */;
	V8= VALUES(0);
	if(((V8))==Cnil){
	goto L336;}
	Lash(2,MAKE_FIXNUM(1),(V8))               /*  ASH             */;
	goto L334;
L336:
	VALUES(0) = assql((V6),(V1));
	VALUES(0) = CDR(VALUES(0));
	if(VALUES(0)==Cnil)goto L338;
	goto L334;
L338:
	if(((V3))==Cnil){
	goto L342;}
	VALUES(0) = Cnil;
	RETURN(1);
L342:
	VALUES(0) = MAKE_FIXNUM(0);
L334:
	Llogior(2,MAKE_FIXNUM(V4),VALUES(0))      /*  LOGIOR          */;
	V4= fix(VALUES(0));
	}
	V5= CDR((V5));
	goto L324;
	}
	}
}
/*	function definition for DEFAULT-KEYSYM-INDEX                  */
static L23(int narg, object V1, object V2, object V3)
{ VT25 VLEX25 CLSR25
TTL:
	{object V4;                               /*  MAPPING         */
	int V5;                                   /*  KEYSYMS-PER-KEYCODE*/
	object V6;                                /*  SYMBOLP         */
	register int V7;                          /*  RESULT          */
	L18(1,(V1))                               /*  DISPLAY-KEYBOARD-MAPPING*/;
	V4= VALUES(0);
	Larray_dimension(2,(V4),MAKE_FIXNUM(1))   /*  ARRAY-DIMENSION */;
	V5= fix(VALUES(0));
	if((V5)>(2)){
	goto L350;}
	V6= Cnil;
	goto L349;
L350:
	L28(3,(V1),(V3),MAKE_FIXNUM(65406))       /*  STATE-KEYSYMP   */;
	V6= VALUES(0);
L349:
	if(((V6))==Cnil){
	goto L354;}
	V7= 2;
	goto L352;
L354:
	V7= 0;
L352:
	if(!((V7)<(V5))){
	goto L356;}
	L15(1,((V4))->a.a_self[fix((V2))*((V4))->a.a_dims[1]+fix(MAKE_FIXNUM(0))])/*  KEYSYM-UPPERCASE-ALPHABETIC-P*/;
	L24(3,(V1),(V3),VALUES(0))                /*  KEYSYM-SHIFT-P  */;
	if(VALUES(0)==Cnil){
	goto L356;}
	V7= (V7)+(1);
L356:
	VALUES(0) = MAKE_FIXNUM(V7);
	RETURN(1);
	}
}
/*	function definition for KEYSYM-SHIFT-P                        */
static L24(int narg, object V1, object V2, object V3, ...)
{ VT26 VLEX26 CLSR26
	{volatile int V4;
	volatile object V5;
	volatile object V6;
	va_list args; va_start(args, V3);
	V4= fix(V2);
	narg -=3;
	{ object keyvars[4];
	parse_key(narg,args,2,L24keys,keyvars,OBJNULL,FALSE);
	V5= keyvars[0];
	if(keyvars[3]==Cnil){
	V6= VV[37];
	}else{
	V6= keyvars[1];}
	}
	{volatile object V7;                      /*  CONTROLP        */
	volatile object V8;                       /*  SHIFTP          */
	volatile object V9;                       /*  LOCKP           */
	volatile object V10;                      /*  ALPHAP          */
	if(!((V4 >> 2) & 1)){
	goto L365;}
	V7= Ct;
	goto L364;
L365:
	{volatile object V11;
	volatile object V12;                      /*  MODIFIER        */
	V11= (V6);
	V12= Cnil;
L370:
	if(!((V11)==Cnil)){
	goto L371;}
	V7= Cnil;
	goto L364;
L371:
	V12= CAR((V11));
	L28(3,(V1),MAKE_FIXNUM(V4),(V12))         /*  STATE-KEYSYMP   */;
	if(VALUES(0)==Cnil){
	goto L376;}
	V7= Ct;
	goto L364;
L376:
	V11= CDR((V11));
	goto L370;
	}
L364:
	V8= ((V4 >> 0) & 1?Ct:Cnil);
	V9= ((V4 >> 1) & 1?Ct:Cnil);
	if((V3)!=Cnil){
	V10= (V3);
	goto L384;}
	L28(3,(V1),MAKE_FIXNUM(2),MAKE_FIXNUM(65509))/*  STATE-KEYSYMP*/;
	V10= ((VALUES(0))==Cnil?Ct:Cnil);
L384:
	if(((V7))!=Cnil){
	goto L386;}
	if(((V9))==Cnil){
	goto L386;}
	if(((V10))==Cnil){
	goto L386;}
	if(((V8))==Cnil){
	goto L389;}
	if(((V5))==Cnil){
	goto L386;}
L389:
	V8= (((V8))==Cnil?Ct:Cnil);
L386:
	VALUES(0) = (V8);
	RETURN(1);
	}
	}
}
/*	function definition for KEYCODE->CHARACTER                    */
static L25(int narg, object V1, object V2, object V3, ...)
{ VT27 VLEX27 CLSR27
	{int V4;
	int V5;
	object V6;
	object V7;
	va_list args; va_start(args, V3);
	V4= fix(V2);
	V5= fix(V3);
	narg -=3;
	{ object keyvars[4];
	parse_key(narg,args,2,L25keys,keyvars,OBJNULL,FALSE);
	V6= keyvars[0];
	if(keyvars[3]==Cnil){
	V7= (VV[60]->s.s_gfdef);
	}else{
	V7= keyvars[1];}
	}
	{object V8;                               /*  INDEX           */
	object V9;                                /*  KEYSYM          */
	if((V6)!=Cnil){
	V8= (V6);
	goto L399;}
	funcall(4,(V7),(V1),MAKE_FIXNUM(V4),MAKE_FIXNUM(V5));
	V8= VALUES(0);
L399:
	if(((V8))==Cnil){
	goto L402;}
	L19(3,(V1),MAKE_FIXNUM(V4),(V8))          /*  KEYCODE->KEYSYM */;
	V9= VALUES(0);
	goto L400;
L402:
	V9= MAKE_FIXNUM(0);
L400:
	if(!(number_compare(MAKE_FIXNUM(0),(V9))<0)){
	goto L405;}
	RETURN(L20(3,(V1),(V9),MAKE_FIXNUM(V5))   /*  KEYSYM->CHARACTER*/);
L405:
	VALUES(0) = Cnil;
	RETURN(1);
	}
	}
}
/*	function definition for GET-DISPLAY-MODIFIER-MAPPING          */
static L26(int narg, object V1)
{ VT28 VLEX28 CLSR28
TTL:
	VALUES(0) = ((V1))->in.in_slots[54];
	if(VALUES(0)==Cnil)goto L407;
	RETURN(1);
L407:
	{ int V2;
	volatile object V3;                       /*  SHIFT           */
	volatile object V4;                       /*  LOCK            */
	volatile object V5;                       /*  CONTROL         */
	volatile object V6;                       /*  MOD1            */
	volatile object V7;                       /*  MOD2            */
	volatile object V8;                       /*  MOD3            */
	volatile object V9;                       /*  MOD4            */
	volatile object V10;                      /*  MOD5            */
	V2=(*LK6)(1,(V1))                         /*  MODIFIER-MAPPING*/;
	if (V2--==0) goto L410;
	V3= VALUES(0);
	if (V2--==0) goto L411;
	V4= VALUES(1);
	if (V2--==0) goto L412;
	V5= VALUES(2);
	if (V2--==0) goto L413;
	V6= VALUES(3);
	if (V2--==0) goto L414;
	V7= VALUES(4);
	if (V2--==0) goto L415;
	V8= VALUES(5);
	if (V2--==0) goto L416;
	V9= VALUES(6);
	if (V2--==0) goto L417;
	V10= VALUES(7);
	goto L418;
L410:
	V3= Cnil;
L411:
	V4= Cnil;
L412:
	V5= Cnil;
L413:
	V6= Cnil;
L414:
	V7= Cnil;
L415:
	V8= Cnil;
L416:
	V9= Cnil;
L417:
	V10= Cnil;
L418:
	LC27(3,(V1),(V3),MAKE_FIXNUM(1))          /*  KEYSYM-REPLACE  */;
	T0= VALUES(0);
	LC27(3,(V1),(V4),MAKE_FIXNUM(2))          /*  KEYSYM-REPLACE  */;
	T1= VALUES(0);
	LC27(3,(V1),(V5),MAKE_FIXNUM(4))          /*  KEYSYM-REPLACE  */;
	T2= VALUES(0);
	LC27(3,(V1),(V6),MAKE_FIXNUM(8))          /*  KEYSYM-REPLACE  */;
	T3= VALUES(0);
	LC27(3,(V1),(V7),MAKE_FIXNUM(16))         /*  KEYSYM-REPLACE  */;
	T4= VALUES(0);
	LC27(3,(V1),(V8),MAKE_FIXNUM(32))         /*  KEYSYM-REPLACE  */;
	T5= VALUES(0);
	LC27(3,(V1),(V9),MAKE_FIXNUM(64))         /*  KEYSYM-REPLACE  */;
	T6= VALUES(0);
	LC27(3,(V1),(V10),MAKE_FIXNUM(128))       /*  KEYSYM-REPLACE  */;
	Lnconc(8,T0,T1,T2,T3,T4,T5,T6,VALUES(0))  /*  NCONC           */;
	((V1))->in.in_slots[54]= VALUES(0);
	VALUES(0) = VALUES(0);
	RETURN(1);}
}
/*	local function KEYSYM-REPLACE                                 */
static LC27(int narg, object V1, object V2, object V3)
{ VT29 VLEX29 CLSR29
TTL:
	{register object V4;                      /*  RESULT          */
	V4= Cnil;
	{volatile object V5;
	volatile object V6;                       /*  MODIFIER        */
	V5= (V2);
	V6= Cnil;
L432:
	if(!((V5)==Cnil)){
	goto L433;}
	VALUES(0) = (V4);
	RETURN(1);
L433:
	V6= CAR((V5));
	L19(3,(V1),(V6),MAKE_FIXNUM(0))           /*  KEYCODE->KEYSYM */;
	V4= CONS(CONS(VALUES(0),(V3)),(V4));
	V5= CDR((V5));
	goto L432;
	}
	}
}
/*	function definition for STATE-KEYSYMP                         */
static L28(int narg, object V1, object V2, object V3)
{ VT30 VLEX30 CLSR30
TTL:
	{object V4;                               /*  MAPPING         */
	object V5;                                /*  MASK            */
	L26(1,(V1))                               /*  GET-DISPLAY-MODIFIER-MAPPING*/;
	V4= VALUES(0);
	V5= assql((V3),(V4));
	if((V5)==Cnil){
	VALUES(0) = Cnil;
	RETURN(1);}
	Llogand(2,(V2),CDR((V5)))                 /*  LOGAND          */;
	VALUES(0) = ((fix(VALUES(0)))>0?Ct:Cnil);
	RETURN(1);
	}
}
/*	function definition for MAPPING-NOTIFY                        */
static L29(int narg, object V1, object V2, object V3, object V4)
{ VT31 VLEX31 CLSR31
TTL:
	if(((V2)!= VV[103]))goto L447;
	((V1))->in.in_slots[54]= Cnil;
	VALUES(0) = Cnil;
	RETURN(1);
L447:
	if(((V2)!= VV[104]))goto L448;
	((V1))->in.in_slots[53]= Cnil;
	VALUES(0) = Cnil;
	RETURN(1);
L448:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for KEYSYM-IN-MAP-P                       */
static L30(int narg, object V1, object V2, object V3)
{ VT32 VLEX32 CLSR32
TTL:
	{volatile object V4;                      /*  MIN             */
	volatile int V5;                          /*  MAX             */
	volatile object V6;                       /*  MAP             */
	volatile int V7;                          /*  JMAX            */
	volatile object V8;                       /*  I               */
	V4= ((V1))->in.in_slots[46];
	V5= fix(((V1))->in.in_slots[47]);
	L18(1,(V1))                               /*  DISPLAY-KEYBOARD-MAPPING*/;
	V6= VALUES(0);
	Larray_dimension(2,(V6),MAKE_FIXNUM(1))   /*  ARRAY-DIMENSION */;
	V7= (2)<=(fix(VALUES(0)))?2:fix(VALUES(0));
	V8= (V4);
L456:
	if(!(number_compare((V8),MAKE_FIXNUM(V5))>0)){
	goto L457;}
	VALUES(0) = Cnil;
	RETURN(1);
L457:
	if(!(number_compare(MAKE_FIXNUM(0),aref1((V3),fix((V8))))<0)){
	goto L460;}
	{volatile int V10;
	volatile int V11;                         /*  J               */
	V10= V7;
	V11= 0;
L468:
	if(!((V11)>=(V10))){
	goto L469;}
	goto L460;
L469:
	if(!(number_compare((V2),((V6))->a.a_self[fix((V8))*((V6))->a.a_dims[1]+fix(MAKE_FIXNUM(V11))])==0)){
	goto L472;}
	goto L464;
L472:
	V11= (V11)+1;
	goto L468;
	}
L464:
	VALUES(0) = Ct;
	RETURN(1);
L460:
	V8= one_plus((V8));
	goto L456;
	}
}
/*	function definition for CHARACTER-IN-MAP-P                    */
static L31(int narg, object V1, object V2, object V3)
{ VT33 VLEX33 CLSR33
	{volatile unsigned char V4;
	V4= char_code(V2);
TTL:
	{volatile object V5;                      /*  MIN             */
	volatile int V6;                          /*  MAX             */
	volatile int V7;                          /*  JMAX            */
	volatile object V8;                       /*  I               */
	V5= ((V1))->in.in_slots[46];
	V6= fix(((V1))->in.in_slots[47]);
	L18(1,(V1))                               /*  DISPLAY-KEYBOARD-MAPPING*/;
	Larray_dimension(2,VALUES(0),MAKE_FIXNUM(1))/*  ARRAY-DIMENSION*/;
	V7= fix(VALUES(0));
	V8= (V5);
L487:
	if(!(number_compare((V8),MAKE_FIXNUM(V6))>0)){
	goto L488;}
	VALUES(0) = Cnil;
	RETURN(1);
L488:
	if(!(number_compare(MAKE_FIXNUM(0),aref1((V3),fix((V8))))<0)){
	goto L491;}
	{volatile int V10;
	volatile int V11;                         /*  J               */
	V10= V7;
	V11= 0;
L499:
	if(!((V11)>=(V10))){
	goto L500;}
	goto L491;
L500:
	L25(5,(V1),(V8),MAKE_FIXNUM(0),VV[38],MAKE_FIXNUM(V11))/*  KEYCODE->CHARACTER*/;
	if(!((CHARACTERP(VALUES(0)) && (V4)==char_code(VALUES(0))))){
	goto L503;}
	goto L495;
L503:
	V11= (V11)+1;
	goto L499;
	}
L495:
	VALUES(0) = Ct;
	RETURN(1);
L491:
	V8= one_plus((V8));
	goto L487;
	}
	}
}
/*	function definition for KEYSYM->KEYCODES                      */
static L32(int narg, object V1, object V2)
{ VT34 VLEX34 CLSR34
TTL:
	{volatile object V3;                      /*  MIN             */
	volatile int V4;                          /*  MAX             */
	volatile object V5;                       /*  MAP             */
	volatile int V6;                          /*  JMAX            */
	volatile object V7;                       /*  I               */
	volatile object V8;                       /*  RESULT          */
	V3= ((V1))->in.in_slots[46];
	V4= fix(((V1))->in.in_slots[47]);
	L18(1,(V1))                               /*  DISPLAY-KEYBOARD-MAPPING*/;
	V5= VALUES(0);
	Larray_dimension(2,(V5),MAKE_FIXNUM(1))   /*  ARRAY-DIMENSION */;
	V6= (2)<=(fix(VALUES(0)))?2:fix(VALUES(0));
	V7= (V3);
	V8= Cnil;
L521:
	if(!(number_compare((V7),MAKE_FIXNUM(V4))>0)){
	goto L522;}
	RETURN(Lvalues_list(1,(V8))               /*  VALUES-LIST     */);
L522:
	{volatile int V10;
	volatile int V11;                         /*  J               */
	V10= V6;
	V11= 0;
L529:
	if(!((V11)>=(V10))){
	goto L530;}
	goto L525;
L530:
	if(!(number_compare((V2),((V5))->a.a_self[fix((V7))*((V5))->a.a_dims[1]+fix(MAKE_FIXNUM(V11))])==0)){
	goto L533;}
	V8= CONS((V7),(V8));
L533:
	V11= (V11)+1;
	goto L529;
	}
L525:
	V7= one_plus((V7));
	goto L521;
	}
}
static LKF6(int narg, ...) {TRAMPOLINK(VV[100],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[93],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[87],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[82],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[81],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[73],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[70],&LK0);}
