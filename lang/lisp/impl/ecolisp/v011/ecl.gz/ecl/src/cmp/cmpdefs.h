
/* (c) Copyright G. Attardi, 1993. */
int siLfset();
int siLfset();
int siLfset();
int siLfset();
int siLfset();
#define VT2
#define VLEX2
#define CLSR2
static L1(int, ...);
static intUobject L1keys[3]={51,52,53};
#define VT3
#define VLEX3
#define CLSR3
static L2(int, ...);
static intUobject L2keys[6]={51,52,53,54,55,56};
#define VT4
#define VLEX4
#define CLSR4
static L3(int, ...);
static intUobject L3keys[8]={51,52,53,57,58,59,60,61};
#define VT5
#define VLEX5
#define CLSR5
static L4(int, ...);
static intUobject L4keys[7]={51,52,53,62,63,64,61};
#define VT6
#define VLEX6
#define CLSR6
static L5(int, ...);
static intUobject L5keys[7]={51,52,53,62,65,66,61};
#define VT7
#define VLEX7
#define CLSR7
static L6(int, ...);
static intUobject L6keys[6]={67,68,56,69,70,71};
#define VT8
#define VLEX8
#define CLSR8
static struct codeblock Cblock;
#define VM8 0
#define VM7 0
#define VM6 0
#define VM5 0
#define VM4 0
#define VM3 0
#define VM2 0
#define VM1 72
static object VV[72];
static LKF0(int, ...);
static (*LK0)(int, ...)=LKF0;
