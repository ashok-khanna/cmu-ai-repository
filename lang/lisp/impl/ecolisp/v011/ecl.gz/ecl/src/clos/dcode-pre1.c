
#include "dcode-pre1.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	MM0(VV[63],L1);
	MM0(VV[1],L3);
	VV[64] = make_cfun(LC4,Cnil,&Cblock);
	{object V1;                               /*  ENTRY           */
	{register object x= VV[22],V2= getf(VV[2]->s.s_plist,VV[23],Cnil);
	while(V2!=Cnil)
	if(CAR(V2) != Cnil && 
	equal(x,CAAR(V2))){
	VALUES(0) = CAR(V2);
	goto L4;
	}else V2=CDR(V2);
	VALUES(0) = Cnil;}
L4:
	if(VALUES(0)==Cnil)goto L3;
	V1= VALUES(0);
	goto L2;
L3:
	{object V2;                               /*  NEW-ENTRY       */
	V2= list(4,VV[22],Cnil,Cnil,Cnil);
	putprop(VV[2],CONS((V2),getf(VV[2]->s.s_plist,VV[23],Cnil)),VV[23]);
	V1= (V2);
	}
L2:
	CAR(CDDR((V1))) = VV[24];
	{object V2;
	V2= VV[64];
	CAR(CDR((V1))) = (V2);
	}
	}
	{object V3;                               /*  ENTRY           */
	{register object x= VV[25],V4= getf(VV[2]->s.s_plist,VV[23],Cnil);
	while(V4!=Cnil)
	if(CAR(V4) != Cnil && 
	equal(x,CAAR(V4))){
	VALUES(0) = CAR(V4);
	goto L14;
	}else V4=CDR(V4);
	VALUES(0) = Cnil;}
L14:
	if(VALUES(0)==Cnil)goto L13;
	V3= VALUES(0);
	goto L12;
L13:
	{object V4;                               /*  NEW-ENTRY       */
	V4= list(4,VV[25],Cnil,Cnil,Cnil);
	putprop(VV[2],CONS((V4),getf(VV[2]->s.s_plist,VV[23],Cnil)),VV[23]);
	V3= (V4);
	}
L12:
	CAR(CDDR((V3))) = VV[24];
	{object V4;
	V4= VV[64];
	CAR(CDR((V3))) = (V4);
	}
	}
	{object V5;                               /*  ENTRY           */
	{register object x= VV[26],V6= getf(VV[2]->s.s_plist,VV[23],Cnil);
	while(V6!=Cnil)
	if(CAR(V6) != Cnil && 
	equal(x,CAAR(V6))){
	VALUES(0) = CAR(V6);
	goto L24;
	}else V6=CDR(V6);
	VALUES(0) = Cnil;}
L24:
	if(VALUES(0)==Cnil)goto L23;
	V5= VALUES(0);
	goto L22;
L23:
	{object V6;                               /*  NEW-ENTRY       */
	V6= list(4,VV[26],Cnil,Cnil,Cnil);
	putprop(VV[2],CONS((V6),getf(VV[2]->s.s_plist,VV[23],Cnil)),VV[23]);
	V5= (V6);
	}
L22:
	CAR(CDDR((V5))) = VV[24];
	{object V6;
	V6= VV[64];
	CAR(CDR((V5))) = (V6);
	}
	}
	{object V7;                               /*  ENTRY           */
	{register object x= VV[27],V8= getf(VV[2]->s.s_plist,VV[23],Cnil);
	while(V8!=Cnil)
	if(CAR(V8) != Cnil && 
	equal(x,CAAR(V8))){
	VALUES(0) = CAR(V8);
	goto L34;
	}else V8=CDR(V8);
	VALUES(0) = Cnil;}
L34:
	if(VALUES(0)==Cnil)goto L33;
	V7= VALUES(0);
	goto L32;
L33:
	{object V8;                               /*  NEW-ENTRY       */
	V8= list(4,VV[27],Cnil,Cnil,Cnil);
	putprop(VV[2],CONS((V8),getf(VV[2]->s.s_plist,VV[23],Cnil)),VV[23]);
	V7= (V8);
	}
L32:
	CAR(CDDR((V7))) = VV[24];
	{object V8;
	V8= VV[64];
	CAR(CDR((V7))) = (V8);
	}
	}
	{object V9;                               /*  ENTRY           */
	{register object x= VV[28],V10= getf(VV[2]->s.s_plist,VV[23],Cnil);
	while(V10!=Cnil)
	if(CAR(V10) != Cnil && 
	equal(x,CAAR(V10))){
	VALUES(0) = CAR(V10);
	goto L44;
	}else V10=CDR(V10);
	VALUES(0) = Cnil;}
L44:
	if(VALUES(0)==Cnil)goto L43;
	V9= VALUES(0);
	goto L42;
L43:
	{object V10;                              /*  NEW-ENTRY       */
	V10= list(4,VV[28],Cnil,Cnil,Cnil);
	putprop(VV[2],CONS((V10),getf(VV[2]->s.s_plist,VV[23],Cnil)),VV[23]);
	V9= (V10);
	}
L42:
	CAR(CDDR((V9))) = VV[24];
	{object V10;
	V10= VV[64];
	CAR(CDR((V9))) = (V10);
	}
	}
	{object V11;                              /*  ENTRY           */
	{register object x= VV[29],V12= getf(VV[2]->s.s_plist,VV[23],Cnil);
	while(V12!=Cnil)
	if(CAR(V12) != Cnil && 
	equal(x,CAAR(V12))){
	VALUES(0) = CAR(V12);
	goto L54;
	}else V12=CDR(V12);
	VALUES(0) = Cnil;}
L54:
	if(VALUES(0)==Cnil)goto L53;
	V11= VALUES(0);
	goto L52;
L53:
	{object V12;                              /*  NEW-ENTRY       */
	V12= list(4,VV[29],Cnil,Cnil,Cnil);
	putprop(VV[2],CONS((V12),getf(VV[2]->s.s_plist,VV[23],Cnil)),VV[23]);
	V11= (V12);
	}
L52:
	CAR(CDDR((V11))) = VV[24];
	{object V12;
	V12= VV[64];
	CAR(CDR((V11))) = (V12);
	}
	}
	{object V13;                              /*  ENTRY           */
	{register object x= VV[30],V14= getf(VV[2]->s.s_plist,VV[23],Cnil);
	while(V14!=Cnil)
	if(CAR(V14) != Cnil && 
	equal(x,CAAR(V14))){
	VALUES(0) = CAR(V14);
	goto L64;
	}else V14=CDR(V14);
	VALUES(0) = Cnil;}
L64:
	if(VALUES(0)==Cnil)goto L63;
	V13= VALUES(0);
	goto L62;
L63:
	{object V14;                              /*  NEW-ENTRY       */
	V14= list(4,VV[30],Cnil,Cnil,Cnil);
	putprop(VV[2],CONS((V14),getf(VV[2]->s.s_plist,VV[23],Cnil)),VV[23]);
	V13= (V14);
	}
L62:
	CAR(CDDR((V13))) = VV[24];
	{object V14;
	V14= VV[64];
	CAR(CDR((V13))) = (V14);
	}
	}
	{object V15;                              /*  ENTRY           */
	{register object x= VV[31],V16= getf(VV[2]->s.s_plist,VV[23],Cnil);
	while(V16!=Cnil)
	if(CAR(V16) != Cnil && 
	equal(x,CAAR(V16))){
	VALUES(0) = CAR(V16);
	goto L74;
	}else V16=CDR(V16);
	VALUES(0) = Cnil;}
L74:
	if(VALUES(0)==Cnil)goto L73;
	V15= VALUES(0);
	goto L72;
L73:
	{object V16;                              /*  NEW-ENTRY       */
	V16= list(4,VV[31],Cnil,Cnil,Cnil);
	putprop(VV[2],CONS((V16),getf(VV[2]->s.s_plist,VV[23],Cnil)),VV[23]);
	V15= (V16);
	}
L72:
	CAR(CDDR((V15))) = VV[24];
	{object V16;
	V16= VV[64];
	CAR(CDR((V15))) = (V16);
	}
	}
	{object V17;                              /*  ENTRY           */
	{register object x= VV[32],V18= getf(VV[2]->s.s_plist,VV[23],Cnil);
	while(V18!=Cnil)
	if(CAR(V18) != Cnil && 
	equal(x,CAAR(V18))){
	VALUES(0) = CAR(V18);
	goto L84;
	}else V18=CDR(V18);
	VALUES(0) = Cnil;}
L84:
	if(VALUES(0)==Cnil)goto L83;
	V17= VALUES(0);
	goto L82;
L83:
	{object V18;                              /*  NEW-ENTRY       */
	V18= list(4,VV[32],Cnil,Cnil,Cnil);
	putprop(VV[2],CONS((V18),getf(VV[2]->s.s_plist,VV[23],Cnil)),VV[23]);
	V17= (V18);
	}
L82:
	CAR(CDDR((V17))) = VV[24];
	{object V18;
	V18= VV[64];
	CAR(CDR((V17))) = (V18);
	}
	}
	{object V19;                              /*  ENTRY           */
	{register object x= VV[33],V20= getf(VV[2]->s.s_plist,VV[23],Cnil);
	while(V20!=Cnil)
	if(CAR(V20) != Cnil && 
	equal(x,CAAR(V20))){
	VALUES(0) = CAR(V20);
	goto L94;
	}else V20=CDR(V20);
	VALUES(0) = Cnil;}
L94:
	if(VALUES(0)==Cnil)goto L93;
	V19= VALUES(0);
	goto L92;
L93:
	{object V20;                              /*  NEW-ENTRY       */
	V20= list(4,VV[33],Cnil,Cnil,Cnil);
	putprop(VV[2],CONS((V20),getf(VV[2]->s.s_plist,VV[23],Cnil)),VV[23]);
	V19= (V20);
	}
L92:
	CAR(CDDR((V19))) = VV[24];
	{object V20;
	V20= VV[64];
	CAR(CDR((V19))) = (V20);
	}
	}
	{object V21;                              /*  ENTRY           */
	{register object x= VV[34],V22= getf(VV[2]->s.s_plist,VV[23],Cnil);
	while(V22!=Cnil)
	if(CAR(V22) != Cnil && 
	equal(x,CAAR(V22))){
	VALUES(0) = CAR(V22);
	goto L104;
	}else V22=CDR(V22);
	VALUES(0) = Cnil;}
L104:
	if(VALUES(0)==Cnil)goto L103;
	V21= VALUES(0);
	goto L102;
L103:
	{object V22;                              /*  NEW-ENTRY       */
	V22= list(4,VV[34],Cnil,Cnil,Cnil);
	putprop(VV[2],CONS((V22),getf(VV[2]->s.s_plist,VV[23],Cnil)),VV[23]);
	V21= (V22);
	}
L102:
	CAR(CDDR((V21))) = VV[24];
	{object V22;
	V22= VV[64];
	CAR(CDR((V21))) = (V22);
	}
	}
	{object V23;                              /*  ENTRY           */
	{register object x= VV[35],V24= getf(VV[2]->s.s_plist,VV[23],Cnil);
	while(V24!=Cnil)
	if(CAR(V24) != Cnil && 
	equal(x,CAAR(V24))){
	VALUES(0) = CAR(V24);
	goto L114;
	}else V24=CDR(V24);
	VALUES(0) = Cnil;}
L114:
	if(VALUES(0)==Cnil)goto L113;
	V23= VALUES(0);
	goto L112;
L113:
	{object V24;                              /*  NEW-ENTRY       */
	V24= list(4,VV[35],Cnil,Cnil,Cnil);
	putprop(VV[2],CONS((V24),getf(VV[2]->s.s_plist,VV[23],Cnil)),VV[23]);
	V23= (V24);
	}
L112:
	CAR(CDDR((V23))) = VV[24];
	{object V24;
	V24= VV[64];
	CAR(CDR((V23))) = (V24);
	}
	}
	{object V25;                              /*  ENTRY           */
	{register object x= VV[36],V26= getf(VV[2]->s.s_plist,VV[23],Cnil);
	while(V26!=Cnil)
	if(CAR(V26) != Cnil && 
	equal(x,CAAR(V26))){
	VALUES(0) = CAR(V26);
	goto L124;
	}else V26=CDR(V26);
	VALUES(0) = Cnil;}
L124:
	if(VALUES(0)==Cnil)goto L123;
	V25= VALUES(0);
	goto L122;
L123:
	{object V26;                              /*  NEW-ENTRY       */
	V26= list(4,VV[36],Cnil,Cnil,Cnil);
	putprop(VV[2],CONS((V26),getf(VV[2]->s.s_plist,VV[23],Cnil)),VV[23]);
	V25= (V26);
	}
L122:
	CAR(CDDR((V25))) = VV[24];
	{object V26;
	V26= VV[64];
	CAR(CDR((V25))) = (V26);
	}
	}
	{object V27;                              /*  ENTRY           */
	{register object x= VV[37],V28= getf(VV[2]->s.s_plist,VV[23],Cnil);
	while(V28!=Cnil)
	if(CAR(V28) != Cnil && 
	equal(x,CAAR(V28))){
	VALUES(0) = CAR(V28);
	goto L134;
	}else V28=CDR(V28);
	VALUES(0) = Cnil;}
L134:
	if(VALUES(0)==Cnil)goto L133;
	V27= VALUES(0);
	goto L132;
L133:
	{object V28;                              /*  NEW-ENTRY       */
	V28= list(4,VV[37],Cnil,Cnil,Cnil);
	putprop(VV[2],CONS((V28),getf(VV[2]->s.s_plist,VV[23],Cnil)),VV[23]);
	V27= (V28);
	}
L132:
	CAR(CDDR((V27))) = VV[24];
	{object V28;
	V28= VV[64];
	CAR(CDR((V27))) = (V28);
	}
	}
	{object V29;                              /*  ENTRY           */
	{register object x= VV[38],V30= getf(VV[2]->s.s_plist,VV[23],Cnil);
	while(V30!=Cnil)
	if(CAR(V30) != Cnil && 
	equal(x,CAAR(V30))){
	VALUES(0) = CAR(V30);
	goto L144;
	}else V30=CDR(V30);
	VALUES(0) = Cnil;}
L144:
	if(VALUES(0)==Cnil)goto L143;
	V29= VALUES(0);
	goto L142;
L143:
	{object V30;                              /*  NEW-ENTRY       */
	V30= list(4,VV[38],Cnil,Cnil,Cnil);
	putprop(VV[2],CONS((V30),getf(VV[2]->s.s_plist,VV[23],Cnil)),VV[23]);
	V29= (V30);
	}
L142:
	CAR(CDDR((V29))) = VV[24];
	{object V30;
	V30= VV[64];
	CAR(CDR((V29))) = (V30);
	}
	}
	{object V31;                              /*  ENTRY           */
	{register object x= VV[39],V32= getf(VV[2]->s.s_plist,VV[23],Cnil);
	while(V32!=Cnil)
	if(CAR(V32) != Cnil && 
	equal(x,CAAR(V32))){
	VALUES(0) = CAR(V32);
	goto L154;
	}else V32=CDR(V32);
	VALUES(0) = Cnil;}
L154:
	if(VALUES(0)==Cnil)goto L153;
	V31= VALUES(0);
	goto L152;
L153:
	{object V32;                              /*  NEW-ENTRY       */
	V32= list(4,VV[39],Cnil,Cnil,Cnil);
	putprop(VV[2],CONS((V32),getf(VV[2]->s.s_plist,VV[23],Cnil)),VV[23]);
	V31= (V32);
	}
L152:
	CAR(CDDR((V31))) = VV[24];
	{object V32;
	V32= VV[64];
	CAR(CDR((V31))) = (V32);
	}
	}
	{object V33;                              /*  ENTRY           */
	{register object x= VV[40],V34= getf(VV[2]->s.s_plist,VV[23],Cnil);
	while(V34!=Cnil)
	if(CAR(V34) != Cnil && 
	equal(x,CAAR(V34))){
	VALUES(0) = CAR(V34);
	goto L164;
	}else V34=CDR(V34);
	VALUES(0) = Cnil;}
L164:
	if(VALUES(0)==Cnil)goto L163;
	V33= VALUES(0);
	goto L162;
L163:
	{object V34;                              /*  NEW-ENTRY       */
	V34= list(4,VV[40],Cnil,Cnil,Cnil);
	putprop(VV[2],CONS((V34),getf(VV[2]->s.s_plist,VV[23],Cnil)),VV[23]);
	V33= (V34);
	}
L162:
	CAR(CDDR((V33))) = VV[24];
	{object V34;
	V34= VV[64];
	CAR(CDR((V33))) = (V34);
	}
	}
	{object V35;                              /*  ENTRY           */
	{register object x= VV[41],V36= getf(VV[2]->s.s_plist,VV[23],Cnil);
	while(V36!=Cnil)
	if(CAR(V36) != Cnil && 
	equal(x,CAAR(V36))){
	VALUES(0) = CAR(V36);
	goto L174;
	}else V36=CDR(V36);
	VALUES(0) = Cnil;}
L174:
	if(VALUES(0)==Cnil)goto L173;
	V35= VALUES(0);
	goto L172;
L173:
	{object V36;                              /*  NEW-ENTRY       */
	V36= list(4,VV[41],Cnil,Cnil,Cnil);
	putprop(VV[2],CONS((V36),getf(VV[2]->s.s_plist,VV[23],Cnil)),VV[23]);
	V35= (V36);
	}
L172:
	CAR(CDDR((V35))) = VV[24];
	{object V36;
	V36= VV[64];
	CAR(CDR((V35))) = (V36);
	}
	}
	{object V37;                              /*  ENTRY           */
	{register object x= VV[42],V38= getf(VV[2]->s.s_plist,VV[23],Cnil);
	while(V38!=Cnil)
	if(CAR(V38) != Cnil && 
	equal(x,CAAR(V38))){
	VALUES(0) = CAR(V38);
	goto L184;
	}else V38=CDR(V38);
	VALUES(0) = Cnil;}
L184:
	if(VALUES(0)==Cnil)goto L183;
	V37= VALUES(0);
	goto L182;
L183:
	{object V38;                              /*  NEW-ENTRY       */
	V38= list(4,VV[42],Cnil,Cnil,Cnil);
	putprop(VV[2],CONS((V38),getf(VV[2]->s.s_plist,VV[23],Cnil)),VV[23]);
	V37= (V38);
	}
L182:
	CAR(CDDR((V37))) = VV[24];
	{object V38;
	V38= VV[64];
	CAR(CDR((V37))) = (V38);
	}
	}
	VALUES(0) = make_cfun(LC25,Cnil,&Cblock);
	funcall(2,VV[65]->s.s_gfdef,list(5,VV[43],VV[44],VALUES(0),VV[48],MAKE_FIXNUM(0)))/*  ADD-EFFECTIVE-METHOD-TEMPLATE-ENTRY*/;
	VALUES(0) = make_cfun(LC28,Cnil,&Cblock);
	funcall(2,VV[65]->s.s_gfdef,list(5,VV[49],VV[44],VALUES(0),VV[48],MAKE_FIXNUM(0)))/*  ADD-EFFECTIVE-METHOD-TEMPLATE-ENTRY*/;
	VALUES(0) = make_cfun(LC31,Cnil,&Cblock);
	funcall(2,VV[65]->s.s_gfdef,list(5,VV[51],VV[44],VALUES(0),VV[48],MAKE_FIXNUM(0)))/*  ADD-EFFECTIVE-METHOD-TEMPLATE-ENTRY*/;
	VALUES(0) = make_cfun(LC34,Cnil,&Cblock);
	funcall(2,VV[65]->s.s_gfdef,list(5,VV[53],VV[44],VALUES(0),VV[48],MAKE_FIXNUM(0)))/*  ADD-EFFECTIVE-METHOD-TEMPLATE-ENTRY*/;
	VALUES(0) = make_cfun(LC37,Cnil,&Cblock);
	funcall(2,VV[65]->s.s_gfdef,list(5,VV[55],VV[44],VALUES(0),VV[48],MAKE_FIXNUM(0)))/*  ADD-EFFECTIVE-METHOD-TEMPLATE-ENTRY*/;
	VALUES(0) = make_cfun(LC40,Cnil,&Cblock);
	funcall(2,VV[65]->s.s_gfdef,list(5,VV[56],VV[44],VALUES(0),VV[48],MAKE_FIXNUM(0)))/*  ADD-EFFECTIVE-METHOD-TEMPLATE-ENTRY*/;
	VALUES(0) = make_cfun(LC43,Cnil,&Cblock);
	funcall(2,VV[65]->s.s_gfdef,list(5,VV[57],VV[44],VALUES(0),VV[48],MAKE_FIXNUM(0)))/*  ADD-EFFECTIVE-METHOD-TEMPLATE-ENTRY*/;
	VALUES(0) = make_cfun(LC46,Cnil,&Cblock);
	funcall(2,VV[65]->s.s_gfdef,list(5,VV[58],VV[44],VALUES(0),VV[48],MAKE_FIXNUM(0)))/*  ADD-EFFECTIVE-METHOD-TEMPLATE-ENTRY*/;
	VALUES(0) = make_cfun(LC49,Cnil,&Cblock);
	funcall(2,VV[65]->s.s_gfdef,list(5,VV[59],VV[44],VALUES(0),VV[48],MAKE_FIXNUM(0)))/*  ADD-EFFECTIVE-METHOD-TEMPLATE-ENTRY*/;
	VALUES(0) = make_cfun(LC52,Cnil,&Cblock);
	funcall(2,VV[65]->s.s_gfdef,list(5,VV[60],VV[44],VALUES(0),VV[48],MAKE_FIXNUM(0)))/*  ADD-EFFECTIVE-METHOD-TEMPLATE-ENTRY*/;
	VALUES(0) = make_cfun(LC55,Cnil,&Cblock);
	funcall(2,VV[65]->s.s_gfdef,list(5,VV[61],VV[44],VALUES(0),VV[48],MAKE_FIXNUM(0)))/*  ADD-EFFECTIVE-METHOD-TEMPLATE-ENTRY*/;
	VALUES(0) = make_cfun(LC58,Cnil,&Cblock);
	funcall(2,VV[65]->s.s_gfdef,list(5,VV[62],VV[44],VALUES(0),VV[48],MAKE_FIXNUM(0)))/*  ADD-EFFECTIVE-METHOD-TEMPLATE-ENTRY*/;
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	local function CLOSURE                                        */
static LC58(int narg, object V1)
{ VT3 VLEX3 CLSR3
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  METHODS         */
	CLV1=&CAR(env0=CONS(Cnil,env0));
	CLV2=&CAR(env0=CONS(Cnil,env0));
	CLV3=&CAR(env0=CONS(Cnil,env0));
	CLV4=&CAR(env0=CONS(Cnil,env0));
	CLV5=&CAR(env0=CONS(Cnil,env0));
	CLV6=&CAR(env0=CONS(Cnil,env0));
	CLV7=&CAR(env0=CONS(Cnil,env0));
	CLV8=&CAR(env0=CONS(Cnil,env0));
	VALUES(0) = make_cclosure(LC56,env0,&Cblock);
	(*LK0)(3,(V1),Cnil,VALUES(0))             /*  SIMPLE-CODE-WALKER*/;
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV1= Cnil;
	goto L218;}
	T0=V2=CONS(Cnil,Cnil);
L219:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV1= T0;
	goto L218;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L219;}
L218:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV2= (V2);
	}
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV3= Cnil;
	goto L231;}
	T0=V2=CONS(Cnil,Cnil);
L232:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV3= T0;
	goto L231;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L232;}
L231:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV4= (V2);
	}
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV5= Cnil;
	goto L244;}
	T0=V2=CONS(Cnil,Cnil);
L245:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV5= T0;
	goto L244;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L245;}
L244:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV6= (V2);
	}
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV7= Cnil;
	goto L257;}
	T0=V2=CONS(Cnil,Cnil);
L258:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV7= T0;
	goto L257;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L258;}
L257:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV8= (V2);
	}
	VALUES(0) = make_cclosure(LC57,env0,&Cblock);
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC55(int narg, object V1)
{ VT4 VLEX4 CLSR4
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  METHODS         */
	CLV1=&CAR(env0=CONS(Cnil,env0));
	CLV2=&CAR(env0=CONS(Cnil,env0));
	CLV3=&CAR(env0=CONS(Cnil,env0));
	CLV4=&CAR(env0=CONS(Cnil,env0));
	CLV5=&CAR(env0=CONS(Cnil,env0));
	CLV6=&CAR(env0=CONS(Cnil,env0));
	VALUES(0) = make_cclosure(LC56,env0,&Cblock);
	(*LK0)(3,(V1),Cnil,VALUES(0))             /*  SIMPLE-CODE-WALKER*/;
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV1= Cnil;
	goto L272;}
	T0=V2=CONS(Cnil,Cnil);
L273:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV1= T0;
	goto L272;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L273;}
L272:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV2= (V2);
	}
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV3= Cnil;
	goto L285;}
	T0=V2=CONS(Cnil,Cnil);
L286:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV3= T0;
	goto L285;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L286;}
L285:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV4= (V2);
	}
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV5= Cnil;
	goto L298;}
	T0=V2=CONS(Cnil,Cnil);
L299:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV5= T0;
	goto L298;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L299;}
L298:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV6= (V2);
	}
	VALUES(0) = make_cclosure(LC54,env0,&Cblock);
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC52(int narg, object V1)
{ VT5 VLEX5 CLSR5
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  METHODS         */
	CLV1=&CAR(env0=CONS(Cnil,env0));
	CLV2=&CAR(env0=CONS(Cnil,env0));
	CLV3=&CAR(env0=CONS(Cnil,env0));
	CLV4=&CAR(env0=CONS(Cnil,env0));
	CLV5=&CAR(env0=CONS(Cnil,env0));
	CLV6=&CAR(env0=CONS(Cnil,env0));
	CLV7=&CAR(env0=CONS(Cnil,env0));
	CLV8=&CAR(env0=CONS(Cnil,env0));
	VALUES(0) = make_cclosure(LC56,env0,&Cblock);
	(*LK0)(3,(V1),Cnil,VALUES(0))             /*  SIMPLE-CODE-WALKER*/;
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV1= Cnil;
	goto L313;}
	T0=V2=CONS(Cnil,Cnil);
L314:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV1= T0;
	goto L313;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L314;}
L313:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV2= (V2);
	}
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV3= Cnil;
	goto L326;}
	T0=V2=CONS(Cnil,Cnil);
L327:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV3= T0;
	goto L326;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L327;}
L326:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV4= (V2);
	}
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV5= Cnil;
	goto L339;}
	T0=V2=CONS(Cnil,Cnil);
L340:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV5= T0;
	goto L339;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L340;}
L339:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV6= (V2);
	}
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV7= Cnil;
	goto L352;}
	T0=V2=CONS(Cnil,Cnil);
L353:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV7= T0;
	goto L352;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L353;}
L352:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV8= (V2);
	}
	VALUES(0) = make_cclosure(LC57,env0,&Cblock);
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC49(int narg, object V1)
{ VT6 VLEX6 CLSR6
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  METHODS         */
	CLV1=&CAR(env0=CONS(Cnil,env0));
	CLV2=&CAR(env0=CONS(Cnil,env0));
	CLV3=&CAR(env0=CONS(Cnil,env0));
	CLV4=&CAR(env0=CONS(Cnil,env0));
	CLV5=&CAR(env0=CONS(Cnil,env0));
	CLV6=&CAR(env0=CONS(Cnil,env0));
	CLV7=&CAR(env0=CONS(Cnil,env0));
	CLV8=&CAR(env0=CONS(Cnil,env0));
	VALUES(0) = make_cclosure(LC56,env0,&Cblock);
	(*LK0)(3,(V1),Cnil,VALUES(0))             /*  SIMPLE-CODE-WALKER*/;
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV1= Cnil;
	goto L367;}
	T0=V2=CONS(Cnil,Cnil);
L368:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV1= T0;
	goto L367;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L368;}
L367:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV2= (V2);
	}
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV3= Cnil;
	goto L380;}
	T0=V2=CONS(Cnil,Cnil);
L381:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV3= T0;
	goto L380;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L381;}
L380:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV4= (V2);
	}
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV5= Cnil;
	goto L393;}
	T0=V2=CONS(Cnil,Cnil);
L394:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV5= T0;
	goto L393;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L394;}
L393:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV6= (V2);
	}
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV7= Cnil;
	goto L406;}
	T0=V2=CONS(Cnil,Cnil);
L407:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV7= T0;
	goto L406;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L407;}
L406:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV8= (V2);
	}
	VALUES(0) = make_cclosure(LC48,env0,&Cblock);
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC46(int narg, object V1)
{ VT7 VLEX7 CLSR7
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  METHODS         */
	CLV1=&CAR(env0=CONS(Cnil,env0));
	CLV2=&CAR(env0=CONS(Cnil,env0));
	CLV3=&CAR(env0=CONS(Cnil,env0));
	CLV4=&CAR(env0=CONS(Cnil,env0));
	CLV5=&CAR(env0=CONS(Cnil,env0));
	CLV6=&CAR(env0=CONS(Cnil,env0));
	CLV7=&CAR(env0=CONS(Cnil,env0));
	CLV8=&CAR(env0=CONS(Cnil,env0));
	CLV9=&CAR(env0=CONS(Cnil,env0));
	CLV10=&CAR(env0=CONS(Cnil,env0));
	VALUES(0) = make_cclosure(LC56,env0,&Cblock);
	(*LK0)(3,(V1),Cnil,VALUES(0))             /*  SIMPLE-CODE-WALKER*/;
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV1= Cnil;
	goto L421;}
	T0=V2=CONS(Cnil,Cnil);
L422:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV1= T0;
	goto L421;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L422;}
L421:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV2= (V2);
	}
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV3= Cnil;
	goto L434;}
	T0=V2=CONS(Cnil,Cnil);
L435:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV3= T0;
	goto L434;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L435;}
L434:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV4= (V2);
	}
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV5= Cnil;
	goto L447;}
	T0=V2=CONS(Cnil,Cnil);
L448:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV5= T0;
	goto L447;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L448;}
L447:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV6= (V2);
	}
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV7= Cnil;
	goto L460;}
	T0=V2=CONS(Cnil,Cnil);
L461:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV7= T0;
	goto L460;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L461;}
L460:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV8= (V2);
	}
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV9= Cnil;
	goto L473;}
	T0=V2=CONS(Cnil,Cnil);
L474:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV9= T0;
	goto L473;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L474;}
L473:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV10= (V2);
	}
	VALUES(0) = make_cclosure(LC45,env0,&Cblock);
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC43(int narg, object V1)
{ VT8 VLEX8 CLSR8
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  METHODS         */
	CLV1=&CAR(env0=CONS(Cnil,env0));
	CLV2=&CAR(env0=CONS(Cnil,env0));
	CLV3=&CAR(env0=CONS(Cnil,env0));
	CLV4=&CAR(env0=CONS(Cnil,env0));
	VALUES(0) = make_cclosure(LC56,env0,&Cblock);
	(*LK0)(3,(V1),Cnil,VALUES(0))             /*  SIMPLE-CODE-WALKER*/;
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV1= Cnil;
	goto L488;}
	T0=V2=CONS(Cnil,Cnil);
L489:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV1= T0;
	goto L488;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L489;}
L488:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV2= (V2);
	}
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV3= Cnil;
	goto L501;}
	T0=V2=CONS(Cnil,Cnil);
L502:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV3= T0;
	goto L501;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L502;}
L501:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV4= (V2);
	}
	VALUES(0) = make_cclosure(LC42,env0,&Cblock);
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC40(int narg, object V1)
{ VT9 VLEX9 CLSR9
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  METHODS         */
	CLV1=&CAR(env0=CONS(Cnil,env0));
	CLV2=&CAR(env0=CONS(Cnil,env0));
	CLV3=&CAR(env0=CONS(Cnil,env0));
	CLV4=&CAR(env0=CONS(Cnil,env0));
	VALUES(0) = make_cclosure(LC56,env0,&Cblock);
	(*LK0)(3,(V1),Cnil,VALUES(0))             /*  SIMPLE-CODE-WALKER*/;
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV1= Cnil;
	goto L516;}
	T0=V2=CONS(Cnil,Cnil);
L517:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV1= T0;
	goto L516;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L517;}
L516:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV2= (V2);
	}
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV3= Cnil;
	goto L529;}
	T0=V2=CONS(Cnil,Cnil);
L530:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV3= T0;
	goto L529;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L530;}
L529:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV4= (V2);
	}
	VALUES(0) = make_cclosure(LC39,env0,&Cblock);
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC37(int narg, object V1)
{ VT10 VLEX10 CLSR10
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  METHODS         */
	CLV1=&CAR(env0=CONS(Cnil,env0));
	CLV2=&CAR(env0=CONS(Cnil,env0));
	CLV3=&CAR(env0=CONS(Cnil,env0));
	CLV4=&CAR(env0=CONS(Cnil,env0));
	CLV5=&CAR(env0=CONS(Cnil,env0));
	CLV6=&CAR(env0=CONS(Cnil,env0));
	VALUES(0) = make_cclosure(LC56,env0,&Cblock);
	(*LK0)(3,(V1),Cnil,VALUES(0))             /*  SIMPLE-CODE-WALKER*/;
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV1= Cnil;
	goto L544;}
	T0=V2=CONS(Cnil,Cnil);
L545:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV1= T0;
	goto L544;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L545;}
L544:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV2= (V2);
	}
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV3= Cnil;
	goto L557;}
	T0=V2=CONS(Cnil,Cnil);
L558:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV3= T0;
	goto L557;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L558;}
L557:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV4= (V2);
	}
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV5= Cnil;
	goto L570;}
	T0=V2=CONS(Cnil,Cnil);
L571:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV5= T0;
	goto L570;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L571;}
L570:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV6= (V2);
	}
	VALUES(0) = make_cclosure(LC36,env0,&Cblock);
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC34(int narg, object V1)
{ VT11 VLEX11 CLSR11
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  METHODS         */
	CLV1=&CAR(env0=CONS(Cnil,env0));
	CLV2=&CAR(env0=CONS(Cnil,env0));
	VALUES(0) = make_cclosure(LC56,env0,&Cblock);
	(*LK0)(3,(V1),Cnil,VALUES(0))             /*  SIMPLE-CODE-WALKER*/;
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV1= Cnil;
	goto L585;}
	T0=V2=CONS(Cnil,Cnil);
L586:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV1= T0;
	goto L585;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L586;}
L585:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV2= (V2);
	}
	VALUES(0) = make_cclosure(LC33,env0,&Cblock);
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC31(int narg, object V1)
{ VT12 VLEX12 CLSR12
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  METHODS         */
	CLV1=&CAR(env0=CONS(Cnil,env0));
	CLV2=&CAR(env0=CONS(Cnil,env0));
	VALUES(0) = make_cclosure(LC56,env0,&Cblock);
	(*LK0)(3,(V1),Cnil,VALUES(0))             /*  SIMPLE-CODE-WALKER*/;
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV1= Cnil;
	goto L600;}
	T0=V2=CONS(Cnil,Cnil);
L601:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV1= T0;
	goto L600;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L601;}
L600:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV2= (V2);
	}
	VALUES(0) = make_cclosure(LC30,env0,&Cblock);
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC28(int narg, object V1)
{ VT13 VLEX13 CLSR13
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  METHODS         */
	CLV1=&CAR(env0=CONS(Cnil,env0));
	CLV2=&CAR(env0=CONS(Cnil,env0));
	CLV3=&CAR(env0=CONS(Cnil,env0));
	CLV4=&CAR(env0=CONS(Cnil,env0));
	VALUES(0) = make_cclosure(LC56,env0,&Cblock);
	(*LK0)(3,(V1),Cnil,VALUES(0))             /*  SIMPLE-CODE-WALKER*/;
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV1= Cnil;
	goto L615;}
	T0=V2=CONS(Cnil,Cnil);
L616:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV1= T0;
	goto L615;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L616;}
L615:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV2= (V2);
	}
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV3= Cnil;
	goto L628;}
	T0=V2=CONS(Cnil,Cnil);
L629:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV3= T0;
	goto L628;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L629;}
L628:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV4= (V2);
	}
	VALUES(0) = make_cclosure(LC27,env0,&Cblock);
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC25(int narg, object V1)
{ VT14 VLEX14 CLSR14
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  METHODS         */
	CLV1=&CAR(env0=CONS(Cnil,env0));
	CLV2=&CAR(env0=CONS(Cnil,env0));
	VALUES(0) = make_cclosure(LC56,env0,&Cblock);
	(*LK0)(3,(V1),Cnil,VALUES(0))             /*  SIMPLE-CODE-WALKER*/;
	T1=VV[67]->s.s_gfdef;
	{object V4;
	V4= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	VALUES(0) = (V4);
	}
	{object V2;
	object V3= VALUES(0);
	if(V3==Cnil){
	*CLV1= Cnil;
	goto L643;}
	T0=V2=CONS(Cnil,Cnil);
L644:
	(*LK1)(1,CAR(V3))                         /*  CONVERT-EFFECTIVE-METHOD*/;
	CAR(V2)= VALUES(0);
	if((V3=CDR(V3))==Cnil){
	*CLV1= T0;
	goto L643;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L644;}
L643:
	{object V2;
	V2= CAR(*CLV0);
	*CLV0= CDR(*CLV0);
	*CLV2= (V2);
	}
	VALUES(0) = make_cclosure(LC24,env0,&Cblock);
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC4(int narg)
{ VT15 VLEX15 CLSR15
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	closure CLOSURE                                               */
static LC56(int narg, object env0, object V1, object V2, object V3)
{ VT16 VLEX16 CLSR16
	narg--;
	{object scan=env0; scan=CDR(scan); scan=CDR(scan); scan=CDR(scan); scan=CDR(scan); scan=CDR(scan); scan=CDR(scan); scan=CDR(scan); scan=CDR(scan);
	CLV0= &CAR(scan);                         /*  METHODS         */}
	if(!(((V2))==(VV[45]))){
	goto L657;}
	if(!(type_of((V1))==t_cons||(V1)==Cnil)){
	goto L657;}
	if(!((CAR((V1)))==(VV[46]))){
	goto L657;}
	(*LK2)(1,CADR((V1)))                      /*  GET-METHOD-FUNCTION*/;
	*CLV0= CONS(VALUES(0),*CLV0);
	*CLV0= CONS(CADDR((V1)),*CLV0);
	{frame_ptr fr; int V4;
	fr=frs_sch_catch((V1));
	if (fr==NULL) FEerror("The tag ~s is undefined.",1,(V1));
	VALUES(0)=(V1);
	V4=1;
	unwind(fr,(V1),V4+1);}
L657:
	VALUES(0) = (V1);
	RETURN(1);
}
/*	closure CLOSURE                                               */
static LC57(int narg, object env0, ...)
{ VT17 VLEX17 CLSR17
	narg--;
	{object scan=env0;
	CLV8= &CAR(scan); scan=CDR(scan);
	CLV7= &CAR(scan); scan=CDR(scan);
	CLV6= &CAR(scan); scan=CDR(scan);
	CLV5= &CAR(scan); scan=CDR(scan);
	CLV4= &CAR(scan); scan=CDR(scan);
	CLV3= &CAR(scan); scan=CDR(scan);
	CLV2= &CAR(scan); scan=CDR(scan);
	CLV1= &CAR(scan);}
	{register object V1;
	va_list args; va_start(args, env0);
	narg -=0;
	V1=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V1;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	bds_bind(VV[47],*CLV7);                   /*  *NEXT-METHODS*  */
	Lapply(2,*CLV8,(V1))                      /*  APPLY           */;
	bds_unwind1;
	{ int V2;
	bds_bind(VV[47],*CLV5);                   /*  *NEXT-METHODS*  */
	V2=Lapply(2,*CLV6,(V1))                   /*  APPLY           */;
	bds_unwind1;
	MV_SAVE(V2);
	bds_bind(VV[47],*CLV3);                   /*  *NEXT-METHODS*  */
	Lapply(2,*CLV4,(V1))                      /*  APPLY           */;
	bds_unwind1;
	bds_bind(VV[47],*CLV1);                   /*  *NEXT-METHODS*  */
	Lapply(2,*CLV2,(V1))                      /*  APPLY           */;
	bds_unwind1;
	MV_RESTORE(V2);
	RETURN(V2);}
	}
}
/*	closure CLOSURE                                               */
static LC54(int narg, object env0, ...)
{ VT18 VLEX18 CLSR18
	narg--;
	{object scan=env0;
	CLV6= &CAR(scan); scan=CDR(scan);
	CLV5= &CAR(scan); scan=CDR(scan);
	CLV4= &CAR(scan); scan=CDR(scan);
	CLV3= &CAR(scan); scan=CDR(scan);
	CLV2= &CAR(scan); scan=CDR(scan);
	CLV1= &CAR(scan);}
	{object V1;
	va_list args; va_start(args, env0);
	narg -=0;
	V1=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V1;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	bds_bind(VV[47],*CLV5);                   /*  *NEXT-METHODS*  */
	Lapply(2,*CLV6,(V1))                      /*  APPLY           */;
	bds_unwind1;
	bds_bind(VV[47],*CLV3);                   /*  *NEXT-METHODS*  */
	Lapply(2,*CLV4,(V1))                      /*  APPLY           */;
	bds_unwind1;
	{ int V2;
	bds_bind(VV[47],*CLV1);                   /*  *NEXT-METHODS*  */
	V2=Lapply(2,*CLV2,(V1))                   /*  APPLY           */;
	bds_unwind1;
	MV_SAVE(V2);
	MV_RESTORE(V2);
	RETURN(V2);}
	}
}
/*	closure CLOSURE                                               */
static LC48(int narg, object env0, ...)
{ VT19 VLEX19 CLSR19
	narg--;
	{object scan=env0;
	CLV8= &CAR(scan); scan=CDR(scan);
	CLV7= &CAR(scan); scan=CDR(scan);
	CLV6= &CAR(scan); scan=CDR(scan);
	CLV5= &CAR(scan); scan=CDR(scan);
	CLV4= &CAR(scan); scan=CDR(scan);
	CLV3= &CAR(scan); scan=CDR(scan);
	CLV2= &CAR(scan); scan=CDR(scan);
	CLV1= &CAR(scan);}
	{register object V1;
	va_list args; va_start(args, env0);
	narg -=0;
	V1=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V1;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	bds_bind(VV[47],*CLV7);                   /*  *NEXT-METHODS*  */
	Lapply(2,*CLV8,(V1))                      /*  APPLY           */;
	bds_unwind1;
	bds_bind(VV[47],*CLV5);                   /*  *NEXT-METHODS*  */
	Lapply(2,*CLV6,(V1))                      /*  APPLY           */;
	bds_unwind1;
	{ int V2;
	bds_bind(VV[47],*CLV3);                   /*  *NEXT-METHODS*  */
	V2=Lapply(2,*CLV4,(V1))                   /*  APPLY           */;
	bds_unwind1;
	MV_SAVE(V2);
	bds_bind(VV[47],*CLV1);                   /*  *NEXT-METHODS*  */
	Lapply(2,*CLV2,(V1))                      /*  APPLY           */;
	bds_unwind1;
	MV_RESTORE(V2);
	RETURN(V2);}
	}
}
/*	closure CLOSURE                                               */
static LC45(int narg, object env0, ...)
{ VT20 VLEX20 CLSR20
	narg--;
	{object scan=env0;
	CLV10= &CAR(scan); scan=CDR(scan);
	CLV9= &CAR(scan); scan=CDR(scan);
	CLV8= &CAR(scan); scan=CDR(scan);
	CLV7= &CAR(scan); scan=CDR(scan);
	CLV6= &CAR(scan); scan=CDR(scan);
	CLV5= &CAR(scan); scan=CDR(scan);
	CLV4= &CAR(scan); scan=CDR(scan);
	CLV3= &CAR(scan); scan=CDR(scan);
	CLV2= &CAR(scan); scan=CDR(scan);
	CLV1= &CAR(scan);}
	{register object V1;
	va_list args; va_start(args, env0);
	narg -=0;
	V1=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V1;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	bds_bind(VV[47],*CLV9);                   /*  *NEXT-METHODS*  */
	Lapply(2,*CLV10,(V1))                     /*  APPLY           */;
	bds_unwind1;
	bds_bind(VV[47],*CLV7);                   /*  *NEXT-METHODS*  */
	Lapply(2,*CLV8,(V1))                      /*  APPLY           */;
	bds_unwind1;
	{ int V2;
	bds_bind(VV[47],*CLV5);                   /*  *NEXT-METHODS*  */
	V2=Lapply(2,*CLV6,(V1))                   /*  APPLY           */;
	bds_unwind1;
	MV_SAVE(V2);
	bds_bind(VV[47],*CLV3);                   /*  *NEXT-METHODS*  */
	Lapply(2,*CLV4,(V1))                      /*  APPLY           */;
	bds_unwind1;
	bds_bind(VV[47],*CLV1);                   /*  *NEXT-METHODS*  */
	Lapply(2,*CLV2,(V1))                      /*  APPLY           */;
	bds_unwind1;
	MV_RESTORE(V2);
	RETURN(V2);}
	}
}
/*	closure CLOSURE                                               */
static LC42(int narg, object env0, ...)
{ VT21 VLEX21 CLSR21
	narg--;
	{object scan=env0;
	CLV4= &CAR(scan); scan=CDR(scan);
	CLV3= &CAR(scan); scan=CDR(scan);
	CLV2= &CAR(scan); scan=CDR(scan);
	CLV1= &CAR(scan);}
	{object V1;
	va_list args; va_start(args, env0);
	narg -=0;
	V1=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V1;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	bds_bind(VV[47],*CLV3);                   /*  *NEXT-METHODS*  */
	Lapply(2,*CLV4,(V1))                      /*  APPLY           */;
	bds_unwind1;
	{ int V2;
	bds_bind(VV[47],*CLV1);                   /*  *NEXT-METHODS*  */
	V2=Lapply(2,*CLV2,(V1))                   /*  APPLY           */;
	bds_unwind1;
	MV_SAVE(V2);
	MV_RESTORE(V2);
	RETURN(V2);}
	}
}
/*	closure CLOSURE                                               */
static LC39(int narg, object env0, ...)
{ VT22 VLEX22 CLSR22
	narg--;
	{object scan=env0;
	CLV4= &CAR(scan); scan=CDR(scan);
	CLV3= &CAR(scan); scan=CDR(scan);
	CLV2= &CAR(scan); scan=CDR(scan);
	CLV1= &CAR(scan);}
	{object V1;
	va_list args; va_start(args, env0);
	narg -=0;
	V1=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V1;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{ int V2;
	bds_bind(VV[47],*CLV3);                   /*  *NEXT-METHODS*  */
	V2=Lapply(2,*CLV4,(V1))                   /*  APPLY           */;
	bds_unwind1;
	MV_SAVE(V2);
	bds_bind(VV[47],*CLV1);                   /*  *NEXT-METHODS*  */
	Lapply(2,*CLV2,(V1))                      /*  APPLY           */;
	bds_unwind1;
	MV_RESTORE(V2);
	RETURN(V2);}
	}
}
/*	closure CLOSURE                                               */
static LC36(int narg, object env0, ...)
{ VT23 VLEX23 CLSR23
	narg--;
	{object scan=env0;
	CLV6= &CAR(scan); scan=CDR(scan);
	CLV5= &CAR(scan); scan=CDR(scan);
	CLV4= &CAR(scan); scan=CDR(scan);
	CLV3= &CAR(scan); scan=CDR(scan);
	CLV2= &CAR(scan); scan=CDR(scan);
	CLV1= &CAR(scan);}
	{object V1;
	va_list args; va_start(args, env0);
	narg -=0;
	V1=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V1;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	bds_bind(VV[47],*CLV5);                   /*  *NEXT-METHODS*  */
	Lapply(2,*CLV6,(V1))                      /*  APPLY           */;
	bds_unwind1;
	{ int V2;
	bds_bind(VV[47],*CLV3);                   /*  *NEXT-METHODS*  */
	V2=Lapply(2,*CLV4,(V1))                   /*  APPLY           */;
	bds_unwind1;
	MV_SAVE(V2);
	bds_bind(VV[47],*CLV1);                   /*  *NEXT-METHODS*  */
	Lapply(2,*CLV2,(V1))                      /*  APPLY           */;
	bds_unwind1;
	MV_RESTORE(V2);
	RETURN(V2);}
	}
}
/*	closure CLOSURE                                               */
static LC33(int narg, object env0, ...)
{ VT24 VLEX24 CLSR24
	narg--;
	{object scan=env0;
	CLV2= &CAR(scan); scan=CDR(scan);
	CLV1= &CAR(scan);}
	{object V1;
	va_list args; va_start(args, env0);
	narg -=0;
	V1=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V1;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{ int V2;
	V2=Lerror(1,VV[54])                       /*  ERROR           */;
	MV_SAVE(V2);
	bds_bind(VV[47],*CLV1);                   /*  *NEXT-METHODS*  */
	Lapply(2,*CLV2,(V1))                      /*  APPLY           */;
	bds_unwind1;
	MV_RESTORE(V2);
	RETURN(V2);}
	}
}
/*	closure CLOSURE                                               */
static LC30(int narg, object env0, ...)
{ VT25 VLEX25 CLSR25
	narg--;
	{object scan=env0;
	CLV2= &CAR(scan); scan=CDR(scan);
	CLV1= &CAR(scan);}
	{object V1;
	va_list args; va_start(args, env0);
	narg -=0;
	V1=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V1;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	bds_bind(VV[47],*CLV1);                   /*  *NEXT-METHODS*  */
	Lapply(2,*CLV2,(V1))                      /*  APPLY           */;
	bds_unwind1;
	{ int V2;
	V2=Lerror(1,VV[52])                       /*  ERROR           */;
	MV_SAVE(V2);
	MV_RESTORE(V2);
	RETURN(V2);}
	}
}
/*	closure CLOSURE                                               */
static LC27(int narg, object env0, ...)
{ VT26 VLEX26 CLSR26
	narg--;
	{object scan=env0;
	CLV4= &CAR(scan); scan=CDR(scan);
	CLV3= &CAR(scan); scan=CDR(scan);
	CLV2= &CAR(scan); scan=CDR(scan);
	CLV1= &CAR(scan);}
	{object V1;
	va_list args; va_start(args, env0);
	narg -=0;
	V1=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V1;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	bds_bind(VV[47],*CLV3);                   /*  *NEXT-METHODS*  */
	Lapply(2,*CLV4,(V1))                      /*  APPLY           */;
	bds_unwind1;
	{ int V2;
	V2=Lerror(1,VV[50])                       /*  ERROR           */;
	MV_SAVE(V2);
	bds_bind(VV[47],*CLV1);                   /*  *NEXT-METHODS*  */
	Lapply(2,*CLV2,(V1))                      /*  APPLY           */;
	bds_unwind1;
	MV_RESTORE(V2);
	RETURN(V2);}
	}
}
/*	closure CLOSURE                                               */
static LC24(int narg, object env0, ...)
{ VT27 VLEX27 CLSR27
	narg--;
	{object scan=env0;
	CLV2= &CAR(scan); scan=CDR(scan);
	CLV1= &CAR(scan);}
	{object V1;
	va_list args; va_start(args, env0);
	narg -=0;
	V1=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V1;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	bds_bind(VV[47],*CLV1);                   /*  *NEXT-METHODS*  */
	{int V2;
	V2=Lapply(2,*CLV2,(V1))                   /*  APPLY           */;
	bds_unwind1;
	RETURN(V2);}
	}
}
/*	macro definition for PRE-MAKE-CACHING-DISCRIMINATING-FUNCTIONS*/
static L1(int narg, object V1, object V2)
{ VT28 VLEX28 CLSR28
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	{object V5;
	object V6= (V4);
	if(V6==Cnil){
	VALUES(0) = Cnil;
	goto L703;}
	T0=V5=CONS(Cnil,Cnil);
L704:
	{object V7;                               /*  S               */
	CAR(V5)= listA(3,VV[1],VV[2],CAR(V6));
	}
	if((V6=CDR(V6))==Cnil){
	VALUES(0) = T0;
	goto L703;}
	V5=CDR(V5)=CONS(Cnil,Cnil);
	goto L704;}
L703:
	VALUES(0) = CONS(VV[0],VALUES(0));
	RETURN(1);}
}
/*	macro definition for PRE-MAKE-TEMPLATED-FUNCTION-CONSTRUCTOR  */
static L3(int narg, object V1, object V2)
{ VT29 VLEX29 CLSR29
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= V3;
	{object V6;                               /*  PARAMS          */
	object V7;                                /*  TEMPLATE-PARAMS */
	object V8;                                /*  INSTANCE-PARAMS */
	object V9;                                /*  BODY            */
	V6= getf((V4)->s.s_plist,VV[3],Cnil);
	V7= CAR((V6));
	V8= CADR((V6));
	V9= CDDR((V6));
	{object V11,V12;
	bds_ptr V10=bds_top;
	V11= (V7);
	V12= (V5);
	while(!endp(V11)) {
	if(endp(V12))bds_bind(CAR(V11),OBJNULL);
	else{bds_bind(CAR(V11),CAR(V12));
	V12=CDR(V12);}
	V11=CDR(V11);}
	{object V10= list(2,VV[8],(V5));
	{object V11= listA(4,VV[7],V10,list(3,VV[9],list(2,VV[8],(V4)),VV[10]),VV[11]);
	{object V12= CONS(list(2,VV[12],listA(3,VV[13],list(2,VV[8],(V5)),VV[14])),Cnil);
	{object V13= CONS(list(2,VV[5],list(3,VV[6],V11,list(4,VV[4],V12,list(3,VV[15],VV[12],list(3,VV[9],list(2,VV[8],(V4)),VV[16])),VV[12]))),Cnil);
	Leval(1,(V8))                             /*  EVAL            */;
	T0= VALUES(0);
	Leval(1,CONS(VV[0],(V9)))                 /*  EVAL            */;
	{int V14;
	VALUES(0)=list(4,VV[4],V13,VV[17],list(3,VV[18],VV[19],list(2,VV[20],list(3,VV[21],T0,VALUES(0)))));
	V14=1;
	bds_unwind(V10);
	RETURN(V14);}}}}}}
	}}
}
static LKF2(int narg, ...) {TRAMPOLINK(VV[68],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[67],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[66],&LK0);}
