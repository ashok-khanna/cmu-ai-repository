
#include "boot.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	VV[51] = make_cfun(LC2,Cnil,&Cblock);
	VV[52] = make_cfun(LC4,Cnil,&Cblock);
	init_keywords(1, L5keys, &Cblock);
	VV[53] = make_cfun(LC7,Cnil,&Cblock);
	VV[54] = make_cfun(LC8,Cnil,&Cblock);
	VV[55] = make_cfun(LC9,Cnil,&Cblock);
	VV[56] = make_cfun(LC10,Cnil,&Cblock);
	VV[57] = make_cfun(LC13,Cnil,&Cblock);
	VV[58] = make_cfun(LC14,Cnil,&Cblock);
	VV[59] = make_cfun(LC15,Cnil,&Cblock);
	VV[60] = make_cfun(LC16,Cnil,&Cblock);
	VV[61] = make_cfun(LC17,Cnil,&Cblock);
	MF0(VV[62],L1);
	(void)putprop(VV[62],VV[Vdeb62],VV[63]);
	L1(0)                                     /*  BOOT            */;
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	local function SLOT-UNBOUND                                   */
static LC17(int narg, object V1, object V2, object V3)
{ VT3 VLEX3 CLSR3
	RETURN(Lerror(3,VV[50],(V3),(V2))         /*  ERROR           */);
}
/*	local function CLOSURE                                        */
static LC16(int narg, object V1, object V2, object V3, object V4, ...)
{ VT4 VLEX4 CLSR4
	{int i=4;
	object V5;
	va_list args; va_start(args, V4);
	if (i==narg) goto L2;
	V5= va_arg(args, object);
	i++;
	goto L3;
L2:
	V5= Cnil;
L3:
	RETURN(Lerror(3,VV[46],(V3),(V2))         /*  ERROR           */);
	}
}
/*	local function INITIALIZE-INSTANCE                            */
static LC15(int narg, object V1, ...)
{ VT5 VLEX5 CLSR5
	{object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{ object keyvars[0];
	parse_key(narg,args,0,L15keys,keyvars,V2,TRUE);
	}
	(*LK0)(2,(V1),(V2))                       /*  INITIALIZE-FROM-INITARGS*/;
	(*LK1)(1,(V1))                            /*  INITIALIZE-FROM-INITFORMS*/;
	VALUES(0) = (V1);
	RETURN(1);
	}
}
/*	local function CLOSURE                                        */
static LC14(int narg, object V1, object V2)
{ VT6 VLEX6 CLSR6
	{register object V3;
	V3= (V2);
	if(!(numberp((VV[35]->s.s_dbind)))){
	goto L11;}
	bds_bind(VV[35],number_minus((VV[35]->s.s_dbind),MAKE_FIXNUM(1)));/*  *PRINT-LEVEL**/
	goto L9;
L11:
	bds_bind(VV[35],Cnil);                    /*  *PRINT-LEVEL*   */
L9:
	princ(VV[36],(V3));
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	Lformat(4,(V2),VV[37],(VALUES(0))->in.in_slots[0],((V1))->in.in_slots[0])/*  FORMAT*/;
	princ(VV[38],(V3));
	siLaddress(1,(V1))                        /*  POINTER         */;
	Lformat(3,(V3),VV[39],VALUES(0))          /*  FORMAT          */;
	T0= princ(VV[40],(V3));
	bds_unwind1;
	T0= T0;
	}
	VALUES(0) = (V1);
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC13(int narg, object V1, ...)
{ VT7 VLEX7 CLSR7
	{object V2;
	va_list args; va_start(args, V1);
	lex0[0]=V1;
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	lex0[1]=V2;
	{object V3;
	object V4;
	V3= CAR((VV[16]->s.s_dbind));
	V4= CDR((VV[16]->s.s_dbind));
	lex0[2]=V3;                               /*  .NEXT-METHOD.   */
	bds_bind(VV[16],V4);                      /*  *NEXT-METHODS*  */
	{ int V5, i=0;
	T0= lex0[0];
	T1= lex0[1];
	V5=length(T1);
	VALUES(i++)=T0;
	V5+=i;
	for (; i<V5;i++,T1=CDR(T1))
		VALUES(i)=CAR(T1);
	{ 
	object *args = &VALUES(1);
	object V6;
	int narg = V5;
	V6=VALUES(0);
	narg -=1;
	{ object keyvars[0];
	parse_key(narg,args,0,L11keys,keyvars,OBJNULL,TRUE);
	}
	LC12(lex0,0)                              /*  CALL-NEXT-METHOD*/;
	if(!((((V6))->in.in_slots[0])!=OBJNULL)){
	goto L24;}
	(*LK2)(2,((V6))->in.in_slots[0],(V6))     /*  SETF-FIND-CLASS */;
L24:
	{register object V7;
	object V8;                                /*  S               */
	V7= ((V6))->in.in_slots[1];
	V8= Cnil;
L31:
	if(!((V7)==Cnil)){
	goto L32;}
	goto L27;
L32:
	V8= CAR((V7));
	{int V10;
	V10= 2;
	siLinstance_ref(2,(V8),MAKE_FIXNUM(V10))  /*  INSTANCE-REF    */;
	siLinstance_set(3,(V8),MAKE_FIXNUM(V10),CONS((V6),VALUES(0)))/*  INSTANCE-SET*/;
	}
	V7= CDR((V7));
	goto L31;
	}
L27:
	{int V7;
	VALUES(0)=(V6);
	V7=1;
	bds_unwind1;
	RETURN(V7);}
	}
	}
	}
	}
}
/*	local function CLOSURE                                        */
static LC10(int narg, object V1, ...)
{ VT8 VLEX8 CLSR8
	RETURN(Lerror(2,VV[28],(V1))              /*  ERROR           */);
}
/*	local function CLOSURE                                        */
static LC9(int narg, object V1, object V2)
{ VT9 VLEX9 CLSR9
	{object V3;                               /*  POSITION        */
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	T0= (VALUES(0))->in.in_slots[3];
	VALUES(0) = (VV[67]->s.s_gfdef);
	(*LK3)(4,(V2),T0,VV[25],VALUES(0))        /*  POSITION        */;
	V3= VALUES(0);
	if(((V3))==Cnil){
	goto L48;}
	RETURN(siLinstance_ref(2,(V1),(V3))       /*  INSTANCE-REF    */);
L48:
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	RETURN((*LK4)(4,VALUES(0),(V1),(V2),VV[22])/*  SLOT-MISSING   */);
	}
}
/*	local function CLOSURE                                        */
static LC8(int narg, object V1, object V2)
{ VT10 VLEX10 CLSR10
	{object V3;
	if(((V2))==Cnil){
	goto L52;}
	VALUES(0) = (V2);
	RETURN(1);
L52:
	(*LK5)(1,Ct)                              /*  FIND-CLASS      */;
	VALUES(0) = CONS(VALUES(0),Cnil);
	RETURN(1);
	}
}
/*	local function CLOSURE                                        */
static LC7(int narg, object V1, ...)
{ VT11 VLEX11 CLSR11
	{object V2;
	va_list args; va_start(args, V1);
	lex0[0]=V1;
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	lex0[1]=V2;
	{object V3;
	object V4;
	V3= CAR((VV[16]->s.s_dbind));
	V4= CDR((VV[16]->s.s_dbind));
	lex0[2]=V3;                               /*  .NEXT-METHOD.   */
	bds_bind(VV[16],V4);                      /*  *NEXT-METHODS*  */
	{ int V5, i=0;
	T0= lex0[0];
	T1= lex0[1];
	V5=length(T1);
	VALUES(i++)=T0;
	V5+=i;
	for (; i<V5;i++,T1=CDR(T1))
		VALUES(i)=CAR(T1);
	{ 
	object *args = &VALUES(1);
	object V6;
	int narg = V5;
	V6=VALUES(0);
	{object V7;
	narg -=1;
	{ object keyvars[2];
	parse_key(narg,args,1,L5keys,keyvars,OBJNULL,TRUE);
	V7= keyvars[0];
	}
	LC12(lex0,0)                              /*  CALL-NEXT-METHOD*/;
	if(((V7))!=Cnil){
	goto L60;}
	(*LK6)(2,(V6),(V7))                       /*  CLASS-DEFAULT-DIRECT-SUPERCLASSES*/;
	siLinstance_set(3,(V6),MAKE_FIXNUM(1),VALUES(0))/*  INSTANCE-SET*/;
L60:
	if(!((((V6))->in.in_slots[0])!=OBJNULL)){
	goto L64;}
	(*LK2)(2,((V6))->in.in_slots[0],(V6))     /*  SETF-FIND-CLASS */;
L64:
	{register object V8;
	object V9;                                /*  S               */
	V8= ((V6))->in.in_slots[1];
	V9= Cnil;
L71:
	if(!((V8)==Cnil)){
	goto L72;}
	goto L67;
L72:
	V9= CAR((V8));
	{int V11;
	V11= 2;
	siLinstance_ref(2,(V9),MAKE_FIXNUM(V11))  /*  INSTANCE-REF    */;
	siLinstance_set(3,(V9),MAKE_FIXNUM(V11),CONS((V6),VALUES(0)))/*  INSTANCE-SET*/;
	}
	V8= CDR((V8));
	goto L71;
	}
L67:
	{int V8;
	VALUES(0)=(V6);
	V8=1;
	bds_unwind1;
	RETURN(V8);}
	}
	}
	}
	}
	}
}
/*	local function CLOSURE                                        */
static LC4(int narg, object V1, ...)
{ VT12 VLEX12 CLSR12
	{object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{object V3;                               /*  INSTANCE        */
	(*LK7)(1,(V1))                            /*  ALLOCATE-INSTANCE*/;
	V3= VALUES(0);
	VALUES(0) = (VV[12]->s.s_gfdef);
	Lapply(3,VALUES(0),(V3),(V2))             /*  APPLY           */;
	VALUES(0) = (V3);
	RETURN(1);
	}
	}
}
/*	local function CLOSURE                                        */
static LC2(int narg, object V1, object V2)
{ VT13 VLEX13 CLSR13
	VALUES(0) = (V2);
	RETURN(1);
}
/*	local function CALL-NEXT-METHOD                               */
static LC12(object *lex0,int narg, ...)
{ VT14 VLEX14 CLSR14
	{object V1;
	va_list args; va_start(args, narg);
	narg -=0;
	V1=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V1;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	if((lex0[2])==Cnil){
	goto L87;}
	if(((V1))==Cnil){
	goto L90;}
	RETURN(Lapply(2,lex0[2],(V1))             /*  APPLY           */);
L90:
	RETURN(Lapply(3,lex0[2],lex0[0],lex0[1])  /*  APPLY           */);
L87:
	RETURN(Lerror(1,VV[17])                   /*  ERROR           */);
	}
}
/*	function definition for BOOT                                  */
static L1(int narg)
{ VT15 VLEX15 CLSR15
	bds_check;
TTL:
	{object V1;                               /*  CLASS           */
	object V2;
	object V3;                                /*  BUILT-IN        */
	(*LK5)(1,VV[0])                           /*  FIND-CLASS      */;
	V2= VALUES(0);
	(*LK5)(1,VV[1])                           /*  FIND-CLASS      */;
	V3= VALUES(0);
	V1= V2;
	(*LK8)(1,VV[2])                           /*  PARSE-CLASS-SLOTS*/;
	siLinstance_set(3,(V1),MAKE_FIXNUM(3),VALUES(0))/*  INSTANCE-SET*/;
	VALUES(0) = VV[51];
	(*LK9)(7,VV[3],Cnil,VV[4],VV[5],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VALUES(0) = VV[51];
	(*LK9)(7,VV[6],Cnil,VV[7],VV[8],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VALUES(0) = VV[52];
	(*LK9)(7,VV[9],Cnil,VV[10],VV[11],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VALUES(0) = VV[53];
	(*LK9)(7,VV[12],Cnil,VV[13],VV[14],Cnil,VV[15],VALUES(0))/*  INSTALL-METHOD*/;
	VALUES(0) = VV[54];
	(*LK9)(7,VV[18],Cnil,VV[19],VV[20],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	(*LK8)(1,VV[21])                          /*  PARSE-CLASS-SLOTS*/;
	siLinstance_set(3,(V3),MAKE_FIXNUM(3),VALUES(0))/*  INSTANCE-SET*/;
	VALUES(0) = VV[55];
	(*LK9)(7,VV[22],Cnil,VV[23],VV[24],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VALUES(0) = VV[56];
	(*LK9)(7,VV[9],Cnil,VV[26],VV[27],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VALUES(0) = VV[57];
	(*LK9)(7,VV[12],Cnil,VV[29],VV[30],Cnil,VV[31],VALUES(0))/*  INSTALL-METHOD*/;
	VALUES(0) = VV[58];
	(*LK9)(7,VV[32],Cnil,VV[33],VV[34],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VALUES(0) = VV[59];
	(*LK9)(7,VV[12],Cnil,VV[41],VV[42],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VALUES(0) = VV[60];
	(*LK9)(7,VV[43],Cnil,VV[44],VV[45],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VALUES(0) = VV[61];
	RETURN((*LK9)(7,VV[47],Cnil,VV[48],VV[49],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/);
	}
}
static LKF9(int narg, ...) {TRAMPOLINK(VV[73],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[72],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[71],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[18],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[69],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[43],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[68],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[66],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[65],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[64],&LK0);}
