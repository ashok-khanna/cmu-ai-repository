
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "cmptop.h"
init_cmptop(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_cmptop; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	VV[0]->s.s_stype=(short)stp_special;
	if(VV[0]->s.s_dbind == OBJNULL){
	(VV[0]->s.s_dbind)= Cnil;}
	VV[1]->s.s_stype=(short)stp_special;
	if(VV[1]->s.s_dbind == OBJNULL){
	(VV[1]->s.s_dbind)= Cnil;}
	VV[2]->s.s_stype=(short)stp_special;
	if(VV[2]->s.s_dbind == OBJNULL){
	(VV[2]->s.s_dbind)= Cnil;}
	VV[3]->s.s_stype=(short)stp_special;
	if(VV[3]->s.s_dbind == OBJNULL){
	(VV[3]->s.s_dbind)= Cnil;}
	VV[4]->s.s_stype=(short)stp_special;
	VV[5]->s.s_stype=(short)stp_special;
	if(VV[5]->s.s_dbind == OBJNULL){
	(VV[5]->s.s_dbind)= MAKE_FIXNUM(5);}
	VV[6]->s.s_stype=(short)stp_special;
	if(VV[6]->s.s_dbind == OBJNULL){
	(VV[6]->s.s_dbind)= MAKE_FIXNUM(6);}
	VV[7]->s.s_stype=(short)stp_special;
	VV[8]->s.s_stype=(short)stp_special;
	if(VV[8]->s.s_dbind == OBJNULL){
	(VV[8]->s.s_dbind)= MAKE_FIXNUM(0);}
	VV[9]->s.s_stype=(short)stp_special;
	if(VV[9]->s.s_dbind == OBJNULL){
	(VV[9]->s.s_dbind)= Cnil;}
	VV[10]->s.s_stype=(short)stp_special;
	if(VV[10]->s.s_dbind == OBJNULL){
	(VV[10]->s.s_dbind)= Cnil;}
	VV[11]->s.s_stype=(short)stp_special;
	if(VV[11]->s.s_dbind == OBJNULL){
	(VV[11]->s.s_dbind)= Cnil;}
	VV[12]->s.s_stype=(short)stp_special;
	if(VV[12]->s.s_dbind == OBJNULL){
	(VV[12]->s.s_dbind)= Cnil;}
	VV[13]->s.s_stype=(short)stp_special;
	if(VV[13]->s.s_dbind == OBJNULL){
	(VV[13]->s.s_dbind)= Cnil;}
	VV[14]->s.s_stype=(short)stp_special;
	if(VV[14]->s.s_dbind == OBJNULL){
	(VV[14]->s.s_dbind)= Cnil;}
	VV[15]->s.s_stype=(short)stp_special;
	if(VV[15]->s.s_dbind == OBJNULL){
	(VV[15]->s.s_dbind)= Cnil;}
	VV[16]->s.s_stype=(short)stp_special;
	if(VV[16]->s.s_dbind == OBJNULL){
	(VV[16]->s.s_dbind)= Cnil;}
	VV[17]->s.s_stype=(short)stp_special;
	if(VV[17]->s.s_dbind == OBJNULL){
	(VV[17]->s.s_dbind)= Cnil;}
	VV[18]->s.s_stype=(short)stp_special;
	if(VV[18]->s.s_dbind == OBJNULL){
	(VV[18]->s.s_dbind)= Cnil;}
	VV[19]->s.s_stype=(short)stp_special;
	if(VV[19]->s.s_dbind == OBJNULL){
	(VV[19]->s.s_dbind)= Cnil;}
	putprop(VV[20],Ct,VV[21]);
	putprop(VV[22],Ct,VV[21]);
	putprop(VV[23],Ct,VV[21]);
	putprop(VV[24],Ct,VV[21]);
	putprop(VV[25],Ct,VV[21]);
	putprop(VV[26],Ct,VV[21]);
	putprop(VV[27],Ct,VV[21]);
	putprop(VV[28],Ct,VV[21]);
	putprop(VV[29],Ct,VV[21]);
	putprop(VV[30],Ct,VV[21]);
	putprop(VV[31],Ct,VV[21]);
	putprop(VV[32],Ct,VV[33]);
	putprop(VV[34],Ct,VV[33]);
	putprop(VV[35],Ct,VV[33]);
	VV[38]=string_to_object(VV[38]);
	MF0(VV[239],L1);
	MF0(VV[240],L2);
	MF0(VV[241],L4);
	MF0(VV[242],L5);
	MF0(VV[243],L6);
	MF0(VV[244],L7);
	MF0(VV[245],L9);
	MF0(VV[246],L10);
	MF0(VV[247],L11);
	MF0(VV[248],L12);
	MF0(VV[249],L13);
	MF0(VV[250],L14);
	MF0(VV[251],L15);
	MF0(VV[252],L16);
	MF0(VV[253],L17);
	MF0(VV[254],L18);
	MF0(VV[255],L21);
	MF0(VV[256],L23);
	MF0(VV[257],L24);
	MF0(VV[258],L25);
	MF0(VV[259],L26);
	MF0(VV[260],L27);
	MF0(VV[261],L28);
	MF0(VV[262],L29);
	MF0(VV[263],L30);
	MF0(VV[264],L31);
	MF0(VV[265],L32);
	MF0(VV[266],L33);
	MF0(VV[267],L34);
	MF0(VV[218],L35);
	MF0(VV[234],L36);
	MF0(VV[268],L37);
	VV[269] = make_cfun(LC39,Cnil,&Cblock);
	MF0(VV[270],L38);
	MF0(VV[224],L40);
	MF0(VV[228],L41);
	MF0(VV[237],L42);
	MF0(VV[231],L45);
	MF0(VV[233],L46);
	VALUES(0) = (VV[242]->s.s_gfdef);
	putprop(VV[74],VALUES(0),VV[42]);
	VALUES(0) = (VV[241]->s.s_gfdef);
	putprop(VV[68],VALUES(0),VV[42]);
	VALUES(0) = (VV[243]->s.s_gfdef);
	putprop(VV[73],VALUES(0),VV[42]);
	VALUES(0) = (VV[244]->s.s_gfdef);
	putprop(VV[77],VALUES(0),VV[42]);
	VALUES(0) = (VV[258]->s.s_gfdef);
	putprop(VV[167],VALUES(0),VV[42]);
	VALUES(0) = (VV[266]->s.s_gfdef);
	putprop(VV[181],VALUES(0),VV[42]);
	putprop(VV[189],VV[218],VV[42]);
	putprop(VV[219],VV[220],VV[42]);
	putprop(VV[206],VV[221],VV[42]);
	putprop(VV[222],VV[223],VV[42]);
	putprop(VV[208],VV[224],VV[42]);
	putprop(VV[225],VV[226],VV[42]);
	VALUES(0) = (VV[250]->s.s_gfdef);
	putprop(VV[77],VALUES(0),VV[63]);
	VALUES(0) = (VV[259]->s.s_gfdef);
	putprop(VV[167],VALUES(0),VV[63]);
	VALUES(0) = (VV[262]->s.s_gfdef);
	putprop(VV[177],VALUES(0),VV[63]);
	VALUES(0) = (VV[265]->s.s_gfdef);
	putprop(VV[182],VALUES(0),VV[63]);
	VALUES(0) = (VV[264]->s.s_gfdef);
	putprop(VV[180],VALUES(0),VV[63]);
	VALUES(0) = (VV[267]->s.s_gfdef);
	putprop(VV[181],VALUES(0),VV[63]);
	putprop(VV[206],VV[227],VV[63]);
	putprop(VV[208],VV[228],VV[63]);
	putprop(VV[225],VV[229],VV[63]);
	putprop(VV[230],VV[231],VV[63]);
	putprop(VV[232],VV[233],VV[63]);
	VALUES(0) = (VV[251]->s.s_gfdef);
	putprop(VV[77],VALUES(0),VV[65]);
	VALUES(0) = (VV[260]->s.s_gfdef);
	putprop(VV[167],VALUES(0),VV[65]);
	putprop(VV[189],VV[234],VV[65]);
	putprop(VV[219],VV[235],VV[65]);
	putprop(VV[206],VV[236],VV[65]);
	putprop(VV[208],VV[237],VV[65]);
	putprop(VV[225],VV[238],VV[65]);
}
/*	local function CLOSURE                                        */
static LC39(int narg, object V1)
{ VT3 VLEX3 CLSR3
	if(!((((V1))->v.v_self[2])==Cnil)){
	goto L77;}
	VALUES(0) = Ct;
	RETURN(1);
L77:
	VALUES(0) = ((((V1))->v.v_self[5])==(VV[190])?Ct:Cnil);
	RETURN(1);
}
/*	function definition for T1EXPR                                */
static L1(int narg, object V1)
{ VT4 VLEX4 CLSR4
	bds_check;
TTL:
	bds_bind(VV[36],(V1));                    /*  *CURRENT-FORM*  */
	bds_bind(VV[37],Ct);                      /*  *FIRST-ERROR*   */
	bds_bind(VV[4],Cnil);                     /*  *FUNARG-VARS*   */
	{ int V2;
	if ((V2=frs_push(FRS_CATCH,VV[38]))==0) {
	if(!(type_of((V1))==t_cons)){
	goto L82;}
	{register object V3;                      /*  FUN             */
	object V4;                                /*  ARGS            */
	register object V5;                       /*  FD              */
	register object V6;                       /*  SETF-SYMBOL     */
	V3= CAR((V1));
	V4= CDR((V1));
	V5= Cnil;
	V6= Cnil;
	if(!(type_of((V3))==t_symbol)){
	goto L87;}
	if(!(((V3))==(VV[39]))){
	goto L90;}
	V2=(*LK0)(1,VV[40])                       /*  CMPERR          */;
	goto L80;
L90:
	if((getf((V3)->s.s_plist,VV[21],Cnil))==Cnil){
	goto L93;}
	if(((VV[16]->s.s_dbind))==Cnil){
	goto L95;}
	(*LK1)(2,VV[41],(V1))                     /*  CMPWARN         */;
L95:
	(*LK2)(1,(V1))                            /*  CMP-EVAL        */;
	V2=(*LK3)(1,(V1))                         /*  WT-DATA-PACKAGE-OPERATION*/;
	goto L80;
L93:
	V5= getf((V3)->s.s_plist,VV[42],Cnil);
	if(((V5))==Cnil){
	goto L100;}
	if(((VV[43]->s.s_dbind))==Cnil){
	goto L103;}
	(*LK4)(0)                                 /*  PRINT-CURRENT-FORM*/;
L103:
	V2=funcall(2,(V5),(V4));
	goto L80;
L100:
	if((getf((V3)->s.s_plist,VV[33],Cnil))==Cnil){
	goto L107;}
	if(((VV[43]->s.s_dbind))==Cnil){
	goto L109;}
	(*LK4)(0)                                 /*  PRINT-CURRENT-FORM*/;
L109:
	bds_bind(VV[13],Ct);                      /*  *COMPILE-TIME-TOO**/
	(*LK5)(1,(V1))                            /*  CMP-MACROEXPAND-1*/;
	V2=L1(1,VALUES(0))                        /*  T1EXPR          */;
	bds_unwind1;
	goto L80;
L107:
	if((getf((V3)->s.s_plist,VV[44],Cnil))==Cnil){
	goto L114;}
	V2=L28(1,(V1))                            /*  T1ORDINARY      */;
	goto L80;
L114:
	Lmacro_function(1,(V3))                   /*  MACRO-FUNCTION  */;
	V5= VALUES(0);
	if(((V5))==Cnil){
	goto L117;}
	(*LK6)(3,(V5),(V3),CDR((V1)))             /*  CMP-EXPAND-MACRO*/;
	V2=L1(1,VALUES(0))                        /*  T1EXPR          */;
	goto L80;
L117:
	V2=L28(1,(V1))                            /*  T1ORDINARY      */;
	goto L80;
L87:
	{object V7;                               /*  SETF-SYMBOL     */
	V7= Cnil;
	if(type_of((V3))==t_cons){
	goto L125;}
	V6= Cnil;
	goto L124;
L125:
	if((2)==(length((V3)))){
	goto L127;}
	V6= Cnil;
	goto L124;
L127:
	if((CAR((V3)))==(VV[45])){
	goto L129;}
	V6= Cnil;
	goto L124;
L129:
	V7= getf(CADR((V3))->s.s_plist,VV[46],Cnil);
	if(((V7))!=Cnil){
	goto L131;}
	V6= Cnil;
	goto L124;
L131:
	if(type_of((V7))==t_symbol){
	goto L134;}
	V6= Cnil;
	goto L124;
L134:
	V6= (V7);
	}
L124:
	if(((V6))==Cnil){
	goto L122;}
	if(!(((V6))==(VV[39]))){
	goto L137;}
	V2=(*LK0)(1,VV[47])                       /*  CMPERR          */;
	goto L80;
L137:
	if((getf((V6)->s.s_plist,VV[21],Cnil))==Cnil){
	goto L140;}
	if(((VV[16]->s.s_dbind))==Cnil){
	goto L142;}
	(*LK1)(2,VV[48],(V1))                     /*  CMPWARN         */;
L142:
	(*LK2)(1,(V1))                            /*  CMP-EVAL        */;
	V2=(*LK3)(1,(V1))                         /*  WT-DATA-PACKAGE-OPERATION*/;
	goto L80;
L140:
	V5= getf((V6)->s.s_plist,VV[42],Cnil);
	if(((V5))==Cnil){
	goto L147;}
	if(((VV[43]->s.s_dbind))==Cnil){
	goto L150;}
	(*LK4)(0)                                 /*  PRINT-CURRENT-FORM*/;
L150:
	V2=funcall(2,(V5),(V4));
	goto L80;
L147:
	if((getf((V6)->s.s_plist,VV[33],Cnil))==Cnil){
	goto L154;}
	if(((VV[43]->s.s_dbind))==Cnil){
	goto L156;}
	(*LK4)(0)                                 /*  PRINT-CURRENT-FORM*/;
L156:
	bds_bind(VV[13],Ct);                      /*  *COMPILE-TIME-TOO**/
	(*LK5)(1,(V1))                            /*  CMP-MACROEXPAND-1*/;
	V2=L1(1,VALUES(0))                        /*  T1EXPR          */;
	bds_unwind1;
	goto L80;
L154:
	if((getf((V6)->s.s_plist,VV[44],Cnil))==Cnil){
	goto L161;}
	V2=L28(1,(V1))                            /*  T1ORDINARY      */;
	goto L80;
L161:
	Lmacro_function(1,(V6))                   /*  MACRO-FUNCTION  */;
	V5= VALUES(0);
	if(((V5))==Cnil){
	goto L164;}
	(*LK6)(3,(V5),(V6),CDR((V1)))             /*  CMP-EXPAND-MACRO*/;
	V2=L1(1,VALUES(0))                        /*  T1EXPR          */;
	goto L80;
L164:
	V2=L28(1,(V1))                            /*  T1ORDINARY      */;
	goto L80;
L122:
	if(!(type_of((V3))==t_cons)){
	goto L169;}
	V2=L28(1,(V1))                            /*  T1ORDINARY      */;
	goto L80;
L169:
	V2=(*LK0)(2,VV[49],(V3))                  /*  CMPERR          */;
	goto L80;
	}
L82:
	VALUES(0)=Cnil;
	V2=1;
L80:
	}
	else V2--;
	frs_pop();
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V2);}
}
/*	function definition for CTOP-WRITE                            */
static L2(int narg, object V1, ...)
{ VT5 VLEX5 CLSR5
	bds_check;
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if (i==narg) goto L171;
	V2= va_arg(args, object);
	i++;
	goto L172;
L171:
	V2= Cnil;
L172:
	{object V3;                               /*  VV-RESERVATION  */
	register object V4;                       /*  DEF             */
	(VV[50]->s.s_dbind)= number_plus((VV[50]->s.s_dbind),MAKE_FIXNUM(1));
	V3= (VV[50]->s.s_dbind);
	V4= Cnil;
	bds_bind(VV[7],VV[51]);                   /*  *VOLATILE*      */
	(VV[15]->s.s_dbind)= nreverse((VV[15]->s.s_dbind));
	{object V5;
	(VV[50]->s.s_dbind)= number_plus((VV[50]->s.s_dbind),MAKE_FIXNUM(1));
	V5= (VV[50]->s.s_dbind);
	bds_bind(VV[52],MAKE_FIXNUM(0));          /*  *LCL*           */
	bds_bind(VV[53],MAKE_FIXNUM(0));          /*  *LEX*           */
	bds_bind(VV[54],MAKE_FIXNUM(0));          /*  *MAX-LEX*       */
	bds_bind(VV[55],MAKE_FIXNUM(0));          /*  *MAX-ENV*       */
	bds_bind(VV[56],MAKE_FIXNUM(0));          /*  *MAX-TEMP*      */
	bds_bind(VV[57],Cnil);                    /*  *UNBOXED*       */
	bds_bind(VV[18],V5);                      /*  *RESERVATION-CMACRO**/
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_str("init_",symbol_value(VV[58]));
	(*LK7)(1,(V1))                            /*  WT1             */;
	princ_str("(int size, object data_stream)",symbol_value(VV[58]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(123,symbol_value(VV[58]));
	princ_str("VT",symbol_value(VV[58]));
	(*LK7)(1,(VV[18]->s.s_dbind))             /*  WT1             */;
	princ_str(" CLSR",symbol_value(VV[58]));
	(*LK7)(1,(VV[18]->s.s_dbind))             /*  WT1             */;
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("volatile object VVprotect;",symbol_value(VV[58]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("Cblock.cd_start=(char *)init_",symbol_value(VV[58]));
	(*LK7)(1,(V1))                            /*  WT1             */;
	princ_str("; Cblock.cd_size=size;",symbol_value(VV[58]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("VVprotect=Cblock.cd_data=read_VV(VV,VM",symbol_value(VV[58]));
	(*LK7)(1,(V3))                            /*  WT1             */;
	princ_str(",data_stream);",symbol_value(VV[58]));
	bds_bind(VV[59],Cnil);                    /*  *COMPILE-TO-LINKING-CALL**/
	{register object V6;
	object V7;                                /*  FORM            */
	V6= (VV[15]->s.s_dbind);
	V7= Cnil;
L214:
	if(!((V6)==Cnil)){
	goto L215;}
	bds_unwind1;
	goto L210;
L215:
	V7= CAR((V6));
	bds_bind(VV[60],MAKE_FIXNUM(0));          /*  *ENV*           */
	bds_bind(VV[61],MAKE_FIXNUM(0));          /*  *LEVEL*         */
	bds_bind(VV[62],MAKE_FIXNUM(0));          /*  *TEMP*          */
	V4= getf(CAR((V7))->s.s_plist,VV[63],Cnil);
	if(((V4))==Cnil){
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	goto L220;}
	Lapply(2,(V4),CDR((V7)))                  /*  APPLY           */;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
L220:
	V6= CDR((V6));
	goto L214;
	}
L210:
	L17(0)                                    /*  WT-FUNCTION-EPILOGUE*/;
	if(((V2))!=Cnil){
	goto L228;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("Cblock.cd_start=(char *)end_init;",symbol_value(VV[58]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("Cblock.cd_size-=(char *)end_init - (char *)init_",symbol_value(VV[58]));
	(*LK7)(1,(V1))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[58]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("insert_contblock((char *)init_",symbol_value(VV[58]));
	(*LK7)(1,(V1))                            /*  WT1             */;
	princ_str(",(char *)end_init - (char *)init_",symbol_value(VV[58]));
	(*LK7)(1,(V1))                            /*  WT1             */;
	princ_str(");",symbol_value(VV[58]));
L228:
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(125,symbol_value(VV[58]));
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	}
	if(((V2))!=Cnil){
	goto L250;}
	princ_char(10,symbol_value(VV[64]));
	princ_str("static end_init();",symbol_value(VV[64]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_str("static end_init() {}",symbol_value(VV[58]));
L250:
	lex0[0]=Cnil;                             /*  LOCAL-FUNS      */
	(VV[12]->s.s_dbind)= nreverse((VV[12]->s.s_dbind));
	LC3(lex0,0)                               /*  EMIT-LOCAL-FUNS */;
	bds_bind(VV[4],Cnil);                     /*  *FUNARG-VARS*   */
	{register object V5;
	register object V6;                       /*  FORM            */
	V5= (VV[15]->s.s_dbind);
	V6= Cnil;
L265:
	if(!((V5)==Cnil)){
	goto L266;}
	bds_unwind1;
	goto L258;
L266:
	V6= CAR((V5));
	V4= getf(CAR((V6))->s.s_plist,VV[65],Cnil);
	if(((V4))==Cnil){
	goto L271;}
	if(((VV[43]->s.s_dbind))==Cnil){
	goto L275;}
	if((memq(CAR((V6)),VV[66]))==Cnil){
	goto L275;}
	(*LK8)(1,CADR((V6)))                      /*  PRINT-EMITTING  */;
L275:
	Lapply(2,(V4),CDR((V6)))                  /*  APPLY           */;
L271:
	LC3(lex0,0)                               /*  EMIT-LOCAL-FUNS */;
	(VV[4]->s.s_dbind)= Cnil;
	V5= CDR((V5));
	goto L265;
	}
L258:
	{register object V5;
	object V6;                                /*  X               */
	V5= (VV[19]->s.s_dbind);
	V6= Cnil;
L290:
	if(!((V5)==Cnil)){
	goto L291;}
	goto L286;
L291:
	V6= CAR((V5));
	VALUES(0) = (VV[256]->s.s_gfdef);
	Lapply(2,VALUES(0),(V6))                  /*  APPLY           */;
	V5= CDR((V5));
	goto L290;
	}
L286:
	{register object V5;
	object V6;                                /*  X               */
	V5= (VV[10]->s.s_dbind);
	V6= Cnil;
L305:
	if(!((V5)==Cnil)){
	goto L306;}
	goto L301;
L306:
	V6= CAR((V5));
	{object V8;                               /*  I               */
	V8= CADR((V6));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_str("static LKF",symbol_value(VV[58]));
	(*LK7)(1,(V8))                            /*  WT1             */;
	princ_str("(int narg, ...) {TRAMPOLINK(VV[",symbol_value(VV[58]));
	(*LK7)(1,CADDR((V6)))                     /*  WT1             */;
	princ_str("],&LK",symbol_value(VV[58]));
	(*LK7)(1,(V8))                            /*  WT1             */;
	princ_str(");}",symbol_value(VV[58]));
	}
	V5= CDR((V5));
	goto L305;
	}
L301:
	princ_char(10,symbol_value(VV[64]));
	princ_str("static struct codeblock Cblock;",symbol_value(VV[64]));
	{register object V5;
	object V6;                                /*  X               */
	V5= (VV[17]->s.s_dbind);
	V6= Cnil;
L331:
	if(!((V5)==Cnil)){
	goto L332;}
	goto L327;
L332:
	V6= CAR((V5));
	princ_char(10,symbol_value(VV[64]));
	princ_str("#define VM",symbol_value(VV[64]));
	(*LK9)(1,CAR((V6)))                       /*  WT-H1           */;
	princ_char(32,symbol_value(VV[64]));
	(*LK9)(1,CDR((V6)))                       /*  WT-H1           */;
	V5= CDR((V5));
	goto L331;
	}
L327:
	(VV[67]->s.s_dbind)= number_plus((VV[67]->s.s_dbind),MAKE_FIXNUM(1));
	princ_char(10,symbol_value(VV[64]));
	princ_str("#define VM",symbol_value(VV[64]));
	(*LK9)(1,(V3))                            /*  WT-H1           */;
	princ_char(32,symbol_value(VV[64]));
	(*LK9)(1,(VV[67]->s.s_dbind))             /*  WT-H1           */;
	if(!(number_compare(MAKE_FIXNUM(0),(VV[67]->s.s_dbind))==0)){
	goto L356;}
	princ_char(10,symbol_value(VV[64]));
	princ_str("static object VV[1];",symbol_value(VV[64]));
	goto L354;
L356:
	princ_char(10,symbol_value(VV[64]));
	princ_str("static object VV[",symbol_value(VV[64]));
	(*LK9)(1,(VV[67]->s.s_dbind))             /*  WT-H1           */;
	princ_str("];",symbol_value(VV[64]));
L354:
	if(((VV[10]->s.s_dbind))==Cnil){
	goto L365;}
	{object V5;
	register int V6;                          /*  I               */
	V5= MAKE_FIXNUM(length((VV[10]->s.s_dbind)));
	V6= 0;
L370:
	if(!((V6)>=(fix((V5))))){
	goto L371;}
	{int V8;
	VALUES(0)=Cnil;
	V8=1;
	bds_unwind1;
	RETURN(V8);}
L371:
	princ_char(10,symbol_value(VV[64]));
	princ_str("static LKF",symbol_value(VV[64]));
	(*LK9)(1,MAKE_FIXNUM(V6))                 /*  WT-H1           */;
	princ_str("(int, ...);",symbol_value(VV[64]));
	princ_char(10,symbol_value(VV[64]));
	princ_str("static (*LK",symbol_value(VV[64]));
	(*LK9)(1,MAKE_FIXNUM(V6))                 /*  WT-H1           */;
	princ_str(")(int, ...)=LKF",symbol_value(VV[64]));
	(*LK9)(1,MAKE_FIXNUM(V6))                 /*  WT-H1           */;
	princ_char(59,symbol_value(VV[64]));
	V6= (V6)+1;
	goto L370;
	}
L365:
	{int V9;
	VALUES(0)=Cnil;
	V9=1;
	bds_unwind1;
	RETURN(V9);}
	}
	}
}
/*	local function EMIT-LOCAL-FUNS                                */
static LC3(object *lex0,int narg)
{ VT6 VLEX6 CLSR6
TTL:
L390:
	if(!((lex0[0])==((VV[12]->s.s_dbind)))){
	goto L391;}
	VALUES(0) = Cnil;
	RETURN(1);
L391:
	{register object V2;                      /*  LFS             */
	V2= (VV[12]->s.s_dbind);
L396:
	if(!((CDR((V2)))==(lex0[0]))){
	goto L397;}
	lex0[0]= (V2);
	if(((VV[43]->s.s_dbind))==Cnil){
	goto L402;}
	(*LK8)(1,(CADAR((V2)))->v.v_self[0])      /*  PRINT-EMITTING  */;
L402:
	T0= (VV[270]->s.s_gfdef);
	Lapply(2,T0,CAR((V2)))                    /*  APPLY           */;
	goto L394;
L397:
	V2= CDR((V2));
	goto L396;
	}
L394:
	goto L390;
}
/*	function definition for T1EVAL-WHEN                           */
static L4(int narg, object V1)
{ VT7 VLEX7 CLSR7
	bds_check;
TTL:
	{object V2;                               /*  LOAD-FLAG       */
	register object V3;                       /*  COMPILE-FLAG    */
	V2= Cnil;
	V3= Cnil;
	if(!((V1)==Cnil)){
	goto L413;}
	(*LK10)(3,VV[68],MAKE_FIXNUM(1),MAKE_FIXNUM(0))/*  TOO-FEW-ARGS*/;
L413:
	{register object V4;
	object V5;                                /*  SITUATION       */
	V4= CAR((V1));
	V5= Cnil;
L420:
	if(!((V4)==Cnil)){
	goto L421;}
	goto L416;
L421:
	V5= CAR((V4));
	{object V7;
	V7= (V5);
	if((memql((V7),VV[69]))==Cnil){
	goto L428;}
	V2= Ct;
	goto L426;
L428:
	if((memql((V7),VV[70]))==Cnil){
	goto L432;}
	V3= Ct;
	goto L426;
L432:
	if((memql((V7),VV[71]))==Cnil){
	goto L436;}
	goto L426;
L436:
	(*LK0)(2,VV[72],(V5))                     /*  CMPERR          */;
	}
L426:
	V4= CDR((V4));
	goto L420;
	}
L416:
	{object V4;
	V4= (((V3))==Cnil?Ct:Cnil);
	bds_bind(VV[14],V4);                      /*  *NOT-COMPILE-TIME**/
	bds_bind(VV[13],(V3));                    /*  *COMPILE-TIME-TOO**/
	if(((V2))==Cnil){
	goto L443;}
	{int V5;
	V5=L6(1,CDR((V1)))                        /*  T1PROGN         */;
	bds_unwind1;
	bds_unwind1;
	RETURN(V5);}
L443:
	if(((V3))==Cnil){
	goto L446;}
	{int V6;
	V6=(*LK2)(1,CONS(VV[73],CDR((V1))))       /*  CMP-EVAL        */;
	bds_unwind1;
	bds_unwind1;
	RETURN(V6);}
L446:
	{int V7;
	VALUES(0)=Cnil;
	V7=1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V7);}
	}
	}
}
/*	function definition for T1COMPILER-LET                        */
static L5(int narg, object V1)
{ VT8 VLEX8 CLSR8
TTL:
	{register object V2;                      /*  SYMBOLS         */
	register object V3;                       /*  VALUES          */
	V2= Cnil;
	V3= Cnil;
	if(!((V1)==Cnil)){
	goto L450;}
	(*LK10)(3,VV[74],MAKE_FIXNUM(1),MAKE_FIXNUM(0))/*  TOO-FEW-ARGS*/;
L450:
	{register object V4;
	register object V5;                       /*  SPEC            */
	V4= CAR((V1));
	V5= Cnil;
L457:
	if(!((V4)==Cnil)){
	goto L458;}
	goto L453;
L458:
	V5= CAR((V4));
	if(!(type_of((V5))==t_cons)){
	goto L465;}
	if(!(type_of(CAR((V5)))==t_symbol)){
	goto L468;}
	if(CDR((V5))==Cnil){
	goto L467;}
	if(CDDR((V5))==Cnil){
	goto L467;}
L468:
	(*LK0)(2,VV[75],(V5))                     /*  CMPERR          */;
L467:
	V2= CONS(CAR((V5)),(V2));
	if(!(CDR((V5))==Cnil)){
	goto L479;}
	VALUES(0) = Cnil;
	goto L477;
L479:
	Leval(1,CADR((V5)))                       /*  EVAL            */;
L477:
	V3= CONS(VALUES(0),(V3));
	goto L463;
L465:
	if(!(type_of((V5))==t_symbol)){
	goto L482;}
	V2= CONS((V5),(V2));
	V3= CONS(Cnil,(V3));
	goto L463;
L482:
	(*LK0)(2,VV[76],(V5))                     /*  CMPERR          */;
L463:
	V4= CDR((V4));
	goto L457;
	}
L453:
	V2= nreverse((V2));
	V3= nreverse((V3));
	{object V5,V6;
	bds_ptr V4=bds_top;
	V5= (V2);
	V6= (V3);
	while(!endp(V5)) {
	if(endp(V6))bds_bind(CAR(V5),OBJNULL);
	else{bds_bind(CAR(V5),CAR(V6));
	V6=CDR(V6);}
	V5=CDR(V5);}
	L6(1,CDR((V1)))                           /*  T1PROGN         */;
	V1= VALUES(0);
	bds_unwind(V4);}
	VALUES(0) = (V1);
	RETURN(1);
	}
}
/*	function definition for T1PROGN                               */
static L6(int narg, object V1)
{ VT9 VLEX9 CLSR9
TTL:
	{register object V2;
	object V3;                                /*  FORM            */
	V2= (V1);
	V3= Cnil;
L500:
	if(!((V2)==Cnil)){
	goto L501;}
	VALUES(0) = Cnil;
	RETURN(1);
L501:
	V3= CAR((V2));
	L1(1,(V3))                                /*  T1EXPR          */;
	V2= CDR((V2));
	goto L500;
	}
}
/*	function definition for T1DEFUN                               */
static L7(int narg, object V1)
{ VT10 VLEX10 CLSR10
	bds_check;
TTL:
	{object V2;                               /*  SETJMPS         */
	V2= (VV[8]->s.s_dbind);
	if((V1)==Cnil){
	goto L512;}
	if(!(CDR((V1))==Cnil)){
	goto L511;}
L512:
	(*LK10)(3,VV[77],MAKE_FIXNUM(2),MAKE_FIXNUM(length((V1))))/*  TOO-FEW-ARGS*/;
L511:
	if(type_of(CAR((V1)))==t_symbol){
	goto L516;}
	(*LK0)(2,VV[78],CAR((V1)))                /*  CMPERR          */;
L516:
	if(((VV[13]->s.s_dbind))==Cnil){
	goto L519;}
	(*LK2)(1,CONS(VV[77],(V1)))               /*  CMP-EVAL        */;
L519:
	(VV[16]->s.s_dbind)= Ct;
	{register object V3;                      /*  LAMBDA-EXPR     */
	object V4;                                /*  CFUN            */
	object V5;                                /*  DOC             */
	register object V6;                       /*  FNAME           */
	(VV[84]->s.s_dbind)= number_plus((VV[84]->s.s_dbind),MAKE_FIXNUM(1));
	V4= (VV[84]->s.s_dbind);
	V6= CAR((V1));
	bds_bind(VV[79],Cnil);                    /*  *VARS*          */
	bds_bind(VV[80],Cnil);                    /*  *FUNS*          */
	bds_bind(VV[81],Cnil);                    /*  *BLOCKS*        */
	bds_bind(VV[82],Cnil);                    /*  *TAGS*          */
	V3= Cnil;
	bds_bind(VV[2],Cnil);                     /*  *SHARP-COMMAS*  */
	bds_bind(VV[83],Cnil);                    /*  *SPECIAL-BINDING**/
	V5= Cnil;
	(*LK11)(2,CDR((V1)),(V6))                 /*  C1LAMBDA-EXPR   */;
	V3= VALUES(0);
	if(eql((V2),(VV[8]->s.s_dbind))){
	goto L529;}
	elt_set(CADR((V3)),5,Ct);
L529:
	if((CADDDR((V3)))==Cnil){
	goto L532;}
	(*LK12)(1,CADDDR((V3)))                   /*  ADD-OBJECT      */;
	V5= VALUES(0);
L532:
	L30(0)                                    /*  ADD-LOAD-TIME-SHARP-COMMA*/;
	L9(5,(V6),(V4),(V3),(V5),(VV[83]->s.s_dbind))/*  NEW-DEFUN    */;
	if((getf((V6)->s.s_plist,VV[85],Cnil))==Cnil){
	goto L539;}
	{register object V7;                      /*  LAMBDA-LIST     */
	V7= CADDR((V3));
	if(CADR((V7))==Cnil){
	goto L544;}
	goto L539;
L544:
	if(CADDR((V7))==Cnil){
	goto L546;}
	goto L539;
L546:
	if(CADDDR((V7))==Cnil){
	goto L548;}
	goto L539;
L548:
	if(!((length(CAR((V7))))<(64))){
	goto L539;}
	}
	{object V7;                               /*  PAT             */
	object V8;                                /*  PRT             */
	V7= getf((V6)->s.s_plist,VV[86],Cnil);
	V8= getf((V6)->s.s_plist,VV[87],Cnil);
	VALUES(0) = memq((V8),VV[89]);
	{object V9= ((VALUES(0))==Cnil?Ct:Cnil);
	LC8(2,(V4),(V7))                          /*  MAKE-INLINE-STRING*/;
	(VV[88]->s.s_dbind)= CONS(list(6,(V6),(V7),(V8),Ct,V9,VALUES(0)),(VV[88]->s.s_dbind));}
	{int V9;
	VALUES(0)=(VV[88]->s.s_dbind);
	V9=1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V9);}
	}
L539:
	{int V10;
	VALUES(0)=Cnil;
	V10=1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V10);}
	}
	}
}
/*	local function MAKE-INLINE-STRING                             */
static LC8(int narg, object V1, object V2)
{ VT11 VLEX11 CLSR11
TTL:
	if(((V2))!=Cnil){
	goto L556;}
	RETURN(Lformat(3,Cnil,VV[90],(V1))        /*  FORMAT          */);
L556:
	{register object V3;                      /*  O               */
	(*LK13)(5,MAKE_FIXNUM(100),VV[91],VV[92],VV[93],MAKE_FIXNUM(0))/*  MAKE-ARRAY*/;
	V3= VALUES(0);
	Lformat(3,(V3),VV[94],(V1))               /*  FORMAT          */;
	{object V4;                               /*  L               */
	register int V5;                          /*  N               */
	V5= 0;
	V4= (V2);
L563:
	if(!(CDR((V4))==Cnil)){
	goto L564;}
	Lformat(3,(V3),VV[95],MAKE_FIXNUM(V5))    /*  FORMAT          */;
	goto L560;
L564:
	Lformat(3,(V3),VV[96],MAKE_FIXNUM(V5))    /*  FORMAT          */;
	V4= CDR((V4));
	V5= (V5)+1;
	goto L563;
	}
L560:
	VALUES(0) = (V3);
	RETURN(1);
	}
}
/*	function definition for NEW-DEFUN                             */
static L9(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT12 VLEX12 CLSR12
TTL:
	{object V6;                               /*  PREVIOUS        */
	{register object V7;
	register object V8;                       /*  FORM            */
	V7= (VV[15]->s.s_dbind);
	V8= Cnil;
L576:
	if(!((V7)==Cnil)){
	goto L577;}
	V6= Cnil;
	goto L572;
L577:
	V8= CAR((V7));
	if(!((VV[77])==(CAR((V8))))){
	goto L582;}
	Lsixth(1,(V8))                            /*  SIXTH           */;
	if(!(equal((V5),VALUES(0)))){
	goto L582;}
	L10(2,(V3),CADDDR((V8)))                  /*  SIMILAR         */;
	if(VALUES(0)==Cnil){
	goto L582;}
	V6= CADDR((V8));
	goto L572;
L582:
	V7= CDR((V7));
	goto L576;
	}
L572:
	if(((V6))==Cnil){
	goto L594;}
	(*LK14)(2,VV[97],(V1))                    /*  CMPNOTE         */;
	(VV[15]->s.s_dbind)= CONS(list(7,VV[77],(V1),(V6),Cnil,(V4),(V5),(VV[4]->s.s_dbind)),(VV[15]->s.s_dbind));
	VALUES(0) = (VV[15]->s.s_dbind);
	RETURN(1);
L594:
	(VV[15]->s.s_dbind)= CONS(list(7,VV[77],(V1),(V2),(V3),(V4),(V5),(VV[4]->s.s_dbind)),(VV[15]->s.s_dbind));
	(VV[9]->s.s_dbind)= CONS(CONS((V1),(V2)),(VV[9]->s.s_dbind));
	VALUES(0) = (VV[9]->s.s_dbind);
	RETURN(1);
	}
}
/*	function definition for SIMILAR                               */
static L10(int narg, object V1, object V2)
{ VT13 VLEX13 CLSR13
TTL:
	if(!(equal((V1),(V2)))){
	goto L601;}
	VALUES(0) = Ct;
	RETURN(1);
L601:
	if(type_of((V1))==t_cons){
	goto L605;}
	VALUES(0) = Cnil;
	goto L604;
L605:
	if(type_of((V2))==t_cons){
	goto L607;}
	VALUES(0) = Cnil;
	goto L604;
L607:
	L10(2,CAR((V1)),CAR((V2)))                /*  SIMILAR         */;
	if(VALUES(0)!=Cnil){
	goto L609;}
	VALUES(0) = Cnil;
	goto L604;
L609:
	L10(2,CDR((V1)),CDR((V2)))                /*  SIMILAR         */;
L604:
	if(VALUES(0)==Cnil)goto L603;
	RETURN(1);
L603:
	(*LK15)(1,(V1))                           /*  VAR-P           */;
	if(VALUES(0)!=Cnil){
	goto L613;}
	VALUES(0) = Cnil;
	goto L612;
L613:
	(*LK15)(1,(V2))                           /*  VAR-P           */;
	if(VALUES(0)!=Cnil){
	goto L615;}
	VALUES(0) = Cnil;
	goto L612;
L615:
	{register int V3;                         /*  I               */
	V3= 2;
L619:
	if(!((V3)==(length((V1))))){
	goto L620;}
	VALUES(0) = Ct;
	goto L612;
L620:
	if(equal(((V1))->v.v_self[V3],((V2))->v.v_self[V3])){
	goto L623;}
	VALUES(0) = Cnil;
	goto L612;
L623:
	V3= (V3)+1;
	goto L619;
	}
L612:
	if(VALUES(0)==Cnil)goto L611;
	RETURN(1);
L611:
	(*LK16)(2,(V1),VV[98])                    /*  TYPEP           */;
	if(VALUES(0)!=Cnil){
	goto L629;}
	VALUES(0) = Cnil;
	RETURN(1);
L629:
	(*LK16)(2,(V2),VV[98])                    /*  TYPEP           */;
	if(VALUES(0)!=Cnil){
	goto L631;}
	VALUES(0) = Cnil;
	RETURN(1);
L631:
	VALUES(0) = (VV[246]->s.s_gfdef);
	RETURN((*LK17)(3,VALUES(0),(V1),(V2))     /*  EVERY           */);
}
/*	function definition for WT-IF-PROCLAIMED                      */
static L11(int narg, object V1, object V2, object V3, object V4)
{ VT14 VLEX14 CLSR14
TTL:
	(*LK18)(1,(V1))                           /*  FAST-LINK-PROCLAIMED-TYPE-P*/;
	if(VALUES(0)==Cnil){
	goto L635;}
	if((assql((V1),(VV[88]->s.s_dbind)))==Cnil){
	goto L638;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("(void)putprop(VV[",symbol_value(VV[58]));
	(*LK7)(1,(V3))                            /*  WT1             */;
	princ_str("],make_fixnum((int)LI",symbol_value(VV[58]));
	(*LK7)(1,(V2))                            /*  WT1             */;
	princ_str("),VV[",symbol_value(VV[58]));
	(*LK12)(1,VV[99])                         /*  ADD-OBJECT      */;
	(*LK7)(1,VALUES(0))                       /*  WT1             */;
	princ_str("]);",symbol_value(VV[58]));
	VALUES(0) = Cnil;
	RETURN(1);
L638:
	{int V5;                                  /*  ARG-C           */
	int V6;                                   /*  ARG-P           */
	V5= length(CAR(CADDR((V4))));
	V6= length(getf((V1)->s.s_plist,VV[86],Cnil));
	if(!((V5)==(V6))){
	goto L653;}
	RETURN((*LK1)(2,VV[100],(V1))             /*  CMPWARN         */);
L653:
	RETURN((*LK1)(4,VV[101],(V1),MAKE_FIXNUM(V6),MAKE_FIXNUM(V5))/*  CMPWARN*/);
	}
L635:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for VOLATILE                              */
static L12(int narg, object V1)
{ VT15 VLEX15 CLSR15
TTL:
	if((((V1))->v.v_self[5])==Cnil){
	goto L656;}
	VALUES(0) = VV[102];
	RETURN(1);
L656:
	VALUES(0) = VV[103];
	RETURN(1);
}
/*	function definition for REGISTER                              */
static L13(int narg, object V1)
{ VT16 VLEX16 CLSR16
TTL:
	if(!(equal((VV[7]->s.s_dbind),VV[104]))){
	goto L659;}
	if(!(number_compare(((V1))->v.v_self[1],(VV[105]->s.s_dbind))>0)){
	goto L659;}
	VALUES(0) = VV[106];
	RETURN(1);
L659:
	VALUES(0) = VV[107];
	RETURN(1);
}
/*	function definition for T2DEFUN                               */
static L14(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT17 VLEX17 CLSR17
TTL:
	{register object V7;                      /*  VV              */
	object V8;                                /*  NKEY            */
	(*LK19)(1,(V1))                           /*  ADD-SYMBOL      */;
	V7= VALUES(0);
	Lfifth(1,CADDR((V3)))                     /*  FIFTH           */;
	V8= MAKE_FIXNUM(length(VALUES(0)));
	if((getf((V1)->s.s_plist,VV[108],Cnil))==Cnil){
	goto L666;}
	VALUES(0) = Cnil;
	RETURN(1);
L666:
	if(!(number_compare(MAKE_FIXNUM(0),(V8))<0)){
	goto L671;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("MF0key(VV[",symbol_value(VV[58]));
	(*LK7)(1,(V7))                            /*  WT1             */;
	princ_str("],L",symbol_value(VV[58]));
	(*LK7)(1,(V2))                            /*  WT1             */;
	princ_char(44,symbol_value(VV[58]));
	(*LK7)(1,(V8))                            /*  WT1             */;
	princ_str(",L",symbol_value(VV[58]));
	(*LK7)(1,(V2))                            /*  WT1             */;
	princ_str("keys);",symbol_value(VV[58]));
	goto L669;
L671:
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("MF0(VV[",symbol_value(VV[58]));
	(*LK7)(1,(V7))                            /*  WT1             */;
	princ_str("],L",symbol_value(VV[58]));
	(*LK7)(1,(V2))                            /*  WT1             */;
	princ_str(");",symbol_value(VV[58]));
L669:
	if(!(number_compare((VV[109]->s.s_dbind),MAKE_FIXNUM(3))<0)){
	goto L691;}
	if(((V4))==Cnil){
	goto L694;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("(void)putprop(VV[",symbol_value(VV[58]));
	(*LK7)(1,(V7))                            /*  WT1             */;
	princ_str("],VV[",symbol_value(VV[58]));
	(*LK7)(1,(V4))                            /*  WT1             */;
	princ_str("],siSfunction_documentation);",symbol_value(VV[58]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
L694:
	putprop((V1),Ct,VV[110]);
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("(void)putprop(VV[",symbol_value(VV[58]));
	(*LK7)(1,(V7))                            /*  WT1             */;
	princ_str("],VV[Vdeb",symbol_value(VV[58]));
	(*LK7)(1,(V7))                            /*  WT1             */;
	princ_str("],VV[",symbol_value(VV[58]));
	(*LK12)(1,VV[111])                        /*  ADD-OBJECT      */;
	(*LK7)(1,VALUES(0))                       /*  WT1             */;
	princ_str("]);",symbol_value(VV[58]));
L691:
	if((getf((V1)->s.s_plist,VV[85],Cnil))==Cnil){
	goto L719;}
	RETURN(L11(4,(V1),(V2),(V7),(V3))         /*  WT-IF-PROCLAIMED*/);
L719:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for T3DEFUN                               */
static L15(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT18 VLEX18 CLSR18
	bds_check;
TTL:
	{register object V7;                      /*  INLINE-INFO     */
	register object V8;                       /*  LAMBDA-LIST     */
	object V9;                                /*  REQUIREDS       */
	V7= Cnil;
	V8= Cnil;
	V9= Cnil;
	bds_bind(VV[36],list(2,VV[77],(V1)));     /*  *CURRENT-FORM*  */
	if(((V3))==Cnil){
	goto L727;}
	L12(1,CADR((V3)))                         /*  VOLATILE        */;
	bds_bind(VV[7],VALUES(0));                /*  *VOLATILE*      */
	goto L725;
L727:
	bds_bind(VV[7],Cnil);                     /*  *VOLATILE*      */
L725:
	bds_bind(VV[52],MAKE_FIXNUM(0));          /*  *LCL*           */
	bds_bind(VV[62],MAKE_FIXNUM(0));          /*  *TEMP*          */
	bds_bind(VV[56],MAKE_FIXNUM(0));          /*  *MAX-TEMP*      */
	bds_bind(VV[112],MAKE_FIXNUM(0));         /*  *NEXT-UNBOXED*  */
	bds_bind(VV[57],Cnil);                    /*  *UNBOXED*       */
	bds_bind(VV[53],(VV[53]->s.s_dbind));     /*  *LEX*           */
	bds_bind(VV[54],(VV[54]->s.s_dbind));     /*  *MAX-LEX*       */
	bds_bind(VV[60],(VV[60]->s.s_dbind));     /*  *ENV*           */
	bds_bind(VV[55],MAKE_FIXNUM(0));          /*  *MAX-ENV*       */
	bds_bind(VV[61],(VV[61]->s.s_dbind));     /*  *LEVEL*         */
	(VV[4]->s.s_dbind)= (V6);
	if(((V3))==Cnil){
	goto L731;}
	V8= CADDR((V3));
	V9= CAR((V8));
	L21(1,(CADR((V3)))->v.v_self[2])          /*  ANALYZE-REGS    */;
	{object V10;
	object V11;                               /*  V               */
	V10= (VV[88]->s.s_dbind);
	V11= Cnil;
L745:
	if(!((V10)==Cnil)){
	goto L746;}
	goto L740;
L746:
	V11= CAR((V10));
	if(!((CAR((V11)))==((V1)))){
	goto L751;}
	V7= (V11);
	if(((V7))==Cnil){
	goto L740;}
	goto L741;
L751:
	V10= CDR((V10));
	goto L745;
	}
L741:
	{object V10= CADDR((V7));
	if((V10!= VV[291]))goto L759;
	bds_bind(VV[113],VV[114]);                /*  *EXIT*          */
	goto L758;
L759:
	if((V10!= VV[292]))goto L760;
	bds_bind(VV[113],VV[115]);                /*  *EXIT*          */
	goto L758;
L760:
	if((V10!= VV[293]))goto L761;
	bds_bind(VV[113],VV[116]);                /*  *EXIT*          */
	goto L758;
L761:
	if((V10!= VV[294]))goto L762;
	bds_bind(VV[113],VV[117]);                /*  *EXIT*          */
	goto L758;
L762:
	bds_bind(VV[113],VV[118]);                /*  *EXIT*          */}
L758:
	bds_bind(VV[119],CONS((VV[113]->s.s_dbind),Cnil));/*  *UNWIND-EXIT**/
	bds_bind(VV[120],(VV[113]->s.s_dbind));   /*  *DESTINATION*   */
	(VV[50]->s.s_dbind)= number_plus((VV[50]->s.s_dbind),MAKE_FIXNUM(1));
	bds_bind(VV[18],(VV[50]->s.s_dbind));     /*  *RESERVATION-CMACRO**/
	(VV[19]->s.s_dbind)= CONS(list(4,(V1),(V2),CADR((V7)),CADDR((V7))),(VV[19]->s.s_dbind));
	(*LK20)(2,VV[121],(V1))                   /*  WT-COMMENT      */;
	princ_char(10,symbol_value(VV[64]));
	princ_str("static ",symbol_value(VV[64]));
	L24(1,CADDR((V7)))                        /*  REP-TYPE        */;
	(*LK9)(1,VALUES(0))                       /*  WT-H1           */;
	princ_str("LI",symbol_value(VV[64]));
	(*LK9)(1,(V2))                            /*  WT-H1           */;
	princ_str("();",symbol_value(VV[64]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_str("static ",symbol_value(VV[58]));
	L24(1,CADDR((V7)))                        /*  REP-TYPE        */;
	(*LK7)(1,VALUES(0))                       /*  WT1             */;
	princ_str("LI",symbol_value(VV[58]));
	(*LK7)(1,(V2))                            /*  WT1             */;
	princ_char(40,symbol_value(VV[58]));
	{object V10;                              /*  VL              */
	object V11;                               /*  TYPES           */
	object V12;                               /*  PREV-TYPE       */
	object V13;                               /*  VAR             */
	register int V14;                         /*  LCL             */
	V11= CADR((V7));
	V14= fix(one_plus((VV[52]->s.s_dbind)));
	V10= (V9);
	V12= Cnil;
	V13= Cnil;
L789:
	if(!((V10)==Cnil)){
	goto L790;}
	goto L785;
L790:
	V13= CAR((V10));
	if((memq(CAR((V11)),VV[122]))==Cnil){
	goto L795;}
	elt_set((V13),4,CAR((V11)));
L795:
	if(((V12))==Cnil){
	goto L798;}
	princ_char(44,symbol_value(VV[58]));
L798:
	(*LK7)(1,(VV[7]->s.s_dbind))              /*  WT1             */;
	L13(1,(V13))                              /*  REGISTER        */;
	(*LK7)(1,VALUES(0))                       /*  WT1             */;
	L24(1,CAR((V11)))                         /*  REP-TYPE        */;
	(*LK7)(1,VALUES(0))                       /*  WT1             */;
	V12= CAR((V11));
	(*LK21)(1,MAKE_FIXNUM(V14))               /*  WT-LCL          */;
	V10= CDR((V10));
	V11= CDR((V11));
	V14= (V14)+1;
	goto L789;
	}
L785:
	princ_char(41,symbol_value(VV[58]));
	{object V10;
	V10= CONS((V1),(V9));
	bds_bind(VV[123],V10);                    /*  *TAIL-RECURSION-INFO**/
	bds_bind(VV[119],(VV[119]->s.s_dbind));   /*  *UNWIND-EXIT*   */
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(123,symbol_value(VV[58]));
	L16(2,Cnil,VV[124])                       /*  WT-FUNCTION-PROLOG*/;
	(*LK22)(6,(V8),CADDR(CDDR((V3))),(V2),(V1),Cnil,VV[124])/*  C2LAMBDA-EXPR*/;
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(125,symbol_value(VV[58]));
	L17(0)                                    /*  WT-FUNCTION-EPILOGUE*/;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	goto L731;
	}
L740:
	{object V11;
	object V12;                               /*  VA_ARGS         */
	(VV[50]->s.s_dbind)= number_plus((VV[50]->s.s_dbind),MAKE_FIXNUM(1));
	V11= (VV[50]->s.s_dbind);
	VALUES(0) = CADR((V8));
	if(VALUES(0)==Cnil)goto L830;
	V12= VALUES(0);
	goto L829;
L830:
	VALUES(0) = CADDR((V8));
	if(VALUES(0)==Cnil)goto L832;
	V12= VALUES(0);
	goto L829;
L832:
	V12= CADDDR((V8));
L829:
	bds_bind(VV[113],VV[125]);                /*  *EXIT*          */
	bds_bind(VV[119],VV[126]);                /*  *UNWIND-EXIT*   */
	bds_bind(VV[120],VV[125]);                /*  *DESTINATION*   */
	bds_bind(VV[18],V11);                     /*  *RESERVATION-CMACRO**/
	(*LK20)(2,VV[127],(V1))                   /*  WT-COMMENT      */;
	if(!(numberp((V2)))){
	goto L837;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_str("static L",symbol_value(VV[58]));
	(*LK7)(1,(V2))                            /*  WT1             */;
	princ_str("(int narg",symbol_value(VV[58]));
	princ_char(10,symbol_value(VV[64]));
	princ_str("static L",symbol_value(VV[64]));
	(*LK9)(1,(V2))                            /*  WT-H1           */;
	princ_str("(int",symbol_value(VV[64]));
	goto L835;
L837:
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,(V2))                            /*  WT1             */;
	princ_str("(int narg",symbol_value(VV[58]));
	princ_char(10,symbol_value(VV[64]));
	(*LK9)(1,(V2))                            /*  WT-H1           */;
	princ_str("(int",symbol_value(VV[64]));
L835:
	{object V13;                              /*  VL              */
	register int V14;                         /*  LCL             */
	V14= fix(one_plus((VV[52]->s.s_dbind)));
	V13= (V9);
L858:
	if(!((V13)==Cnil)){
	goto L859;}
	goto L855;
L859:
	princ_str(", object ",symbol_value(VV[58]));
	(*LK21)(1,MAKE_FIXNUM(V14))               /*  WT-LCL          */;
	(*LK9)(1,VV[128])                         /*  WT-H1           */;
	V13= CDR((V13));
	V14= (V14)+1;
	goto L858;
	}
L855:
	if(((V12))==Cnil){
	goto L870;}
	princ_str(", ...",symbol_value(VV[58]));
	(*LK9)(1,VV[129])                         /*  WT-H1           */;
L870:
	princ_char(41,symbol_value(VV[58]));
	(*LK9)(1,VV[130])                         /*  WT-H1           */;
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(123,symbol_value(VV[58]));
	L16(1,(V5))                               /*  WT-FUNCTION-PROLOG*/;
	(*LK22)(4,(V8),CADDR(CDDR((V3))),(V2),(V1))/*  C2LAMBDA-EXPR  */;
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(125,symbol_value(VV[58]));
	L17(0)                                    /*  WT-FUNCTION-EPILOGUE*/;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	}
L731:
	{int V10;
	V10=L18(2,(V1),(V3))                      /*  ADD-DEBUG-INFO  */;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V10);}
	}
}
/*	function definition for WT-FUNCTION-PROLOG                    */
static L16(int narg, ...)
{ VT19 VLEX19 CLSR19
	{int i=0;
	object V1;
	object V2;
	va_list args; va_start(args, narg);
	if (i==narg) goto L886;
	V1= va_arg(args, object);
	i++;
	if (i==narg) goto L887;
	V2= va_arg(args, object);
	i++;
	goto L888;
L886:
	V1= Cnil;
L887:
	V2= Cnil;
L888:
	princ_str(" VT",symbol_value(VV[58]));
	(*LK7)(1,(VV[18]->s.s_dbind))             /*  WT1             */;
	princ_str(" VLEX",symbol_value(VV[58]));
	(*LK7)(1,(VV[18]->s.s_dbind))             /*  WT1             */;
	princ_str(" CLSR",symbol_value(VV[58]));
	(*LK7)(1,(VV[18]->s.s_dbind))             /*  WT1             */;
	if(((V2))!=Cnil){
	goto L898;}
	if(((VV[131]->s.s_dbind))==Cnil){
	goto L898;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("cs_check;",symbol_value(VV[58]));
L898:
	if(((V1))==Cnil){
	goto L907;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("bds_check;",symbol_value(VV[58]));
	VALUES(0) = Cnil;
	RETURN(1);
L907:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WT-FUNCTION-EPILOGUE                  */
static L17(int narg, ...)
{ VT20 VLEX20 CLSR20
	{int i=0;
	object V1;
	va_list args; va_start(args, narg);
	if (i==narg) goto L912;
	V1= va_arg(args, object);
	i++;
	goto L913;
L912:
	V1= Cnil;
L913:
	{object V2= (VV[18]->s.s_dbind);
	(VV[17]->s.s_dbind)= CONS(CONS(V2,number_plus((VV[56]->s.s_dbind),MAKE_FIXNUM(length((VV[57]->s.s_dbind))))),(VV[17]->s.s_dbind));}
	princ_char(10,symbol_value(VV[64]));
	princ_str("#define VT",symbol_value(VV[64]));
	(*LK9)(1,(VV[18]->s.s_dbind))             /*  WT-H1           */;
	if(!(number_compare(MAKE_FIXNUM(0),(VV[56]->s.s_dbind))<0)){
	goto L921;}
	(*LK9)(1,VV[132])                         /*  WT-H1           */;
	{object V2;
	register int V3;                          /*  I               */
	V2= (VV[56]->s.s_dbind);
	V3= 0;
L929:
	if(!(number_compare(MAKE_FIXNUM(V3),(V2))>=0)){
	goto L930;}
	goto L925;
L930:
	(*LK9)(1,VV[133])                         /*  WT-H1           */;
	(*LK9)(1,MAKE_FIXNUM(V3))                 /*  WT-H1           */;
	if(number_compare(one_plus(MAKE_FIXNUM(V3)),(VV[56]->s.s_dbind))==0){
	goto L935;}
	(*LK9)(1,VV[134])                         /*  WT-H1           */;
L935:
	V3= (V3)+1;
	goto L929;
	}
L925:
	(*LK9)(1,VV[135])                         /*  WT-H1           */;
L921:
	princ_char(10,symbol_value(VV[64]));
	princ_str("#define VLEX",symbol_value(VV[64]));
	(*LK9)(1,(VV[18]->s.s_dbind))             /*  WT-H1           */;
	if(!(number_compare(MAKE_FIXNUM(0),(VV[54]->s.s_dbind))<0)){
	goto L945;}
	(*LK9)(1,VV[136])                         /*  WT-H1           */;
	(*LK9)(1,(VV[61]->s.s_dbind))             /*  WT-H1           */;
	(*LK9)(1,VV[137])                         /*  WT-H1           */;
	(*LK9)(1,(VV[53]->s.s_dbind))             /*  WT-H1           */;
	(*LK9)(1,VV[138])                         /*  WT-H1           */;
L945:
	princ_char(10,symbol_value(VV[64]));
	princ_str("#define CLSR",symbol_value(VV[64]));
	(*LK9)(1,(VV[18]->s.s_dbind))             /*  WT-H1           */;
	if(!(number_compare(MAKE_FIXNUM(0),(VV[55]->s.s_dbind))<0)){
	goto L957;}
	(*LK9)(1,VV[139])                         /*  WT-H1           */;
	if(((V1))!=Cnil){
	goto L960;}
	(*LK9)(1,VV[140])                         /*  WT-H1           */;
L960:
	{object V2;
	register int V3;                          /*  I               */
	V2= (VV[55]->s.s_dbind);
	V3= 0;
L967:
	if(!(number_compare(MAKE_FIXNUM(V3),(V2))>=0)){
	goto L968;}
	goto L963;
L968:
	(*LK9)(1,VV[141])                         /*  WT-H1           */;
	(*LK9)(1,MAKE_FIXNUM(V3))                 /*  WT-H1           */;
	if(number_compare(one_plus(MAKE_FIXNUM(V3)),(VV[55]->s.s_dbind))==0){
	goto L973;}
	(*LK9)(1,VV[142])                         /*  WT-H1           */;
L973:
	V3= (V3)+1;
	goto L967;
	}
L963:
	RETURN((*LK9)(1,VV[143])                  /*  WT-H1           */);
L957:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for ADD-DEBUG-INFO                        */
static L18(int narg, object V1, object V2)
{ VT21 VLEX21 CLSR21
TTL:
	{object V3;
	V3= (number_compare((VV[109]->s.s_dbind),MAKE_FIXNUM(3))>=0?Ct:Cnil);
	if(((V3))==Cnil){
	goto L981;}
	VALUES(0) = (V3);
	RETURN(1);
L981:
	if((getf((V1)->s.s_plist,VV[110],Cnil))!=Cnil){
	goto L984;}
	RETURN((*LK23)(2,VV[144],(V1))            /*  WARN            */);
L984:
	remprop((V1),VV[110]);
	{object V4;                               /*  ARGS            */
	object V5;                                /*  REQUIREDS       */
	object V6;                                /*  OPTIONALS       */
	object V7;                                /*  KEYWORDS        */
	V4= CADDR((V2));
	T1=VV[299]->s.s_gfdef;
	{object V8;
	object V9= CAR((V4));
	if(V9==Cnil){
	V5= Cnil;
	goto L988;}
	T0=V8=CONS(Cnil,Cnil);
L989:
	(*LK24)(1,CAR(V9))                        /*  VAR-NAME        */;
	CAR(V8)= VALUES(0);
	if((V9=CDR(V9))==Cnil){
	V5= T0;
	goto L988;}
	V8=CDR(V8)=CONS(Cnil,Cnil);
	goto L989;}
L988:
	{object V8;
	object V9= CADR((V4));
	if(V9==Cnil){
	V6= Cnil;
	goto L991;}
	T0=V8=CONS(Cnil,Cnil);
L992:
	{object V10;                              /*  X               */
	CAR(V8)= (CAR(CAR(V9)))->v.v_self[0];
	}
	if((V9=CDR(V9))==Cnil){
	V6= T0;
	goto L991;}
	V8=CDR(V8)=CONS(Cnil,Cnil);
	goto L992;}
L991:
	Lfifth(1,(V4))                            /*  FIFTH           */;
	{object V8;
	object V9= VALUES(0);
	if(V9==Cnil){
	V7= Cnil;
	goto L994;}
	T0=V8=CONS(Cnil,Cnil);
L995:
	{object V10;                              /*  X               */
	CAR(V8)= (CADR(CAR(V9)))->v.v_self[0];
	}
	if((V9=CDR(V9))==Cnil){
	V7= T0;
	goto L994;}
	V8=CDR(V8)=CONS(Cnil,Cnil);
	goto L995;}
L994:
	princ_char(10,symbol_value(VV[64]));
	princ_str("#define Vdeb",symbol_value(VV[64]));
	(*LK19)(1,(V1))                           /*  ADD-SYMBOL      */;
	(*LK9)(1,VALUES(0))                       /*  WT-H1           */;
	princ_char(32,symbol_value(VV[64]));
	Lnconc(3,(V5),(V6),(V7))                  /*  NCONC           */;
	(*LK12)(1,VALUES(0))                      /*  ADD-OBJECT      */;
	(*LK9)(1,VALUES(0))                       /*  WT-H1           */;
	VALUES(0) = Cnil;
	RETURN(1);
	}
	}
}
/*	function definition for ANALYZE-REGS                          */
static L21(int narg, object V1)
{ VT22 VLEX22 CLSR22
TTL:
	{object V2;                               /*  ADDR            */
	object V3;                                /*  DATA            */
	V2= Cnil;
	V3= Cnil;
	{register object V4;
	register object V5;                       /*  V               */
	V4= (V1);
	V5= Cnil;
L1010:
	if(!((V4)==Cnil)){
	goto L1011;}
	goto L1006;
L1011:
	V5= CAR((V4));
	if((memq(((V5))->v.v_self[6],VV[145]))==Cnil){
	goto L1018;}
	Ladjoin(2,(V5),(V3))                      /*  ADJOIN          */;
	V3= VALUES(0);
	goto L1016;
L1018:
	Ladjoin(2,(V5),(V2))                      /*  ADJOIN          */;
	V2= VALUES(0);
L1016:
	V4= CDR((V4));
	goto L1010;
	}
L1006:
	LC22(2,(V2),(VV[5]->s.s_dbind))           /*  ANALYZE-REGS1   */;
	RETURN(LC22(2,(V3),(VV[6]->s.s_dbind))    /*  ANALYZE-REGS1   */);
	}
}
/*	local function ANALYZE-REGS1                                  */
static LC22(int narg, object V1, object V2)
{ VT23 VLEX23 CLSR23
	{int V3;
	V3= fix(V2);
TTL:
	{int V4;                                  /*  TEM             */
	register int V5;                          /*  REAL-MIN        */
	register int V6;                          /*  THIS-MIN        */
	register int V7;                          /*  HAVE            */
	V4= 0;
	V5= 3;
	V6= 100000;
	V7= 0;
	{register object V8;                      /*  VS              */
	object V9;                                /*  V               */
	V8= (V1);
	V9= Cnil;
L1032:
	if(((V8))!=Cnil){
	goto L1033;}
	goto L1030;
L1033:
	{object V11;
	V11= CAR((V8));
	V8= CDR((V8));
	V9= (V11);
	}
	V4= fix(((V9))->v.v_self[1]);
	if(!((V4)>=(V5))){
	goto L1043;}
	V7= (V7)+(1);
	V6= (V6)<=(V4)?V6:V4;
	if(!((V7)>(V3))){
	goto L1043;}
	V7= 0;
	V5= (V6)+1;
	V6= 1000000;
	V8= (V1);
L1043:
	goto L1032;
	}
L1030:
	if(!((V7)<(V3))){
	goto L1061;}
	V5= (V5)-(1);
L1061:
	{register object V8;
	register object V9;                       /*  V               */
	V8= (V1);
	V9= Cnil;
L1068:
	if(!((V8)==Cnil)){
	goto L1069;}
	VALUES(0) = Cnil;
	RETURN(1);
L1069:
	V9= CAR((V8));
	if(!(number_compare(((V9))->v.v_self[1],MAKE_FIXNUM(V5))<0)){
	goto L1074;}
	{object V11= ((V9))->v.v_self[1];
	elt_set((V9),1,(number_compare(V11,(VV[105]->s.s_dbind))<=0?V11:(VV[105]->s.s_dbind)));}
L1074:
	V8= CDR((V8));
	goto L1068;
	}
	}
	}
}
/*	function definition for WT-GLOBAL-ENTRY                       */
static L23(int narg, object V1, object V2, object V3, object V4)
{ VT24 VLEX24 CLSR24
TTL:
	if((getf((V1)->s.s_plist,VV[108],Cnil))==Cnil){
	goto L1080;}
	VALUES(0) = Cnil;
	RETURN(1);
L1080:
	(*LK20)(2,VV[146],(V1))                   /*  WT-COMMENT      */;
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_str("static L",symbol_value(VV[58]));
	(*LK7)(1,(V2))                            /*  WT1             */;
	princ_str("(int narg",symbol_value(VV[58]));
	princ_char(10,symbol_value(VV[64]));
	princ_str("static L",symbol_value(VV[64]));
	(*LK9)(1,(V2))                            /*  WT-H1           */;
	princ_str("(int",symbol_value(VV[64]));
	{object V5;                               /*  VL              */
	register int V6;                          /*  LCL             */
	V6= fix(one_plus((VV[52]->s.s_dbind)));
	V5= (V3);
L1097:
	if(!((V5)==Cnil)){
	goto L1098;}
	(*LK7)(1,VV[147])                         /*  WT1             */;
	goto L1094;
L1098:
	(*LK7)(1,VV[148])                         /*  WT1             */;
	(*LK21)(1,MAKE_FIXNUM(V6))                /*  WT-LCL          */;
	(*LK9)(1,VV[149])                         /*  WT-H1           */;
	V5= CDR((V5));
	V6= (V6)+1;
	goto L1097;
	}
L1094:
	(*LK9)(1,VV[150])                         /*  WT-H1           */;
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(123,symbol_value(VV[58]));
	if(((VV[131]->s.s_dbind))!=Cnil){
	goto L1113;}
	if(((VV[151]->s.s_dbind))==Cnil){
	goto L1112;}
L1113:
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("check_arg(",symbol_value(VV[58]));
	(*LK7)(1,MAKE_FIXNUM(length((V3))))       /*  WT1             */;
	princ_str(");",symbol_value(VV[58]));
L1112:
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("VALUES(0)=",symbol_value(VV[58]));
	if(((V4)!= VV[291]))goto L1128;
	VALUES(0) = VV[152];
	goto L1127;
L1128:
	if(((V4)!= VV[292]))goto L1129;
	VALUES(0) = VV[153];
	goto L1127;
L1129:
	if(((V4)!= VV[293]))goto L1130;
	VALUES(0) = VV[154];
	goto L1127;
L1130:
	if(((V4)!= VV[294]))goto L1131;
	VALUES(0) = VV[155];
	goto L1127;
L1131:
	VALUES(0) = VV[156];
L1127:
	(*LK7)(1,VALUES(0))                       /*  WT1             */;
	princ_str("(LI",symbol_value(VV[58]));
	(*LK7)(1,(V2))                            /*  WT1             */;
	princ_char(40,symbol_value(VV[58]));
	{register object V5;                      /*  TYPES           */
	register int V6;                          /*  N               */
	V6= 1;
	V5= (V3);
L1138:
	if(!((V5)==Cnil)){
	goto L1139;}
	goto L1135;
L1139:
	{object V8= CAR((V5));
	if((V8!= VV[291]))goto L1145;
	VALUES(0) = VV[157];
	goto L1144;
L1145:
	if((V8!= VV[292]))goto L1146;
	VALUES(0) = VV[158];
	goto L1144;
L1146:
	if((V8!= VV[293]))goto L1147;
	VALUES(0) = VV[159];
	goto L1144;
L1147:
	if((V8!= VV[294]))goto L1148;
	VALUES(0) = VV[160];
	goto L1144;
L1148:
	VALUES(0) = VV[161];}
L1144:
	(*LK7)(1,VALUES(0))                       /*  WT1             */;
	princ_char(40,symbol_value(VV[58]));
	(*LK21)(1,MAKE_FIXNUM(V6))                /*  WT-LCL          */;
	princ_char(41,symbol_value(VV[58]));
	if(CDR((V5))==Cnil){
	goto L1153;}
	princ_char(44,symbol_value(VV[58]));
L1153:
	V5= CDR((V5));
	V6= (V6)+1;
	goto L1138;
	}
L1135:
	princ_str("));",symbol_value(VV[58]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("RETURN(1);",symbol_value(VV[58]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(125,symbol_value(VV[58]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for REP-TYPE                              */
static L24(int narg, object V1)
{ VT25 VLEX25 CLSR25
TTL:
	if(((V1)!= VV[291]))goto L1169;
	VALUES(0) = VV[162];
	RETURN(1);
L1169:
	if(((V1)!= VV[292]))goto L1170;
	VALUES(0) = VV[163];
	RETURN(1);
L1170:
	if(((V1)!= VV[294]))goto L1171;
	VALUES(0) = VV[164];
	RETURN(1);
L1171:
	if(((V1)!= VV[293]))goto L1172;
	VALUES(0) = VV[165];
	RETURN(1);
L1172:
	VALUES(0) = VV[166];
	RETURN(1);
}
/*	function definition for T1DEFMACRO                            */
static L25(int narg, object V1)
{ VT26 VLEX26 CLSR26
	bds_check;
TTL:
	if((V1)==Cnil){
	goto L1174;}
	if(!(CDR((V1))==Cnil)){
	goto L1173;}
L1174:
	(*LK10)(3,VV[167],MAKE_FIXNUM(2),MAKE_FIXNUM(length((V1))))/*  TOO-FEW-ARGS*/;
L1173:
	if(type_of(CAR((V1)))==t_symbol){
	goto L1178;}
	(*LK0)(2,VV[168],CAR((V1)))               /*  CMPERR          */;
L1178:
	(*LK2)(1,CONS(VV[167],(V1)))              /*  CMP-EVAL        */;
	(VV[16]->s.s_dbind)= Ct;
	{register object V2;                      /*  MACRO-LAMBDA    */
	object V3;                                /*  CFUN            */
	object V4;                                /*  DOC             */
	object V5;                                /*  PPN             */
	(VV[84]->s.s_dbind)= number_plus((VV[84]->s.s_dbind),MAKE_FIXNUM(1));
	V3= (VV[84]->s.s_dbind);
	bds_bind(VV[79],Cnil);                    /*  *VARS*          */
	bds_bind(VV[80],Cnil);                    /*  *FUNS*          */
	bds_bind(VV[81],Cnil);                    /*  *BLOCKS*        */
	bds_bind(VV[82],Cnil);                    /*  *TAGS*          */
	bds_bind(VV[2],Cnil);                     /*  *SHARP-COMMAS*  */
	bds_bind(VV[83],Cnil);                    /*  *SPECIAL-BINDING**/
	V2= Cnil;
	V4= Cnil;
	V5= Cnil;
	(*LK25)(3,CAR((V1)),CADR((V1)),CDDR((V1)))/*  C1DM            */;
	V2= VALUES(0);
	if((CAR((V2)))==Cnil){
	goto L1188;}
	(*LK12)(1,CAR((V2)))                      /*  ADD-OBJECT      */;
	V4= VALUES(0);
L1188:
	if((CADR((V2)))==Cnil){
	goto L1192;}
	(*LK12)(1,CADR((V2)))                     /*  ADD-OBJECT      */;
	V5= VALUES(0);
L1192:
	L30(0)                                    /*  ADD-LOAD-TIME-SHARP-COMMA*/;
	(VV[15]->s.s_dbind)= CONS(list(7,VV[167],CAR((V1)),(V3),CDDR((V2)),(V4),(V5),(VV[83]->s.s_dbind)),(VV[15]->s.s_dbind));
	{int V6;
	VALUES(0)=(VV[15]->s.s_dbind);
	V6=1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V6);}
	}
}
/*	function definition for T2DEFMACRO                            */
static L26(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT27 VLEX27 CLSR27
TTL:
	{object V7;                               /*  VV              */
	(*LK19)(1,(V1))                           /*  ADD-SYMBOL      */;
	V7= VALUES(0);
	if(!(number_compare((VV[109]->s.s_dbind),MAKE_FIXNUM(3))<0)){
	goto L1199;}
	if(((V4))==Cnil){
	goto L1202;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("(void)putprop(VV[",symbol_value(VV[58]));
	(*LK7)(1,(V7))                            /*  WT1             */;
	princ_str("],VV[",symbol_value(VV[58]));
	(*LK7)(1,(V4))                            /*  WT1             */;
	princ_str("],siSfunction_documentation);",symbol_value(VV[58]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
L1202:
	if(((V5))==Cnil){
	goto L1199;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("(void)putprop(VV[",symbol_value(VV[58]));
	(*LK7)(1,(V7))                            /*  WT1             */;
	princ_str("],VV[",symbol_value(VV[58]));
	(*LK7)(1,(V5))                            /*  WT1             */;
	princ_str("],siSpretty_print_format);",symbol_value(VV[58]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
L1199:
	princ_char(10,symbol_value(VV[64]));
	princ_str("static L",symbol_value(VV[64]));
	(*LK9)(1,(V2))                            /*  WT-H1           */;
	princ_str("();",symbol_value(VV[64]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("MM0(VV[",symbol_value(VV[58]));
	(*LK7)(1,(V7))                            /*  WT1             */;
	princ_str("],L",symbol_value(VV[58]));
	(*LK7)(1,(V2))                            /*  WT1             */;
	princ_str(");",symbol_value(VV[58]));
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for T3DEFMACRO                            */
static L27(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT28 VLEX28 CLSR28
	bds_check;
TTL:
	bds_bind(VV[52],MAKE_FIXNUM(0));          /*  *LCL*           */
	bds_bind(VV[62],MAKE_FIXNUM(0));          /*  *TEMP*          */
	bds_bind(VV[56],MAKE_FIXNUM(0));          /*  *MAX-TEMP*      */
	bds_bind(VV[53],(VV[53]->s.s_dbind));     /*  *LEX*           */
	bds_bind(VV[54],(VV[54]->s.s_dbind));     /*  *MAX-LEX*       */
	bds_bind(VV[112],MAKE_FIXNUM(0));         /*  *NEXT-UNBOXED*  */
	bds_bind(VV[57],Cnil);                    /*  *UNBOXED*       */
	bds_bind(VV[60],(VV[60]->s.s_dbind));     /*  *ENV*           */
	bds_bind(VV[55],MAKE_FIXNUM(0));          /*  *MAX-ENV*       */
	bds_bind(VV[61],(VV[61]->s.s_dbind));     /*  *LEVEL*         */
	if((getf((V1)->s.s_plist,VV[169],Cnil))==Cnil){
	goto L1241;}
	bds_bind(VV[7],VV[170]);                  /*  *VOLATILE*      */
	goto L1239;
L1241:
	bds_bind(VV[7],VV[171]);                  /*  *VOLATILE*      */
L1239:
	bds_bind(VV[113],VV[125]);                /*  *EXIT*          */
	bds_bind(VV[119],VV[172]);                /*  *UNWIND-EXIT*   */
	bds_bind(VV[120],VV[125]);                /*  *DESTINATION*   */
	(VV[50]->s.s_dbind)= number_plus((VV[50]->s.s_dbind),MAKE_FIXNUM(1));
	bds_bind(VV[18],(VV[50]->s.s_dbind));     /*  *RESERVATION-CMACRO**/
	(*LK20)(2,VV[173],(V1))                   /*  WT-COMMENT      */;
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_str("static L",symbol_value(VV[58]));
	(*LK7)(1,(V2))                            /*  WT1             */;
	princ_str("(int narg, object V1, object V2)",symbol_value(VV[58]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(123,symbol_value(VV[58]));
	L16(1,(V6))                               /*  WT-FUNCTION-PROLOG*/;
	(*LK26)(5,(V1),CAR((V3)),CADR((V3)),CADDR((V3)),CADDDR((V3)))/*  C2DM*/;
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(125,symbol_value(VV[58]));
	{int V7;
	V7=L17(0)                                 /*  WT-FUNCTION-EPILOGUE*/;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V7);}
}
/*	function definition for T1ORDINARY                            */
static L28(int narg, object V1)
{ VT29 VLEX29 CLSR29
	bds_check;
TTL:
	if(((VV[13]->s.s_dbind))!=Cnil){
	goto L1260;}
	if((CAR((V1)))==(VV[174])){
	goto L1260;}
	if((CAR((V1)))==(VV[175])){
	goto L1260;}
	if(!((CAR((V1)))==(VV[176]))){
	goto L1259;}
L1260:
	(*LK2)(1,(V1))                            /*  CMP-EVAL        */;
L1259:
	(VV[16]->s.s_dbind)= Ct;
	bds_bind(VV[79],Cnil);                    /*  *VARS*          */
	bds_bind(VV[80],Cnil);                    /*  *FUNS*          */
	bds_bind(VV[81],Cnil);                    /*  *BLOCKS*        */
	bds_bind(VV[82],Cnil);                    /*  *TAGS*          */
	bds_bind(VV[2],Cnil);                     /*  *SHARP-COMMAS*  */
	(*LK27)(1,(V1))                           /*  C1EXPR          */;
	V1= VALUES(0);
	L30(0)                                    /*  ADD-LOAD-TIME-SHARP-COMMA*/;
	(VV[15]->s.s_dbind)= CONS(list(2,VV[177],(V1)),(VV[15]->s.s_dbind));
	{int V2;
	VALUES(0)=(VV[15]->s.s_dbind);
	V2=1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V2);}
}
/*	function definition for T2ORDINARY                            */
static L29(int narg, object V1)
{ VT30 VLEX30 CLSR30
	bds_check;
TTL:
	(VV[178]->s.s_dbind)= number_plus((VV[178]->s.s_dbind),MAKE_FIXNUM(1));
	bds_bind(VV[113],CONS((VV[178]->s.s_dbind),Cnil));/*  *EXIT*  */
	bds_bind(VV[119],CONS((VV[113]->s.s_dbind),Cnil));/*  *UNWIND-EXIT**/
	bds_bind(VV[120],VV[179]);                /*  *DESTINATION*   */
	(*LK28)(1,(V1))                           /*  C2EXPR          */;
	if((CDR((VV[113]->s.s_dbind)))==Cnil){
	goto L1279;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(76,symbol_value(VV[58]));
	(*LK7)(1,CAR((VV[113]->s.s_dbind)))       /*  WT1             */;
	princ_char(58,symbol_value(VV[58]));
	{int V2;
	VALUES(0)=Cnil;
	V2=1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V2);}
L1279:
	{int V3;
	VALUES(0)=Cnil;
	V3=1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V3);}
}
/*	function definition for ADD-LOAD-TIME-SHARP-COMMA             */
static L30(int narg)
{ VT31 VLEX31 CLSR31
TTL:
	{register object V1;
	object V2;                                /*  VV              */
	V1= reverse((VV[2]->s.s_dbind));
	V2= Cnil;
L1288:
	if(!((V1)==Cnil)){
	goto L1289;}
	VALUES(0) = Cnil;
	RETURN(1);
L1289:
	V2= CAR((V1));
	(VV[15]->s.s_dbind)= CONS(list(2,VV[180],(V2)),(VV[15]->s.s_dbind));
	V1= CDR((V1));
	goto L1288;
	}
}
/*	function definition for T2SHARP-COMMA                         */
static L31(int narg, object V1)
{ VT32 VLEX32 CLSR32
TTL:
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("VV[",symbol_value(VV[58]));
	(*LK7)(1,(V1))                            /*  WT1             */;
	princ_str("]=string_to_object(VV[",symbol_value(VV[58]));
	(*LK7)(1,(V1))                            /*  WT1             */;
	princ_str("]);",symbol_value(VV[58]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for T2DECLARE                             */
static L32(int narg, object V1)
{ VT33 VLEX33 CLSR33
TTL:
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("VV[",symbol_value(VV[58]));
	(*LK7)(1,(V1))                            /*  WT1             */;
	princ_str("]->s.s_stype=(short)stp_special;",symbol_value(VV[58]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for T1DEFVAR                              */
static L33(int narg, object V1)
{ VT34 VLEX34 CLSR34
	bds_check;
TTL:
	{object V2;                               /*  FORM            */
	object V3;                                /*  DOC             */
	object V4;                                /*  NAME            */
	V2= Cnil;
	V3= Cnil;
	V4= CAR((V1));
	if(((VV[13]->s.s_dbind))==Cnil){
	goto L1314;}
	(*LK2)(1,CONS(VV[181],(V1)))              /*  CMP-EVAL        */;
L1314:
	(VV[16]->s.s_dbind)= Cnil;
	if(!(CDR((V1))==Cnil)){
	goto L1320;}
	(*LK19)(1,(V4))                           /*  ADD-SYMBOL      */;
	(VV[15]->s.s_dbind)= CONS(list(2,VV[182],VALUES(0)),(VV[15]->s.s_dbind));
	VALUES(0) = (VV[15]->s.s_dbind);
	RETURN(1);
L1320:
	if(CDDR((V1))==Cnil){
	goto L1324;}
	(*LK12)(1,CADDR((V1)))                    /*  ADD-OBJECT      */;
	V3= VALUES(0);
L1324:
	bds_bind(VV[79],Cnil);                    /*  *VARS*          */
	bds_bind(VV[80],Cnil);                    /*  *FUNS*          */
	bds_bind(VV[81],Cnil);                    /*  *BLOCKS*        */
	bds_bind(VV[82],Cnil);                    /*  *TAGS*          */
	bds_bind(VV[2],Cnil);                     /*  *SHARP-COMMAS*  */
	(*LK27)(1,CADR((V1)))                     /*  C1EXPR          */;
	V2= VALUES(0);
	L30(0)                                    /*  ADD-LOAD-TIME-SHARP-COMMA*/;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	(*LK19)(1,(V4))                           /*  ADD-SYMBOL      */;
	(*LK29)(6,VV[183],(V4),VV[184],VV[185],VV[186],VALUES(0))/*  MAKE-VAR*/;
	(VV[15]->s.s_dbind)= CONS(list(4,VV[181],VALUES(0),(V2),(V3)),(VV[15]->s.s_dbind));
	VALUES(0) = (VV[15]->s.s_dbind);
	RETURN(1);
	}
}
/*	function definition for T2DEFVAR                              */
static L34(int narg, object V1, object V2, object V3)
{ VT35 VLEX35 CLSR35
	bds_check;
TTL:
	{object V4;                               /*  VV              */
	V4= ((V1))->v.v_self[5];
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("VV[",symbol_value(VV[58]));
	(*LK7)(1,(V4))                            /*  WT1             */;
	princ_str("]->s.s_stype=(short)stp_special;",symbol_value(VV[58]));
	(VV[178]->s.s_dbind)= number_plus((VV[178]->s.s_dbind),MAKE_FIXNUM(1));
	bds_bind(VV[113],CONS((VV[178]->s.s_dbind),Cnil));/*  *EXIT*  */
	bds_bind(VV[119],CONS((VV[113]->s.s_dbind),Cnil));/*  *UNWIND-EXIT**/
	bds_bind(VV[120],list(2,VV[187],(V1)));   /*  *DESTINATION*   */
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(VV[",symbol_value(VV[58]));
	(*LK7)(1,(V4))                            /*  WT1             */;
	princ_str("]->s.s_dbind == OBJNULL){",symbol_value(VV[58]));
	(*LK28)(1,(V2))                           /*  C2EXPR          */;
	princ_char(125,symbol_value(VV[58]));
	if((CDR((VV[113]->s.s_dbind)))==Cnil){
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	goto L1341;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(76,symbol_value(VV[58]));
	(*LK7)(1,CAR((VV[113]->s.s_dbind)))       /*  WT1             */;
	princ_char(58,symbol_value(VV[58]));
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
L1341:
	if(((V3))==Cnil){
	goto L1362;}
	if(!(number_compare((VV[109]->s.s_dbind),MAKE_FIXNUM(3))<0)){
	goto L1362;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("(void)putprop(VV[",symbol_value(VV[58]));
	(*LK7)(1,(V4))                            /*  WT1             */;
	princ_str("],VV[",symbol_value(VV[58]));
	(*LK7)(1,(V3))                            /*  WT1             */;
	princ_str("],siSvariable_documentation);",symbol_value(VV[58]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	VALUES(0) = Cnil;
	RETURN(1);
L1362:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for T1CLINES                              */
static L35(int narg, object V1)
{ VT36 VLEX36 CLSR36
TTL:
	{register object V2;
	object V3;                                /*  S               */
	V2= (V1);
	V3= Cnil;
L1380:
	if(!((V2)==Cnil)){
	goto L1381;}
	goto L1376;
L1381:
	V3= CAR((V2));
	if(type_of((V3))==t_string){
	goto L1386;}
	(*LK0)(2,VV[188],(V3))                    /*  CMPERR          */;
L1386:
	V2= CDR((V2));
	goto L1380;
	}
L1376:
	(VV[15]->s.s_dbind)= CONS(list(2,VV[189],(V1)),(VV[15]->s.s_dbind));
	VALUES(0) = (VV[15]->s.s_dbind);
	RETURN(1);
}
/*	function definition for T3CLINES                              */
static L36(int narg, object V1)
{ VT37 VLEX37 CLSR37
TTL:
	{register object V2;
	object V3;                                /*  S               */
	V2= (V1);
	V3= Cnil;
L1396:
	if(!((V2)==Cnil)){
	goto L1397;}
	VALUES(0) = Cnil;
	RETURN(1);
L1397:
	V3= CAR((V2));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,(V3))                            /*  WT1             */;
	V2= CDR((V2));
	goto L1396;
	}
}
/*	function definition for PARSE-CVSPECS                         */
static L37(int narg, object V1)
{ VT38 VLEX38 CLSR38
TTL:
	{register object V2;                      /*  CVSPECS         */
	V2= Cnil;
	{register object V3;
	register object V4;                       /*  CVS             */
	V3= (V1);
	V4= Cnil;
L1412:
	if(!((V3)==Cnil)){
	goto L1413;}
	VALUES(0) = nreverse((V2));
	RETURN(1);
L1413:
	V4= CAR((V3));
	if(!(type_of((V4))==t_symbol)){
	goto L1420;}
	Lstring_downcase(1,symbol_name((V4)))     /*  STRING-DOWNCASE */;
	V2= CONS(list(2,VV[190],VALUES(0)),(V2));
	goto L1418;
L1420:
	if(!(type_of((V4))==t_string)){
	goto L1425;}
	V2= CONS(list(2,VV[190],(V4)),(V2));
	goto L1418;
L1425:
	if(!(type_of((V4))==t_cons)){
	goto L1429;}
	if((memql(CAR((V4)),VV[191]))==Cnil){
	goto L1429;}
	{register object V6;
	register object V7;                       /*  NAME            */
	V6= CDR((V4));
	V7= Cnil;
L1436:
	if(!((V6)==Cnil)){
	goto L1437;}
	goto L1418;
L1437:
	V7= CAR((V6));
	{object V9= CAR((V4));
	if(!(type_of((V7))==t_symbol)){
	goto L1446;}
	Lstring_downcase(1,symbol_name((V7)))     /*  STRING-DOWNCASE */;
	goto L1444;
L1446:
	if(!(type_of((V7))==t_string)){
	goto L1449;}
	VALUES(0) = (V7);
	goto L1444;
L1449:
	(*LK0)(2,VV[192],(V7))                    /*  CMPERR          */;
L1444:
	V2= CONS(list(2,V9,VALUES(0)),(V2));}
	V6= CDR((V6));
	goto L1436;
	}
L1429:
	(*LK0)(2,VV[193],(V4))                    /*  CMPERR          */;
L1418:
	V3= CDR((V3));
	goto L1412;
	}
	}
}
/*	function definition for T3LOCAL-FUN                           */
static L38(int narg, object V1, object V2, object V3)
{ VT39 VLEX39 CLSR39
	bds_check;
TTL:
	{int V4;                                  /*  LEVEL           */
	register object V5;                       /*  LAMBDA-LIST     */
	object V6;                                /*  REQUIREDS       */
	object V7;                                /*  VA_ARGS         */
	V4= fix(((V2))->v.v_self[5]);
	L12(1,CADR((V3)))                         /*  VOLATILE        */;
	bds_bind(VV[7],VALUES(0));                /*  *VOLATILE*      */
	V5= CADDR((V3));
	V6= CAR((V5));
	VALUES(0) = CADR((V5));
	if(VALUES(0)==Cnil)goto L1462;
	V7= VALUES(0);
	goto L1461;
L1462:
	VALUES(0) = CADDR((V5));
	if(VALUES(0)==Cnil)goto L1464;
	V7= VALUES(0);
	goto L1461;
L1464:
	V7= CADDDR((V5));
L1461:
	if((((V2))->v.v_self[7])==Cnil){
	goto L1469;}
	T0= VV[194];
	goto L1467;
L1469:
	T0= VV[195];
L1467:
	{object V8;                               /*  NAME            */
	V8= ((V2))->v.v_self[0];
	if(!(type_of((V8))==t_symbol)){
	goto L1474;}
	if((V8)!=Cnil){
	VALUES(0) = (V8);
	goto L1471;}
	VALUES(0) = VV[196];
	goto L1471;
L1474:
	VALUES(0) = CAR((V8));
	}
L1471:
	(*LK20)(2,T0,VALUES(0))                   /*  WT-COMMENT      */;
	princ_char(10,symbol_value(VV[64]));
	princ_str("static ",symbol_value(VV[64]));
	princ_str("LC",symbol_value(VV[64]));
	(*LK9)(1,((V2))->v.v_self[4])             /*  WT-H1           */;
	princ_char(40,symbol_value(VV[64]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_str("static ",symbol_value(VV[58]));
	princ_str("LC",symbol_value(VV[58]));
	(*LK7)(1,((V2))->v.v_self[4])             /*  WT1             */;
	princ_char(40,symbol_value(VV[58]));
	{object V8;
	register int V9;                          /*  N               */
	V8= MAKE_FIXNUM(V4);
	V9= 0;
L1492:
	if(!((V9)>=(fix((V8))))){
	goto L1493;}
	goto L1488;
L1493:
	(*LK9)(1,VV[197])                         /*  WT-H1           */;
	princ_str("object *lex",symbol_value(VV[58]));
	(*LK7)(1,MAKE_FIXNUM(V9))                 /*  WT1             */;
	princ_char(44,symbol_value(VV[58]));
	V9= (V9)+1;
	goto L1492;
	}
L1488:
	(*LK9)(1,VV[198])                         /*  WT-H1           */;
	princ_str("int narg",symbol_value(VV[58]));
	if(((V1))==Cnil){
	goto L1507;}
	(*LK9)(1,VV[199])                         /*  WT-H1           */;
	princ_str(", object env0",symbol_value(VV[58]));
L1507:
	{int V8;                                  /*  LCL             */
	V8= 0;
	{register object V9;
	object V10;                               /*  VAR             */
	V9= (V6);
	V10= Cnil;
L1517:
	if(!((V9)==Cnil)){
	goto L1518;}
	goto L1512;
L1518:
	V10= CAR((V9));
	(*LK9)(1,VV[200])                         /*  WT-H1           */;
	princ_str(", object ",symbol_value(VV[58]));
	V8= (V8)+(1);
	(*LK21)(1,MAKE_FIXNUM(V8))                /*  WT-LCL          */;
	V9= CDR((V9));
	goto L1517;
	}
	}
L1512:
	if(((V7))==Cnil){
	goto L1531;}
	(*LK9)(1,VV[201])                         /*  WT-H1           */;
	princ_str(", ...",symbol_value(VV[58]));
L1531:
	(*LK9)(1,VV[202])                         /*  WT-H1           */;
	princ_char(41,symbol_value(VV[58]));
	L21(1,(CADR((V3)))->v.v_self[2])          /*  ANALYZE-REGS    */;
	bds_bind(VV[52],MAKE_FIXNUM(0));          /*  *LCL*           */
	bds_bind(VV[62],MAKE_FIXNUM(0));          /*  *TEMP*          */
	bds_bind(VV[56],MAKE_FIXNUM(0));          /*  *MAX-TEMP*      */
	bds_bind(VV[53],MAKE_FIXNUM(0));          /*  *LEX*           */
	bds_bind(VV[54],MAKE_FIXNUM(0));          /*  *MAX-LEX*       */
	bds_bind(VV[112],MAKE_FIXNUM(0));         /*  *NEXT-UNBOXED*  */
	bds_bind(VV[57],Cnil);                    /*  *UNBOXED*       */
	bds_bind(VV[60],((V2))->v.v_self[6]);     /*  *ENV*           */
	bds_bind(VV[55],(VV[60]->s.s_dbind));     /*  *MAX-ENV*       */
	bds_bind(VV[203],MAKE_FIXNUM(0));         /*  *ENV-LVL*       */
	bds_bind(VV[61],MAKE_FIXNUM(V4));         /*  *LEVEL*         */
	bds_bind(VV[113],VV[125]);                /*  *EXIT*          */
	bds_bind(VV[119],VV[204]);                /*  *UNWIND-EXIT*   */
	bds_bind(VV[120],VV[125]);                /*  *DESTINATION*   */
	(VV[50]->s.s_dbind)= number_plus((VV[50]->s.s_dbind),MAKE_FIXNUM(1));
	bds_bind(VV[18],(VV[50]->s.s_dbind));     /*  *RESERVATION-CMACRO**/
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(123,symbol_value(VV[58]));
	princ_str(" VT",symbol_value(VV[58]));
	(*LK7)(1,(VV[18]->s.s_dbind))             /*  WT1             */;
	princ_str(" VLEX",symbol_value(VV[58]));
	(*LK7)(1,(VV[18]->s.s_dbind))             /*  WT1             */;
	princ_str(" CLSR",symbol_value(VV[58]));
	(*LK7)(1,(VV[18]->s.s_dbind))             /*  WT1             */;
	if((((V2))->v.v_self[7])==Cnil){
	goto L1553;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("narg--;",symbol_value(VV[58]));
	{register object V8;                      /*  CLV-USED        */
	T0= VV[269];
	(*LK30)(2,T0,(CADR((V3)))->v.v_self[6])   /*  REMOVE-IF       */;
	V8= VALUES(0);
	T0= (VV[306]->s.s_gfdef);
	VALUES(0) = (VV[307]->s.s_gfdef);
	(*LK31)(4,(V8),T0,VV[205],VALUES(0))      /*  SORT            */;
	V8= VALUES(0);
	if(((V8))==Cnil){
	goto L1553;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{object scan=env0;",symbol_value(VV[58]));
	{register object V9;                      /*  N               */
	register object V10;                      /*  BS              */
	V9= one_minus(((V2))->v.v_self[6]);
	V10= (V8);
L1575:
	if(!(number_compare(MAKE_FIXNUM(0),(V9))>0)){
	goto L1576;}
	goto L1572;
L1576:
	if(!(number_compare((V9),(CAR((V10)))->v.v_self[5])==0)){
	goto L1579;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("CLV",symbol_value(VV[58]));
	(*LK7)(1,(V9))                            /*  WT1             */;
	princ_str("= &CAR(scan);",symbol_value(VV[58]));
	(*LK20)(1,(CAR((V10)))->v.v_self[0])      /*  WT-COMMENT      */;
	V10= CDR((V10));
L1579:
	if(((V10))!=Cnil){
	goto L1591;}
	goto L1572;
L1591:
	if(!(number_compare(MAKE_FIXNUM(0),(V9))<0)){
	goto L1594;}
	princ_str(" scan=CDR(scan);",symbol_value(VV[58]));
L1594:
	V9= one_minus((V9));
	goto L1575;
	}
L1572:
	princ_char(125,symbol_value(VV[58]));
	}
L1553:
	(*LK22)(5,CADDR((V3)),CADDR(CDDR((V3))),((V2))->v.v_self[4],((V2))->v.v_self[0],((V2))->v.v_self[7])/*  C2LAMBDA-EXPR*/;
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(125,symbol_value(VV[58]));
	{int V8;
	V8=L17(1,(V1))                            /*  WT-FUNCTION-EPILOGUE*/;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V8);}
	}
}
/*	function definition for T1DEFCBODY                            */
static L40(int narg, object V1)
{ VT40 VLEX40 CLSR40
TTL:
	{register object V2;                      /*  FUN             */
	object V3;                                /*  CFUN            */
	V2= Cnil;
	(VV[84]->s.s_dbind)= number_plus((VV[84]->s.s_dbind),MAKE_FIXNUM(1));
	V3= (VV[84]->s.s_dbind);
	if((V1)==Cnil){
	goto L1610;}
	if(CDR((V1))==Cnil){
	goto L1610;}
	if(CDDR((V1))==Cnil){
	goto L1610;}
	if(!(CDDDR((V1))==Cnil)){
	goto L1609;}
L1610:
	(*LK10)(3,VV[206],MAKE_FIXNUM(4),MAKE_FIXNUM(length((V1))))/*  TOO-FEW-ARGS*/;
L1609:
	V2= CAR((V1));
	if(type_of((V2))==t_symbol){
	goto L1620;}
	(*LK0)(2,VV[207],(V2))                    /*  CMPERR          */;
L1620:
	(VV[15]->s.s_dbind)= CONS(list(6,VV[208],(V2),(V3),CADR((V1)),CADDR((V1)),CADDDR((V1))),(VV[15]->s.s_dbind));
	(VV[9]->s.s_dbind)= CONS(CONS((V2),(V3)),(VV[9]->s.s_dbind));
	VALUES(0) = (VV[9]->s.s_dbind);
	RETURN(1);
	}
}
/*	function definition for T2DEFCBODY                            */
static L41(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT41 VLEX41 CLSR41
TTL:
	{object V6;                               /*  VV              */
	(*LK19)(1,(V1))                           /*  ADD-SYMBOL      */;
	V6= VALUES(0);
	princ_char(10,symbol_value(VV[64]));
	princ_str("static L",symbol_value(VV[64]));
	(*LK9)(1,(V2))                            /*  WT-H1           */;
	princ_str("();",symbol_value(VV[64]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("MF0(VV[",symbol_value(VV[58]));
	(*LK7)(1,(V6))                            /*  WT1             */;
	princ_str("],L",symbol_value(VV[58]));
	(*LK7)(1,(V2))                            /*  WT1             */;
	princ_str(");",symbol_value(VV[58]));
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for T3DEFCBODY                            */
static L42(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT42 VLEX42 CLSR42
TTL:
	(*LK20)(2,VV[209],(V1))                   /*  WT-COMMENT      */;
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_str("static L",symbol_value(VV[58]));
	(*LK7)(1,(V2))                            /*  WT1             */;
	princ_str("(int narg",symbol_value(VV[58]));
	{object V6;                               /*  VL              */
	register int V7;                          /*  LCL             */
	V7= 1;
	V6= (V3);
L1648:
	if(!((V6)==Cnil)){
	goto L1649;}
	goto L1645;
L1649:
	princ_str(", object ",symbol_value(VV[58]));
	(*LK21)(1,MAKE_FIXNUM(V7))                /*  WT-LCL          */;
	V6= CDR((V6));
	V7= (V7)+1;
	goto L1648;
	}
L1645:
	princ_char(41,symbol_value(VV[58]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(123,symbol_value(VV[58]));
	if(((V4))==Cnil){
	goto L1664;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	LC43(1,(V4))                              /*  LISP2C-TYPE     */;
	Lstring_downcase(1,VALUES(0))             /*  STRING-DOWNCASE */;
	(*LK7)(1,VALUES(0))                       /*  WT1             */;
	princ_str(" x;",symbol_value(VV[58]));
L1664:
	if(((VV[131]->s.s_dbind))==Cnil){
	goto L1673;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("check_arg(",symbol_value(VV[58]));
	(*LK7)(1,MAKE_FIXNUM(length((V3))))       /*  WT1             */;
	princ_str(");",symbol_value(VV[58]));
L1673:
	if(((V4))==Cnil){
	goto L1681;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("x=",symbol_value(VV[58]));
L1681:
	{register object V6;                      /*  TYPES           */
	register int V7;                          /*  I               */
	object V8;                                /*  LST             */
	V7= 1;
	V6= (V3);
	V8= Cnil;
L1691:
	if(((V6))!=Cnil){
	goto L1692;}
	VALUES(0) = nreverse((V8));
	goto L1688;
L1692:
	LC43(1,CAR((V6)))                         /*  LISP2C-TYPE     */;
	if(!((VALUES(0))==(VV[190]))){
	goto L1699;}
	Lformat(3,Cnil,VV[210],MAKE_FIXNUM(V7))   /*  FORMAT          */;
	goto L1697;
L1699:
	LC43(1,CAR((V6)))                         /*  LISP2C-TYPE     */;
	Lformat(4,Cnil,VV[211],VALUES(0),MAKE_FIXNUM(V7))/*  FORMAT   */;
L1697:
	V8= CONS(VALUES(0),(V8));
	V6= CDR((V6));
	V7= (V7)+1;
	goto L1691;
	}
L1688:
	LC44(2,(V5),VALUES(0))                    /*  WT-INLINE-ARG   */;
	princ_char(59,symbol_value(VV[58]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("VALUES(0)=",symbol_value(VV[58]));
	if(((V4)!= Cnil))goto L1714;
	princ_str("Cnil",symbol_value(VV[58]));
	goto L1713;
L1714:
	if(((V4)!= VV[309]))goto L1716;
	princ_str("(x?Ct:Cnil)",symbol_value(VV[58]));
	goto L1713;
L1716:
	if(((V4)!= VV[292]))goto L1718;
	princ_str("code_char(x)",symbol_value(VV[58]));
	goto L1713;
L1718:
	if(((V4)!= VV[291]))goto L1720;
	princ_str("MAKE_FIXNUM(x)",symbol_value(VV[58]));
	goto L1713;
L1720:
	if(((V4)!= VV[294]))goto L1722;
	princ_str("make_shortfloat(x)",symbol_value(VV[58]));
	goto L1713;
L1722:
	if(((V4)!= VV[293]))goto L1724;
	princ_str("make_longfloat(x)",symbol_value(VV[58]));
	goto L1713;
L1724:
	princ_char(120,symbol_value(VV[58]));
L1713:
	princ_char(59,symbol_value(VV[58]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("RETURN(1);",symbol_value(VV[58]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(125,symbol_value(VV[58]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	local function LISP2C-TYPE                                    */
static LC43(int narg, object V1)
{ VT43 VLEX43 CLSR43
TTL:
	if(((V1)!= Cnil))goto L1735;
	VALUES(0) = VV[212];
	RETURN(1);
L1735:
	if(((V1)!= VV[292]))goto L1736;
	VALUES(0) = VV[213];
	RETURN(1);
L1736:
	if(((V1)!= VV[291]))goto L1737;
	VALUES(0) = VV[214];
	RETURN(1);
L1737:
	if(((V1)!= VV[293]))goto L1738;
	VALUES(0) = VV[215];
	RETURN(1);
L1738:
	if(((V1)!= VV[294]))goto L1739;
	VALUES(0) = VV[216];
	RETURN(1);
L1739:
	VALUES(0) = VV[190];
	RETURN(1);
}
/*	local function WT-INLINE-ARG                                  */
static LC44(int narg, object V1, object V2)
{ VT44 VLEX44 CLSR44
TTL:
	{register int V3;                         /*  I               */
	V3= 0;
	if(!(type_of((V1))==t_string)){
	goto L1742;}
	if(!((((V1))->ust.ust_self[0])==(64))){
	goto L1744;}
	V3= 1;
L1750:
	if(!((((V1))->ust.ust_self[V3])==(59))){
	goto L1751;}
	V3= (V3)+(1);
	goto L1744;
L1751:
	V3= (V3)+(1);
	goto L1750;
L1744:
	{int V4;                                  /*  SIZE            */
	V4= ((V1))->v.v_fillp;
L1761:
	if(!((V3)>=(V4))){
	goto L1762;}
	VALUES(0) = Cnil;
	RETURN(1);
L1762:
	{unsigned char V6;                        /*  CHAR            */
	V6= ((V1))->ust.ust_self[V3];
	if(!((V6)==(35))){
	goto L1769;}
	V3= (V3)+(1);
	(*LK7)(1,nth((((V1))->ust.ust_self[V3])-(48),(V2)))/*  WT1    */;
	goto L1767;
L1769:
	princ(code_char(V6),(VV[58]->s.s_dbind));
L1767:
	V3= (V3)+(1);
	}
	goto L1761;
	}
L1742:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for T2FUNCTION-CONSTANT                   */
static L45(int narg, object V1, object V2)
{ VT45 VLEX45 CLSR45
TTL:
	{object V3;                               /*  PREVIOUS        */
	(*LK32)(3,(VV[61]->s.s_dbind),(V2),(V1))  /*  NEW-LOCAL       */;
	V3= VALUES(0);
	if(((V3))==Cnil){
	goto L1778;}
	if((((V3))->v.v_self[8])==Cnil){
	goto L1778;}
	VALUES(0) = elt_set((V2),8,((V3))->v.v_self[8]);
	RETURN(1);
L1778:
	{object V4;                               /*  LOC             */
	(*LK33)(1,Cnil)                           /*  WT-DATA         */;
	(VV[67]->s.s_dbind)= number_plus((VV[67]->s.s_dbind),MAKE_FIXNUM(1));
	V4= list(2,VV[217],(VV[67]->s.s_dbind));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	(*LK7)(1,(V4))                            /*  WT1             */;
	princ_str(" = ",symbol_value(VV[58]));
	(*LK34)(1,(V2))                           /*  WT-MAKE-CLOSURE */;
	princ_char(59,symbol_value(VV[58]));
	VALUES(0) = elt_set((V2),8,(V4));
	RETURN(1);
	}
	}
}
/*	function definition for T2INIT-KEYWORDS                       */
static L46(int narg, object V1, object V2, object V3)
{ VT46 VLEX46 CLSR46
TTL:
	{register object V4;
	object V5;                                /*  LOCAL           */
	V4= (VV[12]->s.s_dbind);
	V5= Cnil;
L1796:
	if(!((V4)==Cnil)){
	goto L1797;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("init_keywords(",symbol_value(VV[58]));
	(*LK7)(1,(V1))                            /*  WT1             */;
	princ_str(", L",symbol_value(VV[58]));
	(*LK7)(1,(V2))                            /*  WT1             */;
	princ_str("keys, &Cblock);",symbol_value(VV[58]));
	VALUES(0) = Cnil;
	RETURN(1);
L1797:
	V5= CAR((V4));
	L10(2,(V3),CADDR((V5)))                   /*  SIMILAR         */;
	if(VALUES(0)==Cnil){
	goto L1809;}
	VALUES(0) = Cnil;
	RETURN(1);
L1809:
	V4= CDR((V4));
	goto L1796;
	}
}
static LKF34(int narg, ...) {TRAMPOLINK(VV[312],&LK34);}
static LKF33(int narg, ...) {TRAMPOLINK(VV[311],&LK33);}
static LKF32(int narg, ...) {TRAMPOLINK(VV[310],&LK32);}
static LKF31(int narg, ...) {TRAMPOLINK(VV[308],&LK31);}
static LKF30(int narg, ...) {TRAMPOLINK(VV[305],&LK30);}
static LKF29(int narg, ...) {TRAMPOLINK(VV[304],&LK29);}
static LKF28(int narg, ...) {TRAMPOLINK(VV[303],&LK28);}
static LKF27(int narg, ...) {TRAMPOLINK(VV[302],&LK27);}
static LKF26(int narg, ...) {TRAMPOLINK(VV[301],&LK26);}
static LKF25(int narg, ...) {TRAMPOLINK(VV[300],&LK25);}
static LKF24(int narg, ...) {TRAMPOLINK(VV[299],&LK24);}
static LKF23(int narg, ...) {TRAMPOLINK(VV[298],&LK23);}
static LKF22(int narg, ...) {TRAMPOLINK(VV[297],&LK22);}
static LKF21(int narg, ...) {TRAMPOLINK(VV[296],&LK21);}
static LKF20(int narg, ...) {TRAMPOLINK(VV[295],&LK20);}
static LKF19(int narg, ...) {TRAMPOLINK(VV[290],&LK19);}
static LKF18(int narg, ...) {TRAMPOLINK(VV[289],&LK18);}
static LKF17(int narg, ...) {TRAMPOLINK(VV[288],&LK17);}
static LKF16(int narg, ...) {TRAMPOLINK(VV[287],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[286],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[285],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[284],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[283],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[282],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[281],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[280],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[279],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[278],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[277],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[276],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[275],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[274],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[273],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[272],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[271],&LK0);}
