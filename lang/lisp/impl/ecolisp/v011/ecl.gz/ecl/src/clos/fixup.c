
#include "fixup.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	MF0(VV[3],L1);
	(void)putprop(VV[3],VV[Vdeb3],VV[37]);
	MF0(VV[38],L2);
	(void)putprop(VV[38],VV[Vdeb38],VV[37]);
	MF0(VV[39],L3);
	(void)putprop(VV[39],VV[Vdeb39],VV[37]);
	MF0(VV[40],L4);
	(void)putprop(VV[40],VV[Vdeb40],VV[37]);
	MF0(VV[41],L5);
	(void)putprop(VV[41],VV[Vdeb41],VV[37]);
	L1(0)                                     /*  FIX-EARLY-METHODS*/;
	MF0(VV[42],L6);
	(void)putprop(VV[42],VV[Vdeb42],VV[37]);
	MF0(VV[43],L7);
	(void)putprop(VV[43],VV[Vdeb43],VV[37]);
	MF0(VV[44],L8);
	(void)putprop(VV[44],VV[Vdeb44],VV[37]);
	MF0(VV[45],L9);
	(void)putprop(VV[45],VV[Vdeb45],VV[37]);
	MF0(VV[46],L10);
	(void)putprop(VV[46],VV[Vdeb46],VV[37]);
	MF0(VV[47],L11);
	(void)putprop(VV[47],VV[Vdeb47],VV[37]);
	MF0(VV[48],L12);
	(void)putprop(VV[48],VV[Vdeb48],VV[37]);
	MF0(VV[49],L13);
	(void)putprop(VV[49],VV[Vdeb49],VV[37]);
	MF0(VV[50],L14);
	(void)putprop(VV[50],VV[Vdeb50],VV[37]);
	MF0(VV[51],L15);
	(void)putprop(VV[51],VV[Vdeb51],VV[37]);
	MF0(VV[52],L16);
	(void)putprop(VV[52],VV[Vdeb52],VV[37]);
	MF0(VV[53],L17);
	(void)putprop(VV[53],VV[Vdeb53],VV[37]);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	function definition for FIX-EARLY-METHODS                     */
static L1(int narg)
{ VT3 VLEX3 CLSR3
TTL:
	{register object V1;
	object V2;                                /*  METHOD-INFO     */
	V1= (VV[0]->s.s_dbind);
	V2= Cnil;
L6:
	if(!((V1)==Cnil)){
	goto L7;}
	goto L2;
L7:
	V2= CAR((V1));
	{object V4;                               /*  METHOD-NAME     */
	object V5;                                /*  GFUN            */
	register object V6;                       /*  GF-OBJECT       */
	V4= CAR((V2));
	V5= symbol_function((V4));
	siLgfun_instance(1,(V5))                  /*  GFUN-INSTANCE   */;
	V6= VALUES(0);
	siLinstance_class(1,(V6))                 /*  INSTANCE-CLASS  */;
	if(!((Ct)==((VALUES(0))->in.in_slots[0]))){
	goto L16;}
	(*LK0)(1,VV[1])                           /*  FIND-CLASS      */;
	siLinstance_class_set(2,(V6),VALUES(0))   /*  INSTANCE-CLASS-SET*/;
	(*LK0)(1,VV[2])                           /*  FIND-CLASS      */;
	siLinstance_set(3,(V6),MAKE_FIXNUM(4),VALUES(0))/*  INSTANCE-SET*/;
L16:
	{register object V7;
	register object V8;                       /*  METHOD          */
	V7= CDR((V2));
	V8= Cnil;
L26:
	if(!((V7)==Cnil)){
	goto L27;}
	goto L12;
L27:
	V8= CAR((V7));
	L2(8,CADR((V8)),CADDR((V8)),CADDDR((V8)),CAR(CDDDDR((V8))),CADR(CDDDDR((V8))),CADDR(CDDDDR((V8))),(V6),VV[2])/*  MAKE-METHOD*/;
	L4(2,(V6),VALUES(0))                      /*  ADD-METHOD      */;
	V7= CDR((V7));
	goto L26;
	}
	}
L12:
	V1= CDR((V1));
	goto L6;
	}
L2:
	Lfmakunbound(1,VV[3])                     /*  FMAKUNBOUND     */;
	RETURN(Lmakunbound(1,VV[0])               /*  MAKUNBOUND      */);
}
/*	function definition for MAKE-METHOD                           */
static L2(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8)
{ VT4 VLEX4 CLSR4
TTL:
	RETURN((*LK1)(15,(V8),VV[4],(V7),VV[5],(V1),VV[6],(V3),VV[7],(V2),VV[8],(V4),VV[9],(V5),VV[10],Ct)/*  MAKE-INSTANCE*/);
}
/*	function definition for GET-METHOD-QUALIFIERS                 */
static L3(int narg, object V1)
{ VT5 VLEX5 CLSR5
TTL:
	(*LK2)(2,(V1),VV[2])                      /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L42;}
	VALUES(0) = ((V1))->in.in_slots[3];
	RETURN(1);
L42:
	RETURN(Lerror(2,VV[11],(V1))              /*  ERROR           */);
}
/*	function definition for ADD-METHOD                            */
static L4(int narg, object V1, object V2)
{ VT6 VLEX6 CLSR6
TTL:
	{object V3;                               /*  METHOD-QUALIFIERS*/
	object V4;
	object V5;                                /*  SPECIALIZERS    */
	object V6;                                /*  FOUND           */
	(*LK3)(1,(V2))                            /*  METHOD-QUALIFIERS*/;
	V4= VALUES(0);
	(*LK4)(1,(V2))                            /*  SPECIALIZERS    */;
	V5= VALUES(0);
	V3= V4;
	V6= Cnil;
	(*LK5)(4,(V1),(V3),(V5),Cnil)             /*  FIND-METHOD     */;
	V6= VALUES(0);
	if(((V6))==Cnil){
	goto L46;}
	L5(2,(V1),(V6))                           /*  REMOVE-METHOD   */;
L46:
	{object V7;
	(*LK6)(1,(V1))                            /*  METHODS         */;
	V7= CONS((V2),VALUES(0));
	(*LK7)(2,(V7),(V1))                       /*  (SETF METHODS)  */;
	}
	(*LK8)(1,(V1))                            /*  GENERIC-FUNCTION-DISPATCHER*/;
	siLgfun_method_ht(1,VALUES(0))            /*  GFUN-METHOD-HT  */;
	Lclrhash(1,VALUES(0))                     /*  CLRHASH         */;
	VALUES(0) = (V2);
	RETURN(1);
	}
}
/*	function definition for REMOVE-METHOD                         */
static L5(int narg, object V1, object V2)
{ VT7 VLEX7 CLSR7
TTL:
	{object V3;
	(*LK6)(1,(V1))                            /*  METHODS         */;
	(*LK9)(2,(V2),VALUES(0))                  /*  DELETE          */;
	V3= VALUES(0);
	RETURN((*LK7)(2,(V3),(V1))                /*  (SETF METHODS)  */);
	}
}
/*	function definition for METHOD-NEEDS-NEXT-METHODS-P           */
static L6(int narg, object V1)
{ VT8 VLEX8 CLSR8
TTL:
	RETURN(Lgetf(2,((V1))->in.in_slots[7],VV[12])/*  GETF         */);
}
/*	function definition for METHOD-P                              */
static L7(int narg, object V1)
{ VT9 VLEX9 CLSR9
TTL:
	RETURN((*LK2)(2,(V1),VV[13])              /*  TYPEP           */);
}
/*	function definition for GET-METHOD-FUNCTION                   */
static L8(int narg, object V1)
{ VT10 VLEX10 CLSR10
TTL:
	(*LK2)(2,(V1),VV[2])                      /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L59;}
	VALUES(0) = ((V1))->in.in_slots[4];
	RETURN(1);
L59:
	RETURN(Lerror(2,VV[14],(V1))              /*  ERROR           */);
}
/*	function definition for COMPUTE-APPLICABLE-METHODS            */
static L9(int narg, object V1, object V2)
{ VT11 VLEX11 CLSR11
TTL:
	{object V3;                               /*  METHODS         */
	object V4;                                /*  APPLICABLE-LIST */
	register object V5;                       /*  ARGS-SPECIALIZERS*/
	(*LK6)(1,(V1))                            /*  METHODS         */;
	V3= VALUES(0);
	V4= Cnil;
	V5= Cnil;
	{object V6;
	object V7;                                /*  METHOD          */
	V6= (V3);
	V7= Cnil;
L66:
	if(!((V6)==Cnil)){
	goto L67;}
	goto L62;
L67:
	V7= CAR((V6));
	{object V9;                               /*  SCAN-ARGS       */
	object V10;                               /*  SCAN-SPECIALIZERS*/
	register object V11;                      /*  ARG             */
	register object V12;                      /*  SPEC            */
	V9= (V2);
	(*LK4)(1,(V7))                            /*  SPECIALIZERS    */;
	V10= VALUES(0);
	V11= Cnil;
	V12= Cnil;
L78:
	if(((V9))!=Cnil){
	goto L79;}
	V4= CONS((V7),(V4));
	goto L72;
L79:
	V11= CAR((V9));
	V12= CAR((V10));
	if(((V12))==Cnil){
	goto L87;}
	if(!(type_of((V12))==t_cons)){
	goto L91;}
	if(eql((V11),CADR((V12)))){
	goto L87;}
L91:
	(*LK2)(2,(V11),(V12))                     /*  TYPEP           */;
	if(VALUES(0)!=Cnil){
	goto L87;}
	if(!((VV[15])==((V12)))){
	goto L88;}
	siLinstancep(1,(V11))                     /*  INSTANCEP       */;
	if(VALUES(0)==Cnil){
	goto L88;}
	(*LK10)(1,(V11))                          /*  CLASS-OF        */;
	if((VV[15])==((VALUES(0))->in.in_slots[0])){
	goto L87;}
L88:
	goto L72;
L87:
	V9= CDR((V9));
	V10= CDR((V10));
	goto L78;
	}
L72:
	V6= CDR((V6));
	goto L66;
	}
L62:
	{object V6;
	object V7;                                /*  ARG             */
	V6= (V2);
	V7= Cnil;
L115:
	if(!((V6)==Cnil)){
	goto L116;}
	goto L111;
L116:
	V7= CAR((V6));
	V5= CONS(TYPE_OF((V7)),(V5));
	V6= CDR((V6));
	goto L115;
	}
L111:
	V5= nreverse((V5));
	{register object V6;                      /*  SCAN            */
	register object V7;                       /*  MOST-SPECIFIC   */
	object V8;                                /*  ORDERED-LIST    */
	V6= (V4);
	V7= CAR((V6));
	V8= Cnil;
L132:
	if((CDR((V6)))!=Cnil){
	goto L133;}
	if(((V7))==Cnil){
	goto L137;}
	V8= CONS((V7),(V8));
	VALUES(0) = nreverse((V8));
	RETURN(1);
L137:
	VALUES(0) = Cnil;
	RETURN(1);
L133:
	{object V10;
	object V11;                               /*  METH            */
	V10= CDR((V6));
	V11= Cnil;
L144:
	if(!((V10)==Cnil)){
	goto L145;}
	goto L140;
L145:
	V11= CAR((V10));
	L10(3,(V7),(V11),(V5))                    /*  COMPARE-METHODS */;
	if(!((VALUES(0))==(MAKE_FIXNUM(2)))){
	goto L150;}
	V7= (V11);
L150:
	V10= CDR((V10));
	goto L144;
	}
L140:
	(*LK9)(2,(V7),(V6))                       /*  DELETE          */;
	V6= VALUES(0);
	V8= CONS((V7),(V8));
	V7= CAR((V6));
	goto L132;
	}
	}
}
/*	function definition for COMPARE-METHODS                       */
static L10(int narg, object V1, object V2, object V3)
{ VT12 VLEX12 CLSR12
TTL:
	{object V4;                               /*  SPECIALIZERS-LIST-1*/
	object V5;
	object V6;                                /*  SPECIALIZERS-LIST-2*/
	(*LK4)(1,(V1))                            /*  SPECIALIZERS    */;
	V5= VALUES(0);
	(*LK4)(1,(V2))                            /*  SPECIALIZERS    */;
	V6= VALUES(0);
	V4= V5;
	RETURN(L11(3,(V4),(V6),(V3))              /*  COMPARE-SPECIALIZERS-LISTS*/);
	}
}
/*	function definition for COMPARE-SPECIALIZERS-LISTS            */
static L11(int narg, object V1, object V2, object V3)
{ VT13 VLEX13 CLSR13
TTL:
	if(((V1))!=Cnil){
	goto L167;}
	if(((V2))==Cnil){
	goto L168;}
L167:
	L12(3,CAR((V1)),CAR((V2)),CAR((V3)))      /*  COMPARE-SPECIALIZERS*/;
	{object V4= VALUES(0);
	if(!eql(V4,VV[16]))goto L173;
	VALUES(0) = MAKE_FIXNUM(1);
	RETURN(1);
L173:
	if(!eql(V4,VV[17]))goto L174;
	VALUES(0) = MAKE_FIXNUM(2);
	RETURN(1);
L174:
	if((V4!= VV[21]))goto L175;
	V1= CDR((V1));
	V2= CDR((V2));
	V3= CDR((V3));
	goto TTL;
L175:
	if((V4!= Cnil))goto L180;
	VALUES(0) = CAR((V1));
	if(VALUES(0)==Cnil)goto L182;
	T0= VALUES(0);
	goto L181;
L182:
	T0= Ct;
L181:
	VALUES(0) = CAR((V2));
	if(VALUES(0)==Cnil)goto L185;
	T1= VALUES(0);
	goto L184;
L185:
	T1= Ct;
L184:
	RETURN(Lerror(4,VV[18],T0,T1,CAR((V3)))   /*  ERROR           */);
L180:
	FEerror("The ECASE key value ~s is illegal.",1,V4);}
L168:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for COMPARE-SPECIALIZERS                  */
static L12(int narg, object V1, object V2, object V3)
{ VT14 VLEX14 CLSR14
TTL:
	{register object V4;                      /*  ARG-CLASS       */
	object V5;                                /*  CPL             */
	register object V6;                       /*  CPL-NAMES       */
	(*LK11)(1,(V3))                           /*  CLOSEST-CLASS   */;
	V4= VALUES(0);
	(*LK2)(2,(V4),VV[19])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L191;}
	(*LK12)(2,(V4),VV[20])                    /*  SLOT-VALUE      */;
	goto L189;
L191:
	(*LK13)(2,(V3),((V4))->in.in_slots[1])    /*  COMPUTE-CLASS-PRECEDENCE-LIST*/;
L189:
	V5= CONS((V4),VALUES(0));
	V6= Cnil;
	{register object V7;
	object V8;                                /*  E               */
	V7= (V5);
	V8= Cnil;
L199:
	if(!((V7)==Cnil)){
	goto L200;}
	V6= nreverse((V6));
	goto L195;
L200:
	V8= CAR((V7));
	V6= CONS(((V8))->in.in_slots[0],(V6));
	V7= CDR((V7));
	goto L199;
	}
L195:
	if(!(equal((V1),(V2)))){
	goto L211;}
	VALUES(0) = VV[21];
	RETURN(1);
L211:
	if(((V1))!=Cnil){
	goto L214;}
	VALUES(0) = MAKE_FIXNUM(2);
	RETURN(1);
L214:
	if(((V2))!=Cnil){
	goto L217;}
	VALUES(0) = MAKE_FIXNUM(1);
	RETURN(1);
L217:
	(*LK14)(2,(V1),(V2))                      /*  SUBTYPEP        */;
	if(VALUES(0)==Cnil){
	goto L220;}
	VALUES(0) = MAKE_FIXNUM(1);
	RETURN(1);
L220:
	(*LK14)(2,(V2),(V1))                      /*  SUBTYPEP        */;
	if(VALUES(0)==Cnil){
	goto L223;}
	VALUES(0) = MAKE_FIXNUM(2);
	RETURN(1);
L223:
	if(!(type_of((V1))==t_cons||(V1)==Cnil)){
	goto L226;}
	if(!((CAR((V1)))==(VV[22]))){
	goto L226;}
	VALUES(0) = MAKE_FIXNUM(1);
	RETURN(1);
L226:
	if(!(type_of((V2))==t_cons||(V2)==Cnil)){
	goto L231;}
	if(!((CAR((V2)))==(VV[22]))){
	goto L231;}
	VALUES(0) = MAKE_FIXNUM(2);
	RETURN(1);
L231:
	{register object x= (V2),V7= (V6);
	while(V7!=Cnil)
	if(eql(x, CAR(V7))){
	VALUES(0) = V7;
	goto L238;
	}else V7=CDR(V7);
	VALUES(0) = Cnil;}
L238:
	{register object x= (V1),V7= VALUES(0);
	while(V7!=Cnil)
	if(eql(x, CAR(V7))){
	goto L237;
	}else V7=CDR(V7);
	goto L236;}
L237:
	VALUES(0) = MAKE_FIXNUM(2);
	RETURN(1);
L236:
	{register object x= (V1),V7= (V6);
	while(V7!=Cnil)
	if(eql(x, CAR(V7))){
	VALUES(0) = V7;
	goto L242;
	}else V7=CDR(V7);
	VALUES(0) = Cnil;}
L242:
	{register object x= (V2),V7= VALUES(0);
	while(V7!=Cnil)
	if(eql(x, CAR(V7))){
	goto L241;
	}else V7=CDR(V7);
	goto L240;}
L241:
	VALUES(0) = MAKE_FIXNUM(1);
	RETURN(1);
L240:
	RETURN(L13(3,(V1),(V2),(V3))              /*  COMPARE-COMPLEX-SPECIALIZERS*/);
	}
}
/*	function definition for COMPARE-COMPLEX-SPECIALIZERS          */
static L13(int narg, object V1, object V2, object V3)
{ VT15 VLEX15 CLSR15
TTL:
	RETURN(Lerror(1,VV[23])                   /*  ERROR           */);
}
/*	function definition for COMPUTE-EFFECTIVE-METHOD              */
static L14(int narg, object V1, object V2, object V3, object V4)
{ VT16 VLEX16 CLSR16
TTL:
	if(((V2))==Cnil){
	goto L244;}
	RETURN((*LK15)(2,(V1),(V2))               /*  COMPUTE-COMBINED-METHOD*/);
L244:
	RETURN(L15(1,(V1))                        /*  NO-APPLICABLE-METHOD*/);
}
/*	function definition for NO-APPLICABLE-METHOD                  */
static L15(int narg, object V1)
{ VT17 VLEX17 CLSR17
TTL:
	(*LK8)(1,(V1))                            /*  GENERIC-FUNCTION-DISPATCHER*/;
	siLgfun_name(1,VALUES(0))                 /*  GFUN-NAME       */;
	RETURN(Lerror(2,VV[24],VALUES(0))         /*  ERROR           */);
}
/*	function definition for NO-NEXT-METHOD                        */
static L16(int narg, object V1, object V2)
{ VT18 VLEX18 CLSR18
TTL:
	RETURN(Lerror(2,VV[25],(V2))              /*  ERROR           */);
}
/*	function definition for REDEFINE-CLASS                        */
static L17(int narg, object V1, object V2, object V3, object V4)
{ VT19 VLEX19 CLSR19
TTL:
	(*LK2)(2,(V1),VV[19])                     /*  TYPEP           */;
	if(VALUES(0)!=Cnil){
	goto L248;}
	Lerror(2,VV[26],(V1))                     /*  ERROR           */;
L248:
	(*LK16)(1,(V1))                           /*  REMOVE-OPTIONAL-SLOT-ACCESSORS*/;
	{object V5;                               /*  SUPERCLASSES    */
	T1=VV[54]->s.s_gfdef;
	if((V3)!=Cnil){
	VALUES(0) = (V3);
	goto L255;}
	VALUES(0) = CONS(VV[27],Cnil);
L255:
	{object V6;
	object V7= VALUES(0);
	if(V7==Cnil){
	V5= Cnil;
	goto L253;}
	T0=V6=CONS(Cnil,Cnil);
L254:
	(*LK0)(1,CAR(V7))                         /*  FIND-CLASS      */;
	CAR(V6)= VALUES(0);
	if((V7=CDR(V7))==Cnil){
	V5= T0;
	goto L253;}
	V6=CDR(V6)=CONS(Cnil,Cnil);
	goto L254;}
L253:
	{register object V6;
	register object V7;                       /*  SUBCLASS        */
	V6= nreverse((V4));
	V7= Cnil;
L261:
	if(!((V6)==Cnil)){
	goto L262;}
	goto L257;
L262:
	V7= CAR((V6));
	{object V9;                               /*  SUPERCLASSES    */
	object V10;                               /*  SUBCLASS-NAME   */
	{object V11;
	object V12= ((V7))->in.in_slots[1];
	if(V12==Cnil){
	V9= Cnil;
	goto L268;}
	T0=V11=CONS(Cnil,Cnil);
L269:
	{object V13;                              /*  X               */
	CAR(V11)= (CAR(V12))->in.in_slots[0];
	}
	if((V12=CDR(V12))==Cnil){
	V9= T0;
	goto L268;}
	V11=CDR(V11)=CONS(Cnil,Cnil);
	goto L269;}
L268:
	V10= ((V7))->in.in_slots[0];
	{int V11;
	V11= 2;
	siLinstance_class(1,(V7))                 /*  INSTANCE-CLASS  */;
	T0= VALUES(0);
	(*LK12)(2,(V7),VV[28])                    /*  SLOT-VALUE      */;
	T1= VALUES(0);
	(*LK17)(1,(V7))                           /*  CLASS-CLASS-SLOTS*/;
	T2= VALUES(0);
	T4=VV[54]->s.s_gfdef;
	{object V12;
	object V13= (V9);
	if(V13==Cnil){
	VALUES(0) = Cnil;
	goto L277;}
	T3=V12=CONS(Cnil,Cnil);
L278:
	(*LK0)(1,CAR(V13))                        /*  FIND-CLASS      */;
	CAR(V12)= VALUES(0);
	if((V13=CDR(V13))==Cnil){
	VALUES(0) = T3;
	goto L277;}
	V12=CDR(V12)=CONS(Cnil,Cnil);
	goto L278;}
L277:
	(*LK13)(2,(V10),VALUES(0))                /*  COMPUTE-CLASS-PRECEDENCE-LIST*/;
	T3= VALUES(0);
	(*LK12)(2,(V7),VV[28])                    /*  SLOT-VALUE      */;
	(*LK18)(2,T3,VALUES(0))                   /*  COLLECT-SLOTDS  */;
	T4= VALUES(0);
	(*LK19)(1,(V7))                           /*  DEFAULT-INITARGS-OF*/;
	T5= VALUES(0);
	(*LK20)(1,(V7))                           /*  DOCUMENTATION-OF*/;
	(*LK21)(8,T0,(V10),(V9),T1,T2,T4,T5,VALUES(0))/*  DEFINE-A-CLASS*/;
	T6= VALUES(0);
	siLinstance_ref(2,(V2),MAKE_FIXNUM(V11))  /*  INSTANCE-REF    */;
	Ladjoin(2,T6,VALUES(0))                   /*  ADJOIN          */;
	siLinstance_set(3,(V2),MAKE_FIXNUM(V11),VALUES(0))/*  INSTANCE-SET*/;
	}
	(*LK10)(1,(V7))                           /*  CLASS-OF        */;
	T0= (VALUES(0))->in.in_slots[0];
	T1= ((V7))->in.in_slots[3];
	(*LK12)(2,(V7),VV[28])                    /*  SLOT-VALUE      */;
	T2= VALUES(0);
	(*LK12)(2,(V7),VV[35])                    /*  SLOT-VALUE      */;
	(*LK22)(11,(V10),VV[30],T0,VV[31],(V9),VV[32],T1,VV[33],T2,VV[34],VALUES(0))/*  GENERATE-METHODS*/;
	Leval(1,CONS(VV[29],VALUES(0)))           /*  EVAL            */;
	}
	V6= CDR((V6));
	goto L261;
	}
L257:
	siLinstance_set(3,(V1),MAKE_FIXNUM(0),VV[15])/*  INSTANCE-SET */;
	(*LK23)(3,(V2),(V1),VV[36])               /*  (SETF SLOT-VALUE)*/;
	}
	VALUES(0) = (V2);
	RETURN(1);
}
static LKF23(int narg, ...) {TRAMPOLINK(VV[92],&LK23);}
static LKF22(int narg, ...) {TRAMPOLINK(VV[91],&LK22);}
static LKF21(int narg, ...) {TRAMPOLINK(VV[90],&LK21);}
static LKF20(int narg, ...) {TRAMPOLINK(VV[89],&LK20);}
static LKF19(int narg, ...) {TRAMPOLINK(VV[88],&LK19);}
static LKF18(int narg, ...) {TRAMPOLINK(VV[87],&LK18);}
static LKF17(int narg, ...) {TRAMPOLINK(VV[35],&LK17);}
static LKF16(int narg, ...) {TRAMPOLINK(VV[86],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[82],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[79],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[78],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[77],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[76],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[72],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[67],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[65],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[64],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[63],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[62],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[61],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[60],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[58],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[56],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[54],&LK0);}
