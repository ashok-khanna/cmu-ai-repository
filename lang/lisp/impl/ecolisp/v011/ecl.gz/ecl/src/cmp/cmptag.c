
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "cmptag.h"
init_cmptag(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_cmptag; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	VV[0]->s.s_stype=(short)stp_special;
	if(VV[0]->s.s_dbind == OBJNULL){
	(VV[0]->s.s_dbind)= Cnil;}
	VV[1]->s.s_stype=(short)stp_special;
	if(VV[1]->s.s_dbind == OBJNULL){
	(VV[1]->s.s_dbind)= MAKE_FIXNUM(60);}
	MF0(VV[31],L1);
	MF0(VV[26],L4);
	MF0(VV[28],L7);
	MF0(VV[32],L8);
	MF0(VV[29],L9);
	MF0(VV[30],L10);
	putprop(VV[4],VV[26],VV[25]);
	putprop(VV[4],VV[28],VV[27]);
	putprop(VV[2],VV[29],VV[25]);
	putprop(VV[2],VV[30],VV[27]);
}
/*	function definition for ADD-LOOP-REGISTERS                    */
static L1(int narg, object V1)
{ VT3 VLEX3 CLSR3
TTL:
	{register object V2;                      /*  V               */
	object V3;                                /*  END             */
	object V4;                                /*  FIRST           */
	V2= (V1);
	V3= Cnil;
	V4= Cnil;
L8:
	if(((V2))!=Cnil){
	goto L9;}
	{register object V6;                      /*  WW              */
	V6= (V4);
L13:
	if(!(((V6))==((V3)))){
	goto L14;}
	RETURN(LC2(1,CAR((V6)))                   /*  ADD-REG1        */);
L14:
	LC2(1,CAR((V6)))                          /*  ADD-REG1        */;
	V6= CDR((V6));
	goto L13;
	}
L9:
	(*LK0)(1,CAR((V2)))                       /*  TAG-P           */;
	if(VALUES(0)==Cnil){
	goto L21;}
	if(((V4))!=Cnil){
	goto L24;}
	V4= (V2);
L24:
	{register object V8;                      /*  W               */
	object V9;                                /*  NAME            */
	V8= CDR((V2));
	V9= (CAR((V2)))->v.v_self[0];
L31:
	if(((V8))!=Cnil){
	goto L32;}
	goto L21;
L32:
	LC3(2,CAR((V8)),(V9))                     /*  JUMPS-TO-P      */;
	if(VALUES(0)==Cnil){
	goto L35;}
	V3= (V8);
L35:
	V8= CDR((V8));
	goto L31;
	}
L21:
	V2= CDR((V2));
	goto L8;
	}
}
/*	local function JUMPS-TO-P                                     */
static LC3(int narg, object V1, object V2)
{ VT4 VLEX4 CLSR4
TTL:
	if(!(type_of((V1))!=t_cons)){
	goto L46;}
	VALUES(0) = Cnil;
	RETURN(1);
L46:
	if(!((CAR((V1)))==(VV[2]))){
	goto L49;}
	VALUES(0) = (((CADDR((V1)))->v.v_self[0])==((V2))?Ct:Cnil);
	RETURN(1);
L49:
	LC3(2,CAR((V1)),(V2))                     /*  JUMPS-TO-P      */;
	if(VALUES(0)==Cnil)goto L51;
	RETURN(1);
L51:
	V1= CDR((V1));
	goto TTL;
}
/*	local function ADD-REG1                                       */
static LC2(int narg, object V1)
{ VT5 VLEX5 CLSR5
TTL:
	if(!(type_of((V1))==t_cons)){
	goto L57;}
	{register object V2;
	object V3;                                /*  V               */
	V2= (V1);
	V3= Cnil;
L62:
	if(!((V2)==Cnil)){
	goto L63;}
	VALUES(0) = Cnil;
	RETURN(1);
L63:
	V3= CAR((V2));
	LC2(1,(V3))                               /*  ADD-REG1        */;
	V2= CDR((V2));
	goto L62;
	}
L57:
	(*LK1)(1,(V1))                            /*  VAR-P           */;
	if(VALUES(0)==Cnil){
	goto L73;}
	VALUES(0) = elt_set((V1),1,number_plus(((V1))->v.v_self[1],(VV[1]->s.s_dbind)));
	RETURN(1);
L73:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for C1TAGBODY                             */
static L4(int narg, object V1)
{ VT6 VLEX6 CLSR6
	bds_check;
TTL:
	{object V2;                               /*  INFO            */
	object V3;                                /*  TAG-VAR         */
	bds_bind(VV[0],(VV[0]->s.s_dbind));       /*  *TAGS*          */
	(*LK2)(0)                                 /*  MAKE-INFO       */;
	V2= VALUES(0);
	(*LK3)(4,VV[3],VV[4],VV[5],Cnil)          /*  MAKE-VAR        */;
	V3= VALUES(0);
	{object V4;
	object V5= (V1);
	if(V5==Cnil){
	V1= Cnil;
	goto L78;}
	T0=V4=CONS(Cnil,Cnil);
L79:
	{object V6;                               /*  X               */
	V6= CAR(V5);
	if(type_of((V6))==t_cons){
	goto L82;}
	{object V7;                               /*  TAG             */
	(*LK4)(4,VV[3],(V6),VV[6],(V3))           /*  MAKE-TAG        */;
	V7= VALUES(0);
	(VV[0]->s.s_dbind)= CONS((V7),(VV[0]->s.s_dbind));
	CAR(V4)= (V7);
	goto L80;
	}
L82:
	CAR(V4)= (V6);
	}
L80:
	if((V5=CDR(V5))==Cnil){
	V1= T0;
	goto L78;}
	V4=CDR(V4)=CONS(Cnil,Cnil);
	goto L79;}
L78:
	{object V4;
	object V5= (V1);
	if(V5==Cnil){
	V1= Cnil;
	goto L88;}
	T0=V4=CONS(Cnil,Cnil);
L89:
	{object V6;                               /*  X               */
	V6= CAR(V5);
	(*LK0)(1,(V6))                            /*  TAG-P           */;
	if(VALUES(0)==Cnil){
	goto L92;}
	CAR(V4)= (V6);
	goto L90;
L92:
	(*LK5)(2,(V6),(V2))                       /*  C1EXPR*         */;
	CAR(V4)= VALUES(0);
	}
L90:
	if((V5=CDR(V5))==Cnil){
	V1= T0;
	goto L88;}
	V4=CDR(V4)=CONS(Cnil,Cnil);
	goto L89;}
L88:
	{register object V4;                      /*  BODY1           */
	V4= Cnil;
	{register object V5;
	register object V6;                       /*  FORM            */
	V5= (V1);
	V6= Cnil;
L98:
	if(!((V5)==Cnil)){
	goto L99;}
	goto L94;
L99:
	V6= CAR((V5));
	(*LK0)(1,(V6))                            /*  TAG-P           */;
	if(VALUES(0)==Cnil){
	goto L106;}
	if(!(number_compare(MAKE_FIXNUM(0),((V6))->v.v_self[1])<0)){
	goto L104;}
	V4= CONS((V6),(V4));
	goto L104;
L106:
	V4= CONS((V6),(V4));
L104:
	V5= CDR((V5));
	goto L98;
	}
L94:
	if(!(number_compare(MAKE_FIXNUM(0),((V3))->v.v_self[1])<0)){
	goto L116;}
	V4= nreverse((V4));
	(VV[7]->s.s_dbind)= number_plus((VV[7]->s.s_dbind),MAKE_FIXNUM(1));
	L1(1,(V4))                                /*  ADD-LOOP-REGISTERS*/;
	{int V5;
	VALUES(0)=list(4,VV[4],(V2),(V3),(V4));
	V5=1;
	bds_unwind1;
	RETURN(V5);}
L116:
	(*LK6)(0)                                 /*  C1NIL           */;
	{int V6;
	VALUES(0)=list(3,VV[8],(V2),nreverse(CONS(VALUES(0),(V4))));
	V6=1;
	bds_unwind1;
	RETURN(V6);}
	}
	}
}
/*	function definition for C2TAGBODY                             */
static L7(int narg, object V1, object V2)
{ VT7 VLEX7 CLSR7
	bds_check;
TTL:
	if((((V1))->v.v_self[4])!=Cnil){
	goto L125;}
	{object V3;                               /*  LABEL           */
	(VV[9]->s.s_dbind)= number_plus((VV[9]->s.s_dbind),MAKE_FIXNUM(1));
	V3= CONS((VV[9]->s.s_dbind),Cnil);
	{register object V4;
	register object V5;                       /*  X               */
	V4= (V2);
	V5= Cnil;
L133:
	if(!((V4)==Cnil)){
	goto L134;}
	goto L129;
L134:
	V5= CAR((V4));
	(*LK0)(1,(V5))                            /*  TAG-P           */;
	if(VALUES(0)==Cnil){
	goto L139;}
	if(!(number_compare(MAKE_FIXNUM(0),((V5))->v.v_self[1])<0)){
	goto L139;}
	(VV[9]->s.s_dbind)= number_plus((VV[9]->s.s_dbind),MAKE_FIXNUM(1));
	elt_set((V5),5,CONS((VV[9]->s.s_dbind),Ct));
	elt_set((V5),6,(V3));
L139:
	V4= CDR((V4));
	goto L133;
	}
L129:
	{object V4;
	V4= CONS((V3),(VV[10]->s.s_dbind));
	bds_bind(VV[10],V4);                      /*  *UNWIND-EXIT*   */
	{int V5;
	V5=L8(1,(V2))                             /*  C2TAGBODY-BODY  */;
	bds_unwind1;
	RETURN(V5);}
	}
	}
L125:
	{object V6;
	object V7;                                /*  LABEL           */
	object V8;
	object V9;
	object V10;
	object V11;
	object V12;
	object V13;                               /*  ENV-GROWS       */
	V6= CONS(VV[11],(VV[10]->s.s_dbind));
	(VV[9]->s.s_dbind)= number_plus((VV[9]->s.s_dbind),MAKE_FIXNUM(1));
	V8= CONS((VV[9]->s.s_dbind),Cnil);
	V9= (VV[12]->s.s_dbind);
	V10= (VV[13]->s.s_dbind);
	V11= (VV[14]->s.s_dbind);
	V12= (VV[15]->s.s_dbind);
	(*LK7)(1,((V1))->v.v_self[2])             /*  ENV-GROWS       */;
	V13= VALUES(0);
	bds_bind(VV[10],V6);                      /*  *UNWIND-EXIT*   */
	V7= V8;
	bds_bind(VV[12],V9);                      /*  *ENV*           */
	bds_bind(VV[13],V10);                     /*  *ENV-LVL*       */
	bds_bind(VV[14],V11);                     /*  *LEX*           */
	bds_bind(VV[15],V12);                     /*  *LCL*           */
	if(((V13))==Cnil){
	goto L158;}
	{object V14;                              /*  ENV-LVL         */
	V14= (VV[13]->s.s_dbind);
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{ object env",symbol_value(VV[16]));
	(VV[13]->s.s_dbind)= number_plus((VV[13]->s.s_dbind),MAKE_FIXNUM(1));
	(*LK8)(1,(VV[13]->s.s_dbind))             /*  WT1             */;
	princ_str(" = env",symbol_value(VV[16]));
	(*LK8)(1,(V14))                           /*  WT1             */;
	princ_char(59,symbol_value(VV[16]));
	}
L158:
	if(!((VV[17])==(((V1))->v.v_self[4]))){
	goto L169;}
	(*LK9)(0)                                 /*  NEXT-LCL        */;
	elt_set((V1),5,VALUES(0));
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{ object ",symbol_value(VV[16]));
	(*LK10)(1,(V1))                           /*  WT-VAR          */;
	princ_char(59,symbol_value(VV[16]));
	V13= Ct;
L169:
	(*LK11)(2,VV[18],(V1))                    /*  BIND            */;
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if (frs_push(FRS_CATCH,",symbol_value(VV[16]));
	(*LK10)(1,(V1))                           /*  WT-VAR          */;
	princ_str(")==0) {",symbol_value(VV[16]));
	{register object V14;
	register object V15;                      /*  TAG             */
	V14= (V2);
	V15= Cnil;
L194:
	if(!((V14)==Cnil)){
	goto L195;}
	goto L190;
L195:
	V15= CAR((V14));
	(*LK0)(1,(V15))                           /*  TAG-P           */;
	if(VALUES(0)==Cnil){
	goto L200;}
	if(!(number_compare(MAKE_FIXNUM(0),((V15))->v.v_self[1])<0)){
	goto L200;}
	(VV[9]->s.s_dbind)= number_plus((VV[9]->s.s_dbind),MAKE_FIXNUM(1));
	elt_set((V15),5,CONS((VV[9]->s.s_dbind),Cnil));
	elt_set((V15),6,(V7));
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if (eql(nlj_tag,VV[",symbol_value(VV[16]));
	(*LK12)(1,((V15))->v.v_self[0])           /*  ADD-SYMBOL      */;
	(*LK8)(1,VALUES(0))                       /*  WT1             */;
	princ_str("])) ",symbol_value(VV[16]));
	CDR(((V15))->v.v_self[5]) = Ct;
	princ_str("goto L",symbol_value(VV[16]));
	(*LK8)(1,CAR(((V15))->v.v_self[5]))       /*  WT1             */;
	princ_char(59,symbol_value(VV[16]));
L200:
	V14= CDR((V14));
	goto L194;
	}
L190:
	if((((V1))->v.v_self[2])==Cnil){
	goto L222;}
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	princ_str("FEerror(\"The GO tag ~s is not established.\",1,nlj_tag);",symbol_value(VV[16]));
L222:
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	princ_char(125,symbol_value(VV[16]));
	if(((V13))==Cnil){
	goto L232;}
	princ_char(125,symbol_value(VV[16]));
L232:
	{object V14;
	V14= CONS((V7),(VV[10]->s.s_dbind));
	bds_bind(VV[10],V14);                     /*  *UNWIND-EXIT*   */
	{int V15;
	V15=L8(1,(V2))                            /*  C2TAGBODY-BODY  */;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V15);}
	}
	}
}
/*	function definition for C2TAGBODY-BODY                        */
static L8(int narg, object V1)
{ VT8 VLEX8 CLSR8
	bds_check;
TTL:
	{register object V2;                      /*  L               */
	register object V3;                       /*  WRITTEN         */
	V2= (V1);
	V3= Cnil;
L238:
	if(!(CDR((V2))==Cnil)){
	goto L239;}
	if(((V3))==Cnil){
	goto L243;}
	RETURN((*LK13)(1,Cnil)                    /*  UNWIND-EXIT     */);
L243:
	(*LK0)(1,CAR((V2)))                       /*  TAG-P           */;
	if(VALUES(0)==Cnil){
	goto L246;}
	if((CDR((CAR((V2)))->v.v_self[5]))==Cnil){
	goto L248;}
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	princ_char(76,symbol_value(VV[16]));
	(*LK8)(1,CAR((CAR((V2)))->v.v_self[5]))   /*  WT1             */;
	princ_char(58,symbol_value(VV[16]));
L248:
	RETURN((*LK13)(1,Cnil)                    /*  UNWIND-EXIT     */);
L246:
	(VV[9]->s.s_dbind)= number_plus((VV[9]->s.s_dbind),MAKE_FIXNUM(1));
	bds_bind(VV[19],CONS((VV[9]->s.s_dbind),Cnil));/*  *EXIT*     */
	bds_bind(VV[10],CONS((VV[19]->s.s_dbind),(VV[10]->s.s_dbind)));/*  *UNWIND-EXIT**/
	bds_bind(VV[20],VV[21]);                  /*  *DESTINATION*   */
	(*LK14)(1,CAR((V2)))                      /*  C2EXPR          */;
	if((CDR((VV[19]->s.s_dbind)))==Cnil){
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	goto L255;}
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	princ_char(76,symbol_value(VV[16]));
	(*LK8)(1,CAR((VV[19]->s.s_dbind)))        /*  WT1             */;
	princ_char(58,symbol_value(VV[16]));
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
L255:
	if((CAAR((V2)))==(VV[2])){
	goto L267;}
	RETURN((*LK13)(1,Cnil)                    /*  UNWIND-EXIT     */);
L267:
	VALUES(0) = Cnil;
	RETURN(1);
L239:
	if(((V3))==Cnil){
	goto L271;}
	V3= Cnil;
	goto L269;
L271:
	(*LK0)(1,CAR((V2)))                       /*  TAG-P           */;
	if(VALUES(0)==Cnil){
	goto L275;}
	if((CDR((CAR((V2)))->v.v_self[5]))==Cnil){
	goto L269;}
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	princ_char(76,symbol_value(VV[16]));
	(*LK8)(1,CAR((CAR((V2)))->v.v_self[5]))   /*  WT1             */;
	princ_char(58,symbol_value(VV[16]));
	goto L269;
L275:
	(*LK0)(1,CADR((V2)))                      /*  TAG-P           */;
	if(VALUES(0)==Cnil){
	goto L285;}
	V3= Ct;
	bds_bind(VV[19],(CADR((V2)))->v.v_self[5]);/*  *EXIT*         */
	goto L283;
L285:
	(VV[9]->s.s_dbind)= number_plus((VV[9]->s.s_dbind),MAKE_FIXNUM(1));
	bds_bind(VV[19],CONS((VV[9]->s.s_dbind),Cnil));/*  *EXIT*     */
L283:
	bds_bind(VV[10],CONS((VV[19]->s.s_dbind),(VV[10]->s.s_dbind)));/*  *UNWIND-EXIT**/
	bds_bind(VV[20],VV[21]);                  /*  *DESTINATION*   */
	(*LK14)(1,CAR((V2)))                      /*  C2EXPR          */;
	if((CDR((VV[19]->s.s_dbind)))==Cnil){
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	goto L269;}
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	princ_char(76,symbol_value(VV[16]));
	(*LK8)(1,CAR((VV[19]->s.s_dbind)))        /*  WT1             */;
	princ_char(58,symbol_value(VV[16]));
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
L269:
	V2= CDR((V2));
	goto L238;
	}
}
/*	function definition for C1GO                                  */
static L9(int narg, object V1)
{ VT9 VLEX9 CLSR9
TTL:
	if(!((V1)==Cnil)){
	goto L303;}
	(*LK15)(3,VV[2],MAKE_FIXNUM(1),MAKE_FIXNUM(0))/*  TOO-FEW-ARGS*/;
	goto L301;
L303:
	if(CDR((V1))==Cnil){
	goto L306;}
	(*LK16)(3,VV[2],MAKE_FIXNUM(1),MAKE_FIXNUM(length((V1))))/*  TOO-MANY-ARGS*/;
	goto L301;
L306:
	if(type_of(CAR((V1)))==t_symbol){
	goto L301;}
	{object V2= CAR((V1));
	if(type_of(V2)==t_fixnum||type_of(V2)==t_bignum){
	goto L301;}}
L301:
	{register object V2;                      /*  TAGS            */
	object V3;
	object V4;                                /*  NAME            */
	object V5;
	object V6;                                /*  INFO            */
	object V7;                                /*  CCB             */
	object V8;                                /*  CLB             */
	object V9;                                /*  UNW             */
	register object V10;                      /*  TAG             */
	register object V11;                      /*  VAR             */
	V3= (VV[0]->s.s_dbind);
	V5= CAR((V1));
	(*LK2)(0)                                 /*  MAKE-INFO       */;
	V6= VALUES(0);
	V2= V3;
	V4= V5;
	V7= Cnil;
	V8= Cnil;
	V9= Cnil;
	V10= Cnil;
	V11= Cnil;
L317:
	if(!((V2)==Cnil)){
	goto L318;}
	RETURN((*LK17)(2,VV[23],(V4))             /*  CMPERR          */);
L318:
	V10= CAR((V2));
	if(((V10)!= VV[51]))goto L324;
	V7= Ct;
	goto L323;
L324:
	if(((V10)!= VV[52]))goto L326;
	V8= Ct;
	goto L323;
L326:
	if(((V10)!= VV[53]))goto L328;
	V9= Ct;
	goto L323;
L328:
	if(!((((V10))->v.v_self[0])==((V4)))){
	goto L323;}
	V11= ((V10))->v.v_self[7];
	if(((V7))==Cnil){
	goto L336;}
	elt_set((V10),2,Ct);
	elt_set((V11),2,Ct);
	elt_set((V11),4,VV[24]);
	goto L334;
L336:
	if(((V8))==Cnil){
	goto L341;}
	elt_set((V10),4,Ct);
	elt_set((V11),4,VV[24]);
	goto L334;
L341:
	if(((V9))==Cnil){
	goto L334;}
	if((((V11))->v.v_self[4])!=Cnil){
	goto L334;}
	elt_set((V11),4,VV[17]);
L334:
	elt_set((V11),1,number_plus(((V11))->v.v_self[1],MAKE_FIXNUM(1)));
	elt_set((V10),1,number_plus(((V10))->v.v_self[1],MAKE_FIXNUM(1)));
	elt_set((V6),6,CONS((V11),((V6))->v.v_self[6]));
	Ladjoin(2,(V11),((V6))->v.v_self[2])      /*  ADJOIN          */;
	elt_set((V6),2,VALUES(0));
	if((V7)!=Cnil){
	VALUES(0) = (V7);
	goto L353;}
	if((V8)!=Cnil){
	VALUES(0) = (V8);
	goto L353;}
	VALUES(0) = (V9);
L353:
	VALUES(0) = list(4,VV[2],(V6),(V10),VALUES(0));
	RETURN(1);
L323:
	V2= CDR((V2));
	goto L317;
	}
}
/*	function definition for C2GO                                  */
static L10(int narg, object V1, object V2)
{ VT10 VLEX10 CLSR10
TTL:
	{object V3;                               /*  VAR             */
	V3= ((V1))->v.v_self[7];
	if(((V2))==Cnil){
	goto L359;}
	if((((V3))->v.v_self[2])==Cnil){
	goto L362;}
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{frame_ptr fr;",symbol_value(VV[16]));
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	princ_str("fr=frs_sch(",symbol_value(VV[16]));
	(*LK10)(1,(V3))                           /*  WT-VAR          */;
	princ_str(");",symbol_value(VV[16]));
	{object V4;                               /*  INDEX           */
	(*LK12)(1,((V1))->v.v_self[0])            /*  ADD-SYMBOL      */;
	V4= VALUES(0);
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(fr==NULL)FEerror(\"The GO tag ~s is missing.\",1,VV[",symbol_value(VV[16]));
	(*LK8)(1,(V4))                            /*  WT1             */;
	princ_str("]);",symbol_value(VV[16]));
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	princ_str("unwind(fr,VV[",symbol_value(VV[16]));
	(*LK8)(1,(V4))                            /*  WT1             */;
	princ_str("]);}",symbol_value(VV[16]));
	VALUES(0) = Cnil;
	RETURN(1);
	}
L362:
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	princ_str("unwind(frs_sch(",symbol_value(VV[16]));
	(*LK10)(1,(V3))                           /*  WT-VAR          */;
	princ_str("),VV[",symbol_value(VV[16]));
	(*LK12)(1,((V1))->v.v_self[0])            /*  ADD-SYMBOL      */;
	(*LK8)(1,VALUES(0))                       /*  WT1             */;
	princ_str("]);",symbol_value(VV[16]));
	VALUES(0) = Cnil;
	RETURN(1);
L359:
	(*LK18)(1,((V1))->v.v_self[6])            /*  UNWIND-NO-EXIT  */;
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	CDR(((V1))->v.v_self[5]) = Ct;
	princ_str("goto L",symbol_value(VV[16]));
	(*LK8)(1,CAR(((V1))->v.v_self[5]))        /*  WT1             */;
	princ_char(59,symbol_value(VV[16]));
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
static LKF18(int narg, ...) {TRAMPOLINK(VV[54],&LK18);}
static LKF17(int narg, ...) {TRAMPOLINK(VV[50],&LK17);}
static LKF16(int narg, ...) {TRAMPOLINK(VV[49],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[48],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[47],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[46],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[45],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[44],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[43],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[42],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[41],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[40],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[39],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[38],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[37],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[36],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[35],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[34],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[33],&LK0);}
