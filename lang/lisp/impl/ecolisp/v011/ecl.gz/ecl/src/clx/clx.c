
#include "clx.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	Ladjoin(2,VV[1],(VV[0]->s.s_dbind))       /*  ADJOIN          */;
	(VV[0]->s.s_dbind)= VALUES(0);
	Ladjoin(2,VV[2],(VV[0]->s.s_dbind))       /*  ADJOIN          */;
	(VV[0]->s.s_dbind)= VALUES(0);
	siLAmake_special(1,VV[3])                 /*  *MAKE-SPECIAL   */;
	(VV[3]->s.s_dbind)= VV[4];
	Ladjoin(2,VV[5],(VV[0]->s.s_dbind))       /*  ADJOIN          */;
	(VV[0]->s.s_dbind)= VALUES(0);
	Ladjoin(2,VV[6],(VV[0]->s.s_dbind))       /*  ADJOIN          */;
	(VV[0]->s.s_dbind)= VALUES(0);
	siLAmake_special(1,VV[7])                 /*  *MAKE-SPECIAL   */;
	(VV[7]->s.s_dbind)= MAKE_FIXNUM(11);
	siLAmake_special(1,VV[8])                 /*  *MAKE-SPECIAL   */;
	(VV[8]->s.s_dbind)= MAKE_FIXNUM(0);
	siLAmake_special(1,VV[9])                 /*  *MAKE-SPECIAL   */;
	(VV[9]->s.s_dbind)= MAKE_FIXNUM(6000);
	putprop(VV[10],VV[12],VV[11]);
	VV[427] = make_cfun(LC1,Cnil,&Cblock);
	VALUES(0) = VV[427];
	putprop(VV[10],VALUES(0),VV[13]);
	putprop(VV[10],Cnil,VV[15]);
	putprop(VV[16],VV[17],VV[11]);
	VV[428] = make_cfun(LC2,Cnil,&Cblock);
	VALUES(0) = VV[428];
	putprop(VV[16],VALUES(0),VV[13]);
	putprop(VV[16],Cnil,VV[15]);
	putprop(VV[19],VV[20],VV[11]);
	VV[429] = make_cfun(LC3,Cnil,&Cblock);
	VALUES(0) = VV[429];
	putprop(VV[19],VALUES(0),VV[13]);
	putprop(VV[19],Cnil,VV[15]);
	putprop(VV[22],VV[23],VV[11]);
	VV[430] = make_cfun(LC4,Cnil,&Cblock);
	VALUES(0) = VV[430];
	putprop(VV[22],VALUES(0),VV[13]);
	putprop(VV[22],Cnil,VV[15]);
	putprop(VV[25],VV[26],VV[11]);
	VV[431] = make_cfun(LC5,Cnil,&Cblock);
	VALUES(0) = VV[431];
	putprop(VV[25],VALUES(0),VV[13]);
	putprop(VV[25],Cnil,VV[15]);
	putprop(VV[28],VV[29],VV[11]);
	VV[432] = make_cfun(LC6,Cnil,&Cblock);
	VALUES(0) = VV[432];
	putprop(VV[28],VALUES(0),VV[13]);
	putprop(VV[28],Cnil,VV[15]);
	putprop(VV[31],VV[32],VV[11]);
	VV[433] = make_cfun(LC7,Cnil,&Cblock);
	VALUES(0) = VV[433];
	putprop(VV[31],VALUES(0),VV[13]);
	putprop(VV[31],Cnil,VV[15]);
	putprop(VV[34],VV[35],VV[11]);
	VV[434] = make_cfun(LC8,Cnil,&Cblock);
	VALUES(0) = VV[434];
	putprop(VV[34],VALUES(0),VV[13]);
	putprop(VV[34],Cnil,VV[15]);
	putprop(VV[37],VV[38],VV[11]);
	VV[435] = make_cfun(LC9,Cnil,&Cblock);
	VALUES(0) = VV[435];
	putprop(VV[37],VALUES(0),VV[13]);
	putprop(VV[37],Cnil,VV[15]);
	putprop(VV[40],VV[41],VV[11]);
	VV[436] = make_cfun(LC10,Cnil,&Cblock);
	VALUES(0) = VV[436];
	putprop(VV[40],VALUES(0),VV[13]);
	putprop(VV[40],Cnil,VV[15]);
	putprop(VV[43],VV[44],VV[11]);
	VALUES(0) = make_cfun(LC12,Cnil,&Cblock);
	putprop(VV[43],VALUES(0),VV[13]);
	putprop(VV[43],Cnil,VV[15]);
	putprop(VV[52],VV[53],VV[11]);
	VV[437] = make_cfun(LC13,Cnil,&Cblock);
	VALUES(0) = VV[437];
	putprop(VV[52],VALUES(0),VV[13]);
	putprop(VV[52],Cnil,VV[15]);
	putprop(VV[55],VV[56],VV[11]);
	VV[438] = make_cfun(LC14,Cnil,&Cblock);
	VALUES(0) = VV[438];
	putprop(VV[55],VALUES(0),VV[13]);
	putprop(VV[55],Cnil,VV[15]);
	putprop(VV[58],VV[59],VV[11]);
	VV[439] = make_cfun(LC15,Cnil,&Cblock);
	VALUES(0) = VV[439];
	putprop(VV[58],VALUES(0),VV[13]);
	putprop(VV[58],Cnil,VV[15]);
	putprop(VV[61],VV[62],VV[11]);
	VV[440] = make_cfun(LC16,Cnil,&Cblock);
	VALUES(0) = VV[440];
	putprop(VV[61],VALUES(0),VV[13]);
	putprop(VV[61],Cnil,VV[15]);
	putprop(VV[63],VV[64],VV[11]);
	VV[441] = make_cfun(LC17,Cnil,&Cblock);
	VALUES(0) = VV[441];
	putprop(VV[63],VALUES(0),VV[13]);
	putprop(VV[63],Cnil,VV[15]);
	putprop(VV[65],VV[66],VV[11]);
	VV[442] = make_cfun(LC18,Cnil,&Cblock);
	VALUES(0) = VV[442];
	putprop(VV[65],VALUES(0),VV[13]);
	putprop(VV[65],Cnil,VV[15]);
	putprop(VV[68],VV[69],VV[11]);
	VV[443] = make_cfun(LC19,Cnil,&Cblock);
	VALUES(0) = VV[443];
	putprop(VV[68],VALUES(0),VV[13]);
	putprop(VV[68],Cnil,VV[15]);
	putprop(VV[71],VV[72],VV[11]);
	VV[444] = make_cfun(LC20,Cnil,&Cblock);
	VALUES(0) = VV[444];
	putprop(VV[71],VALUES(0),VV[13]);
	putprop(VV[71],Cnil,VV[15]);
	putprop(VV[73],VV[74],VV[11]);
	VALUES(0) = VV[440];
	putprop(VV[73],VALUES(0),VV[13]);
	putprop(VV[73],Cnil,VV[15]);
	funcall(2,VV[445]->s.s_gfdef,VV[75])      /*  FIND-CLASS      */;
	funcall(9,VV[446]->s.s_gfdef,VALUES(0),VV[76],VV[77],VV[78],Cnil,VV[79],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[445]->s.s_gfdef,VV[76])      /*  FIND-CLASS      */;
	VV[447] = make_cfun(LC22,Cnil,&Cblock);
	VALUES(0) = VV[447];
	funcall(8,VV[448]->s.s_gfdef,VV[80],Cnil,VV[81],VV[82],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	funcall(13,VV[449]->s.s_gfdef,VV[76],VV[84],Cnil,Cnil,VV[85],VV[86],Cnil,Cnil,VV[87],VV[88],MAKE_FIXNUM(3),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0(VV[450],L23);
	(void)putprop(VV[450],VV[Vdeb450],VV[451]);
	funcall(5,VV[452]->s.s_gfdef,VV[76],Cnil,Cnil,Cnil)/*  MAKE-PREDICATE*/;
	siLfset(2,VV[89],VALUES(0))               /*  FSET            */;
	MF0(VV[87],L24);
	(void)putprop(VV[87],VV[Vdeb87],VV[451]);
	MF0key(VV[453],L26,3,L26keys);
	(void)putprop(VV[453],VV[Vdeb453],VV[451]);
	MF0(VV[454],L27);
	(void)putprop(VV[454],VV[Vdeb454],VV[451]);
	funcall(2,VV[445]->s.s_gfdef,VV[75])      /*  FIND-CLASS      */;
	funcall(9,VV[446]->s.s_gfdef,VALUES(0),VV[93],VV[94],VV[95],Cnil,VV[96],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[445]->s.s_gfdef,VV[93])      /*  FIND-CLASS      */;
	funcall(13,VV[449]->s.s_gfdef,VV[93],VV[97],Cnil,Cnil,VV[98],VV[99],Cnil,Cnil,Cnil,VV[100],MAKE_FIXNUM(3),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[455],L28,3,L28keys);
	(void)putprop(VV[455],VV[Vdeb455],VV[451]);
	funcall(5,VV[452]->s.s_gfdef,VV[93],Cnil,Cnil,Cnil)/*  MAKE-PREDICATE*/;
	siLfset(2,VV[101],VALUES(0))              /*  FSET            */;
	funcall(2,VV[445]->s.s_gfdef,VV[75])      /*  FIND-CLASS      */;
	funcall(9,VV[446]->s.s_gfdef,VALUES(0),VV[102],VV[103],VV[104],Cnil,VV[105],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[445]->s.s_gfdef,VV[102])     /*  FIND-CLASS      */;
	funcall(13,VV[449]->s.s_gfdef,VV[102],VV[106],Cnil,Cnil,VV[107],VV[108],Cnil,Cnil,Cnil,VV[109],MAKE_FIXNUM(3),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[456],L29,3,L29keys);
	(void)putprop(VV[456],VV[Vdeb456],VV[451]);
	funcall(5,VV[452]->s.s_gfdef,VV[102],Cnil,Cnil,Cnil)/*  MAKE-PREDICATE*/;
	siLfset(2,VV[110],VALUES(0))              /*  FSET            */;
	siLAmake_special(1,VV[111])               /*  *MAKE-SPECIAL   */;
	(VV[111]->s.s_dbind)= MAKE_FIXNUM(200);
	siLAmake_special(1,VV[112])               /*  *MAKE-SPECIAL   */;
	(VV[112]->s.s_dbind)= MAKE_FIXNUM(500);
	funcall(2,VV[445]->s.s_gfdef,VV[75])      /*  FIND-CLASS      */;
	funcall(9,VV[446]->s.s_gfdef,VALUES(0),VV[113],VV[114],VV[115],Cnil,VV[116],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[445]->s.s_gfdef,VV[113])     /*  FIND-CLASS      */;
	VV[457] = make_cfun(LC30,Cnil,&Cblock);
	VALUES(0) = VV[457];
	funcall(8,VV[448]->s.s_gfdef,VV[80],Cnil,VV[117],VV[118],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	funcall(13,VV[449]->s.s_gfdef,VV[113],VV[119],Cnil,Cnil,VV[120],VV[121],Cnil,VV[122],VV[123],VV[124],MAKE_FIXNUM(69),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[458],L31,69,L31keys);
	(void)putprop(VV[458],VV[Vdeb458],VV[451]);
	funcall(5,VV[452]->s.s_gfdef,VV[113],Cnil,Cnil,Cnil)/*  MAKE-PREDICATE*/;
	siLfset(2,VV[148],VALUES(0))              /*  FSET            */;
	MF0(VV[459],L32);
	(void)putprop(VV[459],VV[Vdeb459],VV[451]);
	MF0(VV[123],L33);
	(void)putprop(VV[123],VV[Vdeb123],VV[451]);
	funcall(2,VV[445]->s.s_gfdef,VV[75])      /*  FIND-CLASS      */;
	funcall(9,VV[446]->s.s_gfdef,VALUES(0),VV[154],VV[155],VV[156],Cnil,VV[157],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[445]->s.s_gfdef,VV[154])     /*  FIND-CLASS      */;
	VV[460] = make_cfun(LC35,Cnil,&Cblock);
	VALUES(0) = VV[460];
	funcall(8,VV[448]->s.s_gfdef,VV[80],Cnil,VV[158],VV[159],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	funcall(13,VV[449]->s.s_gfdef,VV[154],VV[160],Cnil,Cnil,VV[161],VV[162],Cnil,Cnil,VV[163],VV[164],MAKE_FIXNUM(3),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[461],L36,3,L36keys);
	(void)putprop(VV[461],VV[Vdeb461],VV[451]);
	funcall(5,VV[452]->s.s_gfdef,VV[154],Cnil,Cnil,Cnil)/*  MAKE-PREDICATE*/;
	siLfset(2,VV[165],VALUES(0))              /*  FSET            */;
	MF0(VV[163],L37);
	(void)putprop(VV[163],VV[Vdeb163],VV[451]);
	funcall(2,VV[445]->s.s_gfdef,VV[75])      /*  FIND-CLASS      */;
	funcall(9,VV[446]->s.s_gfdef,VALUES(0),VV[167],VV[168],Cnil,Cnil,VV[169],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[445]->s.s_gfdef,VV[167])     /*  FIND-CLASS      */;
	VV[462] = make_cfun(LC39,Cnil,&Cblock);
	VALUES(0) = VV[462];
	funcall(8,VV[448]->s.s_gfdef,VV[80],Cnil,VV[170],VV[171],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	funcall(13,VV[449]->s.s_gfdef,VV[167],VV[172],Cnil,Cnil,Cnil,VV[173],Cnil,VV[154],VV[163],VV[174],MAKE_FIXNUM(3),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[463],L40,3,L40keys);
	(void)putprop(VV[463],VV[Vdeb463],VV[451]);
	funcall(5,VV[452]->s.s_gfdef,VV[167],Cnil,Cnil,Cnil)/*  MAKE-PREDICATE*/;
	siLfset(2,VV[175],VALUES(0))              /*  FSET            */;
	funcall(2,VV[445]->s.s_gfdef,VV[75])      /*  FIND-CLASS      */;
	funcall(9,VV[446]->s.s_gfdef,VALUES(0),VV[176],VV[177],Cnil,Cnil,VV[178],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[445]->s.s_gfdef,VV[176])     /*  FIND-CLASS      */;
	VV[464] = make_cfun(LC41,Cnil,&Cblock);
	VALUES(0) = VV[464];
	funcall(8,VV[448]->s.s_gfdef,VV[80],Cnil,VV[179],VV[180],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	funcall(13,VV[449]->s.s_gfdef,VV[176],VV[181],Cnil,Cnil,Cnil,VV[182],Cnil,VV[154],VV[163],VV[183],MAKE_FIXNUM(3),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[465],L42,3,L42keys);
	(void)putprop(VV[465],VV[Vdeb465],VV[451]);
	funcall(5,VV[452]->s.s_gfdef,VV[176],Cnil,Cnil,Cnil)/*  MAKE-PREDICATE*/;
	siLfset(2,VV[184],VALUES(0))              /*  FSET            */;
	funcall(2,VV[445]->s.s_gfdef,VV[75])      /*  FIND-CLASS      */;
	funcall(9,VV[446]->s.s_gfdef,VALUES(0),VV[185],VV[186],VV[187],Cnil,VV[188],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[445]->s.s_gfdef,VV[185])     /*  FIND-CLASS      */;
	VV[466] = make_cfun(LC43,Cnil,&Cblock);
	VALUES(0) = VV[466];
	funcall(8,VV[448]->s.s_gfdef,VV[80],Cnil,VV[189],VV[190],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	funcall(13,VV[449]->s.s_gfdef,VV[185],VV[191],Cnil,Cnil,VV[192],VV[193],Cnil,Cnil,VV[194],VV[195],MAKE_FIXNUM(9),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[467],L44,9,L44keys);
	(void)putprop(VV[467],VV[Vdeb467],VV[451]);
	funcall(5,VV[452]->s.s_gfdef,VV[185],Cnil,Cnil,Cnil)/*  MAKE-PREDICATE*/;
	siLfset(2,VV[197],VALUES(0))              /*  FSET            */;
	MF0(VV[194],L45);
	(void)putprop(VV[194],VV[Vdeb194],VV[451]);
	funcall(2,VV[445]->s.s_gfdef,VV[75])      /*  FIND-CLASS      */;
	funcall(9,VV[446]->s.s_gfdef,VALUES(0),VV[201],VV[202],VV[203],Cnil,VV[204],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[445]->s.s_gfdef,VV[201])     /*  FIND-CLASS      */;
	VV[468] = make_cfun(LC47,Cnil,&Cblock);
	VALUES(0) = VV[468];
	funcall(8,VV[448]->s.s_gfdef,VV[80],Cnil,VV[205],VV[206],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	funcall(13,VV[449]->s.s_gfdef,VV[201],VV[207],Cnil,Cnil,VV[208],VV[209],Cnil,Cnil,VV[210],VV[211],MAKE_FIXNUM(3),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[469],L48,3,L48keys);
	(void)putprop(VV[469],VV[Vdeb469],VV[451]);
	funcall(5,VV[452]->s.s_gfdef,VV[201],Cnil,Cnil,Cnil)/*  MAKE-PREDICATE*/;
	siLfset(2,VV[212],VALUES(0))              /*  FSET            */;
	MF0(VV[210],L49);
	(void)putprop(VV[210],VV[Vdeb210],VV[451]);
	funcall(2,VV[445]->s.s_gfdef,VV[75])      /*  FIND-CLASS      */;
	funcall(9,VV[446]->s.s_gfdef,VALUES(0),VV[215],VV[216],VV[217],Cnil,VV[218],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[445]->s.s_gfdef,VV[215])     /*  FIND-CLASS      */;
	VV[470] = make_cfun(LC51,Cnil,&Cblock);
	VALUES(0) = VV[470];
	funcall(8,VV[448]->s.s_gfdef,VV[80],Cnil,VV[219],VV[220],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	funcall(13,VV[449]->s.s_gfdef,VV[215],VV[221],Cnil,Cnil,VV[222],VV[223],Cnil,Cnil,VV[224],VV[225],MAKE_FIXNUM(2),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[471],L52,2,L52keys);
	(void)putprop(VV[471],VV[Vdeb471],VV[451]);
	funcall(5,VV[452]->s.s_gfdef,VV[215],Cnil,Cnil,Cnil)/*  MAKE-PREDICATE*/;
	siLfset(2,VV[226],VALUES(0))              /*  FSET            */;
	MF0(VV[224],L53);
	(void)putprop(VV[224],VV[Vdeb224],VV[451]);
	putprop(VV[228],VV[229],VV[11]);
	VV[472] = make_cfun(LC55,Cnil,&Cblock);
	VALUES(0) = VV[472];
	putprop(VV[228],VALUES(0),VV[13]);
	putprop(VV[228],Cnil,VV[15]);
	siLAmake_constant(2,VV[231],VV[232])      /*  *MAKE-CONSTANT  */;
	putprop(VV[233],VV[234],VV[11]);
	VV[473] = make_cfun(LC56,Cnil,&Cblock);
	VALUES(0) = VV[473];
	putprop(VV[233],VALUES(0),VV[13]);
	putprop(VV[233],Cnil,VV[15]);
	putprop(VV[236],VV[237],VV[11]);
	VV[474] = make_cfun(LC57,Cnil,&Cblock);
	VALUES(0) = VV[474];
	putprop(VV[236],VALUES(0),VV[13]);
	putprop(VV[236],Cnil,VV[15]);
	putprop(VV[239],VV[240],VV[11]);
	VV[475] = make_cfun(LC58,Cnil,&Cblock);
	VALUES(0) = VV[475];
	putprop(VV[239],VALUES(0),VV[13]);
	putprop(VV[239],Cnil,VV[15]);
	siLAmake_constant(2,VV[242],VV[243])      /*  *MAKE-CONSTANT  */;
	putprop(VV[244],VV[245],VV[11]);
	VV[476] = make_cfun(LC59,Cnil,&Cblock);
	VALUES(0) = VV[476];
	putprop(VV[244],VALUES(0),VV[13]);
	putprop(VV[244],Cnil,VV[15]);
	siLAmake_constant(2,VV[247],VV[248])      /*  *MAKE-CONSTANT  */;
	putprop(VV[249],VV[250],VV[11]);
	VV[477] = make_cfun(LC60,Cnil,&Cblock);
	VALUES(0) = VV[477];
	putprop(VV[249],VALUES(0),VV[13]);
	putprop(VV[249],Cnil,VV[15]);
	putprop(VV[252],VV[253],VV[11]);
	VV[478] = make_cfun(LC61,Cnil,&Cblock);
	VALUES(0) = VV[478];
	putprop(VV[252],VALUES(0),VV[13]);
	putprop(VV[252],Cnil,VV[15]);
	putprop(VV[255],VV[256],VV[11]);
	VV[479] = make_cfun(LC62,Cnil,&Cblock);
	VALUES(0) = VV[479];
	putprop(VV[255],VALUES(0),VV[13]);
	putprop(VV[255],Cnil,VV[15]);
	putprop(VV[257],VV[258],VV[11]);
	VV[480] = make_cfun(LC63,Cnil,&Cblock);
	VALUES(0) = VV[480];
	putprop(VV[257],VALUES(0),VV[13]);
	putprop(VV[257],Cnil,VV[15]);
	putprop(VV[260],VV[261],VV[11]);
	VV[481] = make_cfun(LC64,Cnil,&Cblock);
	VALUES(0) = VV[481];
	putprop(VV[260],VALUES(0),VV[13]);
	putprop(VV[260],Cnil,VV[15]);
	putprop(VV[263],VV[264],VV[11]);
	VV[482] = make_cfun(LC65,Cnil,&Cblock);
	VALUES(0) = VV[482];
	putprop(VV[263],VALUES(0),VV[13]);
	putprop(VV[263],Cnil,VV[15]);
	putprop(VV[266],VV[267],VV[11]);
	VV[483] = make_cfun(LC66,Cnil,&Cblock);
	VALUES(0) = VV[483];
	putprop(VV[266],VALUES(0),VV[13]);
	putprop(VV[266],Cnil,VV[15]);
	putprop(VV[269],VV[270],VV[11]);
	VV[484] = make_cfun(LC67,Cnil,&Cblock);
	VALUES(0) = VV[484];
	putprop(VV[269],VALUES(0),VV[13]);
	putprop(VV[269],Cnil,VV[15]);
	putprop(VV[272],VV[273],VV[11]);
	VV[485] = make_cfun(LC68,Cnil,&Cblock);
	VALUES(0) = VV[485];
	putprop(VV[272],VALUES(0),VV[13]);
	putprop(VV[272],Cnil,VV[15]);
	funcall(2,VV[445]->s.s_gfdef,VV[75])      /*  FIND-CLASS      */;
	funcall(9,VV[446]->s.s_gfdef,VALUES(0),VV[275],VV[276],VV[277],Cnil,VV[278],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[445]->s.s_gfdef,VV[275])     /*  FIND-CLASS      */;
	VV[486] = make_cfun(LC69,Cnil,&Cblock);
	VALUES(0) = VV[486];
	funcall(8,VV[448]->s.s_gfdef,VV[80],Cnil,VV[279],VV[280],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	funcall(13,VV[449]->s.s_gfdef,VV[275],VV[281],Cnil,Cnil,VV[282],VV[283],Cnil,Cnil,VV[284],VV[285],MAKE_FIXNUM(8),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[487],L70,8,L70keys);
	(void)putprop(VV[487],VV[Vdeb487],VV[451]);
	funcall(5,VV[452]->s.s_gfdef,VV[275],Cnil,Cnil,Cnil)/*  MAKE-PREDICATE*/;
	siLfset(2,VV[286],VALUES(0))              /*  FSET            */;
	MF0(VV[284],L71);
	(void)putprop(VV[284],VV[Vdeb284],VV[451]);
	siLAmake_constant(2,VV[288],VV[289])      /*  *MAKE-CONSTANT  */;
	putprop(VV[290],VV[291],VV[11]);
	VV[488] = make_cfun(LC73,Cnil,&Cblock);
	VALUES(0) = VV[488];
	putprop(VV[290],VALUES(0),VV[13]);
	putprop(VV[290],Cnil,VV[15]);
	putprop(VV[293],VV[294],VV[11]);
	VV[489] = make_cfun(LC74,Cnil,&Cblock);
	VALUES(0) = VV[489];
	putprop(VV[293],VALUES(0),VV[13]);
	putprop(VV[293],Cnil,VV[15]);
	siLAmake_constant(2,VV[296],VV[297])      /*  *MAKE-CONSTANT  */;
	putprop(VV[298],VV[299],VV[11]);
	VV[490] = make_cfun(LC75,Cnil,&Cblock);
	VALUES(0) = VV[490];
	putprop(VV[298],VALUES(0),VV[13]);
	putprop(VV[298],Cnil,VV[15]);
	putprop(VV[301],VV[302],VV[11]);
	VV[491] = make_cfun(LC76,Cnil,&Cblock);
	VALUES(0) = VV[491];
	putprop(VV[301],VALUES(0),VV[13]);
	putprop(VV[301],Cnil,VV[15]);
	siLAmake_constant(2,VV[304],VV[305])      /*  *MAKE-CONSTANT  */;
	putprop(VV[306],VV[307],VV[11]);
	VV[492] = make_cfun(LC77,Cnil,&Cblock);
	VALUES(0) = VV[492];
	putprop(VV[306],VALUES(0),VV[13]);
	putprop(VV[306],Cnil,VV[15]);
	putprop(VV[309],VV[310],VV[11]);
	VV[493] = make_cfun(LC78,Cnil,&Cblock);
	VALUES(0) = VV[493];
	putprop(VV[309],VALUES(0),VV[13]);
	putprop(VV[309],Cnil,VV[15]);
	siLAmake_constant(2,VV[312],VV[313])      /*  *MAKE-CONSTANT  */;
	putprop(VV[314],VV[315],VV[11]);
	VV[494] = make_cfun(LC79,Cnil,&Cblock);
	VALUES(0) = VV[494];
	putprop(VV[314],VALUES(0),VV[13]);
	putprop(VV[314],Cnil,VV[15]);
	putprop(VV[317],VV[318],VV[11]);
	VV[495] = make_cfun(LC80,Cnil,&Cblock);
	VALUES(0) = VV[495];
	putprop(VV[317],VALUES(0),VV[13]);
	putprop(VV[317],Cnil,VV[15]);
	putprop(VV[320],VV[321],VV[11]);
	VV[496] = make_cfun(LC81,Cnil,&Cblock);
	VALUES(0) = VV[496];
	putprop(VV[320],VALUES(0),VV[13]);
	putprop(VV[320],Cnil,VV[15]);
	siLAmake_constant(2,VV[323],VV[324])      /*  *MAKE-CONSTANT  */;
	putprop(VV[325],VV[326],VV[11]);
	VV[497] = make_cfun(LC82,Cnil,&Cblock);
	VALUES(0) = VV[497];
	putprop(VV[325],VALUES(0),VV[13]);
	putprop(VV[325],Cnil,VV[15]);
	putprop(VV[328],VV[329],VV[11]);
	VV[498] = make_cfun(LC83,Cnil,&Cblock);
	VALUES(0) = VV[498];
	putprop(VV[328],VALUES(0),VV[13]);
	putprop(VV[328],Cnil,VV[15]);
	putprop(VV[331],VV[332],VV[11]);
	VV[499] = make_cfun(LC84,Cnil,&Cblock);
	VALUES(0) = VV[499];
	putprop(VV[331],VALUES(0),VV[13]);
	putprop(VV[331],Cnil,VV[15]);
	putprop(VV[334],VV[335],VV[11]);
	VV[500] = make_cfun(LC85,Cnil,&Cblock);
	VALUES(0) = VV[500];
	putprop(VV[334],VALUES(0),VV[13]);
	putprop(VV[334],Cnil,VV[15]);
	siLAmake_constant(2,VV[337],VV[338])      /*  *MAKE-CONSTANT  */;
	putprop(VV[339],VV[340],VV[11]);
	VV[501] = make_cfun(LC86,Cnil,&Cblock);
	VALUES(0) = VV[501];
	putprop(VV[339],VALUES(0),VV[13]);
	putprop(VV[339],Cnil,VV[15]);
	funcall(2,VV[445]->s.s_gfdef,VV[75])      /*  FIND-CLASS      */;
	funcall(9,VV[446]->s.s_gfdef,VALUES(0),VV[342],VV[343],VV[344],Cnil,VV[345],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[445]->s.s_gfdef,VV[342])     /*  FIND-CLASS      */;
	VV[502] = make_cfun(LC87,Cnil,&Cblock);
	VALUES(0) = VV[502];
	funcall(8,VV[448]->s.s_gfdef,VV[80],Cnil,VV[346],VV[347],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	funcall(13,VV[449]->s.s_gfdef,VV[342],VV[348],Cnil,Cnil,VV[349],VV[350],Cnil,Cnil,VV[351],VV[352],MAKE_FIXNUM(17),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[503],L88,17,L88keys);
	(void)putprop(VV[503],VV[Vdeb503],VV[451]);
	funcall(5,VV[452]->s.s_gfdef,VV[342],Cnil,Cnil,Cnil)/*  MAKE-PREDICATE*/;
	siLfset(2,VV[354],VALUES(0))              /*  FSET            */;
	MF0(VV[351],L89);
	(void)putprop(VV[351],VV[Vdeb351],VV[451]);
	MF0(VV[504],L91);
	(void)putprop(VV[504],VV[Vdeb504],VV[451]);
	putprop(VV[360],VV[361],VV[11]);
	VV[505] = make_cfun(LC92,Cnil,&Cblock);
	VALUES(0) = VV[505];
	putprop(VV[360],VALUES(0),VV[13]);
	putprop(VV[360],Cnil,VV[15]);
	funcall(2,VV[445]->s.s_gfdef,VV[75])      /*  FIND-CLASS      */;
	funcall(9,VV[446]->s.s_gfdef,VALUES(0),VV[362],VV[363],VV[364],Cnil,VV[365],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[445]->s.s_gfdef,VV[362])     /*  FIND-CLASS      */;
	funcall(13,VV[449]->s.s_gfdef,VV[362],VV[366],Cnil,Cnil,VV[367],VV[368],Cnil,Cnil,Cnil,VV[369],MAKE_FIXNUM(14),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[506],L93,14,L93keys);
	(void)putprop(VV[506],VV[Vdeb506],VV[451]);
	funcall(2,VV[445]->s.s_gfdef,VV[75])      /*  FIND-CLASS      */;
	funcall(9,VV[446]->s.s_gfdef,VALUES(0),VV[371],VV[372],VV[373],Cnil,VV[374],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[445]->s.s_gfdef,VV[371])     /*  FIND-CLASS      */;
	VV[507] = make_cfun(LC94,Cnil,&Cblock);
	VALUES(0) = VV[507];
	funcall(8,VV[448]->s.s_gfdef,VV[80],Cnil,VV[375],VV[376],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	funcall(13,VV[449]->s.s_gfdef,VV[371],VV[377],Cnil,Cnil,VV[378],VV[379],Cnil,Cnil,VV[380],VV[381],MAKE_FIXNUM(8),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[508],L95,8,L95keys);
	(void)putprop(VV[508],VV[Vdeb508],VV[451]);
	funcall(5,VV[452]->s.s_gfdef,VV[371],Cnil,Cnil,Cnil)/*  MAKE-PREDICATE*/;
	siLfset(2,VV[383],VALUES(0))              /*  FSET            */;
	MF0(VV[380],L96);
	(void)putprop(VV[380],VV[Vdeb380],VV[451]);
	MF0(VV[509],L98);
	(void)putprop(VV[509],VV[Vdeb509],VV[451]);
	MF0(VV[510],L99);
	(void)putprop(VV[510],VV[Vdeb510],VV[451]);
	MF0(VV[511],L100);
	(void)putprop(VV[511],VV[Vdeb511],VV[451]);
	MF0key(VV[512],L101,6,L101keys);
	(void)putprop(VV[512],VV[Vdeb512],VV[451]);
	VV[513] = make_cfun(LC102,Cnil,&Cblock);
	VV[514] = make_cfun(LC103,Cnil,&Cblock);
	VV[515] = make_cfun(LC104,Cnil,&Cblock);
	VV[516] = make_cfun(LC105,Cnil,&Cblock);
	VV[517] = make_cfun(LC106,Cnil,&Cblock);
	VV[518] = make_cfun(LC107,Cnil,&Cblock);
	VV[519] = make_cfun(LC108,Cnil,&Cblock);
	VV[520] = make_cfun(LC109,Cnil,&Cblock);
	VV[521] = make_cfun(LC110,Cnil,&Cblock);
	VV[522] = make_cfun(LC111,Cnil,&Cblock);
	VV[523] = make_cfun(LC112,Cnil,&Cblock);
	VV[524] = make_cfun(LC113,Cnil,&Cblock);
	VV[525] = make_cfun(LC114,Cnil,&Cblock);
	VV[526] = make_cfun(LC115,Cnil,&Cblock);
	VALUES(0) = VV[513];
	siLfset(2,VV[394],VALUES(0))              /*  FSET            */;
	VALUES(0) = VV[514];
	siLfset(2,VV[395],VALUES(0))              /*  FSET            */;
	VALUES(0) = VV[515];
	siLfset(2,VV[396],VALUES(0))              /*  FSET            */;
	VALUES(0) = VV[516];
	siLfset(2,VV[397],VALUES(0))              /*  FSET            */;
	VALUES(0) = VV[517];
	siLfset(2,VV[398],VALUES(0))              /*  FSET            */;
	VALUES(0) = VV[518];
	siLfset(2,VV[399],VALUES(0))              /*  FSET            */;
	VALUES(0) = VV[519];
	siLfset(2,VV[400],VALUES(0))              /*  FSET            */;
	VALUES(0) = VV[520];
	siLfset(2,VV[401],VALUES(0))              /*  FSET            */;
	VALUES(0) = VV[521];
	siLfset(2,VV[402],VALUES(0))              /*  FSET            */;
	VALUES(0) = VV[522];
	siLfset(2,VV[403],VALUES(0))              /*  FSET            */;
	VALUES(0) = VV[523];
	siLfset(2,VV[404],VALUES(0))              /*  FSET            */;
	VALUES(0) = VV[524];
	siLfset(2,VV[405],VALUES(0))              /*  FSET            */;
	VALUES(0) = VV[525];
	siLfset(2,VV[406],VALUES(0))              /*  FSET            */;
	VALUES(0) = VV[526];
	siLfset(2,VV[407],VALUES(0))              /*  FSET            */;
	MF0(VV[527],L116);
	(void)putprop(VV[527],VV[Vdeb527],VV[451]);
	VV[528] = make_cfun(LC117,Cnil,&Cblock);
	VV[529] = make_cfun(LC121,Cnil,&Cblock);
	funcall(2,VV[530]->s.s_gfdef,VV[408])     /*  PROCLAIM        */;
	VALUES(0) = VV[528];
	siLfset(2,VV[409],VALUES(0))              /*  FSET            */;
	funcall(2,VV[530]->s.s_gfdef,VV[410])     /*  PROCLAIM        */;
	VALUES(0) = VV[528];
	siLfset(2,VV[411],VALUES(0))              /*  FSET            */;
	funcall(2,VV[530]->s.s_gfdef,VV[412])     /*  PROCLAIM        */;
	VALUES(0) = VV[528];
	siLfset(2,VV[413],VALUES(0))              /*  FSET            */;
	funcall(2,VV[530]->s.s_gfdef,VV[414])     /*  PROCLAIM        */;
	VALUES(0) = VV[528];
	siLfset(2,VV[415],VALUES(0))              /*  FSET            */;
	VALUES(0) = VV[529];
	siLfset(2,VV[416],VALUES(0))              /*  FSET            */;
	funcall(2,VV[530]->s.s_gfdef,VV[417])     /*  PROCLAIM        */;
	VALUES(0) = VV[528];
	siLfset(2,VV[418],VALUES(0))              /*  FSET            */;
	funcall(2,VV[530]->s.s_gfdef,VV[419])     /*  PROCLAIM        */;
	VALUES(0) = VV[528];
	siLfset(2,VV[420],VALUES(0))              /*  FSET            */;
	MF0(VV[531],L124);
	(void)putprop(VV[531],VV[Vdeb531],VV[451]);
	MF0(VV[532],L125);
	(void)putprop(VV[532],VV[Vdeb532],VV[451]);
	VV[421]=string_to_object(VV[421]);
	MF0(VV[533],L126);
	(void)putprop(VV[533],VV[Vdeb533],VV[451]);
	MF0(VV[534],L127);
	(void)putprop(VV[534],VV[Vdeb534],VV[451]);
	MF0(VV[535],L128);
	(void)putprop(VV[535],VV[Vdeb535],VV[451]);
	VV[422]=string_to_object(VV[422]);
	MF0(VV[536],L129);
	(void)putprop(VV[536],VV[Vdeb536],VV[451]);
	VV[423]=string_to_object(VV[423]);
	MF0(VV[537],L130);
	(void)putprop(VV[537],VV[Vdeb537],VV[451]);
	MF0(VV[538],L131);
	(void)putprop(VV[538],VV[Vdeb538],VV[451]);
	MF0(VV[539],L132);
	(void)putprop(VV[539],VV[Vdeb539],VV[451]);
	MF0(VV[540],L133);
	(void)putprop(VV[540],VV[Vdeb540],VV[451]);
	VV[426]=string_to_object(VV[426]);
	MF0(VV[541],L134);
	(void)putprop(VV[541],VV[Vdeb541],VV[451]);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	local function CLOSURE                                        */
static LC121(int narg, object V1, object V2)
{ VT3 VLEX3 CLSR3
	if(!((fix(((V1))->in.in_slots[0]))==(fix(((V2))->in.in_slots[0])))){
	goto L484;}
	VALUES(0) = ((((V1))->in.in_slots[1])==(((V2))->in.in_slots[1])?Ct:Cnil);
	RETURN(1);
L484:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	local function WINDOW-EQUAL                                   */
static LC117(int narg, object V1, object V2)
{ VT4 VLEX4 CLSR4
	VALUES(0) = (((V1))==((V2))?Ct:Cnil);
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC115(int narg, object V1)
{ VT5 VLEX5 CLSR5
	L99(1,(V1))                               /*  FONT-FONT-INFO  */;
	VALUES(0) = (VALUES(0))->in.in_slots[13];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC114(int narg, object V1)
{ VT6 VLEX6 CLSR6
	L99(1,(V1))                               /*  FONT-FONT-INFO  */;
	VALUES(0) = (VALUES(0))->in.in_slots[12];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC113(int narg, object V1)
{ VT7 VLEX7 CLSR7
	L99(1,(V1))                               /*  FONT-FONT-INFO  */;
	VALUES(0) = (VALUES(0))->in.in_slots[11];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC112(int narg, object V1)
{ VT8 VLEX8 CLSR8
	L99(1,(V1))                               /*  FONT-FONT-INFO  */;
	VALUES(0) = (VALUES(0))->in.in_slots[10];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC111(int narg, object V1)
{ VT9 VLEX9 CLSR9
	L99(1,(V1))                               /*  FONT-FONT-INFO  */;
	VALUES(0) = (VALUES(0))->in.in_slots[9];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC110(int narg, object V1)
{ VT10 VLEX10 CLSR10
	L99(1,(V1))                               /*  FONT-FONT-INFO  */;
	VALUES(0) = (VALUES(0))->in.in_slots[8];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC109(int narg, object V1)
{ VT11 VLEX11 CLSR11
	L99(1,(V1))                               /*  FONT-FONT-INFO  */;
	VALUES(0) = (VALUES(0))->in.in_slots[7];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC108(int narg, object V1)
{ VT12 VLEX12 CLSR12
	L99(1,(V1))                               /*  FONT-FONT-INFO  */;
	VALUES(0) = (VALUES(0))->in.in_slots[6];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC107(int narg, object V1)
{ VT13 VLEX13 CLSR13
	L99(1,(V1))                               /*  FONT-FONT-INFO  */;
	VALUES(0) = (VALUES(0))->in.in_slots[5];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC106(int narg, object V1)
{ VT14 VLEX14 CLSR14
	L99(1,(V1))                               /*  FONT-FONT-INFO  */;
	VALUES(0) = (VALUES(0))->in.in_slots[4];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC105(int narg, object V1)
{ VT15 VLEX15 CLSR15
	L99(1,(V1))                               /*  FONT-FONT-INFO  */;
	VALUES(0) = (VALUES(0))->in.in_slots[3];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC104(int narg, object V1)
{ VT16 VLEX16 CLSR16
	L99(1,(V1))                               /*  FONT-FONT-INFO  */;
	VALUES(0) = (VALUES(0))->in.in_slots[2];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC103(int narg, object V1)
{ VT17 VLEX17 CLSR17
	L99(1,(V1))                               /*  FONT-FONT-INFO  */;
	VALUES(0) = (VALUES(0))->in.in_slots[1];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC102(int narg, object V1)
{ VT18 VLEX18 CLSR18
	L99(1,(V1))                               /*  FONT-FONT-INFO  */;
	VALUES(0) = (VALUES(0))->in.in_slots[0];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC94(int narg, object V1, object V2)
{ VT19 VLEX19 CLSR19
	RETURN(L96(3,(V1),(V2),(VV[83]->s.s_dbind))/*  PRINT-FONT     */);
}
/*	local function CLOSURE                                        */
static LC92(int narg)
{ VT20 VLEX20 CLSR20
	VALUES(0) = VV[51];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC87(int narg, object V1, object V2)
{ VT21 VLEX21 CLSR21
	RETURN(L89(3,(V1),(V2),(VV[83]->s.s_dbind))/*  PRINT-SCREEN   */);
}
/*	local function CLOSURE                                        */
static LC86(int narg)
{ VT22 VLEX22 CLSR22
	RETURN(Llist(17,VV[341],MAKE_FIXNUM(0),MAKE_FIXNUM(1),MAKE_FIXNUM(2),MAKE_FIXNUM(3),MAKE_FIXNUM(4),MAKE_FIXNUM(5),MAKE_FIXNUM(6),MAKE_FIXNUM(7),MAKE_FIXNUM(8),MAKE_FIXNUM(9),MAKE_FIXNUM(10),MAKE_FIXNUM(11),MAKE_FIXNUM(12),MAKE_FIXNUM(13),MAKE_FIXNUM(14),MAKE_FIXNUM(15))/*  LIST*/);
}
/*	local function CLOSURE                                        */
static LC85(int narg)
{ VT23 VLEX23 CLSR23
	VALUES(0) = VV[336];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC84(int narg)
{ VT24 VLEX24 CLSR24
	VALUES(0) = VV[333];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC83(int narg)
{ VT25 VLEX25 CLSR25
	VALUES(0) = VV[330];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC82(int narg)
{ VT26 VLEX26 CLSR26
	VALUES(0) = VV[327];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC81(int narg)
{ VT27 VLEX27 CLSR27
	VALUES(0) = VV[322];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC80(int narg)
{ VT28 VLEX28 CLSR28
	VALUES(0) = VV[319];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC79(int narg)
{ VT29 VLEX29 CLSR29
	VALUES(0) = VV[316];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC78(int narg)
{ VT30 VLEX30 CLSR30
	VALUES(0) = VV[311];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC77(int narg)
{ VT31 VLEX31 CLSR31
	VALUES(0) = VV[308];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC76(int narg)
{ VT32 VLEX32 CLSR32
	VALUES(0) = VV[303];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC75(int narg)
{ VT33 VLEX33 CLSR33
	VALUES(0) = VV[300];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC74(int narg)
{ VT34 VLEX34 CLSR34
	VALUES(0) = VV[295];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC73(int narg)
{ VT35 VLEX35 CLSR35
	VALUES(0) = VV[292];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC69(int narg, object V1, object V2)
{ VT36 VLEX36 CLSR36
	RETURN(L71(3,(V1),(V2),(VV[83]->s.s_dbind))/*  PRINT-GCONTEXT */);
}
/*	local function CLOSURE                                        */
static LC68(int narg)
{ VT37 VLEX37 CLSR37
	VALUES(0) = VV[274];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC67(int narg)
{ VT38 VLEX38 CLSR38
	VALUES(0) = VV[271];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC66(int narg)
{ VT39 VLEX39 CLSR39
	VALUES(0) = VV[268];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC65(int narg)
{ VT40 VLEX40 CLSR40
	VALUES(0) = VV[265];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC64(int narg)
{ VT41 VLEX41 CLSR41
	VALUES(0) = VV[262];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC63(int narg, ...)
{ VT42 VLEX42 CLSR42
	{object V1;
	va_list args; va_start(args, narg);
	narg -=0;
	V1=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object p=V1;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	VALUES(0) = VV[259];
	RETURN(1);
	}
}
/*	local function CLOSURE                                        */
static LC62(int narg, object V1, object V2)
{ VT43 VLEX43 CLSR43
	VALUES(0) = VV[51];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC61(int narg)
{ VT44 VLEX44 CLSR44
	VALUES(0) = VV[254];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC60(int narg)
{ VT45 VLEX45 CLSR45
	VALUES(0) = VV[251];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC59(int narg)
{ VT46 VLEX46 CLSR46
	VALUES(0) = VV[246];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC58(int narg)
{ VT47 VLEX47 CLSR47
	VALUES(0) = VV[241];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC57(int narg)
{ VT48 VLEX48 CLSR48
	VALUES(0) = VV[238];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC56(int narg)
{ VT49 VLEX49 CLSR49
	VALUES(0) = VV[235];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC55(int narg)
{ VT50 VLEX50 CLSR50
	VALUES(0) = VV[230];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC51(int narg, object V1, object V2)
{ VT51 VLEX51 CLSR51
	RETURN(L53(3,(V1),(V2),(VV[83]->s.s_dbind))/*  PRINT-CURSOR   */);
}
/*	local function CLOSURE                                        */
static LC47(int narg, object V1, object V2)
{ VT52 VLEX52 CLSR52
	RETURN(L49(3,(V1),(V2),(VV[83]->s.s_dbind))/*  PRINT-COLORMAP */);
}
/*	local function CLOSURE                                        */
static LC43(int narg, object V1, object V2)
{ VT53 VLEX53 CLSR53
	RETURN(L45(3,(V1),(V2),(VV[83]->s.s_dbind))/*  PRINT-VISUAL-INFO*/);
}
/*	local function CLOSURE                                        */
static LC41(int narg, object V1, object V2)
{ VT54 VLEX54 CLSR54
	RETURN(L37(3,(V1),(V2),(VV[83]->s.s_dbind))/*  PRINT-DRAWABLE */);
}
/*	local function CLOSURE                                        */
static LC39(int narg, object V1, object V2)
{ VT55 VLEX55 CLSR55
	RETURN(L37(3,(V1),(V2),(VV[83]->s.s_dbind))/*  PRINT-DRAWABLE */);
}
/*	local function CLOSURE                                        */
static LC35(int narg, object V1, object V2)
{ VT56 VLEX56 CLSR56
	RETURN(L37(3,(V1),(V2),(VV[83]->s.s_dbind))/*  PRINT-DRAWABLE */);
}
/*	local function CLOSURE                                        */
static LC30(int narg, object V1, object V2)
{ VT57 VLEX57 CLSR57
	RETURN(L33(3,(V1),(V2),(VV[83]->s.s_dbind))/*  PRINT-DISPLAY  */);
}
/*	local function CLOSURE                                        */
static LC22(int narg, object V1, object V2)
{ VT58 VLEX58 CLSR58
	RETURN(L24(3,(V1),(V2),(VV[83]->s.s_dbind))/*  PRINT-COLOR    */);
}
/*	local function CLOSURE                                        */
static LC20(int narg)
{ VT59 VLEX59 CLSR59
	VALUES(0) = VV[19];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC19(int narg)
{ VT60 VLEX60 CLSR60
	VALUES(0) = VV[70];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC18(int narg)
{ VT61 VLEX61 CLSR61
	VALUES(0) = VV[67];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC17(int narg)
{ VT62 VLEX62 CLSR62
	VALUES(0) = VV[28];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC16(int narg)
{ VT63 VLEX63 CLSR63
	VALUES(0) = VV[16];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC15(int narg)
{ VT64 VLEX64 CLSR64
	VALUES(0) = VV[60];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC14(int narg)
{ VT65 VLEX65 CLSR65
	VALUES(0) = VV[57];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC13(int narg)
{ VT66 VLEX66 CLSR66
	VALUES(0) = VV[54];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC12(int narg, ...)
{ VT67 VLEX67 CLSR67
	{int i=0;
	object V1;
	object V2;
	va_list args; va_start(args, narg);
	if (i==narg) goto L501;
	V1= va_arg(args, object);
	i++;
	if (i==narg) goto L502;
	V2= va_arg(args, object);
	i++;
	goto L503;
L501:
	V1= VV[45];
L502:
	V2= VV[45];
L503:
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  CONVERT         */
	*CLV0=make_cclosure(LC11,env0,&Cblock);
	LC11(2, env0,(V1),Ct)                     /*  CONVERT         */;
	T0= VALUES(0);
	LC11(2, env0,(V2),Ct)                     /*  CONVERT         */;
	{object V3= list(3,VV[47],T0,VALUES(0));
	LC11(2, env0,(V1),Cnil)                   /*  CONVERT         */;
	T1= VALUES(0);
	LC11(2, env0,(V2),Cnil)                   /*  CONVERT         */;
	VALUES(0) = list(3,VV[46],(V3),list(3,VV[48],T1,VALUES(0)));
	RETURN(1);}
	}
}
/*	local function CLOSURE                                        */
static LC10(int narg)
{ VT68 VLEX68 CLSR68
	VALUES(0) = VV[42];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC9(int narg)
{ VT69 VLEX69 CLSR69
	VALUES(0) = VV[39];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC8(int narg)
{ VT70 VLEX70 CLSR70
	VALUES(0) = VV[36];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC7(int narg)
{ VT71 VLEX71 CLSR71
	VALUES(0) = VV[33];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC6(int narg)
{ VT72 VLEX72 CLSR72
	VALUES(0) = VV[30];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC5(int narg)
{ VT73 VLEX73 CLSR73
	VALUES(0) = VV[27];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC4(int narg)
{ VT74 VLEX74 CLSR74
	VALUES(0) = VV[24];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC3(int narg)
{ VT75 VLEX75 CLSR75
	VALUES(0) = VV[21];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC2(int narg)
{ VT76 VLEX76 CLSR76
	VALUES(0) = VV[18];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC1(int narg)
{ VT77 VLEX77 CLSR77
	VALUES(0) = VV[14];
	RETURN(1);
}
/*	closure CONVERT                                               */
static LC11(int narg, object env0, object V1, object V2)
{ VT78 VLEX78 CLSR78
	narg--;
	{object scan=env0;
	CLV0= &CAR(scan);                         /*  CONVERT         */}
TTL:
	{object V3;
	(*LK0)(2,(V1),VV[49])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L511;}
	if(((V2))==Cnil){
	goto L514;}
	RETURN(Lfloat(2,(V1),VV[50])              /*  FLOAT           */);
L514:
	RETURN(Lrationalp(1,(V1))                 /*  RATIONAL        */);
L511:
	(*LK0)(2,(V1),VV[51])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L517;}
	RETURN((*LK1)(3,VV[51],*CLV0,(V1))        /*  MAP             */);
L517:
	VALUES(0) = (V1);
	RETURN(1);
	}
}
/*	function definition for MAKE-COLOR-INTERNAL                   */
static L23(int narg, object V1, object V2, object V3)
{ VT79 VLEX79 CLSR79
TTL:
	(*LK2)(1,VV[76])                          /*  FIND-CLASS      */;
	RETURN(siLmake_structure(4,VALUES(0),(V1),(V2),(V3))/*  MAKE-STRUCTURE*/);
}
/*	function definition for PRINT-COLOR                           */
static L24(int narg, object V1, object V2, object V3)
{ VT80 VLEX80 CLSR80
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(V1,env0));            /*  COLOR           */
	CLV1=&CAR(env0=CONS(V2,env0));            /*  STREAM          */
	{ object V4;
	V4= make_cclosure(LC25,env0,&Cblock);
	RETURN((*LK3)(5,*CLV0,*CLV1,Ct,Cnil,(V4)) /*  PRINT-UNREADABLE-OBJECT-FUNCTION*/);
	}
}
/*	closure .PRINT-UNREADABLE-OBJECT-BODY.                        */
static LC25(int narg, object env0)
{ VT81 VLEX81 CLSR81
	narg--;
	{object scan=env0;
	CLV1= &CAR(scan);                         /*  STREAM          */ scan=CDR(scan);
	CLV0= &CAR(scan);                         /*  COLOR           */}
TTL:
	prin1((*CLV0)->in.in_slots[0],*CLV1);
	Lwrite_string(2,VV[90],*CLV1)             /*  WRITE-STRING    */;
	prin1((*CLV0)->in.in_slots[1],*CLV1);
	Lwrite_string(2,VV[91],*CLV1)             /*  WRITE-STRING    */;
	VALUES(0) = prin1((*CLV0)->in.in_slots[2],*CLV1);
	RETURN(1);
}
/*	function definition for MAKE-COLOR                            */
static L26(int narg, ...)
{ VT82 VLEX82 CLSR82
	{object V1;
	object V2;
	object V3;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[6];
	parse_key(narg,args,3,L26keys,keyvars,OBJNULL,TRUE);
	if(keyvars[3]==Cnil){
	V1= VV[92];
	}else{
	V1= keyvars[0];}
	if(keyvars[4]==Cnil){
	V2= VV[92];
	}else{
	V2= keyvars[1];}
	if(keyvars[5]==Cnil){
	V3= VV[92];
	}else{
	V3= keyvars[2];}
	}
	RETURN(L23(3,(V1),(V2),(V3))              /*  MAKE-COLOR-INTERNAL*/);
	}
}
/*	function definition for COLOR-RGB                             */
static L27(int narg, object V1)
{ VT83 VLEX83 CLSR83
TTL:
	VALUES(2) = ((V1))->in.in_slots[2];
	VALUES(1) = ((V1))->in.in_slots[1];
	VALUES(0) = ((V1))->in.in_slots[0];
	RETURN(3);
}
/*	function definition for MAKE-BITMAP-FORMAT                    */
static L28(int narg, ...)
{ VT84 VLEX84 CLSR84
	{object V1;
	object V2;
	object V3;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[6];
	parse_key(narg,args,3,L28keys,keyvars,OBJNULL,FALSE);
	if(keyvars[3]==Cnil){
	V1= MAKE_FIXNUM(8);
	}else{
	V1= keyvars[0];}
	if(keyvars[4]==Cnil){
	V2= MAKE_FIXNUM(8);
	}else{
	V2= keyvars[1];}
	V3= keyvars[2];
	}
	(*LK2)(1,VV[93])                          /*  FIND-CLASS      */;
	RETURN(siLmake_structure(4,VALUES(0),(V1),(V2),(V3))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for MAKE-PIXMAP-FORMAT                    */
static L29(int narg, ...)
{ VT85 VLEX85 CLSR85
	{object V1;
	object V2;
	object V3;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[6];
	parse_key(narg,args,3,L29keys,keyvars,OBJNULL,FALSE);
	if(keyvars[3]==Cnil){
	V1= MAKE_FIXNUM(0);
	}else{
	V1= keyvars[0];}
	if(keyvars[4]==Cnil){
	V2= MAKE_FIXNUM(8);
	}else{
	V2= keyvars[1];}
	if(keyvars[5]==Cnil){
	V3= MAKE_FIXNUM(8);
	}else{
	V3= keyvars[2];}
	}
	(*LK2)(1,VV[102])                         /*  FIND-CLASS      */;
	RETURN(siLmake_structure(4,VALUES(0),(V1),(V2),(V3))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for MAKE-DISPLAY-INTERNAL                 */
static L31(int narg, ...)
{ VT86 VLEX86 CLSR86
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	object V10;
	object V11;
	object V12;
	object V13;
	object V14;
	object V15;
	object V16;
	object V17;
	object V18;
	object V19;
	object V20;
	object V21;
	object V22;
	object V23;
	object V24;
	object V25;
	object V26;
	object V27;
	object V28;
	object V29;
	object V30;
	object V31;
	object V32;
	object V33;
	object V34;
	object V35;
	object V36;
	object V37;
	object V38;
	object V39;
	object V40;
	object V41;
	object V42;
	object V43;
	object V44;
	object V45;
	object V46;
	object V47;
	object V48;
	object V49;
	object V50;
	object V51;
	object V52;
	object V53;
	object V54;
	object V55;
	object V56;
	object V57;
	object V58;
	object V59;
	object V60;
	object V61;
	object V62;
	object V63;
	object V64;
	object V65;
	object V66;
	object V67;
	object V68;
	object V69;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[138];
	parse_key(narg,args,69,L31keys,keyvars,OBJNULL,FALSE);
	if(keyvars[69]==Cnil){
	(*LK4)(1,VV[125])                         /*  MAKE-PROCESS-LOCK*/;
	V1= VALUES(0);
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	if(keyvars[71]==Cnil){
	V3= MAKE_FIXNUM(0);
	}else{
	V3= keyvars[2];}
	if(keyvars[72]==Cnil){
	V4= MAKE_FIXNUM(0);
	}else{
	V4= keyvars[3];}
	V5= keyvars[4];
	V6= keyvars[5];
	if(keyvars[75]==Cnil){
	V7= MAKE_FIXNUM(0);
	}else{
	V7= keyvars[6];}
	if(keyvars[76]==Cnil){
	V8= (VV[126]->s.s_dbind);
	}else{
	V8= keyvars[7];}
	if(keyvars[77]==Cnil){
	(*LK5)(4,VV[127],MAKE_FIXNUM(256),VV[128],MAKE_FIXNUM(0))/*  MAKE-SEQUENCE*/;
	V9= VALUES(0);
	}else{
	V9= keyvars[8];}
	V10= keyvars[9];
	V11= keyvars[10];
	V12= keyvars[11];
	if(keyvars[81]==Cnil){
	V13= VV[129];
	}else{
	V13= keyvars[12];}
	if(keyvars[82]==Cnil){
	V14= VV[130];
	}else{
	V14= keyvars[13];}
	if(keyvars[83]==Cnil){
	V15= VV[131];
	}else{
	V15= keyvars[14];}
	if(keyvars[84]==Cnil){
	V16= VV[132];
	}else{
	V16= keyvars[15];}
	if(keyvars[85]==Cnil){
	V17= VV[133];
	}else{
	V17= keyvars[16];}
	if(keyvars[86]==Cnil){
	V18= VV[134];
	}else{
	V18= keyvars[17];}
	V19= keyvars[18];
	if(keyvars[88]==Cnil){
	V20= MAKE_FIXNUM(0);
	}else{
	V20= keyvars[19];}
	V21= keyvars[20];
	if(keyvars[90]==Cnil){
	(*LK4)(1,VV[135])                         /*  MAKE-PROCESS-LOCK*/;
	V22= VALUES(0);
	}else{
	V22= keyvars[21];}
	if(keyvars[91]==Cnil){
	(*LK4)(1,VV[136])                         /*  MAKE-PROCESS-LOCK*/;
	V23= VALUES(0);
	}else{
	V23= keyvars[22];}
	V24= keyvars[23];
	V25= keyvars[24];
	if(keyvars[94]==Cnil){
	VALUES(0) = (VV[629]->s.s_gfdef);
	Lmake_hash_table(4,VV[137],VALUES(0),VV[138],(VV[111]->s.s_dbind))/*  MAKE-HASH-TABLE*/;
	V26= VALUES(0);
	}else{
	V26= keyvars[25];}
	V27= keyvars[26];
	if(keyvars[96]==Cnil){
	V28= MAKE_FIXNUM(0);
	}else{
	V28= keyvars[27];}
	if(keyvars[97]==Cnil){
	V29= MAKE_FIXNUM(0);
	}else{
	V29= keyvars[28];}
	if(keyvars[98]==Cnil){
	V30= VV[139];
	}else{
	V30= keyvars[29];}
	if(keyvars[99]==Cnil){
	V31= MAKE_FIXNUM(0);
	}else{
	V31= keyvars[30];}
	if(keyvars[100]==Cnil){
	V32= MAKE_FIXNUM(0);
	}else{
	V32= keyvars[31];}
	V33= keyvars[32];
	if(keyvars[102]==Cnil){
	V34= MAKE_FIXNUM(0);
	}else{
	V34= keyvars[33];}
	if(keyvars[103]==Cnil){
	VALUES(0) = (VV[630]->s.s_gfdef);
	Lmake_hash_table(4,VV[137],VALUES(0),VV[138],(VV[112]->s.s_dbind))/*  MAKE-HASH-TABLE*/;
	V35= VALUES(0);
	}else{
	V35= keyvars[34];}
	if(keyvars[104]==Cnil){
	V36= VV[140];
	}else{
	V36= keyvars[35];}
	if(keyvars[105]==Cnil){
	V37= VV[141];
	}else{
	V37= keyvars[36];}
	if(keyvars[106]==Cnil){
	V38= MAKE_FIXNUM(0);
	}else{
	V38= keyvars[37];}
	if(keyvars[107]==Cnil){
	V39= MAKE_FIXNUM(0);
	}else{
	V39= keyvars[38];}
	V40= keyvars[39];
	V41= keyvars[40];
	if(keyvars[110]==Cnil){
	V42= MAKE_FIXNUM(0);
	}else{
	V42= keyvars[41];}
	V43= keyvars[42];
	V44= keyvars[43];
	if(keyvars[113]==Cnil){
	L28(0)                                    /*  MAKE-BITMAP-FORMAT*/;
	V45= VALUES(0);
	}else{
	V45= keyvars[44];}
	V46= keyvars[45];
	if(keyvars[115]==Cnil){
	V47= MAKE_FIXNUM(0);
	}else{
	V47= keyvars[46];}
	if(keyvars[116]==Cnil){
	V48= MAKE_FIXNUM(0);
	}else{
	V48= keyvars[47];}
	if(keyvars[117]==Cnil){
	V49= VV[142];
	}else{
	V49= keyvars[48];}
	if(keyvars[118]==Cnil){
	V50= VV[143];
	}else{
	V50= keyvars[49];}
	if(keyvars[119]==Cnil){
	V51= VV[144];
	}else{
	V51= keyvars[50];}
	if(keyvars[120]==Cnil){
	V52= VV[145];
	}else{
	V52= keyvars[51];}
	V53= keyvars[52];
	V54= keyvars[53];
	V55= keyvars[54];
	V56= keyvars[55];
	V57= keyvars[56];
	if(keyvars[126]==Cnil){
	V58= VV[146];
	}else{
	V58= keyvars[57];}
	V59= keyvars[58];
	V60= keyvars[59];
	V61= keyvars[60];
	V62= keyvars[61];
	V63= keyvars[62];
	V64= keyvars[63];
	if(keyvars[133]==Cnil){
	V65= VV[147];
	}else{
	V65= keyvars[64];}
	V66= keyvars[65];
	V67= keyvars[66];
	if(keyvars[136]==Cnil){
	Lgensym(0)                                /*  GENSYM          */;
	T0= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V68= list(2,T0,VALUES(0));
	}else{
	V68= keyvars[67];}
	if(keyvars[137]==Cnil){
	VALUES(0) = (VV[630]->s.s_gfdef);
	Lmake_hash_table(4,VV[137],VALUES(0),VV[138],(VV[111]->s.s_dbind))/*  MAKE-HASH-TABLE*/;
	V69= VALUES(0);
	}else{
	V69= keyvars[68];}
	}
	(*LK2)(1,VV[113])                         /*  FIND-CLASS      */;
	RETURN(siLmake_structure(70,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8),(V9),(V10),(V11),(V12),(V13),(V14),(V15),(V16),(V17),(V18),(V19),(V20),(V21),(V22),(V23),(V24),(V25),(V26),(V27),(V28),(V29),(V30),(V31),(V32),(V33),(V34),(V35),(V36),(V37),(V38),(V39),(V40),(V41),(V42),(V43),(V44),(V45),(V46),(V47),(V48),(V49),(V50),(V51),(V52),(V53),(V54),(V55),(V56),(V57),(V58),(V59),(V60),(V61),(V62),(V63),(V64),(V65),(V66),(V67),(V68),(V69))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for PRINT-DISPLAY-NAME                    */
static L32(int narg, object V1, object V2)
{ VT87 VLEX87 CLSR87
TTL:
	if(((V1))==Cnil){
	goto L581;}
	princ(((V1))->in.in_slots[18],(V2));
	Lwrite_string(2,VV[149],(V2))             /*  WRITE-STRING    */;
	princ(((V1))->in.in_slots[19],(V2));
	goto L579;
L581:
	Lwrite_string(2,VV[150],(V2))             /*  WRITE-STRING    */;
L579:
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for PRINT-DISPLAY                         */
static L33(int narg, object V1, object V2, object V3)
{ VT88 VLEX88 CLSR88
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(V1,env0));            /*  DISPLAY         */
	CLV1=&CAR(env0=CONS(V2,env0));            /*  STREAM          */
	{ object V4;
	V4= make_cclosure(LC34,env0,&Cblock);
	RETURN((*LK3)(5,*CLV0,*CLV1,Ct,Cnil,(V4)) /*  PRINT-UNREADABLE-OBJECT-FUNCTION*/);
	}
}
/*	closure .PRINT-UNREADABLE-OBJECT-BODY.                        */
static LC34(int narg, object env0)
{ VT89 VLEX89 CLSR89
	narg--;
	{object scan=env0;
	CLV1= &CAR(scan);                         /*  STREAM          */ scan=CDR(scan);
	CLV0= &CAR(scan);                         /*  DISPLAY         */}
TTL:
	L32(2,*CLV0,*CLV1)                        /*  PRINT-DISPLAY-NAME*/;
	Lwrite_string(2,VV[151],*CLV1)            /*  WRITE-STRING    */;
	Lwrite_string(2,(*CLV0)->in.in_slots[29],*CLV1)/*  WRITE-STRING*/;
	Lwrite_string(2,VV[152],*CLV1)            /*  WRITE-STRING    */;
	prin1((*CLV0)->in.in_slots[37],*CLV1);
	RETURN(Lwrite_string(2,VV[153],*CLV1)     /*  WRITE-STRING    */);
}
/*	function definition for MAKE-DRAWABLE                         */
static L36(int narg, ...)
{ VT90 VLEX90 CLSR90
	{object V1;
	object V2;
	object V3;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[6];
	parse_key(narg,args,3,L36keys,keyvars,OBJNULL,FALSE);
	if(keyvars[3]==Cnil){
	V1= MAKE_FIXNUM(0);
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	}
	(*LK2)(1,VV[154])                         /*  FIND-CLASS      */;
	RETURN(siLmake_structure(4,VALUES(0),(V1),(V2),(V3))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for PRINT-DRAWABLE                        */
static L37(int narg, object V1, object V2, object V3)
{ VT91 VLEX91 CLSR91
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(V1,env0));            /*  DRAWABLE        */
	CLV1=&CAR(env0=CONS(V2,env0));            /*  STREAM          */
	{ object V4;
	V4= make_cclosure(LC38,env0,&Cblock);
	RETURN((*LK3)(5,*CLV0,*CLV1,Ct,Cnil,(V4)) /*  PRINT-UNREADABLE-OBJECT-FUNCTION*/);
	}
}
/*	closure .PRINT-UNREADABLE-OBJECT-BODY.                        */
static LC38(int narg, object env0)
{ VT92 VLEX92 CLSR92
	narg--;
	{object scan=env0;
	CLV1= &CAR(scan);                         /*  STREAM          */ scan=CDR(scan);
	CLV0= &CAR(scan);                         /*  DRAWABLE        */}
TTL:
	L32(2,(*CLV0)->in.in_slots[1],*CLV1)      /*  PRINT-DISPLAY-NAME*/;
	Lwrite_string(2,VV[166],*CLV1)            /*  WRITE-STRING    */;
	VALUES(0) = prin1((*CLV0)->in.in_slots[0],*CLV1);
	RETURN(1);
}
/*	function definition for MAKE-WINDOW                           */
static L40(int narg, ...)
{ VT93 VLEX93 CLSR93
	{object V1;
	object V2;
	object V3;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[6];
	parse_key(narg,args,3,L40keys,keyvars,OBJNULL,FALSE);
	if(keyvars[3]==Cnil){
	V1= MAKE_FIXNUM(0);
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	}
	(*LK2)(1,VV[167])                         /*  FIND-CLASS      */;
	RETURN(siLmake_structure(4,VALUES(0),(V1),(V2),(V3))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for MAKE-PIXMAP                           */
static L42(int narg, ...)
{ VT94 VLEX94 CLSR94
	{object V1;
	object V2;
	object V3;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[6];
	parse_key(narg,args,3,L42keys,keyvars,OBJNULL,FALSE);
	if(keyvars[3]==Cnil){
	V1= MAKE_FIXNUM(0);
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	}
	(*LK2)(1,VV[176])                         /*  FIND-CLASS      */;
	RETURN(siLmake_structure(4,VALUES(0),(V1),(V2),(V3))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for MAKE-VISUAL-INFO                      */
static L44(int narg, ...)
{ VT95 VLEX95 CLSR95
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[18];
	parse_key(narg,args,9,L44keys,keyvars,OBJNULL,FALSE);
	if(keyvars[9]==Cnil){
	V1= MAKE_FIXNUM(0);
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	if(keyvars[11]==Cnil){
	V3= VV[196];
	}else{
	V3= keyvars[2];}
	if(keyvars[12]==Cnil){
	V4= MAKE_FIXNUM(0);
	}else{
	V4= keyvars[3];}
	if(keyvars[13]==Cnil){
	V5= MAKE_FIXNUM(0);
	}else{
	V5= keyvars[4];}
	if(keyvars[14]==Cnil){
	V6= MAKE_FIXNUM(0);
	}else{
	V6= keyvars[5];}
	if(keyvars[15]==Cnil){
	V7= MAKE_FIXNUM(1);
	}else{
	V7= keyvars[6];}
	if(keyvars[16]==Cnil){
	V8= MAKE_FIXNUM(0);
	}else{
	V8= keyvars[7];}
	V9= keyvars[8];
	}
	(*LK2)(1,VV[185])                         /*  FIND-CLASS      */;
	RETURN(siLmake_structure(10,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8),(V9))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for PRINT-VISUAL-INFO                     */
static L45(int narg, object V1, object V2, object V3)
{ VT96 VLEX96 CLSR96
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(V1,env0));            /*  VISUAL-INFO     */
	CLV1=&CAR(env0=CONS(V2,env0));            /*  STREAM          */
	{ object V4;
	V4= make_cclosure(LC46,env0,&Cblock);
	RETURN((*LK3)(5,*CLV0,*CLV1,Ct,Cnil,(V4)) /*  PRINT-UNREADABLE-OBJECT-FUNCTION*/);
	}
}
/*	closure .PRINT-UNREADABLE-OBJECT-BODY.                        */
static LC46(int narg, object env0)
{ VT97 VLEX97 CLSR97
	narg--;
	{object scan=env0;
	CLV1= &CAR(scan);                         /*  STREAM          */ scan=CDR(scan);
	CLV0= &CAR(scan);                         /*  VISUAL-INFO     */}
TTL:
	prin1((*CLV0)->in.in_slots[6],*CLV1);
	Lwrite_string(2,VV[198],*CLV1)            /*  WRITE-STRING    */;
	princ((*CLV0)->in.in_slots[2],*CLV1);
	Lwrite_string(2,VV[199],*CLV1)            /*  WRITE-STRING    */;
	L32(2,(*CLV0)->in.in_slots[1],*CLV1)      /*  PRINT-DISPLAY-NAME*/;
	Lwrite_string(2,VV[200],*CLV1)            /*  WRITE-STRING    */;
	VALUES(0) = prin1((*CLV0)->in.in_slots[0],*CLV1);
	RETURN(1);
}
/*	function definition for MAKE-COLORMAP                         */
static L48(int narg, ...)
{ VT98 VLEX98 CLSR98
	{object V1;
	object V2;
	object V3;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[6];
	parse_key(narg,args,3,L48keys,keyvars,OBJNULL,FALSE);
	if(keyvars[3]==Cnil){
	V1= MAKE_FIXNUM(0);
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	}
	(*LK2)(1,VV[201])                         /*  FIND-CLASS      */;
	RETURN(siLmake_structure(4,VALUES(0),(V1),(V2),(V3))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for PRINT-COLORMAP                        */
static L49(int narg, object V1, object V2, object V3)
{ VT99 VLEX99 CLSR99
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(V1,env0));            /*  COLORMAP        */
	CLV1=&CAR(env0=CONS(V2,env0));            /*  STREAM          */
	{ object V4;
	V4= make_cclosure(LC50,env0,&Cblock);
	RETURN((*LK3)(5,*CLV0,*CLV1,Ct,Cnil,(V4)) /*  PRINT-UNREADABLE-OBJECT-FUNCTION*/);
	}
}
/*	closure .PRINT-UNREADABLE-OBJECT-BODY.                        */
static LC50(int narg, object env0)
{ VT100 VLEX100 CLSR100
	narg--;
	{object scan=env0;
	CLV1= &CAR(scan);                         /*  STREAM          */ scan=CDR(scan);
	CLV0= &CAR(scan);                         /*  COLORMAP        */}
TTL:
	if(((*CLV0)->in.in_slots[2])==Cnil){
	goto L614;}
	princ(((*CLV0)->in.in_slots[2])->in.in_slots[2],*CLV1);
	Lwrite_string(2,VV[213],*CLV1)            /*  WRITE-STRING    */;
L614:
	L32(2,(*CLV0)->in.in_slots[1],*CLV1)      /*  PRINT-DISPLAY-NAME*/;
	Lwrite_string(2,VV[214],*CLV1)            /*  WRITE-STRING    */;
	VALUES(0) = prin1((*CLV0)->in.in_slots[0],*CLV1);
	RETURN(1);
}
/*	function definition for MAKE-CURSOR                           */
static L52(int narg, ...)
{ VT101 VLEX101 CLSR101
	{object V1;
	object V2;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[4];
	parse_key(narg,args,2,L52keys,keyvars,OBJNULL,FALSE);
	if(keyvars[2]==Cnil){
	V1= MAKE_FIXNUM(0);
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	}
	(*LK2)(1,VV[215])                         /*  FIND-CLASS      */;
	RETURN(siLmake_structure(3,VALUES(0),(V1),(V2))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for PRINT-CURSOR                          */
static L53(int narg, object V1, object V2, object V3)
{ VT102 VLEX102 CLSR102
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(V1,env0));            /*  CURSOR          */
	CLV1=&CAR(env0=CONS(V2,env0));            /*  STREAM          */
	{ object V4;
	V4= make_cclosure(LC54,env0,&Cblock);
	RETURN((*LK3)(5,*CLV0,*CLV1,Ct,Cnil,(V4)) /*  PRINT-UNREADABLE-OBJECT-FUNCTION*/);
	}
}
/*	closure .PRINT-UNREADABLE-OBJECT-BODY.                        */
static LC54(int narg, object env0)
{ VT103 VLEX103 CLSR103
	narg--;
	{object scan=env0;
	CLV1= &CAR(scan);                         /*  STREAM          */ scan=CDR(scan);
	CLV0= &CAR(scan);                         /*  CURSOR          */}
TTL:
	L32(2,(*CLV0)->in.in_slots[1],*CLV1)      /*  PRINT-DISPLAY-NAME*/;
	Lwrite_string(2,VV[227],*CLV1)            /*  WRITE-STRING    */;
	VALUES(0) = prin1((*CLV0)->in.in_slots[0],*CLV1);
	RETURN(1);
}
/*	function definition for MAKE-GCONTEXT                         */
static L70(int narg, ...)
{ VT104 VLEX104 CLSR104
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[16];
	parse_key(narg,args,8,L70keys,keyvars,OBJNULL,FALSE);
	if(keyvars[8]==Cnil){
	V1= MAKE_FIXNUM(0);
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	if(keyvars[11]==Cnil){
	V4= Ct;
	}else{
	V4= keyvars[3];}
	if(keyvars[12]==Cnil){
	(*LK6)(0)                                 /*  ALLOCATE-GCONTEXT-STATE*/;
	V5= VALUES(0);
	}else{
	V5= keyvars[4];}
	if(keyvars[13]==Cnil){
	(*LK6)(0)                                 /*  ALLOCATE-GCONTEXT-STATE*/;
	V6= VALUES(0);
	}else{
	V6= keyvars[5];}
	V7= keyvars[6];
	V8= keyvars[7];
	}
	(*LK2)(1,VV[275])                         /*  FIND-CLASS      */;
	RETURN(siLmake_structure(9,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for PRINT-GCONTEXT                        */
static L71(int narg, object V1, object V2, object V3)
{ VT105 VLEX105 CLSR105
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(V1,env0));            /*  GCONTEXT        */
	CLV1=&CAR(env0=CONS(V2,env0));            /*  STREAM          */
	{ object V4;
	V4= make_cclosure(LC72,env0,&Cblock);
	RETURN((*LK3)(5,*CLV0,*CLV1,Ct,Cnil,(V4)) /*  PRINT-UNREADABLE-OBJECT-FUNCTION*/);
	}
}
/*	closure .PRINT-UNREADABLE-OBJECT-BODY.                        */
static LC72(int narg, object env0)
{ VT106 VLEX106 CLSR106
	narg--;
	{object scan=env0;
	CLV1= &CAR(scan);                         /*  STREAM          */ scan=CDR(scan);
	CLV0= &CAR(scan);                         /*  GCONTEXT        */}
TTL:
	L32(2,(*CLV0)->in.in_slots[1],*CLV1)      /*  PRINT-DISPLAY-NAME*/;
	Lwrite_string(2,VV[287],*CLV1)            /*  WRITE-STRING    */;
	VALUES(0) = prin1((*CLV0)->in.in_slots[0],*CLV1);
	RETURN(1);
}
/*	function definition for MAKE-SCREEN                           */
static L88(int narg, ...)
{ VT107 VLEX107 CLSR107
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	object V10;
	object V11;
	object V12;
	object V13;
	object V14;
	object V15;
	object V16;
	object V17;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[34];
	parse_key(narg,args,17,L88keys,keyvars,OBJNULL,FALSE);
	V1= keyvars[0];
	if(keyvars[18]==Cnil){
	V2= MAKE_FIXNUM(0);
	}else{
	V2= keyvars[1];}
	if(keyvars[19]==Cnil){
	V3= MAKE_FIXNUM(0);
	}else{
	V3= keyvars[2];}
	if(keyvars[20]==Cnil){
	V4= MAKE_FIXNUM(0);
	}else{
	V4= keyvars[3];}
	if(keyvars[21]==Cnil){
	V5= MAKE_FIXNUM(0);
	}else{
	V5= keyvars[4];}
	V6= keyvars[5];
	if(keyvars[23]==Cnil){
	V7= MAKE_FIXNUM(1);
	}else{
	V7= keyvars[6];}
	V8= keyvars[7];
	V9= keyvars[8];
	if(keyvars[26]==Cnil){
	V10= MAKE_FIXNUM(0);
	}else{
	V10= keyvars[9];}
	if(keyvars[27]==Cnil){
	V11= MAKE_FIXNUM(1);
	}else{
	V11= keyvars[10];}
	if(keyvars[28]==Cnil){
	V12= MAKE_FIXNUM(1);
	}else{
	V12= keyvars[11];}
	if(keyvars[29]==Cnil){
	V13= MAKE_FIXNUM(1);
	}else{
	V13= keyvars[12];}
	if(keyvars[30]==Cnil){
	V14= VV[353];
	}else{
	V14= keyvars[13];}
	V15= keyvars[14];
	if(keyvars[32]==Cnil){
	V16= MAKE_FIXNUM(0);
	}else{
	V16= keyvars[15];}
	V17= keyvars[16];
	}
	(*LK2)(1,VV[342])                         /*  FIND-CLASS      */;
	RETURN(siLmake_structure(18,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8),(V9),(V10),(V11),(V12),(V13),(V14),(V15),(V16),(V17))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for PRINT-SCREEN                          */
static L89(int narg, object V1, object V2, object V3)
{ VT108 VLEX108 CLSR108
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(V1,env0));            /*  SCREEN          */
	CLV1=&CAR(env0=CONS(V2,env0));            /*  STREAM          */
	{ object V4;
	V4= make_cclosure(LC90,env0,&Cblock);
	RETURN((*LK3)(5,*CLV0,*CLV1,Ct,Cnil,(V4)) /*  PRINT-UNREADABLE-OBJECT-FUNCTION*/);
	}
}
/*	closure .PRINT-UNREADABLE-OBJECT-BODY.                        */
static LC90(int narg, object env0)
{ VT109 VLEX109 CLSR109
	narg--;
	{object scan=env0;
	CLV1= &CAR(scan);                         /*  STREAM          */ scan=CDR(scan);
	CLV0= &CAR(scan);                         /*  SCREEN          */}
TTL:
	{object V1;                               /*  DISPLAY         */
	V1= ((*CLV0)->in.in_slots[0])->in.in_slots[1];
	L32(2,(V1),*CLV1)                         /*  PRINT-DISPLAY-NAME*/;
	Lwrite_string(2,VV[355],*CLV1)            /*  WRITE-STRING    */;
	(*LK7)(2,*CLV0,((V1))->in.in_slots[40])   /*  POSITION        */;
	princ(VALUES(0),*CLV1);
	}
	Lwrite_string(2,VV[356],*CLV1)            /*  WRITE-STRING    */;
	prin1((*CLV0)->in.in_slots[1],*CLV1);
	Lwrite_string(2,VV[357],*CLV1)            /*  WRITE-STRING    */;
	prin1((*CLV0)->in.in_slots[2],*CLV1);
	Lwrite_string(2,VV[358],*CLV1)            /*  WRITE-STRING    */;
	prin1((*CLV0)->in.in_slots[6],*CLV1);
	if(((*CLV0)->in.in_slots[7])==Cnil){
	goto L655;}
	Lwrite_string(2,VV[359],*CLV1)            /*  WRITE-STRING    */;
	VALUES(0) = princ(((*CLV0)->in.in_slots[7])->in.in_slots[2],*CLV1);
	RETURN(1);
L655:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for SCREEN-ROOT-VISUAL                    */
static L91(int narg, object V1)
{ VT110 VLEX110 CLSR110
TTL:
	VALUES(0) = (((V1))->in.in_slots[7])->in.in_slots[0];
	RETURN(1);
}
/*	function definition for MAKE-FONT-INFO                        */
static L93(int narg, ...)
{ VT111 VLEX111 CLSR111
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	object V10;
	object V11;
	object V12;
	object V13;
	object V14;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[28];
	parse_key(narg,args,14,L93keys,keyvars,OBJNULL,FALSE);
	if(keyvars[14]==Cnil){
	V1= VV[370];
	}else{
	V1= keyvars[0];}
	if(keyvars[15]==Cnil){
	V2= MAKE_FIXNUM(0);
	}else{
	V2= keyvars[1];}
	if(keyvars[16]==Cnil){
	V3= MAKE_FIXNUM(0);
	}else{
	V3= keyvars[2];}
	if(keyvars[17]==Cnil){
	V4= MAKE_FIXNUM(0);
	}else{
	V4= keyvars[3];}
	if(keyvars[18]==Cnil){
	V5= MAKE_FIXNUM(0);
	}else{
	V5= keyvars[4];}
	if(keyvars[19]==Cnil){
	V6= MAKE_FIXNUM(0);
	}else{
	V6= keyvars[5];}
	if(keyvars[20]==Cnil){
	V7= MAKE_FIXNUM(0);
	}else{
	V7= keyvars[6];}
	V8= keyvars[7];
	if(keyvars[22]==Cnil){
	V9= MAKE_FIXNUM(0);
	}else{
	V9= keyvars[8];}
	V10= keyvars[9];
	V11= keyvars[10];
	if(keyvars[25]==Cnil){
	V12= MAKE_FIXNUM(0);
	}else{
	V12= keyvars[11];}
	if(keyvars[26]==Cnil){
	V13= MAKE_FIXNUM(0);
	}else{
	V13= keyvars[12];}
	V14= keyvars[13];
	}
	(*LK2)(1,VV[362])                         /*  FIND-CLASS      */;
	RETURN(siLmake_structure(15,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8),(V9),(V10),(V11),(V12),(V13),(V14))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for MAKE-FONT-INTERNAL                    */
static L95(int narg, ...)
{ VT112 VLEX112 CLSR112
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[16];
	parse_key(narg,args,8,L95keys,keyvars,OBJNULL,FALSE);
	V1= keyvars[0];
	V2= keyvars[1];
	if(keyvars[10]==Cnil){
	V3= MAKE_FIXNUM(0);
	}else{
	V3= keyvars[2];}
	if(keyvars[11]==Cnil){
	V4= VV[382];
	}else{
	V4= keyvars[3];}
	V5= keyvars[4];
	V6= keyvars[5];
	if(keyvars[14]==Cnil){
	V7= Ct;
	}else{
	V7= keyvars[6];}
	V8= keyvars[7];
	}
	(*LK2)(1,VV[371])                         /*  FIND-CLASS      */;
	RETURN(siLmake_structure(9,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for PRINT-FONT                            */
static L96(int narg, object V1, object V2, object V3)
{ VT113 VLEX113 CLSR113
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(V1,env0));            /*  FONT            */
	CLV1=&CAR(env0=CONS(V2,env0));            /*  STREAM          */
	{ object V4;
	V4= make_cclosure(LC97,env0,&Cblock);
	RETURN((*LK3)(5,*CLV0,*CLV1,Ct,Cnil,(V4)) /*  PRINT-UNREADABLE-OBJECT-FUNCTION*/);
	}
}
/*	closure .PRINT-UNREADABLE-OBJECT-BODY.                        */
static LC97(int narg, object env0)
{ VT114 VLEX114 CLSR114
	narg--;
	{object scan=env0;
	CLV1= &CAR(scan);                         /*  STREAM          */ scan=CDR(scan);
	CLV0= &CAR(scan);                         /*  FONT            */}
TTL:
	if(((*CLV0)->in.in_slots[3])==Cnil){
	goto L675;}
	princ((*CLV0)->in.in_slots[3],*CLV1);
	goto L673;
L675:
	Lwrite_string(2,VV[384],*CLV1)            /*  WRITE-STRING    */;
L673:
	Lwrite_string(2,VV[385],*CLV1)            /*  WRITE-STRING    */;
	L32(2,(*CLV0)->in.in_slots[1],*CLV1)      /*  PRINT-DISPLAY-NAME*/;
	if(((*CLV0)->in.in_slots[0])==Cnil){
	goto L680;}
	Lwrite_string(2,VV[386],*CLV1)            /*  WRITE-STRING    */;
	L98(1,*CLV0)                              /*  FONT-ID         */;
	VALUES(0) = prin1(VALUES(0),*CLV1);
	RETURN(1);
L680:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for FONT-ID                               */
static L98(int narg, object V1)
{ VT115 VLEX115 CLSR115
TTL:
	VALUES(0) = ((V1))->in.in_slots[0];
	if(VALUES(0)==Cnil)goto L684;
	RETURN(1);
L684:
	RETURN((*LK8)(1,(V1))                     /*  OPEN-FONT-INTERNAL*/);
}
/*	function definition for FONT-FONT-INFO                        */
static L99(int narg, object V1)
{ VT116 VLEX116 CLSR116
TTL:
	VALUES(0) = ((V1))->in.in_slots[4];
	if(VALUES(0)==Cnil)goto L686;
	RETURN(1);
L686:
	RETURN((*LK9)(1,(V1))                     /*  QUERY-FONT      */);
}
/*	function definition for FONT-CHAR-INFOS                       */
static L100(int narg, object V1)
{ VT117 VLEX117 CLSR117
TTL:
	VALUES(0) = ((V1))->in.in_slots[5];
	if(VALUES(0)==Cnil)goto L688;
	RETURN(1);
L688:
	(*LK9)(1,(V1))                            /*  QUERY-FONT      */;
	VALUES(0) = ((V1))->in.in_slots[5];
	RETURN(1);
}
/*	function definition for MAKE-FONT                             */
static L101(int narg, ...)
{ VT118 VLEX118 CLSR118
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[12];
	parse_key(narg,args,6,L101keys,keyvars,OBJNULL,FALSE);
	V1= keyvars[0];
	V2= keyvars[1];
	if(keyvars[8]==Cnil){
	V3= MAKE_FIXNUM(0);
	}else{
	V3= keyvars[2];}
	if(keyvars[9]==Cnil){
	V4= VV[387];
	}else{
	V4= keyvars[3];}
	if(keyvars[10]==Cnil){
	V5= Ct;
	}else{
	V5= keyvars[4];}
	V6= keyvars[5];
	}
	RETURN(L95(12,VV[388],(V1),VV[389],(V2),VV[390],(V3),VV[391],(V4),VV[392],(V5),VV[393],(V6))/*  MAKE-FONT-INTERNAL*/);
	}
}
/*	function definition for FONT-PROPERTY                         */
static L116(int narg, object V1, object V2)
{ VT119 VLEX119 CLSR119
TTL:
	(*LK10)(1,(V1))                           /*  FONT-PROPERTIES */;
	RETURN(Lgetf(2,VALUES(0),(V2))            /*  GETF            */);
}
/*	function definition for ENCODE-MASK                           */
static L124(int narg, object V1, object V2, object V3)
{ VT120 VLEX120 CLSR120
TTL:
	{volatile object V4;
	(*LK0)(2,(V2),VV[61])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L696;}
	VALUES(0) = (V2);
	RETURN(1);
L696:
	(*LK0)(2,(V2),VV[51])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L699;}
	{volatile object V5;                      /*  MASK            */
	V5= MAKE_FIXNUM(0);
	{volatile object V6;
	volatile object V7;                       /*  KEY             */
	V6= (V2);
	V7= Cnil;
L704:
	if(!((V6)==Cnil)){
	goto L705;}
	VALUES(0) = (V5);
	RETURN(1);
L705:
	V7= CAR((V6));
	{register object V9;                      /*  BIT             */
	VALUES(0) = (VV[629]->s.s_gfdef);
	(*LK7)(4,(V7),(V1),VV[137],VALUES(0))     /*  POSITION        */;
	V9= VALUES(0);
	if(((V9))!=Cnil){
	goto L713;}
	(*LK11)(2,(V7),(V3))                      /*  X-TYPE-ERROR    */;
L713:
	Lash(2,MAKE_FIXNUM(1),(V9))               /*  ASH             */;
	Llogior(2,(V5),VALUES(0))                 /*  LOGIOR          */;
	V5= VALUES(0);
	}
	V6= CDR((V6));
	goto L704;
	}
	}
L699:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for DECODE-MASK                           */
static L125(int narg, object V1, object V2)
{ VT121 VLEX121 CLSR121
TTL:
	{volatile object V3;                      /*  M               */
	volatile int V4;                          /*  BIT             */
	volatile int V5;                          /*  LEN             */
	volatile object V6;                       /*  RESULT          */
	V4= 0;
	V5= ((V1))->v.v_fillp;
	V3= (V2);
	V6= Cnil;
L724:
	if(number_compare(MAKE_FIXNUM(0),(V3))==0){
	goto L726;}
	if(!((V4)>=(V5))){
	goto L725;}
L726:
	VALUES(0) = (V6);
	RETURN(1);
L725:
	Loddp(1,(V3))                             /*  ODDP            */;
	if(VALUES(0)==Cnil){
	goto L730;}
	V6= CONS(((V1))->v.v_self[V4],(V6));
L730:
	Lash(2,(V3),MAKE_FIXNUM(-1))              /*  SHIFT>>         */;
	V3= VALUES(0);
	V4= (V4)+1;
	goto L724;
	}
}
/*	function definition for ENCODE-EVENT-MASK                     */
static L126(int narg, object V1)
{ VT122 VLEX122 CLSR122
TTL:
	L124(3,VV[421],(V1),VV[290])              /*  ENCODE-MASK     */;
	if(VALUES(0)==Cnil)goto L738;
	RETURN(1);
L738:
	RETURN((*LK11)(2,(V1),VV[293])            /*  X-TYPE-ERROR    */);
}
/*	function definition for MAKE-EVENT-MASK                       */
static L127(int narg, ...)
{ VT123 VLEX123 CLSR123
	{object V1;
	va_list args; va_start(args, narg);
	narg -=0;
	V1=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object p=V1;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	RETURN(L124(3,VV[421],(V1),VV[290])       /*  ENCODE-MASK     */);
	}
}
/*	function definition for MAKE-EVENT-KEYS                       */
static L128(int narg, object V1)
{ VT124 VLEX124 CLSR124
TTL:
	RETURN(L125(2,VV[421],(V1))               /*  DECODE-MASK     */);
}
/*	function definition for ENCODE-DEVICE-EVENT-MASK              */
static L129(int narg, object V1)
{ VT125 VLEX125 CLSR125
TTL:
	L124(3,VV[422],(V1),VV[306])              /*  ENCODE-MASK     */;
	if(VALUES(0)==Cnil)goto L740;
	RETURN(1);
L740:
	RETURN((*LK11)(2,(V1),VV[309])            /*  X-TYPE-ERROR    */);
}
/*	function definition for ENCODE-MODIFIER-MASK                  */
static L130(int narg, object V1)
{ VT126 VLEX126 CLSR126
TTL:
	L124(3,VV[423],(V1),VV[314])              /*  ENCODE-MASK     */;
	if(VALUES(0)==Cnil)goto L742;
	RETURN(1);
L742:
	if(((V1))==(VV[424])){
	goto L746;}
	VALUES(0) = Cnil;
	goto L745;
L746:
	VALUES(0) = MAKE_FIXNUM(32768);
L745:
	if(VALUES(0)==Cnil)goto L744;
	RETURN(1);
L744:
	RETURN((*LK11)(2,(V1),VV[317])            /*  X-TYPE-ERROR    */);
}
/*	function definition for ENCODE-STATE-MASK                     */
static L131(int narg, object V1)
{ VT127 VLEX127 CLSR127
TTL:
	L124(3,VV[423],(V1),VV[320])              /*  ENCODE-MASK     */;
	if(VALUES(0)==Cnil)goto L748;
	RETURN(1);
L748:
	RETURN((*LK11)(2,(V1),VV[425])            /*  X-TYPE-ERROR    */);
}
/*	function definition for MAKE-STATE-MASK                       */
static L132(int narg, ...)
{ VT128 VLEX128 CLSR128
	{object V1;
	va_list args; va_start(args, narg);
	narg -=0;
	V1=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object p=V1;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	RETURN(L124(3,VV[423],(V1),VV[320])       /*  ENCODE-MASK     */);
	}
}
/*	function definition for MAKE-STATE-KEYS                       */
static L133(int narg, object V1)
{ VT129 VLEX129 CLSR129
TTL:
	RETURN(L125(2,VV[423],(V1))               /*  DECODE-MASK     */);
}
/*	function definition for ENCODE-POINTER-EVENT-MASK             */
static L134(int narg, object V1)
{ VT130 VLEX130 CLSR130
TTL:
	L124(3,VV[426],(V1),VV[298])              /*  ENCODE-MASK     */;
	if(VALUES(0)==Cnil)goto L750;
	RETURN(1);
L750:
	RETURN((*LK11)(2,(V1),VV[301])            /*  X-TYPE-ERROR    */);
}
static LKF11(int narg, ...) {TRAMPOLINK(VV[705],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[407],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[700],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[698],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[678],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[657],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[628],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[627],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[545],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[445],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[543],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[542],&LK0);}
