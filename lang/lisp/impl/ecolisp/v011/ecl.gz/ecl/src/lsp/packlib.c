
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "packlib.h"
init_packlib(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_packlib; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	funcall(2,symbol_function(VV[34]),VV[0])  /*  PROCLAIM        */;
	MM0(VV[9],L1);
	MF0(VV[35],L2);
	MM0(VV[31],L4);
	MM0(VV[36],L5);
	MM0(VV[37],L6);
	MF0(VV[38],L7);
	MF0(VV[39],L8);
	MF0(VV[40],L9);
	MF0(VV[41],L10);
}
/*	macro definition for COERCE-TO-PACKAGE                        */
static L1(int narg, object V1, object V2)
{ VT3 VLEX3 CLSR3
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4;
	if(endp(V3))FEinvalid_macro_call(VV[9]);
	V4= CAR(V3);
	V3=CDR(V3);
	if(!endp(V3))FEinvalid_macro_call(VV[9]);
	if(!(((V4))==(VV[1]))){
	goto L3;}
	VALUES(0) = (V4);
	RETURN(1);
L3:
	{register object V5;                      /*  G               */
	Lgensym(0)                                /*  GENSYM          */;
	V5= VALUES(0);
	{object V6= CONS(list(2,(V5),(V4)),Cnil);
	{object V7= list(2,VV[4],(V5));
	VALUES(0) = list(3,VV[2],(V6),list(4,VV[3],(V7),(V5),list(2,VV[5],list(2,VV[6],(V5)))));
	RETURN(1);}}
	}}
}
/*	function definition for FIND-ALL-SYMBOLS                      */
static L2(int narg, object V1)
{ VT4 VLEX4 CLSR4
	cs_check;
	check_arg(1);
TTL:
	if(!(type_of((V1))==t_symbol)){
	goto L6;}
	V1= symbol_name((V1));
L6:
	Llist_all_packages(0)                     /*  LIST-ALL-PACKAGES*/;
	{object V2;
	object V3= VALUES(0);
	if(endp(V3)){
	VALUES(0) = Cnil;
	RETURN(1);}
	T0=V2=CONS(Cnil,Cnil);
L10:
	{object V4;                               /*  P               */
	{ int V5;
	object V6;                                /*  S               */
	object V7;                                /*  I               */
	V5=Lfind_symbol(2,(V1),CAR(V3))           /*  FIND-SYMBOL     */;
	if (V5--==0) goto L14;
	V6= VALUES(0);
	if (V5--==0) goto L15;
	V7= VALUES(1);
	goto L16;
L14:
	V6= Cnil;
L15:
	V7= Cnil;
L16:
	if(((V7))==(VV[7])){
	goto L17;}
	if(!(((V7))==(VV[8]))){
	goto L18;}
L17:
	CDR(V2)= CONS((V6),Cnil);
	goto L12;
L18:
	CDR(V2)= Cnil;}
	}
L12:
	while(!endp(CDR(V2)))V2=CDR(V2);
	if(endp(V3=CDR(V3))){
	T0=CDR(T0);
	VALUES(0) = T0;
	RETURN(1);}
	goto L10;}
}
/*	macro definition for DO-SYMBOLS                               */
static L4(int narg, object V1, object V2)
{ VT5 VLEX5 CLSR5
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6,V7;
	if(endp(V3))FEinvalid_macro_call(VV[31]);
	{object V8= CAR(V3);
	if(endp(V8))FEinvalid_macro_call(VV[31]);
	V4= CAR(V8);
	V8=CDR(V8);
	if(endp(V8)){
	V5= VV[1];
	} else {
	V5= CAR(V8);
	V8=CDR(V8);}
	if(endp(V8)){
	V6= Cnil;
	} else {
	V6= CAR(V8);
	V8=CDR(V8);}
	if(!endp(V8))FEinvalid_macro_call(VV[31]);}
	V3=CDR(V3);
	V7= V3;
	{register object V9;                      /*  P               */
	object V10;
	register object V11;                      /*  I               */
	object V12;
	register object V13;                      /*  L               */
	object V14;
	object V15;                               /*  LOOP            */
	object V16;
	register object V17;                      /*  X               */
	object V18;
	object V19;                               /*  Y               */
	object V20;
	object V21;                               /*  BREAK           */
	object V22;                               /*  DECLARATION     */
	Lgensym(0)                                /*  GENSYM          */;
	V10= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V12= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V14= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V16= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V18= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V20= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V21= VALUES(0);
	V9= V10;
	V11= V12;
	V13= V14;
	V15= V16;
	V17= V18;
	V19= V20;
	V22= Cnil;
	{ int V23;
	V23=(*LK0)(1,(V7))                        /*  FIND-DECLARATIONS*/;
	if (V23>0) {
	V22= VALUES(0);
	V23--;
	} else {
	V22= Cnil;}
	if (V23>0) {
	V7= VALUES(1);
	} else {
	V7= Cnil;}
	
	}
	{object V23= list(3,list(2,(V9),list(2,VV[9],(V5))),(V4),(V13));
	{object V24= list(2,(V19),(V17));
	{object V25= list(2,VV[11],(V9));
	{object V26= list(2,VV[12],list(3,VV[13],(V17),(V19)));
	{object V27= list(3,VV[15],VV[13],list(3,VV[16],(V17),(V19)));
	{object V28= list(3,(V11),(V27),list(3,VV[17],list(3,VV[18],(V4),Cnil),(V6)));
	{object V29= list(3,VV[19],(V11),(V17));
	{object V30= list(3,VV[20],(V9),(V11));
	{object V31= list(3,VV[18],(V13),list(4,VV[3],(V29),(V30),list(3,VV[21],(V9),list(3,VV[15],VV[13],list(3,VV[22],(V11),(V17))))));
	{object V32= list(2,VV[24],(V13));
	{object V33= list(3,VV[23],(V32),list(2,VV[25],(V21)));
	{object V34= list(3,VV[18],(V4),list(2,VV[26],(V13)));
	{object V35= list(3,VV[18],(V13),list(2,VV[27],(V13)));
	VALUES(0) = listA(3,VV[2],(V23),append((V22),CONS(list(5,VV[10],(V24),(V25),(V26),listA(7,VV[14],(V28),(V31),(V15),(V33),(V34),append((V7),list(3,(V35),list(2,VV[25],(V15)),(V21))))),Cnil)));
	RETURN(1);}}}}}}}}}}}}}
	}}
}
/*	macro definition for DO-EXTERNAL-SYMBOLS                      */
static L5(int narg, object V1, object V2)
{ VT6 VLEX6 CLSR6
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6,V7;
	if(endp(V3))FEinvalid_macro_call(VV[36]);
	{object V8= CAR(V3);
	if(endp(V8))FEinvalid_macro_call(VV[36]);
	V4= CAR(V8);
	V8=CDR(V8);
	if(endp(V8)){
	V5= VV[1];
	} else {
	V5= CAR(V8);
	V8=CDR(V8);}
	if(endp(V8)){
	V6= Cnil;
	} else {
	V6= CAR(V8);
	V8=CDR(V8);}
	if(!endp(V8))FEinvalid_macro_call(VV[36]);}
	V3=CDR(V3);
	V7= V3;
	{object V9;                               /*  P               */
	object V10;
	object V11;                               /*  I               */
	object V12;
	register object V13;                      /*  L               */
	object V14;
	object V15;                               /*  LOOP            */
	object V16;
	object V17;                               /*  BREAK           */
	object V18;                               /*  DECLARATION     */
	Lgensym(0)                                /*  GENSYM          */;
	V10= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V12= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V14= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V16= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V17= VALUES(0);
	V9= V10;
	V11= V12;
	V13= V14;
	V15= V16;
	V18= Cnil;
	{ int V19;
	V19=(*LK0)(1,(V7))                        /*  FIND-DECLARATIONS*/;
	if (V19>0) {
	V18= VALUES(0);
	V19--;
	} else {
	V18= Cnil;}
	if (V19>0) {
	V7= VALUES(1);
	} else {
	V7= Cnil;}
	
	}
	{object V19= list(3,list(2,(V9),list(2,VV[9],(V5))),(V4),(V13));
	{object V20= list(2,VV[11],(V9));
	{object V21= list(3,(V11),(V20),list(3,VV[17],list(3,VV[18],(V4),Cnil),(V6)));
	{object V22= list(3,VV[18],(V13),list(3,VV[21],(V9),(V11)));
	{object V23= list(2,VV[24],(V13));
	{object V24= list(3,VV[23],(V23),list(2,VV[25],(V17)));
	{object V25= list(3,VV[18],(V4),list(2,VV[26],(V13)));
	{object V26= list(3,VV[18],(V13),list(2,VV[27],(V13)));
	VALUES(0) = listA(3,VV[2],(V19),append((V18),CONS(listA(7,VV[14],(V21),(V22),(V15),(V24),(V25),append((V7),list(3,(V26),list(2,VV[25],(V15)),(V17)))),Cnil)));
	RETURN(1);}}}}}}}}
	}}
}
/*	macro definition for DO-ALL-SYMBOLS                           */
static L6(int narg, object V1, object V2)
{ VT7 VLEX7 CLSR7
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6;
	if(endp(V3))FEinvalid_macro_call(VV[37]);
	{object V7= CAR(V3);
	if(endp(V7))FEinvalid_macro_call(VV[37]);
	V4= CAR(V7);
	V7=CDR(V7);
	if(endp(V7)){
	V5= Cnil;
	} else {
	V5= CAR(V7);
	V7=CDR(V7);}
	if(!endp(V7))FEinvalid_macro_call(VV[37]);}
	V3=CDR(V3);
	V6= V3;
	{object V8= list(3,VV[29],VV[30],(V5));
	VALUES(0) = list(3,VV[28],(V8),listA(3,VV[31],list(2,(V4),VV[29]),(V6)));
	RETURN(1);}}
}
/*	function definition for SUBSTRINGP                            */
static L7(int narg, object V1, object V2)
{ VT8 VLEX8 CLSR8
	cs_check;
	check_arg(2);
TTL:
	{volatile int V3;                         /*  I               */
	volatile int V4;                          /*  L               */
	volatile int V5;                          /*  J               */
	V3= (length((V2)))-(length((V1)));
	V4= length((V1));
	V5= 0;
L47:
	if(!((V5)>(V3))){
	goto L48;}
	VALUES(0) = Cnil;
	RETURN(1);
L48:
	Lstring_equal(6,(V1),(V2),VV[32],MAKE_FIXNUM(V5),VV[33],MAKE_FIXNUM((V5)+(V4)))/*  STRING-EQUAL*/;
	if(VALUES(0)==Cnil){
	goto L51;}
	VALUES(0) = Ct;
	RETURN(1);
L51:
	V5= (V5)+1;
	goto L47;
	}
}
/*	function definition for PRINT-SYMBOL-APROPOS                  */
static L8(int narg, object V1)
{ VT9 VLEX9 CLSR9
	cs_check;
	check_arg(1);
TTL:
	prin1((V1),Cnil);
	Lfboundp(1,(V1))                          /*  FBOUNDP         */;
	if(VALUES(0)==Cnil){
	goto L58;}
	Lspecial_form_p(1,(V1))                   /*  SPECIAL-FORM-P  */;
	if(VALUES(0)==Cnil){
	goto L62;}
	princ_str("  Special form",Cnil);
	goto L58;
L62:
	Lmacro_function(1,(V1))                   /*  MACRO-FUNCTION  */;
	if(VALUES(0)==Cnil){
	goto L65;}
	princ_str("  Macro",Cnil);
	goto L58;
L65:
	princ_str("  Function",Cnil);
L58:
	Lboundp(1,(V1))                           /*  BOUNDP          */;
	if(VALUES(0)==Cnil){
	goto L67;}
	Lconstantp(1,(V1))                        /*  CONSTANTP       */;
	if(VALUES(0)==Cnil){
	goto L72;}
	princ_str("  Constant: ",Cnil);
	goto L70;
L72:
	princ_str("  has value: ",Cnil);
L70:
	Lsymbol_value(1,(V1))                     /*  SYMBOL-VALUE    */;
	prin1(VALUES(0),Cnil);
L67:
	VALUES(0) = terpri(Cnil);
	RETURN(1);
}
/*	function definition for APROPOS                               */
static L9(int narg, object V1, ...)
{ VT10 VLEX10 CLSR10
	cs_check;
	{int i=1;
	volatile object V2;
	va_list args; va_start(args, V1);
	if(narg<1) FEtoo_few_arguments(&narg);
	if(narg>2) FEtoo_many_arguments(&narg);
	if (i==narg) goto L75;
	V2= va_arg(args, object);
	i++;
	goto L76;
L75:
	V2= Cnil;
L76:
	V1= coerce_to_string((V1));
	if(((V2))==Cnil){
	goto L82;}
	{volatile object V3;
	volatile object V4;                       /*  SYMBOL          */
	volatile object V5;
	{object V6;
	V6= (V2);
	Lpackagep(1,(V6))                         /*  PACKAGEP        */;
	if(VALUES(0)==Cnil){
	goto L87;}
	V3= (V6);
	goto L85;
L87:
	Lfind_package(1,coerce_to_string((V6)))   /*  FIND-PACKAGE    */;
	V3= VALUES(0);
	}
L85:
	V4= Cnil;
	V5= Cnil;
	{ int V6;
	volatile object V7;
	volatile int V8;
	V6=(*LK1)(1,(V3))                         /*  PACKAGE-SIZE    */;
	if (V6--==0) goto L90;
	V7= VALUES(0);
	if (V6--==0) goto L91;
	V8= fix(VALUES(1));
	goto L92;
L90:
	V7= MAKE_FIXNUM(0);
L91:
	V8= 0;
L92:
	{volatile int V9;
	volatile int V10;
	V9= (V8)+(fix((V7)));
	V10= 0;
L96:
	if(!((V10)>=(V9))){
	goto L99;}
	V4= Cnil;
	goto L84;
L99:
	if(!((V10)<(V8))){
	goto L106;}
	siLpackage_internal(2,(V3),MAKE_FIXNUM(V10))/*  PACKAGE-INTERNAL*/;
	V5= VALUES(0);
	goto L104;
L106:
	siLpackage_external(2,(V3),MAKE_FIXNUM((V10)-(V8)))/*  PACKAGE-EXTERNAL*/;
	V5= VALUES(0);
L104:
L97:
	if(((V5))!=Cnil){
	goto L108;}
	goto L98;
L108:
	V4= car((V5));
	L7(2,(V1),coerce_to_string((V4)))         /*  SUBSTRINGP      */;
	if(VALUES(0)==Cnil){
	goto L113;}
	L8(1,(V4))                                /*  PRINT-SYMBOL-APROPOS*/;
L113:
	V5= cdr((V5));
	goto L97;
L98:
	V10= (V10)+1;
	goto L96;
	}}
	}
L84:
	{volatile object V3;                      /*  P               */
	Lpackage_use_list(1,(V2))                 /*  PACKAGE-USE-LIST*/;
	V3= VALUES(0);
L123:
	if(((V3))!=Cnil){
	goto L124;}
	goto L80;
L124:
	{volatile object V5;
	volatile object V6;                       /*  SYMBOL          */
	volatile object V7;
	{object V8;
	V8= car((V3));
	Lpackagep(1,(V8))                         /*  PACKAGEP        */;
	if(VALUES(0)==Cnil){
	goto L131;}
	V5= (V8);
	goto L128;
L131:
	Lfind_package(1,coerce_to_string((V8)))   /*  FIND-PACKAGE    */;
	V5= VALUES(0);
	}
L128:
	V6= Cnil;
	V7= Cnil;
	{volatile object V8;
	volatile int V9;
	(*LK1)(1,(V5))                            /*  PACKAGE-SIZE    */;
	V8= VALUES(0);
	V9= 0;
L136:
	if(!(number_compare(MAKE_FIXNUM(V9),(V8))>=0)){
	goto L139;}
	V6= Cnil;
	goto L127;
L139:
	siLpackage_external(2,(V5),MAKE_FIXNUM(V9))/*  PACKAGE-EXTERNAL*/;
	V7= VALUES(0);
L137:
	if(((V7))!=Cnil){
	goto L145;}
	goto L138;
L145:
	V6= car((V7));
	L7(2,(V1),coerce_to_string((V6)))         /*  SUBSTRINGP      */;
	if(VALUES(0)==Cnil){
	goto L150;}
	L8(1,(V6))                                /*  PRINT-SYMBOL-APROPOS*/;
L150:
	V7= cdr((V7));
	goto L137;
L138:
	V9= (V9)+1;
	goto L136;
	}
	}
L127:
	V3= cdr((V3));
	goto L123;
	}
L82:
	{volatile object V11;
	volatile object V12;                      /*  .V              */
	Llist_all_packages(0)                     /*  LIST-ALL-PACKAGES*/;
	V11= VALUES(0);
	V12= Cnil;
L164:
	if(!(endp((V11)))){
	goto L165;}
	goto L80;
L165:
	V12= car((V11));
	{volatile object V14;
	volatile object V15;                      /*  SYMBOL          */
	volatile object V16;
	{object V17;
	V17= (V12);
	Lpackagep(1,(V17))                        /*  PACKAGEP        */;
	if(VALUES(0)==Cnil){
	goto L173;}
	V14= (V17);
	goto L171;
L173:
	Lfind_package(1,coerce_to_string((V17)))  /*  FIND-PACKAGE    */;
	V14= VALUES(0);
	}
L171:
	V15= Cnil;
	V16= Cnil;
	{ int V17;
	volatile object V18;
	volatile int V19;
	V17=(*LK1)(1,(V14))                       /*  PACKAGE-SIZE    */;
	if (V17--==0) goto L176;
	V18= VALUES(0);
	if (V17--==0) goto L177;
	V19= fix(VALUES(1));
	goto L178;
L176:
	V18= MAKE_FIXNUM(0);
L177:
	V19= 0;
L178:
	{volatile int V20;
	volatile int V21;
	V20= (V19)+(fix((V18)));
	V21= 0;
L182:
	if(!((V21)>=(V20))){
	goto L185;}
	V15= Cnil;
	goto L170;
L185:
	if(!((V21)<(V19))){
	goto L192;}
	siLpackage_internal(2,(V14),MAKE_FIXNUM(V21))/*  PACKAGE-INTERNAL*/;
	V16= VALUES(0);
	goto L190;
L192:
	siLpackage_external(2,(V14),MAKE_FIXNUM((V21)-(V19)))/*  PACKAGE-EXTERNAL*/;
	V16= VALUES(0);
L190:
L183:
	if(((V16))!=Cnil){
	goto L194;}
	goto L184;
L194:
	V15= car((V16));
	L7(2,(V1),coerce_to_string((V15)))        /*  SUBSTRINGP      */;
	if(VALUES(0)==Cnil){
	goto L199;}
	L8(1,(V15))                               /*  PRINT-SYMBOL-APROPOS*/;
L199:
	V16= cdr((V16));
	goto L183;
L184:
	V21= (V21)+1;
	goto L182;
	}}
	}
L170:
	V11= cdr((V11));
	goto L164;
	}
L80:
	RETURN(0);
	}
}
/*	function definition for APROPOS-LIST                          */
static L10(int narg, object V1, ...)
{ VT11 VLEX11 CLSR11
	cs_check;
	{int i=1;
	volatile object V2;
	va_list args; va_start(args, V1);
	if(narg<1) FEtoo_few_arguments(&narg);
	if(narg>2) FEtoo_many_arguments(&narg);
	if (i==narg) goto L210;
	V2= va_arg(args, object);
	i++;
	goto L211;
L210:
	V2= Cnil;
L211:
	{register object V3;                      /*  LIST            */
	V3= Cnil;
	V3= Cnil;
	V1= coerce_to_string((V1));
	if(((V2))==Cnil){
	goto L220;}
	{volatile object V4;
	volatile object V5;                       /*  SYMBOL          */
	volatile object V6;
	{object V7;
	V7= (V2);
	Lpackagep(1,(V7))                         /*  PACKAGEP        */;
	if(VALUES(0)==Cnil){
	goto L225;}
	V4= (V7);
	goto L223;
L225:
	Lfind_package(1,coerce_to_string((V7)))   /*  FIND-PACKAGE    */;
	V4= VALUES(0);
	}
L223:
	V5= Cnil;
	V6= Cnil;
	{ int V7;
	volatile object V8;
	volatile int V9;
	V7=(*LK1)(1,(V4))                         /*  PACKAGE-SIZE    */;
	if (V7--==0) goto L228;
	V8= VALUES(0);
	if (V7--==0) goto L229;
	V9= fix(VALUES(1));
	goto L230;
L228:
	V8= MAKE_FIXNUM(0);
L229:
	V9= 0;
L230:
	{volatile int V10;
	volatile int V11;
	V10= (V9)+(fix((V8)));
	V11= 0;
L234:
	if(!((V11)>=(V10))){
	goto L237;}
	V5= Cnil;
	goto L222;
L237:
	if(!((V11)<(V9))){
	goto L244;}
	siLpackage_internal(2,(V4),MAKE_FIXNUM(V11))/*  PACKAGE-INTERNAL*/;
	V6= VALUES(0);
	goto L242;
L244:
	siLpackage_external(2,(V4),MAKE_FIXNUM((V11)-(V9)))/*  PACKAGE-EXTERNAL*/;
	V6= VALUES(0);
L242:
L235:
	if(((V6))!=Cnil){
	goto L246;}
	goto L236;
L246:
	V5= car((V6));
	L7(2,(V1),coerce_to_string((V5)))         /*  SUBSTRINGP      */;
	if(VALUES(0)==Cnil){
	goto L251;}
	V3= CONS((V5),(V3));
L251:
	V6= cdr((V6));
	goto L235;
L236:
	V11= (V11)+1;
	goto L234;
	}}
	}
L222:
	{volatile object V4;                      /*  P               */
	Lpackage_use_list(1,(V2))                 /*  PACKAGE-USE-LIST*/;
	V4= VALUES(0);
L262:
	if(((V4))!=Cnil){
	goto L263;}
	goto L218;
L263:
	{volatile object V6;
	volatile object V7;                       /*  SYMBOL          */
	volatile object V8;
	{object V9;
	V9= car((V4));
	Lpackagep(1,(V9))                         /*  PACKAGEP        */;
	if(VALUES(0)==Cnil){
	goto L270;}
	V6= (V9);
	goto L267;
L270:
	Lfind_package(1,coerce_to_string((V9)))   /*  FIND-PACKAGE    */;
	V6= VALUES(0);
	}
L267:
	V7= Cnil;
	V8= Cnil;
	{ int V9;
	volatile object V10;
	volatile int V11;
	V9=(*LK1)(1,(V6))                         /*  PACKAGE-SIZE    */;
	if (V9--==0) goto L273;
	V10= VALUES(0);
	if (V9--==0) goto L274;
	V11= fix(VALUES(1));
	goto L275;
L273:
	V10= MAKE_FIXNUM(0);
L274:
	V11= 0;
L275:
	{volatile int V12;
	volatile int V13;
	V12= (V11)+(fix((V10)));
	V13= 0;
L279:
	if(!((V13)>=(V12))){
	goto L282;}
	V7= Cnil;
	goto L266;
L282:
	if(!((V13)<(V11))){
	goto L289;}
	siLpackage_internal(2,(V6),MAKE_FIXNUM(V13))/*  PACKAGE-INTERNAL*/;
	V8= VALUES(0);
	goto L287;
L289:
	siLpackage_external(2,(V6),MAKE_FIXNUM((V13)-(V11)))/*  PACKAGE-EXTERNAL*/;
	V8= VALUES(0);
L287:
L280:
	if(((V8))!=Cnil){
	goto L291;}
	goto L281;
L291:
	V7= car((V8));
	L7(2,(V1),coerce_to_string((V7)))         /*  SUBSTRINGP      */;
	if(VALUES(0)==Cnil){
	goto L296;}
	V3= CONS((V7),(V3));
L296:
	V8= cdr((V8));
	goto L280;
L281:
	V13= (V13)+1;
	goto L279;
	}}
	}
L266:
	V4= cdr((V4));
	goto L262;
	}
L220:
	{volatile object V9;
	volatile object V10;                      /*  .V              */
	Llist_all_packages(0)                     /*  LIST-ALL-PACKAGES*/;
	V9= VALUES(0);
	V10= Cnil;
L311:
	if(!(endp((V9)))){
	goto L312;}
	goto L218;
L312:
	V10= car((V9));
	{volatile object V12;
	volatile object V13;                      /*  SYMBOL          */
	volatile object V14;
	{object V15;
	V15= (V10);
	Lpackagep(1,(V15))                        /*  PACKAGEP        */;
	if(VALUES(0)==Cnil){
	goto L320;}
	V12= (V15);
	goto L318;
L320:
	Lfind_package(1,coerce_to_string((V15)))  /*  FIND-PACKAGE    */;
	V12= VALUES(0);
	}
L318:
	V13= Cnil;
	V14= Cnil;
	{ int V15;
	volatile object V16;
	volatile int V17;
	V15=(*LK1)(1,(V12))                       /*  PACKAGE-SIZE    */;
	if (V15--==0) goto L323;
	V16= VALUES(0);
	if (V15--==0) goto L324;
	V17= fix(VALUES(1));
	goto L325;
L323:
	V16= MAKE_FIXNUM(0);
L324:
	V17= 0;
L325:
	{volatile int V18;
	volatile int V19;
	V18= (V17)+(fix((V16)));
	V19= 0;
L329:
	if(!((V19)>=(V18))){
	goto L332;}
	V13= Cnil;
	goto L317;
L332:
	if(!((V19)<(V17))){
	goto L339;}
	siLpackage_internal(2,(V12),MAKE_FIXNUM(V19))/*  PACKAGE-INTERNAL*/;
	V14= VALUES(0);
	goto L337;
L339:
	siLpackage_external(2,(V12),MAKE_FIXNUM((V19)-(V17)))/*  PACKAGE-EXTERNAL*/;
	V14= VALUES(0);
L337:
L330:
	if(((V14))!=Cnil){
	goto L341;}
	goto L331;
L341:
	V13= car((V14));
	L7(2,(V1),coerce_to_string((V13)))        /*  SUBSTRINGP      */;
	if(VALUES(0)==Cnil){
	goto L346;}
	V3= CONS((V13),(V3));
L346:
	V14= cdr((V14));
	goto L330;
L331:
	V19= (V19)+1;
	goto L329;
	}}
	}
L317:
	V9= cdr((V9));
	goto L311;
	}
L218:
	VALUES(0) = (V3);
	RETURN(1);
	}
	}
}
static LKF1(int narg, ...) {TRAMPOLINK(VV[11],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[42],&LK0);}
