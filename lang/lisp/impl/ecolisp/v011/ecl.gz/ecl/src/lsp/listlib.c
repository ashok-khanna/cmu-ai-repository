
/* (c) Copyright G. Attardi, 1993. All rights reserved. */
#include <ecl.h>
#include "listlib.h"
init_listlib(int size, object file)
{
	Cblock.cd_start=NULL; Cblock.cd_size=size;
	Cblock.cd_data=read_VV(VV,VM1,file);
	(void)(funcall(2, VV[1], VV[0]), VALUES(0));
	MF0key(VV[2],L2,3,L2keys);
	MF0key(VV[3],L3,3,L3keys);
	MF0key(VV[4],L4,3,L4keys);
	MF0key(VV[5],L5,3,L5keys);
	MF0key(VV[6],L6,3,L6keys);
	MF0key(VV[7],L7,3,L7keys);
	MF0key(VV[8],L8,3,L8keys);
	MF0key(VV[9],L9,3,L9keys);
	MF0key(VV[10],L10,3,L10keys);
}
/*	function definition for UNION                                 */
static L2(int narg, object V1, object V2, ...)
{ VT3 VLEX3 CLSR3
	cs_reserve(VM3);
	{int i=2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg=narg-i;
	V3=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object keyvars[6];
	parse_key(narg,args,3,L2keys,keyvars,V3,FALSE);
	V4= keyvars[0];
	V5= keyvars[1];
	V6= keyvars[2];
	}
	if(((V1))!=Cnil){
	goto L3;}
	VALUES(0) = (V2);
	RETURN(1);
L3:
	T0=symbol_function(VV[14]);
	{ int V7, i=0;
	T1= car((V1));
	T2= (V2);
	T3= (V3);
	V7=length(T3);
	VALUES(i++)=T1;
	VALUES(i++)=T2;
	V7+=i;
	for (; i<V7;i++,T3=CDR(T3))
		VALUES(i)=CAR(T3);
	APPLY(V7,(*LK0),&VALUES(0))               /*  MEMBER1         */;
	if(VALUES(0)==Cnil){
	goto L6;}
	}
	{ int V7, i=0;
	T0= cdr((V1));
	T1= (V2);
	T2= (V3);
	V7=length(T2);
	VALUES(i++)=T0;
	VALUES(i++)=T1;
	V7+=i;
	for (; i<V7;i++,T2=CDR(T2))
		VALUES(i)=CAR(T2);
	RETURN(APPLY(V7,L2,&VALUES(0))            /*  UNION           */);
	}
L6:
	{object V8= car((V1));
	{ int V9, i=0;
	T0= cdr((V1));
	T1= (V2);
	T2= (V3);
	V9=length(T2);
	VALUES(i++)=T0;
	VALUES(i++)=T1;
	V9+=i;
	for (; i<V9;i++,T2=CDR(T2))
		VALUES(i)=CAR(T2);
	APPLY(V9,L2,&VALUES(0))                   /*  UNION           */;
	}
	VALUES(0) = CONS(V8,VALUES(0));
	RETURN(1);}
	}
}
/*	function definition for NUNION                                */
static L3(int narg, object V1, object V2, ...)
{ VT4 VLEX4 CLSR4
	cs_reserve(VM4);
	{int i=2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg=narg-i;
	V3=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object keyvars[6];
	parse_key(narg,args,3,L3keys,keyvars,V3,FALSE);
	V4= keyvars[0];
	V5= keyvars[1];
	V6= keyvars[2];
	}
	if(((V1))!=Cnil){
	goto L19;}
	VALUES(0) = (V2);
	RETURN(1);
L19:
	T0=symbol_function(VV[14]);
	{ int V7, i=0;
	T1= car((V1));
	T2= (V2);
	T3= (V3);
	V7=length(T3);
	VALUES(i++)=T1;
	VALUES(i++)=T2;
	V7+=i;
	for (; i<V7;i++,T3=CDR(T3))
		VALUES(i)=CAR(T3);
	APPLY(V7,(*LK0),&VALUES(0))               /*  MEMBER1         */;
	if(VALUES(0)==Cnil){
	goto L22;}
	}
	{ int V7, i=0;
	T0= cdr((V1));
	T1= (V2);
	T2= (V3);
	V7=length(T2);
	VALUES(i++)=T0;
	VALUES(i++)=T1;
	V7+=i;
	for (; i<V7;i++,T2=CDR(T2))
		VALUES(i)=CAR(T2);
	RETURN(APPLY(V7,L3,&VALUES(0))            /*  NUNION          */);
	}
L22:
	{ int V8, i=0;
	T0= cdr((V1));
	T1= (V2);
	T2= (V3);
	V8=length(T2);
	VALUES(i++)=T0;
	VALUES(i++)=T1;
	V8+=i;
	for (; i<V8;i++,T2=CDR(T2))
		VALUES(i)=CAR(T2);
	APPLY(V8,L3,&VALUES(0))                   /*  NUNION          */;
	}
	if(type_of((V1))!=t_cons)FEwrong_type_argument(Scons,(V1));
	CDR((V1)) = VALUES(0);
	VALUES(0) = (V1);
	RETURN(1);
	}
}
/*	function definition for INTERSECTION                          */
static L4(int narg, object V1, object V2, ...)
{ VT5 VLEX5 CLSR5
	cs_reserve(VM5);
	{int i=2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg=narg-i;
	V3=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object keyvars[6];
	parse_key(narg,args,3,L4keys,keyvars,V3,FALSE);
	V4= keyvars[0];
	V5= keyvars[1];
	V6= keyvars[2];
	}
	if(((V1))!=Cnil){
	goto L35;}
	VALUES(0) = Cnil;
	RETURN(1);
L35:
	T0=symbol_function(VV[14]);
	{ int V7, i=0;
	T1= car((V1));
	T2= (V2);
	T3= (V3);
	V7=length(T3);
	VALUES(i++)=T1;
	VALUES(i++)=T2;
	V7+=i;
	for (; i<V7;i++,T3=CDR(T3))
		VALUES(i)=CAR(T3);
	APPLY(V7,(*LK0),&VALUES(0))               /*  MEMBER1         */;
	if(VALUES(0)==Cnil){
	goto L38;}
	}
	{object V7= car((V1));
	{ int V8, i=0;
	T0= cdr((V1));
	T1= (V2);
	T2= (V3);
	V8=length(T2);
	VALUES(i++)=T0;
	VALUES(i++)=T1;
	V8+=i;
	for (; i<V8;i++,T2=CDR(T2))
		VALUES(i)=CAR(T2);
	APPLY(V8,L4,&VALUES(0))                   /*  INTERSECTION    */;
	}
	VALUES(0) = CONS(V7,VALUES(0));
	RETURN(1);}
L38:
	{ int V8, i=0;
	T0= cdr((V1));
	T1= (V2);
	T2= (V3);
	V8=length(T2);
	VALUES(i++)=T0;
	VALUES(i++)=T1;
	V8+=i;
	for (; i<V8;i++,T2=CDR(T2))
		VALUES(i)=CAR(T2);
	RETURN(APPLY(V8,L4,&VALUES(0))            /*  INTERSECTION    */);
	}
	}
}
/*	function definition for NINTERSECTION                         */
static L5(int narg, object V1, object V2, ...)
{ VT6 VLEX6 CLSR6
	cs_reserve(VM6);
	{int i=2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg=narg-i;
	V3=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object keyvars[6];
	parse_key(narg,args,3,L5keys,keyvars,V3,FALSE);
	V4= keyvars[0];
	V5= keyvars[1];
	V6= keyvars[2];
	}
	if(((V1))!=Cnil){
	goto L51;}
	VALUES(0) = Cnil;
	RETURN(1);
L51:
	T0=symbol_function(VV[14]);
	{ int V7, i=0;
	T1= car((V1));
	T2= (V2);
	T3= (V3);
	V7=length(T3);
	VALUES(i++)=T1;
	VALUES(i++)=T2;
	V7+=i;
	for (; i<V7;i++,T3=CDR(T3))
		VALUES(i)=CAR(T3);
	APPLY(V7,(*LK0),&VALUES(0))               /*  MEMBER1         */;
	if(VALUES(0)==Cnil){
	goto L54;}
	}
	{ int V7, i=0;
	T0= cdr((V1));
	T1= (V2);
	T2= (V3);
	V7=length(T2);
	VALUES(i++)=T0;
	VALUES(i++)=T1;
	V7+=i;
	for (; i<V7;i++,T2=CDR(T2))
		VALUES(i)=CAR(T2);
	APPLY(V7,L5,&VALUES(0))                   /*  NINTERSECTION   */;
	}
	if(type_of((V1))!=t_cons)FEwrong_type_argument(Scons,(V1));
	CDR((V1)) = VALUES(0);
	VALUES(0) = (V1);
	RETURN(1);
L54:
	{ int V7, i=0;
	T0= cdr((V1));
	T1= (V2);
	T2= (V3);
	V7=length(T2);
	VALUES(i++)=T0;
	VALUES(i++)=T1;
	V7+=i;
	for (; i<V7;i++,T2=CDR(T2))
		VALUES(i)=CAR(T2);
	RETURN(APPLY(V7,L5,&VALUES(0))            /*  NINTERSECTION   */);
	}
	}
}
/*	function definition for SET-DIFFERENCE                        */
static L6(int narg, object V1,object V2, ...)
{ VT7 VLEX7 CLSR7
	cs_reserve(VM7);
	{int i=2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg=narg-i;
	V3=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object keyvars[6];
	parse_key(narg,args,3,L6keys,keyvars,V3,FALSE);
	V4= keyvars[0];
	V5= keyvars[1];
	V6= keyvars[2];
	}
	if(((V1))!=Cnil){
	goto L67;}
	VALUES(0) = Cnil;
	RETURN(1);
L67:
	T0=symbol_function(VV[14]);
	{ int V7, i=0;
	T1= car((V1));
	T2= (V2);
	T3= (V3);
	V7=length(T3);
	VALUES(i++)=T1;
	VALUES(i++)=T2;
	V7+=i;
	for (; i<V7;i++,T3=CDR(T3))
		VALUES(i)=CAR(T3);
	APPLY(V7,(*LK0),&VALUES(0))               /*  MEMBER1         */;
	if(VALUES(0)!=Cnil){
	goto L70;}
	}
	{object V7= car((V1));
	{ int V8, i=0;
	T0= cdr((V1));
	T1= (V2);
	T2= (V3);
	V8=length(T2);
	VALUES(i++)=T0;
	VALUES(i++)=T1;
	V8+=i;
	for (; i<V8;i++,T2=CDR(T2))
		VALUES(i)=CAR(T2);
	APPLY(V8,L6,&VALUES(0))                   /*  SET-DIFFERENCE  */;
	}
	VALUES(0) = CONS(V7,VALUES(0));
	RETURN(1);}
L70:
	{ int V8, i=0;
	T0= cdr((V1));
	T1= (V2);
	T2= (V3);
	V8=length(T2);
	VALUES(i++)=T0;
	VALUES(i++)=T1;
	V8+=i;
	for (; i<V8;i++,T2=CDR(T2))
		VALUES(i)=CAR(T2);
	RETURN(APPLY(V8,L6,&VALUES(0))            /*  SET-DIFFERENCE  */);
	}
	}
}
/*	function definition for NSET-DIFFERENCE                       */
static L7(int narg, object V1,object V2, ...)
{ VT8 VLEX8 CLSR8
	cs_reserve(VM8);
	{int i=2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg=narg-i;
	V3=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object keyvars[6];
	parse_key(narg,args,3,L7keys,keyvars,V3,FALSE);
	V4= keyvars[0];
	V5= keyvars[1];
	V6= keyvars[2];
	}
	if(((V1))!=Cnil){
	goto L83;}
	VALUES(0) = Cnil;
	RETURN(1);
L83:
	T0=symbol_function(VV[14]);
	{ int V7, i=0;
	T1= car((V1));
	T2= (V2);
	T3= (V3);
	V7=length(T3);
	VALUES(i++)=T1;
	VALUES(i++)=T2;
	V7+=i;
	for (; i<V7;i++,T3=CDR(T3))
		VALUES(i)=CAR(T3);
	APPLY(V7,(*LK0),&VALUES(0))               /*  MEMBER1         */;
	if(VALUES(0)!=Cnil){
	goto L86;}
	}
	{ int V7, i=0;
	T0= cdr((V1));
	T1= (V2);
	T2= (V3);
	V7=length(T2);
	VALUES(i++)=T0;
	VALUES(i++)=T1;
	V7+=i;
	for (; i<V7;i++,T2=CDR(T2))
		VALUES(i)=CAR(T2);
	APPLY(V7,L7,&VALUES(0))                   /*  NSET-DIFFERENCE */;
	}
	if(type_of((V1))!=t_cons)FEwrong_type_argument(Scons,(V1));
	CDR((V1)) = VALUES(0);
	VALUES(0) = (V1);
	RETURN(1);
L86:
	{ int V7, i=0;
	T0= cdr((V1));
	T1= (V2);
	T2= (V3);
	V7=length(T2);
	VALUES(i++)=T0;
	VALUES(i++)=T1;
	V7+=i;
	for (; i<V7;i++,T2=CDR(T2))
		VALUES(i)=CAR(T2);
	RETURN(APPLY(V7,L7,&VALUES(0))            /*  NSET-DIFFERENCE */);
	}
	}
}
/*	function definition for SET-EXCLUSIVE-OR                      */
static L8(int narg, object V1,object V2, ...)
{ VT9 VLEX9 CLSR9
	cs_reserve(VM9);
	{int i=2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg=narg-i;
	V3=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object keyvars[6];
	parse_key(narg,args,3,L8keys,keyvars,V3,FALSE);
	V4= keyvars[0];
	V5= keyvars[1];
	V6= keyvars[2];
	}
	{ int V7, i=0;
	T1= (V1);
	T2= (V2);
	T3= (V3);
	V7=length(T3);
	VALUES(i++)=T1;
	VALUES(i++)=T2;
	V7+=i;
	for (; i<V7;i++,T3=CDR(T3))
		VALUES(i)=CAR(T3);
	APPLY(V7,L6,&VALUES(0))                   /*  SET-DIFFERENCE  */;
	T0= VALUES(0);
	}
	{ int V7, i=0;
	T1= (V2);
	T2= (V1);
	T3= (V3);
	V7=length(T3);
	VALUES(i++)=T1;
	VALUES(i++)=T2;
	V7+=i;
	for (; i<V7;i++,T3=CDR(T3))
		VALUES(i)=CAR(T3);
	APPLY(V7,L6,&VALUES(0))                   /*  SET-DIFFERENCE  */;
	}
	VALUES(0) = append(T0,VALUES(0));
	RETURN(1);
	}
}
/*	function definition for NSET-EXCLUSIVE-OR                     */
static L9(int narg, object V1,object V2, ...)
{ VT10 VLEX10 CLSR10
	cs_reserve(VM10);
	{int i=2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg=narg-i;
	V3=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object keyvars[6];
	parse_key(narg,args,3,L9keys,keyvars,V3,FALSE);
	V4= keyvars[0];
	V5= keyvars[1];
	V6= keyvars[2];
	}
	{ int V7, i=0;
	T1= (V1);
	T2= (V2);
	T3= (V3);
	V7=length(T3);
	VALUES(i++)=T1;
	VALUES(i++)=T2;
	V7+=i;
	for (; i<V7;i++,T3=CDR(T3))
		VALUES(i)=CAR(T3);
	APPLY(V7,L6,&VALUES(0))                   /*  SET-DIFFERENCE  */;
	T0= VALUES(0);
	}
	{ int V7, i=0;
	T1= (V2);
	T2= (V1);
	T3= (V3);
	V7=length(T3);
	VALUES(i++)=T1;
	VALUES(i++)=T2;
	V7+=i;
	for (; i<V7;i++,T3=CDR(T3))
		VALUES(i)=CAR(T3);
	APPLY(V7,L7,&VALUES(0))                   /*  NSET-DIFFERENCE */;
	}
	VALUES(0) = nconc(T0,VALUES(0));
	RETURN(1);
	}
}
/*	function definition for SUBSETP                               */
static L10(int narg, object V1,object V2, ...)
{ VT11 VLEX11 CLSR11
	cs_reserve(VM11);
	{int i=2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg=narg-i;
	V3=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object keyvars[6];
	parse_key(narg,args,3,L10keys,keyvars,V3,FALSE);
	V4= keyvars[0];
	V5= keyvars[1];
	V6= keyvars[2];
	}
	{object V7;                               /*  L               */
	V7= (V1);
L115:
	if(((V7))!=Cnil){
	goto L116;}
	VALUES(0) = Ct;
	RETURN(1);
L116:
	T0=symbol_function(VV[14]);
	{ int V9, i=0;
	T1= car((V7));
	T2= (V2);
	T3= (V3);
	V9=length(T3);
	VALUES(i++)=T1;
	VALUES(i++)=T2;
	V9+=i;
	for (; i<V9;i++,T3=CDR(T3))
		VALUES(i)=CAR(T3);
	APPLY(V9,(*LK0),&VALUES(0))               /*  MEMBER1         */;
	if(VALUES(0)!=Cnil){
	goto L120;}
	}
	VALUES(0) = Cnil;
	RETURN(1);
L120:
	V7= cdr((V7));
	goto L115;
	}
	}
}
static LKF0(int narg, ...) {TRAMPOLINK(VV[14],&LK0);}
