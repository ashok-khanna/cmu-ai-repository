
#include "bufmac.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	MM0(VV[60],L1);
	MM0(VV[61],L2);
	MM0(VV[62],L3);
	MM0(VV[63],L4);
	MM0(VV[64],L5);
	MM0(VV[65],L6);
	MM0(VV[66],L7);
	MM0(VV[67],L8);
	MM0(VV[24],L9);
	MM0(VV[68],L10);
	(void)putprop(VV[41],VV[39],siSpretty_print_format);
	
	MM0(VV[41],L11);
	(void)putprop(VV[69],VV[59],siSpretty_print_format);
	
	MM0(VV[69],L12);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	macro definition for WRITE-CARD8                              */
static L1(int narg, object V1, object V2)
{ VT3 VLEX3 CLSR3
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	{object V6= list(3,VV[1],VV[2],(V5));
	VALUES(0) = list(4,VV[0],(V6),VV[3],list(3,VV[4],VV[5],(V4)));
	RETURN(1);}}
}
/*	macro definition for WRITE-INT8                               */
static L2(int narg, object V1, object V2)
{ VT4 VLEX4 CLSR4
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	{object V6= list(3,VV[1],VV[7],(V5));
	VALUES(0) = list(4,VV[6],(V6),VV[3],list(3,VV[4],VV[5],(V4)));
	RETURN(1);}}
}
/*	macro definition for WRITE-CARD16                             */
static L3(int narg, object V1, object V2)
{ VT5 VLEX5 CLSR5
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	{object V6= list(3,VV[1],VV[9],(V5));
	VALUES(0) = list(4,VV[8],(V6),VV[3],list(3,VV[4],VV[5],(V4)));
	RETURN(1);}}
}
/*	macro definition for WRITE-INT16                              */
static L4(int narg, object V1, object V2)
{ VT6 VLEX6 CLSR6
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	{object V6= list(3,VV[1],VV[11],(V5));
	VALUES(0) = list(4,VV[10],(V6),VV[3],list(3,VV[4],VV[5],(V4)));
	RETURN(1);}}
}
/*	macro definition for WRITE-CARD32                             */
static L5(int narg, object V1, object V2)
{ VT7 VLEX7 CLSR7
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	{object V6= list(3,VV[1],VV[13],(V5));
	VALUES(0) = list(4,VV[12],(V6),VV[3],list(3,VV[4],VV[5],(V4)));
	RETURN(1);}}
}
/*	macro definition for WRITE-INT32                              */
static L6(int narg, object V1, object V2)
{ VT8 VLEX8 CLSR8
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	{object V6= list(3,VV[1],VV[15],(V5));
	VALUES(0) = list(4,VV[14],(V6),VV[3],list(3,VV[4],VV[5],(V4)));
	RETURN(1);}}
}
/*	macro definition for WRITE-CARD29                             */
static L7(int narg, object V1, object V2)
{ VT9 VLEX9 CLSR9
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	{object V6= list(3,VV[1],VV[17],(V5));
	VALUES(0) = list(4,VV[16],(V6),VV[3],list(3,VV[4],VV[5],(V4)));
	RETURN(1);}}
}
/*	macro definition for WRITE-CHAR2B                             */
static L8(int narg, object V1, object V2)
{ VT10 VLEX10 CLSR10
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	{object V6= list(2,VV[19],(V5));
	VALUES(0) = listA(3,VV[18],list(2,(V6),list(2,VV[20],list(3,VV[4],VV[5],(V4)))),VV[21]);
	RETURN(1);}}
}
/*	macro definition for SET-BUFFER-OFFSET                        */
static L9(int narg, object V1, object V2)
{ VT11 VLEX11 CLSR11
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = listA(3,VV[18],CONS(list(2,VV[22],(V4)),Cnil),VV[23]);
	RETURN(1);}
}
/*	macro definition for ADVANCE-BUFFER-OFFSET                    */
static L10(int narg, object V1, object V2)
{ VT12 VLEX12 CLSR12
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(2,VV[24],list(3,VV[4],VV[5],(V4)));
	RETURN(1);}
}
/*	macro definition for WITH-BUFFER-OUTPUT                       */
static L11(int narg, object V1, object V2)
{ VT13 VLEX13 CLSR13
	{object V3=CDR(V1),V4,V5,V6,V7,V8;
	{object V9= CAR(V3);
	V4= CAR(V9);
	V9=CDR(V9);
	{object V10;
	V10=getf(V9,VV[45],OBJNULL);
	if(V10==OBJNULL){
	V5= VV[25];
	} else {
	V5= V10;}
	V10=getf(V9,VV[70],OBJNULL);
	if(V10==OBJNULL){
	V6= Cnil;
	} else {
	V6= V10;}
	V10=getf(V9,VV[43],OBJNULL);
	if(V10==OBJNULL){
	V7= Cnil;
	} else {
	V7= V10;}}}
	V3=CDR(V3);
	V8= V3;
	if(type_of((V5))==t_cons||(V5)==Cnil){
	goto L5;}
	V5= CONS((V5),Cnil);
L5:
	{object V11= CONS(list(2,VV[26],(V4)),Cnil);
	(*LK0)(0)                                 /*  DECLARE-BUFMAC  */;
	T0= VALUES(0);
	if(((V6))==Cnil){
	goto L12;}
	T1= list(3,VV[28],list(3,VV[29],list(3,VV[4],VV[30],(V6)),VV[31]),VV[32]);
	goto L10;
L12:
	T1= Cnil;
L10:
	if((V7)!=Cnil){
	VALUES(0) = (V7);
	goto L14;}
	VALUES(0) = VV[35];
L14:
	VALUES(0) = list(6,VV[18],(V11),VV[27],T0,T1,listA(7,VV[33],list(2,list(2,VV[5],list(3,VV[1],VV[34],VALUES(0))),VV[36]),VV[37],VV[38],VV[5],VV[3],(V8)));
	RETURN(1);}}
}
/*	macro definition for WRITING-BUFFER-CHUNKS                    */
static L12(int narg, object V1, object V2)
{ VT14 VLEX14 CLSR14
	{object V3=CDR(V1),V4,V5,V6,V7;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= CAR(V3);
	V3=CDR(V3);
	V7= V3;
	if(!((length((V7)))>(2))){
	goto L15;}
	Lerror(1,VV[40])                          /*  ERROR           */;
L15:
	{object V8;                               /*  SIZE            */
	object V9;                                /*  FORM            */
	(*LK1)(1,(V4))                            /*  INDEX-INCREMENT */;
	V8= number_times(MAKE_FIXNUM(8),VALUES(0));
	V9= CAR((V7));
	Ladjoin(2,(V8),VV[46])                    /*  ADJOIN          */;
	{object V10= list(5,VV[42],VV[43],VV[44],VV[45],reverse(VALUES(0)));
	if(!(number_compare((V8),MAKE_FIXNUM(8))==0)){
	goto L24;}
	VALUES(0) = VV[49];
	goto L22;
L24:
	Ltruncate(2,(V8),MAKE_FIXNUM(16))         /*  TRUNCATE        */;
	VALUES(0) = list(3,VV[50],VV[51],VALUES(0));
L22:
	{object V11= append((V5),list(2,list(3,VV[48],VALUES(0),VV[52]),VV[53]));
	VALUES(0) = list(4,VV[41],(V10),listA(6,VV[47],(V11),VV[54],CONS(VV[55],append((V6),VV[56])),(V9),VV[57]),VV[58]);
	RETURN(1);}}
	}}
}
static LKF1(int narg, ...) {TRAMPOLINK(VV[72],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[71],&LK0);}
