
#include "image.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	(void)putprop(VV[219],VV[11],siSpretty_print_format);
	
	MM0(VV[219],L1);
	funcall(2,VV[220]->s.s_gfdef,VV[12])      /*  FIND-CLASS      */;
	funcall(9,VV[221]->s.s_gfdef,VALUES(0),VV[13],VV[14],VV[15],Cnil,VV[16],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[220]->s.s_gfdef,VV[13])      /*  FIND-CLASS      */;
	funcall(13,VV[222]->s.s_gfdef,VV[13],VV[17],Cnil,Cnil,VV[18],VV[19],Cnil,Cnil,Cnil,Cnil,MAKE_FIXNUM(4),Cnil)/*  DEFINE-STRUCTURE*/;
	MM0(VV[223],L2);
	MM0(VV[224],L3);
	MM0(VV[225],L4);
	MM0(VV[226],L5);
	MM0(VV[227],L6);
	MM0(VV[228],L7);
	MF0(VV[46],L8);
	(void)putprop(VV[46],VV[Vdeb46],VV[229]);
	siLAmake_constant(2,VV[31],VV[32])        /*  *MAKE-CONSTANT  */;
	siLAmake_constant(2,VV[33],VV[34])        /*  *MAKE-CONSTANT  */;
	funcall(2,VV[220]->s.s_gfdef,VV[12])      /*  FIND-CLASS      */;
	funcall(9,VV[221]->s.s_gfdef,VALUES(0),VV[35],VV[36],VV[37],Cnil,VV[38],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[220]->s.s_gfdef,VV[35])      /*  FIND-CLASS      */;
	VV[230] = make_cfun(LC10,Cnil,&Cblock);
	VALUES(0) = VV[230];
	funcall(8,VV[231]->s.s_gfdef,VV[39],Cnil,VV[40],VV[41],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	funcall(13,VV[222]->s.s_gfdef,VV[35],VV[43],Cnil,Cnil,VV[44],VV[45],Cnil,VV[13],VV[46],VV[47],MAKE_FIXNUM(13),Cnil)/*  DEFINE-STRUCTURE*/;
	VV[49]=string_to_object(VV[49]);
	MF0key(VV[232],L11,13,L11keys);
	(void)putprop(VV[232],VV[Vdeb232],VV[229]);
	funcall(5,VV[233]->s.s_gfdef,VV[35],Cnil,Cnil,Cnil)/*  MAKE-PREDICATE*/;
	siLfset(2,VV[50],VALUES(0))               /*  FSET            */;
	funcall(2,VV[220]->s.s_gfdef,VV[12])      /*  FIND-CLASS      */;
	funcall(9,VV[221]->s.s_gfdef,VALUES(0),VV[51],VV[52],VV[53],Cnil,VV[54],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[220]->s.s_gfdef,VV[51])      /*  FIND-CLASS      */;
	VV[234] = make_cfun(LC12,Cnil,&Cblock);
	VALUES(0) = VV[234];
	funcall(8,VV[231]->s.s_gfdef,VV[39],Cnil,VV[55],VV[56],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	funcall(13,VV[222]->s.s_gfdef,VV[51],VV[57],Cnil,Cnil,VV[58],VV[59],Cnil,VV[13],VV[46],VV[60],MAKE_FIXNUM(5),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[235],L13,5,L13keys);
	(void)putprop(VV[235],VV[Vdeb235],VV[229]);
	funcall(5,VV[233]->s.s_gfdef,VV[51],Cnil,Cnil,Cnil)/*  MAKE-PREDICATE*/;
	siLfset(2,VV[61],VALUES(0))               /*  FSET            */;
	funcall(2,VV[220]->s.s_gfdef,VV[12])      /*  FIND-CLASS      */;
	funcall(9,VV[221]->s.s_gfdef,VALUES(0),VV[62],VV[63],VV[64],Cnil,VV[65],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[220]->s.s_gfdef,VV[62])      /*  FIND-CLASS      */;
	VV[236] = make_cfun(LC14,Cnil,&Cblock);
	VALUES(0) = VV[236];
	funcall(8,VV[231]->s.s_gfdef,VV[39],Cnil,VV[66],VV[67],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	funcall(13,VV[222]->s.s_gfdef,VV[62],VV[68],Cnil,Cnil,VV[69],VV[70],Cnil,VV[13],VV[46],VV[71],MAKE_FIXNUM(6),Cnil)/*  DEFINE-STRUCTURE*/;
	VV[72]=string_to_object(VV[72]);
	MF0key(VV[237],L15,6,L15keys);
	(void)putprop(VV[237],VV[Vdeb237],VV[229]);
	funcall(5,VV[233]->s.s_gfdef,VV[62],Cnil,Cnil,Cnil)/*  MAKE-PREDICATE*/;
	siLfset(2,VV[73],VALUES(0))               /*  FSET            */;
	MF0key(VV[238],L16,19,L16keys);
	(void)putprop(VV[238],VV[Vdeb238],VV[229]);
	MF0(VV[119],L17);
	(void)putprop(VV[119],VV[Vdeb119],VV[229]);
	MF0(VV[122],L18);
	(void)putprop(VV[122],VV[Vdeb122],VV[229]);
	MF0(VV[124],L19);
	(void)putprop(VV[124],VV[Vdeb124],VV[229]);
	MF0(VV[125],L20);
	(void)putprop(VV[125],VV[Vdeb125],VV[229]);
	MF0(VV[239],L21);
	(void)putprop(VV[239],VV[Vdeb239],VV[229]);
	MF0(VV[121],L22);
	(void)putprop(VV[121],VV[Vdeb121],VV[229]);
	MF0(VV[240],L23);
	(void)putprop(VV[240],VV[Vdeb240],VV[229]);
	siLAmake_constant(2,VV[107],VV[108])      /*  *MAKE-CONSTANT  */;
	VV[109]=string_to_object(VV[109]);
	MF0(VV[241],L24);
	(void)putprop(VV[241],VV[Vdeb241],VV[229]);
	MF0(VV[242],L25);
	(void)putprop(VV[242],VV[Vdeb242],VV[229]);
	MF0(VV[243],L26);
	(void)putprop(VV[243],VV[Vdeb243],VV[229]);
	MF0(VV[244],L27);
	(void)putprop(VV[244],VV[Vdeb244],VV[229]);
	siLAmake_constant(2,VV[110],VV[111])      /*  *MAKE-CONSTANT  */;
	siLAmake_constant(2,VV[112],VV[113])      /*  *MAKE-CONSTANT  */;
	VV[117]=string_to_object(VV[117]);
	VV[118]=string_to_object(VV[118]);
	MF0(VV[245],L28);
	(void)putprop(VV[245],VV[Vdeb245],VV[229]);
	MF0(VV[246],L29);
	(void)putprop(VV[246],VV[Vdeb246],VV[229]);
	MF0(VV[247],L30);
	(void)putprop(VV[247],VV[Vdeb247],VV[229]);
	MF0(VV[248],L31);
	(void)putprop(VV[248],VV[Vdeb248],VV[229]);
	MF0(VV[249],L32);
	(void)putprop(VV[249],VV[Vdeb249],VV[229]);
	MF0(VV[250],L33);
	(void)putprop(VV[250],VV[Vdeb250],VV[229]);
	MF0(VV[251],L34);
	(void)putprop(VV[251],VV[Vdeb251],VV[229]);
	MF0(VV[252],L35);
	(void)putprop(VV[252],VV[Vdeb252],VV[229]);
	MF0(VV[253],L36);
	(void)putprop(VV[253],VV[Vdeb253],VV[229]);
	MF0(VV[254],L37);
	(void)putprop(VV[254],VV[Vdeb254],VV[229]);
	MF0(VV[255],L38);
	(void)putprop(VV[255],VV[Vdeb255],VV[229]);
	MF0(VV[256],L39);
	(void)putprop(VV[256],VV[Vdeb256],VV[229]);
	MF0(VV[257],L40);
	(void)putprop(VV[257],VV[Vdeb257],VV[229]);
	MF0key(VV[258],L41,8,L41keys);
	(void)putprop(VV[258],VV[Vdeb258],VV[229]);
	MF0(VV[259],L42);
	(void)putprop(VV[259],VV[Vdeb259],VV[229]);
	MF0(VV[260],L43);
	(void)putprop(VV[260],VV[Vdeb260],VV[229]);
	MF0(VV[261],L44);
	(void)putprop(VV[261],VV[Vdeb261],VV[229]);
	MF0(VV[262],L45);
	(void)putprop(VV[262],VV[Vdeb262],VV[229]);
	MF0(VV[263],L46);
	(void)putprop(VV[263],VV[Vdeb263],VV[229]);
	MF0(VV[264],L47);
	(void)putprop(VV[264],VV[Vdeb264],VV[229]);
	MF0(VV[265],L48);
	(void)putprop(VV[265],VV[Vdeb265],VV[229]);
	MF0(VV[266],L49);
	(void)putprop(VV[266],VV[Vdeb266],VV[229]);
	MF0(VV[267],L50);
	(void)putprop(VV[267],VV[Vdeb267],VV[229]);
	MF0(VV[268],L51);
	(void)putprop(VV[268],VV[Vdeb268],VV[229]);
	MF0(VV[269],L52);
	(void)putprop(VV[269],VV[Vdeb269],VV[229]);
	MF0(VV[270],L53);
	(void)putprop(VV[270],VV[Vdeb270],VV[229]);
	MF0(VV[271],L54);
	(void)putprop(VV[271],VV[Vdeb271],VV[229]);
	MF0(VV[272],L55);
	(void)putprop(VV[272],VV[Vdeb272],VV[229]);
	MF0key(VV[273],L56,7,L56keys);
	(void)putprop(VV[273],VV[Vdeb273],VV[229]);
	MF0(VV[274],L57);
	(void)putprop(VV[274],VV[Vdeb274],VV[229]);
	MF0(VV[275],L58);
	(void)putprop(VV[275],VV[Vdeb275],VV[229]);
	MF0(VV[276],L59);
	(void)putprop(VV[276],VV[Vdeb276],VV[229]);
	MF0(VV[277],L60);
	(void)putprop(VV[277],VV[Vdeb277],VV[229]);
	MF0(VV[278],L61);
	(void)putprop(VV[278],VV[Vdeb278],VV[229]);
	MF0(VV[279],L62);
	(void)putprop(VV[279],VV[Vdeb279],VV[229]);
	MF0(VV[280],L63);
	(void)putprop(VV[280],VV[Vdeb280],VV[229]);
	MF0(VV[281],L64);
	(void)putprop(VV[281],VV[Vdeb281],VV[229]);
	MF0(VV[282],L66);
	(void)putprop(VV[282],VV[Vdeb282],VV[229]);
	MF0(VV[283],L67);
	(void)putprop(VV[283],VV[Vdeb283],VV[229]);
	MF0(VV[284],L68);
	(void)putprop(VV[284],VV[Vdeb284],VV[229]);
	MF0(VV[285],L69);
	(void)putprop(VV[285],VV[Vdeb285],VV[229]);
	MF0key(VV[286],L70,5,L70keys);
	(void)putprop(VV[286],VV[Vdeb286],VV[229]);
	MF0(VV[287],L71);
	(void)putprop(VV[287],VV[Vdeb287],VV[229]);
	MF0(VV[288],L75);
	(void)putprop(VV[288],VV[Vdeb288],VV[229]);
	MF0(VV[289],L76);
	(void)putprop(VV[289],VV[Vdeb289],VV[229]);
	MF0key(VV[290],L77,4,L77keys);
	(void)putprop(VV[290],VV[Vdeb290],VV[229]);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	local function CLOSURE                                        */
static LC14(int narg, object V1, object V2)
{ VT3 VLEX3 CLSR3
	RETURN(L8(3,(V1),(V2),(VV[42]->s.s_dbind))/*  PRINT-IMAGE     */);
}
/*	local function CLOSURE                                        */
static LC12(int narg, object V1, object V2)
{ VT4 VLEX4 CLSR4
	RETURN(L8(3,(V1),(V2),(VV[42]->s.s_dbind))/*  PRINT-IMAGE     */);
}
/*	local function CLOSURE                                        */
static LC10(int narg, object V1, object V2)
{ VT5 VLEX5 CLSR5
	RETURN(L8(3,(V1),(V2),(VV[42]->s.s_dbind))/*  PRINT-IMAGE     */);
}
/*	macro definition for WITH-IMAGE-DATA-BUFFER                   */
static L1(int narg, object V1, object V2)
{ VT6 VLEX6 CLSR6
	{object V3=CDR(V1),V4,V5,V6;
	{object V7= CAR(V3);
	V4= CAR(V7);
	V7=CDR(V7);
	V5= CAR(V7);}
	V3=CDR(V3);
	V6= V3;
	{object V8= CONS(list(2,VV[1],list(2,VV[2],(V5))),Cnil);
	{object V9= CONS(list(2,(V4),VV[5]),Cnil);
	{object V10= list(2,VV[6],list(3,VV[7],VV[8],(V4)));
	VALUES(0) = list(4,VV[0],(V8),VV[3],list(3,VV[4],list(4,VV[0],(V9),(V10),listA(3,VV[9],list(2,(V4),VV[8]),(V6))),VV[10]));
	RETURN(1);}}}}
}
/*	macro definition for IMAGE-NAME                               */
static L2(int narg, object V1, object V2)
{ VT7 VLEX7 CLSR7
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(3,VV[20],list(2,VV[21],(V4)),VV[22]);
	RETURN(1);}
}
/*	macro definition for IMAGE-X-HOT                              */
static L3(int narg, object V1, object V2)
{ VT8 VLEX8 CLSR8
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(3,VV[20],list(2,VV[21],(V4)),VV[23]);
	RETURN(1);}
}
/*	macro definition for IMAGE-Y-HOT                              */
static L4(int narg, object V1, object V2)
{ VT9 VLEX9 CLSR9
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(3,VV[20],list(2,VV[21],(V4)),VV[24]);
	RETURN(1);}
}
/*	macro definition for IMAGE-RED-MASK                           */
static L5(int narg, object V1, object V2)
{ VT10 VLEX10 CLSR10
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(3,VV[20],list(2,VV[21],(V4)),VV[25]);
	RETURN(1);}
}
/*	macro definition for IMAGE-BLUE-MASK                          */
static L6(int narg, object V1, object V2)
{ VT11 VLEX11 CLSR11
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(3,VV[20],list(2,VV[21],(V4)),VV[26]);
	RETURN(1);}
}
/*	macro definition for IMAGE-GREEN-MASK                         */
static L7(int narg, object V1, object V2)
{ VT12 VLEX12 CLSR12
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(3,VV[20],list(2,VV[21],(V4)),VV[27]);
	RETURN(1);}
}
/*	function definition for PRINT-IMAGE                           */
static L8(int narg, object V1, object V2, object V3)
{ VT13 VLEX13 CLSR13
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(V1,env0));            /*  IMAGE           */
	CLV1=&CAR(env0=CONS(V2,env0));            /*  STREAM          */
	{ object V4;
	V4= make_cclosure(LC9,env0,&Cblock);
	RETURN((*LK0)(5,*CLV0,*CLV1,Ct,Cnil,(V4)) /*  PRINT-UNREADABLE-OBJECT-FUNCTION*/);
	}
}
/*	closure .PRINT-UNREADABLE-OBJECT-BODY.                        */
static LC9(int narg, object env0)
{ VT14 VLEX14 CLSR14
	narg--;
	{object scan=env0;
	CLV1= &CAR(scan);                         /*  STREAM          */ scan=CDR(scan);
	CLV0= &CAR(scan);                         /*  IMAGE           */}
TTL:
	Lgetf(2,(*CLV0)->in.in_slots[3],VV[22])   /*  GETF            */;
	if(VALUES(0)==Cnil){
	goto L43;}
	Lgetf(2,(*CLV0)->in.in_slots[3],VV[22])   /*  GETF            */;
	Lwrite_string(2,coerce_to_string(VALUES(0)),*CLV1)/*  WRITE-STRING*/;
	Lwrite_string(2,VV[28],*CLV1)             /*  WRITE-STRING    */;
L43:
	(*LK1)(1,*CLV0)                           /*  IMAGE-WIDTH     */;
	prin1(VALUES(0),*CLV1);
	Lwrite_string(2,VV[29],*CLV1)             /*  WRITE-STRING    */;
	(*LK2)(1,*CLV0)                           /*  IMAGE-HEIGHT    */;
	prin1(VALUES(0),*CLV1);
	Lwrite_string(2,VV[30],*CLV1)             /*  WRITE-STRING    */;
	(*LK3)(1,*CLV0)                           /*  IMAGE-DEPTH     */;
	VALUES(0) = prin1(VALUES(0),*CLV1);
	RETURN(1);
}
/*	function definition for MAKE-IMAGE-X                          */
static L11(int narg, ...)
{ VT15 VLEX15 CLSR15
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	object V10;
	object V11;
	object V12;
	object V13;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[26];
	parse_key(narg,args,13,L11keys,keyvars,OBJNULL,FALSE);
	if(keyvars[13]==Cnil){
	V1= MAKE_FIXNUM(0);
	}else{
	V1= keyvars[0];}
	if(keyvars[14]==Cnil){
	V2= MAKE_FIXNUM(0);
	}else{
	V2= keyvars[1];}
	if(keyvars[15]==Cnil){
	V3= MAKE_FIXNUM(1);
	}else{
	V3= keyvars[2];}
	V4= keyvars[3];
	if(keyvars[17]==Cnil){
	V5= VV[48];
	}else{
	V5= keyvars[4];}
	if(keyvars[18]==Cnil){
	V6= MAKE_FIXNUM(0);
	}else{
	V6= keyvars[5];}
	if(keyvars[19]==Cnil){
	V7= MAKE_FIXNUM(1);
	}else{
	V7= keyvars[6];}
	V8= keyvars[7];
	V9= keyvars[8];
	if(keyvars[22]==Cnil){
	V10= VV[49];
	}else{
	V10= keyvars[9];}
	if(keyvars[23]==Cnil){
	V11= MAKE_FIXNUM(32);
	}else{
	V11= keyvars[10];}
	if(keyvars[24]==Cnil){
	V12= MAKE_FIXNUM(32);
	}else{
	V12= keyvars[11];}
	if(keyvars[25]==Cnil){
	V13= MAKE_FIXNUM(0);
	}else{
	V13= keyvars[12];}
	}
	(*LK4)(1,VV[35])                          /*  FIND-CLASS      */;
	RETURN(siLmake_structure(14,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8),(V9),(V10),(V11),(V12),(V13))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for MAKE-IMAGE-XY                         */
static L13(int narg, ...)
{ VT16 VLEX16 CLSR16
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[10];
	parse_key(narg,args,5,L13keys,keyvars,OBJNULL,FALSE);
	if(keyvars[5]==Cnil){
	V1= MAKE_FIXNUM(0);
	}else{
	V1= keyvars[0];}
	if(keyvars[6]==Cnil){
	V2= MAKE_FIXNUM(0);
	}else{
	V2= keyvars[1];}
	if(keyvars[7]==Cnil){
	V3= MAKE_FIXNUM(1);
	}else{
	V3= keyvars[2];}
	V4= keyvars[3];
	V5= keyvars[4];
	}
	(*LK4)(1,VV[51])                          /*  FIND-CLASS      */;
	RETURN(siLmake_structure(6,VALUES(0),(V1),(V2),(V3),(V4),(V5))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for MAKE-IMAGE-Z                          */
static L15(int narg, ...)
{ VT17 VLEX17 CLSR17
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[12];
	parse_key(narg,args,6,L15keys,keyvars,OBJNULL,FALSE);
	if(keyvars[6]==Cnil){
	V1= MAKE_FIXNUM(0);
	}else{
	V1= keyvars[0];}
	if(keyvars[7]==Cnil){
	V2= MAKE_FIXNUM(0);
	}else{
	V2= keyvars[1];}
	if(keyvars[8]==Cnil){
	V3= MAKE_FIXNUM(1);
	}else{
	V3= keyvars[2];}
	V4= keyvars[3];
	if(keyvars[10]==Cnil){
	V5= MAKE_FIXNUM(1);
	}else{
	V5= keyvars[4];}
	if(keyvars[11]==Cnil){
	V6= VV[72];
	}else{
	V6= keyvars[5];}
	}
	(*LK4)(1,VV[62])                          /*  FIND-CLASS      */;
	RETURN(siLmake_structure(7,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for CREATE-IMAGE                          */
static L16(int narg, ...)
{ VT18 VLEX18 CLSR18
	{volatile object V1;
	volatile object V2;
	volatile object V3;
	volatile object V4;
	volatile object V5;
	volatile object V6;
	volatile object V7;
	volatile object V8;
	volatile object V9;
	volatile object V10;
	volatile object V11;
	volatile object V12;
	volatile object V13;
	volatile object V14;
	volatile object V15;
	volatile object V16;
	volatile object V17;
	volatile object V18;
	volatile object V19;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[38];
	parse_key(narg,args,19,L16keys,keyvars,OBJNULL,FALSE);
	V1= keyvars[0];
	V2= keyvars[1];
	V3= keyvars[2];
	if(keyvars[22]==Cnil){
	(*LK5)(3,VV[74],VV[75],VV[76])            /*  X-ERROR         */;
	V4= (VV[77]->s.s_dbind);
	}else{
	V4= keyvars[3];}
	V5= keyvars[4];
	V6= keyvars[5];
	V7= keyvars[6];
	V8= keyvars[7];
	V9= keyvars[8];
	V10= keyvars[9];
	V11= keyvars[10];
	V12= keyvars[11];
	V13= keyvars[12];
	V14= keyvars[13];
	V15= keyvars[14];
	V16= keyvars[15];
	V17= keyvars[16];
	V18= keyvars[17];
	V19= keyvars[18];
	}
	{volatile object V20;                     /*  IMAGE           */
	{volatile object V21;
	V21= (V4);
	(*LK6)(2,(V21),VV[8])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L80;}
	{volatile object V22;                     /*  DATA            */
	if(((V3))!=Cnil){
	goto L82;}
	if((V12)!=Cnil){
	V3= (V12);
	goto L85;}
	V3= MAKE_FIXNUM(1);
L85:
L82:
	if(((V13))!=Cnil){
	goto L86;}
	if(!(number_compare((V3),MAKE_FIXNUM(1))==0)){
	goto L91;}
	V13= VV[78];
	goto L89;
L91:
	V13= VV[48];
L89:
L86:
	if(((V12))!=Cnil){
	goto L93;}
	if(!(((V13))==(VV[78]))){
	goto L98;}
	V12= MAKE_FIXNUM(1);
	goto L96;
L98:
	if(!((fix((V3)))>(24))){
	goto L101;}
	V12= MAKE_FIXNUM(32);
	goto L96;
L101:
	if(!((fix((V3)))>(16))){
	goto L104;}
	V12= MAKE_FIXNUM(24);
	goto L96;
L104:
	if(!((fix((V3)))>(8))){
	goto L107;}
	V12= MAKE_FIXNUM(16);
	goto L96;
L107:
	if(!((fix((V3)))>(4))){
	goto L110;}
	V12= MAKE_FIXNUM(8);
	goto L96;
L110:
	if(!((fix((V3)))>(1))){
	goto L113;}
	V12= MAKE_FIXNUM(4);
	goto L96;
L113:
	V12= MAKE_FIXNUM(1);
L96:
L93:
	if(((V1))!=Cnil){
	goto L115;}
	(*LK5)(3,VV[74],VV[75],VV[79])            /*  X-ERROR         */;
L115:
	if(((V2))!=Cnil){
	goto L119;}
	(*LK5)(3,VV[74],VV[75],VV[80])            /*  X-ERROR         */;
L119:
	if(((V14))!=Cnil){
	goto L123;}
	{int V23;                                 /*  PAD             */
	object V24;                               /*  BITS-PER-LINE   */
	if((V18)!=Cnil){
	V23= fix((V18));
	goto L126;}
	V23= 8;
L126:
	V24= MAKE_FIXNUM((fix((V1)))*(fix((V12))));
	Lceiling(2,(V24),MAKE_FIXNUM(V23))        /*  CEILING         */;
	Lceiling(2,MAKE_FIXNUM((fix(VALUES(0)))*(V23)),MAKE_FIXNUM(8))/*  CEILING*/;
	V14= VALUES(0);
	}
L123:
	if(((V17))!=Cnil){
	goto L130;}
	V17= MAKE_FIXNUM(32);
L130:
	if(((V18))!=Cnil){
	goto L134;}
	{volatile object V23;
	volatile object V24;                      /*  PAD             */
	V23= VV[81];
	V24= Cnil;
L141:
	if(!((V23)==Cnil)){
	goto L142;}
	V18= Cnil;
	goto L137;
L142:
	V24= CAR((V23));
	if(!((fix((V24)))<=(32))){
	goto L147;}
	{int V26= (fix((V14)))*(8);
	if(!(((V26>=0&&fix((V24))>0?(V26)%(fix((V24))):imod(V26,fix((V24)))))==0)){
	goto L147;}}
	V18= (V24);
	goto L137;
L147:
	V23= CDR((V23));
	goto L141;
	}
L137:
L134:
	if(((V19))!=Cnil){
	goto L155;}
	V19= MAKE_FIXNUM(0);
L155:
	L11(26,VV[82],(V1),VV[83],(V2),VV[84],(V3),VV[85],(V5),VV[86],(V13),VV[87],(V4),VV[88],(V12),VV[89],(V14),VV[90],(V15),VV[91],(V16),VV[92],(V17),VV[93],(V18),VV[94],(V19))/*  MAKE-IMAGE-X*/;
	V20= VALUES(0);
	goto L78;
	}
L80:
	(*LK6)(2,(V21),VV[95])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L160;}
	{object V23;                              /*  DATA            */
	V23= (V4);
	if(((V3))!=Cnil){
	goto L162;}
	V3= MAKE_FIXNUM(length((V23)));
L162:
	if(((V23))==Cnil){
	goto L166;}
	if(((V1))!=Cnil){
	goto L169;}
	Larray_dimension(2,CAR((V23)),MAKE_FIXNUM(1))/*  ARRAY-DIMENSION*/;
	V1= VALUES(0);
L169:
	if(((V2))!=Cnil){
	goto L166;}
	Larray_dimension(2,CAR((V23)),MAKE_FIXNUM(0))/*  ARRAY-DIMENSION*/;
	V2= VALUES(0);
L166:
	L13(10,VV[82],(V1),VV[83],(V2),VV[85],(V5),VV[84],(V3),VV[96],(V23))/*  MAKE-IMAGE-XY*/;
	V20= VALUES(0);
	goto L78;
	}
L160:
	(*LK6)(2,(V21),VV[97])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L177;}
	{object V24;                              /*  DATA            */
	V24= (V4);
	if(((V1))!=Cnil){
	goto L180;}
	Larray_dimension(2,(V24),MAKE_FIXNUM(1))  /*  ARRAY-DIMENSION */;
	V1= VALUES(0);
L180:
	if(((V2))!=Cnil){
	goto L184;}
	Larray_dimension(2,(V24),MAKE_FIXNUM(0))  /*  ARRAY-DIMENSION */;
	V2= VALUES(0);
L184:
	if(((V12))!=Cnil){
	goto L179;}
	{object V25;
	V25= (V24);
	(*LK6)(2,(V25),VV[98])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L192;}
	V12= MAKE_FIXNUM(32);
	goto L190;
L192:
	(*LK6)(2,(V25),VV[99])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L195;}
	V12= MAKE_FIXNUM(24);
	goto L190;
L195:
	(*LK6)(2,(V25),VV[100])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L198;}
	V12= MAKE_FIXNUM(16);
	goto L190;
L198:
	(*LK6)(2,(V25),VV[101])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L201;}
	V12= MAKE_FIXNUM(8);
	goto L190;
L201:
	(*LK6)(2,(V25),VV[102])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L204;}
	V12= MAKE_FIXNUM(4);
	goto L190;
L204:
	(*LK6)(2,(V25),VV[103])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L207;}
	V12= MAKE_FIXNUM(1);
	goto L190;
L207:
	(*LK7)(3,VV[76],(V25),VV[104])            /*  TYPECASE-ERROR-STRING*/;
	Lerror(1,VALUES(0))                       /*  ERROR           */;
	V12= VALUES(0);
	}
L190:
	}
L179:
	if(((V3))!=Cnil){
	goto L210;}
	V3= (V12);
L210:
	L15(12,VV[82],(V1),VV[83],(V2),VV[84],(V3),VV[85],(V5),VV[88],(V12),VV[105],(V4))/*  MAKE-IMAGE-Z*/;
	V20= VALUES(0);
	goto L78;
L177:
	(*LK7)(3,VV[76],(V21),VV[106])            /*  TYPECASE-ERROR-STRING*/;
	Lerror(1,VALUES(0))                       /*  ERROR           */;
	V20= VALUES(0);
	}
L78:
	if(((V6))==Cnil){
	goto L215;}
	{object V21;
	siLput_f(3,((V20))->in.in_slots[3],(V6),VV[22])/*  PUT-F      */;
	V21= VALUES(0);
	((V20))->in.in_slots[3]= (V21);
	}
L215:
	if(((V7))==Cnil){
	goto L220;}
	{object V21;
	siLput_f(3,((V20))->in.in_slots[3],(V7),VV[23])/*  PUT-F      */;
	V21= VALUES(0);
	((V20))->in.in_slots[3]= (V21);
	}
L220:
	if(((V8))==Cnil){
	goto L225;}
	{object V21;
	siLput_f(3,((V20))->in.in_slots[3],(V8),VV[24])/*  PUT-F      */;
	V21= VALUES(0);
	((V20))->in.in_slots[3]= (V21);
	}
L225:
	if(((V9))==Cnil){
	goto L230;}
	{object V21;
	siLput_f(3,((V20))->in.in_slots[3],(V9),VV[25])/*  PUT-F      */;
	V21= VALUES(0);
	((V20))->in.in_slots[3]= (V21);
	}
L230:
	if(((V10))==Cnil){
	goto L235;}
	{object V21;
	siLput_f(3,((V20))->in.in_slots[3],(V10),VV[26])/*  PUT-F     */;
	V21= VALUES(0);
	((V20))->in.in_slots[3]= (V21);
	}
L235:
	if(((V11))==Cnil){
	goto L240;}
	{object V21;
	siLput_f(3,((V20))->in.in_slots[3],(V11),VV[27])/*  PUT-F     */;
	V21= VALUES(0);
	((V20))->in.in_slots[3]= (V21);
	}
L240:
	VALUES(0) = (V20);
	RETURN(1);
	}
	}
}
/*	function definition for IMAGE-NOSWAP                          */
static L17(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT19 VLEX19 CLSR19
	{volatile int V10;
	volatile int V11;
	volatile int V12;
	volatile int V13;
	volatile int V14;
	volatile int V15;
	V10= fix(V3);
	V11= fix(V4);
	V12= fix(V5);
	V13= fix(V6);
	V14= fix(V7);
	V15= fix(V8);
TTL:
	if(!((V13)==(V14))){
	goto L246;}
	RETURN((*LK8)(5,(V2),(V1),MAKE_FIXNUM(V11),MAKE_FIXNUM(((V11)+((V13)*((V15)-1)))+(V12)),MAKE_FIXNUM(V10))/*  BUFFER-REPLACE*/);
L246:
	{volatile int V16;                        /*  H               */
	volatile int V17;                         /*  SRCSTART        */
	volatile int V18;                         /*  DESTSTART       */
	volatile int V19;                         /*  DESTEND         */
	V16= V15;
	V17= V10;
	V18= V11;
	V19= (V18)+(V12);
L253:
	if(!((V16)==0)){
	goto L254;}
	VALUES(0) = Cnil;
	RETURN(1);
L254:
	(*LK8)(5,(V2),(V1),MAKE_FIXNUM(V18),MAKE_FIXNUM(V19),MAKE_FIXNUM(V17))/*  BUFFER-REPLACE*/;
	V16= (V16)-1;
	V17= (V17)+(V13);
	V18= (V18)+(V14);
	V19= (V18)+(V12);
	goto L253;
	}
	}
}
/*	function definition for IMAGE-SWAP-TWO-BYTES                  */
static L18(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT20 VLEX20 CLSR20
	{volatile int V10;
	volatile int V11;
	volatile int V12;
	V10= fix(V5);
	V11= fix(V6);
	V12= fix(V7);
TTL:
	{volatile object V13;                     /*  SRC             */
	V13= (V1);
	{volatile object V14;                     /*  DEST            */
	V14= (V2);
	{volatile int V15;                        /*  LENGTH          */
	volatile int V16;                         /*  H               */
	volatile int V17;                         /*  SRCSTART        */
	volatile int V18;                         /*  DESTSTART       */
	Lceiling(2,MAKE_FIXNUM(V10),MAKE_FIXNUM(2))/*  CEILING        */;
	V15= (fix(VALUES(0)))*(2);
	V16= fix((V8));
	V17= fix((V3));
	V18= fix((V4));
L273:
	if(!((V16)==0)){
	goto L274;}
	VALUES(0) = Cnil;
	RETURN(1);
L274:
	if(!((V16)==(1))){
	goto L277;}
	if((V10)==(V15)){
	goto L277;}
	V15= (V15)-(2);
	if(((V9))==Cnil){
	goto L285;}
	((V14))->ust.ust_self[((V18)+(V15))+1]= ((V13))->ust.ust_self[(V17)+(V15)];
	goto L277;
L285:
	((V14))->ust.ust_self[(V18)+(V15)]= ((V13))->ust.ust_self[((V17)+(V15))+1];
L277:
	{volatile int V20;                        /*  I               */
	volatile int V21;                         /*  SRCIDX          */
	volatile int V22;                         /*  DESTIDX         */
	V20= V15;
	V21= V17;
	V22= V18;
L292:
	if(!((V20)==0)){
	goto L293;}
	goto L287;
L293:
	((V14))->ust.ust_self[V22]= ((V13))->ust.ust_self[(V21)+1];
	((V14))->ust.ust_self[(V22)+1]= ((V13))->ust.ust_self[V21];
	V20= (V20)-(2);
	V21= (V21)+(2);
	V22= (V22)+(2);
	goto L292;
	}
L287:
	V16= (V16)-1;
	V17= (V17)+(V11);
	V18= (V18)+(V12);
	goto L273;
	}
	}
	}
	}
}
/*	function definition for IMAGE-SWAP-THREE-BYTES                */
static L19(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT21 VLEX21 CLSR21
	{volatile int V10;
	volatile int V11;
	volatile int V12;
	V10= fix(V5);
	V11= fix(V6);
	V12= fix(V7);
TTL:
	{volatile object V13;                     /*  SRC             */
	V13= (V1);
	{volatile object V14;                     /*  DEST            */
	V14= (V2);
	{volatile int V15;                        /*  LENGTH          */
	volatile int V16;                         /*  H               */
	volatile int V17;                         /*  SRCSTART        */
	volatile int V18;                         /*  DESTSTART       */
	Lceiling(2,MAKE_FIXNUM(V10),MAKE_FIXNUM(3))/*  CEILING        */;
	V15= (fix(VALUES(0)))*(3);
	V16= fix((V8));
	V17= fix((V3));
	V18= fix((V4));
L314:
	if(!((V16)==0)){
	goto L315;}
	VALUES(0) = Cnil;
	RETURN(1);
L315:
	if(!((V16)==(1))){
	goto L318;}
	if((V10)==(V15)){
	goto L318;}
	V15= (V15)-(3);
	if(!(((V10)-(V15))==(2))){
	goto L325;}
	((V14))->ust.ust_self[((V18)+(V15))+(1)]= ((V13))->ust.ust_self[((V17)+(V15))+(1)];
L325:
	if(((V9))==Cnil){
	goto L329;}
	((V14))->ust.ust_self[((V18)+(V15))+(2)]= ((V13))->ust.ust_self[(V17)+(V15)];
	goto L318;
L329:
	((V14))->ust.ust_self[(V18)+(V15)]= ((V13))->ust.ust_self[((V17)+(V15))+(2)];
L318:
	{volatile int V20;                        /*  I               */
	volatile int V21;                         /*  SRCIDX          */
	volatile int V22;                         /*  DESTIDX         */
	V20= V15;
	V21= V17;
	V22= V18;
L336:
	if(!((V20)==0)){
	goto L337;}
	goto L331;
L337:
	((V14))->ust.ust_self[V22]= ((V13))->ust.ust_self[(V21)+(2)];
	((V14))->ust.ust_self[(V22)+1]= ((V13))->ust.ust_self[(V21)+1];
	((V14))->ust.ust_self[(V22)+(2)]= ((V13))->ust.ust_self[V21];
	V20= (V20)-(3);
	V21= (V21)+(3);
	V22= (V22)+(3);
	goto L336;
	}
L331:
	V16= (V16)-1;
	V17= (V17)+(V11);
	V18= (V18)+(V12);
	goto L314;
	}
	}
	}
	}
}
/*	function definition for IMAGE-SWAP-FOUR-BYTES                 */
static L20(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT22 VLEX22 CLSR22
	{volatile int V10;
	volatile int V11;
	volatile int V12;
	V10= fix(V5);
	V11= fix(V6);
	V12= fix(V7);
TTL:
	{volatile object V13;                     /*  SRC             */
	V13= (V1);
	{volatile object V14;                     /*  DEST            */
	V14= (V2);
	{volatile int V15;                        /*  LENGTH          */
	volatile int V16;                         /*  H               */
	volatile int V17;                         /*  SRCSTART        */
	volatile int V18;                         /*  DESTSTART       */
	Lceiling(2,MAKE_FIXNUM(V10),MAKE_FIXNUM(4))/*  CEILING        */;
	V15= (fix(VALUES(0)))*(4);
	V16= fix((V8));
	V17= fix((V3));
	V18= fix((V4));
L359:
	if(!((V16)==0)){
	goto L360;}
	VALUES(0) = Cnil;
	RETURN(1);
L360:
	if(!((V16)==(1))){
	goto L363;}
	if((V10)==(V15)){
	goto L363;}
	V15= (V15)-(4);
	if(((V9))!=Cnil){
	goto L370;}
	((V14))->ust.ust_self[(V18)+(V15)]= ((V13))->ust.ust_self[((V17)+(V15))+(3)];
L370:
	if(((V9))==Cnil){
	goto L377;}
	if(!(((V10)-(V15))==(3))){
	goto L373;}
	goto L375;
L377:
	if(!((((((V10) & (2)))==0?Ct:Cnil))==Cnil)){
	goto L373;}
L375:
	((V14))->ust.ust_self[((V18)+(V15))+(1)]= ((V13))->ust.ust_self[((V17)+(V15))+(2)];
L373:
	if(((V9))!=Cnil){
	goto L383;}
	if(!(((V10)-(V15))==(3))){
	goto L379;}
	goto L381;
L383:
	if(!((((((V10) & (2)))==0?Ct:Cnil))==Cnil)){
	goto L379;}
L381:
	((V14))->ust.ust_self[((V18)+(V15))+(2)]= ((V13))->ust.ust_self[((V17)+(V15))+(1)];
L379:
	if(((V9))==Cnil){
	goto L363;}
	((V14))->ust.ust_self[((V18)+(V15))+(3)]= ((V13))->ust.ust_self[(V17)+(V15)];
L363:
	{volatile int V20;                        /*  I               */
	volatile int V21;                         /*  SRCIDX          */
	volatile int V22;                         /*  DESTIDX         */
	V20= V15;
	V21= V17;
	V22= V18;
L392:
	if(!((V20)==0)){
	goto L393;}
	goto L387;
L393:
	((V14))->ust.ust_self[V22]= ((V13))->ust.ust_self[(V21)+(3)];
	((V14))->ust.ust_self[(V22)+1]= ((V13))->ust.ust_self[(V21)+(2)];
	((V14))->ust.ust_self[(V22)+(2)]= ((V13))->ust.ust_self[(V21)+1];
	((V14))->ust.ust_self[(V22)+(3)]= ((V13))->ust.ust_self[V21];
	V20= (V20)-(4);
	V21= (V21)+(4);
	V22= (V22)+(4);
	goto L392;
	}
L387:
	V16= (V16)-1;
	V17= (V17)+(V11);
	V18= (V18)+(V12);
	goto L359;
	}
	}
	}
	}
}
/*	function definition for IMAGE-SWAP-WORDS                      */
static L21(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT23 VLEX23 CLSR23
	{volatile int V10;
	volatile int V11;
	volatile int V12;
	V10= fix(V5);
	V11= fix(V6);
	V12= fix(V7);
TTL:
	{volatile object V13;                     /*  SRC             */
	V13= (V1);
	{volatile object V14;                     /*  DEST            */
	V14= (V2);
	{volatile int V15;                        /*  LENGTH          */
	volatile int V16;                         /*  H               */
	volatile int V17;                         /*  SRCSTART        */
	volatile int V18;                         /*  DESTSTART       */
	Lceiling(2,MAKE_FIXNUM(V10),MAKE_FIXNUM(4))/*  CEILING        */;
	V15= (fix(VALUES(0)))*(4);
	V16= fix((V8));
	V17= fix((V3));
	V18= fix((V4));
L416:
	if(!((V16)==0)){
	goto L417;}
	VALUES(0) = Cnil;
	RETURN(1);
L417:
	if(!((V16)==(1))){
	goto L420;}
	if((V10)==(V15)){
	goto L420;}
	V15= (V15)-(4);
	if(((V9))!=Cnil){
	goto L427;}
	((V14))->ust.ust_self[((V18)+(V15))+(1)]= ((V13))->ust.ust_self[((V17)+(V15))+(3)];
L427:
	if(((V9))==Cnil){
	goto L434;}
	if(!(((V10)-(V15))==(3))){
	goto L430;}
	goto L432;
L434:
	if(!((((((V10) & (2)))==0?Ct:Cnil))==Cnil)){
	goto L430;}
L432:
	((V14))->ust.ust_self[(V18)+(V15)]= ((V13))->ust.ust_self[((V17)+(V15))+(2)];
L430:
	if(((V9))!=Cnil){
	goto L440;}
	if(!(((V10)-(V15))==(3))){
	goto L436;}
	goto L438;
L440:
	if(!((((((V10) & (2)))==0?Ct:Cnil))==Cnil)){
	goto L436;}
L438:
	((V14))->ust.ust_self[((V18)+(V15))+(3)]= ((V13))->ust.ust_self[((V17)+(V15))+(1)];
L436:
	if(((V9))==Cnil){
	goto L420;}
	((V14))->ust.ust_self[((V18)+(V15))+(2)]= ((V13))->ust.ust_self[(V17)+(V15)];
L420:
	{volatile int V20;                        /*  I               */
	volatile int V21;                         /*  SRCIDX          */
	volatile int V22;                         /*  DESTIDX         */
	V20= V15;
	V21= V17;
	V22= V18;
L449:
	if(!((V20)==0)){
	goto L450;}
	goto L444;
L450:
	((V14))->ust.ust_self[V22]= ((V13))->ust.ust_self[(V21)+(2)];
	((V14))->ust.ust_self[(V22)+1]= ((V13))->ust.ust_self[(V21)+(3)];
	((V14))->ust.ust_self[(V22)+(2)]= ((V13))->ust.ust_self[V21];
	((V14))->ust.ust_self[(V22)+(3)]= ((V13))->ust.ust_self[(V21)+1];
	V20= (V20)-(4);
	V21= (V21)+(4);
	V22= (V22)+(4);
	goto L449;
	}
L444:
	V16= (V16)-1;
	V17= (V17)+(V11);
	V18= (V18)+(V12);
	goto L416;
	}
	}
	}
	}
}
/*	function definition for IMAGE-SWAP-NIBBLES                    */
static L22(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT24 VLEX24 CLSR24
	{volatile int V10;
	volatile int V11;
	volatile int V12;
	V10= fix(V5);
	V11= fix(V6);
	V12= fix(V7);
TTL:
	{volatile object V13;                     /*  SRC             */
	V13= (V1);
	{volatile object V14;                     /*  DEST            */
	V14= (V2);
	{volatile int V15;                        /*  H               */
	volatile int V16;                         /*  SRCSTART        */
	volatile int V17;                         /*  DESTSTART       */
	V15= fix((V8));
	V16= fix((V3));
	V17= fix((V4));
L471:
	if(!((V15)==0)){
	goto L472;}
	VALUES(0) = Cnil;
	RETURN(1);
L472:
	{volatile int V19;                        /*  I               */
	volatile int V20;                         /*  SRCIDX          */
	volatile int V21;                         /*  DESTIDX         */
	V19= V10;
	V20= V16;
	V21= V17;
L480:
	if(!((V19)==0)){
	goto L481;}
	goto L475;
L481:
	{register int V23;                        /*  BYTE            */
	V23= fix(aref1((V13),V20));
	{int V24= ((((~(-1 << (4))) << (0)) & (V23)) >> (0));
	(*LK9)(2,MAKE_FIXNUM(4),MAKE_FIXNUM(4))   /*  BYTE            */;
	T0= VALUES(0);
	(*LK10)(3,MAKE_FIXNUM(V24),T0,MAKE_FIXNUM(((((~(-1 << (4))) << (4)) & (V23)) >> (4))))/*  DPB*/;}
	}
	((V14))->ust.ust_self[V21]= fix(VALUES(0));
	V19= (V19)-1;
	V20= (V20)+1;
	V21= (V21)+1;
	goto L480;
	}
L475:
	V15= (V15)-1;
	V16= (V16)+(V11);
	V17= (V17)+(V12);
	goto L471;
	}
	}
	}
	}
}
/*	function definition for IMAGE-SWAP-NIBBLES-LEFT               */
static L23(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT25 VLEX25 CLSR25
	{volatile int V10;
	volatile int V11;
	volatile int V12;
	V10= fix(V5);
	V11= fix(V6);
	V12= fix(V7);
TTL:
	{volatile object V13;                     /*  SRC             */
	V13= (V1);
	{volatile object V14;                     /*  DEST            */
	V14= (V2);
	{volatile int V15;                        /*  H               */
	volatile int V16;                         /*  SRCSTART        */
	volatile int V17;                         /*  DESTSTART       */
	V15= fix((V8));
	V16= fix((V3));
	V17= fix((V4));
L502:
	if(!((V15)==0)){
	goto L503;}
	VALUES(0) = Cnil;
	RETURN(1);
L503:
	{volatile int V19;                        /*  I               */
	volatile int V20;                         /*  SRCIDX          */
	volatile int V21;                         /*  DESTIDX         */
	V19= V10;
	V20= V16;
	V21= V17;
L511:
	if(!((V19)==(1))){
	goto L512;}
	{register int V23;                        /*  BYTE1           */
	V23= fix(aref1((V13),V20));
	{int V24= ((((~(-1 << (4))) << (0)) & (V23)) >> (0));
	(*LK9)(2,MAKE_FIXNUM(4),MAKE_FIXNUM(4))   /*  BYTE            */;
	(*LK10)(3,MAKE_FIXNUM(V24),VALUES(0),MAKE_FIXNUM(0))/*  DPB   */;}
	}
	((V14))->ust.ust_self[V21]= fix(VALUES(0));
	goto L506;
L512:
	{register int V23;                        /*  BYTE1           */
	register int V24;                         /*  BYTE2           */
	V23= fix(aref1((V13),V20));
	V24= fix(aref1((V13),(V20)+1));
	{int V25= ((((~(-1 << (4))) << (0)) & (V23)) >> (0));
	(*LK9)(2,MAKE_FIXNUM(4),MAKE_FIXNUM(4))   /*  BYTE            */;
	T0= VALUES(0);
	(*LK10)(3,MAKE_FIXNUM(V25),T0,MAKE_FIXNUM(((((~(-1 << (4))) << (4)) & (V24)) >> (4))))/*  DPB*/;}
	}
	((V14))->ust.ust_self[V21]= fix(VALUES(0));
	V19= (V19)-1;
	V20= (V20)+1;
	V21= (V21)+1;
	goto L511;
	}
L506:
	V15= (V15)-1;
	V16= (V16)+(V11);
	V17= (V17)+(V12);
	goto L502;
	}
	}
	}
	}
}
/*	function definition for IMAGE-SWAP-BITS                       */
static L24(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT26 VLEX26 CLSR26
	{volatile int V10;
	volatile int V11;
	volatile int V12;
	V10= fix(V5);
	V11= fix(V6);
	V12= fix(V7);
TTL:
	{volatile object V13;                     /*  SRC             */
	V13= (V1);
	{volatile object V14;                     /*  DEST            */
	V14= (V2);
	{volatile object V15;                     /*  BYTE-REVERSE    */
	{volatile object V16;                     /*  BYTE-REVERSE    */
	V16= VV[109];
	{volatile int V17;                        /*  H               */
	volatile int V18;                         /*  SRCSTART        */
	volatile int V19;                         /*  DESTSTART       */
	V17= fix((V8));
	V18= fix((V3));
	V19= fix((V4));
L537:
	if(!((V17)==0)){
	goto L538;}
	VALUES(0) = Cnil;
	RETURN(1);
L538:
	{volatile int V21;                        /*  I               */
	volatile int V22;                         /*  SRCIDX          */
	volatile int V23;                         /*  DESTIDX         */
	V21= V10;
	V22= V18;
	V23= V19;
L546:
	if(!((V21)==0)){
	goto L547;}
	goto L541;
L547:
	((V14))->ust.ust_self[V23]= ((V16))->ust.ust_self[((V13))->ust.ust_self[V22]];
	V21= (V21)-1;
	V22= (V22)+1;
	V23= (V23)+1;
	goto L546;
	}
L541:
	V17= (V17)-1;
	V18= (V18)+(V11);
	V19= (V19)+(V12);
	goto L537;
	}
	}
	}
	}
	}
	}
}
/*	function definition for IMAGE-SWAP-BITS-AND-TWO-BYTES         */
static L25(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT27 VLEX27 CLSR27
	{volatile int V10;
	volatile int V11;
	volatile int V12;
	V10= fix(V5);
	V11= fix(V6);
	V12= fix(V7);
TTL:
	{volatile object V13;                     /*  SRC             */
	V13= (V1);
	{volatile object V14;                     /*  DEST            */
	V14= (V2);
	{volatile object V15;                     /*  BYTE-REVERSE    */
	{volatile object V16;                     /*  BYTE-REVERSE    */
	V16= VV[109];
	{volatile int V17;                        /*  LENGTH          */
	volatile int V18;                         /*  H               */
	volatile int V19;                         /*  SRCSTART        */
	volatile int V20;                         /*  DESTSTART       */
	Lceiling(2,MAKE_FIXNUM(V10),MAKE_FIXNUM(2))/*  CEILING        */;
	V17= (fix(VALUES(0)))*(2);
	V18= fix((V8));
	V19= fix((V3));
	V20= fix((V4));
L567:
	if(!((V18)==0)){
	goto L568;}
	VALUES(0) = Cnil;
	RETURN(1);
L568:
	if(!((V18)==(1))){
	goto L571;}
	if((V10)==(V17)){
	goto L571;}
	V17= (V17)-(2);
	if(((V9))==Cnil){
	goto L579;}
	((V14))->ust.ust_self[((V20)+(V17))+1]= ((V16))->ust.ust_self[((V13))->ust.ust_self[(V19)+(V17)]];
	goto L571;
L579:
	((V14))->ust.ust_self[(V20)+(V17)]= ((V16))->ust.ust_self[((V13))->ust.ust_self[((V19)+(V17))+1]];
L571:
	{volatile int V22;                        /*  I               */
	volatile int V23;                         /*  SRCIDX          */
	volatile int V24;                         /*  DESTIDX         */
	V22= V17;
	V23= V19;
	V24= V20;
L586:
	if(!((V22)==0)){
	goto L587;}
	goto L581;
L587:
	((V14))->ust.ust_self[V24]= ((V16))->ust.ust_self[((V13))->ust.ust_self[(V23)+1]];
	((V14))->ust.ust_self[(V24)+1]= ((V16))->ust.ust_self[((V13))->ust.ust_self[V23]];
	V22= (V22)-(2);
	V23= (V23)+(2);
	V24= (V24)+(2);
	goto L586;
	}
L581:
	V18= (V18)-1;
	V19= (V19)+(V11);
	V20= (V20)+(V12);
	goto L567;
	}
	}
	}
	}
	}
	}
}
/*	function definition for IMAGE-SWAP-BITS-AND-FOUR-BYTES        */
static L26(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT28 VLEX28 CLSR28
	{volatile int V10;
	volatile int V11;
	volatile int V12;
	V10= fix(V5);
	V11= fix(V6);
	V12= fix(V7);
TTL:
	{volatile object V13;                     /*  SRC             */
	V13= (V1);
	{volatile object V14;                     /*  DEST            */
	V14= (V2);
	{volatile object V15;                     /*  BYTE-REVERSE    */
	{volatile object V16;                     /*  BYTE-REVERSE    */
	V16= VV[109];
	{volatile int V17;                        /*  LENGTH          */
	volatile int V18;                         /*  H               */
	volatile int V19;                         /*  SRCSTART        */
	volatile int V20;                         /*  DESTSTART       */
	Lceiling(2,MAKE_FIXNUM(V10),MAKE_FIXNUM(4))/*  CEILING        */;
	V17= (fix(VALUES(0)))*(4);
	V18= fix((V8));
	V19= fix((V3));
	V20= fix((V4));
L608:
	if(!((V18)==0)){
	goto L609;}
	VALUES(0) = Cnil;
	RETURN(1);
L609:
	if(!((V18)==(1))){
	goto L612;}
	if((V10)==(V17)){
	goto L612;}
	V17= (V17)-(4);
	if(((V9))!=Cnil){
	goto L619;}
	((V14))->ust.ust_self[(V20)+(V17)]= ((V16))->ust.ust_self[((V13))->ust.ust_self[((V19)+(V17))+(3)]];
L619:
	if(((V9))==Cnil){
	goto L626;}
	if(!(((V10)-(V17))==(3))){
	goto L622;}
	goto L624;
L626:
	if(!((((((V10) & (2)))==0?Ct:Cnil))==Cnil)){
	goto L622;}
L624:
	((V14))->ust.ust_self[((V20)+(V17))+(1)]= ((V16))->ust.ust_self[((V13))->ust.ust_self[((V19)+(V17))+(2)]];
L622:
	if(((V9))!=Cnil){
	goto L632;}
	if(!(((V10)-(V17))==(3))){
	goto L628;}
	goto L630;
L632:
	if(!((((((V10) & (2)))==0?Ct:Cnil))==Cnil)){
	goto L628;}
L630:
	((V14))->ust.ust_self[((V20)+(V17))+(2)]= ((V16))->ust.ust_self[((V13))->ust.ust_self[((V19)+(V17))+(1)]];
L628:
	if(((V9))==Cnil){
	goto L612;}
	((V14))->ust.ust_self[((V20)+(V17))+(3)]= ((V16))->ust.ust_self[((V13))->ust.ust_self[(V19)+(V17)]];
L612:
	{volatile int V22;                        /*  I               */
	volatile int V23;                         /*  SRCIDX          */
	volatile int V24;                         /*  DESTIDX         */
	V22= V17;
	V23= V19;
	V24= V20;
L641:
	if(!((V22)==0)){
	goto L642;}
	goto L636;
L642:
	((V14))->ust.ust_self[V24]= ((V16))->ust.ust_self[((V13))->ust.ust_self[(V23)+(3)]];
	((V14))->ust.ust_self[(V24)+1]= ((V16))->ust.ust_self[((V13))->ust.ust_self[(V23)+(2)]];
	((V14))->ust.ust_self[(V24)+(2)]= ((V16))->ust.ust_self[((V13))->ust.ust_self[(V23)+1]];
	((V14))->ust.ust_self[(V24)+(3)]= ((V16))->ust.ust_self[((V13))->ust.ust_self[V23]];
	V22= (V22)-(4);
	V23= (V23)+(4);
	V24= (V24)+(4);
	goto L641;
	}
L636:
	V18= (V18)-1;
	V19= (V19)+(V11);
	V20= (V20)+(V12);
	goto L608;
	}
	}
	}
	}
	}
	}
}
/*	function definition for IMAGE-SWAP-BITS-AND-WORDS             */
static L27(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT29 VLEX29 CLSR29
	{volatile int V10;
	volatile int V11;
	volatile int V12;
	V10= fix(V5);
	V11= fix(V6);
	V12= fix(V7);
TTL:
	{volatile object V13;                     /*  SRC             */
	V13= (V1);
	{volatile object V14;                     /*  DEST            */
	V14= (V2);
	{volatile object V15;                     /*  BYTE-REVERSE    */
	{volatile object V16;                     /*  BYTE-REVERSE    */
	V16= VV[109];
	{volatile int V17;                        /*  LENGTH          */
	volatile int V18;                         /*  H               */
	volatile int V19;                         /*  SRCSTART        */
	volatile int V20;                         /*  DESTSTART       */
	Lceiling(2,MAKE_FIXNUM(V10),MAKE_FIXNUM(4))/*  CEILING        */;
	V17= (fix(VALUES(0)))*(4);
	V18= fix((V8));
	V19= fix((V3));
	V20= fix((V4));
L665:
	if(!((V18)==0)){
	goto L666;}
	VALUES(0) = Cnil;
	RETURN(1);
L666:
	if(!((V18)==(1))){
	goto L669;}
	if((V10)==(V17)){
	goto L669;}
	V17= (V17)-(4);
	if(((V9))!=Cnil){
	goto L676;}
	((V14))->ust.ust_self[((V20)+(V17))+(1)]= ((V16))->ust.ust_self[((V13))->ust.ust_self[((V19)+(V17))+(3)]];
L676:
	if(((V9))==Cnil){
	goto L683;}
	if(!(((V10)-(V17))==(3))){
	goto L679;}
	goto L681;
L683:
	if(!((((((V10) & (2)))==0?Ct:Cnil))==Cnil)){
	goto L679;}
L681:
	((V14))->ust.ust_self[(V20)+(V17)]= ((V16))->ust.ust_self[((V13))->ust.ust_self[((V19)+(V17))+(2)]];
L679:
	if(((V9))!=Cnil){
	goto L689;}
	if(!(((V10)-(V17))==(3))){
	goto L685;}
	goto L687;
L689:
	if(!((((((V10) & (2)))==0?Ct:Cnil))==Cnil)){
	goto L685;}
L687:
	((V14))->ust.ust_self[((V20)+(V17))+(3)]= ((V16))->ust.ust_self[((V13))->ust.ust_self[((V19)+(V17))+(1)]];
L685:
	if(((V9))==Cnil){
	goto L669;}
	((V14))->ust.ust_self[((V20)+(V17))+(2)]= ((V16))->ust.ust_self[((V13))->ust.ust_self[(V19)+(V17)]];
L669:
	{volatile int V22;                        /*  I               */
	volatile int V23;                         /*  SRCIDX          */
	volatile int V24;                         /*  DESTIDX         */
	V22= V17;
	V23= V19;
	V24= V20;
L698:
	if(!((V22)==0)){
	goto L699;}
	goto L693;
L699:
	((V14))->ust.ust_self[V24]= ((V16))->ust.ust_self[((V13))->ust.ust_self[(V23)+(2)]];
	((V14))->ust.ust_self[(V24)+1]= ((V16))->ust.ust_self[((V13))->ust.ust_self[(V23)+(3)]];
	((V14))->ust.ust_self[(V24)+(2)]= ((V16))->ust.ust_self[((V13))->ust.ust_self[V23]];
	((V14))->ust.ust_self[(V24)+(3)]= ((V16))->ust.ust_self[((V13))->ust.ust_self[(V23)+1]];
	V22= (V22)-(4);
	V23= (V23)+(4);
	V24= (V24)+(4);
	goto L698;
	}
L693:
	V18= (V18)-1;
	V19= (V19)+(V11);
	V20= (V20)+(V12);
	goto L665;
	}
	}
	}
	}
	}
	}
}
/*	function definition for IMAGE-SWAP-FUNCTION                   */
static L28(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7)
{ VT30 VLEX30 CLSR30
	{int V8;
	V8= fix(V1);
TTL:
	if(!((V8)==(1))){
	goto L717;}
	{int V9;                                  /*  FROM-INDEX      */
	if(!eql((V2),VV[114]))goto L721;
	T0= MAKE_FIXNUM(2);
	goto L720;
L721:
	if(!eql((V2),VV[115]))goto L722;
	T0= MAKE_FIXNUM(1);
	goto L720;
L722:
	if(!eql((V2),VV[116]))goto L723;
	T0= MAKE_FIXNUM(0);
	goto L720;
L723:
	FEerror("The ECASE key value ~s is illegal.",1,(V2));
L720:
	if(((V4))==Cnil){
	goto L726;}
	VALUES(0) = MAKE_FIXNUM(3);
	goto L724;
L726:
	VALUES(0) = MAKE_FIXNUM(0);
L724:
	{int V10= (fix(T0))+(fix(VALUES(0)));
	if(((V3))==Cnil){
	goto L730;}
	VALUES(0) = MAKE_FIXNUM(6);
	goto L728;
L730:
	VALUES(0) = MAKE_FIXNUM(0);
L728:
	V9= (V10)+(fix(VALUES(0)));}
	if(!eql((V5),VV[114]))goto L733;
	T0= MAKE_FIXNUM(2);
	goto L732;
L733:
	if(!eql((V5),VV[115]))goto L734;
	T0= MAKE_FIXNUM(1);
	goto L732;
L734:
	if(!eql((V5),VV[116]))goto L735;
	T0= MAKE_FIXNUM(0);
	goto L732;
L735:
	FEerror("The ECASE key value ~s is illegal.",1,(V5));
L732:
	if(((V7))==Cnil){
	goto L738;}
	VALUES(0) = MAKE_FIXNUM(3);
	goto L736;
L738:
	VALUES(0) = MAKE_FIXNUM(0);
L736:
	{int V10= (fix(T0))+(fix(VALUES(0)));
	if(((V6))==Cnil){
	goto L742;}
	VALUES(0) = MAKE_FIXNUM(6);
	goto L740;
L742:
	VALUES(0) = MAKE_FIXNUM(0);
L740:
	VALUES(1) = (VV[118])->v.v_self[V9];
	VALUES(0) = (VV[117])->a.a_self[V9*(VV[117])->a.a_dims[1]+(V10)+(fix(VALUES(0)))];
	RETURN(2);}
	}
L717:
	if(!((V8)==(4))){
	goto L749;}
	if(!(((V4))==((V7)))){
	goto L746;}
	goto L747;
L749:
	if(!(((V3))==((V6)))){
	goto L746;}
L747:
	VALUES(0) = VV[119];
	goto L744;
L746:
	if(!eql(MAKE_FIXNUM(V8),VV[120]))goto L751;
	VALUES(0) = VV[121];
	goto L744;
L751:
	if(!eql(MAKE_FIXNUM(V8),VV[116]))goto L752;
	VALUES(0) = VV[119];
	goto L744;
L752:
	if(!eql(MAKE_FIXNUM(V8),VV[115]))goto L753;
	VALUES(0) = VV[122];
	goto L744;
L753:
	if(!eql(MAKE_FIXNUM(V8),VV[123]))goto L754;
	VALUES(0) = VV[124];
	goto L744;
L754:
	if(!eql(MAKE_FIXNUM(V8),VV[114]))goto L755;
	VALUES(0) = VV[125];
	goto L744;
L755:
	FEerror("The ECASE key value ~s is illegal.",1,MAKE_FIXNUM(V8));
L744:
	VALUES(1) = (V3);
	VALUES(0) = VALUES(0);
	RETURN(2);
	}
}
/*	function definition for READ-PIXARRAY-1                       */
static L29(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT31 VLEX31 CLSR31
	{volatile int V10;
	volatile int V11;
	volatile int V12;
	volatile int V13;
	V10= fix(V4);
	V11= fix(V6);
	V12= fix(V7);
	V13= fix(V8);
TTL:
	{volatile object V14;                     /*  BUFFER-BBUF     */
	V14= (V1);
	{volatile int V15;                        /*  START           */
	volatile int V16;                         /*  Y               */
	volatile int V17;                         /*  LEFT-BITS       */
	volatile int V18;                         /*  RIGHT-BITS      */
	volatile int V19;                         /*  MIDDLE-BITS     */
	volatile int V20;                         /*  MIDDLE-BYTES    */
	{int V21= (fix((V2)))+((fix((V5)))*(V13));
	Lceiling(2,MAKE_FIXNUM(V10),MAKE_FIXNUM(8))/*  CEILING        */;
	V15= (V21)+(fix(VALUES(0)));}
	V16= 0;
	{int V21= -(V10);
	V17= (V21>=0&&8>0?(V21)%(8):imod(V21,8));}
	{int V21= (V11)-(V17);
	V18= (V21>=0&&8>0?(V21)%(8):imod(V21,8));}
	V19= ((V11)-(V17))-(V18);
	V20= (V19>=0&&8>0?(V19)/(8):ifloor(V19,8));
L764:
	if(!((V16)>=(V12))){
	goto L765;}
	VALUES(0) = Cnil;
	RETURN(1);
L765:
	if(!((V19)<(0))){
	goto L770;}
	{int V22;                                 /*  BYTE            */
	int V23;                                  /*  X               */
	V22= fix(aref1((V14),(V15)-1));
	V23= V17;
	if(!((V18)>(6))){
	goto L774;}
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(0),MAKE_FIXNUM(V22))/*  LDB1*/;
	T0= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V23)-(1)]= T0;
L774:
	if(!((V17)>(1))){
	goto L778;}
	if(!((V18)>(5))){
	goto L778;}
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(1),MAKE_FIXNUM(V22))/*  LDB1*/;
	T0= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V23)-(2)]= T0;
L778:
	if(!((V17)>(2))){
	goto L784;}
	if(!((V18)>(4))){
	goto L784;}
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(2),MAKE_FIXNUM(V22))/*  LDB1*/;
	T0= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V23)-(3)]= T0;
L784:
	if(!((V17)>(3))){
	goto L790;}
	if(!((V18)>(3))){
	goto L790;}
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(3),MAKE_FIXNUM(V22))/*  LDB1*/;
	T0= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V23)-(4)]= T0;
L790:
	if(!((V17)>(4))){
	goto L796;}
	if(!((V18)>(2))){
	goto L796;}
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(4),MAKE_FIXNUM(V22))/*  LDB1*/;
	T0= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V23)-(5)]= T0;
L796:
	if(!((V17)>(5))){
	goto L802;}
	if(!((V18)>(1))){
	goto L802;}
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(5),MAKE_FIXNUM(V22))/*  LDB1*/;
	T0= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V23)-(6)]= T0;
L802:
	if(!((V17)>(6))){
	goto L768;}
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(6),MAKE_FIXNUM(V22))/*  LDB1*/;
	T0= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V23)-(7)]= T0;
	goto L768;
	}
L770:
	if((V17)==0){
	goto L811;}
	{int V24;                                 /*  BYTE            */
	int V25;                                  /*  X               */
	V24= fix(aref1((V14),(V15)-1));
	V25= V17;
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(0),MAKE_FIXNUM(V24))/*  LDB1*/;
	T0= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V25)-(1)]= T0;
	if(!((V17)>(1))){
	goto L811;}
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(1),MAKE_FIXNUM(V24))/*  LDB1*/;
	T0= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V25)-(2)]= T0;
	if(!((V17)>(2))){
	goto L811;}
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(2),MAKE_FIXNUM(V24))/*  LDB1*/;
	T0= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V25)-(3)]= T0;
	if(!((V17)>(3))){
	goto L811;}
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(3),MAKE_FIXNUM(V24))/*  LDB1*/;
	T0= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V25)-(4)]= T0;
	if(!((V17)>(4))){
	goto L811;}
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(4),MAKE_FIXNUM(V24))/*  LDB1*/;
	T0= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V25)-(5)]= T0;
	if(!((V17)>(5))){
	goto L811;}
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(5),MAKE_FIXNUM(V24))/*  LDB1*/;
	T0= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V25)-(6)]= T0;
	if(!((V17)>(6))){
	goto L811;}
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(6),MAKE_FIXNUM(V24))/*  LDB1*/;
	T0= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V25)-(7)]= T0;
	}
L811:
	{volatile int V24;                        /*  END             */
	volatile int V25;                         /*  I               */
	volatile int V26;                         /*  X               */
	V24= (V15)+(V20);
	V25= V15;
	V26= V17;
L845:
	if(!((V25)>=(V24))){
	goto L846;}
	if((V18)==0){
	goto L768;}
	{register int V28;                        /*  BYTE            */
	register int V29;                         /*  X               */
	V28= fix(aref1((V14),V24));
	V29= (V17)+(V19);
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(7),MAKE_FIXNUM(V28))/*  LDB1*/;
	T0= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V29)+(0)]= T0;
	if(!((V18)>(1))){
	goto L768;}
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(6),MAKE_FIXNUM(V28))/*  LDB1*/;
	T0= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V29)+(1)]= T0;
	if(!((V18)>(2))){
	goto L768;}
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(5),MAKE_FIXNUM(V28))/*  LDB1*/;
	T0= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V29)+(2)]= T0;
	if(!((V18)>(3))){
	goto L768;}
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(4),MAKE_FIXNUM(V28))/*  LDB1*/;
	T0= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V29)+(3)]= T0;
	if(!((V18)>(4))){
	goto L768;}
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(3),MAKE_FIXNUM(V28))/*  LDB1*/;
	T0= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V29)+(4)]= T0;
	if(!((V18)>(5))){
	goto L768;}
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(2),MAKE_FIXNUM(V28))/*  LDB1*/;
	T0= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V29)+(5)]= T0;
	if(!((V18)>(6))){
	goto L768;}
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(1),MAKE_FIXNUM(V28))/*  LDB1*/;
	T0= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V29)+(6)]= T0;
	goto L768;
	}
L846:
	{register int V30;                        /*  BYTE            */
	V30= fix(aref1((V14),V25));
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(7),MAKE_FIXNUM(V30))/*  LDB1*/;
	T1= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V26)+(0)]= T1;
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(6),MAKE_FIXNUM(V30))/*  LDB1*/;
	T1= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V26)+(1)]= T1;
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(5),MAKE_FIXNUM(V30))/*  LDB1*/;
	T1= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V26)+(2)]= T1;
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(4),MAKE_FIXNUM(V30))/*  LDB1*/;
	T1= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V26)+(3)]= T1;
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(3),MAKE_FIXNUM(V30))/*  LDB1*/;
	T1= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V26)+(4)]= T1;
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(2),MAKE_FIXNUM(V30))/*  LDB1*/;
	T1= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V26)+(5)]= T1;
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(1),MAKE_FIXNUM(V30))/*  LDB1*/;
	T1= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V26)+(6)]= T1;
	(*LK11)(3,MAKE_FIXNUM(1),MAKE_FIXNUM(0),MAKE_FIXNUM(V30))/*  LDB1*/;
	T1= VALUES(0);
	((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V26)+(7)]= T1;
	}
	V25= (V25)+1;
	V26= (V26)+(8);
	goto L845;
	}
L768:
	V15= (V15)+(V13);
	V16= (V16)+1;
	goto L764;
	}
	}
	}
}
/*	function definition for READ-PIXARRAY-4                       */
static L30(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT32 VLEX32 CLSR32
	{volatile int V10;
	volatile int V11;
	volatile int V12;
	volatile int V13;
	V10= fix(V4);
	V11= fix(V6);
	V12= fix(V7);
	V13= fix(V8);
TTL:
	{volatile object V14;                     /*  BUFFER-BBUF     */
	V14= (V1);
	{volatile int V15;                        /*  START           */
	volatile int V16;                         /*  Y               */
	volatile int V17;                         /*  LEFT-NIBBLES    */
	volatile int V18;                         /*  RIGHT-NIBBLES   */
	volatile int V19;                         /*  MIDDLE-NIBBLES  */
	volatile int V20;                         /*  MIDDLE-BYTES    */
	{int V21= (fix((V2)))+((fix((V5)))*(V13));
	Lceiling(2,MAKE_FIXNUM(V10),MAKE_FIXNUM(2))/*  CEILING        */;
	V15= (V21)+(fix(VALUES(0)));}
	V16= 0;
	{int V21= -(V10);
	V17= (V21>=0&&2>0?(V21)%(2):imod(V21,2));}
	{int V21= (V11)-(V17);
	V18= (V21>=0&&2>0?(V21)%(2):imod(V21,2));}
	V19= ((V11)-(V17))-(V18);
	V20= (V19>=0&&2>0?(V19)/(2):ifloor(V19,2));
L913:
	if(!((V16)>=(V12))){
	goto L914;}
	VALUES(0) = Cnil;
	RETURN(1);
L914:
	if((V17)==0){
	goto L917;}
	((V3))->fixa.fixa_self[V16*((V3))->a.a_dims[1]+0]= ((((~(-1 << (4))) << (3)) & (((V14))->ust.ust_self[(V15)-1])) >> (3));
L917:
	{volatile int V22;                        /*  END             */
	volatile int V23;                         /*  I               */
	volatile int V24;                         /*  X               */
	V22= (V15)+(V20);
	V23= V15;
	V24= V17;
L925:
	if(!((V23)>=(V22))){
	goto L926;}
	if((V18)==0){
	goto L920;}
	((V3))->fixa.fixa_self[V16*((V3))->a.a_dims[1]+(V17)+(V19)]= ((((~(-1 << (4))) << (7)) & (((V14))->ust.ust_self[V22])) >> (7));
	goto L920;
L926:
	{register int V26;                        /*  BYTE            */
	V26= fix(aref1((V14),V23));
	((V3))->fixa.fixa_self[V16*((V3))->a.a_dims[1]+(V24)+(0)]= ((((~(-1 << (4))) << (7)) & (V26)) >> (7));
	((V3))->fixa.fixa_self[V16*((V3))->a.a_dims[1]+(V24)+(1)]= ((((~(-1 << (4))) << (3)) & (V26)) >> (3));
	}
	V23= (V23)+1;
	V24= (V24)+(2);
	goto L925;
	}
L920:
	V15= (V15)+(V13);
	V16= (V16)+1;
	goto L913;
	}
	}
	}
}
/*	function definition for READ-PIXARRAY-8                       */
static L31(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT33 VLEX33 CLSR33
	{volatile int V10;
	volatile int V11;
	volatile int V12;
	V10= fix(V6);
	V11= fix(V7);
	V12= fix(V8);
TTL:
	{volatile object V13;                     /*  BUFFER-BBUF     */
	V13= (V1);
	{volatile int V14;                        /*  START           */
	volatile int V15;                         /*  Y               */
	V14= ((fix((V2)))+((fix((V5)))*(V12)))+(fix((V4)));
	V15= 0;
L947:
	if(!((V15)>=(V11))){
	goto L948;}
	VALUES(0) = Cnil;
	RETURN(1);
L948:
	{volatile int V17;                        /*  END             */
	volatile int V18;                         /*  I               */
	volatile int V19;                         /*  X               */
	V17= (V14)+(V10);
	V18= V14;
	V19= 0;
L956:
	if(!((V18)>=(V17))){
	goto L957;}
	goto L951;
L957:
	Lint_char(1,MAKE_FIXNUM(((V13))->ust.ust_self[V18]))/*  INT-CHAR*/;
	((V3))->a.a_self[V15*((V3))->a.a_dims[1]+V19]= VALUES(0);
	V18= (V18)+1;
	V19= (V19)+1;
	goto L956;
	}
L951:
	V14= (V14)+(V12);
	V15= (V15)+1;
	goto L947;
	}
	}
	}
}
/*	function definition for READ-PIXARRAY-16                      */
static L32(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT34 VLEX34 CLSR34
	{volatile int V10;
	volatile int V11;
	volatile int V12;
	V10= fix(V6);
	V11= fix(V7);
	V12= fix(V8);
TTL:
	{volatile object V13;                     /*  BUFFER-BBUF     */
	V13= (V1);
	{volatile int V14;                        /*  START           */
	volatile int V15;                         /*  Y               */
	V14= ((fix((V2)))+((fix((V5)))*(V12)))+((fix((V4)))*(2));
	V15= 0;
L975:
	if(!((V15)>=(V11))){
	goto L976;}
	VALUES(0) = Cnil;
	RETURN(1);
L976:
	{volatile int V17;                        /*  END             */
	volatile int V18;                         /*  I               */
	volatile int V19;                         /*  X               */
	V17= (V14)+((V10)*(2));
	V18= V14;
	V19= 0;
L984:
	if(!((V18)>=(V17))){
	goto L985;}
	goto L979;
L985:
	{register object V21;
	register object V22;
	register object V23;
	V21= (V3);
	V22= MAKE_FIXNUM(V15);
	V23= MAKE_FIXNUM(V19);
	{int V24= ((V13))->ust.ust_self[(V18)+(0)];
	(*LK9)(2,MAKE_FIXNUM(8),MAKE_FIXNUM(8))   /*  BYTE            */;
	T0= VALUES(0);
	(*LK10)(3,MAKE_FIXNUM(V24),T0,MAKE_FIXNUM(((V13))->ust.ust_self[(V18)+(1)]))/*  DPB*/;
	((V21))->fixa.fixa_self[fix((V22))*((V21))->a.a_dims[1]+fix((V23))]= fix(VALUES(0));}
	}
	V18= (V18)+(2);
	V19= (V19)+1;
	goto L984;
	}
L979:
	V14= (V14)+(V12);
	V15= (V15)+1;
	goto L975;
	}
	}
	}
}
/*	function definition for READ-PIXARRAY-24                      */
static L33(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT35 VLEX35 CLSR35
	{volatile int V10;
	volatile int V11;
	volatile int V12;
	V10= fix(V6);
	V11= fix(V7);
	V12= fix(V8);
TTL:
	{volatile object V13;                     /*  BUFFER-BBUF     */
	V13= (V1);
	{volatile int V14;                        /*  START           */
	volatile int V15;                         /*  Y               */
	V14= ((fix((V2)))+((fix((V5)))*(V12)))+((fix((V4)))*(3));
	V15= 0;
L1007:
	if(!((V15)>=(V11))){
	goto L1008;}
	VALUES(0) = Cnil;
	RETURN(1);
L1008:
	{volatile int V17;                        /*  END             */
	volatile int V18;                         /*  I               */
	volatile int V19;                         /*  X               */
	V17= (V14)+((V10)*(3));
	V18= V14;
	V19= 0;
L1016:
	if(!((V18)>=(V17))){
	goto L1017;}
	goto L1011;
L1017:
	{register object V21;
	register object V22;
	register object V23;
	V21= (V3);
	V22= MAKE_FIXNUM(V15);
	V23= MAKE_FIXNUM(V19);
	{int V24= ((V13))->ust.ust_self[(V18)+(0)];
	(*LK9)(2,MAKE_FIXNUM(8),MAKE_FIXNUM(16))  /*  BYTE            */;
	T0= VALUES(0);
	{int V25= ((V13))->ust.ust_self[(V18)+(1)];
	(*LK9)(2,MAKE_FIXNUM(8),MAKE_FIXNUM(8))   /*  BYTE            */;
	T1= VALUES(0);
	(*LK10)(3,MAKE_FIXNUM(V25),T1,MAKE_FIXNUM(((V13))->ust.ust_self[(V18)+(2)]))/*  DPB*/;
	(*LK10)(3,MAKE_FIXNUM(V24),T0,VALUES(0))  /*  DPB             */;
	((V21))->fixa.fixa_self[fix((V22))*((V21))->a.a_dims[1]+fix((V23))]= fix(VALUES(0));}}
	}
	V18= (V18)+(3);
	V19= (V19)+1;
	goto L1016;
	}
L1011:
	V14= (V14)+(V12);
	V15= (V15)+1;
	goto L1007;
	}
	}
	}
}
/*	function definition for READ-PIXARRAY-32                      */
static L34(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT36 VLEX36 CLSR36
	{volatile int V10;
	volatile int V11;
	volatile int V12;
	V10= fix(V6);
	V11= fix(V7);
	V12= fix(V8);
TTL:
	{volatile object V13;                     /*  BUFFER-BBUF     */
	V13= (V1);
	{volatile int V14;                        /*  START           */
	volatile int V15;                         /*  Y               */
	V14= ((fix((V2)))+((fix((V5)))*(V12)))+((fix((V4)))*(4));
	V15= 0;
L1041:
	if(!((V15)>=(V11))){
	goto L1042;}
	VALUES(0) = Cnil;
	RETURN(1);
L1042:
	{volatile int V17;                        /*  END             */
	volatile int V18;                         /*  I               */
	volatile int V19;                         /*  X               */
	V17= (V14)+((V10)*(4));
	V18= V14;
	V19= 0;
L1050:
	if(!((V18)>=(V17))){
	goto L1051;}
	goto L1045;
L1051:
	{register object V21;
	register object V22;
	register object V23;
	V21= (V3);
	V22= MAKE_FIXNUM(V15);
	V23= MAKE_FIXNUM(V19);
	{int V24= ((V13))->ust.ust_self[(V18)+(0)];
	(*LK9)(2,MAKE_FIXNUM(8),MAKE_FIXNUM(24))  /*  BYTE            */;
	T0= VALUES(0);
	{int V25= ((V13))->ust.ust_self[(V18)+(1)];
	(*LK9)(2,MAKE_FIXNUM(8),MAKE_FIXNUM(16))  /*  BYTE            */;
	T1= VALUES(0);
	{int V26= ((V13))->ust.ust_self[(V18)+(2)];
	(*LK9)(2,MAKE_FIXNUM(8),MAKE_FIXNUM(8))   /*  BYTE            */;
	T2= VALUES(0);
	(*LK10)(3,MAKE_FIXNUM(V26),T2,MAKE_FIXNUM(((V13))->ust.ust_self[(V18)+(3)]))/*  DPB*/;
	(*LK10)(3,MAKE_FIXNUM(V25),T1,VALUES(0))  /*  DPB             */;
	(*LK10)(3,MAKE_FIXNUM(V24),T0,VALUES(0))  /*  DPB             */;
	((V21))->a.a_self[fix((V22))*((V21))->a.a_dims[1]+fix((V23))]= VALUES(0);}}}
	}
	V18= (V18)+(4);
	V19= (V19)+1;
	goto L1050;
	}
L1045:
	V14= (V14)+(V12);
	V15= (V15)+1;
	goto L1041;
	}
	}
	}
}
/*	function definition for READ-PIXARRAY-INTERNAL                */
static L35(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9, object V10, object V11, object V12, object V13, object V14, object V15, object V16)
{ VT37 VLEX37 CLSR37
	{volatile int V17;
	volatile int V18;
	volatile int V19;
	volatile int V20;
	volatile int V21;
	volatile int V22;
	volatile int V23;
	V17= fix(V2);
	V18= fix(V4);
	V19= fix(V5);
	V20= fix(V6);
	V21= fix(V7);
	V22= fix(V8);
	V23= fix(V9);
TTL:
	{ int V24;
	volatile object V25;                      /*  IMAGE-SWAP-FUNCTION*/
	volatile object V26;                      /*  IMAGE-SWAP-LSB-FIRST-P*/
	V24=L28(7,MAKE_FIXNUM(V23),(V11),(V12),(V13),(V14),(V15),(V16))/*  IMAGE-SWAP-FUNCTION*/;
	if (V24--==0) goto L1075;
	V25= VALUES(0);
	if (V24--==0) goto L1076;
	V26= VALUES(1);
	goto L1077;
L1075:
	V25= Cnil;
L1076:
	V26= Cnil;
L1077:
	if(!(((V25))==(VV[119]))){
	goto L1079;}
	RETURN(funcall(10,(V10),(V1),MAKE_FIXNUM(V17),(V3),MAKE_FIXNUM(V18),MAKE_FIXNUM(V19),MAKE_FIXNUM(V20),MAKE_FIXNUM(V21),MAKE_FIXNUM(V22),MAKE_FIXNUM(V23)));
L1079:
	{volatile object V27;                     /*  .REPLY-BUFFER.  */
	(*LK12)(1,MAKE_FIXNUM((V21)*(V22)))       /*  ALLOCATE-REPLY-BUFFER*/;
	V27= VALUES(0);
	{ int V28; volatile bool unwinding = FALSE;
	if ((V28=frs_push(FRS_PROTECT,Cnil))) {
	V28--; unwinding = TRUE;} else {
	{object V29;                              /*  BUF             */
	V29= ((V27))->in.in_slots[1];
	{object V30;                              /*  BUF             */
	T0= symbol_function((V25));
	{int V31= (V17)+((V19)*(V22));
	Lceiling(2,MAKE_FIXNUM(((V18)+(V20))*(V23)),MAKE_FIXNUM(8))/*  CEILING*/;
	funcall(10,T0,(V1),(V29),MAKE_FIXNUM(V31),MAKE_FIXNUM(0),VALUES(0),MAKE_FIXNUM(V22),MAKE_FIXNUM(V22),MAKE_FIXNUM(V21),(V26));}
	V28=funcall(10,(V10),(V29),MAKE_FIXNUM(0),(V3),MAKE_FIXNUM(V18),MAKE_FIXNUM(0),MAKE_FIXNUM(V20),MAKE_FIXNUM(V21),MAKE_FIXNUM(V22),MAKE_FIXNUM(V23));
	}
	}
	}
	frs_pop();
	MV_SAVE(V28);
	(*LK13)(1,(V27))                          /*  DEALLOCATE-REPLY-BUFFER*/;
	MV_RESTORE(V28);
	if (unwinding) unwind(nlj_fr,nlj_tag,V28+1);
	else {
	RETURN(V28);}}
	}}
	}
}
/*	function definition for READ-PIXARRAY                         */
static L36(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9, object V10, object V11, object V12)
{ VT38 VLEX38 CLSR38
	{int V13;
	int V14;
	int V15;
	int V16;
	int V17;
	int V18;
	int V19;
	int V20;
	V13= fix(V2);
	V14= fix(V4);
	V15= fix(V5);
	V16= fix(V6);
	V17= fix(V7);
	V18= fix(V8);
	V19= fix(V9);
	V20= fix(V10);
TTL:
	(*LK14)(12,(V1),MAKE_FIXNUM(V13),(V3),MAKE_FIXNUM(V14),MAKE_FIXNUM(V15),MAKE_FIXNUM(V16),MAKE_FIXNUM(V17),MAKE_FIXNUM(V18),MAKE_FIXNUM(V19),MAKE_FIXNUM(V20),(V11),(V12))/*  FAST-READ-PIXARRAY*/;
	if(VALUES(0)!=Cnil){
	goto L1089;}
	if(!eql(MAKE_FIXNUM(V19),VV[11]))goto L1092;
	VALUES(0) = (VV[246]->s.s_gfdef);
	goto L1091;
L1092:
	if(!eql(MAKE_FIXNUM(V19),VV[120]))goto L1093;
	VALUES(0) = (VV[247]->s.s_gfdef);
	goto L1091;
L1093:
	if(!eql(MAKE_FIXNUM(V19),VV[116]))goto L1094;
	VALUES(0) = (VV[248]->s.s_gfdef);
	goto L1091;
L1094:
	if(!eql(MAKE_FIXNUM(V19),VV[115]))goto L1095;
	VALUES(0) = (VV[249]->s.s_gfdef);
	goto L1091;
L1095:
	if(!eql(MAKE_FIXNUM(V19),VV[123]))goto L1096;
	VALUES(0) = (VV[250]->s.s_gfdef);
	goto L1091;
L1096:
	if(!eql(MAKE_FIXNUM(V19),VV[114]))goto L1097;
	VALUES(0) = (VV[251]->s.s_gfdef);
	goto L1091;
L1097:
	FEerror("The ECASE key value ~s is illegal.",1,MAKE_FIXNUM(V19));
L1091:
	RETURN(L35(16,(V1),MAKE_FIXNUM(V13),(V3),MAKE_FIXNUM(V14),MAKE_FIXNUM(V15),MAKE_FIXNUM(V16),MAKE_FIXNUM(V17),MAKE_FIXNUM(V18),MAKE_FIXNUM(V19),VALUES(0),MAKE_FIXNUM(V20),(V11),(V12),MAKE_FIXNUM(32),Cnil,Cnil)/*  READ-PIXARRAY-INTERNAL*/);
L1089:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for READ-XY-FORMAT-IMAGE-X                */
static L37(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9, object V10, object V11, object V12, object V13)
{ VT39 VLEX39 CLSR39
	bds_check;
	{volatile int V14;
	volatile int V15;
	volatile int V16;
	volatile int V17;
	volatile int V18;
	volatile int V19;
	volatile int V20;
	V14= fix(V2);
	V15= fix(V3);
	V16= fix(V5);
	V17= fix(V6);
	V18= fix(V7);
	V19= fix(V8);
	V20= fix(V9);
TTL:
	bds_bind(VV[42],MAKE_FIXNUM(4));          /*  *PRINT-LEVEL*   */
	bds_bind(VV[127],MAKE_FIXNUM(4));         /*  *PRINT-LENGTH*  */
L1100:
	if(!(((V18)*(V20))<=(V15))){
	goto L1101;}
	bds_unwind1;
	bds_unwind1;
	goto L1098;
L1101:
	Lcerror(3,VV[128],VV[129],VV[130])        /*  CERROR          */;
	Lformat(2,(VV[131]->s.s_dbind),VV[132])   /*  FORMAT          */;
	goto L1100;
L1098:
	{volatile int V21;                        /*  BYTES-PER-LINE  */
	volatile int V22;                         /*  DATA-LENGTH     */
	Lceiling(2,MAKE_FIXNUM(V16),MAKE_FIXNUM(8))/*  CEILING        */;
	V21= fix(VALUES(0));
	V22= (V20)*(V18);
	if(((V4))==Cnil){
	goto L1112;}
	bds_bind(VV[42],MAKE_FIXNUM(4));          /*  *PRINT-LEVEL*   */
	bds_bind(VV[127],MAKE_FIXNUM(4));         /*  *PRINT-LENGTH*  */
L1116:
	(*LK6)(2,(V4),VV[8])                      /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1117;}
	bds_unwind1;
	bds_unwind1;
	goto L1114;
L1117:
	Lcerror(5,VV[133],VV[134],VV[76],(V4),VV[8])/*  CERROR        */;
	Lformat(3,(VV[131]->s.s_dbind),VV[135],VV[76])/*  FORMAT      */;
	Lfinish_output(1,(VV[131]->s.s_dbind))    /*  FINISH-OUTPUT   */;
	Lread(0)                                  /*  READ            */;
	V4= VALUES(0);
	Lformat(2,(VV[131]->s.s_dbind),VV[136])   /*  FORMAT          */;
	goto L1116;
L1114:
	bds_bind(VV[42],MAKE_FIXNUM(4));          /*  *PRINT-LEVEL*   */
	bds_bind(VV[127],MAKE_FIXNUM(4));         /*  *PRINT-LENGTH*  */
L1129:
	if(!((length((V4)))>=(V22))){
	goto L1130;}
	bds_unwind1;
	bds_unwind1;
	goto L1110;
L1130:
	Lcerror(3,VV[128],VV[129],VV[137])        /*  CERROR          */;
	Lformat(2,(VV[131]->s.s_dbind),VV[132])   /*  FORMAT          */;
	goto L1129;
L1112:
	(*LK15)(3,MAKE_FIXNUM(V22),VV[138],VV[139])/*  MAKE-ARRAY     */;
	V4= VALUES(0);
L1110:
	{volatile int V23;                        /*  PLANE           */
	V23= 0;
L1141:
	if(!((V23)>=(V18))){
	goto L1142;}
	goto L1138;
L1142:
	L17(9,(V1),(V4),MAKE_FIXNUM((V14)+((V23)*(V20))),MAKE_FIXNUM((V23)*(V20)),MAKE_FIXNUM(V21),MAKE_FIXNUM(V19),MAKE_FIXNUM(V19),MAKE_FIXNUM(V17),(V11))/*  IMAGE-NOSWAP*/;
	V23= (V23)+1;
	goto L1141;
	}
L1138:
	RETURN(L16(22,VV[82],MAKE_FIXNUM(V16),VV[83],MAKE_FIXNUM(V17),VV[84],MAKE_FIXNUM(V18),VV[87],(V4),VV[88],MAKE_FIXNUM(1),VV[86],VV[78],VV[89],MAKE_FIXNUM(V19),VV[92],(V10),VV[93],(V13),VV[90],(V11),VV[91],(V12))/*  CREATE-IMAGE*/);
	}
	}
}
/*	function definition for READ-Z-FORMAT-IMAGE-X                 */
static L38(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9, object V10, object V11, object V12, object V13)
{ VT40 VLEX40 CLSR40
	bds_check;
	{volatile int V14;
	volatile int V15;
	volatile int V16;
	volatile int V17;
	volatile int V18;
	V14= fix(V3);
	V15= fix(V5);
	V16= fix(V6);
	V17= fix(V8);
	V18= fix(V13);
TTL:
	bds_bind(VV[42],MAKE_FIXNUM(4));          /*  *PRINT-LEVEL*   */
	bds_bind(VV[127],MAKE_FIXNUM(4));         /*  *PRINT-LENGTH*  */
L1151:
	if(!(((V16)*(V17))<=(V14))){
	goto L1152;}
	bds_unwind1;
	bds_unwind1;
	goto L1149;
L1152:
	Lcerror(3,VV[128],VV[129],VV[140])        /*  CERROR          */;
	Lformat(2,(VV[131]->s.s_dbind),VV[132])   /*  FORMAT          */;
	goto L1151;
L1149:
	{volatile int V19;                        /*  BYTES-PER-LINE  */
	volatile int V20;                         /*  DATA-LENGTH     */
	Lceiling(2,MAKE_FIXNUM((V15)*(V18)),MAKE_FIXNUM(8))/*  CEILING*/;
	V19= fix(VALUES(0));
	V20= (V17)*(V16);
	if(((V4))==Cnil){
	goto L1163;}
	bds_bind(VV[42],MAKE_FIXNUM(4));          /*  *PRINT-LEVEL*   */
	bds_bind(VV[127],MAKE_FIXNUM(4));         /*  *PRINT-LENGTH*  */
L1167:
	(*LK6)(2,(V4),VV[8])                      /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1168;}
	bds_unwind1;
	bds_unwind1;
	goto L1165;
L1168:
	Lcerror(5,VV[133],VV[134],VV[76],(V4),VV[8])/*  CERROR        */;
	Lformat(3,(VV[131]->s.s_dbind),VV[135],VV[76])/*  FORMAT      */;
	Lfinish_output(1,(VV[131]->s.s_dbind))    /*  FINISH-OUTPUT   */;
	Lread(0)                                  /*  READ            */;
	V4= VALUES(0);
	Lformat(2,(VV[131]->s.s_dbind),VV[136])   /*  FORMAT          */;
	goto L1167;
L1165:
	bds_bind(VV[42],MAKE_FIXNUM(4));          /*  *PRINT-LEVEL*   */
	bds_bind(VV[127],MAKE_FIXNUM(4));         /*  *PRINT-LENGTH*  */
L1180:
	if(!((length((V4)))>=(V20))){
	goto L1181;}
	bds_unwind1;
	bds_unwind1;
	goto L1161;
L1181:
	Lcerror(3,VV[128],VV[129],VV[141])        /*  CERROR          */;
	Lformat(2,(VV[131]->s.s_dbind),VV[132])   /*  FORMAT          */;
	goto L1180;
L1163:
	(*LK15)(3,MAKE_FIXNUM(V20),VV[138],VV[139])/*  MAKE-ARRAY     */;
	V4= VALUES(0);
L1161:
	L17(9,(V1),(V4),(V2),MAKE_FIXNUM(0),MAKE_FIXNUM(V19),MAKE_FIXNUM(V17),MAKE_FIXNUM(V17),MAKE_FIXNUM(V16),(V10))/*  IMAGE-NOSWAP*/;
	RETURN(L16(22,VV[82],MAKE_FIXNUM(V15),VV[83],MAKE_FIXNUM(V16),VV[84],(V7),VV[87],(V4),VV[88],MAKE_FIXNUM(V18),VV[86],VV[48],VV[89],MAKE_FIXNUM(V17),VV[92],(V9),VV[93],(V12),VV[90],(V10),VV[91],(V11))/*  CREATE-IMAGE*/);
	}
	}
}
/*	function definition for READ-IMAGE-XY                         */
static L39(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9, object V10, object V11, object V12, object V13, object V14)
{ VT41 VLEX41 CLSR41
	bds_check;
	{volatile int V15;
	volatile int V16;
	volatile int V17;
	volatile int V18;
	volatile int V19;
	volatile int V20;
	volatile int V21;
	volatile int V22;
	volatile int V23;
	V15= fix(V2);
	V16= fix(V5);
	V17= fix(V6);
	V18= fix(V7);
	V19= fix(V8);
	V20= fix(V9);
	V21= fix(V10);
	V22= fix(V11);
	V23= fix(V12);
TTL:
	bds_bind(VV[42],MAKE_FIXNUM(4));          /*  *PRINT-LEVEL*   */
	bds_bind(VV[127],MAKE_FIXNUM(4));         /*  *PRINT-LENGTH*  */
L1192:
	(*LK6)(2,(V4),VV[95])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1193;}
	bds_unwind1;
	bds_unwind1;
	goto L1190;
L1193:
	Lcerror(5,VV[133],VV[134],VV[76],(V4),VV[95])/*  CERROR       */;
	Lformat(3,(VV[131]->s.s_dbind),VV[135],VV[76])/*  FORMAT      */;
	Lfinish_output(1,(VV[131]->s.s_dbind))    /*  FINISH-OUTPUT   */;
	Lread(0)                                  /*  READ            */;
	V4= VALUES(0);
	Lformat(2,(VV[131]->s.s_dbind),VV[136])   /*  FORMAT          */;
	goto L1192;
L1190:
	{ int V24;
	volatile object V25;                      /*  DIMENSIONS      */
	volatile object V26;                      /*  ELEMENT-TYPE    */
	if(((V4))==Cnil){
	goto L1206;}
	(*LK16)(1,CAR((V4)))                      /*  ARRAY-DIMENSIONS*/;
	T0= VALUES(0);
	Larray_element_type(1,CAR((V4)))          /*  ARRAY-ELEMENT-TYPE*/;
	VALUES(1) = VALUES(0);
	VALUES(0) = T0;
	V24=2;
	goto L1204;
L1206:
	Lceiling(2,MAKE_FIXNUM(V18),MAKE_FIXNUM(32))/*  CEILING       */;
	VALUES(1) = VV[142];
	VALUES(0) = list(2,MAKE_FIXNUM(V19),MAKE_FIXNUM((fix(VALUES(0)))*(32)));
	V24=2;
L1204:
	if (V24--==0) goto L1211;
	V25= VALUES(0);
	if (V24--==0) goto L1212;
	V26= VALUES(1);
	goto L1213;
L1211:
	V25= Cnil;
L1212:
	V26= Cnil;
L1213:
	{volatile object V27;                     /*  ARRAYS          */
	volatile object V28;                      /*  RESULT          */
	volatile int V29;                         /*  LIMIT           */
	volatile int V30;                         /*  PLANE           */
	volatile int V31;                         /*  INDEX           */
	V27= (V4);
	V28= Cnil;
	V29= (fix((V3)))+(V15);
	V30= 0;
	V31= V15;
L1221:
	if((V30)>=(V20)){
	goto L1223;}
	if(!(((V31)+(V22))>(V29))){
	goto L1222;}
L1223:
	V4= nreverse((V28));
	V20= length((V4));
	goto L1214;
L1222:
	{register object V33;                     /*  ARRAY           */
	{object V34;
	V34= CAR((V27));
	V27= CDR((V27));
	VALUES(0) = (V34);
	}
	if(VALUES(0)==Cnil)goto L1232;
	V33= VALUES(0);
	goto L1231;
L1232:
	(*LK15)(3,(V25),VV[138],(V26))            /*  MAKE-ARRAY      */;
	V33= VALUES(0);
L1231:
	V28= CONS((V33),(V28));
	L36(12,(V1),MAKE_FIXNUM(V31),(V33),MAKE_FIXNUM(V16),MAKE_FIXNUM(V17),MAKE_FIXNUM(V18),MAKE_FIXNUM(V19),MAKE_FIXNUM(V21),MAKE_FIXNUM(1),MAKE_FIXNUM(V23),(V13),(V14))/*  READ-PIXARRAY*/;
	}
	V30= (V30)+1;
	V31= (V31)+(V22);
	goto L1221;
	}
L1214:
	RETURN(L16(8,VV[82],MAKE_FIXNUM(V18),VV[83],MAKE_FIXNUM(V19),VV[84],MAKE_FIXNUM(V20),VV[87],(V4))/*  CREATE-IMAGE*/);}
	}
}
/*	function definition for READ-IMAGE-Z                          */
static L40(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9, object V10, object V11, object V12, object V13, object V14)
{ VT42 VLEX42 CLSR42
	bds_check;
	{volatile int V15;
	volatile int V16;
	volatile int V17;
	volatile int V18;
	volatile int V19;
	volatile int V20;
	V15= fix(V3);
	V16= fix(V6);
	V17= fix(V7);
	V18= fix(V8);
	V19= fix(V10);
	V20= fix(V11);
TTL:
	bds_bind(VV[42],MAKE_FIXNUM(4));          /*  *PRINT-LEVEL*   */
	bds_bind(VV[127],MAKE_FIXNUM(4));         /*  *PRINT-LENGTH*  */
L1246:
	if(!((((V16)+(V18))*(V19))<=(V15))){
	goto L1247;}
	bds_unwind1;
	bds_unwind1;
	goto L1244;
L1247:
	Lcerror(3,VV[128],VV[129],VV[143])        /*  CERROR          */;
	Lformat(2,(VV[131]->s.s_dbind),VV[132])   /*  FORMAT          */;
	goto L1246;
L1244:
	{object V21;                              /*  IMAGE-BITS-PER-LINE*/
	object V22;                               /*  IMAGE-PIXELS-PER-LINE*/
	V21= MAKE_FIXNUM((V17)*(V20));
	Lceiling(2,(V21),MAKE_FIXNUM(32))         /*  CEILING         */;
	Lceiling(2,MAKE_FIXNUM((fix(VALUES(0)))*(32)),MAKE_FIXNUM(V20))/*  CEILING*/;
	V22= VALUES(0);
	if(((V4))!=Cnil){
	goto L1257;}
	{object V23= list(2,MAKE_FIXNUM(V18),(V22));
	if(!eql(MAKE_FIXNUM(V20),VV[11]))goto L1262;
	VALUES(0) = VV[142];
	goto L1261;
L1262:
	if(!eql(MAKE_FIXNUM(V20),VV[120]))goto L1263;
	VALUES(0) = VV[144];
	goto L1261;
L1263:
	if(!eql(MAKE_FIXNUM(V20),VV[116]))goto L1264;
	VALUES(0) = VV[145];
	goto L1261;
L1264:
	if(!eql(MAKE_FIXNUM(V20),VV[115]))goto L1265;
	VALUES(0) = VV[146];
	goto L1261;
L1265:
	if(!eql(MAKE_FIXNUM(V20),VV[123]))goto L1266;
	VALUES(0) = VV[147];
	goto L1261;
L1266:
	if(!eql(MAKE_FIXNUM(V20),VV[114]))goto L1267;
	VALUES(0) = VV[148];
	goto L1261;
L1267:
	FEerror("The ECASE key value ~s is illegal.",1,MAKE_FIXNUM(V20));
L1261:
	(*LK15)(3,(V23),VV[138],VALUES(0))        /*  MAKE-ARRAY      */;
	V4= VALUES(0);}
L1257:
	L36(12,(V1),(V2),(V4),(V5),MAKE_FIXNUM(V16),MAKE_FIXNUM(V17),MAKE_FIXNUM(V18),MAKE_FIXNUM(V19),MAKE_FIXNUM(V20),(V12),(V13),(V14))/*  READ-PIXARRAY*/;
	RETURN(L16(10,VV[82],MAKE_FIXNUM(V17),VV[83],MAKE_FIXNUM(V18),VV[84],(V9),VV[87],(V4),VV[88],MAKE_FIXNUM(V20))/*  CREATE-IMAGE*/);
	}
	}
}
/*	function definition for GET-IMAGE                             */
static L41(int narg, object V1, ...)
{ VT43 VLEX43 CLSR43
	{volatile object V2;
	volatile int V3;
	volatile int V4;
	volatile int V5;
	volatile int V6;
	volatile object V7;
	volatile object V8;
	volatile object V9;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[16];
	parse_key(narg,args,8,L41keys,keyvars,OBJNULL,FALSE);
	V2= keyvars[0];
	if(keyvars[9]==Cnil){
	(*LK5)(3,VV[74],VV[75],VV[149])           /*  X-ERROR         */;
	V3= fix((VV[77]->s.s_dbind));
	}else{
	V3= fix(keyvars[1]);}
	if(keyvars[10]==Cnil){
	(*LK5)(3,VV[74],VV[75],VV[150])           /*  X-ERROR         */;
	V4= fix((VV[77]->s.s_dbind));
	}else{
	V4= fix(keyvars[2]);}
	if(keyvars[11]==Cnil){
	(*LK5)(3,VV[74],VV[75],VV[79])            /*  X-ERROR         */;
	V5= fix((VV[77]->s.s_dbind));
	}else{
	V5= fix(keyvars[3]);}
	if(keyvars[12]==Cnil){
	(*LK5)(3,VV[74],VV[75],VV[80])            /*  X-ERROR         */;
	V6= fix((VV[77]->s.s_dbind));
	}else{
	V6= fix(keyvars[4]);}
	V7= keyvars[5];
	V8= keyvars[6];
	V9= keyvars[7];
	}
	if(((V9))!=Cnil){
	goto L1277;}
	if(((V8)!= VV[78]))goto L1281;
	V9= VV[51];
	goto L1280;
L1281:
	if(((V8)!= VV[48]))goto L1282;
	V9= VV[62];
	goto L1280;
L1282:
	if(((V8)!= Cnil))goto L1283;
	V9= VV[35];
	goto L1280;
L1283:
	FEerror("The ECASE key value ~s is illegal.",1,(V8));
L1280:
L1277:
	if(((V8))!=Cnil){
	goto L1284;}
	if(((V9)!= VV[51]))goto L1288;
	V8= VV[78];
	goto L1287;
L1288:
	if(((V9)!= VV[62])
	&& ((V9)!= VV[35]))goto L1289;
	V8= VV[48];
	goto L1287;
L1289:
	V8= Cnil;
L1287:
L1284:
	if(((V9)!= VV[51]))goto L1293;
	if(((V8))==(VV[78])){
	goto L1290;}
	goto L1292;
L1293:
	if(((V9)!= VV[62]))goto L1294;
	if(((V8))==(VV[48])){
	goto L1290;}
	goto L1292;
L1294:
	if(((V9)!= VV[35]))goto L1295;
	goto L1290;
L1295:
	FEerror("The ECASE key value ~s is illegal.",1,(V9));
L1292:
	Lerror(3,VV[151],(V9),(V8))               /*  ERROR           */;
L1290:
	if(((V7))!=Cnil){
	goto L1296;}
	V7= VV[152];
L1296:
	{volatile object V10;                     /*  DISPLAY         */
	V10= ((V1))->in.in_slots[1];
	{volatile object V11;                     /*  .DISPLAY.       */
	volatile object V12;                      /*  .PENDING-COMMAND.*/
	volatile object V13;                      /*  .REPLY-BUFFER.  */
	V11= (V10);
	V12= Cnil;
	V13= Cnil;
	{ int V14; volatile bool unwinding = FALSE;
	if ((V14=frs_push(FRS_PROTECT,Cnil))) {
	V14--; unwinding = TRUE;} else {
	if((((V11))->in.in_slots[10])==Cnil){
	goto L1303;}
	(*LK5)(3,VV[155],VV[156],(V11))           /*  X-ERROR         */;
L1303:
	(*LK17)(1,(V11))                          /*  START-PENDING-COMMAND*/;
	V12= VALUES(0);
	{object V15;                              /*  %BUFFER         */
	V15= (V11);
	if(!(((fix(((V15))->in.in_slots[6]))+(160))>=(fix(((V15))->in.in_slots[2])))){
	goto L1309;}
	(*LK18)(1,(V15))                          /*  BUFFER-FLUSH    */;
L1309:
	{register int V16;                        /*  BUFFER-BOFFSET  */
	register object V17;                      /*  BUFFER-BBUF     */
	V16= fix(((V15))->in.in_slots[6]);
	V17= ((V15))->in.in_slots[7];
	((V11))->in.in_slots[4]= MAKE_FIXNUM(V16);
	(((V17))->ust.ust_self[(V16)+(0)]=(73));
	(*LK6)(2,(V8),VV[157])                    /*  TYPEP           */;
	if(VALUES(0)!=Cnil){
	goto L1321;}
	VALUES(0) = Cnil;
	goto L1320;
L1321:
	VALUES(0) = (VV[338]->s.s_gfdef);
	(*LK19)(4,(V8),VV[158],VV[159],VALUES(0)) /*  POSITION        */;
	T0= VALUES(0);
	{int V18= ((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(4))))=fix(T0));
	VALUES(0) = MAKE_FIXNUM((((V17))->ust.ust_self[(V16)+(1)]=(V18)));}
L1320:
	if(VALUES(0)==Cnil)goto L1319;
	goto L1318;
L1319:
	(*LK20)(2,(V8),VV[160])                   /*  X-TYPE-ERROR    */;
L1318:
	(*LK21)(1,(V1))                           /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L1327;}
	((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L1325;
L1327:
	(*LK20)(2,(V1),VV[153])                   /*  X-TYPE-ERROR    */;
L1325:
	(*LK6)(2,MAKE_FIXNUM(V3),VV[161])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1331;}
	((*(short *)(((V17))->st.st_self+((V16)+(8))))=V3);
	goto L1329;
L1331:
	(*LK20)(2,MAKE_FIXNUM(V3),VV[161])        /*  X-TYPE-ERROR    */;
L1329:
	(*LK6)(2,MAKE_FIXNUM(V4),VV[161])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1335;}
	((*(short *)(((V17))->st.st_self+((V16)+(10))))=V4);
	goto L1333;
L1335:
	(*LK20)(2,MAKE_FIXNUM(V4),VV[161])        /*  X-TYPE-ERROR    */;
L1333:
	(*LK6)(2,MAKE_FIXNUM(V5),VV[162])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1339;}
	((*(unsigned short *)(((V17))->ust.ust_self+((V16)+(12))))=V5);
	goto L1337;
L1339:
	(*LK20)(2,MAKE_FIXNUM(V5),VV[162])        /*  X-TYPE-ERROR    */;
L1337:
	(*LK6)(2,MAKE_FIXNUM(V6),VV[162])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1343;}
	((*(unsigned short *)(((V17))->ust.ust_self+((V16)+(14))))=V6);
	goto L1341;
L1343:
	(*LK20)(2,MAKE_FIXNUM(V6),VV[162])        /*  X-TYPE-ERROR    */;
L1341:
	(*LK6)(2,(V7),VV[163])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1347;}
	((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(16))))=fix((V7)));
	goto L1345;
L1347:
	(*LK20)(2,(V7),VV[163])                   /*  X-TYPE-ERROR    */;
L1345:
	((*(unsigned short *)(((V17))->ust.ust_self+((V16)+(2))))=5);
	((V11))->in.in_slots[6]= MAKE_FIXNUM((V16)+(20));
	(*LK22)(1,(V11))                          /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK23)(1,(V11))                          /*  BUFFER-FORCE-OUTPUT*/;
	(*LK24)(1,(V11))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK25)(2,(V11),(V12))                    /*  READ-REPLY      */;
	V13= VALUES(0);
	{object V15;                              /*  %REPLY-BUFFER   */
	object V16;                               /*  %BUFFER         */
	{register int V17;                        /*  BUFFER-BOFFSET  */
	register object V18;                      /*  BUFFER-BBUF     */
	V17= 0;
	V18= ((V13))->in.in_slots[1];
	{register int V19;                        /*  DEPTH           */
	register int V20;                         /*  LENGTH          */
	register object V21;                      /*  VISUAL-INFO     */
	object V22;                               /*  BITMAP-FORMAT   */
	register int V23;                         /*  UNIT            */
	object V24;                               /*  BYTE-LSB-FIRST-P*/
	object V25;                               /*  BIT-LSB-FIRST-P */
	V19= ((V18))->ust.ust_self[(V17)+(1)];
	V20= (4)*((*(unsigned long *)(((V18))->ust.ust_self+((V17)+(4)))));
	(*LK26)(2,(V10),MAKE_FIXNUM(((*(unsigned long *)(((V18))->ust.ust_self+((V17)+(8)))) & 0x1fffffff)))/*  VISUAL-INFO*/;
	V21= VALUES(0);
	V22= ((V10))->in.in_slots[44];
	V23= fix(((V22))->in.in_slots[0]);
	V24= ((V10))->in.in_slots[43];
	V25= ((V22))->in.in_slots[2];
	{ int V26;
	int V27;                                  /*  PAD             */
	int V28;                                  /*  BITS-PER-PIXEL  */
	if(((V8)!= VV[78]))goto L1368;
	VALUES(1) = MAKE_FIXNUM(1);
	VALUES(0) = ((V22))->in.in_slots[1];
	V26=2;
	goto L1367;
L1368:
	if(((V8)!= VV[48]))goto L1369;
	if(!((V19)==(1))){
	goto L1371;}
	VALUES(1) = MAKE_FIXNUM(1);
	VALUES(0) = ((V22))->in.in_slots[1];
	V26=2;
	goto L1367;
L1371:
	{object V29;                              /*  PIXMAP-FORMAT   */
	T0= ((V10))->in.in_slots[45];
	VALUES(0) = (VV[346]->s.s_gfdef);
	(*LK27)(4,MAKE_FIXNUM(V19),T0,VV[166],VALUES(0))/*  FIND      */;
	V29= VALUES(0);
	VALUES(1) = ((V29))->in.in_slots[1];
	VALUES(0) = ((V29))->in.in_slots[2];
	V26=2;
	goto L1367;
	}
L1369:
	FEerror("The ECASE key value ~s is illegal.",1,(V8));
L1367:
	if (V26--==0) goto L1376;
	V27= fix(VALUES(0));
	if (V26--==0) goto L1377;
	V28= fix(VALUES(1));
	goto L1378;
L1376:
	V27= 0;
L1377:
	V28= 0;
L1378:
	{object V29;                              /*  BITS-PER-LINE   */
	object V30;                               /*  PADDED-BITS-PER-LINE*/
	register int V31;                         /*  PADDED-BYTES-PER-LINE*/
	int V32;                                  /*  PADDED-BYTES-PER-PLANE*/
	object V33;                               /*  IMAGE           */
	V29= MAKE_FIXNUM((V28)*(V5));
	Lceiling(2,(V29),MAKE_FIXNUM(V27))        /*  CEILING         */;
	V30= MAKE_FIXNUM((fix(VALUES(0)))*(V27));
	Lceiling(2,(V30),MAKE_FIXNUM(8))          /*  CEILING         */;
	V31= fix(VALUES(0));
	V32= (V31)*(V6);
	if(((V9)!= VV[35]))goto L1385;
	if(((V8)!= VV[78]))goto L1386;
	L37(13,(V18),MAKE_FIXNUM(32),MAKE_FIXNUM(V20),(V2),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),MAKE_FIXNUM(V19),MAKE_FIXNUM(V31),MAKE_FIXNUM(V32),MAKE_FIXNUM(V23),(V24),(V25),MAKE_FIXNUM(V27))/*  READ-XY-FORMAT-IMAGE-X*/;
	V33= VALUES(0);
	goto L1384;
L1386:
	if(((V8)!= VV[48]))goto L1387;
	L38(13,(V18),MAKE_FIXNUM(32),MAKE_FIXNUM(V20),(V2),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),MAKE_FIXNUM(V19),MAKE_FIXNUM(V31),MAKE_FIXNUM(V23),(V24),(V25),MAKE_FIXNUM(V27),MAKE_FIXNUM(V28))/*  READ-Z-FORMAT-IMAGE-X*/;
	V33= VALUES(0);
	goto L1384;
L1387:
	FEerror("The ECASE key value ~s is illegal.",1,(V8));
L1385:
	if(((V9)!= VV[51]))goto L1388;
	L39(14,(V18),MAKE_FIXNUM(32),MAKE_FIXNUM(V20),(V2),MAKE_FIXNUM(0),MAKE_FIXNUM(0),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),MAKE_FIXNUM(V19),MAKE_FIXNUM(V31),MAKE_FIXNUM(V32),MAKE_FIXNUM(V23),(V24),(V25))/*  READ-IMAGE-XY*/;
	V33= VALUES(0);
	goto L1384;
L1388:
	if(((V9)!= VV[62]))goto L1389;
	L40(14,(V18),MAKE_FIXNUM(32),MAKE_FIXNUM(V20),(V2),MAKE_FIXNUM(0),MAKE_FIXNUM(0),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),MAKE_FIXNUM(V19),MAKE_FIXNUM(V31),MAKE_FIXNUM(V28),MAKE_FIXNUM(V23),(V24),(V25))/*  READ-IMAGE-Z*/;
	V33= VALUES(0);
	goto L1384;
L1389:
	FEerror("The ECASE key value ~s is illegal.",1,(V9));
L1384:
	if(((V21))==Cnil){
	goto L1390;}
	if(number_compare(MAKE_FIXNUM(0),((V21))->in.in_slots[3])==0){
	goto L1393;}
	{object V34;
	V34= ((V21))->in.in_slots[3];
	{object V35;
	siLput_f(3,((V33))->in.in_slots[3],(V34),VV[25])/*  PUT-F     */;
	V35= VALUES(0);
	((V33))->in.in_slots[3]= (V35);
	}
	}
L1393:
	if(number_compare(MAKE_FIXNUM(0),((V21))->in.in_slots[4])==0){
	goto L1399;}
	{object V34;
	V34= ((V21))->in.in_slots[4];
	{object V35;
	siLput_f(3,((V33))->in.in_slots[3],(V34),VV[27])/*  PUT-F     */;
	V35= VALUES(0);
	((V33))->in.in_slots[3]= (V35);
	}
	}
L1399:
	if(number_compare(MAKE_FIXNUM(0),((V21))->in.in_slots[5])==0){
	goto L1390;}
	{object V34;
	V34= ((V21))->in.in_slots[5];
	{object V35;
	siLput_f(3,((V33))->in.in_slots[3],(V34),VV[26])/*  PUT-F     */;
	V35= VALUES(0);
	((V33))->in.in_slots[3]= (V35);
	}
	}
L1390:
	VALUES(1) = (V21);
	VALUES(0) = (V33);
	V14=2;
	}}
	}
	}
	}
	}
	frs_pop();
	MV_SAVE(V14);
	if(((V13))==Cnil){
	goto L1411;}
	(*LK13)(1,(V13))                          /*  DEALLOCATE-REPLY-BUFFER*/;
L1411:
	if(((V12))==Cnil){
	goto L1410;}
	(*LK28)(2,(V11),(V12))                    /*  STOP-PENDING-COMMAND*/;
L1410:
	MV_RESTORE(V14);
	if (unwinding) unwind(nlj_fr,nlj_tag,V14+1);
	else {
	RETURN(V14);}}
	}
	}
	}
}
/*	function definition for WRITE-PIXARRAY-1                      */
static L42(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT44 VLEX44 CLSR44
	{volatile int V10;
	volatile int V11;
	volatile int V12;
	volatile int V13;
	V10= fix(V4);
	V11= fix(V6);
	V12= fix(V7);
	V13= fix(V8);
TTL:
	{volatile object V14;                     /*  BUFFER-BBUF     */
	V14= (V1);
	{volatile int V15;                        /*  H               */
	volatile int V16;                         /*  Y               */
	volatile int V17;                         /*  RIGHT-BITS      */
	volatile int V18;                         /*  MIDDLE-BITS     */
	volatile int V19;                         /*  MIDDLE-BYTES    */
	volatile int V20;                         /*  START           */
	V15= 0;
	V16= fix((V5));
	V17= (V11>=0&&8>0?(V11)%(8):imod(V11,8));
	V18= (V11)-(V17);
	Lceiling(2,MAKE_FIXNUM(V18),MAKE_FIXNUM(8))/*  CEILING        */;
	V19= fix(VALUES(0));
	V20= fix((V2));
L1423:
	if(!((V15)>=(V12))){
	goto L1424;}
	VALUES(0) = Cnil;
	RETURN(1);
L1424:
	{volatile int V22;                        /*  END             */
	volatile int V23;                         /*  I               */
	volatile int V24;                         /*  START-X         */
	volatile int V25;                         /*  X               */
	V22= (V20)+(V19);
	V23= V20;
	V24= V10;
	V25= V24;
L1433:
	if(!((V23)>=(V22))){
	goto L1434;}
	if((V17)==0){
	goto L1427;}
	{register int V27;                        /*  X               */
	V27= (V24)+(V18);
	{register object V28;
	object V29;
	V28= (V14);
	V29= MAKE_FIXNUM(V22);
	{object V30= ((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V27)+(0)];
	(*LK9)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(7))   /*  BYTE            */;
	T0= VALUES(0);
	if(!((V17)>(1))){
	goto L1445;}
	T1= ((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V27)+(1)];
	goto L1443;
L1445:
	T1= MAKE_FIXNUM(0);
L1443:
	(*LK9)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(6))   /*  BYTE            */;
	T2= VALUES(0);
	if(!((V17)>(2))){
	goto L1450;}
	T3= ((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V27)+(2)];
	goto L1448;
L1450:
	T3= MAKE_FIXNUM(0);
L1448:
	(*LK9)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(5))   /*  BYTE            */;
	T4= VALUES(0);
	if(!((V17)>(3))){
	goto L1455;}
	T5= ((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V27)+(3)];
	goto L1453;
L1455:
	T5= MAKE_FIXNUM(0);
L1453:
	(*LK9)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(4))   /*  BYTE            */;
	T6= VALUES(0);
	if(!((V17)>(4))){
	goto L1460;}
	T7= ((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V27)+(4)];
	goto L1458;
L1460:
	T7= MAKE_FIXNUM(0);
L1458:
	(*LK9)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(3))   /*  BYTE            */;
	T8= VALUES(0);
	if(!((V17)>(5))){
	goto L1465;}
	T9= ((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V27)+(5)];
	goto L1463;
L1465:
	T9= MAKE_FIXNUM(0);
L1463:
	(*LK9)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(2))   /*  BYTE            */;
	T10= VALUES(0);
	if(!((V17)>(6))){
	goto L1470;}
	T11= ((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V27)+(6)];
	goto L1468;
L1470:
	T11= MAKE_FIXNUM(0);
L1468:
	(*LK9)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(1))   /*  BYTE            */;
	(*LK10)(3,T11,VALUES(0),MAKE_FIXNUM(0))   /*  DPB             */;
	(*LK10)(3,T9,T10,VALUES(0))               /*  DPB             */;
	(*LK10)(3,T7,T8,VALUES(0))                /*  DPB             */;
	(*LK10)(3,T5,T6,VALUES(0))                /*  DPB             */;
	(*LK10)(3,T3,T4,VALUES(0))                /*  DPB             */;
	(*LK10)(3,T1,T2,VALUES(0))                /*  DPB             */;
	(*LK10)(3,(V30),T0,VALUES(0))             /*  DPB             */;
	aset1((V28),fix((V29)),VALUES(0));
	goto L1427;}
	}
	}
L1434:
	{register object V31;
	object V32;
	V31= (V14);
	V32= MAKE_FIXNUM(V23);
	{object V33= ((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V25)+(0)];
	(*LK9)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(7))   /*  BYTE            */;
	T12= VALUES(0);
	{object V34= ((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V25)+(1)];
	(*LK9)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(6))   /*  BYTE            */;
	T13= VALUES(0);
	{object V35= ((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V25)+(2)];
	(*LK9)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(5))   /*  BYTE            */;
	T14= VALUES(0);
	{object V36= ((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V25)+(3)];
	(*LK9)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(4))   /*  BYTE            */;
	T15= VALUES(0);
	{object V37= ((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V25)+(4)];
	(*LK9)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(3))   /*  BYTE            */;
	T16= VALUES(0);
	{object V38= ((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V25)+(5)];
	(*LK9)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(2))   /*  BYTE            */;
	T17= VALUES(0);
	{object V39= ((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V25)+(6)];
	(*LK9)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(1))   /*  BYTE            */;
	T18= VALUES(0);
	(*LK10)(3,(V39),T18,((V3))->a.a_self[V16*((V3))->a.a_dims[1]+(V25)+(7)])/*  DPB*/;
	(*LK10)(3,(V38),T17,VALUES(0))            /*  DPB             */;
	(*LK10)(3,(V37),T16,VALUES(0))            /*  DPB             */;
	(*LK10)(3,(V36),T15,VALUES(0))            /*  DPB             */;
	(*LK10)(3,(V35),T14,VALUES(0))            /*  DPB             */;
	(*LK10)(3,(V34),T13,VALUES(0))            /*  DPB             */;
	(*LK10)(3,(V33),T12,VALUES(0))            /*  DPB             */;
	aset1((V31),fix((V32)),VALUES(0));}}}}}}}
	}
	V23= (V23)+1;
	V25= (V25)+(8);
	goto L1433;
	}
L1427:
	V15= (V15)+1;
	V16= (V16)+1;
	V20= (V20)+(V13);
	goto L1423;
	}
	}
	}
}
/*	function definition for WRITE-PIXARRAY-4                      */
static L43(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT45 VLEX45 CLSR45
	{volatile int V10;
	volatile int V11;
	volatile int V12;
	volatile int V13;
	V10= fix(V4);
	V11= fix(V6);
	V12= fix(V7);
	V13= fix(V8);
TTL:
	{volatile object V14;                     /*  BUFFER-BBUF     */
	V14= (V1);
	{volatile int V15;                        /*  H               */
	volatile int V16;                         /*  Y               */
	volatile int V17;                         /*  RIGHT-NIBBLES   */
	volatile int V18;                         /*  MIDDLE-NIBBLES  */
	volatile int V19;                         /*  MIDDLE-BYTES    */
	volatile int V20;                         /*  START           */
	V15= 0;
	V16= fix((V5));
	V17= (V11>=0&&2>0?(V11)%(2):imod(V11,2));
	V18= (V11)-(V17);
	Lceiling(2,MAKE_FIXNUM(V18),MAKE_FIXNUM(2))/*  CEILING        */;
	V19= fix(VALUES(0));
	V20= fix((V2));
L1516:
	if(!((V15)>=(V12))){
	goto L1517;}
	VALUES(0) = Cnil;
	RETURN(1);
L1517:
	{volatile int V22;                        /*  END             */
	volatile int V23;                         /*  I               */
	volatile int V24;                         /*  START-X         */
	volatile int V25;                         /*  X               */
	V22= (V20)+(V19);
	V23= V20;
	V24= V10;
	V25= V24;
L1526:
	if(!((V23)>=(V22))){
	goto L1527;}
	if((V17)==0){
	goto L1520;}
	{register object V27;
	object V28;
	V27= (V14);
	V28= MAKE_FIXNUM(V22);
	{int V29= ((V3))->fixa.fixa_self[V16*((V3))->a.a_dims[1]+(V24)+(V18)];
	(*LK9)(2,MAKE_FIXNUM(4),MAKE_FIXNUM(4))   /*  BYTE            */;
	(*LK10)(3,MAKE_FIXNUM(V29),VALUES(0),MAKE_FIXNUM(0))/*  DPB   */;
	aset1((V27),fix((V28)),VALUES(0));
	goto L1520;}
	}
L1527:
	{register object V30;
	object V31;
	V30= (V14);
	V31= MAKE_FIXNUM(V23);
	{int V32= ((V3))->fixa.fixa_self[V16*((V3))->a.a_dims[1]+(V25)+(0)];
	(*LK9)(2,MAKE_FIXNUM(4),MAKE_FIXNUM(4))   /*  BYTE            */;
	T0= VALUES(0);
	(*LK10)(3,MAKE_FIXNUM(V32),T0,MAKE_FIXNUM(((V3))->fixa.fixa_self[V16*((V3))->a.a_dims[1]+(V25)+(1)]))/*  DPB*/;
	aset1((V30),fix((V31)),VALUES(0));}
	}
	V23= (V23)+1;
	V25= (V25)+(2);
	goto L1526;
	}
L1520:
	V15= (V15)+1;
	V16= (V16)+1;
	V20= (V20)+(V13);
	goto L1516;
	}
	}
	}
}
/*	function definition for WRITE-PIXARRAY-8                      */
static L44(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT46 VLEX46 CLSR46
	{volatile int V10;
	volatile int V11;
	volatile int V12;
	volatile int V13;
	V10= fix(V4);
	V11= fix(V6);
	V12= fix(V7);
	V13= fix(V8);
TTL:
	{volatile object V14;                     /*  BUFFER-BBUF     */
	V14= (V1);
	{volatile int V15;                        /*  H               */
	volatile int V16;                         /*  Y               */
	volatile int V17;                         /*  START           */
	V15= 0;
	V16= fix((V5));
	V17= fix((V2));
L1557:
	if(!((V15)>=(V12))){
	goto L1558;}
	VALUES(0) = Cnil;
	RETURN(1);
L1558:
	{volatile int V19;                        /*  END             */
	volatile int V20;                         /*  I               */
	volatile int V21;                         /*  X               */
	V19= (V17)+(V11);
	V20= V17;
	V21= V10;
L1566:
	if(!((V20)>=(V19))){
	goto L1567;}
	goto L1561;
L1567:
	((V14))->ust.ust_self[V20]= ((V3))->fixa.fixa_self[V16*((V3))->a.a_dims[1]+V21];
	V20= (V20)+1;
	V21= (V21)+1;
	goto L1566;
	}
L1561:
	V15= (V15)+1;
	V16= (V16)+1;
	V17= (V17)+(V13);
	goto L1557;
	}
	}
	}
}
/*	function definition for WRITE-PIXARRAY-16                     */
static L45(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT47 VLEX47 CLSR47
	{volatile int V10;
	volatile int V11;
	volatile int V12;
	volatile int V13;
	V10= fix(V4);
	V11= fix(V6);
	V12= fix(V7);
	V13= fix(V8);
TTL:
	{volatile object V14;                     /*  BUFFER-BBUF     */
	V14= (V1);
	{volatile int V15;                        /*  H               */
	volatile int V16;                         /*  Y               */
	volatile int V17;                         /*  START           */
	V15= 0;
	V16= fix((V5));
	V17= fix((V2));
L1587:
	if(!((V15)>=(V12))){
	goto L1588;}
	VALUES(0) = Cnil;
	RETURN(1);
L1588:
	{volatile int V19;                        /*  END             */
	volatile int V20;                         /*  I               */
	volatile int V21;                         /*  X               */
	V19= (V17)+((V11)*(2));
	V20= V17;
	V21= V10;
L1596:
	if(!((V20)>=(V19))){
	goto L1597;}
	goto L1591;
L1597:
	{register int V23;                        /*  PIXEL           */
	V23= ((V3))->fixa.fixa_self[V16*((V3))->a.a_dims[1]+V21];
	(*LK11)(3,MAKE_FIXNUM(8),MAKE_FIXNUM(8),MAKE_FIXNUM(V23))/*  LDB1*/;
	T0= VALUES(0);
	aset1((V14),(V20)+(0),T0);
	(*LK11)(3,MAKE_FIXNUM(8),MAKE_FIXNUM(0),MAKE_FIXNUM(V23))/*  LDB1*/;
	T0= VALUES(0);
	aset1((V14),(V20)+(1),T0);
	}
	V20= (V20)+(2);
	V21= (V21)+1;
	goto L1596;
	}
L1591:
	V15= (V15)+1;
	V16= (V16)+1;
	V17= (V17)+(V13);
	goto L1587;
	}
	}
	}
}
/*	function definition for WRITE-PIXARRAY-24                     */
static L46(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT48 VLEX48 CLSR48
	{volatile int V10;
	volatile int V11;
	volatile int V12;
	volatile int V13;
	V10= fix(V4);
	V11= fix(V6);
	V12= fix(V7);
	V13= fix(V8);
TTL:
	{volatile object V14;                     /*  BUFFER-BBUF     */
	V14= (V1);
	{volatile object V15;                     /*  H               */
	volatile int V16;                         /*  Y               */
	volatile int V17;                         /*  START           */
	V15= MAKE_FIXNUM(0);
	V16= fix((V5));
	V17= fix((V2));
L1621:
	if(!((fix((V15)))>=(V12))){
	goto L1622;}
	VALUES(0) = Cnil;
	RETURN(1);
L1622:
	{volatile int V19;                        /*  END             */
	volatile int V20;                         /*  I               */
	volatile int V21;                         /*  X               */
	V19= (V17)+((V11)*(3));
	V20= V17;
	V21= V10;
L1630:
	if(!((V20)>=(V19))){
	goto L1631;}
	goto L1625;
L1631:
	{register int V23;                        /*  PIXEL           */
	V23= ((V3))->fixa.fixa_self[V16*((V3))->a.a_dims[1]+V21];
	(*LK11)(3,MAKE_FIXNUM(8),MAKE_FIXNUM(16),MAKE_FIXNUM(V23))/*  LDB1*/;
	T0= VALUES(0);
	aset1((V14),(V20)+(0),T0);
	(*LK11)(3,MAKE_FIXNUM(8),MAKE_FIXNUM(8),MAKE_FIXNUM(V23))/*  LDB1*/;
	T0= VALUES(0);
	aset1((V14),(V20)+(1),T0);
	(*LK11)(3,MAKE_FIXNUM(8),MAKE_FIXNUM(0),MAKE_FIXNUM(V23))/*  LDB1*/;
	T0= VALUES(0);
	aset1((V14),(V20)+(2),T0);
	}
	V20= (V20)+(3);
	V21= (V21)+1;
	goto L1630;
	}
L1625:
	V15= MAKE_FIXNUM((fix((V15)))+1);
	V16= (V16)+1;
	V17= (V17)+(V13);
	goto L1621;
	}
	}
	}
}
/*	function definition for WRITE-PIXARRAY-32                     */
static L47(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT49 VLEX49 CLSR49
	{volatile int V10;
	volatile int V11;
	volatile int V12;
	volatile int V13;
	V10= fix(V4);
	V11= fix(V6);
	V12= fix(V7);
	V13= fix(V8);
TTL:
	{volatile object V14;                     /*  BUFFER-BBUF     */
	V14= (V1);
	{volatile int V15;                        /*  H               */
	volatile int V16;                         /*  Y               */
	volatile int V17;                         /*  START           */
	V15= 0;
	V16= fix((V5));
	V17= fix((V2));
L1657:
	if(!((V15)>=(V12))){
	goto L1658;}
	VALUES(0) = Cnil;
	RETURN(1);
L1658:
	{volatile int V19;                        /*  END             */
	volatile int V20;                         /*  I               */
	volatile int V21;                         /*  X               */
	V19= (V17)+((V11)*(4));
	V20= V17;
	V21= V10;
L1666:
	if(!((V20)>=(V19))){
	goto L1667;}
	goto L1661;
L1667:
	{register object V23;                     /*  PIXEL           */
	V23= ((V3))->a.a_self[V16*((V3))->a.a_dims[1]+V21];
	{register object V24;
	register object V25;
	V24= (V14);
	V25= MAKE_FIXNUM((V20)+(0));
	(*LK9)(2,MAKE_FIXNUM(8),MAKE_FIXNUM(24))  /*  BYTE            */;
	(*LK29)(2,VALUES(0),(V23))                /*  LDB             */;
	aset1((V24),fix((V25)),VALUES(0));
	}
	{register object V24;
	register object V25;
	V24= (V14);
	V25= MAKE_FIXNUM((V20)+(1));
	(*LK9)(2,MAKE_FIXNUM(8),MAKE_FIXNUM(16))  /*  BYTE            */;
	(*LK29)(2,VALUES(0),(V23))                /*  LDB             */;
	aset1((V24),fix((V25)),VALUES(0));
	}
	{register object V24;
	register object V25;
	V24= (V14);
	V25= MAKE_FIXNUM((V20)+(2));
	(*LK9)(2,MAKE_FIXNUM(8),MAKE_FIXNUM(8))   /*  BYTE            */;
	(*LK29)(2,VALUES(0),(V23))                /*  LDB             */;
	aset1((V24),fix((V25)),VALUES(0));
	}
	{register object V24;
	register object V25;
	V24= (V14);
	V25= MAKE_FIXNUM((V20)+(2));
	(*LK9)(2,MAKE_FIXNUM(8),MAKE_FIXNUM(0))   /*  BYTE            */;
	(*LK29)(2,VALUES(0),(V23))                /*  LDB             */;
	aset1((V24),fix((V25)),VALUES(0));
	}
	}
	V20= (V20)+(4);
	V21= (V21)+1;
	goto L1666;
	}
L1661:
	V15= (V15)+1;
	V16= (V16)+1;
	V17= (V17)+(V13);
	goto L1657;
	}
	}
	}
}
/*	function definition for WRITE-PIXARRAY-INTERNAL               */
static L48(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9, object V10, object V11, object V12, object V13, object V14, object V15, object V16)
{ VT50 VLEX50 CLSR50
	{volatile int V17;
	volatile int V18;
	volatile int V19;
	volatile int V20;
	volatile int V21;
	volatile int V22;
	volatile int V23;
	V17= fix(V2);
	V18= fix(V4);
	V19= fix(V5);
	V20= fix(V6);
	V21= fix(V7);
	V22= fix(V8);
	V23= fix(V9);
TTL:
	{ int V24;
	volatile object V25;                      /*  IMAGE-SWAP-FUNCTION*/
	volatile object V26;                      /*  IMAGE-SWAP-LSB-FIRST-P*/
	V24=L28(7,MAKE_FIXNUM(V23),(V11),(V12),(V13),(V14),(V15),(V16))/*  IMAGE-SWAP-FUNCTION*/;
	if (V24--==0) goto L1704;
	V25= VALUES(0);
	if (V24--==0) goto L1705;
	V26= VALUES(1);
	goto L1706;
L1704:
	V25= Cnil;
L1705:
	V26= Cnil;
L1706:
	if(!(((V25))==(VV[119]))){
	goto L1708;}
	RETURN(funcall(10,(V10),(V1),MAKE_FIXNUM(V17),(V3),MAKE_FIXNUM(V18),MAKE_FIXNUM(V19),MAKE_FIXNUM(V20),MAKE_FIXNUM(V21),MAKE_FIXNUM(V22),MAKE_FIXNUM(V23)));
L1708:
	{volatile object V27;                     /*  .REPLY-BUFFER.  */
	(*LK12)(1,MAKE_FIXNUM((V21)*(V22)))       /*  ALLOCATE-REPLY-BUFFER*/;
	V27= VALUES(0);
	{ int V28; volatile bool unwinding = FALSE;
	if ((V28=frs_push(FRS_PROTECT,Cnil))) {
	V28--; unwinding = TRUE;} else {
	{object V29;                              /*  BUF             */
	V29= ((V27))->in.in_slots[1];
	{object V30;                              /*  BUF             */
	funcall(10,(V10),(V29),MAKE_FIXNUM(0),(V3),MAKE_FIXNUM(V18),MAKE_FIXNUM(V19),MAKE_FIXNUM(V20),MAKE_FIXNUM(V21),MAKE_FIXNUM(V22),MAKE_FIXNUM(V23));
	T0= symbol_function((V25));
	Lceiling(2,MAKE_FIXNUM((V20)*(V23)),MAKE_FIXNUM(8))/*  CEILING*/;
	V28=funcall(10,T0,(V29),(V1),MAKE_FIXNUM(0),MAKE_FIXNUM(V17),VALUES(0),MAKE_FIXNUM(V22),MAKE_FIXNUM(V22),MAKE_FIXNUM(V21),(V26));
	}
	}
	}
	frs_pop();
	MV_SAVE(V28);
	(*LK13)(1,(V27))                          /*  DEALLOCATE-REPLY-BUFFER*/;
	MV_RESTORE(V28);
	if (unwinding) unwind(nlj_fr,nlj_tag,V28+1);
	else {
	RETURN(V28);}}
	}}
	}
}
/*	function definition for WRITE-PIXARRAY                        */
static L49(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9, object V10, object V11, object V12)
{ VT51 VLEX51 CLSR51
	{int V13;
	int V14;
	int V15;
	int V16;
	int V17;
	int V18;
	int V19;
	int V20;
	V13= fix(V2);
	V14= fix(V4);
	V15= fix(V5);
	V16= fix(V6);
	V17= fix(V7);
	V18= fix(V8);
	V19= fix(V9);
	V20= fix(V10);
TTL:
	(*LK30)(12,(V1),MAKE_FIXNUM(V13),(V3),MAKE_FIXNUM(V14),MAKE_FIXNUM(V15),MAKE_FIXNUM(V16),MAKE_FIXNUM(V17),MAKE_FIXNUM(V18),MAKE_FIXNUM(V19),MAKE_FIXNUM(V20),(V11),(V12))/*  FAST-WRITE-PIXARRAY*/;
	if(VALUES(0)!=Cnil){
	goto L1718;}
	if(!eql(MAKE_FIXNUM(V19),VV[11]))goto L1721;
	VALUES(0) = (VV[259]->s.s_gfdef);
	goto L1720;
L1721:
	if(!eql(MAKE_FIXNUM(V19),VV[120]))goto L1722;
	VALUES(0) = (VV[260]->s.s_gfdef);
	goto L1720;
L1722:
	if(!eql(MAKE_FIXNUM(V19),VV[116]))goto L1723;
	VALUES(0) = (VV[261]->s.s_gfdef);
	goto L1720;
L1723:
	if(!eql(MAKE_FIXNUM(V19),VV[115]))goto L1724;
	VALUES(0) = (VV[262]->s.s_gfdef);
	goto L1720;
L1724:
	if(!eql(MAKE_FIXNUM(V19),VV[123]))goto L1725;
	VALUES(0) = (VV[263]->s.s_gfdef);
	goto L1720;
L1725:
	if(!eql(MAKE_FIXNUM(V19),VV[114]))goto L1726;
	VALUES(0) = (VV[264]->s.s_gfdef);
	goto L1720;
L1726:
	FEerror("The ECASE key value ~s is illegal.",1,MAKE_FIXNUM(V19));
L1720:
	RETURN(L48(16,(V1),MAKE_FIXNUM(V13),(V3),MAKE_FIXNUM(V14),MAKE_FIXNUM(V15),MAKE_FIXNUM(V16),MAKE_FIXNUM(V17),MAKE_FIXNUM(V18),MAKE_FIXNUM(V19),VALUES(0),MAKE_FIXNUM(32),Cnil,Cnil,MAKE_FIXNUM(V20),(V11),(V12))/*  WRITE-PIXARRAY-INTERNAL*/);
L1718:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-XY-FORMAT-IMAGE-X-DATA          */
static L50(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9, object V10, object V11, object V12, object V13, object V14, object V15, object V16)
{ VT52 VLEX52 CLSR52
	bds_check;
	{volatile int V17;
	volatile int V18;
	volatile int V19;
	volatile int V20;
	volatile int V21;
	volatile int V22;
	volatile int V23;
	volatile int V24;
	volatile int V25;
	volatile int V26;
	V17= fix(V3);
	V18= fix(V4);
	V19= fix(V5);
	V20= fix(V6);
	V21= fix(V7);
	V22= fix(V8);
	V23= fix(V9);
	V24= fix(V10);
	V25= fix(V11);
	V26= fix(V14);
TTL:
	bds_bind(VV[42],MAKE_FIXNUM(4));          /*  *PRINT-LEVEL*   */
	bds_bind(VV[127],MAKE_FIXNUM(4));         /*  *PRINT-LENGTH*  */
L1729:
	if(!(((V19>=0&&8>0?(V19)%(8):imod(V19,8)))==0)){
	goto L1730;}
	bds_unwind1;
	bds_unwind1;
	goto L1727;
L1730:
	Lcerror(3,VV[128],VV[129],VV[169])        /*  CERROR          */;
	Lformat(2,(VV[131]->s.s_dbind),VV[132])   /*  FORMAT          */;
	goto L1729;
L1727:
	{ int V27;
	volatile object V28;                      /*  IMAGE-SWAP-FUNCTION*/
	volatile object V29;                      /*  IMAGE-SWAP-LSB-FIRST-P*/
	V27=L28(7,MAKE_FIXNUM(1),MAKE_FIXNUM(V25),(V12),(V13),MAKE_FIXNUM(V26),(V15),(V16))/*  IMAGE-SWAP-FUNCTION*/;
	if (V27--==0) goto L1738;
	V28= VALUES(0);
	if (V27--==0) goto L1739;
	V29= VALUES(1);
	goto L1740;
L1738:
	V28= Cnil;
L1739:
	V29= Cnil;
L1740:
	{volatile int V30;                        /*  X-MOD-UNIT      */
	V30= (V19>=0&&V25>0?(V19)%(V25):imod(V19,V25));
	if(!((V30)>0)){
	goto L1743;}
	if(((V12))==((V13))){
	goto L1743;}
	{volatile int V31;                        /*  TEMP-WIDTH      */
	volatile object V32;                      /*  TEMP-BYTES-PER-LINE*/
	volatile object V33;                      /*  TEMP-PADDED-BITS-PER-LINE*/
	volatile int V34;                         /*  TEMP-PADDED-BYTES-PER-LINE*/
	V31= (V21)+(V30);
	Lceiling(2,MAKE_FIXNUM(V31),MAKE_FIXNUM(8))/*  CEILING        */;
	V32= VALUES(0);
	Lceiling(2,MAKE_FIXNUM(V31),MAKE_FIXNUM(V25))/*  CEILING      */;
	V33= MAKE_FIXNUM((fix(VALUES(0)))*(V25));
	Lceiling(2,(V33),MAKE_FIXNUM(8))          /*  CEILING         */;
	V34= fix(VALUES(0));
	{volatile object V35;                     /*  .REPLY-BUFFER.  */
	(*LK12)(1,MAKE_FIXNUM((V22)*(V34)))       /*  ALLOCATE-REPLY-BUFFER*/;
	V35= VALUES(0);
	{ int V36; volatile bool unwinding = FALSE;
	if ((V36=frs_push(FRS_PROTECT,Cnil))) {
	V36--; unwinding = TRUE;} else {
	{object V37;                              /*  BUF             */
	V37= ((V35))->in.in_slots[1];
	{object V38;                              /*  BUF             */
	T0= symbol_function((V28));
	{int V39= (V19)-(V30);
	funcall(10,T0,(V1),(V37),MAKE_FIXNUM(((V17)+((V20)*(V23)))+((V39>=0&&8>0?(V39)/(8):ifloor(V39,8)))),MAKE_FIXNUM(0),(V32),MAKE_FIXNUM(V23),MAKE_FIXNUM(V34),MAKE_FIXNUM(V22),(V29));}
	V36=L50(16,(V37),(V2),MAKE_FIXNUM(0),MAKE_FIXNUM(V18),MAKE_FIXNUM(V30),MAKE_FIXNUM(0),MAKE_FIXNUM(V21),MAKE_FIXNUM(V22),MAKE_FIXNUM(V34),MAKE_FIXNUM(V24),MAKE_FIXNUM(V25),(V15),(V15),MAKE_FIXNUM(V26),(V15),(V16))/*  WRITE-XY-FORMAT-IMAGE-X-DATA*/;
	}
	}
	}
	frs_pop();
	MV_SAVE(V36);
	(*LK13)(1,(V35))                          /*  DEALLOCATE-REPLY-BUFFER*/;
	MV_RESTORE(V36);
	if (unwinding) unwind(nlj_fr,nlj_tag,V36+1);
	else {
	RETURN(V36);}}
	}
	}
L1743:
	T0= symbol_function((V28));
	{int V37= ((V17)+((V20)*(V23)))+((V19>=0&&8>0?(V19)/(8):ifloor(V19,8)));
	Lceiling(2,MAKE_FIXNUM(V21),MAKE_FIXNUM(8))/*  CEILING        */;
	RETURN(funcall(10,T0,(V1),(V2),MAKE_FIXNUM(V37),MAKE_FIXNUM(V18),VALUES(0),MAKE_FIXNUM(V23),MAKE_FIXNUM(V24),MAKE_FIXNUM(V22),(V29)));}
	}}
	}
}
/*	function definition for WRITE-XY-FORMAT-IMAGE-X               */
static L51(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9, object V10)
{ VT53 VLEX53 CLSR53
	{volatile int V11;
	volatile int V12;
	volatile int V13;
	volatile int V14;
	volatile int V15;
	volatile int V16;
	V11= fix(V3);
	V12= fix(V4);
	V13= fix(V5);
	V14= fix(V6);
	V15= fix(V7);
	V16= fix(V8);
TTL:
	{volatile object V17;
	volatile int V18;                         /*  PLANE           */
	(*LK3)(1,(V2))                            /*  IMAGE-DEPTH     */;
	V17= VALUES(0);
	V18= 0;
L1763:
	if(!(number_compare(MAKE_FIXNUM(V18),(V17))>=0)){
	goto L1764;}
	VALUES(0) = Cnil;
	RETURN(1);
L1764:
	{volatile int V20;                        /*  DATA-START      */
	volatile int V21;                         /*  SRC-Y           */
	volatile int V22;                         /*  HEIGHT          */
	(*LK2)(1,(V2))                            /*  IMAGE-HEIGHT    */;
	V20= ((V18)*(fix(VALUES(0))))*(fix(((V2))->in.in_slots[5]));
	V21= V12;
	V22= V14;
L1773:
	if(!((V22)==0)){
	goto L1775;}
	goto L1767;
L1775:
	{register int V23;                        /*  NLINES          */
	{int V24= (fix(((V1))->in.in_slots[2]))-(fix(((V1))->in.in_slots[6]));
	{int V25= (V24>=0&&V15>0?(V24)/(V15):ifloor(V24,V15));
	V23= (V25)<=(V22)?V25:V22;}}
	if(!((V23)>0)){
	goto L1778;}
	L50(16,((V2))->in.in_slots[9],((V1))->in.in_slots[7],MAKE_FIXNUM(V20),((V1))->in.in_slots[6],MAKE_FIXNUM(V11),MAKE_FIXNUM(V21),MAKE_FIXNUM(V13),MAKE_FIXNUM(V23),((V2))->in.in_slots[5],MAKE_FIXNUM(V15),((V2))->in.in_slots[10],((V2))->in.in_slots[8],((V2))->in.in_slots[7],MAKE_FIXNUM(V16),(V9),(V10))/*  WRITE-XY-FORMAT-IMAGE-X-DATA*/;
	{register object V24;
	register object V25;
	V24= (V1);
	V25= MAKE_FIXNUM((fix(((V24))->in.in_slots[6]))+((V23)*(V15)));
	((V24))->in.in_slots[6]= (V25);
	}
	V21= (V21)+(V23);
	V22= (V22)-(V23);
	VALUES(0) = MAKE_FIXNUM(V22);
	if(!((fix(VALUES(0)))==0)){
	goto L1778;}
	goto L1767;
	}
L1778:
	(*LK18)(1,(V1))                           /*  BUFFER-FLUSH    */;
	goto L1773;
	}
L1767:
	V18= (V18)+1;
	goto L1763;
	}
	}
}
/*	function definition for WRITE-Z-FORMAT-IMAGE-X-DATA           */
static L52(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9, object V10, object V11, object V12, object V13, object V14, object V15, object V16, object V17)
{ VT54 VLEX54 CLSR54
	{volatile int V18;
	volatile int V19;
	volatile int V20;
	volatile int V21;
	volatile int V22;
	volatile int V23;
	volatile int V24;
	volatile int V25;
	volatile int V26;
	volatile int V27;
	volatile int V28;
	V18= fix(V3);
	V19= fix(V4);
	V20= fix(V5);
	V21= fix(V6);
	V22= fix(V7);
	V23= fix(V8);
	V24= fix(V9);
	V25= fix(V10);
	V26= fix(V11);
	V27= fix(V12);
	V28= fix(V15);
TTL:
	if(!((V26)==(1))){
	goto L1797;}
	RETURN(L50(16,(V1),(V2),MAKE_FIXNUM(V18),MAKE_FIXNUM(V19),MAKE_FIXNUM(V20),MAKE_FIXNUM(V21),MAKE_FIXNUM(V22),MAKE_FIXNUM(V23),MAKE_FIXNUM(V24),MAKE_FIXNUM(V25),MAKE_FIXNUM(V27),(V13),(V14),MAKE_FIXNUM(V28),(V16),(V17))/*  WRITE-XY-FORMAT-IMAGE-X-DATA*/);
L1797:
	{volatile int V29;                        /*  SRCOFF          */
	volatile int V30;                         /*  SRCLEN          */
	{int V31= (V20)*(V26);
	V29= ((V18)+((V21)*(V24)))+((V31>=0&&8>0?(V31)/(8):ifloor(V31,8)));}
	Lceiling(2,MAKE_FIXNUM((V22)*(V26)),MAKE_FIXNUM(8))/*  CEILING*/;
	V30= fix(VALUES(0));
	if(!((V26)==(4))){
	goto L1802;}
	Loddp(1,MAKE_FIXNUM(V20))                 /*  ODDP            */;
	if(VALUES(0)==Cnil){
	goto L1802;}
	{volatile object V31;                     /*  .REPLY-BUFFER.  */
	(*LK12)(1,MAKE_FIXNUM((V23)*(V25)))       /*  ALLOCATE-REPLY-BUFFER*/;
	V31= VALUES(0);
	{ int V32; volatile bool unwinding = FALSE;
	if ((V32=frs_push(FRS_PROTECT,Cnil))) {
	V32--; unwinding = TRUE;} else {
	{object V33;                              /*  BUF             */
	V33= ((V31))->in.in_slots[1];
	{object V34;                              /*  BUF             */
	L23(9,(V1),(V33),MAKE_FIXNUM(V29),MAKE_FIXNUM(0),MAKE_FIXNUM(V30),MAKE_FIXNUM(V24),MAKE_FIXNUM(V25),MAKE_FIXNUM(V23),Cnil)/*  IMAGE-SWAP-NIBBLES-LEFT*/;
	V32=L52(17,(V33),(V2),MAKE_FIXNUM(0),MAKE_FIXNUM(V19),MAKE_FIXNUM(0),MAKE_FIXNUM(0),MAKE_FIXNUM(V22),MAKE_FIXNUM(V23),MAKE_FIXNUM(V25),MAKE_FIXNUM(V25),MAKE_FIXNUM(V26),MAKE_FIXNUM(V27),(V13),(V14),MAKE_FIXNUM(V28),(V16),(V17))/*  WRITE-Z-FORMAT-IMAGE-X-DATA*/;
	}
	}
	}
	frs_pop();
	MV_SAVE(V32);
	(*LK13)(1,(V31))                          /*  DEALLOCATE-REPLY-BUFFER*/;
	MV_RESTORE(V32);
	if (unwinding) unwind(nlj_fr,nlj_tag,V32+1);
	else {
	RETURN(V32);}}
	}
L1802:
	{ int V33;
	volatile object V34;                      /*  IMAGE-SWAP-FUNCTION*/
	volatile object V35;                      /*  IMAGE-SWAP-LSB-FIRST-P*/
	V33=L28(7,MAKE_FIXNUM(V26),MAKE_FIXNUM(V27),(V13),(V14),MAKE_FIXNUM(V28),(V16),(V17))/*  IMAGE-SWAP-FUNCTION*/;
	if (V33--==0) goto L1812;
	V34= VALUES(0);
	if (V33--==0) goto L1813;
	V35= VALUES(1);
	goto L1814;
L1812:
	V34= Cnil;
L1813:
	V35= Cnil;
L1814:
	T0= symbol_function((V34));
	RETURN(funcall(10,T0,(V1),(V2),MAKE_FIXNUM(V29),MAKE_FIXNUM(V19),MAKE_FIXNUM(V30),MAKE_FIXNUM(V24),MAKE_FIXNUM(V25),MAKE_FIXNUM(V23),(V35)));}
	}
	}
}
/*	function definition for WRITE-Z-FORMAT-IMAGE-X                */
static L53(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9, object V10)
{ VT55 VLEX55 CLSR55
	{volatile int V11;
	volatile int V12;
	volatile int V13;
	volatile int V14;
	volatile int V15;
	V11= fix(V3);
	V12= fix(V4);
	V13= fix(V5);
	V14= fix(V6);
	V15= fix(V7);
TTL:
L1817:
	if(!((V14)==0)){
	goto L1819;}
	VALUES(0) = Cnil;
	RETURN(1);
L1819:
	{register int V16;                        /*  NLINES          */
	{int V17= (fix(((V1))->in.in_slots[2]))-(fix(((V1))->in.in_slots[6]));
	{int V18= (V17>=0&&V15>0?(V17)/(V15):ifloor(V17,V15));
	V16= (V18)<=(V14)?V18:V14;}}
	if(!((V16)>0)){
	goto L1822;}
	L52(17,((V2))->in.in_slots[9],((V1))->in.in_slots[7],MAKE_FIXNUM(0),((V1))->in.in_slots[6],MAKE_FIXNUM(V11),MAKE_FIXNUM(V12),MAKE_FIXNUM(V13),MAKE_FIXNUM(V16),((V2))->in.in_slots[5],MAKE_FIXNUM(V15),((V2))->in.in_slots[6],((V2))->in.in_slots[10],((V2))->in.in_slots[8],((V2))->in.in_slots[7],(V8),(V9),(V10))/*  WRITE-Z-FORMAT-IMAGE-X-DATA*/;
	{register object V17;
	register object V18;
	V17= (V1);
	V18= MAKE_FIXNUM((fix(((V17))->in.in_slots[6]))+((V16)*(V15)));
	((V17))->in.in_slots[6]= (V18);
	}
	V12= (V12)+(V16);
	V14= (V14)-(V16);
	VALUES(0) = MAKE_FIXNUM(V14);
	if(!((fix(VALUES(0)))==0)){
	goto L1822;}
	VALUES(0) = Cnil;
	RETURN(1);
	}
L1822:
	(*LK18)(1,(V1))                           /*  BUFFER-FLUSH    */;
	goto L1817;
	}
}
/*	function definition for WRITE-IMAGE-XY                        */
static L54(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9, object V10)
{ VT56 VLEX56 CLSR56
	{volatile int V11;
	volatile int V12;
	volatile int V13;
	volatile int V14;
	volatile int V15;
	volatile int V16;
	V11= fix(V3);
	V12= fix(V4);
	V13= fix(V5);
	V14= fix(V6);
	V15= fix(V7);
	V16= fix(V8);
TTL:
	{volatile object V17;
	volatile object V18;                      /*  BITMAP          */
	V17= ((V2))->in.in_slots[4];
	V18= Cnil;
L1840:
	if(!((V17)==Cnil)){
	goto L1841;}
	VALUES(0) = Cnil;
	RETURN(1);
L1841:
	V18= CAR((V17));
	{volatile int V20;                        /*  SRC-Y           */
	volatile int V21;                         /*  HEIGHT          */
	V20= V12;
	V21= V14;
L1850:
	{register int V22;                        /*  NLINES          */
	{int V23= (fix(((V1))->in.in_slots[2]))-(fix(((V1))->in.in_slots[6]));
	{int V24= (V23>=0&&V15>0?(V23)/(V15):ifloor(V23,V15));
	V22= (V24)<=(V21)?V24:V21;}}
	if(!((V22)>0)){
	goto L1852;}
	L49(12,((V1))->in.in_slots[7],((V1))->in.in_slots[6],(V18),MAKE_FIXNUM(V11),MAKE_FIXNUM(V20),MAKE_FIXNUM(V13),MAKE_FIXNUM(V22),MAKE_FIXNUM(V15),MAKE_FIXNUM(1),MAKE_FIXNUM(V16),(V9),(V10))/*  WRITE-PIXARRAY*/;
	{register object V23;
	register object V24;
	V23= (V1);
	V24= MAKE_FIXNUM((fix(((V23))->in.in_slots[6]))+((V22)*(V15)));
	((V23))->in.in_slots[6]= (V24);
	}
	V20= (V20)+(V22);
	V21= (V21)-(V22);
	VALUES(0) = MAKE_FIXNUM(V21);
	if(!((fix(VALUES(0)))==0)){
	goto L1852;}
	goto L1846;
	}
L1852:
	(*LK18)(1,(V1))                           /*  BUFFER-FLUSH    */;
	goto L1850;
	}
L1846:
	V17= CDR((V17));
	goto L1840;
	}
	}
}
/*	function definition for WRITE-IMAGE-Z                         */
static L55(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9, object V10)
{ VT57 VLEX57 CLSR57
	{volatile int V11;
	volatile int V12;
	volatile int V13;
	volatile int V14;
	volatile int V15;
	volatile int V16;
	V11= fix(V3);
	V12= fix(V4);
	V13= fix(V5);
	V14= fix(V6);
	V15= fix(V7);
	V16= fix(V8);
TTL:
L1871:
	{register int V17;                        /*  BITS-PER-PIXEL  */
	register int V18;                         /*  NLINES          */
	V17= fix(((V2))->in.in_slots[4]);
	{int V19= (fix(((V1))->in.in_slots[2]))-(fix(((V1))->in.in_slots[6]));
	{int V20= (V19>=0&&V15>0?(V19)/(V15):ifloor(V19,V15));
	V18= (V20)<=(V14)?V20:V14;}}
	if(!((V18)>0)){
	goto L1873;}
	L49(12,((V1))->in.in_slots[7],((V1))->in.in_slots[6],((V2))->in.in_slots[5],MAKE_FIXNUM(V11),MAKE_FIXNUM(V12),MAKE_FIXNUM(V13),MAKE_FIXNUM(V18),MAKE_FIXNUM(V15),MAKE_FIXNUM(V17),MAKE_FIXNUM(V16),(V9),(V10))/*  WRITE-PIXARRAY*/;
	{register object V19;
	register object V20;
	V19= (V1);
	V20= MAKE_FIXNUM((fix(((V19))->in.in_slots[6]))+((V18)*(V15)));
	((V19))->in.in_slots[6]= (V20);
	}
	V12= (V12)+(V18);
	V14= (V14)-(V18);
	VALUES(0) = MAKE_FIXNUM(V14);
	if(!((fix(VALUES(0)))==0)){
	goto L1873;}
	VALUES(0) = Cnil;
	RETURN(1);
	}
L1873:
	(*LK18)(1,(V1))                           /*  BUFFER-FLUSH    */;
	goto L1871;
	}
}
/*	function definition for PUT-IMAGE                             */
static L56(int narg, object V1, object V2, object V3, ...)
{ VT58 VLEX58 CLSR58
	{volatile int V4;
	volatile int V5;
	volatile int V6;
	volatile object V7;
	volatile object V8;
	volatile object V9;
	volatile object V10;
	va_list args; va_start(args, V3);
	narg -=3;
	{ object keyvars[14];
	parse_key(narg,args,7,L56keys,keyvars,OBJNULL,FALSE);
	if(keyvars[7]==Cnil){
	V4= 0;
	}else{
	V4= fix(keyvars[0]);}
	if(keyvars[8]==Cnil){
	V5= 0;
	}else{
	V5= fix(keyvars[1]);}
	if(keyvars[9]==Cnil){
	(*LK5)(3,VV[74],VV[75],VV[149])           /*  X-ERROR         */;
	V6= fix((VV[77]->s.s_dbind));
	}else{
	V6= fix(keyvars[2]);}
	if(keyvars[10]==Cnil){
	(*LK5)(3,VV[74],VV[75],VV[150])           /*  X-ERROR         */;
	V7= (VV[77]->s.s_dbind);
	}else{
	V7= keyvars[3];}
	V8= keyvars[4];
	V9= keyvars[5];
	V10= keyvars[6];
	}
	{volatile object V11;                     /*  FORMAT          */
	volatile int V12;                         /*  SRC-X           */
	volatile int V13;                         /*  IMAGE-WIDTH     */
	volatile int V14;                         /*  IMAGE-HEIGHT    */
	volatile int V15;                         /*  WIDTH           */
	volatile int V16;                         /*  HEIGHT          */
	volatile int V17;                         /*  DEPTH           */
	volatile object V18;                      /*  DISPLAY         */
	volatile object V19;                      /*  BITMAP-FORMAT   */
	volatile int V20;                         /*  UNIT            */
	volatile object V21;                      /*  BYTE-LSB-FIRST-P*/
	volatile object V22;                      /*  BIT-LSB-FIRST-P */
	{object V23;
	V23= (V3);
	(*LK6)(2,(V23),VV[35])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1897;}
	V11= ((V3))->in.in_slots[4];
	goto L1895;
L1897:
	(*LK6)(2,(V23),VV[51])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1900;}
	V11= VV[78];
	goto L1895;
L1900:
	(*LK6)(2,(V23),VV[62])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1903;}
	V11= VV[48];
	goto L1895;
L1903:
	(*LK7)(3,VV[13],(V23),VV[170])            /*  TYPECASE-ERROR-STRING*/;
	Lerror(1,VALUES(0))                       /*  ERROR           */;
	V11= VALUES(0);
	}
L1895:
	(*LK31)(1,(V3))                           /*  IMAGE-X-P       */;
	if(VALUES(0)==Cnil){
	goto L1908;}
	V12= (V4)+(fix(((V3))->in.in_slots[12]));
	goto L1906;
L1908:
	V12= V4;
L1906:
	(*LK1)(1,(V3))                            /*  IMAGE-WIDTH     */;
	V13= fix(VALUES(0));
	(*LK2)(1,(V3))                            /*  IMAGE-HEIGHT    */;
	V14= fix(VALUES(0));
	if((V8)!=Cnil){
	T0= (V8);
	goto L1913;}
	T0= MAKE_FIXNUM(V13);
L1913:
	{object V23= T0;
	{object V24= MAKE_FIXNUM((V13)-(V12));
	V15= fix((number_compare(V23,V24)<=0?V23:V24));}}
	if((V9)!=Cnil){
	T0= (V9);
	goto L1915;}
	T0= MAKE_FIXNUM(V14);
L1915:
	{object V23= T0;
	{object V24= MAKE_FIXNUM((V14)-(V5));
	V16= fix((number_compare(V23,V24)<=0?V23:V24));}}
	(*LK3)(1,(V3))                            /*  IMAGE-DEPTH     */;
	V17= fix(VALUES(0));
	V18= ((V1))->in.in_slots[1];
	V19= ((V18))->in.in_slots[44];
	V20= fix(((V19))->in.in_slots[0]);
	V21= ((V18))->in.in_slots[43];
	V22= ((V19))->in.in_slots[2];
	if(((V10))==Cnil){
	goto L1922;}
	if((V17)==(1)){
	goto L1922;}
	Lerror(1,VV[171])                         /*  ERROR           */;
L1922:
	(*LK1)(1,(V3))                            /*  IMAGE-WIDTH     */;
	Lmonotonically_nondecreasing(3,MAKE_FIXNUM(0),MAKE_FIXNUM(V12),MAKE_FIXNUM((fix(VALUES(0)))-1))/*  <=*/;
	if(VALUES(0)!=Cnil){
	goto L1927;}
	Lerror(1,VV[172])                         /*  ERROR           */;
L1927:
	(*LK2)(1,(V3))                            /*  IMAGE-HEIGHT    */;
	Lmonotonically_nondecreasing(3,MAKE_FIXNUM(0),MAKE_FIXNUM(V5),MAKE_FIXNUM((fix(VALUES(0)))-1))/*  <=*/;
	if(VALUES(0)!=Cnil){
	goto L1931;}
	Lerror(1,VV[173])                         /*  ERROR           */;
L1931:
	if(!((V15)>(0))){
	goto L1936;}
	if(!((V16)>(0))){
	goto L1936;}
	{ int V23;
	volatile int V24;                         /*  PAD             */
	volatile object V25;                      /*  BITS-PER-PIXEL  */
	if(((V11)!= VV[177])
	&& ((V11)!= VV[78]))goto L1941;
	VALUES(1) = MAKE_FIXNUM(1);
	VALUES(0) = ((V19))->in.in_slots[1];
	V23=2;
	goto L1940;
L1941:
	if(((V11)!= VV[48]))goto L1942;
	if(!((V17)==(1))){
	goto L1944;}
	VALUES(1) = MAKE_FIXNUM(1);
	VALUES(0) = ((V19))->in.in_slots[1];
	V23=2;
	goto L1940;
L1944:
	{object V26;                              /*  PIXMAP-FORMAT   */
	T0= ((V18))->in.in_slots[45];
	VALUES(0) = (VV[346]->s.s_gfdef);
	(*LK27)(4,MAKE_FIXNUM(V17),T0,VV[166],VALUES(0))/*  FIND      */;
	V26= VALUES(0);
	if(((V26))!=Cnil){
	goto L1949;}
	Lerror(2,VV[174],(V3))                    /*  ERROR           */;
L1949:
	{object V27;
	(*LK6)(2,(V3),VV[62])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1957;}
	VALUES(0) = ((V3))->in.in_slots[4];
	goto L1955;
L1957:
	(*LK6)(2,(V3),VV[35])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1960;}
	VALUES(0) = ((V3))->in.in_slots[6];
	goto L1955;
L1960:
	VALUES(0) = Cnil;
	}
L1955:
	if(number_compare(VALUES(0),((V26))->in.in_slots[1])==0){
	goto L1952;}
	Lerror(2,VV[175],(V3))                    /*  ERROR           */;
L1952:
	VALUES(1) = ((V26))->in.in_slots[1];
	VALUES(0) = ((V26))->in.in_slots[2];
	V23=2;
	goto L1940;
	}
L1942:
	FEerror("The ECASE key value ~s is illegal.",1,(V11));
L1940:
	if (V23--==0) goto L1962;
	V24= fix(VALUES(0));
	if (V23--==0) goto L1963;
	V25= VALUES(1);
	goto L1964;
L1962:
	V24= 0;
L1963:
	V25= MAKE_FIXNUM(0);
L1964:
	{volatile int V26;                        /*  LEFT-PAD        */
	volatile int V27;                         /*  LEFT-PADDED-SRC-X*/
	volatile int V28;                         /*  LEFT-PADDED-WIDTH*/
	volatile object V29;                      /*  BITS-PER-LINE   */
	volatile object V30;                      /*  PADDED-BITS-PER-LINE*/
	volatile int V31;                         /*  PADDED-BYTES-PER-LINE*/
	volatile int V32;                         /*  REQUEST-BYTES-PER-LINE*/
	volatile object V33;                      /*  MAX-BYTES-PER-REQUEST*/
	volatile int V34;                         /*  MAX-REQUEST-HEIGHT*/
	if(((V11))==(VV[78])){
	goto L1966;}
	if(!((V17)==(1))){
	goto L1967;}
L1966:
	{int V35= (V24)<=(32)?V24:32;
	V26= (V12>=0&&V35>0?(V12)%(V35):imod(V12,V35));
	goto L1965;}
L1967:
	V26= 0;
L1965:
	V27= (V12)-(V26);
	V28= (V15)+(V26);
	V29= MAKE_FIXNUM((V28)*(fix((V25))));
	Lceiling(2,(V29),MAKE_FIXNUM(V24))        /*  CEILING         */;
	V30= MAKE_FIXNUM((fix(VALUES(0)))*(V24));
	Lceiling(2,(V30),MAKE_FIXNUM(8))          /*  CEILING         */;
	V31= fix(VALUES(0));
	if(((V11)!= VV[177])
	&& ((V11)!= VV[78]))goto L1978;
	V32= (V31)*(V17);
	goto L1977;
L1978:
	if(((V11)!= VV[48]))goto L1979;
	V32= V31;
	goto L1977;
L1979:
	FEerror("The ECASE key value ~s is illegal.",1,(V11));
L1977:
	V33= MAKE_FIXNUM(((fix(((V18))->in.in_slots[38]))-(6))*(4));
	V34= (fix((V33))>=0&&V32>0?(fix((V33)))/(V32):ifloor(fix((V33)),V32));
	if(!((V34)==0)){
	goto L1982;}
	Lerror(1,VV[176])                         /*  ERROR           */;
L1982:
	(*LK32)(2,(V18),MAKE_FIXNUM(V31))         /*  BUFFER-ENSURE-SIZE*/;
	{volatile int V35;                        /*  REQUEST-SRC-Y   */
	volatile object V36;                      /*  REQUEST-Y       */
	volatile int V37;                         /*  HEIGHT-REMAINING*/
	volatile int V38;                         /*  REQUEST-HEIGHT  */
	V35= V5;
	V36= (V7);
	V37= V16;
	V38= (V37)<=(V34)?V37:V34;
L1991:
	if(!((V37)<=(0))){
	goto L1992;}
	VALUES(0) = Cnil;
	RETURN(1);
L1992:
	{int V40;                                 /*  REQUEST-BYTES   */
	int V41;                                  /*  REQUEST-WORDS   */
	object V42;                               /*  REQUEST-LENGTH  */
	V40= (V32)*(V38);
	Lceiling(2,MAKE_FIXNUM(V40),MAKE_FIXNUM(4))/*  CEILING        */;
	V41= fix(VALUES(0));
	V42= MAKE_FIXNUM((V41)+(6));
	{register object V43;                     /*  .DISPLAY.       */
	V43= (V18);
	if((((V43))->in.in_slots[10])==Cnil){
	goto L1999;}
	(*LK5)(3,VV[155],VV[156],(V43))           /*  X-ERROR         */;
L1999:
	(*LK33)(1,(V2))                           /*  FORCE-GCONTEXT-CHANGES-INTERNAL*/;
	{register object V44;                     /*  %BUFFER         */
	V44= (V43);
	if(!(((fix(((V44))->in.in_slots[6]))+(160))>=(fix(((V44))->in.in_slots[2])))){
	goto L2004;}
	(*LK18)(1,(V44))                          /*  BUFFER-FLUSH    */;
L2004:
	{register int V45;                        /*  BUFFER-BOFFSET  */
	register object V46;                      /*  BUFFER-BBUF     */
	V45= fix(((V44))->in.in_slots[6]);
	V46= ((V44))->in.in_slots[7];
	((V43))->in.in_slots[4]= MAKE_FIXNUM(V45);
	(((V46))->ust.ust_self[(V45)+(0)]=(72));
	{object V47;                              /*  .VALUE.         */
	if(((V11))==(VV[177])){
	goto L2015;}
	if(((V10))==Cnil){
	goto L2016;}
L2015:
	V47= VV[177];
	goto L2014;
L2016:
	if(!((V26)>0)){
	goto L2021;}
	V47= VV[78];
	goto L2014;
L2021:
	V47= (V11);
L2014:
	(*LK6)(2,(V47),VV[178])                   /*  TYPEP           */;
	if(VALUES(0)!=Cnil){
	goto L2025;}
	VALUES(0) = Cnil;
	goto L2024;
L2025:
	VALUES(0) = (VV[338]->s.s_gfdef);
	(*LK19)(4,(V47),VV[179],VV[159],VALUES(0))/*  POSITION        */;
	T0= VALUES(0);
	{int V48= ((*(unsigned long *)(((V46))->ust.ust_self+((V45)+(4))))=fix(T0));
	VALUES(0) = MAKE_FIXNUM((((V46))->ust.ust_self[(V45)+(1)]=(V48)));}
L2024:
	if(VALUES(0)==Cnil)goto L2023;
	goto L2013;
L2023:
	(*LK20)(2,(V47),VV[180])                  /*  X-TYPE-ERROR    */;
	}
L2013:
	(*LK21)(1,(V1))                           /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L2031;}
	((*(unsigned long *)(((V46))->ust.ust_self+((V45)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L2029;
L2031:
	(*LK20)(2,(V1),VV[153])                   /*  X-TYPE-ERROR    */;
L2029:
	(*LK34)(1,(V2))                           /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L2035;}
	((*(unsigned long *)(((V46))->ust.ust_self+((V45)+(8))))=fix(((V2))->in.in_slots[0]));
	goto L2033;
L2035:
	(*LK20)(2,(V2),VV[181])                   /*  X-TYPE-ERROR    */;
L2033:
	(*LK6)(2,MAKE_FIXNUM(V15),VV[162])        /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2039;}
	((*(unsigned short *)(((V46))->ust.ust_self+((V45)+(12))))=V15);
	goto L2037;
L2039:
	(*LK20)(2,MAKE_FIXNUM(V15),VV[162])       /*  X-TYPE-ERROR    */;
L2037:
	(*LK6)(2,MAKE_FIXNUM(V38),VV[162])        /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2043;}
	((*(unsigned short *)(((V46))->ust.ust_self+((V45)+(14))))=V38);
	goto L2041;
L2043:
	(*LK20)(2,MAKE_FIXNUM(V38),VV[162])       /*  X-TYPE-ERROR    */;
L2041:
	(*LK6)(2,MAKE_FIXNUM(V6),VV[161])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2047;}
	((*(short *)(((V46))->st.st_self+((V45)+(16))))=V6);
	goto L2045;
L2047:
	(*LK20)(2,MAKE_FIXNUM(V6),VV[161])        /*  X-TYPE-ERROR    */;
L2045:
	(*LK6)(2,(V36),VV[161])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2051;}
	((*(short *)(((V46))->st.st_self+((V45)+(18))))=fix((V36)));
	goto L2049;
L2051:
	(*LK20)(2,(V36),VV[161])                  /*  X-TYPE-ERROR    */;
L2049:
	(*LK6)(2,MAKE_FIXNUM(V26),VV[182])        /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2055;}
	(((V46))->ust.ust_self[(V45)+(20)]=(V26));
	goto L2053;
L2055:
	(*LK20)(2,MAKE_FIXNUM(V26),VV[182])       /*  X-TYPE-ERROR    */;
L2053:
	(*LK6)(2,MAKE_FIXNUM(V17),VV[182])        /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2059;}
	(((V46))->ust.ust_self[(V45)+(21)]=(V17));
	goto L2057;
L2059:
	(*LK20)(2,MAKE_FIXNUM(V17),VV[182])       /*  X-TYPE-ERROR    */;
L2057:
	{int V47;                                 /*  .VALUE.         */
	V47= ((*(unsigned short *)(((V46))->ust.ust_self+((V45)+(2))))=fix((V42)));
	}
	{int V47;                                 /*  .VALUE.         */
	{int V48;                                 /*  .BOFFSET.       */
	V48= (V45)+(24);
	V45= V48;
	VALUES(0) = MAKE_FIXNUM(V45);
	}
	((V18))->in.in_slots[6]= VALUES(0);
	V47= fix(VALUES(0));
	}
	{object V47;                              /*  .VALUE.         */
	{object V48;
	V48= (V3);
	(*LK6)(2,(V48),VV[35])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2072;}
	{object V49= ((V3))->in.in_slots[4];
	if((V49!= VV[177])
	&& (V49!= VV[78]))goto L2074;
	L51(10,(V18),(V3),MAKE_FIXNUM(V27),MAKE_FIXNUM(V35),MAKE_FIXNUM(V28),MAKE_FIXNUM(V38),MAKE_FIXNUM(V31),MAKE_FIXNUM(V20),(V21),(V22))/*  WRITE-XY-FORMAT-IMAGE-X*/;
	V47= VALUES(0);
	goto L2070;
L2074:
	if((V49!= VV[48]))goto L2075;
	L53(10,(V18),(V3),MAKE_FIXNUM(V27),MAKE_FIXNUM(V35),MAKE_FIXNUM(V28),MAKE_FIXNUM(V38),MAKE_FIXNUM(V31),MAKE_FIXNUM(V20),(V21),(V22))/*  WRITE-Z-FORMAT-IMAGE-X*/;
	V47= VALUES(0);
	goto L2070;
L2075:
	FEerror("The ECASE key value ~s is illegal.",1,V49);}
L2072:
	(*LK6)(2,(V48),VV[51])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2077;}
	L54(10,(V18),(V3),MAKE_FIXNUM(V27),MAKE_FIXNUM(V35),MAKE_FIXNUM(V28),MAKE_FIXNUM(V38),MAKE_FIXNUM(V31),MAKE_FIXNUM(V20),(V21),(V22))/*  WRITE-IMAGE-XY*/;
	V47= VALUES(0);
	goto L2070;
L2077:
	(*LK6)(2,(V48),VV[62])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2080;}
	L55(10,(V18),(V3),MAKE_FIXNUM(V27),MAKE_FIXNUM(V35),MAKE_FIXNUM(V28),MAKE_FIXNUM(V38),MAKE_FIXNUM(V31),MAKE_FIXNUM(V20),(V21),(V22))/*  WRITE-IMAGE-Z*/;
	V47= VALUES(0);
	goto L2070;
L2080:
	(*LK7)(3,VV[13],(V48),VV[183])            /*  TYPECASE-ERROR-STRING*/;
	Lerror(1,VALUES(0))                       /*  ERROR           */;
	V47= VALUES(0);
	}
L2070:
	}
	{object V47;                              /*  .VALUE.         */
	(*LK35)(2,(V18),MAKE_FIXNUM(((V41)*(4))-(V40)))/*  BUFFER-PAD-REQUEST*/;
	V47= VALUES(0);
	}
	(*LK22)(1,(V43))                          /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK24)(1,(V43))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	}
	V35= (V35)+(V38);
	V36= MAKE_FIXNUM((fix((V36)))+(V38));
	V37= (V37)-(V38);
	V38= (V37)<=(V34)?V37:V34;
	goto L1991;
	}
	}}
L1936:
	VALUES(0) = Cnil;
	RETURN(1);
	}
	}
}
/*	function definition for XY-FORMAT-IMAGE-X->IMAGE-X            */
static L57(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT59 VLEX59 CLSR59
	{volatile int V6;
	volatile int V7;
	volatile int V8;
	V6= fix(V3);
	V7= fix(V4);
	V8= fix(V5);
TTL:
	{volatile int V9;                         /*  PADDED-X        */
	volatile int V10;                         /*  LEFT-PAD        */
	volatile int V11;                         /*  X               */
	volatile int V12;                         /*  UNIT            */
	volatile object V13;                      /*  BYTE-LSB-FIRST-P*/
	volatile object V14;                      /*  BIT-LSB-FIRST-P */
	volatile int V15;                         /*  PAD             */
	volatile object V16;                      /*  PADDED-WIDTH    */
	volatile int V17;                         /*  PADDED-BYTES-PER-LINE*/
	volatile int V18;                         /*  PADDED-BYTES-PER-PLANE*/
	volatile object V19;                      /*  LENGTH          */
	volatile object V20;                      /*  OBUF            */
	V9= (fix((V2)))+(fix(((V1))->in.in_slots[12]));
	V10= (V9>=0&&8>0?(V9)%(8):imod(V9,8));
	V11= (V9)-(V10);
	V12= fix(((V1))->in.in_slots[10]);
	V13= ((V1))->in.in_slots[8];
	V14= ((V1))->in.in_slots[7];
	V15= fix(((V1))->in.in_slots[11]);
	Lceiling(2,MAKE_FIXNUM((V7)+(V10)),MAKE_FIXNUM(V15))/*  CEILING*/;
	V16= MAKE_FIXNUM((fix(VALUES(0)))*(V15));
	Lceiling(2,(V16),MAKE_FIXNUM(8))          /*  CEILING         */;
	V17= fix(VALUES(0));
	V18= (V17)*(V8);
	(*LK3)(1,(V1))                            /*  IMAGE-DEPTH     */;
	V19= MAKE_FIXNUM((V18)*(fix(VALUES(0))));
	(*LK15)(3,(V19),VV[138],VV[139])          /*  MAKE-ARRAY      */;
	V20= VALUES(0);
	{volatile object V21;
	volatile int V22;                         /*  PLANE           */
	(*LK3)(1,(V1))                            /*  IMAGE-DEPTH     */;
	V21= VALUES(0);
	V22= 0;
L2112:
	if(!(number_compare(MAKE_FIXNUM(V22),(V21))>=0)){
	goto L2113;}
	goto L2108;
L2113:
	{register int V24;                        /*  DATA-START      */
	register int V25;                         /*  OBUF-START      */
	T0= ((V1))->in.in_slots[5];
	(*LK2)(1,(V1))                            /*  IMAGE-HEIGHT    */;
	V24= ((fix(T0))*(fix(VALUES(0))))*(V22);
	V25= (V18)*(V22);
	L50(16,((V1))->in.in_slots[9],(V20),MAKE_FIXNUM(V24),MAKE_FIXNUM(V25),MAKE_FIXNUM(V11),MAKE_FIXNUM(V6),MAKE_FIXNUM(V7),MAKE_FIXNUM(V8),((V1))->in.in_slots[5],MAKE_FIXNUM(V17),MAKE_FIXNUM(V12),(V13),(V14),MAKE_FIXNUM(V12),(V13),(V14))/*  WRITE-XY-FORMAT-IMAGE-X-DATA*/;
	}
	V22= (V22)+1;
	goto L2112;
	}
L2108:
	(*LK3)(1,(V1))                            /*  IMAGE-DEPTH     */;
	RETURN(L16(24,VV[82],MAKE_FIXNUM(V7),VV[83],MAKE_FIXNUM(V8),VV[84],VALUES(0),VV[87],(V20),VV[86],((V1))->in.in_slots[4],VV[88],MAKE_FIXNUM(1),VV[89],MAKE_FIXNUM(V17),VV[92],MAKE_FIXNUM(V12),VV[93],MAKE_FIXNUM(V15),VV[94],MAKE_FIXNUM(V10),VV[90],(V13),VV[91],(V14))/*  CREATE-IMAGE*/);
	}
	}
}
/*	function definition for Z-FORMAT-IMAGE-X->IMAGE-X             */
static L58(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT60 VLEX60 CLSR60
	{int V6;
	int V7;
	V6= fix(V4);
	V7= fix(V5);
TTL:
	{int V8;                                  /*  PADDED-X        */
	register int V9;                          /*  LEFT-PAD        */
	object V10;                               /*  X               */
	register int V11;                         /*  BITS-PER-PIXEL  */
	register int V12;                         /*  UNIT            */
	object V13;                               /*  BYTE-LSB-FIRST-P*/
	object V14;                               /*  BIT-LSB-FIRST-P */
	register int V15;                         /*  PAD             */
	object V16;                               /*  BITS-PER-LINE   */
	object V17;                               /*  PADDED-BITS-PER-LINE*/
	register int V18;                         /*  PADDED-BYTES-PER-LINE*/
	object V19;                               /*  PADDED-BYTES-PER-PLANE*/
	object V20;                               /*  LENGTH          */
	object V21;                               /*  OBUF            */
	V8= (fix((V2)))+(fix(((V1))->in.in_slots[12]));
	(*LK3)(1,(V1))                            /*  IMAGE-DEPTH     */;
	if(!((fix(VALUES(0)))==(1))){
	goto L2128;}
	V9= (V8>=0&&8>0?(V8)%(8):imod(V8,8));
	goto L2126;
L2128:
	V9= 0;
L2126:
	V10= MAKE_FIXNUM((V8)-(V9));
	V11= fix(((V1))->in.in_slots[6]);
	V12= fix(((V1))->in.in_slots[10]);
	V13= ((V1))->in.in_slots[8];
	V14= ((V1))->in.in_slots[7];
	V15= fix(((V1))->in.in_slots[11]);
	V16= MAKE_FIXNUM(((V6)+(V9))*(V11));
	Lceiling(2,(V16),MAKE_FIXNUM(V15))        /*  CEILING         */;
	V17= MAKE_FIXNUM((fix(VALUES(0)))*(V15));
	Lceiling(2,(V17),MAKE_FIXNUM(8))          /*  CEILING         */;
	V18= fix(VALUES(0));
	V19= MAKE_FIXNUM((V18)*(V7));
	(*LK3)(1,(V1))                            /*  IMAGE-DEPTH     */;
	V20= MAKE_FIXNUM((fix((V19)))*(fix(VALUES(0))));
	(*LK15)(3,(V20),VV[138],VV[139])          /*  MAKE-ARRAY      */;
	V21= VALUES(0);
	L52(17,((V1))->in.in_slots[9],(V21),MAKE_FIXNUM(0),MAKE_FIXNUM(0),(V10),(V3),MAKE_FIXNUM(V6),MAKE_FIXNUM(V7),((V1))->in.in_slots[5],MAKE_FIXNUM(V18),MAKE_FIXNUM(V11),MAKE_FIXNUM(V12),(V13),(V14),MAKE_FIXNUM(V12),(V13),(V14))/*  WRITE-Z-FORMAT-IMAGE-X-DATA*/;
	(*LK3)(1,(V1))                            /*  IMAGE-DEPTH     */;
	RETURN(L16(24,VV[82],MAKE_FIXNUM(V6),VV[83],MAKE_FIXNUM(V7),VV[84],VALUES(0),VV[87],(V21),VV[86],VV[48],VV[88],MAKE_FIXNUM(V11),VV[89],MAKE_FIXNUM(V18),VV[92],MAKE_FIXNUM(V12),VV[93],MAKE_FIXNUM(V15),VV[94],MAKE_FIXNUM(V9),VV[90],(V13),VV[91],(V14))/*  CREATE-IMAGE*/);
	}
	}
}
/*	function definition for IMAGE-X->IMAGE-X                      */
static L59(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT61 VLEX61 CLSR61
	{int V6;
	int V7;
	int V8;
	int V9;
	V6= fix(V2);
	V7= fix(V3);
	V8= fix(V4);
	V9= fix(V5);
TTL:
	{object V10= ((V1))->in.in_slots[4];
	if((V10!= VV[177])
	&& (V10!= VV[78]))goto L2147;
	RETURN(L57(5,(V1),MAKE_FIXNUM(V6),MAKE_FIXNUM(V7),MAKE_FIXNUM(V8),MAKE_FIXNUM(V9))/*  XY-FORMAT-IMAGE-X->IMAGE-X*/);
L2147:
	if((V10!= VV[48]))goto L2148;
	RETURN(L58(5,(V1),MAKE_FIXNUM(V6),MAKE_FIXNUM(V7),MAKE_FIXNUM(V8),MAKE_FIXNUM(V9))/*  Z-FORMAT-IMAGE-X->IMAGE-X*/);
L2148:
	FEerror("The ECASE key value ~s is illegal.",1,V10);}
	}
}
/*	function definition for IMAGE-X->IMAGE-XY                     */
static L60(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT62 VLEX62 CLSR62
TTL:
	if((((V1))->in.in_slots[4])==(VV[177])){
	goto L2149;}
	if((((V1))->in.in_slots[4])==(VV[78])){
	goto L2149;}
	if(!((((V1))->in.in_slots[4])==(VV[48]))){
	goto L2150;}
	(*LK3)(1,(V1))                            /*  IMAGE-DEPTH     */;
	if((fix(VALUES(0)))==(1)){
	goto L2149;}
L2150:
	Lerror(3,VV[184],((V1))->in.in_slots[4],VV[78])/*  ERROR      */;
L2149:
	T0= ((V1))->in.in_slots[9];
	{int V6= (((V1))->in.in_slots[9])->v.v_fillp;
	{int V7= (fix((V2)))+(fix(((V1))->in.in_slots[12]));
	(*LK3)(1,(V1))                            /*  IMAGE-DEPTH     */;
	T1= VALUES(0);
	T2= ((V1))->in.in_slots[5];
	(*LK2)(1,(V1))                            /*  IMAGE-HEIGHT    */;
	RETURN(L39(14,T0,MAKE_FIXNUM(0),MAKE_FIXNUM(V6),Cnil,MAKE_FIXNUM(V7),(V3),(V4),(V5),T1,((V1))->in.in_slots[5],MAKE_FIXNUM((fix(T2))*(fix(VALUES(0)))),((V1))->in.in_slots[10],((V1))->in.in_slots[8],((V1))->in.in_slots[7])/*  READ-IMAGE-XY*/);}}
}
/*	function definition for IMAGE-X->IMAGE-Z                      */
static L61(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT63 VLEX63 CLSR63
TTL:
	if((((V1))->in.in_slots[4])==(VV[48])){
	goto L2163;}
	if((((V1))->in.in_slots[4])==(VV[177])){
	goto L2163;}
	if(!((((V1))->in.in_slots[4])==(VV[78]))){
	goto L2164;}
	(*LK3)(1,(V1))                            /*  IMAGE-DEPTH     */;
	if((fix(VALUES(0)))==(1)){
	goto L2163;}
L2164:
	Lerror(3,VV[185],((V1))->in.in_slots[4],VV[48])/*  ERROR      */;
L2163:
	T0= ((V1))->in.in_slots[9];
	{int V6= (((V1))->in.in_slots[9])->v.v_fillp;
	{int V7= (fix((V2)))+(fix(((V1))->in.in_slots[12]));
	(*LK3)(1,(V1))                            /*  IMAGE-DEPTH     */;
	RETURN(L40(14,T0,MAKE_FIXNUM(0),MAKE_FIXNUM(V6),Cnil,MAKE_FIXNUM(V7),(V3),(V4),(V5),VALUES(0),((V1))->in.in_slots[5],((V1))->in.in_slots[6],((V1))->in.in_slots[10],((V1))->in.in_slots[8],((V1))->in.in_slots[7])/*  READ-IMAGE-Z*/);}}
}
/*	function definition for COPY-PIXARRAY                         */
static L62(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT64 VLEX64 CLSR64
	{volatile int V7;
	volatile int V8;
	volatile int V9;
	volatile int V10;
	volatile int V11;
	V7= fix(V2);
	V8= fix(V3);
	V9= fix(V4);
	V10= fix(V5);
	V11= fix(V6);
TTL:
	{volatile object V12;                     /*  BITS-PER-LINE   */
	volatile object V13;                      /*  PADDED-BITS-PER-LINE*/
	volatile object V14;                      /*  PADDED-WIDTH    */
	volatile object V15;                      /*  COPY            */
	V12= MAKE_FIXNUM((V11)*(V9));
	Lceiling(2,(V12),MAKE_FIXNUM(32))         /*  CEILING         */;
	V13= MAKE_FIXNUM((fix(VALUES(0)))*(32));
	Lceiling(2,(V13),MAKE_FIXNUM(V11))        /*  CEILING         */;
	V14= VALUES(0);
	{object V16= list(2,MAKE_FIXNUM(V10),(V14));
	Larray_element_type(1,(V1))               /*  ARRAY-ELEMENT-TYPE*/;
	(*LK15)(3,(V16),VV[138],VALUES(0))        /*  MAKE-ARRAY      */;
	V15= VALUES(0);}
	(*LK36)(7,(V1),(V15),MAKE_FIXNUM(V7),MAKE_FIXNUM(V8),MAKE_FIXNUM(V9),MAKE_FIXNUM(V10),MAKE_FIXNUM(V11))/*  FAST-COPY-PIXARRAY*/;
	if(VALUES(0)!=Cnil){
	goto L2181;}
	if(!eql(MAKE_FIXNUM(V11),VV[11]))goto L2184;
	{volatile object V16;                     /*  ARRAY           */
	volatile object V17;                      /*  COPY            */
	V16= (V1);
	V17= (V15);
	{volatile int V18;                        /*  DST-Y           */
	volatile int V19;                         /*  SRC-Y           */
	V18= 0;
	V19= V8;
L2188:
	if(!((V18)>=(V10))){
	goto L2189;}
	goto L2181;
L2189:
	{volatile int V21;                        /*  DST-X           */
	volatile int V22;                         /*  SRC-X           */
	V21= 0;
	V22= V7;
L2196:
	if(!((V21)>=(V9))){
	goto L2197;}
	goto L2192;
L2197:
	((V17))->a.a_self[V18*((V17))->a.a_dims[1]+V21]= ((V16))->a.a_self[V19*((V16))->a.a_dims[1]+V22];
	V21= (V21)+1;
	V22= (V22)+1;
	goto L2196;
	}
L2192:
	V18= (V18)+1;
	V19= (V19)+1;
	goto L2188;
	}
	}
L2184:
	if(!eql(MAKE_FIXNUM(V11),VV[120]))goto L2211;
	{volatile object V24;                     /*  ARRAY           */
	volatile object V25;                      /*  COPY            */
	V24= (V1);
	V25= (V15);
	{volatile int V26;                        /*  DST-Y           */
	volatile int V27;                         /*  SRC-Y           */
	V26= 0;
	V27= V8;
L2215:
	if(!((V26)>=(V10))){
	goto L2216;}
	goto L2181;
L2216:
	{volatile int V29;                        /*  DST-X           */
	volatile int V30;                         /*  SRC-X           */
	V29= 0;
	V30= V7;
L2223:
	if(!((V29)>=(V9))){
	goto L2224;}
	goto L2219;
L2224:
	((V25))->fixa.fixa_self[V26*((V25))->a.a_dims[1]+V29]= ((V24))->fixa.fixa_self[V27*((V24))->a.a_dims[1]+V30];
	V29= (V29)+1;
	V30= (V30)+1;
	goto L2223;
	}
L2219:
	V26= (V26)+1;
	V27= (V27)+1;
	goto L2215;
	}
	}
L2211:
	if(!eql(MAKE_FIXNUM(V11),VV[116]))goto L2238;
	{volatile object V32;                     /*  ARRAY           */
	volatile object V33;                      /*  COPY            */
	V32= (V1);
	V33= (V15);
	{volatile int V34;                        /*  DST-Y           */
	volatile int V35;                         /*  SRC-Y           */
	V34= 0;
	V35= V8;
L2242:
	if(!((V34)>=(V10))){
	goto L2243;}
	goto L2181;
L2243:
	{volatile int V37;                        /*  DST-X           */
	volatile int V38;                         /*  SRC-X           */
	V37= 0;
	V38= V7;
L2250:
	if(!((V37)>=(V9))){
	goto L2251;}
	goto L2246;
L2251:
	((V33))->fixa.fixa_self[V34*((V33))->a.a_dims[1]+V37]= ((V32))->fixa.fixa_self[V35*((V32))->a.a_dims[1]+V38];
	V37= (V37)+1;
	V38= (V38)+1;
	goto L2250;
	}
L2246:
	V34= (V34)+1;
	V35= (V35)+1;
	goto L2242;
	}
	}
L2238:
	if(!eql(MAKE_FIXNUM(V11),VV[115]))goto L2265;
	{volatile object V40;                     /*  ARRAY           */
	volatile object V41;                      /*  COPY            */
	V40= (V1);
	V41= (V15);
	{volatile int V42;                        /*  DST-Y           */
	volatile int V43;                         /*  SRC-Y           */
	V42= 0;
	V43= V8;
L2269:
	if(!((V42)>=(V10))){
	goto L2270;}
	goto L2181;
L2270:
	{volatile int V45;                        /*  DST-X           */
	volatile int V46;                         /*  SRC-X           */
	V45= 0;
	V46= V7;
L2277:
	if(!((V45)>=(V9))){
	goto L2278;}
	goto L2273;
L2278:
	((V41))->fixa.fixa_self[V42*((V41))->a.a_dims[1]+V45]= ((V40))->fixa.fixa_self[V43*((V40))->a.a_dims[1]+V46];
	V45= (V45)+1;
	V46= (V46)+1;
	goto L2277;
	}
L2273:
	V42= (V42)+1;
	V43= (V43)+1;
	goto L2269;
	}
	}
L2265:
	if(!eql(MAKE_FIXNUM(V11),VV[123]))goto L2292;
	{volatile object V48;                     /*  ARRAY           */
	volatile object V49;                      /*  COPY            */
	V48= (V1);
	V49= (V15);
	{volatile int V50;                        /*  DST-Y           */
	volatile int V51;                         /*  SRC-Y           */
	V50= 0;
	V51= V8;
L2296:
	if(!((V50)>=(V10))){
	goto L2297;}
	goto L2181;
L2297:
	{volatile int V53;                        /*  DST-X           */
	volatile int V54;                         /*  SRC-X           */
	V53= 0;
	V54= V7;
L2304:
	if(!((V53)>=(V9))){
	goto L2305;}
	goto L2300;
L2305:
	((V49))->fixa.fixa_self[V50*((V49))->a.a_dims[1]+V53]= ((V48))->fixa.fixa_self[V51*((V48))->a.a_dims[1]+V54];
	V53= (V53)+1;
	V54= (V54)+1;
	goto L2304;
	}
L2300:
	V50= (V50)+1;
	V51= (V51)+1;
	goto L2296;
	}
	}
L2292:
	if(!eql(MAKE_FIXNUM(V11),VV[114]))goto L2319;
	{volatile object V56;                     /*  ARRAY           */
	volatile object V57;                      /*  COPY            */
	V56= (V1);
	V57= (V15);
	{volatile int V58;                        /*  DST-Y           */
	volatile int V59;                         /*  SRC-Y           */
	V58= 0;
	V59= V8;
L2323:
	if(!((V58)>=(V10))){
	goto L2324;}
	goto L2181;
L2324:
	{volatile int V61;                        /*  DST-X           */
	volatile int V62;                         /*  SRC-X           */
	V61= 0;
	V62= V7;
L2331:
	if(!((V61)>=(V9))){
	goto L2332;}
	goto L2327;
L2332:
	((V57))->a.a_self[V58*((V57))->a.a_dims[1]+V61]= ((V56))->a.a_self[V59*((V56))->a.a_dims[1]+V62];
	V61= (V61)+1;
	V62= (V62)+1;
	goto L2331;
	}
L2327:
	V58= (V58)+1;
	V59= (V59)+1;
	goto L2323;
	}
	}
L2319:
	FEerror("The ECASE key value ~s is illegal.",1,MAKE_FIXNUM(V11));
L2181:
	VALUES(0) = (V15);
	RETURN(1);
	}
	}
}
/*	function definition for IMAGE-XY->IMAGE-X                     */
static L63(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT65 VLEX65 CLSR65
	{volatile int V6;
	volatile int V7;
	volatile int V8;
	volatile int V9;
	V6= fix(V2);
	V7= fix(V3);
	V8= fix(V4);
	V9= fix(V5);
TTL:
	{volatile object V10;                     /*  PADDED-BITS-PER-LINE*/
	volatile int V11;                         /*  PADDED-BYTES-PER-LINE*/
	volatile int V12;                         /*  PADDED-BYTES-PER-PLANE*/
	volatile object V13;                      /*  BYTES-TOTAL     */
	volatile object V14;                      /*  DATA            */
	Lceiling(2,MAKE_FIXNUM(V8),MAKE_FIXNUM(32))/*  CEILING        */;
	V10= MAKE_FIXNUM((fix(VALUES(0)))*(32));
	Lceiling(2,(V10),MAKE_FIXNUM(8))          /*  CEILING         */;
	V11= fix(VALUES(0));
	V12= (V11)*(V9);
	(*LK3)(1,(V1))                            /*  IMAGE-DEPTH     */;
	V13= MAKE_FIXNUM((V12)*(fix(VALUES(0))));
	(*LK15)(3,(V13),VV[138],VV[139])          /*  MAKE-ARRAY      */;
	V14= VALUES(0);
	{volatile int V15;                        /*  INDEX           */
	V15= 0;
	{volatile object V16;
	volatile object V17;                      /*  BITMAP          */
	V16= ((V1))->in.in_slots[4];
	V17= Cnil;
L2358:
	if(!((V16)==Cnil)){
	goto L2359;}
	goto L2353;
L2359:
	V17= CAR((V16));
	L49(12,(V14),MAKE_FIXNUM(V15),(V17),MAKE_FIXNUM(V6),MAKE_FIXNUM(V7),MAKE_FIXNUM(V8),MAKE_FIXNUM(V9),MAKE_FIXNUM(V11),MAKE_FIXNUM(1),MAKE_FIXNUM(32),Cnil,Cnil)/*  WRITE-PIXARRAY*/;
	V15= (V15)+(V12);
	V16= CDR((V16));
	goto L2358;
	}
	}
L2353:
	(*LK3)(1,(V1))                            /*  IMAGE-DEPTH     */;
	RETURN(L16(22,VV[82],MAKE_FIXNUM(V8),VV[83],MAKE_FIXNUM(V9),VV[84],VALUES(0),VV[87],(V14),VV[86],VV[78],VV[88],MAKE_FIXNUM(1),VV[89],MAKE_FIXNUM(V11),VV[92],MAKE_FIXNUM(32),VV[93],MAKE_FIXNUM(32),VV[90],Cnil,VV[91],Cnil)/*  CREATE-IMAGE*/);
	}
	}
}
/*	function definition for IMAGE-XY->IMAGE-XY                    */
static L64(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT66 VLEX66 CLSR66
	{int V6;
	int V7;
	V6= fix(V4);
	V7= fix(V5);
TTL:
	(*LK3)(1,(V1))                            /*  IMAGE-DEPTH     */;
	T0= VALUES(0);
	{object V8;
	object V9= ((V1))->in.in_slots[4];
	if(V9==Cnil){
	VALUES(0) = Cnil;
	goto L2372;}
	T1=V8=CONS(Cnil,Cnil);
L2373:
	{object V10;                              /*  ARRAY           */
	L62(6,CAR(V9),(V2),(V3),MAKE_FIXNUM(V6),MAKE_FIXNUM(V7),MAKE_FIXNUM(1))/*  COPY-PIXARRAY*/;
	CAR(V8)= VALUES(0);
	}
	if((V9=CDR(V9))==Cnil){
	VALUES(0) = T1;
	goto L2372;}
	V8=CDR(V8)=CONS(Cnil,Cnil);
	goto L2373;}
L2372:
	RETURN(L16(8,VV[82],MAKE_FIXNUM(V6),VV[83],MAKE_FIXNUM(V7),VV[84],T0,VV[87],VALUES(0))/*  CREATE-IMAGE*/);
	}
}
/*	function definition for IMAGE-XY->IMAGE-Z                     */
static L66(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT67 VLEX67 CLSR67
TTL:
	RETURN(Lerror(3,VV[186],VV[78],VV[48])    /*  ERROR           */);
}
/*	function definition for IMAGE-Z->IMAGE-X                      */
static L67(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT68 VLEX68 CLSR68
	{int V6;
	int V7;
	V6= fix(V4);
	V7= fix(V5);
TTL:
	{object V8;                               /*  BITS-PER-LINE   */
	object V9;                                /*  PADDED-BITS-PER-LINE*/
	register int V10;                         /*  PADDED-BYTES-PER-LINE*/
	object V11;                               /*  BYTES-TOTAL     */
	object V12;                               /*  DATA            */
	object V13;                               /*  BITS-PER-PIXEL  */
	V8= MAKE_FIXNUM((V6)*(fix(((V1))->in.in_slots[4])));
	Lceiling(2,(V8),MAKE_FIXNUM(32))          /*  CEILING         */;
	V9= MAKE_FIXNUM((fix(VALUES(0)))*(32));
	Lceiling(2,(V9),MAKE_FIXNUM(8))           /*  CEILING         */;
	V10= fix(VALUES(0));
	{int V14= (V10)*(V7);
	(*LK3)(1,(V1))                            /*  IMAGE-DEPTH     */;
	V11= MAKE_FIXNUM((V14)*(fix(VALUES(0))));}
	(*LK15)(3,(V11),VV[138],VV[139])          /*  MAKE-ARRAY      */;
	V12= VALUES(0);
	V13= ((V1))->in.in_slots[4];
	L49(12,(V12),MAKE_FIXNUM(0),((V1))->in.in_slots[5],(V2),(V3),MAKE_FIXNUM(V6),MAKE_FIXNUM(V7),MAKE_FIXNUM(V10),((V1))->in.in_slots[4],MAKE_FIXNUM(32),Cnil,Cnil)/*  WRITE-PIXARRAY*/;
	(*LK3)(1,(V1))                            /*  IMAGE-DEPTH     */;
	RETURN(L16(22,VV[82],MAKE_FIXNUM(V6),VV[83],MAKE_FIXNUM(V7),VV[84],VALUES(0),VV[87],(V12),VV[86],VV[48],VV[88],(V13),VV[89],MAKE_FIXNUM(V10),VV[92],MAKE_FIXNUM(32),VV[93],MAKE_FIXNUM(32),VV[90],Cnil,VV[91],Cnil)/*  CREATE-IMAGE*/);
	}
	}
}
/*	function definition for IMAGE-Z->IMAGE-XY                     */
static L68(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT69 VLEX69 CLSR69
TTL:
	RETURN(Lerror(3,VV[187],VV[48],VV[78])    /*  ERROR           */);
}
/*	function definition for IMAGE-Z->IMAGE-Z                      */
static L69(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT70 VLEX70 CLSR70
	{int V6;
	int V7;
	V6= fix(V4);
	V7= fix(V5);
TTL:
	(*LK3)(1,(V1))                            /*  IMAGE-DEPTH     */;
	T0= VALUES(0);
	L62(6,((V1))->in.in_slots[5],(V2),(V3),MAKE_FIXNUM(V6),MAKE_FIXNUM(V7),((V1))->in.in_slots[4])/*  COPY-PIXARRAY*/;
	RETURN(L16(8,VV[82],MAKE_FIXNUM(V6),VV[83],MAKE_FIXNUM(V7),VV[84],T0,VV[87],VALUES(0))/*  CREATE-IMAGE*/);
	}
}
/*	function definition for COPY-IMAGE                            */
static L70(int narg, object V1, ...)
{ VT71 VLEX71 CLSR71
	{register int V2;
	register int V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[10];
	parse_key(narg,args,5,L70keys,keyvars,OBJNULL,FALSE);
	if(keyvars[5]==Cnil){
	V2= 0;
	}else{
	V2= fix(keyvars[0]);}
	if(keyvars[6]==Cnil){
	V3= 0;
	}else{
	V3= fix(keyvars[1]);}
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	}
	{register int V7;                         /*  IMAGE-WIDTH     */
	register int V8;                          /*  IMAGE-HEIGHT    */
	register int V9;                          /*  WIDTH           */
	register int V10;                         /*  HEIGHT          */
	(*LK1)(1,(V1))                            /*  IMAGE-WIDTH     */;
	V7= fix(VALUES(0));
	(*LK2)(1,(V1))                            /*  IMAGE-HEIGHT    */;
	V8= fix(VALUES(0));
	if((V4)!=Cnil){
	V9= fix((V4));
	goto L2391;}
	V9= V7;
L2391:
	if((V5)!=Cnil){
	V10= fix((V5));
	goto L2392;}
	V10= V8;
L2392:
	Lmonotonically_nondecreasing(3,MAKE_FIXNUM(0),MAKE_FIXNUM(V2),MAKE_FIXNUM((V7)-1))/*  <=*/;
	if(VALUES(0)!=Cnil){
	goto L2393;}
	Lerror(1,VV[188])                         /*  ERROR           */;
L2393:
	Lmonotonically_nondecreasing(3,MAKE_FIXNUM(0),MAKE_FIXNUM(V3),MAKE_FIXNUM((V8)-1))/*  <=*/;
	if(VALUES(0)!=Cnil){
	goto L2396;}
	Lerror(1,VV[189])                         /*  ERROR           */;
L2396:
	{int V11= (V7)-(V2);
	{int V12= (V11)>=(0)?V11:0;
	V9= (V9)<=(V12)?V9:V12;}}
	{int V11= (V8)-(V3);
	{int V12= (V11)>=(0)?V11:0;
	V10= (V10)<=(V12)?V10:V12;}}
	{register object V11;                     /*  COPY            */
	{register object V12;
	V12= (V1);
	(*LK6)(2,(V12),VV[35])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2405;}
	if(((V6)!= Cnil)
	&& ((V6)!= VV[35]))goto L2407;
	L59(5,(V1),MAKE_FIXNUM(V2),MAKE_FIXNUM(V3),MAKE_FIXNUM(V9),MAKE_FIXNUM(V10))/*  IMAGE-X->IMAGE-X*/;
	V11= VALUES(0);
	goto L2403;
L2407:
	if(((V6)!= VV[51]))goto L2408;
	L60(5,(V1),MAKE_FIXNUM(V2),MAKE_FIXNUM(V3),MAKE_FIXNUM(V9),MAKE_FIXNUM(V10))/*  IMAGE-X->IMAGE-XY*/;
	V11= VALUES(0);
	goto L2403;
L2408:
	if(((V6)!= VV[62]))goto L2409;
	L61(5,(V1),MAKE_FIXNUM(V2),MAKE_FIXNUM(V3),MAKE_FIXNUM(V9),MAKE_FIXNUM(V10))/*  IMAGE-X->IMAGE-Z*/;
	V11= VALUES(0);
	goto L2403;
L2409:
	FEerror("The ECASE key value ~s is illegal.",1,(V6));
L2405:
	(*LK6)(2,(V12),VV[51])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2411;}
	if(((V6)!= VV[35]))goto L2413;
	L63(5,(V1),MAKE_FIXNUM(V2),MAKE_FIXNUM(V3),MAKE_FIXNUM(V9),MAKE_FIXNUM(V10))/*  IMAGE-XY->IMAGE-X*/;
	V11= VALUES(0);
	goto L2403;
L2413:
	if(((V6)!= Cnil)
	&& ((V6)!= VV[51]))goto L2414;
	L64(5,(V1),MAKE_FIXNUM(V2),MAKE_FIXNUM(V3),MAKE_FIXNUM(V9),MAKE_FIXNUM(V10))/*  IMAGE-XY->IMAGE-XY*/;
	V11= VALUES(0);
	goto L2403;
L2414:
	if(((V6)!= VV[62]))goto L2415;
	L66(5,(V1),MAKE_FIXNUM(V2),MAKE_FIXNUM(V3),MAKE_FIXNUM(V9),MAKE_FIXNUM(V10))/*  IMAGE-XY->IMAGE-Z*/;
	V11= VALUES(0);
	goto L2403;
L2415:
	FEerror("The ECASE key value ~s is illegal.",1,(V6));
L2411:
	(*LK6)(2,(V12),VV[62])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2417;}
	if(((V6)!= VV[35]))goto L2419;
	L67(5,(V1),MAKE_FIXNUM(V2),MAKE_FIXNUM(V3),MAKE_FIXNUM(V9),MAKE_FIXNUM(V10))/*  IMAGE-Z->IMAGE-X*/;
	V11= VALUES(0);
	goto L2403;
L2419:
	if(((V6)!= VV[51]))goto L2420;
	L68(5,(V1),MAKE_FIXNUM(V2),MAKE_FIXNUM(V3),MAKE_FIXNUM(V9),MAKE_FIXNUM(V10))/*  IMAGE-Z->IMAGE-XY*/;
	V11= VALUES(0);
	goto L2403;
L2420:
	if(((V6)!= Cnil)
	&& ((V6)!= VV[62]))goto L2421;
	L69(5,(V1),MAKE_FIXNUM(V2),MAKE_FIXNUM(V3),MAKE_FIXNUM(V9),MAKE_FIXNUM(V10))/*  IMAGE-Z->IMAGE-Z*/;
	V11= VALUES(0);
	goto L2403;
L2421:
	FEerror("The ECASE key value ~s is illegal.",1,(V6));
L2417:
	(*LK7)(3,VV[13],(V12),VV[190])            /*  TYPECASE-ERROR-STRING*/;
	Lerror(1,VALUES(0))                       /*  ERROR           */;
	V11= VALUES(0);
	}
L2403:
	Lcopy_list(1,((V1))->in.in_slots[3])      /*  COPY-LIST       */;
	((V11))->in.in_slots[3]= VALUES(0);
	Lgetf(2,((V1))->in.in_slots[3],VV[23])    /*  GETF            */;
	if(VALUES(0)==Cnil){
	goto L2425;}
	if((V2)==0){
	goto L2425;}
	{int V12;
	Lgetf(2,((V1))->in.in_slots[3],VV[23])    /*  GETF            */;
	V12= (fix(VALUES(0)))-(V2);
	{object V13;
	siLput_f(3,((V11))->in.in_slots[3],MAKE_FIXNUM(V12),VV[23])/*  PUT-F*/;
	V13= VALUES(0);
	((V11))->in.in_slots[3]= (V13);
	}
	}
L2425:
	Lgetf(2,((V1))->in.in_slots[3],VV[24])    /*  GETF            */;
	if(VALUES(0)==Cnil){
	goto L2434;}
	if((V3)==0){
	goto L2434;}
	{int V12;
	Lgetf(2,((V1))->in.in_slots[3],VV[24])    /*  GETF            */;
	V12= (fix(VALUES(0)))-(V3);
	{object V13;
	siLput_f(3,((V11))->in.in_slots[3],MAKE_FIXNUM(V12),VV[24])/*  PUT-F*/;
	V13= VALUES(0);
	((V11))->in.in_slots[3]= (V13);
	}
	}
L2434:
	VALUES(0) = (V11);
	RETURN(1);
	}
	}
	}
}
/*	function definition for READ-BITMAP-FILE                      */
static L71(int narg, object V1)
{ VT72 VLEX72 CLSR72
TTL:
	{volatile object V2;                      /*  FSTREAM         */
	(*LK37)(3,(V1),VV[191],VV[192])           /*  OPEN            */;
	V2= VALUES(0);
	{ int V3; volatile bool unwinding = FALSE;
	if ((V3=frs_push(FRS_PROTECT,Cnil))) {
	V3--; unwinding = TRUE;} else {
	{volatile object V4;                      /*  LINE            */
	volatile object V5;                       /*  NAME            */
	volatile object V6;                       /*  NAME-END        */
	V4= VV[193];
	lex0[0]=Cnil;                             /*  PROPERTIES      */
	V5= Cnil;
	V6= Cnil;
L2447:
	Lread_line(1,(V2))                        /*  READ-LINE       */;
	V4= VALUES(0);
	if(char_code(aref1((V4),0))==char_code(code_char('\43'))){
	goto L2451;}
	goto L2445;
L2451:
	if(((V5))!=Cnil){
	goto L2454;}
	VALUES(0) = (VV[388]->s.s_gfdef);
	(*LK19)(6,code_char('\137'),(V4),VV[159],VALUES(0),VV[194],Ct)/*  POSITION*/;
	V6= VALUES(0);
	LC72(lex0,3,(V4),MAKE_FIXNUM(8),(V6))     /*  READ-KEYWORD    */;
	V5= VALUES(0);
	if(((V5))==(VV[195])){
	goto L2454;}
	{object V7;
	object V8;
	V7= VV[22];
	V8= (V5);
	{object V9;
	siLput_f(3,lex0[0],(V8),(V7))             /*  PUT-F           */;
	V9= VALUES(0);
	lex0[0]= (V9);
	}
	}
L2454:
	{register int V7;                         /*  IND-START       */
	object V8;                                /*  IND-END         */
	object V9;                                /*  IND             */
	object V10;                               /*  VAL-START       */
	object V11;                               /*  VAL             */
	V7= (fix((V6)))+1;
	VALUES(0) = (VV[388]->s.s_gfdef);
	(*LK19)(6,code_char('\40'),(V4),VV[159],VALUES(0),VV[196],MAKE_FIXNUM(V7))/*  POSITION*/;
	V8= VALUES(0);
	LC72(lex0,3,(V4),MAKE_FIXNUM(V7),(V8))    /*  READ-KEYWORD    */;
	V9= VALUES(0);
	V10= MAKE_FIXNUM((fix((V8)))+1);
	Lparse_integer(3,(V4),VV[196],(V10))      /*  PARSE-INTEGER   */;
	V11= VALUES(0);
	{object V12;
	object V13;
	V12= (V9);
	V13= (V11);
	{object V14;
	siLput_f(3,lex0[0],(V13),(V12))           /*  PUT-F           */;
	V14= VALUES(0);
	lex0[0]= (V14);
	}
	}
	}
	goto L2447;
L2445:
	{ int V7;
	volatile object V8;                       /*  WIDTH           */
	volatile object V9;                       /*  HEIGHT          */
	volatile int V10;                         /*  DEPTH           */
	volatile int V11;                         /*  LEFT-PAD        */
	LC73(lex0,1,VV[82])                       /*  EXTRACT-PROPERTY*/;
	T0= VALUES(0);
	LC73(lex0,1,VV[83])                       /*  EXTRACT-PROPERTY*/;
	T1= VALUES(0);
	LC73(lex0,2,VV[84],MAKE_FIXNUM(1))        /*  EXTRACT-PROPERTY*/;
	T2= VALUES(0);
	LC73(lex0,2,VV[94],MAKE_FIXNUM(0))        /*  EXTRACT-PROPERTY*/;
	VALUES(3) = VALUES(0);
	VALUES(2) = T2;
	VALUES(1) = T1;
	VALUES(0) = T0;
	V7=4;
	if (V7--==0) goto L2486;
	V8= VALUES(0);
	if (V7--==0) goto L2487;
	V9= VALUES(1);
	if (V7--==0) goto L2488;
	V10= fix(VALUES(2));
	if (V7--==0) goto L2489;
	V11= fix(VALUES(3));
	goto L2490;
L2486:
	V8= Cnil;
L2487:
	V9= Cnil;
L2488:
	V10= 0;
L2489:
	V11= 0;
L2490:
	if(((V8))==Cnil){
	goto L2492;}
	if(((V9))!=Cnil){
	goto L2491;}
L2492:
	Lerror(1,VV[197])                         /*  ERROR           */;
L2491:
	{volatile object V12;                     /*  BITS-PER-PIXEL  */
	volatile int V13;                         /*  BITS-PER-LINE   */
	volatile int V14;                         /*  BYTES-PER-LINE  */
	volatile object V15;                      /*  PADDED-BITS-PER-LINE*/
	volatile int V16;                         /*  PADDED-BYTES-PER-LINE*/
	volatile object V17;                      /*  DATA            */
	volatile int V18;                         /*  LINE-BASE       */
	volatile int V19;                         /*  BYTE            */
	if(!((V10)>(24))){
	goto L2498;}
	V12= MAKE_FIXNUM(32);
	goto L2496;
L2498:
	if(!((V10)>(16))){
	goto L2501;}
	V12= MAKE_FIXNUM(24);
	goto L2496;
L2501:
	if(!((V10)>(8))){
	goto L2504;}
	V12= MAKE_FIXNUM(16);
	goto L2496;
L2504:
	if(!((V10)>(4))){
	goto L2507;}
	V12= MAKE_FIXNUM(8);
	goto L2496;
L2507:
	if(!((V10)>(1))){
	goto L2510;}
	V12= MAKE_FIXNUM(4);
	goto L2496;
L2510:
	V12= MAKE_FIXNUM(1);
L2496:
	V13= (fix((V8)))*(fix((V12)));
	Lceiling(2,MAKE_FIXNUM(V13),MAKE_FIXNUM(8))/*  CEILING        */;
	V14= fix(VALUES(0));
	Lceiling(2,MAKE_FIXNUM(V13),MAKE_FIXNUM(32))/*  CEILING       */;
	V15= MAKE_FIXNUM((fix(VALUES(0)))*(32));
	Lceiling(2,(V15),MAKE_FIXNUM(8))          /*  CEILING         */;
	V16= fix(VALUES(0));
	(*LK15)(3,number_times(MAKE_FIXNUM(V16),(V9)),VV[138],VV[139])/*  MAKE-ARRAY*/;
	V17= VALUES(0);
	V18= 0;
	V19= 0;
	{volatile object V20;                     /*  DATA            */
	V20= (V17);
	{volatile object V21;
	volatile int V22;                         /*  I               */
	V21= (V9);
	V22= 0;
L2524:
	if(!(number_compare(MAKE_FIXNUM(V22),(V21))>=0)){
	goto L2525;}
	goto L2520;
L2525:
	{volatile int V24;
	volatile int V25;                         /*  J               */
	V24= V14;
	V25= 0;
L2532:
	if(!((V25)>=(V24))){
	goto L2533;}
	goto L2528;
L2533:
L2538:
	{register object V27;
	Lread_char(1,(V2))                        /*  READ-CHAR       */;
	V27= VALUES(0);
	if(CHARACTERP((V27))){
	goto L2543;}
	goto L2539;
L2543:
	if(!((120)==(char_code((V27))))){
	goto L2539;}
	}
	goto L2536;
L2539:
	goto L2538;
L2536:
	Lread_char(1,(V2))                        /*  READ-CHAR       */;
	LC74(lex0,1,VALUES(0))                    /*  PARSE-HEX       */;
	{int V28= ((fix(VALUES(0))) << (4));
	Lread_char(1,(V2))                        /*  READ-CHAR       */;
	LC74(lex0,1,VALUES(0))                    /*  PARSE-HEX       */;
	aset1((V20),(V18)+(V19),number_plus(MAKE_FIXNUM(V28),VALUES(0)));}
	V19= (V19)+(1);
	V25= (V25)+1;
	goto L2532;
	}
L2528:
	V19= 0;
	V18= (V18)+(V16);
	V22= (V22)+1;
	goto L2524;
	}
	}
L2520:
	V8= MAKE_FIXNUM((fix((V8)))-(V11));
	Lgetf(2,lex0[0],VV[23])                   /*  GETF            */;
	if(VALUES(0)==Cnil){
	goto L2565;}
	{int V20;
	Lgetf(3,lex0[0],VV[23],Cnil)              /*  GETF            */;
	V20= (fix(VALUES(0)))-(V11);
	{object V21;
	siLput_f(3,lex0[0],MAKE_FIXNUM(V20),VV[23])/*  PUT-F          */;
	V21= VALUES(0);
	lex0[0]= (V21);
	}
	}
L2565:
	V3=L16(26,VV[82],(V8),VV[83],(V9),VV[84],MAKE_FIXNUM(V10),VV[88],(V12),VV[87],(V17),VV[85],lex0[0],VV[86],VV[48],VV[89],MAKE_FIXNUM(V16),VV[92],MAKE_FIXNUM(32),VV[93],MAKE_FIXNUM(32),VV[94],MAKE_FIXNUM(V11),VV[90],Ct,VV[91],Ct)/*  CREATE-IMAGE*/;
	}}
	}
	}
	frs_pop();
	MV_SAVE(V3);
	Lclose(1,(V2))                            /*  CLOSE           */;
	MV_RESTORE(V3);
	if (unwinding) unwind(nlj_fr,nlj_tag,V3+1);
	else {
	RETURN(V3);}}
	}
}
/*	local function READ-KEYWORD                                   */
static LC72(object *lex0,int narg, object V1, object V2, object V3)
{ VT73 VLEX73 CLSR73
TTL:
	Lsubseq(3,(V1),(V2),(V3))                 /*  SUBSEQ          */;
	Lstring_upcase(1,VALUES(0))               /*  STRING-UPCASE   */;
	T0= VALUES(0);
	VALUES(0) = (VV[388]->s.s_gfdef);
	(*LK38)(5,code_char('\55'),code_char('\137'),T0,VV[159],VALUES(0))/*  SUBSTITUTE*/;
	RETURN((*LK39)(1,VALUES(0))               /*  KINTERN         */);
}
/*	local function EXTRACT-PROPERTY                               */
static LC73(object *lex0,int narg, object V1, ...)
{ VT74 VLEX74 CLSR74
	{object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{object V3;
	VALUES(0) = (VV[20]->s.s_gfdef);
	Lapply(4,VALUES(0),lex0[0],(V1),(V2))     /*  APPLY           */;
	V3= VALUES(0);
	{ int V4;
	object V5;
	object V6;                                /*  FLAG            */
	V4=siLrem_f(2,lex0[0],(V1))               /*  REM-F           */;
	if (V4--==0) goto L2582;
	V5= VALUES(0);
	if (V4--==0) goto L2583;
	V6= VALUES(1);
	goto L2584;
L2582:
	V5= Cnil;
L2583:
	V6= Cnil;
L2584:
	lex0[0]= (V5);}
	VALUES(0) = (V3);
	RETURN(1);
	}
	}
}
/*	local function PARSE-HEX                                      */
static LC74(object *lex0,int narg, object V1)
{ VT75 VLEX75 CLSR75
TTL:
	VALUES(0) = (VV[392]->s.s_gfdef);
	Lassoc(4,(V1),VV[198],VV[159],VALUES(0))  /*  ASSOC           */;
	VALUES(0) = CADR(VALUES(0));
	RETURN(1);
}
/*	function definition for WRITE-BITMAP-FILE                     */
static L75(int narg, object V1, object V2, ...)
{ VT76 VLEX76 CLSR76
	{int i=2;
	volatile object V3;
	va_list args; va_start(args, V2);
	if (i==narg) goto L2589;
	V3= va_arg(args, object);
	i++;
	goto L2590;
L2589:
	V3= Cnil;
L2590:
	(*LK6)(2,(V2),VV[35])                     /*  TYPEP           */;
	if(VALUES(0)!=Cnil){
	goto L2592;}
	L70(3,(V2),VV[199],VV[35])                /*  COPY-IMAGE      */;
	V2= VALUES(0);
L2592:
	{volatile object V4;                      /*  PLIST           */
	volatile object V5;                       /*  NAME            */
	volatile int V6;                          /*  LEFT-PAD        */
	volatile int V7;                          /*  WIDTH           */
	volatile int V8;                          /*  HEIGHT          */
	volatile int V9;                          /*  DEPTH           */
	volatile int V10;                         /*  BITS-PER-PIXEL  */
	volatile object V11;                      /*  BITS-PER-LINE   */
	volatile int V12;                         /*  BYTES-PER-LINE  */
	volatile int V13;                         /*  LAST            */
	volatile int V14;                         /*  COUNT           */
	V4= ((V2))->in.in_slots[3];
	if((V3)!=Cnil){
	V5= (V3);
	goto L2597;}
	Lgetf(2,((V2))->in.in_slots[3],VV[22])    /*  GETF            */;
	if(VALUES(0)==Cnil)goto L2598;
	V5= VALUES(0);
	goto L2597;
L2598:
	V5= VV[13];
L2597:
	V6= fix(((V2))->in.in_slots[12]);
	(*LK1)(1,(V2))                            /*  IMAGE-WIDTH     */;
	V7= (fix(VALUES(0)))+(V6);
	(*LK2)(1,(V2))                            /*  IMAGE-HEIGHT    */;
	V8= fix(VALUES(0));
	if(!((((V2))->in.in_slots[4])==(VV[48]))){
	goto L2606;}
	(*LK3)(1,(V2))                            /*  IMAGE-DEPTH     */;
	V9= fix(VALUES(0));
	goto L2604;
L2606:
	V9= 1;
L2604:
	V10= fix(((V2))->in.in_slots[6]);
	V11= MAKE_FIXNUM((V7)*(V10));
	Lceiling(2,(V11),MAKE_FIXNUM(8))          /*  CEILING         */;
	V12= fix(VALUES(0));
	V13= (V12)*(V8);
	V14= 0;
	Lgetf(2,(V4),VV[23])                      /*  GETF            */;
	if(VALUES(0)==Cnil){
	goto L2613;}
	Lcopy_list(1,(V4))                        /*  COPY-LIST       */;
	V4= VALUES(0);
	{int V15;
	Lgetf(3,(V4),VV[23],Cnil)                 /*  GETF            */;
	V15= (fix(VALUES(0)))+(V6);
	{object V16;
	siLput_f(3,(V4),MAKE_FIXNUM(V15),VV[23])  /*  PUT-F           */;
	V16= VALUES(0);
	V4= (V16);
	}
	}
L2613:
	{volatile object V15;                     /*  .REPLY-BUFFER.  */
	(*LK12)(1,MAKE_FIXNUM(V13))               /*  ALLOCATE-REPLY-BUFFER*/;
	V15= VALUES(0);
	{ int V16; volatile bool unwinding = FALSE;
	if ((V16=frs_push(FRS_PROTECT,Cnil))) {
	V16--; unwinding = TRUE;} else {
	{volatile object V17;                     /*  DATA            */
	V17= ((V15))->in.in_slots[1];
	{volatile object V18;                     /*  DATA            */
	{ int V19;
	volatile object V20;                      /*  IMAGE-SWAP-FUNCTION*/
	volatile object V21;                      /*  IMAGE-SWAP-LSB-FIRST-P*/
	V19=L28(7,MAKE_FIXNUM(V10),((V2))->in.in_slots[10],((V2))->in.in_slots[8],((V2))->in.in_slots[7],MAKE_FIXNUM(32),Ct,Ct)/*  IMAGE-SWAP-FUNCTION*/;
	if (V19--==0) goto L2628;
	V20= VALUES(0);
	if (V19--==0) goto L2629;
	V21= VALUES(1);
	goto L2630;
L2628:
	V20= Cnil;
L2629:
	V21= Cnil;
L2630:
	T0= symbol_function((V20));
	funcall(10,T0,((V2))->in.in_slots[9],(V17),MAKE_FIXNUM(0),MAKE_FIXNUM(0),MAKE_FIXNUM(V12),((V2))->in.in_slots[5],MAKE_FIXNUM(V12),MAKE_FIXNUM(V8),(V21));}
	{volatile object V19;                     /*  DATA            */
	V19= (V17);
	Lstring_downcase(1,coerce_to_string((V5)))/*  STRING-DOWNCASE */;
	V5= VALUES(0);
	{volatile object V20;                     /*  FSTREAM         */
	(*LK37)(3,(V1),VV[191],VV[200])           /*  OPEN            */;
	V20= VALUES(0);
	{ int V21; volatile bool unwinding = FALSE;
	if ((V21=frs_push(FRS_PROTECT,Cnil))) {
	V21--; unwinding = TRUE;} else {
	Lformat(4,(V20),VV[201],(V5),MAKE_FIXNUM(V7))/*  FORMAT       */;
	Lformat(4,(V20),VV[202],(V5),MAKE_FIXNUM(V8))/*  FORMAT       */;
	if((V9)==(1)){
	goto L2638;}
	Lformat(4,(V20),VV[203],(V5),MAKE_FIXNUM(V9))/*  FORMAT       */;
L2638:
	if((V6)==0){
	goto L2641;}
	Lformat(4,(V20),VV[204],(V5),MAKE_FIXNUM(V6))/*  FORMAT       */;
L2641:
	{volatile object V22;                     /*  PROP            */
	V22= (V4);
L2646:
	if(!((V22)==Cnil)){
	goto L2647;}
	goto L2644;
L2647:
	if((memql(CAR((V22)),VV[205]))!=Cnil){
	goto L2650;}
	if(!(numberp(CADR((V22))))){
	goto L2650;}
	Lstring_downcase(1,coerce_to_string(CAR((V22))))/*  STRING-DOWNCASE*/;
	T0= VALUES(0);
	VALUES(0) = (VV[388]->s.s_gfdef);
	(*LK38)(5,code_char('\137'),code_char('\55'),T0,VV[159],VALUES(0))/*  SUBSTITUTE*/;
	T1= VALUES(0);
	Lformat(5,(V20),VV[206],(V5),T1,CADR((V22)))/*  FORMAT        */;
L2650:
	V22= CDDR((V22));
	goto L2646;
	}
L2644:
	Lformat(3,(V20),VV[207],(V5))             /*  FORMAT          */;
	{volatile int V22;
	volatile int V23;                         /*  I               */
	V22= V8;
	V23= 0;
L2666:
	if(!((V23)>=(V22))){
	goto L2667;}
	goto L2662;
L2667:
	{volatile int V25;
	volatile int V26;                         /*  J               */
	V25= V12;
	V26= 0;
L2674:
	if(!((V26)>=(V25))){
	goto L2675;}
	goto L2670;
L2675:
	if(!(((V14>=0&&15>0?(V14)%(15):imod(V14,15)))==0)){
	goto L2678;}
	terpri((V20));
	Lwrite_char(2,code_char('\40'),(V20))     /*  WRITE-CHAR      */;
L2678:
	Lwrite_string(2,VV[208],(V20))            /*  WRITE-STRING    */;
	{register int V28;                        /*  BYTE            */
	register object V29;                      /*  TRANSLATE       */
	V28= fix(aref1((V19),V14));
	V29= VV[209];
	Lwrite_char(2,code_char(((V29))->ust.ust_self[((((~(-1 << (4))) << (4)) & (V28)) >> (4))]),(V20))/*  WRITE-CHAR*/;
	Lwrite_char(2,code_char(((V29))->ust.ust_self[((((~(-1 << (4))) << (0)) & (V28)) >> (0))]),(V20))/*  WRITE-CHAR*/;
	}
	V14= (V14)+(1);
	if((V14)==(V13)){
	goto L2688;}
	Lwrite_char(2,code_char('\54'),(V20))     /*  WRITE-CHAR      */;
L2688:
	V26= (V26)+1;
	goto L2674;
	}
L2670:
	V23= (V23)+1;
	goto L2666;
	}
L2662:
	V21=Lformat(3,(V20),VV[210],(V20))        /*  FORMAT          */;
	}
	frs_pop();
	MV_SAVE(V21);
	Lclose(1,(V20))                           /*  CLOSE           */;
	MV_RESTORE(V21);
	if (unwinding) unwind(nlj_fr,nlj_tag,V21+1);
	else {
	V16=V21;}}
	}
	}
	}
	}
	}
	frs_pop();
	MV_SAVE(V16);
	(*LK13)(1,(V15))                          /*  DEALLOCATE-REPLY-BUFFER*/;
	MV_RESTORE(V16);
	if (unwinding) unwind(nlj_fr,nlj_tag,V16+1);
	else {
	RETURN(V16);}}
	}
	}
	}
}
/*	function definition for BITMAP-IMAGE                          */
static L76(int narg, ...)
{ VT77 VLEX77 CLSR77
	{int i=0;
	volatile object V1;
	volatile object V2;
	va_list args; va_start(args, narg);
	if (i==narg) goto L2699;
	V1= va_arg(args, object);
	i++;
	goto L2700;
L2699:
	V1= Cnil;
L2700:
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	if(type_of((V1))==t_cons||(V1)==Cnil){
	goto L2702;}
	V2= CONS((V1),(V2));
	V1= Cnil;
L2702:
	{volatile int V3;                         /*  WIDTH           */
	volatile int V4;                          /*  HEIGHT          */
	volatile object V5;                       /*  BITARRAY        */
	volatile int V6;                          /*  ROW             */
	V3= length(CAR((V2)));
	V4= length((V2));
	(*LK15)(3,list(2,MAKE_FIXNUM(V4),MAKE_FIXNUM(V3)),VV[138],VV[211])/*  MAKE-ARRAY*/;
	V5= VALUES(0);
	V6= 0;
	{volatile object V7;
	volatile object V8;                       /*  PATTERN         */
	V7= (V2);
	V8= Cnil;
L2716:
	if(!((V7)==Cnil)){
	goto L2717;}
	goto L2712;
L2717:
	V8= CAR((V7));
	{volatile int V10;
	volatile int V11;                         /*  COL             */
	V10= V3;
	V11= 0;
L2726:
	if(!((V11)>=(V10))){
	goto L2727;}
	goto L2722;
L2727:
	((V5))->a.a_self[V6*((V5))->a.a_dims[1]+V11]= aref1((V8),V11);
	V11= (V11)+1;
	goto L2726;
	}
L2722:
	V6= (V6)+(1);
	V7= CDR((V7));
	goto L2716;
	}
L2712:
	RETURN(L16(8,VV[82],MAKE_FIXNUM(V3),VV[83],MAKE_FIXNUM(V4),VV[85],(V1),VV[87],(V5))/*  CREATE-IMAGE*/);
	}
	}
}
/*	function definition for IMAGE-PIXMAP                          */
static L77(int narg, object V1, object V2, ...)
{ VT78 VLEX78 CLSR78
	{volatile object V3;
	volatile object V4;
	volatile object V5;
	volatile object V6;
	va_list args; va_start(args, V2);
	narg -=2;
	{ object keyvars[8];
	parse_key(narg,args,4,L77keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	}
	{volatile object V7;                      /*  IMAGE-WIDTH     */
	volatile object V8;                       /*  IMAGE-HEIGHT    */
	volatile object V9;                       /*  IMAGE-DEPTH     */
	volatile object V10;                      /*  WIDTH           */
	volatile object V11;                      /*  HEIGHT          */
	volatile object V12;                      /*  DEPTH           */
	volatile object V13;                      /*  PIXMAP          */
	volatile object V14;                      /*  GC              */
	(*LK1)(1,(V2))                            /*  IMAGE-WIDTH     */;
	V7= VALUES(0);
	(*LK2)(1,(V2))                            /*  IMAGE-HEIGHT    */;
	V8= VALUES(0);
	(*LK3)(1,(V2))                            /*  IMAGE-DEPTH     */;
	V9= VALUES(0);
	if((V4)!=Cnil){
	V10= (V4);
	goto L2742;}
	V10= (V7);
L2742:
	if((V5)!=Cnil){
	V11= (V5);
	goto L2743;}
	V11= (V8);
L2743:
	if((V6)!=Cnil){
	V12= (V6);
	goto L2744;}
	V12= (V9);
L2744:
	(*LK40)(8,VV[212],(V1),VV[82],(V10),VV[83],(V11),VV[84],(V12))/*  CREATE-PIXMAP*/;
	V13= VALUES(0);
	if((V3)!=Cnil){
	V14= (V3);
	goto L2746;}
	(*LK41)(6,VV[212],(V13),VV[213],MAKE_FIXNUM(1),VV[214],MAKE_FIXNUM(0))/*  CREATE-GCONTEXT*/;
	V14= VALUES(0);
L2746:
	if(number_compare((V12),(V9))==0){
	goto L2747;}
	if(!(number_compare((V9),MAKE_FIXNUM(1))==0)){
	goto L2751;}
	if(((V3))!=Cnil){
	goto L2747;}
	(*LK5)(3,VV[74],VV[75],VV[181])           /*  X-ERROR         */;
	goto L2747;
L2751:
	Lerror(3,VV[215],(V12),(V9))              /*  ERROR           */;
L2747:
	if(number_compare((V9),MAKE_FIXNUM(1))==0){
	goto L2758;}
	VALUES(0) = Cnil;
	goto L2757;
L2758:
	VALUES(0) = (V3);
L2757:
	L56(9,(V13),(V14),(V2),VV[216],MAKE_FIXNUM(0),VV[217],MAKE_FIXNUM(0),VV[218],VALUES(0))/*  PUT-IMAGE*/;
	{volatile object V15;                     /*  X               */
	V15= (V7);
L2762:
	if(!(number_compare((V15),(V10))>=0)){
	goto L2763;}
	goto L2760;
L2763:
	(*LK42)(9,(V13),(V14),MAKE_FIXNUM(0),MAKE_FIXNUM(0),(V7),(V8),(V13),(V15),MAKE_FIXNUM(0))/*  COPY-AREA*/;
	V7= number_plus((V7),(V7));
	V15= number_plus((V15),(V7));
	goto L2762;
	}
L2760:
	{volatile object V15;                     /*  Y               */
	V15= (V8);
L2774:
	if(!(number_compare((V15),(V11))>=0)){
	goto L2775;}
	goto L2772;
L2775:
	(*LK42)(9,(V13),(V14),MAKE_FIXNUM(0),MAKE_FIXNUM(0),(V7),(V8),(V13),MAKE_FIXNUM(0),(V15))/*  COPY-AREA*/;
	V8= number_plus((V8),(V8));
	V15= number_plus((V15),(V8));
	goto L2774;
	}
L2772:
	if(((V3))!=Cnil){
	goto L2784;}
	(*LK43)(1,(V14))                          /*  FREE-GCONTEXT   */;
L2784:
	VALUES(0) = (V13);
	RETURN(1);
	}
	}
}
static LKF43(int narg, ...) {TRAMPOLINK(VV[399],&LK43);}
static LKF42(int narg, ...) {TRAMPOLINK(VV[398],&LK42);}
static LKF41(int narg, ...) {TRAMPOLINK(VV[397],&LK41);}
static LKF40(int narg, ...) {TRAMPOLINK(VV[396],&LK40);}
static LKF39(int narg, ...) {TRAMPOLINK(VV[391],&LK39);}
static LKF38(int narg, ...) {TRAMPOLINK(VV[390],&LK38);}
static LKF37(int narg, ...) {TRAMPOLINK(VV[387],&LK37);}
static LKF36(int narg, ...) {TRAMPOLINK(VV[378],&LK36);}
static LKF35(int narg, ...) {TRAMPOLINK(VV[371],&LK35);}
static LKF34(int narg, ...) {TRAMPOLINK(VV[370],&LK34);}
static LKF33(int narg, ...) {TRAMPOLINK(VV[369],&LK33);}
static LKF32(int narg, ...) {TRAMPOLINK(VV[368],&LK32);}
static LKF31(int narg, ...) {TRAMPOLINK(VV[50],&LK31);}
static LKF30(int narg, ...) {TRAMPOLINK(VV[358],&LK30);}
static LKF29(int narg, ...) {TRAMPOLINK(VV[355],&LK29);}
static LKF28(int narg, ...) {TRAMPOLINK(VV[348],&LK28);}
static LKF27(int narg, ...) {TRAMPOLINK(VV[347],&LK27);}
static LKF26(int narg, ...) {TRAMPOLINK(VV[168],&LK26);}
static LKF25(int narg, ...) {TRAMPOLINK(VV[345],&LK25);}
static LKF24(int narg, ...) {TRAMPOLINK(VV[344],&LK24);}
static LKF23(int narg, ...) {TRAMPOLINK(VV[343],&LK23);}
static LKF22(int narg, ...) {TRAMPOLINK(VV[342],&LK22);}
static LKF21(int narg, ...) {TRAMPOLINK(VV[341],&LK21);}
static LKF20(int narg, ...) {TRAMPOLINK(VV[340],&LK20);}
static LKF19(int narg, ...) {TRAMPOLINK(VV[339],&LK19);}
static LKF18(int narg, ...) {TRAMPOLINK(VV[337],&LK18);}
static LKF17(int narg, ...) {TRAMPOLINK(VV[336],&LK17);}
static LKF16(int narg, ...) {TRAMPOLINK(VV[332],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[329],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[327],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[325],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[2],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[318],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[310],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[309],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[303],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[301],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[300],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[299],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[220],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[295],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[294],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[293],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[291],&LK0);}
