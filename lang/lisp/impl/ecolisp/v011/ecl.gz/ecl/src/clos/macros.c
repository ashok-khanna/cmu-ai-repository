
#include "macros.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	VV[1]->s.s_stype=(short)stp_special;
	if(VV[1]->s.s_dbind == OBJNULL){
	(VV[1]->s.s_dbind)= VV[0];}
	VV[3]->s.s_stype=(short)stp_special;
	if(VV[3]->s.s_dbind == OBJNULL){
	Lfind_package(1,VV[2])                    /*  FIND-PACKAGE    */;
	(VV[3]->s.s_dbind)= VALUES(0);}
	MF0(VV[48],L1);
	(void)putprop(VV[48],VV[Vdeb48],VV[49]);
	(void)putprop(VV[50],VV[13],siSpretty_print_format);
	
	MM0(VV[50],L2);
	MF0(VV[17],L3);
	(void)putprop(VV[17],VV[Vdeb17],VV[49]);
	MF0(VV[18],L4);
	(void)putprop(VV[18],VV[Vdeb18],VV[49]);
	putprop(VV[17],VV[18],VV[19]);
	remprop(VV[17],VV[20]);
	remprop(VV[17],VV[21]);
	putprop(VV[17],Cnil,VV[22]);
	MF0(VV[51],L5);
	(void)putprop(VV[51],VV[Vdeb51],VV[49]);
	(void)putprop(VV[52],VV[13],siSpretty_print_format);
	
	MM0(VV[52],L6);
	funcall(2,VV[53]->s.s_gfdef,VV[27])       /*  PROCLAIM        */;
	funcall(2,VV[53]->s.s_gfdef,VV[28])       /*  PROCLAIM        */;
	MM0(VV[54],L7);
	MM0(VV[55],L8);
	MM0(VV[56],L9);
	MM0(VV[57],L10);
	MM0(VV[58],L11);
	(void)putprop(VV[59],VV[41],siSpretty_print_format);
	
	MM0(VV[59],L12);
	(void)putprop(VV[60],VV[41],siSpretty_print_format);
	
	MM0(VV[60],L13);
	MF0(VV[61],L19);
	MF0(VV[62],L20);
	(void)putprop(VV[62],VV[Vdeb62],VV[49]);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	function definition for MAKE-KEYWORD                          */
static L1(int narg, object V1)
{ VT3 VLEX3 CLSR3
TTL:
	Lsymbol_name(1,(V1))                      /*  SYMBOL-NAME     */;
	RETURN(Lintern(2,VALUES(0),(VV[3]->s.s_dbind))/*  INTERN      */);
}
/*	macro definition for DOPLIST                                  */
static L2(int narg, object V1, object V2)
{ VT4 VLEX4 CLSR4
	{object V3=CDR(V1),V4,V5,V6,V7;
	{object V8= CAR(V3);
	V4= CAR(V8);
	V8=CDR(V8);
	V5= CAR(V8);}
	V3=CDR(V3);
	V6= CAR(V3);
	V3=CDR(V3);
	V7= V3;
	{object V9= list(3,list(2,VV[5],(V6)),(V4),(V5));
	{object V10= list(3,VV[8],(V4),VV[9]);
	{object V11= list(3,VV[8],(V5),VV[11]);
	VALUES(0) = list(3,VV[4],V9,list(6,VV[6],VV[7],V10,VV[10],V11,CONS(VV[12],(V7))));
	RETURN(1);}}}}
}
/*	function definition for FIND-CLASS                            */
static L3(int narg, object V1, ...)
{ VT5 VLEX5 CLSR5
	{int i=1;
	object V2;
	object V3;
	va_list args; va_start(args, V1);
	if (i==narg) goto L11;
	V2= va_arg(args, object);
	i++;
	if (i==narg) goto L12;
	V3= va_arg(args, object);
	i++;
	goto L13;
L11:
	V2= Ct;
L12:
	V3= Cnil;
L13:
	{object V4;                               /*  CLASS           */
	Lgethash(2,(V1),(VV[14]->s.s_dbind))      /*  GETHASH         */;
	V4= VALUES(0);
	if(((V4))==Cnil){
	goto L18;}
	VALUES(0) = (V4);
	RETURN(1);
L18:
	if(((V2))==Cnil){
	goto L21;}
	RETURN(Lerror(2,VV[15],(V1))              /*  ERROR           */);
L21:
	VALUES(0) = Cnil;
	RETURN(1);
	}
	}
}
/*	function definition for SETF-FIND-CLASS                       */
static L4(int narg, object V1, object V2)
{ VT6 VLEX6 CLSR6
TTL:
	(*LK0)(1,(V2))                            /*  CLASSP          */;
	if(VALUES(0)==Cnil){
	goto L24;}
	RETURN(siLhash_set(3,(V1),(VV[14]->s.s_dbind),(V2))/*  HASH-SET*/);
L24:
	RETURN(Lerror(2,VV[16],(V2))              /*  ERROR           */);
}
/*	function definition for LEGAL-CLASS-NAME-P                    */
static L5(int narg, object V1)
{ VT7 VLEX7 CLSR7
TTL:
	if(type_of((V1))==t_symbol){
	goto L26;}
	VALUES(0) = Cnil;
	RETURN(1);
L26:
	VALUES(0) = ((((type_of((V1))==t_symbol&&((V1))->s.s_hpack==keyword_package)?Ct:Cnil))==Cnil?Ct:Cnil);
	RETURN(1);
}
/*	macro definition for KEYWORD-BIND                             */
static L6(int narg, object V1, object V2)
{ VT8 VLEX8 CLSR8
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= V3;
	VALUES(0) = list(3,VV[23],list(2,VV[24],listA(3,VV[25],CONS(VV[26],(V4)),(V6))),(V5));
	RETURN(1);}
}
/*	macro definition for CLASS-NAME                               */
static L7(int narg, object V1, object V2)
{ VT9 VLEX9 CLSR9
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(3,VV[29],(V4),MAKE_FIXNUM(0));
	RETURN(1);}
}
/*	macro definition for CLASS-SUPERIORS                          */
static L8(int narg, object V1, object V2)
{ VT10 VLEX10 CLSR10
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(3,VV[29],(V4),MAKE_FIXNUM(1));
	RETURN(1);}
}
/*	macro definition for CLASS-INFERIORS                          */
static L9(int narg, object V1, object V2)
{ VT11 VLEX11 CLSR11
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(3,VV[29],(V4),MAKE_FIXNUM(2));
	RETURN(1);}
}
/*	macro definition for CLASS-SLOTS                              */
static L10(int narg, object V1, object V2)
{ VT12 VLEX12 CLSR12
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(3,VV[29],(V4),MAKE_FIXNUM(3));
	RETURN(1);}
}
/*	macro definition for SLOT-INDEX-TABLE                         */
static L11(int narg, object V1, object V2)
{ VT13 VLEX13 CLSR13
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(3,VV[30],VV[31],list(3,VV[29],(V4),MAKE_FIXNUM(5)));
	RETURN(1);}
}
/*	macro definition for PRINT-UNREADABLE-OBJECT                  */
static L12(int narg, object V1, object V2)
{ VT14 VLEX14 CLSR14
	{object V3=CDR(V1),V4,V5,V6;
	{object V7= CAR(V3);
	V4= CAR(V7);
	V7=CDR(V7);
	V5= CAR(V7);}
	V3=CDR(V3);
	V6= V3;
	{register object V8;                      /*  VAR             */
	Lgensym(0)                                /*  GENSYM          */;
	V8= VALUES(0);
	{object V9= list(2,list(2,(V8),(V5)),VV[33]);
	{object V10= list(3,VV[34],VV[35],(V8));
	{object V11= list(3,VV[34],VV[36],(V8));
	{object V12= list(4,VV[37],(V8),VV[38],list(2,VV[39],(V4)));
	VALUES(0) = listA(4,VV[32],V9,V10,append((V6),list(3,V11,V12,list(3,VV[34],VV[40],(V8)))));
	RETURN(1);}}}}
	}}
}
/*	macro definition for SYMBOL-MACROLET                          */
static L13(int narg, object V1, object V2)
{ VT15 VLEX15 CLSR15
	{object V3=CDR(V1),V4;
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(CAR(V3),env0));       /*  SYMBOL-EXPANSIONS*/
	V3=CDR(V3);
	V4= V3;
	CLV1=&CAR(env0=CONS(Cnil,env0));          /*  TRANSLATE       */
	*CLV1=make_cclosure(LC18,env0,&Cblock);
	{object V5;
	object V6= (V4);
	if(V6==Cnil){
	VALUES(0) = Cnil;
	goto L29;}
	T0=V5=CONS(Cnil,Cnil);
L30:
	{object V7;                               /*  FORM            */
	(*LK1)(3,CAR(V6),(V2),*CLV1)              /*  WALK-FORM       */;
	CAR(V5)= VALUES(0);
	}
	if((V6=CDR(V6))==Cnil){
	VALUES(0) = T0;
	goto L29;}
	V5=CDR(V5)=CONS(Cnil,Cnil);
	goto L30;}
L29:
	VALUES(0) = CONS(VV[12],VALUES(0));
	RETURN(1);}
}
/*	closure TRANSLATE                                             */
static LC18(int narg, object env0, object V1, object V2, object V3)
{ VT16 VLEX16 CLSR16
	narg--;
	{object scan=env0;
	CLV1= &CAR(scan);                         /*  TRANSLATE       */ scan=CDR(scan);
	CLV0= &CAR(scan);                         /*  SYMBOL-EXPANSIONS*/}
TTL:
	{register object V4;                      /*  SYMBOL-EXPANSION*/
	V4= Cnil;
	if(!(type_of((V1))==t_symbol)){
	goto L34;}
	if(!(((V2))==(VV[42]))){
	goto L34;}
	(*LK2)(2,(V1),(V3))                       /*  VARIABLE-LEXICAL-P*/;
	if(VALUES(0)!=Cnil){
	goto L34;}
	(*LK3)(2,(V1),(V3))                       /*  VARIABLE-SPECIAL-P*/;
	if(VALUES(0)!=Cnil){
	goto L34;}
	{register object x= (V1),V5= *CLV0;
	while(V5!=Cnil)
	if(CAR(V5) != Cnil && 
	eql(x,CAAR(V5))){
	V4= CAR(V5);
	goto L44;
	}else V5=CDR(V5);
	V4= Cnil;}
L44:
	if(((V4))==Cnil){
	goto L34;}
	VALUES(0) = CADR((V4));
	RETURN(1);
L34:
	if(type_of((V1))==t_cons||(V1)==Cnil){
	goto L46;}
	VALUES(0) = (V1);
	RETURN(1);
L46:
	if(!((VV[8])==(CAR((V1))))){
	goto L49;}
	if((CDDDR((V1)))==Cnil){
	goto L52;}
	{object V5= list(3,VV[8],CADR((V1)),CADDR((V1)));
	VALUES(0) = list(3,VV[12],V5,CONS(VV[8],CDDDR((V1))));
	RETURN(1);}
L52:
	if(!(type_of(CADR((V1)))==t_symbol)){
	goto L55;}
	(*LK2)(2,CADR((V1)),(V3))                 /*  VARIABLE-LEXICAL-P*/;
	if(VALUES(0)!=Cnil){
	goto L55;}
	(*LK3)(2,CADR((V1)),(V3))                 /*  VARIABLE-SPECIAL-P*/;
	if(VALUES(0)!=Cnil){
	goto L55;}
	{register object x= CADR((V1)),V6= *CLV0;
	while(V6!=Cnil)
	if(CAR(V6) != Cnil && 
	eql(x,CAAR(V6))){
	V4= CAR(V6);
	goto L63;
	}else V6=CDR(V6);
	V4= Cnil;}
L63:
	if(((V4))==Cnil){
	goto L55;}
	VALUES(0) = list(3,VV[43],CADR((V4)),CADDR((V1)));
	RETURN(1);
L55:
	VALUES(0) = (V1);
	RETURN(1);
L49:
	if(!((CAR((V1)))==(VV[44]))){
	goto L65;}
	{object V6;                               /*  VARS            */
	object V7;                                /*  GENSYMS         */
	V6= CADR((V1));
	{object V8;
	object V9= (V6);
	if(V9==Cnil){
	V7= Cnil;
	goto L68;}
	T0=V8=CONS(Cnil,Cnil);
L69:
	{object V10;                              /*  X               */
	Lgensym(0)                                /*  GENSYM          */;
	CAR(V8)= VALUES(0);
	}
	if((V9=CDR(V9))==Cnil){
	V7= T0;
	goto L68;}
	V8=CDR(V8)=CONS(Cnil,Cnil);
	goto L69;}
L68:
	{object V8= CADDR((V1));
	{object V9;
	object V10= (V6);
	object V11= (V7);
	if(V10==Cnil||V11==Cnil){
	VALUES(0) = Cnil;
	goto L72;}
	T0=V9=CONS(Cnil,Cnil);
L73:
	{object V12;                              /*  V               */
	object V13;                               /*  G               */
	CAR(V9)= list(3,VV[43],CAR(V10),CAR(V11));
	}
	if((V10=CDR(V10))==Cnil||(V11=CDR(V11))==Cnil){
	VALUES(0) = T0;
	goto L72;}
	V9=CDR(V9)=CONS(Cnil,Cnil);
	goto L73;}
L72:
	VALUES(0) = listA(4,VV[45],(V7),V8,VALUES(0));
	RETURN(1);}
	}
L65:
	if(!((CAR((V1)))==(VV[43]))){
	goto L76;}
	{object V9;
	object V10= CDR((V1));
	if(V10==Cnil){
	VALUES(0) = Cnil;
	goto L78;}
	T0=V9=CONS(Cnil,Cnil);
L79:
	{object V11;                              /*  FORM            */
	(*LK1)(3,CAR(V10),(V3),*CLV1)             /*  WALK-FORM       */;
	CAR(V9)= VALUES(0);
	}
	if((V10=CDR(V10))==Cnil){
	VALUES(0) = T0;
	goto L78;}
	V9=CDR(V9)=CONS(Cnil,Cnil);
	goto L79;}
L78:
	VALUES(1) = Ct;
	VALUES(0) = CONS(VV[43],VALUES(0));
	RETURN(2);
L76:
	VALUES(0) = (V1);
	RETURN(1);
	}
}
/*	function definition for SET-COMPILED-FUNCTION-NAME            */
static L19(int narg, object V1, object V2)
{
	object x;
	x=((type_of(V1) == t_cfun) || (type_of(V1) == t_cclosure))
     ? ((V1)->cf.cf_name = (V2))
     : (object)FEerror("~S is not a compiled-function.", 1, (V1));
	VALUES(0)=x;
	RETURN(1);
}
/*	function definition for SET-FUNCTION-NAME                     */
static L20(int narg, object V1, object V2)
{ VT17 VLEX17 CLSR17
TTL:
	(*LK4)(2,(V1),VV[46])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L83;}
	L19(2,(V1),(V2))                          /*  SET-COMPILED-FUNCTION-NAME*/;
	goto L81;
L83:
	if(!(type_of((V1))==t_cons||(V1)==Cnil)){
	goto L86;}
	if(!((CAR((V1)))==(VV[47]))){
	goto L86;}
	CAR(CDR((V1))) = (V2);
	goto L81;
L86:
	if(!(type_of((V1))==t_cons||(V1)==Cnil)){
	goto L81;}
	if(!((CAR((V1)))==(VV[25]))){
	goto L81;}
	CAR((V1)) = VV[47];
	{object V3;
	V3= CONS((V2),CDR((V1)));
	CDR((V1)) = (V3);
	}
L81:
	VALUES(0) = (V1);
	RETURN(1);
}
static LKF4(int narg, ...) {TRAMPOLINK(VV[71],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[70],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[69],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[68],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[65],&LK0);}
