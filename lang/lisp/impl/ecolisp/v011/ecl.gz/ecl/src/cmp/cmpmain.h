
/* (c) Copyright G. Attardi, 1993. */
int siLAmake_constant();
#define VT2
#define VLEX2
#define CLSR2
static L1(int, object, ...);
static intUobject L1keys[7]={98,99,100,101,102,103,104};
int Lmerge_pathnames();
int Lformat();
int Lformat();
int Lformat();
int Lpathname_directory();
int Lpathname_directory();
int Lpathname_name();
int Lpathname_name();
int Lpathname_directory();
int Lpathname_name();
int Lmake_pathname();
int Lpathname_directory();
int Lpathname_name();
int Lmake_pathname();
int Lpathname_directory();
int Lpathname_name();
int Lmake_pathname();
int Lpathname_directory();
int Lpathname_name();
int Lmake_pathname();
int Lget_macro_character();
int Lcopy_readtable();
int Lget_macro_character();
int Lget_dispatch_macro_character();
int Lcopy_readtable();
int Lget_dispatch_macro_character();
int Lset_dispatch_macro_character();
int Lread();
int Lread();
int Lset_dispatch_macro_character();
int Lclose();
int Lformat();
int Lpathname_name();
int Lclose();
int Lformat();
int Lformat();
int Lformat();
int Lformat();
int Ldelete_file();
int Ldelete_file();
int Ldelete_file();
int Ldelete_file();
int Ldelete_file();
int Ldelete_file();
int Lformat();
#define VT3 object T0;
#define VLEX3
#define CLSR3
static L2(int, object, ...);
int Lerror();
int Lformat();
int Lerror();
int Lfboundp();
int Lerror();
int Lerror();
int Lformat();
int Lformat();
int Lmake_pathname();
int Lmake_pathname();
int Lmake_pathname();
int Lmake_pathname();
int Lformat();
int Lclose();
int Lformat();
int Ldelete_file();
int Ldelete_file();
int Ldelete_file();
int Ldelete_file();
int Ldelete_file();
int Lformat();
int Lsymbol_value();
int Ldelete_file();
int Ldelete_file();
int Ldelete_file();
int Lformat();
#define VT4
#define VLEX4
#define CLSR4
static L3(int, ...);
static intUobject L3keys[2]={101,102};
int Lformat();
int Lmacro_function();
int Lerror();
int Lmake_broadcast_stream();
int siLfset();
int siLfset();
int Lclose();
int Lclose();
#define VT5
#define VLEX5
#define CLSR5 object env0, *CLV0,*CLV1;
static LC4(int, object, ...);
int Lapply();
#define VT6
#define VLEX6
#define CLSR6 object *CLV0,*CLV1;
static LC5(int, object, ...);
int Lapply();
#define VT7
#define VLEX7
#define CLSR7 object *CLV0,*CLV1;
static L6(int, object, object, object, object);
int Lwrite_bytes();
int Lclose();
int Lclose();
#define VT8
#define VLEX8
#define CLSR8
static L7(int, object, object);
int Lformat();
#define VT9
#define VLEX9
#define CLSR9
static LC8(int, object );
int Lsystem();
int Lcerror();
#define VT10
#define VLEX10
#define CLSR10
static L9(int, object, object);
int Lmake_string();
int Lread_bytes();
int Lwrite_bytes();
int Lclose();
int Lclose();
#define VT11
#define VLEX11
#define CLSR11
static L10(int);
int Lformat();
#define VT12
#define VLEX12
#define CLSR12
static struct codeblock Cblock;
#define VM12 0
#define VM11 0
#define VM10 0
#define VM9 0
#define VM8 0
#define VM7 0
#define VM6 0
#define VM5 0
#define VM4 0
#define VM3 1
#define VM2 0
#define VM1 113
static object VV[113];
static LKF0(int, ...);
static (*LK0)(int, ...)=LKF0;
static LKF1(int, ...);
static (*LK1)(int, ...)=LKF1;
static LKF2(int, ...);
static (*LK2)(int, ...)=LKF2;
static LKF3(int, ...);
static (*LK3)(int, ...)=LKF3;
static LKF4(int, ...);
static (*LK4)(int, ...)=LKF4;
static LKF5(int, ...);
static (*LK5)(int, ...)=LKF5;
static LKF6(int, ...);
static (*LK6)(int, ...)=LKF6;
static LKF7(int, ...);
static (*LK7)(int, ...)=LKF7;
static LKF8(int, ...);
static (*LK8)(int, ...)=LKF8;
