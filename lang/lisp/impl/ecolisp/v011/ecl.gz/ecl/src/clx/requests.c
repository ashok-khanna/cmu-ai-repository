
#include "requests.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	MF0key(VV[178],L1,23,L1keys);
	(void)putprop(VV[178],VV[Vdeb178],VV[179]);
	MF0(VV[180],L2);
	(void)putprop(VV[180],VV[Vdeb180],VV[179]);
	MF0(VV[181],L3);
	(void)putprop(VV[181],VV[Vdeb181],VV[179]);
	MF0(VV[182],L4);
	(void)putprop(VV[182],VV[Vdeb182],VV[179]);
	MF0(VV[183],L5);
	(void)putprop(VV[183],VV[Vdeb183],VV[179]);
	MF0(VV[184],L6);
	(void)putprop(VV[184],VV[Vdeb184],VV[179]);
	MF0(VV[185],L7);
	(void)putprop(VV[185],VV[Vdeb185],VV[179]);
	MF0(VV[186],L8);
	(void)putprop(VV[186],VV[Vdeb186],VV[179]);
	MF0(VV[187],L9);
	(void)putprop(VV[187],VV[Vdeb187],VV[179]);
	MF0(VV[188],L10);
	(void)putprop(VV[188],VV[Vdeb188],VV[179]);
	MF0(VV[189],L11);
	(void)putprop(VV[189],VV[Vdeb189],VV[179]);
	MF0(VV[190],L12);
	(void)putprop(VV[190],VV[Vdeb190],VV[179]);
	MF0key(VV[191],L13,1,L13keys);
	(void)putprop(VV[191],VV[Vdeb191],VV[179]);
	MF0(VV[192],L14);
	(void)putprop(VV[192],VV[Vdeb192],VV[179]);
	MF0(VV[193],L15);
	(void)putprop(VV[193],VV[Vdeb193],VV[179]);
	MF0(VV[194],L16);
	(void)putprop(VV[194],VV[Vdeb194],VV[179]);
	MF0(VV[195],L17);
	(void)putprop(VV[195],VV[Vdeb195],VV[179]);
	MF0key(VV[196],L18,4,L18keys);
	(void)putprop(VV[196],VV[Vdeb196],VV[179]);
	MF0(VV[197],L19);
	(void)putprop(VV[197],VV[Vdeb197],VV[179]);
	MF0key(VV[198],L20,6,L20keys);
	(void)putprop(VV[198],VV[Vdeb198],VV[179]);
	MF0(VV[199],L21);
	(void)putprop(VV[199],VV[Vdeb199],VV[179]);
	MF0key(VV[200],L22,1,L22keys);
	(void)putprop(VV[200],VV[Vdeb200],VV[179]);
	MF0(VV[59],L23);
	(void)putprop(VV[59],VV[Vdeb59],VV[179]);
	MF0(VV[201],L24);
	(void)putprop(VV[201],VV[Vdeb201],VV[179]);
	putprop(VV[59],VV[60],VV[61]);
	remprop(VV[59],VV[62]);
	remprop(VV[59],VV[63]);
	putprop(VV[59],Cnil,VV[64]);
	MF0(VV[202],L25);
	(void)putprop(VV[202],VV[Vdeb202],VV[179]);
	MF0key(VV[203],L26,2,L26keys);
	(void)putprop(VV[203],VV[Vdeb203],VV[179]);
	MF0key(VV[204],L27,6,L27keys);
	(void)putprop(VV[204],VV[Vdeb204],VV[179]);
	MF0key(VV[205],L28,1,L28keys);
	(void)putprop(VV[205],VV[Vdeb205],VV[179]);
	MF0key(VV[206],L29,6,L29keys);
	(void)putprop(VV[206],VV[Vdeb206],VV[179]);
	MF0key(VV[207],L30,1,L30keys);
	(void)putprop(VV[207],VV[Vdeb207],VV[179]);
	MF0(VV[208],L31);
	(void)putprop(VV[208],VV[Vdeb208],VV[179]);
	MF0key(VV[209],L32,4,L32keys);
	(void)putprop(VV[209],VV[Vdeb209],VV[179]);
	MF0key(VV[210],L33,1,L33keys);
	(void)putprop(VV[210],VV[Vdeb210],VV[179]);
	MF0key(VV[211],L34,4,L34keys);
	(void)putprop(VV[211],VV[Vdeb211],VV[179]);
	MF0key(VV[212],L35,1,L35keys);
	(void)putprop(VV[212],VV[Vdeb212],VV[179]);
	MF0(VV[213],L36);
	(void)putprop(VV[213],VV[Vdeb213],VV[179]);
	MF0(VV[99],L37);
	(void)putprop(VV[99],VV[Vdeb99],VV[179]);
	MF0(VV[100],L38);
	(void)putprop(VV[100],VV[Vdeb100],VV[179]);
	(void)putprop(VV[214],VV[101],siSpretty_print_format);
	
	MM0(VV[214],L39);
	MF0(VV[215],L40);
	(void)putprop(VV[215],VV[Vdeb215],VV[179]);
	MF0(VV[216],L41);
	(void)putprop(VV[216],VV[Vdeb216],VV[179]);
	MF0(VV[217],L42);
	(void)putprop(VV[217],VV[Vdeb217],VV[179]);
	MF0key(VV[218],L43,3,L43keys);
	(void)putprop(VV[218],VV[Vdeb218],VV[179]);
	MF0(VV[219],L44);
	(void)putprop(VV[219],VV[Vdeb219],VV[179]);
	MF0(VV[220],L45);
	(void)putprop(VV[220],VV[Vdeb220],VV[179]);
	MF0(VV[221],L46);
	(void)putprop(VV[221],VV[Vdeb221],VV[179]);
	MF0(VV[222],L47);
	(void)putprop(VV[222],VV[Vdeb222],VV[179]);
	MF0(VV[223],L48);
	(void)putprop(VV[223],VV[Vdeb223],VV[179]);
	MF0(VV[224],L49);
	(void)putprop(VV[224],VV[Vdeb224],VV[179]);
	MF0(VV[225],L50);
	(void)putprop(VV[225],VV[Vdeb225],VV[179]);
	MF0(VV[226],L51);
	(void)putprop(VV[226],VV[Vdeb226],VV[179]);
	MF0key(VV[227],L52,5,L52keys);
	(void)putprop(VV[227],VV[Vdeb227],VV[179]);
	MF0(VV[228],L53);
	(void)putprop(VV[228],VV[Vdeb228],VV[179]);
	MF0key(VV[229],L54,5,L54keys);
	(void)putprop(VV[229],VV[Vdeb229],VV[179]);
	MF0(VV[230],L55);
	(void)putprop(VV[230],VV[Vdeb230],VV[179]);
	MF0(VV[231],L56);
	(void)putprop(VV[231],VV[Vdeb231],VV[179]);
	MF0(VV[232],L57);
	(void)putprop(VV[232],VV[Vdeb232],VV[179]);
	MF0(VV[233],L58);
	(void)putprop(VV[233],VV[Vdeb233],VV[179]);
	MF0(VV[234],L59);
	(void)putprop(VV[234],VV[Vdeb234],VV[179]);
	MF0(VV[235],L60);
	(void)putprop(VV[235],VV[Vdeb235],VV[179]);
	MF0(VV[236],L61);
	(void)putprop(VV[236],VV[Vdeb236],VV[179]);
	MF0key(VV[237],L62,1,L62keys);
	(void)putprop(VV[237],VV[Vdeb237],VV[179]);
	MF0(VV[238],L64);
	(void)putprop(VV[238],VV[Vdeb238],VV[179]);
	MF0key(VV[239],L65,3,L65keys);
	(void)putprop(VV[239],VV[Vdeb239],VV[179]);
	MF0key(VV[240],L66,5,L66keys);
	(void)putprop(VV[240],VV[Vdeb240],VV[179]);
	MF0(VV[241],L67);
	(void)putprop(VV[241],VV[Vdeb241],VV[179]);
	MF0key(VV[242],L68,3,L68keys);
	(void)putprop(VV[242],VV[Vdeb242],VV[179]);
	MF0key(VV[243],L69,3,L69keys);
	(void)putprop(VV[243],VV[Vdeb243],VV[179]);
	MF0key(VV[244],L70,1,L70keys);
	(void)putprop(VV[244],VV[Vdeb244],VV[179]);
	MF0(VV[245],L71);
	(void)putprop(VV[245],VV[Vdeb245],VV[179]);
	MF0key(VV[246],L72,6,L72keys);
	(void)putprop(VV[246],VV[Vdeb246],VV[179]);
	MF0key(VV[247],L73,6,L73keys);
	(void)putprop(VV[247],VV[Vdeb247],VV[179]);
	MF0(VV[248],L74);
	(void)putprop(VV[248],VV[Vdeb248],VV[179]);
	MF0(VV[249],L75);
	(void)putprop(VV[249],VV[Vdeb249],VV[179]);
	MF0(VV[250],L76);
	(void)putprop(VV[250],VV[Vdeb250],VV[179]);
	MF0(VV[251],L77);
	(void)putprop(VV[251],VV[Vdeb251],VV[179]);
	MF0(VV[252],L78);
	(void)putprop(VV[252],VV[Vdeb252],VV[179]);
	MF0(VV[253],L79);
	(void)putprop(VV[253],VV[Vdeb253],VV[179]);
	MF0key(VV[254],L80,1,L80keys);
	(void)putprop(VV[254],VV[Vdeb254],VV[179]);
	MF0key(VV[255],L81,8,L81keys);
	(void)putprop(VV[255],VV[Vdeb255],VV[179]);
	MF0(VV[256],L82);
	(void)putprop(VV[256],VV[Vdeb256],VV[179]);
	MF0(VV[257],L83);
	(void)putprop(VV[257],VV[Vdeb257],VV[179]);
	MF0key(VV[154],L84,1,L84keys);
	(void)putprop(VV[154],VV[Vdeb154],VV[179]);
	MF0(VV[155],L85);
	(void)putprop(VV[155],VV[Vdeb155],VV[179]);
	putprop(VV[154],VV[155],VV[62]);
	remprop(VV[154],VV[61]);
	remprop(VV[154],VV[63]);
	putprop(VV[154],Cnil,VV[64]);
	MF0key(VV[258],L86,2,L86keys);
	(void)putprop(VV[258],VV[Vdeb258],VV[179]);
	MF0(VV[259],L88);
	(void)putprop(VV[259],VV[Vdeb259],VV[179]);
	MF0(VV[260],L89);
	(void)putprop(VV[260],VV[Vdeb260],VV[179]);
	MF0(VV[261],L90);
	(void)putprop(VV[261],VV[Vdeb261],VV[179]);
	MF0(VV[262],L91);
	(void)putprop(VV[262],VV[Vdeb262],VV[179]);
	MF0(VV[263],L92);
	(void)putprop(VV[263],VV[Vdeb263],VV[179]);
	MF0(VV[264],L93);
	(void)putprop(VV[264],VV[Vdeb264],VV[179]);
	MF0(VV[265],L94);
	(void)putprop(VV[265],VV[Vdeb265],VV[179]);
	MF0(VV[266],L95);
	(void)putprop(VV[266],VV[Vdeb266],VV[179]);
	MF0(VV[267],L96);
	(void)putprop(VV[267],VV[Vdeb267],VV[179]);
	MF0(VV[171],L97);
	(void)putprop(VV[171],VV[Vdeb171],VV[179]);
	MF0(VV[172],L98);
	(void)putprop(VV[172],VV[Vdeb172],VV[179]);
	putprop(VV[171],VV[172],VV[62]);
	remprop(VV[171],VV[61]);
	remprop(VV[171],VV[63]);
	putprop(VV[171],Cnil,VV[64]);
	MF0(VV[176],L99);
	(void)putprop(VV[176],VV[Vdeb176],VV[179]);
	MF0(VV[177],L100);
	(void)putprop(VV[177],VV[Vdeb177],VV[179]);
	putprop(VV[176],VV[177],VV[62]);
	remprop(VV[176],VV[61]);
	remprop(VV[176],VV[63]);
	putprop(VV[176],Cnil,VV[64]);
	MF0(VV[268],L101);
	(void)putprop(VV[268],VV[Vdeb268],VV[179]);
	MF0(VV[269],L102);
	(void)putprop(VV[269],VV[Vdeb269],VV[179]);
	MF0(VV[270],L103);
	(void)putprop(VV[270],VV[Vdeb270],VV[179]);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	function definition for CREATE-WINDOW                         */
static L1(int narg, ...)
{ VT3 VLEX3 CLSR3
	{object V1;
	object V2;
	int V3;
	int V4;
	int V5;
	int V6;
	int V7;
	int V8;
	object V9;
	object V10;
	object V11;
	object V12;
	object V13;
	object V14;
	object V15;
	object V16;
	object V17;
	object V18;
	register object V19;
	register object V20;
	object V21;
	object V22;
	object V23;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[46];
	parse_key(narg,args,23,L1keys,keyvars,OBJNULL,FALSE);
	V1= keyvars[0];
	if(keyvars[24]==Cnil){
	(*LK0)(3,VV[0],VV[1],VV[2])               /*  X-ERROR         */;
	V2= (VV[3]->s.s_dbind);
	}else{
	V2= keyvars[1];}
	if(keyvars[25]==Cnil){
	(*LK0)(3,VV[0],VV[1],VV[4])               /*  X-ERROR         */;
	V3= fix((VV[3]->s.s_dbind));
	}else{
	V3= fix(keyvars[2]);}
	if(keyvars[26]==Cnil){
	(*LK0)(3,VV[0],VV[1],VV[5])               /*  X-ERROR         */;
	V4= fix((VV[3]->s.s_dbind));
	}else{
	V4= fix(keyvars[3]);}
	if(keyvars[27]==Cnil){
	(*LK0)(3,VV[0],VV[1],VV[6])               /*  X-ERROR         */;
	V5= fix((VV[3]->s.s_dbind));
	}else{
	V5= fix(keyvars[4]);}
	if(keyvars[28]==Cnil){
	(*LK0)(3,VV[0],VV[1],VV[7])               /*  X-ERROR         */;
	V6= fix((VV[3]->s.s_dbind));
	}else{
	V6= fix(keyvars[5]);}
	if(keyvars[29]==Cnil){
	V7= 0;
	}else{
	V7= fix(keyvars[6]);}
	if(keyvars[30]==Cnil){
	V8= 0;
	}else{
	V8= fix(keyvars[7]);}
	if(keyvars[31]==Cnil){
	V9= VV[8];
	}else{
	V9= keyvars[8];}
	if(keyvars[32]==Cnil){
	V10= VV[8];
	}else{
	V10= keyvars[9];}
	V11= keyvars[10];
	V12= keyvars[11];
	V13= keyvars[12];
	V14= keyvars[13];
	V15= keyvars[14];
	V16= keyvars[15];
	V17= keyvars[16];
	V18= keyvars[17];
	V19= keyvars[18];
	V20= keyvars[19];
	V21= keyvars[20];
	V22= keyvars[21];
	V23= keyvars[22];
	}
	{object V24;                              /*  DISPLAY         */
	object V25;                               /*  WINDOW          */
	register int V26;                         /*  WID             */
	register object V27;                      /*  BACK-PIXMAP     */
	object V28;                               /*  BACK-PIXEL      */
	object V29;                               /*  BORDER-PIXMAP   */
	object V30;                               /*  BORDER-PIXEL    */
	V24= ((V2))->in.in_slots[1];
	if((V1)!=Cnil){
	V25= (V1);
	goto L36;}
	(*LK1)(2,VV[10],(V24))                    /*  MAKE-WINDOW     */;
	V25= VALUES(0);
L36:
	{object V31;                              /*  ID              */
	T0= ((V24))->in.in_slots[35];
	funcall(2,T0,(V24));
	V31= VALUES(0);
	(*LK2)(3,(V24),(V31),(V25))               /*  SAVE-ID         */;
	V26= fix((V31));
	}
	V27= Cnil;
	V28= Cnil;
	V29= Cnil;
	V30= Cnil;
	((V25))->in.in_slots[0]= MAKE_FIXNUM(V26);
	if(((V11)!= Cnil))goto L47;
	goto L46;
L47:
	if(((V11)!= VV[39]))goto L48;
	V27= MAKE_FIXNUM(0);
	goto L46;
L48:
	if(((V11)!= VV[297]))goto L50;
	V27= MAKE_FIXNUM(1);
	goto L46;
L50:
	(*LK3)(1,(V11))                           /*  PIXMAP-P        */;
	if(VALUES(0)==Cnil){
	goto L53;}
	V27= ((V11))->in.in_slots[0];
	goto L46;
L53:
	if(!(type_of((V11))==t_fixnum||type_of((V11))==t_bignum)){
	goto L57;}
	V28= (V11);
	goto L46;
L57:
	(*LK4)(2,(V11),VV[13])                    /*  X-TYPE-ERROR    */;
L46:
	if(((V12)!= Cnil))goto L61;
	goto L60;
L61:
	if(((V12)!= VV[8]))goto L62;
	V29= MAKE_FIXNUM(0);
	goto L60;
L62:
	(*LK3)(1,(V12))                           /*  PIXMAP-P        */;
	if(VALUES(0)==Cnil){
	goto L65;}
	V29= ((V12))->in.in_slots[0];
	goto L60;
L65:
	if(!(type_of((V12))==t_fixnum||type_of((V12))==t_bignum)){
	goto L69;}
	V30= (V12);
	goto L60;
L69:
	(*LK4)(2,(V12),VV[14])                    /*  X-TYPE-ERROR    */;
L60:
	if(((V19))==Cnil){
	goto L72;}
	(*LK5)(1,(V19))                           /*  ENCODE-EVENT-MASK*/;
	V19= VALUES(0);
L72:
	if(((V20))==Cnil){
	goto L76;}
	(*LK6)(1,(V20))                           /*  ENCODE-DEVICE-EVENT-MASK*/;
	V20= VALUES(0);
L76:
	{object V31;                              /*  .DISPLAY.       */
	V31= (V24);
	if((((V31))->in.in_slots[10])==Cnil){
	goto L81;}
	(*LK0)(3,VV[16],VV[10],(V31))             /*  X-ERROR         */;
L81:
	{object V32;                              /*  %BUFFER         */
	V32= (V31);
	if(!(((fix(((V32))->in.in_slots[6]))+(160))>=(fix(((V32))->in.in_slots[2])))){
	goto L85;}
	(*LK7)(1,(V32))                           /*  BUFFER-FLUSH    */;
L85:
	{register int V33;                        /*  BUFFER-BOFFSET  */
	register object V34;                      /*  BUFFER-BBUF     */
	V33= fix(((V32))->in.in_slots[6]);
	V34= ((V32))->in.in_slots[7];
	((V31))->in.in_slots[4]= MAKE_FIXNUM(V33);
	(((V34))->ust.ust_self[(V33)+(0)]=(1));
	(*LK8)(2,MAKE_FIXNUM(V7),VV[17])          /*  TYPEP           */;
	if(VALUES(0)!=Cnil){
	goto L97;}
	VALUES(0) = Cnil;
	goto L96;
L97:
	VALUES(0) = MAKE_FIXNUM((((V34))->ust.ust_self[(V33)+(1)]=(V7)));
L96:
	if(VALUES(0)==Cnil)goto L95;
	goto L94;
L95:
	(*LK4)(2,MAKE_FIXNUM(V7),VV[18])          /*  X-TYPE-ERROR    */;
L94:
	(*LK8)(2,MAKE_FIXNUM(V26),VV[19])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L101;}
	((*(unsigned long *)(((V34))->ust.ust_self+((V33)+(4))))=V26);
	goto L99;
L101:
	(*LK4)(2,MAKE_FIXNUM(V26),VV[19])         /*  X-TYPE-ERROR    */;
L99:
	(*LK9)(1,(V2))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L105;}
	((*(unsigned long *)(((V34))->ust.ust_self+((V33)+(8))))=fix(((V2))->in.in_slots[0]));
	goto L103;
L105:
	(*LK4)(2,(V2),VV[9])                      /*  X-TYPE-ERROR    */;
L103:
	(*LK8)(2,MAKE_FIXNUM(V3),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L109;}
	((*(short *)(((V34))->st.st_self+((V33)+(12))))=V3);
	goto L107;
L109:
	(*LK4)(2,MAKE_FIXNUM(V3),VV[20])          /*  X-TYPE-ERROR    */;
L107:
	(*LK8)(2,MAKE_FIXNUM(V4),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L113;}
	((*(short *)(((V34))->st.st_self+((V33)+(14))))=V4);
	goto L111;
L113:
	(*LK4)(2,MAKE_FIXNUM(V4),VV[20])          /*  X-TYPE-ERROR    */;
L111:
	(*LK8)(2,MAKE_FIXNUM(V5),VV[21])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L117;}
	((*(unsigned short *)(((V34))->ust.ust_self+((V33)+(16))))=V5);
	goto L115;
L117:
	(*LK4)(2,MAKE_FIXNUM(V5),VV[21])          /*  X-TYPE-ERROR    */;
L115:
	(*LK8)(2,MAKE_FIXNUM(V6),VV[21])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L121;}
	((*(unsigned short *)(((V34))->ust.ust_self+((V33)+(18))))=V6);
	goto L119;
L121:
	(*LK4)(2,MAKE_FIXNUM(V6),VV[21])          /*  X-TYPE-ERROR    */;
L119:
	(*LK8)(2,MAKE_FIXNUM(V8),VV[21])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L125;}
	((*(unsigned short *)(((V34))->ust.ust_self+((V33)+(20))))=V8);
	goto L123;
L125:
	(*LK4)(2,MAKE_FIXNUM(V8),VV[21])          /*  X-TYPE-ERROR    */;
L123:
	{int V35;
	VALUES(0) = (VV[305]->s.s_gfdef);
	(*LK10)(4,(V9),VV[22],VV[23],VALUES(0))   /*  POSITION        */;
	V35= fix(VALUES(0));
	if(MAKE_FIXNUM(V35)==Cnil){
	VALUES(0) = Cnil;
	goto L129;}
	VALUES(0) = MAKE_FIXNUM(((*(unsigned short *)(((V34))->ust.ust_self+((V33)+(22))))=V35));
	}
L129:
	if(VALUES(0)==Cnil)goto L128;
	goto L127;
L128:
	(*LK4)(2,(V9),VV[24])                     /*  X-TYPE-ERROR    */;
L127:
	{object V35;                              /*  .VALUE.         */
	if(!(((V10))==(VV[8]))){
	goto L135;}
	V35= MAKE_FIXNUM(0);
	goto L133;
L135:
	(*LK8)(2,(V10),VV[19])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L138;}
	V35= (V10);
	goto L133;
L138:
	V35= ((V10))->in.in_slots[0];
L133:
	(*LK8)(2,(V35),VV[19])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L141;}
	((*(unsigned long *)(((V34))->ust.ust_self+((V33)+(24))))=fix((V35)));
	goto L132;
L141:
	(*LK4)(2,(V35),VV[19])                    /*  X-TYPE-ERROR    */;
	}
L132:
	{register object V35;                     /*  %MASK           */
	register object V36;                      /*  %INDEX          */
	V35= MAKE_FIXNUM(0);
	V36= MAKE_FIXNUM(28);
	if(((V27))==Cnil){
	goto L144;}
	Llogior(2,(V35),MAKE_FIXNUM(1))           /*  LOGIOR          */;
	V35= VALUES(0);
	(*LK8)(2,(V27),VV[26])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L150;}
	V36= MAKE_FIXNUM((fix((V36)))+(4));
	VALUES(0) = (V36);
	((*(unsigned long *)(((V34))->ust.ust_self+((V33)+(fix(VALUES(0))))))=fix((V27)));
	goto L144;
L150:
	(*LK4)(2,(V27),VV[26])                    /*  X-TYPE-ERROR    */;
L144:
	if(((V28))==Cnil){
	goto L154;}
	Llogior(2,(V35),MAKE_FIXNUM(2))           /*  LOGIOR          */;
	V35= VALUES(0);
	(*LK8)(2,(V28),VV[26])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L160;}
	V36= MAKE_FIXNUM((fix((V36)))+(4));
	VALUES(0) = (V36);
	((*(unsigned long *)(((V34))->ust.ust_self+((V33)+(fix(VALUES(0))))))=fix((V28)));
	goto L154;
L160:
	(*LK4)(2,(V28),VV[26])                    /*  X-TYPE-ERROR    */;
L154:
	if(((V29))==Cnil){
	goto L164;}
	Llogior(2,(V35),MAKE_FIXNUM(4))           /*  LOGIOR          */;
	V35= VALUES(0);
	(*LK8)(2,(V29),VV[26])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L170;}
	V36= MAKE_FIXNUM((fix((V36)))+(4));
	VALUES(0) = (V36);
	((*(unsigned long *)(((V34))->ust.ust_self+((V33)+(fix(VALUES(0))))))=fix((V29)));
	goto L164;
L170:
	(*LK4)(2,(V29),VV[26])                    /*  X-TYPE-ERROR    */;
L164:
	if(((V30))==Cnil){
	goto L174;}
	Llogior(2,(V35),MAKE_FIXNUM(8))           /*  LOGIOR          */;
	V35= VALUES(0);
	(*LK8)(2,(V30),VV[26])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L180;}
	V36= MAKE_FIXNUM((fix((V36)))+(4));
	VALUES(0) = (V36);
	((*(unsigned long *)(((V34))->ust.ust_self+((V33)+(fix(VALUES(0))))))=fix((V30)));
	goto L174;
L180:
	(*LK4)(2,(V30),VV[26])                    /*  X-TYPE-ERROR    */;
L174:
	if(((V13))==Cnil){
	goto L184;}
	Llogior(2,(V35),MAKE_FIXNUM(16))          /*  LOGIOR          */;
	V35= VALUES(0);
	VALUES(0) = (VV[305]->s.s_gfdef);
	(*LK10)(4,(V13),VV[27],VV[23],VALUES(0))  /*  POSITION        */;
	T0= VALUES(0);
	V36= MAKE_FIXNUM((fix((V36)))+(4));
	VALUES(0) = (V36);
	VALUES(0) = MAKE_FIXNUM(((*(unsigned long *)(((V34))->ust.ust_self+((V33)+(fix(VALUES(0))))))=fix(T0)));
	if(VALUES(0)==Cnil)goto L189;
	goto L184;
L189:
	(*LK4)(2,(V13),VV[28])                    /*  X-TYPE-ERROR    */;
L184:
	if(((V14))==Cnil){
	goto L195;}
	Llogior(2,(V35),MAKE_FIXNUM(32))          /*  LOGIOR          */;
	V35= VALUES(0);
	VALUES(0) = (VV[305]->s.s_gfdef);
	(*LK10)(4,(V14),VV[29],VV[23],VALUES(0))  /*  POSITION        */;
	T0= VALUES(0);
	V36= MAKE_FIXNUM((fix((V36)))+(4));
	VALUES(0) = (V36);
	VALUES(0) = MAKE_FIXNUM(((*(unsigned long *)(((V34))->ust.ust_self+((V33)+(fix(VALUES(0))))))=fix(T0)));
	if(VALUES(0)==Cnil)goto L200;
	goto L195;
L200:
	(*LK4)(2,(V14),VV[30])                    /*  X-TYPE-ERROR    */;
L195:
	if(((V15))==Cnil){
	goto L206;}
	Llogior(2,(V35),MAKE_FIXNUM(64))          /*  LOGIOR          */;
	V35= VALUES(0);
	{int V37;
	VALUES(0) = (VV[305]->s.s_gfdef);
	(*LK10)(4,(V15),VV[31],VV[23],VALUES(0))  /*  POSITION        */;
	V37= fix(VALUES(0));
	if(MAKE_FIXNUM(V37)==Cnil){
	VALUES(0) = Cnil;
	goto L212;}
	V36= MAKE_FIXNUM((fix((V36)))+(4));
	VALUES(0) = (V36);
	VALUES(0) = MAKE_FIXNUM(((*(unsigned long *)(((V34))->ust.ust_self+((V33)+(fix(VALUES(0))))))=V37));
	}
L212:
	if(VALUES(0)==Cnil)goto L211;
	goto L206;
L211:
	(*LK4)(2,(V15),VV[32])                    /*  X-TYPE-ERROR    */;
L206:
	if(((V16))==Cnil){
	goto L217;}
	Llogior(2,(V35),MAKE_FIXNUM(128))         /*  LOGIOR          */;
	V35= VALUES(0);
	(*LK8)(2,(V16),VV[26])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L223;}
	V36= MAKE_FIXNUM((fix((V36)))+(4));
	VALUES(0) = (V36);
	((*(unsigned long *)(((V34))->ust.ust_self+((V33)+(fix(VALUES(0))))))=fix((V16)));
	goto L217;
L223:
	(*LK4)(2,(V16),VV[26])                    /*  X-TYPE-ERROR    */;
L217:
	if(((V17))==Cnil){
	goto L227;}
	Llogior(2,(V35),MAKE_FIXNUM(256))         /*  LOGIOR          */;
	V35= VALUES(0);
	(*LK8)(2,(V17),VV[26])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L233;}
	V36= MAKE_FIXNUM((fix((V36)))+(4));
	VALUES(0) = (V36);
	((*(unsigned long *)(((V34))->ust.ust_self+((V33)+(fix(VALUES(0))))))=fix((V17)));
	goto L227;
L233:
	(*LK4)(2,(V17),VV[26])                    /*  X-TYPE-ERROR    */;
L227:
	if(((V21))==Cnil){
	goto L237;}
	Llogior(2,(V35),MAKE_FIXNUM(512))         /*  LOGIOR          */;
	V35= VALUES(0);
	{int V37;
	VALUES(0) = (VV[305]->s.s_gfdef);
	(*LK10)(4,(V21),VV[33],VV[23],VALUES(0))  /*  POSITION        */;
	V37= fix(VALUES(0));
	if(MAKE_FIXNUM(V37)==Cnil){
	VALUES(0) = Cnil;
	goto L243;}
	V36= MAKE_FIXNUM((fix((V36)))+(4));
	VALUES(0) = (V36);
	VALUES(0) = MAKE_FIXNUM(((*(unsigned long *)(((V34))->ust.ust_self+((V33)+(fix(VALUES(0))))))=V37));
	}
L243:
	if(VALUES(0)==Cnil)goto L242;
	goto L237;
L242:
	(*LK4)(2,(V21),VV[34])                    /*  X-TYPE-ERROR    */;
L237:
	if(((V18))==Cnil){
	goto L248;}
	Llogior(2,(V35),MAKE_FIXNUM(1024))        /*  LOGIOR          */;
	V35= VALUES(0);
	{int V37;
	VALUES(0) = (VV[305]->s.s_gfdef);
	(*LK10)(4,(V18),VV[35],VV[23],VALUES(0))  /*  POSITION        */;
	V37= fix(VALUES(0));
	if(MAKE_FIXNUM(V37)==Cnil){
	VALUES(0) = Cnil;
	goto L254;}
	V36= MAKE_FIXNUM((fix((V36)))+(4));
	VALUES(0) = (V36);
	VALUES(0) = MAKE_FIXNUM(((*(unsigned long *)(((V34))->ust.ust_self+((V33)+(fix(VALUES(0))))))=V37));
	}
L254:
	if(VALUES(0)==Cnil)goto L253;
	goto L248;
L253:
	(*LK4)(2,(V18),VV[36])                    /*  X-TYPE-ERROR    */;
L248:
	if(((V19))==Cnil){
	goto L259;}
	Llogior(2,(V35),MAKE_FIXNUM(2048))        /*  LOGIOR          */;
	V35= VALUES(0);
	(*LK8)(2,(V19),VV[26])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L265;}
	V36= MAKE_FIXNUM((fix((V36)))+(4));
	VALUES(0) = (V36);
	((*(unsigned long *)(((V34))->ust.ust_self+((V33)+(fix(VALUES(0))))))=fix((V19)));
	goto L259;
L265:
	(*LK4)(2,(V19),VV[26])                    /*  X-TYPE-ERROR    */;
L259:
	if(((V20))==Cnil){
	goto L269;}
	Llogior(2,(V35),MAKE_FIXNUM(4096))        /*  LOGIOR          */;
	V35= VALUES(0);
	(*LK8)(2,(V20),VV[26])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L275;}
	V36= MAKE_FIXNUM((fix((V36)))+(4));
	VALUES(0) = (V36);
	((*(unsigned long *)(((V34))->ust.ust_self+((V33)+(fix(VALUES(0))))))=fix((V20)));
	goto L269;
L275:
	(*LK4)(2,(V20),VV[26])                    /*  X-TYPE-ERROR    */;
L269:
	if(((V22))==Cnil){
	goto L279;}
	Llogior(2,(V35),MAKE_FIXNUM(8192))        /*  LOGIOR          */;
	V35= VALUES(0);
	{object V37;
	if(((V22))==(VV[8])){
	goto L285;}
	V37= Cnil;
	goto L284;
L285:
	V36= MAKE_FIXNUM((fix((V36)))+(4));
	VALUES(0) = (V36);
	V37= MAKE_FIXNUM(((*(unsigned long *)(((V34))->ust.ust_self+((V33)+(fix(VALUES(0))))))=0));
L284:
	if(((V37))==Cnil){
	goto L290;}
	goto L279;
L290:
	(*LK11)(1,(V22))                          /*  COLORMAP-P      */;
	if(VALUES(0)==Cnil){
	goto L293;}
	V36= MAKE_FIXNUM((fix((V36)))+(4));
	VALUES(0) = (V36);
	((*(unsigned long *)(((V34))->ust.ust_self+((V33)+(fix(VALUES(0))))))=fix(((V22))->in.in_slots[0]));
	goto L279;
L293:
	(*LK4)(2,(V22),VV[38])                    /*  X-TYPE-ERROR    */;
	}
L279:
	if(((V23))==Cnil){
	goto L297;}
	Llogior(2,(V35),MAKE_FIXNUM(16384))       /*  LOGIOR          */;
	V35= VALUES(0);
	{object V37;
	if(((V23))==(VV[39])){
	goto L303;}
	V37= Cnil;
	goto L302;
L303:
	V36= MAKE_FIXNUM((fix((V36)))+(4));
	VALUES(0) = (V36);
	V37= MAKE_FIXNUM(((*(unsigned long *)(((V34))->ust.ust_self+((V33)+(fix(VALUES(0))))))=0));
L302:
	if(((V37))==Cnil){
	goto L308;}
	goto L297;
L308:
	(*LK12)(1,(V23))                          /*  CURSOR-P        */;
	if(VALUES(0)==Cnil){
	goto L311;}
	V36= MAKE_FIXNUM((fix((V36)))+(4));
	VALUES(0) = (V36);
	((*(unsigned long *)(((V34))->ust.ust_self+((V33)+(fix(VALUES(0))))))=fix(((V23))->in.in_slots[0]));
	goto L297;
L311:
	(*LK4)(2,(V23),VV[41])                    /*  X-TYPE-ERROR    */;
	}
L297:
	((*(unsigned long *)(((V34))->ust.ust_self+((V33)+(28))))=fix((V35)));
	V36= MAKE_FIXNUM((fix((V36)))+(4));
	VALUES(0) = (V36);
	Lceiling(2,VALUES(0),MAKE_FIXNUM(4))      /*  CEILING         */;
	T0= VALUES(0);
	((*(unsigned short *)(((V34))->ust.ust_self+((V33)+(2))))=fix(T0));
	{object V37;
	V37= number_plus(((V32))->in.in_slots[6],(V36));
	((V32))->in.in_slots[6]= (V37);
	}
	}
	(*LK13)(1,(V31))                          /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK14)(1,(V31))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	VALUES(0) = (V25);
	RETURN(1);
	}
	}
}
/*	function definition for DESTROY-WINDOW                        */
static L2(int narg, object V1)
{ VT4 VLEX4 CLSR4
TTL:
	{register object V2;                      /*  .DISPLAY.       */
	V2= ((V1))->in.in_slots[1];
	if((((V2))->in.in_slots[10])==Cnil){
	goto L322;}
	(*LK0)(3,VV[16],VV[10],(V2))              /*  X-ERROR         */;
L322:
	{ int V3;
	{register object V4;                      /*  %BUFFER         */
	V4= (V2);
	if(!(((fix(((V4))->in.in_slots[6]))+(160))>=(fix(((V4))->in.in_slots[2])))){
	goto L326;}
	(*LK7)(1,(V4))                            /*  BUFFER-FLUSH    */;
L326:
	{register int V5;                         /*  BUFFER-BOFFSET  */
	register object V6;                       /*  BUFFER-BBUF     */
	V5= fix(((V4))->in.in_slots[6]);
	V6= ((V4))->in.in_slots[7];
	((V2))->in.in_slots[4]= MAKE_FIXNUM(V5);
	(((V6))->ust.ust_self[(V5)+(0)]=(4));
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L337;}
	((*(unsigned long *)(((V6))->ust.ust_self+((V5)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L335;
L337:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L335:
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(2))))=2);
	((V2))->in.in_slots[6]= MAKE_FIXNUM((V5)+(8));
	V3=(*LK13)(1,(V2))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V3);
	(*LK14)(1,(V2))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V3);
	RETURN(V3);}
	}
}
/*	function definition for DESTROY-SUBWINDOWS                    */
static L3(int narg, object V1)
{ VT5 VLEX5 CLSR5
TTL:
	{register object V2;                      /*  .DISPLAY.       */
	V2= ((V1))->in.in_slots[1];
	if((((V2))->in.in_slots[10])==Cnil){
	goto L343;}
	(*LK0)(3,VV[16],VV[10],(V2))              /*  X-ERROR         */;
L343:
	{ int V3;
	{register object V4;                      /*  %BUFFER         */
	V4= (V2);
	if(!(((fix(((V4))->in.in_slots[6]))+(160))>=(fix(((V4))->in.in_slots[2])))){
	goto L347;}
	(*LK7)(1,(V4))                            /*  BUFFER-FLUSH    */;
L347:
	{register int V5;                         /*  BUFFER-BOFFSET  */
	register object V6;                       /*  BUFFER-BBUF     */
	V5= fix(((V4))->in.in_slots[6]);
	V6= ((V4))->in.in_slots[7];
	((V2))->in.in_slots[4]= MAKE_FIXNUM(V5);
	(((V6))->ust.ust_self[(V5)+(0)]=(5));
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L358;}
	((*(unsigned long *)(((V6))->ust.ust_self+((V5)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L356;
L358:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L356:
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(2))))=2);
	((V2))->in.in_slots[6]= MAKE_FIXNUM((V5)+(8));
	V3=(*LK13)(1,(V2))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V3);
	(*LK14)(1,(V2))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V3);
	RETURN(V3);}
	}
}
/*	function definition for ADD-TO-SAVE-SET                       */
static L4(int narg, object V1)
{ VT6 VLEX6 CLSR6
TTL:
	{register object V2;                      /*  .DISPLAY.       */
	V2= ((V1))->in.in_slots[1];
	if((((V2))->in.in_slots[10])==Cnil){
	goto L364;}
	(*LK0)(3,VV[16],VV[10],(V2))              /*  X-ERROR         */;
L364:
	{ int V3;
	{register object V4;                      /*  %BUFFER         */
	V4= (V2);
	if(!(((fix(((V4))->in.in_slots[6]))+(160))>=(fix(((V4))->in.in_slots[2])))){
	goto L368;}
	(*LK7)(1,(V4))                            /*  BUFFER-FLUSH    */;
L368:
	{register int V5;                         /*  BUFFER-BOFFSET  */
	register object V6;                       /*  BUFFER-BBUF     */
	V5= fix(((V4))->in.in_slots[6]);
	V6= ((V4))->in.in_slots[7];
	((V2))->in.in_slots[4]= MAKE_FIXNUM(V5);
	(((V6))->ust.ust_self[(V5)+(0)]=(6));
	(((V6))->ust.ust_self[(V5)+(1)]=(0));
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L380;}
	((*(unsigned long *)(((V6))->ust.ust_self+((V5)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L378;
L380:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L378:
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(2))))=2);
	((V2))->in.in_slots[6]= MAKE_FIXNUM((V5)+(8));
	V3=(*LK13)(1,(V2))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V3);
	(*LK14)(1,(V2))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V3);
	RETURN(V3);}
	}
}
/*	function definition for REMOVE-FROM-SAVE-SET                  */
static L5(int narg, object V1)
{ VT7 VLEX7 CLSR7
TTL:
	{register object V2;                      /*  .DISPLAY.       */
	V2= ((V1))->in.in_slots[1];
	if((((V2))->in.in_slots[10])==Cnil){
	goto L386;}
	(*LK0)(3,VV[16],VV[10],(V2))              /*  X-ERROR         */;
L386:
	{ int V3;
	{register object V4;                      /*  %BUFFER         */
	V4= (V2);
	if(!(((fix(((V4))->in.in_slots[6]))+(160))>=(fix(((V4))->in.in_slots[2])))){
	goto L390;}
	(*LK7)(1,(V4))                            /*  BUFFER-FLUSH    */;
L390:
	{register int V5;                         /*  BUFFER-BOFFSET  */
	register object V6;                       /*  BUFFER-BBUF     */
	V5= fix(((V4))->in.in_slots[6]);
	V6= ((V4))->in.in_slots[7];
	((V2))->in.in_slots[4]= MAKE_FIXNUM(V5);
	(((V6))->ust.ust_self[(V5)+(0)]=(6));
	(((V6))->ust.ust_self[(V5)+(1)]=(1));
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L402;}
	((*(unsigned long *)(((V6))->ust.ust_self+((V5)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L400;
L402:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L400:
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(2))))=2);
	((V2))->in.in_slots[6]= MAKE_FIXNUM((V5)+(8));
	V3=(*LK13)(1,(V2))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V3);
	(*LK14)(1,(V2))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V3);
	RETURN(V3);}
	}
}
/*	function definition for REPARENT-WINDOW                       */
static L6(int narg, object V1, object V2, object V3, object V4)
{ VT8 VLEX8 CLSR8
	{int V5;
	int V6;
	V5= fix(V3);
	V6= fix(V4);
TTL:
	{register object V7;                      /*  .DISPLAY.       */
	V7= ((V1))->in.in_slots[1];
	if((((V7))->in.in_slots[10])==Cnil){
	goto L408;}
	(*LK0)(3,VV[16],VV[10],(V7))              /*  X-ERROR         */;
L408:
	{ int V8;
	{register object V9;                      /*  %BUFFER         */
	V9= (V7);
	if(!(((fix(((V9))->in.in_slots[6]))+(160))>=(fix(((V9))->in.in_slots[2])))){
	goto L412;}
	(*LK7)(1,(V9))                            /*  BUFFER-FLUSH    */;
L412:
	{register int V10;                        /*  BUFFER-BOFFSET  */
	register object V11;                      /*  BUFFER-BBUF     */
	V10= fix(((V9))->in.in_slots[6]);
	V11= ((V9))->in.in_slots[7];
	((V7))->in.in_slots[4]= MAKE_FIXNUM(V10);
	(((V11))->ust.ust_self[(V10)+(0)]=(7));
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L423;}
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L421;
L423:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L421:
	(*LK9)(1,(V2))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L427;}
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(8))))=fix(((V2))->in.in_slots[0]));
	goto L425;
L427:
	(*LK4)(2,(V2),VV[9])                      /*  X-TYPE-ERROR    */;
L425:
	(*LK8)(2,MAKE_FIXNUM(V5),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L431;}
	((*(short *)(((V11))->st.st_self+((V10)+(12))))=V5);
	goto L429;
L431:
	(*LK4)(2,MAKE_FIXNUM(V5),VV[20])          /*  X-TYPE-ERROR    */;
L429:
	(*LK8)(2,MAKE_FIXNUM(V6),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L435;}
	((*(short *)(((V11))->st.st_self+((V10)+(14))))=V6);
	goto L433;
L435:
	(*LK4)(2,MAKE_FIXNUM(V6),VV[20])          /*  X-TYPE-ERROR    */;
L433:
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(2))))=4);
	((V7))->in.in_slots[6]= MAKE_FIXNUM((V10)+(16));
	V8=(*LK13)(1,(V7))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V8);
	(*LK14)(1,(V7))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V8);
	RETURN(V8);}
	}
	}
}
/*	function definition for MAP-WINDOW                            */
static L7(int narg, object V1)
{ VT9 VLEX9 CLSR9
TTL:
	{register object V2;                      /*  .DISPLAY.       */
	V2= ((V1))->in.in_slots[1];
	if((((V2))->in.in_slots[10])==Cnil){
	goto L441;}
	(*LK0)(3,VV[16],VV[10],(V2))              /*  X-ERROR         */;
L441:
	{ int V3;
	{register object V4;                      /*  %BUFFER         */
	V4= (V2);
	if(!(((fix(((V4))->in.in_slots[6]))+(160))>=(fix(((V4))->in.in_slots[2])))){
	goto L445;}
	(*LK7)(1,(V4))                            /*  BUFFER-FLUSH    */;
L445:
	{register int V5;                         /*  BUFFER-BOFFSET  */
	register object V6;                       /*  BUFFER-BBUF     */
	V5= fix(((V4))->in.in_slots[6]);
	V6= ((V4))->in.in_slots[7];
	((V2))->in.in_slots[4]= MAKE_FIXNUM(V5);
	(((V6))->ust.ust_self[(V5)+(0)]=(8));
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L456;}
	((*(unsigned long *)(((V6))->ust.ust_self+((V5)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L454;
L456:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L454:
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(2))))=2);
	((V2))->in.in_slots[6]= MAKE_FIXNUM((V5)+(8));
	V3=(*LK13)(1,(V2))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V3);
	(*LK14)(1,(V2))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V3);
	RETURN(V3);}
	}
}
/*	function definition for MAP-SUBWINDOWS                        */
static L8(int narg, object V1)
{ VT10 VLEX10 CLSR10
TTL:
	{register object V2;                      /*  .DISPLAY.       */
	V2= ((V1))->in.in_slots[1];
	if((((V2))->in.in_slots[10])==Cnil){
	goto L462;}
	(*LK0)(3,VV[16],VV[10],(V2))              /*  X-ERROR         */;
L462:
	{ int V3;
	{register object V4;                      /*  %BUFFER         */
	V4= (V2);
	if(!(((fix(((V4))->in.in_slots[6]))+(160))>=(fix(((V4))->in.in_slots[2])))){
	goto L466;}
	(*LK7)(1,(V4))                            /*  BUFFER-FLUSH    */;
L466:
	{register int V5;                         /*  BUFFER-BOFFSET  */
	register object V6;                       /*  BUFFER-BBUF     */
	V5= fix(((V4))->in.in_slots[6]);
	V6= ((V4))->in.in_slots[7];
	((V2))->in.in_slots[4]= MAKE_FIXNUM(V5);
	(((V6))->ust.ust_self[(V5)+(0)]=(9));
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L477;}
	((*(unsigned long *)(((V6))->ust.ust_self+((V5)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L475;
L477:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L475:
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(2))))=2);
	((V2))->in.in_slots[6]= MAKE_FIXNUM((V5)+(8));
	V3=(*LK13)(1,(V2))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V3);
	(*LK14)(1,(V2))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V3);
	RETURN(V3);}
	}
}
/*	function definition for UNMAP-WINDOW                          */
static L9(int narg, object V1)
{ VT11 VLEX11 CLSR11
TTL:
	{register object V2;                      /*  .DISPLAY.       */
	V2= ((V1))->in.in_slots[1];
	if((((V2))->in.in_slots[10])==Cnil){
	goto L483;}
	(*LK0)(3,VV[16],VV[10],(V2))              /*  X-ERROR         */;
L483:
	{ int V3;
	{register object V4;                      /*  %BUFFER         */
	V4= (V2);
	if(!(((fix(((V4))->in.in_slots[6]))+(160))>=(fix(((V4))->in.in_slots[2])))){
	goto L487;}
	(*LK7)(1,(V4))                            /*  BUFFER-FLUSH    */;
L487:
	{register int V5;                         /*  BUFFER-BOFFSET  */
	register object V6;                       /*  BUFFER-BBUF     */
	V5= fix(((V4))->in.in_slots[6]);
	V6= ((V4))->in.in_slots[7];
	((V2))->in.in_slots[4]= MAKE_FIXNUM(V5);
	(((V6))->ust.ust_self[(V5)+(0)]=(10));
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L498;}
	((*(unsigned long *)(((V6))->ust.ust_self+((V5)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L496;
L498:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L496:
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(2))))=2);
	((V2))->in.in_slots[6]= MAKE_FIXNUM((V5)+(8));
	V3=(*LK13)(1,(V2))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V3);
	(*LK14)(1,(V2))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V3);
	RETURN(V3);}
	}
}
/*	function definition for UNMAP-SUBWINDOWS                      */
static L10(int narg, object V1)
{ VT12 VLEX12 CLSR12
TTL:
	{register object V2;                      /*  .DISPLAY.       */
	V2= ((V1))->in.in_slots[1];
	if((((V2))->in.in_slots[10])==Cnil){
	goto L504;}
	(*LK0)(3,VV[16],VV[10],(V2))              /*  X-ERROR         */;
L504:
	{ int V3;
	{register object V4;                      /*  %BUFFER         */
	V4= (V2);
	if(!(((fix(((V4))->in.in_slots[6]))+(160))>=(fix(((V4))->in.in_slots[2])))){
	goto L508;}
	(*LK7)(1,(V4))                            /*  BUFFER-FLUSH    */;
L508:
	{register int V5;                         /*  BUFFER-BOFFSET  */
	register object V6;                       /*  BUFFER-BBUF     */
	V5= fix(((V4))->in.in_slots[6]);
	V6= ((V4))->in.in_slots[7];
	((V2))->in.in_slots[4]= MAKE_FIXNUM(V5);
	(((V6))->ust.ust_self[(V5)+(0)]=(11));
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L519;}
	((*(unsigned long *)(((V6))->ust.ust_self+((V5)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L517;
L519:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L517:
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(2))))=2);
	((V2))->in.in_slots[6]= MAKE_FIXNUM((V5)+(8));
	V3=(*LK13)(1,(V2))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V3);
	(*LK14)(1,(V2))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V3);
	RETURN(V3);}
	}
}
/*	function definition for CIRCULATE-WINDOW-UP                   */
static L11(int narg, object V1)
{ VT13 VLEX13 CLSR13
TTL:
	{register object V2;                      /*  .DISPLAY.       */
	V2= ((V1))->in.in_slots[1];
	if((((V2))->in.in_slots[10])==Cnil){
	goto L525;}
	(*LK0)(3,VV[16],VV[10],(V2))              /*  X-ERROR         */;
L525:
	{ int V3;
	{register object V4;                      /*  %BUFFER         */
	V4= (V2);
	if(!(((fix(((V4))->in.in_slots[6]))+(160))>=(fix(((V4))->in.in_slots[2])))){
	goto L529;}
	(*LK7)(1,(V4))                            /*  BUFFER-FLUSH    */;
L529:
	{register int V5;                         /*  BUFFER-BOFFSET  */
	register object V6;                       /*  BUFFER-BBUF     */
	V5= fix(((V4))->in.in_slots[6]);
	V6= ((V4))->in.in_slots[7];
	((V2))->in.in_slots[4]= MAKE_FIXNUM(V5);
	(((V6))->ust.ust_self[(V5)+(0)]=(13));
	(((V6))->ust.ust_self[(V5)+(1)]=(0));
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L541;}
	((*(unsigned long *)(((V6))->ust.ust_self+((V5)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L539;
L541:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L539:
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(2))))=2);
	((V2))->in.in_slots[6]= MAKE_FIXNUM((V5)+(8));
	V3=(*LK13)(1,(V2))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V3);
	(*LK14)(1,(V2))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V3);
	RETURN(V3);}
	}
}
/*	function definition for CIRCULATE-WINDOW-DOWN                 */
static L12(int narg, object V1)
{ VT14 VLEX14 CLSR14
TTL:
	{register object V2;                      /*  .DISPLAY.       */
	V2= ((V1))->in.in_slots[1];
	if((((V2))->in.in_slots[10])==Cnil){
	goto L547;}
	(*LK0)(3,VV[16],VV[10],(V2))              /*  X-ERROR         */;
L547:
	{ int V3;
	{register object V4;                      /*  %BUFFER         */
	V4= (V2);
	if(!(((fix(((V4))->in.in_slots[6]))+(160))>=(fix(((V4))->in.in_slots[2])))){
	goto L551;}
	(*LK7)(1,(V4))                            /*  BUFFER-FLUSH    */;
L551:
	{register int V5;                         /*  BUFFER-BOFFSET  */
	register object V6;                       /*  BUFFER-BBUF     */
	V5= fix(((V4))->in.in_slots[6]);
	V6= ((V4))->in.in_slots[7];
	((V2))->in.in_slots[4]= MAKE_FIXNUM(V5);
	(((V6))->ust.ust_self[(V5)+(0)]=(13));
	(((V6))->ust.ust_self[(V5)+(1)]=(1));
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L563;}
	((*(unsigned long *)(((V6))->ust.ust_self+((V5)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L561;
L563:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L561:
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(2))))=2);
	((V2))->in.in_slots[6]= MAKE_FIXNUM((V5)+(8));
	V3=(*LK13)(1,(V2))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V3);
	(*LK14)(1,(V2))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V3);
	RETURN(V3);}
	}
}
/*	function definition for QUERY-TREE                            */
static L13(int narg, object V1, ...)
{ VT15 VLEX15 CLSR15
	{volatile object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[2];
	parse_key(narg,args,1,L13keys,keyvars,OBJNULL,FALSE);
	if(keyvars[1]==Cnil){
	V2= VV[42];
	}else{
	V2= keyvars[0];}
	}
	{volatile object V3;                      /*  DISPLAY         */
	V3= ((V1))->in.in_slots[1];
	{ int V4;
	volatile object V5;                       /*  ROOT            */
	volatile object V6;                       /*  PARENT          */
	volatile object V7;                       /*  SEQUENCE        */
	{volatile object V8;                      /*  .DISPLAY.       */
	volatile object V9;                       /*  .PENDING-COMMAND.*/
	volatile object V10;                      /*  .REPLY-BUFFER.  */
	V8= (V3);
	V9= Cnil;
	V10= Cnil;
	{ int V11; volatile bool unwinding = FALSE;
	if ((V11=frs_push(FRS_PROTECT,Cnil))) {
	V11--; unwinding = TRUE;} else {
	if((((V8))->in.in_slots[10])==Cnil){
	goto L573;}
	(*LK0)(3,VV[16],VV[10],(V8))              /*  X-ERROR         */;
L573:
	(*LK15)(1,(V8))                           /*  START-PENDING-COMMAND*/;
	V9= VALUES(0);
	{register object V12;                     /*  %BUFFER         */
	V12= (V8);
	if(!(((fix(((V12))->in.in_slots[6]))+(160))>=(fix(((V12))->in.in_slots[2])))){
	goto L579;}
	(*LK7)(1,(V12))                           /*  BUFFER-FLUSH    */;
L579:
	{register int V13;                        /*  BUFFER-BOFFSET  */
	register object V14;                      /*  BUFFER-BBUF     */
	V13= fix(((V12))->in.in_slots[6]);
	V14= ((V12))->in.in_slots[7];
	((V8))->in.in_slots[4]= MAKE_FIXNUM(V13);
	(((V14))->ust.ust_self[(V13)+(0)]=(15));
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L590;}
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L588;
L590:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L588:
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(2))))=2);
	((V8))->in.in_slots[6]= MAKE_FIXNUM((V13)+(8));
	(*LK13)(1,(V8))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V8))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V8))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V8),(V9))                      /*  READ-REPLY      */;
	V10= VALUES(0);
	{object V12;                              /*  %REPLY-BUFFER   */
	object V13;                               /*  %BUFFER         */
	{register int V14;                        /*  BUFFER-BOFFSET  */
	register object V15;                      /*  BUFFER-BBUF     */
	V14= 0;
	V15= ((V10))->in.in_slots[1];
	(*LK18)(2,(V8),MAKE_FIXNUM(((*(unsigned long *)(((V15))->ust.ust_self+((V14)+(8)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T0= VALUES(0);
	{int V16= ((*(unsigned long *)(((V15))->ust.ust_self+((V14)+(12)))) & 0x1fffffff);
	(*LK19)(7,(V10),(V2),MAKE_FIXNUM((*(unsigned short *)(((V15))->ust.ust_self+((V14)+(16))))),Cnil,Cnil,MAKE_FIXNUM(0),MAKE_FIXNUM(32))/*  READ-SEQUENCE-CARD32*/;
	VALUES(2) = VALUES(0);
	VALUES(1) = MAKE_FIXNUM(V16);
	VALUES(0) = T0;
	V11=3;}
	}
	}
	}
	frs_pop();
	MV_SAVE(V11);
	if(((V10))==Cnil){
	goto L606;}
	(*LK20)(1,(V10))                          /*  DEALLOCATE-REPLY-BUFFER*/;
L606:
	if(((V9))==Cnil){
	goto L605;}
	(*LK21)(2,(V8),(V9))                      /*  STOP-PENDING-COMMAND*/;
L605:
	MV_RESTORE(V11);
	if (unwinding) unwind(nlj_fr,nlj_tag,V11+1);
	else {
	V4=V11;}}
	}
	if (V4--==0) goto L611;
	V5= VALUES(0);
	if (V4--==0) goto L612;
	V6= VALUES(1);
	if (V4--==0) goto L613;
	V7= VALUES(2);
	goto L614;
L611:
	V5= Cnil;
L612:
	V6= Cnil;
L613:
	V7= Cnil;
L614:
	if(number_compare(MAKE_FIXNUM(0),(V6))<0){
	goto L617;}
	V6= Cnil;
	goto L616;
L617:
	(*LK18)(2,(V3),(V6))                      /*  LOOKUP-WINDOW   */;
	V6= VALUES(0);
L616:
	{volatile int V8;
	volatile int V9;                          /*  I               */
	V8= length((V7));
	V9= 0;
L623:
	if(!((V9)>=(V8))){
	goto L624;}
	goto L619;
L624:
	(*LK18)(2,(V3),elt((V7),V9))              /*  LOOKUP-WINDOW   */;
	elt_set((V7),V9,VALUES(0));
	V9= (V9)+1;
	goto L623;
	}
L619:
	VALUES(2) = (V5);
	VALUES(1) = (V6);
	VALUES(0) = (V7);
	RETURN(3);}
	}
	}
}
/*	function definition for INTERN-ATOM                           */
static L14(int narg, object V1, object V2)
{ VT16 VLEX16 CLSR16
TTL:
	{volatile object V3;                      /*  NAME            */
	if(((V2))==Cnil){
	goto L633;}
	if(!((type_of((V2))==t_symbol&&((V2))->s.s_hpack==keyword_package))){
	goto L634;}
L633:
	V3= (V2);
	goto L632;
L634:
	(*LK22)(1,coerce_to_string((V2)))         /*  KINTERN         */;
	V3= VALUES(0);
L632:
	(*LK23)(2,(V3),(V1))                      /*  ATOM-ID         */;
	if(VALUES(0)==Cnil)goto L638;
	RETURN(1);
L638:
	{volatile object V4;                      /*  STRING          */
	V4= symbol_name((V3));
	{ int V5;
	volatile int V6;                          /*  ID              */
	{volatile object V7;                      /*  .DISPLAY.       */
	volatile object V8;                       /*  .PENDING-COMMAND.*/
	volatile object V9;                       /*  .REPLY-BUFFER.  */
	V7= (V1);
	V8= Cnil;
	V9= Cnil;
	{ int V10; volatile bool unwinding = FALSE;
	if ((V10=frs_push(FRS_PROTECT,Cnil))) {
	V10--; unwinding = TRUE;} else {
	if((((V7))->in.in_slots[10])==Cnil){
	goto L644;}
	(*LK0)(3,VV[16],VV[10],(V7))              /*  X-ERROR         */;
L644:
	(*LK15)(1,(V7))                           /*  START-PENDING-COMMAND*/;
	V8= VALUES(0);
	{register object V11;                     /*  %BUFFER         */
	V11= (V7);
	if(!(((fix(((V11))->in.in_slots[6]))+(160))>=(fix(((V11))->in.in_slots[2])))){
	goto L650;}
	(*LK7)(1,(V11))                           /*  BUFFER-FLUSH    */;
L650:
	{register int V12;                        /*  BUFFER-BOFFSET  */
	register object V13;                      /*  BUFFER-BBUF     */
	V12= fix(((V11))->in.in_slots[6]);
	V13= ((V11))->in.in_slots[7];
	((V7))->in.in_slots[4]= MAKE_FIXNUM(V12);
	(((V13))->ust.ust_self[(V12)+(0)]=(16));
	(((V13))->ust.ust_self[(V12)+(1)]=(0));
	{register int V14;                        /*  .VALUE.         */
	V14= ((V4))->v.v_fillp;
	(*LK8)(2,MAKE_FIXNUM(V14),VV[21])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L663;}
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(4))))=V14);
	goto L660;
L663:
	(*LK4)(2,MAKE_FIXNUM(V14),VV[21])         /*  X-TYPE-ERROR    */;
	}
L660:
	(*LK8)(2,(V4),VV[44])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L668;}
	{int V14;
	V14= ((V4))->v.v_fillp;
	Lceiling(2,MAKE_FIXNUM(((V14)-(0))+(8)),MAKE_FIXNUM(4))/*  CEILING*/;
	T0= VALUES(0);
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(2))))=fix(T0));
	(*LK24)(5,(V11),MAKE_FIXNUM((V12)+(8)),(V4),MAKE_FIXNUM(0),MAKE_FIXNUM(V14))/*  WRITE-SEQUENCE-CHAR*/;
	goto L666;
	}
L668:
	(*LK4)(2,(V4),VV[44])                     /*  X-TYPE-ERROR    */;
L666:
	(*LK13)(1,(V7))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V7))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V7))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V7),(V8))                      /*  READ-REPLY      */;
	V9= VALUES(0);
	{object V11;                              /*  %REPLY-BUFFER   */
	object V12;                               /*  %BUFFER         */
	{int V13;                                 /*  BUFFER-BOFFSET  */
	object V14;                               /*  BUFFER-BBUF     */
	V13= 0;
	V14= ((V9))->in.in_slots[1];
	VALUES(0)=MAKE_FIXNUM(((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(8)))) & 0x1fffffff));
	V10=1;
	}
	}
	}
	frs_pop();
	MV_SAVE(V10);
	if(((V9))==Cnil){
	goto L683;}
	(*LK20)(1,(V9))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L683:
	if(((V8))==Cnil){
	goto L682;}
	(*LK21)(2,(V7),(V8))                      /*  STOP-PENDING-COMMAND*/;
L682:
	MV_RESTORE(V10);
	if (unwinding) unwind(nlj_fr,nlj_tag,V10+1);
	else {
	V5=V10;}}
	}
	if (V5--==0) goto L688;
	V6= fix(VALUES(0));
	goto L689;
L688:
	V6= 0;
L689:
	(*LK25)(3,(V3),(V1),MAKE_FIXNUM(V6))      /*  SET-ATOM-ID     */;
	VALUES(0) = MAKE_FIXNUM(V6);
	RETURN(1);}
	}
	}
}
/*	function definition for FIND-ATOM                             */
static L15(int narg, object V1, object V2)
{ VT17 VLEX17 CLSR17
TTL:
	{volatile object V3;                      /*  NAME            */
	if(((V2))==Cnil){
	goto L692;}
	if(!((type_of((V2))==t_symbol&&((V2))->s.s_hpack==keyword_package))){
	goto L693;}
L692:
	V3= (V2);
	goto L691;
L693:
	(*LK22)(1,coerce_to_string((V2)))         /*  KINTERN         */;
	V3= VALUES(0);
L691:
	(*LK23)(2,(V3),(V1))                      /*  ATOM-ID         */;
	if(VALUES(0)==Cnil)goto L697;
	RETURN(1);
L697:
	{volatile object V4;                      /*  STRING          */
	V4= symbol_name((V3));
	{ int V5;
	volatile object V6;                       /*  ID              */
	{volatile object V7;                      /*  .DISPLAY.       */
	volatile object V8;                       /*  .PENDING-COMMAND.*/
	volatile object V9;                       /*  .REPLY-BUFFER.  */
	V7= (V1);
	V8= Cnil;
	V9= Cnil;
	{ int V10; volatile bool unwinding = FALSE;
	if ((V10=frs_push(FRS_PROTECT,Cnil))) {
	V10--; unwinding = TRUE;} else {
	if((((V7))->in.in_slots[10])==Cnil){
	goto L703;}
	(*LK0)(3,VV[16],VV[10],(V7))              /*  X-ERROR         */;
L703:
	(*LK15)(1,(V7))                           /*  START-PENDING-COMMAND*/;
	V8= VALUES(0);
	{register object V11;                     /*  %BUFFER         */
	V11= (V7);
	if(!(((fix(((V11))->in.in_slots[6]))+(160))>=(fix(((V11))->in.in_slots[2])))){
	goto L709;}
	(*LK7)(1,(V11))                           /*  BUFFER-FLUSH    */;
L709:
	{register int V12;                        /*  BUFFER-BOFFSET  */
	register object V13;                      /*  BUFFER-BBUF     */
	V12= fix(((V11))->in.in_slots[6]);
	V13= ((V11))->in.in_slots[7];
	((V7))->in.in_slots[4]= MAKE_FIXNUM(V12);
	(((V13))->ust.ust_self[(V12)+(0)]=(16));
	(((V13))->ust.ust_self[(V12)+(1)]=(1));
	{register int V14;                        /*  .VALUE.         */
	V14= ((V4))->v.v_fillp;
	(*LK8)(2,MAKE_FIXNUM(V14),VV[21])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L722;}
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(4))))=V14);
	goto L719;
L722:
	(*LK4)(2,MAKE_FIXNUM(V14),VV[21])         /*  X-TYPE-ERROR    */;
	}
L719:
	(*LK8)(2,(V4),VV[44])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L727;}
	{int V14;
	V14= ((V4))->v.v_fillp;
	Lceiling(2,MAKE_FIXNUM(((V14)-(0))+(8)),MAKE_FIXNUM(4))/*  CEILING*/;
	T0= VALUES(0);
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(2))))=fix(T0));
	(*LK24)(5,(V11),MAKE_FIXNUM((V12)+(8)),(V4),MAKE_FIXNUM(0),MAKE_FIXNUM(V14))/*  WRITE-SEQUENCE-CHAR*/;
	goto L725;
	}
L727:
	(*LK4)(2,(V4),VV[44])                     /*  X-TYPE-ERROR    */;
L725:
	(*LK13)(1,(V7))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V7))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V7))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V7),(V8))                      /*  READ-REPLY      */;
	V9= VALUES(0);
	{object V11;                              /*  %REPLY-BUFFER   */
	object V12;                               /*  %BUFFER         */
	{register int V13;                        /*  BUFFER-BOFFSET  */
	object V14;                               /*  BUFFER-BBUF     */
	V13= 0;
	V14= ((V9))->in.in_slots[1];
	{int V15;
	V15= (*(unsigned long *)(((V14))->ust.ust_self+((V13)+(8))));
	if(!((V15)==0)){
	goto L743;}
	VALUES(0)=Cnil;
	V10=1;
	goto L701;
L743:
	{int V16;
	V16= ((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(8)))) & 0x1fffffff);
	if((MAKE_FIXNUM(V16))==Cnil){
	goto L747;}
	VALUES(0)=MAKE_FIXNUM(V16);
	V10=1;
	goto L701;
L747:
	VALUES(0)=Cnil;
	V10=1;
	}
	}
	}
	}
L701:
	}
	frs_pop();
	MV_SAVE(V10);
	if(((V9))==Cnil){
	goto L750;}
	(*LK20)(1,(V9))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L750:
	if(((V8))==Cnil){
	goto L749;}
	(*LK21)(2,(V7),(V8))                      /*  STOP-PENDING-COMMAND*/;
L749:
	MV_RESTORE(V10);
	if (unwinding) unwind(nlj_fr,nlj_tag,V10+1);
	else {
	V5=V10;}}
	}
	if (V5--==0) goto L755;
	V6= VALUES(0);
	goto L756;
L755:
	V6= Cnil;
L756:
	if(((V6))==Cnil){
	goto L757;}
	(*LK25)(3,(V3),(V1),(V6))                 /*  SET-ATOM-ID     */;
L757:
	VALUES(0) = (V6);
	RETURN(1);}
	}
	}
}
/*	function definition for ATOM-NAME                             */
static L16(int narg, object V1, object V2)
{ VT18 VLEX18 CLSR18
	{volatile int V3;
	V3= fix(V2);
TTL:
	if(!((V3)==0)){
	goto L761;}
	VALUES(0) = Cnil;
	RETURN(1);
L761:
	(*LK26)(2,MAKE_FIXNUM(V3),(V1))           /*  ID-ATOM         */;
	if(VALUES(0)==Cnil)goto L763;
	RETURN(1);
L763:
	{volatile object V4;                      /*  KEYWORD         */
	{volatile object V5;                      /*  .DISPLAY.       */
	volatile object V6;                       /*  .PENDING-COMMAND.*/
	volatile object V7;                       /*  .REPLY-BUFFER.  */
	V5= (V1);
	V6= Cnil;
	V7= Cnil;
	{ int V8; volatile bool unwinding = FALSE;
	if ((V8=frs_push(FRS_PROTECT,Cnil))) {
	V8--; unwinding = TRUE;} else {
	if((((V5))->in.in_slots[10])==Cnil){
	goto L769;}
	(*LK0)(3,VV[16],VV[10],(V5))              /*  X-ERROR         */;
L769:
	(*LK15)(1,(V5))                           /*  START-PENDING-COMMAND*/;
	V6= VALUES(0);
	{register object V9;                      /*  %BUFFER         */
	V9= (V5);
	if(!(((fix(((V9))->in.in_slots[6]))+(160))>=(fix(((V9))->in.in_slots[2])))){
	goto L775;}
	(*LK7)(1,(V9))                            /*  BUFFER-FLUSH    */;
L775:
	{register int V10;                        /*  BUFFER-BOFFSET  */
	register object V11;                      /*  BUFFER-BBUF     */
	V10= fix(((V9))->in.in_slots[6]);
	V11= ((V9))->in.in_slots[7];
	((V5))->in.in_slots[4]= MAKE_FIXNUM(V10);
	(((V11))->ust.ust_self[(V10)+(0)]=(17));
	(*LK8)(2,MAKE_FIXNUM(V3),VV[19])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L786;}
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(4))))=V3);
	goto L784;
L786:
	(*LK4)(2,MAKE_FIXNUM(V3),VV[19])          /*  X-TYPE-ERROR    */;
L784:
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(2))))=2);
	((V5))->in.in_slots[6]= MAKE_FIXNUM((V10)+(8));
	(*LK13)(1,(V5))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V5))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V5))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V5),(V6))                      /*  READ-REPLY      */;
	V7= VALUES(0);
	{object V9;                               /*  %REPLY-BUFFER   */
	object V10;                               /*  %BUFFER         */
	{int V11;                                 /*  BUFFER-BOFFSET  */
	object V12;                               /*  BUFFER-BBUF     */
	V11= 0;
	V12= ((V7))->in.in_slots[1];
	V8=(*LK27)(7,(V7),VV[44],MAKE_FIXNUM((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(8))))),Cnil,Cnil,MAKE_FIXNUM(0),MAKE_FIXNUM(32))/*  READ-SEQUENCE-CHAR*/;
	}
	}
	}
	frs_pop();
	MV_SAVE(V8);
	if(((V7))==Cnil){
	goto L800;}
	(*LK20)(1,(V7))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L800:
	if(((V6))==Cnil){
	goto L799;}
	(*LK21)(2,(V5),(V6))                      /*  STOP-PENDING-COMMAND*/;
L799:
	MV_RESTORE(V8);
	if (unwinding) unwind(nlj_fr,nlj_tag,V8+1);
	else {}}
	}
	(*LK22)(1,VALUES(0))                      /*  KINTERN         */;
	V4= VALUES(0);
	(*LK25)(3,(V4),(V1),MAKE_FIXNUM(V3))      /*  SET-ATOM-ID     */;
	VALUES(0) = (V4);
	RETURN(1);
	}
	}
}
/*	function definition for LOOKUP-XATOM                          */
static L17(int narg, object V1, object V2)
{ VT19 VLEX19 CLSR19
TTL:
	RETURN(L16(2,(V1),(V2))                   /*  ATOM-NAME       */);
}
/*	function definition for CHANGE-PROPERTY                       */
static L18(int narg, object V1, object V2, object V3, object V4, object V5, ...)
{ VT20 VLEX20 CLSR20
	{register int V6;
	object V7;
	register int V8;
	register object V9;
	object V10;
	va_list args; va_start(args, V5);
	V6= fix(V5);
	narg -=5;
	{ object keyvars[8];
	parse_key(narg,args,4,L18keys,keyvars,OBJNULL,FALSE);
	if(keyvars[4]==Cnil){
	V7= VV[45];
	}else{
	V7= keyvars[0];}
	if(keyvars[5]==Cnil){
	V8= 0;
	}else{
	V8= fix(keyvars[1]);}
	V9= keyvars[2];
	V10= keyvars[3];
	}
	if(((V9))!=Cnil){
	goto L808;}
	V9= MAKE_FIXNUM(length((V3)));
L808:
	{object V11;                              /*  DISPLAY         */
	register int V12;                         /*  LENGTH          */
	register int V13;                         /*  PROPERTY-ID     */
	register int V14;                         /*  TYPE-ID         */
	V11= ((V1))->in.in_slots[1];
	V12= (fix((V9)))-(V8);
	L14(2,(V11),(V2))                         /*  INTERN-ATOM     */;
	V13= fix(VALUES(0));
	L14(2,(V11),(V4))                         /*  INTERN-ATOM     */;
	V14= fix(VALUES(0));
	{register object V15;                     /*  .DISPLAY.       */
	V15= (V11);
	if((((V15))->in.in_slots[10])==Cnil){
	goto L816;}
	(*LK0)(3,VV[16],VV[10],(V15))             /*  X-ERROR         */;
L816:
	{ int V16;
	{register object V17;                     /*  %BUFFER         */
	V17= (V15);
	if(!(((fix(((V17))->in.in_slots[6]))+(160))>=(fix(((V17))->in.in_slots[2])))){
	goto L820;}
	(*LK7)(1,(V17))                           /*  BUFFER-FLUSH    */;
L820:
	{register int V18;                        /*  BUFFER-BOFFSET  */
	register object V19;                      /*  BUFFER-BBUF     */
	V18= fix(((V17))->in.in_slots[6]);
	V19= ((V17))->in.in_slots[7];
	((V15))->in.in_slots[4]= MAKE_FIXNUM(V18);
	(((V19))->ust.ust_self[(V18)+(0)]=(18));
	(*LK8)(2,(V7),VV[46])                     /*  TYPEP           */;
	if(VALUES(0)!=Cnil){
	goto L832;}
	VALUES(0) = Cnil;
	goto L831;
L832:
	VALUES(0) = (VV[305]->s.s_gfdef);
	(*LK10)(4,(V7),VV[47],VV[23],VALUES(0))   /*  POSITION        */;
	T0= VALUES(0);
	{int V20= ((*(unsigned long *)(((V19))->ust.ust_self+((V18)+(4))))=fix(T0));
	VALUES(0) = MAKE_FIXNUM((((V19))->ust.ust_self[(V18)+(1)]=(V20)));}
L831:
	if(VALUES(0)==Cnil)goto L830;
	goto L829;
L830:
	(*LK4)(2,(V7),VV[48])                     /*  X-TYPE-ERROR    */;
L829:
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L838;}
	((*(unsigned long *)(((V19))->ust.ust_self+((V18)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L836;
L838:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L836:
	(*LK8)(2,MAKE_FIXNUM(V13),VV[19])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L842;}
	((*(unsigned long *)(((V19))->ust.ust_self+((V18)+(8))))=V13);
	goto L840;
L842:
	(*LK4)(2,MAKE_FIXNUM(V13),VV[19])         /*  X-TYPE-ERROR    */;
L840:
	(*LK8)(2,MAKE_FIXNUM(V14),VV[19])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L846;}
	((*(unsigned long *)(((V19))->ust.ust_self+((V18)+(12))))=V14);
	goto L844;
L846:
	(*LK4)(2,MAKE_FIXNUM(V14),VV[19])         /*  X-TYPE-ERROR    */;
L844:
	(*LK8)(2,MAKE_FIXNUM(V6),VV[17])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L850;}
	(((V19))->ust.ust_self[(V18)+(16)]=(V6));
	goto L848;
L850:
	(*LK4)(2,MAKE_FIXNUM(V6),VV[17])          /*  X-TYPE-ERROR    */;
L848:
	(*LK8)(2,MAKE_FIXNUM(V12),VV[26])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L854;}
	((*(unsigned long *)(((V19))->ust.ust_self+((V18)+(20))))=V12);
	goto L852;
L854:
	(*LK4)(2,MAKE_FIXNUM(V12),VV[26])         /*  X-TYPE-ERROR    */;
L852:
	{object V20;                              /*  .VALUE.         */
	if(!eql(MAKE_FIXNUM(V6),VV[49]))goto L858;
	{int V21;
	V21= fix((V9));
	Lceiling(2,MAKE_FIXNUM((V21)-(V8)),MAKE_FIXNUM(4))/*  CEILING */;
	((*(unsigned short *)(((V19))->ust.ust_self+((V18)+(2))))=(fix(VALUES(0)))+(6));
	(*LK28)(6,(V17),MAKE_FIXNUM((V18)+(24)),(V3),MAKE_FIXNUM(V8),MAKE_FIXNUM(V21),(V10))/*  WRITE-SEQUENCE-CARD8*/;
	V20= VALUES(0);
	goto L857;
	}
L858:
	if(!eql(MAKE_FIXNUM(V6),VV[50]))goto L862;
	{int V22;
	V22= fix((V9));
	Lceiling(2,MAKE_FIXNUM((V22)-(V8)),MAKE_FIXNUM(2))/*  CEILING */;
	((*(unsigned short *)(((V19))->ust.ust_self+((V18)+(2))))=(fix(VALUES(0)))+(6));
	(*LK29)(6,(V17),MAKE_FIXNUM((V18)+(24)),(V3),MAKE_FIXNUM(V8),MAKE_FIXNUM(V22),(V10))/*  WRITE-SEQUENCE-CARD16*/;
	V20= VALUES(0);
	goto L857;
	}
L862:
	if(!eql(MAKE_FIXNUM(V6),VV[51]))goto L866;
	{int V23;
	V23= fix((V9));
	((*(unsigned short *)(((V19))->ust.ust_self+((V18)+(2))))=((V23)-(V8))+(6));
	(*LK30)(6,(V17),MAKE_FIXNUM((V18)+(24)),(V3),MAKE_FIXNUM(V8),MAKE_FIXNUM(V23),(V10))/*  WRITE-SEQUENCE-CARD32*/;
	V20= VALUES(0);
	goto L857;
	}
L866:
	FEerror("The ECASE key value ~s is illegal.",1,MAKE_FIXNUM(V6));
L857:
	}
	V16=(*LK13)(1,(V15))                      /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V16);
	(*LK14)(1,(V15))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V16);
	RETURN(V16);}
	}
	}
	}
}
/*	function definition for DELETE-PROPERTY                       */
static L19(int narg, object V1, object V2)
{ VT21 VLEX21 CLSR21
TTL:
	{object V3;                               /*  DISPLAY         */
	register int V4;                          /*  PROPERTY-ID     */
	V3= ((V1))->in.in_slots[1];
	L14(2,(V3),(V2))                          /*  INTERN-ATOM     */;
	V4= fix(VALUES(0));
	{register object V5;                      /*  .DISPLAY.       */
	V5= (V3);
	if((((V5))->in.in_slots[10])==Cnil){
	goto L872;}
	(*LK0)(3,VV[16],VV[10],(V5))              /*  X-ERROR         */;
L872:
	{ int V6;
	{register object V7;                      /*  %BUFFER         */
	V7= (V5);
	if(!(((fix(((V7))->in.in_slots[6]))+(160))>=(fix(((V7))->in.in_slots[2])))){
	goto L876;}
	(*LK7)(1,(V7))                            /*  BUFFER-FLUSH    */;
L876:
	{register int V8;                         /*  BUFFER-BOFFSET  */
	register object V9;                       /*  BUFFER-BBUF     */
	V8= fix(((V7))->in.in_slots[6]);
	V9= ((V7))->in.in_slots[7];
	((V5))->in.in_slots[4]= MAKE_FIXNUM(V8);
	(((V9))->ust.ust_self[(V8)+(0)]=(19));
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L887;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L885;
L887:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L885:
	(*LK8)(2,MAKE_FIXNUM(V4),VV[19])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L891;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(8))))=V4);
	goto L889;
L891:
	(*LK4)(2,MAKE_FIXNUM(V4),VV[19])          /*  X-TYPE-ERROR    */;
L889:
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=3);
	((V5))->in.in_slots[6]= MAKE_FIXNUM((V8)+(12));
	V6=(*LK13)(1,(V5))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V6);
	(*LK14)(1,(V5))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V6);
	RETURN(V6);}
	}
	}
}
/*	function definition for GET-PROPERTY                          */
static L20(int narg, object V1, object V2, ...)
{ VT22 VLEX22 CLSR22
	{volatile object V3;
	volatile int V4;
	volatile object V5;
	volatile object V6;
	volatile object V7;
	volatile object V8;
	va_list args; va_start(args, V2);
	narg -=2;
	{ object keyvars[12];
	parse_key(narg,args,6,L20keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	if(keyvars[7]==Cnil){
	V4= 0;
	}else{
	V4= fix(keyvars[1]);}
	V5= keyvars[2];
	V6= keyvars[3];
	if(keyvars[10]==Cnil){
	V7= VV[42];
	}else{
	V7= keyvars[4];}
	V8= keyvars[5];
	}
	{volatile object V9;                      /*  DISPLAY         */
	volatile int V10;                         /*  PROPERTY-ID     */
	volatile object V11;                      /*  TYPE-ID         */
	V9= ((V1))->in.in_slots[1];
	L14(2,(V9),(V2))                          /*  INTERN-ATOM     */;
	V10= fix(VALUES(0));
	if((V3)==Cnil){
	V11= Cnil;
	goto L900;}
	L14(2,(V9),(V3))                          /*  INTERN-ATOM     */;
	V11= VALUES(0);
L900:
	{ int V12;
	volatile object V13;                      /*  REPLY-FORMAT    */
	volatile object V14;                      /*  REPLY-TYPE      */
	volatile object V15;                      /*  BYTES-AFTER     */
	volatile object V16;                      /*  DATA            */
	{volatile object V17;                     /*  .DISPLAY.       */
	volatile object V18;                      /*  .PENDING-COMMAND.*/
	volatile object V19;                      /*  .REPLY-BUFFER.  */
	V17= (V9);
	V18= Cnil;
	V19= Cnil;
	{ int V20; volatile bool unwinding = FALSE;
	if ((V20=frs_push(FRS_PROTECT,Cnil))) {
	V20--; unwinding = TRUE;} else {
	if((((V17))->in.in_slots[10])==Cnil){
	goto L904;}
	(*LK0)(3,VV[16],VV[10],(V17))             /*  X-ERROR         */;
L904:
	(*LK15)(1,(V17))                          /*  START-PENDING-COMMAND*/;
	V18= VALUES(0);
	{register object V21;                     /*  %BUFFER         */
	V21= (V17);
	if(!(((fix(((V21))->in.in_slots[6]))+(160))>=(fix(((V21))->in.in_slots[2])))){
	goto L910;}
	(*LK7)(1,(V21))                           /*  BUFFER-FLUSH    */;
L910:
	{register int V22;                        /*  BUFFER-BOFFSET  */
	register object V23;                      /*  BUFFER-BBUF     */
	V22= fix(((V21))->in.in_slots[6]);
	V23= ((V21))->in.in_slots[7];
	((V17))->in.in_slots[4]= MAKE_FIXNUM(V22);
	(((V23))->ust.ust_self[(V22)+(0)]=(20));
	if(((V6))==Cnil){
	goto L924;}
	T0= MAKE_FIXNUM(1);
	goto L922;
L924:
	T0= MAKE_FIXNUM(0);
L922:
	VALUES(0) = MAKE_FIXNUM((((V23))->ust.ust_self[(V22)+(1)]=(fix(T0))));
	if(VALUES(0)==Cnil)goto L920;
	goto L919;
L920:
	(*LK4)(2,(V6),VV[52])                     /*  X-TYPE-ERROR    */;
L919:
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L928;}
	((*(unsigned long *)(((V23))->ust.ust_self+((V22)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L926;
L928:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L926:
	(*LK8)(2,MAKE_FIXNUM(V10),VV[19])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L932;}
	((*(unsigned long *)(((V23))->ust.ust_self+((V22)+(8))))=V10);
	goto L930;
L932:
	(*LK4)(2,MAKE_FIXNUM(V10),VV[19])         /*  X-TYPE-ERROR    */;
L930:
	if(!((V11)==Cnil)){
	goto L936;}
	((*(unsigned long *)(((V23))->ust.ust_self+((V22)+(12))))=0);
	goto L934;
L936:
	(*LK8)(2,(V11),VV[19])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L939;}
	((*(unsigned long *)(((V23))->ust.ust_self+((V22)+(12))))=fix((V11)));
	goto L934;
L939:
	(*LK4)(2,(V11),VV[53])                    /*  X-TYPE-ERROR    */;
L934:
	(*LK8)(2,MAKE_FIXNUM(V4),VV[26])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L943;}
	((*(unsigned long *)(((V23))->ust.ust_self+((V22)+(16))))=V4);
	goto L941;
L943:
	(*LK4)(2,MAKE_FIXNUM(V4),VV[26])          /*  X-TYPE-ERROR    */;
L941:
	{register int V24;                        /*  .VALUE.         */
	if((V5)!=Cnil){
	VALUES(0) = (V5);
	goto L947;}
	VALUES(0) = MAKE_FIXNUM(64000);
L947:
	V24= (fix(VALUES(0)))-(V4);
	(*LK8)(2,MAKE_FIXNUM(V24),VV[26])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L949;}
	((*(unsigned long *)(((V23))->ust.ust_self+((V22)+(20))))=V24);
	goto L945;
L949:
	(*LK4)(2,MAKE_FIXNUM(V24),VV[26])         /*  X-TYPE-ERROR    */;
	}
L945:
	((*(unsigned short *)(((V23))->ust.ust_self+((V22)+(2))))=6);
	((V17))->in.in_slots[6]= MAKE_FIXNUM((V22)+(24));
	(*LK13)(1,(V17))                          /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V17))                          /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V17))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V17),(V18))                    /*  READ-REPLY      */;
	V19= VALUES(0);
	{register object V21;                     /*  %REPLY-BUFFER   */
	object V22;                               /*  %BUFFER         */
	V21= (V19);
	{register int V23;                        /*  BUFFER-BOFFSET  */
	register object V24;                      /*  BUFFER-BBUF     */
	V23= 0;
	V24= ((V21))->in.in_slots[1];
	{int V25;                                 /*  REPLY-FORMAT    */
	int V26;                                  /*  REPLY-TYPE      */
	int V27;                                  /*  BYTES-AFTER     */
	register int V28;                         /*  NITEMS          */
	V25= ((V24))->ust.ust_self[(V23)+(1)];
	V26= (*(unsigned long *)(((V24))->ust.ust_self+((V23)+(8))));
	V27= (*(unsigned long *)(((V24))->ust.ust_self+((V23)+(12))));
	V28= (*(unsigned long *)(((V24))->ust.ust_self+((V23)+(16))));
	if((V28)>0){
	goto L967;}
	VALUES(0) = Cnil;
	goto L966;
L967:
	if(!eql(MAKE_FIXNUM(V25),VV[54]))goto L969;
	VALUES(0) = Cnil;
	goto L966;
L969:
	if(!eql(MAKE_FIXNUM(V25),VV[49]))goto L970;
	(*LK31)(7,(V21),(V7),MAKE_FIXNUM(V28),(V8),Cnil,MAKE_FIXNUM(0),MAKE_FIXNUM(32))/*  READ-SEQUENCE-CARD8*/;
	goto L966;
L970:
	if(!eql(MAKE_FIXNUM(V25),VV[50]))goto L971;
	(*LK32)(7,(V21),(V7),MAKE_FIXNUM(V28),(V8),Cnil,MAKE_FIXNUM(0),MAKE_FIXNUM(32))/*  READ-SEQUENCE-CARD16*/;
	goto L966;
L971:
	if(!eql(MAKE_FIXNUM(V25),VV[51]))goto L972;
	(*LK19)(7,(V21),(V7),MAKE_FIXNUM(V28),(V8),Cnil,MAKE_FIXNUM(0),MAKE_FIXNUM(32))/*  READ-SEQUENCE-CARD32*/;
	goto L966;
L972:
	FEerror("The ECASE key value ~s is illegal.",1,MAKE_FIXNUM(V25));
L966:
	VALUES(3) = VALUES(0);
	VALUES(2) = MAKE_FIXNUM(V27);
	VALUES(1) = MAKE_FIXNUM(V26);
	VALUES(0) = MAKE_FIXNUM(V25);
	V20=4;
	}
	}
	}
	}
	frs_pop();
	MV_SAVE(V20);
	if(((V19))==Cnil){
	goto L974;}
	(*LK20)(1,(V19))                          /*  DEALLOCATE-REPLY-BUFFER*/;
L974:
	if(((V18))==Cnil){
	goto L973;}
	(*LK21)(2,(V17),(V18))                    /*  STOP-PENDING-COMMAND*/;
L973:
	MV_RESTORE(V20);
	if (unwinding) unwind(nlj_fr,nlj_tag,V20+1);
	else {
	V12=V20;}}
	}
	if (V12--==0) goto L979;
	V13= VALUES(0);
	if (V12--==0) goto L980;
	V14= VALUES(1);
	if (V12--==0) goto L981;
	V15= VALUES(2);
	if (V12--==0) goto L982;
	V16= VALUES(3);
	goto L983;
L979:
	V13= Cnil;
L980:
	V14= Cnil;
L981:
	V15= Cnil;
L982:
	V16= Cnil;
L983:
	if(number_compare(MAKE_FIXNUM(0),(V14))<0){
	goto L985;}
	VALUES(0) = Cnil;
	goto L984;
L985:
	L16(2,(V9),(V14))                         /*  ATOM-NAME       */;
L984:
	VALUES(3) = (V15);
	VALUES(2) = (V13);
	VALUES(1) = VALUES(0);
	VALUES(0) = (V16);
	RETURN(4);}
	}
	}
}
/*	function definition for ROTATE-PROPERTIES                     */
static L21(int narg, object V1, object V2, ...)
{ VT23 VLEX23 CLSR23
	{int i=2;
	volatile object V3;
	va_list args; va_start(args, V2);
	if (i==narg) goto L987;
	V3= va_arg(args, object);
	i++;
	goto L988;
L987:
	V3= MAKE_FIXNUM(1);
L988:
	{volatile object V4;                      /*  DISPLAY         */
	volatile int V5;                          /*  LENGTH          */
	volatile object V6;                       /*  SEQUENCE        */
	V4= ((V1))->in.in_slots[1];
	V5= length((V2));
	(*LK33)(1,MAKE_FIXNUM(V5))                /*  MAKE-ARRAY      */;
	V6= VALUES(0);
	{volatile object V7;                      /*  SEQUENCE        */
	V7= (V6);
	{volatile int V8;
	volatile int V9;                          /*  I               */
	V8= V5;
	V9= 0;
L998:
	if(!((V9)>=(V8))){
	goto L999;}
	goto L994;
L999:
	{register object V11;
	register object V12;
	V11= (V7);
	V12= MAKE_FIXNUM(V9);
	L14(2,(V4),elt((V2),V9))                  /*  INTERN-ATOM     */;
	((V11))->v.v_self[fix((V12))]= VALUES(0);
	}
	V9= (V9)+1;
	goto L998;
	}
L994:
	{register object V8;                      /*  .DISPLAY.       */
	V8= (V4);
	if((((V8))->in.in_slots[10])==Cnil){
	goto L1009;}
	(*LK0)(3,VV[16],VV[10],(V8))              /*  X-ERROR         */;
L1009:
	{register object V9;                      /*  %BUFFER         */
	V9= (V8);
	if(!(((fix(((V9))->in.in_slots[6]))+(160))>=(fix(((V9))->in.in_slots[2])))){
	goto L1013;}
	(*LK7)(1,(V9))                            /*  BUFFER-FLUSH    */;
L1013:
	{register int V10;                        /*  BUFFER-BOFFSET  */
	register object V11;                      /*  BUFFER-BBUF     */
	V10= fix(((V9))->in.in_slots[6]);
	V11= ((V9))->in.in_slots[7];
	((V8))->in.in_slots[4]= MAKE_FIXNUM(V10);
	(((V11))->ust.ust_self[(V10)+(0)]=(114));
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L1024;}
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L1022;
L1024:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L1022:
	(*LK8)(2,MAKE_FIXNUM(V5),VV[21])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1028;}
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(8))))=V5);
	goto L1026;
L1028:
	(*LK4)(2,MAKE_FIXNUM(V5),VV[21])          /*  X-TYPE-ERROR    */;
L1026:
	{object V12;                              /*  .VALUE.         */
	V12= number_negate((V3));
	(*LK8)(2,(V12),VV[20])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1033;}
	((*(short *)(((V11))->st.st_self+((V10)+(10))))=fix((V12)));
	goto L1030;
L1033:
	(*LK4)(2,(V12),VV[20])                    /*  X-TYPE-ERROR    */;
	}
L1030:
	(*LK8)(2,(V7),VV[55])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1037;}
	{int V12;
	V12= V5;
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(2))))=((V12)-(0))+(3));
	(*LK30)(6,(V9),MAKE_FIXNUM((V10)+(12)),(V7),MAKE_FIXNUM(0),MAKE_FIXNUM(V12),Cnil)/*  WRITE-SEQUENCE-CARD32*/;
	goto L1035;
	}
L1037:
	(*LK4)(2,(V7),VV[56])                     /*  X-TYPE-ERROR    */;
L1035:
	(*LK13)(1,(V8))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK14)(1,(V8))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for LIST-PROPERTIES                       */
static L22(int narg, object V1, ...)
{ VT24 VLEX24 CLSR24
	{volatile object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[2];
	parse_key(narg,args,1,L22keys,keyvars,OBJNULL,FALSE);
	if(keyvars[1]==Cnil){
	V2= VV[42];
	}else{
	V2= keyvars[0];}
	}
	{volatile object V3;                      /*  DISPLAY         */
	V3= ((V1))->in.in_slots[1];
	{ int V4;
	volatile object V5;                       /*  SEQ             */
	{volatile object V6;                      /*  .DISPLAY.       */
	volatile object V7;                       /*  .PENDING-COMMAND.*/
	volatile object V8;                       /*  .REPLY-BUFFER.  */
	V6= (V3);
	V7= Cnil;
	V8= Cnil;
	{ int V9; volatile bool unwinding = FALSE;
	if ((V9=frs_push(FRS_PROTECT,Cnil))) {
	V9--; unwinding = TRUE;} else {
	if((((V6))->in.in_slots[10])==Cnil){
	goto L1046;}
	(*LK0)(3,VV[16],VV[10],(V6))              /*  X-ERROR         */;
L1046:
	(*LK15)(1,(V6))                           /*  START-PENDING-COMMAND*/;
	V7= VALUES(0);
	{object V10;                              /*  %BUFFER         */
	V10= (V6);
	if(!(((fix(((V10))->in.in_slots[6]))+(160))>=(fix(((V10))->in.in_slots[2])))){
	goto L1052;}
	(*LK7)(1,(V10))                           /*  BUFFER-FLUSH    */;
L1052:
	{register int V11;                        /*  BUFFER-BOFFSET  */
	object V12;                               /*  BUFFER-BBUF     */
	V11= fix(((V10))->in.in_slots[6]);
	V12= ((V10))->in.in_slots[7];
	((V6))->in.in_slots[4]= MAKE_FIXNUM(V11);
	(((V12))->ust.ust_self[(V11)+(0)]=(21));
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L1063;}
	((*(unsigned long *)(((V12))->ust.ust_self+((V11)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L1061;
L1063:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L1061:
	((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(2))))=2);
	((V6))->in.in_slots[6]= MAKE_FIXNUM((V11)+(8));
	(*LK13)(1,(V6))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V6))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V6))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V6),(V7))                      /*  READ-REPLY      */;
	V8= VALUES(0);
	{object V10;                              /*  %REPLY-BUFFER   */
	object V11;                               /*  %BUFFER         */
	{int V12;                                 /*  BUFFER-BOFFSET  */
	object V13;                               /*  BUFFER-BBUF     */
	V12= 0;
	V13= ((V8))->in.in_slots[1];
	V9=(*LK19)(7,(V8),(V2),MAKE_FIXNUM((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(8))))),Cnil,Cnil,MAKE_FIXNUM(0),MAKE_FIXNUM(32))/*  READ-SEQUENCE-CARD32*/;
	}
	}
	}
	frs_pop();
	MV_SAVE(V9);
	if(((V8))==Cnil){
	goto L1077;}
	(*LK20)(1,(V8))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L1077:
	if(((V7))==Cnil){
	goto L1076;}
	(*LK21)(2,(V6),(V7))                      /*  STOP-PENDING-COMMAND*/;
L1076:
	MV_RESTORE(V9);
	if (unwinding) unwind(nlj_fr,nlj_tag,V9+1);
	else {
	V4=V9;}}
	}
	if (V4--==0) goto L1082;
	V5= VALUES(0);
	goto L1083;
L1082:
	V5= Cnil;
L1083:
	if(!(type_of((V5))==t_cons||(V5)==Cnil)){
	goto L1085;}
	{volatile object V6;                      /*  ELT             */
	V6= (V5);
L1088:
	if(!((V6)==Cnil)){
	goto L1089;}
	VALUES(0) = (V5);
	RETURN(1);
L1089:
	{register object V8;
	register object V9;
	V8= (V6);
	L16(2,(V3),CAR((V6)))                     /*  ATOM-NAME       */;
	V9= VALUES(0);
	CAR((V8)) = (V9);
	}
	V6= CDR((V6));
	goto L1088;
	}
L1085:
	{volatile int V10;
	volatile int V11;                         /*  I               */
	V10= length((V5));
	V11= 0;
L1102:
	if(!((V11)>=(V10))){
	goto L1103;}
	VALUES(0) = (V5);
	RETURN(1);
L1103:
	{register object V13;
	register object V14;
	V13= (V5);
	V14= MAKE_FIXNUM(V11);
	L16(2,(V3),aref1((V5),V11))               /*  ATOM-NAME       */;
	aset1((V13),fix((V14)),VALUES(0));
	}
	V11= (V11)+1;
	goto L1102;
	}}
	}
	}
}
/*	function definition for SELECTION-OWNER                       */
static L23(int narg, object V1, object V2)
{ VT25 VLEX25 CLSR25
TTL:
	{volatile int V3;                         /*  SELECTION-ID    */
	L14(2,(V1),(V2))                          /*  INTERN-ATOM     */;
	V3= fix(VALUES(0));
	{ int V4;
	volatile object V5;                       /*  WINDOW          */
	{volatile object V6;                      /*  .DISPLAY.       */
	volatile object V7;                       /*  .PENDING-COMMAND.*/
	volatile object V8;                       /*  .REPLY-BUFFER.  */
	V6= (V1);
	V7= Cnil;
	V8= Cnil;
	{ int V9; volatile bool unwinding = FALSE;
	if ((V9=frs_push(FRS_PROTECT,Cnil))) {
	V9--; unwinding = TRUE;} else {
	if((((V6))->in.in_slots[10])==Cnil){
	goto L1117;}
	(*LK0)(3,VV[16],VV[10],(V6))              /*  X-ERROR         */;
L1117:
	(*LK15)(1,(V6))                           /*  START-PENDING-COMMAND*/;
	V7= VALUES(0);
	{register object V10;                     /*  %BUFFER         */
	V10= (V6);
	if(!(((fix(((V10))->in.in_slots[6]))+(160))>=(fix(((V10))->in.in_slots[2])))){
	goto L1123;}
	(*LK7)(1,(V10))                           /*  BUFFER-FLUSH    */;
L1123:
	{register int V11;                        /*  BUFFER-BOFFSET  */
	register object V12;                      /*  BUFFER-BBUF     */
	V11= fix(((V10))->in.in_slots[6]);
	V12= ((V10))->in.in_slots[7];
	((V6))->in.in_slots[4]= MAKE_FIXNUM(V11);
	(((V12))->ust.ust_self[(V11)+(0)]=(23));
	(*LK8)(2,MAKE_FIXNUM(V3),VV[19])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1134;}
	((*(unsigned long *)(((V12))->ust.ust_self+((V11)+(4))))=V3);
	goto L1132;
L1134:
	(*LK4)(2,MAKE_FIXNUM(V3),VV[19])          /*  X-TYPE-ERROR    */;
L1132:
	((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(2))))=2);
	((V6))->in.in_slots[6]= MAKE_FIXNUM((V11)+(8));
	(*LK13)(1,(V6))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V6))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V6))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V6),(V7))                      /*  READ-REPLY      */;
	V8= VALUES(0);
	{object V10;                              /*  %REPLY-BUFFER   */
	object V11;                               /*  %BUFFER         */
	{int V12;                                 /*  BUFFER-BOFFSET  */
	object V13;                               /*  BUFFER-BBUF     */
	V12= 0;
	V13= ((V8))->in.in_slots[1];
	{int V14;
	V14= ((*(unsigned long *)(((V13))->ust.ust_self+((V12)+(8)))) & 0x1fffffff);
	if((V14)>0){
	goto L1148;}
	VALUES(0)=Cnil;
	V9=1;
	goto L1115;
L1148:
	VALUES(0)=MAKE_FIXNUM(V14);
	V9=1;
	}
	}
	}
L1115:
	}
	frs_pop();
	MV_SAVE(V9);
	if(((V8))==Cnil){
	goto L1151;}
	(*LK20)(1,(V8))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L1151:
	if(((V7))==Cnil){
	goto L1150;}
	(*LK21)(2,(V6),(V7))                      /*  STOP-PENDING-COMMAND*/;
L1150:
	MV_RESTORE(V9);
	if (unwinding) unwind(nlj_fr,nlj_tag,V9+1);
	else {
	V4=V9;}}
	}
	if (V4--==0) goto L1156;
	V5= VALUES(0);
	goto L1157;
L1156:
	V5= Cnil;
L1157:
	if((V5)==Cnil){
	VALUES(0) = Cnil;
	RETURN(1);}
	RETURN((*LK18)(2,(V1),(V5))               /*  LOOKUP-WINDOW   */);}
	}
}
/*	function definition for SET-SELECTION-OWNER                   */
static L24(int narg, object V1, object V2, object V3, ...)
{ VT26 VLEX26 CLSR26
	{int i=3;
	register object V4;
	va_list args; va_start(args, V3);
	if (i==narg) goto L1158;
	V4= va_arg(args, object);
	i++;
	goto L1159;
L1158:
	V4= Cnil;
L1159:
	{register int V5;                         /*  SELECTION-ID    */
	L14(2,(V1),(V2))                          /*  INTERN-ATOM     */;
	V5= fix(VALUES(0));
	{register object V6;                      /*  .DISPLAY.       */
	V6= (V1);
	if((((V6))->in.in_slots[10])==Cnil){
	goto L1163;}
	(*LK0)(3,VV[16],VV[10],(V6))              /*  X-ERROR         */;
L1163:
	{register object V7;                      /*  %BUFFER         */
	V7= (V6);
	if(!(((fix(((V7))->in.in_slots[6]))+(160))>=(fix(((V7))->in.in_slots[2])))){
	goto L1167;}
	(*LK7)(1,(V7))                            /*  BUFFER-FLUSH    */;
L1167:
	{register int V8;                         /*  BUFFER-BOFFSET  */
	register object V9;                       /*  BUFFER-BBUF     */
	V8= fix(((V7))->in.in_slots[6]);
	V9= ((V7))->in.in_slots[7];
	((V6))->in.in_slots[4]= MAKE_FIXNUM(V8);
	(((V9))->ust.ust_self[(V8)+(0)]=(22));
	if(!((V3)==Cnil)){
	goto L1178;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(4))))=0);
	goto L1176;
L1178:
	(*LK9)(1,(V3))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L1181;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(4))))=fix(((V3))->in.in_slots[0]));
	goto L1176;
L1181:
	(*LK4)(2,(V3),VV[57])                     /*  X-TYPE-ERROR    */;
L1176:
	(*LK8)(2,MAKE_FIXNUM(V5),VV[19])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1185;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(8))))=V5);
	goto L1183;
L1185:
	(*LK4)(2,MAKE_FIXNUM(V5),VV[19])          /*  X-TYPE-ERROR    */;
L1183:
	if(!((V4)==Cnil)){
	goto L1189;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(12))))=0);
	goto L1187;
L1189:
	(*LK8)(2,(V4),VV[26])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1192;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(12))))=fix((V4)));
	goto L1187;
L1192:
	(*LK4)(2,(V4),VV[58])                     /*  X-TYPE-ERROR    */;
L1187:
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=4);
	((V6))->in.in_slots[6]= MAKE_FIXNUM((V8)+(16));
	(*LK13)(1,(V6))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK14)(1,(V6))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	VALUES(0) = (V3);
	RETURN(1);
	}
	}
}
/*	function definition for CONVERT-SELECTION                     */
static L25(int narg, object V1, object V2, object V3, ...)
{ VT27 VLEX27 CLSR27
	{int i=3;
	object V4;
	register object V5;
	va_list args; va_start(args, V3);
	if (i==narg) goto L1196;
	V4= va_arg(args, object);
	i++;
	if (i==narg) goto L1197;
	V5= va_arg(args, object);
	i++;
	goto L1198;
L1196:
	V4= Cnil;
L1197:
	V5= Cnil;
L1198:
	{register object V6;                      /*  DISPLAY         */
	register int V7;                          /*  SELECTION-ID    */
	register int V8;                          /*  TYPE-ID         */
	register object V9;                       /*  PROPERTY-ID     */
	V6= ((V3))->in.in_slots[1];
	L14(2,(V6),(V1))                          /*  INTERN-ATOM     */;
	V7= fix(VALUES(0));
	L14(2,(V6),(V2))                          /*  INTERN-ATOM     */;
	V8= fix(VALUES(0));
	if((V4)==Cnil){
	V9= Cnil;
	goto L1204;}
	L14(2,(V6),(V4))                          /*  INTERN-ATOM     */;
	V9= VALUES(0);
L1204:
	{register object V10;                     /*  .DISPLAY.       */
	V10= (V6);
	if((((V10))->in.in_slots[10])==Cnil){
	goto L1205;}
	(*LK0)(3,VV[16],VV[10],(V10))             /*  X-ERROR         */;
L1205:
	{ int V11;
	{register object V12;                     /*  %BUFFER         */
	V12= (V10);
	if(!(((fix(((V12))->in.in_slots[6]))+(160))>=(fix(((V12))->in.in_slots[2])))){
	goto L1209;}
	(*LK7)(1,(V12))                           /*  BUFFER-FLUSH    */;
L1209:
	{register int V13;                        /*  BUFFER-BOFFSET  */
	register object V14;                      /*  BUFFER-BBUF     */
	V13= fix(((V12))->in.in_slots[6]);
	V14= ((V12))->in.in_slots[7];
	((V10))->in.in_slots[4]= MAKE_FIXNUM(V13);
	(((V14))->ust.ust_self[(V13)+(0)]=(24));
	(*LK9)(1,(V3))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L1220;}
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(4))))=fix(((V3))->in.in_slots[0]));
	goto L1218;
L1220:
	(*LK4)(2,(V3),VV[9])                      /*  X-TYPE-ERROR    */;
L1218:
	(*LK8)(2,MAKE_FIXNUM(V7),VV[19])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1224;}
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(8))))=V7);
	goto L1222;
L1224:
	(*LK4)(2,MAKE_FIXNUM(V7),VV[19])          /*  X-TYPE-ERROR    */;
L1222:
	(*LK8)(2,MAKE_FIXNUM(V8),VV[19])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1228;}
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(12))))=V8);
	goto L1226;
L1228:
	(*LK4)(2,MAKE_FIXNUM(V8),VV[19])          /*  X-TYPE-ERROR    */;
L1226:
	if(!((V9)==Cnil)){
	goto L1232;}
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(16))))=0);
	goto L1230;
L1232:
	(*LK8)(2,(V9),VV[19])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1235;}
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(16))))=fix((V9)));
	goto L1230;
L1235:
	(*LK4)(2,(V9),VV[65])                     /*  X-TYPE-ERROR    */;
L1230:
	if(!((V5)==Cnil)){
	goto L1239;}
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(20))))=0);
	goto L1237;
L1239:
	(*LK8)(2,(V5),VV[26])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1242;}
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(20))))=fix((V5)));
	goto L1237;
L1242:
	(*LK4)(2,(V5),VV[66])                     /*  X-TYPE-ERROR    */;
L1237:
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(2))))=6);
	((V10))->in.in_slots[6]= MAKE_FIXNUM((V13)+(24));
	V11=(*LK13)(1,(V10))                      /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V11);
	(*LK14)(1,(V10))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V11);
	RETURN(V11);}
	}
	}
	}
}
/*	function definition for SEND-EVENT                            */
static L26(int narg, object V1, object V2, object V3, ...)
{ VT28 VLEX28 CLSR28
	{volatile object V4;
	volatile object V5;
	volatile object V6;
	va_list args; va_start(args, V3);
	narg -=3;
	V4=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ int n=narg; object p=V4;
	 for(;n-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{ object keyvars[4];
	va_start(args,V3);
	parse_key(narg,args,2,L26keys,keyvars,V4,TRUE);
	V5= keyvars[0];
	V6= keyvars[1];
	}
	if(((V3))!=Cnil){
	goto L1247;}
	V3= MAKE_FIXNUM(0);
L1247:
	if(((V6))!=Cnil){
	goto L1251;}
	V6= ((V1))->in.in_slots[1];
L1251:
	{volatile int V7;                         /*  INTERNAL-EVENT-CODE*/
	volatile int V8;                          /*  EXTERNAL-EVENT-CODE*/
	(*LK34)(1,(V2))                           /*  GET-EVENT-CODE  */;
	V7= fix(VALUES(0));
	(*LK35)(2,(V6),(V2))                      /*  GET-EXTERNAL-EVENT-CODE*/;
	V8= fix(VALUES(0));
	{volatile object V9;
	volatile object V10;                      /*  ARG             */
	VALUES(0) = assq((V2),VV[67]);
	V9= CDR(VALUES(0));
	V10= Cnil;
L1262:
	if(!((V9)==Cnil)){
	goto L1263;}
	goto L1257;
L1263:
	V10= CAR((V9));
	{register object V12;                     /*  KEYWORD         */
	Lgetf(2,(V4),(V10))                       /*  GETF            */;
	V12= VALUES(0);
	L14(2,(V6),(V12))                         /*  INTERN-ATOM     */;
	}
	V9= CDR((V9));
	goto L1262;
	}
L1257:
	{object V9;                               /*  .DISPLAY.       */
	V9= (V6);
	if((((V9))->in.in_slots[10])==Cnil){
	goto L1273;}
	(*LK0)(3,VV[16],VV[10],(V9))              /*  X-ERROR         */;
L1273:
	{ int V10;
	{object V11;                              /*  %BUFFER         */
	V11= (V9);
	if(!(((fix(((V11))->in.in_slots[6]))+(160))>=(fix(((V11))->in.in_slots[2])))){
	goto L1277;}
	(*LK7)(1,(V11))                           /*  BUFFER-FLUSH    */;
L1277:
	{register int V12;                        /*  BUFFER-BOFFSET  */
	object V13;                               /*  BUFFER-BBUF     */
	V12= fix(((V11))->in.in_slots[6]);
	V13= ((V11))->in.in_slots[7];
	((V9))->in.in_slots[4]= MAKE_FIXNUM(V12);
	(((V13))->ust.ust_self[(V12)+(0)]=(25));
	if(((V5))==Cnil){
	goto L1291;}
	T0= MAKE_FIXNUM(1);
	goto L1289;
L1291:
	T0= MAKE_FIXNUM(0);
L1289:
	VALUES(0) = MAKE_FIXNUM((((V13))->ust.ust_self[(V12)+(1)]=(fix(T0))));
	if(VALUES(0)==Cnil)goto L1287;
	goto L1286;
L1287:
	(*LK4)(2,(V5),VV[68])                     /*  X-TYPE-ERROR    */;
L1286:
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(2))))=11);
	{object V14;
	{int V15;
	VALUES(0) = (VV[305]->s.s_gfdef);
	(*LK10)(4,(V1),VV[69],VV[23],VALUES(0))   /*  POSITION        */;
	V15= fix(VALUES(0));
	if(MAKE_FIXNUM(V15)==Cnil){
	V14= Cnil;
	goto L1295;}
	V14= MAKE_FIXNUM(((*(unsigned long *)(((V13))->ust.ust_self+((V12)+(4))))=V15));
	}
L1295:
	if(((V14))==Cnil){
	goto L1299;}
	goto L1294;
L1299:
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L1302;}
	((*(unsigned long *)(((V13))->ust.ust_self+((V12)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L1294;
L1302:
	(*LK4)(2,(V1),VV[70])                     /*  X-TYPE-ERROR    */;
	}
L1294:
	{object V14;                              /*  .VALUE.         */
	(*LK5)(1,(V3))                            /*  ENCODE-EVENT-MASK*/;
	V14= VALUES(0);
	(*LK8)(2,(V14),VV[26])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1307;}
	((*(unsigned long *)(((V13))->ust.ust_self+((V12)+(8))))=fix((V14)));
	goto L1304;
L1307:
	(*LK4)(2,(V14),VV[26])                    /*  X-TYPE-ERROR    */;
	}
L1304:
	(*LK8)(2,MAKE_FIXNUM(V8),VV[17])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1311;}
	(((V13))->ust.ust_self[(V12)+(12)]=(V8));
	goto L1309;
L1311:
	(*LK4)(2,MAKE_FIXNUM(V8),VV[17])          /*  X-TYPE-ERROR    */;
L1309:
	{object V14;                              /*  .VALUE.         */
	Lapply(3,((VV[71]->s.s_dbind))->v.v_self[V7],(V6),(V4))/*  APPLY*/;
	V14= VALUES(0);
	}
	{int V14;                                 /*  .VALUE.         */
	((V6))->in.in_slots[6]= MAKE_FIXNUM((V12)+(44));
	V14= (V12)+(44);
	}
	V10=(*LK13)(1,(V9))                       /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V10);
	(*LK14)(1,(V9))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V10);
	RETURN(V10);}
	}
	}
	}
}
/*	function definition for GRAB-POINTER                          */
static L27(int narg, object V1, object V2, ...)
{ VT29 VLEX29 CLSR29
	{volatile object V3;
	volatile object V4;
	volatile object V5;
	volatile object V6;
	volatile object V7;
	volatile object V8;
	va_list args; va_start(args, V2);
	narg -=2;
	{ object keyvars[12];
	parse_key(narg,args,6,L27keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	V7= keyvars[4];
	V8= keyvars[5];
	}
	{volatile object V9;                      /*  DISPLAY         */
	V9= ((V1))->in.in_slots[1];
	{volatile object V10;                     /*  .DISPLAY.       */
	volatile object V11;                      /*  .PENDING-COMMAND.*/
	volatile object V12;                      /*  .REPLY-BUFFER.  */
	V10= (V9);
	V11= Cnil;
	V12= Cnil;
	{ int V13; volatile bool unwinding = FALSE;
	if ((V13=frs_push(FRS_PROTECT,Cnil))) {
	V13--; unwinding = TRUE;} else {
	if((((V10))->in.in_slots[10])==Cnil){
	goto L1321;}
	(*LK0)(3,VV[16],VV[10],(V10))             /*  X-ERROR         */;
L1321:
	(*LK15)(1,(V10))                          /*  START-PENDING-COMMAND*/;
	V11= VALUES(0);
	{register object V14;                     /*  %BUFFER         */
	V14= (V10);
	if(!(((fix(((V14))->in.in_slots[6]))+(160))>=(fix(((V14))->in.in_slots[2])))){
	goto L1327;}
	(*LK7)(1,(V14))                           /*  BUFFER-FLUSH    */;
L1327:
	{register int V15;                        /*  BUFFER-BOFFSET  */
	register object V16;                      /*  BUFFER-BBUF     */
	V15= fix(((V14))->in.in_slots[6]);
	V16= ((V14))->in.in_slots[7];
	((V10))->in.in_slots[4]= MAKE_FIXNUM(V15);
	(((V16))->ust.ust_self[(V15)+(0)]=(26));
	if(((V3))==Cnil){
	goto L1341;}
	T0= MAKE_FIXNUM(1);
	goto L1339;
L1341:
	T0= MAKE_FIXNUM(0);
L1339:
	VALUES(0) = MAKE_FIXNUM((((V16))->ust.ust_self[(V15)+(1)]=(fix(T0))));
	if(VALUES(0)==Cnil)goto L1337;
	goto L1336;
L1337:
	(*LK4)(2,(V3),VV[72])                     /*  X-TYPE-ERROR    */;
L1336:
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L1345;}
	((*(unsigned long *)(((V16))->ust.ust_self+((V15)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L1343;
L1345:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L1343:
	{object V17;                              /*  .VALUE.         */
	(*LK36)(1,(V2))                           /*  ENCODE-POINTER-EVENT-MASK*/;
	V17= VALUES(0);
	(*LK8)(2,(V17),VV[21])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1350;}
	((*(unsigned short *)(((V16))->ust.ust_self+((V15)+(8))))=fix((V17)));
	goto L1347;
L1350:
	(*LK4)(2,(V17),VV[21])                    /*  X-TYPE-ERROR    */;
	}
L1347:
	{object V17;                              /*  .VALUE.         */
	V17= (((V4))==Cnil?Ct:Cnil);
	if(((V17))==Cnil){
	goto L1358;}
	T0= MAKE_FIXNUM(1);
	goto L1356;
L1358:
	T0= MAKE_FIXNUM(0);
L1356:
	(((V16))->ust.ust_self[(V15)+(10)]=(fix(T0)));
	goto L1352;
	(*LK4)(2,(V17),VV[73])                    /*  X-TYPE-ERROR    */;
	}
L1352:
	{object V17;                              /*  .VALUE.         */
	V17= (((V5))==Cnil?Ct:Cnil);
	if(((V17))==Cnil){
	goto L1366;}
	T0= MAKE_FIXNUM(1);
	goto L1364;
L1366:
	T0= MAKE_FIXNUM(0);
L1364:
	(((V16))->ust.ust_self[(V15)+(11)]=(fix(T0)));
	goto L1360;
	(*LK4)(2,(V17),VV[73])                    /*  X-TYPE-ERROR    */;
	}
L1360:
	if(!((V6)==Cnil)){
	goto L1370;}
	((*(unsigned long *)(((V16))->ust.ust_self+((V15)+(12))))=0);
	goto L1368;
L1370:
	(*LK9)(1,(V6))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L1373;}
	((*(unsigned long *)(((V16))->ust.ust_self+((V15)+(12))))=fix(((V6))->in.in_slots[0]));
	goto L1368;
L1373:
	(*LK4)(2,(V6),VV[74])                     /*  X-TYPE-ERROR    */;
L1368:
	if(!((V7)==Cnil)){
	goto L1377;}
	((*(unsigned long *)(((V16))->ust.ust_self+((V15)+(16))))=0);
	goto L1375;
L1377:
	(*LK12)(1,(V7))                           /*  CURSOR-P        */;
	if(VALUES(0)==Cnil){
	goto L1380;}
	((*(unsigned long *)(((V16))->ust.ust_self+((V15)+(16))))=fix(((V7))->in.in_slots[0]));
	goto L1375;
L1380:
	(*LK4)(2,(V7),VV[75])                     /*  X-TYPE-ERROR    */;
L1375:
	if(!((V8)==Cnil)){
	goto L1384;}
	((*(unsigned long *)(((V16))->ust.ust_self+((V15)+(20))))=0);
	goto L1382;
L1384:
	(*LK8)(2,(V8),VV[26])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1387;}
	((*(unsigned long *)(((V16))->ust.ust_self+((V15)+(20))))=fix((V8)));
	goto L1382;
L1387:
	(*LK4)(2,(V8),VV[76])                     /*  X-TYPE-ERROR    */;
L1382:
	((*(unsigned short *)(((V16))->ust.ust_self+((V15)+(2))))=6);
	((V10))->in.in_slots[6]= MAKE_FIXNUM((V15)+(24));
	(*LK13)(1,(V10))                          /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V10))                          /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V10))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V10),(V11))                    /*  READ-REPLY      */;
	V12= VALUES(0);
	{object V14;                              /*  %REPLY-BUFFER   */
	object V15;                               /*  %BUFFER         */
	{int V16;                                 /*  BUFFER-BOFFSET  */
	object V17;                               /*  BUFFER-BBUF     */
	V16= 0;
	V17= ((V12))->in.in_slots[1];
	{int V18;
	V18= ((V17))->ust.ust_self[(V16)+(1)];
	if((V18)<(5)){
	goto L1401;}
	VALUES(0)=Cnil;
	V13=1;
	goto L1319;
L1401:
	VALUES(0)=(VV[77])->v.v_self[V18];
	V13=1;
	}
	}
	}
L1319:
	}
	frs_pop();
	MV_SAVE(V13);
	if(((V12))==Cnil){
	goto L1404;}
	(*LK20)(1,(V12))                          /*  DEALLOCATE-REPLY-BUFFER*/;
L1404:
	if(((V11))==Cnil){
	goto L1403;}
	(*LK21)(2,(V10),(V11))                    /*  STOP-PENDING-COMMAND*/;
L1403:
	MV_RESTORE(V13);
	if (unwinding) unwind(nlj_fr,nlj_tag,V13+1);
	else {
	RETURN(V13);}}
	}
	}
	}
}
/*	function definition for UNGRAB-POINTER                        */
static L28(int narg, object V1, ...)
{ VT30 VLEX30 CLSR30
	{register object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[2];
	parse_key(narg,args,1,L28keys,keyvars,OBJNULL,FALSE);
	V2= keyvars[0];
	}
	{register object V3;                      /*  .DISPLAY.       */
	V3= (V1);
	if((((V3))->in.in_slots[10])==Cnil){
	goto L1409;}
	(*LK0)(3,VV[16],VV[10],(V3))              /*  X-ERROR         */;
L1409:
	{ int V4;
	{register object V5;                      /*  %BUFFER         */
	V5= (V3);
	if(!(((fix(((V5))->in.in_slots[6]))+(160))>=(fix(((V5))->in.in_slots[2])))){
	goto L1413;}
	(*LK7)(1,(V5))                            /*  BUFFER-FLUSH    */;
L1413:
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= fix(((V5))->in.in_slots[6]);
	V7= ((V5))->in.in_slots[7];
	((V3))->in.in_slots[4]= MAKE_FIXNUM(V6);
	(((V7))->ust.ust_self[(V6)+(0)]=(27));
	if(!((V2)==Cnil)){
	goto L1424;}
	((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4))))=0);
	goto L1422;
L1424:
	(*LK8)(2,(V2),VV[26])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1427;}
	((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4))))=fix((V2)));
	goto L1422;
L1427:
	(*LK4)(2,(V2),VV[78])                     /*  X-TYPE-ERROR    */;
L1422:
	((*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))))=2);
	((V3))->in.in_slots[6]= MAKE_FIXNUM((V6)+(8));
	V4=(*LK13)(1,(V3))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V4);
	(*LK14)(1,(V3))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V4);
	RETURN(V4);}
	}
	}
}
/*	function definition for GRAB-BUTTON                           */
static L29(int narg, object V1, object V2, object V3, ...)
{ VT31 VLEX31 CLSR31
	{object V4;
	object V5;
	object V6;
	object V7;
	register object V8;
	register object V9;
	va_list args; va_start(args, V3);
	narg -=3;
	{ object keyvars[12];
	parse_key(narg,args,6,L29keys,keyvars,OBJNULL,FALSE);
	if(keyvars[6]==Cnil){
	V4= MAKE_FIXNUM(0);
	}else{
	V4= keyvars[0];}
	V5= keyvars[1];
	V6= keyvars[2];
	V7= keyvars[3];
	V8= keyvars[4];
	V9= keyvars[5];
	}
	{register object V10;                     /*  .DISPLAY.       */
	V10= ((V1))->in.in_slots[1];
	if((((V10))->in.in_slots[10])==Cnil){
	goto L1434;}
	(*LK0)(3,VV[16],VV[10],(V10))             /*  X-ERROR         */;
L1434:
	{ int V11;
	{register object V12;                     /*  %BUFFER         */
	V12= (V10);
	if(!(((fix(((V12))->in.in_slots[6]))+(160))>=(fix(((V12))->in.in_slots[2])))){
	goto L1438;}
	(*LK7)(1,(V12))                           /*  BUFFER-FLUSH    */;
L1438:
	{register int V13;                        /*  BUFFER-BOFFSET  */
	register object V14;                      /*  BUFFER-BBUF     */
	V13= fix(((V12))->in.in_slots[6]);
	V14= ((V12))->in.in_slots[7];
	((V10))->in.in_slots[4]= MAKE_FIXNUM(V13);
	(((V14))->ust.ust_self[(V13)+(0)]=(28));
	if(((V5))==Cnil){
	goto L1452;}
	T0= MAKE_FIXNUM(1);
	goto L1450;
L1452:
	T0= MAKE_FIXNUM(0);
L1450:
	VALUES(0) = MAKE_FIXNUM((((V14))->ust.ust_self[(V13)+(1)]=(fix(T0))));
	if(VALUES(0)==Cnil)goto L1448;
	goto L1447;
L1448:
	(*LK4)(2,(V5),VV[79])                     /*  X-TYPE-ERROR    */;
L1447:
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L1456;}
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L1454;
L1456:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L1454:
	{object V15;                              /*  .VALUE.         */
	(*LK36)(1,(V3))                           /*  ENCODE-POINTER-EVENT-MASK*/;
	V15= VALUES(0);
	(*LK8)(2,(V15),VV[21])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1461;}
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(8))))=fix((V15)));
	goto L1458;
L1461:
	(*LK4)(2,(V15),VV[21])                    /*  X-TYPE-ERROR    */;
	}
L1458:
	{object V15;                              /*  .VALUE.         */
	V15= (((V6))==Cnil?Ct:Cnil);
	if(((V15))==Cnil){
	goto L1469;}
	T0= MAKE_FIXNUM(1);
	goto L1467;
L1469:
	T0= MAKE_FIXNUM(0);
L1467:
	(((V14))->ust.ust_self[(V13)+(10)]=(fix(T0)));
	goto L1463;
	(*LK4)(2,(V15),VV[73])                    /*  X-TYPE-ERROR    */;
	}
L1463:
	{object V15;                              /*  .VALUE.         */
	V15= (((V7))==Cnil?Ct:Cnil);
	if(((V15))==Cnil){
	goto L1477;}
	T0= MAKE_FIXNUM(1);
	goto L1475;
L1477:
	T0= MAKE_FIXNUM(0);
L1475:
	(((V14))->ust.ust_self[(V13)+(11)]=(fix(T0)));
	goto L1471;
	(*LK4)(2,(V15),VV[73])                    /*  X-TYPE-ERROR    */;
	}
L1471:
	if(!((V8)==Cnil)){
	goto L1481;}
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(12))))=0);
	goto L1479;
L1481:
	(*LK9)(1,(V8))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L1484;}
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(12))))=fix(((V8))->in.in_slots[0]));
	goto L1479;
L1484:
	(*LK4)(2,(V8),VV[80])                     /*  X-TYPE-ERROR    */;
L1479:
	if(!((V9)==Cnil)){
	goto L1488;}
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(16))))=0);
	goto L1486;
L1488:
	(*LK12)(1,(V9))                           /*  CURSOR-P        */;
	if(VALUES(0)==Cnil){
	goto L1491;}
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(16))))=fix(((V9))->in.in_slots[0]));
	goto L1486;
L1491:
	(*LK4)(2,(V9),VV[81])                     /*  X-TYPE-ERROR    */;
L1486:
	{object V15;                              /*  .VALUE.         */
	if(!(((V2))==(VV[82]))){
	goto L1496;}
	V15= MAKE_FIXNUM(0);
	goto L1494;
L1496:
	V15= (V2);
L1494:
	(*LK8)(2,(V15),VV[17])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1499;}
	(((V14))->ust.ust_self[(V13)+(20)]=(fix((V15))));
	goto L1493;
L1499:
	(*LK4)(2,(V15),VV[17])                    /*  X-TYPE-ERROR    */;
	}
L1493:
	{object V15;                              /*  .VALUE.         */
	(*LK37)(1,(V4))                           /*  ENCODE-MODIFIER-MASK*/;
	V15= VALUES(0);
	(*LK8)(2,(V15),VV[21])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1505;}
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(22))))=fix((V15)));
	goto L1502;
L1505:
	(*LK4)(2,(V15),VV[21])                    /*  X-TYPE-ERROR    */;
	}
L1502:
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(2))))=6);
	((V10))->in.in_slots[6]= MAKE_FIXNUM((V13)+(24));
	V11=(*LK13)(1,(V10))                      /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V11);
	(*LK14)(1,(V10))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V11);
	RETURN(V11);}
	}
	}
}
/*	function definition for UNGRAB-BUTTON                         */
static L30(int narg, object V1, object V2, ...)
{ VT32 VLEX32 CLSR32
	{object V3;
	va_list args; va_start(args, V2);
	narg -=2;
	{ object keyvars[2];
	parse_key(narg,args,1,L30keys,keyvars,OBJNULL,FALSE);
	if(keyvars[1]==Cnil){
	V3= MAKE_FIXNUM(0);
	}else{
	V3= keyvars[0];}
	}
	{register object V4;                      /*  .DISPLAY.       */
	V4= ((V1))->in.in_slots[1];
	if((((V4))->in.in_slots[10])==Cnil){
	goto L1512;}
	(*LK0)(3,VV[16],VV[10],(V4))              /*  X-ERROR         */;
L1512:
	{ int V5;
	{register object V6;                      /*  %BUFFER         */
	V6= (V4);
	if(!(((fix(((V6))->in.in_slots[6]))+(160))>=(fix(((V6))->in.in_slots[2])))){
	goto L1516;}
	(*LK7)(1,(V6))                            /*  BUFFER-FLUSH    */;
L1516:
	{register int V7;                         /*  BUFFER-BOFFSET  */
	register object V8;                       /*  BUFFER-BBUF     */
	V7= fix(((V6))->in.in_slots[6]);
	V8= ((V6))->in.in_slots[7];
	((V4))->in.in_slots[4]= MAKE_FIXNUM(V7);
	(((V8))->ust.ust_self[(V7)+(0)]=(29));
	{object V9;                               /*  .VALUE.         */
	if(!(((V2))==(VV[82]))){
	goto L1528;}
	V9= MAKE_FIXNUM(0);
	goto L1526;
L1528:
	V9= (V2);
L1526:
	(*LK8)(2,(V9),VV[17])                     /*  TYPEP           */;
	if(VALUES(0)!=Cnil){
	goto L1532;}
	VALUES(0) = Cnil;
	goto L1531;
L1532:
	VALUES(0) = MAKE_FIXNUM((((V8))->ust.ust_self[(V7)+(1)]=(fix((V9)))));
L1531:
	if(VALUES(0)==Cnil)goto L1530;
	goto L1525;
L1530:
	(*LK4)(2,(V9),VV[18])                     /*  X-TYPE-ERROR    */;
	}
L1525:
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L1536;}
	((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L1534;
L1536:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L1534:
	{object V9;                               /*  .VALUE.         */
	(*LK37)(1,(V3))                           /*  ENCODE-MODIFIER-MASK*/;
	V9= VALUES(0);
	(*LK8)(2,(V9),VV[21])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1541;}
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(8))))=fix((V9)));
	goto L1538;
L1541:
	(*LK4)(2,(V9),VV[21])                     /*  X-TYPE-ERROR    */;
	}
L1538:
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(2))))=3);
	((V4))->in.in_slots[6]= MAKE_FIXNUM((V7)+(12));
	V5=(*LK13)(1,(V4))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V5);
	(*LK14)(1,(V4))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V5);
	RETURN(V5);}
	}
	}
}
/*	function definition for CHANGE-ACTIVE-POINTER-GRAB            */
static L31(int narg, object V1, object V2, ...)
{ VT33 VLEX33 CLSR33
	{int i=2;
	register object V3;
	register object V4;
	va_list args; va_start(args, V2);
	if (i==narg) goto L1546;
	V3= va_arg(args, object);
	i++;
	if (i==narg) goto L1547;
	V4= va_arg(args, object);
	i++;
	goto L1548;
L1546:
	V3= Cnil;
L1547:
	V4= Cnil;
L1548:
	{register object V5;                      /*  .DISPLAY.       */
	V5= (V1);
	if((((V5))->in.in_slots[10])==Cnil){
	goto L1551;}
	(*LK0)(3,VV[16],VV[10],(V5))              /*  X-ERROR         */;
L1551:
	{ int V6;
	{register object V7;                      /*  %BUFFER         */
	V7= (V5);
	if(!(((fix(((V7))->in.in_slots[6]))+(160))>=(fix(((V7))->in.in_slots[2])))){
	goto L1555;}
	(*LK7)(1,(V7))                            /*  BUFFER-FLUSH    */;
L1555:
	{register int V8;                         /*  BUFFER-BOFFSET  */
	register object V9;                       /*  BUFFER-BBUF     */
	V8= fix(((V7))->in.in_slots[6]);
	V9= ((V7))->in.in_slots[7];
	((V5))->in.in_slots[4]= MAKE_FIXNUM(V8);
	(((V9))->ust.ust_self[(V8)+(0)]=(30));
	if(!((V3)==Cnil)){
	goto L1566;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(4))))=0);
	goto L1564;
L1566:
	(*LK12)(1,(V3))                           /*  CURSOR-P        */;
	if(VALUES(0)==Cnil){
	goto L1569;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(4))))=fix(((V3))->in.in_slots[0]));
	goto L1564;
L1569:
	(*LK4)(2,(V3),VV[83])                     /*  X-TYPE-ERROR    */;
L1564:
	if(!((V4)==Cnil)){
	goto L1573;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(8))))=0);
	goto L1571;
L1573:
	(*LK8)(2,(V4),VV[26])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1576;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(8))))=fix((V4)));
	goto L1571;
L1576:
	(*LK4)(2,(V4),VV[84])                     /*  X-TYPE-ERROR    */;
L1571:
	{object V10;                              /*  .VALUE.         */
	(*LK36)(1,(V2))                           /*  ENCODE-POINTER-EVENT-MASK*/;
	V10= VALUES(0);
	(*LK8)(2,(V10),VV[21])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1581;}
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(12))))=fix((V10)));
	goto L1578;
L1581:
	(*LK4)(2,(V10),VV[21])                    /*  X-TYPE-ERROR    */;
	}
L1578:
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=4);
	((V5))->in.in_slots[6]= MAKE_FIXNUM((V8)+(16));
	V6=(*LK13)(1,(V5))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V6);
	(*LK14)(1,(V5))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V6);
	RETURN(V6);}
	}
	}
}
/*	function definition for GRAB-KEYBOARD                         */
static L32(int narg, object V1, ...)
{ VT34 VLEX34 CLSR34
	{volatile object V2;
	volatile object V3;
	volatile object V4;
	volatile object V5;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[8];
	parse_key(narg,args,4,L32keys,keyvars,OBJNULL,FALSE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	}
	{volatile object V6;                      /*  DISPLAY         */
	V6= ((V1))->in.in_slots[1];
	{volatile object V7;                      /*  .DISPLAY.       */
	volatile object V8;                       /*  .PENDING-COMMAND.*/
	volatile object V9;                       /*  .REPLY-BUFFER.  */
	V7= (V6);
	V8= Cnil;
	V9= Cnil;
	{ int V10; volatile bool unwinding = FALSE;
	if ((V10=frs_push(FRS_PROTECT,Cnil))) {
	V10--; unwinding = TRUE;} else {
	if((((V7))->in.in_slots[10])==Cnil){
	goto L1589;}
	(*LK0)(3,VV[16],VV[10],(V7))              /*  X-ERROR         */;
L1589:
	(*LK15)(1,(V7))                           /*  START-PENDING-COMMAND*/;
	V8= VALUES(0);
	{register object V11;                     /*  %BUFFER         */
	V11= (V7);
	if(!(((fix(((V11))->in.in_slots[6]))+(160))>=(fix(((V11))->in.in_slots[2])))){
	goto L1595;}
	(*LK7)(1,(V11))                           /*  BUFFER-FLUSH    */;
L1595:
	{register int V12;                        /*  BUFFER-BOFFSET  */
	register object V13;                      /*  BUFFER-BBUF     */
	V12= fix(((V11))->in.in_slots[6]);
	V13= ((V11))->in.in_slots[7];
	((V7))->in.in_slots[4]= MAKE_FIXNUM(V12);
	(((V13))->ust.ust_self[(V12)+(0)]=(31));
	if(((V2))==Cnil){
	goto L1609;}
	T0= MAKE_FIXNUM(1);
	goto L1607;
L1609:
	T0= MAKE_FIXNUM(0);
L1607:
	VALUES(0) = MAKE_FIXNUM((((V13))->ust.ust_self[(V12)+(1)]=(fix(T0))));
	if(VALUES(0)==Cnil)goto L1605;
	goto L1604;
L1605:
	(*LK4)(2,(V2),VV[85])                     /*  X-TYPE-ERROR    */;
L1604:
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L1613;}
	((*(unsigned long *)(((V13))->ust.ust_self+((V12)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L1611;
L1613:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L1611:
	if(!((V5)==Cnil)){
	goto L1617;}
	((*(unsigned long *)(((V13))->ust.ust_self+((V12)+(8))))=0);
	goto L1615;
L1617:
	(*LK8)(2,(V5),VV[26])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1620;}
	((*(unsigned long *)(((V13))->ust.ust_self+((V12)+(8))))=fix((V5)));
	goto L1615;
L1620:
	(*LK4)(2,(V5),VV[86])                     /*  X-TYPE-ERROR    */;
L1615:
	{object V14;                              /*  .VALUE.         */
	V14= (((V3))==Cnil?Ct:Cnil);
	if(((V14))==Cnil){
	goto L1628;}
	T0= MAKE_FIXNUM(1);
	goto L1626;
L1628:
	T0= MAKE_FIXNUM(0);
L1626:
	(((V13))->ust.ust_self[(V12)+(12)]=(fix(T0)));
	goto L1622;
	(*LK4)(2,(V14),VV[73])                    /*  X-TYPE-ERROR    */;
	}
L1622:
	{object V14;                              /*  .VALUE.         */
	V14= (((V4))==Cnil?Ct:Cnil);
	if(((V14))==Cnil){
	goto L1636;}
	T0= MAKE_FIXNUM(1);
	goto L1634;
L1636:
	T0= MAKE_FIXNUM(0);
L1634:
	(((V13))->ust.ust_self[(V12)+(13)]=(fix(T0)));
	goto L1630;
	(*LK4)(2,(V14),VV[73])                    /*  X-TYPE-ERROR    */;
	}
L1630:
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(2))))=4);
	((V7))->in.in_slots[6]= MAKE_FIXNUM((V12)+(16));
	(*LK13)(1,(V7))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V7))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V7))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V7),(V8))                      /*  READ-REPLY      */;
	V9= VALUES(0);
	{object V11;                              /*  %REPLY-BUFFER   */
	object V12;                               /*  %BUFFER         */
	{int V13;                                 /*  BUFFER-BOFFSET  */
	object V14;                               /*  BUFFER-BBUF     */
	V13= 0;
	V14= ((V9))->in.in_slots[1];
	{int V15;
	V15= ((V14))->ust.ust_self[(V13)+(1)];
	if((V15)<(5)){
	goto L1650;}
	VALUES(0)=Cnil;
	V10=1;
	goto L1587;
L1650:
	VALUES(0)=(VV[87])->v.v_self[V15];
	V10=1;
	}
	}
	}
L1587:
	}
	frs_pop();
	MV_SAVE(V10);
	if(((V9))==Cnil){
	goto L1653;}
	(*LK20)(1,(V9))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L1653:
	if(((V8))==Cnil){
	goto L1652;}
	(*LK21)(2,(V7),(V8))                      /*  STOP-PENDING-COMMAND*/;
L1652:
	MV_RESTORE(V10);
	if (unwinding) unwind(nlj_fr,nlj_tag,V10+1);
	else {
	RETURN(V10);}}
	}
	}
	}
}
/*	function definition for UNGRAB-KEYBOARD                       */
static L33(int narg, object V1, ...)
{ VT35 VLEX35 CLSR35
	{register object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[2];
	parse_key(narg,args,1,L33keys,keyvars,OBJNULL,FALSE);
	V2= keyvars[0];
	}
	{register object V3;                      /*  .DISPLAY.       */
	V3= (V1);
	if((((V3))->in.in_slots[10])==Cnil){
	goto L1658;}
	(*LK0)(3,VV[16],VV[10],(V3))              /*  X-ERROR         */;
L1658:
	{ int V4;
	{register object V5;                      /*  %BUFFER         */
	V5= (V3);
	if(!(((fix(((V5))->in.in_slots[6]))+(160))>=(fix(((V5))->in.in_slots[2])))){
	goto L1662;}
	(*LK7)(1,(V5))                            /*  BUFFER-FLUSH    */;
L1662:
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= fix(((V5))->in.in_slots[6]);
	V7= ((V5))->in.in_slots[7];
	((V3))->in.in_slots[4]= MAKE_FIXNUM(V6);
	(((V7))->ust.ust_self[(V6)+(0)]=(32));
	if(!((V2)==Cnil)){
	goto L1673;}
	((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4))))=0);
	goto L1671;
L1673:
	(*LK8)(2,(V2),VV[26])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1676;}
	((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4))))=fix((V2)));
	goto L1671;
L1676:
	(*LK4)(2,(V2),VV[88])                     /*  X-TYPE-ERROR    */;
L1671:
	((*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))))=2);
	((V3))->in.in_slots[6]= MAKE_FIXNUM((V6)+(8));
	V4=(*LK13)(1,(V3))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V4);
	(*LK14)(1,(V3))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V4);
	RETURN(V4);}
	}
	}
}
/*	function definition for GRAB-KEY                              */
static L34(int narg, object V1, object V2, ...)
{ VT36 VLEX36 CLSR36
	{object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V2);
	narg -=2;
	{ object keyvars[8];
	parse_key(narg,args,4,L34keys,keyvars,OBJNULL,FALSE);
	if(keyvars[4]==Cnil){
	V3= MAKE_FIXNUM(0);
	}else{
	V3= keyvars[0];}
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	}
	{register object V7;                      /*  .DISPLAY.       */
	V7= ((V1))->in.in_slots[1];
	if((((V7))->in.in_slots[10])==Cnil){
	goto L1683;}
	(*LK0)(3,VV[16],VV[10],(V7))              /*  X-ERROR         */;
L1683:
	{ int V8;
	{register object V9;                      /*  %BUFFER         */
	V9= (V7);
	if(!(((fix(((V9))->in.in_slots[6]))+(160))>=(fix(((V9))->in.in_slots[2])))){
	goto L1687;}
	(*LK7)(1,(V9))                            /*  BUFFER-FLUSH    */;
L1687:
	{register int V10;                        /*  BUFFER-BOFFSET  */
	register object V11;                      /*  BUFFER-BBUF     */
	V10= fix(((V9))->in.in_slots[6]);
	V11= ((V9))->in.in_slots[7];
	((V7))->in.in_slots[4]= MAKE_FIXNUM(V10);
	(((V11))->ust.ust_self[(V10)+(0)]=(33));
	if(((V4))==Cnil){
	goto L1701;}
	T0= MAKE_FIXNUM(1);
	goto L1699;
L1701:
	T0= MAKE_FIXNUM(0);
L1699:
	VALUES(0) = MAKE_FIXNUM((((V11))->ust.ust_self[(V10)+(1)]=(fix(T0))));
	if(VALUES(0)==Cnil)goto L1697;
	goto L1696;
L1697:
	(*LK4)(2,(V4),VV[89])                     /*  X-TYPE-ERROR    */;
L1696:
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L1705;}
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L1703;
L1705:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L1703:
	{object V12;                              /*  .VALUE.         */
	(*LK37)(1,(V3))                           /*  ENCODE-MODIFIER-MASK*/;
	V12= VALUES(0);
	(*LK8)(2,(V12),VV[21])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1710;}
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(8))))=fix((V12)));
	goto L1707;
L1710:
	(*LK4)(2,(V12),VV[21])                    /*  X-TYPE-ERROR    */;
	}
L1707:
	{object V12;                              /*  .VALUE.         */
	if(!(((V2))==(VV[82]))){
	goto L1715;}
	V12= MAKE_FIXNUM(0);
	goto L1713;
L1715:
	V12= (V2);
L1713:
	(*LK8)(2,(V12),VV[17])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1718;}
	(((V11))->ust.ust_self[(V10)+(10)]=(fix((V12))));
	goto L1712;
L1718:
	(*LK4)(2,(V12),VV[17])                    /*  X-TYPE-ERROR    */;
	}
L1712:
	{object V12;                              /*  .VALUE.         */
	V12= (((V5))==Cnil?Ct:Cnil);
	if(((V12))==Cnil){
	goto L1726;}
	T0= MAKE_FIXNUM(1);
	goto L1724;
L1726:
	T0= MAKE_FIXNUM(0);
L1724:
	(((V11))->ust.ust_self[(V10)+(11)]=(fix(T0)));
	goto L1720;
	(*LK4)(2,(V12),VV[73])                    /*  X-TYPE-ERROR    */;
	}
L1720:
	{object V12;                              /*  .VALUE.         */
	V12= (((V6))==Cnil?Ct:Cnil);
	if(((V12))==Cnil){
	goto L1734;}
	T0= MAKE_FIXNUM(1);
	goto L1732;
L1734:
	T0= MAKE_FIXNUM(0);
L1732:
	(((V11))->ust.ust_self[(V10)+(12)]=(fix(T0)));
	goto L1728;
	(*LK4)(2,(V12),VV[73])                    /*  X-TYPE-ERROR    */;
	}
L1728:
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(2))))=4);
	((V7))->in.in_slots[6]= MAKE_FIXNUM((V10)+(16));
	V8=(*LK13)(1,(V7))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V8);
	(*LK14)(1,(V7))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V8);
	RETURN(V8);}
	}
	}
}
/*	function definition for UNGRAB-KEY                            */
static L35(int narg, object V1, object V2, ...)
{ VT37 VLEX37 CLSR37
	{object V3;
	va_list args; va_start(args, V2);
	narg -=2;
	{ object keyvars[2];
	parse_key(narg,args,1,L35keys,keyvars,OBJNULL,FALSE);
	if(keyvars[1]==Cnil){
	V3= MAKE_FIXNUM(0);
	}else{
	V3= keyvars[0];}
	}
	{register object V4;                      /*  .DISPLAY.       */
	V4= ((V1))->in.in_slots[1];
	if((((V4))->in.in_slots[10])==Cnil){
	goto L1741;}
	(*LK0)(3,VV[16],VV[10],(V4))              /*  X-ERROR         */;
L1741:
	{ int V5;
	{register object V6;                      /*  %BUFFER         */
	V6= (V4);
	if(!(((fix(((V6))->in.in_slots[6]))+(160))>=(fix(((V6))->in.in_slots[2])))){
	goto L1745;}
	(*LK7)(1,(V6))                            /*  BUFFER-FLUSH    */;
L1745:
	{register int V7;                         /*  BUFFER-BOFFSET  */
	register object V8;                       /*  BUFFER-BBUF     */
	V7= fix(((V6))->in.in_slots[6]);
	V8= ((V6))->in.in_slots[7];
	((V4))->in.in_slots[4]= MAKE_FIXNUM(V7);
	(((V8))->ust.ust_self[(V7)+(0)]=(34));
	{object V9;                               /*  .VALUE.         */
	if(!(((V2))==(VV[82]))){
	goto L1757;}
	V9= MAKE_FIXNUM(0);
	goto L1755;
L1757:
	V9= (V2);
L1755:
	(*LK8)(2,(V9),VV[17])                     /*  TYPEP           */;
	if(VALUES(0)!=Cnil){
	goto L1761;}
	VALUES(0) = Cnil;
	goto L1760;
L1761:
	VALUES(0) = MAKE_FIXNUM((((V8))->ust.ust_self[(V7)+(1)]=(fix((V9)))));
L1760:
	if(VALUES(0)==Cnil)goto L1759;
	goto L1754;
L1759:
	(*LK4)(2,(V9),VV[18])                     /*  X-TYPE-ERROR    */;
	}
L1754:
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L1765;}
	((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L1763;
L1765:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L1763:
	{object V9;                               /*  .VALUE.         */
	(*LK37)(1,(V3))                           /*  ENCODE-MODIFIER-MASK*/;
	V9= VALUES(0);
	(*LK8)(2,(V9),VV[21])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1770;}
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(8))))=fix((V9)));
	goto L1767;
L1770:
	(*LK4)(2,(V9),VV[21])                     /*  X-TYPE-ERROR    */;
	}
L1767:
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(2))))=3);
	((V4))->in.in_slots[6]= MAKE_FIXNUM((V7)+(12));
	V5=(*LK13)(1,(V4))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V5);
	(*LK14)(1,(V4))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V5);
	RETURN(V5);}
	}
	}
}
/*	function definition for ALLOW-EVENTS                          */
static L36(int narg, object V1, object V2, ...)
{ VT38 VLEX38 CLSR38
	{int i=2;
	register object V3;
	va_list args; va_start(args, V2);
	if (i==narg) goto L1775;
	V3= va_arg(args, object);
	i++;
	goto L1776;
L1775:
	V3= Cnil;
L1776:
	{register object V4;                      /*  .DISPLAY.       */
	V4= (V1);
	if((((V4))->in.in_slots[10])==Cnil){
	goto L1778;}
	(*LK0)(3,VV[16],VV[10],(V4))              /*  X-ERROR         */;
L1778:
	{ int V5;
	{register object V6;                      /*  %BUFFER         */
	V6= (V4);
	if(!(((fix(((V6))->in.in_slots[6]))+(160))>=(fix(((V6))->in.in_slots[2])))){
	goto L1782;}
	(*LK7)(1,(V6))                            /*  BUFFER-FLUSH    */;
L1782:
	{register int V7;                         /*  BUFFER-BOFFSET  */
	register object V8;                       /*  BUFFER-BBUF     */
	V7= fix(((V6))->in.in_slots[6]);
	V8= ((V6))->in.in_slots[7];
	((V4))->in.in_slots[4]= MAKE_FIXNUM(V7);
	(((V8))->ust.ust_self[(V7)+(0)]=(35));
	(*LK8)(2,(V2),VV[90])                     /*  TYPEP           */;
	if(VALUES(0)!=Cnil){
	goto L1794;}
	VALUES(0) = Cnil;
	goto L1793;
L1794:
	VALUES(0) = (VV[305]->s.s_gfdef);
	(*LK10)(4,(V2),VV[91],VV[23],VALUES(0))   /*  POSITION        */;
	T0= VALUES(0);
	{int V9= ((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(4))))=fix(T0));
	VALUES(0) = MAKE_FIXNUM((((V8))->ust.ust_self[(V7)+(1)]=(V9)));}
L1793:
	if(VALUES(0)==Cnil)goto L1792;
	goto L1791;
L1792:
	(*LK4)(2,(V2),VV[92])                     /*  X-TYPE-ERROR    */;
L1791:
	if(!((V3)==Cnil)){
	goto L1800;}
	((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(4))))=0);
	goto L1798;
L1800:
	(*LK8)(2,(V3),VV[26])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1803;}
	((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(4))))=fix((V3)));
	goto L1798;
L1803:
	(*LK4)(2,(V3),VV[93])                     /*  X-TYPE-ERROR    */;
L1798:
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(2))))=2);
	((V4))->in.in_slots[6]= MAKE_FIXNUM((V7)+(8));
	V5=(*LK13)(1,(V4))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V5);
	(*LK14)(1,(V4))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V5);
	RETURN(V5);}
	}
	}
}
/*	function definition for GRAB-SERVER                           */
static L37(int narg, object V1)
{ VT39 VLEX39 CLSR39
TTL:
	{register object V2;                      /*  .DISPLAY.       */
	V2= (V1);
	if((((V2))->in.in_slots[10])==Cnil){
	goto L1808;}
	(*LK0)(3,VV[16],VV[10],(V2))              /*  X-ERROR         */;
L1808:
	{ int V3;
	{register object V4;                      /*  %BUFFER         */
	V4= (V2);
	if(!(((fix(((V4))->in.in_slots[6]))+(160))>=(fix(((V4))->in.in_slots[2])))){
	goto L1812;}
	(*LK7)(1,(V4))                            /*  BUFFER-FLUSH    */;
L1812:
	{register int V5;                         /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= fix(((V4))->in.in_slots[6]);
	V6= ((V4))->in.in_slots[7];
	((V2))->in.in_slots[4]= MAKE_FIXNUM(V5);
	(((V6))->ust.ust_self[(V5)+(0)]=(36));
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(2))))=1);
	((V2))->in.in_slots[6]= MAKE_FIXNUM((V5)+(4));
	V3=(*LK13)(1,(V2))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V3);
	(*LK14)(1,(V2))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V3);
	RETURN(V3);}
	}
}
/*	function definition for UNGRAB-SERVER                         */
static L38(int narg, object V1)
{ VT40 VLEX40 CLSR40
TTL:
	{register object V2;                      /*  .DISPLAY.       */
	V2= (V1);
	if((((V2))->in.in_slots[10])==Cnil){
	goto L1824;}
	(*LK0)(3,VV[16],VV[10],(V2))              /*  X-ERROR         */;
L1824:
	{ int V3;
	{register object V4;                      /*  %BUFFER         */
	V4= (V2);
	if(!(((fix(((V4))->in.in_slots[6]))+(160))>=(fix(((V4))->in.in_slots[2])))){
	goto L1828;}
	(*LK7)(1,(V4))                            /*  BUFFER-FLUSH    */;
L1828:
	{register int V5;                         /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= fix(((V4))->in.in_slots[6]);
	V6= ((V4))->in.in_slots[7];
	((V2))->in.in_slots[4]= MAKE_FIXNUM(V5);
	(((V6))->ust.ust_self[(V5)+(0)]=(37));
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(2))))=1);
	((V2))->in.in_slots[6]= MAKE_FIXNUM((V5)+(4));
	V3=(*LK13)(1,(V2))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V3);
	(*LK14)(1,(V2))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V3);
	RETURN(V3);}
	}
}
/*	macro definition for WITH-SERVER-GRABBED                      */
static L39(int narg, object V1, object V2)
{ VT41 VLEX41 CLSR41
	{object V3=CDR(V1),V4,V5;
	{object V6= CAR(V3);
	V4= CAR(V6);}
	V3=CDR(V3);
	V5= V3;
	{register object V7;                      /*  DISP            */
	if(!(type_of((V4))==t_symbol)){
	goto L1842;}
	V7= (V4);
	goto L1840;
L1842:
	Lgensym(0)                                /*  GENSYM          */;
	V7= VALUES(0);
L1840:
	{object V8= CONS(list(2,(V7),(V4)),Cnil);
	{object V9= list(2,VV[95],list(3,VV[96],VV[11],(V7)));
	{object V10= listA(3,VV[98],list(2,VV[99],(V7)),(V5));
	VALUES(0) = list(4,VV[94],(V8),(V9),list(3,VV[97],(V10),list(2,VV[100],(V7))));
	RETURN(1);}}}
	}}
}
/*	function definition for QUERY-POINTER                         */
static L40(int narg, object V1)
{ VT42 VLEX42 CLSR42
TTL:
	{volatile object V2;                      /*  DISPLAY         */
	V2= ((V1))->in.in_slots[1];
	{volatile object V3;                      /*  .DISPLAY.       */
	volatile object V4;                       /*  .PENDING-COMMAND.*/
	volatile object V5;                       /*  .REPLY-BUFFER.  */
	V3= (V2);
	V4= Cnil;
	V5= Cnil;
	{ int V6; volatile bool unwinding = FALSE;
	if ((V6=frs_push(FRS_PROTECT,Cnil))) {
	V6--; unwinding = TRUE;} else {
	if((((V3))->in.in_slots[10])==Cnil){
	goto L1847;}
	(*LK0)(3,VV[16],VV[10],(V3))              /*  X-ERROR         */;
L1847:
	(*LK15)(1,(V3))                           /*  START-PENDING-COMMAND*/;
	V4= VALUES(0);
	{register object V7;                      /*  %BUFFER         */
	V7= (V3);
	if(!(((fix(((V7))->in.in_slots[6]))+(160))>=(fix(((V7))->in.in_slots[2])))){
	goto L1853;}
	(*LK7)(1,(V7))                            /*  BUFFER-FLUSH    */;
L1853:
	{register int V8;                         /*  BUFFER-BOFFSET  */
	register object V9;                       /*  BUFFER-BBUF     */
	V8= fix(((V7))->in.in_slots[6]);
	V9= ((V7))->in.in_slots[7];
	((V3))->in.in_slots[4]= MAKE_FIXNUM(V8);
	(((V9))->ust.ust_self[(V8)+(0)]=(38));
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L1864;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L1862;
L1864:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L1862:
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=2);
	((V3))->in.in_slots[6]= MAKE_FIXNUM((V8)+(8));
	(*LK13)(1,(V3))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V3))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V3))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V3),(V4))                      /*  READ-REPLY      */;
	V5= VALUES(0);
	{object V7;                               /*  %REPLY-BUFFER   */
	object V8;                                /*  %BUFFER         */
	V8= (V3);
	{register int V9;                         /*  BUFFER-BOFFSET  */
	register object V10;                      /*  BUFFER-BBUF     */
	V9= 0;
	V10= ((V5))->in.in_slots[1];
	{int V11= (*(short *)(((V10))->st.st_self+((V9)+(20))));
	{int V12= (*(short *)(((V10))->st.st_self+((V9)+(22))));
	{object V13= ((((V10))->ust.ust_self[(V9)+(1)])>0?Ct:Cnil);
	{int V14;
	V14= (*(unsigned long *)(((V10))->ust.ust_self+((V9)+(12))));
	if(!((V14)==0)){
	goto L1880;}
	T0= Cnil;
	goto L1877;
L1880:
	{object V15;
	(*LK18)(2,(V8),MAKE_FIXNUM(V14))          /*  LOOKUP-WINDOW   */;
	V15= VALUES(0);
	if(((V15))==Cnil){
	goto L1884;}
	T0= (V15);
	goto L1877;
L1884:
	T0= Cnil;
	}
	}
L1877:
	{int V14= (*(unsigned short *)(((V10))->ust.ust_self+((V9)+(24))));
	{int V15= (*(short *)(((V10))->st.st_self+((V9)+(16))));
	{int V16= (*(short *)(((V10))->st.st_self+((V9)+(18))));
	(*LK18)(2,(V8),MAKE_FIXNUM(((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(8)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	VALUES(7) = VALUES(0);
	VALUES(6) = MAKE_FIXNUM(V16);
	VALUES(5) = MAKE_FIXNUM(V15);
	VALUES(4) = MAKE_FIXNUM(V14);
	VALUES(3) = T0;
	VALUES(2) = (V13);
	VALUES(1) = MAKE_FIXNUM(V12);
	VALUES(0) = MAKE_FIXNUM(V11);
	V6=8;}}}}}}
	}
	}
	}
	frs_pop();
	MV_SAVE(V6);
	if(((V5))==Cnil){
	goto L1888;}
	(*LK20)(1,(V5))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L1888:
	if(((V4))==Cnil){
	goto L1887;}
	(*LK21)(2,(V3),(V4))                      /*  STOP-PENDING-COMMAND*/;
L1887:
	MV_RESTORE(V6);
	if (unwinding) unwind(nlj_fr,nlj_tag,V6+1);
	else {
	RETURN(V6);}}
	}
	}
}
/*	function definition for POINTER-POSITION                      */
static L41(int narg, object V1)
{ VT43 VLEX43 CLSR43
TTL:
	{volatile object V2;                      /*  DISPLAY         */
	V2= ((V1))->in.in_slots[1];
	{volatile object V3;                      /*  .DISPLAY.       */
	volatile object V4;                       /*  .PENDING-COMMAND.*/
	volatile object V5;                       /*  .REPLY-BUFFER.  */
	V3= (V2);
	V4= Cnil;
	V5= Cnil;
	{ int V6; volatile bool unwinding = FALSE;
	if ((V6=frs_push(FRS_PROTECT,Cnil))) {
	V6--; unwinding = TRUE;} else {
	if((((V3))->in.in_slots[10])==Cnil){
	goto L1896;}
	(*LK0)(3,VV[16],VV[10],(V3))              /*  X-ERROR         */;
L1896:
	(*LK15)(1,(V3))                           /*  START-PENDING-COMMAND*/;
	V4= VALUES(0);
	{register object V7;                      /*  %BUFFER         */
	V7= (V3);
	if(!(((fix(((V7))->in.in_slots[6]))+(160))>=(fix(((V7))->in.in_slots[2])))){
	goto L1902;}
	(*LK7)(1,(V7))                            /*  BUFFER-FLUSH    */;
L1902:
	{register int V8;                         /*  BUFFER-BOFFSET  */
	register object V9;                       /*  BUFFER-BBUF     */
	V8= fix(((V7))->in.in_slots[6]);
	V9= ((V7))->in.in_slots[7];
	((V3))->in.in_slots[4]= MAKE_FIXNUM(V8);
	(((V9))->ust.ust_self[(V8)+(0)]=(38));
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L1913;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L1911;
L1913:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L1911:
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=2);
	((V3))->in.in_slots[6]= MAKE_FIXNUM((V8)+(8));
	(*LK13)(1,(V3))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V3))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V3))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V3),(V4))                      /*  READ-REPLY      */;
	V5= VALUES(0);
	{object V7;                               /*  %REPLY-BUFFER   */
	object V8;                                /*  %BUFFER         */
	{register int V9;                         /*  BUFFER-BOFFSET  */
	register object V10;                      /*  BUFFER-BBUF     */
	V9= 0;
	V10= ((V5))->in.in_slots[1];
	{int V11= (*(short *)(((V10))->st.st_self+((V9)+(20))));
	{int V12= (*(short *)(((V10))->st.st_self+((V9)+(22))));
	VALUES(2) = ((((V10))->ust.ust_self[(V9)+(1)])>0?Ct:Cnil);
	VALUES(1) = MAKE_FIXNUM(V12);
	VALUES(0) = MAKE_FIXNUM(V11);
	V6=3;}}
	}
	}
	}
	frs_pop();
	MV_SAVE(V6);
	if(((V5))==Cnil){
	goto L1927;}
	(*LK20)(1,(V5))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L1927:
	if(((V4))==Cnil){
	goto L1926;}
	(*LK21)(2,(V3),(V4))                      /*  STOP-PENDING-COMMAND*/;
L1926:
	MV_RESTORE(V6);
	if (unwinding) unwind(nlj_fr,nlj_tag,V6+1);
	else {
	RETURN(V6);}}
	}
	}
}
/*	function definition for GLOBAL-POINTER-POSITION               */
static L42(int narg, object V1)
{ VT44 VLEX44 CLSR44
TTL:
	{volatile object V2;                      /*  .DISPLAY.       */
	volatile object V3;                       /*  .PENDING-COMMAND.*/
	volatile object V4;                       /*  .REPLY-BUFFER.  */
	V2= (V1);
	V3= Cnil;
	V4= Cnil;
	{ int V5; volatile bool unwinding = FALSE;
	if ((V5=frs_push(FRS_PROTECT,Cnil))) {
	V5--; unwinding = TRUE;} else {
	if((((V2))->in.in_slots[10])==Cnil){
	goto L1934;}
	(*LK0)(3,VV[16],VV[10],(V2))              /*  X-ERROR         */;
L1934:
	(*LK15)(1,(V2))                           /*  START-PENDING-COMMAND*/;
	V3= VALUES(0);
	{register object V6;                      /*  %BUFFER         */
	V6= (V2);
	if(!(((fix(((V6))->in.in_slots[6]))+(160))>=(fix(((V6))->in.in_slots[2])))){
	goto L1940;}
	(*LK7)(1,(V6))                            /*  BUFFER-FLUSH    */;
L1940:
	{register int V7;                         /*  BUFFER-BOFFSET  */
	register object V8;                       /*  BUFFER-BBUF     */
	V7= fix(((V6))->in.in_slots[6]);
	V8= ((V6))->in.in_slots[7];
	((V2))->in.in_slots[4]= MAKE_FIXNUM(V7);
	(((V8))->ust.ust_self[(V7)+(0)]=(38));
	{object V9;                               /*  .VALUE.         */
	V9= (CAR(((V1))->in.in_slots[40]))->in.in_slots[0];
	(*LK9)(1,(V9))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L1952;}
	((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(4))))=fix(((V9))->in.in_slots[0]));
	goto L1949;
L1952:
	(*LK4)(2,(V9),VV[9])                      /*  X-TYPE-ERROR    */;
	}
L1949:
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(2))))=2);
	((V2))->in.in_slots[6]= MAKE_FIXNUM((V7)+(8));
	(*LK13)(1,(V2))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V2))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V2))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V2),(V3))                      /*  READ-REPLY      */;
	V4= VALUES(0);
	{object V6;                               /*  %REPLY-BUFFER   */
	object V7;                                /*  %BUFFER         */
	{register int V8;                         /*  BUFFER-BOFFSET  */
	register object V9;                       /*  BUFFER-BBUF     */
	V8= 0;
	V9= ((V4))->in.in_slots[1];
	{int V10= (*(short *)(((V9))->st.st_self+((V8)+(16))));
	{int V11= (*(short *)(((V9))->st.st_self+((V8)+(18))));
	(*LK18)(2,(V2),MAKE_FIXNUM(((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(8)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	VALUES(2) = VALUES(0);
	VALUES(1) = MAKE_FIXNUM(V11);
	VALUES(0) = MAKE_FIXNUM(V10);
	V5=3;}}
	}
	}
	}
	frs_pop();
	MV_SAVE(V5);
	if(((V4))==Cnil){
	goto L1967;}
	(*LK20)(1,(V4))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L1967:
	if(((V3))==Cnil){
	goto L1966;}
	(*LK21)(2,(V2),(V3))                      /*  STOP-PENDING-COMMAND*/;
L1966:
	MV_RESTORE(V5);
	if (unwinding) unwind(nlj_fr,nlj_tag,V5+1);
	else {
	RETURN(V5);}}
	}
}
/*	function definition for MOTION-EVENTS                         */
static L43(int narg, object V1, ...)
{ VT45 VLEX45 CLSR45
	{volatile object V2;
	volatile object V3;
	volatile object V4;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[6];
	parse_key(narg,args,3,L43keys,keyvars,OBJNULL,FALSE);
	V2= keyvars[0];
	V3= keyvars[1];
	if(keyvars[5]==Cnil){
	V4= VV[42];
	}else{
	V4= keyvars[2];}
	}
	{volatile object V5;                      /*  DISPLAY         */
	V5= ((V1))->in.in_slots[1];
	{volatile object V6;                      /*  .DISPLAY.       */
	volatile object V7;                       /*  .PENDING-COMMAND.*/
	volatile object V8;                       /*  .REPLY-BUFFER.  */
	V6= (V5);
	V7= Cnil;
	V8= Cnil;
	{ int V9; volatile bool unwinding = FALSE;
	if ((V9=frs_push(FRS_PROTECT,Cnil))) {
	V9--; unwinding = TRUE;} else {
	if((((V6))->in.in_slots[10])==Cnil){
	goto L1976;}
	(*LK0)(3,VV[16],VV[10],(V6))              /*  X-ERROR         */;
L1976:
	(*LK15)(1,(V6))                           /*  START-PENDING-COMMAND*/;
	V7= VALUES(0);
	{register object V10;                     /*  %BUFFER         */
	V10= (V6);
	if(!(((fix(((V10))->in.in_slots[6]))+(160))>=(fix(((V10))->in.in_slots[2])))){
	goto L1982;}
	(*LK7)(1,(V10))                           /*  BUFFER-FLUSH    */;
L1982:
	{register int V11;                        /*  BUFFER-BOFFSET  */
	register object V12;                      /*  BUFFER-BBUF     */
	V11= fix(((V10))->in.in_slots[6]);
	V12= ((V10))->in.in_slots[7];
	((V6))->in.in_slots[4]= MAKE_FIXNUM(V11);
	(((V12))->ust.ust_self[(V11)+(0)]=(39));
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L1993;}
	((*(unsigned long *)(((V12))->ust.ust_self+((V11)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L1991;
L1993:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L1991:
	if(!((V2)==Cnil)){
	goto L1997;}
	((*(unsigned long *)(((V12))->ust.ust_self+((V11)+(8))))=0);
	goto L1995;
L1997:
	(*LK8)(2,(V2),VV[26])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2000;}
	((*(unsigned long *)(((V12))->ust.ust_self+((V11)+(8))))=fix((V2)));
	goto L1995;
L2000:
	(*LK4)(2,(V2),VV[103])                    /*  X-TYPE-ERROR    */;
L1995:
	if(!((V3)==Cnil)){
	goto L2004;}
	((*(unsigned long *)(((V12))->ust.ust_self+((V11)+(12))))=0);
	goto L2002;
L2004:
	(*LK8)(2,(V3),VV[26])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2007;}
	((*(unsigned long *)(((V12))->ust.ust_self+((V11)+(12))))=fix((V3)));
	goto L2002;
L2007:
	(*LK4)(2,(V3),VV[104])                    /*  X-TYPE-ERROR    */;
L2002:
	((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(2))))=4);
	((V6))->in.in_slots[6]= MAKE_FIXNUM((V11)+(16));
	(*LK13)(1,(V6))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V6))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V6))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V6),(V7))                      /*  READ-REPLY      */;
	V8= VALUES(0);
	{object V10;                              /*  %REPLY-BUFFER   */
	object V11;                               /*  %BUFFER         */
	{int V12;                                 /*  BUFFER-BOFFSET  */
	object V13;                               /*  BUFFER-BBUF     */
	V12= 0;
	V13= ((V8))->in.in_slots[1];
	V9=(*LK19)(7,(V8),(V4),MAKE_FIXNUM(((*(unsigned long *)(((V13))->ust.ust_self+((V12)+(8)))))*(3)),Cnil,Cnil,MAKE_FIXNUM(0),MAKE_FIXNUM(32))/*  READ-SEQUENCE-CARD32*/;
	}
	}
	}
	frs_pop();
	MV_SAVE(V9);
	if(((V8))==Cnil){
	goto L2021;}
	(*LK20)(1,(V8))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L2021:
	if(((V7))==Cnil){
	goto L2020;}
	(*LK21)(2,(V6),(V7))                      /*  STOP-PENDING-COMMAND*/;
L2020:
	MV_RESTORE(V9);
	if (unwinding) unwind(nlj_fr,nlj_tag,V9+1);
	else {
	RETURN(V9);}}
	}
	}
	}
}
/*	function definition for TRANSLATE-COORDINATES                 */
static L44(int narg, object V1, object V2, object V3, object V4)
{ VT46 VLEX46 CLSR46
	{volatile int V5;
	volatile int V6;
	V5= fix(V2);
	V6= fix(V3);
TTL:
	{volatile object V7;                      /*  DISPLAY         */
	V7= ((V1))->in.in_slots[1];
	{volatile object V8;                      /*  .DISPLAY.       */
	volatile object V9;                       /*  .PENDING-COMMAND.*/
	volatile object V10;                      /*  .REPLY-BUFFER.  */
	V8= (V7);
	V9= Cnil;
	V10= Cnil;
	{ int V11; volatile bool unwinding = FALSE;
	if ((V11=frs_push(FRS_PROTECT,Cnil))) {
	V11--; unwinding = TRUE;} else {
	if((((V8))->in.in_slots[10])==Cnil){
	goto L2029;}
	(*LK0)(3,VV[16],VV[10],(V8))              /*  X-ERROR         */;
L2029:
	(*LK15)(1,(V8))                           /*  START-PENDING-COMMAND*/;
	V9= VALUES(0);
	{register object V12;                     /*  %BUFFER         */
	V12= (V8);
	if(!(((fix(((V12))->in.in_slots[6]))+(160))>=(fix(((V12))->in.in_slots[2])))){
	goto L2035;}
	(*LK7)(1,(V12))                           /*  BUFFER-FLUSH    */;
L2035:
	{register int V13;                        /*  BUFFER-BOFFSET  */
	register object V14;                      /*  BUFFER-BBUF     */
	V13= fix(((V12))->in.in_slots[6]);
	V14= ((V12))->in.in_slots[7];
	((V8))->in.in_slots[4]= MAKE_FIXNUM(V13);
	(((V14))->ust.ust_self[(V13)+(0)]=(40));
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L2046;}
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L2044;
L2046:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L2044:
	(*LK9)(1,(V4))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L2050;}
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(8))))=fix(((V4))->in.in_slots[0]));
	goto L2048;
L2050:
	(*LK4)(2,(V4),VV[9])                      /*  X-TYPE-ERROR    */;
L2048:
	(*LK8)(2,MAKE_FIXNUM(V5),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2054;}
	((*(short *)(((V14))->st.st_self+((V13)+(12))))=V5);
	goto L2052;
L2054:
	(*LK4)(2,MAKE_FIXNUM(V5),VV[20])          /*  X-TYPE-ERROR    */;
L2052:
	(*LK8)(2,MAKE_FIXNUM(V6),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2058;}
	((*(short *)(((V14))->st.st_self+((V13)+(14))))=V6);
	goto L2056;
L2058:
	(*LK4)(2,MAKE_FIXNUM(V6),VV[20])          /*  X-TYPE-ERROR    */;
L2056:
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(2))))=4);
	((V8))->in.in_slots[6]= MAKE_FIXNUM((V13)+(16));
	(*LK13)(1,(V8))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V8))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V8))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V8),(V9))                      /*  READ-REPLY      */;
	V10= VALUES(0);
	{object V12;                              /*  %REPLY-BUFFER   */
	object V13;                               /*  %BUFFER         */
	{register int V14;                        /*  BUFFER-BOFFSET  */
	register object V15;                      /*  BUFFER-BBUF     */
	V14= 0;
	V15= ((V10))->in.in_slots[1];
	if((((V15))->ust.ust_self[(V14)+(1)])>0){
	goto L2071;}
	VALUES(0)=Cnil;
	V11=1;
	goto L2027;
L2071:
	{int V16= (*(short *)(((V15))->st.st_self+((V14)+(12))));
	{int V17= (*(short *)(((V15))->st.st_self+((V14)+(14))));
	{int V18;
	V18= (*(unsigned long *)(((V15))->ust.ust_self+((V14)+(8))));
	if(!((V18)==0)){
	goto L2076;}
	VALUES(0) = Cnil;
	goto L2073;
L2076:
	{object V19;
	(*LK18)(2,(V8),MAKE_FIXNUM(V18))          /*  LOOKUP-WINDOW   */;
	V19= VALUES(0);
	if(((V19))==Cnil){
	goto L2080;}
	VALUES(0) = (V19);
	goto L2073;
L2080:
	VALUES(0) = Cnil;
	}
	}
L2073:
	VALUES(2) = VALUES(0);
	VALUES(1) = MAKE_FIXNUM(V17);
	VALUES(0) = MAKE_FIXNUM(V16);
	V11=3;}}
	}
	}
L2027:
	}
	frs_pop();
	MV_SAVE(V11);
	if(((V10))==Cnil){
	goto L2083;}
	(*LK20)(1,(V10))                          /*  DEALLOCATE-REPLY-BUFFER*/;
L2083:
	if(((V9))==Cnil){
	goto L2082;}
	(*LK21)(2,(V8),(V9))                      /*  STOP-PENDING-COMMAND*/;
L2082:
	MV_RESTORE(V11);
	if (unwinding) unwind(nlj_fr,nlj_tag,V11+1);
	else {
	RETURN(V11);}}
	}
	}
	}
}
/*	function definition for WARP-POINTER                          */
static L45(int narg, object V1, object V2, object V3)
{ VT47 VLEX47 CLSR47
	{int V4;
	int V5;
	V4= fix(V2);
	V5= fix(V3);
TTL:
	{register object V6;                      /*  .DISPLAY.       */
	V6= ((V1))->in.in_slots[1];
	if((((V6))->in.in_slots[10])==Cnil){
	goto L2089;}
	(*LK0)(3,VV[16],VV[10],(V6))              /*  X-ERROR         */;
L2089:
	{ int V7;
	{register object V8;                      /*  %BUFFER         */
	V8= (V6);
	if(!(((fix(((V8))->in.in_slots[6]))+(160))>=(fix(((V8))->in.in_slots[2])))){
	goto L2093;}
	(*LK7)(1,(V8))                            /*  BUFFER-FLUSH    */;
L2093:
	{register int V9;                         /*  BUFFER-BOFFSET  */
	register object V10;                      /*  BUFFER-BBUF     */
	V9= fix(((V8))->in.in_slots[6]);
	V10= ((V8))->in.in_slots[7];
	((V6))->in.in_slots[4]= MAKE_FIXNUM(V9);
	(((V10))->ust.ust_self[(V9)+(0)]=(41));
	((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(4))))=0);
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L2105;}
	((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(8))))=fix(((V1))->in.in_slots[0]));
	goto L2103;
L2105:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L2103:
	((*(short *)(((V10))->st.st_self+((V9)+(12))))=0);
	((*(short *)(((V10))->st.st_self+((V9)+(14))))=0);
	((*(unsigned short *)(((V10))->ust.ust_self+((V9)+(16))))=0);
	((*(unsigned short *)(((V10))->ust.ust_self+((V9)+(18))))=0);
	(*LK8)(2,MAKE_FIXNUM(V4),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2113;}
	((*(short *)(((V10))->st.st_self+((V9)+(20))))=V4);
	goto L2111;
L2113:
	(*LK4)(2,MAKE_FIXNUM(V4),VV[20])          /*  X-TYPE-ERROR    */;
L2111:
	(*LK8)(2,MAKE_FIXNUM(V5),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2117;}
	((*(short *)(((V10))->st.st_self+((V9)+(22))))=V5);
	goto L2115;
L2117:
	(*LK4)(2,MAKE_FIXNUM(V5),VV[20])          /*  X-TYPE-ERROR    */;
L2115:
	((*(unsigned short *)(((V10))->ust.ust_self+((V9)+(2))))=6);
	((V6))->in.in_slots[6]= MAKE_FIXNUM((V9)+(24));
	V7=(*LK13)(1,(V6))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V7);
	(*LK14)(1,(V6))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V7);
	RETURN(V7);}
	}
	}
}
/*	function definition for WARP-POINTER-RELATIVE                 */
static L46(int narg, object V1, object V2, object V3)
{ VT48 VLEX48 CLSR48
	{int V4;
	int V5;
	V4= fix(V2);
	V5= fix(V3);
TTL:
	{register object V6;                      /*  .DISPLAY.       */
	V6= (V1);
	if((((V6))->in.in_slots[10])==Cnil){
	goto L2122;}
	(*LK0)(3,VV[16],VV[10],(V6))              /*  X-ERROR         */;
L2122:
	{ int V7;
	{register object V8;                      /*  %BUFFER         */
	V8= (V6);
	if(!(((fix(((V8))->in.in_slots[6]))+(160))>=(fix(((V8))->in.in_slots[2])))){
	goto L2126;}
	(*LK7)(1,(V8))                            /*  BUFFER-FLUSH    */;
L2126:
	{register int V9;                         /*  BUFFER-BOFFSET  */
	register object V10;                      /*  BUFFER-BBUF     */
	V9= fix(((V8))->in.in_slots[6]);
	V10= ((V8))->in.in_slots[7];
	((V6))->in.in_slots[4]= MAKE_FIXNUM(V9);
	(((V10))->ust.ust_self[(V9)+(0)]=(41));
	((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(4))))=0);
	((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(8))))=0);
	((*(short *)(((V10))->st.st_self+((V9)+(12))))=0);
	((*(short *)(((V10))->st.st_self+((V9)+(14))))=0);
	((*(unsigned short *)(((V10))->ust.ust_self+((V9)+(16))))=0);
	((*(unsigned short *)(((V10))->ust.ust_self+((V9)+(18))))=0);
	(*LK8)(2,MAKE_FIXNUM(V4),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2143;}
	((*(short *)(((V10))->st.st_self+((V9)+(20))))=V4);
	goto L2141;
L2143:
	(*LK4)(2,MAKE_FIXNUM(V4),VV[20])          /*  X-TYPE-ERROR    */;
L2141:
	(*LK8)(2,MAKE_FIXNUM(V5),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2147;}
	((*(short *)(((V10))->st.st_self+((V9)+(22))))=V5);
	goto L2145;
L2147:
	(*LK4)(2,MAKE_FIXNUM(V5),VV[20])          /*  X-TYPE-ERROR    */;
L2145:
	((*(unsigned short *)(((V10))->ust.ust_self+((V9)+(2))))=6);
	((V6))->in.in_slots[6]= MAKE_FIXNUM((V9)+(24));
	V7=(*LK13)(1,(V6))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V7);
	(*LK14)(1,(V6))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V7);
	RETURN(V7);}
	}
	}
}
/*	function definition for WARP-POINTER-IF-INSIDE                */
static L47(int narg, object V1, object V2, object V3, object V4, object V5, object V6, ...)
{ VT49 VLEX49 CLSR49
	{int V7;
	int V8;
	int V9;
	int V10;int i=6;
	object V11;
	object V12;
	va_list args; va_start(args, V6);
	V7= fix(V2);
	V8= fix(V3);
	V9= fix(V5);
	V10= fix(V6);
	if (i==narg) goto L2152;
	V11= va_arg(args, object);
	i++;
	if (i==narg) goto L2153;
	V12= va_arg(args, object);
	i++;
	goto L2154;
L2152:
	V11= Cnil;
L2153:
	V12= Cnil;
L2154:
	if(eql((V11),MAKE_FIXNUM(0))){
	goto L2158;}
	if(eql((V12),MAKE_FIXNUM(0))){
	goto L2158;}
	{register object V13;                     /*  .DISPLAY.       */
	V13= ((V1))->in.in_slots[1];
	if((((V13))->in.in_slots[10])==Cnil){
	goto L2163;}
	(*LK0)(3,VV[16],VV[10],(V13))             /*  X-ERROR         */;
L2163:
	{ int V14;
	{register object V15;                     /*  %BUFFER         */
	V15= (V13);
	if(!(((fix(((V15))->in.in_slots[6]))+(160))>=(fix(((V15))->in.in_slots[2])))){
	goto L2167;}
	(*LK7)(1,(V15))                           /*  BUFFER-FLUSH    */;
L2167:
	{register int V16;                        /*  BUFFER-BOFFSET  */
	register object V17;                      /*  BUFFER-BBUF     */
	V16= fix(((V15))->in.in_slots[6]);
	V17= ((V15))->in.in_slots[7];
	((V13))->in.in_slots[4]= MAKE_FIXNUM(V16);
	(((V17))->ust.ust_self[(V16)+(0)]=(41));
	(*LK9)(1,(V4))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L2178;}
	((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(4))))=fix(((V4))->in.in_slots[0]));
	goto L2176;
L2178:
	(*LK4)(2,(V4),VV[9])                      /*  X-TYPE-ERROR    */;
L2176:
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L2182;}
	((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(8))))=fix(((V1))->in.in_slots[0]));
	goto L2180;
L2182:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L2180:
	(*LK8)(2,MAKE_FIXNUM(V9),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2186;}
	((*(short *)(((V17))->st.st_self+((V16)+(12))))=V9);
	goto L2184;
L2186:
	(*LK4)(2,MAKE_FIXNUM(V9),VV[20])          /*  X-TYPE-ERROR    */;
L2184:
	(*LK8)(2,MAKE_FIXNUM(V10),VV[20])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2190;}
	((*(short *)(((V17))->st.st_self+((V16)+(14))))=V10);
	goto L2188;
L2190:
	(*LK4)(2,MAKE_FIXNUM(V10),VV[20])         /*  X-TYPE-ERROR    */;
L2188:
	{object V18;                              /*  .VALUE.         */
	if((V11)!=Cnil){
	V18= (V11);
	goto L2193;}
	V18= MAKE_FIXNUM(0);
L2193:
	(*LK8)(2,(V18),VV[21])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2195;}
	((*(unsigned short *)(((V17))->ust.ust_self+((V16)+(16))))=fix((V18)));
	goto L2192;
L2195:
	(*LK4)(2,(V18),VV[21])                    /*  X-TYPE-ERROR    */;
	}
L2192:
	{object V18;                              /*  .VALUE.         */
	if((V12)!=Cnil){
	V18= (V12);
	goto L2198;}
	V18= MAKE_FIXNUM(0);
L2198:
	(*LK8)(2,(V18),VV[21])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2200;}
	((*(unsigned short *)(((V17))->ust.ust_self+((V16)+(18))))=fix((V18)));
	goto L2197;
L2200:
	(*LK4)(2,(V18),VV[21])                    /*  X-TYPE-ERROR    */;
	}
L2197:
	(*LK8)(2,MAKE_FIXNUM(V7),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2204;}
	((*(short *)(((V17))->st.st_self+((V16)+(20))))=V7);
	goto L2202;
L2204:
	(*LK4)(2,MAKE_FIXNUM(V7),VV[20])          /*  X-TYPE-ERROR    */;
L2202:
	(*LK8)(2,MAKE_FIXNUM(V8),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2208;}
	((*(short *)(((V17))->st.st_self+((V16)+(22))))=V8);
	goto L2206;
L2208:
	(*LK4)(2,MAKE_FIXNUM(V8),VV[20])          /*  X-TYPE-ERROR    */;
L2206:
	((*(unsigned short *)(((V17))->ust.ust_self+((V16)+(2))))=6);
	((V13))->in.in_slots[6]= MAKE_FIXNUM((V16)+(24));
	V14=(*LK13)(1,(V13))                      /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V14);
	(*LK14)(1,(V13))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V14);
	RETURN(V14);}
	}
L2158:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WARP-POINTER-RELATIVE-IF-INSIDE       */
static L48(int narg, object V1, object V2, object V3, object V4, object V5, ...)
{ VT50 VLEX50 CLSR50
	{int V6;
	int V7;
	int V8;
	int V9;int i=5;
	object V10;
	object V11;
	va_list args; va_start(args, V5);
	V6= fix(V1);
	V7= fix(V2);
	V8= fix(V4);
	V9= fix(V5);
	if (i==narg) goto L2213;
	V10= va_arg(args, object);
	i++;
	if (i==narg) goto L2214;
	V11= va_arg(args, object);
	i++;
	goto L2215;
L2213:
	V10= Cnil;
L2214:
	V11= Cnil;
L2215:
	if(eql((V10),MAKE_FIXNUM(0))){
	goto L2219;}
	if(eql((V11),MAKE_FIXNUM(0))){
	goto L2219;}
	{register object V12;                     /*  .DISPLAY.       */
	V12= ((V3))->in.in_slots[1];
	if((((V12))->in.in_slots[10])==Cnil){
	goto L2224;}
	(*LK0)(3,VV[16],VV[10],(V12))             /*  X-ERROR         */;
L2224:
	{ int V13;
	{register object V14;                     /*  %BUFFER         */
	V14= (V12);
	if(!(((fix(((V14))->in.in_slots[6]))+(160))>=(fix(((V14))->in.in_slots[2])))){
	goto L2228;}
	(*LK7)(1,(V14))                           /*  BUFFER-FLUSH    */;
L2228:
	{register int V15;                        /*  BUFFER-BOFFSET  */
	register object V16;                      /*  BUFFER-BBUF     */
	V15= fix(((V14))->in.in_slots[6]);
	V16= ((V14))->in.in_slots[7];
	((V12))->in.in_slots[4]= MAKE_FIXNUM(V15);
	(((V16))->ust.ust_self[(V15)+(0)]=(41));
	(*LK9)(1,(V3))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L2239;}
	((*(unsigned long *)(((V16))->ust.ust_self+((V15)+(4))))=fix(((V3))->in.in_slots[0]));
	goto L2237;
L2239:
	(*LK4)(2,(V3),VV[9])                      /*  X-TYPE-ERROR    */;
L2237:
	((*(unsigned long *)(((V16))->ust.ust_self+((V15)+(8))))=0);
	(*LK8)(2,MAKE_FIXNUM(V8),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2244;}
	((*(short *)(((V16))->st.st_self+((V15)+(12))))=V8);
	goto L2242;
L2244:
	(*LK4)(2,MAKE_FIXNUM(V8),VV[20])          /*  X-TYPE-ERROR    */;
L2242:
	(*LK8)(2,MAKE_FIXNUM(V9),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2248;}
	((*(short *)(((V16))->st.st_self+((V15)+(14))))=V9);
	goto L2246;
L2248:
	(*LK4)(2,MAKE_FIXNUM(V9),VV[20])          /*  X-TYPE-ERROR    */;
L2246:
	{object V17;                              /*  .VALUE.         */
	if((V10)!=Cnil){
	V17= (V10);
	goto L2251;}
	V17= MAKE_FIXNUM(0);
L2251:
	(*LK8)(2,(V17),VV[21])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2253;}
	((*(unsigned short *)(((V16))->ust.ust_self+((V15)+(16))))=fix((V17)));
	goto L2250;
L2253:
	(*LK4)(2,(V17),VV[21])                    /*  X-TYPE-ERROR    */;
	}
L2250:
	{object V17;                              /*  .VALUE.         */
	if((V11)!=Cnil){
	V17= (V11);
	goto L2256;}
	V17= MAKE_FIXNUM(0);
L2256:
	(*LK8)(2,(V17),VV[21])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2258;}
	((*(unsigned short *)(((V16))->ust.ust_self+((V15)+(18))))=fix((V17)));
	goto L2255;
L2258:
	(*LK4)(2,(V17),VV[21])                    /*  X-TYPE-ERROR    */;
	}
L2255:
	(*LK8)(2,MAKE_FIXNUM(V6),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2262;}
	((*(short *)(((V16))->st.st_self+((V15)+(20))))=V6);
	goto L2260;
L2262:
	(*LK4)(2,MAKE_FIXNUM(V6),VV[20])          /*  X-TYPE-ERROR    */;
L2260:
	(*LK8)(2,MAKE_FIXNUM(V7),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2266;}
	((*(short *)(((V16))->st.st_self+((V15)+(22))))=V7);
	goto L2264;
L2266:
	(*LK4)(2,MAKE_FIXNUM(V7),VV[20])          /*  X-TYPE-ERROR    */;
L2264:
	((*(unsigned short *)(((V16))->ust.ust_self+((V15)+(2))))=6);
	((V12))->in.in_slots[6]= MAKE_FIXNUM((V15)+(24));
	V13=(*LK13)(1,(V12))                      /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V13);
	(*LK14)(1,(V12))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V13);
	RETURN(V13);}
	}
L2219:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-INPUT-FOCUS                       */
static L49(int narg, object V1, object V2, object V3, ...)
{ VT51 VLEX51 CLSR51
	{int i=3;
	register object V4;
	va_list args; va_start(args, V3);
	if (i==narg) goto L2271;
	V4= va_arg(args, object);
	i++;
	goto L2272;
L2271:
	V4= Cnil;
L2272:
	{register object V5;                      /*  .DISPLAY.       */
	V5= (V1);
	if((((V5))->in.in_slots[10])==Cnil){
	goto L2274;}
	(*LK0)(3,VV[16],VV[10],(V5))              /*  X-ERROR         */;
L2274:
	{ int V6;
	{register object V7;                      /*  %BUFFER         */
	V7= (V5);
	if(!(((fix(((V7))->in.in_slots[6]))+(160))>=(fix(((V7))->in.in_slots[2])))){
	goto L2278;}
	(*LK7)(1,(V7))                            /*  BUFFER-FLUSH    */;
L2278:
	{register int V8;                         /*  BUFFER-BOFFSET  */
	register object V9;                       /*  BUFFER-BBUF     */
	V8= fix(((V7))->in.in_slots[6]);
	V9= ((V7))->in.in_slots[7];
	((V5))->in.in_slots[4]= MAKE_FIXNUM(V8);
	(((V9))->ust.ust_self[(V8)+(0)]=(42));
	(*LK8)(2,(V3),VV[105])                    /*  TYPEP           */;
	if(VALUES(0)!=Cnil){
	goto L2290;}
	VALUES(0) = Cnil;
	goto L2289;
L2290:
	VALUES(0) = (VV[305]->s.s_gfdef);
	(*LK10)(4,(V3),VV[106],VV[23],VALUES(0))  /*  POSITION        */;
	T0= VALUES(0);
	{int V10= ((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(4))))=fix(T0));
	VALUES(0) = MAKE_FIXNUM((((V9))->ust.ust_self[(V8)+(1)]=(V10)));}
L2289:
	if(VALUES(0)==Cnil)goto L2288;
	goto L2287;
L2288:
	(*LK4)(2,(V3),VV[107])                    /*  X-TYPE-ERROR    */;
L2287:
	(*LK9)(1,(V2))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L2296;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(4))))=fix(((V2))->in.in_slots[0]));
	goto L2294;
L2296:
	{object V10;
	{int V11;
	VALUES(0) = (VV[305]->s.s_gfdef);
	(*LK10)(4,(V2),VV[108],VV[23],VALUES(0))  /*  POSITION        */;
	V11= fix(VALUES(0));
	if(MAKE_FIXNUM(V11)==Cnil){
	V10= Cnil;
	goto L2298;}
	V10= MAKE_FIXNUM(((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(4))))=V11));
	}
L2298:
	if(((V10))==Cnil){
	goto L2302;}
	goto L2294;
L2302:
	(*LK4)(2,(V2),VV[109])                    /*  X-TYPE-ERROR    */;
	}
L2294:
	if(!((V4)==Cnil)){
	goto L2306;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(8))))=0);
	goto L2304;
L2306:
	(*LK8)(2,(V4),VV[26])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2309;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(8))))=fix((V4)));
	goto L2304;
L2309:
	(*LK4)(2,(V4),VV[110])                    /*  X-TYPE-ERROR    */;
L2304:
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=3);
	((V5))->in.in_slots[6]= MAKE_FIXNUM((V8)+(12));
	V6=(*LK13)(1,(V5))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V6);
	(*LK14)(1,(V5))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V6);
	RETURN(V6);}
	}
	}
}
/*	function definition for INPUT-FOCUS                           */
static L50(int narg, object V1)
{ VT52 VLEX52 CLSR52
TTL:
	{volatile object V2;                      /*  .DISPLAY.       */
	volatile object V3;                       /*  .PENDING-COMMAND.*/
	volatile object V4;                       /*  .REPLY-BUFFER.  */
	V2= (V1);
	V3= Cnil;
	V4= Cnil;
	{ int V5; volatile bool unwinding = FALSE;
	if ((V5=frs_push(FRS_PROTECT,Cnil))) {
	V5--; unwinding = TRUE;} else {
	if((((V2))->in.in_slots[10])==Cnil){
	goto L2316;}
	(*LK0)(3,VV[16],VV[10],(V2))              /*  X-ERROR         */;
L2316:
	(*LK15)(1,(V2))                           /*  START-PENDING-COMMAND*/;
	V3= VALUES(0);
	{register object V6;                      /*  %BUFFER         */
	V6= (V2);
	if(!(((fix(((V6))->in.in_slots[6]))+(160))>=(fix(((V6))->in.in_slots[2])))){
	goto L2322;}
	(*LK7)(1,(V6))                            /*  BUFFER-FLUSH    */;
L2322:
	{register int V7;                         /*  BUFFER-BOFFSET  */
	object V8;                                /*  BUFFER-BBUF     */
	V7= fix(((V6))->in.in_slots[6]);
	V8= ((V6))->in.in_slots[7];
	((V2))->in.in_slots[4]= MAKE_FIXNUM(V7);
	(((V8))->ust.ust_self[(V7)+(0)]=(43));
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(2))))=1);
	((V2))->in.in_slots[6]= MAKE_FIXNUM((V7)+(4));
	(*LK13)(1,(V2))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V2))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V2))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V2),(V3))                      /*  READ-REPLY      */;
	V4= VALUES(0);
	{object V6;                               /*  %REPLY-BUFFER   */
	object V7;                                /*  %BUFFER         */
	{register int V8;                         /*  BUFFER-BOFFSET  */
	object V9;                                /*  BUFFER-BBUF     */
	V8= 0;
	V9= ((V4))->in.in_slots[1];
	{int V10;
	V10= (*(unsigned long *)(((V9))->ust.ust_self+((V8)+(8))));
	{object V11;
	{int V12;
	V12= V10;
	if((V12)<(2)){
	goto L2346;}
	V11= Cnil;
	goto L2344;
L2346:
	V11= (VV[111])->v.v_self[V12];
	}
L2344:
	if(((V11))==Cnil){
	goto L2349;}
	T0= (V11);
	goto L2342;
L2349:
	{object V12;
	(*LK18)(2,(V2),MAKE_FIXNUM(V10))          /*  LOOKUP-WINDOW   */;
	V12= VALUES(0);
	if(((V12))==Cnil){
	goto L2353;}
	T0= (V12);
	goto L2342;
L2353:
	T0= Cnil;
	}
	}
	}
L2342:
	{int V10;
	V10= ((V9))->ust.ust_self[(V8)+(1)];
	if((V10)<(3)){
	goto L2357;}
	VALUES(0) = Cnil;
	goto L2355;
L2357:
	VALUES(0) = (VV[112])->v.v_self[V10];
	}
L2355:
	VALUES(1) = VALUES(0);
	VALUES(0) = T0;
	V5=2;
	}
	}
	}
	frs_pop();
	MV_SAVE(V5);
	if(((V4))==Cnil){
	goto L2360;}
	(*LK20)(1,(V4))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L2360:
	if(((V3))==Cnil){
	goto L2359;}
	(*LK21)(2,(V2),(V3))                      /*  STOP-PENDING-COMMAND*/;
L2359:
	MV_RESTORE(V5);
	if (unwinding) unwind(nlj_fr,nlj_tag,V5+1);
	else {
	RETURN(V5);}}
	}
}
/*	function definition for QUERY-KEYMAP                          */
static L51(int narg, object V1, ...)
{ VT53 VLEX53 CLSR53
	{int i=1;
	volatile object V2;
	va_list args; va_start(args, V1);
	if (i==narg) goto L2365;
	V2= va_arg(args, object);
	i++;
	goto L2366;
L2365:
	V2= Cnil;
L2366:
	{volatile object V3;                      /*  .DISPLAY.       */
	volatile object V4;                       /*  .PENDING-COMMAND.*/
	volatile object V5;                       /*  .REPLY-BUFFER.  */
	V3= (V1);
	V4= Cnil;
	V5= Cnil;
	{ int V6; volatile bool unwinding = FALSE;
	if ((V6=frs_push(FRS_PROTECT,Cnil))) {
	V6--; unwinding = TRUE;} else {
	if((((V3))->in.in_slots[10])==Cnil){
	goto L2370;}
	(*LK0)(3,VV[16],VV[10],(V3))              /*  X-ERROR         */;
L2370:
	(*LK15)(1,(V3))                           /*  START-PENDING-COMMAND*/;
	V4= VALUES(0);
	{register object V7;                      /*  %BUFFER         */
	V7= (V3);
	if(!(((fix(((V7))->in.in_slots[6]))+(160))>=(fix(((V7))->in.in_slots[2])))){
	goto L2376;}
	(*LK7)(1,(V7))                            /*  BUFFER-FLUSH    */;
L2376:
	{register int V8;                         /*  BUFFER-BOFFSET  */
	object V9;                                /*  BUFFER-BBUF     */
	V8= fix(((V7))->in.in_slots[6]);
	V9= ((V7))->in.in_slots[7];
	((V3))->in.in_slots[4]= MAKE_FIXNUM(V8);
	(((V9))->ust.ust_self[(V8)+(0)]=(44));
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=1);
	((V3))->in.in_slots[6]= MAKE_FIXNUM((V8)+(4));
	(*LK13)(1,(V3))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V3))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V3))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V3),(V4))                      /*  READ-REPLY      */;
	V5= VALUES(0);
	{object V7;                               /*  %REPLY-BUFFER   */
	object V8;                                /*  %BUFFER         */
	{object V9;                               /*  BUFFER-BBUF     */
	V9= ((V5))->in.in_slots[1];
	V6=(*LK38)(3,(V9),MAKE_FIXNUM(8),(V2))    /*  READ-BITVECTOR256*/;
	}
	}
	}
	frs_pop();
	MV_SAVE(V6);
	if(((V5))==Cnil){
	goto L2396;}
	(*LK20)(1,(V5))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L2396:
	if(((V4))==Cnil){
	goto L2395;}
	(*LK21)(2,(V3),(V4))                      /*  STOP-PENDING-COMMAND*/;
L2395:
	MV_RESTORE(V6);
	if (unwinding) unwind(nlj_fr,nlj_tag,V6+1);
	else {
	RETURN(V6);}}
	}
	}
}
/*	function definition for CREATE-PIXMAP                         */
static L52(int narg, ...)
{ VT54 VLEX54 CLSR54
	{object V1;
	int V2;
	int V3;
	int V4;
	register object V5;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[10];
	parse_key(narg,args,5,L52keys,keyvars,OBJNULL,FALSE);
	V1= keyvars[0];
	if(keyvars[6]==Cnil){
	(*LK0)(3,VV[0],VV[1],VV[6])               /*  X-ERROR         */;
	V2= fix((VV[3]->s.s_dbind));
	}else{
	V2= fix(keyvars[1]);}
	if(keyvars[7]==Cnil){
	(*LK0)(3,VV[0],VV[1],VV[7])               /*  X-ERROR         */;
	V3= fix((VV[3]->s.s_dbind));
	}else{
	V3= fix(keyvars[2]);}
	if(keyvars[8]==Cnil){
	(*LK0)(3,VV[0],VV[1],VV[113])             /*  X-ERROR         */;
	V4= fix((VV[3]->s.s_dbind));
	}else{
	V4= fix(keyvars[3]);}
	if(keyvars[9]==Cnil){
	(*LK0)(3,VV[0],VV[1],VV[114])             /*  X-ERROR         */;
	V5= (VV[3]->s.s_dbind);
	}else{
	V5= keyvars[4];}
	}
	{register object V6;                      /*  DISPLAY         */
	object V7;                                /*  PIXMAP          */
	register int V8;                          /*  PID             */
	V6= ((V5))->in.in_slots[1];
	if((V1)!=Cnil){
	V7= (V1);
	goto L2410;}
	(*LK39)(2,VV[10],(V6))                    /*  MAKE-PIXMAP     */;
	V7= VALUES(0);
L2410:
	{object V9;                               /*  ID              */
	T0= ((V6))->in.in_slots[35];
	funcall(2,T0,(V6));
	V9= VALUES(0);
	(*LK2)(3,(V6),(V9),(V7))                  /*  SAVE-ID         */;
	V8= fix((V9));
	}
	((V7))->in.in_slots[0]= MAKE_FIXNUM(V8);
	{register object V9;                      /*  .DISPLAY.       */
	V9= (V6);
	if((((V9))->in.in_slots[10])==Cnil){
	goto L2417;}
	(*LK0)(3,VV[16],VV[10],(V9))              /*  X-ERROR         */;
L2417:
	{register object V10;                     /*  %BUFFER         */
	V10= (V9);
	if(!(((fix(((V10))->in.in_slots[6]))+(160))>=(fix(((V10))->in.in_slots[2])))){
	goto L2421;}
	(*LK7)(1,(V10))                           /*  BUFFER-FLUSH    */;
L2421:
	{register int V11;                        /*  BUFFER-BOFFSET  */
	register object V12;                      /*  BUFFER-BBUF     */
	V11= fix(((V10))->in.in_slots[6]);
	V12= ((V10))->in.in_slots[7];
	((V9))->in.in_slots[4]= MAKE_FIXNUM(V11);
	(((V12))->ust.ust_self[(V11)+(0)]=(53));
	(*LK8)(2,MAKE_FIXNUM(V4),VV[17])          /*  TYPEP           */;
	if(VALUES(0)!=Cnil){
	goto L2433;}
	VALUES(0) = Cnil;
	goto L2432;
L2433:
	VALUES(0) = MAKE_FIXNUM((((V12))->ust.ust_self[(V11)+(1)]=(V4)));
L2432:
	if(VALUES(0)==Cnil)goto L2431;
	goto L2430;
L2431:
	(*LK4)(2,MAKE_FIXNUM(V4),VV[18])          /*  X-TYPE-ERROR    */;
L2430:
	(*LK8)(2,MAKE_FIXNUM(V8),VV[19])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2437;}
	((*(unsigned long *)(((V12))->ust.ust_self+((V11)+(4))))=V8);
	goto L2435;
L2437:
	(*LK4)(2,MAKE_FIXNUM(V8),VV[19])          /*  X-TYPE-ERROR    */;
L2435:
	(*LK40)(1,(V5))                           /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L2441;}
	((*(unsigned long *)(((V12))->ust.ust_self+((V11)+(8))))=fix(((V5))->in.in_slots[0]));
	goto L2439;
L2441:
	(*LK4)(2,(V5),VV[114])                    /*  X-TYPE-ERROR    */;
L2439:
	(*LK8)(2,MAKE_FIXNUM(V2),VV[21])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2445;}
	((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(12))))=V2);
	goto L2443;
L2445:
	(*LK4)(2,MAKE_FIXNUM(V2),VV[21])          /*  X-TYPE-ERROR    */;
L2443:
	(*LK8)(2,MAKE_FIXNUM(V3),VV[21])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2449;}
	((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(14))))=V3);
	goto L2447;
L2449:
	(*LK4)(2,MAKE_FIXNUM(V3),VV[21])          /*  X-TYPE-ERROR    */;
L2447:
	((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(2))))=4);
	((V9))->in.in_slots[6]= MAKE_FIXNUM((V11)+(16));
	(*LK13)(1,(V9))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK14)(1,(V9))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	VALUES(0) = (V7);
	RETURN(1);
	}
	}
}
/*	function definition for FREE-PIXMAP                           */
static L53(int narg, object V1)
{ VT55 VLEX55 CLSR55
TTL:
	{object V2;                               /*  DISPLAY         */
	V2= ((V1))->in.in_slots[1];
	{register object V3;                      /*  .DISPLAY.       */
	V3= (V2);
	if((((V3))->in.in_slots[10])==Cnil){
	goto L2455;}
	(*LK0)(3,VV[16],VV[10],(V3))              /*  X-ERROR         */;
L2455:
	{register object V4;                      /*  %BUFFER         */
	V4= (V3);
	if(!(((fix(((V4))->in.in_slots[6]))+(160))>=(fix(((V4))->in.in_slots[2])))){
	goto L2459;}
	(*LK7)(1,(V4))                            /*  BUFFER-FLUSH    */;
L2459:
	{register int V5;                         /*  BUFFER-BOFFSET  */
	register object V6;                       /*  BUFFER-BBUF     */
	V5= fix(((V4))->in.in_slots[6]);
	V6= ((V4))->in.in_slots[7];
	((V3))->in.in_slots[4]= MAKE_FIXNUM(V5);
	(((V6))->ust.ust_self[(V5)+(0)]=(54));
	(*LK3)(1,(V1))                            /*  PIXMAP-P        */;
	if(VALUES(0)==Cnil){
	goto L2470;}
	((*(unsigned long *)(((V6))->ust.ust_self+((V5)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L2468;
L2470:
	(*LK4)(2,(V1),VV[12])                     /*  X-TYPE-ERROR    */;
L2468:
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(2))))=2);
	((V3))->in.in_slots[6]= MAKE_FIXNUM((V5)+(8));
	(*LK13)(1,(V3))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK14)(1,(V3))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	RETURN((*LK41)(2,(V2),((V1))->in.in_slots[0])/*  DEALLOCATE-RESOURCE-ID-INTERNAL*/);
	}
}
/*	function definition for CLEAR-AREA                            */
static L54(int narg, object V1, ...)
{ VT56 VLEX56 CLSR56
	{int V2;
	int V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[10];
	parse_key(narg,args,5,L54keys,keyvars,OBJNULL,FALSE);
	if(keyvars[5]==Cnil){
	V2= 0;
	}else{
	V2= fix(keyvars[0]);}
	if(keyvars[6]==Cnil){
	V3= 0;
	}else{
	V3= fix(keyvars[1]);}
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	}
	if(eql((V4),MAKE_FIXNUM(0))){
	goto L2477;}
	if(eql((V5),MAKE_FIXNUM(0))){
	goto L2477;}
	{register object V7;                      /*  .DISPLAY.       */
	V7= ((V1))->in.in_slots[1];
	if((((V7))->in.in_slots[10])==Cnil){
	goto L2482;}
	(*LK0)(3,VV[16],VV[10],(V7))              /*  X-ERROR         */;
L2482:
	{ int V8;
	{register object V9;                      /*  %BUFFER         */
	V9= (V7);
	if(!(((fix(((V9))->in.in_slots[6]))+(160))>=(fix(((V9))->in.in_slots[2])))){
	goto L2486;}
	(*LK7)(1,(V9))                            /*  BUFFER-FLUSH    */;
L2486:
	{register int V10;                        /*  BUFFER-BOFFSET  */
	register object V11;                      /*  BUFFER-BBUF     */
	V10= fix(((V9))->in.in_slots[6]);
	V11= ((V9))->in.in_slots[7];
	((V7))->in.in_slots[4]= MAKE_FIXNUM(V10);
	(((V11))->ust.ust_self[(V10)+(0)]=(61));
	if(((V6))==Cnil){
	goto L2500;}
	T0= MAKE_FIXNUM(1);
	goto L2498;
L2500:
	T0= MAKE_FIXNUM(0);
L2498:
	VALUES(0) = MAKE_FIXNUM((((V11))->ust.ust_self[(V10)+(1)]=(fix(T0))));
	if(VALUES(0)==Cnil)goto L2496;
	goto L2495;
L2496:
	(*LK4)(2,(V6),VV[115])                    /*  X-TYPE-ERROR    */;
L2495:
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L2504;}
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L2502;
L2504:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L2502:
	(*LK8)(2,MAKE_FIXNUM(V2),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2508;}
	((*(short *)(((V11))->st.st_self+((V10)+(8))))=V2);
	goto L2506;
L2508:
	(*LK4)(2,MAKE_FIXNUM(V2),VV[20])          /*  X-TYPE-ERROR    */;
L2506:
	(*LK8)(2,MAKE_FIXNUM(V3),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2512;}
	((*(short *)(((V11))->st.st_self+((V10)+(10))))=V3);
	goto L2510;
L2512:
	(*LK4)(2,MAKE_FIXNUM(V3),VV[20])          /*  X-TYPE-ERROR    */;
L2510:
	{object V12;                              /*  .VALUE.         */
	if((V4)!=Cnil){
	V12= (V4);
	goto L2515;}
	V12= MAKE_FIXNUM(0);
L2515:
	(*LK8)(2,(V12),VV[21])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2517;}
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(12))))=fix((V12)));
	goto L2514;
L2517:
	(*LK4)(2,(V12),VV[21])                    /*  X-TYPE-ERROR    */;
	}
L2514:
	{object V12;                              /*  .VALUE.         */
	if((V5)!=Cnil){
	V12= (V5);
	goto L2520;}
	V12= MAKE_FIXNUM(0);
L2520:
	(*LK8)(2,(V12),VV[21])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2522;}
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(14))))=fix((V12)));
	goto L2519;
L2522:
	(*LK4)(2,(V12),VV[21])                    /*  X-TYPE-ERROR    */;
	}
L2519:
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(2))))=4);
	((V7))->in.in_slots[6]= MAKE_FIXNUM((V10)+(16));
	V8=(*LK13)(1,(V7))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V8);
	(*LK14)(1,(V7))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V8);
	RETURN(V8);}
	}
L2477:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for COPY-AREA                             */
static L55(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT57 VLEX57 CLSR57
	{int V10;
	int V11;
	int V12;
	int V13;
	int V14;
	int V15;
	V10= fix(V3);
	V11= fix(V4);
	V12= fix(V5);
	V13= fix(V6);
	V14= fix(V8);
	V15= fix(V9);
TTL:
	{register object V16;                     /*  .DISPLAY.       */
	V16= ((V1))->in.in_slots[1];
	if((((V16))->in.in_slots[10])==Cnil){
	goto L2528;}
	(*LK0)(3,VV[16],VV[10],(V16))             /*  X-ERROR         */;
L2528:
	(*LK42)(1,(V2))                           /*  FORCE-GCONTEXT-CHANGES-INTERNAL*/;
	{ int V17;
	{register object V18;                     /*  %BUFFER         */
	V18= (V16);
	if(!(((fix(((V18))->in.in_slots[6]))+(160))>=(fix(((V18))->in.in_slots[2])))){
	goto L2533;}
	(*LK7)(1,(V18))                           /*  BUFFER-FLUSH    */;
L2533:
	{register int V19;                        /*  BUFFER-BOFFSET  */
	register object V20;                      /*  BUFFER-BBUF     */
	V19= fix(((V18))->in.in_slots[6]);
	V20= ((V18))->in.in_slots[7];
	((V16))->in.in_slots[4]= MAKE_FIXNUM(V19);
	(((V20))->ust.ust_self[(V19)+(0)]=(62));
	(*LK40)(1,(V1))                           /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L2544;}
	((*(unsigned long *)(((V20))->ust.ust_self+((V19)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L2542;
L2544:
	(*LK4)(2,(V1),VV[114])                    /*  X-TYPE-ERROR    */;
L2542:
	(*LK40)(1,(V7))                           /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L2548;}
	((*(unsigned long *)(((V20))->ust.ust_self+((V19)+(8))))=fix(((V7))->in.in_slots[0]));
	goto L2546;
L2548:
	(*LK4)(2,(V7),VV[114])                    /*  X-TYPE-ERROR    */;
L2546:
	(*LK43)(1,(V2))                           /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L2552;}
	((*(unsigned long *)(((V20))->ust.ust_self+((V19)+(12))))=fix(((V2))->in.in_slots[0]));
	goto L2550;
L2552:
	(*LK4)(2,(V2),VV[116])                    /*  X-TYPE-ERROR    */;
L2550:
	(*LK8)(2,MAKE_FIXNUM(V10),VV[20])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2556;}
	((*(short *)(((V20))->st.st_self+((V19)+(16))))=V10);
	goto L2554;
L2556:
	(*LK4)(2,MAKE_FIXNUM(V10),VV[20])         /*  X-TYPE-ERROR    */;
L2554:
	(*LK8)(2,MAKE_FIXNUM(V11),VV[20])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2560;}
	((*(short *)(((V20))->st.st_self+((V19)+(18))))=V11);
	goto L2558;
L2560:
	(*LK4)(2,MAKE_FIXNUM(V11),VV[20])         /*  X-TYPE-ERROR    */;
L2558:
	(*LK8)(2,MAKE_FIXNUM(V14),VV[20])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2564;}
	((*(short *)(((V20))->st.st_self+((V19)+(20))))=V14);
	goto L2562;
L2564:
	(*LK4)(2,MAKE_FIXNUM(V14),VV[20])         /*  X-TYPE-ERROR    */;
L2562:
	(*LK8)(2,MAKE_FIXNUM(V15),VV[20])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2568;}
	((*(short *)(((V20))->st.st_self+((V19)+(22))))=V15);
	goto L2566;
L2568:
	(*LK4)(2,MAKE_FIXNUM(V15),VV[20])         /*  X-TYPE-ERROR    */;
L2566:
	(*LK8)(2,MAKE_FIXNUM(V12),VV[21])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2572;}
	((*(unsigned short *)(((V20))->ust.ust_self+((V19)+(24))))=V12);
	goto L2570;
L2572:
	(*LK4)(2,MAKE_FIXNUM(V12),VV[21])         /*  X-TYPE-ERROR    */;
L2570:
	(*LK8)(2,MAKE_FIXNUM(V13),VV[21])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2576;}
	((*(unsigned short *)(((V20))->ust.ust_self+((V19)+(26))))=V13);
	goto L2574;
L2576:
	(*LK4)(2,MAKE_FIXNUM(V13),VV[21])         /*  X-TYPE-ERROR    */;
L2574:
	((*(unsigned short *)(((V20))->ust.ust_self+((V19)+(2))))=7);
	((V16))->in.in_slots[6]= MAKE_FIXNUM((V19)+(28));
	V17=(*LK13)(1,(V16))                      /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V17);
	(*LK14)(1,(V16))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V17);
	RETURN(V17);}
	}
	}
}
/*	function definition for COPY-PLANE                            */
static L56(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9, object V10)
{ VT58 VLEX58 CLSR58
	{int V11;
	int V12;
	int V13;
	int V14;
	int V15;
	int V16;
	V11= fix(V4);
	V12= fix(V5);
	V13= fix(V6);
	V14= fix(V7);
	V15= fix(V9);
	V16= fix(V10);
TTL:
	{register object V17;                     /*  .DISPLAY.       */
	V17= ((V1))->in.in_slots[1];
	if((((V17))->in.in_slots[10])==Cnil){
	goto L2582;}
	(*LK0)(3,VV[16],VV[10],(V17))             /*  X-ERROR         */;
L2582:
	(*LK42)(1,(V2))                           /*  FORCE-GCONTEXT-CHANGES-INTERNAL*/;
	{ int V18;
	{register object V19;                     /*  %BUFFER         */
	V19= (V17);
	if(!(((fix(((V19))->in.in_slots[6]))+(160))>=(fix(((V19))->in.in_slots[2])))){
	goto L2587;}
	(*LK7)(1,(V19))                           /*  BUFFER-FLUSH    */;
L2587:
	{register int V20;                        /*  BUFFER-BOFFSET  */
	register object V21;                      /*  BUFFER-BBUF     */
	V20= fix(((V19))->in.in_slots[6]);
	V21= ((V19))->in.in_slots[7];
	((V17))->in.in_slots[4]= MAKE_FIXNUM(V20);
	(((V21))->ust.ust_self[(V20)+(0)]=(63));
	(*LK40)(1,(V1))                           /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L2598;}
	((*(unsigned long *)(((V21))->ust.ust_self+((V20)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L2596;
L2598:
	(*LK4)(2,(V1),VV[114])                    /*  X-TYPE-ERROR    */;
L2596:
	(*LK40)(1,(V8))                           /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L2602;}
	((*(unsigned long *)(((V21))->ust.ust_self+((V20)+(8))))=fix(((V8))->in.in_slots[0]));
	goto L2600;
L2602:
	(*LK4)(2,(V8),VV[114])                    /*  X-TYPE-ERROR    */;
L2600:
	(*LK43)(1,(V2))                           /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L2606;}
	((*(unsigned long *)(((V21))->ust.ust_self+((V20)+(12))))=fix(((V2))->in.in_slots[0]));
	goto L2604;
L2606:
	(*LK4)(2,(V2),VV[116])                    /*  X-TYPE-ERROR    */;
L2604:
	(*LK8)(2,MAKE_FIXNUM(V11),VV[20])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2610;}
	((*(short *)(((V21))->st.st_self+((V20)+(16))))=V11);
	goto L2608;
L2610:
	(*LK4)(2,MAKE_FIXNUM(V11),VV[20])         /*  X-TYPE-ERROR    */;
L2608:
	(*LK8)(2,MAKE_FIXNUM(V12),VV[20])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2614;}
	((*(short *)(((V21))->st.st_self+((V20)+(18))))=V12);
	goto L2612;
L2614:
	(*LK4)(2,MAKE_FIXNUM(V12),VV[20])         /*  X-TYPE-ERROR    */;
L2612:
	(*LK8)(2,MAKE_FIXNUM(V15),VV[20])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2618;}
	((*(short *)(((V21))->st.st_self+((V20)+(20))))=V15);
	goto L2616;
L2618:
	(*LK4)(2,MAKE_FIXNUM(V15),VV[20])         /*  X-TYPE-ERROR    */;
L2616:
	(*LK8)(2,MAKE_FIXNUM(V16),VV[20])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2622;}
	((*(short *)(((V21))->st.st_self+((V20)+(22))))=V16);
	goto L2620;
L2622:
	(*LK4)(2,MAKE_FIXNUM(V16),VV[20])         /*  X-TYPE-ERROR    */;
L2620:
	(*LK8)(2,MAKE_FIXNUM(V13),VV[21])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2626;}
	((*(unsigned short *)(((V21))->ust.ust_self+((V20)+(24))))=V13);
	goto L2624;
L2626:
	(*LK4)(2,MAKE_FIXNUM(V13),VV[21])         /*  X-TYPE-ERROR    */;
L2624:
	(*LK8)(2,MAKE_FIXNUM(V14),VV[21])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2630;}
	((*(unsigned short *)(((V21))->ust.ust_self+((V20)+(26))))=V14);
	goto L2628;
L2630:
	(*LK4)(2,MAKE_FIXNUM(V14),VV[21])         /*  X-TYPE-ERROR    */;
L2628:
	(*LK8)(2,(V3),VV[26])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2634;}
	((*(unsigned long *)(((V21))->ust.ust_self+((V20)+(28))))=fix((V3)));
	goto L2632;
L2634:
	(*LK4)(2,(V3),VV[26])                     /*  X-TYPE-ERROR    */;
L2632:
	((*(unsigned short *)(((V21))->ust.ust_self+((V20)+(2))))=8);
	((V17))->in.in_slots[6]= MAKE_FIXNUM((V20)+(32));
	V18=(*LK13)(1,(V17))                      /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V18);
	(*LK14)(1,(V17))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V18);
	RETURN(V18);}
	}
	}
}
/*	function definition for CREATE-COLORMAP                       */
static L57(int narg, object V1, object V2, ...)
{ VT59 VLEX59 CLSR59
	{int i=2;
	object V3;
	va_list args; va_start(args, V2);
	if (i==narg) goto L2639;
	V3= va_arg(args, object);
	i++;
	goto L2640;
L2639:
	V3= Cnil;
L2640:
	{register object V4;                      /*  DISPLAY         */
	V4= ((V2))->in.in_slots[1];
	(*LK8)(2,(V1),VV[19])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2643;}
	(*LK44)(2,(V4),(V1))                      /*  VISUAL-INFO     */;
	V1= VALUES(0);
L2643:
	{object V5;                               /*  COLORMAP        */
	register int V6;                          /*  ID              */
	(*LK45)(4,VV[10],(V4),VV[117],(V1))       /*  MAKE-COLORMAP   */;
	V5= VALUES(0);
	{object V7;                               /*  ID              */
	T0= ((V4))->in.in_slots[35];
	funcall(2,T0,(V4));
	V7= VALUES(0);
	(*LK2)(3,(V4),(V7),(V5))                  /*  SAVE-ID         */;
	V6= fix((V7));
	}
	((V5))->in.in_slots[0]= MAKE_FIXNUM(V6);
	{register object V7;                      /*  .DISPLAY.       */
	V7= (V4);
	if((((V7))->in.in_slots[10])==Cnil){
	goto L2654;}
	(*LK0)(3,VV[16],VV[10],(V7))              /*  X-ERROR         */;
L2654:
	{register object V8;                      /*  %BUFFER         */
	V8= (V7);
	if(!(((fix(((V8))->in.in_slots[6]))+(160))>=(fix(((V8))->in.in_slots[2])))){
	goto L2658;}
	(*LK7)(1,(V8))                            /*  BUFFER-FLUSH    */;
L2658:
	{register int V9;                         /*  BUFFER-BOFFSET  */
	register object V10;                      /*  BUFFER-BBUF     */
	V9= fix(((V8))->in.in_slots[6]);
	V10= ((V8))->in.in_slots[7];
	((V7))->in.in_slots[4]= MAKE_FIXNUM(V9);
	(((V10))->ust.ust_self[(V9)+(0)]=(78));
	if(((V3))==Cnil){
	goto L2672;}
	T0= MAKE_FIXNUM(1);
	goto L2670;
L2672:
	T0= MAKE_FIXNUM(0);
L2670:
	VALUES(0) = MAKE_FIXNUM((((V10))->ust.ust_self[(V9)+(1)]=(fix(T0))));
	if(VALUES(0)==Cnil)goto L2668;
	goto L2667;
L2668:
	(*LK4)(2,(V3),VV[118])                    /*  X-TYPE-ERROR    */;
L2667:
	(*LK8)(2,MAKE_FIXNUM(V6),VV[119])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2676;}
	((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(4))))=V6);
	goto L2674;
L2676:
	(*LK4)(2,MAKE_FIXNUM(V6),VV[119])         /*  X-TYPE-ERROR    */;
L2674:
	(*LK9)(1,(V2))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L2680;}
	((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(8))))=fix(((V2))->in.in_slots[0]));
	goto L2678;
L2680:
	(*LK4)(2,(V2),VV[9])                      /*  X-TYPE-ERROR    */;
L2678:
	{register int V11;                        /*  .VALUE.         */
	V11= fix(((V1))->in.in_slots[0]);
	(*LK8)(2,MAKE_FIXNUM(V11),VV[119])        /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2685;}
	((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(12))))=V11);
	goto L2682;
L2685:
	(*LK4)(2,MAKE_FIXNUM(V11),VV[119])        /*  X-TYPE-ERROR    */;
	}
L2682:
	((*(unsigned short *)(((V10))->ust.ust_self+((V9)+(2))))=4);
	((V7))->in.in_slots[6]= MAKE_FIXNUM((V9)+(16));
	(*LK13)(1,(V7))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK14)(1,(V7))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	VALUES(0) = (V5);
	RETURN(1);
	}
	}
	}
}
/*	function definition for FREE-COLORMAP                         */
static L58(int narg, object V1)
{ VT60 VLEX60 CLSR60
TTL:
	{object V2;                               /*  DISPLAY         */
	V2= ((V1))->in.in_slots[1];
	{register object V3;                      /*  .DISPLAY.       */
	V3= (V2);
	if((((V3))->in.in_slots[10])==Cnil){
	goto L2691;}
	(*LK0)(3,VV[16],VV[10],(V3))              /*  X-ERROR         */;
L2691:
	{register object V4;                      /*  %BUFFER         */
	V4= (V3);
	if(!(((fix(((V4))->in.in_slots[6]))+(160))>=(fix(((V4))->in.in_slots[2])))){
	goto L2695;}
	(*LK7)(1,(V4))                            /*  BUFFER-FLUSH    */;
L2695:
	{register int V5;                         /*  BUFFER-BOFFSET  */
	register object V6;                       /*  BUFFER-BBUF     */
	V5= fix(((V4))->in.in_slots[6]);
	V6= ((V4))->in.in_slots[7];
	((V3))->in.in_slots[4]= MAKE_FIXNUM(V5);
	(((V6))->ust.ust_self[(V5)+(0)]=(79));
	(*LK11)(1,(V1))                           /*  COLORMAP-P      */;
	if(VALUES(0)==Cnil){
	goto L2706;}
	((*(unsigned long *)(((V6))->ust.ust_self+((V5)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L2704;
L2706:
	(*LK4)(2,(V1),VV[37])                     /*  X-TYPE-ERROR    */;
L2704:
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(2))))=2);
	((V3))->in.in_slots[6]= MAKE_FIXNUM((V5)+(8));
	(*LK13)(1,(V3))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK14)(1,(V3))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	RETURN((*LK41)(2,(V2),((V1))->in.in_slots[0])/*  DEALLOCATE-RESOURCE-ID-INTERNAL*/);
	}
}
/*	function definition for COPY-COLORMAP-AND-FREE                */
static L59(int narg, object V1)
{ VT61 VLEX61 CLSR61
TTL:
	{register object V2;                      /*  DISPLAY         */
	object V3;                                /*  NEW-COLORMAP    */
	register int V4;                          /*  ID              */
	V2= ((V1))->in.in_slots[1];
	(*LK45)(4,VV[10],(V2),VV[117],((V1))->in.in_slots[2])/*  MAKE-COLORMAP*/;
	V3= VALUES(0);
	{object V5;                               /*  ID              */
	T0= ((V2))->in.in_slots[35];
	funcall(2,T0,(V2));
	V5= VALUES(0);
	(*LK2)(3,(V2),(V5),(V3))                  /*  SAVE-ID         */;
	V4= fix((V5));
	}
	((V3))->in.in_slots[0]= MAKE_FIXNUM(V4);
	{register object V5;                      /*  .DISPLAY.       */
	V5= (V2);
	if((((V5))->in.in_slots[10])==Cnil){
	goto L2718;}
	(*LK0)(3,VV[16],VV[10],(V5))              /*  X-ERROR         */;
L2718:
	{register object V6;                      /*  %BUFFER         */
	V6= (V5);
	if(!(((fix(((V6))->in.in_slots[6]))+(160))>=(fix(((V6))->in.in_slots[2])))){
	goto L2722;}
	(*LK7)(1,(V6))                            /*  BUFFER-FLUSH    */;
L2722:
	{register int V7;                         /*  BUFFER-BOFFSET  */
	register object V8;                       /*  BUFFER-BBUF     */
	V7= fix(((V6))->in.in_slots[6]);
	V8= ((V6))->in.in_slots[7];
	((V5))->in.in_slots[4]= MAKE_FIXNUM(V7);
	(((V8))->ust.ust_self[(V7)+(0)]=(80));
	(*LK8)(2,MAKE_FIXNUM(V4),VV[19])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2733;}
	((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(4))))=V4);
	goto L2731;
L2733:
	(*LK4)(2,MAKE_FIXNUM(V4),VV[19])          /*  X-TYPE-ERROR    */;
L2731:
	(*LK11)(1,(V1))                           /*  COLORMAP-P      */;
	if(VALUES(0)==Cnil){
	goto L2737;}
	((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(8))))=fix(((V1))->in.in_slots[0]));
	goto L2735;
L2737:
	(*LK4)(2,(V1),VV[37])                     /*  X-TYPE-ERROR    */;
L2735:
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(2))))=3);
	((V5))->in.in_slots[6]= MAKE_FIXNUM((V7)+(12));
	(*LK13)(1,(V5))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK14)(1,(V5))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	VALUES(0) = (V3);
	RETURN(1);
	}
}
/*	function definition for INSTALL-COLORMAP                      */
static L60(int narg, object V1)
{ VT62 VLEX62 CLSR62
TTL:
	{register object V2;                      /*  .DISPLAY.       */
	V2= ((V1))->in.in_slots[1];
	if((((V2))->in.in_slots[10])==Cnil){
	goto L2742;}
	(*LK0)(3,VV[16],VV[10],(V2))              /*  X-ERROR         */;
L2742:
	{ int V3;
	{register object V4;                      /*  %BUFFER         */
	V4= (V2);
	if(!(((fix(((V4))->in.in_slots[6]))+(160))>=(fix(((V4))->in.in_slots[2])))){
	goto L2746;}
	(*LK7)(1,(V4))                            /*  BUFFER-FLUSH    */;
L2746:
	{register int V5;                         /*  BUFFER-BOFFSET  */
	register object V6;                       /*  BUFFER-BBUF     */
	V5= fix(((V4))->in.in_slots[6]);
	V6= ((V4))->in.in_slots[7];
	((V2))->in.in_slots[4]= MAKE_FIXNUM(V5);
	(((V6))->ust.ust_self[(V5)+(0)]=(81));
	(*LK11)(1,(V1))                           /*  COLORMAP-P      */;
	if(VALUES(0)==Cnil){
	goto L2757;}
	((*(unsigned long *)(((V6))->ust.ust_self+((V5)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L2755;
L2757:
	(*LK4)(2,(V1),VV[37])                     /*  X-TYPE-ERROR    */;
L2755:
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(2))))=2);
	((V2))->in.in_slots[6]= MAKE_FIXNUM((V5)+(8));
	V3=(*LK13)(1,(V2))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V3);
	(*LK14)(1,(V2))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V3);
	RETURN(V3);}
	}
}
/*	function definition for UNINSTALL-COLORMAP                    */
static L61(int narg, object V1)
{ VT63 VLEX63 CLSR63
TTL:
	{register object V2;                      /*  .DISPLAY.       */
	V2= ((V1))->in.in_slots[1];
	if((((V2))->in.in_slots[10])==Cnil){
	goto L2763;}
	(*LK0)(3,VV[16],VV[10],(V2))              /*  X-ERROR         */;
L2763:
	{ int V3;
	{register object V4;                      /*  %BUFFER         */
	V4= (V2);
	if(!(((fix(((V4))->in.in_slots[6]))+(160))>=(fix(((V4))->in.in_slots[2])))){
	goto L2767;}
	(*LK7)(1,(V4))                            /*  BUFFER-FLUSH    */;
L2767:
	{register int V5;                         /*  BUFFER-BOFFSET  */
	register object V6;                       /*  BUFFER-BBUF     */
	V5= fix(((V4))->in.in_slots[6]);
	V6= ((V4))->in.in_slots[7];
	((V2))->in.in_slots[4]= MAKE_FIXNUM(V5);
	(((V6))->ust.ust_self[(V5)+(0)]=(82));
	(*LK11)(1,(V1))                           /*  COLORMAP-P      */;
	if(VALUES(0)==Cnil){
	goto L2778;}
	((*(unsigned long *)(((V6))->ust.ust_self+((V5)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L2776;
L2778:
	(*LK4)(2,(V1),VV[37])                     /*  X-TYPE-ERROR    */;
L2776:
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(2))))=2);
	((V2))->in.in_slots[6]= MAKE_FIXNUM((V5)+(8));
	V3=(*LK13)(1,(V2))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V3);
	(*LK14)(1,(V2))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V3);
	RETURN(V3);}
	}
}
/*	function definition for INSTALLED-COLORMAPS                   */
static L62(int narg, object V1, ...)
{ VT64 VLEX64 CLSR64
	{volatile object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[2];
	parse_key(narg,args,1,L62keys,keyvars,OBJNULL,FALSE);
	if(keyvars[1]==Cnil){
	V2= VV[42];
	}else{
	V2= keyvars[0];}
	}
	{volatile object V3;
	V3= ((V1))->in.in_slots[1];
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(V3,env0));            /*  DISPLAY         */
	{ object V4;
	V4= make_cclosure(LC63,env0,&Cblock);
	{volatile object V5;                      /*  .DISPLAY.       */
	volatile object V6;                       /*  .PENDING-COMMAND.*/
	volatile object V7;                       /*  .REPLY-BUFFER.  */
	V5= *CLV0;
	V6= Cnil;
	V7= Cnil;
	{ int V8; volatile bool unwinding = FALSE;
	if ((V8=frs_push(FRS_PROTECT,Cnil))) {
	V8--; unwinding = TRUE;} else {
	if((((V5))->in.in_slots[10])==Cnil){
	goto L2787;}
	(*LK0)(3,VV[16],VV[10],(V5))              /*  X-ERROR         */;
L2787:
	(*LK15)(1,(V5))                           /*  START-PENDING-COMMAND*/;
	V6= VALUES(0);
	{register object V9;                      /*  %BUFFER         */
	V9= (V5);
	if(!(((fix(((V9))->in.in_slots[6]))+(160))>=(fix(((V9))->in.in_slots[2])))){
	goto L2793;}
	(*LK7)(1,(V9))                            /*  BUFFER-FLUSH    */;
L2793:
	{register int V10;                        /*  BUFFER-BOFFSET  */
	register object V11;                      /*  BUFFER-BBUF     */
	V10= fix(((V9))->in.in_slots[6]);
	V11= ((V9))->in.in_slots[7];
	((V5))->in.in_slots[4]= MAKE_FIXNUM(V10);
	(((V11))->ust.ust_self[(V10)+(0)]=(83));
	(*LK9)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L2804;}
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L2802;
L2804:
	(*LK4)(2,(V1),VV[9])                      /*  X-TYPE-ERROR    */;
L2802:
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(2))))=2);
	((V5))->in.in_slots[6]= MAKE_FIXNUM((V10)+(8));
	(*LK13)(1,(V5))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V5))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V5))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V5),(V6))                      /*  READ-REPLY      */;
	V7= VALUES(0);
	{object V9;                               /*  %REPLY-BUFFER   */
	object V10;                               /*  %BUFFER         */
	{int V11;                                 /*  BUFFER-BOFFSET  */
	object V12;                               /*  BUFFER-BBUF     */
	V11= 0;
	V12= ((V7))->in.in_slots[1];
	V8=(*LK19)(7,(V7),(V2),MAKE_FIXNUM((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(8))))),(V4),Cnil,MAKE_FIXNUM(0),MAKE_FIXNUM(32))/*  READ-SEQUENCE-CARD32*/;
	}
	}
	}
	frs_pop();
	MV_SAVE(V8);
	if(((V7))==Cnil){
	goto L2818;}
	(*LK20)(1,(V7))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L2818:
	if(((V6))==Cnil){
	goto L2817;}
	(*LK21)(2,(V5),(V6))                      /*  STOP-PENDING-COMMAND*/;
L2817:
	MV_RESTORE(V8);
	if (unwinding) unwind(nlj_fr,nlj_tag,V8+1);
	else {
	RETURN(V8);}}
	}
	}
	}
	}
}
/*	closure GET-COLORMAP                                          */
static LC63(int narg, object env0, object V1)
{ VT65 VLEX65 CLSR65
	narg--;
	{object scan=env0;
	CLV0= &CAR(scan);                         /*  DISPLAY         */}
TTL:
	RETURN((*LK46)(2,*CLV0,(V1))              /*  LOOKUP-COLORMAP */);
}
/*	function definition for ALLOC-COLOR                           */
static L64(int narg, object V1, object V2)
{ VT66 VLEX66 CLSR66
TTL:
	{volatile object V3;                      /*  DISPLAY         */
	V3= ((V1))->in.in_slots[1];
	{volatile object V4;
	V4= (V2);
	(*LK8)(2,(V4),VV[120])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2825;}
	{volatile object V5;                      /*  .DISPLAY.       */
	volatile object V6;                       /*  .PENDING-COMMAND.*/
	volatile object V7;                       /*  .REPLY-BUFFER.  */
	V5= (V3);
	V6= Cnil;
	V7= Cnil;
	{ int V8; volatile bool unwinding = FALSE;
	if ((V8=frs_push(FRS_PROTECT,Cnil))) {
	V8--; unwinding = TRUE;} else {
	if((((V5))->in.in_slots[10])==Cnil){
	goto L2829;}
	(*LK0)(3,VV[16],VV[10],(V5))              /*  X-ERROR         */;
L2829:
	(*LK15)(1,(V5))                           /*  START-PENDING-COMMAND*/;
	V6= VALUES(0);
	{object V9;                               /*  %BUFFER         */
	V9= (V5);
	if(!(((fix(((V9))->in.in_slots[6]))+(160))>=(fix(((V9))->in.in_slots[2])))){
	goto L2835;}
	(*LK7)(1,(V9))                            /*  BUFFER-FLUSH    */;
L2835:
	{register int V10;                        /*  BUFFER-BOFFSET  */
	register object V11;                      /*  BUFFER-BBUF     */
	V10= fix(((V9))->in.in_slots[6]);
	V11= ((V9))->in.in_slots[7];
	((V5))->in.in_slots[4]= MAKE_FIXNUM(V10);
	(((V11))->ust.ust_self[(V10)+(0)]=(84));
	(*LK11)(1,(V1))                           /*  COLORMAP-P      */;
	if(VALUES(0)==Cnil){
	goto L2846;}
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L2844;
L2846:
	(*LK4)(2,(V1),VV[37])                     /*  X-TYPE-ERROR    */;
L2844:
	{object V12;                              /*  .VALUE.         */
	V12= ((V2))->in.in_slots[0];
	(*LK8)(2,(V12),VV[121])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2851;}
	(*LK47)(1,(V12))                          /*  RGB-VAL->CARD16 */;
	T0= VALUES(0);
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(8))))=fix(T0));
	goto L2848;
L2851:
	(*LK4)(2,(V12),VV[121])                   /*  X-TYPE-ERROR    */;
	}
L2848:
	{object V12;                              /*  .VALUE.         */
	V12= ((V2))->in.in_slots[1];
	(*LK8)(2,(V12),VV[121])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2857;}
	(*LK47)(1,(V12))                          /*  RGB-VAL->CARD16 */;
	T0= VALUES(0);
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(10))))=fix(T0));
	goto L2854;
L2857:
	(*LK4)(2,(V12),VV[121])                   /*  X-TYPE-ERROR    */;
	}
L2854:
	{object V12;                              /*  .VALUE.         */
	V12= ((V2))->in.in_slots[2];
	(*LK8)(2,(V12),VV[121])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2863;}
	(*LK47)(1,(V12))                          /*  RGB-VAL->CARD16 */;
	T0= VALUES(0);
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(12))))=fix(T0));
	goto L2860;
L2863:
	(*LK4)(2,(V12),VV[121])                   /*  X-TYPE-ERROR    */;
	}
L2860:
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(2))))=4);
	((V5))->in.in_slots[6]= MAKE_FIXNUM((V10)+(16));
	(*LK13)(1,(V5))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V5))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V5))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V5),(V6))                      /*  READ-REPLY      */;
	V7= VALUES(0);
	{object V9;                               /*  %REPLY-BUFFER   */
	object V10;                               /*  %BUFFER         */
	{register int V11;                        /*  BUFFER-BOFFSET  */
	object V12;                               /*  BUFFER-BBUF     */
	V11= 0;
	V12= ((V7))->in.in_slots[1];
	{int V13= (*(unsigned long *)(((V12))->ust.ust_self+((V11)+(16))));
	(*LK48)(1,MAKE_FIXNUM((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(8))))))/*  CARD16->RGB-VAL*/;
	T0= VALUES(0);
	(*LK48)(1,MAKE_FIXNUM((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(10))))))/*  CARD16->RGB-VAL*/;
	T1= VALUES(0);
	(*LK48)(1,MAKE_FIXNUM((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(12))))))/*  CARD16->RGB-VAL*/;
	(*LK49)(6,VV[122],T0,VV[123],T1,VV[124],VALUES(0))/*  MAKE-COLOR*/;
	VALUES(2) = (V2);
	VALUES(1) = VALUES(0);
	VALUES(0) = MAKE_FIXNUM(V13);
	V8=3;}
	}
	}
	}
	frs_pop();
	MV_SAVE(V8);
	if(((V7))==Cnil){
	goto L2883;}
	(*LK20)(1,(V7))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L2883:
	if(((V6))==Cnil){
	goto L2882;}
	(*LK21)(2,(V5),(V6))                      /*  STOP-PENDING-COMMAND*/;
L2882:
	MV_RESTORE(V8);
	if (unwinding) unwind(nlj_fr,nlj_tag,V8+1);
	else {
	RETURN(V8);}}
	}
L2825:
	(*LK8)(2,(V4),VV[125])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2889;}
	{volatile object V9;                      /*  STRING          */
	volatile int V10;                         /*  LENGTH          */
	V9= coerce_to_string((V2));
	V10= ((V9))->v.v_fillp;
	{volatile object V11;                     /*  .DISPLAY.       */
	volatile object V12;                      /*  .PENDING-COMMAND.*/
	volatile object V13;                      /*  .REPLY-BUFFER.  */
	V11= (V3);
	V12= Cnil;
	V13= Cnil;
	{ int V14; volatile bool unwinding = FALSE;
	if ((V14=frs_push(FRS_PROTECT,Cnil))) {
	V14--; unwinding = TRUE;} else {
	if((((V11))->in.in_slots[10])==Cnil){
	goto L2895;}
	(*LK0)(3,VV[16],VV[10],(V11))             /*  X-ERROR         */;
L2895:
	(*LK15)(1,(V11))                          /*  START-PENDING-COMMAND*/;
	V12= VALUES(0);
	{object V15;                              /*  %BUFFER         */
	V15= (V11);
	if(!(((fix(((V15))->in.in_slots[6]))+(160))>=(fix(((V15))->in.in_slots[2])))){
	goto L2901;}
	(*LK7)(1,(V15))                           /*  BUFFER-FLUSH    */;
L2901:
	{register int V16;                        /*  BUFFER-BOFFSET  */
	object V17;                               /*  BUFFER-BBUF     */
	V16= fix(((V15))->in.in_slots[6]);
	V17= ((V15))->in.in_slots[7];
	((V11))->in.in_slots[4]= MAKE_FIXNUM(V16);
	(((V17))->ust.ust_self[(V16)+(0)]=(85));
	(*LK11)(1,(V1))                           /*  COLORMAP-P      */;
	if(VALUES(0)==Cnil){
	goto L2912;}
	((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L2910;
L2912:
	(*LK4)(2,(V1),VV[37])                     /*  X-TYPE-ERROR    */;
L2910:
	(*LK8)(2,MAKE_FIXNUM(V10),VV[21])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2916;}
	((*(unsigned short *)(((V17))->ust.ust_self+((V16)+(8))))=V10);
	goto L2914;
L2916:
	(*LK4)(2,MAKE_FIXNUM(V10),VV[21])         /*  X-TYPE-ERROR    */;
L2914:
	(*LK8)(2,(V9),VV[44])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2921;}
	{int V18;
	V18= ((V9))->v.v_fillp;
	Lceiling(2,MAKE_FIXNUM(((V18)-(0))+(12)),MAKE_FIXNUM(4))/*  CEILING*/;
	T0= VALUES(0);
	((*(unsigned short *)(((V17))->ust.ust_self+((V16)+(2))))=fix(T0));
	(*LK24)(5,(V15),MAKE_FIXNUM((V16)+(12)),(V9),MAKE_FIXNUM(0),MAKE_FIXNUM(V18))/*  WRITE-SEQUENCE-CHAR*/;
	goto L2919;
	}
L2921:
	(*LK4)(2,(V9),VV[44])                     /*  X-TYPE-ERROR    */;
L2919:
	(*LK13)(1,(V11))                          /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V11))                          /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V11))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V11),(V12))                    /*  READ-REPLY      */;
	V13= VALUES(0);
	{object V15;                              /*  %REPLY-BUFFER   */
	object V16;                               /*  %BUFFER         */
	{register int V17;                        /*  BUFFER-BOFFSET  */
	register object V18;                      /*  BUFFER-BBUF     */
	V17= 0;
	V18= ((V13))->in.in_slots[1];
	{int V19= (*(unsigned long *)(((V18))->ust.ust_self+((V17)+(8))));
	(*LK48)(1,MAKE_FIXNUM((*(unsigned short *)(((V18))->ust.ust_self+((V17)+(18))))))/*  CARD16->RGB-VAL*/;
	T0= VALUES(0);
	(*LK48)(1,MAKE_FIXNUM((*(unsigned short *)(((V18))->ust.ust_self+((V17)+(20))))))/*  CARD16->RGB-VAL*/;
	T1= VALUES(0);
	(*LK48)(1,MAKE_FIXNUM((*(unsigned short *)(((V18))->ust.ust_self+((V17)+(22))))))/*  CARD16->RGB-VAL*/;
	(*LK49)(6,VV[122],T0,VV[123],T1,VV[124],VALUES(0))/*  MAKE-COLOR*/;
	T2= VALUES(0);
	(*LK48)(1,MAKE_FIXNUM((*(unsigned short *)(((V18))->ust.ust_self+((V17)+(12))))))/*  CARD16->RGB-VAL*/;
	T3= VALUES(0);
	(*LK48)(1,MAKE_FIXNUM((*(unsigned short *)(((V18))->ust.ust_self+((V17)+(14))))))/*  CARD16->RGB-VAL*/;
	T4= VALUES(0);
	(*LK48)(1,MAKE_FIXNUM((*(unsigned short *)(((V18))->ust.ust_self+((V17)+(16))))))/*  CARD16->RGB-VAL*/;
	(*LK49)(6,VV[122],T3,VV[123],T4,VV[124],VALUES(0))/*  MAKE-COLOR*/;
	VALUES(2) = VALUES(0);
	VALUES(1) = T2;
	VALUES(0) = MAKE_FIXNUM(V19);
	V14=3;}
	}
	}
	}
	frs_pop();
	MV_SAVE(V14);
	if(((V13))==Cnil){
	goto L2944;}
	(*LK20)(1,(V13))                          /*  DEALLOCATE-REPLY-BUFFER*/;
L2944:
	if(((V12))==Cnil){
	goto L2943;}
	(*LK21)(2,(V11),(V12))                    /*  STOP-PENDING-COMMAND*/;
L2943:
	MV_RESTORE(V14);
	if (unwinding) unwind(nlj_fr,nlj_tag,V14+1);
	else {
	RETURN(V14);}}
	}
	}
L2889:
	(*LK50)(3,VV[120],(V4),VV[126])           /*  TYPECASE-ERROR-STRING*/;
	RETURN(Lerror(1,VALUES(0))                /*  ERROR           */);
	}
	}
}
/*	function definition for ALLOC-COLOR-CELLS                     */
static L65(int narg, object V1, object V2, ...)
{ VT67 VLEX67 CLSR67
	{volatile int V3;
	volatile int V4;
	volatile object V5;
	volatile object V6;
	va_list args; va_start(args, V2);
	V3= fix(V2);
	narg -=2;
	{ object keyvars[6];
	parse_key(narg,args,3,L65keys,keyvars,OBJNULL,FALSE);
	if(keyvars[3]==Cnil){
	V4= 0;
	}else{
	V4= fix(keyvars[0]);}
	V5= keyvars[1];
	if(keyvars[5]==Cnil){
	V6= VV[42];
	}else{
	V6= keyvars[2];}
	}
	{volatile object V7;                      /*  DISPLAY         */
	V7= ((V1))->in.in_slots[1];
	{volatile object V8;                      /*  .DISPLAY.       */
	volatile object V9;                       /*  .PENDING-COMMAND.*/
	volatile object V10;                      /*  .REPLY-BUFFER.  */
	V8= (V7);
	V9= Cnil;
	V10= Cnil;
	{ int V11; volatile bool unwinding = FALSE;
	if ((V11=frs_push(FRS_PROTECT,Cnil))) {
	V11--; unwinding = TRUE;} else {
	if((((V8))->in.in_slots[10])==Cnil){
	goto L2955;}
	(*LK0)(3,VV[16],VV[10],(V8))              /*  X-ERROR         */;
L2955:
	(*LK15)(1,(V8))                           /*  START-PENDING-COMMAND*/;
	V9= VALUES(0);
	{register object V12;                     /*  %BUFFER         */
	V12= (V8);
	if(!(((fix(((V12))->in.in_slots[6]))+(160))>=(fix(((V12))->in.in_slots[2])))){
	goto L2961;}
	(*LK7)(1,(V12))                           /*  BUFFER-FLUSH    */;
L2961:
	{register int V13;                        /*  BUFFER-BOFFSET  */
	register object V14;                      /*  BUFFER-BBUF     */
	V13= fix(((V12))->in.in_slots[6]);
	V14= ((V12))->in.in_slots[7];
	((V8))->in.in_slots[4]= MAKE_FIXNUM(V13);
	(((V14))->ust.ust_self[(V13)+(0)]=(86));
	if(((V5))==Cnil){
	goto L2975;}
	T0= MAKE_FIXNUM(1);
	goto L2973;
L2975:
	T0= MAKE_FIXNUM(0);
L2973:
	VALUES(0) = MAKE_FIXNUM((((V14))->ust.ust_self[(V13)+(1)]=(fix(T0))));
	if(VALUES(0)==Cnil)goto L2971;
	goto L2970;
L2971:
	(*LK4)(2,(V5),VV[127])                    /*  X-TYPE-ERROR    */;
L2970:
	(*LK11)(1,(V1))                           /*  COLORMAP-P      */;
	if(VALUES(0)==Cnil){
	goto L2979;}
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L2977;
L2979:
	(*LK4)(2,(V1),VV[37])                     /*  X-TYPE-ERROR    */;
L2977:
	(*LK8)(2,MAKE_FIXNUM(V3),VV[21])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2983;}
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(8))))=V3);
	goto L2981;
L2983:
	(*LK4)(2,MAKE_FIXNUM(V3),VV[21])          /*  X-TYPE-ERROR    */;
L2981:
	(*LK8)(2,MAKE_FIXNUM(V4),VV[21])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2987;}
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(10))))=V4);
	goto L2985;
L2987:
	(*LK4)(2,MAKE_FIXNUM(V4),VV[21])          /*  X-TYPE-ERROR    */;
L2985:
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(2))))=3);
	((V8))->in.in_slots[6]= MAKE_FIXNUM((V13)+(12));
	(*LK13)(1,(V8))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V8))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V8))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V8),(V9))                      /*  READ-REPLY      */;
	V10= VALUES(0);
	{object V12;                              /*  %REPLY-BUFFER   */
	object V13;                               /*  %BUFFER         */
	V12= (V10);
	{register int V14;                        /*  BUFFER-BOFFSET  */
	object V15;                               /*  BUFFER-BBUF     */
	V14= 0;
	V15= ((V12))->in.in_slots[1];
	{int V16;                                 /*  PIXEL-LENGTH    */
	int V17;                                  /*  MASK-LENGTH     */
	V16= (*(unsigned short *)(((V15))->ust.ust_self+((V14)+(8))));
	V17= (*(unsigned short *)(((V15))->ust.ust_self+((V14)+(10))));
	(*LK19)(7,(V12),(V6),MAKE_FIXNUM(V16),Cnil,Cnil,MAKE_FIXNUM(0),MAKE_FIXNUM(32))/*  READ-SEQUENCE-CARD32*/;
	T0= VALUES(0);
	(*LK19)(7,(V12),(V6),MAKE_FIXNUM(V17),Cnil,Cnil,MAKE_FIXNUM(0),MAKE_FIXNUM((32)+((V16)*(4))))/*  READ-SEQUENCE-CARD32*/;
	VALUES(1) = VALUES(0);
	VALUES(0) = T0;
	V11=2;
	}
	}
	}
	}
	frs_pop();
	MV_SAVE(V11);
	if(((V10))==Cnil){
	goto L3005;}
	(*LK20)(1,(V10))                          /*  DEALLOCATE-REPLY-BUFFER*/;
L3005:
	if(((V9))==Cnil){
	goto L3004;}
	(*LK21)(2,(V8),(V9))                      /*  STOP-PENDING-COMMAND*/;
L3004:
	MV_RESTORE(V11);
	if (unwinding) unwind(nlj_fr,nlj_tag,V11+1);
	else {
	RETURN(V11);}}
	}
	}
	}
}
/*	function definition for ALLOC-COLOR-PLANES                    */
static L66(int narg, object V1, object V2, ...)
{ VT68 VLEX68 CLSR68
	{volatile int V3;
	volatile int V4;
	volatile int V5;
	volatile int V6;
	volatile object V7;
	volatile object V8;
	va_list args; va_start(args, V2);
	V3= fix(V2);
	narg -=2;
	{ object keyvars[10];
	parse_key(narg,args,5,L66keys,keyvars,OBJNULL,FALSE);
	if(keyvars[5]==Cnil){
	V4= 0;
	}else{
	V4= fix(keyvars[0]);}
	if(keyvars[6]==Cnil){
	V5= 0;
	}else{
	V5= fix(keyvars[1]);}
	if(keyvars[7]==Cnil){
	V6= 0;
	}else{
	V6= fix(keyvars[2]);}
	V7= keyvars[3];
	if(keyvars[9]==Cnil){
	V8= VV[42];
	}else{
	V8= keyvars[4];}
	}
	{volatile object V9;                      /*  DISPLAY         */
	V9= ((V1))->in.in_slots[1];
	{volatile object V10;                     /*  .DISPLAY.       */
	volatile object V11;                      /*  .PENDING-COMMAND.*/
	volatile object V12;                      /*  .REPLY-BUFFER.  */
	V10= (V9);
	V11= Cnil;
	V12= Cnil;
	{ int V13; volatile bool unwinding = FALSE;
	if ((V13=frs_push(FRS_PROTECT,Cnil))) {
	V13--; unwinding = TRUE;} else {
	if((((V10))->in.in_slots[10])==Cnil){
	goto L3017;}
	(*LK0)(3,VV[16],VV[10],(V10))             /*  X-ERROR         */;
L3017:
	(*LK15)(1,(V10))                          /*  START-PENDING-COMMAND*/;
	V11= VALUES(0);
	{register object V14;                     /*  %BUFFER         */
	V14= (V10);
	if(!(((fix(((V14))->in.in_slots[6]))+(160))>=(fix(((V14))->in.in_slots[2])))){
	goto L3023;}
	(*LK7)(1,(V14))                           /*  BUFFER-FLUSH    */;
L3023:
	{register int V15;                        /*  BUFFER-BOFFSET  */
	register object V16;                      /*  BUFFER-BBUF     */
	V15= fix(((V14))->in.in_slots[6]);
	V16= ((V14))->in.in_slots[7];
	((V10))->in.in_slots[4]= MAKE_FIXNUM(V15);
	(((V16))->ust.ust_self[(V15)+(0)]=(87));
	if(((V7))==Cnil){
	goto L3037;}
	T0= MAKE_FIXNUM(1);
	goto L3035;
L3037:
	T0= MAKE_FIXNUM(0);
L3035:
	VALUES(0) = MAKE_FIXNUM((((V16))->ust.ust_self[(V15)+(1)]=(fix(T0))));
	if(VALUES(0)==Cnil)goto L3033;
	goto L3032;
L3033:
	(*LK4)(2,(V7),VV[128])                    /*  X-TYPE-ERROR    */;
L3032:
	(*LK11)(1,(V1))                           /*  COLORMAP-P      */;
	if(VALUES(0)==Cnil){
	goto L3041;}
	((*(unsigned long *)(((V16))->ust.ust_self+((V15)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L3039;
L3041:
	(*LK4)(2,(V1),VV[37])                     /*  X-TYPE-ERROR    */;
L3039:
	(*LK8)(2,MAKE_FIXNUM(V3),VV[21])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3045;}
	((*(unsigned short *)(((V16))->ust.ust_self+((V15)+(8))))=V3);
	goto L3043;
L3045:
	(*LK4)(2,MAKE_FIXNUM(V3),VV[21])          /*  X-TYPE-ERROR    */;
L3043:
	(*LK8)(2,MAKE_FIXNUM(V4),VV[21])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3049;}
	((*(unsigned short *)(((V16))->ust.ust_self+((V15)+(10))))=V4);
	goto L3047;
L3049:
	(*LK4)(2,MAKE_FIXNUM(V4),VV[21])          /*  X-TYPE-ERROR    */;
L3047:
	(*LK8)(2,MAKE_FIXNUM(V5),VV[21])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3053;}
	((*(unsigned short *)(((V16))->ust.ust_self+((V15)+(12))))=V5);
	goto L3051;
L3053:
	(*LK4)(2,MAKE_FIXNUM(V5),VV[21])          /*  X-TYPE-ERROR    */;
L3051:
	(*LK8)(2,MAKE_FIXNUM(V6),VV[21])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3057;}
	((*(unsigned short *)(((V16))->ust.ust_self+((V15)+(14))))=V6);
	goto L3055;
L3057:
	(*LK4)(2,MAKE_FIXNUM(V6),VV[21])          /*  X-TYPE-ERROR    */;
L3055:
	((*(unsigned short *)(((V16))->ust.ust_self+((V15)+(2))))=4);
	((V10))->in.in_slots[6]= MAKE_FIXNUM((V15)+(16));
	(*LK13)(1,(V10))                          /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V10))                          /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V10))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V10),(V11))                    /*  READ-REPLY      */;
	V12= VALUES(0);
	{object V14;                              /*  %REPLY-BUFFER   */
	object V15;                               /*  %BUFFER         */
	{register int V16;                        /*  BUFFER-BOFFSET  */
	register object V17;                      /*  BUFFER-BBUF     */
	V16= 0;
	V17= ((V12))->in.in_slots[1];
	{int V18;                                 /*  RED-MASK        */
	int V19;                                  /*  GREEN-MASK      */
	int V20;                                  /*  BLUE-MASK       */
	V18= (*(unsigned long *)(((V17))->ust.ust_self+((V16)+(12))));
	V19= (*(unsigned long *)(((V17))->ust.ust_self+((V16)+(16))));
	V20= (*(unsigned long *)(((V17))->ust.ust_self+((V16)+(20))));
	(*LK19)(7,(V12),(V8),MAKE_FIXNUM((*(unsigned short *)(((V17))->ust.ust_self+((V16)+(8))))),Cnil,Cnil,MAKE_FIXNUM(0),MAKE_FIXNUM(32))/*  READ-SEQUENCE-CARD32*/;
	VALUES(3) = MAKE_FIXNUM(V20);
	VALUES(2) = MAKE_FIXNUM(V19);
	VALUES(1) = MAKE_FIXNUM(V18);
	VALUES(0) = VALUES(0);
	V13=4;
	}
	}
	}
	}
	frs_pop();
	MV_SAVE(V13);
	if(((V12))==Cnil){
	goto L3075;}
	(*LK20)(1,(V12))                          /*  DEALLOCATE-REPLY-BUFFER*/;
L3075:
	if(((V11))==Cnil){
	goto L3074;}
	(*LK21)(2,(V10),(V11))                    /*  STOP-PENDING-COMMAND*/;
L3074:
	MV_RESTORE(V13);
	if (unwinding) unwind(nlj_fr,nlj_tag,V13+1);
	else {
	RETURN(V13);}}
	}
	}
	}
}
/*	function definition for FREE-COLORS                           */
static L67(int narg, object V1, object V2, ...)
{ VT69 VLEX69 CLSR69
	{int i=2;
	object V3;
	va_list args; va_start(args, V2);
	if (i==narg) goto L3080;
	V3= va_arg(args, object);
	i++;
	goto L3081;
L3080:
	V3= MAKE_FIXNUM(0);
L3081:
	{register object V4;                      /*  .DISPLAY.       */
	V4= ((V1))->in.in_slots[1];
	if((((V4))->in.in_slots[10])==Cnil){
	goto L3084;}
	(*LK0)(3,VV[16],VV[10],(V4))              /*  X-ERROR         */;
L3084:
	{ int V5;
	{register object V6;                      /*  %BUFFER         */
	V6= (V4);
	if(!(((fix(((V6))->in.in_slots[6]))+(160))>=(fix(((V6))->in.in_slots[2])))){
	goto L3088;}
	(*LK7)(1,(V6))                            /*  BUFFER-FLUSH    */;
L3088:
	{register int V7;                         /*  BUFFER-BOFFSET  */
	register object V8;                       /*  BUFFER-BBUF     */
	V7= fix(((V6))->in.in_slots[6]);
	V8= ((V6))->in.in_slots[7];
	((V4))->in.in_slots[4]= MAKE_FIXNUM(V7);
	(((V8))->ust.ust_self[(V7)+(0)]=(88));
	(*LK11)(1,(V1))                           /*  COLORMAP-P      */;
	if(VALUES(0)==Cnil){
	goto L3099;}
	((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L3097;
L3099:
	(*LK4)(2,(V1),VV[37])                     /*  X-TYPE-ERROR    */;
L3097:
	(*LK8)(2,(V3),VV[26])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3103;}
	((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(8))))=fix((V3)));
	goto L3101;
L3103:
	(*LK4)(2,(V3),VV[26])                     /*  X-TYPE-ERROR    */;
L3101:
	(*LK8)(2,(V2),VV[55])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3107;}
	{int V9;
	V9= length((V2));
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(2))))=((V9)-(0))+(3));
	(*LK30)(6,(V6),MAKE_FIXNUM((V7)+(12)),(V2),MAKE_FIXNUM(0),MAKE_FIXNUM(V9),Cnil)/*  WRITE-SEQUENCE-CARD32*/;
	goto L3105;
	}
L3107:
	(*LK4)(2,(V2),VV[55])                     /*  X-TYPE-ERROR    */;
L3105:
	V5=(*LK13)(1,(V4))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V5);
	(*LK14)(1,(V4))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V5);
	RETURN(V5);}
	}
	}
}
/*	function definition for STORE-COLOR                           */
static L68(int narg, object V1, object V2, object V3, ...)
{ VT70 VLEX70 CLSR70
	{object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V3);
	narg -=3;
	{ object keyvars[6];
	parse_key(narg,args,3,L68keys,keyvars,OBJNULL,FALSE);
	if(keyvars[3]==Cnil){
	V4= Ct;
	}else{
	V4= keyvars[0];}
	if(keyvars[4]==Cnil){
	V5= Ct;
	}else{
	V5= keyvars[1];}
	if(keyvars[5]==Cnil){
	V6= Ct;
	}else{
	V6= keyvars[2];}
	}
	{object V7;                               /*  DISPLAY         */
	register int V8;                          /*  FLAGS           */
	V7= ((V1))->in.in_slots[1];
	V8= 0;
	if(((V4))==Cnil){
	goto L3117;}
	V8= 1;
L3117:
	if(((V5))==Cnil){
	goto L3121;}
	V8= (V8)+(2);
L3121:
	if(((V6))==Cnil){
	goto L3125;}
	V8= (V8)+(4);
L3125:
	{object V9;
	V9= (V3);
	(*LK8)(2,(V9),VV[120])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3130;}
	{register object V10;                     /*  .DISPLAY.       */
	V10= (V7);
	if((((V10))->in.in_slots[10])==Cnil){
	goto L3132;}
	(*LK0)(3,VV[16],VV[10],(V10))             /*  X-ERROR         */;
L3132:
	{ int V11;
	{object V12;                              /*  %BUFFER         */
	V12= (V10);
	if(!(((fix(((V12))->in.in_slots[6]))+(160))>=(fix(((V12))->in.in_slots[2])))){
	goto L3136;}
	(*LK7)(1,(V12))                           /*  BUFFER-FLUSH    */;
L3136:
	{register int V13;                        /*  BUFFER-BOFFSET  */
	register object V14;                      /*  BUFFER-BBUF     */
	V13= fix(((V12))->in.in_slots[6]);
	V14= ((V12))->in.in_slots[7];
	((V10))->in.in_slots[4]= MAKE_FIXNUM(V13);
	(((V14))->ust.ust_self[(V13)+(0)]=(89));
	(*LK11)(1,(V1))                           /*  COLORMAP-P      */;
	if(VALUES(0)==Cnil){
	goto L3147;}
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L3145;
L3147:
	(*LK4)(2,(V1),VV[37])                     /*  X-TYPE-ERROR    */;
L3145:
	(*LK8)(2,(V2),VV[26])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3151;}
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(8))))=fix((V2)));
	goto L3149;
L3151:
	(*LK4)(2,(V2),VV[26])                     /*  X-TYPE-ERROR    */;
L3149:
	{object V15;                              /*  .VALUE.         */
	V15= ((V3))->in.in_slots[0];
	(*LK8)(2,(V15),VV[121])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3156;}
	(*LK47)(1,(V15))                          /*  RGB-VAL->CARD16 */;
	T0= VALUES(0);
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(12))))=fix(T0));
	goto L3153;
L3156:
	(*LK4)(2,(V15),VV[121])                   /*  X-TYPE-ERROR    */;
	}
L3153:
	{object V15;                              /*  .VALUE.         */
	V15= ((V3))->in.in_slots[1];
	(*LK8)(2,(V15),VV[121])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3162;}
	(*LK47)(1,(V15))                          /*  RGB-VAL->CARD16 */;
	T0= VALUES(0);
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(14))))=fix(T0));
	goto L3159;
L3162:
	(*LK4)(2,(V15),VV[121])                   /*  X-TYPE-ERROR    */;
	}
L3159:
	{object V15;                              /*  .VALUE.         */
	V15= ((V3))->in.in_slots[2];
	(*LK8)(2,(V15),VV[121])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3168;}
	(*LK47)(1,(V15))                          /*  RGB-VAL->CARD16 */;
	T0= VALUES(0);
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(16))))=fix(T0));
	goto L3165;
L3168:
	(*LK4)(2,(V15),VV[121])                   /*  X-TYPE-ERROR    */;
	}
L3165:
	(*LK8)(2,MAKE_FIXNUM(V8),VV[17])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3173;}
	(((V14))->ust.ust_self[(V13)+(18)]=(V8));
	goto L3171;
L3173:
	(*LK4)(2,MAKE_FIXNUM(V8),VV[17])          /*  X-TYPE-ERROR    */;
L3171:
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(2))))=5);
	((V10))->in.in_slots[6]= MAKE_FIXNUM((V13)+(20));
	V11=(*LK13)(1,(V10))                      /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V11);
	(*LK14)(1,(V10))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V11);
	RETURN(V11);}
	}
L3130:
	(*LK8)(2,(V9),VV[125])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3180;}
	{object V12;                              /*  STRING          */
	register int V13;                         /*  LENGTH          */
	V12= coerce_to_string((V3));
	V13= ((V12))->v.v_fillp;
	{register object V14;                     /*  .DISPLAY.       */
	V14= (V7);
	if((((V14))->in.in_slots[10])==Cnil){
	goto L3184;}
	(*LK0)(3,VV[16],VV[10],(V14))             /*  X-ERROR         */;
L3184:
	{ int V15;
	{register object V16;                     /*  %BUFFER         */
	V16= (V14);
	if(!(((fix(((V16))->in.in_slots[6]))+(160))>=(fix(((V16))->in.in_slots[2])))){
	goto L3188;}
	(*LK7)(1,(V16))                           /*  BUFFER-FLUSH    */;
L3188:
	{register int V17;                        /*  BUFFER-BOFFSET  */
	register object V18;                      /*  BUFFER-BBUF     */
	V17= fix(((V16))->in.in_slots[6]);
	V18= ((V16))->in.in_slots[7];
	((V14))->in.in_slots[4]= MAKE_FIXNUM(V17);
	(((V18))->ust.ust_self[(V17)+(0)]=(90));
	(*LK8)(2,MAKE_FIXNUM(V8),VV[17])          /*  TYPEP           */;
	if(VALUES(0)!=Cnil){
	goto L3200;}
	VALUES(0) = Cnil;
	goto L3199;
L3200:
	VALUES(0) = MAKE_FIXNUM((((V18))->ust.ust_self[(V17)+(1)]=(V8)));
L3199:
	if(VALUES(0)==Cnil)goto L3198;
	goto L3197;
L3198:
	(*LK4)(2,MAKE_FIXNUM(V8),VV[129])         /*  X-TYPE-ERROR    */;
L3197:
	(*LK11)(1,(V1))                           /*  COLORMAP-P      */;
	if(VALUES(0)==Cnil){
	goto L3204;}
	((*(unsigned long *)(((V18))->ust.ust_self+((V17)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L3202;
L3204:
	(*LK4)(2,(V1),VV[37])                     /*  X-TYPE-ERROR    */;
L3202:
	(*LK8)(2,(V2),VV[26])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3208;}
	((*(unsigned long *)(((V18))->ust.ust_self+((V17)+(8))))=fix((V2)));
	goto L3206;
L3208:
	(*LK4)(2,(V2),VV[26])                     /*  X-TYPE-ERROR    */;
L3206:
	(*LK8)(2,MAKE_FIXNUM(V13),VV[21])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3212;}
	((*(unsigned short *)(((V18))->ust.ust_self+((V17)+(12))))=V13);
	goto L3210;
L3212:
	(*LK4)(2,MAKE_FIXNUM(V13),VV[21])         /*  X-TYPE-ERROR    */;
L3210:
	(*LK8)(2,(V12),VV[44])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3217;}
	{int V19;
	V19= ((V12))->v.v_fillp;
	Lceiling(2,MAKE_FIXNUM(((V19)-(0))+(16)),MAKE_FIXNUM(4))/*  CEILING*/;
	T0= VALUES(0);
	((*(unsigned short *)(((V18))->ust.ust_self+((V17)+(2))))=fix(T0));
	(*LK24)(5,(V16),MAKE_FIXNUM((V17)+(16)),(V12),MAKE_FIXNUM(0),MAKE_FIXNUM(V19))/*  WRITE-SEQUENCE-CHAR*/;
	goto L3215;
	}
L3217:
	(*LK4)(2,(V12),VV[44])                    /*  X-TYPE-ERROR    */;
L3215:
	V15=(*LK13)(1,(V14))                      /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V15);
	(*LK14)(1,(V14))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V15);
	RETURN(V15);}
	}
	}
L3180:
	(*LK50)(3,VV[130],(V9),VV[131])           /*  TYPECASE-ERROR-STRING*/;
	RETURN(Lerror(1,VALUES(0))                /*  ERROR           */);
	}
	}
	}
}
/*	function definition for STORE-COLORS                          */
static L69(int narg, object V1, object V2, ...)
{ VT71 VLEX71 CLSR71
	{volatile object V3;
	volatile object V4;
	volatile object V5;
	va_list args; va_start(args, V2);
	narg -=2;
	{ object keyvars[6];
	parse_key(narg,args,3,L69keys,keyvars,OBJNULL,FALSE);
	if(keyvars[3]==Cnil){
	V3= Ct;
	}else{
	V3= keyvars[0];}
	if(keyvars[4]==Cnil){
	V4= Ct;
	}else{
	V4= keyvars[1];}
	if(keyvars[5]==Cnil){
	V5= Ct;
	}else{
	V5= keyvars[2];}
	}
	{volatile object V6;
	V6= (V2);
	(*LK8)(2,(V6),VV[42])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3228;}
	{volatile object V7;                      /*  SPEC            */
	V7= (V2);
L3231:
	if(!((V7)==Cnil)){
	goto L3232;}
	VALUES(0) = Cnil;
	RETURN(1);
L3232:
	L68(9,(V1),CAR((V7)),CADR((V7)),VV[132],(V3),VV[133],(V4),VV[134],(V5))/*  STORE-COLOR*/;
	V7= CDDR((V7));
	goto L3231;
	}
L3228:
	(*LK8)(2,(V6),VV[135])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3240;}
	{volatile object V9;                      /*  I               */
	volatile int V10;                         /*  LEN             */
	V10= length((V2));
	V9= MAKE_FIXNUM(0);
L3244:
	if(!(number_compare((V9),MAKE_FIXNUM(V10))>=0)){
	goto L3245;}
	VALUES(0) = Cnil;
	RETURN(1);
L3245:
	{object V12= aref1((V2),fix((V9)));
	L68(9,(V1),(V12),aref1((V2),fix(one_plus((V9)))),VV[132],(V3),VV[133],(V4),VV[134],(V5))/*  STORE-COLOR*/;}
	V9= number_plus((V9),MAKE_FIXNUM(2));
	goto L3244;
	}
L3240:
	(*LK50)(3,VV[136],(V6),VV[137])           /*  TYPECASE-ERROR-STRING*/;
	RETURN(Lerror(1,VALUES(0))                /*  ERROR           */);
	}
	}
}
/*	function definition for QUERY-COLORS                          */
static L70(int narg, object V1, object V2, ...)
{ VT72 VLEX72 CLSR72
	{volatile object V3;
	va_list args; va_start(args, V2);
	narg -=2;
	{ object keyvars[2];
	parse_key(narg,args,1,L70keys,keyvars,OBJNULL,FALSE);
	if(keyvars[1]==Cnil){
	V3= VV[42];
	}else{
	V3= keyvars[0];}
	}
	{volatile object V4;                      /*  DISPLAY         */
	V4= ((V1))->in.in_slots[1];
	{volatile object V5;                      /*  .DISPLAY.       */
	volatile object V6;                       /*  .PENDING-COMMAND.*/
	volatile object V7;                       /*  .REPLY-BUFFER.  */
	V5= (V4);
	V6= Cnil;
	V7= Cnil;
	{ int V8; volatile bool unwinding = FALSE;
	if ((V8=frs_push(FRS_PROTECT,Cnil))) {
	V8--; unwinding = TRUE;} else {
	if((((V5))->in.in_slots[10])==Cnil){
	goto L3257;}
	(*LK0)(3,VV[16],VV[10],(V5))              /*  X-ERROR         */;
L3257:
	(*LK15)(1,(V5))                           /*  START-PENDING-COMMAND*/;
	V6= VALUES(0);
	{register object V9;                      /*  %BUFFER         */
	V9= (V5);
	if(!(((fix(((V9))->in.in_slots[6]))+(160))>=(fix(((V9))->in.in_slots[2])))){
	goto L3263;}
	(*LK7)(1,(V9))                            /*  BUFFER-FLUSH    */;
L3263:
	{register int V10;                        /*  BUFFER-BOFFSET  */
	register object V11;                      /*  BUFFER-BBUF     */
	V10= fix(((V9))->in.in_slots[6]);
	V11= ((V9))->in.in_slots[7];
	((V5))->in.in_slots[4]= MAKE_FIXNUM(V10);
	(((V11))->ust.ust_self[(V10)+(0)]=(91));
	(*LK11)(1,(V1))                           /*  COLORMAP-P      */;
	if(VALUES(0)==Cnil){
	goto L3274;}
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L3272;
L3274:
	(*LK4)(2,(V1),VV[37])                     /*  X-TYPE-ERROR    */;
L3272:
	(*LK8)(2,(V2),VV[55])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3278;}
	{int V12;
	V12= length((V2));
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(2))))=((V12)-(0))+(2));
	(*LK30)(6,(V9),MAKE_FIXNUM((V10)+(8)),(V2),MAKE_FIXNUM(0),MAKE_FIXNUM(V12),Cnil)/*  WRITE-SEQUENCE-CARD32*/;
	goto L3276;
	}
L3278:
	(*LK4)(2,(V2),VV[55])                     /*  X-TYPE-ERROR    */;
L3276:
	(*LK13)(1,(V5))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V5))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V5))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V5),(V6))                      /*  READ-REPLY      */;
	V7= VALUES(0);
	{volatile object V9;                      /*  %REPLY-BUFFER   */
	volatile object V10;                      /*  %BUFFER         */
	{volatile int V11;                        /*  BUFFER-BOFFSET  */
	volatile object V12;                      /*  BUFFER-BBUF     */
	V11= 0;
	V12= ((V7))->in.in_slots[1];
	{volatile object V13;                     /*  SEQUENCE        */
	(*LK51)(2,(V3),MAKE_FIXNUM((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(8))))))/*  MAKE-SEQUENCE*/;
	V13= VALUES(0);
	{int V14;                                 /*  .BOFFSET.       */
	V14= (V11)+(32);
	V11= V14;
	}
	{volatile int V14;
	volatile int V15;                         /*  I               */
	V14= length((V13));
	V15= 0;
L3298:
	if(!((V15)>=(V14))){
	goto L3299;}
	VALUES(0)=(V13);
	V8=1;
	goto L3255;
L3299:
	(*LK48)(1,MAKE_FIXNUM((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(0))))))/*  CARD16->RGB-VAL*/;
	T0= VALUES(0);
	(*LK48)(1,MAKE_FIXNUM((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(2))))))/*  CARD16->RGB-VAL*/;
	T1= VALUES(0);
	(*LK48)(1,MAKE_FIXNUM((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(4))))))/*  CARD16->RGB-VAL*/;
	(*LK49)(6,VV[122],T0,VV[123],T1,VV[124],VALUES(0))/*  MAKE-COLOR*/;
	elt_set((V13),V15,VALUES(0));
	{register int V17;                        /*  .BOFFSET.       */
	V17= (V11)+(8);
	V11= V17;
	}
	V15= (V15)+1;
	goto L3298;
	}
	}
	}
	}
L3255:
	}
	frs_pop();
	MV_SAVE(V8);
	if(((V7))==Cnil){
	goto L3314;}
	(*LK20)(1,(V7))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L3314:
	if(((V6))==Cnil){
	goto L3313;}
	(*LK21)(2,(V5),(V6))                      /*  STOP-PENDING-COMMAND*/;
L3313:
	MV_RESTORE(V8);
	if (unwinding) unwind(nlj_fr,nlj_tag,V8+1);
	else {
	RETURN(V8);}}
	}
	}
	}
}
/*	function definition for LOOKUP-COLOR                          */
static L71(int narg, object V1, object V2)
{ VT73 VLEX73 CLSR73
TTL:
	{volatile object V3;                      /*  DISPLAY         */
	volatile object V4;                       /*  STRING          */
	volatile int V5;                          /*  LENGTH          */
	V3= ((V1))->in.in_slots[1];
	V4= coerce_to_string((V2));
	V5= ((V4))->v.v_fillp;
	{volatile object V6;                      /*  .DISPLAY.       */
	volatile object V7;                       /*  .PENDING-COMMAND.*/
	volatile object V8;                       /*  .REPLY-BUFFER.  */
	V6= (V3);
	V7= Cnil;
	V8= Cnil;
	{ int V9; volatile bool unwinding = FALSE;
	if ((V9=frs_push(FRS_PROTECT,Cnil))) {
	V9--; unwinding = TRUE;} else {
	if((((V6))->in.in_slots[10])==Cnil){
	goto L3324;}
	(*LK0)(3,VV[16],VV[10],(V6))              /*  X-ERROR         */;
L3324:
	(*LK15)(1,(V6))                           /*  START-PENDING-COMMAND*/;
	V7= VALUES(0);
	{register object V10;                     /*  %BUFFER         */
	V10= (V6);
	if(!(((fix(((V10))->in.in_slots[6]))+(160))>=(fix(((V10))->in.in_slots[2])))){
	goto L3330;}
	(*LK7)(1,(V10))                           /*  BUFFER-FLUSH    */;
L3330:
	{register int V11;                        /*  BUFFER-BOFFSET  */
	register object V12;                      /*  BUFFER-BBUF     */
	V11= fix(((V10))->in.in_slots[6]);
	V12= ((V10))->in.in_slots[7];
	((V6))->in.in_slots[4]= MAKE_FIXNUM(V11);
	(((V12))->ust.ust_self[(V11)+(0)]=(92));
	(*LK11)(1,(V1))                           /*  COLORMAP-P      */;
	if(VALUES(0)==Cnil){
	goto L3341;}
	((*(unsigned long *)(((V12))->ust.ust_self+((V11)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L3339;
L3341:
	(*LK4)(2,(V1),VV[37])                     /*  X-TYPE-ERROR    */;
L3339:
	(*LK8)(2,MAKE_FIXNUM(V5),VV[21])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3345;}
	((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(8))))=V5);
	goto L3343;
L3345:
	(*LK4)(2,MAKE_FIXNUM(V5),VV[21])          /*  X-TYPE-ERROR    */;
L3343:
	(*LK8)(2,(V4),VV[44])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3350;}
	{int V13;
	V13= ((V4))->v.v_fillp;
	Lceiling(2,MAKE_FIXNUM(((V13)-(0))+(12)),MAKE_FIXNUM(4))/*  CEILING*/;
	T0= VALUES(0);
	((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(2))))=fix(T0));
	(*LK24)(5,(V10),MAKE_FIXNUM((V11)+(12)),(V4),MAKE_FIXNUM(0),MAKE_FIXNUM(V13))/*  WRITE-SEQUENCE-CHAR*/;
	goto L3348;
	}
L3350:
	(*LK4)(2,(V4),VV[44])                     /*  X-TYPE-ERROR    */;
L3348:
	(*LK13)(1,(V6))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V6))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V6))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V6),(V7))                      /*  READ-REPLY      */;
	V8= VALUES(0);
	{object V10;                              /*  %REPLY-BUFFER   */
	object V11;                               /*  %BUFFER         */
	{register int V12;                        /*  BUFFER-BOFFSET  */
	register object V13;                      /*  BUFFER-BBUF     */
	V12= 0;
	V13= ((V8))->in.in_slots[1];
	(*LK48)(1,MAKE_FIXNUM((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(14))))))/*  CARD16->RGB-VAL*/;
	T0= VALUES(0);
	(*LK48)(1,MAKE_FIXNUM((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(16))))))/*  CARD16->RGB-VAL*/;
	T1= VALUES(0);
	(*LK48)(1,MAKE_FIXNUM((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(18))))))/*  CARD16->RGB-VAL*/;
	(*LK49)(6,VV[122],T0,VV[123],T1,VV[124],VALUES(0))/*  MAKE-COLOR*/;
	T2= VALUES(0);
	(*LK48)(1,MAKE_FIXNUM((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(8))))))/*  CARD16->RGB-VAL*/;
	T3= VALUES(0);
	(*LK48)(1,MAKE_FIXNUM((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(10))))))/*  CARD16->RGB-VAL*/;
	T4= VALUES(0);
	(*LK48)(1,MAKE_FIXNUM((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(12))))))/*  CARD16->RGB-VAL*/;
	(*LK49)(6,VV[122],T3,VV[123],T4,VV[124],VALUES(0))/*  MAKE-COLOR*/;
	VALUES(1) = VALUES(0);
	VALUES(0) = T2;
	V9=2;
	}
	}
	}
	frs_pop();
	MV_SAVE(V9);
	if(((V8))==Cnil){
	goto L3373;}
	(*LK20)(1,(V8))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L3373:
	if(((V7))==Cnil){
	goto L3372;}
	(*LK21)(2,(V6),(V7))                      /*  STOP-PENDING-COMMAND*/;
L3372:
	MV_RESTORE(V9);
	if (unwinding) unwind(nlj_fr,nlj_tag,V9+1);
	else {
	RETURN(V9);}}
	}
	}
}
/*	function definition for CREATE-CURSOR                         */
static L72(int narg, ...)
{ VT74 VLEX74 CLSR74
	{register object V1;
	register object V2;
	int V3;
	int V4;
	object V5;
	object V6;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[12];
	parse_key(narg,args,6,L72keys,keyvars,OBJNULL,FALSE);
	if(keyvars[6]==Cnil){
	(*LK0)(3,VV[0],VV[1],VV[138])             /*  X-ERROR         */;
	V1= (VV[3]->s.s_dbind);
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	if(keyvars[8]==Cnil){
	(*LK0)(3,VV[0],VV[1],VV[4])               /*  X-ERROR         */;
	V3= fix((VV[3]->s.s_dbind));
	}else{
	V3= fix(keyvars[2]);}
	if(keyvars[9]==Cnil){
	(*LK0)(3,VV[0],VV[1],VV[5])               /*  X-ERROR         */;
	V4= fix((VV[3]->s.s_dbind));
	}else{
	V4= fix(keyvars[3]);}
	if(keyvars[10]==Cnil){
	(*LK0)(3,VV[0],VV[1],VV[139])             /*  X-ERROR         */;
	V5= (VV[3]->s.s_dbind);
	}else{
	V5= keyvars[4];}
	if(keyvars[11]==Cnil){
	(*LK0)(3,VV[0],VV[1],VV[140])             /*  X-ERROR         */;
	V6= (VV[3]->s.s_dbind);
	}else{
	V6= keyvars[5];}
	}
	{register object V7;                      /*  DISPLAY         */
	object V8;                                /*  CURSOR          */
	register int V9;                          /*  CID             */
	V7= ((V1))->in.in_slots[1];
	(*LK52)(2,VV[10],(V7))                    /*  MAKE-CURSOR     */;
	V8= VALUES(0);
	{object V10;                              /*  ID              */
	T0= ((V7))->in.in_slots[35];
	funcall(2,T0,(V7));
	V10= VALUES(0);
	(*LK2)(3,(V7),(V10),(V8))                 /*  SAVE-ID         */;
	V9= fix((V10));
	}
	((V8))->in.in_slots[0]= MAKE_FIXNUM(V9);
	{register object V10;                     /*  .DISPLAY.       */
	V10= (V7);
	if((((V10))->in.in_slots[10])==Cnil){
	goto L3396;}
	(*LK0)(3,VV[16],VV[10],(V10))             /*  X-ERROR         */;
L3396:
	{register object V11;                     /*  %BUFFER         */
	V11= (V10);
	if(!(((fix(((V11))->in.in_slots[6]))+(160))>=(fix(((V11))->in.in_slots[2])))){
	goto L3400;}
	(*LK7)(1,(V11))                           /*  BUFFER-FLUSH    */;
L3400:
	{register int V12;                        /*  BUFFER-BOFFSET  */
	register object V13;                      /*  BUFFER-BBUF     */
	V12= fix(((V11))->in.in_slots[6]);
	V13= ((V11))->in.in_slots[7];
	((V10))->in.in_slots[4]= MAKE_FIXNUM(V12);
	(((V13))->ust.ust_self[(V12)+(0)]=(93));
	(*LK8)(2,MAKE_FIXNUM(V9),VV[19])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3411;}
	((*(unsigned long *)(((V13))->ust.ust_self+((V12)+(4))))=V9);
	goto L3409;
L3411:
	(*LK4)(2,MAKE_FIXNUM(V9),VV[19])          /*  X-TYPE-ERROR    */;
L3409:
	(*LK3)(1,(V1))                            /*  PIXMAP-P        */;
	if(VALUES(0)==Cnil){
	goto L3415;}
	((*(unsigned long *)(((V13))->ust.ust_self+((V12)+(8))))=fix(((V1))->in.in_slots[0]));
	goto L3413;
L3415:
	(*LK4)(2,(V1),VV[12])                     /*  X-TYPE-ERROR    */;
L3413:
	if(!((V2)==Cnil)){
	goto L3419;}
	((*(unsigned long *)(((V13))->ust.ust_self+((V12)+(12))))=0);
	goto L3417;
L3419:
	(*LK3)(1,(V2))                            /*  PIXMAP-P        */;
	if(VALUES(0)==Cnil){
	goto L3422;}
	((*(unsigned long *)(((V13))->ust.ust_self+((V12)+(12))))=fix(((V2))->in.in_slots[0]));
	goto L3417;
L3422:
	(*LK4)(2,(V2),VV[141])                    /*  X-TYPE-ERROR    */;
L3417:
	{object V14;                              /*  .VALUE.         */
	V14= ((V5))->in.in_slots[0];
	(*LK8)(2,(V14),VV[121])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3427;}
	(*LK47)(1,(V14))                          /*  RGB-VAL->CARD16 */;
	T0= VALUES(0);
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(16))))=fix(T0));
	goto L3424;
L3427:
	(*LK4)(2,(V14),VV[121])                   /*  X-TYPE-ERROR    */;
	}
L3424:
	{object V14;                              /*  .VALUE.         */
	V14= ((V5))->in.in_slots[1];
	(*LK8)(2,(V14),VV[121])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3433;}
	(*LK47)(1,(V14))                          /*  RGB-VAL->CARD16 */;
	T0= VALUES(0);
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(18))))=fix(T0));
	goto L3430;
L3433:
	(*LK4)(2,(V14),VV[121])                   /*  X-TYPE-ERROR    */;
	}
L3430:
	{object V14;                              /*  .VALUE.         */
	V14= ((V5))->in.in_slots[2];
	(*LK8)(2,(V14),VV[121])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3439;}
	(*LK47)(1,(V14))                          /*  RGB-VAL->CARD16 */;
	T0= VALUES(0);
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(20))))=fix(T0));
	goto L3436;
L3439:
	(*LK4)(2,(V14),VV[121])                   /*  X-TYPE-ERROR    */;
	}
L3436:
	{object V14;                              /*  .VALUE.         */
	V14= ((V6))->in.in_slots[0];
	(*LK8)(2,(V14),VV[121])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3445;}
	(*LK47)(1,(V14))                          /*  RGB-VAL->CARD16 */;
	T0= VALUES(0);
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(22))))=fix(T0));
	goto L3442;
L3445:
	(*LK4)(2,(V14),VV[121])                   /*  X-TYPE-ERROR    */;
	}
L3442:
	{object V14;                              /*  .VALUE.         */
	V14= ((V6))->in.in_slots[1];
	(*LK8)(2,(V14),VV[121])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3451;}
	(*LK47)(1,(V14))                          /*  RGB-VAL->CARD16 */;
	T0= VALUES(0);
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(24))))=fix(T0));
	goto L3448;
L3451:
	(*LK4)(2,(V14),VV[121])                   /*  X-TYPE-ERROR    */;
	}
L3448:
	{object V14;                              /*  .VALUE.         */
	V14= ((V6))->in.in_slots[2];
	(*LK8)(2,(V14),VV[121])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3457;}
	(*LK47)(1,(V14))                          /*  RGB-VAL->CARD16 */;
	T0= VALUES(0);
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(26))))=fix(T0));
	goto L3454;
L3457:
	(*LK4)(2,(V14),VV[121])                   /*  X-TYPE-ERROR    */;
	}
L3454:
	(*LK8)(2,MAKE_FIXNUM(V3),VV[21])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3462;}
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(28))))=V3);
	goto L3460;
L3462:
	(*LK4)(2,MAKE_FIXNUM(V3),VV[21])          /*  X-TYPE-ERROR    */;
L3460:
	(*LK8)(2,MAKE_FIXNUM(V4),VV[21])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3466;}
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(30))))=V4);
	goto L3464;
L3466:
	(*LK4)(2,MAKE_FIXNUM(V4),VV[21])          /*  X-TYPE-ERROR    */;
L3464:
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(2))))=8);
	((V10))->in.in_slots[6]= MAKE_FIXNUM((V12)+(32));
	(*LK13)(1,(V10))                          /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK14)(1,(V10))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	VALUES(0) = (V8);
	RETURN(1);
	}
	}
}
/*	function definition for CREATE-GLYPH-CURSOR                   */
static L73(int narg, ...)
{ VT75 VLEX75 CLSR75
	{object V1;
	int V2;
	object V3;
	register object V4;
	object V5;
	object V6;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[12];
	parse_key(narg,args,6,L73keys,keyvars,OBJNULL,FALSE);
	if(keyvars[6]==Cnil){
	(*LK0)(3,VV[0],VV[1],VV[142])             /*  X-ERROR         */;
	V1= (VV[3]->s.s_dbind);
	}else{
	V1= keyvars[0];}
	if(keyvars[7]==Cnil){
	(*LK0)(3,VV[0],VV[1],VV[143])             /*  X-ERROR         */;
	V2= fix((VV[3]->s.s_dbind));
	}else{
	V2= fix(keyvars[1]);}
	V3= keyvars[2];
	V4= keyvars[3];
	if(keyvars[10]==Cnil){
	(*LK0)(3,VV[0],VV[1],VV[139])             /*  X-ERROR         */;
	V5= (VV[3]->s.s_dbind);
	}else{
	V5= keyvars[4];}
	if(keyvars[11]==Cnil){
	(*LK0)(3,VV[0],VV[1],VV[140])             /*  X-ERROR         */;
	V6= (VV[3]->s.s_dbind);
	}else{
	V6= keyvars[5];}
	}
	{register object V7;                      /*  DISPLAY         */
	object V8;                                /*  CURSOR          */
	register int V9;                          /*  CID             */
	object V10;                               /*  SOURCE-FONT-ID  */
	object V11;                               /*  MASK-FONT-ID    */
	V7= ((V1))->in.in_slots[1];
	(*LK52)(2,VV[10],(V7))                    /*  MAKE-CURSOR     */;
	V8= VALUES(0);
	{object V12;                              /*  ID              */
	T0= ((V7))->in.in_slots[35];
	funcall(2,T0,(V7));
	V12= VALUES(0);
	(*LK2)(3,(V7),(V12),(V8))                 /*  SAVE-ID         */;
	V9= fix((V12));
	}
	(*LK53)(1,(V1))                           /*  FONT-ID         */;
	V10= VALUES(0);
	if(((V3))==Cnil){
	goto L3487;}
	(*LK53)(1,(V3))                           /*  FONT-ID         */;
	V11= VALUES(0);
	goto L3485;
L3487:
	V11= MAKE_FIXNUM(0);
L3485:
	((V8))->in.in_slots[0]= MAKE_FIXNUM(V9);
	if(((V4))!=Cnil){
	goto L3490;}
	V4= MAKE_FIXNUM(0);
L3490:
	{register object V12;                     /*  .DISPLAY.       */
	V12= (V7);
	if((((V12))->in.in_slots[10])==Cnil){
	goto L3495;}
	(*LK0)(3,VV[16],VV[10],(V12))             /*  X-ERROR         */;
L3495:
	{register object V13;                     /*  %BUFFER         */
	V13= (V12);
	if(!(((fix(((V13))->in.in_slots[6]))+(160))>=(fix(((V13))->in.in_slots[2])))){
	goto L3499;}
	(*LK7)(1,(V13))                           /*  BUFFER-FLUSH    */;
L3499:
	{register int V14;                        /*  BUFFER-BOFFSET  */
	register object V15;                      /*  BUFFER-BBUF     */
	V14= fix(((V13))->in.in_slots[6]);
	V15= ((V13))->in.in_slots[7];
	((V12))->in.in_slots[4]= MAKE_FIXNUM(V14);
	(((V15))->ust.ust_self[(V14)+(0)]=(94));
	(*LK8)(2,MAKE_FIXNUM(V9),VV[19])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3510;}
	((*(unsigned long *)(((V15))->ust.ust_self+((V14)+(4))))=V9);
	goto L3508;
L3510:
	(*LK4)(2,MAKE_FIXNUM(V9),VV[19])          /*  X-TYPE-ERROR    */;
L3508:
	(*LK8)(2,(V10),VV[19])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3514;}
	((*(unsigned long *)(((V15))->ust.ust_self+((V14)+(8))))=fix((V10)));
	goto L3512;
L3514:
	(*LK4)(2,(V10),VV[19])                    /*  X-TYPE-ERROR    */;
L3512:
	(*LK8)(2,(V11),VV[19])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3518;}
	((*(unsigned long *)(((V15))->ust.ust_self+((V14)+(12))))=fix((V11)));
	goto L3516;
L3518:
	(*LK4)(2,(V11),VV[19])                    /*  X-TYPE-ERROR    */;
L3516:
	(*LK8)(2,MAKE_FIXNUM(V2),VV[21])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3522;}
	((*(unsigned short *)(((V15))->ust.ust_self+((V14)+(16))))=V2);
	goto L3520;
L3522:
	(*LK4)(2,MAKE_FIXNUM(V2),VV[21])          /*  X-TYPE-ERROR    */;
L3520:
	(*LK8)(2,(V4),VV[21])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3526;}
	((*(unsigned short *)(((V15))->ust.ust_self+((V14)+(18))))=fix((V4)));
	goto L3524;
L3526:
	(*LK4)(2,(V4),VV[21])                     /*  X-TYPE-ERROR    */;
L3524:
	{object V16;                              /*  .VALUE.         */
	V16= ((V5))->in.in_slots[0];
	(*LK8)(2,(V16),VV[121])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3531;}
	(*LK47)(1,(V16))                          /*  RGB-VAL->CARD16 */;
	T0= VALUES(0);
	((*(unsigned short *)(((V15))->ust.ust_self+((V14)+(20))))=fix(T0));
	goto L3528;
L3531:
	(*LK4)(2,(V16),VV[121])                   /*  X-TYPE-ERROR    */;
	}
L3528:
	{object V16;                              /*  .VALUE.         */
	V16= ((V5))->in.in_slots[1];
	(*LK8)(2,(V16),VV[121])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3537;}
	(*LK47)(1,(V16))                          /*  RGB-VAL->CARD16 */;
	T0= VALUES(0);
	((*(unsigned short *)(((V15))->ust.ust_self+((V14)+(22))))=fix(T0));
	goto L3534;
L3537:
	(*LK4)(2,(V16),VV[121])                   /*  X-TYPE-ERROR    */;
	}
L3534:
	{object V16;                              /*  .VALUE.         */
	V16= ((V5))->in.in_slots[2];
	(*LK8)(2,(V16),VV[121])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3543;}
	(*LK47)(1,(V16))                          /*  RGB-VAL->CARD16 */;
	T0= VALUES(0);
	((*(unsigned short *)(((V15))->ust.ust_self+((V14)+(24))))=fix(T0));
	goto L3540;
L3543:
	(*LK4)(2,(V16),VV[121])                   /*  X-TYPE-ERROR    */;
	}
L3540:
	{object V16;                              /*  .VALUE.         */
	V16= ((V6))->in.in_slots[0];
	(*LK8)(2,(V16),VV[121])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3549;}
	(*LK47)(1,(V16))                          /*  RGB-VAL->CARD16 */;
	T0= VALUES(0);
	((*(unsigned short *)(((V15))->ust.ust_self+((V14)+(26))))=fix(T0));
	goto L3546;
L3549:
	(*LK4)(2,(V16),VV[121])                   /*  X-TYPE-ERROR    */;
	}
L3546:
	{object V16;                              /*  .VALUE.         */
	V16= ((V6))->in.in_slots[1];
	(*LK8)(2,(V16),VV[121])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3555;}
	(*LK47)(1,(V16))                          /*  RGB-VAL->CARD16 */;
	T0= VALUES(0);
	((*(unsigned short *)(((V15))->ust.ust_self+((V14)+(28))))=fix(T0));
	goto L3552;
L3555:
	(*LK4)(2,(V16),VV[121])                   /*  X-TYPE-ERROR    */;
	}
L3552:
	{object V16;                              /*  .VALUE.         */
	V16= ((V6))->in.in_slots[2];
	(*LK8)(2,(V16),VV[121])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3561;}
	(*LK47)(1,(V16))                          /*  RGB-VAL->CARD16 */;
	T0= VALUES(0);
	((*(unsigned short *)(((V15))->ust.ust_self+((V14)+(30))))=fix(T0));
	goto L3558;
L3561:
	(*LK4)(2,(V16),VV[121])                   /*  X-TYPE-ERROR    */;
	}
L3558:
	((*(unsigned short *)(((V15))->ust.ust_self+((V14)+(2))))=8);
	((V12))->in.in_slots[6]= MAKE_FIXNUM((V14)+(32));
	(*LK13)(1,(V12))                          /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK14)(1,(V12))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	VALUES(0) = (V8);
	RETURN(1);
	}
	}
}
/*	function definition for FREE-CURSOR                           */
static L74(int narg, object V1)
{ VT76 VLEX76 CLSR76
TTL:
	{object V2;                               /*  DISPLAY         */
	V2= ((V1))->in.in_slots[1];
	{register object V3;                      /*  .DISPLAY.       */
	V3= (V2);
	if((((V3))->in.in_slots[10])==Cnil){
	goto L3568;}
	(*LK0)(3,VV[16],VV[10],(V3))              /*  X-ERROR         */;
L3568:
	{register object V4;                      /*  %BUFFER         */
	V4= (V3);
	if(!(((fix(((V4))->in.in_slots[6]))+(160))>=(fix(((V4))->in.in_slots[2])))){
	goto L3572;}
	(*LK7)(1,(V4))                            /*  BUFFER-FLUSH    */;
L3572:
	{register int V5;                         /*  BUFFER-BOFFSET  */
	register object V6;                       /*  BUFFER-BBUF     */
	V5= fix(((V4))->in.in_slots[6]);
	V6= ((V4))->in.in_slots[7];
	((V3))->in.in_slots[4]= MAKE_FIXNUM(V5);
	(((V6))->ust.ust_self[(V5)+(0)]=(95));
	(*LK12)(1,(V1))                           /*  CURSOR-P        */;
	if(VALUES(0)==Cnil){
	goto L3583;}
	((*(unsigned long *)(((V6))->ust.ust_self+((V5)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L3581;
L3583:
	(*LK4)(2,(V1),VV[40])                     /*  X-TYPE-ERROR    */;
L3581:
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(2))))=2);
	((V3))->in.in_slots[6]= MAKE_FIXNUM((V5)+(8));
	(*LK13)(1,(V3))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK14)(1,(V3))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	RETURN((*LK41)(2,(V2),((V1))->in.in_slots[0])/*  DEALLOCATE-RESOURCE-ID-INTERNAL*/);
	}
}
/*	function definition for RECOLOR-CURSOR                        */
static L75(int narg, object V1, object V2, object V3)
{ VT77 VLEX77 CLSR77
TTL:
	{register object V4;                      /*  .DISPLAY.       */
	V4= ((V1))->in.in_slots[1];
	if((((V4))->in.in_slots[10])==Cnil){
	goto L3588;}
	(*LK0)(3,VV[16],VV[10],(V4))              /*  X-ERROR         */;
L3588:
	{ int V5;
	{register object V6;                      /*  %BUFFER         */
	V6= (V4);
	if(!(((fix(((V6))->in.in_slots[6]))+(160))>=(fix(((V6))->in.in_slots[2])))){
	goto L3592;}
	(*LK7)(1,(V6))                            /*  BUFFER-FLUSH    */;
L3592:
	{register int V7;                         /*  BUFFER-BOFFSET  */
	register object V8;                       /*  BUFFER-BBUF     */
	V7= fix(((V6))->in.in_slots[6]);
	V8= ((V6))->in.in_slots[7];
	((V4))->in.in_slots[4]= MAKE_FIXNUM(V7);
	(((V8))->ust.ust_self[(V7)+(0)]=(96));
	(*LK12)(1,(V1))                           /*  CURSOR-P        */;
	if(VALUES(0)==Cnil){
	goto L3603;}
	((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L3601;
L3603:
	(*LK4)(2,(V1),VV[40])                     /*  X-TYPE-ERROR    */;
L3601:
	{object V9;                               /*  .VALUE.         */
	V9= ((V2))->in.in_slots[0];
	(*LK8)(2,(V9),VV[121])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3608;}
	(*LK47)(1,(V9))                           /*  RGB-VAL->CARD16 */;
	T0= VALUES(0);
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(8))))=fix(T0));
	goto L3605;
L3608:
	(*LK4)(2,(V9),VV[121])                    /*  X-TYPE-ERROR    */;
	}
L3605:
	{object V9;                               /*  .VALUE.         */
	V9= ((V2))->in.in_slots[1];
	(*LK8)(2,(V9),VV[121])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3614;}
	(*LK47)(1,(V9))                           /*  RGB-VAL->CARD16 */;
	T0= VALUES(0);
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(10))))=fix(T0));
	goto L3611;
L3614:
	(*LK4)(2,(V9),VV[121])                    /*  X-TYPE-ERROR    */;
	}
L3611:
	{object V9;                               /*  .VALUE.         */
	V9= ((V2))->in.in_slots[2];
	(*LK8)(2,(V9),VV[121])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3620;}
	(*LK47)(1,(V9))                           /*  RGB-VAL->CARD16 */;
	T0= VALUES(0);
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(12))))=fix(T0));
	goto L3617;
L3620:
	(*LK4)(2,(V9),VV[121])                    /*  X-TYPE-ERROR    */;
	}
L3617:
	{object V9;                               /*  .VALUE.         */
	V9= ((V3))->in.in_slots[0];
	(*LK8)(2,(V9),VV[121])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3626;}
	(*LK47)(1,(V9))                           /*  RGB-VAL->CARD16 */;
	T0= VALUES(0);
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(14))))=fix(T0));
	goto L3623;
L3626:
	(*LK4)(2,(V9),VV[121])                    /*  X-TYPE-ERROR    */;
	}
L3623:
	{object V9;                               /*  .VALUE.         */
	V9= ((V3))->in.in_slots[1];
	(*LK8)(2,(V9),VV[121])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3632;}
	(*LK47)(1,(V9))                           /*  RGB-VAL->CARD16 */;
	T0= VALUES(0);
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(16))))=fix(T0));
	goto L3629;
L3632:
	(*LK4)(2,(V9),VV[121])                    /*  X-TYPE-ERROR    */;
	}
L3629:
	{object V9;                               /*  .VALUE.         */
	V9= ((V3))->in.in_slots[2];
	(*LK8)(2,(V9),VV[121])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3638;}
	(*LK47)(1,(V9))                           /*  RGB-VAL->CARD16 */;
	T0= VALUES(0);
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(18))))=fix(T0));
	goto L3635;
L3638:
	(*LK4)(2,(V9),VV[121])                    /*  X-TYPE-ERROR    */;
	}
L3635:
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(2))))=5);
	((V4))->in.in_slots[6]= MAKE_FIXNUM((V7)+(20));
	V5=(*LK13)(1,(V4))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V5);
	(*LK14)(1,(V4))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V5);
	RETURN(V5);}
	}
}
/*	function definition for QUERY-BEST-CURSOR                     */
static L76(int narg, object V1, object V2, object V3)
{ VT78 VLEX78 CLSR78
	{volatile int V4;
	volatile int V5;
	V4= fix(V1);
	V5= fix(V2);
TTL:
	{ int V6;
	volatile object V7;                       /*  DISPLAY         */
	volatile object V8;                       /*  DRAWABLE        */
	(*LK40)(1,(V3))                           /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L3646;}
	VALUES(1) = (V3);
	VALUES(0) = ((V3))->in.in_slots[1];
	V6=2;
	goto L3644;
L3646:
	VALUES(1) = (((V3))->in.in_slots[39])->in.in_slots[0];
	VALUES(0) = (V3);
	V6=2;
L3644:
	if (V6--==0) goto L3648;
	V7= VALUES(0);
	if (V6--==0) goto L3649;
	V8= VALUES(1);
	goto L3650;
L3648:
	V7= Cnil;
L3649:
	V8= Cnil;
L3650:
	{volatile object V9;                      /*  .DISPLAY.       */
	volatile object V10;                      /*  .PENDING-COMMAND.*/
	volatile object V11;                      /*  .REPLY-BUFFER.  */
	V9= (V7);
	V10= Cnil;
	V11= Cnil;
	{ int V12; volatile bool unwinding = FALSE;
	if ((V12=frs_push(FRS_PROTECT,Cnil))) {
	V12--; unwinding = TRUE;} else {
	if((((V9))->in.in_slots[10])==Cnil){
	goto L3653;}
	(*LK0)(3,VV[16],VV[10],(V9))              /*  X-ERROR         */;
L3653:
	(*LK15)(1,(V9))                           /*  START-PENDING-COMMAND*/;
	V10= VALUES(0);
	{register object V13;                     /*  %BUFFER         */
	V13= (V9);
	if(!(((fix(((V13))->in.in_slots[6]))+(160))>=(fix(((V13))->in.in_slots[2])))){
	goto L3659;}
	(*LK7)(1,(V13))                           /*  BUFFER-FLUSH    */;
L3659:
	{register int V14;                        /*  BUFFER-BOFFSET  */
	register object V15;                      /*  BUFFER-BBUF     */
	V14= fix(((V13))->in.in_slots[6]);
	V15= ((V13))->in.in_slots[7];
	((V9))->in.in_slots[4]= MAKE_FIXNUM(V14);
	(((V15))->ust.ust_self[(V14)+(0)]=(97));
	(((V15))->ust.ust_self[(V14)+(1)]=(0));
	(*LK9)(1,(V8))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L3671;}
	((*(unsigned long *)(((V15))->ust.ust_self+((V14)+(4))))=fix(((V8))->in.in_slots[0]));
	goto L3669;
L3671:
	(*LK4)(2,(V8),VV[9])                      /*  X-TYPE-ERROR    */;
L3669:
	(*LK8)(2,MAKE_FIXNUM(V4),VV[21])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3675;}
	((*(unsigned short *)(((V15))->ust.ust_self+((V14)+(8))))=V4);
	goto L3673;
L3675:
	(*LK4)(2,MAKE_FIXNUM(V4),VV[21])          /*  X-TYPE-ERROR    */;
L3673:
	(*LK8)(2,MAKE_FIXNUM(V5),VV[21])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3679;}
	((*(unsigned short *)(((V15))->ust.ust_self+((V14)+(10))))=V5);
	goto L3677;
L3679:
	(*LK4)(2,MAKE_FIXNUM(V5),VV[21])          /*  X-TYPE-ERROR    */;
L3677:
	((*(unsigned short *)(((V15))->ust.ust_self+((V14)+(2))))=3);
	((V9))->in.in_slots[6]= MAKE_FIXNUM((V14)+(12));
	(*LK13)(1,(V9))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V9))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V9))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V9),(V10))                     /*  READ-REPLY      */;
	V11= VALUES(0);
	{object V13;                              /*  %REPLY-BUFFER   */
	object V14;                               /*  %BUFFER         */
	{register int V15;                        /*  BUFFER-BOFFSET  */
	object V16;                               /*  BUFFER-BBUF     */
	V15= 0;
	V16= ((V11))->in.in_slots[1];
	{int V17= (*(unsigned short *)(((V16))->ust.ust_self+((V15)+(8))));
	VALUES(1) = MAKE_FIXNUM((*(unsigned short *)(((V16))->ust.ust_self+((V15)+(10)))));
	VALUES(0) = MAKE_FIXNUM(V17);
	V12=2;}
	}
	}
	}
	frs_pop();
	MV_SAVE(V12);
	if(((V11))==Cnil){
	goto L3693;}
	(*LK20)(1,(V11))                          /*  DEALLOCATE-REPLY-BUFFER*/;
L3693:
	if(((V10))==Cnil){
	goto L3692;}
	(*LK21)(2,(V9),(V10))                     /*  STOP-PENDING-COMMAND*/;
L3692:
	MV_RESTORE(V12);
	if (unwinding) unwind(nlj_fr,nlj_tag,V12+1);
	else {
	RETURN(V12);}}
	}}
	}
}
/*	function definition for QUERY-BEST-TILE                       */
static L77(int narg, object V1, object V2, object V3)
{ VT79 VLEX79 CLSR79
	{volatile int V4;
	volatile int V5;
	V4= fix(V1);
	V5= fix(V2);
TTL:
	{volatile object V6;                      /*  DISPLAY         */
	V6= ((V3))->in.in_slots[1];
	{volatile object V7;                      /*  .DISPLAY.       */
	volatile object V8;                       /*  .PENDING-COMMAND.*/
	volatile object V9;                       /*  .REPLY-BUFFER.  */
	V7= (V6);
	V8= Cnil;
	V9= Cnil;
	{ int V10; volatile bool unwinding = FALSE;
	if ((V10=frs_push(FRS_PROTECT,Cnil))) {
	V10--; unwinding = TRUE;} else {
	if((((V7))->in.in_slots[10])==Cnil){
	goto L3701;}
	(*LK0)(3,VV[16],VV[10],(V7))              /*  X-ERROR         */;
L3701:
	(*LK15)(1,(V7))                           /*  START-PENDING-COMMAND*/;
	V8= VALUES(0);
	{register object V11;                     /*  %BUFFER         */
	V11= (V7);
	if(!(((fix(((V11))->in.in_slots[6]))+(160))>=(fix(((V11))->in.in_slots[2])))){
	goto L3707;}
	(*LK7)(1,(V11))                           /*  BUFFER-FLUSH    */;
L3707:
	{register int V12;                        /*  BUFFER-BOFFSET  */
	register object V13;                      /*  BUFFER-BBUF     */
	V12= fix(((V11))->in.in_slots[6]);
	V13= ((V11))->in.in_slots[7];
	((V7))->in.in_slots[4]= MAKE_FIXNUM(V12);
	(((V13))->ust.ust_self[(V12)+(0)]=(97));
	(((V13))->ust.ust_self[(V12)+(1)]=(1));
	(*LK40)(1,(V3))                           /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L3719;}
	((*(unsigned long *)(((V13))->ust.ust_self+((V12)+(4))))=fix(((V3))->in.in_slots[0]));
	goto L3717;
L3719:
	(*LK4)(2,(V3),VV[114])                    /*  X-TYPE-ERROR    */;
L3717:
	(*LK8)(2,MAKE_FIXNUM(V4),VV[21])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3723;}
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(8))))=V4);
	goto L3721;
L3723:
	(*LK4)(2,MAKE_FIXNUM(V4),VV[21])          /*  X-TYPE-ERROR    */;
L3721:
	(*LK8)(2,MAKE_FIXNUM(V5),VV[21])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3727;}
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(10))))=V5);
	goto L3725;
L3727:
	(*LK4)(2,MAKE_FIXNUM(V5),VV[21])          /*  X-TYPE-ERROR    */;
L3725:
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(2))))=3);
	((V7))->in.in_slots[6]= MAKE_FIXNUM((V12)+(12));
	(*LK13)(1,(V7))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V7))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V7))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V7),(V8))                      /*  READ-REPLY      */;
	V9= VALUES(0);
	{object V11;                              /*  %REPLY-BUFFER   */
	object V12;                               /*  %BUFFER         */
	{register int V13;                        /*  BUFFER-BOFFSET  */
	object V14;                               /*  BUFFER-BBUF     */
	V13= 0;
	V14= ((V9))->in.in_slots[1];
	{int V15= (*(unsigned short *)(((V14))->ust.ust_self+((V13)+(8))));
	VALUES(1) = MAKE_FIXNUM((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(10)))));
	VALUES(0) = MAKE_FIXNUM(V15);
	V10=2;}
	}
	}
	}
	frs_pop();
	MV_SAVE(V10);
	if(((V9))==Cnil){
	goto L3741;}
	(*LK20)(1,(V9))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L3741:
	if(((V8))==Cnil){
	goto L3740;}
	(*LK21)(2,(V7),(V8))                      /*  STOP-PENDING-COMMAND*/;
L3740:
	MV_RESTORE(V10);
	if (unwinding) unwind(nlj_fr,nlj_tag,V10+1);
	else {
	RETURN(V10);}}
	}
	}
	}
}
/*	function definition for QUERY-BEST-STIPPLE                    */
static L78(int narg, object V1, object V2, object V3)
{ VT80 VLEX80 CLSR80
	{volatile int V4;
	volatile int V5;
	V4= fix(V1);
	V5= fix(V2);
TTL:
	{volatile object V6;                      /*  DISPLAY         */
	V6= ((V3))->in.in_slots[1];
	{volatile object V7;                      /*  .DISPLAY.       */
	volatile object V8;                       /*  .PENDING-COMMAND.*/
	volatile object V9;                       /*  .REPLY-BUFFER.  */
	V7= (V6);
	V8= Cnil;
	V9= Cnil;
	{ int V10; volatile bool unwinding = FALSE;
	if ((V10=frs_push(FRS_PROTECT,Cnil))) {
	V10--; unwinding = TRUE;} else {
	if((((V7))->in.in_slots[10])==Cnil){
	goto L3749;}
	(*LK0)(3,VV[16],VV[10],(V7))              /*  X-ERROR         */;
L3749:
	(*LK15)(1,(V7))                           /*  START-PENDING-COMMAND*/;
	V8= VALUES(0);
	{register object V11;                     /*  %BUFFER         */
	V11= (V7);
	if(!(((fix(((V11))->in.in_slots[6]))+(160))>=(fix(((V11))->in.in_slots[2])))){
	goto L3755;}
	(*LK7)(1,(V11))                           /*  BUFFER-FLUSH    */;
L3755:
	{register int V12;                        /*  BUFFER-BOFFSET  */
	register object V13;                      /*  BUFFER-BBUF     */
	V12= fix(((V11))->in.in_slots[6]);
	V13= ((V11))->in.in_slots[7];
	((V7))->in.in_slots[4]= MAKE_FIXNUM(V12);
	(((V13))->ust.ust_self[(V12)+(0)]=(97));
	(((V13))->ust.ust_self[(V12)+(1)]=(2));
	(*LK40)(1,(V3))                           /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L3767;}
	((*(unsigned long *)(((V13))->ust.ust_self+((V12)+(4))))=fix(((V3))->in.in_slots[0]));
	goto L3765;
L3767:
	(*LK4)(2,(V3),VV[114])                    /*  X-TYPE-ERROR    */;
L3765:
	(*LK8)(2,MAKE_FIXNUM(V4),VV[21])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3771;}
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(8))))=V4);
	goto L3769;
L3771:
	(*LK4)(2,MAKE_FIXNUM(V4),VV[21])          /*  X-TYPE-ERROR    */;
L3769:
	(*LK8)(2,MAKE_FIXNUM(V5),VV[21])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3775;}
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(10))))=V5);
	goto L3773;
L3775:
	(*LK4)(2,MAKE_FIXNUM(V5),VV[21])          /*  X-TYPE-ERROR    */;
L3773:
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(2))))=3);
	((V7))->in.in_slots[6]= MAKE_FIXNUM((V12)+(12));
	(*LK13)(1,(V7))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V7))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V7))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V7),(V8))                      /*  READ-REPLY      */;
	V9= VALUES(0);
	{object V11;                              /*  %REPLY-BUFFER   */
	object V12;                               /*  %BUFFER         */
	{register int V13;                        /*  BUFFER-BOFFSET  */
	object V14;                               /*  BUFFER-BBUF     */
	V13= 0;
	V14= ((V9))->in.in_slots[1];
	{int V15= (*(unsigned short *)(((V14))->ust.ust_self+((V13)+(8))));
	VALUES(1) = MAKE_FIXNUM((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(10)))));
	VALUES(0) = MAKE_FIXNUM(V15);
	V10=2;}
	}
	}
	}
	frs_pop();
	MV_SAVE(V10);
	if(((V9))==Cnil){
	goto L3789;}
	(*LK20)(1,(V9))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L3789:
	if(((V8))==Cnil){
	goto L3788;}
	(*LK21)(2,(V7),(V8))                      /*  STOP-PENDING-COMMAND*/;
L3788:
	MV_RESTORE(V10);
	if (unwinding) unwind(nlj_fr,nlj_tag,V10+1);
	else {
	RETURN(V10);}}
	}
	}
	}
}
/*	function definition for QUERY-EXTENSION                       */
static L79(int narg, object V1, object V2)
{ VT81 VLEX81 CLSR81
TTL:
	{volatile object V3;                      /*  STRING          */
	V3= coerce_to_string((V2));
	{volatile object V4;                      /*  .DISPLAY.       */
	volatile object V5;                       /*  .PENDING-COMMAND.*/
	volatile object V6;                       /*  .REPLY-BUFFER.  */
	V4= (V1);
	V5= Cnil;
	V6= Cnil;
	{ int V7; volatile bool unwinding = FALSE;
	if ((V7=frs_push(FRS_PROTECT,Cnil))) {
	V7--; unwinding = TRUE;} else {
	if((((V4))->in.in_slots[10])==Cnil){
	goto L3797;}
	(*LK0)(3,VV[16],VV[10],(V4))              /*  X-ERROR         */;
L3797:
	(*LK15)(1,(V4))                           /*  START-PENDING-COMMAND*/;
	V5= VALUES(0);
	{register object V8;                      /*  %BUFFER         */
	V8= (V4);
	if(!(((fix(((V8))->in.in_slots[6]))+(160))>=(fix(((V8))->in.in_slots[2])))){
	goto L3803;}
	(*LK7)(1,(V8))                            /*  BUFFER-FLUSH    */;
L3803:
	{register int V9;                         /*  BUFFER-BOFFSET  */
	register object V10;                      /*  BUFFER-BBUF     */
	V9= fix(((V8))->in.in_slots[6]);
	V10= ((V8))->in.in_slots[7];
	((V4))->in.in_slots[4]= MAKE_FIXNUM(V9);
	(((V10))->ust.ust_self[(V9)+(0)]=(98));
	{register int V11;                        /*  .VALUE.         */
	V11= ((V3))->v.v_fillp;
	(*LK8)(2,MAKE_FIXNUM(V11),VV[21])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3815;}
	((*(unsigned short *)(((V10))->ust.ust_self+((V9)+(4))))=V11);
	goto L3812;
L3815:
	(*LK4)(2,MAKE_FIXNUM(V11),VV[21])         /*  X-TYPE-ERROR    */;
	}
L3812:
	(*LK8)(2,(V3),VV[44])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3820;}
	{int V11;
	V11= ((V3))->v.v_fillp;
	Lceiling(2,MAKE_FIXNUM(((V11)-(0))+(8)),MAKE_FIXNUM(4))/*  CEILING*/;
	T0= VALUES(0);
	((*(unsigned short *)(((V10))->ust.ust_self+((V9)+(2))))=fix(T0));
	(*LK24)(5,(V8),MAKE_FIXNUM((V9)+(8)),(V3),MAKE_FIXNUM(0),MAKE_FIXNUM(V11))/*  WRITE-SEQUENCE-CHAR*/;
	goto L3818;
	}
L3820:
	(*LK4)(2,(V3),VV[44])                     /*  X-TYPE-ERROR    */;
L3818:
	(*LK13)(1,(V4))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V4))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V4))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V4),(V5))                      /*  READ-REPLY      */;
	V6= VALUES(0);
	{object V8;                               /*  %REPLY-BUFFER   */
	object V9;                                /*  %BUFFER         */
	{register int V10;                        /*  BUFFER-BOFFSET  */
	register object V11;                      /*  BUFFER-BBUF     */
	V10= 0;
	V11= ((V6))->in.in_slots[1];
	if((((V11))->ust.ust_self[(V10)+(8)])>0){
	goto L3834;}
	VALUES(0)=Cnil;
	V7=1;
	goto L3795;
L3834:
	{int V12= ((V11))->ust.ust_self[(V10)+(9)];
	{int V13= ((V11))->ust.ust_self[(V10)+(10)];
	VALUES(2) = MAKE_FIXNUM(((V11))->ust.ust_self[(V10)+(11)]);
	VALUES(1) = MAKE_FIXNUM(V13);
	VALUES(0) = MAKE_FIXNUM(V12);
	V7=3;}}
	}
	}
L3795:
	}
	frs_pop();
	MV_SAVE(V7);
	if(((V6))==Cnil){
	goto L3837;}
	(*LK20)(1,(V6))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L3837:
	if(((V5))==Cnil){
	goto L3836;}
	(*LK21)(2,(V4),(V5))                      /*  STOP-PENDING-COMMAND*/;
L3836:
	MV_RESTORE(V7);
	if (unwinding) unwind(nlj_fr,nlj_tag,V7+1);
	else {
	RETURN(V7);}}
	}
	}
}
/*	function definition for LIST-EXTENSIONS                       */
static L80(int narg, object V1, ...)
{ VT82 VLEX82 CLSR82
	{volatile object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[2];
	parse_key(narg,args,1,L80keys,keyvars,OBJNULL,FALSE);
	if(keyvars[1]==Cnil){
	V2= VV[42];
	}else{
	V2= keyvars[0];}
	}
	{volatile object V3;                      /*  .DISPLAY.       */
	volatile object V4;                       /*  .PENDING-COMMAND.*/
	volatile object V5;                       /*  .REPLY-BUFFER.  */
	V3= (V1);
	V4= Cnil;
	V5= Cnil;
	{ int V6; volatile bool unwinding = FALSE;
	if ((V6=frs_push(FRS_PROTECT,Cnil))) {
	V6--; unwinding = TRUE;} else {
	if((((V3))->in.in_slots[10])==Cnil){
	goto L3845;}
	(*LK0)(3,VV[16],VV[10],(V3))              /*  X-ERROR         */;
L3845:
	(*LK15)(1,(V3))                           /*  START-PENDING-COMMAND*/;
	V4= VALUES(0);
	{register object V7;                      /*  %BUFFER         */
	V7= (V3);
	if(!(((fix(((V7))->in.in_slots[6]))+(160))>=(fix(((V7))->in.in_slots[2])))){
	goto L3851;}
	(*LK7)(1,(V7))                            /*  BUFFER-FLUSH    */;
L3851:
	{register int V8;                         /*  BUFFER-BOFFSET  */
	object V9;                                /*  BUFFER-BBUF     */
	V8= fix(((V7))->in.in_slots[6]);
	V9= ((V7))->in.in_slots[7];
	((V3))->in.in_slots[4]= MAKE_FIXNUM(V8);
	(((V9))->ust.ust_self[(V8)+(0)]=(99));
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=1);
	((V3))->in.in_slots[6]= MAKE_FIXNUM((V8)+(4));
	(*LK13)(1,(V3))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V3))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V3))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V3),(V4))                      /*  READ-REPLY      */;
	V5= VALUES(0);
	{int V7;                                  /*  SIZE            */
	V7= fix(((V5))->in.in_slots[3]);
	{object V8;                               /*  %REPLY-BUFFER   */
	object V9;                                /*  %BUFFER         */
	{int V10;                                 /*  BUFFER-BOFFSET  */
	object V11;                               /*  BUFFER-BBUF     */
	V10= 0;
	V11= ((V5))->in.in_slots[1];
	{int V12= (V7)-(32);
	V6=(*LK54)(5,(V11),MAKE_FIXNUM(V12),MAKE_FIXNUM(((V11))->ust.ust_self[(V10)+(1)]),(V2),MAKE_FIXNUM(32))/*  READ-SEQUENCE-STRING*/;}
	}
	}
	}
	}
	frs_pop();
	MV_SAVE(V6);
	if(((V5))==Cnil){
	goto L3873;}
	(*LK20)(1,(V5))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L3873:
	if(((V4))==Cnil){
	goto L3872;}
	(*LK21)(2,(V3),(V4))                      /*  STOP-PENDING-COMMAND*/;
L3872:
	MV_RESTORE(V6);
	if (unwinding) unwind(nlj_fr,nlj_tag,V6+1);
	else {
	RETURN(V6);}}
	}
	}
}
/*	function definition for CHANGE-KEYBOARD-CONTROL               */
static L81(int narg, object V1, ...)
{ VT83 VLEX83 CLSR83
	{register object V2;
	register object V3;
	register object V4;
	register object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[16];
	parse_key(narg,args,8,L81keys,keyvars,OBJNULL,FALSE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	V7= keyvars[5];
	V8= keyvars[6];
	V9= keyvars[7];
	}
	if(!(((V2))==(VV[145]))){
	goto L3878;}
	V2= MAKE_FIXNUM(-1);
L3878:
	if(!(((V3))==(VV[145]))){
	goto L3882;}
	V3= MAKE_FIXNUM(-1);
L3882:
	if(!(((V4))==(VV[145]))){
	goto L3886;}
	V4= MAKE_FIXNUM(-1);
L3886:
	if(!(((V5))==(VV[145]))){
	goto L3890;}
	V5= MAKE_FIXNUM(-1);
L3890:
	{register object V10;                     /*  .DISPLAY.       */
	V10= (V1);
	if((((V10))->in.in_slots[10])==Cnil){
	goto L3894;}
	(*LK0)(3,VV[16],VV[10],(V10))             /*  X-ERROR         */;
L3894:
	{ int V11;
	{register object V12;                     /*  %BUFFER         */
	V12= (V10);
	if(!(((fix(((V12))->in.in_slots[6]))+(160))>=(fix(((V12))->in.in_slots[2])))){
	goto L3898;}
	(*LK7)(1,(V12))                           /*  BUFFER-FLUSH    */;
L3898:
	{register int V13;                        /*  BUFFER-BOFFSET  */
	register object V14;                      /*  BUFFER-BBUF     */
	V13= fix(((V12))->in.in_slots[6]);
	V14= ((V12))->in.in_slots[7];
	((V10))->in.in_slots[4]= MAKE_FIXNUM(V13);
	(((V14))->ust.ust_self[(V13)+(0)]=(102));
	{register object V15;                     /*  %MASK           */
	register object V16;                      /*  %INDEX          */
	V15= MAKE_FIXNUM(0);
	V16= MAKE_FIXNUM(4);
	if(((V2))==Cnil){
	goto L3908;}
	Llogior(2,(V15),MAKE_FIXNUM(1))           /*  LOGIOR          */;
	V15= VALUES(0);
	if(!(type_of((V2))==t_fixnum||type_of((V2))==t_bignum)){
	goto L3914;}
	V16= MAKE_FIXNUM((fix((V16)))+(4));
	VALUES(0) = (V16);
	((*(long *)(((V14))->ust.ust_self+((V13)+(fix(VALUES(0))))))=fix((V2)));
	goto L3908;
L3914:
	(*LK4)(2,(V2),VV[146])                    /*  X-TYPE-ERROR    */;
L3908:
	if(((V3))==Cnil){
	goto L3918;}
	Llogior(2,(V15),MAKE_FIXNUM(2))           /*  LOGIOR          */;
	V15= VALUES(0);
	if(!(type_of((V3))==t_fixnum||type_of((V3))==t_bignum)){
	goto L3924;}
	V16= MAKE_FIXNUM((fix((V16)))+(4));
	VALUES(0) = (V16);
	((*(long *)(((V14))->ust.ust_self+((V13)+(fix(VALUES(0))))))=fix((V3)));
	goto L3918;
L3924:
	(*LK4)(2,(V3),VV[146])                    /*  X-TYPE-ERROR    */;
L3918:
	if(((V4))==Cnil){
	goto L3928;}
	Llogior(2,(V15),MAKE_FIXNUM(4))           /*  LOGIOR          */;
	V15= VALUES(0);
	if(!(type_of((V4))==t_fixnum||type_of((V4))==t_bignum)){
	goto L3934;}
	V16= MAKE_FIXNUM((fix((V16)))+(4));
	VALUES(0) = (V16);
	((*(long *)(((V14))->ust.ust_self+((V13)+(fix(VALUES(0))))))=fix((V4)));
	goto L3928;
L3934:
	(*LK4)(2,(V4),VV[146])                    /*  X-TYPE-ERROR    */;
L3928:
	if(((V5))==Cnil){
	goto L3938;}
	Llogior(2,(V15),MAKE_FIXNUM(8))           /*  LOGIOR          */;
	V15= VALUES(0);
	if(!(type_of((V5))==t_fixnum||type_of((V5))==t_bignum)){
	goto L3944;}
	V16= MAKE_FIXNUM((fix((V16)))+(4));
	VALUES(0) = (V16);
	((*(long *)(((V14))->ust.ust_self+((V13)+(fix(VALUES(0))))))=fix((V5)));
	goto L3938;
L3944:
	(*LK4)(2,(V5),VV[146])                    /*  X-TYPE-ERROR    */;
L3938:
	if(((V6))==Cnil){
	goto L3948;}
	Llogior(2,(V15),MAKE_FIXNUM(16))          /*  LOGIOR          */;
	V15= VALUES(0);
	(*LK8)(2,(V6),VV[26])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3954;}
	V16= MAKE_FIXNUM((fix((V16)))+(4));
	VALUES(0) = (V16);
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(fix(VALUES(0))))))=fix((V6)));
	goto L3948;
L3954:
	(*LK4)(2,(V6),VV[26])                     /*  X-TYPE-ERROR    */;
L3948:
	if(((V7))==Cnil){
	goto L3958;}
	Llogior(2,(V15),MAKE_FIXNUM(32))          /*  LOGIOR          */;
	V15= VALUES(0);
	{int V17;
	VALUES(0) = (VV[305]->s.s_gfdef);
	(*LK10)(4,(V7),VV[147],VV[23],VALUES(0))  /*  POSITION        */;
	V17= fix(VALUES(0));
	if(MAKE_FIXNUM(V17)==Cnil){
	VALUES(0) = Cnil;
	goto L3964;}
	V16= MAKE_FIXNUM((fix((V16)))+(4));
	VALUES(0) = (V16);
	VALUES(0) = MAKE_FIXNUM(((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(fix(VALUES(0))))))=V17));
	}
L3964:
	if(VALUES(0)==Cnil)goto L3963;
	goto L3958;
L3963:
	(*LK4)(2,(V7),VV[148])                    /*  X-TYPE-ERROR    */;
L3958:
	if(((V8))==Cnil){
	goto L3969;}
	Llogior(2,(V15),MAKE_FIXNUM(64))          /*  LOGIOR          */;
	V15= VALUES(0);
	(*LK8)(2,(V8),VV[26])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L3975;}
	V16= MAKE_FIXNUM((fix((V16)))+(4));
	VALUES(0) = (V16);
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(fix(VALUES(0))))))=fix((V8)));
	goto L3969;
L3975:
	(*LK4)(2,(V8),VV[26])                     /*  X-TYPE-ERROR    */;
L3969:
	if(((V9))==Cnil){
	goto L3979;}
	Llogior(2,(V15),MAKE_FIXNUM(128))         /*  LOGIOR          */;
	V15= VALUES(0);
	{int V17;
	VALUES(0) = (VV[305]->s.s_gfdef);
	(*LK10)(4,(V9),VV[149],VV[23],VALUES(0))  /*  POSITION        */;
	V17= fix(VALUES(0));
	if(MAKE_FIXNUM(V17)==Cnil){
	VALUES(0) = Cnil;
	goto L3985;}
	V16= MAKE_FIXNUM((fix((V16)))+(4));
	VALUES(0) = (V16);
	VALUES(0) = MAKE_FIXNUM(((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(fix(VALUES(0))))))=V17));
	}
L3985:
	if(VALUES(0)==Cnil)goto L3984;
	goto L3979;
L3984:
	(*LK4)(2,(V9),VV[150])                    /*  X-TYPE-ERROR    */;
L3979:
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(4))))=fix((V15)));
	V16= MAKE_FIXNUM((fix((V16)))+(4));
	VALUES(0) = (V16);
	Lceiling(2,VALUES(0),MAKE_FIXNUM(4))      /*  CEILING         */;
	T0= VALUES(0);
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(2))))=fix(T0));
	{object V17;
	V17= number_plus(((V12))->in.in_slots[6],(V16));
	((V12))->in.in_slots[6]= (V17);
	}
	}
	V11=(*LK13)(1,(V10))                      /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V11);
	(*LK14)(1,(V10))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V11);
	RETURN(V11);}
	}
	}
}
/*	function definition for KEYBOARD-CONTROL                      */
static L82(int narg, object V1)
{ VT84 VLEX84 CLSR84
TTL:
	{volatile object V2;                      /*  .DISPLAY.       */
	volatile object V3;                       /*  .PENDING-COMMAND.*/
	volatile object V4;                       /*  .REPLY-BUFFER.  */
	V2= (V1);
	V3= Cnil;
	V4= Cnil;
	{ int V5; volatile bool unwinding = FALSE;
	if ((V5=frs_push(FRS_PROTECT,Cnil))) {
	V5--; unwinding = TRUE;} else {
	if((((V2))->in.in_slots[10])==Cnil){
	goto L3999;}
	(*LK0)(3,VV[16],VV[10],(V2))              /*  X-ERROR         */;
L3999:
	(*LK15)(1,(V2))                           /*  START-PENDING-COMMAND*/;
	V3= VALUES(0);
	{register object V6;                      /*  %BUFFER         */
	V6= (V2);
	if(!(((fix(((V6))->in.in_slots[6]))+(160))>=(fix(((V6))->in.in_slots[2])))){
	goto L4005;}
	(*LK7)(1,(V6))                            /*  BUFFER-FLUSH    */;
L4005:
	{register int V7;                         /*  BUFFER-BOFFSET  */
	object V8;                                /*  BUFFER-BBUF     */
	V7= fix(((V6))->in.in_slots[6]);
	V8= ((V6))->in.in_slots[7];
	((V2))->in.in_slots[4]= MAKE_FIXNUM(V7);
	(((V8))->ust.ust_self[(V7)+(0)]=(103));
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(2))))=1);
	((V2))->in.in_slots[6]= MAKE_FIXNUM((V7)+(4));
	(*LK13)(1,(V2))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V2))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V2))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V2),(V3))                      /*  READ-REPLY      */;
	V4= VALUES(0);
	{object V6;                               /*  %REPLY-BUFFER   */
	object V7;                                /*  %BUFFER         */
	{register int V8;                         /*  BUFFER-BOFFSET  */
	register object V9;                       /*  BUFFER-BBUF     */
	V8= 0;
	V9= ((V4))->in.in_slots[1];
	{int V10= ((V9))->ust.ust_self[(V8)+(12)];
	{int V11= ((V9))->ust.ust_self[(V8)+(13)];
	{int V12= (*(unsigned short *)(((V9))->ust.ust_self+((V8)+(14))));
	{int V13= (*(unsigned short *)(((V9))->ust.ust_self+((V8)+(16))));
	{int V14= (*(unsigned long *)(((V9))->ust.ust_self+((V8)+(8))));
	{int V15;
	V15= ((V9))->ust.ust_self[(V8)+(1)];
	if((V15)<(2)){
	goto L4027;}
	T0= Cnil;
	goto L4025;
L4027:
	T0= (VV[151])->v.v_self[V15];
	}
L4025:
	(*LK38)(3,(V9),MAKE_FIXNUM(32),Cnil)      /*  READ-BITVECTOR256*/;
	VALUES(6) = VALUES(0);
	VALUES(5) = T0;
	VALUES(4) = MAKE_FIXNUM(V14);
	VALUES(3) = MAKE_FIXNUM(V13);
	VALUES(2) = MAKE_FIXNUM(V12);
	VALUES(1) = MAKE_FIXNUM(V11);
	VALUES(0) = MAKE_FIXNUM(V10);
	V5=7;}}}}}
	}
	}
	}
	frs_pop();
	MV_SAVE(V5);
	if(((V4))==Cnil){
	goto L4031;}
	(*LK20)(1,(V4))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L4031:
	if(((V3))==Cnil){
	goto L4030;}
	(*LK21)(2,(V2),(V3))                      /*  STOP-PENDING-COMMAND*/;
L4030:
	MV_RESTORE(V5);
	if (unwinding) unwind(nlj_fr,nlj_tag,V5+1);
	else {
	RETURN(V5);}}
	}
}
/*	function definition for BELL                                  */
static L83(int narg, object V1, ...)
{ VT85 VLEX85 CLSR85
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if (i==narg) goto L4036;
	V2= va_arg(args, object);
	i++;
	goto L4037;
L4036:
	V2= MAKE_FIXNUM(0);
L4037:
	{register object V3;                      /*  .DISPLAY.       */
	V3= (V1);
	if((((V3))->in.in_slots[10])==Cnil){
	goto L4039;}
	(*LK0)(3,VV[16],VV[10],(V3))              /*  X-ERROR         */;
L4039:
	{ int V4;
	{register object V5;                      /*  %BUFFER         */
	V5= (V3);
	if(!(((fix(((V5))->in.in_slots[6]))+(160))>=(fix(((V5))->in.in_slots[2])))){
	goto L4043;}
	(*LK7)(1,(V5))                            /*  BUFFER-FLUSH    */;
L4043:
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= fix(((V5))->in.in_slots[6]);
	V7= ((V5))->in.in_slots[7];
	((V3))->in.in_slots[4]= MAKE_FIXNUM(V6);
	(((V7))->ust.ust_self[(V6)+(0)]=(104));
	{register int V8;                         /*  .VALUE.         */
	V8= (fix((V2)));
	(*LK8)(2,MAKE_FIXNUM(V8),VV[17])          /*  TYPEP           */;
	if(VALUES(0)!=Cnil){
	goto L4056;}
	VALUES(0) = Cnil;
	goto L4055;
L4056:
	VALUES(0) = MAKE_FIXNUM((((V7))->ust.ust_self[(V6)+(1)]=(V8)));
L4055:
	if(VALUES(0)==Cnil)goto L4054;
	goto L4052;
L4054:
	(*LK4)(2,MAKE_FIXNUM(V8),VV[18])          /*  X-TYPE-ERROR    */;
	}
L4052:
	((*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))))=1);
	((V3))->in.in_slots[6]= MAKE_FIXNUM((V6)+(4));
	V4=(*LK13)(1,(V3))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V4);
	(*LK14)(1,(V3))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V4);
	RETURN(V4);}
	}
	}
}
/*	function definition for POINTER-MAPPING                       */
static L84(int narg, object V1, ...)
{ VT86 VLEX86 CLSR86
	{volatile object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[2];
	parse_key(narg,args,1,L84keys,keyvars,OBJNULL,FALSE);
	if(keyvars[1]==Cnil){
	V2= VV[42];
	}else{
	V2= keyvars[0];}
	}
	{volatile object V3;                      /*  .DISPLAY.       */
	volatile object V4;                       /*  .PENDING-COMMAND.*/
	volatile object V5;                       /*  .REPLY-BUFFER.  */
	V3= (V1);
	V4= Cnil;
	V5= Cnil;
	{ int V6; volatile bool unwinding = FALSE;
	if ((V6=frs_push(FRS_PROTECT,Cnil))) {
	V6--; unwinding = TRUE;} else {
	if((((V3))->in.in_slots[10])==Cnil){
	goto L4064;}
	(*LK0)(3,VV[16],VV[10],(V3))              /*  X-ERROR         */;
L4064:
	(*LK15)(1,(V3))                           /*  START-PENDING-COMMAND*/;
	V4= VALUES(0);
	{register object V7;                      /*  %BUFFER         */
	V7= (V3);
	if(!(((fix(((V7))->in.in_slots[6]))+(160))>=(fix(((V7))->in.in_slots[2])))){
	goto L4070;}
	(*LK7)(1,(V7))                            /*  BUFFER-FLUSH    */;
L4070:
	{register int V8;                         /*  BUFFER-BOFFSET  */
	object V9;                                /*  BUFFER-BBUF     */
	V8= fix(((V7))->in.in_slots[6]);
	V9= ((V7))->in.in_slots[7];
	((V3))->in.in_slots[4]= MAKE_FIXNUM(V8);
	(((V9))->ust.ust_self[(V8)+(0)]=(117));
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=1);
	((V3))->in.in_slots[6]= MAKE_FIXNUM((V8)+(4));
	(*LK13)(1,(V3))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V3))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V3))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V3),(V4))                      /*  READ-REPLY      */;
	V5= VALUES(0);
	{object V7;                               /*  %REPLY-BUFFER   */
	object V8;                                /*  %BUFFER         */
	{int V9;                                  /*  BUFFER-BOFFSET  */
	object V10;                               /*  BUFFER-BBUF     */
	V9= 0;
	V10= ((V5))->in.in_slots[1];
	V6=(*LK31)(7,(V5),(V2),MAKE_FIXNUM(((V10))->ust.ust_self[(V9)+(1)]),Cnil,Cnil,MAKE_FIXNUM(0),MAKE_FIXNUM(32))/*  READ-SEQUENCE-CARD8*/;
	}
	}
	}
	frs_pop();
	MV_SAVE(V6);
	if(((V5))==Cnil){
	goto L4091;}
	(*LK20)(1,(V5))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L4091:
	if(((V4))==Cnil){
	goto L4090;}
	(*LK21)(2,(V3),(V4))                      /*  STOP-PENDING-COMMAND*/;
L4090:
	MV_RESTORE(V6);
	if (unwinding) unwind(nlj_fr,nlj_tag,V6+1);
	else {
	RETURN(V6);}}
	}
	}
}
/*	function definition for SET-POINTER-MAPPING                   */
static L85(int narg, object V1, object V2)
{ VT87 VLEX87 CLSR87
TTL:
	{volatile object V3;                      /*  .DISPLAY.       */
	volatile object V4;                       /*  .PENDING-COMMAND.*/
	volatile object V5;                       /*  .REPLY-BUFFER.  */
	V3= (V1);
	V4= Cnil;
	V5= Cnil;
	{ int V6; volatile bool unwinding = FALSE;
	if ((V6=frs_push(FRS_PROTECT,Cnil))) {
	V6--; unwinding = TRUE;} else {
	if((((V3))->in.in_slots[10])==Cnil){
	goto L4101;}
	(*LK0)(3,VV[16],VV[10],(V3))              /*  X-ERROR         */;
L4101:
	(*LK15)(1,(V3))                           /*  START-PENDING-COMMAND*/;
	V4= VALUES(0);
	{register object V7;                      /*  %BUFFER         */
	V7= (V3);
	if(!(((fix(((V7))->in.in_slots[6]))+(160))>=(fix(((V7))->in.in_slots[2])))){
	goto L4107;}
	(*LK7)(1,(V7))                            /*  BUFFER-FLUSH    */;
L4107:
	{register int V8;                         /*  BUFFER-BOFFSET  */
	register object V9;                       /*  BUFFER-BBUF     */
	V8= fix(((V7))->in.in_slots[6]);
	V9= ((V7))->in.in_slots[7];
	((V3))->in.in_slots[4]= MAKE_FIXNUM(V8);
	(((V9))->ust.ust_self[(V8)+(0)]=(116));
	{register int V10;                        /*  .VALUE.         */
	V10= length((V2));
	(*LK8)(2,MAKE_FIXNUM(V10),VV[17])         /*  TYPEP           */;
	if(VALUES(0)!=Cnil){
	goto L4120;}
	VALUES(0) = Cnil;
	goto L4119;
L4120:
	VALUES(0) = MAKE_FIXNUM((((V9))->ust.ust_self[(V8)+(1)]=(V10)));
L4119:
	if(VALUES(0)==Cnil)goto L4118;
	goto L4116;
L4118:
	(*LK4)(2,MAKE_FIXNUM(V10),VV[18])         /*  X-TYPE-ERROR    */;
	}
L4116:
	(*LK8)(2,(V2),VV[55])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L4124;}
	{int V10;
	V10= length((V2));
	Lceiling(2,MAKE_FIXNUM((V10)-(0)),MAKE_FIXNUM(4))/*  CEILING  */;
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=(fix(VALUES(0)))+(1));
	(*LK28)(6,(V7),MAKE_FIXNUM((V8)+(4)),(V2),MAKE_FIXNUM(0),MAKE_FIXNUM(V10),Cnil)/*  WRITE-SEQUENCE-CARD8*/;
	goto L4122;
	}
L4124:
	(*LK4)(2,(V2),VV[152])                    /*  X-TYPE-ERROR    */;
L4122:
	(*LK13)(1,(V3))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V3))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V3))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V3),(V4))                      /*  READ-REPLY      */;
	V5= VALUES(0);
	{object V7;                               /*  %REPLY-BUFFER   */
	object V8;                                /*  %BUFFER         */
	{int V9;                                  /*  BUFFER-BOFFSET  */
	object V10;                               /*  BUFFER-BBUF     */
	V9= 0;
	V10= ((V5))->in.in_slots[1];
	VALUES(0)=((((V10))->ust.ust_self[(V9)+(1)])>0?Ct:Cnil);
	V6=1;
	}
	}
	}
	frs_pop();
	MV_SAVE(V6);
	if(((V5))==Cnil){
	goto L4139;}
	(*LK20)(1,(V5))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L4139:
	if(((V4))==Cnil){
	goto L4138;}
	(*LK21)(2,(V3),(V4))                      /*  STOP-PENDING-COMMAND*/;
L4138:
	MV_RESTORE(V6);
	if (unwinding) unwind(nlj_fr,nlj_tag,V6+1);
	else {
	if((VALUES(0))==Cnil){
	goto L4096;}}}
	}
	(*LK0)(3,VV[153],VV[10],(V1))             /*  X-ERROR         */;
L4096:
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for CHANGE-POINTER-CONTROL                */
static L86(int narg, object V1, ...)
{ VT88 VLEX88 CLSR88
	{volatile object V2;
	volatile object V3;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[4];
	parse_key(narg,args,2,L86keys,keyvars,OBJNULL,FALSE);
	V2= keyvars[0];
	V3= keyvars[1];
	}
	{register int V4;                         /*  ACCELERATION-P  */
	register int V5;                          /*  THRESHOLD-P     */
	register int V6;                          /*  NUMERATOR       */
	register int V7;                          /*  DENOMINATOR     */
	V4= 1;
	V5= 1;
	V6= 0;
	V7= 1;
	if(!(((V2))==(VV[145]))){
	goto L4150;}
	V6= -1;
	goto L4148;
L4150:
	if(((V2))==Cnil){
	goto L4154;}
	{ int V8;
	V8=LC87(1,(V2))                           /*  RATIONALIZE16   */;
	if (V8>0) {
	V6= fix(VALUES(0));
	V8--;
	} else {
	V6= fix(Cnil);}
	if (V8>0) {
	V7= fix(VALUES(1));
	} else {
	V7= fix(Cnil);}
	
	goto L4148;
	}
L4154:
	V4= 0;
L4148:
	if(!(((V3))==(VV[145]))){
	goto L4160;}
	V3= MAKE_FIXNUM(-1);
	goto L4158;
L4160:
	if(((V3))!=Cnil){
	goto L4158;}
	V3= MAKE_FIXNUM(-1);
	V5= 0;
L4158:
	{register object V8;                      /*  .DISPLAY.       */
	V8= (V1);
	if((((V8))->in.in_slots[10])==Cnil){
	goto L4168;}
	(*LK0)(3,VV[16],VV[10],(V8))              /*  X-ERROR         */;
L4168:
	{ int V9;
	{object V10;                              /*  %BUFFER         */
	V10= (V8);
	if(!(((fix(((V10))->in.in_slots[6]))+(160))>=(fix(((V10))->in.in_slots[2])))){
	goto L4172;}
	(*LK7)(1,(V10))                           /*  BUFFER-FLUSH    */;
L4172:
	{register int V11;                        /*  BUFFER-BOFFSET  */
	register object V12;                      /*  BUFFER-BBUF     */
	V11= fix(((V10))->in.in_slots[6]);
	V12= ((V10))->in.in_slots[7];
	((V8))->in.in_slots[4]= MAKE_FIXNUM(V11);
	(((V12))->ust.ust_self[(V11)+(0)]=(105));
	(*LK8)(2,MAKE_FIXNUM(V6),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L4183;}
	((*(short *)(((V12))->st.st_self+((V11)+(4))))=V6);
	goto L4181;
L4183:
	(*LK4)(2,MAKE_FIXNUM(V6),VV[20])          /*  X-TYPE-ERROR    */;
L4181:
	(*LK8)(2,MAKE_FIXNUM(V7),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L4187;}
	((*(short *)(((V12))->st.st_self+((V11)+(6))))=V7);
	goto L4185;
L4187:
	(*LK4)(2,MAKE_FIXNUM(V7),VV[20])          /*  X-TYPE-ERROR    */;
L4185:
	(*LK8)(2,(V3),VV[20])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L4191;}
	((*(short *)(((V12))->st.st_self+((V11)+(8))))=fix((V3)));
	goto L4189;
L4191:
	(*LK4)(2,(V3),VV[20])                     /*  X-TYPE-ERROR    */;
L4189:
	(*LK8)(2,MAKE_FIXNUM(V4),VV[17])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L4195;}
	(((V12))->ust.ust_self[(V11)+(10)]=(V4));
	goto L4193;
L4195:
	(*LK4)(2,MAKE_FIXNUM(V4),VV[17])          /*  X-TYPE-ERROR    */;
L4193:
	(*LK8)(2,MAKE_FIXNUM(V5),VV[17])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L4199;}
	(((V12))->ust.ust_self[(V11)+(11)]=(V5));
	goto L4197;
L4199:
	(*LK4)(2,MAKE_FIXNUM(V5),VV[17])          /*  X-TYPE-ERROR    */;
L4197:
	((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(2))))=3);
	((V8))->in.in_slots[6]= MAKE_FIXNUM((V11)+(12));
	V9=(*LK13)(1,(V8))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V9);
	(*LK14)(1,(V8))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V9);
	RETURN(V9);}
	}
	}
	}
}
/*	local function RATIONALIZE16                                  */
static LC87(int narg, object V1)
{ VT89 VLEX89 CLSR89
TTL:
	{volatile object V2;                      /*  RATIONAL        */
	volatile object V3;                       /*  NUMERATOR       */
	volatile object V4;                       /*  DENOMINATOR     */
	(*LK55)(1,(V1))                           /*  RATIONALIZE     */;
	V2= VALUES(0);
	Lnumerator(1,(V2))                        /*  NUMERATOR       */;
	V3= VALUES(0);
	Ldenominator(1,(V2))                      /*  DENOMINATOR     */;
	V4= VALUES(0);
L4208:
	if(number_compare((V3),MAKE_FIXNUM(1))==0){
	goto L4210;}
	(*LK56)(1,(V3))                           /*  ABS             */;
	if(!(number_compare(VALUES(0),MAKE_FIXNUM(32768))<0)){
	goto L4209;}
	if(!(number_compare((V4),MAKE_FIXNUM(32768))<0)){
	goto L4209;}
L4210:
	VALUES(1) = (number_compare((V4),MAKE_FIXNUM(32767))<=0?(V4):MAKE_FIXNUM(32767));
	VALUES(0) = (V3);
	RETURN(2);
L4209:
	Lash(2,(V3),MAKE_FIXNUM(-1))              /*  SHIFT>>         */;
	V3= VALUES(0);
	Lash(2,(V4),MAKE_FIXNUM(-1))              /*  SHIFT>>         */;
	V4= VALUES(0);
	goto L4208;
	}
}
/*	function definition for POINTER-CONTROL                       */
static L88(int narg, object V1)
{ VT90 VLEX90 CLSR90
TTL:
	{volatile object V2;                      /*  .DISPLAY.       */
	volatile object V3;                       /*  .PENDING-COMMAND.*/
	volatile object V4;                       /*  .REPLY-BUFFER.  */
	V2= (V1);
	V3= Cnil;
	V4= Cnil;
	{ int V5; volatile bool unwinding = FALSE;
	if ((V5=frs_push(FRS_PROTECT,Cnil))) {
	V5--; unwinding = TRUE;} else {
	if((((V2))->in.in_slots[10])==Cnil){
	goto L4224;}
	(*LK0)(3,VV[16],VV[10],(V2))              /*  X-ERROR         */;
L4224:
	(*LK15)(1,(V2))                           /*  START-PENDING-COMMAND*/;
	V3= VALUES(0);
	{register object V6;                      /*  %BUFFER         */
	V6= (V2);
	if(!(((fix(((V6))->in.in_slots[6]))+(160))>=(fix(((V6))->in.in_slots[2])))){
	goto L4230;}
	(*LK7)(1,(V6))                            /*  BUFFER-FLUSH    */;
L4230:
	{register int V7;                         /*  BUFFER-BOFFSET  */
	object V8;                                /*  BUFFER-BBUF     */
	V7= fix(((V6))->in.in_slots[6]);
	V8= ((V6))->in.in_slots[7];
	((V2))->in.in_slots[4]= MAKE_FIXNUM(V7);
	(((V8))->ust.ust_self[(V7)+(0)]=(106));
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(2))))=1);
	((V2))->in.in_slots[6]= MAKE_FIXNUM((V7)+(4));
	(*LK13)(1,(V2))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V2))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V2))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V2),(V3))                      /*  READ-REPLY      */;
	V4= VALUES(0);
	{object V6;                               /*  %REPLY-BUFFER   */
	object V7;                                /*  %BUFFER         */
	{register int V8;                         /*  BUFFER-BOFFSET  */
	register object V9;                       /*  BUFFER-BBUF     */
	V8= 0;
	V9= ((V4))->in.in_slots[1];
	{int V10= (*(unsigned short *)(((V9))->ust.ust_self+((V8)+(8))));
	{int V11= (*(unsigned short *)(((V9))->ust.ust_self+((V8)+(10))));
	V5=Ldivide(3,MAKE_FIXNUM(V10),MAKE_FIXNUM(V11),MAKE_FIXNUM((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(12))))))/*  /*/;}}
	}
	}
	}
	frs_pop();
	MV_SAVE(V5);
	if(((V4))==Cnil){
	goto L4251;}
	(*LK20)(1,(V4))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L4251:
	if(((V3))==Cnil){
	goto L4250;}
	(*LK21)(2,(V2),(V3))                      /*  STOP-PENDING-COMMAND*/;
L4250:
	MV_RESTORE(V5);
	if (unwinding) unwind(nlj_fr,nlj_tag,V5+1);
	else {
	RETURN(V5);}}
	}
}
/*	function definition for SET-SCREEN-SAVER                      */
static L89(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT91 VLEX91 CLSR91
TTL:
	if(((V4)!= VV[477]))goto L4257;
	V4= VV[156];
	goto L4256;
L4257:
	if(((V4)!= VV[478]))goto L4259;
	V4= VV[157];
	goto L4256;
L4259:
L4256:
	if(((V5)!= VV[477]))goto L4262;
	V5= VV[156];
	goto L4261;
L4262:
	if(((V5)!= VV[478]))goto L4264;
	V5= VV[157];
	goto L4261;
L4264:
L4261:
	if(!(((V2))==(VV[145]))){
	goto L4266;}
	V2= MAKE_FIXNUM(-1);
L4266:
	if(!(((V3))==(VV[145]))){
	goto L4270;}
	V3= MAKE_FIXNUM(-1);
L4270:
	{register object V6;                      /*  .DISPLAY.       */
	V6= (V1);
	if((((V6))->in.in_slots[10])==Cnil){
	goto L4274;}
	(*LK0)(3,VV[16],VV[10],(V6))              /*  X-ERROR         */;
L4274:
	{ int V7;
	{register object V8;                      /*  %BUFFER         */
	V8= (V6);
	if(!(((fix(((V8))->in.in_slots[6]))+(160))>=(fix(((V8))->in.in_slots[2])))){
	goto L4278;}
	(*LK7)(1,(V8))                            /*  BUFFER-FLUSH    */;
L4278:
	{register int V9;                         /*  BUFFER-BOFFSET  */
	register object V10;                      /*  BUFFER-BBUF     */
	V9= fix(((V8))->in.in_slots[6]);
	V10= ((V8))->in.in_slots[7];
	((V6))->in.in_slots[4]= MAKE_FIXNUM(V9);
	(((V10))->ust.ust_self[(V9)+(0)]=(107));
	(*LK8)(2,(V2),VV[20])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L4289;}
	((*(short *)(((V10))->st.st_self+((V9)+(4))))=fix((V2)));
	goto L4287;
L4289:
	(*LK4)(2,(V2),VV[20])                     /*  X-TYPE-ERROR    */;
L4287:
	(*LK8)(2,(V3),VV[20])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L4293;}
	((*(short *)(((V10))->st.st_self+((V9)+(6))))=fix((V3)));
	goto L4291;
L4293:
	(*LK4)(2,(V3),VV[20])                     /*  X-TYPE-ERROR    */;
L4291:
	{int V11;
	VALUES(0) = (VV[305]->s.s_gfdef);
	(*LK10)(4,(V4),VV[158],VV[23],VALUES(0))  /*  POSITION        */;
	V11= fix(VALUES(0));
	if(MAKE_FIXNUM(V11)==Cnil){
	VALUES(0) = Cnil;
	goto L4297;}
	VALUES(0) = MAKE_FIXNUM((((V10))->ust.ust_self[(V9)+(8)]=(V11)));
	}
L4297:
	if(VALUES(0)==Cnil)goto L4296;
	goto L4295;
L4296:
	(*LK4)(2,(V4),VV[159])                    /*  X-TYPE-ERROR    */;
L4295:
	{int V11;
	VALUES(0) = (VV[305]->s.s_gfdef);
	(*LK10)(4,(V5),VV[160],VV[23],VALUES(0))  /*  POSITION        */;
	V11= fix(VALUES(0));
	if(MAKE_FIXNUM(V11)==Cnil){
	VALUES(0) = Cnil;
	goto L4302;}
	VALUES(0) = MAKE_FIXNUM((((V10))->ust.ust_self[(V9)+(9)]=(V11)));
	}
L4302:
	if(VALUES(0)==Cnil)goto L4301;
	goto L4300;
L4301:
	(*LK4)(2,(V5),VV[161])                    /*  X-TYPE-ERROR    */;
L4300:
	((*(unsigned short *)(((V10))->ust.ust_self+((V9)+(2))))=3);
	((V6))->in.in_slots[6]= MAKE_FIXNUM((V9)+(12));
	V7=(*LK13)(1,(V6))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V7);
	(*LK14)(1,(V6))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V7);
	RETURN(V7);}
	}
}
/*	function definition for SCREEN-SAVER                          */
static L90(int narg, object V1)
{ VT92 VLEX92 CLSR92
TTL:
	{volatile object V2;                      /*  .DISPLAY.       */
	volatile object V3;                       /*  .PENDING-COMMAND.*/
	volatile object V4;                       /*  .REPLY-BUFFER.  */
	V2= (V1);
	V3= Cnil;
	V4= Cnil;
	{ int V5; volatile bool unwinding = FALSE;
	if ((V5=frs_push(FRS_PROTECT,Cnil))) {
	V5--; unwinding = TRUE;} else {
	if((((V2))->in.in_slots[10])==Cnil){
	goto L4310;}
	(*LK0)(3,VV[16],VV[10],(V2))              /*  X-ERROR         */;
L4310:
	(*LK15)(1,(V2))                           /*  START-PENDING-COMMAND*/;
	V3= VALUES(0);
	{register object V6;                      /*  %BUFFER         */
	V6= (V2);
	if(!(((fix(((V6))->in.in_slots[6]))+(160))>=(fix(((V6))->in.in_slots[2])))){
	goto L4316;}
	(*LK7)(1,(V6))                            /*  BUFFER-FLUSH    */;
L4316:
	{register int V7;                         /*  BUFFER-BOFFSET  */
	object V8;                                /*  BUFFER-BBUF     */
	V7= fix(((V6))->in.in_slots[6]);
	V8= ((V6))->in.in_slots[7];
	((V2))->in.in_slots[4]= MAKE_FIXNUM(V7);
	(((V8))->ust.ust_self[(V7)+(0)]=(108));
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(2))))=1);
	((V2))->in.in_slots[6]= MAKE_FIXNUM((V7)+(4));
	(*LK13)(1,(V2))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V2))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V2))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V2),(V3))                      /*  READ-REPLY      */;
	V4= VALUES(0);
	{object V6;                               /*  %REPLY-BUFFER   */
	object V7;                                /*  %BUFFER         */
	{register int V8;                         /*  BUFFER-BOFFSET  */
	register object V9;                       /*  BUFFER-BBUF     */
	V8= 0;
	V9= ((V4))->in.in_slots[1];
	{int V10= (*(unsigned short *)(((V9))->ust.ust_self+((V8)+(8))));
	{int V11= (*(unsigned short *)(((V9))->ust.ust_self+((V8)+(10))));
	{int V12;
	V12= ((V9))->ust.ust_self[(V8)+(12)];
	if((V12)<(3)){
	goto L4338;}
	T0= Cnil;
	goto L4336;
L4338:
	T0= (VV[162])->v.v_self[V12];
	}
L4336:
	{int V12;
	V12= ((V9))->ust.ust_self[(V8)+(13)];
	if((V12)<(3)){
	goto L4342;}
	VALUES(0) = Cnil;
	goto L4340;
L4342:
	VALUES(0) = (VV[163])->v.v_self[V12];
	}
L4340:
	VALUES(3) = VALUES(0);
	VALUES(2) = T0;
	VALUES(1) = MAKE_FIXNUM(V11);
	VALUES(0) = MAKE_FIXNUM(V10);
	V5=4;}}
	}
	}
	}
	frs_pop();
	MV_SAVE(V5);
	if(((V4))==Cnil){
	goto L4345;}
	(*LK20)(1,(V4))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L4345:
	if(((V3))==Cnil){
	goto L4344;}
	(*LK21)(2,(V2),(V3))                      /*  STOP-PENDING-COMMAND*/;
L4344:
	MV_RESTORE(V5);
	if (unwinding) unwind(nlj_fr,nlj_tag,V5+1);
	else {
	RETURN(V5);}}
	}
}
/*	function definition for ACTIVATE-SCREEN-SAVER                 */
static L91(int narg, object V1)
{ VT93 VLEX93 CLSR93
TTL:
	{register object V2;                      /*  .DISPLAY.       */
	V2= (V1);
	if((((V2))->in.in_slots[10])==Cnil){
	goto L4350;}
	(*LK0)(3,VV[16],VV[10],(V2))              /*  X-ERROR         */;
L4350:
	{ int V3;
	{register object V4;                      /*  %BUFFER         */
	V4= (V2);
	if(!(((fix(((V4))->in.in_slots[6]))+(160))>=(fix(((V4))->in.in_slots[2])))){
	goto L4354;}
	(*LK7)(1,(V4))                            /*  BUFFER-FLUSH    */;
L4354:
	{register int V5;                         /*  BUFFER-BOFFSET  */
	register object V6;                       /*  BUFFER-BBUF     */
	V5= fix(((V4))->in.in_slots[6]);
	V6= ((V4))->in.in_slots[7];
	((V2))->in.in_slots[4]= MAKE_FIXNUM(V5);
	(((V6))->ust.ust_self[(V5)+(0)]=(115));
	(((V6))->ust.ust_self[(V5)+(1)]=(1));
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(2))))=1);
	((V2))->in.in_slots[6]= MAKE_FIXNUM((V5)+(4));
	V3=(*LK13)(1,(V2))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V3);
	(*LK14)(1,(V2))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V3);
	RETURN(V3);}
	}
}
/*	function definition for RESET-SCREEN-SAVER                    */
static L92(int narg, object V1)
{ VT94 VLEX94 CLSR94
TTL:
	{register object V2;                      /*  .DISPLAY.       */
	V2= (V1);
	if((((V2))->in.in_slots[10])==Cnil){
	goto L4367;}
	(*LK0)(3,VV[16],VV[10],(V2))              /*  X-ERROR         */;
L4367:
	{ int V3;
	{register object V4;                      /*  %BUFFER         */
	V4= (V2);
	if(!(((fix(((V4))->in.in_slots[6]))+(160))>=(fix(((V4))->in.in_slots[2])))){
	goto L4371;}
	(*LK7)(1,(V4))                            /*  BUFFER-FLUSH    */;
L4371:
	{register int V5;                         /*  BUFFER-BOFFSET  */
	register object V6;                       /*  BUFFER-BBUF     */
	V5= fix(((V4))->in.in_slots[6]);
	V6= ((V4))->in.in_slots[7];
	((V2))->in.in_slots[4]= MAKE_FIXNUM(V5);
	(((V6))->ust.ust_self[(V5)+(0)]=(115));
	(((V6))->ust.ust_self[(V5)+(1)]=(0));
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(2))))=1);
	((V2))->in.in_slots[6]= MAKE_FIXNUM((V5)+(4));
	V3=(*LK13)(1,(V2))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V3);
	(*LK14)(1,(V2))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V3);
	RETURN(V3);}
	}
}
/*	function definition for ADD-ACCESS-HOST                       */
static L93(int narg, object V1, object V2, ...)
{ VT95 VLEX95 CLSR95
	{int i=2;
	object V3;
	va_list args; va_start(args, V2);
	if (i==narg) goto L4384;
	V3= va_arg(args, object);
	i++;
	goto L4385;
L4384:
	V3= VV[164];
L4385:
	RETURN(L95(4,(V1),(V2),(V3),Cnil)         /*  CHANGE-ACCESS-HOST*/);
	}
}
/*	function definition for REMOVE-ACCESS-HOST                    */
static L94(int narg, object V1, object V2, ...)
{ VT96 VLEX96 CLSR96
	{int i=2;
	object V3;
	va_list args; va_start(args, V2);
	if (i==narg) goto L4387;
	V3= va_arg(args, object);
	i++;
	goto L4388;
L4387:
	V3= VV[164];
L4388:
	RETURN(L95(4,(V1),(V2),(V3),Ct)           /*  CHANGE-ACCESS-HOST*/);
	}
}
/*	function definition for CHANGE-ACCESS-HOST                    */
static L95(int narg, object V1, object V2, object V3, object V4)
{ VT97 VLEX97 CLSR97
TTL:
	if(type_of((V2))==t_cons){
	goto L4390;}
	(*LK57)(2,(V2),(V3))                      /*  HOST-ADDRESS    */;
	V2= VALUES(0);
L4390:
	{register object V5;                      /*  FAMILY          */
	register object V6;                       /*  ADDRESS         */
	V5= CAR((V2));
	V6= CDR((V2));
	{register object V7;                      /*  .DISPLAY.       */
	V7= (V1);
	if((((V7))->in.in_slots[10])==Cnil){
	goto L4396;}
	(*LK0)(3,VV[16],VV[10],(V7))              /*  X-ERROR         */;
L4396:
	{ int V8;
	{register object V9;                      /*  %BUFFER         */
	V9= (V7);
	if(!(((fix(((V9))->in.in_slots[6]))+(160))>=(fix(((V9))->in.in_slots[2])))){
	goto L4400;}
	(*LK7)(1,(V9))                            /*  BUFFER-FLUSH    */;
L4400:
	{register int V10;                        /*  BUFFER-BOFFSET  */
	register object V11;                      /*  BUFFER-BBUF     */
	V10= fix(((V9))->in.in_slots[6]);
	V11= ((V9))->in.in_slots[7];
	((V7))->in.in_slots[4]= MAKE_FIXNUM(V10);
	(((V11))->ust.ust_self[(V10)+(0)]=(109));
	if(((V4))==Cnil){
	goto L4414;}
	T0= MAKE_FIXNUM(1);
	goto L4412;
L4414:
	T0= MAKE_FIXNUM(0);
L4412:
	VALUES(0) = MAKE_FIXNUM((((V11))->ust.ust_self[(V10)+(1)]=(fix(T0))));
	if(VALUES(0)==Cnil)goto L4410;
	goto L4409;
L4410:
	(*LK4)(2,(V4),VV[165])                    /*  X-TYPE-ERROR    */;
L4409:
	{object V12;                              /*  .VALUE.         */
	if(!((V5)==Cnil)){
	goto L4419;}
	V12= MAKE_FIXNUM(0);
	goto L4417;
L4419:
	{object V13;
	{int V14;
	VALUES(0) = (VV[305]->s.s_gfdef);
	(*LK10)(4,(V5),VV[166],VV[23],VALUES(0))  /*  POSITION        */;
	V14= fix(VALUES(0));
	if(MAKE_FIXNUM(V14)==Cnil){
	V13= Cnil;
	goto L4421;}
	V13= MAKE_FIXNUM(V14);
	}
L4421:
	if(((V13))==Cnil){
	goto L4425;}
	V12= (V13);
	goto L4417;
L4425:
	(*LK8)(2,(V5),VV[26])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L4428;}
	V12= (V5);
	goto L4417;
L4428:
	(*LK4)(2,(V5),VV[167])                    /*  X-TYPE-ERROR    */;
	V12= VALUES(0);
	}
L4417:
	(*LK8)(2,(V12),VV[17])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L4431;}
	(((V11))->ust.ust_self[(V10)+(4)]=(fix((V12))));
	goto L4416;
L4431:
	(*LK4)(2,(V12),VV[17])                    /*  X-TYPE-ERROR    */;
	}
L4416:
	{register int V12;                        /*  .VALUE.         */
	V12= length((V6));
	(*LK8)(2,MAKE_FIXNUM(V12),VV[21])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L4436;}
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(6))))=V12);
	goto L4433;
L4436:
	(*LK4)(2,MAKE_FIXNUM(V12),VV[21])         /*  X-TYPE-ERROR    */;
	}
L4433:
	(*LK8)(2,(V6),VV[55])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L4440;}
	{int V12;
	V12= length((V6));
	Lceiling(2,MAKE_FIXNUM((V12)-(0)),MAKE_FIXNUM(4))/*  CEILING  */;
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(2))))=(fix(VALUES(0)))+(2));
	(*LK28)(6,(V9),MAKE_FIXNUM((V10)+(8)),(V6),MAKE_FIXNUM(0),MAKE_FIXNUM(V12),Cnil)/*  WRITE-SEQUENCE-CARD8*/;
	goto L4438;
	}
L4440:
	(*LK4)(2,(V6),VV[168])                    /*  X-TYPE-ERROR    */;
L4438:
	V8=(*LK13)(1,(V7))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V8);
	(*LK14)(1,(V7))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V8);
	RETURN(V8);}
	}
	}
}
/*	function definition for ACCESS-HOSTS                          */
static L96(int narg, object V1, ...)
{ VT98 VLEX98 CLSR98
	{int i=1;
	volatile object V2;
	va_list args; va_start(args, V1);
	if (i==narg) goto L4446;
	V2= va_arg(args, object);
	i++;
	goto L4447;
L4446:
	V2= VV[42];
L4447:
	{volatile object V3;                      /*  .DISPLAY.       */
	volatile object V4;                       /*  .PENDING-COMMAND.*/
	volatile object V5;                       /*  .REPLY-BUFFER.  */
	V3= (V1);
	V4= Cnil;
	V5= Cnil;
	{ int V6; volatile bool unwinding = FALSE;
	if ((V6=frs_push(FRS_PROTECT,Cnil))) {
	V6--; unwinding = TRUE;} else {
	if((((V3))->in.in_slots[10])==Cnil){
	goto L4451;}
	(*LK0)(3,VV[16],VV[10],(V3))              /*  X-ERROR         */;
L4451:
	(*LK15)(1,(V3))                           /*  START-PENDING-COMMAND*/;
	V4= VALUES(0);
	{object V7;                               /*  %BUFFER         */
	V7= (V3);
	if(!(((fix(((V7))->in.in_slots[6]))+(160))>=(fix(((V7))->in.in_slots[2])))){
	goto L4457;}
	(*LK7)(1,(V7))                            /*  BUFFER-FLUSH    */;
L4457:
	{register int V8;                         /*  BUFFER-BOFFSET  */
	object V9;                                /*  BUFFER-BBUF     */
	V8= fix(((V7))->in.in_slots[6]);
	V9= ((V7))->in.in_slots[7];
	((V3))->in.in_slots[4]= MAKE_FIXNUM(V8);
	(((V9))->ust.ust_self[(V8)+(0)]=(110));
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=1);
	((V3))->in.in_slots[6]= MAKE_FIXNUM((V8)+(4));
	(*LK13)(1,(V3))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V3))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V3))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V3),(V4))                      /*  READ-REPLY      */;
	V5= VALUES(0);
	{volatile object V7;                      /*  %REPLY-BUFFER   */
	volatile object V8;                       /*  %BUFFER         */
	V7= (V5);
	{volatile int V9;                         /*  BUFFER-BOFFSET  */
	volatile object V10;                      /*  BUFFER-BBUF     */
	V9= 0;
	V10= ((V7))->in.in_slots[1];
	{volatile object V11;                     /*  ENABLED-P       */
	volatile int V12;                         /*  NHOSTS          */
	volatile object V13;                      /*  SEQUENCE        */
	V11= ((((V10))->ust.ust_self[(V9)+(1)])>0?Ct:Cnil);
	V12= (*(unsigned short *)(((V10))->ust.ust_self+((V9)+(8))));
	(*LK51)(2,(V2),MAKE_FIXNUM(V12))          /*  MAKE-SEQUENCE   */;
	V13= VALUES(0);
	{int V14;                                 /*  .BOFFSET.       */
	V14= (V9)+(32);
	V9= V14;
	}
	{volatile object V14;
	volatile int V15;                         /*  I               */
	V14= MAKE_FIXNUM(V12);
	V15= 0;
L4487:
	if(!(number_compare(MAKE_FIXNUM(V15),(V14))>=0)){
	goto L4488;}
	goto L4483;
L4488:
	{register int V17;                        /*  FAMILY          */
	register int V18;                         /*  LEN             */
	V17= ((V10))->ust.ust_self[(V9)+(0)];
	V18= (*(unsigned short *)(((V10))->ust.ust_self+((V9)+(2))));
	if(!((V17)<(3))){
	goto L4497;}
	T0= (VV[169])->v.v_self[V17];
	goto L4495;
L4497:
	T0= MAKE_FIXNUM(V17);
L4495:
	(*LK31)(7,(V7),VV[42],MAKE_FIXNUM(V18),Cnil,Cnil,MAKE_FIXNUM(0),number_plus(MAKE_FIXNUM(V9),MAKE_FIXNUM(4)))/*  READ-SEQUENCE-CARD8*/;
	elt_set((V13),V15,CONS(T0,VALUES(0)));
	{register int V19;                        /*  .BOFFSET.       */
	Lceiling(2,MAKE_FIXNUM(V18),MAKE_FIXNUM(4))/*  CEILING        */;
	V19= (V9)+(fix(number_plus(MAKE_FIXNUM(4),number_times(MAKE_FIXNUM(4),VALUES(0)))));
	V9= V19;
	}
	}
	V15= (V15)+1;
	goto L4487;
	}
L4483:
	VALUES(1) = (V11);
	VALUES(0) = (V13);
	V6=2;
	}
	}
	}
	}
	frs_pop();
	MV_SAVE(V6);
	if(((V5))==Cnil){
	goto L4507;}
	(*LK20)(1,(V5))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L4507:
	if(((V4))==Cnil){
	goto L4506;}
	(*LK21)(2,(V3),(V4))                      /*  STOP-PENDING-COMMAND*/;
L4506:
	MV_RESTORE(V6);
	if (unwinding) unwind(nlj_fr,nlj_tag,V6+1);
	else {
	RETURN(V6);}}
	}
	}
}
/*	function definition for ACCESS-CONTROL                        */
static L97(int narg, object V1)
{ VT99 VLEX99 CLSR99
TTL:
	{volatile object V2;                      /*  .DISPLAY.       */
	volatile object V3;                       /*  .PENDING-COMMAND.*/
	volatile object V4;                       /*  .REPLY-BUFFER.  */
	V2= (V1);
	V3= Cnil;
	V4= Cnil;
	{ int V5; volatile bool unwinding = FALSE;
	if ((V5=frs_push(FRS_PROTECT,Cnil))) {
	V5--; unwinding = TRUE;} else {
	if((((V2))->in.in_slots[10])==Cnil){
	goto L4514;}
	(*LK0)(3,VV[16],VV[10],(V2))              /*  X-ERROR         */;
L4514:
	(*LK15)(1,(V2))                           /*  START-PENDING-COMMAND*/;
	V3= VALUES(0);
	{register object V6;                      /*  %BUFFER         */
	V6= (V2);
	if(!(((fix(((V6))->in.in_slots[6]))+(160))>=(fix(((V6))->in.in_slots[2])))){
	goto L4520;}
	(*LK7)(1,(V6))                            /*  BUFFER-FLUSH    */;
L4520:
	{register int V7;                         /*  BUFFER-BOFFSET  */
	object V8;                                /*  BUFFER-BBUF     */
	V7= fix(((V6))->in.in_slots[6]);
	V8= ((V6))->in.in_slots[7];
	((V2))->in.in_slots[4]= MAKE_FIXNUM(V7);
	(((V8))->ust.ust_self[(V7)+(0)]=(110));
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(2))))=1);
	((V2))->in.in_slots[6]= MAKE_FIXNUM((V7)+(4));
	(*LK13)(1,(V2))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V2))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V2))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK17)(2,(V2),(V3))                      /*  READ-REPLY      */;
	V4= VALUES(0);
	{object V6;                               /*  %REPLY-BUFFER   */
	object V7;                                /*  %BUFFER         */
	{int V8;                                  /*  BUFFER-BOFFSET  */
	object V9;                                /*  BUFFER-BBUF     */
	V8= 0;
	V9= ((V4))->in.in_slots[1];
	VALUES(0)=((((V9))->ust.ust_self[(V8)+(1)])>0?Ct:Cnil);
	V5=1;
	}
	}
	}
	frs_pop();
	MV_SAVE(V5);
	if(((V4))==Cnil){
	goto L4541;}
	(*LK20)(1,(V4))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L4541:
	if(((V3))==Cnil){
	goto L4540;}
	(*LK21)(2,(V2),(V3))                      /*  STOP-PENDING-COMMAND*/;
L4540:
	MV_RESTORE(V5);
	if (unwinding) unwind(nlj_fr,nlj_tag,V5+1);
	else {
	RETURN(V5);}}
	}
}
/*	function definition for SET-ACCESS-CONTROL                    */
static L98(int narg, object V1, object V2)
{ VT100 VLEX100 CLSR100
TTL:
	{register object V3;                      /*  .DISPLAY.       */
	V3= (V1);
	if((((V3))->in.in_slots[10])==Cnil){
	goto L4547;}
	(*LK0)(3,VV[16],VV[10],(V3))              /*  X-ERROR         */;
L4547:
	{register object V4;                      /*  %BUFFER         */
	V4= (V3);
	if(!(((fix(((V4))->in.in_slots[6]))+(160))>=(fix(((V4))->in.in_slots[2])))){
	goto L4551;}
	(*LK7)(1,(V4))                            /*  BUFFER-FLUSH    */;
L4551:
	{register int V5;                         /*  BUFFER-BOFFSET  */
	register object V6;                       /*  BUFFER-BBUF     */
	V5= fix(((V4))->in.in_slots[6]);
	V6= ((V4))->in.in_slots[7];
	((V3))->in.in_slots[4]= MAKE_FIXNUM(V5);
	(((V6))->ust.ust_self[(V5)+(0)]=(111));
	if(((V2))==Cnil){
	goto L4565;}
	T0= MAKE_FIXNUM(1);
	goto L4563;
L4565:
	T0= MAKE_FIXNUM(0);
L4563:
	VALUES(0) = MAKE_FIXNUM((((V6))->ust.ust_self[(V5)+(1)]=(fix(T0))));
	if(VALUES(0)==Cnil)goto L4561;
	goto L4560;
L4561:
	(*LK4)(2,(V2),VV[170])                    /*  X-TYPE-ERROR    */;
L4560:
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(2))))=1);
	((V3))->in.in_slots[6]= MAKE_FIXNUM((V5)+(4));
	(*LK13)(1,(V3))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK14)(1,(V3))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for CLOSE-DOWN-MODE                       */
static L99(int narg, object V1)
{ VT101 VLEX101 CLSR101
TTL:
	VALUES(0) = ((V1))->in.in_slots[49];
	RETURN(1);
}
/*	function definition for SET-CLOSE-DOWN-MODE                   */
static L100(int narg, object V1, object V2)
{ VT102 VLEX102 CLSR102
TTL:
	((V1))->in.in_slots[49]= (V2);
	{register object V3;                      /*  .DISPLAY.       */
	V3= (V1);
	if((((V3))->in.in_slots[10])==Cnil){
	goto L4571;}
	(*LK0)(3,VV[16],VV[10],(V3))              /*  X-ERROR         */;
L4571:
	{register object V4;                      /*  %BUFFER         */
	V4= (V3);
	if(!(((fix(((V4))->in.in_slots[6]))+(160))>=(fix(((V4))->in.in_slots[2])))){
	goto L4575;}
	(*LK7)(1,(V4))                            /*  BUFFER-FLUSH    */;
L4575:
	{register int V5;                         /*  BUFFER-BOFFSET  */
	register object V6;                       /*  BUFFER-BBUF     */
	V5= fix(((V4))->in.in_slots[6]);
	V6= ((V4))->in.in_slots[7];
	((V3))->in.in_slots[4]= MAKE_FIXNUM(V5);
	(((V6))->ust.ust_self[(V5)+(0)]=(112));
	(*LK8)(2,(V2),VV[173])                    /*  TYPEP           */;
	if(VALUES(0)!=Cnil){
	goto L4587;}
	VALUES(0) = Cnil;
	goto L4586;
L4587:
	VALUES(0) = (VV[305]->s.s_gfdef);
	(*LK10)(4,(V2),VV[174],VV[23],VALUES(0))  /*  POSITION        */;
	T0= VALUES(0);
	{int V7= ((*(unsigned long *)(((V6))->ust.ust_self+((V5)+(4))))=fix(T0));
	VALUES(0) = MAKE_FIXNUM((((V6))->ust.ust_self[(V5)+(1)]=(V7)));}
L4586:
	if(VALUES(0)==Cnil)goto L4585;
	goto L4584;
L4585:
	(*LK4)(2,(V2),VV[175])                    /*  X-TYPE-ERROR    */;
L4584:
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(2))))=1);
	((V3))->in.in_slots[6]= MAKE_FIXNUM((V5)+(4));
	(*LK13)(1,(V3))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK14)(1,(V3))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for KILL-CLIENT                           */
static L101(int narg, object V1, object V2)
{ VT103 VLEX103 CLSR103
	{int V3;
	V3= fix(V2);
TTL:
	{register object V4;                      /*  .DISPLAY.       */
	V4= (V1);
	if((((V4))->in.in_slots[10])==Cnil){
	goto L4593;}
	(*LK0)(3,VV[16],VV[10],(V4))              /*  X-ERROR         */;
L4593:
	{ int V5;
	{register object V6;                      /*  %BUFFER         */
	V6= (V4);
	if(!(((fix(((V6))->in.in_slots[6]))+(160))>=(fix(((V6))->in.in_slots[2])))){
	goto L4597;}
	(*LK7)(1,(V6))                            /*  BUFFER-FLUSH    */;
L4597:
	{register int V7;                         /*  BUFFER-BOFFSET  */
	register object V8;                       /*  BUFFER-BBUF     */
	V7= fix(((V6))->in.in_slots[6]);
	V8= ((V6))->in.in_slots[7];
	((V4))->in.in_slots[4]= MAKE_FIXNUM(V7);
	(((V8))->ust.ust_self[(V7)+(0)]=(113));
	(*LK8)(2,MAKE_FIXNUM(V3),VV[19])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L4608;}
	((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(4))))=V3);
	goto L4606;
L4608:
	(*LK4)(2,MAKE_FIXNUM(V3),VV[19])          /*  X-TYPE-ERROR    */;
L4606:
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(2))))=2);
	((V4))->in.in_slots[6]= MAKE_FIXNUM((V7)+(8));
	V5=(*LK13)(1,(V4))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V5);
	(*LK14)(1,(V4))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V5);
	RETURN(V5);}
	}
	}
}
/*	function definition for KILL-TEMPORARY-CLIENTS                */
static L102(int narg, object V1)
{ VT104 VLEX104 CLSR104
TTL:
	{register object V2;                      /*  .DISPLAY.       */
	V2= (V1);
	if((((V2))->in.in_slots[10])==Cnil){
	goto L4613;}
	(*LK0)(3,VV[16],VV[10],(V2))              /*  X-ERROR         */;
L4613:
	{ int V3;
	{register object V4;                      /*  %BUFFER         */
	V4= (V2);
	if(!(((fix(((V4))->in.in_slots[6]))+(160))>=(fix(((V4))->in.in_slots[2])))){
	goto L4617;}
	(*LK7)(1,(V4))                            /*  BUFFER-FLUSH    */;
L4617:
	{register int V5;                         /*  BUFFER-BOFFSET  */
	register object V6;                       /*  BUFFER-BBUF     */
	V5= fix(((V4))->in.in_slots[6]);
	V6= ((V4))->in.in_slots[7];
	((V2))->in.in_slots[4]= MAKE_FIXNUM(V5);
	(((V6))->ust.ust_self[(V5)+(0)]=(113));
	((*(unsigned long *)(((V6))->ust.ust_self+((V5)+(4))))=0);
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(2))))=2);
	((V2))->in.in_slots[6]= MAKE_FIXNUM((V5)+(8));
	V3=(*LK13)(1,(V2))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V3);
	(*LK14)(1,(V2))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V3);
	RETURN(V3);}
	}
}
/*	function definition for NO-OPERATION                          */
static L103(int narg, object V1)
{ VT105 VLEX105 CLSR105
TTL:
	{register object V2;                      /*  .DISPLAY.       */
	V2= (V1);
	if((((V2))->in.in_slots[10])==Cnil){
	goto L4630;}
	(*LK0)(3,VV[16],VV[10],(V2))              /*  X-ERROR         */;
L4630:
	{ int V3;
	{register object V4;                      /*  %BUFFER         */
	V4= (V2);
	if(!(((fix(((V4))->in.in_slots[6]))+(160))>=(fix(((V4))->in.in_slots[2])))){
	goto L4634;}
	(*LK7)(1,(V4))                            /*  BUFFER-FLUSH    */;
L4634:
	{register int V5;                         /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= fix(((V4))->in.in_slots[6]);
	V6= ((V4))->in.in_slots[7];
	((V2))->in.in_slots[4]= MAKE_FIXNUM(V5);
	(((V6))->ust.ust_self[(V5)+(0)]=(127));
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(2))))=1);
	((V2))->in.in_slots[6]= MAKE_FIXNUM((V5)+(4));
	V3=(*LK13)(1,(V2))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V3);
	(*LK14)(1,(V2))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V3);
	RETURN(V3);}
	}
}
static LKF57(int narg, ...) {TRAMPOLINK(VV[485],&LK57);}
static LKF56(int narg, ...) {TRAMPOLINK(VV[475],&LK56);}
static LKF55(int narg, ...) {TRAMPOLINK(VV[474],&LK55);}
static LKF54(int narg, ...) {TRAMPOLINK(VV[456],&LK54);}
static LKF53(int narg, ...) {TRAMPOLINK(VV[448],&LK53);}
static LKF52(int narg, ...) {TRAMPOLINK(VV[442],&LK52);}
static LKF51(int narg, ...) {TRAMPOLINK(VV[436],&LK51);}
static LKF50(int narg, ...) {TRAMPOLINK(VV[424],&LK50);}
static LKF49(int narg, ...) {TRAMPOLINK(VV[423],&LK49);}
static LKF48(int narg, ...) {TRAMPOLINK(VV[422],&LK48);}
static LKF47(int narg, ...) {TRAMPOLINK(VV[421],&LK47);}
static LKF46(int narg, ...) {TRAMPOLINK(VV[420],&LK46);}
static LKF45(int narg, ...) {TRAMPOLINK(VV[413],&LK45);}
static LKF44(int narg, ...) {TRAMPOLINK(VV[25],&LK44);}
static LKF43(int narg, ...) {TRAMPOLINK(VV[410],&LK43);}
static LKF42(int narg, ...) {TRAMPOLINK(VV[409],&LK42);}
static LKF41(int narg, ...) {TRAMPOLINK(VV[405],&LK41);}
static LKF40(int narg, ...) {TRAMPOLINK(VV[403],&LK40);}
static LKF39(int narg, ...) {TRAMPOLINK(VV[402],&LK39);}
static LKF38(int narg, ...) {TRAMPOLINK(VV[398],&LK38);}
static LKF37(int narg, ...) {TRAMPOLINK(VV[375],&LK37);}
static LKF36(int narg, ...) {TRAMPOLINK(VV[371],&LK36);}
static LKF35(int narg, ...) {TRAMPOLINK(VV[364],&LK35);}
static LKF34(int narg, ...) {TRAMPOLINK(VV[363],&LK34);}
static LKF33(int narg, ...) {TRAMPOLINK(VV[356],&LK33);}
static LKF32(int narg, ...) {TRAMPOLINK(VV[354],&LK32);}
static LKF31(int narg, ...) {TRAMPOLINK(VV[353],&LK31);}
static LKF30(int narg, ...) {TRAMPOLINK(VV[348],&LK30);}
static LKF29(int narg, ...) {TRAMPOLINK(VV[347],&LK29);}
static LKF28(int narg, ...) {TRAMPOLINK(VV[346],&LK28);}
static LKF27(int narg, ...) {TRAMPOLINK(VV[339],&LK27);}
static LKF26(int narg, ...) {TRAMPOLINK(VV[338],&LK26);}
static LKF25(int narg, ...) {TRAMPOLINK(VV[335],&LK25);}
static LKF24(int narg, ...) {TRAMPOLINK(VV[334],&LK24);}
static LKF23(int narg, ...) {TRAMPOLINK(VV[333],&LK23);}
static LKF22(int narg, ...) {TRAMPOLINK(VV[332],&LK22);}
static LKF21(int narg, ...) {TRAMPOLINK(VV[330],&LK21);}
static LKF20(int narg, ...) {TRAMPOLINK(VV[329],&LK20);}
static LKF19(int narg, ...) {TRAMPOLINK(VV[328],&LK19);}
static LKF18(int narg, ...) {TRAMPOLINK(VV[327],&LK18);}
static LKF17(int narg, ...) {TRAMPOLINK(VV[326],&LK17);}
static LKF16(int narg, ...) {TRAMPOLINK(VV[325],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[324],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[310],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[309],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[308],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[307],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[306],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[304],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[303],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[302],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[301],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[300],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[299],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[298],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[296],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[295],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[294],&LK0);}
