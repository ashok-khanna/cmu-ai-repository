
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "numlib.h"
init_numlib(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_numlib; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	funcall(2,symbol_function(VV[13]),VV[0])  /*  PROCLAIM        */;
	siLAmake_constant(2,VV[1],VV[2])          /*  *MAKE-CONSTANT  */;
	MF0(VV[14],L1);
	MF0(VV[15],L2);
	MF0(VV[16],L3);
	MF0(VV[17],L4);
	VV[4]=string_to_object(VV[4]);
	MF0(VV[18],L5);
	MF0(VV[19],L6);
	MF0(VV[20],L7);
	MF0(VV[21],L8);
	MF0(VV[22],L9);
	MF0(VV[23],L10);
	MF0(VV[24],L11);
	MF0(VV[25],L12);
	MF0(VV[26],L13);
	MF0(VV[9],L14);
	siLfset(2,VV[12],symbol_function(VV[9]))  /*  FSET            */;
	MF0(VV[27],L15);
	MF0(VV[28],L16);
	MF0(VV[29],L17);
	MF0(VV[30],L18);
	MF0(VV[31],L19);
	MF0(VV[32],L20);
	MF0(VV[33],L21);
	MF0(VV[34],L22);
	MF0(VV[35],L23);
	MF0(VV[36],L24);
	MF0(VV[37],L25);
	MF0(VV[38],L26);
	MF0(VV[39],L27);
	MF0(VV[40],L28);
	MF0(VV[41],L29);
	MF0(VV[42],L30);
	MF0(VV[43],L31);
	MF0(VV[44],L32);
	MF0(VV[45],L33);
	MF0(VV[46],L34);
}
/*	function definition for ISQRT                                 */
static L1(int narg, object V1)
{ VT3 VLEX3 CLSR3
	cs_check;
	check_arg(1);
TTL:
	if(!(type_of((V1))==t_fixnum||type_of((V1))==t_bignum)){
	goto L6;}
	if(number_compare((V1),MAKE_FIXNUM(0))>=0){
	goto L5;}
L6:
	Lerror(2,VV[3],(V1))                      /*  ERROR           */;
L5:
	if(!(number_compare(MAKE_FIXNUM(0),(V1))==0)){
	goto L11;}
	VALUES(0) = MAKE_FIXNUM(0);
	RETURN(1);
L11:
	{volatile int V2;                         /*  N               */
	Linteger_length(1,(V1))                   /*  INTEGER-LENGTH  */;
	V2= fix(VALUES(0));
	{volatile object V3;                      /*  X               */
	volatile object V4;                       /*  Y               */
	Lceiling(2,MAKE_FIXNUM(V2),MAKE_FIXNUM(2))/*  CEILING         */;
	Lash(2,MAKE_FIXNUM(1),VALUES(0))          /*  ASH             */;
	V3= VALUES(0);
	V4= Cnil;
L17:
	Lfloor(2,(V1),(V3))                       /*  FLOOR           */;
	V4= VALUES(0);
	if(!(number_compare((V3),(V4))<=0)){
	goto L21;}
	VALUES(0) = (V3);
	RETURN(1);
L21:
	Lfloor(2,number_plus((V3),(V4)),MAKE_FIXNUM(2))/*  FLOOR      */;
	V3= VALUES(0);
	goto L17;
	}
	}
}
/*	function definition for ABS                                   */
static L2(int narg, object V1)
{ VT4 VLEX4 CLSR4
	cs_check;
	check_arg(1);
TTL:
	Lcomplexp(1,(V1))                         /*  COMPLEXP        */;
	if(VALUES(0)==Cnil){
	goto L29;}
	Lrealpart(1,(V1))                         /*  REALPART        */;
	T0= VALUES(0);
	Lrealpart(1,(V1))                         /*  REALPART        */;
	{object V2= number_times(T0,VALUES(0));
	Limagpart(1,(V1))                         /*  IMAGPART        */;
	T1= VALUES(0);
	Limagpart(1,(V1))                         /*  IMAGPART        */;
	RETURN(Lsqrt(1,number_plus((V2),number_times(T1,VALUES(0))))/*  SQRT*/);}
L29:
	if(!(number_compare(MAKE_FIXNUM(0),(V1))>0)){
	goto L36;}
	VALUES(0) = number_negate((V1));
	RETURN(1);
L36:
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for PHASE                                 */
static L3(int narg, object V1)
{ VT5 VLEX5 CLSR5
	cs_check;
	check_arg(1);
TTL:
	Limagpart(1,(V1))                         /*  IMAGPART        */;
	T0= VALUES(0);
	Lrealpart(1,(V1))                         /*  REALPART        */;
	RETURN(Latan(2,T0,VALUES(0))              /*  ATAN            */);
}
/*	function definition for SIGNUM                                */
static L4(int narg, object V1)
{ VT6 VLEX6 CLSR6
	cs_check;
	check_arg(1);
TTL:
	if(!(number_compare(MAKE_FIXNUM(0),(V1))==0)){
	goto L41;}
	VALUES(0) = (V1);
	RETURN(1);
L41:
	L2(1,(V1))                                /*  ABS             */;
	VALUES(0) = number_divide((V1),VALUES(0));
	RETURN(1);
}
/*	function definition for CIS                                   */
static L5(int narg, object V1)
{ VT7 VLEX7 CLSR7
	cs_check;
	check_arg(1);
TTL:
	RETURN(Lexp(1,number_times(VV[4],(V1)))   /*  EXP             */);
}
/*	function definition for ASIN                                  */
static L6(int narg, object V1)
{ VT8 VLEX8 CLSR8
	cs_check;
	check_arg(1);
TTL:
	{register object V2;                      /*  C               */
	{object V3= number_times(VV[4],(V1));
	Lsqrt(1,number_minus(VV[6],number_times((V1),(V1))))/*  SQRT  */;
	Llog(1,number_plus((V3),VALUES(0)))       /*  LOG             */;
	V2= number_times(VV[5],VALUES(0));}
	Lcomplexp(1,(V2))                         /*  COMPLEXP        */;
	if(VALUES(0)==Cnil){
	goto L47;}
	Limagpart(1,(V2))                         /*  IMAGPART        */;
	if(!(number_compare(MAKE_FIXNUM(0),VALUES(0))==0)){
	goto L48;}
L47:
	RETURN(Lrealpart(1,(V2))                  /*  REALPART        */);
L48:
	VALUES(0) = (V2);
	RETURN(1);
	}
}
/*	function definition for ACOS                                  */
static L7(int narg, object V1)
{ VT9 VLEX9 CLSR9
	cs_check;
	check_arg(1);
TTL:
	{register object V2;                      /*  C               */
	Lsqrt(1,number_minus(VV[6],number_times((V1),(V1))))/*  SQRT  */;
	Llog(1,number_plus((V1),number_times(VV[4],VALUES(0))))/*  LOG*/;
	V2= number_times(VV[5],VALUES(0));
	Lcomplexp(1,(V2))                         /*  COMPLEXP        */;
	if(VALUES(0)==Cnil){
	goto L56;}
	Limagpart(1,(V2))                         /*  IMAGPART        */;
	if(!(number_compare(MAKE_FIXNUM(0),VALUES(0))==0)){
	goto L57;}
L56:
	RETURN(Lrealpart(1,(V2))                  /*  REALPART        */);
L57:
	VALUES(0) = (V2);
	RETURN(1);
	}
}
/*	function definition for SINH                                  */
static L8(int narg, object V1)
{ VT10 VLEX10 CLSR10
	cs_check;
	check_arg(1);
TTL:
	Lexp(1,(V1))                              /*  EXP             */;
	T0= VALUES(0);
	Lexp(1,number_negate((V1)))               /*  EXP             */;
	VALUES(0) = number_divide(number_minus(T0,VALUES(0)),VV[7]);
	RETURN(1);
}
/*	function definition for COSH                                  */
static L9(int narg, object V1)
{ VT11 VLEX11 CLSR11
	cs_check;
	check_arg(1);
TTL:
	Lexp(1,(V1))                              /*  EXP             */;
	T0= VALUES(0);
	Lexp(1,number_negate((V1)))               /*  EXP             */;
	VALUES(0) = number_divide(number_plus(T0,VALUES(0)),VV[7]);
	RETURN(1);
}
/*	function definition for TANH                                  */
static L10(int narg, object V1)
{ VT12 VLEX12 CLSR12
	cs_check;
	check_arg(1);
TTL:
	L8(1,(V1))                                /*  SINH            */;
	T0= VALUES(0);
	L9(1,(V1))                                /*  COSH            */;
	VALUES(0) = number_divide(T0,VALUES(0));
	RETURN(1);
}
/*	function definition for ASINH                                 */
static L11(int narg, object V1)
{ VT13 VLEX13 CLSR13
	cs_check;
	check_arg(1);
TTL:
	Lsqrt(1,number_plus(VV[6],number_times((V1),(V1))))/*  SQRT   */;
	RETURN(Llog(1,number_plus((V1),VALUES(0)))/*  LOG             */);
}
/*	function definition for ACOSH                                 */
static L12(int narg, object V1)
{ VT14 VLEX14 CLSR14
	cs_check;
	check_arg(1);
TTL:
	Lsqrt(1,number_divide(one_plus((V1)),MAKE_FIXNUM(2)))/*  SQRT */;
	T0= VALUES(0);
	Lsqrt(1,number_divide(one_minus((V1)),MAKE_FIXNUM(2)))/*  SQRT*/;
	Llog(1,number_plus(T0,VALUES(0)))         /*  LOG             */;
	VALUES(0) = number_times(MAKE_FIXNUM(2),VALUES(0));
	RETURN(1);
}
/*	function definition for ATANH                                 */
static L13(int narg, object V1)
{ VT15 VLEX15 CLSR15
	cs_check;
	check_arg(1);
TTL:
	Llog(1,one_plus((V1)))                    /*  LOG             */;
	T0= VALUES(0);
	Llog(1,number_minus(MAKE_FIXNUM(1),(V1))) /*  LOG             */;
	VALUES(0) = number_divide(number_minus(T0,VALUES(0)),MAKE_FIXNUM(2));
	RETURN(1);
}
/*	function definition for RATIONAL                              */
static L14(int narg, object V1)
{ VT16 VLEX16 CLSR16
	cs_check;
	check_arg(1);
TTL:
	{object V2;
	V2= (V1);
	(*LK0)(2,(V2),VV[8])                      /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L75;}
	{ int V3;
	object V4;                                /*  I               */
	object V5;                                /*  E               */
	object V6;                                /*  S               */
	V3=Linteger_decode_float(1,(V1))          /*  INTEGER-DECODE-FLOAT*/;
	if (V3--==0) goto L78;
	V4= VALUES(0);
	if (V3--==0) goto L79;
	V5= VALUES(1);
	if (V3--==0) goto L80;
	V6= VALUES(2);
	goto L81;
L78:
	V4= Cnil;
L79:
	V5= Cnil;
L80:
	V6= Cnil;
L81:
	if(!(number_compare((V6),MAKE_FIXNUM(0))>=0)){
	goto L83;}
	Lfloat_radix(1,(V1))                      /*  FLOAT-RADIX     */;
	VALUES(0) = number_times((V4),number_expt(VALUES(0),(V5)));
	RETURN(1);
L83:
	Lfloat_radix(1,(V1))                      /*  FLOAT-RADIX     */;
	VALUES(0) = number_negate(number_times((V4),number_expt(VALUES(0),(V5))));
	RETURN(1);}
L75:
	(*LK0)(2,(V2),VV[9])                      /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L88;}
	VALUES(0) = (V1);
	RETURN(1);
L88:
	(*LK1)(3,VV[10],(V2),VV[11])              /*  TYPECASE-ERROR-STRING*/;
	RETURN(Lerror(1,VALUES(0))                /*  ERROR           */);
	}
}
/*	function definition for FFLOOR                                */
static L15(int narg, object V1, ...)
{ VT17 VLEX17 CLSR17
	cs_check;
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if(narg<1) FEtoo_few_arguments(&narg);
	if(narg>2) FEtoo_many_arguments(&narg);
	if (i==narg) goto L91;
	V2= va_arg(args, object);
	i++;
	goto L92;
L91:
	V2= VV[6];
L92:
	{ int V3;
	object V4;                                /*  I               */
	object V5;                                /*  R               */
	Lfloat(1,(V1))                            /*  FLOAT           */;
	T0= VALUES(0);
	Lfloat(1,(V2))                            /*  FLOAT           */;
	V3=Lfloor(2,T0,VALUES(0))                 /*  FLOOR           */;
	if (V3--==0) goto L97;
	V4= VALUES(0);
	if (V3--==0) goto L98;
	V5= VALUES(1);
	goto L99;
L97:
	V4= Cnil;
L98:
	V5= Cnil;
L99:
	Lfloat(2,(V4),(V5))                       /*  FLOAT           */;
	VALUES(1) = (V5);
	VALUES(0) = VALUES(0);
	RETURN(2);}
	}
}
/*	function definition for FCEILING                              */
static L16(int narg, object V1, ...)
{ VT18 VLEX18 CLSR18
	cs_check;
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if(narg<1) FEtoo_few_arguments(&narg);
	if(narg>2) FEtoo_many_arguments(&narg);
	if (i==narg) goto L101;
	V2= va_arg(args, object);
	i++;
	goto L102;
L101:
	V2= VV[6];
L102:
	{ int V3;
	object V4;                                /*  I               */
	object V5;                                /*  R               */
	Lfloat(1,(V1))                            /*  FLOAT           */;
	T0= VALUES(0);
	Lfloat(1,(V2))                            /*  FLOAT           */;
	V3=Lceiling(2,T0,VALUES(0))               /*  CEILING         */;
	if (V3--==0) goto L107;
	V4= VALUES(0);
	if (V3--==0) goto L108;
	V5= VALUES(1);
	goto L109;
L107:
	V4= Cnil;
L108:
	V5= Cnil;
L109:
	Lfloat(2,(V4),(V5))                       /*  FLOAT           */;
	VALUES(1) = (V5);
	VALUES(0) = VALUES(0);
	RETURN(2);}
	}
}
/*	function definition for FTRUNCATE                             */
static L17(int narg, object V1, ...)
{ VT19 VLEX19 CLSR19
	cs_check;
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if(narg<1) FEtoo_few_arguments(&narg);
	if(narg>2) FEtoo_many_arguments(&narg);
	if (i==narg) goto L111;
	V2= va_arg(args, object);
	i++;
	goto L112;
L111:
	V2= VV[6];
L112:
	{ int V3;
	object V4;                                /*  I               */
	object V5;                                /*  R               */
	Lfloat(1,(V1))                            /*  FLOAT           */;
	T0= VALUES(0);
	Lfloat(1,(V2))                            /*  FLOAT           */;
	V3=Ltruncate(2,T0,VALUES(0))              /*  TRUNCATE        */;
	if (V3--==0) goto L117;
	V4= VALUES(0);
	if (V3--==0) goto L118;
	V5= VALUES(1);
	goto L119;
L117:
	V4= Cnil;
L118:
	V5= Cnil;
L119:
	Lfloat(2,(V4),(V5))                       /*  FLOAT           */;
	VALUES(1) = (V5);
	VALUES(0) = VALUES(0);
	RETURN(2);}
	}
}
/*	function definition for FROUND                                */
static L18(int narg, object V1, ...)
{ VT20 VLEX20 CLSR20
	cs_check;
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if(narg<1) FEtoo_few_arguments(&narg);
	if(narg>2) FEtoo_many_arguments(&narg);
	if (i==narg) goto L121;
	V2= va_arg(args, object);
	i++;
	goto L122;
L121:
	V2= VV[6];
L122:
	{ int V3;
	object V4;                                /*  I               */
	object V5;                                /*  R               */
	Lfloat(1,(V1))                            /*  FLOAT           */;
	T0= VALUES(0);
	Lfloat(1,(V2))                            /*  FLOAT           */;
	V3=Lround(2,T0,VALUES(0))                 /*  ROUND           */;
	if (V3--==0) goto L127;
	V4= VALUES(0);
	if (V3--==0) goto L128;
	V5= VALUES(1);
	goto L129;
L127:
	V4= Cnil;
L128:
	V5= Cnil;
L129:
	Lfloat(2,(V4),(V5))                       /*  FLOAT           */;
	VALUES(1) = (V5);
	VALUES(0) = VALUES(0);
	RETURN(2);}
	}
}
/*	function definition for LOGNAND                               */
static L19(int narg, object V1, object V2)
{ VT21 VLEX21 CLSR21
	cs_check;
	check_arg(2);
TTL:
	VALUES(0) = MAKE_FIXNUM((~((fix((V1))) & (fix((V2))))));
	RETURN(1);
}
/*	function definition for LOGNOR                                */
static L20(int narg, object V1, object V2)
{ VT22 VLEX22 CLSR22
	cs_check;
	check_arg(2);
TTL:
	VALUES(0) = MAKE_FIXNUM((~((fix((V1)))|(fix((V2))))));
	RETURN(1);
}
/*	function definition for LOGANDC1                              */
static L21(int narg, object V1, object V2)
{ VT23 VLEX23 CLSR23
	cs_check;
	check_arg(2);
TTL:
	VALUES(0) = MAKE_FIXNUM(((~(fix((V1))))&(fix((V2)))));
	RETURN(1);
}
/*	function definition for LOGANDC2                              */
static L22(int narg, object V1, object V2)
{ VT24 VLEX24 CLSR24
	cs_check;
	check_arg(2);
TTL:
	VALUES(0) = MAKE_FIXNUM((((fix((V1))))&(~(fix((V2))))));
	RETURN(1);
}
/*	function definition for LOGORC1                               */
static L23(int narg, object V1, object V2)
{ VT25 VLEX25 CLSR25
	cs_check;
	check_arg(2);
TTL:
	VALUES(0) = MAKE_FIXNUM((~(fix((V1))) | (fix((V2)))));
	RETURN(1);
}
/*	function definition for LOGORC2                               */
static L24(int narg, object V1, object V2)
{ VT26 VLEX26 CLSR26
	cs_check;
	check_arg(2);
TTL:
	VALUES(0) = MAKE_FIXNUM(((fix((V1))) | (~(fix((V2))))));
	RETURN(1);
}
/*	function definition for LOGNOT                                */
static L25(int narg, object V1)
{ VT27 VLEX27 CLSR27
	cs_check;
	check_arg(1);
TTL:
	RETURN(Llogxor(2,MAKE_FIXNUM(-1),(V1))    /*  LOGXOR          */);
}
/*	function definition for LOGTEST                               */
static L26(int narg, object V1, object V2)
{ VT28 VLEX28 CLSR28
	cs_check;
	check_arg(2);
TTL:
	Llogand(2,(V1),(V2))                      /*  LOGAND          */;
	VALUES(0) = (((number_compare(MAKE_FIXNUM(0),VALUES(0))==0?Ct:Cnil))==Cnil?Ct:Cnil);
	RETURN(1);
}
/*	function definition for BYTE                                  */
static L27(int narg, object V1, object V2)
{ VT29 VLEX29 CLSR29
	cs_check;
	check_arg(2);
TTL:
	VALUES(0) = CONS((V1),(V2));
	RETURN(1);
}
/*	function definition for BYTE-SIZE                             */
static L28(int narg, object V1)
{ VT30 VLEX30 CLSR30
	cs_check;
	check_arg(1);
TTL:
	VALUES(0) = car((V1));
	RETURN(1);
}
/*	function definition for BYTE-POSITION                         */
static L29(int narg, object V1)
{ VT31 VLEX31 CLSR31
	cs_check;
	check_arg(1);
TTL:
	VALUES(0) = cdr((V1));
	RETURN(1);
}
/*	function definition for LDB                                   */
static L30(int narg, object V1, object V2)
{ VT32 VLEX32 CLSR32
	cs_check;
	check_arg(2);
TTL:
	L29(1,(V1))                               /*  BYTE-POSITION   */;
	Lash(2,(V2),number_negate(VALUES(0)))     /*  ASH             */;
	T0= VALUES(0);
	L28(1,(V1))                               /*  BYTE-SIZE       */;
	Lash(2,MAKE_FIXNUM(1),VALUES(0))          /*  ASH             */;
	RETURN(L22(2,T0,number_negate(VALUES(0))) /*  LOGANDC2        */);
}
/*	function definition for LDB-TEST                              */
static L31(int narg, object V1, object V2)
{ VT33 VLEX33 CLSR33
	cs_check;
	check_arg(2);
TTL:
	L30(2,(V1),(V2))                          /*  LDB             */;
	VALUES(0) = (((number_compare(MAKE_FIXNUM(0),VALUES(0))==0?Ct:Cnil))==Cnil?Ct:Cnil);
	RETURN(1);
}
/*	function definition for MASK-FIELD                            */
static L32(int narg, object V1, object V2)
{ VT34 VLEX34 CLSR34
	cs_check;
	check_arg(2);
TTL:
	L30(2,(V1),(V2))                          /*  LDB             */;
	T0= VALUES(0);
	L29(1,(V1))                               /*  BYTE-POSITION   */;
	RETURN(Lash(2,T0,VALUES(0))               /*  ASH             */);
}
/*	function definition for DPB                                   */
static L33(int narg, object V1, object V2, object V3)
{ VT35 VLEX35 CLSR35
	cs_check;
	check_arg(3);
TTL:
	L32(2,(V2),(V3))                          /*  MASK-FIELD      */;
	T0= VALUES(0);
	L28(1,(V2))                               /*  BYTE-SIZE       */;
	Lash(2,MAKE_FIXNUM(1),VALUES(0))          /*  ASH             */;
	L22(2,(V1),number_negate(VALUES(0)))      /*  LOGANDC2        */;
	T1= VALUES(0);
	L29(1,(V2))                               /*  BYTE-POSITION   */;
	Lash(2,T1,VALUES(0))                      /*  ASH             */;
	RETURN(Llogxor(3,(V3),T0,VALUES(0))       /*  LOGXOR          */);
}
/*	function definition for DEPOSIT-FIELD                         */
static L34(int narg, object V1, object V2, object V3)
{ VT36 VLEX36 CLSR36
	cs_check;
	check_arg(3);
TTL:
	L29(1,(V2))                               /*  BYTE-POSITION   */;
	Lash(2,(V1),number_negate(VALUES(0)))     /*  ASH             */;
	RETURN(L33(3,VALUES(0),(V2),(V3))         /*  DPB             */);
}
static LKF1(int narg, ...) {TRAMPOLINK(VV[48],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[47],&LK0);}
