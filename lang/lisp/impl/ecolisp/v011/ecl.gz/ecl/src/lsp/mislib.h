
/* (c) Copyright G. Attardi, 1993. */
static L1();
int siLAmake_constant();
int siLAmake_constant();
#define VT2
#define VLEX2
#define CLSR2
int Lgentemp();
int Lgentemp();
int Lgentemp();
int Lgentemp();
int Lgentemp();
int Lgentemp();
int Lgentemp();
#define VT3
#define VLEX3
#define CLSR3
static L2(int, object);
int Lmod();
int Lmod();
int Lmod();
#define VT4
#define VLEX4
#define CLSR4
static L3(int, object);
int Lfloor();
int Lfloor();
int Lfloor();
int Lplus();
#define VT5 object T0;
#define VLEX5
#define CLSR5
static L4(int, object, ...);
int Lget_local_time_zone();
int Ldaylight_saving_timep();
int Lround();
int Lfloor();
int Lfloor();
int Lfloor();
int Lmod();
int Lfloor();
#define VT6
#define VLEX6
#define CLSR6
static L5(int, object, object, object, object, object, object, ...);
int Lget_local_time_zone();
int Lmonotonically_nondecreasing();
int Lmod();
int Lplus();
int Lplus();
#define VT7 object T0;
#define VLEX7
#define CLSR7
static struct codeblock Cblock;
#define VM7 1
#define VM6 0
#define VM5 1
#define VM4 0
#define VM3 0
#define VM2 0
#define VM1 32
static object VV[32];
static LKF0(int, ...);
static (*LK0)(int, ...)=LKF0;
static LKF1(int, ...);
static (*LK1)(int, ...)=LKF1;
