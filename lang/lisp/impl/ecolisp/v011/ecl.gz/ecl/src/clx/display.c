
#include "display.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	MF0(VV[104],L1);
	(void)putprop(VV[104],VV[Vdeb104],VV[105]);
	MF0(VV[106],L2);
	(void)putprop(VV[106],VV[Vdeb106],VV[105]);
	VV[1]=string_to_object(VV[1]);
	MM0(VV[107],L3);
	MM0(VV[108],L4);
	MF0(VV[7],L5);
	(void)putprop(VV[7],VV[Vdeb7],VV[105]);
	MF0(VV[109],L6);
	(void)putprop(VV[109],VV[Vdeb109],VV[105]);
	MF0(VV[6],L7);
	(void)putprop(VV[6],VV[Vdeb6],VV[105]);
	VV[110] = make_cfun(LC8,Cnil,&Cblock);
	VV[111] = make_cfun(LC9,Cnil,&Cblock);
	VV[112] = make_cfun(LC10,Cnil,&Cblock);
	VV[113] = make_cfun(LC11,Cnil,&Cblock);
	VV[114] = make_cfun(LC12,Cnil,&Cblock);
	VV[115] = make_cfun(LC13,Cnil,&Cblock);
	VV[116] = make_cfun(LC14,Cnil,&Cblock);
	VALUES(0) = VV[110];
	siLfset(2,VV[8],VALUES(0))                /*  FSET            */;
	VALUES(0) = VV[111];
	siLfset(2,VV[15],VALUES(0))               /*  FSET            */;
	VALUES(0) = VV[112];
	siLfset(2,VV[17],VALUES(0))               /*  FSET            */;
	VALUES(0) = VV[113];
	siLfset(2,VV[19],VALUES(0))               /*  FSET            */;
	VALUES(0) = VV[114];
	siLfset(2,VV[20],VALUES(0))               /*  FSET            */;
	VALUES(0) = VV[115];
	siLfset(2,VV[22],VALUES(0))               /*  FSET            */;
	VALUES(0) = VV[116];
	siLfset(2,VV[24],VALUES(0))               /*  FSET            */;
	MF0(VV[117],L15);
	(void)putprop(VV[117],VV[Vdeb117],VV[105]);
	MF0(VV[26],L16);
	(void)putprop(VV[26],VV[Vdeb26],VV[105]);
	MF0(VV[27],L17);
	(void)putprop(VV[27],VV[Vdeb27],VV[105]);
	putprop(VV[26],VV[27],VV[28]);
	remprop(VV[26],VV[29]);
	remprop(VV[26],VV[30]);
	putprop(VV[26],Cnil,VV[31]);
	VV[32]=string_to_object(VV[32]);
	MF0(VV[118],L18);
	(void)putprop(VV[118],VV[Vdeb118],VV[105]);
	MF0(VV[34],L19);
	(void)putprop(VV[34],VV[Vdeb34],VV[105]);
	(void)putprop(VV[119],VV[39],siSpretty_print_format);
	
	MM0(VV[119],L20);
	(void)putprop(VV[120],VV[39],siSpretty_print_format);
	
	MM0(VV[120],L21);
	MF0(VV[45],L22);
	(void)putprop(VV[45],VV[Vdeb45],VV[105]);
	(void)putprop(VV[121],VV[39],siSpretty_print_format);
	
	MM0(VV[121],L23);
	MF0key(VV[122],L24,4,L24keys);
	(void)putprop(VV[122],VV[Vdeb122],VV[105]);
	MF0(VV[123],L25);
	(void)putprop(VV[123],VV[Vdeb123],VV[105]);
	MF0key(VV[124],L26,1,L26keys);
	(void)putprop(VV[124],VV[Vdeb124],VV[105]);
	MF0key(VV[125],L27,2,L27keys);
	(void)putprop(VV[125],VV[Vdeb125],VV[105]);
	MF0(VV[126],L28);
	(void)putprop(VV[126],VV[Vdeb126],VV[105]);
	MF0(VV[127],L29);
	(void)putprop(VV[127],VV[Vdeb127],VV[105]);
	MF0(VV[128],L30);
	(void)putprop(VV[128],VV[Vdeb128],VV[105]);
	VV[100]->s.s_stype=(short)stp_special;
	if(VV[100]->s.s_dbind == OBJNULL){
	(VV[100]->s.s_dbind)= Cnil;}
	MF0(VV[129],L31);
	(void)putprop(VV[129],VV[Vdeb129],VV[105]);
	MF0(VV[130],L32);
	(void)putprop(VV[130],VV[Vdeb130],VV[105]);
	siLAmake_special(1,VV[102])               /*  *MAKE-SPECIAL   */;
	(VV[102]->s.s_dbind)= VV[103];
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	local function CLOSURE                                        */
static LC14(int narg, object V1, object V2)
{ VT3 VLEX3 CLSR3
	{register int V3;
	V3= fix(V2);
	{register object V4;                      /*  FONT            */
	L6(2,(V1),MAKE_FIXNUM(V3))                /*  LOOKUP-RESOURCE-ID*/;
	V4= VALUES(0);
	if(((V4))!=Cnil){
	goto L34;}
	(*LK0)(4,VV[9],(V1),VV[10],MAKE_FIXNUM(V3))/*  MAKE-FONT      */;
	V4= VALUES(0);
	RETURN(L7(3,(V1),MAKE_FIXNUM(V3),(V4))    /*  SAVE-ID         */);
L34:
	(*LK1)(1,(V4))                            /*  FONT-P          */;
	if(VALUES(0)==Cnil){
	goto L39;}
	VALUES(0) = (V4);
	RETURN(1);
L39:
	RETURN((*LK2)(9,VV[11],VV[10],MAKE_FIXNUM(V3),VV[9],(V1),VV[12],VV[25],VV[14],(V4))/*  X-ERROR*/);
	}
	}
}
/*	local function CLOSURE                                        */
static LC13(int narg, object V1, object V2)
{ VT4 VLEX4 CLSR4
	{register int V3;
	V3= fix(V2);
	{register object V4;                      /*  COLORMAP        */
	L6(2,(V1),MAKE_FIXNUM(V3))                /*  LOOKUP-RESOURCE-ID*/;
	V4= VALUES(0);
	if(((V4))!=Cnil){
	goto L43;}
	(*LK3)(4,VV[9],(V1),VV[10],MAKE_FIXNUM(V3))/*  MAKE-COLORMAP  */;
	V4= VALUES(0);
	RETURN(L7(3,(V1),MAKE_FIXNUM(V3),(V4))    /*  SAVE-ID         */);
L43:
	(*LK4)(1,(V4))                            /*  COLORMAP-P      */;
	if(VALUES(0)==Cnil){
	goto L48;}
	VALUES(0) = (V4);
	RETURN(1);
L48:
	RETURN((*LK2)(9,VV[11],VV[10],MAKE_FIXNUM(V3),VV[9],(V1),VV[12],VV[23],VV[14],(V4))/*  X-ERROR*/);
	}
	}
}
/*	local function CLOSURE                                        */
static LC12(int narg, object V1, object V2)
{ VT5 VLEX5 CLSR5
	{register int V3;
	V3= fix(V2);
	{register object V4;                      /*  CURSOR          */
	L6(2,(V1),MAKE_FIXNUM(V3))                /*  LOOKUP-RESOURCE-ID*/;
	V4= VALUES(0);
	if(((V4))!=Cnil){
	goto L52;}
	(*LK5)(4,VV[9],(V1),VV[10],MAKE_FIXNUM(V3))/*  MAKE-CURSOR    */;
	V4= VALUES(0);
	RETURN(L7(3,(V1),MAKE_FIXNUM(V3),(V4))    /*  SAVE-ID         */);
L52:
	(*LK6)(1,(V4))                            /*  CURSOR-P        */;
	if(VALUES(0)==Cnil){
	goto L57;}
	VALUES(0) = (V4);
	RETURN(1);
L57:
	RETURN((*LK2)(9,VV[11],VV[10],MAKE_FIXNUM(V3),VV[9],(V1),VV[12],VV[21],VV[14],(V4))/*  X-ERROR*/);
	}
	}
}
/*	local function CLOSURE                                        */
static LC11(int narg, object V1, object V2)
{ VT6 VLEX6 CLSR6
	RETURN((*LK7)(4,VV[9],(V1),VV[10],(V2))   /*  MAKE-GCONTEXT   */);
}
/*	local function CLOSURE                                        */
static LC10(int narg, object V1, object V2)
{ VT7 VLEX7 CLSR7
	{register int V3;
	V3= fix(V2);
	{register object V4;                      /*  PIXMAP          */
	L6(2,(V1),MAKE_FIXNUM(V3))                /*  LOOKUP-RESOURCE-ID*/;
	V4= VALUES(0);
	if(((V4))!=Cnil){
	goto L61;}
	(*LK8)(4,VV[9],(V1),VV[10],MAKE_FIXNUM(V3))/*  MAKE-PIXMAP    */;
	V4= VALUES(0);
	RETURN(L7(3,(V1),MAKE_FIXNUM(V3),(V4))    /*  SAVE-ID         */);
L61:
	(*LK9)(1,(V4))                            /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L66;}
	VALUES(0) = (V4);
	RETURN(1);
L66:
	RETURN((*LK2)(9,VV[11],VV[10],MAKE_FIXNUM(V3),VV[9],(V1),VV[12],VV[18],VV[14],(V4))/*  X-ERROR*/);
	}
	}
}
/*	local function CLOSURE                                        */
static LC9(int narg, object V1, object V2)
{ VT8 VLEX8 CLSR8
	{register int V3;
	V3= fix(V2);
	{register object V4;                      /*  WINDOW          */
	L6(2,(V1),MAKE_FIXNUM(V3))                /*  LOOKUP-RESOURCE-ID*/;
	V4= VALUES(0);
	if(((V4))!=Cnil){
	goto L70;}
	(*LK10)(4,VV[9],(V1),VV[10],MAKE_FIXNUM(V3))/*  MAKE-WINDOW   */;
	V4= VALUES(0);
	RETURN(L7(3,(V1),MAKE_FIXNUM(V3),(V4))    /*  SAVE-ID         */);
L70:
	(*LK9)(1,(V4))                            /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L75;}
	VALUES(0) = (V4);
	RETURN(1);
L75:
	RETURN((*LK2)(9,VV[11],VV[10],MAKE_FIXNUM(V3),VV[9],(V1),VV[12],VV[16],VV[14],(V4))/*  X-ERROR*/);
	}
	}
}
/*	local function CLOSURE                                        */
static LC8(int narg, object V1, object V2)
{ VT9 VLEX9 CLSR9
	{register int V3;
	V3= fix(V2);
	{register object V4;                      /*  DRAWABLE        */
	L6(2,(V1),MAKE_FIXNUM(V3))                /*  LOOKUP-RESOURCE-ID*/;
	V4= VALUES(0);
	if(((V4))!=Cnil){
	goto L79;}
	(*LK11)(4,VV[9],(V1),VV[10],MAKE_FIXNUM(V3))/*  MAKE-DRAWABLE */;
	V4= VALUES(0);
	RETURN(L7(3,(V1),MAKE_FIXNUM(V3),(V4))    /*  SAVE-ID         */);
L79:
	(*LK9)(1,(V4))                            /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L84;}
	VALUES(0) = (V4);
	RETURN(1);
L84:
	RETURN((*LK2)(9,VV[11],VV[10],MAKE_FIXNUM(V3),VV[9],(V1),VV[12],VV[13],VV[14],(V4))/*  X-ERROR*/);
	}
	}
}
/*	function definition for INITIALIZE-RESOURCE-ALLOCATOR         */
static L1(int narg, object V1)
{ VT10 VLEX10 CLSR10
TTL:
	{volatile int V2;                         /*  ID-MASK         */
	V2= fix(((V1))->in.in_slots[31]);
	if((V2)==0){
	goto L88;}
	{volatile int V3;                         /*  FIRST           */
	volatile object V4;                       /*  MASK            */
	V3= 0;
	V4= MAKE_FIXNUM(V2);
L92:
	Loddp(1,(V4))                             /*  ODDP            */;
	if(VALUES(0)==Cnil){
	goto L93;}
	Linteger_length(1,(V4))                   /*  INTEGER-LENGTH  */;
	(*LK12)(2,VALUES(0),MAKE_FIXNUM(V3))      /*  BYTE            */;
	((V1))->in.in_slots[32]= VALUES(0);
	VALUES(0) = VALUES(0);
	RETURN(1);
L93:
	V3= (V3)+1;
	Lash(2,(V4),MAKE_FIXNUM(-1))              /*  SHIFT>>         */;
	V4= VALUES(0);
	goto L92;
	}
L88:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for RESOURCEALLOC                         */
static L2(int narg, object V1)
{ VT11 VLEX11 CLSR11
TTL:
	{object V2;
	V2= MAKE_FIXNUM((fix(((V1))->in.in_slots[33]))+(1));
	((V1))->in.in_slots[33]= (V2);
	VALUES(0) = (V2);
	}
	RETURN((*LK13)(3,VALUES(0),((V1))->in.in_slots[32],((V1))->in.in_slots[30])/*  DPB*/);
}
/*	macro definition for ALLOCATE-RESOURCE-ID                     */
static L3(int narg, object V1, object V2)
{ VT12 VLEX12 CLSR12
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= CAR(V3);
	Leval(1,(V6))                             /*  EVAL            */;
	if((memql(VALUES(0),VV[1]))==Cnil){
	goto L105;}
	{object V7= CONS(list(2,VV[3],list(3,VV[4],list(2,VV[5],(V4)),(V4))),Cnil);
	VALUES(0) = list(4,VV[2],(V7),list(4,VV[6],(V4),VV[3],(V5)),VV[3]);
	RETURN(1);}
L105:
	VALUES(0) = list(3,VV[4],list(2,VV[5],(V4)),(V4));
	RETURN(1);}
}
/*	macro definition for DEALLOCATE-RESOURCE-ID                   */
static L4(int narg, object V1, object V2)
{ VT13 VLEX13 CLSR13
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= CAR(V3);
	Leval(1,(V6))                             /*  EVAL            */;
	if((memql(VALUES(0),VV[1]))==Cnil){
	goto L109;}
	VALUES(0) = list(3,VV[7],(V4),(V5));
	RETURN(1);
L109:
	VALUES(0) = Cnil;
	RETURN(1);}
}
/*	function definition for DEALLOCATE-RESOURCE-ID-INTERNAL       */
static L5(int narg, object V1, object V2)
{ VT14 VLEX14 CLSR14
TTL:
	RETURN(Lremhash(2,(V2),((V1))->in.in_slots[34])/*  REMHASH    */);
}
/*	function definition for LOOKUP-RESOURCE-ID                    */
static L6(int narg, object V1, object V2)
{ VT15 VLEX15 CLSR15
TTL:
	RETURN(Lgethash(2,(V2),((V1))->in.in_slots[34])/*  GETHASH    */);
}
/*	function definition for SAVE-ID                               */
static L7(int narg, object V1, object V2, object V3)
{ VT16 VLEX16 CLSR16
TTL:
	RETURN(siLhash_set(3,(V2),((V1))->in.in_slots[34],(V3))/*  HASH-SET*/);
}
/*	function definition for ID-ATOM                               */
static L15(int narg, object V1, object V2)
{ VT17 VLEX17 CLSR17
TTL:
	RETURN(Lgethash(2,(V1),((V2))->in.in_slots[68])/*  GETHASH    */);
}
/*	function definition for ATOM-ID                               */
static L16(int narg, object V1, object V2)
{ VT18 VLEX18 CLSR18
TTL:
	if(((V1))==Cnil){
	goto L113;}
	if(!((type_of((V1))==t_symbol&&((V1))->s.s_hpack==keyword_package))){
	goto L114;}
L113:
	VALUES(0) = (V1);
	goto L112;
L114:
	(*LK14)(1,(V1))                           /*  KINTERN         */;
L112:
	RETURN(Lgethash(2,VALUES(0),((V2))->in.in_slots[25])/*  GETHASH*/);
}
/*	function definition for SET-ATOM-ID                           */
static L17(int narg, object V1, object V2, object V3)
{ VT19 VLEX19 CLSR19
	{int V4;
	V4= fix(V3);
TTL:
	{object V5;                               /*  ATOM            */
	if(((V1))==Cnil){
	goto L119;}
	if(!((type_of((V1))==t_symbol&&((V1))->s.s_hpack==keyword_package))){
	goto L120;}
L119:
	V5= (V1);
	goto L118;
L120:
	(*LK14)(1,(V1))                           /*  KINTERN         */;
	V5= VALUES(0);
L118:
	siLhash_set(3,MAKE_FIXNUM(V4),((V2))->in.in_slots[68],(V5))/*  HASH-SET*/;
	siLhash_set(3,(V5),((V2))->in.in_slots[25],MAKE_FIXNUM(V4))/*  HASH-SET*/;
	VALUES(0) = MAKE_FIXNUM(V4);
	RETURN(1);
	}
	}
}
/*	function definition for INITIALIZE-PREDEFINED-ATOMS           */
static L18(int narg, object V1)
{ VT20 VLEX20 CLSR20
TTL:
	{volatile int V2;
	volatile int V3;                          /*  I               */
	V2= (VV[32])->v.v_fillp;
	V3= 0;
L129:
	if(!((V3)>=(V2))){
	goto L130;}
	VALUES(0) = Cnil;
	RETURN(1);
L130:
	L17(3,(VV[32])->v.v_self[V3],(V1),MAKE_FIXNUM(V3))/*  SET-ATOM-ID*/;
	V3= (V3)+1;
	goto L129;
	}
}
/*	function definition for VISUAL-INFO                           */
static L19(int narg, object V1, object V2)
{ VT21 VLEX21 CLSR21
	{volatile int V3;
	V3= fix(V2);
TTL:
	if(!((V3)==0)){
	goto L137;}
	VALUES(0) = Cnil;
	RETURN(1);
L137:
	{volatile object V4;
	volatile object V5;                       /*  SCREEN          */
	V4= ((V1))->in.in_slots[40];
	V5= Cnil;
L144:
	if(!((V4)==Cnil)){
	goto L145;}
	goto L140;
L145:
	V5= CAR((V4));
	{volatile object V7;
	volatile object V8;                       /*  DEPTH           */
	V7= ((V5))->in.in_slots[5];
	V8= Cnil;
L154:
	if(!((V7)==Cnil)){
	goto L155;}
	goto L150;
L155:
	V8= CAR((V7));
	{volatile object V10;
	volatile object V11;                      /*  VISUAL-INFO     */
	V10= CDR((V8));
	V11= Cnil;
L164:
	if(!((V10)==Cnil)){
	goto L165;}
	goto L160;
L165:
	V11= CAR((V10));
	if(!((V3)==(fix(((V11))->in.in_slots[0])))){
	goto L170;}
	VALUES(0) = (V11);
	RETURN(1);
L170:
	V10= CDR((V10));
	goto L164;
	}
L160:
	V7= CDR((V7));
	goto L154;
	}
L150:
	V4= CDR((V4));
	goto L144;
	}
L140:
	RETURN(Lerror(3,VV[35],MAKE_FIXNUM(V3),(V1))/*  ERROR         */);
	}
}
/*	macro definition for WITH-DISPLAY                             */
static L20(int narg, object V1, object V2)
{ VT22 VLEX22 CLSR22
	{object V3=CDR(V1),V4,V5,V6,V7;
	{object V8= CAR(V3);
	V4= CAR(V8);
	V8=CDR(V8);
	{object V9;
	V9=getf(V8,VV[37],OBJNULL);
	if(V9==OBJNULL){
	V5= Cnil;
	} else {
	V5= V9;}
	V9=getf(V8,VV[38],OBJNULL);
	if(V9==OBJNULL){
	V6= Cnil;
	} else {
	V6= V9;}}}
	V3=CDR(V3);
	V7= V3;
	if((V5)==Cnil){
	T0= Cnil;
	goto L184;}
	T0= list(2,VV[37],(V5));
L184:
	if((V6)==Cnil){
	VALUES(0) = Cnil;
	goto L185;}
	VALUES(0) = list(2,VV[38],(V6));
L185:
	VALUES(0) = listA(3,VV[36],CONS((V4),append(T0,VALUES(0))),(V7));
	RETURN(1);}
}
/*	macro definition for WITH-EVENT-QUEUE                         */
static L21(int narg, object V1, object V2)
{ VT23 VLEX23 CLSR23
	{object V3=CDR(V1),V4,V5,V6,V7;
	{object V8= CAR(V3);
	V4= CAR(V8);
	V8=CDR(V8);
	{object V9;
	V9=getf(V8,VV[37],OBJNULL);
	if(V9==OBJNULL){
	V5= Cnil;
	} else {
	V5= V9;}
	V9=getf(V8,VV[38],OBJNULL);
	if(V9==OBJNULL){
	V6= Cnil;
	} else {
	V6= V9;}}}
	V3=CDR(V3);
	V7= V3;
	if(((V6))!=Cnil){
	goto L190;}
	Lmacroexpand(2,VV[42],(V2))               /*  MACROEXPAND     */;
	if(VALUES(0)==Cnil){
	goto L190;}
	{object V10= CONS(listA(3,VV[44],Cnil,(V7)),Cnil);
	VALUES(0) = list(3,VV[43],(V10),list(4,VV[45],(V4),(V5),VV[46]));
	goto L188;}
L190:
	{register object V11;                     /*  DISP            */
	if(type_of((V4))==t_symbol){
	goto L195;}
	Lconstantp(1,(V4))                        /*  CONSTANTP       */;
	if(VALUES(0)==Cnil){
	goto L196;}
L195:
	V11= (V4);
	goto L194;
L196:
	V11= VV[47];
L194:
	if(((V11))==((V4))){
	goto L202;}
	T0= CONS(list(2,(V11),(V4)),Cnil);
	goto L200;
L202:
	T0= Cnil;
L200:
	{object V12= list(2,VV[49],(V11));
	if((V5)==Cnil){
	VALUES(0) = Cnil;
	goto L204;}
	VALUES(0) = list(2,VV[37],(V5));
L204:
	VALUES(0) = list(3,VV[2],T0,listA(3,VV[48],listA(4,(V12),(V11),VV[50],VALUES(0)),(V7)));}
	}
L188:
	VALUES(0) = list(3,VV[40],VV[41],VALUES(0));
	RETURN(1);}
}
/*	function definition for WITH-EVENT-QUEUE-FUNCTION             */
static L22(int narg, object V1, object V2, object V3)
{ VT24 VLEX24 CLSR24
TTL:
	RETURN(funcall(1,(V3)));
}
/*	macro definition for WITH-EVENT-QUEUE-INTERNAL                */
static L23(int narg, object V1, object V2)
{ VT25 VLEX25 CLSR25
	{object V3=CDR(V1),V4,V5,V6;
	{object V7= CAR(V3);
	V4= CAR(V7);
	V7=CDR(V7);
	{object V8;
	V8=getf(V7,VV[37],OBJNULL);
	if(V8==OBJNULL){
	V5= Cnil;
	} else {
	V5= V8;}}}
	V3=CDR(V3);
	V6= V3;
	{register object V9;                      /*  DISP            */
	if(type_of((V4))==t_symbol){
	goto L207;}
	Lconstantp(1,(V4))                        /*  CONSTANTP       */;
	if(VALUES(0)==Cnil){
	goto L208;}
L207:
	V9= (V4);
	goto L206;
L208:
	V9= VV[47];
L206:
	if(((V9))==((V4))){
	goto L214;}
	T0= CONS(list(2,(V9),(V4)),Cnil);
	goto L212;
L214:
	T0= Cnil;
L212:
	{object V10= list(2,VV[51],(V9));
	if((V5)==Cnil){
	VALUES(0) = Cnil;
	goto L216;}
	VALUES(0) = list(2,VV[37],(V5));
L216:
	VALUES(0) = list(3,VV[2],T0,listA(3,VV[48],listA(4,(V10),(V9),VV[52],VALUES(0)),(V6)));
	RETURN(1);}
	}}
}
/*	function definition for OPEN-DISPLAY                          */
static L24(int narg, object V1, ...)
{ VT26 VLEX26 CLSR26
	{volatile object V2;
	volatile object V3;
	volatile object V4;
	volatile object V5;
	volatile object V6;
	va_list args; va_start(args, V1);
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ int n=narg; object p=V2;
	 for(;n-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{ object keyvars[8];
	va_start(args,V1);
	parse_key(narg,args,4,L24keys,keyvars,V2,TRUE);
	if(keyvars[4]==Cnil){
	V3= MAKE_FIXNUM(0);
	}else{
	V3= keyvars[0];}
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	}
	{volatile object V7;                      /*  STREAM          */
	volatile object V8;                       /*  DISP            */
	volatile object V9;                       /*  OK-P            */
	(*LK15)(3,(V1),(V3),(V4))                 /*  OPEN-X-STREAM   */;
	V7= VALUES(0);
	VALUES(0) = (VV[159]->s.s_gfdef);
	Lapply(14,VALUES(0),(VV[53]->s.s_dbind),VV[54],VV[55],(V1),VV[9],(V3),VV[56],(V7),VV[57],(V7),VV[58],Ct,(V2))/*  APPLY*/;
	V8= VALUES(0);
	V9= Cnil;
	{ int V10; volatile bool unwinding = FALSE;
	if ((V10=frs_push(FRS_PROTECT,Cnil))) {
	V10--; unwinding = TRUE;} else {
	L27(5,(V8),VV[59],(V5),VV[60],(V6))       /*  DISPLAY-CONNECT */;
	L1(1,(V8))                                /*  INITIALIZE-RESOURCE-ALLOCATOR*/;
	L18(1,(V8))                               /*  INITIALIZE-PREDEFINED-ATOMS*/;
	(*LK16)(1,(V8))                           /*  INITIALIZE-EXTENSIONS*/;
	V9= Ct;
	VALUES(0)=Ct;
	V10=1;
	}
	frs_pop();
	MV_SAVE(V10);
	if(((V9))!=Cnil){
	goto L229;}
	L26(3,(V8),VV[61],Ct)                     /*  CLOSE-DISPLAY   */;
L229:
	MV_RESTORE(V10);
	if (unwinding) unwind(nlj_fr,nlj_tag,V10+1);
	else {}}
	VALUES(0) = (V8);
	RETURN(1);
	}
	}
}
/*	function definition for DISPLAY-FORCE-OUTPUT                  */
static L25(int narg, object V1)
{ VT27 VLEX27 CLSR27
TTL:
	if((((V1))->in.in_slots[10])==Cnil){
	goto L232;}
	(*LK2)(3,VV[63],VV[9],(V1))               /*  X-ERROR         */;
L232:
	RETURN((*LK17)(1,(V1))                    /*  BUFFER-FORCE-OUTPUT*/);
}
/*	function definition for CLOSE-DISPLAY                         */
static L26(int narg, object V1, ...)
{ VT28 VLEX28 CLSR28
	{object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[2];
	parse_key(narg,args,1,L26keys,keyvars,OBJNULL,FALSE);
	V2= keyvars[0];
	}
	RETURN((*LK18)(3,(V1),VV[61],(V2))        /*  CLOSE-BUFFER    */);
	}
}
/*	function definition for DISPLAY-CONNECT                       */
static L27(int narg, object V1, ...)
{ VT29 VLEX29 CLSR29
	{volatile object V2;
	volatile object V3;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[4];
	parse_key(narg,args,2,L27keys,keyvars,OBJNULL,FALSE);
	V2= keyvars[0];
	V3= keyvars[1];
	}
	if(((V2))!=Cnil){
	goto L235;}
	V2= VV[64];
L235:
	if(((V3))!=Cnil){
	goto L239;}
	V3= VV[65];
L239:
	{object V4;                               /*  %BUFFER         */
	{int V5;                                  /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= fix(((V1))->in.in_slots[6]);
	V6= ((V1))->in.in_slots[7];
	{object V7= ((V1))->in.in_slots[36];
	if((V7!= VV[166]))goto L251;
	T0= MAKE_FIXNUM(108);
	goto L250;
L251:
	if((V7!= VV[167]))goto L252;
	T0= MAKE_FIXNUM(66);
	goto L250;
L252:
	FEerror("The ECASE key value ~s is illegal.",1,V7);}
L250:
	(((V6))->ust.ust_self[(V5)+(0)]=(fix(T0)));
	{object V7= (VV[66]->s.s_dbind);
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(2))))=fix(V7));}
	{object V7= (VV[67]->s.s_dbind);
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(4))))=fix(V7));}
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(6))))=length((V2)));
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(8))))=length((V3)));
	(*LK19)(3,(V1),MAKE_FIXNUM(12),(V2))      /*  WRITE-SEQUENCE-CHAR*/;
	(*LK19)(3,(V1),MAKE_FIXNUM(((((12)+(length((V2))))+(3)) & (-4))),(V3))/*  WRITE-SEQUENCE-CHAR*/;
	}
	}
	(*LK17)(1,(V1))                           /*  BUFFER-FORCE-OUTPUT*/;
	{volatile object V4;                      /*  REPLY-BUFFER    */
	V4= Cnil;
	{ int V5; volatile bool unwinding = FALSE;
	if ((V5=frs_push(FRS_PROTECT,Cnil))) {
	V5--; unwinding = TRUE;} else {
	(*LK20)(1,MAKE_FIXNUM(4096))              /*  ALLOCATE-REPLY-BUFFER*/;
	V4= VALUES(0);
	{volatile object V6;                      /*  %REPLY-BUFFER   */
	{volatile int V7;                         /*  BUFFER-BOFFSET  */
	volatile object V8;                       /*  BUFFER-BBUF     */
	V7= 0;
	V8= ((V4))->in.in_slots[1];
	(*LK21)(4,(V1),(V8),MAKE_FIXNUM(0),MAKE_FIXNUM(8))/*  BUFFER-INPUT*/;
	{volatile object V9;                      /*  SUCCESS         */
	volatile object V10;
	volatile int V11;                         /*  REASON-LENGTH   */
	volatile int V12;                         /*  MAJOR-VERSION   */
	volatile int V13;                         /*  MINOR-VERSION   */
	volatile object V14;                      /*  TOTAL-LENGTH    */
	volatile object V15;                      /*  VENDOR-LENGTH   */
	volatile int V16;                         /*  NUM-ROOTS       */
	volatile int V17;                         /*  NUM-FORMATS     */
	V10= ((((V8))->ust.ust_self[(V7)+(0)])>0?Ct:Cnil);
	V11= ((V8))->ust.ust_self[(V7)+(1)];
	V12= (*(unsigned short *)(((V8))->ust.ust_self+((V7)+(2))));
	V13= (*(unsigned short *)(((V8))->ust.ust_self+((V7)+(4))));
	V14= MAKE_FIXNUM((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(6)))));
	V16= 0;
	V17= 0;
	V9= V10;
	V15= Cnil;
	if(((V9))!=Cnil){
	goto L275;}
	T0= ((V1))->in.in_slots[18];
	T1= ((V1))->in.in_slots[19];
	(*LK21)(4,(V1),(V8),MAKE_FIXNUM(0),MAKE_FIXNUM(V11))/*  BUFFER-INPUT*/;
	(*LK22)(7,(V4),VV[73],MAKE_FIXNUM(V11),Cnil,Cnil,MAKE_FIXNUM(0),MAKE_FIXNUM(0))/*  READ-SEQUENCE-CHAR*/;
	(*LK2)(11,VV[69],VV[70],MAKE_FIXNUM(V12),VV[71],MAKE_FIXNUM(V13),VV[55],T0,VV[9],T1,VV[72],VALUES(0))/*  X-ERROR*/;
L275:
	(*LK21)(4,(V1),(V8),MAKE_FIXNUM(0),MAKE_FIXNUM(32))/*  BUFFER-INPUT*/;
	((V1))->in.in_slots[27]= MAKE_FIXNUM(V12);
	((V1))->in.in_slots[28]= MAKE_FIXNUM(V13);
	((V1))->in.in_slots[37]= MAKE_FIXNUM((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(0)))));
	(*(unsigned long *)(((V8))->ust.ust_self+((V7)+(0))));
	((V1))->in.in_slots[30]= MAKE_FIXNUM((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(4)))));
	(*(unsigned long *)(((V8))->ust.ust_self+((V7)+(4))));
	((V1))->in.in_slots[31]= MAKE_FIXNUM((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(8)))));
	(*(unsigned long *)(((V8))->ust.ust_self+((V7)+(8))));
	((V1))->in.in_slots[41]= MAKE_FIXNUM((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(12)))));
	(*(unsigned long *)(((V8))->ust.ust_self+((V7)+(12))));
	V15= MAKE_FIXNUM((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(16)))));
	((V1))->in.in_slots[38]= MAKE_FIXNUM((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(18)))));
	(*(unsigned short *)(((V8))->ust.ust_self+((V7)+(18))));
	V16= ((V8))->ust.ust_self[(V7)+(20)];
	V17= ((V8))->ust.ust_self[(V7)+(21)];
	((V1))->in.in_slots[43]= ((((V8))->ust.ust_self[(V7)+(22)])==0?Ct:Cnil);
	{object V18;                              /*  FORMAT          */
	V18= ((V1))->in.in_slots[44];
	((V18))->in.in_slots[2]= ((((V8))->ust.ust_self[(V7)+(23)])==0?Ct:Cnil);
	((V18))->in.in_slots[0]= MAKE_FIXNUM(((V8))->ust.ust_self[(V7)+(24)]);
	((V8))->ust.ust_self[(V7)+(24)];
	((V18))->in.in_slots[1]= MAKE_FIXNUM(((V8))->ust.ust_self[(V7)+(25)]);
	((V8))->ust.ust_self[(V7)+(25)];
	}
	((V1))->in.in_slots[46]= MAKE_FIXNUM(((V8))->ust.ust_self[(V7)+(26)]);
	((V8))->ust.ust_self[(V7)+(26)];
	((V1))->in.in_slots[47]= MAKE_FIXNUM(((V8))->ust.ust_self[(V7)+(27)]);
	((V8))->ust.ust_self[(V7)+(27)];
	(*LK21)(4,(V1),(V8),MAKE_FIXNUM(0),MAKE_FIXNUM((((fix((V15)))+(3)) & (-4))))/*  BUFFER-INPUT*/;
	(*LK22)(7,(V4),VV[73],(V15),Cnil,Cnil,MAKE_FIXNUM(0),MAKE_FIXNUM(0))/*  READ-SEQUENCE-CHAR*/;
	((V1))->in.in_slots[29]= VALUES(0);
	{volatile int V18;
	volatile int V19;                         /*  I               */
	V18= V17;
	V19= 0;
L310:
	if(!((V19)>=(V18))){
	goto L311;}
	goto L306;
L311:
	(*LK21)(4,(V1),(V8),MAKE_FIXNUM(0),MAKE_FIXNUM(8))/*  BUFFER-INPUT*/;
	{object V21;
	object V22;
	V21= (V1);
	{int V23= ((V8))->ust.ust_self[(V7)+(0)];
	{int V24= ((V8))->ust.ust_self[(V7)+(1)];
	(*LK23)(6,VV[75],MAKE_FIXNUM(V23),VV[76],MAKE_FIXNUM(V24),VV[77],MAKE_FIXNUM(((V8))->ust.ust_self[(V7)+(2)]))/*  MAKE-PIXMAP-FORMAT*/;
	V22= CONS(VALUES(0),((V21))->in.in_slots[45]);}}
	((V21))->in.in_slots[45]= (V22);
	}
	V19= (V19)+1;
	goto L310;
	}
L306:
	{object V18= nreverse(((V1))->in.in_slots[45]);
	((V1))->in.in_slots[45]= (V18);}
	{volatile int V18;
	volatile int V19;                         /*  I               */
	V18= V16;
	V19= 0;
L327:
	if(!((V19)>=(V18))){
	goto L328;}
	goto L323;
L328:
	(*LK21)(4,(V1),(V8),MAKE_FIXNUM(0),MAKE_FIXNUM(40))/*  BUFFER-INPUT*/;
	{volatile int V21;                        /*  ROOT-ID         */
	volatile object V22;                      /*  ROOT            */
	volatile int V23;                         /*  ROOT-VISUAL     */
	volatile int V24;                         /*  DEFAULT-COLORMAP-ID*/
	volatile object V25;                      /*  DEFAULT-COLORMAP*/
	volatile object V26;                      /*  SCREEN          */
	volatile object V27;                      /*  NUM-DEPTHS      */
	volatile object V28;                      /*  DEPTHS          */
	V21= (*(unsigned long *)(((V8))->ust.ust_self+((V7)+(0))));
	(*LK10)(4,VV[10],MAKE_FIXNUM(V21),VV[9],(V1))/*  MAKE-WINDOW  */;
	V22= VALUES(0);
	V23= (*(unsigned long *)(((V8))->ust.ust_self+((V7)+(32))));
	V24= (*(unsigned long *)(((V8))->ust.ust_self+((V7)+(4))));
	(*LK3)(4,VV[10],MAKE_FIXNUM(V24),VV[9],(V1))/*  MAKE-COLORMAP */;
	V25= VALUES(0);
	{int V29= (*(unsigned long *)(((V8))->ust.ust_self+((V7)+(8))));
	{int V30= (*(unsigned long *)(((V8))->ust.ust_self+((V7)+(12))));
	{int V31= (*(unsigned long *)(((V8))->ust.ust_self+((V7)+(16))));
	{int V32= (*(unsigned short *)(((V8))->ust.ust_self+((V7)+(20))));
	{int V33= (*(unsigned short *)(((V8))->ust.ust_self+((V7)+(22))));
	{int V34= (*(unsigned short *)(((V8))->ust.ust_self+((V7)+(24))));
	{int V35= (*(unsigned short *)(((V8))->ust.ust_self+((V7)+(26))));
	{int V36= (*(unsigned short *)(((V8))->ust.ust_self+((V7)+(28))));
	{int V37= (*(unsigned short *)(((V8))->ust.ust_self+((V7)+(30))));
	{int V38;
	V38= ((V8))->ust.ust_self[(V7)+(36)];
	if((V38)<(3)){
	goto L341;}
	T0= Cnil;
	goto L339;
L341:
	T0= (VV[90])->v.v_self[V38];
	}
L339:
	{object V38= ((((V8))->ust.ust_self[(V7)+(37)])>0?Ct:Cnil);
	(*LK24)(28,VV[78],(V22),VV[79],(V25),VV[80],MAKE_FIXNUM(V29),VV[81],MAKE_FIXNUM(V30),VV[82],MAKE_FIXNUM(V31),VV[83],MAKE_FIXNUM(V32),VV[84],MAKE_FIXNUM(V33),VV[85],MAKE_FIXNUM(V34),VV[86],MAKE_FIXNUM(V35),VV[87],MAKE_FIXNUM(V36),VV[88],MAKE_FIXNUM(V37),VV[89],T0,VV[91],(V38),VV[92],MAKE_FIXNUM(((V8))->ust.ust_self[(V7)+(38)]))/*  MAKE-SCREEN*/;
	V26= VALUES(0);}}}}}}}}}}
	V27= MAKE_FIXNUM(((V8))->ust.ust_self[(V7)+(39)]);
	V28= Cnil;
	L7(3,(V1),MAKE_FIXNUM(V21),(V22))         /*  SAVE-ID         */;
	L7(3,(V1),MAKE_FIXNUM(V24),(V25))         /*  SAVE-ID         */;
	{volatile int V29;
	volatile int V30;                         /*  J               */
	V29= fix((V27));
	V30= 0;
L351:
	if(!((V30)>=(V29))){
	goto L352;}
	goto L347;
L352:
	(*LK21)(4,(V1),(V8),MAKE_FIXNUM(0),MAKE_FIXNUM(8))/*  BUFFER-INPUT*/;
	{volatile int V32;                        /*  DEPTH           */
	volatile int V33;                         /*  NUM-VISUALS     */
	volatile object V34;                      /*  VISUALS         */
	V32= ((V8))->ust.ust_self[(V7)+(0)];
	V33= (*(unsigned short *)(((V8))->ust.ust_self+((V7)+(2))));
	V34= Cnil;
	{volatile int V35;
	volatile int V36;                         /*  K               */
	V35= V33;
	V36= 0;
L363:
	if(!((V36)>=(V35))){
	goto L364;}
	goto L359;
L364:
	(*LK21)(4,(V1),(V8),MAKE_FIXNUM(0),MAKE_FIXNUM(24))/*  BUFFER-INPUT*/;
	{register int V38;                        /*  VISUAL          */
	register object V39;                      /*  VISUAL-INFO     */
	V38= (*(unsigned long *)(((V8))->ust.ust_self+((V7)+(0))));
	{register int V40;
	V40= ((V8))->ust.ust_self[(V7)+(4)];
	if((V40)<(6)){
	goto L373;}
	T0= Cnil;
	goto L371;
L373:
	T0= (VV[94])->v.v_self[V40];
	}
L371:
	{int V40= ((V8))->ust.ust_self[(V7)+(5)];
	{int V41= (*(unsigned short *)(((V8))->ust.ust_self+((V7)+(6))));
	{int V42= (*(unsigned long *)(((V8))->ust.ust_self+((V7)+(8))));
	{int V43= (*(unsigned long *)(((V8))->ust.ust_self+((V7)+(12))));
	(*LK25)(16,VV[10],MAKE_FIXNUM(V38),VV[9],(V1),VV[93],T0,VV[95],MAKE_FIXNUM(V40),VV[96],MAKE_FIXNUM(V41),VV[97],MAKE_FIXNUM(V42),VV[98],MAKE_FIXNUM(V43),VV[99],MAKE_FIXNUM((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(16))))))/*  MAKE-VISUAL-INFO*/;
	V39= VALUES(0);}}}}
	V34= CONS((V39),(V34));
	if(!((V23)==(V38))){
	goto L368;}
	((V25))->in.in_slots[2]= (V39);
	VALUES(0) = (V39);
	((V26))->in.in_slots[7]= VALUES(0);
	}
L368:
	V36= (V36)+1;
	goto L363;
	}
L359:
	V28= CONS(CONS(MAKE_FIXNUM(V32),nreverse((V34))),(V28));
	}
	V30= (V30)+1;
	goto L351;
	}
L347:
	{object V29= nreverse((V28));
	((V26))->in.in_slots[5]= (V29);}
	{object V29;
	object V30;
	V29= (V1);
	V30= CONS((V26),((V29))->in.in_slots[40]);
	((V29))->in.in_slots[40]= (V30);
	}
	}
	V19= (V19)+1;
	goto L327;
	}
L323:
	{object V18= nreverse(((V1))->in.in_slots[40]);
	((V1))->in.in_slots[40]= (V18);}
	((V1))->in.in_slots[39]= CAR(((V1))->in.in_slots[40]);
	VALUES(0)=CAR(((V1))->in.in_slots[40]);
	V5=1;
	}
	}
	}
	}
	frs_pop();
	MV_SAVE(V5);
	if(((V4))==Cnil){
	goto L394;}
	(*LK26)(1,(V4))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L394:
	MV_RESTORE(V5);
	if (unwinding) unwind(nlj_fr,nlj_tag,V5+1);
	else {}}
	}
	VALUES(0) = (V1);
	RETURN(1);
	}
}
/*	function definition for DISPLAY-PROTOCOL-VERSION              */
static L28(int narg, object V1)
{ VT30 VLEX30 CLSR30
TTL:
	VALUES(1) = ((V1))->in.in_slots[28];
	VALUES(0) = ((V1))->in.in_slots[27];
	RETURN(2);
}
/*	function definition for DISPLAY-VENDOR                        */
static L29(int narg, object V1)
{ VT31 VLEX31 CLSR31
TTL:
	VALUES(1) = ((V1))->in.in_slots[37];
	VALUES(0) = ((V1))->in.in_slots[29];
	RETURN(2);
}
/*	function definition for DISPLAY-NSCREENS                      */
static L30(int narg, object V1)
{ VT32 VLEX32 CLSR32
TTL:
	VALUES(0) = MAKE_FIXNUM(length(((V1))->in.in_slots[40]));
	RETURN(1);
}
/*	function definition for DISPLAY-INVOKE-AFTER-FUNCTION         */
static L31(int narg, object V1)
{ VT33 VLEX33 CLSR33
	bds_check;
TTL:
	if((((V1))->in.in_slots[20])==Cnil){
	goto L398;}
	if(((VV[100]->s.s_dbind))!=Cnil){
	goto L398;}
	bds_bind(VV[100],Ct);                     /*  *INSIDE-DISPLAY-AFTER-FUNCTION**/
	T0= ((V1))->in.in_slots[20];
	{int V2;
	V2=funcall(2,T0,(V1));
	bds_unwind1;
	RETURN(V2);}
L398:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for DISPLAY-FINISH-OUTPUT                 */
static L32(int narg, object V1)
{ VT34 VLEX34 CLSR34
TTL:
	{volatile object V2;                      /*  .DISPLAY.       */
	volatile object V3;                       /*  .PENDING-COMMAND.*/
	volatile object V4;                       /*  .REPLY-BUFFER.  */
	V2= (V1);
	V3= Cnil;
	V4= Cnil;
	{ int V5; volatile bool unwinding = FALSE;
	if ((V5=frs_push(FRS_PROTECT,Cnil))) {
	V5--; unwinding = TRUE;} else {
	if((((V2))->in.in_slots[10])==Cnil){
	goto L406;}
	(*LK2)(3,VV[63],VV[9],(V2))               /*  X-ERROR         */;
L406:
	(*LK27)(1,(V2))                           /*  START-PENDING-COMMAND*/;
	V3= VALUES(0);
	{register object V6;                      /*  %BUFFER         */
	V6= (V2);
	if(!(((fix(((V6))->in.in_slots[6]))+(160))>=(fix(((V6))->in.in_slots[2])))){
	goto L412;}
	(*LK28)(1,(V6))                           /*  BUFFER-FLUSH    */;
L412:
	{register int V7;                         /*  BUFFER-BOFFSET  */
	object V8;                                /*  BUFFER-BBUF     */
	V7= fix(((V6))->in.in_slots[6]);
	V8= ((V6))->in.in_slots[7];
	((V2))->in.in_slots[4]= MAKE_FIXNUM(V7);
	(((V8))->ust.ust_self[(V7)+(0)]=(43));
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(2))))=1);
	((V2))->in.in_slots[6]= MAKE_FIXNUM((V7)+(4));
	(*LK29)(1,(V2))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK17)(1,(V2))                           /*  BUFFER-FORCE-OUTPUT*/;
	L31(1,(V2))                               /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK30)(2,(V2),(V3))                      /*  READ-REPLY      */;
	V4= VALUES(0);
	{object V6;                               /*  %REPLY-BUFFER   */
	object V7;                                /*  %BUFFER         */
	{object V8;                               /*  BUFFER-BBUF     */
	V8= ((V4))->in.in_slots[1];
	VALUES(0)=Cnil;
	V5=1;
	}
	}
	}
	frs_pop();
	MV_SAVE(V5);
	if(((V4))==Cnil){
	goto L431;}
	(*LK26)(1,(V4))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L431:
	if(((V3))==Cnil){
	goto L430;}
	(*LK31)(2,(V2),(V3))                      /*  STOP-PENDING-COMMAND*/;
L430:
	MV_RESTORE(V5);
	if (unwinding) unwind(nlj_fr,nlj_tag,V5+1);
	else {}}
	}
	RETURN((*LK32)(2,(V1),VV[101])            /*  REPORT-ASYNCHRONOUS-ERRORS*/);
}
static LKF32(int narg, ...) {TRAMPOLINK(VV[186],&LK32);}
static LKF31(int narg, ...) {TRAMPOLINK(VV[185],&LK31);}
static LKF30(int narg, ...) {TRAMPOLINK(VV[184],&LK30);}
static LKF29(int narg, ...) {TRAMPOLINK(VV[183],&LK29);}
static LKF28(int narg, ...) {TRAMPOLINK(VV[182],&LK28);}
static LKF27(int narg, ...) {TRAMPOLINK(VV[181],&LK27);}
static LKF26(int narg, ...) {TRAMPOLINK(VV[175],&LK26);}
static LKF25(int narg, ...) {TRAMPOLINK(VV[174],&LK25);}
static LKF24(int narg, ...) {TRAMPOLINK(VV[173],&LK24);}
static LKF23(int narg, ...) {TRAMPOLINK(VV[172],&LK23);}
static LKF22(int narg, ...) {TRAMPOLINK(VV[171],&LK22);}
static LKF21(int narg, ...) {TRAMPOLINK(VV[170],&LK21);}
static LKF20(int narg, ...) {TRAMPOLINK(VV[169],&LK20);}
static LKF19(int narg, ...) {TRAMPOLINK(VV[168],&LK19);}
static LKF18(int narg, ...) {TRAMPOLINK(VV[164],&LK18);}
static LKF17(int narg, ...) {TRAMPOLINK(VV[162],&LK17);}
static LKF16(int narg, ...) {TRAMPOLINK(VV[160],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[158],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[151],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[145],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[143],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[142],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[141],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[140],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[139],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[138],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[137],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[136],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[135],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[134],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[133],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[132],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[131],&LK0);}
