
/* (c) Copyright G. Attardi, 1993. */
#define VT2
#define VLEX2
#define CLSR2
static L1(int, object);
#define VT3
#define VLEX3
#define CLSR3
static L2(int, object, object, object);
int Lchar_code();
int Lchar_code();
#define VT4 object T0;
#define VLEX4
#define CLSR4
static L3(int, object);
#define VT5
#define VLEX5
#define CLSR5
static L4(int, object);
int Lfifth();
#define VT6
#define VLEX6
#define CLSR6
static L5(int, object, object);
#define VT7
#define VLEX7
#define CLSR7
static L6(int, object, object, object, object, object);
int Lgensym();
int Lmake_list();
#define VT8 object T0;
#define VLEX8
#define CLSR8
static L7(int, object);
#define VT9
#define VLEX9
#define CLSR9
static L8(int, object);
#define VT10
#define VLEX10
#define CLSR10
static L9(int, object);
#define VT11
#define VLEX11
#define CLSR11
static L10(int, object);
#define VT12
#define VLEX12
#define CLSR12
static L11(int, object);
#define VT13
#define VLEX13
#define CLSR13
static L12(int, object);
#define VT14
#define VLEX14
#define CLSR14
static L13(int, object, object);
#define VT15
#define VLEX15
#define CLSR15
static L14(int, object);
#define VT16
#define VLEX16
#define CLSR16
static L15(int, object, object);
#define VT17
#define VLEX17
#define CLSR17
static L16(int, object);
int Lmonotonically_nondecreasing();
#define VT18
#define VLEX18
#define CLSR18
static L17(int, object);
int Lmonotonically_nondecreasing();
#define VT19
#define VLEX19
#define CLSR19
static L18(int, object);
int Lmonotonically_nondecreasing();
#define VT20
#define VLEX20
#define CLSR20
static L19(int, object, object);
#define VT21
#define VLEX21
#define CLSR21
static L20(int, object);
int Lmonotonically_nondecreasing();
#define VT22
#define VLEX22
#define CLSR22
static L21(int, object, object);
#define VT23
#define VLEX23
#define CLSR23
static L22(int, object);
int Lconstantp();
int Leval();
#define VT24
#define VLEX24
#define CLSR24
static L23(int, object, object);
int Lash();
#define VT25
#define VLEX25
#define CLSR25
static L25(int, object);
int Lconstantp();
int Leval();
#define VT26
#define VLEX26
#define CLSR26
static L26(int, object);
#define VT27
#define VLEX27
#define CLSR27
static LC27(int, object );
#define VT28
#define VLEX28
#define CLSR28
static L28(int, object);
#define VT29
#define VLEX29
#define CLSR29
static L29(int, object);
int Llast();
int Lbutlast();
#define VT30
#define VLEX30
#define CLSR30
static LC30(int, object );
int Llast();
int Lbutlast();
#define VT31 object T0;
#define VLEX31
#define CLSR31
static L31(int, object);
int Lconstantp();
#define VT32
#define VLEX32
#define CLSR32
static L32(int, object);
int Lgensym();
#define VT33
#define VLEX33
#define CLSR33
static LC33(int, object );
int Lconstantp();
int Leval();
#define VT34
#define VLEX34
#define CLSR34
static L34(int, object);
int Linteger_length();
#define VT35
#define VLEX35
#define CLSR35
static L35(int, object);
#define VT36
#define VLEX36
#define CLSR36
static L36(int, object);
#define VT37
#define VLEX37
#define CLSR37
static L37(int, object, object);
#define VT38
#define VLEX38
#define CLSR38
static L38(int, object);
#define VT39
#define VLEX39
#define CLSR39
static L39(int, object);
#define VT40
#define VLEX40
#define CLSR40
static struct codeblock Cblock;
#define VM40 0
#define VM39 0
#define VM38 0
#define VM37 0
#define VM36 0
#define VM35 0
#define VM34 0
#define VM33 0
#define VM32 0
#define VM31 1
#define VM30 0
#define VM29 0
#define VM28 0
#define VM27 0
#define VM26 0
#define VM25 0
#define VM24 0
#define VM23 0
#define VM22 0
#define VM21 0
#define VM20 0
#define VM19 0
#define VM18 0
#define VM17 0
#define VM16 0
#define VM15 0
#define VM14 0
#define VM13 0
#define VM12 0
#define VM11 0
#define VM10 0
#define VM9 0
#define VM8 1
#define VM7 0
#define VM6 0
#define VM5 0
#define VM4 1
#define VM3 0
#define VM2 0
#define VM1 227
static object VV[227];
static LKF0(int, ...);
static (*LK0)(int, ...)=LKF0;
static LKF1(int, ...);
static (*LK1)(int, ...)=LKF1;
static LKF2(int, ...);
static (*LK2)(int, ...)=LKF2;
static LKF3(int, ...);
static (*LK3)(int, ...)=LKF3;
static LKF4(int, ...);
static (*LK4)(int, ...)=LKF4;
static LKF5(int, ...);
static (*LK5)(int, ...)=LKF5;
static LKF6(int, ...);
static (*LK6)(int, ...)=LKF6;
static LKF7(int, ...);
static (*LK7)(int, ...)=LKF7;
static LKF8(int, ...);
static (*LK8)(int, ...)=LKF8;
static LKF9(int, ...);
static (*LK9)(int, ...)=LKF9;
static LKF10(int, ...);
static (*LK10)(int, ...)=LKF10;
static LKF11(int, ...);
static (*LK11)(int, ...)=LKF11;
static LKF12(int, ...);
static (*LK12)(int, ...)=LKF12;
static LKF13(int, ...);
static (*LK13)(int, ...)=LKF13;
static LKF14(int, ...);
static (*LK14)(int, ...)=LKF14;
static LKF15(int, ...);
static (*LK15)(int, ...)=LKF15;
static LKF16(int, ...);
static (*LK16)(int, ...)=LKF16;
static LKF17(int, ...);
static (*LK17)(int, ...)=LKF17;
static LKF18(int, ...);
static (*LK18)(int, ...)=LKF18;
static LKF19(int, ...);
static (*LK19)(int, ...)=LKF19;
static LKF20(int, ...);
static (*LK20)(int, ...)=LKF20;
static LKF21(int, ...);
static (*LK21)(int, ...)=LKF21;
static LKF22(int, ...);
static (*LK22)(int, ...)=LKF22;
static LKF23(int, ...);
static (*LK23)(int, ...)=LKF23;
static LKF24(int, ...);
static (*LK24)(int, ...)=LKF24;
static LKF25(int, ...);
static (*LK25)(int, ...)=LKF25;
static LKF26(int, ...);
static (*LK26)(int, ...)=LKF26;
static LKF27(int, ...);
static (*LK27)(int, ...)=LKF27;
