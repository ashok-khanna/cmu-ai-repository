
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "cmpenv.h"
init_cmpenv(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_cmpenv; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	VV[0]->s.s_stype=(short)stp_special;
	if(VV[0]->s.s_dbind == OBJNULL){
	(VV[0]->s.s_dbind)= Cnil;}
	VV[1]->s.s_stype=(short)stp_special;
	if(VV[1]->s.s_dbind == OBJNULL){
	(VV[1]->s.s_dbind)= Cnil;}
	VV[2]->s.s_stype=(short)stp_special;
	if(VV[2]->s.s_dbind == OBJNULL){
	(VV[2]->s.s_dbind)= Cnil;}
	VV[3]->s.s_stype=(short)stp_special;
	if(VV[3]->s.s_dbind == OBJNULL){
	(VV[3]->s.s_dbind)= MAKE_FIXNUM(3);}
	VV[4]->s.s_stype=(short)stp_special;
	if(VV[4]->s.s_dbind == OBJNULL){
	(VV[4]->s.s_dbind)= MAKE_FIXNUM(0);}
	MF0(VV[116],L1);
	VV[27]->s.s_stype=(short)stp_special;
	if(VV[27]->s.s_dbind == OBJNULL){
	(VV[27]->s.s_dbind)= MAKE_FIXNUM(0);}
	VV[6]->s.s_stype=(short)stp_special;
	if(VV[6]->s.s_dbind == OBJNULL){
	(VV[6]->s.s_dbind)= MAKE_FIXNUM(0);}
	VV[5]->s.s_stype=(short)stp_special;
	if(VV[5]->s.s_dbind == OBJNULL){
	(VV[5]->s.s_dbind)= MAKE_FIXNUM(0);}
	VV[28]->s.s_stype=(short)stp_special;
	VV[29]->s.s_stype=(short)stp_special;
	if(VV[29]->s.s_dbind == OBJNULL){
	(VV[29]->s.s_dbind)= MAKE_FIXNUM(0);}
	VV[30]->s.s_stype=(short)stp_special;
	if(VV[30]->s.s_dbind == OBJNULL){
	(VV[30]->s.s_dbind)= MAKE_FIXNUM(0);}
	VV[31]->s.s_stype=(short)stp_special;
	if(VV[31]->s.s_dbind == OBJNULL){
	(VV[31]->s.s_dbind)= MAKE_FIXNUM(0);}
	VV[32]->s.s_stype=(short)stp_special;
	if(VV[32]->s.s_dbind == OBJNULL){
	(VV[32]->s.s_dbind)= MAKE_FIXNUM(0);}
	VV[33]->s.s_stype=(short)stp_special;
	if(VV[33]->s.s_dbind == OBJNULL){
	(VV[33]->s.s_dbind)= MAKE_FIXNUM(0);}
	VV[34]->s.s_stype=(short)stp_special;
	if(VV[34]->s.s_dbind == OBJNULL){
	(VV[34]->s.s_dbind)= MAKE_FIXNUM(0);}
	VV[35]->s.s_stype=(short)stp_special;
	if(VV[35]->s.s_dbind == OBJNULL){
	(VV[35]->s.s_dbind)= MAKE_FIXNUM(0);}
	VV[7]->s.s_stype=(short)stp_special;
	if(VV[7]->s.s_dbind == OBJNULL){
	(VV[7]->s.s_dbind)= MAKE_FIXNUM(0);}
	VV[8]->s.s_stype=(short)stp_special;
	if(VV[8]->s.s_dbind == OBJNULL){
	(VV[8]->s.s_dbind)= MAKE_FIXNUM(-1);}
	VV[9]->s.s_stype=(short)stp_special;
	if(VV[9]->s.s_dbind == OBJNULL){
	(VV[9]->s.s_dbind)= MAKE_FIXNUM(0);}
	MF0(VV[117],L2);
	MF0(VV[118],L3);
	MF0(VV[119],L4);
	MF0(VV[120],L5);
	MF0(VV[121],L6);
	MF0(VV[122],L7);
	MF0(VV[123],L8);
	MF0(VV[124],L9);
	VV[38]->s.s_stype=(short)stp_special;
	if(VV[38]->s.s_dbind == OBJNULL){
	(VV[38]->s.s_dbind)= Cnil;}
	VV[23]->s.s_stype=(short)stp_special;
	if(VV[23]->s.s_dbind == OBJNULL){
	(VV[23]->s.s_dbind)= Cnil;}
	MF0(VV[125],L10);
	MF0(VV[126],L11);
	MF0(VV[127],L12);
	MF0(VV[128],L13);
	MF0(VV[129],L14);
	MF0(VV[130],L15);
	MF0(VV[131],L16);
	MF0(VV[132],L17);
	VV[51]->s.s_stype=(short)stp_special;
	if(VV[51]->s.s_dbind == OBJNULL){
	(VV[51]->s.s_dbind)= Cnil;}
	VV[26]->s.s_stype=(short)stp_special;
	if(VV[26]->s.s_dbind == OBJNULL){
	(VV[26]->s.s_dbind)= Cnil;}
	MF0(VV[133],L18);
	MF0(VV[134],L19);
	MF0(VV[135],L20);
	MF0(VV[136],L21);
	MF0(VV[137],L22);
	putprop(VV[96],VV[98],VV[97]);
	MF0(VV[98],L23);
	MF0(VV[138],L24);
	MF0(VV[139],L25);
}
/*	function definition for INIT-ENV                              */
static L1(int narg)
{ VT3 VLEX3 CLSR3
TTL:
	(VV[5]->s.s_dbind)= MAKE_FIXNUM(0);
	(VV[6]->s.s_dbind)= MAKE_FIXNUM(0);
	(VV[7]->s.s_dbind)= MAKE_FIXNUM(0);
	(VV[8]->s.s_dbind)= MAKE_FIXNUM(-1);
	(VV[9]->s.s_dbind)= MAKE_FIXNUM(0);
	(VV[10]->s.s_dbind)= MAKE_FIXNUM(0);
	(VV[11]->s.s_dbind)= Cnil;
	(VV[12]->s.s_dbind)= Cnil;
	(VV[13]->s.s_dbind)= Cnil;
	(VV[14]->s.s_dbind)= Cnil;
	(VV[15]->s.s_dbind)= Cnil;
	(VV[16]->s.s_dbind)= Cnil;
	(VV[17]->s.s_dbind)= Cnil;
	(VV[18]->s.s_dbind)= Cnil;
	(VV[19]->s.s_dbind)= Cnil;
	(VV[20]->s.s_dbind)= Cnil;
	(VV[21]->s.s_dbind)= Cnil;
	(VV[22]->s.s_dbind)= Cnil;
	(VV[23]->s.s_dbind)= Cnil;
	(VV[24]->s.s_dbind)= Cnil;
	(VV[25]->s.s_dbind)= MAKE_FIXNUM(0);
	(VV[26]->s.s_dbind)= Cnil;
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for NEXT-LCL                              */
static L2(int narg)
{ VT4 VLEX4 CLSR4
TTL:
	(VV[27]->s.s_dbind)= number_plus((VV[27]->s.s_dbind),MAKE_FIXNUM(1));
	VALUES(0) = (VV[27]->s.s_dbind);
	RETURN(1);
}
/*	function definition for NEXT-TEMP                             */
static L3(int narg)
{ VT5 VLEX5 CLSR5
TTL:
	{object V1;
	V1= (VV[6]->s.s_dbind);
	(VV[6]->s.s_dbind)= number_plus((VV[6]->s.s_dbind),MAKE_FIXNUM(1));
	(VV[5]->s.s_dbind)= (number_compare((VV[6]->s.s_dbind),(VV[5]->s.s_dbind))>=0?(VV[6]->s.s_dbind):(VV[5]->s.s_dbind));
	VALUES(0) = (V1);
	RETURN(1);
	}
}
/*	function definition for NEXT-UNBOXED                          */
static L4(int narg, object V1)
{ VT6 VLEX6 CLSR6
TTL:
	{object V2;                               /*  TEM             */
	(VV[29]->s.s_dbind)= number_plus((VV[29]->s.s_dbind),MAKE_FIXNUM(1));
	V2= (VV[29]->s.s_dbind);
	(*LK0)(1,(V1))                            /*  REP-TYPE        */;
	(VV[28]->s.s_dbind)= CONS(list(2,VALUES(0),(V2)),(VV[28]->s.s_dbind));
	VALUES(0) = (V2);
	RETURN(1);
	}
}
/*	function definition for NEXT-LEX                              */
static L5(int narg)
{ VT7 VLEX7 CLSR7
TTL:
	{object V1;
	V1= CONS((VV[30]->s.s_dbind),(VV[31]->s.s_dbind));
	(VV[31]->s.s_dbind)= number_plus((VV[31]->s.s_dbind),MAKE_FIXNUM(1));
	(VV[32]->s.s_dbind)= (number_compare((VV[31]->s.s_dbind),(VV[32]->s.s_dbind))>=0?(VV[31]->s.s_dbind):(VV[32]->s.s_dbind));
	VALUES(0) = (V1);
	RETURN(1);
	}
}
/*	function definition for NEXT-ENV                              */
static L6(int narg)
{ VT8 VLEX8 CLSR8
TTL:
	{object V1;
	V1= (VV[33]->s.s_dbind);
	(VV[33]->s.s_dbind)= number_plus((VV[33]->s.s_dbind),MAKE_FIXNUM(1));
	(VV[34]->s.s_dbind)= (number_compare((VV[33]->s.s_dbind),(VV[34]->s.s_dbind))>=0?(VV[33]->s.s_dbind):(VV[34]->s.s_dbind));
	VALUES(0) = (V1);
	RETURN(1);
	}
}
/*	function definition for ADD-SYMBOL                            */
static L7(int narg, object V1)
{ VT9 VLEX9 CLSR9
TTL:
	{object V2;                               /*  X               */
	V2= assql((V1),(VV[11]->s.s_dbind));
	if(((V2))==Cnil){
	goto L88;}
	VALUES(0) = CADR((V2));
	RETURN(1);
L88:
	(VV[8]->s.s_dbind)= number_plus((VV[8]->s.s_dbind),MAKE_FIXNUM(1));
	(VV[11]->s.s_dbind)= CONS(list(2,(V1),(VV[8]->s.s_dbind)),(VV[11]->s.s_dbind));
	(*LK1)(1,(V1))                            /*  WT-DATA         */;
	VALUES(0) = (VV[8]->s.s_dbind);
	RETURN(1);
	}
}
/*	function definition for ADD-OBJECT                            */
static L8(int narg, object V1)
{ VT10 VLEX10 CLSR10
TTL:
	{object V2;                               /*  X               */
	V2= Cnil;
	(*LK2)(1,(V1))                            /*  CONTAINS-SHARP-COMMA*/;
	if(VALUES(0)==Cnil){
	goto L97;}
	(VV[8]->s.s_dbind)= number_plus((VV[8]->s.s_dbind),MAKE_FIXNUM(1));
	(VV[36]->s.s_dbind)= CONS((VV[8]->s.s_dbind),(VV[36]->s.s_dbind));
	(*LK3)(1,(V1))                            /*  PRIN1-TO-STRING */;
	(*LK1)(1,VALUES(0))                       /*  WT-DATA         */;
	VALUES(0) = (VV[8]->s.s_dbind);
	RETURN(1);
L97:
	V2= assql((V1),(VV[11]->s.s_dbind));
	if(((V2))==Cnil){
	goto L106;}
	VALUES(0) = CADR((V2));
	RETURN(1);
L106:
	(VV[8]->s.s_dbind)= number_plus((VV[8]->s.s_dbind),MAKE_FIXNUM(1));
	(VV[11]->s.s_dbind)= CONS(list(2,(V1),(VV[8]->s.s_dbind)),(VV[11]->s.s_dbind));
	(*LK1)(1,(V1))                            /*  WT-DATA         */;
	VALUES(0) = (VV[8]->s.s_dbind);
	RETURN(1);
	}
}
/*	function definition for ADD-CONSTANT                          */
static L9(int narg, object V1)
{ VT11 VLEX11 CLSR11
TTL:
	{object V2;                               /*  X               */
	V2= Cnil;
	V2= assql((V1),(VV[12]->s.s_dbind));
	if(((V2))==Cnil){
	goto L116;}
	VALUES(0) = CADR((V2));
	RETURN(1);
L116:
	(VV[8]->s.s_dbind)= number_plus((VV[8]->s.s_dbind),MAKE_FIXNUM(1));
	(VV[36]->s.s_dbind)= CONS((VV[8]->s.s_dbind),(VV[36]->s.s_dbind));
	(*LK3)(1,CONS(VV[37],(V1)))               /*  PRIN1-TO-STRING */;
	(*LK1)(1,VALUES(0))                       /*  WT-DATA         */;
	(VV[12]->s.s_dbind)= CONS(list(2,(V1),(VV[8]->s.s_dbind)),(VV[12]->s.s_dbind));
	VALUES(0) = (VV[8]->s.s_dbind);
	RETURN(1);
	}
}
/*	function definition for FUNCTION-ARG-TYPES                    */
static L10(int narg, object V1)
{ VT12 VLEX12 CLSR12
TTL:
	{object V2;                               /*  TYPES           */
	V2= Cnil;
	{register object V3;                      /*  AL              */
	V3= (V1);
L129:
	if((V3)==Cnil){
	goto L131;}
	if((memql(CAR((V3)),VV[39]))==Cnil){
	goto L130;}
L131:
	VALUES(0) = nreverse((V2));
	RETURN(1);
L130:
	(*LK4)(1,CAR((V3)))                       /*  TYPE-FILTER     */;
	V2= CONS(VALUES(0),(V2));
	V3= CDR((V3));
	goto L129;
	}
	}
}
/*	function definition for FUNCTION-RETURN-TYPE                  */
static L11(int narg, object V1)
{ VT13 VLEX13 CLSR13
TTL:
	if(!((V1)==Cnil)){
	goto L142;}
	VALUES(0) = Ct;
	RETURN(1);
L142:
	if(!(type_of(CAR((V1)))==t_cons)){
	goto L145;}
	if(!((CAAR((V1)))==(VV[40]))){
	goto L145;}
	if(CDR((V1))==Cnil){
	goto L150;}
	(*LK5)(2,VV[41],(V1))                     /*  WARN            */;
	VALUES(0) = Ct;
	RETURN(1);
L150:
	if(CDAR((V1))==Cnil){
	goto L153;}
	if((memql(CADAR((V1)),VV[42]))==Cnil){
	goto L154;}
L153:
	VALUES(0) = Ct;
	RETURN(1);
L154:
	RETURN((*LK4)(1,CADAR((V1)))              /*  TYPE-FILTER     */);
L145:
	RETURN((*LK4)(1,CAR((V1)))                /*  TYPE-FILTER     */);
}
/*	function definition for ADD-FUNCTION-PROCLAMATION             */
static L12(int narg, object V1, object V2)
{ VT14 VLEX14 CLSR14
TTL:
	{object V3;                               /*  ARG-TYPES       */
	register object V4;                       /*  RETURN-TYPES    */
	V3= Cnil;
	V4= Cnil;
	if(!(type_of((V1))==t_symbol)){
	goto L161;}
	if(!(type_of((V2))==t_cons||(V2)==Cnil)){
	goto L161;}
	{object V5= CDR((V2));
	if(!(type_of(V5)==t_cons||V5==Cnil)){
	goto L161;}}
	if(((V2))==Cnil){
	goto L168;}
	if(!((CAR((V2)))==(VV[43]))){
	goto L169;}
L168:
	V3= VV[43];
	remprop((V1),VV[44]);
	goto L167;
L169:
	L10(1,CAR((V2)))                          /*  FUNCTION-ARG-TYPES*/;
	V3= VALUES(0);
	putprop((V1),(V3),VV[44]);
L167:
	if((CDR((V2)))==Cnil){
	goto L178;}
	if(!((CADR((V2)))==(VV[43]))){
	goto L179;}
L178:
	V4= VV[43];
	goto L177;
L179:
	L11(1,CDR((V2)))                          /*  FUNCTION-RETURN-TYPE*/;
	V4= VALUES(0);
L177:
	putprop((V1),(V4),VV[45]);
	{object V5;
	V5= (eql((V4),VV[43])?Ct:Cnil);
	if(((V5))==Cnil){
	goto L189;}
	goto L186;
L189:
	V4= CDR((V2));
	}
L186:
	if((V4)==Cnil){
	goto L193;}
	if(!(CDR((V4))==Cnil)){
	goto L193;}
	if(!(type_of(CAR((V4)))==t_cons)){
	goto L192;}
	if(!((CAAR((V4)))==(VV[40]))){
	goto L192;}
	if(CDAR((V4))==Cnil){
	goto L193;}
	if(!(CDDAR((V4))==Cnil)){
	goto L193;}
L192:
	VALUES(0) = putprop((V1),Ct,VV[46]);
	RETURN(1);
L193:
	VALUES(0) = remprop((V1),VV[46]);
	RETURN(1);
L161:
	RETURN((*LK5)(3,VV[47],(V1),(V2))         /*  WARN            */);
	}
}
/*	function definition for ADD-FUNCTION-DECLARATION              */
static L13(int narg, object V1, object V2, object V3)
{ VT15 VLEX15 CLSR15
TTL:
	if(!(type_of((V1))==t_symbol)){
	goto L206;}
	(*LK6)(1,(V1))                            /*  SCH-LOCAL-FUN   */;
	T0= VALUES(0);
	L10(1,(V2))                               /*  FUNCTION-ARG-TYPES*/;
	T1= VALUES(0);
	L11(1,(V3))                               /*  FUNCTION-RETURN-TYPE*/;
	(VV[23]->s.s_dbind)= CONS(list(3,T0,T1,VALUES(0)),(VV[23]->s.s_dbind));
	VALUES(0) = (VV[23]->s.s_dbind);
	RETURN(1);
L206:
	RETURN((*LK5)(2,VV[48],(V1))              /*  WARN            */);
}
/*	function definition for GET-ARG-TYPES                         */
static L14(int narg, object V1)
{ VT16 VLEX16 CLSR16
TTL:
	{object V2;                               /*  X               */
	V2= Cnil;
	V2= assql((V1),(VV[23]->s.s_dbind));
	if(((V2))==Cnil){
	goto L214;}
	VALUES(0) = CADR((V2));
	RETURN(1);
L214:
	VALUES(0) = getf((V1)->s.s_plist,VV[44],Cnil);
	RETURN(1);
	}
}
/*	function definition for GET-RETURN-TYPE                       */
static L15(int narg, object V1)
{ VT17 VLEX17 CLSR17
TTL:
	{object V2;                               /*  X               */
	object V3;                                /*  TYPE1           */
	V2= assql((V1),(VV[23]->s.s_dbind));
	if(((V2))==Cnil){
	goto L220;}
	V3= CADDR((V2));
	goto L218;
L220:
	V3= getf((V1)->s.s_plist,VV[45],Cnil);
L218:
	if(((V3))==Cnil){
	goto L223;}
	{register object V4;                      /*  TYPE            */
	V4= getf((V1)->s.s_plist,VV[49],Cnil);
	if(((V4))==Cnil){
	goto L227;}
	(*LK7)(2,(V4),(V3))                       /*  TYPE-AND        */;
	V4= VALUES(0);
	if(((V4))==Cnil){
	goto L230;}
	VALUES(0) = (V4);
	RETURN(1);
L230:
	RETURN((*LK8)(2,VV[50],(V1))              /*  CMPWARN         */);
L227:
	VALUES(0) = (V3);
	RETURN(1);
	}
L223:
	VALUES(0) = getf((V1)->s.s_plist,VV[49],Cnil);
	RETURN(1);
	}
}
/*	function definition for GET-LOCAL-ARG-TYPES                   */
static L16(int narg, object V1)
{ VT18 VLEX18 CLSR18
TTL:
	{object V2;                               /*  X               */
	V2= Cnil;
	V2= assql((V1),(VV[23]->s.s_dbind));
	if(((V2))==Cnil){
	goto L235;}
	VALUES(0) = CADR((V2));
	RETURN(1);
L235:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for GET-LOCAL-RETURN-TYPE                 */
static L17(int narg, object V1)
{ VT19 VLEX19 CLSR19
TTL:
	{object V2;                               /*  X               */
	V2= Cnil;
	V2= assql((V1),(VV[23]->s.s_dbind));
	if(((V2))==Cnil){
	goto L240;}
	VALUES(0) = CADDR((V2));
	RETURN(1);
L240:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for INLINE-POSSIBLE                       */
static L18(int narg, object V1)
{ VT20 VLEX20 CLSR20
TTL:
	VALUES(0) = memql((V1),(VV[26]->s.s_dbind));
	if(VALUES(0)==Cnil)goto L244;
	goto L243;
L244:
	VALUES(0) = getf((V1)->s.s_plist,VV[52],Cnil);
L243:
	VALUES(0) = ((VALUES(0))==Cnil?Ct:Cnil);
	RETURN(1);
}
/*	function definition for PROCLAIM                              */
static L19(int narg, object V1)
{ VT21 VLEX21 CLSR21
TTL:
	if(type_of((V1))==t_cons||(V1)==Cnil){
	goto L246;}
	Lerror(2,VV[53],(V1))                     /*  ERROR           */;
L246:
	{object V2= CAR((V1));
	if((V2!= VV[149]))goto L250;
	{register object V3;
	register object V4;                       /*  VAR             */
	V3= CDR((V1));
	V4= Cnil;
L254:
	if(!((V3)==Cnil)){
	goto L255;}
	goto L249;
L255:
	V4= CAR((V3));
	if(!(type_of((V4))==t_symbol)){
	goto L262;}
	siLAmake_special(1,(V4))                  /*  *MAKE-SPECIAL   */;
	goto L260;
L262:
	(*LK5)(2,VV[54],(V4))                     /*  WARN            */;
L260:
	V3= CDR((V3));
	goto L254;
	}
L250:
	if((V2!= VV[81]))goto L267;
	{register object V6;
	register object V7;                       /*  X               */
	V6= CDR((V1));
	V7= Cnil;
L271:
	if(!((V6)==Cnil)){
	goto L272;}
	goto L249;
L272:
	V7= CAR((V6));
	if(!(type_of((V7))==t_symbol)){
	goto L277;}
	V7= list(2,(V7),MAKE_FIXNUM(3));
L277:
	if(!(type_of((V7))==t_cons)){
	goto L282;}
	if(!(type_of(CDR((V7)))==t_cons)){
	goto L282;}
	if(!(numberp(CADR((V7))))){
	goto L282;}
	Lmonotonically_nondecreasing(3,MAKE_FIXNUM(0),CADR((V7)),MAKE_FIXNUM(3))/*  <=*/;
	if(VALUES(0)!=Cnil){
	goto L283;}
L282:
	(*LK5)(2,VV[55],(V7))                     /*  WARN            */;
	goto L281;
L283:
	{object V9= CAR((V7));
	if((V9!= VV[83]))goto L291;
	(VV[1]->s.s_dbind)= (number_compare(CADR((V7)),MAKE_FIXNUM(1))>=0?Ct:Cnil);
	(VV[0]->s.s_dbind)= (number_compare(CADR((V7)),MAKE_FIXNUM(2))>=0?Ct:Cnil);
	(VV[2]->s.s_dbind)= (number_compare(CADR((V7)),MAKE_FIXNUM(3))>=0?Ct:Cnil);
	goto L281;
L291:
	if((V9!= VV[84]))goto L297;
	(VV[4]->s.s_dbind)= CADR((V7));
	goto L281;
L297:
	if((V9!= VV[150]))goto L299;
	(VV[3]->s.s_dbind)= CADR((V7));
	goto L281;
L299:
	if((V9!= VV[151]))goto L301;
	(VV[3]->s.s_dbind)= number_minus(MAKE_FIXNUM(3),CADR((V7)));
	goto L281;
L301:
	(*LK5)(2,VV[56],CAR((V7)))                /*  WARN            */;}
L281:
	V6= CDR((V6));
	goto L271;
	}
L267:
	if((V2!= VV[152]))goto L306;
	if(!(type_of(CDR((V1)))==t_cons)){
	goto L308;}
	L20(2,CADR((V1)),CDDR((V1)))              /*  PROCLAIM-VAR    */;
	goto L249;
L308:
	(*LK5)(2,VV[57],(V1))                     /*  WARN            */;
	goto L249;
L306:
	if((V2!= VV[153])
	&& (V2!= VV[154])
	&& (V2!= VV[155])
	&& (V2!= VV[156]))goto L310;
	L20(2,CAR((V1)),CDR((V1)))                /*  PROCLAIM-VAR    */;
	goto L249;
L310:
	if((V2!= VV[86]))goto L311;
	if(!(type_of(CDR((V1)))==t_cons)){
	goto L313;}
	if(!(type_of(CADR((V1)))==t_cons)){
	goto L313;}
	{register object V10;
	object V11;                               /*  V               */
	V10= CDDR((V1));
	V11= Cnil;
L321:
	if(!((V10)==Cnil)){
	goto L322;}
	goto L249;
L322:
	V11= CAR((V10));
	L12(2,(V11),CDR(CADR((V1))))              /*  ADD-FUNCTION-PROCLAMATION*/;
	V10= CDR((V10));
	goto L321;
	}
L313:
	(*LK8)(2,VV[59],(V1))                     /*  CMPWARN         */;
	goto L249;
L311:
	if((V2!= VV[58]))goto L331;
	if(!(type_of(CDR((V1)))==t_cons)){
	goto L333;}
	L12(2,CADR((V1)),CDDR((V1)))              /*  ADD-FUNCTION-PROCLAMATION*/;
	goto L249;
L333:
	(*LK8)(2,VV[60],(V1))                     /*  CMPWARN         */;
	goto L249;
L331:
	if((V2!= VV[89]))goto L335;
	{register object V13;
	register object V14;                      /*  FUN             */
	V13= CDR((V1));
	V14= Cnil;
L339:
	if(!((V13)==Cnil)){
	goto L340;}
	goto L249;
L340:
	V14= CAR((V13));
	if(!(type_of((V14))==t_symbol)){
	goto L347;}
	remprop((V14),VV[52]);
	goto L345;
L347:
	(*LK5)(2,VV[61],(V14))                    /*  WARN            */;
L345:
	V13= CDR((V13));
	goto L339;
	}
L335:
	if((V2!= VV[91]))goto L352;
	{register object V16;
	register object V17;                      /*  FUN             */
	V16= CDR((V1));
	V17= Cnil;
L356:
	if(!((V16)==Cnil)){
	goto L357;}
	goto L249;
L357:
	V17= CAR((V16));
	if(!(type_of((V17))==t_symbol)){
	goto L364;}
	putprop((V17),Ct,VV[52]);
	goto L362;
L364:
	(*LK5)(2,VV[62],(V17))                    /*  WARN            */;
L362:
	V16= CDR((V16));
	goto L356;
	}
L352:
	if((V2!= VV[77])
	&& (V2!= VV[157]))goto L369;
	{register object V19;
	object V20;                               /*  VAR             */
	V19= CDR((V1));
	V20= Cnil;
L373:
	if(!((V19)==Cnil)){
	goto L374;}
	goto L249;
L374:
	V20= CAR((V19));
	if(type_of((V20))==t_symbol){
	goto L379;}
	(*LK5)(2,VV[63],(V20))                    /*  WARN            */;
L379:
	V19= CDR((V19));
	goto L373;
	}
L369:
	if((V2!= VV[93]))goto L385;
	{register object V22;
	register object V23;                      /*  X               */
	V22= CDR((V1));
	V23= Cnil;
L389:
	if(!((V22)==Cnil)){
	goto L390;}
	goto L249;
L390:
	V23= CAR((V22));
	if(!(type_of((V23))==t_symbol)){
	goto L397;}
	Ladjoin(2,(V23),(VV[51]->s.s_dbind))      /*  ADJOIN          */;
	(VV[51]->s.s_dbind)= VALUES(0);
	goto L395;
L397:
	(*LK5)(2,VV[64],(V23))                    /*  WARN            */;
L395:
	V22= CDR((V22));
	goto L389;
	}
L385:
	if((V2== VV[158])
	|| (V2== VV[159])
	|| (V2== VV[160])
	|| (V2== VV[161])
	|| (V2== VV[162]))goto L404;
	if((V2== VV[154])
	|| (V2== VV[163])
	|| (V2== VV[164])
	|| (V2== VV[165])
	|| (V2== VV[166]))goto L404;
	if((V2== VV[167])
	|| (V2== VV[153])
	|| (V2== VV[168])
	|| (V2== VV[169])
	|| (V2== VV[170]))goto L404;
	if((V2== VV[171])
	|| (V2== VV[172])
	|| (V2== VV[156])
	|| (V2== Cnil)
	|| (V2== VV[173]))goto L404;
	if((V2== VV[174])
	|| (V2== VV[175])
	|| (V2== VV[176])
	|| (V2== VV[177])
	|| (V2== VV[178]))goto L404;
	if((V2== VV[179])
	|| (V2== VV[180])
	|| (V2== VV[181])
	|| (V2== VV[155])
	|| (V2== VV[182]))goto L404;
	if((V2== VV[183])
	|| (V2== VV[184])
	|| (V2== VV[185])
	|| (V2== VV[186])
	|| (V2== VV[187]))goto L404;
	if((V2== VV[188])
	|| (V2== VV[189])
	|| (V2== VV[190])
	|| (V2== VV[191])
	|| (V2== Ct))goto L404;
	if((V2!= VV[192])
	&& (V2!= VV[193])
	&& (V2!= VV[194]))goto L403;
L404:
	L20(2,CAR((V1)),CDR((V1)))                /*  PROCLAIM-VAR    */;
	goto L249;
L403:
	if((memql(CAR((V1)),(VV[51]->s.s_dbind)))!=Cnil){
	goto L405;}
	(*LK5)(2,VV[65],CAR((V1)))                /*  WARN            */;
L405:
	Lfunctionp(1,getf(CAR((V1))->s.s_plist,VV[66],Cnil))/*  FUNCTIONP*/;
	if(VALUES(0)!=Cnil){
	goto L408;}
	goto L249;
L408:
	{register object V25;
	object V26;                               /*  V               */
	V25= CDR((V1));
	V26= Cnil;
L413:
	if(!((V25)==Cnil)){
	goto L414;}
	goto L249;
L414:
	V26= CAR((V25));
	T0= getf(CAR((V1))->s.s_plist,VV[66],Cnil);
	funcall(2,T0,(V26));
	V25= CDR((V25));
	goto L413;
	}}
L249:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for PROCLAIM-VAR                          */
static L20(int narg, object V1, object V2)
{ VT22 VLEX22 CLSR22
TTL:
	(*LK4)(1,(V1))                            /*  TYPE-FILTER     */;
	V1= VALUES(0);
	{register object V3;
	register object V4;                       /*  VAR             */
	V3= (V2);
	V4= Cnil;
L429:
	if(!((V3)==Cnil)){
	goto L430;}
	VALUES(0) = Cnil;
	RETURN(1);
L430:
	V4= CAR((V3));
	if(!(type_of((V4))==t_symbol)){
	goto L437;}
	{register object V6;                      /*  TYPE1           */
	object V7;
	register object V8;                       /*  V               */
	V7= getf((V4)->s.s_plist,VV[67],Cnil);
	(*LK9)(1,(V4))                            /*  SCH-GLOBAL      */;
	V8= VALUES(0);
	V6= V7;
	if(((V6))==Cnil){
	goto L444;}
	(*LK7)(2,(V6),(V1))                       /*  TYPE-AND        */;
	V6= VALUES(0);
	goto L442;
L444:
	V6= (V1);
L442:
	if(((V8))==Cnil){
	goto L446;}
	(*LK7)(2,(V6),((V8))->v.v_self[6])        /*  TYPE-AND        */;
	V6= VALUES(0);
L446:
	if(((V6))!=Cnil){
	goto L450;}
	(*LK5)(2,VV[68],(V4))                     /*  WARN            */;
	V6= Ct;
L450:
	putprop((V4),(V6),VV[67]);
	if(((V8))==Cnil){
	goto L435;}
	elt_set((V8),6,(V6));
	goto L435;
	}
L437:
	(*LK5)(2,VV[69],(V4))                     /*  WARN            */;
L435:
	V3= CDR((V3));
	goto L429;
	}
}
/*	function definition for C1BODY                                */
static L21(int narg, object V1, object V2)
{ VT23 VLEX23 CLSR23
TTL:
	{object V3;                               /*  SS              */
	object V4;                                /*  IS              */
	register object V5;                       /*  TS              */
	object V6;                                /*  OTHERS          */
	object V7;                                /*  DOC             */
	register object V8;                       /*  FORM            */
	V3= Cnil;
	V4= Cnil;
	V5= Cnil;
	V6= Cnil;
	V7= Cnil;
	V8= Cnil;
L469:
	if(!((V1)==Cnil)){
	goto L471;}
	goto L467;
L471:
	(*LK10)(1,CAR((V1)))                      /*  CMP-MACROEXPAND */;
	V8= VALUES(0);
	if(!(type_of((V8))==t_string)){
	goto L478;}
	if(((V2))==Cnil){
	goto L481;}
	if(CDR((V1))==Cnil){
	goto L481;}
	if(((V7))==Cnil){
	goto L480;}
L481:
	goto L467;
L480:
	V7= (V8);
	goto L476;
L478:
	if(!(type_of((V8))==t_cons)){
	goto L489;}
	if(!((CAR((V8)))==(VV[70]))){
	goto L489;}
	{register object V9;
	register object V10;                      /*  DECL            */
	V9= CDR((V8));
	V10= Cnil;
L496:
	if(!((V9)==Cnil)){
	goto L497;}
	goto L476;
L497:
	V10= CAR((V9));
	if(!(type_of((V10))==t_cons)){
	goto L503;}
	if(type_of(CAR((V10)))==t_symbol){
	goto L502;}
L503:
	(*LK11)(2,VV[71],(V10))                   /*  CMPERR          */;
L502:
	{object V12= CAR((V10));
	if((V12!= VV[149]))goto L508;
	{register object V13;
	register object V14;                      /*  VAR             */
	V13= CDR((V10));
	V14= Cnil;
L512:
	if(!((V13)==Cnil)){
	goto L513;}
	goto L507;
L513:
	V14= CAR((V13));
	if(type_of((V14))==t_symbol){
	goto L518;}
	(*LK11)(3,VV[72],(V10),(V14))             /*  CMPERR          */;
L518:
	V3= CONS((V14),(V3));
	V13= CDR((V13));
	goto L512;
	}
L508:
	if((V12!= VV[157]))goto L526;
	{register object V16;
	register object V17;                      /*  VAR             */
	V16= CDR((V10));
	V17= Cnil;
L530:
	if(!((V16)==Cnil)){
	goto L531;}
	goto L507;
L531:
	V17= CAR((V16));
	if(type_of((V17))==t_symbol){
	goto L536;}
	(*LK11)(3,VV[73],(V10),(V17))             /*  CMPERR          */;
L536:
	V4= CONS((V17),(V4));
	V16= CDR((V16));
	goto L530;
	}
L526:
	if((V12!= VV[152]))goto L544;
	if(!(CDR((V10))==Cnil)){
	goto L545;}
	(*LK11)(2,VV[74],(V10))                   /*  CMPERR          */;
L545:
	{object V19;                              /*  TYPE            */
	(*LK4)(1,CADR((V10)))                     /*  TYPE-FILTER     */;
	V19= VALUES(0);
	if(((V19))==Cnil){
	goto L507;}
	{register object V20;
	register object V21;                      /*  VAR             */
	V20= CDDR((V10));
	V21= Cnil;
L554:
	if(!((V20)==Cnil)){
	goto L555;}
	goto L507;
L555:
	V21= CAR((V20));
	if(type_of((V21))==t_symbol){
	goto L560;}
	(*LK11)(3,VV[75],(V10),(V21))             /*  CMPERR          */;
L560:
	V5= CONS(CONS((V21),(V19)),(V5));
	V20= CDR((V20));
	goto L554;
	}
	}
L544:
	if((V12!= VV[77]))goto L568;
	{register object V23;
	register object V24;                      /*  VAR             */
	V23= CDR((V10));
	V24= Cnil;
L572:
	if(!((V23)==Cnil)){
	goto L573;}
	goto L507;
L573:
	V24= CAR((V23));
	if(type_of((V24))==t_symbol){
	goto L578;}
	(*LK11)(3,VV[76],(V10),(V24))             /*  CMPERR          */;
L578:
	V5= CONS(CONS((V24),VV[77]),(V5));
	V23= CDR((V23));
	goto L572;
	}
L568:
	if((V12!= VV[198]))goto L586;
	{register object V26;
	register object V27;                      /*  VAR             */
	V26= CDR((V10));
	V27= Cnil;
L590:
	if(!((V26)==Cnil)){
	goto L591;}
	goto L507;
L591:
	V27= CAR((V26));
	if(type_of((V27))==t_symbol){
	goto L596;}
	(*LK11)(3,VV[78],(V10),(V27))             /*  CMPERR          */;
L596:
	V5= CONS(CONS((V27),VV[79]),(V5));
	V26= CDR((V26));
	goto L590;
	}
L586:
	if((V12!= VV[199]))goto L604;
	goto L507;
L604:
	if((V12== VV[153])
	|| (V12== VV[154])
	|| (V12== VV[167])
	|| (V12== VV[155])
	|| (V12== VV[158]))goto L606;
	if((V12== VV[159])
	|| (V12== VV[160])
	|| (V12== VV[161])
	|| (V12== VV[162])
	|| (V12== VV[163]))goto L606;
	if((V12== VV[164])
	|| (V12== VV[165])
	|| (V12== VV[166])
	|| (V12== VV[168])
	|| (V12== VV[169]))goto L606;
	if((V12== VV[170])
	|| (V12== VV[171])
	|| (V12== VV[172])
	|| (V12== VV[156])
	|| (V12== Cnil))goto L606;
	if((V12== VV[173])
	|| (V12== VV[174])
	|| (V12== VV[175])
	|| (V12== VV[176])
	|| (V12== VV[177]))goto L606;
	if((V12== VV[178])
	|| (V12== VV[179])
	|| (V12== VV[180])
	|| (V12== VV[181])
	|| (V12== VV[182]))goto L606;
	if((V12== VV[183])
	|| (V12== VV[184])
	|| (V12== VV[185])
	|| (V12== VV[186])
	|| (V12== VV[187]))goto L606;
	if((V12== VV[188])
	|| (V12== VV[189])
	|| (V12== VV[190])
	|| (V12== VV[191])
	|| (V12== Ct))goto L606;
	if((V12!= VV[192])
	&& (V12!= VV[193])
	&& (V12!= VV[194]))goto L605;
L606:
	{object V29;                              /*  TYPE            */
	(*LK4)(1,CAR((V10)))                      /*  TYPE-FILTER     */;
	V29= VALUES(0);
	if(((V29))==Cnil){
	goto L507;}
	{register object V30;
	register object V31;                      /*  VAR             */
	V30= CDR((V10));
	V31= Cnil;
L613:
	if(!((V30)==Cnil)){
	goto L614;}
	goto L507;
L614:
	V31= CAR((V30));
	if(type_of((V31))==t_symbol){
	goto L619;}
	(*LK11)(3,VV[80],(V10),(V31))             /*  CMPERR          */;
L619:
	V5= CONS(CONS((V31),(V29)),(V5));
	V30= CDR((V30));
	goto L613;
	}
	}
L605:
	V6= CONS((V10),(V6));}
L507:
	V9= CDR((V9));
	goto L496;
	}
L489:
	goto L467;
L476:
	V1= CDR((V1));
	goto L469;
L467:
	VALUES(5) = (V7);
	VALUES(4) = (V6);
	VALUES(3) = (V4);
	VALUES(2) = (V5);
	VALUES(1) = (V3);
	VALUES(0) = (V1);
	RETURN(6);
	}
}
/*	function definition for C1DECL-BODY                           */
static L22(int narg, object V1, object V2)
{ VT24 VLEX24 CLSR24
	bds_check;
TTL:
	{register object V3;                      /*  DL              */
	V3= Cnil;
	if(((V1))!=Cnil){
	goto L636;}
	RETURN((*LK12)(1,(V2))                    /*  C1PROGN         */);
L636:
	bds_bind(VV[23],(VV[23]->s.s_dbind));     /*  *FUNCTION-DECLARATIONS**/
	bds_bind(VV[51],(VV[51]->s.s_dbind));     /*  *ALIEN-DECLARATIONS**/
	bds_bind(VV[26],(VV[26]->s.s_dbind));     /*  *NOTINLINE*     */
	bds_bind(VV[4],(VV[4]->s.s_dbind));       /*  *SPACE*         */
	{object V4;
	register object V5;                       /*  DECL            */
	V4= (V1);
	V5= Cnil;
L642:
	if(!((V4)==Cnil)){
	goto L643;}
	goto L638;
L643:
	V5= CAR((V4));
	{register object V7;
	V7= CAR((V5));
	if(!(eql((V7),VV[81]))){
	goto L651;}
	{object V8;
	register object V9;                       /*  X               */
	V8= CDR((V5));
	V9= Cnil;
L656:
	if(!((V8)==Cnil)){
	goto L657;}
	goto L648;
L657:
	V9= CAR((V8));
	if(!(type_of((V9))==t_symbol)){
	goto L662;}
	V9= list(2,(V9),MAKE_FIXNUM(3));
L662:
	if(!(type_of((V9))==t_cons)){
	goto L667;}
	if(!(type_of(CDR((V9)))==t_cons)){
	goto L667;}
	if(!(numberp(CADR((V9))))){
	goto L667;}
	Lmonotonically_nondecreasing(3,MAKE_FIXNUM(0),CADR((V9)),MAKE_FIXNUM(3))/*  <=*/;
	if(VALUES(0)!=Cnil){
	goto L668;}
L667:
	(*LK5)(2,VV[82],(V9))                     /*  WARN            */;
	goto L666;
L668:
	{object V11= CAR((V9));
	if((V11!= VV[83]))goto L676;
	V3= CONS(list(2,VV[83],CADR((V9))),(V3));
	goto L666;
L676:
	if((V11!= VV[84]))goto L678;
	(VV[4]->s.s_dbind)= CADR((V9));
	V3= CONS(list(2,VV[84],CADR((V9))),(V3));
	goto L666;
L678:
	if((V11!= VV[150])
	&& (V11!= VV[151]))goto L682;
	goto L666;
L682:
	(*LK5)(2,VV[85],CAR((V9)))                /*  WARN            */;}
L666:
	V8= CDR((V8));
	goto L656;
	}
L651:
	if(!(eql((V7),VV[86]))){
	goto L687;}
	if(CDR((V5))==Cnil){
	goto L689;}
	if(!(type_of(CADR((V5)))==t_cons)){
	goto L689;}
	if(!((CAADR((V5)))==(VV[58]))){
	goto L689;}
	if(!(CDADR((V5))==Cnil)){
	goto L690;}
L689:
	(*LK5)(2,VV[87],(V5))                     /*  WARN            */;
	goto L648;
L690:
	{object V12;
	object V13;                               /*  FNAME           */
	V12= CDDR((V5));
	V13= Cnil;
L701:
	if(!((V12)==Cnil)){
	goto L702;}
	goto L648;
L702:
	V13= CAR((V12));
	L13(3,(V13),CADADR((V5)),CDDADR((V5)))    /*  ADD-FUNCTION-DECLARATION*/;
	V12= CDR((V12));
	goto L701;
	}
L687:
	if(!(eql((V7),VV[58]))){
	goto L712;}
	if(CDR((V5))==Cnil){
	goto L714;}
	if(CDDR((V5))==Cnil){
	goto L714;}
	if(type_of(CADR((V5)))==t_symbol){
	goto L715;}
L714:
	(*LK5)(2,VV[88],(V5))                     /*  WARN            */;
	goto L648;
L715:
	L13(3,CADR((V5)),CADDR((V5)),CDDDR((V5))) /*  ADD-FUNCTION-DECLARATION*/;
	goto L648;
L712:
	if(!(eql((V7),VV[89]))){
	goto L722;}
	{object V15;
	register object V16;                      /*  FUN             */
	V15= CDR((V5));
	V16= Cnil;
L727:
	if(!((V15)==Cnil)){
	goto L728;}
	goto L648;
L728:
	V16= CAR((V15));
	if(!(type_of((V16))==t_symbol)){
	goto L735;}
	V3= CONS(list(2,VV[89],(V16)),(V3));
	(*LK13)(2,(V16),(VV[26]->s.s_dbind))      /*  REMOVE          */;
	(VV[26]->s.s_dbind)= VALUES(0);
	goto L733;
L735:
	(*LK5)(2,VV[90],(V16))                    /*  WARN            */;
L733:
	V15= CDR((V15));
	goto L727;
	}
L722:
	if(!(eql((V7),VV[91]))){
	goto L744;}
	{object V18;
	register object V19;                      /*  FUN             */
	V18= CDR((V5));
	V19= Cnil;
L749:
	if(!((V18)==Cnil)){
	goto L750;}
	goto L648;
L750:
	V19= CAR((V18));
	if(!(type_of((V19))==t_symbol)){
	goto L757;}
	V3= CONS(list(2,VV[91],(V19)),(V3));
	(VV[26]->s.s_dbind)= CONS((V19),(VV[26]->s.s_dbind));
	goto L755;
L757:
	(*LK5)(2,VV[92],(V19))                    /*  WARN            */;
L755:
	V18= CDR((V18));
	goto L749;
	}
L744:
	if(!(eql((V7),VV[93]))){
	goto L766;}
	{object V21;
	object V22;                               /*  X               */
	V21= CDR((V5));
	V22= Cnil;
L771:
	if(!((V21)==Cnil)){
	goto L772;}
	goto L648;
L772:
	V22= CAR((V21));
	if(!(type_of((V22))==t_symbol)){
	goto L779;}
	Ladjoin(2,(V22),(VV[51]->s.s_dbind))      /*  ADJOIN          */;
	(VV[51]->s.s_dbind)= VALUES(0);
	goto L777;
L779:
	(*LK5)(2,VV[94],(V22))                    /*  WARN            */;
L777:
	V21= CDR((V21));
	goto L771;
	}
L766:
	if((memql(CAR((V5)),(VV[51]->s.s_dbind)))!=Cnil){
	goto L648;}
	(*LK5)(2,VV[95],CAR((V5)))                /*  WARN            */;
	}
L648:
	V4= CDR((V4));
	goto L642;
	}
L638:
	(*LK12)(1,(V2))                           /*  C1PROGN         */;
	V2= VALUES(0);
	{int V4;
	VALUES(0)=list(4,VV[96],CADR((V2)),(V3),(V2));
	V4=1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V4);}
	}
}
/*	function definition for C2DECL-BODY                           */
static L23(int narg, object V1, object V2)
{ VT25 VLEX25 CLSR25
	bds_check;
TTL:
	bds_bind(VV[1],(VV[1]->s.s_dbind));       /*  *COMPILER-CHECK-ARGS**/
	bds_bind(VV[0],(VV[0]->s.s_dbind));       /*  *SAFE-COMPILE*  */
	bds_bind(VV[2],(VV[2]->s.s_dbind));       /*  *COMPILER-PUSH-EVENTS**/
	bds_bind(VV[26],(VV[26]->s.s_dbind));     /*  *NOTINLINE*     */
	bds_bind(VV[4],(VV[4]->s.s_dbind));       /*  *SPACE*         */
	{register object V3;
	register object V4;                       /*  DECL            */
	V3= (V1);
	V4= Cnil;
L796:
	if(!((V3)==Cnil)){
	goto L797;}
	goto L792;
L797:
	V4= CAR((V3));
	{register object V6;
	V6= CAR((V4));
	if(!(eql((V6),VV[83]))){
	goto L805;}
	{register int V7;                         /*  LEVEL           */
	V7= fix(CADR((V4)));
	(VV[1]->s.s_dbind)= ((V7)>=(1)?Ct:Cnil);
	(VV[0]->s.s_dbind)= ((V7)>=(2)?Ct:Cnil);
	(VV[2]->s.s_dbind)= ((V7)>=(3)?Ct:Cnil);
	goto L802;
	}
L805:
	if(!(eql((V6),VV[84]))){
	goto L814;}
	(VV[4]->s.s_dbind)= CADR((V4));
	goto L802;
L814:
	if(!(eql((V6),VV[91]))){
	goto L818;}
	(VV[26]->s.s_dbind)= CONS(CADR((V4)),(VV[26]->s.s_dbind));
	goto L802;
L818:
	if(!(eql((V6),VV[89]))){
	goto L822;}
	(*LK13)(2,CADR((V4)),(VV[26]->s.s_dbind)) /*  REMOVE          */;
	(VV[26]->s.s_dbind)= VALUES(0);
	goto L802;
L822:
	(*LK14)(0)                                /*  BABOON          */;
	}
L802:
	V3= CDR((V3));
	goto L796;
	}
L792:
	{int V3;
	V3=(*LK15)(1,(V2))                        /*  C2EXPR          */;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V3);}
}
/*	function definition for CHECK-VDECL                           */
static L24(int narg, object V1, object V2, object V3)
{ VT26 VLEX26 CLSR26
TTL:
	{register object V4;
	object V5;                                /*  X               */
	V4= (V2);
	V5= Cnil;
L832:
	if(!((V4)==Cnil)){
	goto L833;}
	goto L828;
L833:
	V5= CAR((V4));
	if((memql(CAR((V5)),(V1)))!=Cnil){
	goto L838;}
	(*LK8)(2,VV[99],CAR((V5)))                /*  CMPWARN         */;
L838:
	V4= CDR((V4));
	goto L832;
	}
L828:
	{register object V4;
	object V5;                                /*  X               */
	V4= (V3);
	V5= Cnil;
L847:
	if(!((V4)==Cnil)){
	goto L848;}
	VALUES(0) = Cnil;
	RETURN(1);
L848:
	V5= CAR((V4));
	if((memql((V5),(V1)))!=Cnil){
	goto L853;}
	(*LK8)(2,VV[100],(V5))                    /*  CMPWARN         */;
L853:
	V4= CDR((V4));
	goto L847;
	}
}
/*	function definition for PROCLAMATION                          */
static L25(int narg, object V1)
{ VT27 VLEX27 CLSR27
TTL:
	if(type_of((V1))==t_cons||(V1)==Cnil){
	goto L859;}
	Lerror(2,VV[101],(V1))                    /*  ERROR           */;
L859:
	{object V2= CAR((V1));
	if((V2!= VV[149]))goto L862;
	{register object V3;
	register object V4;                       /*  VAR             */
	V3= CDR((V1));
	V4= Cnil;
L866:
	if(!((V3)==Cnil)){
	goto L867;}
	VALUES(0) = Ct;
	RETURN(1);
L867:
	V4= CAR((V3));
	if(!(type_of((V4))==t_symbol)){
	goto L874;}
	siLspecialp(1,(V4))                       /*  SPECIALP        */;
	if(VALUES(0)!=Cnil){
	goto L872;}
	(*LK16)(1,(V4))                           /*  CHECK-GLOBAL    */;
	if(VALUES(0)!=Cnil){
	goto L872;}
	VALUES(0) = Cnil;
	RETURN(1);
L874:
	(*LK5)(2,VV[102],(V4))                    /*  WARN            */;
L872:
	V3= CDR((V3));
	goto L866;
	}
L862:
	if((V2!= VV[81]))goto L883;
	{register object V7;
	register object V8;                       /*  X               */
	V7= CDR((V1));
	V8= Cnil;
L887:
	if(!((V7)==Cnil)){
	goto L888;}
	VALUES(0) = Ct;
	RETURN(1);
L888:
	V8= CAR((V7));
	if(!(type_of((V8))==t_symbol)){
	goto L893;}
	V8= list(2,(V8),MAKE_FIXNUM(3));
L893:
	if(!(type_of((V8))==t_cons)){
	goto L898;}
	if(!(type_of(CDR((V8)))==t_cons)){
	goto L898;}
	if(!(numberp(CADR((V8))))){
	goto L898;}
	Lmonotonically_nondecreasing(3,MAKE_FIXNUM(0),CADR((V8)),MAKE_FIXNUM(3))/*  <=*/;
	if(VALUES(0)!=Cnil){
	goto L899;}
L898:
	(*LK5)(2,VV[103],(V8))                    /*  WARN            */;
	goto L897;
L899:
	{object V10= CAR((V8));
	if((V10!= VV[83]))goto L907;
	{object V11= CADR((V8));
	if(((VV[1]->s.s_dbind))!=Cnil){
	goto L912;}
	VALUES(0) = MAKE_FIXNUM(0);
	goto L910;
L912:
	if(((VV[0]->s.s_dbind))!=Cnil){
	goto L915;}
	VALUES(0) = MAKE_FIXNUM(1);
	goto L910;
L915:
	if(((VV[2]->s.s_dbind))!=Cnil){
	goto L918;}
	VALUES(0) = MAKE_FIXNUM(2);
	goto L910;
L918:
	VALUES(0) = MAKE_FIXNUM(3);
L910:
	if(number_compare(V11,VALUES(0))==0){
	goto L897;}}
	VALUES(0) = Cnil;
	RETURN(1);
L907:
	if((V10!= VV[84]))goto L920;
	if(number_compare(CADR((V8)),(VV[4]->s.s_dbind))==0){
	goto L897;}
	VALUES(0) = Cnil;
	RETURN(1);
L920:
	if((V10!= VV[150]))goto L923;
	if(number_compare(CADR((V8)),(VV[3]->s.s_dbind))==0){
	goto L897;}
	VALUES(0) = Cnil;
	RETURN(1);
L923:
	if((V10!= VV[151]))goto L926;
	if(number_compare(number_minus(MAKE_FIXNUM(3),CADR((V8))),(VV[3]->s.s_dbind))==0){
	goto L897;}
	VALUES(0) = Cnil;
	RETURN(1);
L926:
	(*LK5)(2,VV[104],CAR((V8)))               /*  WARN            */;}
L897:
	V7= CDR((V7));
	goto L887;
	}
L883:
	if((V2!= VV[152]))goto L932;
	if(!(type_of(CDR((V1)))==t_cons)){
	goto L934;}
	{object V15;                              /*  TYPE            */
	object V16;                               /*  X               */
	(*LK4)(1,CADR((V1)))                      /*  TYPE-FILTER     */;
	V15= VALUES(0);
	V16= Cnil;
	{register object V17;
	register object V18;                      /*  VAR             */
	V17= CDDR((V1));
	V18= Cnil;
L940:
	if(!((V17)==Cnil)){
	goto L941;}
	VALUES(0) = Ct;
	RETURN(1);
L941:
	V18= CAR((V17));
	if(!(type_of((V18))==t_symbol)){
	goto L948;}
	V16= getf((V18)->s.s_plist,VV[67],Cnil);
	if(((V16))==Cnil){
	goto L950;}
	if(equal((V16),(V15))){
	goto L946;}
L950:
	VALUES(0) = Cnil;
	RETURN(1);
L948:
	(*LK5)(2,VV[105],(V18))                   /*  WARN            */;
L946:
	V17= CDR((V17));
	goto L940;
	}
	}
L934:
	RETURN((*LK5)(2,VV[106],(V1))             /*  WARN            */);
L932:
	if((V2!= VV[153])
	&& (V2!= VV[154])
	&& (V2!= VV[155])
	&& (V2!= VV[156]))goto L958;
	{object V21;                              /*  TYPE            */
	object V22;                               /*  X               */
	(*LK4)(1,CAR((V1)))                       /*  TYPE-FILTER     */;
	V21= VALUES(0);
	V22= Cnil;
	{register object V23;
	register object V24;                      /*  VAR             */
	V23= CDR((V1));
	V24= Cnil;
L963:
	if(!((V23)==Cnil)){
	goto L964;}
	VALUES(0) = Ct;
	RETURN(1);
L964:
	V24= CAR((V23));
	if(!(type_of((V24))==t_symbol)){
	goto L971;}
	V22= getf((V24)->s.s_plist,VV[67],Cnil);
	if(((V22))==Cnil){
	goto L973;}
	if(equal((V22),(V21))){
	goto L969;}
L973:
	VALUES(0) = Cnil;
	RETURN(1);
L971:
	(*LK5)(2,VV[107],(V24))                   /*  WARN            */;
L969:
	V23= CDR((V23));
	goto L963;
	}
	}
L958:
	if((V2!= VV[86]))goto L981;
	if(CDR((V1))==Cnil){
	goto L982;}
	if(!(type_of(CADR((V1)))==t_cons)){
	goto L982;}
	if(!((CAADR((V1)))==(VV[58]))){
	goto L982;}
	if(!(CDADR((V1))==Cnil)){
	goto L983;}
L982:
	RETURN((*LK5)(2,VV[108],(V1))             /*  WARN            */);
L983:
	{register object V27;
	register object V28;                      /*  FNAME           */
	V27= CDDR((V1));
	V28= Cnil;
L994:
	if(!((V27)==Cnil)){
	goto L995;}
	VALUES(0) = Ct;
	RETURN(1);
L995:
	V28= CAR((V27));
	if((getf((V28)->s.s_plist,VV[46],Cnil))==Cnil){
	goto L1001;}
	L10(1,CADADR((V1)))                       /*  FUNCTION-ARG-TYPES*/;
	T0= VALUES(0);
	if(!(equal(T0,getf((V28)->s.s_plist,VV[44],Cnil)))){
	goto L1001;}
	L11(1,CDDADR((V1)))                       /*  FUNCTION-RETURN-TYPE*/;
	T0= VALUES(0);
	if(equal(T0,getf((V28)->s.s_plist,VV[45],Cnil))){
	goto L1000;}
L1001:
	VALUES(0) = Cnil;
	RETURN(1);
L1000:
	V27= CDR((V27));
	goto L994;
	}
L981:
	if((V2!= VV[58]))goto L1012;
	if(CDR((V1))==Cnil){
	goto L1013;}
	if(!(CDDR((V1))==Cnil)){
	goto L1014;}
L1013:
	RETURN((*LK5)(2,VV[109],(V1))             /*  WARN            */);
L1014:
	if((getf(CADR((V1))->s.s_plist,VV[46],Cnil))!=Cnil){
	goto L1018;}
	VALUES(0) = Cnil;
	RETURN(1);
L1018:
	L10(1,CADDR((V1)))                        /*  FUNCTION-ARG-TYPES*/;
	T0= VALUES(0);
	if(equal(T0,getf(CADR((V1))->s.s_plist,VV[44],Cnil))){
	goto L1020;}
	VALUES(0) = Cnil;
	RETURN(1);
L1020:
	L11(1,CDDDR((V1)))                        /*  FUNCTION-RETURN-TYPE*/;
	T0= VALUES(0);
	VALUES(0) = (equal(T0,getf(CADR((V1))->s.s_plist,VV[45],Cnil))?Ct:Cnil);
	RETURN(1);
L1012:
	if((V2!= VV[89]))goto L1024;
	{register object V31;
	register object V32;                      /*  FUN             */
	V31= CDR((V1));
	V32= Cnil;
L1028:
	if(!((V31)==Cnil)){
	goto L1029;}
	VALUES(0) = Ct;
	RETURN(1);
L1029:
	V32= CAR((V31));
	if(!(type_of((V32))==t_symbol)){
	goto L1036;}
	if((getf((V32)->s.s_plist,VV[52],Cnil))==Cnil){
	goto L1034;}
	VALUES(0) = Cnil;
	RETURN(1);
L1036:
	(*LK5)(2,VV[110],(V32))                   /*  WARN            */;
L1034:
	V31= CDR((V31));
	goto L1028;
	}
L1024:
	if((V2!= VV[91]))goto L1043;
	{register object V35;
	register object V36;                      /*  FUN             */
	V35= CDR((V1));
	V36= Cnil;
L1047:
	if(!((V35)==Cnil)){
	goto L1048;}
	VALUES(0) = Ct;
	RETURN(1);
L1048:
	V36= CAR((V35));
	if(!(type_of((V36))==t_symbol)){
	goto L1055;}
	if((getf((V36)->s.s_plist,VV[52],Cnil))!=Cnil){
	goto L1053;}
	VALUES(0) = Cnil;
	RETURN(1);
L1055:
	(*LK5)(2,VV[111],(V36))                   /*  WARN            */;
L1053:
	V35= CDR((V35));
	goto L1047;
	}
L1043:
	if((V2!= VV[77])
	&& (V2!= VV[157]))goto L1062;
	{register object V39;
	object V40;                               /*  VAR             */
	V39= CDR((V1));
	V40= Cnil;
L1066:
	if(!((V39)==Cnil)){
	goto L1067;}
	VALUES(0) = Ct;
	RETURN(1);
L1067:
	V40= CAR((V39));
	if(type_of((V40))==t_symbol){
	goto L1072;}
	(*LK5)(2,VV[112],(V40))                   /*  WARN            */;
L1072:
	V39= CDR((V39));
	goto L1066;
	}
L1062:
	if((V2!= VV[93]))goto L1078;
	{register object V42;
	register object V43;                      /*  X               */
	V42= CDR((V1));
	V43= Cnil;
L1082:
	if(!((V42)==Cnil)){
	goto L1083;}
	VALUES(0) = Ct;
	RETURN(1);
L1083:
	V43= CAR((V42));
	if(!(type_of((V43))==t_symbol)){
	goto L1090;}
	if((memql((V43),(VV[51]->s.s_dbind)))!=Cnil){
	goto L1088;}
	VALUES(0) = Cnil;
	RETURN(1);
L1090:
	(*LK5)(2,VV[113],(V43))                   /*  WARN            */;
L1088:
	V42= CDR((V42));
	goto L1082;
	}
L1078:
	if((V2== VV[158])
	|| (V2== VV[159])
	|| (V2== VV[160])
	|| (V2== VV[161])
	|| (V2== VV[162]))goto L1098;
	if((V2== VV[154])
	|| (V2== VV[163])
	|| (V2== VV[164])
	|| (V2== VV[165])
	|| (V2== VV[166]))goto L1098;
	if((V2== VV[167])
	|| (V2== VV[153])
	|| (V2== VV[168])
	|| (V2== VV[169])
	|| (V2== VV[170]))goto L1098;
	if((V2== VV[171])
	|| (V2== VV[172])
	|| (V2== VV[156])
	|| (V2== Cnil)
	|| (V2== VV[173]))goto L1098;
	if((V2== VV[174])
	|| (V2== VV[175])
	|| (V2== VV[176])
	|| (V2== VV[177])
	|| (V2== VV[178]))goto L1098;
	if((V2== VV[179])
	|| (V2== VV[180])
	|| (V2== VV[181])
	|| (V2== VV[155])
	|| (V2== VV[182]))goto L1098;
	if((V2== VV[183])
	|| (V2== VV[184])
	|| (V2== VV[185])
	|| (V2== VV[186])
	|| (V2== VV[187]))goto L1098;
	if((V2== VV[188])
	|| (V2== VV[189])
	|| (V2== VV[190])
	|| (V2== VV[191])
	|| (V2== Ct))goto L1098;
	if((V2!= VV[192])
	&& (V2!= VV[193])
	&& (V2!= VV[194]))goto L1097;
L1098:
	{register object V46;
	register object V47;                      /*  VAR             */
	V46= CDR((V1));
	V47= Cnil;
L1102:
	if(!((V46)==Cnil)){
	goto L1103;}
	VALUES(0) = Ct;
	RETURN(1);
L1103:
	V47= CAR((V46));
	if(!(type_of((V47))==t_symbol)){
	goto L1110;}
	{object V49= getf((V47)->s.s_plist,VV[67],Cnil);
	(*LK4)(1,CAR((V1)))                       /*  TYPE-FILTER     */;
	if(equal(V49,VALUES(0))){
	goto L1108;}}
	VALUES(0) = Cnil;
	RETURN(1);
L1110:
	(*LK5)(2,VV[114],(V47))                   /*  WARN            */;
L1108:
	V46= CDR((V46));
	goto L1102;
	}
L1097:
	if((memql(CAR((V1)),(VV[51]->s.s_dbind)))!=Cnil){
	goto L1119;}
	RETURN((*LK5)(2,VV[115],CAR((V1)))        /*  WARN            */);
L1119:
	VALUES(0) = Cnil;
	RETURN(1);}
}
static LKF16(int narg, ...) {TRAMPOLINK(VV[204],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[203],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[202],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[201],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[200],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[197],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[196],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[195],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[148],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[147],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[146],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[145],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[144],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[143],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[142],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[141],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[140],&LK0);}
