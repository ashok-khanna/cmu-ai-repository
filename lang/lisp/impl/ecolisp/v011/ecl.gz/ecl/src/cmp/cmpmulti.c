
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "cmpmulti.h"
init_cmpmulti(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_cmpmulti; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	MF0(VV[40],L1);
	MF0(VV[41],L2);
	MF0(VV[42],L3);
	MF0(VV[43],L4);
	MF0(VV[44],L5);
	MF0(VV[45],L6);
	MF0(VV[46],L7);
	MF0(VV[47],L8);
	MF0(VV[48],L9);
	MF0(VV[49],L10);
	MF0(VV[50],L11);
	VALUES(0) = (VV[40]->s.s_gfdef);
	putprop(VV[0],VALUES(0),VV[37]);
	VALUES(0) = (VV[41]->s.s_gfdef);
	putprop(VV[0],VALUES(0),VV[38]);
	VALUES(0) = (VV[42]->s.s_gfdef);
	putprop(VV[6],VALUES(0),VV[37]);
	VALUES(0) = (VV[43]->s.s_gfdef);
	putprop(VV[6],VALUES(0),VV[38]);
	VALUES(0) = (VV[44]->s.s_gfdef);
	putprop(VV[4],VALUES(0),VV[39]);
	VALUES(0) = (VV[45]->s.s_gfdef);
	putprop(VV[4],VALUES(0),VV[38]);
	VALUES(0) = (VV[46]->s.s_gfdef);
	putprop(VV[16],VALUES(0),VV[39]);
	VALUES(0) = (VV[48]->s.s_gfdef);
	putprop(VV[16],VALUES(0),VV[38]);
	VALUES(0) = (VV[49]->s.s_gfdef);
	putprop(VV[29],VALUES(0),VV[39]);
	VALUES(0) = (VV[50]->s.s_gfdef);
	putprop(VV[29],VALUES(0),VV[38]);
}
/*	function definition for C1MULTIPLE-VALUE-CALL                 */
static L1(int narg, object V1)
{ VT3 VLEX3 CLSR3
TTL:
	{object V2;                               /*  INFO            */
	object V3;                                /*  FUNOB           */
	V2= Cnil;
	V3= Cnil;
	if(!((V1)==Cnil)){
	goto L23;}
	(*LK0)(3,VV[0],MAKE_FIXNUM(1),MAKE_FIXNUM(0))/*  TOO-FEW-ARGS */;
L23:
	if(!(CDR((V1))==Cnil)){
	goto L27;}
	RETURN((*LK1)(1,(V1))                     /*  C1FUNCALL       */);
L27:
	(*LK2)(1,CAR((V1)))                       /*  C1FUNOB         */;
	V3= VALUES(0);
	(*LK3)(1,CADR((V3)))                      /*  COPY-INFO       */;
	V2= VALUES(0);
	(*LK4)(2,CDR((V1)),(V2))                  /*  C1ARGS          */;
	V1= VALUES(0);
	VALUES(0) = list(4,VV[0],(V2),(V3),(V1));
	RETURN(1);
	}
}
/*	function definition for C2MULTIPLE-VALUE-CALL                 */
static L2(int narg, object V1, object V2)
{ VT4 VLEX4 CLSR4
	bds_check;
TTL:
	{volatile object V3;                      /*  TOT             */
	volatile object V4;
	volatile object V5;                       /*  NR              */
	volatile object V6;
	volatile object V7;                       /*  LOC             */
	(*LK5)(0)                                 /*  NEXT-LCL        */;
	V4= list(2,VV[1],VALUES(0));
	(*LK5)(0)                                 /*  NEXT-LCL        */;
	V6= list(2,VV[1],VALUES(0));
	(*LK6)(1,(V1))                            /*  SAVE-FUNOB      */;
	V7= VALUES(0);
	V3= V4;
	V5= V6;
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{ int ",symbol_value(VV[2]));
	(*LK7)(1,(V5))                            /*  WT1             */;
	princ_char(44,symbol_value(VV[2]));
	(*LK7)(1,(V3))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[2]));
	{object V8;
	V8= list(2,VV[4],(V3));
	bds_bind(VV[3],V8);                       /*  *DESTINATION*   */
	(*LK8)(1,CAR((V2)))                       /*  C2EXPR*         */;
	bds_unwind1;
	}
	{volatile object V8;
	volatile object V9;                       /*  FORM            */
	V8= CDR((V2));
	V9= Cnil;
L54:
	if(!((V8)==Cnil)){
	goto L55;}
	goto L50;
L55:
	V9= CAR((V8));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("MV_SAVE(",symbol_value(VV[2]));
	(*LK7)(1,(V3))                            /*  WT1             */;
	princ_str(");",symbol_value(VV[2]));
	{object V11;
	V11= list(2,VV[4],(V5));
	bds_bind(VV[3],V11);                      /*  *DESTINATION*   */
	(*LK8)(1,(V9))                            /*  C2EXPR*         */;
	bds_unwind1;
	}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("MV_SHIFT(",symbol_value(VV[2]));
	(*LK7)(1,(V5))                            /*  WT1             */;
	princ_char(44,symbol_value(VV[2]));
	(*LK7)(1,(V3))                            /*  WT1             */;
	princ_str(");",symbol_value(VV[2]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("MV_RESTORE(",symbol_value(VV[2]));
	(*LK7)(1,(V3))                            /*  WT1             */;
	princ_str(");",symbol_value(VV[2]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	(*LK7)(1,(V3))                            /*  WT1             */;
	princ_str("+=",symbol_value(VV[2]));
	(*LK7)(1,(V5))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[2]));
	V8= CDR((V8));
	goto L54;
	}
L50:
	(*LK9)(4,(V1),VV[5],(V7),(V3))            /*  C2FUNCALL       */;
	princ_char(125,symbol_value(VV[2]));
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for C1MULTIPLE-VALUE-PROG1                */
static L3(int narg, object V1)
{ VT5 VLEX5 CLSR5
TTL:
	{object V2;                               /*  INFO            */
	object V3;                                /*  FORM            */
	(*LK10)(0)                                /*  MAKE-INFO       */;
	V2= VALUES(0);
	V3= Cnil;
	if(!((V1)==Cnil)){
	goto L96;}
	(*LK0)(3,VV[6],MAKE_FIXNUM(1),MAKE_FIXNUM(0))/*  TOO-FEW-ARGS */;
L96:
	(*LK11)(2,CAR((V1)),(V2))                 /*  C1EXPR*         */;
	V3= VALUES(0);
	(*LK4)(2,CDR((V1)),(V2))                  /*  C1ARGS          */;
	V1= VALUES(0);
	VALUES(0) = list(4,VV[6],(V2),(V3),(V1));
	RETURN(1);
	}
}
/*	function definition for C2MULTIPLE-VALUE-PROG1                */
static L4(int narg, object V1, object V2)
{ VT6 VLEX6 CLSR6
	bds_check;
TTL:
	if(!((VV[7])==((VV[3]->s.s_dbind)))){
	goto L104;}
	RETURN((*LK12)(1,CONS((V1),(V2)))         /*  C2PROGN         */);
L104:
	{volatile object V3;                      /*  NR              */
	volatile object V4;                       /*  VALUES_NR       */
	(*LK5)(0)                                 /*  NEXT-LCL        */;
	V3= list(2,VV[1],VALUES(0));
	V4= list(2,VV[4],(V3));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{ int ",symbol_value(VV[2]));
	(*LK7)(1,(V3))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[2]));
	bds_bind(VV[3],(V4));                     /*  *DESTINATION*   */
	(*LK8)(1,(V1))                            /*  C2EXPR*         */;
	bds_unwind1;
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("MV_SAVE(",symbol_value(VV[2]));
	(*LK7)(1,(V3))                            /*  WT1             */;
	princ_str(");",symbol_value(VV[2]));
	{volatile object V5;
	volatile object V6;                       /*  FORM            */
	V5= (V2);
	V6= Cnil;
L126:
	if(!((V5)==Cnil)){
	goto L127;}
	goto L122;
L127:
	V6= CAR((V5));
	bds_bind(VV[3],VV[7]);                    /*  *DESTINATION*   */
	(*LK8)(1,(V6))                            /*  C2EXPR*         */;
	bds_unwind1;
	V5= CDR((V5));
	goto L126;
	}
L122:
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("MV_RESTORE(",symbol_value(VV[2]));
	(*LK7)(1,(V3))                            /*  WT1             */;
	princ_str(");",symbol_value(VV[2]));
	(*LK13)(1,(V4))                           /*  UNWIND-EXIT     */;
	princ_char(125,symbol_value(VV[2]));
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for C1VALUES                              */
static L5(int narg, object V1)
{ VT7 VLEX7 CLSR7
TTL:
	{object V2;                               /*  INFO            */
	(*LK10)(0)                                /*  MAKE-INFO       */;
	V2= VALUES(0);
	if(((V1))==Cnil){
	goto L146;}
	if((CDR((V1)))!=Cnil){
	goto L146;}
	RETURN((*LK14)(1,CAR((V1)))               /*  C1EXPR          */);
L146:
	(*LK4)(2,(V1),(V2))                       /*  C1ARGS          */;
	V1= VALUES(0);
	VALUES(0) = list(3,VV[4],(V2),(V1));
	RETURN(1);
	}
}
/*	function definition for C2VALUES                              */
static L6(int narg, object V1)
{ VT8 VLEX8 CLSR8
	bds_check;
TTL:
	if(!(((VV[3]->s.s_dbind))==(VV[8]))){
	goto L152;}
	if((CDR((V1)))==Cnil){
	goto L152;}
	if(!(type_of((VV[9]->s.s_dbind))==t_cons)){
	goto L152;}
	if(!((VV[10])==(CAR((VV[9]->s.s_dbind))))){
	goto L152;}
	(*LK15)(2,VV[11],CADR((VV[9]->s.s_dbind)))/*  CMPWARN         */;
L152:
	{volatile int V2;                         /*  NV              */
	V2= length((V1));
	if(!eql(MAKE_FIXNUM(V2),VV[12]))goto L162;
	RETURN((*LK13)(1,VV[13])                  /*  UNWIND-EXIT     */);
L162:
	if(!eql(MAKE_FIXNUM(V2),VV[14]))goto L163;
	RETURN((*LK16)(1,CAR((V1)))               /*  C2EXPR          */);
L163:
	bds_bind(VV[15],MAKE_FIXNUM(0));          /*  *INLINE-BLOCKS* */
	{volatile object V3;                      /*  VL              */
	volatile int V4;                          /*  I               */
	(*LK17)(1,(V1))                           /*  INLINE-ARGS     */;
	V3= nreverse(VALUES(0));
	V4= (length((V1)))-1;
L169:
	if(((V3))!=Cnil){
	goto L170;}
	goto L164;
L170:
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("VALUES(",symbol_value(VV[2]));
	(*LK7)(1,MAKE_FIXNUM(V4))                 /*  WT1             */;
	princ_str(") = ",symbol_value(VV[2]));
	(*LK7)(1,CADR(CAR((V3))))                 /*  WT1             */;
	princ_char(59,symbol_value(VV[2]));
	V3= CDR((V3));
	V4= (V4)-1;
	goto L169;
	}
L164:
	(*LK13)(1,list(2,VV[4],MAKE_FIXNUM(V2)))  /*  UNWIND-EXIT     */;
	{int V3;
	V3=(*LK18)(0)                             /*  CLOSE-INLINE-BLOCKS*/;
	bds_unwind1;
	RETURN(V3);}
	}
}
/*	function definition for C1MULTIPLE-VALUE-SETQ                 */
static L7(int narg, object V1)
{ VT9 VLEX9 CLSR9
TTL:
	{register object V2;                      /*  INFO            */
	register object V3;                       /*  VREFS           */
	(*LK10)(0)                                /*  MAKE-INFO       */;
	V2= VALUES(0);
	V3= Cnil;
	if((V1)==Cnil){
	goto L189;}
	if(!(CDR((V1))==Cnil)){
	goto L188;}
L189:
	(*LK0)(3,VV[16],MAKE_FIXNUM(2),MAKE_FIXNUM(0))/*  TOO-FEW-ARGS*/;
L188:
	if(CDDR((V1))==Cnil){
	goto L193;}
	(*LK19)(3,VV[16],MAKE_FIXNUM(2),MAKE_FIXNUM(length((V1))))/*  TOO-MANY-ARGS*/;
L193:
	{volatile object V4;
	volatile object V5;                       /*  VAR             */
	V4= CAR((V1));
	V5= Cnil;
L200:
	if(!((V4)==Cnil)){
	goto L201;}
	goto L196;
L201:
	V5= CAR((V4));
	if(type_of((V5))==t_symbol){
	goto L206;}
	(*LK20)(2,VV[17],(V5))                    /*  CMPERR          */;
L206:
	Lconstantp(1,(V5))                        /*  CONSTANTP       */;
	if(VALUES(0)==Cnil){
	goto L209;}
	(*LK20)(2,VV[18],(V5))                    /*  CMPERR          */;
L209:
	(*LK21)(1,(V5))                           /*  C1VREF          */;
	V5= VALUES(0);
	V3= CONS((V5),(V3));
	{register object V7;
	V7= (V2);
	elt_set((V7),1,CONS(CAR((V5)),((V7))->v.v_self[1]));
	}
	V4= CDR((V4));
	goto L200;
	}
L196:
	{object V4= nreverse((V3));
	(*LK11)(2,CADR((V1)),(V2))                /*  C1EXPR*         */;
	VALUES(0) = list(4,VV[16],(V2),(V4),VALUES(0));
	RETURN(1);}
	}
}
/*	function definition for MULTIPLE-VALUE-CHECK                  */
static L8(int narg, object V1, object V2)
{ VT10 VLEX10 CLSR10
TTL:
	if((CDR((V1)))!=Cnil){
	goto L222;}
	VALUES(0) = Cnil;
	RETURN(1);
L222:
	if((CAR((V2)))==(VV[19])){
	goto L224;}
	VALUES(0) = Cnil;
	RETURN(1);
L224:
	{object V3;                               /*  FNAME           */
	V3= CADDR((V2));
	if(!(type_of((V3))==t_symbol)){
	goto L228;}
	if((getf((V3)->s.s_plist,VV[20],Cnil))==Cnil){
	goto L228;}
	RETURN((*LK15)(2,VV[21],(V3))             /*  CMPWARN         */);
L228:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for C2MULTIPLE-VALUE-SETQ                 */
static L9(int narg, object V1, object V2)
{ VT11 VLEX11 CLSR11
	bds_check;
TTL:
	L8(2,(V1),(V2))                           /*  MULTIPLE-VALUE-CHECK*/;
	{volatile object V3;                      /*  NR              */
	bds_bind(VV[22],(VV[22]->s.s_dbind));     /*  *LCL*           */
	(*LK5)(0)                                 /*  NEXT-LCL        */;
	V3= list(2,VV[1],VALUES(0));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{ int ",symbol_value(VV[2]));
	(*LK7)(1,(V3))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[2]));
	{object V4;
	V4= list(2,VV[4],(V3));
	bds_bind(VV[3],V4);                       /*  *DESTINATION*   */
	(*LK8)(1,(V2))                            /*  C2EXPR*         */;
	bds_unwind1;
	}
	{volatile object V4;                      /*  VS              */
	volatile int V5;                          /*  I               */
	volatile object V6;                       /*  VREF            */
	V5= 0;
	V4= (V1);
	V6= Cnil;
L246:
	if(!((V4)==Cnil)){
	goto L247;}
	goto L243;
L247:
	V6= CAR((V4));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if (",symbol_value(VV[2]));
	(*LK7)(1,(V3))                            /*  WT1             */;
	princ_str(">0) {",symbol_value(VV[2]));
	(*LK22)(2,list(2,VV[23],MAKE_FIXNUM(V5)),CAR((V6)))/*  SET-VAR*/;
	if(CDR((V4))==Cnil){
	goto L259;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	(*LK7)(1,(V3))                            /*  WT1             */;
	princ_str("--;",symbol_value(VV[2]));
L259:
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("} else {",symbol_value(VV[2]));
	(*LK22)(2,Cnil,CAR((V6)))                 /*  SET-VAR         */;
	princ_char(125,symbol_value(VV[2]));
	V4= CDR((V4));
	V5= (V5)+1;
	goto L246;
	}
L243:
	if(((VV[24]->s.s_dbind))==(VV[25])){
	goto L277;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
L277:
	if(((V1))==Cnil){
	goto L285;}
	VALUES(0) = CONS(VV[26],CAR((V1)));
	goto L283;
L285:
	VALUES(0) = VV[27];
L283:
	(*LK13)(1,VALUES(0))                      /*  UNWIND-EXIT     */;
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_char(125,symbol_value(VV[2]));
	{int V4;
	VALUES(0)=Cnil;
	V4=1;
	bds_unwind1;
	RETURN(V4);}
	}
}
/*	function definition for C1MULTIPLE-VALUE-BIND                 */
static L10(int narg, object V1)
{ VT12 VLEX12 CLSR12
	bds_check;
TTL:
	{object V2;                               /*  INFO            */
	register object V3;                       /*  VARS            */
	object V4;                                /*  VNAMES          */
	object V5;                                /*  INIT-FORM       */
	object V6;                                /*  SS              */
	object V7;                                /*  IS              */
	object V8;                                /*  TS              */
	object V9;                                /*  BODY            */
	object V10;                               /*  OTHER-DECLS     */
	(*LK10)(0)                                /*  MAKE-INFO       */;
	V2= VALUES(0);
	V3= Cnil;
	V4= Cnil;
	V5= Cnil;
	V6= Cnil;
	V7= Cnil;
	V8= Cnil;
	V9= Cnil;
	V10= Cnil;
	bds_bind(VV[28],(VV[28]->s.s_dbind));     /*  *VARS*          */
	if((V1)==Cnil){
	goto L300;}
	if(!(CDR((V1))==Cnil)){
	goto L299;}
L300:
	(*LK0)(3,VV[29],MAKE_FIXNUM(2),MAKE_FIXNUM(length((V1))))/*  TOO-FEW-ARGS*/;
L299:
	{ int V11;
	V11=(*LK23)(2,CDDR((V1)),Cnil)            /*  C1BODY          */;
	if (V11>0) {
	V9= VALUES(0);
	V11--;
	} else {
	V9= Cnil;}
	if (V11>0) {
	V6= VALUES(1);
	V11--;
	} else {
	V6= Cnil;}
	if (V11>0) {
	V8= VALUES(2);
	V11--;
	} else {
	V8= Cnil;}
	if (V11>0) {
	V7= VALUES(3);
	V11--;
	} else {
	V7= Cnil;}
	if (V11>0) {
	V10= VALUES(4);
	} else {
	V10= Cnil;}
	
	}
	(*LK24)(1,(V6))                           /*  C1ADD-GLOBALS   */;
	{volatile object V11;
	volatile object V12;                      /*  S               */
	V11= CAR((V1));
	V12= Cnil;
L311:
	if(!((V11)==Cnil)){
	goto L312;}
	goto L307;
L312:
	V12= CAR((V11));
	V4= CONS((V12),(V4));
	(*LK25)(4,(V12),(V6),(V7),(V8))           /*  C1MAKE-VAR      */;
	V3= CONS(VALUES(0),(V3));
	V11= CDR((V11));
	goto L311;
	}
L307:
	(*LK11)(2,CADR((V1)),(V2))                /*  C1EXPR*         */;
	V5= VALUES(0);
	{volatile object V11;
	volatile object V12;                      /*  V               */
	V3= nreverse((V3));
	V11= (V3);
	V12= Cnil;
L332:
	if(!((V11)==Cnil)){
	goto L333;}
	goto L327;
L333:
	V12= CAR((V11));
	(VV[28]->s.s_dbind)= CONS((V12),(VV[28]->s.s_dbind));
	V11= CDR((V11));
	goto L332;
	}
L327:
	(*LK26)(3,(V4),(V8),(V7))                 /*  CHECK-VDECL     */;
	(*LK27)(2,(V10),(V9))                     /*  C1DECL-BODY     */;
	V9= VALUES(0);
	(*LK28)(2,(V2),CADR((V9)))                /*  ADD-INFO        */;
	elt_set((V2),3,(CADR((V9)))->v.v_self[3]);
	{volatile object V11;
	volatile object V12;                      /*  VAR             */
	V11= (V3);
	V12= Cnil;
L352:
	if(!((V11)==Cnil)){
	goto L353;}
	goto L348;
L353:
	V12= CAR((V11));
	(*LK29)(1,(V12))                          /*  CHECK-VREF      */;
	V11= CDR((V11));
	goto L352;
	}
L348:
	{int V11;
	VALUES(0)=list(5,VV[29],(V2),(V3),(V5),(V9));
	V11=1;
	bds_unwind1;
	RETURN(V11);}
	}
}
/*	function definition for C2MULTIPLE-VALUE-BIND                 */
static L11(int narg, object V1, object V2, object V3)
{ VT13 VLEX13 CLSR13
	bds_check;
TTL:
	{register object V4;                      /*  LABELS          */
	object V5;                                /*  ENV-GROWS       */
	object V6;                                /*  NR              */
	V4= Cnil;
	bds_bind(VV[30],(VV[30]->s.s_dbind));     /*  *UNWIND-EXIT*   */
	bds_bind(VV[31],(VV[31]->s.s_dbind));     /*  *ENV*           */
	V5= Cnil;
	bds_bind(VV[22],(VV[22]->s.s_dbind));     /*  *LCL*           */
	(*LK5)(0)                                 /*  NEXT-LCL        */;
	V6= list(2,VV[1],VALUES(0));
	L8(2,(V1),(V2))                           /*  MULTIPLE-VALUE-CHECK*/;
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{ int ",symbol_value(VV[2]));
	(*LK7)(1,(V6))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[2]));
	{volatile object V7;
	volatile object V8;                       /*  VAR             */
	V7= (V1);
	V8= Cnil;
L377:
	if(!((V7)==Cnil)){
	goto L378;}
	goto L373;
L378:
	V8= CAR((V7));
	{object V10;                              /*  KIND            */
	(*LK30)(1,(V8))                           /*  LOCAL           */;
	V10= VALUES(0);
	if(((V10))==Cnil){
	goto L386;}
	{object V11;                              /*  LCL             */
	(*LK5)(0)                                 /*  NEXT-LCL        */;
	V11= VALUES(0);
	elt_set((V8),5,(V11));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	(*LK7)(1,(VV[32]->s.s_dbind))             /*  WT1             */;
	(*LK31)(1,(V8))                           /*  REGISTER        */;
	(*LK7)(1,VALUES(0))                       /*  WT1             */;
	(*LK32)(1,(V10))                          /*  REP-TYPE        */;
	(*LK7)(1,VALUES(0))                       /*  WT1             */;
	(*LK33)(1,(V11))                          /*  WT-LCL          */;
	princ_char(59,symbol_value(VV[2]));
	(*LK34)(1,((V8))->v.v_self[0])            /*  WT-COMMENT      */;
	goto L383;
	}
L386:
	if(((V5))!=Cnil){
	goto L383;}
	V5= ((V8))->v.v_self[2];
	}
L383:
	V7= CDR((V7));
	goto L377;
	}
L373:
	{object V7;
	V7= list(2,VV[4],(V6));
	bds_bind(VV[3],V7);                       /*  *DESTINATION*   */
	(*LK8)(1,(V2))                            /*  C2EXPR*         */;
	bds_unwind1;
	}
	bds_bind(VV[33],(VV[33]->s.s_dbind));     /*  *ENV-LVL*       */
	(*LK35)(1,(V5))                           /*  ENV-GROWS       */;
	V5= VALUES(0);
	if(((V5))==Cnil){
	goto L410;}
	{object V7;                               /*  ENV-LVL         */
	V7= (VV[33]->s.s_dbind);
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{ object env",symbol_value(VV[2]));
	(VV[33]->s.s_dbind)= number_plus((VV[33]->s.s_dbind),MAKE_FIXNUM(1));
	(*LK7)(1,(VV[33]->s.s_dbind))             /*  WT1             */;
	princ_str(" = env",symbol_value(VV[2]));
	(*LK7)(1,(V7))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[2]));
	}
L410:
	bds_bind(VV[30],(VV[30]->s.s_dbind));     /*  *UNWIND-EXIT*   */
	{volatile object V7;                      /*  VS              */
	volatile int V8;                          /*  I               */
	volatile object V9;                       /*  VALUE           */
	V8= 0;
	V7= (V1);
	V9= VV[34];
L425:
	if(!((V7)==Cnil)){
	goto L426;}
	bds_unwind1;
	goto L422;
L426:
	(VV[35]->s.s_dbind)= number_plus((VV[35]->s.s_dbind),MAKE_FIXNUM(1));
	V4= CONS(CONS((VV[35]->s.s_dbind),Cnil),(V4));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if (",symbol_value(VV[2]));
	(*LK7)(1,(V6))                            /*  WT1             */;
	princ_str("--==0) ",symbol_value(VV[2]));
	CDR(CAR((V4))) = Ct;
	princ_str("goto L",symbol_value(VV[2]));
	(*LK7)(1,CAR(CAR((V4))))                  /*  WT1             */;
	princ_char(59,symbol_value(VV[2]));
	{object V11;
	register int V12;
	V11= (V9);
	V12= V8;
	CAR(CDR((V11))) = MAKE_FIXNUM(V12);
	}
	(*LK36)(2,(V9),CAR((V7)))                 /*  BIND            */;
	V7= CDR((V7));
	V8= (V8)+1;
	goto L425;
	}
L422:
	{volatile object V7;                      /*  LABEL           */
	(VV[35]->s.s_dbind)= number_plus((VV[35]->s.s_dbind),MAKE_FIXNUM(1));
	V7= CONS((VV[35]->s.s_dbind),Cnil);
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	CDR((V7)) = Ct;
	princ_str("goto L",symbol_value(VV[2]));
	(*LK7)(1,CAR((V7)))                       /*  WT1             */;
	princ_char(59,symbol_value(VV[2]));
	V4= nreverse((V4));
	bds_bind(VV[36],Ct);                      /*  *SUPPRESS-COMPILER-WARNINGS**/
	{volatile object V8;
	volatile object V9;                       /*  V               */
	V8= (V1);
	V9= Cnil;
L469:
	if(!((V8)==Cnil)){
	goto L470;}
	bds_unwind1;
	goto L465;
L470:
	V9= CAR((V8));
	if((CDR(CAR((V4))))==Cnil){
	goto L475;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(76,symbol_value(VV[2]));
	(*LK7)(1,CAR(CAR((V4))))                  /*  WT1             */;
	princ_char(58,symbol_value(VV[2]));
L475:
	{object V11;
	V11= CAR((V4));
	V4= CDR((V4));
	}
	(*LK37)(1,((V9))->v.v_self[6])            /*  DEFAULT-INIT    */;
	(*LK36)(2,CADDR(VALUES(0)),(V9))          /*  BIND            */;
	V8= CDR((V8));
	goto L469;
	}
L465:
	if((CDR((V7)))==Cnil){
	goto L452;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(76,symbol_value(VV[2]));
	(*LK7)(1,CAR((V7)))                       /*  WT1             */;
	princ_char(58,symbol_value(VV[2]));
	}
L452:
	(*LK16)(1,(V3))                           /*  C2EXPR          */;
	if(((V5))==Cnil){
	bds_unwind1;
	goto L409;}
	princ_char(125,symbol_value(VV[2]));
	bds_unwind1;
L409:
	princ_char(125,symbol_value(VV[2]));
	{int V7;
	VALUES(0)=Cnil;
	V7=1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V7);}
	}
}
static LKF37(int narg, ...) {TRAMPOLINK(VV[88],&LK37);}
static LKF36(int narg, ...) {TRAMPOLINK(VV[87],&LK36);}
static LKF35(int narg, ...) {TRAMPOLINK(VV[86],&LK35);}
static LKF34(int narg, ...) {TRAMPOLINK(VV[85],&LK34);}
static LKF33(int narg, ...) {TRAMPOLINK(VV[84],&LK33);}
static LKF32(int narg, ...) {TRAMPOLINK(VV[83],&LK32);}
static LKF31(int narg, ...) {TRAMPOLINK(VV[82],&LK31);}
static LKF30(int narg, ...) {TRAMPOLINK(VV[81],&LK30);}
static LKF29(int narg, ...) {TRAMPOLINK(VV[80],&LK29);}
static LKF28(int narg, ...) {TRAMPOLINK(VV[79],&LK28);}
static LKF27(int narg, ...) {TRAMPOLINK(VV[78],&LK27);}
static LKF26(int narg, ...) {TRAMPOLINK(VV[77],&LK26);}
static LKF25(int narg, ...) {TRAMPOLINK(VV[76],&LK25);}
static LKF24(int narg, ...) {TRAMPOLINK(VV[75],&LK24);}
static LKF23(int narg, ...) {TRAMPOLINK(VV[74],&LK23);}
static LKF22(int narg, ...) {TRAMPOLINK(VV[73],&LK22);}
static LKF21(int narg, ...) {TRAMPOLINK(VV[72],&LK21);}
static LKF20(int narg, ...) {TRAMPOLINK(VV[71],&LK20);}
static LKF19(int narg, ...) {TRAMPOLINK(VV[70],&LK19);}
static LKF18(int narg, ...) {TRAMPOLINK(VV[69],&LK18);}
static LKF17(int narg, ...) {TRAMPOLINK(VV[68],&LK17);}
static LKF16(int narg, ...) {TRAMPOLINK(VV[67],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[66],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[65],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[64],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[63],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[62],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[61],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[60],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[59],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[58],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[57],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[56],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[55],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[54],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[53],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[52],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[51],&LK0);}
