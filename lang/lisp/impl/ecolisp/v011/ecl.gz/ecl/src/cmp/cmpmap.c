
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "cmpmap.h"
init_cmpmap(int size, object data_stream)
{VT2 CLSR2
	Cblock.cd_start=(char *)init_cmpmap; Cblock.cd_size=size;
	Cblock.cd_data=read_VV(VV,VM1,data_stream);
	MF0(VV[34],L1);
	MF0(VV[23],L2);
	MF0(VV[28],L6);
	MF0(VV[33],L10);
	MF0(VV[35],L14);
	putprop(VV[17],VV[19],VV[18]);
	putprop(VV[20],VV[21],VV[18]);
	putprop(VV[17],VV[23],VV[22]);
	putprop(VV[24],VV[25],VV[18]);
	putprop(VV[26],VV[27],VV[18]);
	putprop(VV[24],VV[28],VV[22]);
	putprop(VV[29],VV[30],VV[18]);
	putprop(VV[31],VV[32],VV[18]);
	putprop(VV[29],VV[33],VV[22]);
	MF0(VV[19],L15);
	MF0(VV[21],L16);
	MF0(VV[25],L17);
	MF0(VV[27],L18);
	MF0(VV[30],L19);
	MF0(VV[32],L20);
}
/*	function definition for C1MAP-FUNCTIONS                       */
static L1(int narg, object V1, object V2, object V3)
{ VT3 VLEX3 CLSR3
TTL:
	{object V4;                               /*  FUNOB           */
	object V5;                                /*  INFO            */
	V4= Cnil;
	V5= Cnil;
	if((V3)==Cnil){
	goto L13;}
	if(!(CDR((V3))==Cnil)){
	goto L12;}
L13:
	(*LK0)(3,VV[0],MAKE_FIXNUM(2),MAKE_FIXNUM(length((V3))))/*  TOO-FEW-ARGS*/;
L12:
	(*LK1)(1,CAR((V3)))                       /*  C1FUNOB         */;
	V4= VALUES(0);
	(*LK2)(1,CADR((V4)))                      /*  COPY-INFO       */;
	V5= VALUES(0);
	(*LK3)(2,CDR((V3)),(V5))                  /*  C1ARGS          */;
	VALUES(0) = list(5,(V1),(V5),(V4),(V2),VALUES(0));
	RETURN(1);
	}
}
/*	function definition for C2MAPCAR                              */
static L2(int narg, object V1, object V2, object V3)
{ VT4 VLEX4 CLSR4
	bds_check;
TTL:
	bds_bind(VV[1],MAKE_FIXNUM(0));           /*  *INLINE-BLOCKS* */
	{register object V4;                      /*  LABEL           */
	object V5;
	object V6;                                /*  VALUE-LOC       */
	object V7;
	register object V8;                       /*  HANDY           */
	object V9;
	register object V10;                      /*  HANDIES         */
	object V11;
	object V12;                               /*  SAVE            */
	(VV[2]->s.s_dbind)= number_plus((VV[2]->s.s_dbind),MAKE_FIXNUM(1));
	V5= CONS((VV[2]->s.s_dbind),Ct);
	(*LK4)(0)                                 /*  NEXT-TEMP       */;
	V7= list(2,VV[3],VALUES(0));
	(*LK5)(0)                                 /*  NEXT-LCL        */;
	V9= list(2,VV[4],VALUES(0));
	{object V13;
	object V14= (V3);
	if(V14==Cnil){
	V11= Cnil;
	goto L28;}
	T0=V13=CONS(Cnil,Cnil);
L29:
	(*LK5)(0)                                 /*  NEXT-LCL        */;
	CAR(V13)= list(2,VV[4],VALUES(0));
	if((V14=CDR(V14))==Cnil){
	V11= T0;
	goto L28;}
	V13=CDR(V13)=CONS(Cnil,Cnil);
	goto L29;}
L28:
	(*LK6)(1,(V1))                            /*  SAVE-FUNOB      */;
	V12= VALUES(0);
	V4= V5;
	V6= V7;
	V8= V9;
	V10= V11;
	(*LK7)(1,(V3))                            /*  INLINE-ARGS     */;
	(*LK8)(2,VALUES(0),Cnil)                  /*  COERCE-LOCS     */;
	L14(2,VALUES(0),(V1))                     /*  PUSH-CHANGED-VARS*/;
	V3= VALUES(0);
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{object ",symbol_value(VV[5]));
	(*LK9)(1,(V8))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[5]));
	{register object V13;
	object V14;                               /*  LOC             */
	V13= (V10);
	V14= Cnil;
L47:
	if(!((V13)==Cnil)){
	goto L48;}
	goto L43;
L48:
	V14= CAR((V13));
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	princ_str("object ",symbol_value(VV[5]));
	(*LK9)(1,(V14))                           /*  WT1             */;
	princ_str("= ",symbol_value(VV[5]));
	(*LK9)(1,CAR((V3)))                       /*  WT1             */;
	princ_char(59,symbol_value(VV[5]));
	V3= CDR((V3));
	V13= CDR((V13));
	goto L47;
	}
L43:
	if(((VV[6]->s.s_dbind))==Cnil){
	goto L69;}
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(endp(",symbol_value(VV[5]));
	(*LK9)(1,CAR((V10)))                      /*  WT1             */;
	princ_char(41,symbol_value(VV[5]));
	{register object V13;
	object V14;                               /*  LOC             */
	V13= CDR((V10));
	V14= Cnil;
L81:
	if(!((V13)==Cnil)){
	goto L82;}
	goto L77;
L82:
	V14= CAR((V13));
	princ_str("||endp(",symbol_value(VV[5]));
	(*LK9)(1,(V14))                           /*  WT1             */;
	princ_char(41,symbol_value(VV[5]));
	V13= CDR((V13));
	goto L81;
	}
L77:
	princ_str("){",symbol_value(VV[5]));
	goto L67;
L69:
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(",symbol_value(VV[5]));
	(*LK9)(1,CAR((V10)))                      /*  WT1             */;
	princ_str("==Cnil",symbol_value(VV[5]));
	{register object V13;
	object V14;                               /*  LOC             */
	V13= CDR((V10));
	V14= Cnil;
L105:
	if(!((V13)==Cnil)){
	goto L106;}
	goto L101;
L106:
	V14= CAR((V13));
	princ_str("||",symbol_value(VV[5]));
	(*LK9)(1,(V14))                           /*  WT1             */;
	princ_str("==Cnil",symbol_value(VV[5]));
	V13= CDR((V13));
	goto L105;
	}
L101:
	princ_str("){",symbol_value(VV[5]));
L67:
	(*LK10)(2,Cnil,VV[7])                     /*  UNWIND-EXIT     */;
	princ_char(125,symbol_value(VV[5]));
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	(*LK9)(1,(V6))                            /*  WT1             */;
	princ_char(61,symbol_value(VV[5]));
	(*LK9)(1,(V8))                            /*  WT1             */;
	princ_str("=CONS(Cnil,Cnil);",symbol_value(VV[5]));
	if((CDR((V4)))==Cnil){
	goto L129;}
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	princ_char(76,symbol_value(VV[5]));
	(*LK9)(1,CAR((V4)))                       /*  WT1             */;
	princ_char(58,symbol_value(VV[5]));
L129:
	bds_bind(VV[8],list(2,VV[9],CADR((V8)))); /*  *DESTINATION*   */
	(VV[2]->s.s_dbind)= number_plus((VV[2]->s.s_dbind),MAKE_FIXNUM(1));
	bds_bind(VV[10],CONS((VV[2]->s.s_dbind),Cnil));/*  *EXIT*     */
	bds_bind(VV[11],CONS((VV[10]->s.s_dbind),(VV[11]->s.s_dbind)));/*  *UNWIND-EXIT**/
	if(((V2))==Cnil){
	goto L144;}
	{object V13;
	object V14= (V10);
	if(V14==Cnil){
	VALUES(0) = Cnil;
	goto L142;}
	T0=V13=CONS(Cnil,Cnil);
L146:
	{object V15;                              /*  LOC             */
	{object V16= (VV[13]->s.s_dbind);
	CAR(V13)= list(3,VV[12],V16,list(2,VV[9],CADR(CAR(V14))));}
	}
	if((V14=CDR(V14))==Cnil){
	VALUES(0) = T0;
	goto L142;}
	V13=CDR(V13)=CONS(Cnil,Cnil);
	goto L146;}
L144:
	{object V17;
	object V18= (V10);
	if(V18==Cnil){
	VALUES(0) = Cnil;
	goto L142;}
	T1=V17=CONS(Cnil,Cnil);
L148:
	{object V19;                              /*  LOC             */
	CAR(V17)= list(3,VV[12],(VV[13]->s.s_dbind),CAR(V18));
	}
	if((V18=CDR(V18))==Cnil){
	VALUES(0) = T1;
	goto L142;}
	V17=CDR(V17)=CONS(Cnil,Cnil);
	goto L148;}
L142:
	(*LK11)(3,(V1),VALUES(0),(V12))           /*  C2FUNCALL       */;
	if((CDR((VV[10]->s.s_dbind)))==Cnil){
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	goto L136;}
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	princ_char(76,symbol_value(VV[5]));
	(*LK9)(1,CAR((VV[10]->s.s_dbind)))        /*  WT1             */;
	princ_char(58,symbol_value(VV[5]));
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
L136:
	if(((VV[6]->s.s_dbind))==Cnil){
	goto L158;}
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(endp(",symbol_value(VV[5]));
	(*LK9)(1,CAR((V10)))                      /*  WT1             */;
	princ_str("=CDR(",symbol_value(VV[5]));
	(*LK9)(1,CAR((V10)))                      /*  WT1             */;
	princ_str("))",symbol_value(VV[5]));
	{register object V13;
	object V14;                               /*  LOC             */
	V13= CDR((V10));
	V14= Cnil;
L172:
	if(!((V13)==Cnil)){
	goto L173;}
	goto L168;
L173:
	V14= CAR((V13));
	princ_str("||endp(",symbol_value(VV[5]));
	(*LK9)(1,(V14))                           /*  WT1             */;
	princ_str("=CDR(",symbol_value(VV[5]));
	(*LK9)(1,(V14))                           /*  WT1             */;
	princ_str("))",symbol_value(VV[5]));
	V13= CDR((V13));
	goto L172;
	}
L168:
	princ_str("){",symbol_value(VV[5]));
	goto L156;
L158:
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if((",symbol_value(VV[5]));
	(*LK9)(1,CAR((V10)))                      /*  WT1             */;
	princ_str("=CDR(",symbol_value(VV[5]));
	(*LK9)(1,CAR((V10)))                      /*  WT1             */;
	princ_str("))==Cnil",symbol_value(VV[5]));
	{register object V13;
	object V14;                               /*  LOC             */
	V13= CDR((V10));
	V14= Cnil;
L200:
	if(!((V13)==Cnil)){
	goto L201;}
	goto L196;
L201:
	V14= CAR((V13));
	princ_str("||(",symbol_value(VV[5]));
	(*LK9)(1,(V14))                           /*  WT1             */;
	princ_str("=CDR(",symbol_value(VV[5]));
	(*LK9)(1,(V14))                           /*  WT1             */;
	princ_str("))==Cnil",symbol_value(VV[5]));
	V13= CDR((V13));
	goto L200;
	}
L196:
	princ_str("){",symbol_value(VV[5]));
L156:
	(*LK10)(2,(V6),VV[7])                     /*  UNWIND-EXIT     */;
	princ_char(125,symbol_value(VV[5]));
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	(*LK9)(1,(V8))                            /*  WT1             */;
	princ_str("=CDR(",symbol_value(VV[5]));
	(*LK9)(1,(V8))                            /*  WT1             */;
	princ_str(")=CONS(Cnil,Cnil);",symbol_value(VV[5]));
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	CDR((V4)) = Ct;
	princ_str("goto L",symbol_value(VV[5]));
	(*LK9)(1,CAR((V4)))                       /*  WT1             */;
	princ_char(59,symbol_value(VV[5]));
	princ_char(125,symbol_value(VV[5]));
	{int V13;
	V13=(*LK12)(0)                            /*  CLOSE-INLINE-BLOCKS*/;
	bds_unwind1;
	RETURN(V13);}
	}
}
/*	function definition for C2MAPC                                */
static L6(int narg, object V1, object V2, object V3)
{ VT5 VLEX5 CLSR5
	bds_check;
TTL:
	bds_bind(VV[1],MAKE_FIXNUM(0));           /*  *INLINE-BLOCKS* */
	{register object V4;                      /*  LABEL           */
	object V5;
	object V6;                                /*  VALUE-LOC       */
	register object V7;                       /*  HANDIES         */
	object V8;                                /*  SAVE            */
	(VV[2]->s.s_dbind)= number_plus((VV[2]->s.s_dbind),MAKE_FIXNUM(1));
	V5= CONS((VV[2]->s.s_dbind),Ct);
	{object V9;
	object V10= (V3);
	if(V10==Cnil){
	V7= Cnil;
	goto L238;}
	T0=V9=CONS(Cnil,Cnil);
L239:
	(*LK5)(0)                                 /*  NEXT-LCL        */;
	CAR(V9)= list(2,VV[4],VALUES(0));
	if((V10=CDR(V10))==Cnil){
	V7= T0;
	goto L238;}
	V9=CDR(V9)=CONS(Cnil,Cnil);
	goto L239;}
L238:
	V4= V5;
	V6= Cnil;
	V8= Cnil;
	(*LK6)(1,(V1))                            /*  SAVE-FUNOB      */;
	V8= VALUES(0);
	(*LK7)(1,(V3))                            /*  INLINE-ARGS     */;
	(*LK8)(2,VALUES(0),Cnil)                  /*  COERCE-LOCS     */;
	L14(2,VALUES(0),(V1))                     /*  PUSH-CHANGED-VARS*/;
	V3= VALUES(0);
	V6= CAR((V3));
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	princ_char(123,symbol_value(VV[5]));
	{register object V9;
	object V10;                               /*  LOC             */
	V9= (V7);
	V10= Cnil;
L258:
	if(!((V9)==Cnil)){
	goto L259;}
	goto L254;
L259:
	V10= CAR((V9));
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	princ_str("object ",symbol_value(VV[5]));
	(*LK9)(1,(V10))                           /*  WT1             */;
	princ_str("= ",symbol_value(VV[5]));
	(*LK9)(1,CAR((V3)))                       /*  WT1             */;
	princ_char(59,symbol_value(VV[5]));
	V3= CDR((V3));
	V9= CDR((V9));
	goto L258;
	}
L254:
	if(((VV[6]->s.s_dbind))==Cnil){
	goto L280;}
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(endp(",symbol_value(VV[5]));
	(*LK9)(1,CAR((V7)))                       /*  WT1             */;
	princ_char(41,symbol_value(VV[5]));
	{register object V9;
	object V10;                               /*  LOC             */
	V9= CDR((V7));
	V10= Cnil;
L292:
	if(!((V9)==Cnil)){
	goto L293;}
	goto L288;
L293:
	V10= CAR((V9));
	princ_str("||endp(",symbol_value(VV[5]));
	(*LK9)(1,(V10))                           /*  WT1             */;
	princ_char(41,symbol_value(VV[5]));
	V9= CDR((V9));
	goto L292;
	}
L288:
	princ_str("){",symbol_value(VV[5]));
	goto L278;
L280:
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(",symbol_value(VV[5]));
	(*LK9)(1,CAR((V7)))                       /*  WT1             */;
	princ_str("==Cnil",symbol_value(VV[5]));
	{register object V9;
	object V10;                               /*  LOC             */
	V9= CDR((V7));
	V10= Cnil;
L316:
	if(!((V9)==Cnil)){
	goto L317;}
	goto L312;
L317:
	V10= CAR((V9));
	princ_str("||",symbol_value(VV[5]));
	(*LK9)(1,(V10))                           /*  WT1             */;
	princ_str("==Cnil",symbol_value(VV[5]));
	V9= CDR((V9));
	goto L316;
	}
L312:
	princ_str("){",symbol_value(VV[5]));
L278:
	(*LK10)(2,Cnil,VV[7])                     /*  UNWIND-EXIT     */;
	princ_char(125,symbol_value(VV[5]));
	if((CDR((V4)))==Cnil){
	goto L333;}
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	princ_char(76,symbol_value(VV[5]));
	(*LK9)(1,CAR((V4)))                       /*  WT1             */;
	princ_char(58,symbol_value(VV[5]));
L333:
	bds_bind(VV[8],VV[14]);                   /*  *DESTINATION*   */
	(VV[2]->s.s_dbind)= number_plus((VV[2]->s.s_dbind),MAKE_FIXNUM(1));
	bds_bind(VV[10],CONS((VV[2]->s.s_dbind),Cnil));/*  *EXIT*     */
	bds_bind(VV[11],CONS((VV[10]->s.s_dbind),(VV[11]->s.s_dbind)));/*  *UNWIND-EXIT**/
	if(((V2))==Cnil){
	goto L347;}
	{object V9;
	object V10= (V7);
	if(V10==Cnil){
	VALUES(0) = Cnil;
	goto L345;}
	T0=V9=CONS(Cnil,Cnil);
L349:
	{object V11;                              /*  LOC             */
	{object V12= (VV[13]->s.s_dbind);
	CAR(V9)= list(3,VV[12],V12,list(2,VV[9],CADR(CAR(V10))));}
	}
	if((V10=CDR(V10))==Cnil){
	VALUES(0) = T0;
	goto L345;}
	V9=CDR(V9)=CONS(Cnil,Cnil);
	goto L349;}
L347:
	{object V13;
	object V14= (V7);
	if(V14==Cnil){
	VALUES(0) = Cnil;
	goto L345;}
	T1=V13=CONS(Cnil,Cnil);
L351:
	{object V15;                              /*  LOC             */
	CAR(V13)= list(3,VV[12],(VV[13]->s.s_dbind),CAR(V14));
	}
	if((V14=CDR(V14))==Cnil){
	VALUES(0) = T1;
	goto L345;}
	V13=CDR(V13)=CONS(Cnil,Cnil);
	goto L351;}
L345:
	(*LK11)(3,(V1),VALUES(0),(V8))            /*  C2FUNCALL       */;
	if((CDR((VV[10]->s.s_dbind)))==Cnil){
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	goto L340;}
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	princ_char(76,symbol_value(VV[5]));
	(*LK9)(1,CAR((VV[10]->s.s_dbind)))        /*  WT1             */;
	princ_char(58,symbol_value(VV[5]));
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
L340:
	if(((VV[6]->s.s_dbind))==Cnil){
	goto L361;}
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(endp(",symbol_value(VV[5]));
	(*LK9)(1,CAR((V7)))                       /*  WT1             */;
	princ_str("=CDR(",symbol_value(VV[5]));
	(*LK9)(1,CAR((V7)))                       /*  WT1             */;
	princ_str("))",symbol_value(VV[5]));
	{register object V9;
	object V10;                               /*  LOC             */
	V9= CDR((V7));
	V10= Cnil;
L375:
	if(!((V9)==Cnil)){
	goto L376;}
	goto L371;
L376:
	V10= CAR((V9));
	princ_str("||endp(",symbol_value(VV[5]));
	(*LK9)(1,(V10))                           /*  WT1             */;
	princ_str("=CDR(",symbol_value(VV[5]));
	(*LK9)(1,(V10))                           /*  WT1             */;
	princ_str("))",symbol_value(VV[5]));
	V9= CDR((V9));
	goto L375;
	}
L371:
	princ_str("){",symbol_value(VV[5]));
	goto L359;
L361:
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if((",symbol_value(VV[5]));
	(*LK9)(1,CAR((V7)))                       /*  WT1             */;
	princ_str("=CDR(",symbol_value(VV[5]));
	(*LK9)(1,CAR((V7)))                       /*  WT1             */;
	princ_str("))==Cnil",symbol_value(VV[5]));
	{register object V9;
	object V10;                               /*  LOC             */
	V9= CDR((V7));
	V10= Cnil;
L403:
	if(!((V9)==Cnil)){
	goto L404;}
	goto L399;
L404:
	V10= CAR((V9));
	princ_str("||(",symbol_value(VV[5]));
	(*LK9)(1,(V10))                           /*  WT1             */;
	princ_str("=CDR(",symbol_value(VV[5]));
	(*LK9)(1,(V10))                           /*  WT1             */;
	princ_str("))==Cnil",symbol_value(VV[5]));
	V9= CDR((V9));
	goto L403;
	}
L399:
	princ_str("){",symbol_value(VV[5]));
L359:
	(*LK10)(2,(V6),VV[7])                     /*  UNWIND-EXIT     */;
	princ_char(125,symbol_value(VV[5]));
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	CDR((V4)) = Ct;
	princ_str("goto L",symbol_value(VV[5]));
	(*LK9)(1,CAR((V4)))                       /*  WT1             */;
	princ_char(59,symbol_value(VV[5]));
	princ_char(125,symbol_value(VV[5]));
	{int V9;
	V9=(*LK12)(0)                             /*  CLOSE-INLINE-BLOCKS*/;
	bds_unwind1;
	RETURN(V9);}
	}
}
/*	function definition for C2MAPCAN                              */
static L10(int narg, object V1, object V2, object V3)
{ VT6 VLEX6 CLSR6
	bds_check;
TTL:
	bds_bind(VV[1],MAKE_FIXNUM(0));           /*  *INLINE-BLOCKS* */
	{register object V4;                      /*  LABEL           */
	object V5;
	register object V6;                       /*  VALUE-LOC       */
	object V7;
	register object V8;                       /*  HANDY           */
	object V9;
	register object V10;                      /*  HANDIES         */
	object V11;                               /*  SAVE            */
	(VV[2]->s.s_dbind)= number_plus((VV[2]->s.s_dbind),MAKE_FIXNUM(1));
	V5= CONS((VV[2]->s.s_dbind),Ct);
	(*LK4)(0)                                 /*  NEXT-TEMP       */;
	V7= list(2,VV[3],VALUES(0));
	(*LK5)(0)                                 /*  NEXT-LCL        */;
	V9= list(2,VV[4],VALUES(0));
	{object V12;
	object V13= (V3);
	if(V13==Cnil){
	V10= Cnil;
	goto L438;}
	T0=V12=CONS(Cnil,Cnil);
L439:
	(*LK5)(0)                                 /*  NEXT-LCL        */;
	CAR(V12)= list(2,VV[4],VALUES(0));
	if((V13=CDR(V13))==Cnil){
	V10= T0;
	goto L438;}
	V12=CDR(V12)=CONS(Cnil,Cnil);
	goto L439;}
L438:
	V4= V5;
	V6= V7;
	V8= V9;
	V11= Cnil;
	(*LK6)(1,(V1))                            /*  SAVE-FUNOB      */;
	V11= VALUES(0);
	(*LK7)(1,(V3))                            /*  INLINE-ARGS     */;
	(*LK8)(2,VALUES(0),Cnil)                  /*  COERCE-LOCS     */;
	L14(2,VALUES(0),(V1))                     /*  PUSH-CHANGED-VARS*/;
	V3= VALUES(0);
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{object ",symbol_value(VV[5]));
	(*LK9)(1,(V8))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[5]));
	{register object V12;
	object V13;                               /*  LOC             */
	V12= (V10);
	V13= Cnil;
L458:
	if(!((V12)==Cnil)){
	goto L459;}
	goto L454;
L459:
	V13= CAR((V12));
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	princ_str("object ",symbol_value(VV[5]));
	(*LK9)(1,(V13))                           /*  WT1             */;
	princ_str("= ",symbol_value(VV[5]));
	(*LK9)(1,CAR((V3)))                       /*  WT1             */;
	princ_char(59,symbol_value(VV[5]));
	V3= CDR((V3));
	V12= CDR((V12));
	goto L458;
	}
L454:
	if(((VV[6]->s.s_dbind))==Cnil){
	goto L480;}
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(endp(",symbol_value(VV[5]));
	(*LK9)(1,CAR((V10)))                      /*  WT1             */;
	princ_char(41,symbol_value(VV[5]));
	{register object V12;
	object V13;                               /*  LOC             */
	V12= CDR((V10));
	V13= Cnil;
L492:
	if(!((V12)==Cnil)){
	goto L493;}
	goto L488;
L493:
	V13= CAR((V12));
	princ_str("||endp(",symbol_value(VV[5]));
	(*LK9)(1,(V13))                           /*  WT1             */;
	princ_char(41,symbol_value(VV[5]));
	V12= CDR((V12));
	goto L492;
	}
L488:
	princ_str("){",symbol_value(VV[5]));
	goto L478;
L480:
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(",symbol_value(VV[5]));
	(*LK9)(1,CAR((V10)))                      /*  WT1             */;
	princ_str("==Cnil",symbol_value(VV[5]));
	{register object V12;
	object V13;                               /*  LOC             */
	V12= CDR((V10));
	V13= Cnil;
L516:
	if(!((V12)==Cnil)){
	goto L517;}
	goto L512;
L517:
	V13= CAR((V12));
	princ_str("||",symbol_value(VV[5]));
	(*LK9)(1,(V13))                           /*  WT1             */;
	princ_str("==Cnil",symbol_value(VV[5]));
	V12= CDR((V12));
	goto L516;
	}
L512:
	princ_str("){",symbol_value(VV[5]));
L478:
	(*LK10)(2,Cnil,VV[7])                     /*  UNWIND-EXIT     */;
	princ_char(125,symbol_value(VV[5]));
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	(*LK9)(1,(V6))                            /*  WT1             */;
	princ_char(61,symbol_value(VV[5]));
	(*LK9)(1,(V8))                            /*  WT1             */;
	princ_str("=CONS(Cnil,Cnil);",symbol_value(VV[5]));
	if((CDR((V4)))==Cnil){
	goto L540;}
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	princ_char(76,symbol_value(VV[5]));
	(*LK9)(1,CAR((V4)))                       /*  WT1             */;
	princ_char(58,symbol_value(VV[5]));
L540:
	bds_bind(VV[8],list(2,VV[15],CADR((V8))));/*  *DESTINATION*   */
	(VV[2]->s.s_dbind)= number_plus((VV[2]->s.s_dbind),MAKE_FIXNUM(1));
	bds_bind(VV[10],CONS((VV[2]->s.s_dbind),Cnil));/*  *EXIT*     */
	bds_bind(VV[11],CONS((VV[10]->s.s_dbind),(VV[11]->s.s_dbind)));/*  *UNWIND-EXIT**/
	if(((V2))==Cnil){
	goto L555;}
	{object V12;
	object V13= (V10);
	if(V13==Cnil){
	VALUES(0) = Cnil;
	goto L553;}
	T0=V12=CONS(Cnil,Cnil);
L557:
	{object V14;                              /*  LOC             */
	{object V15= (VV[13]->s.s_dbind);
	CAR(V12)= list(3,VV[12],V15,list(2,VV[9],CADR(CAR(V13))));}
	}
	if((V13=CDR(V13))==Cnil){
	VALUES(0) = T0;
	goto L553;}
	V12=CDR(V12)=CONS(Cnil,Cnil);
	goto L557;}
L555:
	{object V16;
	object V17= (V10);
	if(V17==Cnil){
	VALUES(0) = Cnil;
	goto L553;}
	T1=V16=CONS(Cnil,Cnil);
L559:
	{object V18;                              /*  LOC             */
	CAR(V16)= list(3,VV[12],(VV[13]->s.s_dbind),CAR(V17));
	}
	if((V17=CDR(V17))==Cnil){
	VALUES(0) = T1;
	goto L553;}
	V16=CDR(V16)=CONS(Cnil,Cnil);
	goto L559;}
L553:
	(*LK11)(3,(V1),VALUES(0),(V11))           /*  C2FUNCALL       */;
	if((CDR((VV[10]->s.s_dbind)))==Cnil){
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	goto L547;}
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	princ_char(76,symbol_value(VV[5]));
	(*LK9)(1,CAR((VV[10]->s.s_dbind)))        /*  WT1             */;
	princ_char(58,symbol_value(VV[5]));
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
L547:
	if(((VV[6]->s.s_dbind))==Cnil){
	goto L569;}
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	princ_str("while(!endp(CDR(",symbol_value(VV[5]));
	(*LK9)(1,(V8))                            /*  WT1             */;
	princ_str(")))",symbol_value(VV[5]));
	(*LK9)(1,(V8))                            /*  WT1             */;
	princ_str("=CDR(",symbol_value(VV[5]));
	(*LK9)(1,(V8))                            /*  WT1             */;
	princ_str(");",symbol_value(VV[5]));
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(endp(",symbol_value(VV[5]));
	(*LK9)(1,CAR((V10)))                      /*  WT1             */;
	princ_str("=CDR(",symbol_value(VV[5]));
	(*LK9)(1,CAR((V10)))                      /*  WT1             */;
	princ_str("))",symbol_value(VV[5]));
	{register object V12;
	object V13;                               /*  LOC             */
	V12= CDR((V10));
	V13= Cnil;
L593:
	if(!((V12)==Cnil)){
	goto L594;}
	goto L589;
L594:
	V13= CAR((V12));
	princ_str("||endp(",symbol_value(VV[5]));
	(*LK9)(1,(V13))                           /*  WT1             */;
	princ_str("=CDR(",symbol_value(VV[5]));
	(*LK9)(1,(V13))                           /*  WT1             */;
	princ_str("))",symbol_value(VV[5]));
	V12= CDR((V12));
	goto L593;
	}
L589:
	princ_str("){",symbol_value(VV[5]));
	goto L567;
L569:
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	princ_str("while(CDR(",symbol_value(VV[5]));
	(*LK9)(1,(V8))                            /*  WT1             */;
	princ_str(")!=Cnil)",symbol_value(VV[5]));
	(*LK9)(1,(V8))                            /*  WT1             */;
	princ_str("=CDR(",symbol_value(VV[5]));
	(*LK9)(1,(V8))                            /*  WT1             */;
	princ_str(");",symbol_value(VV[5]));
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if((",symbol_value(VV[5]));
	(*LK9)(1,CAR((V10)))                      /*  WT1             */;
	princ_str("=CDR(",symbol_value(VV[5]));
	(*LK9)(1,CAR((V10)))                      /*  WT1             */;
	princ_str("))==Cnil",symbol_value(VV[5]));
	{register object V12;
	object V13;                               /*  LOC             */
	V12= CDR((V10));
	V13= Cnil;
L631:
	if(!((V12)==Cnil)){
	goto L632;}
	goto L627;
L632:
	V13= CAR((V12));
	princ_str("||(",symbol_value(VV[5]));
	(*LK9)(1,(V13))                           /*  WT1             */;
	princ_str("=CDR(",symbol_value(VV[5]));
	(*LK9)(1,(V13))                           /*  WT1             */;
	princ_str("))==Cnil",symbol_value(VV[5]));
	V12= CDR((V12));
	goto L631;
	}
L627:
	princ_str("){",symbol_value(VV[5]));
L567:
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	(*LK9)(1,(V6))                            /*  WT1             */;
	princ_str("=CDR(",symbol_value(VV[5]));
	(*LK9)(1,(V6))                            /*  WT1             */;
	princ_str(");",symbol_value(VV[5]));
	(*LK10)(2,(V6),VV[7])                     /*  UNWIND-EXIT     */;
	princ_char(125,symbol_value(VV[5]));
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	CDR((V4)) = Ct;
	princ_str("goto L",symbol_value(VV[5]));
	(*LK9)(1,CAR((V4)))                       /*  WT1             */;
	princ_char(59,symbol_value(VV[5]));
	princ_char(125,symbol_value(VV[5]));
	{int V12;
	V12=(*LK12)(0)                            /*  CLOSE-INLINE-BLOCKS*/;
	bds_unwind1;
	RETURN(V12);}
	}
}
/*	function definition for PUSH-CHANGED-VARS                     */
static L14(int narg, object V1, object V2)
{ VT7 VLEX7 CLSR7
TTL:
	{register object V3;                      /*  LOCS1           */
	object V4;                                /*  FORMS           */
	V3= Cnil;
	V4= CONS((V2),Cnil);
	{register object V5;
	register object V6;                       /*  LOC             */
	V5= (V1);
	V6= Cnil;
L672:
	if(!((V5)==Cnil)){
	goto L673;}
	VALUES(0) = nreverse((V3));
	RETURN(1);
L673:
	V6= CAR((V5));
	if(!(type_of((V6))==t_cons)){
	goto L680;}
	if(!((CAR((V6)))==(VV[16]))){
	goto L680;}
	(*LK13)(2,CADR((V6)),(V4))                /*  VAR-CHANGED-IN-FORMS*/;
	if(VALUES(0)==Cnil){
	goto L680;}
	{object V8;                               /*  TEMP            */
	(*LK4)(0)                                 /*  NEXT-TEMP       */;
	V8= list(2,VV[3],VALUES(0));
	(*LK9)(1,code_char('\12'))                /*  WT1             */;
	(*LK9)(1,code_char('\11'))                /*  WT1             */;
	(*LK9)(1,(V8))                            /*  WT1             */;
	princ_str("= ",symbol_value(VV[5]));
	(*LK9)(1,(V6))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[5]));
	V3= CONS((V8),(V3));
	goto L678;
	}
L680:
	V3= CONS((V6),(V3));
L678:
	V5= CDR((V5));
	goto L672;
	}
	}
}
/*	function definition for C1MAPCAR                              */
static L15(int narg, object V1)
{ VT8 VLEX8 CLSR8
TTL:
	RETURN(L1(3,VV[17],Ct,(V1))               /*  C1MAP-FUNCTIONS */);
}
/*	function definition for C1MAPLIST                             */
static L16(int narg, object V1)
{ VT9 VLEX9 CLSR9
TTL:
	RETURN(L1(3,VV[17],Cnil,(V1))             /*  C1MAP-FUNCTIONS */);
}
/*	function definition for C1MAPC                                */
static L17(int narg, object V1)
{ VT10 VLEX10 CLSR10
TTL:
	RETURN(L1(3,VV[24],Ct,(V1))               /*  C1MAP-FUNCTIONS */);
}
/*	function definition for C1MAPL                                */
static L18(int narg, object V1)
{ VT11 VLEX11 CLSR11
TTL:
	RETURN(L1(3,VV[24],Cnil,(V1))             /*  C1MAP-FUNCTIONS */);
}
/*	function definition for C1MAPCAN                              */
static L19(int narg, object V1)
{ VT12 VLEX12 CLSR12
TTL:
	RETURN(L1(3,VV[29],Ct,(V1))               /*  C1MAP-FUNCTIONS */);
}
/*	function definition for C1MAPCON                              */
static L20(int narg, object V1)
{ VT13 VLEX13 CLSR13
TTL:
	RETURN(L1(3,VV[29],Cnil,(V1))             /*  C1MAP-FUNCTIONS */);
}
static LKF13(int narg, ...) {TRAMPOLINK(VV[49],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[48],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[47],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[46],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[45],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[44],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[43],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[42],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[41],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[40],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[39],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[38],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[37],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[36],&LK0);}
