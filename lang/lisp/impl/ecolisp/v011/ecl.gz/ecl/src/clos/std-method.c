
#include "std-method.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	funcall(2,VV[29]->s.s_gfdef,VV[0])        /*  FIND-CLASS      */;
	funcall(9,VV[30]->s.s_gfdef,VALUES(0),VV[1],Cnil,Cnil,Cnil,Cnil,Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[29]->s.s_gfdef,VV[1])        /*  FIND-CLASS      */;
	funcall(2,VV[29]->s.s_gfdef,VV[0])        /*  FIND-CLASS      */;
	funcall(9,VV[30]->s.s_gfdef,VALUES(0),VV[2],VV[3],VV[4],Cnil,VV[5],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	VV[31] = make_cfun(LC1,Cnil,&Cblock);
	VALUES(0) = VV[31];
	funcall(8,VV[32]->s.s_gfdef,VV[6],Cnil,VV[7],VV[8],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[33] = make_cfun(LC2,Cnil,&Cblock);
	VALUES(0) = VV[33];
	funcall(8,VV[32]->s.s_gfdef,VV[10],Cnil,VV[11],VV[12],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[34] = make_cfun(LC3,Cnil,&Cblock);
	VALUES(0) = VV[34];
	funcall(8,VV[32]->s.s_gfdef,VV[13],Cnil,VV[14],VV[15],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[35] = make_cfun(LC4,Cnil,&Cblock);
	VALUES(0) = VV[35];
	funcall(8,VV[32]->s.s_gfdef,VV[17],Cnil,VV[18],VV[8],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[36] = make_cfun(LC5,Cnil,&Cblock);
	VALUES(0) = VV[36];
	funcall(8,VV[32]->s.s_gfdef,VV[19],Cnil,VV[20],VV[12],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	funcall(2,VV[29]->s.s_gfdef,VV[2])        /*  FIND-CLASS      */;
	VV[37] = make_cfun(LC6,Cnil,&Cblock);
	VALUES(0) = VV[37];
	funcall(8,VV[32]->s.s_gfdef,VV[21],Cnil,VV[22],VV[23],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	local function CLOSURE                                        */
static LC6(int narg, object V1)
{ VT3 VLEX3 CLSR3
	{object V2;
	{object V3;                               /*  CLASS           */
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	V3= VALUES(0);
	V2= ((V3))->in.in_slots[5];
	}
	{int V3;
	V3= fix(gethash(VV[24],(V2))->hte_value);
	{object V4;                               /*  LAMBDA-LIST     */
	register object V5;                       /*  KEY-LIST        */
	object V6;                                /*  KEYP            */
	object V7;                                /*  ALLOWED         */
	V4= ((V1))->in.in_slots[V3];
	V5= Cnil;
	V6= Cnil;
	V7= Cnil;
	{register object V8;
	register object V9;                       /*  ARG             */
	V8= (V4);
	V9= Cnil;
L27:
	if(!((V8)==Cnil)){
	goto L28;}
	V5= nreverse((V5));
	goto L23;
L28:
	V9= CAR((V8));
	if(!(((V9))==(VV[25]))){
	goto L36;}
	V6= Ct;
	goto L34;
L36:
	if(((V6))==Cnil){
	goto L43;}
	{register object x= (V9),V11= VV[26];
	while(V11!=Cnil)
	if(eql(x, CAR(V11))){
	VALUES(0) = V11;
	goto L45;
	}else V11=CDR(V11);
	VALUES(0) = Cnil;}
L45:
	if(!((VALUES(0))==Cnil)){
	goto L40;}
	goto L41;
L43:
	goto L40;
L41:
	if(!(type_of((V9))==t_cons||(V9)==Cnil)){
	goto L49;}
	{object V11;                              /*  KEY-PAR         */
	V11= CAR((V9));
	if(!(type_of((V11))==t_cons||(V11)==Cnil)){
	goto L53;}
	VALUES(0) = CAR((V11));
	goto L47;
L53:
	(*LK0)(1,(V11))                           /*  MAKE-KEYWORD    */;
	goto L47;
	}
L49:
	(*LK0)(1,(V9))                            /*  MAKE-KEYWORD    */;
L47:
	V5= CONS(VALUES(0),(V5));
	goto L34;
L40:
	if(!(((V9))==(VV[27]))){
	goto L56;}
	V7= Ct;
	goto L23;
L56:
	if(!(((V9))==(VV[28]))){
	goto L34;}
	goto L23;
L34:
	V8= CDR((V8));
	goto L27;
	}
L23:
	VALUES(1) = (V7);
	VALUES(0) = (V5);
	RETURN(2);
	}
	}
	}
}
/*	local function CLOSURE                                        */
static LC5(int narg, object V1, object V2)
{ VT4 VLEX4 CLSR4
	VALUES(0) = ((V2))->in.in_slots[2]=((V1));
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC4(int narg, object V1)
{ VT5 VLEX5 CLSR5
	{object V2;                               /*  VAL             */
	V2= ((V1))->in.in_slots[2];
	if(!(((V2))!=OBJNULL)){
	goto L67;}
	VALUES(0) = (V2);
	RETURN(1);
L67:
	RETURN((*LK1)(3,((V1))->in.in_class,(V1),VV[17])/*  SLOT-UNBOUND*/);
	}
}
/*	local function CLOSURE                                        */
static LC3(int narg, object V1)
{ VT6 VLEX6 CLSR6
	{object V2;                               /*  VAL             */
	V2= ((V1))->in.in_slots[3];
	if(!(((V2))!=OBJNULL)){
	goto L71;}
	VALUES(0) = (V2);
	RETURN(1);
L71:
	RETURN((*LK1)(3,((V1))->in.in_class,(V1),VV[16])/*  SLOT-UNBOUND*/);
	}
}
/*	local function CLOSURE                                        */
static LC2(int narg, object V1, object V2)
{ VT7 VLEX7 CLSR7
	VALUES(0) = ((V2))->in.in_slots[7]=((V1));
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC1(int narg, object V1)
{ VT8 VLEX8 CLSR8
	{object V2;                               /*  VAL             */
	V2= ((V1))->in.in_slots[7];
	if(!(((V2))!=OBJNULL)){
	goto L75;}
	VALUES(0) = (V2);
	RETURN(1);
L75:
	RETURN((*LK1)(3,((V1))->in.in_class,(V1),VV[9])/*  SLOT-UNBOUND*/);
	}
}
static LKF1(int narg, ...) {TRAMPOLINK(VV[39],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[38],&LK0);}
