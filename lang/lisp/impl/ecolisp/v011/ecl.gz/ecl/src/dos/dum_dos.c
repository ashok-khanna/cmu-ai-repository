#define DUM(a) int a(int n) {}
DUM(profil)
/* DUM(alarm) */
DUM(getpid)
DUM(getuid)
DUM(popen)
DUM(pclose)
DUM(getpwuid)
DUM(getpwnam)
