
#include "walk.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	funcall(2,VV[118]->s.s_gfdef,VV[0])       /*  PROCLAIM        */;
	MF0(VV[119],L1);
	(void)putprop(VV[119],VV[Vdeb119],VV[120]);
	(void)putprop(VV[19],VV[4],siSpretty_print_format);
	
	MM0(VV[19],L2);
	MF0(VV[3],L3);
	(void)putprop(VV[3],VV[Vdeb3],VV[120]);
	MF0(VV[121],L4);
	(void)putprop(VV[121],VV[Vdeb121],VV[120]);
	MF0(VV[122],L5);
	(void)putprop(VV[122],VV[Vdeb122],VV[120]);
	(void)putprop(VV[123],VV[4],siSpretty_print_format);
	
	MM0(VV[123],L6);
	MF0(VV[124],L7);
	(void)putprop(VV[124],VV[Vdeb124],VV[120]);
	(void)putprop(VV[125],VV[4],siSpretty_print_format);
	
	MM0(VV[125],L8);
	VV[25]->s.s_stype=(short)stp_special;
	if(VV[25]->s.s_dbind == OBJNULL){
	Lgensym(0)                                /*  GENSYM          */;
	(VV[25]->s.s_dbind)= VALUES(0);}
	MF0(VV[126],L9);
	(void)putprop(VV[126],VV[Vdeb126],VV[120]);
	MF0key(VV[24],L10,4,L10keys);
	(void)putprop(VV[24],VV[Vdeb24],VV[120]);
	MF0(VV[127],L11);
	(void)putprop(VV[127],VV[Vdeb127],VV[120]);
	MF0(VV[128],L12);
	(void)putprop(VV[128],VV[Vdeb128],VV[120]);
	MF0(VV[129],L13);
	(void)putprop(VV[129],VV[Vdeb129],VV[120]);
	MF0(VV[130],L14);
	(void)putprop(VV[130],VV[Vdeb130],VV[120]);
	MF0(VV[131],L15);
	(void)putprop(VV[131],VV[Vdeb131],VV[120]);
	MF0(VV[132],L16);
	(void)putprop(VV[132],VV[Vdeb132],VV[120]);
	MF0(VV[133],L17);
	(void)putprop(VV[133],VV[Vdeb133],VV[120]);
	VV[27]->s.s_stype=(short)stp_special;
	if(VV[27]->s.s_dbind == OBJNULL){
	(VV[27]->s.s_dbind)= VV[26];}
	MF0(VV[134],L18);
	(void)putprop(VV[134],VV[Vdeb134],VV[120]);
	MF0(VV[135],L19);
	(void)putprop(VV[135],VV[Vdeb135],VV[120]);
	MF0(VV[136],L20);
	(void)putprop(VV[136],VV[Vdeb136],VV[120]);
	MM0(VV[37],L21);
	MM0(VV[137],L22);
	MF0(VV[138],L23);
	(void)putprop(VV[138],VV[Vdeb138],VV[120]);
	MF0(VV[139],L24);
	(void)putprop(VV[139],VV[Vdeb139],VV[120]);
	putprop(VV[43],VV[44],VV[39]);
	putprop(VV[45],VV[46],VV[39]);
	putprop(VV[47],VV[48],VV[39]);
	putprop(VV[49],VV[50],VV[39]);
	putprop(VV[34],VV[51],VV[39]);
	putprop(VV[52],VV[53],VV[39]);
	putprop(VV[5],VV[54],VV[39]);
	putprop(VV[55],VV[56],VV[39]);
	putprop(VV[57],VV[58],VV[39]);
	putprop(VV[59],VV[60],VV[39]);
	putprop(VV[40],VV[61],VV[39]);
	putprop(VV[2],VV[62],VV[39]);
	putprop(VV[63],VV[64],VV[39]);
	putprop(VV[65],VV[66],VV[39]);
	putprop(VV[67],VV[68],VV[39]);
	putprop(VV[69],VV[70],VV[39]);
	putprop(VV[71],VV[72],VV[39]);
	putprop(VV[73],VV[74],VV[39]);
	putprop(VV[75],VV[76],VV[39]);
	putprop(VV[77],VV[78],VV[39]);
	putprop(VV[38],VV[79],VV[39]);
	putprop(VV[80],VV[81],VV[39]);
	putprop(VV[82],VV[83],VV[39]);
	putprop(VV[84],VV[85],VV[39]);
	putprop(VV[86],VV[87],VV[39]);
	putprop(VV[88],VV[89],VV[39]);
	putprop(VV[90],VV[91],VV[39]);
	putprop(VV[92],VV[93],VV[39]);
	putprop(VV[94],VV[95],VV[39]);
	putprop(VV[96],VV[97],VV[39]);
	putprop(VV[98],VV[99],VV[39]);
	putprop(VV[100],VV[101],VV[39]);
	putprop(VV[102],VV[103],VV[39]);
	VV[140] = make_cfun(LC26,Cnil,&Cblock);
	MF0(VV[141],L25);
	(void)putprop(VV[141],VV[Vdeb141],VV[120]);
	MF0(VV[142],L27);
	(void)putprop(VV[142],VV[Vdeb142],VV[120]);
	MF0(VV[143],L30);
	(void)putprop(VV[143],VV[Vdeb143],VV[120]);
	MF0(VV[144],L31);
	(void)putprop(VV[144],VV[Vdeb144],VV[120]);
	MF0(VV[145],L32);
	(void)putprop(VV[145],VV[Vdeb145],VV[120]);
	MF0(VV[146],L33);
	(void)putprop(VV[146],VV[Vdeb146],VV[120]);
	MF0(VV[147],L34);
	(void)putprop(VV[147],VV[Vdeb147],VV[120]);
	MF0(VV[148],L35);
	(void)putprop(VV[148],VV[Vdeb148],VV[120]);
	MF0(VV[149],L36);
	(void)putprop(VV[149],VV[Vdeb149],VV[120]);
	MF0(VV[150],L37);
	(void)putprop(VV[150],VV[Vdeb150],VV[120]);
	MF0(VV[151],L38);
	(void)putprop(VV[151],VV[Vdeb151],VV[120]);
	MF0(VV[152],L39);
	(void)putprop(VV[152],VV[Vdeb152],VV[120]);
	MF0(VV[50],L40);
	(void)putprop(VV[50],VV[Vdeb50],VV[120]);
	VV[112]=string_to_object(VV[112]);
	MF0(VV[153],L41);
	(void)putprop(VV[153],VV[Vdeb153],VV[120]);
	MF0(VV[62],L42);
	(void)putprop(VV[62],VV[Vdeb62],VV[120]);
	MF0(VV[64],L43);
	(void)putprop(VV[64],VV[Vdeb64],VV[120]);
	MF0(VV[97],L44);
	(void)putprop(VV[97],VV[Vdeb97],VV[120]);
	MF0(VV[99],L45);
	(void)putprop(VV[99],VV[Vdeb99],VV[120]);
	MF0(VV[93],L46);
	(void)putprop(VV[93],VV[Vdeb93],VV[120]);
	MF0(VV[95],L47);
	(void)putprop(VV[95],VV[Vdeb95],VV[120]);
	MF0(VV[154],L48);
	(void)putprop(VV[154],VV[Vdeb154],VV[120]);
	MF0(VV[155],L49);
	(void)putprop(VV[155],VV[Vdeb155],VV[120]);
	MF0(VV[156],L51);
	(void)putprop(VV[156],VV[Vdeb156],VV[120]);
	MF0(VV[74],L52);
	(void)putprop(VV[74],VV[Vdeb74],VV[120]);
	MF0(VV[157],L54);
	(void)putprop(VV[157],VV[Vdeb157],VV[120]);
	MF0(VV[158],L55);
	(void)putprop(VV[158],VV[Vdeb158],VV[120]);
	MF0(VV[61],L56);
	(void)putprop(VV[61],VV[Vdeb61],VV[120]);
	MF0(VV[103],L57);
	(void)putprop(VV[103],VV[Vdeb103],VV[120]);
	MF0(VV[85],L58);
	(void)putprop(VV[85],VV[Vdeb85],VV[120]);
	MF0(VV[159],L59);
	(void)putprop(VV[159],VV[Vdeb159],VV[120]);
	MF0(VV[48],L60);
	(void)putprop(VV[48],VV[Vdeb48],VV[120]);
	MF0(VV[66],L61);
	(void)putprop(VV[66],VV[Vdeb66],VV[120]);
	MF0(VV[53],L63);
	(void)putprop(VV[53],VV[Vdeb53],VV[120]);
	MF0(VV[60],L65);
	(void)putprop(VV[60],VV[Vdeb60],VV[120]);
	MF0(VV[58],L67);
	(void)putprop(VV[58],VV[Vdeb58],VV[120]);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	local function CLOSURE                                        */
static LC26(int narg, object V1, object V2, object V3)
{ VT3 VLEX3 CLSR3
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for UNBOUND-LEXICAL-FUNCTION              */
static L1(int narg, ...)
{ VT4 VLEX4 CLSR4
	RETURN(Lerror(1,VV[1])                    /*  ERROR           */);
}
/*	macro definition for WITH-AUGMENTED-ENVIRONMENT               */
static L2(int narg, object V1, object V2)
{ VT5 VLEX5 CLSR5
	{object V3=CDR(V1),V4,V5,V6,V7,V8;
	{object V9= CAR(V3);
	V4= CAR(V9);
	V9=CDR(V9);
	V5= CAR(V9);
	V9=CDR(V9);
	{object V10;
	V10=getf(V9,VV[20],OBJNULL);
	if(V10==OBJNULL){
	V6= Cnil;
	} else {
	V6= V10;}
	V10=getf(V9,VV[21],OBJNULL);
	if(V10==OBJNULL){
	V7= Cnil;
	} else {
	V7= V10;}}}
	V3=CDR(V3);
	V8= V3;
	VALUES(0) = listA(3,VV[2],CONS(list(2,(V4),list(4,VV[3],(V5),(V6),(V7))),Cnil),(V8));
	RETURN(1);}
}
/*	function definition for WITH-AUGMENTED-ENVIRONMENT-INTERNAL   */
static L3(int narg, object V1, object V2, object V3)
{ VT6 VLEX6 CLSR6
TTL:
	{object V4;                               /*  VARS            */
	register object V5;                       /*  FUNS            */
	object V6;                                /*  BLOCKS          */
	V4= Cnil;
	V5= Cnil;
	V6= Cnil;
	if(((V1))==Cnil){
	goto L39;}
	V4= CAR((V1));
	V5= CADR((V1));
	V6= CADDR((V1));
L39:
	{register object V7;
	object V8;                                /*  F               */
	V7= (V2);
	V8= Cnil;
L51:
	if(!((V7)==Cnil)){
	goto L52;}
	goto L47;
L52:
	V8= CAR((V7));
	{object V10= CAR((V8));
	VALUES(0) = (VV[119]->s.s_gfdef);
	V5= CONS(list(3,V10,VV[5],VALUES(0)),(V5));}
	V7= CDR((V7));
	goto L51;
	}
L47:
	{register object V7;
	object V8;                                /*  M               */
	V7= (V3);
	V8= Cnil;
L67:
	if(!((V7)==Cnil)){
	goto L68;}
	goto L63;
L68:
	V8= CAR((V7));
	V5= CONS(list(3,CAR((V8)),VV[6],CADR((V8))),(V5));
	V7= CDR((V7));
	goto L67;
	}
L63:
	VALUES(0) = list(3,(V4),(V5),(V6));
	RETURN(1);
	}
}
/*	function definition for ENVIRONMENT-FUNCTION                  */
static L4(int narg, object V1, object V2)
{ VT7 VLEX7 CLSR7
TTL:
	if(((V1))==Cnil){
	goto L79;}
	{object V3;                               /*  ENTRY           */
	{register object x= (V2),V4= CADR((V1));
	while(V4!=Cnil)
	if(CAR(V4) != Cnil && 
	eql(x,CAAR(V4))){
	V3= CAR(V4);
	goto L81;
	}else V4=CDR(V4);
	V3= Cnil;}
L81:
	if((V3)==Cnil){
	VALUES(0) = Cnil;
	RETURN(1);}
	if((CADR((V3)))==(VV[5])){
	goto L82;}
	VALUES(0) = Cnil;
	RETURN(1);
L82:
	VALUES(0) = CADDR((V3));
	RETURN(1);
	}
L79:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for ENVIRONMENT-MACRO                     */
static L5(int narg, object V1, object V2)
{ VT8 VLEX8 CLSR8
TTL:
	if(((V1))==Cnil){
	goto L85;}
	{object V3;                               /*  ENTRY           */
	{register object x= (V2),V4= CADR((V1));
	while(V4!=Cnil)
	if(CAR(V4) != Cnil && 
	eql(x,CAAR(V4))){
	V3= CAR(V4);
	goto L87;
	}else V4=CDR(V4);
	V3= Cnil;}
L87:
	if((V3)==Cnil){
	VALUES(0) = Cnil;
	RETURN(1);}
	if((CADR((V3)))==(VV[6])){
	goto L88;}
	VALUES(0) = Cnil;
	RETURN(1);
L88:
	VALUES(0) = CADDR((V3));
	RETURN(1);
	}
L85:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	macro definition for WITH-NEW-DEFINITION-IN-ENVIRONMENT       */
static L6(int narg, object V1, object V2)
{ VT9 VLEX9 CLSR9
	{object V3=CDR(V1),V4,V5,V6,V7;
	{object V8= CAR(V3);
	V4= CAR(V8);
	V8=CDR(V8);
	V5= CAR(V8);
	V8=CDR(V8);
	V6= CAR(V8);}
	V3=CDR(V3);
	V7= V3;
	{object V9;                               /*  FUNCTIONS       */
	object V10;
	object V11;                               /*  MACROS          */
	Lmake_symbol(1,VV[7])                     /*  MAKE-SYMBOL     */;
	V10= VALUES(0);
	Lmake_symbol(1,VV[8])                     /*  MAKE-SYMBOL     */;
	V11= VALUES(0);
	V9= V10;
	{object V12= list(2,(V9),Cnil);
	{object V13= list(2,V12,list(2,(V11),Cnil));
	{object V14= list(2,VV[10],(V6));
	{object V15= list(2,VV[13],list(2,VV[14],(V6)));
	{object V16= list(2,VV[11],list(3,VV[12],V15,list(3,VV[15],VV[13],(V9))));
	{object V17= list(2,VV[17],list(2,VV[14],(V6)));
	{object V18= list(4,VV[9],V14,V16,list(2,VV[16],list(3,VV[12],V17,list(3,VV[15],VV[18],(V11)))));
	VALUES(0) = list(4,VV[2],V13,V18,listA(3,VV[19],list(6,(V4),(V5),VV[20],(V9),VV[21],(V11)),(V7)));
	RETURN(1);}}}}}}}
	}}
}
/*	function definition for CONVERT-MACRO-TO-LAMBDA               */
static L7(int narg, object V1, object V2, ...)
{ VT10 VLEX10 CLSR10
	{int i=2;
	object V3;
	va_list args; va_start(args, V2);
	if (i==narg) goto L92;
	V3= va_arg(args, object);
	i++;
	goto L93;
L92:
	V3= VV[22];
L93:
	{object V4;                               /*  GENSYM          */
	Lmake_symbol(1,(V3))                      /*  MAKE-SYMBOL     */;
	V4= VALUES(0);
	Leval(1,listA(4,VV[23],(V4),(V1),(V2)))   /*  EVAL            */;
	RETURN(Lmacro_function(1,(V4))            /*  MACRO-FUNCTION  */);
	}
	}
}
/*	macro definition for WALKER-ENVIRONMENT-BIND                  */
static L8(int narg, object V1, object V2)
{ VT11 VLEX11 CLSR11
	{object V3=CDR(V1),V4,V5,V6,V7;
	{object V8= CAR(V3);
	V4= CAR(V8);
	V8=CDR(V8);
	V5= CAR(V8);
	V8=CDR(V8);
	V6= V8;}
	V3=CDR(V3);
	V7= V3;
	VALUES(0) = listA(3,VV[19],list(4,(V4),(V5),VV[21],listA(3,VV[24],(V5),(V6))),(V7));
	RETURN(1);}
}
/*	function definition for ENV-LOCK                              */
static L9(int narg, object V1)
{ VT12 VLEX12 CLSR12
TTL:
	RETURN(L5(2,(V1),(VV[25]->s.s_dbind))     /*  ENVIRONMENT-MACRO*/);
}
/*	function definition for WALKER-ENVIRONMENT-BIND-1             */
static L10(int narg, object V1, ...)
{ VT13 VLEX13 CLSR13
	{object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[8];
	parse_key(narg,args,4,L10keys,keyvars,OBJNULL,FALSE);
	V2= keyvars[0];
	V3= keyvars[4];
	V4= keyvars[1];
	V5= keyvars[5];
	V6= keyvars[2];
	V7= keyvars[6];
	V8= keyvars[3];
	V9= keyvars[7];
	}
	{register object V10;                     /*  LOCK            */
	L9(1,(V1))                                /*  ENV-LOCK        */;
	V10= VALUES(0);
	{object V11= (VV[25]->s.s_dbind);
	if(((V3))==Cnil){
	goto L100;}
	T0= (V2);
	goto L98;
L100:
	T0= CAR((V10));
L98:
	if(((V5))==Cnil){
	goto L104;}
	T1= (V4);
	goto L102;
L104:
	T1= CADR((V10));
L102:
	if(((V7))==Cnil){
	goto L108;}
	T2= (V6);
	goto L106;
L108:
	T2= CADDR((V10));
L106:
	if(((V9))==Cnil){
	goto L112;}
	VALUES(0) = (V8);
	goto L110;
L112:
	VALUES(0) = CADDDR((V10));
L110:
	VALUES(0) = CONS(list(2,V11,list(4,T0,T1,T2,VALUES(0))),Cnil);
	RETURN(1);}
	}
	}
}
/*	function definition for ENV-WALK-FUNCTION                     */
static L11(int narg, object V1)
{ VT14 VLEX14 CLSR14
TTL:
	L9(1,(V1))                                /*  ENV-LOCK        */;
	VALUES(0) = CAR(VALUES(0));
	RETURN(1);
}
/*	function definition for ENV-WALK-FORM                         */
static L12(int narg, object V1)
{ VT15 VLEX15 CLSR15
TTL:
	L9(1,(V1))                                /*  ENV-LOCK        */;
	VALUES(0) = CADR(VALUES(0));
	RETURN(1);
}
/*	function definition for ENV-DECLARATIONS                      */
static L13(int narg, object V1)
{ VT16 VLEX16 CLSR16
TTL:
	L9(1,(V1))                                /*  ENV-LOCK        */;
	VALUES(0) = CADDR(VALUES(0));
	RETURN(1);
}
/*	function definition for ENV-LEXICAL-VARIABLES                 */
static L14(int narg, object V1)
{ VT17 VLEX17 CLSR17
TTL:
	L9(1,(V1))                                /*  ENV-LOCK        */;
	VALUES(0) = CADDDR(VALUES(0));
	RETURN(1);
}
/*	function definition for NOTE-DECLARATION                      */
static L15(int narg, object V1, object V2)
{ VT18 VLEX18 CLSR18
TTL:
	{object V3;                               /*  LOCK            */
	L9(1,(V2))                                /*  ENV-LOCK        */;
	V3= VALUES(0);
	{object V4;
	V4= CONS((V1),CADDR((V3)));
	CAR(CDDR((V3))) = (V4);
	VALUES(0) = (V4);
	RETURN(1);
	}
	}
}
/*	function definition for NOTE-LEXICAL-BINDING                  */
static L16(int narg, object V1, object V2)
{ VT19 VLEX19 CLSR19
TTL:
	{object V3;                               /*  LOCK            */
	L9(1,(V2))                                /*  ENV-LOCK        */;
	V3= VALUES(0);
	{object V4;
	V4= CONS((V1),CADDDR((V3)));
	CAR(CDDDR((V3))) = (V4);
	VALUES(0) = (V4);
	RETURN(1);
	}
	}
}
/*	function definition for VARIABLE-LEXICAL-P                    */
static L17(int narg, object V1, object V2)
{ VT20 VLEX20 CLSR20
TTL:
	L14(1,(V2))                               /*  ENV-LEXICAL-VARIABLES*/;
	{register object x= (V1),V3= VALUES(0);
	while(V3!=Cnil)
	if(eql(x, CAR(V3))){
	VALUES(0) = V3;
	RETURN(1);
	}else V3=CDR(V3);
	VALUES(0) = Cnil;
	RETURN(1);}
}
/*	function definition for VARIABLE-DECLARATION                  */
static L18(int narg, object V1, object V2, object V3)
{ VT21 VLEX21 CLSR21
TTL:
	{register object x= (V1),V4= (VV[27]->s.s_dbind);
	while(V4!=Cnil)
	if(eql(x, CAR(V4))){
	goto L126;
	}else V4=CDR(V4);}
	RETURN(Lerror(2,VV[28],(V1))              /*  ERROR           */);
L126:
	{object V4;                               /*  ID              */
	L14(1,(V3))                               /*  ENV-LEXICAL-VARIABLES*/;
	{register object x= (V2),V5= VALUES(0);
	while(V5!=Cnil)
	if(eql(x, CAR(V5))){
	VALUES(0) = V5;
	goto L130;
	}else V5=CDR(V5);
	VALUES(0) = Cnil;}
L130:
	if(VALUES(0)==Cnil)goto L129;
	V4= VALUES(0);
	goto L128;
L129:
	V4= (V2);
L128:
	{register object V5;
	register object V6;                       /*  DECL            */
	L13(1,(V3))                               /*  ENV-DECLARATIONS*/;
	V5= VALUES(0);
	V6= Cnil;
L135:
	if(!((V5)==Cnil)){
	goto L136;}
	VALUES(0) = Cnil;
	RETURN(1);
L136:
	V6= CAR((V5));
	if(!((CAR((V6)))==((V1)))){
	goto L141;}
	if((CADR((V6)))==((V4))){
	goto L142;}
	if(!((VV[29])==(CAR((V6))))){
	goto L141;}
	{register object x= (V2),V8= CDDR((V6));
	while(V8!=Cnil)
	if(x==CAR(V8)){
	goto L149;
	}else V8=CDR(V8);
	goto L141;}
L149:
L142:
	VALUES(0) = (V6);
	RETURN(1);
L141:
	V5= CDR((V5));
	goto L135;
	}
	}
}
/*	function definition for VARIABLE-SPECIAL-P                    */
static L19(int narg, object V1, object V2)
{ VT22 VLEX22 CLSR22
TTL:
	L18(3,VV[30],(V1),(V2))                   /*  VARIABLE-DECLARATION*/;
	if(!(((VALUES(0)==Cnil?Ct:Cnil))==Cnil)){
	goto L153;}
	VALUES(0) = Ct;
	RETURN(1);
L153:
	RETURN(L20(1,(V1))                        /*  VARIABLE-GLOBALLY-SPECIAL-P*/);
}
/*	function definition for VARIABLE-GLOBALLY-SPECIAL-P           */
static L20(int narg, object V1)
{ VT23 VLEX23 CLSR23
TTL:
	RETURN(siLspecialp(1,(V1))                /*  SPECIALP        */);
}
/*	macro definition for GET-WALKER-TEMPLATE-INTERNAL             */
static L21(int narg, object V1, object V2)
{ VT24 VLEX24 CLSR24
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(3,VV[31],(V4),VV[32]);
	RETURN(1);}
}
/*	macro definition for DEFINE-WALKER-TEMPLATE                   */
static L22(int narg, object V1, object V2)
{ VT25 VLEX25 CLSR25
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	if(endp(V3)){
	V5= VV[33];
	} else {
	V5= CAR(V3);}
	{object V6= list(2,VV[37],list(2,VV[38],(V4)));
	VALUES(0) = list(3,VV[34],VV[35],list(3,VV[36],V6,list(2,VV[38],(V5))));
	RETURN(1);}}
}
/*	function definition for GET-WALKER-TEMPLATE                   */
static L23(int narg, object V1)
{ VT26 VLEX26 CLSR26
TTL:
	if(!(type_of((V1))==t_symbol)){
	goto L158;}
	VALUES(0) = getf((V1)->s.s_plist,VV[39],Cnil);
	if(VALUES(0)==Cnil)goto L160;
	RETURN(1);
L160:
	RETURN(L24(1,(V1))                        /*  GET-IMPLEMENTATION-DEPENDENT-WALKER-TEMPLATE*/);
L158:
	if(!(type_of((V1))==t_cons||(V1)==Cnil)){
	goto L163;}
	if(!((CAR((V1)))==(VV[40]))){
	goto L163;}
	VALUES(0) = VV[41];
	RETURN(1);
L163:
	RETURN(Lerror(2,VV[42],(V1))              /*  ERROR           */);
}
/*	function definition for GET-IMPLEMENTATION-DEPENDENT-WALKER-TEMPLATE*/
static L24(int narg, object V1)
{ VT27 VLEX27 CLSR27
TTL:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WALK-FORM                             */
static L25(int narg, object V1, ...)
{ VT28 VLEX28 CLSR28
	{int i=1;
	object V2;
	object V3;
	va_list args; va_start(args, V1);
	if (i==narg) goto L167;
	V2= va_arg(args, object);
	i++;
	if (i==narg) goto L168;
	V3= va_arg(args, object);
	i++;
	goto L169;
L167:
	V2= Cnil;
L168:
	V3= VV[140];
L169:
	{object V4;                               /*  NEW-ENV         */
	L10(3,(V2),VV[104],(V3))                  /*  WALKER-ENVIRONMENT-BIND-1*/;
	L3(3,(V2),Cnil,VALUES(0))                 /*  WITH-AUGMENTED-ENVIRONMENT-INTERNAL*/;
	V4= VALUES(0);
	RETURN((*LK0)(3,(V1),VV[105],(V4))        /*  WALK-FORM-INTERNAL*/);
	}
	}
}
/*	function definition for NESTED-WALK-FORM                      */
static L27(int narg, object V1, object V2, ...)
{ VT29 VLEX29 CLSR29
	{int i=2;
	register object V3;
	va_list args; va_start(args, V2);
	if (i==narg) goto L174;
	V3= va_arg(args, object);
	i++;
	if (i==narg) goto L175;
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(va_arg(args, object),env0));/*  WALK-FUNCTION*/
	i++;
	goto L176;
L174:
	V3= Cnil;
L175:
	CLV1=&CAR(env0=CONS(VV[140],env0));       /*  WALK-FUNCTION   */
L176:
	L12(1,(V3))                               /*  ENV-WALK-FORM   */;
	if(!(((V1))==(VALUES(0)))){
	goto L180;}
	{object V4;object env1 = env0;
	L11(1,(V3))                               /*  ENV-WALK-FUNCTION*/;
	V4= VALUES(0);
	CLV2=&CAR(env1=CONS(V4,env1));            /*  OUTER-WALK-FUNCTION*/
	{frame_ptr fr; int V5;
	fr=frs_sch_catch((V1));
	if (fr==NULL) FEerror("The tag ~s is undefined.",1,(V1));
	VALUES(0) = make_cclosure(LC29,env1,&Cblock);
	V5=L25(3,(V2),(V3),VALUES(0))             /*  WALK-FORM       */;
	unwind(fr,(V1),V5+1);}
	}
L180:
	RETURN(L25(3,(V2),(V3),*CLV1)             /*  WALK-FORM       */);
	}
}
/*	closure CLOSURE                                               */
static LC29(int narg, object env0, object V1, object V2, object V3)
{ VT30 VLEX30 CLSR30
	narg--;
	{object scan=env0;
	CLV2= &CAR(scan);                         /*  OUTER-WALK-FUNCTION*/ scan=CDR(scan);
	CLV1= &CAR(scan);                         /*  WALK-FUNCTION   */}
	{register object V4;                      /*  INNER-RESULT    */
	object V5;                                /*  INNER-NO-MORE-P */
	object V6;                                /*  OUTER-RESULT    */
	object V7;                                /*  OUTER-NO-MORE-P */
	V4= Cnil;
	V5= Cnil;
	V6= Cnil;
	V7= Cnil;
L188:
	{ int V8;
	V8=funcall(4,*CLV1,(V1),(V2),(V3));
	if (V8>0) {
	V4= VALUES(0);
	V8--;
	} else {
	V4= Cnil;}
	if (V8>0) {
	V5= VALUES(1);
	} else {
	V5= Cnil;}
	
	}
	if(((V5))==Cnil){
	goto L194;}
	goto L186;
L194:
	{object V9;
	V9= (((((V4))==((V1))?Ct:Cnil))==Cnil?Ct:Cnil);
	if(((V9))==Cnil){
	goto L198;}
	goto L192;
L198:
	if(type_of((V4))==t_cons){
	goto L201;}
	goto L186;
L201:
	L23(1,CAR((V4)))                          /*  GET-WALKER-TEMPLATE*/;
	if(VALUES(0)==Cnil){
	goto L204;}
	goto L186;
L204:
	{ int V12;
	object V13;                               /*  EXPANSION       */
	object V14;                               /*  MACROP          */
	{object V15;                              /*  NEW-ENV         */
	L10(3,(V3),VV[106],(V4))                  /*  WALKER-ENVIRONMENT-BIND-1*/;
	L3(3,(V3),Cnil,VALUES(0))                 /*  WITH-AUGMENTED-ENVIRONMENT-INTERNAL*/;
	V15= VALUES(0);
	V12=Lmacroexpand_1(2,(V4),(V15))          /*  MACROEXPAND-1   */;
	}
	if (V12==0) goto L209;
	V13= VALUES(0);
	V12--;
	if (V12==0) goto L210;
	V14= VALUES(1);
	V12--;
	goto L211;
L209:
	V13= Cnil;
L210:
	V14= Cnil;
L211:
	if(((V14))==Cnil){
	goto L213;}
	V4= (V13);
	goto L192;
L213:
	goto L186;}
	}
L192:
	V1= (V4);
	goto L188;
L186:
	{ int V8;
	V8=funcall(4,*CLV2,(V4),(V2),(V3));
	if (V8>0) {
	V6= VALUES(0);
	V8--;
	} else {
	V6= Cnil;}
	if (V8>0) {
	V7= VALUES(1);
	} else {
	V7= Cnil;}
	
	}
	if((V5)==Cnil){
	VALUES(0) = Cnil;
	goto L220;}
	VALUES(0) = (V7);
L220:
	VALUES(1) = VALUES(0);
	VALUES(0) = (V6);
	RETURN(2);
	}
}
/*	function definition for WALK-FORM-INTERNAL                    */
static L30(int narg, object V1, object V2, object V3)
{ VT31 VLEX31 CLSR31
TTL:
	{register object V4;                      /*  NEWFORM         */
	object V5;                                /*  NEWNEWFORM      */
	object V6;                                /*  WALK-NO-MORE-P  */
	object V7;                                /*  MACROP          */
	register object V8;                       /*  FN              */
	register object V9;                       /*  TEMPLATE        */
	V4= Cnil;
	V5= Cnil;
	V6= Cnil;
	V7= Cnil;
	V8= Cnil;
	V9= Cnil;
	{ int V10;
	if ((V10=frs_push(FRS_CATCH,(V1)))==0) {
	{ int V11;
	L11(1,(V3))                               /*  ENV-WALK-FUNCTION*/;
	T0= VALUES(0);
	V11=funcall(4,T0,(V1),(V2),(V3));
	if (V11>0) {
	V4= VALUES(0);
	V11--;
	} else {
	V4= Cnil;}
	if (V11>0) {
	V6= VALUES(1);
	} else {
	V6= Cnil;}
	
	}
	{ int V11;
	if ((V11=frs_push(FRS_CATCH,(V4)))==0) {
	if(((V6))==Cnil){
	goto L235;}
	VALUES(0)=(V4);
	V11=1;
	goto L233;
L235:
	if(((V1))==((V4))){
	goto L238;}
	V11=(*LK0)(3,(V4),(V2),(V3))              /*  WALK-FORM-INTERNAL*/;
	goto L233;
L238:
	if(type_of((V4))==t_cons){
	goto L241;}
	VALUES(0)=(V4);
	V11=1;
	goto L233;
L241:
	V8= CAR((V4));
	L23(1,(V8))                               /*  GET-WALKER-TEMPLATE*/;
	V9= VALUES(0);
	if(((V9))==Cnil){
	goto L244;}
	if(!(type_of((V9))==t_symbol)){
	goto L249;}
	V11=funcall(4,(V9),(V4),(V2),(V3));
	goto L233;
L249:
	V11=L31(4,(V4),(V9),(V2),(V3))            /*  WALK-TEMPLATE   */;
	goto L233;
L244:
	{ int V12;
	{object V13;                              /*  NEW-ENV         */
	L10(3,(V3),VV[106],(V4))                  /*  WALKER-ENVIRONMENT-BIND-1*/;
	L3(3,(V3),Cnil,VALUES(0))                 /*  WITH-AUGMENTED-ENVIRONMENT-INTERNAL*/;
	V13= VALUES(0);
	V12=Lmacroexpand_1(2,(V4),(V13))          /*  MACROEXPAND-1   */;
	}
	if (V12>0) {
	V5= VALUES(0);
	V12--;
	} else {
	V5= Cnil;}
	if (V12>0) {
	V7= VALUES(1);
	} else {
	V7= Cnil;}
	
	}
	if(((V7))==Cnil){
	goto L256;}
	V11=(*LK0)(3,(V5),(V2),(V3))              /*  WALK-FORM-INTERNAL*/;
	goto L233;
L256:
	if(!(type_of((V8))==t_symbol)){
	goto L259;}
	Lfboundp(1,(V8))                          /*  FBOUNDP         */;
	if(VALUES(0)!=Cnil){
	goto L259;}
	Lspecial_form_p(1,(V8))                   /*  SPECIAL-FORM-P  */;
	if(VALUES(0)==Cnil){
	goto L259;}
	V11=Lerror(2,VV[107],(V8))                /*  ERROR           */;
	goto L233;
L259:
	V11=L31(4,(V5),VV[108],(V2),(V3))         /*  WALK-TEMPLATE   */;
L233:
	}
	else V11--;
	frs_pop();
	V10=V11;}
	}
	else V10--;
	frs_pop();
	RETURN(V10);}
	}
}
/*	function definition for WALK-TEMPLATE                         */
static L31(int narg, object V1, object V2, object V3, object V4)
{ VT32 VLEX32 CLSR32
TTL:
	if(!(type_of((V2))!=t_cons)){
	goto L266;}
	if(((V2)!= VV[115])
	&& ((V2)!= VV[5])
	&& ((V2)!= VV[184])
	&& ((V2)!= VV[185])
	&& ((V2)!= VV[186]))goto L268;
	RETURN((*LK0)(3,(V1),VV[105],(V4))        /*  WALK-FORM-INTERNAL*/);
L268:
	if(((V2)!= VV[38])
	&& ((V2)!= Cnil))goto L269;
	VALUES(0) = (V1);
	RETURN(1);
L269:
	if(((V2)!= VV[187]))goto L270;
	RETURN((*LK0)(3,(V1),VV[109],(V4))        /*  WALK-FORM-INTERNAL*/);
L270:
	if(((V2)!= VV[40])
	&& ((V2)!= VV[188]))goto L271;
	if(!(type_of((V1))==t_symbol)){
	goto L273;}
	VALUES(0) = (V1);
	RETURN(1);
L273:
	RETURN((*LK0)(3,(V1),(V3),(V4))           /*  WALK-FORM-INTERNAL*/);
L271:
	FEerror("The ECASE key value ~s is illegal.",1,(V2));
L266:
	{object V5= CAR((V2));
	if((V5!= VV[189]))goto L275;
	{object V6= CDR((V2));
	if((CDDR((V2)))!=Cnil){
	goto L278;}
	VALUES(0) = Cnil;
	goto L276;
L278:
	VALUES(0) = nthcdr((length((V1)))-(length(CDDR((V2)))),(V1));
L276:
	RETURN(L32(5,(V1),V6,VALUES(0),(V3),(V4)) /*  WALK-TEMPLATE-HANDLE-REPEAT*/);}
L275:
	if((V5!= VV[57]))goto L280;
	{object V7;
	V7= (V1);
	{object V8= CADR((V2));
	if(!(type_of(V8)==t_cons||V8==Cnil)){
	goto L288;}}
	Leval(1,CADR((V2)))                       /*  EVAL            */;
	if(VALUES(0)==Cnil){
	goto L285;}
	goto L286;
L288:
	T0= CADR((V2));
	funcall(2,T0,(V1));
	if(VALUES(0)==Cnil){
	goto L285;}
L286:
	V2= CADDR((V2));
	goto L283;
L285:
	V2= CADDDR((V2));
L283:
	V1= (V7);}
	goto TTL;
L280:
	if((V5!= VV[190]))goto L293;
	V2= CADR((V2));
	goto TTL;
L293:
	if(!(type_of((V1))!=t_cons)){
	goto L300;}
	VALUES(0) = (V1);
	RETURN(1);
L300:
	L31(4,CAR((V1)),CAR((V2)),(V3),(V4))      /*  WALK-TEMPLATE   */;
	T0= VALUES(0);
	L31(4,CDR((V1)),CDR((V2)),(V3),(V4))      /*  WALK-TEMPLATE   */;
	RETURN(L35(3,(V1),T0,VALUES(0))           /*  RECONS          */);}
}
/*	function definition for WALK-TEMPLATE-HANDLE-REPEAT           */
static L32(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT33 VLEX33 CLSR33
TTL:
	if(!(((V1))==((V3)))){
	goto L305;}
	RETURN(L31(4,(V1),CDR((V2)),(V4),(V5))    /*  WALK-TEMPLATE   */);
L305:
	RETURN(L33(6,(V1),(V2),CAR((V2)),(V3),(V4),(V5))/*  WALK-TEMPLATE-HANDLE-REPEAT-1*/);
}
/*	function definition for WALK-TEMPLATE-HANDLE-REPEAT-1         */
static L33(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT34 VLEX34 CLSR34
TTL:
	if(((V1))!=Cnil){
	goto L308;}
	VALUES(0) = Cnil;
	RETURN(1);
L308:
	if(!(((V1))==((V4)))){
	goto L311;}
	if(((V3))!=Cnil){
	goto L314;}
	RETURN(L31(4,(V4),CDR((V2)),(V5),(V6))    /*  WALK-TEMPLATE   */);
L314:
	RETURN(Lerror(1,VV[110])                  /*  ERROR           */);
L311:
	if(((V3))!=Cnil){
	goto L317;}
	{object V7;
	V7= (V2);
	V3= CAR((V2));
	V2= (V7);}
	goto TTL;
L317:
	L31(4,CAR((V1)),CAR((V3)),(V5),(V6))      /*  WALK-TEMPLATE   */;
	T0= VALUES(0);
	L33(6,CDR((V1)),(V2),CDR((V3)),(V4),(V5),(V6))/*  WALK-TEMPLATE-HANDLE-REPEAT-1*/;
	RETURN(L35(3,(V1),T0,VALUES(0))           /*  RECONS          */);
}
/*	function definition for WALK-REPEAT-EVAL                      */
static L34(int narg, object V1, object V2)
{ VT35 VLEX35 CLSR35
TTL:
	if((V1)==Cnil){
	VALUES(0) = Cnil;
	RETURN(1);}
	(*LK0)(3,CAR((V1)),VV[105],(V2))          /*  WALK-FORM-INTERNAL*/;
	T0= VALUES(0);
	L34(2,CDR((V1)),(V2))                     /*  WALK-REPEAT-EVAL*/;
	RETURN(L35(3,(V1),T0,VALUES(0))           /*  RECONS          */);
}
/*	function definition for RECONS                                */
static L35(int narg, object V1, object V2, object V3)
{ VT36 VLEX36 CLSR36
TTL:
	if(!((CAR((V1)))==((V2)))){
	goto L330;}
	if((CDR((V1)))==((V3))){
	goto L331;}
L330:
	VALUES(0) = CONS((V2),(V3));
	RETURN(1);
L331:
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for RELIST                                */
static L36(int narg, object V1, ...)
{ VT37 VLEX37 CLSR37
	{object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	RETURN(L38(3,(V1),(V2),Cnil)              /*  RELIST-INTERNAL */);
	}
}
/*	function definition for RELIST*                               */
static L37(int narg, object V1, ...)
{ VT38 VLEX38 CLSR38
	{object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	RETURN(L38(3,(V1),(V2),Ct)                /*  RELIST-INTERNAL */);
	}
}
/*	function definition for RELIST-INTERNAL                       */
static L38(int narg, object V1, object V2, object V3)
{ VT39 VLEX39 CLSR39
TTL:
	if((CDR((V2)))!=Cnil){
	goto L336;}
	if(((V3))==Cnil){
	goto L339;}
	VALUES(0) = CAR((V2));
	RETURN(1);
L339:
	VALUES(0) = CONS(CAR((V2)),Cnil);
	RETURN(1);
L336:
	{object V4= CAR((V2));
	L38(3,CDR((V1)),CDR((V2)),(V3))           /*  RELIST-INTERNAL */;
	RETURN(L35(3,(V1),V4,VALUES(0))           /*  RECONS          */);}
}
/*	function definition for WALK-DECLARATIONS                     */
static L39(int narg, object V1, object V2, object V3, ...)
{ VT40 VLEX40 CLSR40
	{int i=3;
	object V4;
	register object V5;
	object V6;
	va_list args; va_start(args, V3);
	if (i==narg) goto L342;
	V4= va_arg(args, object);
	i++;
	if (i==narg) goto L343;
	V5= va_arg(args, object);
	i++;
	if (i==narg) goto L344;
	V6= va_arg(args, object);
	i++;
	goto L345;
L342:
	V4= Cnil;
L343:
	V5= Cnil;
L344:
	V6= Cnil;
L345:
	{register object V7;                      /*  FORM            */
	object V8;                                /*  MACROP          */
	object V9;                                /*  NEW-FORM        */
	V7= CAR((V1));
	V8= Cnil;
	V9= Cnil;
	if(!(type_of((V7))==t_string)){
	goto L353;}
	if((CDR((V1)))==Cnil){
	goto L353;}
	if(((V4))!=Cnil){
	goto L353;}
	if(((V5))!=Cnil){
	goto L353;}
	L39(4,CDR((V1)),(V2),(V3),Ct)             /*  WALK-DECLARATIONS*/;
	RETURN(L35(3,(V1),(V7),VALUES(0))         /*  RECONS          */);
L353:
	if(!(type_of((V7))==t_cons||(V7)==Cnil)){
	goto L363;}
	if(!((CAR((V7)))==(VV[49]))){
	goto L363;}
	{object V10;
	register object V11;                      /*  DECLARATION     */
	V10= CDR((V7));
	V11= Cnil;
L371:
	if(!((V10)==Cnil)){
	goto L372;}
	goto L367;
L372:
	V11= CAR((V10));
	{object V13;                              /*  TYPE            */
	object V14;                               /*  NAME            */
	object V15;                               /*  ARGS            */
	V13= CAR((V11));
	V14= CADR((V11));
	V15= CDDR((V11));
	{register object x= (V13),V16= (VV[27]->s.s_dbind);
	while(V16!=Cnil)
	if(eql(x, CAR(V16))){
	goto L384;
	}else V16=CDR(V16);
	goto L383;}
L384:
	L17(2,(V14),(V3))                         /*  VARIABLE-LEXICAL-P*/;
	if(VALUES(0)==Cnil)goto L386;
	goto L385;
L386:
	VALUES(0) = (V14);
L385:
	L15(2,listA(3,(V13),VALUES(0),(V15)),(V3))/*  NOTE-DECLARATION*/;
	goto L381;
L383:
	L15(2,(V11),(V3))                         /*  NOTE-DECLARATION*/;
L381:
	V5= CONS((V11),(V5));
	}
	V10= CDR((V10));
	goto L371;
	}
L367:
	L39(5,CDR((V1)),(V2),(V3),(V4),(V5))      /*  WALK-DECLARATIONS*/;
	RETURN(L35(3,(V1),(V7),VALUES(0))         /*  RECONS          */);
L363:
	if(((V7))==Cnil){
	goto L394;}
	if(!(type_of((V7))==t_cons||(V7)==Cnil)){
	goto L394;}
	L23(1,CAR((V7)))                          /*  GET-WALKER-TEMPLATE*/;
	if(VALUES(0)!=Cnil){
	goto L394;}
	{ int V10;
	V10=Lmacroexpand_1(2,(V7),(V3))           /*  MACROEXPAND-1   */;
	if (V10>0) {
	V9= VALUES(0);
	V10--;
	} else {
	V9= Cnil;}
	if (V10>0) {
	V8= VALUES(1);
	} else {
	V8= Cnil;}
	
	}
	if(((V8))==Cnil){
	goto L394;}
	L35(3,(V1),(V9),CDR((V1)))                /*  RECONS          */;
	T0= VALUES(0);
	if((V6)!=Cnil){
	VALUES(0) = (V6);
	goto L405;}
	VALUES(0) = (V1);
L405:
	RETURN(L39(6,T0,(V2),(V3),(V4),(V5),VALUES(0))/*  WALK-DECLARATIONS*/);
L394:
	if((V6)!=Cnil){
	VALUES(0) = (V6);
	goto L406;}
	VALUES(0) = (V1);
L406:
	RETURN(funcall(3,(V2),VALUES(0),(V3)));
	}
	}
}
/*	function definition for WALK-UNEXPECTED-DECLARE               */
static L40(int narg, object V1, object V2, object V3)
{ VT41 VLEX41 CLSR41
TTL:
	(*LK1)(2,VV[111],(V1))                    /*  WARN            */;
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for WALK-ARGLIST                          */
static L41(int narg, object V1, object V2, object V3, ...)
{ VT42 VLEX42 CLSR42
	{int i=3;
	object V4;
	va_list args; va_start(args, V3);
	if (i==narg) goto L408;
	V4= va_arg(args, object);
	i++;
	goto L409;
L408:
	V4= Cnil;
L409:
	{register object V5;                      /*  ARG             */
	V5= Cnil;
	if(((V1))!=Cnil){
	goto L413;}
	VALUES(0) = Cnil;
	RETURN(1);
L413:
	V5= CAR((V1));
	if(!(type_of((V5))==t_symbol)){
	goto L416;}
	{register object x= (V5),V6= VV[112];
	while(V6!=Cnil)
	if(eql(x, CAR(V6))){
	VALUES(0) = V6;
	goto L421;
	}else V6=CDR(V6);
	VALUES(0) = Cnil;}
L421:
	if(VALUES(0)==Cnil)goto L420;
	goto L419;
L420:
	(*LK2)(2,(V5),(V3))                       /*  NOTE-LEXICAL-BINDING*/;
L419:
	{object V6= CDR((V1));
	if((V4)==Cnil){
	VALUES(0) = Cnil;
	goto L422;}
	{register object x= (V5),V7= VV[112];
	while(V7!=Cnil)
	if(eql(x, CAR(V7))){
	VALUES(0) = V7;
	goto L423;
	}else V7=CDR(V7);
	VALUES(0) = Cnil;}
L423:
	VALUES(0) = ((VALUES(0))==Cnil?Ct:Cnil);
L422:
	L41(4,V6,(V2),(V3),VALUES(0))             /*  WALK-ARGLIST    */;
	RETURN(L35(3,(V1),(V5),VALUES(0))         /*  RECONS          */);}
L416:
	if(!(type_of((V5))==t_cons)){
	goto L426;}
	{object V7;
	if(((V4))==Cnil){
	goto L430;}
	L41(4,(V5),(V2),(V3),(V4))                /*  WALK-ARGLIST    */;
	V7= VALUES(0);
	goto L428;
L430:
	{object V8= CAR((V5));
	(*LK0)(3,CADR((V5)),VV[105],(V3))         /*  WALK-FORM-INTERNAL*/;
	T0= VALUES(0);
	L37(4,(V5),V8,T0,CDDR((V5)))              /*  RELIST*         */;
	T1= VALUES(0);
	L41(4,CDR((V1)),(V2),(V3),Cnil)           /*  WALK-ARGLIST    */;
	L35(3,(V1),T1,VALUES(0))                  /*  RECONS          */;
	V7= VALUES(0);}
L428:
	if(!(type_of(CAR((V5)))==t_symbol)){
	goto L437;}
	(*LK2)(2,CAR((V5)),(V3))                  /*  NOTE-LEXICAL-BINDING*/;
	goto L435;
L437:
	(*LK2)(2,CADAR((V5)),(V3))                /*  NOTE-LEXICAL-BINDING*/;
L435:
	if(!(CDDR((V5))==Cnil)){
	goto L440;}
	goto L439;
L440:
	if(!(((type_of(CADDR((V5)))==t_symbol?Ct:Cnil))==Cnil)){
	goto L442;}
	goto L439;
L442:
	(*LK2)(2,CADDR((V5)),(V3))                /*  NOTE-LEXICAL-BINDING*/;
L439:
	VALUES(0) = (V7);
	RETURN(1);
	}
L426:
	RETURN(Lerror(2,VV[113],(V1))             /*  ERROR           */);
	}
	}
}
/*	function definition for WALK-LET                              */
static L42(int narg, object V1, object V2, object V3)
{ VT43 VLEX43 CLSR43
TTL:
	RETURN((*LK3)(4,(V1),(V2),(V3),Cnil)      /*  WALK-LET/LET*   */);
}
/*	function definition for WALK-LET*                             */
static L43(int narg, object V1, object V2, object V3)
{ VT44 VLEX44 CLSR44
TTL:
	RETURN((*LK3)(4,(V1),(V2),(V3),Ct)        /*  WALK-LET/LET*   */);
}
/*	function definition for WALK-PROG                             */
static L44(int narg, object V1, object V2, object V3)
{ VT45 VLEX45 CLSR45
TTL:
	RETURN(L49(4,(V1),(V2),(V3),Cnil)         /*  WALK-PROG/PROG* */);
}
/*	function definition for WALK-PROG*                            */
static L45(int narg, object V1, object V2, object V3)
{ VT46 VLEX46 CLSR46
TTL:
	RETURN(L49(4,(V1),(V2),(V3),Ct)           /*  WALK-PROG/PROG* */);
}
/*	function definition for WALK-DO                               */
static L46(int narg, object V1, object V2, object V3)
{ VT47 VLEX47 CLSR47
TTL:
	RETURN(L51(4,(V1),(V2),(V3),Cnil)         /*  WALK-DO/DO*     */);
}
/*	function definition for WALK-DO*                              */
static L47(int narg, object V1, object V2, object V3)
{ VT48 VLEX48 CLSR48
TTL:
	RETURN(L51(4,(V1),(V2),(V3),Ct)           /*  WALK-DO/DO*     */);
}
/*	function definition for WALK-LET/LET*                         */
static L48(int narg, object V1, object V2, object V3, object V4)
{ VT49 VLEX49 CLSR49
TTL:
	{object V5;                               /*  NEW-ENV         */
	L10(1,(V3))                               /*  WALKER-ENVIRONMENT-BIND-1*/;
	L3(3,(V3),Cnil,VALUES(0))                 /*  WITH-AUGMENTED-ENVIRONMENT-INTERNAL*/;
	V5= VALUES(0);
	{object V6;                               /*  LET/LET*        */
	object V7;                                /*  BINDINGS        */
	object V8;                                /*  BODY            */
	object V9;                                /*  WALKED-BINDINGS */
	V6= CAR((V1));
	V7= CADR((V1));
	V8= CDDR((V1));
	(*LK4)(5,(V7),(V3),(V5),(V2),(V4))        /*  WALK-BINDINGS-1 */;
	V9= VALUES(0);
	VALUES(0) = (VV[147]->s.s_gfdef);
	L39(3,(V8),VALUES(0),(V5))                /*  WALK-DECLARATIONS*/;
	RETURN(L37(4,(V1),(V6),(V9),VALUES(0))    /*  RELIST*         */);
	}
	}
}
/*	function definition for WALK-PROG/PROG*                       */
static L49(int narg, object V1, object V2, object V3, object V4)
{ VT50 VLEX50 CLSR50
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(V2,env0));            /*  CONTEXT         */
	{object V5;                               /*  NEW-ENV         */
	L10(1,(V3))                               /*  WALKER-ENVIRONMENT-BIND-1*/;
	L3(3,(V3),Cnil,VALUES(0))                 /*  WITH-AUGMENTED-ENVIRONMENT-INTERNAL*/;
	V5= VALUES(0);
	{object V6;                               /*  LET/LET*        */
	object V7;                                /*  BINDINGS        */
	object V8;                                /*  BODY            */
	object V9;                                /*  WALKED-BINDINGS */
	V6= CAR((V1));
	V7= CADR((V1));
	V8= CDDR((V1));
	(*LK4)(5,(V7),(V3),(V5),*CLV0,(V4))       /*  WALK-BINDINGS-1 */;
	V9= VALUES(0);
	VALUES(0) = make_cclosure(LC50,env0,&Cblock);
	L39(3,(V8),VALUES(0),(V5))                /*  WALK-DECLARATIONS*/;
	RETURN(L37(4,(V1),(V6),(V9),VALUES(0))    /*  RELIST*         */);
	}
	}
}
/*	closure CLOSURE                                               */
static LC50(int narg, object env0, object V1, object V2)
{ VT51 VLEX51 CLSR51
	narg--;
	{object scan=env0;
	CLV0= &CAR(scan);                         /*  CONTEXT         */}
	RETURN(L59(3,(V1),*CLV0,(V2))             /*  WALK-TAGBODY-1  */);
}
/*	function definition for WALK-DO/DO*                           */
static L51(int narg, object V1, object V2, object V3, object V4)
{ VT52 VLEX52 CLSR52
TTL:
	{register object V5;                      /*  NEW-ENV         */
	L10(1,(V3))                               /*  WALKER-ENVIRONMENT-BIND-1*/;
	L3(3,(V3),Cnil,VALUES(0))                 /*  WITH-AUGMENTED-ENVIRONMENT-INTERNAL*/;
	V5= VALUES(0);
	{object V6;                               /*  DO/DO*          */
	object V7;                                /*  BINDINGS        */
	object V8;                                /*  END-TEST        */
	object V9;                                /*  BODY            */
	object V10;                               /*  WALKED-BINDINGS */
	object V11;                               /*  WALKED-BODY     */
	V6= CAR((V1));
	V7= CADR((V1));
	V8= CADDR((V1));
	V9= CDDDR((V1));
	(*LK4)(5,(V7),(V3),(V5),(V2),(V4))        /*  WALK-BINDINGS-1 */;
	V10= VALUES(0);
	VALUES(0) = (VV[147]->s.s_gfdef);
	L39(3,(V9),VALUES(0),(V5))                /*  WALK-DECLARATIONS*/;
	V11= VALUES(0);
	L55(4,(V7),(V10),(V2),(V5))               /*  WALK-BINDINGS-2 */;
	T0= VALUES(0);
	L31(4,(V8),VV[114],(V2),(V5))             /*  WALK-TEMPLATE   */;
	RETURN(L37(5,(V1),(V6),T0,VALUES(0),(V11))/*  RELIST*         */);
	}
	}
}
/*	function definition for WALK-MULTIPLE-VALUE-BIND              */
static L52(int narg, object V1, object V2, object V3)
{ VT53 VLEX53 CLSR53
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(V2,env0));            /*  CONTEXT         */
	CLV1=&CAR(env0=CONS(V3,env0));            /*  OLD-ENV         */
	{object V4;
	L10(1,*CLV1)                              /*  WALKER-ENVIRONMENT-BIND-1*/;
	L3(3,*CLV1,Cnil,VALUES(0))                /*  WITH-AUGMENTED-ENVIRONMENT-INTERNAL*/;
	V4= VALUES(0);
	CLV2=&CAR(env0=CONS(V4,env0));            /*  NEW-ENV         */
	{object V5;                               /*  MVB             */
	object V6;                                /*  MV-FORM         */
	object V7;                                /*  BODY            */
	object V8;                                /*  WALKED-BODY     */
	V5= CAR((V1));
	CLV3=&CAR(env0=CONS(CADR((V1)),env0));    /*  BINDINGS        */
	L31(4,CADDR((V1)),VV[115],*CLV0,*CLV1)    /*  WALK-TEMPLATE   */;
	V6= VALUES(0);
	V7= CDDDR((V1));
	CLV4=&CAR(env0=CONS(Cnil,env0));          /*  WALKED-BINDINGS */
	VALUES(0) = make_cclosure(LC53,env0,&Cblock);
	L39(3,(V7),VALUES(0),*CLV2)               /*  WALK-DECLARATIONS*/;
	V8= VALUES(0);
	RETURN(L37(5,(V1),(V5),*CLV4,(V6),(V8))   /*  RELIST*         */);
	}
	}
}
/*	closure CLOSURE                                               */
static LC53(int narg, object env0, object V1, object V2)
{ VT54 VLEX54 CLSR54
	narg--;
	{object scan=env0;
	CLV4= &CAR(scan);                         /*  WALKED-BINDINGS */ scan=CDR(scan);
	CLV3= &CAR(scan);                         /*  BINDINGS        */ scan=CDR(scan);
	CLV2= &CAR(scan);                         /*  NEW-ENV         */ scan=CDR(scan);
	CLV1= &CAR(scan);                         /*  OLD-ENV         */ scan=CDR(scan);
	CLV0= &CAR(scan);                         /*  CONTEXT         */}
	(*LK4)(5,*CLV3,*CLV1,*CLV2,*CLV0,Cnil)    /*  WALK-BINDINGS-1 */;
	*CLV4= VALUES(0);
	RETURN(L34(2,(V1),(V2))                   /*  WALK-REPEAT-EVAL*/);
}
/*	function definition for WALK-BINDINGS-1                       */
static L54(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT55 VLEX55 CLSR55
TTL:
	if((V1)==Cnil){
	VALUES(0) = Cnil;
	RETURN(1);}
	{register object V6;                      /*  BINDING         */
	V6= CAR((V1));
	if(!(type_of((V6))==t_symbol)){
	goto L484;}
	{object V7;
	(*LK2)(2,(V6),(V3))                       /*  NOTE-LEXICAL-BINDING*/;
	T0= (V6);
	goto L482;
	}
L484:
	{object V8;
	{object V9= CAR((V6));
	{object V10= CADR((V6));
	if(((V5))==Cnil){
	goto L490;}
	VALUES(0) = (V3);
	goto L488;
L490:
	VALUES(0) = (V2);
L488:
	(*LK0)(3,V10,(V4),VALUES(0))              /*  WALK-FORM-INTERNAL*/;
	T1= VALUES(0);
	L37(4,(V6),V9,T1,CDDR((V6)))              /*  RELIST*         */;
	V8= VALUES(0);}}
	(*LK2)(2,CAR((V6)),(V3))                  /*  NOTE-LEXICAL-BINDING*/;
	T0= (V8);
	}
L482:
	(*LK4)(5,CDR((V1)),(V2),(V3),(V4),(V5))   /*  WALK-BINDINGS-1 */;
	RETURN(L35(3,(V1),T0,VALUES(0))           /*  RECONS          */);
	}
}
/*	function definition for WALK-BINDINGS-2                       */
static L55(int narg, object V1, object V2, object V3, object V4)
{ VT56 VLEX56 CLSR56
TTL:
	if((V1)==Cnil){
	VALUES(0) = Cnil;
	RETURN(1);}
	{register object V5;                      /*  BINDING         */
	object V6;                                /*  WALKED-BINDING  */
	V5= CAR((V1));
	V6= CAR((V2));
	if(!(type_of((V5))==t_symbol)){
	goto L499;}
	T0= (V5);
	goto L497;
L499:
	{object V7= CAR((V6));
	{object V8= CADR((V6));
	L31(4,CDDR((V5)),VV[116],(V3),(V4))       /*  WALK-TEMPLATE   */;
	L37(4,(V5),V7,V8,VALUES(0))               /*  RELIST*         */;
	T0= VALUES(0);}}
L497:
	L55(4,CDR((V1)),CDR((V2)),(V3),(V4))      /*  WALK-BINDINGS-2 */;
	RETURN(L35(3,(V1),T0,VALUES(0))           /*  RECONS          */);
	}
}
/*	function definition for WALK-LAMBDA                           */
static L56(int narg, object V1, object V2, object V3)
{ VT57 VLEX57 CLSR57
TTL:
	{object V4;                               /*  NEW-ENV         */
	L10(1,(V3))                               /*  WALKER-ENVIRONMENT-BIND-1*/;
	L3(3,(V3),Cnil,VALUES(0))                 /*  WITH-AUGMENTED-ENVIRONMENT-INTERNAL*/;
	V4= VALUES(0);
	{object V5;                               /*  ARGLIST         */
	object V6;                                /*  BODY            */
	object V7;                                /*  WALKED-ARGLIST  */
	V5= CADR((V1));
	V6= CDDR((V1));
	L41(3,(V5),(V2),(V4))                     /*  WALK-ARGLIST    */;
	V7= VALUES(0);
	{object V8= CAR((V1));
	VALUES(0) = (VV[147]->s.s_gfdef);
	L39(3,(V6),VALUES(0),(V4))                /*  WALK-DECLARATIONS*/;
	RETURN(L37(4,(V1),V8,(V7),VALUES(0))      /*  RELIST*         */);}
	}
	}
}
/*	function definition for WALK-NAMED-LAMBDA                     */
static L57(int narg, object V1, object V2, object V3)
{ VT58 VLEX58 CLSR58
TTL:
	{object V4;                               /*  NEW-ENV         */
	L10(1,(V3))                               /*  WALKER-ENVIRONMENT-BIND-1*/;
	L3(3,(V3),Cnil,VALUES(0))                 /*  WITH-AUGMENTED-ENVIRONMENT-INTERNAL*/;
	V4= VALUES(0);
	{object V5;                               /*  NAME            */
	object V6;                                /*  ARGLIST         */
	object V7;                                /*  BODY            */
	object V8;                                /*  WALKED-ARGLIST  */
	V5= CADR((V1));
	V6= CADDR((V1));
	V7= CDDDR((V1));
	L41(3,(V6),(V2),(V4))                     /*  WALK-ARGLIST    */;
	V8= VALUES(0);
	{object V9= CAR((V1));
	VALUES(0) = (VV[147]->s.s_gfdef);
	L39(3,(V7),VALUES(0),(V4))                /*  WALK-DECLARATIONS*/;
	RETURN(L37(5,(V1),V9,(V5),(V8),VALUES(0)) /*  RELIST*         */);}
	}
	}
}
/*	function definition for WALK-TAGBODY                          */
static L58(int narg, object V1, object V2, object V3)
{ VT59 VLEX59 CLSR59
TTL:
	{object V4= CAR((V1));
	L59(3,CDR((V1)),(V2),(V3))                /*  WALK-TAGBODY-1  */;
	RETURN(L35(3,(V1),V4,VALUES(0))           /*  RECONS          */);}
}
/*	function definition for WALK-TAGBODY-1                        */
static L59(int narg, object V1, object V2, object V3)
{ VT60 VLEX60 CLSR60
TTL:
	if((V1)==Cnil){
	VALUES(0) = Cnil;
	RETURN(1);}
	{object V4= CAR((V1));
	if(!(type_of(CAR((V1)))==t_symbol)){
	goto L521;}
	VALUES(0) = VV[38];
	goto L519;
L521:
	VALUES(0) = (V2);
L519:
	(*LK0)(3,V4,VALUES(0),(V3))               /*  WALK-FORM-INTERNAL*/;
	T0= VALUES(0);
	L59(3,CDR((V1)),(V2),(V3))                /*  WALK-TAGBODY-1  */;
	RETURN(L35(3,(V1),T0,VALUES(0))           /*  RECONS          */);}
}
/*	function definition for WALK-COMPILER-LET                     */
static L60(int narg, object V1, object V2, object V3)
{ VT61 VLEX61 CLSR61
TTL:
	{register object V4;                      /*  VARS            */
	register object V5;                       /*  VALS            */
	V4= Cnil;
	V5= Cnil;
	{register object V6;
	register object V7;                       /*  BINDING         */
	V6= CADR((V1));
	V7= Cnil;
L529:
	if(!((V6)==Cnil)){
	goto L530;}
	goto L525;
L530:
	V7= CAR((V6));
	if(!(type_of((V7))==t_symbol)){
	goto L537;}
	V4= CONS((V7),(V4));
	V5= CONS(Cnil,(V5));
	goto L535;
L537:
	V4= CONS(CAR((V7)),(V4));
	Leval(1,CADR((V7)))                       /*  EVAL            */;
	V5= CONS(VALUES(0),(V5));
L535:
	V6= CDR((V6));
	goto L529;
	}
L525:
	{object V6= CAR((V1));
	{object V7= CADR((V1));
	{object V9,V10;
	bds_ptr V8=bds_top;
	V9= (V4);
	V10= (V5);
	while(!endp(V9)) {
	if(endp(V10))bds_bind(CAR(V9),OBJNULL);
	else{bds_bind(CAR(V9),CAR(V10));
	V10=CDR(V10);}
	V9=CDR(V9);}
	L34(2,CDDR((V1)),(V3))                    /*  WALK-REPEAT-EVAL*/;
	bds_unwind(V8);}
	RETURN(L37(4,(V1),V6,V7,VALUES(0))        /*  RELIST*         */);}}
	}
}
/*	function definition for WALK-MACROLET                         */
static L61(int narg, object V1, object V2, object V3)
{ VT62 VLEX62 CLSR62
	lex0[0]=V2;                               /*  CONTEXT         */
TTL:
	{object V4;
	L11(1,(V3))                               /*  ENV-WALK-FUNCTION*/;
	L10(3,Cnil,VV[104],VALUES(0))             /*  WALKER-ENVIRONMENT-BIND-1*/;
	L3(3,Cnil,Cnil,VALUES(0))                 /*  WITH-AUGMENTED-ENVIRONMENT-INTERNAL*/;
	V4= VALUES(0);
	lex0[1]=V4;                               /*  MACRO-ENV       */
	{object V5;
	object V6;
	V5= Cnil;
	V6= Cnil;
	{object V7= CAR((V1));
	if((V7!= VV[52])
	&& (V7!= VV[59]))goto L556;
	{register object V8;
	object V9;                                /*  FN              */
	V8= CADR((V1));
	V9= Cnil;
L560:
	if(!((V8)==Cnil)){
	goto L561;}
	goto L555;
L561:
	V9= CAR((V8));
	V5= CONS((V9),(V5));
	V8= CDR((V8));
	goto L560;
	}
L556:
	if((V7!= VV[65]))goto L571;
	{register object V11;
	register object V12;                      /*  MAC             */
	V11= CADR((V1));
	V12= Cnil;
L575:
	if(!((V11)==Cnil)){
	goto L576;}
	goto L555;
L576:
	V12= CAR((V11));
	{object V14= CAR((V12));
	{object V15= CADR((V12));
	{object V16= CDDR((V12));
	Lstring(1,CAR((V12)))                     /*  STRING          */;
	L7(3,V15,V16,VALUES(0))                   /*  CONVERT-MACRO-TO-LAMBDA*/;
	V6= CONS(list(2,V14,VALUES(0)),(V6));}}}
	V11= CDR((V11));
	goto L575;
	}
L571:
	FEerror("The ECASE key value ~s is illegal.",1,V7);}
L555:
	{object V7;                               /*  NEW-ENV         */
	L3(3,(V3),(V5),(V6))                      /*  WITH-AUGMENTED-ENVIRONMENT-INTERNAL*/;
	V7= VALUES(0);
	{object V8= CAR((V1));
	LC62(lex0,1,CADR((V1)))                   /*  WALK-DEFINITIONS*/;
	T0= VALUES(0);
	{object V9= CDDR((V1));
	VALUES(0) = (VV[147]->s.s_gfdef);
	L39(3,V9,VALUES(0),(V7))                  /*  WALK-DECLARATIONS*/;
	RETURN(L37(4,(V1),V8,T0,VALUES(0))        /*  RELIST*         */);}}
	}
	}
	}
}
/*	local function WALK-DEFINITIONS                               */
static LC62(object *lex0,int narg, object V1)
{ VT63 VLEX63 CLSR63
TTL:
	if((V1)==Cnil){
	VALUES(0) = Cnil;
	RETURN(1);}
	{register object V2;                      /*  DEFINITION      */
	V2= CAR((V1));
	{object V3= CAR((V2));
	L41(4,CADR((V2)),lex0[0],lex0[1],Ct)      /*  WALK-ARGLIST    */;
	T0= VALUES(0);
	{object V4= CDDR((V2));
	VALUES(0) = (VV[147]->s.s_gfdef);
	L39(3,V4,VALUES(0),lex0[1])               /*  WALK-DECLARATIONS*/;
	L37(4,(V2),V3,T0,VALUES(0))               /*  RELIST*         */;
	T1= VALUES(0);
	LC62(lex0,1,CDR((V1)))                    /*  WALK-DEFINITIONS*/;
	RETURN(L35(3,(V1),T1,VALUES(0))           /*  RECONS          */);}}
	}
}
/*	function definition for WALK-FLET                             */
static L63(int narg, object V1, object V2, object V3)
{ VT64 VLEX64 CLSR64
	lex0[0]=V2;                               /*  CONTEXT         */
	lex0[1]=V3;                               /*  OLD-ENV         */
TTL:
	{object V4= CAR((V1));
	{object V5= CDR((V1));
	LC64(lex0,1,CADR((V1)))                   /*  WALK-DEFINITIONS*/;
	T0= VALUES(0);
	{object V6;
	object V7;
	V6= Cnil;
	V7= Cnil;
	{object V8= CAR((V1));
	if((V8!= VV[52])
	&& (V8!= VV[59]))goto L601;
	{register object V9;
	object V10;                               /*  FN              */
	V9= CADR((V1));
	V10= Cnil;
L605:
	if(!((V9)==Cnil)){
	goto L606;}
	goto L600;
L606:
	V10= CAR((V9));
	V6= CONS((V10),(V6));
	V9= CDR((V9));
	goto L605;
	}
L601:
	if((V8!= VV[65]))goto L616;
	{register object V12;
	register object V13;                      /*  MAC             */
	V12= CADR((V1));
	V13= Cnil;
L620:
	if(!((V12)==Cnil)){
	goto L621;}
	goto L600;
L621:
	V13= CAR((V12));
	{object V15= CAR((V13));
	{object V16= CADR((V13));
	{object V17= CDDR((V13));
	Lstring(1,CAR((V13)))                     /*  STRING          */;
	L7(3,V16,V17,VALUES(0))                   /*  CONVERT-MACRO-TO-LAMBDA*/;
	V7= CONS(list(2,V15,VALUES(0)),(V7));}}}
	V12= CDR((V12));
	goto L620;
	}
L616:
	FEerror("The ECASE key value ~s is illegal.",1,V8);}
L600:
	{object V8;                               /*  NEW-ENV         */
	L3(3,lex0[1],(V6),(V7))                   /*  WITH-AUGMENTED-ENVIRONMENT-INTERNAL*/;
	V8= VALUES(0);
	{object V9= CDDR((V1));
	VALUES(0) = (VV[147]->s.s_gfdef);
	L39(3,V9,VALUES(0),(V8))                  /*  WALK-DECLARATIONS*/;}
	}
	}
	L35(3,V5,T0,VALUES(0))                    /*  RECONS          */;
	RETURN(L35(3,(V1),V4,VALUES(0))           /*  RECONS          */);}}
}
/*	local function WALK-DEFINITIONS                               */
static LC64(object *lex0,int narg, object V1)
{ VT65 VLEX65 CLSR65
TTL:
	if(((V1))!=Cnil){
	goto L637;}
	VALUES(0) = Cnil;
	RETURN(1);
L637:
	L56(3,CAR((V1)),lex0[0],lex0[1])          /*  WALK-LAMBDA     */;
	T0= VALUES(0);
	LC64(lex0,1,CDR((V1)))                    /*  WALK-DEFINITIONS*/;
	RETURN(L35(3,(V1),T0,VALUES(0))           /*  RECONS          */);
}
/*	function definition for WALK-LABELS                           */
static L65(int narg, object V1, object V2, object V3)
{ VT66 VLEX66 CLSR66
	lex0[0]=V2;                               /*  CONTEXT         */
TTL:
	{object V4;
	object V5;
	V4= Cnil;
	V5= Cnil;
	{object V6= CAR((V1));
	if((V6!= VV[52])
	&& (V6!= VV[59]))goto L642;
	{register object V7;
	object V8;                                /*  FN              */
	V7= CADR((V1));
	V8= Cnil;
L646:
	if(!((V7)==Cnil)){
	goto L647;}
	goto L641;
L647:
	V8= CAR((V7));
	V4= CONS((V8),(V4));
	V7= CDR((V7));
	goto L646;
	}
L642:
	if((V6!= VV[65]))goto L657;
	{register object V10;
	register object V11;                      /*  MAC             */
	V10= CADR((V1));
	V11= Cnil;
L661:
	if(!((V10)==Cnil)){
	goto L662;}
	goto L641;
L662:
	V11= CAR((V10));
	{object V13= CAR((V11));
	{object V14= CADR((V11));
	{object V15= CDDR((V11));
	Lstring(1,CAR((V11)))                     /*  STRING          */;
	L7(3,V14,V15,VALUES(0))                   /*  CONVERT-MACRO-TO-LAMBDA*/;
	V5= CONS(list(2,V13,VALUES(0)),(V5));}}}
	V10= CDR((V10));
	goto L661;
	}
L657:
	FEerror("The ECASE key value ~s is illegal.",1,V6);}
L641:
	{object V6;
	L3(3,(V3),(V4),(V5))                      /*  WITH-AUGMENTED-ENVIRONMENT-INTERNAL*/;
	V6= VALUES(0);
	lex0[1]=V6;                               /*  NEW-ENV         */
	{object V7= CAR((V1));
	{object V8= CDR((V1));
	LC66(lex0,1,CADR((V1)))                   /*  WALK-DEFINITIONS*/;
	T0= VALUES(0);
	{object V9= CDDR((V1));
	VALUES(0) = (VV[147]->s.s_gfdef);
	L39(3,V9,VALUES(0),lex0[1])               /*  WALK-DECLARATIONS*/;
	L35(3,V8,T0,VALUES(0))                    /*  RECONS          */;
	RETURN(L35(3,(V1),V7,VALUES(0))           /*  RECONS          */);}}}
	}
	}
}
/*	local function WALK-DEFINITIONS                               */
static LC66(object *lex0,int narg, object V1)
{ VT67 VLEX67 CLSR67
TTL:
	if(((V1))!=Cnil){
	goto L680;}
	VALUES(0) = Cnil;
	RETURN(1);
L680:
	L56(3,CAR((V1)),lex0[0],lex0[1])          /*  WALK-LAMBDA     */;
	T0= VALUES(0);
	LC66(lex0,1,CDR((V1)))                    /*  WALK-DEFINITIONS*/;
	RETURN(L35(3,(V1),T0,VALUES(0))           /*  RECONS          */);
}
/*	function definition for WALK-IF                               */
static L67(int narg, object V1, object V2, object V3)
{ VT68 VLEX68 CLSR68
TTL:
	{object V4;                               /*  PREDICATE       */
	object V5;
	object V6;                                /*  ARM1            */
	object V7;
	object V8;                                /*  ARM2            */
	V5= CADR((V1));
	V7= CADDR((V1));
	if((CDDDDR((V1)))==Cnil){
	goto L688;}
	(*LK1)(3,VV[117],(V1),MAKE_FIXNUM(length(CDR((V1)))))/*  WARN */;
	V8= CONS(VV[75],CDDDR((V1)));
	goto L686;
L688:
	V8= CADDDR((V1));
L686:
	V4= V5;
	V6= V7;
	(*LK0)(3,(V4),(V2),(V3))                  /*  WALK-FORM-INTERNAL*/;
	T0= VALUES(0);
	(*LK0)(3,(V6),(V2),(V3))                  /*  WALK-FORM-INTERNAL*/;
	T1= VALUES(0);
	(*LK0)(3,(V8),(V2),(V3))                  /*  WALK-FORM-INTERNAL*/;
	RETURN(L36(5,(V1),VV[57],T0,T1,VALUES(0)) /*  RELIST          */);
	}
}
static LKF4(int narg, ...) {TRAMPOLINK(VV[157],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[154],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[132],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[200],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[143],&LK0);}
