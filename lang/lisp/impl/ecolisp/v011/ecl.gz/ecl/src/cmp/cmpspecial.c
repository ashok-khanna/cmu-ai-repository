
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "cmpspecial.h"
init_cmpspecial(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_cmpspecial; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	MF0(VV[53],L1);
	MF0(VV[58],L2);
	MF0(VV[59],L3);
	MF0(VV[57],L4);
	MF0(VV[60],L5);
	MF0(VV[61],L6);
	MF0(VV[65],L7);
	MF0(VV[54],L8);
	MF0(VV[56],L9);
	MF0(VV[66],L10);
	MF0(VV[67],L11);
	MF0(VV[63],L12);
	MF0(VV[64],L13);
	putprop(VV[0],VV[53],VV[52]);
	putprop(VV[23],VV[54],VV[52]);
	putprop(VV[23],VV[56],VV[55]);
	putprop(VV[7],VV[57],VV[52]);
	putprop(VV[1],VV[58],VV[52]);
	putprop(VV[6],VV[59],VV[52]);
	putprop(VV[9],VV[60],VV[52]);
	putprop(VV[9],VV[61],VV[55]);
	putprop(VV[40],VV[63],VV[62]);
	putprop(VV[42],VV[64],VV[62]);
}
/*	function definition for C1QUOTE                               */
static L1(int narg, object V1)
{ VT3 VLEX3 CLSR3
TTL:
	if(!((V1)==Cnil)){
	goto L11;}
	(*LK0)(3,VV[0],MAKE_FIXNUM(1),MAKE_FIXNUM(0))/*  TOO-FEW-ARGS */;
L11:
	if(CDR((V1))==Cnil){
	goto L14;}
	(*LK1)(3,VV[0],MAKE_FIXNUM(1),MAKE_FIXNUM(length((V1))))/*  TOO-MANY-ARGS*/;
L14:
	RETURN((*LK2)(2,CAR((V1)),Ct)             /*  C1CONSTANT-VALUE*/);
}
/*	function definition for C1EVAL-WHEN                           */
static L2(int narg, object V1)
{ VT4 VLEX4 CLSR4
TTL:
	if(!((V1)==Cnil)){
	goto L17;}
	(*LK0)(3,VV[1],MAKE_FIXNUM(1),MAKE_FIXNUM(0))/*  TOO-FEW-ARGS */;
L17:
	{register object V2;
	object V3;                                /*  SITUATION       */
	V2= CAR((V1));
	V3= Cnil;
L23:
	if(!((V2)==Cnil)){
	goto L24;}
	RETURN((*LK3)(0)                          /*  C1NIL           */);
L24:
	V3= CAR((V2));
	{object V5;
	if((memql((V3),VV[2]))==Cnil){
	goto L31;}
	RETURN((*LK4)(1,CDR((V1)))                /*  C1PROGN         */);
L31:
	if((memql((V3),VV[3]))==Cnil){
	goto L34;}
	goto L29;
L34:
	(*LK5)(2,VV[4],(V3))                      /*  CMPERR          */;
	}
L29:
	V2= CDR((V2));
	goto L23;
	}
}
/*	function definition for C1DECLARE                             */
static L3(int narg, object V1)
{ VT5 VLEX5 CLSR5
TTL:
	RETURN((*LK5)(2,VV[5],CONS(VV[6],(V1)))   /*  CMPERR          */);
}
/*	function definition for C1THE                                 */
static L4(int narg, object V1)
{ VT6 VLEX6 CLSR6
TTL:
	{register object V2;                      /*  INFO            */
	register object V3;                       /*  FORM            */
	register object V4;                       /*  TYPE            */
	V2= Cnil;
	V3= Cnil;
	V4= Cnil;
	if((V1)==Cnil){
	goto L43;}
	if(!(CDR((V1))==Cnil)){
	goto L42;}
L43:
	(*LK0)(3,VV[7],MAKE_FIXNUM(2),MAKE_FIXNUM(length((V1))))/*  TOO-FEW-ARGS*/;
L42:
	if(CDDR((V1))==Cnil){
	goto L47;}
	(*LK1)(3,VV[7],MAKE_FIXNUM(2),MAKE_FIXNUM(length((V1))))/*  TOO-MANY-ARGS*/;
L47:
	(*LK6)(1,CADR((V1)))                      /*  C1EXPR          */;
	V3= VALUES(0);
	(*LK7)(1,CADR((V3)))                      /*  COPY-INFO       */;
	V2= VALUES(0);
	(*LK8)(1,CAR((V1)))                       /*  TYPE-FILTER     */;
	T0= VALUES(0);
	(*LK9)(2,T0,((V2))->v.v_self[3])          /*  TYPE-AND        */;
	V4= VALUES(0);
	if(((V4))!=Cnil){
	goto L57;}
	(*LK10)(2,VV[8],CONS(VV[7],(V1)))         /*  CMPWARN         */;
	V4= Ct;
L57:
	elt_set((V2),3,(V4));
	CAR(CDR((V3))) = (V2);
	VALUES(0) = (V3);
	RETURN(1);
	}
}
/*	function definition for C1COMPILER-LET                        */
static L5(int narg, object V1)
{ VT7 VLEX7 CLSR7
TTL:
	{register object V2;                      /*  SYMBOLS         */
	register object V3;                       /*  VALUES          */
	V2= Cnil;
	V3= Cnil;
	if(!((V1)==Cnil)){
	goto L67;}
	(*LK0)(3,VV[9],MAKE_FIXNUM(1),MAKE_FIXNUM(0))/*  TOO-FEW-ARGS */;
L67:
	{register object V4;
	register object V5;                       /*  SPEC            */
	V4= CAR((V1));
	V5= Cnil;
L74:
	if(!((V4)==Cnil)){
	goto L75;}
	goto L70;
L75:
	V5= CAR((V4));
	if(!(type_of((V5))==t_cons)){
	goto L82;}
	if(!(type_of(CAR((V5)))==t_symbol)){
	goto L85;}
	if(CDR((V5))==Cnil){
	goto L84;}
	if(CDDR((V5))==Cnil){
	goto L84;}
L85:
	(*LK5)(2,VV[10],(V5))                     /*  CMPERR          */;
L84:
	V2= CONS(CAR((V5)),(V2));
	if(!(CDR((V5))==Cnil)){
	goto L96;}
	VALUES(0) = Cnil;
	goto L94;
L96:
	Leval(1,CADR((V5)))                       /*  EVAL            */;
L94:
	V3= CONS(VALUES(0),(V3));
	goto L80;
L82:
	if(!(type_of((V5))==t_symbol)){
	goto L99;}
	V2= CONS((V5),(V2));
	V3= CONS(Cnil,(V3));
	goto L80;
L99:
	(*LK5)(2,VV[11],(V5))                     /*  CMPERR          */;
L80:
	V4= CDR((V4));
	goto L74;
	}
L70:
	V2= nreverse((V2));
	V3= nreverse((V3));
	{object V5,V6;
	bds_ptr V4=bds_top;
	V5= (V2);
	V6= (V3);
	while(!endp(V5)) {
	if(endp(V6))bds_bind(CAR(V5),OBJNULL);
	else{bds_bind(CAR(V5),CAR(V6));
	V6=CDR(V6);}
	V5=CDR(V5);}
	(*LK4)(1,CDR((V1)))                       /*  C1PROGN         */;
	V1= VALUES(0);
	bds_unwind(V4);}
	VALUES(0) = list(5,VV[9],CADR((V1)),(V2),(V3),(V1));
	RETURN(1);
	}
}
/*	function definition for C2COMPILER-LET                        */
static L6(int narg, object V1, object V2, object V3)
{ VT8 VLEX8 CLSR8
TTL:
	{object V5,V6;
	bds_ptr V4=bds_top;
	V5= (V1);
	V6= (V2);
	while(!endp(V5)) {
	if(endp(V6))bds_bind(CAR(V5),OBJNULL);
	else{bds_bind(CAR(V5),CAR(V6));
	V6=CDR(V6);}
	V5=CDR(V5);}
	{int V4;
	V4=(*LK11)(1,(V3))                        /*  C2EXPR          */;
	bds_unwind(V4);
	RETURN(V4);}}
}
/*	function definition for C1LOCAL-CLOSURE                       */
static L7(int narg, object V1)
{ VT9 VLEX9 CLSR9
TTL:
	{object V2;                               /*  CCB             */
	object V3;                                /*  CLB             */
	V2= Cnil;
	V3= Cnil;
	{register object V4;
	register object V5;                       /*  FUN             */
	V4= (VV[12]->s.s_dbind);
	V5= Cnil;
L122:
	if(!((V4)==Cnil)){
	goto L123;}
	VALUES(0) = Cnil;
	RETURN(1);
L123:
	V5= CAR((V4));
	if(!(((V5))==(VV[13]))){
	goto L130;}
	V2= Ct;
	goto L128;
L130:
	if(!(((V5))==(VV[14]))){
	goto L134;}
	V3= Ct;
	goto L128;
L134:
	if(!(type_of((V5))==t_cons)){
	goto L138;}
	if(!((CAR((V5)))==((V1)))){
	goto L128;}
	VALUES(0) = CADR((V5));
	RETURN(1);
L138:
	if(!((((V5))->v.v_self[0])==((V1)))){
	goto L128;}
	elt_set((V5),2,Ct);
	elt_set((V5),1,number_plus(((V5))->v.v_self[1],MAKE_FIXNUM(1)));
	{register object V8;                      /*  VAR             */
	VALUES(0) = ((V5))->v.v_self[8];
	if(VALUES(0)==Cnil)goto L147;
	V8= VALUES(0);
	goto L146;
L147:
	(*LK12)(4,VV[15],(V1),VV[16],VV[17])      /*  MAKE-VAR        */;
	V8= elt_set((V5),8,VALUES(0));
L146:
	if(((V2))==Cnil){
	goto L152;}
	elt_set((V8),2,Ct);
	elt_set((V8),4,VV[18]);
	goto L150;
L152:
	if(((V3))==Cnil){
	goto L150;}
	elt_set((V8),5,VV[19]);
	elt_set((V8),4,VV[18]);
L150:
	elt_set((V8),1,number_plus(((V8))->v.v_self[1],MAKE_FIXNUM(1)));
	{object V10= CONS((V8),Cnil);
	(*LK13)(4,VV[21],V10,VV[22],CONS((V8),Cnil))/*  MAKE-INFO     */;
	T0= VALUES(0);
	VALUES(0) = list(3,VV[20],T0,CONS((V8),Cnil));
	RETURN(1);}
	}
L128:
	V4= CDR((V4));
	goto L122;
	}
	}
}
/*	function definition for C1FUNCTION                            */
static L8(int narg, object V1)
{ VT10 VLEX10 CLSR10
	bds_check;
TTL:
	{object V2;                               /*  FD              */
	V2= Cnil;
	if(!((V1)==Cnil)){
	goto L164;}
	(*LK0)(3,VV[23],MAKE_FIXNUM(1),MAKE_FIXNUM(0))/*  TOO-FEW-ARGS*/;
L164:
	if(CDR((V1))==Cnil){
	goto L167;}
	(*LK1)(3,VV[23],MAKE_FIXNUM(1),MAKE_FIXNUM(length((V1))))/*  TOO-MANY-ARGS*/;
L167:
	{register object V3;                      /*  FUN             */
	V3= CAR((V1));
	siLsetf_namep(1,(V3))                     /*  SETF-NAMEP      */;
	if(VALUES(0)==Cnil){
	goto L173;}
	V3= Ct;
	goto L172;
L173:
L172:
	if(!(type_of((V3))==t_symbol)){
	goto L176;}
	L7(1,(V3))                                /*  C1LOCAL-CLOSURE */;
	V2= VALUES(0);
	if(((V2))==Cnil){
	goto L179;}
	if(!((VV[20])==(CAR((V2))))){
	goto L179;}
	VALUES(0) = (V2);
	RETURN(1);
L179:
	(*LK13)(2,VV[24],((getf((V3)->s.s_plist,VV[25],Cnil))==Cnil?Ct:Cnil))/*  MAKE-INFO*/;
	VALUES(0) = list(5,VV[23],VALUES(0),VV[26],Cnil,(V3));
	RETURN(1);
L176:
	if(!(type_of((V3))==t_cons)){
	goto L186;}
	if(!((CAR((V3)))==(VV[27]))){
	goto L186;}
	if(!(CDR((V3))==Cnil)){
	goto L190;}
	(*LK5)(2,VV[28],(V3))                     /*  CMPERR          */;
L190:
	{register object V4;                      /*  FUNOB           */
	object V5;                                /*  INFO            */
	object V6;                                /*  CLOSURE         */
	register object V7;                       /*  BODY            */
	object V8;                                /*  FUN             */
	{object V9;
	object V10;
	object V11;
	object V12;
	V9= CONS(VV[13],(VV[29]->s.s_dbind));
	V10= CONS(VV[13],(VV[12]->s.s_dbind));
	V11= CONS(VV[13],(VV[30]->s.s_dbind));
	V12= CONS(VV[13],(VV[31]->s.s_dbind));
	bds_bind(VV[29],V9);                      /*  *VARS*          */
	bds_bind(VV[12],V10);                     /*  *FUNS*          */
	bds_bind(VV[30],V11);                     /*  *BLOCKS*        */
	bds_bind(VV[31],V12);                     /*  *TAGS*          */
	(*LK14)(1,CDR((V3)))                      /*  C1LAMBDA-EXPR   */;
	V4= VALUES(0);
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	}
	V5= CADR((V4));
	(*LK15)(1,(V4))                           /*  CLOSURE-P       */;
	V6= VALUES(0);
	V7= CDDR((V3));
	if(!(type_of((V7))==t_cons)){
	goto L204;}
	if((CDR((V7)))!=Cnil){
	goto L204;}
	if(!(type_of(CAR((V7)))==t_cons)){
	goto L204;}
	if(!((VV[32])==(CAR(CAR((V7)))))){
	goto L204;}
	T0= CONS(CADR(CAR((V7))),Cnil);
	goto L202;
L204:
	T0= Cnil;
L202:
	L11(1,(V4))                               /*  GEN-INIT-KEYWORDS*/;
	(*LK16)(6,VV[15],T0,VV[33],VALUES(0),VV[34],(V6))/*  MAKE-FUN */;
	V8= VALUES(0);
	if(((V6))==Cnil){
	goto L214;}
	VALUES(0) = list(5,VV[23],(V5),VV[35],(V4),(V8));
	RETURN(1);
L214:
	(VV[36]->s.s_dbind)= CONS(list(3,VV[37],(V4),(V8)),(VV[36]->s.s_dbind));
	VALUES(0) = list(5,VV[23],(V5),VV[38],(V4),(V8));
	RETURN(1);
	}
L186:
	RETURN((*LK5)(2,VV[39],(V3))              /*  CMPERR          */);
	}
	}
}
/*	function definition for C2FUNCTION                            */
static L9(int narg, object V1, object V2, object V3)
{ VT11 VLEX11 CLSR11
TTL:
	if(((V1)!= VV[26]))goto L218;
	(*LK17)(1,(V3))                           /*  ADD-SYMBOL      */;
	RETURN((*LK18)(1,list(2,VV[40],VALUES(0)))/*  UNWIND-EXIT     */);
L218:
	if(((V1)!= VV[35]))goto L220;
	elt_set((V3),7,(number_compare((VV[41]->s.s_dbind),MAKE_FIXNUM(0))>0?Ct:Cnil));
	L10(3,MAKE_FIXNUM(0),(V3),(V2))           /*  NEW-LOCAL       */;
	RETURN((*LK18)(1,list(2,VV[42],(V3)))     /*  UNWIND-EXIT     */);
L220:
	if(((V1)!= VV[38]))goto L223;
	RETURN((*LK18)(1,((V3))->v.v_self[8])     /*  UNWIND-EXIT     */);
L223:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for NEW-LOCAL                             */
static L10(int narg, object V1, object V2, object V3)
{ VT12 VLEX12 CLSR12
TTL:
	{object V4;                               /*  PREVIOUS        */
	object V5;
	object V6;                                /*  CLOSURE         */
	{register object V7;
	object V8;                                /*  LOCAL           */
	V7= (VV[43]->s.s_dbind);
	V8= Cnil;
L228:
	if(!((V7)==Cnil)){
	goto L229;}
	V5= Cnil;
	goto L224;
L229:
	V8= CAR((V7));
	(*LK19)(2,(V3),CADDR((V8)))               /*  SIMILAR         */;
	if(VALUES(0)==Cnil){
	goto L234;}
	V5= CADR((V8));
	goto L224;
L234:
	V7= CDR((V7));
	goto L228;
	}
L224:
	if((((V2))->v.v_self[7])==Cnil){
	goto L242;}
	V6= VV[35];
	goto L240;
L242:
	V6= Cnil;
L240:
	V4= V5;
	if(((V4))==Cnil){
	goto L245;}
	if(((V6))==Cnil){
	goto L249;}
	(*LK20)(1,VV[44])                         /*  CMPNOTE         */;
	goto L247;
L249:
	(*LK20)(2,VV[45],((V2))->v.v_self[0])     /*  CMPNOTE         */;
L247:
	elt_set((V2),4,((V4))->v.v_self[4]);
	VALUES(0) = (V4);
	RETURN(1);
L245:
	if((((V2))->v.v_self[2])==Cnil){
	goto L256;}
	VALUES(0) = MAKE_FIXNUM(0);
	goto L254;
L256:
	VALUES(0) = (V1);
L254:
	elt_set((V2),5,VALUES(0));
	elt_set((V2),6,(VV[41]->s.s_dbind));
	(VV[43]->s.s_dbind)= CONS(list(3,(V6),(V2),(V3)),(VV[43]->s.s_dbind));
	if(((V6))==Cnil){
	goto L260;}
	(VV[46]->s.s_dbind)= CONS((V2),(VV[46]->s.s_dbind));
L260:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for GEN-INIT-KEYWORDS                     */
static L11(int narg, object V1)
{ VT13 VLEX13 CLSR13
TTL:
	{object V2;                               /*  KEYS            */
	object V3;                                /*  CFUN            */
	Lfifth(1,CADDR((V1)))                     /*  FIFTH           */;
	V2= VALUES(0);
	(VV[47]->s.s_dbind)= number_plus((VV[47]->s.s_dbind),MAKE_FIXNUM(1));
	V3= (VV[47]->s.s_dbind);
	if(((V2))==Cnil){
	goto L267;}
	(VV[36]->s.s_dbind)= CONS(list(4,VV[48],MAKE_FIXNUM(length((V2))),(V3),(V1)),(VV[36]->s.s_dbind));
L267:
	VALUES(0) = (V3);
	RETURN(1);
	}
}
/*	function definition for WT-SYMBOL-FUNCTION                    */
static L12(int narg, object V1)
{ VT14 VLEX14 CLSR14
TTL:
	if(((VV[49]->s.s_dbind))==Cnil){
	goto L272;}
	princ_str("symbol_function(VV[",symbol_value(VV[50]));
	(*LK21)(1,(V1))                           /*  WT1             */;
	princ_str("])",symbol_value(VV[50]));
	VALUES(0) = Cnil;
	RETURN(1);
L272:
	princ_str("(VV[",symbol_value(VV[50]));
	(*LK21)(1,(V1))                           /*  WT1             */;
	princ_str("]->s.s_gfdef)",symbol_value(VV[50]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-MAKE-CLOSURE                       */
static L13(int narg, object V1)
{ VT15 VLEX15 CLSR15
TTL:
	{object V2;                               /*  CFUN            */
	V2= ((V1))->v.v_self[4];
	if((((V1))->v.v_self[7])==Cnil){
	goto L283;}
	princ_str("make_cclosure(LC",symbol_value(VV[50]));
	(*LK21)(1,(V2))                           /*  WT1             */;
	princ_str(",env",symbol_value(VV[50]));
	(*LK21)(1,(VV[51]->s.s_dbind))            /*  WT1             */;
	goto L281;
L283:
	princ_str("make_cfun(LC",symbol_value(VV[50]));
	(*LK21)(1,(V2))                           /*  WT1             */;
	princ_str(",Cnil",symbol_value(VV[50]));
L281:
	princ_str(",&Cblock)",symbol_value(VV[50]));
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
static LKF21(int narg, ...) {TRAMPOLINK(VV[89],&LK21);}
static LKF20(int narg, ...) {TRAMPOLINK(VV[88],&LK20);}
static LKF19(int narg, ...) {TRAMPOLINK(VV[87],&LK19);}
static LKF18(int narg, ...) {TRAMPOLINK(VV[86],&LK18);}
static LKF17(int narg, ...) {TRAMPOLINK(VV[85],&LK17);}
static LKF16(int narg, ...) {TRAMPOLINK(VV[84],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[83],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[82],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[81],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[80],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[79],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[78],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[77],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[76],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[75],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[74],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[73],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[72],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[71],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[70],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[69],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[68],&LK0);}
