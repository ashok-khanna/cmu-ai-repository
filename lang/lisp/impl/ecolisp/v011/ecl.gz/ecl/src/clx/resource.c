
#include "resource.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	funcall(2,VV[93]->s.s_gfdef,VV[0])        /*  FIND-CLASS      */;
	funcall(9,VV[94]->s.s_gfdef,VALUES(0),VV[1],VV[2],VV[3],Cnil,VV[4],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[93]->s.s_gfdef,VV[1])        /*  FIND-CLASS      */;
	VV[95] = make_cfun(LC1,Cnil,&Cblock);
	VALUES(0) = VV[95];
	funcall(8,VV[96]->s.s_gfdef,VV[5],Cnil,VV[6],VV[7],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	funcall(13,VV[97]->s.s_gfdef,VV[1],VV[9],Cnil,Cnil,VV[10],VV[11],Cnil,Cnil,VV[12],VV[13],MAKE_FIXNUM(4),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[98],L2,4,L2keys);
	(void)putprop(VV[98],VV[Vdeb98],VV[99]);
	MF0(VV[12],L3);
	(void)putprop(VV[12],VV[Vdeb12],VV[99]);
	MF0(VV[100],L5);
	(void)putprop(VV[100],VV[Vdeb100],VV[99]);
	MF0(VV[101],L6);
	(void)putprop(VV[101],VV[Vdeb101],VV[99]);
	MF0(VV[102],L7);
	(void)putprop(VV[102],VV[Vdeb102],VV[99]);
	MF0(VV[103],L8);
	(void)putprop(VV[103],VV[Vdeb103],VV[99]);
	siLAmake_special(1,VV[21])                /*  *MAKE-SPECIAL   */;
	(VV[21]->s.s_dbind)= Cnil;
	MF0(VV[104],L9);
	(void)putprop(VV[104],VV[Vdeb104],VV[99]);
	MF0(VV[105],L10);
	(void)putprop(VV[105],VV[Vdeb105],VV[99]);
	MF0(VV[106],L11);
	(void)putprop(VV[106],VV[Vdeb106],VV[99]);
	MF0(VV[107],L12);
	(void)putprop(VV[107],VV[Vdeb107],VV[99]);
	MF0(VV[108],L13);
	(void)putprop(VV[108],VV[Vdeb108],VV[99]);
	MF0(VV[109],L14);
	(void)putprop(VV[109],VV[Vdeb109],VV[99]);
	MF0(VV[110],L15);
	(void)putprop(VV[110],VV[Vdeb110],VV[99]);
	MF0(VV[111],L16);
	(void)putprop(VV[111],VV[Vdeb111],VV[99]);
	MF0(VV[112],L17);
	(void)putprop(VV[112],VV[Vdeb112],VV[99]);
	VV[36]->s.s_stype=(short)stp_special;
	VV[113] = make_cfun(LC19,Cnil,&Cblock);
	MF0(VV[114],L18);
	(void)putprop(VV[114],VV[Vdeb114],VV[99]);
	MF0(VV[115],L20);
	(void)putprop(VV[115],VV[Vdeb115],VV[99]);
	MF0(VV[116],L21);
	(void)putprop(VV[116],VV[Vdeb116],VV[99]);
	MF0(VV[117],L22);
	(void)putprop(VV[117],VV[Vdeb117],VV[99]);
	VV[118] = make_cfun(LC25,Cnil,&Cblock);
	MF0(VV[119],L24);
	(void)putprop(VV[119],VV[Vdeb119],VV[99]);
	MF0(VV[120],L26);
	(void)putprop(VV[120],VV[Vdeb120],VV[99]);
	(void)putprop(VV[121],VV[53],siSpretty_print_format);
	
	MM0(VV[121],L27);
	MF0key(VV[122],L28,3,L28keys);
	(void)putprop(VV[122],VV[Vdeb122],VV[99]);
	MF0(VV[123],L29);
	(void)putprop(VV[123],VV[Vdeb123],VV[99]);
	VV[124] = make_cfun(LC31,Cnil,&Cblock);
	MF0key(VV[125],L30,3,L30keys);
	(void)putprop(VV[125],VV[Vdeb125],VV[99]);
	MF0key(VV[126],L32,3,L32keys);
	(void)putprop(VV[126],VV[Vdeb126],VV[99]);
	MF0key(VV[127],L33,3,L33keys);
	(void)putprop(VV[127],VV[Vdeb127],VV[99]);
	MF0key(VV[87],L34,4,L34keys);
	(void)putprop(VV[87],VV[84],siSfunction_documentation);
	
	(void)putprop(VV[87],VV[Vdeb87],VV[99]);
	MF0key(VV[88],L35,4,L35keys);
	(void)putprop(VV[88],VV[86],siSfunction_documentation);
	
	(void)putprop(VV[88],VV[Vdeb88],VV[99]);
	putprop(VV[87],VV[88],VV[89]);
	remprop(VV[87],VV[90]);
	remprop(VV[87],VV[91]);
	putprop(VV[87],Cnil,VV[92]);
	MF0(VV[128],L36);
	(void)putprop(VV[128],VV[Vdeb128],VV[99]);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	local function CLOSURE                                        */
static LC31(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT3 VLEX3 CLSR3
	if(((V5))==Cnil){
	goto L21;}
	funcall(3,(V5),(V1),(V2));
	if(VALUES(0)==Cnil){
	goto L18;}
	goto L19;
L21:
	if(((V6))==Cnil){
	goto L24;}
	funcall(3,(V6),(V1),(V2));
	if(!((VALUES(0))==Cnil)){
	goto L18;}
	goto L19;
L24:
L19:
	{volatile object V7;                      /*  PREVIOUS        */
	V7= CAR((V1));
	princ((V7),(V3));
	{volatile object V8;
	volatile object V9;                       /*  NAME            */
	V8= CDR((V1));
	V9= Cnil;
L33:
	if(!((V8)==Cnil)){
	goto L34;}
	goto L27;
L34:
	V9= CAR((V8));
	L10(2,(V9),VV[73])                        /*  STRINGABLE-EQUAL*/;
	if(VALUES(0)!=Cnil){
	goto L39;}
	L10(2,(V7),VV[74])                        /*  STRINGABLE-EQUAL*/;
	if(VALUES(0)!=Cnil){
	goto L39;}
	Lwrite_char(2,code_char('\56'),(V3))      /*  WRITE-CHAR      */;
L39:
	V7= (V9);
	princ((V9),(V3));
	V8= CDR((V8));
	goto L33;
	}
	}
L27:
	Lwrite_string(2,VV[75],(V3))              /*  WRITE-STRING    */;
	funcall(3,(V4),(V2),(V3));
	VALUES(0) = terpri((V3));
	RETURN(1);
L18:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC25(int narg, object V1, object V2, object V3)
{ VT4 VLEX4 CLSR4
	RETURN(L11(3,(V3),(V1),(V2))              /*  ADD-RESOURCE    */);
}
/*	local function CLOSURE                                        */
static LC19(int narg, object V1)
{ VT5 VLEX5 CLSR5
	VALUES(0) = ((V1))->in.in_slots[2];
	if(VALUES(0)==Cnil)goto L52;
	RETURN(1);
L52:
	VALUES(0) = ((V1))->in.in_slots[3];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC1(int narg, object V1, object V2)
{ VT6 VLEX6 CLSR6
	RETURN(L3(3,(V1),(V2),(VV[8]->s.s_dbind)) /*  PRINT-RESOURCE-DATABASE*/);
}
/*	function definition for MAKE-RESOURCE-DATABASE-INTERNAL       */
static L2(int narg, ...)
{ VT7 VLEX7 CLSR7
	{object V1;
	object V2;
	object V3;
	object V4;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[8];
	parse_key(narg,args,4,L2keys,keyvars,OBJNULL,FALSE);
	V1= keyvars[0];
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	}
	(*LK0)(1,VV[1])                           /*  FIND-CLASS      */;
	RETURN(siLmake_structure(5,VALUES(0),(V1),(V2),(V3),(V4))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for PRINT-RESOURCE-DATABASE               */
static L3(int narg, object V1, object V2, object V3)
{ VT8 VLEX8 CLSR8
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(V1,env0));            /*  DATABASE        */
	CLV1=&CAR(env0=CONS(V2,env0));            /*  STREAM          */
	{ object V4;
	V4= make_cclosure(LC4,env0,&Cblock);
	RETURN((*LK1)(5,*CLV0,*CLV1,Ct,Cnil,(V4)) /*  PRINT-UNREADABLE-OBJECT-FUNCTION*/);
	}
}
/*	closure .PRINT-UNREADABLE-OBJECT-BODY.                        */
static LC4(int narg, object env0)
{ VT9 VLEX9 CLSR9
	narg--;
	{object scan=env0;
	CLV1= &CAR(scan);                         /*  STREAM          */ scan=CDR(scan);
	CLV0= &CAR(scan);                         /*  DATABASE        */}
TTL:
	(*LK2)(1,*CLV0)                           /*  RESOURCE-DATABASE-NAME*/;
	Lwrite_string(2,coerce_to_string(VALUES(0)),*CLV1)/*  WRITE-STRING*/;
	if(((*CLV0)->in.in_slots[1])==Cnil){
	goto L58;}
	Lwrite_string(2,VV[14],*CLV1)             /*  WRITE-STRING    */;
	VALUES(0) = prin1((*CLV0)->in.in_slots[1],*CLV1);
	RETURN(1);
L58:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for MAKE-RESOURCE-DATABASE                */
static L5(int narg)
{ VT10 VLEX10 CLSR10
TTL:
	RETURN(L2(4,VV[15],VV[16],VV[17],MAKE_FIXNUM(0))/*  MAKE-RESOURCE-DATABASE-INTERNAL*/);
}
/*	function definition for RESOURCE-DATABASE-TIMESTAMP           */
static L6(int narg, object V1)
{ VT11 VLEX11 CLSR11
TTL:
	VALUES(0) = ((V1))->in.in_slots[1];
	RETURN(1);
}
/*	function definition for INCF-RESOURCE-DATABASE-TIMESTAMP      */
static L7(int narg, object V1)
{ VT12 VLEX12 CLSR12
TTL:
	{object V2;                               /*  TIMESTAMP       */
	V2= ((V1))->in.in_slots[1];
	if(!(number_compare((V2),MAKE_FIXNUM(536870911))==0)){
	goto L64;}
	VALUES(0) = MAKE_FIXNUM(-536870912);
	goto L62;
L64:
	VALUES(0) = one_plus((V2));
L62:
	((V1))->in.in_slots[1]= VALUES(0);
	VALUES(0) = VALUES(0);
	RETURN(1);
	}
}
/*	function definition for PRINT-DB                              */
static L8(int narg, object V1, ...)
{ VT13 VLEX13 CLSR13
	{int i=1;
	volatile object V2;
	volatile object V3;
	va_list args; va_start(args, V1);
	if (i==narg) goto L66;
	V2= va_arg(args, object);
	i++;
	if (i==narg) goto L67;
	V3= va_arg(args, object);
	i++;
	goto L68;
L66:
	V2= MAKE_FIXNUM(0);
L67:
	V3= Cnil;
L68:
	(*LK2)(1,(V1))                            /*  RESOURCE-DATABASE-NAME*/;
	T0= VALUES(0);
	Lformat(6,Ct,VV[18],(V2),T0,(((V3))==(VV[19])?Ct:Cnil),((V1))->in.in_slots[1])/*  FORMAT*/;
	if((((V1))->in.in_slots[2])==Cnil){
	goto L73;}
	{volatile object V4;
	volatile object V5;                       /*  TIGHT           */
	V4= ((V1))->in.in_slots[2];
	V5= Cnil;
L79:
	if(!((V4)==Cnil)){
	goto L80;}
	goto L73;
L80:
	V5= CAR((V4));
	L8(3,(V5),number_plus(MAKE_FIXNUM(2),(V2)),VV[20])/*  PRINT-DB*/;
	V4= CDR((V4));
	goto L79;
	}
L73:
	if((((V1))->in.in_slots[3])==Cnil){
	goto L90;}
	{volatile object V4;
	volatile object V5;                       /*  LOOSE           */
	V4= ((V1))->in.in_slots[3];
	V5= Cnil;
L95:
	if(!((V4)==Cnil)){
	goto L96;}
	VALUES(0) = Cnil;
	RETURN(1);
L96:
	V5= CAR((V4));
	L8(3,(V5),number_plus(MAKE_FIXNUM(2),(V2)),VV[19])/*  PRINT-DB*/;
	V4= CDR((V4));
	goto L95;
	}
L90:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for RESOURCE-KEY                          */
static L9(int narg, object V1)
{ VT14 VLEX14 CLSR14
TTL:
	{object V2;
	V2= (V1);
	(*LK3)(2,(V2),VV[22])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L106;}
	if(!((type_of((V1))==t_symbol&&((V1))->s.s_hpack==keyword_package))){
	goto L109;}
	VALUES(0) = (V1);
	RETURN(1);
L109:
	RETURN((*LK4)(1,symbol_name((V1)))        /*  KINTERN         */);
L106:
	(*LK3)(2,(V2),VV[23])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L112;}
	if(((VV[21]->s.s_dbind))==Cnil){
	goto L114;}
	Lstring_upcase(1,(V1))                    /*  STRING-UPCASE   */;
	V1= VALUES(0);
L114:
	RETURN((*LK4)(1,(V1))                     /*  KINTERN         */);
L112:
	(*LK5)(3,VV[24],(V2),VV[25])              /*  TYPECASE-ERROR-STRING*/;
	RETURN(Lerror(1,VALUES(0))                /*  ERROR           */);
	}
}
/*	function definition for STRINGABLE-EQUAL                      */
static L10(int narg, object V1, object V2)
{ VT15 VLEX15 CLSR15
TTL:
	{object V3;
	V3= (V1);
	(*LK3)(2,(V3),VV[23])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L120;}
	{object V4;
	V4= (V2);
	(*LK3)(2,(V4),VV[23])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L123;}
	VALUES(0) = (string_eq((V1),(V2))?Ct:Cnil);
	RETURN(1);
L123:
	(*LK3)(2,(V4),VV[22])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L126;}
	if(((VV[21]->s.s_dbind))==Cnil){
	goto L129;}
	VALUES(0) = (string_equal((V1),symbol_name((V2)))?Ct:Cnil);
	RETURN(1);
L129:
	VALUES(0) = (string_eq((V1),symbol_name((V2)))?Ct:Cnil);
	RETURN(1);
L126:
	(*LK5)(3,VV[26],(V4),VV[27])              /*  TYPECASE-ERROR-STRING*/;
	RETURN(Lerror(1,VALUES(0))                /*  ERROR           */);
	}
L120:
	(*LK3)(2,(V3),VV[22])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L133;}
	{object V5;
	V5= (V2);
	(*LK3)(2,(V5),VV[23])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L136;}
	if(((VV[21]->s.s_dbind))==Cnil){
	goto L139;}
	VALUES(0) = (string_equal(symbol_name((V1)),(V2))?Ct:Cnil);
	RETURN(1);
L139:
	VALUES(0) = (string_eq(symbol_name((V1)),(V2))?Ct:Cnil);
	RETURN(1);
L136:
	(*LK3)(2,(V5),VV[22])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L142;}
	{object V6= symbol_name((V1));
	VALUES(0) = (string_eq((V6),symbol_name((V2)))?Ct:Cnil);
	RETURN(1);}
L142:
	(*LK5)(3,VV[26],(V5),VV[28])              /*  TYPECASE-ERROR-STRING*/;
	RETURN(Lerror(1,VALUES(0))                /*  ERROR           */);
	}
L133:
	(*LK5)(3,VV[29],(V3),VV[30])              /*  TYPECASE-ERROR-STRING*/;
	RETURN(Lerror(1,VALUES(0))                /*  ERROR           */);
	}
}
/*	function definition for ADD-RESOURCE                          */
static L11(int narg, object V1, object V2, object V3)
{ VT16 VLEX16 CLSR16
TTL:
	if(((V3))!=Cnil){
	goto L146;}
	Lerror(1,VV[31])                          /*  ERROR           */;
L146:
	L7(1,(V1))                                /*  INCF-RESOURCE-DATABASE-TIMESTAMP*/;
	{volatile object V4;                      /*  LIST            */
	volatile object V5;                       /*  NAME            */
	volatile object V6;                       /*  NODE            */
	volatile object V7;                       /*  LOOSE-P         */
	V4= (V2);
	V5= CAR((V4));
	V6= (V1);
	V7= Cnil;
L155:
	if(!((V4)==Cnil)){
	goto L156;}
	((V6))->in.in_slots[1]= (V3);
	VALUES(0) = (V3);
	RETURN(1);
L156:
	L10(2,(V5),VV[32])                        /*  STRINGABLE-EQUAL*/;
	if(VALUES(0)==Cnil){
	goto L161;}
	V7= Ct;
	goto L159;
L161:
	{volatile object V9;                      /*  ENTRY           */
	if(((V7))==Cnil){
	goto L167;}
	V9= ((V6))->in.in_slots[3];
	goto L165;
L167:
	V9= ((V6))->in.in_slots[2];
L165:
L170:
	if(!((V9)==Cnil)){
	goto L171;}
	L2(2,VV[15],(V5))                         /*  MAKE-RESOURCE-DATABASE-INTERNAL*/;
	V9= VALUES(0);
	if(((V7))==Cnil){
	goto L178;}
	{register object V11;
	object V12;
	V11= (V6);
	V12= CONS((V9),((V11))->in.in_slots[3]);
	((V11))->in.in_slots[3]= (V12);
	goto L176;
	}
L178:
	{register object V13;
	object V14;
	V13= (V6);
	V14= CONS((V9),((V13))->in.in_slots[2]);
	((V13))->in.in_slots[2]= (V14);
	}
L176:
	V6= (V9);
	goto L164;
L171:
	(*LK2)(1,CAR((V9)))                       /*  RESOURCE-DATABASE-NAME*/;
	L10(2,(V5),VALUES(0))                     /*  STRINGABLE-EQUAL*/;
	if(VALUES(0)==Cnil){
	goto L185;}
	V6= CAR((V9));
	goto L164;
L185:
	V9= CDR((V9));
	goto L170;
	}
L164:
	V7= Cnil;
L159:
	V4= CDR((V4));
	V5= CAR((V4));
	goto L155;
	}
}
/*	function definition for DELETE-RESOURCE                       */
static L12(int narg, object V1, object V2)
{ VT17 VLEX17 CLSR17
TTL:
	L7(1,(V1))                                /*  INCF-RESOURCE-DATABASE-TIMESTAMP*/;
	RETURN(L13(2,(V1),(V2))                   /*  DELETE-RESOURCE-INTERNAL*/);
}
/*	function definition for DELETE-RESOURCE-INTERNAL              */
static L13(int narg, object V1, object V2)
{ VT18 VLEX18 CLSR18
TTL:
	{volatile object V3;                      /*  LIST            */
	volatile object V4;                       /*  STRING          */
	volatile object V5;                       /*  NODE            */
	volatile object V6;                       /*  LOOSE-P         */
	V3= (V2);
	V4= CAR((V3));
	V5= (V1);
	V6= Cnil;
L205:
	if(!((V3)==Cnil)){
	goto L206;}
	VALUES(0) = Cnil;
	RETURN(1);
L206:
	L10(2,(V4),VV[33])                        /*  STRINGABLE-EQUAL*/;
	if(VALUES(0)==Cnil){
	goto L211;}
	V6= Ct;
	goto L209;
L211:
	{volatile object V8;                      /*  FIRST-ENTRY     */
	volatile object V9;                       /*  ENTRY-LIST      */
	volatile object V10;                      /*  ENTRY           */
	if(((V6))==Cnil){
	goto L217;}
	V8= ((V5))->in.in_slots[3];
	goto L215;
L217:
	V8= ((V5))->in.in_slots[2];
L215:
	V9= (V8);
	V10= CAR((V9));
L222:
	if(!((V9)==Cnil)){
	goto L223;}
	VALUES(0) = Cnil;
	RETURN(1);
L223:
	(*LK2)(1,(V10))                           /*  RESOURCE-DATABASE-NAME*/;
	L10(2,(V4),VALUES(0))                     /*  STRINGABLE-EQUAL*/;
	if(VALUES(0)==Cnil){
	goto L226;}
	if((CDR((V3)))==Cnil){
	goto L230;}
	L13(2,(V10),CDR((V3)))                    /*  DELETE-RESOURCE-INTERNAL*/;
L230:
	if((((V10))->in.in_slots[3])!=Cnil){
	goto L233;}
	if((((V10))->in.in_slots[2])!=Cnil){
	goto L233;}
	if(((V6))==Cnil){
	goto L239;}
	T0= ((V5))->in.in_slots[3];
	VALUES(0) = (VV[146]->s.s_gfdef);
	(*LK6)(6,(V10),T0,VV[34],VALUES(0),VV[35],MAKE_FIXNUM(1))/*  DELETE*/;
	((V5))->in.in_slots[3]= VALUES(0);
	goto L233;
L239:
	T0= ((V5))->in.in_slots[2];
	VALUES(0) = (VV[146]->s.s_gfdef);
	(*LK6)(6,(V10),T0,VV[34],VALUES(0),VV[35],MAKE_FIXNUM(1))/*  DELETE*/;
	((V5))->in.in_slots[2]= VALUES(0);
L233:
	VALUES(0) = Ct;
	RETURN(1);
L226:
	V9= CDR((V9));
	V10= CAR((V9));
	goto L222;
	}
	V6= Cnil;
L209:
	V3= CDR((V3));
	V4= CAR((V3));
	goto L205;
	}
}
/*	function definition for GET-RESOURCE                          */
static L14(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT19 VLEX19 CLSR19
TTL:
	{object V6;                               /*  NAMES           */
	object V7;                                /*  CLASSES         */
	V6= append((V4),CONS((V2),Cnil));
	V7= append((V5),CONS((V3),Cnil));
	{object V8;                               /*  RESULT          */
	L16(4,((V1))->in.in_slots[2],((V1))->in.in_slots[3],(V6),(V7))/*  GET-ENTRY*/;
	V8= VALUES(0);
	if(((V8))==Cnil){
	goto L262;}
	VALUES(0) = ((V8))->in.in_slots[1];
	RETURN(1);
L262:
	VALUES(0) = Cnil;
	RETURN(1);
	}
	}
}
/*	function definition for GET-ENTRY-LOOKUP                      */
static L15(int narg, object V1, object V2, object V3, object V4)
{ VT20 VLEX20 CLSR20
TTL:
	{volatile object V5;
	volatile object V6;                       /*  ENTRY           */
	V5= (V1);
	V6= Cnil;
L267:
	if(!((V5)==Cnil)){
	goto L268;}
	VALUES(0) = Cnil;
	RETURN(1);
L268:
	V6= CAR((V5));
	(*LK2)(1,(V6))                            /*  RESOURCE-DATABASE-NAME*/;
	L10(2,(V2),VALUES(0))                     /*  STRINGABLE-EQUAL*/;
	if(VALUES(0)==Cnil){
	goto L273;}
	if((CDR((V3)))!=Cnil){
	goto L278;}
	VALUES(0) = (V6);
	RETURN(1);
L278:
	{register object V9;                      /*  RESULT          */
	L16(4,((V6))->in.in_slots[2],((V6))->in.in_slots[3],CDR((V3)),CDR((V4)))/*  GET-ENTRY*/;
	V9= VALUES(0);
	if(((V9))==Cnil){
	goto L273;}
	VALUES(0) = (V9);
	RETURN(1);
	}
L273:
	V5= CDR((V5));
	goto L267;
	}
}
/*	function definition for GET-ENTRY                             */
static L16(int narg, object V1, object V2, object V3, object V4)
{ VT21 VLEX21 CLSR21
TTL:
	{register object V5;                      /*  RESULT          */
	V5= Cnil;
	{volatile object V6;                      /*  NAME            */
	volatile object V7;                       /*  CLASS           */
	V6= CAR((V3));
	V7= CAR((V4));
	{volatile object V8;
	if((V1)==Cnil){
	V8= Cnil;
	goto L289;}
	L15(4,(V1),(V6),(V3),(V4))                /*  GET-ENTRY-LOOKUP*/;
	V8= VALUES(0);
L289:
	if(((V8))==Cnil){
	goto L291;}
	VALUES(0) = (V8);
	RETURN(1);
L291:
	{volatile object V9;
	if((V2)==Cnil){
	V9= Cnil;
	goto L293;}
	L15(4,(V2),(V6),(V3),(V4))                /*  GET-ENTRY-LOOKUP*/;
	V9= VALUES(0);
L293:
	if(((V9))==Cnil){
	goto L295;}
	VALUES(0) = (V9);
	RETURN(1);
L295:
	{volatile object V10;
	if((V1)==Cnil){
	V10= Cnil;
	goto L297;}
	L10(2,(V6),(V7))                          /*  STRINGABLE-EQUAL*/;
	if((VALUES(0))==Cnil){
	goto L298;}
	V10= Cnil;
	goto L297;
L298:
	L15(4,(V1),(V7),(V3),(V4))                /*  GET-ENTRY-LOOKUP*/;
	V10= VALUES(0);
L297:
	if(((V10))==Cnil){
	goto L302;}
	VALUES(0) = (V10);
	RETURN(1);
L302:
	{volatile object V11;
	if((V2)==Cnil){
	V11= Cnil;
	goto L304;}
	L10(2,(V6),(V7))                          /*  STRINGABLE-EQUAL*/;
	if((VALUES(0))==Cnil){
	goto L305;}
	V11= Cnil;
	goto L304;
L305:
	L15(4,(V2),(V7),(V3),(V4))                /*  GET-ENTRY-LOOKUP*/;
	V11= VALUES(0);
L304:
	if(((V11))==Cnil){
	goto L309;}
	VALUES(0) = (V11);
	RETURN(1);
L309:
	if(((V2))==Cnil){
	goto L312;}
L315:
	{object V12;
	V12= CAR((V3));
	V3= CDR((V3));
	}
	{object V12;
	V12= CAR((V4));
	V4= CDR((V4));
	}
	if(((V3))==Cnil){
	goto L326;}
	if(((V4))!=Cnil){
	goto L325;}
L326:
	VALUES(0) = Cnil;
	RETURN(1);
L325:
	V6= CAR((V3));
	V7= CAR((V4));
	L15(4,(V2),(V6),(V3),(V4))                /*  GET-ENTRY-LOOKUP*/;
	V5= VALUES(0);
	if(((V5))==Cnil){
	goto L334;}
	VALUES(0) = (V5);
	RETURN(1);
L334:
	L10(2,(V6),(V7))                          /*  STRINGABLE-EQUAL*/;
	if(VALUES(0)!=Cnil){
	goto L316;}
	L15(4,(V2),(V7),(V3),(V4))                /*  GET-ENTRY-LOOKUP*/;
	V5= VALUES(0);
	if(((V5))==Cnil){
	goto L316;}
	VALUES(0) = (V5);
	RETURN(1);
L316:
	goto L315;
L312:
	VALUES(0) = Cnil;
	RETURN(1);
	}
	}
	}
	}
	}
	}
}
/*	function definition for GET-SEARCH-RESOURCE                   */
static L17(int narg, object V1, object V2, object V3)
{ VT22 VLEX22 CLSR22
TTL:
	{volatile object V4;                      /*  DO-CLASS        */
	if((V3)==Cnil){
	V4= Cnil;
	goto L344;}
	L10(2,(V2),(V3))                          /*  STRINGABLE-EQUAL*/;
	V4= ((VALUES(0))==Cnil?Ct:Cnil);
L344:
	{volatile object V5;
	volatile object V6;                       /*  DBASE-LIST      */
	V5= (V1);
	V6= Cnil;
L349:
	if(!((V5)==Cnil)){
	goto L350;}
	VALUES(0) = Cnil;
	RETURN(1);
L350:
	V6= CAR((V5));
	{volatile object V8;
	volatile object V9;                       /*  DBASE           */
	V8= (V6);
	V9= Cnil;
L359:
	if(!((V8)==Cnil)){
	goto L360;}
	goto L355;
L360:
	V9= CAR((V8));
	(*LK2)(1,(V9))                            /*  RESOURCE-DATABASE-NAME*/;
	L10(2,(V2),VALUES(0))                     /*  STRINGABLE-EQUAL*/;
	if(VALUES(0)==Cnil){
	goto L365;}
	VALUES(0) = ((V9))->in.in_slots[1];
	RETURN(1);
L365:
	V8= CDR((V8));
	goto L359;
	}
L355:
	if(((V4))==Cnil){
	goto L372;}
	{volatile object V12;
	volatile object V13;                      /*  DBASE           */
	V12= (V6);
	V13= Cnil;
L378:
	if(!((V12)==Cnil)){
	goto L379;}
	goto L372;
L379:
	V13= CAR((V12));
	(*LK2)(1,(V13))                           /*  RESOURCE-DATABASE-NAME*/;
	L10(2,(V3),VALUES(0))                     /*  STRINGABLE-EQUAL*/;
	if(VALUES(0)==Cnil){
	goto L384;}
	VALUES(0) = ((V13))->in.in_slots[1];
	RETURN(1);
L384:
	V12= CDR((V12));
	goto L378;
	}
L372:
	V5= CDR((V5));
	goto L349;
	}
	}
}
/*	function definition for GET-SEARCH-TABLE                      */
static L18(int narg, object V1, object V2, object V3)
{ VT23 VLEX23 CLSR23
	bds_check;
TTL:
	{object V4;                               /*  TIGHT           */
	object V5;                                /*  LOOSE           */
	object V6;                                /*  RESULT          */
	V4= ((V1))->in.in_slots[2];
	V5= ((V1))->in.in_slots[3];
	V6= CONS(Cnil,Cnil);
	bds_bind(VV[36],(V6));                    /*  *GET-TABLE-RESULT**/
	if(((V4))!=Cnil){
	goto L398;}
	if(((V5))==Cnil){
	goto L397;}
L398:
	if(((V2))==Cnil){
	goto L402;}
	L21(4,(V4),(V5),(V2),(V3))                /*  GET-TABLES      */;
L402:
	{object V7;                               /*  UNIVERSAL-BINDINGS*/
	T0= (VV[146]->s.s_gfdef);
	VALUES(0) = VV[113];
	(*LK7)(6,Cnil,(V5),VV[37],T0,VV[38],VALUES(0))/*  REMOVE      */;
	V7= VALUES(0);
	if(((V7))==Cnil){
	goto L397;}
	{object V8;
	object V9;
	V8= (VV[36]->s.s_dbind);
	V9= CONS((V7),Cnil);
	CDR((V8)) = (V9);
	}
	}
L397:
	{int V7;
	VALUES(0)=CDR((V6));
	V7=1;
	bds_unwind1;
	RETURN(V7);}
	}
}
/*	function definition for GET-TABLES-LOOKUP                     */
static L20(int narg, object V1, object V2, object V3, object V4)
{ VT24 VLEX24 CLSR24
TTL:
	{volatile object V5;
	volatile object V6;                       /*  ENTRY           */
	V5= (V1);
	V6= Cnil;
L416:
	if(!((V5)==Cnil)){
	goto L417;}
	VALUES(0) = Cnil;
	RETURN(1);
L417:
	V6= CAR((V5));
	(*LK2)(1,(V6))                            /*  RESOURCE-DATABASE-NAME*/;
	L10(2,(V2),VALUES(0))                     /*  STRINGABLE-EQUAL*/;
	if(VALUES(0)==Cnil){
	goto L422;}
	{register object V8;                      /*  TIGHT           */
	register object V9;                       /*  LOOSE           */
	V8= ((V6))->in.in_slots[2];
	V9= ((V6))->in.in_slots[3];
	if(((V8))!=Cnil){
	goto L428;}
	if(((V9))==Cnil){
	goto L422;}
L428:
	if((CDR((V3)))==Cnil){
	goto L434;}
	L21(4,(V8),(V9),CDR((V3)),CDR((V4)))      /*  GET-TABLES      */;
	goto L432;
L434:
	if(((V8))==Cnil){
	goto L432;}
	{object V10;                              /*  RESULT          */
	V10= (VV[36]->s.s_dbind);
	{object V11;
	object V12;
	V11= (V10);
	(VV[36]->s.s_dbind)= CONS((V8),Cnil);
	V12= (VV[36]->s.s_dbind);
	CDR((V11)) = (V12);
	}
	}
L432:
	if(((V9))==Cnil){
	goto L422;}
	{object V10;                              /*  RESULT          */
	V10= (VV[36]->s.s_dbind);
	{object V11;
	object V12;
	V11= (V10);
	(VV[36]->s.s_dbind)= CONS((V9),Cnil);
	V12= (VV[36]->s.s_dbind);
	CDR((V11)) = (V12);
	}
	}
	}
L422:
	V5= CDR((V5));
	goto L416;
	}
}
/*	function definition for GET-TABLES                            */
static L21(int narg, object V1, object V2, object V3, object V4)
{ VT25 VLEX25 CLSR25
TTL:
	{volatile object V5;                      /*  NAME            */
	volatile object V6;                       /*  CLASS           */
	V5= CAR((V3));
	V6= CAR((V4));
	if(((V1))==Cnil){
	goto L453;}
	L20(4,(V1),(V5),(V3),(V4))                /*  GET-TABLES-LOOKUP*/;
L453:
	if(((V2))==Cnil){
	goto L456;}
	L20(4,(V2),(V5),(V3),(V4))                /*  GET-TABLES-LOOKUP*/;
L456:
	if(((V1))==Cnil){
	goto L459;}
	L10(2,(V5),(V6))                          /*  STRINGABLE-EQUAL*/;
	if(VALUES(0)!=Cnil){
	goto L459;}
	L20(4,(V1),(V6),(V3),(V4))                /*  GET-TABLES-LOOKUP*/;
L459:
	if(((V2))==Cnil){
	goto L464;}
	L10(2,(V5),(V6))                          /*  STRINGABLE-EQUAL*/;
	if(VALUES(0)!=Cnil){
	goto L464;}
	L20(4,(V2),(V6),(V3),(V4))                /*  GET-TABLES-LOOKUP*/;
L464:
	if(((V2))==Cnil){
	goto L470;}
L473:
	{object V7;
	V7= CAR((V3));
	V3= CDR((V3));
	}
	{object V7;
	V7= CAR((V4));
	V4= CDR((V4));
	}
	if(((V3))==Cnil){
	goto L484;}
	if(((V4))!=Cnil){
	goto L483;}
L484:
	VALUES(0) = Cnil;
	RETURN(1);
L483:
	V5= CAR((V3));
	V6= CAR((V4));
	L20(4,(V2),(V5),(V3),(V4))                /*  GET-TABLES-LOOKUP*/;
	L10(2,(V5),(V6))                          /*  STRINGABLE-EQUAL*/;
	if(VALUES(0)!=Cnil){
	goto L474;}
	L20(4,(V2),(V6),(V3),(V4))                /*  GET-TABLES-LOOKUP*/;
L474:
	goto L473;
L470:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for MAP-RESOURCE                          */
static L22(int narg, object V1, object V2, ...)
{ VT26 VLEX26 CLSR26
	{volatile object V3;
	va_list args; va_start(args, V2);
	narg -=2;
	V3=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object p=V3;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	RETURN(LC23(4,(V1),(V2),(V3),Cnil)        /*  MAP-RESOURCE-INTERNAL*/);
	}
}
/*	local function MAP-RESOURCE-INTERNAL                          */
static LC23(int narg, object V1, object V2, object V3, object V4)
{ VT27 VLEX27 CLSR27
TTL:
	{volatile object V5;                      /*  TIGHT           */
	volatile object V6;                       /*  LOOSE           */
	V5= ((V1))->in.in_slots[2];
	V6= ((V1))->in.in_slots[3];
	{volatile object V7;
	volatile object V8;                       /*  RESOURCE        */
	V7= (V5);
	V8= Cnil;
L502:
	if(!((V7)==Cnil)){
	goto L503;}
	goto L498;
L503:
	V8= CAR((V7));
	{object V10;                              /*  VALUE           */
	object V11;                               /*  NAME            */
	V10= ((V8))->in.in_slots[1];
	(*LK2)(1,(V8))                            /*  RESOURCE-DATABASE-NAME*/;
	V11= append((V4),CONS(VALUES(0),Cnil));
	if(((V10))==Cnil){
	goto L513;}
	Lapply(4,(V2),(V11),(V10),(V3))           /*  APPLY           */;
	goto L508;
L513:
	LC23(4,(V8),(V2),(V3),(V11))              /*  MAP-RESOURCE-INTERNAL*/;
	}
L508:
	V7= CDR((V7));
	goto L502;
	}
L498:
	{volatile object V7;
	volatile object V8;                       /*  RESOURCE        */
	V7= (V6);
	V8= Cnil;
L521:
	if(!((V7)==Cnil)){
	goto L522;}
	VALUES(0) = Cnil;
	RETURN(1);
L522:
	V8= CAR((V7));
	{object V10;                              /*  VALUE           */
	object V11;                               /*  NAME            */
	V10= ((V8))->in.in_slots[1];
	(*LK2)(1,(V8))                            /*  RESOURCE-DATABASE-NAME*/;
	V11= append((V4),list(2,VV[39],VALUES(0)));
	if(((V10))==Cnil){
	goto L532;}
	Lapply(4,(V2),(V11),(V10),(V3))           /*  APPLY           */;
	goto L527;
L532:
	LC23(4,(V8),(V2),(V3),(V11))              /*  MAP-RESOURCE-INTERNAL*/;
	}
L527:
	V7= CDR((V7));
	goto L521;
	}
	}
}
/*	function definition for MERGE-RESOURCES                       */
static L24(int narg, object V1, object V2)
{ VT28 VLEX28 CLSR28
TTL:
	VALUES(0) = VV[118];
	L22(3,(V1),VALUES(0),(V2))                /*  MAP-RESOURCE    */;
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for CHAR-MEMQ                             */
static L26(int narg, object V1, object V2)
{ VT29 VLEX29 CLSR29
TTL:
	VALUES(0) = memql((V2),(V1));
	RETURN(1);
}
/*	macro definition for RESOURCE-WITH-OPEN-FILE                  */
static L27(int narg, object V1, object V2)
{ VT30 VLEX30 CLSR30
	{object V3=CDR(V1),V4,V5,V6,V7;
	{object V8= CAR(V3);
	V4= CAR(V8);
	V8=CDR(V8);
	V5= CAR(V8);
	V8=CDR(V8);
	V6= V8;}
	V3=CDR(V3);
	V7= V3;
	{object V9;                               /*  ABORTP          */
	object V10;
	object V11;                               /*  STREAMP         */
	Lgensym(0)                                /*  GENSYM          */;
	V10= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V11= VALUES(0);
	V9= V10;
	{object V12= list(2,(V9),Ct);
	{object V13= list(2,(V11),VV[41]);
	{object V14= list(3,(V12),(V13),list(2,(V4),list(4,VV[42],(V11),VV[43],listA(3,VV[44],(V5),(V6)))));
	{object V15= CONS(VV[47],(V7));
	{object V16= list(3,VV[46],(V15),list(3,VV[48],(V9),Cnil));
	VALUES(0) = list(3,VV[40],(V14),list(3,VV[45],(V16),list(3,VV[49],(V11),list(4,VV[50],VV[51],VV[52],(V9)))));
	RETURN(1);}}}}}
	}}
}
/*	function definition for READ-RESOURCES                        */
static L28(int narg, object V1, object V2, ...)
{ VT31 VLEX31 CLSR31
	{volatile object V3;
	volatile object V4;
	volatile object V5;
	va_list args; va_start(args, V2);
	narg -=2;
	{ object keyvars[6];
	parse_key(narg,args,3,L28keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	}
	{volatile object V6;
	volatile object V7;
	volatile object V8;                       /*  STREAM          */
	V6= Ct;
	Lstreamp(1,(V2))                          /*  STREAMP         */;
	V7= VALUES(0);
	if(((V7))==Cnil){
	goto L545;}
	V8= (V2);
	goto L543;
L545:
	(*LK8)(1,(V2))                            /*  OPEN            */;
	V8= VALUES(0);
L543:
	{ int V9; volatile bool unwinding = FALSE;
	if ((V9=frs_push(FRS_PROTECT,Cnil))) {
	V9--; unwinding = TRUE;} else {
	{ int V10;
L550:
	{register object V11;                     /*  STRING          */
	Lread_line(3,(V8),Cnil,VV[54])            /*  READ-LINE       */;
	V11= VALUES(0);
	if(!(((V11))==(VV[54]))){
	goto L553;}
	VALUES(0)=(V1);
	V10=1;
	goto L548;
L553:
	{register int V12;                        /*  END             */
	register object V13;                      /*  I               */
	register object V14;                      /*  TERM            */
	V12= length((V11));
	VALUES(0) = (VV[120]->s.s_gfdef);
	(*LK9)(6,VV[55],(V11),VV[37],VALUES(0),VV[56],MAKE_FIXNUM(V12))/*  POSITION*/;
	V13= VALUES(0);
	V14= Cnil;
	if(((V13))==Cnil){
	goto L551;}
	{object V15= code_char(((V11))->ust.ust_self[fix((V13))]);
	if(!eql(V15,VV[57]))goto L562;
	goto L551;
L562:
	if(!eql(V15,VV[58]))goto L563;
	goto L551;
L563:
	if(!eql(V15,VV[59]))goto L564;
	VALUES(0) = (VV[120]->s.s_gfdef);
	(*LK9)(8,VV[60],(V11),VV[34],VALUES(0),VV[61],(V13),VV[56],MAKE_FIXNUM(V12))/*  POSITION*/;
	V14= VALUES(0);
	Lstring_equal(6,(V11),VV[62],VV[63],(V13),VV[64],(V14))/*  STRING-EQUAL*/;
	if(VALUES(0)==Cnil){
	goto L551;}
	{object V16;                              /*  PATH            */
	Lsubseq(2,(V11),one_plus((V14)))          /*  SUBSEQ          */;
	T0= VALUES(0);
	Ltruename(1,(V8))                         /*  TRUENAME        */;
	Lmerge_pathnames(2,T0,VALUES(0))          /*  MERGE-PATHNAMES */;
	V16= VALUES(0);
	L28(8,(V1),(V16),VV[38],(V3),VV[34],(V4),VV[37],(V5))/*  READ-RESOURCES*/;
	goto L551;
	}
L564:
	{ int V17;
	register object V18;                      /*  NAME-LIST       */
	register object V19;                      /*  VALUE           */
	V17=L29(3,(V11),(V13),MAKE_FIXNUM(V12))   /*  PARSE-RESOURCE  */;
	if (V17--==0) goto L574;
	V18= VALUES(0);
	if (V17--==0) goto L575;
	V19= VALUES(1);
	goto L576;
L574:
	V18= Cnil;
L575:
	V19= Cnil;
L576:
	if(((V18))==Cnil){
	goto L551;}
	if(((V3))==Cnil){
	goto L579;}
	funcall(2,(V3),(V19));
	V19= VALUES(0);
L579:
	if(((V4))==Cnil){
	goto L586;}
	funcall(3,(V4),(V18),(V19));
	if(VALUES(0)==Cnil){
	goto L551;}
	goto L584;
L586:
	if(((V5))==Cnil){
	goto L589;}
	funcall(3,(V5),(V18),(V19));
	if(!((VALUES(0))==Cnil)){
	goto L551;}
	goto L584;
L589:
L584:
	L11(3,(V1),(V18),(V19))                   /*  ADD-RESOURCE    */;}}
	}
	}
L551:
	goto L550;
L548:
	MV_SAVE(V10);
	V6= Cnil;
	MV_RESTORE(V10);
	V9=V10;}
	}
	frs_pop();
	MV_SAVE(V9);
	if(((V7))!=Cnil){
	goto L595;}
	Lclose(3,(V8),VV[52],(V6))                /*  CLOSE           */;
L595:
	MV_RESTORE(V9);
	if (unwinding) unwind(nlj_fr,nlj_tag,V9+1);
	else {
	RETURN(V9);}}
	}
	}
}
/*	function definition for PARSE-RESOURCE                        */
static L29(int narg, object V1, ...)
{ VT32 VLEX32 CLSR32
	{int i=1;
	volatile object V2;
	volatile object V3;
	va_list args; va_start(args, V1);
	if (i==narg) goto L598;
	V2= va_arg(args, object);
	i++;
	if (i==narg) goto L599;
	V3= va_arg(args, object);
	i++;
	goto L600;
L598:
	V2= MAKE_FIXNUM(0);
L599:
	V3= Cnil;
L600:
	{volatile object V4;                      /*  I               */
	volatile int V5;                          /*  END             */
	volatile object V6;                       /*  TERM            */
	volatile object V7;                       /*  NAME-LIST       */
	if((V3)!=Cnil){
	V5= fix((V3));
	goto L603;}
	V5= ((V1))->v.v_fillp;
L603:
	V4= (V2);
	V6= Cnil;
	V7= Cnil;
L605:
	if(!(number_compare((V4),MAKE_FIXNUM(V5))>=0)){
	goto L606;}
	VALUES(0) = Cnil;
	RETURN(1);
L606:
	VALUES(0) = (VV[120]->s.s_gfdef);
	(*LK9)(8,VV[65],(V1),VV[34],VALUES(0),VV[61],(V4),VV[56],MAKE_FIXNUM(V5))/*  POSITION*/;
	V6= VALUES(0);
	if((V6)==Cnil){
	VALUES(0) = Cnil;
	goto L613;}
	VALUES(0) = code_char(((V1))->ust.ust_self[fix((V6))]);
L613:
	{object V9= VALUES(0);
	if(!eql(V9,VV[66]))goto L614;
	if(!(number_compare((V6),(V4))>0)){
	goto L612;}
	Lsubseq(3,(V1),(V4),(V6))                 /*  SUBSEQ          */;
	V7= CONS(VALUES(0),(V7));
	goto L612;
L614:
	if(!eql(V9,VV[67]))goto L619;
	if(!(number_compare((V6),(V4))>0)){
	goto L620;}
	Lsubseq(3,(V1),(V4),(V6))                 /*  SUBSEQ          */;
	V7= CONS(VALUES(0),(V7));
L620:
	V7= CONS(VV[68],(V7));
	goto L612;
L619:
	if(!eql(V9,VV[69]))goto L626;
	Lsubseq(3,(V1),(V4),(V6))                 /*  SUBSEQ          */;
	V7= CONS(VALUES(0),(V7));
	{object V11= nreverse((V7));
	Lsubseq(2,(V1),one_plus((V6)))            /*  SUBSEQ          */;
	Lstring_trim(2,VV[70],VALUES(0))          /*  STRING-TRIM     */;
	VALUES(1) = VALUES(0);
	VALUES(0) = (V11);
	RETURN(2);}
L626:
	{object V13= nreverse((V7));
	Lsubseq(3,(V1),(V4),(V6))                 /*  SUBSEQ          */;
	VALUES(1) = VALUES(0);
	VALUES(0) = (V13);
	RETURN(2);}}
L612:
	V4= one_plus((V6));
	goto L605;
	}
	}
}
/*	function definition for WRITE-RESOURCES                       */
static L30(int narg, object V1, object V2, ...)
{ VT33 VLEX33 CLSR33
	{volatile object V3;
	volatile object V4;
	volatile object V5;
	va_list args; va_start(args, V2);
	narg -=2;
	{ object keyvars[6];
	parse_key(narg,args,3,L30keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	}
	{volatile object V6;
	volatile object V7;
	volatile object V8;                       /*  STREAM          */
	V6= Ct;
	Lstreamp(1,(V2))                          /*  STREAMP         */;
	V7= VALUES(0);
	if(((V7))==Cnil){
	goto L642;}
	V8= (V2);
	goto L640;
L642:
	(*LK8)(3,(V2),VV[71],VV[72])              /*  OPEN            */;
	V8= VALUES(0);
L640:
	{ int V9; volatile bool unwinding = FALSE;
	if ((V9=frs_push(FRS_PROTECT,Cnil))) {
	V9--; unwinding = TRUE;} else {
	{ int V10;
	T0= VV[124];
	if((V3)!=Cnil){
	VALUES(0) = (V3);
	goto L647;}
	VALUES(0) = (VV[85]->s.s_gfdef);
L647:
	V10=L22(6,(V1),T0,(V8),VALUES(0),(V4),(V5))/*  MAP-RESOURCE   */;
	MV_SAVE(V10);
	V6= Cnil;
	MV_RESTORE(V10);
	V9=V10;}
	}
	frs_pop();
	MV_SAVE(V9);
	if(((V7))!=Cnil){
	goto L650;}
	Lclose(3,(V8),VV[52],(V6))                /*  CLOSE           */;
L650:
	MV_RESTORE(V9);
	if (unwinding) unwind(nlj_fr,nlj_tag,V9+1);
	else {}}
	}
	VALUES(0) = (V1);
	RETURN(1);
	}
}
/*	function definition for WM-RESOURCES                          */
static L32(int narg, object V1, object V2, ...)
{ VT34 VLEX34 CLSR34
	{object V3;
	object V4;
	object V5;
	va_list args; va_start(args, V2);
	narg -=2;
	{ object keyvars[6];
	parse_key(narg,args,3,L32keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	}
	{object V6;                               /*  STRING          */
	VALUES(0) = (VV[164]->s.s_gfdef);
	(*LK10)(8,(V2),VV[76],VV[77],VV[78],VV[79],VV[23],VV[80],VALUES(0))/*  GET-PROPERTY*/;
	V6= VALUES(0);
	if(((V6))==Cnil){
	goto L656;}
	{object V7;                               /*  STREAM          */
	Lmake_string_input_stream(3,(V6),Cnil,Cnil)/*  MAKE-STRING-INPUT-STREAM*/;
	V7= VALUES(0);
	RETURN(L28(8,(V1),(V7),VV[38],(V3),VV[34],(V4),VV[37],(V5))/*  READ-RESOURCES*/);
	}
L656:
	VALUES(0) = Cnil;
	RETURN(1);
	}
	}
}
/*	function definition for SET-WM-RESOURCES                      */
static L33(int narg, object V1, object V2, ...)
{ VT35 VLEX35 CLSR35
	{object V3;
	object V4;
	object V5;
	va_list args; va_start(args, V2);
	narg -=2;
	{ object keyvars[6];
	parse_key(narg,args,3,L33keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	}
	{object V6;                               /*  STREAM          */
	Lmake_string_output_stream(0)             /*  MAKE-STRING-OUTPUT-STREAM*/;
	V6= VALUES(0);
	L30(8,(V1),(V6),VV[81],(V3),VV[34],(V4),VV[37],(V5))/*  WRITE-RESOURCES*/;
	Lget_output_stream_string(1,(V6))         /*  GET-OUTPUT-STREAM-STRING*/;
	}
	RETURN((*LK11)(3,(V2),VV[76],VALUES(0))   /*  SET-STRING-PROPERTY*/);
	}
}
/*	function definition for ROOT-RESOURCES                        */
static L34(int narg, object V1, ...)
{ VT36 VLEX36 CLSR36
	{object V2;
	object V3;
	object V4;
	object V5;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[8];
	parse_key(narg,args,4,L34keys,keyvars,OBJNULL,FALSE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	}
	{object V6;                               /*  SCREEN          */
	object V7;                                /*  WINDOW          */
	object V8;                                /*  DATABASE        */
	(*LK3)(2,(V1),VV[82])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L664;}
	V6= ((V1))->in.in_slots[39];
	goto L662;
L664:
	V6= (V1);
L662:
	V7= ((V6))->in.in_slots[0];
	if((V2)!=Cnil){
	V8= (V2);
	goto L667;}
	L5(0)                                     /*  MAKE-RESOURCE-DATABASE*/;
	V8= VALUES(0);
L667:
	L32(8,(V8),(V7),VV[38],(V3),VV[34],(V4),VV[37],(V5))/*  WM-RESOURCES*/;
	VALUES(0) = (V8);
	RETURN(1);
	}
	}
}
/*	function definition for SET-ROOT-RESOURCES                    */
static L35(int narg, object V1, ...)
{ VT37 VLEX37 CLSR37
	{object V2;
	object V3;
	object V4;
	object V5;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[8];
	parse_key(narg,args,4,L35keys,keyvars,OBJNULL,FALSE);
	V2= keyvars[0];
	V3= keyvars[1];
	if(keyvars[6]==Cnil){
	V4= VV[85];
	}else{
	V4= keyvars[2];}
	V5= keyvars[3];
	}
	{object V6;                               /*  SCREEN          */
	object V7;                                /*  WINDOW          */
	(*LK3)(2,(V1),VV[82])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L672;}
	V6= ((V1))->in.in_slots[39];
	goto L670;
L672:
	V6= (V1);
L670:
	V7= ((V6))->in.in_slots[0];
	L33(8,(V5),(V7),VV[81],(V4),VV[34],(V2),VV[37],(V3))/*  SET-WM-RESOURCES*/;
	VALUES(0) = (V5);
	RETURN(1);
	}
	}
}
/*	function definition for INITIALIZE-RESOURCE-DATABASE          */
static L36(int narg, object V1)
{ VT38 VLEX38 CLSR38
TTL:
	{register object V2;                      /*  RDB             */
	object V3;                                /*  ROOTWIN         */
	L5(0)                                     /*  MAKE-RESOURCE-DATABASE*/;
	V2= VALUES(0);
	V3= (CAR(((V1))->in.in_slots[40]))->in.in_slots[0];
	(*LK10)(2,(V3),VV[76])                    /*  GET-PROPERTY    */;
	if(VALUES(0)==Cnil){
	goto L680;}
	L32(2,(V2),(V3))                          /*  WM-RESOURCES    */;
	goto L678;
L680:
	{object V4;                               /*  PATH            */
	(*LK12)(0)                                /*  DEFAULT-RESOURCES-PATHNAME*/;
	V4= VALUES(0);
	if(((V4))==Cnil){
	goto L678;}
	if(!((file_exists((V4))))){
	goto L678;}
	L28(2,(V2),(V4))                          /*  READ-RESOURCES  */;
	}
L678:
	{object V4;                               /*  PATH            */
	(*LK13)(0)                                /*  RESOURCES-PATHNAME*/;
	V4= VALUES(0);
	if(((V4))==Cnil){
	goto L687;}
	if(!((file_exists((V4))))){
	goto L687;}
	L28(2,(V2),(V4))                          /*  READ-RESOURCES  */;
	}
L687:
	((V1))->in.in_slots[42]= (V2);
	VALUES(0) = (V2);
	RETURN(1);
	}
}
static LKF13(int narg, ...) {TRAMPOLINK(VV[173],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[172],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[167],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[165],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[160],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[44],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[153],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[147],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[141],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[140],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[139],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[134],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[132],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[93],&LK0);}
