
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "cmputil.h"
init_cmputil(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_cmputil; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	VV[1]->s.s_stype=(short)stp_special;
	if(VV[1]->s.s_dbind == OBJNULL){
	(VV[1]->s.s_dbind)= VV[0];}
	VV[2]->s.s_stype=(short)stp_special;
	if(VV[2]->s.s_dbind == OBJNULL){
	(VV[2]->s.s_dbind)= Ct;}
	VV[3]->s.s_stype=(short)stp_special;
	if(VV[3]->s.s_dbind == OBJNULL){
	(VV[3]->s.s_dbind)= MAKE_FIXNUM(0);}
	siLAmake_constant(2,VV[4],CONS(Cnil,Cnil))/*  *MAKE-CONSTANT  */;
	VV[8]=string_to_object(VV[8]);
	MF0(VV[55],L1);
	MF0(VV[56],L2);
	MF0(VV[57],L3);
	VV[11]->s.s_stype=(short)stp_special;
	if(VV[11]->s.s_dbind == OBJNULL){
	(VV[11]->s.s_dbind)= Cnil;}
	MF0(VV[58],L4);
	VV[13]->s.s_stype=(short)stp_special;
	if(VV[13]->s.s_dbind == OBJNULL){
	(VV[13]->s.s_dbind)= Cnil;}
	MF0(VV[59],L5);
	MF0(VV[60],L6);
	MF0(VV[61],L7);
	MF0(VV[62],L8);
	MF0(VV[63],L9);
	MF0(VV[64],L10);
	MF0(VV[65],L11);
	MF0(VV[66],L12);
	MF0(VV[67],L13);
	VV[36]->s.s_stype=(short)stp_special;
	if(VV[36]->s.s_dbind == OBJNULL){
	(VV[36]->s.s_dbind)= Cnil;}
	MF0(VV[68],L14);
	MF0(VV[69],L15);
}
/*	function definition for CMPERR                                */
static L1(int narg, object V1, ...)
{ VT3 VLEX3 CLSR3
	bds_check;
	{object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	bds_bind(VV[6],VV[5]);                    /*  *PRINT-CASE*    */
	L6(0)                                     /*  PRINT-CURRENT-FORM*/;
	Lformat(2,Ct,VV[7])                       /*  FORMAT          */;
	VALUES(0) = (VV[70]->s.s_gfdef);
	Lapply(4,VALUES(0),Ct,(V1),(V2))          /*  APPLY           */;
	(VV[3]->s.s_dbind)= number_plus((VV[3]->s.s_dbind),MAKE_FIXNUM(1));
	{frame_ptr fr; int V3;
	fr=frs_sch_catch(VV[8]);
	if (fr==NULL) FEerror("The tag ~s is undefined.",1,VV[8]);
	VALUES(0)=VV[4];
	V3=1;
	unwind(fr,VV[8],V3+1);}
	}
}
/*	function definition for TOO-MANY-ARGS                         */
static L2(int narg, object V1, object V2, object V3)
{ VT4 VLEX4 CLSR4
	bds_check;
TTL:
	bds_bind(VV[6],VV[5]);                    /*  *PRINT-CASE*    */
	L6(0)                                     /*  PRINT-CURRENT-FORM*/;
	Lformat(5,Ct,VV[9],(V1),(V2),(V3))        /*  FORMAT          */;
	(VV[3]->s.s_dbind)= number_plus((VV[3]->s.s_dbind),MAKE_FIXNUM(1));
	{frame_ptr fr; int V4;
	fr=frs_sch_catch(VV[8]);
	if (fr==NULL) FEerror("The tag ~s is undefined.",1,VV[8]);
	VALUES(0)=VV[4];
	V4=1;
	unwind(fr,VV[8],V4+1);}
}
/*	function definition for TOO-FEW-ARGS                          */
static L3(int narg, object V1, object V2, object V3)
{ VT5 VLEX5 CLSR5
	bds_check;
TTL:
	bds_bind(VV[6],VV[5]);                    /*  *PRINT-CASE*    */
	L6(0)                                     /*  PRINT-CURRENT-FORM*/;
	Lformat(5,Ct,VV[10],(V1),(V2),(V3))       /*  FORMAT          */;
	(VV[3]->s.s_dbind)= number_plus((VV[3]->s.s_dbind),MAKE_FIXNUM(1));
	{frame_ptr fr; int V4;
	fr=frs_sch_catch(VV[8]);
	if (fr==NULL) FEerror("The tag ~s is undefined.",1,VV[8]);
	VALUES(0)=VV[4];
	V4=1;
	unwind(fr,VV[8],V4+1);}
}
/*	function definition for CMPWARN                               */
static L4(int narg, object V1, ...)
{ VT6 VLEX6 CLSR6
	bds_check;
	{object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	bds_bind(VV[6],VV[5]);                    /*  *PRINT-CASE*    */
	if(((VV[11]->s.s_dbind))!=Cnil){
	goto L26;}
	L6(0)                                     /*  PRINT-CURRENT-FORM*/;
	Lformat(2,Ct,VV[12])                      /*  FORMAT          */;
	VALUES(0) = (VV[70]->s.s_gfdef);
	Lapply(4,VALUES(0),Ct,(V1),(V2))          /*  APPLY           */;
	princ_char(10,Cnil);
L26:
	{int V3;
	VALUES(0)=Cnil;
	V3=1;
	bds_unwind1;
	RETURN(V3);}
	}
}
/*	function definition for CMPNOTE                               */
static L5(int narg, object V1, ...)
{ VT7 VLEX7 CLSR7
	bds_check;
	{object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	bds_bind(VV[6],VV[5]);                    /*  *PRINT-CASE*    */
	if(((VV[13]->s.s_dbind))!=Cnil){
	goto L33;}
	princ_char(10,Cnil);
	Lformat(2,Ct,VV[14])                      /*  FORMAT          */;
	VALUES(0) = (VV[70]->s.s_gfdef);
	Lapply(4,VALUES(0),Ct,(V1),(V2))          /*  APPLY           */;
L33:
	{int V3;
	VALUES(0)=Cnil;
	V3=1;
	bds_unwind1;
	RETURN(V3);}
	}
}
/*	function definition for PRINT-CURRENT-FORM                    */
static L6(int narg)
{ VT8 VLEX8 CLSR8
	bds_check;
TTL:
	if(((VV[2]->s.s_dbind))==Cnil){
	goto L39;}
	(VV[2]->s.s_dbind)= Cnil;
	if(!(type_of((VV[1]->s.s_dbind))==t_cons)){
	goto L45;}
	if(!((CAR((VV[1]->s.s_dbind)))==(VV[15]))){
	goto L45;}
	Lformat(3,Ct,VV[16],CDR((VV[1]->s.s_dbind)))/*  FORMAT        */;
	goto L39;
L45:
	bds_bind(VV[17],MAKE_FIXNUM(2));          /*  *PRINT-LENGTH*  */
	bds_bind(VV[18],MAKE_FIXNUM(2));          /*  *PRINT-LEVEL*   */
	Lformat(3,Ct,VV[19],(VV[1]->s.s_dbind))   /*  FORMAT          */;
	bds_unwind1;
	bds_unwind1;
L39:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for PRINT-EMITTING                        */
static L7(int narg, object V1)
{ VT9 VLEX9 CLSR9
TTL:
	if((V1)!=Cnil){
	VALUES(0) = (V1);
	goto L49;}
	VALUES(0) = VV[21];
L49:
	RETURN(Lformat(3,Ct,VV[20],VALUES(0))     /*  FORMAT          */);
}
/*	function definition for UNDEFINED-VARIABLE                    */
static L8(int narg, object V1)
{ VT10 VLEX10 CLSR10
	bds_check;
TTL:
	bds_bind(VV[6],VV[5]);                    /*  *PRINT-CASE*    */
	L6(0)                                     /*  PRINT-CURRENT-FORM*/;
	Lformat(3,Ct,VV[22],(V1))                 /*  FORMAT          */;
	{int V2;
	VALUES(0)=Cnil;
	V2=1;
	bds_unwind1;
	RETURN(V2);}
}
/*	function definition for BABOON                                */
static L9(int narg)
{ VT11 VLEX11 CLSR11
	bds_check;
TTL:
	bds_bind(VV[6],VV[5]);                    /*  *PRINT-CASE*    */
	L6(0)                                     /*  PRINT-CURRENT-FORM*/;
	Lformat(2,Ct,VV[23])                      /*  FORMAT          */;
	(VV[3]->s.s_dbind)= number_plus((VV[3]->s.s_dbind),MAKE_FIXNUM(1));
	{int V1;
	V1=(*LK0)(0)                              /*  BREAK           */;
	bds_unwind1;
	RETURN(V1);}
}
/*	function definition for CMP-EVAL                              */
static L10(int narg, object V1)
{ VT12 VLEX12 CLSR12
	bds_check;
TTL:
	{object V2;                               /*  THROW-FLAG      */
	V2= Ct;
	if(((VV[24]->s.s_dbind))!=Cnil){
	goto L58;}
	{ int V3; bool unwinding = FALSE;
	if ((V3=frs_push(FRS_PROTECT,Cnil))) {
	V3--; unwinding = TRUE;} else {
	{object V4;
	L14(1,(V1))                               /*  CMP-TOPLEVEL-EVAL*/;
	V4= VALUES(0);
	V2= Cnil;
	VALUES(0)=(V4);
	V3=1;
	}
	}
	frs_pop();
	MV_SAVE(V3);
	if(((V2))==Cnil){
	goto L64;}
	bds_bind(VV[6],VV[5]);                    /*  *PRINT-CASE*    */
	L6(0)                                     /*  PRINT-CURRENT-FORM*/;
	Lformat(3,Ct,VV[25],(V1))                 /*  FORMAT          */;
	bds_unwind1;
L64:
	MV_RESTORE(V3);
	if (unwinding) unwind(nlj_fr,nlj_tag,V3+1);
	else {
	RETURN(V3);}}
L58:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for CMP-MACROEXPAND                       */
static L11(int narg, object V1)
{ VT13 VLEX13 CLSR13
	bds_check;
TTL:
	{register object V2;                      /*  ENV             */
	object V3;                                /*  THROW-FLAG      */
	V2= Cnil;
	V3= Ct;
	{register object V4;
	register object V5;                       /*  V               */
	V4= (VV[26]->s.s_dbind);
	V5= Cnil;
L74:
	if(!((V4)==Cnil)){
	goto L75;}
	goto L70;
L75:
	V5= CAR((V4));
	if(!(type_of((V5))==t_cons)){
	goto L80;}
	V2= CONS(list(3,CAR((V5)),VV[27],CADR((V5))),(V2));
L80:
	V4= CDR((V4));
	goto L74;
	}
L70:
	if(((V2))==Cnil){
	goto L87;}
	{object V4= nreverse((V2));
	V2= list(3,Cnil,V4,Cnil);}
L87:
	{ int V4; bool unwinding = FALSE;
	if ((V4=frs_push(FRS_PROTECT,Cnil))) {
	V4--; unwinding = TRUE;} else {
	{ int V5;
	{object V6= list(2,VV[29],(V1));
	V5=L14(1,list(3,VV[28],V6,list(2,VV[29],(V2))))/*  CMP-TOPLEVEL-EVAL*/;}
	MV_SAVE(V5);
	V3= Cnil;
	MV_RESTORE(V5);
	V4=V5;}
	}
	frs_pop();
	MV_SAVE(V4);
	if(((V3))==Cnil){
	goto L95;}
	bds_bind(VV[6],VV[5]);                    /*  *PRINT-CASE*    */
	L6(0)                                     /*  PRINT-CURRENT-FORM*/;
	Lformat(3,Ct,VV[30],(V1))                 /*  FORMAT          */;
	bds_unwind1;
L95:
	MV_RESTORE(V4);
	if (unwinding) unwind(nlj_fr,nlj_tag,V4+1);
	else {
	RETURN(V4);}}
	}
}
/*	function definition for CMP-MACROEXPAND-1                     */
static L12(int narg, object V1)
{ VT14 VLEX14 CLSR14
	bds_check;
TTL:
	{object V2;                               /*  ENV             */
	object V3;                                /*  THROW-FLAG      */
	V2= Cnil;
	V3= Ct;
	{register object V4;
	register object V5;                       /*  V               */
	V4= (VV[26]->s.s_dbind);
	V5= Cnil;
L105:
	if(!((V4)==Cnil)){
	goto L106;}
	goto L101;
L106:
	V5= CAR((V4));
	if(!(type_of((V5))==t_cons)){
	goto L111;}
	V2= CONS(list(3,CAR((V5)),VV[27],CADR((V5))),(V2));
L111:
	V4= CDR((V4));
	goto L105;
	}
L101:
	{ int V4; bool unwinding = FALSE;
	if ((V4=frs_push(FRS_PROTECT,Cnil))) {
	V4--; unwinding = TRUE;} else {
	{object V5;
	{object V6= list(2,VV[29],(V1));
	L14(1,list(3,VV[31],V6,list(2,VV[29],(V2))))/*  CMP-TOPLEVEL-EVAL*/;
	V5= VALUES(0);}
	V3= Cnil;
	VALUES(0)=(V5);
	V4=1;
	}
	}
	frs_pop();
	MV_SAVE(V4);
	if(((V3))==Cnil){
	goto L122;}
	bds_bind(VV[6],VV[5]);                    /*  *PRINT-CASE*    */
	L6(0)                                     /*  PRINT-CURRENT-FORM*/;
	Lformat(3,Ct,VV[32],(V1))                 /*  FORMAT          */;
	bds_unwind1;
L122:
	MV_RESTORE(V4);
	if (unwinding) unwind(nlj_fr,nlj_tag,V4+1);
	else {
	RETURN(V4);}}
	}
}
/*	function definition for CMP-EXPAND-MACRO                      */
static L13(int narg, object V1, object V2, object V3)
{ VT15 VLEX15 CLSR15
	bds_check;
TTL:
	{register object V4;                      /*  ENV             */
	object V5;                                /*  THROW-FLAG      */
	V4= Cnil;
	V5= Ct;
	{register object V6;
	register object V7;                       /*  V               */
	V6= (VV[26]->s.s_dbind);
	V7= Cnil;
L132:
	if(!((V6)==Cnil)){
	goto L133;}
	goto L128;
L133:
	V7= CAR((V6));
	if(!(type_of((V7))==t_cons)){
	goto L138;}
	V4= CONS(list(3,CAR((V7)),VV[27],CADR((V7))),(V4));
L138:
	V6= CDR((V6));
	goto L132;
	}
L128:
	if(((V4))==Cnil){
	goto L145;}
	{object V6= nreverse((V4));
	V4= list(3,Cnil,V6,Cnil);}
L145:
	{ int V6; bool unwinding = FALSE;
	if ((V6=frs_push(FRS_PROTECT,Cnil))) {
	V6--; unwinding = TRUE;} else {
	{object V7;
	{object V8= list(2,VV[29],(V1));
	{object V9= list(2,VV[29],CONS((V2),(V3)));
	L14(1,list(5,VV[33],VV[34],V8,V9,list(2,VV[29],(V4))))/*  CMP-TOPLEVEL-EVAL*/;
	V7= VALUES(0);}}
	V5= Cnil;
	VALUES(0)=(V7);
	V6=1;
	}
	}
	frs_pop();
	MV_SAVE(V6);
	if(((V5))==Cnil){
	goto L153;}
	bds_bind(VV[6],VV[5]);                    /*  *PRINT-CASE*    */
	L6(0)                                     /*  PRINT-CURRENT-FORM*/;
	Lformat(3,Ct,VV[35],(V2))                 /*  FORMAT          */;
	bds_unwind1;
L153:
	MV_RESTORE(V6);
	if (unwinding) unwind(nlj_fr,nlj_tag,V6+1);
	else {
	RETURN(V6);}}
	}
}
/*	function definition for CMP-TOPLEVEL-EVAL                     */
static L14(int narg, object V1)
{ VT16 VLEX16 CLSR16
	bds_check;
TTL:
	bds_bind(VV[37],(VV[38]->s.s_dbind));     /*  *IHS-BASE*      */
	siLihs_top(0)                             /*  IHS-TOP         */;
	bds_bind(VV[38],one_minus(VALUES(0)));    /*  *IHS-TOP*       */
	bds_bind(VV[39],(VV[36]->s.s_dbind));     /*  *BREAK-ENABLE*  */
	Lfind_package(1,VV[41])                   /*  FIND-PACKAGE    */;
	bds_bind(VV[40],CONS(VALUES(0),(VV[40]->s.s_dbind)));/*  *BREAK-HIDDEN-PACKAGES**/
	{int V2;
	V2=Leval(1,(V1))                          /*  EVAL            */;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V2);}
}
/*	function definition for COMPILER-CLEAR-COMPILER-PROPERTIES    */
static L15(int narg, object V1)
{ VT17 VLEX17 CLSR17
TTL:
	remprop((V1),VV[42]);
	siLunlink_symbol(1,(V1))                  /*  UNLINK-SYMBOL   */;
	remprop((V1),VV[43]);
	remprop((V1),VV[44]);
	remprop((V1),VV[45]);
	remprop((V1),VV[46]);
	remprop((V1),VV[47]);
	remprop((V1),VV[48]);
	remprop((V1),VV[49]);
	remprop((V1),VV[50]);
	remprop((V1),VV[51]);
	remprop((V1),VV[52]);
	remprop((V1),VV[53]);
	VALUES(0) = remprop((V1),VV[54]);
	RETURN(1);
}
static LKF0(int narg, ...) {TRAMPOLINK(VV[71],&LK0);}
