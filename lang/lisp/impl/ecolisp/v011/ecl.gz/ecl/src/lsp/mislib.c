
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "mislib.h"
init_mislib(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_mislib; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	funcall(2,symbol_function(VV[23]),VV[0])  /*  PROCLAIM        */;
	MM0(VV[24],L1);
	siLAmake_constant(2,VV[18],MAKE_FIXNUM(86400))/*  *MAKE-CONSTANT*/;
	MF0(VV[25],L2);
	MF0(VV[26],L3);
	siLAmake_constant(2,VV[19],VV[20])        /*  *MAKE-CONSTANT  */;
	VV[21]=string_to_object(VV[21]);
	MF0(VV[27],L4);
	MF0(VV[28],L5);
}
/*	macro definition for TIME                                     */
static L1(int narg, object V1, object V2)
{ VT3 VLEX3 CLSR3
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4;
	if(endp(V3))FEinvalid_macro_call(VV[24]);
	V4= CAR(V3);
	V3=CDR(V3);
	if(!endp(V3))FEinvalid_macro_call(VV[24]);
	{object V5;                               /*  REAL-START      */
	object V6;
	object V7;                                /*  REAL-END        */
	object V8;
	object V9;                                /*  RUN-START       */
	object V10;
	object V11;                               /*  RUN-END         */
	object V12;
	object V13;                               /*  GC-START        */
	object V14;
	object V15;                               /*  GC-END          */
	object V16;
	object V17;                               /*  X               */
	Lgentemp(0)                               /*  GENTEMP         */;
	V6= VALUES(0);
	Lgentemp(0)                               /*  GENTEMP         */;
	V8= VALUES(0);
	Lgentemp(0)                               /*  GENTEMP         */;
	V10= VALUES(0);
	Lgentemp(0)                               /*  GENTEMP         */;
	V12= VALUES(0);
	Lgentemp(0)                               /*  GENTEMP         */;
	V14= VALUES(0);
	Lgentemp(0)                               /*  GENTEMP         */;
	V16= VALUES(0);
	Lgentemp(0)                               /*  GENTEMP         */;
	V17= VALUES(0);
	V5= V6;
	V7= V8;
	V9= V10;
	V11= V12;
	V13= V14;
	V15= V16;
	{object V18= list(2,(V5),VV[2]);
	{object V19= list(2,(V9),VV[3]);
	{object V20= list(7,(V18),(V19),list(2,(V13),VV[4]),(V7),(V11),(V15),(V17));
	{object V21= list(3,VV[5],(V17),list(2,VV[6],(V4)));
	{object V22= list(3,VV[5],(V11),VV[7]);
	{object V23= list(3,VV[5],(V7),VV[8]);
	{object V24= list(3,VV[5],(V15),VV[9]);
	{object V25= list(3,VV[14],list(3,VV[15],(V7),(V5)),VV[16]);
	{object V26= list(3,VV[14],list(3,VV[15],(V11),(V9)),VV[16]);
	{object V27= list(6,VV[11],VV[12],VV[13],(V25),(V26),list(3,VV[14],list(3,VV[15],(V15),(V13)),VV[16]));
	VALUES(0) = list(9,VV[1],(V20),(V21),(V22),(V23),(V24),VV[10],(V27),list(2,VV[17],(V17)));
	RETURN(1);}}}}}}}}}}
	}}
}
/*	function definition for LEAP-YEAR-P                           */
static L2(int narg, object V1)
{ VT4 VLEX4 CLSR4
	cs_check;
	check_arg(1);
TTL:
	Lmod(2,(V1),MAKE_FIXNUM(4))               /*  MOD             */;
	if(number_compare(MAKE_FIXNUM(0),VALUES(0))==0){
	goto L13;}
	VALUES(0) = Cnil;
	RETURN(1);
L13:
	Lmod(2,(V1),MAKE_FIXNUM(100))             /*  MOD             */;
	if(!(((number_compare(MAKE_FIXNUM(0),VALUES(0))==0?Ct:Cnil))==Cnil)){
	goto L16;}
	VALUES(0) = Ct;
	RETURN(1);
L16:
	Lmod(2,(V1),MAKE_FIXNUM(400))             /*  MOD             */;
	VALUES(0) = (number_compare(MAKE_FIXNUM(0),VALUES(0))==0?Ct:Cnil);
	RETURN(1);
}
/*	function definition for NUMBER-OF-DAYS-FROM-1900              */
static L3(int narg, object V1)
{ VT5 VLEX5 CLSR5
	cs_check;
	check_arg(1);
TTL:
	{object V2;                               /*  Y1              */
	V2= one_minus((V1));
	{object V3= number_times(number_minus((V1),MAKE_FIXNUM(1900)),MAKE_FIXNUM(365));
	Lfloor(2,(V2),MAKE_FIXNUM(4))             /*  FLOOR           */;
	T0= VALUES(0);
	Lfloor(2,(V2),MAKE_FIXNUM(100))           /*  FLOOR           */;
	{object V4= number_negate(VALUES(0));
	Lfloor(2,(V2),MAKE_FIXNUM(400))           /*  FLOOR           */;
	RETURN(Lplus(5,(V3),T0,(V4),VALUES(0),MAKE_FIXNUM(-460))/*  + */);}}
	}
}
/*	function definition for DECODE-UNIVERSAL-TIME                 */
static L4(int narg, object V1, ...)
{ VT6 VLEX6 CLSR6
	cs_check;
	{int i=1;
	volatile object V2;
	va_list args; va_start(args, V1);
	if(narg<1) FEtoo_few_arguments(&narg);
	if(narg>2) FEtoo_many_arguments(&narg);
	if (i==narg) goto L24;
	V2= va_arg(args, object);
	i++;
	goto L25;
L24:
	Lget_local_time_zone(0)                   /*  GET-LOCAL-TIME-ZONE*/;
	V2= VALUES(0);
L25:
	{volatile object V3;                      /*  SEC             */
	volatile object V4;                       /*  MIN             */
	volatile object V5;                       /*  HOUR            */
	volatile object V6;                       /*  DAY             */
	volatile object V7;                       /*  MONTH           */
	volatile object V8;                       /*  YEAR            */
	volatile object V9;                       /*  DOW             */
	volatile object V10;                      /*  DAYS            */
	volatile object V11;                      /*  DSTP            */
	Ldaylight_saving_timep(0)                 /*  DAYLIGHT-SAVING-TIME-P*/;
	V11= VALUES(0);
	V3= Cnil;
	V4= Cnil;
	V5= Cnil;
	V6= Cnil;
	V7= Cnil;
	V8= Cnil;
	V9= Cnil;
	V10= Cnil;
	Lround(1,number_times((V2),MAKE_FIXNUM(3600)))/*  ROUND       */;
	V1= number_minus((V1),VALUES(0));
	{ int V12;
	V12=Lfloor(2,(V1),MAKE_FIXNUM(60))        /*  FLOOR           */;
	if (V12>0) {
	V1= VALUES(0);
	V12--;
	} else {
	V1= Cnil;}
	if (V12>0) {
	V3= VALUES(1);
	} else {
	V3= Cnil;}
	
	}
	{ int V12;
	V12=Lfloor(2,(V1),MAKE_FIXNUM(60))        /*  FLOOR           */;
	if (V12>0) {
	V1= VALUES(0);
	V12--;
	} else {
	V1= Cnil;}
	if (V12>0) {
	V4= VALUES(1);
	} else {
	V4= Cnil;}
	
	}
	{ int V12;
	V12=Lfloor(2,(V1),MAKE_FIXNUM(24))        /*  FLOOR           */;
	if (V12>0) {
	V10= VALUES(0);
	V12--;
	} else {
	V10= Cnil;}
	if (V12>0) {
	V5= VALUES(1);
	} else {
	V5= Cnil;}
	
	}
	Lmod(2,(V10),MAKE_FIXNUM(7))              /*  MOD             */;
	V9= VALUES(0);
	Lfloor(2,(V10),MAKE_FIXNUM(366))          /*  FLOOR           */;
	V8= number_plus(MAKE_FIXNUM(1900),VALUES(0));
	{volatile object V12;                     /*  X               */
	V12= Cnil;
L44:
	L3(1,(V8))                                /*  NUMBER-OF-DAYS-FROM-1900*/;
	V12= number_minus((V10),VALUES(0));
	L2(1,(V8))                                /*  LEAP-YEAR-P     */;
	if(VALUES(0)==Cnil){
	goto L52;}
	VALUES(0) = MAKE_FIXNUM(366);
	goto L50;
L52:
	VALUES(0) = MAKE_FIXNUM(365);
L50:
	if(!(number_compare((V12),VALUES(0))<0)){
	goto L45;}
	V6= one_plus((V12));
	goto L42;
L45:
	V8= number_plus((V8),MAKE_FIXNUM(1));
	goto L44;
	}
L42:
	L2(1,(V8))                                /*  LEAP-YEAR-P     */;
	if(VALUES(0)==Cnil){
	goto L59;}
	if(!(number_compare((V6),MAKE_FIXNUM(60))==0)){
	goto L62;}
	VALUES(8) = (V2);
	VALUES(7) = (V11);
	VALUES(6) = (V9);
	VALUES(5) = (V8);
	VALUES(4) = MAKE_FIXNUM(2);
	VALUES(3) = MAKE_FIXNUM(29);
	VALUES(2) = (V5);
	VALUES(1) = (V4);
	VALUES(0) = (V3);
	RETURN(9);
L62:
	if(!(number_compare((V6),MAKE_FIXNUM(60))>0)){
	goto L59;}
	V6= number_minus((V6),MAKE_FIXNUM(1));
L59:
	VALUES(0) = symbol_function(VV[29]);
	(*LK0)(4,(V6),VV[21],VV[22],VALUES(0))    /*  POSITION        */;
	V7= VALUES(0);
	V6= number_minus((V6),aref1(VV[21],fixint(one_minus((V7)))));
	VALUES(8) = (V2);
	VALUES(7) = (V11);
	VALUES(6) = (V9);
	VALUES(5) = (V8);
	VALUES(4) = (V7);
	VALUES(3) = (V6);
	VALUES(2) = (V5);
	VALUES(1) = (V4);
	VALUES(0) = (V3);
	RETURN(9);
	}
	}
}
/*	function definition for ENCODE-UNIVERSAL-TIME                 */
static L5(int narg, object V1, object V2, object V3, object V4, object V5, object V6, ...)
{ VT7 VLEX7 CLSR7
	cs_check;
	{int i=6;
	object V7;
	va_list args; va_start(args, V6);
	if(narg<6) FEtoo_few_arguments(&narg);
	if(narg>7) FEtoo_many_arguments(&narg);
	if (i==narg) goto L73;
	V7= va_arg(args, object);
	i++;
	goto L74;
L73:
	Lget_local_time_zone(0)                   /*  GET-LOCAL-TIME-ZONE*/;
	V7= VALUES(0);
L74:
	V3= number_plus((V3),(V7));
	Lmonotonically_nondecreasing(3,MAKE_FIXNUM(0),(V6),MAKE_FIXNUM(99))/*  <=*/;
	if(VALUES(0)==Cnil){
	goto L78;}
	{ int V8;
	object V9;                                /*  SEC             */
	object V10;                               /*  MIN             */
	object V11;                               /*  H               */
	object V12;                               /*  D               */
	object V13;                               /*  M               */
	register object V14;                      /*  Y1              */
	object V15;                               /*  DOW             */
	object V16;                               /*  DSTP            */
	object V17;                               /*  TZ              */
	V8=(*LK1)(0)                              /*  GET-DECODED-TIME*/;
	if (V8--==0) goto L82;
	V9= VALUES(0);
	if (V8--==0) goto L83;
	V10= VALUES(1);
	if (V8--==0) goto L84;
	V11= VALUES(2);
	if (V8--==0) goto L85;
	V12= VALUES(3);
	if (V8--==0) goto L86;
	V13= VALUES(4);
	if (V8--==0) goto L87;
	V14= VALUES(5);
	if (V8--==0) goto L88;
	V15= VALUES(6);
	if (V8--==0) goto L89;
	V16= VALUES(7);
	if (V8--==0) goto L90;
	V17= VALUES(8);
	goto L91;
L82:
	V9= Cnil;
L83:
	V10= Cnil;
L84:
	V11= Cnil;
L85:
	V12= Cnil;
L86:
	V13= Cnil;
L87:
	V14= Cnil;
L88:
	V15= Cnil;
L89:
	V16= Cnil;
L90:
	V17= Cnil;
L91:
	Lmod(2,(V14),MAKE_FIXNUM(100))            /*  MOD             */;
	V6= number_plus((V6),number_minus((V14),VALUES(0)));
	if(!(number_compare(number_minus((V6),(V14)),MAKE_FIXNUM(-50))<0)){
	goto L96;}
	V6= number_plus((V6),MAKE_FIXNUM(100));
	goto L78;
L96:
	if(!(number_compare(number_minus((V6),(V14)),MAKE_FIXNUM(50))>=0)){
	goto L78;}
	V6= number_minus((V6),MAKE_FIXNUM(100));}
L78:
	L2(1,(V6))                                /*  LEAP-YEAR-P     */;
	if(VALUES(0)==Cnil){
	goto L102;}
	if(!(number_compare((V5),MAKE_FIXNUM(2))>0)){
	goto L102;}
	V4= number_plus((V4),MAKE_FIXNUM(1));
L102:
	L3(1,(V6))                                /*  NUMBER-OF-DAYS-FROM-1900*/;
	T0= VALUES(0);
	Lplus(3,T0,aref1(VV[21],fixint((V5))),(V4))/*  +              */;
	{object V8= number_times(VALUES(0),MAKE_FIXNUM(86400));
	{object V9= number_times((V3),MAKE_FIXNUM(3600));
	RETURN(Lplus(4,(V8),(V9),number_times((V2),MAKE_FIXNUM(60)),(V1))/*  +*/);}}
	}
}
static LKF1(int narg, ...) {TRAMPOLINK(VV[31],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[30],&LK0);}
