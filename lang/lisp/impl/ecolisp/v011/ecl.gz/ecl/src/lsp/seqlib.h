
/* (c) Copyright G. Attardi, 1993. All rights reserved. */
static L1(int, object);
static L2(int, object, object, object, object);
static L3(int);
static L4(int, object, ...);
static L5(int, object, object);
static L6(int, object);
static L7(int, object, object, ...);
static L8(int, object, object, ...);
static L9(int, object, object, ...);
static L10(int, object, object, ...);
static L11(int, object, object, ...);
static L12(int, object, object, ...);
static L13(int, object, object, ...);
static L14(int, object, object, ...);
static L15(int, object, object, ...);
static L16(int, object, object, ...);
static L17(int, object, object, ...);
static L18(int, object, object, ...);
static L19(int, object, object, ...);
static L20(int, object, object, object, ...);
static L21(int, object, object, object, ...);
static L22(int, object, object, object, ...);
static L23(int, object, object, object, ...);
static L24(int, object, object, object, ...);
static L25(int, object, object, object, ...);
static L26(int, object, object, ...);
static L27(int, object, object, ...);
static L28(int, object, object, ...);
static L29(int, object, object, ...);
static L30(int, object, object, ...);
static L31(int, object, object, ...);
static L32(int, object, ...);
static L33(int, object, ...);
static L34(int, object, object, ...);
static L35(int, object, object, ...);
static L36(int, object, object, ...);
static L37(int, object, object, object);
static L39(int, object, object, object, object, object);
static L40(int, object, object, ...);
static L41(int, object, object, object, object, ...);
#define VT2
#define VLEX2
#define CLSR2
static object LI1();
int Larray_element_type();
int Lerror();
#define VT3
#define VLEX3
#define CLSR3
static object LI2();
#define VT4
#define VLEX4
#define CLSR4
static object LI3();
int Lerror();
#define VT5
#define VLEX5
#define CLSR5
int Lerror();
#define VT6
#define VLEX6
#define CLSR6
#define VT7
#define VLEX7
#define CLSR7
#define VT8
#define VLEX8
#define CLSR8
static intUobject L7keys[4]={11,14,15,60};
#define VT9
#define VLEX9
#define CLSR9
static intUobject L8keys[2]={14,15};
#define VT10
#define VLEX10
#define CLSR10
static intUobject L9keys[4]={61,62,63,64};
#define VT11
#define VLEX11
#define CLSR11
static intUobject L10keys[7]={11,12,13,14,15,16,17};
int Lreconc();
#define VT12
#define VLEX12
#define CLSR12
static intUobject L11keys[5]={11,14,15,16,17};
#define VT13
#define VLEX13
#define CLSR13
static intUobject L12keys[5]={11,14,15,16,17};
#define VT14
#define VLEX14
#define CLSR14
static intUobject L13keys[7]={11,12,13,14,15,16,17};
#define VT15
#define VLEX15
#define CLSR15
static intUobject L14keys[5]={11,14,15,16,17};
#define VT16
#define VLEX16
#define CLSR16
static intUobject L15keys[5]={11,14,15,16,17};
#define VT17
#define VLEX17
#define CLSR17
static intUobject L16keys[6]={11,12,13,14,15,17};
#define VT18
#define VLEX18
#define CLSR18
static intUobject L17keys[4]={11,14,15,17};
#define VT19
#define VLEX19
#define CLSR19
static intUobject L18keys[4]={11,14,15,17};
#define VT20
#define VLEX20
#define CLSR20
static intUobject L19keys[7]={11,12,13,14,15,16,17};
#define VT21
#define VLEX21
#define CLSR21
static intUobject L20keys[7]={11,12,13,14,15,16,17};
#define VT22
#define VLEX22
#define CLSR22
static intUobject L21keys[5]={11,14,15,16,17};
#define VT23
#define VLEX23
#define CLSR23
static intUobject L22keys[5]={11,14,15,16,17};
#define VT24
#define VLEX24
#define CLSR24
static intUobject L23keys[7]={11,12,13,14,15,16,17};
#define VT25
#define VLEX25
#define CLSR25
static intUobject L24keys[5]={11,14,15,16,17};
#define VT26
#define VLEX26
#define CLSR26
static intUobject L25keys[5]={11,14,15,16,17};
#define VT27
#define VLEX27
#define CLSR27
static intUobject L26keys[6]={11,12,13,14,15,17};
#define VT28
#define VLEX28
#define CLSR28
static intUobject L27keys[4]={11,14,15,17};
#define VT29
#define VLEX29
#define CLSR29
static intUobject L28keys[4]={11,14,15,17};
#define VT30
#define VLEX30
#define CLSR30
static intUobject L29keys[6]={11,12,13,14,15,17};
#define VT31
#define VLEX31
#define CLSR31
static intUobject L30keys[4]={11,14,15,17};
#define VT32
#define VLEX32
#define CLSR32
static intUobject L31keys[4]={11,14,15,17};
#define VT33
#define VLEX33
#define CLSR33
static intUobject L32keys[6]={11,12,13,14,15,17};
int Lreconc();
#define VT34
#define VLEX34
#define CLSR34
static intUobject L33keys[6]={11,12,13,14,15,17};
#define VT35 object T0;
#define VLEX35
#define CLSR35
static intUobject L34keys[8]={11,12,13,17,61,63,62,64};
#define VT36 object T0;
#define VLEX36
#define CLSR36
static intUobject L35keys[8]={11,12,13,17,61,63,62,64};
#define VT37 object T0;
#define VLEX37
#define CLSR37
static intUobject L36keys[1]={17};
#define VT38
#define VLEX38
#define CLSR38
#define VT39
#define VLEX39 register object lex0[2];
#define CLSR39
static LC38(object *,int, object );
#define VT40
#define VLEX40
#define CLSR40
static object LI39();
#define VT41
#define VLEX41
#define CLSR41
static intUobject L40keys[1]={17};
#define VT42 object T0;
#define VLEX42
#define CLSR42
static intUobject L41keys[1]={17};
#define VT43 object T0;
#define VLEX43
#define CLSR43
static struct codeblock Cblock;
#define VM43 1
#define VM42 1
#define VM41 0
#define VM40 0
#define VM39 0
#define VM38 0
#define VM37 1
#define VM36 1
#define VM35 1
#define VM34 0
#define VM33 0
#define VM32 0
#define VM31 0
#define VM30 0
#define VM29 0
#define VM28 0
#define VM27 0
#define VM26 0
#define VM25 0
#define VM24 0
#define VM23 0
#define VM22 0
#define VM21 0
#define VM20 0
#define VM19 0
#define VM18 0
#define VM17 0
#define VM16 0
#define VM15 0
#define VM14 0
#define VM13 0
#define VM12 0
#define VM11 0
#define VM10 0
#define VM9 0
#define VM8 0
#define VM7 0
#define VM6 0
#define VM5 0
#define VM4 0
#define VM3 0
#define VM2 0
#define VM1 70
static object VV[70];
static LKF0(int, ...);
static (*LK0)(int, ...)=LKF0;
static LKF1(int, ...);
static (*LK1)(int, ...)=LKF1;
static LKF2(int, ...);
static (*LK2)(int, ...)=LKF2;
