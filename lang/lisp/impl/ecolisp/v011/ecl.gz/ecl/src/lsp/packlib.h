
/* (c) Copyright G. Attardi, 1993. */
static L1();
static L4();
static L5();
static L6();
#define VT2
#define VLEX2
#define CLSR2
int Lgensym();
#define VT3
#define VLEX3
#define CLSR3
static L2(int, object);
int Llist_all_packages();
int Lfind_symbol();
#define VT4 object T0;
#define VLEX4
#define CLSR4
int Lgensym();
int Lgensym();
int Lgensym();
int Lgensym();
int Lgensym();
int Lgensym();
int Lgensym();
#define VT5
#define VLEX5
#define CLSR5
int Lgensym();
int Lgensym();
int Lgensym();
int Lgensym();
int Lgensym();
#define VT6
#define VLEX6
#define CLSR6
#define VT7
#define VLEX7
#define CLSR7
static L7(int, object, object);
int Lstring_equal();
#define VT8
#define VLEX8
#define CLSR8
static L8(int, object);
int Lfboundp();
int Lspecial_form_p();
int Lmacro_function();
int Lboundp();
int Lconstantp();
int Lsymbol_value();
#define VT9
#define VLEX9
#define CLSR9
static L9(int, object, ...);
int Lpackagep();
int Lfind_package();
int siLpackage_internal();
int siLpackage_external();
int Lpackage_use_list();
int Lpackagep();
int Lfind_package();
int siLpackage_external();
int Llist_all_packages();
int Lpackagep();
int Lfind_package();
int siLpackage_internal();
int siLpackage_external();
#define VT10
#define VLEX10
#define CLSR10
static L10(int, object, ...);
int Lpackagep();
int Lfind_package();
int siLpackage_internal();
int siLpackage_external();
int Lpackage_use_list();
int Lpackagep();
int Lfind_package();
int siLpackage_internal();
int siLpackage_external();
int Llist_all_packages();
int Lpackagep();
int Lfind_package();
int siLpackage_internal();
int siLpackage_external();
#define VT11
#define VLEX11
#define CLSR11
static struct codeblock Cblock;
#define VM11 0
#define VM10 0
#define VM9 0
#define VM8 0
#define VM7 0
#define VM6 0
#define VM5 0
#define VM4 1
#define VM3 0
#define VM2 0
#define VM1 43
static object VV[43];
static LKF0(int, ...);
static (*LK0)(int, ...)=LKF0;
static LKF1(int, ...);
static (*LK1)(int, ...)=LKF1;
