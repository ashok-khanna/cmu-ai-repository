
/* (c) Copyright G. Attardi, 1993. */
static L1();
static L3();
int siLAmake_constant();
static L9();
#define VT2
#define VLEX2
#define CLSR2
#define VT3
#define VLEX3
#define CLSR3
static L2(int, object);
#define VT4
#define VLEX4
#define CLSR4
#define VT5
#define VLEX5
#define CLSR5
static L4(int, object);
#define VT6
#define VLEX6
#define CLSR6
static L5(int, object);
int Lerror();
int Lerror();
int Lfboundp();
int Lformat();
int Lspecial_form_p();
int Lformat();
int Lmacro_function();
int Lformat();
int Lformat();
int Lgensym();
int siLfset();
int Lappend();
int Leval();
#define VT7 object T0,T1,T2;
#define VLEX7
#define CLSR7
static L6(int, object, object, object, ...);
int Lfresh_line();
int Lfloor();
int Lformat();
int Lformat();
int Lfloor();
int Lformat();
int Lformat();
int Lfloor();
int Lformat();
int Lformat();
#define VT8
#define VLEX8
#define CLSR8
static L7(int, object);
int siLfset();
int Lformat();
int Lformat();
#define VT9
#define VLEX9
#define CLSR9
static L8(int, object);
#define VT10
#define VLEX10
#define CLSR10
#define VT11
#define VLEX11
#define CLSR11
static L10(int, object);
#define VT12
#define VLEX12
#define CLSR12
static L11(int, object, ...);
int Levalhook();
int Lapplyhook();
int Levalhook();
int Levalhook();
int Levalhook();
int Lconstantp();
int Lformat();
int Lwrite();
int Levalhook();
int Llist();
int Lwrite();
int Ladjoin();
int Ladjoin();
int Lformat();
int Lformat();
int Lwrite();
int Lvalues_list();
#define VT13 object T0;
#define VLEX13
#define CLSR13 object env0, *CLV0,*CLV1;
static LC12(int, object);
int Lformat();
int Lwrite();
#define VT14
#define VLEX14
#define CLSR14 object *CLV0,*CLV1;
static L13(int);
int Llist();
#define VT15
#define VLEX15
#define CLSR15
static L14(int, ...);
int Lerror();
int Llist();
#define VT16
#define VLEX16
#define CLSR16
static L15(int);
int Lwrite();
#define VT17
#define VLEX17
#define CLSR17
static L16(int);
int Llist();
#define VT18
#define VLEX18
#define CLSR18
static L17(int, ...);
#define VT19
#define VLEX19
#define CLSR19
static struct codeblock Cblock;
#define VM19 0
#define VM18 0
#define VM17 0
#define VM16 0
#define VM15 0
#define VM14 0
#define VM13 1
#define VM12 0
#define VM11 0
#define VM10 0
#define VM9 0
#define VM8 0
#define VM7 3
#define VM6 0
#define VM5 0
#define VM4 0
#define VM3 0
#define VM2 0
#define VM1 112
static object VV[112];
static LKF0(int, ...);
static (*LK0)(int, ...)=LKF0;
static LKF1(int, ...);
static (*LK1)(int, ...)=LKF1;
static LKF2(int, ...);
static (*LK2)(int, ...)=LKF2;
