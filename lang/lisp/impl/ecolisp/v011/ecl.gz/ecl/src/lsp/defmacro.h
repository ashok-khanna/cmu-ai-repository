
/* (c) Copyright G. Attardi, 1993. */
static L1();
#define VT2
#define VLEX2
#define CLSR2
#define VT3
#define VLEX3
#define CLSR3
static L2(int, object, object, object);
int Lerror();
int Lgensym();
int Lldiff();
int Lgensym();
#define VT4 object T0;
#define VLEX4
#define CLSR4
static LC6(int, object , object );
int Lfloor();
#define VT5
#define VLEX5
#define CLSR5
static LC5(int, object , object );
int Lfloor();
#define VT6
#define VLEX6
#define CLSR6
static LC4(int, object , object );
int Lgensym();
#define VT7
#define VLEX7
#define CLSR7
static LC3(int, object , object , object );
int Lgensym();
int Lgensym();
int Lintern();
int Lintern();
#define VT8 object T0;
#define VLEX8
#define CLSR8
static L7(int, object);
int Lerror();
#define VT9
#define VLEX9
#define CLSR9
static L8(int);
int Lerror();
#define VT10
#define VLEX10
#define CLSR10
static L9(int);
int Lerror();
#define VT11
#define VLEX11
#define CLSR11
static L10(int, object);
int Lerror();
#define VT12
#define VLEX12
#define CLSR12
static L11(int, object, object);
int Lmacroexpand();
#define VT13
#define VLEX13
#define CLSR13
static L12(int, object);
int Lmacroexpand();
#define VT14
#define VLEX14
#define CLSR14
static struct codeblock Cblock;
#define VM14 0
#define VM13 0
#define VM12 0
#define VM11 0
#define VM10 0
#define VM9 0
#define VM8 1
#define VM7 0
#define VM6 0
#define VM5 0
#define VM4 1
#define VM3 0
#define VM2 0
#define VM1 65
static object VV[65];
