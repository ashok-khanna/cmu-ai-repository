
#include "combin.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	MF0(VV[47],L1);
	(void)putprop(VV[47],VV[Vdeb47],VV[48]);
	MF0(VV[49],L2);
	(void)putprop(VV[49],VV[Vdeb49],VV[48]);
	VV[0]->s.s_stype=(short)stp_special;
	if(VV[0]->s.s_dbind == OBJNULL){
	(VV[0]->s.s_dbind)= Cnil;}
	MF0(VV[50],L3);
	(void)putprop(VV[50],VV[Vdeb50],VV[48]);
	MF0(VV[51],L5);
	(void)putprop(VV[51],VV[Vdeb51],VV[48]);
	VV[52] = make_cfun(LC7,Cnil,&Cblock);
	MF0(VV[10],L6);
	(void)putprop(VV[10],VV[Vdeb10],VV[48]);
	MF0(VV[53],L8);
	(void)putprop(VV[53],VV[Vdeb53],VV[48]);
	MM0(VV[54],L9);
	MF0(VV[55],L10);
	(void)putprop(VV[55],VV[Vdeb55],VV[48]);
	MF0(VV[56],L12);
	(void)putprop(VV[56],VV[Vdeb56],VV[48]);
	MF0(VV[4],L13);
	(void)putprop(VV[4],VV[Vdeb4],VV[48]);
	MF0(VV[19],L16);
	(void)putprop(VV[19],VV[Vdeb19],VV[48]);
	MF0(VV[15],L17);
	(void)putprop(VV[15],VV[Vdeb15],VV[48]);
	MF0(VV[57],L20);
	(void)putprop(VV[57],VV[Vdeb57],VV[48]);
	VV[20]->s.s_stype=(short)stp_special;
	if(VV[20]->s.s_dbind == OBJNULL){
	(VV[20]->s.s_dbind)= Cnil;}
	VV[21]->s.s_stype=(short)stp_special;
	if(VV[21]->s.s_dbind == OBJNULL){
	(VV[21]->s.s_dbind)= Cnil;}
	{register int V1;                         /*  I               */
	V1= 0;
L7:
	if(!((V1)>=(fix(MAKE_FIXNUM(10))))){
	goto L8;}
	goto L4;
L8:
	Lformat(3,Cnil,VV[22],MAKE_FIXNUM((9)-(V1)))/*  FORMAT        */;
	Lmake_symbol(1,VALUES(0))                 /*  MAKE-SYMBOL     */;
	(VV[20]->s.s_dbind)= CONS(VALUES(0),(VV[20]->s.s_dbind));
	Lformat(3,Cnil,VV[23],MAKE_FIXNUM((9)-(V1)))/*  FORMAT        */;
	Lmake_symbol(1,VALUES(0))                 /*  MAKE-SYMBOL     */;
	(VV[21]->s.s_dbind)= CONS(VALUES(0),(VV[21]->s.s_dbind));
	V1= (V1)+1;
	goto L7;
	}
L4:
	MF0(VV[58],L21);
	(void)putprop(VV[58],VV[Vdeb58],VV[48]);
	MF0(VV[59],L23);
	(void)putprop(VV[59],VV[Vdeb59],VV[48]);
	MF0(VV[60],L24);
	(void)putprop(VV[60],VV[Vdeb60],VV[48]);
	MF0(VV[61],L25);
	(void)putprop(VV[61],VV[Vdeb61],VV[48]);
	MF0(VV[62],L27);
	(void)putprop(VV[62],VV[Vdeb62],VV[48]);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	local function CLOSURE                                        */
static LC7(int narg, object V1, object V2)
{ VT3 VLEX3 CLSR3
	if(((V1))==(VV[4])){
	goto L22;}
	VALUES(0) = Cnil;
	RETURN(1);
L22:
	VALUES(0) = (((((V1))==((V2))?Ct:Cnil))==Cnil?Ct:Cnil);
	RETURN(1);
}
/*	function definition for GET-METHOD-QUALIFIERS                 */
static L1(int narg, object V1)
{ VT4 VLEX4 CLSR4
TTL:
	VALUES(0) = CADR((V1));
	RETURN(1);
}
/*	function definition for GET-METHOD-FUNCTION                   */
static L2(int narg, object V1)
{ VT5 VLEX5 CLSR5
TTL:
	VALUES(0) = CAR(CDDDDR((V1)));
	RETURN(1);
}
/*	function definition for MAKE-EFFECTIVE-METHOD-FUNCTION        */
static L3(int narg, object V1)
{ VT6 VLEX6 CLSR6
	bds_check;
TTL:
	if(!(type_of((V1))==t_cons||(V1)==Cnil)){
	goto L25;}
	if(!((CAR((V1)))==(VV[1]))){
	goto L25;}
	(*LK0)(1,CADR((V1)))                      /*  METHOD-P        */;
	if(VALUES(0)==Cnil){
	goto L25;}
	T0= (VV[65]->s.s_gfdef);
	(*LK1)(2,T0,CADDR((V1)))                  /*  EVERY           */;
	if(VALUES(0)==Cnil){
	goto L25;}
	{object V2;
	(*LK2)(1,CADR((V1)))                      /*  GET-METHOD-FUNCTION*/;
	V2= VALUES(0);
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(V2,env0));            /*  METHOD-FUNCTION */
	(*LK3)(1,CADR((V1)))                      /*  METHOD-NEEDS-NEXT-METHODS-P*/;
	if(VALUES(0)==Cnil){
	goto L36;}
	{object V3;object env1 = env0;
	T1=VV[49]->s.s_gfdef;
	{object V4;
	object V5= CADDR((V1));
	if(V5==Cnil){
	V3= Cnil;
	goto L38;}
	T0=V4=CONS(Cnil,Cnil);
L39:
	(*LK2)(1,CAR(V5))                         /*  GET-METHOD-FUNCTION*/;
	CAR(V4)= VALUES(0);
	if((V5=CDR(V5))==Cnil){
	V3= T0;
	goto L38;}
	V4=CDR(V4)=CONS(Cnil,Cnil);
	goto L39;}
L38:
	CLV1=&CAR(env1=CONS(V3,env1));            /*  NEXT-METHOD-FUNCTIONS*/
	VALUES(0) = make_cclosure(LC4,env1,&Cblock);
	RETURN(1);
	}
L36:
	VALUES(0) = *CLV0;
	RETURN(1);
	}
L25:
	L5(1,(V1))                                /*  GET-EFFECTIVE-METHOD-CODE-CONSTRUCTOR*/;
	T0= VALUES(0);
	RETURN(funcall(2,T0,(V1)));
}
/*	closure CLOSURE                                               */
static LC4(int narg, object env0, ...)
{ VT7 VLEX7 CLSR7
	narg--;
	{object scan=env0;
	CLV1= &CAR(scan);                         /*  NEXT-METHOD-FUNCTIONS*/ scan=CDR(scan);
	CLV0= &CAR(scan);                         /*  METHOD-FUNCTION */}
	{object V1;
	va_list args; va_start(args, env0);
	narg -=0;
	V1=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V1;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	bds_bind(VV[2],*CLV1);                    /*  *NEXT-METHODS*  */
	{int V2;
	V2=Lapply(2,*CLV0,(V1))                   /*  APPLY           */;
	bds_unwind1;
	RETURN(V2);}
	}
}
/*	function definition for GET-EFFECTIVE-METHOD-CODE-CONSTRUCTOR */
static L5(int narg, object V1)
{ VT8 VLEX8 CLSR8
TTL:
	{register object V2;                      /*  ENTRY           */
	V2= Cnil;
	{register object V3;
	register object V4;                       /*  E               */
	V3= (VV[0]->s.s_dbind);
	V4= Cnil;
L46:
	if(!((V3)==Cnil)){
	goto L47;}
	goto L42;
L47:
	V4= CAR((V3));
	{object V6;                               /*  MATCHP          */
	T0= symbol_function(CADR((V4)));
	funcall(3,T0,CAR((V4)),(V1));
	V6= VALUES(0);
	if(((V6))==Cnil){
	goto L52;}
	V2= (V4);
	goto L42;
	}
L52:
	V3= CDR((V3));
	goto L46;
	}
L42:
	if(((V2))!=Cnil){
	goto L61;}
	L8(1,(V1))                                /*  COMPILE-EFFECTIVE-METHOD-TEMPLATE-ENTRY*/;
	V2= VALUES(0);
	L6(1,(V2))                                /*  ADD-EFFECTIVE-METHOD-TEMPLATE-ENTRY*/;
L61:
	{object V3;
	object V4;
	V3= CDDDDR((V2));
	V4= number_plus(CAR((V3)),MAKE_FIXNUM(1));
	CAR((V3)) = (V4);
	}
	VALUES(0) = CADDR((V2));
	RETURN(1);
	}
}
/*	function definition for ADD-EFFECTIVE-METHOD-TEMPLATE-ENTRY   */
static L6(int narg, object V1)
{ VT9 VLEX9 CLSR9
TTL:
	{object V2= (VV[0]->s.s_dbind);
	{object V3= CONS((V1),Cnil);
	T0= VV[52];
	VALUES(0) = (VV[70]->s.s_gfdef);
	(*LK4)(6,VV[3],V2,V3,T0,VV[5],VALUES(0))  /*  MERGE           */;
	(VV[0]->s.s_dbind)= VALUES(0);}}
	VALUES(0) = (VV[0]->s.s_dbind);
	RETURN(1);
}
/*	function definition for COMPILE-EFFECTIVE-METHOD-TEMPLATE-ENTRY*/
static L8(int narg, object V1)
{ VT10 VLEX10 CLSR10
TTL:
	{ int V2;
	object V3;                                /*  TEMPLATE        */
	object V4;                                /*  PREDICATE       */
	object V5;                                /*  CONSTRUCTOR     */
	V2=L10(1,(V1))                            /*  COMPILE-EFFECTIVE-METHOD-TEMPLATE-ENTRY-INTERNAL*/;
	if (V2==0) goto L74;
	V3= VALUES(0);
	V2--;
	if (V2==0) goto L75;
	V4= VALUES(1);
	V2--;
	if (V2==0) goto L76;
	V5= VALUES(2);
	V2--;
	goto L77;
L74:
	V3= Cnil;
L75:
	V4= Cnil;
L76:
	V5= Cnil;
L77:
	(*LK5)(2,Cnil,(V5))                       /*  COMPILE         */;
	VALUES(0) = list(5,(V3),(V4),VALUES(0),VV[6],MAKE_FIXNUM(0));
	RETURN(1);}
}
/*	macro definition for PRECOMPILE-EFFECTIVE-METHOD-TEMPLATE-1   */
static L9(int narg, object V1, object V2)
{ VT11 VLEX11 CLSR11
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	if(endp(V3)){
	V5= VV[7];
	} else {
	V5= CAR(V3);}
	{ int V6;
	object V7;                                /*  TEMPLATE        */
	object V8;                                /*  PREDICATE       */
	object V9;                                /*  CONSTRUCTOR     */
	V6=L10(1,(V4))                            /*  COMPILE-EFFECTIVE-METHOD-TEMPLATE-ENTRY-INTERNAL*/;
	if (V6==0) goto L81;
	V7= VALUES(0);
	V6--;
	if (V6==0) goto L82;
	V8= VALUES(1);
	V6--;
	if (V6==0) goto L83;
	V9= VALUES(2);
	V6--;
	goto L84;
L81:
	V7= Cnil;
L82:
	V8= Cnil;
L83:
	V9= Cnil;
L84:
	{object V10= list(2,VV[11],(V7));
	{object V11= list(2,VV[11],(V8));
	{object V12= list(2,VV[12],(V9));
	VALUES(0) = list(3,VV[8],VV[9],list(2,VV[10],list(6,VV[3],V10,V11,V12,list(2,VV[11],(V5)),MAKE_FIXNUM(0))));
	RETURN(1);}}}}}
}
/*	function definition for COMPILE-EFFECTIVE-METHOD-TEMPLATE-ENTRY-INTERNAL*/
static L10(int narg, object V1)
{ VT12 VLEX12 CLSR12
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(V1,env0));            /*  FORM            */
	{object V2;                               /*  WALKED-FORM     */
	CLV1=&CAR(env0=CONS(Cnil,env0));          /*  COMPLEXP        */
	VALUES(0) = make_cclosure(LC11,env0,&Cblock);
	(*LK6)(3,*CLV0,Cnil,VALUES(0))            /*  WALK-FORM       */;
	V2= VALUES(0);
	if((*CLV1)==Cnil){
	goto L88;}
	(*LK7)(1,*CLV0)                           /*  MAKE-COMPLEX-EFFECTIVE-METHOD-CODE-CONSTRUCTOR*/;
	VALUES(2) = VALUES(0);
	VALUES(1) = VV[15];
	VALUES(0) = *CLV0;
	RETURN(3);
L88:
	L20(1,*CLV0)                              /*  MAKE-SIMPLE-EFFECTIVE-METHOD-CODE-CONSTRUCTOR*/;
	VALUES(2) = VALUES(0);
	VALUES(1) = VV[4];
	VALUES(0) = (V2);
	RETURN(3);
	}
}
/*	closure CLOSURE                                               */
static LC11(int narg, object env0, object V1, object V2, object V3)
{ VT13 VLEX13 CLSR13
	narg--;
	{object scan=env0;
	CLV1= &CAR(scan);                         /*  COMPLEXP        */ scan=CDR(scan);
	CLV0= &CAR(scan);                         /*  FORM            */}
	L12(1,*CLV0)                              /*  FORCES-COMPLEX-WALKER-P*/;
	if(VALUES(0)==Cnil){
	goto L92;}
	*CLV1= Ct;
L92:
	if(type_of((V1))==t_cons){
	goto L97;}
	VALUES(0) = (V1);
	RETURN(1);
L97:
	{object V4;                               /*  FN              */
	V4= CAR((V1));
	if(!(((V4))==(VV[1]))){
	goto L101;}
	if(!((length((V1)))==(3))){
	goto L104;}
	VALUES(0) = VV[13];
	RETURN(1);
L104:
	RETURN(Lerror(1,VV[14])                   /*  ERROR           */);
L101:
	VALUES(0) = (V1);
	RETURN(1);
	}
}
/*	function definition for FORCES-COMPLEX-WALKER-P               */
static L12(int narg, object V1)
{ VT14 VLEX14 CLSR14
TTL:
	if(type_of((V1))==t_cons||(V1)==Cnil){
	goto L106;}
	VALUES(0) = Cnil;
	RETURN(1);
L106:
	{register object x= CAR((V1)),V2= VV[16];
	while(V2!=Cnil)
	if(eql(x, CAR(V2))){
	goto L108;
	}else V2=CDR(V2);}
	VALUES(0) = Cnil;
	RETURN(1);
L108:
	Lfboundp(1,CAR((V1)))                     /*  FBOUNDP         */;
	if(VALUES(0)!=Cnil){
	goto L111;}
	VALUES(0) = Cnil;
	goto L110;
L111:
	Lmacro_function(1,CAR((V1)))              /*  MACRO-FUNCTION  */;
	VALUES(0) = ((VALUES(0))==Cnil?Ct:Cnil);
L110:
	VALUES(0) = ((VALUES(0))==Cnil?Ct:Cnil);
	RETURN(1);
}
/*	function definition for SIMPLE-EFFECTIVE-METHOD-MATCH-P       */
static L13(int narg, object V1, object V2)
{ VT15 VLEX15 CLSR15
TTL:
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  WALK            */
	*CLV0=make_cclosure(LC15,env0,&Cblock);
	RETURN(LC15(2, env0,(V1),(V2))            /*  WALK            */);
}
/*	local function EVERY*                                         */
static LC14(int narg, object V1, object V2, object V3)
{ VT16 VLEX16 CLSR16
TTL:
	{register object V4;                      /*  T1              */
	register object V5;                       /*  T2              */
	V4= (V2);
	V5= (V3);
L115:
	if(((V4))!=Cnil){
	goto L119;}
	VALUES(0) = ((V5)==Cnil?Ct:Cnil);
	RETURN(1);
L119:
	if(((V5))!=Cnil){
	goto L122;}
	VALUES(0) = ((V4)==Cnil?Ct:Cnil);
	RETURN(1);
L122:
	{object V8;
	funcall(3,(V1),CAR((V4)),CAR((V5)));
	V8= VALUES(0);
	if(((V8))==Cnil){
	goto L126;}
	goto L117;
L126:
	VALUES(0) = Cnil;
	RETURN(1);
	}
L117:
	V4= CDR((V4));
	V5= CDR((V5));
	goto L115;
	}
}
/*	closure WALK                                                  */
static LC15(int narg, object env0, object V1, object V2)
{ VT17 VLEX17 CLSR17
	narg--;
	{object scan=env0;
	CLV0= &CAR(scan);                         /*  WALK            */}
TTL:
	if(!(((V1))==((V2)))){
	goto L133;}
	VALUES(0) = Ct;
	RETURN(1);
L133:
	if(!(type_of((V1))==t_cons||(V1)==Cnil)){
	goto L136;}
	if(!(type_of((V2))==t_cons||(V2)==Cnil)){
	goto L136;}
	if(!((CAR((V2)))==(VV[1]))){
	goto L141;}
	VALUES(0) = ((CAR((V1)))==(VV[17])?Ct:Cnil);
	RETURN(1);
L141:
	RETURN(LC14(3,*CLV0,(V1),(V2))            /*  EVERY*          */);
L136:
	if(!(type_of((V1))==t_string)){
	goto L144;}
	if(!(type_of((V2))==t_string)){
	goto L144;}
	RETURN(Lstring_equal(2,(V1),(V2))         /*  STRING-EQUAL    */);
L144:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for SIMPLE-CODE-WALKER                    */
static L16(int narg, object V1, object V2, object V3)
{ VT18 VLEX18 CLSR18
TTL:
	if(((V1))!=Cnil){
	goto L149;}
	VALUES(0) = Cnil;
	RETURN(1);
L149:
	if(!(type_of((V1))==t_cons||(V1)==Cnil)){
	goto L152;}
	{ int V4;
	if ((V4=frs_push(FRS_CATCH,(V1)))==0) {
	{object V5;                               /*  NEW             */
	funcall(4,(V3),(V1),VV[18],Cnil);
	V5= VALUES(0);
	L16(3,CAR((V5)),(V2),(V3))                /*  SIMPLE-CODE-WALKER*/;
	T0= VALUES(0);
	L16(3,CDR((V5)),(V2),(V3))                /*  SIMPLE-CODE-WALKER*/;
	V4=(*LK8)(3,(V5),T0,VALUES(0))            /*  RECONS          */;
	}
	}
	else V4--;
	frs_pop();
	RETURN(V4);}
L152:
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for COMPLEX-EFFECTIVE-METHOD-MATCH-P      */
static L17(int narg, object V1, object V2)
{ VT19 VLEX19 CLSR19
TTL:
	L13(2,(V1),(V2))                          /*  SIMPLE-EFFECTIVE-METHOD-MATCH-P*/;
	if(VALUES(0)!=Cnil){
	goto L159;}
	VALUES(0) = Cnil;
	RETURN(1);
L159:
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  TRAIL1          */
	CLV1=&CAR(env0=CONS(Cnil,env0));          /*  TRAIL2          */
	VALUES(0) = make_cclosure(LC18,env0,&Cblock);
	(*LK6)(3,(V1),Cnil,VALUES(0))             /*  WALK-FORM       */;
	VALUES(0) = make_cclosure(LC19,env0,&Cblock);
	(*LK6)(3,(V2),Cnil,VALUES(0))             /*  WALK-FORM       */;
	VALUES(0) = (equal(*CLV0,*CLV1)?Ct:Cnil);
	RETURN(1);
}
/*	closure CLOSURE                                               */
static LC18(int narg, object env0, object V1, object V2, object V3)
{ VT20 VLEX20 CLSR20
	narg--;
	{object scan=env0; scan=CDR(scan);
	CLV0= &CAR(scan);                         /*  TRAIL1          */}
	*CLV0= CONS(CONS((V2),(V1)),*CLV0);
	VALUES(0) = (V1);
	RETURN(1);
}
/*	closure CLOSURE                                               */
static LC19(int narg, object env0, object V1, object V2, object V3)
{ VT21 VLEX21 CLSR21
	narg--;
	{object scan=env0;
	CLV1= &CAR(scan);                         /*  TRAIL2          */}
	*CLV1= CONS(CONS((V2),(V1)),*CLV1);
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for MAKE-SIMPLE-EFFECTIVE-METHOD-CODE-CONSTRUCTOR*/
static L20(int narg, object V1)
{ VT22 VLEX22 CLSR22
TTL:
	RETURN(L21(2,VV[19],(V1))                 /*  MAKE-CODE-CONSTRUCTOR*/);
}
/*	function definition for MAKE-CODE-CONSTRUCTOR                 */
static L21(int narg, object V1, object V2)
{ VT23 VLEX23 CLSR23
TTL:
	{object V3;                               /*  CODE-BODY       */
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  METHOD-VARS     */
	V3= Cnil;
	CLV1=&CAR(env0=CONS((VV[20]->s.s_dbind),env0));/*  NEXT-METHOD-GENSYMS*/
	CLV2=&CAR(env0=CONS((VV[21]->s.s_dbind),env0));/*  METHOD-FUNCTION-GENSYMS*/
	{ object V4;
	V4= make_cclosure(LC22,env0,&Cblock);
	funcall(4,(V1),(V2),Cnil,(V4));
	V3= VALUES(0);
	{object V5= CONS(VV[27],*CLV0);
	{object V6= listA(3,VV[28],list(2,VV[11],(V1)),VV[29]);
	{register object V7;                      /*  MVS             */
	register object V8;                       /*  SETQS           */
	V7= *CLV0;
	V8= Cnil;
L174:
	if(((V7))!=Cnil){
	goto L175;}
	T0= nreverse((V8));
	goto L172;
L175:
	V8= CONS(list(3,VV[30],CAR((V7)),VV[31]),(V8));
	V8= CONS(list(3,VV[30],CADR((V7)),VV[32]),(V8));
	V7= CDDR((V7));
	goto L174;
	}
L172:
	VALUES(0) = list(3,VV[24],VV[25],listA(4,VV[26],V5,V6,append(T0,CONS(list(2,VV[12],list(3,VV[24],VV[33],(V3))),Cnil))));
	RETURN(1);}}
	}
	}
}
/*	closure CONVERT-FUNCTION                                      */
static LC22(int narg, object env0, object V1, object V2, object V3)
{ VT24 VLEX24 CLSR24
	narg--;
	{object scan=env0;
	CLV2= &CAR(scan);                         /*  METHOD-FUNCTION-GENSYMS*/ scan=CDR(scan);
	CLV1= &CAR(scan);                         /*  NEXT-METHOD-GENSYMS*/ scan=CDR(scan);
	CLV0= &CAR(scan);                         /*  METHOD-VARS     */}
TTL:
	if(!(type_of((V1))==t_cons||(V1)==Cnil)){
	goto L186;}
	if(!(((V2))==(VV[18]))){
	goto L186;}
	if((CAR((V1)))==(VV[17])){
	goto L190;}
	if(!((CAR((V1)))==(VV[1]))){
	goto L191;}
L190:
	{object V4;                               /*  GENSYM1         */
	object V5;
	object V6;                                /*  GENSYM2         */
	{object V7;
	V7= CAR(*CLV2);
	*CLV2= CDR(*CLV2);
	VALUES(0) = (V7);
	}
	if(VALUES(0)==Cnil)goto L196;
	V5= VALUES(0);
	goto L195;
L196:
	Lgensym(0)                                /*  GENSYM          */;
	V5= VALUES(0);
L195:
	{object V7;
	V7= CAR(*CLV1);
	*CLV1= CDR(*CLV1);
	VALUES(0) = (V7);
	}
	if(VALUES(0)==Cnil)goto L202;
	V6= VALUES(0);
	goto L201;
L202:
	Lgensym(0)                                /*  GENSYM          */;
	V6= VALUES(0);
L201:
	V4= V5;
	*CLV0= CONS((V4),*CLV0);
	*CLV0= CONS((V6),*CLV0);
	{object V7= CONS(list(2,VV[2],(V6)),Cnil);
	VALUES(0) = list(4,VV[26],V7,VV[34],list(3,VV[35],(V4),VV[36]));
	RETURN(1);}
	}
L191:
	VALUES(0) = (V1);
	RETURN(1);
L186:
	(*LK0)(1,(V1))                            /*  METHOD-P        */;
	if(VALUES(0)==Cnil){
	goto L212;}
	RETURN(Lerror(1,VV[37])                   /*  ERROR           */);
L212:
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for CONVERT-EFFECTIVE-METHOD              */
static L23(int narg, object V1)
{ VT25 VLEX25 CLSR25
TTL:
	(*LK0)(1,(V1))                            /*  METHOD-P        */;
	if(VALUES(0)==Cnil){
	goto L215;}
	RETURN((*LK2)(1,(V1))                     /*  GET-METHOD-FUNCTION*/);
L215:
	if(!(type_of((V1))==t_cons||(V1)==Cnil)){
	goto L218;}
	if(!((CAR((V1)))==(VV[38]))){
	goto L218;}
	Lformat(3,Ct,VV[39],(V1))                 /*  FORMAT          */;
	L25(1,CADR((V1)))                         /*  MAKE-PROGN      */;
	RETURN(L3(1,VALUES(0))                    /*  MAKE-EFFECTIVE-METHOD-FUNCTION*/);
L218:
	RETURN(Lerror(1,VV[40])                   /*  ERROR           */);
}
/*	function definition for MAKE-METHOD-CALL                      */
static L24(int narg, object V1, ...)
{ VT26 VLEX26 CLSR26
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if (i==narg) goto L224;
	V2= va_arg(args, object);
	i++;
	goto L225;
L224:
	V2= Cnil;
L225:
	VALUES(0) = list(3,VV[1],(V1),(V2));
	RETURN(1);
	}
}
/*	function definition for MAKE-PROGN                            */
static L25(int narg, ...)
{ VT27 VLEX27 CLSR27
	{object V1;
	va_list args; va_start(args, narg);
	narg -=0;
	V1=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V1;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	lex0[0]=Cnil;                             /*  PROGN-FORM      */
	LC26(lex0,1,(V1))                         /*  COLLECT-FORMS   */;
	VALUES(0) = CONS(VV[41],lex0[0]);
	RETURN(1);
	}
}
/*	local function COLLECT-FORMS                                  */
static LC26(object *lex0,int narg, object V1)
{ VT28 VLEX28 CLSR28
TTL:
	if(((V1))==Cnil){
	goto L229;}
	LC26(lex0,1,CDR((V1)))                    /*  COLLECT-FORMS   */;
	{object V2= CAR((V1));
	if(!(type_of(V2)==t_cons||V2==Cnil)){
	goto L233;}}
	if(!((CAAR((V1)))==(VV[41]))){
	goto L233;}
	V1= CDAR((V1));
	goto TTL;
L233:
	lex0[0]= CONS(CAR((V1)),lex0[0]);
	VALUES(0) = lex0[0];
	RETURN(1);
L229:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for COMPUTE-COMBINED-METHOD               */
static L27(int narg, object V1, object V2)
{ VT29 VLEX29 CLSR29
TTL:
	{register object V3;                      /*  BEFORE          */
	register object V4;                       /*  PRIMARY         */
	register object V5;                       /*  AFTER           */
	register object V6;                       /*  AROUND          */
	V3= Cnil;
	V4= Cnil;
	V5= Cnil;
	V6= Cnil;
	{object V7;
	register object V8;                       /*  M               */
	V7= (V2);
	V8= Cnil;
L244:
	if(!((V7)==Cnil)){
	goto L245;}
	goto L240;
L245:
	V8= CAR((V7));
	{object V10;                              /*  QUALIFIERS      */
	(*LK9)(1,(V8))                            /*  GET-METHOD-QUALIFIERS*/;
	V10= VALUES(0);
	{register object x= VV[42],V11= (V10);
	while(V11!=Cnil)
	if(eql(x, CAR(V11))){
	goto L254;
	}else V11=CDR(V11);
	goto L253;}
L254:
	V3= CONS((V8),(V3));
	goto L250;
L253:
	{register object x= VV[43],V11= (V10);
	while(V11!=Cnil)
	if(eql(x, CAR(V11))){
	goto L258;
	}else V11=CDR(V11);
	goto L257;}
L258:
	V5= CONS((V8),(V5));
	goto L250;
L257:
	{register object x= VV[44],V11= (V10);
	while(V11!=Cnil)
	if(eql(x, CAR(V11))){
	goto L262;
	}else V11=CDR(V11);
	goto L261;}
L262:
	V6= CONS((V8),(V6));
	goto L250;
L261:
	V4= CONS((V8),(V4));
	}
L250:
	V7= CDR((V7));
	goto L244;
	}
L240:
	V3= nreverse((V3));
	V4= nreverse((V4));
	V6= nreverse((V6));
	if(((V3))!=Cnil){
	goto L278;}
	if(((V5))!=Cnil){
	goto L278;}
	if(((V6))!=Cnil){
	goto L283;}
	VALUES(0) = list(3,VV[1],CAR((V4)),CDR((V4)));
	goto L276;
L283:
	{object V7= CAR((V6));
	VALUES(0) = list(3,VV[1],V7,append(CDR((V6)),(V4)));
	goto L276;}
L278:
	{object V8;                               /*  MAIN-COMBINED-METHOD*/
	{object V9;
	object V10= (V3);
	if(V10==Cnil){
	T0= Cnil;
	goto L286;}
	T1=V9=CONS(Cnil,Cnil);
L287:
	L24(1,CAR(V10))                           /*  MAKE-METHOD-CALL*/;
	CAR(V9)= VALUES(0);
	if((V10=CDR(V10))==Cnil){
	T0= T1;
	goto L286;}
	V9=CDR(V9)=CONS(Cnil,Cnil);
	goto L287;}
L286:
	if(((V4))==Cnil){
	goto L291;}
	T1= list(3,VV[1],CAR((V4)),CDR((V4)));
	goto L289;
L291:
	T1= VV[46];
L289:
	{object V9;
	object V10= (V5);
	if(V10==Cnil){
	VALUES(0) = Cnil;
	goto L293;}
	T2=V9=CONS(Cnil,Cnil);
L294:
	L24(1,CAR(V10))                           /*  MAKE-METHOD-CALL*/;
	CAR(V9)= VALUES(0);
	if((V10=CDR(V10))==Cnil){
	VALUES(0) = T2;
	goto L293;}
	V9=CDR(V9)=CONS(Cnil,Cnil);
	goto L294;}
L293:
	V8= CONS(VV[41],append(T0,CONS(listA(3,VV[45],T1,VALUES(0)),Cnil)));
	if(((V6))==Cnil){
	goto L297;}
	{object V9= CAR((V6));
	{object V10= CDR((V6));
	VALUES(0) = list(3,VV[1],V9,append(V10,CONS(list(2,VV[38],(V8)),Cnil)));
	goto L276;}}
L297:
	VALUES(0) = (V8);
	}
L276:
	RETURN(L3(1,VALUES(0))                    /*  MAKE-EFFECTIVE-METHOD-FUNCTION*/);
	}
}
static LKF9(int narg, ...) {TRAMPOLINK(VV[47],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[80],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[76],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[75],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[73],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[71],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[67],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[49],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[66],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[65],&LK0);}
