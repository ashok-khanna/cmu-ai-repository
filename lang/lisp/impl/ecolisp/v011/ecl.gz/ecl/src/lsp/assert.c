
/* (c) Copyright G. Attardi, 1993. All rights reserved. */
#include <ecl.h>
#include "assert.h"
init_assert(int size, object data_stream)
{VT2 CLSR2
	Cblock.cd_start=NULL; Cblock.cd_size=size;
	Cblock.cd_data=read_VV(VV,VM1,data_stream);
	funcall(2,symbol_function(VV[57]),VV[0])  /*  PROCLAIM        */;
	MM0(VV[58],L1);
	MM0(VV[59],L2);
	MF0(VV[60],L3);
	MM0(VV[61],L4);
	MM0(VV[62],L7);
	MM0(VV[63],L11);
	MM0(VV[64],L12);
	MM0(VV[65],L14);
	MF0(VV[36],L17);
	MF0(VV[66],L19);
}
/*	macro definition for CHECK-TYPE                               */
static L1(int narg, object V1, object V2)
{ VT3 VLEX3 CLSR3
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6,V7;
	if(endp(V3))FEinvalid_macro_call(VV[58]);
	V4= CAR(V3);
	V3=CDR(V3);
	if(endp(V3))FEinvalid_macro_call(VV[58]);
	V5= CAR(V3);
	V3=CDR(V3);
	if(endp(V3)){
	V6= Cnil;
	V7= Cnil;
	} else {
	V6= CAR(V3);
	V7= Ct;
	V3=CDR(V3);}
	if(!endp(V3))FEinvalid_macro_call(VV[58]);
	{object V8= list(2,list(3,VV[3],(V4),list(2,VV[4],(V5))),Cnil);
	{object V9= list(2,VV[4],(V4));
	if(((V7))==Cnil){
	goto L5;}
	VALUES(0) = (V6);
	goto L3;
L5:
	VALUES(0) = list(2,VV[4],(V5));
L3:
	{object V10= list(6,VV[5],VV[6],VV[7],V9,(V4),VALUES(0));
	L3(1,(V4))                                /*  ASK-FOR-FORM    */;
	VALUES(0) = list(6,VV[1],VV[2],V8,V10,VALUES(0),VV[8]);
	RETURN(1);}}}}
}
/*	macro definition for ASSERT                                   */
static L2(int narg, object V1, object V2)
{ VT4 VLEX4 CLSR4
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6,V7;
	if(endp(V3))FEinvalid_macro_call(VV[59]);
	V4= CAR(V3);
	V3=CDR(V3);
	if(endp(V3)){
	V5= Cnil;
	} else {
	V5= CAR(V3);
	V3=CDR(V3);}
	if(endp(V3)){
	V6= Cnil;
	} else {
	V6= CAR(V3);
	V3=CDR(V3);}
	V7= V3;
	{object V8= list(2,(V4),Cnil);
	if(((V6))==Cnil){
	goto L12;}
	T0= listA(4,VV[5],VV[10],(V6),(V7));
	goto L10;
L12:
	T0= list(4,VV[5],VV[11],VV[12],list(2,VV[4],(V4)));
L10:
	{object V9;
	object V10= (V5);
	if(endp(V10)){
	VALUES(0) = Cnil;
	goto L14;}
	T1=V9=CONS(Cnil,Cnil);
L15:
	L3(1,CAR(V10))                            /*  ASK-FOR-FORM    */;
	CAR(V9)= VALUES(0);
	if(endp(V10=CDR(V10))){
	VALUES(0) = T1;
	goto L14;}
	V9=CDR(V9)=CONS(Cnil,Cnil);
	goto L15;}
L14:
	VALUES(0) = listA(5,VV[1],VV[9],V8,T0,append(VALUES(0),VV[13]));
	RETURN(1);}}
}
/*	function definition for ASK-FOR-FORM                          */
static L3(int narg, object V1)
{ VT5 VLEX5 CLSR5
	cs_check;
	check_arg(1);
TTL:
	{object V2= list(4,VV[15],VV[16],VV[17],list(2,VV[4],(V1)));
	VALUES(0) = list(4,VV[14],V2,VV[18],list(3,VV[19],(V1),VV[20]));
	RETURN(1);}
}
/*	macro definition for ECASE                                    */
static L4(int narg, object V1, object V2)
{ VT6 VLEX6 CLSR6
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6;
	if(endp(V3))FEinvalid_macro_call(VV[61]);
	V4= CAR(V3);
	V3=CDR(V3);
	V5= V3;
	Lgensym(0)                                /*  GENSYM          */;
	V6= VALUES(0);
	{register object V7;                      /*  L               */
	object V8;                                /*  FORM            */
	V7= reverse((V5));
	{object V9= list(2,VV[4],(V4));
	{object V10;
	object V11= (V5);
	if(endp(V11)){
	VALUES(0) = Cnil;
	goto L20;}
	T0=V10=CONS(Cnil,Cnil);
L21:
	{object V12;                              /*  X               */
	V12= CAR(V11);
	{object V13= car((V12));
	if(!(type_of(V13)==t_cons||V13==Cnil)){
	goto L24;}}
	{object V13;
	object V14= car((V12));
	if(endp(V14)){
	CDR(V10)= Cnil;
	goto L22;}
	T1=V13=CONS(Cnil,Cnil);
L26:
	{object V15;                              /*  Y               */
	CAR(V13)= list(2,VV[4],CAR(V14));
	}
	if(endp(V14=CDR(V14))){
	CDR(V10)= T1;
	goto L22;}
	V13=CDR(V13)=CONS(Cnil,Cnil);
	goto L26;}
L24:
	CDR(V10)= CONS(list(2,VV[4],car((V12))),Cnil);
	}
L22:
	while(!endp(CDR(V10)))V10=CDR(V10);
	if(endp(V11=CDR(V11))){
	T0=CDR(T0);
	VALUES(0) = T0;
	goto L20;}
	goto L21;}
L20:
	V8= list(3,VV[21],VV[22],listA(5,VV[23],VV[24],V9,(V6),VALUES(0)));}
L29:
	if(!(endp((V7)))){
	goto L30;}
	VALUES(0) = list(3,VV[21],CONS(list(2,(V6),(V4)),Cnil),(V8));
	RETURN(1);
L30:
	if((caar((V7)))==Cnil){
	goto L33;}
	{object V10= caar((V7));
	if(!(type_of(V10)==t_cons||V10==Cnil)){
	goto L39;}}
	T0= list(3,VV[26],(V6),list(2,VV[4],caar((V7))));
	goto L37;
L39:
	T0= list(3,VV[27],(V6),list(2,VV[4],caar((V7))));
L37:
	V8= list(4,VV[25],T0,CONS(VV[14],cdar((V7))),(V8));
L33:
	V7= cdr((V7));
	goto L29;
	}}
}
/*	macro definition for CCASE                                    */
static L7(int narg, object V1, object V2)
{ VT7 VLEX7 CLSR7
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6;
	if(endp(V3))FEinvalid_macro_call(VV[62]);
	V4= CAR(V3);
	V3=CDR(V3);
	V5= V3;
	Lgensym(0)                                /*  GENSYM          */;
	V6= VALUES(0);
	{object V7= CONS(list(2,(V6),(V4)),Cnil);
	{object V8;
	object V9= (V5);
	if(endp(V9)){
	T0= Cnil;
	goto L45;}
	T1=V8=CONS(Cnil,Cnil);
L46:
	{register object V10;                     /*  L               */
	V10= CAR(V9);
	{object V11= car((V10));
	if(!(type_of(V11)==t_cons||V11==Cnil)){
	goto L50;}}
	T2= list(3,VV[26],(V6),list(2,VV[4],car((V10))));
	goto L48;
L50:
	T2= list(3,VV[27],(V6),list(2,VV[4],car((V10))));
L48:
	CAR(V8)= list(3,VV[29],T2,list(2,VV[30],CONS(VV[14],cdr((V10)))));
	}
	if(endp(V9=CDR(V9))){
	T0= T1;
	goto L45;}
	V8=CDR(V8)=CONS(Cnil,Cnil);
	goto L46;}
L45:
	{object V8= list(2,VV[4],(V4));
	{object V9;
	object V10= (V5);
	if(endp(V10)){
	VALUES(0) = Cnil;
	goto L52;}
	T1=V9=CONS(Cnil,Cnil);
L53:
	{object V11;                              /*  X               */
	V11= CAR(V10);
	{object V12= car((V11));
	if(!(type_of(V12)==t_cons||V12==Cnil)){
	goto L56;}}
	{object V12;
	object V13= car((V11));
	if(endp(V13)){
	CDR(V9)= Cnil;
	goto L54;}
	T2=V12=CONS(Cnil,Cnil);
L58:
	{object V14;                              /*  Y               */
	CAR(V12)= list(2,VV[4],CAR(V13));
	}
	if(endp(V13=CDR(V13))){
	CDR(V9)= T2;
	goto L54;}
	V12=CDR(V12)=CONS(Cnil,Cnil);
	goto L58;}
L56:
	CDR(V9)= CONS(list(2,VV[4],car((V11))),Cnil);
	}
L54:
	while(!endp(CDR(V9)))V9=CDR(V9);
	if(endp(V10=CDR(V10))){
	T1=CDR(T1);
	VALUES(0) = T1;
	goto L52;}
	goto L53;}
L52:
	{object V9= listA(6,VV[5],VV[32],VV[33],V8,(V6),VALUES(0));
	L3(1,(V4))                                /*  ASK-FOR-FORM    */;
	VALUES(0) = list(2,VV[28],listA(3,VV[21],V7,append(T0,CONS(list(5,VV[21],VV[31],V9,VALUES(0),VV[34]),Cnil))));
	RETURN(1);}}}}
}
/*	macro definition for TYPECASE                                 */
static L11(int narg, object V1, object V2)
{ VT8 VLEX8 CLSR8
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5;
	if(endp(V3))FEinvalid_macro_call(VV[63]);
	V4= CAR(V3);
	V3=CDR(V3);
	V5= V3;
	{register object V6;                      /*  L               */
	object V7;
	register object V8;                       /*  FORM            */
	object V9;                                /*  KEY             */
	V7= reverse((V5));
	Lgensym(0)                                /*  GENSYM          */;
	V9= VALUES(0);
	V6= V7;
	V8= Cnil;
L64:
	if(!(endp((V6)))){
	goto L65;}
	VALUES(0) = list(3,VV[21],CONS(list(2,(V9),(V4)),Cnil),(V8));
	RETURN(1);
L65:
	if((caar((V6)))==(Ct)){
	goto L69;}
	if(!((caar((V6)))==(VV[35]))){
	goto L70;}
L69:
	V8= CONS(VV[14],cdar((V6)));
	goto L68;
L70:
	{object V11= list(3,VV[3],(V9),list(2,VV[4],caar((V6))));
	V8= list(4,VV[25],V11,CONS(VV[14],cdar((V6))),(V8));}
L68:
	V6= cdr((V6));
	goto L64;
	}}
}
/*	macro definition for ETYPECASE                                */
static L12(int narg, object V1, object V2)
{ VT9 VLEX9 CLSR9
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6;
	if(endp(V3))FEinvalid_macro_call(VV[64]);
	V4= CAR(V3);
	V3=CDR(V3);
	V5= V3;
	Lgensym(0)                                /*  GENSYM          */;
	V6= VALUES(0);
	{register object V7;                      /*  L               */
	object V8;                                /*  FORM            */
	V7= reverse((V5));
	{object V9= list(2,VV[4],(V4));
	{object V10;
	object V11= (V5);
	if(endp(V11)){
	VALUES(0) = Cnil;
	goto L82;}
	T0=V10=CONS(Cnil,Cnil);
L83:
	{object V12;                              /*  L               */
	CAR(V10)= car(CAR(V11));
	}
	if(endp(V11=CDR(V11))){
	VALUES(0) = T0;
	goto L82;}
	V10=CDR(V10)=CONS(Cnil,Cnil);
	goto L83;}
L82:
	V8= list(2,VV[23],list(4,VV[36],V9,(V6),list(2,VV[4],VALUES(0))));}
L86:
	if(!(endp((V7)))){
	goto L87;}
	VALUES(0) = list(3,VV[21],CONS(list(2,(V6),(V4)),Cnil),(V8));
	RETURN(1);
L87:
	{object V10= list(3,VV[3],(V6),list(2,VV[4],caar((V7))));
	V8= list(4,VV[25],V10,CONS(VV[14],cdar((V7))),(V8));}
	V7= cdr((V7));
	goto L86;
	}}
}
/*	macro definition for CTYPECASE                                */
static L14(int narg, object V1, object V2)
{ VT10 VLEX10 CLSR10
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6;
	if(endp(V3))FEinvalid_macro_call(VV[65]);
	V4= CAR(V3);
	V3=CDR(V3);
	V5= V3;
	Lgensym(0)                                /*  GENSYM          */;
	V6= VALUES(0);
	{object V7= CONS(list(2,(V6),(V4)),Cnil);
	{object V8;
	object V9= (V5);
	if(endp(V9)){
	T0= Cnil;
	goto L96;}
	T1=V8=CONS(Cnil,Cnil);
L97:
	{object V10;                              /*  L               */
	{object V11= list(3,VV[3],(V6),list(2,VV[4],car(CAR(V9))));
	CAR(V8)= list(3,VV[29],V11,list(2,VV[30],CONS(VV[14],cdr(CAR(V9)))));}
	}
	if(endp(V9=CDR(V9))){
	T0= T1;
	goto L96;}
	V8=CDR(V8)=CONS(Cnil,Cnil);
	goto L97;}
L96:
	{object V8= list(2,VV[4],(V4));
	{object V9;
	object V10= (V5);
	if(endp(V10)){
	VALUES(0) = Cnil;
	goto L99;}
	T1=V9=CONS(Cnil,Cnil);
L100:
	{object V11;                              /*  L               */
	CAR(V9)= car(CAR(V10));
	}
	if(endp(V10=CDR(V10))){
	VALUES(0) = T1;
	goto L99;}
	V9=CDR(V9)=CONS(Cnil,Cnil);
	goto L100;}
L99:
	{object V9= listA(3,VV[21],V7,append(T0,CONS(list(3,VV[5],VV[37],list(4,VV[36],V8,(V6),list(2,VV[4],VALUES(0)))),Cnil)));
	L3(1,(V4))                                /*  ASK-FOR-FORM    */;
	VALUES(0) = list(4,VV[28],V9,VALUES(0),VV[38]);
	RETURN(1);}}}}
}
/*	function definition for TYPECASE-ERROR-STRING                 */
static L17(int narg, object V1, object V2, object V3)
{ VT11 VLEX11 CLSR11
	cs_check;
	check_arg(3);
TTL:
	{register object V4;                      /*  NEGS1           */
	register object V5;                       /*  POSS            */
	register object V6;                       /*  POSS1           */
	V4= Cnil;
	V5= Cnil;
	V6= Cnil;
L108:
	if(!(endp((V3)))){
	goto L109;}
	goto L106;
L109:
	if(!(type_of(car((V3)))==t_symbol)){
	goto L114;}
	V4= CONS(CONS(car((V3)),Cnil),(V4));
	V3= cdr((V3));
	goto L112;
L114:
	{object V8= caar((V3));
	if((V8!= VV[67]))goto L120;
	V3= append(cdar((V3)),cdr((V3)));
	goto L112;
L120:
	if((V8!= VV[26]))goto L122;
	{
	object V9= cdar((V3));
	if(endp(V9)){
	goto L123;}
L124:
	{object V10;                              /*  X               */
	V4= CONS(list(2,VV[26],CAR(V9)),(V4));
	}
	if(endp(V9=CDR(V9))){
	goto L123;}
	goto L124;}
L123:
	V3= cdr((V3));
	goto L112;
L122:
	if((V8!= VV[68]))goto L129;
	V5= CONS(cadar((V3)),(V5));
	V3= cdr((V3));
	goto L112;
L129:
	V4= CONS(car((V3)),(V4));
	V3= cdr((V3));}
L112:
	goto L108;
L106:
L142:
	if(!(endp((V5)))){
	goto L143;}
	goto L140;
L143:
	if(!(type_of(car((V5)))==t_symbol)){
	goto L148;}
	V6= CONS(CONS(car((V5)),Cnil),(V6));
	V5= cdr((V5));
	goto L146;
L148:
	if(!((caar((V5)))==(VV[39]))){
	goto L155;}
	V5= append(cdar((V5)),cdr((V5)));
	goto L146;
L155:
	V6= CONS(car((V5)),(V6));
	V5= cdr((V5));
L146:
	goto L142;
L140:
	{object V7;
	object V8= (V6);
	if(endp(V8)){
	T0= Cnil;
	goto L164;}
	T1=V7=CONS(Cnil,Cnil);
L165:
	L19(1,CAR(V8))                            /*  TYPECASE-ERROR-STRINGS*/;
	CDR(V7)= VALUES(0);
	while(!endp(CDR(V7)))V7=CDR(V7);
	if(endp(V8=CDR(V8))){
	T1=CDR(T1);
	T0= T1;
	goto L164;}
	goto L165;}
L164:
	{int V7= length((V4));
	{object V8;
	object V9= nreverse((V4));
	if(endp(V9)){
	VALUES(0) = Cnil;
	goto L167;}
	T1=V8=CONS(Cnil,Cnil);
L168:
	L19(1,CAR(V9))                            /*  TYPECASE-ERROR-STRINGS*/;
	CDR(V8)= VALUES(0);
	while(!endp(CDR(V8)))V8=CDR(V8);
	if(endp(V9=CDR(V9))){
	T1=CDR(T1);
	VALUES(0) = T1;
	goto L167;}
	goto L168;}
L167:
	RETURN(Lformat(8,Cnil,VV[40],(V1),(V2),VV[41],T0,VV[42],listA(3,(V6),MAKE_FIXNUM(V7),VALUES(0)))/*  FORMAT*/);}
	}
}
/*	function definition for TYPECASE-ERROR-STRINGS                */
static L19(int narg, object V1)
{ VT12 VLEX12 CLSR12
	cs_check;
	check_arg(1);
TTL:
	if(!((car((V1)))==(VV[26]))){
	goto L171;}
	{object V2= MAKE_FIXNUM(length(cdr((V1))));
	if(!eql(V2,VV[43]))goto L173;
	VALUES(0) = VV[44];
	RETURN(1);
L173:
	if(!eql(V2,VV[45]))goto L174;
	VALUES(0) = list(2,VV[46],CONS(cadr((V1)),Cnil));
	RETURN(1);
L174:
	if(!eql(V2,VV[47]))goto L175;
	VALUES(0) = list(2,VV[48],cdr((V1)));
	RETURN(1);
L175:
	VALUES(0) = list(2,VV[49],CONS(cdr((V1)),Cnil));
	RETURN(1);}
L171:
	if(!((car((V1)))==(VV[50]))){
	goto L177;}
	VALUES(0) = list(2,VV[51],cdr((V1)));
	RETURN(1);
L177:
	if(endp(cdr((V1)))){
	goto L179;}
	(*LK0)(2,VV[52],cdr((V1)))                /*  REMOVE          */;
	if(VALUES(0)!=Cnil){
	goto L180;}
L179:
	{object V3;                               /*  X               */
	V3= assql(car((V1)),VV[53]);
	if(((V3))==Cnil){
	goto L186;}
	VALUES(0) = list(2,cadr((V3)),Cnil);
	RETURN(1);
L186:
	LC20(1,car((V1)))                         /*  VOWEL-P         */;
	T0= VALUES(0);
	VALUES(0) = list(2,VV[54],list(2,T0,car((V1))));
	RETURN(1);
	}
L180:
	LC20(1,car((V1)))                         /*  VOWEL-P         */;
	VALUES(0) = list(2,VV[55],list(2,VALUES(0),(V1)));
	RETURN(1);
}
/*	local function VOWEL-P                                        */
static LC20(int narg, object V1)
{ VT13 VLEX13 CLSR13
	check_arg(1);
	Lsymbol_name(1,(V1))                      /*  SYMBOL-NAME     */;
	VALUES(0) = memq(elt(VALUES(0),0),VV[56]);
	RETURN(1);
}
static LKF0(int narg, ...) {TRAMPOLINK(VV[69],&LK0);}
