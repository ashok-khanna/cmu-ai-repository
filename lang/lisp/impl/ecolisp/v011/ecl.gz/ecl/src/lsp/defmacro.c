
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "defmacro.h"
init_defmacro(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_defmacro; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	VV[0]->s.s_stype=(short)stp_special;
	VV[1]->s.s_stype=(short)stp_special;
	VV[2]->s.s_stype=(short)stp_special;
	MM0(VV[58],L1);
	MF0(VV[5],L2);
	MF0(VV[59],L7);
	MF0(VV[60],L8);
	MF0(VV[61],L9);
	MF0(VV[62],L10);
	MF0(VV[63],L11);
	MF0(VV[64],L12);
}
/*	macro definition for DEFMACRO                                 */
static L1(int narg, object V1, object V2)
{ VT3 VLEX3 CLSR3
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6;
	if(endp(V3))FEinvalid_macro_call(VV[58]);
	V4= CAR(V3);
	V3=CDR(V3);
	if(endp(V3))FEinvalid_macro_call(VV[58]);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= V3;
	{object V7= list(2,VV[6],(V4));
	{object V8= list(2,VV[6],(V5));
	{object V9= list(4,VV[5],(V7),(V8),list(2,VV[6],(V6)));
	VALUES(0) = list(4,VV[3],VV[4],(V9),listA(3,VV[7],list(2,VV[6],(V4)),VV[8]));
	RETURN(1);}}}}
}
/*	function definition for EXPAND-DEFMACRO                       */
static L2(int narg, object V1, object V2, object V3)
{ VT4 VLEX4 CLSR4
	cs_check;
	bds_check;
	check_arg(3);
TTL:
	{object V4;                               /*  DOC             */
	object V5;                                /*  DECLS           */
	object V6;                                /*  WHOLE           */
	object V7;                                /*  PPN             */
	object V8;                                /*  ENV             */
	bds_bind(VV[0],Cnil);                     /*  *DL*            */
	bds_bind(VV[1],Cnil);                     /*  *KEY-CHECK*     */
	bds_bind(VV[2],Cnil);                     /*  *ARG-CHECK*     */
	V4= Cnil;
	V5= Cnil;
	V6= Cnil;
	V7= Cnil;
	V8= Cnil;
	{object V9;
	V9= (type_of((V2))==t_cons||(V2)==Cnil?Ct:Cnil);
	if(((V9))==Cnil){
	goto L9;}
	goto L6;
L9:
	if(!(type_of((V2))==t_symbol)){
	goto L12;}
	V2= list(2,VV[9],(V2));
	goto L6;
L12:
	Lerror(2,VV[10],(V2))                     /*  ERROR           */;
	}
L6:
	{ int V9;
	V9=L11(2,(V3),Cnil)                       /*  FIND-DOC        */;
	if (V9>0) {
	V4= VALUES(0);
	V9--;
	} else {
	V4= Cnil;}
	if (V9>0) {
	V5= VALUES(1);
	V9--;
	} else {
	V5= Cnil;}
	if (V9>0) {
	V3= VALUES(2);
	} else {
	V3= Cnil;}
	
	}
	if(!(type_of((V2))==t_cons||(V2)==Cnil)){
	goto L19;}
	if(!((car((V2)))==(VV[11]))){
	goto L19;}
	V6= cadr((V2));
	V2= cddr((V2));
	goto L17;
L19:
	Lgensym(0)                                /*  GENSYM          */;
	V6= VALUES(0);
L17:
	V8= memq(VV[12],(V2));
	if(((V8))==Cnil){
	goto L29;}
	Lldiff(2,(V2),(V8))                       /*  LDIFF           */;
	T0= VALUES(0);
	V2= nconc(T0,cddr((V8)));
	V8= cadr((V8));
	goto L27;
L29:
	Lgensym(0)                                /*  GENSYM          */;
	V8= VALUES(0);
	V5= CONS(list(2,VV[13],list(2,VV[14],(V8))),(V5));
L27:
	(VV[0]->s.s_dbind)= list(3,VV[15],(V8),(V6));
	LC3(3,(V2),(V6),Ct)                       /*  DM-VL           */;
	V7= VALUES(0);
	{volatile object V9;
	volatile object V10;                      /*  KC              */
	V9= (VV[1]->s.s_dbind);
	V10= Cnil;
L47:
	if(!(endp((V9)))){
	goto L48;}
	goto L43;
L48:
	V10= car((V9));
	{object V12= list(3,VV[17],car((V10)),VV[18]);
	{object V13= CONS(list(3,VV[20],car((V10)),VV[21]),Cnil);
	V3= CONS(list(3,VV[16],(V12),list(4,VV[19],(V13),VV[22],list(3,VV[16],list(3,VV[23],VV[24],list(2,VV[6],cdr((V10)))),VV[25]))),(V3));}}
	V9= cdr((V9));
	goto L47;
	}
L43:
	{volatile object V9;
	volatile object V10;                      /*  AC              */
	V9= (VV[2]->s.s_dbind);
	V10= Cnil;
L62:
	if(!(endp((V9)))){
	goto L63;}
	goto L58;
L63:
	V10= car((V9));
	LC6(2,cdr((V10)),car((V10)))              /*  DM-NTH-CDR      */;
	V3= CONS(list(3,VV[16],list(2,VV[26],VALUES(0)),VV[27]),(V3));
	V9= cdr((V9));
	goto L62;
	}
L58:
	{object V9= nreverse((VV[0]->s.s_dbind));
	VALUES(2) = (V7);
	VALUES(1) = (V4);
	VALUES(0) = listA(4,VV[28],(V1),(V9),nconc((V5),(V3)));
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(3);}
	}
}
/*	local function DM-NTH-CDR                                     */
static LC6(int narg, object V1, object V2)
{ VT5 VLEX5 CLSR5
	check_arg(2);
TTL:
	{ int V3;
	object V4;                                /*  Q               */
	object V5;                                /*  R               */
	V3=Lfloor(2,(V1),MAKE_FIXNUM(4))          /*  FLOOR           */;
	if (V3--==0) goto L75;
	V4= VALUES(0);
	if (V3--==0) goto L76;
	V5= VALUES(1);
	goto L77;
L75:
	V4= MAKE_FIXNUM(0);
L76:
	V5= MAKE_FIXNUM(0);
L77:
	{volatile int V6;
	volatile int V7;                          /*  I               */
	V6= fix((V4));
	V7= 0;
L82:
	if(!((V7)>=(V6))){
	goto L83;}
	goto L78;
L83:
	V2= list(2,VV[42],(V2));
	V7= (V7)+1;
	goto L82;
	}
L78:
	if(!eql((V5),VV[43]))goto L91;
	VALUES(0) = (V2);
	RETURN(1);
L91:
	if(!eql((V5),VV[45]))goto L92;
	VALUES(0) = list(2,VV[51],(V2));
	RETURN(1);
L92:
	if(!eql((V5),VV[47]))goto L93;
	VALUES(0) = list(2,VV[52],(V2));
	RETURN(1);
L93:
	if(!eql((V5),VV[49]))goto L94;
	VALUES(0) = list(2,VV[53],(V2));
	RETURN(1);
L94:
	VALUES(0) = Cnil;
	RETURN(1);}
}
/*	local function DM-NTH                                         */
static LC5(int narg, object V1, object V2)
{ VT6 VLEX6 CLSR6
	check_arg(2);
TTL:
	{ int V3;
	object V4;                                /*  Q               */
	object V5;                                /*  R               */
	V3=Lfloor(2,(V1),MAKE_FIXNUM(4))          /*  FLOOR           */;
	if (V3--==0) goto L96;
	V4= VALUES(0);
	if (V3--==0) goto L97;
	V5= VALUES(1);
	goto L98;
L96:
	V4= MAKE_FIXNUM(0);
L97:
	V5= MAKE_FIXNUM(0);
L98:
	{volatile int V6;
	volatile int V7;                          /*  I               */
	V6= fix((V4));
	V7= 0;
L103:
	if(!((V7)>=(V6))){
	goto L104;}
	goto L99;
L104:
	V2= list(2,VV[42],(V2));
	V7= (V7)+1;
	goto L103;
	}
L99:
	if(!eql((V5),VV[43]))goto L112;
	VALUES(0) = list(2,VV[44],(V2));
	RETURN(1);
L112:
	if(!eql((V5),VV[45]))goto L113;
	VALUES(0) = list(2,VV[46],(V2));
	RETURN(1);
L113:
	if(!eql((V5),VV[47]))goto L114;
	VALUES(0) = list(2,VV[48],(V2));
	RETURN(1);
L114:
	if(!eql((V5),VV[49]))goto L115;
	VALUES(0) = list(2,VV[50],(V2));
	RETURN(1);
L115:
	VALUES(0) = Cnil;
	RETURN(1);}
}
/*	local function DM-V                                           */
static LC4(int narg, object V1, object V2)
{ VT7 VLEX7 CLSR7
	check_arg(2);
TTL:
	if(!(type_of((V1))==t_symbol)){
	goto L117;}
	if(((V2))==Cnil){
	goto L122;}
	VALUES(0) = list(2,(V1),(V2));
	goto L120;
L122:
	VALUES(0) = (V1);
L120:
	(VV[0]->s.s_dbind)= CONS(VALUES(0),(VV[0]->s.s_dbind));
	VALUES(0) = (VV[0]->s.s_dbind);
	RETURN(1);
L117:
	{object V3;                               /*  TEMP            */
	Lgensym(0)                                /*  GENSYM          */;
	V3= VALUES(0);
	if(((V2))==Cnil){
	goto L129;}
	VALUES(0) = list(2,(V3),(V2));
	goto L127;
L129:
	VALUES(0) = (V3);
L127:
	(VV[0]->s.s_dbind)= CONS(VALUES(0),(VV[0]->s.s_dbind));
	RETURN(LC3(3,(V1),(V3),Cnil)              /*  DM-VL           */);
	}
}
/*	local function DM-VL                                          */
static LC3(int narg, object V1, object V2, object V3)
{ VT8 VLEX8 CLSR8
	check_arg(3);
TTL:
	{volatile object V4;                      /*  OPTIONALP       */
	volatile object V5;                       /*  RESTP           */
	volatile object V6;                       /*  KEYP            */
	volatile object V7;                       /*  ALLOW-OTHER-KEYS-P*/
	volatile object V8;                       /*  AUXP            */
	volatile object V9;                       /*  REST            */
	volatile object V10;                      /*  ALLOW-OTHER-KEYS*/
	volatile object V11;                      /*  KEYS            */
	volatile object V12;                      /*  NO-CHECK        */
	volatile int V13;                         /*  N               */
	volatile int V14;                         /*  PPN             */
	volatile object V15;                      /*  V               */
	if(((V3))==Cnil){
	goto L133;}
	V13= 1;
	goto L131;
L133:
	V13= 0;
L131:
	V14= 0;
	V4= Cnil;
	V5= Cnil;
	V6= Cnil;
	V7= Cnil;
	V8= Cnil;
	V9= Cnil;
	V10= Cnil;
	V11= Cnil;
	V12= Cnil;
	V15= Cnil;
L137:
	if(type_of((V1))==t_cons){
	goto L138;}
	if(((V1))==Cnil){
	goto L141;}
	if(((V5))==Cnil){
	goto L144;}
	L7(1,VV[9])                               /*  DM-BAD-KEY      */;
L144:
	LC6(2,MAKE_FIXNUM(V13),(V2))              /*  DM-NTH-CDR      */;
	(VV[0]->s.s_dbind)= CONS(list(2,(V1),VALUES(0)),(VV[0]->s.s_dbind));
	V12= Ct;
L141:
	if(((V9))==Cnil){
	goto L151;}
	if(((V10))!=Cnil){
	goto L151;}
	(VV[1]->s.s_dbind)= CONS(CONS((V9),(V11)),(VV[1]->s.s_dbind));
L151:
	if(((V12))!=Cnil){
	goto L157;}
	(VV[2]->s.s_dbind)= CONS(CONS((V2),MAKE_FIXNUM(V13)),(VV[2]->s.s_dbind));
L157:
	VALUES(0) = MAKE_FIXNUM(V14);
	RETURN(1);
L138:
	V15= car((V1));
	if(!(((V15))==(VV[29]))){
	goto L165;}
	if(((V4))==Cnil){
	goto L167;}
	L7(1,VV[29])                              /*  DM-BAD-KEY      */;
L167:
	V4= Ct;
	{object V17;
	V17= car((V1));
	V1= cdr((V1));
	goto L163;
	}
L165:
	if(((V15))==(VV[9])){
	goto L175;}
	if(!(((V15))==(VV[30]))){
	goto L176;}
L175:
	if(((V5))==Cnil){
	goto L180;}
	L7(1,(V15))                               /*  DM-BAD-KEY      */;
L180:
	{object V18= cadr((V1));
	LC6(2,MAKE_FIXNUM(V13),(V2))              /*  DM-NTH-CDR      */;
	LC4(2,(V18),VALUES(0))                    /*  DM-V            */;}
	V5= Ct;
	V4= Ct;
	V12= Ct;
	V1= cddr((V1));
	if(!(((V15))==(VV[30]))){
	goto L163;}
	if(((V3))==Cnil){
	goto L197;}
	V14= (V13)-1;
	goto L195;
L197:
	V14= V13;
L195:
	goto L163;
L176:
	if(!(((V15))==(VV[31]))){
	goto L200;}
	if(((V6))==Cnil){
	goto L202;}
	L7(1,VV[31])                              /*  DM-BAD-KEY      */;
L202:
	Lgensym(0)                                /*  GENSYM          */;
	V9= VALUES(0);
	LC6(2,MAKE_FIXNUM(V13),(V2))              /*  DM-NTH-CDR      */;
	(VV[0]->s.s_dbind)= CONS(list(2,(V9),VALUES(0)),(VV[0]->s.s_dbind));
	V6= Ct;
	V5= Ct;
	V4= Ct;
	V12= Ct;
	{object V18;
	V18= car((V1));
	V1= cdr((V1));
	goto L163;
	}
L200:
	if(!(((V15))==(VV[32]))){
	goto L222;}
	if(((V6))==Cnil){
	goto L225;}
	if(((V7))==Cnil){
	goto L224;}
L225:
	L7(1,VV[32])                              /*  DM-BAD-KEY      */;
L224:
	V7= Ct;
	V10= Ct;
	{object V19;
	V19= car((V1));
	V1= cdr((V1));
	goto L163;
	}
L222:
	if(!(((V15))==(VV[15]))){
	goto L237;}
	if(((V8))==Cnil){
	goto L239;}
	L7(1,VV[15])                              /*  DM-BAD-KEY      */;
L239:
	V8= Ct;
	V7= Ct;
	V6= Ct;
	V5= Ct;
	V4= Ct;
	{object V20;
	V20= car((V1));
	V1= cdr((V1));
	goto L163;
	}
L237:
	if(((V8))==Cnil){
	goto L256;}
	{object V21;                              /*  X               */
	object V22;                               /*  INIT            */
	V21= Cnil;
	V22= Cnil;
	if(!(type_of((V15))==t_symbol)){
	goto L261;}
	V21= (V15);
	goto L259;
L261:
	V21= car((V15));
	if(endp(cdr((V15)))){
	goto L259;}
	V22= cadr((V15));
L259:
	LC4(2,(V21),(V22))                        /*  DM-V            */;
	}
	{object V21;
	V21= car((V1));
	V1= cdr((V1));
	goto L163;
	}
L256:
	if(((V6))==Cnil){
	goto L273;}
	{object V22;                              /*  TEMP            */
	object V23;                               /*  X               */
	register object V24;                      /*  K               */
	object V25;                               /*  INIT            */
	object V26;                               /*  SV              */
	Lgensym(0)                                /*  GENSYM          */;
	V22= VALUES(0);
	V23= Cnil;
	V24= Cnil;
	V25= Cnil;
	V26= Cnil;
	if(!(type_of((V15))==t_symbol)){
	goto L279;}
	V23= (V15);
	Lintern(2,coerce_to_string((V15)),VV[33]) /*  INTERN          */;
	V24= VALUES(0);
	goto L277;
L279:
	if(!(type_of(car((V15)))==t_symbol)){
	goto L286;}
	V23= car((V15));
	Lintern(2,coerce_to_string(car((V15))),VV[33])/*  INTERN      */;
	V24= VALUES(0);
	goto L284;
L286:
	V23= cadar((V15));
	V24= caar((V15));
L284:
	if(endp(cdr((V15)))){
	goto L277;}
	V25= cadr((V15));
	if(endp(cddr((V15)))){
	goto L277;}
	V26= caddr((V15));
L277:
	LC4(2,(V22),list(4,VV[17],(V9),(V24),VV[34]))/*  DM-V         */;
	LC4(2,(V23),list(4,VV[35],list(3,VV[36],(V22),VV[37]),(V25),(V22)))/*  DM-V*/;
	if(((V26))==Cnil){
	goto L303;}
	LC4(2,(V26),list(2,VV[38],list(3,VV[36],(V22),VV[39])))/*  DM-V*/;
L303:
	V11= CONS((V24),(V11));
	}
	{object V22;
	V22= car((V1));
	V1= cdr((V1));
	goto L163;
	}
L273:
	if(((V4))==Cnil){
	goto L311;}
	{object V23;                              /*  X               */
	object V24;                               /*  INIT            */
	object V25;                               /*  SV              */
	V23= Cnil;
	V24= Cnil;
	V25= Cnil;
	if(!(type_of((V15))==t_symbol)){
	goto L316;}
	V23= (V15);
	goto L314;
L316:
	V23= car((V15));
	if(endp(cdr((V15)))){
	goto L314;}
	V24= cadr((V15));
	if(endp(cddr((V15)))){
	goto L314;}
	V25= caddr((V15));
L314:
	LC6(2,MAKE_FIXNUM(V13),(V2))              /*  DM-NTH-CDR      */;
	T0= VALUES(0);
	LC5(2,MAKE_FIXNUM(V13),(V2))              /*  DM-NTH          */;
	LC4(2,(V23),list(4,VV[35],T0,VALUES(0),(V24)))/*  DM-V        */;
	if(((V25))==Cnil){
	goto L313;}
	LC6(2,MAKE_FIXNUM(V13),(V2))              /*  DM-NTH-CDR      */;
	LC4(2,(V25),list(2,VV[38],list(2,VV[40],VALUES(0))))/*  DM-V  */;
	}
L313:
	V13= (V13)+(1);
	{object V23;
	V23= car((V1));
	V1= cdr((V1));
	goto L163;
	}
L311:
	LC6(2,MAKE_FIXNUM(V13),(V2))              /*  DM-NTH-CDR      */;
	T0= VALUES(0);
	LC5(2,MAKE_FIXNUM(V13),(V2))              /*  DM-NTH          */;
	LC4(2,(V15),list(4,VV[35],T0,VALUES(0),VV[41]))/*  DM-V       */;
	V13= (V13)+(1);
	{object V24;
	V24= car((V1));
	V1= cdr((V1));
	}
L163:
	goto L137;
	}
}
/*	function definition for DM-BAD-KEY                            */
static L7(int narg, object V1)
{ VT9 VLEX9 CLSR9
	cs_check;
	check_arg(1);
TTL:
	RETURN(Lerror(2,VV[54],(V1))              /*  ERROR           */);
}
/*	function definition for DM-TOO-FEW-ARGUMENTS                  */
static L8(int narg)
{ VT10 VLEX10 CLSR10
	cs_check;
	check_arg(0);
TTL:
	RETURN(Lerror(1,VV[55])                   /*  ERROR           */);
}
/*	function definition for DM-TOO-MANY-ARGUMENTS                 */
static L9(int narg)
{ VT11 VLEX11 CLSR11
	cs_check;
	check_arg(0);
TTL:
	RETURN(Lerror(1,VV[56])                   /*  ERROR           */);
}
/*	function definition for DM-KEY-NOT-ALLOWED                    */
static L10(int narg, object V1)
{ VT12 VLEX12 CLSR12
	cs_check;
	check_arg(1);
TTL:
	RETURN(Lerror(2,VV[57],(V1))              /*  ERROR           */);
}
/*	function definition for FIND-DOC                              */
static L11(int narg, object V1, object V2)
{ VT13 VLEX13 CLSR13
	cs_check;
	check_arg(2);
TTL:
	if(!(endp((V1)))){
	goto L350;}
	VALUES(2) = Cnil;
	VALUES(1) = Cnil;
	VALUES(0) = Cnil;
	RETURN(3);
L350:
	{register object V3;                      /*  D               */
	Lmacroexpand(1,car((V1)))                 /*  MACROEXPAND     */;
	V3= VALUES(0);
	if(!(type_of((V3))==t_string)){
	goto L354;}
	if(endp(cdr((V1)))){
	goto L356;}
	if(((V2))==Cnil){
	goto L357;}
L356:
	VALUES(2) = CONS((V3),cdr((V1)));
	VALUES(1) = Cnil;
	VALUES(0) = Cnil;
	RETURN(3);
L357:
	{ int V4;
	object V5;                                /*  DOC             */
	object V6;                                /*  DECLS           */
	object V7;                                /*  B               */
	V4=L11(2,cdr((V1)),Ct)                    /*  FIND-DOC        */;
	if (V4--==0) goto L362;
	V5= VALUES(0);
	if (V4--==0) goto L363;
	V6= VALUES(1);
	if (V4--==0) goto L364;
	V7= VALUES(2);
	goto L365;
L362:
	V5= Cnil;
L363:
	V6= Cnil;
L364:
	V7= Cnil;
L365:
	VALUES(2) = (V7);
	VALUES(1) = (V6);
	VALUES(0) = (V3);
	RETURN(3);}
L354:
	if(!(type_of((V3))==t_cons)){
	goto L367;}
	if(!((car((V3)))==(VV[13]))){
	goto L367;}
	{ int V4;
	object V5;                                /*  DOC             */
	object V6;                                /*  DECLS           */
	object V7;                                /*  B               */
	V4=L11(2,cdr((V1)),(V2))                  /*  FIND-DOC        */;
	if (V4--==0) goto L372;
	V5= VALUES(0);
	if (V4--==0) goto L373;
	V6= VALUES(1);
	if (V4--==0) goto L374;
	V7= VALUES(2);
	goto L375;
L372:
	V5= Cnil;
L373:
	V6= Cnil;
L374:
	V7= Cnil;
L375:
	VALUES(2) = (V7);
	VALUES(1) = CONS((V3),(V6));
	VALUES(0) = (V5);
	RETURN(3);}
L367:
	VALUES(2) = CONS((V3),cdr((V1)));
	VALUES(1) = Cnil;
	VALUES(0) = Cnil;
	RETURN(3);
	}
}
/*	function definition for FIND-DECLARATIONS                     */
static L12(int narg, object V1)
{ VT14 VLEX14 CLSR14
	cs_check;
	check_arg(1);
TTL:
	if(!(endp((V1)))){
	goto L377;}
	VALUES(1) = Cnil;
	VALUES(0) = Cnil;
	RETURN(2);
L377:
	{register object V2;                      /*  D               */
	Lmacroexpand(1,car((V1)))                 /*  MACROEXPAND     */;
	V2= VALUES(0);
	if(!(type_of((V2))==t_string)){
	goto L381;}
	if(!(endp(cdr((V1))))){
	goto L384;}
	VALUES(1) = CONS((V2),Cnil);
	VALUES(0) = Cnil;
	RETURN(2);
L384:
	{ int V3;
	object V4;                                /*  DS              */
	object V5;                                /*  B               */
	V3=L12(1,cdr((V1)))                       /*  FIND-DECLARATIONS*/;
	if (V3--==0) goto L387;
	V4= VALUES(0);
	if (V3--==0) goto L388;
	V5= VALUES(1);
	goto L389;
L387:
	V4= Cnil;
L388:
	V5= Cnil;
L389:
	VALUES(1) = (V5);
	VALUES(0) = CONS((V2),(V4));
	RETURN(2);}
L381:
	if(!(type_of((V2))==t_cons)){
	goto L391;}
	if(!((car((V2)))==(VV[13]))){
	goto L391;}
	{ int V3;
	object V4;                                /*  DS              */
	object V5;                                /*  B               */
	V3=L12(1,cdr((V1)))                       /*  FIND-DECLARATIONS*/;
	if (V3--==0) goto L396;
	V4= VALUES(0);
	if (V3--==0) goto L397;
	V5= VALUES(1);
	goto L398;
L396:
	V4= Cnil;
L397:
	V5= Cnil;
L398:
	VALUES(1) = (V5);
	VALUES(0) = CONS((V2),(V4));
	RETURN(2);}
L391:
	VALUES(1) = CONS((V2),cdr((V1)));
	VALUES(0) = Cnil;
	RETURN(2);
	}
}
