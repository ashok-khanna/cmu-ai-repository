
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "cmplam.h"
init_cmplam(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_cmplam; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	MF0(VV[50],L1);
	MF0(VV[51],L2);
	MF0(VV[52],L3);
	MF0(VV[53],L4);
	MF0(VV[54],L7);
	MF0(VV[55],L10);
	MF0(VV[56],L11);
	MF0(VV[57],L14);
	MF0(VV[58],L15);
}
/*	function definition for C1LAMBDA-EXPR                         */
static L1(int narg, object V1, ...)
{ VT3 VLEX3 CLSR3
	bds_check;
	{int i=1;
	volatile object V2;
	volatile object V3;
	va_list args; va_start(args, V1);
	if (i==narg) goto L1;
	V2= va_arg(args, object);
	V3= Ct;
	i++;
	goto L2;
L1:
	V2= Cnil;
	V3= Cnil;
L2:
	{object V4;                               /*  REQUIREDS       */
	object V5;                                /*  OPTIONALS       */
	object V6;                                /*  REST            */
	object V7;                                /*  KEYWORDS        */
	object V8;                                /*  KEY-FLAG        */
	object V9;                                /*  ALLOW-OTHER-KEYS*/
	object V10;                               /*  AUX-VARS        */
	object V11;                               /*  AUX-INITS       */
	object V12;                               /*  DOC             */
	register object V13;                      /*  SPEC            */
	object V14;                               /*  BODY            */
	register object V15;                      /*  SS              */
	register object V16;                      /*  IS              */
	register object V17;                      /*  TS              */
	object V18;                               /*  OTHER-DECLS     */
	register object V19;                      /*  VNAMES          */
	object V20;                               /*  INFO            */
	object V21;                               /*  AUX-INFO        */
	V4= Cnil;
	V5= Cnil;
	V6= Cnil;
	V7= Cnil;
	V8= Cnil;
	V9= Cnil;
	V10= Cnil;
	V11= Cnil;
	V12= Cnil;
	V13= Cnil;
	V14= Cnil;
	V15= Cnil;
	V16= Cnil;
	V17= Cnil;
	V18= Cnil;
	V19= Cnil;
	bds_bind(VV[0],(VV[0]->s.s_dbind));       /*  *VARS*          */
	(*LK0)(0)                                 /*  MAKE-INFO       */;
	V20= VALUES(0);
	V21= Cnil;
	if(!((V1)==Cnil)){
	goto L22;}
	(*LK1)(2,VV[1],CONS(VV[2],(V1)))          /*  CMPERR          */;
L22:
	{ int V22;
	V22=(*LK2)(2,CDR((V1)),Ct)                /*  C1BODY          */;
	if (V22>0) {
	V14= VALUES(0);
	V22--;
	} else {
	V14= Cnil;}
	if (V22>0) {
	V15= VALUES(1);
	V22--;
	} else {
	V15= Cnil;}
	if (V22>0) {
	V17= VALUES(2);
	V22--;
	} else {
	V17= Cnil;}
	if (V22>0) {
	V16= VALUES(3);
	V22--;
	} else {
	V16= Cnil;}
	if (V22>0) {
	V18= VALUES(4);
	V22--;
	} else {
	V18= Cnil;}
	if (V22>0) {
	V12= VALUES(5);
	} else {
	V12= Cnil;}
	
	}
	if(((V3))==Cnil){
	goto L27;}
	V14= CONS(listA(3,VV[3],(V2),(V14)),Cnil);
L27:
	(*LK3)(1,(V15))                           /*  C1ADD-GLOBALS   */;
	{ int V22;
	V22=L2(1,CAR((V1)))                       /*  PARSE-LAMBDA-LIST*/;
	if (V22>0) {
	V4= VALUES(0);
	V22--;
	} else {
	V4= Cnil;}
	if (V22>0) {
	V5= VALUES(1);
	V22--;
	} else {
	V5= Cnil;}
	if (V22>0) {
	V6= VALUES(2);
	V22--;
	} else {
	V6= Cnil;}
	if (V22>0) {
	V8= VALUES(3);
	V22--;
	} else {
	V8= Cnil;}
	if (V22>0) {
	V7= VALUES(4);
	V22--;
	} else {
	V7= Cnil;}
	if (V22>0) {
	V9= VALUES(5);
	V22--;
	} else {
	V9= Cnil;}
	if (V22>0) {
	V10= VALUES(6);
	} else {
	V10= Cnil;}
	
	}
	{volatile object V22;                     /*  SPECS           */
	V22= (V4);
L36:
	if(((V22))!=Cnil){
	goto L37;}
	goto L34;
L37:
	V13= CAR((V22));
	{object V24;                              /*  V               */
	(*LK4)(4,(V13),(V15),(V16),(V17))         /*  C1MAKE-VAR      */;
	V24= VALUES(0);
	V19= CONS((V13),(V19));
	(VV[0]->s.s_dbind)= CONS((V24),(VV[0]->s.s_dbind));
	{object V25;
	object V26;
	V25= (V22);
	V26= (V24);
	CAR((V25)) = (V26);
	}
	}
	V22= CDR((V22));
	goto L36;
	}
L34:
	{volatile object V22;                     /*  SPECS           */
	V22= (V5);
L56:
	if(((V22))!=Cnil){
	goto L57;}
	goto L54;
L57:
	V13= CAR((V22));
	if(!(type_of((V13))==t_symbol)){
	goto L64;}
	{object V24;                              /*  V               */
	(*LK4)(4,(V13),(V15),(V16),(V17))         /*  C1MAKE-VAR      */;
	V24= VALUES(0);
	V19= CONS((V13),(V19));
	{object V25;
	object V26;
	V25= (V22);
	(*LK5)(1,((V24))->v.v_self[6])            /*  DEFAULT-INIT    */;
	V26= list(3,(V24),VALUES(0),Cnil);
	CAR((V25)) = (V26);
	}
	(VV[0]->s.s_dbind)= CONS((V24),(VV[0]->s.s_dbind));
	goto L62;
	}
L64:
	if(!(type_of(CDR((V13)))==t_symbol)){
	goto L76;}
	if((CDR((V13)))==Cnil){
	goto L78;}
	(*LK1)(2,VV[4],(V13))                     /*  CMPERR          */;
L78:
	{object V25;                              /*  V               */
	(*LK4)(4,CAR((V13)),(V15),(V16),(V17))    /*  C1MAKE-VAR      */;
	V25= VALUES(0);
	V19= CONS(CAR((V13)),(V19));
	{object V26;
	object V27;
	V26= (V22);
	(*LK5)(1,((V25))->v.v_self[6])            /*  DEFAULT-INIT    */;
	V27= list(3,(V25),VALUES(0),Cnil);
	CAR((V26)) = (V27);
	}
	(VV[0]->s.s_dbind)= CONS((V25),(VV[0]->s.s_dbind));
	goto L62;
	}
L76:
	if(!(type_of(CDDR((V13)))==t_symbol)){
	goto L91;}
	if((CDDR((V13)))==Cnil){
	goto L93;}
	(*LK1)(2,VV[4],(V13))                     /*  CMPERR          */;
L93:
	{object V26;                              /*  INIT            */
	object V27;
	object V28;                               /*  V               */
	(*LK6)(2,CADR((V13)),(V20))               /*  C1EXPR*         */;
	V27= VALUES(0);
	(*LK4)(4,CAR((V13)),(V15),(V16),(V17))    /*  C1MAKE-VAR      */;
	V28= VALUES(0);
	V26= V27;
	V19= CONS(CAR((V13)),(V19));
	{object V29;
	object V30;
	V29= (V22);
	(*LK7)(3,((V28))->v.v_self[6],(V26),CADR((V13)))/*  AND-FORM-TYPE*/;
	V30= list(3,(V28),VALUES(0),Cnil);
	CAR((V29)) = (V30);
	}
	(VV[0]->s.s_dbind)= CONS((V28),(VV[0]->s.s_dbind));
	goto L62;
	}
L91:
	if((CDDDR((V13)))==Cnil){
	goto L106;}
	(*LK1)(2,VV[4],(V13))                     /*  CMPERR          */;
L106:
	{object V29;                              /*  INIT            */
	object V30;
	object V31;                               /*  V               */
	object V32;
	object V33;                               /*  SV              */
	(*LK6)(2,CADR((V13)),(V20))               /*  C1EXPR*         */;
	V30= VALUES(0);
	(*LK4)(4,CAR((V13)),(V15),(V16),(V17))    /*  C1MAKE-VAR      */;
	V32= VALUES(0);
	(*LK4)(4,CADDR((V13)),(V15),(V16),(V17))  /*  C1MAKE-VAR      */;
	V33= VALUES(0);
	V29= V30;
	V31= V32;
	V19= CONS(CAR((V13)),(V19));
	V19= CONS(CADDR((V13)),(V19));
	{object V34;
	object V35;
	V34= (V22);
	(*LK7)(3,((V31))->v.v_self[6],(V29),CADR((V13)))/*  AND-FORM-TYPE*/;
	V35= list(3,(V31),VALUES(0),(V33));
	CAR((V34)) = (V35);
	}
	(VV[0]->s.s_dbind)= CONS((V31),(VV[0]->s.s_dbind));
	(VV[0]->s.s_dbind)= CONS((V33),(VV[0]->s.s_dbind));
	}
L62:
	V22= CDR((V22));
	goto L56;
	}
L54:
	if(((V6))==Cnil){
	goto L127;}
	V19= CONS((V6),(V19));
	(*LK4)(4,(V6),(V15),(V16),(V17))          /*  C1MAKE-VAR      */;
	V6= VALUES(0);
	(VV[0]->s.s_dbind)= CONS((V6),(VV[0]->s.s_dbind));
L127:
	{volatile object V22;                     /*  SPECS           */
	V22= (V7);
L137:
	if(((V22))!=Cnil){
	goto L138;}
	goto L135;
L138:
	V13= CAR((V22));
	if((CDDR((V13)))!=Cnil){
	goto L145;}
	if((CDDR((V13)))==Cnil){
	goto L147;}
	(*LK1)(2,VV[4],(V13))                     /*  CMPERR          */;
L147:
	{object V24;                              /*  V               */
	(*LK4)(4,CADR((V13)),(V15),(V16),(V17))   /*  C1MAKE-VAR      */;
	V24= VALUES(0);
	V19= CONS(CADR((V13)),(V19));
	{object V25;
	object V26;
	V25= (V22);
	{object V27= CAR((V13));
	(*LK5)(1,((V24))->v.v_self[6])            /*  DEFAULT-INIT    */;
	T0= VALUES(0);
	(*LK8)(2,VV[5],VV[6])                     /*  MAKE-VAR        */;
	V26= list(4,(V27),(V24),T0,VALUES(0));}
	CAR((V25)) = (V26);
	}
	(VV[0]->s.s_dbind)= CONS((V24),(VV[0]->s.s_dbind));
	goto L143;
	}
L145:
	if((CDDDR((V13)))!=Cnil){
	goto L161;}
	if((CDDDR((V13)))==Cnil){
	goto L163;}
	(*LK1)(2,VV[4],(V13))                     /*  CMPERR          */;
L163:
	{object V25;                              /*  INIT            */
	object V26;
	object V27;                               /*  V               */
	(*LK6)(2,CADDR((V13)),(V20))              /*  C1EXPR*         */;
	V26= VALUES(0);
	(*LK4)(4,CADR((V13)),(V15),(V16),(V17))   /*  C1MAKE-VAR      */;
	V27= VALUES(0);
	V25= V26;
	V19= CONS(CADR((V13)),(V19));
	{object V28;
	object V29;
	V28= (V22);
	{object V30= CAR((V13));
	(*LK7)(3,((V27))->v.v_self[6],(V25),CADDR((V13)))/*  AND-FORM-TYPE*/;
	T0= VALUES(0);
	(*LK8)(2,VV[5],VV[6])                     /*  MAKE-VAR        */;
	V29= list(4,(V30),(V27),T0,VALUES(0));}
	CAR((V28)) = (V29);
	}
	(VV[0]->s.s_dbind)= CONS((V27),(VV[0]->s.s_dbind));
	goto L143;
	}
L161:
	if((CDDDDR((V13)))==Cnil){
	goto L177;}
	(*LK1)(2,VV[4],(V13))                     /*  CMPERR          */;
L177:
	{object V28;                              /*  INIT            */
	object V29;
	object V30;                               /*  V               */
	object V31;
	object V32;                               /*  SV              */
	(*LK6)(2,CADDR((V13)),(V20))              /*  C1EXPR*         */;
	V29= VALUES(0);
	(*LK4)(4,CADR((V13)),(V15),(V16),(V17))   /*  C1MAKE-VAR      */;
	V31= VALUES(0);
	(*LK4)(4,CADDDR((V13)),(V15),(V16),(V17)) /*  C1MAKE-VAR      */;
	V32= VALUES(0);
	V28= V29;
	V30= V31;
	V19= CONS(CADR((V13)),(V19));
	V19= CONS(CADDDR((V13)),(V19));
	{object V33;
	object V34;
	V33= (V22);
	{object V35= CAR((V13));
	(*LK7)(3,((V30))->v.v_self[6],(V28),CADDR((V13)))/*  AND-FORM-TYPE*/;
	V34= list(4,(V35),(V30),VALUES(0),(V32));}
	CAR((V33)) = (V34);
	}
	(VV[0]->s.s_dbind)= CONS((V30),(VV[0]->s.s_dbind));
	(VV[0]->s.s_dbind)= CONS((V32),(VV[0]->s.s_dbind));
	}
L143:
	V22= CDR((V22));
	goto L137;
	}
L135:
	if(((V10))==Cnil){
	goto L198;}
	(*LK0)(0)                                 /*  MAKE-INFO       */;
	V21= VALUES(0);
	{volatile object V22;                     /*  SPECS           */
	V22= (V10);
L205:
	if(((V22))!=Cnil){
	goto L206;}
	goto L203;
L206:
	V13= CAR((V22));
	if(!(type_of((V13))==t_cons)){
	goto L213;}
	if(!(type_of(CDR((V13)))==t_symbol)){
	goto L216;}
	if((CDR((V13)))==Cnil){
	goto L218;}
	(*LK1)(2,VV[4],(V13))                     /*  CMPERR          */;
L218:
	{object V24;                              /*  V               */
	(*LK4)(4,CAR((V13)),(V15),(V16),(V17))    /*  C1MAKE-VAR      */;
	V24= VALUES(0);
	V19= CONS(CAR((V13)),(V19));
	(*LK5)(1,((V24))->v.v_self[6])            /*  DEFAULT-INIT    */;
	V11= CONS(VALUES(0),(V11));
	{object V25;
	object V26;
	V25= (V22);
	V26= (V24);
	CAR((V25)) = (V26);
	}
	(VV[0]->s.s_dbind)= CONS((V24),(VV[0]->s.s_dbind));
	goto L211;
	}
L216:
	if((CDDR((V13)))==Cnil){
	goto L232;}
	(*LK1)(2,VV[4],(V13))                     /*  CMPERR          */;
L232:
	{object V25;                              /*  INIT            */
	object V26;
	object V27;                               /*  V               */
	(*LK6)(2,CADR((V13)),(V21))               /*  C1EXPR*         */;
	V26= VALUES(0);
	(*LK4)(4,CAR((V13)),(V15),(V16),(V17))    /*  C1MAKE-VAR      */;
	V27= VALUES(0);
	V25= V26;
	V19= CONS(CAR((V13)),(V19));
	(*LK7)(3,((V27))->v.v_self[6],(V25),CADR((V13)))/*  AND-FORM-TYPE*/;
	V11= CONS(VALUES(0),(V11));
	{object V28;
	object V29;
	V28= (V22);
	V29= (V27);
	CAR((V28)) = (V29);
	}
	(VV[0]->s.s_dbind)= CONS((V27),(VV[0]->s.s_dbind));
	goto L211;
	}
L213:
	{object V28;                              /*  V               */
	(*LK4)(4,(V13),(V15),(V16),(V17))         /*  C1MAKE-VAR      */;
	V28= VALUES(0);
	V19= CONS((V13),(V19));
	(*LK5)(1,((V28))->v.v_self[6])            /*  DEFAULT-INIT    */;
	V11= CONS(VALUES(0),(V11));
	{object V29;
	object V30;
	V29= (V22);
	V30= (V28);
	CAR((V29)) = (V30);
	}
	(VV[0]->s.s_dbind)= CONS((V28),(VV[0]->s.s_dbind));
	}
L211:
	V22= CDR((V22));
	goto L205;
	}
L203:
	V11= nreverse((V11));
	(*LK9)(2,(V20),(V21))                     /*  ADD-INFO        */;
L198:
	(*LK10)(3,(V19),(V17),(V16))              /*  CHECK-VDECL     */;
	(*LK11)(2,(V18),(V14))                    /*  C1DECL-BODY     */;
	V14= VALUES(0);
	(*LK9)(2,(V20),CADR((V14)))               /*  ADD-INFO        */;
	{volatile object V22;
	volatile object V23;                      /*  VAR             */
	V22= (V4);
	V23= Cnil;
L271:
	if(!((V22)==Cnil)){
	goto L272;}
	goto L267;
L272:
	V23= CAR((V22));
	(*LK12)(1,(V23))                          /*  CHECK-VREF      */;
	V22= CDR((V22));
	goto L271;
	}
L267:
	{volatile object V22;
	volatile object V23;                      /*  OPT             */
	V22= (V5);
	V23= Cnil;
L285:
	if(!((V22)==Cnil)){
	goto L286;}
	goto L281;
L286:
	V23= CAR((V22));
	(*LK12)(1,CAR((V23)))                     /*  CHECK-VREF      */;
	if((CADDR((V23)))==Cnil){
	goto L292;}
	(*LK12)(1,CADDR((V23)))                   /*  CHECK-VREF      */;
L292:
	V22= CDR((V22));
	goto L285;
	}
L281:
	if(((V6))==Cnil){
	goto L298;}
	(*LK12)(1,(V6))                           /*  CHECK-VREF      */;
L298:
	{volatile object V22;
	volatile object V23;                      /*  KWD             */
	V22= (V7);
	V23= Cnil;
L305:
	if(!((V22)==Cnil)){
	goto L306;}
	goto L301;
L306:
	V23= CAR((V22));
	(*LK12)(1,CADR((V23)))                    /*  CHECK-VREF      */;
	if((CADDDR((V23)))==Cnil){
	goto L312;}
	(*LK12)(1,CADDDR((V23)))                  /*  CHECK-VREF      */;
L312:
	V22= CDR((V22));
	goto L305;
	}
L301:
	{volatile object V22;
	volatile object V23;                      /*  VAR             */
	V22= (V10);
	V23= Cnil;
L322:
	if(!((V22)==Cnil)){
	goto L323;}
	goto L318;
L323:
	V23= CAR((V22));
	(*LK12)(1,(V23))                          /*  CHECK-VREF      */;
	V22= CDR((V22));
	goto L322;
	}
L318:
	if(((V10))==Cnil){
	goto L332;}
	(*LK9)(2,(V21),CADR((V14)))               /*  ADD-INFO        */;
	V14= list(5,VV[7],(V21),(V10),(V11),(V14));
L332:
	{int V22;
	VALUES(0)=list(5,VV[2],(V20),list(6,(V4),(V5),(V6),(V8),(V7),(V9)),(V12),(V14));
	V22=1;
	bds_unwind1;
	RETURN(V22);}
	}
	}
}
/*	function definition for PARSE-LAMBDA-LIST                     */
static L2(int narg, object V1)
{ VT4 VLEX4 CLSR4
TTL:
	{register object V2;                      /*  SPEC            */
	register object V3;                       /*  REQUIREDS       */
	register object V4;                       /*  OPTIONALS       */
	object V5;                                /*  REST            */
	object V6;                                /*  KEY-FLAG        */
	register object V7;                       /*  KEYWORDS        */
	object V8;                                /*  ALLOW-OTHER-KEYS*/
	register object V9;                       /*  AUX-VARS        */
	V2= Cnil;
	V3= Cnil;
	V4= Cnil;
	V5= Cnil;
	V6= Cnil;
	V7= Cnil;
	V8= Cnil;
	V9= Cnil;
L347:
	if(((V1))!=Cnil){
	goto L352;}
	goto L345;
L352:
	if(type_of((V1))==t_cons){
	goto L355;}
	(*LK1)(2,VV[8],(V1))                      /*  CMPERR          */;
L355:
	{object V11;
	V11= CAR((V1));
	V1= CDR((V1));
	V2= (V11);
	}
	if(((V2)!= VV[40]))goto L363;
	goto L348;
L363:
	if(((V2)!= VV[39]))goto L364;
	goto L349;
L364:
	if(((V2)!= VV[42]))goto L365;
	goto L350;
L365:
	if(((V2)!= VV[44]))goto L366;
	goto L351;
L366:
	V3= CONS((V2),(V3));
	goto L347;
L348:
	if(((V1))!=Cnil){
	goto L369;}
	goto L345;
L369:
	if(type_of((V1))==t_cons){
	goto L372;}
	(*LK1)(2,VV[8],(V1))                      /*  CMPERR          */;
L372:
	{object V12;
	V12= CAR((V1));
	V1= CDR((V1));
	V2= (V12);
	}
	if(((V2)!= VV[39]))goto L380;
	goto L349;
L380:
	if(((V2)!= VV[42]))goto L381;
	goto L350;
L381:
	if(((V2)!= VV[44]))goto L382;
	goto L351;
L382:
	V4= CONS((V2),(V4));
	goto L348;
L349:
	if(type_of((V1))==t_cons){
	goto L385;}
	(*LK1)(2,VV[8],(V1))                      /*  CMPERR          */;
L385:
	{object V12;
	V12= CAR((V1));
	V1= CDR((V1));
	V5= (V12);
	}
	if(((V1))!=Cnil){
	goto L393;}
	goto L345;
L393:
	if(type_of((V1))==t_cons){
	goto L396;}
	(*LK1)(2,VV[8],(V1))                      /*  CMPERR          */;
L396:
	{object V13;
	V13= CAR((V1));
	V1= CDR((V1));
	V2= (V13);
	}
	if(((V2)!= VV[42]))goto L404;
	goto L350;
L404:
	if(((V2)!= VV[44]))goto L405;
	goto L351;
L405:
	(*LK1)(2,VV[9],(V2))                      /*  CMPERR          */;
L350:
	V6= Ct;
	if(((V1))!=Cnil){
	goto L408;}
	goto L345;
L408:
	if(type_of((V1))==t_cons){
	goto L411;}
	(*LK1)(2,VV[8],(V1))                      /*  CMPERR          */;
L411:
	{object V14;
	V14= CAR((V1));
	V1= CDR((V1));
	V2= (V14);
	}
	if(((V2)!= VV[44]))goto L419;
	goto L351;
L419:
	if(((V2)!= VV[43]))goto L420;
	V8= Ct;
	if(((V1))!=Cnil){
	goto L423;}
	goto L345;
L423:
	if(type_of((V1))==t_cons){
	goto L426;}
	(*LK1)(2,VV[8],(V1))                      /*  CMPERR          */;
L426:
	{object V14;
	V14= CAR((V1));
	V1= CDR((V1));
	V2= (V14);
	}
	if(((V2)!= VV[44]))goto L434;
	goto L351;
L434:
	(*LK1)(2,VV[10],(V2))                     /*  CMPERR          */;
	goto L414;
L420:
L414:
	if(type_of((V2))==t_cons){
	goto L435;}
	V2= CONS((V2),Cnil);
L435:
	if(!(type_of(CAR((V2)))==t_cons)){
	goto L441;}
	{object V14= CAAR((V2));
	if(!((type_of(V14)==t_symbol&&(V14)->s.s_hpack==keyword_package))){
	goto L444;}}
	if(!(type_of(CDAR((V2)))==t_cons)){
	goto L444;}
	if((CDDAR((V2)))==Cnil){
	goto L443;}
L444:
	(*LK1)(2,VV[4],(V2))                      /*  CMPERR          */;
L443:
	V2= listA(3,CAAR((V2)),CADAR((V2)),CDR((V2)));
	goto L439;
L441:
	if(type_of(CAR((V2)))==t_symbol){
	goto L451;}
	(*LK1)(2,VV[4],(V2))                      /*  CMPERR          */;
L451:
	Lintern(2,coerce_to_string(CAR((V2))),VV[11])/*  INTERN       */;
	T0= VALUES(0);
	V2= listA(3,T0,CAR((V2)),CDR((V2)));
L439:
	V7= CONS((V2),(V7));
	goto L350;
L351:
	if(((V1))!=Cnil){
	goto L458;}
	goto L345;
L458:
	if(type_of((V1))==t_cons){
	goto L461;}
	(*LK1)(2,VV[8],(V1))                      /*  CMPERR          */;
L461:
	{object V15;
	V15= CAR((V1));
	V1= CDR((V1));
	VALUES(0) = (V15);
	}
	V9= CONS(VALUES(0),(V9));
	goto L351;
L345:
	{object V10= nreverse((V3));
	{object V11= nreverse((V4));
	{object V12= nreverse((V7));
	VALUES(6) = nreverse((V9));
	VALUES(5) = (V8);
	VALUES(4) = (V12);
	VALUES(3) = (V6);
	VALUES(2) = (V5);
	VALUES(1) = (V11);
	VALUES(0) = (V10);
	RETURN(7);}}}
	}
}
/*	function definition for C2LAMBDA-EXPR                         */
static L3(int narg, object V1, object V2, object V3, object V4, ...)
{ VT5 VLEX5 CLSR5
	bds_check;
	{int i=4;
	volatile object V5;
	volatile object V6;
	va_list args; va_start(args, V4);
	if (i==narg) goto L471;
	V5= va_arg(args, object);
	i++;
	if (i==narg) goto L472;
	V6= va_arg(args, object);
	i++;
	goto L473;
L471:
	V5= Cnil;
L472:
	V6= Cnil;
L473:
	{volatile object V7;
	if((V4)==Cnil){
	V7= Cnil;
	goto L476;}
	if(type_of((V4))==t_symbol){
	goto L477;}
	V7= Cnil;
	goto L476;
L477:
	{volatile object V8;
	volatile object V9;                       /*  VAR             */
	V8= CAR((V1));
	V9= Cnil;
L484:
	if(!((V8)==Cnil)){
	goto L485;}
	goto L479;
L485:
	V9= CAR((V8));
	if((((V9))->v.v_self[2])==Cnil){
	goto L490;}
	goto L480;
L490:
	V8= CDR((V8));
	goto L484;
	}
L480:
	V7= Cnil;
	goto L476;
L479:
	if(CADR((V1))==Cnil){
	goto L496;}
	V7= Cnil;
	goto L476;
L496:
	if(CADDR((V1))==Cnil){
	goto L498;}
	V7= Cnil;
	goto L476;
L498:
	if(CADDDR((V1))==Cnil){
	goto L500;}
	V7= Cnil;
	goto L476;
L500:
	V7= CONS((V4),CAR((V1)));
L476:
	bds_bind(VV[12],V7);                      /*  *TAIL-RECURSION-INFO**/
	if((CADDDR((V1)))==Cnil){
	goto L503;}
	{int V8;
	V8=L7(5,(V1),(V2),(V5),(V6),(V3))         /*  C2LAMBDA-EXPR-WITH-KEY*/;
	bds_unwind1;
	RETURN(V8);}
L503:
	{int V9;
	V9=L4(4,(V1),(V2),(V5),(V6))              /*  C2LAMBDA-EXPR-WITHOUT-KEY*/;
	bds_unwind1;
	RETURN(V9);}
	}
	}
}
/*	function definition for C2LAMBDA-EXPR-WITHOUT-KEY             */
static L4(int narg, object V1, object V2, object V3, object V4)
{ VT6 VLEX6 CLSR6
	bds_check;
TTL:
	{object V5;                               /*  REQUIREDS       */
	object V6;                                /*  OPTIONALS       */
	object V7;                                /*  REST            */
	object V8;                                /*  REST-LOC        */
	register int V9;                          /*  NREQ            */
	register object V10;                      /*  LABELS          */
	V5= CAR((V1));
	V6= CADR((V1));
	V7= CADDR((V1));
	V8= Cnil;
	V9= length((V5));
	V10= Cnil;
	bds_bind(VV[13],(VV[13]->s.s_dbind));     /*  *UNWIND-EXIT*   */
	bds_bind(VV[14],(VV[14]->s.s_dbind));     /*  *ENV*           */
	lex0[0]=Cnil;                             /*  BLOCK-P         */
	if(!((VV[15])==((V4)))){
	goto L513;}
	{volatile object V11;                     /*  REQS            */
	volatile int V12;                         /*  REQI            */
	volatile object V13;                      /*  LCL_I           */
	V12= fix(one_plus((VV[16]->s.s_dbind)));
	V13= list(2,VV[17],MAKE_FIXNUM(0));
	V11= (V5);
L518:
	if(!((V11)==Cnil)){
	goto L519;}
	(VV[16]->s.s_dbind)= MAKE_FIXNUM(V12);
	goto L511;
L519:
	if(!(((CAR((V11)))->v.v_self[4])==(VV[18]))){
	goto L525;}
	{object V15;
	register int V16;
	V15= (V13);
	V16= V12;
	CAR(CDR((V15))) = MAKE_FIXNUM(V16);
	}
	(*LK13)(2,(V13),CAR((V11)))               /*  BIND            */;
	goto L523;
L525:
	elt_set(CAR((V11)),5,MAKE_FIXNUM(V12));
L523:
	V11= CDR((V11));
	V12= (V12)+1;
	goto L518;
	}
L513:
	{volatile object V15;
	V15= number_plus((VV[16]->s.s_dbind),MAKE_FIXNUM(V9));
	lex0[1]=V15;                              /*  LCL             */
	{volatile object V16;                     /*  REQS            */
	volatile int V17;                         /*  REQI            */
	volatile object V18;                      /*  VAR             */
	V17= fix(one_plus((VV[16]->s.s_dbind)));
	V16= (V5);
	V18= Cnil;
L540:
	if(!((V16)==Cnil)){
	goto L541;}
	goto L537;
L541:
	V18= CAR((V16));
	(*LK14)(1,(V18))                          /*  UNBOXED         */;
	if(VALUES(0)==Cnil){
	goto L546;}
	LC5(lex0,1,(V18))                         /*  WT-DECL         */;
	elt_set((V18),5,VALUES(0));
L546:
	V16= CDR((V16));
	V17= (V17)+1;
	goto L540;
	}
L537:
	if(((V7))==Cnil){
	goto L554;}
	if(!(number_compare(((V7))->v.v_self[1],MAKE_FIXNUM(1))<0)){
	goto L554;}
	V7= Cnil;
L554:
	if(((V6))==Cnil){
	goto L560;}
	if((lex0[0])!=Cnil){
	goto L563;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_char(123,symbol_value(VV[19]));
	lex0[0]= Ct;
L563:
	princ_str("int i=",symbol_value(VV[19]));
	(*LK15)(1,MAKE_FIXNUM(V9))                /*  WT1             */;
	princ_char(59,symbol_value(VV[19]));
L560:
	{volatile object V16;
	volatile object V17;                      /*  OPT             */
	V16= (V6);
	V17= Cnil;
L578:
	if(!((V16)==Cnil)){
	goto L579;}
	goto L574;
L579:
	V17= CAR((V16));
	LC6(lex0,1,CAR((V17)))                    /*  DO-DECL         */;
	if((CADDR((V17)))==Cnil){
	goto L585;}
	LC6(lex0,1,CADDR((V17)))                  /*  DO-DECL         */;
L585:
	V16= CDR((V16));
	goto L578;
	}
L574:
	if(((V7))==Cnil){
	goto L536;}
	LC5(lex0,1,(V7))                          /*  WT-DECL         */;
	V8= list(2,VV[17],VALUES(0));
L536:
	if(((V6))!=Cnil){
	goto L596;}
	if(((V7))==Cnil){
	goto L595;}
L596:
	if((lex0[0])!=Cnil){
	goto L600;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_char(123,symbol_value(VV[19]));
	lex0[0]= Ct;
L600:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("va_list args; va_start(args, ",symbol_value(VV[19]));
	if(!((V9)>0)){
	goto L614;}
	(*LK16)(1,MAKE_FIXNUM(V9))                /*  WT-LCL          */;
	goto L612;
L614:
	if(((V3))==Cnil){
	goto L617;}
	princ_str("env0",symbol_value(VV[19]));
	goto L612;
L617:
	princ_str("narg",symbol_value(VV[19]));
L612:
	princ_str(");",symbol_value(VV[19]));
L595:
	if(((VV[21]->s.s_dbind))!=Cnil){
	goto L623;}
	if(((VV[22]->s.s_dbind))==Cnil){
	goto L622;}
L623:
	if(((V7))!=Cnil){
	goto L627;}
	if(((V6))==Cnil){
	goto L628;}
L627:
	if(((V5))==Cnil){
	goto L632;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("if(narg<",symbol_value(VV[19]));
	(*LK15)(1,MAKE_FIXNUM(V9))                /*  WT1             */;
	princ_str(") FEtoo_few_arguments(&narg);",symbol_value(VV[19]));
L632:
	if(((V7))!=Cnil){
	goto L622;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("if(narg>",symbol_value(VV[19]));
	(*LK15)(1,number_plus(MAKE_FIXNUM(V9),MAKE_FIXNUM(length((V6)))))/*  WT1*/;
	princ_str(") FEtoo_many_arguments(&narg);",symbol_value(VV[19]));
	goto L622;
L628:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("check_arg(",symbol_value(VV[19]));
	(*LK15)(1,MAKE_FIXNUM(V9))                /*  WT1             */;
	princ_str(");",symbol_value(VV[19]));
L622:
	{volatile object V16;                     /*  REQS            */
	volatile int V17;                         /*  REQI            */
	volatile object V18;                      /*  LCL_I           */
	V17= fix(one_plus((VV[16]->s.s_dbind)));
	V18= list(2,VV[17],MAKE_FIXNUM(0));
	V16= (V5);
L656:
	if(!((V16)==Cnil)){
	goto L657;}
	goto L652;
L657:
	{object V20;
	register int V21;
	V20= (V18);
	V21= V17;
	CAR(CDR((V20))) = MAKE_FIXNUM(V21);
	}
	(*LK13)(2,(V18),CAR((V16)))               /*  BIND            */;
	V16= CDR((V16));
	V17= (V17)+1;
	goto L656;
	}
L652:
	(VV[16]->s.s_dbind)= lex0[1];
	}
L511:
	if(((V6))==Cnil){
	goto L670;}
	{volatile object V11;
	volatile object V12;                      /*  OPT             */
	V11= (V6);
	V12= Cnil;
L677:
	if(!((V11)==Cnil)){
	goto L678;}
	goto L673;
L678:
	V12= CAR((V11));
	(VV[23]->s.s_dbind)= number_plus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	V10= CONS(CONS((VV[23]->s.s_dbind),Cnil),(V10));
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("if (i==narg) ",symbol_value(VV[19]));
	CDR(CAR((V10))) = Ct;
	princ_str("goto L",symbol_value(VV[19]));
	(*LK15)(1,CAR(CAR((V10))))                /*  WT1             */;
	princ_char(59,symbol_value(VV[19]));
	(*LK13)(2,VV[24],CAR((V12)))              /*  BIND            */;
	if((CADDR((V12)))==Cnil){
	goto L696;}
	(*LK13)(2,Ct,CADDR((V12)))                /*  BIND            */;
L696:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("i++;",symbol_value(VV[19]));
	V11= CDR((V11));
	goto L677;
	}
L673:
	{volatile object V11;                     /*  LABEL           */
	(VV[23]->s.s_dbind)= number_plus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	V11= CONS((VV[23]->s.s_dbind),Cnil);
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	CDR((V11)) = Ct;
	princ_str("goto L",symbol_value(VV[19]));
	(*LK15)(1,CAR((V11)))                     /*  WT1             */;
	princ_char(59,symbol_value(VV[19]));
	V10= nreverse((V10));
	{volatile object V12;
	volatile object V13;                      /*  OPT             */
	V12= (V6);
	V13= Cnil;
L722:
	if(!((V12)==Cnil)){
	goto L723;}
	goto L718;
L723:
	V13= CAR((V12));
	if((CDR(CAR((V10))))==Cnil){
	goto L728;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	princ_char(76,symbol_value(VV[19]));
	(*LK15)(1,CAR(CAR((V10))))                /*  WT1             */;
	princ_char(58,symbol_value(VV[19]));
L728:
	{object V15;
	V15= CAR((V10));
	V10= CDR((V10));
	}
	(*LK17)(3,CAR((V13)),CADR((V13)),Ct)      /*  BIND-INIT       */;
	if((CADDR((V13)))==Cnil){
	goto L740;}
	(*LK13)(3,Cnil,CADDR((V13)),Ct)           /*  BIND            */;
L740:
	V12= CDR((V12));
	goto L722;
	}
L718:
	if((CDR((V11)))==Cnil){
	goto L670;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	princ_char(76,symbol_value(VV[19]));
	(*LK15)(1,CAR((V11)))                     /*  WT1             */;
	princ_char(58,symbol_value(VV[19]));
	}
L670:
	if(((V7))==Cnil){
	goto L752;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("narg -=",symbol_value(VV[19]));
	(*LK15)(1,number_plus(MAKE_FIXNUM(V9),MAKE_FIXNUM(length((V6)))))/*  WT1*/;
	princ_char(59,symbol_value(VV[19]));
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	(*LK15)(1,(V8))                           /*  WT1             */;
	if(!((((V7))->v.v_self[6])==(VV[25]))){
	goto L767;}
	princ_str("=(ALLOCA_CONS(narg),ON_STACK_MAKE_LIST(narg));",symbol_value(VV[19]));
	goto L765;
L767:
	princ_str("=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));",symbol_value(VV[19]));
L765:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("{ object p=",symbol_value(VV[19]));
	(*LK15)(1,(V8))                           /*  WT1             */;
	princ_char(59,symbol_value(VV[19]));
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str(" for(;narg-->0;p=CDR(p))",symbol_value(VV[19]));
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("   CAR(p)=va_arg(args, object);}",symbol_value(VV[19]));
	(*LK13)(2,(V8),(V7))                      /*  BIND            */;
L752:
	if(((VV[12]->s.s_dbind))==Cnil){
	goto L785;}
	(VV[13]->s.s_dbind)= CONS(VV[26],(VV[13]->s.s_dbind));
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	princ_str("TTL:",symbol_value(VV[19]));
L785:
	(*LK18)(1,(V2))                           /*  C2EXPR          */;
	if((lex0[0])==Cnil){
	goto L794;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_char(125,symbol_value(VV[19]));
	{int V11;
	VALUES(0)=Cnil;
	V11=1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V11);}
L794:
	{int V12;
	VALUES(0)=Cnil;
	V12=1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V12);}
	}
}
/*	local function DO-DECL                                        */
static LC6(object *lex0,int narg, object V1)
{ VT7 VLEX7 CLSR7
TTL:
	(*LK19)(1,(V1))                           /*  LOCAL           */;
	if(VALUES(0)==Cnil){
	goto L800;}
	LC5(lex0,1,(V1))                          /*  WT-DECL         */;
	VALUES(0) = elt_set((V1),5,VALUES(0));
	RETURN(1);
L800:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	local function WT-DECL                                        */
static LC5(object *lex0,int narg, object V1)
{ VT8 VLEX8 CLSR8
TTL:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	if((lex0[0])!=Cnil){
	goto L806;}
	princ_char(123,symbol_value(VV[19]));
	lex0[0]= Ct;
L806:
	(*LK15)(1,(VV[20]->s.s_dbind))            /*  WT1             */;
	(*LK20)(1,(V1))                           /*  REGISTER        */;
	(*LK15)(1,VALUES(0))                      /*  WT1             */;
	(*LK21)(1,((V1))->v.v_self[4])            /*  REP-TYPE        */;
	(*LK15)(1,VALUES(0))                      /*  WT1             */;
	lex0[1]= MAKE_FIXNUM((fix(lex0[1]))+(1));
	(*LK16)(1,lex0[1])                        /*  WT-LCL          */;
	princ_char(59,symbol_value(VV[19]));
	VALUES(0) = lex0[1];
	RETURN(1);
}
/*	function definition for C2LAMBDA-EXPR-WITH-KEY                */
static L7(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT9 VLEX9 CLSR9
	bds_check;
TTL:
	{object V6;                               /*  REQUIREDS       */
	object V7;                                /*  OPTIONALS       */
	object V8;                                /*  REST            */
	object V9;                                /*  REST-LOC        */
	object V10;                               /*  KEY-FLAG        */
	object V11;                               /*  KEYWORDS        */
	object V12;                               /*  ALLOW-OTHER-KEYS*/
	int V13;                                  /*  NREQ            */
	register int V14;                         /*  NKEY            */
	register object V15;                      /*  LABELS          */
	object V16;                               /*  LAST-ARG        */
	V6= CAR((V1));
	V7= CADR((V1));
	V8= CADDR((V1));
	V9= Cnil;
	V10= CADDDR((V1));
	Lfifth(1,(V1))                            /*  FIFTH           */;
	V11= VALUES(0);
	Lsixth(1,(V1))                            /*  SIXTH           */;
	V12= VALUES(0);
	V13= length((V6));
	V14= length((V11));
	V15= Cnil;
	bds_bind(VV[13],(VV[13]->s.s_dbind));     /*  *UNWIND-EXIT*   */
	bds_bind(VV[14],(VV[14]->s.s_dbind));     /*  *ENV*           */
	lex0[0]=Cnil;                             /*  BLOCK-P         */
	V16= Cnil;
	{volatile object V17;
	V17= number_plus((VV[16]->s.s_dbind),MAKE_FIXNUM(V13));
	lex0[1]=V17;                              /*  LCL             */
	{volatile object V18;                     /*  REQS            */
	volatile int V19;                         /*  REQI            */
	volatile object V20;                      /*  VAR             */
	V19= fix(one_plus((VV[16]->s.s_dbind)));
	V18= (V6);
	V20= Cnil;
L839:
	if(!((V18)==Cnil)){
	goto L840;}
	goto L836;
L840:
	V20= CAR((V18));
	(*LK14)(1,(V20))                          /*  UNBOXED         */;
	if(VALUES(0)==Cnil){
	goto L845;}
	LC8(lex0,1,(V20))                         /*  WT-DECL         */;
	elt_set((V20),5,VALUES(0));
L845:
	V18= CDR((V18));
	V19= (V19)+1;
	goto L839;
	}
L836:
	if(((V8))==Cnil){
	goto L853;}
	if(!(number_compare(((V8))->v.v_self[1],MAKE_FIXNUM(1))<0)){
	goto L853;}
	V8= Cnil;
L853:
	if(((V7))==Cnil){
	goto L859;}
	if((lex0[0])!=Cnil){
	goto L862;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_char(123,symbol_value(VV[19]));
	lex0[0]= Ct;
L862:
	princ_str("int i=",symbol_value(VV[19]));
	(*LK15)(1,MAKE_FIXNUM(V13))               /*  WT1             */;
	princ_char(59,symbol_value(VV[19]));
L859:
	{volatile object V18;
	volatile object V19;                      /*  OPT             */
	V18= (V7);
	V19= Cnil;
L877:
	if(!((V18)==Cnil)){
	goto L878;}
	goto L873;
L878:
	V19= CAR((V18));
	LC9(lex0,1,CAR((V19)))                    /*  DO-DECL         */;
	if((CADDR((V19)))==Cnil){
	goto L884;}
	LC9(lex0,1,CADDR((V19)))                  /*  DO-DECL         */;
L884:
	V18= CDR((V18));
	goto L877;
	}
L873:
	if(((V8))==Cnil){
	goto L890;}
	LC8(lex0,1,(V8))                          /*  WT-DECL         */;
	V9= list(2,VV[17],VALUES(0));
L890:
	{volatile object V18;
	volatile object V19;                      /*  KEY             */
	V18= (V11);
	V19= Cnil;
L898:
	if(!((V18)==Cnil)){
	goto L899;}
	goto L835;
L899:
	V19= CAR((V18));
	LC9(lex0,1,CADR((V19)))                   /*  DO-DECL         */;
	if((CADDDR((V19)))==Cnil){
	goto L905;}
	LC9(lex0,1,CADDDR((V19)))                 /*  DO-DECL         */;
L905:
	V18= CDR((V18));
	goto L898;
	}
L835:
	if(((V4))!=Cnil){
	goto L911;}
	if((lex0[0])!=Cnil){
	goto L914;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_char(123,symbol_value(VV[19]));
	lex0[0]= Ct;
L914:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("va_list args; va_start(args, ",symbol_value(VV[19]));
	if(!((V13)>0)){
	goto L930;}
	Lformat(3,Cnil,VV[27],MAKE_FIXNUM(V13))   /*  FORMAT          */;
	V16= VALUES(0);
	goto L928;
L930:
	if(((V3))==Cnil){
	goto L933;}
	V16= VV[28];
	goto L928;
L933:
	V16= VV[29];
L928:
	(*LK15)(1,(V16))                          /*  WT1             */;
	princ_str(");",symbol_value(VV[19]));
L911:
	if(((VV[21]->s.s_dbind))!=Cnil){
	goto L938;}
	if(((VV[22]->s.s_dbind))==Cnil){
	goto L936;}
L938:
	if(((V6))==Cnil){
	goto L936;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("if(narg<",symbol_value(VV[19]));
	(*LK15)(1,MAKE_FIXNUM(V13))               /*  WT1             */;
	princ_str(") FEtoo_few_arguments(&narg);",symbol_value(VV[19]));
L936:
	{volatile object V18;                     /*  REQS            */
	volatile int V19;                         /*  REQI            */
	volatile object V20;                      /*  LCL_I           */
	V19= fix(one_plus((VV[16]->s.s_dbind)));
	V20= list(2,VV[17],MAKE_FIXNUM(0));
	V18= (V6);
L952:
	if(!((V18)==Cnil)){
	goto L953;}
	goto L948;
L953:
	{object V22;
	register int V23;
	V22= (V20);
	V23= V19;
	CAR(CDR((V22))) = MAKE_FIXNUM(V23);
	}
	(*LK13)(2,(V20),CAR((V18)))               /*  BIND            */;
	V18= CDR((V18));
	V19= (V19)+1;
	goto L952;
	}
L948:
	(VV[16]->s.s_dbind)= lex0[1];
	}
	if(((V7))==Cnil){
	goto L966;}
	{volatile object V17;
	volatile object V18;                      /*  OPT             */
	V17= (V7);
	V18= Cnil;
L973:
	if(!((V17)==Cnil)){
	goto L974;}
	goto L969;
L974:
	V18= CAR((V17));
	(VV[23]->s.s_dbind)= number_plus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	V15= CONS(CONS((VV[23]->s.s_dbind),Cnil),(V15));
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("if (i==narg) ",symbol_value(VV[19]));
	CDR(CAR((V15))) = Ct;
	princ_str("goto L",symbol_value(VV[19]));
	(*LK15)(1,CAR(CAR((V15))))                /*  WT1             */;
	princ_char(59,symbol_value(VV[19]));
	(*LK13)(2,VV[30],CAR((V18)))              /*  BIND            */;
	if((CADDR((V18)))==Cnil){
	goto L992;}
	(*LK13)(2,Ct,CADDR((V18)))                /*  BIND            */;
L992:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("i++;",symbol_value(VV[19]));
	V17= CDR((V17));
	goto L973;
	}
L969:
	{volatile object V17;                     /*  LABEL           */
	(VV[23]->s.s_dbind)= number_plus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	V17= CONS((VV[23]->s.s_dbind),Cnil);
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	CDR((V17)) = Ct;
	princ_str("goto L",symbol_value(VV[19]));
	(*LK15)(1,CAR((V17)))                     /*  WT1             */;
	princ_char(59,symbol_value(VV[19]));
	V15= nreverse((V15));
	{volatile object V18;
	volatile object V19;                      /*  OPT             */
	V18= (V7);
	V19= Cnil;
L1018:
	if(!((V18)==Cnil)){
	goto L1019;}
	goto L1014;
L1019:
	V19= CAR((V18));
	if((CDR(CAR((V15))))==Cnil){
	goto L1024;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	princ_char(76,symbol_value(VV[19]));
	(*LK15)(1,CAR(CAR((V15))))                /*  WT1             */;
	princ_char(58,symbol_value(VV[19]));
L1024:
	{object V21;
	V21= CAR((V15));
	V15= CDR((V15));
	}
	(*LK17)(3,CAR((V19)),CADR((V19)),Ct)      /*  BIND-INIT       */;
	if((CADDR((V19)))==Cnil){
	goto L1036;}
	(*LK13)(3,Cnil,CADDR((V19)),Ct)           /*  BIND            */;
L1036:
	V18= CDR((V18));
	goto L1018;
	}
L1014:
	if((CDR((V17)))==Cnil){
	goto L966;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	princ_char(76,symbol_value(VV[19]));
	(*LK15)(1,CAR((V17)))                     /*  WT1             */;
	princ_char(58,symbol_value(VV[19]));
	}
L966:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("narg -=",symbol_value(VV[19]));
	(*LK15)(1,number_plus(MAKE_FIXNUM(V13),MAKE_FIXNUM(length((V7)))))/*  WT1*/;
	princ_char(59,symbol_value(VV[19]));
	if(((V8))==Cnil){
	goto L1054;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	(*LK15)(1,(V9))                           /*  WT1             */;
	if(!((((V8))->v.v_self[6])==(VV[25]))){
	goto L1063;}
	princ_str("=(ALLOCA_CONS(narg),ON_STACK_MAKE_LIST(narg));",symbol_value(VV[19]));
	goto L1061;
L1063:
	princ_str("=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));",symbol_value(VV[19]));
L1061:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("{ int n=narg; object p=",symbol_value(VV[19]));
	(*LK15)(1,(V9))                           /*  WT1             */;
	princ_char(59,symbol_value(VV[19]));
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str(" for(;n-->0;p=CDR(p))",symbol_value(VV[19]));
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("   CAR(p)=va_arg(args, object);}",symbol_value(VV[19]));
	(*LK13)(2,(V9),(V8))                      /*  BIND            */;
L1054:
	princ_char(10,symbol_value(VV[31]));
	princ_str("static intUobject L",symbol_value(VV[31]));
	(*LK22)(1,(V5))                           /*  WT-H1           */;
	princ_str("keys[",symbol_value(VV[31]));
	(*LK22)(1,MAKE_FIXNUM(length((V11))))     /*  WT-H1           */;
	princ_str("]={",symbol_value(VV[31]));
	{volatile object V17;                     /*  KWDS            */
	V17= (V11);
L1090:
	if(((V17))!=Cnil){
	goto L1091;}
	princ_str("};",symbol_value(VV[31]));
	goto L1088;
L1091:
	(*LK23)(1,CAAR((V17)))                    /*  ADD-SYMBOL      */;
	princ(VALUES(0),(VV[31]->s.s_dbind));
	if((CDR((V17)))==Cnil){
	goto L1096;}
	princ_char(44,symbol_value(VV[31]));
L1096:
	V17= CDR((V17));
	goto L1090;
	}
L1088:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("{ object keyvars[",symbol_value(VV[19]));
	(*LK15)(1,fixnum_times(2,V14))            /*  WT1             */;
	princ_str("];",symbol_value(VV[19]));
	if(((V8))==Cnil){
	goto L1108;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("va_start(args,",symbol_value(VV[19]));
	(*LK15)(1,(V16))                          /*  WT1             */;
	princ_str(");",symbol_value(VV[19]));
L1108:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("parse_key(narg,args,",symbol_value(VV[19]));
	(*LK15)(1,MAKE_FIXNUM(length((V11))))     /*  WT1             */;
	princ_str(",L",symbol_value(VV[19]));
	(*LK15)(1,(V5))                           /*  WT1             */;
	princ_str("keys,keyvars,",symbol_value(VV[19]));
	if(((V8))==Cnil){
	goto L1126;}
	(*LK15)(1,(V9))                           /*  WT1             */;
	goto L1124;
L1126:
	princ_str("OBJNULL",symbol_value(VV[19]));
L1124:
	if(((V12))==Cnil){
	goto L1134;}
	VALUES(0) = VV[32];
	goto L1132;
L1134:
	VALUES(0) = VV[33];
L1132:
	(*LK15)(1,VALUES(0))                      /*  WT1             */;
	{volatile object V17;                     /*  KEYVARS[I]      */
	volatile int V18;                         /*  I               */
	V18= 0;
	V17= VV[34];
	{volatile object V19;
	volatile object V20;                      /*  KWD             */
	V19= (V11);
	V20= Cnil;
L1141:
	if(!((V19)==Cnil)){
	goto L1142;}
	goto L1136;
L1142:
	V20= CAR((V19));
	if(!((CAR(CADDR((V20))))==(VV[35]))){
	goto L1149;}
	if((CADDR(CADDR((V20))))!=Cnil){
	goto L1149;}
	{object V22;
	register int V23;
	V22= (V17);
	V23= V18;
	CAR(CDR((V22))) = MAKE_FIXNUM(V23);
	}
	(*LK13)(2,(V17),CADR((V20)))              /*  BIND            */;
	goto L1147;
L1149:
	{object V22;
	object V23;
	V22= (V17);
	V23= number_plus(MAKE_FIXNUM(V14),MAKE_FIXNUM(V18));
	CAR(CDR((V22))) = (V23);
	}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("if(",symbol_value(VV[19]));
	(*LK24)(1,(V17))                          /*  WT-LOC          */;
	princ_str("==Cnil){",symbol_value(VV[19]));
	(*LK17)(3,CADR((V20)),CADDR((V20)),Ct)    /*  BIND-INIT       */;
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("}else{",symbol_value(VV[19]));
	{object V22;
	register int V23;
	V22= (V17);
	V23= V18;
	CAR(CDR((V22))) = MAKE_FIXNUM(V23);
	}
	(*LK13)(2,(V17),CADR((V20)))              /*  BIND            */;
	princ_char(125,symbol_value(VV[19]));
L1147:
	if(((CADDDR((V20)))->v.v_self[4])==(VV[6])){
	goto L1179;}
	{object V22;
	object V23;
	V22= (V17);
	V23= number_plus(MAKE_FIXNUM(V14),MAKE_FIXNUM(V18));
	CAR(CDR((V22))) = (V23);
	}
	(*LK13)(2,(V17),CADDDR((V20)))            /*  BIND            */;
L1179:
	V18= (V18)+(1);
	V19= CDR((V19));
	goto L1141;
	}
	}
L1136:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_char(125,symbol_value(VV[19]));
	(*LK18)(1,(V2))                           /*  C2EXPR          */;
	if((lex0[0])==Cnil){
	goto L1197;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_char(125,symbol_value(VV[19]));
	{int V17;
	VALUES(0)=Cnil;
	V17=1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V17);}
L1197:
	{int V18;
	VALUES(0)=Cnil;
	V18=1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V18);}
	}
}
/*	local function DO-DECL                                        */
static LC9(object *lex0,int narg, object V1)
{ VT10 VLEX10 CLSR10
TTL:
	(*LK19)(1,(V1))                           /*  LOCAL           */;
	if(VALUES(0)==Cnil){
	goto L1203;}
	LC8(lex0,1,(V1))                          /*  WT-DECL         */;
	VALUES(0) = elt_set((V1),5,VALUES(0));
	RETURN(1);
L1203:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	local function WT-DECL                                        */
static LC8(object *lex0,int narg, object V1)
{ VT11 VLEX11 CLSR11
TTL:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	if((lex0[0])!=Cnil){
	goto L1209;}
	princ_char(123,symbol_value(VV[19]));
	lex0[0]= Ct;
L1209:
	(*LK15)(1,(VV[20]->s.s_dbind))            /*  WT1             */;
	(*LK20)(1,(V1))                           /*  REGISTER        */;
	(*LK15)(1,VALUES(0))                      /*  WT1             */;
	(*LK21)(1,((V1))->v.v_self[4])            /*  REP-TYPE        */;
	(*LK15)(1,VALUES(0))                      /*  WT1             */;
	lex0[1]= MAKE_FIXNUM((fix(lex0[1]))+(1));
	(*LK16)(1,lex0[1])                        /*  WT-LCL          */;
	princ_char(59,symbol_value(VV[19]));
	VALUES(0) = lex0[1];
	RETURN(1);
}
/*	function definition for NEED-TO-SET-VS-POINTERS               */
static L10(int narg, object V1)
{ VT12 VLEX12 CLSR12
TTL:
	if((VV[21]->s.s_dbind)!=Cnil){
	VALUES(0) = (VV[21]->s.s_dbind);
	RETURN(1);}
	if((VV[22]->s.s_dbind)!=Cnil){
	VALUES(0) = (VV[22]->s.s_dbind);
	RETURN(1);}
	VALUES(0) = CADR((V1));
	if(VALUES(0)==Cnil)goto L1225;
	RETURN(1);
L1225:
	VALUES(0) = CADDR((V1));
	if(VALUES(0)==Cnil)goto L1227;
	RETURN(1);
L1227:
	VALUES(0) = CADDDR((V1));
	RETURN(1);
}
/*	function definition for C1DM                                  */
static L11(int narg, object V1, object V2, object V3)
{ VT13 VLEX13 CLSR13
TTL:
	{object V4;                               /*  WHOLE           */
	object V5;                                /*  ENV             */
	object V6;                                /*  SETJMPS         */
	object V7;                                /*  DOC             */
	object V8;                                /*  SS              */
	object V9;                                /*  IS              */
	object V10;                               /*  TS              */
	object V11;                               /*  OTHER-DECLS     */
	object V12;                               /*  PPN             */
	V4= Cnil;
	V5= Cnil;
	lex0[0]=Cnil;                             /*  VNAMES          */
	(*LK0)(0)                                 /*  MAKE-INFO       */;
	lex0[1]=VALUES(0);                        /*  DM-INFO         */
	lex0[2]=Cnil;                             /*  DM-VARS         */
	V6= (VV[36]->s.s_dbind);
	V7= Cnil;
	V8= Cnil;
	V9= Cnil;
	V10= Cnil;
	V11= Cnil;
	V12= Cnil;
	{ int V13;
	V13=(*LK2)(2,(V3),Ct)                     /*  C1BODY          */;
	if (V13>0) {
	V3= VALUES(0);
	V13--;
	} else {
	V3= Cnil;}
	if (V13>0) {
	V8= VALUES(1);
	V13--;
	} else {
	V8= Cnil;}
	if (V13>0) {
	V10= VALUES(2);
	V13--;
	} else {
	V10= Cnil;}
	if (V13>0) {
	V9= VALUES(3);
	V13--;
	} else {
	V9= Cnil;}
	if (V13>0) {
	V11= VALUES(4);
	V13--;
	} else {
	V11= Cnil;}
	if (V13>0) {
	V7= VALUES(5);
	} else {
	V7= Cnil;}
	
	}
	V3= CONS(listA(3,VV[3],(V1),(V3)),Cnil);
	(*LK3)(1,(V8))                            /*  C1ADD-GLOBALS   */;
	if(!(type_of((V2))==t_cons||(V2)==Cnil)){
	goto L1244;}
	if(!((CAR((V2)))==(VV[37]))){
	goto L1244;}
	lex0[0]= CONS(CADR((V2)),lex0[0]);
	(*LK4)(4,CADR((V2)),(V8),(V9),(V10))      /*  C1MAKE-VAR      */;
	V4= VALUES(0);
	lex0[2]= CONS((V4),lex0[2]);
	(VV[0]->s.s_dbind)= CONS((V4),(VV[0]->s.s_dbind));
	V2= CDDR((V2));
L1244:
	{volatile object V13;                     /*  X               */
	V13= (V2);
L1260:
	if(!(type_of((V13))!=t_cons)){
	goto L1261;}
	goto L1258;
L1261:
	if(!((CAR((V13)))==(VV[38]))){
	goto L1264;}
	lex0[0]= CONS(CADR((V13)),lex0[0]);
	(*LK4)(4,CADR((V13)),(V8),(V9),(V10))     /*  C1MAKE-VAR      */;
	V5= VALUES(0);
	lex0[2]= CONS((V5),lex0[2]);
	(VV[0]->s.s_dbind)= CONS((V5),(VV[0]->s.s_dbind));
	Lldiff(2,(V2),(V13))                      /*  LDIFF           */;
	T0= VALUES(0);
	V2= nconc(T0,CDDR((V13)));
L1264:
	V13= CDR((V13));
	goto L1260;
	}
L1258:
	{ int V13;
	V13=LC12(lex0,4,(V2),(V8),(V9),(V10))     /*  C1DM-VL         */;
	if (V13>0) {
	V2= VALUES(0);
	V13--;
	} else {
	V2= Cnil;}
	if (V13>0) {
	V12= VALUES(1);
	} else {
	V12= Cnil;}
	
	}
	(*LK10)(3,lex0[0],(V10),(V9))             /*  CHECK-VDECL     */;
	(*LK11)(2,(V11),(V3))                     /*  C1DECL-BODY     */;
	V3= VALUES(0);
	(*LK9)(2,lex0[1],CADR((V3)))              /*  ADD-INFO        */;
	if(eql((V6),(VV[36]->s.s_dbind))){
	goto L1286;}
	elt_set(lex0[1],5,Ct);
	putprop((V1),Ct,VV[45]);
L1286:
	{volatile object V13;
	volatile object V14;                      /*  V               */
	V13= lex0[2];
	V14= Cnil;
L1294:
	if(!((V13)==Cnil)){
	goto L1295;}
	goto L1290;
L1295:
	V14= CAR((V13));
	(*LK12)(1,(V14))                          /*  CHECK-VREF      */;
	V13= CDR((V13));
	goto L1294;
	}
L1290:
	VALUES(0) = list(6,(V7),(V12),(V4),(V5),(V2),(V3));
	RETURN(1);
	}
}
/*	local function C1DM-V                                         */
static LC13(object *lex0,int narg, object V1, object V2, object V3, object V4)
{ VT14 VLEX14 CLSR14
TTL:
	if(!(type_of((V1))==t_symbol)){
	goto L1305;}
	lex0[0]= CONS((V1),lex0[0]);
	(*LK4)(4,(V1),(V2),(V3),(V4))             /*  C1MAKE-VAR      */;
	V1= VALUES(0);
	(VV[0]->s.s_dbind)= CONS((V1),(VV[0]->s.s_dbind));
	lex0[2]= CONS((V1),lex0[2]);
	VALUES(0) = (V1);
	RETURN(1);
L1305:
	RETURN(LC12(lex0,4,(V1),(V2),(V3),(V4))   /*  C1DM-VL         */);
}
/*	local function C1DM-VL                                        */
static LC12(object *lex0,int narg, object V1, object V2, object V3, object V4)
{ VT15 VLEX15 CLSR15
TTL:
	{volatile object V5;                      /*  OPTIONALP       */
	volatile object V6;                       /*  RESTP           */
	volatile object V7;                       /*  KEYP            */
	volatile object V8;                       /*  ALLOW-OTHER-KEYS-P*/
	volatile object V9;                       /*  AUXP            */
	volatile object V10;                      /*  REQUIREDS       */
	volatile object V11;                      /*  OPTIONALS       */
	volatile object V12;                      /*  REST            */
	volatile object V13;                      /*  KEY-FLAG        */
	volatile object V14;                      /*  KEYWORDS        */
	volatile object V15;                      /*  AUXS            */
	volatile object V16;                      /*  ALLOW-OTHER-KEYS*/
	volatile object V17;                      /*  N               */
	volatile object V18;                      /*  PPN             */
	V5= Cnil;
	V6= Cnil;
	V7= Cnil;
	V8= Cnil;
	V9= Cnil;
	V10= Cnil;
	V11= Cnil;
	V12= Cnil;
	V13= Cnil;
	V14= Cnil;
	V15= Cnil;
	V16= Cnil;
	V17= MAKE_FIXNUM(0);
	V18= Cnil;
L1316:
	if(type_of((V1))==t_cons){
	goto L1317;}
	if(((V1))==Cnil){
	goto L1320;}
	if(((V6))==Cnil){
	goto L1323;}
	(*LK25)(1,VV[39])                         /*  DM-BAD-KEY      */;
L1323:
	LC13(lex0,4,(V1),(V2),(V3),(V4))          /*  C1DM-V          */;
	V12= VALUES(0);
L1320:
	{object V20= nreverse((V10));
	{object V21= nreverse((V11));
	{object V22= nreverse((V14));
	VALUES(1) = (V18);
	VALUES(0) = list(7,(V20),(V21),(V12),(V13),(V22),(V16),nreverse((V15)));
	RETURN(2);}}}
L1317:
	{register object V23;                     /*  V               */
	V23= CAR((V1));
	if(!(((V23))==(VV[40]))){
	goto L1330;}
	if(((V5))==Cnil){
	goto L1332;}
	(*LK25)(1,VV[40])                         /*  DM-BAD-KEY      */;
L1332:
	V5= Ct;
	{object V24;
	V24= CAR((V1));
	V1= CDR((V1));
	goto L1327;
	}
L1330:
	if(((V23))==(VV[39])){
	goto L1340;}
	if(!(((V23))==(VV[41]))){
	goto L1341;}
L1340:
	if(((V6))==Cnil){
	goto L1345;}
	(*LK25)(1,(V23))                          /*  DM-BAD-KEY      */;
L1345:
	LC13(lex0,4,CADR((V1)),(V2),(V3),(V4))    /*  C1DM-V          */;
	V12= VALUES(0);
	V6= Ct;
	V5= Ct;
	V1= CDDR((V1));
	if(!(((V23))==(VV[41]))){
	goto L1327;}
	V18= (V17);
	goto L1327;
L1341:
	if(!(((V23))==(VV[42]))){
	goto L1360;}
	if(((V7))==Cnil){
	goto L1362;}
	(*LK25)(1,VV[42])                         /*  DM-BAD-KEY      */;
L1362:
	V7= Ct;
	V6= Ct;
	V5= Ct;
	V13= Ct;
	{object V25;
	V25= CAR((V1));
	V1= CDR((V1));
	goto L1327;
	}
L1360:
	if(!(((V23))==(VV[43]))){
	goto L1377;}
	if(((V7))==Cnil){
	goto L1380;}
	if(((V8))==Cnil){
	goto L1379;}
L1380:
	(*LK25)(1,VV[43])                         /*  DM-BAD-KEY      */;
L1379:
	V8= Ct;
	V16= Ct;
	{object V26;
	V26= CAR((V1));
	V1= CDR((V1));
	goto L1327;
	}
L1377:
	if(!(((V23))==(VV[44]))){
	goto L1392;}
	if(((V9))==Cnil){
	goto L1394;}
	(*LK25)(1,VV[44])                         /*  DM-BAD-KEY      */;
L1394:
	V9= Ct;
	V8= Ct;
	V7= Ct;
	V6= Ct;
	V5= Ct;
	{object V27;
	V27= CAR((V1));
	V1= CDR((V1));
	goto L1327;
	}
L1392:
	if(((V9))==Cnil){
	goto L1411;}
	{object V28;                              /*  X               */
	object V29;                               /*  INIT            */
	V28= Cnil;
	V29= Cnil;
	if(!(type_of((V23))==t_symbol)){
	goto L1416;}
	V28= (V23);
	(*LK26)(0)                                /*  C1NIL           */;
	V29= VALUES(0);
	goto L1414;
L1416:
	V28= CAR((V23));
	if(!(CDR((V23))==Cnil)){
	goto L1424;}
	(*LK26)(0)                                /*  C1NIL           */;
	V29= VALUES(0);
	goto L1414;
L1424:
	(*LK6)(2,CADR((V23)),lex0[1])             /*  C1EXPR*         */;
	V29= VALUES(0);
L1414:
	LC13(lex0,4,(V28),(V2),(V3),(V4))         /*  C1DM-V          */;
	V15= CONS(list(2,VALUES(0),(V29)),(V15));
	}
	{object V28;
	V28= CAR((V1));
	V1= CDR((V1));
	goto L1327;
	}
L1411:
	if(((V7))==Cnil){
	goto L1434;}
	{object V29;                              /*  X               */
	object V30;                               /*  K               */
	object V31;                               /*  INIT            */
	object V32;                               /*  SV              */
	V29= Cnil;
	V30= Cnil;
	V31= Cnil;
	V32= Cnil;
	if(!(type_of((V23))==t_symbol)){
	goto L1439;}
	V29= (V23);
	Lintern(2,coerce_to_string((V23)),VV[11]) /*  INTERN          */;
	V30= VALUES(0);
	(*LK26)(0)                                /*  C1NIL           */;
	V31= VALUES(0);
	goto L1437;
L1439:
	if(!(type_of(CAR((V23)))==t_symbol)){
	goto L1448;}
	V29= CAR((V23));
	Lintern(2,coerce_to_string(CAR((V23))),VV[11])/*  INTERN      */;
	V30= VALUES(0);
	goto L1446;
L1448:
	V29= CADAR((V23));
	V30= CAAR((V23));
L1446:
	if(!(CDR((V23))==Cnil)){
	goto L1457;}
	(*LK26)(0)                                /*  C1NIL           */;
	V31= VALUES(0);
	goto L1437;
L1457:
	(*LK6)(2,CADR((V23)),lex0[1])             /*  C1EXPR*         */;
	V31= VALUES(0);
	if(CDDR((V23))==Cnil){
	goto L1437;}
	V32= CADDR((V23));
L1437:
	LC13(lex0,4,(V29),(V2),(V3),(V4))         /*  C1DM-V          */;
	T0= VALUES(0);
	if(((V32))==Cnil){
	goto L1469;}
	LC13(lex0,4,(V32),(V2),(V3),(V4))         /*  C1DM-V          */;
	goto L1467;
L1469:
	VALUES(0) = Cnil;
L1467:
	V14= CONS(list(4,(V30),T0,(V31),VALUES(0)),(V14));
	}
	{object V29;
	V29= CAR((V1));
	V1= CDR((V1));
	goto L1327;
	}
L1434:
	if(((V5))==Cnil){
	goto L1475;}
	{object V30;                              /*  X               */
	object V31;                               /*  INIT            */
	object V32;                               /*  SV              */
	V30= Cnil;
	V31= Cnil;
	V32= Cnil;
	if(!(type_of((V23))==t_symbol)){
	goto L1480;}
	V30= (V23);
	(*LK26)(0)                                /*  C1NIL           */;
	V31= VALUES(0);
	goto L1478;
L1480:
	V30= CAR((V23));
	if(!(CDR((V23))==Cnil)){
	goto L1488;}
	(*LK26)(0)                                /*  C1NIL           */;
	V31= VALUES(0);
	goto L1478;
L1488:
	(*LK6)(2,CADR((V23)),lex0[1])             /*  C1EXPR*         */;
	V31= VALUES(0);
	if(CDDR((V23))==Cnil){
	goto L1478;}
	V32= CADDR((V23));
L1478:
	LC13(lex0,4,(V30),(V2),(V3),(V4))         /*  C1DM-V          */;
	T0= VALUES(0);
	if(((V32))==Cnil){
	goto L1500;}
	LC13(lex0,4,(V32),(V2),(V3),(V4))         /*  C1DM-V          */;
	goto L1498;
L1500:
	VALUES(0) = Cnil;
L1498:
	V11= CONS(list(3,T0,(V31),VALUES(0)),(V11));
	}
	{object V30;
	V30= CAR((V1));
	V1= CDR((V1));
	}
	V17= number_plus((V17),MAKE_FIXNUM(1));
	goto L1327;
L1475:
	LC13(lex0,4,(V23),(V2),(V3),(V4))         /*  C1DM-V          */;
	V10= CONS(VALUES(0),(V10));
	{object V30;
	V30= CAR((V1));
	V1= CDR((V1));
	}
	V17= number_plus((V17),MAKE_FIXNUM(1));
	}
L1327:
	goto L1316;
	}
}
/*	function definition for C1DM-BAD-KEY                          */
static L14(int narg, object V1)
{ VT16 VLEX16 CLSR16
TTL:
	RETURN((*LK1)(2,VV[46],(V1))              /*  CMPERR          */);
}
/*	function definition for C2DM                                  */
static L15(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT17 VLEX17 CLSR17
	bds_check;
	lex0[0]=V1;                               /*  NAME            */
TTL:
	{object V6;                               /*  LCL             */
	V6= Cnil;
	if(((VV[21]->s.s_dbind))!=Cnil){
	goto L1519;}
	if(((VV[22]->s.s_dbind))==Cnil){
	goto L1518;}
L1519:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("check_arg(2);",symbol_value(VV[19]));
L1518:
	(*LK27)(0)                                /*  NEXT-LCL        */;
	V6= VALUES(0);
	if(((V2))==Cnil){
	goto L1528;}
	(*LK12)(1,(V2))                           /*  CHECK-VREF      */;
	(*LK13)(2,list(2,VV[17],(V6)),(V2))       /*  BIND            */;
L1528:
	(*LK27)(0)                                /*  NEXT-LCL        */;
	V6= VALUES(0);
	if(((V3))==Cnil){
	goto L1534;}
	(*LK12)(1,(V3))                           /*  CHECK-VREF      */;
	(*LK13)(2,list(2,VV[17],(V6)),(V3))       /*  BIND            */;
L1534:
	(*LK27)(0)                                /*  NEXT-LCL        */;
	V6= VALUES(0);
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("{object ",symbol_value(VV[19]));
	(*LK16)(1,(V6))                           /*  WT-LCL          */;
	princ_str("=CDR(V1)",symbol_value(VV[19]));
	LC17(lex0,1,(V4))                         /*  RESERVE-VL      */;
	princ_char(59,symbol_value(VV[19]));
	LC20(lex0,2,(V4),(V6))                    /*  DM-BIND-VL      */;
	(*LK18)(1,(V5))                           /*  C2EXPR          */;
	princ_char(125,symbol_value(VV[19]));
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	local function DM-BIND-INIT                                   */
static LC19(object *lex0,int narg, object V1)
{ VT18 VLEX18 CLSR18
TTL:
	{object V2;                               /*  V               */
	object V3;                                /*  INIT            */
	V2= CAR((V1));
	V3= CADR((V1));
	if(!(type_of((V2))==t_cons)){
	goto L1556;}
	{object V4;                               /*  LCL             */
	object V5;                                /*  LOC             */
	bds_bind(VV[49],MAKE_FIXNUM(0));          /*  *INLINE-BLOCKS* */
	(*LK27)(0)                                /*  NEXT-LCL        */;
	V4= VALUES(0);
	(*LK28)(1,CONS((V3),Cnil))                /*  INLINE-ARGS     */;
	V5= CADR(CAR(VALUES(0)));
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	(*LK16)(1,(V4))                           /*  WT-LCL          */;
	princ_str("= ",symbol_value(VV[19]));
	(*LK15)(1,(V5))                           /*  WT1             */;
	princ_char(59,symbol_value(VV[19]));
	LC20(lex0,2,(V2),(V4))                    /*  DM-BIND-VL      */;
	{int V6;
	V6=(*LK29)(0)                             /*  CLOSE-INLINE-BLOCKS*/;
	bds_unwind1;
	RETURN(V6);}
	}
L1556:
	RETURN((*LK17)(2,(V2),(V3))               /*  BIND-INIT       */);
	}
}
/*	local function DM-BIND-LOC                                    */
static LC18(object *lex0,int narg, object V1, object V2)
{ VT19 VLEX19 CLSR19
TTL:
	if(!(type_of((V1))==t_cons)){
	goto L1571;}
	{object V3;                               /*  LCL             */
	(*LK27)(0)                                /*  NEXT-LCL        */;
	V3= VALUES(0);
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("{object ",symbol_value(VV[19]));
	(*LK16)(1,(V3))                           /*  WT-LCL          */;
	princ_str("= ",symbol_value(VV[19]));
	(*LK15)(1,(V2))                           /*  WT1             */;
	princ_char(59,symbol_value(VV[19]));
	LC20(lex0,2,(V1),(V3))                    /*  DM-BIND-VL      */;
	princ_char(125,symbol_value(VV[19]));
	VALUES(0) = Cnil;
	RETURN(1);
	}
L1571:
	RETURN((*LK13)(2,(V2),(V1))               /*  BIND            */);
}
/*	local function RESERVE-V                                      */
static LC16(object *lex0,int narg, object V1)
{ VT20 VLEX20 CLSR20
TTL:
	if(!(type_of((V1))==t_cons)){
	goto L1586;}
	RETURN(LC17(lex0,1,(V1))                  /*  RESERVE-VL      */);
L1586:
	(*LK19)(1,(V1))                           /*  LOCAL           */;
	if(VALUES(0)==Cnil){
	goto L1589;}
	{object V2;                               /*  LCL             */
	(*LK27)(0)                                /*  NEXT-LCL        */;
	V2= VALUES(0);
	elt_set((V1),5,(V2));
	elt_set((V1),4,VV[48]);
	princ_char(44,symbol_value(VV[19]));
	RETURN((*LK16)(1,(V2))                    /*  WT-LCL          */);
	}
L1589:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	local function DM-BIND-VL                                     */
static LC20(object *lex0,int narg, object V1, object V2)
{ VT21 VLEX21 CLSR21
TTL:
	{object V3;                               /*  REQUIREDS       */
	object V4;                                /*  OPTIONALS       */
	object V5;                                /*  REST            */
	object V6;                                /*  KEY-FLAG        */
	object V7;                                /*  KEYWORDS        */
	object V8;                                /*  ALLOW-OTHER-KEYS*/
	object V9;                                /*  AUXS            */
	V3= CAR((V1));
	V4= CADR((V1));
	V5= CADDR((V1));
	V6= CADDDR((V1));
	Lfifth(1,(V1))                            /*  FIFTH           */;
	V7= VALUES(0);
	Lsixth(1,(V1))                            /*  SIXTH           */;
	V8= VALUES(0);
	Lseventh(1,(V1))                          /*  SEVENTH         */;
	V9= VALUES(0);
	{volatile object V10;                     /*  REQS            */
	V10= (V3);
L1605:
	if(!((V10)==Cnil)){
	goto L1606;}
	goto L1603;
L1606:
	if(((VV[21]->s.s_dbind))!=Cnil){
	goto L1610;}
	if(((VV[22]->s.s_dbind))==Cnil){
	goto L1609;}
L1610:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("if(endp(",symbol_value(VV[19]));
	(*LK16)(1,(V2))                           /*  WT-LCL          */;
	princ_str("))FEinvalid_macro_call(VV[",symbol_value(VV[19]));
	(*LK23)(1,lex0[0])                        /*  ADD-SYMBOL      */;
	(*LK15)(1,VALUES(0))                      /*  WT1             */;
	princ_str("]);",symbol_value(VV[19]));
L1609:
	{object V12= CAR((V10));
	LC18(lex0,2,(V12),list(2,VV[47],(V2)))    /*  DM-BIND-LOC     */;}
	if((CDR((V10)))!=Cnil){
	goto L1625;}
	if(((V4))!=Cnil){
	goto L1625;}
	if(((V5))!=Cnil){
	goto L1625;}
	if(((V6))!=Cnil){
	goto L1625;}
	if(((VV[21]->s.s_dbind))!=Cnil){
	goto L1625;}
	if(((VV[22]->s.s_dbind))==Cnil){
	goto L1624;}
L1625:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	(*LK16)(1,(V2))                           /*  WT-LCL          */;
	princ_str("=CDR(",symbol_value(VV[19]));
	(*LK16)(1,(V2))                           /*  WT-LCL          */;
	princ_str(");",symbol_value(VV[19]));
L1624:
	V10= CDR((V10));
	goto L1605;
	}
L1603:
	{volatile object V10;                     /*  OPTS            */
	volatile object V11;                      /*  OPT             */
	V10= (V4);
	V11= Cnil;
L1650:
	if(!((V10)==Cnil)){
	goto L1651;}
	goto L1648;
L1651:
	V11= CAR((V10));
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("if(endp(",symbol_value(VV[19]));
	(*LK16)(1,(V2))                           /*  WT-LCL          */;
	princ_str(")){",symbol_value(VV[19]));
	bds_bind(VV[14],(VV[14]->s.s_dbind));     /*  *ENV*           */
	bds_bind(VV[13],(VV[13]->s.s_dbind));     /*  *UNWIND-EXIT*   */
	LC19(lex0,1,(V11))                        /*  DM-BIND-INIT    */;
	if((CADDR((V11)))==Cnil){
	bds_unwind1;
	bds_unwind1;
	goto L1663;}
	LC18(lex0,2,CADDR((V11)),Cnil)            /*  DM-BIND-LOC     */;
	bds_unwind1;
	bds_unwind1;
L1663:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("} else {",symbol_value(VV[19]));
	{object V13= CAR((V11));
	LC18(lex0,2,(V13),list(2,VV[47],(V2)))    /*  DM-BIND-LOC     */;}
	if((CADDR((V11)))==Cnil){
	goto L1672;}
	LC18(lex0,2,CADDR((V11)),Ct)              /*  DM-BIND-LOC     */;
L1672:
	if((CDR((V10)))!=Cnil){
	goto L1676;}
	if(((V5))!=Cnil){
	goto L1676;}
	if(((V6))!=Cnil){
	goto L1676;}
	if(((VV[21]->s.s_dbind))!=Cnil){
	goto L1676;}
	if(((VV[22]->s.s_dbind))==Cnil){
	goto L1675;}
L1676:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	(*LK16)(1,(V2))                           /*  WT-LCL          */;
	princ_str("=CDR(",symbol_value(VV[19]));
	(*LK16)(1,(V2))                           /*  WT-LCL          */;
	princ_str(");",symbol_value(VV[19]));
L1675:
	princ_char(125,symbol_value(VV[19]));
	V10= CDR((V10));
	goto L1650;
	}
L1648:
	if(((V5))==Cnil){
	goto L1699;}
	LC18(lex0,2,(V5),list(2,VV[17],(V2)))     /*  DM-BIND-LOC     */;
L1699:
	if(((V7))==Cnil){
	goto L1702;}
	{volatile object V10;                     /*  LCL1            */
	volatile object V11;                      /*  LOC1            */
	(*LK27)(0)                                /*  NEXT-LCL        */;
	V10= VALUES(0);
	V11= list(2,VV[17],(V10));
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("{object ",symbol_value(VV[19]));
	(*LK15)(1,(V11))                          /*  WT1             */;
	princ_char(59,symbol_value(VV[19]));
	{volatile object V12;
	volatile object V13;                      /*  KWD             */
	V12= (V7);
	V13= Cnil;
L1717:
	if(!((V12)==Cnil)){
	goto L1718;}
	goto L1713;
L1718:
	V13= CAR((V12));
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	(*LK15)(1,(V11))                          /*  WT1             */;
	princ_str("=getf(",symbol_value(VV[19]));
	(*LK16)(1,(V2))                           /*  WT-LCL          */;
	princ_str(",VV[",symbol_value(VV[19]));
	(*LK23)(1,CAR((V13)))                     /*  ADD-SYMBOL      */;
	(*LK15)(1,VALUES(0))                      /*  WT1             */;
	princ_str("],OBJNULL);",symbol_value(VV[19]));
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("if(",symbol_value(VV[19]));
	(*LK15)(1,(V11))                          /*  WT1             */;
	princ_str("==OBJNULL){",symbol_value(VV[19]));
	bds_bind(VV[14],(VV[14]->s.s_dbind));     /*  *ENV*           */
	bds_bind(VV[13],(VV[13]->s.s_dbind));     /*  *UNWIND-EXIT*   */
	LC19(lex0,1,CDR((V13)))                   /*  DM-BIND-INIT    */;
	if((CADDDR((V13)))==Cnil){
	goto L1742;}
	LC18(lex0,2,CADDDR((V13)),Cnil)           /*  DM-BIND-LOC     */;
L1742:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("} else {",symbol_value(VV[19]));
	bds_unwind1;
	bds_unwind1;
	LC18(lex0,2,CADR((V13)),(V11))            /*  DM-BIND-LOC     */;
	if((CADDDR((V13)))==Cnil){
	goto L1749;}
	LC18(lex0,2,CADDDR((V13)),Ct)             /*  DM-BIND-LOC     */;
L1749:
	princ_char(125,symbol_value(VV[19]));
	V12= CDR((V12));
	goto L1717;
	}
L1713:
	princ_char(125,symbol_value(VV[19]));
	}
L1702:
	if(((VV[21]->s.s_dbind))!=Cnil){
	goto L1760;}
	if(((VV[22]->s.s_dbind))==Cnil){
	goto L1758;}
L1760:
	if(((V5))!=Cnil){
	goto L1758;}
	if(((V6))!=Cnil){
	goto L1758;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("if(!endp(",symbol_value(VV[19]));
	(*LK16)(1,(V2))                           /*  WT-LCL          */;
	princ_str("))FEinvalid_macro_call(VV[",symbol_value(VV[19]));
	(*LK23)(1,lex0[0])                        /*  ADD-SYMBOL      */;
	(*LK15)(1,VALUES(0))                      /*  WT1             */;
	princ_str("]);",symbol_value(VV[19]));
L1758:
	if(((VV[21]->s.s_dbind))!=Cnil){
	goto L1778;}
	if(((VV[22]->s.s_dbind))==Cnil){
	goto L1776;}
L1778:
	if(((V6))==Cnil){
	goto L1776;}
	if(((V8))!=Cnil){
	goto L1776;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("check_other_key(",symbol_value(VV[19]));
	(*LK16)(1,(V2))                           /*  WT-LCL          */;
	princ_char(44,symbol_value(VV[19]));
	(*LK15)(1,MAKE_FIXNUM(length((V7))))      /*  WT1             */;
	{volatile object V10;
	volatile object V11;                      /*  KWD             */
	V10= (V7);
	V11= Cnil;
L1797:
	if(!((V10)==Cnil)){
	goto L1798;}
	goto L1793;
L1798:
	V11= CAR((V10));
	princ_str(",VV[",symbol_value(VV[19]));
	(*LK23)(1,CAR((V11)))                     /*  ADD-SYMBOL      */;
	(*LK15)(1,VALUES(0))                      /*  WT1             */;
	princ_char(93,symbol_value(VV[19]));
	V10= CDR((V10));
	goto L1797;
	}
L1793:
	princ_str(");",symbol_value(VV[19]));
L1776:
	{volatile object V10;
	volatile object V11;                      /*  AUX             */
	V10= (V9);
	V11= Cnil;
L1815:
	if(!((V10)==Cnil)){
	goto L1816;}
	VALUES(0) = Cnil;
	RETURN(1);
L1816:
	V11= CAR((V10));
	LC19(lex0,1,(V11))                        /*  DM-BIND-INIT    */;
	V10= CDR((V10));
	goto L1815;
	}
	}
}
/*	local function RESERVE-VL                                     */
static LC17(object *lex0,int narg, object V1)
{ VT22 VLEX22 CLSR22
TTL:
	{volatile object V2;
	volatile object V3;                       /*  VAR             */
	V2= CAR((V1));
	V3= Cnil;
L1829:
	if(!((V2)==Cnil)){
	goto L1830;}
	goto L1825;
L1830:
	V3= CAR((V2));
	LC16(lex0,1,(V3))                         /*  RESERVE-V       */;
	V2= CDR((V2));
	goto L1829;
	}
L1825:
	{volatile object V2;
	volatile object V3;                       /*  OPT             */
	V2= CADR((V1));
	V3= Cnil;
L1843:
	if(!((V2)==Cnil)){
	goto L1844;}
	goto L1839;
L1844:
	V3= CAR((V2));
	LC16(lex0,1,CAR((V3)))                    /*  RESERVE-V       */;
	if((CADDR((V3)))==Cnil){
	goto L1850;}
	LC16(lex0,1,CADDR((V3)))                  /*  RESERVE-V       */;
L1850:
	V2= CDR((V2));
	goto L1843;
	}
L1839:
	if((CADDR((V1)))==Cnil){
	goto L1856;}
	LC16(lex0,1,CADDR((V1)))                  /*  RESERVE-V       */;
L1856:
	{volatile object V2;
	volatile object V3;                       /*  KWD             */
	Lfifth(1,(V1))                            /*  FIFTH           */;
	V2= VALUES(0);
	V3= Cnil;
L1863:
	if(!((V2)==Cnil)){
	goto L1864;}
	goto L1859;
L1864:
	V3= CAR((V2));
	LC16(lex0,1,CADR((V3)))                   /*  RESERVE-V       */;
	if((CADDDR((V3)))==Cnil){
	goto L1870;}
	LC16(lex0,1,CADDDR((V3)))                 /*  RESERVE-V       */;
L1870:
	V2= CDR((V2));
	goto L1863;
	}
L1859:
	{volatile object V2;
	volatile object V3;                       /*  AUX             */
	Lseventh(1,(V1))                          /*  SEVENTH         */;
	V2= VALUES(0);
	V3= Cnil;
L1879:
	if(!((V2)==Cnil)){
	goto L1880;}
	VALUES(0) = Cnil;
	RETURN(1);
L1880:
	V3= CAR((V2));
	LC16(lex0,1,CAR((V3)))                    /*  RESERVE-V       */;
	V2= CDR((V2));
	goto L1879;
	}
}
static LKF29(int narg, ...) {TRAMPOLINK(VV[88],&LK29);}
static LKF28(int narg, ...) {TRAMPOLINK(VV[87],&LK28);}
static LKF27(int narg, ...) {TRAMPOLINK(VV[86],&LK27);}
static LKF26(int narg, ...) {TRAMPOLINK(VV[85],&LK26);}
static LKF25(int narg, ...) {TRAMPOLINK(VV[84],&LK25);}
static LKF24(int narg, ...) {TRAMPOLINK(VV[83],&LK24);}
static LKF23(int narg, ...) {TRAMPOLINK(VV[82],&LK23);}
static LKF22(int narg, ...) {TRAMPOLINK(VV[81],&LK22);}
static LKF21(int narg, ...) {TRAMPOLINK(VV[80],&LK21);}
static LKF20(int narg, ...) {TRAMPOLINK(VV[79],&LK20);}
static LKF19(int narg, ...) {TRAMPOLINK(VV[78],&LK19);}
static LKF18(int narg, ...) {TRAMPOLINK(VV[77],&LK18);}
static LKF17(int narg, ...) {TRAMPOLINK(VV[76],&LK17);}
static LKF16(int narg, ...) {TRAMPOLINK(VV[75],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[74],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[73],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[72],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[71],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[70],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[69],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[68],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[67],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[66],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[65],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[64],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[63],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[62],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[61],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[60],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[59],&LK0);}
