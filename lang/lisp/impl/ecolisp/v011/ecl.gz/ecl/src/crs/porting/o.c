#include <stdio.h>

int a[100];

extra_lenght_foo()
{
	printf("Hello.\n");
	printf("a[10] = %d\n", a[10]);
}
