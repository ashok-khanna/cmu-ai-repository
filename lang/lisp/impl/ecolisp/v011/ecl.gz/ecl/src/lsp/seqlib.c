
/* (c) Copyright G. Attardi, 1993. All rights reserved. */
#include <ecl.h>
#include "seqlib.h"
init_seqlib(int size, object data_stream)
{VT2
	Cblock.cd_start=(char *)init_seqlib; Cblock.cd_size=size;
	Cblock.cd_data=read_VV(VV,VM1,data_stream);
	funcall(2,symbol_function(VV[27]),VV[0])  /*  PROCLAIM        */;
	funcall(2,symbol_function(VV[27]),VV[1])  /*  PROCLAIM        */;
	MF0(VV[28],L1);
	funcall(2,symbol_function(VV[27]),VV[7])  /*  PROCLAIM        */;
	MF0(VV[29],L2);
	funcall(2,symbol_function(VV[27]),VV[8])  /*  PROCLAIM        */;
	MF0(VV[30],L3);
	MF0(VV[31],L4);
	MF0(VV[32],L5);
	MF0(VV[33],L6);
	MF0key(VV[34],L7,4,L7keys);
	MF0key(VV[35],L8,2,L8keys);
	MF0key(VV[36],L9,4,L9keys);
	MF0key(VV[18],L10,7,L10keys);
	MF0key(VV[37],L11,5,L11keys);
	MF0key(VV[38],L12,5,L12keys);
	MF0key(VV[19],L13,7,L13keys);
	MF0key(VV[39],L14,5,L14keys);
	MF0key(VV[40],L15,5,L15keys);
	MF0key(VV[20],L16,6,L16keys);
	MF0key(VV[41],L17,4,L17keys);
	MF0key(VV[42],L18,4,L18keys);
	MF0key(VV[21],L19,7,L19keys);
	MF0key(VV[22],L20,7,L20keys);
	MF0key(VV[43],L21,5,L21keys);
	MF0key(VV[44],L22,5,L22keys);
	MF0key(VV[23],L23,7,L23keys);
	MF0key(VV[45],L24,5,L24keys);
	MF0key(VV[46],L25,5,L25keys);
	MF0key(VV[24],L26,6,L26keys);
	MF0key(VV[47],L27,4,L27keys);
	MF0key(VV[48],L28,4,L28keys);
	MF0key(VV[25],L29,6,L29keys);
	MF0key(VV[49],L30,4,L30keys);
	MF0key(VV[50],L31,4,L31keys);
	MF0key(VV[51],L32,6,L32keys);
	MF0key(VV[52],L33,6,L33keys);
	MF0key(VV[53],L34,8,L34keys);
	MF0key(VV[54],L35,8,L35keys);
	MF0key(VV[55],L36,1,L36keys);
	MF0(VV[56],L37);
	funcall(2,symbol_function(VV[27]),VV[26]) /*  PROCLAIM        */;
	MF0(VV[57],L39);
	MF0key(VV[58],L40,1,L40keys);
	MF0key(VV[59],L41,1,L41keys);
}
/*	local entry for function SEQTYPE                              */
static object LI1(register object V1)
{ VT3 VLEX3 CLSR3
TTL:
	if(!(type_of((V1))==t_cons||(V1)==Cnil)){
	goto L15;}
	return(VV[2]);
L15:
	if(!(type_of((V1))==t_string)){
	goto L18;}
	return(VV[3]);
L18:
	if(!((type_of((V1))==t_bitvector))){
	goto L21;}
	return(VV[4]);
L21:
	if(!(type_of((V1))==t_vector||
type_of((V1))==t_string||
type_of((V1))==t_bitvector)){
	goto L24;}
	Larray_element_type(1,(V1))               /*  ARRAY-ELEMENT-TYPE*/;
	return(list(2,VV[5],VALUES(0)));
L24:
	return(Lerror(2,VV[6],(V1))               /*  ERROR           */,VALUES(0));
}
/*	local entry for function CALL-TEST                            */
static object LI2(object V1,object V2,object V3,object V4)
{ VT4 VLEX4 CLSR4
TTL:
	if(((V1))==Cnil){
	goto L28;}
	return(funcall(3,(V1),(V3),(V4)),VALUES(0));
L28:
	if(((V2))==Cnil){
	goto L31;}
	funcall(3,(V2),(V3),(V4));
	return(((VALUES(0))==Cnil?Ct:Cnil));
L31:
	return((eql((V3),(V4))?Ct:Cnil));
}
/*	local entry for function TEST-ERROR                           */
static object LI3()
{ VT5 VLEX5 CLSR5
TTL:
	return(Lerror(1,VV[9])                    /*  ERROR           */,VALUES(0));
}
/*	function definition for BAD-SEQ-LIMIT                         */
static L4(int narg, object V1, ...)
{ VT6 VLEX6 CLSR6
	cs_check;
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if(narg<1) FEtoo_few_arguments(&narg);
	if(narg>2) FEtoo_many_arguments(&narg);
	if (i==narg) goto L34;
	V2= va_arg(args, object);
	i++;
	goto L35;
L34:
	V2= Cnil;
L35:
	if(((V2))==Cnil){
	goto L39;}
	VALUES(0) = list(2,(V1),(V2));
	goto L37;
L39:
	VALUES(0) = (V1);
L37:
	RETURN(Lerror(2,VV[10],VALUES(0))         /*  ERROR           */);
	}
}
/*	function definition for THE-END                               */
static L5(int narg, object V1, object V2)
{ VT7 VLEX7 CLSR7
	cs_check;
	check_arg(2);
TTL:
	if(!(FIXNUMP((V1)))){
	goto L42;}
	if((fix((V1)))<=(length((V2)))){
	goto L44;}
	L4(1,(V1))                                /*  BAD-SEQ-LIMIT   */;
L44:
	VALUES(0) = (V1);
	RETURN(1);
L42:
	if(((V1))!=Cnil){
	goto L48;}
	VALUES(0) = MAKE_FIXNUM(length((V2)));
	RETURN(1);
L48:
	RETURN(L4(1,(V1))                         /*  BAD-SEQ-LIMIT   */);
}
/*	function definition for THE-START                             */
static L6(int narg, object V1)
{ VT8 VLEX8 CLSR8
	cs_check;
	check_arg(1);
TTL:
	if(!(FIXNUMP((V1)))){
	goto L51;}
	if((fix((V1)))>=(0)){
	goto L53;}
	L4(1,(V1))                                /*  BAD-SEQ-LIMIT   */;
L53:
	VALUES(0) = (V1);
	RETURN(1);
L51:
	if(((V1))!=Cnil){
	goto L57;}
	VALUES(0) = MAKE_FIXNUM(0);
	RETURN(1);
L57:
	RETURN(L4(1,(V1))                         /*  BAD-SEQ-LIMIT   */);
}
/*	function definition for REDUCE                                */
static L7(int narg, object V1, object V2, ...)
{ VT9 VLEX9 CLSR9
	cs_check;
	{int i=2;
	object V3;
	object V4;
	object V5;
	register object V6;
	object V7;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[8];
	parse_key(narg,args,4,L7keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	V7= keyvars[7];
	}
	{register int V8;                         /*  START           */
	register int V9;                          /*  END             */
	if(((V4))==Cnil){
	goto L61;}
	L6(1,(V4))                                /*  THE-START       */;
	V8= fix(VALUES(0));
	goto L59;
L61:
	V8= 0;
L59:
	L5(2,(V5),(V2))                           /*  THE-END         */;
	V9= fix(VALUES(0));
	if((V8)<=(V9)){
	goto L64;}
	L4(2,MAKE_FIXNUM(V8),MAKE_FIXNUM(V9))     /*  BAD-SEQ-LIMIT   */;
L64:
	if(((V3))!=Cnil){
	goto L68;}
	if(((V7))!=Cnil){
	goto L70;}
	if(!((V8)>=(V9))){
	goto L73;}
	RETURN(funcall(1,(V1)));
L73:
	V6= elt((V2),V8);
	V8= (V8)+(1);
L70:
	{object V10;                              /*  X               */
	V10= (V6);
L80:
	if(!((V8)>=(V9))){
	goto L81;}
	VALUES(0) = (V10);
	RETURN(1);
L81:
	{object V12;
	V12= elt((V2),V8);
	V8= (V8)+(1);
	VALUES(0) = (V12);
	}
	funcall(3,(V1),(V10),VALUES(0));
	V10= VALUES(0);
	goto L80;
	}
L68:
	if(((V7))!=Cnil){
	goto L91;}
	if(!((V8)>=(V9))){
	goto L94;}
	RETURN(funcall(1,(V1)));
L94:
	V9= (V9)-(1);
	V6= elt((V2),V9);
L91:
	{object V12;                              /*  X               */
	V12= (V6);
L101:
	if(!((V8)>=(V9))){
	goto L102;}
	VALUES(0) = (V12);
	RETURN(1);
L102:
	V9= (V9)-(1);
	funcall(3,(V1),elt((V2),V9),(V12));
	V12= VALUES(0);
	goto L101;
	}
	}
	}
}
/*	function definition for FILL                                  */
static L8(int narg, object V1, object V2, ...)
{ VT10 VLEX10 CLSR10
	cs_check;
	{int i=2;
	object V3;
	object V4;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[4];
	parse_key(narg,args,2,L8keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	}
	{int V5;                                  /*  START           */
	int V6;                                   /*  END             */
	if(((V3))==Cnil){
	goto L112;}
	L6(1,(V3))                                /*  THE-START       */;
	V5= fix(VALUES(0));
	goto L110;
L112:
	V5= 0;
L110:
	L5(2,(V4),(V1))                           /*  THE-END         */;
	V6= fix(VALUES(0));
	if((V5)<=(V6)){
	goto L115;}
	L4(2,MAKE_FIXNUM(V5),MAKE_FIXNUM(V6))     /*  BAD-SEQ-LIMIT   */;
L115:
	{register int V7;                         /*  I               */
	V7= V5;
L120:
	if(!((V7)>=(V6))){
	goto L121;}
	VALUES(0) = (V1);
	RETURN(1);
L121:
	elt_set((V1),V7,(V2));
	V7= (V7)+1;
	goto L120;
	}
	}
	}
}
/*	function definition for REPLACE                               */
static L9(int narg, object V1, object V2, ...)
{ VT11 VLEX11 CLSR11
	cs_check;
	{int i=2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[8];
	parse_key(narg,args,4,L9keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	}
	{register int V7;                         /*  START1          */
	register int V8;                          /*  END1            */
	if(((V3))==Cnil){
	goto L130;}
	L6(1,(V3))                                /*  THE-START       */;
	V7= fix(VALUES(0));
	goto L128;
L130:
	V7= 0;
L128:
	L5(2,(V4),(V1))                           /*  THE-END         */;
	V8= fix(VALUES(0));
	if((V7)<=(V8)){
	goto L133;}
	L4(2,MAKE_FIXNUM(V7),MAKE_FIXNUM(V8))     /*  BAD-SEQ-LIMIT   */;
L133:
	{register int V9;                         /*  START2          */
	register int V10;                         /*  END2            */
	if(((V5))==Cnil){
	goto L138;}
	L6(1,(V5))                                /*  THE-START       */;
	V9= fix(VALUES(0));
	goto L136;
L138:
	V9= 0;
L136:
	L5(2,(V6),(V2))                           /*  THE-END         */;
	V10= fix(VALUES(0));
	if((V9)<=(V10)){
	goto L141;}
	L4(2,MAKE_FIXNUM(V9),MAKE_FIXNUM(V10))    /*  BAD-SEQ-LIMIT   */;
L141:
	if(!(((V1))==((V2)))){
	goto L145;}
	if(!((V7)>(V9))){
	goto L145;}
	{int V11;                                 /*  I               */
	int V12;                                  /*  L               */
	int V13;                                  /*  S1              */
	int V14;                                  /*  S2              */
	V11= 0;
	if(!(((V8)-(V7))<((V10)-(V9)))){
	goto L152;}
	V12= (V8)-(V7);
	goto L150;
L152:
	V12= (V10)-(V9);
L150:
	V13= (V7)+((V12)-1);
	V14= (V9)+((V12)-1);
L157:
	if(!((V11)>=(V12))){
	goto L158;}
	VALUES(0) = (V1);
	RETURN(1);
L158:
	elt_set((V1),V13,elt((V2),V14));
	V11= (V11)+1;
	V13= (V13)-1;
	V14= (V14)-1;
	goto L157;
	}
L145:
	{int V16;                                 /*  I               */
	object V17;                               /*  L               */
	int V18;                                  /*  S1              */
	int V19;                                  /*  S2              */
	V16= 0;
	if(!(((V8)-(V7))<((V10)-(V9)))){
	goto L172;}
	V17= MAKE_FIXNUM((V8)-(V7));
	goto L170;
L172:
	V17= MAKE_FIXNUM((V10)-(V9));
L170:
	V18= V7;
	V19= V9;
L177:
	if(!((V16)>=(fix((V17))))){
	goto L178;}
	VALUES(0) = (V1);
	RETURN(1);
L178:
	elt_set((V1),V18,elt((V2),V19));
	V16= (V16)+1;
	V18= (V18)+1;
	V19= (V19)+1;
	goto L177;
	}
	}
	}
	}
}
/*	function definition for REMOVE                                */
static L10(int narg, object V1, object V2, ...)
{ VT12 VLEX12 CLSR12
	cs_check;
	{int i=2;
	object V3;
	register object V4;
	register object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[14];
	parse_key(narg,args,7,L10keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	V7= keyvars[4];
	V8= keyvars[5];
	if(keyvars[13]==Cnil){
	V9= symbol_function(VV[65]);
	}else{
	V9= keyvars[6];}
	}
	{register int V10;                        /*  START           */
	register int V11;                         /*  END             */
	if(((V6))==Cnil){
	goto L190;}
	L6(1,(V6))                                /*  THE-START       */;
	V10= fix(VALUES(0));
	goto L188;
L190:
	V10= 0;
L188:
	L5(2,(V7),(V2))                           /*  THE-END         */;
	V11= fix(VALUES(0));
	if((V10)<=(V11)){
	goto L193;}
	L4(2,MAKE_FIXNUM(V10),MAKE_FIXNUM(V11))   /*  BAD-SEQ-LIMIT   */;
L193:
	{int V12;                                 /*  COUNT           */
	if(((V8))!=Cnil){
	goto L198;}
	V12= 536870911;
	goto L196;
L198:
	V12= fix((V8));
L196:
	if((V4)==Cnil){
	goto L201;}
	if((V5)==Cnil){
	goto L201;}
	LI3();
L201:
	if(((V3))!=Cnil){
	goto L203;}
	if(!(type_of((V2))==t_cons||(V2)==Cnil)){
	goto L206;}
	{register object V13;                     /*  L               */
	register object V14;                      /*  L1              */
	V13= (V2);
	V14= Cnil;
	{int V15;                                 /*  I               */
	V15= 0;
L211:
	if(!((V15)>=(V10))){
	goto L212;}
	goto L208;
L212:
	V14= CONS(car((V13)),(V14));
	V13= cdr((V13));
	V15= (V15)+1;
	goto L211;
	}
L208:
	{int V15;                                 /*  I               */
	int V16;                                  /*  J               */
	V15= V10;
	V16= 0;
L226:
	if((V15)>=(V11)){
	goto L228;}
	if((V16)>=(V12)){
	goto L228;}
	if(!(endp((V13)))){
	goto L227;}
L228:
	RETURN(Lreconc(2,(V14),(V13))             /*  NRECONC         */);
L227:
	funcall(2,(V9),car((V13)));
	if((LI2((V4),(V5),(V1),VALUES(0)))==Cnil){
	goto L236;}
	V16= (V16)+(1);
	goto L234;
L236:
	V14= CONS(car((V13)),(V14));
L234:
	V13= cdr((V13));
	V15= (V15)+1;
	goto L226;
	}
	}
L206:
	RETURN(L13(16,(V1),(V2),VV[11],(V3),VV[12],(V4),VV[13],(V5),VV[14],MAKE_FIXNUM(V10),VV[15],MAKE_FIXNUM(V11),VV[16],MAKE_FIXNUM(V12),VV[17],(V9))/*  DELETE*/);
L203:
	RETURN(L13(16,(V1),(V2),VV[11],(V3),VV[12],(V4),VV[13],(V5),VV[14],MAKE_FIXNUM(V10),VV[15],MAKE_FIXNUM(V11),VV[16],MAKE_FIXNUM(V12),VV[17],(V9))/*  DELETE*/);
	}
	}
	}
}
/*	function definition for REMOVE-IF                             */
static L11(int narg, object V1, object V2, ...)
{ VT13 VLEX13 CLSR13
	cs_check;
	{int i=2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[10];
	parse_key(narg,args,5,L11keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	if(keyvars[9]==Cnil){
	V7= symbol_function(VV[65]);
	}else{
	V7= keyvars[4];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L10(14,(V1),(V2),VV[11],(V3),VV[12],VALUES(0),VV[14],(V4),VV[15],(V5),VV[16],(V6),VV[17],(V7))/*  REMOVE*/);
	}
}
/*	function definition for REMOVE-IF-NOT                         */
static L12(int narg, object V1, object V2, ...)
{ VT14 VLEX14 CLSR14
	cs_check;
	{int i=2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[10];
	parse_key(narg,args,5,L12keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	if(keyvars[9]==Cnil){
	V7= symbol_function(VV[65]);
	}else{
	V7= keyvars[4];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L10(14,(V1),(V2),VV[11],(V3),VV[13],VALUES(0),VV[14],(V4),VV[15],(V5),VV[16],(V6),VV[17],(V7))/*  REMOVE*/);
	}
}
/*	function definition for DELETE                                */
static L13(int narg, object V1, object V2, ...)
{ VT15 VLEX15 CLSR15
	cs_check;
	{int i=2;
	object V3;
	register object V4;
	register object V5;
	object V6;
	object V7;
	object V8;
	register object V9;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[14];
	parse_key(narg,args,7,L13keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	V7= keyvars[4];
	V8= keyvars[5];
	if(keyvars[13]==Cnil){
	V9= symbol_function(VV[65]);
	}else{
	V9= keyvars[6];}
	}
	{register int V10;                        /*  L               */
	V10= length((V2));
	{register int V11;                        /*  START           */
	register int V12;                         /*  END             */
	if(((V6))==Cnil){
	goto L255;}
	L6(1,(V6))                                /*  THE-START       */;
	V11= fix(VALUES(0));
	goto L253;
L255:
	V11= 0;
L253:
	L5(2,(V7),(V2))                           /*  THE-END         */;
	V12= fix(VALUES(0));
	if((V11)<=(V12)){
	goto L258;}
	L4(2,MAKE_FIXNUM(V11),MAKE_FIXNUM(V12))   /*  BAD-SEQ-LIMIT   */;
L258:
	{register int V13;                        /*  COUNT           */
	if(((V8))!=Cnil){
	goto L263;}
	V13= 536870911;
	goto L261;
L263:
	V13= fix((V8));
L261:
	if((V4)==Cnil){
	goto L266;}
	if((V5)==Cnil){
	goto L266;}
	LI3();
L266:
	if(((V3))!=Cnil){
	goto L268;}
	if(!(type_of((V2))==t_cons||(V2)==Cnil)){
	goto L271;}
	{object V14;                              /*  L0              */
	register object V15;                      /*  L               */
	V14= CONS(Cnil,(V2));
	V15= (V14);
	{int V16;                                 /*  I               */
	V16= 0;
L278:
	if(!((V16)>=(V11))){
	goto L279;}
	goto L275;
L279:
	V15= cdr((V15));
	V16= (V16)+1;
	goto L278;
	}
L275:
	{int V16;                                 /*  I               */
	int V17;                                  /*  J               */
	V16= V11;
	V17= 0;
L291:
	if((V16)>=(V12)){
	goto L293;}
	if((V17)>=(V13)){
	goto L293;}
	if(!(endp(cdr((V15))))){
	goto L292;}
L293:
	VALUES(0) = cdr((V14));
	RETURN(1);
L292:
	funcall(2,(V9),cadr((V15)));
	if((LI2((V4),(V5),(V1),VALUES(0)))==Cnil){
	goto L301;}
	V17= (V17)+(1);
	if(type_of((V15))!=t_cons)FEwrong_type_argument(Scons,(V15));
	CDR((V15)) = cddr((V15));
	goto L299;
L301:
	V15= cdr((V15));
L299:
	V16= (V16)+1;
	goto L291;
	}
	}
L271:
	{int V19;                                 /*  N               */
	L19(16,(V1),(V2),VV[11],(V3),VV[12],(V4),VV[13],(V5),VV[14],MAKE_FIXNUM(V11),VV[15],MAKE_FIXNUM(V12),VV[16],MAKE_FIXNUM(V13),VV[17],(V9))/*  INTERNAL-COUNT*/;
	V19= fix(VALUES(0));
	if(!((V19)<(V13))){
	goto L311;}
	V13= V19;
L311:
	{object V20;                              /*  NEWSEQ          */
	register int V21;                         /*  I               */
	int V22;                                  /*  J               */
	int V23;                                  /*  K               */
	{object V24= LI1((V2));
	(*LK0)(2,V24,MAKE_FIXNUM((V10)-(V13)))    /*  MAKE-SEQUENCE   */;
	V20= VALUES(0);}
	V21= 0;
	V22= 0;
	V23= 0;
L320:
	if(!((V21)>=(V10))){
	goto L321;}
	VALUES(0) = (V20);
	RETURN(1);
L321:
	if(!((V11)<=(V21))){
	goto L326;}
	if(!((V21)<(V12))){
	goto L326;}
	if(!((V23)<(V13))){
	goto L326;}
	funcall(2,(V9),elt((V2),V21));
	if((LI2((V4),(V5),(V1),VALUES(0)))==Cnil){
	goto L326;}
	V23= (V23)+1;
	goto L324;
L326:
	elt_set((V20),V22,elt((V2),V21));
	V22= (V22)+(1);
L324:
	V21= (V21)+1;
	goto L320;
	}
	}
L268:
	{int V25;                                 /*  N               */
	L19(16,(V1),(V2),VV[11],(V3),VV[12],(V4),VV[13],(V5),VV[14],MAKE_FIXNUM(V11),VV[15],MAKE_FIXNUM(V12),VV[16],MAKE_FIXNUM(V13),VV[17],(V9))/*  INTERNAL-COUNT*/;
	V25= fix(VALUES(0));
	if(!((V25)<(V13))){
	goto L342;}
	V13= V25;
L342:
	{object V26;                              /*  NEWSEQ          */
	register int V27;                         /*  I               */
	int V28;                                  /*  J               */
	int V29;                                  /*  K               */
	{object V30= LI1((V2));
	(*LK0)(2,V30,MAKE_FIXNUM((V10)-(V13)))    /*  MAKE-SEQUENCE   */;
	V26= VALUES(0);}
	V27= (V10)-1;
	V28= ((V12)-1)-(V25);
	V29= 0;
L351:
	if(!((V27)<(0))){
	goto L352;}
	VALUES(0) = (V26);
	RETURN(1);
L352:
	if(!((V11)<=(V27))){
	goto L357;}
	if(!((V27)<(V12))){
	goto L357;}
	if(!((V29)<(V13))){
	goto L357;}
	funcall(2,(V9),elt((V2),V27));
	if((LI2((V4),(V5),(V1),VALUES(0)))==Cnil){
	goto L357;}
	V29= (V29)+1;
	goto L355;
L357:
	elt_set((V26),V28,elt((V2),V27));
	V28= (V28)-(1);
L355:
	V27= (V27)-1;
	goto L351;
	}
	}
	}
	}
	}
	}
}
/*	function definition for DELETE-IF                             */
static L14(int narg, object V1, object V2, ...)
{ VT16 VLEX16 CLSR16
	cs_check;
	{int i=2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[10];
	parse_key(narg,args,5,L14keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	if(keyvars[9]==Cnil){
	V7= symbol_function(VV[65]);
	}else{
	V7= keyvars[4];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L13(14,(V1),(V2),VV[11],(V3),VV[12],VALUES(0),VV[14],(V4),VV[15],(V5),VV[16],(V6),VV[17],(V7))/*  DELETE*/);
	}
}
/*	function definition for DELETE-IF-NOT                         */
static L15(int narg, object V1, object V2, ...)
{ VT17 VLEX17 CLSR17
	cs_check;
	{int i=2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[10];
	parse_key(narg,args,5,L15keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	if(keyvars[9]==Cnil){
	V7= symbol_function(VV[65]);
	}else{
	V7= keyvars[4];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L13(14,(V1),(V2),VV[11],(V3),VV[13],VALUES(0),VV[14],(V4),VV[15],(V5),VV[16],(V6),VV[17],(V7))/*  DELETE*/);
	}
}
/*	function definition for COUNT                                 */
static L16(int narg, object V1, object V2, ...)
{ VT18 VLEX18 CLSR18
	cs_check;
	{int i=2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[12];
	parse_key(narg,args,6,L16keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	V7= keyvars[4];
	if(keyvars[11]==Cnil){
	V8= symbol_function(VV[65]);
	}else{
	V8= keyvars[5];}
	}
	{register int V9;                         /*  START           */
	register int V10;                         /*  END             */
	if(((V6))==Cnil){
	goto L379;}
	L6(1,(V6))                                /*  THE-START       */;
	V9= fix(VALUES(0));
	goto L377;
L379:
	V9= 0;
L377:
	L5(2,(V7),(V2))                           /*  THE-END         */;
	V10= fix(VALUES(0));
	if((V9)<=(V10)){
	goto L382;}
	L4(2,MAKE_FIXNUM(V9),MAKE_FIXNUM(V10))    /*  BAD-SEQ-LIMIT   */;
L382:
	if((V4)==Cnil){
	goto L385;}
	if((V5)==Cnil){
	goto L385;}
	LI3();
L385:
	if(((V3))!=Cnil){
	goto L387;}
	{register int V11;                        /*  I               */
	int V12;                                  /*  K               */
	V11= V9;
	V12= 0;
L392:
	if(!((V11)>=(V10))){
	goto L393;}
	VALUES(0) = MAKE_FIXNUM(V12);
	RETURN(1);
L393:
	funcall(2,(V8),elt((V2),V11));
	if((LI2((V4),(V5),(V1),VALUES(0)))==Cnil){
	goto L396;}
	V12= (V12)+1;
L396:
	V11= (V11)+1;
	goto L392;
	}
L387:
	{register int V14;                        /*  I               */
	int V15;                                  /*  K               */
	V14= (V10)-1;
	V15= 0;
L407:
	if(!((V14)<(V9))){
	goto L408;}
	VALUES(0) = MAKE_FIXNUM(V15);
	RETURN(1);
L408:
	funcall(2,(V8),elt((V2),V14));
	if((LI2((V4),(V5),(V1),VALUES(0)))==Cnil){
	goto L411;}
	V15= (V15)+1;
L411:
	V14= (V14)-1;
	goto L407;
	}
	}
	}
}
/*	function definition for COUNT-IF                              */
static L17(int narg, object V1, object V2, ...)
{ VT19 VLEX19 CLSR19
	cs_check;
	{int i=2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[8];
	parse_key(narg,args,4,L17keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	if(keyvars[7]==Cnil){
	V6= symbol_function(VV[65]);
	}else{
	V6= keyvars[3];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L16(12,(V1),(V2),VV[11],(V3),VV[12],VALUES(0),VV[14],(V4),VV[15],(V5),VV[17],(V6))/*  COUNT*/);
	}
}
/*	function definition for COUNT-IF-NOT                          */
static L18(int narg, object V1, object V2, ...)
{ VT20 VLEX20 CLSR20
	cs_check;
	{int i=2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[8];
	parse_key(narg,args,4,L18keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	if(keyvars[7]==Cnil){
	V6= symbol_function(VV[65]);
	}else{
	V6= keyvars[3];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L16(12,(V1),(V2),VV[11],(V3),VV[13],VALUES(0),VV[14],(V4),VV[15],(V5),VV[17],(V6))/*  COUNT*/);
	}
}
/*	function definition for INTERNAL-COUNT                        */
static L19(int narg, object V1, object V2, ...)
{ VT21 VLEX21 CLSR21
	cs_check;
	{int i=2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[14];
	parse_key(narg,args,7,L19keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	V7= keyvars[4];
	V8= keyvars[5];
	if(keyvars[13]==Cnil){
	V9= symbol_function(VV[65]);
	}else{
	V9= keyvars[6];}
	}
	{register int V10;                        /*  START           */
	register int V11;                         /*  END             */
	if(((V6))==Cnil){
	goto L426;}
	L6(1,(V6))                                /*  THE-START       */;
	V10= fix(VALUES(0));
	goto L424;
L426:
	V10= 0;
L424:
	L5(2,(V7),(V2))                           /*  THE-END         */;
	V11= fix(VALUES(0));
	if((V10)<=(V11)){
	goto L429;}
	L4(2,MAKE_FIXNUM(V10),MAKE_FIXNUM(V11))   /*  BAD-SEQ-LIMIT   */;
L429:
	{int V12;                                 /*  COUNT           */
	if(((V8))!=Cnil){
	goto L434;}
	V12= 536870911;
	goto L432;
L434:
	V12= fix((V8));
L432:
	if((V4)==Cnil){
	goto L437;}
	if((V5)==Cnil){
	goto L437;}
	LI3();
L437:
	if(((V3))!=Cnil){
	goto L439;}
	{register int V13;                        /*  I               */
	register int V14;                         /*  K               */
	V13= V10;
	V14= 0;
L444:
	if(!((V13)>=(V11))){
	goto L445;}
	VALUES(0) = MAKE_FIXNUM(V14);
	RETURN(1);
L445:
	if(!((V14)<(V12))){
	goto L448;}
	funcall(2,(V9),elt((V2),V13));
	if((LI2((V4),(V5),(V1),VALUES(0)))==Cnil){
	goto L448;}
	V14= (V14)+1;
L448:
	V13= (V13)+1;
	goto L444;
	}
L439:
	{register int V16;                        /*  I               */
	register int V17;                         /*  K               */
	V16= (V11)-1;
	V17= 0;
L461:
	if(!((V16)<(V10))){
	goto L462;}
	VALUES(0) = MAKE_FIXNUM(V17);
	RETURN(1);
L462:
	if(!((V17)<(V12))){
	goto L465;}
	funcall(2,(V9),elt((V2),V16));
	if((LI2((V4),(V5),(V1),VALUES(0)))==Cnil){
	goto L465;}
	V17= (V17)+1;
L465:
	V16= (V16)-1;
	goto L461;
	}
	}
	}
	}
}
/*	function definition for SUBSTITUTE                            */
static L20(int narg, object V1, object V2, object V3, ...)
{ VT22 VLEX22 CLSR22
	cs_check;
	{int i=3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	object V10;
	va_list args; va_start(args, V3);
	if(narg<3) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[14];
	parse_key(narg,args,7,L20keys,keyvars,OBJNULL,FALSE);
	V4= keyvars[0];
	V5= keyvars[1];
	V6= keyvars[2];
	V7= keyvars[3];
	V8= keyvars[4];
	V9= keyvars[5];
	if(keyvars[13]==Cnil){
	V10= symbol_function(VV[65]);
	}else{
	V10= keyvars[6];}
	}
	{register int V11;                        /*  L               */
	V11= length((V3));
	{register int V12;                        /*  START           */
	register int V13;                         /*  END             */
	if(((V7))==Cnil){
	goto L479;}
	L6(1,(V7))                                /*  THE-START       */;
	V12= fix(VALUES(0));
	goto L477;
L479:
	V12= 0;
L477:
	L5(2,(V8),(V3))                           /*  THE-END         */;
	V13= fix(VALUES(0));
	if((V12)<=(V13)){
	goto L482;}
	L4(2,MAKE_FIXNUM(V12),MAKE_FIXNUM(V13))   /*  BAD-SEQ-LIMIT   */;
L482:
	{int V14;                                 /*  COUNT           */
	if(((V9))!=Cnil){
	goto L487;}
	V14= 536870911;
	goto L485;
L487:
	V14= fix((V9));
L485:
	if((V5)==Cnil){
	goto L490;}
	if((V6)==Cnil){
	goto L490;}
	LI3();
L490:
	if(((V4))!=Cnil){
	goto L492;}
	{object V15;                              /*  NEWSEQ          */
	register int V16;                         /*  I               */
	int V17;                                  /*  K               */
	{object V18= LI1((V3));
	(*LK0)(2,V18,MAKE_FIXNUM(V11))            /*  MAKE-SEQUENCE   */;
	V15= VALUES(0);}
	V16= 0;
	V17= 0;
L498:
	if(!((V16)>=(V11))){
	goto L499;}
	VALUES(0) = (V15);
	RETURN(1);
L499:
	if(!((V12)<=(V16))){
	goto L504;}
	if(!((V16)<(V13))){
	goto L504;}
	if(!((V17)<(V14))){
	goto L504;}
	funcall(2,(V10),elt((V3),V16));
	if((LI2((V5),(V6),(V2),VALUES(0)))==Cnil){
	goto L504;}
	elt_set((V15),V16,(V1));
	V17= (V17)+1;
	goto L502;
L504:
	elt_set((V15),V16,elt((V3),V16));
L502:
	V16= (V16)+1;
	goto L498;
	}
L492:
	{object V19;                              /*  NEWSEQ          */
	register int V20;                         /*  I               */
	int V21;                                  /*  K               */
	{object V22= LI1((V3));
	(*LK0)(2,V22,MAKE_FIXNUM(V11))            /*  MAKE-SEQUENCE   */;
	V19= VALUES(0);}
	V20= (V11)-1;
	V21= 0;
L522:
	if(!((V20)<(0))){
	goto L523;}
	VALUES(0) = (V19);
	RETURN(1);
L523:
	if(!((V12)<=(V20))){
	goto L528;}
	if(!((V20)<(V13))){
	goto L528;}
	if(!((V21)<(V14))){
	goto L528;}
	funcall(2,(V10),elt((V3),V20));
	if((LI2((V5),(V6),(V2),VALUES(0)))==Cnil){
	goto L528;}
	elt_set((V19),V20,(V1));
	V21= (V21)+1;
	goto L526;
L528:
	elt_set((V19),V20,elt((V3),V20));
L526:
	V20= (V20)-1;
	goto L522;
	}
	}
	}
	}
	}
}
/*	function definition for SUBSTITUTE-IF                         */
static L21(int narg, object V1, object V2, object V3, ...)
{ VT23 VLEX23 CLSR23
	cs_check;
	{int i=3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	va_list args; va_start(args, V3);
	if(narg<3) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[10];
	parse_key(narg,args,5,L21keys,keyvars,OBJNULL,FALSE);
	V4= keyvars[0];
	V5= keyvars[1];
	V6= keyvars[2];
	V7= keyvars[3];
	if(keyvars[9]==Cnil){
	V8= symbol_function(VV[65]);
	}else{
	V8= keyvars[4];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L20(15,(V1),(V2),(V3),VV[11],(V4),VV[12],VALUES(0),VV[14],(V5),VV[15],(V6),VV[16],(V7),VV[17],(V8))/*  SUBSTITUTE*/);
	}
}
/*	function definition for SUBSTITUTE-IF-NOT                     */
static L22(int narg, object V1, object V2, object V3, ...)
{ VT24 VLEX24 CLSR24
	cs_check;
	{int i=3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	va_list args; va_start(args, V3);
	if(narg<3) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[10];
	parse_key(narg,args,5,L22keys,keyvars,OBJNULL,FALSE);
	V4= keyvars[0];
	V5= keyvars[1];
	V6= keyvars[2];
	V7= keyvars[3];
	if(keyvars[9]==Cnil){
	V8= symbol_function(VV[65]);
	}else{
	V8= keyvars[4];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L20(15,(V1),(V2),(V3),VV[11],(V4),VV[13],VALUES(0),VV[14],(V5),VV[15],(V6),VV[16],(V7),VV[17],(V8))/*  SUBSTITUTE*/);
	}
}
/*	function definition for NSUBSTITUTE                           */
static L23(int narg, object V1, object V2, object V3, ...)
{ VT25 VLEX25 CLSR25
	cs_check;
	{int i=3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	object V10;
	va_list args; va_start(args, V3);
	if(narg<3) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[14];
	parse_key(narg,args,7,L23keys,keyvars,OBJNULL,FALSE);
	V4= keyvars[0];
	V5= keyvars[1];
	V6= keyvars[2];
	V7= keyvars[3];
	V8= keyvars[4];
	V9= keyvars[5];
	if(keyvars[13]==Cnil){
	V10= symbol_function(VV[65]);
	}else{
	V10= keyvars[6];}
	}
	{register int V11;                        /*  START           */
	register int V12;                         /*  END             */
	if(((V7))==Cnil){
	goto L549;}
	L6(1,(V7))                                /*  THE-START       */;
	V11= fix(VALUES(0));
	goto L547;
L549:
	V11= 0;
L547:
	L5(2,(V8),(V3))                           /*  THE-END         */;
	V12= fix(VALUES(0));
	if((V11)<=(V12)){
	goto L552;}
	L4(2,MAKE_FIXNUM(V11),MAKE_FIXNUM(V12))   /*  BAD-SEQ-LIMIT   */;
L552:
	{int V13;                                 /*  COUNT           */
	if(((V9))!=Cnil){
	goto L557;}
	V13= 536870911;
	goto L555;
L557:
	V13= fix((V9));
L555:
	if((V5)==Cnil){
	goto L560;}
	if((V6)==Cnil){
	goto L560;}
	LI3();
L560:
	if(((V4))!=Cnil){
	goto L562;}
	{register int V14;                        /*  I               */
	int V15;                                  /*  K               */
	V14= V11;
	V15= 0;
L567:
	if(!((V14)>=(V12))){
	goto L568;}
	VALUES(0) = (V3);
	RETURN(1);
L568:
	if(!((V15)<(V13))){
	goto L571;}
	funcall(2,(V10),elt((V3),V14));
	if((LI2((V5),(V6),(V2),VALUES(0)))==Cnil){
	goto L571;}
	elt_set((V3),V14,(V1));
	V15= (V15)+1;
L571:
	V14= (V14)+1;
	goto L567;
	}
L562:
	{register int V17;                        /*  I               */
	int V18;                                  /*  K               */
	V17= (V12)-1;
	V18= 0;
L585:
	if(!((V17)<(V11))){
	goto L586;}
	VALUES(0) = (V3);
	RETURN(1);
L586:
	if(!((V18)<(V13))){
	goto L589;}
	funcall(2,(V10),elt((V3),V17));
	if((LI2((V5),(V6),(V2),VALUES(0)))==Cnil){
	goto L589;}
	elt_set((V3),V17,(V1));
	V18= (V18)+1;
L589:
	V17= (V17)-1;
	goto L585;
	}
	}
	}
	}
}
/*	function definition for NSUBSTITUTE-IF                        */
static L24(int narg, object V1, object V2, object V3, ...)
{ VT26 VLEX26 CLSR26
	cs_check;
	{int i=3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	va_list args; va_start(args, V3);
	if(narg<3) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[10];
	parse_key(narg,args,5,L24keys,keyvars,OBJNULL,FALSE);
	V4= keyvars[0];
	V5= keyvars[1];
	V6= keyvars[2];
	V7= keyvars[3];
	if(keyvars[9]==Cnil){
	V8= symbol_function(VV[65]);
	}else{
	V8= keyvars[4];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L23(15,(V1),(V2),(V3),VV[11],(V4),VV[12],VALUES(0),VV[14],(V5),VV[15],(V6),VV[16],(V7),VV[17],(V8))/*  NSUBSTITUTE*/);
	}
}
/*	function definition for NSUBSTITUTE-IF-NOT                    */
static L25(int narg, object V1, object V2, object V3, ...)
{ VT27 VLEX27 CLSR27
	cs_check;
	{int i=3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	va_list args; va_start(args, V3);
	if(narg<3) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[10];
	parse_key(narg,args,5,L25keys,keyvars,OBJNULL,FALSE);
	V4= keyvars[0];
	V5= keyvars[1];
	V6= keyvars[2];
	V7= keyvars[3];
	if(keyvars[9]==Cnil){
	V8= symbol_function(VV[65]);
	}else{
	V8= keyvars[4];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L23(15,(V1),(V2),(V3),VV[11],(V4),VV[13],VALUES(0),VV[14],(V5),VV[15],(V6),VV[16],(V7),VV[17],(V8))/*  NSUBSTITUTE*/);
	}
}
/*	function definition for FIND                                  */
static L26(int narg, object V1, object V2, ...)
{ VT28 VLEX28 CLSR28
	cs_check;
	{int i=2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[12];
	parse_key(narg,args,6,L26keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	V7= keyvars[4];
	if(keyvars[11]==Cnil){
	V8= symbol_function(VV[65]);
	}else{
	V8= keyvars[5];}
	}
	{register int V9;                         /*  START           */
	register int V10;                         /*  END             */
	if(((V6))==Cnil){
	goto L607;}
	L6(1,(V6))                                /*  THE-START       */;
	V9= fix(VALUES(0));
	goto L605;
L607:
	V9= 0;
L605:
	L5(2,(V7),(V2))                           /*  THE-END         */;
	V10= fix(VALUES(0));
	if((V9)<=(V10)){
	goto L610;}
	L4(2,MAKE_FIXNUM(V9),MAKE_FIXNUM(V10))    /*  BAD-SEQ-LIMIT   */;
L610:
	if((V4)==Cnil){
	goto L613;}
	if((V5)==Cnil){
	goto L613;}
	LI3();
L613:
	if(((V3))!=Cnil){
	goto L615;}
	{register int V11;                        /*  I               */
	V11= V9;
L619:
	if(!((V11)>=(V10))){
	goto L620;}
	VALUES(0) = Cnil;
	RETURN(1);
L620:
	funcall(2,(V8),elt((V2),V11));
	if((LI2((V4),(V5),(V1),VALUES(0)))==Cnil){
	goto L623;}
	VALUES(0) = elt((V2),V11);
	RETURN(1);
L623:
	V11= (V11)+1;
	goto L619;
	}
L615:
	{register int V14;                        /*  I               */
	V14= (V10)-1;
L632:
	if(!((V14)<(V9))){
	goto L633;}
	VALUES(0) = Cnil;
	RETURN(1);
L633:
	funcall(2,(V8),elt((V2),V14));
	if((LI2((V4),(V5),(V1),VALUES(0)))==Cnil){
	goto L636;}
	VALUES(0) = elt((V2),V14);
	RETURN(1);
L636:
	V14= (V14)-1;
	goto L632;
	}
	}
	}
}
/*	function definition for FIND-IF                               */
static L27(int narg, object V1, object V2, ...)
{ VT29 VLEX29 CLSR29
	cs_check;
	{int i=2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[8];
	parse_key(narg,args,4,L27keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	if(keyvars[7]==Cnil){
	V6= symbol_function(VV[65]);
	}else{
	V6= keyvars[3];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L26(12,(V1),(V2),VV[11],(V3),VV[12],VALUES(0),VV[14],(V4),VV[15],(V5),VV[17],(V6))/*  FIND*/);
	}
}
/*	function definition for FIND-IF-NOT                           */
static L28(int narg, object V1, object V2, ...)
{ VT30 VLEX30 CLSR30
	cs_check;
	{int i=2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[8];
	parse_key(narg,args,4,L28keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	if(keyvars[7]==Cnil){
	V6= symbol_function(VV[65]);
	}else{
	V6= keyvars[3];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L26(12,(V1),(V2),VV[11],(V3),VV[13],VALUES(0),VV[14],(V4),VV[15],(V5),VV[17],(V6))/*  FIND*/);
	}
}
/*	function definition for POSITION                              */
static L29(int narg, object V1, object V2, ...)
{ VT31 VLEX31 CLSR31
	cs_check;
	{int i=2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[12];
	parse_key(narg,args,6,L29keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	V7= keyvars[4];
	if(keyvars[11]==Cnil){
	V8= symbol_function(VV[65]);
	}else{
	V8= keyvars[5];}
	}
	{register int V9;                         /*  START           */
	register int V10;                         /*  END             */
	if(((V6))==Cnil){
	goto L650;}
	L6(1,(V6))                                /*  THE-START       */;
	V9= fix(VALUES(0));
	goto L648;
L650:
	V9= 0;
L648:
	L5(2,(V7),(V2))                           /*  THE-END         */;
	V10= fix(VALUES(0));
	if((V9)<=(V10)){
	goto L653;}
	L4(2,MAKE_FIXNUM(V9),MAKE_FIXNUM(V10))    /*  BAD-SEQ-LIMIT   */;
L653:
	if((V4)==Cnil){
	goto L656;}
	if((V5)==Cnil){
	goto L656;}
	LI3();
L656:
	if(((V3))!=Cnil){
	goto L658;}
	{register int V11;                        /*  I               */
	V11= V9;
L662:
	if(!((V11)>=(V10))){
	goto L663;}
	VALUES(0) = Cnil;
	RETURN(1);
L663:
	funcall(2,(V8),elt((V2),V11));
	if((LI2((V4),(V5),(V1),VALUES(0)))==Cnil){
	goto L666;}
	VALUES(0) = MAKE_FIXNUM(V11);
	RETURN(1);
L666:
	V11= (V11)+1;
	goto L662;
	}
L658:
	{register int V14;                        /*  I               */
	V14= (V10)-1;
L675:
	if(!((V14)<(V9))){
	goto L676;}
	VALUES(0) = Cnil;
	RETURN(1);
L676:
	funcall(2,(V8),elt((V2),V14));
	if((LI2((V4),(V5),(V1),VALUES(0)))==Cnil){
	goto L679;}
	VALUES(0) = MAKE_FIXNUM(V14);
	RETURN(1);
L679:
	V14= (V14)-1;
	goto L675;
	}
	}
	}
}
/*	function definition for POSITION-IF                           */
static L30(int narg, object V1, object V2, ...)
{ VT32 VLEX32 CLSR32
	cs_check;
	{int i=2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[8];
	parse_key(narg,args,4,L30keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	if(keyvars[7]==Cnil){
	V6= symbol_function(VV[65]);
	}else{
	V6= keyvars[3];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L29(12,(V1),(V2),VV[11],(V3),VV[12],VALUES(0),VV[14],(V4),VV[15],(V5),VV[17],(V6))/*  POSITION*/);
	}
}
/*	function definition for POSITION-IF-NOT                       */
static L31(int narg, object V1, object V2, ...)
{ VT33 VLEX33 CLSR33
	cs_check;
	{int i=2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[8];
	parse_key(narg,args,4,L31keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	if(keyvars[7]==Cnil){
	V6= symbol_function(VV[65]);
	}else{
	V6= keyvars[3];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L29(12,(V1),(V2),VV[11],(V3),VV[13],VALUES(0),VV[14],(V4),VV[15],(V5),VV[17],(V6))/*  POSITION*/);
	}
}
/*	function definition for REMOVE-DUPLICATES                     */
static L32(int narg, object V1, ...)
{ VT34 VLEX34 CLSR34
	cs_check;
	{int i=1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	va_list args; va_start(args, V1);
	if(narg<1) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[12];
	parse_key(narg,args,6,L32keys,keyvars,OBJNULL,FALSE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	if(keyvars[11]==Cnil){
	V7= symbol_function(VV[65]);
	}else{
	V7= keyvars[5];}
	}
	if((V3)==Cnil){
	goto L691;}
	if((V4)==Cnil){
	goto L691;}
	LI3();
L691:
	if(!(type_of((V1))==t_cons||(V1)==Cnil)){
	goto L692;}
	if(((V2))!=Cnil){
	goto L692;}
	if(((V5))!=Cnil){
	goto L692;}
	if(((V6))!=Cnil){
	goto L692;}
	if(!(endp((V1)))){
	goto L701;}
	VALUES(0) = Cnil;
	RETURN(1);
L701:
	{register object V8;                      /*  L               */
	object V9;                                /*  L1              */
	V8= (V1);
	V9= Cnil;
L705:
	if(!(endp(cdr((V8))))){
	goto L706;}
	RETURN(Lreconc(2,(V9),(V8))               /*  NRECONC         */);
L706:
	(*LK1)(8,car((V8)),cdr((V8)),VV[12],(V3),VV[13],(V4),VV[17],(V7))/*  MEMBER1*/;
	if(VALUES(0)!=Cnil){
	goto L709;}
	V9= CONS(car((V8)),(V9));
L709:
	V8= cdr((V8));
	goto L705;
	}
L692:
	RETURN(L33(13,(V1),VV[11],(V2),VV[12],(V3),VV[13],(V4),VV[14],(V5),VV[15],(V6),VV[17],(V7))/*  DELETE-DUPLICATES*/);
	}
}
/*	function definition for DELETE-DUPLICATES                     */
static L33(int narg, object V1, ...)
{ VT35 VLEX35 CLSR35
	cs_check;
	{int i=1;
	object V2;
	register object V3;
	register object V4;
	object V5;
	object V6;
	register object V7;
	va_list args; va_start(args, V1);
	if(narg<1) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[12];
	parse_key(narg,args,6,L33keys,keyvars,OBJNULL,FALSE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	if(keyvars[11]==Cnil){
	V7= symbol_function(VV[65]);
	}else{
	V7= keyvars[5];}
	}
	{register int V8;                         /*  L               */
	V8= length((V1));
	if((V3)==Cnil){
	goto L718;}
	if((V4)==Cnil){
	goto L718;}
	LI3();
L718:
	if(!(type_of((V1))==t_cons||(V1)==Cnil)){
	goto L719;}
	if(((V2))!=Cnil){
	goto L719;}
	if(((V5))!=Cnil){
	goto L719;}
	if(((V6))!=Cnil){
	goto L719;}
	if(!(endp((V1)))){
	goto L728;}
	VALUES(0) = Cnil;
	RETURN(1);
L728:
	{register object V9;                      /*  L               */
	V9= (V1);
L732:
	if(!(endp(cdr((V9))))){
	goto L733;}
	VALUES(0) = (V1);
	RETURN(1);
L733:
	(*LK1)(8,car((V9)),cdr((V9)),VV[12],(V3),VV[13],(V4),VV[17],(V7))/*  MEMBER1*/;
	if(VALUES(0)==Cnil){
	goto L738;}
	if(type_of((V9))!=t_cons)FEwrong_type_argument(Scons,(V9));
	CAR((V9)) = cadr((V9));
	if(type_of((V9))!=t_cons)FEwrong_type_argument(Scons,(V9));
	CDR((V9)) = cddr((V9));
	goto L736;
L738:
	V9= cdr((V9));
L736:
	goto L732;
	}
L719:
	{register int V9;                         /*  START           */
	register int V10;                         /*  END             */
	if(((V5))==Cnil){
	goto L746;}
	L6(1,(V5))                                /*  THE-START       */;
	V9= fix(VALUES(0));
	goto L744;
L746:
	V9= 0;
L744:
	L5(2,(V6),(V1))                           /*  THE-END         */;
	V10= fix(VALUES(0));
	if((V9)<=(V10)){
	goto L749;}
	L4(2,MAKE_FIXNUM(V9),MAKE_FIXNUM(V10))    /*  BAD-SEQ-LIMIT   */;
L749:
	if(((V2))!=Cnil){
	goto L753;}
	{int V11;                                 /*  N               */
	register int V12;                         /*  I               */
	V11= 0;
	V12= V9;
L758:
	if(!((V12)>=(V10))){
	goto L759;}
	{object V14;                              /*  NEWSEQ          */
	register int V15;                         /*  I               */
	int V16;                                  /*  J               */
	{object V17= LI1((V1));
	(*LK0)(2,V17,MAKE_FIXNUM((V8)-(V11)))     /*  MAKE-SEQUENCE   */;
	V14= VALUES(0);}
	V15= 0;
	V16= 0;
L766:
	if(!((V15)>=(V8))){
	goto L767;}
	VALUES(0) = (V14);
	RETURN(1);
L767:
	{object V18;
	if((V9)<=(V15)){
	goto L772;}
	V18= Cnil;
	goto L771;
L772:
	if((V15)<(V10)){
	goto L774;}
	V18= Cnil;
	goto L771;
L774:
	funcall(2,(V7),elt((V1),V15));
	T0= VALUES(0);
	L29(12,T0,(V1),VV[12],(V3),VV[13],(V4),VV[14],MAKE_FIXNUM((V15)+1),VV[15],MAKE_FIXNUM(V10),VV[17],(V7))/*  POSITION*/;
	V18= VALUES(0);
L771:
	if(((V18))==Cnil){
	goto L778;}
	goto L770;
L778:
	elt_set((V14),V16,elt((V1),V15));
	V16= (V16)+(1);
	}
L770:
	V15= (V15)+1;
	goto L766;
	}
L759:
	funcall(2,(V7),elt((V1),V12));
	T0= VALUES(0);
	L29(12,T0,(V1),VV[12],(V3),VV[13],(V4),VV[14],MAKE_FIXNUM((V12)+1),VV[15],MAKE_FIXNUM(V10),VV[17],(V7))/*  POSITION*/;
	if(VALUES(0)==Cnil){
	goto L785;}
	V11= (V11)+(1);
L785:
	V12= (V12)+1;
	goto L758;
	}
L753:
	{int V19;                                 /*  N               */
	register int V20;                         /*  I               */
	V19= 0;
	V20= (V10)-1;
L796:
	if(!((V20)<(V9))){
	goto L797;}
	{object V22;                              /*  NEWSEQ          */
	register int V23;                         /*  I               */
	int V24;                                  /*  J               */
	{object V25= LI1((V1));
	(*LK0)(2,V25,MAKE_FIXNUM((V8)-(V19)))     /*  MAKE-SEQUENCE   */;
	V22= VALUES(0);}
	V23= (V8)-1;
	V24= ((V8)-1)-(V19);
L804:
	if(!((V23)<(0))){
	goto L805;}
	VALUES(0) = (V22);
	RETURN(1);
L805:
	{object V26;
	if((V9)<=(V23)){
	goto L810;}
	V26= Cnil;
	goto L809;
L810:
	if((V23)<(V10)){
	goto L812;}
	V26= Cnil;
	goto L809;
L812:
	funcall(2,(V7),elt((V1),V23));
	L29(14,VALUES(0),(V1),VV[11],Ct,VV[12],(V3),VV[13],(V4),VV[14],MAKE_FIXNUM(V9),VV[15],MAKE_FIXNUM(V23),VV[17],(V7))/*  POSITION*/;
	V26= VALUES(0);
L809:
	if(((V26))==Cnil){
	goto L816;}
	goto L808;
L816:
	elt_set((V22),V24,elt((V1),V23));
	V24= (V24)-(1);
	}
L808:
	V23= (V23)-1;
	goto L804;
	}
L797:
	funcall(2,(V7),elt((V1),V20));
	L29(14,VALUES(0),(V1),VV[11],Ct,VV[12],(V3),VV[13],(V4),VV[14],MAKE_FIXNUM(V9),VV[15],MAKE_FIXNUM(V20),VV[17],(V7))/*  POSITION*/;
	if(VALUES(0)==Cnil){
	goto L823;}
	V19= (V19)+(1);
L823:
	V20= (V20)-1;
	goto L796;
	}
	}
	}
	}
}
/*	function definition for MISMATCH                              */
static L34(int narg, object V1, object V2, ...)
{ VT36 VLEX36 CLSR36
	cs_check;
	{int i=2;
	object V3;
	object V4;
	object V5;
	register object V6;
	object V7;
	object V8;
	object V9;
	object V10;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[16];
	parse_key(narg,args,8,L34keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	if(keyvars[11]==Cnil){
	V6= symbol_function(VV[65]);
	}else{
	V6= keyvars[3];}
	V7= keyvars[4];
	V8= keyvars[5];
	V9= keyvars[6];
	V10= keyvars[7];
	}
	if((V4)==Cnil){
	goto L832;}
	if((V5)==Cnil){
	goto L832;}
	LI3();
L832:
	{register int V11;                        /*  START1          */
	register int V12;                         /*  END1            */
	if(((V7))==Cnil){
	goto L835;}
	L6(1,(V7))                                /*  THE-START       */;
	V11= fix(VALUES(0));
	goto L833;
L835:
	V11= 0;
L833:
	L5(2,(V9),(V1))                           /*  THE-END         */;
	V12= fix(VALUES(0));
	if((V11)<=(V12)){
	goto L838;}
	L4(2,MAKE_FIXNUM(V11),MAKE_FIXNUM(V12))   /*  BAD-SEQ-LIMIT   */;
L838:
	{register int V13;                        /*  START2          */
	register int V14;                         /*  END2            */
	if(((V8))==Cnil){
	goto L843;}
	L6(1,(V8))                                /*  THE-START       */;
	V13= fix(VALUES(0));
	goto L841;
L843:
	V13= 0;
L841:
	L5(2,(V10),(V2))                          /*  THE-END         */;
	V14= fix(VALUES(0));
	if((V13)<=(V14)){
	goto L846;}
	L4(2,MAKE_FIXNUM(V13),MAKE_FIXNUM(V14))   /*  BAD-SEQ-LIMIT   */;
L846:
	if(((V3))!=Cnil){
	goto L850;}
	{register int V15;                        /*  I1              */
	register int V16;                         /*  I2              */
	V15= V11;
	V16= V13;
L855:
	if((V15)>=(V12)){
	goto L857;}
	if(!((V16)>=(V14))){
	goto L856;}
L857:
	if(!((V15)>=(V12))){
	goto L862;}
	if(!((V16)>=(V14))){
	goto L862;}
	VALUES(0) = Cnil;
	RETURN(1);
L862:
	VALUES(0) = MAKE_FIXNUM(V15);
	RETURN(1);
L856:
	funcall(2,(V6),elt((V1),V15));
	T0= VALUES(0);
	funcall(2,(V6),elt((V2),V16));
	if((LI2((V4),(V5),T0,VALUES(0)))!=Cnil){
	goto L866;}
	VALUES(0) = MAKE_FIXNUM(V15);
	RETURN(1);
L866:
	V15= (V15)+1;
	V16= (V16)+1;
	goto L855;
	}
L850:
	{register int V19;                        /*  I1              */
	register int V20;                         /*  I2              */
	V19= (V12)-1;
	V20= (V14)-1;
L878:
	if((V19)<(V11)){
	goto L880;}
	if(!((V20)<(V13))){
	goto L879;}
L880:
	if(!((V19)<(V11))){
	goto L885;}
	if(!((V20)<(V13))){
	goto L885;}
	VALUES(0) = Cnil;
	RETURN(1);
L885:
	VALUES(0) = MAKE_FIXNUM((V19)+1);
	RETURN(1);
L879:
	funcall(2,(V6),elt((V1),V19));
	T0= VALUES(0);
	funcall(2,(V6),elt((V2),V20));
	if((LI2((V4),(V5),T0,VALUES(0)))!=Cnil){
	goto L889;}
	VALUES(0) = MAKE_FIXNUM((V19)+1);
	RETURN(1);
L889:
	V19= (V19)-1;
	V20= (V20)-1;
	goto L878;
	}
	}
	}
	}
}
/*	function definition for SEARCH                                */
static L35(int narg, object V1, object V2, ...)
{ VT37 VLEX37 CLSR37
	cs_check;
	{int i=2;
	object V3;
	object V4;
	object V5;
	register object V6;
	object V7;
	object V8;
	object V9;
	object V10;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[16];
	parse_key(narg,args,8,L35keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	if(keyvars[11]==Cnil){
	V6= symbol_function(VV[65]);
	}else{
	V6= keyvars[3];}
	V7= keyvars[4];
	V8= keyvars[5];
	V9= keyvars[6];
	V10= keyvars[7];
	}
	if((V4)==Cnil){
	goto L899;}
	if((V5)==Cnil){
	goto L899;}
	LI3();
L899:
	{register int V11;                        /*  START1          */
	register int V12;                         /*  END1            */
	if(((V7))==Cnil){
	goto L902;}
	L6(1,(V7))                                /*  THE-START       */;
	V11= fix(VALUES(0));
	goto L900;
L902:
	V11= 0;
L900:
	L5(2,(V9),(V1))                           /*  THE-END         */;
	V12= fix(VALUES(0));
	if((V11)<=(V12)){
	goto L905;}
	L4(2,MAKE_FIXNUM(V11),MAKE_FIXNUM(V12))   /*  BAD-SEQ-LIMIT   */;
L905:
	{register int V13;                        /*  START2          */
	register int V14;                         /*  END2            */
	if(((V8))==Cnil){
	goto L910;}
	L6(1,(V8))                                /*  THE-START       */;
	V13= fix(VALUES(0));
	goto L908;
L910:
	V13= 0;
L908:
	L5(2,(V10),(V2))                          /*  THE-END         */;
	V14= fix(VALUES(0));
	if((V13)<=(V14)){
	goto L913;}
	L4(2,MAKE_FIXNUM(V13),MAKE_FIXNUM(V14))   /*  BAD-SEQ-LIMIT   */;
L913:
	if(((V3))!=Cnil){
	goto L917;}
L920:
	{register int V15;                        /*  I1              */
	register int V16;                         /*  I2              */
	V15= V11;
	V16= V13;
L926:
	if(!((V15)>=(V12))){
	goto L927;}
	VALUES(0) = MAKE_FIXNUM(V13);
	RETURN(1);
L927:
	if(!((V16)>=(V14))){
	goto L930;}
	VALUES(0) = Cnil;
	RETURN(1);
L930:
	funcall(2,(V6),elt((V1),V15));
	T0= VALUES(0);
	funcall(2,(V6),elt((V2),V16));
	if((LI2((V4),(V5),T0,VALUES(0)))!=Cnil){
	goto L933;}
	goto L922;
L933:
	V15= (V15)+1;
	V16= (V16)+1;
	goto L926;
	}
L922:
	V13= (V13)+(1);
	goto L920;
L917:
L945:
	{register int V15;                        /*  I1              */
	register int V16;                         /*  I2              */
	V15= (V12)-1;
	V16= (V14)-1;
L951:
	if(!((V15)<(V11))){
	goto L952;}
	VALUES(0) = MAKE_FIXNUM((V16)+1);
	RETURN(1);
L952:
	if(!((V16)<(V13))){
	goto L955;}
	VALUES(0) = Cnil;
	RETURN(1);
L955:
	funcall(2,(V6),elt((V1),V15));
	T0= VALUES(0);
	funcall(2,(V6),elt((V2),V16));
	if((LI2((V4),(V5),T0,VALUES(0)))!=Cnil){
	goto L958;}
	goto L947;
L958:
	V15= (V15)-1;
	V16= (V16)-1;
	goto L951;
	}
L947:
	V14= (V14)-(1);
	goto L945;
	}
	}
	}
}
/*	function definition for SORT                                  */
static L36(int narg, object V1, object V2, ...)
{ VT38 VLEX38 CLSR38
	cs_check;
	{int i=2;
	object V3;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[2];
	parse_key(narg,args,1,L36keys,keyvars,OBJNULL,FALSE);
	if(keyvars[1]==Cnil){
	V3= symbol_function(VV[65]);
	}else{
	V3= keyvars[0];}
	}
	if(!(type_of((V1))==t_cons||(V1)==Cnil)){
	goto L971;}
	RETURN(L37(3,(V1),(V2),(V3))              /*  LIST-MERGE-SORT */);
L971:
	VALUES(0) = LI39((V1),0,length((V1)),(V2),(V3));
	RETURN(1);
	}
}
/*	function definition for LIST-MERGE-SORT                       */
static L37(int narg, object V1, object V2, object V3)
{ VT39 VLEX39 CLSR39
	cs_check;
	check_arg(3);
	lex0[0]=V2;                               /*  PREDICATE       */
	lex0[1]=V3;                               /*  KEY             */
TTL:
	RETURN(LC38(lex0,1,(V1))                  /*  SORT            */);
}
/*	local function SORT                                           */
static LC38(object *lex0,int narg, object V1)
{ VT40 VLEX40 CLSR40
	check_arg(1);
TTL:
	{register int V2;                         /*  I               */
	register object V3;                       /*  LEFT            */
	register object V4;                       /*  RIGHT           */
	object V5;                                /*  L0              */
	register object V6;                       /*  L1              */
	register object V7;                       /*  KEY-LEFT        */
	register object V8;                       /*  KEY-RIGHT       */
	V2= 0;
	V3= Cnil;
	V4= Cnil;
	V5= Cnil;
	V6= Cnil;
	V7= Cnil;
	V8= Cnil;
	V2= length((V1));
	if(!((V2)<(2))){
	goto L982;}
	VALUES(0) = (V1);
	RETURN(1);
L982:
	if(!((V2)==(2))){
	goto L980;}
	funcall(2,lex0[1],car((V1)));
	V7= VALUES(0);
	funcall(2,lex0[1],cadr((V1)));
	V8= VALUES(0);
	funcall(3,lex0[0],(V7),(V8));
	if(VALUES(0)==Cnil){
	goto L991;}
	VALUES(0) = (V1);
	RETURN(1);
L991:
	funcall(3,lex0[0],(V8),(V7));
	if(VALUES(0)==Cnil){
	goto L994;}
	VALUES(0) = nreverse((V1));
	RETURN(1);
L994:
	VALUES(0) = (V1);
	RETURN(1);
L980:
	{int V13= 2;
	V2= (V2>=0&&V13>0?(V2)/(V13):ifloor(V2,V13));}
	{int V13;                                 /*  J               */
	object V14;                               /*  L1              */
	V13= 1;
	V14= (V1);
L1001:
	if(!((V13)>=(V2))){
	goto L1002;}
	V3= (V1);
	V4= cdr((V14));
	if(type_of((V14))!=t_cons)FEwrong_type_argument(Scons,(V14));
	CDR((V14)) = Cnil;
	goto L998;
L1002:
	V13= (V13)+1;
	V14= cdr((V14));
	goto L1001;
	}
L998:
	LC38(lex0,1,(V3))                         /*  SORT            */;
	V3= VALUES(0);
	LC38(lex0,1,(V4))                         /*  SORT            */;
	V4= VALUES(0);
	if(!(endp((V3)))){
	goto L1019;}
	VALUES(0) = (V4);
	RETURN(1);
L1019:
	if(!(endp((V4)))){
	goto L1017;}
	VALUES(0) = (V3);
	RETURN(1);
L1017:
	V5= CONS(Cnil,Cnil);
	V6= (V5);
	funcall(2,lex0[1],car((V3)));
	V7= VALUES(0);
	funcall(2,lex0[1],car((V4)));
	V8= VALUES(0);
L975:
	funcall(3,lex0[0],(V7),(V8));
	if(VALUES(0)==Cnil){
	goto L1031;}
	goto L976;
L1031:
	funcall(3,lex0[0],(V8),(V7));
	if(VALUES(0)==Cnil){
	goto L1034;}
	goto L977;
L1034:
	goto L976;
L976:
	if(type_of((V6))!=t_cons)FEwrong_type_argument(Scons,(V6));
	CDR((V6)) = (V3);
	V6= cdr((V6));
	V3= cdr((V3));
	if(!(endp((V3)))){
	goto L1041;}
	if(type_of((V6))!=t_cons)FEwrong_type_argument(Scons,(V6));
	CDR((V6)) = (V4);
	VALUES(0) = cdr((V5));
	RETURN(1);
L1041:
	funcall(2,lex0[1],car((V3)));
	V7= VALUES(0);
	goto L975;
L977:
	if(type_of((V6))!=t_cons)FEwrong_type_argument(Scons,(V6));
	CDR((V6)) = (V4);
	V6= cdr((V6));
	V4= cdr((V4));
	if(!(endp((V4)))){
	goto L1052;}
	if(type_of((V6))!=t_cons)FEwrong_type_argument(Scons,(V6));
	CDR((V6)) = (V3);
	VALUES(0) = cdr((V5));
	RETURN(1);
L1052:
	funcall(2,lex0[1],car((V4)));
	V8= VALUES(0);
	goto L975;
	}
}
/*	local entry for function QUICK-SORT                           */
static object LI39(register object V1,register int V2,int V3,register object V4,register object V5)
{ VT41 VLEX41 CLSR41
TTL:
	if(!((V3)<=((V2)+1))){
	goto L1060;}
	return((V1));
L1060:
	{register int V7;                         /*  J               */
	register int V8;                          /*  K               */
	object V9;                                /*  D               */
	object V10;                               /*  KD              */
	V7= V2;
	V8= V3;
	V9= elt((V1),V2);
	funcall(2,(V5),(V9));
	V10= VALUES(0);
L1068:
L1072:
	V8= (V8)-(1);
	if((V7)<(V8)){
	goto L1076;}
	goto L1066;
L1076:
	funcall(2,(V5),elt((V1),V8));
	funcall(3,(V4),VALUES(0),(V10));
	if(VALUES(0)==Cnil){
	goto L1073;}
	goto L1070;
L1073:
	goto L1072;
L1070:
L1085:
	V7= (V7)+(1);
	if((V7)<(V8)){
	goto L1089;}
	goto L1066;
L1089:
	funcall(2,(V5),elt((V1),V7));
	funcall(3,(V4),VALUES(0),(V10));
	if(VALUES(0)!=Cnil){
	goto L1086;}
	goto L1083;
L1086:
	goto L1085;
L1083:
	{object V11;                              /*  TEMP            */
	V11= elt((V1),V7);
	elt_set((V1),V7,elt((V1),V8));
	elt_set((V1),V8,(V11));
	}
	goto L1068;
L1066:
	elt_set((V1),V2,elt((V1),V7));
	elt_set((V1),V7,(V9));
	LI39((V1),V2,V7,(V4),(V5));
	V2= (V7)+1;
	goto TTL;
	}
}
/*	function definition for STABLE-SORT                           */
static L40(int narg, object V1, object V2, ...)
{ VT42 VLEX42 CLSR42
	cs_check;
	{int i=2;
	object V3;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[2];
	parse_key(narg,args,1,L40keys,keyvars,OBJNULL,FALSE);
	if(keyvars[1]==Cnil){
	V3= symbol_function(VV[65]);
	}else{
	V3= keyvars[0];}
	}
	if(!(type_of((V1))==t_cons||(V1)==Cnil)){
	goto L1110;}
	RETURN(L37(3,(V1),(V2),(V3))              /*  LIST-MERGE-SORT */);
L1110:
	if(type_of((V1))==t_string){
	goto L1112;}
	if(!((type_of((V1))==t_bitvector))){
	goto L1113;}
L1112:
	RETURN(L36(4,(V1),(V2),VV[17],(V3))       /*  SORT            */);
L1113:
	(*LK2)(2,(V1),VV[2])                      /*  COERCE          */;
	L37(3,VALUES(0),(V2),(V3))                /*  LIST-MERGE-SORT */;
	T0= VALUES(0);
	RETURN((*LK2)(2,T0,LI1((V1)))             /*  COERCE          */);
	}
}
/*	function definition for MERGE                                 */
static L41(int narg, object V1, object V2, object V3, object V4, ...)
{ VT43 VLEX43 CLSR43
	cs_check;
	{int i=4;
	register object V5;
	va_list args; va_start(args, V4);
	if(narg<4) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[2];
	parse_key(narg,args,1,L41keys,keyvars,OBJNULL,FALSE);
	if(keyvars[1]==Cnil){
	V5= symbol_function(VV[65]);
	}else{
	V5= keyvars[0];}
	}
	{register int V6;                         /*  L1              */
	int V7;                                   /*  L2              */
	V6= length((V2));
	V7= length((V3));
	{register object V8;                      /*  NEWSEQ          */
	register int V9;                          /*  J               */
	register int V10;                         /*  I1              */
	register int V11;                         /*  I2              */
	(*LK0)(2,(V1),MAKE_FIXNUM((V6)+(V7)))     /*  MAKE-SEQUENCE   */;
	V8= VALUES(0);
	V9= 0;
	V10= 0;
	V11= 0;
L1127:
	if(!((V10)==(V6))){
	goto L1128;}
	if(!((V11)==(V7))){
	goto L1128;}
	VALUES(0) = (V8);
	RETURN(1);
L1128:
	if(!((V10)<(V6))){
	goto L1135;}
	if(!((V11)<(V7))){
	goto L1135;}
	funcall(2,(V5),elt((V2),V10));
	T0= VALUES(0);
	funcall(2,(V5),elt((V3),V11));
	funcall(3,(V4),T0,VALUES(0));
	if(VALUES(0)==Cnil){
	goto L1140;}
	elt_set((V8),V9,elt((V2),V10));
	V10= (V10)+(1);
	goto L1133;
L1140:
	funcall(2,(V5),elt((V3),V11));
	T0= VALUES(0);
	funcall(2,(V5),elt((V2),V10));
	funcall(3,(V4),T0,VALUES(0));
	if(VALUES(0)==Cnil){
	goto L1147;}
	elt_set((V8),V9,elt((V3),V11));
	V11= (V11)+(1);
	goto L1133;
L1147:
	elt_set((V8),V9,elt((V2),V10));
	V10= (V10)+(1);
	goto L1133;
L1135:
	if(!((V10)<(V6))){
	goto L1156;}
	elt_set((V8),V9,elt((V2),V10));
	V10= (V10)+(1);
	goto L1133;
L1156:
	elt_set((V8),V9,elt((V3),V11));
	V11= (V11)+(1);
L1133:
	V9= (V9)+1;
	goto L1127;
	}
	}
	}
}
/*	global entry for the function QUICK-SORT                      */
static L39(int narg, object V1, object V2, object V3, object V4, object V5)
{
	check_arg(5);
	VALUES(0)=(LI39((V1),fix(V2),fix(V3),(V4),(V5)));
	RETURN(1);
}
/*	global entry for the function TEST-ERROR                      */
static L3(int narg)
{
	check_arg(0);
	VALUES(0)=(LI3());
	RETURN(1);
}
/*	global entry for the function CALL-TEST                       */
static L2(int narg, object V1, object V2, object V3, object V4)
{
	check_arg(4);
	VALUES(0)=(LI2((V1),(V2),(V3),(V4)));
	RETURN(1);
}
/*	global entry for the function SEQTYPE                         */
static L1(int narg, object V1)
{
	check_arg(1);
	VALUES(0)=(LI1((V1)));
	RETURN(1);
}
static LKF2(int narg, ...) {TRAMPOLINK(VV[69],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[68],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[67],&LK0);}
