
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "trace.h"
init_trace(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_trace; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	funcall(2,symbol_function(VV[92]),VV[0])  /*  PROCLAIM        */;
	VV[1]->s.s_stype=(short)stp_special;
	if(VV[1]->s.s_dbind == OBJNULL){
	(VV[1]->s.s_dbind)= MAKE_FIXNUM(0);}
	VV[2]->s.s_stype=(short)stp_special;
	if(VV[2]->s.s_dbind == OBJNULL){
	(VV[2]->s.s_dbind)= Cnil;}
	MM0(VV[93],L1);
	MF0(VV[3],L2);
	MM0(VV[94],L3);
	MF0(VV[5],L4);
	VV[6]->s.s_stype=(short)stp_special;
	if(VV[6]->s.s_dbind == OBJNULL){
	(VV[6]->s.s_dbind)= Cnil;}
	MF0(VV[95],L5);
	MF0(VV[38],L6);
	MF0(VV[96],L7);
	MF0(VV[97],L8);
	VV[66]->s.s_stype=(short)stp_special;
	if(VV[66]->s.s_dbind == OBJNULL){
	(VV[66]->s.s_dbind)= MAKE_FIXNUM(0);}
	VV[67]->s.s_stype=(short)stp_special;
	if(VV[67]->s.s_dbind == OBJNULL){
	(VV[67]->s.s_dbind)= Cnil;}
	VV[68]->s.s_stype=(short)stp_special;
	if(VV[68]->s.s_dbind == OBJNULL){
	(VV[68]->s.s_dbind)= Cnil;}
	VV[69]->s.s_stype=(short)stp_special;
	VV[70]->s.s_stype=(short)stp_special;
	VV[71]->s.s_stype=(short)stp_special;
	if(VV[71]->s.s_dbind == OBJNULL){
	(VV[71]->s.s_dbind)= CONS(Cnil,Cnil);}
	siLAmake_constant(2,VV[72],VV[73])        /*  *MAKE-CONSTANT  */;
	MM0(VV[98],L9);
	MF0(VV[74],L10);
	VV[85]=string_to_object(VV[85]);
	VV[86]=string_to_object(VV[86]);
	MF0(VV[99],L11);
	MF0(VV[100],L13);
	MF0(VV[101],L14);
	MF0(VV[102],L15);
	MF0(VV[103],L16);
	MF0(VV[104],L17);
}
/*	macro definition for TRACE                                    */
static L1(int narg, object V1, object V2)
{ VT3 VLEX3 CLSR3
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4;
	V4= V3;
	VALUES(0) = list(2,VV[3],list(2,VV[4],(V4)));
	RETURN(1);}
}
/*	function definition for TRACE*                                */
static L2(int narg, object V1)
{ VT4 VLEX4 CLSR4
	cs_check;
	check_arg(1);
TTL:
	if(((V1))!=Cnil){
	goto L12;}
	VALUES(0) = symbol_value(VV[2]);
	RETURN(1);
L12:
	{
	object V2= (V1);
	if(endp(V2)){
	VALUES(0) = Cnil;
	RETURN(1);}
L14:
	L5(1,CAR(V2))                             /*  TRACE-ONE       */;
	if(endp(V2=CDR(V2))){
	VALUES(0) = (V1);
	RETURN(1);}
	goto L14;}
}
/*	macro definition for UNTRACE                                  */
static L3(int narg, object V1, object V2)
{ VT5 VLEX5 CLSR5
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4;
	V4= V3;
	VALUES(0) = list(2,VV[5],list(2,VV[4],(V4)));
	RETURN(1);}
}
/*	function definition for UNTRACE*                              */
static L4(int narg, object V1)
{ VT6 VLEX6 CLSR6
	cs_check;
	check_arg(1);
TTL:
	if(((V1))!=Cnil){
	goto L19;}
	VALUES(0) = symbol_value(VV[2]);
	goto L17;
L19:
	VALUES(0) = (V1);
L17:
	{
	object V2= VALUES(0);
	if(endp(V2)){
	VALUES(0) = Cnil;
	RETURN(1);}
L16:
	L7(1,CAR(V2))                             /*  UNTRACE-ONE     */;
	if(endp(V2=CDR(V2))){
	VALUES(0) = VALUES(0);
	RETURN(1);}
	goto L16;}
}
/*	function definition for TRACE-ONE                             */
static L5(int narg, object V1)
{ VT7 VLEX7 CLSR7
	cs_check;
	check_arg(1);
TTL:
	{volatile object V2;                      /*  BREAK           */
	volatile object V3;                       /*  EXITBREAK       */
	volatile object V4;                       /*  ENTRYCOND       */
	volatile object V5;                       /*  EXITCOND        */
	volatile object V6;                       /*  ENTRY           */
	volatile object V7;                       /*  EXIT            */
	volatile object V8;                       /*  STEP            */
	volatile object V9;                       /*  BARFP           */
	volatile object V10;                      /*  FNAME           */
	volatile object V11;                      /*  OLDF            */
	V2= Cnil;
	V3= Cnil;
	V4= Ct;
	V5= Ct;
	V6= Cnil;
	V7= Cnil;
	V8= Cnil;
	V9= Ct;
	V10= Cnil;
	V11= Cnil;
	if(!(type_of((V1))!=t_cons)){
	goto L24;}
	V10= (V1);
	goto L22;
L24:
	if(!((VV[7])==(car((V1))))){
	goto L28;}
	V10= get(cadr((V1)),VV[8],Cnil);
	goto L22;
L28:
	if(!(type_of(car((V1)))!=t_cons)){
	goto L32;}
	V10= car((V1));
	{volatile object V12;                     /*  SPECS           */
	V12= cdr((V1));
L38:
	if(((V12))!=Cnil){
	goto L39;}
	goto L22;
L39:
	{register object V14;
	V14= car((V12));
	if(!(eql((V14),VV[9]))){
	goto L45;}
	V9= (V12);
	V12= cdr((V12));
	V2= car((V12));
	goto L42;
L45:
	if(!(eql((V14),VV[10]))){
	goto L53;}
	V9= (V12);
	V12= cdr((V12));
	V3= car((V12));
	goto L42;
L53:
	if(!(eql((V14),VV[11]))){
	goto L61;}
	V8= Ct;
	goto L42;
L61:
	if(!(eql((V14),VV[12]))){
	goto L65;}
	V9= (V12);
	V12= cdr((V12));
	V4= car((V12));
	V5= (V4);
	goto L42;
L65:
	if(!(eql((V14),VV[13]))){
	goto L74;}
	V9= (V12);
	V12= cdr((V12));
	V4= car((V12));
	goto L42;
L74:
	if(!(eql((V14),VV[14]))){
	goto L82;}
	V9= (V12);
	V12= cdr((V12));
	V5= car((V12));
	goto L42;
L82:
	if(!(eql((V14),VV[15]))){
	goto L90;}
	V9= (V12);
	V12= cdr((V12));
	V6= car((V12));
	goto L42;
L90:
	if(!(eql((V14),VV[16]))){
	goto L98;}
	V9= (V12);
	V12= cdr((V12));
	V7= car((V12));
	goto L42;
L98:
	Lerror(2,VV[17],car((V12)))               /*  ERROR           */;
	}
L42:
	if(((V9))!=Cnil){
	goto L105;}
	Lerror(1,VV[18])                          /*  ERROR           */;
L105:
	V12= cdr((V12));
	goto L38;
	}
L32:
	if(!((VV[7])==(caar((V1))))){
	goto L112;}
	V1= CONS(get(cadar((V1)),VV[8],Cnil),cdr((V1)));
	goto TTL;
L112:
	{volatile object V16;                     /*  RESULTS         */
	V16= Cnil;
	{volatile object V17;
	volatile object V18;                      /*  FNAME           */
	V17= car((V1));
	V18= Cnil;
L120:
	if(!(endp((V17)))){
	goto L121;}
	goto L116;
L121:
	V18= car((V17));
	L5(1,CONS((V18),cdr((V1))))               /*  TRACE-ONE       */;
	V16= CONS(VALUES(0),(V16));
	V17= cdr((V17));
	goto L120;
	}
L116:
	VALUES(0) = nreverse((V16));
	RETURN(1);
	}
L22:
	Lfboundp(1,(V10))                         /*  FBOUNDP         */;
	if(VALUES(0)!=Cnil){
	goto L132;}
	Lformat(3,symbol_value(VV[19]),VV[20],(V10))/*  FORMAT        */;
	VALUES(0) = Cnil;
	RETURN(1);
L132:
	Lspecial_form_p(1,(V10))                  /*  SPECIAL-FORM-P  */;
	if(VALUES(0)==Cnil){
	goto L136;}
	Lformat(3,symbol_value(VV[19]),VV[21],(V10))/*  FORMAT        */;
	VALUES(0) = Cnil;
	RETURN(1);
L136:
	Lmacro_function(1,(V10))                  /*  MACRO-FUNCTION  */;
	if(VALUES(0)==Cnil){
	goto L140;}
	Lformat(3,symbol_value(VV[19]),VV[22],(V10))/*  FORMAT        */;
	VALUES(0) = Cnil;
	RETURN(1);
L140:
	if((get((V10),VV[23],Cnil))==Cnil){
	goto L144;}
	L8(1,(V10))                               /*  TRACING-BODY    */;
	if(VALUES(0)==Cnil){
	goto L148;}
	Lformat(3,symbol_value(VV[19]),VV[24],(V10))/*  FORMAT        */;
	VALUES(0) = Cnil;
	RETURN(1);
L148:
	L7(1,(V10))                               /*  UNTRACE-ONE     */;
L144:
	Lgensym(0)                                /*  GENSYM          */;
	V11= VALUES(0);
	siLfset(2,(V11),symbol_function((V10)))   /*  FSET            */;
	putprop((V10),(V11),VV[23]);
	{object V12= list(3,VV[32],VV[33],list(2,VV[34],list(3,VV[35],list(2,VV[4],(V11)),VV[36])));
	if(((V4))==Cnil){
	goto L157;}
	if(!((Ct)==((V4)))){
	goto L160;}
	T0= CONS(listA(5,VV[38],VV[39],list(2,VV[4],(V10)),VV[36],(V6)),Cnil);
	goto L155;
L160:
	T0= CONS(list(3,VV[40],(V4),listA(5,VV[38],VV[41],list(2,VV[4],(V10)),VV[36],(V6))),Cnil);
	goto L155;
L157:
	T0= Cnil;
L155:
	if(((V2))==Cnil){
	goto L164;}
	T1= CONS(list(3,VV[40],(V2),list(3,VV[29],VV[42],list(3,VV[43],VV[44],list(2,VV[4],(V10))))),Cnil);
	goto L162;
L164:
	T1= Cnil;
L162:
	if(((V8))==Cnil){
	goto L168;}
	VALUES(0) = list(3,VV[29],VV[46],listA(3,VV[47],list(2,VV[4],(V11)),VV[48]));
	goto L166;
L168:
	VALUES(0) = list(3,VV[35],list(2,VV[4],(V11)),VV[36]);
L166:
	{object V13= list(3,VV[32],VV[33],list(3,VV[29],VV[45],list(2,VV[34],VALUES(0))));
	if(((V5))==Cnil){
	goto L172;}
	if(!((Ct)==((V5)))){
	goto L175;}
	T2= CONS(listA(5,VV[38],VV[49],list(2,VV[4],(V10)),VV[33],(V7)),Cnil);
	goto L170;
L175:
	T2= CONS(list(3,VV[40],(V5),listA(5,VV[38],VV[50],list(2,VV[4],(V10)),VV[33],(V7))),Cnil);
	goto L170;
L172:
	T2= Cnil;
L170:
	if(((V3))==Cnil){
	goto L179;}
	VALUES(0) = CONS(list(3,VV[40],(V3),list(3,VV[29],VV[51],list(3,VV[43],VV[52],list(2,VV[4],(V10))))),Cnil);
	goto L177;
L179:
	VALUES(0) = Cnil;
L177:
	Lappend(3,T0,T1,CONS((V13),append(T2,VALUES(0))))/*  APPEND   */;
	Leval(1,list(4,VV[25],(V10),VV[26],list(3,VV[27],VV[28],list(4,VV[29],VV[30],list(4,VV[31],VV[6],(V12),listA(3,VV[29],VV[37],VALUES(0))),VV[53]))))/*  EVAL*/;}}
	setq(VV[2],CONS((V10),symbol_value(VV[2])));
	VALUES(0) = CONS((V10),Cnil);
	RETURN(1);
	}
}
/*	function definition for TRACE-PRINT                           */
static L6(int narg, object V1, object V2, object V3, ...)
{ VT8 VLEX8 CLSR8
	cs_check;
	{volatile object V4;
	va_list args; va_start(args, V3);
	if(narg<3) FEtoo_few_arguments(&narg);
	narg -=3;
	V4=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object p=V4;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{volatile object V5;                      /*  INDENT          */
	{object V6= number_times(one_minus(symbol_value(VV[1])),MAKE_FIXNUM(2));
	V5= (number_compare(V6,MAKE_FIXNUM(20))<=0?V6:MAKE_FIXNUM(20));}
	Lfresh_line(1,symbol_value(VV[19]))       /*  FRESH-LINE      */;
	if(((V1)!= VV[105]))goto L187;
	{ int V6;
	volatile object V7;                       /*  BARS            */
	volatile object V8;                       /*  REM             */
	V6=Lfloor(2,(V5),MAKE_FIXNUM(4))          /*  FLOOR           */;
	if (V6--==0) goto L190;
	V7= VALUES(0);
	if (V6--==0) goto L191;
	V8= VALUES(1);
	goto L192;
L190:
	V7= Cnil;
L191:
	V8= Cnil;
L192:
	{volatile object V9;
	volatile int V10;                         /*  I               */
	V9= (V7);
	V10= 0;
L197:
	if(!(number_compare(MAKE_FIXNUM(V10),(V9))>=0)){
	goto L198;}
	goto L193;
L198:
	princ_str("|   ",symbol_value(VV[19]));
	V10= (V10)+1;
	goto L197;
	}
L193:
	if(!(number_compare(MAKE_FIXNUM(0),(V8))<0)){
	goto L188;}
	Lformat(4,symbol_value(VV[19]),VV[54],(V8),VV[55])/*  FORMAT  */;}
L188:
	Lformat(5,symbol_value(VV[19]),VV[56],symbol_value(VV[1]),(V2),(V3))/*  FORMAT*/;
	goto L186;
L187:
	if(((V1)!= VV[106]))goto L207;
	{ int V6;
	volatile object V7;                       /*  BARS            */
	volatile object V8;                       /*  REM             */
	V6=Lfloor(2,(V5),MAKE_FIXNUM(4))          /*  FLOOR           */;
	if (V6--==0) goto L210;
	V7= VALUES(0);
	if (V6--==0) goto L211;
	V8= VALUES(1);
	goto L212;
L210:
	V7= Cnil;
L211:
	V8= Cnil;
L212:
	{volatile object V9;
	volatile int V10;                         /*  I               */
	V9= (V7);
	V10= 0;
L217:
	if(!(number_compare(MAKE_FIXNUM(V10),(V9))>=0)){
	goto L218;}
	goto L213;
L218:
	princ_str("|   ",symbol_value(VV[19]));
	V10= (V10)+1;
	goto L217;
	}
L213:
	if(!(number_compare(MAKE_FIXNUM(0),(V8))<0)){
	goto L208;}
	Lformat(4,symbol_value(VV[19]),VV[57],(V8),VV[58])/*  FORMAT  */;}
L208:
	Lformat(5,symbol_value(VV[19]),VV[59],symbol_value(VV[1]),(V2),(V3))/*  FORMAT*/;
	goto L186;
L207:
L186:
	if(((V4))==Cnil){
	goto L228;}
	{ int V6;
	volatile object V7;                       /*  BARS            */
	volatile object V8;                       /*  REM             */
	V6=Lfloor(2,(V5),MAKE_FIXNUM(4))          /*  FLOOR           */;
	if (V6--==0) goto L232;
	V7= VALUES(0);
	if (V6--==0) goto L233;
	V8= VALUES(1);
	goto L234;
L232:
	V7= Cnil;
L233:
	V8= Cnil;
L234:
	{volatile object V9;
	volatile int V10;                         /*  I               */
	V9= (V7);
	V10= 0;
L239:
	if(!(number_compare(MAKE_FIXNUM(V10),(V9))>=0)){
	goto L240;}
	goto L235;
L240:
	princ_str("|   ",symbol_value(VV[19]));
	V10= (V10)+1;
	goto L239;
	}
L235:
	if(!(number_compare(MAKE_FIXNUM(0),(V8))<0)){
	goto L230;}
	Lformat(4,symbol_value(VV[19]),VV[60],(V8),VV[61])/*  FORMAT  */;}
L230:
	RETURN(Lformat(3,symbol_value(VV[19]),VV[62],(V4))/*  FORMAT  */);
L228:
	VALUES(0) = Cnil;
	RETURN(1);
	}
	}
}
/*	function definition for UNTRACE-ONE                           */
static L7(int narg, object V1)
{ VT9 VLEX9 CLSR9
	cs_check;
	check_arg(1);
TTL:
	if((get((V1),VV[23],Cnil))==Cnil){
	goto L250;}
	L8(1,(V1))                                /*  TRACING-BODY    */;
	if(VALUES(0)==Cnil){
	goto L254;}
	siLfset(2,(V1),symbol_function(get((V1),VV[23],Cnil)))/*  FSET*/;
	goto L252;
L254:
	Lformat(3,symbol_value(VV[19]),VV[63],(V1))/*  FORMAT         */;
L252:
	remprop((V1),VV[23]);
	{object V2= symbol_value(VV[2]);
	VALUES(0) = symbol_function(VV[107]);
	(*LK0)(4,(V1),V2,VV[64],VALUES(0))        /*  DELETE          */;
	setq(VV[2],VALUES(0));}
	VALUES(0) = CONS((V1),Cnil);
	RETURN(1);
L250:
	Lformat(3,symbol_value(VV[19]),VV[65],(V1))/*  FORMAT         */;
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for TRACING-BODY                          */
static L8(int narg, object V1)
{ VT10 VLEX10 CLSR10
	cs_check;
	check_arg(1);
TTL:
	{register object V2;                      /*  FUN             */
	V2= symbol_function((V1));
	if(type_of((V2))==t_cons){
	goto L262;}
	VALUES(0) = Cnil;
	RETURN(1);
L262:
	if(type_of(cadddr((V2)))==t_cons){
	goto L264;}
	VALUES(0) = Cnil;
	RETURN(1);
L264:
	if((car(cadddr((V2))))==(VV[27])){
	goto L266;}
	VALUES(0) = Cnil;
	RETURN(1);
L266:
	VALUES(0) = ((cadr(cadddr((V2))))==(VV[28])?Ct:Cnil);
	RETURN(1);
	}
}
/*	macro definition for STEP                                     */
static L9(int narg, object V1, object V2)
{ VT11 VLEX11 CLSR11
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4;
	if(endp(V3))FEinvalid_macro_call(VV[98]);
	V4= CAR(V3);
	V3=CDR(V3);
	if(!endp(V3))FEinvalid_macro_call(VV[98]);
	VALUES(0) = list(2,VV[74],list(2,VV[4],(V4)));
	RETURN(1);}
}
/*	function definition for STEP*                                 */
static L10(int narg, object V1)
{ VT12 VLEX12 CLSR12
	cs_check;
	bds_check;
	check_arg(1);
TTL:
	bds_bind(VV[67],Cnil);                    /*  *STEP-QUIT*     */
	bds_bind(VV[68],Cnil);                    /*  *STEP-FUNCTION* */
	bds_bind(VV[66],MAKE_FIXNUM(0));          /*  *STEP-LEVEL*    */
	{int V2;
	V2=L11(2,(V1),Cnil)                       /*  STEPPER         */;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V2);}
}
/*	function definition for STEPPER                               */
static L11(int narg, object V1, ...)
{ VT13 VLEX13 CLSR13
	cs_check;
	bds_check;
	{int i=1;
	volatile object V2;
	va_list args; va_start(args, V1);
	if(narg<1) FEtoo_few_arguments(&narg);
	if(narg>2) FEtoo_many_arguments(&narg);
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(V1,env0));            /*  FORM            */
	if (i==narg) goto L268;
	V2= va_arg(args, object);
	i++;
	goto L269;
L268:
	V2= Cnil;
L269:
	if(!((symbol_value(VV[67]))==(Ct))){
	goto L271;}
	RETURN(Levalhook(4,*CLV0,Cnil,Cnil,(V2))  /*  EVALHOOK        */);
L271:
	if(!(type_of(*CLV0)==t_cons)){
	goto L274;}
	if(!(type_of(car(*CLV0))==t_symbol)){
	goto L274;}
	if((get(car(*CLV0),VV[23],Cnil))==Cnil){
	goto L274;}
	L8(1,car(*CLV0))                          /*  TRACING-BODY    */;
	if(VALUES(0)==Cnil){
	goto L274;}
	{volatile object V3;                      /*  ARGS            */
	volatile object V4;                       /*  VALUES          */
	V3= cdr(*CLV0);
	V4= Cnil;
L285:
	if(((V3))!=Cnil){
	goto L286;}
	{object V7= car(*CLV0);
	{object V8= nreverse((V4));
	VALUES(0) = symbol_function(VV[99]);
	RETURN(Lapplyhook(5,(V7),(V8),VALUES(0),Cnil,(V2))/*  APPLYHOOK*/);}}
L286:
	{object V9= car((V3));
	VALUES(0) = symbol_function(VV[99]);
	Levalhook(4,(V9),VALUES(0),Cnil,(V2))     /*  EVALHOOK        */;
	V4= CONS(VALUES(0),(V4));}
	V3= cdr((V3));
	goto L285;
	}
L274:
	if(!(numberp(symbol_value(VV[67])))){
	goto L297;}
	if(!(number_compare(symbol_value(VV[66]),symbol_value(VV[67]))>=0)){
	goto L301;}
	RETURN(Levalhook(4,*CLV0,Cnil,Cnil,(V2))  /*  EVALHOOK        */);
L301:
	setq(VV[67],Cnil);
L297:
	if((symbol_value(VV[68]))==Cnil){
	goto L304;}
	if(!(type_of(*CLV0)==t_cons)){
	goto L308;}
	if(!((car(*CLV0))==(symbol_value(VV[68])))){
	goto L308;}
	bds_bind(VV[68],Cnil);                    /*  *STEP-FUNCTION* */
	{int V4;
	V4=L11(2,*CLV0,(V2))                      /*  STEPPER         */;
	bds_unwind1;
	RETURN(V4);}
L308:
	VALUES(0) = symbol_function(VV[99]);
	RETURN(Levalhook(4,*CLV0,VALUES(0),Cnil,(V2))/*  EVALHOOK     */);
L304:
	{volatile object V3;
	volatile object V4;                       /*  VALUES          */
	volatile object V5;                       /*  PROMPT          */
	V3= one_plus(symbol_value(VV[66]));
	bds_bind(VV[66],V3);                      /*  *STEP-LEVEL*    */
	bds_bind(VV[69],*CLV0);                   /*  *STEP-FORM*     */
	bds_bind(VV[70],(V2));                    /*  *STEP-ENV*      */
	V4= Cnil;
	CLV1=&CAR(env0=CONS(Cnil,env0));          /*  INDENT          */
	V5= Cnil;
	{object V6= number_times(symbol_value(VV[75]),MAKE_FIXNUM(2));
	*CLV1= (number_compare(V6,MAKE_FIXNUM(20))<=0?V6:MAKE_FIXNUM(20));}
	V5= make_cclosure(LC12,env0,&Cblock);
	Lconstantp(1,*CLV0)                       /*  CONSTANTP       */;
	if(VALUES(0)==Cnil){
	goto L320;}
	Lformat(3,symbol_value(VV[76]),VV[82],*CLV1)/*  FORMAT        */;
	Lwrite(9,*CLV0,VV[78],symbol_value(VV[76]),VV[79],Cnil,VV[80],MAKE_FIXNUM(2),VV[81],MAKE_FIXNUM(2))/*  WRITE*/;
	princ_char(32,symbol_value(VV[76]));
	princ_char(61,symbol_value(VV[76]));
	{ int V7,V6;
	V6=Levalhook(4,*CLV0,Cnil,Cnil,(V2))      /*  EVALHOOK        */;
	APPLY(V6,Llist,&VALUES(0))                /*  LIST            */;
	V4= VALUES(0);}
	{volatile object V6;
	volatile object V7;                       /*  V               */
	V6= (V4);
	V7= Cnil;
L333:
	if(!(endp((V6)))){
	goto L334;}
	goto L329;
L334:
	V7= car((V6));
	princ_char(32,symbol_value(VV[76]));
	Lwrite(9,(V7),VV[78],symbol_value(VV[76]),VV[79],Cnil,VV[80],MAKE_FIXNUM(2),VV[81],MAKE_FIXNUM(2))/*  WRITE*/;
	V6= cdr((V6));
	goto L333;
	}
L329:
	princ_char(10,symbol_value(VV[76]));
	goto L318;
L320:
	{ int V6;
	if ((V6=frs_push(FRS_CATCH,symbol_value(VV[71])))==0) {
	Ladjoin(2,VV[86],symbol_value(VV[87]))    /*  ADJOIN          */;
	Ladjoin(2,VV[85],VALUES(0))               /*  ADJOIN          */;
	V6=(*LK1)(6,VV[83],Ct,VV[84],VALUES(0),VV[88],(V5))/*  TPL    */;
	}
	else V6--;
	frs_pop();
	V4= VALUES(0);}
	if(!(endp((V4)))){
	goto L351;}
	Lformat(3,symbol_value(VV[76]),VV[89],*CLV1)/*  FORMAT        */;
	goto L318;
L351:
	{volatile object V6;                      /*  L               */
	volatile object V7;                       /*  B               */
	V6= (V4);
	V7= Ct;
L354:
	if(!(endp((V6)))){
	goto L355;}
	goto L318;
L355:
	{object V9= symbol_value(VV[76]);
	if(((V7))==Cnil){
	goto L361;}
	T0= code_char('\75');
	goto L359;
L361:
	T0= code_char('\46');
L359:
	Lformat(5,V9,VV[90],*CLV1,T0,car((V6)))   /*  FORMAT          */;}
	Lwrite(9,car((V6)),VV[78],symbol_value(VV[76]),VV[79],Cnil,VV[80],MAKE_FIXNUM(2),VV[81],MAKE_FIXNUM(2))/*  WRITE*/;
	princ_char(10,symbol_value(VV[76]));
	V6= cdr((V6));
	V7= Cnil;
	goto L354;
	}
L318:
	{int V6;
	V6=Lvalues_list(1,(V4))                   /*  VALUES-LIST     */;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V6);}
	}
	}
}
/*	closure CLOSURE                                               */
static LC12(int narg, object env0)
{ VT14 VLEX14 CLSR14
	narg--;
	{object scan=env0;
	CLV1= &CAR(scan);                         /*  INDENT          */ scan=CDR(scan);
	CLV0= &CAR(scan);                         /*  FORM            */}
	check_arg(0);
	Lformat(3,symbol_value(VV[76]),VV[77],*CLV1)/*  FORMAT        */;
	Lwrite(9,*CLV0,VV[78],symbol_value(VV[76]),VV[79],Cnil,VV[80],MAKE_FIXNUM(2),VV[81],MAKE_FIXNUM(2))/*  WRITE*/;
	princ_char(32,symbol_value(VV[76]));
	VALUES(0) = princ(code_char(VV[110]),symbol_value(VV[76]));
	RETURN(1);
}
/*	function definition for STEP-NEXT                             */
static L13(int narg)
{ VT15 VLEX15 CLSR15
	cs_check;
	check_arg(0);
TTL:
	{frame_ptr fr; int V1;
	fr=frs_sch_catch(symbol_value(VV[71]));
	if (fr==NULL) FEerror("The tag ~s is undefined.",1,symbol_value(VV[71]));
	{ int V3,V2;
	{object V4= symbol_value(VV[69]);
	VALUES(0) = symbol_function(VV[99]);
	V2=(*LK2)(4,V4,VALUES(0),Cnil,symbol_value(VV[70]))/*  EVALHOOK*/;}
	V1=APPLY(V2,Llist,&VALUES(0))             /*  LIST            */;}
	unwind(fr,symbol_value(VV[71]),V1+1);}
}
/*	function definition for STEP-SKIP                             */
static L14(int narg, ...)
{ VT16 VLEX16 CLSR16
	cs_check;
	bds_check;
	{int i=0;
	register object V1;
	va_list args; va_start(args, narg);
	if(narg>1) FEtoo_many_arguments(&narg);
	if (i==narg) goto L375;
	V1= va_arg(args, object);
	i++;
	goto L376;
L375:
	V1= MAKE_FIXNUM(0);
L376:
	{frame_ptr fr; int V2;
	fr=frs_sch_catch(symbol_value(VV[71]));
	if (fr==NULL) FEerror("The tag ~s is undefined.",1,symbol_value(VV[71]));
	{ int V4,V3;
	if(!(type_of((V1))==t_symbol)){
	goto L381;}
	bds_bind(VV[68],(V1));                    /*  *STEP-FUNCTION* */
	{object V5= symbol_value(VV[69]);
	VALUES(0) = symbol_function(VV[99]);
	V3=(*LK2)(4,V5,VALUES(0),Cnil,symbol_value(VV[70]))/*  EVALHOOK*/;
	bds_unwind1;
	goto L379;}
L381:
	if(!(type_of((V1))==t_fixnum||type_of((V1))==t_bignum)){
	goto L385;}
	setq(VV[67],number_minus(symbol_value(VV[66]),(V1)));
	V3=(*LK2)(4,symbol_value(VV[69]),Cnil,Cnil,symbol_value(VV[70]))/*  EVALHOOK*/;
	goto L379;
L385:
	V3=Lerror(1,VV[91])                       /*  ERROR           */;
L379:
	V2=APPLY(V3,Llist,&VALUES(0))             /*  LIST            */;}
	unwind(fr,symbol_value(VV[71]),V2+1);}
	}
}
/*	function definition for STEP-PRINT                            */
static L15(int narg)
{ VT17 VLEX17 CLSR17
	cs_check;
	check_arg(0);
TTL:
	Lwrite(9,symbol_value(VV[69]),VV[78],symbol_value(VV[76]),VV[79],Ct,VV[80],Cnil,VV[81],Cnil)/*  WRITE*/;
	princ_char(10,Cnil);
	RETURN(0);
}
/*	function definition for STEP-QUIT                             */
static L16(int narg)
{ VT18 VLEX18 CLSR18
	cs_check;
	check_arg(0);
TTL:
	setq(VV[67],Ct);
	{frame_ptr fr; int V1;
	fr=frs_sch_catch(symbol_value(VV[71]));
	if (fr==NULL) FEerror("The tag ~s is undefined.",1,symbol_value(VV[71]));
	{ int V3,V2;
	V2=(*LK2)(4,symbol_value(VV[69]),Cnil,Cnil,symbol_value(VV[70]))/*  EVALHOOK*/;
	V1=APPLY(V2,Llist,&VALUES(0))             /*  LIST            */;}
	unwind(fr,symbol_value(VV[71]),V1+1);}
}
/*	function definition for STEP-RETURN                           */
static L17(int narg, ...)
{ VT19 VLEX19 CLSR19
	cs_check;
	{object V1;
	va_list args; va_start(args, narg);
	narg -=0;
	V1=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object p=V1;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{frame_ptr fr; int V2;
	fr=frs_sch_catch(symbol_value(VV[71]));
	if (fr==NULL) FEerror("The tag ~s is undefined.",1,symbol_value(VV[71]));
	VALUES(0)=(V1);
	V2=1;
	unwind(fr,symbol_value(VV[71]),V2+1);}
	}
}
static LKF2(int narg, ...) {TRAMPOLINK(VV[111],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[109],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[108],&LK0);}
