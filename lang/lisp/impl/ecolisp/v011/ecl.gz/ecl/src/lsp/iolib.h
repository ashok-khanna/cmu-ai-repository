
/* (c) Copyright G. Attardi, 1993. */
static L1();
static L2();
static L3();
static L8();
int Lset_dispatch_macro_character();
int Lset_dispatch_macro_character();
int Lset_dispatch_macro_character();
int Lset_dispatch_macro_character();
#define VT2
#define VLEX2
#define CLSR2
#define VT3
#define VLEX3
#define CLSR3
#define VT4
#define VLEX4
#define CLSR4
#define VT5
#define VLEX5
#define CLSR5
static L4(int, object, ...);
static intUobject L4keys[3]={61,62,63};
int Lmake_string_input_stream();
int Lread_preserving_whitespace();
int siLget_string_input_stream_index();
int Lread();
int siLget_string_input_stream_index();
#define VT6 object T0;
#define VLEX6
#define CLSR6
static L5(int, object, ...);
static intUobject L5keys[10]={64,65,66,67,68,69,70,71,72,73};
int Lmake_string_output_stream();
int Lapply();
int Lget_output_stream_string();
#define VT7
#define VLEX7
#define CLSR7
static L6(int, object);
int Lmake_string_output_stream();
int Lget_output_stream_string();
#define VT8
#define VLEX8
#define CLSR8
static L7(int, object);
int Lmake_string_output_stream();
int Lget_output_stream_string();
#define VT9
#define VLEX9
#define CLSR9
#define VT10
#define VLEX10
#define CLSR10
static L9(int, ...);
int Lformat();
int Lread();
#define VT11
#define VLEX11
#define CLSR11
static L10(int, ...);
int Lformat();
int Lread();
#define VT12
#define VLEX12
#define CLSR12
static L11(int, object, object, object);
int Lread();
#define VT13
#define VLEX13
#define CLSR13
static L12(int, object, object, object);
int Lerror();
int Lread();
int Lerror();
int Lerror();
int Lapply();
int Lintern();
#define VT14
#define VLEX14
#define CLSR14
static L13(int, ...);
int Lerror();
int Lclose();
int Lformat();
int Lerror();
int Lmake_echo_stream();
int Lmake_broadcast_stream();
int Lmake_two_way_stream();
int Lformat();
#define VT15 object T0;
#define VLEX15
#define CLSR15
static struct codeblock Cblock;
#define VM15 1
#define VM14 0
#define VM13 0
#define VM12 0
#define VM11 0
#define VM10 0
#define VM9 0
#define VM8 0
#define VM7 0
#define VM6 1
#define VM5 0
#define VM4 0
#define VM3 0
#define VM2 0
#define VM1 78
static object VV[78];
static LKF0(int, ...);
static (*LK0)(int, ...)=LKF0;
static LKF1(int, ...);
static (*LK1)(int, ...)=LKF1;
static LKF2(int, ...);
static (*LK2)(int, ...)=LKF2;
static LKF3(int, ...);
static (*LK3)(int, ...)=LKF3;
static LKF4(int, ...);
static (*LK4)(int, ...)=LKF4;
