
/* (c) Copyright G. Attardi, 1993. */
#define VT2
#define VLEX2
#define CLSR2
static L1(int, object, object, object);
#define VT3
#define VLEX3
#define CLSR3
static L2(int, object, object, object);
#define VT4 object T0,T1;
#define VLEX4
#define CLSR4
static L6(int, object, object, object);
#define VT5 object T0,T1;
#define VLEX5
#define CLSR5
static L10(int, object, object, object);
#define VT6 object T0,T1;
#define VLEX6
#define CLSR6
static L14(int, object, object);
#define VT7
#define VLEX7
#define CLSR7
static L15(int, object);
#define VT8
#define VLEX8
#define CLSR8
static L16(int, object);
#define VT9
#define VLEX9
#define CLSR9
static L17(int, object);
#define VT10
#define VLEX10
#define CLSR10
static L18(int, object);
#define VT11
#define VLEX11
#define CLSR11
static L19(int, object);
#define VT12
#define VLEX12
#define CLSR12
static L20(int, object);
#define VT13
#define VLEX13
#define CLSR13
static struct codeblock Cblock;
#define VM13 0
#define VM12 0
#define VM11 0
#define VM10 0
#define VM9 0
#define VM8 0
#define VM7 0
#define VM6 2
#define VM5 2
#define VM4 2
#define VM3 0
#define VM2 0
#define VM1 50
static object VV[50];
static LKF0(int, ...);
static (*LK0)(int, ...)=LKF0;
static LKF1(int, ...);
static (*LK1)(int, ...)=LKF1;
static LKF2(int, ...);
static (*LK2)(int, ...)=LKF2;
static LKF3(int, ...);
static (*LK3)(int, ...)=LKF3;
static LKF4(int, ...);
static (*LK4)(int, ...)=LKF4;
static LKF5(int, ...);
static (*LK5)(int, ...)=LKF5;
static LKF6(int, ...);
static (*LK6)(int, ...)=LKF6;
static LKF7(int, ...);
static (*LK7)(int, ...)=LKF7;
static LKF8(int, ...);
static (*LK8)(int, ...)=LKF8;
static LKF9(int, ...);
static (*LK9)(int, ...)=LKF9;
static LKF10(int, ...);
static (*LK10)(int, ...)=LKF10;
static LKF11(int, ...);
static (*LK11)(int, ...)=LKF11;
static LKF12(int, ...);
static (*LK12)(int, ...)=LKF12;
static LKF13(int, ...);
static (*LK13)(int, ...)=LKF13;
