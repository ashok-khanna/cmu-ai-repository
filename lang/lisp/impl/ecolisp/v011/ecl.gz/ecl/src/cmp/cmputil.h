
/* (c) Copyright G. Attardi, 1993. */
int siLAmake_constant();
#define VT2
#define VLEX2
#define CLSR2
static L1(int, object, ...);
int Lformat();
int Lapply();
#define VT3
#define VLEX3
#define CLSR3
static L2(int, object, object, object);
int Lformat();
#define VT4
#define VLEX4
#define CLSR4
static L3(int, object, object, object);
int Lformat();
#define VT5
#define VLEX5
#define CLSR5
static L4(int, object, ...);
int Lformat();
int Lapply();
#define VT6
#define VLEX6
#define CLSR6
static L5(int, object, ...);
int Lformat();
int Lapply();
#define VT7
#define VLEX7
#define CLSR7
static L6(int);
int Lformat();
int Lformat();
#define VT8
#define VLEX8
#define CLSR8
static L7(int, object);
int Lformat();
#define VT9
#define VLEX9
#define CLSR9
static L8(int, object);
int Lformat();
#define VT10
#define VLEX10
#define CLSR10
static L9(int);
int Lformat();
#define VT11
#define VLEX11
#define CLSR11
static L10(int, object);
int Lformat();
#define VT12
#define VLEX12
#define CLSR12
static L11(int, object);
int Lformat();
#define VT13
#define VLEX13
#define CLSR13
static L12(int, object);
int Lformat();
#define VT14
#define VLEX14
#define CLSR14
static L13(int, object, object, object);
int Lformat();
#define VT15
#define VLEX15
#define CLSR15
static L14(int, object);
int siLihs_top();
int Lfind_package();
int Leval();
#define VT16
#define VLEX16
#define CLSR16
static L15(int, object);
int siLunlink_symbol();
#define VT17
#define VLEX17
#define CLSR17
static struct codeblock Cblock;
#define VM17 0
#define VM16 0
#define VM15 0
#define VM14 0
#define VM13 0
#define VM12 0
#define VM11 0
#define VM10 0
#define VM9 0
#define VM8 0
#define VM7 0
#define VM6 0
#define VM5 0
#define VM4 0
#define VM3 0
#define VM2 0
#define VM1 72
static object VV[72];
static LKF0(int, ...);
static (*LK0)(int, ...)=LKF0;
