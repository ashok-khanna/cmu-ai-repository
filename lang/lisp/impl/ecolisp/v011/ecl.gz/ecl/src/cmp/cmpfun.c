
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "cmpfun.h"
init_cmpfun(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_cmpfun; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	VV[0]->s.s_stype=(short)stp_special;
	if(VV[0]->s.s_dbind == OBJNULL){
	(VV[0]->s.s_dbind)= MAKE_FIXNUM(80);}
	MF0(VV[145],L1);
	MF0(VV[147],L2);
	MF0(VV[148],L3);
	MF0(VV[149],L4);
	MF0(VV[150],L5);
	MF0(VV[186],L6);
	MF0(VV[151],L7);
	MF0(VV[152],L8);
	MF0(VV[153],L9);
	MF0(VV[154],L10);
	MF0(VV[155],L11);
	MF0(VV[156],L12);
	MF0(VV[157],L13);
	MF0(VV[158],L14);
	MF0(VV[159],L15);
	MF0(VV[162],L16);
	MF0(VV[164],L17);
	MF0(VV[165],L18);
	MF0(VV[166],L19);
	MF0(VV[167],L20);
	MF0(VV[168],L21);
	MF0(VV[170],L22);
	MF0(VV[76],L23);
	MF0(VV[77],L23);
	putprop(VV[76],VV[85],VV[84]);
	putprop(VV[77],VV[86],VV[84]);
	MF0(VV[173],L25);
	MF0(VV[171],L26);
	MF0(VV[175],L28);
	MF0(VV[176],L29);
	MF0(VV[187],L31);
	MF0(VV[177],L32);
	MF0(VV[179],L34);
	putprop(VV[129],CONS(VV[131],getf(VV[129]->s.s_plist,VV[130],Cnil)),VV[130]);
	MF0(VV[184],L35);
	MF0(VV[185],L36);
	MF0(VV[188],L37);
	MF0(VV[180],L38);
	MF0(VV[182],L39);
	putprop(VV[1],VV[145],VV[144]);
	putprop(VV[1],VV[147],VV[146]);
	putprop(VV[8],VV[148],VV[144]);
	putprop(VV[15],VV[149],VV[144]);
	putprop(VV[17],VV[150],VV[146]);
	putprop(VV[35],VV[151],VV[144]);
	putprop(VV[36],VV[152],VV[144]);
	putprop(VV[36],VV[153],VV[146]);
	putprop(VV[39],VV[154],VV[144]);
	putprop(VV[39],VV[155],VV[146]);
	putprop(VV[40],VV[156],VV[144]);
	putprop(VV[41],VV[157],VV[146]);
	putprop(VV[49],VV[158],VV[144]);
	putprop(VV[50],VV[159],VV[146]);
	putprop(VV[160],VV[162],VV[161]);
	putprop(VV[163],VV[164],VV[161]);
	putprop(VV[72],VV[165],VV[144]);
	putprop(VV[73],VV[166],VV[146]);
	putprop(VV[75],VV[167],VV[144]);
	putprop(VV[74],VV[168],VV[146]);
	putprop(VV[169],VV[170],VV[161]);
	putprop(VV[87],VV[171],VV[146]);
	putprop(VV[172],VV[173],VV[161]);
	putprop(VV[174],VV[175],VV[161]);
	putprop(VV[121],VV[176],VV[161]);
	putprop(VV[42],VV[177],VV[161]);
	putprop(VV[178],VV[179],VV[161]);
	putprop(VV[142],VV[180],VV[144]);
	putprop(VV[181],VV[182],VV[161]);
	putprop(VV[183],VV[184],VV[161]);
	putprop(VV[139],VV[185],VV[161]);
}
/*	function definition for C1PRINC                               */
static L1(int narg, object V1)
{ VT3 VLEX3 CLSR3
TTL:
	{register object V2;                      /*  STREAM          */
	register object V3;                       /*  INFO            */
	V2= Cnil;
	(*LK0)(0)                                 /*  MAKE-INFO       */;
	V3= VALUES(0);
	if(!((V1)==Cnil)){
	goto L38;}
	(*LK1)(3,VV[1],MAKE_FIXNUM(1),MAKE_FIXNUM(0))/*  TOO-FEW-ARGS */;
L38:
	if(CDR((V1))==Cnil){
	goto L41;}
	if(CDDR((V1))==Cnil){
	goto L41;}
	(*LK2)(3,VV[1],MAKE_FIXNUM(2),MAKE_FIXNUM(length((V1))))/*  TOO-MANY-ARGS*/;
L41:
	if(!(CDR((V1))==Cnil)){
	goto L49;}
	(*LK3)(0)                                 /*  C1NIL           */;
	V2= VALUES(0);
	goto L47;
L49:
	(*LK4)(2,CADR((V1)),(V3))                 /*  C1EXPR*         */;
	V2= VALUES(0);
L47:
	if(!(type_of(CAR((V1)))==t_string)){
	goto L54;}
	if(number_compare(MAKE_FIXNUM(length(CAR((V1)))),(VV[0]->s.s_dbind))<=0){
	goto L53;}
L54:
	if(!(CHARACTERP(CAR((V1))))){
	goto L52;}
L53:
	if(CDR((V1))==Cnil){
	goto L51;}
	if(!((CAR((V2)))==(VV[2]))){
	goto L52;}
	if((memq((CAR(CADDR((V2))))->v.v_self[4],VV[3]))==Cnil){
	goto L52;}
L51:
	{object V4= CAR((V1));
	if(!(CDR((V1))==Cnil)){
	goto L66;}
	VALUES(0) = Cnil;
	goto L64;
L66:
	VALUES(0) = (CAADDR((V2)))->v.v_self[5];
L64:
	VALUES(0) = list(5,VV[1],(V3),V4,VALUES(0),(V2));
	RETURN(1);}
L52:
	(*LK4)(2,CAR((V1)),(V3))                  /*  C1EXPR*         */;
	VALUES(0) = list(4,VV[4],(V3),VV[1],list(2,VALUES(0),(V2)));
	RETURN(1);
	}
}
/*	function definition for C2PRINC                               */
static L2(int narg, object V1, object V2, object V3)
{ VT4 VLEX4 CLSR4
TTL:
	if(!(((VV[5]->s.s_dbind))==(VV[6]))){
	goto L70;}
	if(!(CHARACTERP((V1)))){
	goto L74;}
	(*LK5)(1,code_char('\12'))                /*  WT1             */;
	(*LK5)(1,code_char('\11'))                /*  WT1             */;
	princ_str("princ_char(",symbol_value(VV[7]));
	Lchar_code(1,(V1))                        /*  CHAR-CODE       */;
	(*LK5)(1,VALUES(0))                       /*  WT1             */;
	if(((V2))!=Cnil){
	goto L84;}
	princ_str(",Cnil",symbol_value(VV[7]));
	goto L82;
L84:
	princ_str(",symbol_value(VV[",symbol_value(VV[7]));
	(*LK5)(1,(V2))                            /*  WT1             */;
	princ_str("])",symbol_value(VV[7]));
L82:
	princ_str(");",symbol_value(VV[7]));
	goto L72;
L74:
	if(!((length((V1)))==(1))){
	goto L92;}
	(*LK5)(1,code_char('\12'))                /*  WT1             */;
	(*LK5)(1,code_char('\11'))                /*  WT1             */;
	princ_str("princ_char(",symbol_value(VV[7]));
	Lchar_code(1,aref1((V1),0))               /*  CHAR-CODE       */;
	(*LK5)(1,VALUES(0))                       /*  WT1             */;
	if(((V2))!=Cnil){
	goto L102;}
	princ_str(",Cnil",symbol_value(VV[7]));
	goto L100;
L102:
	princ_str(",symbol_value(VV[",symbol_value(VV[7]));
	(*LK5)(1,(V2))                            /*  WT1             */;
	princ_str("])",symbol_value(VV[7]));
L100:
	princ_str(");",symbol_value(VV[7]));
	goto L72;
L92:
	(*LK5)(1,code_char('\12'))                /*  WT1             */;
	(*LK5)(1,code_char('\11'))                /*  WT1             */;
	princ_str("princ_str(\"",symbol_value(VV[7]));
	{object V4;
	register int V5;                          /*  N               */
	V4= MAKE_FIXNUM(length((V1)));
	V5= 0;
L117:
	if(!((V5)>=(fix((V4))))){
	goto L118;}
	goto L113;
L118:
	{register unsigned char V7;               /*  CHAR            */
	V7= ((V1))->ust.ust_self[V5];
	if(!((V7)==(92))){
	goto L124;}
	princ_str("\\\\",symbol_value(VV[7]));
	goto L121;
L124:
	if(!((V7)==(34))){
	goto L128;}
	princ_str("\\\"",symbol_value(VV[7]));
	goto L121;
L128:
	if(!((V7)==(10))){
	goto L132;}
	princ_str("\\n",symbol_value(VV[7]));
	goto L121;
L132:
	(*LK5)(1,code_char(V7))                   /*  WT1             */;
	}
L121:
	V5= (V5)+1;
	goto L117;
	}
L113:
	princ_str("\",",symbol_value(VV[7]));
	if(((V2))!=Cnil){
	goto L143;}
	princ_str("Cnil",symbol_value(VV[7]));
	goto L141;
L143:
	princ_str("symbol_value(VV[",symbol_value(VV[7]));
	(*LK5)(1,(V2))                            /*  WT1             */;
	princ_str("])",symbol_value(VV[7]));
L141:
	princ_str(");",symbol_value(VV[7]));
L72:
	RETURN((*LK6)(1,Cnil)                     /*  UNWIND-EXIT     */);
L70:
	{object V4;
	if(CHARACTERP((V1))){
	goto L153;}
	goto L151;
L153:
	if(!((10)==(char_code((V1))))){
	goto L151;}
	}
	RETURN((*LK7)(4,VV[8],CONS((V3),Cnil),Cnil,Ct)/*  C2CALL-GLOBAL*/);
L151:
	if(!(CHARACTERP((V1)))){
	goto L157;}
	VALUES(0) = VV[11];
	goto L155;
L157:
	VALUES(0) = VV[12];
L155:
	(*LK0)(2,VV[10],VALUES(0))                /*  MAKE-INFO       */;
	T0= VALUES(0);
	(*LK8)(1,(V1))                            /*  ADD-OBJECT      */;
	RETURN((*LK7)(4,VV[1],list(2,list(3,VV[9],T0,list(2,VV[13],VALUES(0))),(V3)),Cnil,Ct)/*  C2CALL-GLOBAL*/);
}
/*	function definition for C1TERPRI                              */
static L3(int narg, object V1)
{ VT5 VLEX5 CLSR5
TTL:
	{register object V2;                      /*  STREAM          */
	object V3;                                /*  INFO            */
	V2= Cnil;
	(*LK0)(0)                                 /*  MAKE-INFO       */;
	V3= VALUES(0);
	if((V1)==Cnil){
	goto L163;}
	if(CDR((V1))==Cnil){
	goto L163;}
	(*LK2)(3,VV[8],MAKE_FIXNUM(1),MAKE_FIXNUM(length((V1))))/*  TOO-MANY-ARGS*/;
L163:
	if(!((V1)==Cnil)){
	goto L171;}
	(*LK3)(0)                                 /*  C1NIL           */;
	V2= VALUES(0);
	goto L169;
L171:
	(*LK4)(2,CAR((V1)),(V3))                  /*  C1EXPR*         */;
	V2= VALUES(0);
L169:
	if((V1)==Cnil){
	goto L173;}
	if(!((CAR((V2)))==(VV[2]))){
	goto L174;}
	if((memq((CAR(CADDR((V2))))->v.v_self[4],VV[14]))==Cnil){
	goto L174;}
L173:
	if(!((V1)==Cnil)){
	goto L182;}
	VALUES(0) = Cnil;
	goto L180;
L182:
	VALUES(0) = (CAADDR((V2)))->v.v_self[5];
L180:
	VALUES(0) = list(5,VV[1],(V3),code_char('\12'),VALUES(0),(V2));
	RETURN(1);
L174:
	VALUES(0) = list(4,VV[4],(V3),VV[8],CONS((V2),Cnil));
	RETURN(1);
	}
}
/*	function definition for C1APPLY                               */
static L4(int narg, object V1)
{ VT6 VLEX6 CLSR6
TTL:
	{register object V2;                      /*  INFO            */
	V2= Cnil;
	if((V1)==Cnil){
	goto L186;}
	if(!(CDR((V1))==Cnil)){
	goto L185;}
L186:
	(*LK1)(3,VV[15],MAKE_FIXNUM(2),MAKE_FIXNUM(length((V1))))/*  TOO-FEW-ARGS*/;
L185:
	{object V3;                               /*  FUN             */
	register object V4;                       /*  FUNOB           */
	object V5;                                /*  LAMBDA-EXPR     */
	register object V6;                       /*  LAMBDA-LIST     */
	V3= CAR((V1));
	(*LK9)(1,(V3))                            /*  C1FUNOB         */;
	V4= VALUES(0);
	V5= Cnil;
	V6= Cnil;
	V2= CADR((V4));
	(*LK10)(2,CDR((V1)),(V2))                 /*  C1ARGS          */;
	V1= VALUES(0);
	if(!((CAR((V4)))==(VV[16]))){
	goto L199;}
	V5= CADDR((V4));
	V6= CADDR((V5));
	if((CADR((V6)))!=Cnil){
	goto L199;}
	if((CADDDR((V6)))!=Cnil){
	goto L199;}
	{object V7= CAR((V6));
	{object V8= CADDR((V6));
	Lfifth(1,(V5))                            /*  FIFTH           */;
	RETURN(L6(5,(V2),V7,V8,VALUES(0),(V1))    /*  C1APPLY-OPTIMIZE*/);}}
L199:
	{object V9= CAR((V4));
	if((V9!= VV[200]))goto L208;
	VALUES(0) = list(4,VV[4],(V2),VV[15],CONS(CADDR((V4)),(V1)));
	RETURN(1);
L208:
	if((V9!= VV[4]))goto L209;
	(*LK11)(1,CDR((V3)))                      /*  C1FUNCTION      */;
	VALUES(0) = list(4,VV[4],(V2),VV[15],CONS(VALUES(0),(V1)));
	RETURN(1);
L209:
	if((V9!= VV[16])
	&& (V9!= VV[202]))goto L211;
	VALUES(0) = list(4,VV[17],(V2),(V4),(V1));
	RETURN(1);
L211:
	VALUES(0) = Cnil;
	RETURN(1);}
	}
	}
}
/*	function definition for C2APPLY-LAMBDA/LOCAL                  */
static L5(int narg, object V1, object V2)
{ VT7 VLEX7 CLSR7
	bds_check;
TTL:
	{object V3;                               /*  LOC             */
	object V4;                                /*  TEMP            */
	register object V5;                       /*  ARG             */
	register object V6;                       /*  NARG            */
	object V7;                                /*  IS-LAMBDA       */
	(*LK12)(1,(V1))                           /*  SAVE-FUNOB      */;
	V3= VALUES(0);
	V4= (VV[18]->s.s_dbind);
	bds_bind(VV[18],(V4));                    /*  *TEMP*          */
	V5= list(2,VV[19],MAKE_FIXNUM(0));
	(*LK13)(0)                                /*  NEXT-LCL        */;
	V6= list(2,VV[20],VALUES(0));
	V7= ((VV[16])==(CAR((V1)))?Ct:Cnil);
	(*LK5)(1,code_char('\12'))                /*  WT1             */;
	(*LK5)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{ int ",symbol_value(VV[7]));
	(*LK5)(1,(V6))                            /*  WT1             */;
	princ_str(", i=0;",symbol_value(VV[7]));
	{register object V8;
	object V9;                                /*  EXPR            */
	V8= (V2);
	V9= Cnil;
L228:
	if(!((V8)==Cnil)){
	goto L229;}
	goto L224;
L229:
	V9= CAR((V8));
	{object V11;
	(*LK14)(0)                                /*  NEXT-TEMP       */;
	V11= VALUES(0);
	CAR(CDR((V5))) = (V11);
	}
	bds_bind(VV[5],(V5));                     /*  *DESTINATION*   */
	(*LK15)(1,(V9))                           /*  C2EXPR*         */;
	bds_unwind1;
	V8= CDR((V8));
	goto L228;
	}
L224:
	(*LK5)(1,code_char('\12'))                /*  WT1             */;
	(*LK5)(1,code_char('\11'))                /*  WT1             */;
	(*LK5)(1,(V6))                            /*  WT1             */;
	princ_str("=length(",symbol_value(VV[7]));
	(*LK5)(1,(V5))                            /*  WT1             */;
	princ_str(");",symbol_value(VV[7]));
	CAR(CDR((V5))) = (V4);
	if(((V7))!=Cnil){
	goto L250;}
	{object V8;                               /*  FUN             */
	object V9;                                /*  LEX-LVL         */
	object V10;                               /*  CLOSURE-LVL     */
	V8= CADDR((V1));
	V9= ((V8))->v.v_self[5];
	if((((V8))->v.v_self[7])==Cnil){
	goto L257;}
	{object V11= (VV[21]->s.s_dbind);
	V10= number_minus(V11,((V8))->v.v_self[6]);
	goto L255;}
L257:
	V10= Cnil;
L255:
	if(!(number_compare(MAKE_FIXNUM(0),(V9))<0)){
	goto L259;}
	{register int V11;                        /*  N               */
	V11= 0;
L264:
	if(!(number_compare(MAKE_FIXNUM(V11),(V9))>=0)){
	goto L265;}
	goto L259;
L265:
	(*LK5)(1,code_char('\12'))                /*  WT1             */;
	(*LK5)(1,code_char('\11'))                /*  WT1             */;
	princ_str("VALUES(i++)=(object)lex",symbol_value(VV[7]));
	(*LK5)(1,MAKE_FIXNUM(V11))                /*  WT1             */;
	princ_char(59,symbol_value(VV[7]));
	V11= (V11)+1;
	goto L264;
	}
L259:
	if(((V10))==Cnil){
	goto L250;}
	(*LK5)(1,code_char('\12'))                /*  WT1             */;
	(*LK5)(1,code_char('\11'))                /*  WT1             */;
	princ_str("VALUES(i++)=(object)env",symbol_value(VV[7]));
	(*LK5)(1,(VV[22]->s.s_dbind))             /*  WT1             */;
	princ_char(59,symbol_value(VV[7]));
	}
L250:
	{object V8;
	register int V9;                          /*  I               */
	V8= one_minus(MAKE_FIXNUM(length((V2))));
	V9= 0;
L288:
	if(!(number_compare(MAKE_FIXNUM(V9),(V8))>=0)){
	goto L289;}
	goto L284;
L289:
	(*LK5)(1,code_char('\12'))                /*  WT1             */;
	(*LK5)(1,code_char('\11'))                /*  WT1             */;
	princ_str("VALUES(i++)=",symbol_value(VV[7]));
	(*LK5)(1,(V5))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[7]));
	{object V11;
	V11= number_plus(CADR((V5)),MAKE_FIXNUM(1));
	CAR(CDR((V5))) = (V11);
	}
	V9= (V9)+1;
	goto L288;
	}
L284:
	(*LK5)(1,code_char('\12'))                /*  WT1             */;
	(*LK5)(1,code_char('\11'))                /*  WT1             */;
	(*LK5)(1,(V6))                            /*  WT1             */;
	princ_str("+=i;",symbol_value(VV[7]));
	(*LK5)(1,code_char('\12'))                /*  WT1             */;
	(*LK5)(1,code_char('\11'))                /*  WT1             */;
	princ_str("for (; i<",symbol_value(VV[7]));
	(*LK5)(1,(V6))                            /*  WT1             */;
	princ_str(";i++,",symbol_value(VV[7]));
	(*LK5)(1,(V5))                            /*  WT1             */;
	princ_str("=CDR(",symbol_value(VV[7]));
	(*LK5)(1,(V5))                            /*  WT1             */;
	princ_str("))",symbol_value(VV[7]));
	(*LK5)(1,code_char('\12'))                /*  WT1             */;
	(*LK5)(1,code_char('\11'))                /*  WT1             */;
	princ_str("	VALUES(i)=CAR(",symbol_value(VV[7]));
	(*LK5)(1,(V5))                            /*  WT1             */;
	princ_str(");",symbol_value(VV[7]));
	if(((V7))==Cnil){
	goto L327;}
	(*LK16)(4,(V1),VV[23],(V3),(V6))          /*  C2FUNCALL       */;
	goto L325;
L327:
	(*LK17)(3,CDDR((V1)),VV[23],(V6))         /*  C2CALL-LOCAL    */;
L325:
	(*LK5)(1,code_char('\12'))                /*  WT1             */;
	(*LK5)(1,code_char('\11'))                /*  WT1             */;
	princ_char(125,symbol_value(VV[7]));
	{int V8;
	VALUES(0)=Cnil;
	V8=1;
	bds_unwind1;
	RETURN(V8);}
	}
}
/*	function definition for C1APPLY-OPTIMIZE                      */
static L6(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT8 VLEX8 CLSR8
	bds_check;
TTL:
	{register object V6;                      /*  VL              */
	register object V7;                       /*  FL              */
	V6= Cnil;
	V7= Cnil;
L336:
	if(CDR((V5))==Cnil){
	goto L338;}
	if(!((V2)==Cnil)){
	goto L337;}
L338:
	goto L334;
L337:
	{object V9;
	V9= CAR((V2));
	V2= CDR((V2));
	VALUES(0) = (V9);
	}
	V6= CONS(VALUES(0),(V6));
	{object V9;
	V9= CAR((V5));
	V5= CDR((V5));
	VALUES(0) = (V9);
	}
	V7= CONS(VALUES(0),(V7));
	goto L336;
L334:
	if((CDR((V5)))==Cnil){
	goto L357;}
	if(((V3))!=Cnil){
	goto L359;}
	(*LK18)(1,VV[24])                         /*  CMPERR          */;
L359:
	V6= CONS((V3),(V6));
	V7= CONS(list(4,VV[4],(V1),VV[25],(V5)),(V7));
	{object V8= nreverse((V6));
	{object V9= nreverse((V7));
	VALUES(0) = list(5,VV[26],(V1),V8,V9,(V4));
	RETURN(1);}}
L357:
	{object V10;
	object V11;                               /*  TEMP            */
	V10= (VV[27]->s.s_dbind);
	if((V3)!=Cnil){
	V11= (V3);
	goto L367;}
	Lgensym(0)                                /*  GENSYM          */;
	T0= VALUES(0);
	(*LK19)(6,VV[28],T0,VV[29],VV[30],VV[31],MAKE_FIXNUM(length((V5))))/*  MAKE-VAR*/;
	V11= VALUES(0);
L367:
	bds_bind(VV[27],V10);                     /*  *VARS*          */
	(VV[27]->s.s_dbind)= CONS((V11),(VV[27]->s.s_dbind));
	V6= CONS((V11),(V6));
	V7= CONS(CAR((V5)),(V7));
	{object V12= nreverse((V6));
	{object V13= nreverse((V7));
	{object V14= CADR((V4));
	{int V15= length((V2));
	(*LK20)(1,list(2,VV[34],((V11))->v.v_self[0]))/*  C1EXPR      */;
	Lmake_list(3,MAKE_FIXNUM(V15),VV[33],VALUES(0))/*  MAKE-LIST  */;
	{int V16;
	VALUES(0)=list(5,VV[26],(V1),V12,V13,list(5,VV[32],V14,(V2),VALUES(0),(V4)));
	V16=1;
	bds_unwind1;
	RETURN(V16);}}}}}
	}
	}
}
/*	function definition for C1FUNCALL                             */
static L7(int narg, object V1)
{ VT9 VLEX9 CLSR9
TTL:
	{object V2;                               /*  FUNOB           */
	object V3;                                /*  INFO            */
	V2= Cnil;
	(*LK0)(0)                                 /*  MAKE-INFO       */;
	V3= VALUES(0);
	if(!((V1)==Cnil)){
	goto L379;}
	(*LK1)(3,VV[35],MAKE_FIXNUM(1),MAKE_FIXNUM(0))/*  TOO-FEW-ARGS*/;
L379:
	(*LK9)(1,CAR((V1)))                       /*  C1FUNOB         */;
	V2= VALUES(0);
	(*LK21)(2,(V3),CADR((V2)))                /*  ADD-INFO        */;
	(*LK10)(2,CDR((V1)),(V3))                 /*  C1ARGS          */;
	VALUES(0) = list(4,VV[35],(V3),(V2),VALUES(0));
	RETURN(1);
	}
}
/*	function definition for C1RPLACA                              */
static L8(int narg, object V1)
{ VT10 VLEX10 CLSR10
TTL:
	{object V2;                               /*  INFO            */
	(*LK0)(0)                                 /*  MAKE-INFO       */;
	V2= VALUES(0);
	if((V1)==Cnil){
	goto L388;}
	if(!(CDR((V1))==Cnil)){
	goto L387;}
L388:
	(*LK1)(3,VV[36],MAKE_FIXNUM(2),MAKE_FIXNUM(length((V1))))/*  TOO-FEW-ARGS*/;
L387:
	if(CDDR((V1))==Cnil){
	goto L392;}
	(*LK2)(3,VV[36],MAKE_FIXNUM(2),MAKE_FIXNUM(length((V1))))/*  TOO-MANY-ARGS*/;
L392:
	(*LK10)(2,(V1),(V2))                      /*  C1ARGS          */;
	V1= VALUES(0);
	VALUES(0) = list(3,VV[36],(V2),(V1));
	RETURN(1);
	}
}
/*	function definition for C2RPLACA                              */
static L9(int narg, object V1)
{ VT11 VLEX11 CLSR11
	bds_check;
TTL:
	{register object V2;                      /*  X               */
	object V3;                                /*  Y               */
	bds_bind(VV[37],MAKE_FIXNUM(0));          /*  *INLINE-BLOCKS* */
	V2= Cnil;
	V3= Cnil;
	(*LK22)(1,(V1))                           /*  INLINE-ARGS     */;
	V1= VALUES(0);
	V2= CADR(CAR((V1)));
	V3= CADR(CADR((V1)));
	if(((VV[38]->s.s_dbind))==Cnil){
	goto L405;}
	(*LK5)(1,code_char('\12'))                /*  WT1             */;
	(*LK5)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(type_of(",symbol_value(VV[7]));
	(*LK5)(1,(V2))                            /*  WT1             */;
	princ_str(")!=t_cons)",symbol_value(VV[7]));
	princ_str("FEwrong_type_argument(Scons,",symbol_value(VV[7]));
	(*LK5)(1,(V2))                            /*  WT1             */;
	princ_str(");",symbol_value(VV[7]));
L405:
	(*LK5)(1,code_char('\12'))                /*  WT1             */;
	(*LK5)(1,code_char('\11'))                /*  WT1             */;
	princ_str("CAR(",symbol_value(VV[7]));
	(*LK5)(1,(V2))                            /*  WT1             */;
	princ_str(") = ",symbol_value(VV[7]));
	(*LK5)(1,(V3))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[7]));
	(*LK6)(1,(V2))                            /*  UNWIND-EXIT     */;
	{int V4;
	V4=(*LK23)(0)                             /*  CLOSE-INLINE-BLOCKS*/;
	bds_unwind1;
	RETURN(V4);}
	}
}
/*	function definition for C1RPLACD                              */
static L10(int narg, object V1)
{ VT12 VLEX12 CLSR12
TTL:
	{object V2;                               /*  INFO            */
	(*LK0)(0)                                 /*  MAKE-INFO       */;
	V2= VALUES(0);
	if((V1)==Cnil){
	goto L427;}
	if(!(CDR((V1))==Cnil)){
	goto L426;}
L427:
	(*LK1)(3,VV[39],MAKE_FIXNUM(2),MAKE_FIXNUM(length((V1))))/*  TOO-FEW-ARGS*/;
L426:
	if(CDDR((V1))==Cnil){
	goto L431;}
	(*LK2)(3,VV[39],MAKE_FIXNUM(2),MAKE_FIXNUM(length((V1))))/*  TOO-MANY-ARGS*/;
L431:
	(*LK10)(2,(V1),(V2))                      /*  C1ARGS          */;
	V1= VALUES(0);
	VALUES(0) = list(3,VV[39],(V2),(V1));
	RETURN(1);
	}
}
/*	function definition for C2RPLACD                              */
static L11(int narg, object V1)
{ VT13 VLEX13 CLSR13
	bds_check;
TTL:
	{register object V2;                      /*  X               */
	object V3;                                /*  Y               */
	bds_bind(VV[37],MAKE_FIXNUM(0));          /*  *INLINE-BLOCKS* */
	V2= Cnil;
	V3= Cnil;
	(*LK22)(1,(V1))                           /*  INLINE-ARGS     */;
	V1= VALUES(0);
	V2= CADR(CAR((V1)));
	V3= CADR(CADR((V1)));
	if(((VV[38]->s.s_dbind))==Cnil){
	goto L444;}
	(*LK5)(1,code_char('\12'))                /*  WT1             */;
	(*LK5)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(type_of(",symbol_value(VV[7]));
	(*LK5)(1,(V2))                            /*  WT1             */;
	princ_str(")!=t_cons)",symbol_value(VV[7]));
	princ_str("FEwrong_type_argument(Scons,",symbol_value(VV[7]));
	(*LK5)(1,(V2))                            /*  WT1             */;
	princ_str(");",symbol_value(VV[7]));
L444:
	(*LK5)(1,code_char('\12'))                /*  WT1             */;
	(*LK5)(1,code_char('\11'))                /*  WT1             */;
	princ_str("CDR(",symbol_value(VV[7]));
	(*LK5)(1,(V2))                            /*  WT1             */;
	princ_str(") = ",symbol_value(VV[7]));
	(*LK5)(1,(V3))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[7]));
	(*LK6)(1,(V2))                            /*  UNWIND-EXIT     */;
	{int V4;
	V4=(*LK23)(0)                             /*  CLOSE-INLINE-BLOCKS*/;
	bds_unwind1;
	RETURN(V4);}
	}
}
/*	function definition for C1MEMBER                              */
static L12(int narg, object V1)
{ VT14 VLEX14 CLSR14
TTL:
	{register object V2;                      /*  INFO            */
	(*LK0)(0)                                 /*  MAKE-INFO       */;
	V2= VALUES(0);
	if((V1)==Cnil){
	goto L466;}
	if(!(CDR((V1))==Cnil)){
	goto L465;}
L466:
	(*LK1)(3,VV[40],MAKE_FIXNUM(2),MAKE_FIXNUM(length((V1))))/*  TOO-FEW-ARGS*/;
L465:
	if(!(CDDR((V1))==Cnil)){
	goto L471;}
	(*LK10)(2,(V1),(V2))                      /*  C1ARGS          */;
	VALUES(0) = list(4,VV[41],(V2),VV[42],VALUES(0));
	RETURN(1);
L471:
	if(!((CADDR((V1)))==(VV[43]))){
	goto L475;}
	if(!((length((V1)))==(4))){
	goto L475;}
	if((member(CADDDR((V1)),VV[44]))==Cnil){
	goto L475;}
	{object V3= CADR(CADDDR((V1)));
	(*LK10)(2,list(2,CAR((V1)),CADR((V1))),(V2))/*  C1ARGS        */;
	VALUES(0) = list(4,VV[41],(V2),V3,VALUES(0));
	RETURN(1);}
L475:
	(*LK10)(2,(V1),(V2))                      /*  C1ARGS          */;
	VALUES(0) = list(4,VV[4],(V2),VV[40],VALUES(0));
	RETURN(1);
	}
}
/*	function definition for C2MEMBER!2                            */
static L13(int narg, object V1, object V2)
{ VT15 VLEX15 CLSR15
	bds_check;
TTL:
	bds_bind(VV[37],MAKE_FIXNUM(0));          /*  *INLINE-BLOCKS* */
	(*LK22)(1,(V2))                           /*  INLINE-ARGS     */;
	(*LK24)(2,VALUES(0),Cnil)                 /*  COERCE-LOCS     */;
	V2= VALUES(0);
	if(((V1)!= VV[216]))goto L488;
	VALUES(0) = VV[46];
	goto L487;
L488:
	if(((V1)!= VV[42]))goto L489;
	VALUES(0) = VV[47];
	goto L487;
L489:
	if(((V1)!= VV[217]))goto L490;
	VALUES(0) = VV[48];
	goto L487;
L490:
	VALUES(0) = Cnil;
L487:
	(*LK6)(1,list(4,VV[45],Cnil,VALUES(0),(V2)))/*  UNWIND-EXIT   */;
	{int V3;
	V3=(*LK23)(0)                             /*  CLOSE-INLINE-BLOCKS*/;
	bds_unwind1;
	RETURN(V3);}
}
/*	function definition for C1ASSOC                               */
static L14(int narg, object V1)
{ VT16 VLEX16 CLSR16
TTL:
	{register object V2;                      /*  INFO            */
	(*LK0)(0)                                 /*  MAKE-INFO       */;
	V2= VALUES(0);
	if((V1)==Cnil){
	goto L493;}
	if(!(CDR((V1))==Cnil)){
	goto L492;}
L493:
	(*LK1)(3,VV[49],MAKE_FIXNUM(2),MAKE_FIXNUM(length((V1))))/*  TOO-FEW-ARGS*/;
L492:
	if(!(CDDR((V1))==Cnil)){
	goto L498;}
	(*LK10)(2,(V1),(V2))                      /*  C1ARGS          */;
	VALUES(0) = list(4,VV[50],(V2),VV[42],VALUES(0));
	RETURN(1);
L498:
	if(!((CADDR((V1)))==(VV[43]))){
	goto L502;}
	if(!((length((V1)))==(4))){
	goto L502;}
	if((member(CADDDR((V1)),VV[51]))==Cnil){
	goto L502;}
	{object V3= CADR(CADDDR((V1)));
	(*LK10)(2,list(2,CAR((V1)),CADR((V1))),(V2))/*  C1ARGS        */;
	VALUES(0) = list(4,VV[50],(V2),V3,VALUES(0));
	RETURN(1);}
L502:
	(*LK10)(2,(V1),(V2))                      /*  C1ARGS          */;
	VALUES(0) = list(4,VV[4],(V2),VV[49],VALUES(0));
	RETURN(1);
	}
}
/*	function definition for C2ASSOC!2                             */
static L15(int narg, object V1, object V2)
{ VT17 VLEX17 CLSR17
	bds_check;
TTL:
	bds_bind(VV[37],MAKE_FIXNUM(0));          /*  *INLINE-BLOCKS* */
	(*LK22)(1,(V2))                           /*  INLINE-ARGS     */;
	(*LK24)(2,VALUES(0),Cnil)                 /*  COERCE-LOCS     */;
	V2= VALUES(0);
	if(((V1)!= VV[216]))goto L515;
	VALUES(0) = VV[52];
	goto L514;
L515:
	if(((V1)!= VV[42]))goto L516;
	VALUES(0) = VV[53];
	goto L514;
L516:
	if(((V1)!= VV[217]))goto L517;
	VALUES(0) = VV[54];
	goto L514;
L517:
	if(((V1)!= VV[218]))goto L518;
	VALUES(0) = VV[55];
	goto L514;
L518:
	VALUES(0) = Cnil;
L514:
	(*LK6)(1,list(4,VV[45],Cnil,VALUES(0),(V2)))/*  UNWIND-EXIT   */;
	{int V3;
	V3=(*LK23)(0)                             /*  CLOSE-INLINE-BLOCKS*/;
	bds_unwind1;
	RETURN(V3);}
}
/*	function definition for CO1NTH                                */
static L16(int narg, object V1)
{ VT18 VLEX18 CLSR18
TTL:
	if((((V1)==Cnil?Ct:Cnil))==Cnil){
	goto L519;}
	VALUES(0) = Cnil;
	RETURN(1);
L519:
	if(((CDR((V1))==Cnil?Ct:Cnil))==Cnil){
	goto L521;}
	VALUES(0) = Cnil;
	RETURN(1);
L521:
	if(CDDR((V1))==Cnil){
	goto L523;}
	VALUES(0) = Cnil;
	RETURN(1);
L523:
	if(numberp(CAR((V1)))){
	goto L525;}
	VALUES(0) = Cnil;
	RETURN(1);
L525:
	Lmonotonically_nondecreasing(3,MAKE_FIXNUM(0),CAR((V1)),MAKE_FIXNUM(7))/*  <=*/;
	if(VALUES(0)!=Cnil){
	goto L527;}
	VALUES(0) = Cnil;
	RETURN(1);
L527:
	{object V2= CAR((V1));
	if(!eql(V2,VV[56]))goto L530;
	VALUES(0) = CONS(VV[57],CDR((V1)));
	goto L529;
L530:
	if(!eql(V2,VV[58]))goto L531;
	VALUES(0) = CONS(VV[59],CDR((V1)));
	goto L529;
L531:
	if(!eql(V2,VV[60]))goto L532;
	VALUES(0) = CONS(VV[61],CDR((V1)));
	goto L529;
L532:
	if(!eql(V2,VV[62]))goto L533;
	VALUES(0) = CONS(VV[63],CDR((V1)));
	goto L529;
L533:
	if(!eql(V2,VV[64]))goto L534;
	VALUES(0) = list(2,VV[57],CONS(VV[65],CDR((V1))));
	goto L529;
L534:
	if(!eql(V2,VV[66]))goto L535;
	VALUES(0) = list(2,VV[59],CONS(VV[65],CDR((V1))));
	goto L529;
L535:
	if(!eql(V2,VV[67]))goto L536;
	VALUES(0) = list(2,VV[61],CONS(VV[65],CDR((V1))));
	goto L529;
L536:
	if(!eql(V2,VV[68]))goto L537;
	VALUES(0) = list(2,VV[63],CONS(VV[65],CDR((V1))));
	goto L529;
L537:
	VALUES(0) = Cnil;}
L529:
	RETURN((*LK20)(1,VALUES(0))               /*  C1EXPR          */);
}
/*	function definition for CO1NTHCDR                             */
static L17(int narg, object V1)
{ VT19 VLEX19 CLSR19
TTL:
	if((((V1)==Cnil?Ct:Cnil))==Cnil){
	goto L538;}
	VALUES(0) = Cnil;
	RETURN(1);
L538:
	if(((CDR((V1))==Cnil?Ct:Cnil))==Cnil){
	goto L540;}
	VALUES(0) = Cnil;
	RETURN(1);
L540:
	if(CDDR((V1))==Cnil){
	goto L542;}
	VALUES(0) = Cnil;
	RETURN(1);
L542:
	if(numberp(CAR((V1)))){
	goto L544;}
	VALUES(0) = Cnil;
	RETURN(1);
L544:
	Lmonotonically_nondecreasing(3,MAKE_FIXNUM(0),CAR((V1)),MAKE_FIXNUM(7))/*  <=*/;
	if(VALUES(0)!=Cnil){
	goto L546;}
	VALUES(0) = Cnil;
	RETURN(1);
L546:
	{object V2= CAR((V1));
	if(!eql(V2,VV[56]))goto L549;
	VALUES(0) = CADR((V1));
	goto L548;
L549:
	if(!eql(V2,VV[58]))goto L550;
	VALUES(0) = CONS(VV[69],CDR((V1)));
	goto L548;
L550:
	if(!eql(V2,VV[60]))goto L551;
	VALUES(0) = CONS(VV[70],CDR((V1)));
	goto L548;
L551:
	if(!eql(V2,VV[62]))goto L552;
	VALUES(0) = CONS(VV[71],CDR((V1)));
	goto L548;
L552:
	if(!eql(V2,VV[64]))goto L553;
	VALUES(0) = CONS(VV[65],CDR((V1)));
	goto L548;
L553:
	if(!eql(V2,VV[66]))goto L554;
	VALUES(0) = list(2,VV[69],CONS(VV[65],CDR((V1))));
	goto L548;
L554:
	if(!eql(V2,VV[67]))goto L555;
	VALUES(0) = list(2,VV[70],CONS(VV[65],CDR((V1))));
	goto L548;
L555:
	if(!eql(V2,VV[68]))goto L556;
	VALUES(0) = list(2,VV[71],CONS(VV[65],CDR((V1))));
	goto L548;
L556:
	VALUES(0) = Cnil;}
L548:
	RETURN((*LK20)(1,VALUES(0))               /*  C1EXPR          */);
}
/*	function definition for C1RPLACA-NTHCDR                       */
static L18(int narg, object V1)
{ VT20 VLEX20 CLSR20
TTL:
	{register object V2;                      /*  INFO            */
	(*LK0)(0)                                 /*  MAKE-INFO       */;
	V2= VALUES(0);
	if((V1)==Cnil){
	goto L559;}
	if(CDR((V1))==Cnil){
	goto L559;}
	if(!(CDDR((V1))==Cnil)){
	goto L558;}
L559:
	(*LK1)(3,VV[72],MAKE_FIXNUM(3),MAKE_FIXNUM(length((V1))))/*  TOO-FEW-ARGS*/;
L558:
	if(CDDDR((V1))==Cnil){
	goto L565;}
	(*LK1)(3,VV[72],MAKE_FIXNUM(3),MAKE_FIXNUM(length((V1))))/*  TOO-FEW-ARGS*/;
L565:
	if(!(numberp(CADR((V1))))){
	goto L569;}
	Lmonotonically_nondecreasing(3,MAKE_FIXNUM(0),CADR((V1)),MAKE_FIXNUM(10))/*  <=*/;
	if(VALUES(0)==Cnil){
	goto L569;}
	{object V3= CADR((V1));
	(*LK10)(2,list(2,CAR((V1)),CADDR((V1))),(V2))/*  C1ARGS       */;
	VALUES(0) = list(4,VV[73],(V2),V3,VALUES(0));
	RETURN(1);}
L569:
	(*LK10)(2,(V1),(V2))                      /*  C1ARGS          */;
	VALUES(0) = list(4,VV[4],(V2),VV[72],VALUES(0));
	RETURN(1);
	}
}
/*	function definition for C2RPLACA-NTHCDR-IMMEDIATE             */
static L19(int narg, object V1, object V2)
{ VT21 VLEX21 CLSR21
	bds_check;
	{register int V3;
	V3= fix(V1);
TTL:
	bds_bind(VV[37],MAKE_FIXNUM(0));          /*  *INLINE-BLOCKS* */
	(*LK22)(1,(V2))                           /*  INLINE-ARGS     */;
	(*LK24)(2,VALUES(0),Cnil)                 /*  COERCE-LOCS     */;
	V2= VALUES(0);
	if(((VV[38]->s.s_dbind))==Cnil){
	goto L580;}
	(*LK5)(1,code_char('\12'))                /*  WT1             */;
	(*LK5)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{object l= ",symbol_value(VV[7]));
	{object V4;
	register int V5;                          /*  I               */
	V4= MAKE_FIXNUM(V3);
	V5= 0;
L590:
	if(!((V5)>=(fix((V4))))){
	goto L591;}
	goto L586;
L591:
	princ_str("cdr(",symbol_value(VV[7]));
	V5= (V5)+1;
	goto L590;
	}
L586:
	(*LK5)(1,CAR((V2)))                       /*  WT1             */;
	{object V4;
	register int V5;                          /*  I               */
	V4= MAKE_FIXNUM(V3);
	V5= 0;
L605:
	if(!((V5)>=(fix((V4))))){
	goto L606;}
	goto L601;
L606:
	princ_char(41,symbol_value(VV[7]));
	V5= (V5)+1;
	goto L605;
	}
L601:
	princ_char(59,symbol_value(VV[7]));
	(*LK5)(1,code_char('\12'))                /*  WT1             */;
	(*LK5)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(type_of(l)!=t_cons)FEwrong_type_argument(Scons,l);",symbol_value(VV[7]));
	(*LK5)(1,code_char('\12'))                /*  WT1             */;
	(*LK5)(1,code_char('\11'))                /*  WT1             */;
	princ_str("CAR(l)= ",symbol_value(VV[7]));
	(*LK5)(1,CADR((V2)))                      /*  WT1             */;
	princ_str(";}",symbol_value(VV[7]));
	goto L578;
L580:
	(*LK5)(1,code_char('\12'))                /*  WT1             */;
	(*LK5)(1,code_char('\11'))                /*  WT1             */;
	princ_str("CAR(",symbol_value(VV[7]));
	{object V4;
	register int V5;                          /*  I               */
	V4= MAKE_FIXNUM(V3);
	V5= 0;
L633:
	if(!((V5)>=(fix((V4))))){
	goto L634;}
	goto L629;
L634:
	princ_str("CDR(",symbol_value(VV[7]));
	V5= (V5)+1;
	goto L633;
	}
L629:
	(*LK5)(1,CAR((V2)))                       /*  WT1             */;
	{object V4;
	register int V5;                          /*  I               */
	V4= MAKE_FIXNUM(V3);
	V5= 0;
L648:
	if(!((V5)>=(fix((V4))))){
	goto L649;}
	goto L644;
L649:
	princ_char(41,symbol_value(VV[7]));
	V5= (V5)+1;
	goto L648;
	}
L644:
	princ_str(")= ",symbol_value(VV[7]));
	(*LK5)(1,CADR((V2)))                      /*  WT1             */;
	princ_char(59,symbol_value(VV[7]));
L578:
	(*LK6)(1,CADR((V2)))                      /*  UNWIND-EXIT     */;
	{int V4;
	V4=(*LK23)(0)                             /*  CLOSE-INLINE-BLOCKS*/;
	bds_unwind1;
	RETURN(V4);}
	}
}
/*	function definition for C1LIST-NTH                            */
static L20(int narg, object V1)
{ VT22 VLEX22 CLSR22
TTL:
	{register object V2;                      /*  INFO            */
	(*LK0)(0)                                 /*  MAKE-INFO       */;
	V2= VALUES(0);
	if((V1)==Cnil){
	goto L663;}
	if(!(CDR((V1))==Cnil)){
	goto L662;}
L663:
	(*LK1)(3,VV[72],MAKE_FIXNUM(2),MAKE_FIXNUM(length((V1))))/*  TOO-FEW-ARGS*/;
L662:
	if(CDDR((V1))==Cnil){
	goto L667;}
	(*LK1)(3,VV[72],MAKE_FIXNUM(2),MAKE_FIXNUM(length((V1))))/*  TOO-FEW-ARGS*/;
L667:
	if(!(numberp(CAR((V1))))){
	goto L671;}
	Lmonotonically_nondecreasing(3,MAKE_FIXNUM(0),CAR((V1)),MAKE_FIXNUM(10))/*  <=*/;
	if(VALUES(0)==Cnil){
	goto L671;}
	{object V3= CAR((V1));
	(*LK10)(2,CONS(CADR((V1)),Cnil),(V2))     /*  C1ARGS          */;
	VALUES(0) = list(4,VV[74],(V2),V3,VALUES(0));
	RETURN(1);}
L671:
	(*LK10)(2,(V1),(V2))                      /*  C1ARGS          */;
	VALUES(0) = list(4,VV[4],(V2),VV[75],VALUES(0));
	RETURN(1);
	}
}
/*	function definition for C2LIST-NTH-IMMEDIATE                  */
static L21(int narg, object V1, object V2)
{ VT23 VLEX23 CLSR23
	bds_check;
	{register int V3;
	V3= fix(V1);
TTL:
	{register object V4;                      /*  L               */
	(*LK13)(0)                                /*  NEXT-LCL        */;
	V4= VALUES(0);
	bds_bind(VV[37],MAKE_FIXNUM(0));          /*  *INLINE-BLOCKS* */
	(*LK22)(1,(V2))                           /*  INLINE-ARGS     */;
	(*LK24)(2,VALUES(0),Cnil)                 /*  COERCE-LOCS     */;
	V2= VALUES(0);
	(*LK5)(1,code_char('\12'))                /*  WT1             */;
	(*LK5)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{object ",symbol_value(VV[7]));
	(*LK25)(1,(V4))                           /*  WT-LCL          */;
	princ_str("= ",symbol_value(VV[7]));
	if(((VV[38]->s.s_dbind))==Cnil){
	goto L690;}
	{object V5;
	register int V6;                          /*  I               */
	V5= MAKE_FIXNUM(V3);
	V6= 0;
L696:
	if(!((V6)>=(fix((V5))))){
	goto L697;}
	goto L692;
L697:
	princ_str("cdr(",symbol_value(VV[7]));
	V6= (V6)+1;
	goto L696;
	}
L692:
	(*LK5)(1,CAR((V2)))                       /*  WT1             */;
	{object V5;
	register int V6;                          /*  I               */
	V5= MAKE_FIXNUM(V3);
	V6= 0;
L711:
	if(!((V6)>=(fix((V5))))){
	goto L712;}
	goto L707;
L712:
	princ_char(41,symbol_value(VV[7]));
	V6= (V6)+1;
	goto L711;
	}
L707:
	princ_char(59,symbol_value(VV[7]));
	(*LK5)(1,code_char('\12'))                /*  WT1             */;
	(*LK5)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(type_of(",symbol_value(VV[7]));
	(*LK25)(1,(V4))                           /*  WT-LCL          */;
	princ_str(")!=t_cons)",symbol_value(VV[7]));
	(*LK5)(1,code_char('\12'))                /*  WT1             */;
	(*LK5)(1,code_char('\11'))                /*  WT1             */;
	princ_str(" FEwrong_type_argument(Scons,",symbol_value(VV[7]));
	(*LK25)(1,(V4))                           /*  WT-LCL          */;
	princ_str(");",symbol_value(VV[7]));
	goto L688;
L690:
	{object V5;
	register int V6;                          /*  I               */
	V5= MAKE_FIXNUM(V3);
	V6= 0;
L739:
	if(!((V6)>=(fix((V5))))){
	goto L740;}
	goto L735;
L740:
	princ_str("CDR(",symbol_value(VV[7]));
	V6= (V6)+1;
	goto L739;
	}
L735:
	(*LK5)(1,CAR((V2)))                       /*  WT1             */;
	{object V5;
	register int V6;                          /*  I               */
	V5= MAKE_FIXNUM(V3);
	V6= 0;
L754:
	if(!((V6)>=(fix((V5))))){
	goto L755;}
	goto L750;
L755:
	princ_char(41,symbol_value(VV[7]));
	V6= (V6)+1;
	goto L754;
	}
L750:
	princ_char(59,symbol_value(VV[7]));
L688:
	(*LK6)(1,list(2,VV[57],(V4)))             /*  UNWIND-EXIT     */;
	princ_char(125,symbol_value(VV[7]));
	{int V5;
	V5=(*LK23)(0)                             /*  CLOSE-INLINE-BLOCKS*/;
	bds_unwind1;
	RETURN(V5);}
	}
	}
}
/*	function definition for CO1ASH                                */
static L22(int narg, object V1)
{ VT24 VLEX24 CLSR24
TTL:
	{register object V2;                      /*  SHAMT           */
	register object V3;                       /*  TYPE            */
	object V4;                                /*  FUN             */
	V2= CADR((V1));
	V3= Cnil;
	V4= Cnil;
	Lconstantp(1,(V2))                        /*  CONSTANTP       */;
	if(VALUES(0)==Cnil){
	goto L772;}
	Leval(1,(V2))                             /*  EVAL            */;
	V2= VALUES(0);
	if(!(FIXNUMP((V2)))){
	goto L772;}
	if(!(number_compare((V2),MAKE_FIXNUM(0))<0)){
	goto L779;}
	V4= VV[76];
	goto L777;
L779:
	V4= VV[77];
L777:
	if(((V4))==Cnil){
	goto L769;}
	goto L770;
L772:
	if(!(type_of((V2))==t_cons)){
	goto L782;}
	if(!((CAR((V2)))==(VV[78]))){
	goto L782;}
	V3= CADR((V2));
	(*LK26)(2,(V3),VV[79])                    /*  SUBTYPEP        */;
	if(VALUES(0)!=Cnil){
	goto L781;}
	if(!((VV[80])->s.s_dbind!=OBJNULL)){
	goto L782;}
	if(((VV[80]->s.s_dbind))==Cnil){
	goto L782;}
	(*LK26)(2,(V3),VV[81])                    /*  SUBTYPEP        */;
	if(VALUES(0)==Cnil){
	goto L782;}
L781:
	(*LK26)(2,(V3),VV[82])                    /*  SUBTYPEP        */;
	if(VALUES(0)==Cnil){
	goto L797;}
	V4= VV[77];
	goto L795;
L797:
	(*LK26)(2,(V3),VV[83])                    /*  SUBTYPEP        */;
	if(VALUES(0)==Cnil){
	goto L800;}
	V4= VV[76];
	goto L795;
L800:
	V4= Cnil;
L795:
	if(((V4))==Cnil){
	goto L769;}
	goto L770;
L782:
	goto L769;
L770:
	RETURN((*LK20)(1,CONS((V4),(V1)))         /*  C1EXPR          */);
L769:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SHIFT>>                               */
static L23(int narg, object V1, object V2)
{ VT25 VLEX25 CLSR25
TTL:
	RETURN(Lash(2,(V1),(V2))                  /*  ASH             */);
}
/*	function definition for CO1BOOLE                              */
static L25(int narg, object V1)
{ VT26 VLEX26 CLSR26
TTL:
	if(((CDDR((V1))==Cnil?Ct:Cnil))==Cnil){
	goto L802;}
	VALUES(0) = Cnil;
	RETURN(1);
L802:
	if(CDDDR((V1))==Cnil){
	goto L804;}
	VALUES(0) = Cnil;
	RETURN(1);
L804:
	{register object V2;                      /*  OP-CODE         */
	object V3;
	object V4;                                /*  INFO            */
	V3= CAR((V1));
	(*LK0)(0)                                 /*  MAKE-INFO       */;
	V4= VALUES(0);
	V2= V3;
	Lconstantp(1,(V2))                        /*  CONSTANTP       */;
	if(VALUES(0)!=Cnil){
	goto L808;}
	VALUES(0) = Cnil;
	RETURN(1);
L808:
	Leval(1,(V2))                             /*  EVAL            */;
	V2= VALUES(0);
	if(FIXNUMP((V2))){
	goto L810;}
	VALUES(0) = Cnil;
	RETURN(1);
L810:
	(*LK10)(2,CONS((V2),CDR((V1))),(V4))      /*  C1ARGS          */;
	VALUES(0) = list(3,VV[87],(V4),VALUES(0));
	RETURN(1);
	}
}
/*	function definition for C2BOOLE3                              */
static L26(int narg, object V1)
{ VT27 VLEX27 CLSR27
	bds_check;
TTL:
	{object V2;                               /*  BOOLE-OP-ARG    */
	object V3;                                /*  STRING          */
	V2= CADDR(CAR((V1)));
	{object V4= CADR((V2));
	if(!eql(V4,VV[56]))goto L816;
	V3= VV[88];
	goto L815;
L816:
	if(!eql(V4,VV[89]))goto L817;
	V3= VV[90];
	goto L815;
L817:
	if(!eql(V4,VV[62]))goto L818;
	V3= VV[91];
	goto L815;
L818:
	if(!eql(V4,VV[66]))goto L819;
	V3= VV[92];
	goto L815;
L819:
	if(!eql(V4,VV[93]))goto L820;
	V3= VV[94];
	goto L815;
L820:
	if(!eql(V4,VV[95]))goto L821;
	V3= VV[96];
	goto L815;
L821:
	if(!eql(V4,VV[58]))goto L822;
	V3= VV[97];
	goto L815;
L822:
	if(!eql(V4,VV[68]))goto L823;
	V3= VV[98];
	goto L815;
L823:
	if(!eql(V4,VV[67]))goto L824;
	V3= VV[99];
	goto L815;
L824:
	if(!eql(V4,VV[100]))goto L825;
	V3= VV[101];
	goto L815;
L825:
	if(!eql(V4,VV[102]))goto L826;
	V3= VV[103];
	goto L815;
L826:
	if(!eql(V4,VV[104]))goto L827;
	V3= VV[105];
	goto L815;
L827:
	if(!eql(V4,VV[64]))goto L828;
	V3= VV[106];
	goto L815;
L828:
	if(!eql(V4,VV[60]))goto L829;
	V3= VV[107];
	goto L815;
L829:
	if(!eql(V4,VV[108]))goto L830;
	V3= VV[109];
	goto L815;
L830:
	if(!eql(V4,VV[110]))goto L831;
	V3= VV[111];
	goto L815;
L831:
	FEerror("The ECASE key value ~s is illegal.",1,V4);}
L815:
	bds_bind(VV[37],MAKE_FIXNUM(0));          /*  *INLINE-BLOCKS* */
	(*LK22)(1,CDR((V1)))                      /*  INLINE-ARGS     */;
	LC27(1,VALUES(0))                         /*  COERCE-TO-FIXNUMS*/;
	(*LK6)(1,list(4,VV[112],Cnil,(V3),VALUES(0)))/*  UNWIND-EXIT  */;
	{int V4;
	V4=(*LK23)(0)                             /*  CLOSE-INLINE-BLOCKS*/;
	bds_unwind1;
	RETURN(V4);}
	}
}
/*	local function COERCE-TO-FIXNUMS                              */
static LC27(int narg, object V1)
{ VT28 VLEX28 CLSR28
TTL:
	{register object V2;                      /*  L               */
	V2= (V1);
L836:
	if(((V2))!=Cnil){
	goto L837;}
	VALUES(0) = (V1);
	RETURN(1);
L837:
	if((VV[113])==(CAAR((V2)))){
	goto L840;}
	CAR(CAR((V2))) = VV[114];
L840:
	V2= CDR((V2));
	goto L836;
	}
}
/*	function definition for CO1COERCE                             */
static L28(int narg, object V1)
{ VT29 VLEX29 CLSR29
TTL:
	{object V2;                               /*  INFO            */
	(*LK0)(0)                                 /*  MAKE-INFO       */;
	V2= VALUES(0);
	if((V1)==Cnil){
	VALUES(0) = Cnil;
	RETURN(1);}
	if((CDR((V1)))!=Cnil){
	goto L848;}
	VALUES(0) = Cnil;
	RETURN(1);
L848:
	if(CDDR((V1))==Cnil){
	goto L850;}
	VALUES(0) = Cnil;
	RETURN(1);
L850:
	{register object V3;                      /*  EXPR            */
	object V4;                                /*  TYPE            */
	V3= CAR((V1));
	V4= CADR((V1));
	if(type_of((V4))==t_cons||(V4)==Cnil){
	goto L854;}
	VALUES(0) = Cnil;
	RETURN(1);
L854:
	if((CAR((V4)))==(VV[115])){
	goto L856;}
	VALUES(0) = Cnil;
	RETURN(1);
L856:
	{object V5= CADR((V4));
	if((V5!= VV[11])
	&& (V5!= VV[221]))goto L858;
	RETURN((*LK20)(1,list(2,VV[11],(V3)))     /*  C1EXPR          */);
L858:
	if((V5!= VV[116]))goto L859;
	RETURN((*LK20)(1,list(2,VV[116],(V3)))    /*  C1EXPR          */);
L859:
	if((V5!= VV[222])
	&& (V5!= VV[223]))goto L860;
	RETURN((*LK20)(1,list(3,VV[116],(V3),VV[117]))/*  C1EXPR      */);
L860:
	if((V5!= VV[224])
	&& (V5!= VV[225]))goto L861;
	RETURN((*LK20)(1,list(3,VV[116],(V3),VV[118]))/*  C1EXPR      */);
L861:
	VALUES(0) = Cnil;
	RETURN(1);}
	}
	}
}
/*	function definition for CO1CONS                               */
static L29(int narg, object V1)
{ VT30 VLEX30 CLSR30
TTL:
	{register object V2;                      /*  TEMP            */
	V2= Cnil;
	if((length((V1)))==(2)){
	goto L863;}
	VALUES(0) = Cnil;
	RETURN(1);
L863:
	LC30(1,(V1))                              /*  CONS-TO-LISTA   */;
	V2= VALUES(0);
	if(((((V1))==((V2))?Ct:Cnil))==Cnil){
	goto L865;}
	VALUES(0) = Cnil;
	RETURN(1);
L865:
	Llast(1,(V2))                             /*  LAST            */;
	if(!(equal(VV[119],VALUES(0)))){
	goto L870;}
	Lbutlast(1,(V2))                          /*  BUTLAST         */;
	VALUES(0) = CONS(VV[120],VALUES(0));
	goto L868;
L870:
	VALUES(0) = CONS(VV[25],(V2));
L868:
	RETURN((*LK20)(1,VALUES(0))               /*  C1EXPR          */);
	}
}
/*	local function CONS-TO-LISTA                                  */
static LC30(int narg, object V1)
{ VT31 VLEX31 CLSR31
TTL:
	{register object V2;                      /*  TEM             */
	Llast(1,(V1))                             /*  LAST            */;
	V2= VALUES(0);
	if(!(type_of((V2))==t_cons)){
	goto L876;}
	if(!(type_of(CAR((V2)))==t_cons)){
	goto L876;}
	if(!((CAAR((V2)))==(VV[121]))){
	goto L876;}
	if(!((length(CDAR((V2))))==(2))){
	goto L876;}
	Lbutlast(1,(V1))                          /*  BUTLAST         */;
	T0= VALUES(0);
	V1= append(T0,CDAR((V2)));
	goto TTL;
L876:
	VALUES(0) = (V1);
	RETURN(1);
	}
}
/*	function definition for RESULT-TYPE                           */
static L31(int narg, object V1)
{ VT32 VLEX32 CLSR32
TTL:
	if(!(type_of((V1))==t_symbol)){
	goto L888;}
	(*LK20)(1,(V1))                           /*  C1EXPR          */;
	VALUES(0) = (CADR(VALUES(0)))->v.v_self[3];
	RETURN(1);
L888:
	Lconstantp(1,(V1))                        /*  CONSTANTP       */;
	if(VALUES(0)==Cnil){
	goto L892;}
	RETURN((*LK27)(1,TYPE_OF((V1)))           /*  TYPE-FILTER     */);
L892:
	if(!(type_of((V1))==t_cons)){
	goto L895;}
	if(!((CAR((V1)))==(VV[78]))){
	goto L895;}
	RETURN((*LK27)(1,CADR((V1)))              /*  TYPE-FILTER     */);
L895:
	VALUES(0) = Ct;
	RETURN(1);
}
/*	function definition for CO1EQL                                */
static L32(int narg, object V1)
{ VT33 VLEX33 CLSR33
TTL:
	if((CDR((V1)))==Cnil){
	goto L900;}
	if(((VV[38]->s.s_dbind))!=Cnil){
	goto L900;}
	LC33(1,(V1))                              /*  REPLACE-CONSTANT*/;
	if(VALUES(0)==Cnil){
	goto L900;}
	if(!(CHARACTERP(CADR((V1))))){
	goto L906;}
	V1= reverse((V1));
L906:
	if(!(CHARACTERP(CAR((V1))))){
	goto L911;}
	{register object V2;                      /*  C               */
	Lgensym(0)                                /*  GENSYM          */;
	V2= VALUES(0);
	{object V3= CONS(list(2,(V2),CADR((V1))),Cnil);
	L31(1,CADR((V1)))                         /*  RESULT-TYPE     */;
	{object V4= list(2,VV[122],list(3,VV[123],VALUES(0),(V2)));
	{object V5= list(2,VV[125],(V2));
	{object V6= list(2,VV[127],CAR((V1)));
	RETURN((*LK20)(1,list(4,VV[26],V3,V4,list(3,VV[124],V5,list(3,VV[126],V6,list(3,VV[78],VV[113],list(2,VV[127],list(3,VV[78],VV[11],(V2))))))))/*  C1EXPR*/);}}}}
	}
L911:
	VALUES(0) = Cnil;
	RETURN(1);
L900:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	local function REPLACE-CONSTANT                               */
static LC33(int narg, object V1)
{ VT34 VLEX34 CLSR34
TTL:
	{register object V2;                      /*  V               */
	object V3;                                /*  FOUND           */
	object V4;                                /*  TEM             */
	V2= (V1);
	V3= Cnil;
	V4= Cnil;
L916:
	if(((V2))!=Cnil){
	goto L917;}
	VALUES(0) = (V3);
	RETURN(1);
L917:
	Lconstantp(1,CAR((V2)))                   /*  CONSTANTP       */;
	if(VALUES(0)==Cnil){
	goto L920;}
	Leval(1,CAR((V2)))                        /*  EVAL            */;
	V4= VALUES(0);
	if(numberp((V4))){
	goto L921;}
	if(!(CHARACTERP((V4)))){
	goto L920;}
L921:
	V3= Ct;
	CAR((V2)) = (V4);
L920:
	V2= CDR((V2));
	goto L916;
	}
}
/*	function definition for CO1LDB                                */
static L34(int narg, object V1)
{ VT35 VLEX35 CLSR35
TTL:
	{register object V2;                      /*  ARG1            */
	object V3;                                /*  LEN             */
	object V4;                                /*  SIZE            */
	object V5;                                /*  POS             */
	V2= CAR((V1));
	Linteger_length(1,MAKE_FIXNUM(536870911)) /*  INTEGER-LENGTH  */;
	V3= VALUES(0);
	V4= Cnil;
	V5= Cnil;
	if(type_of((V2))==t_cons){
	goto L938;}
	VALUES(0) = Cnil;
	RETURN(1);
L938:
	if((VV[128])==(CAR((V2)))){
	goto L940;}
	VALUES(0) = Cnil;
	RETURN(1);
L940:
	V4= CADR((V2));
	if(type_of((V4))==t_fixnum||type_of((V4))==t_bignum){
	goto L942;}
	VALUES(0) = Cnil;
	RETURN(1);
L942:
	V5= CADDR((V2));
	if(type_of((V5))==t_fixnum||type_of((V5))==t_bignum){
	goto L945;}
	VALUES(0) = Cnil;
	RETURN(1);
L945:
	if(number_compare(number_plus((V4),(V5)),(V3))<0){
	goto L948;}
	VALUES(0) = Cnil;
	RETURN(1);
L948:
	L31(1,CADR((V1)))                         /*  RESULT-TYPE     */;
	(*LK26)(2,VALUES(0),VV[113])              /*  SUBTYPEP        */;
	if(VALUES(0)!=Cnil){
	goto L950;}
	VALUES(0) = Cnil;
	RETURN(1);
L950:
	RETURN((*LK20)(1,list(3,VV[78],VV[113],list(4,VV[129],(V4),(V5),CADR((V1)))))/*  C1EXPR*/);
	}
}
/*	function definition for CO1VECTOR-PUSH                        */
static L35(int narg, object V1)
{ VT36 VLEX36 CLSR36
TTL:
	RETURN(L37(2,Cnil,(V1))                   /*  CO1VECTOR-PUSH1 */);
}
/*	function definition for CO1VECTOR-PUSH-EXTEND                 */
static L36(int narg, object V1)
{ VT37 VLEX37 CLSR37
TTL:
	RETURN(L37(2,Ct,(V1))                     /*  CO1VECTOR-PUSH1 */);
}
/*	function definition for CO1VECTOR-PUSH1                       */
static L37(int narg, object V1, object V2)
{ VT38 VLEX38 CLSR38
	bds_check;
TTL:
	if(((VV[38]->s.s_dbind))!=Cnil){
	goto L954;}
	if(number_compare((VV[132]->s.s_dbind),MAKE_FIXNUM(3))>0){
	goto L954;}
	if((CDR((V2)))==Cnil){
	goto L954;}
	bds_bind(VV[132],MAKE_FIXNUM(10));        /*  *SPACE*         */
	{object V3= list(2,VV[133],CAR((V2)));
	{object V4= listA(3,V3,list(2,VV[134],CADR((V2))),VV[135]);
	L31(1,CADR((V2)))                         /*  RESULT-TYPE     */;
	{object V5= list(3,VV[123],VALUES(0),VV[134]);
	L31(1,CAR((V2)))                          /*  RESULT-TYPE     */;
	{object V6= list(4,VV[122],VV[136],V5,list(3,VV[123],VALUES(0),VV[133]));
	if(((V1))==Cnil){
	goto L964;}
	VALUES(0) = listA(4,VV[139],VV[133],VV[134],CDDR((V2)));
	goto L962;
L964:
	VALUES(0) = Cnil;
L962:
	{int V7;
	V7=(*LK20)(1,list(4,VV[32],V4,V6,list(3,VV[137],VV[138],list(2,Ct,VALUES(0)))))/*  C1EXPR*/;
	bds_unwind1;
	RETURN(V7);}}}}}
L954:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for C1LENGTH                              */
static L38(int narg, object V1)
{ VT39 VLEX39 CLSR39
TTL:
	{register object V2;                      /*  INFO            */
	object V3;                                /*  ARGS1           */
	(*LK0)(0)                                 /*  MAKE-INFO       */;
	V2= VALUES(0);
	V3= Cnil;
	elt_set((V2),3,VV[113]);
	if(!(type_of(CAR((V1)))==t_cons)){
	goto L970;}
	if(!((CAAR((V1)))==(VV[140]))){
	goto L970;}
	V3= CDAR((V1));
	if(((V3))==Cnil){
	goto L970;}
	if((CDDR((V3)))!=Cnil){
	goto L970;}
	(*LK10)(2,(V3),(V2))                      /*  C1ARGS          */;
	VALUES(0) = list(4,VV[4],(V2),VV[141],VALUES(0));
	RETURN(1);
L970:
	(*LK10)(2,(V1),(V2))                      /*  C1ARGS          */;
	VALUES(0) = list(4,VV[4],(V2),VV[142],VALUES(0));
	RETURN(1);
	}
}
/*	function definition for CO1SCHAR                              */
static L39(int narg, object V1)
{ VT40 VLEX40 CLSR40
TTL:
	{object V2= CAR((V1));
	if(type_of(V2)==t_cons||V2==Cnil){
	goto L981;}}
	VALUES(0) = Cnil;
	RETURN(1);
L981:
	if(((VV[38]->s.s_dbind))==Cnil){
	goto L983;}
	VALUES(0) = Cnil;
	RETURN(1);
L983:
	if((CDR((V1)))!=Cnil){
	goto L985;}
	VALUES(0) = Cnil;
	RETURN(1);
L985:
	if((CAAR((V1)))==(VV[140])){
	goto L987;}
	VALUES(0) = Cnil;
	RETURN(1);
L987:
	RETURN((*LK20)(1,list(3,VV[143],list(3,VV[78],VV[12],CADR(CAR((V1)))),CADR((V1))))/*  C1EXPR*/);
}
static LKF27(int narg, ...) {TRAMPOLINK(VV[226],&LK27);}
static LKF26(int narg, ...) {TRAMPOLINK(VV[220],&LK26);}
static LKF25(int narg, ...) {TRAMPOLINK(VV[219],&LK25);}
static LKF24(int narg, ...) {TRAMPOLINK(VV[215],&LK24);}
static LKF23(int narg, ...) {TRAMPOLINK(VV[214],&LK23);}
static LKF22(int narg, ...) {TRAMPOLINK(VV[213],&LK22);}
static LKF21(int narg, ...) {TRAMPOLINK(VV[212],&LK21);}
static LKF20(int narg, ...) {TRAMPOLINK(VV[211],&LK20);}
static LKF19(int narg, ...) {TRAMPOLINK(VV[210],&LK19);}
static LKF18(int narg, ...) {TRAMPOLINK(VV[209],&LK18);}
static LKF17(int narg, ...) {TRAMPOLINK(VV[208],&LK17);}
static LKF16(int narg, ...) {TRAMPOLINK(VV[207],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[206],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[205],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[204],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[203],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[201],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[199],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[198],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[197],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[196],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[195],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[194],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[193],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[192],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[191],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[190],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[189],&LK0);}
