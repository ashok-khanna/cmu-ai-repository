
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "cmploc.h"
init_cmploc(int size, object data_stream)
{VT2 CLSR2
	Cblock.cd_start=(char *)init_cmploc; Cblock.cd_size=size;
	Cblock.cd_data=read_VV(VV,VM1,data_stream);
	VV[0]->s.s_stype=(short)stp_special;
	MF0(VV[6],L1);
	MF0(VV[7],L2);
	MF0(VV[31],L3);
	MF0(VV[32],L4);
	MF0(VV[33],L5);
	MF0(VV[34],L6);
	MF0(VV[35],L7);
	MF0(VV[36],L8);
	MF0(VV[37],L9);
	MF0(VV[38],L10);
	MF0(VV[39],L11);
	MF0(VV[40],L12);
	MF0(VV[41],L13);
	MF0(VV[42],L14);
	MF0(VV[43],L15);
	MF0(VV[44],L16);
	MF0(VV[45],L17);
	MF0(VV[46],L18);
	MF0(VV[47],L19);
	MF0(VV[48],L20);
	MF0(VV[49],L21);
	MF0(VV[50],L22);
	VALUES(0) = (VV[38]->s.s_gfdef);
	putprop(VV[18],VALUES(0),VV[7]);
	VALUES(0) = (VV[37]->s.s_gfdef);
	putprop(VV[19],VALUES(0),VV[7]);
	VALUES(0) = (VV[36]->s.s_gfdef);
	putprop(VV[20],VALUES(0),VV[7]);
	VALUES(0) = (VV[32]->s.s_gfdef);
	putprop(VV[21],VALUES(0),VV[7]);
	VALUES(0) = (VV[33]->s.s_gfdef);
	putprop(VV[22],VALUES(0),VV[7]);
	VALUES(0) = (VV[34]->s.s_gfdef);
	putprop(VV[23],VALUES(0),VV[7]);
	VALUES(0) = (VV[39]->s.s_gfdef);
	putprop(VV[24],VALUES(0),VV[7]);
	VALUES(0) = (VV[41]->s.s_gfdef);
	putprop(VV[25],VALUES(0),VV[7]);
	VALUES(0) = (VV[40]->s.s_gfdef);
	putprop(VV[26],VALUES(0),VV[7]);
	VALUES(0) = (VV[39]->s.s_gfdef);
	putprop(VV[27],VALUES(0),VV[7]);
	VALUES(0) = (VV[39]->s.s_gfdef);
	putprop(VV[28],VALUES(0),VV[7]);
	VALUES(0) = (VV[45]->s.s_gfdef);
	putprop(VV[29],VALUES(0),VV[7]);
	VALUES(0) = (VV[46]->s.s_gfdef);
	putprop(VV[29],VALUES(0),VV[6]);
	VALUES(0) = (VV[47]->s.s_gfdef);
	putprop(VV[5],VALUES(0),VV[7]);
	VALUES(0) = (VV[48]->s.s_gfdef);
	putprop(VV[3],VALUES(0),VV[7]);
	VALUES(0) = (VV[49]->s.s_gfdef);
	putprop(VV[3],VALUES(0),VV[6]);
	VALUES(0) = (VV[50]->s.s_gfdef);
	putprop(VV[30],VALUES(0),VV[7]);
}
/*	function definition for SET-LOC                               */
static L1(int narg, object V1)
{ VT3 VLEX3 CLSR3
TTL:
	{register object V2;                      /*  FD              */
	V2= Cnil;
	if(!(type_of((V1))==t_cons)){
	goto L36;}
	if((memq(CAR((V1)),VV[2]))==Cnil){
	goto L36;}
	if(!(type_of((VV[0]->s.s_dbind))==t_cons)){
	goto L41;}
	if((CAR((VV[0]->s.s_dbind)))==(VV[3])){
	goto L36;}
L41:
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[4]));
	V1= VV[1];
L36:
	if(((VV[0]->s.s_dbind)!= VV[8]))goto L51;
	if(!(type_of((V1))==t_cons)){
	goto L52;}
	if((CAR((V1)))==(VV[3])){
	goto L53;}
	if((CAR((V1)))==(VV[5])){
	goto L53;}
L52:
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("VALUES(0) = ",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L53:
	VALUES(0) = Cnil;
	RETURN(1);
L51:
	if(((VV[0]->s.s_dbind)!= VV[52]))goto L64;
	if(!(type_of((V1))==t_cons)){
	goto L66;}
	{object V3= CAR((V1));
	if((V3== VV[53])
	|| (V3== VV[54])
	|| (V3== VV[55])
	|| (V3== VV[56])
	|| (V3== VV[57]))goto L69;
	if((V3!= VV[58]))goto L68;
L69:
	if((CADR((V1)))==Cnil){
	goto L71;}
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	(*LK1)(3,Ct,CADDR((V1)),CADDDR((V1)))     /*  WT-INLINE       */;
	princ_char(59,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L71:
	VALUES(0) = Cnil;
	RETURN(1);
L68:
	if((V3!= VV[60])
	&& (V3!= VV[61]))goto L78;
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("(void)",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L78:
	VALUES(0) = Cnil;
	RETURN(1);}
L66:
	VALUES(0) = Cnil;
	RETURN(1);
L64:
	if(!(type_of((VV[0]->s.s_dbind))==t_cons)){
	goto L84;}
	if(type_of(CAR((VV[0]->s.s_dbind)))==t_symbol){
	goto L85;}
L84:
	RETURN((*LK2)(0)                          /*  BABOON          */);
L85:
	V2= getf(CAR((VV[0]->s.s_dbind))->s.s_plist,VV[6],Cnil);
	if(((V2))==Cnil){
	goto L90;}
	RETURN(Lapply(3,(V2),(V1),CDR((VV[0]->s.s_dbind)))/*  APPLY   */);
L90:
	V2= getf(CAR((VV[0]->s.s_dbind))->s.s_plist,VV[7],Cnil);
	if(((V2))==Cnil){
	goto L94;}
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	Lapply(2,(V2),CDR((VV[0]->s.s_dbind)))    /*  APPLY           */;
	princ_str("= ",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L94:
	RETURN((*LK2)(0)                          /*  BABOON          */);
	}
}
/*	function definition for WT-LOC                                */
static L2(int narg, object V1)
{ VT4 VLEX4 CLSR4
TTL:
	{object V2;                               /*  FD              */
	V2= Cnil;
	if(!(((V1))==(Cnil))){
	goto L106;}
	princ_str("Cnil",symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L106:
	if(!(((V1))==(Ct))){
	goto L110;}
	princ_str("Ct",symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L110:
	if(!(((V1))==(VV[8]))){
	goto L114;}
	princ_str("VALUES(0)",symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L114:
	if(!(type_of((V1))==t_cons)){
	goto L117;}
	if(type_of(CAR((V1)))==t_symbol){
	goto L118;}
L117:
	RETURN((*LK2)(0)                          /*  BABOON          */);
L118:
	V2= getf(CAR((V1))->s.s_plist,VV[7],Cnil);
	if(((V2))==Cnil){
	goto L123;}
	RETURN(Lapply(2,(V2),CDR((V1)))           /*  APPLY           */);
L123:
	RETURN((*LK2)(0)                          /*  BABOON          */);
	}
}
/*	function definition for LAST-CALL-P                           */
static L3(int narg)
{ VT5 VLEX5 CLSR5
TTL:
	VALUES(0) = memql((VV[9]->s.s_dbind),VV[10]);
	RETURN(1);
}
/*	function definition for WT-CAR                                */
static L4(int narg, object V1)
{ VT6 VLEX6 CLSR6
TTL:
	princ_str("CAR(",symbol_value(VV[4]));
	L7(1,(V1))                                /*  WT-LCL          */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-CDR                                */
static L5(int narg, object V1)
{ VT7 VLEX7 CLSR7
TTL:
	princ_str("CDR(",symbol_value(VV[4]));
	L7(1,(V1))                                /*  WT-LCL          */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-CADR                               */
static L6(int narg, object V1)
{ VT8 VLEX8 CLSR8
TTL:
	princ_str("CADR(",symbol_value(VV[4]));
	L7(1,(V1))                                /*  WT-LCL          */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-LCL                                */
static L7(int narg, object V1)
{ VT9 VLEX9 CLSR9
TTL:
	princ_char(86,symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-VV                                 */
static L8(int narg, object V1)
{ VT10 VLEX10 CLSR10
TTL:
	princ_str("VV[",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(93,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-LCL-LOC                            */
static L9(int narg, object V1)
{ VT11 VLEX11 CLSR11
TTL:
	RETURN(L7(1,(V1))                         /*  WT-LCL          */);
}
/*	function definition for WT-TEMP                               */
static L10(int narg, object V1)
{ VT12 VLEX12 CLSR12
TTL:
	princ_char(84,symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-NUMBER                             */
static L11(int narg, object V1, ...)
{ VT13 VLEX13 CLSR13
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if (i==narg) goto L145;
	V2= va_arg(args, object);
	i++;
	goto L146;
L145:
	V2= Cnil;
L146:
	{object V3;
	(*LK3)(2,(V1),VV[11])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L149;}
	princ_str("MAKE_FIXNUM(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L149:
	princ_str("VV[",symbol_value(VV[4]));
	(*LK0)(1,(V2))                            /*  WT1             */;
	princ_char(93,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
	}
	}
}
/*	function definition for WT-CHARACTER                          */
static L12(int narg, object V1, ...)
{ VT14 VLEX14 CLSR14
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if (i==narg) goto L157;
	V2= va_arg(args, object);
	i++;
	goto L158;
L157:
	V2= Cnil;
L158:
	Lformat(3,Cnil,VV[12],(V1))               /*  FORMAT          */;
	(*LK0)(1,VALUES(0))                       /*  WT1             */;
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WT-FIXNUM-LOC                         */
static L13(int narg, object V1)
{ VT15 VLEX15 CLSR15
TTL:
	if(!(type_of((V1))==t_cons)){
	goto L163;}
	{object V2= CAR((V1));
	if((V2!= VV[64]))goto L165;
	if(!(((CADR((V1)))->v.v_self[4])==(VV[11]))){
	goto L167;}
	RETURN(L7(1,(CADR((V1)))->v.v_self[5])    /*  WT-LCL          */);
L167:
	princ_str("fix(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L165:
	if((V2!= VV[55]))goto L172;
	RETURN((*LK4)(2,CADDR((V1)),CADDDR((V1))) /*  WT-INLINE-LOC   */);
L172:
	if((V2!= VV[24]))goto L173;
	(*LK0)(1,CADR((V1)))                      /*  WT1             */;
	VALUES(0) = Cnil;
	RETURN(1);
L173:
	if((V2!= VV[58])
	&& (V2!= VV[57]))goto L175;
	princ_str("((int)(",symbol_value(VV[4]));
	(*LK4)(2,CADDR((V1)),CADDDR((V1)))        /*  WT-INLINE-LOC   */;
	princ_str("))",symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L175:
	princ_str("fix(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);}
L163:
	princ_str("fix(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-CHARACTER-LOC                      */
static L14(int narg, object V1)
{ VT16 VLEX16 CLSR16
TTL:
	if(!(type_of((V1))==t_cons)){
	goto L187;}
	{object V2= CAR((V1));
	if((V2!= VV[64]))goto L189;
	if(!(((CADR((V1)))->v.v_self[4])==(VV[13]))){
	goto L191;}
	RETURN(L7(1,(CADR((V1)))->v.v_self[5])    /*  WT-LCL          */);
L191:
	princ_str("char_code(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L189:
	if((V2!= VV[56]))goto L196;
	RETURN((*LK4)(2,CADDR((V1)),CADDDR((V1))) /*  WT-INLINE-LOC   */);
L196:
	if((V2!= VV[26]))goto L197;
	(*LK0)(1,CADR((V1)))                      /*  WT1             */;
	VALUES(0) = Cnil;
	RETURN(1);
L197:
	princ_str("char_code(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);}
L187:
	princ_str("char_code(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-LONG-FLOAT-LOC                     */
static L15(int narg, object V1)
{ VT17 VLEX17 CLSR17
TTL:
	if(!(type_of((V1))==t_cons)){
	goto L206;}
	{object V2= CAR((V1));
	if((V2!= VV[64]))goto L208;
	if(!(((CADR((V1)))->v.v_self[4])==(VV[14]))){
	goto L210;}
	RETURN(L7(1,(CADR((V1)))->v.v_self[5])    /*  WT-LCL          */);
L210:
	princ_str("lf(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L208:
	if((V2!= VV[57]))goto L215;
	RETURN((*LK4)(2,CADDR((V1)),CADDDR((V1))) /*  WT-INLINE-LOC   */);
L215:
	if((V2!= VV[27]))goto L216;
	(*LK0)(1,CADR((V1)))                      /*  WT1             */;
	VALUES(0) = Cnil;
	RETURN(1);
L216:
	princ_str("lf(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);}
L206:
	princ_str("lf(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-SHORT-FLOAT-LOC                    */
static L16(int narg, object V1)
{ VT18 VLEX18 CLSR18
TTL:
	if(!(type_of((V1))==t_cons)){
	goto L225;}
	{object V2= CAR((V1));
	if((V2!= VV[64]))goto L227;
	if(!(((CADR((V1)))->v.v_self[4])==(VV[15]))){
	goto L229;}
	RETURN(L7(1,(CADR((V1)))->v.v_self[5])    /*  WT-LCL          */);
L229:
	princ_str("sf(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L227:
	if((V2!= VV[58]))goto L234;
	RETURN((*LK4)(2,CADDR((V1)),CADDDR((V1))) /*  WT-INLINE-LOC   */);
L234:
	if((V2!= VV[28]))goto L235;
	(*LK0)(1,CADR((V1)))                      /*  WT1             */;
	VALUES(0) = Cnil;
	RETURN(1);
L235:
	princ_str("sf(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);}
L225:
	princ_str("sf(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-VA_ARG                             */
static L17(int narg)
{ VT19 VLEX19 CLSR19
TTL:
	princ_str("va_arg(args, object)",symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for SET-VA_ARG                            */
static L18(int narg, object V1)
{ VT20 VLEX20 CLSR20
TTL:
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("va_arg(args, object)=",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-VALUE                              */
static L19(int narg, object V1)
{ VT21 VLEX21 CLSR21
TTL:
	princ_str("VALUES(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-VALUES                             */
static L20(int narg, object V1)
{ VT22 VLEX22 CLSR22
TTL:
	princ_str("VALUES(0)",symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for SET-VALUES                            */
static L21(int narg, object V1, object V2)
{ VT23 VLEX23 CLSR23
TTL:
	if(!(type_of((V1))==t_cons)){
	goto L254;}
	if((memq(CAR((V1)),VV[16]))!=Cnil){
	goto L253;}
	if(!((CAR((V1)))==(VV[3]))){
	goto L261;}
	V1= CADR((V1));
	if(((V1))==Cnil){
	goto L254;}
	goto L259;
L261:
	goto L254;
L259:
L253:
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	(*LK0)(1,(V2))                            /*  WT1             */;
	princ_char(61,symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L254:
	if(!(type_of((V1))==t_cons)){
	goto L271;}
	if((memq(CAR((V1)),VV[17]))!=Cnil){
	goto L270;}
L271:
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("VALUES(0)=",symbol_value(VV[4]));
L270:
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[4]));
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	(*LK0)(1,(V2))                            /*  WT1             */;
	princ_str("=1;",symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-KEYVARS                            */
static L22(int narg, object V1)
{ VT24 VLEX24 CLSR24
TTL:
	princ_str("keyvars[",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(93,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
static LKF4(int narg, ...) {TRAMPOLINK(VV[65],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[63],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[62],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[59],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[51],&LK0);}
