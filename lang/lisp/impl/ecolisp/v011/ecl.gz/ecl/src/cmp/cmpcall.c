
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "cmpcall.h"
init_cmpcall(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_cmpcall; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	VV[0]->s.s_stype=(short)stp_special;
	if(VV[0]->s.s_dbind == OBJNULL){
	(VV[0]->s.s_dbind)= Ct;}
	VV[61] = make_cfun(LC2,Cnil,&Cblock);
	MF0(VV[62],L1);
	MF0(VV[63],L3);
	MF0(VV[64],L4);
	MF0(VV[65],L5);
	MF0(VV[66],L6);
	MF0(VV[67],L7);
	MF0(VV[7],L9);
	MF0(VV[68],L11);
	MF0(VV[69],L12);
	MF0(VV[70],L13);
	MF0(VV[71],L14);
	VALUES(0) = (VV[65]->s.s_gfdef);
	putprop(VV[58],VALUES(0),VV[59]);
	VALUES(0) = (VV[66]->s.s_gfdef);
	putprop(VV[15],VALUES(0),VV[59]);
	VALUES(0) = (VV[67]->s.s_gfdef);
	putprop(VV[7],VALUES(0),VV[59]);
	VALUES(0) = (VV[70]->s.s_gfdef);
	putprop(VV[47],VALUES(0),VV[60]);
}
/*	local function CLOSURE                                        */
static LC2(int narg, object V1)
{ VT3 VLEX3 CLSR3
	VALUES(0) = (((V1))==(Ct)?Ct:Cnil);
	RETURN(1);
}
/*	function definition for FAST-LINK-PROCLAIMED-TYPE-P           */
static L1(int narg, object V1, ...)
{ VT4 VLEX4 CLSR4
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if (i==narg) goto L10;
	V2= va_arg(args, object);
	i++;
	goto L11;
L10:
	V2= Cnil;
L11:
	if((VV[0]->s.s_dbind)==Cnil){
	VALUES(0) = Cnil;
	RETURN(1);}
	if(type_of((V1))==t_symbol){
	goto L13;}
	VALUES(0) = Cnil;
	RETURN(1);
L13:
	if((length((V2)))<(10)){
	goto L15;}
	VALUES(0) = Cnil;
	RETURN(1);
L15:
	if((getf((V1)->s.s_plist,VV[1],Cnil))!=Cnil){
	goto L19;}
	VALUES(0) = Cnil;
	goto L18;
L19:
	VALUES(0) = (type_of((V2))==t_cons||(V2)==Cnil?Ct:Cnil);
L18:
	if(VALUES(0)==Cnil)goto L17;
	RETURN(1);
L17:
	if((getf((V1)->s.s_plist,VV[2],Cnil))!=Cnil){
	goto L21;}
	VALUES(0) = Cnil;
	RETURN(1);
L21:
	if((getf((V1)->s.s_plist,VV[3],Cnil))==(Ct)){
	goto L23;}
	VALUES(0) = Cnil;
	RETURN(1);
L23:
	T0= VV[61];
	RETURN((*LK0)(2,T0,getf((V1)->s.s_plist,VV[4],Cnil))/*  EVERY */);
	}
}
/*	function definition for CMP-MACRO-FUNCTION                    */
static L3(int narg, object V1)
{ VT5 VLEX5 CLSR5
TTL:
	{object V2;                               /*  FD              */
	V2= Cnil;
	(*LK1)(1,(V1))                            /*  C1CALL-LOCAL    */;
	V2= VALUES(0);
	if(((V2))==Cnil){
	goto L28;}
	if(!((CAR((V2)))==(VV[5]))){
	goto L32;}
	VALUES(0) = Cnil;
	RETURN(1);
L32:
	VALUES(0) = (V2);
	RETURN(1);
L28:
	RETURN(Lmacro_function(1,(V1))            /*  MACRO-FUNCTION  */);
	}
}
/*	function definition for C1FUNOB                               */
static L4(int narg, object V1)
{ VT6 VLEX6 CLSR6
	bds_check;
TTL:
	{object V2;                               /*  FD              */
	register object V3;                       /*  FUNCTION        */
	V2= Cnil;
	V3= Cnil;
	if(!(type_of((V1))==t_cons)){
	goto L36;}
	if(!(type_of(CAR((V1)))==t_symbol)){
	goto L36;}
	L3(1,CAR((V1)))                           /*  CMP-MACRO-FUNCTION*/;
	if(VALUES(0)==Cnil){
	goto L36;}
	(*LK2)(1,(V1))                            /*  CMP-MACROEXPAND */;
	V1= VALUES(0);
L36:
	if(!(type_of((V1))==t_cons)){
	goto L45;}
	if((memq(CAR((V1)),VV[6]))==Cnil){
	goto L45;}
	if(!(type_of(CDR((V1)))==t_cons)){
	goto L45;}
	if(!(CDDR((V1))==Cnil)){
	goto L45;}
	V3= CADR((V1));
	if(!(type_of((V3))==t_symbol)){
	goto L54;}
	(*LK1)(1,(V3))                            /*  C1CALL-LOCAL    */;
	V2= VALUES(0);
	if(((V2))==Cnil){
	goto L58;}
	if(!((CAR((V2)))==(VV[5]))){
	goto L58;}
	VALUES(0) = (V2);
	RETURN(1);
L58:
	(*LK3)(2,VV[8],((getf((V3)->s.s_plist,VV[9],Cnil))==Cnil?Ct:Cnil))/*  MAKE-INFO*/;
	VALUES(0) = list(3,VV[7],VALUES(0),(V3));
	RETURN(1);
L54:
	if(!(type_of((V3))==t_cons)){
	goto L65;}
	if(!((CAR((V3)))==(VV[10]))){
	goto L65;}
	if(!(type_of(CDR((V3)))==t_cons)){
	goto L65;}
	{object V4= CAR((V1));
	if((V4!= VV[76]))goto L71;
	{object V5;                               /*  LAMBDA-EXPR     */
	bds_bind(VV[11],Cnil);                    /*  *VARS*          */
	bds_bind(VV[12],Cnil);                    /*  *FUNS*          */
	bds_bind(VV[13],Cnil);                    /*  *BLOCKS*        */
	bds_bind(VV[14],Cnil);                    /*  *TAGS*          */
	(*LK4)(1,CDR((V3)))                       /*  C1LAMBDA-EXPR   */;
	V5= VALUES(0);
	{object V6= CADR((V5));
	(*LK5)(1,(V5))                            /*  GEN-INIT-KEYWORDS*/;
	{int V7;
	VALUES(0)=list(5,VV[15],(V6),(V5),Cnil,VALUES(0));
	V7=1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V7);}}
	}
L71:
	if((V4!= VV[79]))goto L74;
	{object V8;                               /*  LAMBDA-EXPR     */
	(*LK4)(1,CDR((V3)))                       /*  C1LAMBDA-EXPR   */;
	V8= VALUES(0);
	{object V9= CADR((V8));
	(*LK5)(1,(V8))                            /*  GEN-INIT-KEYWORDS*/;
	VALUES(0) = list(5,VV[15],(V9),(V8),Cnil,VALUES(0));
	RETURN(1);}
	}
L74:
	VALUES(0) = Cnil;
	RETURN(1);}
L65:
	RETURN((*LK6)(2,VV[16],(V1))              /*  CMPERR          */);
L45:
	{object V10;                              /*  X               */
	object V11;
	object V12;                               /*  INFO            */
	(*LK7)(1,(V1))                            /*  C1EXPR          */;
	V11= VALUES(0);
	(*LK3)(2,VV[8],Ct)                        /*  MAKE-INFO       */;
	V12= VALUES(0);
	V10= V11;
	(*LK8)(2,(V12),CADR((V10)))               /*  ADD-INFO        */;
	VALUES(0) = list(3,VV[17],(V12),(V10));
	RETURN(1);
	}
	}
}
/*	function definition for C2FUNCALL                             */
static L5(int narg, object V1, object V2, ...)
{ VT7 VLEX7 CLSR7
	bds_check;
	{int i=2;
	register object V3;
	register object V4;
	va_list args; va_start(args, V2);
	if (i==narg) goto L80;
	V3= va_arg(args, object);
	i++;
	if (i==narg) goto L81;
	V4= va_arg(args, object);
	i++;
	goto L82;
L80:
	V3= Cnil;
L81:
	V4= Cnil;
L82:
	{register object V5;                      /*  FORM            */
	V5= CADDR((V1));
	{object V6= CAR((V1));
	if((V6!= VV[7]))goto L86;
	RETURN(L7(5,(V5),(V2),(V3),Ct,(V4))       /*  C2CALL-GLOBAL   */);
L86:
	if((V6!= VV[5]))goto L87;
	RETURN((*LK9)(3,CDDR((V1)),(V2),(V4))     /*  C2CALL-LOCAL    */);
L87:
	if((V6!= VV[15]))goto L88;
	Lfifth(1,(V1))                            /*  FIFTH           */;
	RETURN(L6(4,(V5),(V2),VALUES(0),(V4))     /*  C2CALL-LAMBDA   */);
L88:
	if((V6!= VV[17]))goto L90;
	{object V7;                               /*  FUN             */
	V7= CADDR((V5));
	if(((V3))!=Cnil){
	goto L92;}
	if(!((CAR((V5)))==(VV[18]))){
	goto L96;}
	V3= (V7);
	goto L92;
L96:
	if(!((CAR((V5)))==(VV[19]))){
	goto L100;}
	(*LK10)(2,CAR((V7)),(V2))                 /*  VAR-CHANGED-IN-FORMS*/;
	if(VALUES(0)!=Cnil){
	goto L100;}
	V3= CONS(VV[19],(V7));
	goto L92;
L100:
	(*LK11)(0)                                /*  NEXT-TEMP       */;
	V3= list(2,VV[20],VALUES(0));
	bds_bind(VV[21],(V3));                    /*  *DESTINATION*   */
	(*LK12)(1,(V5))                           /*  C2EXPR*         */;
	bds_unwind1;
L92:
	bds_bind(VV[22],MAKE_FIXNUM(0));          /*  *INLINE-BLOCKS* */
	if(!(((V2))==(VV[23]))){
	goto L111;}
	VALUES(0) = (V2);
	goto L109;
L111:
	(*LK13)(1,(V2))                           /*  INLINE-ARGS     */;
L109:
	L14(5,Cnil,VALUES(0),(V3),Cnil,(V4))      /*  C2CALL-UNKNOWN-GLOBAL*/;
	{int V8;
	V8=(*LK14)(0)                             /*  CLOSE-INLINE-BLOCKS*/;
	bds_unwind1;
	RETURN(V8);}
	}
L90:
	RETURN((*LK15)(0)                         /*  BABOON          */);}
	}
	}
}
/*	function definition for C2CALL-LAMBDA                         */
static L6(int narg, object V1, object V2, object V3, ...)
{ VT8 VLEX8 CLSR8
	bds_check;
	{int i=3;
	object V4;
	va_list args; va_start(args, V3);
	if (i==narg) goto L113;
	V4= va_arg(args, object);
	i++;
	goto L114;
L113:
	V4= Cnil;
L114:
	{register object V5;                      /*  LAMBDA-LIST     */
	register object V6;                       /*  ARGS-PUSHED     */
	V5= CADDR((V1));
	V6= ((VV[23])==((V2))?Ct:Cnil);
	if((CADR((V5)))!=Cnil){
	goto L118;}
	if((CADDR((V5)))!=Cnil){
	goto L118;}
	if((CADDDR((V5)))!=Cnil){
	goto L118;}
	if(((V6))==Cnil){
	goto L119;}
L118:
	{object V7;                               /*  REQUIREDS       */
	register int V8;                          /*  NREQ            */
	V7= CAR((V5));
	V8= length((V7));
	if(((V6))!=Cnil){
	goto L129;}
	V4= MAKE_FIXNUM(length((V2)));
L129:
	(*LK16)(1,code_char('\12'))               /*  WT1             */;
	(*LK16)(1,code_char('\11'))               /*  WT1             */;
	princ_str("{ ",symbol_value(VV[24]));
	if(((V6))==Cnil){
	goto L139;}
	(*LK16)(1,code_char('\12'))               /*  WT1             */;
	(*LK16)(1,code_char('\11'))               /*  WT1             */;
	princ_str("object *args = &VALUES(",symbol_value(VV[24]));
	(*LK16)(1,MAKE_FIXNUM(V8))                /*  WT1             */;
	princ_str(");",symbol_value(VV[24]));
	goto L137;
L139:
	(*LK16)(1,code_char('\12'))               /*  WT1             */;
	(*LK16)(1,code_char('\11'))               /*  WT1             */;
	princ_str("object args[",symbol_value(VV[24]));
	(*LK16)(1,(V4))                           /*  WT1             */;
	princ_char(45,symbol_value(VV[24]));
	(*LK16)(1,MAKE_FIXNUM(V8))                /*  WT1             */;
	princ_str("];",symbol_value(VV[24]));
L137:
	if(((V7))==Cnil){
	goto L153;}
	(*LK16)(1,code_char('\12'))               /*  WT1             */;
	(*LK16)(1,code_char('\11'))               /*  WT1             */;
	princ_str("object ",symbol_value(VV[24]));
	{register int V9;                         /*  LCL             */
	V9= fix(number_plus((VV[25]->s.s_dbind),MAKE_FIXNUM(V8)));
	{register object V10;                     /*  ARGS            */
	V10= (V7);
L163:
	if(((V10))!=Cnil){
	goto L164;}
	goto L160;
L164:
	(*LK17)(1,MAKE_FIXNUM(V9))                /*  WT-LCL          */;
	if((CDR((V10)))==Cnil){
	goto L168;}
	princ_str(", ",symbol_value(VV[24]));
L168:
	V9= (V9)-(1);
	V10= CDR((V10));
	goto L163;
	}
	}
L160:
	princ_char(59,symbol_value(VV[24]));
L153:
	(*LK16)(1,code_char('\12'))               /*  WT1             */;
	(*LK16)(1,code_char('\11'))               /*  WT1             */;
	princ_str("int narg = ",symbol_value(VV[24]));
	if(((V6))==Cnil){
	goto L186;}
	VALUES(0) = (V4);
	goto L184;
L186:
	VALUES(0) = MAKE_FIXNUM(length((V2)));
L184:
	(*LK16)(1,VALUES(0))                      /*  WT1             */;
	princ_char(59,symbol_value(VV[24]));
	if(((V6))==Cnil){
	goto L191;}
	{int V9;                                  /*  LCL             */
	V9= fix((VV[25]->s.s_dbind));
	{object V10;
	register int V11;                         /*  I               */
	V10= MAKE_FIXNUM(V8);
	V11= 0;
L197:
	if(!(number_compare(MAKE_FIXNUM(V11),(V10))>=0)){
	goto L198;}
	goto L189;
L198:
	(*LK16)(1,code_char('\12'))               /*  WT1             */;
	(*LK16)(1,code_char('\11'))               /*  WT1             */;
	V9= (V9)+(1);
	(*LK17)(1,MAKE_FIXNUM(V9))                /*  WT-LCL          */;
	princ_str("=VALUES(",symbol_value(VV[24]));
	(*LK16)(1,MAKE_FIXNUM(V11))               /*  WT1             */;
	princ_str(");",symbol_value(VV[24]));
	V11= (V11)+1;
	goto L197;
	}
	}
L191:
	{object V13;
	register int V14;                         /*  I               */
	V13= MAKE_FIXNUM(V8);
	V14= 0;
L217:
	if(!(number_compare(MAKE_FIXNUM(V14),(V13))>=0)){
	goto L218;}
	goto L213;
L218:
	{object V16;
	(*LK18)(0)                                /*  NEXT-LCL        */;
	V16= list(2,VV[26],VALUES(0));
	bds_bind(VV[21],V16);                     /*  *DESTINATION*   */
	{object V17;
	V17= CAR((V2));
	V2= CDR((V2));
	VALUES(0) = (V17);
	}
	(*LK12)(1,VALUES(0))                      /*  C2EXPR*         */;
	bds_unwind1;
	}
	V14= (V14)+1;
	goto L217;
	}
L213:
	{register object V13;                     /*  VALS            */
	register int V14;                         /*  I               */
	bds_bind(VV[22],MAKE_FIXNUM(0));          /*  *INLINE-BLOCKS* */
	(*LK13)(1,(V2))                           /*  INLINE-ARGS     */;
	V13= VALUES(0);
	V14= 0;
L234:
	if(((V13))!=Cnil){
	goto L235;}
	(*LK14)(0)                                /*  CLOSE-INLINE-BLOCKS*/;
	bds_unwind1;
	goto L189;
L235:
	(*LK16)(1,code_char('\12'))               /*  WT1             */;
	(*LK16)(1,code_char('\11'))               /*  WT1             */;
	princ_str("args[",symbol_value(VV[24]));
	(*LK16)(1,MAKE_FIXNUM(V14))               /*  WT1             */;
	princ_str("]=",symbol_value(VV[24]));
	(*LK16)(1,CADR(CAR((V13))))               /*  WT1             */;
	princ_char(59,symbol_value(VV[24]));
	V13= CDR((V13));
	V14= (V14)+1;
	goto L234;
	}
L189:
	(*LK19)(6,(V5),CADDR(CDDR((V1))),(V3),Cnil,Cnil,VV[15])/*  C2LAMBDA-EXPR*/;
	(*LK16)(1,code_char('\12'))               /*  WT1             */;
	(*LK16)(1,code_char('\11'))               /*  WT1             */;
	princ_char(125,symbol_value(VV[24]));
	VALUES(0) = Cnil;
	RETURN(1);
	}
L119:
	RETURN((*LK20)(3,CAR((V5)),(V2),CADDR(CDDR((V1))))/*  C2LET   */);
	}
	}
}
/*	function definition for C2CALL-GLOBAL                         */
static L7(int narg, object V1, object V2, object V3, object V4, ...)
{ VT9 VLEX9 CLSR9
	bds_check;
	{int i=4;
	object V5;
	va_list args; va_start(args, V4);
	if (i==narg) goto L255;
	V5= va_arg(args, object);
	i++;
	goto L256;
L255:
	V5= Cnil;
L256:
	if((VV[23])==((V2))){
	goto L258;}
	if(((V1)!= VV[95]))goto L261;
	{register object V6;                      /*  ETYPE           */
	V6= (CADAR((V2)))->v.v_self[3];
	if(!(((V6))==(VV[27]))){
	goto L264;}
	V6= VV[28];
	if((VV[28])!=Cnil){
	goto L263;}
L264:
	if(!(type_of((V6))==t_cons)){
	goto L258;}
	if((CAR((V6)))==(VV[29])){
	goto L271;}
	if(!((CAR((V6)))==(VV[30]))){
	goto L258;}
L271:
	V6= CADR((V6));
	if(((V6))==Cnil){
	goto L258;}
L263:
	(*LK21)(2,(V4),(V6))                      /*  TYPE-AND        */;
	V6= VALUES(0);
	if(((V6))!=Cnil){
	goto L279;}
	(*LK22)(2,VV[31],CONS((V1),(V2)))         /*  CMPWARN         */;
	V6= Ct;
L279:
	V4= (V6);
	goto L258;
	}
L261:
	if(((V1)!= VV[98]))goto L285;
	{register object V7;                      /*  ETYPE           */
	V7= (CADR(CADR((V2))))->v.v_self[3];
	if(!(((V7))==(VV[27]))){
	goto L288;}
	V7= VV[28];
	if((VV[28])!=Cnil){
	goto L287;}
L288:
	if(!(type_of((V7))==t_cons)){
	goto L258;}
	if((CAR((V7)))==(VV[29])){
	goto L295;}
	if(!((CAR((V7)))==(VV[30]))){
	goto L258;}
L295:
	V7= CADR((V7));
	if(((V7))==Cnil){
	goto L258;}
L287:
	(*LK21)(2,(CADR(CAR((V2))))->v.v_self[3],(V7))/*  TYPE-AND    */;
	(*LK21)(2,(V4),VALUES(0))                 /*  TYPE-AND        */;
	V7= VALUES(0);
	if(((V7))!=Cnil){
	goto L304;}
	(*LK22)(2,VV[32],CONS((V1),(V2)))         /*  CMPWARN         */;
	V7= Ct;
L304:
	V4= (V7);
	elt_set(CADR(CAR((V2))),3,(V7));
	goto L258;
	}
L285:
L258:
	(*LK23)(1,(V1))                           /*  INLINE-POSSIBLE */;
	if(VALUES(0)==Cnil){
	goto L312;}
	if((VV[23])==((V2))){
	goto L312;}
	if(((VV[33]->s.s_dbind))==Cnil){
	goto L312;}
	if(!((CAR((VV[33]->s.s_dbind)))==((V1)))){
	goto L312;}
	(*LK24)(0)                                /*  LAST-CALL-P     */;
	if(VALUES(0)==Cnil){
	goto L312;}
	(*LK25)(0)                                /*  TAIL-RECURSION-POSSIBLE*/;
	if(VALUES(0)==Cnil){
	goto L312;}
	if(!((length((V2)))==(length(CDR((VV[33]->s.s_dbind)))))){
	goto L312;}
	bds_bind(VV[21],VV[34]);                  /*  *DESTINATION*   */
	(VV[36]->s.s_dbind)= number_plus((VV[36]->s.s_dbind),MAKE_FIXNUM(1));
	bds_bind(VV[35],CONS((VV[36]->s.s_dbind),Cnil));/*  *EXIT*    */
	bds_bind(VV[37],CONS((VV[35]->s.s_dbind),(VV[37]->s.s_dbind)));/*  *UNWIND-EXIT**/
	{object V6;
	object V7= CDR((VV[33]->s.s_dbind));
	if(V7==Cnil){
	VALUES(0) = Cnil;
	goto L330;}
	T0=V6=CONS(Cnil,Cnil);
L331:
	{object V8;                               /*  V               */
	CAR(V6)= CONS(CAR(V7),Cnil);
	}
	if((V7=CDR(V7))==Cnil){
	VALUES(0) = T0;
	goto L330;}
	V6=CDR(V6)=CONS(Cnil,Cnil);
	goto L331;}
L330:
	(*LK26)(2,VALUES(0),(V2))                 /*  C2PSETQ         */;
	if((CDR((VV[35]->s.s_dbind)))==Cnil){
	goto L333;}
	(*LK16)(1,code_char('\12'))               /*  WT1             */;
	princ_char(76,symbol_value(VV[24]));
	(*LK16)(1,CAR((VV[35]->s.s_dbind)))       /*  WT1             */;
	princ_char(58,symbol_value(VV[24]));
L333:
	(*LK27)(1,VV[38])                         /*  UNWIND-NO-EXIT  */;
	(*LK16)(1,code_char('\12'))               /*  WT1             */;
	(*LK16)(1,code_char('\11'))               /*  WT1             */;
	princ_str("goto TTL;",symbol_value(VV[24]));
	{int V6;
	V6=(*LK28)(2,VV[39],(V1))                 /*  CMPNOTE         */;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V6);}
L312:
	bds_bind(VV[22],MAKE_FIXNUM(0));          /*  *INLINE-BLOCKS* */
	if(!(((V2))==(VV[23]))){
	goto L348;}
	VALUES(0) = (V2);
	goto L346;
L348:
	(*LK13)(1,(V2))                           /*  INLINE-ARGS     */;
L346:
	L9(5,(V1),VALUES(0),(V3),(V4),(V5))       /*  CALL-GLOBAL     */;
	{int V7;
	V7=(*LK14)(0)                             /*  CLOSE-INLINE-BLOCKS*/;
	bds_unwind1;
	RETURN(V7);}
	}
}
/*	function definition for CALL-GLOBAL                           */
static L9(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT10 VLEX10 CLSR10
TTL:
	{register object V6;                      /*  FD              */
	V6= Cnil;
	(*LK23)(1,(V1))                           /*  INLINE-POSSIBLE */;
	if(VALUES(0)==Cnil){
	goto L352;}
	if((VV[23])==((V2))){
	goto L355;}
	if(((V3))!=Cnil){
	goto L355;}
	(*LK29)(3,(V1),(V2),(V4))                 /*  INLINE-FUNCTION */;
	V3= VALUES(0);
	if(((V3))==Cnil){
	goto L355;}
	(*LK30)(1,(V3))                           /*  FIX-LOC         */;
	RETURN((*LK31)(1,VALUES(0))               /*  UNWIND-EXIT     */);
L355:
	V6= getf((V1)->s.s_plist,VV[40],Cnil);
	if(((V6))==Cnil){
	goto L364;}
	princ_char(10,symbol_value(VV[41]));
	princ_str("int ",symbol_value(VV[41]));
	(*LK32)(1,(V6))                           /*  WT-H1           */;
	princ_str("();",symbol_value(VV[41]));
	L12(4,(V1),(V6),(V2),(V5))                /*  CALL-LOC        */;
	RETURN((*LK31)(1,VALUES(0))               /*  UNWIND-EXIT     */);
L364:
	V6= assql((V1),(VV[42]->s.s_dbind));
	if(((V6))==Cnil){
	goto L374;}
	Lformat(3,Cnil,VV[43],CDR((V6)))          /*  FORMAT          */;
	L12(4,(V1),VALUES(0),(V2),(V5))           /*  CALL-LOC        */;
	RETURN((*LK31)(1,VALUES(0))               /*  UNWIND-EXIT     */);
L374:
	if(((VV[0]->s.s_dbind))==Cnil){
	goto L380;}
	RETURN(LC10(3,(V1),(V2),(V5))             /*  EMIT-LINKING-CALL*/);
L380:
	RETURN(L14(5,(V1),(V2),(V3),Ct,(V5))      /*  C2CALL-UNKNOWN-GLOBAL*/);
L352:
	RETURN(LC10(3,(V1),(V2),(V5))             /*  EMIT-LINKING-CALL*/);
	}
}
/*	local function EMIT-LINKING-CALL                              */
static LC10(int narg, object V1, object V2, object V3)
{ VT11 VLEX11 CLSR11
TTL:
	{register object V4;                      /*  I               */
	V4= Cnil;
	if(((VV[44]->s.s_dbind))!=Cnil){
	goto L385;}
	(*LK33)(1,(V1))                           /*  ADD-SYMBOL      */;
	(VV[44]->s.s_dbind)= CONS(list(3,(V1),MAKE_FIXNUM(0),VALUES(0)),(VV[44]->s.s_dbind));
	V4= MAKE_FIXNUM(0);
	goto L383;
L385:
	V4= assql((V1),(VV[44]->s.s_dbind));
	if(((V4))==Cnil){
	goto L392;}
	V4= CADR((V4));
	goto L383;
L392:
	V4= one_plus(CADAR((VV[44]->s.s_dbind)));
	(*LK33)(1,(V1))                           /*  ADD-SYMBOL      */;
	(VV[44]->s.s_dbind)= CONS(list(3,(V1),(V4),VALUES(0)),(VV[44]->s.s_dbind));
L383:
	Lformat(3,Cnil,VV[45],(V4))               /*  FORMAT          */;
	L12(4,(V1),VALUES(0),(V2),(V3))           /*  CALL-LOC        */;
	RETURN((*LK31)(1,VALUES(0))               /*  UNWIND-EXIT     */);
	}
}
/*	function definition for SAVE-FUNOB                            */
static L11(int narg, object V1)
{ VT12 VLEX12 CLSR12
	bds_check;
TTL:
	{object V2= CAR((V1));
	if((V2!= VV[15])
	&& (V2!= VV[110])
	&& (V2!= VV[5]))goto L402;
	VALUES(0) = Cnil;
	RETURN(1);
L402:
	if((V2!= VV[7]))goto L403;
	(*LK23)(1,CADDR((V1)))                    /*  INLINE-POSSIBLE */;
	if(VALUES(0)==Cnil){
	goto L404;}
	if((getf(CADDR((V1))->s.s_plist,VV[40],Cnil))!=Cnil){
	goto L405;}
	if((assql(CADDR((V1)),(VV[42]->s.s_dbind)))!=Cnil){
	goto L405;}
L404:
	{object V3;                               /*  TEMP            */
	(*LK11)(0)                                /*  NEXT-TEMP       */;
	V3= list(2,VV[20],VALUES(0));
	if(((VV[46]->s.s_dbind))==Cnil){
	goto L415;}
	(*LK16)(1,code_char('\12'))               /*  WT1             */;
	(*LK16)(1,code_char('\11'))               /*  WT1             */;
	(*LK16)(1,(V3))                           /*  WT1             */;
	princ_str("=symbol_function(VV[",symbol_value(VV[24]));
	(*LK33)(1,CADDR((V1)))                    /*  ADD-SYMBOL      */;
	(*LK16)(1,VALUES(0))                      /*  WT1             */;
	princ_str("]);",symbol_value(VV[24]));
	goto L413;
L415:
	(*LK16)(1,code_char('\12'))               /*  WT1             */;
	(*LK16)(1,code_char('\11'))               /*  WT1             */;
	(*LK16)(1,(V3))                           /*  WT1             */;
	princ_str("=VV[",symbol_value(VV[24]));
	(*LK33)(1,CADDR((V1)))                    /*  ADD-SYMBOL      */;
	(*LK16)(1,VALUES(0))                      /*  WT1             */;
	princ_str("]->s.s_gfdef;",symbol_value(VV[24]));
L413:
	VALUES(0) = (V3);
	RETURN(1);
	}
L405:
	VALUES(0) = Cnil;
	RETURN(1);
L403:
	if((V2!= VV[17]))goto L431;
	{object V4;                               /*  TEMP            */
	(*LK11)(0)                                /*  NEXT-TEMP       */;
	V4= list(2,VV[20],VALUES(0));
	bds_bind(VV[21],(V4));                    /*  *DESTINATION*   */
	(*LK12)(1,CADDR((V1)))                    /*  C2EXPR*         */;
	{int V5;
	VALUES(0)=(V4);
	V5=1;
	bds_unwind1;
	RETURN(V5);}
	}
L431:
	RETURN((*LK15)(0)                         /*  BABOON          */);}
}
/*	function definition for CALL-LOC                              */
static L12(int narg, object V1, object V2, object V3, ...)
{ VT13 VLEX13 CLSR13
	{int i=3;
	object V4;
	va_list args; va_start(args, V3);
	if (i==narg) goto L435;
	V4= va_arg(args, object);
	i++;
	goto L436;
L435:
	V4= Cnil;
L436:
	if(!((VV[23])==((V3)))){
	goto L439;}
	if(!(type_of((V2))==t_string)){
	goto L443;}
	T0= VV[48];
	goto L441;
L443:
	T0= VV[49];
L441:
	VALUES(0) = list(5,VV[47],T0,(V4),list(2,(V2),VV[50]),(V1));
	RETURN(1);
L439:
	{int V5= length((V3));
	(*LK34)(2,(V3),Cnil)                      /*  COERCE-LOCS     */;
	VALUES(0) = list(5,VV[47],(V2),MAKE_FIXNUM(V5),VALUES(0),(V1));
	RETURN(1);}
	}
}
/*	function definition for WT-CALL                               */
static L13(int narg, object V1, object V2, object V3, ...)
{ VT14 VLEX14 CLSR14
	{int i=3;
	object V4;
	va_list args; va_start(args, V3);
	if (i==narg) goto L446;
	V4= va_arg(args, object);
	i++;
	goto L447;
L446:
	V4= Cnil;
L447:
	(*LK16)(1,(V1))                           /*  WT1             */;
	princ_char(40,symbol_value(VV[24]));
	(*LK16)(1,(V2))                           /*  WT1             */;
	{register object V5;
	object V6;                                /*  ARG             */
	V5= (V3);
	V6= Cnil;
L457:
	if(!((V5)==Cnil)){
	goto L458;}
	goto L453;
L458:
	V6= CAR((V5));
	princ_char(44,symbol_value(VV[24]));
	(*LK16)(1,(V6))                           /*  WT1             */;
	V5= CDR((V5));
	goto L457;
	}
L453:
	princ_char(41,symbol_value(VV[24]));
	if(((V4))==Cnil){
	goto L472;}
	RETURN((*LK35)(1,(V4))                    /*  WT-COMMENT      */);
L472:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for C2CALL-UNKNOWN-GLOBAL                 */
static L14(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT15 VLEX15 CLSR15
TTL:
	if(((V3))!=Cnil){
	goto L474;}
	if(((VV[51]->s.s_dbind))==Cnil){
	goto L479;}
	(*LK33)(1,(V1))                           /*  ADD-SYMBOL      */;
	V3= list(2,VV[52],VALUES(0));
	goto L477;
L479:
	if(((VV[46]->s.s_dbind))==Cnil){
	goto L484;}
	T0= VV[53];
	goto L482;
L484:
	T0= VV[54];
L482:
	(*LK33)(1,(V1))                           /*  ADD-SYMBOL      */;
	Lformat(3,Cnil,T0,VALUES(0))              /*  FORMAT          */;
	V3= VALUES(0);
L477:
L474:
	if(!(((V2))==(VV[23]))){
	goto L489;}
	VALUES(0) = list(5,VV[47],VV[55],(V5),list(2,(V3),VV[56]),(V1));
	goto L487;
L489:
	L12(3,(V1),VV[57],CONS(list(2,Ct,(V3)),(V2)))/*  CALL-LOC     */;
L487:
	RETURN((*LK31)(1,VALUES(0))               /*  UNWIND-EXIT     */);
}
static LKF35(int narg, ...) {TRAMPOLINK(VV[112],&LK35);}
static LKF34(int narg, ...) {TRAMPOLINK(VV[111],&LK34);}
static LKF33(int narg, ...) {TRAMPOLINK(VV[109],&LK33);}
static LKF32(int narg, ...) {TRAMPOLINK(VV[108],&LK32);}
static LKF31(int narg, ...) {TRAMPOLINK(VV[107],&LK31);}
static LKF30(int narg, ...) {TRAMPOLINK(VV[106],&LK30);}
static LKF29(int narg, ...) {TRAMPOLINK(VV[105],&LK29);}
static LKF28(int narg, ...) {TRAMPOLINK(VV[104],&LK28);}
static LKF27(int narg, ...) {TRAMPOLINK(VV[103],&LK27);}
static LKF26(int narg, ...) {TRAMPOLINK(VV[102],&LK26);}
static LKF25(int narg, ...) {TRAMPOLINK(VV[101],&LK25);}
static LKF24(int narg, ...) {TRAMPOLINK(VV[100],&LK24);}
static LKF23(int narg, ...) {TRAMPOLINK(VV[99],&LK23);}
static LKF22(int narg, ...) {TRAMPOLINK(VV[97],&LK22);}
static LKF21(int narg, ...) {TRAMPOLINK(VV[96],&LK21);}
static LKF20(int narg, ...) {TRAMPOLINK(VV[94],&LK20);}
static LKF19(int narg, ...) {TRAMPOLINK(VV[93],&LK19);}
static LKF18(int narg, ...) {TRAMPOLINK(VV[92],&LK18);}
static LKF17(int narg, ...) {TRAMPOLINK(VV[91],&LK17);}
static LKF16(int narg, ...) {TRAMPOLINK(VV[90],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[89],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[88],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[87],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[86],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[85],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[84],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[83],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[82],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[81],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[80],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[78],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[77],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[75],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[74],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[73],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[72],&LK0);}
