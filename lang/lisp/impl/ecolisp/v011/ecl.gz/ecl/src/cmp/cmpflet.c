
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "cmpflet.h"
init_cmpflet(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_cmpflet; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	VV[0]->s.s_stype=(short)stp_special;
	if(VV[0]->s.s_dbind == OBJNULL){
	(VV[0]->s.s_dbind)= Cnil;}
	MF0(VV[41],L1);
	VV[48] = make_cfun(LC3,Cnil,&Cblock);
	MF0(VV[49],L2);
	MF0(VV[45],L4);
	MF0(VV[42],L5);
	MF0(VV[43],L6);
	MF0(VV[50],L7);
	MF0(VV[51],L8);
	MF0(VV[46],L9);
	MF0(VV[52],L11);
	putprop(VV[1],VV[41],VV[40]);
	putprop(VV[18],VV[42],VV[40]);
	putprop(VV[22],VV[43],VV[40]);
	putprop(VV[10],VV[45],VV[44]);
	putprop(VV[24],VV[46],VV[44]);
	VALUES(0) = (VV[52]->s.s_gfdef);
	putprop(VV[24],VALUES(0),VV[47]);
}
/*	local function CLOSURE                                        */
static LC3(int narg, object V1)
{ VT3 VLEX3 CLSR3
	(*LK0)(1,(V1))                            /*  FUN-P           */;
	if(VALUES(0)!=Cnil){
	goto L9;}
	VALUES(0) = Cnil;
	RETURN(1);
L9:
	VALUES(0) = ((V1))->v.v_self[2];
	RETURN(1);
}
/*	function definition for C1FLET                                */
static L1(int narg, object V1)
{ VT4 VLEX4 CLSR4
	bds_check;
TTL:
	{object V2;                               /*  BODY            */
	object V3;                                /*  SS              */
	object V4;                                /*  TS              */
	object V5;                                /*  IS              */
	object V6;                                /*  OTHER-DECL      */
	object V7;                                /*  INFO            */
	object V8;                                /*  DEFS1           */
	object V9;                                /*  LOCAL-FUNS      */
	V2= Cnil;
	V3= Cnil;
	V4= Cnil;
	V5= Cnil;
	V6= Cnil;
	V7= Cnil;
	V8= Cnil;
	V9= Cnil;
	if(!((V1)==Cnil)){
	goto L19;}
	(*LK1)(3,VV[1],MAKE_FIXNUM(1),MAKE_FIXNUM(0))/*  TOO-FEW-ARGS */;
L19:
	bds_bind(VV[0],(VV[0]->s.s_dbind));       /*  *FUNS*          */
	{volatile object V10;
	volatile object V11;                      /*  DEF             */
	V10= CAR((V1));
	V11= Cnil;
L27:
	if(!((V10)==Cnil)){
	goto L28;}
	goto L23;
L28:
	V11= CAR((V10));
	if((V11)==Cnil){
	goto L34;}
	if(!(type_of(CAR((V11)))==t_symbol)){
	goto L34;}
	if(!(CDR((V11))==Cnil)){
	goto L33;}
L34:
	(*LK2)(2,VV[2],(V11))                     /*  CMPERR          */;
L33:
	{object V13;                              /*  FUN             */
	(*LK3)(2,VV[3],CAR((V11)))                /*  MAKE-FUN        */;
	V13= VALUES(0);
	(VV[0]->s.s_dbind)= CONS((V13),(VV[0]->s.s_dbind));
	V8= CONS(list(2,(V13),CDR((V11))),(V8));
	}
	V10= CDR((V10));
	goto L27;
	}
L23:
	{ int V10;
	V10=(*LK4)(2,CDR((V1)),Ct)                /*  C1BODY          */;
	if (V10>0) {
	V2= VALUES(0);
	V10--;
	} else {
	V2= Cnil;}
	if (V10>0) {
	V3= VALUES(1);
	V10--;
	} else {
	V3= Cnil;}
	if (V10>0) {
	V4= VALUES(2);
	V10--;
	} else {
	V4= Cnil;}
	if (V10>0) {
	V5= VALUES(3);
	V10--;
	} else {
	V5= Cnil;}
	if (V10>0) {
	V6= VALUES(4);
	} else {
	V6= Cnil;}
	
	}
	bds_bind(VV[4],(VV[4]->s.s_dbind));       /*  *VARS*          */
	(*LK5)(1,(V3))                            /*  C1ADD-GLOBALS   */;
	(*LK6)(3,Cnil,(V4),(V5))                  /*  CHECK-VDECL     */;
	(*LK7)(2,(V6),(V2))                       /*  C1DECL-BODY     */;
	V2= VALUES(0);
	bds_unwind1;
	(*LK8)(1,CADR((V2)))                      /*  COPY-INFO       */;
	V7= VALUES(0);
	bds_unwind1;
	{volatile object V10;
	volatile object V11;                      /*  DEF             */
	V10= nreverse((V8));
	V11= Cnil;
L59:
	if(!((V10)==Cnil)){
	goto L60;}
	goto L55;
L60:
	V11= CAR((V10));
	{register object V13;                     /*  FUN             */
	V13= CAR((V11));
	if((((V13))->v.v_self[2])==Cnil){
	goto L69;}
	{object V14;
	object V15;
	object V16;
	object V17;
	V14= CONS(VV[5],(VV[4]->s.s_dbind));
	V15= CONS(VV[5],(VV[0]->s.s_dbind));
	V16= CONS(VV[5],(VV[6]->s.s_dbind));
	V17= CONS(VV[5],(VV[7]->s.s_dbind));
	bds_bind(VV[4],V14);                      /*  *VARS*          */
	bds_bind(VV[0],V15);                      /*  *FUNS*          */
	bds_bind(VV[6],V16);                      /*  *BLOCKS*        */
	bds_bind(VV[7],V17);                      /*  *TAGS*          */
	{object V18;                              /*  LAM             */
	(*LK9)(2,CADR((V11)),((V13))->v.v_self[0])/*  C1LAMBDA-EXPR   */;
	V18= VALUES(0);
	(*LK10)(3,(V7),CADR((V18)),VV[5])         /*  ADD-INFO        */;
	V9= CONS(list(2,(V13),(V18)),(V9));
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	goto L67;
	}
	}
L69:
	if(!(number_compare(MAKE_FIXNUM(0),((V13))->v.v_self[1])<0)){
	goto L67;}
	{object V19;
	object V20;
	object V21;
	object V22;
	V19= CONS(VV[8],(VV[4]->s.s_dbind));
	V20= CONS(VV[8],(VV[0]->s.s_dbind));
	V21= CONS(VV[8],(VV[6]->s.s_dbind));
	V22= CONS(VV[8],(VV[7]->s.s_dbind));
	bds_bind(VV[4],V19);                      /*  *VARS*          */
	bds_bind(VV[0],V20);                      /*  *FUNS*          */
	bds_bind(VV[6],V21);                      /*  *BLOCKS*        */
	bds_bind(VV[7],V22);                      /*  *TAGS*          */
	{object V23;                              /*  LAM             */
	(*LK9)(2,CADR((V11)),((V13))->v.v_self[0])/*  C1LAMBDA-EXPR   */;
	V23= VALUES(0);
	(*LK10)(3,(V7),CADR((V23)),VV[8])         /*  ADD-INFO        */;
	V9= CONS(list(2,(V13),(V23)),(V9));
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	}
	}
L67:
	if(!(number_compare(MAKE_FIXNUM(0),((V13))->v.v_self[1])<0)){
	goto L65;}
	(VV[9]->s.s_dbind)= number_plus((VV[9]->s.s_dbind),MAKE_FIXNUM(1));
	elt_set((V13),4,(VV[9]->s.s_dbind));
	}
L65:
	V10= CDR((V10));
	goto L59;
	}
L55:
	if(((V9))==Cnil){
	goto L94;}
	{object V10= nreverse((V9));
	VALUES(0) = list(5,VV[10],(V7),(V10),(V2),Cnil);
	RETURN(1);}
L94:
	VALUES(0) = (V2);
	RETURN(1);
	}
}
/*	function definition for CLOSURE-P                             */
static L2(int narg, object V1)
{ VT5 VLEX5 CLSR5
TTL:
	{object V2;                               /*  INFO            */
	V2= CADR((V1));
	T0= (VV[64]->s.s_gfdef);
	(*LK11)(2,T0,((V2))->v.v_self[2])         /*  SOME            */;
	if(VALUES(0)==Cnil)goto L97;
	RETURN(1);
L97:
	T0= VV[48];
	RETURN((*LK11)(2,T0,((V2))->v.v_self[6])  /*  SOME            */);
	}
}
/*	function definition for C2LOCALS                              */
static L4(int narg, object V1, object V2, object V3)
{ VT6 VLEX6 CLSR6
	bds_check;
TTL:
	{object V4;                               /*  BLOCK-P         */
	object V5;                                /*  LEVEL           */
	object V6;                                /*  ENV-GROWS       */
	V4= Cnil;
	if(!(number_compare(MAKE_FIXNUM(0),(VV[11]->s.s_dbind))<0)){
	goto L104;}
	V5= one_plus((VV[12]->s.s_dbind));
	goto L102;
L104:
	V5= (VV[12]->s.s_dbind);
L102:
	bds_bind(VV[13],(VV[13]->s.s_dbind));     /*  *ENV*           */
	bds_bind(VV[14],(VV[14]->s.s_dbind));     /*  *ENV-LVL*       */
	V6= Cnil;
	{volatile object V7;
	volatile object V8;                       /*  DEF             */
	V7= (V1);
	V8= Cnil;
L111:
	if(!((V7)==Cnil)){
	goto L112;}
	goto L107;
L112:
	V8= CAR((V7));
	{register object V10;                     /*  FUN             */
	register object V11;                      /*  VAR             */
	object V12;                               /*  PREVIOUS        */
	V10= CAR((V8));
	V11= ((V10))->v.v_self[8];
	V12= Cnil;
	L2(1,CADR((V8)))                          /*  CLOSURE-P       */;
	elt_set((V10),7,VALUES(0));
	(*LK12)(3,(V5),(V10),CADR((V8)))          /*  NEW-LOCAL       */;
	V12= VALUES(0);
	if(((V12))==Cnil){
	goto L123;}
	elt_set((V10),5,((V12))->v.v_self[5]);
	elt_set((V10),6,((V12))->v.v_self[6]);
L123:
	if(((V11))==Cnil){
	goto L117;}
	if((VV[15])==(((V11))->v.v_self[4])){
	goto L130;}
	(*LK13)(0)                                /*  NEXT-LCL        */;
	elt_set((V11),5,VALUES(0));
	if(((V4))!=Cnil){
	goto L135;}
	V4= Ct;
	(*LK14)(1,code_char('\12'))               /*  WT1             */;
	(*LK14)(1,code_char('\11'))               /*  WT1             */;
	princ_str("{ ",symbol_value(VV[16]));
L135:
	princ_str("object ",symbol_value(VV[16]));
	(*LK15)(1,((V11))->v.v_self[5])           /*  WT-LCL          */;
	princ_char(59,symbol_value(VV[16]));
L130:
	if(((V6))!=Cnil){
	goto L117;}
	V6= ((V11))->v.v_self[2];
	}
L117:
	V7= CDR((V7));
	goto L111;
	}
L107:
	(*LK16)(1,(V6))                           /*  ENV-GROWS       */;
	if(VALUES(0)==Cnil){
	goto L153;}
	if(((V4))!=Cnil){
	goto L156;}
	(*LK14)(1,code_char('\12'))               /*  WT1             */;
	(*LK14)(1,code_char('\11'))               /*  WT1             */;
	princ_str("{ ",symbol_value(VV[16]));
	V4= Ct;
L156:
	{object V7;                               /*  ENV-LVL         */
	V7= (VV[14]->s.s_dbind);
	princ_str("object env",symbol_value(VV[16]));
	(VV[14]->s.s_dbind)= number_plus((VV[14]->s.s_dbind),MAKE_FIXNUM(1));
	(*LK14)(1,(VV[14]->s.s_dbind))            /*  WT1             */;
	princ_str(" = env",symbol_value(VV[16]));
	(*LK14)(1,(V7))                           /*  WT1             */;
	princ_char(59,symbol_value(VV[16]));
	}
L153:
	{volatile object V7;
	volatile object V8;                       /*  DEF             */
	V7= (V1);
	V8= Cnil;
L174:
	if(!((V7)==Cnil)){
	goto L175;}
	goto L170;
L175:
	V8= CAR((V7));
	{object V10;                              /*  FUN             */
	register object V11;                      /*  VAR             */
	V10= CAR((V8));
	V11= ((V10))->v.v_self[8];
	if(((V11))==Cnil){
	goto L180;}
	{object V12;                              /*  CLOSURE         */
	V12= list(2,VV[17],(V10));
	if(((V3))==Cnil){
	goto L187;}
	{object V13;
	V13= (V10);
	elt_set((V13),6,number_plus(((V13))->v.v_self[6],MAKE_FIXNUM(1)));
	}
	(*LK17)(2,Cnil,(V11))                     /*  BIND            */;
	(*LK14)(1,code_char('\12'))               /*  WT1             */;
	(*LK14)(1,code_char('\11'))               /*  WT1             */;
	(*LK18)(1,(V11))                          /*  WT-VAR          */;
	princ_char(61,symbol_value(VV[16]));
	(*LK14)(1,(V12))                          /*  WT1             */;
	princ_char(59,symbol_value(VV[16]));
	goto L180;
L187:
	(*LK17)(2,(V12),(V11))                    /*  BIND            */;
	}
	}
L180:
	V7= CDR((V7));
	goto L174;
	}
L170:
	bds_bind(VV[12],(V5));                    /*  *LEVEL*         */
	(*LK19)(1,(V2))                           /*  C2EXPR          */;
	bds_unwind1;
	if(((V4))==Cnil){
	goto L204;}
	(*LK14)(1,code_char('\12'))               /*  WT1             */;
	(*LK14)(1,code_char('\11'))               /*  WT1             */;
	princ_char(125,symbol_value(VV[16]));
	{int V7;
	VALUES(0)=Cnil;
	V7=1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V7);}
L204:
	{int V8;
	VALUES(0)=Cnil;
	V8=1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V8);}
	}
}
/*	function definition for C1LABELS                              */
static L5(int narg, object V1)
{ VT7 VLEX7 CLSR7
	bds_check;
TTL:
	{object V2;                               /*  BODY            */
	object V3;                                /*  SS              */
	object V4;                                /*  TS              */
	object V5;                                /*  IS              */
	object V6;                                /*  OTHER-DECL      */
	object V7;                                /*  INFO            */
	object V8;                                /*  DEFS1           */
	register object V9;                       /*  LOCAL-FUNS      */
	object V10;                               /*  FNAMES          */
	V2= Cnil;
	V3= Cnil;
	V4= Cnil;
	V5= Cnil;
	V6= Cnil;
	V7= Cnil;
	V8= Cnil;
	V9= Cnil;
	V10= Cnil;
	bds_bind(VV[0],(VV[0]->s.s_dbind));       /*  *FUNS*          */
	if(!((V1)==Cnil)){
	goto L218;}
	(*LK1)(3,VV[18],MAKE_FIXNUM(1),MAKE_FIXNUM(0))/*  TOO-FEW-ARGS*/;
L218:
	{volatile object V11;
	volatile object V12;                      /*  DEF             */
	V11= CAR((V1));
	V12= Cnil;
L225:
	if(!((V11)==Cnil)){
	goto L226;}
	goto L221;
L226:
	V12= CAR((V11));
	if((V12)==Cnil){
	goto L232;}
	if(!(type_of(CAR((V12)))==t_symbol)){
	goto L232;}
	if(!(CDR((V12))==Cnil)){
	goto L231;}
L232:
	(*LK2)(2,VV[19],(V12))                    /*  CMPERR          */;
L231:
	if((memql(CAR((V12)),(V10)))==Cnil){
	goto L238;}
	(*LK2)(2,VV[20],CAR((V12)))               /*  CMPERR          */;
L238:
	V10= CONS(CAR((V12)),(V10));
	{object V14;                              /*  FUN             */
	(*LK3)(2,VV[3],CAR((V12)))                /*  MAKE-FUN        */;
	V14= VALUES(0);
	(VV[0]->s.s_dbind)= CONS((V14),(VV[0]->s.s_dbind));
	V8= CONS(list(4,(V14),Cnil,Cnil,CDR((V12))),(V8));
	}
	V11= CDR((V11));
	goto L225;
	}
L221:
	V8= nreverse((V8));
	{ int V11;
	V11=(*LK4)(2,CDR((V1)),Ct)                /*  C1BODY          */;
	if (V11>0) {
	V2= VALUES(0);
	V11--;
	} else {
	V2= Cnil;}
	if (V11>0) {
	V3= VALUES(1);
	V11--;
	} else {
	V3= Cnil;}
	if (V11>0) {
	V4= VALUES(2);
	V11--;
	} else {
	V4= Cnil;}
	if (V11>0) {
	V5= VALUES(3);
	V11--;
	} else {
	V5= Cnil;}
	if (V11>0) {
	V6= VALUES(4);
	} else {
	V6= Cnil;}
	
	}
	bds_bind(VV[4],(VV[4]->s.s_dbind));       /*  *VARS*          */
	(*LK5)(1,(V3))                            /*  C1ADD-GLOBALS   */;
	(*LK6)(3,Cnil,(V4),(V5))                  /*  CHECK-VDECL     */;
	(*LK7)(2,(V6),(V2))                       /*  C1DECL-BODY     */;
	V2= VALUES(0);
	bds_unwind1;
	(*LK8)(1,CADR((V2)))                      /*  COPY-INFO       */;
	V7= VALUES(0);
	{volatile object V11;                     /*  NONE-PROCESSED  */
	volatile object V12;                      /*  FUN             */
	V11= Cnil;
	V12= Cnil;
L263:
	if(((V11))==Cnil){
	goto L264;}
	goto L261;
L264:
	V11= Ct;
	{volatile object V14;
	volatile object V15;                      /*  DEF             */
	V14= (V8);
	V15= Cnil;
L273:
	if(!((V14)==Cnil)){
	goto L274;}
	goto L269;
L274:
	V15= CAR((V14));
	V12= CAR((V15));
	if(!(number_compare(MAKE_FIXNUM(0),((V12))->v.v_self[1])<0)){
	goto L281;}
	if((((V12))->v.v_self[8])!=Cnil){
	goto L281;}
	if((CADR((V15)))!=Cnil){
	goto L281;}
	V11= Cnil;
	{object V17;
	object V18;
	V17= (V15);
	V18= Ct;
	CAR(CDR((V17))) = (V18);
	}
	{object V17;
	object V18;
	object V19;
	object V20;
	V17= CONS(VV[8],(VV[4]->s.s_dbind));
	V18= CONS(VV[8],(VV[0]->s.s_dbind));
	V19= CONS(VV[8],(VV[6]->s.s_dbind));
	V20= CONS(VV[8],(VV[7]->s.s_dbind));
	bds_bind(VV[4],V17);                      /*  *VARS*          */
	bds_bind(VV[0],V18);                      /*  *FUNS*          */
	bds_bind(VV[6],V19);                      /*  *BLOCKS*        */
	bds_bind(VV[7],V20);                      /*  *TAGS*          */
	{object V21;                              /*  LAM             */
	(*LK9)(2,CADDDR((V15)),((V12))->v.v_self[0])/*  C1LAMBDA-EXPR */;
	V21= VALUES(0);
	(*LK10)(3,(V7),CADR((V21)),VV[8])         /*  ADD-INFO        */;
	V9= CONS(list(2,(V12),(V21)),(V9));
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	}
	}
L281:
	V14= CDR((V14));
	goto L273;
	}
L269:
	goto L263;
	}
L261:
	{volatile object V11;                     /*  NONE-PROCESSED  */
	volatile object V12;                      /*  FUN             */
	V11= Cnil;
	V12= Cnil;
L308:
	if(((V11))==Cnil){
	goto L309;}
	goto L306;
L309:
	V11= Ct;
	{volatile object V14;
	volatile object V15;                      /*  DEF             */
	V14= (V8);
	V15= Cnil;
L318:
	if(!((V14)==Cnil)){
	goto L319;}
	goto L314;
L319:
	V15= CAR((V14));
	V12= CAR((V15));
	if((((V12))->v.v_self[2])==Cnil){
	goto L326;}
	if((CADDR((V15)))!=Cnil){
	goto L326;}
	V11= Cnil;
	{object V17;
	object V18;
	V17= (V15);
	V18= Ct;
	CAR(CDDR((V17))) = (V18);
	}
	if((CADR((V15)))==Cnil){
	goto L337;}
	VALUES(0) = (VV[74]->s.s_gfdef);
	(*LK20)(4,(V12),(V9),VV[21],VALUES(0))    /*  DELETE          */;
	V9= VALUES(0);
L337:
	{object V17;
	object V18;
	object V19;
	object V20;
	V17= CONS(VV[5],(VV[4]->s.s_dbind));
	V18= CONS(VV[5],(VV[0]->s.s_dbind));
	V19= CONS(VV[5],(VV[6]->s.s_dbind));
	V20= CONS(VV[5],(VV[7]->s.s_dbind));
	bds_bind(VV[4],V17);                      /*  *VARS*          */
	bds_bind(VV[0],V18);                      /*  *FUNS*          */
	bds_bind(VV[6],V19);                      /*  *BLOCKS*        */
	bds_bind(VV[7],V20);                      /*  *TAGS*          */
	{object V21;                              /*  LAM             */
	(*LK9)(2,CADDDR((V15)),((V12))->v.v_self[0])/*  C1LAMBDA-EXPR */;
	V21= VALUES(0);
	(*LK10)(3,(V7),CADR((V21)),VV[5])         /*  ADD-INFO        */;
	V9= CONS(list(2,(V12),(V21)),(V9));
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	}
	}
L326:
	V14= CDR((V14));
	goto L318;
	}
L314:
	goto L308;
	}
L306:
	{volatile object V11;
	volatile object V12;                      /*  DEF             */
	V11= (V8);
	V12= Cnil;
L358:
	if(!((V11)==Cnil)){
	goto L359;}
	goto L354;
L359:
	V12= CAR((V11));
	{object V14= CAR((V12));
	(VV[9]->s.s_dbind)= number_plus((VV[9]->s.s_dbind),MAKE_FIXNUM(1));
	elt_set((V14),4,(VV[9]->s.s_dbind));}
	V11= CDR((V11));
	goto L358;
	}
L354:
	if(((V9))==Cnil){
	goto L370;}
	{int V11;
	VALUES(0)=list(5,VV[10],(V7),(V9),(V2),Ct);
	V11=1;
	bds_unwind1;
	RETURN(V11);}
L370:
	{int V12;
	VALUES(0)=(V2);
	V12=1;
	bds_unwind1;
	RETURN(V12);}
	}
}
/*	function definition for C1MACROLET                            */
static L6(int narg, object V1)
{ VT8 VLEX8 CLSR8
	bds_check;
TTL:
	bds_bind(VV[0],(VV[0]->s.s_dbind));       /*  *FUNS*          */
	bds_bind(VV[4],(VV[4]->s.s_dbind));       /*  *VARS*          */
	if(!((V1)==Cnil)){
	goto L372;}
	(*LK1)(3,VV[22],MAKE_FIXNUM(1),MAKE_FIXNUM(0))/*  TOO-FEW-ARGS*/;
L372:
	{volatile object V2;
	volatile object V3;                       /*  DEF             */
	V2= CAR((V1));
	V3= Cnil;
L379:
	if(!((V2)==Cnil)){
	goto L380;}
	goto L375;
L380:
	V3= CAR((V2));
	if((V3)==Cnil){
	goto L386;}
	if(!(type_of(CAR((V3)))==t_symbol)){
	goto L386;}
	if(!(CDR((V3))==Cnil)){
	goto L385;}
L386:
	(*LK2)(2,VV[23],(V3))                     /*  CMPERR          */;
L385:
	{object V5= CAR((V3));
	(*LK21)(3,CAR((V3)),CADR((V3)),CDDR((V3)))/*  EXPAND-DEFMACRO */;
	(VV[0]->s.s_dbind)= CONS(list(2,(V5),VALUES(0)),(VV[0]->s.s_dbind));}
	V2= CDR((V2));
	goto L379;
	}
L375:
	{ int V2;
	object V3;                                /*  BODY            */
	object V4;                                /*  SS              */
	object V5;                                /*  TS              */
	object V6;                                /*  IS              */
	object V7;                                /*  OTHER-DECL      */
	V2=(*LK4)(2,CDR((V1)),Ct)                 /*  C1BODY          */;
	if (V2--==0) goto L399;
	V3= VALUES(0);
	if (V2--==0) goto L400;
	V4= VALUES(1);
	if (V2--==0) goto L401;
	V5= VALUES(2);
	if (V2--==0) goto L402;
	V6= VALUES(3);
	if (V2--==0) goto L403;
	V7= VALUES(4);
	goto L404;
L399:
	V3= Cnil;
L400:
	V4= Cnil;
L401:
	V5= Cnil;
L402:
	V6= Cnil;
L403:
	V7= Cnil;
L404:
	(*LK5)(1,(V4))                            /*  C1ADD-GLOBALS   */;
	(*LK6)(3,Cnil,(V5),(V6))                  /*  CHECK-VDECL     */;
	{int V8;
	V8=(*LK7)(2,(V7),(V3))                    /*  C1DECL-BODY     */;
	bds_unwind1;
	bds_unwind1;
	RETURN(V8);}}
}
/*	function definition for C1CALL-LOCAL                          */
static L7(int narg, object V1)
{ VT9 VLEX9 CLSR9
TTL:
	{register object V2;                      /*  CCB             */
	V2= Cnil;
	{volatile object V3;
	volatile object V4;                       /*  FUN             */
	V3= (VV[0]->s.s_dbind);
	V4= Cnil;
L411:
	if(!((V3)==Cnil)){
	goto L412;}
	VALUES(0) = Cnil;
	RETURN(1);
L412:
	V4= CAR((V3));
	if(!(((V4))==(VV[5]))){
	goto L419;}
	V2= Ct;
	goto L417;
L419:
	if(!(type_of((V4))==t_cons)){
	goto L423;}
	if(!((CAR((V4)))==((V1)))){
	goto L417;}
	VALUES(0) = CADR((V4));
	RETURN(1);
L423:
	if(!((((V4))->v.v_self[0])==((V1)))){
	goto L417;}
	if(((V2))==Cnil){
	goto L429;}
	elt_set((V4),2,Ct);
L429:
	{register object V7;
	V7= (V4);
	elt_set((V7),1,number_plus(((V7))->v.v_self[1],MAKE_FIXNUM(1)));
	}
	(*LK22)(2,VV[25],CONS((V4),Cnil))         /*  MAKE-INFO       */;
	VALUES(0) = list(3,VV[24],VALUES(0),(V4));
	RETURN(1);
L417:
	V3= CDR((V3));
	goto L411;
	}
	}
}
/*	function definition for SCH-LOCAL-FUN                         */
static L8(int narg, object V1)
{ VT10 VLEX10 CLSR10
TTL:
	{volatile object V2;
	volatile object V3;                       /*  FUN             */
	V2= (VV[0]->s.s_dbind);
	V3= Cnil;
L441:
	if(!((V2)==Cnil)){
	goto L442;}
	VALUES(0) = (V1);
	RETURN(1);
L442:
	V3= CAR((V2));
	if(((V3))==(VV[5])){
	goto L447;}
	if(type_of((V3))==t_cons){
	goto L447;}
	if(!((((V3))->v.v_self[0])==((V1)))){
	goto L447;}
	VALUES(0) = (V3);
	RETURN(1);
L447:
	V2= CDR((V2));
	goto L441;
	}
}
/*	function definition for C2CALL-LOCAL                          */
static L9(int narg, object V1, object V2, ...)
{ VT11 VLEX11 CLSR11
	bds_check;
	{int i=2;
	object V3;
	va_list args; va_start(args, V2);
	if (i==narg) goto L457;
	V3= va_arg(args, object);
	i++;
	goto L458;
L457:
	V3= Cnil;
L458:
	{register object V4;                      /*  FUN             */
	V4= CAR((V1));
	if(!(type_of((V2))==t_cons||(V2)==Cnil)){
	goto L462;}
	if(((VV[26]->s.s_dbind))==Cnil){
	goto L462;}
	if(!((CAR((VV[26]->s.s_dbind)))==(((V4))->v.v_self[0]))){
	goto L462;}
	if(!(((VV[27]->s.s_dbind))==(VV[28]))){
	goto L462;}
	(*LK23)(0)                                /*  TAIL-RECURSION-POSSIBLE*/;
	if(VALUES(0)==Cnil){
	goto L462;}
	if(!((length((V2)))==(length(CDR((VV[26]->s.s_dbind)))))){
	goto L462;}
	bds_bind(VV[29],VV[30]);                  /*  *DESTINATION*   */
	(VV[31]->s.s_dbind)= number_plus((VV[31]->s.s_dbind),MAKE_FIXNUM(1));
	bds_bind(VV[27],CONS((VV[31]->s.s_dbind),Cnil));/*  *EXIT*    */
	bds_bind(VV[32],CONS((VV[27]->s.s_dbind),(VV[32]->s.s_dbind)));/*  *UNWIND-EXIT**/
	{object V5;
	object V6= CDR((VV[26]->s.s_dbind));
	if(V6==Cnil){
	VALUES(0) = Cnil;
	goto L479;}
	T0=V5=CONS(Cnil,Cnil);
L480:
	{object V7;                               /*  V               */
	CAR(V5)= CONS(CAR(V6),Cnil);
	}
	if((V6=CDR(V6))==Cnil){
	VALUES(0) = T0;
	goto L479;}
	V5=CDR(V5)=CONS(Cnil,Cnil);
	goto L480;}
L479:
	(*LK24)(2,VALUES(0),(V2))                 /*  C2PSETQ         */;
	if((CDR((VV[27]->s.s_dbind)))==Cnil){
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	goto L474;}
	(*LK14)(1,code_char('\12'))               /*  WT1             */;
	princ_char(76,symbol_value(VV[16]));
	(*LK14)(1,CAR((VV[27]->s.s_dbind)))       /*  WT1             */;
	princ_char(58,symbol_value(VV[16]));
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
L474:
	(*LK25)(1,VV[33])                         /*  UNWIND-NO-EXIT  */;
	(*LK14)(1,code_char('\12'))               /*  WT1             */;
	(*LK14)(1,code_char('\11'))               /*  WT1             */;
	princ_str("goto TTL;",symbol_value(VV[16]));
	RETURN((*LK26)(2,VV[34],((V4))->v.v_self[0])/*  CMPNOTE       */);
L462:
	{object V5;                               /*  FUN             */
	object V6;                                /*  LEX-LEVEL       */
	object V7;                                /*  CLOSURE-P       */
	object V8;                                /*  FNAME           */
	Lformat(3,Cnil,VV[36],((V4))->v.v_self[4])/*  FORMAT          */;
	V5= VALUES(0);
	V6= ((V4))->v.v_self[5];
	V7= ((V4))->v.v_self[7];
	V8= ((V4))->v.v_self[0];
	bds_bind(VV[35],MAKE_FIXNUM(0));          /*  *INLINE-BLOCKS* */
	if(!((VV[37])==((V2)))){
	goto L500;}
	VALUES(0) = list(7,VV[24],VV[38],(V6),(V7),list(2,(V5),VV[39]),(V3),(V8));
	goto L498;
L500:
	(*LK27)(1,(V2))                           /*  INLINE-ARGS     */;
	(*LK28)(2,VALUES(0),Cnil)                 /*  COERCE-LOCS     */;
	VALUES(0) = list(7,VV[24],(V5),(V6),(V7),VALUES(0),(V3),(V8));
L498:
	(*LK29)(1,VALUES(0))                      /*  UNWIND-EXIT     */;
	{int V9;
	V9=(*LK30)(0)                             /*  CLOSE-INLINE-BLOCKS*/;
	bds_unwind1;
	RETURN(V9);}
	}
	}
	}
}
/*	function definition for WT-CALL-LOCAL                         */
static L11(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT12 VLEX12 CLSR12
TTL:
	(*LK14)(1,(V1))                           /*  WT1             */;
	princ_char(40,symbol_value(VV[16]));
	if(((V5))==Cnil){
	goto L509;}
	(*LK31)(1,(V5))                           /*  WT-LOC          */;
	goto L507;
L509:
	if(!(number_compare(MAKE_FIXNUM(0),(V2))<0)){
	goto L511;}
	{volatile object V7;
	volatile int V8;                          /*  N               */
	V7= (V2);
	V8= 0;
L517:
	if(!(number_compare(MAKE_FIXNUM(V8),(V7))>=0)){
	goto L518;}
	goto L511;
L518:
	princ_str("lex",symbol_value(VV[16]));
	(*LK14)(1,MAKE_FIXNUM(V8))                /*  WT1             */;
	princ_char(44,symbol_value(VV[16]));
	V8= (V8)+1;
	goto L517;
	}
L511:
	(*LK14)(1,MAKE_FIXNUM(length((V4))))      /*  WT1             */;
	if(((V3))==Cnil){
	goto L507;}
	princ_str(", env",symbol_value(VV[16]));
	(*LK14)(1,(VV[14]->s.s_dbind))            /*  WT1             */;
L507:
	{volatile object V7;
	volatile object V8;                       /*  ARG             */
	V7= (V4);
	V8= Cnil;
L538:
	if(!((V7)==Cnil)){
	goto L539;}
	goto L534;
L539:
	V8= CAR((V7));
	princ_char(44,symbol_value(VV[16]));
	(*LK14)(1,(V8))                           /*  WT1             */;
	V7= CDR((V7));
	goto L538;
	}
L534:
	princ_char(41,symbol_value(VV[16]));
	if(((V6))==Cnil){
	goto L553;}
	RETURN((*LK32)(1,(V6))                    /*  WT-COMMENT      */);
L553:
	VALUES(0) = Cnil;
	RETURN(1);
}
static LKF32(int narg, ...) {TRAMPOLINK(VV[86],&LK32);}
static LKF31(int narg, ...) {TRAMPOLINK(VV[47],&LK31);}
static LKF30(int narg, ...) {TRAMPOLINK(VV[85],&LK30);}
static LKF29(int narg, ...) {TRAMPOLINK(VV[84],&LK29);}
static LKF28(int narg, ...) {TRAMPOLINK(VV[83],&LK28);}
static LKF27(int narg, ...) {TRAMPOLINK(VV[82],&LK27);}
static LKF26(int narg, ...) {TRAMPOLINK(VV[81],&LK26);}
static LKF25(int narg, ...) {TRAMPOLINK(VV[80],&LK25);}
static LKF24(int narg, ...) {TRAMPOLINK(VV[79],&LK24);}
static LKF23(int narg, ...) {TRAMPOLINK(VV[78],&LK23);}
static LKF22(int narg, ...) {TRAMPOLINK(VV[77],&LK22);}
static LKF21(int narg, ...) {TRAMPOLINK(VV[76],&LK21);}
static LKF20(int narg, ...) {TRAMPOLINK(VV[75],&LK20);}
static LKF19(int narg, ...) {TRAMPOLINK(VV[73],&LK19);}
static LKF18(int narg, ...) {TRAMPOLINK(VV[72],&LK18);}
static LKF17(int narg, ...) {TRAMPOLINK(VV[71],&LK17);}
static LKF16(int narg, ...) {TRAMPOLINK(VV[70],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[69],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[68],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[67],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[66],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[65],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[63],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[62],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[61],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[60],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[59],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[58],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[57],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[56],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[55],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[54],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[53],&LK0);}
