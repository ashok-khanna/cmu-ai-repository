
/* h/ecl.h.  Generated automatically by configure.  */
/*
    ecl.h  -- Include file for compiled code.
*/
/*
    Copyright (c) 1984, Taiichi Yuasa and Masami Hagiya.
    Copyright (c) 1990, Giuseppe Attardi.

    ECoLisp is free software; you can redistribute it and/or modify it under
    the terms of the GNU General Library Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    See file '../Copyright' for full details.
*/

#include <stdio.h>
#include <stdarg.h>
#include <setjmp.h>
#include <math.h>

#define CLOS 1 
/* #undef PDE */
/* #undef LOCATIVE */
/* #undef THREADS */

/* #undef _setjmp */
/* #undef _longjmp */

#define LINK_ARGS	&narg
#ifdef CLOS
#define TRAMPOLINK(vv, lk) \
	static object gfun = OBJNULL; \
	va_list args; va_start(args, narg); \
	if (gfun) return(gcall(narg, gfun, args)); \
	else return(link_call(vv, lk , &gfun, &narg))
#else
#define TRAMPOLINK(vv, lk) \
	va_list args; va_start(args, narg); \
	return(link_call(vv, lk , &narg))
#endif CLOS
#ifndef VOL
#define VOL
#endif
#define VALUES(n)	Values[n]
#define RETURN(x)	return(x)
#define MV_SAVE(nr) \
   { object mv_values[nr]; /* __GNUC__ */ \
       memcpy(mv_values, &VALUES(0), (nr) * sizeof(object))
#define MV_RESTORE(nr) \
       memcpy(&VALUES(0), mv_values, (nr) * sizeof(object));}
#define MV_SHIFT(nr, d) \
   { int i; for (i = (nr)-1; i >= 0; i--) VALUES(i+d) = VALUES(i);}
#define	TRUE		1
#define	FALSE		0
typedef int bool;
typedef int fixnum;
typedef float shortfloat;
typedef double longfloat;
typedef unsigned char byte;
typedef union lispunion *object;
#define	OBJNULL		((object)NULL)
#define IMMEDIATE(obje)	((int)(obje) & 3)
#define MAKE_FIXNUM(n)		((object)(((int)(n) << 2) | 1))
#define	fix(obje)		(((int)(obje)) >> 2)
#ifdef LOCATIVE
#define FIXNUMP(obje)		((((int)(obje)) & 3) == 1)
#else
#define FIXNUMP(obje)		(((int)(obje)) & 1)
#endif
#define CHARACTERP(obje)	((((int)(obje)) & 3) == 2)
#define	code_char(c)		((object)(((int)(c) << 2) | 2))
#define MAKE_CHARACTER(c,b,f)	((object)(((((b) << 16) | (int)(c)) << 2) | 2))
#define	char_code(obje)		((((int)(obje)) >> 2) & 0xffff)
#define	char_bits(obje)		(((int)(obje)) >> 18) /* CHCODEFLEN * 8 + 2 */
#define	char_font(obje)		0
#define char_int(obje)		char_code(obje)
#define int_char(i)		code_char(i)
#ifdef LOCATIVE
#define LOCATIVEP(obje)	((((int)(obje)) & 3) == 3)
#define MAKE_LOCATIVE(n)((object)(((int)(n) << 2) | 3))
#define DEREF(loc)	(*(object *)((unsigned int)(loc) >> 2))
#define UNBOUNDP(loc)	(DEREF(loc) == OBJNULL)
#endif LOCATIVE
#define ARRAYP(x)	(type_of(x) >= t_array && type_of(x) <= t_bitvector)
#define HEADER		byte t, m
struct shortfloat_struct {
	HEADER;
	shortfloat	SFVAL;
};
#define	sf(obje)	(obje)->SF.SFVAL
struct longfloat_struct {
	HEADER;
	longfloat	LFVAL;
};
#define	lf(obje)	(obje)->LF.LFVAL
struct bignum {
	HEADER;
	struct bignum   *big_cdr;
	int		big_car;
};
struct ratio {
	HEADER;
	object	rat_den;
	object	rat_num;
};
struct complex {
	HEADER;
	object	cmp_real;
	object	cmp_imag;
};
enum stype {
	stp_ordinary,
	stp_constant,
        stp_special
};
#define	Cnil			((object)&Cnil_body)
#define	Ct			((object)&Ct_body)
struct symbol {
	HEADER;
	byte    s_stype;
	byte    s_mflag;
	object	s_dbind;
	int	(*s_sfdef)();
#define	NOT_SPECIAL		((int (*)())Cnil)
#define SPECIAL(fun)		((fun)->s.s_sfdef != NOT_SPECIAL)
#define	s_fillp		st_fillp
#define	s_self		st_self
	int	s_fillp;
	char	*s_self;
	object	s_gfdef;
	object	s_plist;
	object	s_hpack;
};
struct package {
	HEADER;
	object	p_name;
	object	p_nicknames;
	object	p_shadowings;
	object	p_uselist;
	object	p_usedbylist;
	object	*p_internal;
	object	*p_external;
	struct package
		*p_link;
};
struct cons {
	HEADER;
	object	c_cdr;
	object	c_car;
};
enum httest {
	htt_eq,
	htt_eql,
	htt_equal
};
struct htent {
	object	hte_key;
	object	hte_value;
};
struct hashtable {
	HEADER;
	short	ht_test;
	struct  htent
		*ht_self;
	object	ht_rhsize;
	object	ht_rhthresh;
	int	ht_nent;
	int	ht_size;
};
enum aelttype {
	aet_object,
	aet_ch,
	aet_bit,
	aet_fix,
	aet_sf,
	aet_lf
/*	,aet_char,
        aet_uchar,
	aet_short,
	aet_ushort
*/
};
struct array {
	HEADER;
	byte	a_adjustable;
	byte	a_rank;
	object	a_displaced;
	int	a_dim;
	int	*a_dims;
	object	*a_self;
	byte	a_elttype;
	byte	a_offset;
};
struct vector {
	HEADER;
	byte	v_adjustable;
	byte	v_hasfillp;
	object	v_displaced;
	int	v_dim;
	int	v_fillp;
	object	*v_self;
	byte	v_elttype;
};
struct string {
	HEADER;
	byte	st_adjustable;
	byte	st_hasfillp;
	object	st_displaced;
	int	st_dim;
	int	st_fillp;
	char	*st_self;
};
struct ustring {
	HEADER;
	byte	ust_adjustable;
	byte	ust_hasfillp;
	object	ust_displaced;
	int	ust_dim;
	int	ust_fillp;
	unsigned char
		*ust_self;
};
struct bitvector {
	HEADER;
	byte	bv_adjustable;
	byte	bv_hasfillp;
	object	bv_displaced;
	int	bv_dim;
	int	bv_fillp;
	char	*bv_self;
	byte	bv_elttype;
	byte	bv_offset;
};
struct fixarray {
	HEADER;
	byte	fixa_adjustable;
	byte	fixa_rank;
	object	fixa_displaced;
	int	fixa_dim;
	int	*fixa_dims;
	fixnum	*fixa_self;
	byte	fixa_elttype;
};
struct sfarray {
	HEADER;
	byte	sfa_adjustable;
	byte	sfa_rank;
	object	sfa_displaced;
	int	sfa_dim;
	int	*sfa_dims;
	shortfloat
		*sfa_self;
	byte	sfa_elttype;
};
struct lfarray {
	HEADER;
	byte	lfa_adjustable;
	byte	lfa_rank;
	object	lfa_displaced;
	int	lfa_dim;
	int	*lfa_dims;
	longfloat
		*lfa_self;
	byte	lfa_elttype;
};
struct structure {
	HEADER;
	short	str_length;
	object	str_name;
	object	*str_self;
};
#ifdef CLOS
#define T_STRUCTURE	t_instance
#define STYPE(x)	CLASS_OF(x)
#define SLOTS(x)	(x)->in.in_slots
#define SLENGTH(x)	(x)->in.in_length
#define SLOT(x,i)	(x)->in.in_slots[i]
#define SNAME(x)	CLASS_NAME(CLASS_OF(x))
#else
#define T_STRUCTURE	t_structure
#define STYPE(x)	x->str.str_name
#define SLOTS(x)	(x)->str.str_self
#define SLENGTH(x)	(x)->str.str_length
#define SLOT(x,i)	(x)->str.str_self[i]
#define SNAME(x)	x->str.str_name
#endif
enum smmode {
	smm_input,
	smm_output,
	smm_io,
	smm_probe,
	smm_synonym,
	smm_broadcast,
	smm_concatenated,
	smm_two_way,
	smm_echo,
	smm_string_input,
	smm_string_output
};
struct stream {
	HEADER;
	short	sm_mode;
	FILE	*sm_fp;
	object	sm_object0;
	object	sm_object1;
	int	sm_int0;
	int	sm_int1;
};
struct random {
	HEADER;
	unsigned	rnd_value;
};
enum chattrib {
	cat_whitespace,
	cat_terminating,
	cat_non_terminating,
	cat_single_escape,
	cat_multiple_escape,
	cat_constituent
};
struct rtent {
	enum chattrib	rte_chattrib;
	object		rte_macro;
	object		*rte_dtab;
};
struct readtable {
	HEADER;
	struct rtent	*rt_self;
};
struct pathname {
	HEADER;
	object	pn_host;
	object	pn_device;
	object	pn_directory;
	object	pn_name;
	object	pn_type;
	object	pn_version;
};
struct codeblock {
	char	*cd_start;
	int	cd_size;
 	object	cd_data;
      };
struct cfun {
	HEADER;
	object	cf_name;
	int	(*cf_self)();
	struct codeblock *cf_block;
};
struct cclosure {
	HEADER;
	int	(*cc_self)();
	object	cc_env;
	struct codeblock *cc_block;
};
/*
struct spice {
	HEADER;
	int	spc_dummy;
};
*/
struct dummy {
	HEADER;
};
#ifdef THREADS
struct cont {
	HEADER;
	object	cn_thread;
	bool	cn_resumed;
	bool	cn_timed_out;
};
struct thread {
	HEADER;
	struct pd      *th_self;
	int	th_size;
	object	th_fun;
	object	th_cont;
};
#endif THREADS
#ifdef CLOS
struct instance {
	HEADER;
	short	in_length;
	object	in_class;
	object	*in_slots;
};
struct gfun {
	HEADER;
	short	gf_arg_no;
	object	gf_name;
	object  gf_meth_ht;
	object  *gf_spec_how;
	object  gf_gfun;
};
#endif CLOS
union lispunion {
	struct bignum	big;
	struct ratio	rat;
	struct shortfloat_struct
			SF;
	struct longfloat_struct
			LF;
	struct complex	cmp;
	struct symbol	s;
	struct package	p;
	struct cons	c;
	struct hashtable
			ht;
	struct array	a;
	struct vector	v;
	struct string	st;
	struct ustring	ust;
	struct bitvector
			bv;
	struct stream	sm;
	struct random	rnd;
	struct readtable
			rt;
	struct pathname	pn;
	struct cfun	cf;
	struct cclosure	cc;
/*	struct spice	spc; */
	struct dummy	d;
	struct fixarray	fixa;
	struct sfarray	sfa;
	struct lfarray	lfa;
#ifdef CLOS
	struct instance in;
	struct gfun	gf;
#else
	struct structure
			str;
#endif CLOS
#ifdef THREADS
	struct cont     cn;
	struct thread   th;
#endif THREADS
};
typedef union { int i; object o;} intUobject;
enum type {
	t_cons = 0,
#ifdef APOLLO
	t_start = 0,
#else
	t_start = t_cons,
#endif APOLLO
	t_bignum,
	t_ratio,
	t_shortfloat,
	t_longfloat,
	t_complex,
	t_symbol,
	t_package,
	t_hashtable,
	t_array,
	t_vector,
	t_string,
	t_bitvector,
	t_stream,
	t_random,
	t_readtable,
	t_pathname,
	t_cfun,
	t_cclosure,
/*	t_spice, */
#ifdef CLOS
	t_instance,
	t_gfun,
#else
	t_structure,
#endif CLOS
#ifdef THREADS
	t_cont,
	t_thread,
#endif
	t_end,
	t_contiguous,
	t_relocatable,
	t_other,
	t_fixnum,
#ifdef MAC
	t_character,
#ifdef LOCATIVE
	t_locative,
#endif LOCATIVE
	t_last
#else
	t_character
#ifdef LOCATIVE
	, t_locative
#endif LOCATIVE
#endif MAC
};
#define	type_of(obje)	((enum type)(IMMEDIATE(obje) ? \
				       ((int)t_other + IMMEDIATE(obje)) \
				       : (((object)(obje))->d.t)))
#define	endp(obje)	endp1(obje)
#ifdef THREADS
#define Values		clwp->lwp_Values
#define cs_limit        clwp->lwp_cs_limit
#else
extern object Values[];
extern int *cs_limit;
#endif THREADS
#define	cs_check \
	if ((int *)(&narg) < cs_limit) \
		cs_overflow()
#define	check_arg(n)  \
			if (narg != (n))  \
				check_arg_failed(narg, n)
#define cs_reserve(x)	if(&narg-(x) < cs_limit)  \
				cs_overflow();
struct bds_bd {
	object	bds_sym;
	object	bds_val;
};
#ifdef THREADS
#define bind_stack      clwp->lwp_bind_stack
#else
extern struct bds_bd bind_stack[]; 
#endif THREADS
#define bds_org		bind_stack
typedef struct bds_bd *bds_ptr;
#ifdef THREADS
#define bds_limit       clwp->lwp_bds_limit
#define bds_top         clwp->lwp_bds_top
#else
extern bds_ptr bds_limit;
extern bds_ptr bds_top;
#endif THREADS
#define	bds_check  \
	if (bds_top >= bds_limit)  \
		bds_overflow()
#define	bds_bind(sym, val)  \
	((++bds_top)->bds_sym = (sym),  \
	bds_top->bds_val = (sym)->s.s_dbind,  \
	(sym)->s.s_dbind = (val))
#define	bds_unwind1  \
	((bds_top->bds_sym)->s.s_dbind = bds_top->bds_val, --bds_top)
typedef struct invocation_history {
	object	ihs_function;
	object	*ihs_base;
} *ihs_ptr;
#ifdef THREADS
#define ihs_stack       clwp->lwp_ihs_stack
#else
extern struct invocation_history ihs_stack[];
#endif THREADS
#define ihs_org		ihs_stack
#ifdef THREADS
#define ihs_limit       clwp->lwp_ihs_limit
#define ihs_top         clwp->lwp_ihs_top
#else
extern ihs_ptr ihs_limit;
extern ihs_ptr ihs_top;
#endif THREADS
#define	ihs_check  \
	if (ihs_top >= ihs_limit)  \
		ihs_overflow()
#define ihs_push(function, args)  \
	(++ihs_top)->ihs_function = (function);  \
	ihs_top->ihs_base = args
#define ihs_pop() 	(ihs_top--)
enum fr_class {
	FRS_CATCH,
	FRS_CATCHALL,
	FRS_PROTECT
};
struct frame {
	jmp_buf		frs_jmpbuf;
	object		*frs_lex;
	bds_ptr		frs_bds_top;
	enum fr_class	frs_class;
	object		frs_val;
	ihs_ptr		frs_ihs;
};
typedef struct frame *frame_ptr;

#ifdef THREADS
#define frame_stack       clwp->lwp_frame_stack
#else
extern struct frame frame_stack[];
#endif THREADS
#define frs_org		frame_stack
#ifdef THREADS
#define frs_limit       clwp->lwp_frs_limit
#define frs_top         clwp->lwp_frs_top
#else
extern frame_ptr frs_limit;
extern frame_ptr frs_top;
#endif THREADS
#define frs_push(class, val)  \
	(((++frs_top >= frs_limit) && frs_overflow()),  \
 	frs_top->frs_lex = lex_env,\
	frs_top->frs_bds_top = bds_top,  \
	frs_top->frs_class = (class),  \
	frs_top->frs_val = (val),  \
	frs_top->frs_ihs = ihs_top,  \
        _setjmp(frs_top->frs_jmpbuf))
#define frs_pop()	frs_top--
#ifdef THREADS
#define nlj_fr           clwp->lwp_nlj_fr
#define nlj_tag          clwp->lwp_nlj_tag
#define lex_env		 clwp->lwp_lex_env
#else
extern frame_ptr nlj_fr;
extern object nlj_tag;
extern object *lex_env;
#endif THREADS
object caar();
object cadr();
object cdar();
object cddr();
object caaar();
object caadr();
object cadar();
object caddr();
object cdaar();
object cdadr();
object cddar();
object cdddr();
object caaaar();
object caaadr();
object caadar();
object caaddr();
object cadaar();
object cadadr();
object caddar();
object cadddr();
object cdaaar();
object cdaadr();
object cdadar();
object cdaddr();
object cddaar();
object cddadr();
object cdddar();
object cddddr();
#define CONS(a,d)	make_cons((a),(d))
#define CAR(x)	(x)->c.c_car
#define CDR(x)	(x)->c.c_cdr
#define CAAR(x)	(x)->c.c_car->c.c_car
#define CADR(x)	(x)->c.c_cdr->c.c_car
#define CDAR(x)	(x)->c.c_car->c.c_cdr
#define CDDR(x)	(x)->c.c_cdr->c.c_cdr
#define CAAAR(x)	(x)->c.c_car->c.c_car->c.c_car
#define CAADR(x)	(x)->c.c_cdr->c.c_car->c.c_car
#define CADAR(x)	(x)->c.c_car->c.c_cdr->c.c_car
#define CADDR(x)	(x)->c.c_cdr->c.c_cdr->c.c_car
#define CDAAR(x)	(x)->c.c_car->c.c_car->c.c_cdr
#define CDADR(x)	(x)->c.c_cdr->c.c_car->c.c_cdr
#define CDDAR(x)	(x)->c.c_car->c.c_cdr->c.c_cdr
#define CDDDR(x)	(x)->c.c_cdr->c.c_cdr->c.c_cdr
#define CAAAAR(x)	(x)->c.c_car->c.c_car->c.c_car->c.c_car
#define CAAADR(x)	(x)->c.c_cdr->c.c_car->c.c_car->c.c_car
#define CAADAR(x)	(x)->c.c_car->c.c_cdr->c.c_car->c.c_car
#define CAADDR(x)	(x)->c.c_cdr->c.c_cdr->c.c_car->c.c_car
#define CADAAR(x)	(x)->c.c_car->c.c_car->c.c_cdr->c.c_car
#define CADADR(x)	(x)->c.c_cdr->c.c_car->c.c_cdr->c.c_car
#define CADDAR(x)	(x)->c.c_car->c.c_cdr->c.c_cdr->c.c_car
#define CADDDR(x)	(x)->c.c_cdr->c.c_cdr->c.c_cdr->c.c_car
#define CDAAAR(x)	(x)->c.c_car->c.c_car->c.c_car->c.c_car
#define CDAADR(x)	(x)->c.c_cdr->c.c_car->c.c_car->c.c_cdr
#define CDADAR(x)	(x)->c.c_car->c.c_cdr->c.c_car->c.c_cdr
#define CDADDR(x)	(x)->c.c_cdr->c.c_cdr->c.c_car->c.c_cdr
#define CDDAAR(x)	(x)->c.c_car->c.c_car->c.c_cdr->c.c_cdr
#define CDDADR(x)	(x)->c.c_cdr->c.c_car->c.c_cdr->c.c_cdr
#define CDDDAR(x)	(x)->c.c_car->c.c_cdr->c.c_cdr->c.c_cdr
#define CDDDDR(x)	(x)->c.c_cdr->c.c_cdr->c.c_cdr->c.c_cdr
#define	cclosure_call	funcall
int funcall(int, ...);
int funcall_with_catcher(int, ...);
int apply();
extern struct symbol Cnil_body, Ct_body;
object MF();
object MM();
#define MF0(x,y) MF(x,y,&Cblock)
#define MF0key(x,y,z,w) MFkey(x,y,&Cblock,z,w)
#define MM0(x,y) MM(x,y,&Cblock)
extern object Scons;
extern object siSfunction_documentation;
extern object siSvariable_documentation;
extern object siSpretty_print_format;
extern object Slist;
extern object keyword_package;
object alloc_object();
object car();
object cdr();
object list();
object listA();
object coerce_to_string();
object elt();
object elt_set();
frame_ptr frs_sch();
frame_ptr frs_sch_catch();
object new_frame_id();
object make_cclosure();
object nth();
object nthcdr();
object make_cons();
object append();
object nconc();
object reverse();
object nreverse();
object number_divide();
object number_expt();
object number_minus();
object number_negate();
object number_plus();
object number_times();
object one_minus();
object one_plus();
object fixnum_times();
object times_plus();
object get();
object getf();
object putprop();
object remprop();
object string_to_object();
object read_VV();
object symbol_function();
object symbol_name();
object symbol_value();
object make_fixnum();
object make_shortfloat();
object make_longfloat();
object structure_ref();
object structure_set();
object princ();
object prin1();
object print();
object terpri();
object aref();
object aset();
object aref1();
object aset1();
char object_to_char();
int object_to_int();
char *object_to_string();
float object_to_float();
double object_to_double();
object TYPE_OF();
#define Creturn(v)	return((VALUES(0)=(v),1))
#define Cexit		return(0)
double sin(), cos(), tan();
#ifdef THREADS
#define BDSSIZE 1024
#define BDSGETA 16
#define IHSSIZE 1024
#define IHSGETA 32
#define FRSSIZE 1024
#define FRSGETA 16
#define VSSIZE 128
typedef struct lpd {
  struct bds_bd lwp_bind_stack[BDSSIZE + BDSGETA + BDSGETA];
  bds_ptr lwp_bds_limit;
  bds_ptr lwp_bds_top;
  int lwp_cssize;
  int *lwp_cs_org;
  int *lwp_cs_limit;
  struct invocation_history lwp_ihs_stack[IHSSIZE + IHSGETA + IHSGETA];
  ihs_ptr lwp_ihs_limit;
  ihs_ptr lwp_ihs_top;
  struct frame lwp_frame_stack[FRSSIZE + FRSGETA + FRSGETA];
  frame_ptr lwp_frs_limit;
  frame_ptr lwp_frs_top;
  frame_ptr lwp_nlj_fr;
  object lwp_nlj_tag;
  object *lwp_lex_env;
  object lwp_Values[VSSIZE];
  object *lwp_vs_limit;
  object *lwp_vs_base;
  object *lwp_vs_top;
  object lwp_alloc_temporary;
  int lwp_backq_level;
  int lwp_eval1;
  int (*lwp_fmt_ch_fun)();
  object lwp_fmt_stream;
  int lwp_ctl_origin;
  int lwp_ctl_index;
  int lwp_ctl_end;
  object *lwp_fmt_base;
  int lwp_fmt_index;
  int lwp_fmt_end;
  int *lwp_fmt_jmp_buf;
  int lwp_fmt_indents;
  object lwp_fmt_string;
  object lwp_fmt_temporary_stream;
  object lwp_fmt_temporary_string;
  int lwp_fmt_nparam;
  struct {
    int fmt_param_type;
    int fmt_param_value;
  } lwp_fmt_param[100];
  int lwp_fmt_spare_spaces;
  int lwp_fmt_line_length;
  object lwp_thread;
  object lwp_test_function;
  object lwp_item_compared;
  bool (*lwp_tf)();
  object lwp_key_function;
  object (*lwp_kf)();
  int lwp_intern_flag;
  object *lwp_PRINTvs_top;
  object *lwp_PRINTvs_limit;
  object lwp_PRINTstream;
  bool lwp_PRINTescape;
  bool lwp_PRINTpretty;
  bool lwp_PRINTcircle;
  int lwp_PRINTbase;
  bool lwp_PRINTradix;
  object lwp_PRINTcase;
  bool lwp_PRINTgensym;
  int lwp_PRINTlevel;
  int lwp_PRINTlength;
  bool lwp_PRINTarray;
  bool lwp_PRINTpackage;
  bool lwp_PRINTstructure;
  int (*lwp_write_ch_fun)();
  int (*lwp_output_ch_fun)();
#define Q_SIZE    128
#define IS_SIZE   256
  short lwp_queue[Q_SIZE];
  short lwp_indent_stack[IS_SIZE];
  int lwp_qh;
  int lwp_qt;
  int lwp_qc;
  int lwp_isp;
  int lwp_iisp;
  object lwp_READtable;
  int lwp_READdefault_float_format;
  int lwp_READbase;
  bool lwp_READsuppress;
  bool lwp_preserving_whitespace_flag;
  bool lwp_escape_flag;
  object lwp_delimiting_char;
  bool lwp_detect_eos_flag;
  bool lwp_in_list_flag;
  bool lwp_dot_flag;
  object lwp_default_dispatch_macro;
  object lwp_big_register_0;
  int lwp_sharp_eq_context_max;
  object (*lwp_read_ch_fun)();
  object lwp_string_register;
  object lwp_gensym_prefix;
  object lwp_gentemp_prefix;
  object lwp_token;
} lpd;
extern lpd *clwp;
#endif
object make_cfun();
object instance_ref();
object memq();
object memql();
object member();
object assq();
object assql();
object assqlp();
object assoc();
struct htent *gethash(object, object);
#ifdef PDE
extern object siVsource_pathname;
#endif PDE
/* for PROLOG */
extern object *alloc_relblock();
extern object *slot;
extern object (*slotf)();
extern object *trail[];
extern object **trail_top;
#define	trail_push(loc)		(*trail_top++ = (loc))
#define	trail_pop		(**--trail_top = OBJNULL)
#define BIND(loc, val)		{loc = val; trail_push(&loc);}
#define trail_mark		trail_push((object *)NULL)
#define trail_restore	{while (trail_top[-1] != (object *)NULL) trail_pop;}
#define trail_unmark		{trail_restore; trail_top--;}
#define get_value(v, x)		unify(x, v)
#define get_constant(c, x)	(c == x || unify(x, c))
#define get_nil(x)		(Cnil == x || unify(x, Cnil))
#define unify_slot		(*slotf)(*slot)
#define unify_value(loc)	(*slotf)(loc)
#define unify_constant(c)	(*slotf)(c)
#define unify_nil		(*slotf)(Cnil)

int siLAmake_constant();
int siLAmake_special();
static L3();
static L8();
static L28();
static L29();
static L125();
static L131();
static L133();
static L136();
static L139();
int siLAmake_special();
static L223();
#define VT2
#define VLEX2
#define CLSR2
static end_init();
static LC228(int, object , object );
#define VT3
#define VLEX3
#define CLSR3
static LC227(int, object , object );
#define VT4
#define VLEX4
#define CLSR4
static LC226(int, object , object );
#define VT5
#define VLEX5
#define CLSR5
static LC32(int, object , object , object , object );
#define VT6 object T0;
#define VLEX6
#define CLSR6
static LC24(int, object );
#define VT7
#define VLEX7
#define CLSR7
static LC22(int, object );
#define VT8
#define VLEX8
#define CLSR8
static LC19(int, object , object , ...);
int Lapply();
#define VT9
#define VLEX9
#define CLSR9
static LC31(int, object , object , object , object );
#define VT10 object T0;
#define VLEX10
#define CLSR10
static L1(int);
#define VT11
#define VLEX11
#define CLSR11
#define Vdeb641 815
static L2(int, object);
#define VT12
#define VLEX12
#define CLSR12
#define Vdeb643 816
#define VT13 object T0;
#define VLEX13
#define CLSR13
static L4(int, object);
#define VT14
#define VLEX14
#define CLSR14
#define Vdeb645 819
static L5(int, object);
#define VT15
#define VLEX15
#define CLSR15
#define Vdeb135 821
static L6(int, object, object);
#define VT16
#define VLEX16
#define CLSR16
#define Vdeb646 823
static L7(int, object, object);
#define VT17
#define VLEX17
#define CLSR17
#define Vdeb647 824
#define VT18
#define VLEX18
#define CLSR18
static L9(int, object);
#define VT19
#define VLEX19
#define CLSR19
#define Vdeb649 827
static L10(int, object);
#define VT20 object T0;
#define VLEX20
#define CLSR20
#define Vdeb650 832
static L11(int, object, object);
#define VT21
#define VLEX21
#define CLSR21
#define Vdeb651 833
static L12(int, object);
int Linteger_length();
int Lash();
#define VT22
#define VLEX22
#define CLSR22
#define Vdeb652 834
static L13(int, object);
int Linteger_length();
#define VT23
#define VLEX23
#define CLSR23
#define Vdeb653 835
static L14(int, object, object, object, object);
int Lapply();
#define VT24 object T0;
#define VLEX24
#define CLSR24
#define Vdeb654 837
static L15(int, object, object, object, object);
#define VT25
#define VLEX25
#define CLSR25
#define Vdeb655 840
static L16(int, object, object, object);
#define VT26
#define VLEX26
#define CLSR26
#define Vdeb656 841
static L17(int, object, object);
#define VT27
#define VLEX27
#define CLSR27
#define Vdeb657 842
static L18(int, object, object, object, object, ...);
int Lapply();
int Lapply();
#define VT28 object T0;
#define VLEX28
#define CLSR28
#define Vdeb659 847
static L20(int, object, object);
int Lapply();
#define VT29 object T0;
#define VLEX29
#define CLSR29
#define Vdeb660 848
static L21(int, object, object, object);
#define VT30 object T0;
#define VLEX30
#define CLSR30
#define Vdeb662 849
static L23(int, object, object);
int Lapply();
#define VT31 object T0;
#define VLEX31
#define CLSR31
#define Vdeb664 850
static L25(int, object, ...);
int Lsymbol_value();
#define VT32
#define VLEX32
#define CLSR32
#define Vdeb665 851
static L26(int, object, object, ...);
static intUobject L26keys[2]={852,112};
int Lapply();
int Llogior();
#define VT33
#define VLEX33
#define CLSR33
#define Vdeb666 853
static L27(int, object, object);
int Lcerror();
#define VT34
#define VLEX34
#define CLSR34
#define Vdeb667 854
#define VT35
#define VLEX35
#define CLSR35
int Lmacroexpand();
int LlistA();
#define VT36 object T0,T1,T2;
#define VLEX36
#define CLSR36 object env0, *CLV0;
static LC34(int, object, object , object , object , object );
#define VT37 object T0;
#define VLEX37
#define CLSR37 object *CLV0;
static L36(int, object, ...);
#define VT38 object T0;
#define VLEX38
#define CLSR38
#define Vdeb99 858
static L37(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT39
#define VLEX39
#define CLSR39
#define Vdeb670 859
static L38(int, object, object, object);
#define VT40 object T0,T1,T2,T3,T4;
#define VLEX40
#define CLSR40
#define Vdeb671 861
static L39(int, object, ...);
static intUobject L39keys[13]={148,149,150,151,153,152,154,155,156,157,158,159,160};
#define VT41 object T0;
#define VLEX41
#define CLSR41
#define Vdeb672 864
static L40(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT42
#define VLEX42
#define CLSR42
#define Vdeb673 865
static L41(int, object, object, object);
#define VT43 object T0,T1,T2,T3,T4;
#define VLEX43
#define CLSR43
#define Vdeb674 866
static L42(int, object, ...);
static intUobject L42keys[13]={167,149,150,151,153,152,154,155,156,157,158,159,160};
#define VT44 object T0;
#define VLEX44
#define CLSR44
#define Vdeb675 867
static L43(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT45
#define VLEX45
#define CLSR45
#define Vdeb676 868
static L44(int, object, object, object);
#define VT46 object T0,T1,T2,T3,T4,T5,T6;
#define VLEX46
#define CLSR46
#define Vdeb677 869
static L45(int, object, ...);
static intUobject L45keys[15]={172,149,150,151,153,152,154,155,156,157,158,159,174,176,160};
#define VT47 object T0,T1,T2;
#define VLEX47
#define CLSR47
#define Vdeb678 872
static L46(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT48
#define VLEX48
#define CLSR48
#define Vdeb679 873
static L47(int, object, object, object);
#define VT49 object T0,T1,T2;
#define VLEX49
#define CLSR49
#define Vdeb680 874
static L48(int, object, ...);
static intUobject L48keys[5]={172,149,153,152,174};
#define VT50 object T0;
#define VLEX50
#define CLSR50
#define Vdeb681 875
static L49(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT51
#define VLEX51
#define CLSR51
#define Vdeb682 876
static L50(int, object, object, object);
#define VT52
#define VLEX52
#define CLSR52
#define Vdeb683 878
static L51(int, object, ...);
static intUobject L51keys[1]={190};
#define VT53
#define VLEX53
#define CLSR53
#define Vdeb684 880
static L52(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT54
#define VLEX54
#define CLSR54
#define Vdeb685 881
static L53(int, object, object, object);
#define VT55 object T0,T1;
#define VLEX55
#define CLSR55
#define Vdeb686 882
static L54(int, object, ...);
static intUobject L54keys[8]={149,153,152,157,158,192,193,194};
#define VT56
#define VLEX56
#define CLSR56
#define Vdeb687 883
static L55(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT57
#define VLEX57
#define CLSR57
#define Vdeb688 884
static L56(int, object, object, object);
#define VT58 object T0,T1;
#define VLEX58
#define CLSR58
#define Vdeb689 886
static L57(int, object, ...);
static intUobject L57keys[10]={149,153,197,157,158,192,193,198,194,199};
#define VT59
#define VLEX59
#define CLSR59
#define Vdeb690 887
static L58(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT60
#define VLEX60
#define CLSR60
#define Vdeb691 888
static L59(int, object, object, object);
#define VT61 object T0,T1;
#define VLEX61
#define CLSR61
#define Vdeb692 889
static L60(int, object, ...);
static intUobject L60keys[5]={149,153,197,198,199};
#define VT62
#define VLEX62
#define CLSR62
#define Vdeb693 890
static L61(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT63
#define VLEX63
#define CLSR63
#define Vdeb694 891
static L62(int, object, object, object);
#define VT64 object T0,T1;
#define VLEX64
#define CLSR64
#define Vdeb695 892
static L63(int, object, ...);
static intUobject L63keys[4]={149,153,152,159};
#define VT65 object T0;
#define VLEX65
#define CLSR65
#define Vdeb696 893
static L64(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT66
#define VLEX66
#define CLSR66
#define Vdeb697 894
static L65(int, object, object, object);
#define VT67 object T0,T1,T2;
#define VLEX67
#define CLSR67
#define Vdeb698 895
static L66(int, object, ...);
static intUobject L66keys[10]={149,153,209,152,157,158,192,193,210,211};
#define VT68 object T0;
#define VLEX68
#define CLSR68
#define Vdeb699 896
static L67(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT69
#define VLEX69
#define CLSR69
#define Vdeb700 897
static L68(int, object, object, object);
#define VT70 object T0;
#define VLEX70
#define CLSR70
#define Vdeb701 898
static L69(int, object, ...);
static intUobject L69keys[3]={149,153,152};
#define VT71
#define VLEX71
#define CLSR71
#define Vdeb702 899
static L70(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT72
#define VLEX72
#define CLSR72
#define Vdeb703 900
static L71(int, object, object, object);
#define VT73 object T0,T1;
#define VLEX73
#define CLSR73
#define Vdeb704 901
static L72(int, object, ...);
static intUobject L72keys[4]={149,153,152,215};
#define VT74 object T0;
#define VLEX74
#define CLSR74
#define Vdeb705 902
static L73(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT75
#define VLEX75
#define CLSR75
#define Vdeb706 903
static L74(int, object, object, object);
#define VT76 object T0,T1;
#define VLEX76
#define CLSR76
#define Vdeb707 904
static L75(int, object, ...);
static intUobject L75keys[4]={149,153,152,211};
#define VT77 object T0;
#define VLEX77
#define CLSR77
#define Vdeb708 905
static L76(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT78
#define VLEX78
#define CLSR78
#define Vdeb709 906
static L77(int, object, object, object);
#define VT79 object T0,T1;
#define VLEX79
#define CLSR79
#define Vdeb710 907
static L78(int, object, ...);
static intUobject L78keys[4]={149,153,209,152};
#define VT80
#define VLEX80
#define CLSR80
#define Vdeb711 908
static L79(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT81
#define VLEX81
#define CLSR81
#define Vdeb712 909
static L80(int, object, object, object);
#define VT82 object T0,T1,T2;
#define VLEX82
#define CLSR82
#define Vdeb713 910
static L81(int, object, ...);
static intUobject L81keys[7]={149,153,152,209,157,158,211};
#define VT83 object T0;
#define VLEX83
#define CLSR83
#define Vdeb714 911
static L82(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT84
#define VLEX84
#define CLSR84
#define Vdeb715 912
static L83(int, object, object, object);
#define VT85 object T0,T1,T2;
#define VLEX85
#define CLSR85
#define Vdeb716 913
static L84(int, object, ...);
static intUobject L84keys[10]={149,153,152,221,157,158,192,193,210,211};
#define VT86 object T0;
#define VLEX86
#define CLSR86
#define Vdeb717 914
static L85(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT87
#define VLEX87
#define CLSR87
#define Vdeb718 915
static L86(int, object, object, object);
#define VT88 object T0,T1,T2,T3,T4;
#define VLEX88
#define CLSR88
#define Vdeb719 916
static L87(int, object, ...);
static intUobject L87keys[12]={224,149,153,209,152,221,157,158,192,193,210,226};
#define VT89 object T0;
#define VLEX89
#define CLSR89
#define Vdeb720 917
static L88(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT90
#define VLEX90
#define CLSR90
#define Vdeb721 918
static L89(int, object, object, object);
#define VT91 object T0,T1;
#define VLEX91
#define CLSR91
#define Vdeb722 919
static L90(int, object, ...);
static intUobject L90keys[5]={149,153,152,157,158};
#define VT92
#define VLEX92
#define CLSR92
#define Vdeb723 920
static L91(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT93
#define VLEX93
#define CLSR93
#define Vdeb724 921
static L92(int, object, object, object);
#define VT94 object T0,T1;
#define VLEX94
#define CLSR94
#define Vdeb725 922
static L93(int, object, ...);
static intUobject L93keys[5]={149,153,152,192,193};
#define VT95
#define VLEX95
#define CLSR95
#define Vdeb726 923
static L94(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT96
#define VLEX96
#define CLSR96
#define Vdeb727 924
static L95(int, object, object, object);
#define VT97 object T0,T1,T2;
#define VLEX97
#define CLSR97
#define Vdeb728 925
static L96(int, object, ...);
static intUobject L96keys[5]={149,153,152,209,234};
#define VT98 object T0;
#define VLEX98
#define CLSR98
#define Vdeb729 926
static L97(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT99
#define VLEX99
#define CLSR99
#define Vdeb730 927
static L98(int, object, object, object);
#define VT100 object T0,T1,T2;
#define VLEX100
#define CLSR100
#define Vdeb731 928
static L99(int, object, ...);
static intUobject L99keys[5]={149,153,209,152,234};
#define VT101 object T0;
#define VLEX101
#define CLSR101
#define Vdeb732 929
static L100(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT102
#define VLEX102
#define CLSR102
#define Vdeb733 930
static L101(int, object, object, object);
#define VT103 object T0,T1,T2,T3;
#define VLEX103
#define CLSR103
#define Vdeb734 932
static L102(int, object, ...);
static intUobject L102keys[6]={149,153,152,242,150,159};
int Lerror();
#define VT104 object T0;
#define VLEX104
#define CLSR104
#define Vdeb735 934
static L103(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT105
#define VLEX105
#define CLSR105
#define Vdeb736 935
static L104(int, object, object, object);
#define VT106 object T0,T1,T2;
#define VLEX106
#define CLSR106
#define Vdeb737 936
static L105(int, object, ...);
static intUobject L105keys[5]={149,150,153,152,249};
int Lerror();
#define VT107 object T0;
#define VLEX107
#define CLSR107
#define Vdeb738 937
static L106(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT108
#define VLEX108
#define CLSR108
#define Vdeb739 938
static L107(int, object, object, object);
#define VT109 object T0,T1,T2,T3,T4,T5;
#define VLEX109
#define CLSR109
#define Vdeb740 939
static L108(int, object, ...);
static intUobject L108keys[8]={149,150,153,152,253,249,254,255};
int Lerror();
int Lerror();
int Lerror();
#define VT110 object T0;
#define VLEX110
#define CLSR110
#define Vdeb741 940
static L109(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT111
#define VLEX111
#define CLSR111
#define Vdeb742 941
static L110(int, object, object, object);
#define VT112 object T0,T1,T2,T3,T4;
#define VLEX112
#define CLSR112
#define Vdeb743 942
static L111(int, object, ...);
static intUobject L111keys[7]={149,150,153,152,249,254,255};
int Lerror();
int Lerror();
int Lerror();
#define VT113 object T0;
#define VLEX113
#define CLSR113
#define Vdeb744 943
static L112(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT114
#define VLEX114
#define CLSR114
#define Vdeb745 944
static L113(int, object, object, object);
#define VT115 object T0,T1,T2;
#define VLEX115
#define CLSR115
#define Vdeb746 946
static L114(int, object, ...);
static intUobject L114keys[6]={149,153,152,264,265,266};
#define VT116 object T0;
#define VLEX116
#define CLSR116
#define Vdeb747 948
static L115(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT117
#define VLEX117
#define CLSR117
#define Vdeb748 949
static L116(int, object, object, object);
int Lceiling();
#define VT118 object T0,T1,T2,T3;
#define VLEX118
#define CLSR118
#define Vdeb749 950
static L117(int, object, ...);
static intUobject L117keys[6]={271,149,153,152,272,273};
int Lerror();
#define VT119 object T0;
#define VLEX119
#define CLSR119
#define Vdeb750 954
static L118(int, object, object, object);
int Lgetf();
int Lsubst();
#define VT120
#define VLEX120
#define CLSR120
#define Vdeb751 955
static L119(int, object, object, object);
#define VT121 object T0;
#define VLEX121
#define CLSR121
#define Vdeb752 956
static L120(int, object, ...);
static intUobject L120keys[4]={149,280,25,194};
#define VT122 object T0;
#define VLEX122
#define CLSR122
#define Vdeb753 957
static L121(int, object);
int Lsymbol_value();
#define VT123
#define VLEX123
#define CLSR123
#define Vdeb754 958
static L122(int, object, object, object, object);
int Lsymbol_value();
int Lset();
int Lsymbol_value();
#define VT124
#define VLEX124
#define CLSR124
#define Vdeb755 959
static L123(int, object, object);
#define VT125
#define VLEX125
#define CLSR125
#define Vdeb756 960
static L124(int, object, object, object, object, object, ...);
int Lsymbol_value();
int Lsymbol_value();
int Lset();
int Lset();
#define VT126
#define VLEX126
#define CLSR126
#define Vdeb757 961
#define VT127
#define VLEX127
#define CLSR127
static L126(int, object);
int Lsymbol_value();
int Lset();
#define VT128
#define VLEX128
#define CLSR128
#define Vdeb333 962
static L127(int, object, ...);
static intUobject L127keys[5]={963,48,964,965,966};
int Lfunctionp();
int Lcerror();
int Lcerror();
#define VT129
#define VLEX129
#define CLSR129
#define Vdeb758 967
static L128(int, ...);
static intUobject L128keys[2]={272,968};
#define VT130
#define VLEX130
#define CLSR130
#define Vdeb759 970
static L129(int, object, object);
#define VT131
#define VLEX131
#define CLSR131
#define Vdeb315 971
static L130(int, object, object, object);
#define VT132
#define VLEX132
#define CLSR132
#define Vdeb316 972
#define VT133 object T0;
#define VLEX133
#define CLSR133
int Lgensym();
int Lgensym();
int Lgensym();
#define VT134
#define VLEX134
#define CLSR134
static L134(int, object);
#define VT135
#define VLEX135
#define CLSR135
#define Vdeb761 973
static L135(int, object, object, object);
int Lgetf();
#define VT136
#define VLEX136
#define CLSR136
#define Vdeb762 974
int Lgensym();
#define VT137 object T0,T1;
#define VLEX137
#define CLSR137
static LC137(int, object , object , object , object );
int Lgensym();
#define VT138
#define VLEX138
#define CLSR138
int Lmember();
int Lmember();
int Lmember();
#define VT139 object T0,T1,T2;
#define VLEX139
#define CLSR139
static LC142(int, object );
#define VT140
#define VLEX140
#define CLSR140
static LC143(int, object );
#define VT141
#define VLEX141
#define CLSR141
static L144(int, object, object, object);
#define VT142 object T0;
#define VLEX142
#define CLSR142
#define Vdeb763 979
static L145(int, object, object, object, ...);
int Lapply();
#define VT143
#define VLEX143
#define CLSR143
#define Vdeb764 980
static L146(int, object, ...);
#define VT144
#define VLEX144
#define CLSR144
#define Vdeb765 981
static L147(int, ...);
static intUobject L147keys[8]={982,30,983,199,198,149,341,340};
int siLmake_structure();
#define VT145
#define VLEX145
#define CLSR145
#define Vdeb769 984
static L148(int, object, object);
#define VT146
#define VLEX146
#define CLSR146
#define Vdeb353 985
static L149(int, object, object);
int Lformat();
#define VT147
#define VLEX147
#define CLSR147
#define Vdeb770 986
static L150(int, ...);
static intUobject L150keys[9]={982,30,983,199,198,149,341,340,635};
int siLmake_structure();
#define VT148
#define VLEX148
#define CLSR148
#define Vdeb771 987
static L151(int, object, object);
int Lformat();
#define VT149
#define VLEX149
#define CLSR149
#define Vdeb363 988
static L153(int, ...);
static intUobject L153keys[9]={982,30,983,199,198,149,341,340,636};
int siLmake_structure();
#define VT150
#define VLEX150
#define CLSR150
#define Vdeb772 989
static L154(int, object, object);
int Lformat();
#define VT151
#define VLEX151
#define CLSR151
#define Vdeb373 990
static L156(int, ...);
static intUobject L156keys[8]={982,30,983,199,198,149,341,340};
int siLmake_structure();
#define VT152
#define VLEX152
#define CLSR152
#define Vdeb773 991
static L157(int, ...);
static intUobject L157keys[8]={982,30,983,199,198,149,341,340};
int siLmake_structure();
#define VT153
#define VLEX153
#define CLSR153
#define Vdeb774 992
static L158(int, ...);
static intUobject L158keys[9]={982,30,983,199,198,149,341,340,638};
int siLmake_structure();
#define VT154
#define VLEX154
#define CLSR154
#define Vdeb775 993
static L159(int, object, object);
int Lformat();
#define VT155
#define VLEX155
#define CLSR155
#define Vdeb395 994
static L161(int, ...);
static intUobject L161keys[9]={982,30,983,199,198,149,341,340,635};
int siLmake_structure();
#define VT156
#define VLEX156
#define CLSR156
#define Vdeb776 995
static L162(int, ...);
static intUobject L162keys[9]={982,30,983,199,198,149,341,340,635};
int siLmake_structure();
#define VT157
#define VLEX157
#define CLSR157
#define Vdeb777 996
static L163(int, ...);
static intUobject L163keys[9]={982,30,983,199,198,149,341,340,635};
int siLmake_structure();
#define VT158
#define VLEX158
#define CLSR158
#define Vdeb778 997
static L164(int, ...);
static intUobject L164keys[9]={982,30,983,199,198,149,341,340,635};
int siLmake_structure();
#define VT159
#define VLEX159
#define CLSR159
#define Vdeb779 998
static L165(int, ...);
static intUobject L165keys[9]={982,30,983,199,198,149,341,340,635};
int siLmake_structure();
#define VT160
#define VLEX160
#define CLSR160
#define Vdeb780 999
static L166(int, ...);
static intUobject L166keys[9]={982,30,983,199,198,149,341,340,635};
int siLmake_structure();
#define VT161
#define VLEX161
#define CLSR161
#define Vdeb781 1000
static L167(int, ...);
static intUobject L167keys[8]={982,30,983,199,198,149,341,340};
int siLmake_structure();
#define VT162
#define VLEX162
#define CLSR162
#define Vdeb782 1001
static L168(int, ...);
static intUobject L168keys[8]={982,30,983,199,198,149,341,340};
int siLmake_structure();
#define VT163
#define VLEX163
#define CLSR163
#define Vdeb783 1002
static L169(int, ...);
static intUobject L169keys[8]={982,30,983,199,198,149,341,340};
int siLmake_structure();
#define VT164
#define VLEX164
#define CLSR164
#define Vdeb784 1003
static L170(int, ...);
static intUobject L170keys[8]={982,30,983,199,198,149,341,340};
int siLmake_structure();
#define VT165
#define VLEX165
#define CLSR165
#define Vdeb785 1004
static L171(int, ...);
static intUobject L171keys[9]={982,30,983,199,198,149,341,340,635};
int siLmake_structure();
#define VT166
#define VLEX166
#define CLSR166
#define Vdeb786 1005
static L172(int, ...);
static intUobject L172keys[9]={982,30,983,199,198,149,341,340,637};
int siLmake_structure();
#define VT167
#define VLEX167
#define CLSR167
#define Vdeb787 1006
static L173(int, object, object);
int Lformat();
#define VT168
#define VLEX168
#define CLSR168
#define Vdeb471 1007
static L175(int, ...);
static intUobject L175keys[9]={982,30,983,199,198,149,341,340,635};
int siLmake_structure();
#define VT169
#define VLEX169
#define CLSR169
#define Vdeb788 1008
static L176(int, ...);
static intUobject L176keys[8]={982,30,983,199,198,149,341,340};
int siLmake_structure();
#define VT170
#define VLEX170
#define CLSR170
#define Vdeb789 1009
static L177(int, ...);
static intUobject L177keys[4]={982,1010,1011,1012};
int siLmake_structure();
#define VT171
#define VLEX171
#define CLSR171
#define Vdeb790 1013
static L178(int, object, object);
int Lformat();
#define VT172 object T0;
#define VLEX172
#define CLSR172
#define Vdeb494 1014
static L180(int, ...);
static intUobject L180keys[2]={982,30};
int siLmake_structure();
#define VT173
#define VLEX173
#define CLSR173
#define Vdeb791 1015
static L181(int, object, object);
int Lformat();
#define VT174
#define VLEX174
#define CLSR174
#define Vdeb503 1016
static L183(int, ...);
static intUobject L183keys[5]={982,1017,30,272,1018};
int siLmake_structure();
#define VT175
#define VLEX175
#define CLSR175
#define Vdeb792 1019
static L184(int, object, object);
int Lformat();
#define VT176
#define VLEX176
#define CLSR176
#define Vdeb513 1020
static L186(int, ...);
static intUobject L186keys[6]={982,1021,1022,1023,30,1024};
int siLmake_structure();
#define VT177
#define VLEX177
#define CLSR177
#define Vdeb793 1025
static L187(int, object, object);
int Lformat();
#define VT178
#define VLEX178
#define CLSR178
#define Vdeb523 1026
static L189(int, ...);
static intUobject L189keys[4]={982,1027,1028,30};
int siLmake_structure();
#define VT179
#define VLEX179
#define CLSR179
#define Vdeb794 1029
static L190(int, object, object);
int Lformat();
#define VT180
#define VLEX180
#define CLSR180
#define Vdeb533 1030
static L192(int, ...);
static intUobject L192keys[3]={982,48,30};
int siLmake_structure();
#define VT181
#define VLEX181
#define CLSR181
#define Vdeb795 1031
static L193(int, object, object);
int Lformat();
#define VT182
#define VLEX182
#define CLSR182
#define Vdeb543 1032
static L195(int, ...);
static intUobject L195keys[4]={982,30,1033,1034};
int siLmake_structure();
#define VT183
#define VLEX183
#define CLSR183
#define Vdeb796 1035
static L196(int, object, object);
int Lformat();
#define VT184
#define VLEX184
#define CLSR184
#define Vdeb553 1036
static L198(int, ...);
static intUobject L198keys[5]={982,30,1034,1033,1037};
int siLmake_structure();
#define VT185
#define VLEX185
#define CLSR185
#define Vdeb797 1038
static L199(int, object, object);
int Lformat();
#define VT186
#define VLEX186
#define CLSR186
#define Vdeb563 1039
static L201(int, ...);
static intUobject L201keys[2]={982,1040};
int siLmake_structure();
#define VT187
#define VLEX187
#define CLSR187
#define Vdeb798 1041
static L202(int, object, object);
int Lformat();
int Lformat();
#define VT188
#define VLEX188
#define CLSR188
#define Vdeb573 1042
static L204(int, ...);
static intUobject L204keys[2]={982,1043};
int siLmake_structure();
#define VT189
#define VLEX189
#define CLSR189
#define Vdeb799 1044
static L205(int, object, object);
int Lformat();
#define VT190
#define VLEX190
#define CLSR190
#define Vdeb584 1045
static L207(int, ...);
static intUobject L207keys[2]={982,30};
int siLmake_structure();
#define VT191
#define VLEX191
#define CLSR191
#define Vdeb800 1046
static L208(int, object, object);
int Lformat();
#define VT192
#define VLEX192
#define CLSR192
#define Vdeb594 1047
static L210(int, ...);
static intUobject L210keys[3]={982,30,29};
int siLmake_structure();
#define VT193
#define VLEX193
#define CLSR193
#define Vdeb801 1048
static L211(int, object, object);
int Lformat();
#define VT194
#define VLEX194
#define CLSR194
#define Vdeb603 1049
static L213(int, ...);
static intUobject L213keys[3]={982,30,32};
int siLmake_structure();
#define VT195
#define VLEX195
#define CLSR195
#define Vdeb802 1050
static L214(int, object, object);
int Lformat();
#define VT196
#define VLEX196
#define CLSR196
#define Vdeb612 1051
static L216(int, ...);
static intUobject L216keys[3]={982,39,30};
int siLmake_structure();
#define VT197
#define VLEX197
#define CLSR197
#define Vdeb803 1052
static L217(int, object, object);
int Lformat();
#define VT198
#define VLEX198
#define CLSR198
#define Vdeb622 1053
static L219(int, ...);
static intUobject L219keys[2]={982,142};
int siLmake_structure();
#define VT199
#define VLEX199
#define CLSR199
#define Vdeb804 1054
static L220(int, object, object);
int Lformat();
#define VT200
#define VLEX200
#define CLSR200
#define Vdeb631 1055
static L222(int, object, object);
int Lmonotonically_nondecreasing();
#define VT201
#define VLEX201
#define CLSR201
#define Vdeb805 1056
#define VT202
#define VLEX202
#define CLSR202
static L224(int, object, object, ...);
#define VT203
#define VLEX203
#define CLSR203
#define Vdeb807 1058
static L225(int, object, object);
#define VT204
#define VLEX204
#define CLSR204
#define Vdeb808 1059
static struct codeblock Cblock;
#define VM204 0
#define VM203 0
#define VM202 0
#define VM201 0
#define VM200 0
#define VM199 0
#define VM198 0
#define VM197 0
#define VM196 0
#define VM195 0
#define VM194 0
#define VM193 0
#define VM192 0
#define VM191 0
#define VM190 0
#define VM189 0
#define VM188 0
#define VM187 0
#define VM186 0
#define VM185 0
#define VM184 0
#define VM183 0
#define VM182 0
#define VM181 0
#define VM180 0
#define VM179 0
#define VM178 0
#define VM177 0
#define VM176 0
#define VM175 0
#define VM174 0
#define VM173 0
#define VM172 1
#define VM171 0
#define VM170 0
#define VM169 0
#define VM168 0
#define VM167 0
#define VM166 0
#define VM165 0
#define VM164 0
#define VM163 0
#define VM162 0
#define VM161 0
#define VM160 0
#define VM159 0
#define VM158 0
#define VM157 0
#define VM156 0
#define VM155 0
#define VM154 0
#define VM153 0
#define VM152 0
#define VM151 0
#define VM150 0
#define VM149 0
#define VM148 0
#define VM147 0
#define VM146 0
#define VM145 0
#define VM144 0
#define VM143 0
#define VM142 1
#define VM141 0
#define VM140 0
#define VM139 3
#define VM138 0
#define VM137 2
#define VM136 0
#define VM135 0
#define VM134 0
#define VM133 1
#define VM132 0
#define VM131 0
#define VM130 0
#define VM129 0
#define VM128 0
#define VM127 0
#define VM126 0
#define VM125 0
#define VM124 0
#define VM123 0
#define VM122 1
#define VM121 1
#define VM120 0
#define VM119 1
#define VM118 4
#define VM117 0
#define VM116 1
#define VM115 3
#define VM114 0
#define VM113 1
#define VM112 5
#define VM111 0
#define VM110 1
#define VM109 6
#define VM108 0
#define VM107 1
#define VM106 3
#define VM105 0
#define VM104 1
#define VM103 4
#define VM102 0
#define VM101 1
#define VM100 3
#define VM99 0
#define VM98 1
#define VM97 3
#define VM96 0
#define VM95 0
#define VM94 2
#define VM93 0
#define VM92 0
#define VM91 2
#define VM90 0
#define VM89 1
#define VM88 5
#define VM87 0
#define VM86 1
#define VM85 3
#define VM84 0
#define VM83 1
#define VM82 3
#define VM81 0
#define VM80 0
#define VM79 2
#define VM78 0
#define VM77 1
#define VM76 2
#define VM75 0
#define VM74 1
#define VM73 2
#define VM72 0
#define VM71 0
#define VM70 1
#define VM69 0
#define VM68 1
#define VM67 3
#define VM66 0
#define VM65 1
#define VM64 2
#define VM63 0
#define VM62 0
#define VM61 2
#define VM60 0
#define VM59 0
#define VM58 2
#define VM57 0
#define VM56 0
#define VM55 2
#define VM54 0
#define VM53 0
#define VM52 0
#define VM51 0
#define VM50 1
#define VM49 3
#define VM48 0
#define VM47 3
#define VM46 7
#define VM45 0
#define VM44 1
#define VM43 5
#define VM42 0
#define VM41 1
#define VM40 5
#define VM39 0
#define VM38 1
#define VM37 1
#define VM36 3
#define VM35 0
#define VM34 0
#define VM33 0
#define VM32 0
#define VM31 1
#define VM30 1
#define VM29 1
#define VM28 1
#define VM27 0
#define VM26 0
#define VM25 0
#define VM24 1
#define VM23 0
#define VM22 0
#define VM21 0
#define VM20 1
#define VM19 0
#define VM18 0
#define VM17 0
#define VM16 0
#define VM15 0
#define VM14 0
#define VM13 1
#define VM12 0
#define VM11 0
#define VM10 1
#define VM9 0
#define VM8 0
#define VM7 0
#define VM6 1
#define VM5 0
#define VM4 0
#define VM3 0
#define VM2 0
#define VM1 1060
static object VV[1060];
static LKF0(int, ...);
static (*LK0)(int, ...)=LKF0;
static LKF1(int, ...);
static (*LK1)(int, ...)=LKF1;
static LKF2(int, ...);
static (*LK2)(int, ...)=LKF2;
static LKF3(int, ...);
static (*LK3)(int, ...)=LKF3;
static LKF4(int, ...);
static (*LK4)(int, ...)=LKF4;
static LKF5(int, ...);
static (*LK5)(int, ...)=LKF5;
static LKF6(int, ...);
static (*LK6)(int, ...)=LKF6;
static LKF7(int, ...);
static (*LK7)(int, ...)=LKF7;
static LKF8(int, ...);
static (*LK8)(int, ...)=LKF8;
static LKF9(int, ...);
static (*LK9)(int, ...)=LKF9;
static LKF10(int, ...);
static (*LK10)(int, ...)=LKF10;
static LKF11(int, ...);
static (*LK11)(int, ...)=LKF11;
static LKF12(int, ...);
static (*LK12)(int, ...)=LKF12;
static LKF13(int, ...);
static (*LK13)(int, ...)=LKF13;
static LKF14(int, ...);
static (*LK14)(int, ...)=LKF14;
static LKF15(int, ...);
static (*LK15)(int, ...)=LKF15;
static LKF16(int, ...);
static (*LK16)(int, ...)=LKF16;
static LKF17(int, ...);
static (*LK17)(int, ...)=LKF17;
static LKF18(int, ...);
static (*LK18)(int, ...)=LKF18;
static LKF19(int, ...);
static (*LK19)(int, ...)=LKF19;
static LKF20(int, ...);
static (*LK20)(int, ...)=LKF20;
static LKF21(int, ...);
static (*LK21)(int, ...)=LKF21;
static LKF22(int, ...);
static (*LK22)(int, ...)=LKF22;
static LKF23(int, ...);
static (*LK23)(int, ...)=LKF23;
static LKF24(int, ...);
static (*LK24)(int, ...)=LKF24;
static LKF25(int, ...);
static (*LK25)(int, ...)=LKF25;
static LKF26(int, ...);
static (*LK26)(int, ...)=LKF26;
static LKF27(int, ...);
static (*LK27)(int, ...)=LKF27;
static LKF28(int, ...);
static (*LK28)(int, ...)=LKF28;
static LKF29(int, ...);
static (*LK29)(int, ...)=LKF29;
static LKF30(int, ...);
static (*LK30)(int, ...)=LKF30;
static LKF31(int, ...);
static (*LK31)(int, ...)=LKF31;
static LKF32(int, ...);
static (*LK32)(int, ...)=LKF32;
static LKF33(int, ...);
static (*LK33)(int, ...)=LKF33;
static LKF34(int, ...);
static (*LK34)(int, ...)=LKF34;
static LKF35(int, ...);
static (*LK35)(int, ...)=LKF35;
static LKF36(int, ...);
static (*LK36)(int, ...)=LKF36;
static LKF37(int, ...);
static (*LK37)(int, ...)=LKF37;
static LKF38(int, ...);
static (*LK38)(int, ...)=LKF38;
static LKF39(int, ...);
static (*LK39)(int, ...)=LKF39;
static LKF40(int, ...);
static (*LK40)(int, ...)=LKF40;
