
#include "dependent.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	siLAmake_special(1,VV[0])                 /*  *MAKE-SPECIAL   */;
	(VV[0]->s.s_dbind)= MAKE_FIXNUM(8192);
	siLAmake_special(1,VV[1])                 /*  *MAKE-SPECIAL   */;
	(VV[1]->s.s_dbind)= Cnil;
	siLAmake_constant(2,VV[2],MAKE_FIXNUM(1)) /*  *MAKE-CONSTANT  */;
	siLAmake_constant(2,VV[3],MAKE_FIXNUM(0)) /*  *MAKE-CONSTANT  */;
	siLAmake_constant(2,VV[4],MAKE_FIXNUM(3)) /*  *MAKE-CONSTANT  */;
	siLAmake_constant(2,VV[5],MAKE_FIXNUM(2)) /*  *MAKE-CONSTANT  */;
	siLAmake_constant(2,VV[6],MAKE_FIXNUM(1)) /*  *MAKE-CONSTANT  */;
	siLAmake_constant(2,VV[7],MAKE_FIXNUM(0)) /*  *MAKE-CONSTANT  */;
	siLAmake_constant(2,VV[8],MAKE_FIXNUM(3)) /*  *MAKE-CONSTANT  */;
	putprop(VV[8],VV[9],VV[10]);
	siLAmake_constant(2,VV[11],MAKE_FIXNUM(0))/*  *MAKE-CONSTANT  */;
	putprop(VV[11],VV[12],VV[10]);
	MF0(VV[231],L1);
	(void)putprop(VV[231],VV[Vdeb231],VV[232]);
	MF0(VV[233],L1);
	(void)putprop(VV[233],VV[Vdeb233],VV[232]);
	funcall(2,VV[234]->s.s_gfdef,VV[17])      /*  PROCLAIM        */;
	funcall(2,VV[234]->s.s_gfdef,VV[18])      /*  PROCLAIM        */;
	putprop(VV[19],VV[20],VV[21]);
	remprop(VV[19],VV[22]);
	remprop(VV[19],VV[23]);
	putprop(VV[19],Cnil,VV[24]);
	putprop(VV[25],VV[26],VV[21]);
	remprop(VV[25],VV[22]);
	remprop(VV[25],VV[23]);
	putprop(VV[25],Cnil,VV[24]);
	putprop(VV[27],VV[28],VV[21]);
	remprop(VV[27],VV[22]);
	remprop(VV[27],VV[23]);
	putprop(VV[27],Cnil,VV[24]);
	putprop(VV[29],VV[30],VV[21]);
	remprop(VV[29],VV[22]);
	remprop(VV[29],VV[23]);
	putprop(VV[29],Cnil,VV[24]);
	putprop(VV[31],VV[32],VV[21]);
	remprop(VV[31],VV[22]);
	remprop(VV[31],VV[23]);
	putprop(VV[31],Cnil,VV[24]);
	putprop(VV[33],VV[34],VV[21]);
	remprop(VV[33],VV[22]);
	remprop(VV[33],VV[23]);
	putprop(VV[33],Cnil,VV[24]);
	putprop(VV[35],VV[36],VV[21]);
	remprop(VV[35],VV[22]);
	remprop(VV[35],VV[23]);
	putprop(VV[35],Cnil,VV[24]);
	MF0(VV[235],L3);
	(void)putprop(VV[235],VV[Vdeb235],VV[232]);
	MF0(VV[236],L4);
	(void)putprop(VV[236],VV[Vdeb236],VV[232]);
	MF0(VV[237],L5);
	(void)putprop(VV[237],VV[Vdeb237],VV[232]);
	MF0(VV[238],L6);
	(void)putprop(VV[238],VV[Vdeb238],VV[232]);
	funcall(2,VV[234]->s.s_gfdef,VV[39])      /*  PROCLAIM        */;
	funcall(2,VV[234]->s.s_gfdef,VV[40])      /*  PROCLAIM        */;
	funcall(2,VV[234]->s.s_gfdef,VV[41])      /*  PROCLAIM        */;
	VV[239] = make_cfun(LC7,Cnil,&Cblock);
	VV[240] = make_cfun(LC8,Cnil,&Cblock);
	VALUES(0) = VV[239];
	siLfset(2,VV[42],VALUES(0))               /*  FSET            */;
	VALUES(0) = VV[240];
	siLfset(2,VV[43],VALUES(0))               /*  FSET            */;
	MF0(VV[241],L9);
	(void)putprop(VV[241],VV[Vdeb241],VV[232]);
	(void)putprop(VV[242],VV[45],siSpretty_print_format);
	
	MM0(VV[242],L10);
	(void)putprop(VV[243],VV[46],siSpretty_print_format);
	
	MM0(VV[243],L11);
	MF0(VV[244],L12);
	(void)putprop(VV[244],VV[Vdeb244],VV[232]);
	funcall(2,VV[234]->s.s_gfdef,VV[48])      /*  PROCLAIM        */;
	MF0(VV[245],L9);
	(void)putprop(VV[245],VV[Vdeb245],VV[232]);
	funcall(2,VV[234]->s.s_gfdef,VV[49])      /*  PROCLAIM        */;
	MF0(VV[246],L14);
	(void)putprop(VV[246],VV[Vdeb246],VV[232]);
	(void)putprop(VV[50],VV[46],siSpretty_print_format);
	
	MM0(VV[50],L15);
	MM0(VV[247],L16);
	(void)putprop(VV[248],VV[45],siSpretty_print_format);
	
	MM0(VV[248],L17);
	(void)putprop(VV[249],VV[45],siSpretty_print_format);
	
	MM0(VV[249],L18);
	MF0(VV[250],L19);
	(void)putprop(VV[250],VV[Vdeb250],VV[232]);
	MF0(VV[251],L20);
	(void)putprop(VV[251],VV[Vdeb251],VV[232]);
	MF0(VV[252],L21);
	(void)putprop(VV[252],VV[Vdeb252],VV[232]);
	MF0(VV[253],L9);
	(void)putprop(VV[253],VV[Vdeb253],VV[232]);
	MF0key(VV[254],L23,1,L23keys);
	(void)putprop(VV[254],VV[Vdeb254],VV[232]);
	siLAmake_special(1,VV[61])                /*  *MAKE-SPECIAL   */;
	(VV[61]->s.s_dbind)= VV[62];
	MF0(VV[255],L24);
	(void)putprop(VV[255],VV[Vdeb255],VV[232]);
	MF0(VV[256],L25);
	(void)putprop(VV[256],VV[Vdeb256],VV[232]);
	(void)putprop(VV[257],VV[45],siSpretty_print_format);
	
	MM0(VV[257],L26);
	(void)putprop(VV[258],VV[45],siSpretty_print_format);
	
	MM0(VV[258],L27);
	funcall(2,VV[234]->s.s_gfdef,VV[68])      /*  PROCLAIM        */;
	MF0(VV[259],L28);
	(void)putprop(VV[259],VV[Vdeb259],VV[232]);
	(void)putprop(VV[260],VV[45],siSpretty_print_format);
	
	MM0(VV[260],L29);
	siLAmake_constant(2,VV[79],Ct)            /*  *MAKE-CONSTANT  */;
	MM0(VV[261],L30);
	MF0(VV[86],L31);
	(void)putprop(VV[86],VV[Vdeb86],VV[232]);
	MF0key(VV[262],L32,1,L32keys);
	(void)putprop(VV[262],VV[Vdeb262],VV[232]);
	MF0(VV[96],L33);
	(void)putprop(VV[96],VV[Vdeb96],VV[232]);
	MF0(VV[263],L34);
	(void)putprop(VV[263],VV[Vdeb263],VV[232]);
	funcall(2,VV[264]->s.s_gfdef,VV[95])      /*  FIND-CLASS      */;
	funcall(9,VV[265]->s.s_gfdef,VALUES(0),VV[96],VV[97],VV[98],Cnil,VV[99],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[264]->s.s_gfdef,VV[96])      /*  FIND-CLASS      */;
	funcall(13,VV[266]->s.s_gfdef,VV[96],VV[100],Cnil,Cnil,VV[101],VV[102],VV[103],Cnil,Cnil,VV[104],MAKE_FIXNUM(1),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[267],L35,1,L35keys);
	(void)putprop(VV[267],VV[Vdeb267],VV[232]);
	funcall(5,VV[268]->s.s_gfdef,VV[96],Cnil,Cnil,Cnil)/*  MAKE-PREDICATE*/;
	siLfset(2,VV[105],VALUES(0))              /*  FSET            */;
	(void)putprop(VV[116],VV[126],siSpretty_print_format);
	
	MM0(VV[116],L36);
	VV[269] = make_cfun(LC39,Cnil,&Cblock);
	VALUES(0) = VV[269];
	funcall(8,VV[270]->s.s_gfdef,VV[127],Cnil,VV[128],VV[129],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	MF0(VV[271],L40);
	(void)putprop(VV[271],VV[Vdeb271],VV[232]);
	funcall(2,VV[264]->s.s_gfdef,VV[95])      /*  FIND-CLASS      */;
	funcall(9,VV[265]->s.s_gfdef,VALUES(0),VV[133],VV[134],VV[135],Cnil,VV[136],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[264]->s.s_gfdef,VV[133])     /*  FIND-CLASS      */;
	funcall(13,VV[266]->s.s_gfdef,VV[133],VV[137],Cnil,Cnil,VV[138],VV[139],Cnil,VV[96],Cnil,VV[140],MAKE_FIXNUM(3),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[272],L41,3,L41keys);
	(void)putprop(VV[272],VV[Vdeb272],VV[232]);
	MF0(VV[141],L42);
	(void)putprop(VV[141],VV[Vdeb141],VV[232]);
	MF0(VV[273],L44);
	(void)putprop(VV[273],VV[Vdeb273],VV[232]);
	MM0(VV[274],L45);
	MF0(VV[275],L46);
	(void)putprop(VV[275],VV[Vdeb275],VV[232]);
	MF0(VV[276],L47);
	(void)putprop(VV[276],VV[Vdeb276],VV[232]);
	MF0(VV[277],L48);
	(void)putprop(VV[277],VV[Vdeb277],VV[232]);
	MF0(VV[278],L49);
	(void)putprop(VV[278],VV[Vdeb278],VV[232]);
	(void)putprop(VV[279],VV[46],siSpretty_print_format);
	
	MM0(VV[279],L50);
	VV[177]=string_to_object(VV[177]);
	MF0(VV[280],L51);
	(void)putprop(VV[280],VV[Vdeb280],VV[232]);
	putprop(VV[181],VV[183],VV[182]);
	VV[281] = make_cfun(LC52,Cnil,&Cblock);
	VALUES(0) = VV[281];
	putprop(VV[181],VALUES(0),VV[184]);
	putprop(VV[181],Cnil,VV[186]);
	putprop(VV[187],VV[188],VV[182]);
	VV[282] = make_cfun(LC53,Cnil,&Cblock);
	VALUES(0) = VV[282];
	putprop(VV[187],VALUES(0),VV[184]);
	putprop(VV[187],Cnil,VV[186]);
	putprop(VV[190],VV[191],VV[182]);
	VV[283] = make_cfun(LC54,Cnil,&Cblock);
	VALUES(0) = VV[283];
	putprop(VV[190],VALUES(0),VV[184]);
	putprop(VV[190],Cnil,VV[186]);
	putprop(VV[193],VV[194],VV[182]);
	VV[284] = make_cfun(LC55,Cnil,&Cblock);
	VALUES(0) = VV[284];
	putprop(VV[193],VALUES(0),VV[184]);
	putprop(VV[193],Cnil,VV[186]);
	putprop(VV[196],VV[197],VV[182]);
	VV[285] = make_cfun(LC56,Cnil,&Cblock);
	VALUES(0) = VV[285];
	putprop(VV[196],VALUES(0),VV[184]);
	putprop(VV[196],Cnil,VV[186]);
	putprop(VV[199],VV[200],VV[182]);
	VV[286] = make_cfun(LC57,Cnil,&Cblock);
	VALUES(0) = VV[286];
	putprop(VV[199],VALUES(0),VV[184]);
	putprop(VV[199],Cnil,VV[186]);
	putprop(VV[202],VV[203],VV[182]);
	VV[287] = make_cfun(LC58,Cnil,&Cblock);
	VALUES(0) = VV[287];
	putprop(VV[202],VALUES(0),VV[184]);
	putprop(VV[202],Cnil,VV[186]);
	putprop(VV[205],VV[206],VV[182]);
	VV[288] = make_cfun(LC59,Cnil,&Cblock);
	VALUES(0) = VV[288];
	putprop(VV[205],VALUES(0),VV[184]);
	putprop(VV[205],Cnil,VV[186]);
	putprop(VV[208],VV[209],VV[182]);
	VV[289] = make_cfun(LC60,Cnil,&Cblock);
	VALUES(0) = VV[289];
	putprop(VV[208],VALUES(0),VV[184]);
	putprop(VV[208],Cnil,VV[186]);
	putprop(VV[211],VV[212],VV[182]);
	VV[290] = make_cfun(LC61,Cnil,&Cblock);
	VALUES(0) = VV[290];
	putprop(VV[211],VALUES(0),VV[184]);
	putprop(VV[211],Cnil,VV[186]);
	putprop(VV[214],VV[215],VV[182]);
	VV[291] = make_cfun(LC62,Cnil,&Cblock);
	VALUES(0) = VV[291];
	putprop(VV[214],VALUES(0),VV[184]);
	putprop(VV[214],Cnil,VV[186]);
	putprop(VV[217],VV[218],VV[182]);
	VV[292] = make_cfun(LC63,Cnil,&Cblock);
	VALUES(0) = VV[292];
	putprop(VV[217],VALUES(0),VV[184]);
	putprop(VV[217],Cnil,VV[186]);
	putprop(VV[220],VV[221],VV[182]);
	VV[293] = make_cfun(LC64,Cnil,&Cblock);
	VALUES(0) = VV[293];
	putprop(VV[220],VALUES(0),VV[184]);
	putprop(VV[220],Cnil,VV[186]);
	putprop(VV[223],VV[224],VV[182]);
	VV[294] = make_cfun(LC65,Cnil,&Cblock);
	VALUES(0) = VV[294];
	putprop(VV[223],VALUES(0),VV[184]);
	putprop(VV[223],Cnil,VV[186]);
	MM0(VV[295],L66);
	MM0(VV[296],L67);
	MM0(VV[297],L68);
	MM0(VV[298],L69);
	MF0(VV[299],L70);
	(void)putprop(VV[299],VV[Vdeb299],VV[232]);
	MF0(VV[300],L71);
	(void)putprop(VV[300],VV[Vdeb300],VV[232]);
	MF0(VV[301],L72);
	(void)putprop(VV[301],VV[Vdeb301],VV[232]);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	local function CLOSURE                                        */
static LC65(int narg)
{ VT3 VLEX3 CLSR3
	VALUES(0) = VV[202];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC64(int narg)
{ VT4 VLEX4 CLSR4
	VALUES(0) = VV[222];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC63(int narg)
{ VT5 VLEX5 CLSR5
	VALUES(0) = VV[219];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC62(int narg)
{ VT6 VLEX6 CLSR6
	VALUES(0) = VV[216];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC61(int narg)
{ VT7 VLEX7 CLSR7
	VALUES(0) = VV[213];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC60(int narg)
{ VT8 VLEX8 CLSR8
	VALUES(0) = VV[210];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC59(int narg)
{ VT9 VLEX9 CLSR9
	VALUES(0) = VV[207];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC58(int narg)
{ VT10 VLEX10 CLSR10
	VALUES(0) = VV[204];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC57(int narg)
{ VT11 VLEX11 CLSR11
	VALUES(0) = VV[201];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC56(int narg)
{ VT12 VLEX12 CLSR12
	VALUES(0) = VV[198];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC55(int narg)
{ VT13 VLEX13 CLSR13
	VALUES(0) = VV[195];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC54(int narg)
{ VT14 VLEX14 CLSR14
	VALUES(0) = VV[192];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC53(int narg)
{ VT15 VLEX15 CLSR15
	VALUES(0) = VV[189];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC52(int narg)
{ VT16 VLEX16 CLSR16
	VALUES(0) = VV[185];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC39(int narg, object V1, object V2)
{ VT17 VLEX17 CLSR17
	if(((VV[130]->s.s_dbind))==Cnil){
	goto L169;}
	Lformat(3,(V2),VV[131],TYPE_OF((V1)))     /*  FORMAT          */;
	goto L167;
L169:
	T0= ((V1))->in.in_slots[0];
	funcall(3,T0,(V1),(V2));
L167:
	VALUES(0) = (V1);
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC8(int narg, object V1)
{ VT18 VLEX18 CLSR18
	VALUES(0) = code_char(fix((V1)));
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC7(int narg, object V1)
{ VT19 VLEX19 CLSR19
	VALUES(0) = MAKE_FIXNUM(char_code((V1)));
	RETURN(1);
}
/*	function definition for DECLARE-BUFMAC                        */
static L1(int narg)
{ VT20 VLEX20 CLSR20
TTL:
	{object V1= list(2,VV[15],MAKE_FIXNUM(3));
	VALUES(0) = list(2,VV[13],list(3,VV[14],(V1),list(2,VV[16],MAKE_FIXNUM(0))));
	RETURN(1);}
}
/*	function definition for RGB-VAL->CARD16                       */
static L3(int narg, object V1)
{ VT21 VLEX21 CLSR21
TTL:
	RETURN(Lround(2,(V1),VV[37])              /*  ROUND           */);
}
/*	function definition for CARD16->RGB-VAL                       */
static L4(int narg, object V1)
{ VT22 VLEX22 CLSR22
TTL:
	VALUES(0) = make_shortfloat((float)(fix((V1)))*(float)(1.5259020e-5));
	RETURN(1);
}
/*	function definition for RADIANS->INT16                        */
static L5(int narg, object V1)
{ VT23 VLEX23 CLSR23
TTL:
	RETURN(Lround(2,(V1),VV[38])              /*  ROUND           */);
}
/*	function definition for INT16->RADIANS                        */
static L6(int narg, object V1)
{ VT24 VLEX24 CLSR24
TTL:
	VALUES(0) = make_shortfloat((float)(fix((V1)))*(float)(2.7270770e-4));
	RETURN(1);
}
/*	function definition for MAKE-PROCESS-LOCK                     */
static L9(int narg, object V1)
{ VT25 VLEX25 CLSR25
TTL:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	macro definition for HOLDING-LOCK                             */
static L10(int narg, object V1, object V2)
{ VT26 VLEX26 CLSR26
	{object V3=CDR(V1),V4,V5,V6,V7,V8;
	{object V9= CAR(V3);
	V4= CAR(V9);
	V9=CDR(V9);
	V5= CAR(V9);
	V9=CDR(V9);
	if(endp(V9)){
	V6= Cnil;
	} else {
	V6= CAR(V9);
	V9=CDR(V9);}
	{object V10;
	V10=getf(V9,VV[59],OBJNULL);
	if(V10==OBJNULL){
	V7= Cnil;
	} else {
	V7= V10;}}}
	V3=CDR(V3);
	V8= V3;
	VALUES(0) = CONS(VV[44],(V8));
	RETURN(1);}
}
/*	macro definition for WITHOUT-ABORTS                           */
static L11(int narg, object V1, object V2)
{ VT27 VLEX27 CLSR27
	{object V3=CDR(V1),V4;
	V4= V3;
	VALUES(0) = CONS(VV[44],(V4));
	RETURN(1);}
}
/*	function definition for PROCESS-BLOCK                         */
static L12(int narg, object V1, object V2, ...)
{ VT28 VLEX28 CLSR28
	{object V3;
	va_list args; va_start(args, V2);
	narg -=2;
	V3=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object p=V3;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	Lapply(2,(V2),(V3))                       /*  APPLY           */;
	if(VALUES(0)==Cnil)goto L174;
	RETURN(1);
L174:
	RETURN(Lerror(1,VV[47])                   /*  ERROR           */);
	}
}
/*	function definition for CURRENT-PROCESS                       */
static L14(int narg)
{ VT29 VLEX29 CLSR29
TTL:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	macro definition for WITHOUT-INTERRUPTS                       */
static L15(int narg, object V1, object V2)
{ VT30 VLEX30 CLSR30
	{object V3=CDR(V1),V4;
	V4= V3;
	VALUES(0) = CONS(VV[44],(V4));
	RETURN(1);}
}
/*	macro definition for CONDITIONAL-STORE                        */
static L16(int narg, object V1, object V2)
{ VT31 VLEX31 CLSR31
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= CAR(V3);
	{object V7= list(3,VV[52],(V4),(V5));
	VALUES(0) = list(2,VV[50],list(2,VV[51],list(3,(V7),list(3,VV[53],(V4),(V6)),Ct)));
	RETURN(1);}}
}
/*	macro definition for WRAP-BUF-OUTPUT                          */
static L17(int narg, object V1, object V2)
{ VT32 VLEX32 CLSR32
	{object V3=CDR(V1),V4,V5;
	{object V6= CAR(V3);
	V4= CAR(V6);}
	V3=CDR(V3);
	V5= V3;
	VALUES(0) = listA(3,VV[54],list(2,VV[55],(V4)),(V5));
	RETURN(1);}
}
/*	macro definition for WRAP-BUF-INPUT                           */
static L18(int narg, object V1, object V2)
{ VT33 VLEX33 CLSR33
	{object V3=CDR(V1),V4,V5;
	{object V6= CAR(V3);
	V4= CAR(V6);}
	V3=CDR(V3);
	V5= V3;
	VALUES(0) = CONS(VV[44],(V5));
	RETURN(1);}
}
/*	function definition for OPEN-X-STREAM                         */
static L19(int narg, object V1, object V2, object V3)
{ VT34 VLEX34 CLSR34
TTL:
	{object V4;                               /*  STREAM          */
	(*LK0)(2,(V1),number_plus((VV[56]->s.s_dbind),(V2)))/*  OPEN-CLIENT-STREAM*/;
	V4= VALUES(0);
	Lstreamp(1,(V4))                          /*  STREAMP         */;
	if(VALUES(0)==Cnil){
	goto L178;}
	VALUES(0) = (V4);
	RETURN(1);
L178:
	RETURN(Lerror(3,VV[57],(V1),(V2))         /*  ERROR           */);
	}
}
/*	function definition for BUFFER-READ-DEFAULT                   */
static L20(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT35 VLEX35 CLSR35
TTL:
	(*LK1)(0)                                 /*  DECLARE-BUFFUN  */;
	{object V6;                               /*  STREAM          */
	V6= ((V1))->in.in_slots[9];
	{object V7;
	V7= ((V6)==Cnil?Ct:Cnil);
	if(((V7))==Cnil){
	goto L186;}
	VALUES(0) = (V7);
	goto L183;
L186:
	Llisten(1,(V6))                           /*  LISTEN          */;
	if(VALUES(0)==Cnil){
	goto L189;}
	VALUES(0) = Cnil;
	goto L183;
L189:
	if(!(eql((V5),MAKE_FIXNUM(0)))){
	goto L192;}
	VALUES(0) = VV[59];
	goto L183;
L192:
	{object V8;
	L24(2,(V1),(V5))                          /*  BUFFER-INPUT-WAIT-DEFAULT*/;
	V8= VALUES(0);
	if(((V8))==Cnil){
	goto L196;}
	VALUES(0) = (V8);
	goto L183;
L196:
	VALUES(0) = Cnil;
	}
	}
L183:
	if(VALUES(0)==Cnil)goto L182;
	RETURN(1);
L182:
	Lread_bytes(4,(V6),(V2),(V3),(V4))        /*  READ-BYTES      */;
	VALUES(0) = (number_compare(MAKE_FIXNUM(0),VALUES(0))>0?Ct:Cnil);
	RETURN(1);
	}
}
/*	function definition for BUFFER-WRITE-DEFAULT                  */
static L21(int narg, object V1, object V2, object V3, object V4)
{ VT36 VLEX36 CLSR36
TTL:
	(*LK1)(0)                                 /*  DECLARE-BUFFUN  */;
	RETURN(Lwrite_bytes(4,((V2))->in.in_slots[1],(V1),(V3),(V4))/*  WRITE-BYTES*/);
}
/*	function definition for BUFFER-CLOSE-DEFAULT                  */
static L23(int narg, object V1, ...)
{ VT37 VLEX37 CLSR37
	{object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[2];
	parse_key(narg,args,1,L23keys,keyvars,OBJNULL,FALSE);
	V2= keyvars[0];
	}
	{object V3;                               /*  STREAM          */
	V3= ((V1))->in.in_slots[1];
	if(((V3))==Cnil){
	goto L202;}
	RETURN(Lclose(3,(V3),VV[60],(V2))         /*  CLOSE           */);
L202:
	VALUES(0) = Cnil;
	RETURN(1);
	}
	}
}
/*	function definition for BUFFER-INPUT-WAIT-DEFAULT             */
static L24(int narg, object V1, object V2)
{ VT38 VLEX38 CLSR38
TTL:
	{volatile object V3;                      /*  STREAM          */
	V3= ((V1))->in.in_slots[9];
	{volatile object V4;
	V4= ((V3)==Cnil?Ct:Cnil);
	if(((V4))==Cnil){
	goto L207;}
	VALUES(0) = (V4);
	RETURN(1);
L207:
	Llisten(1,(V3))                           /*  LISTEN          */;
	if(VALUES(0)==Cnil){
	goto L210;}
	VALUES(0) = Cnil;
	RETURN(1);
L210:
	if(!(eql((V2),MAKE_FIXNUM(0)))){
	goto L213;}
	VALUES(0) = VV[59];
	RETURN(1);
L213:
	if(((V2))==Cnil){
	goto L216;}
	{ int V5;
	volatile object V6;                       /*  NPOLL           */
	volatile object V7;                       /*  FRACTION        */
	V5=Ltruncate(2,(V2),(VV[61]->s.s_dbind))  /*  TRUNCATE        */;
	if (V5--==0) goto L219;
	V6= VALUES(0);
	if (V5--==0) goto L220;
	V7= VALUES(1);
	goto L221;
L219:
	V6= Cnil;
L220:
	V7= Cnil;
L221:
	{volatile object V8;
	volatile int V9;                          /*  I               */
	V8= (V6);
	V9= 0;
L226:
	if(!(number_compare(MAKE_FIXNUM(V9),(V8))>=0)){
	goto L227;}
	goto L222;
L227:
	Lsleep(1,(VV[61]->s.s_dbind))             /*  SLEEP           */;
	Llisten(1,(V3))                           /*  LISTEN          */;
	if(VALUES(0)==Cnil){
	goto L231;}
	VALUES(0) = Cnil;
	RETURN(1);
L231:
	V9= (V9)+1;
	goto L226;
	}
L222:
	if(!(number_compare(MAKE_FIXNUM(0),(V7))<0)){
	goto L237;}
	Lsleep(1,(V7))                            /*  SLEEP           */;
	Llisten(1,(V3))                           /*  LISTEN          */;
	if(VALUES(0)==Cnil){
	goto L237;}
	VALUES(0) = Cnil;
	RETURN(1);
L237:
	VALUES(0) = VV[59];
	RETURN(1);}
L216:
	VALUES(0) = Cnil;
	RETURN(1);
	}
	}
}
/*	function definition for BUFFER-LISTEN-DEFAULT                 */
static L25(int narg, object V1)
{ VT39 VLEX39 CLSR39
TTL:
	{object V2;                               /*  STREAM          */
	V2= ((V1))->in.in_slots[9];
	if(((V2))!=Cnil){
	goto L245;}
	VALUES(0) = Ct;
	RETURN(1);
L245:
	RETURN(Llisten(1,(V2))                    /*  LISTEN          */);
	}
}
/*	macro definition for WITH-STACK-LIST                          */
static L26(int narg, object V1, object V2)
{ VT40 VLEX40 CLSR40
	{object V3=CDR(V1),V4,V5,V6;
	{object V7= CAR(V3);
	V4= CAR(V7);
	V7=CDR(V7);
	V5= V7;}
	V3=CDR(V3);
	V6= V3;
	{object V8= CONS(list(2,(V4),CONS(VV[64],(V5))),Cnil);
	VALUES(0) = listA(4,VV[63],(V8),list(2,VV[13],list(3,VV[65],VV[66],(V4))),(V6));
	RETURN(1);}}
}
/*	macro definition for WITH-STACK-LIST*                         */
static L27(int narg, object V1, object V2)
{ VT41 VLEX41 CLSR41
	{object V3=CDR(V1),V4,V5,V6;
	{object V7= CAR(V3);
	V4= CAR(V7);
	V7=CDR(V7);
	V5= V7;}
	V3=CDR(V3);
	V6= V3;
	{object V8= CONS(list(2,(V4),CONS(VV[67],(V5))),Cnil);
	VALUES(0) = listA(4,VV[63],(V8),list(2,VV[13],list(3,VV[65],VV[66],(V4))),(V6));
	RETURN(1);}}
}
/*	function definition for BUFFER-REPLACE                        */
static L28(int narg, object V1, object V2, object V3, object V4, ...)
{ VT42 VLEX42 CLSR42
	{int i=4;
	object V5;
	va_list args; va_start(args, V4);
	if (i==narg) goto L247;
	V5= va_arg(args, object);
	i++;
	goto L248;
L247:
	V5= MAKE_FIXNUM(0);
L248:
	RETURN((*LK2)(8,(V1),(V2),VV[69],(V3),VV[70],(V4),VV[71],(V5))/*  REPLACE*/);
	}
}
/*	macro definition for WITH-GCONTEXT-BINDINGS                   */
static L29(int narg, object V1, object V2)
{ VT43 VLEX43 CLSR43
	{object V3=CDR(V1),V4,V5,V6,V7,V8,V9,V10;
	{object V11= CAR(V3);
	V4= CAR(V11);
	V11=CDR(V11);
	V5= CAR(V11);
	V11=CDR(V11);
	V6= CAR(V11);
	V11=CDR(V11);
	V7= CAR(V11);
	V11=CDR(V11);
	V8= CAR(V11);
	V11=CDR(V11);
	V9= CAR(V11);}
	V3=CDR(V3);
	V10= V3;
	{volatile object V12;                     /*  LOCAL-STATE     */
	volatile object V13;                      /*  RESETS          */
	Lgensym(0)                                /*  GENSYM          */;
	V12= VALUES(0);
	V13= Cnil;
	{volatile object V14;
	volatile object V15;                      /*  INDEX           */
	V14= (V6);
	V15= Cnil;
L255:
	if(!((V14)==Cnil)){
	goto L256;}
	goto L251;
L256:
	V15= CAR((V14));
	{object V17= list(3,VV[72],(V12),(V15));
	V13= CONS(list(3,VV[53],(V17),list(3,VV[72],(V5),(V15))),(V13));}
	V14= CDR((V14));
	goto L255;
	}
L251:
	{object V14= CONS(VV[44],(V10));
	{object V15= CONS(list(2,(V12),list(2,VV[74],(V4))),Cnil);
	{object V16= list(2,VV[13],list(3,VV[65],VV[75],(V12)));
	{object V17= listA(4,VV[63],(V15),(V16),append((V13),CONS(list(3,VV[53],list(3,VV[72],(V12),(V7)),MAKE_FIXNUM(0)),Cnil)));
	{object V18= list(3,VV[76],(V9),list(4,VV[77],(V4),(V8),(V9)));
	VALUES(0) = list(5,VV[73],(V14),(V17),(V18),list(2,VV[78],(V5)));
	RETURN(1);}}}}}
	}}
}
/*	macro definition for TYPE?                                    */
static L30(int narg, object V1, object V2)
{ VT44 VLEX44 CLSR44
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	Lconstantp(1,(V5))                        /*  CONSTANTP       */;
	if(VALUES(0)!=Cnil){
	goto L267;}
	VALUES(0) = list(3,VV[80],(V4),(V5));
	RETURN(1);
L267:
	Leval(1,(V5))                             /*  EVAL            */;
	V5= VALUES(0);
	{object V6;                               /*  PREDICATE       */
	V6= assql((V5),VV[81]);
	if(((V6))==Cnil){
	goto L273;}
	VALUES(0) = list(2,CADR((V6)),(V4));
	RETURN(1);
L273:
	if(!(((V5))==(VV[82]))){
	goto L276;}
	VALUES(0) = Ct;
	RETURN(1);
L276:
	VALUES(0) = list(3,VV[83],VV[84],list(3,VV[80],(V4),list(2,VV[85],(V5))));
	RETURN(1);
	}}
}
/*	function definition for X-TYPE-ERROR                          */
static L31(int narg, object V1, object V2, ...)
{ VT45 VLEX45 CLSR45
	{int i=2;
	object V3;
	va_list args; va_start(args, V2);
	if (i==narg) goto L278;
	V3= va_arg(args, object);
	i++;
	goto L279;
L278:
	V3= Cnil;
L279:
	RETURN(L33(7,VV[86],VV[87],(V1),VV[88],(V2),VV[89],(V3))/*  X-ERROR*/);
	}
}
/*	function definition for DEFAULT-ERROR-HANDLER                 */
static L32(int narg, object V1, object V2, ...)
{ VT46 VLEX46 CLSR46
	{object V3;
	object V4;
	va_list args; va_start(args, V2);
	narg -=2;
	V3=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ int n=narg; object p=V3;
	 for(;n-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{ object keyvars[2];
	va_start(args,V2);
	parse_key(narg,args,1,L32keys,keyvars,V3,TRUE);
	V4= keyvars[0];
	}
	if(((V4))==Cnil){
	goto L282;}
	VALUES(0) = (VV[263]->s.s_gfdef);
	RETURN(Lapply(8,VALUES(0),VV[90],(V2),VV[91],(V1),VV[92],(V2),(V3))/*  APPLY*/);
L282:
	VALUES(0) = (VV[96]->s.s_gfdef);
	RETURN(Lapply(7,VALUES(0),(V2),VV[91],(V1),VV[92],(V2),(V3))/*  APPLY*/);
	}
}
/*	function definition for X-ERROR                               */
static L33(int narg, object V1, ...)
{ VT47 VLEX47 CLSR47
	{object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	VALUES(0) = (VV[271]->s.s_gfdef);
	Lapply(3,VALUES(0),(V1),(V2))             /*  APPLY           */;
	(*LK3)(1,VALUES(0))                       /*  PRINC-TO-STRING */;
	RETURN(Lerror(2,VV[93],VALUES(0))         /*  ERROR           */);
	}
}
/*	function definition for X-CERROR                              */
static L34(int narg, object V1, object V2, ...)
{ VT48 VLEX48 CLSR48
	{object V3;
	va_list args; va_start(args, V2);
	narg -=2;
	V3=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object p=V3;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	VALUES(0) = (VV[271]->s.s_gfdef);
	Lapply(3,VALUES(0),(V2),(V3))             /*  APPLY           */;
	(*LK3)(1,VALUES(0))                       /*  PRINC-TO-STRING */;
	RETURN(Lcerror(3,(V1),VV[94],VALUES(0))   /*  CERROR          */);
	}
}
/*	function definition for MAKE-X-ERROR                          */
static L35(int narg, ...)
{ VT49 VLEX49 CLSR49
	{object V1;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[2];
	parse_key(narg,args,1,L35keys,keyvars,OBJNULL,FALSE);
	V1= keyvars[0];
	}
	(*LK4)(1,VV[96])                          /*  FIND-CLASS      */;
	RETURN(siLmake_structure(2,VALUES(0),(V1))/*  MAKE-STRUCTURE  */);
	}
}
/*	macro definition for DEFINE-CONDITION                         */
static L36(int narg, object V1, object V2)
{ VT50 VLEX50 CLSR50
	bds_check;
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= V3;
	{volatile object V7;                      /*  SLOT-NAMES      */
	volatile object V8;
	volatile object V9;                       /*  DOCUMENTATION   */
	volatile object V10;                      /*  CONC-NAME       */
	volatile object V11;
	volatile object V12;                      /*  REPORTER        */
	volatile object V13;                      /*  CONDITION       */
	volatile object V14;
	volatile object V15;                      /*  STREAM          */
	volatile object V16;
	volatile object V17;                      /*  REPORT-FUNCTION */
	{object V20;
	V20= CAR((V6));
	V6= CDR((V6));
	VALUES(0) = (V20);
	}
	{object V18;
	object V19= VALUES(0);
	if(V19==Cnil){
	V8= Cnil;
	goto L293;}
	T0=V18=CONS(Cnil,Cnil);
L294:
	{volatile object V20;                     /*  SLOT            */
	V20= CAR(V19);
	if(!(type_of((V20))==t_cons)){
	goto L301;}
	CAR(V18)= CAR((V20));
	goto L299;
L301:
	CAR(V18)= (V20);
	}
L299:
	if((V19=CDR(V19))==Cnil){
	V8= T0;
	goto L293;}
	V18=CDR(V18)=CONS(Cnil,Cnil);
	goto L294;}
L293:
	(*LK5)(3,VV[106],coerce_to_string((V4)),VV[107])/*  CONCATENATE*/;
	V11= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V14= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V16= VALUES(0);
	LC38(1,(V4))                              /*  REPORTER-FOR-CONDITION*/;
	V17= VALUES(0);
	V7= V8;
	V9= Cnil;
	V10= V11;
	V12= Cnil;
	V13= V14;
	V15= V16;
	{volatile object V18;
	volatile object V19;                      /*  ITEM            */
	V18= (V6);
	V19= Cnil;
L311:
	if(!((V18)==Cnil)){
	goto L312;}
	goto L307;
L312:
	V19= CAR((V18));
	{register object V21;
	V21= CAR((V19));
	if(!(eql((V21),VV[108]))){
	goto L320;}
	V9= CADR((V19));
	goto L317;
L320:
	if(!(eql((V21),VV[109]))){
	goto L324;}
	V10= coerce_to_string(CADR((V19)));
	goto L317;
L324:
	if(!(eql((V21),VV[110]))){
	goto L328;}
	V12= CADR((V19));
	goto L317;
L328:
	bds_bind(VV[111],MAKE_FIXNUM(4));         /*  *PRINT-LEVEL*   */
	bds_bind(VV[112],MAKE_FIXNUM(4));         /*  *PRINT-LENGTH*  */
	Lerror(6,VV[113],VV[114],(V21),VV[108],VV[109],VV[110])/*  ERROR*/;
	bds_unwind1;
	bds_unwind1;
	}
L317:
	V18= CDR((V18));
	goto L311;
	}
L307:
	if(((V12))!=Cnil){
	goto L334;}
	LC38(1,CAR((V5)))                         /*  REPORTER-FOR-CONDITION*/;
	V17= VALUES(0);
L334:
	{object V18= list(2,(V4),VV[116]);
	Lintern(1,(V10))                          /*  INTERN          */;
	{object V19= list(2,VV[109],VALUES(0));
	{object V20= CAR((V5));
	{object V21= listA(3,VV[117],listA(4,(V4),(V19),list(3,VV[118],(V20),list(2,VV[119],list(2,VV[85],(V17)))),VV[120]),(V7));
	if(((V9))==Cnil){
	goto L341;}
	T0= list(3,VV[53],VV[121],(V9));
	goto L339;
L341:
	T0= Cnil;
L339:
	if(((V12))==Cnil){
	goto L345;}
	{object V22= list(2,(V13),(V15));
	if(!(type_of((V12))==t_string)){
	goto L349;}
	VALUES(0) = list(3,VV[123],(V12),(V15));
	goto L347;
L349:
	VALUES(0) = list(3,(V12),(V13),(V15));
L347:
	T1= list(5,VV[122],(V17),(V22),VALUES(0),(V13));
	goto L343;}
L345:
	T1= Cnil;
L343:
	VALUES(0) = list(6,VV[115],(V18),(V21),T0,T1,list(2,VV[85],(V4)));
	RETURN(1);}}}}
	}}
}
/*	local function REPORTER-FOR-CONDITION                         */
static LC38(int narg, object V1)
{ VT51 VLEX51 CLSR51
TTL:
	RETURN((*LK6)(3,VV[124],(V1),VV[125])     /*  XINTERN         */);
}
/*	function definition for MAKE-CONDITION                        */
static L40(int narg, object V1, ...)
{ VT52 VLEX52 CLSR52
	{object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{object V3;                               /*  MAKE-FUNCTION   */
	(*LK5)(3,VV[106],coerce_to_string(VV[132]),coerce_to_string((V1)))/*  CONCATENATE*/;
	T0= VALUES(0);
	Lsymbol_package(1,(V1))                   /*  SYMBOL-PACKAGE  */;
	Lintern(2,T0,VALUES(0))                   /*  INTERN          */;
	V3= VALUES(0);
	RETURN(Lapply(2,(V3),(V2))                /*  APPLY           */);
	}
	}
}
/*	function definition for MAKE-TYPE-ERROR                       */
static L41(int narg, ...)
{ VT53 VLEX53 CLSR53
	{object V1;
	object V2;
	object V3;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[6];
	parse_key(narg,args,3,L41keys,keyvars,OBJNULL,FALSE);
	if(keyvars[3]==Cnil){
	V1= VV[141];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	}
	(*LK4)(1,VV[133])                         /*  FIND-CLASS      */;
	RETURN(siLmake_structure(4,VALUES(0),(V1),(V2),(V3))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for .TYPE-ERROR-REPORTER.                 */
static L42(int narg, object V1, object V2)
{ VT54 VLEX54 CLSR54
TTL:
	{object V3;                               /*  CONDITION       */
	object V4;                                /*  STREAM          */
	Lformat(4,(V2),VV[142],((V1))->in.in_slots[1],((V1))->in.in_slots[2])/*  FORMAT*/;
	}
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for HOST-ADDRESS                          */
static L44(int narg, object V1, ...)
{ VT55 VLEX55 CLSR55
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if (i==narg) goto L357;
	V2= va_arg(args, object);
	i++;
	goto L358;
L357:
	V2= VV[143];
L358:
	RETURN(Lerror(1,VV[144])                  /*  ERROR           */);
	}
}
/*	macro definition for USE-CLOSURES                             */
static L45(int narg, object V1, object V2)
{ VT56 VLEX56 CLSR56
	{object V3=CDR(V1);
	VALUES(0) = Cnil;
	RETURN(1);}
}
/*	function definition for DEFAULT-RESOURCES-PATHNAME            */
static L46(int narg)
{ VT57 VLEX57 CLSR57
TTL:
	Luser_homedir_pathname(0)                 /*  USER-HOMEDIR-PATHNAME*/;
	T0= VALUES(0);
	Lpathname(1,VV[145])                      /*  PATHNAME        */;
	RETURN(Lmerge_pathnames(2,T0,VALUES(0))   /*  MERGE-PATHNAMES */);
}
/*	function definition for RESOURCES-PATHNAME                    */
static L47(int narg)
{ VT58 VLEX58 CLSR58
TTL:
	Luser_homedir_pathname(0)                 /*  USER-HOMEDIR-PATHNAME*/;
	T0= VALUES(0);
	(*LK7)(0)                                 /*  MACHINE-INSTANCE*/;
	(*LK5)(3,VV[146],VV[147],VALUES(0))       /*  CONCATENATE     */;
	Lpathname(1,VALUES(0))                    /*  PATHNAME        */;
	RETURN(Lmerge_pathnames(2,T0,VALUES(0))   /*  MERGE-PATHNAMES */);
}
/*	function definition for GC-CLEANUP                            */
static L48(int narg)
{ VT59 VLEX59 CLSR59
TTL:
	(VV[152]->s.s_dbind)= Cnil;
	(VV[151]->s.s_dbind)= Cnil;
	if(!((VV[150])->s.s_dbind!=OBJNULL)){
	goto L372;}
	(*LK8)(2,(VV[150]->s.s_dbind),Cnil)       /*  FILL            */;
L372:
	(VV[149]->s.s_dbind)= Cnil;
	(VV[148]->s.s_dbind)= Cnil;
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WITH-STANDARD-IO-SYNTAX-FUNCTION      */
static L49(int narg, object V1)
{ VT60 VLEX60 CLSR60
	bds_check;
TTL:
	{object V2;
	Lfind_package(1,VV[154])                  /*  FIND-PACKAGE    */;
	V2= VALUES(0);
	bds_bind(VV[153],V2);                     /*  *PACKAGE*       */
	bds_bind(VV[155],Ct);                     /*  *PRINT-ARRAY*   */
	bds_bind(VV[156],MAKE_FIXNUM(10));        /*  *PRINT-BASE*    */
	bds_bind(VV[157],VV[158]);                /*  *PRINT-CASE*    */
	bds_bind(VV[159],Cnil);                   /*  *PRINT-CIRCLE*  */
	bds_bind(VV[130],Ct);                     /*  *PRINT-ESCAPE*  */
	bds_bind(VV[160],Ct);                     /*  *PRINT-GENSYM*  */
	bds_bind(VV[112],Cnil);                   /*  *PRINT-LENGTH*  */
	bds_bind(VV[111],Cnil);                   /*  *PRINT-LEVEL*   */
	bds_bind(VV[161],Cnil);                   /*  *PRINT-PRETTY*  */
	bds_bind(VV[162],Cnil);                   /*  *PRINT-RADIX*   */
	bds_bind(VV[163],MAKE_FIXNUM(10));        /*  *READ-BASE*     */
	bds_bind(VV[164],VV[165]);                /*  *READ-DEFAULT-FLOAT-FORMAT**/
	bds_bind(VV[166],Cnil);                   /*  *READ-SUPPRESS* */
	{int V3;
	V3=funcall(1,(V1));
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V3);}
	}
}
/*	macro definition for WITH-STANDARD-IO-SYNTAX                  */
static L50(int narg, object V1, object V2)
{ VT61 VLEX61 CLSR61
	{object V3=CDR(V1),V4;
	V4= V3;
	VALUES(0) = list(3,VV[167],CONS(listA(3,VV[168],Cnil,(V4)),Cnil),VV[169]);
	RETURN(1);}
}
/*	function definition for DEFAULT-KEYSYM-TRANSLATE              */
static L51(int narg, object V1, object V2, object V3)
{ VT62 VLEX62 CLSR62
	{register int V4;
	V4= fix(V2);
TTL:
	if(!(CHARACTERP((V3)))){
	goto L380;}
	(*LK9)(2,VV[176],VV[177])                 /*  POSITION        */;
	Llogbitp(2,VALUES(0),MAKE_FIXNUM(V4))     /*  LOGBITP         */;
	if(VALUES(0)==Cnil){
	goto L383;}
	{int V5;
	V5= 1;
	{unsigned char V6;
	Lset_char_bit(3,(V3),VV[176],MAKE_FIXNUM(V5))/*  SET-CHAR-BIT */;
	V6= char_code(VALUES(0));
	V3= code_char(V6);
	}
	}
L383:
	(*LK10)(3,(V1),MAKE_FIXNUM(V4),(VV[175]->s.s_dbind))/*  STATE-KEYSYMP*/;
	if(VALUES(0)!=Cnil){
	goto L392;}
	(*LK10)(3,(V1),MAKE_FIXNUM(V4),(VV[174]->s.s_dbind))/*  STATE-KEYSYMP*/;
	if(VALUES(0)==Cnil){
	goto L391;}
L392:
	{int V5;
	V5= 1;
	{unsigned char V6;
	Lset_char_bit(3,(V3),VV[178],MAKE_FIXNUM(V5))/*  SET-CHAR-BIT */;
	V6= char_code(VALUES(0));
	V3= code_char(V6);
	}
	}
L391:
	(*LK10)(3,(V1),MAKE_FIXNUM(V4),(VV[173]->s.s_dbind))/*  STATE-KEYSYMP*/;
	if(VALUES(0)!=Cnil){
	goto L401;}
	(*LK10)(3,(V1),MAKE_FIXNUM(V4),(VV[172]->s.s_dbind))/*  STATE-KEYSYMP*/;
	if(VALUES(0)==Cnil){
	goto L400;}
L401:
	{int V5;
	V5= 1;
	{unsigned char V6;
	Lset_char_bit(3,(V3),VV[179],MAKE_FIXNUM(V5))/*  SET-CHAR-BIT */;
	V6= char_code(VALUES(0));
	V3= code_char(V6);
	}
	}
L400:
	(*LK10)(3,(V1),MAKE_FIXNUM(V4),(VV[171]->s.s_dbind))/*  STATE-KEYSYMP*/;
	if(VALUES(0)!=Cnil){
	goto L409;}
	(*LK10)(3,(V1),MAKE_FIXNUM(V4),(VV[170]->s.s_dbind))/*  STATE-KEYSYMP*/;
	if(VALUES(0)==Cnil){
	goto L380;}
L409:
	{int V5;
	V5= 1;
	{unsigned char V6;
	Lset_char_bit(3,(V3),VV[180],MAKE_FIXNUM(V5))/*  SET-CHAR-BIT */;
	V6= char_code(VALUES(0));
	V3= code_char(V6);
	}
	}
L380:
	VALUES(0) = (V3);
	RETURN(1);
	}
}
/*	macro definition for READ-IMAGE-LOAD-BYTE                     */
static L66(int narg, object V1, object V2)
{ VT63 VLEX63 CLSR63
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= CAR(V3);
	V5= number_minus(MAKE_FIXNUM(7),(V5));
	{object V7= list(2,VV[226],(V4));
	{object V8= list(3,VV[228],(V4),(V5));
	VALUES(0) = list(3,VV[225],(V7),list(3,VV[227],(V8),list(3,VV[225],VV[229],(V6))));
	RETURN(1);}}}
}
/*	macro definition for READ-IMAGE-ASSEMBLE-BYTES                */
static L67(int narg, object V1, object V2)
{ VT64 VLEX64 CLSR64
	{object V3=CDR(V1),V4;
	V4= V3;
	V4= reverse((V4));
	{volatile object V5;                      /*  IT              */
	volatile object V6;                       /*  COUNT           */
	V5= CAR((V4));
	V6= MAKE_FIXNUM(0);
	{volatile object V7;
	volatile object V8;                       /*  BYTE            */
	V7= CDR((V4));
	V8= Cnil;
L426:
	if(!((V7)==Cnil)){
	goto L427;}
	goto L422;
L427:
	V8= CAR((V7));
	{object V10= list(3,VV[225],VV[229],(V8));
	V6= number_plus((V6),MAKE_FIXNUM(8));
	{object V11= list(3,VV[228],MAKE_FIXNUM(8),(V6));
	V5= list(4,VV[230],(V10),(V11),list(3,VV[225],list(2,VV[226],(V6)),(V5)));}}
	V7= CDR((V7));
	goto L426;
	}
L422:
	VALUES(0) = list(3,VV[225],list(2,VV[226],fixnum_times(length((V4)),8)),(V5));
	RETURN(1);
	}}
}
/*	macro definition for WRITE-IMAGE-LOAD-BYTE                    */
static L68(int narg, object V1, object V2)
{ VT65 VLEX65 CLSR65
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= CAR(V3);
	Lminus(3,(V6),MAKE_FIXNUM(8),(V4))        /*  -               */;
	V4= VALUES(0);
	{object V7= list(3,VV[228],MAKE_FIXNUM(8),(V4));
	VALUES(0) = list(3,VV[225],VV[229],list(3,VV[227],(V7),list(3,VV[225],list(2,VV[226],(V6)),(V5))));
	RETURN(1);}}
}
/*	macro definition for WRITE-IMAGE-ASSEMBLE-BYTES               */
static L69(int narg, object V1, object V2)
{ VT66 VLEX66 CLSR66
	{object V3=CDR(V1),V4;
	V4= V3;
	V4= reverse((V4));
	{volatile object V5;                      /*  SIZE            */
	volatile object V6;                       /*  IT              */
	volatile object V7;                       /*  COUNT           */
	Lfloor(2,MAKE_FIXNUM(8),MAKE_FIXNUM(length((V4))))/*  FLOOR   */;
	V5= VALUES(0);
	V6= CAR((V4));
	V7= MAKE_FIXNUM(0);
	{volatile object V8;
	volatile object V9;                       /*  BYTE            */
	V8= CDR((V4));
	V9= Cnil;
L449:
	if(!((V8)==Cnil)){
	goto L450;}
	goto L445;
L450:
	V9= CAR((V8));
	{object V11= list(3,VV[225],list(2,VV[226],(V5)),(V9));
	V7= number_plus((V7),(V5));
	{object V12= list(3,VV[228],(V5),(V7));
	V6= list(4,VV[230],(V11),(V12),list(3,VV[225],list(2,VV[226],(V7)),(V6)));}}
	V8= CDR((V8));
	goto L449;
	}
L445:
	VALUES(0) = list(3,VV[225],VV[229],(V6));
	RETURN(1);
	}}
}
/*	function definition for FAST-READ-PIXARRAY                    */
static L70(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9, object V10, object V11, object V12)
{ VT67 VLEX67 CLSR67
	{int V13;
	int V14;
	int V15;
	int V16;
	int V17;
	int V18;
	int V19;
	int V20;
	V13= fix(V2);
	V14= fix(V4);
	V15= fix(V5);
	V16= fix(V6);
	V17= fix(V7);
	V18= fix(V8);
	V19= fix(V9);
	V20= fix(V10);
TTL:
	{object V21;                              /*  FUNCTION        */
	if((Cnil)==Cnil){
	goto L474;}
	RETURN((*LK11)(16,(V1),MAKE_FIXNUM(V13),(V3),MAKE_FIXNUM(V14),MAKE_FIXNUM(V15),MAKE_FIXNUM(V16),MAKE_FIXNUM(V17),MAKE_FIXNUM(V18),MAKE_FIXNUM(V19),Cnil,MAKE_FIXNUM(V20),(V11),(V12),MAKE_FIXNUM(32),Cnil,Cnil)/*  READ-PIXARRAY-INTERNAL*/);
L474:
	VALUES(0) = Cnil;
	RETURN(1);
	}
	}
}
/*	function definition for FAST-WRITE-PIXARRAY                   */
static L71(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9, object V10, object V11, object V12)
{ VT68 VLEX68 CLSR68
	{int V13;
	int V14;
	int V15;
	int V16;
	int V17;
	int V18;
	int V19;
	int V20;
	V13= fix(V2);
	V14= fix(V4);
	V15= fix(V5);
	V16= fix(V6);
	V17= fix(V7);
	V18= fix(V8);
	V19= fix(V9);
	V20= fix(V10);
TTL:
	{object V21;                              /*  FUNCTION        */
	if((Cnil)==Cnil){
	goto L489;}
	RETURN((*LK12)(16,(V1),MAKE_FIXNUM(V13),(V3),MAKE_FIXNUM(V14),MAKE_FIXNUM(V15),MAKE_FIXNUM(V16),MAKE_FIXNUM(V17),MAKE_FIXNUM(V18),MAKE_FIXNUM(V19),Cnil,MAKE_FIXNUM(32),Cnil,Cnil,MAKE_FIXNUM(V20),(V11),(V12))/*  WRITE-PIXARRAY-INTERNAL*/);
L489:
	VALUES(0) = Cnil;
	RETURN(1);
	}
	}
}
/*	function definition for FAST-COPY-PIXARRAY                    */
static L72(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7)
{ VT69 VLEX69 CLSR69
TTL:
	VALUES(0) = Cnil;
	RETURN(1);
}
static LKF12(int narg, ...) {TRAMPOLINK(VV[340],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[338],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[336],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[335],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[333],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[332],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[327],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[326],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[264],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[321],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[316],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[233],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[309],&LK0);}
