/*
    vs.h  -- Multiple Values.
*/
/*
    Copyright (c) 1990, Giuseppe Attardi.

    ECoLisp is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    See file '../Copyright' for full details.
*/

#define VSSIZE	128
#define VALUES(n)	Values[n]
#define RETURN(x)	return(x)

#ifdef MTCL
#define Values     clwp->lwp_Values
#else
extern object Values[VSSIZE];
#endif

#define	check_arg(n)  \
			if (narg != (n))  \
				check_arg_failed(narg, n)

#define cs_reserve(x)	if(&narg-(x) < cs_limit)  \
				cs_overflow();
