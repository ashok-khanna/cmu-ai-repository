
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "seqlib.h"
init_seqlib(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_seqlib; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	funcall(2,symbol_function(VV[27]),VV[0])  /*  PROCLAIM        */;
	funcall(2,symbol_function(VV[27]),VV[1])  /*  PROCLAIM        */;
	MF0(VV[28],L1);
	funcall(2,symbol_function(VV[27]),VV[7])  /*  PROCLAIM        */;
	MF0(VV[29],L2);
	funcall(2,symbol_function(VV[27]),VV[8])  /*  PROCLAIM        */;
	MF0(VV[30],L3);
	MF0(VV[31],L4);
	MF0(VV[32],L5);
	MF0(VV[33],L6);
	MF0key(VV[34],L7,4,L7keys);
	MF0key(VV[35],L8,2,L8keys);
	MF0key(VV[36],L9,4,L9keys);
	MF0key(VV[18],L10,7,L10keys);
	MF0key(VV[37],L11,5,L11keys);
	MF0key(VV[38],L12,5,L12keys);
	MF0key(VV[19],L13,7,L13keys);
	MF0key(VV[39],L14,5,L14keys);
	MF0key(VV[40],L15,5,L15keys);
	MF0key(VV[20],L16,6,L16keys);
	MF0key(VV[41],L17,4,L17keys);
	MF0key(VV[42],L18,4,L18keys);
	MF0key(VV[21],L19,7,L19keys);
	MF0key(VV[22],L20,7,L20keys);
	MF0key(VV[43],L21,5,L21keys);
	MF0key(VV[44],L22,5,L22keys);
	MF0key(VV[23],L23,7,L23keys);
	MF0key(VV[45],L24,5,L24keys);
	MF0key(VV[46],L25,5,L25keys);
	MF0key(VV[24],L26,6,L26keys);
	MF0key(VV[47],L27,4,L27keys);
	MF0key(VV[48],L28,4,L28keys);
	MF0key(VV[25],L29,6,L29keys);
	MF0key(VV[49],L30,4,L30keys);
	MF0key(VV[50],L31,4,L31keys);
	MF0key(VV[51],L32,6,L32keys);
	MF0key(VV[52],L33,6,L33keys);
	MF0key(VV[53],L34,8,L34keys);
	MF0key(VV[54],L35,8,L35keys);
	MF0key(VV[55],L36,1,L36keys);
	MF0(VV[56],L37);
	funcall(2,symbol_function(VV[27]),VV[26]) /*  PROCLAIM        */;
	MF0(VV[57],L39);
	MF0key(VV[58],L40,1,L40keys);
	MF0key(VV[59],L41,1,L41keys);
}
/*	local entry for function SEQTYPE                              */
static object LI1(register object V1)
{ VT3 VLEX3 CLSR3
TTL:
	if(!(type_of((V1))==t_cons||(V1)==Cnil)){
	goto L15;}
	return(VV[2]);
L15:
	if(!(type_of((V1))==t_string)){
	goto L18;}
	return(VV[3]);
L18:
	if(!((type_of((V1))==t_bitvector))){
	goto L21;}
	return(VV[4]);
L21:
	if(!(type_of((V1))==t_vector||
type_of((V1))==t_string||
type_of((V1))==t_bitvector)){
	goto L24;}
	Larray_element_type(1,(V1))               /*  ARRAY-ELEMENT-TYPE*/;
	return(list(2,VV[5],VALUES(0)));
L24:
	return(Lerror(2,VV[6],(V1))               /*  ERROR           */,VALUES(0));
}
/*	local entry for function CALL-TEST                            */
static object LI2(object V1,object V2,object V3,object V4)
{ VT4 VLEX4 CLSR4
TTL:
	if(((V1))==Cnil){
	goto L28;}
	return(funcall(3,(V1),(V3),(V4)),VALUES(0));
L28:
	if(((V2))==Cnil){
	goto L31;}
	funcall(3,(V2),(V3),(V4));
	return(((VALUES(0))==Cnil?Ct:Cnil));
L31:
	return((eql((V3),(V4))?Ct:Cnil));
}
/*	local entry for function TEST-ERROR                           */
static object LI3()
{ VT5 VLEX5 CLSR5
TTL:
	return(Lerror(1,VV[9])                    /*  ERROR           */,VALUES(0));
}
/*	function definition for BAD-SEQ-LIMIT                         */
static L4(int narg, object V1, ...)
{ VT6 VLEX6 CLSR6
	cs_check;
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if(narg<1) FEtoo_few_arguments(&narg);
	if(narg>2) FEtoo_many_arguments(&narg);
	if (i==narg) goto L34;
	V2= va_arg(args, object);
	i++;
	goto L35;
L34:
	V2= Cnil;
L35:
	if(((V2))==Cnil){
	goto L39;}
	VALUES(0) = list(2,(V1),(V2));
	goto L37;
L39:
	VALUES(0) = (V1);
L37:
	RETURN(Lerror(2,VV[10],VALUES(0))         /*  ERROR           */);
	}
}
/*	function definition for THE-END                               */
static L5(int narg, object V1, object V2)
{ VT7 VLEX7 CLSR7
	cs_check;
	check_arg(2);
TTL:
	if(!(FIXNUMP((V1)))){
	goto L42;}
	if((fix((V1)))<=(length((V2)))){
	goto L44;}
	L4(1,(V1))                                /*  BAD-SEQ-LIMIT   */;
L44:
	VALUES(0) = (V1);
	RETURN(1);
L42:
	if(((V1))!=Cnil){
	goto L48;}
	VALUES(0) = MAKE_FIXNUM(length((V2)));
	RETURN(1);
L48:
	RETURN(L4(1,(V1))                         /*  BAD-SEQ-LIMIT   */);
}
/*	function definition for THE-START                             */
static L6(int narg, object V1)
{ VT8 VLEX8 CLSR8
	cs_check;
	check_arg(1);
TTL:
	if(!(FIXNUMP((V1)))){
	goto L51;}
	if((fix((V1)))>=(0)){
	goto L53;}
	L4(1,(V1))                                /*  BAD-SEQ-LIMIT   */;
L53:
	VALUES(0) = (V1);
	RETURN(1);
L51:
	if(((V1))!=Cnil){
	goto L57;}
	VALUES(0) = MAKE_FIXNUM(0);
	RETURN(1);
L57:
	RETURN(L4(1,(V1))                         /*  BAD-SEQ-LIMIT   */);
}
/*	function definition for REDUCE                                */
static L7(int narg, object V1, object V2, ...)
{ VT9 VLEX9 CLSR9
	cs_check;
	{volatile object V3;
	volatile object V4;
	volatile object V5;
	volatile object V6;
	volatile object V7;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -=2;
	{ object keyvars[8];
	parse_key(narg,args,4,L7keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	V7= keyvars[7];
	}
	{volatile int V8;                         /*  START           */
	volatile int V9;                          /*  END             */
	if(((V4))==Cnil){
	goto L61;}
	L6(1,(V4))                                /*  THE-START       */;
	V8= fix(VALUES(0));
	goto L59;
L61:
	V8= 0;
L59:
	L5(2,(V5),(V2))                           /*  THE-END         */;
	V9= fix(VALUES(0));
	if((V8)<=(V9)){
	goto L64;}
	L4(2,MAKE_FIXNUM(V8),MAKE_FIXNUM(V9))     /*  BAD-SEQ-LIMIT   */;
L64:
	if(((V3))!=Cnil){
	goto L68;}
	if(((V7))!=Cnil){
	goto L70;}
	if(!((V8)>=(V9))){
	goto L73;}
	RETURN(funcall(1,(V1)));
L73:
	V6= elt((V2),V8);
	V8= (V8)+(1);
L70:
	{volatile object V10;                     /*  X               */
	V10= (V6);
L80:
	if(!((V8)>=(V9))){
	goto L81;}
	VALUES(0) = (V10);
	RETURN(1);
L81:
	{register object V12;
	V12= elt((V2),V8);
	V8= (V8)+(1);
	VALUES(0) = (V12);
	}
	funcall(3,(V1),(V10),VALUES(0));
	V10= VALUES(0);
	goto L80;
	}
L68:
	if(((V7))!=Cnil){
	goto L91;}
	if(!((V8)>=(V9))){
	goto L94;}
	RETURN(funcall(1,(V1)));
L94:
	V9= (V9)-(1);
	V6= elt((V2),V9);
L91:
	{volatile object V12;                     /*  X               */
	V12= (V6);
L101:
	if(!((V8)>=(V9))){
	goto L102;}
	VALUES(0) = (V12);
	RETURN(1);
L102:
	V9= (V9)-(1);
	funcall(3,(V1),elt((V2),V9),(V12));
	V12= VALUES(0);
	goto L101;
	}
	}
	}
}
/*	function definition for FILL                                  */
static L8(int narg, object V1, object V2, ...)
{ VT10 VLEX10 CLSR10
	cs_check;
	{volatile object V3;
	volatile object V4;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -=2;
	{ object keyvars[4];
	parse_key(narg,args,2,L8keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	}
	{volatile int V5;                         /*  START           */
	volatile int V6;                          /*  END             */
	if(((V3))==Cnil){
	goto L112;}
	L6(1,(V3))                                /*  THE-START       */;
	V5= fix(VALUES(0));
	goto L110;
L112:
	V5= 0;
L110:
	L5(2,(V4),(V1))                           /*  THE-END         */;
	V6= fix(VALUES(0));
	if((V5)<=(V6)){
	goto L115;}
	L4(2,MAKE_FIXNUM(V5),MAKE_FIXNUM(V6))     /*  BAD-SEQ-LIMIT   */;
L115:
	{volatile int V7;                         /*  I               */
	V7= V5;
L120:
	if(!((V7)>=(V6))){
	goto L121;}
	VALUES(0) = (V1);
	RETURN(1);
L121:
	elt_set((V1),V7,(V2));
	V7= (V7)+1;
	goto L120;
	}
	}
	}
}
/*	function definition for REPLACE                               */
static L9(int narg, object V1, object V2, ...)
{ VT11 VLEX11 CLSR11
	cs_check;
	{volatile object V3;
	volatile object V4;
	volatile object V5;
	volatile object V6;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -=2;
	{ object keyvars[8];
	parse_key(narg,args,4,L9keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	}
	{volatile int V7;                         /*  START1          */
	volatile int V8;                          /*  END1            */
	if(((V3))==Cnil){
	goto L130;}
	L6(1,(V3))                                /*  THE-START       */;
	V7= fix(VALUES(0));
	goto L128;
L130:
	V7= 0;
L128:
	L5(2,(V4),(V1))                           /*  THE-END         */;
	V8= fix(VALUES(0));
	if((V7)<=(V8)){
	goto L133;}
	L4(2,MAKE_FIXNUM(V7),MAKE_FIXNUM(V8))     /*  BAD-SEQ-LIMIT   */;
L133:
	{volatile int V9;                         /*  START2          */
	volatile int V10;                         /*  END2            */
	if(((V5))==Cnil){
	goto L138;}
	L6(1,(V5))                                /*  THE-START       */;
	V9= fix(VALUES(0));
	goto L136;
L138:
	V9= 0;
L136:
	L5(2,(V6),(V2))                           /*  THE-END         */;
	V10= fix(VALUES(0));
	if((V9)<=(V10)){
	goto L141;}
	L4(2,MAKE_FIXNUM(V9),MAKE_FIXNUM(V10))    /*  BAD-SEQ-LIMIT   */;
L141:
	if(!(((V1))==((V2)))){
	goto L145;}
	if(!((V7)>(V9))){
	goto L145;}
	{volatile int V11;                        /*  I               */
	volatile int V12;                         /*  L               */
	volatile int V13;                         /*  S1              */
	volatile int V14;                         /*  S2              */
	V11= 0;
	if(!(((V8)-(V7))<((V10)-(V9)))){
	goto L152;}
	V12= (V8)-(V7);
	goto L150;
L152:
	V12= (V10)-(V9);
L150:
	V13= (V7)+((V12)-1);
	V14= (V9)+((V12)-1);
L157:
	if(!((V11)>=(V12))){
	goto L158;}
	VALUES(0) = (V1);
	RETURN(1);
L158:
	elt_set((V1),V13,elt((V2),V14));
	V11= (V11)+1;
	V13= (V13)-1;
	V14= (V14)-1;
	goto L157;
	}
L145:
	{volatile int V16;                        /*  I               */
	volatile int V17;                         /*  L               */
	volatile int V18;                         /*  S1              */
	volatile int V19;                         /*  S2              */
	V16= 0;
	if(!(((V8)-(V7))<((V10)-(V9)))){
	goto L172;}
	V17= (V8)-(V7);
	goto L170;
L172:
	V17= (V10)-(V9);
L170:
	V18= V7;
	V19= V9;
L177:
	if(!((V16)>=(V17))){
	goto L178;}
	VALUES(0) = (V1);
	RETURN(1);
L178:
	elt_set((V1),V18,elt((V2),V19));
	V16= (V16)+1;
	V18= (V18)+1;
	V19= (V19)+1;
	goto L177;
	}
	}
	}
	}
}
/*	function definition for REMOVE                                */
static L10(int narg, object V1, object V2, ...)
{ VT12 VLEX12 CLSR12
	cs_check;
	{volatile object V3;
	volatile object V4;
	volatile object V5;
	volatile object V6;
	volatile object V7;
	volatile object V8;
	volatile object V9;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -=2;
	{ object keyvars[14];
	parse_key(narg,args,7,L10keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	V7= keyvars[4];
	V8= keyvars[5];
	if(keyvars[13]==Cnil){
	V9= symbol_function(VV[65]);
	}else{
	V9= keyvars[6];}
	}
	{volatile int V10;                        /*  START           */
	volatile int V11;                         /*  END             */
	if(((V6))==Cnil){
	goto L190;}
	L6(1,(V6))                                /*  THE-START       */;
	V10= fix(VALUES(0));
	goto L188;
L190:
	V10= 0;
L188:
	L5(2,(V7),(V2))                           /*  THE-END         */;
	V11= fix(VALUES(0));
	if((V10)<=(V11)){
	goto L193;}
	L4(2,MAKE_FIXNUM(V10),MAKE_FIXNUM(V11))   /*  BAD-SEQ-LIMIT   */;
L193:
	{volatile int V12;                        /*  COUNT           */
	if(((V8))!=Cnil){
	goto L198;}
	V12= 536870911;
	goto L196;
L198:
	V12= fix((V8));
L196:
	if((V4)==Cnil){
	goto L201;}
	if((V5)==Cnil){
	goto L201;}
	LI3();
L201:
	if(((V3))!=Cnil){
	goto L203;}
	if(!(type_of((V2))==t_cons||(V2)==Cnil)){
	goto L206;}
	{volatile object V13;                     /*  L               */
	volatile object V14;                      /*  L1              */
	V13= (V2);
	V14= Cnil;
	{volatile int V15;                        /*  I               */
	V15= 0;
L211:
	if(!((V15)>=(V10))){
	goto L212;}
	goto L208;
L212:
	V14= CONS(car((V13)),(V14));
	{register object V17;
	V17= car((V13));
	V13= cdr((V13));
	}
	V15= (V15)+1;
	goto L211;
	}
L208:
	{volatile int V15;                        /*  I               */
	volatile int V16;                         /*  J               */
	V15= V10;
	V16= 0;
L227:
	if((V15)>=(V11)){
	goto L229;}
	if((V16)>=(V12)){
	goto L229;}
	if(!(endp((V13)))){
	goto L228;}
L229:
	RETURN(Lreconc(2,(V14),(V13))             /*  NRECONC         */);
L228:
	funcall(2,(V9),car((V13)));
	if((LI2((V4),(V5),(V1),VALUES(0)))==Cnil){
	goto L237;}
	V16= (V16)+(1);
	goto L235;
L237:
	V14= CONS(car((V13)),(V14));
L235:
	{register object V18;
	V18= car((V13));
	V13= cdr((V13));
	}
	V15= (V15)+1;
	goto L227;
	}
	}
L206:
	RETURN(L13(16,(V1),(V2),VV[11],(V3),VV[12],(V4),VV[13],(V5),VV[14],MAKE_FIXNUM(V10),VV[15],MAKE_FIXNUM(V11),VV[16],MAKE_FIXNUM(V12),VV[17],(V9))/*  DELETE*/);
L203:
	RETURN(L13(16,(V1),(V2),VV[11],(V3),VV[12],(V4),VV[13],(V5),VV[14],MAKE_FIXNUM(V10),VV[15],MAKE_FIXNUM(V11),VV[16],MAKE_FIXNUM(V12),VV[17],(V9))/*  DELETE*/);
	}
	}
	}
}
/*	function definition for REMOVE-IF                             */
static L11(int narg, object V1, object V2, ...)
{ VT13 VLEX13 CLSR13
	cs_check;
	{object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -=2;
	{ object keyvars[10];
	parse_key(narg,args,5,L11keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	if(keyvars[9]==Cnil){
	V7= symbol_function(VV[65]);
	}else{
	V7= keyvars[4];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L10(14,(V1),(V2),VV[11],(V3),VV[12],VALUES(0),VV[14],(V4),VV[15],(V5),VV[16],(V6),VV[17],(V7))/*  REMOVE*/);
	}
}
/*	function definition for REMOVE-IF-NOT                         */
static L12(int narg, object V1, object V2, ...)
{ VT14 VLEX14 CLSR14
	cs_check;
	{object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -=2;
	{ object keyvars[10];
	parse_key(narg,args,5,L12keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	if(keyvars[9]==Cnil){
	V7= symbol_function(VV[65]);
	}else{
	V7= keyvars[4];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L10(14,(V1),(V2),VV[11],(V3),VV[13],VALUES(0),VV[14],(V4),VV[15],(V5),VV[16],(V6),VV[17],(V7))/*  REMOVE*/);
	}
}
/*	function definition for DELETE                                */
static L13(int narg, object V1, object V2, ...)
{ VT15 VLEX15 CLSR15
	cs_check;
	{volatile object V3;
	volatile object V4;
	volatile object V5;
	volatile object V6;
	volatile object V7;
	volatile object V8;
	volatile object V9;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -=2;
	{ object keyvars[14];
	parse_key(narg,args,7,L13keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	V7= keyvars[4];
	V8= keyvars[5];
	if(keyvars[13]==Cnil){
	V9= symbol_function(VV[65]);
	}else{
	V9= keyvars[6];}
	}
	{int V10;                                 /*  L               */
	V10= length((V2));
	{volatile int V11;                        /*  START           */
	volatile int V12;                         /*  END             */
	if(((V6))==Cnil){
	goto L257;}
	L6(1,(V6))                                /*  THE-START       */;
	V11= fix(VALUES(0));
	goto L255;
L257:
	V11= 0;
L255:
	L5(2,(V7),(V2))                           /*  THE-END         */;
	V12= fix(VALUES(0));
	if((V11)<=(V12)){
	goto L260;}
	L4(2,MAKE_FIXNUM(V11),MAKE_FIXNUM(V12))   /*  BAD-SEQ-LIMIT   */;
L260:
	{volatile int V13;                        /*  COUNT           */
	if(((V8))!=Cnil){
	goto L265;}
	V13= 536870911;
	goto L263;
L265:
	V13= fix((V8));
L263:
	if((V4)==Cnil){
	goto L268;}
	if((V5)==Cnil){
	goto L268;}
	LI3();
L268:
	if(((V3))!=Cnil){
	goto L270;}
	if(!(type_of((V2))==t_cons||(V2)==Cnil)){
	goto L273;}
	{volatile object V14;                     /*  L0              */
	volatile object V15;                      /*  L               */
	V14= CONS(Cnil,(V2));
	V15= (V14);
	{volatile int V16;                        /*  I               */
	V16= 0;
L280:
	if(!((V16)>=(V11))){
	goto L281;}
	goto L277;
L281:
	{object V18;
	V18= car((V15));
	V15= cdr((V15));
	}
	V16= (V16)+1;
	goto L280;
	}
L277:
	{volatile int V16;                        /*  I               */
	volatile int V17;                         /*  J               */
	V16= V11;
	V17= 0;
L294:
	if((V16)>=(V12)){
	goto L296;}
	if((V17)>=(V13)){
	goto L296;}
	if(!(endp(cdr((V15))))){
	goto L295;}
L296:
	VALUES(0) = cdr((V14));
	RETURN(1);
L295:
	funcall(2,(V9),cadr((V15)));
	if((LI2((V4),(V5),(V1),VALUES(0)))==Cnil){
	goto L304;}
	V17= (V17)+(1);
	if(type_of((V15))!=t_cons)FEwrong_type_argument(Scons,(V15));
	CDR((V15)) = cddr((V15));
	goto L302;
L304:
	V15= cdr((V15));
L302:
	V16= (V16)+1;
	goto L294;
	}
	}
L273:
	{volatile int V19;                        /*  N               */
	L19(16,(V1),(V2),VV[11],(V3),VV[12],(V4),VV[13],(V5),VV[14],MAKE_FIXNUM(V11),VV[15],MAKE_FIXNUM(V12),VV[16],MAKE_FIXNUM(V13),VV[17],(V9))/*  INTERNAL-COUNT*/;
	V19= fix(VALUES(0));
	if(!((V19)<(V13))){
	goto L314;}
	V13= V19;
L314:
	{volatile object V20;                     /*  NEWSEQ          */
	volatile int V21;                         /*  I               */
	volatile int V22;                         /*  J               */
	volatile int V23;                         /*  K               */
	{object V24= LI1((V2));
	(*LK0)(2,(V24),MAKE_FIXNUM((V10)-(V13)))  /*  MAKE-SEQUENCE   */;
	V20= VALUES(0);}
	V21= 0;
	V22= 0;
	V23= 0;
L323:
	if(!((V21)>=(V10))){
	goto L324;}
	VALUES(0) = (V20);
	RETURN(1);
L324:
	if(!((V11)<=(V21))){
	goto L329;}
	if(!((V21)<(V12))){
	goto L329;}
	if(!((V23)<(V13))){
	goto L329;}
	funcall(2,(V9),elt((V2),V21));
	if((LI2((V4),(V5),(V1),VALUES(0)))==Cnil){
	goto L329;}
	V23= (V23)+1;
	goto L327;
L329:
	elt_set((V20),V22,elt((V2),V21));
	V22= (V22)+(1);
L327:
	V21= (V21)+1;
	goto L323;
	}
	}
L270:
	{volatile int V25;                        /*  N               */
	L19(16,(V1),(V2),VV[11],(V3),VV[12],(V4),VV[13],(V5),VV[14],MAKE_FIXNUM(V11),VV[15],MAKE_FIXNUM(V12),VV[16],MAKE_FIXNUM(V13),VV[17],(V9))/*  INTERNAL-COUNT*/;
	V25= fix(VALUES(0));
	if(!((V25)<(V13))){
	goto L345;}
	V13= V25;
L345:
	{volatile object V26;                     /*  NEWSEQ          */
	volatile int V27;                         /*  I               */
	volatile int V28;                         /*  J               */
	volatile int V29;                         /*  K               */
	{object V30= LI1((V2));
	(*LK0)(2,(V30),MAKE_FIXNUM((V10)-(V13)))  /*  MAKE-SEQUENCE   */;
	V26= VALUES(0);}
	V27= (V10)-1;
	V28= ((V12)-1)-(V25);
	V29= 0;
L354:
	if(!((V27)<(0))){
	goto L355;}
	VALUES(0) = (V26);
	RETURN(1);
L355:
	if(!((V11)<=(V27))){
	goto L360;}
	if(!((V27)<(V12))){
	goto L360;}
	if(!((V29)<(V13))){
	goto L360;}
	funcall(2,(V9),elt((V2),V27));
	if((LI2((V4),(V5),(V1),VALUES(0)))==Cnil){
	goto L360;}
	V29= (V29)+1;
	goto L358;
L360:
	elt_set((V26),V28,elt((V2),V27));
	V28= (V28)-(1);
L358:
	V27= (V27)-1;
	goto L354;
	}
	}
	}
	}
	}
	}
}
/*	function definition for DELETE-IF                             */
static L14(int narg, object V1, object V2, ...)
{ VT16 VLEX16 CLSR16
	cs_check;
	{object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -=2;
	{ object keyvars[10];
	parse_key(narg,args,5,L14keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	if(keyvars[9]==Cnil){
	V7= symbol_function(VV[65]);
	}else{
	V7= keyvars[4];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L13(14,(V1),(V2),VV[11],(V3),VV[12],VALUES(0),VV[14],(V4),VV[15],(V5),VV[16],(V6),VV[17],(V7))/*  DELETE*/);
	}
}
/*	function definition for DELETE-IF-NOT                         */
static L15(int narg, object V1, object V2, ...)
{ VT17 VLEX17 CLSR17
	cs_check;
	{object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -=2;
	{ object keyvars[10];
	parse_key(narg,args,5,L15keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	if(keyvars[9]==Cnil){
	V7= symbol_function(VV[65]);
	}else{
	V7= keyvars[4];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L13(14,(V1),(V2),VV[11],(V3),VV[13],VALUES(0),VV[14],(V4),VV[15],(V5),VV[16],(V6),VV[17],(V7))/*  DELETE*/);
	}
}
/*	function definition for COUNT                                 */
static L16(int narg, object V1, object V2, ...)
{ VT18 VLEX18 CLSR18
	cs_check;
	{volatile object V3;
	volatile object V4;
	volatile object V5;
	volatile object V6;
	volatile object V7;
	volatile object V8;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -=2;
	{ object keyvars[12];
	parse_key(narg,args,6,L16keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	V7= keyvars[4];
	if(keyvars[11]==Cnil){
	V8= symbol_function(VV[65]);
	}else{
	V8= keyvars[5];}
	}
	{volatile int V9;                         /*  START           */
	volatile int V10;                         /*  END             */
	if(((V6))==Cnil){
	goto L382;}
	L6(1,(V6))                                /*  THE-START       */;
	V9= fix(VALUES(0));
	goto L380;
L382:
	V9= 0;
L380:
	L5(2,(V7),(V2))                           /*  THE-END         */;
	V10= fix(VALUES(0));
	if((V9)<=(V10)){
	goto L385;}
	L4(2,MAKE_FIXNUM(V9),MAKE_FIXNUM(V10))    /*  BAD-SEQ-LIMIT   */;
L385:
	if((V4)==Cnil){
	goto L388;}
	if((V5)==Cnil){
	goto L388;}
	LI3();
L388:
	if(((V3))!=Cnil){
	goto L390;}
	{volatile int V11;                        /*  I               */
	volatile int V12;                         /*  K               */
	V11= V9;
	V12= 0;
L395:
	if(!((V11)>=(V10))){
	goto L396;}
	VALUES(0) = MAKE_FIXNUM(V12);
	RETURN(1);
L396:
	funcall(2,(V8),elt((V2),V11));
	if((LI2((V4),(V5),(V1),VALUES(0)))==Cnil){
	goto L399;}
	V12= (V12)+1;
L399:
	V11= (V11)+1;
	goto L395;
	}
L390:
	{volatile int V14;                        /*  I               */
	volatile int V15;                         /*  K               */
	V14= (V10)-1;
	V15= 0;
L410:
	if(!((V14)<(V9))){
	goto L411;}
	VALUES(0) = MAKE_FIXNUM(V15);
	RETURN(1);
L411:
	funcall(2,(V8),elt((V2),V14));
	if((LI2((V4),(V5),(V1),VALUES(0)))==Cnil){
	goto L414;}
	V15= (V15)+1;
L414:
	V14= (V14)-1;
	goto L410;
	}
	}
	}
}
/*	function definition for COUNT-IF                              */
static L17(int narg, object V1, object V2, ...)
{ VT19 VLEX19 CLSR19
	cs_check;
	{object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -=2;
	{ object keyvars[8];
	parse_key(narg,args,4,L17keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	if(keyvars[7]==Cnil){
	V6= symbol_function(VV[65]);
	}else{
	V6= keyvars[3];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L16(12,(V1),(V2),VV[11],(V3),VV[12],VALUES(0),VV[14],(V4),VV[15],(V5),VV[17],(V6))/*  COUNT*/);
	}
}
/*	function definition for COUNT-IF-NOT                          */
static L18(int narg, object V1, object V2, ...)
{ VT20 VLEX20 CLSR20
	cs_check;
	{object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -=2;
	{ object keyvars[8];
	parse_key(narg,args,4,L18keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	if(keyvars[7]==Cnil){
	V6= symbol_function(VV[65]);
	}else{
	V6= keyvars[3];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L16(12,(V1),(V2),VV[11],(V3),VV[13],VALUES(0),VV[14],(V4),VV[15],(V5),VV[17],(V6))/*  COUNT*/);
	}
}
/*	function definition for INTERNAL-COUNT                        */
static L19(int narg, object V1, object V2, ...)
{ VT21 VLEX21 CLSR21
	cs_check;
	{volatile object V3;
	volatile object V4;
	volatile object V5;
	volatile object V6;
	volatile object V7;
	volatile object V8;
	volatile object V9;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -=2;
	{ object keyvars[14];
	parse_key(narg,args,7,L19keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	V7= keyvars[4];
	V8= keyvars[5];
	if(keyvars[13]==Cnil){
	V9= symbol_function(VV[65]);
	}else{
	V9= keyvars[6];}
	}
	{volatile int V10;                        /*  START           */
	volatile int V11;                         /*  END             */
	if(((V6))==Cnil){
	goto L429;}
	L6(1,(V6))                                /*  THE-START       */;
	V10= fix(VALUES(0));
	goto L427;
L429:
	V10= 0;
L427:
	L5(2,(V7),(V2))                           /*  THE-END         */;
	V11= fix(VALUES(0));
	if((V10)<=(V11)){
	goto L432;}
	L4(2,MAKE_FIXNUM(V10),MAKE_FIXNUM(V11))   /*  BAD-SEQ-LIMIT   */;
L432:
	{volatile int V12;                        /*  COUNT           */
	if(((V8))!=Cnil){
	goto L437;}
	V12= 536870911;
	goto L435;
L437:
	V12= fix((V8));
L435:
	if((V4)==Cnil){
	goto L440;}
	if((V5)==Cnil){
	goto L440;}
	LI3();
L440:
	if(((V3))!=Cnil){
	goto L442;}
	{volatile int V13;                        /*  I               */
	volatile int V14;                         /*  K               */
	V13= V10;
	V14= 0;
L447:
	if(!((V13)>=(V11))){
	goto L448;}
	VALUES(0) = MAKE_FIXNUM(V14);
	RETURN(1);
L448:
	if(!((V14)<(V12))){
	goto L451;}
	funcall(2,(V9),elt((V2),V13));
	if((LI2((V4),(V5),(V1),VALUES(0)))==Cnil){
	goto L451;}
	V14= (V14)+1;
L451:
	V13= (V13)+1;
	goto L447;
	}
L442:
	{volatile int V16;                        /*  I               */
	volatile int V17;                         /*  K               */
	V16= (V11)-1;
	V17= 0;
L464:
	if(!((V16)<(V10))){
	goto L465;}
	VALUES(0) = MAKE_FIXNUM(V17);
	RETURN(1);
L465:
	if(!((V17)<(V12))){
	goto L468;}
	funcall(2,(V9),elt((V2),V16));
	if((LI2((V4),(V5),(V1),VALUES(0)))==Cnil){
	goto L468;}
	V17= (V17)+1;
L468:
	V16= (V16)-1;
	goto L464;
	}
	}
	}
	}
}
/*	function definition for SUBSTITUTE                            */
static L20(int narg, object V1, object V2, object V3, ...)
{ VT22 VLEX22 CLSR22
	cs_check;
	{volatile object V4;
	volatile object V5;
	volatile object V6;
	volatile object V7;
	volatile object V8;
	volatile object V9;
	volatile object V10;
	va_list args; va_start(args, V3);
	if(narg<3) FEtoo_few_arguments(&narg);
	narg -=3;
	{ object keyvars[14];
	parse_key(narg,args,7,L20keys,keyvars,OBJNULL,FALSE);
	V4= keyvars[0];
	V5= keyvars[1];
	V6= keyvars[2];
	V7= keyvars[3];
	V8= keyvars[4];
	V9= keyvars[5];
	if(keyvars[13]==Cnil){
	V10= symbol_function(VV[65]);
	}else{
	V10= keyvars[6];}
	}
	{int V11;                                 /*  L               */
	V11= length((V3));
	{volatile int V12;                        /*  START           */
	volatile int V13;                         /*  END             */
	if(((V7))==Cnil){
	goto L482;}
	L6(1,(V7))                                /*  THE-START       */;
	V12= fix(VALUES(0));
	goto L480;
L482:
	V12= 0;
L480:
	L5(2,(V8),(V3))                           /*  THE-END         */;
	V13= fix(VALUES(0));
	if((V12)<=(V13)){
	goto L485;}
	L4(2,MAKE_FIXNUM(V12),MAKE_FIXNUM(V13))   /*  BAD-SEQ-LIMIT   */;
L485:
	{volatile int V14;                        /*  COUNT           */
	if(((V9))!=Cnil){
	goto L490;}
	V14= 536870911;
	goto L488;
L490:
	V14= fix((V9));
L488:
	if((V5)==Cnil){
	goto L493;}
	if((V6)==Cnil){
	goto L493;}
	LI3();
L493:
	if(((V4))!=Cnil){
	goto L495;}
	{volatile object V15;                     /*  NEWSEQ          */
	volatile int V16;                         /*  I               */
	volatile int V17;                         /*  K               */
	{object V18= LI1((V3));
	(*LK0)(2,(V18),MAKE_FIXNUM(V11))          /*  MAKE-SEQUENCE   */;
	V15= VALUES(0);}
	V16= 0;
	V17= 0;
L501:
	if(!((V16)>=(V11))){
	goto L502;}
	VALUES(0) = (V15);
	RETURN(1);
L502:
	if(!((V12)<=(V16))){
	goto L507;}
	if(!((V16)<(V13))){
	goto L507;}
	if(!((V17)<(V14))){
	goto L507;}
	funcall(2,(V10),elt((V3),V16));
	if((LI2((V5),(V6),(V2),VALUES(0)))==Cnil){
	goto L507;}
	elt_set((V15),V16,(V1));
	V17= (V17)+1;
	goto L505;
L507:
	elt_set((V15),V16,elt((V3),V16));
L505:
	V16= (V16)+1;
	goto L501;
	}
L495:
	{volatile object V19;                     /*  NEWSEQ          */
	volatile int V20;                         /*  I               */
	volatile int V21;                         /*  K               */
	{object V22= LI1((V3));
	(*LK0)(2,(V22),MAKE_FIXNUM(V11))          /*  MAKE-SEQUENCE   */;
	V19= VALUES(0);}
	V20= (V11)-1;
	V21= 0;
L525:
	if(!((V20)<(0))){
	goto L526;}
	VALUES(0) = (V19);
	RETURN(1);
L526:
	if(!((V12)<=(V20))){
	goto L531;}
	if(!((V20)<(V13))){
	goto L531;}
	if(!((V21)<(V14))){
	goto L531;}
	funcall(2,(V10),elt((V3),V20));
	if((LI2((V5),(V6),(V2),VALUES(0)))==Cnil){
	goto L531;}
	elt_set((V19),V20,(V1));
	V21= (V21)+1;
	goto L529;
L531:
	elt_set((V19),V20,elt((V3),V20));
L529:
	V20= (V20)-1;
	goto L525;
	}
	}
	}
	}
	}
}
/*	function definition for SUBSTITUTE-IF                         */
static L21(int narg, object V1, object V2, object V3, ...)
{ VT23 VLEX23 CLSR23
	cs_check;
	{object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	va_list args; va_start(args, V3);
	if(narg<3) FEtoo_few_arguments(&narg);
	narg -=3;
	{ object keyvars[10];
	parse_key(narg,args,5,L21keys,keyvars,OBJNULL,FALSE);
	V4= keyvars[0];
	V5= keyvars[1];
	V6= keyvars[2];
	V7= keyvars[3];
	if(keyvars[9]==Cnil){
	V8= symbol_function(VV[65]);
	}else{
	V8= keyvars[4];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L20(15,(V1),(V2),(V3),VV[11],(V4),VV[12],VALUES(0),VV[14],(V5),VV[15],(V6),VV[16],(V7),VV[17],(V8))/*  SUBSTITUTE*/);
	}
}
/*	function definition for SUBSTITUTE-IF-NOT                     */
static L22(int narg, object V1, object V2, object V3, ...)
{ VT24 VLEX24 CLSR24
	cs_check;
	{object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	va_list args; va_start(args, V3);
	if(narg<3) FEtoo_few_arguments(&narg);
	narg -=3;
	{ object keyvars[10];
	parse_key(narg,args,5,L22keys,keyvars,OBJNULL,FALSE);
	V4= keyvars[0];
	V5= keyvars[1];
	V6= keyvars[2];
	V7= keyvars[3];
	if(keyvars[9]==Cnil){
	V8= symbol_function(VV[65]);
	}else{
	V8= keyvars[4];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L20(15,(V1),(V2),(V3),VV[11],(V4),VV[13],VALUES(0),VV[14],(V5),VV[15],(V6),VV[16],(V7),VV[17],(V8))/*  SUBSTITUTE*/);
	}
}
/*	function definition for NSUBSTITUTE                           */
static L23(int narg, object V1, object V2, object V3, ...)
{ VT25 VLEX25 CLSR25
	cs_check;
	{volatile object V4;
	volatile object V5;
	volatile object V6;
	volatile object V7;
	volatile object V8;
	volatile object V9;
	volatile object V10;
	va_list args; va_start(args, V3);
	if(narg<3) FEtoo_few_arguments(&narg);
	narg -=3;
	{ object keyvars[14];
	parse_key(narg,args,7,L23keys,keyvars,OBJNULL,FALSE);
	V4= keyvars[0];
	V5= keyvars[1];
	V6= keyvars[2];
	V7= keyvars[3];
	V8= keyvars[4];
	V9= keyvars[5];
	if(keyvars[13]==Cnil){
	V10= symbol_function(VV[65]);
	}else{
	V10= keyvars[6];}
	}
	{volatile int V11;                        /*  START           */
	volatile int V12;                         /*  END             */
	if(((V7))==Cnil){
	goto L552;}
	L6(1,(V7))                                /*  THE-START       */;
	V11= fix(VALUES(0));
	goto L550;
L552:
	V11= 0;
L550:
	L5(2,(V8),(V3))                           /*  THE-END         */;
	V12= fix(VALUES(0));
	if((V11)<=(V12)){
	goto L555;}
	L4(2,MAKE_FIXNUM(V11),MAKE_FIXNUM(V12))   /*  BAD-SEQ-LIMIT   */;
L555:
	{volatile int V13;                        /*  COUNT           */
	if(((V9))!=Cnil){
	goto L560;}
	V13= 536870911;
	goto L558;
L560:
	V13= fix((V9));
L558:
	if((V5)==Cnil){
	goto L563;}
	if((V6)==Cnil){
	goto L563;}
	LI3();
L563:
	if(((V4))!=Cnil){
	goto L565;}
	{volatile int V14;                        /*  I               */
	volatile int V15;                         /*  K               */
	V14= V11;
	V15= 0;
L570:
	if(!((V14)>=(V12))){
	goto L571;}
	VALUES(0) = (V3);
	RETURN(1);
L571:
	if(!((V15)<(V13))){
	goto L574;}
	funcall(2,(V10),elt((V3),V14));
	if((LI2((V5),(V6),(V2),VALUES(0)))==Cnil){
	goto L574;}
	elt_set((V3),V14,(V1));
	V15= (V15)+1;
L574:
	V14= (V14)+1;
	goto L570;
	}
L565:
	{volatile int V17;                        /*  I               */
	volatile int V18;                         /*  K               */
	V17= (V12)-1;
	V18= 0;
L588:
	if(!((V17)<(V11))){
	goto L589;}
	VALUES(0) = (V3);
	RETURN(1);
L589:
	if(!((V18)<(V13))){
	goto L592;}
	funcall(2,(V10),elt((V3),V17));
	if((LI2((V5),(V6),(V2),VALUES(0)))==Cnil){
	goto L592;}
	elt_set((V3),V17,(V1));
	V18= (V18)+1;
L592:
	V17= (V17)-1;
	goto L588;
	}
	}
	}
	}
}
/*	function definition for NSUBSTITUTE-IF                        */
static L24(int narg, object V1, object V2, object V3, ...)
{ VT26 VLEX26 CLSR26
	cs_check;
	{object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	va_list args; va_start(args, V3);
	if(narg<3) FEtoo_few_arguments(&narg);
	narg -=3;
	{ object keyvars[10];
	parse_key(narg,args,5,L24keys,keyvars,OBJNULL,FALSE);
	V4= keyvars[0];
	V5= keyvars[1];
	V6= keyvars[2];
	V7= keyvars[3];
	if(keyvars[9]==Cnil){
	V8= symbol_function(VV[65]);
	}else{
	V8= keyvars[4];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L23(15,(V1),(V2),(V3),VV[11],(V4),VV[12],VALUES(0),VV[14],(V5),VV[15],(V6),VV[16],(V7),VV[17],(V8))/*  NSUBSTITUTE*/);
	}
}
/*	function definition for NSUBSTITUTE-IF-NOT                    */
static L25(int narg, object V1, object V2, object V3, ...)
{ VT27 VLEX27 CLSR27
	cs_check;
	{object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	va_list args; va_start(args, V3);
	if(narg<3) FEtoo_few_arguments(&narg);
	narg -=3;
	{ object keyvars[10];
	parse_key(narg,args,5,L25keys,keyvars,OBJNULL,FALSE);
	V4= keyvars[0];
	V5= keyvars[1];
	V6= keyvars[2];
	V7= keyvars[3];
	if(keyvars[9]==Cnil){
	V8= symbol_function(VV[65]);
	}else{
	V8= keyvars[4];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L23(15,(V1),(V2),(V3),VV[11],(V4),VV[13],VALUES(0),VV[14],(V5),VV[15],(V6),VV[16],(V7),VV[17],(V8))/*  NSUBSTITUTE*/);
	}
}
/*	function definition for FIND                                  */
static L26(int narg, object V1, object V2, ...)
{ VT28 VLEX28 CLSR28
	cs_check;
	{volatile object V3;
	volatile object V4;
	volatile object V5;
	volatile object V6;
	volatile object V7;
	volatile object V8;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -=2;
	{ object keyvars[12];
	parse_key(narg,args,6,L26keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	V7= keyvars[4];
	if(keyvars[11]==Cnil){
	V8= symbol_function(VV[65]);
	}else{
	V8= keyvars[5];}
	}
	{volatile int V9;                         /*  START           */
	volatile int V10;                         /*  END             */
	if(((V6))==Cnil){
	goto L610;}
	L6(1,(V6))                                /*  THE-START       */;
	V9= fix(VALUES(0));
	goto L608;
L610:
	V9= 0;
L608:
	L5(2,(V7),(V2))                           /*  THE-END         */;
	V10= fix(VALUES(0));
	if((V9)<=(V10)){
	goto L613;}
	L4(2,MAKE_FIXNUM(V9),MAKE_FIXNUM(V10))    /*  BAD-SEQ-LIMIT   */;
L613:
	if((V4)==Cnil){
	goto L616;}
	if((V5)==Cnil){
	goto L616;}
	LI3();
L616:
	if(((V3))!=Cnil){
	goto L618;}
	{volatile int V11;                        /*  I               */
	V11= V9;
L622:
	if(!((V11)>=(V10))){
	goto L623;}
	VALUES(0) = Cnil;
	RETURN(1);
L623:
	funcall(2,(V8),elt((V2),V11));
	if((LI2((V4),(V5),(V1),VALUES(0)))==Cnil){
	goto L626;}
	VALUES(0) = elt((V2),V11);
	RETURN(1);
L626:
	V11= (V11)+1;
	goto L622;
	}
L618:
	{volatile int V14;                        /*  I               */
	V14= (V10)-1;
L635:
	if(!((V14)<(V9))){
	goto L636;}
	VALUES(0) = Cnil;
	RETURN(1);
L636:
	funcall(2,(V8),elt((V2),V14));
	if((LI2((V4),(V5),(V1),VALUES(0)))==Cnil){
	goto L639;}
	VALUES(0) = elt((V2),V14);
	RETURN(1);
L639:
	V14= (V14)-1;
	goto L635;
	}
	}
	}
}
/*	function definition for FIND-IF                               */
static L27(int narg, object V1, object V2, ...)
{ VT29 VLEX29 CLSR29
	cs_check;
	{object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -=2;
	{ object keyvars[8];
	parse_key(narg,args,4,L27keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	if(keyvars[7]==Cnil){
	V6= symbol_function(VV[65]);
	}else{
	V6= keyvars[3];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L26(12,(V1),(V2),VV[11],(V3),VV[12],VALUES(0),VV[14],(V4),VV[15],(V5),VV[17],(V6))/*  FIND*/);
	}
}
/*	function definition for FIND-IF-NOT                           */
static L28(int narg, object V1, object V2, ...)
{ VT30 VLEX30 CLSR30
	cs_check;
	{object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -=2;
	{ object keyvars[8];
	parse_key(narg,args,4,L28keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	if(keyvars[7]==Cnil){
	V6= symbol_function(VV[65]);
	}else{
	V6= keyvars[3];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L26(12,(V1),(V2),VV[11],(V3),VV[13],VALUES(0),VV[14],(V4),VV[15],(V5),VV[17],(V6))/*  FIND*/);
	}
}
/*	function definition for POSITION                              */
static L29(int narg, object V1, object V2, ...)
{ VT31 VLEX31 CLSR31
	cs_check;
	{volatile object V3;
	volatile object V4;
	volatile object V5;
	volatile object V6;
	volatile object V7;
	volatile object V8;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -=2;
	{ object keyvars[12];
	parse_key(narg,args,6,L29keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	V7= keyvars[4];
	if(keyvars[11]==Cnil){
	V8= symbol_function(VV[65]);
	}else{
	V8= keyvars[5];}
	}
	{volatile int V9;                         /*  START           */
	volatile int V10;                         /*  END             */
	if(((V6))==Cnil){
	goto L653;}
	L6(1,(V6))                                /*  THE-START       */;
	V9= fix(VALUES(0));
	goto L651;
L653:
	V9= 0;
L651:
	L5(2,(V7),(V2))                           /*  THE-END         */;
	V10= fix(VALUES(0));
	if((V9)<=(V10)){
	goto L656;}
	L4(2,MAKE_FIXNUM(V9),MAKE_FIXNUM(V10))    /*  BAD-SEQ-LIMIT   */;
L656:
	if((V4)==Cnil){
	goto L659;}
	if((V5)==Cnil){
	goto L659;}
	LI3();
L659:
	if(((V3))!=Cnil){
	goto L661;}
	{volatile int V11;                        /*  I               */
	V11= V9;
L665:
	if(!((V11)>=(V10))){
	goto L666;}
	VALUES(0) = Cnil;
	RETURN(1);
L666:
	funcall(2,(V8),elt((V2),V11));
	if((LI2((V4),(V5),(V1),VALUES(0)))==Cnil){
	goto L669;}
	VALUES(0) = MAKE_FIXNUM(V11);
	RETURN(1);
L669:
	V11= (V11)+1;
	goto L665;
	}
L661:
	{volatile int V14;                        /*  I               */
	V14= (V10)-1;
L678:
	if(!((V14)<(V9))){
	goto L679;}
	VALUES(0) = Cnil;
	RETURN(1);
L679:
	funcall(2,(V8),elt((V2),V14));
	if((LI2((V4),(V5),(V1),VALUES(0)))==Cnil){
	goto L682;}
	VALUES(0) = MAKE_FIXNUM(V14);
	RETURN(1);
L682:
	V14= (V14)-1;
	goto L678;
	}
	}
	}
}
/*	function definition for POSITION-IF                           */
static L30(int narg, object V1, object V2, ...)
{ VT32 VLEX32 CLSR32
	cs_check;
	{object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -=2;
	{ object keyvars[8];
	parse_key(narg,args,4,L30keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	if(keyvars[7]==Cnil){
	V6= symbol_function(VV[65]);
	}else{
	V6= keyvars[3];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L29(12,(V1),(V2),VV[11],(V3),VV[12],VALUES(0),VV[14],(V4),VV[15],(V5),VV[17],(V6))/*  POSITION*/);
	}
}
/*	function definition for POSITION-IF-NOT                       */
static L31(int narg, object V1, object V2, ...)
{ VT33 VLEX33 CLSR33
	cs_check;
	{object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -=2;
	{ object keyvars[8];
	parse_key(narg,args,4,L31keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	if(keyvars[7]==Cnil){
	V6= symbol_function(VV[65]);
	}else{
	V6= keyvars[3];}
	}
	VALUES(0) = symbol_function(VV[66]);
	RETURN(L29(12,(V1),(V2),VV[11],(V3),VV[13],VALUES(0),VV[14],(V4),VV[15],(V5),VV[17],(V6))/*  POSITION*/);
	}
}
/*	function definition for REMOVE-DUPLICATES                     */
static L32(int narg, object V1, ...)
{ VT34 VLEX34 CLSR34
	cs_check;
	{volatile object V2;
	volatile object V3;
	volatile object V4;
	volatile object V5;
	volatile object V6;
	volatile object V7;
	va_list args; va_start(args, V1);
	if(narg<1) FEtoo_few_arguments(&narg);
	narg -=1;
	{ object keyvars[12];
	parse_key(narg,args,6,L32keys,keyvars,OBJNULL,FALSE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	if(keyvars[11]==Cnil){
	V7= symbol_function(VV[65]);
	}else{
	V7= keyvars[5];}
	}
	if((V3)==Cnil){
	goto L694;}
	if((V4)==Cnil){
	goto L694;}
	LI3();
L694:
	if(!(type_of((V1))==t_cons||(V1)==Cnil)){
	goto L695;}
	if(((V2))!=Cnil){
	goto L695;}
	if(((V5))!=Cnil){
	goto L695;}
	if(((V6))!=Cnil){
	goto L695;}
	if(!(endp((V1)))){
	goto L704;}
	VALUES(0) = Cnil;
	RETURN(1);
L704:
	{volatile object V8;                      /*  L               */
	volatile object V9;                       /*  L1              */
	V8= (V1);
	V9= Cnil;
L708:
	if(!(endp(cdr((V8))))){
	goto L709;}
	RETURN(Lreconc(2,(V9),(V8))               /*  NRECONC         */);
L709:
	(*LK1)(8,car((V8)),cdr((V8)),VV[12],(V3),VV[13],(V4),VV[17],(V7))/*  MEMBER1*/;
	if(VALUES(0)!=Cnil){
	goto L712;}
	V9= CONS(car((V8)),(V9));
L712:
	V8= cdr((V8));
	goto L708;
	}
L695:
	RETURN(L33(13,(V1),VV[11],(V2),VV[12],(V3),VV[13],(V4),VV[14],(V5),VV[15],(V6),VV[17],(V7))/*  DELETE-DUPLICATES*/);
	}
}
/*	function definition for DELETE-DUPLICATES                     */
static L33(int narg, object V1, ...)
{ VT35 VLEX35 CLSR35
	cs_check;
	{volatile object V2;
	volatile object V3;
	volatile object V4;
	volatile object V5;
	volatile object V6;
	volatile object V7;
	va_list args; va_start(args, V1);
	if(narg<1) FEtoo_few_arguments(&narg);
	narg -=1;
	{ object keyvars[12];
	parse_key(narg,args,6,L33keys,keyvars,OBJNULL,FALSE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	if(keyvars[11]==Cnil){
	V7= symbol_function(VV[65]);
	}else{
	V7= keyvars[5];}
	}
	{int V8;                                  /*  L               */
	V8= length((V1));
	if((V3)==Cnil){
	goto L721;}
	if((V4)==Cnil){
	goto L721;}
	LI3();
L721:
	if(!(type_of((V1))==t_cons||(V1)==Cnil)){
	goto L722;}
	if(((V2))!=Cnil){
	goto L722;}
	if(((V5))!=Cnil){
	goto L722;}
	if(((V6))!=Cnil){
	goto L722;}
	if(!(endp((V1)))){
	goto L731;}
	VALUES(0) = Cnil;
	RETURN(1);
L731:
	{volatile object V9;                      /*  L               */
	V9= (V1);
L735:
	if(!(endp(cdr((V9))))){
	goto L736;}
	VALUES(0) = (V1);
	RETURN(1);
L736:
	(*LK1)(8,car((V9)),cdr((V9)),VV[12],(V3),VV[13],(V4),VV[17],(V7))/*  MEMBER1*/;
	if(VALUES(0)==Cnil){
	goto L741;}
	if(type_of((V9))!=t_cons)FEwrong_type_argument(Scons,(V9));
	CAR((V9)) = cadr((V9));
	if(type_of((V9))!=t_cons)FEwrong_type_argument(Scons,(V9));
	CDR((V9)) = cddr((V9));
	goto L739;
L741:
	V9= cdr((V9));
L739:
	goto L735;
	}
L722:
	{volatile int V9;                         /*  START           */
	volatile int V10;                         /*  END             */
	if(((V5))==Cnil){
	goto L749;}
	L6(1,(V5))                                /*  THE-START       */;
	V9= fix(VALUES(0));
	goto L747;
L749:
	V9= 0;
L747:
	L5(2,(V6),(V1))                           /*  THE-END         */;
	V10= fix(VALUES(0));
	if((V9)<=(V10)){
	goto L752;}
	L4(2,MAKE_FIXNUM(V9),MAKE_FIXNUM(V10))    /*  BAD-SEQ-LIMIT   */;
L752:
	if(((V2))!=Cnil){
	goto L756;}
	{volatile int V11;                        /*  N               */
	volatile int V12;                         /*  I               */
	V11= 0;
	V12= V9;
L761:
	if(!((V12)>=(V10))){
	goto L762;}
	{volatile object V14;                     /*  NEWSEQ          */
	volatile int V15;                         /*  I               */
	volatile int V16;                         /*  J               */
	{object V17= LI1((V1));
	(*LK0)(2,(V17),MAKE_FIXNUM((V8)-(V11)))   /*  MAKE-SEQUENCE   */;
	V14= VALUES(0);}
	V15= 0;
	V16= 0;
L769:
	if(!((V15)>=(V8))){
	goto L770;}
	VALUES(0) = (V14);
	RETURN(1);
L770:
	{object V18;
	if((V9)<=(V15)){
	goto L775;}
	V18= Cnil;
	goto L774;
L775:
	if((V15)<(V10)){
	goto L777;}
	V18= Cnil;
	goto L774;
L777:
	funcall(2,(V7),elt((V1),V15));
	T0= VALUES(0);
	L29(12,T0,(V1),VV[12],(V3),VV[13],(V4),VV[14],MAKE_FIXNUM((V15)+1),VV[15],MAKE_FIXNUM(V10),VV[17],(V7))/*  POSITION*/;
	V18= VALUES(0);
L774:
	if(((V18))==Cnil){
	goto L781;}
	goto L773;
L781:
	elt_set((V14),V16,elt((V1),V15));
	V16= (V16)+(1);
	}
L773:
	V15= (V15)+1;
	goto L769;
	}
L762:
	funcall(2,(V7),elt((V1),V12));
	T0= VALUES(0);
	L29(12,T0,(V1),VV[12],(V3),VV[13],(V4),VV[14],MAKE_FIXNUM((V12)+1),VV[15],MAKE_FIXNUM(V10),VV[17],(V7))/*  POSITION*/;
	if(VALUES(0)==Cnil){
	goto L788;}
	V11= (V11)+(1);
L788:
	V12= (V12)+1;
	goto L761;
	}
L756:
	{volatile int V19;                        /*  N               */
	volatile int V20;                         /*  I               */
	V19= 0;
	V20= (V10)-1;
L799:
	if(!((V20)<(V9))){
	goto L800;}
	{volatile object V22;                     /*  NEWSEQ          */
	volatile int V23;                         /*  I               */
	volatile int V24;                         /*  J               */
	{object V25= LI1((V1));
	(*LK0)(2,(V25),MAKE_FIXNUM((V8)-(V19)))   /*  MAKE-SEQUENCE   */;
	V22= VALUES(0);}
	V23= (V8)-1;
	V24= ((V8)-1)-(V19);
L807:
	if(!((V23)<(0))){
	goto L808;}
	VALUES(0) = (V22);
	RETURN(1);
L808:
	{object V26;
	if((V9)<=(V23)){
	goto L813;}
	V26= Cnil;
	goto L812;
L813:
	if((V23)<(V10)){
	goto L815;}
	V26= Cnil;
	goto L812;
L815:
	funcall(2,(V7),elt((V1),V23));
	L29(14,VALUES(0),(V1),VV[11],Ct,VV[12],(V3),VV[13],(V4),VV[14],MAKE_FIXNUM(V9),VV[15],MAKE_FIXNUM(V23),VV[17],(V7))/*  POSITION*/;
	V26= VALUES(0);
L812:
	if(((V26))==Cnil){
	goto L819;}
	goto L811;
L819:
	elt_set((V22),V24,elt((V1),V23));
	V24= (V24)-(1);
	}
L811:
	V23= (V23)-1;
	goto L807;
	}
L800:
	funcall(2,(V7),elt((V1),V20));
	L29(14,VALUES(0),(V1),VV[11],Ct,VV[12],(V3),VV[13],(V4),VV[14],MAKE_FIXNUM(V9),VV[15],MAKE_FIXNUM(V20),VV[17],(V7))/*  POSITION*/;
	if(VALUES(0)==Cnil){
	goto L826;}
	V19= (V19)+(1);
L826:
	V20= (V20)-1;
	goto L799;
	}
	}
	}
	}
}
/*	function definition for MISMATCH                              */
static L34(int narg, object V1, object V2, ...)
{ VT36 VLEX36 CLSR36
	cs_check;
	{volatile object V3;
	volatile object V4;
	volatile object V5;
	volatile object V6;
	volatile object V7;
	volatile object V8;
	volatile object V9;
	volatile object V10;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -=2;
	{ object keyvars[16];
	parse_key(narg,args,8,L34keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	if(keyvars[11]==Cnil){
	V6= symbol_function(VV[65]);
	}else{
	V6= keyvars[3];}
	V7= keyvars[4];
	V8= keyvars[5];
	V9= keyvars[6];
	V10= keyvars[7];
	}
	if((V4)==Cnil){
	goto L835;}
	if((V5)==Cnil){
	goto L835;}
	LI3();
L835:
	{volatile int V11;                        /*  START1          */
	volatile int V12;                         /*  END1            */
	if(((V7))==Cnil){
	goto L838;}
	L6(1,(V7))                                /*  THE-START       */;
	V11= fix(VALUES(0));
	goto L836;
L838:
	V11= 0;
L836:
	L5(2,(V9),(V1))                           /*  THE-END         */;
	V12= fix(VALUES(0));
	if((V11)<=(V12)){
	goto L841;}
	L4(2,MAKE_FIXNUM(V11),MAKE_FIXNUM(V12))   /*  BAD-SEQ-LIMIT   */;
L841:
	{volatile int V13;                        /*  START2          */
	volatile int V14;                         /*  END2            */
	if(((V8))==Cnil){
	goto L846;}
	L6(1,(V8))                                /*  THE-START       */;
	V13= fix(VALUES(0));
	goto L844;
L846:
	V13= 0;
L844:
	L5(2,(V10),(V2))                          /*  THE-END         */;
	V14= fix(VALUES(0));
	if((V13)<=(V14)){
	goto L849;}
	L4(2,MAKE_FIXNUM(V13),MAKE_FIXNUM(V14))   /*  BAD-SEQ-LIMIT   */;
L849:
	if(((V3))!=Cnil){
	goto L853;}
	{volatile int V15;                        /*  I1              */
	volatile int V16;                         /*  I2              */
	V15= V11;
	V16= V13;
L858:
	if((V15)>=(V12)){
	goto L860;}
	if(!((V16)>=(V14))){
	goto L859;}
L860:
	if(!((V15)>=(V12))){
	goto L865;}
	if(!((V16)>=(V14))){
	goto L865;}
	VALUES(0) = Cnil;
	RETURN(1);
L865:
	VALUES(0) = MAKE_FIXNUM(V15);
	RETURN(1);
L859:
	funcall(2,(V6),elt((V1),V15));
	T0= VALUES(0);
	funcall(2,(V6),elt((V2),V16));
	if((LI2((V4),(V5),T0,VALUES(0)))!=Cnil){
	goto L869;}
	VALUES(0) = MAKE_FIXNUM(V15);
	RETURN(1);
L869:
	V15= (V15)+1;
	V16= (V16)+1;
	goto L858;
	}
L853:
	{volatile int V19;                        /*  I1              */
	volatile int V20;                         /*  I2              */
	V19= (V12)-1;
	V20= (V14)-1;
L881:
	if((V19)<(V11)){
	goto L883;}
	if(!((V20)<(V13))){
	goto L882;}
L883:
	if(!((V19)<(V11))){
	goto L888;}
	if(!((V20)<(V13))){
	goto L888;}
	VALUES(0) = Cnil;
	RETURN(1);
L888:
	VALUES(0) = one_plus(MAKE_FIXNUM(V19));
	RETURN(1);
L882:
	funcall(2,(V6),elt((V1),V19));
	T0= VALUES(0);
	funcall(2,(V6),elt((V2),V20));
	if((LI2((V4),(V5),T0,VALUES(0)))!=Cnil){
	goto L892;}
	VALUES(0) = one_plus(MAKE_FIXNUM(V19));
	RETURN(1);
L892:
	V19= (V19)-1;
	V20= (V20)-1;
	goto L881;
	}
	}
	}
	}
}
/*	function definition for SEARCH                                */
static L35(int narg, object V1, object V2, ...)
{ VT37 VLEX37 CLSR37
	cs_check;
	{volatile object V3;
	volatile object V4;
	volatile object V5;
	volatile object V6;
	volatile object V7;
	volatile object V8;
	volatile object V9;
	volatile object V10;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -=2;
	{ object keyvars[16];
	parse_key(narg,args,8,L35keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	if(keyvars[11]==Cnil){
	V6= symbol_function(VV[65]);
	}else{
	V6= keyvars[3];}
	V7= keyvars[4];
	V8= keyvars[5];
	V9= keyvars[6];
	V10= keyvars[7];
	}
	if((V4)==Cnil){
	goto L902;}
	if((V5)==Cnil){
	goto L902;}
	LI3();
L902:
	{volatile int V11;                        /*  START1          */
	volatile int V12;                         /*  END1            */
	if(((V7))==Cnil){
	goto L905;}
	L6(1,(V7))                                /*  THE-START       */;
	V11= fix(VALUES(0));
	goto L903;
L905:
	V11= 0;
L903:
	L5(2,(V9),(V1))                           /*  THE-END         */;
	V12= fix(VALUES(0));
	if((V11)<=(V12)){
	goto L908;}
	L4(2,MAKE_FIXNUM(V11),MAKE_FIXNUM(V12))   /*  BAD-SEQ-LIMIT   */;
L908:
	{volatile int V13;                        /*  START2          */
	volatile int V14;                         /*  END2            */
	if(((V8))==Cnil){
	goto L913;}
	L6(1,(V8))                                /*  THE-START       */;
	V13= fix(VALUES(0));
	goto L911;
L913:
	V13= 0;
L911:
	L5(2,(V10),(V2))                          /*  THE-END         */;
	V14= fix(VALUES(0));
	if((V13)<=(V14)){
	goto L916;}
	L4(2,MAKE_FIXNUM(V13),MAKE_FIXNUM(V14))   /*  BAD-SEQ-LIMIT   */;
L916:
	if(((V3))!=Cnil){
	goto L920;}
L923:
	{volatile int V15;                        /*  I1              */
	volatile int V16;                         /*  I2              */
	V15= V11;
	V16= V13;
L929:
	if(!((V15)>=(V12))){
	goto L930;}
	VALUES(0) = MAKE_FIXNUM(V13);
	RETURN(1);
L930:
	if(!((V16)>=(V14))){
	goto L933;}
	VALUES(0) = Cnil;
	RETURN(1);
L933:
	funcall(2,(V6),elt((V1),V15));
	T0= VALUES(0);
	funcall(2,(V6),elt((V2),V16));
	if((LI2((V4),(V5),T0,VALUES(0)))!=Cnil){
	goto L936;}
	goto L925;
L936:
	V15= (V15)+1;
	V16= (V16)+1;
	goto L929;
	}
L925:
	V13= (V13)+(1);
	goto L923;
L920:
L948:
	{volatile int V15;                        /*  I1              */
	volatile int V16;                         /*  I2              */
	V15= (V12)-1;
	V16= (V14)-1;
L954:
	if(!((V15)<(V11))){
	goto L955;}
	VALUES(0) = MAKE_FIXNUM((V16)+1);
	RETURN(1);
L955:
	if(!((V16)<(V13))){
	goto L958;}
	VALUES(0) = Cnil;
	RETURN(1);
L958:
	funcall(2,(V6),elt((V1),V15));
	T0= VALUES(0);
	funcall(2,(V6),elt((V2),V16));
	if((LI2((V4),(V5),T0,VALUES(0)))!=Cnil){
	goto L961;}
	goto L950;
L961:
	V15= (V15)-1;
	V16= (V16)-1;
	goto L954;
	}
L950:
	V14= (V14)-(1);
	goto L948;
	}
	}
	}
}
/*	function definition for SORT                                  */
static L36(int narg, object V1, object V2, ...)
{ VT38 VLEX38 CLSR38
	cs_check;
	{object V3;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -=2;
	{ object keyvars[2];
	parse_key(narg,args,1,L36keys,keyvars,OBJNULL,FALSE);
	if(keyvars[1]==Cnil){
	V3= symbol_function(VV[65]);
	}else{
	V3= keyvars[0];}
	}
	if(!(type_of((V1))==t_cons||(V1)==Cnil)){
	goto L974;}
	RETURN(L37(3,(V1),(V2),(V3))              /*  LIST-MERGE-SORT */);
L974:
	VALUES(0) = LI39((V1),0,length((V1)),(V2),(V3));
	RETURN(1);
	}
}
/*	function definition for LIST-MERGE-SORT                       */
static L37(int narg, object V1, object V2, object V3)
{ VT39 VLEX39 CLSR39
	cs_check;
	check_arg(3);
	lex0[0]=V2;                               /*  PREDICATE       */
	lex0[1]=V3;                               /*  KEY             */
TTL:
	RETURN(LC38(lex0,1,(V1))                  /*  SORT            */);
}
/*	local function SORT                                           */
static LC38(object *lex0,int narg, object V1)
{ VT40 VLEX40 CLSR40
	check_arg(1);
TTL:
	{volatile int V2;                         /*  I               */
	volatile object V3;                       /*  LEFT            */
	volatile object V4;                       /*  RIGHT           */
	volatile object V5;                       /*  L0              */
	volatile object V6;                       /*  L1              */
	volatile object V7;                       /*  KEY-LEFT        */
	volatile object V8;                       /*  KEY-RIGHT       */
	V2= 0;
	V3= Cnil;
	V4= Cnil;
	V5= Cnil;
	V6= Cnil;
	V7= Cnil;
	V8= Cnil;
	V2= length((V1));
	if(!((V2)<(2))){
	goto L985;}
	VALUES(0) = (V1);
	RETURN(1);
L985:
	if(!((V2)==(2))){
	goto L983;}
	funcall(2,lex0[1],car((V1)));
	V7= VALUES(0);
	funcall(2,lex0[1],cadr((V1)));
	V8= VALUES(0);
	funcall(3,lex0[0],(V7),(V8));
	if(VALUES(0)==Cnil){
	goto L994;}
	VALUES(0) = (V1);
	RETURN(1);
L994:
	funcall(3,lex0[0],(V8),(V7));
	if(VALUES(0)==Cnil){
	goto L997;}
	VALUES(0) = nreverse((V1));
	RETURN(1);
L997:
	VALUES(0) = (V1);
	RETURN(1);
L983:
	V2= (V2>=0&&2>0?(V2)/(2):ifloor(V2,2));
	{volatile int V13;                        /*  J               */
	volatile object V14;                      /*  L1              */
	V13= 1;
	V14= (V1);
L1004:
	if(!((V13)>=(V2))){
	goto L1005;}
	V3= (V1);
	V4= cdr((V14));
	if(type_of((V14))!=t_cons)FEwrong_type_argument(Scons,(V14));
	CDR((V14)) = Cnil;
	goto L1001;
L1005:
	V13= (V13)+1;
	V14= cdr((V14));
	goto L1004;
	}
L1001:
	LC38(lex0,1,(V3))                         /*  SORT            */;
	V3= VALUES(0);
	LC38(lex0,1,(V4))                         /*  SORT            */;
	V4= VALUES(0);
	if(!(endp((V3)))){
	goto L1022;}
	VALUES(0) = (V4);
	RETURN(1);
L1022:
	if(!(endp((V4)))){
	goto L1020;}
	VALUES(0) = (V3);
	RETURN(1);
L1020:
	V5= CONS(Cnil,Cnil);
	V6= (V5);
	funcall(2,lex0[1],car((V3)));
	V7= VALUES(0);
	funcall(2,lex0[1],car((V4)));
	V8= VALUES(0);
L978:
	funcall(3,lex0[0],(V7),(V8));
	if(VALUES(0)==Cnil){
	goto L1034;}
	goto L979;
L1034:
	funcall(3,lex0[0],(V8),(V7));
	if(VALUES(0)==Cnil){
	goto L1037;}
	goto L980;
L1037:
	goto L979;
L979:
	if(type_of((V6))!=t_cons)FEwrong_type_argument(Scons,(V6));
	CDR((V6)) = (V3);
	V6= cdr((V6));
	V3= cdr((V3));
	if(!(endp((V3)))){
	goto L1044;}
	if(type_of((V6))!=t_cons)FEwrong_type_argument(Scons,(V6));
	CDR((V6)) = (V4);
	VALUES(0) = cdr((V5));
	RETURN(1);
L1044:
	funcall(2,lex0[1],car((V3)));
	V7= VALUES(0);
	goto L978;
L980:
	if(type_of((V6))!=t_cons)FEwrong_type_argument(Scons,(V6));
	CDR((V6)) = (V4);
	V6= cdr((V6));
	V4= cdr((V4));
	if(!(endp((V4)))){
	goto L1055;}
	if(type_of((V6))!=t_cons)FEwrong_type_argument(Scons,(V6));
	CDR((V6)) = (V3);
	VALUES(0) = cdr((V5));
	RETURN(1);
L1055:
	funcall(2,lex0[1],car((V4)));
	V8= VALUES(0);
	goto L978;
	}
}
/*	local entry for function QUICK-SORT                           */
static object LI39(volatile object V1,volatile int V2,volatile int V3,volatile object V4,volatile object V5)
{ VT41 VLEX41 CLSR41
TTL:
	if(!((V3)<=((V2)+1))){
	goto L1063;}
	return((V1));
L1063:
	{volatile int V7;                         /*  J               */
	volatile int V8;                          /*  K               */
	volatile object V9;                       /*  D               */
	volatile object V10;                      /*  KD              */
	V7= V2;
	V8= V3;
	V9= elt((V1),V2);
	funcall(2,(V5),(V9));
	V10= VALUES(0);
L1071:
L1075:
	V8= (V8)-(1);
	if((V7)<(V8)){
	goto L1079;}
	goto L1069;
L1079:
	funcall(2,(V5),elt((V1),V8));
	funcall(3,(V4),VALUES(0),(V10));
	if(VALUES(0)==Cnil){
	goto L1076;}
	goto L1073;
L1076:
	goto L1075;
L1073:
L1088:
	V7= (V7)+(1);
	if((V7)<(V8)){
	goto L1092;}
	goto L1069;
L1092:
	funcall(2,(V5),elt((V1),V7));
	funcall(3,(V4),VALUES(0),(V10));
	if(VALUES(0)!=Cnil){
	goto L1089;}
	goto L1086;
L1089:
	goto L1088;
L1086:
	{register object V11;                     /*  TEMP            */
	V11= elt((V1),V7);
	elt_set((V1),V7,elt((V1),V8));
	elt_set((V1),V8,(V11));
	}
	goto L1071;
L1069:
	elt_set((V1),V2,elt((V1),V7));
	elt_set((V1),V7,(V9));
	LI39((V1),V2,V7,(V4),(V5));
	V2= (V7)+1;
	goto TTL;
	}
}
/*	function definition for STABLE-SORT                           */
static L40(int narg, object V1, object V2, ...)
{ VT42 VLEX42 CLSR42
	cs_check;
	{object V3;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -=2;
	{ object keyvars[2];
	parse_key(narg,args,1,L40keys,keyvars,OBJNULL,FALSE);
	if(keyvars[1]==Cnil){
	V3= symbol_function(VV[65]);
	}else{
	V3= keyvars[0];}
	}
	if(!(type_of((V1))==t_cons||(V1)==Cnil)){
	goto L1113;}
	RETURN(L37(3,(V1),(V2),(V3))              /*  LIST-MERGE-SORT */);
L1113:
	if(type_of((V1))==t_string){
	goto L1115;}
	if(!((type_of((V1))==t_bitvector))){
	goto L1116;}
L1115:
	RETURN(L36(4,(V1),(V2),VV[17],(V3))       /*  SORT            */);
L1116:
	(*LK2)(2,(V1),VV[2])                      /*  COERCE          */;
	L37(3,VALUES(0),(V2),(V3))                /*  LIST-MERGE-SORT */;
	T0= VALUES(0);
	RETURN((*LK2)(2,T0,LI1((V1)))             /*  COERCE          */);
	}
}
/*	function definition for MERGE                                 */
static L41(int narg, object V1, object V2, object V3, object V4, ...)
{ VT43 VLEX43 CLSR43
	cs_check;
	{volatile object V5;
	va_list args; va_start(args, V4);
	if(narg<4) FEtoo_few_arguments(&narg);
	narg -=4;
	{ object keyvars[2];
	parse_key(narg,args,1,L41keys,keyvars,OBJNULL,FALSE);
	if(keyvars[1]==Cnil){
	V5= symbol_function(VV[65]);
	}else{
	V5= keyvars[0];}
	}
	{register int V6;                         /*  L1              */
	register int V7;                          /*  L2              */
	V6= length((V2));
	V7= length((V3));
	{volatile object V8;                      /*  NEWSEQ          */
	volatile int V9;                          /*  J               */
	volatile int V10;                         /*  I1              */
	volatile int V11;                         /*  I2              */
	(*LK0)(2,(V1),MAKE_FIXNUM((V6)+(V7)))     /*  MAKE-SEQUENCE   */;
	V8= VALUES(0);
	V9= 0;
	V10= 0;
	V11= 0;
L1130:
	if(!((V10)==(V6))){
	goto L1131;}
	if(!((V11)==(V7))){
	goto L1131;}
	VALUES(0) = (V8);
	RETURN(1);
L1131:
	if(!((V10)<(V6))){
	goto L1138;}
	if(!((V11)<(V7))){
	goto L1138;}
	funcall(2,(V5),elt((V2),V10));
	T0= VALUES(0);
	funcall(2,(V5),elt((V3),V11));
	funcall(3,(V4),T0,VALUES(0));
	if(VALUES(0)==Cnil){
	goto L1143;}
	elt_set((V8),V9,elt((V2),V10));
	V10= (V10)+(1);
	goto L1136;
L1143:
	funcall(2,(V5),elt((V3),V11));
	T0= VALUES(0);
	funcall(2,(V5),elt((V2),V10));
	funcall(3,(V4),T0,VALUES(0));
	if(VALUES(0)==Cnil){
	goto L1150;}
	elt_set((V8),V9,elt((V3),V11));
	V11= (V11)+(1);
	goto L1136;
L1150:
	elt_set((V8),V9,elt((V2),V10));
	V10= (V10)+(1);
	goto L1136;
L1138:
	if(!((V10)<(V6))){
	goto L1159;}
	elt_set((V8),V9,elt((V2),V10));
	V10= (V10)+(1);
	goto L1136;
L1159:
	elt_set((V8),V9,elt((V3),V11));
	V11= (V11)+(1);
L1136:
	V9= (V9)+1;
	goto L1130;
	}
	}
	}
}
/*	global entry for the function QUICK-SORT                      */
static L39(int narg, object V1, object V2, object V3, object V4, object V5)
{
	check_arg(5);
	VALUES(0)=(LI39((V1),fix(V2),fix(V3),(V4),(V5)));
	RETURN(1);
}
/*	global entry for the function TEST-ERROR                      */
static L3(int narg)
{
	check_arg(0);
	VALUES(0)=(LI3());
	RETURN(1);
}
/*	global entry for the function CALL-TEST                       */
static L2(int narg, object V1, object V2, object V3, object V4)
{
	check_arg(4);
	VALUES(0)=(LI2((V1),(V2),(V3),(V4)));
	RETURN(1);
}
/*	global entry for the function SEQTYPE                         */
static L1(int narg, object V1)
{
	check_arg(1);
	VALUES(0)=(LI1((V1)));
	RETURN(1);
}
static LKF2(int narg, ...) {TRAMPOLINK(VV[69],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[68],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[67],&LK0);}
