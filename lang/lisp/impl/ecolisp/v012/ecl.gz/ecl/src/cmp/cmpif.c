
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "cmpif.h"
init_cmpif(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_cmpif; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	MF0(VV[39],L1);
	MF0(VV[40],L2);
	MF0(VV[41],L3);
	MF0(VV[42],L6);
	MF0(VV[43],L7);
	MF0(VV[44],L8);
	MF0(VV[45],L9);
	MF0(VV[46],L10);
	MF0(VV[47],L11);
	MF0(VV[48],L12);
	MF0(VV[49],L13);
	MF0(VV[50],L14);
	MF0(VV[51],L15);
	MF0(VV[52],L16);
	MF0(VV[53],L18);
	VALUES(0) = (VV[39]->s.s_gfdef);
	putprop(VV[0],VALUES(0),VV[34]);
	VALUES(0) = (VV[42]->s.s_gfdef);
	putprop(VV[0],VALUES(0),VV[35]);
	VALUES(0) = (VV[45]->s.s_gfdef);
	putprop(VV[1],VALUES(0),VV[36]);
	VALUES(0) = (VV[46]->s.s_gfdef);
	putprop(VV[1],VALUES(0),VV[35]);
	VALUES(0) = (VV[47]->s.s_gfdef);
	putprop(VV[2],VALUES(0),VV[36]);
	VALUES(0) = (VV[48]->s.s_gfdef);
	putprop(VV[2],VALUES(0),VV[35]);
	VALUES(0) = (VV[49]->s.s_gfdef);
	putprop(VV[19],VALUES(0),VV[37]);
	VALUES(0) = (VV[50]->s.s_gfdef);
	putprop(VV[20],VALUES(0),VV[37]);
	VALUES(0) = (VV[52]->s.s_gfdef);
	putprop(VV[28],VALUES(0),VV[36]);
	VALUES(0) = (VV[51]->s.s_gfdef);
	putprop(VV[38],VALUES(0),VV[36]);
	VALUES(0) = (VV[53]->s.s_gfdef);
	putprop(VV[28],VALUES(0),VV[35]);
}
/*	function definition for C1IF                                  */
static L1(int narg, object V1)
{ VT3 VLEX3 CLSR3
TTL:
	{register object V2;                      /*  INFO            */
	object V3;                                /*  F               */
	V2= Cnil;
	V3= Cnil;
	if((V1)==Cnil){
	goto L26;}
	if(!(CDR((V1))==Cnil)){
	goto L25;}
L26:
	(*LK0)(3,VV[0],MAKE_FIXNUM(2),MAKE_FIXNUM(length((V1))))/*  TOO-FEW-ARGS*/;
L25:
	if(CDDR((V1))==Cnil){
	goto L30;}
	if(CDDDR((V1))==Cnil){
	goto L30;}
	(*LK1)(3,VV[0],MAKE_FIXNUM(3),MAKE_FIXNUM(length((V1))))/*  TOO-MANY-ARGS*/;
L30:
	L2(1,CAR((V1)))                           /*  C1FMLA-CONSTANT */;
	V3= VALUES(0);
	if(((V3)!= Ct))goto L37;
	RETURN((*LK2)(1,CADR((V1)))               /*  C1EXPR          */);
L37:
	if(((V3)!= Cnil))goto L38;
	if(!(CDDR((V1))==Cnil)){
	goto L40;}
	RETURN((*LK3)(0)                          /*  C1NIL           */);
L40:
	RETURN((*LK2)(1,CADDR((V1)))              /*  C1EXPR          */);
L38:
	(*LK4)(0)                                 /*  MAKE-INFO       */;
	V2= VALUES(0);
	L3(2,(V3),(V2))                           /*  C1FMLA          */;
	T0= VALUES(0);
	(*LK5)(2,CADR((V1)),(V2))                 /*  C1EXPR*         */;
	T1= VALUES(0);
	if(!(CDDR((V1))==Cnil)){
	goto L48;}
	(*LK3)(0)                                 /*  C1NIL           */;
	goto L46;
L48:
	(*LK5)(2,CADDR((V1)),(V2))                /*  C1EXPR*         */;
L46:
	VALUES(0) = list(5,VV[0],(V2),T0,T1,VALUES(0));
	RETURN(1);
	}
}
/*	function definition for C1FMLA-CONSTANT                       */
static L2(int narg, object V1)
{ VT4 VLEX4 CLSR4
TTL:
	{register object V2;                      /*  F               */
	V2= Cnil;
	if(!(type_of((V1))==t_cons)){
	goto L52;}
	{object V3= CAR((V1));
	if((V3!= VV[1]))goto L54;
	{register object V4;                      /*  FL              */
	V4= CDR((V1));
L57:
	if(!((V4)==Cnil)){
	goto L58;}
	VALUES(0) = Ct;
	RETURN(1);
L58:
	L2(1,CAR((V4)))                           /*  C1FMLA-CONSTANT */;
	V2= VALUES(0);
	if(((V2)!= Ct))goto L64;
	goto L63;
L64:
	if(((V2)!= Cnil))goto L65;
	VALUES(0) = Cnil;
	RETURN(1);
L65:
	if(!(CDR((V4))==Cnil)){
	goto L67;}
	VALUES(0) = (V2);
	RETURN(1);
L67:
	VALUES(0) = listA(3,VV[1],(V2),CDR((V4)));
	RETURN(1);
L63:
	V4= CDR((V4));
	goto L57;
	}
L54:
	if((V3!= VV[2]))goto L72;
	{register object V9;                      /*  FL              */
	V9= CDR((V1));
L75:
	if(!((V9)==Cnil)){
	goto L76;}
	VALUES(0) = Cnil;
	RETURN(1);
L76:
	L2(1,CAR((V9)))                           /*  C1FMLA-CONSTANT */;
	V2= VALUES(0);
	if(((V2)!= Ct))goto L82;
	VALUES(0) = Ct;
	RETURN(1);
L82:
	if(((V2)!= Cnil))goto L83;
	goto L81;
L83:
	if(!(CDR((V9))==Cnil)){
	goto L85;}
	VALUES(0) = (V2);
	RETURN(1);
L85:
	VALUES(0) = listA(3,VV[2],(V2),CDR((V9)));
	RETURN(1);
L81:
	V9= CDR((V9));
	goto L75;
	}
L72:
	if((V3!= VV[3])
	&& (V3!= VV[60]))goto L90;
	if(!(CDR((V1))==Cnil)){
	goto L91;}
	(*LK0)(3,VV[3],MAKE_FIXNUM(1),MAKE_FIXNUM(0))/*  TOO-FEW-ARGS */;
L91:
	if(CDDR((V1))==Cnil){
	goto L94;}
	(*LK1)(3,VV[3],MAKE_FIXNUM(1),MAKE_FIXNUM(length(CDR((V1)))))/*  TOO-MANY-ARGS*/;
L94:
	L2(1,CADR((V1)))                          /*  C1FMLA-CONSTANT */;
	V2= VALUES(0);
	if(((V2)!= Ct))goto L99;
	VALUES(0) = Cnil;
	RETURN(1);
L99:
	if(((V2)!= Cnil))goto L100;
	VALUES(0) = Ct;
	RETURN(1);
L100:
	VALUES(0) = list(2,VV[3],(V2));
	RETURN(1);
L90:
	VALUES(0) = (V1);
	RETURN(1);}
L52:
	if(!(type_of((V1))==t_symbol)){
	goto L102;}
	Lconstantp(1,(V1))                        /*  CONSTANTP       */;
	if(VALUES(0)==Cnil){
	goto L105;}
	Lsymbol_value(1,(V1))                     /*  SYMBOL-VALUE    */;
	if(VALUES(0)==Cnil){
	goto L108;}
	VALUES(0) = Ct;
	RETURN(1);
L108:
	VALUES(0) = Cnil;
	RETURN(1);
L105:
	VALUES(0) = (V1);
	RETURN(1);
L102:
	VALUES(0) = Ct;
	RETURN(1);
	}
}
/*	function definition for C1FMLA                                */
static L3(int narg, object V1, object V2)
{ VT5 VLEX5 CLSR5
TTL:
	if(!(type_of((V1))==t_cons)){
	goto L111;}
	{object V3= CAR((V1));
	if((V3!= VV[1]))goto L113;
	{object V4= MAKE_FIXNUM(length(CDR((V1))));
	if(!eql(V4,VV[4]))goto L114;
	RETURN((*LK6)(0)                          /*  C1T             */);
L114:
	if(!eql(V4,VV[5]))goto L115;
	V1= CADR((V1));
	goto TTL;
L115:
	{object V5;
	object V6= CDR((V1));
	if(V6==Cnil){
	VALUES(0) = Cnil;
	goto L119;}
	T0=V5=CONS(Cnil,Cnil);
L120:
	{object V7;                               /*  X               */
	L3(2,CAR(V6),(V2))                        /*  C1FMLA          */;
	CAR(V5)= VALUES(0);
	}
	if((V6=CDR(V6))==Cnil){
	VALUES(0) = T0;
	goto L119;}
	V5=CDR(V5)=CONS(Cnil,Cnil);
	goto L120;}
L119:
	VALUES(0) = CONS(VV[6],VALUES(0));
	RETURN(1);}
L113:
	if((V3!= VV[2]))goto L122;
	{object V5= MAKE_FIXNUM(length(CDR((V1))));
	if(!eql(V5,VV[4]))goto L123;
	RETURN((*LK3)(0)                          /*  C1NIL           */);
L123:
	if(!eql(V5,VV[5]))goto L124;
	V1= CADR((V1));
	goto TTL;
L124:
	{object V6;
	object V7= CDR((V1));
	if(V7==Cnil){
	VALUES(0) = Cnil;
	goto L128;}
	T0=V6=CONS(Cnil,Cnil);
L129:
	{object V8;                               /*  X               */
	L3(2,CAR(V7),(V2))                        /*  C1FMLA          */;
	CAR(V6)= VALUES(0);
	}
	if((V7=CDR(V7))==Cnil){
	VALUES(0) = T0;
	goto L128;}
	V6=CDR(V6)=CONS(Cnil,Cnil);
	goto L129;}
L128:
	VALUES(0) = CONS(VV[7],VALUES(0));
	RETURN(1);}
L122:
	if((V3!= VV[3])
	&& (V3!= VV[60]))goto L131;
	if(!(CDR((V1))==Cnil)){
	goto L132;}
	(*LK0)(3,VV[3],MAKE_FIXNUM(1),MAKE_FIXNUM(0))/*  TOO-FEW-ARGS */;
L132:
	if(CDDR((V1))==Cnil){
	goto L135;}
	(*LK1)(3,VV[3],MAKE_FIXNUM(1),MAKE_FIXNUM(length(CDR((V1)))))/*  TOO-MANY-ARGS*/;
L135:
	L3(2,CADR((V1)),(V2))                     /*  C1FMLA          */;
	VALUES(0) = list(2,VV[8],VALUES(0));
	RETURN(1);
L131:
	RETURN((*LK5)(2,(V1),(V2))                /*  C1EXPR*         */);}
L111:
	RETURN((*LK5)(2,(V1),(V2))                /*  C1EXPR*         */);
}
/*	function definition for C2IF                                  */
static L6(int narg, object V1, object V2, object V3)
{ VT6 VLEX6 CLSR6
	bds_check;
TTL:
	{register object V4;                      /*  TLABEL          */
	register object V5;                       /*  FLABEL          */
	(VV[9]->s.s_dbind)= number_plus((VV[9]->s.s_dbind),MAKE_FIXNUM(1));
	V4= CONS((VV[9]->s.s_dbind),Cnil);
	V5= Cnil;
	if(!((CAR((V3)))==(VV[10]))){
	goto L143;}
	if((CADDR((V3)))!=Cnil){
	goto L143;}
	if(!(((VV[11]->s.s_dbind))==(VV[12]))){
	goto L143;}
	if(((VV[13]->s.s_dbind))==(VV[14])){
	goto L143;}
	{object V6;                               /*  EXIT            */
	object V7;
	V6= (VV[13]->s.s_dbind);
	V7= CONS((V4),(VV[15]->s.s_dbind));
	bds_bind(VV[15],V7);                      /*  *UNWIND-EXIT*   */
	bds_bind(VV[13],(V4));                    /*  *EXIT*          */
	L8(3,(V1),(V4),(V6))                      /*  CJF             */;
	bds_unwind1;
	bds_unwind1;
	}
	if((CDR((V4)))==Cnil){
	goto L154;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(76,symbol_value(VV[16]));
	(*LK7)(1,CAR((V4)))                       /*  WT1             */;
	princ_char(58,symbol_value(VV[16]));
L154:
	RETURN((*LK8)(1,(V2))                     /*  C2EXPR          */);
L143:
	(VV[9]->s.s_dbind)= number_plus((VV[9]->s.s_dbind),MAKE_FIXNUM(1));
	V5= CONS((VV[9]->s.s_dbind),Cnil);
	{object V6;
	V6= listA(3,(V5),(V4),(VV[15]->s.s_dbind));
	bds_bind(VV[15],V6);                      /*  *UNWIND-EXIT*   */
	bds_bind(VV[13],(V4));                    /*  *EXIT*          */
	L8(3,(V1),(V4),(V5))                      /*  CJF             */;
	bds_unwind1;
	bds_unwind1;
	}
	if((CDR((V4)))==Cnil){
	goto L166;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(76,symbol_value(VV[16]));
	(*LK7)(1,CAR((V4)))                       /*  WT1             */;
	princ_char(58,symbol_value(VV[16]));
L166:
	{object V6;
	V6= CONS(VV[17],(VV[15]->s.s_dbind));
	bds_bind(VV[15],V6);                      /*  *UNWIND-EXIT*   */
	bds_bind(VV[18],(VV[18]->s.s_dbind));     /*  *TEMP*          */
	(*LK8)(1,(V2))                            /*  C2EXPR          */;
	bds_unwind1;
	bds_unwind1;
	}
	if((CDR((V5)))==Cnil){
	goto L175;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(76,symbol_value(VV[16]));
	(*LK7)(1,CAR((V5)))                       /*  WT1             */;
	princ_char(58,symbol_value(VV[16]));
L175:
	RETURN((*LK8)(1,(V3))                     /*  C2EXPR          */);
	}
}
/*	function definition for CJT                                   */
static L7(int narg, object V1, object V2, object V3)
{ VT7 VLEX7 CLSR7
	bds_check;
TTL:
	{object V4= CAR((V1));
	if((V4!= VV[6]))goto L182;
	{register object V5;                      /*  FS              */
	V5= CDR((V1));
L185:
	if(!(CDR((V5))==Cnil)){
	goto L186;}
	V1= CAR((V5));
	goto TTL;
L186:
	{register object V7;                      /*  LABEL           */
	(VV[9]->s.s_dbind)= number_plus((VV[9]->s.s_dbind),MAKE_FIXNUM(1));
	V7= CONS((VV[9]->s.s_dbind),Cnil);
	bds_bind(VV[15],CONS((V7),(VV[15]->s.s_dbind)));/*  *UNWIND-EXIT**/
	L8(3,CAR((V5)),(V7),(V3))                 /*  CJF             */;
	if((CDR((V7)))==Cnil){
	bds_unwind1;
	goto L193;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(76,symbol_value(VV[16]));
	(*LK7)(1,CAR((V7)))                       /*  WT1             */;
	princ_char(58,symbol_value(VV[16]));
	bds_unwind1;
	}
L193:
	V5= CDR((V5));
	goto L185;
	}
L182:
	if((V4!= VV[7]))goto L207;
	{register object V8;                      /*  FS              */
	V8= CDR((V1));
L210:
	if(!(CDR((V8))==Cnil)){
	goto L211;}
	V1= CAR((V8));
	goto TTL;
L211:
	{register object V10;                     /*  LABEL           */
	(VV[9]->s.s_dbind)= number_plus((VV[9]->s.s_dbind),MAKE_FIXNUM(1));
	V10= CONS((VV[9]->s.s_dbind),Cnil);
	bds_bind(VV[15],CONS((V10),(VV[15]->s.s_dbind)));/*  *UNWIND-EXIT**/
	L7(3,CAR((V8)),(V2),(V10))                /*  CJT             */;
	if((CDR((V10)))==Cnil){
	bds_unwind1;
	goto L218;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(76,symbol_value(VV[16]));
	(*LK7)(1,CAR((V10)))                      /*  WT1             */;
	princ_char(58,symbol_value(VV[16]));
	bds_unwind1;
	}
L218:
	V8= CDR((V8));
	goto L210;
	}
L207:
	if((V4!= VV[8]))goto L232;
	RETURN(L8(3,CADR((V1)),(V3),(V2))         /*  CJF             */);
L232:
	if((V4!= VV[10]))goto L233;
	{object V11= CADDR((V1));
	if((V11!= Ct))goto L234;
	(*LK9)(1,(V2))                            /*  UNWIND-NO-EXIT  */;
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	CDR((V2)) = Ct;
	princ_str("goto L",symbol_value(VV[16]));
	(*LK7)(1,CAR((V2)))                       /*  WT1             */;
	princ_char(59,symbol_value(VV[16]));
	VALUES(0) = Cnil;
	RETURN(1);
L234:
	if((V11!= Cnil))goto L243;
	VALUES(0) = Cnil;
	RETURN(1);
L243:
	{object V12;
	V12= list(2,VV[19],(V2));
	bds_bind(VV[11],V12);                     /*  *DESTINATION*   */
	{int V13;
	V13=(*LK10)(1,(V1))                       /*  C2EXPR*         */;
	bds_unwind1;
	RETURN(V13);}
	}}
L233:
	{object V14;
	V14= list(2,VV[19],(V2));
	bds_bind(VV[11],V14);                     /*  *DESTINATION*   */
	{int V15;
	V15=(*LK10)(1,(V1))                       /*  C2EXPR*         */;
	bds_unwind1;
	RETURN(V15);}
	}}
}
/*	function definition for CJF                                   */
static L8(int narg, object V1, object V2, object V3)
{ VT8 VLEX8 CLSR8
	bds_check;
TTL:
	{object V4= CAR((V1));
	if((V4!= VV[6]))goto L246;
	{register object V5;                      /*  FS              */
	V5= CDR((V1));
L249:
	if(!(CDR((V5))==Cnil)){
	goto L250;}
	V1= CAR((V5));
	goto TTL;
L250:
	{register object V7;                      /*  LABEL           */
	(VV[9]->s.s_dbind)= number_plus((VV[9]->s.s_dbind),MAKE_FIXNUM(1));
	V7= CONS((VV[9]->s.s_dbind),Cnil);
	bds_bind(VV[15],CONS((V7),(VV[15]->s.s_dbind)));/*  *UNWIND-EXIT**/
	L8(3,CAR((V5)),(V7),(V3))                 /*  CJF             */;
	if((CDR((V7)))==Cnil){
	bds_unwind1;
	goto L257;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(76,symbol_value(VV[16]));
	(*LK7)(1,CAR((V7)))                       /*  WT1             */;
	princ_char(58,symbol_value(VV[16]));
	bds_unwind1;
	}
L257:
	V5= CDR((V5));
	goto L249;
	}
L246:
	if((V4!= VV[7]))goto L271;
	{register object V8;                      /*  FS              */
	V8= CDR((V1));
L274:
	if(!(CDR((V8))==Cnil)){
	goto L275;}
	V1= CAR((V8));
	goto TTL;
L275:
	{register object V10;                     /*  LABEL           */
	(VV[9]->s.s_dbind)= number_plus((VV[9]->s.s_dbind),MAKE_FIXNUM(1));
	V10= CONS((VV[9]->s.s_dbind),Cnil);
	bds_bind(VV[15],CONS((V10),(VV[15]->s.s_dbind)));/*  *UNWIND-EXIT**/
	L7(3,CAR((V8)),(V2),(V10))                /*  CJT             */;
	if((CDR((V10)))==Cnil){
	bds_unwind1;
	goto L282;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(76,symbol_value(VV[16]));
	(*LK7)(1,CAR((V10)))                      /*  WT1             */;
	princ_char(58,symbol_value(VV[16]));
	bds_unwind1;
	}
L282:
	V8= CDR((V8));
	goto L274;
	}
L271:
	if((V4!= VV[8]))goto L296;
	RETURN(L7(3,CADR((V1)),(V3),(V2))         /*  CJT             */);
L296:
	if((V4!= VV[10]))goto L297;
	{object V11= CADDR((V1));
	if((V11!= Ct))goto L298;
	VALUES(0) = Cnil;
	RETURN(1);
L298:
	if((V11!= Cnil))goto L299;
	(*LK9)(1,(V3))                            /*  UNWIND-NO-EXIT  */;
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	CDR((V3)) = Ct;
	princ_str("goto L",symbol_value(VV[16]));
	(*LK7)(1,CAR((V3)))                       /*  WT1             */;
	princ_char(59,symbol_value(VV[16]));
	VALUES(0) = Cnil;
	RETURN(1);
L299:
	{object V12;
	V12= list(2,VV[20],(V3));
	bds_bind(VV[11],V12);                     /*  *DESTINATION*   */
	{int V13;
	V13=(*LK10)(1,(V1))                       /*  C2EXPR*         */;
	bds_unwind1;
	RETURN(V13);}
	}}
L297:
	{object V14;
	V14= list(2,VV[20],(V3));
	bds_bind(VV[11],V14);                     /*  *DESTINATION*   */
	{int V15;
	V15=(*LK10)(1,(V1))                       /*  C2EXPR*         */;
	bds_unwind1;
	RETURN(V15);}
	}}
}
/*	function definition for C1AND                                 */
static L9(int narg, object V1)
{ VT9 VLEX9 CLSR9
TTL:
	if(!((V1)==Cnil)){
	goto L311;}
	RETURN((*LK6)(0)                          /*  C1T             */);
L311:
	if(!(CDR((V1))==Cnil)){
	goto L314;}
	RETURN((*LK2)(1,CAR((V1)))                /*  C1EXPR          */);
L314:
	{object V2;                               /*  INFO            */
	(*LK4)(0)                                 /*  MAKE-INFO       */;
	V2= VALUES(0);
	(*LK11)(2,(V1),(V2))                      /*  C1ARGS          */;
	VALUES(0) = list(3,VV[1],(V2),VALUES(0));
	RETURN(1);
	}
}
/*	function definition for C2AND                                 */
static L10(int narg, object V1)
{ VT10 VLEX10 CLSR10
	bds_check;
TTL:
	{register object V2;                      /*  FORMS           */
	register object V3;                       /*  FORM            */
	V2= (V1);
	V3= Cnil;
L319:
	if(!(CDR((V2))==Cnil)){
	goto L320;}
	RETURN((*LK8)(1,CAR((V2)))                /*  C2EXPR          */);
L320:
	V3= CAR((V2));
	if(!((CAR((V3)))==(VV[10]))){
	goto L327;}
	{object V5= CADDR((V3));
	if((V5!= Ct))goto L329;
	goto L325;
L329:
	if((V5!= Cnil))goto L330;
	(*LK12)(2,Cnil,VV[17])                    /*  UNWIND-EXIT     */;
	goto L325;
L330:
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(",symbol_value(VV[16]));
	(*LK7)(1,CADDR((V3)))                     /*  WT1             */;
	princ_str("==Cnil){",symbol_value(VV[16]));
	(*LK12)(2,Cnil,VV[17])                    /*  UNWIND-EXIT     */;
	princ_char(125,symbol_value(VV[16]));
	goto L325;}
L327:
	if(!((CAR((V3)))==(VV[21]))){
	goto L340;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(",symbol_value(VV[16]));
	(*LK13)(1,CAR(CADDR((V3))))               /*  WT-VAR          */;
	princ_str("==Cnil){",symbol_value(VV[16]));
	(*LK12)(2,Cnil,VV[17])                    /*  UNWIND-EXIT     */;
	princ_char(125,symbol_value(VV[16]));
	goto L325;
L340:
	{register object V6;                      /*  LABEL           */
	(VV[9]->s.s_dbind)= number_plus((VV[9]->s.s_dbind),MAKE_FIXNUM(1));
	V6= CONS((VV[9]->s.s_dbind),Cnil);
	bds_bind(VV[15],CONS((V6),(VV[15]->s.s_dbind)));/*  *UNWIND-EXIT**/
	{object V7;
	V7= list(2,VV[19],(V6));
	bds_bind(VV[11],V7);                      /*  *DESTINATION*   */
	(*LK10)(1,(V3))                           /*  C2EXPR*         */;
	bds_unwind1;
	}
	(*LK12)(2,Cnil,VV[17])                    /*  UNWIND-EXIT     */;
	if((CDR((V6)))==Cnil){
	bds_unwind1;
	goto L325;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(76,symbol_value(VV[16]));
	(*LK7)(1,CAR((V6)))                       /*  WT1             */;
	princ_char(58,symbol_value(VV[16]));
	bds_unwind1;
	}
L325:
	V2= CDR((V2));
	goto L319;
	}
}
/*	function definition for C1OR                                  */
static L11(int narg, object V1)
{ VT11 VLEX11 CLSR11
TTL:
	if(!((V1)==Cnil)){
	goto L367;}
	RETURN((*LK3)(0)                          /*  C1NIL           */);
L367:
	if(!(CDR((V1))==Cnil)){
	goto L370;}
	RETURN((*LK2)(1,CAR((V1)))                /*  C1EXPR          */);
L370:
	{object V2;                               /*  INFO            */
	(*LK4)(0)                                 /*  MAKE-INFO       */;
	V2= VALUES(0);
	(*LK11)(2,(V1),(V2))                      /*  C1ARGS          */;
	VALUES(0) = list(3,VV[2],(V2),VALUES(0));
	RETURN(1);
	}
}
/*	function definition for C2OR                                  */
static L12(int narg, object V1)
{ VT12 VLEX12 CLSR12
	bds_check;
TTL:
	{register object V2;                      /*  FORMS           */
	register object V3;                       /*  FORM            */
	V2= (V1);
	V3= Cnil;
L375:
	if(!(CDR((V2))==Cnil)){
	goto L376;}
	RETURN((*LK8)(1,CAR((V2)))                /*  C2EXPR          */);
L376:
	V3= CAR((V2));
	if(!((CAR((V3)))==(VV[10]))){
	goto L383;}
	{object V5= CADDR((V3));
	if((V5!= Ct))goto L385;
	(*LK12)(2,Ct,VV[17])                      /*  UNWIND-EXIT     */;
	goto L381;
L385:
	if((V5!= Cnil))goto L386;
	goto L381;
L386:
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(",symbol_value(VV[16]));
	(*LK7)(1,CADDR((V3)))                     /*  WT1             */;
	princ_str("!=Cnil){",symbol_value(VV[16]));
	(*LK12)(2,CADDR((V3)),VV[17])             /*  UNWIND-EXIT     */;
	princ_char(125,symbol_value(VV[16]));
	goto L381;}
L383:
	if(!((CAR((V3)))==(VV[21]))){
	goto L396;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(",symbol_value(VV[16]));
	(*LK13)(1,CAR(CADDR((V3))))               /*  WT-VAR          */;
	princ_str("!=Cnil){",symbol_value(VV[16]));
	(*LK12)(2,CONS(VV[21],CADDR((V3))),VV[17])/*  UNWIND-EXIT     */;
	princ_char(125,symbol_value(VV[16]));
	goto L381;
L396:
	if(!((CAR((V3)))==(VV[22]))){
	goto L408;}
	if((getf(CADDR((V3))->s.s_plist,VV[23],Cnil))==Cnil){
	goto L408;}
	{register object V6;                      /*  LABEL           */
	(VV[9]->s.s_dbind)= number_plus((VV[9]->s.s_dbind),MAKE_FIXNUM(1));
	V6= CONS((VV[9]->s.s_dbind),Cnil);
	bds_bind(VV[15],CONS((V6),(VV[15]->s.s_dbind)));/*  *UNWIND-EXIT**/
	{object V7;
	V7= list(2,VV[20],(V6));
	bds_bind(VV[11],V7);                      /*  *DESTINATION*   */
	(*LK10)(1,(V3))                           /*  C2EXPR*         */;
	bds_unwind1;
	}
	(*LK12)(2,Ct,VV[17])                      /*  UNWIND-EXIT     */;
	if((CDR((V6)))==Cnil){
	bds_unwind1;
	goto L381;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(76,symbol_value(VV[16]));
	(*LK7)(1,CAR((V6)))                       /*  WT1             */;
	princ_char(58,symbol_value(VV[16]));
	bds_unwind1;
	goto L381;
	}
L408:
	{register object V7;                      /*  LABEL           */
	(VV[9]->s.s_dbind)= number_plus((VV[9]->s.s_dbind),MAKE_FIXNUM(1));
	V7= CONS((VV[9]->s.s_dbind),Cnil);
	bds_bind(VV[15],CONS((V7),(VV[15]->s.s_dbind)));/*  *UNWIND-EXIT**/
	bds_bind(VV[11],VV[14]);                  /*  *DESTINATION*   */
	(*LK10)(1,(V3))                           /*  C2EXPR*         */;
	bds_unwind1;
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(VALUES(0)==Cnil)",symbol_value(VV[16]));
	CDR((V7)) = Ct;
	princ_str("goto L",symbol_value(VV[16]));
	(*LK7)(1,CAR((V7)))                       /*  WT1             */;
	princ_char(59,symbol_value(VV[16]));
	(*LK12)(2,VV[24],VV[17])                  /*  UNWIND-EXIT     */;
	if((CDR((V7)))==Cnil){
	bds_unwind1;
	goto L381;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(76,symbol_value(VV[16]));
	(*LK7)(1,CAR((V7)))                       /*  WT1             */;
	princ_char(58,symbol_value(VV[16]));
	bds_unwind1;
	}
L381:
	V2= CDR((V2));
	goto L375;
	}
}
/*	function definition for SET-JUMP-TRUE                         */
static L13(int narg, object V1, object V2)
{ VT13 VLEX13 CLSR13
TTL:
	if(((V1))==Cnil){
	goto L448;}
	{object V3;
	V3= (((V1))==(Ct)?Ct:Cnil);
	if(((V3))==Cnil){
	goto L453;}
	goto L450;
L453:
	if(!((CAR((V1)))==(VV[25]))){
	goto L456;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(",symbol_value(VV[16]));
	(*LK14)(2,CADDR((V1)),CADDDR((V1)))       /*  WT-INLINE-LOC   */;
	princ_char(41,symbol_value(VV[16]));
	goto L450;
L456:
	if((memq(CAR((V1)),VV[26]))==Cnil){
	goto L465;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	(*LK7)(1,(V1))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[16]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(VALUES(0)!=Cnil)",symbol_value(VV[16]));
	goto L450;
L465:
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if((",symbol_value(VV[16]));
	(*LK7)(1,(V1))                            /*  WT1             */;
	princ_str(")!=Cnil)",symbol_value(VV[16]));
	}
L450:
	if(((V1))==(Ct)){
	goto L480;}
	princ_char(123,symbol_value(VV[16]));
L480:
	(*LK9)(1,(V2))                            /*  UNWIND-NO-EXIT  */;
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	CDR((V2)) = Ct;
	princ_str("goto L",symbol_value(VV[16]));
	(*LK7)(1,CAR((V2)))                       /*  WT1             */;
	princ_char(59,symbol_value(VV[16]));
	if(((V1))==(Ct)){
	goto L494;}
	princ_char(125,symbol_value(VV[16]));
	VALUES(0) = Cnil;
	RETURN(1);
L494:
	VALUES(0) = Cnil;
	RETURN(1);
L448:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for SET-JUMP-FALSE                        */
static L14(int narg, object V1, object V2)
{ VT14 VLEX14 CLSR14
TTL:
	if(((V1))==(Ct)){
	goto L498;}
	{object V3;
	V3= ((V1)==Cnil?Ct:Cnil);
	if(((V3))==Cnil){
	goto L503;}
	goto L500;
L503:
	if(!((CAR((V1)))==(VV[25]))){
	goto L506;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(!(",symbol_value(VV[16]));
	(*LK14)(2,CADDR((V1)),CADDDR((V1)))       /*  WT-INLINE-LOC   */;
	princ_str("))",symbol_value(VV[16]));
	goto L500;
L506:
	if((memq(CAR((V1)),VV[27]))==Cnil){
	goto L515;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	(*LK7)(1,(V1))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[16]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(VALUES(0)==Cnil)",symbol_value(VV[16]));
	goto L500;
L515:
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if((",symbol_value(VV[16]));
	(*LK7)(1,(V1))                            /*  WT1             */;
	princ_str(")==Cnil)",symbol_value(VV[16]));
	}
L500:
	if(((V1))==Cnil){
	goto L530;}
	princ_char(123,symbol_value(VV[16]));
L530:
	(*LK9)(1,(V2))                            /*  UNWIND-NO-EXIT  */;
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	CDR((V2)) = Ct;
	princ_str("goto L",symbol_value(VV[16]));
	(*LK7)(1,CAR((V2)))                       /*  WT1             */;
	princ_char(59,symbol_value(VV[16]));
	if(((V1))==Cnil){
	goto L544;}
	princ_char(125,symbol_value(VV[16]));
	VALUES(0) = Cnil;
	RETURN(1);
L544:
	VALUES(0) = Cnil;
	RETURN(1);
L498:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for C1ECASE                               */
static L15(int narg, object V1)
{ VT15 VLEX15 CLSR15
TTL:
	RETURN(L16(2,(V1),Ct)                     /*  C1CASE          */);
}
/*	function definition for C1CASE                                */
static L16(int narg, object V1, ...)
{ VT16 VLEX16 CLSR16
	{int i=1;
	register object V2;
	va_list args; va_start(args, V1);
	if (i==narg) goto L547;
	V2= va_arg(args, object);
	i++;
	goto L548;
L547:
	V2= Cnil;
L548:
	if(!((V1)==Cnil)){
	goto L550;}
	(*LK0)(3,VV[28],MAKE_FIXNUM(1),MAKE_FIXNUM(0))/*  TOO-FEW-ARGS*/;
L550:
	{register object V3;                      /*  INFO            */
	object V4;                                /*  KEY-FORM        */
	object V5;                                /*  CLAUSES         */
	(*LK4)(0)                                 /*  MAKE-INFO       */;
	V3= VALUES(0);
	(*LK5)(2,CAR((V1)),(V3))                  /*  C1EXPR*         */;
	V4= VALUES(0);
	V5= Cnil;
	{register object V6;
	register object V7;                       /*  CLAUSE          */
	V6= CDR((V1));
	V7= Cnil;
L560:
	if(!((V6)==Cnil)){
	goto L561;}
	goto L556;
L561:
	V7= CAR((V6));
	if(!((V7)==Cnil)){
	goto L566;}
	(*LK15)(2,VV[29],(V7))                    /*  CMPERR          */;
L566:
	{object V9= CAR((V7));
	if((V9!= Cnil))goto L570;
	goto L569;
L570:
	if((V9!= Ct)
	&& (V9!= VV[71]))goto L571;
	if(((V2))==Cnil){
	goto L572;}
	if(!(((V2))==(Ct))){
	goto L577;}
	VALUES(0) = VV[30];
	goto L575;
L577:
	VALUES(0) = VV[31];
L575:
	(*LK15)(1,VALUES(0))                      /*  CMPERR          */;
L572:
	(*LK16)(1,CDR((V7)))                      /*  C1PROGN         */;
	V2= VALUES(0);
	(*LK17)(2,(V3),CADR((V2)))                /*  ADD-INFO        */;
	goto L569;
L571:
	{object V10;                              /*  KEYLIST         */
	object V11;                               /*  BODY            */
	if(!(type_of(CAR((V7)))==t_cons)){
	goto L583;}
	{object V12;
	object V13= CAR((V7));
	if(V13==Cnil){
	V10= Cnil;
	goto L581;}
	T0=V12=CONS(Cnil,Cnil);
L585:
	{object V14;                              /*  KEY             */
	V14= CAR(V13);
	if(!(type_of((V14))==t_symbol)){
	goto L588;}
	CAR(V12)= (V14);
	goto L586;
L588:
	(*LK18)(1,(V14))                          /*  ADD-OBJECT      */;
	CAR(V12)= VALUES(0);
	}
L586:
	if((V13=CDR(V13))==Cnil){
	V10= T0;
	goto L581;}
	V12=CDR(V12)=CONS(Cnil,Cnil);
	goto L585;}
L583:
	if(!(type_of(CAR((V7)))==t_symbol)){
	goto L591;}
	V10= CONS(CAR((V7)),Cnil);
	goto L581;
L591:
	(*LK18)(1,CAR((V7)))                      /*  ADD-OBJECT      */;
	V10= CONS(VALUES(0),Cnil);
L581:
	(*LK16)(1,CDR((V7)))                      /*  C1PROGN         */;
	V11= VALUES(0);
	(*LK17)(2,(V3),CADR((V11)))               /*  ADD-INFO        */;
	V5= CONS(CONS((V10),(V11)),(V5));
	}}
L569:
	V6= CDR((V6));
	goto L560;
	}
L556:
	{object V6= nreverse((V5));
	if((V2)!=Cnil){
	VALUES(0) = (V2);
	goto L600;}
	(*LK3)(0)                                 /*  C1NIL           */;
L600:
	VALUES(0) = list(5,VV[28],(V3),(V4),V6,VALUES(0));
	RETURN(1);}
	}
	}
}
/*	function definition for C2CASE                                */
static L18(int narg, object V1, object V2, object V3)
{ VT17 VLEX17 CLSR17
	bds_check;
TTL:
	{register object V4;                      /*  LOC             */
	V4= Cnil;
	bds_bind(VV[32],MAKE_FIXNUM(0));          /*  *INLINE-BLOCKS* */
	(*LK19)(1,CONS((V1),Cnil))                /*  INLINE-ARGS     */;
	V1= CADR(CAR(VALUES(0)));
	if(!(type_of((V1))==t_cons)){
	goto L607;}
	if(!((CAR((V1)))==(VV[21]))){
	goto L607;}
	V4= (V1);
	goto L605;
L607:
	(*LK20)(0)                                /*  NEXT-LCL        */;
	V4= list(2,VV[33],VALUES(0));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{object ",symbol_value(VV[16]));
	(*LK7)(1,(V4))                            /*  WT1             */;
	princ_str("= ",symbol_value(VV[16]));
	(*LK7)(1,(V1))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[16]));
L605:
	{register object V5;
	object V6;                                /*  CLAUSE          */
	V5= (V2);
	V6= Cnil;
L626:
	if(!((V5)==Cnil)){
	goto L627;}
	goto L622;
L627:
	V6= CAR((V5));
	{register object V8;                      /*  LABEL           */
	register object V9;                       /*  KEYLIST         */
	register object V10;                      /*  LOCAL-LABEL     */
	(VV[9]->s.s_dbind)= number_plus((VV[9]->s.s_dbind),MAKE_FIXNUM(1));
	V8= CONS((VV[9]->s.s_dbind),Cnil);
	V9= CAR((V6));
	V10= Cnil;
L639:
	if(!((length((V9)))<=(5))){
	goto L640;}
	goto L637;
L640:
	if(((V10))!=Cnil){
	goto L643;}
	(VV[9]->s.s_dbind)= number_plus((VV[9]->s.s_dbind),MAKE_FIXNUM(1));
	V10= CONS((VV[9]->s.s_dbind),Cnil);
L643:
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(",symbol_value(VV[16]));
	{register int V12;                        /*  I               */
	V12= 0;
L655:
	if(!((V12)>=(fix(MAKE_FIXNUM(5))))){
	goto L656;}
	goto L652;
L656:
	if(!(type_of(CAR((V9)))==t_symbol)){
	goto L661;}
	princ_char(40,symbol_value(VV[16]));
	(*LK7)(1,(V4))                            /*  WT1             */;
	princ_str("== ",symbol_value(VV[16]));
	{object V14= CAR((V9));
	if((V14!= Ct))goto L668;
	princ_str("Ct",symbol_value(VV[16]));
	goto L667;
L668:
	if((V14!= Cnil))goto L670;
	princ_str("Cnil",symbol_value(VV[16]));
	goto L667;
L670:
	princ_str("VV[",symbol_value(VV[16]));
	(*LK21)(1,CAR((V9)))                      /*  ADD-SYMBOL      */;
	(*LK7)(1,VALUES(0))                       /*  WT1             */;
	princ_char(93,symbol_value(VV[16]));}
L667:
	princ_char(41,symbol_value(VV[16]));
	goto L659;
L661:
	princ_str("eql(",symbol_value(VV[16]));
	(*LK7)(1,(V4))                            /*  WT1             */;
	princ_str(",VV[",symbol_value(VV[16]));
	(*LK7)(1,CAR((V9)))                       /*  WT1             */;
	princ_str("])",symbol_value(VV[16]));
L659:
	if(!((V12)<(4))){
	goto L682;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("|| ",symbol_value(VV[16]));
L682:
	V9= CDR((V9));
	V12= (V12)+1;
	goto L655;
	}
L652:
	princ_char(41,symbol_value(VV[16]));
	CDR((V10)) = Ct;
	princ_str("goto L",symbol_value(VV[16]));
	(*LK7)(1,CAR((V10)))                      /*  WT1             */;
	princ_char(59,symbol_value(VV[16]));
	goto L639;
L637:
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(",symbol_value(VV[16]));
L709:
	if(!((V9)==Cnil)){
	goto L710;}
	goto L707;
L710:
	if(!(type_of(CAR((V9)))==t_symbol)){
	goto L715;}
	princ_char(40,symbol_value(VV[16]));
	(*LK7)(1,(V4))                            /*  WT1             */;
	princ_str("!= ",symbol_value(VV[16]));
	{object V12= CAR((V9));
	if((V12!= Ct))goto L722;
	princ_str("Ct",symbol_value(VV[16]));
	goto L721;
L722:
	if((V12!= Cnil))goto L724;
	princ_str("Cnil",symbol_value(VV[16]));
	goto L721;
L724:
	princ_str("VV[",symbol_value(VV[16]));
	(*LK21)(1,CAR((V9)))                      /*  ADD-SYMBOL      */;
	(*LK7)(1,VALUES(0))                       /*  WT1             */;
	princ_char(93,symbol_value(VV[16]));}
L721:
	princ_char(41,symbol_value(VV[16]));
	goto L713;
L715:
	princ_str("!eql(",symbol_value(VV[16]));
	(*LK7)(1,(V4))                            /*  WT1             */;
	princ_str(",VV[",symbol_value(VV[16]));
	(*LK7)(1,CAR((V9)))                       /*  WT1             */;
	princ_str("])",symbol_value(VV[16]));
L713:
	if(CDR((V9))==Cnil){
	goto L736;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("&& ",symbol_value(VV[16]));
L736:
	V9= CDR((V9));
	goto L709;
L707:
	princ_char(41,symbol_value(VV[16]));
	CDR((V8)) = Ct;
	princ_str("goto L",symbol_value(VV[16]));
	(*LK7)(1,CAR((V8)))                       /*  WT1             */;
	princ_char(59,symbol_value(VV[16]));
	if(((V10))==Cnil){
	goto L754;}
	if((CDR((V10)))==Cnil){
	goto L754;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(76,symbol_value(VV[16]));
	(*LK7)(1,CAR((V10)))                      /*  WT1             */;
	princ_char(58,symbol_value(VV[16]));
L754:
	{object V11;
	V11= CONS(VV[17],(VV[15]->s.s_dbind));
	bds_bind(VV[15],V11);                     /*  *UNWIND-EXIT*   */
	(*LK8)(1,CDR((V6)))                       /*  C2EXPR          */;
	bds_unwind1;
	}
	if((CDR((V8)))==Cnil){
	goto L632;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	princ_char(76,symbol_value(VV[16]));
	(*LK7)(1,CAR((V8)))                       /*  WT1             */;
	princ_char(58,symbol_value(VV[16]));
	}
L632:
	V5= CDR((V5));
	goto L626;
	}
L622:
	if(!(((V3))==(Ct))){
	goto L776;}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("FEerror(\"The ECASE key value ~s is illegal.\",1,",symbol_value(VV[16]));
	(*LK7)(1,(V4))                            /*  WT1             */;
	princ_str(");",symbol_value(VV[16]));
	goto L774;
L776:
	(*LK8)(1,(V3))                            /*  C2EXPR          */;
L774:
	if(((V4))==((V1))){
	goto L783;}
	princ_char(125,symbol_value(VV[16]));
L783:
	{int V5;
	V5=(*LK22)(0)                             /*  CLOSE-INLINE-BLOCKS*/;
	bds_unwind1;
	RETURN(V5);}
	}
}
static LKF22(int narg, ...) {TRAMPOLINK(VV[78],&LK22);}
static LKF21(int narg, ...) {TRAMPOLINK(VV[77],&LK21);}
static LKF20(int narg, ...) {TRAMPOLINK(VV[76],&LK20);}
static LKF19(int narg, ...) {TRAMPOLINK(VV[75],&LK19);}
static LKF18(int narg, ...) {TRAMPOLINK(VV[74],&LK18);}
static LKF17(int narg, ...) {TRAMPOLINK(VV[73],&LK17);}
static LKF16(int narg, ...) {TRAMPOLINK(VV[72],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[70],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[69],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[68],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[67],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[66],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[65],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[64],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[63],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[62],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[61],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[59],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[58],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[57],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[56],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[55],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[54],&LK0);}
