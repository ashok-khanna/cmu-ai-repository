
/* h/ecl.h.  Generated automatically by configure.  */
/*
    ecl.h  -- Include file for compiled code.
*/
/*
    Copyright (c) 1984, Taiichi Yuasa and Masami Hagiya.
    Copyright (c) 1990, Giuseppe Attardi.

    ECoLisp is free software; you can redistribute it and/or modify it under
    the terms of the GNU General Library Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    See file '../Copyright' for full details.
*/

#include <stdio.h>
#include <stdarg.h>
#include <setjmp.h>
#include <math.h>

#define CLOS 1 
/* #undef PDE */
/* #undef LOCATIVE */
/* #undef THREADS */

/* #undef _setjmp */
/* #undef _longjmp */

#define LINK_ARGS	&narg
#ifdef CLOS
#define TRAMPOLINK(vv, lk) \
	static object gfun = OBJNULL; \
	va_list args; va_start(args, narg); \
	if (gfun) return(gcall(narg, gfun, args)); \
	else return(link_call(vv, lk , &gfun, &narg))
#else
#define TRAMPOLINK(vv, lk) \
	va_list args; va_start(args, narg); \
	return(link_call(vv, lk , &narg))
#endif CLOS
#ifndef VOL
#define VOL
#endif
#define VALUES(n)	Values[n]
#define RETURN(x)	return(x)
#define MV_SAVE(nr) \
   { object mv_values[nr]; /* __GNUC__ */ \
       memcpy(mv_values, &VALUES(0), (nr) * sizeof(object))
#define MV_RESTORE(nr) \
       memcpy(&VALUES(0), mv_values, (nr) * sizeof(object));}
#define MV_SHIFT(nr, d) \
   { int i; for (i = (nr)-1; i >= 0; i--) VALUES(i+d) = VALUES(i);}
#define	TRUE		1
#define	FALSE		0
typedef int bool;
typedef int fixnum;
typedef float shortfloat;
typedef double longfloat;
typedef unsigned char byte;
typedef union lispunion *object;
#define	OBJNULL		((object)NULL)
#define IMMEDIATE(obje)	((int)(obje) & 3)
#define MAKE_FIXNUM(n)		((object)(((int)(n) << 2) | 1))
#define	fix(obje)		(((int)(obje)) >> 2)
#ifdef LOCATIVE
#define FIXNUMP(obje)		((((int)(obje)) & 3) == 1)
#else
#define FIXNUMP(obje)		(((int)(obje)) & 1)
#endif
#define CHARACTERP(obje)	((((int)(obje)) & 3) == 2)
#define	code_char(c)		((object)(((int)(c) << 2) | 2))
#define MAKE_CHARACTER(c,b,f)	((object)(((((b) << 16) | (int)(c)) << 2) | 2))
#define	char_code(obje)		((((int)(obje)) >> 2) & 0xffff)
#define	char_bits(obje)		(((int)(obje)) >> 18) /* CHCODEFLEN * 8 + 2 */
#define	char_font(obje)		0
#define char_int(obje)		char_code(obje)
#define int_char(i)		code_char(i)
#ifdef LOCATIVE
#define LOCATIVEP(obje)	((((int)(obje)) & 3) == 3)
#define MAKE_LOCATIVE(n)((object)(((int)(n) << 2) | 3))
#define DEREF(loc)	(*(object *)((unsigned int)(loc) >> 2))
#define UNBOUNDP(loc)	(DEREF(loc) == OBJNULL)
#endif LOCATIVE
#define ARRAYP(x)	(type_of(x) >= t_array && type_of(x) <= t_bitvector)
#define HEADER		byte t, m
struct shortfloat_struct {
	HEADER;
	shortfloat	SFVAL;
};
#define	sf(obje)	(obje)->SF.SFVAL
struct longfloat_struct {
	HEADER;
	longfloat	LFVAL;
};
#define	lf(obje)	(obje)->LF.LFVAL
struct bignum {
	HEADER;
	struct bignum   *big_cdr;
	int		big_car;
};
struct ratio {
	HEADER;
	object	rat_den;
	object	rat_num;
};
struct complex {
	HEADER;
	object	cmp_real;
	object	cmp_imag;
};
enum stype {
	stp_ordinary,
	stp_constant,
        stp_special
};
#define	Cnil			((object)&Cnil_body)
#define	Ct			((object)&Ct_body)
struct symbol {
	HEADER;
	byte    s_stype;
	byte    s_mflag;
	object	s_dbind;
	int	(*s_sfdef)();
#define	NOT_SPECIAL		((int (*)())Cnil)
#define SPECIAL(fun)		((fun)->s.s_sfdef != NOT_SPECIAL)
#define	s_fillp		st_fillp
#define	s_self		st_self
	int	s_fillp;
	char	*s_self;
	object	s_gfdef;
	object	s_plist;
	object	s_hpack;
};
struct package {
	HEADER;
	object	p_name;
	object	p_nicknames;
	object	p_shadowings;
	object	p_uselist;
	object	p_usedbylist;
	object	*p_internal;
	object	*p_external;
	struct package
		*p_link;
};
struct cons {
	HEADER;
	object	c_cdr;
	object	c_car;
};
enum httest {
	htt_eq,
	htt_eql,
	htt_equal
};
struct htent {
	object	hte_key;
	object	hte_value;
};
struct hashtable {
	HEADER;
	short	ht_test;
	struct  htent
		*ht_self;
	object	ht_rhsize;
	object	ht_rhthresh;
	int	ht_nent;
	int	ht_size;
};
enum aelttype {
	aet_object,
	aet_ch,
	aet_bit,
	aet_fix,
	aet_sf,
	aet_lf
/*	,aet_char,
        aet_uchar,
	aet_short,
	aet_ushort
*/
};
struct array {
	HEADER;
	byte	a_adjustable;
	byte	a_rank;
	object	a_displaced;
	int	a_dim;
	int	*a_dims;
	object	*a_self;
	byte	a_elttype;
	byte	a_offset;
};
struct vector {
	HEADER;
	byte	v_adjustable;
	byte	v_hasfillp;
	object	v_displaced;
	int	v_dim;
	int	v_fillp;
	object	*v_self;
	byte	v_elttype;
};
struct string {
	HEADER;
	byte	st_adjustable;
	byte	st_hasfillp;
	object	st_displaced;
	int	st_dim;
	int	st_fillp;
	char	*st_self;
};
struct ustring {
	HEADER;
	byte	ust_adjustable;
	byte	ust_hasfillp;
	object	ust_displaced;
	int	ust_dim;
	int	ust_fillp;
	unsigned char
		*ust_self;
};
struct bitvector {
	HEADER;
	byte	bv_adjustable;
	byte	bv_hasfillp;
	object	bv_displaced;
	int	bv_dim;
	int	bv_fillp;
	char	*bv_self;
	byte	bv_elttype;
	byte	bv_offset;
};
struct fixarray {
	HEADER;
	byte	fixa_adjustable;
	byte	fixa_rank;
	object	fixa_displaced;
	int	fixa_dim;
	int	*fixa_dims;
	fixnum	*fixa_self;
	byte	fixa_elttype;
};
struct sfarray {
	HEADER;
	byte	sfa_adjustable;
	byte	sfa_rank;
	object	sfa_displaced;
	int	sfa_dim;
	int	*sfa_dims;
	shortfloat
		*sfa_self;
	byte	sfa_elttype;
};
struct lfarray {
	HEADER;
	byte	lfa_adjustable;
	byte	lfa_rank;
	object	lfa_displaced;
	int	lfa_dim;
	int	*lfa_dims;
	longfloat
		*lfa_self;
	byte	lfa_elttype;
};
struct structure {
	HEADER;
	short	str_length;
	object	str_name;
	object	*str_self;
};
#ifdef CLOS
#define T_STRUCTURE	t_instance
#define STYPE(x)	CLASS_OF(x)
#define SLOTS(x)	(x)->in.in_slots
#define SLENGTH(x)	(x)->in.in_length
#define SLOT(x,i)	(x)->in.in_slots[i]
#define SNAME(x)	CLASS_NAME(CLASS_OF(x))
#else
#define T_STRUCTURE	t_structure
#define STYPE(x)	x->str.str_name
#define SLOTS(x)	(x)->str.str_self
#define SLENGTH(x)	(x)->str.str_length
#define SLOT(x,i)	(x)->str.str_self[i]
#define SNAME(x)	x->str.str_name
#endif
enum smmode {
	smm_input,
	smm_output,
	smm_io,
	smm_probe,
	smm_synonym,
	smm_broadcast,
	smm_concatenated,
	smm_two_way,
	smm_echo,
	smm_string_input,
	smm_string_output
};
struct stream {
	HEADER;
	short	sm_mode;
	FILE	*sm_fp;
	object	sm_object0;
	object	sm_object1;
	int	sm_int0;
	int	sm_int1;
};
struct random {
	HEADER;
	unsigned	rnd_value;
};
enum chattrib {
	cat_whitespace,
	cat_terminating,
	cat_non_terminating,
	cat_single_escape,
	cat_multiple_escape,
	cat_constituent
};
struct rtent {
	enum chattrib	rte_chattrib;
	object		rte_macro;
	object		*rte_dtab;
};
struct readtable {
	HEADER;
	struct rtent	*rt_self;
};
struct pathname {
	HEADER;
	object	pn_host;
	object	pn_device;
	object	pn_directory;
	object	pn_name;
	object	pn_type;
	object	pn_version;
};
struct codeblock {
	char	*cd_start;
	int	cd_size;
 	object	cd_data;
      };
struct cfun {
	HEADER;
	object	cf_name;
	int	(*cf_self)();
	struct codeblock *cf_block;
};
struct cclosure {
	HEADER;
	int	(*cc_self)();
	object	cc_env;
	struct codeblock *cc_block;
};
/*
struct spice {
	HEADER;
	int	spc_dummy;
};
*/
struct dummy {
	HEADER;
};
#ifdef THREADS
struct cont {
	HEADER;
	object	cn_thread;
	bool	cn_resumed;
	bool	cn_timed_out;
};
struct thread {
	HEADER;
	struct pd      *th_self;
	int	th_size;
	object	th_fun;
	object	th_cont;
};
#endif THREADS
#ifdef CLOS
struct instance {
	HEADER;
	short	in_length;
	object	in_class;
	object	*in_slots;
};
struct gfun {
	HEADER;
	short	gf_arg_no;
	object	gf_name;
	object  gf_meth_ht;
	object  *gf_spec_how;
	object  gf_gfun;
};
#endif CLOS
union lispunion {
	struct bignum	big;
	struct ratio	rat;
	struct shortfloat_struct
			SF;
	struct longfloat_struct
			LF;
	struct complex	cmp;
	struct symbol	s;
	struct package	p;
	struct cons	c;
	struct hashtable
			ht;
	struct array	a;
	struct vector	v;
	struct string	st;
	struct ustring	ust;
	struct bitvector
			bv;
	struct stream	sm;
	struct random	rnd;
	struct readtable
			rt;
	struct pathname	pn;
	struct cfun	cf;
	struct cclosure	cc;
/*	struct spice	spc; */
	struct dummy	d;
	struct fixarray	fixa;
	struct sfarray	sfa;
	struct lfarray	lfa;
#ifdef CLOS
	struct instance in;
	struct gfun	gf;
#else
	struct structure
			str;
#endif CLOS
#ifdef THREADS
	struct cont     cn;
	struct thread   th;
#endif THREADS
};
typedef union { int i; object o;} intUobject;
enum type {
	t_cons = 0,
#ifdef APOLLO
	t_start = 0,
#else
	t_start = t_cons,
#endif APOLLO
	t_bignum,
	t_ratio,
	t_shortfloat,
	t_longfloat,
	t_complex,
	t_symbol,
	t_package,
	t_hashtable,
	t_array,
	t_vector,
	t_string,
	t_bitvector,
	t_stream,
	t_random,
	t_readtable,
	t_pathname,
	t_cfun,
	t_cclosure,
/*	t_spice, */
#ifdef CLOS
	t_instance,
	t_gfun,
#else
	t_structure,
#endif CLOS
#ifdef THREADS
	t_cont,
	t_thread,
#endif
	t_end,
	t_contiguous,
	t_relocatable,
	t_other,
	t_fixnum,
#ifdef MAC
	t_character,
#ifdef LOCATIVE
	t_locative,
#endif LOCATIVE
	t_last
#else
	t_character
#ifdef LOCATIVE
	, t_locative
#endif LOCATIVE
#endif MAC
};
#define	type_of(obje)	((enum type)(IMMEDIATE(obje) ? \
				       ((int)t_other + IMMEDIATE(obje)) \
				       : (((object)(obje))->d.t)))
#define	endp(obje)	endp1(obje)
#ifdef THREADS
#define Values		clwp->lwp_Values
#define cs_limit        clwp->lwp_cs_limit
#else
extern object Values[];
extern int *cs_limit;
#endif THREADS
#define	cs_check \
	if ((int *)(&narg) < cs_limit) \
		cs_overflow()
#define	check_arg(n)  \
			if (narg != (n))  \
				check_arg_failed(narg, n)
#define cs_reserve(x)	if(&narg-(x) < cs_limit)  \
				cs_overflow();
struct bds_bd {
	object	bds_sym;
	object	bds_val;
};
#ifdef THREADS
#define bind_stack      clwp->lwp_bind_stack
#else
extern struct bds_bd bind_stack[]; 
#endif THREADS
#define bds_org		bind_stack
typedef struct bds_bd *bds_ptr;
#ifdef THREADS
#define bds_limit       clwp->lwp_bds_limit
#define bds_top         clwp->lwp_bds_top
#else
extern bds_ptr bds_limit;
extern bds_ptr bds_top;
#endif THREADS
#define	bds_check  \
	if (bds_top >= bds_limit)  \
		bds_overflow()
#define	bds_bind(sym, val)  \
	((++bds_top)->bds_sym = (sym),  \
	bds_top->bds_val = (sym)->s.s_dbind,  \
	(sym)->s.s_dbind = (val))
#define	bds_unwind1  \
	((bds_top->bds_sym)->s.s_dbind = bds_top->bds_val, --bds_top)
typedef struct invocation_history {
	object	ihs_function;
	object	*ihs_base;
} *ihs_ptr;
#ifdef THREADS
#define ihs_stack       clwp->lwp_ihs_stack
#else
extern struct invocation_history ihs_stack[];
#endif THREADS
#define ihs_org		ihs_stack
#ifdef THREADS
#define ihs_limit       clwp->lwp_ihs_limit
#define ihs_top         clwp->lwp_ihs_top
#else
extern ihs_ptr ihs_limit;
extern ihs_ptr ihs_top;
#endif THREADS
#define	ihs_check  \
	if (ihs_top >= ihs_limit)  \
		ihs_overflow()
#define ihs_push(function, args)  \
	(++ihs_top)->ihs_function = (function);  \
	ihs_top->ihs_base = args
#define ihs_pop() 	(ihs_top--)
enum fr_class {
	FRS_CATCH,
	FRS_CATCHALL,
	FRS_PROTECT
};
struct frame {
	jmp_buf		frs_jmpbuf;
	object		*frs_lex;
	bds_ptr		frs_bds_top;
	enum fr_class	frs_class;
	object		frs_val;
	ihs_ptr		frs_ihs;
};
typedef struct frame *frame_ptr;

#ifdef THREADS
#define frame_stack       clwp->lwp_frame_stack
#else
extern struct frame frame_stack[];
#endif THREADS
#define frs_org		frame_stack
#ifdef THREADS
#define frs_limit       clwp->lwp_frs_limit
#define frs_top         clwp->lwp_frs_top
#else
extern frame_ptr frs_limit;
extern frame_ptr frs_top;
#endif THREADS
#define frs_push(class, val)  \
	(((++frs_top >= frs_limit) && frs_overflow()),  \
 	frs_top->frs_lex = lex_env,\
	frs_top->frs_bds_top = bds_top,  \
	frs_top->frs_class = (class),  \
	frs_top->frs_val = (val),  \
	frs_top->frs_ihs = ihs_top,  \
        _setjmp(frs_top->frs_jmpbuf))
#define frs_pop()	frs_top--
#ifdef THREADS
#define nlj_fr           clwp->lwp_nlj_fr
#define nlj_tag          clwp->lwp_nlj_tag
#define lex_env		 clwp->lwp_lex_env
#else
extern frame_ptr nlj_fr;
extern object nlj_tag;
extern object *lex_env;
#endif THREADS
object caar();
object cadr();
object cdar();
object cddr();
object caaar();
object caadr();
object cadar();
object caddr();
object cdaar();
object cdadr();
object cddar();
object cdddr();
object caaaar();
object caaadr();
object caadar();
object caaddr();
object cadaar();
object cadadr();
object caddar();
object cadddr();
object cdaaar();
object cdaadr();
object cdadar();
object cdaddr();
object cddaar();
object cddadr();
object cdddar();
object cddddr();
#define CONS(a,d)	make_cons((a),(d))
#define CAR(x)	(x)->c.c_car
#define CDR(x)	(x)->c.c_cdr
#define CAAR(x)	(x)->c.c_car->c.c_car
#define CADR(x)	(x)->c.c_cdr->c.c_car
#define CDAR(x)	(x)->c.c_car->c.c_cdr
#define CDDR(x)	(x)->c.c_cdr->c.c_cdr
#define CAAAR(x)	(x)->c.c_car->c.c_car->c.c_car
#define CAADR(x)	(x)->c.c_cdr->c.c_car->c.c_car
#define CADAR(x)	(x)->c.c_car->c.c_cdr->c.c_car
#define CADDR(x)	(x)->c.c_cdr->c.c_cdr->c.c_car
#define CDAAR(x)	(x)->c.c_car->c.c_car->c.c_cdr
#define CDADR(x)	(x)->c.c_cdr->c.c_car->c.c_cdr
#define CDDAR(x)	(x)->c.c_car->c.c_cdr->c.c_cdr
#define CDDDR(x)	(x)->c.c_cdr->c.c_cdr->c.c_cdr
#define CAAAAR(x)	(x)->c.c_car->c.c_car->c.c_car->c.c_car
#define CAAADR(x)	(x)->c.c_cdr->c.c_car->c.c_car->c.c_car
#define CAADAR(x)	(x)->c.c_car->c.c_cdr->c.c_car->c.c_car
#define CAADDR(x)	(x)->c.c_cdr->c.c_cdr->c.c_car->c.c_car
#define CADAAR(x)	(x)->c.c_car->c.c_car->c.c_cdr->c.c_car
#define CADADR(x)	(x)->c.c_cdr->c.c_car->c.c_cdr->c.c_car
#define CADDAR(x)	(x)->c.c_car->c.c_cdr->c.c_cdr->c.c_car
#define CADDDR(x)	(x)->c.c_cdr->c.c_cdr->c.c_cdr->c.c_car
#define CDAAAR(x)	(x)->c.c_car->c.c_car->c.c_car->c.c_car
#define CDAADR(x)	(x)->c.c_cdr->c.c_car->c.c_car->c.c_cdr
#define CDADAR(x)	(x)->c.c_car->c.c_cdr->c.c_car->c.c_cdr
#define CDADDR(x)	(x)->c.c_cdr->c.c_cdr->c.c_car->c.c_cdr
#define CDDAAR(x)	(x)->c.c_car->c.c_car->c.c_cdr->c.c_cdr
#define CDDADR(x)	(x)->c.c_cdr->c.c_car->c.c_cdr->c.c_cdr
#define CDDDAR(x)	(x)->c.c_car->c.c_cdr->c.c_cdr->c.c_cdr
#define CDDDDR(x)	(x)->c.c_cdr->c.c_cdr->c.c_cdr->c.c_cdr
#define	cclosure_call	funcall
int funcall(int, ...);
int funcall_with_catcher(int, ...);
int apply();
extern struct symbol Cnil_body, Ct_body;
object MF();
object MM();
#define MF0(x,y) MF(x,y,&Cblock)
#define MF0key(x,y,z,w) MFkey(x,y,&Cblock,z,w)
#define MM0(x,y) MM(x,y,&Cblock)
extern object Scons;
extern object siSfunction_documentation;
extern object siSvariable_documentation;
extern object siSpretty_print_format;
extern object Slist;
extern object keyword_package;
object alloc_object();
object car();
object cdr();
object list();
object listA();
object coerce_to_string();
object elt();
object elt_set();
frame_ptr frs_sch();
frame_ptr frs_sch_catch();
object new_frame_id();
object make_cclosure();
object nth();
object nthcdr();
object make_cons();
object append();
object nconc();
object reverse();
object nreverse();
object number_divide();
object number_expt();
object number_minus();
object number_negate();
object number_plus();
object number_times();
object one_minus();
object one_plus();
object fixnum_times();
object times_plus();
object get();
object getf();
object putprop();
object remprop();
object string_to_object();
object read_VV();
object symbol_function();
object symbol_name();
object symbol_value();
object make_fixnum();
object make_shortfloat();
object make_longfloat();
object structure_ref();
object structure_set();
object princ();
object prin1();
object print();
object terpri();
object aref();
object aset();
object aref1();
object aset1();
char object_to_char();
int object_to_int();
char *object_to_string();
float object_to_float();
double object_to_double();
object TYPE_OF();
#define Creturn(v)	return((VALUES(0)=(v),1))
#define Cexit		return(0)
double sin(), cos(), tan();
#ifdef THREADS
#define BDSSIZE 1024
#define BDSGETA 16
#define IHSSIZE 1024
#define IHSGETA 32
#define FRSSIZE 1024
#define FRSGETA 16
#define VSSIZE 128
typedef struct lpd {
  struct bds_bd lwp_bind_stack[BDSSIZE + BDSGETA + BDSGETA];
  bds_ptr lwp_bds_limit;
  bds_ptr lwp_bds_top;
  int lwp_cssize;
  int *lwp_cs_org;
  int *lwp_cs_limit;
  struct invocation_history lwp_ihs_stack[IHSSIZE + IHSGETA + IHSGETA];
  ihs_ptr lwp_ihs_limit;
  ihs_ptr lwp_ihs_top;
  struct frame lwp_frame_stack[FRSSIZE + FRSGETA + FRSGETA];
  frame_ptr lwp_frs_limit;
  frame_ptr lwp_frs_top;
  frame_ptr lwp_nlj_fr;
  object lwp_nlj_tag;
  object *lwp_lex_env;
  object lwp_Values[VSSIZE];
  object *lwp_vs_limit;
  object *lwp_vs_base;
  object *lwp_vs_top;
  object lwp_alloc_temporary;
  int lwp_backq_level;
  int lwp_eval1;
  int (*lwp_fmt_ch_fun)();
  object lwp_fmt_stream;
  int lwp_ctl_origin;
  int lwp_ctl_index;
  int lwp_ctl_end;
  object *lwp_fmt_base;
  int lwp_fmt_index;
  int lwp_fmt_end;
  int *lwp_fmt_jmp_buf;
  int lwp_fmt_indents;
  object lwp_fmt_string;
  object lwp_fmt_temporary_stream;
  object lwp_fmt_temporary_string;
  int lwp_fmt_nparam;
  struct {
    int fmt_param_type;
    int fmt_param_value;
  } lwp_fmt_param[100];
  int lwp_fmt_spare_spaces;
  int lwp_fmt_line_length;
  object lwp_thread;
  object lwp_test_function;
  object lwp_item_compared;
  bool (*lwp_tf)();
  object lwp_key_function;
  object (*lwp_kf)();
  int lwp_intern_flag;
  object *lwp_PRINTvs_top;
  object *lwp_PRINTvs_limit;
  object lwp_PRINTstream;
  bool lwp_PRINTescape;
  bool lwp_PRINTpretty;
  bool lwp_PRINTcircle;
  int lwp_PRINTbase;
  bool lwp_PRINTradix;
  object lwp_PRINTcase;
  bool lwp_PRINTgensym;
  int lwp_PRINTlevel;
  int lwp_PRINTlength;
  bool lwp_PRINTarray;
  bool lwp_PRINTpackage;
  bool lwp_PRINTstructure;
  int (*lwp_write_ch_fun)();
  int (*lwp_output_ch_fun)();
#define Q_SIZE    128
#define IS_SIZE   256
  short lwp_queue[Q_SIZE];
  short lwp_indent_stack[IS_SIZE];
  int lwp_qh;
  int lwp_qt;
  int lwp_qc;
  int lwp_isp;
  int lwp_iisp;
  object lwp_READtable;
  int lwp_READdefault_float_format;
  int lwp_READbase;
  bool lwp_READsuppress;
  bool lwp_preserving_whitespace_flag;
  bool lwp_escape_flag;
  object lwp_delimiting_char;
  bool lwp_detect_eos_flag;
  bool lwp_in_list_flag;
  bool lwp_dot_flag;
  object lwp_default_dispatch_macro;
  object lwp_big_register_0;
  int lwp_sharp_eq_context_max;
  object (*lwp_read_ch_fun)();
  object lwp_string_register;
  object lwp_gensym_prefix;
  object lwp_gentemp_prefix;
  object lwp_token;
} lpd;
extern lpd *clwp;
#endif
object make_cfun();
object instance_ref();
object memq();
object memql();
object member();
object assq();
object assql();
object assqlp();
object assoc();
struct htent *gethash(object, object);
#ifdef PDE
extern object siVsource_pathname;
#endif PDE
/* for PROLOG */
extern object *alloc_relblock();
extern object *slot;
extern object (*slotf)();
extern object *trail[];
extern object **trail_top;
#define	trail_push(loc)		(*trail_top++ = (loc))
#define	trail_pop		(**--trail_top = OBJNULL)
#define BIND(loc, val)		{loc = val; trail_push(&loc);}
#define trail_mark		trail_push((object *)NULL)
#define trail_restore	{while (trail_top[-1] != (object *)NULL) trail_pop;}
#define trail_unmark		{trail_restore; trail_top--;}
#define get_value(v, x)		unify(x, v)
#define get_constant(c, x)	(c == x || unify(x, c))
#define get_nil(x)		(Cnil == x || unify(x, Cnil))
#define unify_slot		(*slotf)(*slot)
#define unify_value(loc)	(*slotf)(loc)
#define unify_constant(c)	(*slotf)(c)
#define unify_nil		(*slotf)(Cnil)

int siLAmake_constant();
int siLdefine_macro();
int siLdefine_macro();
int siLdefine_macro();
int siLdefine_macro();
int siLdefine_macro();
int siLdefine_macro();
int siLdefine_macro();
int siLdefine_macro();
int siLdefine_macro();
int siLdefine_macro();
int siLdefine_macro();
int siLdefine_macro();
int siLdefine_macro();
int siLdefine_macro();
int siLdefine_macro();
int siLdefine_macro();
int siLdefine_macro();
int siLdefine_macro();
int siLdefine_macro();
int siLdefine_macro();
int siLdefine_macro();
int siLdefine_macro();
int siLdefine_macro();
int siLdefine_macro();
int siLdefine_macro();
int siLdefine_macro();
int siLdefine_macro();
int siLAmake_constant();
int siLAmake_constant();
int siLAmake_constant();
static L4();
static L9();
static L10();
static L11();
static L12();
static L13();
static L62();
static L69();
#define VT2
#define VLEX2
#define CLSR2
static end_init();
static LC2(int);
#define VT3
#define VLEX3
#define CLSR3
static LC1(int);
#define VT4
#define VLEX4
#define CLSR4
static L3(int, ...);
static intUobject L3keys[4]={225,297,298,299};
#define VT5
#define VLEX5
#define CLSR5
#define Vdeb304 325
#define VT6
#define VLEX6
#define CLSR6
static L5(int);
#define VT7
#define VLEX7
#define CLSR7
#define Vdeb307 327
static L6(int, object);
#define VT8
#define VLEX8
#define CLSR8
#define Vdeb308 329
static L7(int);
#define VT9
#define VLEX9
#define CLSR9
#define Vdeb309 327
static L8(int, object);
#define VT10
#define VLEX10
#define CLSR10
#define Vdeb310 331
#define VT11
#define VLEX11
#define CLSR11
#define VT12
#define VLEX12
#define CLSR12
#define VT13
#define VLEX13
#define CLSR13
#define VT14
#define VLEX14
#define CLSR14
int Lgensym();
#define VT15
#define VLEX15
#define CLSR15
static L14(int, object);
#define VT16
#define VLEX16
#define CLSR16
#define Vdeb136 333
static L15(int, object, object);
#define VT17
#define VLEX17
#define CLSR17
#define Vdeb137 336
static L16(int, object);
#define VT18
#define VLEX18
#define CLSR18
#define Vdeb143 337
static L17(int, object, object);
#define VT19
#define VLEX19
#define CLSR19
#define Vdeb144 339
static L18(int, object);
#define VT20
#define VLEX20
#define CLSR20
#define Vdeb145 340
static L19(int, object, object);
#define VT21
#define VLEX21
#define CLSR21
#define Vdeb146 341
static L20(int, object);
#define VT22
#define VLEX22
#define CLSR22
#define Vdeb147 342
static L21(int, object, object);
#define VT23
#define VLEX23
#define CLSR23
#define Vdeb148 343
static L22(int, object);
#define VT24
#define VLEX24
#define CLSR24
#define Vdeb150 344
static L23(int, object, object);
#define VT25
#define VLEX25
#define CLSR25
#define Vdeb151 345
static L24(int, object);
#define VT26
#define VLEX26
#define CLSR26
#define Vdeb156 346
static L25(int, object, object);
#define VT27
#define VLEX27
#define CLSR27
#define Vdeb157 348
static L26(int, object);
#define VT28
#define VLEX28
#define CLSR28
#define Vdeb161 349
static L27(int, object, object);
#define VT29
#define VLEX29
#define CLSR29
#define Vdeb162 350
static L28(int, object);
#define VT30
#define VLEX30
#define CLSR30
#define Vdeb166 351
static L29(int, object, object);
#define VT31
#define VLEX31
#define CLSR31
#define Vdeb167 352
static L30(int, object);
#define VT32
#define VLEX32
#define CLSR32
#define Vdeb171 353
static L31(int, object, object);
#define VT33
#define VLEX33
#define CLSR33
#define Vdeb172 354
static L32(int, object);
#define VT34
#define VLEX34
#define CLSR34
#define Vdeb176 355
static L33(int, object, object);
#define VT35
#define VLEX35
#define CLSR35
#define Vdeb177 356
static L34(int, object);
#define VT36
#define VLEX36
#define CLSR36
#define Vdeb178 358
static L35(int, object, object);
#define VT37
#define VLEX37
#define CLSR37
#define Vdeb179 360
static L36(int, object);
#define VT38
#define VLEX38
#define CLSR38
#define Vdeb180 361
static L37(int, object, object);
#define VT39
#define VLEX39
#define CLSR39
#define Vdeb181 362
static L38(int, object);
#define VT40
#define VLEX40
#define CLSR40
#define Vdeb183 363
static L39(int, object, object);
#define VT41
#define VLEX41
#define CLSR41
#define Vdeb184 364
static L40(int, object);
#define VT42
#define VLEX42
#define CLSR42
#define Vdeb185 365
static L41(int, object, object);
#define VT43
#define VLEX43
#define CLSR43
#define Vdeb186 366
static L42(int, object);
#define VT44
#define VLEX44
#define CLSR44
#define Vdeb190 367
static L43(int, object, object);
#define VT45
#define VLEX45
#define CLSR45
#define Vdeb191 368
static L44(int, object);
#define VT46
#define VLEX46
#define CLSR46
#define Vdeb195 369
static L45(int, object, object);
#define VT47
#define VLEX47
#define CLSR47
#define Vdeb196 370
static L46(int, object);
#define VT48
#define VLEX48
#define CLSR48
#define Vdeb197 371
static L47(int, object, object);
#define VT49
#define VLEX49
#define CLSR49
#define Vdeb198 372
static L48(int, object);
#define VT50
#define VLEX50
#define CLSR50
#define Vdeb199 373
static L49(int, object, object);
#define VT51
#define VLEX51
#define CLSR51
#define Vdeb200 374
static L50(int, object);
#define VT52
#define VLEX52
#define CLSR52
#define Vdeb201 375
static L51(int, object, object);
#define VT53
#define VLEX53
#define CLSR53
#define Vdeb202 376
static L52(int, object);
#define VT54
#define VLEX54
#define CLSR54
#define Vdeb206 377
static L53(int, object, object);
#define VT55
#define VLEX55
#define CLSR55
#define Vdeb207 378
static L54(int, object);
#define VT56
#define VLEX56
#define CLSR56
#define Vdeb210 379
static L55(int, object, object, object);
int Lcopy_seq();
#define VT57 object T0;
#define VLEX57
#define CLSR57
#define Vdeb314 380
static L56(int, object);
#define VT58
#define VLEX58
#define CLSR58
#define Vdeb218 381
static L57(int, object, object);
int Lcopy_seq();
#define VT59
#define VLEX59
#define CLSR59
#define Vdeb219 382
static L58(int, object, ...);
#define VT60
#define VLEX60
#define CLSR60
#define Vdeb226 384
static L59(int, object, object);
#define VT61
#define VLEX61
#define CLSR61
#define Vdeb227 388
static L60(int, object);
int Lceiling();
int Lceiling();
#define VT62 object T0;
#define VLEX62
#define CLSR62
#define Vdeb315 396
static L61(int, object);
#define VT63
#define VLEX63
#define CLSR63
#define Vdeb316 398
int siLrem_f();
int Lgensym();
int Lgensym();
int Lgensym();
int Lgensym();
int Lgetf();
int Lgetf();
int Lgensym();
#define VT64 object T0;
#define VLEX64
#define CLSR64
static L63(int, object, object, ...);
int Lash();
int Llogior();
int Lash();
int Lash();
int Llogior();
#define VT65 object T0;
#define VLEX65
#define CLSR65
#define Vdeb242 403
static L64(int, object, object, object);
int Lash();
int Lash();
int Loddp();
#define VT66
#define VLEX66
#define CLSR66
#define Vdeb318 404
static L65(int, ...);
static intUobject L65keys[26]={253,405,406,407,408,409,410,411,412,413,414,415,416,417,418,419,420,421,422,423,424,240,233,425,426,254};
int Lgetf();
#define VT67 object T0;
#define VLEX67
#define CLSR67
#define Vdeb319 429
static L66(int, object, object, ...);
int Lgetf();
int Loddp();
#define VT68 object T0;
#define VLEX68
#define CLSR68
#define Vdeb320 430
static L67(int, object, object);
int Lapply();
#define VT69 object T0;
#define VLEX69
#define CLSR69
#define Vdeb321 431
static L68(int, object);
#define VT70
#define VLEX70
#define CLSR70
#define Vdeb322 432
int Lintern();
#define VT71
#define VLEX71
#define CLSR71
static L70(int, object, object, object, object);
#define VT72
#define VLEX72
#define CLSR72
#define Vdeb282 435
static struct codeblock Cblock;
#define VM72 0
#define VM71 0
#define VM70 0
#define VM69 1
#define VM68 1
#define VM67 1
#define VM66 0
#define VM65 1
#define VM64 1
#define VM63 0
#define VM62 1
#define VM61 0
#define VM60 0
#define VM59 0
#define VM58 0
#define VM57 1
#define VM56 0
#define VM55 0
#define VM54 0
#define VM53 0
#define VM52 0
#define VM51 0
#define VM50 0
#define VM49 0
#define VM48 0
#define VM47 0
#define VM46 0
#define VM45 0
#define VM44 0
#define VM43 0
#define VM42 0
#define VM41 0
#define VM40 0
#define VM39 0
#define VM38 0
#define VM37 0
#define VM36 0
#define VM35 0
#define VM34 0
#define VM33 0
#define VM32 0
#define VM31 0
#define VM30 0
#define VM29 0
#define VM28 0
#define VM27 0
#define VM26 0
#define VM25 0
#define VM24 0
#define VM23 0
#define VM22 0
#define VM21 0
#define VM20 0
#define VM19 0
#define VM18 0
#define VM17 0
#define VM16 0
#define VM15 0
#define VM14 0
#define VM13 0
#define VM12 0
#define VM11 0
#define VM10 0
#define VM9 0
#define VM8 0
#define VM7 0
#define VM6 0
#define VM5 0
#define VM4 0
#define VM3 0
#define VM2 0
#define VM1 436
static object VV[436];
static LKF0(int, ...);
static (*LK0)(int, ...)=LKF0;
static LKF1(int, ...);
static (*LK1)(int, ...)=LKF1;
static LKF2(int, ...);
static (*LK2)(int, ...)=LKF2;
static LKF3(int, ...);
static (*LK3)(int, ...)=LKF3;
static LKF4(int, ...);
static (*LK4)(int, ...)=LKF4;
static LKF5(int, ...);
static (*LK5)(int, ...)=LKF5;
static LKF6(int, ...);
static (*LK6)(int, ...)=LKF6;
static LKF7(int, ...);
static (*LK7)(int, ...)=LKF7;
static LKF8(int, ...);
static (*LK8)(int, ...)=LKF8;
static LKF9(int, ...);
static (*LK9)(int, ...)=LKF9;
static LKF10(int, ...);
static (*LK10)(int, ...)=LKF10;
static LKF11(int, ...);
static (*LK11)(int, ...)=LKF11;
static LKF12(int, ...);
static (*LK12)(int, ...)=LKF12;
static LKF13(int, ...);
static (*LK13)(int, ...)=LKF13;
static LKF14(int, ...);
static (*LK14)(int, ...)=LKF14;
static LKF15(int, ...);
static (*LK15)(int, ...)=LKF15;
static LKF16(int, ...);
static (*LK16)(int, ...)=LKF16;
static LKF17(int, ...);
static (*LK17)(int, ...)=LKF17;
static LKF18(int, ...);
static (*LK18)(int, ...)=LKF18;
static LKF19(int, ...);
static (*LK19)(int, ...)=LKF19;
static LKF20(int, ...);
static (*LK20)(int, ...)=LKF20;
static LKF21(int, ...);
static (*LK21)(int, ...)=LKF21;
static LKF22(int, ...);
static (*LK22)(int, ...)=LKF22;
static LKF23(int, ...);
static (*LK23)(int, ...)=LKF23;
static LKF24(int, ...);
static (*LK24)(int, ...)=LKF24;
static LKF25(int, ...);
static (*LK25)(int, ...)=LKF25;
static LKF26(int, ...);
static (*LK26)(int, ...)=LKF26;
static LKF27(int, ...);
static (*LK27)(int, ...)=LKF27;
static LKF28(int, ...);
static (*LK28)(int, ...)=LKF28;
