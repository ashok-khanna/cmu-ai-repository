
/* (c) Copyright G. Attardi, 1993. All rights reserved. */
#include <ecl.h>
#include "seq.h"
init_seq(int size, object data_stream)
{VT2 CLSR2
	Cblock.cd_start=(char *)init_seq; Cblock.cd_size=size;
	Cblock.cd_data=read_VV(VV,VM1,data_stream);
	funcall(2,symbol_function(VV[14]),VV[0])  /*  PROCLAIM        */;
	MF0key(VV[15],L1,1,L1keys);
	MF0(VV[16],L2);
	MF0(VV[17],L3);
	MF0(VV[18],L6);
	MF0(VV[19],L8);
	MF0(VV[20],L10);
	MF0(VV[21],L11);
}
/*	function definition for MAKE-SEQUENCE                         */
static L1(int narg, object V1, object V2, ...)
{ VT3 VLEX3 CLSR3
	cs_check;
	{int i=2;
	object V3;
	object V4;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[2];
	parse_key(narg,args,1,L1keys,keyvars,OBJNULL,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	}
	{object V5;                               /*  ELEMENT-TYPE    */
	object V6;                                /*  SEQUENCE        */
	V5= Cnil;
	V6= Cnil;
	if(!(((V1))==(VV[1]))){
	goto L7;}
	if(((V4))==Cnil){
	goto L10;}
	RETURN(Lmake_list(3,(V2),VV[2],(V3))      /*  MAKE-LIST       */);
L10:
	RETURN(Lmake_list(1,(V2))                 /*  MAKE-LIST       */);
L7:
	if(((V1))==(VV[3])){
	goto L12;}
	if(!(((V1))==(VV[4]))){
	goto L13;}
L12:
	V5= VV[5];
	goto L5;
L13:
	if(((V1))==(VV[6])){
	goto L17;}
	if(!(((V1))==(VV[7]))){
	goto L18;}
L17:
	V5= VV[8];
	goto L5;
L18:
	if(((V1))==(VV[9])){
	goto L22;}
	if(!(((V1))==(VV[10]))){
	goto L23;}
L22:
	V5= Ct;
	goto L5;
L23:
	(*LK0)(1,(V1))                            /*  NORMALIZE-TYPE  */;
	V1= VALUES(0);
	if(!((car((V1)))==(VV[1]))){
	goto L29;}
	if(((V4))==Cnil){
	goto L33;}
	RETURN(Lmake_list(3,(V2),VV[2],(V3))      /*  MAKE-LIST       */);
L33:
	RETURN(Lmake_list(1,(V2))                 /*  MAKE-LIST       */);
L29:
	if((car((V1)))==(VV[11])){
	goto L35;}
	if((car((V1)))==(VV[12])){
	goto L35;}
	Lerror(2,VV[13],(V1))                     /*  ERROR           */;
L35:
	VALUES(0) = cadr((V1));
	if(VALUES(0)==Cnil)goto L40;
	V5= VALUES(0);
	goto L5;
L40:
	V5= Ct;
L5:
	siLmake_vector(7,(V5),(V2),Cnil,Cnil,Cnil,Cnil,Cnil)/*  MAKE-VECTOR*/;
	V6= VALUES(0);
	if(((V4))==Cnil){
	goto L44;}
	{register int V7;                         /*  I               */
	object V8;                                /*  SIZE            */
	V7= 0;
L49:
	if(!((V7)>=(fix((V2))))){
	goto L50;}
	goto L44;
L50:
	elt_set((V6),V7,(V3));
	V7= (V7)+1;
	goto L49;
	}
L44:
	VALUES(0) = (V6);
	RETURN(1);
	}
	}
}
/*	function definition for CONCATENATE                           */
static L2(int narg, object V1, ...)
{ VT4 VLEX4 CLSR4
	cs_check;
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if(narg<1) FEtoo_few_arguments(&narg);
	narg -= i;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{object V3;                               /*  X               */
	register object V4;                       /*  S               */
	int V5;                                   /*  I               */
	{ int V6, i=0;
	{object V7;
	object V8= (V2);
	if(endp(V8)){
	T0= Cnil;
	goto L59;}
	T1=V7=CONS(Cnil,Cnil);
L60:
	CAR(V7)= MAKE_FIXNUM(length(CAR(V8)));
	if(endp(V8=CDR(V8))){
	T0= T1;
	goto L59;}
	V7=CDR(V7)=CONS(Cnil,Cnil);
	goto L60;}
L59:
	V6=length(T0);
	V6+=i;
	for (; i<V6;i++,T0=CDR(T0))
		VALUES(i)=CAR(T0);
	APPLY(V6,Lplus,&VALUES(0))                /*  +               */;
	}
	L1(2,(V1),VALUES(0))                      /*  MAKE-SEQUENCE   */;
	V3= VALUES(0);
	V5= 0;
	V4= (V2);
L64:
	if(((V4))!=Cnil){
	goto L65;}
	VALUES(0) = (V3);
	RETURN(1);
L65:
	{register int V7;                         /*  J               */
	object V8;                                /*  N               */
	V7= 0;
	V8= MAKE_FIXNUM(length(car((V4))));
L72:
	if(!((V7)>=(fix((V8))))){
	goto L73;}
	goto L68;
L73:
	elt_set((V3),V5,elt(car((V4)),V7));
	V5= (V5)+(1);
	V7= (V7)+1;
	goto L72;
	}
L68:
	V4= cdr((V4));
	goto L64;
	}
	}
}
/*	function definition for MAP                                   */
static L3(int narg, object V1, object V2, object V3, ...)
{ VT5 VLEX5 CLSR5
	cs_check;
	{int i=3;
	register object V4;
	va_list args; va_start(args, V3);
	if(narg<3) FEtoo_few_arguments(&narg);
	narg -= i;
	V4=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V4;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	V4= CONS((V3),(V4));
	{object V5;                               /*  L               */
	{ int V6, i=0;
	{object V7;
	object V8= (V4);
	if(endp(V8)){
	T0= Cnil;
	goto L88;}
	T1=V7=CONS(Cnil,Cnil);
L89:
	CAR(V7)= MAKE_FIXNUM(length(CAR(V8)));
	if(endp(V8=CDR(V8))){
	T0= T1;
	goto L88;}
	V7=CDR(V7)=CONS(Cnil,Cnil);
	goto L89;}
L88:
	V6=length(T0);
	V6+=i;
	for (; i<V6;i++,T0=CDR(T0))
		VALUES(i)=CAR(T0);
	APPLY(V6,Lmin,&VALUES(0))                 /*  MIN             */;
	V5= VALUES(0);
	}
	if(((V1))!=Cnil){
	goto L92;}
	{register int V6;                         /*  I               */
	object V7;                                /*  L               */
	V6= 0;
L96:
	if(!((V6)>=(fix((V5))))){
	goto L97;}
	VALUES(0) = Cnil;
	RETURN(1);
L97:
	T0= (V2);
	{ int V9, i=0;
	{object V10;
	object V11= (V4);
	if(endp(V11)){
	T1= Cnil;
	goto L102;}
	T2=V10=CONS(Cnil,Cnil);
L103:
	{object V12;                              /*  Z               */
	CAR(V10)= elt(CAR(V11),V6);
	}
	if(endp(V11=CDR(V11))){
	T1= T2;
	goto L102;}
	V10=CDR(V10)=CONS(Cnil,Cnil);
	goto L103;}
L102:
	V9=length(T1);
	V9+=i;
	for (; i<V9;i++,T1=CDR(T1))
		VALUES(i)=CAR(T1);
	apply(V9,T0,&VALUES(0));
	}
	V6= (V6)+1;
	goto L96;
	}
L92:
	{object V10;                              /*  X               */
	L1(2,(V1),(V5))                           /*  MAKE-SEQUENCE   */;
	V10= VALUES(0);
	{register int V11;                        /*  I               */
	object V12;                               /*  L               */
	V11= 0;
L111:
	if(!((V11)>=(fix((V5))))){
	goto L112;}
	VALUES(0) = (V10);
	RETURN(1);
L112:
	T1= (V2);
	{ int V14, i=0;
	{object V15;
	object V16= (V4);
	if(endp(V16)){
	T2= Cnil;
	goto L118;}
	T3=V15=CONS(Cnil,Cnil);
L119:
	{object V17;                              /*  Z               */
	CAR(V15)= elt(CAR(V16),V11);
	}
	if(endp(V16=CDR(V16))){
	T2= T3;
	goto L118;}
	V15=CDR(V15)=CONS(Cnil,Cnil);
	goto L119;}
L118:
	V14=length(T2);
	V14+=i;
	for (; i<V14;i++,T2=CDR(T2))
		VALUES(i)=CAR(T2);
	apply(V14,T1,&VALUES(0));
	}
	elt_set((V10),V11,VALUES(0));
	V11= (V11)+1;
	goto L111;
	}
	}
	}
	}
}
/*	function definition for SOME                                  */
static L6(int narg, object V1, object V2, ...)
{ VT6 VLEX6 CLSR6
	cs_check;
	{int i=2;
	register object V3;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	V3=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V3;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	V3= CONS((V2),(V3));
	{register int V4;                         /*  I               */
	object V5;                                /*  L               */
	V4= 0;
	{ int V6, i=0;
	{object V7;
	object V8= (V3);
	if(endp(V8)){
	T0= Cnil;
	goto L128;}
	T1=V7=CONS(Cnil,Cnil);
L129:
	CAR(V7)= MAKE_FIXNUM(length(CAR(V8)));
	if(endp(V8=CDR(V8))){
	T0= T1;
	goto L128;}
	V7=CDR(V7)=CONS(Cnil,Cnil);
	goto L129;}
L128:
	V6=length(T0);
	V6+=i;
	for (; i<V6;i++,T0=CDR(T0))
		VALUES(i)=CAR(T0);
	APPLY(V6,Lmin,&VALUES(0))                 /*  MIN             */;
	V5= VALUES(0);
	}
L132:
	if(!((V4)>=(fix((V5))))){
	goto L133;}
	VALUES(0) = Cnil;
	RETURN(1);
L133:
	{object V7;                               /*  THAT-VALUE      */
	T0= (V1);
	{ int V8, i=0;
	{object V9;
	object V10= (V3);
	if(endp(V10)){
	T1= Cnil;
	goto L139;}
	T2=V9=CONS(Cnil,Cnil);
L140:
	{object V11;                              /*  Z               */
	CAR(V9)= elt(CAR(V10),V4);
	}
	if(endp(V10=CDR(V10))){
	T1= T2;
	goto L139;}
	V9=CDR(V9)=CONS(Cnil,Cnil);
	goto L140;}
L139:
	V8=length(T1);
	V8+=i;
	for (; i<V8;i++,T1=CDR(T1))
		VALUES(i)=CAR(T1);
	apply(V8,T0,&VALUES(0));
	V7= VALUES(0);
	}
	if(((V7))==Cnil){
	goto L136;}
	VALUES(0) = (V7);
	RETURN(1);
	}
L136:
	V4= (V4)+1;
	goto L132;
	}
	}
}
/*	function definition for EVERY                                 */
static L8(int narg, object V1, object V2, ...)
{ VT7 VLEX7 CLSR7
	cs_check;
	{int i=2;
	register object V3;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	V3=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V3;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	V3= CONS((V2),(V3));
	{register int V4;                         /*  I               */
	object V5;                                /*  L               */
	V4= 0;
	{ int V6, i=0;
	{object V7;
	object V8= (V3);
	if(endp(V8)){
	T0= Cnil;
	goto L151;}
	T1=V7=CONS(Cnil,Cnil);
L152:
	CAR(V7)= MAKE_FIXNUM(length(CAR(V8)));
	if(endp(V8=CDR(V8))){
	T0= T1;
	goto L151;}
	V7=CDR(V7)=CONS(Cnil,Cnil);
	goto L152;}
L151:
	V6=length(T0);
	V6+=i;
	for (; i<V6;i++,T0=CDR(T0))
		VALUES(i)=CAR(T0);
	APPLY(V6,Lmin,&VALUES(0))                 /*  MIN             */;
	V5= VALUES(0);
	}
L155:
	if(!((V4)>=(fix((V5))))){
	goto L156;}
	VALUES(0) = Ct;
	RETURN(1);
L156:
	T0= (V1);
	{ int V7, i=0;
	{object V8;
	object V9= (V3);
	if(endp(V9)){
	T1= Cnil;
	goto L163;}
	T2=V8=CONS(Cnil,Cnil);
L164:
	{object V10;                              /*  Z               */
	CAR(V8)= elt(CAR(V9),V4);
	}
	if(endp(V9=CDR(V9))){
	T1= T2;
	goto L163;}
	V8=CDR(V8)=CONS(Cnil,Cnil);
	goto L164;}
L163:
	V7=length(T1);
	V7+=i;
	for (; i<V7;i++,T1=CDR(T1))
		VALUES(i)=CAR(T1);
	apply(V7,T0,&VALUES(0));
	if(VALUES(0)!=Cnil){
	goto L159;}
	}
	VALUES(0) = Cnil;
	RETURN(1);
L159:
	V4= (V4)+1;
	goto L155;
	}
	}
}
/*	function definition for NOTANY                                */
static L10(int narg, object V1, object V2, ...)
{ VT8 VLEX8 CLSR8
	cs_check;
	{int i=2;
	object V3;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	V3=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V3;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{ int V4, i=0;
	T0= (V1);
	T1= (V2);
	T2= (V3);
	V4=length(T2);
	VALUES(i++)=T0;
	VALUES(i++)=T1;
	V4+=i;
	for (; i<V4;i++,T2=CDR(T2))
		VALUES(i)=CAR(T2);
	APPLY(V4,L6,&VALUES(0))                   /*  SOME            */;
	}
	VALUES(0) = ((VALUES(0))==Cnil?Ct:Cnil);
	RETURN(1);
	}
}
/*	function definition for NOTEVERY                              */
static L11(int narg, object V1, object V2, ...)
{ VT9 VLEX9 CLSR9
	cs_check;
	{int i=2;
	object V3;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	V3=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V3;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{ int V4, i=0;
	T0= (V1);
	T1= (V2);
	T2= (V3);
	V4=length(T2);
	VALUES(i++)=T0;
	VALUES(i++)=T1;
	V4+=i;
	for (; i<V4;i++,T2=CDR(T2))
		VALUES(i)=CAR(T2);
	APPLY(V4,L8,&VALUES(0))                   /*  EVERY           */;
	}
	VALUES(0) = ((VALUES(0))==Cnil?Ct:Cnil);
	RETURN(1);
	}
}
static LKF0(int narg, ...) {TRAMPOLINK(VV[22],&LK0);}
