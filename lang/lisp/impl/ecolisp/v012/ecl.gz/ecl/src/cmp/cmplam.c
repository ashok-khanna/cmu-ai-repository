
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "cmplam.h"
init_cmplam(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_cmplam; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	MF0(VV[50],L1);
	MF0(VV[51],L2);
	MF0(VV[52],L3);
	MF0(VV[53],L4);
	MF0(VV[54],L7);
	MF0(VV[55],L10);
	MF0(VV[56],L11);
	MF0(VV[57],L14);
	MF0(VV[58],L15);
}
/*	function definition for C1LAMBDA-EXPR                         */
static L1(int narg, object V1, ...)
{ VT3 VLEX3 CLSR3
	bds_check;
	{int i=1;
	volatile object V2;
	volatile object V3;
	va_list args; va_start(args, V1);
	if (i==narg) goto L1;
	V2= va_arg(args, object);
	V3= Ct;
	i++;
	goto L2;
L1:
	V2= Cnil;
	V3= Cnil;
L2:
	{object V4;                               /*  REQUIREDS       */
	object V5;                                /*  OPTIONALS       */
	object V6;                                /*  REST            */
	object V7;                                /*  KEYWORDS        */
	object V8;                                /*  KEY-FLAG        */
	object V9;                                /*  ALLOW-OTHER-KEYS*/
	object V10;                               /*  AUX-VARS        */
	object V11;                               /*  AUX-INITS       */
	object V12;                               /*  DOC             */
	register object V13;                      /*  SPEC            */
	object V14;                               /*  BODY            */
	register object V15;                      /*  SS              */
	register object V16;                      /*  IS              */
	register object V17;                      /*  TS              */
	object V18;                               /*  OTHER-DECLS     */
	register object V19;                      /*  VNAMES          */
	object V20;                               /*  INFO            */
	object V21;                               /*  AUX-INFO        */
	V4= Cnil;
	V5= Cnil;
	V6= Cnil;
	V7= Cnil;
	V8= Cnil;
	V9= Cnil;
	V10= Cnil;
	V11= Cnil;
	V12= Cnil;
	V13= Cnil;
	V14= Cnil;
	V15= Cnil;
	V16= Cnil;
	V17= Cnil;
	V18= Cnil;
	V19= Cnil;
	bds_bind(VV[0],(VV[0]->s.s_dbind));       /*  *VARS*          */
	(*LK0)(0)                                 /*  MAKE-INFO       */;
	V20= VALUES(0);
	V21= Cnil;
	if(!((V1)==Cnil)){
	goto L22;}
	(*LK1)(2,VV[1],CONS(VV[2],(V1)))          /*  CMPERR          */;
L22:
	{ int V22;
	V22=(*LK2)(2,CDR((V1)),Ct)                /*  C1BODY          */;
	if (V22>0) {
	V14= VALUES(0);
	V22--;
	} else {
	V14= Cnil;}
	if (V22>0) {
	V15= VALUES(1);
	V22--;
	} else {
	V15= Cnil;}
	if (V22>0) {
	V17= VALUES(2);
	V22--;
	} else {
	V17= Cnil;}
	if (V22>0) {
	V16= VALUES(3);
	V22--;
	} else {
	V16= Cnil;}
	if (V22>0) {
	V18= VALUES(4);
	V22--;
	} else {
	V18= Cnil;}
	if (V22>0) {
	V12= VALUES(5);
	} else {
	V12= Cnil;}
	
	}
	if(((V3))==Cnil){
	goto L27;}
	V14= CONS(listA(3,VV[3],(V2),(V14)),Cnil);
L27:
	(*LK3)(1,(V15))                           /*  C1ADD-GLOBALS   */;
	{ int V22;
	V22=L2(1,CAR((V1)))                       /*  PARSE-LAMBDA-LIST*/;
	if (V22>0) {
	V4= VALUES(0);
	V22--;
	} else {
	V4= Cnil;}
	if (V22>0) {
	V5= VALUES(1);
	V22--;
	} else {
	V5= Cnil;}
	if (V22>0) {
	V6= VALUES(2);
	V22--;
	} else {
	V6= Cnil;}
	if (V22>0) {
	V8= VALUES(3);
	V22--;
	} else {
	V8= Cnil;}
	if (V22>0) {
	V7= VALUES(4);
	V22--;
	} else {
	V7= Cnil;}
	if (V22>0) {
	V9= VALUES(5);
	V22--;
	} else {
	V9= Cnil;}
	if (V22>0) {
	V10= VALUES(6);
	} else {
	V10= Cnil;}
	
	}
	{volatile object V22;                     /*  SPECS           */
	V22= (V4);
L36:
	if(((V22))!=Cnil){
	goto L37;}
	goto L34;
L37:
	V13= CAR((V22));
	{object V24;                              /*  V               */
	(*LK4)(4,(V13),(V15),(V16),(V17))         /*  C1MAKE-VAR      */;
	V24= VALUES(0);
	V19= CONS((V13),(V19));
	(VV[0]->s.s_dbind)= CONS((V24),(VV[0]->s.s_dbind));
	{object V25;
	object V26;
	V25= (V22);
	V26= (V24);
	CAR((V25)) = (V26);
	}
	}
	V22= CDR((V22));
	goto L36;
	}
L34:
	{volatile object V22;                     /*  SPECS           */
	V22= (V5);
L56:
	if(((V22))!=Cnil){
	goto L57;}
	goto L54;
L57:
	V13= CAR((V22));
	if(!(type_of((V13))==t_symbol)){
	goto L64;}
	{object V24;                              /*  V               */
	(*LK4)(4,(V13),(V15),(V16),(V17))         /*  C1MAKE-VAR      */;
	V24= VALUES(0);
	V19= CONS((V13),(V19));
	{object V25;
	object V26;
	V25= (V22);
	(*LK5)(1,((V24))->v.v_self[6])            /*  DEFAULT-INIT    */;
	V26= list(3,(V24),VALUES(0),Cnil);
	CAR((V25)) = (V26);
	}
	(VV[0]->s.s_dbind)= CONS((V24),(VV[0]->s.s_dbind));
	goto L62;
	}
L64:
	if(!(type_of(CDR((V13)))==t_symbol)){
	goto L76;}
	if((CDR((V13)))==Cnil){
	goto L78;}
	(*LK1)(2,VV[4],(V13))                     /*  CMPERR          */;
L78:
	{object V25;                              /*  V               */
	(*LK4)(4,CAR((V13)),(V15),(V16),(V17))    /*  C1MAKE-VAR      */;
	V25= VALUES(0);
	V19= CONS(CAR((V13)),(V19));
	{object V26;
	object V27;
	V26= (V22);
	(*LK5)(1,((V25))->v.v_self[6])            /*  DEFAULT-INIT    */;
	V27= list(3,(V25),VALUES(0),Cnil);
	CAR((V26)) = (V27);
	}
	(VV[0]->s.s_dbind)= CONS((V25),(VV[0]->s.s_dbind));
	goto L62;
	}
L76:
	if(!(type_of(CDDR((V13)))==t_symbol)){
	goto L91;}
	if((CDDR((V13)))==Cnil){
	goto L93;}
	(*LK1)(2,VV[4],(V13))                     /*  CMPERR          */;
L93:
	{object V26;                              /*  INIT            */
	object V27;
	object V28;                               /*  V               */
	(*LK6)(2,CADR((V13)),(V20))               /*  C1EXPR*         */;
	V27= VALUES(0);
	(*LK4)(4,CAR((V13)),(V15),(V16),(V17))    /*  C1MAKE-VAR      */;
	V28= VALUES(0);
	V26= V27;
	V19= CONS(CAR((V13)),(V19));
	{object V29;
	object V30;
	V29= (V22);
	(*LK7)(3,((V28))->v.v_self[6],(V26),CADR((V13)))/*  AND-FORM-TYPE*/;
	V30= list(3,(V28),VALUES(0),Cnil);
	CAR((V29)) = (V30);
	}
	(VV[0]->s.s_dbind)= CONS((V28),(VV[0]->s.s_dbind));
	goto L62;
	}
L91:
	if((CDDDR((V13)))==Cnil){
	goto L106;}
	(*LK1)(2,VV[4],(V13))                     /*  CMPERR          */;
L106:
	{object V29;                              /*  INIT            */
	object V30;
	object V31;                               /*  V               */
	object V32;
	object V33;                               /*  SV              */
	(*LK6)(2,CADR((V13)),(V20))               /*  C1EXPR*         */;
	V30= VALUES(0);
	(*LK4)(4,CAR((V13)),(V15),(V16),(V17))    /*  C1MAKE-VAR      */;
	V32= VALUES(0);
	(*LK4)(4,CADDR((V13)),(V15),(V16),(V17))  /*  C1MAKE-VAR      */;
	V33= VALUES(0);
	V29= V30;
	V31= V32;
	V19= CONS(CAR((V13)),(V19));
	V19= CONS(CADDR((V13)),(V19));
	{object V34;
	object V35;
	V34= (V22);
	(*LK7)(3,((V31))->v.v_self[6],(V29),CADR((V13)))/*  AND-FORM-TYPE*/;
	V35= list(3,(V31),VALUES(0),(V33));
	CAR((V34)) = (V35);
	}
	(VV[0]->s.s_dbind)= CONS((V31),(VV[0]->s.s_dbind));
	(VV[0]->s.s_dbind)= CONS((V33),(VV[0]->s.s_dbind));
	}
L62:
	V22= CDR((V22));
	goto L56;
	}
L54:
	if(((V6))==Cnil){
	goto L127;}
	V19= CONS((V6),(V19));
	(*LK4)(4,(V6),(V15),(V16),(V17))          /*  C1MAKE-VAR      */;
	V6= VALUES(0);
	(VV[0]->s.s_dbind)= CONS((V6),(VV[0]->s.s_dbind));
L127:
	{volatile object V22;                     /*  SPECS           */
	V22= (V7);
L137:
	if(((V22))!=Cnil){
	goto L138;}
	goto L135;
L138:
	V13= CAR((V22));
	if((CDDR((V13)))!=Cnil){
	goto L145;}
	if((CDDR((V13)))==Cnil){
	goto L147;}
	(*LK1)(2,VV[4],(V13))                     /*  CMPERR          */;
L147:
	{object V24;                              /*  V               */
	(*LK4)(4,CADR((V13)),(V15),(V16),(V17))   /*  C1MAKE-VAR      */;
	V24= VALUES(0);
	V19= CONS(CADR((V13)),(V19));
	{object V25;
	object V26;
	V25= (V22);
	{object V27= CAR((V13));
	(*LK5)(1,((V24))->v.v_self[6])            /*  DEFAULT-INIT    */;
	T0= VALUES(0);
	(*LK8)(2,VV[5],VV[6])                     /*  MAKE-VAR        */;
	V26= list(4,(V27),(V24),T0,VALUES(0));}
	CAR((V25)) = (V26);
	}
	(VV[0]->s.s_dbind)= CONS((V24),(VV[0]->s.s_dbind));
	goto L143;
	}
L145:
	if((CDDDR((V13)))!=Cnil){
	goto L161;}
	if((CDDDR((V13)))==Cnil){
	goto L163;}
	(*LK1)(2,VV[4],(V13))                     /*  CMPERR          */;
L163:
	{object V25;                              /*  INIT            */
	object V26;
	object V27;                               /*  V               */
	(*LK6)(2,CADDR((V13)),(V20))              /*  C1EXPR*         */;
	V26= VALUES(0);
	(*LK4)(4,CADR((V13)),(V15),(V16),(V17))   /*  C1MAKE-VAR      */;
	V27= VALUES(0);
	V25= V26;
	V19= CONS(CADR((V13)),(V19));
	{object V28;
	object V29;
	V28= (V22);
	{object V30= CAR((V13));
	(*LK7)(3,((V27))->v.v_self[6],(V25),CADDR((V13)))/*  AND-FORM-TYPE*/;
	T0= VALUES(0);
	(*LK8)(2,VV[5],VV[6])                     /*  MAKE-VAR        */;
	V29= list(4,(V30),(V27),T0,VALUES(0));}
	CAR((V28)) = (V29);
	}
	(VV[0]->s.s_dbind)= CONS((V27),(VV[0]->s.s_dbind));
	goto L143;
	}
L161:
	if((CDDDDR((V13)))==Cnil){
	goto L177;}
	(*LK1)(2,VV[4],(V13))                     /*  CMPERR          */;
L177:
	{object V28;                              /*  INIT            */
	object V29;
	object V30;                               /*  V               */
	object V31;
	object V32;                               /*  SV              */
	(*LK6)(2,CADDR((V13)),(V20))              /*  C1EXPR*         */;
	V29= VALUES(0);
	(*LK4)(4,CADR((V13)),(V15),(V16),(V17))   /*  C1MAKE-VAR      */;
	V31= VALUES(0);
	(*LK4)(4,CADDDR((V13)),(V15),(V16),(V17)) /*  C1MAKE-VAR      */;
	V32= VALUES(0);
	V28= V29;
	V30= V31;
	V19= CONS(CADR((V13)),(V19));
	V19= CONS(CADDDR((V13)),(V19));
	{object V33;
	object V34;
	V33= (V22);
	{object V35= CAR((V13));
	(*LK7)(3,((V30))->v.v_self[6],(V28),CADDR((V13)))/*  AND-FORM-TYPE*/;
	V34= list(4,(V35),(V30),VALUES(0),(V32));}
	CAR((V33)) = (V34);
	}
	(VV[0]->s.s_dbind)= CONS((V30),(VV[0]->s.s_dbind));
	(VV[0]->s.s_dbind)= CONS((V32),(VV[0]->s.s_dbind));
	}
L143:
	V22= CDR((V22));
	goto L137;
	}
L135:
	if(((V10))==Cnil){
	goto L198;}
	(*LK0)(0)                                 /*  MAKE-INFO       */;
	V21= VALUES(0);
	{volatile object V22;                     /*  SPECS           */
	V22= (V10);
L205:
	if(((V22))!=Cnil){
	goto L206;}
	goto L203;
L206:
	V13= CAR((V22));
	if(!(type_of((V13))==t_cons)){
	goto L213;}
	if(!(type_of(CDR((V13)))==t_symbol)){
	goto L216;}
	if((CDR((V13)))==Cnil){
	goto L218;}
	(*LK1)(2,VV[4],(V13))                     /*  CMPERR          */;
L218:
	{object V24;                              /*  V               */
	(*LK4)(4,CAR((V13)),(V15),(V16),(V17))    /*  C1MAKE-VAR      */;
	V24= VALUES(0);
	V19= CONS(CAR((V13)),(V19));
	(*LK5)(1,((V24))->v.v_self[6])            /*  DEFAULT-INIT    */;
	V11= CONS(VALUES(0),(V11));
	{object V25;
	object V26;
	V25= (V22);
	V26= (V24);
	CAR((V25)) = (V26);
	}
	(VV[0]->s.s_dbind)= CONS((V24),(VV[0]->s.s_dbind));
	goto L211;
	}
L216:
	if((CDDR((V13)))==Cnil){
	goto L232;}
	(*LK1)(2,VV[4],(V13))                     /*  CMPERR          */;
L232:
	{object V25;                              /*  INIT            */
	object V26;
	object V27;                               /*  V               */
	(*LK6)(2,CADR((V13)),(V21))               /*  C1EXPR*         */;
	V26= VALUES(0);
	(*LK4)(4,CAR((V13)),(V15),(V16),(V17))    /*  C1MAKE-VAR      */;
	V27= VALUES(0);
	V25= V26;
	V19= CONS(CAR((V13)),(V19));
	(*LK7)(3,((V27))->v.v_self[6],(V25),CADR((V13)))/*  AND-FORM-TYPE*/;
	V11= CONS(VALUES(0),(V11));
	{object V28;
	object V29;
	V28= (V22);
	V29= (V27);
	CAR((V28)) = (V29);
	}
	(VV[0]->s.s_dbind)= CONS((V27),(VV[0]->s.s_dbind));
	goto L211;
	}
L213:
	{object V28;                              /*  V               */
	(*LK4)(4,(V13),(V15),(V16),(V17))         /*  C1MAKE-VAR      */;
	V28= VALUES(0);
	V19= CONS((V13),(V19));
	(*LK5)(1,((V28))->v.v_self[6])            /*  DEFAULT-INIT    */;
	V11= CONS(VALUES(0),(V11));
	{object V29;
	object V30;
	V29= (V22);
	V30= (V28);
	CAR((V29)) = (V30);
	}
	(VV[0]->s.s_dbind)= CONS((V28),(VV[0]->s.s_dbind));
	}
L211:
	V22= CDR((V22));
	goto L205;
	}
L203:
	V11= nreverse((V11));
	(*LK9)(2,(V20),(V21))                     /*  ADD-INFO        */;
L198:
	(*LK10)(3,(V19),(V17),(V16))              /*  CHECK-VDECL     */;
	(*LK11)(2,(V18),(V14))                    /*  C1DECL-BODY     */;
	V14= VALUES(0);
	(*LK9)(2,(V20),CADR((V14)))               /*  ADD-INFO        */;
	{volatile object V22;
	volatile object V23;                      /*  VAR             */
	V22= (V4);
	V23= Cnil;
L271:
	if(!((V22)==Cnil)){
	goto L272;}
	goto L267;
L272:
	V23= CAR((V22));
	(*LK12)(1,(V23))                          /*  CHECK-VREF      */;
	V22= CDR((V22));
	goto L271;
	}
L267:
	{volatile object V22;
	volatile object V23;                      /*  OPT             */
	V22= (V5);
	V23= Cnil;
L285:
	if(!((V22)==Cnil)){
	goto L286;}
	goto L281;
L286:
	V23= CAR((V22));
	(*LK12)(1,CAR((V23)))                     /*  CHECK-VREF      */;
	if((CADDR((V23)))==Cnil){
	goto L292;}
	(*LK12)(1,CADDR((V23)))                   /*  CHECK-VREF      */;
L292:
	V22= CDR((V22));
	goto L285;
	}
L281:
	if(((V6))==Cnil){
	goto L298;}
	(*LK12)(1,(V6))                           /*  CHECK-VREF      */;
L298:
	{volatile object V22;
	volatile object V23;                      /*  KWD             */
	V22= (V7);
	V23= Cnil;
L305:
	if(!((V22)==Cnil)){
	goto L306;}
	goto L301;
L306:
	V23= CAR((V22));
	(*LK12)(1,CADR((V23)))                    /*  CHECK-VREF      */;
	if((CADDDR((V23)))==Cnil){
	goto L312;}
	(*LK12)(1,CADDDR((V23)))                  /*  CHECK-VREF      */;
L312:
	V22= CDR((V22));
	goto L305;
	}
L301:
	{volatile object V22;
	volatile object V23;                      /*  VAR             */
	V22= (V10);
	V23= Cnil;
L322:
	if(!((V22)==Cnil)){
	goto L323;}
	goto L318;
L323:
	V23= CAR((V22));
	(*LK12)(1,(V23))                          /*  CHECK-VREF      */;
	V22= CDR((V22));
	goto L322;
	}
L318:
	if(((V10))==Cnil){
	goto L332;}
	(*LK9)(2,(V21),CADR((V14)))               /*  ADD-INFO        */;
	V14= list(5,VV[7],(V21),(V10),(V11),(V14));
L332:
	{int V22;
	VALUES(0)=list(5,VV[2],(V20),list(6,(V4),(V5),(V6),(V8),(V7),(V9)),(V12),(V14));
	V22=1;
	bds_unwind1;
	RETURN(V22);}
	}
	}
}
/*	function definition for PARSE-LAMBDA-LIST                     */
static L2(int narg, object V1)
{ VT4 VLEX4 CLSR4
TTL:
	{register object V2;                      /*  SPEC            */
	register object V3;                       /*  REQUIREDS       */
	register object V4;                       /*  OPTIONALS       */
	object V5;                                /*  REST            */
	object V6;                                /*  KEY-FLAG        */
	register object V7;                       /*  KEYWORDS        */
	object V8;                                /*  ALLOW-OTHER-KEYS*/
	register object V9;                       /*  AUX-VARS        */
	V2= Cnil;
	V3= Cnil;
	V4= Cnil;
	V5= Cnil;
	V6= Cnil;
	V7= Cnil;
	V8= Cnil;
	V9= Cnil;
L347:
	if(((V1))!=Cnil){
	goto L352;}
	goto L345;
L352:
	if(type_of((V1))==t_cons){
	goto L355;}
	(*LK1)(2,VV[8],(V1))                      /*  CMPERR          */;
L355:
	{object V11;
	V11= CAR((V1));
	V1= CDR((V1));
	V2= (V11);
	}
	if(((V2)!= VV[40]))goto L363;
	goto L348;
L363:
	if(((V2)!= VV[39]))goto L364;
	goto L349;
L364:
	if(((V2)!= VV[42]))goto L365;
	goto L350;
L365:
	if(((V2)!= VV[44]))goto L366;
	goto L351;
L366:
	V3= CONS((V2),(V3));
	goto L347;
L348:
	if(((V1))!=Cnil){
	goto L369;}
	goto L345;
L369:
	if(type_of((V1))==t_cons){
	goto L372;}
	(*LK1)(2,VV[8],(V1))                      /*  CMPERR          */;
L372:
	{object V12;
	V12= CAR((V1));
	V1= CDR((V1));
	V2= (V12);
	}
	if(((V2)!= VV[39]))goto L380;
	goto L349;
L380:
	if(((V2)!= VV[42]))goto L381;
	goto L350;
L381:
	if(((V2)!= VV[44]))goto L382;
	goto L351;
L382:
	V4= CONS((V2),(V4));
	goto L348;
L349:
	if(type_of((V1))==t_cons){
	goto L385;}
	(*LK1)(2,VV[8],(V1))                      /*  CMPERR          */;
L385:
	{object V12;
	V12= CAR((V1));
	V1= CDR((V1));
	V5= (V12);
	}
	if(((V1))!=Cnil){
	goto L393;}
	goto L345;
L393:
	if(type_of((V1))==t_cons){
	goto L396;}
	(*LK1)(2,VV[8],(V1))                      /*  CMPERR          */;
L396:
	{object V13;
	V13= CAR((V1));
	V1= CDR((V1));
	V2= (V13);
	}
	if(((V2)!= VV[42]))goto L404;
	goto L350;
L404:
	if(((V2)!= VV[44]))goto L405;
	goto L351;
L405:
	(*LK1)(2,VV[9],(V2))                      /*  CMPERR          */;
L350:
	V6= Ct;
	if(((V1))!=Cnil){
	goto L408;}
	goto L345;
L408:
	if(type_of((V1))==t_cons){
	goto L411;}
	(*LK1)(2,VV[8],(V1))                      /*  CMPERR          */;
L411:
	{object V14;
	V14= CAR((V1));
	V1= CDR((V1));
	V2= (V14);
	}
	if(((V2)!= VV[44]))goto L419;
	goto L351;
L419:
	if(((V2)!= VV[43]))goto L420;
	V8= Ct;
	if(((V1))!=Cnil){
	goto L423;}
	goto L345;
L423:
	if(type_of((V1))==t_cons){
	goto L426;}
	(*LK1)(2,VV[8],(V1))                      /*  CMPERR          */;
L426:
	{object V14;
	V14= CAR((V1));
	V1= CDR((V1));
	V2= (V14);
	}
	if(((V2)!= VV[44]))goto L434;
	goto L351;
L434:
	(*LK1)(2,VV[10],(V2))                     /*  CMPERR          */;
	goto L414;
L420:
L414:
	if(type_of((V2))==t_cons){
	goto L435;}
	V2= CONS((V2),Cnil);
L435:
	if(!(type_of(CAR((V2)))==t_cons)){
	goto L441;}
	{object V14= CAAR((V2));
	if(!((type_of(V14)==t_symbol&&(V14)->s.s_hpack==keyword_package))){
	goto L444;}}
	if(!(type_of(CDAR((V2)))==t_cons)){
	goto L444;}
	if((CDDAR((V2)))==Cnil){
	goto L443;}
L444:
	(*LK1)(2,VV[4],(V2))                      /*  CMPERR          */;
L443:
	V2= listA(3,CAAR((V2)),CADAR((V2)),CDR((V2)));
	goto L439;
L441:
	if(type_of(CAR((V2)))==t_symbol){
	goto L451;}
	(*LK1)(2,VV[4],(V2))                      /*  CMPERR          */;
L451:
	Lintern(2,coerce_to_string(CAR((V2))),VV[11])/*  INTERN       */;
	T0= VALUES(0);
	V2= listA(3,T0,CAR((V2)),CDR((V2)));
L439:
	V7= CONS((V2),(V7));
	goto L350;
L351:
	if(((V1))!=Cnil){
	goto L458;}
	goto L345;
L458:
	if(type_of((V1))==t_cons){
	goto L461;}
	(*LK1)(2,VV[8],(V1))                      /*  CMPERR          */;
L461:
	{object V15;
	V15= CAR((V1));
	V1= CDR((V1));
	VALUES(0) = (V15);
	}
	V9= CONS(VALUES(0),(V9));
	goto L351;
L345:
	{object V10= nreverse((V3));
	{object V11= nreverse((V4));
	{object V12= nreverse((V7));
	VALUES(6) = nreverse((V9));
	VALUES(5) = (V8);
	VALUES(4) = (V12);
	VALUES(3) = (V6);
	VALUES(2) = (V5);
	VALUES(1) = (V11);
	VALUES(0) = (V10);
	RETURN(7);}}}
	}
}
/*	function definition for C2LAMBDA-EXPR                         */
static L3(int narg, object V1, object V2, object V3, object V4, ...)
{ VT5 VLEX5 CLSR5
	bds_check;
	{int i=4;
	volatile object V5;
	volatile object V6;
	va_list args; va_start(args, V4);
	if (i==narg) goto L471;
	V5= va_arg(args, object);
	i++;
	if (i==narg) goto L472;
	V6= va_arg(args, object);
	i++;
	goto L473;
L471:
	V5= Cnil;
L472:
	V6= Cnil;
L473:
	{volatile object V7;
	if((V4)==Cnil){
	V7= Cnil;
	goto L476;}
	if(type_of((V4))==t_symbol){
	goto L477;}
	V7= Cnil;
	goto L476;
L477:
	{volatile object V8;
	volatile object V9;                       /*  VAR             */
	V8= CAR((V1));
	V9= Cnil;
L484:
	if(!((V8)==Cnil)){
	goto L485;}
	goto L479;
L485:
	V9= CAR((V8));
	if((((V9))->v.v_self[2])==Cnil){
	goto L490;}
	goto L480;
L490:
	V8= CDR((V8));
	goto L484;
	}
L480:
	V7= Cnil;
	goto L476;
L479:
	if(CADR((V1))==Cnil){
	goto L496;}
	V7= Cnil;
	goto L476;
L496:
	if(CADDR((V1))==Cnil){
	goto L498;}
	V7= Cnil;
	goto L476;
L498:
	if(CADDDR((V1))==Cnil){
	goto L500;}
	V7= Cnil;
	goto L476;
L500:
	V7= CONS((V4),CAR((V1)));
L476:
	bds_bind(VV[12],V7);                      /*  *TAIL-RECURSION-INFO**/
	if((CADDDR((V1)))==Cnil){
	goto L503;}
	{int V8;
	V8=L7(5,(V1),(V2),(V5),(V6),(V3))         /*  C2LAMBDA-EXPR-WITH-KEY*/;
	bds_unwind1;
	RETURN(V8);}
L503:
	{int V9;
	V9=L4(4,(V1),(V2),(V5),(V6))              /*  C2LAMBDA-EXPR-WITHOUT-KEY*/;
	bds_unwind1;
	RETURN(V9);}
	}
	}
}
/*	function definition for C2LAMBDA-EXPR-WITHOUT-KEY             */
static L4(int narg, object V1, object V2, object V3, object V4)
{ VT6 VLEX6 CLSR6
	bds_check;
TTL:
	{object V5;                               /*  REQUIREDS       */
	object V6;                                /*  OPTIONALS       */
	object V7;                                /*  REST            */
	object V8;                                /*  REST-LOC        */
	register int V9;                          /*  NREQ            */
	register object V10;                      /*  LABELS          */
	V5= CAR((V1));
	V6= CADR((V1));
	V7= CADDR((V1));
	V8= Cnil;
	V9= length((V5));
	V10= Cnil;
	bds_bind(VV[13],(VV[13]->s.s_dbind));     /*  *UNWIND-EXIT*   */
	bds_bind(VV[14],(VV[14]->s.s_dbind));     /*  *ENV*           */
	lex0[0]=Cnil;                             /*  BLOCK-P         */
	if(!((VV[15])==((V4)))){
	goto L513;}
	{volatile object V11;                     /*  REQS            */
	volatile int V12;                         /*  REQI            */
	volatile object V13;                      /*  LCL_I           */
	V12= fix(one_plus((VV[16]->s.s_dbind)));
	V13= list(2,VV[17],MAKE_FIXNUM(0));
	V11= (V5);
L518:
	if(!((V11)==Cnil)){
	goto L519;}
	(VV[16]->s.s_dbind)= MAKE_FIXNUM(V12);
	goto L511;
L519:
	if(!(((CAR((V11)))->v.v_self[4])==(VV[18]))){
	goto L525;}
	{object V15;
	register int V16;
	V15= (V13);
	V16= V12;
	CAR(CDR((V15))) = MAKE_FIXNUM(V16);
	}
	(*LK13)(2,(V13),CAR((V11)))               /*  BIND            */;
	goto L523;
L525:
	elt_set(CAR((V11)),5,MAKE_FIXNUM(V12));
L523:
	V11= CDR((V11));
	V12= (V12)+1;
	goto L518;
	}
L513:
	{volatile object V15;                     /*  REQ0            */
	if(!((VV[19])==((V4)))){
	goto L537;}
	V15= number_minus((VV[16]->s.s_dbind),MAKE_FIXNUM(V9));
	goto L535;
L537:
	V15= (VV[16]->s.s_dbind);
L535:
	lex0[1]=number_plus((V15),MAKE_FIXNUM(V9));/*  LCL            */
	{volatile object V16;                     /*  REQS            */
	volatile int V17;                         /*  REQI            */
	volatile object V18;                      /*  VAR             */
	V17= fix(one_plus((V15)));
	V16= (V5);
	V18= Cnil;
L544:
	if(!((V16)==Cnil)){
	goto L545;}
	goto L541;
L545:
	V18= CAR((V16));
	(*LK14)(1,(V18))                          /*  UNBOXED         */;
	if(VALUES(0)==Cnil){
	goto L550;}
	LC5(lex0,1,(V18))                         /*  WT-DECL         */;
	elt_set((V18),5,VALUES(0));
L550:
	V16= CDR((V16));
	V17= (V17)+1;
	goto L544;
	}
L541:
	if(((V7))==Cnil){
	goto L558;}
	if(!(number_compare(((V7))->v.v_self[1],MAKE_FIXNUM(1))<0)){
	goto L558;}
	V7= Cnil;
L558:
	if(((V6))==Cnil){
	goto L564;}
	if((lex0[0])!=Cnil){
	goto L567;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_char(123,symbol_value(VV[20]));
	lex0[0]= Ct;
L567:
	princ_str("int i=",symbol_value(VV[20]));
	if(!((VV[19])==((V4)))){
	goto L579;}
	VALUES(0) = MAKE_FIXNUM(0);
	goto L577;
L579:
	VALUES(0) = MAKE_FIXNUM(V9);
L577:
	(*LK15)(1,VALUES(0))                      /*  WT1             */;
	princ_char(59,symbol_value(VV[20]));
L564:
	{volatile object V16;
	volatile object V17;                      /*  OPT             */
	V16= (V6);
	V17= Cnil;
L586:
	if(!((V16)==Cnil)){
	goto L587;}
	goto L582;
L587:
	V17= CAR((V16));
	LC6(lex0,1,CAR((V17)))                    /*  DO-DECL         */;
	if((CADDR((V17)))==Cnil){
	goto L593;}
	LC6(lex0,1,CADDR((V17)))                  /*  DO-DECL         */;
L593:
	V16= CDR((V16));
	goto L586;
	}
L582:
	if(((V7))==Cnil){
	goto L540;}
	LC5(lex0,1,(V7))                          /*  WT-DECL         */;
	V8= list(2,VV[17],VALUES(0));
L540:
	if((VV[19])==((V4))){
	goto L603;}
	if(((V6))!=Cnil){
	goto L606;}
	if(((V7))==Cnil){
	goto L603;}
L606:
	if((lex0[0])!=Cnil){
	goto L610;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_char(123,symbol_value(VV[20]));
	lex0[0]= Ct;
L610:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("va_list args; va_start(args, ",symbol_value(VV[20]));
	if(!((V9)>0)){
	goto L624;}
	(*LK16)(1,number_plus((V15),MAKE_FIXNUM(V9)))/*  WT-LCL       */;
	goto L622;
L624:
	if(((V3))==Cnil){
	goto L627;}
	princ_str("env0",symbol_value(VV[20]));
	goto L622;
L627:
	princ_str("narg",symbol_value(VV[20]));
L622:
	princ_str(");",symbol_value(VV[20]));
L603:
	if(((VV[22]->s.s_dbind))!=Cnil){
	goto L633;}
	if(((VV[23]->s.s_dbind))==Cnil){
	goto L632;}
L633:
	if((CADDR((V1)))!=Cnil){
	goto L637;}
	if(((V6))==Cnil){
	goto L638;}
L637:
	if(((V5))==Cnil){
	goto L642;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("if(narg<",symbol_value(VV[20]));
	(*LK15)(1,MAKE_FIXNUM(V9))                /*  WT1             */;
	princ_str(") FEtoo_few_arguments(&narg);",symbol_value(VV[20]));
L642:
	if((CADDR((V1)))!=Cnil){
	goto L632;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("if(narg>",symbol_value(VV[20]));
	(*LK15)(1,number_plus(MAKE_FIXNUM(V9),MAKE_FIXNUM(length((V6)))))/*  WT1*/;
	princ_str(") FEtoo_many_arguments(&narg);",symbol_value(VV[20]));
	goto L632;
L638:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("check_arg(",symbol_value(VV[20]));
	(*LK15)(1,MAKE_FIXNUM(V9))                /*  WT1             */;
	princ_str(");",symbol_value(VV[20]));
L632:
	{volatile object V16;                     /*  REQS            */
	volatile int V17;                         /*  REQI            */
	volatile object V18;                      /*  LCL_I           */
	V17= fix(one_plus((V15)));
	V18= list(2,VV[17],MAKE_FIXNUM(0));
	V16= (V5);
L666:
	if(!((V16)==Cnil)){
	goto L667;}
	goto L662;
L667:
	{object V20;
	register int V21;
	V20= (V18);
	V21= V17;
	CAR(CDR((V20))) = MAKE_FIXNUM(V21);
	}
	(*LK13)(2,(V18),CAR((V16)))               /*  BIND            */;
	V16= CDR((V16));
	V17= (V17)+1;
	goto L666;
	}
L662:
	(VV[16]->s.s_dbind)= lex0[1];
	}
L511:
	if(((V6))==Cnil){
	goto L680;}
	{volatile object V11;                     /*  VA-ARG-LOC      */
	V11= list(2,VV[24],(((V4))==(VV[19])?Ct:Cnil));
	{volatile object V12;
	volatile object V13;                      /*  OPT             */
	V12= (V6);
	V13= Cnil;
L688:
	if(!((V12)==Cnil)){
	goto L689;}
	goto L683;
L689:
	V13= CAR((V12));
	(VV[25]->s.s_dbind)= number_plus((VV[25]->s.s_dbind),MAKE_FIXNUM(1));
	V10= CONS(CONS((VV[25]->s.s_dbind),Cnil),(V10));
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("if (i==narg) ",symbol_value(VV[20]));
	CDR(CAR((V10))) = Ct;
	princ_str("goto L",symbol_value(VV[20]));
	(*LK15)(1,CAR(CAR((V10))))                /*  WT1             */;
	princ_char(59,symbol_value(VV[20]));
	(*LK13)(2,(V11),CAR((V13)))               /*  BIND            */;
	if((CADDR((V13)))==Cnil){
	goto L707;}
	(*LK13)(2,Ct,CADDR((V13)))                /*  BIND            */;
L707:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("i++;",symbol_value(VV[20]));
	V12= CDR((V12));
	goto L688;
	}
	}
L683:
	{volatile object V11;                     /*  LABEL           */
	(VV[25]->s.s_dbind)= number_plus((VV[25]->s.s_dbind),MAKE_FIXNUM(1));
	V11= CONS((VV[25]->s.s_dbind),Cnil);
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	CDR((V11)) = Ct;
	princ_str("goto L",symbol_value(VV[20]));
	(*LK15)(1,CAR((V11)))                     /*  WT1             */;
	princ_char(59,symbol_value(VV[20]));
	V10= nreverse((V10));
	{volatile object V12;
	volatile object V13;                      /*  OPT             */
	V12= (V6);
	V13= Cnil;
L733:
	if(!((V12)==Cnil)){
	goto L734;}
	goto L729;
L734:
	V13= CAR((V12));
	if((CDR(CAR((V10))))==Cnil){
	goto L739;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	princ_char(76,symbol_value(VV[20]));
	(*LK15)(1,CAR(CAR((V10))))                /*  WT1             */;
	princ_char(58,symbol_value(VV[20]));
L739:
	{object V15;
	V15= CAR((V10));
	V10= CDR((V10));
	}
	(*LK17)(3,CAR((V13)),CADR((V13)),Ct)      /*  BIND-INIT       */;
	if((CADDR((V13)))==Cnil){
	goto L751;}
	(*LK13)(3,Cnil,CADDR((V13)),Ct)           /*  BIND            */;
L751:
	V12= CDR((V12));
	goto L733;
	}
L729:
	if((CDR((V11)))==Cnil){
	goto L680;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	princ_char(76,symbol_value(VV[20]));
	(*LK15)(1,CAR((V11)))                     /*  WT1             */;
	princ_char(58,symbol_value(VV[20]));
	}
L680:
	if(((V7))==Cnil){
	goto L763;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("narg -=",symbol_value(VV[20]));
	(*LK15)(1,number_plus(MAKE_FIXNUM(V9),MAKE_FIXNUM(length((V6)))))/*  WT1*/;
	princ_char(59,symbol_value(VV[20]));
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	(*LK15)(1,(V8))                           /*  WT1             */;
	if(!((((V7))->v.v_self[6])==(VV[26]))){
	goto L778;}
	princ_str("=(ALLOCA_CONS(narg),ON_STACK_MAKE_LIST(narg));",symbol_value(VV[20]));
	goto L776;
L778:
	princ_str("=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));",symbol_value(VV[20]));
L776:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("{ object p=",symbol_value(VV[20]));
	(*LK15)(1,(V8))                           /*  WT1             */;
	princ_char(59,symbol_value(VV[20]));
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str(" for(;narg-->0;p=CDR(p))",symbol_value(VV[20]));
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("   CAR(p)=",symbol_value(VV[20]));
	(*LK18)(1,((VV[19])==((V4))?Ct:Cnil))     /*  WT-VA_ARG       */;
	princ_str(";}",symbol_value(VV[20]));
	(*LK13)(2,(V8),(V7))                      /*  BIND            */;
L763:
	if(((VV[12]->s.s_dbind))==Cnil){
	goto L799;}
	(VV[13]->s.s_dbind)= CONS(VV[27],(VV[13]->s.s_dbind));
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	princ_str("TTL:",symbol_value(VV[20]));
L799:
	(*LK19)(1,(V2))                           /*  C2EXPR          */;
	if((lex0[0])==Cnil){
	goto L808;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_char(125,symbol_value(VV[20]));
	{int V11;
	VALUES(0)=Cnil;
	V11=1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V11);}
L808:
	{int V12;
	VALUES(0)=Cnil;
	V12=1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V12);}
	}
}
/*	local function DO-DECL                                        */
static LC6(object *lex0,int narg, object V1)
{ VT7 VLEX7 CLSR7
TTL:
	(*LK20)(1,(V1))                           /*  LOCAL           */;
	if(VALUES(0)==Cnil){
	goto L814;}
	LC5(lex0,1,(V1))                          /*  WT-DECL         */;
	VALUES(0) = elt_set((V1),5,VALUES(0));
	RETURN(1);
L814:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	local function WT-DECL                                        */
static LC5(object *lex0,int narg, object V1)
{ VT8 VLEX8 CLSR8
TTL:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	if((lex0[0])!=Cnil){
	goto L820;}
	princ_char(123,symbol_value(VV[20]));
	lex0[0]= Ct;
L820:
	(*LK15)(1,(VV[21]->s.s_dbind))            /*  WT1             */;
	(*LK21)(1,(V1))                           /*  REGISTER        */;
	(*LK15)(1,VALUES(0))                      /*  WT1             */;
	(*LK22)(1,((V1))->v.v_self[4])            /*  REP-TYPE        */;
	(*LK15)(1,VALUES(0))                      /*  WT1             */;
	lex0[1]= MAKE_FIXNUM((fix(lex0[1]))+(1));
	(*LK16)(1,lex0[1])                        /*  WT-LCL          */;
	princ_char(59,symbol_value(VV[20]));
	VALUES(0) = lex0[1];
	RETURN(1);
}
/*	function definition for C2LAMBDA-EXPR-WITH-KEY                */
static L7(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT9 VLEX9 CLSR9
	bds_check;
TTL:
	{object V6;                               /*  REQUIREDS       */
	object V7;                                /*  OPTIONALS       */
	object V8;                                /*  REST            */
	object V9;                                /*  REST-LOC        */
	object V10;                               /*  KEY-FLAG        */
	object V11;                               /*  KEYWORDS        */
	object V12;                               /*  ALLOW-OTHER-KEYS*/
	int V13;                                  /*  NREQ            */
	register int V14;                         /*  NKEY            */
	register object V15;                      /*  LABELS          */
	object V16;                               /*  LAST-ARG        */
	V6= CAR((V1));
	V7= CADR((V1));
	V8= CADDR((V1));
	V9= Cnil;
	V10= CADDDR((V1));
	Lfifth(1,(V1))                            /*  FIFTH           */;
	V11= VALUES(0);
	Lsixth(1,(V1))                            /*  SIXTH           */;
	V12= VALUES(0);
	V13= length((V6));
	V14= length((V11));
	V15= Cnil;
	bds_bind(VV[13],(VV[13]->s.s_dbind));     /*  *UNWIND-EXIT*   */
	bds_bind(VV[14],(VV[14]->s.s_dbind));     /*  *ENV*           */
	lex0[0]=Cnil;                             /*  BLOCK-P         */
	V16= Cnil;
	{volatile object V17;                     /*  REQ0            */
	if(((V4))==Cnil){
	goto L850;}
	V17= number_minus((VV[16]->s.s_dbind),MAKE_FIXNUM(V13));
	goto L848;
L850:
	V17= (VV[16]->s.s_dbind);
L848:
	lex0[1]=number_plus((V17),MAKE_FIXNUM(V13));/*  LCL           */
	{volatile object V18;                     /*  REQS            */
	volatile int V19;                         /*  REQI            */
	volatile object V20;                      /*  VAR             */
	V19= fix(one_plus((V17)));
	V18= (V6);
	V20= Cnil;
L857:
	if(!((V18)==Cnil)){
	goto L858;}
	goto L854;
L858:
	V20= CAR((V18));
	(*LK14)(1,(V20))                          /*  UNBOXED         */;
	if(VALUES(0)==Cnil){
	goto L863;}
	LC8(lex0,1,(V20))                         /*  WT-DECL         */;
	elt_set((V20),5,VALUES(0));
L863:
	V18= CDR((V18));
	V19= (V19)+1;
	goto L857;
	}
L854:
	if(((V8))==Cnil){
	goto L871;}
	if(!(number_compare(((V8))->v.v_self[1],MAKE_FIXNUM(1))<0)){
	goto L871;}
	V8= Cnil;
L871:
	if(((V7))==Cnil){
	goto L877;}
	if((lex0[0])!=Cnil){
	goto L880;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_char(123,symbol_value(VV[20]));
	lex0[0]= Ct;
L880:
	princ_str("int i=",symbol_value(VV[20]));
	if(((V4))==Cnil){
	goto L892;}
	VALUES(0) = MAKE_FIXNUM(0);
	goto L890;
L892:
	VALUES(0) = MAKE_FIXNUM(V13);
L890:
	(*LK15)(1,VALUES(0))                      /*  WT1             */;
	princ_char(59,symbol_value(VV[20]));
L877:
	{volatile object V18;
	volatile object V19;                      /*  OPT             */
	V18= (V7);
	V19= Cnil;
L899:
	if(!((V18)==Cnil)){
	goto L900;}
	goto L895;
L900:
	V19= CAR((V18));
	LC9(lex0,1,CAR((V19)))                    /*  DO-DECL         */;
	if((CADDR((V19)))==Cnil){
	goto L906;}
	LC9(lex0,1,CADDR((V19)))                  /*  DO-DECL         */;
L906:
	V18= CDR((V18));
	goto L899;
	}
L895:
	if(((V8))==Cnil){
	goto L912;}
	LC8(lex0,1,(V8))                          /*  WT-DECL         */;
	V9= list(2,VV[17],VALUES(0));
L912:
	{volatile object V18;
	volatile object V19;                      /*  KEY             */
	V18= (V11);
	V19= Cnil;
L920:
	if(!((V18)==Cnil)){
	goto L921;}
	goto L853;
L921:
	V19= CAR((V18));
	LC9(lex0,1,CADR((V19)))                   /*  DO-DECL         */;
	if((CADDDR((V19)))==Cnil){
	goto L927;}
	LC9(lex0,1,CADDDR((V19)))                 /*  DO-DECL         */;
L927:
	V18= CDR((V18));
	goto L920;
	}
L853:
	if(((V4))!=Cnil){
	goto L933;}
	if((lex0[0])!=Cnil){
	goto L936;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_char(123,symbol_value(VV[20]));
	lex0[0]= Ct;
L936:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("va_list args; va_start(args, ",symbol_value(VV[20]));
	if(!((V13)>0)){
	goto L952;}
	Lformat(3,Cnil,VV[28],number_plus((V17),MAKE_FIXNUM(V13)))/*  FORMAT*/;
	V16= VALUES(0);
	goto L950;
L952:
	if(((V3))==Cnil){
	goto L955;}
	V16= VV[29];
	goto L950;
L955:
	V16= VV[30];
L950:
	(*LK15)(1,(V16))                          /*  WT1             */;
	princ_str(");",symbol_value(VV[20]));
L933:
	if(((VV[22]->s.s_dbind))!=Cnil){
	goto L960;}
	if(((VV[23]->s.s_dbind))==Cnil){
	goto L958;}
L960:
	if(((V6))==Cnil){
	goto L958;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("if(narg<",symbol_value(VV[20]));
	(*LK15)(1,MAKE_FIXNUM(V13))               /*  WT1             */;
	princ_str(") FEtoo_few_arguments(&narg);",symbol_value(VV[20]));
L958:
	{volatile object V18;                     /*  REQS            */
	volatile int V19;                         /*  REQI            */
	volatile object V20;                      /*  LCL_I           */
	V19= fix(one_plus((V17)));
	V20= list(2,VV[17],MAKE_FIXNUM(0));
	V18= (V6);
L974:
	if(!((V18)==Cnil)){
	goto L975;}
	goto L970;
L975:
	{object V22;
	register int V23;
	V22= (V20);
	V23= V19;
	CAR(CDR((V22))) = MAKE_FIXNUM(V23);
	}
	(*LK13)(2,(V20),CAR((V18)))               /*  BIND            */;
	V18= CDR((V18));
	V19= (V19)+1;
	goto L974;
	}
L970:
	(VV[16]->s.s_dbind)= lex0[1];
	}
	if(((V7))==Cnil){
	goto L988;}
	{volatile object V17;                     /*  VA-ARG-LOC      */
	V17= list(2,VV[24],(V4));
	{volatile object V18;
	volatile object V19;                      /*  OPT             */
	V18= (V7);
	V19= Cnil;
L996:
	if(!((V18)==Cnil)){
	goto L997;}
	goto L991;
L997:
	V19= CAR((V18));
	(VV[25]->s.s_dbind)= number_plus((VV[25]->s.s_dbind),MAKE_FIXNUM(1));
	V15= CONS(CONS((VV[25]->s.s_dbind),Cnil),(V15));
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("if (i==narg) ",symbol_value(VV[20]));
	CDR(CAR((V15))) = Ct;
	princ_str("goto L",symbol_value(VV[20]));
	(*LK15)(1,CAR(CAR((V15))))                /*  WT1             */;
	princ_char(59,symbol_value(VV[20]));
	(*LK13)(2,(V17),CAR((V19)))               /*  BIND            */;
	if((CADDR((V19)))==Cnil){
	goto L1015;}
	(*LK13)(2,Ct,CADDR((V19)))                /*  BIND            */;
L1015:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("i++;",symbol_value(VV[20]));
	V18= CDR((V18));
	goto L996;
	}
	}
L991:
	{volatile object V17;                     /*  LABEL           */
	(VV[25]->s.s_dbind)= number_plus((VV[25]->s.s_dbind),MAKE_FIXNUM(1));
	V17= CONS((VV[25]->s.s_dbind),Cnil);
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	CDR((V17)) = Ct;
	princ_str("goto L",symbol_value(VV[20]));
	(*LK15)(1,CAR((V17)))                     /*  WT1             */;
	princ_char(59,symbol_value(VV[20]));
	V15= nreverse((V15));
	{volatile object V18;
	volatile object V19;                      /*  OPT             */
	V18= (V7);
	V19= Cnil;
L1041:
	if(!((V18)==Cnil)){
	goto L1042;}
	goto L1037;
L1042:
	V19= CAR((V18));
	if((CDR(CAR((V15))))==Cnil){
	goto L1047;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	princ_char(76,symbol_value(VV[20]));
	(*LK15)(1,CAR(CAR((V15))))                /*  WT1             */;
	princ_char(58,symbol_value(VV[20]));
L1047:
	{object V21;
	V21= CAR((V15));
	V15= CDR((V15));
	}
	(*LK17)(3,CAR((V19)),CADR((V19)),Ct)      /*  BIND-INIT       */;
	if((CADDR((V19)))==Cnil){
	goto L1059;}
	(*LK13)(3,Cnil,CADDR((V19)),Ct)           /*  BIND            */;
L1059:
	V18= CDR((V18));
	goto L1041;
	}
L1037:
	if((CDR((V17)))==Cnil){
	goto L988;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	princ_char(76,symbol_value(VV[20]));
	(*LK15)(1,CAR((V17)))                     /*  WT1             */;
	princ_char(58,symbol_value(VV[20]));
	}
L988:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("narg -=",symbol_value(VV[20]));
	(*LK15)(1,number_plus(MAKE_FIXNUM(V13),MAKE_FIXNUM(length((V7)))))/*  WT1*/;
	princ_char(59,symbol_value(VV[20]));
	if(((V8))==Cnil){
	goto L1077;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	(*LK15)(1,(V9))                           /*  WT1             */;
	if(!((((V8))->v.v_self[6])==(VV[26]))){
	goto L1086;}
	princ_str("=(ALLOCA_CONS(narg), ON_STACK_MAKE_LIST(narg));",symbol_value(VV[20]));
	goto L1084;
L1086:
	princ_str("=(Lmake_list(1, MAKE_FIXNUM(narg)), VALUES(0));",symbol_value(VV[20]));
L1084:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("{ int n=narg; object p=",symbol_value(VV[20]));
	(*LK15)(1,(V9))                           /*  WT1             */;
	princ_char(59,symbol_value(VV[20]));
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str(" for(;n-->0;p=CDR(p))",symbol_value(VV[20]));
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("   CAR(p)=",symbol_value(VV[20]));
	(*LK18)(1,(V4))                           /*  WT-VA_ARG       */;
	princ_str(";}",symbol_value(VV[20]));
	(*LK13)(2,(V9),(V8))                      /*  BIND            */;
L1077:
	princ_char(10,symbol_value(VV[31]));
	princ_str("static intUobject L",symbol_value(VV[31]));
	(*LK23)(1,(V5))                           /*  WT-H1           */;
	princ_str("keys[",symbol_value(VV[31]));
	(*LK23)(1,MAKE_FIXNUM(length((V11))))     /*  WT-H1           */;
	princ_str("]={",symbol_value(VV[31]));
	{volatile object V17;                     /*  KWDS            */
	V17= (V11);
L1116:
	if(((V17))!=Cnil){
	goto L1117;}
	princ_str("};",symbol_value(VV[31]));
	goto L1114;
L1117:
	(*LK24)(1,CAAR((V17)))                    /*  ADD-SYMBOL      */;
	princ(VALUES(0),(VV[31]->s.s_dbind));
	if((CDR((V17)))==Cnil){
	goto L1122;}
	princ_char(44,symbol_value(VV[31]));
L1122:
	V17= CDR((V17));
	goto L1116;
	}
L1114:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("{ object keyvars[",symbol_value(VV[20]));
	(*LK15)(1,fixnum_times(2,V14))            /*  WT1             */;
	princ_str("];",symbol_value(VV[20]));
	if(((V8))==Cnil){
	goto L1134;}
	if(((V4))==Cnil){
	goto L1138;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("args -= narg;",symbol_value(VV[20]));
	goto L1134;
L1138:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("va_start(args,",symbol_value(VV[20]));
	(*LK15)(1,(V16))                          /*  WT1             */;
	princ_str(");",symbol_value(VV[20]));
L1134:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("parse_key(narg,args,",symbol_value(VV[20]));
	(*LK15)(1,MAKE_FIXNUM(length((V11))))     /*  WT1             */;
	princ_str(",L",symbol_value(VV[20]));
	(*LK15)(1,(V5))                           /*  WT1             */;
	princ_str("keys,keyvars,",symbol_value(VV[20]));
	if(((V8))==Cnil){
	goto L1158;}
	(*LK15)(1,(V9))                           /*  WT1             */;
	goto L1156;
L1158:
	princ_str("OBJNULL",symbol_value(VV[20]));
L1156:
	if(((V12))==Cnil){
	goto L1166;}
	VALUES(0) = VV[32];
	goto L1164;
L1166:
	VALUES(0) = VV[33];
L1164:
	(*LK15)(1,VALUES(0))                      /*  WT1             */;
	{volatile object V17;                     /*  KEYVARS[I]      */
	volatile int V18;                         /*  I               */
	V18= 0;
	V17= VV[34];
	{volatile object V19;
	volatile object V20;                      /*  KWD             */
	V19= (V11);
	V20= Cnil;
L1173:
	if(!((V19)==Cnil)){
	goto L1174;}
	goto L1168;
L1174:
	V20= CAR((V19));
	if(!((CAR(CADDR((V20))))==(VV[35]))){
	goto L1181;}
	if((CADDR(CADDR((V20))))!=Cnil){
	goto L1181;}
	{object V22;
	register int V23;
	V22= (V17);
	V23= V18;
	CAR(CDR((V22))) = MAKE_FIXNUM(V23);
	}
	(*LK13)(2,(V17),CADR((V20)))              /*  BIND            */;
	goto L1179;
L1181:
	{object V22;
	object V23;
	V22= (V17);
	V23= number_plus(MAKE_FIXNUM(V14),MAKE_FIXNUM(V18));
	CAR(CDR((V22))) = (V23);
	}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("if(",symbol_value(VV[20]));
	(*LK25)(1,(V17))                          /*  WT-LOC          */;
	princ_str("==Cnil){",symbol_value(VV[20]));
	(*LK17)(3,CADR((V20)),CADDR((V20)),Ct)    /*  BIND-INIT       */;
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("}else{",symbol_value(VV[20]));
	{object V22;
	register int V23;
	V22= (V17);
	V23= V18;
	CAR(CDR((V22))) = MAKE_FIXNUM(V23);
	}
	(*LK13)(2,(V17),CADR((V20)))              /*  BIND            */;
	princ_char(125,symbol_value(VV[20]));
L1179:
	if(((CADDDR((V20)))->v.v_self[4])==(VV[6])){
	goto L1211;}
	{object V22;
	object V23;
	V22= (V17);
	V23= number_plus(MAKE_FIXNUM(V14),MAKE_FIXNUM(V18));
	CAR(CDR((V22))) = (V23);
	}
	(*LK13)(2,(V17),CADDDR((V20)))            /*  BIND            */;
L1211:
	V18= (V18)+(1);
	V19= CDR((V19));
	goto L1173;
	}
	}
L1168:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_char(125,symbol_value(VV[20]));
	(*LK19)(1,(V2))                           /*  C2EXPR          */;
	if((lex0[0])==Cnil){
	goto L1229;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_char(125,symbol_value(VV[20]));
	{int V17;
	VALUES(0)=Cnil;
	V17=1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V17);}
L1229:
	{int V18;
	VALUES(0)=Cnil;
	V18=1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V18);}
	}
}
/*	local function DO-DECL                                        */
static LC9(object *lex0,int narg, object V1)
{ VT10 VLEX10 CLSR10
TTL:
	(*LK20)(1,(V1))                           /*  LOCAL           */;
	if(VALUES(0)==Cnil){
	goto L1235;}
	LC8(lex0,1,(V1))                          /*  WT-DECL         */;
	VALUES(0) = elt_set((V1),5,VALUES(0));
	RETURN(1);
L1235:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	local function WT-DECL                                        */
static LC8(object *lex0,int narg, object V1)
{ VT11 VLEX11 CLSR11
TTL:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	if((lex0[0])!=Cnil){
	goto L1241;}
	princ_char(123,symbol_value(VV[20]));
	lex0[0]= Ct;
L1241:
	(*LK15)(1,(VV[21]->s.s_dbind))            /*  WT1             */;
	(*LK21)(1,(V1))                           /*  REGISTER        */;
	(*LK15)(1,VALUES(0))                      /*  WT1             */;
	(*LK22)(1,((V1))->v.v_self[4])            /*  REP-TYPE        */;
	(*LK15)(1,VALUES(0))                      /*  WT1             */;
	lex0[1]= MAKE_FIXNUM((fix(lex0[1]))+(1));
	(*LK16)(1,lex0[1])                        /*  WT-LCL          */;
	princ_char(59,symbol_value(VV[20]));
	VALUES(0) = lex0[1];
	RETURN(1);
}
/*	function definition for NEED-TO-SET-VS-POINTERS               */
static L10(int narg, object V1)
{ VT12 VLEX12 CLSR12
TTL:
	if((VV[22]->s.s_dbind)!=Cnil){
	VALUES(0) = (VV[22]->s.s_dbind);
	RETURN(1);}
	if((VV[23]->s.s_dbind)!=Cnil){
	VALUES(0) = (VV[23]->s.s_dbind);
	RETURN(1);}
	VALUES(0) = CADR((V1));
	if(VALUES(0)==Cnil)goto L1257;
	RETURN(1);
L1257:
	VALUES(0) = CADDR((V1));
	if(VALUES(0)==Cnil)goto L1259;
	RETURN(1);
L1259:
	VALUES(0) = CADDDR((V1));
	RETURN(1);
}
/*	function definition for C1DM                                  */
static L11(int narg, object V1, object V2, object V3)
{ VT13 VLEX13 CLSR13
TTL:
	{object V4;                               /*  WHOLE           */
	object V5;                                /*  ENV             */
	object V6;                                /*  SETJMPS         */
	object V7;                                /*  DOC             */
	object V8;                                /*  SS              */
	object V9;                                /*  IS              */
	object V10;                               /*  TS              */
	object V11;                               /*  OTHER-DECLS     */
	object V12;                               /*  PPN             */
	V4= Cnil;
	V5= Cnil;
	lex0[0]=Cnil;                             /*  VNAMES          */
	(*LK0)(0)                                 /*  MAKE-INFO       */;
	lex0[1]=VALUES(0);                        /*  DM-INFO         */
	lex0[2]=Cnil;                             /*  DM-VARS         */
	V6= (VV[36]->s.s_dbind);
	V7= Cnil;
	V8= Cnil;
	V9= Cnil;
	V10= Cnil;
	V11= Cnil;
	V12= Cnil;
	{ int V13;
	V13=(*LK2)(2,(V3),Ct)                     /*  C1BODY          */;
	if (V13>0) {
	V3= VALUES(0);
	V13--;
	} else {
	V3= Cnil;}
	if (V13>0) {
	V8= VALUES(1);
	V13--;
	} else {
	V8= Cnil;}
	if (V13>0) {
	V10= VALUES(2);
	V13--;
	} else {
	V10= Cnil;}
	if (V13>0) {
	V9= VALUES(3);
	V13--;
	} else {
	V9= Cnil;}
	if (V13>0) {
	V11= VALUES(4);
	V13--;
	} else {
	V11= Cnil;}
	if (V13>0) {
	V7= VALUES(5);
	} else {
	V7= Cnil;}
	
	}
	V3= CONS(listA(3,VV[3],(V1),(V3)),Cnil);
	(*LK3)(1,(V8))                            /*  C1ADD-GLOBALS   */;
	if(!(type_of((V2))==t_cons||(V2)==Cnil)){
	goto L1276;}
	if(!((CAR((V2)))==(VV[37]))){
	goto L1276;}
	lex0[0]= CONS(CADR((V2)),lex0[0]);
	(*LK4)(4,CADR((V2)),(V8),(V9),(V10))      /*  C1MAKE-VAR      */;
	V4= VALUES(0);
	lex0[2]= CONS((V4),lex0[2]);
	(VV[0]->s.s_dbind)= CONS((V4),(VV[0]->s.s_dbind));
	V2= CDDR((V2));
L1276:
	{volatile object V13;                     /*  X               */
	V13= (V2);
L1292:
	if(!(type_of((V13))!=t_cons)){
	goto L1293;}
	goto L1290;
L1293:
	if(!((CAR((V13)))==(VV[38]))){
	goto L1296;}
	lex0[0]= CONS(CADR((V13)),lex0[0]);
	(*LK4)(4,CADR((V13)),(V8),(V9),(V10))     /*  C1MAKE-VAR      */;
	V5= VALUES(0);
	lex0[2]= CONS((V5),lex0[2]);
	(VV[0]->s.s_dbind)= CONS((V5),(VV[0]->s.s_dbind));
	Lldiff(2,(V2),(V13))                      /*  LDIFF           */;
	T0= VALUES(0);
	V2= nconc(T0,CDDR((V13)));
L1296:
	V13= CDR((V13));
	goto L1292;
	}
L1290:
	{ int V13;
	V13=LC12(lex0,4,(V2),(V8),(V9),(V10))     /*  C1DM-VL         */;
	if (V13>0) {
	V2= VALUES(0);
	V13--;
	} else {
	V2= Cnil;}
	if (V13>0) {
	V12= VALUES(1);
	} else {
	V12= Cnil;}
	
	}
	(*LK10)(3,lex0[0],(V10),(V9))             /*  CHECK-VDECL     */;
	(*LK11)(2,(V11),(V3))                     /*  C1DECL-BODY     */;
	V3= VALUES(0);
	(*LK9)(2,lex0[1],CADR((V3)))              /*  ADD-INFO        */;
	if(eql((V6),(VV[36]->s.s_dbind))){
	goto L1318;}
	elt_set(lex0[1],5,Ct);
	putprop((V1),Ct,VV[45]);
L1318:
	{volatile object V13;
	volatile object V14;                      /*  V               */
	V13= lex0[2];
	V14= Cnil;
L1326:
	if(!((V13)==Cnil)){
	goto L1327;}
	goto L1322;
L1327:
	V14= CAR((V13));
	(*LK12)(1,(V14))                          /*  CHECK-VREF      */;
	V13= CDR((V13));
	goto L1326;
	}
L1322:
	VALUES(0) = list(6,(V7),(V12),(V4),(V5),(V2),(V3));
	RETURN(1);
	}
}
/*	local function C1DM-V                                         */
static LC13(object *lex0,int narg, object V1, object V2, object V3, object V4)
{ VT14 VLEX14 CLSR14
TTL:
	if(!(type_of((V1))==t_symbol)){
	goto L1337;}
	lex0[0]= CONS((V1),lex0[0]);
	(*LK4)(4,(V1),(V2),(V3),(V4))             /*  C1MAKE-VAR      */;
	V1= VALUES(0);
	(VV[0]->s.s_dbind)= CONS((V1),(VV[0]->s.s_dbind));
	lex0[2]= CONS((V1),lex0[2]);
	VALUES(0) = (V1);
	RETURN(1);
L1337:
	RETURN(LC12(lex0,4,(V1),(V2),(V3),(V4))   /*  C1DM-VL         */);
}
/*	local function C1DM-VL                                        */
static LC12(object *lex0,int narg, object V1, object V2, object V3, object V4)
{ VT15 VLEX15 CLSR15
TTL:
	{volatile object V5;                      /*  OPTIONALP       */
	volatile object V6;                       /*  RESTP           */
	volatile object V7;                       /*  KEYP            */
	volatile object V8;                       /*  ALLOW-OTHER-KEYS-P*/
	volatile object V9;                       /*  AUXP            */
	volatile object V10;                      /*  REQUIREDS       */
	volatile object V11;                      /*  OPTIONALS       */
	volatile object V12;                      /*  REST            */
	volatile object V13;                      /*  KEY-FLAG        */
	volatile object V14;                      /*  KEYWORDS        */
	volatile object V15;                      /*  AUXS            */
	volatile object V16;                      /*  ALLOW-OTHER-KEYS*/
	volatile object V17;                      /*  N               */
	volatile object V18;                      /*  PPN             */
	V5= Cnil;
	V6= Cnil;
	V7= Cnil;
	V8= Cnil;
	V9= Cnil;
	V10= Cnil;
	V11= Cnil;
	V12= Cnil;
	V13= Cnil;
	V14= Cnil;
	V15= Cnil;
	V16= Cnil;
	V17= MAKE_FIXNUM(0);
	V18= Cnil;
L1348:
	if(type_of((V1))==t_cons){
	goto L1349;}
	if(((V1))==Cnil){
	goto L1352;}
	if(((V6))==Cnil){
	goto L1355;}
	(*LK26)(1,VV[39])                         /*  DM-BAD-KEY      */;
L1355:
	LC13(lex0,4,(V1),(V2),(V3),(V4))          /*  C1DM-V          */;
	V12= VALUES(0);
L1352:
	{object V20= nreverse((V10));
	{object V21= nreverse((V11));
	{object V22= nreverse((V14));
	VALUES(1) = (V18);
	VALUES(0) = list(7,(V20),(V21),(V12),(V13),(V22),(V16),nreverse((V15)));
	RETURN(2);}}}
L1349:
	{register object V23;                     /*  V               */
	V23= CAR((V1));
	if(!(((V23))==(VV[40]))){
	goto L1362;}
	if(((V5))==Cnil){
	goto L1364;}
	(*LK26)(1,VV[40])                         /*  DM-BAD-KEY      */;
L1364:
	V5= Ct;
	{object V24;
	V24= CAR((V1));
	V1= CDR((V1));
	goto L1359;
	}
L1362:
	if(((V23))==(VV[39])){
	goto L1372;}
	if(!(((V23))==(VV[41]))){
	goto L1373;}
L1372:
	if(((V6))==Cnil){
	goto L1377;}
	(*LK26)(1,(V23))                          /*  DM-BAD-KEY      */;
L1377:
	LC13(lex0,4,CADR((V1)),(V2),(V3),(V4))    /*  C1DM-V          */;
	V12= VALUES(0);
	V6= Ct;
	V5= Ct;
	V1= CDDR((V1));
	if(!(((V23))==(VV[41]))){
	goto L1359;}
	V18= (V17);
	goto L1359;
L1373:
	if(!(((V23))==(VV[42]))){
	goto L1392;}
	if(((V7))==Cnil){
	goto L1394;}
	(*LK26)(1,VV[42])                         /*  DM-BAD-KEY      */;
L1394:
	V7= Ct;
	V6= Ct;
	V5= Ct;
	V13= Ct;
	{object V25;
	V25= CAR((V1));
	V1= CDR((V1));
	goto L1359;
	}
L1392:
	if(!(((V23))==(VV[43]))){
	goto L1409;}
	if(((V7))==Cnil){
	goto L1412;}
	if(((V8))==Cnil){
	goto L1411;}
L1412:
	(*LK26)(1,VV[43])                         /*  DM-BAD-KEY      */;
L1411:
	V8= Ct;
	V16= Ct;
	{object V26;
	V26= CAR((V1));
	V1= CDR((V1));
	goto L1359;
	}
L1409:
	if(!(((V23))==(VV[44]))){
	goto L1424;}
	if(((V9))==Cnil){
	goto L1426;}
	(*LK26)(1,VV[44])                         /*  DM-BAD-KEY      */;
L1426:
	V9= Ct;
	V8= Ct;
	V7= Ct;
	V6= Ct;
	V5= Ct;
	{object V27;
	V27= CAR((V1));
	V1= CDR((V1));
	goto L1359;
	}
L1424:
	if(((V9))==Cnil){
	goto L1443;}
	{object V28;                              /*  X               */
	object V29;                               /*  INIT            */
	V28= Cnil;
	V29= Cnil;
	if(!(type_of((V23))==t_symbol)){
	goto L1448;}
	V28= (V23);
	(*LK27)(0)                                /*  C1NIL           */;
	V29= VALUES(0);
	goto L1446;
L1448:
	V28= CAR((V23));
	if(!(CDR((V23))==Cnil)){
	goto L1456;}
	(*LK27)(0)                                /*  C1NIL           */;
	V29= VALUES(0);
	goto L1446;
L1456:
	(*LK6)(2,CADR((V23)),lex0[1])             /*  C1EXPR*         */;
	V29= VALUES(0);
L1446:
	LC13(lex0,4,(V28),(V2),(V3),(V4))         /*  C1DM-V          */;
	V15= CONS(list(2,VALUES(0),(V29)),(V15));
	}
	{object V28;
	V28= CAR((V1));
	V1= CDR((V1));
	goto L1359;
	}
L1443:
	if(((V7))==Cnil){
	goto L1466;}
	{object V29;                              /*  X               */
	object V30;                               /*  K               */
	object V31;                               /*  INIT            */
	object V32;                               /*  SV              */
	V29= Cnil;
	V30= Cnil;
	V31= Cnil;
	V32= Cnil;
	if(!(type_of((V23))==t_symbol)){
	goto L1471;}
	V29= (V23);
	Lintern(2,coerce_to_string((V23)),VV[11]) /*  INTERN          */;
	V30= VALUES(0);
	(*LK27)(0)                                /*  C1NIL           */;
	V31= VALUES(0);
	goto L1469;
L1471:
	if(!(type_of(CAR((V23)))==t_symbol)){
	goto L1480;}
	V29= CAR((V23));
	Lintern(2,coerce_to_string(CAR((V23))),VV[11])/*  INTERN      */;
	V30= VALUES(0);
	goto L1478;
L1480:
	V29= CADAR((V23));
	V30= CAAR((V23));
L1478:
	if(!(CDR((V23))==Cnil)){
	goto L1489;}
	(*LK27)(0)                                /*  C1NIL           */;
	V31= VALUES(0);
	goto L1469;
L1489:
	(*LK6)(2,CADR((V23)),lex0[1])             /*  C1EXPR*         */;
	V31= VALUES(0);
	if(CDDR((V23))==Cnil){
	goto L1469;}
	V32= CADDR((V23));
L1469:
	LC13(lex0,4,(V29),(V2),(V3),(V4))         /*  C1DM-V          */;
	T0= VALUES(0);
	if(((V32))==Cnil){
	goto L1501;}
	LC13(lex0,4,(V32),(V2),(V3),(V4))         /*  C1DM-V          */;
	goto L1499;
L1501:
	VALUES(0) = Cnil;
L1499:
	V14= CONS(list(4,(V30),T0,(V31),VALUES(0)),(V14));
	}
	{object V29;
	V29= CAR((V1));
	V1= CDR((V1));
	goto L1359;
	}
L1466:
	if(((V5))==Cnil){
	goto L1507;}
	{object V30;                              /*  X               */
	object V31;                               /*  INIT            */
	object V32;                               /*  SV              */
	V30= Cnil;
	V31= Cnil;
	V32= Cnil;
	if(!(type_of((V23))==t_symbol)){
	goto L1512;}
	V30= (V23);
	(*LK27)(0)                                /*  C1NIL           */;
	V31= VALUES(0);
	goto L1510;
L1512:
	V30= CAR((V23));
	if(!(CDR((V23))==Cnil)){
	goto L1520;}
	(*LK27)(0)                                /*  C1NIL           */;
	V31= VALUES(0);
	goto L1510;
L1520:
	(*LK6)(2,CADR((V23)),lex0[1])             /*  C1EXPR*         */;
	V31= VALUES(0);
	if(CDDR((V23))==Cnil){
	goto L1510;}
	V32= CADDR((V23));
L1510:
	LC13(lex0,4,(V30),(V2),(V3),(V4))         /*  C1DM-V          */;
	T0= VALUES(0);
	if(((V32))==Cnil){
	goto L1532;}
	LC13(lex0,4,(V32),(V2),(V3),(V4))         /*  C1DM-V          */;
	goto L1530;
L1532:
	VALUES(0) = Cnil;
L1530:
	V11= CONS(list(3,T0,(V31),VALUES(0)),(V11));
	}
	{object V30;
	V30= CAR((V1));
	V1= CDR((V1));
	}
	V17= number_plus((V17),MAKE_FIXNUM(1));
	goto L1359;
L1507:
	LC13(lex0,4,(V23),(V2),(V3),(V4))         /*  C1DM-V          */;
	V10= CONS(VALUES(0),(V10));
	{object V30;
	V30= CAR((V1));
	V1= CDR((V1));
	}
	V17= number_plus((V17),MAKE_FIXNUM(1));
	}
L1359:
	goto L1348;
	}
}
/*	function definition for C1DM-BAD-KEY                          */
static L14(int narg, object V1)
{ VT16 VLEX16 CLSR16
TTL:
	RETURN((*LK1)(2,VV[46],(V1))              /*  CMPERR          */);
}
/*	function definition for C2DM                                  */
static L15(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT17 VLEX17 CLSR17
	bds_check;
	lex0[0]=V1;                               /*  NAME            */
TTL:
	{object V6;                               /*  LCL             */
	V6= Cnil;
	if(((VV[22]->s.s_dbind))!=Cnil){
	goto L1551;}
	if(((VV[23]->s.s_dbind))==Cnil){
	goto L1550;}
L1551:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("check_arg(2);",symbol_value(VV[20]));
L1550:
	(*LK28)(0)                                /*  NEXT-LCL        */;
	V6= VALUES(0);
	if(((V2))==Cnil){
	goto L1560;}
	(*LK12)(1,(V2))                           /*  CHECK-VREF      */;
	(*LK13)(2,list(2,VV[17],(V6)),(V2))       /*  BIND            */;
L1560:
	(*LK28)(0)                                /*  NEXT-LCL        */;
	V6= VALUES(0);
	if(((V3))==Cnil){
	goto L1566;}
	(*LK12)(1,(V3))                           /*  CHECK-VREF      */;
	(*LK13)(2,list(2,VV[17],(V6)),(V3))       /*  BIND            */;
L1566:
	(*LK28)(0)                                /*  NEXT-LCL        */;
	V6= VALUES(0);
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("{object ",symbol_value(VV[20]));
	(*LK16)(1,(V6))                           /*  WT-LCL          */;
	princ_str("=CDR(V1)",symbol_value(VV[20]));
	LC17(lex0,1,(V4))                         /*  RESERVE-VL      */;
	princ_char(59,symbol_value(VV[20]));
	LC20(lex0,2,(V4),(V6))                    /*  DM-BIND-VL      */;
	(*LK19)(1,(V5))                           /*  C2EXPR          */;
	princ_char(125,symbol_value(VV[20]));
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	local function DM-BIND-INIT                                   */
static LC19(object *lex0,int narg, object V1)
{ VT18 VLEX18 CLSR18
TTL:
	{object V2;                               /*  V               */
	object V3;                                /*  INIT            */
	V2= CAR((V1));
	V3= CADR((V1));
	if(!(type_of((V2))==t_cons)){
	goto L1588;}
	{object V4;                               /*  LCL             */
	object V5;                                /*  LOC             */
	bds_bind(VV[49],MAKE_FIXNUM(0));          /*  *INLINE-BLOCKS* */
	(*LK28)(0)                                /*  NEXT-LCL        */;
	V4= VALUES(0);
	(*LK29)(1,CONS((V3),Cnil))                /*  INLINE-ARGS     */;
	V5= CADR(CAR(VALUES(0)));
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	(*LK16)(1,(V4))                           /*  WT-LCL          */;
	princ_str("= ",symbol_value(VV[20]));
	(*LK15)(1,(V5))                           /*  WT1             */;
	princ_char(59,symbol_value(VV[20]));
	LC20(lex0,2,(V2),(V4))                    /*  DM-BIND-VL      */;
	{int V6;
	V6=(*LK30)(0)                             /*  CLOSE-INLINE-BLOCKS*/;
	bds_unwind1;
	RETURN(V6);}
	}
L1588:
	RETURN((*LK17)(2,(V2),(V3))               /*  BIND-INIT       */);
	}
}
/*	local function DM-BIND-LOC                                    */
static LC18(object *lex0,int narg, object V1, object V2)
{ VT19 VLEX19 CLSR19
TTL:
	if(!(type_of((V1))==t_cons)){
	goto L1603;}
	{object V3;                               /*  LCL             */
	(*LK28)(0)                                /*  NEXT-LCL        */;
	V3= VALUES(0);
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("{object ",symbol_value(VV[20]));
	(*LK16)(1,(V3))                           /*  WT-LCL          */;
	princ_str("= ",symbol_value(VV[20]));
	(*LK15)(1,(V2))                           /*  WT1             */;
	princ_char(59,symbol_value(VV[20]));
	LC20(lex0,2,(V1),(V3))                    /*  DM-BIND-VL      */;
	princ_char(125,symbol_value(VV[20]));
	VALUES(0) = Cnil;
	RETURN(1);
	}
L1603:
	RETURN((*LK13)(2,(V2),(V1))               /*  BIND            */);
}
/*	local function RESERVE-V                                      */
static LC16(object *lex0,int narg, object V1)
{ VT20 VLEX20 CLSR20
TTL:
	if(!(type_of((V1))==t_cons)){
	goto L1618;}
	RETURN(LC17(lex0,1,(V1))                  /*  RESERVE-VL      */);
L1618:
	(*LK20)(1,(V1))                           /*  LOCAL           */;
	if(VALUES(0)==Cnil){
	goto L1621;}
	{object V2;                               /*  LCL             */
	(*LK28)(0)                                /*  NEXT-LCL        */;
	V2= VALUES(0);
	elt_set((V1),5,(V2));
	elt_set((V1),4,VV[48]);
	princ_char(44,symbol_value(VV[20]));
	RETURN((*LK16)(1,(V2))                    /*  WT-LCL          */);
	}
L1621:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	local function DM-BIND-VL                                     */
static LC20(object *lex0,int narg, object V1, object V2)
{ VT21 VLEX21 CLSR21
TTL:
	{object V3;                               /*  REQUIREDS       */
	object V4;                                /*  OPTIONALS       */
	object V5;                                /*  REST            */
	object V6;                                /*  KEY-FLAG        */
	object V7;                                /*  KEYWORDS        */
	object V8;                                /*  ALLOW-OTHER-KEYS*/
	object V9;                                /*  AUXS            */
	V3= CAR((V1));
	V4= CADR((V1));
	V5= CADDR((V1));
	V6= CADDDR((V1));
	Lfifth(1,(V1))                            /*  FIFTH           */;
	V7= VALUES(0);
	Lsixth(1,(V1))                            /*  SIXTH           */;
	V8= VALUES(0);
	Lseventh(1,(V1))                          /*  SEVENTH         */;
	V9= VALUES(0);
	{volatile object V10;                     /*  REQS            */
	V10= (V3);
L1637:
	if(!((V10)==Cnil)){
	goto L1638;}
	goto L1635;
L1638:
	if(((VV[22]->s.s_dbind))!=Cnil){
	goto L1642;}
	if(((VV[23]->s.s_dbind))==Cnil){
	goto L1641;}
L1642:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("if(endp(",symbol_value(VV[20]));
	(*LK16)(1,(V2))                           /*  WT-LCL          */;
	princ_str("))FEinvalid_macro_call(VV[",symbol_value(VV[20]));
	(*LK24)(1,lex0[0])                        /*  ADD-SYMBOL      */;
	(*LK15)(1,VALUES(0))                      /*  WT1             */;
	princ_str("]);",symbol_value(VV[20]));
L1641:
	{object V12= CAR((V10));
	LC18(lex0,2,(V12),list(2,VV[47],(V2)))    /*  DM-BIND-LOC     */;}
	if((CDR((V10)))!=Cnil){
	goto L1657;}
	if(((V4))!=Cnil){
	goto L1657;}
	if(((V5))!=Cnil){
	goto L1657;}
	if(((V6))!=Cnil){
	goto L1657;}
	if(((VV[22]->s.s_dbind))!=Cnil){
	goto L1657;}
	if(((VV[23]->s.s_dbind))==Cnil){
	goto L1656;}
L1657:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	(*LK16)(1,(V2))                           /*  WT-LCL          */;
	princ_str("=CDR(",symbol_value(VV[20]));
	(*LK16)(1,(V2))                           /*  WT-LCL          */;
	princ_str(");",symbol_value(VV[20]));
L1656:
	V10= CDR((V10));
	goto L1637;
	}
L1635:
	{volatile object V10;                     /*  OPTS            */
	volatile object V11;                      /*  OPT             */
	V10= (V4);
	V11= Cnil;
L1682:
	if(!((V10)==Cnil)){
	goto L1683;}
	goto L1680;
L1683:
	V11= CAR((V10));
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("if(endp(",symbol_value(VV[20]));
	(*LK16)(1,(V2))                           /*  WT-LCL          */;
	princ_str(")){",symbol_value(VV[20]));
	bds_bind(VV[14],(VV[14]->s.s_dbind));     /*  *ENV*           */
	bds_bind(VV[13],(VV[13]->s.s_dbind));     /*  *UNWIND-EXIT*   */
	LC19(lex0,1,(V11))                        /*  DM-BIND-INIT    */;
	if((CADDR((V11)))==Cnil){
	bds_unwind1;
	bds_unwind1;
	goto L1695;}
	LC18(lex0,2,CADDR((V11)),Cnil)            /*  DM-BIND-LOC     */;
	bds_unwind1;
	bds_unwind1;
L1695:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("} else {",symbol_value(VV[20]));
	{object V13= CAR((V11));
	LC18(lex0,2,(V13),list(2,VV[47],(V2)))    /*  DM-BIND-LOC     */;}
	if((CADDR((V11)))==Cnil){
	goto L1704;}
	LC18(lex0,2,CADDR((V11)),Ct)              /*  DM-BIND-LOC     */;
L1704:
	if((CDR((V10)))!=Cnil){
	goto L1708;}
	if(((V5))!=Cnil){
	goto L1708;}
	if(((V6))!=Cnil){
	goto L1708;}
	if(((VV[22]->s.s_dbind))!=Cnil){
	goto L1708;}
	if(((VV[23]->s.s_dbind))==Cnil){
	goto L1707;}
L1708:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	(*LK16)(1,(V2))                           /*  WT-LCL          */;
	princ_str("=CDR(",symbol_value(VV[20]));
	(*LK16)(1,(V2))                           /*  WT-LCL          */;
	princ_str(");",symbol_value(VV[20]));
L1707:
	princ_char(125,symbol_value(VV[20]));
	V10= CDR((V10));
	goto L1682;
	}
L1680:
	if(((V5))==Cnil){
	goto L1731;}
	LC18(lex0,2,(V5),list(2,VV[17],(V2)))     /*  DM-BIND-LOC     */;
L1731:
	if(((V7))==Cnil){
	goto L1734;}
	{volatile object V10;                     /*  LCL1            */
	volatile object V11;                      /*  LOC1            */
	(*LK28)(0)                                /*  NEXT-LCL        */;
	V10= VALUES(0);
	V11= list(2,VV[17],(V10));
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("{object ",symbol_value(VV[20]));
	(*LK15)(1,(V11))                          /*  WT1             */;
	princ_char(59,symbol_value(VV[20]));
	{volatile object V12;
	volatile object V13;                      /*  KWD             */
	V12= (V7);
	V13= Cnil;
L1749:
	if(!((V12)==Cnil)){
	goto L1750;}
	goto L1745;
L1750:
	V13= CAR((V12));
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	(*LK15)(1,(V11))                          /*  WT1             */;
	princ_str("=getf(",symbol_value(VV[20]));
	(*LK16)(1,(V2))                           /*  WT-LCL          */;
	princ_str(",VV[",symbol_value(VV[20]));
	(*LK24)(1,CAR((V13)))                     /*  ADD-SYMBOL      */;
	(*LK15)(1,VALUES(0))                      /*  WT1             */;
	princ_str("],OBJNULL);",symbol_value(VV[20]));
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("if(",symbol_value(VV[20]));
	(*LK15)(1,(V11))                          /*  WT1             */;
	princ_str("==OBJNULL){",symbol_value(VV[20]));
	bds_bind(VV[14],(VV[14]->s.s_dbind));     /*  *ENV*           */
	bds_bind(VV[13],(VV[13]->s.s_dbind));     /*  *UNWIND-EXIT*   */
	LC19(lex0,1,CDR((V13)))                   /*  DM-BIND-INIT    */;
	if((CADDDR((V13)))==Cnil){
	goto L1774;}
	LC18(lex0,2,CADDDR((V13)),Cnil)           /*  DM-BIND-LOC     */;
L1774:
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("} else {",symbol_value(VV[20]));
	bds_unwind1;
	bds_unwind1;
	LC18(lex0,2,CADR((V13)),(V11))            /*  DM-BIND-LOC     */;
	if((CADDDR((V13)))==Cnil){
	goto L1781;}
	LC18(lex0,2,CADDDR((V13)),Ct)             /*  DM-BIND-LOC     */;
L1781:
	princ_char(125,symbol_value(VV[20]));
	V12= CDR((V12));
	goto L1749;
	}
L1745:
	princ_char(125,symbol_value(VV[20]));
	}
L1734:
	if(((VV[22]->s.s_dbind))!=Cnil){
	goto L1792;}
	if(((VV[23]->s.s_dbind))==Cnil){
	goto L1790;}
L1792:
	if(((V5))!=Cnil){
	goto L1790;}
	if(((V6))!=Cnil){
	goto L1790;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("if(!endp(",symbol_value(VV[20]));
	(*LK16)(1,(V2))                           /*  WT-LCL          */;
	princ_str("))FEinvalid_macro_call(VV[",symbol_value(VV[20]));
	(*LK24)(1,lex0[0])                        /*  ADD-SYMBOL      */;
	(*LK15)(1,VALUES(0))                      /*  WT1             */;
	princ_str("]);",symbol_value(VV[20]));
L1790:
	if(((VV[22]->s.s_dbind))!=Cnil){
	goto L1810;}
	if(((VV[23]->s.s_dbind))==Cnil){
	goto L1808;}
L1810:
	if(((V6))==Cnil){
	goto L1808;}
	if(((V8))!=Cnil){
	goto L1808;}
	(*LK15)(1,code_char('\12'))               /*  WT1             */;
	(*LK15)(1,code_char('\11'))               /*  WT1             */;
	princ_str("check_other_key(",symbol_value(VV[20]));
	(*LK16)(1,(V2))                           /*  WT-LCL          */;
	princ_char(44,symbol_value(VV[20]));
	(*LK15)(1,MAKE_FIXNUM(length((V7))))      /*  WT1             */;
	{volatile object V10;
	volatile object V11;                      /*  KWD             */
	V10= (V7);
	V11= Cnil;
L1829:
	if(!((V10)==Cnil)){
	goto L1830;}
	goto L1825;
L1830:
	V11= CAR((V10));
	princ_str(",VV[",symbol_value(VV[20]));
	(*LK24)(1,CAR((V11)))                     /*  ADD-SYMBOL      */;
	(*LK15)(1,VALUES(0))                      /*  WT1             */;
	princ_char(93,symbol_value(VV[20]));
	V10= CDR((V10));
	goto L1829;
	}
L1825:
	princ_str(");",symbol_value(VV[20]));
L1808:
	{volatile object V10;
	volatile object V11;                      /*  AUX             */
	V10= (V9);
	V11= Cnil;
L1847:
	if(!((V10)==Cnil)){
	goto L1848;}
	VALUES(0) = Cnil;
	RETURN(1);
L1848:
	V11= CAR((V10));
	LC19(lex0,1,(V11))                        /*  DM-BIND-INIT    */;
	V10= CDR((V10));
	goto L1847;
	}
	}
}
/*	local function RESERVE-VL                                     */
static LC17(object *lex0,int narg, object V1)
{ VT22 VLEX22 CLSR22
TTL:
	{volatile object V2;
	volatile object V3;                       /*  VAR             */
	V2= CAR((V1));
	V3= Cnil;
L1861:
	if(!((V2)==Cnil)){
	goto L1862;}
	goto L1857;
L1862:
	V3= CAR((V2));
	LC16(lex0,1,(V3))                         /*  RESERVE-V       */;
	V2= CDR((V2));
	goto L1861;
	}
L1857:
	{volatile object V2;
	volatile object V3;                       /*  OPT             */
	V2= CADR((V1));
	V3= Cnil;
L1875:
	if(!((V2)==Cnil)){
	goto L1876;}
	goto L1871;
L1876:
	V3= CAR((V2));
	LC16(lex0,1,CAR((V3)))                    /*  RESERVE-V       */;
	if((CADDR((V3)))==Cnil){
	goto L1882;}
	LC16(lex0,1,CADDR((V3)))                  /*  RESERVE-V       */;
L1882:
	V2= CDR((V2));
	goto L1875;
	}
L1871:
	if((CADDR((V1)))==Cnil){
	goto L1888;}
	LC16(lex0,1,CADDR((V1)))                  /*  RESERVE-V       */;
L1888:
	{volatile object V2;
	volatile object V3;                       /*  KWD             */
	Lfifth(1,(V1))                            /*  FIFTH           */;
	V2= VALUES(0);
	V3= Cnil;
L1895:
	if(!((V2)==Cnil)){
	goto L1896;}
	goto L1891;
L1896:
	V3= CAR((V2));
	LC16(lex0,1,CADR((V3)))                   /*  RESERVE-V       */;
	if((CADDDR((V3)))==Cnil){
	goto L1902;}
	LC16(lex0,1,CADDDR((V3)))                 /*  RESERVE-V       */;
L1902:
	V2= CDR((V2));
	goto L1895;
	}
L1891:
	{volatile object V2;
	volatile object V3;                       /*  AUX             */
	Lseventh(1,(V1))                          /*  SEVENTH         */;
	V2= VALUES(0);
	V3= Cnil;
L1911:
	if(!((V2)==Cnil)){
	goto L1912;}
	VALUES(0) = Cnil;
	RETURN(1);
L1912:
	V3= CAR((V2));
	LC16(lex0,1,CAR((V3)))                    /*  RESERVE-V       */;
	V2= CDR((V2));
	goto L1911;
	}
}
static LKF30(int narg, ...) {TRAMPOLINK(VV[89],&LK30);}
static LKF29(int narg, ...) {TRAMPOLINK(VV[88],&LK29);}
static LKF28(int narg, ...) {TRAMPOLINK(VV[87],&LK28);}
static LKF27(int narg, ...) {TRAMPOLINK(VV[86],&LK27);}
static LKF26(int narg, ...) {TRAMPOLINK(VV[85],&LK26);}
static LKF25(int narg, ...) {TRAMPOLINK(VV[84],&LK25);}
static LKF24(int narg, ...) {TRAMPOLINK(VV[83],&LK24);}
static LKF23(int narg, ...) {TRAMPOLINK(VV[82],&LK23);}
static LKF22(int narg, ...) {TRAMPOLINK(VV[81],&LK22);}
static LKF21(int narg, ...) {TRAMPOLINK(VV[80],&LK21);}
static LKF20(int narg, ...) {TRAMPOLINK(VV[79],&LK20);}
static LKF19(int narg, ...) {TRAMPOLINK(VV[78],&LK19);}
static LKF18(int narg, ...) {TRAMPOLINK(VV[77],&LK18);}
static LKF17(int narg, ...) {TRAMPOLINK(VV[76],&LK17);}
static LKF16(int narg, ...) {TRAMPOLINK(VV[75],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[74],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[73],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[72],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[71],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[70],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[69],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[68],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[67],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[66],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[65],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[64],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[63],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[62],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[61],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[60],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[59],&LK0);}
