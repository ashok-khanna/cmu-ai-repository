
/* (c) Copyright G. Attardi, 1993. All rights reserved. */
#include <ecl.h>
#include "module.h"
init_module(int size, object file)
{
	Cblock.cd_start=NULL; Cblock.cd_size=size;
	Cblock.cd_data=read_VV(VV,VM1,file);
	VV[0]->s.s_stype=(short)stp_special;
	if(VV[0]->s.s_dbind == OBJNULL){
	(VV[0]->s.s_dbind)= Cnil;}
	MF0(VV[4],L1);
	MF0(VV[5],L2);
}
/*	function definition for PROVIDE                               */
static L1(int narg, object V1)
{ VT3 VLEX3 CLSR3
	cs_reserve(VM3);
	check_arg(1);
TTL:
	Lstring(1,(V1))                           /*  STRING          */;
	T0= VALUES(0);
	VALUES(0) = symbol_function(VV[6]);
	Ladjoin(4,T0,symbol_value(VV[0]),VV[1],VALUES(0))/*  ADJOIN   */;
	setq(VV[0],VALUES(0));
	VALUES(0) = symbol_value(VV[0]);
	RETURN(1);
}
/*	function definition for REQUIRE                               */
static L2(int narg, object V1, ...)
{ VT4 VLEX4 CLSR4
	cs_reserve(VM4);
	bds_check;
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if(narg<1) FEtoo_few_arguments(&narg);
	if(narg>2) FEtoo_many_arguments(&narg);
	if (i==narg) goto L5;
	V2= va_arg(args, object);
	i++;
	goto L6;
L5:
	Lstring(1,(V1))                           /*  STRING          */;
	Lstring_downcase(1,VALUES(0))             /*  STRING-DOWNCASE */;
	V2= VALUES(0);
L6:
	bds_bind(VV[2],VV[3]);                    /*  *DEFAULT-PATHNAME-DEFAULTS**/
	Lstring(1,(V1))                           /*  STRING          */;
	T0= VALUES(0);
	VALUES(0) = symbol_function(VV[6]);
	Lmember(4,T0,symbol_value(VV[0]),VV[1],VALUES(0))/*  MEMBER   */;
	if(VALUES(0)!=Cnil){
	goto L10;}
	if(!(type_of((V2))!=t_cons)){
	goto L15;}
	{int V3;
	V3=(*LK0)(1,(V2))                         /*  LOAD            */;
	bds_unwind1;
	RETURN(V3);}
L15:
	{register object V4;
	object V5;                                /*  P               */
	V4= (V2);
	V5= Cnil;
L20:
	if(!(endp((V4)))){
	goto L21;}
	{int V7;
	VALUES(0)=Cnil;
	V7=1;
	bds_unwind1;
	RETURN(V7);}
L21:
	V5= car((V4));
	(*LK0)(1,(V5))                            /*  LOAD            */;
	V4= cdr((V4));
	goto L20;
	}
L10:
	{int V8;
	VALUES(0)=Cnil;
	V8=1;
	bds_unwind1;
	RETURN(V8);}
	}
}
static LKF0(int narg, ...) {TRAMPOLINK(VV[7],&LK0);}
