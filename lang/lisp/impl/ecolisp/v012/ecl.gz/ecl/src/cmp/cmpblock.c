
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "cmpblock.h"
init_cmpblock(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_cmpblock; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	VV[0]->s.s_stype=(short)stp_special;
	if(VV[0]->s.s_dbind == OBJNULL){
	(VV[0]->s.s_dbind)= Cnil;}
	MF0(VV[25],L1);
	MF0(VV[27],L2);
	MF0(VV[28],L3);
	MF0(VV[29],L4);
	putprop(VV[1],VV[25],VV[24]);
	putprop(VV[1],VV[27],VV[26]);
	putprop(VV[18],VV[28],VV[24]);
	putprop(VV[18],VV[29],VV[26]);
}
/*	function definition for C1BLOCK                               */
static L1(int narg, object V1)
{ VT3 VLEX3 CLSR3
	bds_check;
TTL:
	if(!((V1)==Cnil)){
	goto L6;}
	(*LK0)(3,VV[1],MAKE_FIXNUM(1),MAKE_FIXNUM(0))/*  TOO-FEW-ARGS */;
L6:
	if(type_of(CAR((V1)))==t_symbol){
	goto L9;}
	(*LK1)(2,VV[2],CAR((V1)))                 /*  CMPERR          */;
L9:
	{register object V2;                      /*  BLK             */
	object V3;                                /*  BODY            */
	{object V4= CAR((V1));
	(*LK2)(4,VV[3],CAR((V1)),VV[5],VV[6])     /*  MAKE-VAR        */;
	(*LK3)(4,VV[3],(V4),VV[4],VALUES(0))      /*  MAKE-BLK        */;
	V2= VALUES(0);}
	bds_bind(VV[0],CONS((V2),(VV[0]->s.s_dbind)));/*  *BLOCKS*    */
	(*LK4)(1,CDR((V1)))                       /*  C1PROGN         */;
	V3= VALUES(0);
	if((((V2))->v.v_self[2])!=Cnil){
	goto L17;}
	if((((V2))->v.v_self[4])==Cnil){
	goto L16;}
L17:
	(VV[7]->s.s_dbind)= number_plus((VV[7]->s.s_dbind),MAKE_FIXNUM(1));
L16:
	if(!(number_compare(MAKE_FIXNUM(0),((V2))->v.v_self[1])<0)){
	goto L23;}
	(*LK5)(1,CADR((V3)))                      /*  RESET-INFO-TYPE */;
	{int V4;
	VALUES(0)=list(4,VV[1],VALUES(0),(V2),(V3));
	V4=1;
	bds_unwind1;
	RETURN(V4);}
L23:
	{int V5;
	VALUES(0)=(V3);
	V5=1;
	bds_unwind1;
	RETURN(V5);}
	}
}
/*	function definition for C2BLOCK                               */
static L2(int narg, object V1, object V2)
{ VT4 VLEX4 CLSR4
	bds_check;
TTL:
	if(!(number_compare(MAKE_FIXNUM(0),(((V1))->v.v_self[7])->v.v_self[1])<0)){
	goto L27;}
	{register object V3;                      /*  NR              */
	object V4;                                /*  VALUES_NR       */
	register object V5;                       /*  BLK-VAR         */
	(*LK6)(0)                                 /*  NEXT-LCL        */;
	V3= list(2,VV[8],VALUES(0));
	V4= list(2,VV[9],(V3));
	V5= ((V1))->v.v_self[7];
	bds_bind(VV[10],(VV[10]->s.s_dbind));     /*  *ENV-LVL*       */
	elt_set((V1),5,(VV[11]->s.s_dbind));
	elt_set((V1),6,(VV[12]->s.s_dbind));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{ int ",symbol_value(VV[13]));
	(*LK7)(1,(V3))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[13]));
	if((((V1))->v.v_self[2])!=Cnil){
	goto L41;}
	if((((V1))->v.v_self[4])!=Cnil){
	goto L41;}
	(*LK6)(0)                                 /*  NEXT-LCL        */;
	elt_set((V5),5,VALUES(0));
	elt_set((V5),4,VV[14]);
	princ_str(" object ",symbol_value(VV[13]));
	(*LK8)(1,(V5))                            /*  WT-VAR          */;
	princ_char(59,symbol_value(VV[13]));
L41:
	(*LK9)(1,((V1))->v.v_self[2])             /*  ENV-GROWS       */;
	if(VALUES(0)==Cnil){
	goto L53;}
	{object V6;                               /*  ENV-LVL         */
	V6= (VV[10]->s.s_dbind);
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("object env",symbol_value(VV[13]));
	(VV[10]->s.s_dbind)= number_plus((VV[10]->s.s_dbind),MAKE_FIXNUM(1));
	(*LK7)(1,(VV[10]->s.s_dbind))             /*  WT1             */;
	princ_str(" = env",symbol_value(VV[13]));
	(*LK7)(1,(V6))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[13]));
	}
L53:
	(*LK10)(2,VV[15],(V5))                    /*  BIND            */;
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if ((",symbol_value(VV[13]));
	(*LK7)(1,(V3))                            /*  WT1             */;
	princ_str("=frs_push(FRS_CATCH,",symbol_value(VV[13]));
	(*LK8)(1,(V5))                            /*  WT-VAR          */;
	princ_str("))!=0) ",symbol_value(VV[13]));
	(*LK7)(1,(V3))                            /*  WT1             */;
	princ_str("--;",symbol_value(VV[13]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("else {",symbol_value(VV[13]));
	bds_bind(VV[12],(V4));                    /*  *DESTINATION*   */
	(*LK11)(1,(V2))                           /*  C2EXPR*         */;
	bds_unwind1;
	princ_char(125,symbol_value(VV[13]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("frs_pop();",symbol_value(VV[13]));
	(*LK12)(2,(V4),VV[16])                    /*  UNWIND-EXIT     */;
	if((((V1))->v.v_self[2])==Cnil){
	goto L88;}
	(VV[17]->s.s_dbind)= number_minus((VV[17]->s.s_dbind),MAKE_FIXNUM(1));
L88:
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_char(125,symbol_value(VV[13]));
	{int V6;
	VALUES(0)=Cnil;
	V6=1;
	bds_unwind1;
	RETURN(V6);}
	}
L27:
	elt_set((V1),5,(VV[11]->s.s_dbind));
	elt_set((V1),6,(VV[12]->s.s_dbind));
	RETURN((*LK13)(1,(V2))                    /*  C2EXPR          */);
}
/*	function definition for C1RETURN-FROM                         */
static L3(int narg, object V1)
{ VT5 VLEX5 CLSR5
TTL:
	if(!((V1)==Cnil)){
	goto L99;}
	(*LK0)(3,VV[18],MAKE_FIXNUM(1),MAKE_FIXNUM(0))/*  TOO-FEW-ARGS*/;
	goto L97;
L99:
	if(CDR((V1))==Cnil){
	goto L102;}
	if(CDDR((V1))==Cnil){
	goto L102;}
	(*LK14)(3,VV[18],MAKE_FIXNUM(2),MAKE_FIXNUM(length((V1))))/*  TOO-MANY-ARGS*/;
	goto L97;
L102:
	if(type_of(CAR((V1)))==t_symbol){
	goto L97;}
L97:
	{ int V2; object (V3);
	V3= new_frame_id();
	if ((V2=frs_push(FRS_CATCH,(V3)))!=0) V2--;
	else {
	{volatile object V4;                      /*  BLKS            */
	volatile object V5;                       /*  NAME            */
	volatile object V6;                       /*  CCB             */
	volatile object V7;                       /*  CLB             */
	volatile object V8;                       /*  UNW             */
	volatile object V9;                       /*  BLK             */
	volatile object V10;                      /*  TYPE            */
	V4= (VV[0]->s.s_dbind);
	V5= CAR((V1));
	V6= Cnil;
	V7= Cnil;
	V8= Cnil;
	V9= Cnil;
	V10= Ct;
L113:
	if(!((V4)==Cnil)){
	goto L114;}
	{ int V11;
	V11=(*LK1)(2,VV[20],(V5))                 /*  CMPERR          */;
	unwind(frs_sch((V3)),Cnil,V11+1);}
L114:
	V9= CAR((V4));
	if(((V9)!= VV[45]))goto L121;
	V6= Ct;
	goto L120;
L121:
	if(((V9)!= VV[46]))goto L123;
	V7= Ct;
	goto L120;
L123:
	if(((V9)!= VV[23]))goto L125;
	V8= Ct;
	goto L120;
L125:
	if(!((((V9))->v.v_self[0])==((V5)))){
	goto L120;}
	{object V12;                              /*  VAL             */
	register object V13;                      /*  INFO            */
	register object V14;                      /*  VAR             */
	(*LK15)(1,CADR((V1)))                     /*  C1EXPR          */;
	V12= VALUES(0);
	(*LK5)(1,CADR((V12)))                     /*  RESET-INFO-TYPE */;
	V13= VALUES(0);
	V14= ((V9))->v.v_self[7];
	if(((V6))==Cnil){
	goto L134;}
	elt_set((V9),2,Ct);
	V10= VV[21];
	elt_set((V14),2,Ct);
	{object V15;
	V15= (V14);
	elt_set((V15),1,number_plus(((V15))->v.v_self[1],MAKE_FIXNUM(1)));
	goto L132;
	}
L134:
	if(((V7))==Cnil){
	goto L142;}
	elt_set((V9),4,Ct);
	V10= VV[22];
	{object V16;
	V16= (V14);
	elt_set((V16),1,number_plus(((V16))->v.v_self[1],MAKE_FIXNUM(1)));
	goto L132;
	}
L142:
	if(((V8))==Cnil){
	goto L132;}
	V10= VV[23];
	{object V17;
	V17= (V14);
	elt_set((V17),1,number_plus(((V17))->v.v_self[1],MAKE_FIXNUM(1)));
	}
L132:
	{object V15;
	V15= (V9);
	elt_set((V15),1,number_plus(((V15))->v.v_self[1],MAKE_FIXNUM(1)));
	}
	{object V15;
	V15= (V13);
	elt_set((V15),6,CONS((V14),((V15))->v.v_self[6]));
	}
	{object V15;
	V15= (V13);
	Ladjoin(2,(V14),((V15))->v.v_self[2])     /*  ADJOIN          */;
	elt_set((V15),2,VALUES(0));
	}
	{ int V15;
	VALUES(0)=list(5,VV[18],(V13),(V9),(V10),(V12));
	V15=1;
	unwind(frs_sch((V3)),Cnil,V15+1);}
	}
L120:
	V4= CDR((V4));
	goto L113;
	}}
	frs_pop();
	RETURN(V2);
	}
}
/*	function definition for C2RETURN-FROM                         */
static L4(int narg, object V1, object V2, object V3)
{ VT6 VLEX6 CLSR6
	bds_check;
TTL:
	{register object V4;                      /*  NR              */
	(*LK6)(0)                                 /*  NEXT-LCL        */;
	V4= list(2,VV[8],VALUES(0));
	if(((V2)!= VV[21]))goto L166;
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{frame_ptr fr; int ",symbol_value(VV[13]));
	(*LK7)(1,(V4))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[13]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("fr=frs_sch(",symbol_value(VV[13]));
	(*LK8)(1,((V1))->v.v_self[7])             /*  WT-VAR          */;
	princ_str(");",symbol_value(VV[13]));
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(fr==NULL) FEerror(\"The block ~s is missing.\",1,VV[",symbol_value(VV[13]));
	(*LK16)(1,((V1))->v.v_self[0])            /*  ADD-SYMBOL      */;
	(*LK7)(1,VALUES(0))                       /*  WT1             */;
	princ_str("]);",symbol_value(VV[13]));
	{object V5;
	V5= list(2,VV[9],(V4));
	bds_bind(VV[12],V5);                      /*  *DESTINATION*   */
	(*LK11)(1,(V3))                           /*  C2EXPR*         */;
	bds_unwind1;
	}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("unwind(fr,Cnil,",symbol_value(VV[13]));
	(*LK7)(1,(V4))                            /*  WT1             */;
	princ_str("+1);}",symbol_value(VV[13]));
	VALUES(0) = Cnil;
	RETURN(1);
L166:
	if(((V2)!= VV[22])
	&& ((V2)!= VV[23]))goto L194;
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{ int ",symbol_value(VV[13]));
	(*LK7)(1,(V4))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[13]));
	{object V5;
	V5= list(2,VV[9],(V4));
	bds_bind(VV[12],V5);                      /*  *DESTINATION*   */
	(*LK11)(1,(V3))                           /*  C2EXPR*         */;
	bds_unwind1;
	}
	(*LK7)(1,code_char('\12'))                /*  WT1             */;
	(*LK7)(1,code_char('\11'))                /*  WT1             */;
	princ_str("unwind(frs_sch(",symbol_value(VV[13]));
	(*LK8)(1,((V1))->v.v_self[7])             /*  WT-VAR          */;
	princ_str("),Cnil,",symbol_value(VV[13]));
	(*LK7)(1,(V4))                            /*  WT1             */;
	princ_str("+1);}",symbol_value(VV[13]));
	VALUES(0) = Cnil;
	RETURN(1);
L194:
	{object V5;
	object V6;
	V5= ((V1))->v.v_self[6];
	V6= ((V1))->v.v_self[5];
	bds_bind(VV[12],V5);                      /*  *DESTINATION*   */
	bds_bind(VV[11],V6);                      /*  *EXIT*          */
	{int V7;
	V7=(*LK13)(1,(V3))                        /*  C2EXPR          */;
	bds_unwind1;
	bds_unwind1;
	RETURN(V7);}
	}
	}
}
static LKF16(int narg, ...) {TRAMPOLINK(VV[48],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[47],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[44],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[43],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[42],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[41],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[40],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[39],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[38],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[37],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[36],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[35],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[34],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[33],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[32],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[31],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[30],&LK0);}
