
/* (c) Copyright G. Attardi, 1993. */
#define VT2
#define VLEX2
#define CLSR2
static LC2(int, object );
#define VT3
#define VLEX3
#define CLSR3
static L1(int, object, ...);
#define VT4 object T0;
#define VLEX4
#define CLSR4
static L3(int, object);
int Lmacro_function();
#define VT5
#define VLEX5
#define CLSR5
static L4(int, object);
#define VT6
#define VLEX6
#define CLSR6
static L5(int, object, object, ...);
int Lfifth();
#define VT7
#define VLEX7
#define CLSR7
static L6(int, object, object, object, ...);
#define VT8
#define VLEX8
#define CLSR8
static L7(int, object, object, object, object, ...);
#define VT9 object T0;
#define VLEX9
#define CLSR9
static L9(int, object, object, object, object, object);
int Lformat();
#define VT10
#define VLEX10
#define CLSR10
static LC10(int, object , object , object );
int Lformat();
#define VT11
#define VLEX11
#define CLSR11
static L11(int, object);
#define VT12
#define VLEX12
#define CLSR12
static L12(int, object, object, object, ...);
#define VT13 object T0;
#define VLEX13
#define CLSR13
static L13(int, object, object, object, ...);
#define VT14
#define VLEX14
#define CLSR14
static L14(int, object, object, object, object, object);
int Lformat();
#define VT15 object T0;
#define VLEX15
#define CLSR15
static struct codeblock Cblock;
#define VM15 1
#define VM14 0
#define VM13 1
#define VM12 0
#define VM11 0
#define VM10 0
#define VM9 1
#define VM8 0
#define VM7 0
#define VM6 0
#define VM5 0
#define VM4 1
#define VM3 0
#define VM2 0
#define VM1 113
static object VV[113];
static LKF0(int, ...);
static (*LK0)(int, ...)=LKF0;
static LKF1(int, ...);
static (*LK1)(int, ...)=LKF1;
static LKF2(int, ...);
static (*LK2)(int, ...)=LKF2;
static LKF3(int, ...);
static (*LK3)(int, ...)=LKF3;
static LKF4(int, ...);
static (*LK4)(int, ...)=LKF4;
static LKF5(int, ...);
static (*LK5)(int, ...)=LKF5;
static LKF6(int, ...);
static (*LK6)(int, ...)=LKF6;
static LKF7(int, ...);
static (*LK7)(int, ...)=LKF7;
static LKF8(int, ...);
static (*LK8)(int, ...)=LKF8;
static LKF9(int, ...);
static (*LK9)(int, ...)=LKF9;
static LKF10(int, ...);
static (*LK10)(int, ...)=LKF10;
static LKF11(int, ...);
static (*LK11)(int, ...)=LKF11;
static LKF12(int, ...);
static (*LK12)(int, ...)=LKF12;
static LKF13(int, ...);
static (*LK13)(int, ...)=LKF13;
static LKF14(int, ...);
static (*LK14)(int, ...)=LKF14;
static LKF15(int, ...);
static (*LK15)(int, ...)=LKF15;
static LKF16(int, ...);
static (*LK16)(int, ...)=LKF16;
static LKF17(int, ...);
static (*LK17)(int, ...)=LKF17;
static LKF18(int, ...);
static (*LK18)(int, ...)=LKF18;
static LKF19(int, ...);
static (*LK19)(int, ...)=LKF19;
static LKF20(int, ...);
static (*LK20)(int, ...)=LKF20;
static LKF21(int, ...);
static (*LK21)(int, ...)=LKF21;
static LKF22(int, ...);
static (*LK22)(int, ...)=LKF22;
static LKF23(int, ...);
static (*LK23)(int, ...)=LKF23;
static LKF24(int, ...);
static (*LK24)(int, ...)=LKF24;
static LKF25(int, ...);
static (*LK25)(int, ...)=LKF25;
static LKF26(int, ...);
static (*LK26)(int, ...)=LKF26;
static LKF27(int, ...);
static (*LK27)(int, ...)=LKF27;
static LKF28(int, ...);
static (*LK28)(int, ...)=LKF28;
static LKF29(int, ...);
static (*LK29)(int, ...)=LKF29;
static LKF30(int, ...);
static (*LK30)(int, ...)=LKF30;
static LKF31(int, ...);
static (*LK31)(int, ...)=LKF31;
static LKF32(int, ...);
static (*LK32)(int, ...)=LKF32;
static LKF33(int, ...);
static (*LK33)(int, ...)=LKF33;
static LKF34(int, ...);
static (*LK34)(int, ...)=LKF34;
static LKF35(int, ...);
static (*LK35)(int, ...)=LKF35;
