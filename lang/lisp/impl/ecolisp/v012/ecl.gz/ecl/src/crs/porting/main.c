#include <stdio.h>

int a[100];

main()
{
	printf("Hello.\n");
	printf("a[10] = %d\n", a[10]);
}
