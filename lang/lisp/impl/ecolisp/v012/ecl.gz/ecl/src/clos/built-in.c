
#include "built-in.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	funcall(2,VV[105]->s.s_gfdef,VV[0])       /*  FIND-CLASS      */;
	funcall(9,VV[62]->s.s_gfdef,VALUES(0),VV[1],VV[2],Cnil,Cnil,Cnil,Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[105]->s.s_gfdef,VV[1])       /*  FIND-CLASS      */;
	funcall(2,VV[105]->s.s_gfdef,VV[0])       /*  FIND-CLASS      */;
	funcall(9,VV[62]->s.s_gfdef,VALUES(0),VV[3],VV[4],Cnil,Cnil,Cnil,Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[105]->s.s_gfdef,VV[3])       /*  FIND-CLASS      */;
	funcall(2,VV[105]->s.s_gfdef,VV[0])       /*  FIND-CLASS      */;
	funcall(9,VV[62]->s.s_gfdef,VALUES(0),VV[5],VV[6],Cnil,Cnil,Cnil,Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[105]->s.s_gfdef,VV[5])       /*  FIND-CLASS      */;
	funcall(2,VV[105]->s.s_gfdef,VV[0])       /*  FIND-CLASS      */;
	funcall(9,VV[62]->s.s_gfdef,VALUES(0),VV[7],VV[8],Cnil,Cnil,Cnil,Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[105]->s.s_gfdef,VV[7])       /*  FIND-CLASS      */;
	funcall(2,VV[105]->s.s_gfdef,VV[0])       /*  FIND-CLASS      */;
	funcall(9,VV[62]->s.s_gfdef,VALUES(0),VV[9],VV[10],Cnil,Cnil,Cnil,Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[105]->s.s_gfdef,VV[9])       /*  FIND-CLASS      */;
	funcall(2,VV[105]->s.s_gfdef,VV[0])       /*  FIND-CLASS      */;
	funcall(9,VV[62]->s.s_gfdef,VALUES(0),VV[11],VV[12],Cnil,Cnil,Cnil,Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[105]->s.s_gfdef,VV[11])      /*  FIND-CLASS      */;
	funcall(2,VV[105]->s.s_gfdef,VV[0])       /*  FIND-CLASS      */;
	funcall(9,VV[62]->s.s_gfdef,VALUES(0),VV[13],VV[14],Cnil,Cnil,Cnil,Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[105]->s.s_gfdef,VV[13])      /*  FIND-CLASS      */;
	funcall(2,VV[105]->s.s_gfdef,VV[0])       /*  FIND-CLASS      */;
	funcall(9,VV[62]->s.s_gfdef,VALUES(0),VV[15],VV[16],Cnil,Cnil,Cnil,Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[105]->s.s_gfdef,VV[15])      /*  FIND-CLASS      */;
	funcall(2,VV[105]->s.s_gfdef,VV[0])       /*  FIND-CLASS      */;
	funcall(9,VV[62]->s.s_gfdef,VALUES(0),VV[17],VV[18],Cnil,Cnil,Cnil,Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[105]->s.s_gfdef,VV[17])      /*  FIND-CLASS      */;
	funcall(2,VV[105]->s.s_gfdef,VV[0])       /*  FIND-CLASS      */;
	funcall(9,VV[62]->s.s_gfdef,VALUES(0),VV[19],VV[20],Cnil,Cnil,Cnil,Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[105]->s.s_gfdef,VV[19])      /*  FIND-CLASS      */;
	funcall(2,VV[105]->s.s_gfdef,VV[0])       /*  FIND-CLASS      */;
	funcall(9,VV[62]->s.s_gfdef,VALUES(0),VV[21],VV[22],Cnil,Cnil,Cnil,Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[105]->s.s_gfdef,VV[21])      /*  FIND-CLASS      */;
	funcall(2,VV[105]->s.s_gfdef,VV[0])       /*  FIND-CLASS      */;
	funcall(9,VV[62]->s.s_gfdef,VALUES(0),VV[23],VV[24],Cnil,Cnil,Cnil,Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[105]->s.s_gfdef,VV[23])      /*  FIND-CLASS      */;
	funcall(2,VV[105]->s.s_gfdef,VV[0])       /*  FIND-CLASS      */;
	funcall(9,VV[62]->s.s_gfdef,VALUES(0),VV[25],VV[26],Cnil,Cnil,Cnil,Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[105]->s.s_gfdef,VV[25])      /*  FIND-CLASS      */;
	funcall(2,VV[105]->s.s_gfdef,VV[0])       /*  FIND-CLASS      */;
	funcall(9,VV[62]->s.s_gfdef,VALUES(0),VV[27],VV[28],Cnil,Cnil,Cnil,Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[105]->s.s_gfdef,VV[27])      /*  FIND-CLASS      */;
	funcall(2,VV[105]->s.s_gfdef,VV[0])       /*  FIND-CLASS      */;
	funcall(9,VV[62]->s.s_gfdef,VALUES(0),VV[29],VV[30],Cnil,Cnil,Cnil,Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[105]->s.s_gfdef,VV[29])      /*  FIND-CLASS      */;
	funcall(2,VV[105]->s.s_gfdef,VV[0])       /*  FIND-CLASS      */;
	funcall(9,VV[62]->s.s_gfdef,VALUES(0),VV[31],VV[32],Cnil,Cnil,Cnil,Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[105]->s.s_gfdef,VV[31])      /*  FIND-CLASS      */;
	funcall(2,VV[105]->s.s_gfdef,VV[0])       /*  FIND-CLASS      */;
	funcall(9,VV[62]->s.s_gfdef,VALUES(0),VV[33],VV[34],Cnil,Cnil,Cnil,Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[105]->s.s_gfdef,VV[33])      /*  FIND-CLASS      */;
	MF0(VV[106],L1);
	(void)putprop(VV[106],VV[Vdeb106],VV[107]);
	VV[108] = make_cfun(LC2,Cnil,&Cblock);
	VALUES(0) = VV[108];
	funcall(8,VV[109]->s.s_gfdef,VV[41],Cnil,VV[42],VV[43],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[110] = make_cfun(LC3,Cnil,&Cblock);
	VALUES(0) = VV[110];
	funcall(8,VV[109]->s.s_gfdef,VV[44],Cnil,VV[45],VV[46],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	funcall(2,VV[105]->s.s_gfdef,VV[47])      /*  FIND-CLASS      */;
	funcall(9,VV[62]->s.s_gfdef,VALUES(0),VV[48],VV[49],Cnil,Cnil,VV[50],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	VV[111] = make_cfun(LC4,Cnil,&Cblock);
	VALUES(0) = VV[111];
	funcall(8,VV[109]->s.s_gfdef,VV[51],Cnil,VV[52],VV[53],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[112] = make_cfun(LC5,Cnil,&Cblock);
	VALUES(0) = VV[112];
	funcall(8,VV[109]->s.s_gfdef,VV[55],Cnil,VV[56],VV[57],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	funcall(2,VV[105]->s.s_gfdef,VV[48])      /*  FIND-CLASS      */;
	VV[113] = make_cfun(LC6,Cnil,&Cblock);
	VALUES(0) = VV[113];
	funcall(8,VV[109]->s.s_gfdef,VV[59],Cnil,VV[60],VV[61],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[114] = make_cfun(LC9,Cnil,&Cblock);
	VALUES(0) = VV[114];
	funcall(8,VV[109]->s.s_gfdef,VV[62],Cnil,VV[63],VV[64],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[115] = make_cfun(LC10,Cnil,&Cblock);
	VALUES(0) = VV[115];
	funcall(8,VV[109]->s.s_gfdef,VV[41],Cnil,VV[73],VV[74],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	funcall(2,VV[105]->s.s_gfdef,VV[48])      /*  FIND-CLASS      */;
	funcall(9,VV[62]->s.s_gfdef,VALUES(0),VV[75],VV[76],VV[77],Cnil,VV[78],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	VV[116] = make_cfun(LC11,Cnil,&Cblock);
	VALUES(0) = VV[116];
	funcall(8,VV[109]->s.s_gfdef,VV[51],Cnil,VV[79],VV[53],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[117] = make_cfun(LC12,Cnil,&Cblock);
	VALUES(0) = VV[117];
	funcall(8,VV[109]->s.s_gfdef,VV[55],Cnil,VV[80],VV[57],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	funcall(2,VV[105]->s.s_gfdef,VV[75])      /*  FIND-CLASS      */;
	VV[118] = make_cfun(LC13,Cnil,&Cblock);
	VALUES(0) = VV[118];
	funcall(8,VV[109]->s.s_gfdef,VV[41],Cnil,VV[81],VV[82],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[119] = make_cfun(LC16,Cnil,&Cblock);
	VALUES(0) = VV[119];
	funcall(8,VV[109]->s.s_gfdef,VV[84],Cnil,VV[85],VV[86],Cnil,VV[87],VALUES(0))/*  INSTALL-METHOD*/;
	funcall(2,VV[105]->s.s_gfdef,VV[91])      /*  FIND-CLASS      */;
	T0= VALUES(0);
	funcall(2,VV[105]->s.s_gfdef,Ct)          /*  FIND-CLASS      */;
	funcall(18,VV[41]->s.s_gfdef,T0,VV[66],VV[92],VV[67],CONS(VALUES(0),Cnil),VV[68],Cnil,VV[69],Cnil,VV[93],Cnil,VV[94],Cnil,VV[95],Cnil,VV[96],VV[97])/*  MAKE-INSTANCE*/;
	VV[120] = make_cfun(LC17,Cnil,&Cblock);
	VALUES(0) = VV[120];
	funcall(8,VV[109]->s.s_gfdef,VV[98],Cnil,VV[99],VV[100],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	local function CLOSURE                                        */
static LC17(int narg, object V1, object V2)
{ VT3 VLEX3 CLSR3
	{object V3;                               /*  CLASS           */
	object V4;                                /*  SLOTDS          */
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	V3= VALUES(0);
	V4= ((V3))->in.in_slots[3];
	princ(VV[101],(V2));
	prin1(((V3))->in.in_slots[0],(V2));
	{register object V5;                      /*  SCAN            */
	register int V6;                          /*  I               */
	object V7;                                /*  SV              */
	V6= 0;
	V5= (V4);
	V7= Cnil;
L92:
	if(((V5))!=Cnil){
	goto L93;}
	goto L89;
L93:
	siLinstance_ref(2,(V1),MAKE_FIXNUM(V6))   /*  INSTANCE-REF    */;
	V7= VALUES(0);
	princ(VV[102],(V2));
	{object V9= CAR((V5));
	VALUES(0) = CAR(V9);}
	prin1(VALUES(0),(V2));
	princ(VV[103],(V2));
	prin1((V7),(V2));
	V5= CDR((V5));
	V6= (V6)+1;
	goto L92;
	}
L89:
	princ(VV[104],(V2));
	VALUES(0) = (V1);
	RETURN(1);
	}
}
/*	local function CLOSURE                                        */
static LC16(int narg, object V1, ...)
{ VT4 VLEX4 CLSR4
	{object V2;
	va_list args; va_start(args, V1);
	lex0[0]=V1;
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	lex0[1]=V2;
	{object V3;
	object V4;
	V3= CAR((VV[88]->s.s_dbind));
	V4= CDR((VV[88]->s.s_dbind));
	lex0[2]=V3;                               /*  .NEXT-METHOD.   */
	bds_bind(VV[88],V4);                      /*  *NEXT-METHODS*  */
	{ int V5, i=0;
	T0= lex0[0];
	T1= lex0[1];
	V5=length(T1);
	VALUES(i++)=T0;
	V5+=i;
	for (; i<V5;i++,T1=CDR(T1))
		VALUES(i)=CAR(T1);
	{ 
	object *args = &VALUES(1);
	object V6;
	int narg = V5;
	V6=VALUES(0);
	narg -=1;
	{ object keyvars[0];
	parse_key(narg,args,0,L14keys,keyvars,OBJNULL,TRUE);
	}
	LC15(lex0,0)                              /*  CALL-NEXT-METHOD*/;
	if(!((((V6))->in.in_slots[0])!=OBJNULL)){
	goto L113;}
	L1(2,((V6))->in.in_slots[0],(V6))         /*  SETF-FIND-CLASS */;
L113:
	{register object V7;
	object V8;                                /*  S               */
	V7= ((V6))->in.in_slots[1];
	V8= Cnil;
L120:
	if(!((V7)==Cnil)){
	goto L121;}
	goto L116;
L121:
	V8= CAR((V7));
	{int V10;
	V10= 2;
	siLinstance_ref(2,(V8),MAKE_FIXNUM(V10))  /*  INSTANCE-REF    */;
	siLinstance_set(3,(V8),MAKE_FIXNUM(V10),CONS((V6),VALUES(0)))/*  INSTANCE-SET*/;
	}
	V7= CDR((V7));
	goto L120;
	}
L116:
	{object V7;
	(*LK0)(2,(V6),VV[89])                     /*  SLOT-VALUE      */;
	V7= CONS((V6),VALUES(0));
	(*LK1)(3,(V7),(V6),VV[89])                /*  (SETF SLOT-VALUE)*/;
	}
	{int V7;
	VALUES(0)=(V6);
	V7=1;
	bds_unwind1;
	RETURN(V7);}
	}
	}
	}
	}
}
/*	local function CLOSURE                                        */
static LC13(int narg, object V1, ...)
{ VT5 VLEX5 CLSR5
	RETURN(Lerror(2,VV[83],(V1))              /*  ERROR           */);
}
/*	local function CLOSURE                                        */
static LC12(int narg, object V1, object V2, object V3)
{ VT6 VLEX6 CLSR6
	if(((V3)!= VV[122]))goto L135;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(0),(V1))/*  INSTANCE-SET*/);
L135:
	if(((V3)!= VV[123]))goto L136;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(1),(V1))/*  INSTANCE-SET*/);
L136:
	if(((V3)!= VV[124]))goto L137;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(2),(V1))/*  INSTANCE-SET*/);
L137:
	if(((V3)!= VV[71]))goto L138;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(3),(V1))/*  INSTANCE-SET*/);
L138:
	if(((V3)!= VV[89]))goto L139;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(4),(V1))/*  INSTANCE-SET*/);
L139:
	if(((V3)!= VV[125]))goto L140;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(5),(V1))/*  INSTANCE-SET*/);
L140:
	if(((V3)!= VV[126]))goto L141;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(6),(V1))/*  INSTANCE-SET*/);
L141:
	if(((V3)!= VV[127]))goto L142;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(7),(V1))/*  INSTANCE-SET*/);
L142:
	if(((V3)!= VV[128]))goto L143;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(8),(V1))/*  INSTANCE-SET*/);
L143:
	if(((V3)!= VV[72]))goto L144;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(9),(V1))/*  INSTANCE-SET*/);
L144:
	if(((V3)!= VV[129]))goto L145;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(10),(V1))/*  INSTANCE-SET*/);
L145:
	if(((V3)!= VV[130]))goto L146;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(11),(V1))/*  INSTANCE-SET*/);
L146:
	if(((V3)!= VV[131]))goto L147;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(12),(V1))/*  INSTANCE-SET*/);
L147:
	siLinstance_class(1,(V2))                 /*  INSTANCE-CLASS  */;
	RETURN((*LK2)(5,VALUES(0),(V2),(V3),(V1),VV[58])/*  SLOT-MISSING*/);
}
/*	local function CLOSURE                                        */
static LC11(int narg, object V1, object V2)
{ VT7 VLEX7 CLSR7
	if(((V2)!= VV[122]))goto L149;
	{object V3;                               /*  VAL             */
	V3= ((V1))->in.in_slots[0];
	if(!(((V3))!=OBJNULL)){
	goto L152;}
	VALUES(0) = (V3);
	RETURN(1);
L152:
	VALUES(0) = VV[54];
	RETURN(1);
	}
L149:
	if(((V2)!= VV[123]))goto L154;
	{object V4;                               /*  VAL             */
	V4= ((V1))->in.in_slots[1];
	if(!(((V4))!=OBJNULL)){
	goto L157;}
	VALUES(0) = (V4);
	RETURN(1);
L157:
	VALUES(0) = VV[54];
	RETURN(1);
	}
L154:
	if(((V2)!= VV[124]))goto L159;
	{object V5;                               /*  VAL             */
	V5= ((V1))->in.in_slots[2];
	if(!(((V5))!=OBJNULL)){
	goto L162;}
	VALUES(0) = (V5);
	RETURN(1);
L162:
	VALUES(0) = VV[54];
	RETURN(1);
	}
L159:
	if(((V2)!= VV[71]))goto L164;
	{object V6;                               /*  VAL             */
	V6= ((V1))->in.in_slots[3];
	if(!(((V6))!=OBJNULL)){
	goto L167;}
	VALUES(0) = (V6);
	RETURN(1);
L167:
	VALUES(0) = VV[54];
	RETURN(1);
	}
L164:
	if(((V2)!= VV[89]))goto L169;
	{object V7;                               /*  VAL             */
	V7= ((V1))->in.in_slots[4];
	if(!(((V7))!=OBJNULL)){
	goto L172;}
	VALUES(0) = (V7);
	RETURN(1);
L172:
	VALUES(0) = VV[54];
	RETURN(1);
	}
L169:
	if(((V2)!= VV[125]))goto L174;
	{object V8;                               /*  VAL             */
	V8= ((V1))->in.in_slots[5];
	if(!(((V8))!=OBJNULL)){
	goto L177;}
	VALUES(0) = (V8);
	RETURN(1);
L177:
	VALUES(0) = VV[54];
	RETURN(1);
	}
L174:
	if(((V2)!= VV[126]))goto L179;
	{object V9;                               /*  VAL             */
	V9= ((V1))->in.in_slots[6];
	if(!(((V9))!=OBJNULL)){
	goto L182;}
	VALUES(0) = (V9);
	RETURN(1);
L182:
	VALUES(0) = VV[54];
	RETURN(1);
	}
L179:
	if(((V2)!= VV[127]))goto L184;
	{object V10;                              /*  VAL             */
	V10= ((V1))->in.in_slots[7];
	if(!(((V10))!=OBJNULL)){
	goto L187;}
	VALUES(0) = (V10);
	RETURN(1);
L187:
	VALUES(0) = VV[54];
	RETURN(1);
	}
L184:
	if(((V2)!= VV[128]))goto L189;
	{object V11;                              /*  VAL             */
	V11= ((V1))->in.in_slots[8];
	if(!(((V11))!=OBJNULL)){
	goto L192;}
	VALUES(0) = (V11);
	RETURN(1);
L192:
	VALUES(0) = VV[54];
	RETURN(1);
	}
L189:
	if(((V2)!= VV[72]))goto L194;
	{object V12;                              /*  VAL             */
	V12= ((V1))->in.in_slots[9];
	if(!(((V12))!=OBJNULL)){
	goto L197;}
	VALUES(0) = (V12);
	RETURN(1);
L197:
	VALUES(0) = VV[54];
	RETURN(1);
	}
L194:
	if(((V2)!= VV[129]))goto L199;
	{object V13;                              /*  VAL             */
	V13= ((V1))->in.in_slots[10];
	if(!(((V13))!=OBJNULL)){
	goto L202;}
	VALUES(0) = (V13);
	RETURN(1);
L202:
	VALUES(0) = VV[54];
	RETURN(1);
	}
L199:
	if(((V2)!= VV[130]))goto L204;
	{object V14;                              /*  VAL             */
	V14= ((V1))->in.in_slots[11];
	if(!(((V14))!=OBJNULL)){
	goto L207;}
	VALUES(0) = (V14);
	RETURN(1);
L207:
	VALUES(0) = VV[54];
	RETURN(1);
	}
L204:
	if(((V2)!= VV[131]))goto L209;
	{object V15;                              /*  VAL             */
	V15= ((V1))->in.in_slots[12];
	if(!(((V15))!=OBJNULL)){
	goto L212;}
	VALUES(0) = (V15);
	RETURN(1);
L212:
	VALUES(0) = VV[54];
	RETURN(1);
	}
L209:
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	RETURN((*LK2)(4,VALUES(0),(V1),(V2),VV[51])/*  SLOT-MISSING   */);
}
/*	local function CLOSURE                                        */
static LC10(int narg, object V1, ...)
{ VT8 VLEX8 CLSR8
	{object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{object V3;                               /*  INSTANCE        */
	(*LK3)(1,(V1))                            /*  ALLOCATE-INSTANCE*/;
	V3= VALUES(0);
	VALUES(0) = (VV[84]->s.s_gfdef);
	Lapply(3,VALUES(0),(V3),(V2))             /*  APPLY           */;
	VALUES(0) = (V3);
	RETURN(1);
	}
	}
}
/*	local function CLOSURE                                        */
static LC9(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8)
{ VT9 VLEX9 CLSR9
	lex0[0]=V1;                               /*  METACLASS       */
	lex0[1]=V3;                               /*  SUPERCLASSES-NAMES*/
	lex0[2]=V6;                               /*  ALL-SLOTS       */
	lex0[3]=V8;                               /*  DOCUMENTATION   */
	if(((V5))==Cnil){
	goto L218;}
	Lerror(2,VV[65],(V2))                     /*  ERROR           */;
L218:
	{object V9;                               /*  SUPERCLASSES    */
	object V10;                               /*  CPL             */
	(*LK4)(2,(V2),Cnil)                       /*  FIND-CLASS      */;
	lex0[4]=VALUES(0);                        /*  EXISTING        */
	T1=VV[105]->s.s_gfdef;
	{object V11;
	object V12= lex0[1];
	if(V12==Cnil){
	V9= Cnil;
	goto L222;}
	T0=V11=CONS(Cnil,Cnil);
L223:
	(*LK4)(1,CAR(V12))                        /*  FIND-CLASS      */;
	CAR(V11)= VALUES(0);
	if((V12=CDR(V12))==Cnil){
	V9= T0;
	goto L222;}
	V11=CDR(V11)=CONS(Cnil,Cnil);
	goto L223;}
L222:
	(*LK5)(2,(V2),(V9))                       /*  COMPUTE-CLASS-PRECEDENCE-LIST*/;
	V10= VALUES(0);
	LC8(lex0,0)                               /*  UNCHANGED-CLASS */;
	if(VALUES(0)==Cnil){
	goto L227;}
	VALUES(0) = lex0[4];
	RETURN(1);
L227:
	RETURN((*LK6)(9,lex0[0],VV[66],(V2),VV[67],(V9),VV[68],lex0[2],VV[69],(V10))/*  MAKE-INSTANCE*/);
	}
}
/*	local function CLOSURE                                        */
static LC6(int narg, object V1, object V2, object V3, object V4)
{ VT10 VLEX10 CLSR10
	{object V5;                               /*  SUPERCLASSES    */
	T1=VV[105]->s.s_gfdef;
	{object V6;
	object V7= (V4);
	if(V7==Cnil){
	V5= Cnil;
	goto L229;}
	T0=V6=CONS(Cnil,Cnil);
L230:
	(*LK4)(1,CAR(V7))                         /*  FIND-CLASS      */;
	CAR(V6)= VALUES(0);
	if((V7=CDR(V7))==Cnil){
	V5= T0;
	goto L229;}
	V6=CDR(V6)=CONS(Cnil,Cnil);
	goto L230;}
L229:
	(*LK5)(2,(V3),(V5))                       /*  COMPUTE-CLASS-PRECEDENCE-LIST*/;
	RETURN((*LK7)(2,VALUES(0),(V2))           /*  COLLECT-SLOTDS  */);
	}
}
/*	local function CLOSURE                                        */
static LC5(int narg, object V1, object V2, object V3)
{ VT11 VLEX11 CLSR11
	if(((V3)!= VV[122]))goto L233;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(0),(V1))/*  INSTANCE-SET*/);
L233:
	if(((V3)!= VV[123]))goto L234;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(1),(V1))/*  INSTANCE-SET*/);
L234:
	if(((V3)!= VV[124]))goto L235;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(2),(V1))/*  INSTANCE-SET*/);
L235:
	if(((V3)!= VV[71]))goto L236;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(3),(V1))/*  INSTANCE-SET*/);
L236:
	siLinstance_class(1,(V2))                 /*  INSTANCE-CLASS  */;
	RETURN((*LK2)(5,VALUES(0),(V2),(V3),(V1),VV[58])/*  SLOT-MISSING*/);
}
/*	local function CLOSURE                                        */
static LC4(int narg, object V1, object V2)
{ VT12 VLEX12 CLSR12
	if(((V2)!= VV[122]))goto L238;
	{object V3;                               /*  VAL             */
	V3= ((V1))->in.in_slots[0];
	if(!(((V3))!=OBJNULL)){
	goto L241;}
	VALUES(0) = (V3);
	RETURN(1);
L241:
	VALUES(0) = VV[54];
	RETURN(1);
	}
L238:
	if(((V2)!= VV[123]))goto L243;
	{object V4;                               /*  VAL             */
	V4= ((V1))->in.in_slots[1];
	if(!(((V4))!=OBJNULL)){
	goto L246;}
	VALUES(0) = (V4);
	RETURN(1);
L246:
	VALUES(0) = VV[54];
	RETURN(1);
	}
L243:
	if(((V2)!= VV[124]))goto L248;
	{object V5;                               /*  VAL             */
	V5= ((V1))->in.in_slots[2];
	if(!(((V5))!=OBJNULL)){
	goto L251;}
	VALUES(0) = (V5);
	RETURN(1);
L251:
	VALUES(0) = VV[54];
	RETURN(1);
	}
L248:
	if(((V2)!= VV[71]))goto L253;
	{object V6;                               /*  VAL             */
	V6= ((V1))->in.in_slots[3];
	if(!(((V6))!=OBJNULL)){
	goto L256;}
	VALUES(0) = (V6);
	RETURN(1);
L256:
	VALUES(0) = VV[54];
	RETURN(1);
	}
L253:
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	RETURN((*LK2)(4,VALUES(0),(V1),(V2),VV[51])/*  SLOT-MISSING   */);
}
/*	local function CLOSURE                                        */
static LC3(int narg, object V1, object V2)
{ VT13 VLEX13 CLSR13
	(*LK4)(1,(V2))                            /*  FIND-CLASS      */;
	RETURN((*LK8)(2,(V1),VALUES(0))           /*  CHANGE-CLASS    */);
}
/*	local function CLOSURE                                        */
static LC2(int narg, object V1, ...)
{ VT14 VLEX14 CLSR14
	{object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	T0= (VV[41]->s.s_gfdef);
	(*LK4)(1,(V1))                            /*  FIND-CLASS      */;
	RETURN(Lapply(3,T0,VALUES(0),(V2))        /*  APPLY           */);
	}
}
/*	local function CALL-NEXT-METHOD                               */
static LC15(object *lex0,int narg, ...)
{ VT15 VLEX15 CLSR15
	{object V1;
	va_list args; va_start(args, narg);
	narg -=0;
	V1=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V1;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	if((lex0[2])==Cnil){
	goto L263;}
	if(((V1))==Cnil){
	goto L266;}
	RETURN(Lapply(2,lex0[2],(V1))             /*  APPLY           */);
L266:
	RETURN(Lapply(3,lex0[2],lex0[0],lex0[1])  /*  APPLY           */);
L263:
	RETURN(Lerror(1,VV[90])                   /*  ERROR           */);
	}
}
/*	local function UNCHANGED-CLASS                                */
static LC8(object *lex0,int narg)
{ VT16 VLEX16 CLSR16
TTL:
	if((lex0[4])==Cnil){
	goto L269;}
	siLinstance_class(1,lex0[4])              /*  INSTANCE-CLASS  */;
	if(!((lex0[0])==(VALUES(0)))){
	goto L272;}
	{object V1;
	if((lex0[1])==Cnil){
	goto L280;}
	T0= lex0[1];
	goto L278;
L280:
	T0= VV[70];
	}
L278:
	{object V1;
	object V2= (lex0[4])->in.in_slots[1];
	if(V2==Cnil){
	VALUES(0) = Cnil;
	goto L282;}
	T1=V1=CONS(Cnil,Cnil);
L283:
	{object V3;                               /*  X               */
	CAR(V1)= (CAR(V2))->in.in_slots[0];
	}
	if((V2=CDR(V2))==Cnil){
	VALUES(0) = T1;
	goto L282;}
	V1=CDR(V1)=CONS(Cnil,Cnil);
	goto L283;}
L282:
	if(!(equal(T0,VALUES(0)))){
	goto L276;}
	(*LK0)(2,lex0[4],VV[71])                  /*  SLOT-VALUE      */;
	if(!(equal(lex0[2],VALUES(0)))){
	goto L286;}
	(*LK1)(3,lex0[3],lex0[4],VV[72])          /*  (SETF SLOT-VALUE)*/;
	{object V1;
	VALUES(0) = Ct;
	RETURN(1);
	}
L286:
	VALUES(0) = Cnil;
	RETURN(1);
L276:
	VALUES(0) = Cnil;
	RETURN(1);
L272:
	VALUES(0) = Cnil;
	RETURN(1);
L269:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for SETF-FIND-CLASS                       */
static L1(int narg, object V1, object V2)
{ VT17 VLEX17 CLSR17
TTL:
	{register object x= (V1),V3= VV[35];
	while(V3!=Cnil)
	if(eql(x, CAR(V3))){
	goto L292;
	}else V3=CDR(V3);
	goto L291;}
L292:
	RETURN(Lerror(2,VV[36],(V1))              /*  ERROR           */);
L291:
	{register object x= (V1),V3= VV[37];
	while(V3!=Cnil)
	if(eql(x, CAR(V3))){
	goto L295;
	}else V3=CDR(V3);
	goto L294;}
L295:
	RETURN(Lerror(2,VV[38],(V1))              /*  ERROR           */);
L294:
	(*LK9)(1,(V2))                            /*  CLASSP          */;
	if(VALUES(0)==Cnil){
	goto L297;}
	RETURN(siLhash_set(3,(V1),(VV[39]->s.s_dbind),(V2))/*  HASH-SET*/);
L297:
	if(((V2))!=Cnil){
	goto L300;}
	RETURN(Lremhash(2,(V1),(VV[39]->s.s_dbind))/*  REMHASH        */);
L300:
	RETURN(Lerror(2,VV[40],(V2))              /*  ERROR           */);
}
static LKF9(int narg, ...) {TRAMPOLINK(VV[136],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[44],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[135],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[41],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[134],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[105],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[133],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[132],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[121],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[51],&LK0);}
