
#include "macros.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	VV[0]->s.s_stype=(short)stp_special;
	MM0(VV[414],L1);
	MM0(VV[415],L2);
	MM0(VV[416],L3);
	MF0(VV[417],L4);
	(void)putprop(VV[417],VV[Vdeb417],VV[418]);
	MF0(VV[419],L5);
	(void)putprop(VV[419],VV[Vdeb419],VV[418]);
	MF0(VV[420],L6);
	(void)putprop(VV[420],VV[Vdeb420],VV[418]);
	(void)putprop(VV[22],VV[28],siSpretty_print_format);
	
	MM0(VV[22],L7);
	putprop(VV[29],MAKE_FIXNUM(4),VV[10]);
	MM0(VV[421],L8);
	MM0(VV[422],L9);
	putprop(VV[32],MAKE_FIXNUM(4),VV[10]);
	MM0(VV[423],L10);
	MM0(VV[424],L11);
	putprop(VV[35],MAKE_FIXNUM(2),VV[10]);
	MM0(VV[104],L12);
	MM0(VV[425],L13);
	putprop(VV[38],MAKE_FIXNUM(1),VV[10]);
	MM0(VV[426],L14);
	MM0(VV[427],L15);
	putprop(VV[41],MAKE_FIXNUM(4),VV[10]);
	MM0(VV[428],L16);
	MM0(VV[429],L17);
	putprop(VV[44],MAKE_FIXNUM(2),VV[10]);
	MM0(VV[98],L18);
	MM0(VV[430],L19);
	putprop(VV[47],MAKE_FIXNUM(2),VV[10]);
	MM0(VV[431],L20);
	MM0(VV[432],L21);
	putprop(VV[50],MAKE_FIXNUM(2),VV[10]);
	MM0(VV[433],L22);
	MM0(VV[434],L23);
	putprop(VV[53],MAKE_FIXNUM(0),VV[10]);
	MM0(VV[435],L24);
	MM0(VV[436],L25);
	putprop(VV[60],MAKE_FIXNUM(1),VV[10]);
	MM0(VV[437],L26);
	MM0(VV[438],L27);
	putprop(VV[63],MAKE_FIXNUM(4),VV[10]);
	MM0(VV[439],L28);
	MM0(VV[440],L29);
	putprop(VV[67],MAKE_FIXNUM(4),VV[10]);
	MM0(VV[441],L30);
	MM0(VV[442],L31);
	putprop(VV[70],MAKE_FIXNUM(4),VV[10]);
	MM0(VV[443],L32);
	MM0(VV[444],L33);
	putprop(VV[73],MAKE_FIXNUM(4),VV[10]);
	MM0(VV[445],L34);
	MM0(VV[446],L35);
	putprop(VV[76],MAKE_FIXNUM(4),VV[10]);
	MM0(VV[447],L36);
	MM0(VV[448],L37);
	putprop(VV[79],MAKE_FIXNUM(4),VV[10]);
	MM0(VV[449],L38);
	MM0(VV[450],L39);
	putprop(VV[82],MAKE_FIXNUM(4),VV[10]);
	MM0(VV[451],L40);
	MM0(VV[452],L41);
	putprop(VV[85],MAKE_FIXNUM(4),VV[10]);
	MM0(VV[453],L42);
	MM0(VV[454],L43);
	putprop(VV[90],MAKE_FIXNUM(4),VV[10]);
	MM0(VV[455],L44);
	MM0(VV[456],L45);
	putprop(VV[91],MAKE_FIXNUM(4),VV[10]);
	MM0(VV[457],L46);
	MM0(VV[458],L47);
	MM0(VV[459],L48);
	putprop(VV[105],MAKE_FIXNUM(1),VV[10]);
	MM0(VV[132],L49);
	MM0(VV[133],L50);
	putprop(VV[105],Ct,VV[111]);
	MM0(VV[460],L51);
	putprop(VV[113],MAKE_FIXNUM(2),VV[10]);
	MM0(VV[129],L52);
	MM0(VV[130],L53);
	putprop(VV[113],Ct,VV[111]);
	MM0(VV[461],L54);
	putprop(VV[116],MAKE_FIXNUM(4),VV[10]);
	MM0(VV[126],L55);
	MM0(VV[127],L56);
	putprop(VV[116],Ct,VV[111]);
	MM0(VV[462],L57);
	putprop(VV[120],VV[122],VV[121]);
	VV[463] = make_cfun(LC58,Cnil,&Cblock);
	VALUES(0) = VV[463];
	putprop(VV[120],VALUES(0),VV[123]);
	putprop(VV[120],Cnil,VV[125]);
	putprop(VV[120],MAKE_FIXNUM(4),VV[10]);
	MM0(VV[464],L59);
	MM0(VV[465],L60);
	putprop(VV[120],Ct,VV[111]);
	MM0(VV[466],L61);
	putprop(VV[128],MAKE_FIXNUM(2),VV[10]);
	MM0(VV[467],L62);
	MM0(VV[468],L63);
	putprop(VV[128],Ct,VV[111]);
	MM0(VV[469],L64);
	putprop(VV[131],MAKE_FIXNUM(1),VV[10]);
	MM0(VV[470],L65);
	MM0(VV[471],L66);
	putprop(VV[131],Ct,VV[111]);
	MM0(VV[472],L67);
	putprop(VV[134],MAKE_FIXNUM(4),VV[10]);
	VV[135]=string_to_object(VV[135]);
	MM0(VV[473],L68);
	MM0(VV[474],L69);
	putprop(VV[134],Ct,VV[111]);
	MM0(VV[475],L70);
	putprop(VV[139],MAKE_FIXNUM(4),VV[10]);
	MM0(VV[476],L71);
	MM0(VV[477],L72);
	putprop(VV[141],MAKE_FIXNUM(1),VV[10]);
	MM0(VV[478],L73);
	MM0(VV[479],L74);
	putprop(VV[142],MAKE_FIXNUM(2),VV[10]);
	MM0(VV[480],L75);
	MM0(VV[481],L76);
	putprop(VV[143],MAKE_FIXNUM(32),VV[10]);
	MM0(VV[482],L77);
	MM0(VV[483],L78);
	putprop(VV[148],Cnil,VV[10]);
	MM0(VV[484],L79);
	MM0(VV[485],L80);
	putprop(VV[156],Cnil,VV[10]);
	MM0(VV[486],L81);
	MM0(VV[166],L82);
	MM0(VV[487],L84);
	MM0(VV[175],L85);
	putprop(VV[173],MAKE_FIXNUM(20),VV[10]);
	MM0(VV[488],L86);
	MM0(VV[489],L87);
	putprop(VV[176],MAKE_FIXNUM(0),VV[10]);
	MM0(VV[490],L88);
	MM0(VV[491],L89);
	putprop(VV[176],Ct,VV[111]);
	MM0(VV[492],L90);
	putprop(VV[152],MAKE_FIXNUM(0),VV[10]);
	MM0(VV[493],L91);
	MM0(VV[494],L92);
	putprop(VV[152],Ct,VV[111]);
	MM0(VV[495],L93);
	putprop(VV[179],VV[180],VV[121]);
	VV[496] = make_cfun(LC94,Cnil,&Cblock);
	VALUES(0) = VV[496];
	putprop(VV[179],VALUES(0),VV[123]);
	putprop(VV[179],Cnil,VV[125]);
	putprop(VV[179],MAKE_FIXNUM(0),VV[10]);
	MM0(VV[497],L95);
	MM0(VV[498],L96);
	putprop(VV[179],Ct,VV[111]);
	MM0(VV[499],L97);
	MM0(VV[191],L98);
	putprop(VV[87],MAKE_FIXNUM(4),VV[10]);
	MM0(VV[500],L101);
	MM0(VV[501],L102);
	putprop(VV[193],Cnil,VV[10]);
	MF0(VV[502],L103);
	(void)putprop(VV[502],VV[Vdeb502],VV[418]);
	MF0(VV[503],L106);
	(void)putprop(VV[503],VV[Vdeb503],VV[418]);
	putprop(VV[1],Cnil,VV[10]);
	MM0(VV[504],L108);
	MM0(VV[505],L109);
	MM0(VV[208],L110);
	MM0(VV[210],L111);
	VV[506] = make_cfun(LC113,Cnil,&Cblock);
	MF0(VV[507],L112);
	(void)putprop(VV[507],VV[Vdeb507],VV[418]);
	(void)putprop(VV[226],VV[220],siSpretty_print_format);
	
	MM0(VV[226],L114);
	(void)putprop(VV[508],VV[220],siSpretty_print_format);
	
	MM0(VV[508],L115);
	(void)putprop(VV[509],VV[28],siSpretty_print_format);
	
	MM0(VV[509],L116);
	(void)putprop(VV[510],VV[220],siSpretty_print_format);
	
	MM0(VV[510],L117);
	(void)putprop(VV[511],VV[220],siSpretty_print_format);
	
	MM0(VV[511],L118);
	MM0(VV[269],L119);
	MM0(VV[268],L120);
	MM0(VV[270],L121);
	putprop(VV[269],VV[270],VV[271]);
	remprop(VV[269],VV[272]);
	remprop(VV[269],VV[273]);
	putprop(VV[269],Cnil,VV[274]);
	siLAmake_constant(2,VV[275],MAKE_FIXNUM(1))/*  *MAKE-CONSTANT */;
	siLAmake_constant(2,VV[276],MAKE_FIXNUM(2))/*  *MAKE-CONSTANT */;
	siLAmake_constant(2,VV[277],MAKE_FIXNUM(3))/*  *MAKE-CONSTANT */;
	siLAmake_constant(2,VV[278],MAKE_FIXNUM(4))/*  *MAKE-CONSTANT */;
	siLAmake_constant(2,VV[279],MAKE_FIXNUM(5))/*  *MAKE-CONSTANT */;
	siLAmake_constant(2,VV[280],MAKE_FIXNUM(6))/*  *MAKE-CONSTANT */;
	siLAmake_constant(2,VV[281],MAKE_FIXNUM(7))/*  *MAKE-CONSTANT */;
	siLAmake_constant(2,VV[282],MAKE_FIXNUM(8))/*  *MAKE-CONSTANT */;
	siLAmake_constant(2,VV[283],MAKE_FIXNUM(9))/*  *MAKE-CONSTANT */;
	siLAmake_constant(2,VV[284],MAKE_FIXNUM(10))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[285],MAKE_FIXNUM(11))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[286],MAKE_FIXNUM(12))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[287],MAKE_FIXNUM(13))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[288],MAKE_FIXNUM(14))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[289],MAKE_FIXNUM(15))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[290],MAKE_FIXNUM(16))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[291],MAKE_FIXNUM(17))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[292],MAKE_FIXNUM(18))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[293],MAKE_FIXNUM(19))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[294],MAKE_FIXNUM(20))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[295],MAKE_FIXNUM(21))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[296],MAKE_FIXNUM(22))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[297],MAKE_FIXNUM(23))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[298],MAKE_FIXNUM(24))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[299],MAKE_FIXNUM(25))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[300],MAKE_FIXNUM(26))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[301],MAKE_FIXNUM(27))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[302],MAKE_FIXNUM(28))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[303],MAKE_FIXNUM(29))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[304],MAKE_FIXNUM(30))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[305],MAKE_FIXNUM(31))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[306],MAKE_FIXNUM(32))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[307],MAKE_FIXNUM(33))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[308],MAKE_FIXNUM(34))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[309],MAKE_FIXNUM(35))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[310],MAKE_FIXNUM(36))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[311],MAKE_FIXNUM(37))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[312],MAKE_FIXNUM(38))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[313],MAKE_FIXNUM(39))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[314],MAKE_FIXNUM(40))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[315],MAKE_FIXNUM(41))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[316],MAKE_FIXNUM(42))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[317],MAKE_FIXNUM(43))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[318],MAKE_FIXNUM(44))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[319],MAKE_FIXNUM(45))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[320],MAKE_FIXNUM(46))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[321],MAKE_FIXNUM(47))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[322],MAKE_FIXNUM(48))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[323],MAKE_FIXNUM(49))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[324],MAKE_FIXNUM(50))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[325],MAKE_FIXNUM(51))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[326],MAKE_FIXNUM(52))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[327],MAKE_FIXNUM(53))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[328],MAKE_FIXNUM(54))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[329],MAKE_FIXNUM(55))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[330],MAKE_FIXNUM(56))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[331],MAKE_FIXNUM(57))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[332],MAKE_FIXNUM(58))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[333],MAKE_FIXNUM(59))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[334],MAKE_FIXNUM(60))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[335],MAKE_FIXNUM(61))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[336],MAKE_FIXNUM(62))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[337],MAKE_FIXNUM(63))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[338],MAKE_FIXNUM(64))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[339],MAKE_FIXNUM(65))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[340],MAKE_FIXNUM(66))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[341],MAKE_FIXNUM(67))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[342],MAKE_FIXNUM(68))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[343],MAKE_FIXNUM(69))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[344],MAKE_FIXNUM(70))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[345],MAKE_FIXNUM(71))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[346],MAKE_FIXNUM(72))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[347],MAKE_FIXNUM(73))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[348],MAKE_FIXNUM(74))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[349],MAKE_FIXNUM(75))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[350],MAKE_FIXNUM(76))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[351],MAKE_FIXNUM(77))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[352],MAKE_FIXNUM(78))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[353],MAKE_FIXNUM(79))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[354],MAKE_FIXNUM(80))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[355],MAKE_FIXNUM(81))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[356],MAKE_FIXNUM(82))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[357],MAKE_FIXNUM(83))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[358],MAKE_FIXNUM(84))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[359],MAKE_FIXNUM(85))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[360],MAKE_FIXNUM(86))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[361],MAKE_FIXNUM(87))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[362],MAKE_FIXNUM(88))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[363],MAKE_FIXNUM(89))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[364],MAKE_FIXNUM(90))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[365],MAKE_FIXNUM(91))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[366],MAKE_FIXNUM(92))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[367],MAKE_FIXNUM(93))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[368],MAKE_FIXNUM(94))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[369],MAKE_FIXNUM(95))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[370],MAKE_FIXNUM(96))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[371],MAKE_FIXNUM(97))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[372],MAKE_FIXNUM(98))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[373],MAKE_FIXNUM(99))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[374],MAKE_FIXNUM(100))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[375],MAKE_FIXNUM(101))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[376],MAKE_FIXNUM(102))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[377],MAKE_FIXNUM(103))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[378],MAKE_FIXNUM(104))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[379],MAKE_FIXNUM(105))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[380],MAKE_FIXNUM(106))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[381],MAKE_FIXNUM(107))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[382],MAKE_FIXNUM(108))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[383],MAKE_FIXNUM(109))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[384],MAKE_FIXNUM(110))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[385],MAKE_FIXNUM(111))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[386],MAKE_FIXNUM(112))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[387],MAKE_FIXNUM(113))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[388],MAKE_FIXNUM(114))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[389],MAKE_FIXNUM(115))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[390],MAKE_FIXNUM(116))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[391],MAKE_FIXNUM(117))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[392],MAKE_FIXNUM(118))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[393],MAKE_FIXNUM(119))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[394],MAKE_FIXNUM(127))/*  *MAKE-CONSTANT*/;
	MM0(VV[512],L122);
	MM0(VV[513],L123);
	MM0(VV[406],L124);
	MM0(VV[514],L125);
	MM0(VV[515],L126);
	MM0(VV[516],L127);
	MM0(VV[517],L128);
	MM0(VV[518],L129);
	(void)putprop(VV[519],VV[220],siSpretty_print_format);
	
	MM0(VV[519],L130);
	MM0(VV[520],L131);
	MM0(VV[521],L132);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	local function CLOSURE                                        */
static LC113(int narg, object V1, object V2, object V3, object V4)
{ VT3 VLEX3 CLSR3
	VALUES(0) = CONS(listA(5,VV[210],(V2),(V3),(V1),(V4)),Cnil);
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC94(int narg)
{ VT4 VLEX4 CLSR4
	VALUES(0) = VV[38];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC58(int narg, object V1)
{ VT5 VLEX5 CLSR5
	Lsymbol_value(1,(V1))                     /*  SYMBOL-VALUE    */;
	(*LK0)(2,VALUES(0),VV[124])               /*  COERCE          */;
	VALUES(0) = CONS(VV[116],VALUES(0));
	RETURN(1);
}
/*	macro definition for REQUIRED-ARG                             */
static L1(int narg, object V1, object V2)
{ VT6 VLEX6 CLSR6
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(3,VV[1],list(4,VV[2],VV[3],VV[4],list(2,VV[5],(V4))),VV[0]);
	RETURN(1);}
}
/*	macro definition for LROUND                                   */
static L2(int narg, object V1, object V2)
{ VT7 VLEX7 CLSR7
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(3,VV[6],VV[7],list(3,VV[8],list(3,VV[9],(V4),MAKE_FIXNUM(3)),MAKE_FIXNUM(-4)));
	RETURN(1);}
}
/*	macro definition for WROUND                                   */
static L3(int narg, object V1, object V2)
{ VT8 VLEX8 CLSR8
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(3,VV[6],VV[7],list(3,VV[8],list(3,VV[9],(V4),MAKE_FIXNUM(1)),MAKE_FIXNUM(-2)));
	RETURN(1);}
}
/*	function definition for INDEX-INCREMENT                       */
static L4(int narg, object V1)
{ VT9 VLEX9 CLSR9
TTL:
	{register object V2;                      /*  NAME            */
	register object V3;                       /*  INCREMENT       */
	if(!(type_of((V1))==t_cons)){
	goto L310;}
	V2= CAR((V1));
	goto L308;
L310:
	V2= (V1);
L308:
	V3= getf((V2)->s.s_plist,VV[10],VV[11]);
	if(!(((V3))==(VV[11]))){
	goto L313;}
	Lsymbol_package(1,(V2))                   /*  SYMBOL-PACKAGE  */;
	if((VALUES(0))==((VV[12]->s.s_dbind))){
	goto L316;}
	(*LK1)(1,(V2))                            /*  XINTERN         */;
	V2= VALUES(0);
	V3= getf((V2)->s.s_plist,VV[10],VV[11]);
L316:
	if(!(((V3))==(VV[11]))){
	goto L313;}
	Lerror(2,VV[13],(V2))                     /*  ERROR           */;
L313:
	VALUES(0) = (V3);
	RETURN(1);
	}
}
/*	function definition for GETIFY                                */
static L5(int narg, object V1)
{ VT10 VLEX10 CLSR10
TTL:
	RETURN((*LK1)(2,(V1),VV[14])              /*  XINTERN         */);
}
/*	function definition for PUTIFY                                */
static L6(int narg, object V1, ...)
{ VT11 VLEX11 CLSR11
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if (i==narg) goto L325;
	V2= va_arg(args, object);
	i++;
	goto L326;
L325:
	V2= Cnil;
L326:
	if(((V2))==Cnil){
	goto L330;}
	VALUES(0) = VV[16];
	goto L328;
L330:
	VALUES(0) = VV[17];
L328:
	RETURN((*LK1)(3,(V1),VV[15],VALUES(0))    /*  XINTERN         */);
	}
}
/*	macro definition for DEFINE-ACCESSOR                          */
static L7(int narg, object V1, object V2)
{ VT12 VLEX12 CLSR12
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	{object V7= CAR(V3);
	V5= CAR(V7);}
	V3=CDR(V3);
	V6= V3;
	if((CDDDR((V6)))==Cnil){
	goto L332;}
	Lerror(2,VV[18],CDDDR((V6)))              /*  ERROR           */;
L332:
	{object V8;                               /*  GET-MACRO       */
	object V9;
	object V10;                               /*  PUT-MACRO       */
	VALUES(0) = CAR((V6));
	if(VALUES(0)==Cnil)goto L336;
	V9= VALUES(0);
	goto L335;
L336:
	Lerror(2,VV[19],(V4))                     /*  ERROR           */;
	V9= VALUES(0);
L335:
	VALUES(0) = CADR((V6));
	if(VALUES(0)==Cnil)goto L339;
	V10= VALUES(0);
	goto L338;
L339:
	Lerror(2,VV[20],(V4))                     /*  ERROR           */;
	V10= VALUES(0);
L338:
	V8= V9;
	{object V11= list(2,(V4),VV[22]);
	{object V12= list(3,VV[24],list(2,VV[5],(V4)),VV[25]);
	if((V5)==Cnil){
	VALUES(0) = Cnil;
	goto L341;}
	Lfloor(2,(V5),MAKE_FIXNUM(8))             /*  FLOOR           */;
L341:
	{object V13= list(3,VV[23],(V12),VALUES(0));
	L5(1,(V4))                                /*  GETIFY          */;
	T0= VALUES(0);
	{object V14= listA(4,VV[26],T0,CAR((V8)),CDR((V8)));
	L6(1,(V4))                                /*  PUTIFY          */;
	T1= VALUES(0);
	{object V15= listA(4,VV[26],T1,CAR((V10)),CDR((V10)));
	{object V16;                              /*  PREDICATING-PUT */
	V16= CADDR((V6));
	if(((V16))==Cnil){
	goto L347;}
	{object V17= list(3,VV[23],list(3,VV[24],list(2,VV[5],(V4)),VV[27]),Ct);
	L6(2,(V4),Ct)                             /*  PUTIFY          */;
	T2= VALUES(0);
	VALUES(0) = list(2,(V17),listA(4,VV[26],T2,CAR((V16)),CDR((V16))));
	goto L344;}
L347:
	VALUES(0) = Cnil;
	}
L344:
	VALUES(0) = listA(6,VV[21],(V11),(V13),(V14),(V15),VALUES(0));
	RETURN(1);}}}}}
	}}
}
/*	macro definition for CARD32-GET                               */
static L8(int narg, object V1, object V2)
{ VT13 VLEX13 CLSR13
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(2,VV[30],(V4));
	RETURN(1);}
}
/*	macro definition for CARD32-PUT                               */
static L9(int narg, object V1, object V2)
{ VT14 VLEX14 CLSR14
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = list(3,VV[31],(V4),(V5));
	RETURN(1);}
}
/*	macro definition for CARD29-GET                               */
static L10(int narg, object V1, object V2)
{ VT15 VLEX15 CLSR15
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(2,VV[33],(V4));
	RETURN(1);}
}
/*	macro definition for CARD29-PUT                               */
static L11(int narg, object V1, object V2)
{ VT16 VLEX16 CLSR16
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = list(3,VV[34],(V4),(V5));
	RETURN(1);}
}
/*	macro definition for CARD16-GET                               */
static L12(int narg, object V1, object V2)
{ VT17 VLEX17 CLSR17
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(2,VV[36],(V4));
	RETURN(1);}
}
/*	macro definition for CARD16-PUT                               */
static L13(int narg, object V1, object V2)
{ VT18 VLEX18 CLSR18
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = list(3,VV[37],(V4),(V5));
	RETURN(1);}
}
/*	macro definition for CARD8-GET                                */
static L14(int narg, object V1, object V2)
{ VT19 VLEX19 CLSR19
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(2,VV[39],(V4));
	RETURN(1);}
}
/*	macro definition for CARD8-PUT                                */
static L15(int narg, object V1, object V2)
{ VT20 VLEX20 CLSR20
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = list(3,VV[40],(V4),(V5));
	RETURN(1);}
}
/*	macro definition for INTEGER-GET                              */
static L16(int narg, object V1, object V2)
{ VT21 VLEX21 CLSR21
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(2,VV[42],(V4));
	RETURN(1);}
}
/*	macro definition for INTEGER-PUT                              */
static L17(int narg, object V1, object V2)
{ VT22 VLEX22 CLSR22
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = list(3,VV[43],(V4),(V5));
	RETURN(1);}
}
/*	macro definition for INT16-GET                                */
static L18(int narg, object V1, object V2)
{ VT23 VLEX23 CLSR23
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(2,VV[45],(V4));
	RETURN(1);}
}
/*	macro definition for INT16-PUT                                */
static L19(int narg, object V1, object V2)
{ VT24 VLEX24 CLSR24
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = list(3,VV[46],(V4),(V5));
	RETURN(1);}
}
/*	macro definition for RGB-VAL-GET                              */
static L20(int narg, object V1, object V2)
{ VT25 VLEX25 CLSR25
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(2,VV[48],list(2,VV[36],(V4)));
	RETURN(1);}
}
/*	macro definition for RGB-VAL-PUT                              */
static L21(int narg, object V1, object V2)
{ VT26 VLEX26 CLSR26
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = list(3,VV[37],(V4),list(2,VV[49],(V5)));
	RETURN(1);}
}
/*	macro definition for ANGLE-GET                                */
static L22(int narg, object V1, object V2)
{ VT27 VLEX27 CLSR27
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(2,VV[51],list(2,VV[45],(V4)));
	RETURN(1);}
}
/*	macro definition for ANGLE-PUT                                */
static L23(int narg, object V1, object V2)
{ VT28 VLEX28 CLSR28
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = list(3,VV[46],(V4),list(2,VV[52],(V5)));
	RETURN(1);}
}
/*	macro definition for BIT-GET                                  */
static L24(int narg, object V1, object V2)
{ VT29 VLEX29 CLSR29
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = list(3,VV[54],(V5),list(2,VV[39],(V4)));
	RETURN(1);}
}
/*	macro definition for BIT-PUT                                  */
static L25(int narg, object V1, object V2)
{ VT30 VLEX30 CLSR30
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= CAR(V3);
	if(!(number_compare(MAKE_FIXNUM(0),(V6))==0)){
	goto L351;}
	VALUES(0) = list(3,VV[40],(V4),listA(3,VV[55],(V5),VV[56]));
	RETURN(1);
L351:
	{object V7= listA(3,VV[55],(V5),VV[58]);
	{object V8= list(3,VV[59],MAKE_FIXNUM(1),(V6));
	VALUES(0) = list(3,VV[40],(V4),list(4,VV[57],(V7),(V8),list(2,VV[39],(V4))));
	RETURN(1);}}}
}
/*	macro definition for BOOLEAN-GET                              */
static L26(int narg, object V1, object V2)
{ VT31 VLEX31 CLSR31
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(2,VV[61],list(2,VV[39],(V4)));
	RETURN(1);}
}
/*	macro definition for BOOLEAN-PUT                              */
static L27(int narg, object V1, object V2)
{ VT32 VLEX32 CLSR32
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = list(3,VV[40],(V4),listA(3,VV[55],(V5),VV[62]));
	RETURN(1);}
}
/*	macro definition for DRAWABLE-GET                             */
static L28(int narg, object V1, object V2)
{ VT33 VLEX33 CLSR33
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	if(endp(V3)){
	V5= VV[64];
	} else {
	V5= CAR(V3);}
	VALUES(0) = list(3,VV[65],(V5),list(2,VV[33],(V4)));
	RETURN(1);}
}
/*	macro definition for DRAWABLE-PUT                             */
static L29(int narg, object V1, object V2)
{ VT34 VLEX34 CLSR34
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = list(3,VV[34],(V4),list(2,VV[66],(V5)));
	RETURN(1);}
}
/*	macro definition for WINDOW-GET                               */
static L30(int narg, object V1, object V2)
{ VT35 VLEX35 CLSR35
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	if(endp(V3)){
	V5= VV[64];
	} else {
	V5= CAR(V3);}
	VALUES(0) = list(3,VV[68],(V5),list(2,VV[33],(V4)));
	RETURN(1);}
}
/*	macro definition for WINDOW-PUT                               */
static L31(int narg, object V1, object V2)
{ VT36 VLEX36 CLSR36
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = list(3,VV[34],(V4),list(2,VV[69],(V5)));
	RETURN(1);}
}
/*	macro definition for PIXMAP-GET                               */
static L32(int narg, object V1, object V2)
{ VT37 VLEX37 CLSR37
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	if(endp(V3)){
	V5= VV[64];
	} else {
	V5= CAR(V3);}
	VALUES(0) = list(3,VV[71],(V5),list(2,VV[33],(V4)));
	RETURN(1);}
}
/*	macro definition for PIXMAP-PUT                               */
static L33(int narg, object V1, object V2)
{ VT38 VLEX38 CLSR38
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = list(3,VV[34],(V4),list(2,VV[72],(V5)));
	RETURN(1);}
}
/*	macro definition for GCONTEXT-GET                             */
static L34(int narg, object V1, object V2)
{ VT39 VLEX39 CLSR39
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	if(endp(V3)){
	V5= VV[64];
	} else {
	V5= CAR(V3);}
	VALUES(0) = list(3,VV[74],(V5),list(2,VV[33],(V4)));
	RETURN(1);}
}
/*	macro definition for GCONTEXT-PUT                             */
static L35(int narg, object V1, object V2)
{ VT40 VLEX40 CLSR40
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = list(3,VV[34],(V4),list(2,VV[75],(V5)));
	RETURN(1);}
}
/*	macro definition for CURSOR-GET                               */
static L36(int narg, object V1, object V2)
{ VT41 VLEX41 CLSR41
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	if(endp(V3)){
	V5= VV[64];
	} else {
	V5= CAR(V3);}
	VALUES(0) = list(3,VV[77],(V5),list(2,VV[33],(V4)));
	RETURN(1);}
}
/*	macro definition for CURSOR-PUT                               */
static L37(int narg, object V1, object V2)
{ VT42 VLEX42 CLSR42
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = list(3,VV[34],(V4),list(2,VV[78],(V5)));
	RETURN(1);}
}
/*	macro definition for COLORMAP-GET                             */
static L38(int narg, object V1, object V2)
{ VT43 VLEX43 CLSR43
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	if(endp(V3)){
	V5= VV[64];
	} else {
	V5= CAR(V3);}
	VALUES(0) = list(3,VV[80],(V5),list(2,VV[33],(V4)));
	RETURN(1);}
}
/*	macro definition for COLORMAP-PUT                             */
static L39(int narg, object V1, object V2)
{ VT44 VLEX44 CLSR44
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = list(3,VV[34],(V4),list(2,VV[81],(V5)));
	RETURN(1);}
}
/*	macro definition for FONT-GET                                 */
static L40(int narg, object V1, object V2)
{ VT45 VLEX45 CLSR45
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	if(endp(V3)){
	V5= VV[64];
	} else {
	V5= CAR(V3);}
	VALUES(0) = list(3,VV[83],(V5),list(2,VV[33],(V4)));
	RETURN(1);}
}
/*	macro definition for FONT-PUT                                 */
static L41(int narg, object V1, object V2)
{ VT46 VLEX46 CLSR46
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	RETURN(Lerror(1,VV[84])                   /*  ERROR           */);}
}
/*	macro definition for KEYWORD-GET                              */
static L42(int narg, object V1, object V2)
{ VT47 VLEX47 CLSR47
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	if(endp(V3)){
	V5= VV[64];
	} else {
	V5= CAR(V3);}
	VALUES(0) = list(3,VV[86],(V5),list(2,VV[33],(V4)));
	RETURN(1);}
}
/*	macro definition for KEYWORD-PUT                              */
static L43(int narg, object V1, object V2)
{ VT48 VLEX48 CLSR48
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	{object V7;
	V7=getf(V3,VV[527],OBJNULL);
	if(V7==OBJNULL){
	V6= VV[64];
	} else {
	V6= V7;}}
	VALUES(0) = list(3,VV[34],(V4),list(3,VV[87],list(3,VV[88],(V5),(V6)),VV[89]));
	RETURN(1);}
}
/*	macro definition for RESOURCE-ID-GET                          */
static L44(int narg, object V1, object V2)
{ VT49 VLEX49 CLSR49
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(2,VV[33],(V4));
	RETURN(1);}
}
/*	macro definition for RESOURCE-ID-PUT                          */
static L45(int narg, object V1, object V2)
{ VT50 VLEX50 CLSR50
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = list(3,VV[34],(V4),(V5));
	RETURN(1);}
}
/*	macro definition for RESOURCE-ID-OR-NIL-GET                   */
static L46(int narg, object V1, object V2)
{ VT51 VLEX51 CLSR51
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	{register object V5;                      /*  ID              */
	Lgensym(0)                                /*  GENSYM          */;
	V5= VALUES(0);
	{object V6= CONS(list(2,(V5),list(2,VV[33],(V4))),Cnil);
	{object V7= list(2,VV[93],list(3,VV[94],VV[32],(V5)));
	VALUES(0) = list(4,VV[92],(V6),(V7),list(3,VV[95],list(2,VV[61],(V5)),(V5)));
	RETURN(1);}}
	}}
}
/*	macro definition for RESOURCE-ID-OR-NIL-PUT                   */
static L47(int narg, object V1, object V2)
{ VT52 VLEX52 CLSR52
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = list(3,VV[34],(V4),list(3,VV[87],(V5),MAKE_FIXNUM(0)));
	RETURN(1);}
}
/*	macro definition for CHAR-INFO-GET                            */
static L48(int narg, object V1, object V2)
{ VT53 VLEX53 CLSR53
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	{object V5= list(2,VV[98],(V4));
	{object V6= list(2,VV[98],number_plus((V4),MAKE_FIXNUM(2)));
	{object V7= list(2,VV[98],number_plus((V4),MAKE_FIXNUM(4)));
	{object V8= list(2,VV[98],number_plus((V4),MAKE_FIXNUM(6)));
	{object V9= list(2,VV[98],number_plus((V4),MAKE_FIXNUM(8)));
	RETURN(Llist(13,VV[96],VV[97],(V5),VV[99],(V6),VV[100],(V7),VV[101],(V8),VV[102],(V9),VV[103],list(2,VV[104],number_plus((V4),MAKE_FIXNUM(10))))/*  LIST*/);}}}}}}
}
/*	macro definition for MEMBER8-GET                              */
static L49(int narg, object V1, object V2)
{ VT54 VLEX54 CLSR54
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= V3;
	{register object V6;                      /*  VALUE           */
	Lgensym(0)                                /*  GENSYM          */;
	V6= VALUES(0);
	{object V7= CONS(list(2,(V6),list(2,VV[39],(V4))),Cnil);
	{object V8= list(2,VV[93],list(3,VV[94],VV[38],(V6)));
	{object V9= list(3,VV[106],(V6),MAKE_FIXNUM(length((V5))));
	VALUES(0) = (VV[528]->s.s_gfdef);
	Lapply(2,VALUES(0),(V5))                  /*  APPLY           */;
	VALUES(0) = list(4,VV[92],(V7),(V8),list(3,VV[95],(V9),list(3,VV[107],list(2,VV[5],VALUES(0)),(V6))));
	RETURN(1);}}}
	}}
}
/*	macro definition for MEMBER8-PUT                              */
static L50(int narg, object V1, object V2)
{ VT55 VLEX55 CLSR55
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= V3;
	VALUES(0) = (VV[528]->s.s_gfdef);
	Lapply(2,VALUES(0),(V6))                  /*  APPLY           */;
	VALUES(0) = list(3,VV[40],(V4),listA(4,VV[108],(V5),list(3,VV[6],VV[109],list(2,VV[5],VALUES(0))),VV[110]));
	RETURN(1);}
}
/*	macro definition for MEMBER8-PUT-PREDICATING                  */
static L51(int narg, object V1, object V2)
{ VT56 VLEX56 CLSR56
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= V3;
	{register object V7;                      /*  VALUE           */
	Lgensym(0)                                /*  GENSYM          */;
	V7= VALUES(0);
	VALUES(0) = (VV[528]->s.s_gfdef);
	Lapply(2,VALUES(0),(V6))                  /*  APPLY           */;
	{object V8= CONS(list(2,(V7),listA(4,VV[108],(V5),list(3,VV[6],VV[109],list(2,VV[5],VALUES(0))),VV[112])),Cnil);
	{object V9= list(2,VV[93],list(3,VV[94],VV[38],(V7)));
	VALUES(0) = list(4,VV[92],(V8),(V9),list(3,VV[95],(V7),list(3,VV[40],(V4),(V7))));
	RETURN(1);}}
	}}
}
/*	macro definition for MEMBER16-GET                             */
static L52(int narg, object V1, object V2)
{ VT57 VLEX57 CLSR57
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= V3;
	{register object V6;                      /*  VALUE           */
	Lgensym(0)                                /*  GENSYM          */;
	V6= VALUES(0);
	{object V7= CONS(list(2,(V6),list(2,VV[36],(V4))),Cnil);
	{object V8= list(2,VV[93],list(3,VV[94],VV[35],(V6)));
	{object V9= list(3,VV[106],(V6),MAKE_FIXNUM(length((V5))));
	VALUES(0) = (VV[528]->s.s_gfdef);
	Lapply(2,VALUES(0),(V5))                  /*  APPLY           */;
	VALUES(0) = list(4,VV[92],(V7),(V8),list(3,VV[95],(V9),list(3,VV[107],list(2,VV[5],VALUES(0)),(V6))));
	RETURN(1);}}}
	}}
}
/*	macro definition for MEMBER16-PUT                             */
static L53(int narg, object V1, object V2)
{ VT58 VLEX58 CLSR58
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= V3;
	VALUES(0) = (VV[528]->s.s_gfdef);
	Lapply(2,VALUES(0),(V6))                  /*  APPLY           */;
	VALUES(0) = list(3,VV[37],(V4),listA(4,VV[108],(V5),list(3,VV[6],VV[109],list(2,VV[5],VALUES(0))),VV[114]));
	RETURN(1);}
}
/*	macro definition for MEMBER16-PUT-PREDICATING                 */
static L54(int narg, object V1, object V2)
{ VT59 VLEX59 CLSR59
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= V3;
	{register object V7;                      /*  VALUE           */
	Lgensym(0)                                /*  GENSYM          */;
	V7= VALUES(0);
	VALUES(0) = (VV[528]->s.s_gfdef);
	Lapply(2,VALUES(0),(V6))                  /*  APPLY           */;
	{object V8= CONS(list(2,(V7),listA(4,VV[108],(V5),list(3,VV[6],VV[109],list(2,VV[5],VALUES(0))),VV[115])),Cnil);
	{object V9= list(2,VV[93],list(3,VV[94],VV[35],(V7)));
	VALUES(0) = list(4,VV[92],(V8),(V9),list(3,VV[95],(V7),list(3,VV[37],(V4),(V7))));
	RETURN(1);}}
	}}
}
/*	macro definition for MEMBER-GET                               */
static L55(int narg, object V1, object V2)
{ VT60 VLEX60 CLSR60
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= V3;
	{register object V6;                      /*  VALUE           */
	Lgensym(0)                                /*  GENSYM          */;
	V6= VALUES(0);
	{object V7= CONS(list(2,(V6),list(2,VV[33],(V4))),Cnil);
	{object V8= list(2,VV[93],list(3,VV[94],VV[32],(V6)));
	{object V9= list(3,VV[106],(V6),MAKE_FIXNUM(length((V5))));
	VALUES(0) = (VV[528]->s.s_gfdef);
	Lapply(2,VALUES(0),(V5))                  /*  APPLY           */;
	VALUES(0) = list(4,VV[92],(V7),(V8),list(3,VV[95],(V9),list(3,VV[107],list(2,VV[5],VALUES(0)),(V6))));
	RETURN(1);}}}
	}}
}
/*	macro definition for MEMBER-PUT                               */
static L56(int narg, object V1, object V2)
{ VT61 VLEX61 CLSR61
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= V3;
	VALUES(0) = (VV[528]->s.s_gfdef);
	Lapply(2,VALUES(0),(V6))                  /*  APPLY           */;
	VALUES(0) = list(3,VV[34],(V4),listA(4,VV[108],(V5),list(3,VV[6],VV[109],list(2,VV[5],VALUES(0))),VV[117]));
	RETURN(1);}
}
/*	macro definition for MEMBER-PUT-PREDICATING                   */
static L57(int narg, object V1, object V2)
{ VT62 VLEX62 CLSR62
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= V3;
	if((CDR((V6)))==Cnil){
	goto L385;}
	{register object V7;                      /*  VALUE           */
	Lgensym(0)                                /*  GENSYM          */;
	V7= VALUES(0);
	VALUES(0) = (VV[528]->s.s_gfdef);
	Lapply(2,VALUES(0),(V6))                  /*  APPLY           */;
	{object V8= CONS(list(2,(V7),listA(4,VV[108],(V5),list(3,VV[6],VV[109],list(2,VV[5],VALUES(0))),VV[118])),Cnil);
	{object V9= list(2,VV[93],list(3,VV[94],VV[32],(V7)));
	VALUES(0) = list(4,VV[92],(V8),(V9),list(3,VV[95],(V7),list(3,VV[34],(V4),(V7))));
	RETURN(1);}}
	}
L385:
	{object V10= list(3,VV[119],(V5),CAR((V6)));
	VALUES(0) = list(3,VV[95],(V10),list(3,VV[34],(V4),MAKE_FIXNUM(0)));
	RETURN(1);}}
}
/*	macro definition for MEMBER-VECTOR-GET                        */
static L59(int narg, object V1, object V2)
{ VT63 VLEX63 CLSR63
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	Leval(1,(V5))                             /*  EVAL            */;
	(*LK0)(2,VALUES(0),VV[124])               /*  COERCE          */;
	VALUES(0) = listA(3,VV[126],(V4),VALUES(0));
	RETURN(1);}
}
/*	macro definition for MEMBER-VECTOR-PUT                        */
static L60(int narg, object V1, object V2)
{ VT64 VLEX64 CLSR64
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= CAR(V3);
	Leval(1,(V6))                             /*  EVAL            */;
	(*LK0)(2,VALUES(0),VV[124])               /*  COERCE          */;
	VALUES(0) = listA(4,VV[127],(V4),(V5),VALUES(0));
	RETURN(1);}
}
/*	macro definition for MEMBER-VECTOR-PUT-PREDICATING            */
static L61(int narg, object V1, object V2)
{ VT65 VLEX65 CLSR65
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= CAR(V3);
	Leval(1,(V6))                             /*  EVAL            */;
	(*LK0)(2,VALUES(0),VV[124])               /*  COERCE          */;
	VALUES(0) = listA(4,VV[127],(V4),(V5),VALUES(0));
	RETURN(1);}
}
/*	macro definition for MEMBER16-VECTOR-GET                      */
static L62(int narg, object V1, object V2)
{ VT66 VLEX66 CLSR66
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	Leval(1,(V5))                             /*  EVAL            */;
	(*LK0)(2,VALUES(0),VV[124])               /*  COERCE          */;
	VALUES(0) = listA(3,VV[129],(V4),VALUES(0));
	RETURN(1);}
}
/*	macro definition for MEMBER16-VECTOR-PUT                      */
static L63(int narg, object V1, object V2)
{ VT67 VLEX67 CLSR67
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= CAR(V3);
	Leval(1,(V6))                             /*  EVAL            */;
	(*LK0)(2,VALUES(0),VV[124])               /*  COERCE          */;
	VALUES(0) = listA(4,VV[130],(V4),(V5),VALUES(0));
	RETURN(1);}
}
/*	macro definition for MEMBER16-VECTOR-PUT-PREDICATING          */
static L64(int narg, object V1, object V2)
{ VT68 VLEX68 CLSR68
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= CAR(V3);
	Leval(1,(V6))                             /*  EVAL            */;
	(*LK0)(2,VALUES(0),VV[124])               /*  COERCE          */;
	VALUES(0) = listA(4,VV[130],(V4),(V5),VALUES(0));
	RETURN(1);}
}
/*	macro definition for MEMBER8-VECTOR-GET                       */
static L65(int narg, object V1, object V2)
{ VT69 VLEX69 CLSR69
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	Leval(1,(V5))                             /*  EVAL            */;
	(*LK0)(2,VALUES(0),VV[124])               /*  COERCE          */;
	VALUES(0) = listA(3,VV[132],(V4),VALUES(0));
	RETURN(1);}
}
/*	macro definition for MEMBER8-VECTOR-PUT                       */
static L66(int narg, object V1, object V2)
{ VT70 VLEX70 CLSR70
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= CAR(V3);
	Leval(1,(V6))                             /*  EVAL            */;
	(*LK0)(2,VALUES(0),VV[124])               /*  COERCE          */;
	VALUES(0) = listA(4,VV[133],(V4),(V5),VALUES(0));
	RETURN(1);}
}
/*	macro definition for MEMBER8-VECTOR-PUT-PREDICATING           */
static L67(int narg, object V1, object V2)
{ VT71 VLEX71 CLSR71
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= CAR(V3);
	Leval(1,(V6))                             /*  EVAL            */;
	(*LK0)(2,VALUES(0),VV[124])               /*  COERCE          */;
	VALUES(0) = listA(4,VV[133],(V4),(V5),VALUES(0));
	RETURN(1);}
}
/*	macro definition for BOOLE-CONSTANT-GET                       */
static L68(int narg, object V1, object V2)
{ VT72 VLEX72 CLSR72
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	{register object V5;                      /*  VALUE           */
	Lgensym(0)                                /*  GENSYM          */;
	V5= VALUES(0);
	{object V6= CONS(list(2,(V5),list(2,VV[33],(V4))),Cnil);
	{object V7= list(2,VV[93],list(3,VV[94],VV[32],(V5)));
	{object V8= list(3,VV[106],(V5),MAKE_FIXNUM((VV[135])->v.v_fillp));
	VALUES(0) = list(4,VV[92],(V6),(V7),list(3,VV[95],(V8),list(3,VV[107],VV[136],(V5))));
	RETURN(1);}}}
	}}
}
/*	macro definition for BOOLE-CONSTANT-PUT                       */
static L69(int narg, object V1, object V2)
{ VT73 VLEX73 CLSR73
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = list(3,VV[34],(V4),list(3,VV[108],(V5),VV[137]));
	RETURN(1);}
}
/*	macro definition for BOOLE-CONSTANT-PUT-PREDICATING           */
static L70(int narg, object V1, object V2)
{ VT74 VLEX74 CLSR74
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	{register object V6;                      /*  VALUE           */
	Lgensym(0)                                /*  GENSYM          */;
	V6= VALUES(0);
	{object V7= CONS(list(2,(V6),list(3,VV[108],(V5),VV[138])),Cnil);
	{object V8= list(2,VV[93],list(3,VV[94],VV[32],(V6)));
	VALUES(0) = list(4,VV[92],(V7),(V8),list(3,VV[95],(V6),list(3,VV[34],(V4),(V6))));
	RETURN(1);}}
	}}
}
/*	macro definition for NULL-GET                                 */
static L71(int narg, object V1, object V2)
{ VT75 VLEX75 CLSR75
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	{object V5= list(2,VV[140],list(2,VV[30],(V4)));
	VALUES(0) = list(4,VV[55],(V5),Cnil,list(2,VV[30],(V4)));
	RETURN(1);}}
}
/*	macro definition for NULL-PUT                                 */
static L72(int narg, object V1, object V2)
{ VT76 VLEX76 CLSR76
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = list(3,VV[31],(V4),MAKE_FIXNUM(0));
	RETURN(1);}
}
/*	macro definition for PAD8-GET                                 */
static L73(int narg, object V1, object V2)
{ VT77 VLEX77 CLSR77
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = Cnil;
	RETURN(1);}
}
/*	macro definition for PAD8-PUT                                 */
static L74(int narg, object V1, object V2)
{ VT78 VLEX78 CLSR78
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = Cnil;
	RETURN(1);}
}
/*	macro definition for PAD16-GET                                */
static L75(int narg, object V1, object V2)
{ VT79 VLEX79 CLSR79
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = Cnil;
	RETURN(1);}
}
/*	macro definition for PAD16-PUT                                */
static L76(int narg, object V1, object V2)
{ VT80 VLEX80 CLSR80
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = Cnil;
	RETURN(1);}
}
/*	macro definition for BIT-VECTOR256-GET                        */
static L77(int narg, object V1, object V2)
{ VT81 VLEX81 CLSR81
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	if(endp(V3)){
	V5= (V4);
	} else {
	V5= CAR(V3);
	V3=CDR(V3);}
	if(endp(V3)){
	V6= Cnil;
	} else {
	V6= CAR(V3);}
	VALUES(0) = list(4,VV[144],VV[145],(V5),(V6));
	RETURN(1);}
}
/*	macro definition for BIT-VECTOR256-PUT                        */
static L78(int narg, object V1, object V2)
{ VT82 VLEX82 CLSR82
	{object V3=CDR(V1),V4,V5,V6,V7;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	if(endp(V3)){
	V6= (V4);
	} else {
	V6= CAR(V3);
	V3=CDR(V3);}
	if(endp(V3)){
	V7= VV[64];
	} else {
	V7= CAR(V3);}
	VALUES(0) = list(4,VV[146],(V7),list(3,VV[9],VV[147],(V6)),(V5));
	RETURN(1);}
}
/*	macro definition for STRING-GET                               */
static L79(int narg, object V1, object V2)
{ VT83 VLEX83 CLSR83
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	{object V7;
	V7=getf(V3,VV[529],OBJNULL);
	if(V7==OBJNULL){
	V6= Cnil;
	} else {
	V6= V7;}}
	if((V6)!=Cnil){
	VALUES(0) = (V6);
	goto L415;}
	VALUES(0) = VV[150];
L415:
	VALUES(0) = list(8,VV[149],VALUES(0),VV[151],(V4),Cnil,Cnil,MAKE_FIXNUM(0),(V5));
	RETURN(1);}
}
/*	macro definition for STRING-PUT                               */
static L80(int narg, object V1, object V2)
{ VT84 VLEX84 CLSR84
	{object V3=CDR(V1),V4,V5,V6,V7,V8,V9,V10;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	{object V11;
	V11=getf(V3,VV[527],OBJNULL);
	if(V11==OBJNULL){
	V6= Cnil;
	} else {
	V6= V11;}
	V11=getf(V3,VV[530],OBJNULL);
	if(V11==OBJNULL){
	V7= MAKE_FIXNUM(0);
	} else {
	V7= V11;}
	V11=getf(V3,VV[168],OBJNULL);
	if(V11==OBJNULL){
	V8= Cnil;
	} else {
	V8= V11;}
	V11=getf(V3,VV[531],OBJNULL);
	if(V11==OBJNULL){
	V9= Cnil;
	} else {
	V9= V11;}
	V11=getf(V3,VV[532],OBJNULL);
	if(V11==OBJNULL){
	V10= Cnil;
	} else {
	V10= V11;}}
	if(((V6))!=Cnil){
	goto L421;}
	V6= VV[64];
L421:
	if(((V9))!=Cnil){
	goto L425;}
	V9= MAKE_FIXNUM((((fix((V4)))+(3)) & (-4)));
L425:
	{register object V12;                     /*  REAL-END        */
	object V13;                               /*  FORM            */
	if(((V10))==Cnil){
	goto L431;}
	if((V8)!=Cnil){
	V12= (V8);
	goto L429;}
	V12= list(2,VV[152],(V5));
	goto L429;
L431:
	Lgensym(0)                                /*  GENSYM          */;
	V12= VALUES(0);
L429:
	V13= list(6,VV[153],(V6),list(3,VV[9],VV[147],(V9)),(V5),(V7),(V12));
	if(((V10))==Cnil){
	goto L435;}
	VALUES(0) = (V13);
	RETURN(1);
L435:
	if((V8)!=Cnil){
	VALUES(0) = (V8);
	goto L437;}
	VALUES(0) = list(2,VV[152],(V5));
L437:
	{object V14= CONS(list(2,(V12),VALUES(0)),Cnil);
	{object V15= list(2,VV[93],list(3,VV[94],VV[7],(V12)));
	VALUES(0) = list(5,VV[92],(V14),(V15),list(3,VV[37],MAKE_FIXNUM(2),list(3,VV[154],list(3,VV[9],list(3,VV[155],(V12),(V7)),(V9)),MAKE_FIXNUM(4))),(V13));
	RETURN(1);}}
	}}
}
/*	macro definition for SEQUENCE-GET                             */
static L81(int narg, object V1, object V2)
{ VT85 VLEX85 CLSR85
	{object V3=CDR(V1),V4,V5,V6,V7,V8,V9,V10,V11;
	{object V12;
	V12=getf(V3,VV[216],OBJNULL);
	if(V12==OBJNULL){
	V4= Cnil;
	} else {
	V4= V12;}
	V12=getf(V3,VV[167],OBJNULL);
	if(V12==OBJNULL){
	V5= VV[29];
	} else {
	V5= V12;}
	V12=getf(V3,VV[533],OBJNULL);
	if(V12==OBJNULL){
	V6= Cnil;
	} else {
	V6= V12;}
	V12=getf(V3,VV[534],OBJNULL);
	if(V12==OBJNULL){
	V7= Cnil;
	} else {
	V7= V12;}
	V12=getf(V3,VV[529],OBJNULL);
	if(V12==OBJNULL){
	V8= Cnil;
	} else {
	V8= V12;}
	V12=getf(V3,VV[535],OBJNULL);
	if(V12==OBJNULL){
	V9= Cnil;
	} else {
	V9= V12;}
	V12=getf(V3,VV[536],OBJNULL);
	if(V12==OBJNULL){
	V10= Cnil;
	} else {
	V10= V12;}
	V12=getf(V3,VV[530],OBJNULL);
	if(V12==OBJNULL){
	V11= Cnil;
	} else {
	V11= V12;}}
	if(((V5)!= VV[38]))goto L447;
	T0= VV[157];
	goto L446;
L447:
	if(((V5)!= VV[537]))goto L448;
	T0= VV[158];
	goto L446;
L448:
	if(((V5)!= VV[35]))goto L449;
	T0= VV[159];
	goto L446;
L449:
	if(((V5)!= VV[44]))goto L450;
	T0= VV[160];
	goto L446;
L450:
	if(((V5)!= VV[29]))goto L451;
	T0= VV[161];
	goto L446;
L451:
	if(((V5)!= VV[538]))goto L452;
	T0= VV[162];
	goto L446;
L452:
	FEerror("The ECASE key value ~s is illegal.",1,(V5));
L446:
	if((V8)!=Cnil){
	T1= (V8);
	goto L453;}
	T1= VV[150];
L453:
	if(((V11))!=Cnil){
	goto L455;}
	if(((V10))==Cnil){
	goto L456;}
L455:
	if((V11)!=Cnil){
	VALUES(0) = (V11);
	goto L460;}
	VALUES(0) = MAKE_FIXNUM(0);
L460:
	T2= CONS(VALUES(0),Cnil);
	goto L454;
L456:
	T2= Cnil;
L454:
	if(((V10))==Cnil){
	goto L463;}
	VALUES(0) = CONS((V10),Cnil);
	goto L461;
L463:
	VALUES(0) = Cnil;
L461:
	VALUES(0) = listA(7,T0,T1,(V6),(V4),(V7),(V9),append(T2,VALUES(0)));
	RETURN(1);}
}
/*	macro definition for SEQUENCE-PUT                             */
static L82(int narg, object V1, object V2)
{ VT86 VLEX86 CLSR86
	{object V3=CDR(V1),V4,V5,V6;
	lex0[0]=CAR(V3);                          /*  INDEX           */
	V3=CDR(V3);
	lex0[1]=CAR(V3);                          /*  DATA            */
	V3=CDR(V3);
	{object V7;
	V7=getf(V3,VV[167],OBJNULL);
	if(V7==OBJNULL){
	V4= VV[29];
	} else {
	V4= V7;}
	V7=getf(V3,VV[530],OBJNULL);
	if(V7==OBJNULL){
	lex0[2]=MAKE_FIXNUM(0);                   /*  START           */
	} else {
	lex0[2]=V7;                               /*  START           */}
	V7=getf(V3,VV[168],OBJNULL);
	if(V7==OBJNULL){
	lex0[3]=Cnil;                             /*  END             */
	} else {
	lex0[3]=V7;                               /*  END             */}
	V7=getf(V3,VV[534],OBJNULL);
	if(V7==OBJNULL){
	V5= Cnil;
	} else {
	V5= V7;}
	V7=getf(V3,VV[527],OBJNULL);
	if(V7==OBJNULL){
	V6= Cnil;
	} else {
	V6= V7;}
	V7=getf(V3,VV[532],OBJNULL);
	if(V7==OBJNULL){
	lex0[4]=Cnil;                             /*  APPENDING       */
	} else {
	lex0[4]=V7;                               /*  APPENDING       */}}
	if(((V6))!=Cnil){
	goto L471;}
	V6= VV[64];
L471:
	{object V8;                               /*  WRITER          */
	if((lex0[4])==Cnil){
	goto L477;}
	if(lex0[3]!=Cnil){
	lex0[5]=lex0[3];                          /*  REAL-END        */
	goto L475;}
	lex0[5]=list(2,VV[152],lex0[1]);          /*  REAL-END        */
	goto L475;
L477:
	Lgensym(0)                                /*  GENSYM          */;
	lex0[5]=VALUES(0);                        /*  REAL-END        */
L475:
	(*LK1)(2,VV[163],(V4))                    /*  XINTERN         */;
	V8= VALUES(0);
	lex0[6]=list(7,(V8),(V6),list(3,VV[9],VV[147],MAKE_FIXNUM((((fix(lex0[0]))+(3)) & (-4)))),lex0[1],lex0[2],lex0[5],(V5));/*  FORM*/
	if(((V4)!= VV[38])
	&& ((V4)!= VV[537]))goto L481;
	RETURN(LC83(lex0,1,MAKE_FIXNUM(4))        /*  MAKER           */);
L481:
	if(((V4)!= VV[35])
	&& ((V4)!= VV[44])
	&& ((V4)!= VV[539]))goto L482;
	RETURN(LC83(lex0,1,MAKE_FIXNUM(2))        /*  MAKER           */);
L482:
	if(((V4)!= VV[29])
	&& ((V4)!= VV[538]))goto L483;
	RETURN(LC83(lex0,1,MAKE_FIXNUM(1))        /*  MAKER           */);
L483:
	FEerror("The ECASE key value ~s is illegal.",1,(V4));
	}}
}
/*	local function MAKER                                          */
static LC83(object *lex0,int narg, object V1)
{ VT87 VLEX87 CLSR87
TTL:
	if((lex0[4])==Cnil){
	goto L485;}
	VALUES(0) = lex0[6];
	RETURN(1);
L485:
	{object V2;                               /*  IDX             */
	V2= list(3,VV[155],lex0[5],lex0[2]);
	if(number_compare((V1),MAKE_FIXNUM(1))==0){
	goto L488;}
	V2= list(3,VV[154],(V2),(V1));
L488:
	if(lex0[3]!=Cnil){
	VALUES(0) = lex0[3];
	goto L492;}
	VALUES(0) = list(2,VV[152],lex0[1]);
L492:
	{object V3= CONS(list(2,lex0[5],VALUES(0)),Cnil);
	{object V4= list(2,VV[93],list(3,VV[94],VV[7],lex0[5]));
	Lceiling(2,lex0[0],MAKE_FIXNUM(4))        /*  CEILING         */;
	VALUES(0) = list(5,VV[92],(V3),(V4),list(3,VV[37],MAKE_FIXNUM(2),list(3,VV[9],(V2),VALUES(0))),lex0[6]);
	RETURN(1);}}
	}
}
/*	macro definition for CLIENT-MESSAGE-EVENT-GET-SEQUENCE        */
static L84(int narg, object V1, object V2)
{ VT88 VLEX88 CLSR88
	{object V3=CDR(V1);
	VALUES(0) = VV[164];
	RETURN(1);}
}
/*	macro definition for CLIENT-MESSAGE-EVENT-PUT-SEQUENCE        */
static L85(int narg, object V1, object V2)
{ VT89 VLEX89 CLSR89
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	{object V6= list(2,MAKE_FIXNUM(8),listA(8,VV[166],MAKE_FIXNUM(12),(V5),VV[167],VV[38],VV[168],list(3,VV[169],list(2,VV[152],(V5)),MAKE_FIXNUM(20)),VV[170]));
	{object V7= list(2,MAKE_FIXNUM(16),listA(8,VV[166],MAKE_FIXNUM(12),(V5),VV[167],VV[35],VV[168],list(3,VV[169],list(2,VV[152],(V5)),MAKE_FIXNUM(10)),VV[171]));
	VALUES(0) = list(5,VV[165],(V4),(V6),(V7),list(2,MAKE_FIXNUM(32),listA(8,VV[166],MAKE_FIXNUM(12),(V5),VV[167],VV[29],VV[168],list(3,VV[169],list(2,VV[152],(V5)),MAKE_FIXNUM(5)),VV[172])));
	RETURN(1);}}}
}
/*	macro definition for CLIENT-MESSAGE-SEQUENCE-GET              */
static L86(int narg, object V1, object V2)
{ VT90 VLEX90 CLSR90
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = VV[174];
	RETURN(1);}
}
/*	macro definition for CLIENT-MESSAGE-SEQUENCE-PUT              */
static L87(int narg, object V1, object V2)
{ VT91 VLEX91 CLSR91
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= CAR(V3);
	VALUES(0) = list(3,VV[175],(V6),(V5));
	RETURN(1);}
}
/*	macro definition for CODE-GET                                 */
static L88(int narg, object V1, object V2)
{ VT92 VLEX92 CLSR92
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = VV[177];
	RETURN(1);}
}
/*	macro definition for CODE-PUT                                 */
static L89(int narg, object V1, object V2)
{ VT93 VLEX93 CLSR93
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = list(3,VV[40],MAKE_FIXNUM(0),(V5));
	RETURN(1);}
}
/*	macro definition for CODE-PUT-PREDICATING                     */
static L90(int narg, object V1, object V2)
{ VT94 VLEX94 CLSR94
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = list(3,VV[40],MAKE_FIXNUM(0),(V5));
	RETURN(1);}
}
/*	macro definition for LENGTH-GET                               */
static L91(int narg, object V1, object V2)
{ VT95 VLEX95 CLSR95
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = VV[178];
	RETURN(1);}
}
/*	macro definition for LENGTH-PUT                               */
static L92(int narg, object V1, object V2)
{ VT96 VLEX96 CLSR96
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = list(3,VV[37],MAKE_FIXNUM(2),(V5));
	RETURN(1);}
}
/*	macro definition for LENGTH-PUT-PREDICATING                   */
static L93(int narg, object V1, object V2)
{ VT97 VLEX97 CLSR97
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = list(3,VV[37],MAKE_FIXNUM(2),(V5));
	RETURN(1);}
}
/*	macro definition for DATA-GET                                 */
static L95(int narg, object V1, object V2)
{ VT98 VLEX98 CLSR98
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	if(endp(V3)){
	V5= Cnil;
	} else {
	V5= CAR(V3);}
	if(((V5))==Cnil){
	goto L496;}
	if(!(type_of((V5))==t_cons)){
	goto L499;}
	L5(1,CAR((V5)))                           /*  GETIFY          */;
	T0= VALUES(0);
	VALUES(0) = listA(3,T0,MAKE_FIXNUM(1),CDR((V5)));
	RETURN(1);
L499:
	L5(1,(V5))                                /*  GETIFY          */;
	VALUES(0) = list(2,VALUES(0),MAKE_FIXNUM(1));
	RETURN(1);
L496:
	VALUES(0) = VV[181];
	RETURN(1);}
}
/*	macro definition for DATA-PUT                                 */
static L96(int narg, object V1, object V2)
{ VT99 VLEX99 CLSR99
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	if(endp(V3)){
	V6= Cnil;
	} else {
	V6= CAR(V3);}
	if(((V6))==Cnil){
	goto L505;}
	if(!(type_of((V6))==t_cons)){
	goto L508;}
	L6(1,CAR((V6)))                           /*  PUTIFY          */;
	T0= VALUES(0);
	VALUES(0) = list(3,VV[182],VV[183],list(3,VV[40],MAKE_FIXNUM(1),listA(4,T0,(V4),(V5),CDR((V6)))));
	RETURN(1);
L508:
	L6(1,(V6))                                /*  PUTIFY          */;
	VALUES(0) = list(3,VALUES(0),MAKE_FIXNUM(1),(V5));
	RETURN(1);
L505:
	VALUES(0) = list(3,VV[40],MAKE_FIXNUM(1),(V5));
	RETURN(1);}
}
/*	macro definition for DATA-PUT-PREDICATING                     */
static L97(int narg, object V1, object V2)
{ VT100 VLEX100 CLSR100
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	if(endp(V3)){
	V6= Cnil;
	} else {
	V6= CAR(V3);}
	if(((V6))==Cnil){
	goto L514;}
	{object V7= list(3,VV[184],(V5),list(2,VV[5],(V6)));
	if(!(type_of((V6))==t_cons)){
	goto L518;}
	L6(1,CAR((V6)))                           /*  PUTIFY          */;
	T0= VALUES(0);
	VALUES(0) = list(3,VV[182],VV[185],list(3,VV[40],MAKE_FIXNUM(1),listA(4,T0,(V4),(V5),CDR((V6)))));
	goto L516;
L518:
	L6(1,(V6))                                /*  PUTIFY          */;
	VALUES(0) = list(3,VALUES(0),MAKE_FIXNUM(1),(V5));
L516:
	VALUES(0) = list(3,VV[95],(V7),VALUES(0));
	RETURN(1);}
L514:
	{object V8= list(3,VV[184],(V5),VV[186]);
	VALUES(0) = list(3,VV[95],(V8),list(3,VV[40],MAKE_FIXNUM(1),(V5)));
	RETURN(1);}}
}
/*	macro definition for OR-EXPAND                                */
static L98(int narg, object V1, object V2)
{ VT101 VLEX101 CLSR101
	{object V3=CDR(V1),V4;
	V4= V3;
	{object V5;
	object V6= (V4);
	if(V6==Cnil){
	VALUES(0) = Cnil;
	goto L522;}
	T0=V5=CONS(Cnil,Cnil);
L523:
	{object V7;                               /*  FORMS           */
	{object V8;
	object V9= CAR(V6);
	if(V9==Cnil){
	CAR(V5)= Cnil;
	goto L524;}
	T1=V8=CONS(Cnil,Cnil);
L525:
	{object V10;                              /*  FORM            */
	Lmacroexpand(2,CAR(V9),(V2))              /*  MACROEXPAND     */;
	CAR(V8)= VALUES(0);
	}
	if((V9=CDR(V9))==Cnil){
	CAR(V5)= T1;
	goto L524;}
	V8=CDR(V8)=CONS(Cnil,Cnil);
	goto L525;}
	}
L524:
	if((V6=CDR(V6))==Cnil){
	VALUES(0) = T0;
	goto L522;}
	V5=CDR(V5)=CONS(Cnil,Cnil);
	goto L523;}
L522:
	VALUES(0) = CONS(VV[187],VALUES(0));
	RETURN(1);}
}
/*	macro definition for OR-GET                                   */
static L101(int narg, object V1, object V2)
{ VT102 VLEX102 CLSR102
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= V3;
	{volatile object V6;                      /*  TYPES           */
	volatile object V7;                       /*  VALUE           */
	volatile object V8;                       /*  RESULT          */
	Lgensym(0)                                /*  GENSYM          */;
	V7= VALUES(0);
	V6= (V5);
	V8= Cnil;
L529:
	if(!((V6)==Cnil)){
	goto L530;}
	{object V10= CONS(list(2,(V7),list(2,VV[30],(V4))),Cnil);
	{object V11= list(2,VV[93],list(3,VV[94],VV[29],(V7)));
	{object V12= list(4,VV[30],VV[188],VV[189],list(2,VV[5],(V7)));
	{object V13= list(2,(V12),list(4,VV[33],VV[190],VV[189],list(2,VV[5],(V7))));
	Lmacroexpand(2,CONS(VV[191],nreverse((V8))),(V2))/*  MACROEXPAND*/;
	VALUES(0) = list(4,VV[92],(V10),(V11),list(3,VV[182],(V13),VALUES(0)));
	RETURN(1);}}}}
L530:
	{register object V14;                     /*  ITEM            */
	register object V15;                      /*  ARGS            */
	V14= CAR((V6));
	V15= Cnil;
	if(!(type_of((V14))==t_cons)){
	goto L536;}
	V15= CDR((V14));
	V14= CAR((V14));
L536:
	if(!(((V14))==(VV[139]))){
	goto L543;}
	V8= CONS(list(2,list(2,VV[140],(V7)),Cnil),(V8));
	goto L534;
L543:
	L5(1,(V14))                               /*  GETIFY          */;
	V8= CONS(CONS(listA(3,VALUES(0),(V4),(V15)),Cnil),(V8));
	}
L534:
	V6= CDR((V6));
	goto L529;
	}}
}
/*	macro definition for OR-PUT                                   */
static L102(int narg, object V1, object V2)
{ VT103 VLEX103 CLSR103
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= V3;
	{volatile object V7;                      /*  TYPES           */
	volatile object V8;                       /*  RESULT          */
	V7= (V6);
	V8= Cnil;
L552:
	if(!((V7)==Cnil)){
	goto L553;}
	{object V10= nreverse((V8));
	VALUES(0) = CONS(VV[187],append((V10),CONS(list(2,Ct,list(3,VV[192],(V5),list(2,VV[5],CONS(VV[87],(V6))))),Cnil)));
	RETURN(1);}
L553:
	{register object V11;                     /*  TYPE            */
	register object V12;                      /*  TYPE-NAME       */
	register object V13;                      /*  ARGS            */
	V11= CAR((V7));
	V12= (V11);
	V13= Cnil;
	if(!(type_of((V11))==t_cons)){
	goto L560;}
	V13= CDR((V11));
	V12= CAR((V11));
L560:
	if((getf((V12)->s.s_plist,VV[111],Cnil))==Cnil){
	goto L569;}
	T0= Cnil;
	goto L567;
L569:
	T0= CONS(list(3,VV[184],(V5),list(2,VV[5],(V11))),Cnil);
L567:
	L6(2,(V12),getf((V12)->s.s_plist,VV[111],Cnil))/*  PUTIFY     */;
	V8= CONS(append(T0,CONS(listA(4,VALUES(0),(V4),(V5),(V13)),Cnil)),(V8));
	}
	V7= CDR((V7));
	goto L552;
	}}
}
/*	function definition for MASK-GET                              */
static L103(int narg, object V1, object V2, object V3)
{ VT104 VLEX104 CLSR104
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(V3,env0));            /*  BODY-FUNCTION   */
	{register object V4;                      /*  BIT             */
	register object V5;                       /*  RESULT          */
	V4= MAKE_FIXNUM(0);
	{int V8= (fix((V1)))+(4);
	VALUES(0) = make_cclosure(LC105,env0,&Cblock);
	L112(4,MAKE_FIXNUM(V8),(V2),Cnil,VALUES(0))/*  GET-PUT-ITEMS  */;
	{object V6;
	object V7= VALUES(0);
	if(V7==Cnil){
	V5= Cnil;
	goto L576;}
	T0=V6=CONS(Cnil,Cnil);
L577:
	{object V9;                               /*  FORM            */
	V9= CAR(V7);
	if(!(type_of((V9))!=t_cons)){
	goto L582;}
	CAR(V6)= (V9);
	goto L580;
L582:
	{object V10;
	V10= list(3,VV[194],list(3,VV[54],(V4),VV[195]),(V9));
	V4= number_plus((V4),MAKE_FIXNUM(1));
	CAR(V6)= (V10);
	}
	}
L580:
	if((V7=CDR(V7))==Cnil){
	V5= T0;
	goto L576;}
	V6=CDR(V6)=CONS(Cnil,Cnil);
	goto L577;}}
L576:
	if(!(type_of(CAR((V5)))!=t_cons)){
	goto L589;}
	{object V6;
	V6= CAR((V5));
	V5= CDR((V5));
	VALUES(0) = (V6);
	}
	T0= CONS(VALUES(0),Cnil);
	goto L587;
L589:
	T0= Cnil;
L587:
	{object V6= list(3,VV[197],VV[195],list(2,VV[30],(V1)));
	Lceiling(2,(V1),MAKE_FIXNUM(4))           /*  CEILING         */;
	VALUES(0) = append(T0,CONS(list(4,VV[1],(V6),list(3,VV[197],VV[198],VALUES(0)),CAR((V5))),CDR((V5))));
	RETURN(1);}
	}
}
/*	closure CLOSURE                                               */
static LC105(int narg, object env0, object V1, object V2, object V3, object V4)
{ VT105 VLEX105 CLSR105
	narg--;
	{object scan=env0;
	CLV0= &CAR(scan);                         /*  BODY-FUNCTION   */}
	RETURN(funcall(5,*CLV0,(V1),VV[196],(V3),(V4)));
}
/*	function definition for MASK-PUT                              */
static L106(int narg, object V1, object V2, object V3)
{ VT106 VLEX106 CLSR106
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(V3,env0));            /*  BODY-FUNCTION   */
	{object V4= list(2,VV[199],list(2,VV[198],(V1)));
	{ object env1 = env0;
	CLV1=&CAR(env1=CONS(MAKE_FIXNUM(1),env1));/*  BIT             */
	VALUES(0) = make_cclosure(LC107,env1,&Cblock);
	L112(4,(V1),(V2),Ct,VALUES(0))            /*  GET-PUT-ITEMS   */;
	T0= VALUES(0);
	}
	VALUES(0) = CONS(listA(3,VV[92],(V4),append(T0,CONS(list(3,VV[31],(V1),VV[195]),VV[206]))),Cnil);
	RETURN(1);}
}
/*	closure CLOSURE                                               */
static LC107(int narg, object env0, object V1, object V2, object V3, object V4)
{ VT107 VLEX107 CLSR107
	narg--;
	{object scan=env0;
	CLV1= &CAR(scan);                         /*  BIT             */ scan=CDR(scan);
	CLV0= &CAR(scan);                         /*  BODY-FUNCTION   */}
	if(type_of((V3))==t_symbol){
	goto L598;}
	Lconstantp(1,(V3))                        /*  CONSTANTP       */;
	if(VALUES(0)==Cnil){
	goto L599;}
L598:
	{object V5= list(2,VV[139],(V3));
	{object V6;
	object V7;
	V6= *CLV1;
	Lash(2,*CLV1,MAKE_FIXNUM(1))              /*  SHIFT<<         */;
	V7= VALUES(0);
	*CLV1= (V7);
	VALUES(0) = (V6);
	}
	{object V6= list(3,VV[197],VV[195],list(3,VV[201],VV[195],VALUES(0)));
	funcall(5,*CLV0,(V1),VV[202],(V3),(V4));
	VALUES(0) = CONS(listA(4,VV[200],(V5),(V6),VALUES(0)),Cnil);
	RETURN(1);}}
L599:
	{object V7= CONS(list(2,VV[203],(V3)),Cnil);
	{object V8;
	object V9;
	V8= *CLV1;
	Lash(2,*CLV1,MAKE_FIXNUM(1))              /*  SHIFT<<         */;
	V9= VALUES(0);
	*CLV1= (V9);
	VALUES(0) = (V8);
	}
	{object V8= list(3,VV[197],VV[195],list(3,VV[201],VV[195],VALUES(0)));
	funcall(5,*CLV0,(V1),VV[205],VV[203],(V4));
	VALUES(0) = CONS(list(3,VV[92],(V7),listA(4,VV[200],VV[204],(V8),VALUES(0))),Cnil);
	RETURN(1);}}
}
/*	macro definition for PROGN-GET                                */
static L108(int narg, object V1, object V2)
{ VT108 VLEX108 CLSR108
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = (V5);
	RETURN(1);}
}
/*	macro definition for PROGN-PUT                                */
static L109(int narg, object V1, object V2)
{ VT109 VLEX109 CLSR109
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	VALUES(0) = (V5);
	RETURN(1);}
}
/*	macro definition for TYPE-CHECK                               */
static L110(int narg, object V1, object V2)
{ VT110 VLEX110 CLSR110
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	{object V6= list(3,VV[184],(V4),(V5));
	VALUES(0) = list(3,VV[200],(V6),list(3,VV[192],(V4),(V5)));
	RETURN(1);}}
}
/*	macro definition for CHECK-PUT                                */
static L111(int narg, object V1, object V2)
{ VT111 VLEX111 CLSR111
	{object V3=CDR(V1),V4,V5,V6,V7;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= CAR(V3);
	V3=CDR(V3);
	V7= V3;
	{register object V8;                      /*  VAR             */
	object V9;                                /*  BODY            */
	if(type_of((V5))==t_symbol){
	goto L618;}
	Lconstantp(1,(V5))                        /*  CONSTANTP       */;
	if(VALUES(0)==Cnil){
	goto L619;}
L618:
	V8= (V5);
	goto L617;
L619:
	V8= VV[207];
L617:
	Lmacroexpand(2,list(3,VV[208],(V8),list(2,VV[5],(V6))),(V2))/*  MACROEXPAND*/;
	if(VALUES(0)==Cnil){
	goto L624;}
	if((memql((V6),VV[209]))!=Cnil){
	goto L624;}
	Lconstantp(1,(V5))                        /*  CONSTANTP       */;
	if(VALUES(0)==Cnil){
	goto L625;}
L624:
	L6(1,(V6))                                /*  PUTIFY          */;
	V9= listA(4,VALUES(0),(V4),(V8),(V7));
	goto L623;
L625:
	if((getf((V6)->s.s_plist,VV[111],Cnil))==Cnil){
	goto L633;}
	L6(2,(V6),Ct)                             /*  PUTIFY          */;
	{object V10= listA(4,VALUES(0),(V4),(V8),(V7));
	if(((V7))==Cnil){
	goto L638;}
	VALUES(0) = CONS((V6),(V7));
	goto L636;
L638:
	VALUES(0) = (V6);
L636:
	V9= list(3,VV[87],(V10),list(3,VV[192],(V8),list(2,VV[5],VALUES(0))));
	goto L623;}
L633:
	{object V11= list(3,VV[184],(V8),list(2,VV[5],(V6)));
	L6(1,(V6))                                /*  PUTIFY          */;
	{object V12= listA(4,VALUES(0),(V4),(V8),(V7));
	if(((V7))==Cnil){
	goto L643;}
	VALUES(0) = CONS((V6),(V7));
	goto L641;
L643:
	VALUES(0) = (V6);
L641:
	V9= list(4,VV[55],(V11),(V12),list(3,VV[192],(V8),list(2,VV[5],VALUES(0))));}}
L623:
	if(!(((V8))==((V5)))){
	goto L646;}
	VALUES(0) = (V9);
	RETURN(1);
L646:
	VALUES(0) = list(3,VV[92],CONS(list(2,(V8),(V5)),Cnil),(V9));
	RETURN(1);
	}}
}
/*	function definition for GET-PUT-ITEMS                         */
static L112(int narg, object V1, object V2, object V3, ...)
{ VT112 VLEX112 CLSR112
	{int i=3;
	volatile object V4;
	va_list args; va_start(args, V3);
	if (i==narg) goto L648;
	V4= va_arg(args, object);
	i++;
	goto L649;
L648:
	V4= Cnil;
L649:
	if(((V4))!=Cnil){
	goto L651;}
	V4= VV[506];
L651:
	{volatile object V5;                      /*  ITEMS           */
	volatile object V6;                       /*  TYPE            */
	volatile object V7;                       /*  ARGS            */
	volatile object V8;                       /*  RESULT          */
	volatile object V9;                       /*  SIZES           */
	V5= (V2);
	V6= CAAR((V5));
	V7= Cnil;
	V8= Cnil;
	V9= Cnil;
L661:
	if(!((V5)==Cnil)){
	goto L662;}
	VALUES(2) = (V9);
	VALUES(1) = (V1);
	VALUES(0) = (V8);
	RETURN(3);
L662:
	if(!(type_of((V6))==t_cons)){
	goto L665;}
	V7= CDR((V6));
	V6= CAR((V6));
L665:
	{volatile object V11;
	V11= memql((V6),VV[211]);
	if(((V11))==Cnil){
	goto L674;}
	goto L671;
L674:
	if(!(((V6))==(VV[193]))){
	goto L677;}
	if(((V3))==Cnil){
	goto L683;}
	L106(3,(V1),CDAR((V5)),(V4))              /*  MASK-PUT        */;
	goto L681;
L683:
	L103(3,(V1),CDAR((V5)),(V4))              /*  MASK-GET        */;
L681:
	V8= append((V8),VALUES(0));
	V1= Cnil;
	goto L671;
L677:
	{volatile object V12;                     /*  ITEM            */
	volatile object V13;                      /*  INCREMENT       */
	V12= CDAR((V5));
	L4(1,(V6))                                /*  INDEX-INCREMENT */;
	V13= VALUES(0);
L689:
	if(!((V12)==Cnil)){
	goto L690;}
	goto L671;
L690:
	Lconstantp(1,(V1))                        /*  CONSTANTP       */;
	if(VALUES(0)==Cnil){
	goto L693;}
	if(!eql((V13),VV[28]))goto L696;
	V1= MAKE_FIXNUM((((fix((V1)))+(1)) & (-2)));
	goto L693;
L696:
	if(!eql((V13),VV[212]))goto L698;
	V1= MAKE_FIXNUM((((fix((V1)))+(3)) & (-4)));
	goto L693;
L698:
L693:
	funcall(5,(V4),(V6),(V1),CAR((V12)),(V7));
	V8= append((V8),VALUES(0));
	Lconstantp(1,(V1))                        /*  CONSTANTP       */;
	if(VALUES(0)==Cnil){
	goto L703;}
	if(((V13))!=Cnil){
	goto L707;}
	V1= Cnil;
	goto L703;
L707:
	V1= number_plus((V1),(V13));
	if(((V13))==Cnil){
	goto L712;}
	if(!(number_compare(MAKE_FIXNUM(0),(V13))==0)){
	goto L712;}
	V13= MAKE_FIXNUM(1);
L712:
	Ladjoin(2,number_times((V13),MAKE_FIXNUM(8)),(V9))/*  ADJOIN  */;
	V9= VALUES(0);
L703:
	V12= CDR((V12));
	goto L689;
	}
	}
L671:
	V5= CDR((V5));
	V6= CAAR((V5));
	V7= Cnil;
	goto L661;
	}
	}
}
/*	macro definition for WITH-BUFFER-REQUEST-INTERNAL             */
static L114(int narg, object V1, object V2)
{ VT113 VLEX113 CLSR113
	{object V3=CDR(V1),V4,V5,V6,V7,V8;
	{object V9= CAR(V3);
	V4= CAR(V9);
	V9=CDR(V9);
	V5= CAR(V9);
	V9=CDR(V9);
	{object V10;
	V10=getf(V9,VV[216],OBJNULL);
	if(V10==OBJNULL){
	V6= Cnil;
	} else {
	V6= V10;}
	V10=getf(V9,VV[217],OBJNULL);
	if(V10==OBJNULL){
	V7= Cnil;
	} else {
	V7= V10;}}}
	V3=CDR(V3);
	V8= V3;
	{ int V11;
	object V12;                               /*  CODE            */
	register object V13;                      /*  INDEX           */
	object V14;                               /*  ITEM-SIZES      */
	V11=L112(3,MAKE_FIXNUM(4),(V8),Ct)        /*  GET-PUT-ITEMS   */;
	if (V11--==0) goto L732;
	V12= VALUES(0);
	if (V11--==0) goto L733;
	V13= VALUES(1);
	if (V11--==0) goto L734;
	V14= VALUES(2);
	goto L735;
L732:
	V12= Cnil;
L733:
	V13= Cnil;
L734:
	V14= Cnil;
L735:
	{object V15;                              /*  LENGTH          */
	object V16;
	object V17;                               /*  SIZES           */
	if(((V6))==Cnil){
	goto L738;}
	V16= list(3,VV[9],(V6),VV[213]);
	goto L736;
L738:
	V16= VV[213];
L736:
	Lappend(3,VV[214],(V14),(V7))             /*  APPEND          */;
	(*LK2)(1,VALUES(0))                       /*  REMOVE-DUPLICATES*/;
	V17= VALUES(0);
	V15= V16;
	{object V18= list(5,(V4),VV[216],(V15),VV[217],(V17));
	{object V19= list(3,VV[23],list(2,VV[218],(V4)),VV[147]);
	{object V20= list(3,VV[40],MAKE_FIXNUM(0),(V5));
	if(((V13))==Cnil){
	goto L744;}
	V13= MAKE_FIXNUM((((fix((V13)))+(3)) & (-4)));
	Lceiling(2,(V13),MAKE_FIXNUM(4))          /*  CEILING         */;
	{object V21= list(3,VV[37],MAKE_FIXNUM(2),VALUES(0));
	{object V22= list(2,VV[147],(V4));
	T0= list(2,(V21),list(3,VV[23],(V22),list(3,VV[9],VV[147],(V13))));
	goto L742;}}
L744:
	T0= Cnil;
L742:
	Lappend(3,(V12),T0,CONS(list(2,VV[219],(V4)),Cnil))/*  APPEND */;
	VALUES(0) = listA(5,VV[215],(V18),(V19),(V20),VALUES(0));
	RETURN(1);}}}
	}}}
}
/*	macro definition for WITH-BUFFER-REQUEST                      */
static L115(int narg, object V1, object V2)
{ VT114 VLEX114 CLSR114
	{object V3=CDR(V1),V4,V5,V6,V7,V8,V9;
	{object V10= CAR(V3);
	V4= CAR(V10);
	V10=CDR(V10);
	V5= CAR(V10);
	V10=CDR(V10);
	V6= V10;
	{object V11;
	V11=getf(V10,VV[544],OBJNULL);
	if(V11==OBJNULL){
	V7= Cnil;
	} else {
	V7= V11;}
	V11=getf(V10,VV[545],OBJNULL);
	if(V11==OBJNULL){
	V8= Cnil;
	} else {
	V8= V11;}}}
	V3=CDR(V3);
	V9= V3;
	if(((V7))!=Cnil){
	goto L753;}
	Lmacroexpand(2,VV[221],(V2))              /*  MACROEXPAND     */;
	if(VALUES(0)==Cnil){
	goto L753;}
	{object V12= CONS(list(4,VV[223],VV[224],VV[225],listA(3,VV[226],listA(3,VV[227],(V5),(V6)),(V9))),Cnil);
	Lmacroexpand(2,VV[228],(V2))              /*  MACROEXPAND     */;
	if(!((CAR(VALUES(0)))==(VV[1]))){
	goto L759;}
	VALUES(0) = VV[229];
	goto L757;
L759:
	VALUES(0) = VV[230];
L757:
	VALUES(0) = list(3,VV[222],(V12),list(4,VALUES(0),(V4),(V8),VV[231]));
	RETURN(1);}
L753:
	{object V13= CONS(list(2,VV[227],(V4)),Cnil);
	if(((V8))==Cnil){
	goto L764;}
	T0= CONS(list(2,VV[235],(V8)),Cnil);
	goto L762;
L764:
	T0= Cnil;
L762:
	VALUES(0) = list(4,VV[92],(V13),VV[232],listA(3,VV[233],VV[234],append(T0,CONS(list(3,VV[236],list(2,VV[237],listA(3,VV[226],listA(3,VV[227],(V5),(V6)),(V9))),VV[238]),Cnil))));
	RETURN(1);}}
}
/*	macro definition for WITH-BUFFER-REQUEST-AND-REPLY            */
static L116(int narg, object V1, object V2)
{ VT115 VLEX115 CLSR115
	{object V3=CDR(V1),V4,V5,V6,V7,V8,V9,V10,V11;
	{object V12= CAR(V3);
	V4= CAR(V12);
	V12=CDR(V12);
	V5= CAR(V12);
	V12=CDR(V12);
	V6= CAR(V12);
	V12=CDR(V12);
	{object V13;
	V13=getf(V12,VV[217],OBJNULL);
	if(V13==OBJNULL){
	V7= Cnil;
	} else {
	V7= V13;}
	V13=getf(V12,VV[546],OBJNULL);
	if(V13==OBJNULL){
	V8= Cnil;
	} else {
	V8= V13;}
	V13=getf(V12,VV[544],OBJNULL);
	if(V13==OBJNULL){
	V9= Cnil;
	} else {
	V9= V13;}}}
	V3=CDR(V3);
	V10= CAR(V3);
	V3=CDR(V3);
	V11= V3;
	{object V14;                              /*  INNER-REPLY-BODY*/
	object V15;                               /*  REPLY-BODY      */
	if((V7)==Cnil){
	VALUES(0) = Cnil;
	goto L770;}
	VALUES(0) = list(2,VV[217],(V7));
L770:
	V14= listA(4,VV[239],listA(4,VV[240],VV[241],VV[227],VALUES(0)),Cnil,(V11));
	if(!(type_of((V6))==t_symbol)){
	goto L772;}
	Lconstantp(1,(V6))                        /*  CONSTANTP       */;
	if(VALUES(0)==Cnil){
	goto L773;}
L772:
	V15= (V14);
	goto L771;
L773:
	{object V16= CONS(list(2,(V6),VV[242]),Cnil);
	V15= list(4,VV[92],(V16),list(2,VV[93],list(3,VV[94],VV[7],(V6))),(V14));}
L771:
	if(((V9))!=Cnil){
	goto L778;}
	Lmacroexpand(2,VV[243],(V2))              /*  MACROEXPAND     */;
	if(VALUES(0)==Cnil){
	goto L778;}
	{object V16= list(4,VV[223],VV[244],VV[245],listA(3,VV[226],list(2,VV[227],(V5)),(V10)));
	{object V17= list(2,(V16),list(5,VV[246],VV[247],VV[248],VV[249],(V15)));
	VALUES(0) = list(3,VV[222],(V17),listA(4,VV[250],(V4),(V8),VV[251]));
	RETURN(1);}}
L778:
	{object V18= CONS(list(2,VV[227],(V4)),VV[252]);
	{object V19= listA(5,VV[233],VV[255],VV[256],list(2,VV[237],listA(3,VV[226],list(2,VV[227],(V5)),(V10))),VV[257]);
	if(((V8))==Cnil){
	goto L784;}
	VALUES(0) = CONS(list(4,VV[258],VV[259],list(3,VV[194],(V15),VV[260]),VV[261]),Cnil);
	goto L782;
L784:
	VALUES(0) = list(2,VV[262],(V15));
L782:
	VALUES(0) = list(4,VV[92],(V18),VV[253],listA(3,VV[254],listA(3,VV[1],(V19),VALUES(0)),VV[263]));
	RETURN(1);}}
	}}
}
/*	macro definition for COMPARE-REQUEST                          */
static L117(int narg, object V1, object V2)
{ VT116 VLEX116 CLSR116
	{object V3=CDR(V1),V4,V5;
	{object V6= CAR(V3);
	V4= CAR(V6);}
	V3=CDR(V3);
	V5= V3;
	L112(3,(V4),(V5),Ct)                      /*  GET-PUT-ITEMS   */;
	VALUES(0) = list(3,VV[182],VV[264],list(3,VV[182],VV[265],CONS(VV[95],VALUES(0))));
	RETURN(1);}
}
/*	macro definition for PUT-ITEMS                                */
static L118(int narg, object V1, object V2)
{ VT117 VLEX117 CLSR117
	{object V3=CDR(V1),V4,V5;
	{object V6= CAR(V3);
	V4= CAR(V6);}
	V3=CDR(V3);
	V5= V3;
	L112(3,(V4),(V5),Ct)                      /*  GET-PUT-ITEMS   */;
	VALUES(0) = CONS(VV[1],VALUES(0));
	RETURN(1);}
}
/*	macro definition for DECODE-TYPE                              */
static L119(int narg, object V1, object V2)
{ VT118 VLEX118 CLSR118
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	{object V6;                               /*  ARGS            */
	V6= Cnil;
	if(!(type_of((V4))==t_cons)){
	goto L788;}
	V6= CDR((V4));
	V4= CAR((V4));
L788:
	L5(1,(V4))                                /*  GETIFY          */;
	VALUES(0) = list(3,VV[182],VV[266],listA(3,VALUES(0),(V5),(V6)));
	RETURN(1);
	}}
}
/*	macro definition for ENCODE-TYPE                              */
static L120(int narg, object V1, object V2)
{ VT119 VLEX119 CLSR119
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	{object V6;                               /*  ARGS            */
	V6= Cnil;
	if(!(type_of((V4))==t_cons)){
	goto L795;}
	V6= CDR((V4));
	V4= CAR((V4));
L795:
	VALUES(0) = list(3,VV[182],VV[267],listA(5,VV[210],MAKE_FIXNUM(0),(V5),(V4),(V6)));
	RETURN(1);
	}}
}
/*	macro definition for SET-DECODE-TYPE                          */
static L121(int narg, object V1, object V2)
{ VT120 VLEX120 CLSR120
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= CAR(V3);
	VALUES(0) = list(3,VV[23],(V5),list(3,VV[268],(V4),(V6)));
	RETURN(1);}
}
/*	macro definition for THREADED-ATOMIC-PUSH                     */
static L122(int narg, object V1, object V2)
{ VT121 VLEX121 CLSR121
	{object V3=CDR(V1),V4,V5,V6,V7;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= CAR(V3);
	V3=CDR(V3);
	V7= CAR(V3);
	{register object V8;                      /*  X               */
	object V9;
	register object V10;                      /*  Y               */
	Lgensym(0)                                /*  GENSYM          */;
	V9= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V10= VALUES(0);
	V8= V9;
	{object V11= CONS(list(2,(V8),(V4)),Cnil);
	{object V12= list(2,VV[93],list(3,VV[94],(V7),(V8)));
	{object V13= CONS(list(2,(V10),(V5)),Cnil);
	{object V14= list(3,VV[93],list(3,VV[94],list(3,VV[87],VV[139],(V7)),(V10)),VV[395]);
	{object V15= list(3,VV[23],list(2,(V6),(V8)),(V10));
	{object V16= list(4,VV[396],(V5),(V10),(V8));
	VALUES(0) = list(4,VV[92],(V11),(V12),list(2,VV[258],list(5,VV[92],(V13),(V14),(V15),list(3,VV[194],(V16),list(2,VV[397],(V8))))));
	RETURN(1);}}}}}}
	}}
}
/*	macro definition for THREADED-ATOMIC-POP                      */
static L123(int narg, object V1, object V2)
{ VT122 VLEX122 CLSR122
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= CAR(V3);
	{register object V7;                      /*  Y               */
	Lgensym(0)                                /*  GENSYM          */;
	V7= VALUES(0);
	{object V8= CONS(list(2,(V7),(V4)),Cnil);
	{object V9= list(3,VV[93],list(3,VV[94],list(3,VV[87],VV[139],(V6)),(V7)),VV[398]);
	{object V10= list(2,VV[139],(V7));
	{object V11= list(4,VV[396],(V4),(V7),list(2,(V5),list(3,VV[6],(V6),(V7))));
	{object V12= list(3,VV[23],list(2,(V5),list(3,VV[6],(V6),(V7))),Cnil);
	VALUES(0) = list(2,VV[258],list(4,VV[92],(V8),(V9),list(4,VV[55],(V10),VV[399],list(4,VV[194],(V11),(V12),list(2,VV[397],(V7))))));
	RETURN(1);}}}}}
	}}
}
/*	macro definition for THREADED-NCONC                           */
static L124(int narg, object V1, object V2)
{ VT123 VLEX123 CLSR123
	{object V3=CDR(V1),V4,V5,V6,V7;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= CAR(V3);
	V3=CDR(V3);
	V7= CAR(V3);
	{register object V8;                      /*  FIRST           */
	object V9;
	register object V10;                      /*  X               */
	object V11;
	register object V12;                      /*  Y               */
	object V13;
	register object V14;                      /*  Z               */
	Lgensym(0)                                /*  GENSYM          */;
	V9= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V11= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V13= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V14= VALUES(0);
	V8= V9;
	V10= V11;
	V12= V13;
	{object V15= list(2,(V14),(V4));
	{object V16= list(2,(V15),list(2,(V8),(V5)));
	{object V17= list(3,VV[94],(V7),(V14));
	{object V18= list(4,VV[93],(V17),list(3,VV[94],list(3,VV[87],VV[139],(V7)),(V8)),VV[400]);
	{object V19= list(2,VV[139],(V8));
	{object V20= list(3,VV[23],(V5),(V14));
	{object V21= list(3,(V10),(V8),(V12));
	{object V22= list(2,(V6),(V10));
	{object V23= list(2,(V21),list(3,(V12),(V22),list(2,(V6),(V10))));
	{object V24= list(2,VV[139],(V12));
	{object V25= list(3,(V24),list(3,VV[23],list(2,(V6),(V10)),(V14)),(V8));
	{object V26= list(3,VV[94],(V7),(V10));
	VALUES(0) = list(4,VV[92],(V16),(V18),list(4,VV[55],(V19),(V20),list(4,VV[401],(V23),(V25),list(3,VV[93],(V26),list(3,VV[94],list(3,VV[87],VV[139],(V7)),(V12))))));
	RETURN(1);}}}}}}}}}}}}
	}}
}
/*	macro definition for THREADED-PUSH                            */
static L125(int narg, object V1, object V2)
{ VT124 VLEX124 CLSR124
	{object V3=CDR(V1),V4,V5,V6,V7;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= CAR(V3);
	V3=CDR(V3);
	V7= CAR(V3);
	{register object V8;                      /*  X               */
	Lgensym(0)                                /*  GENSYM          */;
	V8= VALUES(0);
	{object V9= CONS(list(2,(V8),(V4)),Cnil);
	{object V10= list(3,VV[93],list(3,VV[94],(V7),(V8)),VV[402]);
	VALUES(0) = list(5,VV[92],(V9),(V10),list(4,VV[403],list(2,(V6),(V8)),(V5),(V8)),(V8));
	RETURN(1);}}
	}}
}
/*	macro definition for THREADED-POP                             */
static L126(int narg, object V1, object V2)
{ VT125 VLEX125 CLSR125
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= CAR(V3);
	{register object V7;                      /*  X               */
	Lgensym(0)                                /*  GENSYM          */;
	V7= VALUES(0);
	{object V8= CONS(list(2,(V7),(V4)),Cnil);
	{object V9= list(3,VV[93],list(3,VV[94],list(3,VV[87],VV[139],(V6)),(V7)),VV[404]);
	VALUES(0) = list(5,VV[92],(V8),(V9),list(3,VV[194],(V7),list(4,VV[403],(V4),list(2,(V5),list(3,VV[6],(V6),(V7))),Cnil)),(V7));
	RETURN(1);}}
	}}
}
/*	macro definition for THREADED-ENQUEUE                         */
static L127(int narg, object V1, object V2)
{ VT126 VLEX126 CLSR126
	{object V3=CDR(V1),V4,V5,V6,V7,V8;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= CAR(V3);
	V3=CDR(V3);
	V7= CAR(V3);
	V3=CDR(V3);
	V8= CAR(V3);
	{register object V9;                      /*  X               */
	Lgensym(0)                                /*  GENSYM          */;
	V9= VALUES(0);
	{object V10= CONS(list(2,(V9),(V4)),Cnil);
	{object V11= list(3,VV[93],list(3,VV[94],(V8),(V9)),VV[405]);
	{object V12= list(2,VV[139],(V6));
	{object V13= list(5,VV[406],(V9),(V5),(V7),(V8));
	{object V14= list(4,VV[55],(V12),(V13),list(5,VV[406],(V9),list(2,(V7),list(3,VV[6],(V8),(V6))),(V7),(V8)));
	VALUES(0) = list(5,VV[92],(V10),(V11),(V14),list(3,VV[23],(V6),(V9)));
	RETURN(1);}}}}}
	}}
}
/*	macro definition for THREADED-DEQUEUE                         */
static L128(int narg, object V1, object V2)
{ VT127 VLEX127 CLSR127
	{object V3=CDR(V1),V4,V5,V6,V7;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= CAR(V3);
	V3=CDR(V3);
	V7= CAR(V3);
	{register object V8;                      /*  X               */
	Lgensym(0)                                /*  GENSYM          */;
	V8= VALUES(0);
	{object V9= CONS(list(2,(V8),(V4)),Cnil);
	{object V10= list(3,VV[93],list(3,VV[94],list(3,VV[87],VV[139],(V7)),(V8)),VV[407]);
	{object V11= list(3,VV[119],(V8),(V5));
	{object V12= list(3,VV[194],(V11),list(3,VV[23],(V5),list(2,(V6),list(3,VV[6],(V7),(V8)))));
	VALUES(0) = list(5,VV[92],(V9),(V10),list(4,VV[194],(V8),(V12),list(3,VV[23],(V4),list(2,(V6),list(3,VV[6],(V7),(V8))))),(V8));
	RETURN(1);}}}}
	}}
}
/*	macro definition for THREADED-REQUEUE                         */
static L129(int narg, object V1, object V2)
{ VT128 VLEX128 CLSR128
	{object V3=CDR(V1),V4,V5,V6,V7,V8;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= CAR(V3);
	V3=CDR(V3);
	V7= CAR(V3);
	V3=CDR(V3);
	V8= CAR(V3);
	{register object V9;                      /*  X               */
	Lgensym(0)                                /*  GENSYM          */;
	V9= VALUES(0);
	{object V10= CONS(list(2,(V9),(V4)),Cnil);
	{object V11= list(3,VV[93],list(3,VV[94],(V8),(V9)),VV[408]);
	{object V12= list(2,VV[139],(V6));
	{object V13= list(3,VV[23],(V6),list(3,VV[23],(V5),(V9)));
	VALUES(0) = list(5,VV[92],(V10),(V11),list(4,VV[55],(V12),(V13),list(4,VV[403],list(2,(V7),(V9)),(V5),(V9))),(V9));
	RETURN(1);}}}}
	}}
}
/*	macro definition for THREADED-DOLIST                          */
static L130(int narg, object V1, object V2)
{ VT129 VLEX129 CLSR129
	{object V3=CDR(V1),V4,V5,V6,V7,V8;
	{object V9= CAR(V3);
	V4= CAR(V9);
	V9=CDR(V9);
	V5= CAR(V9);
	V9=CDR(V9);
	V6= CAR(V9);
	V9=CDR(V9);
	V7= CAR(V9);}
	V3=CDR(V3);
	V8= V3;
	{object V10= CONS(list(3,(V4),(V5),list(2,(V6),list(3,VV[6],(V7),(V4)))),Cnil);
	{object V11= CONS(list(2,VV[139],(V4)),Cnil);
	VALUES(0) = list(3,VV[409],Cnil,listA(5,VV[401],(V10),(V11),list(2,VV[93],list(3,VV[94],list(3,VV[87],VV[139],(V7)),(V4))),(V8)));
	RETURN(1);}}}
}
/*	macro definition for THREADED-DELETE                          */
static L131(int narg, object V1, object V2)
{ VT130 VLEX130 CLSR130
	{object V3=CDR(V1),V4,V5,V6,V7;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= CAR(V3);
	V3=CDR(V3);
	V7= CAR(V3);
	{register object V8;                      /*  X               */
	object V9;
	register object V10;                      /*  Y               */
	object V11;
	register object V12;                      /*  Z               */
	object V13;
	register object V14;                      /*  FIRST           */
	Lgensym(0)                                /*  GENSYM          */;
	V9= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V11= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V13= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V14= VALUES(0);
	V8= V9;
	V10= V11;
	V12= V13;
	{object V15= list(2,(V8),(V4));
	{object V16= list(2,(V15),list(2,(V14),(V5)));
	{object V17= list(3,VV[94],(V7),(V8));
	{object V18= list(4,VV[93],(V17),list(3,VV[94],list(3,VV[87],VV[139],(V7)),(V14)),VV[410]);
	{object V19= list(3,VV[119],(V14),(V8));
	{object V20= list(3,VV[23],(V14),list(3,VV[23],(V5),list(2,(V6),(V8))));
	{object V21= list(3,(V10),(V14),(V12));
	{object V22= list(2,(V6),(V10));
	{object V23= list(2,(V21),list(3,(V12),(V22),list(2,(V6),(V10))));
	{object V24= list(2,VV[139],(V12));
	{object V25= list(3,VV[87],(V24),list(3,VV[119],(V12),(V8)));
	{object V26= list(3,VV[119],(V12),(V8));
	{object V27= list(2,(V6),(V10));
	{object V28= list(2,(V25),list(3,VV[194],(V26),list(3,VV[23],(V27),list(2,(V6),(V8)))));
	{object V29= list(2,VV[93],list(3,VV[94],(V7),(V10)));
	{object V30= list(3,VV[194],(V14),list(4,VV[55],(V19),(V20),list(5,VV[401],(V23),(V28),(V29),list(2,VV[93],list(3,VV[94],list(3,VV[87],VV[139],(V7)),(V12))))));
	VALUES(0) = list(6,VV[92],(V16),(V18),(V30),list(3,VV[23],list(2,(V6),(V8)),Cnil),(V14));
	RETURN(1);}}}}}}}}}}}}}}}}
	}}
}
/*	macro definition for THREADED-LENGTH                          */
static L132(int narg, object V1, object V2)
{ VT131 VLEX131 CLSR131
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= CAR(V3);
	{register object V7;                      /*  X               */
	object V8;
	register object V9;                       /*  COUNT           */
	Lgensym(0)                                /*  GENSYM          */;
	V8= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V9= VALUES(0);
	V7= V8;
	{object V10= list(3,(V7),(V4),list(2,(V5),list(3,VV[6],(V6),(V7))));
	{object V11= list(2,(V10),list(3,(V9),MAKE_FIXNUM(0),list(2,VV[412],(V9))));
	{object V12= list(2,list(2,VV[139],(V7)),(V9));
	{object V13= list(3,VV[94],list(3,VV[87],VV[139],(V6)),(V7));
	VALUES(0) = list(4,VV[411],(V11),(V12),list(4,VV[93],(V13),list(3,VV[94],VV[7],(V9)),VV[413]));
	RETURN(1);}}}}
	}}
}
static LKF2(int narg, ...) {TRAMPOLINK(VV[543],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[523],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[522],&LK0);}
