/*
    num_include.h  -- Number routine include file.
*/
/*
    Copyright (c) 1984, Taiichi Yuasa and Masami Hagiya.
    Copyright (c) 1990, Giuseppe Attardi.

    ECoLisp is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    See file '../Copyright' for full details.
*/


#define MASK	0x7fffffff

#ifdef MV
#define	extended_mul(d, q, r, hp, rp)	EMUL(d, q, r, hp, rp)
#define	extended_div(d, h, l, qp, rp)	EDIV(d, h, l, qp, rp)
#endif

object shortfloat_zero;
object longfloat_zero;
object Sshort_float;
object Ssingle_float;
object Sdouble_float;
object Slong_float;
object Vrandom_state;


#define BOOLCLR		0
#define BOOLSET		017
#define BOOL1		03
#define BOOL2		05
#define BOOLC1		014
#define BOOLC2		012
#define BOOLAND		01
#define BOOLIOR		07
#define BOOLXOR		06
#define BOOLEQV		011
#define BOOLNAND	016
#define BOOLNOR		010
#define BOOLANDC1	04
#define BOOLANDC2	02
#define BOOLORC1	015
#define BOOLORC2	013

#define PI			3.141592653589793L

#ifdef LOCATIVE
#define MOST_POSITIVE_FIX	 268435455
#define MOST_NEGATIVE_FIX	-268435456
#else
#define MOST_POSITIVE_FIX	 536870911
#define MOST_NEGATIVE_FIX	-536870912
#endif LOCATIVE
