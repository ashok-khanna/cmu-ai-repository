
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "cmploc.h"
init_cmploc(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_cmploc; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	VV[0]->s.s_stype=(short)stp_special;
	MF0(VV[6],L1);
	MF0(VV[7],L2);
	MF0(VV[31],L3);
	MF0(VV[32],L4);
	MF0(VV[33],L5);
	MF0(VV[34],L6);
	MF0(VV[35],L7);
	MF0(VV[36],L8);
	MF0(VV[37],L9);
	MF0(VV[38],L10);
	MF0(VV[39],L11);
	MF0(VV[40],L12);
	MF0(VV[41],L13);
	MF0(VV[42],L14);
	MF0(VV[43],L15);
	MF0(VV[44],L16);
	MF0(VV[45],L17);
	MF0(VV[46],L18);
	MF0(VV[47],L19);
	MF0(VV[48],L20);
	MF0(VV[49],L21);
	VALUES(0) = (VV[38]->s.s_gfdef);
	putprop(VV[18],VALUES(0),VV[7]);
	VALUES(0) = (VV[37]->s.s_gfdef);
	putprop(VV[19],VALUES(0),VV[7]);
	VALUES(0) = (VV[36]->s.s_gfdef);
	putprop(VV[20],VALUES(0),VV[7]);
	VALUES(0) = (VV[32]->s.s_gfdef);
	putprop(VV[21],VALUES(0),VV[7]);
	VALUES(0) = (VV[33]->s.s_gfdef);
	putprop(VV[22],VALUES(0),VV[7]);
	VALUES(0) = (VV[34]->s.s_gfdef);
	putprop(VV[23],VALUES(0),VV[7]);
	VALUES(0) = (VV[39]->s.s_gfdef);
	putprop(VV[24],VALUES(0),VV[7]);
	VALUES(0) = (VV[41]->s.s_gfdef);
	putprop(VV[25],VALUES(0),VV[7]);
	VALUES(0) = (VV[40]->s.s_gfdef);
	putprop(VV[26],VALUES(0),VV[7]);
	VALUES(0) = (VV[39]->s.s_gfdef);
	putprop(VV[27],VALUES(0),VV[7]);
	VALUES(0) = (VV[39]->s.s_gfdef);
	putprop(VV[28],VALUES(0),VV[7]);
	VALUES(0) = (VV[45]->s.s_gfdef);
	putprop(VV[29],VALUES(0),VV[7]);
	VALUES(0) = (VV[46]->s.s_gfdef);
	putprop(VV[5],VALUES(0),VV[7]);
	VALUES(0) = (VV[47]->s.s_gfdef);
	putprop(VV[3],VALUES(0),VV[7]);
	VALUES(0) = (VV[48]->s.s_gfdef);
	putprop(VV[3],VALUES(0),VV[6]);
	VALUES(0) = (VV[49]->s.s_gfdef);
	putprop(VV[30],VALUES(0),VV[7]);
}
/*	function definition for SET-LOC                               */
static L1(int narg, object V1)
{ VT3 VLEX3 CLSR3
TTL:
	{register object V2;                      /*  FD              */
	V2= Cnil;
	if(!(type_of((V1))==t_cons)){
	goto L34;}
	if((memq(CAR((V1)),VV[2]))==Cnil){
	goto L34;}
	if(!(type_of((VV[0]->s.s_dbind))==t_cons)){
	goto L39;}
	if((CAR((VV[0]->s.s_dbind)))==(VV[3])){
	goto L34;}
L39:
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[4]));
	V1= VV[1];
L34:
	if(((VV[0]->s.s_dbind)!= VV[8]))goto L49;
	if(!(type_of((V1))==t_cons)){
	goto L50;}
	if((CAR((V1)))==(VV[3])){
	goto L51;}
	if((CAR((V1)))==(VV[5])){
	goto L51;}
L50:
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("VALUES(0) = ",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L51:
	VALUES(0) = Cnil;
	RETURN(1);
L49:
	if(((VV[0]->s.s_dbind)!= VV[51]))goto L62;
	if(!(type_of((V1))==t_cons)){
	goto L64;}
	{object V3= CAR((V1));
	if((V3== VV[52])
	|| (V3== VV[53])
	|| (V3== VV[54])
	|| (V3== VV[55])
	|| (V3== VV[56]))goto L67;
	if((V3!= VV[57]))goto L66;
L67:
	if((CADR((V1)))==Cnil){
	goto L69;}
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	(*LK1)(3,Ct,CADDR((V1)),CADDDR((V1)))     /*  WT-INLINE       */;
	princ_char(59,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L69:
	VALUES(0) = Cnil;
	RETURN(1);
L66:
	if((V3!= VV[59])
	&& (V3!= VV[60]))goto L76;
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("(void)",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L76:
	VALUES(0) = Cnil;
	RETURN(1);}
L64:
	VALUES(0) = Cnil;
	RETURN(1);
L62:
	if(!(type_of((VV[0]->s.s_dbind))==t_cons)){
	goto L82;}
	if(type_of(CAR((VV[0]->s.s_dbind)))==t_symbol){
	goto L83;}
L82:
	RETURN((*LK2)(0)                          /*  BABOON          */);
L83:
	V2= getf(CAR((VV[0]->s.s_dbind))->s.s_plist,VV[6],Cnil);
	if(((V2))==Cnil){
	goto L88;}
	RETURN(Lapply(3,(V2),(V1),CDR((VV[0]->s.s_dbind)))/*  APPLY   */);
L88:
	V2= getf(CAR((VV[0]->s.s_dbind))->s.s_plist,VV[7],Cnil);
	if(((V2))==Cnil){
	goto L92;}
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	Lapply(2,(V2),CDR((VV[0]->s.s_dbind)))    /*  APPLY           */;
	princ_str("= ",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L92:
	RETURN((*LK2)(0)                          /*  BABOON          */);
	}
}
/*	function definition for WT-LOC                                */
static L2(int narg, object V1)
{ VT4 VLEX4 CLSR4
TTL:
	{object V2;                               /*  FD              */
	V2= Cnil;
	if(!(((V1))==(Cnil))){
	goto L104;}
	princ_str("Cnil",symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L104:
	if(!(((V1))==(Ct))){
	goto L108;}
	princ_str("Ct",symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L108:
	if(!(((V1))==(VV[8]))){
	goto L112;}
	princ_str("VALUES(0)",symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L112:
	if(!(type_of((V1))==t_cons)){
	goto L115;}
	if(type_of(CAR((V1)))==t_symbol){
	goto L116;}
L115:
	RETURN((*LK2)(0)                          /*  BABOON          */);
L116:
	V2= getf(CAR((V1))->s.s_plist,VV[7],Cnil);
	if(((V2))==Cnil){
	goto L121;}
	RETURN(Lapply(2,(V2),CDR((V1)))           /*  APPLY           */);
L121:
	RETURN((*LK2)(0)                          /*  BABOON          */);
	}
}
/*	function definition for LAST-CALL-P                           */
static L3(int narg)
{ VT5 VLEX5 CLSR5
TTL:
	VALUES(0) = memql((VV[9]->s.s_dbind),VV[10]);
	RETURN(1);
}
/*	function definition for WT-CAR                                */
static L4(int narg, object V1)
{ VT6 VLEX6 CLSR6
TTL:
	princ_str("CAR(",symbol_value(VV[4]));
	L7(1,(V1))                                /*  WT-LCL          */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-CDR                                */
static L5(int narg, object V1)
{ VT7 VLEX7 CLSR7
TTL:
	princ_str("CDR(",symbol_value(VV[4]));
	L7(1,(V1))                                /*  WT-LCL          */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-CADR                               */
static L6(int narg, object V1)
{ VT8 VLEX8 CLSR8
TTL:
	princ_str("CADR(",symbol_value(VV[4]));
	L7(1,(V1))                                /*  WT-LCL          */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-LCL                                */
static L7(int narg, object V1)
{ VT9 VLEX9 CLSR9
TTL:
	princ_char(86,symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-VV                                 */
static L8(int narg, object V1)
{ VT10 VLEX10 CLSR10
TTL:
	princ_str("VV[",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(93,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-LCL-LOC                            */
static L9(int narg, object V1)
{ VT11 VLEX11 CLSR11
TTL:
	RETURN(L7(1,(V1))                         /*  WT-LCL          */);
}
/*	function definition for WT-TEMP                               */
static L10(int narg, object V1)
{ VT12 VLEX12 CLSR12
TTL:
	princ_char(84,symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-NUMBER                             */
static L11(int narg, object V1, ...)
{ VT13 VLEX13 CLSR13
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if (i==narg) goto L143;
	V2= va_arg(args, object);
	i++;
	goto L144;
L143:
	V2= Cnil;
L144:
	{object V3;
	(*LK3)(2,(V1),VV[11])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L147;}
	princ_str("MAKE_FIXNUM(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L147:
	princ_str("VV[",symbol_value(VV[4]));
	(*LK0)(1,(V2))                            /*  WT1             */;
	princ_char(93,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
	}
	}
}
/*	function definition for WT-CHARACTER                          */
static L12(int narg, object V1, ...)
{ VT14 VLEX14 CLSR14
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if (i==narg) goto L155;
	V2= va_arg(args, object);
	i++;
	goto L156;
L155:
	V2= Cnil;
L156:
	Lformat(3,Cnil,VV[12],(V1))               /*  FORMAT          */;
	(*LK0)(1,VALUES(0))                       /*  WT1             */;
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WT-FIXNUM-LOC                         */
static L13(int narg, object V1)
{ VT15 VLEX15 CLSR15
TTL:
	if(!(type_of((V1))==t_cons)){
	goto L161;}
	{object V2= CAR((V1));
	if((V2!= VV[63]))goto L163;
	if(!(((CADR((V1)))->v.v_self[4])==(VV[11]))){
	goto L165;}
	RETURN(L7(1,(CADR((V1)))->v.v_self[5])    /*  WT-LCL          */);
L165:
	princ_str("fix(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L163:
	if((V2!= VV[54]))goto L170;
	RETURN((*LK4)(2,CADDR((V1)),CADDDR((V1))) /*  WT-INLINE-LOC   */);
L170:
	if((V2!= VV[24]))goto L171;
	(*LK0)(1,CADR((V1)))                      /*  WT1             */;
	VALUES(0) = Cnil;
	RETURN(1);
L171:
	if((V2!= VV[57])
	&& (V2!= VV[56]))goto L173;
	princ_str("((int)(",symbol_value(VV[4]));
	(*LK4)(2,CADDR((V1)),CADDDR((V1)))        /*  WT-INLINE-LOC   */;
	princ_str("))",symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L173:
	princ_str("fix(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);}
L161:
	princ_str("fix(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-CHARACTER-LOC                      */
static L14(int narg, object V1)
{ VT16 VLEX16 CLSR16
TTL:
	if(!(type_of((V1))==t_cons)){
	goto L185;}
	{object V2= CAR((V1));
	if((V2!= VV[63]))goto L187;
	if(!(((CADR((V1)))->v.v_self[4])==(VV[13]))){
	goto L189;}
	RETURN(L7(1,(CADR((V1)))->v.v_self[5])    /*  WT-LCL          */);
L189:
	princ_str("char_code(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L187:
	if((V2!= VV[55]))goto L194;
	RETURN((*LK4)(2,CADDR((V1)),CADDDR((V1))) /*  WT-INLINE-LOC   */);
L194:
	if((V2!= VV[26]))goto L195;
	(*LK0)(1,CADR((V1)))                      /*  WT1             */;
	VALUES(0) = Cnil;
	RETURN(1);
L195:
	princ_str("char_code(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);}
L185:
	princ_str("char_code(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-LONG-FLOAT-LOC                     */
static L15(int narg, object V1)
{ VT17 VLEX17 CLSR17
TTL:
	if(!(type_of((V1))==t_cons)){
	goto L204;}
	{object V2= CAR((V1));
	if((V2!= VV[63]))goto L206;
	if(!(((CADR((V1)))->v.v_self[4])==(VV[14]))){
	goto L208;}
	RETURN(L7(1,(CADR((V1)))->v.v_self[5])    /*  WT-LCL          */);
L208:
	princ_str("lf(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L206:
	if((V2!= VV[56]))goto L213;
	RETURN((*LK4)(2,CADDR((V1)),CADDDR((V1))) /*  WT-INLINE-LOC   */);
L213:
	if((V2!= VV[27]))goto L214;
	(*LK0)(1,CADR((V1)))                      /*  WT1             */;
	VALUES(0) = Cnil;
	RETURN(1);
L214:
	princ_str("lf(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);}
L204:
	princ_str("lf(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-SHORT-FLOAT-LOC                    */
static L16(int narg, object V1)
{ VT18 VLEX18 CLSR18
TTL:
	if(!(type_of((V1))==t_cons)){
	goto L223;}
	{object V2= CAR((V1));
	if((V2!= VV[63]))goto L225;
	if(!(((CADR((V1)))->v.v_self[4])==(VV[15]))){
	goto L227;}
	RETURN(L7(1,(CADR((V1)))->v.v_self[5])    /*  WT-LCL          */);
L227:
	princ_str("sf(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L225:
	if((V2!= VV[57]))goto L232;
	RETURN((*LK4)(2,CADDR((V1)),CADDDR((V1))) /*  WT-INLINE-LOC   */);
L232:
	if((V2!= VV[28]))goto L233;
	(*LK0)(1,CADR((V1)))                      /*  WT1             */;
	VALUES(0) = Cnil;
	RETURN(1);
L233:
	princ_str("sf(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);}
L223:
	princ_str("sf(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-VA_ARG                             */
static L17(int narg, object V1)
{ VT19 VLEX19 CLSR19
TTL:
	if(((V1))==Cnil){
	goto L242;}
	princ_str("args[i]",symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L242:
	princ_str("va_arg(args, object)",symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-VALUE                              */
static L18(int narg, object V1)
{ VT20 VLEX20 CLSR20
TTL:
	princ_str("VALUES(",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(41,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-VALUES                             */
static L19(int narg, object V1)
{ VT21 VLEX21 CLSR21
TTL:
	princ_str("VALUES(0)",symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for SET-VALUES                            */
static L20(int narg, object V1, object V2)
{ VT22 VLEX22 CLSR22
TTL:
	if(!(type_of((V1))==t_cons)){
	goto L251;}
	if((memq(CAR((V1)),VV[16]))!=Cnil){
	goto L250;}
	if(!((CAR((V1)))==(VV[3]))){
	goto L258;}
	V1= CADR((V1));
	if(((V1))==Cnil){
	goto L251;}
	goto L256;
L258:
	goto L251;
L256:
L250:
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	(*LK0)(1,(V2))                            /*  WT1             */;
	princ_char(61,symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
L251:
	if(!(type_of((V1))==t_cons)){
	goto L268;}
	if((memq(CAR((V1)),VV[17]))!=Cnil){
	goto L267;}
L268:
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("VALUES(0)=",symbol_value(VV[4]));
L267:
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[4]));
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	(*LK0)(1,(V2))                            /*  WT1             */;
	princ_str("=1;",symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-KEYVARS                            */
static L21(int narg, object V1)
{ VT23 VLEX23 CLSR23
TTL:
	princ_str("keyvars[",symbol_value(VV[4]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_char(93,symbol_value(VV[4]));
	VALUES(0) = Cnil;
	RETURN(1);
}
static LKF4(int narg, ...) {TRAMPOLINK(VV[64],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[62],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[61],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[58],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[50],&LK0);}
