
/* (c) Copyright G. Attardi, 1993. */
#define VT2
#define VLEX2
#define CLSR2
static L1(int);
#define VT3
#define VLEX3
#define CLSR3
static L2(int);
#define VT4
#define VLEX4
#define CLSR4
static L3(int);
#define VT5
#define VLEX5
#define CLSR5
static L4(int, object);
#define VT6
#define VLEX6
#define CLSR6
static L5(int);
#define VT7
#define VLEX7
#define CLSR7
static L6(int);
#define VT8
#define VLEX8
#define CLSR8
static L7(int, object);
#define VT9
#define VLEX9
#define CLSR9
static L8(int, object);
#define VT10
#define VLEX10
#define CLSR10
static L9(int, object);
#define VT11
#define VLEX11
#define CLSR11
static L10(int, object);
#define VT12
#define VLEX12
#define CLSR12
static L11(int, object);
#define VT13
#define VLEX13
#define CLSR13
static L12(int, object, object);
#define VT14
#define VLEX14
#define CLSR14
static L13(int, object, object, object);
#define VT15 object T0,T1;
#define VLEX15
#define CLSR15
static L14(int, object);
#define VT16
#define VLEX16
#define CLSR16
static L15(int, object);
#define VT17
#define VLEX17
#define CLSR17
static L16(int, object);
#define VT18
#define VLEX18
#define CLSR18
static L17(int, object);
#define VT19
#define VLEX19
#define CLSR19
static L18(int, object);
#define VT20
#define VLEX20
#define CLSR20
static L19(int, object);
int Lerror();
int siLAmake_special();
int Lmonotonically_nondecreasing();
int Ladjoin();
int Lfunctionp();
#define VT21 object T0;
#define VLEX21
#define CLSR21
static L20(int, object, object);
#define VT22
#define VLEX22
#define CLSR22
static L21(int, object, object);
#define VT23
#define VLEX23
#define CLSR23
static L22(int, object, object);
int Lmonotonically_nondecreasing();
int Ladjoin();
#define VT24
#define VLEX24
#define CLSR24
static L23(int, object, object);
#define VT25
#define VLEX25
#define CLSR25
static L24(int, object, object, object);
#define VT26
#define VLEX26
#define CLSR26
static L25(int, object);
int Lerror();
int siLspecialp();
int Lmonotonically_nondecreasing();
#define VT27 object T0;
#define VLEX27
#define CLSR27
static struct codeblock Cblock;
#define VM27 1
#define VM26 0
#define VM25 0
#define VM24 0
#define VM23 0
#define VM22 0
#define VM21 1
#define VM20 0
#define VM19 0
#define VM18 0
#define VM17 0
#define VM16 0
#define VM15 2
#define VM14 0
#define VM13 0
#define VM12 0
#define VM11 0
#define VM10 0
#define VM9 0
#define VM8 0
#define VM7 0
#define VM6 0
#define VM5 0
#define VM4 0
#define VM3 0
#define VM2 0
#define VM1 205
static object VV[205];
static LKF0(int, ...);
static (*LK0)(int, ...)=LKF0;
static LKF1(int, ...);
static (*LK1)(int, ...)=LKF1;
static LKF2(int, ...);
static (*LK2)(int, ...)=LKF2;
static LKF3(int, ...);
static (*LK3)(int, ...)=LKF3;
static LKF4(int, ...);
static (*LK4)(int, ...)=LKF4;
static LKF5(int, ...);
static (*LK5)(int, ...)=LKF5;
static LKF6(int, ...);
static (*LK6)(int, ...)=LKF6;
static LKF7(int, ...);
static (*LK7)(int, ...)=LKF7;
static LKF8(int, ...);
static (*LK8)(int, ...)=LKF8;
static LKF9(int, ...);
static (*LK9)(int, ...)=LKF9;
static LKF10(int, ...);
static (*LK10)(int, ...)=LKF10;
static LKF11(int, ...);
static (*LK11)(int, ...)=LKF11;
static LKF12(int, ...);
static (*LK12)(int, ...)=LKF12;
static LKF13(int, ...);
static (*LK13)(int, ...)=LKF13;
static LKF14(int, ...);
static (*LK14)(int, ...)=LKF14;
static LKF15(int, ...);
static (*LK15)(int, ...)=LKF15;
static LKF16(int, ...);
static (*LK16)(int, ...)=LKF16;
