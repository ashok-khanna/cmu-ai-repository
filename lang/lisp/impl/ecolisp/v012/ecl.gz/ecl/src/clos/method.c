
#include "method.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	VV[0]->s.s_stype=(short)stp_special;
	if(VV[0]->s.s_dbind == OBJNULL){
	(VV[0]->s.s_dbind)= MAKE_FIXNUM(32);}
	VV[1]->s.s_stype=(short)stp_special;
	if(VV[1]->s.s_dbind == OBJNULL){
	(VV[1]->s.s_dbind)= Cnil;}
	VV[2]->s.s_stype=(short)stp_special;
	if(VV[2]->s.s_dbind == OBJNULL){
	(VV[2]->s.s_dbind)= Cnil;}
	MM0(VV[101],L1);
	MF0(VV[102],L2);
	(void)putprop(VV[102],VV[Vdeb102],VV[103]);
	MF0(VV[104],L6);
	(void)putprop(VV[104],VV[Vdeb104],VV[103]);
	MF0(VV[105],L7);
	(void)putprop(VV[105],VV[Vdeb105],VV[103]);
	MF0(VV[106],L8);
	(void)putprop(VV[106],VV[Vdeb106],VV[103]);
	VV[50]=string_to_object(VV[50]);
	MF0(VV[107],L9);
	(void)putprop(VV[107],VV[Vdeb107],VV[103]);
	MF0(VV[108],L10);
	(void)putprop(VV[108],VV[Vdeb108],VV[103]);
	MF0(VV[109],L11);
	(void)putprop(VV[109],VV[Vdeb109],VV[103]);
	funcall(13,VV[110]->s.s_gfdef,VV[65],VV[66],VV[67],Cnil,VV[68],VV[69],VV[70],Cnil,Cnil,VV[71],MAKE_FIXNUM(7),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0(VV[111],L12);
	(void)putprop(VV[111],VV[Vdeb111],VV[103]);
	MF0(VV[112],L13);
	(void)putprop(VV[112],VV[Vdeb112],VV[103]);
	MF0(VV[113],L14);
	(void)putprop(VV[113],VV[Vdeb113],VV[103]);
	MF0(VV[114],L15);
	(void)putprop(VV[114],VV[Vdeb114],VV[103]);
	MF0(VV[115],L16);
	(void)putprop(VV[115],VV[Vdeb115],VV[103]);
	MF0(VV[116],L17);
	(void)putprop(VV[116],VV[Vdeb116],VV[103]);
	VV[76]->s.s_stype=(short)stp_special;
	if(VV[76]->s.s_dbind == OBJNULL){
	VALUES(0) = (VV[117]->s.s_gfdef);
	Lmake_hash_table(4,VV[74],VALUES(0),VV[75],MAKE_FIXNUM(32))/*  MAKE-HASH-TABLE*/;
	(VV[76]->s.s_dbind)= VALUES(0);}
	MF0(VV[118],L18);
	(void)putprop(VV[118],VV[Vdeb118],VV[103]);
	(void)putprop(VV[119],VV[80],siSpretty_print_format);
	
	MM0(VV[119],L19);
	(void)putprop(VV[120],VV[80],siSpretty_print_format);
	
	MM0(VV[120],L20);
	MF0(VV[121],L21);
	(void)putprop(VV[121],VV[Vdeb121],VV[103]);
	MF0(VV[122],L24);
	(void)putprop(VV[122],VV[Vdeb122],VV[103]);
	MF0(VV[123],L24);
	(void)putprop(VV[123],VV[Vdeb123],VV[103]);
	MF0(VV[124],L26);
	(void)putprop(VV[124],VV[Vdeb124],VV[103]);
	MF0(VV[125],L27);
	(void)putprop(VV[125],VV[Vdeb125],VV[103]);
	MF0(VV[126],L28);
	(void)putprop(VV[126],VV[Vdeb126],VV[103]);
	MF0(VV[127],L29);
	(void)putprop(VV[127],VV[Vdeb127],VV[103]);
	MF0(VV[90],L30);
	(void)putprop(VV[90],VV[Vdeb90],VV[103]);
	MF0(VV[128],L31);
	(void)putprop(VV[128],VV[Vdeb128],VV[103]);
	siLfset(2,VV[95],symbol_function(VV[97])) /*  FSET            */;
	putprop(VV[95],VV[99],VV[98]);
	MF0(VV[129],L32);
	(void)putprop(VV[129],VV[Vdeb129],VV[103]);
	Ladjoin(2,VV[9],(VV[100]->s.s_dbind))     /*  ADJOIN          */;
	(VV[100]->s.s_dbind)= VALUES(0);
	Ladjoin(2,VV[78],(VV[100]->s.s_dbind))    /*  ADJOIN          */;
	(VV[100]->s.s_dbind)= VALUES(0);
	MF0(VV[130],L33);
	(void)putprop(VV[130],VV[Vdeb130],VV[103]);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	macro definition for DEFMETHOD                                */
static L1(int narg, object V1, object V2)
{ VT3 VLEX3 CLSR3
	{object V3=CDR(V1),V4;
	V4= V3;
	{ int V5;
	object V6;                                /*  NAME            */
	object V7;                                /*  QUALIFIERS      */
	object V8;                                /*  LAMBDA-LIST     */
	object V9;                                /*  BODY            */
	V5=L8(1,(V4))                             /*  PARSE-DEFMETHOD */;
	if (V5==0) goto L15;
	V6= VALUES(0);
	V5--;
	if (V5==0) goto L16;
	V7= VALUES(1);
	V5--;
	if (V5==0) goto L17;
	V8= VALUES(2);
	V5--;
	if (V5==0) goto L18;
	V9= VALUES(3);
	V5--;
	goto L19;
L15:
	V6= Cnil;
L16:
	V7= Cnil;
L17:
	V8= Cnil;
L18:
	V9= Cnil;
L19:
	{ int V10;
	object V11;                               /*  FN-FORM         */
	object V12;                               /*  SPECIALIZERS    */
	object V13;                               /*  DOC             */
	object V14;                               /*  PLIST           */
	V10=L2(5,(V6),(V7),(V8),(V9),(V2))        /*  EXPAND-DEFMETHOD*/;
	if (V10==0) goto L21;
	V11= VALUES(0);
	V10--;
	if (V10==0) goto L22;
	V12= VALUES(1);
	V10--;
	if (V10==0) goto L23;
	V13= VALUES(2);
	V10--;
	if (V10==0) goto L24;
	V14= VALUES(3);
	V10--;
	goto L25;
L21:
	V11= Cnil;
L22:
	V12= Cnil;
L23:
	V13= Cnil;
L24:
	V14= Cnil;
L25:
	{ int V15;
	object V16;                               /*  PARAMETERS      */
	object V17;                               /*  SPECIALIZED-LAMBDA-LIST*/
	object V18;                               /*  SPECIALIZERS    */
	V15=L9(2,(V8),Cnil)                       /*  PARSE-SPECIALIZED-LAMBDA-LIST*/;
	if (V15==0) goto L27;
	V16= VALUES(0);
	V15--;
	if (V15==0) goto L28;
	V17= VALUES(1);
	V15--;
	if (V15==0) goto L29;
	V18= VALUES(2);
	V15--;
	goto L30;
L27:
	V16= Cnil;
L28:
	V17= Cnil;
L29:
	V18= Cnil;
L30:
	(*LK0)(1,(V2))                            /*  ENV-LEXICAL-VARIABLES*/;
	{object V19= list(2,VV[7],(V6));
	{object V20= list(2,VV[7],(V7));
	{object V21= list(2,VV[7],(V18));
	{object V22= list(2,VV[7],(V17));
	{object V23= list(2,VV[7],(V13));
	VALUES(0) = list(2,VV[3],list(3,VV[4],VV[5],list(8,VV[6],V19,V20,V21,V22,V23,list(2,VV[7],(V14)),(V11))));
	RETURN(1);}}}}}}}}}
}
/*	function definition for EXPAND-DEFMETHOD                      */
static L2(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT4 VLEX4 CLSR4
TTL:
	{ int V6;
	object V7;                                /*  DOCUMENTATION   */
	object V8;                                /*  DECLARATIONS    */
	object V9;                                /*  REAL-BODY       */
	V6=L11(1,(V4))                            /*  EXTRACT-DECLARATIONS*/;
	if (V6==0) goto L33;
	V7= VALUES(0);
	V6--;
	if (V6==0) goto L34;
	V8= VALUES(1);
	V6--;
	if (V6==0) goto L35;
	V9= VALUES(2);
	V6--;
	goto L36;
L33:
	V7= Cnil;
L34:
	V8= Cnil;
L35:
	V9= Cnil;
L36:
	{ int V10;
	object V11;                               /*  PARAMETERS      */
	register object V12;                      /*  LAMBDA-LIST     */
	object V13;                               /*  SPECIALIZERS    */
	V10=L9(2,(V3),Ct)                         /*  PARSE-SPECIALIZED-LAMBDA-LIST*/;
	if (V10==0) goto L38;
	V11= VALUES(0);
	V10--;
	if (V10==0) goto L39;
	V12= VALUES(1);
	V10--;
	if (V10==0) goto L40;
	V13= VALUES(2);
	V10--;
	goto L41;
L38:
	V11= Cnil;
L39:
	V12= Cnil;
L40:
	V13= Cnil;
L41:
	{object V14;                              /*  REQUIRED-PARAMETERS*/
	object V15;                               /*  CLASS-DECLARATIONS*/
	object V16;                               /*  METHOD-LAMBDA   */
	register object V17;                      /*  ORIGINAL-ARGS   */
	object V18;                               /*  APPLYP          */
	object V19;                               /*  AUX-BINDINGS    */
	object V20;                               /*  PLIST           */
	object V21;                               /*  WALKED-LAMBDA   */
	{object V22;
	object V23= (V11);
	object V24= (V13);
	if(V23==Cnil||V24==Cnil){
	V14= Cnil;
	goto L42;}
	T0=V22=CONS(Cnil,Cnil);
L43:
	{object V25;                              /*  R               */
	CAR(V22)= CAR(V23);
	}
	if((V23=CDR(V23))==Cnil||(V24=CDR(V24))==Cnil){
	V14= T0;
	goto L42;}
	V22=CDR(V22)=CONS(Cnil,Cnil);
	goto L43;}
L42:
	{object V22;
	object V23= (V11);
	object V24= (V13);
	if(V23==Cnil||V24==Cnil){
	VALUES(0) = Cnil;
	goto L46;}
	T0=V22=CONS(Cnil,Cnil);
L47:
	{object V25;                              /*  P               */
	object V26;                               /*  S               */
	V26= CAR(V24);
	if(type_of((V26))==t_symbol){
	goto L49;}
	CDR(V22)= Cnil;
	goto L48;
L49:
	if((V26)==Cnil){
	CDR(V22)= Cnil;
	goto L48;}
	if(((((V26))==(Ct)?Ct:Cnil))==Cnil){
	goto L51;}
	CDR(V22)= Cnil;
	goto L48;
L51:
	CDR(V22)= CONS(list(3,VV[9],(V26),CAR(V23)),Cnil);
	}
L48:
	while(CDR(V22)!=Cnil)V22=CDR(V22);
	if((V23=CDR(V23))==Cnil||(V24=CDR(V24))==Cnil){
	T0=CDR(T0);
	VALUES(0) = T0;
	goto L46;}
	goto L47;}
L46:
	V15= CONS(VV[8],VALUES(0));
	if(!(type_of((V1))==t_cons||(V1)==Cnil)){
	goto L56;}
	VALUES(0) = CADR((V1));
	goto L54;
L56:
	VALUES(0) = (V1);
L54:
	V16= listA(4,VV[10],(V12),(V15),append((V8),CONS(listA(3,VV[11],VALUES(0),(V9)),Cnil)));
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  CALL-NEXT-METHOD-P*/
	CLV1=&CAR(env0=CONS(Cnil,env0));          /*  NEXT-METHOD-P-P */
	CLV2=&CAR(env0=CONS(Cnil,env0));          /*  SAVE-ORIGINAL-ARGS*/
	V17= Cnil;
	V18= Cnil;
	V19= Cnil;
	{object V22;
	object V23= (V14);
	if(V23==Cnil){
	CLV3=&CAR(env0=CONS(Cnil,env0));          /*  SLOTS           */
	goto L61;}
	T0=V22=CONS(Cnil,Cnil);
L62:
	CAR(V22)= CONS(CAR(V23),Cnil);
	if((V23=CDR(V23))==Cnil){
	CLV3=&CAR(env0=CONS(T0,env0));            /*  SLOTS           */
	goto L61;}
	V22=CDR(V22)=CONS(Cnil,Cnil);
	goto L62;}
L61:
	V20= Cnil;
	V21= Cnil;
	{ object V22;
	V22= make_cclosure(LC5,env0,&Cblock);
	(*LK1)(3,(V16),(V5),(V22))                /*  WALK-FORM       */;
	V21= VALUES(0);
	{object V23;
	object V24;                               /*  P               */
	V23= (V12);
	V24= Cnil;
L72:
	if(!((V23)==Cnil)){
	goto L73;}
	goto L68;
L73:
	V24= CAR((V23));
	{register object x= (V24),V26= VV[12];
	while(V26!=Cnil)
	if(x==CAR(V26)){
	goto L81;
	}else V26=CDR(V26);
	goto L80;}
L81:
	if(!(((V24))==(VV[13]))){
	goto L83;}
	{register object x= VV[13],V26= (V12);
	while(V26!=Cnil)
	if(x==CAR(V26)){
	VALUES(0) = V26;
	goto L87;
	}else V26=CDR(V26);
	VALUES(0) = Cnil;}
L87:
	V19= CDR(VALUES(0));
	goto L68;
L83:
	V18= Ct;
	*CLV2= Ct;
	V17= CONS(VV[14],(V17));
	Lmake_symbol(1,VV[15])                    /*  MAKE-SYMBOL     */;
	V17= CONS(VALUES(0),(V17));
	goto L68;
L80:
	Lsymbol_name(1,(V24))                     /*  SYMBOL-NAME     */;
	Lmake_symbol(1,VALUES(0))                 /*  MAKE-SYMBOL     */;
	V17= CONS(VALUES(0),(V17));
	V23= CDR((V23));
	goto L72;
	}
L68:
	if((*CLV2)==Cnil){
	goto L106;}
	V17= nreverse((V17));
	goto L104;
L106:
	V17= Cnil;
L104:
	{ int V23;
	object V24;                               /*  IGNORE          */
	object V25;                               /*  WALKED-DECLARATIONS*/
	object V26;                               /*  WALKED-LAMBDA-BODY*/
	V23=L11(1,CDDR((V21)))                    /*  EXTRACT-DECLARATIONS*/;
	if (V23==0) goto L109;
	V24= VALUES(0);
	V23--;
	if (V23==0) goto L110;
	V25= VALUES(1);
	V23--;
	if (V23==0) goto L111;
	V26= VALUES(2);
	V23--;
	goto L112;
L109:
	V24= Cnil;
L110:
	V25= Cnil;
L111:
	V26= Cnil;
L112:
	VALUES(0) = (VV[133]->s.s_gfdef);
	(*LK2)(2,VALUES(0),*CLV3)                 /*  SOME            */;
	if(VALUES(0)==Cnil){
	goto L113;}
	L31(2,(V26),*CLV3)                        /*  ADD-INDEX-BINDING*/;
	V26= VALUES(0);
L113:
	if((*CLV1)!=Cnil){
	goto L119;}
	if((*CLV0)==Cnil){
	goto L118;}
L119:
	V20= listA(3,VV[16],Ct,(V20));
L118:
	if((*CLV0)!=Cnil){
	goto L125;}
	if((*CLV1)==Cnil){
	goto L126;}
L125:
	L6(10,(V25),(V26),listA(3,VV[10],(V12),append((V25),(V26))),(V17),(V12),*CLV2,(V18),(V19),*CLV0,*CLV1)/*  ADD-LEXICAL-FUNCTIONS-TO-METHOD-LAMBDA*/;
	goto L124;
L126:
	VALUES(0) = listA(3,VV[10],(V12),append((V25),(V26)));
L124:
	VALUES(3) = (V20);
	VALUES(2) = (V7);
	VALUES(1) = (V13);
	VALUES(0) = list(2,VV[17],VALUES(0));
	RETURN(4);}
	}
	}}}
}
/*	closure WALK-FUNCTION                                         */
static LC5(int narg, object env0, object V1, object V2, object V3)
{ VT5 VLEX5 CLSR5
	narg--;
	{object scan=env0;
	CLV3= &CAR(scan);                         /*  SLOTS           */ scan=CDR(scan);
	CLV2= &CAR(scan);                         /*  SAVE-ORIGINAL-ARGS*/ scan=CDR(scan);
	CLV1= &CAR(scan);                         /*  NEXT-METHOD-P-P */ scan=CDR(scan);
	CLV0= &CAR(scan);                         /*  CALL-NEXT-METHOD-P*/}
TTL:
	if(((V2))==(VV[18])){
	goto L131;}
	VALUES(0) = (V1);
	RETURN(1);
L131:
	if(type_of((V1))==t_cons||(V1)==Cnil){
	goto L134;}
	VALUES(0) = (V1);
	RETURN(1);
L134:
	if(!((CAR((V1)))==(VV[19]))){
	goto L137;}
	*CLV0= Ct;
	*CLV2= ((CDR((V1)))==Cnil?Ct:Cnil);
	VALUES(0) = (V1);
	RETURN(1);
L137:
	if(!((CAR((V1)))==(VV[20]))){
	goto L144;}
	*CLV1= Ct;
	VALUES(0) = (V1);
	RETURN(1);
L144:
	{object V4;
	if((CAR((V1)))==(VV[17])){
	goto L149;}
	V4= Cnil;
	goto L148;
L149:
	if(!((CADR((V1)))==(VV[19]))){
	goto L152;}
	*CLV0= Ct;
	*CLV2= Ct;
	V4= (V1);
	goto L148;
L152:
	if(!((CADR((V1)))==(VV[20]))){
	goto L159;}
	*CLV1= Ct;
	V4= (V1);
	goto L148;
L159:
	V4= Cnil;
L148:
	if(((V4))==Cnil){
	goto L164;}
	VALUES(0) = (V4);
	RETURN(1);
L164:
	if(!((CAR((V1)))==(VV[21]))){
	goto L167;}
	if(!(type_of(CADR((V1)))==t_symbol)){
	goto L167;}
	Lconstantp(1,CADDR((V1)))                 /*  CONSTANTP       */;
	if(VALUES(0)==Cnil){
	goto L167;}
	{ int V5;
	object V6;                                /*  IGNORE          */
	object V7;                                /*  CLASS           */
	V5=(*LK3)(2,CADR((V1)),(V3))              /*  CAN-OPTIMIZE-ACCESS*/;
	if (V5==0) goto L174;
	V6= VALUES(0);
	V5--;
	if (V5==0) goto L175;
	V7= VALUES(1);
	V5--;
	goto L176;
L174:
	V6= Cnil;
L175:
	V7= Cnil;
L176:
	if(((V7))==Cnil){
	goto L178;}
	RETURN((*LK4)(2,(V7),(V1))                /*  OPTIMIZE-SLOT-VALUE*/);
L178:
	VALUES(0) = (V1);
	RETURN(1);}
L167:
	if(!((CAR((V1)))==(VV[22]))){
	goto L181;}
	if((CDDDR((V1)))==Cnil){
	goto L184;}
	{object V5;                               /*  RESULT          */
	V5= Cnil;
	{register object V6;                      /*  SETF-LIST       */
	register object V7;                       /*  INSTANCE-ACCESS */
	object V8;                                /*  VALUE           */
	V6= CDR((V1));
	V7= CAR((V6));
	V8= CADR((V6));
L190:
	if(((V6))!=Cnil){
	goto L191;}
	VALUES(0) = CONS(VV[3],nreverse((V5)));
	RETURN(1);
L191:
	if(((V7))==Cnil){
	goto L198;}
	if(!(type_of((V7))==t_cons||(V7)==Cnil)){
	goto L198;}
	if(!((CAR((V7)))==(VV[21]))){
	goto L198;}
	if(!(type_of(CADR((V7)))==t_symbol)){
	goto L198;}
	Lconstantp(1,CADDR((V7)))                 /*  CONSTANTP       */;
	if(VALUES(0)==Cnil){
	goto L198;}
	{ int V10;
	object V11;                               /*  IGNORE          */
	object V12;                               /*  CLASS           */
	V10=L27(2,CADR((V7)),(V3))                /*  CAN-OPTIMIZE-ACCESS*/;
	if (V10==0) goto L209;
	V11= VALUES(0);
	V10--;
	if (V10==0) goto L210;
	V12= VALUES(1);
	V10--;
	goto L211;
L209:
	V11= Cnil;
L210:
	V12= Cnil;
L211:
	{object V13;                              /*  NEW-FORM        */
	V13= list(3,VV[22],(V7),(V8));
	if(((V12))==Cnil){
	goto L214;}
	(*LK5)(2,(V12),(V13))                     /*  OPTIMIZE-SET-SLOT-VALUE*/;
	goto L196;
L214:
	VALUES(0) = (V13);
	goto L196;
	}}
L198:
	VALUES(0) = list(3,VV[22],(V7),(V8));
L196:
	V5= CONS(VALUES(0),(V5));
	V6= CDDR((V6));
	V7= CAR((V6));
	V8= CADR((V6));
	goto L190;
	}
	}
L184:
	if((CDR((V1)))==Cnil){
	goto L224;}
	if((CADR((V1)))==Cnil){
	goto L224;}
	{object V10= CADR((V1));
	if(!(type_of(V10)==t_cons||V10==Cnil)){
	goto L224;}}
	if(!((CAADR((V1)))==(VV[21]))){
	goto L224;}
	if(!(type_of(CADADR((V1)))==t_symbol)){
	goto L224;}
	Lconstantp(1,CADDR(CADR((V1))))           /*  CONSTANTP       */;
	if(VALUES(0)==Cnil){
	goto L224;}
	{ int V10;
	object V11;                               /*  IGNORE          */
	object V12;                               /*  CLASS           */
	V10=L27(2,CADADR((V1)),(V3))              /*  CAN-OPTIMIZE-ACCESS*/;
	if (V10==0) goto L237;
	V11= VALUES(0);
	V10--;
	if (V10==0) goto L238;
	V12= VALUES(1);
	V10--;
	goto L239;
L237:
	V11= Cnil;
L238:
	V12= Cnil;
L239:
	if(((V12))==Cnil){
	goto L241;}
	RETURN((*LK5)(2,(V12),(V1))               /*  OPTIMIZE-SET-SLOT-VALUE*/);
L241:
	VALUES(0) = (V1);
	RETURN(1);}
L224:
	VALUES(0) = (V1);
	RETURN(1);
L181:
	if(!((CAR((V1)))==(VV[23]))){
	goto L244;}
	{ int V10;
	object V11;                               /*  PARAMETER       */
	object V12;                               /*  CLASS           */
	V10=L27(2,CADR((V1)),(V3))                /*  CAN-OPTIMIZE-ACCESS*/;
	if (V10==0) goto L247;
	V11= VALUES(0);
	V10--;
	if (V10==0) goto L248;
	V12= VALUES(1);
	V10--;
	goto L249;
L247:
	V11= Cnil;
L248:
	V12= Cnil;
L249:
	if(((V12))==Cnil){
	goto L251;}
	RETURN(L28(4,(V12),(V11),(V1),*CLV3)      /*  OPTIMIZE-STANDARD-INSTANCE-ACCESS*/);
L251:
	VALUES(0) = (V1);
	RETURN(1);}
L244:
	VALUES(0) = (V1);
	RETURN(1);
	}
}
/*	function definition for ADD-LEXICAL-FUNCTIONS-TO-METHOD-LAMBDA*/
static L6(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9, object V10)
{ VT6 VLEX6 CLSR6
TTL:
	if(((V6))!=Cnil){
	goto L254;}
	if(((V7))!=Cnil){
	goto L254;}
	if((V9)==Cnil){
	T0= Cnil;
	goto L258;}
	T0= VV[27];
L258:
	if((V10)==Cnil){
	VALUES(0) = Cnil;
	goto L259;}
	VALUES(0) = VV[28];
L259:
	VALUES(0) = listA(3,VV[10],(V5),append((V1),CONS(list(3,VV[24],VV[25],listA(3,VV[26],append(T0,VALUES(0)),(V2))),Cnil)));
	RETURN(1);
L254:
	if(((V7))!=Cnil){
	goto L261;}
	if((V9)==Cnil){
	T1= Cnil;
	goto L263;}
	T1= CONS(list(3,VV[19],VV[30],list(4,VV[31],VV[32],list(4,VV[31],VV[33],VV[34],listA(3,VV[35],VV[32],(V4))),VV[36])),Cnil);
L263:
	if((V10)==Cnil){
	VALUES(0) = Cnil;
	goto L264;}
	VALUES(0) = VV[37];
L264:
	{object V11= append(T1,VALUES(0));
	(*LK6)(2,VV[13],(V5))                     /*  POSITION        */;
	Lsubseq(3,(V5),MAKE_FIXNUM(0),VALUES(0))  /*  SUBSEQ          */;
	{object V12;
	object V13= VALUES(0);
	object V14= (V4);
	if(V13==Cnil||V14==Cnil){
	VALUES(0) = Cnil;
	goto L265;}
	T2=V12=CONS(Cnil,Cnil);
L266:
	CAR(V12)= list(2,CAR(V13),CAR(V14));
	if((V13=CDR(V13))==Cnil||(V14=CDR(V14))==Cnil){
	VALUES(0) = T2;
	goto L265;}
	V12=CDR(V12)=CONS(Cnil,Cnil);
	goto L266;}
L265:
	{object V12= append(VALUES(0),(V8));
	VALUES(0) = list(3,VV[10],(V4),list(3,VV[24],VV[29],list(3,VV[26],V11,listA(3,VV[38],V12,append((V1),(V2))))));
	RETURN(1);}}
L261:
	if((V9)==Cnil){
	T2= Cnil;
	goto L270;}
	(*LK7)(2,VV[14],(V4))                     /*  REMOVE          */;
	T2= CONS(list(3,VV[19],VV[40],list(4,VV[31],VV[32],list(4,VV[31],VV[33],VV[41],listA(3,VV[42],VV[32],VALUES(0))),VV[43])),Cnil);
L270:
	if((V10)==Cnil){
	VALUES(0) = Cnil;
	goto L272;}
	VALUES(0) = VV[44];
L272:
	{object V13= append(T2,VALUES(0));
	{object V14= list(2,VV[17],(V3));
	(*LK7)(2,VV[14],(V4))                     /*  REMOVE          */;
	VALUES(0) = list(3,VV[10],(V4),list(3,VV[24],VV[39],list(3,VV[26],V13,listA(3,VV[42],V14,VALUES(0)))));
	RETURN(1);}}
}
/*	function definition for LEGAL-GENERIC-FUNCTION-NAME-P         */
static L7(int narg, object V1)
{ VT7 VLEX7 CLSR7
TTL:
	if(!(type_of((V1))==t_symbol)){
	goto L274;}
	VALUES(0) = Ct;
	RETURN(1);
L274:
	RETURN(siLsetf_namep(1,(V1))              /*  SETF-NAMEP      */);
}
/*	function definition for PARSE-DEFMETHOD                       */
static L8(int narg, object V1)
{ VT8 VLEX8 CLSR8
TTL:
	{register object V2;                      /*  NAME            */
	register object V3;                       /*  QUALIFIERS      */
	V2= Cnil;
	V3= Cnil;
	if(((V1))!=Cnil){
	goto L276;}
	Lerror(1,VV[45])                          /*  ERROR           */;
L276:
	{object V4;
	V4= CAR((V1));
	V1= CDR((V1));
	V2= (V4);
	}
	L7(1,(V2))                                /*  LEGAL-GENERIC-FUNCTION-NAME-P*/;
	if(VALUES(0)!=Cnil){
	goto L284;}
	Lerror(2,VV[46],(V2))                     /*  ERROR           */;
L284:
	if(((V1))!=Cnil){
	goto L287;}
	Lerror(1,VV[47])                          /*  ERROR           */;
L287:
L292:
	if((CAR((V1)))!=Cnil){
	goto L295;}
	Lerror(1,VV[48])                          /*  ERROR           */;
	goto L293;
L295:
	if(!(type_of(CAR((V1)))==t_cons)){
	goto L298;}
	V3= nreverse((V3));
	goto L290;
L298:
	{object V5;
	V5= CAR((V1));
	V1= CDR((V1));
	VALUES(0) = (V5);
	}
	V3= CONS(VALUES(0),(V3));
L293:
	goto L292;
L290:
	VALUES(3) = CDR((V1));
	VALUES(2) = CAR((V1));
	VALUES(1) = (V3);
	VALUES(0) = (V2);
	RETURN(4);
	}
}
/*	function definition for PARSE-SPECIALIZED-LAMBDA-LIST         */
static L9(int narg, object V1, object V2)
{ VT9 VLEX9 CLSR9
TTL:
	{register object V3;                      /*  PARAMETERS      */
	register object V4;                       /*  LAMBDA-LIST     */
	object V5;                                /*  SPECIALIZERS    */
	V3= Cnil;
	V4= Cnil;
	V5= Cnil;
	{register object V6;                      /*  ARG             */
	V6= CAR((V1));
L310:
	if(((V1))==Cnil){
	goto L312;}
	{register object x= (V6),V7= VV[49];
	while(V7!=Cnil)
	if(eql(x, CAR(V7))){
	goto L315;
	}else V7=CDR(V7);
	goto L311;}
L315:
L312:
	goto L307;
L311:
	V1= CDR((V1));
	if(((V2))==Cnil){
	goto L319;}
	{register object x= (V6),V8= VV[50];
	while(V8!=Cnil)
	if(eql(x, CAR(V8))){
	goto L323;
	}else V8=CDR(V8);
	goto L319;}
L323:
	(*LK8)(2,VV[51],(V6))                     /*  WARN            */;
L319:
	if(!(type_of((V6))==t_cons||(V6)==Cnil)){
	goto L328;}
	VALUES(0) = CAR((V6));
	goto L326;
L328:
	VALUES(0) = (V6);
L326:
	V3= CONS(VALUES(0),(V3));
	if(!(type_of((V6))==t_cons||(V6)==Cnil)){
	goto L334;}
	VALUES(0) = CAR((V6));
	goto L332;
L334:
	VALUES(0) = (V6);
L332:
	V4= CONS(VALUES(0),(V4));
	if(!(type_of((V6))==t_cons||(V6)==Cnil)){
	goto L340;}
	if(!(type_of(CADR((V6)))==t_cons)){
	goto L343;}
	Leval(1,CADADR((V6)))                     /*  EVAL            */;
	VALUES(0) = list(2,VV[52],VALUES(0));
	goto L338;
L343:
	VALUES(0) = CADR((V6));
	goto L338;
L340:
	VALUES(0) = Cnil;
L338:
	V5= CONS(VALUES(0),(V5));
	V6= CAR((V1));
	goto L310;
	}
L307:
	if(!((CAR((V1)))==(VV[53]))){
	goto L349;}
	{object V6;
	V6= CAR((V1));
	V1= CDR((V1));
	VALUES(0) = (V6);
	}
	V4= CONS(VALUES(0),(V4));
	{object V6;                               /*  ARG             */
	V6= CAR((V1));
L360:
	if(((V1))==Cnil){
	goto L362;}
	{register object x= (V6),V7= VV[54];
	while(V7!=Cnil)
	if(eql(x, CAR(V7))){
	goto L365;
	}else V7=CDR(V7);
	goto L361;}
L365:
L362:
	goto L349;
L361:
	V1= CDR((V1));
	if(((V2))==Cnil){
	goto L369;}
	{register object x= (V6),V8= VV[50];
	while(V8!=Cnil)
	if(eql(x, CAR(V8))){
	goto L373;
	}else V8=CDR(V8);
	goto L369;}
L373:
	(*LK8)(2,VV[55],(V6))                     /*  WARN            */;
L369:
	if(!(type_of((V6))==t_cons||(V6)==Cnil)){
	goto L378;}
	VALUES(0) = CAR((V6));
	goto L376;
L378:
	VALUES(0) = (V6);
L376:
	V3= CONS(VALUES(0),(V3));
	V4= CONS((V6),(V4));
	V6= CAR((V1));
	goto L360;
	}
L349:
	if(!((CAR((V1)))==(VV[14]))){
	goto L385;}
	{object V6;
	V6= CAR((V1));
	V1= CDR((V1));
	VALUES(0) = (V6);
	}
	V4= CONS(VALUES(0),(V4));
	if(type_of(CAR((V1)))==t_symbol){
	goto L394;}
	Lerror(2,VV[56],CAR((V1)))                /*  ERROR           */;
L394:
	{object V6;
	V6= CAR((V1));
	V1= CDR((V1));
	VALUES(0) = (V6);
	}
	V4= CONS(VALUES(0),(V4));
L385:
	if(!((CAR((V1)))==(VV[57]))){
	goto L402;}
	{object V6;
	V6= CAR((V1));
	V1= CDR((V1));
	VALUES(0) = (V6);
	}
	V4= CONS(VALUES(0),(V4));
	{register object V6;                      /*  ARG             */
	V6= CAR((V1));
L413:
	if(((V1))==Cnil){
	goto L415;}
	{register object x= (V6),V7= VV[58];
	while(V7!=Cnil)
	if(eql(x, CAR(V7))){
	goto L418;
	}else V7=CDR(V7);
	goto L414;}
L418:
L415:
	goto L402;
L414:
	V1= CDR((V1));
	if(!(((V6))==(VV[59]))){
	goto L422;}
	V4= CONS((V6),(V4));
	goto L402;
L422:
	if(((V2))==Cnil){
	goto L427;}
	{register object x= (V6),V9= VV[50];
	while(V9!=Cnil)
	if(eql(x, CAR(V9))){
	goto L431;
	}else V9=CDR(V9);
	goto L427;}
L431:
	(*LK8)(2,VV[60],(V6))                     /*  WARN            */;
L427:
	if(!(type_of((V6))==t_cons||(V6)==Cnil)){
	goto L436;}
	VALUES(0) = CAR((V6));
	goto L434;
L436:
	VALUES(0) = (V6);
L434:
	V3= CONS(VALUES(0),(V3));
	V4= CONS((V6),(V4));
	V6= CAR((V1));
	goto L413;
	}
L402:
	if(!((CAR((V1)))==(VV[13]))){
	goto L443;}
	{object V6;
	V6= CAR((V1));
	V1= CDR((V1));
	VALUES(0) = (V6);
	}
	V4= CONS(VALUES(0),(V4));
	{object V6;                               /*  ARG             */
	V6= CAR((V1));
L454:
	if(((V1))==Cnil){
	goto L456;}
	{register object x= (V6),V7= VV[61];
	while(V7!=Cnil)
	if(eql(x, CAR(V7))){
	goto L459;
	}else V7=CDR(V7);
	goto L455;}
L459:
L456:
	goto L443;
L455:
	V1= CDR((V1));
	if(((V2))==Cnil){
	goto L463;}
	{register object x= (V6),V8= VV[50];
	while(V8!=Cnil)
	if(eql(x, CAR(V8))){
	goto L467;
	}else V8=CDR(V8);
	goto L463;}
L467:
	(*LK8)(2,VV[62],(V6))                     /*  WARN            */;
L463:
	if(!(type_of((V6))==t_cons||(V6)==Cnil)){
	goto L472;}
	VALUES(0) = CAR((V6));
	goto L470;
L472:
	VALUES(0) = (V6);
L470:
	V3= CONS(VALUES(0),(V3));
	V4= CONS((V6),(V4));
	V6= CAR((V1));
	goto L454;
	}
L443:
	if(((V1))==Cnil){
	goto L479;}
	Lerror(2,VV[63],CAR((V1)))                /*  ERROR           */;
L479:
	{object V6= nreverse((V3));
	{object V7= nreverse((V4));
	VALUES(2) = nreverse((V5));
	VALUES(1) = V7;
	VALUES(0) = V6;
	RETURN(3);}}
	}
}
/*	function definition for DECLARATION-SPECIALIZERS              */
static L10(int narg, object V1, object V2)
{ VT10 VLEX10 CLSR10
TTL:
	{register object V3;                      /*  ARGSCAN         */
	object V4;                                /*  DECLIST         */
	if(((V2))==Cnil){
	goto L484;}
	V4= CDR((V2));
	goto L482;
L484:
	V4= Cnil;
L482:
	V3= (V1);
L487:
	if(((V3))==Cnil){
	goto L489;}
	{register object x= CAR((V3)),V5= VV[64];
	while(V5!=Cnil)
	if(eql(x, CAR(V5))){
	goto L492;
	}else V5=CDR(V5);
	goto L488;}
L492:
L489:
	VALUES(0) = CONS(VV[8],(V4));
	RETURN(1);
L488:
	{object V6= CAR((V3));
	if(!(type_of(V6)==t_cons||V6==Cnil)){
	goto L493;}}
	V4= CONS(list(3,VV[9],CADAR((V3)),CAAR((V3))),(V4));
L493:
	V3= CDR((V3));
	goto L487;
	}
}
/*	function definition for EXTRACT-DECLARATIONS                  */
static L11(int narg, object V1, ...)
{ VT11 VLEX11 CLSR11
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if (i==narg) goto L500;
	V2= va_arg(args, object);
	i++;
	goto L501;
L500:
	V2= Cnil;
L501:
	{object V3;                               /*  DOCUMENTATION   */
	register object V4;                       /*  DECLARATIONS    */
	object V5;                                /*  FORM            */
	V3= Cnil;
	V4= Cnil;
	V5= Cnil;
L505:
	if(((V3))!=Cnil){
	goto L507;}
	if(!(type_of(CAR((V1)))==t_string)){
	goto L507;}
	{object V6;
	V6= CAR((V1));
	V1= CDR((V1));
	V3= (V6);
	}
L507:
	if(((V1))!=Cnil){
	goto L516;}
	goto L503;
L516:
	Lmacroexpand(1,CAR((V1)))                 /*  MACROEXPAND     */;
	V5= VALUES(0);
	if(!(type_of((V5))==t_cons||(V5)==Cnil)){
	goto L522;}
	if(!((CAR((V5)))==(VV[8]))){
	goto L522;}
	{register object V6;
	object V7;                                /*  DECLARATION     */
	{object V8;
	V8= CAR((V1));
	V1= CDR((V1));
	VALUES(0) = (V8);
	}
	V6= CDR(VALUES(0));
	V7= Cnil;
L533:
	if(!((V6)==Cnil)){
	goto L534;}
	goto L506;
L534:
	V7= CAR((V6));
	V4= CONS((V7),(V4));
	V6= CDR((V6));
	goto L533;
	}
L522:
	goto L503;
L506:
	goto L505;
L503:
	if(((V4))==Cnil){
	goto L547;}
	VALUES(0) = CONS(CONS(VV[8],(V4)),Cnil);
	goto L545;
L547:
	VALUES(0) = Cnil;
L545:
	VALUES(2) = (V1);
	VALUES(1) = VALUES(0);
	VALUES(0) = (V3);
	RETURN(3);
	}
	}
}
/*	function definition for MAKE-METHOD                           */
static L12(int narg, object V1, object V2, object V3, object V4, object V5, object V6, ...)
{ VT12 VLEX12 CLSR12
	VALUES(0) = list(7,VV[72],(V1),(V2),(V3),(V4),(V5),(V6));
	RETURN(1);
}
/*	function definition for METHOD-P                              */
static L13(int narg, object V1)
{ VT13 VLEX13 CLSR13
TTL:
	if(type_of((V1))==t_cons||(V1)==Cnil){
	goto L549;}
	VALUES(0) = Cnil;
	RETURN(1);
L549:
	VALUES(0) = ((VV[72])==(CAR((V1)))?Ct:Cnil);
	RETURN(1);
}
/*	function definition for METHOD-NEEDS-NEXT-METHODS-P           */
static L14(int narg, object V1)
{ VT14 VLEX14 CLSR14
TTL:
	RETURN(Lgetf(2,CADR(CDDDDR((V1))),VV[16]) /*  GETF            */);
}
/*	function definition for GENERIC-FUNCTION-DISPATCHER           */
static L15(int narg, object V1)
{ VT15 VLEX15 CLSR15
TTL:
	VALUES(0) = ((V1))->in.in_slots[6];
	RETURN(1);
}
/*	function definition for ADD-METHOD                            */
static L16(int narg, object V1, object V2)
{ VT16 VLEX16 CLSR16
TTL:
	{object V3;                               /*  NAME            */
	register object V4;                       /*  METHOD-ENTRY    */
	L15(1,(V1))                               /*  GENERIC-FUNCTION-DISPATCHER*/;
	siLgfun_name(1,VALUES(0))                 /*  GFUN-NAME       */;
	V3= VALUES(0);
	{register object x= (V3),V5= (VV[1]->s.s_dbind);
	while(V5!=Cnil)
	if(CAR(V5) != Cnil && 
	eql(x,CAAR(V5))){
	V4= CAR(V5);
	goto L553;
	}else V5=CDR(V5);
	V4= Cnil;}
L553:
	if(((V4))!=Cnil){
	goto L554;}
	V4= CONS((V3),Cnil);
	(VV[1]->s.s_dbind)= CONS((V4),(VV[1]->s.s_dbind));
L554:
	{object V5;
	V5= CONS((V2),CDR((V4)));
	CDR((V4)) = (V5);
	}
	VALUES(0) = (V2);
	RETURN(1);
	}
}
/*	function definition for FIND-METHOD                           */
static L17(int narg, object V1, object V2, object V3, ...)
{ VT17 VLEX17 CLSR17
	{int i=3;
	object V4;
	va_list args; va_start(args, V3);
	if (i==narg) goto L563;
	V4= va_arg(args, object);
	i++;
	goto L564;
L563:
	V4= Ct;
L564:
	{object V5;                               /*  METHOD-LIST     */
	object V6;
	object V7;                                /*  REQUIRED-ARGS   */
	object V8;                                /*  FOUND           */
	(*LK9)(1,(V1))                            /*  METHODS         */;
	V6= VALUES(0);
	(*LK10)(1,(V1))                           /*  LAMBDA-LIST     */;
	T0= VALUES(0);
	Lsubseq(3,T0,MAKE_FIXNUM(0),MAKE_FIXNUM(length((V3))))/*  SUBSEQ*/;
	V7= VALUES(0);
	V5= V6;
	V8= Cnil;
	{register object V9;
	register object V10;                      /*  METHOD          */
	V9= (V5);
	V10= Cnil;
L573:
	if(!((V9)==Cnil)){
	goto L574;}
	goto L569;
L574:
	V10= CAR((V9));
	(*LK11)(1,(V10))                          /*  METHOD-QUALIFIERS*/;
	if(!(equal((V2),VALUES(0)))){
	goto L579;}
	(*LK12)(1,(V10))                          /*  SPECIALIZERS    */;
	if(!(equal((V3),VALUES(0)))){
	goto L579;}
	V8= (V10);
	goto L569;
L579:
	V9= CDR((V9));
	goto L573;
	}
L569:
	if(((V8))!=Cnil){
	goto L592;}
	if(((V4))==Cnil){
	goto L592;}
	L15(1,(V1))                               /*  GENERIC-FUNCTION-DISPATCHER*/;
	siLgfun_name(1,VALUES(0))                 /*  GFUN-NAME       */;
	RETURN(Lerror(4,VV[73],VALUES(0),(V2),(V3))/*  ERROR          */);
L592:
	VALUES(0) = (V8);
	RETURN(1);
	}
	}
}
/*	function definition for UPDATE-METHOD-KEY-HASH-TABLE          */
static L18(int narg, object V1, object V2)
{ VT18 VLEX18 CLSR18
TTL:
	{object V3;                               /*  POST-KEY-LIST   */
	register object V4;                       /*  KEYWORDS-LIST   */
	V3= Cnil;
	V4= Cnil;
	{register object V5;                      /*  SCAN            */
	V5= (V2);
L601:
	if(((V5))!=Cnil){
	goto L602;}
	V3= Cnil;
	goto L599;
L602:
	if(!((CAR((V5)))==(VV[57]))){
	goto L605;}
	V3= CDR((V5));
	goto L599;
L605:
	V5= CDR((V5));
	goto L601;
	}
L599:
	if(((V3))==Cnil){
	goto L612;}
	{register object V5;                      /*  KEY-SCAN        */
	register object V6;                       /*  FIRST-KEY-SCAN  */
	V5= (V3);
	V6= CAR((V5));
L618:
	if(((V5))==Cnil){
	goto L620;}
	{register object x= (V6),V7= VV[77];
	while(V7!=Cnil)
	if(eql(x, CAR(V7))){
	goto L623;
	}else V7=CDR(V7);
	goto L619;}
L623:
L620:
	V4= nreverse((V4));
	goto L614;
L619:
	if(!(type_of((V6))==t_cons||(V6)==Cnil)){
	goto L629;}
	{object V8;                               /*  KEY-PAR         */
	V8= CAR((V6));
	if(!(type_of((V8))==t_cons||(V8)==Cnil)){
	goto L633;}
	VALUES(0) = CAR((V8));
	goto L627;
L633:
	(*LK13)(1,(V8))                           /*  MAKE-KEYWORD    */;
	goto L627;
	}
L629:
	(*LK13)(1,(V6))                           /*  MAKE-KEYWORD    */;
L627:
	V4= CONS(VALUES(0),(V4));
	V5= CDR((V5));
	V6= CAR((V5));
	goto L618;
	}
L614:
	RETURN(siLhash_set(3,(V1),(VV[76]->s.s_dbind),(V4))/*  HASH-SET*/);
L612:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	macro definition for WITH-SLOTS                               */
static L19(int narg, object V1, object V2)
{ VT19 VLEX19 CLSR19
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= V3;
	{register object V7;                      /*  TEMP            */
	object V8;                                /*  ACCESSORS       */
	Lgensym(0)                                /*  GENSYM          */;
	V7= VALUES(0);
	{register object V9;                      /*  SCAN            */
	register object V10;                      /*  RES             */
	V9= (V4);
	V10= Cnil;
L643:
	if(((V9))!=Cnil){
	goto L644;}
	V8= nreverse((V10));
	goto L641;
L644:
	if(!(type_of(CAR((V9)))==t_symbol)){
	goto L649;}
	{object V12= CAR((V9));
	V10= CONS(list(2,V12,list(3,VV[21],(V7),list(2,VV[7],CAR((V9))))),(V10));}
	goto L647;
L649:
	{object V12= CAAR((V9));
	V10= CONS(list(2,V12,list(3,VV[21],(V7),list(2,VV[7],CADAR((V9))))),(V10));}
L647:
	V9= CDR((V9));
	goto L643;
	}
L641:
	{object V9= CONS(list(2,(V7),(V5)),Cnil);
	if(type_of((V5))==t_symbol){
	goto L657;}
	T0= Cnil;
	goto L656;
L657:
	T0= CONS(list(2,VV[8],list(3,VV[78],(V7),(V5))),Cnil);
L656:
	VALUES(0) = listA(3,VV[24],V9,append(T0,CONS(listA(3,VV[79],(V8),(V6)),Cnil)));
	RETURN(1);}
	}}
}
/*	macro definition for WITH-ACCESSORS                           */
static L20(int narg, object V1, object V2)
{ VT20 VLEX20 CLSR20
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= V3;
	{object V7;                               /*  TEMP            */
	object V8;                                /*  ACCESSORS       */
	Lgensym(0)                                /*  GENSYM          */;
	V7= VALUES(0);
	{register object V9;                      /*  SCAN            */
	object V10;                               /*  RES             */
	V9= (V4);
	V10= Cnil;
L662:
	if(((V9))!=Cnil){
	goto L663;}
	V8= nreverse((V10));
	goto L660;
L663:
	{object V12= CAAR((V9));
	V10= CONS(list(2,V12,list(2,CADAR((V9)),(V7))),(V10));}
	V9= CDR((V9));
	goto L662;
	}
L660:
	{object V9= CONS(list(2,(V7),(V5)),Cnil);
	if(type_of((V5))==t_symbol){
	goto L672;}
	T0= Cnil;
	goto L671;
L672:
	T0= CONS(list(2,VV[8],list(3,VV[78],(V7),(V5))),Cnil);
L671:
	VALUES(0) = listA(3,VV[24],V9,append(T0,CONS(listA(3,VV[79],(V8),(V6)),Cnil)));
	RETURN(1);}
	}}
}
/*	function definition for COMPUTE-APPLICABLE-METHODS            */
static L21(int narg, object V1, object V2)
{ VT21 VLEX21 CLSR21
TTL:
	{object V3;                               /*  GFUN            */
	object V4;                                /*  NAME            */
	L15(1,(V1))                               /*  GENERIC-FUNCTION-DISPATCHER*/;
	V3= VALUES(0);
	siLgfun_name(1,(V3))                      /*  GFUN-NAME       */;
	V4= VALUES(0);
	if(type_of((V4))==t_cons||(V4)==Cnil){
	goto L677;}
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  SETFP           */
	goto L676;
L677:
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(((VV[22])==(CAR((V4)))?Ct:Cnil),env0));/*  SETFP*/
L676:
	{register object x= (V4),V5= (VV[1]->s.s_dbind);
	while(V5!=Cnil)
	if(CAR(V5) != Cnil && 
	eql(x,CAAR(V5))){
	VALUES(0) = CAR(V5);
	goto L680;
	}else V5=CDR(V5);
	VALUES(0) = Cnil;}
L680:
	lex0[0]=CDR(VALUES(0));                   /*  EARLY-METHODS   */
	lex0[1]=Cnil;                             /*  METHODS         */
	if((*CLV0)==Cnil){
	goto L684;}
	VALUES(0) = CADR((V2));
	goto L682;
L684:
	VALUES(0) = CAR((V2));
L682:
	(*LK14)(1,TYPE_OF(VALUES(0)))             /*  FIND-CLASS      */;
	LC23(lex0,1, env0,VALUES(0))              /*  SEARCH-EARLY-METHODS*/;
	VALUES(0) = nreverse(lex0[1]);
	RETURN(1);
	}
}
/*	closure SEARCH-EARLY-METHODS                                  */
static LC23(object *lex0,int narg, object env0, object V1)
{ VT22 VLEX22 CLSR22
	narg--;
	{object scan=env0;
	CLV0= &CAR(scan);                         /*  SETFP           */}
TTL:
	{object V2;                               /*  CLASS-NAME      */
	object V3;                                /*  METHOD          */
	V2= ((V1))->in.in_slots[0];
	if((*CLV0)==Cnil){
	goto L691;}
	T0= list(2,Ct,(V2));
	goto L689;
L691:
	T0= CONS((V2),Cnil);
L689:
	T1= (VV[161]->s.s_gfdef);
	VALUES(0) = make_cclosure(LC22,env0,&Cblock);
	(*LK15)(6,T0,lex0[0],VV[81],T1,VV[74],VALUES(0))/*  FIND      */;
	V3= VALUES(0);
	if(((V3))==Cnil){
	goto L695;}
	lex0[1]= CONS((V3),lex0[1]);
L695:
	{register object V4;
	object V5;                                /*  C               */
	V4= ((V1))->in.in_slots[1];
	V5= Cnil;
L702:
	if(!((V4)==Cnil)){
	goto L703;}
	VALUES(0) = Cnil;
	RETURN(1);
L703:
	V5= CAR((V4));
	LC23(lex0,1, env0,(V5))                   /*  SEARCH-EARLY-METHODS*/;
	V4= CDR((V4));
	goto L702;
	}
	}
}
/*	closure CLOSURE                                               */
static LC22(int narg, object env0, object V1, object V2)
{ VT23 VLEX23 CLSR23
	narg--;
	{object scan=env0;
	CLV0= &CAR(scan);                         /*  SETFP           */}
	if((*CLV0)==Cnil){
	goto L713;}
	VALUES(0) = ((CADR((V1)))==(CADR((V2)))?Ct:Cnil);
	RETURN(1);
L713:
	VALUES(0) = ((CAR((V1)))==(CAR((V2)))?Ct:Cnil);
	RETURN(1);
}
/*	function definition for GENERIC-FUNCTION-METHOD-COMBINATION   */
static L24(int narg, object V1)
{ VT24 VLEX24 CLSR24
TTL:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for COMPUTE-EFFECTIVE-METHOD              */
static L26(int narg, object V1, object V2, object V3, object V4)
{ VT25 VLEX25 CLSR25
TTL:
	if(((V2))==Cnil){
	goto L716;}
	RETURN((*LK16)(1,list(3,VV[82],CAR((V2)),CDR((V2))))/*  MAKE-EFFECTIVE-METHOD-FUNCTION*/);
L716:
	RETURN((*LK17)(1,(V1))                    /*  NO-APPLICABLE-METHOD*/);
}
/*	function definition for CAN-OPTIMIZE-ACCESS                   */
static L27(int narg, object V1, object V2)
{ VT26 VLEX26 CLSR26
TTL:
	{object V3;                               /*  REQUIRED-PARAMETER?*/
	(*LK18)(3,VV[78],(V1),(V2))               /*  VARIABLE-DECLARATION*/;
	VALUES(0) = CADDR(VALUES(0));
	if(VALUES(0)==Cnil)goto L719;
	V3= VALUES(0);
	goto L718;
L719:
	V3= (V1);
L718:
	if(((V3))==Cnil){
	goto L723;}
	L33(2,(V3),(V2))                          /*  VARIABLE-CLASS  */;
	(*LK14)(2,VALUES(0),Cnil)                 /*  FIND-CLASS      */;
	VALUES(1) = VALUES(0);
	VALUES(0) = (V3);
	RETURN(2);
L723:
	VALUES(1) = Cnil;
	VALUES(0) = Cnil;
	RETURN(2);
	}
}
/*	function definition for OPTIMIZE-STANDARD-INSTANCE-ACCESS     */
static L28(int narg, object V1, object V2, object V3, object V4)
{ VT27 VLEX27 CLSR27
TTL:
	{register object V5;                      /*  INSTANCE        */
	object V6;
	register object V7;                       /*  SLOT-NAME       */
	object V8;
	object V9;                                /*  NEW             */
	object V10;
	register object V11;                      /*  ENTRY           */
	V6= CADR((V3));
	L32(1,CADDR((V3)))                        /*  REDUCE-CONSTANT */;
	V8= VALUES(0);
	V10= CDDDR((V3));
	{register object x= (V2),V12= (V4);
	while(V12!=Cnil)
	if(CAR(V12) != Cnil && 
	x==(CAAR(V12))){
	V11= CAR(V12);
	goto L730;
	}else V12=CDR(V12);
	V11= Cnil;}
L730:
	V5= V6;
	V7= V8;
	V9= V10;
	if(((V11))!=Cnil){
	goto L732;}
	RETURN(Lerror(1,VV[83])                   /*  ERROR           */);
L732:
	if((CDR((V11)))!=Cnil){
	goto L734;}
	{object V12;                              /*  CLASS-SLOT-INFO */
	T0= (VV[170]->s.s_gfdef);
	VALUES(0) = (VV[117]->s.s_gfdef);
	(*LK15)(6,(V1),(V4),VV[81],T0,VV[74],VALUES(0))/*  FIND       */;
	V12= VALUES(0);
	{object V13;
	if(((V12))==Cnil){
	goto L742;}
	V13= CDR((V12));
	goto L740;
L742:
	Lgensym(0)                                /*  GENSYM          */;
	V13= CONS(CONS((V1),VALUES(0)),Cnil);
L740:
	CDR((V11)) = (V13);
	}
	}
L734:
	{object V12;                              /*  SLOT-ENTRY      */
	register object V13;                      /*  SLOT-INDEX      */
	{register object x= (V7),V14= CDDR((V11));
	while(V14!=Cnil)
	if(CAR(V14) != Cnil && 
	x==(CAAR(V14))){
	V12= CAR(V14);
	goto L746;
	}else V14=CDR(V14);
	V12= Cnil;}
L746:
	V13= Cnil;
	if(((V12))==Cnil){
	goto L749;}
	V13= CDR((V12));
	goto L747;
L749:
	{object V14;
	Lgensym(0)                                /*  GENSYM          */;
	V13= VALUES(0);
	V14= CONS(CONS((V7),(V13)),CDDR((V11)));
	CDR(CDR((V11))) = (V14);
	}
L747:
	if(((V9))==Cnil){
	goto L756;}
	VALUES(0) = listA(4,VV[84],(V5),(V13),(V9));
	RETURN(1);
L756:
	{register object V14;                     /*  TYPE            */
	L29(2,(V1),(V7))                          /*  GET-SLOTD-TYPE  */;
	V14= VALUES(0);
	if(((VV[85]->s.s_dbind))==Cnil){
	goto L760;}
	{object V15= CONS(list(2,VV[86],list(3,VV[87],(V5),(V13))),Cnil);
	if((Ct)==((V14))){
	goto L764;}
	T0= CONS(list(2,VV[8],list(3,VV[9],(V14),VV[86])),Cnil);
	goto L762;
L764:
	T0= Cnil;
L762:
	VALUES(0) = listA(3,VV[24],V15,append(T0,CONS(list(3,VV[88],(V14),list(4,VV[31],VV[89],VV[86],list(3,VV[90],(V5),list(2,VV[7],(V7))))),Cnil)));
	RETURN(1);}
L760:
	VALUES(0) = list(3,VV[88],(V14),list(3,VV[87],(V5),(V13)));
	RETURN(1);
	}
	}
	}
}
/*	function definition for GET-SLOTD-TYPE                        */
static L29(int narg, object V1, object V2)
{ VT28 VLEX28 CLSR28
TTL:
	(*LK19)(2,(V1),VV[91])                    /*  SLOT-VALUE      */;
	T0= VALUES(0);
	VALUES(0) = (VV[172]->s.s_gfdef);
	(*LK15)(4,(V2),T0,VV[81],VALUES(0))       /*  FIND            */;
	{object V3= CDR(CDR(CDR(CDR(CDR(CDR(CDR(VALUES(0))))))));
	VALUES(0) = CAR(V3);
	RETURN(1);}
}
/*	function definition for SIGNAL-SLOT-UNBOUND                   */
static L30(int narg, object V1, object V2)
{ VT29 VLEX29 CLSR29
TTL:
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	RETURN((*LK20)(3,VALUES(0),(V1),(V2))     /*  SLOT-UNBOUND    */);
}
/*	function definition for ADD-INDEX-BINDING                     */
static L31(int narg, object V1, object V2)
{ VT30 VLEX30 CLSR30
TTL:
	{register object V3;                      /*  CLASS-INDEX-BINDINGS*/
	register object V4;                       /*  SLOT-INDEX-BINDINGS*/
	object V5;                                /*  SLOT-INDEX-DECLARATIONS*/
	V3= Cnil;
	V4= Cnil;
	V5= Cnil;
	{register object V6;
	register object V7;                       /*  ENTRY           */
	V6= (V2);
	V7= Cnil;
L775:
	if(!((V6)==Cnil)){
	goto L776;}
	V3= nreverse((V3));
	goto L771;
L776:
	V7= CAR((V6));
	if((CDR((V7)))==Cnil){
	goto L781;}
	{register object x= CDADR((V7)),V9= (V3);
	while(V9!=Cnil)
	if(CAR(V9) != Cnil && 
	x==(CAAR(V9))){
	goto L781;
	}else V9=CDR(V9);}
	{object V9= CDADR((V7));
	V3= CONS(list(2,V9,listA(3,VV[24],CONS(list(2,VV[92],list(2,VV[93],CAR((V7)))),Cnil),VV[94])),(V3));}
L781:
	V6= CDR((V6));
	goto L775;
	}
L771:
	{register object V6;
	object V7;                                /*  ENTRY           */
	V6= (V2);
	V7= Cnil;
L795:
	if(!((V6)==Cnil)){
	goto L796;}
	V4= nreverse((V4));
	goto L791;
L796:
	V7= CAR((V6));
	{register object V9;
	register object V10;                      /*  SLOT-ENTRY      */
	V9= CDDR((V7));
	V10= Cnil;
L805:
	if(!((V9)==Cnil)){
	goto L806;}
	goto L801;
L806:
	V10= CAR((V9));
	{object V12= CDR((V10));
	V4= CONS(list(2,V12,list(3,VV[95],list(2,VV[7],CAR((V10))),CDADR((V7)))),(V4));}
	V5= CONS(list(2,VV[96],CDR((V10))),(V5));
	V9= CDR((V9));
	goto L805;
	}
L801:
	V6= CDR((V6));
	goto L795;
	}
L791:
	VALUES(0) = CONS(list(3,VV[24],(V3),listA(4,VV[24],(V4),CONS(VV[8],(V5)),(V1))),Cnil);
	RETURN(1);
	}
}
/*	function definition for REDUCE-CONSTANT                       */
static L32(int narg, object V1)
{ VT31 VLEX31 CLSR31
TTL:
	{register object V2;                      /*  NEW             */
	Leval(1,(V1))                             /*  EVAL            */;
	V2= VALUES(0);
	if(!(((V2))==((V1)))){
	goto L823;}
	VALUES(0) = (V2);
	RETURN(1);
L823:
	Lconstantp(1,(V2))                        /*  CONSTANTP       */;
	if(VALUES(0)==Cnil){
	goto L826;}
	V1= (V2);
	goto TTL;
L826:
	VALUES(0) = (V2);
	RETURN(1);
	}
}
/*	function definition for VARIABLE-CLASS                        */
static L33(int narg, object V1, object V2)
{ VT32 VLEX32 CLSR32
TTL:
	(*LK18)(3,VV[9],(V1),(V2))                /*  VARIABLE-DECLARATION*/;
	VALUES(0) = CADR(VALUES(0));
	RETURN(1);
}
static LKF20(int narg, ...) {TRAMPOLINK(VV[174],&LK20);}
static LKF19(int narg, ...) {TRAMPOLINK(VV[21],&LK19);}
static LKF18(int narg, ...) {TRAMPOLINK(VV[168],&LK18);}
static LKF17(int narg, ...) {TRAMPOLINK(VV[166],&LK17);}
static LKF16(int narg, ...) {TRAMPOLINK(VV[165],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[162],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[159],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[157],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[155],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[154],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[153],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[152],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[143],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[139],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[138],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[137],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[136],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[125],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[134],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[132],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[131],&LK0);}
