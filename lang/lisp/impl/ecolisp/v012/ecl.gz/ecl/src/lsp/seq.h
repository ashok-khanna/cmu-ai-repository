
/* (c) Copyright G. Attardi, 1993. All rights reserved. */
#define VT2
#define VLEX2
#define CLSR2
static L1(int narg, object, object, ...);
static intUobject L1keys[1]={2};
int Lmake_list();
int Lmake_list();
int Lmake_list();
int Lmake_list();
int Lerror();
int siLmake_vector();
#define VT3
#define VLEX3
#define CLSR3
static L2(int narg, object, ...);
int Lplus();
#define VT4 object T0,T1;
#define VLEX4
#define CLSR4
static L3(int narg, object, object, object, ...);
int Lmin();
#define VT5 object T0,T1,T2,T3;
#define VLEX5
#define CLSR5
static L6(int narg, object, object, ...);
int Lmin();
#define VT6 object T0,T1,T2;
#define VLEX6
#define CLSR6
static L8(int narg, object, object, ...);
int Lmin();
#define VT7 object T0,T1,T2;
#define VLEX7
#define CLSR7
static L10(int narg, object, object, ...);
#define VT8 object T0,T1,T2;
#define VLEX8
#define CLSR8
static L11(int narg, object, object, ...);
#define VT9 object T0,T1,T2;
#define VLEX9
#define CLSR9
static struct codeblock Cblock;
#define VM9 3
#define VM8 3
#define VM7 3
#define VM6 3
#define VM5 4
#define VM4 2
#define VM3 0
#define VM2 0
#define VM1 23
static object VV[23];
static LKF0(int, ...);
static (*LK0)(int, ...)=LKF0;
