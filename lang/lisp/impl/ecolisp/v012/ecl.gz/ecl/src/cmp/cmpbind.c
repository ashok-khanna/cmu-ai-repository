
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "cmpbind.h"
init_cmpbind(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_cmpbind; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	MF0(VV[7],L1);
	MF0(VV[11],L2);
	MF0(VV[3],L3);
	putprop(VV[7],VV[7],VV[10]);
}
/*	function definition for BIND                                  */
static L1(int narg, object V1, object V2, ...)
{ VT3 VLEX3 CLSR3
	{int i=2;
	object V3;
	va_list args; va_start(args, V2);
	if (i==narg) goto L2;
	V3= va_arg(args, object);
	i++;
	goto L3;
L2:
	V3= Cnil;
L3:
	{object V4= ((V2))->v.v_self[4];
	if((V4!= VV[8]))goto L5;
	{register object V5;                      /*  VAR-LOC         */
	V5= ((V2))->v.v_self[5];
	if((((V2))->v.v_self[2])==Cnil){
	goto L9;}
	if(FIXNUMP((V5))){
	goto L11;}
	(*LK0)(0)                                 /*  NEXT-ENV        */;
	V5= VALUES(0);
	elt_set((V2),5,(V5));
L11:
	if(!(number_compare(MAKE_FIXNUM(0),(V5))==0)){
	goto L16;}
	(*LK1)(1,code_char('\12'))                /*  WT1             */;
	(*LK1)(1,code_char('\11'))                /*  WT1             */;
	princ_str("env",symbol_value(VV[0]));
	(*LK1)(1,(VV[1]->s.s_dbind))              /*  WT1             */;
	princ_str(" = Cnil;",symbol_value(VV[0]));
L16:
	(*LK1)(1,code_char('\12'))                /*  WT1             */;
	(*LK1)(1,code_char('\11'))                /*  WT1             */;
	princ_str("CLV",symbol_value(VV[0]));
	(*LK1)(1,(V5))                            /*  WT1             */;
	princ_str("=&CAR(env",symbol_value(VV[0]));
	(*LK1)(1,(VV[1]->s.s_dbind))              /*  WT1             */;
	princ_str("=CONS(",symbol_value(VV[0]));
	(*LK1)(1,(V1))                            /*  WT1             */;
	princ_str(",env",symbol_value(VV[0]));
	(*LK1)(1,(VV[1]->s.s_dbind))              /*  WT1             */;
	princ_str("));",symbol_value(VV[0]));
	goto L7;
L9:
	if(type_of((V5))==t_cons){
	goto L35;}
	(*LK2)(0)                                 /*  NEXT-LEX        */;
	V5= VALUES(0);
	elt_set((V2),5,(V5));
L35:
	(*LK1)(1,code_char('\12'))                /*  WT1             */;
	(*LK1)(1,code_char('\11'))                /*  WT1             */;
	(*LK3)(1,(V5))                            /*  WT-LEX          */;
	princ_char(61,symbol_value(VV[0]));
	(*LK1)(1,(V1))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[0]));
L7:
	RETURN((*LK4)(1,((V2))->v.v_self[0])      /*  WT-COMMENT      */);
	}
L5:
	if((V4!= VV[9]))goto L47;
	L3(2,(V1),(V2))                           /*  BDS-BIND        */;
	if(((V3))!=Cnil){
	goto L50;}
	(VV[2]->s.s_dbind)= CONS(VV[3],(VV[2]->s.s_dbind));
	VALUES(0) = (VV[2]->s.s_dbind);
	RETURN(1);
L50:
	VALUES(0) = Cnil;
	RETURN(1);
L47:
	if((V4!= VV[4]))goto L53;
	if(!((((V2))->v.v_self[5])==(VV[4]))){
	goto L55;}
	VALUES(0) = elt_set((V2),5,CADR((V1)));
	RETURN(1);
L55:
	if(!(type_of((V1))==t_cons)){
	goto L57;}
	if(!((VV[5])==(CAR((V1))))){
	goto L57;}
	if(number_compare(((V2))->v.v_self[5],CADR((V1)))==0){
	goto L58;}
L57:
	(*LK1)(1,code_char('\12'))                /*  WT1             */;
	(*LK1)(1,code_char('\11'))                /*  WT1             */;
	(*LK5)(1,((V2))->v.v_self[5])             /*  WT-LCL          */;
	princ_str("= ",symbol_value(VV[0]));
	(*LK1)(1,(V1))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[0]));
	VALUES(0) = Cnil;
	RETURN(1);
L58:
	VALUES(0) = Cnil;
	RETURN(1);
L53:
	(*LK1)(1,code_char('\12'))                /*  WT1             */;
	(*LK1)(1,code_char('\11'))                /*  WT1             */;
	(*LK5)(1,((V2))->v.v_self[5])             /*  WT-LCL          */;
	princ_str("= ",symbol_value(VV[0]));
	{object V6= ((V2))->v.v_self[4];
	if((V6!= VV[18]))goto L78;
	(*LK6)(1,(V1))                            /*  WT-FIXNUM-LOC   */;
	goto L77;
L78:
	if((V6!= VV[20]))goto L79;
	(*LK7)(1,(V1))                            /*  WT-CHARACTER-LOC*/;
	goto L77;
L79:
	if((V6!= VV[22]))goto L80;
	(*LK8)(1,(V1))                            /*  WT-LONG-FLOAT-LOC*/;
	goto L77;
L80:
	if((V6!= VV[24]))goto L81;
	(*LK9)(1,(V1))                            /*  WT-SHORT-FLOAT-LOC*/;
	goto L77;
L81:
	(*LK10)(0)                                /*  BABOON          */;}
L77:
	princ_char(59,symbol_value(VV[0]));
	VALUES(0) = Cnil;
	RETURN(1);}
	}
}
/*	function definition for BIND-INIT                             */
static L2(int narg, object V1, object V2, ...)
{ VT4 VLEX4 CLSR4
	bds_check;
	{int i=2;
	object V3;
	va_list args; va_start(args, V2);
	if (i==narg) goto L83;
	V3= va_arg(args, object);
	i++;
	goto L84;
L83:
	V3= Cnil;
L84:
	{object V4;
	V4= list(2,VV[7],(V1));
	bds_bind(VV[6],V4);                       /*  *DESTINATION*   */
	if(!((((V1))->v.v_self[4])==(VV[8]))){
	goto L87;}
	if((((V1))->v.v_self[2])==Cnil){
	goto L91;}
	if(FIXNUMP(((V1))->v.v_self[5])){
	goto L87;}
	(*LK0)(0)                                 /*  NEXT-ENV        */;
	elt_set((V1),5,VALUES(0));
	goto L87;
L91:
	if(type_of(((V1))->v.v_self[5])==t_cons){
	goto L87;}
	(*LK2)(0)                                 /*  NEXT-LEX        */;
	elt_set((V1),5,VALUES(0));
L87:
	(*LK11)(1,(V2))                           /*  C2EXPR*         */;
	if(!((((V1))->v.v_self[4])==(VV[9]))){
	goto L101;}
	if(((V3))!=Cnil){
	goto L101;}
	(VV[2]->s.s_dbind)= CONS(VV[3],(VV[2]->s.s_dbind));
	{int V5;
	VALUES(0)=(VV[2]->s.s_dbind);
	V5=1;
	bds_unwind1;
	RETURN(V5);}
L101:
	{int V6;
	VALUES(0)=Cnil;
	V6=1;
	bds_unwind1;
	RETURN(V6);}
	}
	}
}
/*	function definition for BDS-BIND                              */
static L3(int narg, object V1, object V2)
{ VT5 VLEX5 CLSR5
TTL:
	(*LK1)(1,code_char('\12'))                /*  WT1             */;
	(*LK1)(1,code_char('\11'))                /*  WT1             */;
	princ_str("bds_bind(VV[",symbol_value(VV[0]));
	(*LK1)(1,((V2))->v.v_self[5])             /*  WT1             */;
	princ_str("],",symbol_value(VV[0]));
	(*LK1)(1,(V1))                            /*  WT1             */;
	princ_str(");",symbol_value(VV[0]));
	RETURN((*LK4)(1,((V2))->v.v_self[0])      /*  WT-COMMENT      */);
}
static LKF11(int narg, ...) {TRAMPOLINK(VV[27],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[26],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[25],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[23],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[21],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[19],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[17],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[16],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[15],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[14],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[13],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[12],&LK0);}
