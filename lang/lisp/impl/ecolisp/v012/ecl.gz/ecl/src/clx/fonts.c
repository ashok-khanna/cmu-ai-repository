
#include "fonts.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	putprop(VV[0],VV[2],VV[1]);
	VV[80] = make_cfun(LC1,Cnil,&Cblock);
	VALUES(0) = VV[80];
	putprop(VV[0],VALUES(0),VV[3]);
	putprop(VV[0],Cnil,VV[5]);
	VV[81] = make_cfun(LC2,Cnil,&Cblock);
	VV[82] = make_cfun(LC3,Cnil,&Cblock);
	VV[83] = make_cfun(LC4,Cnil,&Cblock);
	VV[84] = make_cfun(LC5,Cnil,&Cblock);
	VV[85] = make_cfun(LC6,Cnil,&Cblock);
	VV[86] = make_cfun(LC7,Cnil,&Cblock);
	VV[87] = make_cfun(LC8,Cnil,&Cblock);
	VV[88] = make_cfun(LC9,Cnil,&Cblock);
	VV[89] = make_cfun(LC10,Cnil,&Cblock);
	VV[90] = make_cfun(LC11,Cnil,&Cblock);
	VV[91] = make_cfun(LC12,Cnil,&Cblock);
	VV[92] = make_cfun(LC13,Cnil,&Cblock);
	VV[93] = make_cfun(LC14,Cnil,&Cblock);
	VV[94] = make_cfun(LC15,Cnil,&Cblock);
	VV[95] = make_cfun(LC16,Cnil,&Cblock);
	VV[96] = make_cfun(LC17,Cnil,&Cblock);
	VV[97] = make_cfun(LC18,Cnil,&Cblock);
	VV[98] = make_cfun(LC19,Cnil,&Cblock);
	init_keywords(6, L20keys, &Cblock);
	VV[99] = make_cfun(LC20,Cnil,&Cblock);
	VALUES(0) = VV[81];
	siLfset(2,VV[6],VALUES(0))                /*  FSET            */;
	VALUES(0) = VV[82];
	siLfset(2,VV[8],VALUES(0))                /*  FSET            */;
	VALUES(0) = VV[83];
	siLfset(2,VV[9],VALUES(0))                /*  FSET            */;
	VALUES(0) = VV[84];
	siLfset(2,VV[10],VALUES(0))               /*  FSET            */;
	VALUES(0) = VV[85];
	siLfset(2,VV[11],VALUES(0))               /*  FSET            */;
	VALUES(0) = VV[86];
	siLfset(2,VV[12],VALUES(0))               /*  FSET            */;
	VALUES(0) = VV[87];
	siLfset(2,VV[13],VALUES(0))               /*  FSET            */;
	VALUES(0) = VV[88];
	siLfset(2,VV[14],VALUES(0))               /*  FSET            */;
	VALUES(0) = VV[89];
	siLfset(2,VV[15],VALUES(0))               /*  FSET            */;
	VALUES(0) = VV[90];
	siLfset(2,VV[16],VALUES(0))               /*  FSET            */;
	VALUES(0) = VV[91];
	siLfset(2,VV[17],VALUES(0))               /*  FSET            */;
	VALUES(0) = VV[92];
	siLfset(2,VV[18],VALUES(0))               /*  FSET            */;
	VALUES(0) = VV[93];
	siLfset(2,VV[19],VALUES(0))               /*  FSET            */;
	VALUES(0) = VV[94];
	siLfset(2,VV[20],VALUES(0))               /*  FSET            */;
	VALUES(0) = VV[95];
	siLfset(2,VV[21],VALUES(0))               /*  FSET            */;
	VALUES(0) = VV[96];
	siLfset(2,VV[22],VALUES(0))               /*  FSET            */;
	VALUES(0) = VV[97];
	siLfset(2,VV[23],VALUES(0))               /*  FSET            */;
	VALUES(0) = VV[98];
	siLfset(2,VV[24],VALUES(0))               /*  FSET            */;
	VALUES(0) = VV[99];
	siLfset(2,VV[25],VALUES(0))               /*  FSET            */;
	MF0(VV[100],L21);
	(void)putprop(VV[100],VV[Vdeb100],VV[101]);
	MF0(VV[102],L22);
	(void)putprop(VV[102],VV[Vdeb102],VV[101]);
	MF0(VV[103],L23);
	(void)putprop(VV[103],VV[Vdeb103],VV[101]);
	MF0(VV[104],L24);
	(void)putprop(VV[104],VV[Vdeb104],VV[101]);
	MF0(VV[105],L25);
	(void)putprop(VV[105],VV[Vdeb105],VV[101]);
	MF0key(VV[106],L26,2,L26keys);
	(void)putprop(VV[106],VV[Vdeb106],VV[101]);
	MF0key(VV[107],L27,2,L27keys);
	(void)putprop(VV[107],VV[Vdeb107],VV[101]);
	MF0key(VV[74],L28,1,L28keys);
	(void)putprop(VV[74],VV[Vdeb74],VV[101]);
	MF0(VV[75],L29);
	(void)putprop(VV[75],VV[Vdeb75],VV[101]);
	putprop(VV[74],VV[75],VV[76]);
	remprop(VV[74],VV[77]);
	remprop(VV[74],VV[78]);
	putprop(VV[74],Cnil,VV[79]);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	local function CLOSURE                                        */
static LC20(int narg, ...)
{ VT3 VLEX3 CLSR3
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[12];
	parse_key(narg,args,6,L20keys,keyvars,OBJNULL,FALSE);
	if(keyvars[6]==Cnil){
	(*LK0)(3,VV[26],VV[27],VV[28])            /*  X-ERROR         */;
	V1= (VV[29]->s.s_dbind);
	}else{
	V1= keyvars[0];}
	if(keyvars[7]==Cnil){
	(*LK0)(3,VV[26],VV[27],VV[30])            /*  X-ERROR         */;
	V2= (VV[29]->s.s_dbind);
	}else{
	V2= keyvars[1];}
	if(keyvars[8]==Cnil){
	(*LK0)(3,VV[26],VV[27],VV[31])            /*  X-ERROR         */;
	V3= (VV[29]->s.s_dbind);
	}else{
	V3= keyvars[2];}
	if(keyvars[9]==Cnil){
	(*LK0)(3,VV[26],VV[27],VV[32])            /*  X-ERROR         */;
	V4= (VV[29]->s.s_dbind);
	}else{
	V4= keyvars[3];}
	if(keyvars[10]==Cnil){
	(*LK0)(3,VV[26],VV[27],VV[33])            /*  X-ERROR         */;
	V5= (VV[29]->s.s_dbind);
	}else{
	V5= keyvars[4];}
	if(keyvars[11]==Cnil){
	(*LK0)(3,VV[26],VV[27],VV[34])            /*  X-ERROR         */;
	V6= (VV[29]->s.s_dbind);
	}else{
	V6= keyvars[5];}
	}
	{register object V7;                      /*  RESULT          */
	(*LK1)(3,MAKE_FIXNUM(6),VV[35],VV[36])    /*  MAKE-ARRAY      */;
	V7= VALUES(0);
	((V7))->fixa.fixa_self[0]= fix((V1));
	((V7))->fixa.fixa_self[1]= fix((V2));
	((V7))->fixa.fixa_self[2]= fix((V3));
	((V7))->fixa.fixa_self[3]= fix((V4));
	((V7))->fixa.fixa_self[4]= fix((V5));
	((V7))->fixa.fixa_self[fix(MAKE_FIXNUM(5))]= ((short)(fix((V6))));
	VALUES(0) = (V7);
	RETURN(1);
	}
	}
}
/*	local function CLOSURE                                        */
static LC19(int narg, object V1, object V2)
{ VT4 VLEX4 CLSR4
	{int V3;
	V3= fix(V2);
	if((((V1))->in.in_slots[3])==Cnil){
	goto L88;}
	(*LK2)(1,(V1))                            /*  FONT-MAX-CHAR   */;
	T0= VALUES(0);
	(*LK3)(1,(V1))                            /*  FONT-MIN-CHAR   */;
	Lmonotonically_nonincreasing(3,T0,MAKE_FIXNUM(V3),VALUES(0))/*  >=*/;
	if(VALUES(0)==Cnil){
	goto L88;}
	{object V4;                               /*  CHAR-INFO-VECTOR*/
	(*LK4)(1,(V1))                            /*  FONT-CHAR-INFOS */;
	V4= VALUES(0);
	if(!((((V4))->v.v_fillp)==0)){
	goto L96;}
	(*LK5)(1,(V1))                            /*  FONT-MAX-BOUNDS */;
	VALUES(0) = MAKE_FIXNUM((VALUES(0))->fixa.fixa_self[0]);
	RETURN(1);
L96:
	(*LK3)(1,(V1))                            /*  FONT-MIN-CHAR   */;
	VALUES(0) = MAKE_FIXNUM(((V4))->fixa.fixa_self[((6)*((V3)-(fix(VALUES(0)))))+(0)]);
	RETURN(1);
	}
L88:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	local function CLOSURE                                        */
static LC18(int narg, object V1)
{ VT5 VLEX5 CLSR5
	if((((V1))->in.in_slots[3])==Cnil){
	goto L101;}
	(*LK6)(1,(V1))                            /*  FONT-MIN-BOUNDS */;
	VALUES(0) = MAKE_FIXNUM((VALUES(0))->fixa.fixa_self[0]);
	RETURN(1);
L101:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC17(int narg, object V1)
{ VT6 VLEX6 CLSR6
	if((((V1))->in.in_slots[3])==Cnil){
	goto L105;}
	(*LK5)(1,(V1))                            /*  FONT-MAX-BOUNDS */;
	VALUES(0) = MAKE_FIXNUM((VALUES(0))->fixa.fixa_self[0]);
	RETURN(1);
L105:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC16(int narg, object V1, object V2)
{ VT7 VLEX7 CLSR7
	{int V3;
	V3= fix(V2);
	if((((V1))->in.in_slots[3])==Cnil){
	goto L109;}
	(*LK2)(1,(V1))                            /*  FONT-MAX-CHAR   */;
	T0= VALUES(0);
	(*LK3)(1,(V1))                            /*  FONT-MIN-CHAR   */;
	Lmonotonically_nonincreasing(3,T0,MAKE_FIXNUM(V3),VALUES(0))/*  >=*/;
	if(VALUES(0)==Cnil){
	goto L109;}
	{object V4;                               /*  CHAR-INFO-VECTOR*/
	(*LK4)(1,(V1))                            /*  FONT-CHAR-INFOS */;
	V4= VALUES(0);
	if(!((((V4))->v.v_fillp)==0)){
	goto L117;}
	(*LK5)(1,(V1))                            /*  FONT-MAX-BOUNDS */;
	VALUES(0) = MAKE_FIXNUM((VALUES(0))->fixa.fixa_self[1]);
	RETURN(1);
L117:
	(*LK3)(1,(V1))                            /*  FONT-MIN-CHAR   */;
	VALUES(0) = MAKE_FIXNUM(((V4))->fixa.fixa_self[((6)*((V3)-(fix(VALUES(0)))))+(1)]);
	RETURN(1);
	}
L109:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	local function CLOSURE                                        */
static LC15(int narg, object V1)
{ VT8 VLEX8 CLSR8
	if((((V1))->in.in_slots[3])==Cnil){
	goto L122;}
	(*LK6)(1,(V1))                            /*  FONT-MIN-BOUNDS */;
	VALUES(0) = MAKE_FIXNUM((VALUES(0))->fixa.fixa_self[1]);
	RETURN(1);
L122:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC14(int narg, object V1)
{ VT9 VLEX9 CLSR9
	if((((V1))->in.in_slots[3])==Cnil){
	goto L126;}
	(*LK5)(1,(V1))                            /*  FONT-MAX-BOUNDS */;
	VALUES(0) = MAKE_FIXNUM((VALUES(0))->fixa.fixa_self[1]);
	RETURN(1);
L126:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC13(int narg, object V1, object V2)
{ VT10 VLEX10 CLSR10
	{int V3;
	V3= fix(V2);
	if((((V1))->in.in_slots[3])==Cnil){
	goto L130;}
	(*LK2)(1,(V1))                            /*  FONT-MAX-CHAR   */;
	T0= VALUES(0);
	(*LK3)(1,(V1))                            /*  FONT-MIN-CHAR   */;
	Lmonotonically_nonincreasing(3,T0,MAKE_FIXNUM(V3),VALUES(0))/*  >=*/;
	if(VALUES(0)==Cnil){
	goto L130;}
	{object V4;                               /*  CHAR-INFO-VECTOR*/
	(*LK4)(1,(V1))                            /*  FONT-CHAR-INFOS */;
	V4= VALUES(0);
	if(!((((V4))->v.v_fillp)==0)){
	goto L138;}
	(*LK5)(1,(V1))                            /*  FONT-MAX-BOUNDS */;
	VALUES(0) = MAKE_FIXNUM((VALUES(0))->fixa.fixa_self[2]);
	RETURN(1);
L138:
	(*LK3)(1,(V1))                            /*  FONT-MIN-CHAR   */;
	VALUES(0) = MAKE_FIXNUM(((V4))->fixa.fixa_self[((6)*((V3)-(fix(VALUES(0)))))+(2)]);
	RETURN(1);
	}
L130:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	local function CLOSURE                                        */
static LC12(int narg, object V1)
{ VT11 VLEX11 CLSR11
	if((((V1))->in.in_slots[3])==Cnil){
	goto L143;}
	(*LK6)(1,(V1))                            /*  FONT-MIN-BOUNDS */;
	VALUES(0) = MAKE_FIXNUM((VALUES(0))->fixa.fixa_self[2]);
	RETURN(1);
L143:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC11(int narg, object V1)
{ VT12 VLEX12 CLSR12
	if((((V1))->in.in_slots[3])==Cnil){
	goto L147;}
	(*LK5)(1,(V1))                            /*  FONT-MAX-BOUNDS */;
	VALUES(0) = MAKE_FIXNUM((VALUES(0))->fixa.fixa_self[2]);
	RETURN(1);
L147:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC10(int narg, object V1, object V2)
{ VT13 VLEX13 CLSR13
	{int V3;
	V3= fix(V2);
	if((((V1))->in.in_slots[3])==Cnil){
	goto L151;}
	(*LK2)(1,(V1))                            /*  FONT-MAX-CHAR   */;
	T0= VALUES(0);
	(*LK3)(1,(V1))                            /*  FONT-MIN-CHAR   */;
	Lmonotonically_nonincreasing(3,T0,MAKE_FIXNUM(V3),VALUES(0))/*  >=*/;
	if(VALUES(0)==Cnil){
	goto L151;}
	{object V4;                               /*  CHAR-INFO-VECTOR*/
	(*LK4)(1,(V1))                            /*  FONT-CHAR-INFOS */;
	V4= VALUES(0);
	if(!((((V4))->v.v_fillp)==0)){
	goto L159;}
	(*LK5)(1,(V1))                            /*  FONT-MAX-BOUNDS */;
	VALUES(0) = MAKE_FIXNUM((VALUES(0))->fixa.fixa_self[3]);
	RETURN(1);
L159:
	(*LK3)(1,(V1))                            /*  FONT-MIN-CHAR   */;
	VALUES(0) = MAKE_FIXNUM(((V4))->fixa.fixa_self[((6)*((V3)-(fix(VALUES(0)))))+(3)]);
	RETURN(1);
	}
L151:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	local function CLOSURE                                        */
static LC9(int narg, object V1)
{ VT14 VLEX14 CLSR14
	if((((V1))->in.in_slots[3])==Cnil){
	goto L164;}
	(*LK6)(1,(V1))                            /*  FONT-MIN-BOUNDS */;
	VALUES(0) = MAKE_FIXNUM((VALUES(0))->fixa.fixa_self[3]);
	RETURN(1);
L164:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC8(int narg, object V1)
{ VT15 VLEX15 CLSR15
	if((((V1))->in.in_slots[3])==Cnil){
	goto L168;}
	(*LK5)(1,(V1))                            /*  FONT-MAX-BOUNDS */;
	VALUES(0) = MAKE_FIXNUM((VALUES(0))->fixa.fixa_self[3]);
	RETURN(1);
L168:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC7(int narg, object V1, object V2)
{ VT16 VLEX16 CLSR16
	{int V3;
	V3= fix(V2);
	if((((V1))->in.in_slots[3])==Cnil){
	goto L172;}
	(*LK2)(1,(V1))                            /*  FONT-MAX-CHAR   */;
	T0= VALUES(0);
	(*LK3)(1,(V1))                            /*  FONT-MIN-CHAR   */;
	Lmonotonically_nonincreasing(3,T0,MAKE_FIXNUM(V3),VALUES(0))/*  >=*/;
	if(VALUES(0)==Cnil){
	goto L172;}
	{object V4;                               /*  CHAR-INFO-VECTOR*/
	(*LK4)(1,(V1))                            /*  FONT-CHAR-INFOS */;
	V4= VALUES(0);
	if(!((((V4))->v.v_fillp)==0)){
	goto L180;}
	(*LK5)(1,(V1))                            /*  FONT-MAX-BOUNDS */;
	VALUES(0) = MAKE_FIXNUM((VALUES(0))->fixa.fixa_self[4]);
	RETURN(1);
L180:
	(*LK3)(1,(V1))                            /*  FONT-MIN-CHAR   */;
	VALUES(0) = MAKE_FIXNUM(((V4))->fixa.fixa_self[((6)*((V3)-(fix(VALUES(0)))))+(4)]);
	RETURN(1);
	}
L172:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	local function CLOSURE                                        */
static LC6(int narg, object V1)
{ VT17 VLEX17 CLSR17
	if((((V1))->in.in_slots[3])==Cnil){
	goto L185;}
	(*LK6)(1,(V1))                            /*  FONT-MIN-BOUNDS */;
	VALUES(0) = MAKE_FIXNUM((VALUES(0))->fixa.fixa_self[4]);
	RETURN(1);
L185:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC5(int narg, object V1)
{ VT18 VLEX18 CLSR18
	if((((V1))->in.in_slots[3])==Cnil){
	goto L189;}
	(*LK5)(1,(V1))                            /*  FONT-MAX-BOUNDS */;
	VALUES(0) = MAKE_FIXNUM((VALUES(0))->fixa.fixa_self[4]);
	RETURN(1);
L189:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC4(int narg, object V1, object V2)
{ VT19 VLEX19 CLSR19
	{int V3;
	V3= fix(V2);
	if((((V1))->in.in_slots[3])==Cnil){
	goto L193;}
	(*LK2)(1,(V1))                            /*  FONT-MAX-CHAR   */;
	T0= VALUES(0);
	(*LK3)(1,(V1))                            /*  FONT-MIN-CHAR   */;
	Lmonotonically_nonincreasing(3,T0,MAKE_FIXNUM(V3),VALUES(0))/*  >=*/;
	if(VALUES(0)==Cnil){
	goto L193;}
	{object V4;                               /*  CHAR-INFO-VECTOR*/
	(*LK4)(1,(V1))                            /*  FONT-CHAR-INFOS */;
	V4= VALUES(0);
	if(!((((V4))->v.v_fillp)==0)){
	goto L202;}
	(*LK5)(1,(V1))                            /*  FONT-MAX-BOUNDS */;
	VALUES(0) = MAKE_FIXNUM((VALUES(0))->fixa.fixa_self[5]);
	goto L199;
L202:
	(*LK3)(1,(V1))                            /*  FONT-MIN-CHAR   */;
	VALUES(0) = MAKE_FIXNUM(((V4))->fixa.fixa_self[((6)*((V3)-(fix(VALUES(0)))))+(5)]);
	}
L199:
	VALUES(0) = MAKE_FIXNUM(((unsigned short)(fix(VALUES(0)))));
	RETURN(1);
L193:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	local function CLOSURE                                        */
static LC3(int narg, object V1)
{ VT20 VLEX20 CLSR20
	if((((V1))->in.in_slots[3])==Cnil){
	goto L207;}
	(*LK6)(1,(V1))                            /*  FONT-MIN-BOUNDS */;
	VALUES(0) = MAKE_FIXNUM(((unsigned short)((VALUES(0))->fixa.fixa_self[5])));
	RETURN(1);
L207:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC2(int narg, object V1)
{ VT21 VLEX21 CLSR21
	if((((V1))->in.in_slots[3])==Cnil){
	goto L211;}
	(*LK5)(1,(V1))                            /*  FONT-MAX-BOUNDS */;
	VALUES(0) = MAKE_FIXNUM(((unsigned short)((VALUES(0))->fixa.fixa_self[5])));
	RETURN(1);
L211:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC1(int narg)
{ VT22 VLEX22 CLSR22
	VALUES(0) = VV[4];
	RETURN(1);
}
/*	function definition for OPEN-FONT                             */
static L21(int narg, object V1, object V2)
{ VT23 VLEX23 CLSR23
TTL:
	{register object V3;                      /*  NAME-STRING     */
	register object V4;                       /*  FONT            */
	object V5;                                /*  FONT-ID         */
	Lstring_downcase(1,coerce_to_string((V2)))/*  STRING-DOWNCASE */;
	V3= VALUES(0);
	Lmember(6,(V3),((V1))->in.in_slots[26],VV[38],VV[39],VV[40],VV[41])/*  MEMBER*/;
	V4= CAR(VALUES(0));
	V5= Cnil;
	if(((V4))!=Cnil){
	goto L218;}
	(*LK7)(4,VV[42],(V1),VV[43],(V3))         /*  MAKE-FONT       */;
	V4= VALUES(0);
	{object V6;                               /*  ID              */
	T0= ((V1))->in.in_slots[35];
	funcall(2,T0,(V1));
	V6= VALUES(0);
	(*LK8)(3,(V1),(V6),(V4))                  /*  SAVE-ID         */;
	V5= (V6);
	}
	((V4))->in.in_slots[0]= (V5);
	{register object V6;                      /*  .DISPLAY.       */
	V6= (V1);
	if((((V6))->in.in_slots[10])==Cnil){
	goto L230;}
	(*LK0)(3,VV[45],VV[42],(V6))              /*  X-ERROR         */;
L230:
	{register object V7;                      /*  %BUFFER         */
	V7= (V6);
	if(!(((fix(((V7))->in.in_slots[6]))+(160))>=(fix(((V7))->in.in_slots[2])))){
	goto L234;}
	(*LK9)(1,(V7))                            /*  BUFFER-FLUSH    */;
L234:
	{register int V8;                         /*  BUFFER-BOFFSET  */
	object V9;                                /*  BUFFER-BBUF     */
	V8= fix(((V7))->in.in_slots[6]);
	V9= ((V7))->in.in_slots[7];
	((V6))->in.in_slots[4]= MAKE_FIXNUM(V8);
	(((V9))->ust.ust_self[(V8)+(0)]=(45));
	(*LK10)(2,(V5),VV[46])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L245;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(4))))=fix((V5)));
	goto L243;
L245:
	(*LK11)(2,(V5),VV[46])                    /*  X-TYPE-ERROR    */;
L243:
	{register int V10;                        /*  .VALUE.         */
	V10= ((V3))->v.v_fillp;
	(*LK10)(2,MAKE_FIXNUM(V10),VV[47])        /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L250;}
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(8))))=V10);
	goto L247;
L250:
	(*LK11)(2,MAKE_FIXNUM(V10),VV[47])        /*  X-TYPE-ERROR    */;
	}
L247:
	(*LK10)(2,(V3),VV[48])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L255;}
	{int V10;
	V10= ((V3))->v.v_fillp;
	Lceiling(2,MAKE_FIXNUM(((V10)-(0))+(12)),MAKE_FIXNUM(4))/*  CEILING*/;
	T0= VALUES(0);
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=fix(T0));
	(*LK12)(5,(V7),MAKE_FIXNUM((V8)+(12)),(V3),MAKE_FIXNUM(0),MAKE_FIXNUM(V10))/*  WRITE-SEQUENCE-CHAR*/;
	goto L253;
	}
L255:
	(*LK11)(2,(V3),VV[48])                    /*  X-TYPE-ERROR    */;
L253:
	(*LK13)(1,(V6))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK14)(1,(V6))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	{object V6;
	V6= CONS((V4),((V1))->in.in_slots[26]);
	((V1))->in.in_slots[26]= (V6);
	}
L218:
	{object V6;
	V6= MAKE_FIXNUM((fix(((V4))->in.in_slots[2]))+(1));
	((V4))->in.in_slots[2]= (V6);
	}
	VALUES(0) = (V4);
	RETURN(1);
	}
}
/*	function definition for OPEN-FONT-INTERNAL                    */
static L22(int narg, object V1)
{ VT24 VLEX24 CLSR24
TTL:
	{register object V2;                      /*  NAME-STRING     */
	register object V3;                       /*  DISPLAY         */
	register object V4;                       /*  ID              */
	V2= ((V1))->in.in_slots[3];
	V3= ((V1))->in.in_slots[1];
	{object V5;                               /*  ID              */
	T0= ((V3))->in.in_slots[35];
	funcall(2,T0,(V3));
	V5= VALUES(0);
	(*LK8)(3,(V3),(V5),(V1))                  /*  SAVE-ID         */;
	V4= (V5);
	}
	((V1))->in.in_slots[0]= (V4);
	{register object V5;                      /*  .DISPLAY.       */
	V5= (V3);
	if((((V5))->in.in_slots[10])==Cnil){
	goto L271;}
	(*LK0)(3,VV[45],VV[42],(V5))              /*  X-ERROR         */;
L271:
	{register object V6;                      /*  %BUFFER         */
	V6= (V5);
	if(!(((fix(((V6))->in.in_slots[6]))+(160))>=(fix(((V6))->in.in_slots[2])))){
	goto L275;}
	(*LK9)(1,(V6))                            /*  BUFFER-FLUSH    */;
L275:
	{register int V7;                         /*  BUFFER-BOFFSET  */
	register object V8;                       /*  BUFFER-BBUF     */
	V7= fix(((V6))->in.in_slots[6]);
	V8= ((V6))->in.in_slots[7];
	((V5))->in.in_slots[4]= MAKE_FIXNUM(V7);
	(((V8))->ust.ust_self[(V7)+(0)]=(45));
	(*LK10)(2,(V4),VV[46])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L286;}
	((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(4))))=fix((V4)));
	goto L284;
L286:
	(*LK11)(2,(V4),VV[46])                    /*  X-TYPE-ERROR    */;
L284:
	{register int V9;                         /*  .VALUE.         */
	V9= length((V2));
	(*LK10)(2,MAKE_FIXNUM(V9),VV[47])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L291;}
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(8))))=V9);
	goto L288;
L291:
	(*LK11)(2,MAKE_FIXNUM(V9),VV[47])         /*  X-TYPE-ERROR    */;
	}
L288:
	(*LK10)(2,(V2),VV[48])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L296;}
	{int V9;
	V9= length((V2));
	Lceiling(2,MAKE_FIXNUM(((V9)-(0))+(12)),MAKE_FIXNUM(4))/*  CEILING*/;
	T0= VALUES(0);
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(2))))=fix(T0));
	(*LK12)(5,(V6),MAKE_FIXNUM((V7)+(12)),(V2),MAKE_FIXNUM(0),MAKE_FIXNUM(V9))/*  WRITE-SEQUENCE-CHAR*/;
	goto L294;
	}
L296:
	(*LK11)(2,(V2),VV[48])                    /*  X-TYPE-ERROR    */;
L294:
	(*LK13)(1,(V5))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK14)(1,(V5))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	{object V5;
	V5= CONS((V1),((V3))->in.in_slots[26]);
	((V3))->in.in_slots[26]= (V5);
	}
	{object V5;
	V5= MAKE_FIXNUM((fix(((V1))->in.in_slots[2]))+(1));
	((V1))->in.in_slots[2]= (V5);
	}
	VALUES(0) = (V4);
	RETURN(1);
	}
}
/*	function definition for DISCARD-FONT-INFO                     */
static L23(int narg, object V1)
{ VT25 VLEX25 CLSR25
TTL:
	((V1))->in.in_slots[4]= Cnil;
	((V1))->in.in_slots[5]= Cnil;
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for QUERY-FONT                            */
static L24(int narg, object V1)
{ VT26 VLEX26 CLSR26
TTL:
	{volatile object V2;                      /*  DISPLAY         */
	volatile object V3;                       /*  FONT-ID         */
	volatile object V4;                       /*  FONT-INFO       */
	volatile object V5;                       /*  PROPS           */
	V2= ((V1))->in.in_slots[1];
	V3= Cnil;
	V4= Cnil;
	V5= Cnil;
	(*LK15)(1,(V1))                           /*  FONT-ID         */;
	V3= VALUES(0);
	{volatile object V6;                      /*  .DISPLAY.       */
	volatile object V7;                       /*  .PENDING-COMMAND.*/
	volatile object V8;                       /*  .REPLY-BUFFER.  */
	V6= (V2);
	V7= Cnil;
	V8= Cnil;
	{ int V9; volatile bool unwinding = FALSE;
	if ((V9=frs_push(FRS_PROTECT,Cnil))) {
	V9--; unwinding = TRUE;} else {
	if((((V6))->in.in_slots[10])==Cnil){
	goto L312;}
	(*LK0)(3,VV[45],VV[42],(V6))              /*  X-ERROR         */;
L312:
	(*LK16)(1,(V6))                           /*  START-PENDING-COMMAND*/;
	V7= VALUES(0);
	{object V10;                              /*  %BUFFER         */
	V10= (V6);
	if(!(((fix(((V10))->in.in_slots[6]))+(160))>=(fix(((V10))->in.in_slots[2])))){
	goto L318;}
	(*LK9)(1,(V10))                           /*  BUFFER-FLUSH    */;
L318:
	{register int V11;                        /*  BUFFER-BOFFSET  */
	object V12;                               /*  BUFFER-BBUF     */
	V11= fix(((V10))->in.in_slots[6]);
	V12= ((V10))->in.in_slots[7];
	((V6))->in.in_slots[4]= MAKE_FIXNUM(V11);
	(((V12))->ust.ust_self[(V11)+(0)]=(47));
	(*LK10)(2,(V3),VV[46])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L329;}
	((*(unsigned long *)(((V12))->ust.ust_self+((V11)+(4))))=fix((V3)));
	goto L327;
L329:
	(*LK11)(2,(V3),VV[46])                    /*  X-TYPE-ERROR    */;
L327:
	((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(2))))=2);
	((V6))->in.in_slots[6]= MAKE_FIXNUM((V11)+(8));
	(*LK13)(1,(V6))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK17)(1,(V6))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V6))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK18)(2,(V6),(V7))                      /*  READ-REPLY      */;
	V8= VALUES(0);
	{object V10;                              /*  %REPLY-BUFFER   */
	object V11;                               /*  %BUFFER         */
	V10= (V8);
	{register int V12;                        /*  BUFFER-BOFFSET  */
	register object V13;                      /*  BUFFER-BBUF     */
	V12= 0;
	V13= ((V10))->in.in_slots[1];
	{int V14;                                 /*  MIN-BYTE2       */
	int V15;                                  /*  MAX-BYTE2       */
	object V16;                               /*  MIN-BYTE1       */
	int V17;                                  /*  MAX-BYTE1       */
	object V18;                               /*  MIN-CHAR        */
	object V19;                               /*  MAX-CHAR        */
	int V20;                                  /*  NFONT-PROPS     */
	int V21;                                  /*  NCHAR-INFOS     */
	object V22;                               /*  CHAR-INFO       */
	V14= (*(unsigned short *)(((V13))->ust.ust_self+((V12)+(40))));
	V15= (*(unsigned short *)(((V13))->ust.ust_self+((V12)+(42))));
	V16= MAKE_FIXNUM(((V13))->ust.ust_self[(V12)+(49)]);
	V17= ((V13))->ust.ust_self[(V12)+(50)];
	V18= MAKE_FIXNUM(V14);
	V19= MAKE_FIXNUM((((V17) << (8)))+(V15));
	V20= (*(unsigned short *)(((V13))->ust.ust_self+((V12)+(46))));
	V21= ((*(unsigned long *)(((V13))->ust.ust_self+((V12)+(56)))))*(6);
	(*LK1)(3,MAKE_FIXNUM(V21),VV[35],VV[36])  /*  MAKE-ARRAY      */;
	V22= VALUES(0);
	{int V23;
	V23= ((V13))->ust.ust_self[(V12)+(48)];
	if((V23)<(2)){
	goto L355;}
	T0= Cnil;
	goto L353;
L355:
	T0= (VV[51])->v.v_self[V23];
	}
L353:
	{object V23= ((((V13))->ust.ust_self[(V12)+(51)])>0?Ct:Cnil);
	{int V24= (*(unsigned short *)(((V13))->ust.ust_self+((V12)+(44))));
	{int V25= (*(short *)(((V13))->st.st_self+((V12)+(52))));
	{int V26= (*(short *)(((V13))->st.st_self+((V12)+(54))));
	{int V27= (*(short *)(((V13))->st.st_self+((V12)+(8))));
	{int V28= (*(short *)(((V13))->st.st_self+((V12)+(10))));
	{int V29= (*(short *)(((V13))->st.st_self+((V12)+(12))));
	{int V30= (*(short *)(((V13))->st.st_self+((V12)+(14))));
	{int V31= (*(short *)(((V13))->st.st_self+((V12)+(16))));
	(*LK19)(12,VV[63],MAKE_FIXNUM(V27),VV[64],MAKE_FIXNUM(V28),VV[65],MAKE_FIXNUM(V29),VV[60],MAKE_FIXNUM(V30),VV[61],MAKE_FIXNUM(V31),VV[66],MAKE_FIXNUM((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(18))))))/*  MAKE-CHAR-INFO*/;
	T1= VALUES(0);
	{int V32= (*(short *)(((V13))->st.st_self+((V12)+(24))));
	{int V33= (*(short *)(((V13))->st.st_self+((V12)+(26))));
	{int V34= (*(short *)(((V13))->st.st_self+((V12)+(28))));
	{int V35= (*(short *)(((V13))->st.st_self+((V12)+(30))));
	{int V36= (*(short *)(((V13))->st.st_self+((V12)+(32))));
	(*LK19)(12,VV[63],MAKE_FIXNUM(V32),VV[64],MAKE_FIXNUM(V33),VV[65],MAKE_FIXNUM(V34),VV[60],MAKE_FIXNUM(V35),VV[61],MAKE_FIXNUM(V36),VV[66],MAKE_FIXNUM((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(34))))))/*  MAKE-CHAR-INFO*/;
	(*LK20)(26,VV[50],T0,VV[52],(V18),VV[53],(V19),VV[54],(V16),VV[55],MAKE_FIXNUM(V17),VV[56],MAKE_FIXNUM(V14),VV[57],MAKE_FIXNUM(V15),VV[58],(V23),VV[59],MAKE_FIXNUM(V24),VV[60],MAKE_FIXNUM(V25),VV[61],MAKE_FIXNUM(V26),VV[62],T1,VV[67],VALUES(0))/*  MAKE-FONT-INFO*/;
	V4= VALUES(0);}}}}}}}}}}}}}}
	(*LK21)(7,(V10),VV[68],MAKE_FIXNUM((2)*(V20)),Cnil,Cnil,MAKE_FIXNUM(0),MAKE_FIXNUM(60))/*  READ-SEQUENCE-INT32*/;
	V5= VALUES(0);
	(*LK22)(7,(V10),Cnil,MAKE_FIXNUM(V21),Cnil,(V22),MAKE_FIXNUM(0),MAKE_FIXNUM((60)+(((2)*(V20))*(4))))/*  READ-SEQUENCE-INT16*/;
	((V1))->in.in_slots[5]= (V22);
	((V1))->in.in_slots[4]= (V4);
	VALUES(0)=(V4);
	V9=1;
	}
	}
	}
	}
	frs_pop();
	MV_SAVE(V9);
	if(((V8))==Cnil){
	goto L364;}
	(*LK23)(1,(V8))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L364:
	if(((V7))==Cnil){
	goto L363;}
	(*LK24)(2,(V6),(V7))                      /*  STOP-PENDING-COMMAND*/;
L363:
	MV_RESTORE(V9);
	if (unwinding) unwind(nlj_fr,nlj_tag,V9+1);
	else {}}
	}
	{volatile object V6;                      /*  P               */
	V6= (V5);
L371:
	if(!((V6)==Cnil)){
	goto L372;}
	goto L369;
L372:
	{register object V8;
	register object V9;
	V8= (V6);
	(*LK25)(2,(V2),CAR((V6)))                 /*  ATOM-NAME       */;
	V9= VALUES(0);
	CAR((V8)) = (V9);
	}
	V6= CDDR((V6));
	goto L371;
	}
L369:
	((V4))->in.in_slots[13]= (V5);
	VALUES(0) = (V4);
	RETURN(1);
	}
}
/*	function definition for CLOSE-FONT                            */
static L25(int narg, object V1)
{ VT27 VLEX27 CLSR27
TTL:
	{object V2;
	V2= MAKE_FIXNUM((fix(((V1))->in.in_slots[2]))-(1));
	((V1))->in.in_slots[2]= (V2);
	VALUES(0) = (V2);
	}
	if(number_compare(MAKE_FIXNUM(0),VALUES(0))<0){
	goto L384;}
	if((((V1))->in.in_slots[0])==Cnil){
	goto L384;}
	{object V2;                               /*  DISPLAY         */
	object V3;                                /*  ID              */
	V2= ((V1))->in.in_slots[1];
	V3= ((V1))->in.in_slots[0];
	(*LK26)(2,(V1),((V2))->in.in_slots[26])   /*  DELETE          */;
	((V2))->in.in_slots[26]= VALUES(0);
	{register object V4;                      /*  .DISPLAY.       */
	V4= (V2);
	if((((V4))->in.in_slots[10])==Cnil){
	goto L394;}
	(*LK0)(3,VV[45],VV[42],(V4))              /*  X-ERROR         */;
L394:
	{ int V5;
	{register object V6;                      /*  %BUFFER         */
	V6= (V4);
	if(!(((fix(((V6))->in.in_slots[6]))+(160))>=(fix(((V6))->in.in_slots[2])))){
	goto L398;}
	(*LK9)(1,(V6))                            /*  BUFFER-FLUSH    */;
L398:
	{register int V7;                         /*  BUFFER-BOFFSET  */
	register object V8;                       /*  BUFFER-BBUF     */
	V7= fix(((V6))->in.in_slots[6]);
	V8= ((V6))->in.in_slots[7];
	((V4))->in.in_slots[4]= MAKE_FIXNUM(V7);
	(((V8))->ust.ust_self[(V7)+(0)]=(46));
	(*LK10)(2,(V3),VV[46])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L409;}
	((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(4))))=fix((V3)));
	goto L407;
L409:
	(*LK11)(2,(V3),VV[46])                    /*  X-TYPE-ERROR    */;
L407:
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(2))))=2);
	((V4))->in.in_slots[6]= MAKE_FIXNUM((V7)+(8));
	V5=(*LK13)(1,(V4))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V5);
	(*LK14)(1,(V4))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V5);
	RETURN(V5);}
	}
	}
L384:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for LIST-FONT-NAMES                       */
static L26(int narg, object V1, object V2, ...)
{ VT28 VLEX28 CLSR28
	{volatile int V3;
	volatile object V4;
	va_list args; va_start(args, V2);
	narg -=2;
	{ object keyvars[4];
	parse_key(narg,args,2,L26keys,keyvars,OBJNULL,FALSE);
	if(keyvars[2]==Cnil){
	V3= 65535;
	}else{
	V3= fix(keyvars[0]);}
	if(keyvars[3]==Cnil){
	V4= VV[68];
	}else{
	V4= keyvars[1];}
	}
	{volatile object V5;                      /*  STRING          */
	V5= coerce_to_string((V2));
	{volatile object V6;                      /*  .DISPLAY.       */
	volatile object V7;                       /*  .PENDING-COMMAND.*/
	volatile object V8;                       /*  .REPLY-BUFFER.  */
	V6= (V1);
	V7= Cnil;
	V8= Cnil;
	{ int V9; volatile bool unwinding = FALSE;
	if ((V9=frs_push(FRS_PROTECT,Cnil))) {
	V9--; unwinding = TRUE;} else {
	if((((V6))->in.in_slots[10])==Cnil){
	goto L419;}
	(*LK0)(3,VV[45],VV[42],(V6))              /*  X-ERROR         */;
L419:
	(*LK16)(1,(V6))                           /*  START-PENDING-COMMAND*/;
	V7= VALUES(0);
	{register object V10;                     /*  %BUFFER         */
	V10= (V6);
	if(!(((fix(((V10))->in.in_slots[6]))+(160))>=(fix(((V10))->in.in_slots[2])))){
	goto L425;}
	(*LK9)(1,(V10))                           /*  BUFFER-FLUSH    */;
L425:
	{register int V11;                        /*  BUFFER-BOFFSET  */
	register object V12;                      /*  BUFFER-BBUF     */
	V11= fix(((V10))->in.in_slots[6]);
	V12= ((V10))->in.in_slots[7];
	((V6))->in.in_slots[4]= MAKE_FIXNUM(V11);
	(((V12))->ust.ust_self[(V11)+(0)]=(49));
	(*LK10)(2,MAKE_FIXNUM(V3),VV[47])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L436;}
	((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(4))))=V3);
	goto L434;
L436:
	(*LK11)(2,MAKE_FIXNUM(V3),VV[47])         /*  X-TYPE-ERROR    */;
L434:
	{register int V13;                        /*  .VALUE.         */
	V13= ((V5))->v.v_fillp;
	(*LK10)(2,MAKE_FIXNUM(V13),VV[47])        /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L441;}
	((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(6))))=V13);
	goto L438;
L441:
	(*LK11)(2,MAKE_FIXNUM(V13),VV[47])        /*  X-TYPE-ERROR    */;
	}
L438:
	(*LK10)(2,(V5),VV[48])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L445;}
	{int V13;
	V13= ((V5))->v.v_fillp;
	Lceiling(2,MAKE_FIXNUM(((V13)-(0))+(8)),MAKE_FIXNUM(4))/*  CEILING*/;
	T0= VALUES(0);
	((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(2))))=fix(T0));
	(*LK12)(5,(V10),MAKE_FIXNUM((V11)+(8)),(V5),MAKE_FIXNUM(0),MAKE_FIXNUM(V13))/*  WRITE-SEQUENCE-CHAR*/;
	goto L443;
	}
L445:
	(*LK11)(2,(V5),VV[48])                    /*  X-TYPE-ERROR    */;
L443:
	(*LK13)(1,(V6))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK17)(1,(V6))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V6))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK18)(2,(V6),(V7))                      /*  READ-REPLY      */;
	V8= VALUES(0);
	{int V10;                                 /*  SIZE            */
	V10= fix(((V8))->in.in_slots[3]);
	{object V11;                              /*  %REPLY-BUFFER   */
	object V12;                               /*  %BUFFER         */
	{int V13;                                 /*  BUFFER-BOFFSET  */
	object V14;                               /*  BUFFER-BBUF     */
	V13= 0;
	V14= ((V8))->in.in_slots[1];
	{int V15= (V10)-(32);
	V9=(*LK27)(5,(V14),MAKE_FIXNUM(V15),MAKE_FIXNUM((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(8))))),(V4),MAKE_FIXNUM(32))/*  READ-SEQUENCE-STRING*/;}
	}
	}
	}
	}
	frs_pop();
	MV_SAVE(V9);
	if(((V8))==Cnil){
	goto L461;}
	(*LK23)(1,(V8))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L461:
	if(((V7))==Cnil){
	goto L460;}
	(*LK24)(2,(V6),(V7))                      /*  STOP-PENDING-COMMAND*/;
L460:
	MV_RESTORE(V9);
	if (unwinding) unwind(nlj_fr,nlj_tag,V9+1);
	else {
	RETURN(V9);}}
	}
	}
	}
}
/*	function definition for LIST-FONTS                            */
static L27(int narg, object V1, object V2, ...)
{ VT29 VLEX29 CLSR29
	{volatile int V3;
	volatile object V4;
	va_list args; va_start(args, V2);
	narg -=2;
	{ object keyvars[4];
	parse_key(narg,args,2,L27keys,keyvars,OBJNULL,FALSE);
	if(keyvars[2]==Cnil){
	V3= 65535;
	}else{
	V3= fix(keyvars[0]);}
	if(keyvars[3]==Cnil){
	V4= VV[68];
	}else{
	V4= keyvars[1];}
	}
	{volatile object V5;                      /*  STRING          */
	volatile object V6;                       /*  RESULT          */
	V5= coerce_to_string((V2));
	V6= Cnil;
	{volatile object V7;                      /*  .DISPLAY.       */
	volatile object V8;                       /*  .PENDING-COMMAND.*/
	volatile object V9;                       /*  .REPLY-BUFFER.  */
	V7= (V1);
	V8= Cnil;
	V9= Cnil;
	{ int V10; volatile bool unwinding = FALSE;
	if ((V10=frs_push(FRS_PROTECT,Cnil))) {
	V10--; unwinding = TRUE;} else {
	if((((V7))->in.in_slots[10])==Cnil){
	goto L472;}
	(*LK0)(3,VV[45],VV[42],(V7))              /*  X-ERROR         */;
L472:
	(*LK16)(1,(V7))                           /*  START-PENDING-COMMAND*/;
	V8= VALUES(0);
	{object V11;                              /*  %BUFFER         */
	V11= (V7);
	if(!(((fix(((V11))->in.in_slots[6]))+(160))>=(fix(((V11))->in.in_slots[2])))){
	goto L478;}
	(*LK9)(1,(V11))                           /*  BUFFER-FLUSH    */;
L478:
	{int V12;                                 /*  BUFFER-BOFFSET  */
	object V13;                               /*  BUFFER-BBUF     */
	V12= fix(((V11))->in.in_slots[6]);
	V13= ((V11))->in.in_slots[7];
	((V7))->in.in_slots[4]= MAKE_FIXNUM(V12);
	(((V13))->ust.ust_self[(V12)+(0)]=(50));
	(*LK10)(2,MAKE_FIXNUM(V3),VV[47])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L489;}
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(4))))=V3);
	goto L487;
L489:
	(*LK11)(2,MAKE_FIXNUM(V3),VV[47])         /*  X-TYPE-ERROR    */;
L487:
	{int V14;                                 /*  .VALUE.         */
	V14= ((V5))->v.v_fillp;
	(*LK10)(2,MAKE_FIXNUM(V14),VV[47])        /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L494;}
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(6))))=V14);
	goto L491;
L494:
	(*LK11)(2,MAKE_FIXNUM(V14),VV[47])        /*  X-TYPE-ERROR    */;
	}
L491:
	(*LK10)(2,(V5),VV[48])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L498;}
	{int V14;
	V14= ((V5))->v.v_fillp;
	Lceiling(2,MAKE_FIXNUM(((V14)-(0))+(8)),MAKE_FIXNUM(4))/*  CEILING*/;
	T0= VALUES(0);
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(2))))=fix(T0));
	(*LK12)(5,(V11),MAKE_FIXNUM((V12)+(8)),(V5),MAKE_FIXNUM(0),MAKE_FIXNUM(V14))/*  WRITE-SEQUENCE-CHAR*/;
	goto L496;
	}
L498:
	(*LK11)(2,(V5),VV[48])                    /*  X-TYPE-ERROR    */;
L496:
	(*LK13)(1,(V7))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK17)(1,(V7))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V7))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
L505:
	(*LK18)(2,(V7),(V8))                      /*  READ-REPLY      */;
	V9= VALUES(0);
	{object V11;                              /*  %REPLY-BUFFER   */
	object V12;                               /*  %BUFFER         */
	V11= (V9);
	V12= (V7);
	{register int V13;                        /*  BUFFER-BOFFSET  */
	register object V14;                      /*  BUFFER-BBUF     */
	V13= 0;
	V14= ((V11))->in.in_slots[1];
	if(!((((V14))->ust.ust_self[(V13)+(1)])==0)){
	goto L519;}
	goto L511;
L519:
	{object V15;                              /*  NAME-LEN        */
	register int V16;                         /*  MIN-BYTE2       */
	register int V17;                         /*  MAX-BYTE2       */
	object V18;                               /*  MIN-BYTE1       */
	register int V19;                         /*  MAX-BYTE1       */
	object V20;                               /*  MIN-CHAR        */
	object V21;                               /*  MAX-CHAR        */
	register int V22;                         /*  NFONT-PROPS     */
	object V23;                               /*  FONT            */
	V15= MAKE_FIXNUM(((V14))->ust.ust_self[(V13)+(1)]);
	V16= (*(unsigned short *)(((V14))->ust.ust_self+((V13)+(40))));
	V17= (*(unsigned short *)(((V14))->ust.ust_self+((V13)+(42))));
	V18= MAKE_FIXNUM(((V14))->ust.ust_self[(V13)+(49)]);
	V19= ((V14))->ust.ust_self[(V13)+(50)];
	V20= MAKE_FIXNUM(V16);
	V21= MAKE_FIXNUM((((V19) << (8)))+(V17));
	V22= (*(unsigned short *)(((V14))->ust.ust_self+((V13)+(46))));
	{register int V24;
	V24= ((V14))->ust.ust_self[(V13)+(48)];
	if((V24)<(2)){
	goto L533;}
	T0= Cnil;
	goto L531;
L533:
	T0= (VV[71])->v.v_self[V24];
	}
L531:
	{object V24= ((((V14))->ust.ust_self[(V13)+(51)])>0?Ct:Cnil);
	{int V25= (*(unsigned short *)(((V14))->ust.ust_self+((V13)+(44))));
	{int V26= (*(short *)(((V14))->st.st_self+((V13)+(52))));
	{int V27= (*(short *)(((V14))->st.st_self+((V13)+(54))));
	{int V28= (*(short *)(((V14))->st.st_self+((V13)+(8))));
	{int V29= (*(short *)(((V14))->st.st_self+((V13)+(10))));
	{int V30= (*(short *)(((V14))->st.st_self+((V13)+(12))));
	{int V31= (*(short *)(((V14))->st.st_self+((V13)+(14))));
	{int V32= (*(short *)(((V14))->st.st_self+((V13)+(16))));
	(*LK19)(12,VV[63],MAKE_FIXNUM(V28),VV[64],MAKE_FIXNUM(V29),VV[65],MAKE_FIXNUM(V30),VV[60],MAKE_FIXNUM(V31),VV[61],MAKE_FIXNUM(V32),VV[66],MAKE_FIXNUM((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(18))))))/*  MAKE-CHAR-INFO*/;
	T1= VALUES(0);
	{int V33= (*(short *)(((V14))->st.st_self+((V13)+(24))));
	{int V34= (*(short *)(((V14))->st.st_self+((V13)+(26))));
	{int V35= (*(short *)(((V14))->st.st_self+((V13)+(28))));
	{int V36= (*(short *)(((V14))->st.st_self+((V13)+(30))));
	{int V37= (*(short *)(((V14))->st.st_self+((V13)+(32))));
	(*LK19)(12,VV[63],MAKE_FIXNUM(V33),VV[64],MAKE_FIXNUM(V34),VV[65],MAKE_FIXNUM(V35),VV[60],MAKE_FIXNUM(V36),VV[61],MAKE_FIXNUM(V37),VV[66],MAKE_FIXNUM((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(34))))))/*  MAKE-CHAR-INFO*/;
	T2= VALUES(0);
	(*LK21)(7,(V11),VV[68],MAKE_FIXNUM((2)*(V22)),Cnil,Cnil,MAKE_FIXNUM(0),MAKE_FIXNUM(60))/*  READ-SEQUENCE-INT32*/;
	(*LK20)(28,VV[50],T0,VV[52],(V20),VV[53],(V21),VV[54],(V18),VV[55],MAKE_FIXNUM(V19),VV[56],MAKE_FIXNUM(V16),VV[57],MAKE_FIXNUM(V17),VV[58],(V24),VV[59],MAKE_FIXNUM(V25),VV[60],MAKE_FIXNUM(V26),VV[61],MAKE_FIXNUM(V27),VV[62],T1,VV[67],T2,VV[72],VALUES(0))/*  MAKE-FONT-INFO*/;
	(*LK7)(6,VV[42],(V1),VV[43],Cnil,VV[70],VALUES(0))/*  MAKE-FONT*/;
	V23= VALUES(0);}}}}}}}}}}}}}}
	(*LK28)(7,(V11),VV[48],(V15),Cnil,Cnil,MAKE_FIXNUM(0),MAKE_FIXNUM((60)+(((2)*(V22))*(4))))/*  READ-SEQUENCE-CHAR*/;
	((V23))->in.in_slots[3]= VALUES(0);
	V6= CONS((V23),(V6));
	}
	goto L509;
	}
	}
L511:
	VALUES(0)=Cnil;
	V10=1;
	goto L470;
L509:
	{object V11;
	object V12;
	V11= (V9);
	V12= Cnil;
	V9= (V12);
	VALUES(0) = (V11);
	}
	(*LK23)(1,VALUES(0))                      /*  DEALLOCATE-REPLY-BUFFER*/;
	goto L505;
L470:
	}
	frs_pop();
	MV_SAVE(V10);
	if(((V9))==Cnil){
	goto L549;}
	(*LK23)(1,(V9))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L549:
	if(((V8))==Cnil){
	goto L548;}
	(*LK24)(2,(V7),(V8))                      /*  STOP-PENDING-COMMAND*/;
L548:
	MV_RESTORE(V10);
	if (unwinding) unwind(nlj_fr,nlj_tag,V10+1);
	else {}}
	}
	{volatile object V7;
	volatile object V8;                       /*  FONT            */
	V7= (V6);
	V8= Cnil;
L558:
	if(!((V7)==Cnil)){
	goto L559;}
	goto L554;
L559:
	V8= CAR((V7));
	{volatile object V10;                     /*  P               */
	(*LK29)(1,(V8))                           /*  FONT-PROPERTIES */;
	V10= VALUES(0);
L567:
	if(!((V10)==Cnil)){
	goto L568;}
	goto L564;
L568:
	{object V12;
	register object V13;
	V12= (V10);
	(*LK25)(2,(V1),CAR((V10)))                /*  ATOM-NAME       */;
	V13= VALUES(0);
	CAR((V12)) = (V13);
	}
	V10= CDDR((V10));
	goto L567;
	}
L564:
	V7= CDR((V7));
	goto L558;
	}
L554:
	{object V7= nreverse((V6));
	RETURN((*LK30)(2,(V7),(V4))               /*  COERCE          */);}
	}
	}
}
/*	function definition for FONT-PATH                             */
static L28(int narg, object V1, ...)
{ VT30 VLEX30 CLSR30
	{volatile object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[2];
	parse_key(narg,args,1,L28keys,keyvars,OBJNULL,FALSE);
	if(keyvars[1]==Cnil){
	V2= VV[68];
	}else{
	V2= keyvars[0];}
	}
	{volatile object V3;                      /*  .DISPLAY.       */
	volatile object V4;                       /*  .PENDING-COMMAND.*/
	volatile object V5;                       /*  .REPLY-BUFFER.  */
	V3= (V1);
	V4= Cnil;
	V5= Cnil;
	{ int V6; volatile bool unwinding = FALSE;
	if ((V6=frs_push(FRS_PROTECT,Cnil))) {
	V6--; unwinding = TRUE;} else {
	if((((V3))->in.in_slots[10])==Cnil){
	goto L584;}
	(*LK0)(3,VV[45],VV[42],(V3))              /*  X-ERROR         */;
L584:
	(*LK16)(1,(V3))                           /*  START-PENDING-COMMAND*/;
	V4= VALUES(0);
	{register object V7;                      /*  %BUFFER         */
	V7= (V3);
	if(!(((fix(((V7))->in.in_slots[6]))+(160))>=(fix(((V7))->in.in_slots[2])))){
	goto L590;}
	(*LK9)(1,(V7))                            /*  BUFFER-FLUSH    */;
L590:
	{register int V8;                         /*  BUFFER-BOFFSET  */
	object V9;                                /*  BUFFER-BBUF     */
	V8= fix(((V7))->in.in_slots[6]);
	V9= ((V7))->in.in_slots[7];
	((V3))->in.in_slots[4]= MAKE_FIXNUM(V8);
	(((V9))->ust.ust_self[(V8)+(0)]=(52));
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=1);
	((V3))->in.in_slots[6]= MAKE_FIXNUM((V8)+(4));
	(*LK13)(1,(V3))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK17)(1,(V3))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK14)(1,(V3))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK18)(2,(V3),(V4))                      /*  READ-REPLY      */;
	V5= VALUES(0);
	{int V7;                                  /*  SIZE            */
	V7= fix(((V5))->in.in_slots[3]);
	{object V8;                               /*  %REPLY-BUFFER   */
	object V9;                                /*  %BUFFER         */
	{int V10;                                 /*  BUFFER-BOFFSET  */
	object V11;                               /*  BUFFER-BBUF     */
	V10= 0;
	V11= ((V5))->in.in_slots[1];
	{int V12= (V7)-(32);
	V6=(*LK27)(5,(V11),MAKE_FIXNUM(V12),MAKE_FIXNUM((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(8))))),(V2),MAKE_FIXNUM(32))/*  READ-SEQUENCE-STRING*/;}
	}
	}
	}
	}
	frs_pop();
	MV_SAVE(V6);
	if(((V5))==Cnil){
	goto L612;}
	(*LK23)(1,(V5))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L612:
	if(((V4))==Cnil){
	goto L611;}
	(*LK24)(2,(V3),(V4))                      /*  STOP-PENDING-COMMAND*/;
L611:
	MV_RESTORE(V6);
	if (unwinding) unwind(nlj_fr,nlj_tag,V6+1);
	else {
	RETURN(V6);}}
	}
	}
}
/*	function definition for SET-FONT-PATH                         */
static L29(int narg, object V1, object V2)
{ VT31 VLEX31 CLSR31
TTL:
	{volatile int V3;                         /*  PATH-LENGTH     */
	volatile object V4;                       /*  REQUEST-LENGTH  */
	V3= length((V2));
	V4= MAKE_FIXNUM(8);
	{volatile object V5;
	volatile int V6;                          /*  I               */
	V5= MAKE_FIXNUM(V3);
	V6= 0;
L623:
	if(!(number_compare(MAKE_FIXNUM(V6),(V5))>=0)){
	goto L624;}
	goto L619;
L624:
	{register object V8;                      /*  STRING          */
	V8= coerce_to_string(elt((V2),V6));
	V4= number_plus((V4),one_plus(MAKE_FIXNUM(((V8))->v.v_fillp)));
	}
	V6= (V6)+1;
	goto L623;
	}
L619:
	{volatile object V5;                      /*  .DISPLAY.       */
	V5= (V1);
	if((((V5))->in.in_slots[10])==Cnil){
	goto L633;}
	(*LK0)(3,VV[45],VV[42],(V5))              /*  X-ERROR         */;
L633:
	{volatile object V6;                      /*  %BUFFER         */
	V6= (V5);
	if(!(((fix(((V6))->in.in_slots[6]))+((fix((V4)))+(160)))>=(fix(((V6))->in.in_slots[2])))){
	goto L637;}
	(*LK9)(1,(V6))                            /*  BUFFER-FLUSH    */;
L637:
	{volatile int V7;                         /*  BUFFER-BOFFSET  */
	volatile object V8;                       /*  BUFFER-BBUF     */
	V7= fix(((V6))->in.in_slots[6]);
	V8= ((V6))->in.in_slots[7];
	((V5))->in.in_slots[4]= MAKE_FIXNUM(V7);
	(((V8))->ust.ust_self[(V7)+(0)]=(51));
	{object V9;                               /*  .VALUE.         */
	Lceiling(2,(V4),MAKE_FIXNUM(4))           /*  CEILING         */;
	V9= VALUES(0);
	VALUES(0) = MAKE_FIXNUM(((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(2))))=fix((V9))));
	if(VALUES(0)==Cnil)goto L648;
	goto L646;
L648:
	(*LK11)(2,(V9),VV[73])                    /*  X-TYPE-ERROR    */;
	}
L646:
	(*LK10)(2,MAKE_FIXNUM(V3),VV[47])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L652;}
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(4))))=V3);
	goto L650;
L652:
	(*LK11)(2,MAKE_FIXNUM(V3),VV[47])         /*  X-TYPE-ERROR    */;
L650:
	{int V9;                                  /*  .VALUE.         */
	V7= (V7)+(8);
	V9= V7;
	}
	{volatile object V9;                      /*  .VALUE.         */
	{volatile object V10;
	volatile int V11;                         /*  I               */
	V10= MAKE_FIXNUM(V3);
	V11= 0;
L663:
	if(!(number_compare(MAKE_FIXNUM(V11),(V10))>=0)){
	goto L664;}
	V9= Cnil;
	goto L659;
L664:
	{register object V13;                     /*  STRING          */
	register int V14;                         /*  LEN             */
	V13= coerce_to_string(elt((V2),V11));
	V14= ((V13))->v.v_fillp;
	(((V8))->ust.ust_self[(V7)+(0)]=(V14));
	(*LK12)(5,(V6),MAKE_FIXNUM((V7)+(1)),(V13),MAKE_FIXNUM(0),MAKE_FIXNUM(((V13))->v.v_fillp))/*  WRITE-SEQUENCE-CHAR*/;
	V7= fix(number_plus(MAKE_FIXNUM(V7),one_plus(MAKE_FIXNUM(V14))));
	}
	V11= (V11)+1;
	goto L663;
	}
L659:
	}
	{int V9;                                  /*  .VALUE.         */
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V7)+(3)) & (-4)));
	V9= (((V7)+(3)) & (-4));
	}
	(*LK13)(1,(V5))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK14)(1,(V5))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	}
	VALUES(0) = (V2);
	RETURN(1);
}
static LKF30(int narg, ...) {TRAMPOLINK(VV[145],&LK30);}
static LKF29(int narg, ...) {TRAMPOLINK(VV[144],&LK29);}
static LKF28(int narg, ...) {TRAMPOLINK(VV[143],&LK28);}
static LKF27(int narg, ...) {TRAMPOLINK(VV[141],&LK27);}
static LKF26(int narg, ...) {TRAMPOLINK(VV[137],&LK26);}
static LKF25(int narg, ...) {TRAMPOLINK(VV[135],&LK25);}
static LKF24(int narg, ...) {TRAMPOLINK(VV[134],&LK24);}
static LKF23(int narg, ...) {TRAMPOLINK(VV[133],&LK23);}
static LKF22(int narg, ...) {TRAMPOLINK(VV[132],&LK22);}
static LKF21(int narg, ...) {TRAMPOLINK(VV[131],&LK21);}
static LKF20(int narg, ...) {TRAMPOLINK(VV[130],&LK20);}
static LKF19(int narg, ...) {TRAMPOLINK(VV[25],&LK19);}
static LKF18(int narg, ...) {TRAMPOLINK(VV[129],&LK18);}
static LKF17(int narg, ...) {TRAMPOLINK(VV[128],&LK17);}
static LKF16(int narg, ...) {TRAMPOLINK(VV[127],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[126],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[122],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[121],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[120],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[119],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[118],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[117],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[116],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[115],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[114],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[113],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[112],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[111],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[110],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[109],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[108],&LK0);}
