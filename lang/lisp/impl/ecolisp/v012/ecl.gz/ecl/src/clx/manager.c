
#include "manager.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	MF0(VV[6],L1);
	(void)putprop(VV[6],VV[Vdeb6],VV[150]);
	putprop(VV[6],VV[7],VV[8]);
	remprop(VV[6],VV[9]);
	remprop(VV[6],VV[10]);
	putprop(VV[6],Cnil,VV[11]);
	MF0(VV[151],L2);
	(void)putprop(VV[151],VV[Vdeb151],VV[150]);
	MF0(VV[13],L3);
	(void)putprop(VV[13],VV[Vdeb13],VV[150]);
	putprop(VV[13],VV[14],VV[8]);
	remprop(VV[13],VV[9]);
	remprop(VV[13],VV[10]);
	putprop(VV[13],Cnil,VV[11]);
	MF0(VV[16],L4);
	(void)putprop(VV[16],VV[Vdeb16],VV[150]);
	putprop(VV[16],VV[17],VV[8]);
	remprop(VV[16],VV[9]);
	remprop(VV[16],VV[10]);
	putprop(VV[16],Cnil,VV[11]);
	MF0(VV[152],L5);
	(void)putprop(VV[152],VV[Vdeb152],VV[150]);
	MF0(VV[153],L6);
	(void)putprop(VV[153],VV[Vdeb153],VV[150]);
	MF0(VV[25],L7);
	(void)putprop(VV[25],VV[Vdeb25],VV[150]);
	putprop(VV[25],VV[26],VV[9]);
	remprop(VV[25],VV[8]);
	remprop(VV[25],VV[10]);
	putprop(VV[25],Cnil,VV[11]);
	MF0(VV[26],L8);
	(void)putprop(VV[26],VV[Vdeb26],VV[150]);
	funcall(2,VV[154]->s.s_gfdef,VV[27])      /*  FIND-CLASS      */;
	funcall(9,VV[155]->s.s_gfdef,VALUES(0),VV[28],VV[29],VV[30],Cnil,VV[31],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[154]->s.s_gfdef,VV[28])      /*  FIND-CLASS      */;
	funcall(13,VV[156]->s.s_gfdef,VV[28],VV[32],Cnil,Cnil,VV[33],VV[34],VV[35],Cnil,Cnil,VV[36],MAKE_FIXNUM(9),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[157],L10,9,L10keys);
	(void)putprop(VV[157],VV[Vdeb157],VV[150]);
	funcall(5,VV[158]->s.s_gfdef,VV[28],Cnil,Cnil,Cnil)/*  MAKE-PREDICATE*/;
	siLfset(2,VV[37],VALUES(0))               /*  FSET            */;
	MF0(VV[28],L11);
	(void)putprop(VV[28],VV[Vdeb28],VV[150]);
	putprop(VV[28],VV[41],VV[9]);
	remprop(VV[28],VV[8]);
	remprop(VV[28],VV[10]);
	putprop(VV[28],Cnil,VV[11]);
	MF0(VV[41],L12);
	(void)putprop(VV[41],VV[Vdeb41],VV[150]);
	MF0(VV[159],L13);
	(void)putprop(VV[159],VV[Vdeb159],VV[150]);
	MF0(VV[160],L14);
	(void)putprop(VV[160],VV[Vdeb160],VV[150]);
	funcall(2,VV[154]->s.s_gfdef,VV[27])      /*  FIND-CLASS      */;
	funcall(9,VV[155]->s.s_gfdef,VALUES(0),VV[52],VV[53],VV[54],Cnil,VV[55],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[154]->s.s_gfdef,VV[52])      /*  FIND-CLASS      */;
	funcall(13,VV[156]->s.s_gfdef,VV[52],VV[56],Cnil,Cnil,VV[57],VV[58],VV[59],Cnil,Cnil,VV[60],MAKE_FIXNUM(19),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[161],L15,19,L15keys);
	(void)putprop(VV[161],VV[Vdeb161],VV[150]);
	funcall(5,VV[158]->s.s_gfdef,VV[52],Cnil,Cnil,Cnil)/*  MAKE-PREDICATE*/;
	siLfset(2,VV[61],VALUES(0))               /*  FSET            */;
	MF0(VV[64],L16);
	(void)putprop(VV[64],VV[Vdeb64],VV[150]);
	putprop(VV[64],VV[65],VV[9]);
	remprop(VV[64],VV[8]);
	remprop(VV[64],VV[10]);
	putprop(VV[64],Cnil,VV[11]);
	MF0(VV[65],L17);
	(void)putprop(VV[65],VV[Vdeb65],VV[150]);
	MF0(VV[67],L18);
	(void)putprop(VV[67],VV[Vdeb67],VV[150]);
	putprop(VV[67],VV[68],VV[9]);
	remprop(VV[67],VV[8]);
	remprop(VV[67],VV[10]);
	putprop(VV[67],Cnil,VV[11]);
	MF0(VV[68],L19);
	(void)putprop(VV[68],VV[Vdeb68],VV[150]);
	MF0(VV[162],L20);
	(void)putprop(VV[162],VV[Vdeb162],VV[150]);
	MF0(VV[163],L21);
	(void)putprop(VV[163],VV[Vdeb163],VV[150]);
	MF0(VV[79],L22);
	(void)putprop(VV[79],VV[Vdeb79],VV[150]);
	putprop(VV[79],VV[80],VV[9]);
	remprop(VV[79],VV[8]);
	remprop(VV[79],VV[10]);
	putprop(VV[79],Cnil,VV[11]);
	MF0(VV[80],L23);
	(void)putprop(VV[80],VV[Vdeb80],VV[150]);
	MF0(VV[84],L24);
	(void)putprop(VV[84],VV[Vdeb84],VV[150]);
	putprop(VV[84],VV[85],VV[9]);
	remprop(VV[84],VV[8]);
	remprop(VV[84],VV[10]);
	putprop(VV[84],Cnil,VV[11]);
	MF0(VV[85],L26);
	(void)putprop(VV[85],VV[Vdeb85],VV[150]);
	MF0(VV[88],L28);
	(void)putprop(VV[88],VV[Vdeb88],VV[150]);
	putprop(VV[88],VV[89],VV[9]);
	remprop(VV[88],VV[8]);
	remprop(VV[88],VV[10]);
	putprop(VV[88],Cnil,VV[11]);
	MF0(VV[89],L30);
	(void)putprop(VV[89],VV[Vdeb89],VV[150]);
	MF0(VV[91],L31);
	(void)putprop(VV[91],VV[Vdeb91],VV[150]);
	putprop(VV[91],VV[92],VV[9]);
	remprop(VV[91],VV[8]);
	remprop(VV[91],VV[10]);
	putprop(VV[91],Cnil,VV[11]);
	MF0(VV[92],L32);
	(void)putprop(VV[92],VV[Vdeb92],VV[150]);
	MF0key(VV[164],L33,36,L33keys);
	(void)putprop(VV[164],VV[Vdeb164],VV[150]);
	MF0(VV[165],L34);
	(void)putprop(VV[165],VV[Vdeb165],VV[150]);
	MF0(VV[166],L35);
	(void)putprop(VV[166],VV[Vdeb166],VV[150]);
	MF0(VV[167],L36);
	(void)putprop(VV[167],VV[Vdeb167],VV[150]);
	funcall(2,VV[154]->s.s_gfdef,VV[27])      /*  FIND-CLASS      */;
	funcall(9,VV[155]->s.s_gfdef,VALUES(0),VV[105],VV[106],VV[107],Cnil,VV[108],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[154]->s.s_gfdef,VV[105])     /*  FIND-CLASS      */;
	funcall(13,VV[156]->s.s_gfdef,VV[105],VV[109],Cnil,Cnil,VV[110],VV[111],Cnil,Cnil,Cnil,VV[112],MAKE_FIXNUM(6),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[168],L37,6,L37keys);
	(void)putprop(VV[168],VV[Vdeb168],VV[150]);
	MF0(VV[124],L38);
	(void)putprop(VV[124],VV[Vdeb124],VV[150]);
	putprop(VV[124],VV[125],VV[9]);
	remprop(VV[124],VV[8]);
	remprop(VV[124],VV[10]);
	putprop(VV[124],Cnil,VV[11]);
	MF0(VV[125],L39);
	(void)putprop(VV[125],VV[Vdeb125],VV[150]);
	MF0(VV[169],L40);
	(void)putprop(VV[169],VV[Vdeb169],VV[150]);
	MF0(VV[170],L41);
	(void)putprop(VV[170],VV[Vdeb170],VV[150]);
	MF0key(VV[142],L42,6,L42keys);
	(void)putprop(VV[142],VV[Vdeb142],VV[150]);
	VV[171] = make_cfun(LC43,Cnil,&Cblock);
	VALUES(0) = VV[171];
	putprop(VV[142],VALUES(0),VV[10]);
	remprop(VV[142],VV[8]);
	remprop(VV[142],VV[9]);
	putprop(VV[142],Cnil,VV[11]);
	MF0key(VV[143],L44,6,L44keys);
	(void)putprop(VV[143],VV[Vdeb143],VV[150]);
	MF0(VV[172],L45);
	(void)putprop(VV[172],VV[Vdeb172],VV[150]);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	local function CLOSURE                                        */
static LC43(int narg, object V1, object V2, ...)
{ VT3 VLEX3 CLSR3
	{object V3;
	va_list args; va_start(args, V2);
	narg -=2;
	V3=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object p=V3;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{volatile object V4;                      /*  OPTIONS         */
	volatile object V5;                       /*  OPTION          */
	volatile object V6;                       /*  STORE           */
	volatile object V7;                       /*  DTEMP           */
	volatile object V8;                       /*  TEMPS           */
	volatile object V9;                       /*  VALUES          */
	Lcopy_list(1,(V3))                        /*  COPY-LIST       */;
	V4= VALUES(0);
	V5= (V4);
	Lgensym(0)                                /*  GENSYM          */;
	V6= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V7= VALUES(0);
	V8= CONS((V7),Cnil);
	V9= CONS((V2),Cnil);
L93:
	if(!((V5)==Cnil)){
	goto L94;}
	{object V11= nreverse((V8));
	{object V12= nreverse((V9));
	{object V13= CONS((V6),Cnil);
	{object V14= listA(4,VV[143],(V6),(V7),(V4));
	VALUES(4) = CONS(VV[142],(V4));
	VALUES(3) = (V14);
	VALUES(2) = (V13);
	VALUES(1) = (V12);
	VALUES(0) = (V11);
	RETURN(5);}}}}
L94:
	if((memql(CAR((V5)),VV[144]))!=Cnil){
	goto L97;}
	Lerror(2,VV[145],CAR((V5)))               /*  ERROR           */;
L97:
	{register object V15;                     /*  X               */
	Lgensym(0)                                /*  GENSYM          */;
	V15= VALUES(0);
	V8= CONS((V15),(V8));
	V9= CONS(CADR((V5)),(V9));
	{object V16;
	register object V17;
	V16= (V5);
	V17= (V15);
	CAR(CDR((V16))) = (V17);
	}
	}
	V5= CDDR((V5));
	goto L93;
	}
	}
}
/*	function definition for WM-NAME                               */
static L1(int narg, object V1)
{ VT4 VLEX4 CLSR4
TTL:
	VALUES(0) = (VV[173]->s.s_gfdef);
	RETURN((*LK0)(8,(V1),VV[0],VV[1],VV[2],VV[3],VV[4],VV[5],VALUES(0))/*  GET-PROPERTY*/);
}
/*	function definition for SET-STRING-PROPERTY                   */
static L2(int narg, object V1, object V2, object V3)
{ VT5 VLEX5 CLSR5
TTL:
	{object V4= coerce_to_string((V3));
	VALUES(0) = (VV[176]->s.s_gfdef);
	(*LK1)(7,(V1),(V2),(V4),VV[2],MAKE_FIXNUM(8),VV[5],VALUES(0))/*  CHANGE-PROPERTY*/;}
	VALUES(0) = (V3);
	RETURN(1);
}
/*	function definition for WM-ICON-NAME                          */
static L3(int narg, object V1)
{ VT6 VLEX6 CLSR6
TTL:
	VALUES(0) = (VV[173]->s.s_gfdef);
	RETURN((*LK0)(8,(V1),VV[12],VV[1],VV[2],VV[3],VV[4],VV[5],VALUES(0))/*  GET-PROPERTY*/);
}
/*	function definition for WM-CLIENT-MACHINE                     */
static L4(int narg, object V1)
{ VT7 VLEX7 CLSR7
TTL:
	VALUES(0) = (VV[173]->s.s_gfdef);
	RETURN((*LK0)(8,(V1),VV[15],VV[1],VV[2],VV[3],VV[4],VV[5],VALUES(0))/*  GET-PROPERTY*/);
}
/*	function definition for GET-WM-CLASS                          */
static L5(int narg, object V1)
{ VT8 VLEX8 CLSR8
TTL:
	{register object V2;                      /*  VALUE           */
	VALUES(0) = (VV[173]->s.s_gfdef);
	(*LK0)(8,(V1),VV[18],VV[1],VV[2],VV[3],VV[4],VV[5],VALUES(0))/*  GET-PROPERTY*/;
	V2= VALUES(0);
	if(((V2))==Cnil){
	goto L120;}
	{object V3;                               /*  NAME-LEN        */
	object V4;                                /*  NAME            */
	object V5;                                /*  CLASS           */
	(*LK2)(2,code_char('\0'),(V2))            /*  POSITION        */;
	V3= VALUES(0);
	Lsubseq(3,(V2),MAKE_FIXNUM(0),(V3))       /*  SUBSEQ          */;
	V4= VALUES(0);
	{object V6= one_plus((V3));
	Lsubseq(3,(V2),(V6),one_minus(MAKE_FIXNUM(length((V2)))))/*  SUBSEQ*/;
	V5= VALUES(0);}
	if((length((V4)))>0){
	goto L126;}
	T0= Cnil;
	goto L125;
L126:
	T0= (V4);
L125:
	if((length((V5)))>0){
	goto L129;}
	VALUES(0) = Cnil;
	goto L128;
L129:
	VALUES(0) = (V5);
L128:
	VALUES(1) = VALUES(0);
	VALUES(0) = T0;
	RETURN(2);
	}
L120:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-WM-CLASS                          */
static L6(int narg, object V1, object V2, object V3)
{ VT9 VLEX9 CLSR9
TTL:
	if((V2)!=Cnil){
	VALUES(0) = (V2);
	goto L132;}
	VALUES(0) = VV[19];
L132:
	{object V4= coerce_to_string(VALUES(0));
	if((V3)!=Cnil){
	VALUES(0) = (V3);
	goto L133;}
	VALUES(0) = VV[21];
L133:
	(*LK3)(5,VV[4],(V4),VV[20],coerce_to_string(VALUES(0)),VV[22])/*  CONCATENATE*/;
	L2(3,(V1),VV[18],VALUES(0))               /*  SET-STRING-PROPERTY*/;}
	RETURN(0);
}
/*	function definition for WM-COMMAND                            */
static L7(int narg, object V1)
{ VT10 VLEX10 CLSR10
TTL:
	{volatile object V2;                      /*  COMMAND-STRING  */
	volatile object V3;                       /*  COMMAND         */
	volatile object V4;                       /*  START           */
	volatile object V5;                       /*  END             */
	volatile int V6;                          /*  LEN             */
	VALUES(0) = (VV[173]->s.s_gfdef);
	(*LK0)(8,(V1),VV[23],VV[1],VV[2],VV[3],VV[4],VV[5],VALUES(0))/*  GET-PROPERTY*/;
	V2= VALUES(0);
	V3= Cnil;
	V4= MAKE_FIXNUM(0);
	V5= MAKE_FIXNUM(0);
	V6= length((V2));
L142:
	if(!(number_compare((V4),MAKE_FIXNUM(V6))>=0)){
	goto L143;}
	VALUES(0) = nreverse((V3));
	RETURN(1);
L143:
	(*LK2)(4,code_char('\0'),(V2),VV[24],(V4))/*  POSITION        */;
	V5= VALUES(0);
	Lsubseq(3,(V2),(V4),(V5))                 /*  SUBSEQ          */;
	V3= CONS(VALUES(0),(V3));
	V4= one_plus((V5));
	goto L142;
	}
}
/*	function definition for SET-WM-COMMAND                        */
static L8(int narg, object V1, object V2)
{ VT11 VLEX11 CLSR11
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(V2,env0));            /*  COMMAND         */
	{volatile object V3;object env1 = env0;
	Lmake_string_output_stream(0)             /*  MAKE-STRING-OUTPUT-STREAM*/;
	V3= VALUES(0);
	CLV1=&CAR(env1=CONS(V3,env1));            /*  STREAM          */
	{ object V4;
	V4= make_cclosure(LC9,env1,&Cblock);
	(*LK4)(1,(V4))                            /*  WITH-STANDARD-IO-SYNTAX-FUNCTION*/;
	}
	Lget_output_stream_string(1,*CLV1)        /*  GET-OUTPUT-STREAM-STRING*/;
	}
	L2(3,(V1),VV[23],VALUES(0))               /*  SET-STRING-PROPERTY*/;
	VALUES(0) = *CLV0;
	RETURN(1);
}
/*	closure .WITH-STANDARD-IO-SYNTAX-BODY.                        */
static LC9(int narg, object env0)
{ VT12 VLEX12 CLSR12
	narg--;
	{object scan=env0;
	CLV1= &CAR(scan);                         /*  STREAM          */ scan=CDR(scan);
	CLV0= &CAR(scan);                         /*  COMMAND         */}
TTL:
	{volatile object V1;
	volatile object V2;                       /*  C               */
	V1= *CLV0;
	V2= Cnil;
L161:
	if(!((V1)==Cnil)){
	goto L162;}
	VALUES(0) = Cnil;
	RETURN(1);
L162:
	V2= CAR((V1));
	prin1((V2),*CLV1);
	Lwrite_char(2,code_char('\0'),*CLV1)      /*  WRITE-CHAR      */;
	V1= CDR((V1));
	goto L161;
	}
}
/*	function definition for MAKE-WM-HINTS                         */
static L10(int narg, ...)
{ VT13 VLEX13 CLSR13
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[18];
	parse_key(narg,args,9,L10keys,keyvars,OBJNULL,FALSE);
	V1= keyvars[0];
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	V7= keyvars[6];
	V8= keyvars[7];
	if(keyvars[17]==Cnil){
	V9= MAKE_FIXNUM(0);
	}else{
	V9= keyvars[8];}
	}
	(*LK5)(1,VV[28])                          /*  FIND-CLASS      */;
	RETURN(siLmake_structure(10,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8),(V9))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for WM-HINTS                              */
static L11(int narg, object V1)
{ VT14 VLEX14 CLSR14
TTL:
	{object V2;                               /*  PROP            */
	(*LK0)(6,(V1),VV[38],VV[1],VV[38],VV[3],VV[39])/*  GET-PROPERTY*/;
	V2= VALUES(0);
	if(((V2))==Cnil){
	goto L176;}
	RETURN(L13(2,(V2),((V1))->in.in_slots[1]) /*  DECODE-WM-HINTS */);
L176:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-WM-HINTS                          */
static L12(int narg, object V1, object V2)
{ VT15 VLEX15 CLSR15
TTL:
	L14(1,(V2))                               /*  ENCODE-WM-HINTS */;
	(*LK1)(5,(V1),VV[38],VALUES(0),VV[38],MAKE_FIXNUM(32))/*  CHANGE-PROPERTY*/;
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for DECODE-WM-HINTS                       */
static L13(int narg, object V1, object V2)
{ VT16 VLEX16 CLSR16
TTL:
	{int V3;                                  /*  INPUT-HINT      */
	int V4;                                   /*  STATE-HINT      */
	int V5;                                   /*  ICON-PIXMAP-HINT*/
	int V6;                                   /*  ICON-WINDOW-HINT*/
	int V7;                                   /*  ICON-POSITION-HINT*/
	int V8;                                   /*  ICON-MASK-HINT  */
	int V9;                                   /*  WINDOW-GROUP-HINT*/
	V3= 0;
	V4= 1;
	V5= 2;
	V6= 3;
	V7= 4;
	V8= 5;
	V9= 6;
	{register object V10;                     /*  FLAGS           */
	object V11;
	register object V12;                      /*  HINTS           */
	object V13;                               /*  %BUFFER         */
	V11= ((V1))->v.v_self[0];
	L10(0)                                    /*  MAKE-WM-HINTS   */;
	V12= VALUES(0);
	V10= V11;
	V13= (V2);
	((V12))->in.in_slots[8]= (V10);
	Llogbitp(2,MAKE_FIXNUM(V3),(V10))         /*  LOGBITP         */;
	if(VALUES(0)==Cnil){
	goto L190;}
	{int V14;
	V14= fix(((V1))->v.v_self[1]);
	if((V14)<(2)){
	goto L195;}
	VALUES(0) = Cnil;
	goto L193;
L195:
	VALUES(0) = (VV[42])->v.v_self[V14];
	}
L193:
	((V12))->in.in_slots[0]= VALUES(0);
L190:
	Llogbitp(2,MAKE_FIXNUM(V4),(V10))         /*  LOGBITP         */;
	if(VALUES(0)==Cnil){
	goto L197;}
	{int V14;
	V14= fix(((V1))->v.v_self[2]);
	if((V14)<(5)){
	goto L202;}
	VALUES(0) = Cnil;
	goto L200;
L202:
	VALUES(0) = (VV[43])->v.v_self[V14];
	}
L200:
	((V12))->in.in_slots[1]= VALUES(0);
L197:
	Llogbitp(2,MAKE_FIXNUM(V5),(V10))         /*  LOGBITP         */;
	if(VALUES(0)==Cnil){
	goto L204;}
	(*LK6)(2,(V13),((V1))->v.v_self[3])       /*  LOOKUP-PIXMAP   */;
	((V12))->in.in_slots[2]= VALUES(0);
L204:
	Llogbitp(2,MAKE_FIXNUM(V6),(V10))         /*  LOGBITP         */;
	if(VALUES(0)==Cnil){
	goto L208;}
	(*LK7)(2,(V13),((V1))->v.v_self[4])       /*  LOOKUP-WINDOW   */;
	((V12))->in.in_slots[3]= VALUES(0);
L208:
	Llogbitp(2,MAKE_FIXNUM(V7),(V10))         /*  LOGBITP         */;
	if(VALUES(0)==Cnil){
	goto L212;}
	((V12))->in.in_slots[4]= ((V1))->v.v_self[5];
	((V12))->in.in_slots[5]= ((V1))->v.v_self[6];
L212:
	Llogbitp(2,MAKE_FIXNUM(V8),(V10))         /*  LOGBITP         */;
	if(VALUES(0)==Cnil){
	goto L216;}
	(*LK6)(2,(V13),((V1))->v.v_self[7])       /*  LOOKUP-PIXMAP   */;
	((V12))->in.in_slots[6]= VALUES(0);
L216:
	Llogbitp(2,MAKE_FIXNUM(V9),(V10))         /*  LOGBITP         */;
	if(VALUES(0)==Cnil){
	goto L220;}
	if(!((((V1))->v.v_fillp)>(7))){
	goto L220;}
	((V12))->in.in_slots[7]= ((V1))->v.v_self[8];
L220:
	VALUES(0) = (V12);
	RETURN(1);
	}
	}
}
/*	function definition for ENCODE-WM-HINTS                       */
static L14(int narg, object V1)
{ VT17 VLEX17 CLSR17
TTL:
	{int V2;                                  /*  INPUT-HINT      */
	int V3;                                   /*  STATE-HINT      */
	int V4;                                   /*  ICON-PIXMAP-HINT*/
	int V5;                                   /*  ICON-WINDOW-HINT*/
	int V6;                                   /*  ICON-POSITION-HINT*/
	int V7;                                   /*  ICON-MASK-HINT  */
	int V8;                                   /*  WINDOW-GROUP-HINT*/
	int V9;                                   /*  MASK            */
	V2= 1;
	V3= 2;
	V4= 4;
	V5= 8;
	V6= 16;
	V7= 32;
	V8= 64;
	V9= 127;
	{register object V10;                     /*  VECTOR          */
	register int V11;                         /*  FLAGS           */
	(*LK8)(3,MAKE_FIXNUM(9),VV[44],MAKE_FIXNUM(0))/*  MAKE-ARRAY  */;
	V10= VALUES(0);
	V11= 0;
	if((((V1))->in.in_slots[0])==Cnil){
	goto L235;}
	V11= V2;
	{object V12;                              /*  .VALUE.         */
	V12= ((V1))->in.in_slots[0];
	{int V13;
	VALUES(0) = (VV[204]->s.s_gfdef);
	(*LK2)(4,(V12),VV[45],VV[46],VALUES(0))   /*  POSITION        */;
	V13= fix(VALUES(0));
	if(MAKE_FIXNUM(V13)==Cnil){
	VALUES(0) = Cnil;
	goto L243;}
	VALUES(0) = MAKE_FIXNUM(V13);
	}
L243:
	if(VALUES(0)==Cnil)goto L242;
	goto L240;
L242:
	(*LK9)(2,(V12),VV[47])                    /*  X-TYPE-ERROR    */;
	}
L240:
	((V10))->v.v_self[fix(MAKE_FIXNUM(1))]= VALUES(0);
L235:
	if((((V1))->in.in_slots[1])==Cnil){
	goto L246;}
	V11= ((V11) | (V3));
	{object V12;                              /*  .VALUE.         */
	V12= ((V1))->in.in_slots[1];
	{int V13;
	VALUES(0) = (VV[204]->s.s_gfdef);
	(*LK2)(4,(V12),VV[48],VV[46],VALUES(0))   /*  POSITION        */;
	V13= fix(VALUES(0));
	if(MAKE_FIXNUM(V13)==Cnil){
	VALUES(0) = Cnil;
	goto L254;}
	VALUES(0) = MAKE_FIXNUM(V13);
	}
L254:
	if(VALUES(0)==Cnil)goto L253;
	goto L251;
L253:
	(*LK9)(2,(V12),VV[49])                    /*  X-TYPE-ERROR    */;
	}
L251:
	((V10))->v.v_self[fix(MAKE_FIXNUM(2))]= VALUES(0);
L246:
	if((((V1))->in.in_slots[2])==Cnil){
	goto L257;}
	V11= ((V11) | (V4));
	{object V12;                              /*  .VALUE.         */
	V12= ((V1))->in.in_slots[2];
	(*LK10)(1,(V12))                          /*  PIXMAP-P        */;
	if(VALUES(0)==Cnil){
	goto L265;}
	VALUES(0) = ((V12))->in.in_slots[0];
	goto L262;
L265:
	(*LK9)(2,(V12),VV[50])                    /*  X-TYPE-ERROR    */;
	}
L262:
	((V10))->v.v_self[fix(MAKE_FIXNUM(3))]= VALUES(0);
L257:
	if((((V1))->in.in_slots[3])==Cnil){
	goto L267;}
	V11= ((V11) | (V5));
	{object V12;                              /*  .VALUE.         */
	V12= ((V1))->in.in_slots[3];
	(*LK11)(1,(V12))                          /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L275;}
	VALUES(0) = ((V12))->in.in_slots[0];
	goto L272;
L275:
	(*LK9)(2,(V12),VV[40])                    /*  X-TYPE-ERROR    */;
	}
L272:
	((V10))->v.v_self[fix(MAKE_FIXNUM(4))]= VALUES(0);
L267:
	if((((V1))->in.in_slots[4])==Cnil){
	goto L277;}
	if((((V1))->in.in_slots[5])==Cnil){
	goto L277;}
	V11= ((V11) | (V6));
	{object V12;                              /*  .VALUE.         */
	V12= ((V1))->in.in_slots[4];
	(*LK12)(2,(V12),VV[51])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L288;}
	VALUES(0) = (V12);
	goto L285;
L288:
	(*LK9)(2,(V12),VV[51])                    /*  X-TYPE-ERROR    */;
	}
L285:
	((V10))->v.v_self[fix(MAKE_FIXNUM(5))]= VALUES(0);
	{object V12;                              /*  .VALUE.         */
	V12= ((V1))->in.in_slots[5];
	(*LK12)(2,(V12),VV[51])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L293;}
	VALUES(0) = (V12);
	goto L290;
L293:
	(*LK9)(2,(V12),VV[51])                    /*  X-TYPE-ERROR    */;
	}
L290:
	((V10))->v.v_self[fix(MAKE_FIXNUM(6))]= VALUES(0);
L277:
	if((((V1))->in.in_slots[6])==Cnil){
	goto L295;}
	V11= ((V11) | (V7));
	{object V12;                              /*  .VALUE.         */
	V12= ((V1))->in.in_slots[6];
	(*LK10)(1,(V12))                          /*  PIXMAP-P        */;
	if(VALUES(0)==Cnil){
	goto L303;}
	VALUES(0) = ((V12))->in.in_slots[0];
	goto L300;
L303:
	(*LK9)(2,(V12),VV[50])                    /*  X-TYPE-ERROR    */;
	}
L300:
	((V10))->v.v_self[fix(MAKE_FIXNUM(7))]= VALUES(0);
L295:
	if((((V1))->in.in_slots[7])==Cnil){
	goto L305;}
	V11= ((V11) | (V8));
	((V10))->v.v_self[8]= ((V1))->in.in_slots[7];
L305:
	(*LK13)(2,((V1))->in.in_slots[8],MAKE_FIXNUM(V9))/*  LOGANDC2 */;
	Llogior(2,MAKE_FIXNUM(V11),VALUES(0))     /*  LOGIOR          */;
	((V10))->v.v_self[fix(MAKE_FIXNUM(0))]= VALUES(0);
	VALUES(0) = (V10);
	RETURN(1);
	}
	}
}
/*	function definition for MAKE-WM-SIZE-HINTS                    */
static L15(int narg, ...)
{ VT18 VLEX18 CLSR18
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	object V10;
	object V11;
	object V12;
	object V13;
	object V14;
	object V15;
	object V16;
	object V17;
	object V18;
	object V19;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[38];
	parse_key(narg,args,19,L15keys,keyvars,OBJNULL,FALSE);
	V1= keyvars[0];
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	V7= keyvars[6];
	V8= keyvars[7];
	V9= keyvars[8];
	V10= keyvars[9];
	V11= keyvars[10];
	V12= keyvars[11];
	V13= keyvars[12];
	V14= keyvars[13];
	V15= keyvars[14];
	V16= keyvars[15];
	V17= keyvars[16];
	V18= keyvars[17];
	V19= keyvars[18];
	}
	(*LK5)(1,VV[52])                          /*  FIND-CLASS      */;
	RETURN(siLmake_structure(20,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8),(V9),(V10),(V11),(V12),(V13),(V14),(V15),(V16),(V17),(V18),(V19))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for WM-NORMAL-HINTS                       */
static L16(int narg, object V1)
{ VT19 VLEX19 CLSR19
TTL:
	(*LK0)(6,(V1),VV[62],VV[1],VV[63],VV[3],VV[39])/*  GET-PROPERTY*/;
	RETURN(L20(1,VALUES(0))                   /*  DECODE-WM-SIZE-HINTS*/);
}
/*	function definition for SET-WM-NORMAL-HINTS                   */
static L17(int narg, object V1, object V2)
{ VT20 VLEX20 CLSR20
TTL:
	L21(1,(V2))                               /*  ENCODE-WM-SIZE-HINTS*/;
	(*LK1)(5,(V1),VV[62],VALUES(0),VV[63],MAKE_FIXNUM(32))/*  CHANGE-PROPERTY*/;
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for WM-ZOOM-HINTS                         */
static L18(int narg, object V1)
{ VT21 VLEX21 CLSR21
TTL:
	(*LK0)(6,(V1),VV[66],VV[1],VV[63],VV[3],VV[39])/*  GET-PROPERTY*/;
	RETURN(L20(1,VALUES(0))                   /*  DECODE-WM-SIZE-HINTS*/);
}
/*	function definition for SET-WM-ZOOM-HINTS                     */
static L19(int narg, object V1, object V2)
{ VT22 VLEX22 CLSR22
TTL:
	L21(1,(V2))                               /*  ENCODE-WM-SIZE-HINTS*/;
	(*LK1)(5,(V1),VV[66],VALUES(0),VV[63],MAKE_FIXNUM(32))/*  CHANGE-PROPERTY*/;
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for DECODE-WM-SIZE-HINTS                  */
static L20(int narg, object V1)
{ VT23 VLEX23 CLSR23
TTL:
	if(((V1))==Cnil){
	goto L321;}
	{register int V2;                         /*  FLAGS           */
	register object V3;                       /*  HINTS           */
	V2= fix(aref1((V1),0));
	L15(0)                                    /*  MAKE-WM-SIZE-HINTS*/;
	V3= VALUES(0);
	((V3))->in.in_slots[0]= ((V2 >> 0) & 1?Ct:Cnil);
	((V3))->in.in_slots[1]= ((V2 >> 1) & 1?Ct:Cnil);
	((V3))->in.in_slots[17]= ((V2 >> 2) & 1?Ct:Cnil);
	((V3))->in.in_slots[18]= ((V2 >> 3) & 1?Ct:Cnil);
	if(!((V2 >> 4) & 1)){
	goto L329;}
	((V3))->in.in_slots[6]= aref1((V1),5);
	((V3))->in.in_slots[7]= aref1((V1),6);
L329:
	if(!((V2 >> 5) & 1)){
	goto L333;}
	((V3))->in.in_slots[8]= aref1((V1),7);
	((V3))->in.in_slots[9]= aref1((V1),8);
L333:
	if(!((V2 >> 6) & 1)){
	goto L337;}
	((V3))->in.in_slots[10]= aref1((V1),9);
	((V3))->in.in_slots[11]= aref1((V1),10);
L337:
	if(!((V2 >> 7) & 1)){
	goto L341;}
	{object V4= aref1((V1),11);
	((V3))->in.in_slots[12]= number_divide((V4),aref1((V1),12));}
	{object V4= aref1((V1),13);
	((V3))->in.in_slots[13]= number_divide((V4),aref1((V1),14));}
L341:
	if(!((length((V1)))>(15))){
	goto L345;}
	if(!((V2 >> 8) & 1)){
	goto L348;}
	((V3))->in.in_slots[14]= aref1((V1),15);
	((V3))->in.in_slots[15]= aref1((V1),16);
L348:
	if(!((V2 >> 9) & 1)){
	goto L345;}
	{int V4;
	V4= fix(aref1((V1),17));
	if((V4)<(11)){
	goto L356;}
	VALUES(0) = Cnil;
	goto L354;
L356:
	VALUES(0) = (VV[69])->v.v_self[V4];
	}
L354:
	((V3))->in.in_slots[16]= VALUES(0);
L345:
	if((V2 >> 0) & 1){
	goto L359;}
	if(!((V2 >> 2) & 1)){
	goto L358;}
L359:
	((V3))->in.in_slots[2]= aref1((V1),1);
	((V3))->in.in_slots[3]= aref1((V1),2);
L358:
	if((V2 >> 1) & 1){
	goto L365;}
	if(!((V2 >> 3) & 1)){
	goto L364;}
L365:
	((V3))->in.in_slots[4]= aref1((V1),3);
	((V3))->in.in_slots[5]= aref1((V1),4);
L364:
	VALUES(0) = (V3);
	RETURN(1);
	}
L321:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for ENCODE-WM-SIZE-HINTS                  */
static L21(int narg, object V1)
{ VT24 VLEX24 CLSR24
TTL:
	{register object V2;                      /*  VECTOR          */
	register int V3;                          /*  FLAGS           */
	(*LK8)(3,MAKE_FIXNUM(18),VV[44],MAKE_FIXNUM(0))/*  MAKE-ARRAY */;
	V2= VALUES(0);
	V3= 0;
	if((((V1))->in.in_slots[0])==Cnil){
	goto L372;}
	{object V4;
	int V5;
	(*LK14)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(0))  /*  BYTE            */;
	V4= VALUES(0);
	V5= 1;
	{object V6;
	(*LK15)(3,MAKE_FIXNUM(V5),(V4),MAKE_FIXNUM(V3))/*  DPB        */;
	V6= VALUES(0);
	V3= fix((V6));
	}
	}
L372:
	if((((V1))->in.in_slots[1])==Cnil){
	goto L380;}
	{object V4;
	int V5;
	(*LK14)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(1))  /*  BYTE            */;
	V4= VALUES(0);
	V5= 1;
	{object V6;
	(*LK15)(3,MAKE_FIXNUM(V5),(V4),MAKE_FIXNUM(V3))/*  DPB        */;
	V6= VALUES(0);
	V3= fix((V6));
	}
	}
L380:
	if((((V1))->in.in_slots[17])==Cnil){
	goto L388;}
	{object V4;
	int V5;
	(*LK14)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(2))  /*  BYTE            */;
	V4= VALUES(0);
	V5= 1;
	{object V6;
	(*LK15)(3,MAKE_FIXNUM(V5),(V4),MAKE_FIXNUM(V3))/*  DPB        */;
	V6= VALUES(0);
	V3= fix((V6));
	}
	}
L388:
	if((((V1))->in.in_slots[18])==Cnil){
	goto L396;}
	{object V4;
	int V5;
	(*LK14)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(3))  /*  BYTE            */;
	V4= VALUES(0);
	V5= 1;
	{object V6;
	(*LK15)(3,MAKE_FIXNUM(V5),(V4),MAKE_FIXNUM(V3))/*  DPB        */;
	V6= VALUES(0);
	V3= fix((V6));
	}
	}
L396:
	if((((V1))->in.in_slots[6])==Cnil){
	goto L404;}
	if((((V1))->in.in_slots[7])==Cnil){
	goto L404;}
	{object V4;
	int V5;
	(*LK14)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(4))  /*  BYTE            */;
	V4= VALUES(0);
	V5= 1;
	{object V6;
	(*LK15)(3,MAKE_FIXNUM(V5),(V4),MAKE_FIXNUM(V3))/*  DPB        */;
	V6= VALUES(0);
	V3= fix((V6));
	}
	}
	((V2))->v.v_self[5]= ((V1))->in.in_slots[6];
	((V2))->v.v_self[6]= ((V1))->in.in_slots[7];
L404:
	if((((V1))->in.in_slots[8])==Cnil){
	goto L416;}
	if((((V1))->in.in_slots[9])==Cnil){
	goto L416;}
	{object V4;
	int V5;
	(*LK14)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(5))  /*  BYTE            */;
	V4= VALUES(0);
	V5= 1;
	{object V6;
	(*LK15)(3,MAKE_FIXNUM(V5),(V4),MAKE_FIXNUM(V3))/*  DPB        */;
	V6= VALUES(0);
	V3= fix((V6));
	}
	}
	((V2))->v.v_self[7]= ((V1))->in.in_slots[8];
	((V2))->v.v_self[8]= ((V1))->in.in_slots[9];
L416:
	if((((V1))->in.in_slots[10])==Cnil){
	goto L428;}
	if((((V1))->in.in_slots[11])==Cnil){
	goto L428;}
	{object V4;
	int V5;
	(*LK14)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(6))  /*  BYTE            */;
	V4= VALUES(0);
	V5= 1;
	{object V6;
	(*LK15)(3,MAKE_FIXNUM(V5),(V4),MAKE_FIXNUM(V3))/*  DPB        */;
	V6= VALUES(0);
	V3= fix((V6));
	}
	}
	((V2))->v.v_self[9]= ((V1))->in.in_slots[10];
	((V2))->v.v_self[10]= ((V1))->in.in_slots[11];
L428:
	{register object V4;                      /*  MIN-ASPECT      */
	register object V5;                       /*  MAX-ASPECT      */
	V4= ((V1))->in.in_slots[12];
	V5= ((V1))->in.in_slots[13];
	if(((V4))==Cnil){
	goto L440;}
	if(((V5))==Cnil){
	goto L440;}
	{object V6;
	int V7;
	(*LK14)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(7))  /*  BYTE            */;
	V6= VALUES(0);
	V7= 1;
	{object V8;
	(*LK15)(3,MAKE_FIXNUM(V7),(V6),MAKE_FIXNUM(V3))/*  DPB        */;
	V8= VALUES(0);
	V3= fix((V8));
	}
	}
	(*LK16)(1,(V4))                           /*  RATIONALIZE     */;
	V4= VALUES(0);
	(*LK16)(1,(V5))                           /*  RATIONALIZE     */;
	V5= VALUES(0);
	Lnumerator(1,(V4))                        /*  NUMERATOR       */;
	((V2))->v.v_self[fix(MAKE_FIXNUM(11))]= VALUES(0);
	Ldenominator(1,(V4))                      /*  DENOMINATOR     */;
	((V2))->v.v_self[fix(MAKE_FIXNUM(12))]= VALUES(0);
	Lnumerator(1,(V5))                        /*  NUMERATOR       */;
	((V2))->v.v_self[fix(MAKE_FIXNUM(13))]= VALUES(0);
	Ldenominator(1,(V5))                      /*  DENOMINATOR     */;
	((V2))->v.v_self[fix(MAKE_FIXNUM(14))]= VALUES(0);
	}
L440:
	if((((V1))->in.in_slots[14])==Cnil){
	goto L464;}
	if((((V1))->in.in_slots[15])==Cnil){
	goto L464;}
	{object V4;
	int V5;
	(*LK14)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(8))  /*  BYTE            */;
	V4= VALUES(0);
	V5= 1;
	{object V6;
	(*LK15)(3,MAKE_FIXNUM(V5),(V4),MAKE_FIXNUM(V3))/*  DPB        */;
	V6= VALUES(0);
	V3= fix((V6));
	}
	}
	((V2))->v.v_self[15]= ((V1))->in.in_slots[14];
	((V2))->v.v_self[16]= ((V1))->in.in_slots[15];
L464:
	if((((V1))->in.in_slots[16])==Cnil){
	goto L476;}
	{object V4;
	int V5;
	(*LK14)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(9))  /*  BYTE            */;
	V4= VALUES(0);
	V5= 1;
	{object V6;
	(*LK15)(3,MAKE_FIXNUM(V5),(V4),MAKE_FIXNUM(V3))/*  DPB        */;
	V6= VALUES(0);
	V3= fix((V6));
	}
	}
	{object V4;                               /*  .VALUE.         */
	V4= ((V1))->in.in_slots[16];
	VALUES(0) = (VV[204]->s.s_gfdef);
	(*LK2)(4,(V4),VV[70],VV[46],VALUES(0))    /*  POSITION        */;
	if(VALUES(0)==Cnil)goto L487;
	goto L485;
L487:
	(*LK9)(2,(V4),VV[71])                     /*  X-TYPE-ERROR    */;
	}
L485:
	((V2))->v.v_self[fix(MAKE_FIXNUM(17))]= VALUES(0);
L476:
	if((((V1))->in.in_slots[2])==Cnil){
	goto L490;}
	if((((V1))->in.in_slots[3])==Cnil){
	goto L490;}
	if((((V1))->in.in_slots[0])!=Cnil){
	goto L495;}
	{object V4;
	int V5;
	(*LK14)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(2))  /*  BYTE            */;
	V4= VALUES(0);
	V5= 1;
	{object V6;
	(*LK15)(3,MAKE_FIXNUM(V5),(V4),MAKE_FIXNUM(V3))/*  DPB        */;
	V6= VALUES(0);
	V3= fix((V6));
	}
	}
L495:
	((V2))->v.v_self[1]= ((V1))->in.in_slots[2];
	((V2))->v.v_self[2]= ((V1))->in.in_slots[3];
L490:
	if((((V1))->in.in_slots[4])==Cnil){
	goto L504;}
	if((((V1))->in.in_slots[5])==Cnil){
	goto L504;}
	if((((V1))->in.in_slots[1])!=Cnil){
	goto L509;}
	{object V4;
	int V5;
	(*LK14)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(3))  /*  BYTE            */;
	V4= VALUES(0);
	V5= 1;
	{object V6;
	(*LK15)(3,MAKE_FIXNUM(V5),(V4),MAKE_FIXNUM(V3))/*  DPB        */;
	V6= VALUES(0);
	V3= fix((V6));
	}
	}
L509:
	((V2))->v.v_self[3]= ((V1))->in.in_slots[4];
	((V2))->v.v_self[4]= ((V1))->in.in_slots[5];
L504:
	((V2))->v.v_self[0]= MAKE_FIXNUM(V3);
	VALUES(0) = (V2);
	RETURN(1);
	}
}
/*	function definition for ICON-SIZES                            */
static L22(int narg, object V1)
{ VT25 VLEX25 CLSR25
TTL:
	{register object V2;                      /*  VECTOR          */
	(*LK0)(6,(V1),VV[72],VV[1],VV[72],VV[3],VV[39])/*  GET-PROPERTY*/;
	V2= VALUES(0);
	if(((V2))==Cnil){
	goto L521;}
	{object V3= aref1((V2),0);
	{object V4= aref1((V2),1);
	{object V5= aref1((V2),2);
	{object V6= aref1((V2),3);
	{object V7= aref1((V2),4);
	RETURN(L15(12,VV[73],(V3),VV[74],(V4),VV[75],(V5),VV[76],(V6),VV[77],(V7),VV[78],aref1((V2),5))/*  MAKE-WM-SIZE-HINTS*/);}}}}}
L521:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-ICON-SIZES                        */
static L23(int narg, object V1, object V2)
{ VT26 VLEX26 CLSR26
TTL:
	{object V3;                               /*  VECTOR          */
	(*LK17)(6,((V2))->in.in_slots[6],((V2))->in.in_slots[7],((V2))->in.in_slots[8],((V2))->in.in_slots[9],((V2))->in.in_slots[10],((V2))->in.in_slots[11])/*  VECTOR*/;
	V3= VALUES(0);
	(*LK1)(5,(V1),VV[72],(V3),VV[72],MAKE_FIXNUM(32))/*  CHANGE-PROPERTY*/;
	VALUES(0) = (V2);
	RETURN(1);
	}
}
/*	function definition for WM-PROTOCOLS                          */
static L24(int narg, object V1)
{ VT27 VLEX27 CLSR27
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(V1,env0));            /*  WINDOW          */
	T0= make_cclosure(LC25,env0,&Cblock);
	(*LK0)(4,*CLV0,VV[82],VV[1],VV[83])       /*  GET-PROPERTY    */;
	RETURN((*LK18)(3,VV[81],T0,VALUES(0))     /*  MAP             */);
}
/*	closure CLOSURE                                               */
static LC25(int narg, object env0, object V1)
{ VT28 VLEX28 CLSR28
	narg--;
	{object scan=env0;
	CLV0= &CAR(scan);                         /*  WINDOW          */}
	RETURN((*LK19)(2,(*CLV0)->in.in_slots[1],(V1))/*  ATOM-NAME   */);
}
/*	function definition for SET-WM-PROTOCOLS                      */
static L26(int narg, object V1, object V2)
{ VT29 VLEX29 CLSR29
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(V1,env0));            /*  WINDOW          */
	VALUES(0) = make_cclosure(LC27,env0,&Cblock);
	(*LK18)(3,VV[81],VALUES(0),(V2))          /*  MAP             */;
	(*LK1)(5,*CLV0,VV[82],VALUES(0),VV[83],MAKE_FIXNUM(32))/*  CHANGE-PROPERTY*/;
	VALUES(0) = (V2);
	RETURN(1);
}
/*	closure CLOSURE                                               */
static LC27(int narg, object env0, object V1)
{ VT30 VLEX30 CLSR30
	narg--;
	{object scan=env0;
	CLV0= &CAR(scan);                         /*  WINDOW          */}
	RETURN((*LK20)(2,(*CLV0)->in.in_slots[1],(V1))/*  INTERN-ATOM */);
}
/*	function definition for WM-COLORMAP-WINDOWS                   */
static L28(int narg, object V1)
{ VT31 VLEX31 CLSR31
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(V1,env0));            /*  WINDOW          */
	VALUES(0) = make_cclosure(LC29,env0,&Cblock);
	RETURN((*LK0)(6,*CLV0,VV[86],VV[1],VV[87],VV[5],VALUES(0))/*  GET-PROPERTY*/);
}
/*	closure CLOSURE                                               */
static LC29(int narg, object env0, object V1)
{ VT32 VLEX32 CLSR32
	narg--;
	{object scan=env0;
	CLV0= &CAR(scan);                         /*  WINDOW          */}
	RETURN((*LK7)(2,(*CLV0)->in.in_slots[1],(V1))/*  LOOKUP-WINDOW*/);
}
/*	function definition for SET-WM-COLORMAP-WINDOWS               */
static L30(int narg, object V1, object V2)
{ VT33 VLEX33 CLSR33
TTL:
	VALUES(0) = (VV[242]->s.s_gfdef);
	(*LK1)(7,(V1),VV[86],(V2),VV[87],MAKE_FIXNUM(32),VV[5],VALUES(0))/*  CHANGE-PROPERTY*/;
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for TRANSIENT-FOR                         */
static L31(int narg, object V1)
{ VT34 VLEX34 CLSR34
TTL:
	{object V2;                               /*  PROP            */
	(*LK0)(6,(V1),VV[90],VV[1],VV[87],VV[3],VV[81])/*  GET-PROPERTY*/;
	V2= VALUES(0);
	if((V2)==Cnil){
	VALUES(0) = Cnil;
	RETURN(1);}
	RETURN((*LK7)(2,((V1))->in.in_slots[1],CAR((V2)))/*  LOOKUP-WINDOW*/);
	}
}
/*	function definition for SET-TRANSIENT-FOR                     */
static L32(int narg, object V1, object V2)
{ VT35 VLEX35 CLSR35
TTL:
	(*LK1)(5,(V1),VV[90],CONS(((V2))->in.in_slots[0],Cnil),VV[87],MAKE_FIXNUM(32))/*  CHANGE-PROPERTY*/;
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for SET-WM-PROPERTIES                     */
static L33(int narg, object V1, ...)
{ VT36 VLEX36 CLSR36
	{volatile object V2;
	volatile object V3;
	volatile object V4;
	volatile object V5;
	volatile object V6;
	volatile object V7;
	volatile object V8;
	volatile object V9;
	volatile object V10;
	volatile object V11;
	volatile object V12;
	volatile object V13;
	volatile object V14;
	volatile object V15;
	volatile object V16;
	volatile object V17;
	volatile object V18;
	volatile object V19;
	volatile object V20;
	volatile object V21;
	volatile object V22;
	volatile object V23;
	volatile object V24;
	volatile object V25;
	volatile object V26;
	volatile object V27;
	volatile object V28;
	volatile object V29;
	volatile object V30;
	volatile object V31;
	volatile object V32;
	volatile object V33;
	volatile object V34;
	volatile object V35;
	volatile object V36;
	volatile object V37;
	volatile object V38;
	volatile object V39;
	volatile object V40;
	volatile object V41;
	volatile object V42;
	va_list args; va_start(args, V1);
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ int n=narg; object p=V2;
	 for(;n-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{ object keyvars[72];
	va_start(args,V1);
	parse_key(narg,args,36,L33keys,keyvars,V2,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	V7= keyvars[4];
	V8= keyvars[5];
	V9= keyvars[6];
	V10= keyvars[7];
	V11= keyvars[8];
	V12= keyvars[9];
	V13= keyvars[45];
	V14= keyvars[10];
	V15= keyvars[46];
	V16= keyvars[11];
	V17= keyvars[47];
	V18= keyvars[12];
	V19= keyvars[48];
	V20= keyvars[13];
	V21= keyvars[14];
	V22= keyvars[15];
	V23= keyvars[16];
	V24= keyvars[17];
	V25= keyvars[18];
	V26= keyvars[19];
	V27= keyvars[20];
	V28= keyvars[21];
	V29= keyvars[22];
	V30= keyvars[23];
	V31= keyvars[24];
	V32= keyvars[25];
	V33= keyvars[26];
	V34= keyvars[27];
	V35= keyvars[28];
	V36= keyvars[29];
	V37= keyvars[30];
	V38= keyvars[31];
	V39= keyvars[32];
	V40= keyvars[33];
	V41= keyvars[34];
	V42= keyvars[35];
	}
	if(((V3))==Cnil){
	goto L535;}
	L2(3,(V1),VV[0],(V3))                     /*  SET-STRING-PROPERTY*/;
L535:
	if(((V4))==Cnil){
	goto L538;}
	L2(3,(V1),VV[12],(V4))                    /*  SET-STRING-PROPERTY*/;
L538:
	if(((V8))==Cnil){
	goto L541;}
	L2(3,(V1),VV[15],(V8))                    /*  SET-STRING-PROPERTY*/;
L541:
	if(((V5))!=Cnil){
	goto L545;}
	if(((V6))==Cnil){
	goto L544;}
L545:
	L6(3,(V1),(V5),(V6))                      /*  SET-WM-CLASS    */;
L544:
	if(((V7))==Cnil){
	goto L549;}
	L8(2,(V1),(V7))                           /*  SET-WM-COMMAND  */;
L549:
	{volatile object V43;
	volatile object V44;                      /*  ARG             */
	V43= VV[93];
	V44= Cnil;
L559:
	if(!((V43)==Cnil)){
	goto L560;}
	goto L554;
L560:
	V44= CAR((V43));
	Lgetf(2,(V2),(V44))                       /*  GETF            */;
	if(VALUES(0)==Cnil){
	goto L565;}
	goto L555;
L565:
	V43= CDR((V43));
	goto L559;
	}
L555:
	{object V43;                              /*  WM-HINTS        */
	if(((V9))==Cnil){
	goto L573;}
	(*LK21)(1,(V9))                           /*  COPY-WM-HINTS   */;
	V43= VALUES(0);
	goto L571;
L573:
	L10(0)                                    /*  MAKE-WM-HINTS   */;
	V43= VALUES(0);
L571:
	if(((V35))==Cnil){
	goto L575;}
	((V43))->in.in_slots[0]= (V35);
L575:
	if(((V36))==Cnil){
	goto L578;}
	((V43))->in.in_slots[1]= (V36);
L578:
	if(((V37))==Cnil){
	goto L581;}
	((V43))->in.in_slots[2]= (V37);
L581:
	if(((V38))==Cnil){
	goto L584;}
	((V43))->in.in_slots[3]= (V38);
L584:
	if(((V39))==Cnil){
	goto L587;}
	((V43))->in.in_slots[4]= (V39);
L587:
	if(((V40))==Cnil){
	goto L590;}
	((V43))->in.in_slots[5]= (V40);
L590:
	if(((V41))==Cnil){
	goto L593;}
	((V43))->in.in_slots[6]= (V41);
L593:
	if(((V42))==Cnil){
	goto L596;}
	((V43))->in.in_slots[0]= (V42);
L596:
	L12(2,(V1),(V43))                         /*  SET-WM-HINTS    */;
	goto L552;
	}
L554:
	if(((V9))==Cnil){
	goto L552;}
	L12(2,(V1),(V9))                          /*  SET-WM-HINTS    */;
L552:
	{volatile object V43;
	volatile object V44;                      /*  ARG             */
	V43= VV[94];
	V44= Cnil;
L608:
	if(!((V43)==Cnil)){
	goto L609;}
	goto L603;
L609:
	V44= CAR((V43));
	Lgetf(2,(V2),(V44))                       /*  GETF            */;
	if(VALUES(0)==Cnil){
	goto L614;}
	goto L604;
L614:
	V43= CDR((V43));
	goto L608;
	}
L604:
	{object V43;                              /*  SIZE            */
	if(((V10))==Cnil){
	goto L622;}
	(*LK22)(1,(V10))                          /*  COPY-WM-SIZE-HINTS*/;
	V43= VALUES(0);
	goto L620;
L622:
	L15(0)                                    /*  MAKE-WM-SIZE-HINTS*/;
	V43= VALUES(0);
L620:
	if(((V20))==Cnil){
	goto L624;}
	((V43))->in.in_slots[2]= (V20);
L624:
	if(((V21))==Cnil){
	goto L627;}
	((V43))->in.in_slots[3]= (V21);
L627:
	if(((V22))==Cnil){
	goto L630;}
	((V43))->in.in_slots[4]= (V22);
L630:
	if(((V23))==Cnil){
	goto L633;}
	((V43))->in.in_slots[5]= (V23);
L633:
	if(((V24))==Cnil){
	goto L636;}
	((V43))->in.in_slots[6]= (V24);
L636:
	if(((V25))==Cnil){
	goto L639;}
	((V43))->in.in_slots[7]= (V25);
L639:
	if(((V26))==Cnil){
	goto L642;}
	((V43))->in.in_slots[8]= (V26);
L642:
	if(((V27))==Cnil){
	goto L645;}
	((V43))->in.in_slots[9]= (V27);
L645:
	if(((V28))==Cnil){
	goto L648;}
	((V43))->in.in_slots[10]= (V28);
L648:
	if(((V29))==Cnil){
	goto L651;}
	((V43))->in.in_slots[11]= (V29);
L651:
	if(((V30))==Cnil){
	goto L654;}
	((V43))->in.in_slots[12]= (V30);
L654:
	if(((V31))==Cnil){
	goto L657;}
	((V43))->in.in_slots[13]= (V31);
L657:
	if(((V32))==Cnil){
	goto L660;}
	((V43))->in.in_slots[14]= (V32);
L660:
	if(((V33))==Cnil){
	goto L663;}
	((V43))->in.in_slots[15]= (V33);
L663:
	if(((V34))==Cnil){
	goto L666;}
	((V43))->in.in_slots[16]= (V34);
L666:
	if(((V13))==Cnil){
	goto L669;}
	((V43))->in.in_slots[0]= (V12);
L669:
	if(((V15))==Cnil){
	goto L672;}
	((V43))->in.in_slots[1]= (V14);
L672:
	if(((V17))==Cnil){
	goto L675;}
	((V43))->in.in_slots[17]= (V16);
L675:
	if(((V19))==Cnil){
	goto L678;}
	((V43))->in.in_slots[18]= (V18);
L678:
	L17(2,(V1),(V43))                         /*  SET-WM-NORMAL-HINTS*/;
	goto L601;
	}
L603:
	if(((V10))==Cnil){
	goto L601;}
	L17(2,(V1),(V10))                         /*  SET-WM-NORMAL-HINTS*/;
L601:
	if(((V11))==Cnil){
	goto L684;}
	RETURN(L19(2,(V1),(V11))                  /*  SET-WM-ZOOM-HINTS*/);
L684:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-STANDARD-PROPERTIES               */
static L34(int narg, object V1, ...)
{ VT37 VLEX37 CLSR37
	{object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	VALUES(0) = (VV[164]->s.s_gfdef);
	RETURN(Lapply(3,VALUES(0),(V1),(V2))      /*  APPLY           */);
	}
}
/*	function definition for ICONIFY-WINDOW                        */
static L35(int narg, object V1, object V2)
{ VT38 VLEX38 CLSR38
TTL:
	{object V3;                               /*  ROOT            */
	V3= ((V2))->in.in_slots[0];
	RETURN((*LK23)(11,(V3),VV[96],VV[97],VV[87],(V1),VV[98],MAKE_FIXNUM(32),VV[1],VV[99],VV[100],CONS(MAKE_FIXNUM(3),Cnil))/*  SEND-EVENT*/);
	}
}
/*	function definition for WITHDRAW-WINDOW                       */
static L36(int narg, object V1, object V2)
{ VT39 VLEX39 CLSR39
TTL:
	(*LK24)(1,(V1))                           /*  UNMAP-WINDOW    */;
	{object V3;                               /*  ROOT            */
	V3= ((V2))->in.in_slots[0];
	RETURN((*LK23)(9,(V3),VV[101],VV[102],VV[87],(V1),VV[103],(V3),VV[104],Cnil)/*  SEND-EVENT*/);
	}
}
/*	function definition for MAKE-STANDARD-COLORMAP                */
static L37(int narg, ...)
{ VT40 VLEX40 CLSR40
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[12];
	parse_key(narg,args,6,L37keys,keyvars,OBJNULL,FALSE);
	V1= keyvars[0];
	if(keyvars[7]==Cnil){
	V2= MAKE_FIXNUM(0);
	}else{
	V2= keyvars[1];}
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	}
	(*LK5)(1,VV[105])                         /*  FIND-CLASS      */;
	RETURN(siLmake_structure(7,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for RGB-COLORMAPS                         */
static L38(int narg, object V1, object V2)
{ VT41 VLEX41 CLSR41
TTL:
	{register object V3;                      /*  PROP            */
	(*LK0)(6,(V1),(V2),VV[1],VV[113],VV[3],VV[39])/*  GET-PROPERTY*/;
	V3= VALUES(0);
	if(((V3))==Cnil){
	goto L694;}
	(*LK25)(2,((V1))->in.in_slots[1],aref1((V3),0))/*  LOOKUP-COLORMAP*/;
	T0= VALUES(0);
	{object V4= aref1((V3),7);
	(*LK26)(1,aref1((V3),1))                  /*  CARD16->RGB-VAL */;
	T1= VALUES(0);
	(*LK26)(1,aref1((V3),3))                  /*  CARD16->RGB-VAL */;
	T2= VALUES(0);
	(*LK26)(1,aref1((V3),5))                  /*  CARD16->RGB-VAL */;
	(*LK27)(6,VV[117],T1,VV[118],T2,VV[119],VALUES(0))/*  MAKE-COLOR*/;
	T3= VALUES(0);
	(*LK26)(1,aref1((V3),2))                  /*  CARD16->RGB-VAL */;
	T4= VALUES(0);
	(*LK26)(1,aref1((V3),4))                  /*  CARD16->RGB-VAL */;
	T5= VALUES(0);
	(*LK26)(1,aref1((V3),6))                  /*  CARD16->RGB-VAL */;
	(*LK27)(6,VV[117],T4,VV[118],T5,VV[119],VALUES(0))/*  MAKE-COLOR*/;
	T6= VALUES(0);
	if((9)<=(length((V3)))){
	goto L706;}
	T7= Cnil;
	goto L705;
L706:
	(*LK28)(2,((V1))->in.in_slots[1],aref1((V3),8))/*  VISUAL-INFO*/;
	T7= VALUES(0);
L705:
	if((10)<=(length((V3)))){
	goto L709;}
	VALUES(0) = Cnil;
	goto L708;
L709:
	{object V5;                               /*  KILLID          */
	V5= aref1((V3),9);
	if(!(number_compare((V5),MAKE_FIXNUM(1))==0)){
	goto L713;}
	VALUES(0) = VV[123];
	goto L708;
L713:
	(*LK29)(2,((V1))->in.in_slots[1],(V5))    /*  LOOKUP-RESOURCE-ID*/;
	}
L708:
	L37(12,VV[114],T0,VV[115],(V4),VV[116],T3,VV[120],T6,VV[121],T7,VV[122],VALUES(0))/*  MAKE-STANDARD-COLORMAP*/;
	VALUES(0) = CONS(VALUES(0),Cnil);
	RETURN(1);}
L694:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-RGB-COLORMAPS                     */
static L39(int narg, object V1, object V2, object V3)
{ VT42 VLEX42 CLSR42
TTL:
	{volatile object V4;                      /*  PROP            */
	volatile object V5;                       /*  INDEX           */
	(*LK8)(3,fixnum_times(10,length((V3))),VV[126],VV[127])/*  MAKE-ARRAY*/;
	V4= VALUES(0);
	V5= MAKE_FIXNUM(-1);
	{volatile object V6;
	volatile object V7;                       /*  MAP             */
	V6= (V3);
	V7= Cnil;
L721:
	if(!((V6)==Cnil)){
	goto L722;}
	goto L717;
L722:
	V7= CAR((V6));
	{object V9;
	object V10;
	V9= (V4);
	V5= number_plus((V5),MAKE_FIXNUM(1));
	V10= (V5);
	{object V11;                              /*  .VALUE.         */
	V11= ((V7))->in.in_slots[0];
	(*LK30)(1,(V11))                          /*  COLORMAP-P      */;
	if(VALUES(0)==Cnil){
	goto L734;}
	VALUES(0) = ((V11))->in.in_slots[0];
	goto L731;
L734:
	(*LK9)(2,(V11),VV[128])                   /*  X-TYPE-ERROR    */;
	}
L731:
	aset1((V9),fix((V10)),VALUES(0));
	}
	{object V11;
	object V12;
	V11= (V4);
	V5= number_plus((V5),MAKE_FIXNUM(1));
	V12= (V5);
	{object V13;                              /*  .VALUE.         */
	V13= (((V7))->in.in_slots[2])->in.in_slots[0];
	(*LK12)(2,(V13),VV[130])                  /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L743;}
	(*LK31)(1,(V13))                          /*  RGB-VAL->CARD16 */;
	goto L740;
L743:
	(*LK9)(2,(V13),VV[130])                   /*  X-TYPE-ERROR    */;
	}
L740:
	aset1((V11),fix((V12)),VALUES(0));
	}
	{object V13;
	object V14;
	V13= (V4);
	V5= number_plus((V5),MAKE_FIXNUM(1));
	V14= (V5);
	{object V15;                              /*  .VALUE.         */
	V15= (((V7))->in.in_slots[3])->in.in_slots[0];
	(*LK12)(2,(V15),VV[130])                  /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L752;}
	(*LK31)(1,(V15))                          /*  RGB-VAL->CARD16 */;
	goto L749;
L752:
	(*LK9)(2,(V15),VV[130])                   /*  X-TYPE-ERROR    */;
	}
L749:
	aset1((V13),fix((V14)),VALUES(0));
	}
	{object V15;
	object V16;
	V15= (V4);
	V5= number_plus((V5),MAKE_FIXNUM(1));
	V16= (V5);
	{object V17;                              /*  .VALUE.         */
	V17= (((V7))->in.in_slots[2])->in.in_slots[1];
	(*LK12)(2,(V17),VV[130])                  /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L761;}
	(*LK31)(1,(V17))                          /*  RGB-VAL->CARD16 */;
	goto L758;
L761:
	(*LK9)(2,(V17),VV[130])                   /*  X-TYPE-ERROR    */;
	}
L758:
	aset1((V15),fix((V16)),VALUES(0));
	}
	{object V17;
	object V18;
	V17= (V4);
	V5= number_plus((V5),MAKE_FIXNUM(1));
	V18= (V5);
	{object V19;                              /*  .VALUE.         */
	V19= (((V7))->in.in_slots[3])->in.in_slots[1];
	(*LK12)(2,(V19),VV[130])                  /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L770;}
	(*LK31)(1,(V19))                          /*  RGB-VAL->CARD16 */;
	goto L767;
L770:
	(*LK9)(2,(V19),VV[130])                   /*  X-TYPE-ERROR    */;
	}
L767:
	aset1((V17),fix((V18)),VALUES(0));
	}
	{object V19;
	object V20;
	V19= (V4);
	V5= number_plus((V5),MAKE_FIXNUM(1));
	V20= (V5);
	{object V21;                              /*  .VALUE.         */
	V21= (((V7))->in.in_slots[2])->in.in_slots[2];
	(*LK12)(2,(V21),VV[130])                  /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L779;}
	(*LK31)(1,(V21))                          /*  RGB-VAL->CARD16 */;
	goto L776;
L779:
	(*LK9)(2,(V21),VV[130])                   /*  X-TYPE-ERROR    */;
	}
L776:
	aset1((V19),fix((V20)),VALUES(0));
	}
	{object V21;
	object V22;
	V21= (V4);
	V5= number_plus((V5),MAKE_FIXNUM(1));
	V22= (V5);
	{object V23;                              /*  .VALUE.         */
	V23= (((V7))->in.in_slots[3])->in.in_slots[2];
	(*LK12)(2,(V23),VV[130])                  /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L788;}
	(*LK31)(1,(V23))                          /*  RGB-VAL->CARD16 */;
	goto L785;
L788:
	(*LK9)(2,(V23),VV[130])                   /*  X-TYPE-ERROR    */;
	}
L785:
	aset1((V21),fix((V22)),VALUES(0));
	}
	{object V23;
	object V24;
	V23= (V4);
	V5= number_plus((V5),MAKE_FIXNUM(1));
	V24= (V5);
	aset1((V23),fix((V24)),((V7))->in.in_slots[1]);
	}
	{object V25;
	object V26;
	V25= (V4);
	V5= number_plus((V5),MAKE_FIXNUM(1));
	V26= (V5);
	aset1((V25),fix((V26)),(((V7))->in.in_slots[4])->in.in_slots[0]);
	}
	{object V27;
	object V28;
	V27= (V4);
	V5= number_plus((V5),MAKE_FIXNUM(1));
	V28= (V5);
	{register object V29;                     /*  KILL            */
	V29= ((V7))->in.in_slots[5];
	{register object V30;
	V30= (V29);
	(*LK12)(2,(V30),VV[132])                  /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L805;}
	if(((V29)!= Cnil))goto L807;
	VALUES(0) = MAKE_FIXNUM(0);
	goto L802;
L807:
	if(((V29)!= VV[123]))goto L808;
	VALUES(0) = MAKE_FIXNUM(1);
	goto L802;
L808:
	FEerror("The ECASE key value ~s is illegal.",1,(V29));
L805:
	(*LK12)(2,(V30),VV[133])                  /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L810;}
	VALUES(0) = ((V29))->in.in_slots[0];
	goto L802;
L810:
	(*LK12)(2,(V30),VV[134])                  /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L813;}
	VALUES(0) = ((V29))->in.in_slots[0];
	goto L802;
L813:
	(*LK12)(2,(V30),VV[135])                  /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L816;}
	VALUES(0) = ((V29))->in.in_slots[0];
	goto L802;
L816:
	(*LK12)(2,(V30),VV[128])                  /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L819;}
	VALUES(0) = ((V29))->in.in_slots[0];
	goto L802;
L819:
	(*LK12)(2,(V30),VV[136])                  /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L822;}
	(*LK32)(1,(V29))                          /*  FONT-ID         */;
	goto L802;
L822:
	(*LK33)(3,VV[137],(V30),VV[138])          /*  TYPECASE-ERROR-STRING*/;
	Lerror(1,VALUES(0))                       /*  ERROR           */;
	}
	}
L802:
	aset1((V27),fix((V28)),VALUES(0));
	}
	V6= CDR((V6));
	goto L721;
	}
L717:
	RETURN((*LK1)(5,(V1),(V2),(V4),VV[113],MAKE_FIXNUM(32))/*  CHANGE-PROPERTY*/);
	}
}
/*	function definition for GET-STANDARD-COLORMAP                 */
static L40(int narg, object V1, object V2)
{ VT43 VLEX43 CLSR43
TTL:
	{register object V3;                      /*  PROP            */
	(*LK0)(6,(V1),(V2),VV[1],VV[113],VV[3],VV[39])/*  GET-PROPERTY*/;
	V3= VALUES(0);
	if(((V3))==Cnil){
	goto L830;}
	(*LK25)(2,((V1))->in.in_slots[1],aref1((V3),0))/*  LOOKUP-COLORMAP*/;
	T0= VALUES(0);
	{object V4= aref1((V3),7);
	(*LK26)(1,aref1((V3),1))                  /*  CARD16->RGB-VAL */;
	T1= VALUES(0);
	(*LK26)(1,aref1((V3),3))                  /*  CARD16->RGB-VAL */;
	T2= VALUES(0);
	(*LK26)(1,aref1((V3),5))                  /*  CARD16->RGB-VAL */;
	(*LK27)(6,VV[117],T1,VV[118],T2,VV[119],VALUES(0))/*  MAKE-COLOR*/;
	T3= VALUES(0);
	(*LK26)(1,aref1((V3),2))                  /*  CARD16->RGB-VAL */;
	T4= VALUES(0);
	(*LK26)(1,aref1((V3),4))                  /*  CARD16->RGB-VAL */;
	T5= VALUES(0);
	(*LK26)(1,aref1((V3),6))                  /*  CARD16->RGB-VAL */;
	(*LK27)(6,VV[117],T4,VV[118],T5,VV[119],VALUES(0))/*  MAKE-COLOR*/;
	VALUES(3) = VALUES(0);
	VALUES(2) = T3;
	VALUES(1) = (V4);
	VALUES(0) = T0;
	RETURN(4);}
L830:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-STANDARD-COLORMAP                 */
static L41(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT44 VLEX44 CLSR44
TTL:
	{object V7;                               /*  PROP            */
	T0= (VV[39]->s.s_gfdef);
	(*LK30)(1,(V3))                           /*  COLORMAP-P      */;
	if(VALUES(0)==Cnil){
	goto L845;}
	T1= ((V3))->in.in_slots[0];
	goto L843;
L845:
	(*LK9)(2,(V3),VV[128])                    /*  X-TYPE-ERROR    */;
	T1= VALUES(0);
L843:
	{object V8;                               /*  .VALUE.         */
	V8= ((V5))->in.in_slots[0];
	(*LK12)(2,(V8),VV[130])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L850;}
	(*LK31)(1,(V8))                           /*  RGB-VAL->CARD16 */;
	T2= VALUES(0);
	goto L847;
L850:
	(*LK9)(2,(V8),VV[130])                    /*  X-TYPE-ERROR    */;
	T2= VALUES(0);
	}
L847:
	{object V8;                               /*  .VALUE.         */
	V8= ((V6))->in.in_slots[0];
	(*LK12)(2,(V8),VV[130])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L855;}
	(*LK31)(1,(V8))                           /*  RGB-VAL->CARD16 */;
	T3= VALUES(0);
	goto L852;
L855:
	(*LK9)(2,(V8),VV[130])                    /*  X-TYPE-ERROR    */;
	T3= VALUES(0);
	}
L852:
	{object V8;                               /*  .VALUE.         */
	V8= ((V5))->in.in_slots[1];
	(*LK12)(2,(V8),VV[130])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L860;}
	(*LK31)(1,(V8))                           /*  RGB-VAL->CARD16 */;
	T4= VALUES(0);
	goto L857;
L860:
	(*LK9)(2,(V8),VV[130])                    /*  X-TYPE-ERROR    */;
	T4= VALUES(0);
	}
L857:
	{object V8;                               /*  .VALUE.         */
	V8= ((V6))->in.in_slots[1];
	(*LK12)(2,(V8),VV[130])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L865;}
	(*LK31)(1,(V8))                           /*  RGB-VAL->CARD16 */;
	T5= VALUES(0);
	goto L862;
L865:
	(*LK9)(2,(V8),VV[130])                    /*  X-TYPE-ERROR    */;
	T5= VALUES(0);
	}
L862:
	{object V8;                               /*  .VALUE.         */
	V8= ((V5))->in.in_slots[2];
	(*LK12)(2,(V8),VV[130])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L870;}
	(*LK31)(1,(V8))                           /*  RGB-VAL->CARD16 */;
	T6= VALUES(0);
	goto L867;
L870:
	(*LK9)(2,(V8),VV[130])                    /*  X-TYPE-ERROR    */;
	T6= VALUES(0);
	}
L867:
	{object V8;                               /*  .VALUE.         */
	V8= ((V6))->in.in_slots[2];
	(*LK12)(2,(V8),VV[130])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L875;}
	(*LK31)(1,(V8))                           /*  RGB-VAL->CARD16 */;
	goto L872;
L875:
	(*LK9)(2,(V8),VV[130])                    /*  X-TYPE-ERROR    */;
	}
L872:
	Lapply(9,T0,T1,T2,T3,T4,T5,T6,VALUES(0),(V4))/*  APPLY        */;
	V7= VALUES(0);
	RETURN((*LK1)(5,(V1),(V2),(V7),VV[113],MAKE_FIXNUM(32))/*  CHANGE-PROPERTY*/);
	}
}
/*	function definition for CUT-BUFFER                            */
static L42(int narg, object V1, ...)
{ VT45 VLEX45 CLSR45
	{object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[12];
	parse_key(narg,args,6,L42keys,keyvars,OBJNULL,FALSE);
	if(keyvars[6]==Cnil){
	V2= MAKE_FIXNUM(0);
	}else{
	V2= keyvars[0];}
	if(keyvars[7]==Cnil){
	V3= VV[2];
	}else{
	V3= keyvars[1];}
	if(keyvars[8]==Cnil){
	V4= VV[4];
	}else{
	V4= keyvars[2];}
	if(keyvars[9]==Cnil){
	V5= (VV[173]->s.s_gfdef);
	}else{
	V5= keyvars[3];}
	if(keyvars[10]==Cnil){
	V6= MAKE_FIXNUM(0);
	}else{
	V6= keyvars[4];}
	V7= keyvars[5];
	}
	RETURN((*LK0)(12,(CAR(((V1))->in.in_slots[40]))->in.in_slots[0],(VV[140])->v.v_self[fix((V2))],VV[1],(V3),VV[3],(V4),VV[24],(V6),VV[141],(V7),VV[5],(V5))/*  GET-PROPERTY*/);
	}
}
/*	function definition for SET-CUT-BUFFER                        */
static L44(int narg, object V1, object V2, ...)
{ VT46 VLEX46 CLSR46
	{object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	va_list args; va_start(args, V2);
	narg -=2;
	{ object keyvars[12];
	parse_key(narg,args,6,L44keys,keyvars,OBJNULL,FALSE);
	if(keyvars[6]==Cnil){
	V3= MAKE_FIXNUM(0);
	}else{
	V3= keyvars[0];}
	if(keyvars[7]==Cnil){
	V4= VV[2];
	}else{
	V4= keyvars[1];}
	if(keyvars[8]==Cnil){
	V5= MAKE_FIXNUM(8);
	}else{
	V5= keyvars[2];}
	if(keyvars[9]==Cnil){
	V6= MAKE_FIXNUM(0);
	}else{
	V6= keyvars[3];}
	V7= keyvars[4];
	if(keyvars[11]==Cnil){
	V8= (VV[176]->s.s_gfdef);
	}else{
	V8= keyvars[5];}
	}
	{object V9;                               /*  ROOT            */
	object V10;                               /*  PROPERTY        */
	V9= (CAR(((V2))->in.in_slots[40]))->in.in_slots[0];
	V10= (VV[146])->v.v_self[fix((V3))];
	(*LK1)(11,(V9),(V10),(V1),(V4),(V5),VV[5],(V8),VV[24],(V6),VV[141],(V7))/*  CHANGE-PROPERTY*/;
	VALUES(0) = (V1);
	RETURN(1);
	}
	}
}
/*	function definition for ROTATE-CUT-BUFFERS                    */
static L45(int narg, object V1, ...)
{ VT47 VLEX47 CLSR47
	{int i=1;
	volatile object V2;
	volatile object V3;
	va_list args; va_start(args, V1);
	if (i==narg) goto L890;
	V2= va_arg(args, object);
	i++;
	if (i==narg) goto L891;
	V3= va_arg(args, object);
	i++;
	goto L892;
L890:
	V2= MAKE_FIXNUM(1);
L891:
	V3= Ct;
L892:
	{volatile object V4;                      /*  ROOT            */
	volatile object V5;                       /*  BUFFERS         */
	V4= (CAR(((V1))->in.in_slots[40]))->in.in_slots[0];
	V5= VV[147];
	if(((V3))==Cnil){
	goto L897;}
	{volatile object V6;                      /*  PROPS           */
	(*LK34)(1,(V4))                           /*  LIST-PROPERTIES */;
	V6= VALUES(0);
	{volatile int V7;
	volatile int V8;                          /*  I               */
	V7= 8;
	V8= 0;
L904:
	if(!((V8)>=(V7))){
	goto L905;}
	goto L897;
L905:
	if((memql(((V5))->v.v_self[V8],(V6)))!=Cnil){
	goto L908;}
	L44(4,VV[148],(V1),VV[149],MAKE_FIXNUM(V8))/*  SET-CUT-BUFFER */;
L908:
	V8= (V8)+1;
	goto L904;
	}
	}
L897:
	RETURN((*LK35)(3,(V4),(V5),(V2))          /*  ROTATE-PROPERTIES*/);
	}
	}
}
static LKF35(int narg, ...) {TRAMPOLINK(VV[277],&LK35);}
static LKF34(int narg, ...) {TRAMPOLINK(VV[276],&LK34);}
static LKF33(int narg, ...) {TRAMPOLINK(VV[270],&LK33);}
static LKF32(int narg, ...) {TRAMPOLINK(VV[269],&LK32);}
static LKF31(int narg, ...) {TRAMPOLINK(VV[268],&LK31);}
static LKF30(int narg, ...) {TRAMPOLINK(VV[267],&LK30);}
static LKF29(int narg, ...) {TRAMPOLINK(VV[265],&LK29);}
static LKF28(int narg, ...) {TRAMPOLINK(VV[131],&LK28);}
static LKF27(int narg, ...) {TRAMPOLINK(VV[264],&LK27);}
static LKF26(int narg, ...) {TRAMPOLINK(VV[263],&LK26);}
static LKF25(int narg, ...) {TRAMPOLINK(VV[262],&LK25);}
static LKF24(int narg, ...) {TRAMPOLINK(VV[259],&LK24);}
static LKF23(int narg, ...) {TRAMPOLINK(VV[257],&LK23);}
static LKF22(int narg, ...) {TRAMPOLINK(VV[59],&LK22);}
static LKF21(int narg, ...) {TRAMPOLINK(VV[35],&LK21);}
static LKF20(int narg, ...) {TRAMPOLINK(VV[240],&LK20);}
static LKF19(int narg, ...) {TRAMPOLINK(VV[238],&LK19);}
static LKF18(int narg, ...) {TRAMPOLINK(VV[236],&LK18);}
static LKF17(int narg, ...) {TRAMPOLINK(VV[39],&LK17);}
static LKF16(int narg, ...) {TRAMPOLINK(VV[232],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[231],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[230],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[209],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[208],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[207],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[206],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[205],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[203],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[201],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[200],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[154],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[186],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[183],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[181],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[177],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[174],&LK0);}
