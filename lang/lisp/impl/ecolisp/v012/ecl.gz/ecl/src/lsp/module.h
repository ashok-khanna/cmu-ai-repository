
/* (c) Copyright Giuseppe Attardi, 1993. All rights reserved. */
static L1();
static L2(int, object, ...);
int Ladjoin();
int Lstring();
#define VT3 object T0;
#define VLEX3
#define CLSR3
int Lstring_downcase();
int Lstring();
int Lmember();
int Lstring();
#define VT4 object T0;
#define VLEX4
#define CLSR4
static struct codeblock Cblock;
#define VM4 1
#define VM3 1
#define VM2 0
#define VM1 9
static object VV[9];
static LKF0(int, ...);
static (*LK0)(int, ...)=LKF0;
