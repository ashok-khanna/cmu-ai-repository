
/* (c) Copyright Giuseppe Attardi, 1993. All rights reserved. */
static L2(int, object, object, ...);
static L3(int, object, object, ...);
static L4(int, object, object, ...);
static L5(int, object, object, ...);
static L6(int, object, object, ...);
static L7(int, object, object, ...);
static L8(int, object, object, ...);
static L9(int, object, object, ...);
static L10(int, object, object, ...);
#define VC2
static intUobject L2keys[3]={11,12,13};
#define VT3 object T0,T1,T2,T3;
#define VLEX3
#define CLSR3
static intUobject L3keys[3]={11,12,13};
#define VT4 object T0,T1,T2,T3;
#define VLEX4
#define CLSR4
static intUobject L4keys[3]={11,12,13};
#define VT5 object T0,T1,T2,T3;
#define VLEX5
#define CLSR5
static intUobject L5keys[3]={11,12,13};
#define VT6 object T0,T1,T2,T3;
#define VLEX6
#define CLSR6
static intUobject L6keys[3]={11,12,13};
#define VT7 object T0,T1,T2,T3;
#define VLEX7
#define CLSR7
static intUobject L7keys[3]={11,12,13};
#define VT8 object T0,T1,T2,T3;
#define VLEX8
#define CLSR8
static intUobject L8keys[3]={11,12,13};
#define VT9 object T0,T1,T2,T3;
#define VLEX9
#define CLSR9
static intUobject L9keys[3]={11,12,13};
#define VT10 object T0,T1,T2,T3;
#define VLEX10
#define CLSR10
static intUobject L10keys[3]={11,12,13};
#define VT11 object T0,T1,T2,T3;
#define VLEX11
#define CLSR11
static struct codeblock Cblock;
#define VM11 4
#define VM10 4
#define VM9 4
#define VM8 4
#define VM7 4
#define VM6 4
#define VM5 4
#define VM4 4
#define VM3 4
#define VM2 0
#define VM1 16
static object VV[16];
static LKF0(int, ...);
static (*LK0)(int, ...)=LKF0;

