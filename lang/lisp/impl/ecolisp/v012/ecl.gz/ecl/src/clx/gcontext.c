
#include "gcontext.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	siLAmake_constant(2,VV[0],MAKE_FIXNUM(23))/*  *MAKE-CONSTANT  */;
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[1],VV[2],VV[3])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L6;
	V2= VALUES(0);
	if (V1--==0) goto L7;
	V3= VALUES(1);
	if (V1--==0) goto L8;
	V4= VALUES(2);
	goto L9;
L6:
	V2= Cnil;
L7:
	V3= Cnil;
L8:
	V4= Cnil;
L9:
	siLdefine_macro(4,VV[1],(V2),(V3),(V4))   /*  DEFINE-MACRO    */;}
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[4],VV[2],VV[5])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L12;
	V2= VALUES(0);
	if (V1--==0) goto L13;
	V3= VALUES(1);
	if (V1--==0) goto L14;
	V4= VALUES(2);
	goto L15;
L12:
	V2= Cnil;
L13:
	V3= Cnil;
L14:
	V4= Cnil;
L15:
	siLdefine_macro(4,VV[4],(V2),(V3),(V4))   /*  DEFINE-MACRO    */;}
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[6],VV[2],VV[7])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L18;
	V2= VALUES(0);
	if (V1--==0) goto L19;
	V3= VALUES(1);
	if (V1--==0) goto L20;
	V4= VALUES(2);
	goto L21;
L18:
	V2= Cnil;
L19:
	V3= Cnil;
L20:
	V4= Cnil;
L21:
	siLdefine_macro(4,VV[6],(V2),(V3),(V4))   /*  DEFINE-MACRO    */;}
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[8],VV[2],VV[9])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L24;
	V2= VALUES(0);
	if (V1--==0) goto L25;
	V3= VALUES(1);
	if (V1--==0) goto L26;
	V4= VALUES(2);
	goto L27;
L24:
	V2= Cnil;
L25:
	V3= Cnil;
L26:
	V4= Cnil;
L27:
	siLdefine_macro(4,VV[8],(V2),(V3),(V4))   /*  DEFINE-MACRO    */;}
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[10],VV[2],VV[11])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L30;
	V2= VALUES(0);
	if (V1--==0) goto L31;
	V3= VALUES(1);
	if (V1--==0) goto L32;
	V4= VALUES(2);
	goto L33;
L30:
	V2= Cnil;
L31:
	V3= Cnil;
L32:
	V4= Cnil;
L33:
	siLdefine_macro(4,VV[10],(V2),(V3),(V4))  /*  DEFINE-MACRO    */;}
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[12],VV[2],VV[13])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L36;
	V2= VALUES(0);
	if (V1--==0) goto L37;
	V3= VALUES(1);
	if (V1--==0) goto L38;
	V4= VALUES(2);
	goto L39;
L36:
	V2= Cnil;
L37:
	V3= Cnil;
L38:
	V4= Cnil;
L39:
	siLdefine_macro(4,VV[12],(V2),(V3),(V4))  /*  DEFINE-MACRO    */;}
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[14],VV[2],VV[15])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L42;
	V2= VALUES(0);
	if (V1--==0) goto L43;
	V3= VALUES(1);
	if (V1--==0) goto L44;
	V4= VALUES(2);
	goto L45;
L42:
	V2= Cnil;
L43:
	V3= Cnil;
L44:
	V4= Cnil;
L45:
	siLdefine_macro(4,VV[14],(V2),(V3),(V4))  /*  DEFINE-MACRO    */;}
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[16],VV[2],VV[17])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L48;
	V2= VALUES(0);
	if (V1--==0) goto L49;
	V3= VALUES(1);
	if (V1--==0) goto L50;
	V4= VALUES(2);
	goto L51;
L48:
	V2= Cnil;
L49:
	V3= Cnil;
L50:
	V4= Cnil;
L51:
	siLdefine_macro(4,VV[16],(V2),(V3),(V4))  /*  DEFINE-MACRO    */;}
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[18],VV[2],VV[19])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L54;
	V2= VALUES(0);
	if (V1--==0) goto L55;
	V3= VALUES(1);
	if (V1--==0) goto L56;
	V4= VALUES(2);
	goto L57;
L54:
	V2= Cnil;
L55:
	V3= Cnil;
L56:
	V4= Cnil;
L57:
	siLdefine_macro(4,VV[18],(V2),(V3),(V4))  /*  DEFINE-MACRO    */;}
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[20],VV[2],VV[21])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L60;
	V2= VALUES(0);
	if (V1--==0) goto L61;
	V3= VALUES(1);
	if (V1--==0) goto L62;
	V4= VALUES(2);
	goto L63;
L60:
	V2= Cnil;
L61:
	V3= Cnil;
L62:
	V4= Cnil;
L63:
	siLdefine_macro(4,VV[20],(V2),(V3),(V4))  /*  DEFINE-MACRO    */;}
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[22],VV[2],VV[23])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L66;
	V2= VALUES(0);
	if (V1--==0) goto L67;
	V3= VALUES(1);
	if (V1--==0) goto L68;
	V4= VALUES(2);
	goto L69;
L66:
	V2= Cnil;
L67:
	V3= Cnil;
L68:
	V4= Cnil;
L69:
	siLdefine_macro(4,VV[22],(V2),(V3),(V4))  /*  DEFINE-MACRO    */;}
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[24],VV[2],VV[25])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L72;
	V2= VALUES(0);
	if (V1--==0) goto L73;
	V3= VALUES(1);
	if (V1--==0) goto L74;
	V4= VALUES(2);
	goto L75;
L72:
	V2= Cnil;
L73:
	V3= Cnil;
L74:
	V4= Cnil;
L75:
	siLdefine_macro(4,VV[24],(V2),(V3),(V4))  /*  DEFINE-MACRO    */;}
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[26],VV[2],VV[27])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L78;
	V2= VALUES(0);
	if (V1--==0) goto L79;
	V3= VALUES(1);
	if (V1--==0) goto L80;
	V4= VALUES(2);
	goto L81;
L78:
	V2= Cnil;
L79:
	V3= Cnil;
L80:
	V4= Cnil;
L81:
	siLdefine_macro(4,VV[26],(V2),(V3),(V4))  /*  DEFINE-MACRO    */;}
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[28],VV[2],VV[29])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L84;
	V2= VALUES(0);
	if (V1--==0) goto L85;
	V3= VALUES(1);
	if (V1--==0) goto L86;
	V4= VALUES(2);
	goto L87;
L84:
	V2= Cnil;
L85:
	V3= Cnil;
L86:
	V4= Cnil;
L87:
	siLdefine_macro(4,VV[28],(V2),(V3),(V4))  /*  DEFINE-MACRO    */;}
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[30],VV[2],VV[31])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L90;
	V2= VALUES(0);
	if (V1--==0) goto L91;
	V3= VALUES(1);
	if (V1--==0) goto L92;
	V4= VALUES(2);
	goto L93;
L90:
	V2= Cnil;
L91:
	V3= Cnil;
L92:
	V4= Cnil;
L93:
	siLdefine_macro(4,VV[30],(V2),(V3),(V4))  /*  DEFINE-MACRO    */;}
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[32],VV[2],VV[33])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L96;
	V2= VALUES(0);
	if (V1--==0) goto L97;
	V3= VALUES(1);
	if (V1--==0) goto L98;
	V4= VALUES(2);
	goto L99;
L96:
	V2= Cnil;
L97:
	V3= Cnil;
L98:
	V4= Cnil;
L99:
	siLdefine_macro(4,VV[32],(V2),(V3),(V4))  /*  DEFINE-MACRO    */;}
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[34],VV[2],VV[35])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L102;
	V2= VALUES(0);
	if (V1--==0) goto L103;
	V3= VALUES(1);
	if (V1--==0) goto L104;
	V4= VALUES(2);
	goto L105;
L102:
	V2= Cnil;
L103:
	V3= Cnil;
L104:
	V4= Cnil;
L105:
	siLdefine_macro(4,VV[34],(V2),(V3),(V4))  /*  DEFINE-MACRO    */;}
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[36],VV[2],VV[37])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L108;
	V2= VALUES(0);
	if (V1--==0) goto L109;
	V3= VALUES(1);
	if (V1--==0) goto L110;
	V4= VALUES(2);
	goto L111;
L108:
	V2= Cnil;
L109:
	V3= Cnil;
L110:
	V4= Cnil;
L111:
	siLdefine_macro(4,VV[36],(V2),(V3),(V4))  /*  DEFINE-MACRO    */;}
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[38],VV[2],VV[39])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L114;
	V2= VALUES(0);
	if (V1--==0) goto L115;
	V3= VALUES(1);
	if (V1--==0) goto L116;
	V4= VALUES(2);
	goto L117;
L114:
	V2= Cnil;
L115:
	V3= Cnil;
L116:
	V4= Cnil;
L117:
	siLdefine_macro(4,VV[38],(V2),(V3),(V4))  /*  DEFINE-MACRO    */;}
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[40],VV[2],VV[41])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L120;
	V2= VALUES(0);
	if (V1--==0) goto L121;
	V3= VALUES(1);
	if (V1--==0) goto L122;
	V4= VALUES(2);
	goto L123;
L120:
	V2= Cnil;
L121:
	V3= Cnil;
L122:
	V4= Cnil;
L123:
	siLdefine_macro(4,VV[40],(V2),(V3),(V4))  /*  DEFINE-MACRO    */;}
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[42],VV[2],VV[43])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L126;
	V2= VALUES(0);
	if (V1--==0) goto L127;
	V3= VALUES(1);
	if (V1--==0) goto L128;
	V4= VALUES(2);
	goto L129;
L126:
	V2= Cnil;
L127:
	V3= Cnil;
L128:
	V4= Cnil;
L129:
	siLdefine_macro(4,VV[42],(V2),(V3),(V4))  /*  DEFINE-MACRO    */;}
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[44],VV[2],VV[45])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L132;
	V2= VALUES(0);
	if (V1--==0) goto L133;
	V3= VALUES(1);
	if (V1--==0) goto L134;
	V4= VALUES(2);
	goto L135;
L132:
	V2= Cnil;
L133:
	V3= Cnil;
L134:
	V4= Cnil;
L135:
	siLdefine_macro(4,VV[44],(V2),(V3),(V4))  /*  DEFINE-MACRO    */;}
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[46],VV[2],VV[47])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L138;
	V2= VALUES(0);
	if (V1--==0) goto L139;
	V3= VALUES(1);
	if (V1--==0) goto L140;
	V4= VALUES(2);
	goto L141;
L138:
	V2= Cnil;
L139:
	V3= Cnil;
L140:
	V4= Cnil;
L141:
	siLdefine_macro(4,VV[46],(V2),(V3),(V4))  /*  DEFINE-MACRO    */;}
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[48],VV[49],VV[50])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L144;
	V2= VALUES(0);
	if (V1--==0) goto L145;
	V3= VALUES(1);
	if (V1--==0) goto L146;
	V4= VALUES(2);
	goto L147;
L144:
	V2= Cnil;
L145:
	V3= Cnil;
L146:
	V4= Cnil;
L147:
	siLdefine_macro(4,VV[48],(V2),(V3),(V4))  /*  DEFINE-MACRO    */;}
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[51],VV[49],VV[52])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L150;
	V2= VALUES(0);
	if (V1--==0) goto L151;
	V3= VALUES(1);
	if (V1--==0) goto L152;
	V4= VALUES(2);
	goto L153;
L150:
	V2= Cnil;
L151:
	V3= Cnil;
L152:
	V4= Cnil;
L153:
	siLdefine_macro(4,VV[51],(V2),(V3),(V4))  /*  DEFINE-MACRO    */;}
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[53],VV[49],VV[54])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L156;
	V2= VALUES(0);
	if (V1--==0) goto L157;
	V3= VALUES(1);
	if (V1--==0) goto L158;
	V4= VALUES(2);
	goto L159;
L156:
	V2= Cnil;
L157:
	V3= Cnil;
L158:
	V4= Cnil;
L159:
	siLdefine_macro(4,VV[53],(V2),(V3),(V4))  /*  DEFINE-MACRO    */;}
	{ int V1;
	 volatile object V2;                      /*  EXPR            */
	 volatile object V3;                      /*  DOC             */
	 volatile object V4;                      /*  PPRINT          */
	V1=funcall(4,VV[300]->s.s_gfdef,VV[55],VV[49],VV[56])/*  EXPAND-DEFMACRO*/;
	if (V1--==0) goto L162;
	V2= VALUES(0);
	if (V1--==0) goto L163;
	V3= VALUES(1);
	if (V1--==0) goto L164;
	V4= VALUES(2);
	goto L165;
L162:
	V2= Cnil;
L163:
	V3= Cnil;
L164:
	V4= Cnil;
L165:
	siLdefine_macro(4,VV[55],(V2),(V3),(V4))  /*  DEFINE-MACRO    */;}
	siLAmake_constant(2,VV[57],MAKE_FIXNUM(27))/*  *MAKE-CONSTANT */;
	siLAmake_constant(2,VV[58],VV[59])        /*  *MAKE-CONSTANT  */;
	siLAmake_constant(2,VV[60],VV[61])        /*  *MAKE-CONSTANT  */;
	putprop(VV[62],VV[64],VV[63]);
	VV[301] = make_cfun(LC1,Cnil,&Cblock);
	VALUES(0) = VV[301];
	putprop(VV[62],VALUES(0),VV[65]);
	putprop(VV[62],Cnil,VV[67]);
	putprop(VV[68],VV[69],VV[63]);
	VV[302] = make_cfun(LC2,Cnil,&Cblock);
	VALUES(0) = VV[302];
	putprop(VV[68],VALUES(0),VV[65]);
	putprop(VV[68],Cnil,VV[67]);
	funcall(13,VV[303]->s.s_gfdef,VV[71],VV[72],VV[73],Cnil,VV[74],VV[75],Cnil,Cnil,Cnil,VV[76],MAKE_FIXNUM(4),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[304],L3,4,L3keys);
	(void)putprop(VV[304],VV[Vdeb304],VV[305]);
	VV[77]->s.s_stype=(short)stp_special;
	if(VV[77]->s.s_dbind == OBJNULL){
	(VV[77]->s.s_dbind)= Cnil;}
	VV[78]->s.s_stype=(short)stp_special;
	if(VV[78]->s.s_dbind == OBJNULL){
	(VV[78]->s.s_dbind)= Cnil;}
	MM0(VV[306],L4);
	MF0(VV[307],L5);
	(void)putprop(VV[307],VV[Vdeb307],VV[305]);
	MF0(VV[308],L6);
	(void)putprop(VV[308],VV[Vdeb308],VV[305]);
	VV[81]->s.s_stype=(short)stp_special;
	if(VV[81]->s.s_dbind == OBJNULL){
	(VV[81]->s.s_dbind)= Cnil;}
	MF0(VV[309],L7);
	(void)putprop(VV[309],VV[Vdeb309],VV[305]);
	MF0(VV[310],L8);
	(void)putprop(VV[310],VV[Vdeb310],VV[305]);
	MM0(VV[311],L9);
	(void)putprop(VV[312],VV[94],siSpretty_print_format);
	
	MM0(VV[312],L10);
	(void)putprop(VV[119],VV[94],siSpretty_print_format);
	
	MM0(VV[119],L11);
	MM0(VV[102],L12);
	MM0(VV[313],L13);
	VV[134]=string_to_object(VV[134]);
	MF0(VV[136],L14);
	(void)putprop(VV[136],VV[Vdeb136],VV[305]);
	MF0(VV[137],L15);
	(void)putprop(VV[137],VV[Vdeb137],VV[305]);
	putprop(VV[136],VV[137],VV[138]);
	remprop(VV[136],VV[139]);
	remprop(VV[136],VV[140]);
	putprop(VV[136],Cnil,VV[141]);
	MF0(VV[143],L16);
	(void)putprop(VV[143],VV[Vdeb143],VV[305]);
	MF0(VV[144],L17);
	(void)putprop(VV[144],VV[Vdeb144],VV[305]);
	putprop(VV[143],VV[144],VV[138]);
	remprop(VV[143],VV[139]);
	remprop(VV[143],VV[140]);
	putprop(VV[143],Cnil,VV[141]);
	MF0(VV[145],L18);
	(void)putprop(VV[145],VV[Vdeb145],VV[305]);
	MF0(VV[146],L19);
	(void)putprop(VV[146],VV[Vdeb146],VV[305]);
	putprop(VV[145],VV[146],VV[138]);
	remprop(VV[145],VV[139]);
	remprop(VV[145],VV[140]);
	putprop(VV[145],Cnil,VV[141]);
	MF0(VV[147],L20);
	(void)putprop(VV[147],VV[Vdeb147],VV[305]);
	MF0(VV[148],L21);
	(void)putprop(VV[148],VV[Vdeb148],VV[305]);
	putprop(VV[147],VV[148],VV[138]);
	remprop(VV[147],VV[139]);
	remprop(VV[147],VV[140]);
	putprop(VV[147],Cnil,VV[141]);
	MF0(VV[150],L22);
	(void)putprop(VV[150],VV[Vdeb150],VV[305]);
	MF0(VV[151],L23);
	(void)putprop(VV[151],VV[Vdeb151],VV[305]);
	putprop(VV[150],VV[151],VV[138]);
	remprop(VV[150],VV[139]);
	remprop(VV[150],VV[140]);
	putprop(VV[150],Cnil,VV[141]);
	MF0(VV[156],L24);
	(void)putprop(VV[156],VV[Vdeb156],VV[305]);
	MF0(VV[157],L25);
	(void)putprop(VV[157],VV[Vdeb157],VV[305]);
	putprop(VV[156],VV[157],VV[138]);
	remprop(VV[156],VV[139]);
	remprop(VV[156],VV[140]);
	putprop(VV[156],Cnil,VV[141]);
	MF0(VV[161],L26);
	(void)putprop(VV[161],VV[Vdeb161],VV[305]);
	MF0(VV[162],L27);
	(void)putprop(VV[162],VV[Vdeb162],VV[305]);
	putprop(VV[161],VV[162],VV[138]);
	remprop(VV[161],VV[139]);
	remprop(VV[161],VV[140]);
	putprop(VV[161],Cnil,VV[141]);
	MF0(VV[166],L28);
	(void)putprop(VV[166],VV[Vdeb166],VV[305]);
	MF0(VV[167],L29);
	(void)putprop(VV[167],VV[Vdeb167],VV[305]);
	putprop(VV[166],VV[167],VV[138]);
	remprop(VV[166],VV[139]);
	remprop(VV[166],VV[140]);
	putprop(VV[166],Cnil,VV[141]);
	MF0(VV[171],L30);
	(void)putprop(VV[171],VV[Vdeb171],VV[305]);
	MF0(VV[172],L31);
	(void)putprop(VV[172],VV[Vdeb172],VV[305]);
	putprop(VV[171],VV[172],VV[138]);
	remprop(VV[171],VV[139]);
	remprop(VV[171],VV[140]);
	putprop(VV[171],Cnil,VV[141]);
	MF0(VV[176],L32);
	(void)putprop(VV[176],VV[Vdeb176],VV[305]);
	MF0(VV[177],L33);
	(void)putprop(VV[177],VV[Vdeb177],VV[305]);
	putprop(VV[176],VV[177],VV[138]);
	remprop(VV[176],VV[139]);
	remprop(VV[176],VV[140]);
	putprop(VV[176],Cnil,VV[141]);
	MF0(VV[178],L34);
	(void)putprop(VV[178],VV[Vdeb178],VV[305]);
	MF0(VV[179],L35);
	(void)putprop(VV[179],VV[Vdeb179],VV[305]);
	putprop(VV[178],VV[179],VV[138]);
	remprop(VV[178],VV[139]);
	remprop(VV[178],VV[140]);
	putprop(VV[178],Cnil,VV[141]);
	MF0(VV[180],L36);
	(void)putprop(VV[180],VV[Vdeb180],VV[305]);
	MF0(VV[181],L37);
	(void)putprop(VV[181],VV[Vdeb181],VV[305]);
	putprop(VV[180],VV[181],VV[138]);
	remprop(VV[180],VV[139]);
	remprop(VV[180],VV[140]);
	putprop(VV[180],Cnil,VV[141]);
	MF0(VV[183],L38);
	(void)putprop(VV[183],VV[Vdeb183],VV[305]);
	MF0(VV[184],L39);
	(void)putprop(VV[184],VV[Vdeb184],VV[305]);
	putprop(VV[183],VV[184],VV[138]);
	remprop(VV[183],VV[139]);
	remprop(VV[183],VV[140]);
	putprop(VV[183],Cnil,VV[141]);
	MF0(VV[185],L40);
	(void)putprop(VV[185],VV[Vdeb185],VV[305]);
	MF0(VV[186],L41);
	(void)putprop(VV[186],VV[Vdeb186],VV[305]);
	putprop(VV[185],VV[186],VV[138]);
	remprop(VV[185],VV[139]);
	remprop(VV[185],VV[140]);
	putprop(VV[185],Cnil,VV[141]);
	MF0(VV[190],L42);
	(void)putprop(VV[190],VV[Vdeb190],VV[305]);
	MF0(VV[191],L43);
	(void)putprop(VV[191],VV[Vdeb191],VV[305]);
	putprop(VV[190],VV[191],VV[138]);
	remprop(VV[190],VV[139]);
	remprop(VV[190],VV[140]);
	putprop(VV[190],Cnil,VV[141]);
	MF0(VV[195],L44);
	(void)putprop(VV[195],VV[Vdeb195],VV[305]);
	MF0(VV[196],L45);
	(void)putprop(VV[196],VV[Vdeb196],VV[305]);
	putprop(VV[195],VV[196],VV[138]);
	remprop(VV[195],VV[139]);
	remprop(VV[195],VV[140]);
	putprop(VV[195],Cnil,VV[141]);
	MF0(VV[197],L46);
	(void)putprop(VV[197],VV[Vdeb197],VV[305]);
	MF0(VV[198],L47);
	(void)putprop(VV[198],VV[Vdeb198],VV[305]);
	putprop(VV[197],VV[198],VV[138]);
	remprop(VV[197],VV[139]);
	remprop(VV[197],VV[140]);
	putprop(VV[197],Cnil,VV[141]);
	MF0(VV[199],L48);
	(void)putprop(VV[199],VV[Vdeb199],VV[305]);
	MF0(VV[200],L49);
	(void)putprop(VV[200],VV[Vdeb200],VV[305]);
	putprop(VV[199],VV[200],VV[138]);
	remprop(VV[199],VV[139]);
	remprop(VV[199],VV[140]);
	putprop(VV[199],Cnil,VV[141]);
	MF0(VV[201],L50);
	(void)putprop(VV[201],VV[Vdeb201],VV[305]);
	MF0(VV[202],L51);
	(void)putprop(VV[202],VV[Vdeb202],VV[305]);
	putprop(VV[201],VV[202],VV[138]);
	remprop(VV[201],VV[139]);
	remprop(VV[201],VV[140]);
	putprop(VV[201],Cnil,VV[141]);
	MF0(VV[206],L52);
	(void)putprop(VV[206],VV[Vdeb206],VV[305]);
	MF0(VV[207],L53);
	(void)putprop(VV[207],VV[Vdeb207],VV[305]);
	putprop(VV[206],VV[207],VV[138]);
	remprop(VV[206],VV[139]);
	remprop(VV[206],VV[140]);
	putprop(VV[206],Cnil,VV[141]);
	MF0(VV[210],L54);
	(void)putprop(VV[210],VV[Vdeb210],VV[305]);
	putprop(VV[210],VV[211],VV[139]);
	remprop(VV[210],VV[138]);
	remprop(VV[210],VV[140]);
	putprop(VV[210],Cnil,VV[141]);
	MF0(VV[314],L55);
	(void)putprop(VV[314],VV[Vdeb314],VV[305]);
	MF0(VV[218],L56);
	(void)putprop(VV[218],VV[Vdeb218],VV[305]);
	putprop(VV[218],VV[219],VV[138]);
	remprop(VV[218],VV[139]);
	remprop(VV[218],VV[140]);
	putprop(VV[218],Cnil,VV[141]);
	MF0(VV[219],L57);
	(void)putprop(VV[219],VV[Vdeb219],VV[305]);
	MF0(VV[226],L58);
	(void)putprop(VV[226],VV[Vdeb226],VV[305]);
	putprop(VV[226],VV[227],VV[138]);
	remprop(VV[226],VV[139]);
	remprop(VV[226],VV[140]);
	putprop(VV[226],Cnil,VV[141]);
	MF0(VV[227],L59);
	(void)putprop(VV[227],VV[Vdeb227],VV[305]);
	MF0(VV[315],L60);
	(void)putprop(VV[315],VV[Vdeb315],VV[305]);
	MF0(VV[316],L61);
	(void)putprop(VV[316],VV[Vdeb316],VV[305]);
	VV[234]=string_to_object(VV[234]);
	(void)putprop(VV[317],VV[94],siSpretty_print_format);
	
	MM0(VV[317],L62);
	VV[246]=string_to_object(VV[246]);
	MF0(VV[242],L63);
	(void)putprop(VV[242],VV[Vdeb242],VV[305]);
	MF0(VV[318],L64);
	(void)putprop(VV[318],VV[Vdeb318],VV[305]);
	MF0key(VV[319],L65,26,L65keys);
	(void)putprop(VV[319],VV[Vdeb319],VV[305]);
	MF0(VV[320],L66);
	(void)putprop(VV[320],VV[Vdeb320],VV[305]);
	VV[266]=string_to_object(VV[266]);
	MF0(VV[321],L67);
	(void)putprop(VV[321],VV[Vdeb321],VV[305]);
	MF0(VV[322],L68);
	(void)putprop(VV[322],VV[Vdeb322],VV[305]);
	MM0(VV[323],L69);
	MF0(VV[282],L70);
	(void)putprop(VV[282],VV[Vdeb282],VV[305]);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	local function CLOSURE                                        */
static LC2(int narg)
{ VT3 VLEX3 CLSR3
	VALUES(0) = VV[70];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC1(int narg)
{ VT4 VLEX4 CLSR4
	VALUES(0) = VV[66];
	RETURN(1);
}
/*	function definition for MAKE-GCONTEXT-EXTENSION               */
static L3(int narg, ...)
{ VT5 VLEX5 CLSR5
	{object V1;
	object V2;
	object V3;
	object V4;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[8];
	parse_key(narg,args,4,L3keys,keyvars,OBJNULL,FALSE);
	V1= keyvars[0];
	V2= keyvars[1];
	if(keyvars[6]==Cnil){
	V3= (VV[324]->s.s_gfdef);
	}else{
	V3= keyvars[2];}
	if(keyvars[7]==Cnil){
	V4= (VV[324]->s.s_gfdef);
	}else{
	V4= keyvars[3];}
	}
	RETURN((*LK0)(4,(V1),(V2),(V3),(V4))      /*  VECTOR          */);
	}
}
/*	macro definition for GCONTEXT-STATE-NEXT                      */
static L4(int narg, object V1, object V2)
{ VT6 VLEX6 CLSR6
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(3,VV[79],(V4),MAKE_FIXNUM(0));
	RETURN(1);}
}
/*	function definition for ALLOCATE-GCONTEXT-STATE               */
static L5(int narg)
{ VT7 VLEX7 CLSR7
TTL:
	{volatile int V1;                         /*  LENGTH          */
	V1= (27)+(length((VV[77]->s.s_dbind)));
L305:
	{volatile object V2;                      /*  STATE           */
L311:
	{register object V3;
	V3= (VV[78]->s.s_dbind);
	if(((V3))!=Cnil){
	goto L314;}
	VALUES(0) = Cnil;
	goto L309;
L314:
	if(!(((VV[78]->s.s_dbind))==((V3)))){
	goto L319;}
	(VV[78]->s.s_dbind)= ((V3))->v.v_self[0];
	goto L317;
L319:
	goto L312;
L317:
	((V3))->v.v_self[0]= Cnil;
	VALUES(0) = (V3);
	goto L309;
	}
L312:
	goto L311;
L309:
	if(VALUES(0)==Cnil)goto L308;
	V2= VALUES(0);
	goto L307;
L308:
	(*LK1)(3,MAKE_FIXNUM(V1),VV[80],Cnil)     /*  MAKE-ARRAY      */;
	V2= VALUES(0);
L307:
	if(!((((V2))->v.v_fillp)>=(V1))){
	goto L306;}
	VALUES(0) = (V2);
	RETURN(1);
	}
L306:
	goto L305;
	}
}
/*	function definition for DEALLOCATE-GCONTEXT-STATE             */
static L6(int narg, object V1)
{ VT8 VLEX8 CLSR8
TTL:
	(*LK2)(2,(V1),Cnil)                       /*  FILL            */;
	{volatile object V2;
	V2= (V1);
L330:
	{register object V3;
	V3= (VV[78]->s.s_dbind);
	((V2))->v.v_self[0]= (V3);
	if(!(((VV[78]->s.s_dbind))==((V3)))){
	goto L336;}
	(VV[78]->s.s_dbind)= (V2);
	goto L334;
L336:
	goto L331;
L334:
	VALUES(0) = (V2);
	RETURN(1);
	}
L331:
	goto L330;
	}
}
/*	function definition for ALLOCATE-TEMP-GCONTEXT                */
static L7(int narg)
{ VT9 VLEX9 CLSR9
TTL:
L344:
	{register object V1;
	V1= (VV[81]->s.s_dbind);
	if(((V1))!=Cnil){
	goto L347;}
	VALUES(0) = Cnil;
	goto L342;
L347:
	if(!(((VV[81]->s.s_dbind))==((V1)))){
	goto L352;}
	(VV[81]->s.s_dbind)= ((V1))->in.in_slots[7];
	goto L350;
L352:
	goto L345;
L350:
	((V1))->in.in_slots[7]= Cnil;
	VALUES(0) = (V1);
	goto L342;
	}
L345:
	goto L344;
L342:
	if(VALUES(0)==Cnil)goto L341;
	RETURN(1);
L341:
	RETURN((*LK3)(4,VV[83],VV[84],VV[85],VV[86])/*  MAKE-GCONTEXT */);
}
/*	function definition for DEALLOCATE-TEMP-GCONTEXT              */
static L8(int narg, object V1)
{ VT10 VLEX10 CLSR10
TTL:
	{volatile object V2;
	V2= (V1);
L359:
	{register object V3;
	V3= (VV[81]->s.s_dbind);
	((V2))->in.in_slots[7]= (V3);
	if(!(((VV[81]->s.s_dbind))==((V3)))){
	goto L365;}
	(VV[81]->s.s_dbind)= (V2);
	goto L363;
L365:
	goto L360;
L363:
	VALUES(0) = (V2);
	RETURN(1);
	}
L360:
	goto L359;
	}
}
/*	macro definition for XGCMASK->GCMASK                          */
static L9(int narg, object V1, object V2)
{ VT11 VLEX11 CLSR11
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(3,VV[87],VV[62],list(3,VV[88],(V4),MAKE_FIXNUM(8388607)));
	RETURN(1);}
}
/*	macro definition for ACCESS-GCONTEXT                          */
static L10(int narg, object V1, object V2)
{ VT12 VLEX12 CLSR12
	{object V3=CDR(V1),V4,V5,V6;
	{object V7= CAR(V3);
	V4= CAR(V7);
	V7=CDR(V7);
	V5= CAR(V7);}
	V3=CDR(V3);
	V6= V3;
	{object V8= CONS(list(2,(V5),list(2,VV[90],(V4))),Cnil);
	VALUES(0) = listA(4,VV[89],(V8),list(2,VV[91],list(3,VV[92],VV[93],(V5))),(V6));
	RETURN(1);}}
}
/*	macro definition for MODIFY-GCONTEXT                          */
static L11(int narg, object V1, object V2)
{ VT13 VLEX13 CLSR13
	{object V3=CDR(V1),V4,V5,V6;
	{object V7= CAR(V3);
	V4= CAR(V7);
	V7=CDR(V7);
	V5= CAR(V7);}
	V3=CDR(V3);
	V6= V3;
	{object V8= CONS(list(2,(V5),list(2,VV[90],(V4))),Cnil);
	{object V9= list(2,VV[91],list(3,VV[92],VV[93],(V5)));
	{object V10= CONS(VV[96],(V6));
	VALUES(0) = list(4,VV[89],(V8),(V9),list(3,VV[95],(V10),list(3,VV[97],list(2,VV[55],(V5)),MAKE_FIXNUM(0))));
	RETURN(1);}}}}
}
/*	macro definition for DEF-GC-ACCESSOR                          */
static L12(int narg, object V1, object V2)
{ VT14 VLEX14 CLSR14
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	{object V6;                               /*  GCONTEXT-NAME   */
	object V7;                                /*  INTERNAL-ACCESSOR*/
	object V8;                                /*  INTERNAL-SETFER */
	(*LK4)(2,VV[98],(V4))                     /*  XINTERN         */;
	V6= VALUES(0);
	(*LK4)(2,VV[99],(V4))                     /*  XINTERN         */;
	V7= VALUES(0);
	(*LK4)(2,VV[100],(V6))                    /*  XINTERN         */;
	V8= VALUES(0);
	{object V9= list(2,(V4),VV[102]);
	{object V10= list(2,VV[91],list(2,VV[106],list(3,VV[107],VV[108],(V5))));
	{object V11= CONS(list(2,VV[109],list(2,(V7),VV[110])),Cnil);
	{object V12= list(6,VV[103],(V6),VV[104],VV[105],(V10),list(4,VV[89],(V11),VV[111],list(3,VV[112],VV[109],list(5,VV[89],VV[113],VV[114],VV[115],list(3,VV[116],(V5),VV[109])))));
	{object V13= list(3,VV[91],VV[118],list(3,VV[92],(V5),VV[109]));
	{object V14= list(2,(V7),VV[121]);
	{object V15= list(3,VV[97],(V14),list(3,VV[122],(V5),VV[109]));
	if(!(((V5))==(VV[123]))){
	goto L375;}
	VALUES(0) = CONS(list(3,VV[89],VV[124],list(3,VV[97],list(2,(V7),VV[125]),Cnil)),Cnil);
	goto L373;
L375:
	VALUES(0) = Cnil;
L373:
	{object V16= list(5,VV[103],(V8),VV[117],(V13),listA(4,VV[119],VV[120],(V15),append(VALUES(0),VV[126])));
	VALUES(0) = list(5,VV[101],(V9),(V12),(V16),list(3,VV[127],(V6),(V8)));
	RETURN(1);}}}}}}}}
	}}
}
/*	macro definition for INCF-INTERNAL-TIMESTAMP                  */
static L13(int narg, object V1, object V2)
{ VT15 VLEX15 CLSR15
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	{register object V5;                      /*  TS              */
	Lgensym(0)                                /*  GENSYM          */;
	V5= VALUES(0);
	{object V6= CONS(list(2,(V5),list(3,VV[87],VV[128],list(2,VV[55],(V4)))),Cnil);
	{object V7= list(2,VV[91],list(3,VV[92],VV[128],(V5)));
	{object V8= list(3,VV[131],(V5),VV[132]);
	{object V9= list(3,VV[129],(V5),list(4,VV[130],(V8),MAKE_FIXNUM(1),list(3,VV[87],VV[128],list(2,VV[133],(V5)))));
	VALUES(0) = list(5,VV[89],(V6),(V7),(V9),list(3,VV[97],list(2,VV[55],(V4)),(V5)));
	RETURN(1);}}}}
	}}
}
/*	function definition for GCONTEXT-FUNCTION                     */
static L14(int narg, object V1)
{ VT16 VLEX16 CLSR16
TTL:
	{object V2;                               /*  VALUE           */
	V2= (((V1))->in.in_slots[5])->v.v_self[0];
	if(((V2))==Cnil){
	goto L380;}
	{object V3;                               /*  %BUFFER         */
	V3= ((V1))->in.in_slots[1];
	{int V4;
	V4= fix((V2));
	if((V4)<(16)){
	goto L385;}
	VALUES(0) = Cnil;
	RETURN(1);
L385:
	VALUES(0) = (VV[134])->v.v_self[V4];
	RETURN(1);
	}
	}
L380:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-GCONTEXT-FUNCTION                 */
static L15(int narg, object V1, object V2)
{ VT17 VLEX17 CLSR17
	{int V3;
	V3= fix(V2);
TTL:
	{object V4;                               /*  LOCAL-STATE     */
	V4= ((V1))->in.in_slots[5];
	{int V5;
	{int V6;
	(*LK5)(2,MAKE_FIXNUM(V3),VV[134])         /*  POSITION        */;
	V6= fix(VALUES(0));
	if(MAKE_FIXNUM(V6)==Cnil){
	VALUES(0) = Cnil;
	goto L392;}
	VALUES(0) = MAKE_FIXNUM(V6);
	}
L392:
	if(VALUES(0)==Cnil)goto L391;
	goto L390;
L391:
	(*LK6)(2,MAKE_FIXNUM(V3),VV[135])         /*  X-TYPE-ERROR    */;
L390:
	((V4))->v.v_self[0]= VALUES(0);
	V5= V3;
	((V4))->v.v_self[26]= MAKE_FIXNUM(0);
	VALUES(0) = MAKE_FIXNUM(V5);
	RETURN(1);
	}
	}
	}
}
/*	function definition for GCONTEXT-PLANE-MASK                   */
static L16(int narg, object V1)
{ VT18 VLEX18 CLSR18
TTL:
	{object V2;                               /*  VALUE           */
	V2= (((V1))->in.in_slots[5])->v.v_self[1];
	if(((V2))==Cnil){
	goto L397;}
	{object V3;                               /*  %BUFFER         */
	V3= ((V1))->in.in_slots[1];
	VALUES(0) = (V2);
	RETURN(1);
	}
L397:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-GCONTEXT-PLANE-MASK               */
static L17(int narg, object V1, object V2)
{ VT19 VLEX19 CLSR19
TTL:
	{object V3;                               /*  LOCAL-STATE     */
	V3= ((V1))->in.in_slots[5];
	{object V4;
	(*LK7)(2,(V2),VV[142])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L406;}
	VALUES(0) = (V2);
	goto L404;
L406:
	(*LK6)(2,(V2),VV[142])                    /*  X-TYPE-ERROR    */;
L404:
	((V3))->v.v_self[1]= VALUES(0);
	V4= (V2);
	((V3))->v.v_self[26]= MAKE_FIXNUM(0);
	VALUES(0) = (V4);
	RETURN(1);
	}
	}
}
/*	function definition for GCONTEXT-FOREGROUND                   */
static L18(int narg, object V1)
{ VT20 VLEX20 CLSR20
TTL:
	{object V2;                               /*  VALUE           */
	V2= (((V1))->in.in_slots[5])->v.v_self[2];
	if(((V2))==Cnil){
	goto L411;}
	{object V3;                               /*  %BUFFER         */
	V3= ((V1))->in.in_slots[1];
	VALUES(0) = (V2);
	RETURN(1);
	}
L411:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-GCONTEXT-FOREGROUND               */
static L19(int narg, object V1, object V2)
{ VT21 VLEX21 CLSR21
TTL:
	{object V3;                               /*  LOCAL-STATE     */
	V3= ((V1))->in.in_slots[5];
	{object V4;
	(*LK7)(2,(V2),VV[142])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L420;}
	VALUES(0) = (V2);
	goto L418;
L420:
	(*LK6)(2,(V2),VV[142])                    /*  X-TYPE-ERROR    */;
L418:
	((V3))->v.v_self[2]= VALUES(0);
	V4= (V2);
	((V3))->v.v_self[26]= MAKE_FIXNUM(0);
	VALUES(0) = (V4);
	RETURN(1);
	}
	}
}
/*	function definition for GCONTEXT-BACKGROUND                   */
static L20(int narg, object V1)
{ VT22 VLEX22 CLSR22
TTL:
	{object V2;                               /*  VALUE           */
	V2= (((V1))->in.in_slots[5])->v.v_self[3];
	if(((V2))==Cnil){
	goto L425;}
	{object V3;                               /*  %BUFFER         */
	V3= ((V1))->in.in_slots[1];
	VALUES(0) = (V2);
	RETURN(1);
	}
L425:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-GCONTEXT-BACKGROUND               */
static L21(int narg, object V1, object V2)
{ VT23 VLEX23 CLSR23
TTL:
	{object V3;                               /*  LOCAL-STATE     */
	V3= ((V1))->in.in_slots[5];
	{object V4;
	(*LK7)(2,(V2),VV[142])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L434;}
	VALUES(0) = (V2);
	goto L432;
L434:
	(*LK6)(2,(V2),VV[142])                    /*  X-TYPE-ERROR    */;
L432:
	((V3))->v.v_self[3]= VALUES(0);
	V4= (V2);
	((V3))->v.v_self[26]= MAKE_FIXNUM(0);
	VALUES(0) = (V4);
	RETURN(1);
	}
	}
}
/*	function definition for GCONTEXT-LINE-WIDTH                   */
static L22(int narg, object V1)
{ VT24 VLEX24 CLSR24
TTL:
	{object V2;                               /*  VALUE           */
	V2= (((V1))->in.in_slots[5])->v.v_self[4];
	if(((V2))==Cnil){
	goto L439;}
	{object V3;                               /*  %BUFFER         */
	V3= ((V1))->in.in_slots[1];
	VALUES(0) = (V2);
	RETURN(1);
	}
L439:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-GCONTEXT-LINE-WIDTH               */
static L23(int narg, object V1, object V2)
{ VT25 VLEX25 CLSR25
	{register int V3;
	V3= fix(V2);
TTL:
	{object V4;                               /*  LOCAL-STATE     */
	V4= ((V1))->in.in_slots[5];
	{int V5;
	(*LK7)(2,MAKE_FIXNUM(V3),VV[149])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L448;}
	VALUES(0) = MAKE_FIXNUM(V3);
	goto L446;
L448:
	(*LK6)(2,MAKE_FIXNUM(V3),VV[149])         /*  X-TYPE-ERROR    */;
L446:
	((V4))->v.v_self[4]= VALUES(0);
	V5= V3;
	((V4))->v.v_self[26]= MAKE_FIXNUM(0);
	VALUES(0) = MAKE_FIXNUM(V5);
	RETURN(1);
	}
	}
	}
}
/*	function definition for GCONTEXT-LINE-STYLE                   */
static L24(int narg, object V1)
{ VT26 VLEX26 CLSR26
TTL:
	{object V2;                               /*  VALUE           */
	V2= (((V1))->in.in_slots[5])->v.v_self[5];
	if(((V2))==Cnil){
	goto L453;}
	{object V3;                               /*  %BUFFER         */
	V3= ((V1))->in.in_slots[1];
	{int V4;
	V4= fix((V2));
	if((V4)<(3)){
	goto L458;}
	VALUES(0) = Cnil;
	RETURN(1);
L458:
	VALUES(0) = (VV[152])->v.v_self[V4];
	RETURN(1);
	}
	}
L453:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-GCONTEXT-LINE-STYLE               */
static L25(int narg, object V1, object V2)
{ VT27 VLEX27 CLSR27
TTL:
	{object V3;                               /*  LOCAL-STATE     */
	V3= ((V1))->in.in_slots[5];
	{object V4;
	{int V5;
	VALUES(0) = (VV[347]->s.s_gfdef);
	(*LK5)(4,(V2),VV[153],VV[154],VALUES(0))  /*  POSITION        */;
	V5= fix(VALUES(0));
	if(MAKE_FIXNUM(V5)==Cnil){
	VALUES(0) = Cnil;
	goto L465;}
	VALUES(0) = MAKE_FIXNUM(V5);
	}
L465:
	if(VALUES(0)==Cnil)goto L464;
	goto L463;
L464:
	(*LK6)(2,(V2),VV[155])                    /*  X-TYPE-ERROR    */;
L463:
	((V3))->v.v_self[5]= VALUES(0);
	V4= (V2);
	((V3))->v.v_self[26]= MAKE_FIXNUM(0);
	VALUES(0) = (V4);
	RETURN(1);
	}
	}
}
/*	function definition for GCONTEXT-CAP-STYLE                    */
static L26(int narg, object V1)
{ VT28 VLEX28 CLSR28
TTL:
	{object V2;                               /*  VALUE           */
	V2= (((V1))->in.in_slots[5])->v.v_self[6];
	if(((V2))==Cnil){
	goto L471;}
	{object V3;                               /*  %BUFFER         */
	V3= ((V1))->in.in_slots[1];
	{int V4;
	V4= fix((V2));
	if((V4)<(4)){
	goto L476;}
	VALUES(0) = Cnil;
	RETURN(1);
L476:
	VALUES(0) = (VV[158])->v.v_self[V4];
	RETURN(1);
	}
	}
L471:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-GCONTEXT-CAP-STYLE                */
static L27(int narg, object V1, object V2)
{ VT29 VLEX29 CLSR29
TTL:
	{object V3;                               /*  LOCAL-STATE     */
	V3= ((V1))->in.in_slots[5];
	{object V4;
	{int V5;
	VALUES(0) = (VV[347]->s.s_gfdef);
	(*LK5)(4,(V2),VV[159],VV[154],VALUES(0))  /*  POSITION        */;
	V5= fix(VALUES(0));
	if(MAKE_FIXNUM(V5)==Cnil){
	VALUES(0) = Cnil;
	goto L483;}
	VALUES(0) = MAKE_FIXNUM(V5);
	}
L483:
	if(VALUES(0)==Cnil)goto L482;
	goto L481;
L482:
	(*LK6)(2,(V2),VV[160])                    /*  X-TYPE-ERROR    */;
L481:
	((V3))->v.v_self[6]= VALUES(0);
	V4= (V2);
	((V3))->v.v_self[26]= MAKE_FIXNUM(0);
	VALUES(0) = (V4);
	RETURN(1);
	}
	}
}
/*	function definition for GCONTEXT-JOIN-STYLE                   */
static L28(int narg, object V1)
{ VT30 VLEX30 CLSR30
TTL:
	{object V2;                               /*  VALUE           */
	V2= (((V1))->in.in_slots[5])->v.v_self[7];
	if(((V2))==Cnil){
	goto L489;}
	{object V3;                               /*  %BUFFER         */
	V3= ((V1))->in.in_slots[1];
	{int V4;
	V4= fix((V2));
	if((V4)<(3)){
	goto L494;}
	VALUES(0) = Cnil;
	RETURN(1);
L494:
	VALUES(0) = (VV[163])->v.v_self[V4];
	RETURN(1);
	}
	}
L489:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-GCONTEXT-JOIN-STYLE               */
static L29(int narg, object V1, object V2)
{ VT31 VLEX31 CLSR31
TTL:
	{object V3;                               /*  LOCAL-STATE     */
	V3= ((V1))->in.in_slots[5];
	{object V4;
	{int V5;
	VALUES(0) = (VV[347]->s.s_gfdef);
	(*LK5)(4,(V2),VV[164],VV[154],VALUES(0))  /*  POSITION        */;
	V5= fix(VALUES(0));
	if(MAKE_FIXNUM(V5)==Cnil){
	VALUES(0) = Cnil;
	goto L501;}
	VALUES(0) = MAKE_FIXNUM(V5);
	}
L501:
	if(VALUES(0)==Cnil)goto L500;
	goto L499;
L500:
	(*LK6)(2,(V2),VV[165])                    /*  X-TYPE-ERROR    */;
L499:
	((V3))->v.v_self[7]= VALUES(0);
	V4= (V2);
	((V3))->v.v_self[26]= MAKE_FIXNUM(0);
	VALUES(0) = (V4);
	RETURN(1);
	}
	}
}
/*	function definition for GCONTEXT-FILL-STYLE                   */
static L30(int narg, object V1)
{ VT32 VLEX32 CLSR32
TTL:
	{object V2;                               /*  VALUE           */
	V2= (((V1))->in.in_slots[5])->v.v_self[8];
	if(((V2))==Cnil){
	goto L507;}
	{object V3;                               /*  %BUFFER         */
	V3= ((V1))->in.in_slots[1];
	{int V4;
	V4= fix((V2));
	if((V4)<(4)){
	goto L512;}
	VALUES(0) = Cnil;
	RETURN(1);
L512:
	VALUES(0) = (VV[168])->v.v_self[V4];
	RETURN(1);
	}
	}
L507:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-GCONTEXT-FILL-STYLE               */
static L31(int narg, object V1, object V2)
{ VT33 VLEX33 CLSR33
TTL:
	{object V3;                               /*  LOCAL-STATE     */
	V3= ((V1))->in.in_slots[5];
	{object V4;
	{int V5;
	VALUES(0) = (VV[347]->s.s_gfdef);
	(*LK5)(4,(V2),VV[169],VV[154],VALUES(0))  /*  POSITION        */;
	V5= fix(VALUES(0));
	if(MAKE_FIXNUM(V5)==Cnil){
	VALUES(0) = Cnil;
	goto L519;}
	VALUES(0) = MAKE_FIXNUM(V5);
	}
L519:
	if(VALUES(0)==Cnil)goto L518;
	goto L517;
L518:
	(*LK6)(2,(V2),VV[170])                    /*  X-TYPE-ERROR    */;
L517:
	((V3))->v.v_self[8]= VALUES(0);
	V4= (V2);
	((V3))->v.v_self[26]= MAKE_FIXNUM(0);
	VALUES(0) = (V4);
	RETURN(1);
	}
	}
}
/*	function definition for GCONTEXT-FILL-RULE                    */
static L32(int narg, object V1)
{ VT34 VLEX34 CLSR34
TTL:
	{object V2;                               /*  VALUE           */
	V2= (((V1))->in.in_slots[5])->v.v_self[9];
	if(((V2))==Cnil){
	goto L525;}
	{object V3;                               /*  %BUFFER         */
	V3= ((V1))->in.in_slots[1];
	{int V4;
	V4= fix((V2));
	if((V4)<(2)){
	goto L530;}
	VALUES(0) = Cnil;
	RETURN(1);
L530:
	VALUES(0) = (VV[173])->v.v_self[V4];
	RETURN(1);
	}
	}
L525:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-GCONTEXT-FILL-RULE                */
static L33(int narg, object V1, object V2)
{ VT35 VLEX35 CLSR35
TTL:
	{object V3;                               /*  LOCAL-STATE     */
	V3= ((V1))->in.in_slots[5];
	{object V4;
	{int V5;
	VALUES(0) = (VV[347]->s.s_gfdef);
	(*LK5)(4,(V2),VV[174],VV[154],VALUES(0))  /*  POSITION        */;
	V5= fix(VALUES(0));
	if(MAKE_FIXNUM(V5)==Cnil){
	VALUES(0) = Cnil;
	goto L537;}
	VALUES(0) = MAKE_FIXNUM(V5);
	}
L537:
	if(VALUES(0)==Cnil)goto L536;
	goto L535;
L536:
	(*LK6)(2,(V2),VV[175])                    /*  X-TYPE-ERROR    */;
L535:
	((V3))->v.v_self[9]= VALUES(0);
	V4= (V2);
	((V3))->v.v_self[26]= MAKE_FIXNUM(0);
	VALUES(0) = (V4);
	RETURN(1);
	}
	}
}
/*	function definition for GCONTEXT-TILE                         */
static L34(int narg, object V1)
{ VT36 VLEX36 CLSR36
TTL:
	{object V2;                               /*  VALUE           */
	V2= (((V1))->in.in_slots[5])->v.v_self[10];
	if(((V2))==Cnil){
	goto L543;}
	{object V3;                               /*  %BUFFER         */
	V3= ((V1))->in.in_slots[1];
	RETURN((*LK8)(2,(V3),(V2))                /*  LOOKUP-PIXMAP   */);
	}
L543:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-GCONTEXT-TILE                     */
static L35(int narg, object V1, object V2)
{ VT37 VLEX37 CLSR37
TTL:
	{object V3;                               /*  LOCAL-STATE     */
	V3= ((V1))->in.in_slots[5];
	{object V4;
	(*LK9)(1,(V2))                            /*  PIXMAP-P        */;
	if(VALUES(0)==Cnil){
	goto L552;}
	VALUES(0) = ((V2))->in.in_slots[0];
	goto L550;
L552:
	(*LK6)(2,(V2),VV[123])                    /*  X-TYPE-ERROR    */;
L550:
	((V3))->v.v_self[10]= VALUES(0);
	{object V5;                               /*  SERVER-STATE    */
	V5= ((V1))->in.in_slots[4];
	((V5))->v.v_self[10]= Cnil;
	}
	V4= (V2);
	((V3))->v.v_self[26]= MAKE_FIXNUM(0);
	VALUES(0) = (V4);
	RETURN(1);
	}
	}
}
/*	function definition for GCONTEXT-STIPPLE                      */
static L36(int narg, object V1)
{ VT38 VLEX38 CLSR38
TTL:
	{object V2;                               /*  VALUE           */
	V2= (((V1))->in.in_slots[5])->v.v_self[11];
	if(((V2))==Cnil){
	goto L559;}
	{object V3;                               /*  %BUFFER         */
	V3= ((V1))->in.in_slots[1];
	RETURN((*LK8)(2,(V3),(V2))                /*  LOOKUP-PIXMAP   */);
	}
L559:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-GCONTEXT-STIPPLE                  */
static L37(int narg, object V1, object V2)
{ VT39 VLEX39 CLSR39
TTL:
	{object V3;                               /*  LOCAL-STATE     */
	V3= ((V1))->in.in_slots[5];
	{object V4;
	(*LK9)(1,(V2))                            /*  PIXMAP-P        */;
	if(VALUES(0)==Cnil){
	goto L568;}
	VALUES(0) = ((V2))->in.in_slots[0];
	goto L566;
L568:
	(*LK6)(2,(V2),VV[123])                    /*  X-TYPE-ERROR    */;
L566:
	((V3))->v.v_self[11]= VALUES(0);
	{object V5;                               /*  SERVER-STATE    */
	V5= ((V1))->in.in_slots[4];
	((V5))->v.v_self[11]= Cnil;
	}
	V4= (V2);
	((V3))->v.v_self[26]= MAKE_FIXNUM(0);
	VALUES(0) = (V4);
	RETURN(1);
	}
	}
}
/*	function definition for GCONTEXT-TS-X                         */
static L38(int narg, object V1)
{ VT40 VLEX40 CLSR40
TTL:
	{object V2;                               /*  VALUE           */
	V2= (((V1))->in.in_slots[5])->v.v_self[12];
	if(((V2))==Cnil){
	goto L575;}
	{object V3;                               /*  %BUFFER         */
	V3= ((V1))->in.in_slots[1];
	VALUES(0) = MAKE_FIXNUM(((short)(fix((V2)))));
	RETURN(1);
	}
L575:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-GCONTEXT-TS-X                     */
static L39(int narg, object V1, object V2)
{ VT41 VLEX41 CLSR41
	{register int V3;
	V3= fix(V2);
TTL:
	{object V4;                               /*  LOCAL-STATE     */
	V4= ((V1))->in.in_slots[5];
	{int V5;
	(*LK7)(2,MAKE_FIXNUM(V3),VV[182])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L584;}
	VALUES(0) = MAKE_FIXNUM(((unsigned short)(V3)));
	goto L582;
L584:
	(*LK6)(2,MAKE_FIXNUM(V3),VV[182])         /*  X-TYPE-ERROR    */;
L582:
	((V4))->v.v_self[12]= VALUES(0);
	V5= V3;
	((V4))->v.v_self[26]= MAKE_FIXNUM(0);
	VALUES(0) = MAKE_FIXNUM(V5);
	RETURN(1);
	}
	}
	}
}
/*	function definition for GCONTEXT-TS-Y                         */
static L40(int narg, object V1)
{ VT42 VLEX42 CLSR42
TTL:
	{object V2;                               /*  VALUE           */
	V2= (((V1))->in.in_slots[5])->v.v_self[13];
	if(((V2))==Cnil){
	goto L589;}
	{object V3;                               /*  %BUFFER         */
	V3= ((V1))->in.in_slots[1];
	VALUES(0) = MAKE_FIXNUM(((short)(fix((V2)))));
	RETURN(1);
	}
L589:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-GCONTEXT-TS-Y                     */
static L41(int narg, object V1, object V2)
{ VT43 VLEX43 CLSR43
	{register int V3;
	V3= fix(V2);
TTL:
	{object V4;                               /*  LOCAL-STATE     */
	V4= ((V1))->in.in_slots[5];
	{int V5;
	(*LK7)(2,MAKE_FIXNUM(V3),VV[182])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L598;}
	VALUES(0) = MAKE_FIXNUM(((unsigned short)(V3)));
	goto L596;
L598:
	(*LK6)(2,MAKE_FIXNUM(V3),VV[182])         /*  X-TYPE-ERROR    */;
L596:
	((V4))->v.v_self[13]= VALUES(0);
	V5= V3;
	((V4))->v.v_self[26]= MAKE_FIXNUM(0);
	VALUES(0) = MAKE_FIXNUM(V5);
	RETURN(1);
	}
	}
	}
}
/*	function definition for GCONTEXT-SUBWINDOW-MODE               */
static L42(int narg, object V1)
{ VT44 VLEX44 CLSR44
TTL:
	{object V2;                               /*  VALUE           */
	V2= (((V1))->in.in_slots[5])->v.v_self[15];
	if(((V2))==Cnil){
	goto L603;}
	{object V3;                               /*  %BUFFER         */
	V3= ((V1))->in.in_slots[1];
	{int V4;
	V4= fix((V2));
	if((V4)<(2)){
	goto L608;}
	VALUES(0) = Cnil;
	RETURN(1);
L608:
	VALUES(0) = (VV[187])->v.v_self[V4];
	RETURN(1);
	}
	}
L603:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-GCONTEXT-SUBWINDOW-MODE           */
static L43(int narg, object V1, object V2)
{ VT45 VLEX45 CLSR45
TTL:
	{object V3;                               /*  LOCAL-STATE     */
	V3= ((V1))->in.in_slots[5];
	{object V4;
	{int V5;
	VALUES(0) = (VV[347]->s.s_gfdef);
	(*LK5)(4,(V2),VV[188],VV[154],VALUES(0))  /*  POSITION        */;
	V5= fix(VALUES(0));
	if(MAKE_FIXNUM(V5)==Cnil){
	VALUES(0) = Cnil;
	goto L615;}
	VALUES(0) = MAKE_FIXNUM(V5);
	}
L615:
	if(VALUES(0)==Cnil)goto L614;
	goto L613;
L614:
	(*LK6)(2,(V2),VV[189])                    /*  X-TYPE-ERROR    */;
L613:
	((V3))->v.v_self[15]= VALUES(0);
	V4= (V2);
	((V3))->v.v_self[26]= MAKE_FIXNUM(0);
	VALUES(0) = (V4);
	RETURN(1);
	}
	}
}
/*	function definition for GCONTEXT-EXPOSURES                    */
static L44(int narg, object V1)
{ VT46 VLEX46 CLSR46
TTL:
	{object V2;                               /*  VALUE           */
	V2= (((V1))->in.in_slots[5])->v.v_self[16];
	if(((V2))==Cnil){
	goto L621;}
	{object V3;                               /*  %BUFFER         */
	V3= ((V1))->in.in_slots[1];
	{int V4;
	V4= fix((V2));
	if((V4)<(2)){
	goto L626;}
	VALUES(0) = Cnil;
	RETURN(1);
L626:
	VALUES(0) = (VV[192])->v.v_self[V4];
	RETURN(1);
	}
	}
L621:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-GCONTEXT-EXPOSURES                */
static L45(int narg, object V1, object V2)
{ VT47 VLEX47 CLSR47
TTL:
	{object V3;                               /*  LOCAL-STATE     */
	V3= ((V1))->in.in_slots[5];
	{object V4;
	{int V5;
	VALUES(0) = (VV[347]->s.s_gfdef);
	(*LK5)(4,(V2),VV[193],VV[154],VALUES(0))  /*  POSITION        */;
	V5= fix(VALUES(0));
	if(MAKE_FIXNUM(V5)==Cnil){
	VALUES(0) = Cnil;
	goto L633;}
	VALUES(0) = MAKE_FIXNUM(V5);
	}
L633:
	if(VALUES(0)==Cnil)goto L632;
	goto L631;
L632:
	(*LK6)(2,(V2),VV[194])                    /*  X-TYPE-ERROR    */;
L631:
	((V3))->v.v_self[16]= VALUES(0);
	V4= (V2);
	((V3))->v.v_self[26]= MAKE_FIXNUM(0);
	VALUES(0) = (V4);
	RETURN(1);
	}
	}
}
/*	function definition for GCONTEXT-CLIP-X                       */
static L46(int narg, object V1)
{ VT48 VLEX48 CLSR48
TTL:
	{object V2;                               /*  VALUE           */
	V2= (((V1))->in.in_slots[5])->v.v_self[17];
	if(((V2))==Cnil){
	goto L639;}
	{object V3;                               /*  %BUFFER         */
	V3= ((V1))->in.in_slots[1];
	VALUES(0) = MAKE_FIXNUM(((short)(fix((V2)))));
	RETURN(1);
	}
L639:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-GCONTEXT-CLIP-X                   */
static L47(int narg, object V1, object V2)
{ VT49 VLEX49 CLSR49
	{register int V3;
	V3= fix(V2);
TTL:
	{object V4;                               /*  LOCAL-STATE     */
	V4= ((V1))->in.in_slots[5];
	{int V5;
	(*LK7)(2,MAKE_FIXNUM(V3),VV[182])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L648;}
	VALUES(0) = MAKE_FIXNUM(((unsigned short)(V3)));
	goto L646;
L648:
	(*LK6)(2,MAKE_FIXNUM(V3),VV[182])         /*  X-TYPE-ERROR    */;
L646:
	((V4))->v.v_self[17]= VALUES(0);
	V5= V3;
	((V4))->v.v_self[26]= MAKE_FIXNUM(0);
	VALUES(0) = MAKE_FIXNUM(V5);
	RETURN(1);
	}
	}
	}
}
/*	function definition for GCONTEXT-CLIP-Y                       */
static L48(int narg, object V1)
{ VT50 VLEX50 CLSR50
TTL:
	{object V2;                               /*  VALUE           */
	V2= (((V1))->in.in_slots[5])->v.v_self[18];
	if(((V2))==Cnil){
	goto L653;}
	{object V3;                               /*  %BUFFER         */
	V3= ((V1))->in.in_slots[1];
	VALUES(0) = MAKE_FIXNUM(((short)(fix((V2)))));
	RETURN(1);
	}
L653:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-GCONTEXT-CLIP-Y                   */
static L49(int narg, object V1, object V2)
{ VT51 VLEX51 CLSR51
	{register int V3;
	V3= fix(V2);
TTL:
	{object V4;                               /*  LOCAL-STATE     */
	V4= ((V1))->in.in_slots[5];
	{int V5;
	(*LK7)(2,MAKE_FIXNUM(V3),VV[182])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L662;}
	VALUES(0) = MAKE_FIXNUM(((unsigned short)(V3)));
	goto L660;
L662:
	(*LK6)(2,MAKE_FIXNUM(V3),VV[182])         /*  X-TYPE-ERROR    */;
L660:
	((V4))->v.v_self[18]= VALUES(0);
	V5= V3;
	((V4))->v.v_self[26]= MAKE_FIXNUM(0);
	VALUES(0) = MAKE_FIXNUM(V5);
	RETURN(1);
	}
	}
	}
}
/*	function definition for GCONTEXT-DASH-OFFSET                  */
static L50(int narg, object V1)
{ VT52 VLEX52 CLSR52
TTL:
	{object V2;                               /*  VALUE           */
	V2= (((V1))->in.in_slots[5])->v.v_self[20];
	if(((V2))==Cnil){
	goto L667;}
	{object V3;                               /*  %BUFFER         */
	V3= ((V1))->in.in_slots[1];
	VALUES(0) = (V2);
	RETURN(1);
	}
L667:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-GCONTEXT-DASH-OFFSET              */
static L51(int narg, object V1, object V2)
{ VT53 VLEX53 CLSR53
	{register int V3;
	V3= fix(V2);
TTL:
	{object V4;                               /*  LOCAL-STATE     */
	V4= ((V1))->in.in_slots[5];
	{int V5;
	(*LK7)(2,MAKE_FIXNUM(V3),VV[149])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L676;}
	VALUES(0) = MAKE_FIXNUM(V3);
	goto L674;
L676:
	(*LK6)(2,MAKE_FIXNUM(V3),VV[149])         /*  X-TYPE-ERROR    */;
L674:
	((V4))->v.v_self[20]= VALUES(0);
	V5= V3;
	((V4))->v.v_self[26]= MAKE_FIXNUM(0);
	VALUES(0) = MAKE_FIXNUM(V5);
	RETURN(1);
	}
	}
	}
}
/*	function definition for GCONTEXT-ARC-MODE                     */
static L52(int narg, object V1)
{ VT54 VLEX54 CLSR54
TTL:
	{object V2;                               /*  VALUE           */
	V2= (((V1))->in.in_slots[5])->v.v_self[22];
	if(((V2))==Cnil){
	goto L681;}
	{object V3;                               /*  %BUFFER         */
	V3= ((V1))->in.in_slots[1];
	{int V4;
	V4= fix((V2));
	if((V4)<(2)){
	goto L686;}
	VALUES(0) = Cnil;
	RETURN(1);
L686:
	VALUES(0) = (VV[203])->v.v_self[V4];
	RETURN(1);
	}
	}
L681:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-GCONTEXT-ARC-MODE                 */
static L53(int narg, object V1, object V2)
{ VT55 VLEX55 CLSR55
TTL:
	{object V3;                               /*  LOCAL-STATE     */
	V3= ((V1))->in.in_slots[5];
	{object V4;
	{int V5;
	VALUES(0) = (VV[347]->s.s_gfdef);
	(*LK5)(4,(V2),VV[204],VV[154],VALUES(0))  /*  POSITION        */;
	V5= fix(VALUES(0));
	if(MAKE_FIXNUM(V5)==Cnil){
	VALUES(0) = Cnil;
	goto L693;}
	VALUES(0) = MAKE_FIXNUM(V5);
	}
L693:
	if(VALUES(0)==Cnil)goto L692;
	goto L691;
L692:
	(*LK6)(2,(V2),VV[205])                    /*  X-TYPE-ERROR    */;
L691:
	((V3))->v.v_self[22]= VALUES(0);
	V4= (V2);
	((V3))->v.v_self[26]= MAKE_FIXNUM(0);
	VALUES(0) = (V4);
	RETURN(1);
	}
	}
}
/*	function definition for GCONTEXT-CLIP-MASK                    */
static L54(int narg, object V1)
{ VT56 VLEX56 CLSR56
TTL:
	{object V2;                               /*  LOCAL-STATE     */
	V2= ((V1))->in.in_slots[5];
	{ int V3;
	object V4;                                /*  CLIP            */
	object V5;                                /*  CLIP-MASK       */
	VALUES(1) = ((V2))->v.v_self[19];
	VALUES(0) = ((V2))->v.v_self[23];
	V3=2;
	if (V3--==0) goto L699;
	V4= VALUES(0);
	if (V3--==0) goto L700;
	V5= VALUES(1);
	goto L701;
L699:
	V4= Cnil;
L700:
	V5= Cnil;
L701:
	if(((V4))!=Cnil){
	goto L703;}
	{object V6;                               /*  %BUFFER         */
	V6= ((V1))->in.in_slots[1];
	{object V7;
	{object V8;
	{int V9;
	V9= fix((V5));
	if((V9)<(1)){
	goto L709;}
	V8= Cnil;
	goto L707;
L709:
	V8= (VV[208])->v.v_self[V9];
	}
L707:
	if(((V8))==Cnil){
	goto L712;}
	VALUES(0) = (V8);
	goto L705;
L712:
	{object V9;
	(*LK8)(2,(V6),(V5))                       /*  LOOKUP-PIXMAP   */;
	V9= VALUES(0);
	if(((V9))==Cnil){
	goto L716;}
	VALUES(0) = (V9);
	goto L705;
L716:
	VALUES(0) = Cnil;
	}
	}
	}
	}
L705:
	VALUES(1) = Cnil;
	VALUES(0) = VALUES(0);
	RETURN(2);
L703:
	{object V6= CADR((V4));
	{object V7;
	V7= CAR((V4));
	if(!(number_compare(MAKE_FIXNUM(0),(V7))==0)){
	goto L721;}
	VALUES(0) = Cnil;
	goto L718;
L721:
	{object V8;
	{int V9;
	V9= fix((V7));
	if((V9)<(4)){
	goto L725;}
	V8= Cnil;
	goto L723;
L725:
	V8= (VV[209])->v.v_self[V9];
	}
L723:
	if(((V8))==Cnil){
	goto L728;}
	VALUES(0) = (V8);
	goto L718;
L728:
	VALUES(0) = Cnil;
	}
	}
L718:
	VALUES(1) = VALUES(0);
	VALUES(0) = (V6);
	RETURN(2);}}
	}
}
/*	function definition for SET-GCONTEXT-CLIP-MASK                */
static L55(int narg, object V1, object V2, object V3)
{ VT57 VLEX57 CLSR57
TTL:
	if(((V3))!=Cnil){
	goto L730;}
	(*LK6)(2,(V3),VV[212])                    /*  X-TYPE-ERROR    */;
L730:
	{ int V4;
	object V5;                                /*  CLIP-MASK       */
	object V6;                                /*  CLIP            */
	{object V7;
	V7= (V3);
	(*LK7)(2,(V7),VV[123])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L736;}
	VALUES(1) = Cnil;
	VALUES(0) = ((V3))->in.in_slots[0];
	V4=2;
	goto L734;
L736:
	(*LK7)(2,(V7),VV[213])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L739;}
	VALUES(1) = Cnil;
	VALUES(0) = MAKE_FIXNUM(0);
	V4=2;
	goto L734;
L739:
	(*LK7)(2,(V7),VV[214])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L742;}
	if(!((V2)==Cnil)){
	goto L746;}
	T0= MAKE_FIXNUM(0);
	goto L744;
L746:
	{object V8;
	{int V9;
	VALUES(0) = (VV[347]->s.s_gfdef);
	(*LK5)(4,(V2),VV[215],VV[154],VALUES(0))  /*  POSITION        */;
	V9= fix(VALUES(0));
	if(MAKE_FIXNUM(V9)==Cnil){
	V8= Cnil;
	goto L748;}
	V8= MAKE_FIXNUM(V9);
	}
L748:
	if(((V8))==Cnil){
	goto L752;}
	T0= (V8);
	goto L744;
L752:
	(*LK6)(2,(V2),VV[216])                    /*  X-TYPE-ERROR    */;
	T0= VALUES(0);
	}
L744:
	Lcopy_seq(1,(V3))                         /*  COPY-SEQ        */;
	VALUES(1) = list(2,T0,VALUES(0));
	VALUES(0) = Cnil;
	V4=2;
	goto L734;
L742:
	V4=(*LK6)(2,(V3),VV[217])                 /*  X-TYPE-ERROR    */;
	}
L734:
	if (V4--==0) goto L755;
	V5= VALUES(0);
	if (V4--==0) goto L756;
	V6= VALUES(1);
	goto L757;
L755:
	V5= Cnil;
L756:
	V6= Cnil;
L757:
	{object V7;                               /*  LOCAL-STATE     */
	V7= ((V1))->in.in_slots[5];
	{object V8;
	{object V9;                               /*  SERVER-STATE    */
	V9= ((V1))->in.in_slots[4];
	((V7))->v.v_self[23]= (V6);
	((V7))->v.v_self[19]= (V5);
	if(((V6))!=Cnil){
	goto L765;}
	((V9))->v.v_self[23]= Cnil;
	goto L763;
L765:
	((V9))->v.v_self[19]= Cnil;
L763:
	if(((V5))==Cnil){
	goto L768;}
	if(number_compare(MAKE_FIXNUM(0),(V5))==0){
	goto L768;}
	V8= ((V9))->v.v_self[19]= Cnil;
	goto L759;
L768:
	V8= Cnil;
	}
L759:
	((V7))->v.v_self[26]= MAKE_FIXNUM(0);
	}
	}}
	VALUES(0) = (V3);
	RETURN(1);
}
/*	function definition for GCONTEXT-DASHES                       */
static L56(int narg, object V1)
{ VT58 VLEX58 CLSR58
TTL:
	{object V2;                               /*  LOCAL-STATE     */
	V2= ((V1))->in.in_slots[5];
	{ int V3;
	object V4;                                /*  DASH            */
	object V5;                                /*  DASHES          */
	VALUES(1) = ((V2))->v.v_self[21];
	VALUES(0) = ((V2))->v.v_self[24];
	V3=2;
	if (V3--==0) goto L775;
	V4= VALUES(0);
	if (V3--==0) goto L776;
	V5= VALUES(1);
	goto L777;
L775:
	V4= Cnil;
L776:
	V5= Cnil;
L777:
	if(((V4))!=Cnil){
	goto L779;}
	VALUES(0) = (V5);
	RETURN(1);
L779:
	VALUES(0) = (V4);
	RETURN(1);}
	}
}
/*	function definition for SET-GCONTEXT-DASHES                   */
static L57(int narg, object V1, object V2)
{ VT59 VLEX59 CLSR59
TTL:
	{ int V3;
	object V4;                                /*  DASHES          */
	object V5;                                /*  DASH            */
	(*LK7)(2,(V2),VV[214])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L784;}
	if(!((length((V2)))==0)){
	goto L787;}
	V3=(*LK6)(3,(V2),VV[220],VV[221])         /*  X-TYPE-ERROR    */;
	goto L782;
L787:
	Lcopy_seq(1,(V2))                         /*  COPY-SEQ        */;
	if(VALUES(0)==Cnil)goto L790;
	goto L789;
L790:
	(*LK0)(0)                                 /*  VECTOR          */;
L789:
	VALUES(1) = VALUES(0);
	VALUES(0) = Cnil;
	V3=2;
	goto L782;
L784:
	(*LK7)(2,(V2),VV[222])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L794;}
	VALUES(0) = (V2);
	goto L792;
L794:
	(*LK6)(2,(V2),VV[222])                    /*  X-TYPE-ERROR    */;
L792:
	VALUES(1) = Cnil;
	VALUES(0) = VALUES(0);
	V3=2;
L782:
	if (V3--==0) goto L796;
	V4= VALUES(0);
	if (V3--==0) goto L797;
	V5= VALUES(1);
	goto L798;
L796:
	V4= Cnil;
L797:
	V5= Cnil;
L798:
	{object V6;                               /*  LOCAL-STATE     */
	V6= ((V1))->in.in_slots[5];
	{object V7;
	{object V8;                               /*  SERVER-STATE    */
	V8= ((V1))->in.in_slots[4];
	((V6))->v.v_self[24]= (V5);
	((V6))->v.v_self[21]= (V4);
	if(((V5))!=Cnil){
	goto L805;}
	V7= ((V8))->v.v_self[24]= Cnil;
	goto L800;
L805:
	V7= ((V8))->v.v_self[21]= Cnil;
	}
L800:
	((V6))->v.v_self[26]= MAKE_FIXNUM(0);
	}
	}}
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for GCONTEXT-FONT                         */
static L58(int narg, object V1, ...)
{ VT60 VLEX60 CLSR60
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if (i==narg) goto L808;
	V2= va_arg(args, object);
	i++;
	goto L809;
L808:
	V2= Cnil;
L809:
	{object V3;                               /*  LOCAL-STATE     */
	V3= ((V1))->in.in_slots[5];
	{object V4;                               /*  FONT            */
	V4= ((V3))->v.v_self[25];
	if((V4)!=Cnil){
	VALUES(0) = (V4);
	RETURN(1);}
	if(((V2))==Cnil){
	goto L814;}
	RETURN((*LK10)(6,VV[223],((V1))->in.in_slots[1],VV[224],((V1))->in.in_slots[0],VV[225],Cnil)/*  MAKE-FONT*/);
L814:
	VALUES(0) = Cnil;
	RETURN(1);
	}
	}
	}
}
/*	function definition for SET-GCONTEXT-FONT                     */
static L59(int narg, object V1, object V2)
{ VT61 VLEX61 CLSR61
TTL:
	{register object V3;                      /*  FONT-OBJECT     */
	object V4;                                /*  FONT            */
	(*LK11)(1,(V2))                           /*  FONT-P          */;
	if(VALUES(0)==Cnil){
	goto L819;}
	V3= (V2);
	goto L817;
L819:
	(*LK12)(2,((V1))->in.in_slots[1],(V2))    /*  OPEN-FONT       */;
	V3= VALUES(0);
L817:
	if((V3)==Cnil){
	V4= Cnil;
	goto L821;}
	(*LK13)(1,(V3))                           /*  FONT-ID         */;
	V4= VALUES(0);
L821:
	{object V5;                               /*  LOCAL-STATE     */
	V5= ((V1))->in.in_slots[5];
	{object V6;
	{object V7;                               /*  SERVER-STATE    */
	V7= ((V1))->in.in_slots[4];
	((V5))->v.v_self[25]= (V3);
	((V5))->v.v_self[14]= (V4);
	if(((V4))!=Cnil){
	goto L828;}
	V6= ((V7))->v.v_self[14]= Cnil;
	goto L823;
L828:
	V6= ((V7))->v.v_self[25]= (V3);
	}
L823:
	((V5))->v.v_self[26]= MAKE_FIXNUM(0);
	}
	}
	}
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for FORCE-GCONTEXT-CHANGES-INTERNAL       */
static L60(int narg, object V1)
{ VT62 VLEX62 CLSR62
TTL:
	{volatile object V2;                      /*  DISPLAY         */
	volatile object V3;                       /*  SERVER-STATE    */
	volatile object V4;                       /*  LOCAL-STATE     */
	V2= ((V1))->in.in_slots[1];
	V3= ((V1))->in.in_slots[4];
	V4= ((V1))->in.in_slots[5];
	if((fix(((V4))->v.v_self[26]))==(fix(((V3))->v.v_self[26]))){
	goto L835;}
	{int V5;
	V5= fix(((V3))->v.v_self[26]);
	if(!((V5)==(536870911))){
	goto L843;}
	V5= 1;
	goto L841;
L843:
	V5= (V5)+1;
L841:
	VALUES(0) = ((V3))->v.v_self[26]= MAKE_FIXNUM(V5);
	}
	((V4))->v.v_self[26]= VALUES(0);
	{volatile object V5;                      /*  LAST-REQUEST    */
	V5= ((V2))->in.in_slots[4];
	{volatile object V6;                      /*  .DISPLAY.       */
	V6= (V2);
	{volatile object V7;                      /*  %BUFFER         */
	V7= (V6);
	if(!(((fix(((V7))->in.in_slots[6]))+(160))>=(fix(((V7))->in.in_slots[2])))){
	goto L850;}
	(*LK14)(1,(V7))                           /*  BUFFER-FLUSH    */;
L850:
	{volatile int V8;                         /*  BUFFER-BOFFSET  */
	volatile object V9;                       /*  BUFFER-BBUF     */
	V8= fix(((V7))->in.in_slots[6]);
	V9= ((V7))->in.in_slots[7];
	((V6))->in.in_slots[4]= MAKE_FIXNUM(V8);
	(((V9))->ust.ust_self[(V8)+(0)]=(56));
	(*LK15)(1,(V1))                           /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L861;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L859;
L861:
	(*LK6)(2,(V1),VV[82])                     /*  X-TYPE-ERROR    */;
L859:
	{volatile object V10;                     /*  .VALUE.         */
	{volatile int V11;                        /*  I               */
	volatile int V12;                         /*  BIT             */
	volatile int V13;                         /*  NBYTE           */
	volatile int V14;                         /*  MASK            */
	volatile object V15;                      /*  LOCAL           */
	V11= 0;
	V12= 1;
	V13= 12;
	V14= 0;
	V15= MAKE_FIXNUM(0);
L870:
	if(!((V11)>=(23))){
	goto L871;}
	if(!((V14)==0)){
	goto L874;}
	if(!(number_compare(MAKE_FIXNUM(0),((V2))->in.in_slots[4])==0)){
	goto L880;}
	VALUES(0) = Cnil;
	goto L878;
L880:
	VALUES(0) = (V5);
L878:
	((V2))->in.in_slots[4]= VALUES(0);
	goto L845;
L874:
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(8))))=V14);
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=((V13) >> (- (-2))));
	{object V17;
	object V18;
	V17= (V2);
	V18= MAKE_FIXNUM((fix(((V17))->in.in_slots[6]))+(V13));
	((V17))->in.in_slots[6]= (V18);
	V10= (V18);
	goto L864;
	}
L871:
	{object V19= ((V3))->v.v_self[V11];
	V15= ((V4))->v.v_self[V11];
	if(eql((V19),(V15))){
	goto L886;}}
	((V3))->v.v_self[V11]= (V15);
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(V13))))=fix((V15)));
	V14= ((V14) | (V12));
	V13= (V13)+(4);
L886:
	V11= (V11)+(1);
	V12= ((V12) << (1));
	goto L870;
	}
L864:
	}
	(*LK16)(1,(V6))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK17)(1,(V6))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	}
L845:
	{volatile object V5;                      /*  EXTENSION       */
	volatile int V6;                          /*  I               */
	volatile object V7;                       /*  LOCAL           */
	V6= 27;
	V5= (VV[77]->s.s_dbind);
	V7= Cnil;
L902:
	if(!((V5)==Cnil)){
	goto L903;}
	goto L899;
L903:
	{object V9= ((V3))->v.v_self[V6];
	V7= ((V4))->v.v_self[V6];
	if(eql((V9),(V7))){
	goto L906;}}
	((V3))->v.v_self[V6]= (V7);
	(*LK18)(1,CAR((V5)))                      /*  GCONTEXT-EXTENSION-SET-FUNCTION*/;
	T0= VALUES(0);
	funcall(3,T0,(V1),(V7));
L906:
	V5= CDR((V5));
	V6= (V6)+(1);
	goto L902;
	}
L899:
	{ int V5;
	volatile object V6;                       /*  LOCAL-CLIP      */
	volatile object V7;                       /*  SERVER-CLIP     */
	VALUES(1) = ((V3))->v.v_self[23];
	VALUES(0) = ((V4))->v.v_self[23];
	V5=2;
	if (V5--==0) goto L918;
	V6= VALUES(0);
	if (V5--==0) goto L919;
	V7= VALUES(1);
	goto L920;
L918:
	V6= Cnil;
L919:
	V7= Cnil;
L920:
	if(equalp((V6),(V7))){
	goto L916;}
	((V3))->v.v_self[23]= Cnil;
	if(((V6))==Cnil){
	goto L916;}
	{object V8;                               /*  .DISPLAY.       */
	V8= (V2);
	{object V9;                               /*  %BUFFER         */
	V9= (V8);
	if(!(((fix(((V9))->in.in_slots[6]))+(160))>=(fix(((V9))->in.in_slots[2])))){
	goto L930;}
	(*LK14)(1,(V9))                           /*  BUFFER-FLUSH    */;
L930:
	{int V10;                                 /*  BUFFER-BOFFSET  */
	object V11;                               /*  BUFFER-BBUF     */
	V10= fix(((V9))->in.in_slots[6]);
	V11= ((V9))->in.in_slots[7];
	((V8))->in.in_slots[4]= MAKE_FIXNUM(V10);
	(((V11))->ust.ust_self[(V10)+(0)]=(59));
	{object V12;                              /*  .VALUE.         */
	V12= CAR((V6));
	(*LK7)(2,(V12),VV[222])                   /*  TYPEP           */;
	if(VALUES(0)!=Cnil){
	goto L943;}
	VALUES(0) = Cnil;
	goto L942;
L943:
	VALUES(0) = MAKE_FIXNUM((((V11))->ust.ust_self[(V10)+(1)]=(fix((V12)))));
L942:
	if(VALUES(0)==Cnil)goto L941;
	goto L939;
L941:
	(*LK6)(2,(V12),VV[229])                   /*  X-TYPE-ERROR    */;
	}
L939:
	(*LK15)(1,(V1))                           /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L947;}
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L945;
L947:
	(*LK6)(2,(V1),VV[82])                     /*  X-TYPE-ERROR    */;
L945:
	{object V12;                              /*  .VALUE.         */
	VALUES(0) = ((V4))->v.v_self[17];
	if(VALUES(0)==Cnil)goto L951;
	V12= VALUES(0);
	goto L950;
L951:
	V12= MAKE_FIXNUM(0);
L950:
	(*LK7)(2,(V12),VV[149])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L954;}
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(8))))=fix((V12)));
	goto L949;
L954:
	(*LK6)(2,(V12),VV[149])                   /*  X-TYPE-ERROR    */;
	}
L949:
	{object V12;                              /*  .VALUE.         */
	VALUES(0) = ((V4))->v.v_self[18];
	if(VALUES(0)==Cnil)goto L958;
	V12= VALUES(0);
	goto L957;
L958:
	V12= MAKE_FIXNUM(0);
L957:
	(*LK7)(2,(V12),VV[149])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L961;}
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(10))))=fix((V12)));
	goto L956;
L961:
	(*LK6)(2,(V12),VV[149])                   /*  X-TYPE-ERROR    */;
	}
L956:
	{object V12;                              /*  .VALUE.         */
	V12= CADR((V6));
	(*LK7)(2,(V12),VV[214])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L966;}
	{int V13;
	V13= length((V12));
	Lceiling(2,MAKE_FIXNUM((V13)-(0)),MAKE_FIXNUM(2))/*  CEILING  */;
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(2))))=(fix(VALUES(0)))+(3));
	(*LK19)(6,(V9),MAKE_FIXNUM((V10)+(12)),(V12),MAKE_FIXNUM(0),MAKE_FIXNUM(V13),Cnil)/*  WRITE-SEQUENCE-INT16*/;
	goto L963;
	}
L966:
	(*LK6)(2,(V12),VV[230])                   /*  X-TYPE-ERROR    */;
	}
L963:
	(*LK16)(1,(V8))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK17)(1,(V8))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	((V3))->v.v_self[23]= (V6);}
L916:
	{ int V5;
	volatile object V6;                       /*  LOCAL-DASH      */
	volatile object V7;                       /*  SERVER-DASH     */
	VALUES(1) = ((V3))->v.v_self[24];
	VALUES(0) = ((V4))->v.v_self[24];
	V5=2;
	if (V5--==0) goto L972;
	V6= VALUES(0);
	if (V5--==0) goto L973;
	V7= VALUES(1);
	goto L974;
L972:
	V6= Cnil;
L973:
	V7= Cnil;
L974:
	if(equalp((V6),(V7))){
	goto L976;}
	((V3))->v.v_self[24]= Cnil;
	if(((V6))==Cnil){
	goto L980;}
	{object V8;                               /*  .DISPLAY.       */
	V8= (V2);
	{object V9;                               /*  %BUFFER         */
	V9= (V8);
	if(!(((fix(((V9))->in.in_slots[6]))+(160))>=(fix(((V9))->in.in_slots[2])))){
	goto L986;}
	(*LK14)(1,(V9))                           /*  BUFFER-FLUSH    */;
L986:
	{int V10;                                 /*  BUFFER-BOFFSET  */
	object V11;                               /*  BUFFER-BBUF     */
	V10= fix(((V9))->in.in_slots[6]);
	V11= ((V9))->in.in_slots[7];
	((V8))->in.in_slots[4]= MAKE_FIXNUM(V10);
	(((V11))->ust.ust_self[(V10)+(0)]=(58));
	(*LK15)(1,(V1))                           /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L997;}
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L995;
L997:
	(*LK6)(2,(V1),VV[82])                     /*  X-TYPE-ERROR    */;
L995:
	{object V12;                              /*  .VALUE.         */
	VALUES(0) = ((V4))->v.v_self[20];
	if(VALUES(0)==Cnil)goto L1001;
	V12= VALUES(0);
	goto L1000;
L1001:
	V12= MAKE_FIXNUM(0);
L1000:
	(*LK7)(2,(V12),VV[149])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1004;}
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(8))))=fix((V12)));
	goto L999;
L1004:
	(*LK6)(2,(V12),VV[149])                   /*  X-TYPE-ERROR    */;
	}
L999:
	{int V12;                                 /*  .VALUE.         */
	V12= length((V6));
	(*LK7)(2,MAKE_FIXNUM(V12),VV[149])        /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1009;}
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(10))))=V12);
	goto L1006;
L1009:
	(*LK6)(2,MAKE_FIXNUM(V12),VV[149])        /*  X-TYPE-ERROR    */;
	}
L1006:
	(*LK7)(2,(V6),VV[214])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1013;}
	{int V12;
	V12= length((V6));
	Lceiling(2,MAKE_FIXNUM((V12)-(0)),MAKE_FIXNUM(4))/*  CEILING  */;
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(2))))=(fix(VALUES(0)))+(3));
	(*LK20)(6,(V9),MAKE_FIXNUM((V10)+(12)),(V6),MAKE_FIXNUM(0),MAKE_FIXNUM(V12),Cnil)/*  WRITE-SEQUENCE-CARD8*/;
	goto L1011;
	}
L1013:
	(*LK6)(2,(V6),VV[231])                    /*  X-TYPE-ERROR    */;
L1011:
	(*LK16)(1,(V8))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK17)(1,(V8))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	VALUES(0) = ((V3))->v.v_self[24]= (V6);
	RETURN(1);
L980:
	VALUES(0) = Cnil;
	RETURN(1);
L976:
	VALUES(0) = Cnil;
	RETURN(1);}
L835:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for FORCE-GCONTEXT-CHANGES                */
static L61(int narg, object V1)
{ VT63 VLEX63 CLSR63
TTL:
	{object V2;                               /*  DISPLAY         */
	object V3;                                /*  SERVER-STATE    */
	object V4;                                /*  LOCAL-STATE     */
	V2= ((V1))->in.in_slots[1];
	V3= ((V1))->in.in_slots[4];
	V4= ((V1))->in.in_slots[5];
	if((fix(((V4))->v.v_self[26]))==(fix(((V3))->v.v_self[26]))){
	goto L1022;}
	if((((V2))->in.in_slots[10])==Cnil){
	goto L1024;}
	(*LK21)(3,VV[232],VV[223],(V2))           /*  X-ERROR         */;
L1024:
	RETURN(L60(1,(V1))                        /*  FORCE-GCONTEXT-CHANGES-INTERNAL*/);
L1022:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	macro definition for WITH-GCONTEXT                            */
static L62(int narg, object V1, object V2)
{ VT64 VLEX64 CLSR64
	{object V3=CDR(V1),V4,V5,V6,V7;
	{object V8= CAR(V3);
	V4= CAR(V8);
	V8=CDR(V8);
	V5= V8;
	{object V9;
	V9=getf(V8,VV[233],OBJNULL);
	if(V9==OBJNULL){
	V6= Cnil;
	} else {
	V6= V9;}}}
	V3=CDR(V3);
	V7= V3;
	{ int V10;
	object V11;
	object V12;                               /*  FLAG            */
	V10=siLrem_f(2,(V5),VV[233])              /*  REM-F           */;
	if (V10--==0) goto L1030;
	V11= VALUES(0);
	if (V10--==0) goto L1031;
	V12= VALUES(1);
	goto L1032;
L1030:
	V11= Cnil;
L1031:
	V12= Cnil;
L1032:
	V5= (V11);}
	{volatile object V10;                     /*  GC              */
	volatile object V11;
	volatile object V12;                      /*  SAVED-STATE     */
	volatile object V13;
	volatile object V14;                      /*  TEMP-GC         */
	volatile object V15;
	volatile object V16;                      /*  TEMP-MASK       */
	volatile object V17;
	volatile object V18;                      /*  TEMP-VARS       */
	volatile object V19;                      /*  SETFS           */
	volatile object V20;                      /*  INDEXES         */
	volatile object V21;                      /*  EXTENSION-INDEXES*/
	volatile object V22;                      /*  TS-INDEX        */
	Lgensym(0)                                /*  GENSYM          */;
	V11= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V13= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V15= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V17= VALUES(0);
	Lgetf(2,VV[234],VV[235])                  /*  GETF            */;
	V22= VALUES(0);
	V10= V11;
	V12= V13;
	V14= V15;
	V16= V17;
	V18= Cnil;
	V19= Cnil;
	V20= Cnil;
	V21= Cnil;
	{volatile object V23;                     /*  OPTION          */
	volatile object V24;                      /*  NAME            */
	volatile object V25;                      /*  VALUE           */
	V23= (V5);
	V24= CAR((V23));
	V25= CADR((V23));
L1045:
	if(!((V23)==Cnil)){
	goto L1046;}
	V19= nreverse((V19));
	goto L1040;
L1046:
	{register object V27;                     /*  INDEX           */
	Lgetf(2,VV[234],(V24))                    /*  GETF            */;
	V27= VALUES(0);
	if(((V27))==Cnil){
	goto L1053;}
	V20= CONS((V27),(V20));
	goto L1050;
L1053:
	{register object V28;                     /*  EXTENSION       */
	{object V29= (VV[77]->s.s_dbind);
	VALUES(0) = (VV[399]->s.s_gfdef);
	(*LK22)(4,(V24),V29,VV[236],VALUES(0))    /*  FIND            */;
	V28= VALUES(0);}
	if(((V28))==Cnil){
	goto L1059;}
	(*LK4)(4,VV[237],VV[98],(V24),VV[238])    /*  XINTERN         */;
	V21= CONS(VALUES(0),(V21));
	goto L1050;
L1059:
	(*LK6)(2,(V24),VV[239])                   /*  X-TYPE-ERROR    */;
	}
	}
L1050:
	{register object V29;                     /*  ACCESSOR        */
	object V30;
	register object V31;                      /*  TEMP-VAR        */
	(*LK4)(2,VV[98],(V24))                    /*  XINTERN         */;
	T0= VALUES(0);
	if(!(((V24))==(VV[240]))){
	goto L1068;}
	VALUES(0) = CONS((V6),Cnil);
	goto L1066;
L1068:
	VALUES(0) = Cnil;
L1066:
	V30= listA(3,T0,(V10),VALUES(0));
	Lgensym(0)                                /*  GENSYM          */;
	V31= VALUES(0);
	V29= V30;
	if(((V25))==Cnil){
	goto L1063;}
	V18= CONS(list(2,(V31),(V25)),(V18));
	V19= CONS(list(3,VV[112],(V31),list(3,VV[97],(V29),(V31))),(V19));
	}
L1063:
	V23= CDDR((V23));
	V24= CAR((V23));
	V25= CADR((V23));
	goto L1045;
	}
L1040:
	if(((V19))==Cnil){
	goto L1084;}
	{object V23= list(4,(V10),(V12),(V16),(V14));
	{object V24= listA(4,VV[242],(V4),list(2,VV[243],(V20)),(V21));
	{object V25= list(3,VV[92],VV[82],(V10));
	{object V26= list(3,VV[92],VV[93],(V12));
	{object V27= list(3,VV[92],VV[68],(V16));
	{object V28= list(5,VV[91],(V25),(V26),(V27),list(3,VV[92],VV[244],(V14)));
	{object V29= list(6,(V10),(V12),append((V20),(V21)),(V22),(V16),(V14));
	VALUES(0) = list(5,VV[241],(V23),(V24),(V28),listA(4,VV[245],(V29),listA(3,VV[89],(V18),(V19)),(V7)));
	RETURN(1);}}}}}}}
L1084:
	VALUES(0) = CONS(VV[96],(V7));
	RETURN(1);
	}}
}
/*	function definition for COPY-GCONTEXT-LOCAL-STATE             */
static L63(int narg, object V1, object V2, ...)
{ VT65 VLEX65 CLSR65
	{volatile object V3;
	va_list args; va_start(args, V2);
	narg -=2;
	V3=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object p=V3;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{volatile object V4;                      /*  LOCAL-STATE     */
	volatile object V5;
	volatile object V6;                       /*  SAVED-STATE     */
	volatile object V7;                       /*  CACHE-P         */
	V5= ((V1))->in.in_slots[5];
	L5(0)                                     /*  ALLOCATE-GCONTEXT-STATE*/;
	V6= VALUES(0);
	V7= ((V1))->in.in_slots[3];
	V4= V5;
	((V6))->v.v_self[26]= MAKE_FIXNUM(1);
	{volatile object V8;                      /*  TEMP-GC         */
	volatile int V9;                          /*  TEMP-MASK       */
	volatile object V10;                      /*  EXTENSION-MASK  */
	V9= 0;
	V8= Cnil;
	V10= MAKE_FIXNUM(0);
	{volatile object V11;
	volatile object V12;                      /*  I               */
	V11= (V2);
	V12= Cnil;
L1095:
	if(!((V11)==Cnil)){
	goto L1096;}
	goto L1091;
L1096:
	V12= CAR((V11));
	if(((((V6))->v.v_self[fix((V12))]=(((V4))->v.v_self[fix((V12))])))==Cnil){
	goto L1102;}
	if(((V7))!=Cnil){
	goto L1101;}
L1102:
	V9= ((V9) | (fix((VV[246])->v.v_self[fix((V12))])));
L1101:
	V11= CDR((V11));
	goto L1095;
	}
L1091:
	{volatile object V11;
	volatile int V12;                         /*  I               */
	V11= (V3);
	V12= fix(Cnil);
L1114:
	if(!((V11)==Cnil)){
	goto L1115;}
	goto L1110;
L1115:
	V12= fix(CAR((V11)));
	if((((V6))->v.v_self[V12]= ((V4))->v.v_self[V12])==Cnil){
	goto L1121;}
	if(((V7))!=Cnil){
	goto L1120;}
L1121:
	Lash(2,MAKE_FIXNUM(1),MAKE_FIXNUM(V12))   /*  ASH             */;
	Llogior(2,(V10),VALUES(0))                /*  LOGIOR          */;
	V10= VALUES(0);
L1120:
	V11= CDR((V11));
	goto L1114;
	}
L1110:
	if((V9)>0){
	goto L1131;}
	if(!(number_compare(MAKE_FIXNUM(0),(V10))<0)){
	goto L1130;}
L1131:
	{volatile object V11;                     /*  DISPLAY         */
	V11= ((V1))->in.in_slots[1];
	if((((V11))->in.in_slots[10])==Cnil){
	goto L1136;}
	(*LK21)(3,VV[232],VV[223],(V11))          /*  X-ERROR         */;
L1136:
	L7(0)                                     /*  ALLOCATE-TEMP-GCONTEXT*/;
	V8= VALUES(0);
	T0= ((V11))->in.in_slots[35];
	funcall(2,T0,(V11));
	((V8))->in.in_slots[0]= VALUES(0);
	((V8))->in.in_slots[1]= (V11);
	((V8))->in.in_slots[2]= ((V1))->in.in_slots[2];
	((V8))->in.in_slots[4]= (V6);
	((V8))->in.in_slots[5]= (V6);
	{object V12;                              /*  .DISPLAY.       */
	V12= (V11);
	{object V13;                              /*  %BUFFER         */
	V13= (V12);
	if(!(((fix(((V13))->in.in_slots[6]))+(160))>=(fix(((V13))->in.in_slots[2])))){
	goto L1152;}
	(*LK14)(1,(V13))                          /*  BUFFER-FLUSH    */;
L1152:
	{register int V14;                        /*  BUFFER-BOFFSET  */
	object V15;                               /*  BUFFER-BBUF     */
	V14= fix(((V13))->in.in_slots[6]);
	V15= ((V13))->in.in_slots[7];
	((V12))->in.in_slots[4]= MAKE_FIXNUM(V14);
	(((V15))->ust.ust_self[(V14)+(0)]=(55));
	(*LK15)(1,(V8))                           /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L1163;}
	((*(unsigned long *)(((V15))->ust.ust_self+((V14)+(4))))=fix(((V8))->in.in_slots[0]));
	goto L1161;
L1163:
	(*LK6)(2,(V8),VV[82])                     /*  X-TYPE-ERROR    */;
L1161:
	{object V16;                              /*  .VALUE.         */
	V16= ((V1))->in.in_slots[2];
	(*LK23)(1,(V16))                          /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L1168;}
	((*(unsigned long *)(((V15))->ust.ust_self+((V14)+(8))))=fix(((V16))->in.in_slots[0]));
	goto L1165;
L1168:
	(*LK6)(2,(V16),VV[248])                   /*  X-TYPE-ERROR    */;
	}
L1165:
	((*(unsigned long *)(((V15))->ust.ust_self+((V14)+(12))))=0);
	((*(unsigned short *)(((V15))->ust.ust_self+((V14)+(2))))=4);
	((V12))->in.in_slots[6]= MAKE_FIXNUM((V14)+(16));
	(*LK16)(1,(V12))                          /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK17)(1,(V12))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	if(!((V9)>0)){
	goto L1173;}
	{object V12;                              /*  .DISPLAY.       */
	V12= (V11);
	{object V13;                              /*  %BUFFER         */
	V13= (V12);
	if(!(((fix(((V13))->in.in_slots[6]))+(160))>=(fix(((V13))->in.in_slots[2])))){
	goto L1179;}
	(*LK14)(1,(V13))                          /*  BUFFER-FLUSH    */;
L1179:
	{register int V14;                        /*  BUFFER-BOFFSET  */
	object V15;                               /*  BUFFER-BBUF     */
	V14= fix(((V13))->in.in_slots[6]);
	V15= ((V13))->in.in_slots[7];
	((V12))->in.in_slots[4]= MAKE_FIXNUM(V14);
	(((V15))->ust.ust_self[(V14)+(0)]=(57));
	(*LK15)(1,(V1))                           /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L1190;}
	((*(unsigned long *)(((V15))->ust.ust_self+((V14)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L1188;
L1190:
	(*LK6)(2,(V1),VV[82])                     /*  X-TYPE-ERROR    */;
L1188:
	(*LK15)(1,(V8))                           /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L1194;}
	((*(unsigned long *)(((V15))->ust.ust_self+((V14)+(8))))=fix(((V8))->in.in_slots[0]));
	goto L1192;
L1194:
	(*LK6)(2,(V8),VV[82])                     /*  X-TYPE-ERROR    */;
L1192:
	{register int V16;                        /*  .VALUE.         */
	V16= ((V9) & (8388607));
	(*LK7)(2,MAKE_FIXNUM(V16),VV[249])        /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1199;}
	((*(unsigned long *)(((V15))->ust.ust_self+((V14)+(12))))=V16);
	goto L1196;
L1199:
	(*LK6)(2,MAKE_FIXNUM(V16),VV[249])        /*  X-TYPE-ERROR    */;
	}
L1196:
	((*(unsigned short *)(((V15))->ust.ust_self+((V14)+(2))))=4);
	((V12))->in.in_slots[6]= MAKE_FIXNUM((V14)+(16));
	(*LK16)(1,(V12))                          /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK17)(1,(V12))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
L1173:
	if(!(number_compare(MAKE_FIXNUM(0),(V10))<0)){
	goto L1130;}
	{volatile object V12;                     /*  BIT             */
	volatile int V13;                         /*  I               */
	Lash(2,(V10),number_negate(MAKE_FIXNUM(27)))/*  ASH           */;
	V12= VALUES(0);
	V13= 0;
L1208:
	if(!(number_compare(MAKE_FIXNUM(0),(V12))==0)){
	goto L1209;}
	goto L1130;
L1209:
	{object V15;                              /*  COPY-FUNCTION   */
	(*LK24)(1,elt((VV[77]->s.s_dbind),V13))   /*  GCONTEXT-EXTENSION-COPY-FUNCTION*/;
	V15= VALUES(0);
	funcall(4,(V15),(V1),(V8),((V4))->v.v_self[(V13)+(27)]);
	}
	Lash(2,(V12),MAKE_FIXNUM(-1))             /*  SHIFT>>         */;
	V12= VALUES(0);
	V13= (V13)+(1);
	goto L1208;
	}
	}
L1130:
	Llogior(2,MAKE_FIXNUM(V9),(V10))          /*  LOGIOR          */;
	VALUES(3) = (V8);
	VALUES(2) = VALUES(0);
	VALUES(1) = (V6);
	VALUES(0) = (V1);
	RETURN(4);
	}
	}
	}
}
/*	function definition for RESTORE-GCONTEXT-TEMP-STATE           */
static L64(int narg, object V1, object V2, object V3)
{ VT66 VLEX66 CLSR66
	{volatile int V4;
	V4= fix(V2);
TTL:
	{volatile object V5;                      /*  DISPLAY         */
	V5= ((V1))->in.in_slots[1];
	if((((V5))->in.in_slots[10])==Cnil){
	goto L1220;}
	(*LK21)(3,VV[232],VV[223],(V5))           /*  X-ERROR         */;
L1220:
	{object V6;                               /*  .DISPLAY.       */
	V6= (V5);
	{object V7;                               /*  %BUFFER         */
	V7= (V6);
	if(!(((fix(((V7))->in.in_slots[6]))+(160))>=(fix(((V7))->in.in_slots[2])))){
	goto L1227;}
	(*LK14)(1,(V7))                           /*  BUFFER-FLUSH    */;
L1227:
	{register int V8;                         /*  BUFFER-BOFFSET  */
	object V9;                                /*  BUFFER-BBUF     */
	V8= fix(((V7))->in.in_slots[6]);
	V9= ((V7))->in.in_slots[7];
	((V6))->in.in_slots[4]= MAKE_FIXNUM(V8);
	(((V9))->ust.ust_self[(V8)+(0)]=(57));
	(*LK15)(1,(V3))                           /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L1238;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(4))))=fix(((V3))->in.in_slots[0]));
	goto L1236;
L1238:
	(*LK6)(2,(V3),VV[82])                     /*  X-TYPE-ERROR    */;
L1236:
	(*LK15)(1,(V1))                           /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L1242;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(8))))=fix(((V1))->in.in_slots[0]));
	goto L1240;
L1242:
	(*LK6)(2,(V1),VV[82])                     /*  X-TYPE-ERROR    */;
L1240:
	{int V10;                                 /*  .VALUE.         */
	V10= ((V4) & (8388607));
	(*LK7)(2,MAKE_FIXNUM(V10),VV[249])        /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1247;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(12))))=V10);
	goto L1244;
L1247:
	(*LK6)(2,MAKE_FIXNUM(V10),VV[249])        /*  X-TYPE-ERROR    */;
	}
L1244:
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=4);
	((V6))->in.in_slots[6]= MAKE_FIXNUM((V8)+(16));
	(*LK16)(1,(V6))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK17)(1,(V6))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	{volatile object V6;                      /*  BIT             */
	volatile object V7;                       /*  EXTENSIONS      */
	volatile int V8;                          /*  I               */
	volatile object V9;                       /*  LOCAL-STATE     */
	Lash(2,MAKE_FIXNUM(V4),number_negate(MAKE_FIXNUM(27)))/*  ASH */;
	V6= VALUES(0);
	V8= 27;
	V9= ((V3))->in.in_slots[5];
	V7= (VV[77]->s.s_dbind);
L1256:
	if(!(number_compare(MAKE_FIXNUM(0),(V6))==0)){
	goto L1257;}
	goto L1251;
L1257:
	{register object V11;                     /*  COPY-FUNCTION   */
	(*LK24)(1,CAR((V7)))                      /*  GCONTEXT-EXTENSION-COPY-FUNCTION*/;
	V11= VALUES(0);
	funcall(4,(V11),(V3),(V1),((V9))->v.v_self[V8]);
	}
	Lash(2,(V6),MAKE_FIXNUM(-1))              /*  SHIFT>>         */;
	V6= VALUES(0);
	V7= CDR((V7));
	V8= (V8)+(1);
	goto L1256;
	}
L1251:
	{object V6;                               /*  .DISPLAY.       */
	V6= (V5);
	{object V7;                               /*  %BUFFER         */
	V7= (V6);
	if(!(((fix(((V7))->in.in_slots[6]))+(160))>=(fix(((V7))->in.in_slots[2])))){
	goto L1271;}
	(*LK14)(1,(V7))                           /*  BUFFER-FLUSH    */;
L1271:
	{register int V8;                         /*  BUFFER-BOFFSET  */
	object V9;                                /*  BUFFER-BBUF     */
	V8= fix(((V7))->in.in_slots[6]);
	V9= ((V7))->in.in_slots[7];
	((V6))->in.in_slots[4]= MAKE_FIXNUM(V8);
	(((V9))->ust.ust_self[(V8)+(0)]=(60));
	(*LK15)(1,(V3))                           /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L1282;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(4))))=fix(((V3))->in.in_slots[0]));
	goto L1280;
L1282:
	(*LK6)(2,(V3),VV[82])                     /*  X-TYPE-ERROR    */;
L1280:
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=2);
	((V6))->in.in_slots[6]= MAKE_FIXNUM((V8)+(8));
	(*LK16)(1,(V6))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK17)(1,(V6))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	L8(1,(V3))                                /*  DEALLOCATE-TEMP-GCONTEXT*/;
	{volatile object V6;                      /*  SERVER-STATE    */
	volatile int V7;                          /*  BIT             */
	volatile int V8;                          /*  I               */
	V6= ((V1))->in.in_slots[4];
	V7= ((V4) & (8388607));
	V8= 0;
L1292:
	if(!((V7)==0)){
	goto L1293;}
	{register int V10;
	V10= fix(((V6))->v.v_self[26]);
	if(!((V10)==(536870911))){
	goto L1300;}
	V10= 1;
	goto L1298;
L1300:
	V10= (V10)+1;
L1298:
	VALUES(0) = ((V6))->v.v_self[26]= MAKE_FIXNUM(V10);
	RETURN(1);
	}
L1293:
	Loddp(1,MAKE_FIXNUM(V7))                  /*  ODDP            */;
	if(VALUES(0)==Cnil){
	goto L1302;}
	((V6))->v.v_self[V8]= Cnil;
L1302:
	V7= ((V7) >> (- (-1)));
	V8= (V8)+(1);
	goto L1292;
	}
	}
	}
}
/*	function definition for CREATE-GCONTEXT                       */
static L65(int narg, ...)
{ VT67 VLEX67 CLSR67
	{volatile object V1;
	volatile object V2;
	volatile object V3;
	volatile object V4;
	volatile object V5;
	volatile object V6;
	volatile object V7;
	volatile object V8;
	volatile object V9;
	volatile object V10;
	volatile object V11;
	volatile object V12;
	volatile object V13;
	volatile object V14;
	volatile object V15;
	volatile object V16;
	volatile object V17;
	volatile object V18;
	volatile object V19;
	volatile object V20;
	volatile object V21;
	volatile object V22;
	volatile object V23;
	volatile object V24;
	volatile object V25;
	volatile object V26;
	volatile object V27;
	va_list args; va_start(args, narg);
	narg -=0;
	V1=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ int n=narg; object p=V1;
	 for(;n-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{ object keyvars[52];
	va_start(args,narg);
	parse_key(narg,args,26,L65keys,keyvars,V1,TRUE);
	if(keyvars[26]==Cnil){
	(*LK21)(3,VV[250],VV[251],VV[248])        /*  X-ERROR         */;
	V2= (VV[252]->s.s_dbind);
	}else{
	V2= keyvars[0];}
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	V7= keyvars[5];
	V8= keyvars[6];
	V9= keyvars[7];
	V10= keyvars[8];
	V11= keyvars[9];
	V12= keyvars[10];
	V13= keyvars[11];
	V14= keyvars[12];
	V15= keyvars[13];
	V16= keyvars[14];
	V17= keyvars[15];
	V18= keyvars[16];
	V19= keyvars[17];
	V20= keyvars[18];
	V21= keyvars[19];
	V22= keyvars[20];
	V23= keyvars[21];
	V24= keyvars[22];
	V25= keyvars[23];
	V26= keyvars[24];
	if(keyvars[51]==Cnil){
	V27= Ct;
	}else{
	V27= keyvars[25];}
	}
	{volatile object V28;                     /*  DISPLAY         */
	volatile object V29;                      /*  GCONTEXT        */
	volatile object V30;                      /*  LOCAL-STATE     */
	volatile object V31;                      /*  SERVER-STATE    */
	volatile int V32;                         /*  GCONTEXTID      */
	V28= ((V2))->in.in_slots[1];
	(*LK3)(6,VV[223],(V28),VV[253],(V2),VV[254],(V27))/*  MAKE-GCONTEXT*/;
	V29= VALUES(0);
	V30= ((V29))->in.in_slots[5];
	V31= ((V29))->in.in_slots[4];
	T0= ((V28))->in.in_slots[35];
	funcall(2,T0,(V28));
	V32= fix(VALUES(0));
	((V29))->in.in_slots[0]= MAKE_FIXNUM(V32);
	if(((V3))!=Cnil){
	goto L1319;}
	L15(2,(V29),MAKE_FIXNUM(3))               /*  SET-GCONTEXT-FUNCTION*/;
L1319:
	if(((V4))!=Cnil){
	goto L1322;}
	L17(2,(V29),VV[255])                      /*  SET-GCONTEXT-PLANE-MASK*/;
L1322:
	if(((V5))!=Cnil){
	goto L1325;}
	L19(2,(V29),MAKE_FIXNUM(0))               /*  SET-GCONTEXT-FOREGROUND*/;
L1325:
	if(((V6))!=Cnil){
	goto L1328;}
	L21(2,(V29),MAKE_FIXNUM(1))               /*  SET-GCONTEXT-BACKGROUND*/;
L1328:
	if(((V7))!=Cnil){
	goto L1331;}
	L23(2,(V29),MAKE_FIXNUM(0))               /*  SET-GCONTEXT-LINE-WIDTH*/;
L1331:
	if(((V8))!=Cnil){
	goto L1334;}
	L25(2,(V29),VV[256])                      /*  SET-GCONTEXT-LINE-STYLE*/;
L1334:
	if(((V9))!=Cnil){
	goto L1337;}
	L27(2,(V29),VV[257])                      /*  SET-GCONTEXT-CAP-STYLE*/;
L1337:
	if(((V10))!=Cnil){
	goto L1340;}
	L29(2,(V29),VV[258])                      /*  SET-GCONTEXT-JOIN-STYLE*/;
L1340:
	if(((V11))!=Cnil){
	goto L1343;}
	L31(2,(V29),VV[256])                      /*  SET-GCONTEXT-FILL-STYLE*/;
L1343:
	if(((V12))!=Cnil){
	goto L1346;}
	L33(2,(V29),VV[259])                      /*  SET-GCONTEXT-FILL-RULE*/;
L1346:
	if(((V13))!=Cnil){
	goto L1349;}
	L53(2,(V29),VV[260])                      /*  SET-GCONTEXT-ARC-MODE*/;
L1349:
	if(((V16))!=Cnil){
	goto L1352;}
	L39(2,(V29),MAKE_FIXNUM(0))               /*  SET-GCONTEXT-TS-X*/;
L1352:
	if(((V17))!=Cnil){
	goto L1355;}
	L41(2,(V29),MAKE_FIXNUM(0))               /*  SET-GCONTEXT-TS-Y*/;
L1355:
	if(((V19))!=Cnil){
	goto L1358;}
	L43(2,(V29),VV[261])                      /*  SET-GCONTEXT-SUBWINDOW-MODE*/;
L1358:
	if(((V20))!=Cnil){
	goto L1361;}
	L45(2,(V29),VV[262])                      /*  SET-GCONTEXT-EXPOSURES*/;
L1361:
	if(((V23))!=Cnil){
	goto L1364;}
	L55(3,(V29),Cnil,VV[263])                 /*  SET-GCONTEXT-CLIP-MASK*/;
L1364:
	if(((V21))!=Cnil){
	goto L1367;}
	L47(2,(V29),MAKE_FIXNUM(0))               /*  SET-GCONTEXT-CLIP-X*/;
L1367:
	if(((V22))!=Cnil){
	goto L1370;}
	L49(2,(V29),MAKE_FIXNUM(0))               /*  SET-GCONTEXT-CLIP-Y*/;
L1370:
	if(((V26))!=Cnil){
	goto L1373;}
	L57(2,(V29),MAKE_FIXNUM(4))               /*  SET-GCONTEXT-DASHES*/;
L1373:
	if(((V25))!=Cnil){
	goto L1376;}
	L51(2,(V29),MAKE_FIXNUM(0))               /*  SET-GCONTEXT-DASH-OFFSET*/;
L1376:
	(*LK25)(2,(V31),(V30))                    /*  REPLACE         */;
	if(((V3))==Cnil){
	goto L1380;}
	L15(2,(V29),(V3))                         /*  SET-GCONTEXT-FUNCTION*/;
L1380:
	if(((V4))==Cnil){
	goto L1383;}
	L17(2,(V29),(V4))                         /*  SET-GCONTEXT-PLANE-MASK*/;
L1383:
	if(((V5))==Cnil){
	goto L1386;}
	L19(2,(V29),(V5))                         /*  SET-GCONTEXT-FOREGROUND*/;
L1386:
	if(((V6))==Cnil){
	goto L1389;}
	L21(2,(V29),(V6))                         /*  SET-GCONTEXT-BACKGROUND*/;
L1389:
	if(((V7))==Cnil){
	goto L1392;}
	L23(2,(V29),(V7))                         /*  SET-GCONTEXT-LINE-WIDTH*/;
L1392:
	if(((V8))==Cnil){
	goto L1395;}
	L25(2,(V29),(V8))                         /*  SET-GCONTEXT-LINE-STYLE*/;
L1395:
	if(((V9))==Cnil){
	goto L1398;}
	L27(2,(V29),(V9))                         /*  SET-GCONTEXT-CAP-STYLE*/;
L1398:
	if(((V10))==Cnil){
	goto L1401;}
	L29(2,(V29),(V10))                        /*  SET-GCONTEXT-JOIN-STYLE*/;
L1401:
	if(((V11))==Cnil){
	goto L1404;}
	L31(2,(V29),(V11))                        /*  SET-GCONTEXT-FILL-STYLE*/;
L1404:
	if(((V12))==Cnil){
	goto L1407;}
	L33(2,(V29),(V12))                        /*  SET-GCONTEXT-FILL-RULE*/;
L1407:
	if(((V13))==Cnil){
	goto L1410;}
	L53(2,(V29),(V13))                        /*  SET-GCONTEXT-ARC-MODE*/;
L1410:
	if(((V14))==Cnil){
	goto L1413;}
	L35(2,(V29),(V14))                        /*  SET-GCONTEXT-TILE*/;
L1413:
	if(((V15))==Cnil){
	goto L1416;}
	L37(2,(V29),(V15))                        /*  SET-GCONTEXT-STIPPLE*/;
L1416:
	if(((V16))==Cnil){
	goto L1419;}
	L39(2,(V29),(V16))                        /*  SET-GCONTEXT-TS-X*/;
L1419:
	if(((V17))==Cnil){
	goto L1422;}
	L41(2,(V29),(V17))                        /*  SET-GCONTEXT-TS-Y*/;
L1422:
	if(((V18))==Cnil){
	goto L1425;}
	L59(2,(V29),(V18))                        /*  SET-GCONTEXT-FONT*/;
L1425:
	if(((V19))==Cnil){
	goto L1428;}
	L43(2,(V29),(V19))                        /*  SET-GCONTEXT-SUBWINDOW-MODE*/;
L1428:
	if(((V20))==Cnil){
	goto L1431;}
	L45(2,(V29),(V20))                        /*  SET-GCONTEXT-EXPOSURES*/;
L1431:
	if(((V21))==Cnil){
	goto L1434;}
	L47(2,(V29),(V21))                        /*  SET-GCONTEXT-CLIP-X*/;
L1434:
	if(((V22))==Cnil){
	goto L1437;}
	L49(2,(V29),(V22))                        /*  SET-GCONTEXT-CLIP-Y*/;
L1437:
	if(((V23))==Cnil){
	goto L1440;}
	L55(3,(V29),(V24),(V23))                  /*  SET-GCONTEXT-CLIP-MASK*/;
L1440:
	if(((V25))==Cnil){
	goto L1443;}
	L51(2,(V29),(V25))                        /*  SET-GCONTEXT-DASH-OFFSET*/;
L1443:
	if(((V26))==Cnil){
	goto L1446;}
	L57(2,(V29),(V26))                        /*  SET-GCONTEXT-DASHES*/;
L1446:
	((V31))->v.v_self[26]= MAKE_FIXNUM(1);
	if((((V30))->v.v_self[23])!=Cnil){
	goto L1452;}
	if((((V30))->v.v_self[24])==Cnil){
	goto L1453;}
L1452:
	VALUES(0) = MAKE_FIXNUM(0);
	goto L1451;
L1453:
	VALUES(0) = MAKE_FIXNUM(1);
L1451:
	((V30))->v.v_self[26]= VALUES(0);
	{volatile object V33;                     /*  .DISPLAY.       */
	V33= (V28);
	if((((V33))->in.in_slots[10])==Cnil){
	goto L1458;}
	(*LK21)(3,VV[232],VV[223],(V33))          /*  X-ERROR         */;
L1458:
	{volatile object V34;                     /*  %BUFFER         */
	V34= (V33);
	if(!(((fix(((V34))->in.in_slots[6]))+(160))>=(fix(((V34))->in.in_slots[2])))){
	goto L1462;}
	(*LK14)(1,(V34))                          /*  BUFFER-FLUSH    */;
L1462:
	{volatile int V35;                        /*  BUFFER-BOFFSET  */
	volatile object V36;                      /*  BUFFER-BBUF     */
	V35= fix(((V34))->in.in_slots[6]);
	V36= ((V34))->in.in_slots[7];
	((V33))->in.in_slots[4]= MAKE_FIXNUM(V35);
	(((V36))->ust.ust_self[(V35)+(0)]=(55));
	(*LK7)(2,MAKE_FIXNUM(V32),VV[264])        /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1473;}
	((*(unsigned long *)(((V36))->ust.ust_self+((V35)+(4))))=V32);
	goto L1471;
L1473:
	(*LK6)(2,MAKE_FIXNUM(V32),VV[264])        /*  X-TYPE-ERROR    */;
L1471:
	(*LK23)(1,(V2))                           /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L1477;}
	((*(unsigned long *)(((V36))->ust.ust_self+((V35)+(8))))=fix(((V2))->in.in_slots[0]));
	goto L1475;
L1477:
	(*LK6)(2,(V2),VV[248])                    /*  X-TYPE-ERROR    */;
L1475:
	{volatile object V37;                     /*  .VALUE.         */
	{volatile int V38;                        /*  I               */
	volatile int V39;                         /*  BIT             */
	volatile int V40;                         /*  NBYTE           */
	volatile int V41;                         /*  MASK            */
	volatile object V42;                      /*  LOCAL           */
	V38= 0;
	V39= 1;
	V40= 16;
	V41= 0;
	V42= ((V30))->v.v_self[V38];
L1487:
	if(!((V38)>=(23))){
	goto L1488;}
	((*(unsigned long *)(((V36))->ust.ust_self+((V35)+(12))))=V41);
	((*(unsigned short *)(((V36))->ust.ust_self+((V35)+(2))))=((V40) >> (- (-2))));
	{object V44;
	object V45;
	V44= (V28);
	V45= MAKE_FIXNUM((fix(((V44))->in.in_slots[6]))+(V40));
	((V44))->in.in_slots[6]= (V45);
	V37= (V45);
	goto L1480;
	}
L1488:
	if(eql((V42),((V31))->v.v_self[V38])){
	goto L1495;}
	((V31))->v.v_self[V38]= (V42);
	((*(unsigned long *)(((V36))->ust.ust_self+((V35)+(V40))))=fix((V42)));
	V41= ((V41) | (V39));
	V40= (V40)+(4);
L1495:
	V38= (V38)+(1);
	V39= ((V39) << (1));
	V42= ((V30))->v.v_self[V38];
	goto L1487;
	}
L1480:
	}
	(*LK16)(1,(V33))                          /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK17)(1,(V33))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	{volatile object V33;                     /*  EXTENSIONS      */
	volatile int V34;                         /*  I               */
	V34= 27;
	V33= (VV[77]->s.s_dbind);
L1513:
	if(!((V33)==Cnil)){
	goto L1514;}
	goto L1510;
L1514:
	(*LK26)(1,CAR((V33)))                     /*  GCONTEXT-EXTENSION-DEFAULT*/;
	((V31))->v.v_self[V34]= ((V30))->v.v_self[V34]= VALUES(0);
	V33= CDR((V33));
	V34= (V34)+(1);
	goto L1513;
	}
L1510:
	{volatile object V33;                     /*  OPTION-LIST     */
	volatile object V34;                      /*  OPTION          */
	volatile object V35;                      /*  EXTENSION       */
	V33= (V1);
	V34= CAR((V33));
	V35= Cnil;
L1528:
	if(!((V33)==Cnil)){
	goto L1529;}
	goto L1523;
L1529:
	{object V37;
	Lgetf(2,VV[234],(V34))                    /*  GETF            */;
	V37= VALUES(0);
	if(((V37))==Cnil){
	goto L1535;}
	goto L1532;
L1535:
	{object V38;
	V38= memql((V34),VV[265]);
	if(((V38))==Cnil){
	goto L1539;}
	goto L1532;
L1539:
	{object V39= (VV[77]->s.s_dbind);
	VALUES(0) = (VV[399]->s.s_gfdef);
	(*LK22)(4,(V34),V39,VV[236],VALUES(0))    /*  FIND            */;
	V35= VALUES(0);}
	if(((V35))==Cnil){
	goto L1542;}
	(*LK18)(1,(V35))                          /*  GCONTEXT-EXTENSION-SET-FUNCTION*/;
	T0= VALUES(0);
	funcall(3,T0,(V29),CADR((V33)));
	goto L1532;
L1542:
	(*LK6)(2,(V34),VV[239])                   /*  X-TYPE-ERROR    */;
	}
	}
L1532:
	V33= CDDR((V33));
	V34= CAR((V33));
	goto L1528;
	}
L1523:
	VALUES(0) = (V29);
	RETURN(1);
	}
	}
}
/*	function definition for COPY-GCONTEXT-COMPONENTS              */
static L66(int narg, object V1, object V2, ...)
{ VT68 VLEX68 CLSR68
	{volatile object V3;
	va_list args; va_start(args, V2);
	narg -=2;
	V3=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object p=V3;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	if(((V3))==Cnil){
	goto L1553;}
	{volatile object V4;                      /*  DISPLAY         */
	volatile int V5;                          /*  MASK            */
	V4= ((V1))->in.in_slots[1];
	V5= 0;
	if((((V4))->in.in_slots[10])==Cnil){
	goto L1557;}
	(*LK21)(3,VV[232],VV[223],(V4))           /*  X-ERROR         */;
L1557:
	L60(1,(V1))                               /*  FORCE-GCONTEXT-CHANGES-INTERNAL*/;
	L60(1,(V2))                               /*  FORCE-GCONTEXT-CHANGES-INTERNAL*/;
	{volatile object V6;
	volatile object V7;                       /*  KEY             */
	V6= (V3);
	V7= Cnil;
L1566:
	if(!((V6)==Cnil)){
	goto L1567;}
	goto L1562;
L1567:
	V7= CAR((V6));
	{register object V9;                      /*  I               */
	Lgetf(2,VV[234],(V7))                     /*  GETF            */;
	V9= VALUES(0);
	if(((V9))==Cnil){
	goto L1575;}
	V5= ((V5) | (fix((VV[246])->v.v_self[fix((V9))])));
	goto L1572;
L1575:
	{ int V10;
	register object V11;                      /*  EXTENSION       */
	object V12;                               /*  INDEX           */
	{object V13= (VV[77]->s.s_dbind);
	VALUES(0) = (VV[399]->s.s_gfdef);
	V10=(*LK22)(4,(V7),V13,VV[236],VALUES(0)) /*  FIND            */;}
	if (V10--==0) goto L1580;
	V11= VALUES(0);
	if (V10--==0) goto L1581;
	V12= VALUES(1);
	goto L1582;
L1580:
	V11= Cnil;
L1581:
	V12= Cnil;
L1582:
	if(((V11))==Cnil){
	goto L1584;}
	(*LK24)(1,(V11))                          /*  GCONTEXT-EXTENSION-COPY-FUNCTION*/;
	T0= VALUES(0);
	funcall(4,T0,(V1),(V2),(((V1))->in.in_slots[5])->v.v_self[(fix((V12)))+(27)]);
	goto L1572;
L1584:
	(*LK6)(2,(V7),VV[239])                    /*  X-TYPE-ERROR    */;}
	}
L1572:
	V6= CDR((V6));
	goto L1566;
	}
L1562:
	if(!((V5)>0)){
	goto L1591;}
	{volatile object V6;                      /*  SRC-SERVER-STATE*/
	volatile object V7;                       /*  DST-SERVER-STATE*/
	volatile object V8;                       /*  DST-LOCAL-STATE */
	volatile int V9;                          /*  BIT             */
	volatile int V10;                         /*  I               */
	V6= ((V1))->in.in_slots[4];
	V7= ((V2))->in.in_slots[4];
	V8= ((V2))->in.in_slots[5];
	V9= V5;
	V10= 0;
L1600:
	if(!((V9)==0)){
	goto L1601;}
	{register int V12;
	V12= fix(((V7))->v.v_self[26]);
	if(!((V12)==(536870911))){
	goto L1609;}
	V12= 1;
	goto L1607;
L1609:
	V12= (V12)+1;
L1607:
	((V7))->v.v_self[26]= MAKE_FIXNUM(V12);
	}
	((V8))->v.v_self[26]= MAKE_FIXNUM(0);
	goto L1593;
L1601:
	Loddp(1,MAKE_FIXNUM(V9))                  /*  ODDP            */;
	if(VALUES(0)==Cnil){
	goto L1611;}
	((V8))->v.v_self[V10]= ((V7))->v.v_self[V10]= ((V6))->v.v_self[V10];
L1611:
	V9= ((V9) >> (- (-1)));
	V10= (V10)+(1);
	goto L1600;
	}
L1593:
	{object V6;                               /*  .DISPLAY.       */
	V6= (V4);
	{ int V7;
	{object V8;                               /*  %BUFFER         */
	V8= (V6);
	if(!(((fix(((V8))->in.in_slots[6]))+(160))>=(fix(((V8))->in.in_slots[2])))){
	goto L1621;}
	(*LK14)(1,(V8))                           /*  BUFFER-FLUSH    */;
L1621:
	{register int V9;                         /*  BUFFER-BOFFSET  */
	object V10;                               /*  BUFFER-BBUF     */
	V9= fix(((V8))->in.in_slots[6]);
	V10= ((V8))->in.in_slots[7];
	((V6))->in.in_slots[4]= MAKE_FIXNUM(V9);
	(((V10))->ust.ust_self[(V9)+(0)]=(57));
	(*LK15)(1,(V1))                           /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L1632;}
	((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L1630;
L1632:
	(*LK6)(2,(V1),VV[82])                     /*  X-TYPE-ERROR    */;
L1630:
	(*LK15)(1,(V2))                           /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L1636;}
	((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(8))))=fix(((V2))->in.in_slots[0]));
	goto L1634;
L1636:
	(*LK6)(2,(V2),VV[82])                     /*  X-TYPE-ERROR    */;
L1634:
	{register int V11;                        /*  .VALUE.         */
	V11= ((V5) & (8388607));
	(*LK7)(2,MAKE_FIXNUM(V11),VV[249])        /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1641;}
	((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(12))))=V11);
	goto L1638;
L1641:
	(*LK6)(2,MAKE_FIXNUM(V11),VV[249])        /*  X-TYPE-ERROR    */;
	}
L1638:
	((*(unsigned short *)(((V10))->ust.ust_self+((V9)+(2))))=4);
	((V6))->in.in_slots[6]= MAKE_FIXNUM((V9)+(16));
	V7=(*LK16)(1,(V6))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V7);
	(*LK17)(1,(V6))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V7);
	RETURN(V7);}
	}
L1591:
	VALUES(0) = Cnil;
	RETURN(1);
	}
L1553:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for COPY-GCONTEXT                         */
static L67(int narg, object V1, object V2)
{ VT69 VLEX69 CLSR69
TTL:
	VALUES(0) = (VV[320]->s.s_gfdef);
	Lapply(4,VALUES(0),(V1),(V2),VV[266])     /*  APPLY           */;
	{volatile object V3;                      /*  EXTENSIONS      */
	volatile int V4;                          /*  I               */
	V4= 27;
	V3= (VV[77]->s.s_dbind);
L1650:
	if(!((V3)==Cnil)){
	goto L1651;}
	VALUES(0) = Cnil;
	RETURN(1);
L1651:
	(*LK24)(1,CAR((V3)))                      /*  GCONTEXT-EXTENSION-COPY-FUNCTION*/;
	T0= VALUES(0);
	funcall(4,T0,(V1),(V2),(((V1))->in.in_slots[5])->v.v_self[V4]);
	V3= CDR((V3));
	V4= (V4)+(1);
	goto L1650;
	}
}
/*	function definition for FREE-GCONTEXT                         */
static L68(int narg, object V1)
{ VT70 VLEX70 CLSR70
TTL:
	{object V2;                               /*  DISPLAY         */
	V2= ((V1))->in.in_slots[1];
	{register object V3;                      /*  .DISPLAY.       */
	V3= (V2);
	if((((V3))->in.in_slots[10])==Cnil){
	goto L1662;}
	(*LK21)(3,VV[232],VV[223],(V3))           /*  X-ERROR         */;
L1662:
	{register object V4;                      /*  %BUFFER         */
	V4= (V3);
	if(!(((fix(((V4))->in.in_slots[6]))+(160))>=(fix(((V4))->in.in_slots[2])))){
	goto L1666;}
	(*LK14)(1,(V4))                           /*  BUFFER-FLUSH    */;
L1666:
	{register int V5;                         /*  BUFFER-BOFFSET  */
	register object V6;                       /*  BUFFER-BBUF     */
	V5= fix(((V4))->in.in_slots[6]);
	V6= ((V4))->in.in_slots[7];
	((V3))->in.in_slots[4]= MAKE_FIXNUM(V5);
	(((V6))->ust.ust_self[(V5)+(0)]=(60));
	(*LK15)(1,(V1))                           /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L1677;}
	((*(unsigned long *)(((V6))->ust.ust_self+((V5)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L1675;
L1677:
	(*LK6)(2,(V1),VV[82])                     /*  X-TYPE-ERROR    */;
L1675:
	((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(2))))=2);
	((V3))->in.in_slots[6]= MAKE_FIXNUM((V5)+(8));
	(*LK16)(1,(V3))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK17)(1,(V3))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	L6(1,((V1))->in.in_slots[4])              /*  DEALLOCATE-GCONTEXT-STATE*/;
	L6(1,((V1))->in.in_slots[5])              /*  DEALLOCATE-GCONTEXT-STATE*/;
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	macro definition for DEFINE-GCONTEXT-ACCESSOR                 */
static L69(int narg, object V1, object V2)
{ VT71 VLEX71 CLSR71
	{object V3=CDR(V1),V4,V5,V6,V7;
	V4= CAR(V3);
	V3=CDR(V3);
	{object V8;
	V8=getf(V3,VV[297],OBJNULL);
	if(V8==OBJNULL){
	V5= Cnil;
	} else {
	V5= V8;}
	V8=getf(V3,VV[298],OBJNULL);
	if(V8==OBJNULL){
	V6= Cnil;
	} else {
	V6= V8;}
	V8=getf(V3,VV[299],OBJNULL);
	if(V8==OBJNULL){
	V7= Cnil;
	} else {
	V7= V8;}}
	{register object V9;                      /*  GC-NAME         */
	object V10;                               /*  KEY-NAME        */
	object V11;                               /*  SETFER          */
	object V12;                               /*  INTERNAL-SET-FUNCTION*/
	object V13;                               /*  INTERNAL-COPY-FUNCTION*/
	register object V14;                      /*  INTERNAL-STATE-INDEX*/
	(*LK27)(3,VV[267],coerce_to_string(VV[98]),coerce_to_string((V4)))/*  CONCATENATE*/;
	Lintern(1,VALUES(0))                      /*  INTERN          */;
	V9= VALUES(0);
	(*LK28)(1,(V4))                           /*  KINTERN         */;
	V10= VALUES(0);
	(*LK4)(2,VV[268],(V9))                    /*  XINTERN         */;
	V11= VALUES(0);
	(*LK4)(2,VV[269],(V9))                    /*  XINTERN         */;
	V12= VALUES(0);
	(*LK4)(2,VV[270],(V9))                    /*  XINTERN         */;
	V13= VALUES(0);
	(*LK4)(3,VV[271],(V9),VV[272])            /*  XINTERN         */;
	V14= VALUES(0);
	if(((V7))!=Cnil){
	goto L1694;}
	{object V15= CONS((V6),VV[276]);
	V7= list(4,VV[273],VV[274],VV[275],list(4,VV[130],VV[109],(V15),list(3,VV[277],VV[278],list(2,VV[243],(V4)))));}
L1694:
	{object V15= list(2,VV[243],(V10));
	{object V16= list(2,VV[243],(V12));
	{object V17= list(3,VV[279],VV[280],list(3,VV[281],(V14),list(5,VV[282],(V15),(V5),(V16),list(2,VV[243],(V13)))));
	{object V18= list(4,VV[103],(V9),VV[283],list(3,VV[79],VV[284],(V14)));
	{object V19= list(4,VV[103],(V11),VV[285],list(4,VV[89],VV[286],VV[287],list(3,VV[97],list(3,VV[79],VV[121],(V14)),VV[288])));
	{object V20= list(3,VV[127],(V9),(V11));
	{object V21= CONS((V6),VV[290]);
	{object V22= list(3,VV[79],VV[291],(V14));
	{object V23= list(5,VV[103],(V12),VV[289],(V21),list(3,VV[97],(V22),list(3,VV[97],list(3,VV[79],VV[292],(V14)),VV[288])));
	{object V24= CONS((V7),VV[294]);
	{object V25= list(3,VV[79],VV[295],(V14));
	{object V26= list(5,VV[103],(V13),VV[293],(V24),list(3,VV[97],(V25),list(3,VV[97],list(3,VV[79],VV[296],(V14)),VV[288])));
	VALUES(0) = list(8,VV[96],(V17),(V18),(V19),(V20),(V23),(V26),list(2,VV[243],(V4)));
	RETURN(1);}}}}}}}}}}}}
	}}
}
/*	function definition for ADD-GCONTEXT-EXTENSION                */
static L70(int narg, object V1, object V2, object V3, object V4)
{ VT72 VLEX72 CLSR72
TTL:
	{object V5;                               /*  NUMBER          */
	{object V6= (VV[77]->s.s_dbind);
	VALUES(0) = (VV[399]->s.s_gfdef);
	(*LK5)(4,(V1),V6,VV[236],VALUES(0))       /*  POSITION        */;}
	if(VALUES(0)==Cnil)goto L1699;
	V5= VALUES(0);
	goto L1698;
L1699:
	{int V6;
	V6= length((VV[77]->s.s_dbind));
	(VV[77]->s.s_dbind)= CONS(Cnil,(VV[77]->s.s_dbind));
	V5= MAKE_FIXNUM(V6);
	}
L1698:
	{object V6;
	object V7;
	V6= (VV[77]->s.s_dbind);
	L3(8,VV[225],(V1),VV[297],(V2),VV[298],(V3),VV[299],(V4))/*  MAKE-GCONTEXT-EXTENSION*/;
	V7= VALUES(0);
	CAR(nthcdr(fix((V5)),(V6))) = (V7);
	}
	VALUES(0) = number_plus((V5),MAKE_FIXNUM(27));
	RETURN(1);
	}
}
static LKF28(int narg, ...) {TRAMPOLINK(VV[434],&LK28);}
static LKF27(int narg, ...) {TRAMPOLINK(VV[433],&LK27);}
static LKF26(int narg, ...) {TRAMPOLINK(VV[428],&LK26);}
static LKF25(int narg, ...) {TRAMPOLINK(VV[427],&LK25);}
static LKF24(int narg, ...) {TRAMPOLINK(VV[402],&LK24);}
static LKF23(int narg, ...) {TRAMPOLINK(VV[401],&LK23);}
static LKF22(int narg, ...) {TRAMPOLINK(VV[400],&LK22);}
static LKF21(int narg, ...) {TRAMPOLINK(VV[397],&LK21);}
static LKF20(int narg, ...) {TRAMPOLINK(VV[395],&LK20);}
static LKF19(int narg, ...) {TRAMPOLINK(VV[394],&LK19);}
static LKF18(int narg, ...) {TRAMPOLINK(VV[393],&LK18);}
static LKF17(int narg, ...) {TRAMPOLINK(VV[392],&LK17);}
static LKF16(int narg, ...) {TRAMPOLINK(VV[391],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[390],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[389],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[387],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[386],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[385],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[383],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[359],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[357],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[338],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[335],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[334],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[332],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[330],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[328],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[326],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[73],&LK0);}
