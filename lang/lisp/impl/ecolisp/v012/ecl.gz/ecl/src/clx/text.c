
#include "text.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	siLAmake_special(1,VV[0])                 /*  *MAKE-SPECIAL   */;
	(VV[0]->s.s_dbind)= MAKE_FIXNUM(254);
	putprop(VV[1],VV[3],VV[2]);
	VV[50] = make_cfun(LC1,Cnil,&Cblock);
	VALUES(0) = VV[50];
	putprop(VV[1],VALUES(0),VV[4]);
	putprop(VV[1],Cnil,VV[6]);
	MF0(VV[51],L2);
	(void)putprop(VV[51],VV[Vdeb51],VV[52]);
	MF0key(VV[53],L3,3,L3keys);
	(void)putprop(VV[53],VV[Vdeb53],VV[52]);
	MF0key(VV[54],L4,3,L4keys);
	(void)putprop(VV[54],VV[Vdeb54],VV[52]);
	MF0(VV[55],L5);
	(void)putprop(VV[55],VV[Vdeb55],VV[52]);
	MF0(VV[56],L6);
	(void)putprop(VV[56],VV[Vdeb56],VV[52]);
	MF0(VV[57],L7);
	(void)putprop(VV[57],VV[Vdeb57],VV[52]);
	putprop(VV[33],VV[34],VV[2]);
	VV[58] = make_cfun(LC8,Cnil,&Cblock);
	VALUES(0) = VV[58];
	putprop(VV[33],VALUES(0),VV[4]);
	putprop(VV[33],Cnil,VV[6]);
	MF0key(VV[59],L9,3,L9keys);
	(void)putprop(VV[59],VV[Vdeb59],VV[52]);
	MF0key(VV[60],L10,5,L10keys);
	(void)putprop(VV[60],VV[Vdeb60],VV[52]);
	MF0(VV[61],L11);
	(void)putprop(VV[61],VV[Vdeb61],VV[52]);
	MF0(VV[62],L12);
	(void)putprop(VV[62],VV[Vdeb62],VV[52]);
	MF0key(VV[63],L13,3,L13keys);
	(void)putprop(VV[63],VV[Vdeb63],VV[52]);
	MF0key(VV[64],L14,5,L14keys);
	(void)putprop(VV[64],VV[Vdeb64],VV[52]);
	MF0(VV[65],L15);
	(void)putprop(VV[65],VV[Vdeb65],VV[52]);
	MF0(VV[66],L16);
	(void)putprop(VV[66],VV[Vdeb66],VV[52]);
	MF0(VV[67],L17);
	(void)putprop(VV[67],VV[Vdeb67],VV[52]);
	MF0key(VV[68],L18,8,L18keys);
	(void)putprop(VV[68],VV[Vdeb68],VV[52]);
	MF0(VV[69],L19);
	(void)putprop(VV[69],VV[Vdeb69],VV[52]);
	MF0key(VV[70],L20,3,L20keys);
	(void)putprop(VV[70],VV[Vdeb70],VV[52]);
	MF0key(VV[71],L21,4,L21keys);
	(void)putprop(VV[71],VV[Vdeb71],VV[52]);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	local function CLOSURE                                        */
static LC8(int narg)
{ VT3 VLEX3 CLSR3
	VALUES(0) = VV[35];
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC1(int narg)
{ VT4 VLEX4 CLSR4
	VALUES(0) = VV[5];
	RETURN(1);
}
/*	function definition for TRANSLATE-DEFAULT                     */
static L2(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT5 VLEX5 CLSR5
	{volatile int V7;
	volatile int V8;
	volatile int V9;
	V7= fix(V2);
	V8= fix(V3);
	V9= fix(V6);
TTL:
	if(!(type_of((V1))==t_string)){
	goto L17;}
	{volatile int V10;                        /*  I               */
	volatile int V11;                         /*  J               */
	volatile object V12;                      /*  CHAR            */
	V10= V7;
	V11= V9;
	V12= Cnil;
L22:
	if(!((V10)>=(V8))){
	goto L23;}
	VALUES(0) = MAKE_FIXNUM(V10);
	RETURN(1);
L23:
	V12= code_char(((V1))->ust.ust_self[V10]);
	Lgraphic_char_p(1,(V12))                  /*  GRAPHIC-CHAR-P  */;
	if(VALUES(0)==Cnil){
	goto L28;}
	if(!((TYPE_OF((V5)))==(VV[7]))){
	goto L32;}
	(*LK0)(1,(V12))                           /*  CHAR->CARD8     */;
	((V5))->ust.ust_self[V11]= fix(VALUES(0));
	goto L26;
L32:
	{register object V14;
	register object V15;
	V14= (V5);
	V15= MAKE_FIXNUM(V11);
	(*LK0)(1,(V12))                           /*  CHAR->CARD8     */;
	((V14))->v.v_self[fix((V15))]= VALUES(0);
	goto L26;
	}
L28:
	VALUES(0) = MAKE_FIXNUM(V10);
	RETURN(1);
L26:
	V10= (V10)+(1);
	V11= (V11)+(1);
	goto L22;
	}
L17:
	{volatile int V17;                        /*  I               */
	volatile int V18;                         /*  J               */
	volatile object V19;                      /*  ELT             */
	V17= V7;
	V18= V9;
	V19= Cnil;
L45:
	if(!((V17)>=(V8))){
	goto L46;}
	VALUES(0) = MAKE_FIXNUM(V17);
	RETURN(1);
L46:
	V19= elt((V1),V17);
	if(!(CHARACTERP((V19)))){
	goto L53;}
	Lgraphic_char_p(1,(V19))                  /*  GRAPHIC-CHAR-P  */;
	if(VALUES(0)==Cnil){
	goto L53;}
	if(!((TYPE_OF((V5)))==(VV[7]))){
	goto L58;}
	(*LK0)(1,(V19))                           /*  CHAR->CARD8     */;
	((V5))->ust.ust_self[V18]= fix(VALUES(0));
	goto L51;
L58:
	{register object V21;
	register object V22;
	V21= (V5);
	V22= MAKE_FIXNUM(V18);
	(*LK0)(1,(V19))                           /*  CHAR->CARD8     */;
	((V21))->v.v_self[fix((V22))]= VALUES(0);
	goto L51;
	}
L53:
	if(!(type_of((V19))==t_fixnum||type_of((V19))==t_bignum)){
	goto L65;}
	((V5))->v.v_self[V18]= (V19);
	goto L51;
L65:
	VALUES(0) = MAKE_FIXNUM(V17);
	RETURN(1);
L51:
	V17= (V17)+(1);
	V18= (V18)+(1);
	goto L45;
	}
	}
}
/*	function definition for TEXT-EXTENTS                          */
static L3(int narg, object V1, object V2, ...)
{ VT6 VLEX6 CLSR6
	bds_check;
	{volatile object V3;
	volatile object V4;
	volatile object V5;
	va_list args; va_start(args, V2);
	narg -=2;
	{ object keyvars[6];
	parse_key(narg,args,3,L3keys,keyvars,OBJNULL,FALSE);
	if(keyvars[3]==Cnil){
	V3= MAKE_FIXNUM(0);
	}else{
	V3= keyvars[0];}
	V4= keyvars[1];
	V5= keyvars[2];
	}
	(*LK1)(1,(V1))                            /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L72;}
	(*LK2)(1,(V1))                            /*  FORCE-GCONTEXT-CHANGES*/;
	(*LK3)(2,(V1),Ct)                         /*  GCONTEXT-FONT   */;
	V1= VALUES(0);
L72:
	bds_bind(VV[8],MAKE_FIXNUM(4));           /*  *PRINT-LEVEL*   */
	bds_bind(VV[9],MAKE_FIXNUM(4));           /*  *PRINT-LENGTH*  */
L79:
	(*LK4)(2,(V1),VV[10])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L80;}
	bds_unwind1;
	bds_unwind1;
	goto L77;
L80:
	Lcerror(5,VV[11],VV[12],VV[10],(V1),VV[10])/*  CERROR         */;
	Lformat(3,(VV[13]->s.s_dbind),VV[14],VV[10])/*  FORMAT        */;
	Lfinish_output(1,(VV[13]->s.s_dbind))     /*  FINISH-OUTPUT   */;
	Lread(0)                                  /*  READ            */;
	V1= VALUES(0);
	Lformat(2,(VV[13]->s.s_dbind),VV[15])     /*  FORMAT          */;
	goto L79;
L77:
	{volatile object V6;                      /*  LEFT-BEARING    */
	volatile object V7;                       /*  RIGHT-BEARING   */
	volatile object V8;                       /*  WIDTH           */
	volatile int V9;                          /*  ASCENT          */
	volatile int V10;                         /*  DESCENT         */
	volatile int V11;                         /*  OVERALL-ASCENT  */
	volatile int V12;                         /*  OVERALL-DESCENT */
	volatile object V13;                      /*  OVERALL-DIRECTION*/
	volatile object V14;                      /*  NEXT-START      */
	volatile object V15;                      /*  DISPLAY         */
	V6= MAKE_FIXNUM(0);
	V7= MAKE_FIXNUM(0);
	V8= MAKE_FIXNUM(0);
	V9= 0;
	V10= 0;
	(*LK5)(1,(V1))                            /*  FONT-ASCENT     */;
	V11= fix(VALUES(0));
	(*LK6)(1,(V1))                            /*  FONT-DESCENT    */;
	V12= fix(VALUES(0));
	(*LK7)(1,(V1))                            /*  FONT-DIRECTION  */;
	V13= VALUES(0);
	V14= Cnil;
	V15= ((V1))->in.in_slots[1];
	if((((V15))->in.in_slots[10])==Cnil){
	goto L102;}
	(*LK8)(3,VV[17],VV[18],(V15))             /*  X-ERROR         */;
L102:
	{volatile object V16;                     /*  WBUF            */
	volatile int V17;                         /*  SRC-END         */
	volatile int V18;                         /*  SRC-START       */
	volatile int V19;                         /*  END             */
	volatile int V20;                         /*  BUF-END         */
	volatile object V21;                      /*  NEW-FONT        */
	volatile int V22;                         /*  FONT-ASCENT     */
	volatile int V23;                         /*  FONT-DESCENT    */
	volatile object V24;                      /*  FONT-DIRECTION  */
	volatile object V25;                      /*  STOP-P          */
	V16= ((V15))->in.in_slots[8];
	if((V4)!=Cnil){
	V17= fix((V4));
	goto L106;}
	V17= length((V2));
L106:
	V18= fix((V3));
	{int V26= (V18)+(256);
	V19= (V17)<=(V26)?V17:V26;}
	V20= 0;
	V21= Cnil;
	V22= 0;
	V23= 0;
	V24= Cnil;
	V25= Cnil;
L116:
	if(((V25))!=Cnil){
	goto L118;}
	if(!((V18)>=(V17))){
	goto L117;}
L118:
	if(!((V18)<(V17))){
	goto L101;}
	V14= MAKE_FIXNUM(V18);
	goto L101;
L117:
	{object V27;
	{ int V29,V28;
	{object V30;
	V30= (V5);
	if(((V30))==Cnil){
	goto L130;}
	T0= (V30);
	goto L128;
L130:
	T0= (VV[51]->s.s_gfdef);
	}
L128:
	V28=funcall(7,T0,(V2),MAKE_FIXNUM(V18),MAKE_FIXNUM(V19),(V1),(V16),MAKE_FIXNUM(0));
	APPLY(V28,Llist,&VALUES(0))               /*  LIST            */;
	V27= VALUES(0);}
	V21= CADR((V27));
	V20= fix(CAR((V27)));
	}
	V20= (V20)-(V18);
	if(((V21))!=Cnil){
	goto L139;}
	V25= Ct;
	goto L137;
L139:
	if(!(type_of((V21))==t_fixnum||type_of((V21))==t_bignum)){
	goto L137;}
	V8= number_plus((V8),(V21));
L137:
	{object V28;                              /*  W               */
	register object V29;                      /*  A               */
	register object V30;                      /*  D               */
	register object V31;                      /*  L               */
	register object V32;                      /*  R               */
	V28= Cnil;
	V29= Cnil;
	V30= Cnil;
	V31= Cnil;
	V32= Cnil;
	if((((V1))->in.in_slots[5])!=Cnil){
	goto L147;}
	if((((V1))->in.in_slots[6])==Cnil){
	goto L148;}
L147:
	{ int V33;
	V33=L7(5,(V1),(V16),MAKE_FIXNUM(0),MAKE_FIXNUM(V20),Cnil)/*  TEXT-EXTENTS-LOCAL*/;
	if (V33>0) {
	V28= VALUES(0);
	V33--;
	} else {
	V28= Cnil;}
	if (V33>0) {
	V29= VALUES(1);
	V33--;
	} else {
	V29= Cnil;}
	if (V33>0) {
	V30= VALUES(2);
	V33--;
	} else {
	V30= Cnil;}
	if (V33>0) {
	V31= VALUES(3);
	V33--;
	} else {
	V31= Cnil;}
	if (V33>0) {
	V32= VALUES(4);
	} else {
	V32= Cnil;}
	
	}
	(*LK5)(1,(V1))                            /*  FONT-ASCENT     */;
	V22= fix(VALUES(0));
	(*LK6)(1,(V1))                            /*  FONT-DESCENT    */;
	V23= fix(VALUES(0));
	(*LK7)(1,(V1))                            /*  FONT-DIRECTION  */;
	V24= VALUES(0);
	goto L146;
L148:
	{ int V33;
	V33=L5(4,(V1),(V16),MAKE_FIXNUM(0),MAKE_FIXNUM(V20))/*  TEXT-EXTENTS-SERVER*/;
	if (V33>0) {
	V28= VALUES(0);
	V33--;
	} else {
	V28= Cnil;}
	if (V33>0) {
	V29= VALUES(1);
	V33--;
	} else {
	V29= Cnil;}
	if (V33>0) {
	V30= VALUES(2);
	V33--;
	} else {
	V30= Cnil;}
	if (V33>0) {
	V31= VALUES(3);
	V33--;
	} else {
	V31= Cnil;}
	if (V33>0) {
	V32= VALUES(4);
	V33--;
	} else {
	V32= Cnil;}
	if (V33>0) {
	V22= fix(VALUES(5));
	V33--;
	} else {
	V22= fix(Cnil);}
	if (V33>0) {
	V23= fix(VALUES(6));
	V33--;
	} else {
	V23= fix(Cnil);}
	if (V33>0) {
	V24= VALUES(7);
	} else {
	V24= Cnil;}
	
	}
L146:
	V8= number_plus((V8),(V28));
	if(!((V18)==(fix((V3))))){
	goto L163;}
	V6= (V31);
	V7= (V32);
	V9= fix((V29));
	V10= fix((V30));
	goto L145;
L163:
	V6= (number_compare((V6),(V31))<=0?(V6):(V31));
	V7= (number_compare((V7),(V32))>=0?(V7):(V32));
	V9= (V9)>=(fix((V29)))?V9:fix((V29));
	V10= (V10)>=(fix((V30)))?V10:fix((V30));
	}
L145:
	(*LK9)(1,(V21))                           /*  FONT-P          */;
	if(VALUES(0)==Cnil){
	goto L179;}
	V1= (V21);
L179:
	V11= (V11)>=(V22)?V11:V22;
	V12= (V12)>=(V23)?V12:V23;
	if(((V13)!= VV[86]))goto L188;
	V13= (V24);
	goto L187;
L188:
	if(((V13)!= VV[20]))goto L190;
	if(((V24))==(VV[20])){
	goto L187;}
	V13= Cnil;
	goto L187;
L190:
	if(((V13)!= VV[21]))goto L194;
	if(((V24))==(VV[21])){
	goto L187;}
	V13= Cnil;
	goto L187;
L194:
L187:
	V18= (V18)+(V20);
	{int V33= (V18)+(256);
	V19= (V17)<=(V33)?V17:V33;}
	goto L116;
	}
L101:
	VALUES(8) = (V14);
	VALUES(7) = (V13);
	VALUES(6) = MAKE_FIXNUM(V12);
	VALUES(5) = MAKE_FIXNUM(V11);
	VALUES(4) = (V7);
	VALUES(3) = (V6);
	VALUES(2) = MAKE_FIXNUM(V10);
	VALUES(1) = MAKE_FIXNUM(V9);
	VALUES(0) = (V8);
	RETURN(9);
	}
	}
}
/*	function definition for TEXT-WIDTH                            */
static L4(int narg, object V1, object V2, ...)
{ VT7 VLEX7 CLSR7
	bds_check;
	{volatile object V3;
	volatile object V4;
	volatile object V5;
	va_list args; va_start(args, V2);
	narg -=2;
	{ object keyvars[6];
	parse_key(narg,args,3,L4keys,keyvars,OBJNULL,FALSE);
	if(keyvars[3]==Cnil){
	V3= MAKE_FIXNUM(0);
	}else{
	V3= keyvars[0];}
	V4= keyvars[1];
	V5= keyvars[2];
	}
	(*LK1)(1,(V1))                            /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L204;}
	(*LK2)(1,(V1))                            /*  FORCE-GCONTEXT-CHANGES*/;
	(*LK3)(2,(V1),Ct)                         /*  GCONTEXT-FONT   */;
	V1= VALUES(0);
L204:
	bds_bind(VV[8],MAKE_FIXNUM(4));           /*  *PRINT-LEVEL*   */
	bds_bind(VV[9],MAKE_FIXNUM(4));           /*  *PRINT-LENGTH*  */
L211:
	(*LK4)(2,(V1),VV[10])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L212;}
	bds_unwind1;
	bds_unwind1;
	goto L209;
L212:
	Lcerror(5,VV[11],VV[12],VV[10],(V1),VV[10])/*  CERROR         */;
	Lformat(3,(VV[13]->s.s_dbind),VV[14],VV[10])/*  FORMAT        */;
	Lfinish_output(1,(VV[13]->s.s_dbind))     /*  FINISH-OUTPUT   */;
	Lread(0)                                  /*  READ            */;
	V1= VALUES(0);
	Lformat(2,(VV[13]->s.s_dbind),VV[15])     /*  FORMAT          */;
	goto L211;
L209:
	{volatile object V6;                      /*  WIDTH           */
	volatile object V7;                       /*  NEXT-START      */
	volatile object V8;                       /*  DISPLAY         */
	V6= MAKE_FIXNUM(0);
	V7= Cnil;
	V8= ((V1))->in.in_slots[1];
	if((((V8))->in.in_slots[10])==Cnil){
	goto L227;}
	(*LK8)(3,VV[17],VV[18],(V8))              /*  X-ERROR         */;
L227:
	{volatile object V9;                      /*  WBUF            */
	volatile int V10;                         /*  SRC-END         */
	volatile int V11;                         /*  SRC-START       */
	volatile int V12;                         /*  END             */
	volatile int V13;                         /*  BUF-END         */
	volatile object V14;                      /*  NEW-FONT        */
	volatile object V15;                      /*  STOP-P          */
	V9= ((V8))->in.in_slots[8];
	if((V4)!=Cnil){
	V10= fix((V4));
	goto L231;}
	V10= length((V2));
L231:
	V11= fix((V3));
	{int V16= (V11)+(256);
	V12= (V10)<=(V16)?V10:V16;}
	V13= 0;
	V14= Cnil;
	V15= Cnil;
L238:
	if(((V15))!=Cnil){
	goto L240;}
	if(!((V11)>=(V10))){
	goto L239;}
L240:
	if(!((V11)<(V10))){
	goto L226;}
	V7= MAKE_FIXNUM(V11);
	goto L226;
L239:
	{object V17;
	{ int V19,V18;
	{object V20;
	V20= (V5);
	if(((V20))==Cnil){
	goto L252;}
	T0= (V20);
	goto L250;
L252:
	T0= (VV[51]->s.s_gfdef);
	}
L250:
	V18=funcall(7,T0,(V2),MAKE_FIXNUM(V11),MAKE_FIXNUM(V12),(V1),(V9),MAKE_FIXNUM(0));
	APPLY(V18,Llist,&VALUES(0))               /*  LIST            */;
	V17= VALUES(0);}
	V14= CADR((V17));
	V13= fix(CAR((V17)));
	}
	V13= (V13)-(V11);
	if(((V14))!=Cnil){
	goto L261;}
	V15= Ct;
	goto L259;
L261:
	if(!(type_of((V14))==t_fixnum||type_of((V14))==t_bignum)){
	goto L259;}
	V6= number_plus((V6),(V14));
L259:
	if((((V1))->in.in_slots[5])!=Cnil){
	goto L270;}
	if((((V1))->in.in_slots[6])==Cnil){
	goto L271;}
L270:
	L7(5,(V1),(V9),MAKE_FIXNUM(0),MAKE_FIXNUM(V13),VV[22])/*  TEXT-EXTENTS-LOCAL*/;
	goto L269;
L271:
	L6(4,(V1),(V9),MAKE_FIXNUM(0),MAKE_FIXNUM(V13))/*  TEXT-WIDTH-SERVER*/;
L269:
	V6= number_plus((V6),VALUES(0));
	(*LK9)(1,(V14))                           /*  FONT-P          */;
	if(VALUES(0)==Cnil){
	goto L275;}
	V1= (V14);
L275:
	V11= (V11)+(V13);
	{int V18= (V11)+(256);
	V12= (V10)<=(V18)?V10:V18;}
	goto L238;
	}
L226:
	VALUES(1) = (V7);
	VALUES(0) = (V6);
	RETURN(2);
	}
	}
}
/*	function definition for TEXT-EXTENTS-SERVER                   */
static L5(int narg, object V1, object V2, object V3, object V4)
{ VT8 VLEX8 CLSR8
	{volatile int V5;
	volatile int V6;
	V5= fix(V3);
	V6= fix(V4);
TTL:
	{volatile object V7;                      /*  DISPLAY         */
	volatile object V8;
	volatile int V9;                          /*  LENGTH          */
	volatile int V10;                         /*  FONT-ID         */
	V8= ((V1))->in.in_slots[1];
	V9= (V6)-(V5);
	(*LK10)(1,(V1))                           /*  FONT-ID         */;
	V10= fix(VALUES(0));
	V7= V8;
	{volatile object V11;                     /*  .DISPLAY.       */
	volatile object V12;                      /*  .PENDING-COMMAND.*/
	volatile object V13;                      /*  .REPLY-BUFFER.  */
	V11= (V7);
	V12= Cnil;
	V13= Cnil;
	{ int V14; volatile bool unwinding = FALSE;
	if ((V14=frs_push(FRS_PROTECT,Cnil))) {
	V14--; unwinding = TRUE;} else {
	if((((V11))->in.in_slots[10])==Cnil){
	goto L289;}
	(*LK8)(3,VV[17],VV[18],(V11))             /*  X-ERROR         */;
L289:
	(*LK11)(1,(V11))                          /*  START-PENDING-COMMAND*/;
	V12= VALUES(0);
	{register object V15;                     /*  %BUFFER         */
	V15= (V11);
	if(!(((fix(((V15))->in.in_slots[6]))+(160))>=(fix(((V15))->in.in_slots[2])))){
	goto L295;}
	(*LK12)(1,(V15))                          /*  BUFFER-FLUSH    */;
L295:
	{register int V16;                        /*  BUFFER-BOFFSET  */
	register object V17;                      /*  BUFFER-BBUF     */
	V16= fix(((V15))->in.in_slots[6]);
	V17= ((V15))->in.in_slots[7];
	((V11))->in.in_slots[4]= MAKE_FIXNUM(V16);
	(((V17))->ust.ust_self[(V16)+(0)]=(48));
	{object V18;                              /*  .VALUE.         */
	Loddp(1,MAKE_FIXNUM(V9))                  /*  ODDP            */;
	V18= VALUES(0);
	if(((V18))==Cnil){
	goto L310;}
	T0= MAKE_FIXNUM(1);
	goto L308;
L310:
	T0= MAKE_FIXNUM(0);
L308:
	VALUES(0) = MAKE_FIXNUM((((V17))->ust.ust_self[(V16)+(1)]=(fix(T0))));
	if(VALUES(0)==Cnil)goto L306;
	goto L304;
L306:
	(*LK13)(2,(V18),VV[23])                   /*  X-TYPE-ERROR    */;
	}
L304:
	{int V18;                                 /*  .VALUE.         */
	Lceiling(2,MAKE_FIXNUM(V9),MAKE_FIXNUM(2))/*  CEILING         */;
	V18= (fix(VALUES(0)))+(2);
	VALUES(0) = MAKE_FIXNUM(((*(unsigned short *)(((V17))->ust.ust_self+((V16)+(2))))=V18));
	if(VALUES(0)==Cnil)goto L315;
	goto L312;
L315:
	(*LK13)(2,MAKE_FIXNUM(V18),VV[24])        /*  X-TYPE-ERROR    */;
	}
L312:
	(*LK4)(2,MAKE_FIXNUM(V10),VV[25])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L319;}
	((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(4))))=V10);
	goto L317;
L319:
	(*LK13)(2,MAKE_FIXNUM(V10),VV[25])        /*  X-TYPE-ERROR    */;
L317:
	(*LK4)(2,(V2),VV[26])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L323;}
	(*LK14)(6,(V15),MAKE_FIXNUM((V16)+(8)),(V2),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),Cnil)/*  WRITE-SEQUENCE-CHAR2B*/;
	goto L321;
L323:
	(*LK13)(2,(V2),VV[27])                    /*  X-TYPE-ERROR    */;
L321:
	(*LK15)(1,(V11))                          /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V11))                          /*  BUFFER-FORCE-OUTPUT*/;
	(*LK17)(1,(V11))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK18)(2,(V11),(V12))                    /*  READ-REPLY      */;
	V13= VALUES(0);
	{object V15;                              /*  %REPLY-BUFFER   */
	object V16;                               /*  %BUFFER         */
	{register int V17;                        /*  BUFFER-BOFFSET  */
	register object V18;                      /*  BUFFER-BBUF     */
	V17= 0;
	V18= ((V13))->in.in_slots[1];
	{int V19= (*(long *)(((V18))->ust.ust_self+((V17)+(16))));
	{int V20= (*(short *)(((V18))->st.st_self+((V17)+(12))));
	{int V21= (*(short *)(((V18))->st.st_self+((V17)+(14))));
	{int V22= (*(long *)(((V18))->ust.ust_self+((V17)+(20))));
	{int V23= (*(long *)(((V18))->ust.ust_self+((V17)+(24))));
	{int V24= (*(short *)(((V18))->st.st_self+((V17)+(8))));
	{int V25= (*(short *)(((V18))->st.st_self+((V17)+(10))));
	{int V26;
	V26= ((V18))->ust.ust_self[(V17)+(1)];
	if((V26)<(2)){
	goto L336;}
	VALUES(0) = Cnil;
	goto L334;
L336:
	VALUES(0) = (VV[29])->v.v_self[V26];
	}
L334:
	VALUES(7) = VALUES(0);
	VALUES(6) = MAKE_FIXNUM(V25);
	VALUES(5) = MAKE_FIXNUM(V24);
	VALUES(4) = MAKE_FIXNUM(V23);
	VALUES(3) = MAKE_FIXNUM(V22);
	VALUES(2) = MAKE_FIXNUM(V21);
	VALUES(1) = MAKE_FIXNUM(V20);
	VALUES(0) = MAKE_FIXNUM(V19);
	V14=8;}}}}}}}
	}
	}
	}
	frs_pop();
	MV_SAVE(V14);
	if(((V13))==Cnil){
	goto L339;}
	(*LK19)(1,(V13))                          /*  DEALLOCATE-REPLY-BUFFER*/;
L339:
	if(((V12))==Cnil){
	goto L338;}
	(*LK20)(2,(V11),(V12))                    /*  STOP-PENDING-COMMAND*/;
L338:
	MV_RESTORE(V14);
	if (unwinding) unwind(nlj_fr,nlj_tag,V14+1);
	else {
	RETURN(V14);}}
	}
	}
	}
}
/*	function definition for TEXT-WIDTH-SERVER                     */
static L6(int narg, object V1, object V2, object V3, object V4)
{ VT9 VLEX9 CLSR9
	{volatile int V5;
	volatile int V6;
	V5= fix(V3);
	V6= fix(V4);
TTL:
	{volatile object V7;                      /*  DISPLAY         */
	volatile object V8;
	volatile int V9;                          /*  LENGTH          */
	volatile int V10;                         /*  FONT-ID         */
	V8= ((V1))->in.in_slots[1];
	V9= (V6)-(V5);
	(*LK10)(1,(V1))                           /*  FONT-ID         */;
	V10= fix(VALUES(0));
	V7= V8;
	{volatile object V11;                     /*  .DISPLAY.       */
	volatile object V12;                      /*  .PENDING-COMMAND.*/
	volatile object V13;                      /*  .REPLY-BUFFER.  */
	V11= (V7);
	V12= Cnil;
	V13= Cnil;
	{ int V14; volatile bool unwinding = FALSE;
	if ((V14=frs_push(FRS_PROTECT,Cnil))) {
	V14--; unwinding = TRUE;} else {
	if((((V11))->in.in_slots[10])==Cnil){
	goto L349;}
	(*LK8)(3,VV[17],VV[18],(V11))             /*  X-ERROR         */;
L349:
	(*LK11)(1,(V11))                          /*  START-PENDING-COMMAND*/;
	V12= VALUES(0);
	{register object V15;                     /*  %BUFFER         */
	V15= (V11);
	if(!(((fix(((V15))->in.in_slots[6]))+(160))>=(fix(((V15))->in.in_slots[2])))){
	goto L355;}
	(*LK12)(1,(V15))                          /*  BUFFER-FLUSH    */;
L355:
	{register int V16;                        /*  BUFFER-BOFFSET  */
	register object V17;                      /*  BUFFER-BBUF     */
	V16= fix(((V15))->in.in_slots[6]);
	V17= ((V15))->in.in_slots[7];
	((V11))->in.in_slots[4]= MAKE_FIXNUM(V16);
	(((V17))->ust.ust_self[(V16)+(0)]=(48));
	{object V18;                              /*  .VALUE.         */
	Loddp(1,MAKE_FIXNUM(V9))                  /*  ODDP            */;
	V18= VALUES(0);
	if(((V18))==Cnil){
	goto L370;}
	T0= MAKE_FIXNUM(1);
	goto L368;
L370:
	T0= MAKE_FIXNUM(0);
L368:
	VALUES(0) = MAKE_FIXNUM((((V17))->ust.ust_self[(V16)+(1)]=(fix(T0))));
	if(VALUES(0)==Cnil)goto L366;
	goto L364;
L366:
	(*LK13)(2,(V18),VV[30])                   /*  X-TYPE-ERROR    */;
	}
L364:
	{int V18;                                 /*  .VALUE.         */
	Lceiling(2,MAKE_FIXNUM(V9),MAKE_FIXNUM(2))/*  CEILING         */;
	V18= (fix(VALUES(0)))+(2);
	VALUES(0) = MAKE_FIXNUM(((*(unsigned short *)(((V17))->ust.ust_self+((V16)+(2))))=V18));
	if(VALUES(0)==Cnil)goto L375;
	goto L372;
L375:
	(*LK13)(2,MAKE_FIXNUM(V18),VV[24])        /*  X-TYPE-ERROR    */;
	}
L372:
	(*LK4)(2,MAKE_FIXNUM(V10),VV[25])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L379;}
	((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(4))))=V10);
	goto L377;
L379:
	(*LK13)(2,MAKE_FIXNUM(V10),VV[25])        /*  X-TYPE-ERROR    */;
L377:
	(*LK4)(2,(V2),VV[26])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L383;}
	(*LK14)(6,(V15),MAKE_FIXNUM((V16)+(8)),(V2),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),Cnil)/*  WRITE-SEQUENCE-CHAR2B*/;
	goto L381;
L383:
	(*LK13)(2,(V2),VV[31])                    /*  X-TYPE-ERROR    */;
L381:
	(*LK15)(1,(V11))                          /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V11))                          /*  BUFFER-FORCE-OUTPUT*/;
	(*LK17)(1,(V11))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK18)(2,(V11),(V12))                    /*  READ-REPLY      */;
	V13= VALUES(0);
	{object V15;                              /*  %REPLY-BUFFER   */
	object V16;                               /*  %BUFFER         */
	{int V17;                                 /*  BUFFER-BOFFSET  */
	object V18;                               /*  BUFFER-BBUF     */
	V17= 0;
	V18= ((V13))->in.in_slots[1];
	VALUES(0)=MAKE_FIXNUM((*(long *)(((V18))->ust.ust_self+((V17)+(16)))));
	V14=1;
	}
	}
	}
	frs_pop();
	MV_SAVE(V14);
	if(((V13))==Cnil){
	goto L395;}
	(*LK19)(1,(V13))                          /*  DEALLOCATE-REPLY-BUFFER*/;
L395:
	if(((V12))==Cnil){
	goto L394;}
	(*LK20)(2,(V11),(V12))                    /*  STOP-PENDING-COMMAND*/;
L394:
	MV_RESTORE(V14);
	if (unwinding) unwind(nlj_fr,nlj_tag,V14+1);
	else {
	RETURN(V14);}}
	}
	}
	}
}
/*	function definition for TEXT-EXTENTS-LOCAL                    */
static L7(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT10 VLEX10 CLSR10
TTL:
	{volatile object V6;                      /*  CHAR-INFOS      */
	volatile object V7;                       /*  FONT-INFO       */
	(*LK21)(1,(V1))                           /*  FONT-CHAR-INFOS */;
	V6= VALUES(0);
	(*LK22)(1,(V1))                           /*  FONT-FONT-INFO  */;
	V7= VALUES(0);
	if(!((((V6))->v.v_fillp)==0)){
	goto L403;}
	{int V8;                                  /*  FONT-WIDTH      */
	object V9;                                /*  FONT-ASCENT     */
	object V10;                               /*  FONT-DESCENT    */
	object V11;                               /*  WIDTH           */
	(*LK23)(1,(V1))                           /*  MAX-CHAR-WIDTH  */;
	V8= fix(VALUES(0));
	(*LK24)(1,(V1))                           /*  MAX-CHAR-ASCENT */;
	V9= VALUES(0);
	(*LK25)(1,(V1))                           /*  MAX-CHAR-DESCENT*/;
	V10= VALUES(0);
	V11= fixnum_times((fix((V4)))-(fix((V3))),V8);
	if(((V5))==Cnil){
	goto L410;}
	VALUES(0) = (V11);
	RETURN(1);
L410:
	(*LK26)(1,(V1))                           /*  MAX-CHAR-LEFT-BEARING*/;
	T0= VALUES(0);
	{object V12= number_negate(MAKE_FIXNUM(V8));
	(*LK27)(1,(V1))                           /*  MAX-CHAR-RIGHT-BEARING*/;
	Lplus(3,(V11),(V12),VALUES(0))            /*  +               */;
	VALUES(4) = VALUES(0);
	VALUES(3) = T0;
	VALUES(2) = (V10);
	VALUES(1) = (V9);
	VALUES(0) = (V11);
	RETURN(5);}
	}
L403:
	{volatile int V13;                        /*  FIRST-COL       */
	volatile int V14;                         /*  NUM-COLS        */
	volatile int V15;                         /*  FIRST-ROW       */
	volatile int V16;                         /*  LAST-ROW        */
	volatile int V17;                         /*  NUM-ROWS        */
	V13= fix(((V7))->in.in_slots[5]);
	V14= fix(one_plus(number_minus(((V7))->in.in_slots[6],MAKE_FIXNUM(V13))));
	V15= fix(((V7))->in.in_slots[3]);
	V16= fix(((V7))->in.in_slots[4]);
	V17= fix(one_plus(number_minus(MAKE_FIXNUM(V16),MAKE_FIXNUM(V15))));
	if((V15)>0){
	goto L420;}
	if(!((V16)>0)){
	goto L421;}
L420:
	if(((V5))==Cnil){
	goto L426;}
	{volatile int V18;                        /*  I               */
	volatile object V19;                      /*  WIDTH           */
	V18= fix((V3));
	V19= MAKE_FIXNUM(0);
L430:
	if(!((V18)>=(fix((V4))))){
	goto L431;}
	VALUES(0) = (V19);
	RETURN(1);
L431:
	{int V21;                                 /*  N               */
	{int V22;                                 /*  CHAR            */
	int V23;                                  /*  ROW             */
	int V24;                                  /*  COL             */
	V22= fix(elt((V2),V18));
	Lash(2,MAKE_FIXNUM(V22),MAKE_FIXNUM(-8))  /*  SHIFT>>         */;
	V23= fix(number_minus(VALUES(0),MAKE_FIXNUM(V15)));
	Llogand(2,MAKE_FIXNUM(V22),MAKE_FIXNUM(255))/*  LOGAND        */;
	V24= fix(number_minus(VALUES(0),MAKE_FIXNUM(V13)));
	Lmonotonically_increasing(3,MAKE_FIXNUM(-1),MAKE_FIXNUM(V23),MAKE_FIXNUM(V17))/*  <*/;
	if(VALUES(0)==Cnil){
	goto L442;}
	Lmonotonically_increasing(3,MAKE_FIXNUM(-1),MAKE_FIXNUM(V24),MAKE_FIXNUM(V14))/*  <*/;
	if(VALUES(0)==Cnil){
	goto L442;}
	V21= (6)*(((V23)*(V14))+(V24));
	goto L435;
L442:
	V21= -1;
	}
L435:
	if((V21)<0){
	goto L434;}
	V19= number_plus((V19),MAKE_FIXNUM(((V6))->fixa.fixa_self[(2)+(V21)]));
	}
L434:
	V18= (V18)+1;
	goto L430;
	}
L426:
	{volatile int V22;                        /*  I               */
	volatile object V23;                      /*  WIDTH           */
	volatile int V24;                         /*  ASCENT          */
	volatile int V25;                         /*  DESCENT         */
	volatile object V26;                      /*  LEFT            */
	volatile object V27;                      /*  RIGHT           */
	V22= fix((V3));
	V24= -32767;
	V25= -32767;
	V23= MAKE_FIXNUM(0);
	V26= MAKE_FIXNUM(32767);
	V27= MAKE_FIXNUM(-32767);
L456:
	if(!((V22)>=(fix((V4))))){
	goto L457;}
	VALUES(4) = (V27);
	VALUES(3) = (V26);
	VALUES(2) = MAKE_FIXNUM(V25);
	VALUES(1) = MAKE_FIXNUM(V24);
	VALUES(0) = (V23);
	RETURN(5);
L457:
	{register int V29;                        /*  N               */
	{int V30;                                 /*  CHAR            */
	int V31;                                  /*  ROW             */
	int V32;                                  /*  COL             */
	V30= fix(elt((V2),V22));
	Lash(2,MAKE_FIXNUM(V30),MAKE_FIXNUM(-8))  /*  SHIFT>>         */;
	V31= fix(number_minus(VALUES(0),MAKE_FIXNUM(V15)));
	Llogand(2,MAKE_FIXNUM(V30),MAKE_FIXNUM(255))/*  LOGAND        */;
	V32= fix(number_minus(VALUES(0),MAKE_FIXNUM(V13)));
	Lmonotonically_increasing(3,MAKE_FIXNUM(-1),MAKE_FIXNUM(V31),MAKE_FIXNUM(V17))/*  <*/;
	if(VALUES(0)==Cnil){
	goto L468;}
	Lmonotonically_increasing(3,MAKE_FIXNUM(-1),MAKE_FIXNUM(V32),MAKE_FIXNUM(V14))/*  <*/;
	if(VALUES(0)==Cnil){
	goto L468;}
	V29= (6)*(((V31)*(V14))+(V32));
	goto L461;
L468:
	V29= -1;
	}
L461:
	if((V29)<0){
	goto L460;}
	{object V30= number_plus((V23),((V6))->v.v_self[V29]);
	V26= (number_compare((V26),V30)<=0?(V26):V30);}
	{object V30= number_plus((V23),((V6))->v.v_self[(V29)+1]);
	V27= (number_compare((V27),V30)>=0?(V27):V30);}
	V23= number_plus((V23),((V6))->v.v_self[(2)+(V29)]);
	{object V30= ((V6))->v.v_self[(3)+(V29)];
	V24= fix((number_compare(MAKE_FIXNUM(V24),V30)>=0?MAKE_FIXNUM(V24):V30));}
	{object V30= ((V6))->v.v_self[(4)+(V29)];
	V25= fix((number_compare(MAKE_FIXNUM(V25),V30)>=0?MAKE_FIXNUM(V25):V30));}
	}
L460:
	V22= (V22)+1;
	goto L456;
	}
L421:
	if(((V5))==Cnil){
	goto L487;}
	{volatile int V30;                        /*  I               */
	volatile object V31;                      /*  WIDTH           */
	V30= fix((V3));
	V31= MAKE_FIXNUM(0);
L491:
	if(!((V30)>=(fix((V4))))){
	goto L492;}
	VALUES(0) = (V31);
	RETURN(1);
L492:
	{int V33;                                 /*  N               */
	{int V34;                                 /*  COL             */
	V34= (fix(elt((V2),V30)))-(V13);
	Lmonotonically_increasing(3,MAKE_FIXNUM(-1),MAKE_FIXNUM(V34),MAKE_FIXNUM(V14))/*  <*/;
	if(VALUES(0)==Cnil){
	goto L499;}
	V33= (6)*(V34);
	goto L496;
L499:
	V33= -1;
	}
L496:
	if((V33)<0){
	goto L495;}
	V31= number_plus((V31),MAKE_FIXNUM(((V6))->fixa.fixa_self[(2)+(V33)]));
	}
L495:
	V30= (V30)+1;
	goto L491;
	}
L487:
	{volatile int V34;                        /*  I               */
	volatile object V35;                      /*  WIDTH           */
	volatile int V36;                         /*  ASCENT          */
	volatile int V37;                         /*  DESCENT         */
	volatile object V38;                      /*  LEFT            */
	volatile object V39;                      /*  RIGHT           */
	V34= fix((V3));
	V36= -32767;
	V37= -32767;
	V35= MAKE_FIXNUM(0);
	V38= MAKE_FIXNUM(32767);
	V39= MAKE_FIXNUM(-32767);
L511:
	if(!((V34)>=(fix((V4))))){
	goto L512;}
	VALUES(4) = (V39);
	VALUES(3) = (V38);
	VALUES(2) = MAKE_FIXNUM(V37);
	VALUES(1) = MAKE_FIXNUM(V36);
	VALUES(0) = (V35);
	RETURN(5);
L512:
	{register int V41;                        /*  N               */
	{int V42;                                 /*  COL             */
	V42= (fix(elt((V2),V34)))-(V13);
	Lmonotonically_increasing(3,MAKE_FIXNUM(-1),MAKE_FIXNUM(V42),MAKE_FIXNUM(V14))/*  <*/;
	if(VALUES(0)==Cnil){
	goto L519;}
	V41= (6)*(V42);
	goto L516;
L519:
	V41= -1;
	}
L516:
	if((V41)<0){
	goto L515;}
	{object V42= number_plus((V35),((V6))->v.v_self[V41]);
	V38= (number_compare((V38),V42)<=0?(V38):V42);}
	{object V42= number_plus((V35),((V6))->v.v_self[(V41)+1]);
	V39= (number_compare((V39),V42)>=0?(V39):V42);}
	V35= number_plus((V35),((V6))->v.v_self[(2)+(V41)]);
	{object V42= ((V6))->v.v_self[(3)+(V41)];
	V36= fix((number_compare(MAKE_FIXNUM(V36),V42)>=0?MAKE_FIXNUM(V36):V42));}
	{object V42= ((V6))->v.v_self[(4)+(V41)];
	V37= fix((number_compare(MAKE_FIXNUM(V37),V42)>=0?MAKE_FIXNUM(V37):V42));}
	}
L515:
	V34= (V34)+1;
	goto L511;
	}
	}
	}
}
/*	function definition for DRAW-GLYPH                            */
static L9(int narg, object V1, object V2, object V3, object V4, object V5, ...)
{ VT11 VLEX11 CLSR11
	{int V6;
	int V7;
	object V8;
	object V9;
	object V10;
	va_list args; va_start(args, V5);
	V6= fix(V3);
	V7= fix(V4);
	narg -=5;
	{ object keyvars[6];
	parse_key(narg,args,3,L9keys,keyvars,OBJNULL,FALSE);
	V8= keyvars[0];
	V9= keyvars[1];
	if(keyvars[5]==Cnil){
	V10= VV[36];
	}else{
	V10= keyvars[2];}
	}
	{object V11;                              /*  DISPLAY         */
	object V12;                               /*  RESULT          */
	object V13;                               /*  OPCODE          */
	V11= ((V2))->in.in_slots[1];
	V12= Ct;
	V13= MAKE_FIXNUM(74);
	{register object V14;                     /*  VECTOR          */
	(*LK28)(0)                                /*  ALLOCATE-GCONTEXT-STATE*/;
	V14= VALUES(0);
	((V14))->v.v_self[0]= (V5);
	{ int V15;
	object V16;                               /*  NEW-START       */
	object V17;                               /*  NEW-FONT        */
	object V18;                               /*  TRANSLATE-WIDTH */
	{object V19;
	if(((V8))==Cnil){
	goto L545;}
	T0= (V8);
	goto L543;
L545:
	T0= (VV[51]->s.s_gfdef);
	}
L543:
	(*LK3)(2,(V2),Ct)                         /*  GCONTEXT-FONT   */;
	V15=funcall(7,T0,(V14),MAKE_FIXNUM(0),MAKE_FIXNUM(1),VALUES(0),(V14),MAKE_FIXNUM(1));
	if (V15--==0) goto L548;
	V16= VALUES(0);
	if (V15--==0) goto L549;
	V17= VALUES(1);
	if (V15--==0) goto L550;
	V18= VALUES(2);
	goto L551;
L548:
	V16= Cnil;
L549:
	V17= Cnil;
L550:
	V18= Cnil;
L551:
	(*LK9)(1,(V17))                           /*  FONT-P          */;
	if(VALUES(0)==Cnil){
	goto L552;}
	(*LK29)(2,(V2),(V17))                     /*  SET-GCONTEXT-FONT*/;
	{ int V19;
	V19=funcall(7,(V8),(V14),MAKE_FIXNUM(0),MAKE_FIXNUM(1),(V17),(V14),MAKE_FIXNUM(1));
	if (V19>0) {
	V16= VALUES(0);
	V19--;
	} else {
	V16= Cnil;}
	if (V19>0) {
	V17= VALUES(1);
	V19--;
	} else {
	V17= Cnil;}
	if (V19>0) {
	V18= VALUES(2);
	} else {
	V18= Cnil;}
	
	}
L552:
	V12= ((fix((V16)))>0?Ct:Cnil);
	V5= ((V14))->v.v_self[1];
	(*LK30)(1,(V14))                          /*  DEALLOCATE-GCONTEXT-STATE*/;
	if(((V18))==Cnil){
	goto L539;}
	V9= (V18);}
	}
L539:
	if(((V12))==Cnil){
	goto L566;}
	if(!(eql((V10),MAKE_FIXNUM(16)))){
	goto L568;}
	V13= MAKE_FIXNUM(75);
	(*LK31)(2,MAKE_FIXNUM(8),MAKE_FIXNUM(8))  /*  BYTE            */;
	T0= VALUES(0);
	(*LK31)(2,MAKE_FIXNUM(8),MAKE_FIXNUM(8))  /*  BYTE            */;
	(*LK32)(2,VALUES(0),(V5))                 /*  LDB             */;
	(*LK33)(3,(V5),T0,VALUES(0))              /*  DPB             */;
	V5= VALUES(0);
L568:
	{register object V14;                     /*  .DISPLAY.       */
	V14= (V11);
	if((((V14))->in.in_slots[10])==Cnil){
	goto L578;}
	(*LK8)(3,VV[17],VV[18],(V14))             /*  X-ERROR         */;
L578:
	(*LK34)(1,(V2))                           /*  FORCE-GCONTEXT-CHANGES-INTERNAL*/;
	{object V15;                              /*  %BUFFER         */
	V15= (V14);
	if(!(((fix(((V15))->in.in_slots[6]))+(160))>=(fix(((V15))->in.in_slots[2])))){
	goto L583;}
	(*LK12)(1,(V15))                          /*  BUFFER-FLUSH    */;
L583:
	{register int V16;                        /*  BUFFER-BOFFSET  */
	register object V17;                      /*  BUFFER-BBUF     */
	V16= fix(((V15))->in.in_slots[6]);
	V17= ((V15))->in.in_slots[7];
	((V14))->in.in_slots[4]= MAKE_FIXNUM(V16);
	(((V17))->ust.ust_self[(V16)+(0)]=(fix((V13))));
	(*LK35)(1,(V1))                           /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L594;}
	((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L592;
L594:
	(*LK13)(2,(V1),VV[38])                    /*  X-TYPE-ERROR    */;
L592:
	(*LK1)(1,(V2))                            /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L598;}
	((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(8))))=fix(((V2))->in.in_slots[0]));
	goto L596;
L598:
	(*LK13)(2,(V2),VV[37])                    /*  X-TYPE-ERROR    */;
L596:
	(*LK4)(2,MAKE_FIXNUM(V6),VV[39])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L602;}
	((*(short *)(((V17))->st.st_self+((V16)+(12))))=V6);
	goto L600;
L602:
	(*LK13)(2,MAKE_FIXNUM(V6),VV[39])         /*  X-TYPE-ERROR    */;
L600:
	(*LK4)(2,MAKE_FIXNUM(V7),VV[39])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L606;}
	((*(short *)(((V17))->st.st_self+((V16)+(14))))=V7);
	goto L604;
L606:
	(*LK13)(2,MAKE_FIXNUM(V7),VV[39])         /*  X-TYPE-ERROR    */;
L604:
	(((V17))->ust.ust_self[(V16)+(16)]=(1));
	(((V17))->ust.ust_self[(V16)+(17)]=(0));
	{object V18;                              /*  .VALUE.         */
	(*LK31)(2,MAKE_FIXNUM(8),MAKE_FIXNUM(0))  /*  BYTE            */;
	(*LK32)(2,VALUES(0),(V5))                 /*  LDB             */;
	V18= VALUES(0);
	(*LK4)(2,(V18),VV[40])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L614;}
	(((V17))->ust.ust_self[(V16)+(18)]=(fix((V18))));
	goto L610;
L614:
	(*LK13)(2,(V18),VV[40])                   /*  X-TYPE-ERROR    */;
	}
L610:
	{object V18;                              /*  .VALUE.         */
	(*LK31)(2,MAKE_FIXNUM(8),MAKE_FIXNUM(8))  /*  BYTE            */;
	(*LK32)(2,VALUES(0),(V5))                 /*  LDB             */;
	V18= VALUES(0);
	(*LK4)(2,(V18),VV[40])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L620;}
	(((V17))->ust.ust_self[(V16)+(19)]=(fix((V18))));
	goto L616;
L620:
	(*LK13)(2,(V18),VV[40])                   /*  X-TYPE-ERROR    */;
	}
L616:
	((*(unsigned short *)(((V17))->ust.ust_self+((V16)+(2))))=5);
	((V14))->in.in_slots[6]= MAKE_FIXNUM((V16)+(20));
	(*LK15)(1,(V14))                          /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK17)(1,(V14))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	VALUES(1) = (V9);
	VALUES(0) = Ct;
	RETURN(2);
L566:
	VALUES(0) = Cnil;
	RETURN(1);
	}
	}
}
/*	function definition for DRAW-GLYPHS                           */
static L10(int narg, object V1, object V2, object V3, object V4, object V5, ...)
{ VT12 VLEX12 CLSR12
	{int V6;
	int V7;
	int V8;
	register object V9;
	object V10;
	object V11;
	object V12;
	va_list args; va_start(args, V5);
	V6= fix(V3);
	V7= fix(V4);
	narg -=5;
	{ object keyvars[10];
	parse_key(narg,args,5,L10keys,keyvars,OBJNULL,FALSE);
	if(keyvars[5]==Cnil){
	V8= 0;
	}else{
	V8= fix(keyvars[0]);}
	V9= keyvars[1];
	V10= keyvars[2];
	V11= keyvars[3];
	if(keyvars[9]==Cnil){
	V12= VV[36];
	}else{
	V12= keyvars[4];}
	}
	if(((V9))!=Cnil){
	goto L626;}
	V9= MAKE_FIXNUM(length((V5)));
L626:
	if(((V12)!= VV[36])
	&& !eql((V12),VV[41]))goto L630;
	if((V10)!=Cnil){
	VALUES(0) = (V10);
	goto L631;}
	VALUES(0) = (VV[51]->s.s_gfdef);
L631:
	RETURN(L11(9,(V1),(V2),MAKE_FIXNUM(V6),MAKE_FIXNUM(V7),(V5),MAKE_FIXNUM(V8),(V9),VALUES(0),(V11))/*  DRAW-GLYPHS8*/);
L630:
	if(!eql((V12),VV[42]))goto L632;
	if((V10)!=Cnil){
	VALUES(0) = (V10);
	goto L633;}
	VALUES(0) = (VV[51]->s.s_gfdef);
L633:
	RETURN(L12(9,(V1),(V2),MAKE_FIXNUM(V6),MAKE_FIXNUM(V7),(V5),MAKE_FIXNUM(V8),(V9),VALUES(0),(V11))/*  DRAW-GLYPHS16*/);
L632:
	FEerror("The ECASE key value ~s is illegal.",1,(V12));
	}
}
/*	function definition for DRAW-GLYPHS8                          */
static L11(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT13 VLEX13 CLSR13
	{volatile int V10;
	volatile int V11;
	V10= fix(V3);
	V11= fix(V4);
TTL:
	{volatile int V12;                        /*  SRC-START       */
	volatile object V13;                      /*  SRC-END         */
	volatile object V14;                      /*  NEXT-START      */
	volatile int V15;                         /*  LENGTH          */
	volatile object V16;                      /*  REQUEST-LENGTH  */
	volatile object V17;                      /*  DISPLAY         */
	volatile object V18;                      /*  FONT            */
	V12= fix((V6));
	if((V7)!=Cnil){
	V13= (V7);
	goto L635;}
	V13= MAKE_FIXNUM(length((V5)));
L635:
	V14= Cnil;
	V15= (fix((V13)))-(V12);
	V16= MAKE_FIXNUM((V15)*(2));
	V17= ((V2))->in.in_slots[1];
	(*LK3)(2,(V2),Ct)                         /*  GCONTEXT-FONT   */;
	V18= VALUES(0);
	{volatile object V19;                     /*  .DISPLAY.       */
	V19= (V17);
	if((((V19))->in.in_slots[10])==Cnil){
	goto L642;}
	(*LK8)(3,VV[17],VV[18],(V19))             /*  X-ERROR         */;
L642:
	(*LK34)(1,(V2))                           /*  FORCE-GCONTEXT-CHANGES-INTERNAL*/;
	{volatile object V20;                     /*  %BUFFER         */
	V20= (V19);
	if(!(((fix(((V20))->in.in_slots[6]))+((fix((V16)))+(160)))>=(fix(((V20))->in.in_slots[2])))){
	goto L647;}
	(*LK12)(1,(V20))                          /*  BUFFER-FLUSH    */;
L647:
	{volatile int V21;                        /*  BUFFER-BOFFSET  */
	volatile object V22;                      /*  BUFFER-BBUF     */
	V21= fix(((V20))->in.in_slots[6]);
	V22= ((V20))->in.in_slots[7];
	((V19))->in.in_slots[4]= MAKE_FIXNUM(V21);
	(((V22))->ust.ust_self[(V21)+(0)]=(74));
	(*LK35)(1,(V1))                           /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L658;}
	((*(unsigned long *)(((V22))->ust.ust_self+((V21)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L656;
L658:
	(*LK13)(2,(V1),VV[38])                    /*  X-TYPE-ERROR    */;
L656:
	(*LK1)(1,(V2))                            /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L662;}
	((*(unsigned long *)(((V22))->ust.ust_self+((V21)+(8))))=fix(((V2))->in.in_slots[0]));
	goto L660;
L662:
	(*LK13)(2,(V2),VV[37])                    /*  X-TYPE-ERROR    */;
L660:
	(*LK4)(2,MAKE_FIXNUM(V10),VV[39])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L666;}
	((*(short *)(((V22))->st.st_self+((V21)+(12))))=V10);
	goto L664;
L666:
	(*LK13)(2,MAKE_FIXNUM(V10),VV[39])        /*  X-TYPE-ERROR    */;
L664:
	(*LK4)(2,MAKE_FIXNUM(V11),VV[39])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L670;}
	((*(short *)(((V22))->st.st_self+((V21)+(14))))=V11);
	goto L668;
L670:
	(*LK13)(2,MAKE_FIXNUM(V11),VV[39])        /*  X-TYPE-ERROR    */;
L668:
	{volatile object V23;                     /*  .VALUE.         */
	{volatile object V24;                     /*  .SAVED-BUFFER-FLUSH-INHIBIT.*/
	V24= ((V17))->in.in_slots[11];
	{ int V25; volatile bool unwinding = FALSE;
	if ((V25=frs_push(FRS_PROTECT,Cnil))) {
	V25--; unwinding = TRUE;} else {
	((V17))->in.in_slots[11]= Ct;
	{volatile int V26;                        /*  BOFFSET         */
	volatile int V27;                         /*  SRC-CHUNK       */
	volatile int V28;                         /*  DST-CHUNK       */
	volatile int V29;                         /*  OFFSET          */
	volatile object V30;                      /*  OVERALL-WIDTH   */
	volatile object V31;                      /*  STOP-P          */
	V26= (V21)+(16);
	V27= 0;
	V28= 0;
	V29= 0;
	V30= MAKE_FIXNUM(0);
	V31= Cnil;
L684:
	if(((V31))!=Cnil){
	goto L686;}
	if(!((V15)==0)){
	goto L685;}
L686:
	{volatile int V33;                        /*  END             */
	V33= (((V26)+(3)) & (-4));
L693:
	if(!((V26)>=(V33))){
	goto L694;}
	goto L690;
L694:
	(((V22))->ust.ust_self[V26]=(0));
	V26= (V26)+(1);
	goto L693;
	}
L690:
	((*(unsigned short *)(((V22))->ust.ust_self+((V21)+(2))))=(((V26)-(V21)) >> (- (-2))));
	((V17))->in.in_slots[6]= MAKE_FIXNUM(V26);
	if((V15)==0){
	goto L704;}
	V14= MAKE_FIXNUM(V12);
L704:
	if(((V30))==Cnil){
	goto L709;}
	V9= (V30);
	VALUES(0)=(V9);
	V25=1;
	goto L675;
L709:
	VALUES(0)=Cnil;
	V25=1;
	goto L675;
L685:
	V27= (V15)<=(fix((VV[0]->s.s_dbind)))?V15:fix((VV[0]->s.s_dbind));
	{ int V33;
	volatile object V34;                      /*  NEW-START       */
	volatile object V35;                      /*  NEW-FONT        */
	volatile object V36;                      /*  TRANSLATED-WIDTH*/
	V33=funcall(7,(V8),(V5),MAKE_FIXNUM(V12),MAKE_FIXNUM((V12)+(V27)),(V18),(V22),MAKE_FIXNUM((V26)+(2)));
	if (V33--==0) goto L716;
	V34= VALUES(0);
	if (V33--==0) goto L717;
	V35= VALUES(1);
	if (V33--==0) goto L718;
	V36= VALUES(2);
	goto L719;
L716:
	V34= Cnil;
L717:
	V35= Cnil;
L718:
	V36= Cnil;
L719:
	V28= (fix((V34)))-(V12);
	V15= (V15)-(V28);
	V12= fix((V34));
	if(((V36))==Cnil){
	goto L728;}
	if(((V30))==Cnil){
	goto L726;}
	V30= number_plus((V30),(V36));
	goto L726;
L728:
	V30= Cnil;
L726:
	if(!((V28)>0)){
	goto L734;}
	(((V22))->ust.ust_self[V26]=(V28));
	(((V22))->ust.ust_self[(V26)+(1)]=(V29));
	V26= (V26)+((V28)+(2));
L734:
	V29= 0;
	if(((V35))!=Cnil){
	goto L743;}
	if((V27)==(V28)){
	goto L714;}
	V31= Ct;
	goto L714;
L743:
	if(!(type_of((V35))==t_fixnum||type_of((V35))==t_bignum)){
	goto L749;}
	V29= fix((V35));
	goto L714;
L749:
	(*LK9)(1,(V35))                           /*  FONT-P          */;
	if(VALUES(0)==Cnil){
	goto L714;}
	V18= (V35);
	{register int V37;                        /*  FONT-ID         */
	register int V38;                         /*  BUFFER-BOFFSET  */
	(*LK10)(1,(V18))                          /*  FONT-ID         */;
	V37= fix(VALUES(0));
	V38= V26;
	{register object V39;                     /*  LOCAL-STATE     */
	register object V40;                      /*  SERVER-STATE    */
	V39= ((V2))->in.in_slots[5];
	V40= ((V2))->in.in_slots[4];
	((V40))->v.v_self[25]= (V18);
	((V40))->v.v_self[14]= MAKE_FIXNUM(V37);
	((V39))->v.v_self[25]= (V18);
	((V39))->v.v_self[14]= MAKE_FIXNUM(V37);
	}
	(((V22))->ust.ust_self[(V38)+(0)]=(255));
	(*LK31)(2,MAKE_FIXNUM(8),MAKE_FIXNUM(24)) /*  BYTE            */;
	(*LK32)(2,VALUES(0),MAKE_FIXNUM(V37))     /*  LDB             */;
	T0= VALUES(0);
	(((V22))->ust.ust_self[(V38)+(1)]=(fix(T0)));
	(((V22))->ust.ust_self[(V38)+(2)]=(((((~(-1 << (8))) << (16)) & (V37)) >> (16))));
	(((V22))->ust.ust_self[(V38)+(3)]=(((((~(-1 << (8))) << (8)) & (V37)) >> (8))));
	(((V22))->ust.ust_self[(V38)+(4)]=(((((~(-1 << (8))) << (0)) & (V37)) >> (0))));
	}
	V26= (V26)+(5);}
L714:
	goto L684;
	}
L675:
	}
	frs_pop();
	MV_SAVE(V25);
	((V17))->in.in_slots[11]= (V24);
	MV_RESTORE(V25);
	if (unwinding) unwind(nlj_fr,nlj_tag,V25+1);
	else {
	V23= VALUES(0);}}
	}
	}
	(*LK15)(1,(V19))                          /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK17)(1,(V19))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	VALUES(1) = (V9);
	VALUES(0) = (V14);
	RETURN(2);
	}
	}
}
/*	function definition for DRAW-GLYPHS16                         */
static L12(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT14 VLEX14 CLSR14
	{volatile int V10;
	volatile int V11;
	V10= fix(V3);
	V11= fix(V4);
TTL:
	{volatile int V12;                        /*  SRC-START       */
	volatile object V13;                      /*  SRC-END         */
	volatile object V14;                      /*  NEXT-START      */
	volatile int V15;                         /*  LENGTH          */
	volatile object V16;                      /*  REQUEST-LENGTH  */
	volatile object V17;                      /*  DISPLAY         */
	volatile object V18;                      /*  FONT            */
	volatile object V19;                      /*  BUFFER          */
	V12= fix((V6));
	if((V7)!=Cnil){
	V13= (V7);
	goto L776;}
	V13= MAKE_FIXNUM(length((V5)));
L776:
	V14= Cnil;
	V15= (fix((V13)))-(V12);
	V16= fixnum_times(V15,3);
	V17= ((V2))->in.in_slots[1];
	(*LK3)(2,(V2),Ct)                         /*  GCONTEXT-FONT   */;
	V18= VALUES(0);
	V19= ((V17))->in.in_slots[8];
	{volatile object V20;                     /*  .DISPLAY.       */
	V20= (V17);
	if((((V20))->in.in_slots[10])==Cnil){
	goto L784;}
	(*LK8)(3,VV[17],VV[18],(V20))             /*  X-ERROR         */;
L784:
	(*LK34)(1,(V2))                           /*  FORCE-GCONTEXT-CHANGES-INTERNAL*/;
	{volatile object V21;                     /*  %BUFFER         */
	V21= (V20);
	if(!(((fix(((V21))->in.in_slots[6]))+((fix((V16)))+(160)))>=(fix(((V21))->in.in_slots[2])))){
	goto L789;}
	(*LK12)(1,(V21))                          /*  BUFFER-FLUSH    */;
L789:
	{volatile int V22;                        /*  BUFFER-BOFFSET  */
	volatile object V23;                      /*  BUFFER-BBUF     */
	V22= fix(((V21))->in.in_slots[6]);
	V23= ((V21))->in.in_slots[7];
	((V20))->in.in_slots[4]= MAKE_FIXNUM(V22);
	(((V23))->ust.ust_self[(V22)+(0)]=(75));
	(*LK35)(1,(V1))                           /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L800;}
	((*(unsigned long *)(((V23))->ust.ust_self+((V22)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L798;
L800:
	(*LK13)(2,(V1),VV[38])                    /*  X-TYPE-ERROR    */;
L798:
	(*LK1)(1,(V2))                            /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L804;}
	((*(unsigned long *)(((V23))->ust.ust_self+((V22)+(8))))=fix(((V2))->in.in_slots[0]));
	goto L802;
L804:
	(*LK13)(2,(V2),VV[37])                    /*  X-TYPE-ERROR    */;
L802:
	(*LK4)(2,MAKE_FIXNUM(V10),VV[39])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L808;}
	((*(short *)(((V23))->st.st_self+((V22)+(12))))=V10);
	goto L806;
L808:
	(*LK13)(2,MAKE_FIXNUM(V10),VV[39])        /*  X-TYPE-ERROR    */;
L806:
	(*LK4)(2,MAKE_FIXNUM(V11),VV[39])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L812;}
	((*(short *)(((V23))->st.st_self+((V22)+(14))))=V11);
	goto L810;
L812:
	(*LK13)(2,MAKE_FIXNUM(V11),VV[39])        /*  X-TYPE-ERROR    */;
L810:
	{volatile object V24;                     /*  .VALUE.         */
	{volatile object V25;                     /*  .SAVED-BUFFER-FLUSH-INHIBIT.*/
	V25= ((V17))->in.in_slots[11];
	{ int V26; volatile bool unwinding = FALSE;
	if ((V26=frs_push(FRS_PROTECT,Cnil))) {
	V26--; unwinding = TRUE;} else {
	((V17))->in.in_slots[11]= Ct;
	{volatile int V27;                        /*  BOFFSET         */
	volatile int V28;                         /*  SRC-CHUNK       */
	volatile int V29;                         /*  DST-CHUNK       */
	volatile int V30;                         /*  OFFSET          */
	volatile object V31;                      /*  OVERALL-WIDTH   */
	volatile object V32;                      /*  STOP-P          */
	V27= (V22)+(16);
	V28= 0;
	V29= 0;
	V30= 0;
	V31= MAKE_FIXNUM(0);
	V32= Cnil;
L826:
	if(((V32))!=Cnil){
	goto L828;}
	if(!((V15)==0)){
	goto L827;}
L828:
	{volatile int V34;                        /*  END             */
	V34= (((V27)+(3)) & (-4));
L835:
	if(!((V27)>=(V34))){
	goto L836;}
	goto L832;
L836:
	(((V23))->ust.ust_self[V27]=(0));
	V27= (V27)+(1);
	goto L835;
	}
L832:
	((*(unsigned short *)(((V23))->ust.ust_self+((V22)+(2))))=(((V27)-(V22)) >> (- (-2))));
	((V17))->in.in_slots[6]= MAKE_FIXNUM(V27);
	if((V15)==0){
	goto L846;}
	V14= MAKE_FIXNUM(V12);
L846:
	if(((V31))==Cnil){
	goto L851;}
	V9= (V31);
	VALUES(0)=(V9);
	V26=1;
	goto L817;
L851:
	VALUES(0)=Cnil;
	V26=1;
	goto L817;
L827:
	V28= (V15)<=(fix((VV[0]->s.s_dbind)))?V15:fix((VV[0]->s.s_dbind));
	{ int V34;
	volatile object V35;                      /*  NEW-START       */
	volatile object V36;                      /*  NEW-FONT        */
	volatile object V37;                      /*  TRANSLATED-WIDTH*/
	V34=funcall(7,(V8),(V5),MAKE_FIXNUM(V12),MAKE_FIXNUM((V12)+(V28)),(V18),(V19),MAKE_FIXNUM(0));
	if (V34--==0) goto L858;
	V35= VALUES(0);
	if (V34--==0) goto L859;
	V36= VALUES(1);
	if (V34--==0) goto L860;
	V37= VALUES(2);
	goto L861;
L858:
	V35= Cnil;
L859:
	V36= Cnil;
L860:
	V37= Cnil;
L861:
	V29= (fix((V35)))-(V12);
	V15= (V15)-(V29);
	V12= fix((V35));
	(*LK14)(5,(V17),MAKE_FIXNUM((V27)+(2)),(V19),MAKE_FIXNUM(0),MAKE_FIXNUM(V29))/*  WRITE-SEQUENCE-CHAR2B*/;
	if(((V37))==Cnil){
	goto L871;}
	if(((V31))==Cnil){
	goto L869;}
	V31= number_plus((V31),(V37));
	goto L869;
L871:
	V31= Cnil;
L869:
	if(!((V29)>0)){
	goto L877;}
	(((V23))->ust.ust_self[V27]=(V29));
	(((V23))->ust.ust_self[(V27)+(1)]=(V30));
	V27= (V27)+(((V29)+(V29))+(2));
L877:
	V30= 0;
	if(((V36))!=Cnil){
	goto L886;}
	if((V28)==(V29)){
	goto L856;}
	V32= Ct;
	goto L856;
L886:
	if(!(type_of((V36))==t_fixnum||type_of((V36))==t_bignum)){
	goto L892;}
	V30= fix((V36));
	goto L856;
L892:
	(*LK9)(1,(V36))                           /*  FONT-P          */;
	if(VALUES(0)==Cnil){
	goto L856;}
	V18= (V36);
	{register int V38;                        /*  FONT-ID         */
	register int V39;                         /*  BUFFER-BOFFSET  */
	(*LK10)(1,(V18))                          /*  FONT-ID         */;
	V38= fix(VALUES(0));
	V39= V27;
	{register object V40;                     /*  LOCAL-STATE     */
	register object V41;                      /*  SERVER-STATE    */
	V40= ((V2))->in.in_slots[5];
	V41= ((V2))->in.in_slots[4];
	((V41))->v.v_self[25]= (V18);
	((V41))->v.v_self[14]= MAKE_FIXNUM(V38);
	((V40))->v.v_self[25]= (V18);
	((V40))->v.v_self[14]= MAKE_FIXNUM(V38);
	}
	(((V23))->ust.ust_self[(V39)+(0)]=(255));
	(*LK31)(2,MAKE_FIXNUM(8),MAKE_FIXNUM(24)) /*  BYTE            */;
	(*LK32)(2,VALUES(0),MAKE_FIXNUM(V38))     /*  LDB             */;
	T0= VALUES(0);
	(((V23))->ust.ust_self[(V39)+(1)]=(fix(T0)));
	(((V23))->ust.ust_self[(V39)+(2)]=(((((~(-1 << (8))) << (16)) & (V38)) >> (16))));
	(((V23))->ust.ust_self[(V39)+(3)]=(((((~(-1 << (8))) << (8)) & (V38)) >> (8))));
	(((V23))->ust.ust_self[(V39)+(4)]=(((((~(-1 << (8))) << (0)) & (V38)) >> (0))));
	}
	V27= (V27)+(5);}
L856:
	goto L826;
	}
L817:
	}
	frs_pop();
	MV_SAVE(V26);
	((V17))->in.in_slots[11]= (V25);
	MV_RESTORE(V26);
	if (unwinding) unwind(nlj_fr,nlj_tag,V26+1);
	else {
	V24= VALUES(0);}}
	}
	}
	(*LK15)(1,(V20))                          /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK17)(1,(V20))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	VALUES(1) = (V9);
	VALUES(0) = (V14);
	RETURN(2);
	}
	}
}
/*	function definition for DRAW-IMAGE-GLYPH                      */
static L13(int narg, object V1, object V2, object V3, object V4, object V5, ...)
{ VT15 VLEX15 CLSR15
	{int V6;
	int V7;
	object V8;
	object V9;
	object V10;
	va_list args; va_start(args, V5);
	V6= fix(V3);
	V7= fix(V4);
	narg -=5;
	{ object keyvars[6];
	parse_key(narg,args,3,L13keys,keyvars,OBJNULL,FALSE);
	V8= keyvars[0];
	V9= keyvars[1];
	if(keyvars[5]==Cnil){
	V10= VV[36];
	}else{
	V10= keyvars[2];}
	}
	{object V11;                              /*  DISPLAY         */
	object V12;                               /*  RESULT          */
	object V13;                               /*  OPCODE          */
	V11= ((V2))->in.in_slots[1];
	V12= Ct;
	V13= MAKE_FIXNUM(76);
	{register object V14;                     /*  VECTOR          */
	(*LK28)(0)                                /*  ALLOCATE-GCONTEXT-STATE*/;
	V14= VALUES(0);
	((V14))->v.v_self[0]= (V5);
	{ int V15;
	object V16;                               /*  NEW-START       */
	object V17;                               /*  NEW-FONT        */
	object V18;                               /*  TRANSLATE-WIDTH */
	{object V19;
	if(((V8))==Cnil){
	goto L928;}
	T0= (V8);
	goto L926;
L928:
	T0= (VV[51]->s.s_gfdef);
	}
L926:
	(*LK3)(2,(V2),Ct)                         /*  GCONTEXT-FONT   */;
	V15=funcall(7,T0,(V14),MAKE_FIXNUM(0),MAKE_FIXNUM(1),VALUES(0),(V14),MAKE_FIXNUM(1));
	if (V15--==0) goto L931;
	V16= VALUES(0);
	if (V15--==0) goto L932;
	V17= VALUES(1);
	if (V15--==0) goto L933;
	V18= VALUES(2);
	goto L934;
L931:
	V16= Cnil;
L932:
	V17= Cnil;
L933:
	V18= Cnil;
L934:
	(*LK9)(1,(V17))                           /*  FONT-P          */;
	if(VALUES(0)==Cnil){
	goto L935;}
	(*LK29)(2,(V2),(V17))                     /*  SET-GCONTEXT-FONT*/;
	{ int V19;
	V19=funcall(7,(V8),(V14),MAKE_FIXNUM(0),MAKE_FIXNUM(1),(V17),(V14),MAKE_FIXNUM(1));
	if (V19>0) {
	V16= VALUES(0);
	V19--;
	} else {
	V16= Cnil;}
	if (V19>0) {
	V17= VALUES(1);
	V19--;
	} else {
	V17= Cnil;}
	if (V19>0) {
	V18= VALUES(2);
	} else {
	V18= Cnil;}
	
	}
L935:
	V12= ((fix((V16)))>0?Ct:Cnil);
	V5= ((V14))->v.v_self[1];
	(*LK30)(1,(V14))                          /*  DEALLOCATE-GCONTEXT-STATE*/;
	if(((V18))==Cnil){
	goto L922;}
	V9= (V18);}
	}
L922:
	if(((V12))==Cnil){
	goto L949;}
	if(!(eql((V10),MAKE_FIXNUM(16)))){
	goto L951;}
	V13= MAKE_FIXNUM(77);
	(*LK31)(2,MAKE_FIXNUM(8),MAKE_FIXNUM(8))  /*  BYTE            */;
	T0= VALUES(0);
	(*LK31)(2,MAKE_FIXNUM(8),MAKE_FIXNUM(8))  /*  BYTE            */;
	(*LK32)(2,VALUES(0),(V5))                 /*  LDB             */;
	(*LK33)(3,(V5),T0,VALUES(0))              /*  DPB             */;
	V5= VALUES(0);
L951:
	{register object V14;                     /*  .DISPLAY.       */
	V14= (V11);
	if((((V14))->in.in_slots[10])==Cnil){
	goto L961;}
	(*LK8)(3,VV[17],VV[18],(V14))             /*  X-ERROR         */;
L961:
	(*LK34)(1,(V2))                           /*  FORCE-GCONTEXT-CHANGES-INTERNAL*/;
	{object V15;                              /*  %BUFFER         */
	V15= (V14);
	if(!(((fix(((V15))->in.in_slots[6]))+(160))>=(fix(((V15))->in.in_slots[2])))){
	goto L966;}
	(*LK12)(1,(V15))                          /*  BUFFER-FLUSH    */;
L966:
	{register int V16;                        /*  BUFFER-BOFFSET  */
	register object V17;                      /*  BUFFER-BBUF     */
	V16= fix(((V15))->in.in_slots[6]);
	V17= ((V15))->in.in_slots[7];
	((V14))->in.in_slots[4]= MAKE_FIXNUM(V16);
	(((V17))->ust.ust_self[(V16)+(0)]=(fix((V13))));
	(*LK35)(1,(V1))                           /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L977;}
	((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L975;
L977:
	(*LK13)(2,(V1),VV[38])                    /*  X-TYPE-ERROR    */;
L975:
	(*LK1)(1,(V2))                            /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L981;}
	((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(8))))=fix(((V2))->in.in_slots[0]));
	goto L979;
L981:
	(*LK13)(2,(V2),VV[37])                    /*  X-TYPE-ERROR    */;
L979:
	(((V17))->ust.ust_self[(V16)+(1)]=(1));
	(*LK4)(2,MAKE_FIXNUM(V6),VV[39])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L986;}
	((*(short *)(((V17))->st.st_self+((V16)+(12))))=V6);
	goto L984;
L986:
	(*LK13)(2,MAKE_FIXNUM(V6),VV[39])         /*  X-TYPE-ERROR    */;
L984:
	(*LK4)(2,MAKE_FIXNUM(V7),VV[39])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L990;}
	((*(short *)(((V17))->st.st_self+((V16)+(14))))=V7);
	goto L988;
L990:
	(*LK13)(2,MAKE_FIXNUM(V7),VV[39])         /*  X-TYPE-ERROR    */;
L988:
	{object V18;                              /*  .VALUE.         */
	(*LK31)(2,MAKE_FIXNUM(8),MAKE_FIXNUM(0))  /*  BYTE            */;
	(*LK32)(2,VALUES(0),(V5))                 /*  LDB             */;
	V18= VALUES(0);
	(*LK4)(2,(V18),VV[40])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L996;}
	(((V17))->ust.ust_self[(V16)+(16)]=(fix((V18))));
	goto L992;
L996:
	(*LK13)(2,(V18),VV[40])                   /*  X-TYPE-ERROR    */;
	}
L992:
	{object V18;                              /*  .VALUE.         */
	(*LK31)(2,MAKE_FIXNUM(8),MAKE_FIXNUM(8))  /*  BYTE            */;
	(*LK32)(2,VALUES(0),(V5))                 /*  LDB             */;
	V18= VALUES(0);
	(*LK4)(2,(V18),VV[40])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1002;}
	(((V17))->ust.ust_self[(V16)+(17)]=(fix((V18))));
	goto L998;
L1002:
	(*LK13)(2,(V18),VV[40])                   /*  X-TYPE-ERROR    */;
	}
L998:
	((*(unsigned short *)(((V17))->ust.ust_self+((V16)+(2))))=5);
	((V14))->in.in_slots[6]= MAKE_FIXNUM((V16)+(20));
	(*LK15)(1,(V14))                          /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK17)(1,(V14))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	VALUES(1) = (V9);
	VALUES(0) = Ct;
	RETURN(2);
L949:
	VALUES(0) = Cnil;
	RETURN(1);
	}
	}
}
/*	function definition for DRAW-IMAGE-GLYPHS                     */
static L14(int narg, object V1, object V2, object V3, object V4, object V5, ...)
{ VT16 VLEX16 CLSR16
	{int V6;
	int V7;
	int V8;
	register object V9;
	object V10;
	object V11;
	object V12;
	va_list args; va_start(args, V5);
	V6= fix(V3);
	V7= fix(V4);
	narg -=5;
	{ object keyvars[10];
	parse_key(narg,args,5,L14keys,keyvars,OBJNULL,FALSE);
	if(keyvars[5]==Cnil){
	V8= 0;
	}else{
	V8= fix(keyvars[0]);}
	V9= keyvars[1];
	V10= keyvars[2];
	V11= keyvars[3];
	if(keyvars[9]==Cnil){
	V12= VV[36];
	}else{
	V12= keyvars[4];}
	}
	{int V13= (V8)+(255);
	if((V9)!=Cnil){
	VALUES(0) = (V9);
	goto L1010;}
	VALUES(0) = MAKE_FIXNUM(length((V5)));
L1010:
	V9= MAKE_FIXNUM((V13)<=(fix(VALUES(0)))?V13:fix(VALUES(0)));}
	if(((V12)!= VV[36])
	&& !eql((V12),VV[41]))goto L1011;
	RETURN(L15(9,(V1),(V2),MAKE_FIXNUM(V6),MAKE_FIXNUM(V7),(V5),MAKE_FIXNUM(V8),(V9),(V10),(V11))/*  DRAW-IMAGE-GLYPHS8*/);
L1011:
	if(!eql((V12),VV[42]))goto L1012;
	RETURN(L16(9,(V1),(V2),MAKE_FIXNUM(V6),MAKE_FIXNUM(V7),(V5),MAKE_FIXNUM(V8),(V9),(V10),(V11))/*  DRAW-IMAGE-GLYPHS16*/);
L1012:
	FEerror("The ECASE key value ~s is illegal.",1,(V12));
	}
}
/*	function definition for DRAW-IMAGE-GLYPHS8                    */
static L15(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT17 VLEX17 CLSR17
	{volatile int V10;
	volatile int V11;
	volatile int V12;
	V10= fix(V3);
	V11= fix(V4);
	V12= fix(V6);
TTL:
	{ int V13; object (V14);
	V14= new_frame_id();
	if ((V13=frs_push(FRS_CATCH,(V14)))!=0) V13--;
	else {
	{volatile object V15;                     /*  DISPLAY         */
	volatile int V16;                         /*  LENGTH          */
	volatile object V17;                      /*  FONT            */
	volatile object V18;                      /*  FONT-CHANGE     */
	volatile object V19;                      /*  NEW-START       */
	volatile object V20;                      /*  TRANSLATED-WIDTH*/
	volatile object V21;                      /*  CHUNK           */
	V15= ((V2))->in.in_slots[1];
	V16= (fix((V7)))-(V12);
	(*LK3)(2,(V2),Ct)                         /*  GCONTEXT-FONT   */;
	V17= VALUES(0);
	V18= Cnil;
	V19= Cnil;
	V20= Cnil;
	V21= Cnil;
L1022:
	if(((V18))==Cnil){
	goto L1024;}
	(*LK29)(2,(V2),(V17))                     /*  SET-GCONTEXT-FONT*/;
L1024:
	{ int V22; object (V23);
	V23= new_frame_id();
	if ((V22=frs_push(FRS_CATCH,(V23)))!=0) V22--;
	else {
	{volatile object V24;                     /*  .DISPLAY.       */
	V24= (V15);
	if((((V24))->in.in_slots[10])==Cnil){
	goto L1030;}
	(*LK8)(3,VV[17],VV[18],(V24))             /*  X-ERROR         */;
L1030:
	(*LK34)(1,(V2))                           /*  FORCE-GCONTEXT-CHANGES-INTERNAL*/;
	{volatile object V25;                     /*  %BUFFER         */
	V25= (V24);
	if(!(((fix(((V25))->in.in_slots[6]))+((V16)+(160)))>=(fix(((V25))->in.in_slots[2])))){
	goto L1035;}
	(*LK12)(1,(V25))                          /*  BUFFER-FLUSH    */;
L1035:
	{volatile int V26;                        /*  BUFFER-BOFFSET  */
	volatile object V27;                      /*  BUFFER-BBUF     */
	V26= fix(((V25))->in.in_slots[6]);
	V27= ((V25))->in.in_slots[7];
	((V24))->in.in_slots[4]= MAKE_FIXNUM(V26);
	(((V27))->ust.ust_self[(V26)+(0)]=(76));
	(*LK35)(1,(V1))                           /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L1046;}
	((*(unsigned long *)(((V27))->ust.ust_self+((V26)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L1044;
L1046:
	(*LK13)(2,(V1),VV[38])                    /*  X-TYPE-ERROR    */;
L1044:
	(*LK1)(1,(V2))                            /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L1050;}
	((*(unsigned long *)(((V27))->ust.ust_self+((V26)+(8))))=fix(((V2))->in.in_slots[0]));
	goto L1048;
L1050:
	(*LK13)(2,(V2),VV[37])                    /*  X-TYPE-ERROR    */;
L1048:
	(*LK4)(2,MAKE_FIXNUM(V10),VV[39])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1054;}
	((*(short *)(((V27))->st.st_self+((V26)+(12))))=V10);
	goto L1052;
L1054:
	(*LK13)(2,MAKE_FIXNUM(V10),VV[39])        /*  X-TYPE-ERROR    */;
L1052:
	(*LK4)(2,MAKE_FIXNUM(V11),VV[39])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1058;}
	((*(short *)(((V27))->st.st_self+((V26)+(14))))=V11);
	goto L1056;
L1058:
	(*LK13)(2,MAKE_FIXNUM(V11),VV[39])        /*  X-TYPE-ERROR    */;
L1056:
	{volatile object V28;                     /*  .VALUE.         */
	{volatile object V29;                     /*  .SAVED-BUFFER-FLUSH-INHIBIT.*/
	V29= ((V15))->in.in_slots[11];
	{ int V30; volatile bool unwinding = FALSE;
	if ((V30=frs_push(FRS_PROTECT,Cnil))) {
	V30--; unwinding = TRUE;} else {
	((V15))->in.in_slots[11]= Ct;
	{ int V31;
	{object V32;
	V32= (V8);
	if(((V32))==Cnil){
	goto L1069;}
	T0= (V32);
	goto L1067;
L1069:
	T0= (VV[51]->s.s_gfdef);
	}
L1067:
	V31=funcall(7,T0,(V5),MAKE_FIXNUM(V12),(V7),(V17),(V27),MAKE_FIXNUM((V26)+(16)));
	if (V31>0) {
	V19= VALUES(0);
	V31--;
	} else {
	V19= Cnil;}
	if (V31>0) {
	V17= VALUES(1);
	V31--;
	} else {
	V17= Cnil;}
	if (V31>0) {
	V20= VALUES(2);
	} else {
	V20= Cnil;}
	
	}
	V21= MAKE_FIXNUM((fix((V19)))-(V12));
	if(!((fix((V21)))==0)){
	goto L1073;}
	(*LK9)(1,(V17))                           /*  FONT-P          */;
	if(VALUES(0)==Cnil){
	goto L1073;}
	V18= Ct;
	{ int V31;
	VALUES(0)=Cnil;
	V31=1;
	unwind(frs_sch((V23)),Cnil,V31+1);}
L1073:
	if(!((fix((V21)))==0)){
	goto L1081;}
	{ int V31;
	VALUES(0)=(V19);
	V31=1;
	unwind(frs_sch((V14)),Cnil,V31+1);}
L1081:
	(((V27))->ust.ust_self[(V26)+(1)]=(fix((V21))));
	{register int V31;                        /*  BLEN            */
	V31= ((((16)+(fix((V21))))+(3)) & (-4));
	((*(unsigned short *)(((V27))->ust.ust_self+((V26)+(2))))=((V31) >> (- (-2))));
	((V15))->in.in_slots[6]= MAKE_FIXNUM((V26)+(V31));
	VALUES(0)=MAKE_FIXNUM((V26)+(V31));
	V30=1;
	}
	}
	frs_pop();
	MV_SAVE(V30);
	((V15))->in.in_slots[11]= (V29);
	MV_RESTORE(V30);
	if (unwinding) unwind(nlj_fr,nlj_tag,V30+1);
	else {
	V28= VALUES(0);}}
	}
	}
	(*LK15)(1,(V24))                          /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK17)(1,(V24))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	if(!((fix((V21)))==(V16))){
	goto L1091;}
	T0= Cnil;
	goto L1089;
L1091:
	T0= (V19);
L1089:
	if((V20)!=Cnil){
	VALUES(0) = (V20);
	goto L1093;}
	VALUES(0) = (V9);
L1093:
	VALUES(1) = VALUES(0);
	VALUES(0) = T0;
	RETURN(2);}
	frs_pop();
	goto L1027;
	}
L1027:
	goto L1022;
	}}
	frs_pop();
	RETURN(V13);
	}
	}
}
/*	function definition for DRAW-IMAGE-GLYPHS16                   */
static L16(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, object V9)
{ VT18 VLEX18 CLSR18
	{volatile int V10;
	volatile int V11;
	volatile int V12;
	V10= fix(V3);
	V11= fix(V4);
	V12= fix(V6);
TTL:
	{ int V13; object (V14);
	V14= new_frame_id();
	if ((V13=frs_push(FRS_CATCH,(V14)))!=0) V13--;
	else {
	{volatile object V15;                     /*  DISPLAY         */
	volatile int V16;                         /*  LENGTH          */
	volatile object V17;                      /*  FONT            */
	volatile object V18;                      /*  FONT-CHANGE     */
	volatile object V19;                      /*  NEW-START       */
	volatile object V20;                      /*  TRANSLATED-WIDTH*/
	volatile object V21;                      /*  CHUNK           */
	volatile object V22;                      /*  BUFFER          */
	V15= ((V2))->in.in_slots[1];
	V16= (fix((V7)))-(V12);
	(*LK3)(2,(V2),Ct)                         /*  GCONTEXT-FONT   */;
	V17= VALUES(0);
	V18= Cnil;
	V19= Cnil;
	V20= Cnil;
	V21= Cnil;
	V22= ((V15))->in.in_slots[8];
L1106:
	if(((V18))==Cnil){
	goto L1108;}
	(*LK29)(2,(V2),(V17))                     /*  SET-GCONTEXT-FONT*/;
L1108:
	{ int V23; object (V24);
	V24= new_frame_id();
	if ((V23=frs_push(FRS_CATCH,(V24)))!=0) V23--;
	else {
	{volatile object V25;                     /*  .DISPLAY.       */
	V25= (V15);
	if((((V25))->in.in_slots[10])==Cnil){
	goto L1114;}
	(*LK8)(3,VV[17],VV[18],(V25))             /*  X-ERROR         */;
L1114:
	(*LK34)(1,(V2))                           /*  FORCE-GCONTEXT-CHANGES-INTERNAL*/;
	{volatile object V26;                     /*  %BUFFER         */
	V26= (V25);
	if(!(((fix(((V26))->in.in_slots[6]))+((V16)+(160)))>=(fix(((V26))->in.in_slots[2])))){
	goto L1119;}
	(*LK12)(1,(V26))                          /*  BUFFER-FLUSH    */;
L1119:
	{volatile int V27;                        /*  BUFFER-BOFFSET  */
	volatile object V28;                      /*  BUFFER-BBUF     */
	V27= fix(((V26))->in.in_slots[6]);
	V28= ((V26))->in.in_slots[7];
	((V25))->in.in_slots[4]= MAKE_FIXNUM(V27);
	(((V28))->ust.ust_self[(V27)+(0)]=(77));
	(*LK35)(1,(V1))                           /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L1130;}
	((*(unsigned long *)(((V28))->ust.ust_self+((V27)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L1128;
L1130:
	(*LK13)(2,(V1),VV[38])                    /*  X-TYPE-ERROR    */;
L1128:
	(*LK1)(1,(V2))                            /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L1134;}
	((*(unsigned long *)(((V28))->ust.ust_self+((V27)+(8))))=fix(((V2))->in.in_slots[0]));
	goto L1132;
L1134:
	(*LK13)(2,(V2),VV[37])                    /*  X-TYPE-ERROR    */;
L1132:
	(*LK4)(2,MAKE_FIXNUM(V10),VV[39])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1138;}
	((*(short *)(((V28))->st.st_self+((V27)+(12))))=V10);
	goto L1136;
L1138:
	(*LK13)(2,MAKE_FIXNUM(V10),VV[39])        /*  X-TYPE-ERROR    */;
L1136:
	(*LK4)(2,MAKE_FIXNUM(V11),VV[39])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1142;}
	((*(short *)(((V28))->st.st_self+((V27)+(14))))=V11);
	goto L1140;
L1142:
	(*LK13)(2,MAKE_FIXNUM(V11),VV[39])        /*  X-TYPE-ERROR    */;
L1140:
	{volatile object V29;                     /*  .VALUE.         */
	{volatile object V30;                     /*  .SAVED-BUFFER-FLUSH-INHIBIT.*/
	V30= ((V15))->in.in_slots[11];
	{ int V31; volatile bool unwinding = FALSE;
	if ((V31=frs_push(FRS_PROTECT,Cnil))) {
	V31--; unwinding = TRUE;} else {
	((V15))->in.in_slots[11]= Ct;
	{ int V32;
	{object V33;
	V33= (V8);
	if(((V33))==Cnil){
	goto L1153;}
	T0= (V33);
	goto L1151;
L1153:
	T0= (VV[51]->s.s_gfdef);
	}
L1151:
	V32=funcall(7,T0,(V5),MAKE_FIXNUM(V12),(V7),(V17),(V22),MAKE_FIXNUM(0));
	if (V32>0) {
	V19= VALUES(0);
	V32--;
	} else {
	V19= Cnil;}
	if (V32>0) {
	V17= VALUES(1);
	V32--;
	} else {
	V17= Cnil;}
	if (V32>0) {
	V20= VALUES(2);
	} else {
	V20= Cnil;}
	
	}
	V21= MAKE_FIXNUM((fix((V19)))-(V12));
	if(!((fix((V21)))==0)){
	goto L1157;}
	(*LK9)(1,(V17))                           /*  FONT-P          */;
	if(VALUES(0)==Cnil){
	goto L1157;}
	V18= Ct;
	{ int V32;
	VALUES(0)=Cnil;
	V32=1;
	unwind(frs_sch((V24)),Cnil,V32+1);}
L1157:
	if(!((fix((V21)))==0)){
	goto L1165;}
	{ int V32;
	VALUES(0)=(V19);
	V32=1;
	unwind(frs_sch((V14)),Cnil,V32+1);}
L1165:
	(*LK14)(5,(V15),MAKE_FIXNUM((V27)+(16)),(V22),MAKE_FIXNUM(0),(V21))/*  WRITE-SEQUENCE-CHAR2B*/;
	(((V28))->ust.ust_self[(V27)+(1)]=(fix((V21))));
	{register int V32;                        /*  BLEN            */
	V32= ((((16)+(((fix((V21))) << (1))))+(3)) & (-4));
	((*(unsigned short *)(((V28))->ust.ust_self+((V27)+(2))))=((V32) >> (- (-2))));
	((V15))->in.in_slots[6]= MAKE_FIXNUM((V27)+(V32));
	VALUES(0)=MAKE_FIXNUM((V27)+(V32));
	V31=1;
	}
	}
	frs_pop();
	MV_SAVE(V31);
	((V15))->in.in_slots[11]= (V30);
	MV_RESTORE(V31);
	if (unwinding) unwind(nlj_fr,nlj_tag,V31+1);
	else {
	V29= VALUES(0);}}
	}
	}
	(*LK15)(1,(V25))                          /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK17)(1,(V25))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	}
	if(!((fix((V21)))==(V16))){
	goto L1176;}
	T0= Cnil;
	goto L1174;
L1176:
	T0= (V19);
L1174:
	if((V20)!=Cnil){
	VALUES(0) = (V20);
	goto L1178;}
	VALUES(0) = (V9);
L1178:
	VALUES(1) = VALUES(0);
	VALUES(0) = T0;
	RETURN(2);}
	frs_pop();
	goto L1111;
	}
L1111:
	goto L1106;
	}}
	frs_pop();
	RETURN(V13);
	}
	}
}
/*	function definition for DISPLAY-KEYCODE-RANGE                 */
static L17(int narg, object V1)
{ VT19 VLEX19 CLSR19
TTL:
	VALUES(1) = ((V1))->in.in_slots[47];
	VALUES(0) = ((V1))->in.in_slots[46];
	RETURN(2);
}
/*	function definition for SET-MODIFIER-MAPPING                  */
static L18(int narg, object V1, ...)
{ VT20 VLEX20 CLSR20
	{volatile object V2;
	volatile object V3;
	volatile object V4;
	volatile object V5;
	volatile object V6;
	volatile object V7;
	volatile object V8;
	volatile object V9;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[16];
	parse_key(narg,args,8,L18keys,keyvars,OBJNULL,FALSE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	V7= keyvars[5];
	V8= keyvars[6];
	V9= keyvars[7];
	}
	{volatile int V10;                        /*  KEYCODES-PER-MODIFIER*/
	volatile object V11;                      /*  DATA            */
	{int V12= length((V2));
	{int V13= length((V3));
	{int V14= (V12)>=(V13)?V12:V13;
	{int V15= length((V4));
	{int V16= (V14)>=(V15)?V14:V15;
	{int V17= length((V5));
	{int V18= (V16)>=(V17)?V16:V17;
	{int V19= length((V6));
	{int V20= (V18)>=(V19)?V18:V19;
	{int V21= length((V7));
	{int V22= (V20)>=(V21)?V20:V21;
	{int V23= length((V8));
	{int V24= (V22)>=(V23)?V22:V23;
	{int V25= length((V9));
	V10= (V24)>=(V25)?V24:V25;}}}}}}}}}}}}}}
	(*LK36)(5,MAKE_FIXNUM((8)*(V10)),VV[43],VV[40],VV[44],MAKE_FIXNUM(0))/*  MAKE-ARRAY*/;
	V11= VALUES(0);
	(*LK37)(2,(V11),(V2))                     /*  REPLACE         */;
	(*LK37)(4,(V11),(V3),VV[45],MAKE_FIXNUM(V10))/*  REPLACE      */;
	(*LK37)(4,(V11),(V4),VV[45],MAKE_FIXNUM((2)*(V10)))/*  REPLACE*/;
	(*LK37)(4,(V11),(V5),VV[45],MAKE_FIXNUM((3)*(V10)))/*  REPLACE*/;
	(*LK37)(4,(V11),(V6),VV[45],MAKE_FIXNUM((4)*(V10)))/*  REPLACE*/;
	(*LK37)(4,(V11),(V7),VV[45],MAKE_FIXNUM((5)*(V10)))/*  REPLACE*/;
	(*LK37)(4,(V11),(V8),VV[45],MAKE_FIXNUM((6)*(V10)))/*  REPLACE*/;
	(*LK37)(4,(V11),(V9),VV[45],MAKE_FIXNUM((7)*(V10)))/*  REPLACE*/;
	{volatile object V12;                     /*  .DISPLAY.       */
	volatile object V13;                      /*  .PENDING-COMMAND.*/
	volatile object V14;                      /*  .REPLY-BUFFER.  */
	V12= (V1);
	V13= Cnil;
	V14= Cnil;
	{ int V15; volatile bool unwinding = FALSE;
	if ((V15=frs_push(FRS_PROTECT,Cnil))) {
	V15--; unwinding = TRUE;} else {
	if((((V12))->in.in_slots[10])==Cnil){
	goto L1193;}
	(*LK8)(3,VV[17],VV[18],(V12))             /*  X-ERROR         */;
L1193:
	(*LK11)(1,(V12))                          /*  START-PENDING-COMMAND*/;
	V13= VALUES(0);
	{register object V16;                     /*  %BUFFER         */
	V16= (V12);
	if(!(((fix(((V16))->in.in_slots[6]))+(160))>=(fix(((V16))->in.in_slots[2])))){
	goto L1199;}
	(*LK12)(1,(V16))                          /*  BUFFER-FLUSH    */;
L1199:
	{register int V17;                        /*  BUFFER-BOFFSET  */
	register object V18;                      /*  BUFFER-BBUF     */
	V17= fix(((V16))->in.in_slots[6]);
	V18= ((V16))->in.in_slots[7];
	((V12))->in.in_slots[4]= MAKE_FIXNUM(V17);
	(((V18))->ust.ust_self[(V17)+(0)]=(118));
	(*LK4)(2,MAKE_FIXNUM(V10),VV[40])         /*  TYPEP           */;
	if(VALUES(0)!=Cnil){
	goto L1211;}
	VALUES(0) = Cnil;
	goto L1210;
L1211:
	VALUES(0) = MAKE_FIXNUM((((V18))->ust.ust_self[(V17)+(1)]=(V10)));
L1210:
	if(VALUES(0)==Cnil)goto L1209;
	goto L1208;
L1209:
	(*LK13)(2,MAKE_FIXNUM(V10),VV[46])        /*  X-TYPE-ERROR    */;
L1208:
	(*LK4)(2,(V11),VV[26])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1215;}
	{int V19;
	V19= length((V11));
	Lceiling(2,MAKE_FIXNUM((V19)-(0)),MAKE_FIXNUM(4))/*  CEILING  */;
	((*(unsigned short *)(((V18))->ust.ust_self+((V17)+(2))))=(fix(VALUES(0)))+(1));
	(*LK38)(6,(V16),MAKE_FIXNUM((V17)+(4)),(V11),MAKE_FIXNUM(0),MAKE_FIXNUM(V19),Cnil)/*  WRITE-SEQUENCE-CARD8*/;
	goto L1213;
	}
L1215:
	(*LK13)(2,(V11),VV[47])                   /*  X-TYPE-ERROR    */;
L1213:
	(*LK15)(1,(V12))                          /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V12))                          /*  BUFFER-FORCE-OUTPUT*/;
	(*LK17)(1,(V12))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK18)(2,(V12),(V13))                    /*  READ-REPLY      */;
	V14= VALUES(0);
	{object V16;                              /*  %REPLY-BUFFER   */
	object V17;                               /*  %BUFFER         */
	{int V18;                                 /*  BUFFER-BOFFSET  */
	object V19;                               /*  BUFFER-BBUF     */
	V18= 0;
	V19= ((V14))->in.in_slots[1];
	{int V20;
	V20= ((V19))->ust.ust_self[(V18)+(1)];
	if((V20)<(3)){
	goto L1230;}
	VALUES(0)=Cnil;
	V15=1;
	goto L1191;
L1230:
	VALUES(0)=(VV[48])->v.v_self[V20];
	V15=1;
	}
	}
	}
L1191:
	}
	frs_pop();
	MV_SAVE(V15);
	if(((V14))==Cnil){
	goto L1233;}
	(*LK19)(1,(V14))                          /*  DEALLOCATE-REPLY-BUFFER*/;
L1233:
	if(((V13))==Cnil){
	goto L1232;}
	(*LK20)(2,(V12),(V13))                    /*  STOP-PENDING-COMMAND*/;
L1232:
	MV_RESTORE(V15);
	if (unwinding) unwind(nlj_fr,nlj_tag,V15+1);
	else {
	RETURN(V15);}}
	}
	}
	}
}
/*	function definition for MODIFIER-MAPPING                      */
static L19(int narg, object V1)
{ VT21 VLEX21 CLSR21
TTL:
	{volatile object V2;                      /*  LISTS           */
	V2= Cnil;
	{volatile object V3;                      /*  .DISPLAY.       */
	volatile object V4;                       /*  .PENDING-COMMAND.*/
	volatile object V5;                       /*  .REPLY-BUFFER.  */
	V3= (V1);
	V4= Cnil;
	V5= Cnil;
	{ int V6; volatile bool unwinding = FALSE;
	if ((V6=frs_push(FRS_PROTECT,Cnil))) {
	V6--; unwinding = TRUE;} else {
	if((((V3))->in.in_slots[10])==Cnil){
	goto L1241;}
	(*LK8)(3,VV[17],VV[18],(V3))              /*  X-ERROR         */;
L1241:
	(*LK11)(1,(V3))                           /*  START-PENDING-COMMAND*/;
	V4= VALUES(0);
	{object V7;                               /*  %BUFFER         */
	V7= (V3);
	if(!(((fix(((V7))->in.in_slots[6]))+(160))>=(fix(((V7))->in.in_slots[2])))){
	goto L1247;}
	(*LK12)(1,(V7))                           /*  BUFFER-FLUSH    */;
L1247:
	{register int V8;                         /*  BUFFER-BOFFSET  */
	object V9;                                /*  BUFFER-BBUF     */
	V8= fix(((V7))->in.in_slots[6]);
	V9= ((V7))->in.in_slots[7];
	((V3))->in.in_slots[4]= MAKE_FIXNUM(V8);
	(((V9))->ust.ust_self[(V8)+(0)]=(119));
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=1);
	((V3))->in.in_slots[6]= MAKE_FIXNUM((V8)+(4));
	(*LK15)(1,(V3))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V3))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK17)(1,(V3))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK18)(2,(V3),(V4))                      /*  READ-REPLY      */;
	V5= VALUES(0);
	{volatile object V7;                      /*  %REPLY-BUFFER   */
	volatile object V8;                       /*  %BUFFER         */
	{volatile int V9;                         /*  BUFFER-BOFFSET  */
	volatile object V10;                      /*  BUFFER-BBUF     */
	V9= 0;
	V10= ((V5))->in.in_slots[1];
	{volatile int V11;                        /*  KEYCODES-PER-MODIFIER*/
	volatile object V12;                      /*  ADVANCE-BY      */
	volatile object V13;                      /*  KEYS            */
	volatile object V14;                      /*  I               */
	V11= ((V10))->ust.ust_self[(V9)+(1)];
	V12= MAKE_FIXNUM(32);
	V13= Cnil;
	V14= MAKE_FIXNUM(0);
L1272:
	if(!((fix((V14)))==(8))){
	goto L1273;}
	VALUES(0)=Cnil;
	V6=1;
	goto L1239;
L1273:
	{register int V16;                        /*  .BOFFSET.       */
	V16= (V9)+(fix((V12)));
	V9= V16;
	}
	{volatile object V17;
	volatile int V18;                         /*  J               */
	V17= MAKE_FIXNUM(V11);
	V18= 0;
L1283:
	if(!(number_compare(MAKE_FIXNUM(V18),(V17))>=0)){
	goto L1284;}
	goto L1279;
L1284:
	{register int V20;                        /*  KEY             */
	V20= ((V10))->ust.ust_self[(V9)+(V18)];
	if((V20)==0){
	goto L1287;}
	V13= CONS(MAKE_FIXNUM(V20),(V13));
	}
L1287:
	V18= (V18)+1;
	goto L1283;
	}
L1279:
	{object V21= nreverse((V13));
	V2= CONS((V21),(V2));}
	V12= MAKE_FIXNUM(V11);
	V13= Cnil;
	V14= MAKE_FIXNUM((fix((V14)))+(1));
	goto L1272;
	}
	}
	}
L1239:
	}
	frs_pop();
	MV_SAVE(V6);
	if(((V5))==Cnil){
	goto L1305;}
	(*LK19)(1,(V5))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L1305:
	if(((V4))==Cnil){
	goto L1304;}
	(*LK20)(2,(V3),(V4))                      /*  STOP-PENDING-COMMAND*/;
L1304:
	MV_RESTORE(V6);
	if (unwinding) unwind(nlj_fr,nlj_tag,V6+1);
	else {}}
	}
	RETURN(Lvalues_list(1,nreverse((V2)))     /*  VALUES-LIST     */);
	}
}
/*	function definition for CHANGE-KEYBOARD-MAPPING               */
static L20(int narg, object V1, object V2, ...)
{ VT22 VLEX22 CLSR22
	{volatile int V3;
	volatile object V4;
	volatile int V5;
	va_list args; va_start(args, V2);
	narg -=2;
	{ object keyvars[6];
	parse_key(narg,args,3,L20keys,keyvars,OBJNULL,FALSE);
	if(keyvars[3]==Cnil){
	V3= 0;
	}else{
	V3= fix(keyvars[0]);}
	V4= keyvars[1];
	if(keyvars[5]==Cnil){
	V5= V3;
	}else{
	V5= fix(keyvars[2]);}
	}
	{volatile int V6;                         /*  KEYCODE-END     */
	volatile int V7;                          /*  KEYSYMS-PER-KEYCODE*/
	volatile int V8;                          /*  LENGTH          */
	volatile object V9;                       /*  SIZE            */
	volatile int V10;                         /*  REQUEST-LENGTH  */
	if((V4)!=Cnil){
	V6= fix((V4));
	goto L1312;}
	Larray_dimension(2,(V2),MAKE_FIXNUM(0))   /*  ARRAY-DIMENSION */;
	V6= fix(VALUES(0));
L1312:
	Larray_dimension(2,(V2),MAKE_FIXNUM(1))   /*  ARRAY-DIMENSION */;
	V7= fix(VALUES(0));
	V8= (V6)-(V3);
	V9= MAKE_FIXNUM((V8)*(V7));
	V10= (fix((V9)))+(2);
	{volatile object V11;                     /*  .DISPLAY.       */
	V11= (V1);
	if((((V11))->in.in_slots[10])==Cnil){
	goto L1317;}
	(*LK8)(3,VV[17],VV[18],(V11))             /*  X-ERROR         */;
L1317:
	{ int V12;
	{volatile object V13;                     /*  %BUFFER         */
	V13= (V11);
	if(!(((fix(((V13))->in.in_slots[6]))+((((V10) << (2)))+(160)))>=(fix(((V13))->in.in_slots[2])))){
	goto L1321;}
	(*LK12)(1,(V13))                          /*  BUFFER-FLUSH    */;
L1321:
	{volatile int V14;                        /*  BUFFER-BOFFSET  */
	volatile object V15;                      /*  BUFFER-BBUF     */
	V14= fix(((V13))->in.in_slots[6]);
	V15= ((V13))->in.in_slots[7];
	((V11))->in.in_slots[4]= MAKE_FIXNUM(V14);
	(((V15))->ust.ust_self[(V14)+(0)]=(100));
	(*LK4)(2,MAKE_FIXNUM(V8),VV[40])          /*  TYPEP           */;
	if(VALUES(0)!=Cnil){
	goto L1333;}
	VALUES(0) = Cnil;
	goto L1332;
L1333:
	VALUES(0) = MAKE_FIXNUM((((V15))->ust.ust_self[(V14)+(1)]=(V8)));
L1332:
	if(VALUES(0)==Cnil)goto L1331;
	goto L1330;
L1331:
	(*LK13)(2,MAKE_FIXNUM(V8),VV[46])         /*  X-TYPE-ERROR    */;
L1330:
	VALUES(0) = MAKE_FIXNUM(((*(unsigned short *)(((V15))->ust.ust_self+((V14)+(2))))=V10));
	if(VALUES(0)==Cnil)goto L1336;
	goto L1335;
L1336:
	(*LK13)(2,MAKE_FIXNUM(V10),VV[24])        /*  X-TYPE-ERROR    */;
L1335:
	(*LK4)(2,MAKE_FIXNUM(V5),VV[40])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1340;}
	(((V15))->ust.ust_self[(V14)+(4)]=(V5));
	goto L1338;
L1340:
	(*LK13)(2,MAKE_FIXNUM(V5),VV[40])         /*  X-TYPE-ERROR    */;
L1338:
	(*LK4)(2,MAKE_FIXNUM(V7),VV[40])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1344;}
	(((V15))->ust.ust_self[(V14)+(5)]=(V7));
	goto L1342;
L1344:
	(*LK13)(2,MAKE_FIXNUM(V7),VV[40])         /*  X-TYPE-ERROR    */;
L1342:
	{volatile object V16;                     /*  .VALUE.         */
	{volatile int V17;                        /*  LIMIT           */
	volatile int V18;                         /*  W               */
	volatile int V19;                         /*  I               */
	V17= ((fix(((V1))->in.in_slots[2])) >> (- (-2)));
	V18= (2)+(((V14) >> (- (-2))));
	V19= V3;
L1352:
	if(!((V19)>=(V6))){
	goto L1353;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(((V18) << (2)));
	V16= MAKE_FIXNUM(((V18) << (2)));
	goto L1347;
L1353:
	if(!((V18)>(V17))){
	goto L1356;}
	(*LK12)(1,(V1))                           /*  BUFFER-FLUSH    */;
	V18= ((fix(((V1))->in.in_slots[6])) >> (- (-2)));
L1356:
	{volatile int V21;                        /*  J               */
	V21= 0;
L1364:
	if(!((V21)>=(V7))){
	goto L1365;}
	goto L1361;
L1365:
	((*(unsigned long *)(((V15))->ust.ust_self+((V14)+((V18)*(4)))))=fix(((V2))->a.a_self[V19*((V2))->a.a_dims[1]+V21]));
	V18= (V18)+(1);
	V21= (V21)+(1);
	goto L1364;
	}
L1361:
	V19= (V19)+(1);
	goto L1352;
	}
L1347:
	}
	V12=(*LK15)(1,(V11))                      /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V12);
	(*LK17)(1,(V11))                          /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V12);
	RETURN(V12);}
	}
	}
	}
}
/*	function definition for KEYBOARD-MAPPING                      */
static L21(int narg, object V1, ...)
{ VT23 VLEX23 CLSR23
	{volatile object V2;
	volatile object V3;
	volatile object V4;
	volatile object V5;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[8];
	parse_key(narg,args,4,L21keys,keyvars,OBJNULL,FALSE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	}
	if(((V2))!=Cnil){
	goto L1378;}
	V2= ((V1))->in.in_slots[46];
L1378:
	if(((V3))!=Cnil){
	goto L1382;}
	V3= (V2);
L1382:
	if(((V4))!=Cnil){
	goto L1386;}
	V4= one_plus(((V1))->in.in_slots[47]);
L1386:
	{volatile object V6;                      /*  .DISPLAY.       */
	volatile object V7;                       /*  .PENDING-COMMAND.*/
	volatile object V8;                       /*  .REPLY-BUFFER.  */
	V6= (V1);
	V7= Cnil;
	V8= Cnil;
	{ int V9; volatile bool unwinding = FALSE;
	if ((V9=frs_push(FRS_PROTECT,Cnil))) {
	V9--; unwinding = TRUE;} else {
	if((((V6))->in.in_slots[10])==Cnil){
	goto L1393;}
	(*LK8)(3,VV[17],VV[18],(V6))              /*  X-ERROR         */;
L1393:
	(*LK11)(1,(V6))                           /*  START-PENDING-COMMAND*/;
	V7= VALUES(0);
	{object V10;                              /*  %BUFFER         */
	V10= (V6);
	if(!(((fix(((V10))->in.in_slots[6]))+(160))>=(fix(((V10))->in.in_slots[2])))){
	goto L1399;}
	(*LK12)(1,(V10))                          /*  BUFFER-FLUSH    */;
L1399:
	{register int V11;                        /*  BUFFER-BOFFSET  */
	object V12;                               /*  BUFFER-BBUF     */
	V11= fix(((V10))->in.in_slots[6]);
	V12= ((V10))->in.in_slots[7];
	((V6))->in.in_slots[4]= MAKE_FIXNUM(V11);
	(((V12))->ust.ust_self[(V11)+(0)]=(101));
	(*LK4)(2,(V2),VV[40])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1410;}
	(((V12))->ust.ust_self[(V11)+(4)]=(fix((V2))));
	goto L1408;
L1410:
	(*LK13)(2,(V2),VV[40])                    /*  X-TYPE-ERROR    */;
L1408:
	{int V13;                                 /*  .VALUE.         */
	V13= (fix((V4)))-(fix((V3)));
	(*LK4)(2,MAKE_FIXNUM(V13),VV[40])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1415;}
	(((V12))->ust.ust_self[(V11)+(5)]=(V13));
	goto L1412;
L1415:
	(*LK13)(2,MAKE_FIXNUM(V13),VV[40])        /*  X-TYPE-ERROR    */;
	}
L1412:
	((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(2))))=2);
	((V6))->in.in_slots[6]= MAKE_FIXNUM((V11)+(8));
	(*LK15)(1,(V6))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK16)(1,(V6))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK17)(1,(V6))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK18)(2,(V6),(V7))                      /*  READ-REPLY      */;
	V8= VALUES(0);
	{volatile object V10;                     /*  %REPLY-BUFFER   */
	volatile object V11;                      /*  %BUFFER         */
	{volatile int V12;                        /*  BUFFER-BOFFSET  */
	volatile object V13;                      /*  BUFFER-BBUF     */
	V12= 0;
	V13= ((V8))->in.in_slots[1];
	{volatile int V14;                        /*  KEYSYMS-PER-KEYCODE*/
	volatile object V15;                      /*  BYTES-PER-KEYCODE*/
	volatile object V16;                      /*  ADVANCE-BY      */
	volatile object V17;                      /*  KEYCODE-COUNT   */
	volatile object V18;                      /*  RESULT          */
	volatile object V19;                      /*  I               */
	V14= ((V13))->ust.ust_self[(V12)+(1)];
	V15= fixnum_times(V14,4);
	V16= MAKE_FIXNUM(32);
	Lfloor(2,MAKE_FIXNUM((*(unsigned long *)(((V13))->ust.ust_self+((V12)+(4))))),MAKE_FIXNUM(V14))/*  FLOOR*/;
	V17= VALUES(0);
	if(!(ARRAYP((V5)))){
	goto L1434;}
	Larray_rank(1,(V5))                       /*  ARRAY-RANK      */;
	if(!((fix(VALUES(0)))==(2))){
	goto L1434;}
	Larray_dimension(2,(V5),MAKE_FIXNUM(0))   /*  ARRAY-DIMENSION */;
	T0= VALUES(0);
	if(!((fix(T0))>=((fix((V3)))+(fix((V17)))))){
	goto L1434;}
	Larray_dimension(2,(V5),MAKE_FIXNUM(1))   /*  ARRAY-DIMENSION */;
	if(!((fix(VALUES(0)))>=(V14))){
	goto L1434;}
	V18= (V5);
	goto L1432;
L1434:
	(*LK36)(5,list(2,MAKE_FIXNUM((fix((V3)))+(fix((V17)))),MAKE_FIXNUM(V14)),VV[43],VV[49],VV[44],MAKE_FIXNUM(0))/*  MAKE-ARRAY*/;
	V18= VALUES(0);
L1432:
	V19= (V3);
L1447:
	if(!(number_compare(MAKE_FIXNUM(0),(V17))==0)){
	goto L1448;}
	V5= (V18);
	VALUES(0)=(V5);
	V9=1;
	goto L1391;
L1448:
	{register int V21;                        /*  .BOFFSET.       */
	V21= (V12)+(fix((V16)));
	V12= V21;
	}
	{volatile object V22;
	volatile int V23;                         /*  J               */
	V22= MAKE_FIXNUM(V14);
	V23= 0;
L1459:
	if(!(number_compare(MAKE_FIXNUM(V23),(V22))>=0)){
	goto L1460;}
	goto L1455;
L1460:
	{register object V25;
	register object V26;
	register object V27;
	V25= (V18);
	V26= (V19);
	V27= MAKE_FIXNUM(V23);
	{object V28= MAKE_FIXNUM(((*(unsigned long *)(((V13))->ust.ust_self+((V12)+((V23)*(4))))) & 0x1fffffff));
	aset((V25),fix((V26))*((V25))->a.a_dims[1]+fix((V27)),V28);}
	}
	V23= (V23)+1;
	goto L1459;
	}
L1455:
	V16= (V15);
	V17= MAKE_FIXNUM((fix((V17)))-(1));
	V19= one_plus((V19));
	goto L1447;
	}
	}
	}
L1391:
	}
	frs_pop();
	MV_SAVE(V9);
	if(((V8))==Cnil){
	goto L1478;}
	(*LK19)(1,(V8))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L1478:
	if(((V7))==Cnil){
	goto L1477;}
	(*LK20)(2,(V6),(V7))                      /*  STOP-PENDING-COMMAND*/;
L1477:
	MV_RESTORE(V9);
	if (unwinding) unwind(nlj_fr,nlj_tag,V9+1);
	else {}}
	}
	VALUES(0) = (V5);
	RETURN(1);
	}
}
static LKF38(int narg, ...) {TRAMPOLINK(VV[139],&LK38);}
static LKF37(int narg, ...) {TRAMPOLINK(VV[138],&LK37);}
static LKF36(int narg, ...) {TRAMPOLINK(VV[137],&LK36);}
static LKF35(int narg, ...) {TRAMPOLINK(VV[119],&LK35);}
static LKF34(int narg, ...) {TRAMPOLINK(VV[118],&LK34);}
static LKF33(int narg, ...) {TRAMPOLINK(VV[117],&LK33);}
static LKF32(int narg, ...) {TRAMPOLINK(VV[116],&LK32);}
static LKF31(int narg, ...) {TRAMPOLINK(VV[115],&LK31);}
static LKF30(int narg, ...) {TRAMPOLINK(VV[114],&LK30);}
static LKF29(int narg, ...) {TRAMPOLINK(VV[113],&LK29);}
static LKF28(int narg, ...) {TRAMPOLINK(VV[112],&LK28);}
static LKF27(int narg, ...) {TRAMPOLINK(VV[108],&LK27);}
static LKF26(int narg, ...) {TRAMPOLINK(VV[107],&LK26);}
static LKF25(int narg, ...) {TRAMPOLINK(VV[106],&LK25);}
static LKF24(int narg, ...) {TRAMPOLINK(VV[105],&LK24);}
static LKF23(int narg, ...) {TRAMPOLINK(VV[104],&LK23);}
static LKF22(int narg, ...) {TRAMPOLINK(VV[103],&LK22);}
static LKF21(int narg, ...) {TRAMPOLINK(VV[102],&LK21);}
static LKF20(int narg, ...) {TRAMPOLINK(VV[99],&LK20);}
static LKF19(int narg, ...) {TRAMPOLINK(VV[98],&LK19);}
static LKF18(int narg, ...) {TRAMPOLINK(VV[97],&LK18);}
static LKF17(int narg, ...) {TRAMPOLINK(VV[96],&LK17);}
static LKF16(int narg, ...) {TRAMPOLINK(VV[95],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[94],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[93],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[92],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[91],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[90],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[89],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[85],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[84],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[83],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[82],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[81],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[80],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[79],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[78],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[77],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[72],&LK0);}
