
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "cmpmain.h"
init_cmpmain(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_cmpmain; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	VV[1]->s.s_stype=(short)stp_special;
	if(VV[1]->s.s_dbind == OBJNULL){
	(VV[1]->s.s_dbind)= VV[0];}
	siLAmake_constant(2,VV[2],VV[3])          /*  *MAKE-CONSTANT  */;
	VV[5]->s.s_stype=(short)stp_special;
	if(VV[5]->s.s_dbind == OBJNULL){
	(VV[5]->s.s_dbind)= VV[4];}
	VV[7]->s.s_stype=(short)stp_special;
	if(VV[7]->s.s_dbind == OBJNULL){
	(VV[7]->s.s_dbind)= VV[6];}
	VV[8]->s.s_stype=(short)stp_special;
	if(VV[8]->s.s_dbind == OBJNULL){
	(VV[8]->s.s_dbind)= Cnil;}
	VV[9]->s.s_stype=(short)stp_special;
	VV[10]->s.s_stype=(short)stp_special;
	VV[11]->s.s_stype=(short)stp_special;
	VV[12]->s.s_stype=(short)stp_special;
	VV[13]->s.s_stype=(short)stp_special;
	if(VV[13]->s.s_dbind == OBJNULL){
	(VV[13]->s.s_dbind)= Cnil;}
	VV[14]->s.s_stype=(short)stp_special;
	if(VV[14]->s.s_dbind == OBJNULL){
	(VV[14]->s.s_dbind)= Ct;}
	VV[15]->s.s_stype=(short)stp_special;
	if(VV[15]->s.s_dbind == OBJNULL){
	(VV[15]->s.s_dbind)= Ct;}
	MF0key(VV[91],L1,7,L1keys);
	MF0(VV[92],L2);
	VV[76]=string_to_object(VV[76]);
	MF0key(VV[93],L3,2,L3keys);
	VV[78]=string_to_object(VV[78]);
	MF0(VV[94],L6);
	VV[80]->s.s_stype=(short)stp_special;
	if(VV[80]->s.s_dbind == OBJNULL){
	(VV[80]->s.s_dbind)= VV[79];}
	MF0(VV[95],L7);
	MF0(VV[96],L9);
	MF0(VV[97],L10);
}
/*	function definition for COMPILE-FILE                          */
static L1(int narg, object V1, ...)
{ VT3 VLEX3 CLSR3
	bds_check;
	{VOL object V2;
	VOL object V3;
	VOL object V4;
	VOL object V5;
	VOL object V6;
	VOL object V7;
	VOL object V8;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[14];
	parse_key(narg,args,7,L1keys,keyvars,OBJNULL,FALSE);
	if(keyvars[7]==Cnil){
	V2= (V1);
	}else{
	V2= keyvars[0];}
	if(keyvars[8]==Cnil){
	V3= Ct;
	}else{
	V3= keyvars[1];}
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	V7= keyvars[5];
	V8= keyvars[6];
	}
	bds_bind(VV[16],(VV[16]->s.s_dbind));     /*  *STANDARD-OUTPUT**/
	bds_bind(VV[17],(VV[17]->s.s_dbind));     /*  *ERROR-OUTPUT*  */
	bds_bind(VV[8],(VV[8]->s.s_dbind));       /*  *COMPILER-IN-USE**/
	bds_bind(VV[18],(VV[18]->s.s_dbind));     /*  *PACKAGE*       */
	bds_bind(VV[19],Cnil);                    /*  *PRINT-PRETTY*  */
	bds_bind(VV[20],MAKE_FIXNUM(0));          /*  *ERROR-COUNT*   */
	Lmerge_pathnames(2,(V1),VV[21])           /*  MERGE-PATHNAMES */;
	V1= VALUES(0);
	if(((VV[8]->s.s_dbind))==Cnil){
	goto L15;}
	Lformat(3,Ct,VV[22],coerce_to_namestring((V1)))/*  FORMAT     */;
	(VV[13]->s.s_dbind)= Ct;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(0);
L15:
	(VV[13]->s.s_dbind)= Cnil;
	(VV[8]->s.s_dbind)= Ct;
	if((file_exists((V1)))){
	goto L25;}
	Lformat(3,Ct,VV[23],coerce_to_namestring((V1)))/*  FORMAT     */;
	(VV[13]->s.s_dbind)= Ct;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(0);
L25:
	if(((VV[15]->s.s_dbind))==Cnil){
	goto L31;}
	Lformat(3,Ct,VV[24],coerce_to_namestring((V1)))/*  FORMAT     */;
L31:
	{VOL object V9;                           /*  EOF             */
	VOL object V10;                           /*  DIR             */
	VOL object V11;                           /*  NAME            */
	VOL object V12;                           /*  O-PATHNAME      */
	VOL object V13;                           /*  C-PATHNAME      */
	VOL object V14;                           /*  H-PATHNAME      */
	VOL object V15;                           /*  DATA-PATHNAME   */
	V9= CONS(Cnil,Cnil);
	if((V2)==Cnil){
	VALUES(0) = Cnil;
	goto L37;}
	Lpathname_directory(1,(V2))               /*  PATHNAME-DIRECTORY*/;
L37:
	if(VALUES(0)==Cnil)goto L36;
	V10= VALUES(0);
	goto L35;
L36:
	Lpathname_directory(1,(V1))               /*  PATHNAME-DIRECTORY*/;
	V10= VALUES(0);
L35:
	if((V2)==Cnil){
	VALUES(0) = Cnil;
	goto L40;}
	Lpathname_name(1,(V2))                    /*  PATHNAME-NAME   */;
L40:
	if(VALUES(0)==Cnil)goto L39;
	V11= VALUES(0);
	goto L38;
L39:
	Lpathname_name(1,(V1))                    /*  PATHNAME-NAME   */;
	V11= VALUES(0);
L38:
	if((V3)==Cnil){
	VALUES(0) = Cnil;
	goto L44;}
	if(((((V3))==(Ct)?Ct:Cnil))==Cnil){
	goto L45;}
	VALUES(0) = Cnil;
	goto L44;
L45:
	Lpathname_directory(1,(V3))               /*  PATHNAME-DIRECTORY*/;
L44:
	if(VALUES(0)==Cnil)goto L43;
	T0= VALUES(0);
	goto L42;
L43:
	T0= (V10);
L42:
	if((V3)==Cnil){
	VALUES(0) = Cnil;
	goto L49;}
	if(((((V3))==(Ct)?Ct:Cnil))==Cnil){
	goto L50;}
	VALUES(0) = Cnil;
	goto L49;
L50:
	Lpathname_name(1,(V3))                    /*  PATHNAME-NAME   */;
L49:
	if(VALUES(0)==Cnil)goto L48;
	goto L47;
L48:
	VALUES(0) = (V11);
L47:
	Lmake_pathname(6,VV[25],T0,VV[26],VALUES(0),VV[27],VV[28])/*  MAKE-PATHNAME*/;
	V12= VALUES(0);
	if((V4)==Cnil){
	VALUES(0) = Cnil;
	goto L55;}
	if(((((V4))==(Ct)?Ct:Cnil))==Cnil){
	goto L56;}
	VALUES(0) = Cnil;
	goto L55;
L56:
	Lpathname_directory(1,(V4))               /*  PATHNAME-DIRECTORY*/;
L55:
	if(VALUES(0)==Cnil)goto L54;
	T0= VALUES(0);
	goto L53;
L54:
	T0= (V10);
L53:
	if((V4)==Cnil){
	VALUES(0) = Cnil;
	goto L60;}
	if(((((V4))==(Ct)?Ct:Cnil))==Cnil){
	goto L61;}
	VALUES(0) = Cnil;
	goto L60;
L61:
	Lpathname_name(1,(V4))                    /*  PATHNAME-NAME   */;
L60:
	if(VALUES(0)==Cnil)goto L59;
	goto L58;
L59:
	VALUES(0) = (V11);
L58:
	Lmake_pathname(6,VV[25],T0,VV[26],VALUES(0),VV[27],VV[29])/*  MAKE-PATHNAME*/;
	V13= VALUES(0);
	if((V5)==Cnil){
	VALUES(0) = Cnil;
	goto L66;}
	if(((((V5))==(Ct)?Ct:Cnil))==Cnil){
	goto L67;}
	VALUES(0) = Cnil;
	goto L66;
L67:
	Lpathname_directory(1,(V5))               /*  PATHNAME-DIRECTORY*/;
L66:
	if(VALUES(0)==Cnil)goto L65;
	T0= VALUES(0);
	goto L64;
L65:
	T0= (V10);
L64:
	if((V5)==Cnil){
	VALUES(0) = Cnil;
	goto L71;}
	if(((((V5))==(Ct)?Ct:Cnil))==Cnil){
	goto L72;}
	VALUES(0) = Cnil;
	goto L71;
L72:
	Lpathname_name(1,(V5))                    /*  PATHNAME-NAME   */;
L71:
	if(VALUES(0)==Cnil)goto L70;
	goto L69;
L70:
	VALUES(0) = (V11);
L69:
	Lmake_pathname(6,VV[25],T0,VV[26],VALUES(0),VV[27],VV[30])/*  MAKE-PATHNAME*/;
	V14= VALUES(0);
	if((V6)==Cnil){
	VALUES(0) = Cnil;
	goto L77;}
	if(((((V6))==(Ct)?Ct:Cnil))==Cnil){
	goto L78;}
	VALUES(0) = Cnil;
	goto L77;
L78:
	Lpathname_directory(1,(V6))               /*  PATHNAME-DIRECTORY*/;
L77:
	if(VALUES(0)==Cnil)goto L76;
	T0= VALUES(0);
	goto L75;
L76:
	T0= (V10);
L75:
	if((V6)==Cnil){
	VALUES(0) = Cnil;
	goto L82;}
	if(((((V6))==(Ct)?Ct:Cnil))==Cnil){
	goto L83;}
	VALUES(0) = Cnil;
	goto L82;
L83:
	Lpathname_name(1,(V6))                    /*  PATHNAME-NAME   */;
L82:
	if(VALUES(0)==Cnil)goto L81;
	goto L80;
L81:
	VALUES(0) = (V11);
L80:
	Lmake_pathname(6,VV[25],T0,VV[26],VALUES(0),VV[27],VV[31])/*  MAKE-PATHNAME*/;
	V15= VALUES(0);
	(*LK0)(0)                                 /*  INIT-ENV        */;
	if(!((file_exists(VV[32])))){
	goto L86;}
	(*LK1)(3,VV[33],VV[34],(VV[15]->s.s_dbind))/*  LOAD           */;
L86:
	{VOL object V16;
	(*LK2)(3,(V15),VV[35],VV[36])             /*  OPEN            */;
	V16= VALUES(0);
	bds_bind(VV[12],V16);                     /*  *COMPILER-OUTPUT-DATA**/
	{ int V17; bool unwinding = FALSE;
	if ((V17=frs_push(FRS_PROTECT,Cnil))) {
	V17--; unwinding = TRUE;} else {
	(*LK3)(0)                                 /*  WT-DATA-BEGIN   */;
	{VOL object V18;
	(*LK2)(1,(V1))                            /*  OPEN            */;
	V18= VALUES(0);
	bds_bind(VV[9],V18);                      /*  *COMPILER-INPUT**/
	{ int V19; bool unwinding = FALSE;
	if ((V19=frs_push(FRS_PROTECT,Cnil))) {
	V19--; unwinding = TRUE;} else {
	{VOL object V20;                          /*  RTB             */
	VOL object V21;                           /*  PREV            */
	V20= (VV[37]->s.s_dbind);
	Lget_macro_character(2,code_char('\43'),(V20))/*  GET-MACRO-CHARACTER*/;
	T0= VALUES(0);
	Lcopy_readtable(1,Cnil)                   /*  COPY-READTABLE  */;
	Lget_macro_character(2,code_char('\43'),VALUES(0))/*  GET-MACRO-CHARACTER*/;
	if((T0)==(VALUES(0))){
	goto L98;}
	V21= Cnil;
	goto L97;
L98:
	Lget_dispatch_macro_character(3,code_char('\43'),code_char('\54'),(V20))/*  GET-DISPATCH-MACRO-CHARACTER*/;
	V21= VALUES(0);
L97:
	if(((V21))==Cnil){
	goto L105;}
	Lcopy_readtable(1,Cnil)                   /*  COPY-READTABLE  */;
	Lget_dispatch_macro_character(3,code_char('\43'),code_char('\54'),VALUES(0))/*  GET-DISPATCH-MACRO-CHARACTER*/;
	if(!(((V21))==(VALUES(0)))){
	goto L105;}
	Lset_dispatch_macro_character(4,code_char('\43'),code_char('\54'),VV[38],(V20))/*  SET-DISPATCH-MACRO-CHARACTER*/;
	goto L103;
L105:
	V21= Cnil;
L103:
	{ int V22; bool unwinding = FALSE;
	if ((V22=frs_push(FRS_PROTECT,Cnil))) {
	V22--; unwinding = TRUE;} else {
	{object V23;                              /*  FORM            */
	Lread(3,(VV[9]->s.s_dbind),Cnil,(V9))     /*  READ            */;
	V23= VALUES(0);
L115:
	if(!(((V23))==((V9)))){
	goto L116;}
	VALUES(0)=Cnil;
	V22=1;
	goto L112;
L116:
	(*LK4)(1,(V23))                           /*  T1EXPR          */;
	Lread(3,(VV[9]->s.s_dbind),Cnil,(V9))     /*  READ            */;
	V23= VALUES(0);
	goto L115;
	}
L112:
	}
	frs_pop();
	MV_SAVE(V22);
	if(((V21))==Cnil){
	goto L123;}
	Lset_dispatch_macro_character(4,code_char('\43'),code_char('\54'),(V21),(V20))/*  SET-DISPATCH-MACRO-CHARACTER*/;
L123:
	MV_RESTORE(V22);
	if (unwinding) unwind(nlj_fr,nlj_tag,V22+1);
	else {
	V19=V22;}}
	}
	}
	frs_pop();
	MV_SAVE(V19);
	Lclose(1,(VV[9]->s.s_dbind))              /*  CLOSE           */;
	MV_RESTORE(V19);
	if (unwinding) unwind(nlj_fr,nlj_tag,V19+1);
	else {
	bds_unwind1;}}
	}
	if(!(number_compare(MAKE_FIXNUM(0),(VV[20]->s.s_dbind))==0)){
	goto L127;}
	if(((VV[15]->s.s_dbind))==Cnil){
	goto L130;}
	Lformat(2,Ct,VV[39])                      /*  FORMAT          */;
L130:
	if(((V7))==Cnil){
	goto L135;}
	Lpathname_name(1,(V1))                    /*  PATHNAME-NAME   */;
	goto L133;
L135:
	VALUES(0) = VV[40];
L133:
	L6(4,(V13),(V14),(V7),VALUES(0))          /*  COMPILER-PASS2  */;
L127:
	V17=(*LK5)(0)                             /*  WT-DATA-END     */;
	}
	frs_pop();
	MV_SAVE(V17);
	Lclose(1,(VV[12]->s.s_dbind))             /*  CLOSE           */;
	MV_RESTORE(V17);
	if (unwinding) unwind(nlj_fr,nlj_tag,V17+1);
	else {
	bds_unwind1;}}
	}
	(*LK0)(0)                                 /*  INIT-ENV        */;
	if(!(number_compare(MAKE_FIXNUM(0),(VV[20]->s.s_dbind))==0)){
	goto L140;}
	if(((V3))==Cnil){
	goto L144;}
	if(((VV[15]->s.s_dbind))==Cnil){
	goto L146;}
	Lformat(2,Ct,VV[41])                      /*  FORMAT          */;
L146:
	(*LK6)(2,(V13),(V12))                     /*  COMPILER-CC     */;
	if(!((file_exists((V12))))){
	goto L151;}
	L9(2,(V12),(V15))                         /*  CAT-DATA-FILE   */;
	if(((V8))==Cnil){
	goto L154;}
	(*LK1)(1,(V12))                           /*  LOAD            */;
L154:
	if(((VV[15]->s.s_dbind))==Cnil){
	goto L142;}
	L10(0)                                    /*  PRINT-COMPILER-INFO*/;
	Lformat(3,Ct,VV[42],coerce_to_namestring((V1)))/*  FORMAT     */;
	goto L142;
L151:
	Lformat(2,Ct,VV[43])                      /*  FORMAT          */;
	(VV[13]->s.s_dbind)= Ct;
	goto L142;
L144:
	if(((VV[15]->s.s_dbind))==Cnil){
	goto L142;}
	L10(0)                                    /*  PRINT-COMPILER-INFO*/;
	Lformat(3,Ct,VV[44],coerce_to_namestring((V1)))/*  FORMAT     */;
L142:
	if(((V4))!=Cnil){
	goto L165;}
	Ldelete_file(1,(V13))                     /*  DELETE-FILE     */;
L165:
	if(((V5))!=Cnil){
	goto L168;}
	Ldelete_file(1,(V14))                     /*  DELETE-FILE     */;
L168:
	if(((V6))!=Cnil){
	goto L171;}
	Ldelete_file(1,(V15))                     /*  DELETE-FILE     */;
L171:
	{int V16;
	VALUES(0)=(V12);
	V16=1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V16);}
L140:
	if(!((file_exists((V13))))){
	goto L174;}
	Ldelete_file(1,(V13))                     /*  DELETE-FILE     */;
L174:
	if(!((file_exists((V14))))){
	goto L177;}
	Ldelete_file(1,(V14))                     /*  DELETE-FILE     */;
L177:
	if(!((file_exists((V15))))){
	goto L180;}
	Ldelete_file(1,(V15))                     /*  DELETE-FILE     */;
L180:
	Lformat(2,Ct,VV[45])                      /*  FORMAT          */;
	(VV[13]->s.s_dbind)= Ct;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(0);
	}
	}
}
/*	function definition for COMPILE                               */
static L2(int narg, object V1, ...)
{ VT4 VLEX4 CLSR4
	bds_check;
	{int i=1;
	VOL object V2;
	VOL object V3;
	va_list args; va_start(args, V1);
	if (i==narg) goto L186;
	V2= va_arg(args, object);
	V3= Ct;
	i++;
	goto L187;
L186:
	V2= Cnil;
	V3= Cnil;
L187:
	{register object V4;                      /*  FORM            */
	register object V5;                       /*  GAZONK-NAME     */
	register object V6;                       /*  DATA-PATHNAME   */
	V4= Cnil;
	V5= Cnil;
	V6= Cnil;
	bds_bind(VV[8],(VV[8]->s.s_dbind));       /*  *COMPILER-IN-USE**/
	bds_bind(VV[16],(VV[16]->s.s_dbind));     /*  *STANDARD-OUTPUT**/
	bds_bind(VV[17],(VV[17]->s.s_dbind));     /*  *ERROR-OUTPUT*  */
	bds_bind(VV[18],(VV[18]->s.s_dbind));     /*  *PACKAGE*       */
	bds_bind(VV[14],Cnil);                    /*  *COMPILE-PRINT* */
	bds_bind(VV[19],Cnil);                    /*  *PRINT-PRETTY*  */
	bds_bind(VV[20],MAKE_FIXNUM(0));          /*  *ERROR-COUNT*   */
	if(type_of((V1))==t_symbol){
	goto L192;}
	Lerror(2,VV[46],(V1))                     /*  ERROR           */;
L192:
	if(((VV[8]->s.s_dbind))==Cnil){
	goto L195;}
	Lformat(3,Ct,VV[47],(V1))                 /*  FORMAT          */;
	(VV[13]->s.s_dbind)= Ct;
	{int V8;
	VALUES(0)=Cnil;
	V8=1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V8);}
L195:
	(VV[13]->s.s_dbind)= Cnil;
	(VV[8]->s.s_dbind)= Ct;
	if(((V3))==Cnil){
	goto L207;}
	if(((V2))==Cnil){
	goto L207;}
	if(!(type_of((V2))==t_cons)){
	goto L212;}
	if((CAR((V2)))==(VV[48])){
	goto L211;}
L212:
	Lerror(2,VV[49],(V2))                     /*  ERROR           */;
L211:
	if(((V1))==Cnil){
	goto L218;}
	V4= listA(3,VV[50],(V1),CDR((V2)));
	goto L216;
L218:
	V4= list(3,VV[51],VV[52],list(2,VV[53],(V2)));
L216:
	goto L205;
L207:
	Lfboundp(1,(V1))                          /*  FBOUNDP         */;
	if(VALUES(0)==Cnil){
	goto L221;}
	V2= symbol_function((V1));
	if(!(type_of((V2))==t_cons)){
	goto L221;}
	if(!((CAR((V2)))==(VV[54]))){
	goto L227;}
	if(!(type_of(CDR((V2)))==t_cons)){
	goto L227;}
	if(!(type_of(CDDR((V2)))==t_cons)){
	goto L227;}
	if(!((CADR((V2)))==((V1)))){
	goto L234;}
	V4= listA(3,VV[50],(V1),CDDR((V2)));
	goto L205;
L234:
	{object V7= CADDR((V2));
	V4= list(4,VV[50],(V1),V7,listA(3,VV[55],CADR((V2)),CDDDR((V2))));}
	goto L205;
L227:
	if(!((CAR((V2)))==(VV[48]))){
	goto L239;}
	V4= listA(3,VV[50],(V1),CDR((V2)));
	goto L205;
L239:
	if(!((CAR((V2)))==(VV[56]))){
	goto L243;}
	if(!(type_of(CDR((V2)))==t_cons)){
	goto L243;}
	if((CADR((V2)))!=Cnil){
	goto L243;}
	if(!(type_of(CDDR((V2)))==t_cons)){
	goto L243;}
	if((CADDR((V2)))!=Cnil){
	goto L243;}
	if(!(type_of(CDDDR((V2)))==t_cons)){
	goto L243;}
	if((CADDDR((V2)))!=Cnil){
	goto L243;}
	V4= listA(3,VV[50],(V1),CDDDDR((V2)));
	goto L205;
L243:
	if(!((CAR((V2)))==(VV[57]))){
	goto L259;}
	if(!(type_of(CDR((V2)))==t_cons)){
	goto L259;}
	if((CADR((V2)))!=Cnil){
	goto L259;}
	if(!(type_of(CDDR((V2)))==t_cons)){
	goto L259;}
	if((CADDR((V2)))!=Cnil){
	goto L259;}
	if(!(type_of(CDDDR((V2)))==t_cons)){
	goto L259;}
	if((CADDDR((V2)))!=Cnil){
	goto L259;}
	if(!(type_of(CDDDDR((V2)))==t_cons)){
	goto L259;}
	V4= list(3,VV[50],(V1),listA(3,VV[55],CAR(CDDDDR((V2))),CDR(CDDDDR((V2)))));
	goto L205;
L259:
	Lerror(2,VV[58],CAR((V2)))                /*  ERROR           */;
	goto L205;
L221:
	Lerror(2,VV[59],(V1))                     /*  ERROR           */;
L205:
	{register int V7;                         /*  N               */
	V7= 0;
L279:
	if(!((V7)>=(fix(MAKE_FIXNUM(1000))))){
	goto L280;}
	Lformat(3,Ct,VV[60],(V1))                 /*  FORMAT          */;
	(VV[13]->s.s_dbind)= Ct;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(0);
L280:
	Lformat(3,Cnil,VV[61],MAKE_FIXNUM(V7))    /*  FORMAT          */;
	V5= VALUES(0);
	Lmake_pathname(4,VV[26],(V5),VV[27],VV[62])/*  MAKE-PATHNAME  */;
	V6= VALUES(0);
	if((file_exists((V6)))){
	goto L290;}
	goto L276;
L290:
	V7= (V7)+1;
	goto L279;
	}
L276:
	{VOL object V7;                           /*  C-PATHNAME      */
	VOL object V8;
	VOL object V9;                            /*  H-PATHNAME      */
	VOL object V10;
	VOL object V11;                           /*  O-PATHNAME      */
	Lmake_pathname(4,VV[26],(V5),VV[27],VV[63])/*  MAKE-PATHNAME  */;
	V8= VALUES(0);
	Lmake_pathname(4,VV[26],(V5),VV[27],VV[64])/*  MAKE-PATHNAME  */;
	V10= VALUES(0);
	Lmake_pathname(4,VV[26],(V5),VV[27],VV[65])/*  MAKE-PATHNAME  */;
	V11= VALUES(0);
	V7= V8;
	V9= V10;
	(*LK0)(0)                                 /*  INIT-ENV        */;
	{VOL object V12;
	(*LK2)(3,(V6),VV[35],VV[36])              /*  OPEN            */;
	V12= VALUES(0);
	bds_bind(VV[12],V12);                     /*  *COMPILER-OUTPUT-DATA**/
	{ int V13; bool unwinding = FALSE;
	if ((V13=frs_push(FRS_PROTECT,Cnil))) {
	V13--; unwinding = TRUE;} else {
	(*LK3)(0)                                 /*  WT-DATA-BEGIN   */;
	(*LK4)(1,(V4))                            /*  T1EXPR          */;
	if(!(number_compare(MAKE_FIXNUM(0),(VV[20]->s.s_dbind))==0)){
	goto L305;}
	if(((VV[15]->s.s_dbind))==Cnil){
	goto L308;}
	Lformat(2,Ct,VV[66])                      /*  FORMAT          */;
L308:
	L6(4,(V7),(V9),Cnil,VV[67])               /*  COMPILER-PASS2  */;
L305:
	V13=(*LK5)(0)                             /*  WT-DATA-END     */;
	}
	frs_pop();
	MV_SAVE(V13);
	Lclose(1,(VV[12]->s.s_dbind))             /*  CLOSE           */;
	MV_RESTORE(V13);
	if (unwinding) unwind(nlj_fr,nlj_tag,V13+1);
	else {
	bds_unwind1;}}
	}
	(*LK0)(0)                                 /*  INIT-ENV        */;
	if(!(number_compare(MAKE_FIXNUM(0),(VV[20]->s.s_dbind))==0)){
	goto L314;}
	if(((VV[15]->s.s_dbind))==Cnil){
	goto L316;}
	Lformat(2,Ct,VV[68])                      /*  FORMAT          */;
L316:
	L7(2,(V7),(V11))                          /*  COMPILER-CC     */;
	Ldelete_file(1,(V7))                      /*  DELETE-FILE     */;
	Ldelete_file(1,(V9))                      /*  DELETE-FILE     */;
	if(!((file_exists((V11))))){
	goto L324;}
	L9(2,(V11),(V6))                          /*  CAT-DATA-FILE   */;
	(*LK1)(3,(V11),VV[34],Cnil)               /*  LOAD            */;
	if(((VV[15]->s.s_dbind))==Cnil){
	goto L328;}
	L10(0)                                    /*  PRINT-COMPILER-INFO*/;
L328:
	Ldelete_file(1,(V11))                     /*  DELETE-FILE     */;
	Ldelete_file(1,(V6))                      /*  DELETE-FILE     */;
	goto L322;
L324:
	Ldelete_file(1,(V6))                      /*  DELETE-FILE     */;
	Lformat(3,Ct,VV[69],(V1))                 /*  FORMAT          */;
	(VV[13]->s.s_dbind)= Ct;
L322:
	if((V1)!=Cnil){
	{int V12;
	VALUES(0)=(V1);
	V12=1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V12);}}
	{int V13;
	V13=Lsymbol_value(1,VV[70])               /*  SYMBOL-VALUE    */;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V13);}
L314:
	if(!((file_exists((V7))))){
	goto L335;}
	Ldelete_file(1,(V7))                      /*  DELETE-FILE     */;
L335:
	if(!((file_exists((V9))))){
	goto L338;}
	Ldelete_file(1,(V9))                      /*  DELETE-FILE     */;
L338:
	if(!((file_exists((V6))))){
	goto L341;}
	Ldelete_file(1,(V6))                      /*  DELETE-FILE     */;
L341:
	Lformat(3,Ct,VV[71],(V1))                 /*  FORMAT          */;
	(VV[13]->s.s_dbind)= Ct;
	{int V14;
	VALUES(0)=(V1);
	V14=1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V14);}
	}
	}
	}
}
/*	function definition for DISASSEMBLE                           */
static L3(int narg, ...)
{ VT5 VLEX5 CLSR5
	bds_check;
	{int i=0;
	VOL object V1;
	VOL object V2;
	VOL object V3;
	va_list args; va_start(args, narg);
	if (i==narg) goto L347;
	V1= va_arg(args, object);
	i++;
	goto L348;
L347:
	V1= Cnil;
L348:
	narg -=1;
	{ object keyvars[4];
	parse_key(narg,args,2,L3keys,keyvars,OBJNULL,FALSE);
	V2= keyvars[0];
	V3= keyvars[1];
	}
	{register object V4;                      /*  DEF             */
	register object V5;                       /*  DISASSEMBLED-FORM*/
	V4= Cnil;
	V5= Cnil;
	bds_bind(VV[8],(VV[8]->s.s_dbind));       /*  *COMPILER-IN-USE**/
	bds_bind(VV[19],Cnil);                    /*  *PRINT-PRETTY*  */
	if(((VV[8]->s.s_dbind))==Cnil){
	goto L352;}
	Lformat(3,Ct,VV[72],(V1))                 /*  FORMAT          */;
	(VV[13]->s.s_dbind)= Ct;
	{int V7;
	VALUES(0)=Cnil;
	V7=1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V7);}
L352:
	(VV[13]->s.s_dbind)= Cnil;
	(VV[8]->s.s_dbind)= Ct;
	{object V6;
	V6= ((V1)==Cnil?Ct:Cnil);
	if(((V6))==Cnil){
	goto L365;}
	goto L362;
L365:
	if(!(type_of((V1))==t_symbol)){
	goto L368;}
	V4= symbol_function((V1));
	Lmacro_function(1,(V1))                   /*  MACRO-FUNCTION  */;
	if(VALUES(0)==Cnil){
	goto L372;}
	V4= CDR((V4));
L372:
	if(!(type_of((V4))==t_cons)){
	goto L377;}
	if(!((CAR((V4)))==(VV[54]))){
	goto L377;}
	if(!(type_of(CDR((V4)))==t_cons)){
	goto L377;}
	V5= listA(3,VV[50],(V1),CDDR((V4)));
	goto L362;
L377:
	Lerror(2,VV[73],(V4))                     /*  ERROR           */;
	goto L362;
L368:
	if(!(type_of((V1))==t_cons)){
	goto L385;}
	if(!((CAR((V1)))==(VV[48]))){
	goto L385;}
	V5= listA(3,VV[50],VV[70],CDR((V1)));
	goto L362;
L385:
	V5= (V1);
	}
L362:
	{VOL object V6;                           /*  NULL-STREAM     */
	Lmake_broadcast_stream(0)                 /*  MAKE-BROADCAST-STREAM*/;
	V6= VALUES(0);
	bds_bind(VV[10],(V6));                    /*  *COMPILER-OUTPUT1**/
	if(((V2))==Cnil){
	goto L395;}
	(*LK2)(3,(V2),VV[35],VV[36])              /*  OPEN            */;
	bds_bind(VV[11],VALUES(0));               /*  *COMPILER-OUTPUT2**/
	goto L393;
L395:
	bds_bind(VV[11],(V6));                    /*  *COMPILER-OUTPUT2**/
L393:
	if(((V3))==Cnil){
	goto L399;}
	(*LK2)(3,(V3),VV[35],VV[36])              /*  OPEN            */;
	bds_bind(VV[12],VALUES(0));               /*  *COMPILER-OUTPUT-DATA**/
	goto L397;
L399:
	bds_bind(VV[12],(V6));                    /*  *COMPILER-OUTPUT-DATA**/
L397:
	bds_bind(VV[20],MAKE_FIXNUM(0));          /*  *ERROR-COUNT*   */
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(symbol_function(VV[74]),env0));/*  T3LOCAL-FUN*/
	CLV1=&CAR(env0=CONS(getf(VV[50]->s.s_plist,VV[75],Cnil),env0));/*  T3FUN*/
	{ int V7; bool unwinding = FALSE;
	if ((V7=frs_push(FRS_PROTECT,Cnil))) {
	V7--; unwinding = TRUE;} else {
	VALUES(0) = make_cclosure(LC4,env0,&Cblock);
	putprop(VV[50],VALUES(0),VV[75]);
	VALUES(0) = make_cclosure(LC5,env0,&Cblock);
	siLfset(2,VV[74],VALUES(0))               /*  FSET            */;
	(*LK0)(0)                                 /*  INIT-ENV        */;
	if(((V3))==Cnil){
	goto L409;}
	(*LK3)(0)                                 /*  WT-DATA-BEGIN   */;
L409:
	(*LK4)(1,(V5))                            /*  T1EXPR          */;
	if(!(number_compare(MAKE_FIXNUM(0),(VV[20]->s.s_dbind))==0)){
	goto L415;}
	{ int V8;
	if ((V8=frs_push(FRS_CATCH,VV[76]))==0) {
	V8=(*LK7)(1,VV[77])                       /*  CTOP-WRITE      */;
	}
	else V8--;
	frs_pop();
	goto L413;}
L415:
	(VV[13]->s.s_dbind)= Ct;
L413:
	if(((V3))==Cnil){
	goto L421;}
	V7=(*LK5)(0)                              /*  WT-DATA-END     */;
	goto L403;
L421:
	VALUES(0)=Cnil;
	V7=1;
L403:
	}
	frs_pop();
	MV_SAVE(V7);
	putprop(VV[50],*CLV1,VV[75]);
	siLfset(2,VV[74],*CLV0)                   /*  FSET            */;
	if(((V2))==Cnil){
	goto L426;}
	Lclose(1,(VV[11]->s.s_dbind))             /*  CLOSE           */;
L426:
	if(((V3))==Cnil){
	goto L423;}
	Lclose(1,(VV[12]->s.s_dbind))             /*  CLOSE           */;
L423:
	MV_RESTORE(V7);
	if (unwinding) unwind(nlj_fr,nlj_tag,V7+1);
	else {
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;}}
	}
	bds_unwind1;
	bds_unwind1;
	RETURN(0);
	}
	}
}
/*	closure CLOSURE                                               */
static LC4(int narg, object env0, ...)
{ VT6 VLEX6 CLSR6
	narg--;
	{object scan=env0;
	CLV1= &CAR(scan);                         /*  T3FUN           */}
	{object V1;
	va_list args; va_start(args, env0);
	narg -=0;
	V1=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V1;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	bds_bind(VV[10],(VV[16]->s.s_dbind));     /*  *COMPILER-OUTPUT1**/
	{int V2;
	V2=Lapply(2,*CLV1,(V1))                   /*  APPLY           */;
	bds_unwind1;
	RETURN(V2);}
	}
}
/*	closure CLOSURE                                               */
static LC5(int narg, object env0, ...)
{ VT7 VLEX7 CLSR7
	narg--;
	{object scan=env0; scan=CDR(scan);
	CLV0= &CAR(scan);                         /*  T3LOCAL-FUN     */}
	{object V1;
	va_list args; va_start(args, env0);
	narg -=0;
	V1=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V1;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	bds_bind(VV[10],(VV[16]->s.s_dbind));     /*  *COMPILER-OUTPUT1**/
	{int V2;
	V2=Lapply(2,*CLV0,(V1))                   /*  APPLY           */;
	bds_unwind1;
	RETURN(V2);}
	}
}
/*	function definition for COMPILER-PASS2                        */
static L6(int narg, object V1, object V2, object V3, object V4)
{ VT8 VLEX8 CLSR8
	bds_check;
TTL:
	{VOL object V5;
	(*LK2)(3,(V1),VV[35],VV[36])              /*  OPEN            */;
	V5= VALUES(0);
	bds_bind(VV[10],V5);                      /*  *COMPILER-OUTPUT1**/
	{ int V6; bool unwinding = FALSE;
	if ((V6=frs_push(FRS_PROTECT,Cnil))) {
	V6--; unwinding = TRUE;} else {
	{VOL object V7;
	(*LK2)(3,(V2),VV[35],VV[36])              /*  OPEN            */;
	V7= VALUES(0);
	bds_bind(VV[11],V7);                      /*  *COMPILER-OUTPUT2**/
	{ int V8; bool unwinding = FALSE;
	if ((V8=frs_push(FRS_PROTECT,Cnil))) {
	V8--; unwinding = TRUE;} else {
	if(((V3))==Cnil){
	goto L435;}
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	princ_str("/* (c) Copyright G. Attardi, 1993. */",symbol_value(VV[10]));
	princ_char(10,symbol_value(VV[11]));
	princ_str("/* (c) Copyright G. Attardi, 1993. */",symbol_value(VV[11]));
L435:
	if(((V3))!=Cnil){
	goto L445;}
	Lwrite_bytes(4,(VV[11]->s.s_dbind),VV[78],MAKE_FIXNUM(0),MAKE_FIXNUM((VV[78])->v.v_fillp))/*  WRITE-BYTES*/;
	goto L443;
L445:
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	princ_str("#include ",symbol_value(VV[10]));
	(*LK8)(1,(VV[1]->s.s_dbind))              /*  WT1             */;
L443:
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	princ_str("#include \"",symbol_value(VV[10]));
	(*LK8)(1,coerce_to_namestring((V2)))      /*  WT1             */;
	princ_char(34,symbol_value(VV[10]));
	{ int V9;
	if ((V9=frs_push(FRS_CATCH,VV[76]))==0) {
	V9=(*LK7)(2,(V4),(V3))                    /*  CTOP-WRITE      */;
	}
	else V9--;
	frs_pop();}
	princ_char(10,symbol_value(VV[10]));
	VALUES(0)=terpri((VV[11]->s.s_dbind));
	V8=1;
	}
	frs_pop();
	MV_SAVE(V8);
	Lclose(1,(VV[11]->s.s_dbind))             /*  CLOSE           */;
	MV_RESTORE(V8);
	if (unwinding) unwind(nlj_fr,nlj_tag,V8+1);
	else {
	V6=V8;
	bds_unwind1;}}
	}
	}
	frs_pop();
	MV_SAVE(V6);
	Lclose(1,(VV[10]->s.s_dbind))             /*  CLOSE           */;
	MV_RESTORE(V6);
	if (unwinding) unwind(nlj_fr,nlj_tag,V6+1);
	else {
	bds_unwind1;
	RETURN(V6);}}
	}
}
/*	function definition for COMPILER-CC                           */
static L7(int narg, object V1, object V2)
{ VT9 VLEX9 CLSR9
TTL:
	{object V3= (VV[80]->s.s_dbind);
	{object V4= (VV[5]->s.s_dbind);
	{object V5= (number_compare((VV[81]->s.s_dbind),MAKE_FIXNUM(2))>=0?Ct:Cnil);
	{object V6= (VV[7]->s.s_dbind);
	{object V7= coerce_to_namestring((V1));
	Lformat(7,Cnil,V3,V4,V5,V6,V7,coerce_to_namestring((V2)))/*  FORMAT*/;
	RETURN(LC8(1,VALUES(0))                   /*  SAFE-SYSTEM     */);}}}}}
}
/*	local function SAFE-SYSTEM                                    */
static LC8(int narg, object V1)
{ VT10 VLEX10 CLSR10
TTL:
	{object V2;                               /*  RESULT          */
	Lsystem(1,(V1))                           /*  SYSTEM          */;
	V2= VALUES(0);
	if(number_compare(MAKE_FIXNUM(0),(V2))==0){
	goto L463;}
	Lcerror(4,VV[82],VV[83],(V1),(V2))        /*  CERROR          */;
	(VV[13]->s.s_dbind)= Ct;
L463:
	VALUES(0) = (V2);
	RETURN(1);
	}
}
/*	function definition for CAT-DATA-FILE                         */
static L9(int narg, object V1, object V2)
{ VT11 VLEX11 CLSR11
TTL:
	{VOL object V3;                           /*  O-FILE          */
	(*LK2)(5,coerce_to_namestring((V1)),VV[35],VV[36],VV[84],VV[85])/*  OPEN*/;
	V3= VALUES(0);
	{ int V4; bool unwinding = FALSE;
	if ((V4=frs_push(FRS_PROTECT,Cnil))) {
	V4--; unwinding = TRUE;} else {
	{VOL object V5;                           /*  DATA-FILE       */
	(*LK2)(1,coerce_to_namestring((V2)))      /*  OPEN            */;
	V5= VALUES(0);
	{ int V6; bool unwinding = FALSE;
	if ((V6=frs_push(FRS_PROTECT,Cnil))) {
	V6--; unwinding = TRUE;} else {
	{object V7;                               /*  BUFFER          */
	int V8;                                   /*  N               */
	Lmake_string(1,MAKE_FIXNUM(256))          /*  MAKE-STRING     */;
	V7= VALUES(0);
	V8= 0;
L475:
	Lread_bytes(4,(V5),(V7),MAKE_FIXNUM(0),MAKE_FIXNUM(256))/*  READ-BYTES*/;
	V8= fix(VALUES(0));
	if(!((V8)==0)){
	goto L476;}
	VALUES(0)=Cnil;
	V6=1;
	goto L471;
L476:
	Lwrite_bytes(4,(V3),(V7),MAKE_FIXNUM(0),MAKE_FIXNUM(V8))/*  WRITE-BYTES*/;
	goto L475;
	}
L471:
	}
	frs_pop();
	MV_SAVE(V6);
	Lclose(1,(V5))                            /*  CLOSE           */;
	MV_RESTORE(V6);
	if (unwinding) unwind(nlj_fr,nlj_tag,V6+1);
	else {
	V4=V6;}}
	}
	}
	frs_pop();
	MV_SAVE(V4);
	Lclose(1,(V3))                            /*  CLOSE           */;
	MV_RESTORE(V4);
	if (unwinding) unwind(nlj_fr,nlj_tag,V4+1);
	else {
	RETURN(V4);}}
	}
}
/*	function definition for PRINT-COMPILER-INFO                   */
static L10(int narg)
{ VT12 VLEX12 CLSR12
TTL:
	if(((VV[87]->s.s_dbind))!=Cnil){
	goto L487;}
	VALUES(0) = MAKE_FIXNUM(0);
	goto L485;
L487:
	if(((VV[88]->s.s_dbind))!=Cnil){
	goto L490;}
	VALUES(0) = MAKE_FIXNUM(1);
	goto L485;
L490:
	if(((VV[89]->s.s_dbind))!=Cnil){
	goto L493;}
	VALUES(0) = MAKE_FIXNUM(2);
	goto L485;
L493:
	VALUES(0) = MAKE_FIXNUM(3);
L485:
	RETURN(Lformat(6,Ct,VV[86],VALUES(0),(VV[88]->s.s_dbind),(VV[90]->s.s_dbind),(VV[81]->s.s_dbind))/*  FORMAT*/);
}
static LKF8(int narg, ...) {TRAMPOLINK(VV[112],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[111],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[95],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[110],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[109],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[108],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[107],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[106],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[105],&LK0);}
