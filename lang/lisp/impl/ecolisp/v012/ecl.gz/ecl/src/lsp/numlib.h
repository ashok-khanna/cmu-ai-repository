
/* (c) Copyright G. Attardi, 1993. */
int siLAmake_constant();
int siLfset();
#define VT2
#define VLEX2
#define CLSR2
static L1(int, object);
int Lerror();
int Linteger_length();
int Lceiling();
int Lash();
int Lfloor();
int Lfloor();
#define VT3
#define VLEX3
#define CLSR3
static L2(int, object);
int Lcomplexp();
int Lrealpart();
int Lrealpart();
int Limagpart();
int Limagpart();
int Lsqrt();
#define VT4 object T0,T1;
#define VLEX4
#define CLSR4
static L3(int, object);
int Limagpart();
int Lrealpart();
int Latan();
#define VT5 object T0;
#define VLEX5
#define CLSR5
static L4(int, object);
#define VT6
#define VLEX6
#define CLSR6
static L5(int, object);
int Lexp();
#define VT7
#define VLEX7
#define CLSR7
static L6(int, object);
int Lsqrt();
int Llog();
int Lcomplexp();
int Limagpart();
int Lrealpart();
#define VT8
#define VLEX8
#define CLSR8
static L7(int, object);
int Lsqrt();
int Llog();
int Lcomplexp();
int Limagpart();
int Lrealpart();
#define VT9
#define VLEX9
#define CLSR9
static L8(int, object);
int Lexp();
int Lexp();
#define VT10 object T0;
#define VLEX10
#define CLSR10
static L9(int, object);
int Lexp();
int Lexp();
#define VT11 object T0;
#define VLEX11
#define CLSR11
static L10(int, object);
#define VT12 object T0;
#define VLEX12
#define CLSR12
static L11(int, object);
int Lsqrt();
int Llog();
#define VT13
#define VLEX13
#define CLSR13
static L12(int, object);
int Lsqrt();
int Lsqrt();
int Llog();
#define VT14 object T0;
#define VLEX14
#define CLSR14
static L13(int, object);
int Llog();
int Llog();
#define VT15 object T0;
#define VLEX15
#define CLSR15
static L14(int, object);
int Linteger_decode_float();
int Lfloat_radix();
int Lfloat_radix();
int Lerror();
#define VT16
#define VLEX16
#define CLSR16
static L15(int, object, ...);
int Lfloat();
int Lfloat();
int Lfloor();
int Lfloat();
#define VT17 object T0;
#define VLEX17
#define CLSR17
static L16(int, object, ...);
int Lfloat();
int Lfloat();
int Lceiling();
int Lfloat();
#define VT18 object T0;
#define VLEX18
#define CLSR18
static L17(int, object, ...);
int Lfloat();
int Lfloat();
int Ltruncate();
int Lfloat();
#define VT19 object T0;
#define VLEX19
#define CLSR19
static L18(int, object, ...);
int Lfloat();
int Lfloat();
int Lround();
int Lfloat();
#define VT20 object T0;
#define VLEX20
#define CLSR20
static L19(int, object, object);
#define VT21
#define VLEX21
#define CLSR21
static L20(int, object, object);
#define VT22
#define VLEX22
#define CLSR22
static L21(int, object, object);
#define VT23
#define VLEX23
#define CLSR23
static L22(int, object, object);
#define VT24
#define VLEX24
#define CLSR24
static L23(int, object, object);
#define VT25
#define VLEX25
#define CLSR25
static L24(int, object, object);
#define VT26
#define VLEX26
#define CLSR26
static L25(int, object);
int Llogxor();
#define VT27
#define VLEX27
#define CLSR27
static L26(int, object, object);
int Llogand();
#define VT28
#define VLEX28
#define CLSR28
static L27(int, object, object);
#define VT29
#define VLEX29
#define CLSR29
static L28(int, object);
#define VT30
#define VLEX30
#define CLSR30
static L29(int, object);
#define VT31
#define VLEX31
#define CLSR31
static L30(int, object, object);
int Lash();
int Lash();
#define VT32 object T0;
#define VLEX32
#define CLSR32
static L31(int, object, object);
#define VT33
#define VLEX33
#define CLSR33
static L32(int, object, object);
int Lash();
#define VT34 object T0;
#define VLEX34
#define CLSR34
static L33(int, object, object, object);
int Lash();
int Lash();
int Llogxor();
#define VT35 object T0,T1;
#define VLEX35
#define CLSR35
static L34(int, object, object, object);
int Lash();
#define VT36
#define VLEX36
#define CLSR36
static struct codeblock Cblock;
#define VM36 0
#define VM35 2
#define VM34 1
#define VM33 0
#define VM32 1
#define VM31 0
#define VM30 0
#define VM29 0
#define VM28 0
#define VM27 0
#define VM26 0
#define VM25 0
#define VM24 0
#define VM23 0
#define VM22 0
#define VM21 0
#define VM20 1
#define VM19 1
#define VM18 1
#define VM17 1
#define VM16 0
#define VM15 1
#define VM14 1
#define VM13 0
#define VM12 1
#define VM11 1
#define VM10 1
#define VM9 0
#define VM8 0
#define VM7 0
#define VM6 0
#define VM5 1
#define VM4 2
#define VM3 0
#define VM2 0
#define VM1 49
static object VV[49];
static LKF0(int, ...);
static (*LK0)(int, ...)=LKF0;
static LKF1(int, ...);
static (*LK1)(int, ...)=LKF1;
