
#include "kernel.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	siLAmake_constant(2,VV[0],MAKE_FIXNUM(64))/*  *MAKE-CONSTANT  */;
	putprop(VV[0],VV[1],VV[2]);
	MF0(VV[32],L1);
	(void)putprop(VV[32],VV[Vdeb32],VV[33]);
	MF0(VV[34],L2);
	(void)putprop(VV[34],VV[Vdeb34],VV[33]);
	MF0(VV[35],L3);
	(void)putprop(VV[35],VV[Vdeb35],VV[33]);
	MF0(VV[36],L4);
	(void)putprop(VV[36],VV[Vdeb36],VV[33]);
	MF0(VV[37],L5);
	(void)putprop(VV[37],VV[Vdeb37],VV[33]);
	MF0(VV[38],L6);
	(void)putprop(VV[38],VV[Vdeb38],VV[33]);
	MF0(VV[39],L7);
	(void)putprop(VV[39],VV[Vdeb39],VV[33]);
	MF0(VV[40],L8);
	(void)putprop(VV[40],VV[Vdeb40],VV[33]);
	MF0(VV[41],L9);
	(void)putprop(VV[41],VV[Vdeb41],VV[33]);
	MF0(VV[42],L10);
	(void)putprop(VV[42],VV[Vdeb42],VV[33]);
	MF0(VV[43],L11);
	(void)putprop(VV[43],VV[Vdeb43],VV[33]);
	VV[44] = make_cfun(LC13,Cnil,&Cblock);
	MF0(VV[45],L12);
	(void)putprop(VV[45],VV[Vdeb45],VV[33]);
	MF0key(VV[46],L14,1,L14keys);
	(void)putprop(VV[46],VV[Vdeb46],VV[33]);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	local function CLOSURE                                        */
static LC13(int narg, object V1)
{ VT3 VLEX3 CLSR3
	{register object x= (V1),V2= VV[25];
	while(V2!=Cnil)
	if(eql(x, CAR(V2))){
	VALUES(0) = V2;
	RETURN(1);
	}else V2=CDR(V2);
	VALUES(0) = Cnil;
	RETURN(1);}
}
/*	function definition for CLASS-OF                              */
static L1(int narg, object V1)
{ VT4 VLEX4 CLSR4
TTL:
	siLinstancep(1,(V1))                      /*  INSTANCEP       */;
	if(VALUES(0)==Cnil){
	goto L5;}
	RETURN(siLinstance_class(1,(V1))          /*  INSTANCE-CLASS  */);
L5:
	{register object V2;
	V2= (V1);
	(*LK0)(2,(V2),VV[3])                      /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L8;}
	RETURN((*LK1)(1,VV[3])                    /*  FIND-CLASS      */);
L8:
	(*LK0)(2,(V2),VV[4])                      /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L11;}
	RETURN((*LK1)(1,VV[4])                    /*  FIND-CLASS      */);
L11:
	(*LK0)(2,(V2),VV[5])                      /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L14;}
	RETURN((*LK1)(1,VV[5])                    /*  FIND-CLASS      */);
L14:
	(*LK0)(2,(V2),VV[6])                      /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L17;}
	RETURN((*LK1)(1,VV[6])                    /*  FIND-CLASS      */);
L17:
	(*LK0)(2,(V2),VV[7])                      /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L20;}
	RETURN((*LK1)(1,VV[7])                    /*  FIND-CLASS      */);
L20:
	(*LK0)(2,(V2),VV[8])                      /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L23;}
	RETURN((*LK1)(1,VV[8])                    /*  FIND-CLASS      */);
L23:
	(*LK0)(2,(V2),VV[9])                      /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L26;}
	RETURN((*LK1)(1,VV[9])                    /*  FIND-CLASS      */);
L26:
	(*LK0)(2,(V2),VV[10])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L29;}
	RETURN((*LK1)(1,VV[10])                   /*  FIND-CLASS      */);
L29:
	(*LK0)(2,(V2),VV[11])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L32;}
	RETURN((*LK1)(1,VV[11])                   /*  FIND-CLASS      */);
L32:
	(*LK0)(2,(V2),VV[12])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L35;}
	RETURN((*LK1)(1,VV[12])                   /*  FIND-CLASS      */);
L35:
	(*LK0)(2,(V2),VV[13])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L38;}
	RETURN((*LK1)(1,VV[13])                   /*  FIND-CLASS      */);
L38:
	(*LK0)(2,(V2),VV[14])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L41;}
	RETURN((*LK1)(1,VV[14])                   /*  FIND-CLASS      */);
L41:
	(*LK0)(2,(V2),VV[15])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L44;}
	RETURN((*LK1)(1,VV[15])                   /*  FIND-CLASS      */);
L44:
	(*LK0)(2,(V2),VV[16])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L47;}
	RETURN((*LK1)(1,VV[16])                   /*  FIND-CLASS      */);
L47:
	(*LK0)(2,(V2),VV[17])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L50;}
	RETURN((*LK1)(1,VV[17])                   /*  FIND-CLASS      */);
L50:
	(*LK0)(2,(V2),VV[18])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L53;}
	RETURN((*LK1)(1,VV[18])                   /*  FIND-CLASS      */);
L53:
	(*LK0)(2,(V2),VV[19])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L56;}
	RETURN((*LK1)(1,VV[19])                   /*  FIND-CLASS      */);
L56:
	RETURN((*LK1)(1,Ct)                       /*  FIND-CLASS      */);
	}
}
/*	function definition for CLOSEST-CLASS                         */
static L2(int narg, object V1)
{ VT5 VLEX5 CLSR5
TTL:
	(*LK1)(2,(V1),Cnil)                       /*  FIND-CLASS      */;
	if(VALUES(0)==Cnil)goto L58;
	RETURN(1);
L58:
	if(((V1)!= VV[50])
	&& ((V1)!= VV[51]))goto L60;
	RETURN((*LK1)(1,VV[14])                   /*  FIND-CLASS      */);
L60:
	if(((V1)!= VV[52])
	&& ((V1)!= VV[53]))goto L61;
	RETURN((*LK1)(1,VV[17])                   /*  FIND-CLASS      */);
L61:
	if(((V1)!= VV[54])
	&& ((V1)!= VV[55]))goto L62;
	RETURN((*LK1)(1,VV[13])                   /*  FIND-CLASS      */);
L62:
	if(((V1)!= VV[56]))goto L63;
	RETURN((*LK1)(1,VV[12])                   /*  FIND-CLASS      */);
L63:
	if(((V1)!= VV[57]))goto L64;
	RETURN((*LK1)(1,VV[10])                   /*  FIND-CLASS      */);
L64:
	if(((V1)!= VV[58]))goto L65;
	RETURN((*LK1)(1,VV[9])                    /*  FIND-CLASS      */);
L65:
	if(((V1)!= VV[59]))goto L66;
	RETURN((*LK1)(1,VV[8])                    /*  FIND-CLASS      */);
L66:
	if(((V1)== VV[60])
	|| ((V1)== VV[61])
	|| ((V1)== VV[62])
	|| ((V1)== VV[63])
	|| ((V1)== VV[64]))goto L68;
	if(((V1)!= VV[65])
	&& ((V1)!= VV[66])
	&& ((V1)!= VV[67])
	&& ((V1)!= VV[68])
	&& ((V1)!= VV[69]))goto L67;
L68:
	RETURN((*LK1)(1,Ct)                       /*  FIND-CLASS      */);
L67:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for SEARCH-MAKE-INSTANCE                  */
static L3(int narg, object V1)
{ VT6 VLEX6 CLSR6
TTL:
	{object V2;                               /*  GFUN            */
	object V3;                                /*  TABLE           */
	object V4;                                /*  KEY             */
	object V5;                                /*  METHOD          */
	(*LK2)(1,VV[20])                          /*  TRACING-BODY    */;
	if(VALUES(0)==Cnil){
	goto L72;}
	VALUES(0) = getf(VV[20]->s.s_plist,VV[21],Cnil);
	goto L70;
L72:
	VALUES(0) = VV[20];
L70:
	V2= symbol_function(VALUES(0));
	siLgfun_method_ht(1,(V2))                 /*  GFUN-METHOD-HT  */;
	V3= VALUES(0);
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	V4= CONS((VALUES(0))->in.in_slots[0],Cnil);
	(*LK3)(2,(V4),(V3))                       /*  METHOD-HT-GET   */;
	V5= VALUES(0);
	if(((V5))!=Cnil){
	goto L78;}
	siLgfun_instance(1,(V2))                  /*  GFUN-INSTANCE   */;
	T0= VALUES(0);
	(*LK4)(2,T0,CONS((V1),Cnil))              /*  COMPUTE-APPLICABLE-METHODS*/;
	V5= VALUES(0);
L78:
	VALUES(0) = (V5);
	RETURN(1);
	}
}
/*	function definition for CLASSP                                */
static L4(int narg, object V1)
{ VT7 VLEX7 CLSR7
TTL:
	siLinstancep(1,(V1))                      /*  INSTANCEP       */;
	if(VALUES(0)!=Cnil){
	goto L83;}
	VALUES(0) = Cnil;
	RETURN(1);
L83:
	L3(1,(V1))                                /*  SEARCH-MAKE-INSTANCE*/;
	if(VALUES(0)!=Cnil){
	goto L85;}
	VALUES(0) = Cnil;
	RETURN(1);
L85:
	VALUES(0) = Ct;
	RETURN(1);
}
/*	function definition for METACLASSP                            */
static L5(int narg, object V1)
{ VT8 VLEX8 CLSR8
TTL:
	siLinstancep(1,(V1))                      /*  INSTANCEP       */;
	if(VALUES(0)!=Cnil){
	goto L87;}
	VALUES(0) = Cnil;
	RETURN(1);
L87:
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	L3(1,VALUES(0))                           /*  SEARCH-MAKE-INSTANCE*/;
	if(VALUES(0)!=Cnil){
	goto L89;}
	VALUES(0) = Cnil;
	RETURN(1);
L89:
	L3(1,(V1))                                /*  SEARCH-MAKE-INSTANCE*/;
	if(VALUES(0)!=Cnil){
	goto L92;}
	VALUES(0) = Cnil;
	RETURN(1);
L92:
	VALUES(0) = Ct;
	RETURN(1);
}
/*	function definition for ALLOCATE-INSTANCE                     */
static L6(int narg, object V1)
{ VT9 VLEX9 CLSR9
TTL:
	RETURN(siLallocate_instance(2,(V1),MAKE_FIXNUM(length(((V1))->in.in_slots[3])))/*  ALLOCATE-INSTANCE*/);
}
/*	function definition for INITIALIZE-FROM-INITFORMS             */
static L7(int narg, object V1)
{ VT10 VLEX10 CLSR10
TTL:
	{register object V2;                      /*  SCAN            */
	register object V3;                       /*  I               */
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	V2= (VALUES(0))->in.in_slots[3];
	V3= MAKE_FIXNUM(0);
L97:
	if(((V2))!=Cnil){
	goto L98;}
	VALUES(0) = (V1);
	RETURN(1);
L98:
	siLinstance_ref(2,(V1),(V3))              /*  INSTANCE-REF    */;
	if((VALUES(0))!=OBJNULL){
	goto L101;}
	{object V5= CDR(CDR(CAR((V2))));
	VALUES(0) = CAR(V5);}
	if((VALUES(0))==(VV[22])){
	goto L101;}
	{object V5= CDR(CDR(CAR((V2))));
	VALUES(0) = CAR(V5);}
	Leval(1,VALUES(0))                        /*  EVAL            */;
	siLinstance_set(3,(V1),(V3),VALUES(0))    /*  INSTANCE-SET    */;
L101:
	V2= CDR((V2));
	V3= one_plus((V3));
	goto L97;
	}
}
/*	function definition for INITIALIZE-FROM-INITARGS              */
static L8(int narg, object V1, object V2)
{ VT11 VLEX11 CLSR11
TTL:
	{object V3;                               /*  CLASS-SLOTS     */
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	V3= (VALUES(0))->in.in_slots[3];
	{register object V4;                      /*  NAME-LOC        */
	object V5;                                /*  NAME            */
	V4= (V2);
	V5= CAR((V4));
L119:
	if(((V4))!=Cnil){
	goto L120;}
	VALUES(0) = (V1);
	RETURN(1);
L120:
	{register object V7;                      /*  SCAN-SLOT       */
	register int V8;                          /*  INDEX           */
	V8= 0;
	V7= (V3);
L126:
	if(((V7))!=Cnil){
	goto L127;}
	goto L123;
L127:
	{object V10= CDR(CAR((V7)));
	VALUES(0) = CAR(V10);}
	{register object x= (V5),V10= VALUES(0);
	while(V10!=Cnil)
	if(eql(x, CAR(V10))){
	goto L132;
	}else V10=CDR(V10);
	goto L130;}
L132:
	siLinstance_set(3,(V1),MAKE_FIXNUM(V8),CADR((V4)))/*  INSTANCE-SET*/;
L130:
	V7= CDR((V7));
	V8= (V8)+1;
	goto L126;
	}
L123:
	V4= CDDR((V4));
	V5= CAR((V4));
	goto L119;
	}
	}
}
/*	function definition for INSTALL-METHOD                        */
static L9(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, ...)
{ VT12 VLEX12 CLSR12
	{object V8;
	va_list args; va_start(args, V7);
	narg -=7;
	V8=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V8;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{register object V9;                      /*  GF              */
	object V10;                               /*  METHOD          */
	register object V11;                      /*  DISPATCHER      */
	(*LK5)(3,(V1),VV[23],(V4))                /*  ENSURE-GENERIC-FUNCTION*/;
	V9= VALUES(0);
	(*LK6)(1,(V9))                            /*  METHOD-CLASS    */;
	(*LK7)(8,(V2),(V3),(V4),(V7),(V6),(V8),(V9),VALUES(0))/*  MAKE-METHOD*/;
	V10= VALUES(0);
	(*LK8)(1,(V9))                            /*  GENERIC-FUNCTION-DISPATCHER*/;
	V11= VALUES(0);
	{register int V12;                        /*  I               */
	register object V13;                      /*  L               */
	register object V14;                      /*  SPEC-HOW        */
	register object V15;                      /*  SPEC-HOW-OLD    */
	V12= 0;
	V13= (V3);
	V14= Cnil;
	V15= Cnil;
L150:
	if(((V13))!=Cnil){
	goto L151;}
	goto L147;
L151:
	V14= CAR((V13));
	siLgfun_spec_how_ref(2,(V11),MAKE_FIXNUM(V12))/*  GFUN-SPEC-HOW-REF*/;
	V15= VALUES(0);
	if(!(type_of((V14))==t_cons)){
	goto L160;}
	if(!(type_of((V15))==t_cons)){
	goto L163;}
	{int V17;
	V17= V12;
	{object V18= CADR((V14));
	siLgfun_spec_how_ref(2,(V11),MAKE_FIXNUM(V17))/*  GFUN-SPEC-HOW-REF*/;
	siLgfun_spec_how_set(3,(V11),MAKE_FIXNUM(V17),CONS(V18,VALUES(0)))/*  GFUN-SPEC-HOW-SET*/;
	goto L158;}
	}
L163:
	siLgfun_spec_how_set(3,(V11),MAKE_FIXNUM(V12),CDR((V14)))/*  GFUN-SPEC-HOW-SET*/;
	goto L158;
L160:
	if(type_of((V15))==t_cons){
	goto L158;}
	if((V14)!=Cnil){
	VALUES(0) = (V14);
	goto L169;}
	VALUES(0) = (V15);
L169:
	siLgfun_spec_how_set(3,(V11),MAKE_FIXNUM(V12),VALUES(0))/*  GFUN-SPEC-HOW-SET*/;
L158:
	V12= (V12)+1;
	V13= CDR((V13));
	goto L150;
	}
L147:
	RETURN((*LK9)(2,(V9),(V10))               /*  ADD-METHOD      */);
	}
	}
}
/*	function definition for METHOD-CLASS                          */
static L10(int narg, object V1)
{ VT13 VLEX13 CLSR13
TTL:
	VALUES(0) = VV[24];
	RETURN(1);
}
/*	function definition for METHODS                               */
static L11(int narg, object V1)
{ VT14 VLEX14 CLSR14
TTL:
	VALUES(0) = ((V1))->in.in_slots[7];
	RETURN(1);
}
/*	function definition for MAKE-GFUN                             */
static L12(int narg, object V1, object V2)
{ VT15 VLEX15 CLSR15
TTL:
	{int V3;                                  /*  NARGS           */
	object V4;                                /*  GFUN            */
	VALUES(0) = VV[44];
	(*LK10)(2,VALUES(0),(V2))                 /*  POSITION-IF     */;
	if(VALUES(0)==Cnil)goto L175;
	V3= fix(VALUES(0));
	goto L174;
L175:
	V3= length((V2));
L174:
	VALUES(0) = (VV[87]->s.s_gfdef);
	Lmake_hash_table(8,VV[26],VALUES(0),VV[27],MAKE_FIXNUM(64),VV[28],MAKE_FIXNUM(32),VV[29],MAKE_FIXNUM(32))/*  MAKE-HASH-TABLE*/;
	siLallocate_gfun(3,(V1),MAKE_FIXNUM(V3),VALUES(0))/*  ALLOCATE-GFUN*/;
	V4= VALUES(0);
	{object V5;
	register int V6;                          /*  I               */
	V5= MAKE_FIXNUM(V3);
	V6= 0;
L185:
	if(!((V6)>=(fix((V5))))){
	goto L186;}
	goto L181;
L186:
	siLgfun_spec_how_set(3,(V4),MAKE_FIXNUM(V6),Cnil)/*  GFUN-SPEC-HOW-SET*/;
	V6= (V6)+1;
	goto L185;
	}
L181:
	VALUES(0) = (V4);
	RETURN(1);
	}
}
/*	function definition for ENSURE-GENERIC-FUNCTION               */
static L14(int narg, object V1, ...)
{ VT16 VLEX16 CLSR16
	{object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[2];
	parse_key(narg,args,1,L14keys,keyvars,OBJNULL,FALSE);
	V2= keyvars[0];
	}
	{register object V3;                      /*  GFUN            */
	V3= Cnil;
	Lfboundp(1,(V1))                          /*  FBOUNDP         */;
	if(VALUES(0)==Cnil){
	goto L194;}
	V3= symbol_function((V1));
	siLgfunp(1,(V3))                          /*  GFUNP           */;
	if(VALUES(0)!=Cnil){
	goto L193;}
L194:
	{register object V4;                      /*  GF-OBJECT       */
	(*LK1)(1,Ct)                              /*  FIND-CLASS      */;
	siLallocate_instance(2,VALUES(0),MAKE_FIXNUM(8))/*  ALLOCATE-INSTANCE*/;
	V4= VALUES(0);
	L12(2,(V1),(V2))                          /*  MAKE-GFUN       */;
	V3= VALUES(0);
	((V4))->in.in_slots[0]=((V2));
	((V4))->in.in_slots[1]=(VV[30]);
	((V4))->in.in_slots[2]=(VV[31]);
	((V4))->in.in_slots[3]=(Cnil);
	((V4))->in.in_slots[5]=(Cnil);
	((V4))->in.in_slots[6]=((V3));
	((V4))->in.in_slots[7]=(Cnil);
	siLgfun_instance_set(2,(V3),(V4))         /*  GFUN-INSTANCE-SET*/;
	siLfset(2,(V1),(V3))                      /*  FSET            */;
	}
L193:
	RETURN(siLgfun_instance(1,(V3))           /*  GFUN-INSTANCE   */);
	}
	}
}
static LKF10(int narg, ...) {TRAMPOLINK(VV[86],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[82],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[81],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[80],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[42],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[46],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[73],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[72],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[71],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[48],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[47],&LK0);}
