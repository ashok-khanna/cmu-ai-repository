
/* (c) Copyright G. Attardi, 1993. */
#define VT2
#define VLEX2
#define CLSR2
static L1(int, object, ...);
#define VT3 object T0;
#define VLEX3
#define CLSR3
static L2(int, object);
int Lintern();
#define VT4 object T0;
#define VLEX4
#define CLSR4
static L3(int, object, object, object, object, ...);
#define VT5
#define VLEX5
#define CLSR5
static L4(int, object, object, object, object);
#define VT6
#define VLEX6 register object lex0[2];
#define CLSR6
static LC6(object *,int, object );
#define VT7
#define VLEX7
#define CLSR7
static LC5(object *,int, object );
#define VT8
#define VLEX8
#define CLSR8
static L7(int, object, object, object, object, object);
int Lfifth();
int Lsixth();
int Lformat();
#define VT9
#define VLEX9 register object lex0[2];
#define CLSR9
static LC9(object *,int, object );
#define VT10
#define VLEX10
#define CLSR10
static LC8(object *,int, object );
#define VT11
#define VLEX11
#define CLSR11
static L10(int, object);
#define VT12
#define VLEX12
#define CLSR12
static L11(int, object, object, object);
int Lldiff();
#define VT13 object T0;
#define VLEX13 register object lex0[3];
#define CLSR13
static LC13(object *,int, object , object , object , object );
#define VT14
#define VLEX14
#define CLSR14
static LC12(object *,int, object , object , object , object );
int Lintern();
int Lintern();
#define VT15 object T0;
#define VLEX15
#define CLSR15
static L14(int, object);
#define VT16
#define VLEX16
#define CLSR16
static L15(int, object, object, object, object, object);
#define VT17
#define VLEX17 register object lex0[1];
#define CLSR17
static LC19(object *,int, object );
#define VT18
#define VLEX18
#define CLSR18
static LC18(object *,int, object , object );
#define VT19
#define VLEX19
#define CLSR19
static LC16(object *,int, object );
#define VT20
#define VLEX20
#define CLSR20
static LC20(object *,int, object , object );
int Lfifth();
int Lsixth();
int Lseventh();
#define VT21
#define VLEX21
#define CLSR21
static LC17(object *,int, object );
int Lfifth();
int Lseventh();
#define VT22
#define VLEX22
#define CLSR22
static struct codeblock Cblock;
#define VM22 0
#define VM21 0
#define VM20 0
#define VM19 0
#define VM18 0
#define VM17 0
#define VM16 0
#define VM15 1
#define VM14 0
#define VM13 1
#define VM12 0
#define VM11 0
#define VM10 0
#define VM9 0
#define VM8 0
#define VM7 0
#define VM6 0
#define VM5 0
#define VM4 1
#define VM3 1
#define VM2 0
#define VM1 90
static object VV[90];
static LKF0(int, ...);
static (*LK0)(int, ...)=LKF0;
static LKF1(int, ...);
static (*LK1)(int, ...)=LKF1;
static LKF2(int, ...);
static (*LK2)(int, ...)=LKF2;
static LKF3(int, ...);
static (*LK3)(int, ...)=LKF3;
static LKF4(int, ...);
static (*LK4)(int, ...)=LKF4;
static LKF5(int, ...);
static (*LK5)(int, ...)=LKF5;
static LKF6(int, ...);
static (*LK6)(int, ...)=LKF6;
static LKF7(int, ...);
static (*LK7)(int, ...)=LKF7;
static LKF8(int, ...);
static (*LK8)(int, ...)=LKF8;
static LKF9(int, ...);
static (*LK9)(int, ...)=LKF9;
static LKF10(int, ...);
static (*LK10)(int, ...)=LKF10;
static LKF11(int, ...);
static (*LK11)(int, ...)=LKF11;
static LKF12(int, ...);
static (*LK12)(int, ...)=LKF12;
static LKF13(int, ...);
static (*LK13)(int, ...)=LKF13;
static LKF14(int, ...);
static (*LK14)(int, ...)=LKF14;
static LKF15(int, ...);
static (*LK15)(int, ...)=LKF15;
static LKF16(int, ...);
static (*LK16)(int, ...)=LKF16;
static LKF17(int, ...);
static (*LK17)(int, ...)=LKF17;
static LKF18(int, ...);
static (*LK18)(int, ...)=LKF18;
static LKF19(int, ...);
static (*LK19)(int, ...)=LKF19;
static LKF20(int, ...);
static (*LK20)(int, ...)=LKF20;
static LKF21(int, ...);
static (*LK21)(int, ...)=LKF21;
static LKF22(int, ...);
static (*LK22)(int, ...)=LKF22;
static LKF23(int, ...);
static (*LK23)(int, ...)=LKF23;
static LKF24(int, ...);
static (*LK24)(int, ...)=LKF24;
static LKF25(int, ...);
static (*LK25)(int, ...)=LKF25;
static LKF26(int, ...);
static (*LK26)(int, ...)=LKF26;
static LKF27(int, ...);
static (*LK27)(int, ...)=LKF27;
static LKF28(int, ...);
static (*LK28)(int, ...)=LKF28;
static LKF29(int, ...);
static (*LK29)(int, ...)=LKF29;
static LKF30(int, ...);
static (*LK30)(int, ...)=LKF30;
