
/* (c) Copyright G. Attardi, 1993. */
static L1();
static L2();
static L3();
static L4();
static L5();
static L6();
static L7();
static L8();
static L9();
static L10();
static L11();
static L12();
static L13();
static L14();
static L15();
static L16();
static L17();
static L18();
static L19();
static L21();
static L22();
static L23();
static L24();
static L25();
static L26();
#define VT2
#define VLEX2
#define CLSR2
int Lappend();
#define VT3 object T0,T1;
#define VLEX3
#define CLSR3
#define VT4 object T0;
#define VLEX4
#define CLSR4
#define VT5 object T0;
#define VLEX5
#define CLSR5
#define VT6
#define VLEX6
#define CLSR6
int Lgensym();
#define VT7
#define VLEX7
#define CLSR7
#define VT8
#define VLEX8
#define CLSR8
int Lgensym();
#define VT9
#define VLEX9
#define CLSR9
#define VT10 object T0;
#define VLEX10
#define CLSR10
int Lgensym();
#define VT11
#define VLEX11
#define CLSR11
int Lgensym();
#define VT12
#define VLEX12
#define CLSR12
#define VT13
#define VLEX13
#define CLSR13
#define VT14
#define VLEX14
#define CLSR14
#define VT15
#define VLEX15
#define CLSR15
#define VT16
#define VLEX16
#define CLSR16
int Lgensym();
#define VT17
#define VLEX17
#define CLSR17
int Lgensym();
#define VT18
#define VLEX18
#define CLSR18
#define VT19
#define VLEX19
#define CLSR19
int Lgensym();
#define VT20
#define VLEX20
#define CLSR20
int Lgensym();
#define VT21
#define VLEX21
#define CLSR21
static L20(int, object, object, object, object, object, object);
int Lgensym();
#define VT22
#define VLEX22
#define CLSR22
#define VT23
#define VLEX23
#define CLSR23
#define VT24
#define VLEX24
#define CLSR24
int Lgensym();
#define VT25
#define VLEX25
#define CLSR25
#define VT26
#define VLEX26
#define CLSR26
int Lgensym();
#define VT27
#define VLEX27
#define CLSR27
int Lgensym();
#define VT28
#define VLEX28
#define CLSR28
static struct codeblock Cblock;
#define VM28 0
#define VM27 0
#define VM26 0
#define VM25 0
#define VM24 0
#define VM23 0
#define VM22 0
#define VM21 0
#define VM20 0
#define VM19 0
#define VM18 0
#define VM17 0
#define VM16 0
#define VM15 0
#define VM14 0
#define VM13 0
#define VM12 0
#define VM11 0
#define VM10 1
#define VM9 0
#define VM8 0
#define VM7 0
#define VM6 0
#define VM5 1
#define VM4 1
#define VM3 2
#define VM2 0
#define VM1 71
static object VV[71];
static LKF0(int, ...);
static (*LK0)(int, ...)=LKF0;
static LKF1(int, ...);
static (*LK1)(int, ...)=LKF1;
