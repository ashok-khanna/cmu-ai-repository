
#include "generic.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	MF0(VV[67],L1);
	(void)putprop(VV[67],VV[Vdeb67],VV[68]);
	MM0(VV[69],L2);
	MM0(VV[64],L3);
	MF0(VV[70],L4);
	(void)putprop(VV[70],VV[Vdeb70],VV[68]);
	MF0(VV[71],L5);
	(void)putprop(VV[71],VV[Vdeb71],VV[68]);
	MF0(VV[72],L6);
	(void)putprop(VV[72],VV[Vdeb72],VV[68]);
	MF0key(VV[7],L7,8,L7keys);
	(void)putprop(VV[7],VV[Vdeb7],VV[68]);
	MF0(VV[73],L8);
	(void)putprop(VV[73],VV[Vdeb73],VV[68]);
	VV[53]=string_to_object(VV[53]);
	MF0(VV[74],L9);
	(void)putprop(VV[74],VV[Vdeb74],VV[68]);
	MF0(VV[75],L10);
	(void)putprop(VV[75],VV[Vdeb75],VV[68]);
	MF0(VV[76],L11);
	(void)putprop(VV[76],VV[Vdeb76],VV[68]);
	MF0(VV[77],L12);
	(void)putprop(VV[77],VV[Vdeb77],VV[68]);
	MF0(VV[78],L13);
	(void)putprop(VV[78],VV[Vdeb78],VV[68]);
	MF0(VV[79],L14);
	(void)putprop(VV[79],VV[Vdeb79],VV[68]);
	MF0(VV[80],L15);
	(void)putprop(VV[80],VV[Vdeb80],VV[68]);
	MF0(VV[81],L16);
	(void)putprop(VV[81],VV[Vdeb81],VV[68]);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	function definition for LEGAL-GENERIC-FUNCTION-P              */
static L1(int narg, object V1)
{ VT3 VLEX3 CLSR3
TTL:
	{object V2;
	Lfboundp(1,(V1))                          /*  FBOUNDP         */;
	V2= ((VALUES(0))==Cnil?Ct:Cnil);
	if(((V2))==Cnil){
	goto L4;}
	VALUES(0) = (V2);
	RETURN(1);
L4:
	{object V3;
	siLgfunp(1,symbol_function((V1)))         /*  GFUNP           */;
	V3= VALUES(0);
	if(((V3))==Cnil){
	goto L8;}
	VALUES(0) = (V3);
	RETURN(1);
L8:
	Lspecial_form_p(1,(V1))                   /*  SPECIAL-FORM-P  */;
	if(VALUES(0)==Cnil){
	goto L11;}
	RETURN(Lerror(2,VV[0],(V1))               /*  ERROR           */);
L11:
	Lmacro_function(1,(V1))                   /*  MACRO-FUNCTION  */;
	if(VALUES(0)==Cnil){
	goto L14;}
	RETURN(Lerror(2,VV[1],(V1))               /*  ERROR           */);
L14:
	RETURN(Lerror(2,VV[2],(V1))               /*  ERROR           */);
	}
	}
}
/*	macro definition for DEFGENERIC                               */
static L2(int narg, object V1, object V2)
{ VT4 VLEX4 CLSR4
	{object V3=CDR(V1),V4;
	V4= V3;
	{ int V5;
	object V6;                                /*  FUNCTION-SPECIFIER*/
	object V7;                                /*  LAMBDA-LIST     */
	object V8;                                /*  OPTIONS         */
	V5=L4(1,(V4))                             /*  PARSE-DEFGENERIC*/;
	if (V5==0) goto L17;
	V6= VALUES(0);
	V5--;
	if (V5==0) goto L18;
	V7= VALUES(1);
	V5--;
	if (V5==0) goto L19;
	V8= VALUES(2);
	V5--;
	goto L20;
L17:
	V6= Cnil;
L18:
	V7= Cnil;
L19:
	V8= Cnil;
L20:
	L1(1,(V6))                                /*  LEGAL-GENERIC-FUNCTION-P*/;
	if(VALUES(0)==Cnil){
	goto L22;}
	L9(1,(V7))                                /*  PARSE-LAMBDA-LIST*/;
	{ int V9;
	object V10;                               /*  ARGUMENT-PRECEDENCE-ORDER*/
	object V11;                               /*  DECLARATION     */
	object V12;                               /*  DOCUMENTATION   */
	object V13;                               /*  METHOD-COMBINATION*/
	object V14;                               /*  GENERIC-FUNCTION-CLASS*/
	object V15;                               /*  METHOD-CLASS    */
	object V16;                               /*  METHOD-LIST     */
	V9=L6(2,(V8),(V7))                        /*  PARSE-GENERIC-OPTIONS*/;
	if (V9==0) goto L26;
	V10= VALUES(0);
	V9--;
	if (V9==0) goto L27;
	V11= VALUES(1);
	V9--;
	if (V9==0) goto L28;
	V12= VALUES(2);
	V9--;
	if (V9==0) goto L29;
	V13= VALUES(3);
	V9--;
	if (V9==0) goto L30;
	V14= VALUES(4);
	V9--;
	if (V9==0) goto L31;
	V15= VALUES(5);
	V9--;
	if (V9==0) goto L32;
	V16= VALUES(6);
	V9--;
	goto L33;
L26:
	V10= Cnil;
L27:
	V11= Cnil;
L28:
	V12= Cnil;
L29:
	V13= Cnil;
L30:
	V14= Cnil;
L31:
	V15= Cnil;
L32:
	V16= Cnil;
L33:
	if(((V14))!=Cnil){
	goto L34;}
	V14= VV[3];
L34:
	if(((V15))!=Cnil){
	goto L38;}
	V15= VV[4];
L38:
	if(((V10))!=Cnil){
	goto L42;}
	V10= VV[5];
L42:
	{object V17= list(2,VV[8],(V6));
	{object V18= list(2,VV[8],(V7));
	{object V19= list(2,VV[8],(V10));
	{object V20= list(2,VV[8],(V11));
	{object V21= list(2,VV[8],(V12));
	{object V22= list(2,VV[8],(V14));
	{object V23= list(2,VV[8],(V13));
	Llist(16,VV[7],V17,VV[9],V18,VV[10],V19,VV[11],V20,VV[12],V21,VV[13],V22,VV[14],V23,VV[15],list(2,VV[8],(V15)))/*  LIST*/;
	VALUES(0) = list(2,VV[6],VALUES(0));
	RETURN(1);}}}}}}}}
L22:
	VALUES(0) = Cnil;
	RETURN(1);}}
}
/*	macro definition for GENERIC-FUNCTION                         */
static L3(int narg, object V1, object V2)
{ VT5 VLEX5 CLSR5
	{object V3=CDR(V1),V4;
	V4= V3;
	{ int V5;
	register object V6;                       /*  LAMBDA-LIST     */
	object V7;                                /*  OPTIONS         */
	V5=(*LK0)(1,(V4))                         /*  PARSE--GENERIC-FUNCTION*/;
	if (V5==0) goto L48;
	V6= VALUES(0);
	V5--;
	if (V5==0) goto L49;
	V7= VALUES(1);
	V5--;
	goto L50;
L48:
	V6= Cnil;
L49:
	V7= Cnil;
L50:
	L9(1,(V6))                                /*  PARSE-LAMBDA-LIST*/;
	{ int V8;
	object V9;                                /*  ARGUMENT-PRECEDENCE-ORDER*/
	object V10;                               /*  DECLARATION     */
	object V11;                               /*  DOCUMENTATION   */
	object V12;                               /*  METHOD-COMBINATION*/
	object V13;                               /*  GENERIC-FUNCTION-CLASS*/
	object V14;                               /*  METHOD-CLASS    */
	object V15;                               /*  METHOD-LIST     */
	V8=L6(2,(V7),(V6))                        /*  PARSE-GENERIC-OPTIONS*/;
	if (V8==0) goto L53;
	V9= VALUES(0);
	V8--;
	if (V8==0) goto L54;
	V10= VALUES(1);
	V8--;
	if (V8==0) goto L55;
	V11= VALUES(2);
	V8--;
	if (V8==0) goto L56;
	V12= VALUES(3);
	V8--;
	if (V8==0) goto L57;
	V13= VALUES(4);
	V8--;
	if (V8==0) goto L58;
	V14= VALUES(5);
	V8--;
	if (V8==0) goto L59;
	V15= VALUES(6);
	V8--;
	goto L60;
L53:
	V9= Cnil;
L54:
	V10= Cnil;
L55:
	V11= Cnil;
L56:
	V12= Cnil;
L57:
	V13= Cnil;
L58:
	V14= Cnil;
L59:
	V15= Cnil;
L60:
	if(((V13))!=Cnil){
	goto L61;}
	V13= VV[3];
L61:
	if(((V14))!=Cnil){
	goto L65;}
	V14= VV[4];
L65:
	if(((V9))!=Cnil){
	goto L69;}
	V9= VV[5];
L69:
	{object V16= list(2,VV[17],list(3,VV[18],Cnil,list(2,VV[8],(V6))));
	{object V17= list(2,VV[8],(V13));
	{object V18= list(2,VV[8],(V6));
	{object V19= list(2,VV[8],(V9));
	{object V20= list(2,VV[8],(V12));
	{object V21= list(2,VV[8],(V14));
	LlistA(13,VV[20],V17,VV[9],V18,VV[10],V19,VV[14],V20,VV[15],V21,VV[12],list(2,VV[8],(V11)),VV[21])/*  LIST**/;
	VALUES(0) = list(2,VV[6],listA(3,VV[16],list(2,V16,list(2,VV[19],VALUES(0))),VV[22]));
	RETURN(1);}}}}}}}}}
}
/*	function definition for PARSE-DEFGENERIC                      */
static L4(int narg, object V1)
{ VT6 VLEX6 CLSR6
TTL:
	{register object V2;                      /*  FUNCTION-SPECIFIER*/
	V2= Cnil;
	if(((V1))!=Cnil){
	goto L74;}
	Lerror(1,VV[23])                          /*  ERROR           */;
L74:
	{object V3;
	V3= CAR((V1));
	V1= CDR((V1));
	V2= (V3);
	}
	(*LK1)(1,(V2))                            /*  LEGAL-GENERIC-FUNCTION-NAME-P*/;
	if(VALUES(0)!=Cnil){
	goto L82;}
	Lerror(2,VV[24],(V2))                     /*  ERROR           */;
L82:
	if(((V1))!=Cnil){
	goto L85;}
	Lerror(1,VV[25])                          /*  ERROR           */;
L85:
	VALUES(2) = CDR((V1));
	VALUES(1) = CAR((V1));
	VALUES(0) = (V2);
	RETURN(3);
	}
}
/*	function definition for PARSE-GENERIC-FUNCTION                */
static L5(int narg, object V1)
{ VT7 VLEX7 CLSR7
TTL:
	if(((V1))!=Cnil){
	goto L88;}
	Lerror(1,VV[26])                          /*  ERROR           */;
L88:
	VALUES(1) = CDR((V1));
	VALUES(0) = CAR((V1));
	RETURN(2);
}
/*	function definition for PARSE-GENERIC-OPTIONS                 */
static L6(int narg, object V1, object V2)
{ VT8 VLEX8 CLSR8
TTL:
	{object V3;                               /*  ARGUMENT-PRECEDENCE-ORDER*/
	object V4;                                /*  DECLARATION     */
	object V5;                                /*  DOCUMENTATION   */
	object V6;                                /*  METHOD-COMBINATION*/
	object V7;                                /*  GENERIC-FUNCTION-CLASS*/
	object V8;                                /*  METHOD-CLASS    */
	object V9;                                /*  METHOD-LIST     */
	V3= Cnil;
	V4= Cnil;
	V5= Cnil;
	V6= Cnil;
	V7= Cnil;
	V8= Cnil;
	V9= Cnil;
	{register object V10;
	register object V11;                      /*  OPTION          */
	V10= (V1);
	V11= Cnil;
L95:
	if(!((V10)==Cnil)){
	goto L96;}
	goto L91;
L96:
	V11= CAR((V10));
	{register object V13;
	V13= CAR((V11));
	if(!(eql((V13),VV[10]))){
	goto L104;}
	if(((V3))==Cnil){
	goto L107;}
	Lerror(1,VV[27])                          /*  ERROR           */;
	goto L101;
L107:
	L10(2,CADR((V11)),(V2))                   /*  PARSE-PARAMETER-NAMES*/;
	V3= VALUES(0);
	goto L101;
L104:
	if(!(eql((V13),VV[28]))){
	goto L111;}
	if(((V4))==Cnil){
	goto L114;}
	Lerror(1,VV[29])                          /*  ERROR           */;
	goto L101;
L114:
	L11(1,CADR((V11)))                        /*  PARSE-LEGAL-DECLARATION*/;
	V4= VALUES(0);
	goto L101;
L111:
	if(!(eql((V13),VV[12]))){
	goto L118;}
	if(((V5))==Cnil){
	goto L121;}
	Lerror(1,VV[30])                          /*  ERROR           */;
	goto L101;
L121:
	L12(1,CADR((V11)))                        /*  PARSE-LEGAL-DOCUMENTATION*/;
	V5= VALUES(0);
	goto L101;
L118:
	if(!(eql((V13),VV[14]))){
	goto L125;}
	if(((V6))==Cnil){
	goto L128;}
	Lerror(1,VV[31])                          /*  ERROR           */;
	goto L101;
L128:
	V6= CADR((V11));
	goto L101;
L125:
	if(!(eql((V13),VV[13]))){
	goto L132;}
	if(((V7))==Cnil){
	goto L135;}
	Lerror(1,VV[32])                          /*  ERROR           */;
	goto L101;
L135:
	L14(1,CADR((V11)))                        /*  LEGAL-GENERIC-FUNCTION-CLASSP*/;
	V7= VALUES(0);
	goto L101;
L132:
	if(!(eql((V13),VV[15]))){
	goto L139;}
	if(((V8))==Cnil){
	goto L142;}
	Lerror(1,VV[33])                          /*  ERROR           */;
	goto L101;
L142:
	L15(1,CADR((V11)))                        /*  PARSE-LEGAL-METHOD-CLASS*/;
	V8= VALUES(0);
	goto L101;
L139:
	if(!(eql((V13),VV[34]))){
	goto L146;}
	L16(1,CADR((V11)))                        /*  PARSE-LEGAL-METHOD-LIST*/;
	V9= CONS(VALUES(0),(V9));
	goto L101;
L146:
	Lerror(2,VV[35],CAR((V11)))               /*  ERROR           */;
	}
L101:
	V10= CDR((V10));
	goto L95;
	}
L91:
	VALUES(6) = (V9);
	VALUES(5) = (V8);
	VALUES(4) = (V7);
	VALUES(3) = (V6);
	VALUES(2) = (V5);
	VALUES(1) = (V4);
	VALUES(0) = (V3);
	RETURN(7);
	}
}
/*	function definition for ENSURE-GENERIC-FUNCTION               */
static L7(int narg, object V1, ...)
{ VT9 VLEX9 CLSR9
	{object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	register object V8;
	object V9;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[16];
	parse_key(narg,args,8,L7keys,keyvars,OBJNULL,FALSE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	if(keyvars[12]==Cnil){
	V6= VV[3];
	}else{
	V6= keyvars[4];}
	if(keyvars[13]==Cnil){
	V7= VV[36];
	}else{
	V7= keyvars[5];}
	if(keyvars[14]==Cnil){
	V8= VV[4];
	}else{
	V8= keyvars[6];}
	V9= keyvars[7];
	}
	(*LK1)(1,(V1))                            /*  LEGAL-GENERIC-FUNCTION-NAME-P*/;
	if(VALUES(0)!=Cnil){
	goto L156;}
	Lerror(2,VV[37],(V1))                     /*  ERROR           */;
L156:
	L1(1,(V1))                                /*  LEGAL-GENERIC-FUNCTION-P*/;
	if(VALUES(0)==Cnil){
	goto L160;}
	(*LK2)(1,(V8))                            /*  CLASSP          */;
	if(VALUES(0)!=Cnil){
	goto L162;}
	(*LK3)(1,(V8))                            /*  FIND-CLASS      */;
	V8= VALUES(0);
L162:
	{register object V10;                     /*  DISPATCHER      */
	register object V11;                      /*  GF-OBJECT       */
	V10= Cnil;
	V11= Cnil;
	Lfboundp(1,(V1))                          /*  FBOUNDP         */;
	if(VALUES(0)==Cnil){
	goto L168;}
	V10= symbol_function((V1));
	siLgfunp(1,(V10))                         /*  GFUNP           */;
	if(VALUES(0)==Cnil){
	goto L168;}
	siLgfun_instance(1,(V10))                 /*  GFUN-INSTANCE   */;
	V11= VALUES(0);
	(*LK4)(3,(V3),(V11),VV[38])               /*  (SETF SLOT-VALUE)*/;
	(*LK4)(3,(V5),(V11),VV[39])               /*  (SETF SLOT-VALUE)*/;
	(*LK5)(2,(V7),(V11))                      /*  (SETF GENERIC-FUNCTION-METHOD-COMBINATION)*/;
	(*LK4)(3,(V8),(V11),VV[40])               /*  (SETF SLOT-VALUE)*/;
	goto L166;
L168:
	(*LK6)(2,(V1),(V2))                       /*  MAKE-GFUN       */;
	V10= VALUES(0);
	(*LK7)(13,(V6),VV[9],(V2),VV[10],(V3),VV[14],(V7),VV[15],(V8),VV[12],(V5),VV[41],(V10))/*  MAKE-INSTANCE*/;
	V11= VALUES(0);
	siLgfun_instance_set(2,(V10),(V11))       /*  GFUN-INSTANCE-SET*/;
	siLfset(2,(V1),(V10))                     /*  FSET            */;
L166:
	VALUES(0) = (V11);
	RETURN(1);
	}
L160:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for CONGRUENT-LAMBDA-LIST-P               */
static L8(int narg, object V1, object V2)
{ VT10 VLEX10 CLSR10
TTL:
	{object V3;                               /*  POST-KEYWORD    */
	{register object V4;                      /*  SCAN1           */
	register object V5;                       /*  SCAN2           */
	V4= (V1);
	V5= (V2);
L184:
	if(((V4))!=Cnil){
	goto L185;}
	if(((V5))!=Cnil){
	goto L185;}
	VALUES(0) = Cnil;
	RETURN(1);
L185:
	if((Cnil)!=Cnil){
	goto L192;}
	{register object x= CAR((V4)),V7= VV[42];
	while(V7!=Cnil)
	if(eql(x, CAR(V7))){
	goto L197;
	}else V7=CDR(V7);
	goto L195;}
L197:
	{register object x= CAR((V5)),V7= VV[43];
	while(V7!=Cnil)
	if(eql(x, CAR(V7))){
	goto L198;
	}else V7=CDR(V7);
	goto L191;}
L198:
L195:
	{register object x= CAR((V5)),V7= VV[44];
	while(V7!=Cnil)
	if(eql(x, CAR(V7))){
	goto L200;
	}else V7=CDR(V7);
	goto L192;}
L200:
	{register object x= CAR((V4)),V7= VV[45];
	while(V7!=Cnil)
	if(eql(x, CAR(V7))){
	goto L192;
	}else V7=CDR(V7);}
L191:
	Lerror(3,VV[46],(V1),(V2))                /*  ERROR           */;
	goto L190;
L192:
	if(!((CAR((V4)))==(VV[47]))){
	goto L190;}
	if((CAR((V5)))==(VV[47])){
	goto L204;}
	Lerror(3,VV[48],(V1),(V2))                /*  ERROR           */;
L204:
	{object V7;                               /*  SCAN-OP1        */
	register object V8;                       /*  SCAN-OP2        */
	V7= CDR((V4));
	V8= CDR((V5));
L210:
	if(((V7))!=Cnil){
	goto L211;}
	if(((V8))!=Cnil){
	goto L211;}
	goto L190;
L211:
	if(((V8))==Cnil){
	goto L217;}
	{register object x= CAR((V8)),V10= VV[49];
	while(V10!=Cnil)
	if(eql(x, CAR(V10))){
	goto L220;
	}else V10=CDR(V10);
	goto L216;}
L220:
L217:
	Lerror(3,VV[50],(V1),(V2))                /*  ERROR           */;
L216:
	V7= CDR((V7));
	V8= CDR((V8));
	goto L210;
	}
L190:
	V4= CDR((V4));
	V5= CDR((V5));
	goto L184;
	}
	}
}
/*	function definition for PARSE-LAMBDA-LIST                     */
static L9(int narg, object V1, ...)
{ VT11 VLEX11 CLSR11
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if (i==narg) goto L229;
	V2= va_arg(args, object);
	i++;
	goto L230;
L229:
	V2= Cnil;
L230:
	{object V3;                               /*  ARG             */
	V3= CAR((V1));
	{object V4;
	V4= ((V1)==Cnil?Ct:Cnil);
	if(((V4))==Cnil){
	goto L235;}
	VALUES(0) = (V4);
	RETURN(1);
L235:
	if(!(((V3))==(VV[51]))){
	goto L238;}
	RETURN(Lerror(1,VV[52])                   /*  ERROR           */);
L238:
	{register object x= (V3),V5= VV[53];
	while(V5!=Cnil)
	if(eql(x, CAR(V5))){
	goto L242;
	}else V5=CDR(V5);
	goto L241;}
L242:
	RETURN(L9(2,CDR((V1)),Ct)                 /*  PARSE-LAMBDA-LIST*/);
L241:
	if(((V2))==Cnil){
	goto L244;}
	RETURN(L9(2,CDR((V1)),Ct)                 /*  PARSE-LAMBDA-LIST*/);
L244:
	if(!(type_of((V3))==t_cons||(V3)==Cnil)){
	goto L247;}
	RETURN(Lerror(1,VV[54])                   /*  ERROR           */);
L247:
	RETURN(L9(1,CDR((V1)))                    /*  PARSE-LAMBDA-LIST*/);
	}
	}
	}
}
/*	function definition for PARSE-PARAMETER-NAMES                 */
static L10(int narg, object V1, object V2)
{ VT12 VLEX12 CLSR12
TTL:
	{register object V3;                      /*  REQUIRED-LIST   */
	object V4;                                /*  COUNT           */
	V3= Cnil;
	V4= Cnil;
	{register object V5;                      /*  L               */
	V5= (V2);
L252:
	if(((V5))==Cnil){
	goto L254;}
	{register object x= CAR((V5)),V6= VV[55];
	while(V6!=Cnil)
	if(eql(x, CAR(V6))){
	goto L257;
	}else V6=CDR(V6);
	goto L253;}
L257:
L254:
	V3= nreverse((V3));
	goto L250;
L253:
	V3= CONS((V5),(V3));
	V5= CDR((V5));
	goto L252;
	}
L250:
	{register object V5;
	object V6;                                /*  L               */
	V5= (V3);
	V6= Cnil;
L266:
	if(!((V5)==Cnil)){
	goto L267;}
	VALUES(0) = (V1);
	RETURN(1);
L267:
	V6= CAR((V5));
	(*LK8)(2,(V6),(V1))                       /*  COUNT           */;
	V4= VALUES(0);
	if(number_compare((V4),MAKE_FIXNUM(1))==0){
	goto L274;}
	Lerror(2,VV[56],(V6))                     /*  ERROR           */;
L274:
	V5= CDR((V5));
	goto L266;
	}
	}
}
/*	function definition for PARSE-LEGAL-DECLARATION               */
static L11(int narg, object V1)
{ VT13 VLEX13 CLSR13
TTL:
	if((CAR((V1)))==(VV[57])){
	goto L280;}
	Lerror(1,VV[58])                          /*  ERROR           */;
L280:
	{register object V2;                      /*  D               */
	object V3;                                /*  FIRST           */
	V2= CDR((V1));
	V3= CAR((V2));
L286:
	if(((V2))!=Cnil){
	goto L287;}
	VALUES(0) = (V1);
	RETURN(1);
L287:
	{register object x= CAR((V3)),V5= VV[59];
	while(V5!=Cnil)
	if(eql(x, CAR(V5))){
	goto L290;
	}else V5=CDR(V5);}
	Lerror(1,VV[60])                          /*  ERROR           */;
L290:
	V2= CDR((V2));
	V3= CAR((V2));
	goto L286;
	}
}
/*	function definition for PARSE-LEGAL-DOCUMENTATION             */
static L12(int narg, object V1)
{ VT14 VLEX14 CLSR14
TTL:
	if(type_of((V1))==t_string){
	goto L298;}
	Lerror(1,VV[61])                          /*  ERROR           */;
L298:
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for PARSE-LEGAL-METHOD-COMBINATION        */
static L13(int narg, object V1, object V2)
{ VT15 VLEX15 CLSR15
TTL:
	(*LK9)(1,(V1))                            /*  METHOD-COMBINATION-P*/;
	if(VALUES(0)!=Cnil){
	goto L301;}
	Lerror(2,VV[62],(V1))                     /*  ERROR           */;
L301:
	(*LK10)(2,(V1),(V2))                      /*  LEGAL-METHOD-COMBINATION-ARGS*/;
	if(VALUES(0)!=Cnil){
	goto L304;}
	Lerror(3,VV[63],(V2),(V1))                /*  ERROR           */;
L304:
	VALUES(1) = (V2);
	VALUES(0) = (V1);
	RETURN(2);
}
/*	function definition for LEGAL-GENERIC-FUNCTION-CLASSP         */
static L14(int narg, object V1)
{ VT16 VLEX16 CLSR16
TTL:
	(*LK3)(1,(V1))                            /*  FIND-CLASS      */;
	T0= VALUES(0);
	(*LK3)(1,VV[64])                          /*  FIND-CLASS      */;
	(*LK11)(2,T0,VALUES(0))                   /*  SUBTYPEP        */;
	if(VALUES(0)!=Cnil){
	goto L307;}
	Lerror(2,VV[65],(V1))                     /*  ERROR           */;
L307:
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for PARSE-LEGAL-METHOD-CLASS              */
static L15(int narg, object V1)
{ VT17 VLEX17 CLSR17
TTL:
	RETURN(Lerror(1,VV[66])                   /*  ERROR           */);
}
/*	function definition for PARSE-LEGAL-METHOD-LIST               */
static L16(int narg, object V1)
{ VT18 VLEX18 CLSR18
TTL:
	VALUES(0) = (V1);
	RETURN(1);
}
static LKF11(int narg, ...) {TRAMPOLINK(VV[103],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[101],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[100],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[96],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[20],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[18],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[92],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[91],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[90],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[89],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[84],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[83],&LK0);}
