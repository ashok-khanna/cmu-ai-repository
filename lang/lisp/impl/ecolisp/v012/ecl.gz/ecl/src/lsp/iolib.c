
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "iolib.h"
init_iolib(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_iolib; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	funcall(2,symbol_function(VV[47]),VV[0])  /*  PROCLAIM        */;
	MM0(VV[48],L1);
	MM0(VV[49],L2);
	MM0(VV[50],L3);
	MF0key(VV[51],L4,3,L4keys);
	MF0key(VV[52],L5,10,L5keys);
	MF0(VV[53],L6);
	MF0(VV[54],L7);
	MM0(VV[55],L8);
	MF0(VV[56],L9);
	MF0(VV[57],L10);
	MF0(VV[22],L11);
	Lset_dispatch_macro_character(3,code_char('\43'),code_char('\141'),VV[22])/*  SET-DISPATCH-MACRO-CHARACTER*/;
	Lset_dispatch_macro_character(3,code_char('\43'),code_char('\101'),VV[22])/*  SET-DISPATCH-MACRO-CHARACTER*/;
	MF0(VV[29],L12);
	Lset_dispatch_macro_character(3,code_char('\43'),code_char('\163'),VV[29])/*  SET-DISPATCH-MACRO-CHARACTER*/;
	Lset_dispatch_macro_character(3,code_char('\43'),code_char('\123'),VV[29])/*  SET-DISPATCH-MACRO-CHARACTER*/;
	VV[30]->s.s_stype=(short)stp_special;
	if(VV[30]->s.s_dbind == OBJNULL){
	(VV[30]->s.s_dbind)= Cnil;}
	VV[31]->s.s_stype=(short)stp_special;
	if(VV[31]->s.s_dbind == OBJNULL){
	(VV[31]->s.s_dbind)= Cnil;}
	VV[32]->s.s_stype=(short)stp_special;
	if(VV[32]->s.s_dbind == OBJNULL){
	(VV[32]->s.s_dbind)= Cnil;}
	VV[33]->s.s_stype=(short)stp_special;
	if(VV[33]->s.s_dbind == OBJNULL){
	(VV[33]->s.s_dbind)= Cnil;}
	MF0(VV[58],L13);
}
/*	macro definition for WITH-OPEN-STREAM                         */
static L1(int narg, object V1, object V2)
{ VT3 VLEX3 CLSR3
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6;
	if(endp(V3))FEinvalid_macro_call(VV[48]);
	{object V7= CAR(V3);
	if(endp(V7))FEinvalid_macro_call(VV[48]);
	V4= CAR(V7);
	V7=CDR(V7);
	if(endp(V7))FEinvalid_macro_call(VV[48]);
	V5= CAR(V7);
	V7=CDR(V7);
	if(!endp(V7))FEinvalid_macro_call(VV[48]);}
	V3=CDR(V3);
	V6= V3;
	{ int V8;
	object V9;                                /*  DS              */
	object V10;                               /*  B               */
	V8=(*LK0)(1,(V6))                         /*  FIND-DECLARATIONS*/;
	if (V8--==0) goto L11;
	V9= VALUES(0);
	if (V8--==0) goto L12;
	V10= VALUES(1);
	goto L13;
L11:
	V9= Cnil;
L12:
	V10= Cnil;
L13:
	{object V11= CONS(list(2,(V4),(V5)),Cnil);
	{object V12= CONS(VV[3],(V10));
	VALUES(0) = listA(3,VV[1],(V11),append((V9),CONS(list(3,VV[2],(V12),list(2,VV[4],(V4))),Cnil)));
	RETURN(1);}}}}
}
/*	macro definition for WITH-INPUT-FROM-STRING                   */
static L2(int narg, object V1, object V2)
{ VT4 VLEX4 CLSR4
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6,V7,V8,V9;
	if(endp(V3))FEinvalid_macro_call(VV[49]);
	{object V10= CAR(V3);
	if(endp(V10))FEinvalid_macro_call(VV[49]);
	V4= CAR(V10);
	V10=CDR(V10);
	if(endp(V10))FEinvalid_macro_call(VV[49]);
	V5= CAR(V10);
	V10=CDR(V10);
	{object V11;
	V11=getf(V10,VV[60],OBJNULL);
	if(V11==OBJNULL){
	V6= Cnil;
	} else {
	V6= V11;}
	V11=getf(V10,VV[61],OBJNULL);
	if(V11==OBJNULL){
	V7= Cnil;
	} else {
	V7= V11;}
	V11=getf(V10,VV[62],OBJNULL);
	if(V11==OBJNULL){
	V8= Cnil;
	} else {
	V8= V11;}}
	check_other_key(V10,3,VV[60],VV[61],VV[62]);}
	V3=CDR(V3);
	V9= V3;
	if(((V6))==Cnil){
	goto L18;}
	{ int V12;
	object V13;                               /*  DS              */
	object V14;                               /*  B               */
	V12=(*LK0)(1,(V9))                        /*  FIND-DECLARATIONS*/;
	if (V12--==0) goto L21;
	V13= VALUES(0);
	if (V12--==0) goto L22;
	V14= VALUES(1);
	goto L23;
L21:
	V13= Cnil;
L22:
	V14= Cnil;
L23:
	{object V15= CONS(list(2,(V4),list(4,VV[5],(V5),(V7),(V8))),Cnil);
	{object V16= CONS(VV[3],(V14));
	VALUES(0) = listA(3,VV[1],(V15),append((V13),CONS(list(3,VV[2],(V16),list(3,VV[6],(V6),list(2,VV[7],(V4)))),Cnil)));
	RETURN(1);}}}
L18:
	VALUES(0) = listA(3,VV[1],CONS(list(2,(V4),list(4,VV[5],(V5),(V7),(V8))),Cnil),(V9));
	RETURN(1);}
}
/*	macro definition for WITH-OUTPUT-TO-STRING                    */
static L3(int narg, object V1, object V2)
{ VT5 VLEX5 CLSR5
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6;
	if(endp(V3))FEinvalid_macro_call(VV[50]);
	{object V7= CAR(V3);
	if(endp(V7))FEinvalid_macro_call(VV[50]);
	V4= CAR(V7);
	V7=CDR(V7);
	if(endp(V7)){
	V5= Cnil;
	} else {
	V5= CAR(V7);
	V7=CDR(V7);}
	if(!endp(V7))FEinvalid_macro_call(VV[50]);}
	V3=CDR(V3);
	V6= V3;
	if(((V5))==Cnil){
	goto L26;}
	VALUES(0) = listA(3,VV[1],CONS(list(2,(V4),list(2,VV[8],(V5))),Cnil),(V6));
	RETURN(1);
L26:
	{object V8= CONS(list(2,(V4),VV[9]),Cnil);
	VALUES(0) = listA(3,VV[1],(V8),append((V6),CONS(list(2,VV[10],(V4)),Cnil)));
	RETURN(1);}}
}
/*	function definition for READ-FROM-STRING                      */
static L4(int narg, object V1, ...)
{ VT6 VLEX6 CLSR6
	cs_check;
	{int i=1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V1);
	if(narg<1) FEtoo_few_arguments(&narg);
	if (i==narg) goto L28;
	V2= va_arg(args, object);
	i++;
	if (i==narg) goto L29;
	V3= va_arg(args, object);
	i++;
	goto L30;
L28:
	V2= Ct;
L29:
	V3= Cnil;
L30:
	narg -=3;
	{ object keyvars[6];
	parse_key(narg,args,3,L4keys,keyvars,OBJNULL,FALSE);
	if(keyvars[3]==Cnil){
	V4= MAKE_FIXNUM(0);
	}else{
	V4= keyvars[0];}
	if(keyvars[4]==Cnil){
	V5= MAKE_FIXNUM(length((V1)));
	}else{
	V5= keyvars[1];}
	V6= keyvars[2];
	}
	{register object V7;                      /*  STREAM          */
	Lmake_string_input_stream(3,(V1),(V4),(V5))/*  MAKE-STRING-INPUT-STREAM*/;
	V7= VALUES(0);
	if(((V6))==Cnil){
	goto L37;}
	Lread_preserving_whitespace(3,(V7),(V2),(V3))/*  READ-PRESERVING-WHITESPACE*/;
	T0= VALUES(0);
	siLget_string_input_stream_index(1,(V7))  /*  GET-STRING-INPUT-STREAM-INDEX*/;
	VALUES(1) = VALUES(0);
	VALUES(0) = T0;
	RETURN(2);
L37:
	Lread(3,(V7),(V2),(V3))                   /*  READ            */;
	T0= VALUES(0);
	siLget_string_input_stream_index(1,(V7))  /*  GET-STRING-INPUT-STREAM-INDEX*/;
	VALUES(1) = VALUES(0);
	VALUES(0) = T0;
	RETURN(2);
	}
	}
}
/*	function definition for WRITE-TO-STRING                       */
static L5(int narg, object V1, ...)
{ VT7 VLEX7 CLSR7
	cs_check;
	{object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	object V10;
	object V11;
	object V12;
	va_list args; va_start(args, V1);
	if(narg<1) FEtoo_few_arguments(&narg);
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ int n=narg; object p=V2;
	 for(;n-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{ object keyvars[20];
	va_start(args,V1);
	parse_key(narg,args,10,L5keys,keyvars,V2,FALSE);
	V3= keyvars[0];
	V4= keyvars[1];
	V5= keyvars[2];
	V6= keyvars[3];
	V7= keyvars[4];
	V8= keyvars[5];
	V9= keyvars[6];
	V10= keyvars[7];
	V11= keyvars[8];
	V12= keyvars[9];
	}
	{object V13;                              /*  STREAM          */
	Lmake_string_output_stream(0)             /*  MAKE-STRING-OUTPUT-STREAM*/;
	V13= VALUES(0);
	VALUES(0) = symbol_function(VV[74]);
	Lapply(5,VALUES(0),(V1),VV[11],(V13),(V2))/*  APPLY           */;
	RETURN(Lget_output_stream_string(1,(V13)) /*  GET-OUTPUT-STREAM-STRING*/);
	}
	}
}
/*	function definition for PRIN1-TO-STRING                       */
static L6(int narg, object V1)
{ VT8 VLEX8 CLSR8
	cs_check;
	check_arg(1);
TTL:
	{object V2;                               /*  STREAM          */
	Lmake_string_output_stream(0)             /*  MAKE-STRING-OUTPUT-STREAM*/;
	V2= VALUES(0);
	prin1((V1),(V2));
	RETURN(Lget_output_stream_string(1,(V2))  /*  GET-OUTPUT-STREAM-STRING*/);
	}
}
/*	function definition for PRINC-TO-STRING                       */
static L7(int narg, object V1)
{ VT9 VLEX9 CLSR9
	cs_check;
	check_arg(1);
TTL:
	{object V2;                               /*  STREAM          */
	Lmake_string_output_stream(0)             /*  MAKE-STRING-OUTPUT-STREAM*/;
	V2= VALUES(0);
	princ((V1),(V2));
	RETURN(Lget_output_stream_string(1,(V2))  /*  GET-OUTPUT-STREAM-STRING*/);
	}
}
/*	macro definition for WITH-OPEN-FILE                           */
static L8(int narg, object V1, object V2)
{ VT10 VLEX10 CLSR10
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6;
	if(endp(V3))FEinvalid_macro_call(VV[55]);
	{object V7= CAR(V3);
	if(endp(V7))FEinvalid_macro_call(VV[55]);
	V4= CAR(V7);
	V7=CDR(V7);
	V5= V7;}
	V3=CDR(V3);
	V6= V3;
	{ int V8;
	object V9;                                /*  DS              */
	object V10;                               /*  B               */
	V8=(*LK0)(1,(V6))                         /*  FIND-DECLARATIONS*/;
	if (V8--==0) goto L51;
	V9= VALUES(0);
	if (V8--==0) goto L52;
	V10= VALUES(1);
	goto L53;
L51:
	V9= Cnil;
L52:
	V10= Cnil;
L53:
	{object V11= CONS(list(2,(V4),CONS(VV[12],(V5))),Cnil);
	{object V12= CONS(VV[3],(V10));
	VALUES(0) = listA(3,VV[1],(V11),append((V9),CONS(list(3,VV[2],(V12),list(2,VV[4],(V4))),Cnil)));
	RETURN(1);}}}}
}
/*	function definition for Y-OR-N-P                              */
static L9(int narg, ...)
{ VT11 VLEX11 CLSR11
	cs_check;
	{int i=0;
	volatile object V1;
	volatile object V2;
	va_list args; va_start(args, narg);
	if (i==narg) goto L54;
	V1= va_arg(args, object);
	i++;
	goto L55;
L54:
	V1= Cnil;
L55:
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{volatile object V3;                      /*  REPLY           */
	V3= Cnil;
L58:
	if(((V1))==Cnil){
	goto L60;}
	Lformat(4,symbol_value(VV[13]),VV[14],(V1),(V2))/*  FORMAT    */;
L60:
	Lread(1,symbol_value(VV[13]))             /*  READ            */;
	V3= VALUES(0);
	if(!(string_equal(symbol_name((V3)),VV[15]))){
	goto L67;}
	VALUES(0) = Ct;
	RETURN(1);
L67:
	if(!(string_equal(symbol_name((V3)),VV[16]))){
	goto L65;}
	VALUES(0) = Cnil;
	RETURN(1);
L65:
	goto L58;
	}
	}
}
/*	function definition for YES-OR-NO-P                           */
static L10(int narg, ...)
{ VT12 VLEX12 CLSR12
	cs_check;
	{int i=0;
	volatile object V1;
	volatile object V2;
	va_list args; va_start(args, narg);
	if (i==narg) goto L73;
	V1= va_arg(args, object);
	i++;
	goto L74;
L73:
	V1= Cnil;
L74:
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{volatile object V3;                      /*  REPLY           */
	V3= Cnil;
L77:
	if(((V1))==Cnil){
	goto L79;}
	Lformat(4,symbol_value(VV[13]),VV[17],(V1),(V2))/*  FORMAT    */;
L79:
	Lread(1,symbol_value(VV[13]))             /*  READ            */;
	V3= VALUES(0);
	if(!(string_equal(symbol_name((V3)),VV[18]))){
	goto L86;}
	VALUES(0) = Ct;
	RETURN(1);
L86:
	if(!(string_equal(symbol_name((V3)),VV[19]))){
	goto L84;}
	VALUES(0) = Cnil;
	RETURN(1);
L84:
	goto L77;
	}
	}
}
/*	function definition for SHARP-A-READER                        */
static L11(int narg, object V1, object V2, object V3)
{ VT13 VLEX13 CLSR13
	cs_check;
	check_arg(3);
TTL:
	{volatile object V4;                      /*  INITIAL-CONTENTS*/
	Lread(4,(V1),Cnil,Cnil,Ct)                /*  READ            */;
	V4= VALUES(0);
	if((symbol_value(VV[20]))==Cnil){
	goto L94;}
	VALUES(0) = Cnil;
	RETURN(1);
L94:
	{volatile int V5;                         /*  I               */
	volatile object V6;                       /*  D               */
	volatile object V7;                       /*  IC              */
	V5= 0;
	V6= Cnil;
	V7= (V4);
L98:
	if(!(number_compare(MAKE_FIXNUM(V5),(V3))>=0)){
	goto L99;}
	{object V9= nreverse((V6));
	RETURN((*LK1)(3,(V9),VV[21],(V4))         /*  MAKE-ARRAY      */);}
L99:
	V5= (V5)+1;
	V6= CONS(MAKE_FIXNUM(length((V7))),(V6));
	if(!((length((V7)))==0)){
	goto L107;}
	goto L105;
L107:
	V7= elt((V7),0);
L105:
	goto L98;
	}
	}
}
/*	function definition for SHARP-S-READER-SI                     */
static L12(int narg, object V1, object V2, object V3)
{ VT14 VLEX14 CLSR14
	cs_check;
	check_arg(3);
TTL:
	if(((V3))==Cnil){
	goto L110;}
	if((symbol_value(VV[20]))!=Cnil){
	goto L110;}
	Lerror(2,VV[23],(V3))                     /*  ERROR           */;
L110:
	{volatile object V4;                      /*  L               */
	Lread(1,(V1))                             /*  READ            */;
	V4= VALUES(0);
	if((get(car((V4)),VV[24],Cnil))!=Cnil){
	goto L116;}
	Lerror(2,VV[25],car((V4)))                /*  ERROR           */;
L116:
	{volatile object V5;                      /*  LL              */
	V5= cdr((V4));
L121:
	if(!(endp((V5)))){
	goto L122;}
	{volatile object V7;                      /*  CS              */
	V7= get(car((V4)),VV[26],Cnil);
L127:
	if(!(endp((V7)))){
	goto L128;}
	RETURN(Lerror(2,VV[27],car((V4)))         /*  ERROR           */);
L128:
	if(!(type_of(car((V7)))==t_symbol)){
	goto L131;}
	RETURN(Lapply(2,car((V7)),cdr((V4)))      /*  APPLY           */);
L131:
	V7= cdr((V7));
	goto L127;
	}
L122:
	Lintern(2,coerce_to_string(car((V5))),VV[28])/*  INTERN       */;
	if(type_of((V5))!=t_cons)FEwrong_type_argument(Scons,(V5));
	CAR((V5)) = VALUES(0);
	V5= cddr((V5));
	goto L121;
	}
	}
}
/*	function definition for DRIBBLE                               */
static L13(int narg, ...)
{ VT15 VLEX15 CLSR15
	cs_check;
	{int i=0;
	object V1;
	object V2;
	object V3;
	va_list args; va_start(args, narg);
	if(narg>2) FEtoo_many_arguments(&narg);
	if (i==narg) goto L142;
	V1= va_arg(args, object);
	V2= Ct;
	i++;
	if (i==narg) goto L143;
	V3= va_arg(args, object);
	i++;
	goto L144;
L142:
	V1= VV[34];
	V2= Cnil;
L143:
	V3= VV[35];
L144:
	if(((V2))!=Cnil){
	goto L148;}
	if((symbol_value(VV[30]))!=Cnil){
	goto L150;}
	Lerror(1,VV[36])                          /*  ERROR           */;
L150:
	if(!((symbol_value(VV[31]))==(symbol_value(VV[37])))){
	goto L155;}
	setq(VV[37],symbol_value(VV[33]));
	goto L153;
L155:
	(*LK2)(1,VV[38])                          /*  WARN            */;
L153:
	Lclose(1,symbol_value(VV[30]))            /*  CLOSE           */;
	setq(VV[30],Cnil);
	RETURN(Lformat(3,Ct,VV[39],symbol_value(VV[32]))/*  FORMAT    */);
L148:
	if((symbol_value(VV[30]))==Cnil){
	goto L162;}
	RETURN(Lerror(2,VV[40],symbol_value(VV[32]))/*  ERROR         */);
L162:
	{object V4;                               /*  NAMESTRING      */
	object V5;                                /*  STREAM          */
	V4= coerce_to_namestring((V1));
	(*LK3)(7,(V1),VV[41],VV[42],VV[43],(V3),VV[44],VV[45])/*  OPEN*/;
	V5= VALUES(0);
	setq(VV[32],(V4));
	setq(VV[30],(V5));
	setq(VV[33],symbol_value(VV[37]));
	Lmake_echo_stream(2,symbol_value(VV[37]),(V5))/*  MAKE-ECHO-STREAM*/;
	T0= VALUES(0);
	Lmake_broadcast_stream(2,symbol_value(VV[37]),(V5))/*  MAKE-BROADCAST-STREAM*/;
	Lmake_two_way_stream(2,T0,VALUES(0))      /*  MAKE-TWO-WAY-STREAM*/;
	setq(VV[31],VALUES(0));
	setq(VV[37],symbol_value(VV[31]));
	{ int V6;
	object V7;                                /*  SEC             */
	object V8;                                /*  MIN             */
	object V9;                                /*  HOUR            */
	object V10;                               /*  DAY             */
	object V11;                               /*  MONTH           */
	object V12;                               /*  YEAR            */
	V6=(*LK4)(0)                              /*  GET-DECODED-TIME*/;
	if (V6--==0) goto L179;
	V7= VALUES(0);
	if (V6--==0) goto L180;
	V8= VALUES(1);
	if (V6--==0) goto L181;
	V9= VALUES(2);
	if (V6--==0) goto L182;
	V10= VALUES(3);
	if (V6--==0) goto L183;
	V11= VALUES(4);
	if (V6--==0) goto L184;
	V12= VALUES(5);
	goto L185;
L179:
	V7= Cnil;
L180:
	V8= Cnil;
L181:
	V9= Cnil;
L182:
	V10= Cnil;
L183:
	V11= Cnil;
L184:
	V12= Cnil;
L185:
	RETURN(Lformat(9,Ct,VV[46],(V4),(V12),(V11),(V10),(V9),(V8),(V7))/*  FORMAT*/);}
	}
	}
}
static LKF4(int narg, ...) {TRAMPOLINK(VV[77],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[12],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[76],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[75],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[59],&LK0);}
