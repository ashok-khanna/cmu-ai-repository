
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "cmpwt.h"
init_cmpwt(int size, object data_stream)
{VT2 CLSR2
	Cblock.cd_start=(char *)init_cmpwt; Cblock.cd_size=size;
	Cblock.cd_data=read_VV(VV,VM1,data_stream);
	MF0(VV[26],L1);
	MF0(VV[27],L2);
	MF0(VV[28],L3);
	MF0(VV[29],L4);
	MF0(VV[30],L5);
	MF0(VV[31],L6);
	MF0(VV[32],L7);
}
/*	function definition for WT-COMMENT                            */
static L1(int narg, object V1, ...)
{ VT3 VLEX3 CLSR3
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if (i==narg) goto L1;
	V2= va_arg(args, object);
	i++;
	goto L2;
L1:
	V2= Cnil;
L2:
	if(((V2))==Cnil){
	goto L6;}
	princ_char(10,symbol_value(VV[0]));
	princ_str("/*	",symbol_value(VV[0]));
	princ((V1),(VV[0]->s.s_dbind));
	goto L4;
L6:
	Lsymbol_package(1,(V1))                   /*  SYMBOL-PACKAGE  */;
	if(VALUES(0)==Cnil){
	goto L11;}
	Lformat(2,(VV[0]->s.s_dbind),VV[1])       /*  FORMAT          */;
	V2= (V1);
	goto L4;
L11:
	VALUES(0) = Cnil;
	RETURN(1);
L4:
	{register object V3;                      /*  S               */
	int V4;                                   /*  L               */
	register unsigned char V5;                /*  C               */
	Lsymbol_name(1,(V2))                      /*  SYMBOL-NAME     */;
	V3= VALUES(0);
	V4= (((V3))->v.v_fillp)-1;
	V5= 32;
	{object V6;
	register int V7;                          /*  N               */
	V6= MAKE_FIXNUM(V4);
	V7= 0;
L23:
	if(!((V7)>=(fix((V6))))){
	goto L24;}
	goto L19;
L24:
	V5= ((V3))->ust.ust_self[V7];
	princ(code_char(V5),(VV[0]->s.s_dbind));
	if(!((V5)==(42))){
	goto L30;}
	if(!((((V3))->ust.ust_self[(V7)+1])==(47))){
	goto L30;}
	princ_char(92,symbol_value(VV[0]));
L30:
	V7= (V7)+1;
	goto L23;
	}
L19:
	princ(code_char(((V3))->ust.ust_self[V4]),(VV[0]->s.s_dbind));
	}
	Lformat(2,(VV[0]->s.s_dbind),VV[2])       /*  FORMAT          */;
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WT1                                   */
static L2(int narg, object V1)
{ VT4 VLEX4 CLSR4
TTL:
	{object V2;
	V2= (V1);
	(*LK0)(2,(V2),VV[3])                      /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L41;}
	princ((V1),(VV[0]->s.s_dbind));
	goto L39;
L41:
	(*LK0)(2,(V2),VV[4])                      /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L44;}
	Lformat(3,(VV[0]->s.s_dbind),VV[5],(V1))  /*  FORMAT          */;
	goto L39;
L44:
	(*LK0)(2,(V2),VV[6])                      /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L47;}
	(*LK1)(1,(V1))                            /*  WT-VAR          */;
	goto L39;
L47:
	(*LK2)(1,(V1))                            /*  WT-LOC          */;
	}
L39:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-H1                                 */
static L3(int narg, object V1)
{ VT5 VLEX5 CLSR5
TTL:
	if(!(type_of((V1))==t_cons)){
	goto L51;}
	{object V2;                               /*  FUN             */
	V2= getf(CAR((V1))->s.s_plist,VV[7],Cnil);
	if(((V2))==Cnil){
	goto L55;}
	Lapply(2,(V2),CDR((V1)))                  /*  APPLY           */;
	goto L49;
L55:
	(*LK3)(2,VV[8],(V1))                      /*  CMPERR          */;
	goto L49;
	}
L51:
	princ((V1),(VV[9]->s.s_dbind));
L49:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-DATA                               */
static L4(int narg, object V1)
{ VT6 VLEX6 CLSR6
	bds_check;
TTL:
	bds_bind(VV[10],Cnil);                    /*  *PRINT-RADIX*   */
	bds_bind(VV[11],MAKE_FIXNUM(10));         /*  *PRINT-BASE*    */
	bds_bind(VV[12],Ct);                      /*  *PRINT-CIRCLE*  */
	bds_bind(VV[13],Cnil);                    /*  *PRINT-PRETTY*  */
	bds_bind(VV[14],Cnil);                    /*  *PRINT-LEVEL*   */
	bds_bind(VV[15],Cnil);                    /*  *PRINT-LENGTH*  */
	bds_bind(VV[16],VV[17]);                  /*  *PRINT-CASE*    */
	bds_bind(VV[18],Ct);                      /*  *PRINT-GENSYM*  */
	bds_bind(VV[19],Ct);                      /*  *PRINT-ARRAY*   */
	bds_bind(VV[20],VV[21]);                  /*  *READ-DEFAULT-FLOAT-FORMAT**/
	bds_bind(VV[22],Ct);                      /*  *PRINT-PACKAGE* */
	bds_bind(VV[23],Ct);                      /*  *PRINT-STRUCTURE**/
	princ_char(10,symbol_value(VV[24]));
	Lcompiled_function_p(1,(V1))              /*  COMPILED-FUNCTION-P*/;
	if(VALUES(0)==Cnil){
	goto L60;}
	siLcompiled_function_name(1,(V1))         /*  COMPILED-FUNCTION-NAME*/;
	prin1(VALUES(0),(VV[24]->s.s_dbind));
	goto L58;
L60:
	prin1((V1),(VV[24]->s.s_dbind));
L58:
	{int V2;
	VALUES(0)=Cnil;
	V2=1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V2);}
}
/*	function definition for WT-DATA-BEGIN                         */
static L5(int narg)
{ VT7 VLEX7 CLSR7
TTL:
	princ_str("          ",symbol_value(VV[24]));
	princ_char(10,symbol_value(VV[24]));
	princ_str("#(",symbol_value(VV[24]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-DATA-END                           */
static L6(int narg)
{ VT8 VLEX8 CLSR8
TTL:
	princ_char(10,symbol_value(VV[24]));
	princ_char(41,symbol_value(VV[24]));
	{object V1= (VV[24]->s.s_dbind);
	Lfile_length(1,(VV[24]->s.s_dbind))       /*  FILE-LENGTH     */;
	RETURN(Lformat(3,V1,VV[25],number_plus(MAKE_FIXNUM(11),VALUES(0)))/*  FORMAT*/);}
}
/*	function definition for WT-DATA-PACKAGE-OPERATION             */
static L7(int narg, object V1)
{ VT9 VLEX9 CLSR9
TTL:
	princ_char(10,symbol_value(VV[24]));
	princ_str("#!",symbol_value(VV[24]));
	RETURN(L4(1,(V1))                         /*  WT-DATA         */);
}
static LKF3(int narg, ...) {TRAMPOLINK(VV[36],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[35],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[34],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[33],&LK0);}
