
#include "graphics.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	VV[0]->s.s_stype=(short)stp_special;
	if(VV[0]->s.s_dbind == OBJNULL){
	(VV[0]->s.s_dbind)= Cnil;}
	MF0(VV[49],L1);
	(void)putprop(VV[49],VV[Vdeb49],VV[50]);
	MF0(VV[51],L2);
	(void)putprop(VV[51],VV[Vdeb51],VV[50]);
	MF0(VV[52],L3);
	(void)putprop(VV[52],VV[Vdeb52],VV[50]);
	MF0key(VV[53],L4,3,L4keys);
	(void)putprop(VV[53],VV[Vdeb53],VV[50]);
	MF0(VV[54],L5);
	(void)putprop(VV[54],VV[Vdeb54],VV[50]);
	MF0(VV[55],L6);
	(void)putprop(VV[55],VV[Vdeb55],VV[50]);
	MF0(VV[56],L7);
	(void)putprop(VV[56],VV[Vdeb56],VV[50]);
	MF0(VV[57],L8);
	(void)putprop(VV[57],VV[Vdeb57],VV[50]);
	MF0(VV[58],L9);
	(void)putprop(VV[58],VV[Vdeb58],VV[50]);
	MF0(VV[59],L10);
	(void)putprop(VV[59],VV[Vdeb59],VV[50]);
	MF0(VV[60],L11);
	(void)putprop(VV[60],VV[Vdeb60],VV[50]);
	MF0(VV[61],L12);
	(void)putprop(VV[61],VV[Vdeb61],VV[50]);
	MF0key(VV[62],L13,8,L13keys);
	(void)putprop(VV[62],VV[Vdeb62],VV[50]);
	MF0key(VV[63],L14,9,L14keys);
	(void)putprop(VV[63],VV[Vdeb63],VV[50]);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	function definition for DRAW-POINT                            */
static L1(int narg, object V1, object V2, object V3, object V4)
{ VT3 VLEX3 CLSR3
	{register int V5;
	register int V6;
	V5= fix(V3);
	V6= fix(V4);
TTL:
	{register object V7;                      /*  DISPLAY         */
	V7= ((V1))->in.in_slots[1];
	if((((V7))->in.in_slots[10])==Cnil){
	goto L4;}
	(*LK0)(3,VV[3],VV[4],(V7))                /*  X-ERROR         */;
L4:
	(*LK1)(1,(V2))                            /*  FORCE-GCONTEXT-CHANGES-INTERNAL*/;
	{register object V8;                      /*  %BUFFER         */
	V8= (V7);
	if(!(((fix(((V8))->in.in_slots[6]))+(160))>=(fix(((V8))->in.in_slots[2])))){
	goto L8;}
	(*LK2)(1,(V8))                            /*  BUFFER-FLUSH    */;
L8:
	{register int V9;                         /*  BUFFER-BOFFSET  */
	register object V10;                      /*  BUFFER-BBUF     */
	V9= fix(((V8))->in.in_slots[6]);
	V10= ((V8))->in.in_slots[7];
	{object V11;                              /*  LAST-REQUEST-BYTE*/
	register int V12;                         /*  CURRENT-BOFFSET */
	V11= ((V7))->in.in_slots[4];
	V12= V9;
	if(((VV[0]->s.s_dbind))!=Cnil){
	goto L18;}
	if(((V11))==Cnil){
	goto L18;}
	if(!((((V10))->ust.ust_self[fix((V11))])==(64))){
	goto L18;}
	{int V13;                                 /*  .BOFFSET.       */
	V13= fix((V11));
	V9= V13;
	}
	if((0)==(((V10))->ust.ust_self[(V9)+(1)])){
	goto L31;}
	VALUES(0) = Cnil;
	goto L30;
L31:
	T0= ((V1))->in.in_slots[0];
	if((fix(T0))==(((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(4)))) & 0x1fffffff))){
	goto L33;}
	VALUES(0) = Cnil;
	goto L30;
L33:
	T0= ((V2))->in.in_slots[0];
	VALUES(0) = ((fix(T0))==(((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(8)))) & 0x1fffffff))?Ct:Cnil);
L30:
	if(VALUES(0)==Cnil)goto L29;
	if((VALUES(0))==Cnil){
	goto L18;}
	goto L25;
L29:
	{int V13;                                 /*  .BOFFSET.       */
	V13= V12;
	V9= V13;
	}
	goto L18;
L25:
	((*(unsigned short *)(((V10))->ust.ust_self+((V9)+(2))))=(1)+((((V12)-(fix((V11)))) >> (- (-2)))));
	{int V13;                                 /*  .BOFFSET.       */
	V13= V12;
	V9= V13;
	}
	(*LK3)(2,MAKE_FIXNUM(V5),VV[7])           /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L47;}
	((*(short *)(((V10))->st.st_self+((V9)+(0))))=V5);
	goto L45;
L47:
	(*LK4)(2,MAKE_FIXNUM(V5),VV[7])           /*  X-TYPE-ERROR    */;
L45:
	(*LK3)(2,MAKE_FIXNUM(V6),VV[7])           /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L50;}
	((*(short *)(((V10))->st.st_self+((V9)+(2))))=V6);
	goto L44;
L50:
	(*LK4)(2,MAKE_FIXNUM(V6),VV[7])           /*  X-TYPE-ERROR    */;
L44:
	((V7))->in.in_slots[6]= MAKE_FIXNUM((V9)+(4));
	goto L3;
L18:
	(((V10))->ust.ust_self[(V9)+(0)]=(64));
	(((V10))->ust.ust_self[(V9)+(1)]=(0));
	((*(unsigned short *)(((V10))->ust.ust_self+((V9)+(2))))=4);
	(*LK5)(1,(V1))                            /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L58;}
	((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L56;
L58:
	(*LK4)(2,(V1),VV[1])                      /*  X-TYPE-ERROR    */;
L56:
	(*LK6)(1,(V2))                            /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L62;}
	((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(8))))=fix(((V2))->in.in_slots[0]));
	goto L60;
L62:
	(*LK4)(2,(V2),VV[6])                      /*  X-TYPE-ERROR    */;
L60:
	(*LK3)(2,MAKE_FIXNUM(V5),VV[7])           /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L66;}
	((*(short *)(((V10))->st.st_self+((V9)+(12))))=V5);
	goto L64;
L66:
	(*LK4)(2,MAKE_FIXNUM(V5),VV[7])           /*  X-TYPE-ERROR    */;
L64:
	(*LK3)(2,MAKE_FIXNUM(V6),VV[7])           /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L69;}
	((*(short *)(((V10))->st.st_self+((V9)+(14))))=V6);
	goto L52;
L69:
	(*LK4)(2,MAKE_FIXNUM(V6),VV[7])           /*  X-TYPE-ERROR    */;
L52:
	(*LK7)(1,(V7))                            /*  BUFFER-NEW-REQUEST-NUMBER*/;
	((V7))->in.in_slots[4]= MAKE_FIXNUM(V9);
	((V7))->in.in_slots[6]= MAKE_FIXNUM((V9)+(16));
	}
	}
	}
L3:
	RETURN((*LK8)(1,(V7))                     /*  DISPLAY-INVOKE-AFTER-FUNCTION*/);
	}
	}
}
/*	function definition for DRAW-POINTS                           */
static L2(int narg, object V1, object V2, object V3, ...)
{ VT4 VLEX4 CLSR4
	{int i=3;
	object V4;
	va_list args; va_start(args, V3);
	if (i==narg) goto L73;
	V4= va_arg(args, object);
	i++;
	goto L74;
L73:
	V4= Cnil;
L74:
	{register object V5;                      /*  .DISPLAY.       */
	V5= ((V1))->in.in_slots[1];
	if((((V5))->in.in_slots[10])==Cnil){
	goto L77;}
	(*LK0)(3,VV[3],VV[4],(V5))                /*  X-ERROR         */;
L77:
	(*LK1)(1,(V2))                            /*  FORCE-GCONTEXT-CHANGES-INTERNAL*/;
	{ int V6;
	{register object V7;                      /*  %BUFFER         */
	V7= (V5);
	if(!(((fix(((V7))->in.in_slots[6]))+(160))>=(fix(((V7))->in.in_slots[2])))){
	goto L82;}
	(*LK2)(1,(V7))                            /*  BUFFER-FLUSH    */;
L82:
	{register int V8;                         /*  BUFFER-BOFFSET  */
	register object V9;                       /*  BUFFER-BBUF     */
	V8= fix(((V7))->in.in_slots[6]);
	V9= ((V7))->in.in_slots[7];
	((V5))->in.in_slots[4]= MAKE_FIXNUM(V8);
	(((V9))->ust.ust_self[(V8)+(0)]=(64));
	if(((V4))==Cnil){
	goto L96;}
	T0= MAKE_FIXNUM(1);
	goto L94;
L96:
	T0= MAKE_FIXNUM(0);
L94:
	VALUES(0) = MAKE_FIXNUM((((V9))->ust.ust_self[(V8)+(1)]=(fix(T0))));
	if(VALUES(0)==Cnil)goto L92;
	goto L91;
L92:
	(*LK4)(2,(V4),VV[8])                      /*  X-TYPE-ERROR    */;
L91:
	(*LK5)(1,(V1))                            /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L100;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L98;
L100:
	(*LK4)(2,(V1),VV[1])                      /*  X-TYPE-ERROR    */;
L98:
	(*LK6)(1,(V2))                            /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L104;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(8))))=fix(((V2))->in.in_slots[0]));
	goto L102;
L104:
	(*LK4)(2,(V2),VV[6])                      /*  X-TYPE-ERROR    */;
L102:
	(*LK3)(2,(V3),VV[9])                      /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L108;}
	{int V10;
	V10= length((V3));
	Lceiling(2,MAKE_FIXNUM((V10)-(0)),MAKE_FIXNUM(2))/*  CEILING  */;
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=(fix(VALUES(0)))+(3));
	(*LK9)(6,(V7),MAKE_FIXNUM((V8)+(12)),(V3),MAKE_FIXNUM(0),MAKE_FIXNUM(V10),Cnil)/*  WRITE-SEQUENCE-INT16*/;
	goto L106;
	}
L108:
	(*LK4)(2,(V3),VV[10])                     /*  X-TYPE-ERROR    */;
L106:
	V6=(*LK7)(1,(V5))                         /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V6);
	(*LK8)(1,(V5))                            /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V6);
	RETURN(V6);}
	}
	}
}
/*	function definition for DRAW-LINE                             */
static L3(int narg, object V1, object V2, object V3, object V4, object V5, object V6, ...)
{ VT5 VLEX5 CLSR5
	{register int V7;
	register int V8;
	register int V9;
	register int V10;int i=6;
	object V11;
	va_list args; va_start(args, V6);
	V7= fix(V3);
	V8= fix(V4);
	V9= fix(V5);
	V10= fix(V6);
	if (i==narg) goto L114;
	V11= va_arg(args, object);
	i++;
	goto L115;
L114:
	V11= Cnil;
L115:
	{register object V12;                     /*  DISPLAY         */
	V12= ((V1))->in.in_slots[1];
	if(((V11))==Cnil){
	goto L118;}
	V9= (V9)+(V7);
	V10= (V10)+(V8);
L118:
	if((((V12))->in.in_slots[10])==Cnil){
	goto L125;}
	(*LK0)(3,VV[3],VV[4],(V12))               /*  X-ERROR         */;
L125:
	(*LK1)(1,(V2))                            /*  FORCE-GCONTEXT-CHANGES-INTERNAL*/;
	{register object V13;                     /*  %BUFFER         */
	V13= (V12);
	if(!(((fix(((V13))->in.in_slots[6]))+(160))>=(fix(((V13))->in.in_slots[2])))){
	goto L129;}
	(*LK2)(1,(V13))                           /*  BUFFER-FLUSH    */;
L129:
	{register int V14;                        /*  BUFFER-BOFFSET  */
	register object V15;                      /*  BUFFER-BBUF     */
	V14= fix(((V13))->in.in_slots[6]);
	V15= ((V13))->in.in_slots[7];
	{object V16;                              /*  LAST-REQUEST-BYTE*/
	register int V17;                         /*  CURRENT-BOFFSET */
	V16= ((V12))->in.in_slots[4];
	V17= V14;
	if(((VV[0]->s.s_dbind))!=Cnil){
	goto L139;}
	if(((V16))==Cnil){
	goto L139;}
	if(!((((V15))->ust.ust_self[fix((V16))])==(66))){
	goto L139;}
	{int V18;                                 /*  .BOFFSET.       */
	V18= fix((V16));
	V14= V18;
	}
	T0= ((V1))->in.in_slots[0];
	if((fix(T0))==(((*(unsigned long *)(((V15))->ust.ust_self+((V14)+(4)))) & 0x1fffffff))){
	goto L152;}
	VALUES(0) = Cnil;
	goto L151;
L152:
	T0= ((V2))->in.in_slots[0];
	VALUES(0) = ((fix(T0))==(((*(unsigned long *)(((V15))->ust.ust_self+((V14)+(8)))) & 0x1fffffff))?Ct:Cnil);
L151:
	if(VALUES(0)==Cnil)goto L150;
	if((VALUES(0))==Cnil){
	goto L139;}
	goto L146;
L150:
	{int V18;                                 /*  .BOFFSET.       */
	V18= V17;
	V14= V18;
	}
	goto L139;
L146:
	((*(unsigned short *)(((V15))->ust.ust_self+((V14)+(2))))=(2)+((((V17)-(fix((V16)))) >> (- (-2)))));
	{int V18;                                 /*  .BOFFSET.       */
	V18= V17;
	V14= V18;
	}
	(*LK3)(2,MAKE_FIXNUM(V7),VV[7])           /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L166;}
	((*(short *)(((V15))->st.st_self+((V14)+(0))))=V7);
	goto L164;
L166:
	(*LK4)(2,MAKE_FIXNUM(V7),VV[7])           /*  X-TYPE-ERROR    */;
L164:
	(*LK3)(2,MAKE_FIXNUM(V8),VV[7])           /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L170;}
	((*(short *)(((V15))->st.st_self+((V14)+(2))))=V8);
	goto L168;
L170:
	(*LK4)(2,MAKE_FIXNUM(V8),VV[7])           /*  X-TYPE-ERROR    */;
L168:
	(*LK3)(2,MAKE_FIXNUM(V9),VV[7])           /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L174;}
	((*(short *)(((V15))->st.st_self+((V14)+(4))))=V9);
	goto L172;
L174:
	(*LK4)(2,MAKE_FIXNUM(V9),VV[7])           /*  X-TYPE-ERROR    */;
L172:
	(*LK3)(2,MAKE_FIXNUM(V10),VV[7])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L177;}
	((*(short *)(((V15))->st.st_self+((V14)+(6))))=V10);
	goto L163;
L177:
	(*LK4)(2,MAKE_FIXNUM(V10),VV[7])          /*  X-TYPE-ERROR    */;
L163:
	((V12))->in.in_slots[6]= MAKE_FIXNUM((V14)+(8));
	goto L124;
L139:
	(((V15))->ust.ust_self[(V14)+(0)]=(66));
	((*(unsigned short *)(((V15))->ust.ust_self+((V14)+(2))))=5);
	(*LK5)(1,(V1))                            /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L184;}
	((*(unsigned long *)(((V15))->ust.ust_self+((V14)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L182;
L184:
	(*LK4)(2,(V1),VV[1])                      /*  X-TYPE-ERROR    */;
L182:
	(*LK6)(1,(V2))                            /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L188;}
	((*(unsigned long *)(((V15))->ust.ust_self+((V14)+(8))))=fix(((V2))->in.in_slots[0]));
	goto L186;
L188:
	(*LK4)(2,(V2),VV[6])                      /*  X-TYPE-ERROR    */;
L186:
	(*LK3)(2,MAKE_FIXNUM(V7),VV[7])           /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L192;}
	((*(short *)(((V15))->st.st_self+((V14)+(12))))=V7);
	goto L190;
L192:
	(*LK4)(2,MAKE_FIXNUM(V7),VV[7])           /*  X-TYPE-ERROR    */;
L190:
	(*LK3)(2,MAKE_FIXNUM(V8),VV[7])           /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L196;}
	((*(short *)(((V15))->st.st_self+((V14)+(14))))=V8);
	goto L194;
L196:
	(*LK4)(2,MAKE_FIXNUM(V8),VV[7])           /*  X-TYPE-ERROR    */;
L194:
	(*LK3)(2,MAKE_FIXNUM(V9),VV[7])           /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L200;}
	((*(short *)(((V15))->st.st_self+((V14)+(16))))=V9);
	goto L198;
L200:
	(*LK4)(2,MAKE_FIXNUM(V9),VV[7])           /*  X-TYPE-ERROR    */;
L198:
	(*LK3)(2,MAKE_FIXNUM(V10),VV[7])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L203;}
	((*(short *)(((V15))->st.st_self+((V14)+(18))))=V10);
	goto L179;
L203:
	(*LK4)(2,MAKE_FIXNUM(V10),VV[7])          /*  X-TYPE-ERROR    */;
L179:
	(*LK7)(1,(V12))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	((V12))->in.in_slots[4]= MAKE_FIXNUM(V14);
	((V12))->in.in_slots[6]= MAKE_FIXNUM((V14)+(20));
	}
	}
	}
L124:
	RETURN((*LK8)(1,(V12))                    /*  DISPLAY-INVOKE-AFTER-FUNCTION*/);
	}
	}
}
/*	function definition for DRAW-LINES                            */
static L4(int narg, object V1, object V2, object V3, ...)
{ VT6 VLEX6 CLSR6
	{object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V3);
	narg -=3;
	{ object keyvars[6];
	parse_key(narg,args,3,L4keys,keyvars,OBJNULL,FALSE);
	V4= keyvars[0];
	V5= keyvars[1];
	if(keyvars[5]==Cnil){
	V6= VV[11];
	}else{
	V6= keyvars[2];}
	}
	if(((V5))==Cnil){
	goto L209;}
	RETURN(L5(5,(V1),(V2),(V3),(V4),(V6))     /*  FILL-POLYGON    */);
L209:
	{register object V7;                      /*  .DISPLAY.       */
	V7= ((V1))->in.in_slots[1];
	if((((V7))->in.in_slots[10])==Cnil){
	goto L212;}
	(*LK0)(3,VV[3],VV[4],(V7))                /*  X-ERROR         */;
L212:
	(*LK1)(1,(V2))                            /*  FORCE-GCONTEXT-CHANGES-INTERNAL*/;
	{ int V8;
	{register object V9;                      /*  %BUFFER         */
	V9= (V7);
	if(!(((fix(((V9))->in.in_slots[6]))+(160))>=(fix(((V9))->in.in_slots[2])))){
	goto L217;}
	(*LK2)(1,(V9))                            /*  BUFFER-FLUSH    */;
L217:
	{register int V10;                        /*  BUFFER-BOFFSET  */
	register object V11;                      /*  BUFFER-BBUF     */
	V10= fix(((V9))->in.in_slots[6]);
	V11= ((V9))->in.in_slots[7];
	((V7))->in.in_slots[4]= MAKE_FIXNUM(V10);
	(((V11))->ust.ust_self[(V10)+(0)]=(65));
	if(((V4))==Cnil){
	goto L231;}
	T0= MAKE_FIXNUM(1);
	goto L229;
L231:
	T0= MAKE_FIXNUM(0);
L229:
	VALUES(0) = MAKE_FIXNUM((((V11))->ust.ust_self[(V10)+(1)]=(fix(T0))));
	if(VALUES(0)==Cnil)goto L227;
	goto L226;
L227:
	(*LK4)(2,(V4),VV[12])                     /*  X-TYPE-ERROR    */;
L226:
	(*LK5)(1,(V1))                            /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L235;}
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L233;
L235:
	(*LK4)(2,(V1),VV[1])                      /*  X-TYPE-ERROR    */;
L233:
	(*LK6)(1,(V2))                            /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L239;}
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(8))))=fix(((V2))->in.in_slots[0]));
	goto L237;
L239:
	(*LK4)(2,(V2),VV[6])                      /*  X-TYPE-ERROR    */;
L237:
	(*LK3)(2,(V3),VV[9])                      /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L243;}
	{int V12;
	V12= length((V3));
	Lceiling(2,MAKE_FIXNUM((V12)-(0)),MAKE_FIXNUM(2))/*  CEILING  */;
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(2))))=(fix(VALUES(0)))+(3));
	(*LK9)(6,(V9),MAKE_FIXNUM((V10)+(12)),(V3),MAKE_FIXNUM(0),MAKE_FIXNUM(V12),Cnil)/*  WRITE-SEQUENCE-INT16*/;
	goto L241;
	}
L243:
	(*LK4)(2,(V3),VV[13])                     /*  X-TYPE-ERROR    */;
L241:
	V8=(*LK7)(1,(V7))                         /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V8);
	(*LK8)(1,(V7))                            /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V8);
	RETURN(V8);}
	}
	}
}
/*	function definition for FILL-POLYGON                          */
static L5(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT7 VLEX7 CLSR7
TTL:
	{register object V6;                      /*  .DISPLAY.       */
	V6= ((V1))->in.in_slots[1];
	if((((V6))->in.in_slots[10])==Cnil){
	goto L250;}
	(*LK0)(3,VV[3],VV[4],(V6))                /*  X-ERROR         */;
L250:
	(*LK1)(1,(V2))                            /*  FORCE-GCONTEXT-CHANGES-INTERNAL*/;
	{ int V7;
	{register object V8;                      /*  %BUFFER         */
	V8= (V6);
	if(!(((fix(((V8))->in.in_slots[6]))+(160))>=(fix(((V8))->in.in_slots[2])))){
	goto L255;}
	(*LK2)(1,(V8))                            /*  BUFFER-FLUSH    */;
L255:
	{register int V9;                         /*  BUFFER-BOFFSET  */
	register object V10;                      /*  BUFFER-BBUF     */
	V9= fix(((V8))->in.in_slots[6]);
	V10= ((V8))->in.in_slots[7];
	((V6))->in.in_slots[4]= MAKE_FIXNUM(V9);
	(((V10))->ust.ust_self[(V9)+(0)]=(69));
	(*LK5)(1,(V1))                            /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L266;}
	((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L264;
L266:
	(*LK4)(2,(V1),VV[1])                      /*  X-TYPE-ERROR    */;
L264:
	(*LK6)(1,(V2))                            /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L270;}
	((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(8))))=fix(((V2))->in.in_slots[0]));
	goto L268;
L270:
	(*LK4)(2,(V2),VV[6])                      /*  X-TYPE-ERROR    */;
L268:
	{int V11;
	VALUES(0) = (VV[81]->s.s_gfdef);
	(*LK10)(4,(V5),VV[14],VV[15],VALUES(0))   /*  POSITION        */;
	V11= fix(VALUES(0));
	if(MAKE_FIXNUM(V11)==Cnil){
	VALUES(0) = Cnil;
	goto L274;}
	VALUES(0) = MAKE_FIXNUM((((V10))->ust.ust_self[(V9)+(12)]=(V11)));
	}
L274:
	if(VALUES(0)==Cnil)goto L273;
	goto L272;
L273:
	(*LK4)(2,(V5),VV[16])                     /*  X-TYPE-ERROR    */;
L272:
	if(((V4))==Cnil){
	goto L282;}
	T0= MAKE_FIXNUM(1);
	goto L280;
L282:
	T0= MAKE_FIXNUM(0);
L280:
	(((V10))->ust.ust_self[(V9)+(13)]=(fix(T0)));
	goto L277;
	(*LK4)(2,(V4),VV[17])                     /*  X-TYPE-ERROR    */;
L277:
	(*LK3)(2,(V3),VV[9])                      /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L286;}
	{int V11;
	V11= length((V3));
	Lceiling(2,MAKE_FIXNUM((V11)-(0)),MAKE_FIXNUM(2))/*  CEILING  */;
	((*(unsigned short *)(((V10))->ust.ust_self+((V9)+(2))))=(fix(VALUES(0)))+(4));
	(*LK9)(6,(V8),MAKE_FIXNUM((V9)+(16)),(V3),MAKE_FIXNUM(0),MAKE_FIXNUM(V11),Cnil)/*  WRITE-SEQUENCE-INT16*/;
	goto L284;
	}
L286:
	(*LK4)(2,(V3),VV[18])                     /*  X-TYPE-ERROR    */;
L284:
	V7=(*LK7)(1,(V6))                         /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V7);
	(*LK8)(1,(V6))                            /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V7);
	RETURN(V7);}
	}
}
/*	function definition for DRAW-SEGMENTS                         */
static L6(int narg, object V1, object V2, object V3)
{ VT8 VLEX8 CLSR8
TTL:
	{register object V4;                      /*  .DISPLAY.       */
	V4= ((V1))->in.in_slots[1];
	if((((V4))->in.in_slots[10])==Cnil){
	goto L293;}
	(*LK0)(3,VV[3],VV[4],(V4))                /*  X-ERROR         */;
L293:
	(*LK1)(1,(V2))                            /*  FORCE-GCONTEXT-CHANGES-INTERNAL*/;
	{ int V5;
	{register object V6;                      /*  %BUFFER         */
	V6= (V4);
	if(!(((fix(((V6))->in.in_slots[6]))+(160))>=(fix(((V6))->in.in_slots[2])))){
	goto L298;}
	(*LK2)(1,(V6))                            /*  BUFFER-FLUSH    */;
L298:
	{register int V7;                         /*  BUFFER-BOFFSET  */
	register object V8;                       /*  BUFFER-BBUF     */
	V7= fix(((V6))->in.in_slots[6]);
	V8= ((V6))->in.in_slots[7];
	((V4))->in.in_slots[4]= MAKE_FIXNUM(V7);
	(((V8))->ust.ust_self[(V7)+(0)]=(66));
	(*LK5)(1,(V1))                            /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L309;}
	((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L307;
L309:
	(*LK4)(2,(V1),VV[1])                      /*  X-TYPE-ERROR    */;
L307:
	(*LK6)(1,(V2))                            /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L313;}
	((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(8))))=fix(((V2))->in.in_slots[0]));
	goto L311;
L313:
	(*LK4)(2,(V2),VV[6])                      /*  X-TYPE-ERROR    */;
L311:
	(*LK3)(2,(V3),VV[9])                      /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L317;}
	{int V9;
	V9= length((V3));
	Lceiling(2,MAKE_FIXNUM((V9)-(0)),MAKE_FIXNUM(2))/*  CEILING   */;
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(2))))=(fix(VALUES(0)))+(3));
	(*LK9)(6,(V6),MAKE_FIXNUM((V7)+(12)),(V3),MAKE_FIXNUM(0),MAKE_FIXNUM(V9),Cnil)/*  WRITE-SEQUENCE-INT16*/;
	goto L315;
	}
L317:
	(*LK4)(2,(V3),VV[19])                     /*  X-TYPE-ERROR    */;
L315:
	V5=(*LK7)(1,(V4))                         /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V5);
	(*LK8)(1,(V4))                            /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V5);
	RETURN(V5);}
	}
}
/*	function definition for DRAW-RECTANGLE                        */
static L7(int narg, object V1, object V2, object V3, object V4, object V5, object V6, ...)
{ VT9 VLEX9 CLSR9
	{register int V7;
	register int V8;
	register int V9;
	register int V10;int i=6;
	object V11;
	va_list args; va_start(args, V6);
	V7= fix(V3);
	V8= fix(V4);
	V9= fix(V5);
	V10= fix(V6);
	if (i==narg) goto L323;
	V11= va_arg(args, object);
	i++;
	goto L324;
L323:
	V11= Cnil;
L324:
	{register object V12;                     /*  DISPLAY         */
	object V13;
	register int V14;                         /*  REQUEST         */
	V13= ((V1))->in.in_slots[1];
	if(((V11))==Cnil){
	goto L329;}
	V14= 70;
	goto L327;
L329:
	V14= 67;
L327:
	V12= V13;
	if((((V12))->in.in_slots[10])==Cnil){
	goto L332;}
	(*LK0)(3,VV[3],VV[4],(V12))               /*  X-ERROR         */;
L332:
	(*LK1)(1,(V2))                            /*  FORCE-GCONTEXT-CHANGES-INTERNAL*/;
	{register object V15;                     /*  %BUFFER         */
	V15= (V12);
	if(!(((fix(((V15))->in.in_slots[6]))+(160))>=(fix(((V15))->in.in_slots[2])))){
	goto L336;}
	(*LK2)(1,(V15))                           /*  BUFFER-FLUSH    */;
L336:
	{register int V16;                        /*  BUFFER-BOFFSET  */
	register object V17;                      /*  BUFFER-BBUF     */
	V16= fix(((V15))->in.in_slots[6]);
	V17= ((V15))->in.in_slots[7];
	{object V18;                              /*  LAST-REQUEST-BYTE*/
	register int V19;                         /*  CURRENT-BOFFSET */
	V18= ((V12))->in.in_slots[4];
	V19= V16;
	if(((VV[0]->s.s_dbind))!=Cnil){
	goto L346;}
	if(((V18))==Cnil){
	goto L346;}
	if(!((((V17))->ust.ust_self[fix((V18))])==(V14))){
	goto L346;}
	{int V20;                                 /*  .BOFFSET.       */
	V20= fix((V18));
	V16= V20;
	}
	T0= ((V1))->in.in_slots[0];
	if((fix(T0))==(((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(4)))) & 0x1fffffff))){
	goto L359;}
	VALUES(0) = Cnil;
	goto L358;
L359:
	T0= ((V2))->in.in_slots[0];
	VALUES(0) = ((fix(T0))==(((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(8)))) & 0x1fffffff))?Ct:Cnil);
L358:
	if(VALUES(0)==Cnil)goto L357;
	if((VALUES(0))==Cnil){
	goto L346;}
	goto L353;
L357:
	{int V20;                                 /*  .BOFFSET.       */
	V20= V19;
	V16= V20;
	}
	goto L346;
L353:
	((*(unsigned short *)(((V17))->ust.ust_self+((V16)+(2))))=(2)+((((V19)-(fix((V18)))) >> (- (-2)))));
	{int V20;                                 /*  .BOFFSET.       */
	V20= V19;
	V16= V20;
	}
	(*LK3)(2,MAKE_FIXNUM(V7),VV[7])           /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L373;}
	((*(short *)(((V17))->st.st_self+((V16)+(0))))=V7);
	goto L371;
L373:
	(*LK4)(2,MAKE_FIXNUM(V7),VV[7])           /*  X-TYPE-ERROR    */;
L371:
	(*LK3)(2,MAKE_FIXNUM(V8),VV[7])           /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L377;}
	((*(short *)(((V17))->st.st_self+((V16)+(2))))=V8);
	goto L375;
L377:
	(*LK4)(2,MAKE_FIXNUM(V8),VV[7])           /*  X-TYPE-ERROR    */;
L375:
	(*LK3)(2,MAKE_FIXNUM(V9),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L381;}
	((*(unsigned short *)(((V17))->ust.ust_self+((V16)+(4))))=V9);
	goto L379;
L381:
	(*LK4)(2,MAKE_FIXNUM(V9),VV[20])          /*  X-TYPE-ERROR    */;
L379:
	(*LK3)(2,MAKE_FIXNUM(V10),VV[20])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L384;}
	((*(unsigned short *)(((V17))->ust.ust_self+((V16)+(6))))=V10);
	goto L370;
L384:
	(*LK4)(2,MAKE_FIXNUM(V10),VV[20])         /*  X-TYPE-ERROR    */;
L370:
	((V12))->in.in_slots[6]= MAKE_FIXNUM((V16)+(8));
	goto L331;
L346:
	VALUES(0) = MAKE_FIXNUM((((V17))->ust.ust_self[(V16)+(0)]=(V14)));
	if(VALUES(0)==Cnil)goto L388;
	goto L387;
L388:
	(*LK4)(2,MAKE_FIXNUM(V14),VV[21])         /*  X-TYPE-ERROR    */;
L387:
	((*(unsigned short *)(((V17))->ust.ust_self+((V16)+(2))))=5);
	(*LK5)(1,(V1))                            /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L393;}
	((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L391;
L393:
	(*LK4)(2,(V1),VV[1])                      /*  X-TYPE-ERROR    */;
L391:
	(*LK6)(1,(V2))                            /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L397;}
	((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(8))))=fix(((V2))->in.in_slots[0]));
	goto L395;
L397:
	(*LK4)(2,(V2),VV[6])                      /*  X-TYPE-ERROR    */;
L395:
	(*LK3)(2,MAKE_FIXNUM(V7),VV[7])           /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L401;}
	((*(short *)(((V17))->st.st_self+((V16)+(12))))=V7);
	goto L399;
L401:
	(*LK4)(2,MAKE_FIXNUM(V7),VV[7])           /*  X-TYPE-ERROR    */;
L399:
	(*LK3)(2,MAKE_FIXNUM(V8),VV[7])           /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L405;}
	((*(short *)(((V17))->st.st_self+((V16)+(14))))=V8);
	goto L403;
L405:
	(*LK4)(2,MAKE_FIXNUM(V8),VV[7])           /*  X-TYPE-ERROR    */;
L403:
	(*LK3)(2,MAKE_FIXNUM(V9),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L409;}
	((*(unsigned short *)(((V17))->ust.ust_self+((V16)+(16))))=V9);
	goto L407;
L409:
	(*LK4)(2,MAKE_FIXNUM(V9),VV[20])          /*  X-TYPE-ERROR    */;
L407:
	(*LK3)(2,MAKE_FIXNUM(V10),VV[20])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L412;}
	((*(unsigned short *)(((V17))->ust.ust_self+((V16)+(18))))=V10);
	goto L386;
L412:
	(*LK4)(2,MAKE_FIXNUM(V10),VV[20])         /*  X-TYPE-ERROR    */;
L386:
	(*LK7)(1,(V12))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	((V12))->in.in_slots[4]= MAKE_FIXNUM(V16);
	((V12))->in.in_slots[6]= MAKE_FIXNUM((V16)+(20));
	}
	}
	}
L331:
	RETURN((*LK8)(1,(V12))                    /*  DISPLAY-INVOKE-AFTER-FUNCTION*/);
	}
	}
}
/*	function definition for DRAW-RECTANGLES                       */
static L8(int narg, object V1, object V2, object V3, ...)
{ VT10 VLEX10 CLSR10
	{int i=3;
	object V4;
	va_list args; va_start(args, V3);
	if (i==narg) goto L416;
	V4= va_arg(args, object);
	i++;
	goto L417;
L416:
	V4= Cnil;
L417:
	{register object V5;                      /*  .DISPLAY.       */
	V5= ((V1))->in.in_slots[1];
	if((((V5))->in.in_slots[10])==Cnil){
	goto L420;}
	(*LK0)(3,VV[3],VV[4],(V5))                /*  X-ERROR         */;
L420:
	(*LK1)(1,(V2))                            /*  FORCE-GCONTEXT-CHANGES-INTERNAL*/;
	{ int V6;
	{register object V7;                      /*  %BUFFER         */
	V7= (V5);
	if(!(((fix(((V7))->in.in_slots[6]))+(160))>=(fix(((V7))->in.in_slots[2])))){
	goto L425;}
	(*LK2)(1,(V7))                            /*  BUFFER-FLUSH    */;
L425:
	{register int V8;                         /*  BUFFER-BOFFSET  */
	register object V9;                       /*  BUFFER-BBUF     */
	V8= fix(((V7))->in.in_slots[6]);
	V9= ((V7))->in.in_slots[7];
	((V5))->in.in_slots[4]= MAKE_FIXNUM(V8);
	if(((V4))==Cnil){
	goto L436;}
	T0= MAKE_FIXNUM(70);
	goto L434;
L436:
	T0= MAKE_FIXNUM(67);
L434:
	(((V9))->ust.ust_self[(V8)+(0)]=(fix(T0)));
	(*LK5)(1,(V1))                            /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L440;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L438;
L440:
	(*LK4)(2,(V1),VV[1])                      /*  X-TYPE-ERROR    */;
L438:
	(*LK6)(1,(V2))                            /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L444;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(8))))=fix(((V2))->in.in_slots[0]));
	goto L442;
L444:
	(*LK4)(2,(V2),VV[6])                      /*  X-TYPE-ERROR    */;
L442:
	(*LK3)(2,(V3),VV[9])                      /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L448;}
	{int V10;
	V10= length((V3));
	Lceiling(2,MAKE_FIXNUM((V10)-(0)),MAKE_FIXNUM(2))/*  CEILING  */;
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=(fix(VALUES(0)))+(3));
	(*LK9)(6,(V7),MAKE_FIXNUM((V8)+(12)),(V3),MAKE_FIXNUM(0),MAKE_FIXNUM(V10),Cnil)/*  WRITE-SEQUENCE-INT16*/;
	goto L446;
	}
L448:
	(*LK4)(2,(V3),VV[22])                     /*  X-TYPE-ERROR    */;
L446:
	V6=(*LK7)(1,(V5))                         /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V6);
	(*LK8)(1,(V5))                            /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V6);
	RETURN(V6);}
	}
	}
}
/*	function definition for DRAW-ARC                              */
static L9(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8, ...)
{ VT11 VLEX11 CLSR11
	{register int V9;
	register int V10;
	register int V11;
	register int V12;int i=8;
	object V13;
	va_list args; va_start(args, V8);
	V9= fix(V3);
	V10= fix(V4);
	V11= fix(V5);
	V12= fix(V6);
	if (i==narg) goto L454;
	V13= va_arg(args, object);
	i++;
	goto L455;
L454:
	V13= Cnil;
L455:
	{register object V14;                     /*  DISPLAY         */
	object V15;
	register int V16;                         /*  REQUEST         */
	V15= ((V1))->in.in_slots[1];
	if(((V13))==Cnil){
	goto L460;}
	V16= 71;
	goto L458;
L460:
	V16= 68;
L458:
	V14= V15;
	if((((V14))->in.in_slots[10])==Cnil){
	goto L463;}
	(*LK0)(3,VV[3],VV[4],(V14))               /*  X-ERROR         */;
L463:
	(*LK1)(1,(V2))                            /*  FORCE-GCONTEXT-CHANGES-INTERNAL*/;
	{register object V17;                     /*  %BUFFER         */
	V17= (V14);
	if(!(((fix(((V17))->in.in_slots[6]))+(160))>=(fix(((V17))->in.in_slots[2])))){
	goto L467;}
	(*LK2)(1,(V17))                           /*  BUFFER-FLUSH    */;
L467:
	{register int V18;                        /*  BUFFER-BOFFSET  */
	register object V19;                      /*  BUFFER-BBUF     */
	V18= fix(((V17))->in.in_slots[6]);
	V19= ((V17))->in.in_slots[7];
	{object V20;                              /*  LAST-REQUEST-BYTE*/
	register int V21;                         /*  CURRENT-BOFFSET */
	V20= ((V14))->in.in_slots[4];
	V21= V18;
	if(((VV[0]->s.s_dbind))!=Cnil){
	goto L477;}
	if(((V20))==Cnil){
	goto L477;}
	if(!((((V19))->ust.ust_self[fix((V20))])==(V16))){
	goto L477;}
	{int V22;                                 /*  .BOFFSET.       */
	V22= fix((V20));
	V18= V22;
	}
	T0= ((V1))->in.in_slots[0];
	if((fix(T0))==(((*(unsigned long *)(((V19))->ust.ust_self+((V18)+(4)))) & 0x1fffffff))){
	goto L490;}
	VALUES(0) = Cnil;
	goto L489;
L490:
	T0= ((V2))->in.in_slots[0];
	VALUES(0) = ((fix(T0))==(((*(unsigned long *)(((V19))->ust.ust_self+((V18)+(8)))) & 0x1fffffff))?Ct:Cnil);
L489:
	if(VALUES(0)==Cnil)goto L488;
	if((VALUES(0))==Cnil){
	goto L477;}
	goto L484;
L488:
	{int V22;                                 /*  .BOFFSET.       */
	V22= V21;
	V18= V22;
	}
	goto L477;
L484:
	((*(unsigned short *)(((V19))->ust.ust_self+((V18)+(2))))=(3)+((((V21)-(fix((V20)))) >> (- (-2)))));
	{int V22;                                 /*  .BOFFSET.       */
	V22= V21;
	V18= V22;
	}
	(*LK3)(2,MAKE_FIXNUM(V9),VV[7])           /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L504;}
	((*(short *)(((V19))->st.st_self+((V18)+(0))))=V9);
	goto L502;
L504:
	(*LK4)(2,MAKE_FIXNUM(V9),VV[7])           /*  X-TYPE-ERROR    */;
L502:
	(*LK3)(2,MAKE_FIXNUM(V10),VV[7])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L508;}
	((*(short *)(((V19))->st.st_self+((V18)+(2))))=V10);
	goto L506;
L508:
	(*LK4)(2,MAKE_FIXNUM(V10),VV[7])          /*  X-TYPE-ERROR    */;
L506:
	(*LK3)(2,MAKE_FIXNUM(V11),VV[20])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L512;}
	((*(unsigned short *)(((V19))->ust.ust_self+((V18)+(4))))=V11);
	goto L510;
L512:
	(*LK4)(2,MAKE_FIXNUM(V11),VV[20])         /*  X-TYPE-ERROR    */;
L510:
	(*LK3)(2,MAKE_FIXNUM(V12),VV[20])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L516;}
	((*(unsigned short *)(((V19))->ust.ust_self+((V18)+(6))))=V12);
	goto L514;
L516:
	(*LK4)(2,MAKE_FIXNUM(V12),VV[20])         /*  X-TYPE-ERROR    */;
L514:
	(*LK3)(2,(V7),VV[23])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L520;}
	(*LK11)(1,(V7))                           /*  RADIANS->INT16  */;
	T0= VALUES(0);
	((*(short *)(((V19))->st.st_self+((V18)+(8))))=fix(T0));
	goto L518;
L520:
	(*LK4)(2,(V7),VV[23])                     /*  X-TYPE-ERROR    */;
L518:
	(*LK3)(2,(V8),VV[23])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L524;}
	(*LK11)(1,(V8))                           /*  RADIANS->INT16  */;
	T0= VALUES(0);
	((*(short *)(((V19))->st.st_self+((V18)+(10))))=fix(T0));
	goto L501;
L524:
	(*LK4)(2,(V8),VV[23])                     /*  X-TYPE-ERROR    */;
L501:
	((V14))->in.in_slots[6]= MAKE_FIXNUM((V18)+(12));
	goto L462;
L477:
	VALUES(0) = MAKE_FIXNUM((((V19))->ust.ust_self[(V18)+(0)]=(V16)));
	if(VALUES(0)==Cnil)goto L529;
	goto L528;
L529:
	(*LK4)(2,MAKE_FIXNUM(V16),VV[21])         /*  X-TYPE-ERROR    */;
L528:
	((*(unsigned short *)(((V19))->ust.ust_self+((V18)+(2))))=6);
	(*LK5)(1,(V1))                            /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L534;}
	((*(unsigned long *)(((V19))->ust.ust_self+((V18)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L532;
L534:
	(*LK4)(2,(V1),VV[1])                      /*  X-TYPE-ERROR    */;
L532:
	(*LK6)(1,(V2))                            /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L538;}
	((*(unsigned long *)(((V19))->ust.ust_self+((V18)+(8))))=fix(((V2))->in.in_slots[0]));
	goto L536;
L538:
	(*LK4)(2,(V2),VV[6])                      /*  X-TYPE-ERROR    */;
L536:
	(*LK3)(2,MAKE_FIXNUM(V9),VV[7])           /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L542;}
	((*(short *)(((V19))->st.st_self+((V18)+(12))))=V9);
	goto L540;
L542:
	(*LK4)(2,MAKE_FIXNUM(V9),VV[7])           /*  X-TYPE-ERROR    */;
L540:
	(*LK3)(2,MAKE_FIXNUM(V10),VV[7])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L546;}
	((*(short *)(((V19))->st.st_self+((V18)+(14))))=V10);
	goto L544;
L546:
	(*LK4)(2,MAKE_FIXNUM(V10),VV[7])          /*  X-TYPE-ERROR    */;
L544:
	(*LK3)(2,MAKE_FIXNUM(V11),VV[20])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L550;}
	((*(unsigned short *)(((V19))->ust.ust_self+((V18)+(16))))=V11);
	goto L548;
L550:
	(*LK4)(2,MAKE_FIXNUM(V11),VV[20])         /*  X-TYPE-ERROR    */;
L548:
	(*LK3)(2,MAKE_FIXNUM(V12),VV[20])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L554;}
	((*(unsigned short *)(((V19))->ust.ust_self+((V18)+(18))))=V12);
	goto L552;
L554:
	(*LK4)(2,MAKE_FIXNUM(V12),VV[20])         /*  X-TYPE-ERROR    */;
L552:
	(*LK3)(2,(V7),VV[23])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L558;}
	(*LK11)(1,(V7))                           /*  RADIANS->INT16  */;
	T0= VALUES(0);
	((*(short *)(((V19))->st.st_self+((V18)+(20))))=fix(T0));
	goto L556;
L558:
	(*LK4)(2,(V7),VV[23])                     /*  X-TYPE-ERROR    */;
L556:
	(*LK3)(2,(V8),VV[23])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L562;}
	(*LK11)(1,(V8))                           /*  RADIANS->INT16  */;
	T0= VALUES(0);
	((*(short *)(((V19))->st.st_self+((V18)+(22))))=fix(T0));
	goto L527;
L562:
	(*LK4)(2,(V8),VV[23])                     /*  X-TYPE-ERROR    */;
L527:
	(*LK7)(1,(V14))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	((V14))->in.in_slots[4]= MAKE_FIXNUM(V18);
	((V14))->in.in_slots[6]= MAKE_FIXNUM((V18)+(24));
	}
	}
	}
L462:
	RETURN((*LK8)(1,(V14))                    /*  DISPLAY-INVOKE-AFTER-FUNCTION*/);
	}
	}
}
/*	function definition for DRAW-ARCS-LIST                        */
static L10(int narg, object V1, object V2, object V3, ...)
{ VT12 VLEX12 CLSR12
	{int i=3;
	volatile object V4;
	va_list args; va_start(args, V3);
	if (i==narg) goto L567;
	V4= va_arg(args, object);
	i++;
	goto L568;
L567:
	V4= Cnil;
L568:
	{volatile object V5;                      /*  DISPLAY         */
	volatile int V6;                          /*  LIMIT           */
	volatile object V7;                       /*  LENGTH          */
	volatile object V8;                       /*  REQUEST         */
	V5= ((V1))->in.in_slots[1];
	V6= (fix(((V5))->in.in_slots[2]))-(12);
	V7= MAKE_FIXNUM(length((V3)));
	if(((V4))==Cnil){
	goto L575;}
	V8= MAKE_FIXNUM(71);
	goto L573;
L575:
	V8= MAKE_FIXNUM(68);
L573:
	{volatile object V9;                      /*  .DISPLAY.       */
	V9= ((V1))->in.in_slots[1];
	if((((V9))->in.in_slots[10])==Cnil){
	goto L578;}
	(*LK0)(3,VV[3],VV[4],(V9))                /*  X-ERROR         */;
L578:
	(*LK1)(1,(V2))                            /*  FORCE-GCONTEXT-CHANGES-INTERNAL*/;
	{ int V10;
	{volatile object V11;                     /*  %BUFFER         */
	V11= (V9);
	if(!(((fix(((V11))->in.in_slots[6]))+(160))>=(fix(((V11))->in.in_slots[2])))){
	goto L583;}
	(*LK2)(1,(V11))                           /*  BUFFER-FLUSH    */;
L583:
	{volatile int V12;                        /*  BUFFER-BOFFSET  */
	volatile object V13;                      /*  BUFFER-BBUF     */
	V12= fix(((V11))->in.in_slots[6]);
	V13= ((V11))->in.in_slots[7];
	((V9))->in.in_slots[4]= MAKE_FIXNUM(V12);
	(((V13))->ust.ust_self[(V12)+(0)]=(fix((V8))));
	(*LK5)(1,(V1))                            /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L594;}
	((*(unsigned long *)(((V13))->ust.ust_self+((V12)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L592;
L594:
	(*LK4)(2,(V1),VV[1])                      /*  X-TYPE-ERROR    */;
L592:
	(*LK6)(1,(V2))                            /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L598;}
	((*(unsigned long *)(((V13))->ust.ust_self+((V12)+(8))))=fix(((V2))->in.in_slots[0]));
	goto L596;
L598:
	(*LK4)(2,(V2),VV[6])                      /*  X-TYPE-ERROR    */;
L596:
	{int V14;                                 /*  .VALUE.         */
	V14= ((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(2))))=(((fix((V7))) >> (- (-1))))+(3));
	}
	{int V14;                                 /*  .VALUE.         */
	{int V15;                                 /*  .BOFFSET.       */
	V15= (V12)+(12);
	V12= V15;
	V14= V12;
	}
	}
	{volatile object V14;                     /*  .VALUE.         */
	{volatile object V15;                     /*  ARC             */
	V15= (V3);
L609:
	if(!((V15)==Cnil)){
	goto L610;}
	((V5))->in.in_slots[6]= MAKE_FIXNUM(V12);
	V14= MAKE_FIXNUM(V12);
	goto L607;
L610:
	if(!((V12)>=(V6))){
	goto L613;}
	((V5))->in.in_slots[6]= MAKE_FIXNUM(V12);
	(*LK2)(1,(V5))                            /*  BUFFER-FLUSH    */;
	{register int V17;                        /*  .BOFFSET.       */
	V17= fix(((V5))->in.in_slots[6]);
	V12= V17;
	}
L613:
	{register object V18;
	V18= CAR((V15));
	V15= CDR((V15));
	T0= (V18);
	}
	((*(short *)(((V13))->st.st_self+((V12)+(0))))=fix(T0));
	{register object V18;
	V18= CAR((V15));
	V15= CDR((V15));
	T1= (V18);
	}
	((*(short *)(((V13))->st.st_self+((V12)+(2))))=fix(T1));
	{register object V18;
	V18= CAR((V15));
	V15= CDR((V15));
	T2= (V18);
	}
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(4))))=fix(T2));
	{register object V18;
	V18= CAR((V15));
	V15= CDR((V15));
	T3= (V18);
	}
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(6))))=fix(T3));
	{register object V18;
	V18= CAR((V15));
	V15= CDR((V15));
	VALUES(0) = (V18);
	}
	(*LK11)(1,VALUES(0))                      /*  RADIANS->INT16  */;
	T4= VALUES(0);
	((*(short *)(((V13))->st.st_self+((V12)+(8))))=fix(T4));
	{register object V18;
	V18= CAR((V15));
	V15= CDR((V15));
	VALUES(0) = (V18);
	}
	(*LK11)(1,VALUES(0))                      /*  RADIANS->INT16  */;
	T5= VALUES(0);
	((*(short *)(((V13))->st.st_self+((V12)+(10))))=fix(T5));
	{register int V18;                        /*  .BOFFSET.       */
	V18= (V12)+(12);
	V12= V18;
	}
	goto L609;
	}
L607:
	}
	V10=(*LK7)(1,(V9))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V10);
	(*LK8)(1,(V9))                            /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V10);
	RETURN(V10);}
	}
	}
	}
}
/*	function definition for DRAW-ARCS-VECTOR                      */
static L11(int narg, object V1, object V2, object V3, ...)
{ VT13 VLEX13 CLSR13
	{int i=3;
	volatile object V4;
	va_list args; va_start(args, V3);
	if (i==narg) goto L658;
	V4= va_arg(args, object);
	i++;
	goto L659;
L658:
	V4= Cnil;
L659:
	{volatile object V5;                      /*  DISPLAY         */
	volatile int V6;                          /*  LIMIT           */
	volatile object V7;                       /*  LENGTH          */
	volatile object V8;                       /*  REQUEST         */
	V5= ((V1))->in.in_slots[1];
	V6= (fix(((V5))->in.in_slots[2]))-(12);
	V7= MAKE_FIXNUM(((V3))->v.v_fillp);
	if(((V4))==Cnil){
	goto L666;}
	V8= MAKE_FIXNUM(71);
	goto L664;
L666:
	V8= MAKE_FIXNUM(68);
L664:
	{volatile object V9;                      /*  .DISPLAY.       */
	V9= ((V1))->in.in_slots[1];
	if((((V9))->in.in_slots[10])==Cnil){
	goto L669;}
	(*LK0)(3,VV[3],VV[4],(V9))                /*  X-ERROR         */;
L669:
	(*LK1)(1,(V2))                            /*  FORCE-GCONTEXT-CHANGES-INTERNAL*/;
	{ int V10;
	{volatile object V11;                     /*  %BUFFER         */
	V11= (V9);
	if(!(((fix(((V11))->in.in_slots[6]))+(160))>=(fix(((V11))->in.in_slots[2])))){
	goto L674;}
	(*LK2)(1,(V11))                           /*  BUFFER-FLUSH    */;
L674:
	{volatile int V12;                        /*  BUFFER-BOFFSET  */
	volatile object V13;                      /*  BUFFER-BBUF     */
	V12= fix(((V11))->in.in_slots[6]);
	V13= ((V11))->in.in_slots[7];
	((V9))->in.in_slots[4]= MAKE_FIXNUM(V12);
	(((V13))->ust.ust_self[(V12)+(0)]=(fix((V8))));
	(*LK5)(1,(V1))                            /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L685;}
	((*(unsigned long *)(((V13))->ust.ust_self+((V12)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L683;
L685:
	(*LK4)(2,(V1),VV[1])                      /*  X-TYPE-ERROR    */;
L683:
	(*LK6)(1,(V2))                            /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L689;}
	((*(unsigned long *)(((V13))->ust.ust_self+((V12)+(8))))=fix(((V2))->in.in_slots[0]));
	goto L687;
L689:
	(*LK4)(2,(V2),VV[6])                      /*  X-TYPE-ERROR    */;
L687:
	{int V14;                                 /*  .VALUE.         */
	V14= ((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(2))))=(((fix((V7))) >> (- (-1))))+(3));
	}
	{int V14;                                 /*  .VALUE.         */
	{int V15;                                 /*  .BOFFSET.       */
	V15= (V12)+(12);
	V12= V15;
	V14= V12;
	}
	}
	{volatile object V14;                     /*  .VALUE.         */
	{volatile object V15;                     /*  N               */
	volatile int V16;                         /*  LENGTH          */
	V16= ((V3))->v.v_fillp;
	V15= MAKE_FIXNUM(0);
L701:
	if(!((fix((V15)))>=(V16))){
	goto L702;}
	((V5))->in.in_slots[6]= MAKE_FIXNUM(V12);
	V14= MAKE_FIXNUM(V12);
	goto L698;
L702:
	if(!((V12)>=(V6))){
	goto L705;}
	((V5))->in.in_slots[6]= MAKE_FIXNUM(V12);
	(*LK2)(1,(V5))                            /*  BUFFER-FLUSH    */;
	{register int V18;                        /*  .BOFFSET.       */
	V18= fix(((V5))->in.in_slots[6]);
	V12= V18;
	}
L705:
	((*(short *)(((V13))->st.st_self+((V12)+(0))))=fix(((V3))->v.v_self[(fix((V15)))+(0)]));
	((*(short *)(((V13))->st.st_self+((V12)+(2))))=fix(((V3))->v.v_self[(fix((V15)))+(1)]));
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(4))))=fix(((V3))->v.v_self[(fix((V15)))+(2)]));
	((*(unsigned short *)(((V13))->ust.ust_self+((V12)+(6))))=fix(((V3))->v.v_self[(fix((V15)))+(3)]));
	(*LK11)(1,((V3))->v.v_self[(fix((V15)))+(4)])/*  RADIANS->INT16*/;
	T0= VALUES(0);
	((*(short *)(((V13))->st.st_self+((V12)+(8))))=fix(T0));
	(*LK11)(1,((V3))->v.v_self[(fix((V15)))+(5)])/*  RADIANS->INT16*/;
	T1= VALUES(0);
	((*(short *)(((V13))->st.st_self+((V12)+(10))))=fix(T1));
	{register int V19;                        /*  .BOFFSET.       */
	V19= (V12)+(12);
	V12= V19;
	}
	V15= MAKE_FIXNUM((fix((V15)))+(6));
	goto L701;
	}
L698:
	}
	V10=(*LK7)(1,(V9))                        /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V10);
	(*LK8)(1,(V9))                            /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V10);
	RETURN(V10);}
	}
	}
	}
}
/*	function definition for DRAW-ARCS                             */
static L12(int narg, object V1, object V2, object V3, ...)
{ VT14 VLEX14 CLSR14
	{int i=3;
	object V4;
	va_list args; va_start(args, V3);
	if (i==narg) goto L727;
	V4= va_arg(args, object);
	i++;
	goto L728;
L727:
	V4= Cnil;
L728:
	{object V5;
	V5= (V3);
	(*LK3)(2,(V5),VV[24])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L731;}
	RETURN(L10(4,(V1),(V2),(V3),(V4))         /*  DRAW-ARCS-LIST  */);
L731:
	(*LK3)(2,(V5),VV[25])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L734;}
	RETURN(L11(4,(V1),(V2),(V3),(V4))         /*  DRAW-ARCS-VECTOR*/);
L734:
	(*LK12)(3,VV[26],(V5),VV[27])             /*  TYPECASE-ERROR-STRING*/;
	RETURN(Lerror(1,VALUES(0))                /*  ERROR           */);
	}
	}
}
/*	function definition for PUT-RAW-IMAGE                         */
static L13(int narg, object V1, object V2, object V3, ...)
{ VT15 VLEX15 CLSR15
	{int V4;
	int V5;
	int V6;
	int V7;
	int V8;
	int V9;
	int V10;
	object V11;
	va_list args; va_start(args, V3);
	narg -=3;
	{ object keyvars[16];
	parse_key(narg,args,8,L13keys,keyvars,OBJNULL,FALSE);
	if(keyvars[8]==Cnil){
	V4= 0;
	}else{
	V4= fix(keyvars[0]);}
	if(keyvars[9]==Cnil){
	(*LK0)(3,VV[28],VV[29],VV[30])            /*  X-ERROR         */;
	V5= fix((VV[31]->s.s_dbind));
	}else{
	V5= fix(keyvars[1]);}
	if(keyvars[10]==Cnil){
	(*LK0)(3,VV[28],VV[29],VV[32])            /*  X-ERROR         */;
	V6= fix((VV[31]->s.s_dbind));
	}else{
	V6= fix(keyvars[2]);}
	if(keyvars[11]==Cnil){
	(*LK0)(3,VV[28],VV[29],VV[33])            /*  X-ERROR         */;
	V7= fix((VV[31]->s.s_dbind));
	}else{
	V7= fix(keyvars[3]);}
	if(keyvars[12]==Cnil){
	(*LK0)(3,VV[28],VV[29],VV[34])            /*  X-ERROR         */;
	V8= fix((VV[31]->s.s_dbind));
	}else{
	V8= fix(keyvars[4]);}
	if(keyvars[13]==Cnil){
	(*LK0)(3,VV[28],VV[29],VV[35])            /*  X-ERROR         */;
	V9= fix((VV[31]->s.s_dbind));
	}else{
	V9= fix(keyvars[5]);}
	if(keyvars[14]==Cnil){
	V10= 0;
	}else{
	V10= fix(keyvars[6]);}
	if(keyvars[15]==Cnil){
	(*LK0)(3,VV[28],VV[29],VV[36])            /*  X-ERROR         */;
	V11= (VV[31]->s.s_dbind);
	}else{
	V11= keyvars[7];}
	}
	{register object V12;                     /*  .DISPLAY.       */
	V12= ((V1))->in.in_slots[1];
	if((((V12))->in.in_slots[10])==Cnil){
	goto L752;}
	(*LK0)(3,VV[3],VV[4],(V12))               /*  X-ERROR         */;
L752:
	(*LK1)(1,(V2))                            /*  FORCE-GCONTEXT-CHANGES-INTERNAL*/;
	{ int V13;
	{register object V14;                     /*  %BUFFER         */
	V14= (V12);
	if(!(((fix(((V14))->in.in_slots[6]))+(160))>=(fix(((V14))->in.in_slots[2])))){
	goto L757;}
	(*LK2)(1,(V14))                           /*  BUFFER-FLUSH    */;
L757:
	{register int V15;                        /*  BUFFER-BOFFSET  */
	register object V16;                      /*  BUFFER-BBUF     */
	V15= fix(((V14))->in.in_slots[6]);
	V16= ((V14))->in.in_slots[7];
	((V12))->in.in_slots[4]= MAKE_FIXNUM(V15);
	(((V16))->ust.ust_self[(V15)+(0)]=(72));
	(*LK3)(2,(V11),VV[37])                    /*  TYPEP           */;
	if(VALUES(0)!=Cnil){
	goto L769;}
	VALUES(0) = Cnil;
	goto L768;
L769:
	VALUES(0) = (VV[81]->s.s_gfdef);
	(*LK10)(4,(V11),VV[38],VV[15],VALUES(0))  /*  POSITION        */;
	T0= VALUES(0);
	{int V17= ((*(unsigned long *)(((V16))->ust.ust_self+((V15)+(4))))=fix(T0));
	VALUES(0) = MAKE_FIXNUM((((V16))->ust.ust_self[(V15)+(1)]=(V17)));}
L768:
	if(VALUES(0)==Cnil)goto L767;
	goto L766;
L767:
	(*LK4)(2,(V11),VV[39])                    /*  X-TYPE-ERROR    */;
L766:
	(*LK5)(1,(V1))                            /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L775;}
	((*(unsigned long *)(((V16))->ust.ust_self+((V15)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L773;
L775:
	(*LK4)(2,(V1),VV[1])                      /*  X-TYPE-ERROR    */;
L773:
	(*LK6)(1,(V2))                            /*  GCONTEXT-P      */;
	if(VALUES(0)==Cnil){
	goto L779;}
	((*(unsigned long *)(((V16))->ust.ust_self+((V15)+(8))))=fix(((V2))->in.in_slots[0]));
	goto L777;
L779:
	(*LK4)(2,(V2),VV[6])                      /*  X-TYPE-ERROR    */;
L777:
	(*LK3)(2,MAKE_FIXNUM(V8),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L783;}
	((*(unsigned short *)(((V16))->ust.ust_self+((V15)+(12))))=V8);
	goto L781;
L783:
	(*LK4)(2,MAKE_FIXNUM(V8),VV[20])          /*  X-TYPE-ERROR    */;
L781:
	(*LK3)(2,MAKE_FIXNUM(V9),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L787;}
	((*(unsigned short *)(((V16))->ust.ust_self+((V15)+(14))))=V9);
	goto L785;
L787:
	(*LK4)(2,MAKE_FIXNUM(V9),VV[20])          /*  X-TYPE-ERROR    */;
L785:
	(*LK3)(2,MAKE_FIXNUM(V6),VV[7])           /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L791;}
	((*(short *)(((V16))->st.st_self+((V15)+(16))))=V6);
	goto L789;
L791:
	(*LK4)(2,MAKE_FIXNUM(V6),VV[7])           /*  X-TYPE-ERROR    */;
L789:
	(*LK3)(2,MAKE_FIXNUM(V7),VV[7])           /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L795;}
	((*(short *)(((V16))->st.st_self+((V15)+(18))))=V7);
	goto L793;
L795:
	(*LK4)(2,MAKE_FIXNUM(V7),VV[7])           /*  X-TYPE-ERROR    */;
L793:
	(*LK3)(2,MAKE_FIXNUM(V10),VV[40])         /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L799;}
	(((V16))->ust.ust_self[(V15)+(20)]=(V10));
	goto L797;
L799:
	(*LK4)(2,MAKE_FIXNUM(V10),VV[40])         /*  X-TYPE-ERROR    */;
L797:
	(*LK3)(2,MAKE_FIXNUM(V5),VV[40])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L803;}
	(((V16))->ust.ust_self[(V15)+(21)]=(V5));
	goto L801;
L803:
	(*LK4)(2,MAKE_FIXNUM(V5),VV[40])          /*  X-TYPE-ERROR    */;
L801:
	(*LK3)(2,(V3),VV[9])                      /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L808;}
	{int V17;
	V17= length((V3));
	Lceiling(2,MAKE_FIXNUM((V17)-(V4)),MAKE_FIXNUM(4))/*  CEILING */;
	((*(unsigned short *)(((V16))->ust.ust_self+((V15)+(2))))=(fix(VALUES(0)))+(6));
	(*LK13)(6,(V14),MAKE_FIXNUM((V15)+(24)),(V3),MAKE_FIXNUM(V4),MAKE_FIXNUM(V17),Cnil)/*  WRITE-SEQUENCE-CARD8*/;
	goto L806;
	}
L808:
	(*LK4)(2,(V3),VV[41])                     /*  X-TYPE-ERROR    */;
L806:
	V13=(*LK7)(1,(V12))                       /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V13);
	(*LK8)(1,(V12))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V13);
	RETURN(V13);}
	}
	}
}
/*	function definition for GET-RAW-IMAGE                         */
static L14(int narg, object V1, ...)
{ VT16 VLEX16 CLSR16
	{volatile object V2;
	volatile object V3;
	volatile int V4;
	volatile int V5;
	volatile int V6;
	volatile int V7;
	volatile object V8;
	volatile object V9;
	volatile object V10;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[18];
	parse_key(narg,args,9,L14keys,keyvars,OBJNULL,FALSE);
	V2= keyvars[0];
	if(keyvars[10]==Cnil){
	V3= MAKE_FIXNUM(0);
	}else{
	V3= keyvars[1];}
	if(keyvars[11]==Cnil){
	(*LK0)(3,VV[28],VV[29],VV[32])            /*  X-ERROR         */;
	V4= fix((VV[31]->s.s_dbind));
	}else{
	V4= fix(keyvars[2]);}
	if(keyvars[12]==Cnil){
	(*LK0)(3,VV[28],VV[29],VV[33])            /*  X-ERROR         */;
	V5= fix((VV[31]->s.s_dbind));
	}else{
	V5= fix(keyvars[3]);}
	if(keyvars[13]==Cnil){
	(*LK0)(3,VV[28],VV[29],VV[34])            /*  X-ERROR         */;
	V6= fix((VV[31]->s.s_dbind));
	}else{
	V6= fix(keyvars[4]);}
	if(keyvars[14]==Cnil){
	(*LK0)(3,VV[28],VV[29],VV[35])            /*  X-ERROR         */;
	V7= fix((VV[31]->s.s_dbind));
	}else{
	V7= fix(keyvars[5]);}
	if(keyvars[15]==Cnil){
	V8= VV[42];
	}else{
	V8= keyvars[6];}
	if(keyvars[16]==Cnil){
	(*LK0)(3,VV[28],VV[29],VV[36])            /*  X-ERROR         */;
	V9= (VV[31]->s.s_dbind);
	}else{
	V9= keyvars[7];}
	if(keyvars[17]==Cnil){
	V10= VV[43];
	}else{
	V10= keyvars[8];}
	}
	{volatile object V11;                     /*  DISPLAY         */
	V11= ((V1))->in.in_slots[1];
	{volatile object V12;                     /*  .DISPLAY.       */
	volatile object V13;                      /*  .PENDING-COMMAND.*/
	volatile object V14;                      /*  .REPLY-BUFFER.  */
	V12= (V11);
	V13= Cnil;
	V14= Cnil;
	{ int V15; volatile bool unwinding = FALSE;
	if ((V15=frs_push(FRS_PROTECT,Cnil))) {
	V15--; unwinding = TRUE;} else {
	if((((V12))->in.in_slots[10])==Cnil){
	goto L830;}
	(*LK0)(3,VV[3],VV[4],(V12))               /*  X-ERROR         */;
L830:
	(*LK14)(1,(V12))                          /*  START-PENDING-COMMAND*/;
	V13= VALUES(0);
	{register object V16;                     /*  %BUFFER         */
	V16= (V12);
	if(!(((fix(((V16))->in.in_slots[6]))+(160))>=(fix(((V16))->in.in_slots[2])))){
	goto L836;}
	(*LK2)(1,(V16))                           /*  BUFFER-FLUSH    */;
L836:
	{register int V17;                        /*  BUFFER-BOFFSET  */
	register object V18;                      /*  BUFFER-BBUF     */
	V17= fix(((V16))->in.in_slots[6]);
	V18= ((V16))->in.in_slots[7];
	((V12))->in.in_slots[4]= MAKE_FIXNUM(V17);
	(((V18))->ust.ust_self[(V17)+(0)]=(73));
	(*LK3)(2,(V9),VV[44])                     /*  TYPEP           */;
	if(VALUES(0)!=Cnil){
	goto L848;}
	VALUES(0) = Cnil;
	goto L847;
L848:
	VALUES(0) = (VV[81]->s.s_gfdef);
	(*LK10)(4,(V9),VV[45],VV[15],VALUES(0))   /*  POSITION        */;
	T0= VALUES(0);
	{int V19= ((*(unsigned long *)(((V18))->ust.ust_self+((V17)+(4))))=fix(T0));
	VALUES(0) = MAKE_FIXNUM((((V18))->ust.ust_self[(V17)+(1)]=(V19)));}
L847:
	if(VALUES(0)==Cnil)goto L846;
	goto L845;
L846:
	(*LK4)(2,(V9),VV[46])                     /*  X-TYPE-ERROR    */;
L845:
	(*LK5)(1,(V1))                            /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L854;}
	((*(unsigned long *)(((V18))->ust.ust_self+((V17)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L852;
L854:
	(*LK4)(2,(V1),VV[1])                      /*  X-TYPE-ERROR    */;
L852:
	(*LK3)(2,MAKE_FIXNUM(V4),VV[7])           /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L858;}
	((*(short *)(((V18))->st.st_self+((V17)+(8))))=V4);
	goto L856;
L858:
	(*LK4)(2,MAKE_FIXNUM(V4),VV[7])           /*  X-TYPE-ERROR    */;
L856:
	(*LK3)(2,MAKE_FIXNUM(V5),VV[7])           /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L862;}
	((*(short *)(((V18))->st.st_self+((V17)+(10))))=V5);
	goto L860;
L862:
	(*LK4)(2,MAKE_FIXNUM(V5),VV[7])           /*  X-TYPE-ERROR    */;
L860:
	(*LK3)(2,MAKE_FIXNUM(V6),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L866;}
	((*(unsigned short *)(((V18))->ust.ust_self+((V17)+(12))))=V6);
	goto L864;
L866:
	(*LK4)(2,MAKE_FIXNUM(V6),VV[20])          /*  X-TYPE-ERROR    */;
L864:
	(*LK3)(2,MAKE_FIXNUM(V7),VV[20])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L870;}
	((*(unsigned short *)(((V18))->ust.ust_self+((V17)+(14))))=V7);
	goto L868;
L870:
	(*LK4)(2,MAKE_FIXNUM(V7),VV[20])          /*  X-TYPE-ERROR    */;
L868:
	(*LK3)(2,(V8),VV[47])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L874;}
	((*(unsigned long *)(((V18))->ust.ust_self+((V17)+(16))))=fix((V8)));
	goto L872;
L874:
	(*LK4)(2,(V8),VV[47])                     /*  X-TYPE-ERROR    */;
L872:
	((*(unsigned short *)(((V18))->ust.ust_self+((V17)+(2))))=5);
	((V12))->in.in_slots[6]= MAKE_FIXNUM((V17)+(20));
	(*LK7)(1,(V12))                           /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK15)(1,(V12))                          /*  BUFFER-FORCE-OUTPUT*/;
	(*LK8)(1,(V12))                           /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK16)(2,(V12),(V13))                    /*  READ-REPLY      */;
	V14= VALUES(0);
	{object V16;                              /*  %REPLY-BUFFER   */
	object V17;                               /*  %BUFFER         */
	{register int V18;                        /*  BUFFER-BOFFSET  */
	register object V19;                      /*  BUFFER-BBUF     */
	V18= 0;
	V19= ((V14))->in.in_slots[1];
	{int V20;                                 /*  DEPTH           */
	object V21;                               /*  LENGTH          */
	object V22;
	int V23;                                  /*  VISUAL          */
	V20= ((V19))->ust.ust_self[(V18)+(1)];
	V22= fixnum_times(4,(*(unsigned long *)(((V19))->ust.ust_self+((V18)+(4)))));
	V23= ((*(unsigned long *)(((V19))->ust.ust_self+((V18)+(8)))) & 0x1fffffff);
	V21= V22;
	(*LK17)(7,(V14),(V10),(V21),Cnil,(V2),(V3),MAKE_FIXNUM(32))/*  READ-SEQUENCE-CARD8*/;
	T0= VALUES(0);
	(*LK18)(2,(V11),MAKE_FIXNUM(V23))         /*  VISUAL-INFO     */;
	VALUES(2) = VALUES(0);
	VALUES(1) = MAKE_FIXNUM(V20);
	VALUES(0) = T0;
	V15=3;
	}
	}
	}
	}
	frs_pop();
	MV_SAVE(V15);
	if(((V14))==Cnil){
	goto L893;}
	(*LK19)(1,(V14))                          /*  DEALLOCATE-REPLY-BUFFER*/;
L893:
	if(((V13))==Cnil){
	goto L892;}
	(*LK20)(2,(V12),(V13))                    /*  STOP-PENDING-COMMAND*/;
L892:
	MV_RESTORE(V15);
	if (unwinding) unwind(nlj_fr,nlj_tag,V15+1);
	else {
	RETURN(V15);}}
	}
	}
	}
}
static LKF20(int narg, ...) {TRAMPOLINK(VV[112],&LK20);}
static LKF19(int narg, ...) {TRAMPOLINK(VV[111],&LK19);}
static LKF18(int narg, ...) {TRAMPOLINK(VV[110],&LK18);}
static LKF17(int narg, ...) {TRAMPOLINK(VV[109],&LK17);}
static LKF16(int narg, ...) {TRAMPOLINK(VV[108],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[107],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[106],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[101],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[91],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[87],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[82],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[74],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[72],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[71],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[70],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[69],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[68],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[67],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[66],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[65],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[64],&LK0);}
