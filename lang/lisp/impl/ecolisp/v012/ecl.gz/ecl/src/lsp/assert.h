
/* (C) Copyright Taiichi Yuasa and Masami Hagiya, 1984. All rights reserved. *//* (c) Copyright Enhancements by G. Attardi, 1990. All rights reserved. */
static L1();
static L2();
static L4();
static L7();
static L11();
static L12();
static L14();
#define VT2
#define VLEX2
#define CLSR2
#define VT3
#define VLEX3
#define CLSR3
#define VT4 object T0,T1;
#define VLEX4
#define CLSR4
static L3(int, object);
#define VT5
#define VLEX5
#define CLSR5
int Lgensym();
#define VT6 object T0,T1;
#define VLEX6
#define CLSR6
int Lgensym();
#define VT7 object T0,T1,T2;
#define VLEX7
#define CLSR7
int Lgensym();
#define VT8
#define VLEX8
#define CLSR8
int Lgensym();
#define VT9 object T0;
#define VLEX9
#define CLSR9
int Lgensym();
#define VT10 object T0,T1;
#define VLEX10
#define CLSR10
static L17(int, object, object, object);
int Lformat();
#define VT11 object T0,T1;
#define VLEX11
#define CLSR11
static L19(int, object);
#define VT12 object T0;
#define VLEX12
#define CLSR12
static LC20(int, object );
int Lsymbol_name();
#define VT13
#define VLEX13
#define CLSR13
static struct codeblock Cblock;
#define VM13 0
#define VM12 1
#define VM11 2
#define VM10 2
#define VM9 1
#define VM8 0
#define VM7 3
#define VM6 2
#define VM5 0
#define VM4 2
#define VM3 0
#define VM2 0
#define VM1 70
static object VV[70];
static LKF0(int, ...);
static (*LK0)(int, ...)=LKF0;
