
#include "defclass.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	MM0(VV[118],L1);
	MF0(VV[119],L2);
	(void)putprop(VV[119],VV[Vdeb119],VV[120]);
	VV[121] = make_cfun(LC3,Cnil,&Cblock);
	VALUES(0) = VV[121];
	funcall(8,VV[40]->s.s_gfdef,VV[31],Cnil,VV[32],VV[33],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[122] = make_cfun(LC4,Cnil,&Cblock);
	VALUES(0) = VV[122];
	funcall(8,VV[40]->s.s_gfdef,VV[10],Cnil,VV[34],VV[35],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	init_keywords(7, L6keys, &Cblock);
	MF0(VV[123],L5);
	(void)putprop(VV[123],VV[Vdeb123],VV[120]);
	MF0(VV[124],L7);
	(void)putprop(VV[124],VV[Vdeb124],VV[120]);
	MF0(VV[125],L8);
	(void)putprop(VV[125],VV[Vdeb125],VV[120]);
	MF0(VV[126],L9);
	(void)putprop(VV[126],VV[Vdeb126],VV[120]);
	MF0(VV[127],L10);
	(void)putprop(VV[127],VV[Vdeb127],VV[120]);
	MF0(VV[128],L11);
	(void)putprop(VV[128],VV[Vdeb128],VV[120]);
	MF0(VV[129],L12);
	(void)putprop(VV[129],VV[Vdeb129],VV[120]);
	MF0(VV[130],L13);
	(void)putprop(VV[130],VV[Vdeb130],VV[120]);
	MF0(VV[131],L14);
	(void)putprop(VV[131],VV[Vdeb131],VV[120]);
	MF0(VV[132],L19);
	(void)putprop(VV[132],VV[Vdeb132],VV[120]);
	MF0(VV[133],L20);
	(void)putprop(VV[133],VV[Vdeb133],VV[120]);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	local function CLOSURE                                        */
static LC4(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8)
{ VT3 VLEX3 CLSR3
	if(((V5))==Cnil){
	goto L5;}
	Lerror(2,VV[36],(V2))                     /*  ERROR           */;
L5:
	{object V9;                               /*  SUPERCLASSES    */
	T1=VV[11]->s.s_gfdef;
	{object V10;
	object V11= (V3);
	if(V11==Cnil){
	V9= Cnil;
	goto L8;}
	T0=V10=CONS(Cnil,Cnil);
L9:
	(*LK0)(1,CAR(V11))                        /*  FIND-CLASS      */;
	CAR(V10)= VALUES(0);
	if((V11=CDR(V11))==Cnil){
	V9= T0;
	goto L8;}
	V10=CDR(V10)=CONS(Cnil,Cnil);
	goto L9;}
L8:
	RETURN((*LK1)(7,(V1),VV[37],(V2),VV[38],(V9),VV[15],(V6))/*  MAKE-INSTANCE*/);
	}
}
/*	local function CLOSURE                                        */
static LC3(int narg, object V1, object V2, object V3, object V4)
{ VT4 VLEX4 CLSR4
	T1=VV[11]->s.s_gfdef;
	{object V5;
	object V6= (V4);
	if(V6==Cnil){
	VALUES(0) = Cnil;
	goto L11;}
	T0=V5=CONS(Cnil,Cnil);
L12:
	(*LK0)(1,CAR(V6))                         /*  FIND-CLASS      */;
	CAR(V5)= VALUES(0);
	if((V6=CDR(V6))==Cnil){
	VALUES(0) = T0;
	goto L11;}
	V5=CDR(V5)=CONS(Cnil,Cnil);
	goto L12;}
L11:
	RETURN(L9(2,VALUES(0),(V2))               /*  COLLECT-SLOTDS  */);
}
/*	macro definition for DEFCLASS                                 */
static L1(int narg, object V1, object V2)
{ VT5 VLEX5 CLSR5
	bds_check;
	{object V3=CDR(V1),V4;
	V4= V3;
	{ int V5;
	register object V6;                       /*  NAME            */
	register object V7;                       /*  SUPERCLASSES    */
	object V8;                                /*  SLOTS           */
	register object V9;                       /*  METACLASS-NAME  */
	object V10;                               /*  DEFAULT-INITARGS*/
	object V11;                               /*  DOCUMENTATION   */
	V5=L2(1,(V4))                             /*  PARSE-DEFCLASS  */;
	if (V5==0) goto L15;
	V6= VALUES(0);
	V5--;
	if (V5==0) goto L16;
	V7= VALUES(1);
	V5--;
	if (V5==0) goto L17;
	V8= VALUES(2);
	V5--;
	if (V5==0) goto L18;
	V9= VALUES(3);
	V5--;
	if (V5==0) goto L19;
	V10= VALUES(4);
	V5--;
	if (V5==0) goto L20;
	V11= VALUES(5);
	V5--;
	goto L21;
L15:
	V6= Cnil;
L16:
	V7= Cnil;
L17:
	V8= Cnil;
L18:
	V9= Cnil;
L19:
	V10= Cnil;
L20:
	V11= Cnil;
L21:
	if(((V9))!=Cnil){
	goto L22;}
	V9= VV[0];
L22:
	{register object V12;
	object V13;                               /*  SUPERCLASS      */
	V12= (V7);
	V13= Cnil;
L30:
	if(!((V12)==Cnil)){
	goto L31;}
	goto L26;
L31:
	V13= CAR((V12));
	(*LK2)(1,(V13))                           /*  LEGAL-CLASS-NAME-P*/;
	if(VALUES(0)!=Cnil){
	goto L36;}
	Lerror(2,VV[1],(V13))                     /*  ERROR           */;
L36:
	V12= CDR((V12));
	goto L30;
	}
L26:
	{object V12;                              /*  SLOTS           */
	object V13;                               /*  ALL-SLOTS       */
	register object V14;                      /*  INSTANCE-SLOTS  */
	register object V15;                      /*  LOCAL-SLOTS     */
	register object V16;                      /*  CLASS-SLOTS     */
	(*LK3)(1,(V8))                            /*  PARSE-CLASS-SLOTS*/;
	V12= VALUES(0);
	(*LK0)(1,(V9))                            /*  FIND-CLASS      */;
	(*LK4)(4,VALUES(0),(V12),(V6),(V7))       /*  COLLECT-ALL-SLOTS*/;
	V13= VALUES(0);
	V14= Cnil;
	V15= Cnil;
	V16= Cnil;
	L10(2,(V12),(V13))                        /*  UPDATE-LOCAL-SLOTS*/;
	{register object V17;
	object V18;                               /*  SLOT            */
	V17= (V12);
	V18= Cnil;
L53:
	if(!((V17)==Cnil)){
	goto L54;}
	goto L49;
L54:
	V18= CAR((V17));
	{object V20;
	{object V21= CDR(CDR(CDR(CDR(CDR(CDR((V18)))))));
	V20= CAR(V21);}
	if(!(eql((V20),VV[2]))){
	goto L59;}
	V15= CONS((V18),(V15));
	}
L59:
	V17= CDR((V17));
	goto L53;
	}
L49:
	V15= nreverse((V15));
	{register object V17;
	register object V18;                      /*  SLOT            */
	V17= (V13);
	V18= Cnil;
L73:
	if(!((V17)==Cnil)){
	goto L74;}
	goto L69;
L74:
	V18= CAR((V17));
	{object V20;
	{object V21= CDR(CDR(CDR(CDR(CDR(CDR((V18)))))));
	V20= CAR(V21);}
	if(!(eql((V20),VV[2]))){
	goto L82;}
	V14= CONS((V18),(V14));
	goto L79;
L82:
	if(!(eql((V20),VV[3]))){
	goto L86;}
	V16= CONS((V18),(V16));
	goto L79;
L86:
	bds_bind(VV[4],MAKE_FIXNUM(4));           /*  *PRINT-LEVEL*   */
	bds_bind(VV[5],MAKE_FIXNUM(4));           /*  *PRINT-LENGTH*  */
	Lerror(5,VV[6],VV[7],(V20),VV[2],VV[3])   /*  ERROR           */;
	bds_unwind1;
	bds_unwind1;
	}
L79:
	V17= CDR((V17));
	goto L73;
	}
L69:
	V14= nreverse((V14));
	V16= nreverse((V16));
	{object V17= list(2,VV[11],list(2,VV[12],(V9)));
	{object V18= list(2,VV[12],(V6));
	{object V19= list(2,VV[12],(V7));
	{object V20= list(2,VV[12],(V15));
	{object V21= list(2,VV[12],(V16));
	{object V22= list(2,VV[12],(V14));
	{object V23= list(2,VV[12],(V10));
	{object V24= list(9,VV[10],V17,V18,V19,V20,V21,V22,V23,list(2,VV[12],(V11)));
	T2=VV[11]->s.s_gfdef;
	{object V25;
	object V26= (V7);
	if(V26==Cnil){
	T0= Cnil;
	goto L96;}
	T1=V25=CONS(Cnil,Cnil);
L97:
	(*LK0)(1,CAR(V26))                        /*  FIND-CLASS      */;
	CAR(V25)= VALUES(0);
	if((V26=CDR(V26))==Cnil){
	T0= T1;
	goto L96;}
	V25=CDR(V25)=CONS(Cnil,Cnil);
	goto L97;}
L96:
	(*LK0)(1,(V9))                            /*  FIND-CLASS      */;
	L9(2,CONS(VALUES(0),Cnil),(V16))          /*  COLLECT-SLOTDS  */;
	L5(11,(V6),VV[13],(V9),VV[14],T0,VV[15],(V14),VV[16],(V16),VV[17],VALUES(0))/*  GENERATE-METHODS*/;
	T1= VALUES(0);
	VALUES(0) = listA(4,VV[8],VV[9],V24,append(T1,CONS(list(2,VV[11],list(2,VV[12],(V6))),Cnil)));
	RETURN(1);}}}}}}}}
	}}}
}
/*	function definition for PARSE-DEFCLASS                        */
static L2(int narg, object V1)
{ VT6 VLEX6 CLSR6
TTL:
	{register object V2;                      /*  NAME            */
	object V3;                                /*  SUPERCLASSES    */
	object V4;                                /*  SLOTS           */
	object V5;                                /*  OPTIONS         */
	object V6;                                /*  METACLASS-NAME  */
	object V7;                                /*  DEFAULT-INITARGS*/
	object V8;                                /*  DOCUMENTATION   */
	V2= Cnil;
	V3= Cnil;
	V4= Cnil;
	V5= Cnil;
	V6= Cnil;
	V7= Cnil;
	V8= Cnil;
	if(((V1))!=Cnil){
	goto L102;}
	Lerror(1,VV[18])                          /*  ERROR           */;
L102:
	{object V9;
	V9= CAR((V1));
	V1= CDR((V1));
	V2= (V9);
	}
	if(((V1))!=Cnil){
	goto L110;}
	Lerror(1,VV[19])                          /*  ERROR           */;
L110:
	{object V9= CAR((V1));
	if(type_of(V9)==t_cons||V9==Cnil){
	goto L113;}}
	Lerror(1,VV[20])                          /*  ERROR           */;
L113:
	{object V9;
	V9= CAR((V1));
	V1= CDR((V1));
	V3= (V9);
	}
	if(((V1))!=Cnil){
	goto L121;}
	Lerror(1,VV[21])                          /*  ERROR           */;
L121:
	{object V9= CAR((V1));
	if(type_of(V9)==t_cons||V9==Cnil){
	goto L124;}}
	Lerror(1,VV[22])                          /*  ERROR           */;
L124:
	{object V9;
	V9= CAR((V1));
	V1= CDR((V1));
	V4= (V9);
	}
	V5= (V1);
	(*LK2)(1,(V2))                            /*  LEGAL-CLASS-NAME-P*/;
	if(VALUES(0)!=Cnil){
	goto L134;}
	Lerror(1,VV[23])                          /*  ERROR           */;
L134:
	{register object V9;
	register object V10;                      /*  OPTION          */
	V9= (V5);
	V10= Cnil;
L141:
	if(!((V9)==Cnil)){
	goto L142;}
	goto L137;
L142:
	V10= CAR((V9));
	{object V12;
	V12= CAR((V10));
	if(!(eql((V12),VV[24]))){
	goto L150;}
	if(((V6))==Cnil){
	goto L153;}
	Lerror(2,VV[25],(V2))                     /*  ERROR           */;
	goto L147;
L153:
	V6= CADR((V10));
	goto L147;
L150:
	if(!(eql((V12),VV[26]))){
	goto L157;}
	if(((V7))==Cnil){
	goto L160;}
	Lerror(2,VV[27],(V2))                     /*  ERROR           */;
	goto L147;
L160:
	V7= CDR((V10));
	goto L147;
L157:
	if(!(eql((V12),VV[28]))){
	goto L164;}
	if(((V8))==Cnil){
	goto L167;}
	Lerror(2,VV[29],(V2))                     /*  ERROR           */;
	goto L147;
L167:
	V8= CADR((V10));
	goto L147;
L164:
	Lerror(2,VV[30],CAR((V10)))               /*  ERROR           */;
	}
L147:
	V9= CDR((V9));
	goto L141;
	}
L137:
	VALUES(5) = (V8);
	VALUES(4) = (V7);
	VALUES(3) = (V6);
	VALUES(2) = (V4);
	VALUES(1) = (V3);
	VALUES(0) = (V2);
	RETURN(6);
	}
}
/*	function definition for GENERATE-METHODS                      */
static L5(int narg, object V1, ...)
{ VT7 VLEX7 CLSR7
	{object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{ int V3, i=0;
	T0= (V2);
	V3=length(T0);
	V3+=i;
	for (; i<V3;i++,T0=CDR(T0))
		VALUES(i)=CAR(T0);
	{ 
	object *args = &VALUES(0);
	int narg = V3;
	{object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	object V10;
	narg -=0;
	{ object keyvars[14];
	parse_key(narg,args,7,L6keys,keyvars,OBJNULL,FALSE);
	V4= keyvars[0];
	V5= keyvars[1];
	V6= keyvars[2];
	V7= keyvars[3];
	V8= keyvars[4];
	V9= keyvars[5];
	V10= keyvars[6];
	}
	(*LK5)(2,(V4),VV[0])                      /*  SUBTYPEP        */;
	if(VALUES(0)==Cnil){
	goto L175;}
	RETURN(L8(4,(V1),(V7),(V9),Ct)            /*  GENERATE-OPTIONAL-SLOT-ACCESSORS*/);
L175:
	(*LK5)(2,(V4),VV[39])                     /*  SUBTYPEP        */;
	if(VALUES(0)==Cnil){
	goto L178;}
	VALUES(0) = Cnil;
	RETURN(1);
L178:
	RETURN(L7(3,(V1),(V7),(V9))               /*  GENERATE-SLOT-ACCESSORS*/);
	}
	}
	}
	}
}
/*	function definition for GENERATE-SLOT-ACCESSORS               */
static L7(int narg, object V1, object V2, object V3)
{ VT8 VLEX8 CLSR8
TTL:
	if(!((length((V2)))>0)){
	goto L181;}
	if(!(((length((V2)))+(length((V3))))<(16))){
	goto L185;}
	{object V4= list(2,VV[12],list(2,(V1),Cnil));
	{object V5= list(2,VV[46],list(3,VV[47],(V1),VV[48]));
	{register object V6;                      /*  SCAN            */
	register object V7;                       /*  INDEX           */
	object V8;                                /*  CLAUSES         */
	V6= (V2);
	V7= MAKE_FIXNUM(0);
	V8= Cnil;
L189:
	if(((V6))!=Cnil){
	goto L190;}
	VALUES(0) = nreverse(CONS(VV[51],(V8)));
	goto L187;
L190:
	{object V10= CAR((V6));
	T1= CAR(V10);}
	{object V10= CONS(list(2,VV[53],list(3,VV[54],VV[48],(V7))),Cnil);
	{object V11;                              /*  TYPE            */
	{object V12= CDR(CDR(CDR(CDR(CDR(CDR(CDR(CAR((V6)))))))));
	V11= CAR(V12);}
	if((Ct)==((V11))){
	goto L199;}
	VALUES(0) = CONS(list(2,VV[46],list(3,VV[47],(V11),VV[53])),Cnil);
	goto L196;
L199:
	VALUES(0) = Cnil;
	}
L196:
	V8= CONS(list(2,T1,listA(3,VV[52],V10,append(VALUES(0),VV[55]))),(V8));}
	V6= CDR((V6));
	V7= one_plus((V7));
	goto L189;
	}
L187:
	{object V6= list(8,VV[40],VV[41],Cnil,V4,VV[42],Cnil,Cnil,list(2,VV[43],list(4,VV[44],VV[45],V5,listA(3,VV[49],VV[50],VALUES(0)))));
	{object V7= list(2,VV[12],list(3,Cnil,(V1),Cnil));
	{object V8= list(2,VV[46],list(3,VV[47],(V1),VV[48]));
	{register object V9;                      /*  SCAN            */
	register object V10;                      /*  INDEX           */
	object V11;                               /*  CLAUSES         */
	V9= (V2);
	V10= MAKE_FIXNUM(0);
	V11= Cnil;
L207:
	if(((V9))!=Cnil){
	goto L208;}
	VALUES(0) = nreverse(CONS(VV[59],(V11)));
	goto L205;
L208:
	{object V13= CAR((V9));
	T1= CAR(V13);}
	V11= CONS(list(2,T1,list(3,VV[60],list(3,VV[54],VV[48],(V10)),VV[61])),(V11));
	V9= CDR((V9));
	V10= one_plus((V10));
	goto L207;
	}
L205:
	T0= list(2,V6,list(8,VV[40],VV[56],Cnil,V7,VV[57],Cnil,Cnil,list(2,VV[43],list(4,VV[44],VV[58],V8,listA(3,VV[49],VV[50],VALUES(0))))));
	goto L183;}}}}}
L185:
	{object V9= list(2,list(2,VV[63],list(3,VV[64],list(2,VV[65],list(2,VV[12],(V2))),VV[66])),VV[67]);
	{object V10= listA(3,VV[68],list(2,list(3,VV[69],list(2,VV[12],(V2)),VV[70]),VV[71]),VV[72]);
	{object V11= list(2,VV[12],list(2,(V1),Cnil));
	{object V12= list(8,VV[40],VV[73],Cnil,V11,VV[74],Cnil,Cnil,list(2,VV[43],list(4,VV[44],VV[75],list(2,VV[46],list(3,VV[47],(V1),VV[48])),VV[76])));
	{object V13= list(2,VV[12],list(3,Cnil,(V1),Cnil));
	T0= CONS(list(5,VV[62],V9,V10,V12,list(8,VV[40],VV[77],Cnil,V13,VV[78],Cnil,Cnil,list(2,VV[43],list(4,VV[44],VV[79],list(2,VV[46],list(3,VV[47],(V1),VV[48])),VV[80])))),Cnil);}}}}}
L183:
	L8(3,(V1),(V2),(V3))                      /*  GENERATE-OPTIONAL-SLOT-ACCESSORS*/;
	VALUES(0) = append(T0,VALUES(0));
	RETURN(1);
L181:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for GENERATE-OPTIONAL-SLOT-ACCESSORS      */
static L8(int narg, object V1, object V2, object V3, ...)
{ VT9 VLEX9 CLSR9
	{int i=3;
	object V4;
	va_list args; va_start(args, V3);
	if (i==narg) goto L219;
	V4= va_arg(args, object);
	i++;
	goto L220;
L219:
	V4= Cnil;
L220:
	{object V5;                               /*  SCAN            */
	register int V6;                          /*  I               */
	register object V7;                       /*  SLOTD           */
	register object V8;                       /*  METHODS         */
	V6= 0;
	V5= (V2);
	V7= Cnil;
	V8= Cnil;
L225:
	if(((V5))!=Cnil){
	goto L226;}
	T0= (V8);
	goto L222;
L226:
	V7= CAR((V5));
	{object V10;
	object V11;                               /*  ACCESSOR        */
	{object V12= CDR(CDR(CDR((V7))));
	V10= CAR(V12);}
	V11= Cnil;
L235:
	if(!((V10)==Cnil)){
	goto L236;}
	goto L231;
L236:
	V11= CAR((V10));
	{object V13= list(2,VV[12],list(2,VV[60],(V11)));
	{object V14= list(2,VV[12],list(2,Cnil,(V1)));
	if(((V4))==Cnil){
	goto L245;}
	{object V15= list(2,VV[46],list(3,VV[47],(V1),VV[48]));
	VALUES(0) = list(2,VV[43],list(4,VV[44],VV[82],V15,list(4,VV[83],VV[48],MAKE_FIXNUM(V6),VV[84])));
	goto L243;}
L245:
	{object V16= (V7);
	VALUES(0) = CAR(V16);}
	VALUES(0) = list(2,VV[43],list(3,VV[44],VV[85],list(3,VV[60],list(3,VV[86],VV[48],list(2,VV[12],VALUES(0))),VV[84])));
L243:
	V8= CONS(list(8,VV[40],V13,Cnil,V14,VV[81],Cnil,Cnil,VALUES(0)),(V8));}}
	{object V13= list(2,VV[12],(V11));
	{object V14= list(2,VV[12],CONS((V1),Cnil));
	if(((V4))==Cnil){
	goto L252;}
	{object V15= list(2,VV[46],list(3,VV[47],(V1),VV[48]));
	{object V16= CONS(list(2,VV[53],list(3,VV[54],VV[48],MAKE_FIXNUM(V6))),Cnil);
	{object V17;                              /*  TYPE            */
	{object V18= CDR(CDR(CDR(CDR(CDR(CDR(CDR((V7))))))));
	V17= CAR(V18);}
	if((Ct)==((V17))){
	goto L257;}
	T1= CONS(list(2,VV[46],list(3,VV[47],(V17),VV[53])),Cnil);
	goto L254;
L257:
	T1= Cnil;
	}
L254:
	{object V17= (V7);
	VALUES(0) = CAR(V17);}
	VALUES(0) = list(2,VV[43],list(4,VV[44],VV[88],V15,listA(3,VV[52],V16,append(T1,CONS(list(4,VV[89],VV[90],VV[53],list(4,VV[91],VV[92],VV[48],list(2,VV[12],VALUES(0)))),Cnil)))));
	goto L250;}}
L252:
	{object V17= list(2,VV[46],list(3,VV[47],(V1),VV[48]));
	{object V18= (V7);
	VALUES(0) = CAR(V18);}
	VALUES(0) = list(2,VV[43],list(4,VV[44],VV[93],V17,list(3,VV[86],VV[48],list(2,VV[12],VALUES(0)))));}
L250:
	V8= CONS(list(8,VV[40],V13,Cnil,V14,VV[87],Cnil,Cnil,VALUES(0)),(V8));}}
	V10= CDR((V10));
	goto L235;
	}
L231:
	{object V13;
	object V14;                               /*  READER          */
	{object V15= CDR(CDR(CDR(CDR((V7)))));
	V13= CAR(V15);}
	V14= Cnil;
L268:
	if(!((V13)==Cnil)){
	goto L269;}
	goto L264;
L269:
	V14= CAR((V13));
	{object V16= list(2,VV[12],(V14));
	{object V17= list(2,VV[12],CONS((V1),Cnil));
	if(((V4))==Cnil){
	goto L278;}
	{object V18= list(2,VV[46],list(3,VV[47],(V1),VV[48]));
	{object V19= CONS(list(2,VV[53],list(3,VV[54],VV[48],MAKE_FIXNUM(V6))),Cnil);
	{object V20;                              /*  TYPE            */
	{object V21= CDR(CDR(CDR(CDR(CDR(CDR(CDR((V7))))))));
	V20= CAR(V21);}
	if((Ct)==((V20))){
	goto L283;}
	T1= CONS(list(2,VV[46],list(3,VV[47],(V20),VV[53])),Cnil);
	goto L280;
L283:
	T1= Cnil;
	}
L280:
	{object V20= (V7);
	VALUES(0) = CAR(V20);}
	VALUES(0) = list(2,VV[43],list(4,VV[44],VV[95],V18,listA(3,VV[52],V19,append(T1,CONS(list(4,VV[89],VV[96],VV[53],list(4,VV[91],VV[97],VV[48],list(2,VV[12],VALUES(0)))),Cnil)))));
	goto L276;}}
L278:
	{object V20= list(2,VV[46],list(3,VV[47],(V1),VV[48]));
	{object V21= (V7);
	VALUES(0) = CAR(V21);}
	VALUES(0) = list(2,VV[43],list(4,VV[44],VV[98],V20,list(3,VV[86],VV[48],list(2,VV[12],VALUES(0)))));}
L276:
	V8= CONS(list(8,VV[40],V16,Cnil,V17,VV[94],Cnil,Cnil,VALUES(0)),(V8));}}
	V13= CDR((V13));
	goto L268;
	}
L264:
	{object V16;
	object V17;                               /*  WRITER          */
	{object V18= CDR(CDR(CDR(CDR(CDR((V7))))));
	V16= CAR(V18);}
	V17= Cnil;
L294:
	if(!((V16)==Cnil)){
	goto L295;}
	goto L290;
L295:
	V17= CAR((V16));
	{object V19= list(2,VV[12],(V17));
	{object V20= list(2,VV[12],list(2,Cnil,(V1)));
	if(((V4))==Cnil){
	goto L304;}
	{object V21= list(2,VV[46],list(3,VV[47],(V1),VV[48]));
	VALUES(0) = list(2,VV[43],list(4,VV[44],VV[100],V21,list(4,VV[83],VV[48],MAKE_FIXNUM(V6),VV[84])));
	goto L302;}
L304:
	{object V22= list(2,VV[46],list(3,VV[47],(V1),VV[48]));
	{object V23= (V7);
	VALUES(0) = CAR(V23);}
	VALUES(0) = list(2,VV[43],list(4,VV[44],VV[101],V22,list(3,VV[60],list(3,VV[86],VV[48],list(2,VV[12],VALUES(0))),VV[84])));}
L302:
	V8= CONS(list(8,VV[40],V19,Cnil,V20,VV[99],Cnil,Cnil,VALUES(0)),(V8));}}
	V16= CDR((V16));
	goto L294;
	}
L290:
	V5= CDR((V5));
	V6= (V6)+1;
	goto L225;
	}
L222:
	{object V5;                               /*  SCAN            */
	register object V6;                       /*  SLOTD           */
	register object V7;                       /*  METHODS         */
	V5= (V3);
	V6= Cnil;
	V7= Cnil;
L316:
	if(((V5))!=Cnil){
	goto L317;}
	VALUES(0) = (V7);
	goto L314;
L317:
	V6= CAR((V5));
	{object V9;
	object V10;                               /*  ACCESSOR        */
	{object V11= CDR(CDR(CDR((V6))));
	V9= CAR(V11);}
	V10= Cnil;
L326:
	if(!((V9)==Cnil)){
	goto L327;}
	goto L322;
L327:
	V10= CAR((V9));
	{object V12= list(2,VV[12],list(2,VV[60],(V10)));
	{object V13= list(2,VV[12],list(2,Cnil,(V1)));
	{object V14= list(2,VV[46],list(3,VV[47],(V1),VV[48]));
	{object V15= (V6);
	VALUES(0) = CAR(V15);}
	V7= CONS(list(8,VV[40],V12,Cnil,V13,VV[102],Cnil,Cnil,list(2,VV[43],list(4,VV[44],VV[103],V14,list(3,VV[60],list(3,VV[86],VV[48],list(2,VV[12],VALUES(0))),VV[84])))),(V7));}}}
	{object V12= list(2,VV[12],(V10));
	{object V13= list(2,VV[12],CONS((V1),Cnil));
	{object V14= list(2,VV[46],list(3,VV[47],(V1),VV[48]));
	{object V15= (V6);
	VALUES(0) = CAR(V15);}
	V7= CONS(list(8,VV[40],V12,Cnil,V13,VV[104],Cnil,Cnil,list(2,VV[43],list(4,VV[44],VV[105],V14,list(3,VV[86],VV[48],list(2,VV[12],VALUES(0)))))),(V7));}}}
	V9= CDR((V9));
	goto L326;
	}
L322:
	{object V12;
	object V13;                               /*  READER          */
	{object V14= CDR(CDR(CDR(CDR((V6)))));
	V12= CAR(V14);}
	V13= Cnil;
L345:
	if(!((V12)==Cnil)){
	goto L346;}
	goto L341;
L346:
	V13= CAR((V12));
	{object V15= list(2,VV[12],(V13));
	{object V16= list(2,VV[12],CONS((V1),Cnil));
	{object V17= list(2,VV[46],list(3,VV[47],(V1),VV[48]));
	{object V18= (V6);
	VALUES(0) = CAR(V18);}
	V7= CONS(list(8,VV[40],V15,Cnil,V16,VV[106],Cnil,Cnil,list(2,VV[43],list(4,VV[44],VV[107],V17,list(3,VV[86],VV[48],list(2,VV[12],VALUES(0)))))),(V7));}}}
	V12= CDR((V12));
	goto L345;
	}
L341:
	{object V15;
	object V16;                               /*  WRITER          */
	{object V17= CDR(CDR(CDR(CDR(CDR((V6))))));
	V15= CAR(V17);}
	V16= Cnil;
L361:
	if(!((V15)==Cnil)){
	goto L362;}
	goto L357;
L362:
	V16= CAR((V15));
	{object V18= list(2,VV[12],(V16));
	{object V19= list(2,VV[12],list(2,Cnil,(V1)));
	{object V20= list(2,VV[46],list(3,VV[47],(V1),VV[48]));
	{object V21= (V6);
	VALUES(0) = CAR(V21);}
	V7= CONS(list(8,VV[40],V18,Cnil,V19,VV[108],Cnil,Cnil,list(2,VV[43],list(4,VV[44],VV[109],V20,list(3,VV[60],list(3,VV[86],VV[48],list(2,VV[12],VALUES(0))),VV[84])))),(V7));}}}
	V15= CDR((V15));
	goto L361;
	}
L357:
	V5= CDR((V5));
	goto L316;
	}
L314:
	VALUES(0) = nconc(T0,VALUES(0));
	RETURN(1);
	}
}
/*	function definition for COLLECT-SLOTDS                        */
static L9(int narg, object V1, object V2)
{ VT10 VLEX10 CLSR10
TTL:
	{register object V3;                      /*  COLLECTED-SLOTS */
	object V4;                                /*  ALL-CLASS-SLOTS */
	register object V5;                       /*  NEW-SLOT        */
	V3= Cnil;
	V4= Cnil;
	V5= Cnil;
	{register object V6;
	register object V7;                       /*  SC              */
	V6= (V1);
	V7= Cnil;
L380:
	if(!((V6)==Cnil)){
	goto L381;}
	goto L376;
L381:
	V7= CAR((V6));
	(*LK6)(2,(V7),VV[0])                      /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L389;}
	T0= ((V7))->in.in_slots[3];
	(*LK7)(1,(V7))                            /*  CLASS-CLASS-SLOTS*/;
	V4= append(T0,VALUES(0));
	goto L387;
L389:
	V4= ((V7))->in.in_slots[3];
L387:
	{register object V9;
	register object V10;                      /*  SLOT            */
	V9= (V4);
	V10= Cnil;
L397:
	if(!((V9)==Cnil)){
	goto L398;}
	goto L393;
L398:
	V10= CAR((V9));
	{object V12= (V10);
	T0= CAR(V12);}
	VALUES(0) = (VV[146]->s.s_gfdef);
	(*LK8)(4,T0,(V3),VV[110],VALUES(0))       /*  FIND            */;
	V5= VALUES(0);
	if(((V5))==Cnil){
	goto L405;}
	L11(2,(V5),(V10))                         /*  COMBINE-SLOTDS  */;
	goto L403;
L405:
	{object V12= (V10);
	T0= CAR(V12);}
	VALUES(0) = (VV[146]->s.s_gfdef);
	(*LK8)(4,T0,(V2),VV[110],VALUES(0))       /*  FIND            */;
	V5= VALUES(0);
	if(((V5))==Cnil){
	goto L411;}
	(*LK9)(2,(V5),(V2))                       /*  DELETE          */;
	V2= VALUES(0);
	L11(2,(V5),(V10))                         /*  COMBINE-SLOTDS  */;
	V3= CONS((V5),(V3));
	goto L403;
L411:
	(*LK10)(1,(V10))                          /*  COPY-SLOTD      */;
	V3= CONS(VALUES(0),(V3));
L403:
	V9= CDR((V9));
	goto L397;
	}
L393:
	V6= CDR((V6));
	goto L380;
	}
L376:
	{object V6= nreverse((V3));
	VALUES(0) = nconc(V6,(V2));
	RETURN(1);}
	}
}
/*	function definition for UPDATE-LOCAL-SLOTS                    */
static L10(int narg, object V1, object V2)
{ VT11 VLEX11 CLSR11
TTL:
	{register object V3;                      /*  SCAN            */
	V3= (V1);
L429:
	if(((V3))!=Cnil){
	goto L430;}
	VALUES(0) = (V1);
	RETURN(1);
L430:
	{object V5;
	{object V6= CAR((V3));
	T0= CAR(V6);}
	VALUES(0) = (VV[146]->s.s_gfdef);
	(*LK8)(4,T0,(V2),VV[110],VALUES(0))       /*  FIND            */;
	V5= VALUES(0);
	CAR((V3)) = (V5);
	}
	V3= CDR((V3));
	goto L429;
	}
}
/*	function definition for COMBINE-SLOTDS                        */
static L11(int narg, object V1, object V2)
{ VT12 VLEX12 CLSR12
TTL:
	{register object V3;                      /*  NEW-TYPE        */
	object V4;
	register object V5;                       /*  OLD-TYPE        */
	{object V6= CDR(CDR(CDR(CDR(CDR(CDR(CDR((V1))))))));
	V4= CAR(V6);}
	{object V6= CDR(CDR(CDR(CDR(CDR(CDR(CDR((V2))))))));
	V5= CAR(V6);}
	V3= V4;
	{object V6= CDR((V1));
	T0= CAR(V6);}
	{object V6= CDR((V2));
	VALUES(0) = CAR(V6);}
	(*LK11)(2,T0,VALUES(0))                   /*  UNION           */;
	CAR(CDR((V1)))= VALUES(0);
	{object V6= CDR(CDR((V1)));
	VALUES(0) = CAR(V6);}
	if(!((VALUES(0))==((VV[111]->s.s_dbind)))){
	goto L447;}
	{object V6= CDR(CDR((V2)));
	VALUES(0) = CAR(V6);}
	CAR(CDR(CDR((V1))))= VALUES(0);
L447:
	(*LK5)(2,(V3),(V5))                       /*  SUBTYPEP        */;
	if(VALUES(0)==Cnil){
	goto L455;}
	VALUES(0) = (V3);
	goto L453;
L455:
	(*LK5)(2,(V5),(V3))                       /*  SUBTYPEP        */;
	if(VALUES(0)==Cnil){
	goto L458;}
	VALUES(0) = (V5);
	goto L453;
L458:
	if(!(type_of((V5))==t_cons||(V5)==Cnil)){
	goto L461;}
	if(!(type_of((V3))==t_cons||(V3)==Cnil)){
	goto L464;}
	VALUES(0) = CONS(VV[112],append(CDR((V3)),CDR((V5))));
	goto L453;
L464:
	VALUES(0) = listA(3,VV[112],(V3),CDR((V5)));
	goto L453;
L461:
	if(!(type_of((V3))==t_cons||(V3)==Cnil)){
	goto L467;}
	{object V6= CDR((V3));
	VALUES(0) = CONS(VV[112],append(V6,CONS((V5),Cnil)));
	goto L453;}
L467:
	VALUES(0) = list(3,VV[112],(V3),(V5));
L453:
	CAR(CDR(CDR(CDR(CDR(CDR(CDR(CDR((V1)))))))))= VALUES(0);
	VALUES(0) = (V1);
	RETURN(1);
	}
}
/*	function definition for COLLECT-DEFAULT-INITARGS              */
static L12(int narg, object V1, object V2)
{ VT13 VLEX13 CLSR13
TTL:
	{register object V3;
	object V4;                                /*  SC              */
	V3= (V1);
	V4= Cnil;
L473:
	if(!((V3)==Cnil)){
	goto L474;}
	goto L469;
L474:
	V4= CAR((V3));
	(*LK12)(2,(V4),(V2))                      /*  DEFAULT-INITARGS*/;
	V2= VALUES(0);
	V3= CDR((V3));
	goto L473;
	}
L469:
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for BUILD-SLOT-INDEX-TABLE                */
static L13(int narg, object V1)
{ VT14 VLEX14 CLSR14
TTL:
	{object V2;                               /*  TABLE           */
	register int V3;                          /*  I               */
	{int V4= (2)*(length((V1)));
	{int V5= (32)>=(V4)?32:V4;
	VALUES(0) = (VV[156]->s.s_gfdef);
	Lmake_hash_table(4,VV[113],MAKE_FIXNUM(V5),VV[114],VALUES(0))/*  MAKE-HASH-TABLE*/;
	V2= VALUES(0);}}
	V3= 0;
	{register object V4;                      /*  SLOTDSCAN       */
	register object V5;                       /*  SLOTD           */
	V4= (V1);
	V5= CAR((V4));
L490:
	if(((V4))!=Cnil){
	goto L491;}
	VALUES(0) = (V2);
	RETURN(1);
L491:
	{object V7;                               /*  SLOTD-ALLOCATION*/
	{object V8= CDR(CDR(CDR(CDR(CDR(CDR((V5)))))));
	V7= CAR(V8);}
	if(((V7)!= VV[2]))goto L496;
	{object V8;
	{object V9= (V5);
	V8= CAR(V9);}
	siLhash_set(3,(V8),(V2),MAKE_FIXNUM(V3))  /*  HASH-SET        */;
	}
	V3= (V3)+(1);
	goto L494;
L496:
	if(((V7)!= VV[3]))goto L500;
	{object V8;
	{object V9= (V5);
	V8= CAR(V9);}
	siLhash_set(3,(V8),(V2),MAKE_FIXNUM(-1))  /*  HASH-SET        */;
	goto L494;
	}
L500:
	}
L494:
	V4= CDR((V4));
	V5= CAR((V4));
	goto L490;
	}
	}
}
/*	function definition for COMPUTE-CLASS-PRECEDENCE-LIST         */
static L14(int narg, object V1, object V2)
{ VT15 VLEX15 CLSR15
	lex0[0]=V1;                               /*  CLASS-NAME      */
TTL:
	{ int V3;
	object V4;                                /*  CPL             */
	object V5;                                /*  PRECEDENCE-ALIST*/
	V3=L19(3,(V2),Cnil,Cnil)                  /*  WALK-SUPERS     */;
	if (V3==0) goto L508;
	V4= VALUES(0);
	V3--;
	if (V3==0) goto L509;
	V5= VALUES(1);
	V3--;
	goto L510;
L508:
	V4= Cnil;
L509:
	V5= Cnil;
L510:
	{register object V6;                      /*  TAIL            */
	register object V7;                       /*  ELEMENT         */
	register object V8;                       /*  MOVE            */
	V6= (V4);
	V7= Cnil;
	V8= Cnil;
L513:
	if(((V6))!=Cnil){
	goto L515;}
	goto L511;
L515:
	V7= CAR((V6));
	LC16(lex0,3,(V7),(V6),(V5))               /*  MUST-MOVE-P     */;
	V8= VALUES(0);
	if(((V8))==Cnil){
	goto L523;}
	LC17(lex0,3,(V7),(V8),(V5))               /*  FIND-FARTHEST-MOVE*/;
	V8= VALUES(0);
	{object V9;
	V9= CONS((V7),CDR((V8)));
	CDR((V8)) = (V9);
	}
	{object V9;
	V9= CADR((V6));
	CAR((V6)) = (V9);
	}
	{object V9;
	V9= CDDR((V6));
	CDR((V6)) = (V9);
	goto L514;
	}
L523:
	V6= CDR((V6));
L514:
	goto L513;
L511:
	VALUES(0) = (V4);
	RETURN(1);
	}}
}
/*	local function TRANSITIVE-CLOSURE                             */
static LC18(object *lex0,int narg, object V1, object V2)
{ VT16 VLEX16 CLSR16
	lex1[0]=V2;                               /*  PRECEDENCE-ALIST*/
TTL:
	lex1[1]=Cnil;                             /*  CLOSURE         */
	LC15(lex0,lex1,2,(V1),Cnil)               /*  WALK            */;
	VALUES(0) = lex1[1];
	RETURN(1);
}
/*	local function FIND-FARTHEST-MOVE                             */
static LC17(object *lex0,int narg, object V1, object V2, object V3)
{ VT17 VLEX17 CLSR17
TTL:
	{register object V4;
	object V5;                                /*  MUST-PRECEDE    */
	LC18(lex0,2,(V1),(V3))                    /*  TRANSITIVE-CLOSURE*/;
	V4= VALUES(0);
	V5= Cnil;
L542:
	if(!((V4)==Cnil)){
	goto L543;}
	goto L538;
L543:
	V5= CAR((V4));
	{register object x= (V5),V7= (V2);
	while(V7!=Cnil)
	if(x==CAR(V7)){
	VALUES(0) = V7;
	goto L551;
	}else V7=CDR(V7);
	VALUES(0) = Cnil;}
L551:
	if(VALUES(0)==Cnil)goto L550;
	V2= VALUES(0);
	goto L549;
L550:
L549:
	V4= CDR((V4));
	goto L542;
	}
L538:
	VALUES(0) = (V2);
	RETURN(1);
}
/*	local function MUST-MOVE-P                                    */
static LC16(object *lex0,int narg, object V1, object V2, object V3)
{ VT18 VLEX18 CLSR18
TTL:
	{object V4;                               /*  MOVE            */
	V4= Cnil;
	{register object V5;
	object V6;                                /*  MUST-PRECEDE    */
	{register object x= (V1),V7= (V3);
	while(V7!=Cnil)
	if(CAR(V7) != Cnil && 
	x==(CAAR(V7))){
	VALUES(0) = CAR(V7);
	goto L557;
	}else V7=CDR(V7);
	VALUES(0) = Cnil;}
L557:
	V5= CDR(VALUES(0));
	V6= Cnil;
L560:
	if(!((V5)==Cnil)){
	goto L561;}
	VALUES(0) = Cnil;
	RETURN(1);
L561:
	V6= CAR((V5));
	{register object x= (V6),V8= CDR((V2));
	while(V8!=Cnil)
	if(x==CAR(V8)){
	V4= V8;
	goto L569;
	}else V8=CDR(V8);
	V4= Cnil;}
L569:
	if(((V4))==Cnil){
	goto L566;}
	VALUES(0) = (V4);
	RETURN(1);
L566:
	V5= CDR((V5));
	goto L560;
	}
	}
}
/*	local function WALK                                           */
static LC15(object *lex0,object *lex1,int narg, object V1, object V2)
{ VT19 VLEX19 CLSR19
TTL:
	{register object x= (V1),V3= (V2);
	while(V3!=Cnil)
	if(x==CAR(V3)){
	goto L575;
	}else V3=CDR(V3);
	goto L573;}
L575:
	L20(4,lex0[0],(V1),(V2),lex1[0])          /*  CLASS-ORDERING-ERROR*/;
L573:
	{register object V3;
	register object V4;                       /*  PRECEDE         */
	{register object x= (V1),V5= lex1[0];
	while(V5!=Cnil)
	if(CAR(V5) != Cnil && 
	x==(CAAR(V5))){
	VALUES(0) = CAR(V5);
	goto L577;
	}else V5=CDR(V5);
	VALUES(0) = Cnil;}
L577:
	V3= CDR(VALUES(0));
	V4= Cnil;
L580:
	if(!((V3)==Cnil)){
	goto L581;}
	VALUES(0) = Cnil;
	RETURN(1);
L581:
	V4= CAR((V3));
	{register object x= (V4),V6= lex1[1];
	while(V6!=Cnil)
	if(x==CAR(V6)){
	goto L586;
	}else V6=CDR(V6);}
	Ladjoin(2,(V4),lex1[1])                   /*  ADJOIN          */;
	lex1[1]= VALUES(0);
	LC15(lex0,lex1,2,(V4),CONS((V1),(V2)))    /*  WALK            */;
L586:
	V3= CDR((V3));
	goto L580;
	}
}
/*	function definition for WALK-SUPERS                           */
static L19(int narg, object V1, object V2, object V3)
{ VT20 VLEX20 CLSR20
TTL:
	{register object V4;                      /*  PRE             */
	register object V5;                       /*  SUP             */
	register object V6;                       /*  PRECEDENCE      */
	V4= reverse((V1));
	V5= Cnil;
	V6= Cnil;
L598:
	if(((V4))!=Cnil){
	goto L599;}
	VALUES(1) = (V3);
	VALUES(0) = (V2);
	RETURN(2);
L599:
	{object V8;
	V8= CAR((V4));
	V4= CDR((V4));
	V5= (V8);
	}
	if(((V4))==Cnil){
	goto L607;}
	{register object x= (V5),V8= (V3);
	while(V8!=Cnil)
	if(CAR(V8) != Cnil && 
	x==(CAAR(V8))){
	V6= CAR(V8);
	goto L613;
	}else V8=CDR(V8);
	V6= Cnil;}
L613:
	if(((V6))==Cnil){
	goto L611;}
	{object V8= CAR((V6));
	(*LK11)(2,(V4),(V6))                      /*  UNION           */;
	V6= CONS(V8,VALUES(0));}
	goto L607;
L611:
	V3= CONS(CONS((V5),(V4)),(V3));
L607:
	{ int V8;
	V8=L19(3,((V5))->in.in_slots[1],(V2),(V3))/*  WALK-SUPERS     */;
	if (V8>0) {
	V2= VALUES(0);
	V8--;
	} else {
	V2= Cnil;}
	if (V8>0) {
	V3= VALUES(1);
	} else {
	V3= Cnil;}
	
	}
	Ladjoin(2,(V5),(V2))                      /*  ADJOIN          */;
	V2= VALUES(0);
	goto L598;
	}
}
/*	function definition for CLASS-ORDERING-ERROR                  */
static L20(int narg, object V1, object V2, object V3, object V4)
{ VT21 VLEX21 CLSR21
TTL:
	{register object x= (V2),V5= reverse((V3));
	while(V5!=Cnil)
	if(x==CAR(V5)){
	VALUES(0) = V5;
	goto L625;
	}else V5=CDR(V5);
	VALUES(0) = Cnil;}
L625:
	V3= CONS((V2),reverse(VALUES(0)));
	{register object V5;                      /*  EXPLANATIONS    */
	V5= Cnil;
	{register object V6;                      /*  TAIL            */
	V6= (V3);
L628:
	if((CDR((V6)))!=Cnil){
	goto L629;}
	goto L626;
L629:
	{register object V8;                      /*  AFTER           */
	register object V9;                       /*  BEFORE          */
	V8= CADR((V6));
	V9= CAR((V6));
	{register object x= (V8),V10= ((V9))->in.in_slots[1];
	while(V10!=Cnil)
	if(x==CAR(V10)){
	goto L637;
	}else V10=CDR(V10);
	goto L636;}
L637:
	LC21(1,(V9))                              /*  PRETTY          */;
	T0= VALUES(0);
	LC21(1,(V8))                              /*  PRETTY          */;
	T1= VALUES(0);
	LC21(1,(V8))                              /*  PRETTY          */;
	T2= VALUES(0);
	LC21(1,(V9))                              /*  PRETTY          */;
	Lformat(6,Cnil,VV[115],T0,T1,T2,VALUES(0))/*  FORMAT          */;
	V5= CONS(VALUES(0),(V5));
	goto L632;
L636:
	{register object V10;
	register object V11;                      /*  COMMON-PRECEDE  */
	{register object x= (V8),V12= (V4);
	while(V12!=Cnil)
	if(CAR(V12) != Cnil && 
	x==(CAAR(V12))){
	VALUES(0) = CAR(V12);
	goto L645;
	}else V12=CDR(V12);
	VALUES(0) = Cnil;}
L645:
	{object V12= CDR(VALUES(0));
	{register object x= (V9),V13= (V4);
	while(V13!=Cnil)
	if(CAR(V13) != Cnil && 
	x==(CAAR(V13))){
	VALUES(0) = CAR(V13);
	goto L646;
	}else V13=CDR(V13);
	VALUES(0) = Cnil;}
L646:
	(*LK13)(2,V12,CDR(VALUES(0)))             /*  INTERSECTION    */;
	V10= VALUES(0);}
	V11= Cnil;
L649:
	if(!((V10)==Cnil)){
	goto L650;}
	goto L632;
L650:
	V11= CAR((V10));
	{register object x= (V9),V13= ((V11))->in.in_slots[1];
	while(V13!=Cnil)
	if(x==CAR(V13)){
	VALUES(0) = V13;
	goto L658;
	}else V13=CDR(V13);
	VALUES(0) = Cnil;}
L658:
	{register object x= (V8),V13= VALUES(0);
	while(V13!=Cnil)
	if(x==CAR(V13)){
	goto L657;
	}else V13=CDR(V13);
	goto L655;}
L657:
	LC21(1,(V9))                              /*  PRETTY          */;
	T0= VALUES(0);
	LC21(1,(V8))                              /*  PRETTY          */;
	T1= VALUES(0);
	LC21(1,(V11))                             /*  PRETTY          */;
	T2= VALUES(0);
	{object V13;
	object V14= ((V11))->in.in_slots[1];
	if(V14==Cnil){
	VALUES(0) = Cnil;
	goto L663;}
	T3=V13=CONS(Cnil,Cnil);
L664:
	LC21(1,CAR(V14))                          /*  PRETTY          */;
	CAR(V13)= VALUES(0);
	if((V14=CDR(V14))==Cnil){
	VALUES(0) = T3;
	goto L663;}
	V13=CDR(V13)=CONS(Cnil,Cnil);
	goto L664;}
L663:
	Lformat(6,Cnil,VV[116],T0,T1,T2,VALUES(0))/*  FORMAT          */;
	V5= CONS(VALUES(0),(V5));
L655:
	V10= CDR((V10));
	goto L649;
	}
	}
L632:
	V6= CDR((V6));
	goto L628;
	}
L626:
	{object V6;
	object V7= (V3);
	if(V7==Cnil){
	T0= Cnil;
	goto L673;}
	T1=V6=CONS(Cnil,Cnil);
L674:
	LC21(1,CAR(V7))                           /*  PRETTY          */;
	CAR(V6)= VALUES(0);
	if((V7=CDR(V7))==Cnil){
	T0= T1;
	goto L673;}
	V6=CDR(V6)=CONS(Cnil,Cnil);
	goto L674;}
L673:
	RETURN(Lerror(4,VV[117],(V1),T0,reverse((V5)))/*  ERROR       */);
	}
}
/*	local function PRETTY                                         */
static LC21(int narg, object V1)
{ VT22 VLEX22 CLSR22
TTL:
	VALUES(0) = ((V1))->in.in_slots[0];
	if(VALUES(0)==Cnil)goto L676;
	RETURN(1);
L676:
	VALUES(0) = (V1);
	RETURN(1);
}
static LKF13(int narg, ...) {TRAMPOLINK(VV[160],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[154],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[152],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[149],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[148],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[147],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[145],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[144],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[140],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[31],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[136],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[135],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[134],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[11],&LK0);}
