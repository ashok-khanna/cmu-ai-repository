
#include "standard.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	funcall(2,VV[179]->s.s_gfdef,VV[0])       /*  FIND-CLASS      */;
	funcall(9,VV[15]->s.s_gfdef,VALUES(0),VV[1],VV[2],Cnil,Cnil,VV[3],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	VV[180] = make_cfun(LC1,Cnil,&Cblock);
	VALUES(0) = VV[180];
	funcall(8,VV[181]->s.s_gfdef,VV[4],Cnil,VV[5],VV[6],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[182] = make_cfun(LC2,Cnil,&Cblock);
	VALUES(0) = VV[182];
	funcall(8,VV[181]->s.s_gfdef,VV[8],Cnil,VV[9],VV[10],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	funcall(2,VV[179]->s.s_gfdef,VV[1])       /*  FIND-CLASS      */;
	VV[183] = make_cfun(LC3,Cnil,&Cblock);
	VALUES(0) = VV[183];
	funcall(8,VV[181]->s.s_gfdef,VV[12],Cnil,VV[13],VV[14],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[184] = make_cfun(LC6,Cnil,&Cblock);
	VALUES(0) = VV[184];
	funcall(8,VV[181]->s.s_gfdef,VV[15],Cnil,VV[16],VV[17],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	MF0(VV[185],L7);
	(void)putprop(VV[185],VV[Vdeb185],VV[186]);
	funcall(2,VV[179]->s.s_gfdef,VV[1])       /*  FIND-CLASS      */;
	funcall(9,VV[15]->s.s_gfdef,VALUES(0),VV[32],VV[33],VV[34],Cnil,VV[35],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	VV[187] = make_cfun(LC8,Cnil,&Cblock);
	VALUES(0) = VV[187];
	funcall(8,VV[181]->s.s_gfdef,VV[4],Cnil,VV[36],VV[6],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[188] = make_cfun(LC9,Cnil,&Cblock);
	VALUES(0) = VV[188];
	funcall(8,VV[181]->s.s_gfdef,VV[8],Cnil,VV[37],VV[10],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[189] = make_cfun(LC10,Cnil,&Cblock);
	VALUES(0) = VV[189];
	funcall(8,VV[181]->s.s_gfdef,VV[38],Cnil,VV[39],VV[40],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[190] = make_cfun(LC11,Cnil,&Cblock);
	VALUES(0) = VV[190];
	funcall(8,VV[181]->s.s_gfdef,VV[41],Cnil,VV[42],VV[43],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[191] = make_cfun(LC12,Cnil,&Cblock);
	VALUES(0) = VV[191];
	funcall(8,VV[181]->s.s_gfdef,VV[44],Cnil,VV[45],VV[46],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[192] = make_cfun(LC13,Cnil,&Cblock);
	VALUES(0) = VV[192];
	funcall(8,VV[181]->s.s_gfdef,VV[48],Cnil,VV[49],VV[40],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[193] = make_cfun(LC14,Cnil,&Cblock);
	VALUES(0) = VV[193];
	funcall(8,VV[181]->s.s_gfdef,VV[50],Cnil,VV[51],VV[43],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[194] = make_cfun(LC15,Cnil,&Cblock);
	VALUES(0) = VV[194];
	funcall(8,VV[181]->s.s_gfdef,VV[52],Cnil,VV[53],VV[46],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	funcall(2,VV[179]->s.s_gfdef,VV[32])      /*  FIND-CLASS      */;
	funcall(2,VV[179]->s.s_gfdef,VV[32])      /*  FIND-CLASS      */;
	T0= VALUES(0);
	funcall(2,VV[179]->s.s_gfdef,Ct)          /*  FIND-CLASS      */;
	{object V1= CONS(VALUES(0),Cnil);
	funcall(2,VV[179]->s.s_gfdef,Ct)          /*  FIND-CLASS      */;
	funcall(18,VV[140]->s.s_gfdef,T0,VV[18],VV[54],VV[19],V1,VV[20],Cnil,VV[24],CONS(VALUES(0),Cnil),VV[21],Cnil,VV[22],Cnil,VV[25],Cnil,VV[26],VV[55])/*  MAKE-INSTANCE*/;}
	VV[195] = make_cfun(LC16,Cnil,&Cblock);
	VALUES(0) = VV[195];
	funcall(8,VV[181]->s.s_gfdef,VV[4],Cnil,VV[56],VV[57],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[196] = make_cfun(LC17,Cnil,&Cblock);
	VALUES(0) = VV[196];
	funcall(8,VV[181]->s.s_gfdef,VV[65],Cnil,VV[66],VV[67],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[197] = make_cfun(LC18,Cnil,&Cblock);
	VALUES(0) = VV[197];
	funcall(8,VV[181]->s.s_gfdef,VV[68],Cnil,VV[69],VV[70],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[198] = make_cfun(LC19,Cnil,&Cblock);
	VALUES(0) = VV[198];
	funcall(8,VV[181]->s.s_gfdef,VV[71],Cnil,VV[72],VV[73],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[199] = make_cfun(LC20,Cnil,&Cblock);
	VALUES(0) = VV[199];
	funcall(8,VV[181]->s.s_gfdef,VV[74],Cnil,VV[75],VV[76],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[200] = make_cfun(LC25,Cnil,&Cblock);
	VALUES(0) = VV[200];
	funcall(8,VV[181]->s.s_gfdef,VV[78],Cnil,VV[79],VV[80],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[201] = make_cfun(LC26,Cnil,&Cblock);
	VALUES(0) = VV[201];
	funcall(8,VV[181]->s.s_gfdef,VV[83],Cnil,VV[84],VV[85],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[202] = make_cfun(LC28,Cnil,&Cblock);
	VALUES(0) = VV[202];
	funcall(8,VV[181]->s.s_gfdef,VV[86],Cnil,VV[87],VV[88],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[203] = make_cfun(LC29,Cnil,&Cblock);
	VALUES(0) = VV[203];
	funcall(8,VV[181]->s.s_gfdef,VV[90],Cnil,VV[91],VV[92],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	MF0(VV[204],L30);
	(void)putprop(VV[204],VV[Vdeb204],VV[186]);
	VV[205] = make_cfun(LC32,Cnil,&Cblock);
	VALUES(0) = VV[205];
	funcall(8,VV[181]->s.s_gfdef,VV[93],Cnil,VV[94],VV[95],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[206] = make_cfun(LC33,Cnil,&Cblock);
	VALUES(0) = VV[206];
	funcall(8,VV[181]->s.s_gfdef,VV[97],Cnil,VV[98],VV[99],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[207] = make_cfun(LC34,Cnil,&Cblock);
	VALUES(0) = VV[207];
	funcall(8,VV[181]->s.s_gfdef,VV[100],Cnil,VV[101],VV[102],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	funcall(2,VV[179]->s.s_gfdef,VV[32])      /*  FIND-CLASS      */;
	T0= VALUES(0);
	funcall(2,VV[179]->s.s_gfdef,VV[0])       /*  FIND-CLASS      */;
	T1= VALUES(0);
	funcall(2,VV[179]->s.s_gfdef,VV[54])      /*  FIND-CLASS      */;
	siLinstance_set(3,T0,MAKE_FIXNUM(1),list(2,T1,VALUES(0)))/*  INSTANCE-SET*/;
	VV[208] = make_cfun(LC35,Cnil,&Cblock);
	VALUES(0) = VV[208];
	funcall(8,VV[181]->s.s_gfdef,VV[47],Cnil,VV[110],VV[111],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[209] = make_cfun(LC36,Cnil,&Cblock);
	VALUES(0) = VV[209];
	funcall(8,VV[181]->s.s_gfdef,VV[47],Cnil,VV[112],VV[113],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	MF0(VV[210],L37);
	(void)putprop(VV[210],VV[Vdeb210],VV[186]);
	MF0(VV[211],L38);
	(void)putprop(VV[211],VV[Vdeb211],VV[186]);
	MF0(VV[212],L39);
	(void)putprop(VV[212],VV[Vdeb212],VV[186]);
	MF0(VV[213],L40);
	(void)putprop(VV[213],VV[Vdeb213],VV[186]);
	VV[214] = make_cfun(LC41,Cnil,&Cblock);
	VALUES(0) = VV[214];
	funcall(8,VV[181]->s.s_gfdef,VV[118],Cnil,VV[119],VV[120],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[215] = make_cfun(LC42,Cnil,&Cblock);
	VALUES(0) = VV[215];
	funcall(8,VV[181]->s.s_gfdef,VV[123],Cnil,VV[124],VV[125],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	init_keywords(2, L43keys, &Cblock);
	VV[216] = make_cfun(LC45,Cnil,&Cblock);
	VALUES(0) = VV[216];
	funcall(8,VV[181]->s.s_gfdef,VV[83],Cnil,VV[126],VV[127],Cnil,VV[128],VALUES(0))/*  INSTALL-METHOD*/;
	VV[217] = make_cfun(LC46,Cnil,&Cblock);
	VV[218] = make_cfun(LC47,Cnil,&Cblock);
	VALUES(0) = VV[218];
	funcall(8,VV[181]->s.s_gfdef,VV[133],Cnil,VV[134],VV[135],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[219] = make_cfun(LC49,Cnil,&Cblock);
	VALUES(0) = VV[219];
	funcall(8,VV[181]->s.s_gfdef,VV[140],Cnil,VV[141],VV[142],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[220] = make_cfun(LC50,Cnil,&Cblock);
	VALUES(0) = VV[220];
	funcall(8,VV[181]->s.s_gfdef,VV[100],Cnil,VV[143],VV[144],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	funcall(2,VV[179]->s.s_gfdef,VV[32])      /*  FIND-CLASS      */;
	funcall(9,VV[15]->s.s_gfdef,VALUES(0),VV[147],Cnil,Cnil,Cnil,Cnil,Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[179]->s.s_gfdef,VV[147])     /*  FIND-CLASS      */;
	funcall(2,VV[179]->s.s_gfdef,VV[32])      /*  FIND-CLASS      */;
	funcall(9,VV[15]->s.s_gfdef,VALUES(0),VV[148],VV[149],VV[150],Cnil,VV[151],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	VV[221] = make_cfun(LC51,Cnil,&Cblock);
	VALUES(0) = VV[221];
	funcall(8,VV[181]->s.s_gfdef,VV[152],Cnil,VV[153],VV[40],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[222] = make_cfun(LC52,Cnil,&Cblock);
	VALUES(0) = VV[222];
	funcall(8,VV[181]->s.s_gfdef,VV[154],Cnil,VV[155],VV[43],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[223] = make_cfun(LC53,Cnil,&Cblock);
	VALUES(0) = VV[223];
	funcall(8,VV[181]->s.s_gfdef,VV[156],Cnil,VV[157],VV[40],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[224] = make_cfun(LC54,Cnil,&Cblock);
	VALUES(0) = VV[224];
	funcall(8,VV[181]->s.s_gfdef,VV[158],Cnil,VV[159],VV[43],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[225] = make_cfun(LC55,Cnil,&Cblock);
	VALUES(0) = VV[225];
	funcall(8,VV[181]->s.s_gfdef,VV[160],Cnil,VV[161],VV[40],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[226] = make_cfun(LC56,Cnil,&Cblock);
	VALUES(0) = VV[226];
	funcall(8,VV[181]->s.s_gfdef,VV[163],Cnil,VV[164],VV[43],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[227] = make_cfun(LC57,Cnil,&Cblock);
	VALUES(0) = VV[227];
	funcall(8,VV[181]->s.s_gfdef,VV[165],Cnil,VV[166],VV[40],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[228] = make_cfun(LC58,Cnil,&Cblock);
	VALUES(0) = VV[228];
	funcall(8,VV[181]->s.s_gfdef,VV[168],Cnil,VV[169],VV[43],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[229] = make_cfun(LC59,Cnil,&Cblock);
	VALUES(0) = VV[229];
	funcall(8,VV[181]->s.s_gfdef,VV[170],Cnil,VV[171],VV[40],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[230] = make_cfun(LC60,Cnil,&Cblock);
	VALUES(0) = VV[230];
	funcall(8,VV[181]->s.s_gfdef,VV[173],Cnil,VV[174],VV[43],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[231] = make_cfun(LC61,Cnil,&Cblock);
	VALUES(0) = VV[231];
	funcall(8,VV[181]->s.s_gfdef,VV[175],Cnil,VV[176],VV[40],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[232] = make_cfun(LC62,Cnil,&Cblock);
	VALUES(0) = VV[232];
	funcall(8,VV[181]->s.s_gfdef,VV[177],Cnil,VV[178],VV[43],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	funcall(2,VV[179]->s.s_gfdef,VV[148])     /*  FIND-CLASS      */;
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	local function CLOSURE                                        */
static LC62(int narg, object V1, object V2)
{ VT3 VLEX3 CLSR3
	VALUES(0) = ((V2))->in.in_slots[0]=((V1));
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC61(int narg, object V1)
{ VT4 VLEX4 CLSR4
	{object V2;                               /*  VAL             */
	V2= ((V1))->in.in_slots[0];
	if(!(((V2))!=OBJNULL)){
	goto L111;}
	VALUES(0) = (V2);
	RETURN(1);
L111:
	RETURN((*LK0)(3,((V1))->in.in_class,(V1),VV[175])/*  SLOT-UNBOUND*/);
	}
}
/*	local function CLOSURE                                        */
static LC60(int narg, object V1, object V2)
{ VT5 VLEX5 CLSR5
	VALUES(0) = ((V2))->in.in_slots[1]=((V1));
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC59(int narg, object V1)
{ VT6 VLEX6 CLSR6
	{object V2;                               /*  VAL             */
	V2= ((V1))->in.in_slots[1];
	if(!(((V2))!=OBJNULL)){
	goto L115;}
	VALUES(0) = (V2);
	RETURN(1);
L115:
	RETURN((*LK0)(3,((V1))->in.in_class,(V1),VV[172])/*  SLOT-UNBOUND*/);
	}
}
/*	local function CLOSURE                                        */
static LC58(int narg, object V1, object V2)
{ VT7 VLEX7 CLSR7
	VALUES(0) = ((V2))->in.in_slots[2]=((V1));
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC57(int narg, object V1)
{ VT8 VLEX8 CLSR8
	{object V2;                               /*  VAL             */
	V2= ((V1))->in.in_slots[2];
	if(!(((V2))!=OBJNULL)){
	goto L119;}
	VALUES(0) = (V2);
	RETURN(1);
L119:
	RETURN((*LK0)(3,((V1))->in.in_class,(V1),VV[167])/*  SLOT-UNBOUND*/);
	}
}
/*	local function CLOSURE                                        */
static LC56(int narg, object V1, object V2)
{ VT9 VLEX9 CLSR9
	VALUES(0) = ((V2))->in.in_slots[3]=((V1));
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC55(int narg, object V1)
{ VT10 VLEX10 CLSR10
	{object V2;                               /*  VAL             */
	V2= ((V1))->in.in_slots[3];
	if(!(((V2))!=OBJNULL)){
	goto L123;}
	VALUES(0) = (V2);
	RETURN(1);
L123:
	RETURN((*LK0)(3,((V1))->in.in_class,(V1),VV[162])/*  SLOT-UNBOUND*/);
	}
}
/*	local function CLOSURE                                        */
static LC54(int narg, object V1, object V2)
{ VT11 VLEX11 CLSR11
	VALUES(0) = ((V2))->in.in_slots[6]=((V1));
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC53(int narg, object V1)
{ VT12 VLEX12 CLSR12
	{object V2;                               /*  VAL             */
	V2= ((V1))->in.in_slots[6];
	if(!(((V2))!=OBJNULL)){
	goto L127;}
	VALUES(0) = (V2);
	RETURN(1);
L127:
	RETURN((*LK0)(3,((V1))->in.in_class,(V1),VV[156])/*  SLOT-UNBOUND*/);
	}
}
/*	local function CLOSURE                                        */
static LC52(int narg, object V1, object V2)
{ VT13 VLEX13 CLSR13
	VALUES(0) = ((V2))->in.in_slots[7]=((V1));
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC51(int narg, object V1)
{ VT14 VLEX14 CLSR14
	{object V2;                               /*  VAL             */
	V2= ((V1))->in.in_slots[7];
	if(!(((V2))!=OBJNULL)){
	goto L131;}
	VALUES(0) = (V2);
	RETURN(1);
L131:
	RETURN((*LK0)(3,((V1))->in.in_class,(V1),VV[152])/*  SLOT-UNBOUND*/);
	}
}
/*	local function CLOSURE                                        */
static LC50(int narg, object V1)
{ VT15 VLEX15 CLSR15
	{object V2;                               /*  SLOTDS          */
	V2= (((V1))->in.in_class)->in.in_slots[3];
	Lformat(4,Ct,VV[145],(V1),(((V1))->in.in_class)->in.in_slots[0])/*  FORMAT*/;
	{register object V3;                      /*  SCAN            */
	register int V4;                          /*  I               */
	V4= 0;
	V3= (V2);
L138:
	if(((V3))!=Cnil){
	goto L139;}
	goto L133;
L139:
	{object V6= CAR((V3));
	VALUES(0) = CAR(V6);}
	print(VALUES(0),Cnil);
	princ_str(":	",Cnil);
	{object V6;
	{object V7= CAR((V3));
	V6= CAR(V7);}
	{register object x= (V6),V7= VV[146];
	while(V7!=Cnil)
	if(eql(x, CAR(V7))){
	goto L149;
	}else V7=CDR(V7);
	goto L148;}
L149:
	princ_char(40,Cnil);
	{register object V7;                      /*  SCAN            */
	object V8;                                /*  E               */
	V7= ((V1))->in.in_slots[V4];
	V8= CAR((V7));
L155:
	if(((V7))!=Cnil){
	goto L156;}
	goto L151;
L156:
	prin1(((V8))->in.in_slots[0],Cnil);
	if((CDR((V7)))==Cnil){
	goto L160;}
	princ_char(32,Cnil);
L160:
	V7= CDR((V7));
	V8= CAR((V7));
	goto L155;
	}
L151:
	princ_char(41,Cnil);
	goto L145;
L148:
	VALUES(0) = ((V1))->in.in_slots[V4];
	prin1(VALUES(0),Cnil);
	}
L145:
	V3= CDR((V3));
	V4= (V4)+1;
	goto L138;
	}
	}
L133:
	VALUES(0) = (V1);
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC49(int narg, object V1, ...)
{ VT16 VLEX16 CLSR16
	{register object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	(*LK1)(2,(V1),(V2))                       /*  DEFAULT-INITARGS*/;
	V2= VALUES(0);
	LC48(1,(V2))                              /*  SEARCH-ALLOW-OTHER-KEYS*/;
	if(VALUES(0)!=Cnil){
	goto L175;}
	L37(2,(V1),(V2))                          /*  CHECK-INITARGS  */;
L175:
	{object V3;                               /*  INSTANCE        */
	(*LK2)(1,(V1))                            /*  ALLOCATE-INSTANCE*/;
	V3= VALUES(0);
	VALUES(0) = (VV[83]->s.s_gfdef);
	Lapply(3,VALUES(0),(V3),(V2))             /*  APPLY           */;
	VALUES(0) = (V3);
	RETURN(1);
	}
	}
}
/*	local function CLOSURE                                        */
static LC47(int narg, object V1, object V2)
{ VT17 VLEX17 CLSR17
	{register object V3;                      /*  DEFAULT-SUPERCLASSES*/
	V3= (V2);
	if(((V2))==Cnil){
	goto L183;}
	{register object V4;
	object V5;                                /*  SUPER           */
	V4= CDR((V2));
	V5= Cnil;
L189:
	if(!((V4)==Cnil)){
	goto L190;}
	goto L185;
L190:
	V5= CAR((V4));
	(*LK3)(2,(V5),VV[136])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L195;}
	Lerror(3,VV[137],(V1),(V5))               /*  ERROR           */;
L195:
	V4= CDR((V4));
	goto L189;
	}
L185:
	(*LK4)(1,CAR((V2)))                       /*  CLASS-OF        */;
	if(!(((VALUES(0))->in.in_slots[0])==(VV[138]))){
	goto L202;}
	(*LK5)(1,VV[54])                          /*  FIND-CLASS      */;
	V3= CONS(VALUES(0),(V3));
	goto L181;
L202:
	{object V4;
	V4= ((((V1))->in.in_slots[0])==(VV[54])?Ct:Cnil);
	if(((V4))==Cnil){
	goto L211;}
	if(((V4))!=Cnil){
	goto L181;}
	goto L208;
L211:
	{object V5;
	V5= ((((V1))->in.in_slots[0])==(VV[139])?Ct:Cnil);
	if(((V5))==Cnil){
	goto L215;}
	if(((V5))!=Cnil){
	goto L181;}
	goto L208;
L215:
	VALUES(0) = VV[217];
	(*LK6)(2,VALUES(0),(V2))                  /*  SOME            */;
	if(VALUES(0)!=Cnil){
	goto L181;}
	}
	}
L208:
	(*LK5)(1,VV[54])                          /*  FIND-CLASS      */;
	T0= VALUES(0);
	V3= nreverse(CONS(T0,nreverse((V2))));
	goto L181;
L183:
	(*LK5)(1,VV[54])                          /*  FIND-CLASS      */;
	V3= CONS(VALUES(0),Cnil);
L181:
	VALUES(0) = (V3);
	RETURN(1);
	}
}
/*	local function CLOSURE                                        */
static LC46(int narg, object V1)
{ VT18 VLEX18 CLSR18
	RETURN((*LK7)(2,((V1))->in.in_slots[0],VV[54])/*  SUBTYPEP    */);
}
/*	local function CLOSURE                                        */
static LC45(int narg, object V1, ...)
{ VT19 VLEX19 CLSR19
	{object V2;
	va_list args; va_start(args, V1);
	lex0[0]=V1;
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	lex0[1]=V2;
	{object V3;
	object V4;
	V3= CAR((VV[129]->s.s_dbind));
	V4= CDR((VV[129]->s.s_dbind));
	lex0[2]=V3;                               /*  .NEXT-METHOD.   */
	bds_bind(VV[129],V4);                     /*  *NEXT-METHODS*  */
	{ int V5, i=0;
	T0= lex0[0];
	T1= lex0[1];
	V5=length(T1);
	VALUES(i++)=T0;
	V5+=i;
	for (; i<V5;i++,T1=CDR(T1))
		VALUES(i)=CAR(T1);
	{ 
	object *args = &VALUES(1);
	object V6;
	int narg = V5;
	V6=VALUES(0);
	{object V7;
	object V8;
	narg -=1;
	{ object keyvars[4];
	parse_key(narg,args,2,L43keys,keyvars,OBJNULL,TRUE);
	V7= keyvars[0];
	V8= keyvars[1];
	}
	LC44(lex0,0)                              /*  CALL-NEXT-METHOD*/;
	{register object V9;                      /*  SUPERCLASSES    */
	object V10;                               /*  CPL             */
	(*LK8)(2,(V6),(V8))                       /*  CLASS-DEFAULT-DIRECT-SUPERCLASSES*/;
	V9= VALUES(0);
	if((CDR((V9)))==Cnil){
	goto L234;}
	if(!(((CAR((V9)))->in.in_slots[0])==(VV[54]))){
	goto L231;}
	goto L232;
L234:
	goto L231;
L232:
	{object V11= CAR((V9));
	(*LK5)(1,VV[54])                          /*  FIND-CLASS      */;
	T2= VALUES(0);
	(*LK9)(2,(V7),CDR((V9)))                  /*  COMPUTE-CLASS-PRECEDENCE-LIST*/;
	(*LK10)(2,T2,VALUES(0))                   /*  REMOVE          */;
	V10= CONS(V11,VALUES(0));
	goto L229;}
L231:
	(*LK9)(2,(V7),(V9))                       /*  COMPUTE-CLASS-PRECEDENCE-LIST*/;
	V10= VALUES(0);
L229:
	(*LK11)(3,(V9),(V6),VV[130])              /*  (SETF SLOT-VALUE)*/;
	(*LK11)(3,(V10),(V6),VV[131])             /*  (SETF SLOT-VALUE)*/;
	}
	{int V9;
	VALUES(0)=(V6);
	V9=1;
	bds_unwind1;
	RETURN(V9);}
	}
	}
	}
	}
	}
}
/*	local function CLOSURE                                        */
static LC42(int narg, object V1, object V2)
{ VT20 VLEX20 CLSR20
	{object V3;                               /*  INSTANCE        */
	object V4;                                /*  SLOT-NAME       */
	object V5;                                /*  NEW-VALUE       */
	V3= CADADR((V2));
	V4= CADDR(CADR((V2)));
	V5= CADDR((V2));
	(*LK12)(1,(V4))                           /*  REDUCE-CONSTANT */;
	VALUES(0) = list(4,VV[121],(V3),list(2,VV[122],VALUES(0)),(V5));
	RETURN(1);
	}
}
/*	local function CLOSURE                                        */
static LC41(int narg, object V1, object V2)
{ VT21 VLEX21 CLSR21
	{object V3;                               /*  INSTANCE        */
	object V4;                                /*  SLOT-NAME       */
	V3= CADR((V2));
	V4= CADDR((V2));
	(*LK12)(1,(V4))                           /*  REDUCE-CONSTANT */;
	VALUES(0) = listA(4,VV[121],(V3),list(2,VV[122],VALUES(0)),CDDDR((V2)));
	RETURN(1);
	}
}
/*	local function CLOSURE                                        */
static LC36(int narg, object V1, object V2)
{ VT22 VLEX22 CLSR22
	{register object V3;                      /*  SCAN            */
	object V4;                                /*  DEFAULTS        */
	(*LK13)(1,(V1))                           /*  DEFAULT-INITARGS-OF*/;
	V3= reverse(VALUES(0));
	V4= Cnil;
L250:
	if(((V3))!=Cnil){
	goto L251;}
	VALUES(0) = nconc((V2),nreverse((V4)));
	RETURN(1);
L251:
	{register object V6;                      /*  ISCAN           */
	V6= (V2);
L258:
	if(((V6))!=Cnil){
	goto L259;}
	goto L256;
L259:
	if(!((CAR((V6)))==(CADR((V3))))){
	goto L262;}
	goto L254;
L262:
	V6= CDDR((V6));
	goto L258;
	}
L256:
	V4= nconc((V4),list(2,CAR((V3)),CADR((V3))));
L254:
	V3= CDDR((V3));
	goto L250;
	}
}
/*	local function DEFAULT-INITARGS                               */
static LC35(int narg, object V1, object V2)
{ VT23 VLEX23 CLSR23
	VALUES(0) = (V2);
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC34(int narg, object V1)
{ VT24 VLEX24 CLSR24
	{register object V2;                      /*  CLASS           */
	object V3;                                /*  SLOTDS          */
	V2= ((V1))->in.in_class;
	V3= ((V2))->in.in_slots[3];
	Lformat(4,Ct,VV[103],(V1),((V2))->in.in_slots[0])/*  FORMAT   */;
	if(((V3))==Cnil){
	goto L276;}
	princ_char(10,Cnil);
	Lformat(2,Ct,VV[104])                     /*  FORMAT          */;
	{register object V4;                      /*  SCAN            */
	register int V5;                          /*  I               */
	object V6;                                /*  SV              */
	V5= 0;
	V4= (V3);
	V6= Cnil;
L283:
	if(((V4))!=Cnil){
	goto L284;}
	goto L276;
L284:
	V6= ((V1))->in.in_slots[V5];
	{object V8= CAR((V4));
	T0= CAR(V8);}
	if(!(((V6))!=OBJNULL)){
	goto L293;}
	VALUES(0) = (V6);
	goto L291;
L293:
	VALUES(0) = VV[106];
L291:
	Lformat(4,Ct,VV[105],T0,VALUES(0))        /*  FORMAT          */;
	V4= CDR((V4));
	V5= (V5)+1;
	goto L283;
	}
L276:
	(*LK3)(2,(V2),VV[32])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L272;}
	{object V4;                               /*  CLASS-CLASS-SLOTS*/
	(*LK14)(1,(V2))                           /*  CLASS-CLASS-SLOTS*/;
	V4= VALUES(0);
	if(((V4))==Cnil){
	goto L272;}
	princ_char(10,Cnil);
	Lformat(2,Ct,VV[107])                     /*  FORMAT          */;
	{register object V5;
	object V6;                                /*  SCAN            */
	V5= (V4);
	V6= Cnil;
L309:
	if(!((V5)==Cnil)){
	goto L310;}
	goto L272;
L310:
	V6= CAR((V5));
	{object V8;                               /*  SLOTD-NAME      */
	object V9;                                /*  SV              */
	{object V10= (V6);
	V8= CAR(V10);}
	(*LK15)(1,(V2))                           /*  CLASS-CLASS-SLOTS-VALUES*/;
	{register object x= (V8),V10= VALUES(0);
	while(V10!=Cnil)
	if(CAR(V10) != Cnil && 
	x==(CAAR(V10))){
	VALUES(0) = CAR(V10);
	goto L318;
	}else V10=CDR(V10);
	VALUES(0) = Cnil;}
L318:
	V9= CDR(VALUES(0));
	if(!(((V9))!=OBJNULL)){
	goto L322;}
	VALUES(0) = (V9);
	goto L320;
L322:
	VALUES(0) = VV[109];
L320:
	Lformat(4,Ct,VV[108],(V8),VALUES(0))      /*  FORMAT          */;
	}
	V5= CDR((V5));
	goto L309;
	}
	}
	}
L272:
	VALUES(0) = (V1);
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC33(int narg, object V1, object V2, object V3, object V4, ...)
{ VT25 VLEX25 CLSR25
	{object V5;
	va_list args; va_start(args, V4);
	narg -=4;
	V5=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V5;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	VALUES(0) = (VV[78]->s.s_gfdef);
	RETURN(Lapply(4,VALUES(0),(V1),(V2),(V5)) /*  APPLY           */);
	}
}
/*	local function CLOSURE                                        */
static LC32(int narg, object V1, object V2, ...)
{ VT26 VLEX26 CLSR26
	{object V3;
	va_list args; va_start(args, V2);
	narg -=2;
	V3=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V3;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{object V4;                               /*  CLASS           */
	V4= ((V2))->in.in_class;
	LC31(1,(V3))                              /*  SEARCH-ALLOW-OTHER-KEYS*/;
	if(VALUES(0)!=Cnil){
	goto L329;}
	L37(2,(V4),(V3))                          /*  CHECK-INITARGS  */;
L329:
	{object V5;                               /*  ADDED-SLOTS     */
	object V6;                                /*  CURRENT-SLOTDS  */
	object V7;
	object V8;                                /*  PREVIOUS-SLOT-NAMES*/
	V7= (((V2))->in.in_class)->in.in_slots[3];
	T2=VV[243]->s.s_gfdef;
	(*LK14)(1,((V1))->in.in_class)            /*  CLASS-CLASS-SLOTS*/;
	{object V9;
	object V10= VALUES(0);
	if(V10==Cnil){
	T0= Cnil;
	goto L334;}
	T1=V9=CONS(Cnil,Cnil);
L335:
	(*LK16)(1,CAR(V10))                       /*  SLOTD-NAME      */;
	CAR(V9)= VALUES(0);
	if((V10=CDR(V10))==Cnil){
	T0= T1;
	goto L334;}
	V9=CDR(V9)=CONS(Cnil,Cnil);
	goto L335;}
L334:
	T2=VV[243]->s.s_gfdef;
	{object V9;
	object V10= (((V1))->in.in_class)->in.in_slots[3];
	if(V10==Cnil){
	VALUES(0) = Cnil;
	goto L338;}
	T1=V9=CONS(Cnil,Cnil);
L339:
	(*LK16)(1,CAR(V10))                       /*  SLOTD-NAME      */;
	CAR(V9)= VALUES(0);
	if((V10=CDR(V10))==Cnil){
	VALUES(0) = T1;
	goto L338;}
	V9=CDR(V9)=CONS(Cnil,Cnil);
	goto L339;}
L338:
	V8= nconc(T0,VALUES(0));
	V5= Cnil;
	V6= V7;
	{register object V9;
	register object V10;                      /*  SLOTD           */
	V9= (V6);
	V10= Cnil;
L345:
	if(!((V9)==Cnil)){
	goto L346;}
	goto L341;
L346:
	V10= CAR((V9));
	{object V12= (V10);
	VALUES(0) = CAR(V12);}
	{register object x= VALUES(0),V12= (V8);
	while(V12!=Cnil)
	if(x==CAR(V12)){
	goto L355;
	}else V12=CDR(V12);}
	{object V12= CDR(CDR(CDR(CDR(CDR(CDR((V10)))))));
	VALUES(0) = CAR(V12);}
	if(!((VALUES(0))==(VV[96]))){
	goto L351;}
	goto L353;
L355:
	goto L351;
L353:
	{object V12= (V10);
	VALUES(0) = CAR(V12);}
	V5= CONS(VALUES(0),(V5));
L351:
	V9= CDR((V9));
	goto L345;
	}
L341:
	VALUES(0) = (VV[78]->s.s_gfdef);
	RETURN(Lapply(4,VALUES(0),(V2),(V5),(V3)) /*  APPLY           */);
	}
	}
	}
}
/*	local function CLOSURE                                        */
static LC29(int narg, object V1, object V2)
{ VT27 VLEX27 CLSR27
	{object V3;                               /*  OLD-CLASS       */
	object V4;                                /*  COPY            */
	object V5;                                /*  OLD-SLOTDS      */
	object V6;                                /*  OLD-SLOTDS-NAMES*/
	object V7;                                /*  NEW-SLOTDS      */
	V3= ((V1))->in.in_class;
	L30(1,(V1))                               /*  ALLOCATE-COPY   */;
	V4= VALUES(0);
	T0= ((V3))->in.in_slots[3];
	(*LK14)(1,(V3))                           /*  CLASS-CLASS-SLOTS*/;
	V5= append(T0,VALUES(0));
	T1=VV[243]->s.s_gfdef;
	{object V8;
	object V9= (V5);
	if(V9==Cnil){
	V6= Cnil;
	goto L371;}
	T0=V8=CONS(Cnil,Cnil);
L372:
	(*LK16)(1,CAR(V9))                        /*  SLOTD-NAME      */;
	CAR(V8)= VALUES(0);
	if((V9=CDR(V9))==Cnil){
	V6= T0;
	goto L371;}
	V8=CDR(V8)=CONS(Cnil,Cnil);
	goto L372;}
L371:
	V7= ((V2))->in.in_slots[3];
	(*LK17)(3,(V1),(V2),MAKE_FIXNUM(length((V7))))/*  CHANGE-INSTANCE*/;
	{register object V8;                      /*  SLOTDS          */
	object V9;                                /*  SLOTD           */
	register object V10;                      /*  I               */
	V8= (V7);
	V9= CAR((V8));
	V10= MAKE_FIXNUM(0);
L381:
	if(((V8))!=Cnil){
	goto L382;}
	goto L376;
L382:
	{object V12;                              /*  SLOTD-NAME      */
	{object V13= (V9);
	V12= CAR(V13);}
	{register object x= (V12),V13= (V6);
	while(V13!=Cnil)
	if(x==CAR(V13)){
	goto L388;
	}else V13=CDR(V13);
	goto L385;}
L388:
	(*LK18)(2,(V4),(V12))                     /*  SLOT-BOUNDP     */;
	if(VALUES(0)==Cnil){
	goto L385;}
	(*LK19)(2,(V4),(V12))                     /*  SLOT-VALUE      */;
	((V1))->in.in_slots[fix((V10))]=(VALUES(0));
	}
L385:
	V8= CDR((V8));
	V9= CAR((V8));
	V10= one_plus((V10));
	goto L381;
	}
L376:
	(*LK20)(2,(V4),(V1))                      /*  UPDATE-INSTANCE-FOR-DIFFERENT-CLASS*/;
	}
	VALUES(0) = (V1);
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC28(int narg, object V1, ...)
{ VT28 VLEX28 CLSR28
	{object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{object V3;                               /*  CLASS           */
	V3= ((V1))->in.in_class;
	LC27(1,(V2))                              /*  SEARCH-ALLOW-OTHER-KEYS*/;
	if(VALUES(0)!=Cnil){
	goto L400;}
	L37(2,(V3),(V2))                          /*  CHECK-INITARGS  */;
L400:
	VALUES(0) = (VV[78]->s.s_gfdef);
	Lapply(4,VALUES(0),(V1),Cnil,(V2))        /*  APPLY           */;
	VALUES(0) = (V1);
	RETURN(1);
	}
	}
}
/*	local function CLOSURE                                        */
static LC26(int narg, object V1, ...)
{ VT29 VLEX29 CLSR29
	{object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	VALUES(0) = (VV[78]->s.s_gfdef);
	RETURN(Lapply(4,VALUES(0),(V1),Ct,(V2))   /*  APPLY           */);
	}
}
/*	local function CLOSURE                                        */
static LC25(int narg, object V1, object V2, ...)
{ VT30 VLEX30 CLSR30
	{object V3;
	va_list args; va_start(args, V2);
	lex0[0]=V1;                               /*  INSTANCE        */
	lex0[1]=V2;                               /*  SLOT-NAMES      */
	narg -=2;
	V3=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V3;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	lex0[2]=V3;                               /*  INITARGS        */
	{object V4;                               /*  CLASS           */
	V4= (lex0[0])->in.in_class;
	{object V5;                               /*  SLOTDS          */
	V5= ((V4))->in.in_slots[3];
	lex0[3]=CAR((V5));                        /*  SLOTD           */
	lex0[4]=MAKE_FIXNUM(0);                   /*  I               */
L412:
	if(((V5))!=Cnil){
	goto L413;}
	goto L408;
L413:
	{object V7;
	object V8;
	{object V9= lex0[3];
	V7= CAR(V9);}
	{object V9= CDR(lex0[3]);
	V8= CAR(V9);}
	lex0[5]=V7;                               /*  SLOT-NAME       */
	lex0[6]=V8;                               /*  SLOT-INITARGS   */
	{object V9;
	LC21(lex0,0)                              /*  FROM-INITARGS   */;
	V9= VALUES(0);
	if(((V9))==Cnil){
	goto L421;}
	goto L416;
L421:
	LC22(lex0,0)                              /*  FROM-INITFORMS  */;
	}
	}
L416:
	V5= CDR((V5));
	lex0[3]= CAR((V5));
	lex0[4]= one_plus(lex0[4]);
	goto L412;
	}
L408:
	(*LK3)(2,(V4),VV[32])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L406;}
	{object V5;                               /*  CLASS-CLASS-SLOTS*/
	object V6;
	register object V7;                       /*  CLASS-CLASS-SLOTS-VALUES*/
	(*LK14)(1,(V4))                           /*  CLASS-CLASS-SLOTS*/;
	V6= VALUES(0);
	(*LK19)(2,(V4),VV[48])                    /*  SLOT-VALUE      */;
	V7= VALUES(0);
	V5= V6;
	{object V8;
	V8= (V5);
	lex0[7]=Cnil;                             /*  SLOTD           */
L437:
	if(!((V8)==Cnil)){
	goto L438;}
	goto L434;
L438:
	lex0[7]= CAR((V8));
	{object V10;                              /*  SLOT-NAME       */
	object V11;                               /*  FOUND           */
	{object V12= lex0[7];
	V10= CAR(V12);}
	{object V12= CDR(lex0[7]);
	lex0[8]=CAR(V12);                         /*  SLOT-INITARGS   */}
	V11= Cnil;
	lex0[9]=Cnil;                             /*  VALUE           */
	{register object x= (V10),V12= (V7);
	while(V12!=Cnil)
	if(CAR(V12) != Cnil && 
	x==(CAAR(V12))){
	V11= CAR(V12);
	goto L451;
	}else V12=CDR(V12);
	V11= Cnil;}
L451:
	if(((V11))==Cnil){
	goto L449;}
	lex0[9]= CDR((V11));
	(*LK21)(2,(V11),(V7))                     /*  DELETE          */;
	V7= VALUES(0);
	goto L447;
L449:
	lex0[9]= VV[77];
L447:
	{object V12;
	LC23(lex0,0)                              /*  FROM-INITARGS   */;
	V12= VALUES(0);
	if(((V12))==Cnil){
	goto L459;}
	goto L456;
L459:
	LC24(lex0,0)                              /*  FROM-INITFORMS  */;
	}
L456:
	V7= CONS(CONS((V10),lex0[9]),(V7));
	}
	V8= CDR((V8));
	goto L437;
	}
L434:
	(*LK11)(3,(V7),(V4),VV[48])               /*  (SETF SLOT-VALUE)*/;
	}
	}
L406:
	VALUES(0) = lex0[0];
	RETURN(1);
	}
}
/*	local function CLOSURE                                        */
static LC20(int narg, object V1, object V2)
{ VT31 VLEX31 CLSR31
	{object V3;                               /*  CLASS           */
	register int V4;                          /*  INDEX           */
	V3= ((V1))->in.in_class;
	V4= fix(gethash((V2),((V3))->in.in_slots[5])->hte_value);
	if((MAKE_FIXNUM(V4))==Cnil){
	goto L468;}
	if(!((V4)>=(0))){
	goto L471;}
	RETURN(siLsl_makunbound(2,(V1),MAKE_FIXNUM(V4))/*  SL-MAKUNBOUND*/);
L471:
	{object V5;                               /*  ENTRY           */
	(*LK15)(1,(V3))                           /*  CLASS-CLASS-SLOTS-VALUES*/;
	{register object x= (V2),V6= VALUES(0);
	while(V6!=Cnil)
	if(CAR(V6) != Cnil && 
	x==(CAAR(V6))){
	V5= CAR(V6);
	goto L473;
	}else V6=CDR(V6);
	V5= Cnil;}
L473:
	{object V6;
	V6= (VV[77]->s.s_dbind);
	CDR((V5)) = (V6);
	VALUES(0) = (V6);
	RETURN(1);
	}
	}
L468:
	RETURN((*LK22)(4,((V1))->in.in_class,(V1),(V2),VV[74])/*  SLOT-MISSING*/);
	}
}
/*	local function CLOSURE                                        */
static LC19(int narg, object V1, object V2)
{ VT32 VLEX32 CLSR32
	{object V3;                               /*  CLASS           */
	V3= ((V1))->in.in_class;
	VALUES(0) = MAKE_FIXNUM(fix(gethash((V2),((V3))->in.in_slots[5])->hte_value));
	RETURN(1);
	}
}
/*	local function CLOSURE                                        */
static LC18(int narg, object V1, object V2)
{ VT33 VLEX33 CLSR33
	{ int V3;
	object V4;                                /*  VAL             */
	object V5;                                /*  CONDITION       */
	V3=L38(2,(V1),(V2))                       /*  STANDARD-INSTANCE-GET*/;
	if (V3==0) goto L479;
	V4= VALUES(0);
	V3--;
	if (V3==0) goto L480;
	V5= VALUES(1);
	V3--;
	goto L481;
L479:
	V4= Cnil;
L480:
	V5= Cnil;
L481:
	{register object V6;
	V6= (V5);
	if(!(eql((V6),VV[58]))){
	goto L483;}
	VALUES(0) = Ct;
	RETURN(1);
L483:
	if(!(eql((V6),VV[59]))){
	goto L486;}
	VALUES(0) = Cnil;
	RETURN(1);
L486:
	if(!(eql((V6),VV[60]))){
	goto L489;}
	RETURN((*LK22)(4,((V1))->in.in_class,(V1),(V2),VV[68])/*  SLOT-MISSING*/);
L489:
	bds_bind(VV[61],MAKE_FIXNUM(4));          /*  *PRINT-LEVEL*   */
	bds_bind(VV[62],MAKE_FIXNUM(4));          /*  *PRINT-LENGTH*  */
	{int V7;
	V7=Lerror(6,VV[63],VV[64],(V6),VV[58],VV[59],VV[60])/*  ERROR */;
	bds_unwind1;
	bds_unwind1;
	RETURN(V7);}
	}}
}
/*	local function CLOSURE                                        */
static LC17(int narg, object V1, object V2, object V3)
{ VT34 VLEX34 CLSR34
	RETURN(L39(3,(V1),(V2),(V3))              /*  STANDARD-INSTANCE-SET*/);
}
/*	local function CLOSURE                                        */
static LC16(int narg, object V1, object V2)
{ VT35 VLEX35 CLSR35
	{ int V3;
	object V4;                                /*  VAL             */
	object V5;                                /*  CONDITION       */
	V3=L38(2,(V1),(V2))                       /*  STANDARD-INSTANCE-GET*/;
	if (V3==0) goto L492;
	V4= VALUES(0);
	V3--;
	if (V3==0) goto L493;
	V5= VALUES(1);
	V3--;
	goto L494;
L492:
	V4= Cnil;
L493:
	V5= Cnil;
L494:
	{register object V6;
	V6= (V5);
	if(!(eql((V6),VV[58]))){
	goto L496;}
	VALUES(0) = (V4);
	RETURN(1);
L496:
	if(!(eql((V6),VV[59]))){
	goto L499;}
	RETURN((*LK0)(3,((V1))->in.in_class,(V1),(V2))/*  SLOT-UNBOUND*/);
L499:
	if(!(eql((V6),VV[60]))){
	goto L502;}
	RETURN((*LK22)(4,((V1))->in.in_class,(V1),(V2),VV[4])/*  SLOT-MISSING*/);
L502:
	bds_bind(VV[61],MAKE_FIXNUM(4));          /*  *PRINT-LEVEL*   */
	bds_bind(VV[62],MAKE_FIXNUM(4));          /*  *PRINT-LENGTH*  */
	{int V7;
	V7=Lerror(6,VV[63],VV[64],(V6),VV[58],VV[59],VV[60])/*  ERROR */;
	bds_unwind1;
	bds_unwind1;
	RETURN(V7);}
	}}
}
/*	local function CLOSURE                                        */
static LC15(int narg, object V1)
{ VT36 VLEX36 CLSR36
	RETURN((*LK19)(2,(V1),VV[52])             /*  SLOT-VALUE      */);
}
/*	local function CLOSURE                                        */
static LC14(int narg, object V1, object V2)
{ VT37 VLEX37 CLSR37
	RETURN((*LK11)(3,(V1),(V2),VV[48])        /*  (SETF SLOT-VALUE)*/);
}
/*	local function CLOSURE                                        */
static LC13(int narg, object V1)
{ VT38 VLEX38 CLSR38
	RETURN((*LK19)(2,(V1),VV[48])             /*  SLOT-VALUE      */);
}
/*	local function CLOSURE                                        */
static LC12(int narg, object V1)
{ VT39 VLEX39 CLSR39
	RETURN((*LK19)(2,(V1),VV[47])             /*  SLOT-VALUE      */);
}
/*	local function CLOSURE                                        */
static LC11(int narg, object V1, object V2)
{ VT40 VLEX40 CLSR40
	RETURN((*LK11)(3,(V1),(V2),VV[30])        /*  (SETF SLOT-VALUE)*/);
}
/*	local function CLOSURE                                        */
static LC10(int narg, object V1)
{ VT41 VLEX41 CLSR41
	RETURN((*LK19)(2,(V1),VV[30])             /*  SLOT-VALUE      */);
}
/*	local function CLOSURE                                        */
static LC9(int narg, object V1, object V2, object V3)
{ VT42 VLEX42 CLSR42
	if(((V3)!= VV[247]))goto L504;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(0),(V1))/*  INSTANCE-SET*/);
L504:
	if(((V3)!= VV[130]))goto L505;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(1),(V1))/*  INSTANCE-SET*/);
L505:
	if(((V3)!= VV[248]))goto L506;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(2),(V1))/*  INSTANCE-SET*/);
L506:
	if(((V3)!= VV[29]))goto L507;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(3),(V1))/*  INSTANCE-SET*/);
L507:
	if(((V3)!= VV[131]))goto L508;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(4),(V1))/*  INSTANCE-SET*/);
L508:
	if(((V3)!= VV[249]))goto L509;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(5),(V1))/*  INSTANCE-SET*/);
L509:
	if(((V3)!= VV[28]))goto L510;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(6),(V1))/*  INSTANCE-SET*/);
L510:
	if(((V3)!= VV[52]))goto L511;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(7),(V1))/*  INSTANCE-SET*/);
L511:
	if(((V3)!= VV[48]))goto L512;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(8),(V1))/*  INSTANCE-SET*/);
L512:
	if(((V3)!= VV[47]))goto L513;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(9),(V1))/*  INSTANCE-SET*/);
L513:
	if(((V3)!= VV[30]))goto L514;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(10),(V1))/*  INSTANCE-SET*/);
L514:
	if(((V3)!= VV[250]))goto L515;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(11),(V1))/*  INSTANCE-SET*/);
L515:
	siLinstance_class(1,(V2))                 /*  INSTANCE-CLASS  */;
	RETURN((*LK22)(5,VALUES(0),(V2),(V3),(V1),VV[11])/*  SLOT-MISSING*/);
}
/*	local function CLOSURE                                        */
static LC8(int narg, object V1, object V2)
{ VT43 VLEX43 CLSR43
	if(((V2)!= VV[247]))goto L517;
	{object V3;                               /*  VAL             */
	V3= ((V1))->in.in_slots[0];
	if(!(((V3))!=OBJNULL)){
	goto L520;}
	VALUES(0) = (V3);
	RETURN(1);
L520:
	VALUES(0) = VV[7];
	RETURN(1);
	}
L517:
	if(((V2)!= VV[130]))goto L522;
	{object V4;                               /*  VAL             */
	V4= ((V1))->in.in_slots[1];
	if(!(((V4))!=OBJNULL)){
	goto L525;}
	VALUES(0) = (V4);
	RETURN(1);
L525:
	VALUES(0) = VV[7];
	RETURN(1);
	}
L522:
	if(((V2)!= VV[248]))goto L527;
	{object V5;                               /*  VAL             */
	V5= ((V1))->in.in_slots[2];
	if(!(((V5))!=OBJNULL)){
	goto L530;}
	VALUES(0) = (V5);
	RETURN(1);
L530:
	VALUES(0) = VV[7];
	RETURN(1);
	}
L527:
	if(((V2)!= VV[29]))goto L532;
	{object V6;                               /*  VAL             */
	V6= ((V1))->in.in_slots[3];
	if(!(((V6))!=OBJNULL)){
	goto L535;}
	VALUES(0) = (V6);
	RETURN(1);
L535:
	VALUES(0) = VV[7];
	RETURN(1);
	}
L532:
	if(((V2)!= VV[131]))goto L537;
	{object V7;                               /*  VAL             */
	V7= ((V1))->in.in_slots[4];
	if(!(((V7))!=OBJNULL)){
	goto L540;}
	VALUES(0) = (V7);
	RETURN(1);
L540:
	VALUES(0) = VV[7];
	RETURN(1);
	}
L537:
	if(((V2)!= VV[249]))goto L542;
	{object V8;                               /*  VAL             */
	V8= ((V1))->in.in_slots[5];
	if(!(((V8))!=OBJNULL)){
	goto L545;}
	VALUES(0) = (V8);
	RETURN(1);
L545:
	VALUES(0) = VV[7];
	RETURN(1);
	}
L542:
	if(((V2)!= VV[28]))goto L547;
	{object V9;                               /*  VAL             */
	V9= ((V1))->in.in_slots[6];
	if(!(((V9))!=OBJNULL)){
	goto L550;}
	VALUES(0) = (V9);
	RETURN(1);
L550:
	VALUES(0) = VV[7];
	RETURN(1);
	}
L547:
	if(((V2)!= VV[52]))goto L552;
	{object V10;                              /*  VAL             */
	V10= ((V1))->in.in_slots[7];
	if(!(((V10))!=OBJNULL)){
	goto L555;}
	VALUES(0) = (V10);
	RETURN(1);
L555:
	VALUES(0) = VV[7];
	RETURN(1);
	}
L552:
	if(((V2)!= VV[48]))goto L557;
	{object V11;                              /*  VAL             */
	V11= ((V1))->in.in_slots[8];
	if(!(((V11))!=OBJNULL)){
	goto L560;}
	VALUES(0) = (V11);
	RETURN(1);
L560:
	VALUES(0) = VV[7];
	RETURN(1);
	}
L557:
	if(((V2)!= VV[47]))goto L562;
	{object V12;                              /*  VAL             */
	V12= ((V1))->in.in_slots[9];
	if(!(((V12))!=OBJNULL)){
	goto L565;}
	VALUES(0) = (V12);
	RETURN(1);
L565:
	VALUES(0) = VV[7];
	RETURN(1);
	}
L562:
	if(((V2)!= VV[30]))goto L567;
	{object V13;                              /*  VAL             */
	V13= ((V1))->in.in_slots[10];
	if(!(((V13))!=OBJNULL)){
	goto L570;}
	VALUES(0) = (V13);
	RETURN(1);
L570:
	VALUES(0) = VV[7];
	RETURN(1);
	}
L567:
	if(((V2)!= VV[250]))goto L572;
	{object V14;                              /*  VAL             */
	V14= ((V1))->in.in_slots[11];
	if(!(((V14))!=OBJNULL)){
	goto L575;}
	VALUES(0) = (V14);
	RETURN(1);
L575:
	VALUES(0) = VV[7];
	RETURN(1);
	}
L572:
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	RETURN((*LK22)(4,VALUES(0),(V1),(V2),VV[4])/*  SLOT-MISSING   */);
}
/*	local function CLOSURE                                        */
static LC6(int narg, object V1, object V2, object V3, object V4, object V5, object V6, object V7, object V8)
{ VT44 VLEX44 CLSR44
	lex0[0]=V1;                               /*  METACLASS       */
	lex0[1]=V3;                               /*  SUPERCLASSES-NAMES*/
	lex0[2]=V4;                               /*  LOCAL-SLOTS     */
	lex0[3]=V5;                               /*  CLASS-SLOTS     */
	lex0[4]=V6;                               /*  ALL-SLOTS       */
	lex0[5]=V7;                               /*  DEFAULT-INITARGS*/
	lex0[6]=V8;                               /*  DOCUMENTATION   */
	{object V9;                               /*  SUPERCLASSES    */
	object V10;                               /*  CPL             */
	(*LK5)(2,(V2),Cnil)                       /*  FIND-CLASS      */;
	lex0[7]=VALUES(0);                        /*  EXISTING        */
	T1=VV[179]->s.s_gfdef;
	{object V11;
	object V12= lex0[1];
	if(V12==Cnil){
	V9= Cnil;
	goto L579;}
	T0=V11=CONS(Cnil,Cnil);
L580:
	(*LK5)(1,CAR(V12))                        /*  FIND-CLASS      */;
	CAR(V11)= VALUES(0);
	if((V12=CDR(V12))==Cnil){
	V9= T0;
	goto L579;}
	V11=CDR(V11)=CONS(Cnil,Cnil);
	goto L580;}
L579:
	(*LK9)(2,(V2),(V9))                       /*  COMPUTE-CLASS-PRECEDENCE-LIST*/;
	V10= VALUES(0);
	LC5(lex0,0)                               /*  UNCHANGED-CLASS */;
	if(VALUES(0)==Cnil){
	goto L584;}
	VALUES(0) = lex0[7];
	RETURN(1);
L584:
	{object V11;                              /*  NEW-CLASS       */
	(*LK23)(1,append(lex0[4],lex0[3]))        /*  BUILD-SLOT-INDEX-TABLE*/;
	T0= VALUES(0);
	(*LK24)(2,(V10),lex0[5])                  /*  COLLECT-DEFAULT-INITARGS*/;
	(*LK25)(19,lex0[0],VV[18],(V2),VV[19],(V9),VV[20],lex0[4],VV[21],T0,VV[22],lex0[2],VV[23],lex0[3],VV[24],(V10),VV[25],VALUES(0),VV[26],lex0[6])/*  MAKE-INSTANCE*/;
	V11= VALUES(0);
	if((lex0[7])==Cnil){
	goto L589;}
	L7(4,lex0[7],(V11),lex0[1],(lex0[7])->in.in_slots[2])/*  REDEFINE-CLASS*/;
L589:
	VALUES(0) = (V11);
	RETURN(1);
	}
	}
}
/*	local function CLOSURE                                        */
static LC3(int narg, object V1, object V2, object V3, object V4)
{ VT45 VLEX45 CLSR45
	{object V5;                               /*  SUPERCLASSES    */
	T1=VV[179]->s.s_gfdef;
	{object V6;
	object V7= (V4);
	if(V7==Cnil){
	V5= Cnil;
	goto L592;}
	T0=V6=CONS(Cnil,Cnil);
L593:
	(*LK5)(1,CAR(V7))                         /*  FIND-CLASS      */;
	CAR(V6)= VALUES(0);
	if((V7=CDR(V7))==Cnil){
	V5= T0;
	goto L592;}
	V6=CDR(V6)=CONS(Cnil,Cnil);
	goto L593;}
L592:
	(*LK9)(2,(V3),(V5))                       /*  COMPUTE-CLASS-PRECEDENCE-LIST*/;
	RETURN((*LK26)(2,VALUES(0),(V2))          /*  COLLECT-SLOTDS  */);
	}
}
/*	local function CLOSURE                                        */
static LC2(int narg, object V1, object V2, object V3)
{ VT46 VLEX46 CLSR46
	if(((V3)!= VV[247]))goto L596;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(0),(V1))/*  INSTANCE-SET*/);
L596:
	if(((V3)!= VV[130]))goto L597;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(1),(V1))/*  INSTANCE-SET*/);
L597:
	if(((V3)!= VV[248]))goto L598;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(2),(V1))/*  INSTANCE-SET*/);
L598:
	if(((V3)!= VV[29]))goto L599;
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(3),(V1))/*  INSTANCE-SET*/);
L599:
	siLinstance_class(1,(V2))                 /*  INSTANCE-CLASS  */;
	RETURN((*LK22)(5,VALUES(0),(V2),(V3),(V1),VV[11])/*  SLOT-MISSING*/);
}
/*	local function CLOSURE                                        */
static LC1(int narg, object V1, object V2)
{ VT47 VLEX47 CLSR47
	if(((V2)!= VV[247]))goto L601;
	{object V3;                               /*  VAL             */
	V3= ((V1))->in.in_slots[0];
	if(!(((V3))!=OBJNULL)){
	goto L604;}
	VALUES(0) = (V3);
	RETURN(1);
L604:
	VALUES(0) = VV[7];
	RETURN(1);
	}
L601:
	if(((V2)!= VV[130]))goto L606;
	{object V4;                               /*  VAL             */
	V4= ((V1))->in.in_slots[1];
	if(!(((V4))!=OBJNULL)){
	goto L609;}
	VALUES(0) = (V4);
	RETURN(1);
L609:
	VALUES(0) = VV[7];
	RETURN(1);
	}
L606:
	if(((V2)!= VV[248]))goto L611;
	{object V5;                               /*  VAL             */
	V5= ((V1))->in.in_slots[2];
	if(!(((V5))!=OBJNULL)){
	goto L614;}
	VALUES(0) = (V5);
	RETURN(1);
L614:
	VALUES(0) = VV[7];
	RETURN(1);
	}
L611:
	if(((V2)!= VV[29]))goto L616;
	{object V6;                               /*  VAL             */
	V6= ((V1))->in.in_slots[3];
	if(!(((V6))!=OBJNULL)){
	goto L619;}
	VALUES(0) = (V6);
	RETURN(1);
L619:
	VALUES(0) = VV[7];
	RETURN(1);
	}
L616:
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	RETURN((*LK22)(4,VALUES(0),(V1),(V2),VV[4])/*  SLOT-MISSING   */);
}
/*	local function SEARCH-ALLOW-OTHER-KEYS                        */
static LC48(int narg, object V1)
{ VT48 VLEX48 CLSR48
TTL:
	{register object V2;                      /*  ARG-LIST        */
	V2= (V1);
L623:
	if(((V2))!=Cnil){
	goto L624;}
	VALUES(0) = Cnil;
	RETURN(1);
L624:
	if(!((CAR((V2)))==(VV[89]))){
	goto L627;}
	VALUES(0) = CADR((V2));
	RETURN(1);
L627:
	V2= CDDR((V2));
	goto L623;
	}
}
/*	local function CALL-NEXT-METHOD                               */
static LC44(object *lex0,int narg, ...)
{ VT49 VLEX49 CLSR49
	{object V1;
	va_list args; va_start(args, narg);
	narg -=0;
	V1=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V1;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	if((lex0[2])==Cnil){
	goto L634;}
	if(((V1))==Cnil){
	goto L637;}
	RETURN(Lapply(2,lex0[2],(V1))             /*  APPLY           */);
L637:
	RETURN(Lapply(3,lex0[2],lex0[0],lex0[1])  /*  APPLY           */);
L634:
	RETURN(Lerror(1,VV[132])                  /*  ERROR           */);
	}
}
/*	local function SEARCH-ALLOW-OTHER-KEYS                        */
static LC31(int narg, object V1)
{ VT50 VLEX50 CLSR50
TTL:
	{register object V2;                      /*  ARG-LIST        */
	V2= (V1);
L640:
	if(((V2))!=Cnil){
	goto L641;}
	VALUES(0) = Cnil;
	RETURN(1);
L641:
	if(!((CAR((V2)))==(VV[89]))){
	goto L644;}
	VALUES(0) = CADR((V2));
	RETURN(1);
L644:
	V2= CDDR((V2));
	goto L640;
	}
}
/*	local function SEARCH-ALLOW-OTHER-KEYS                        */
static LC27(int narg, object V1)
{ VT51 VLEX51 CLSR51
TTL:
	{register object V2;                      /*  ARG-LIST        */
	V2= (V1);
L651:
	if(((V2))!=Cnil){
	goto L652;}
	VALUES(0) = Cnil;
	RETURN(1);
L652:
	if(!((CAR((V2)))==(VV[89]))){
	goto L655;}
	VALUES(0) = CADR((V2));
	RETURN(1);
L655:
	V2= CDDR((V2));
	goto L651;
	}
}
/*	local function FROM-INITARGS                                  */
static LC21(object *lex0,int narg)
{ VT52 VLEX52 CLSR52
TTL:
	{register object V1;                      /*  .PLIST-TAIL.    */
	object V2;                                /*  INITARG         */
	object V3;                                /*  VAL             */
	V1= lex0[2];
	V2= Cnil;
	V3= Cnil;
L662:
	if(((V1))!=Cnil){
	goto L664;}
	VALUES(0) = Cnil;
	RETURN(1);
L664:
	{object V4;
	V4= CAR((V1));
	V1= CDR((V1));
	V2= (V4);
	}
	if(((V1))!=Cnil){
	goto L672;}
	Lerror(1,VV[81])                          /*  ERROR           */;
L672:
	{object V4;
	V4= CAR((V1));
	V1= CDR((V1));
	V3= (V4);
	}
	{register object x= (V2),V4= lex0[6];
	while(V4!=Cnil)
	if(x==CAR(V4)){
	goto L681;
	}else V4=CDR(V4);
	goto L663;}
L681:
	(lex0[0])->in.in_slots[fix(lex0[4])]=((V3));
	VALUES(0) = Ct;
	RETURN(1);
L663:
	goto L662;
	}
}
/*	local function FROM-INITFORMS                                 */
static LC22(object *lex0,int narg)
{ VT53 VLEX53 CLSR53
TTL:
	if((lex0[1])==Cnil){
	goto L688;}
	{object V1;
	V1= ((lex0[1])==(Ct)?Ct:Cnil);
	if(((V1))==Cnil){
	goto L695;}
	if(((V1))==Cnil){
	goto L691;}
	goto L692;
L695:
	{register object x= lex0[5],V2= lex0[1];
	while(V2!=Cnil)
	if(x==CAR(V2)){
	goto L692;
	}else V2=CDR(V2);
	goto L691;}
	}
L692:
	siLinstance_ref(2,lex0[0],lex0[4])        /*  INSTANCE-REF    */;
	if(!((((VALUES(0))!=OBJNULL?Ct:Cnil))==Cnil)){
	goto L685;}
	goto L686;
L691:
	goto L685;
L688:
	goto L685;
L686:
	{object V1;                               /*  INITFORM        */
	{object V2= CDR(CDR(lex0[3]));
	V1= CAR(V2);}
	if(((V1))==(VV[82])){
	goto L700;}
	Leval(1,(V1))                             /*  EVAL            */;
	VALUES(0) = (lex0[0])->in.in_slots[fix(lex0[4])]=(VALUES(0));
	RETURN(1);
L700:
	VALUES(0) = Cnil;
	RETURN(1);
	}
L685:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	local function FROM-INITARGS                                  */
static LC23(object *lex0,int narg)
{ VT54 VLEX54 CLSR54
TTL:
	{register object V1;                      /*  .PLIST-TAIL.    */
	object V2;                                /*  INITARG         */
	object V3;                                /*  VAL             */
	V1= lex0[2];
	V2= Cnil;
	V3= Cnil;
L704:
	if(((V1))!=Cnil){
	goto L706;}
	VALUES(0) = Cnil;
	RETURN(1);
L706:
	{object V4;
	V4= CAR((V1));
	V1= CDR((V1));
	V2= (V4);
	}
	if(((V1))!=Cnil){
	goto L714;}
	Lerror(1,VV[81])                          /*  ERROR           */;
L714:
	{object V4;
	V4= CAR((V1));
	V1= CDR((V1));
	V3= (V4);
	}
	{register object x= (V2),V4= lex0[8];
	while(V4!=Cnil)
	if(x==CAR(V4)){
	goto L723;
	}else V4=CDR(V4);
	goto L705;}
L723:
	lex0[9]= (V3);
	VALUES(0) = Ct;
	RETURN(1);
L705:
	goto L704;
	}
}
/*	local function FROM-INITFORMS                                 */
static LC24(object *lex0,int narg)
{ VT55 VLEX55 CLSR55
TTL:
	if(!(eql(lex0[9],VV[77]))){
	goto L728;}
	{object V1;                               /*  INITFORM        */
	{object V2= CDR(CDR(lex0[7]));
	V1= CAR(V2);}
	if(((V1))==(VV[82])){
	goto L732;}
	Leval(1,(V1))                             /*  EVAL            */;
	lex0[9]= VALUES(0);
	VALUES(0) = lex0[9];
	RETURN(1);
L732:
	VALUES(0) = Cnil;
	RETURN(1);
	}
L728:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	local function UNCHANGED-CLASS                                */
static LC5(object *lex0,int narg)
{ VT56 VLEX56 CLSR56
TTL:
	if((lex0[7])==Cnil){
	goto L736;}
	siLinstance_class(1,lex0[7])              /*  INSTANCE-CLASS  */;
	if(!((lex0[0])==(VALUES(0)))){
	goto L739;}
	{object V1;
	if((lex0[1])==Cnil){
	goto L747;}
	T0= lex0[1];
	goto L745;
L747:
	T0= VV[27];
	}
L745:
	{object V1;
	object V2= (lex0[7])->in.in_slots[1];
	if(V2==Cnil){
	VALUES(0) = Cnil;
	goto L749;}
	T1=V1=CONS(Cnil,Cnil);
L750:
	{object V3;                               /*  X               */
	CAR(V1)= (CAR(V2))->in.in_slots[0];
	}
	if((V2=CDR(V2))==Cnil){
	VALUES(0) = T1;
	goto L749;}
	V1=CDR(V1)=CONS(Cnil,Cnil);
	goto L750;}
L749:
	if(!(equal(T0,VALUES(0)))){
	goto L743;}
	(*LK19)(2,lex0[7],VV[28])                 /*  SLOT-VALUE      */;
	if(!(equal(lex0[2],VALUES(0)))){
	goto L753;}
	(*LK14)(1,lex0[7])                        /*  CLASS-CLASS-SLOTS*/;
	if(!(equal(lex0[3],VALUES(0)))){
	goto L757;}
	(*LK19)(2,lex0[7],VV[29])                 /*  SLOT-VALUE      */;
	if(!(equal(lex0[4],VALUES(0)))){
	goto L761;}
	(*LK13)(1,lex0[7])                        /*  DEFAULT-INITARGS-OF*/;
	if(!(equal(lex0[5],VALUES(0)))){
	goto L765;}
	(*LK11)(3,lex0[6],lex0[7],VV[30])         /*  (SETF SLOT-VALUE)*/;
	{object V1;
	VALUES(0) = Ct;
	RETURN(1);
	}
L765:
	VALUES(0) = Cnil;
	RETURN(1);
L761:
	VALUES(0) = Cnil;
	RETURN(1);
L757:
	VALUES(0) = Cnil;
	RETURN(1);
L753:
	VALUES(0) = Cnil;
	RETURN(1);
L743:
	VALUES(0) = Cnil;
	RETURN(1);
L739:
	VALUES(0) = Cnil;
	RETURN(1);
L736:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for REDEFINE-CLASS                        */
static L7(int narg, object V1, object V2, object V3, object V4)
{ VT57 VLEX57 CLSR57
TTL:
	Lformat(3,Ct,VV[31],((V1))->in.in_slots[0])/*  FORMAT         */;
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for ALLOCATE-COPY                         */
static L30(int narg, object V1)
{ VT58 VLEX58 CLSR58
TTL:
	{object V2;                               /*  CLASS           */
	object V3;                                /*  COPY            */
	object V4;                                /*  L               */
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	V2= VALUES(0);
	(*LK2)(1,(V2))                            /*  ALLOCATE-INSTANCE*/;
	V3= VALUES(0);
	V4= MAKE_FIXNUM(length(((V2))->in.in_slots[3]));
	{register int V5;                         /*  I               */
	V5= 0;
L776:
	if(!(number_compare(MAKE_FIXNUM(V5),(V4))>=0)){
	goto L777;}
	goto L773;
L777:
	siLinstance_ref(2,(V1),MAKE_FIXNUM(V5))   /*  INSTANCE-REF    */;
	siLinstance_set(3,(V3),MAKE_FIXNUM(V5),VALUES(0))/*  INSTANCE-SET*/;
	V5= (V5)+1;
	goto L776;
	}
L773:
	VALUES(0) = (V3);
	RETURN(1);
	}
}
/*	function definition for CHECK-INITARGS                        */
static L37(int narg, object V1, object V2)
{ VT59 VLEX59 CLSR59
TTL:
	{register object V3;                      /*  NAME-LOC        */
	register object V4;                       /*  NAME            */
	V3= (V2);
	V4= CAR((V3));
L788:
	if(((V3))!=Cnil){
	goto L789;}
	VALUES(0) = (V1);
	RETURN(1);
L789:
	if((CDR((V3)))!=Cnil){
	goto L794;}
	Lerror(2,VV[114],(V4))                    /*  ERROR           */;
	goto L792;
L794:
	{register object V6;                      /*  SCAN-SLOT       */
	V6= ((V1))->in.in_slots[3];
L801:
	if(((V6))!=Cnil){
	goto L802;}
	goto L798;
L802:
	{object V8= CDR(CAR((V6)));
	VALUES(0) = CAR(V8);}
	{register object x= (V4),V8= VALUES(0);
	while(V8!=Cnil)
	if(eql(x, CAR(V8))){
	goto L807;
	}else V8=CDR(V8);
	goto L805;}
L807:
	goto L792;
L805:
	V6= CDR((V6));
	goto L801;
	}
L798:
	{register object V6;                      /*  SCAN-SLOT       */
	(*LK14)(1,(V1))                           /*  CLASS-CLASS-SLOTS*/;
	V6= VALUES(0);
L815:
	if(((V6))!=Cnil){
	goto L816;}
	goto L812;
L816:
	{object V8= CDR(CAR((V6)));
	VALUES(0) = CAR(V8);}
	{register object x= (V4),V8= VALUES(0);
	while(V8!=Cnil)
	if(eql(x, CAR(V8))){
	goto L821;
	}else V8=CDR(V8);
	goto L819;}
L821:
	goto L792;
L819:
	V6= CDR((V6));
	goto L815;
	}
L812:
	Lerror(3,VV[115],(V4),(V1))               /*  ERROR           */;
L792:
	V3= CDDR((V3));
	V4= CAR((V3));
	goto L788;
	}
}
/*	function definition for STANDARD-INSTANCE-GET                 */
static L38(int narg, object V1, object V2)
{ VT60 VLEX60 CLSR60
TTL:
	{object V3;                               /*  CLASS           */
	register int V4;                          /*  INDEX           */
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	V3= VALUES(0);
	Lgethash(3,(V2),((V3))->in.in_slots[5],MAKE_FIXNUM(536870911))/*  GETHASH*/;
	V4= fix(VALUES(0));
	if(!((V4)==(536870911))){
	goto L834;}
	VALUES(1) = VV[60];
	VALUES(0) = Cnil;
	RETURN(2);
L834:
	if(!((V4)>=(0))){
	goto L837;}
	{object V5;                               /*  VAL             */
	siLinstance_ref(2,(V1),MAKE_FIXNUM(V4))   /*  INSTANCE-REF    */;
	V5= VALUES(0);
	if(!(((V5))!=OBJNULL)){
	goto L841;}
	VALUES(1) = VV[58];
	VALUES(0) = (V5);
	RETURN(2);
L841:
	VALUES(1) = VV[59];
	VALUES(0) = Cnil;
	RETURN(2);
	}
L837:
	{object V6;                               /*  VAL             */
	(*LK15)(1,(V3))                           /*  CLASS-CLASS-SLOTS-VALUES*/;
	{register object x= (V2),V7= VALUES(0);
	while(V7!=Cnil)
	if(CAR(V7) != Cnil && 
	x==(CAAR(V7))){
	VALUES(0) = CAR(V7);
	goto L844;
	}else V7=CDR(V7);
	VALUES(0) = Cnil;}
L844:
	V6= CDR(VALUES(0));
	if(!(eql((V6),VV[77]))){
	goto L847;}
	VALUES(1) = VV[59];
	VALUES(0) = Cnil;
	RETURN(2);
L847:
	VALUES(1) = VV[58];
	VALUES(0) = (V6);
	RETURN(2);
	}
	}
}
/*	function definition for STANDARD-INSTANCE-SET                 */
static L39(int narg, object V1, object V2, object V3)
{ VT61 VLEX61 CLSR61
TTL:
	{object V4;                               /*  CLASS           */
	register int V5;                          /*  INDEX           */
	siLinstance_class(1,(V2))                 /*  INSTANCE-CLASS  */;
	V4= VALUES(0);
	Lgethash(2,(V3),((V4))->in.in_slots[5])   /*  GETHASH         */;
	V5= fix(VALUES(0));
	if((MAKE_FIXNUM(V5))==Cnil){
	goto L852;}
	if(!((V5)>=(0))){
	goto L855;}
	RETURN(siLinstance_set(3,(V2),MAKE_FIXNUM(V5),(V1))/*  INSTANCE-SET*/);
L855:
	{object V6;                               /*  ENTRY           */
	(*LK15)(1,(V4))                           /*  CLASS-CLASS-SLOTS-VALUES*/;
	{register object x= (V3),V7= VALUES(0);
	while(V7!=Cnil)
	if(CAR(V7) != Cnil && 
	x==(CAAR(V7))){
	V6= CAR(V7);
	goto L857;
	}else V7=CDR(V7);
	V6= Cnil;}
L857:
	CDR((V6)) = (V1);
	VALUES(0) = (V1);
	RETURN(1);
	}
L852:
	siLinstance_class(1,(V2))                 /*  INSTANCE-CLASS  */;
	RETURN((*LK22)(4,VALUES(0),(V2),(V3),VV[4])/*  SLOT-MISSING   */);
	}
}
/*	function definition for GENERAL-INSTANCE-GET                  */
static L40(int narg, object V1, object V2)
{ VT62 VLEX62 CLSR62
TTL:
	{object V3;                               /*  CLASS           */
	object V4;                                /*  INDEX           */
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	V3= VALUES(0);
	T0= ((V3))->in.in_slots[3];
	T1= (VV[243]->s.s_gfdef);
	VALUES(0) = (VV[259]->s.s_gfdef);
	(*LK27)(6,(V2),T0,VV[116],T1,VV[117],VALUES(0))/*  POSITION   */;
	V4= VALUES(0);
	if(((V4))==Cnil){
	goto L867;}
	{object V5;                               /*  VAL             */
	siLinstance_ref(2,(V1),(V4))              /*  INSTANCE-REF    */;
	V5= VALUES(0);
	if(!(((V5))!=OBJNULL)){
	goto L871;}
	VALUES(1) = VV[58];
	VALUES(0) = (V5);
	RETURN(2);
L871:
	VALUES(1) = VV[59];
	VALUES(0) = Cnil;
	RETURN(2);
	}
L867:
	VALUES(1) = VV[60];
	VALUES(0) = Cnil;
	RETURN(2);
	}
}
static LKF27(int narg, ...) {TRAMPOLINK(VV[260],&LK27);}
static LKF26(int narg, ...) {TRAMPOLINK(VV[253],&LK26);}
static LKF25(int narg, ...) {TRAMPOLINK(VV[140],&LK25);}
static LKF24(int narg, ...) {TRAMPOLINK(VV[252],&LK24);}
static LKF23(int narg, ...) {TRAMPOLINK(VV[251],&LK23);}
static LKF22(int narg, ...) {TRAMPOLINK(VV[246],&LK22);}
static LKF21(int narg, ...) {TRAMPOLINK(VV[245],&LK21);}
static LKF20(int narg, ...) {TRAMPOLINK(VV[93],&LK20);}
static LKF19(int narg, ...) {TRAMPOLINK(VV[4],&LK19);}
static LKF18(int narg, ...) {TRAMPOLINK(VV[68],&LK18);}
static LKF17(int narg, ...) {TRAMPOLINK(VV[244],&LK17);}
static LKF16(int narg, ...) {TRAMPOLINK(VV[243],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[48],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[52],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[44],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[242],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[241],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[240],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[239],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[133],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[238],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[237],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[179],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[236],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[235],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[234],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[47],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[233],&LK0);}
