
#include "print.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	VV[27] = make_cfun(LC1,Cnil,&Cblock);
	VALUES(0) = VV[27];
	funcall(8,VV[28]->s.s_gfdef,VV[0],Cnil,VV[1],VV[2],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[29] = make_cfun(LC2,Cnil,&Cblock);
	VALUES(0) = VV[29];
	funcall(8,VV[28]->s.s_gfdef,VV[0],Cnil,VV[9],VV[10],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[30] = make_cfun(LC3,Cnil,&Cblock);
	VALUES(0) = VV[30];
	funcall(8,VV[28]->s.s_gfdef,VV[12],Cnil,VV[13],VV[14],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[31] = make_cfun(LC4,Cnil,&Cblock);
	VALUES(0) = VV[31];
	funcall(8,VV[28]->s.s_gfdef,VV[12],Cnil,VV[18],VV[19],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	local function CLOSURE                                        */
static LC4(int narg, object V1, ...)
{ VT3 VLEX3 CLSR3
	{int i=1;
	register object V2;
	va_list args; va_start(args, V1);
	if (i==narg) goto L9;
	V2= va_arg(args, object);
	i++;
	goto L10;
L9:
	V2= Ct;
L10:
	{object V3;                               /*  CLASS           */
	object V4;                                /*  SLOTDS          */
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	V3= VALUES(0);
	V4= ((V3))->in.in_slots[3];
	Lformat(4,(V2),VV[20],(V1),((V3))->in.in_slots[0])/*  FORMAT  */;
	{register object V5;                      /*  SCAN            */
	register int V6;                          /*  I               */
	object V7;                                /*  SV              */
	V6= 0;
	V5= (V4);
	V7= Cnil;
L18:
	if(((V5))!=Cnil){
	goto L19;}
	goto L12;
L19:
	{object V9= CAR((V5));
	VALUES(0) = CAR(V9);}
	print(VALUES(0),(V2));
	princ(VV[21],(V2));
	{object V9;
	{object V10= CAR((V5));
	V9= CAR(V10);}
	{register object x= (V9),V10= VV[22];
	while(V10!=Cnil)
	if(eql(x, CAR(V10))){
	goto L29;
	}else V10=CDR(V10);
	goto L28;}
L29:
	princ(VV[23],(V2));
	{register object V10;                     /*  SCAN            */
	object V11;                               /*  E               */
	siLinstance_ref(2,(V1),MAKE_FIXNUM(V6))   /*  INSTANCE-REF    */;
	V10= VALUES(0);
	V11= CAR((V10));
L35:
	if(((V10))!=Cnil){
	goto L36;}
	goto L31;
L36:
	prin1(((V11))->in.in_slots[0],(V2));
	if((CDR((V10)))==Cnil){
	goto L40;}
	princ(VV[24],(V2));
L40:
	V10= CDR((V10));
	V11= CAR((V10));
	goto L35;
	}
L31:
	princ(VV[25],(V2));
	goto L25;
L28:
	siLinstance_ref(2,(V1),MAKE_FIXNUM(V6))   /*  INSTANCE-REF    */;
	V7= VALUES(0);
	if(!(((V7))!=OBJNULL)){
	goto L51;}
	prin1((V7),(V2));
	goto L25;
L51:
	prin1(VV[26],(V2));
	}
L25:
	V5= CDR((V5));
	V6= (V6)+1;
	goto L18;
	}
	}
L12:
	VALUES(0) = (V1);
	RETURN(1);
	}
}
/*	local function DESCRIBE-OBJECT                                */
static LC3(int narg, object V1, ...)
{ VT4 VLEX4 CLSR4
	{int i=1;
	register object V2;
	va_list args; va_start(args, V1);
	if (i==narg) goto L57;
	V2= va_arg(args, object);
	i++;
	goto L58;
L57:
	V2= Ct;
L58:
	{object V3;                               /*  CLASS           */
	object V4;                                /*  SLOTDS          */
	(*LK0)(1,(V1))                            /*  CLASS-OF        */;
	V3= VALUES(0);
	V4= ((V3))->in.in_slots[3];
	Lformat(4,(V2),VV[15],(V1),((V3))->in.in_slots[0])/*  FORMAT  */;
	{register object V5;                      /*  SCAN            */
	register int V6;                          /*  I               */
	object V7;                                /*  SV              */
	V6= 0;
	V5= (V4);
	V7= Cnil;
L66:
	if(((V5))!=Cnil){
	goto L67;}
	goto L60;
L67:
	siLinstance_ref(2,(V1),MAKE_FIXNUM(V6))   /*  INSTANCE-REF    */;
	V7= VALUES(0);
	{object V9= CAR((V5));
	VALUES(0) = CAR(V9);}
	print(VALUES(0),(V2));
	princ(VV[16],(V2));
	if(!(((V7))!=OBJNULL)){
	goto L77;}
	prin1((V7),(V2));
	goto L75;
L77:
	prin1(VV[17],(V2));
L75:
	V5= CDR((V5));
	V6= (V6)+1;
	goto L66;
	}
	}
L60:
	VALUES(0) = (V1);
	RETURN(1);
	}
}
/*	local function CLOSURE                                        */
static LC2(int narg, object V1, object V2)
{ VT5 VLEX5 CLSR5
	{register object V3;
	V3= (V2);
	if(!(numberp((VV[3]->s.s_dbind)))){
	goto L87;}
	bds_bind(VV[3],number_minus((VV[3]->s.s_dbind),MAKE_FIXNUM(1)));/*  *PRINT-LEVEL**/
	goto L85;
L87:
	bds_bind(VV[3],Cnil);                     /*  *PRINT-LEVEL*   */
L85:
	princ(VV[4],(V3));
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	Lformat(4,(V2),VV[11],(VALUES(0))->in.in_slots[0],((V1))->in.in_slots[0])/*  FORMAT*/;
	princ(VV[6],(V3));
	siLaddress(1,(V1))                        /*  POINTER         */;
	Lformat(3,(V3),VV[7],VALUES(0))           /*  FORMAT          */;
	T0= princ(VV[8],(V3));
	bds_unwind1;
	T0= T0;
	}
	VALUES(0) = (V1);
	RETURN(1);
}
/*	local function PRINT-OBJECT                                   */
static LC1(int narg, object V1, object V2)
{ VT6 VLEX6 CLSR6
	{register object V3;
	V3= (V2);
	if(!(numberp((VV[3]->s.s_dbind)))){
	goto L99;}
	bds_bind(VV[3],number_minus((VV[3]->s.s_dbind),MAKE_FIXNUM(1)));/*  *PRINT-LEVEL**/
	goto L97;
L99:
	bds_bind(VV[3],Cnil);                     /*  *PRINT-LEVEL*   */
L97:
	princ(VV[4],(V3));
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	Lformat(3,(V2),VV[5],(VALUES(0))->in.in_slots[0])/*  FORMAT   */;
	princ(VV[6],(V3));
	siLaddress(1,(V1))                        /*  POINTER         */;
	Lformat(3,(V3),VV[7],VALUES(0))           /*  FORMAT          */;
	T0= princ(VV[8],(V3));
	bds_unwind1;
	T0= T0;
	}
	VALUES(0) = (V1);
	RETURN(1);
}
static LKF0(int narg, ...) {TRAMPOLINK(VV[32],&LK0);}
