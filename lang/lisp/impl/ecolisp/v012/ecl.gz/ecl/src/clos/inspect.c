
#include "inspect.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	VV[140] = make_cfun(LC1,Cnil,&Cblock);
	VALUES(0) = VV[140];
	funcall(8,VV[141]->s.s_gfdef,VV[0],Cnil,VV[1],VV[2],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[142] = make_cfun(LC2,Cnil,&Cblock);
	VALUES(0) = VV[142];
	funcall(8,VV[141]->s.s_gfdef,VV[0],Cnil,VV[10],VV[11],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[143] = make_cfun(LC3,Cnil,&Cblock);
	VALUES(0) = VV[143];
	funcall(8,VV[141]->s.s_gfdef,VV[12],Cnil,VV[13],VV[14],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[144] = make_cfun(LC4,Cnil,&Cblock);
	VALUES(0) = VV[144];
	funcall(8,VV[141]->s.s_gfdef,VV[12],Cnil,VV[15],VV[16],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[145] = make_cfun(LC5,Cnil,&Cblock);
	VALUES(0) = VV[145];
	funcall(8,VV[141]->s.s_gfdef,VV[17],Cnil,VV[18],VV[19],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[146] = make_cfun(LC6,Cnil,&Cblock);
	VALUES(0) = VV[146];
	funcall(8,VV[141]->s.s_gfdef,VV[17],Cnil,VV[33],VV[34],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[147] = make_cfun(LC7,Cnil,&Cblock);
	VALUES(0) = VV[147];
	funcall(8,VV[141]->s.s_gfdef,VV[17],Cnil,VV[40],VV[41],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[148] = make_cfun(LC8,Cnil,&Cblock);
	VALUES(0) = VV[148];
	funcall(8,VV[141]->s.s_gfdef,VV[47],Cnil,VV[48],VV[49],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[149] = make_cfun(LC9,Cnil,&Cblock);
	VALUES(0) = VV[149];
	funcall(8,VV[141]->s.s_gfdef,VV[47],Cnil,VV[56],VV[57],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[150] = make_cfun(LC10,Cnil,&Cblock);
	VALUES(0) = VV[150];
	funcall(8,VV[141]->s.s_gfdef,VV[47],Cnil,VV[61],VV[62],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[151] = make_cfun(LC11,Cnil,&Cblock);
	VALUES(0) = VV[151];
	funcall(8,VV[141]->s.s_gfdef,VV[66],Cnil,VV[67],VV[68],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[152] = make_cfun(LC12,Cnil,&Cblock);
	VALUES(0) = VV[152];
	funcall(8,VV[141]->s.s_gfdef,VV[66],Cnil,VV[76],VV[77],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[153] = make_cfun(LC13,Cnil,&Cblock);
	VALUES(0) = VV[153];
	funcall(8,VV[141]->s.s_gfdef,VV[66],Cnil,VV[82],VV[83],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	MF0(VV[154],L14);
	(void)putprop(VV[154],VV[Vdeb154],VV[155]);
	VV[156] = make_cfun(LC15,Cnil,&Cblock);
	VALUES(0) = VV[156];
	funcall(8,VV[141]->s.s_gfdef,VV[89],Cnil,VV[90],VV[91],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[157] = make_cfun(LC16,Cnil,&Cblock);
	VALUES(0) = VV[157];
	funcall(8,VV[141]->s.s_gfdef,VV[89],Cnil,VV[110],VV[111],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[158] = make_cfun(LC17,Cnil,&Cblock);
	VALUES(0) = VV[158];
	funcall(8,VV[141]->s.s_gfdef,VV[89],Cnil,VV[125],VV[126],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	local function INSPECT-OBJ                                    */
static LC17(int narg, object V1)
{ VT3 VLEX3 CLSR3
	(VV[23]->s.s_dbind)= number_minus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	{object V2;                               /*  CLASS           */
	object V3;                                /*  LOCAL-SLOTDS    */
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	V2= VALUES(0);
	(*LK0)(2,(V2),VV[20])                     /*  SLOT-VALUE      */;
	V3= VALUES(0);
L39:
	Lformat(3,Ct,VV[127],(V1))                /*  FORMAT          */;
	(VV[23]->s.s_dbind)= number_plus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	(*LK1)(0)                                 /*  INSPECT-INDENT  */;
	Lformat(3,Ct,VV[128],((V2))->in.in_slots[0])/*  FORMAT        */;
	(*LK1)(0)                                 /*  INSPECT-INDENT  */;
	Lformat(3,Ct,VV[129],MAKE_FIXNUM(length((V3))))/*  FORMAT     */;
	Lforce_output(0)                          /*  FORCE-OUTPUT    */;
	{register object V4;
	{object V5;                               /*  CHAR            */
	Lread_char(1,(VV[69]->s.s_dbind))         /*  READ-CHAR       */;
	V5= VALUES(0);
L53:
	if(!(char_code((V5))!=char_code(code_char('\40')))){
	goto L58;}
	Lchar_neq(1,code_char('\11'))             /*  CHAR/=          */;
	if(VALUES(0)==Cnil){
	goto L54;}
	goto L56;
L58:
	goto L54;
L56:
	V4= (V5);
	goto L50;
L54:
	Lread_char(1,(VV[69]->s.s_dbind))         /*  READ-CHAR       */;
	V5= VALUES(0);
	goto L53;
	}
L50:
	{register object x= (V4),V5= VV[130];
	while(V5!=Cnil)
	if(eql(x, CAR(V5))){
	goto L65;
	}else V5=CDR(V5);
	goto L64;}
L65:
	(*LK2)(1,(V1))                            /*  SELECT-CLOS-N   */;
	goto L35;
L64:
	{register object x= (V4),V6= VV[131];
	while(V6!=Cnil)
	if(eql(x, CAR(V6))){
	goto L69;
	}else V6=CDR(V6);
	goto L68;}
L69:
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	(*LK2)(1,(V1))                            /*  SELECT-CLOS-N   */;
	goto L35;
L68:
	{register object x= (V4),V7= VV[132];
	while(V7!=Cnil)
	if(eql(x, CAR(V7))){
	goto L74;
	}else V7=CDR(V7);
	goto L73;}
L74:
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	goto L35;
L73:
	{register object x= (V4),V8= VV[133];
	while(V8!=Cnil)
	if(eql(x, CAR(V8))){
	goto L78;
	}else V8=CDR(V8);
	goto L77;}
L78:
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	(*LK4)(1,(V1))                            /*  SELECT-P        */;
	goto L49;
L77:
	{register object x= (V4),V8= VV[134];
	while(V8!=Cnil)
	if(eql(x, CAR(V8))){
	goto L82;
	}else V8=CDR(V8);
	goto L81;}
L82:
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	{frame_ptr fr; int V8;
	fr=frs_sch_catch(VV[95]);
	if (fr==NULL) FEerror("The tag ~s is undefined.",1,VV[95]);
	VALUES(0)=Cnil;
	V8=1;
	unwind(fr,VV[95],V8+1);}
L81:
	{register object x= (V4),V9= VV[135];
	while(V9!=Cnil)
	if(eql(x, CAR(V9))){
	goto L87;
	}else V9=CDR(V9);
	goto L86;}
L87:
	(*LK5)(0)                                 /*  SELECT-E        */;
	goto L49;
L86:
	{register object x= (V4),V9= VV[136];
	while(V9!=Cnil)
	if(eql(x, CAR(V9))){
	goto L90;
	}else V9=CDR(V9);
	goto L89;}
L90:
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	{frame_ptr fr; int V9;
	fr=frs_sch_catch(VV[106]);
	if (fr==NULL) FEerror("The tag ~s is undefined.",1,VV[106]);
	VALUES(0)=Cnil;
	V9=1;
	unwind(fr,VV[106],V9+1);}
L89:
	{register object x= (V4),V10= VV[137];
	while(V10!=Cnil)
	if(eql(x, CAR(V10))){
	goto L95;
	}else V10=CDR(V10);
	goto L94;}
L95:
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	(*LK6)(1,(V1))                            /*  SELECT-CLOS-L   */;
	goto L49;
L94:
	{register object x= (V4),V10= VV[138];
	while(V10!=Cnil)
	if(eql(x, CAR(V10))){
	goto L99;
	}else V10=CDR(V10);
	goto L98;}
L99:
	(*LK7)(1,(V1))                            /*  SELECT-CLOS-J   */;
	goto L49;
L98:
	{register object x= (V4),V10= VV[139];
	while(V10!=Cnil)
	if(eql(x, CAR(V10))){
	goto L102;
	}else V10=CDR(V10);
	goto L101;}
L102:
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	L14(0)                                    /*  SELECT-CLOS-?   */;
	goto L49;
L101:
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	}
L49:
	(VV[23]->s.s_dbind)= number_minus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	(*LK1)(0)                                 /*  INSPECT-INDENT  */;
	goto L39;
	}
L35:
	(VV[23]->s.s_dbind)= number_plus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	VALUES(0) = (VV[23]->s.s_dbind);
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC16(int narg, object V1)
{ VT4 VLEX4 CLSR4
	(VV[23]->s.s_dbind)= number_minus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	{object V2;                               /*  CLASS           */
	object V3;                                /*  LOCAL-SLOTDS    */
	V2= ((V1))->in.in_class;
	(*LK0)(2,(V2),VV[20])                     /*  SLOT-VALUE      */;
	V3= VALUES(0);
L114:
	Lformat(3,Ct,VV[112],(V1))                /*  FORMAT          */;
	(VV[23]->s.s_dbind)= number_plus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	(*LK1)(0)                                 /*  INSPECT-INDENT  */;
	Lformat(3,Ct,VV[113],((V2))->in.in_slots[0])/*  FORMAT        */;
	(*LK1)(0)                                 /*  INSPECT-INDENT  */;
	Lformat(3,Ct,VV[114],MAKE_FIXNUM(length((V3))))/*  FORMAT     */;
	Lforce_output(0)                          /*  FORCE-OUTPUT    */;
	{register object V4;
	{object V5;                               /*  CHAR            */
	Lread_char(1,(VV[69]->s.s_dbind))         /*  READ-CHAR       */;
	V5= VALUES(0);
L128:
	if(!(char_code((V5))!=char_code(code_char('\40')))){
	goto L133;}
	Lchar_neq(1,code_char('\11'))             /*  CHAR/=          */;
	if(VALUES(0)==Cnil){
	goto L129;}
	goto L131;
L133:
	goto L129;
L131:
	V4= (V5);
	goto L125;
L129:
	Lread_char(1,(VV[69]->s.s_dbind))         /*  READ-CHAR       */;
	V5= VALUES(0);
	goto L128;
	}
L125:
	{register object x= (V4),V5= VV[115];
	while(V5!=Cnil)
	if(eql(x, CAR(V5))){
	goto L140;
	}else V5=CDR(V5);
	goto L139;}
L140:
	(*LK2)(1,(V1))                            /*  SELECT-CLOS-N   */;
	goto L110;
L139:
	{register object x= (V4),V6= VV[116];
	while(V6!=Cnil)
	if(eql(x, CAR(V6))){
	goto L144;
	}else V6=CDR(V6);
	goto L143;}
L144:
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	(*LK2)(1,(V1))                            /*  SELECT-CLOS-N   */;
	goto L110;
L143:
	{register object x= (V4),V7= VV[117];
	while(V7!=Cnil)
	if(eql(x, CAR(V7))){
	goto L149;
	}else V7=CDR(V7);
	goto L148;}
L149:
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	goto L110;
L148:
	{register object x= (V4),V8= VV[118];
	while(V8!=Cnil)
	if(eql(x, CAR(V8))){
	goto L153;
	}else V8=CDR(V8);
	goto L152;}
L153:
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	(*LK4)(1,(V1))                            /*  SELECT-P        */;
	goto L124;
L152:
	{register object x= (V4),V8= VV[119];
	while(V8!=Cnil)
	if(eql(x, CAR(V8))){
	goto L157;
	}else V8=CDR(V8);
	goto L156;}
L157:
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	{frame_ptr fr; int V8;
	fr=frs_sch_catch(VV[95]);
	if (fr==NULL) FEerror("The tag ~s is undefined.",1,VV[95]);
	VALUES(0)=Cnil;
	V8=1;
	unwind(fr,VV[95],V8+1);}
L156:
	{register object x= (V4),V9= VV[120];
	while(V9!=Cnil)
	if(eql(x, CAR(V9))){
	goto L162;
	}else V9=CDR(V9);
	goto L161;}
L162:
	(*LK5)(0)                                 /*  SELECT-E        */;
	goto L124;
L161:
	{register object x= (V4),V9= VV[121];
	while(V9!=Cnil)
	if(eql(x, CAR(V9))){
	goto L165;
	}else V9=CDR(V9);
	goto L164;}
L165:
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	{frame_ptr fr; int V9;
	fr=frs_sch_catch(VV[106]);
	if (fr==NULL) FEerror("The tag ~s is undefined.",1,VV[106]);
	VALUES(0)=Cnil;
	V9=1;
	unwind(fr,VV[106],V9+1);}
L164:
	{register object x= (V4),V10= VV[122];
	while(V10!=Cnil)
	if(eql(x, CAR(V10))){
	goto L170;
	}else V10=CDR(V10);
	goto L169;}
L170:
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	(*LK6)(1,(V1))                            /*  SELECT-CLOS-L   */;
	goto L124;
L169:
	{register object x= (V4),V10= VV[123];
	while(V10!=Cnil)
	if(eql(x, CAR(V10))){
	goto L174;
	}else V10=CDR(V10);
	goto L173;}
L174:
	(*LK7)(1,(V1))                            /*  SELECT-CLOS-J   */;
	goto L124;
L173:
	{register object x= (V4),V10= VV[124];
	while(V10!=Cnil)
	if(eql(x, CAR(V10))){
	goto L177;
	}else V10=CDR(V10);
	goto L176;}
L177:
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	L14(0)                                    /*  SELECT-CLOS-?   */;
	goto L124;
L176:
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	}
L124:
	(VV[23]->s.s_dbind)= number_minus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	(*LK1)(0)                                 /*  INSPECT-INDENT  */;
	goto L114;
	}
L110:
	(VV[23]->s.s_dbind)= number_plus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	VALUES(0) = (VV[23]->s.s_dbind);
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC15(int narg, object V1)
{ VT5 VLEX5 CLSR5
	siLinstance_class(1,((V1))->in.in_class)  /*  INSTANCE-CLASS  */;
	T0= VALUES(0);
	(*LK8)(1,VV[92])                          /*  FIND-CLASS      */;
	if((T0)==(VALUES(0))){
	goto L183;}
	princ_char(10,Cnil);
	Lformat(2,Ct,VV[93])                      /*  FORMAT          */;
	Lformat(3,Ct,VV[94],((V1))->in.in_class)  /*  FORMAT          */;
	{frame_ptr fr; int V2;
	fr=frs_sch_catch(VV[95]);
	if (fr==NULL) FEerror("The tag ~s is undefined.",1,VV[95]);
	VALUES(0)=Cnil;
	V2=1;
	unwind(fr,VV[95],V2+1);}
L183:
	(VV[23]->s.s_dbind)= number_minus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	{object V2;                               /*  CLASS           */
	object V3;                                /*  LOCAL-SLOTDS    */
	object V4;                                /*  CLASS-SLOTDS    */
	V2= ((V1))->in.in_class;
	(*LK0)(2,(V2),VV[20])                     /*  SLOT-VALUE      */;
	V3= VALUES(0);
	(*LK0)(2,(V2),VV[21])                     /*  SLOT-VALUE      */;
	V4= VALUES(0);
L199:
	Lformat(3,Ct,VV[96],(V1))                 /*  FORMAT          */;
	(VV[23]->s.s_dbind)= number_plus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	(*LK1)(0)                                 /*  INSPECT-INDENT  */;
	Lformat(3,Ct,VV[97],((V2))->in.in_slots[0])/*  FORMAT         */;
	(*LK1)(0)                                 /*  INSPECT-INDENT  */;
	Lformat(4,Ct,VV[98],MAKE_FIXNUM(length((V3))),MAKE_FIXNUM(length((V4))))/*  FORMAT*/;
	Lforce_output(0)                          /*  FORCE-OUTPUT    */;
	{register object V5;
	{object V6;                               /*  CHAR            */
	Lread_char(1,(VV[69]->s.s_dbind))         /*  READ-CHAR       */;
	V6= VALUES(0);
L213:
	if(!(char_code((V6))!=char_code(code_char('\40')))){
	goto L218;}
	Lchar_neq(1,code_char('\11'))             /*  CHAR/=          */;
	if(VALUES(0)==Cnil){
	goto L214;}
	goto L216;
L218:
	goto L214;
L216:
	V5= (V6);
	goto L210;
L214:
	Lread_char(1,(VV[69]->s.s_dbind))         /*  READ-CHAR       */;
	V6= VALUES(0);
	goto L213;
	}
L210:
	{register object x= (V5),V6= VV[99];
	while(V6!=Cnil)
	if(eql(x, CAR(V6))){
	goto L225;
	}else V6=CDR(V6);
	goto L224;}
L225:
	(*LK2)(1,(V1))                            /*  SELECT-CLOS-N   */;
	goto L194;
L224:
	{register object x= (V5),V7= VV[100];
	while(V7!=Cnil)
	if(eql(x, CAR(V7))){
	goto L229;
	}else V7=CDR(V7);
	goto L228;}
L229:
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	(*LK2)(1,(V1))                            /*  SELECT-CLOS-N   */;
	goto L194;
L228:
	{register object x= (V5),V8= VV[101];
	while(V8!=Cnil)
	if(eql(x, CAR(V8))){
	goto L234;
	}else V8=CDR(V8);
	goto L233;}
L234:
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	goto L194;
L233:
	{register object x= (V5),V9= VV[102];
	while(V9!=Cnil)
	if(eql(x, CAR(V9))){
	goto L238;
	}else V9=CDR(V9);
	goto L237;}
L238:
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	(*LK4)(1,(V1))                            /*  SELECT-P        */;
	goto L209;
L237:
	{register object x= (V5),V9= VV[103];
	while(V9!=Cnil)
	if(eql(x, CAR(V9))){
	goto L242;
	}else V9=CDR(V9);
	goto L241;}
L242:
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	{frame_ptr fr; int V9;
	fr=frs_sch_catch(VV[95]);
	if (fr==NULL) FEerror("The tag ~s is undefined.",1,VV[95]);
	VALUES(0)=Cnil;
	V9=1;
	unwind(fr,VV[95],V9+1);}
L241:
	{register object x= (V5),V10= VV[104];
	while(V10!=Cnil)
	if(eql(x, CAR(V10))){
	goto L247;
	}else V10=CDR(V10);
	goto L246;}
L247:
	(*LK5)(0)                                 /*  SELECT-E        */;
	goto L209;
L246:
	{register object x= (V5),V10= VV[105];
	while(V10!=Cnil)
	if(eql(x, CAR(V10))){
	goto L250;
	}else V10=CDR(V10);
	goto L249;}
L250:
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	{frame_ptr fr; int V10;
	fr=frs_sch_catch(VV[106]);
	if (fr==NULL) FEerror("The tag ~s is undefined.",1,VV[106]);
	VALUES(0)=Cnil;
	V10=1;
	unwind(fr,VV[106],V10+1);}
L249:
	{register object x= (V5),V11= VV[107];
	while(V11!=Cnil)
	if(eql(x, CAR(V11))){
	goto L255;
	}else V11=CDR(V11);
	goto L254;}
L255:
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	(*LK6)(1,(V1))                            /*  SELECT-CLOS-L   */;
	goto L209;
L254:
	{register object x= (V5),V11= VV[108];
	while(V11!=Cnil)
	if(eql(x, CAR(V11))){
	goto L259;
	}else V11=CDR(V11);
	goto L258;}
L259:
	(*LK7)(1,(V1))                            /*  SELECT-CLOS-J   */;
	goto L209;
L258:
	{register object x= (V5),V11= VV[109];
	while(V11!=Cnil)
	if(eql(x, CAR(V11))){
	goto L262;
	}else V11=CDR(V11);
	goto L261;}
L262:
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	L14(0)                                    /*  SELECT-CLOS-?   */;
	goto L209;
L261:
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	}
L209:
	(VV[23]->s.s_dbind)= number_minus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	(*LK1)(0)                                 /*  INSPECT-INDENT  */;
	goto L199;
	}
L194:
	(VV[23]->s.s_dbind)= number_plus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	VALUES(0) = (VV[23]->s.s_dbind);
	RETURN(1);
}
/*	local function SELECT-CLOS-J                                  */
static LC13(int narg, object V1)
{ VT6 VLEX6 CLSR6
	{object V2;                               /*  CLASS           */
	object V3;                                /*  LOCAL-SLOTDS    */
	register object V4;                       /*  SLOTD           */
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	V2= VALUES(0);
	(*LK0)(2,(V2),VV[20])                     /*  SLOT-VALUE      */;
	V3= VALUES(0);
	{object V5;
	Lread_preserving_whitespace(1,(VV[69]->s.s_dbind))/*  READ-PRESERVING-WHITESPACE*/;
	V5= VALUES(0);
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	T0= (V5);
	}
	T1= (VV[164]->s.s_gfdef);
	VALUES(0) = (VV[165]->s.s_gfdef);
	Lmember(6,T0,(V3),VV[70],T1,VV[71],VALUES(0))/*  MEMBER       */;
	V4= CAR(VALUES(0));
	if(((V4))==Cnil){
	goto L278;}
	(VV[23]->s.s_dbind)= number_plus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	(*LK9)(0)                                 /*  INSPECT-INDENT-1*/;
	{object V5= (V4);
	VALUES(0) = CAR(V5);}
	Lformat(3,Ct,VV[84],VALUES(0))            /*  FORMAT          */;
	{object V5= (V4);
	VALUES(0) = CAR(V5);}
	(*LK10)(2,(V1),VALUES(0))                 /*  SLOT-BOUNDP     */;
	if(VALUES(0)==Cnil){
	goto L287;}
	{object V5= (V4);
	VALUES(0) = CAR(V5);}
	(*LK0)(2,(V1),VALUES(0))                  /*  SLOT-VALUE      */;
	(*LK11)(3,VV[85],VALUES(0),Ct)            /*  READ-INSPECT-COMMAND*/;
	if(VALUES(0)==Cnil){
	goto L285;}
	princ_str("Not updated.",Cnil);
	princ_char(10,Cnil);
	goto L285;
L287:
	(*LK11)(3,VV[86],Cnil,Cnil)               /*  READ-INSPECT-COMMAND*/;
	if(VALUES(0)==Cnil){
	goto L285;}
	princ_str("Not updated.",Cnil);
	princ_char(10,Cnil);
L285:
	(VV[23]->s.s_dbind)= number_minus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	VALUES(0) = (VV[23]->s.s_dbind);
	RETURN(1);
L278:
	princ_char(10,Cnil);
	{object V5= (V4);
	VALUES(0) = CAR(V5);}
	Lformat(3,Ct,VV[87],VALUES(0))            /*  FORMAT          */;
	princ_char(10,Cnil);
	VALUES(0) = terpri(Cnil);
	RETURN(1);
	}
}
/*	local function CLOSURE                                        */
static LC12(int narg, object V1)
{ VT7 VLEX7 CLSR7
	{object V2;                               /*  CLASS           */
	object V3;                                /*  LOCAL-SLOTDS    */
	register object V4;                       /*  SLOTD           */
	V2= ((V1))->in.in_class;
	(*LK0)(2,(V2),VV[20])                     /*  SLOT-VALUE      */;
	V3= VALUES(0);
	{object V5;
	Lread_preserving_whitespace(1,(VV[69]->s.s_dbind))/*  READ-PRESERVING-WHITESPACE*/;
	V5= VALUES(0);
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	T0= (V5);
	}
	T1= (VV[164]->s.s_gfdef);
	VALUES(0) = (VV[165]->s.s_gfdef);
	Lmember(6,T0,(V3),VV[70],T1,VV[71],VALUES(0))/*  MEMBER       */;
	V4= CAR(VALUES(0));
	if(((V4))==Cnil){
	goto L313;}
	(VV[23]->s.s_dbind)= number_plus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	(*LK9)(0)                                 /*  INSPECT-INDENT-1*/;
	{object V5= (V4);
	VALUES(0) = CAR(V5);}
	Lformat(3,Ct,VV[78],VALUES(0))            /*  FORMAT          */;
	{object V5= (V4);
	VALUES(0) = CAR(V5);}
	(*LK10)(2,(V1),VALUES(0))                 /*  SLOT-BOUNDP     */;
	if(VALUES(0)==Cnil){
	goto L322;}
	{object V5= (V4);
	VALUES(0) = CAR(V5);}
	(*LK0)(2,(V1),VALUES(0))                  /*  SLOT-VALUE      */;
	(*LK11)(3,VV[79],VALUES(0),Ct)            /*  READ-INSPECT-COMMAND*/;
	if(VALUES(0)==Cnil){
	goto L320;}
	princ_str("Not updated.",Cnil);
	princ_char(10,Cnil);
	goto L320;
L322:
	(*LK11)(3,VV[80],Cnil,Cnil)               /*  READ-INSPECT-COMMAND*/;
	if(VALUES(0)==Cnil){
	goto L320;}
	princ_str("Not updated.",Cnil);
	princ_char(10,Cnil);
L320:
	(VV[23]->s.s_dbind)= number_minus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	VALUES(0) = (VV[23]->s.s_dbind);
	RETURN(1);
L313:
	princ_char(10,Cnil);
	{object V5= (V4);
	VALUES(0) = CAR(V5);}
	Lformat(3,Ct,VV[81],VALUES(0))            /*  FORMAT          */;
	princ_char(10,Cnil);
	VALUES(0) = terpri(Cnil);
	RETURN(1);
	}
}
/*	local function CLOSURE                                        */
static LC11(int narg, object V1)
{ VT8 VLEX8 CLSR8
	{object V2;                               /*  CLASS           */
	object V3;                                /*  LOCAL-SLOTDS    */
	object V4;                                /*  CLASS-SLOTDS    */
	register object V5;                       /*  SLOTD           */
	V2= ((V1))->in.in_class;
	(*LK0)(2,(V2),VV[20])                     /*  SLOT-VALUE      */;
	V3= VALUES(0);
	(*LK0)(2,(V2),VV[21])                     /*  SLOT-VALUE      */;
	V4= VALUES(0);
	{object V6;
	Lread_preserving_whitespace(1,(VV[69]->s.s_dbind))/*  READ-PRESERVING-WHITESPACE*/;
	V6= VALUES(0);
	(*LK3)(0)                                 /*  INSPECT-READ-LINE*/;
	T0= (V6);
	}
	{object V6= append((V3),(V4));
	T1= (VV[164]->s.s_gfdef);
	VALUES(0) = (VV[165]->s.s_gfdef);
	Lmember(6,T0,V6,VV[70],T1,VV[71],VALUES(0))/*  MEMBER         */;
	V5= CAR(VALUES(0));}
	if(((V5))==Cnil){
	goto L349;}
	(VV[23]->s.s_dbind)= number_plus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	(*LK9)(0)                                 /*  INSPECT-INDENT-1*/;
	{object V6= (V5);
	VALUES(0) = CAR(V6);}
	Lformat(3,Ct,VV[72],VALUES(0))            /*  FORMAT          */;
	{object V6= (V5);
	VALUES(0) = CAR(V6);}
	(*LK10)(2,(V1),VALUES(0))                 /*  SLOT-BOUNDP     */;
	if(VALUES(0)==Cnil){
	goto L358;}
	{ int V6;
	object V7;                                /*  UPDATE-FLAG     */
	object V8;                                /*  NEW-VALUE       */
	{object V9= (V5);
	VALUES(0) = CAR(V9);}
	(*LK0)(2,(V1),VALUES(0))                  /*  SLOT-VALUE      */;
	V6=(*LK11)(3,VV[73],VALUES(0),Ct)         /*  READ-INSPECT-COMMAND*/;
	if (V6==0) goto L364;
	V7= VALUES(0);
	V6--;
	if (V6==0) goto L365;
	V8= VALUES(1);
	V6--;
	goto L366;
L364:
	V7= Cnil;
L365:
	V8= Cnil;
L366:
	if(((V7))==Cnil){
	goto L356;}
	{object V9;
	{object V10= (V5);
	V9= CAR(V10);}
	(*LK12)(3,(V8),(V1),(V9))                 /*  (SETF SLOT-VALUE)*/;
	goto L356;
	}}
L358:
	{ int V6;
	object V7;                                /*  UPDATE-FLAG     */
	object V8;                                /*  NEW-VALUE       */
	V6=(*LK11)(3,VV[74],Cnil,Cnil)            /*  READ-INSPECT-COMMAND*/;
	if (V6==0) goto L371;
	V7= VALUES(0);
	V6--;
	if (V6==0) goto L372;
	V8= VALUES(1);
	V6--;
	goto L373;
L371:
	V7= Cnil;
L372:
	V8= Cnil;
L373:
	if(((V7))==Cnil){
	goto L356;}
	{object V9;
	{object V10= (V5);
	V9= CAR(V10);}
	(*LK12)(3,(V8),(V1),(V9))                 /*  (SETF SLOT-VALUE)*/;
	}}
L356:
	(VV[23]->s.s_dbind)= number_minus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	VALUES(0) = (VV[23]->s.s_dbind);
	RETURN(1);
L349:
	princ_char(10,Cnil);
	{object V6= (V5);
	VALUES(0) = CAR(V6);}
	Lformat(3,Ct,VV[75],VALUES(0))            /*  FORMAT          */;
	princ_char(10,Cnil);
	VALUES(0) = terpri(Cnil);
	RETURN(1);
	}
}
/*	local function SELECT-CLOS-L                                  */
static LC10(int narg, object V1)
{ VT9 VLEX9 CLSR9
	{object V2;                               /*  CLASS           */
	object V3;                                /*  LOCAL-SLOTDS    */
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	V2= VALUES(0);
	(*LK0)(2,(V2),VV[20])                     /*  SLOT-VALUE      */;
	V3= VALUES(0);
	princ_char(10,Cnil);
	if(((V3))==Cnil){
	goto L387;}
	Lformat(2,Ct,VV[63])                      /*  FORMAT          */;
	{register object V4;
	object V5;                                /*  SLOTD           */
	V4= (V3);
	V5= Cnil;
L393:
	if(!((V4)==Cnil)){
	goto L394;}
	goto L385;
L394:
	V5= CAR((V4));
	{object V7= (V5);
	VALUES(0) = CAR(V7);}
	Lformat(3,Ct,VV[64],VALUES(0))            /*  FORMAT          */;
	V4= CDR((V4));
	goto L393;
	}
L387:
	Lformat(2,Ct,VV[65])                      /*  FORMAT          */;
L385:
	VALUES(0) = terpri(Cnil);
	RETURN(1);
	}
}
/*	local function CLOSURE                                        */
static LC9(int narg, object V1)
{ VT10 VLEX10 CLSR10
	{object V2;                               /*  CLASS           */
	object V3;                                /*  LOCAL-SLOTDS    */
	V2= ((V1))->in.in_class;
	(*LK0)(2,(V2),VV[20])                     /*  SLOT-VALUE      */;
	V3= VALUES(0);
	princ_char(10,Cnil);
	if(((V3))==Cnil){
	goto L409;}
	Lformat(2,Ct,VV[58])                      /*  FORMAT          */;
	{register object V4;
	object V5;                                /*  SLOTD           */
	V4= (V3);
	V5= Cnil;
L415:
	if(!((V4)==Cnil)){
	goto L416;}
	goto L407;
L416:
	V5= CAR((V4));
	{object V7= (V5);
	VALUES(0) = CAR(V7);}
	Lformat(3,Ct,VV[59],VALUES(0))            /*  FORMAT          */;
	V4= CDR((V4));
	goto L415;
	}
L409:
	Lformat(2,Ct,VV[60])                      /*  FORMAT          */;
L407:
	VALUES(0) = terpri(Cnil);
	RETURN(1);
	}
}
/*	local function CLOSURE                                        */
static LC8(int narg, object V1)
{ VT11 VLEX11 CLSR11
	{object V2;                               /*  CLASS           */
	object V3;                                /*  LOCAL-SLOTDS    */
	object V4;                                /*  CLASS-SLOTDS    */
	V2= ((V1))->in.in_class;
	(*LK0)(2,(V2),VV[20])                     /*  SLOT-VALUE      */;
	V3= VALUES(0);
	(*LK0)(2,(V2),VV[21])                     /*  SLOT-VALUE      */;
	V4= VALUES(0);
	princ_char(10,Cnil);
	if(((V3))==Cnil){
	goto L432;}
	Lformat(2,Ct,VV[50])                      /*  FORMAT          */;
	{register object V5;
	object V6;                                /*  SLOTD           */
	V5= (V3);
	V6= Cnil;
L438:
	if(!((V5)==Cnil)){
	goto L439;}
	goto L430;
L439:
	V6= CAR((V5));
	{object V8= (V6);
	VALUES(0) = CAR(V8);}
	Lformat(3,Ct,VV[51],VALUES(0))            /*  FORMAT          */;
	V5= CDR((V5));
	goto L438;
	}
L432:
	Lformat(2,Ct,VV[52])                      /*  FORMAT          */;
L430:
	princ_char(10,Cnil);
	if(((V4))==Cnil){
	goto L452;}
	Lformat(2,Ct,VV[53])                      /*  FORMAT          */;
	{register object V5;
	object V6;                                /*  SLOTD           */
	V5= (V4);
	V6= Cnil;
L458:
	if(!((V5)==Cnil)){
	goto L459;}
	goto L450;
L459:
	V6= CAR((V5));
	{object V8= (V6);
	VALUES(0) = CAR(V8);}
	Lformat(3,Ct,VV[54],VALUES(0))            /*  FORMAT          */;
	V5= CDR((V5));
	goto L458;
	}
L452:
	Lformat(2,Ct,VV[55])                      /*  FORMAT          */;
L450:
	VALUES(0) = terpri(Cnil);
	RETURN(1);
	}
}
/*	local function SELECT-CLOS-N                                  */
static LC7(int narg, object V1)
{ VT12 VLEX12 CLSR12
	{object V2;                               /*  CLASS           */
	object V3;                                /*  LOCAL-SLOTDS    */
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	V2= VALUES(0);
	(*LK0)(2,(V2),VV[20])                     /*  SLOT-VALUE      */;
	V3= VALUES(0);
	if(((V3))==Cnil){
	goto L472;}
	(*LK1)(0)                                 /*  INSPECT-INDENT  */;
	Lformat(2,Ct,VV[42])                      /*  FORMAT          */;
	(VV[23]->s.s_dbind)= number_plus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	{register object V4;
	register object V5;                       /*  SLOTD           */
	V4= (V3);
	V5= Cnil;
L482:
	if(!((V4)==Cnil)){
	goto L483;}
	goto L478;
L483:
	V5= CAR((V4));
	(*LK9)(0)                                 /*  INSPECT-INDENT-1*/;
	{object V7= (V5);
	VALUES(0) = CAR(V7);}
	Lformat(3,Ct,VV[43],VALUES(0))            /*  FORMAT          */;
	{object V7= (V5);
	VALUES(0) = CAR(V7);}
	(*LK10)(2,(V1),VALUES(0))                 /*  SLOT-BOUNDP     */;
	if(VALUES(0)==Cnil){
	goto L493;}
	{object V7= (V5);
	VALUES(0) = CAR(V7);}
	(*LK0)(2,(V1),VALUES(0))                  /*  SLOT-VALUE      */;
	(*LK11)(3,VV[44],VALUES(0),Ct)            /*  READ-INSPECT-COMMAND*/;
	if(VALUES(0)==Cnil){
	goto L491;}
	princ_str("Not updated.",Cnil);
	princ_char(10,Cnil);
	goto L491;
L493:
	(*LK11)(3,VV[45],Cnil,Cnil)               /*  READ-INSPECT-COMMAND*/;
	if(VALUES(0)==Cnil){
	goto L491;}
	princ_str("Not updated.",Cnil);
	princ_char(10,Cnil);
L491:
	V4= CDR((V4));
	goto L482;
	}
L478:
	(VV[23]->s.s_dbind)= number_minus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	VALUES(0) = (VV[23]->s.s_dbind);
	RETURN(1);
L472:
	(*LK1)(0)                                 /*  INSPECT-INDENT  */;
	RETURN(Lformat(2,Ct,VV[46])               /*  FORMAT          */);
	}
}
/*	local function CLOSURE                                        */
static LC6(int narg, object V1)
{ VT13 VLEX13 CLSR13
	{object V2;                               /*  CLASS           */
	object V3;                                /*  LOCAL-SLOTDS    */
	V2= ((V1))->in.in_class;
	(*LK0)(2,(V2),VV[20])                     /*  SLOT-VALUE      */;
	V3= VALUES(0);
	if(((V3))==Cnil){
	goto L512;}
	(*LK1)(0)                                 /*  INSPECT-INDENT  */;
	Lformat(2,Ct,VV[35])                      /*  FORMAT          */;
	(VV[23]->s.s_dbind)= number_plus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	{register object V4;
	register object V5;                       /*  SLOTD           */
	V4= (V3);
	V5= Cnil;
L522:
	if(!((V4)==Cnil)){
	goto L523;}
	goto L518;
L523:
	V5= CAR((V4));
	(*LK9)(0)                                 /*  INSPECT-INDENT-1*/;
	{object V7= (V5);
	VALUES(0) = CAR(V7);}
	Lformat(3,Ct,VV[36],VALUES(0))            /*  FORMAT          */;
	{object V7= (V5);
	VALUES(0) = CAR(V7);}
	(*LK10)(2,(V1),VALUES(0))                 /*  SLOT-BOUNDP     */;
	if(VALUES(0)==Cnil){
	goto L533;}
	{object V7= (V5);
	VALUES(0) = CAR(V7);}
	(*LK0)(2,(V1),VALUES(0))                  /*  SLOT-VALUE      */;
	(*LK11)(3,VV[37],VALUES(0),Ct)            /*  READ-INSPECT-COMMAND*/;
	if(VALUES(0)==Cnil){
	goto L531;}
	princ_str("Not updated.",Cnil);
	princ_char(10,Cnil);
	goto L531;
L533:
	(*LK11)(3,VV[38],Cnil,Cnil)               /*  READ-INSPECT-COMMAND*/;
	if(VALUES(0)==Cnil){
	goto L531;}
	princ_str("Not updated.",Cnil);
	princ_char(10,Cnil);
L531:
	V4= CDR((V4));
	goto L522;
	}
L518:
	(VV[23]->s.s_dbind)= number_minus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	VALUES(0) = (VV[23]->s.s_dbind);
	RETURN(1);
L512:
	(*LK1)(0)                                 /*  INSPECT-INDENT  */;
	RETURN(Lformat(2,Ct,VV[39])               /*  FORMAT          */);
	}
}
/*	local function CLOSURE                                        */
static LC5(int narg, object V1)
{ VT14 VLEX14 CLSR14
	{object V2;                               /*  CLASS           */
	object V3;                                /*  LOCAL-SLOTDS    */
	object V4;                                /*  CLASS-SLOTDS    */
	V2= ((V1))->in.in_class;
	(*LK0)(2,(V2),VV[20])                     /*  SLOT-VALUE      */;
	V3= VALUES(0);
	(*LK0)(2,(V2),VV[21])                     /*  SLOT-VALUE      */;
	V4= VALUES(0);
	if(((V3))==Cnil){
	goto L554;}
	(*LK1)(0)                                 /*  INSPECT-INDENT  */;
	Lformat(2,Ct,VV[22])                      /*  FORMAT          */;
	(VV[23]->s.s_dbind)= number_plus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	{register object V5;
	register object V6;                       /*  SLOTD           */
	V5= (V3);
	V6= Cnil;
L564:
	if(!((V5)==Cnil)){
	goto L565;}
	goto L560;
L565:
	V6= CAR((V5));
	(*LK9)(0)                                 /*  INSPECT-INDENT-1*/;
	{object V8= (V6);
	VALUES(0) = CAR(V8);}
	Lformat(3,Ct,VV[24],VALUES(0))            /*  FORMAT          */;
	{object V8= (V6);
	VALUES(0) = CAR(V8);}
	(*LK10)(2,(V1),VALUES(0))                 /*  SLOT-BOUNDP     */;
	if(VALUES(0)==Cnil){
	goto L575;}
	{ int V8;
	object V9;                                /*  UPDATE-FLAG     */
	object V10;                               /*  NEW-VALUE       */
	{object V11= (V6);
	VALUES(0) = CAR(V11);}
	(*LK0)(2,(V1),VALUES(0))                  /*  SLOT-VALUE      */;
	V8=(*LK11)(3,VV[25],VALUES(0),Ct)         /*  READ-INSPECT-COMMAND*/;
	if (V8==0) goto L581;
	V9= VALUES(0);
	V8--;
	if (V8==0) goto L582;
	V10= VALUES(1);
	V8--;
	goto L583;
L581:
	V9= Cnil;
L582:
	V10= Cnil;
L583:
	if(((V9))==Cnil){
	goto L573;}
	{object V11;
	{object V12= (V6);
	V11= CAR(V12);}
	(*LK12)(3,(V10),(V1),(V11))               /*  (SETF SLOT-VALUE)*/;
	goto L573;
	}}
L575:
	{ int V8;
	object V9;                                /*  UPDATE-FLAG     */
	object V10;                               /*  NEW-VALUE       */
	V8=(*LK11)(3,VV[26],Cnil,Cnil)            /*  READ-INSPECT-COMMAND*/;
	if (V8==0) goto L588;
	V9= VALUES(0);
	V8--;
	if (V8==0) goto L589;
	V10= VALUES(1);
	V8--;
	goto L590;
L588:
	V9= Cnil;
L589:
	V10= Cnil;
L590:
	if(((V9))==Cnil){
	goto L573;}
	{object V11;
	{object V12= (V6);
	V11= CAR(V12);}
	(*LK12)(3,(V10),(V1),(V11))               /*  (SETF SLOT-VALUE)*/;
	}}
L573:
	V5= CDR((V5));
	goto L564;
	}
L560:
	(VV[23]->s.s_dbind)= number_minus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	goto L552;
L554:
	(*LK1)(0)                                 /*  INSPECT-INDENT  */;
	Lformat(2,Ct,VV[27])                      /*  FORMAT          */;
L552:
	if(((V4))==Cnil){
	goto L600;}
	(*LK1)(0)                                 /*  INSPECT-INDENT  */;
	Lformat(2,Ct,VV[28])                      /*  FORMAT          */;
	(VV[23]->s.s_dbind)= number_plus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	{register object V5;
	register object V6;                       /*  SLOTD           */
	V5= (V4);
	V6= Cnil;
L610:
	if(!((V5)==Cnil)){
	goto L611;}
	goto L606;
L611:
	V6= CAR((V5));
	(*LK9)(0)                                 /*  INSPECT-INDENT-1*/;
	{object V8= (V6);
	VALUES(0) = CAR(V8);}
	Lformat(3,Ct,VV[29],VALUES(0))            /*  FORMAT          */;
	{object V8= (V6);
	VALUES(0) = CAR(V8);}
	(*LK10)(2,(V1),VALUES(0))                 /*  SLOT-BOUNDP     */;
	if(VALUES(0)==Cnil){
	goto L621;}
	{ int V8;
	object V9;                                /*  UPDATE-FLAG     */
	object V10;                               /*  NEW-VALUE       */
	{object V11= (V6);
	VALUES(0) = CAR(V11);}
	(*LK0)(2,(V1),VALUES(0))                  /*  SLOT-VALUE      */;
	V8=(*LK11)(3,VV[30],VALUES(0),Ct)         /*  READ-INSPECT-COMMAND*/;
	if (V8==0) goto L627;
	V9= VALUES(0);
	V8--;
	if (V8==0) goto L628;
	V10= VALUES(1);
	V8--;
	goto L629;
L627:
	V9= Cnil;
L628:
	V10= Cnil;
L629:
	if(((V9))==Cnil){
	goto L619;}
	{object V11;
	{object V12= (V6);
	V11= CAR(V12);}
	(*LK12)(3,(V10),(V1),(V11))               /*  (SETF SLOT-VALUE)*/;
	goto L619;
	}}
L621:
	{ int V8;
	object V9;                                /*  UPDATE-FLAG     */
	object V10;                               /*  NEW-VALUE       */
	V8=(*LK11)(3,VV[31],Cnil,Cnil)            /*  READ-INSPECT-COMMAND*/;
	if (V8==0) goto L634;
	V9= VALUES(0);
	V8--;
	if (V8==0) goto L635;
	V10= VALUES(1);
	V8--;
	goto L636;
L634:
	V9= Cnil;
L635:
	V10= Cnil;
L636:
	if(((V9))==Cnil){
	goto L619;}
	{object V11;
	{object V12= (V6);
	V11= CAR(V12);}
	(*LK12)(3,(V10),(V1),(V11))               /*  (SETF SLOT-VALUE)*/;
	}}
L619:
	V5= CDR((V5));
	goto L610;
	}
L606:
	(VV[23]->s.s_dbind)= number_minus((VV[23]->s.s_dbind),MAKE_FIXNUM(1));
	VALUES(0) = (VV[23]->s.s_dbind);
	RETURN(1);
L600:
	(*LK1)(0)                                 /*  INSPECT-INDENT  */;
	RETURN(Lformat(2,Ct,VV[32])               /*  FORMAT          */);
	}
}
/*	local function SLOT-BOUNDP                                    */
static LC4(int narg, object V1, object V2)
{ VT15 VLEX15 CLSR15
	{ int V3;
	object V4;                                /*  VAL             */
	object V5;                                /*  CONDITION       */
	V3=(*LK13)(2,(V1),(V2))                   /*  GENERAL-INSTANCE-GET*/;
	if (V3==0) goto L646;
	V4= VALUES(0);
	V3--;
	if (V3==0) goto L647;
	V5= VALUES(1);
	V3--;
	goto L648;
L646:
	V4= Cnil;
L647:
	V5= Cnil;
L648:
	{register object V6;
	V6= (V5);
	if(!(eql((V6),VV[3]))){
	goto L650;}
	VALUES(0) = Ct;
	RETURN(1);
L650:
	if(!(eql((V6),VV[4]))){
	goto L653;}
	VALUES(0) = Cnil;
	RETURN(1);
L653:
	if(!(eql((V6),VV[5]))){
	goto L656;}
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	RETURN((*LK14)(4,VALUES(0),(V1),(V2),VV[12])/*  SLOT-MISSING  */);
L656:
	bds_bind(VV[6],MAKE_FIXNUM(4));           /*  *PRINT-LEVEL*   */
	bds_bind(VV[7],MAKE_FIXNUM(4));           /*  *PRINT-LENGTH*  */
	{int V7;
	V7=Lerror(6,VV[8],VV[9],(V6),VV[3],VV[4],VV[5])/*  ERROR      */;
	bds_unwind1;
	bds_unwind1;
	RETURN(V7);}
	}}
}
/*	local function CLOSURE                                        */
static LC3(int narg, object V1, object V2)
{ VT16 VLEX16 CLSR16
	{ int V3;
	object V4;                                /*  VAL             */
	object V5;                                /*  CONDITION       */
	V3=(*LK13)(2,(V1),(V2))                   /*  GENERAL-INSTANCE-GET*/;
	if (V3==0) goto L660;
	V4= VALUES(0);
	V3--;
	if (V3==0) goto L661;
	V5= VALUES(1);
	V3--;
	goto L662;
L660:
	V4= Cnil;
L661:
	V5= Cnil;
L662:
	{register object V6;
	V6= (V5);
	if(!(eql((V6),VV[3]))){
	goto L664;}
	VALUES(0) = Ct;
	RETURN(1);
L664:
	if(!(eql((V6),VV[4]))){
	goto L667;}
	VALUES(0) = Cnil;
	RETURN(1);
L667:
	if(!(eql((V6),VV[5]))){
	goto L670;}
	RETURN((*LK14)(4,((V1))->in.in_class,(V1),(V2),VV[12])/*  SLOT-MISSING*/);
L670:
	bds_bind(VV[6],MAKE_FIXNUM(4));           /*  *PRINT-LEVEL*   */
	bds_bind(VV[7],MAKE_FIXNUM(4));           /*  *PRINT-LENGTH*  */
	{int V7;
	V7=Lerror(6,VV[8],VV[9],(V6),VV[3],VV[4],VV[5])/*  ERROR      */;
	bds_unwind1;
	bds_unwind1;
	RETURN(V7);}
	}}
}
/*	local function CLOSURE                                        */
static LC2(int narg, object V1, object V2)
{ VT17 VLEX17 CLSR17
	{ int V3;
	object V4;                                /*  VAL             */
	object V5;                                /*  CONDITION       */
	V3=(*LK13)(2,(V1),(V2))                   /*  GENERAL-INSTANCE-GET*/;
	if (V3==0) goto L673;
	V4= VALUES(0);
	V3--;
	if (V3==0) goto L674;
	V5= VALUES(1);
	V3--;
	goto L675;
L673:
	V4= Cnil;
L674:
	V5= Cnil;
L675:
	{register object V6;
	V6= (V5);
	if(!(eql((V6),VV[3]))){
	goto L677;}
	VALUES(0) = (V4);
	RETURN(1);
L677:
	if(!(eql((V6),VV[4]))){
	goto L680;}
	RETURN((*LK15)(3,((V1))->in.in_class,(V1),(V2))/*  SLOT-UNBOUND*/);
L680:
	if(!(eql((V6),VV[5]))){
	goto L683;}
	RETURN((*LK14)(4,((V1))->in.in_class,(V1),(V2),VV[0])/*  SLOT-MISSING*/);
L683:
	bds_bind(VV[6],MAKE_FIXNUM(4));           /*  *PRINT-LEVEL*   */
	bds_bind(VV[7],MAKE_FIXNUM(4));           /*  *PRINT-LENGTH*  */
	{int V7;
	V7=Lerror(6,VV[8],VV[9],(V6),VV[3],VV[4],VV[5])/*  ERROR      */;
	bds_unwind1;
	bds_unwind1;
	RETURN(V7);}
	}}
}
/*	local function SLOT-VALUE                                     */
static LC1(int narg, object V1, object V2)
{ VT18 VLEX18 CLSR18
	{ int V3;
	object V4;                                /*  VAL             */
	object V5;                                /*  CONDITION       */
	V3=(*LK13)(2,(V1),(V2))                   /*  GENERAL-INSTANCE-GET*/;
	if (V3==0) goto L686;
	V4= VALUES(0);
	V3--;
	if (V3==0) goto L687;
	V5= VALUES(1);
	V3--;
	goto L688;
L686:
	V4= Cnil;
L687:
	V5= Cnil;
L688:
	{register object V6;
	V6= (V5);
	if(!(eql((V6),VV[3]))){
	goto L690;}
	VALUES(0) = (V4);
	RETURN(1);
L690:
	if(!(eql((V6),VV[4]))){
	goto L693;}
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	RETURN((*LK15)(3,VALUES(0),(V1),(V2))     /*  SLOT-UNBOUND    */);
L693:
	if(!(eql((V6),VV[5]))){
	goto L697;}
	siLinstance_class(1,(V1))                 /*  INSTANCE-CLASS  */;
	RETURN((*LK14)(4,VALUES(0),(V1),(V2),VV[0])/*  SLOT-MISSING   */);
L697:
	bds_bind(VV[6],MAKE_FIXNUM(4));           /*  *PRINT-LEVEL*   */
	bds_bind(VV[7],MAKE_FIXNUM(4));           /*  *PRINT-LENGTH*  */
	{int V7;
	V7=Lerror(6,VV[8],VV[9],(V6),VV[3],VV[4],VV[5])/*  ERROR      */;
	bds_unwind1;
	bds_unwind1;
	RETURN(V7);}
	}}
}
/*	function definition for SELECT-CLOS-?                         */
static L14(int narg)
{ VT19 VLEX19 CLSR19
TTL:
	princ_char(10,Cnil);
	RETURN(Lformat(2,Ct,VV[88])               /*  FORMAT          */);
}
static LKF15(int narg, ...) {TRAMPOLINK(VV[171],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[170],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[169],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[168],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[167],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[12],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[166],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[163],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[66],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[47],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[162],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[161],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[160],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[17],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[159],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[0],&LK0);}
