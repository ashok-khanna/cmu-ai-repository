
#include "/home/dipartimento/attardi/lisp/ecl/src/clx/package.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
