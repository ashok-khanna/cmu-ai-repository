
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "cmplet.h"
init_cmplet(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_cmplet; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	MF0(VV[31],L1);
	MF0(VV[32],L2);
	MF0(VV[29],L3);
	MF0(VV[33],L6);
	MF0(VV[34],L7);
	MF0(VV[35],L9);
	MF0(VV[30],L10);
	MF0(VV[36],L11);
	MF0(VV[37],L13);
	MF0(VV[38],L14);
	VALUES(0) = (VV[31]->s.s_gfdef);
	putprop(VV[2],VALUES(0),VV[27]);
	putprop(VV[2],VV[29],VV[28]);
	VALUES(0) = (VV[34]->s.s_gfdef);
	putprop(VV[20],VALUES(0),VV[27]);
	putprop(VV[20],VV[30],VV[28]);
}
/*	function definition for C1LET                                 */
static L1(int narg, object V1)
{ VT3 VLEX3 CLSR3
	bds_check;
TTL:
	{object V2;                               /*  INFO            */
	object V3;                                /*  SETJMPS         */
	register object V4;                       /*  FORMS           */
	register object V5;                       /*  VARS            */
	object V6;                                /*  VNAMES          */
	object V7;                                /*  SS              */
	object V8;                                /*  IS              */
	object V9;                                /*  TS              */
	register object V10;                      /*  BODY            */
	object V11;                               /*  OTHER-DECLS     */
	(*LK0)(0)                                 /*  MAKE-INFO       */;
	V2= VALUES(0);
	V3= (VV[0]->s.s_dbind);
	V4= Cnil;
	V5= Cnil;
	V6= Cnil;
	V7= Cnil;
	V8= Cnil;
	V9= Cnil;
	V10= Cnil;
	V11= Cnil;
	bds_bind(VV[1],(VV[1]->s.s_dbind));       /*  *VARS*          */
	if(!((V1)==Cnil)){
	goto L17;}
	(*LK1)(3,VV[2],MAKE_FIXNUM(1),MAKE_FIXNUM(0))/*  TOO-FEW-ARGS */;
L17:
	{ int V12;
	V12=(*LK2)(2,CDR((V1)),Cnil)              /*  C1BODY          */;
	if (V12>0) {
	V10= VALUES(0);
	V12--;
	} else {
	V10= Cnil;}
	if (V12>0) {
	V7= VALUES(1);
	V12--;
	} else {
	V7= Cnil;}
	if (V12>0) {
	V9= VALUES(2);
	V12--;
	} else {
	V9= Cnil;}
	if (V12>0) {
	V8= VALUES(3);
	V12--;
	} else {
	V8= Cnil;}
	if (V12>0) {
	V11= VALUES(4);
	} else {
	V11= Cnil;}
	
	}
	(*LK3)(1,(V7))                            /*  C1ADD-GLOBALS   */;
	{object V12;
	register object V13;                      /*  X               */
	V12= CAR((V1));
	V13= Cnil;
L27:
	if(!((V12)==Cnil)){
	goto L28;}
	goto L23;
L28:
	V13= CAR((V12));
	if(!(type_of((V13))==t_symbol)){
	goto L35;}
	{object V15;                              /*  V               */
	(*LK4)(4,(V13),(V7),(V8),(V9))            /*  C1MAKE-VAR      */;
	V15= VALUES(0);
	V6= CONS((V13),(V6));
	V5= CONS((V15),(V5));
	(*LK5)(1,((V15))->v.v_self[6])            /*  DEFAULT-INIT    */;
	V4= CONS(VALUES(0),(V4));
	goto L33;
	}
L35:
	if(!(type_of((V13))==t_cons)){
	goto L45;}
	if(CDR((V13))==Cnil){
	goto L44;}
	if(CDDR((V13))==Cnil){
	goto L44;}
L45:
	(*LK6)(2,VV[3],(V13))                     /*  CMPERR          */;
L44:
	{object V16;                              /*  VNAME           */
	object V17;                               /*  V               */
	object V18;                               /*  FORM            */
	V16= CAR((V13));
	(*LK4)(4,(V16),(V7),(V8),(V9))            /*  C1MAKE-VAR      */;
	V17= VALUES(0);
	if(!(CDR((V13))==Cnil)){
	goto L55;}
	(*LK5)(1,((V17))->v.v_self[6])            /*  DEFAULT-INIT    */;
	V18= VALUES(0);
	goto L53;
L55:
	{object V19= ((V17))->v.v_self[6];
	(*LK7)(2,CADR((V13)),(V2))                /*  C1EXPR*         */;
	T0= VALUES(0);
	(*LK8)(3,V19,T0,CADR((V13)))              /*  AND-FORM-TYPE   */;
	V18= VALUES(0);}
L53:
	V6= CONS((V16),(V6));
	V5= CONS((V17),(V5));
	V4= CONS((V18),(V4));
	}
L33:
	V12= CDR((V12));
	goto L27;
	}
L23:
	{object V12;
	object V13;                               /*  V               */
	V12= reverse((V5));
	V13= Cnil;
L70:
	if(!((V12)==Cnil)){
	goto L71;}
	goto L66;
L71:
	V13= CAR((V12));
	(VV[1]->s.s_dbind)= CONS((V13),(VV[1]->s.s_dbind));
	V12= CDR((V12));
	goto L70;
	}
L66:
	(*LK9)(3,(V6),(V9),(V8))                  /*  CHECK-VDECL     */;
	(*LK10)(2,(V11),(V10))                    /*  C1DECL-BODY     */;
	V10= VALUES(0);
	(*LK11)(2,(V2),CADR((V10)))               /*  ADD-INFO        */;
	elt_set((V2),3,(CADR((V10)))->v.v_self[3]);
	{object V12;                              /*  VARS            */
	register object V13;                      /*  FORMS           */
	object V14;                               /*  FORM            */
	register object V15;                      /*  VAR             */
	V12= (V5);
	V13= (V4);
	V14= Cnil;
	V15= Cnil;
L88:
	if(((V12))!=Cnil){
	goto L89;}
	goto L86;
L89:
	V15= CAR((V12));
	V14= CAR((V13));
	{object V17;
	(*LK8)(3,((V15))->v.v_self[6],(V14),((V15))->v.v_self[0])/*  AND-FORM-TYPE*/;
	V17= VALUES(0);
	CAR((V13)) = (V17);
	}
	if((memq((CADR(CAR((V13))))->v.v_self[3],VV[4]))==Cnil){
	goto L99;}
	elt_set((V15),1,number_plus(((V15))->v.v_self[1],MAKE_FIXNUM(1)));
L99:
	(*LK12)(2,(V15),CONS((V10),Cnil))         /*  VAR-CHANGED-IN-FORMS*/;
	if(VALUES(0)!=Cnil){
	goto L102;}
	{object V18;                              /*  TYPE            */
	V18= (CADR(CAR((V13))))->v.v_self[3];
	elt_set((V15),6,(V18));
	L2(3,(V15),(V18),(V10))                   /*  UPDATE-VAR-TYPE */;
	}
L102:
	(*LK13)(1,(V15))                          /*  CHECK-VREF      */;
	V12= CDR((V12));
	V13= CDR((V13));
	goto L88;
	}
L86:
	if(eql((V3),(VV[0]->s.s_dbind))){
	goto L112;}
	elt_set((V2),5,Ct);
L112:
	{object V12= reverse((V5));
	{int V13;
	VALUES(0)=list(5,VV[2],(V2),V12,reverse((V4)),(V10));
	V13=1;
	bds_unwind1;
	RETURN(V13);}}
	}
}
/*	function definition for UPDATE-VAR-TYPE                       */
static L2(int narg, object V1, object V2, object V3)
{ VT4 VLEX4 CLSR4
TTL:
	if(!(type_of((V3))==t_cons||(V3)==Cnil)){
	goto L116;}
	if(!((CAR((V3)))==(VV[5]))){
	goto L119;}
	if(!(((V1))==(CAR(CADDR((V3)))))){
	goto L119;}
	{object V4= CADR((V3));
	(*LK14)(2,(CADR((V3)))->v.v_self[3],(V2)) /*  TYPE-AND        */;
	VALUES(0) = elt_set(V4,3,VALUES(0));
	RETURN(1);}
L119:
	{register object V5;
	object V6;                                /*  E               */
	V5= (V3);
	V6= Cnil;
L127:
	if(!((V5)==Cnil)){
	goto L128;}
	VALUES(0) = Cnil;
	RETURN(1);
L128:
	V6= CAR((V5));
	L2(3,(V1),(V2),(V6))                      /*  UPDATE-VAR-TYPE */;
	V5= CDR((V5));
	goto L127;
	}
L116:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for C2LET                                 */
static L3(int narg, object V1, object V2, object V3)
{ VT5 VLEX5 CLSR5
	bds_check;
TTL:
	{object V4;                               /*  ENV-GROWS       */
	lex0[0]=Cnil;                             /*  BLOCK-P         */
	lex0[1]=Cnil;                             /*  BINDINGS        */
	lex0[2]=Cnil;                             /*  INITIALS        */
	bds_bind(VV[6],(VV[6]->s.s_dbind));       /*  *UNWIND-EXIT*   */
	bds_bind(VV[7],(VV[7]->s.s_dbind));       /*  *ENV*           */
	bds_bind(VV[8],(VV[8]->s.s_dbind));       /*  *ENV-LVL*       */
	V4= Cnil;
	{object V5;                               /*  VL              */
	register object V6;                       /*  FL              */
	register object V7;                       /*  FORM            */
	register object V8;                       /*  VAR             */
	object V9;                                /*  PREV-SS         */
	object V10;                               /*  USED            */
	V5= (V1);
	V6= (V2);
	V7= Cnil;
	V8= Cnil;
	V9= Cnil;
	V10= Ct;
L140:
	if(!((V5)==Cnil)){
	goto L141;}
	goto L138;
L141:
	V7= CAR((V6));
	V8= CAR((V5));
	(*LK15)(1,(V8))                           /*  LOCAL           */;
	if(VALUES(0)==Cnil){
	goto L148;}
	L11(3,(V8),(V7),(V3))                     /*  DISCARDED       */;
	V10= ((VALUES(0))==Cnil?Ct:Cnil);
	if(((V10))==Cnil){
	goto L148;}
	(*LK16)(0)                                /*  NEXT-LCL        */;
	LC4(lex0,2,(V8),VALUES(0))                /*  DO-DECL         */;
L148:
	if(((V10))==Cnil){
	goto L156;}
	(*LK17)(1,(V8))                           /*  UNBOXED         */;
	if(VALUES(0)==Cnil){
	goto L161;}
	lex0[2]= CONS(CONS(list(2,VV[5],(V8)),(V7)),lex0[2]);
	goto L159;
L161:
	{object V12= CAR((V7));
	if((V12!= VV[57]))goto L164;
	L13(2,(V8),(V3))                          /*  CAN-BE-REPLACED */;
	if(VALUES(0)==Cnil){
	goto L166;}
	elt_set((V8),4,VV[9]);
	elt_set((V8),5,CADDR((V7)));
	goto L159;
L166:
	lex0[1]= CONS(CONS((V8),CADDR((V7))),lex0[1]);
	goto L159;
L164:
	if((V12!= VV[5]))goto L170;
	{object V13;                              /*  VREF1           */
	register object V14;                      /*  VAR1            */
	V13= CADDR((V7));
	V14= CAR((V13));
	(*LK12)(2,(V14),CDR((V6)))                /*  VAR-CHANGED-IN-FORMS*/;
	if(VALUES(0)!=Cnil){
	goto L173;}
	if((memq(((V14))->v.v_self[4],VV[10]))==Cnil){
	goto L174;}
	if((memq(((V14))->v.v_self[0],(V9)))==Cnil){
	goto L174;}
L173:
	LC5(lex0,3,(V8),(V7),(V6))                /*  DO-INIT         */;
	goto L159;
L174:
	L13(2,(V8),(V3))                          /*  CAN-BE-REPLACED */;
	if(VALUES(0)==Cnil){
	goto L181;}
	if((memq(((V14))->v.v_self[4],VV[11]))==Cnil){
	goto L181;}
	if((((V14))->v.v_self[2])!=Cnil){
	goto L181;}
	if((memql((V14),(CADR((V3)))->v.v_self[1]))!=Cnil){
	goto L181;}
	elt_set((V8),4,VV[9]);
	elt_set((V8),5,CONS(VV[5],(V13)));
	goto L159;
L181:
	lex0[1]= CONS(listA(3,(V8),VV[5],(V13)),lex0[1]);
	goto L159;
	}
L170:
	LC5(lex0,3,(V8),(V7),(V6))                /*  DO-INIT         */;}
L159:
	if(((V4))!=Cnil){
	goto L156;}
	V4= ((V8))->v.v_self[2];
L156:
	if(!((((V8))->v.v_self[4])==(VV[12]))){
	goto L194;}
	V9= CONS(((V8))->v.v_self[0],(V9));
L194:
	V5= CDR((V5));
	V6= CDR((V6));
	V10= Ct;
	goto L140;
	}
L138:
	L6(1,(V4))                                /*  ENV-GROWS       */;
	if(VALUES(0)==Cnil){
	goto L203;}
	if((lex0[0])!=Cnil){
	goto L206;}
	(*LK18)(1,code_char('\12'))               /*  WT1             */;
	(*LK18)(1,code_char('\11'))               /*  WT1             */;
	princ_str("{ ",symbol_value(VV[13]));
	lex0[0]= Ct;
L206:
	{object V5;                               /*  ENV-LVL         */
	V5= (VV[8]->s.s_dbind);
	princ_str("object env",symbol_value(VV[13]));
	(VV[8]->s.s_dbind)= number_plus((VV[8]->s.s_dbind),MAKE_FIXNUM(1));
	(*LK18)(1,(VV[8]->s.s_dbind))             /*  WT1             */;
	princ_str(" = env",symbol_value(VV[13]));
	(*LK18)(1,(V5))                           /*  WT1             */;
	princ_char(59,symbol_value(VV[13]));
	}
L203:
	{object V5;
	object V6;                                /*  INIT            */
	V5= nreverse(lex0[2]);
	V6= Cnil;
L224:
	if(!((V5)==Cnil)){
	goto L225;}
	goto L220;
L225:
	V6= CAR((V5));
	{object V8;
	V8= CAR((V6));
	bds_bind(VV[16],V8);                      /*  *DESTINATION*   */
	bds_bind(VV[17],(VV[17]->s.s_dbind));     /*  *LCL*           */
	(*LK19)(1,CDR((V6)))                      /*  C2EXPR*         */;
	bds_unwind1;
	bds_unwind1;
	}
	V5= CDR((V5));
	goto L224;
	}
L220:
	{object V5;
	object V6;                                /*  BINDING         */
	V5= nreverse(lex0[1]);
	V6= Cnil;
L239:
	if(!((V5)==Cnil)){
	goto L240;}
	goto L235;
L240:
	V6= CAR((V5));
	(*LK20)(2,CDR((V6)),CAR((V6)))            /*  BIND            */;
	V5= CDR((V5));
	goto L239;
	}
L235:
	(*LK21)(1,(V3))                           /*  C2EXPR          */;
	if((lex0[0])==Cnil){
	goto L251;}
	(*LK18)(1,code_char('\12'))               /*  WT1             */;
	(*LK18)(1,code_char('\11'))               /*  WT1             */;
	princ_char(125,symbol_value(VV[13]));
	{int V5;
	VALUES(0)=Cnil;
	V5=1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V5);}
L251:
	{int V6;
	VALUES(0)=Cnil;
	V6=1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V6);}
	}
}
/*	local function DO-INIT                                        */
static LC5(object *lex0,int narg, object V1, object V2, object V3)
{ VT6 VLEX6 CLSR6
TTL:
	(*LK15)(1,(V1))                           /*  LOCAL           */;
	if(VALUES(0)==Cnil){
	goto L257;}
	(*LK22)(1,CDR((V3)))                      /*  ARGS-CAUSE-SIDE-EFFECT*/;
	if(VALUES(0)!=Cnil){
	goto L257;}
	lex0[2]= CONS(CONS(list(2,VV[5],(V1)),(V2)),lex0[2]);
	VALUES(0) = lex0[2];
	RETURN(1);
L257:
	{object V4;                               /*  LCL             */
	object V5;                                /*  LOC             */
	(*LK16)(0)                                /*  NEXT-LCL        */;
	V4= VALUES(0);
	V5= list(2,VV[15],(V4));
	(*LK23)(0)                                /*  MAKE-VAR        */;
	LC4(lex0,2,VALUES(0),(V4))                /*  DO-DECL         */;
	lex0[2]= CONS(CONS((V5),(V2)),lex0[2]);
	lex0[1]= CONS(CONS((V1),(V5)),lex0[1]);
	VALUES(0) = lex0[1];
	RETURN(1);
	}
}
/*	local function DO-DECL                                        */
static LC4(object *lex0,int narg, object V1, object V2)
{ VT7 VLEX7 CLSR7
TTL:
	elt_set((V1),5,(V2));
	(*LK18)(1,code_char('\12'))               /*  WT1             */;
	(*LK18)(1,code_char('\11'))               /*  WT1             */;
	if((lex0[0])!=Cnil){
	goto L273;}
	princ_char(123,symbol_value(VV[13]));
	lex0[0]= Ct;
L273:
	(*LK18)(1,(VV[14]->s.s_dbind))            /*  WT1             */;
	(*LK24)(1,(V1))                           /*  REGISTER        */;
	(*LK18)(1,VALUES(0))                      /*  WT1             */;
	(*LK25)(1,((V1))->v.v_self[4])            /*  REP-TYPE        */;
	(*LK18)(1,VALUES(0))                      /*  WT1             */;
	(*LK26)(1,(V2))                           /*  WT-LCL          */;
	princ_char(59,symbol_value(VV[13]));
	(*LK15)(1,(V1))                           /*  LOCAL           */;
	if(VALUES(0)==Cnil){
	goto L289;}
	RETURN((*LK27)(1,((V1))->v.v_self[0])     /*  WT-COMMENT      */);
L289:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for ENV-GROWS                             */
static L6(int narg, object V1)
{ VT8 VLEX8 CLSR8
TTL:
	if((V1)==Cnil){
	VALUES(0) = Cnil;
	RETURN(1);}
	if(number_compare(MAKE_FIXNUM(0),(VV[7]->s.s_dbind))<0){
	goto L291;}
	VALUES(0) = Cnil;
	RETURN(1);
L291:
	{register object V2;
	object V3;                                /*  EXIT            */
	V2= (VV[6]->s.s_dbind);
	V3= Cnil;
L296:
	if(!((V2)==Cnil)){
	goto L297;}
	VALUES(0) = Cnil;
	RETURN(1);
L297:
	V3= CAR((V2));
	{object V5;
	if(!(eql((V3),VV[18]))){
	goto L304;}
	VALUES(0) = Cnil;
	RETURN(1);
L304:
	if(!(eql((V3),VV[19]))){
	goto L307;}
	goto L302;
L307:
	VALUES(0) = Ct;
	RETURN(1);
	}
L302:
	V2= CDR((V2));
	goto L296;
	}
}
/*	function definition for C1LET*                                */
static L7(int narg, object V1)
{ VT9 VLEX9 CLSR9
	bds_check;
TTL:
	{object V2;                               /*  FORMS           */
	register object V3;                       /*  VARS            */
	object V4;                                /*  VNAMES          */
	object V5;                                /*  SETJMPS         */
	object V6;                                /*  SS              */
	object V7;                                /*  IS              */
	object V8;                                /*  TS              */
	register object V9;                       /*  BODY            */
	object V10;                               /*  OTHER-DECLS     */
	object V11;                               /*  INFO            */
	V2= Cnil;
	V3= Cnil;
	V4= Cnil;
	V5= (VV[0]->s.s_dbind);
	V6= Cnil;
	V7= Cnil;
	V8= Cnil;
	V9= Cnil;
	V10= Cnil;
	(*LK0)(0)                                 /*  MAKE-INFO       */;
	V11= VALUES(0);
	bds_bind(VV[1],(VV[1]->s.s_dbind));       /*  *VARS*          */
	if(!((V1)==Cnil)){
	goto L322;}
	(*LK1)(3,VV[20],MAKE_FIXNUM(1),MAKE_FIXNUM(0))/*  TOO-FEW-ARGS*/;
L322:
	{ int V12;
	V12=(*LK2)(2,CDR((V1)),Cnil)              /*  C1BODY          */;
	if (V12>0) {
	V9= VALUES(0);
	V12--;
	} else {
	V9= Cnil;}
	if (V12>0) {
	V6= VALUES(1);
	V12--;
	} else {
	V6= Cnil;}
	if (V12>0) {
	V8= VALUES(2);
	V12--;
	} else {
	V8= Cnil;}
	if (V12>0) {
	V7= VALUES(3);
	V12--;
	} else {
	V7= Cnil;}
	if (V12>0) {
	V10= VALUES(4);
	} else {
	V10= Cnil;}
	
	}
	(*LK3)(1,(V6))                            /*  C1ADD-GLOBALS   */;
	{object V12;
	register object V13;                      /*  X               */
	V12= CAR((V1));
	V13= Cnil;
L332:
	if(!((V12)==Cnil)){
	goto L333;}
	goto L328;
L333:
	V13= CAR((V12));
	if(!(type_of((V13))==t_symbol)){
	goto L340;}
	{object V15;                              /*  V               */
	(*LK4)(4,(V13),(V6),(V7),(V8))            /*  C1MAKE-VAR      */;
	V15= VALUES(0);
	V4= CONS((V13),(V4));
	(*LK5)(1,((V15))->v.v_self[6])            /*  DEFAULT-INIT    */;
	V2= CONS(VALUES(0),(V2));
	V3= CONS((V15),(V3));
	(VV[1]->s.s_dbind)= CONS((V15),(VV[1]->s.s_dbind));
	goto L338;
	}
L340:
	if(!(type_of((V13))==t_cons)){
	goto L351;}
	if(CDR((V13))==Cnil){
	goto L352;}
	if(CDDR((V13))==Cnil){
	goto L352;}
L351:
	(*LK6)(2,VV[21],(V13))                    /*  CMPERR          */;
	goto L338;
L352:
	{object V16;                              /*  V               */
	object V17;                               /*  FORM            */
	(*LK4)(4,CAR((V13)),(V6),(V7),(V8))       /*  C1MAKE-VAR      */;
	V16= VALUES(0);
	if(!(CDR((V13))==Cnil)){
	goto L361;}
	(*LK5)(1,((V16))->v.v_self[6])            /*  DEFAULT-INIT    */;
	V17= VALUES(0);
	goto L359;
L361:
	{object V18= ((V16))->v.v_self[6];
	(*LK7)(2,CADR((V13)),(V11))               /*  C1EXPR*         */;
	T0= VALUES(0);
	(*LK8)(3,V18,T0,CADR((V13)))              /*  AND-FORM-TYPE   */;
	V17= VALUES(0);}
L359:
	V4= CONS(CAR((V13)),(V4));
	V2= CONS((V17),(V2));
	V3= CONS((V16),(V3));
	(VV[1]->s.s_dbind)= CONS((V16),(VV[1]->s.s_dbind));
	}
L338:
	V12= CDR((V12));
	goto L332;
	}
L328:
	(*LK9)(3,(V4),(V8),(V7))                  /*  CHECK-VDECL     */;
	(*LK10)(2,(V10),(V9))                     /*  C1DECL-BODY     */;
	V9= VALUES(0);
	(*LK11)(2,(V11),CADR((V9)))               /*  ADD-INFO        */;
	elt_set((V11),3,(CADR((V9)))->v.v_self[3]);
	{VOL object V12;                          /*  USED-VARS       */
	VOL object V13;                           /*  USED-FORMS      */
	V12= Cnil;
	V13= Cnil;
	{VOL object V14;                          /*  VS              */
	VOL object V15;
	VOL object V16;                           /*  FS              */
	VOL object V17;                           /*  FORM            */
	V3= nreverse((V3));
	V15= (V3);
	V16= nreverse((V2));
	V14= V15;
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  VAR             */
	V17= Cnil;
L384:
	if(((V14))!=Cnil){
	goto L385;}
	goto L379;
L385:
	*CLV0= CAR((V14));
	(*LK8)(3,(*CLV0)->v.v_self[6],CAR((V16)),CADAR((V1)))/*  AND-FORM-TYPE*/;
	V17= VALUES(0);
	{object V19;                              /*  REST-FORMS      */
	V19= CONS((V9),CDR((V16)));
	(*LK12)(2,*CLV0,(V19))                    /*  VAR-CHANGED-IN-FORMS*/;
	if(VALUES(0)!=Cnil){
	goto L392;}
	{object V20;                              /*  TYPE            */
	V20= (CADR((V17)))->v.v_self[3];
	elt_set(*CLV0,6,(V20));
	L2(3,*CLV0,(V20),(V19))                   /*  UPDATE-VAR-TYPE */;
	}
	}
L392:
	(*LK13)(1,*CLV0)                          /*  CHECK-VREF      */;
	if(!(number_compare(MAKE_FIXNUM(1),(*CLV0)->v.v_self[1])==0)){
	goto L401;}
	if((memql(*CLV0,(CADR((V9)))->v.v_self[2]))==Cnil){
	goto L401;}
	if((CDR((V16)))!=Cnil){
	goto L407;}
	{object V21;                              /*  TFORMS          */
	V21= CONS(CAR((V16)),Cnil);
	{object V22;
	object V23;                               /*  V               */
	V22= (V3);
	V23= Cnil;
L415:
	if(!((V22)==Cnil)){
	goto L416;}
	goto L410;
L416:
	V23= CAR((V22));
	if(!(((V23))==(*CLV0))){
	goto L421;}
	goto L406;
L421:
	(*LK12)(2,(V23),(V21))                    /*  VAR-CHANGED-IN-FORMS*/;
	if(VALUES(0)==Cnil){
	goto L424;}
	goto L410;
L424:
	V22= CDR((V22));
	goto L415;
	}
	}
L410:
L407:
	(*LK22)(1,(V16))                          /*  ARGS-CAUSE-SIDE-EFFECT*/;
	if(VALUES(0)!=Cnil){
	goto L401;}
L406:
	{ int V21;
	if ((V21=frs_push(FRS_CATCH,*CLV0))==0) {
	V21=L9(2,*CLV0,(V9))                      /*  REPLACEABLE     */;
	}
	else V21--;
	frs_pop();
	if((VALUES(0))==Cnil){
	goto L401;}}
	VALUES(0) = make_cclosure(LC8,env0,&Cblock);
	Lnsubst_if(3,(V17),VALUES(0),(V9))        /*  NSUBST-IF       */;
	V9= VALUES(0);
	goto L399;
L401:
	V12= CONS(*CLV0,(V12));
	V13= CONS((V17),(V13));
	if((memq((CADR((V17)))->v.v_self[3],VV[22]))==Cnil){
	goto L399;}
	{object V21;
	V21= *CLV0;
	elt_set((V21),1,number_plus(((V21))->v.v_self[1],MAKE_FIXNUM(1)));
	}
L399:
	V14= CDR((V14));
	V16= CDR((V16));
	goto L384;
	}
L379:
	if(eql((V5),(VV[0]->s.s_dbind))){
	goto L447;}
	elt_set((V11),5,Ct);
L447:
	{object V14= nreverse((V12));
	{object V15= nreverse((V13));
	{int V16;
	VALUES(0)=list(5,VV[20],(V11),V14,V15,(V9));
	V16=1;
	bds_unwind1;
	RETURN(V16);}}}
	}
	}
}
/*	closure CLOSURE                                               */
static LC8(int narg, object env0, object V1)
{ VT10 VLEX10 CLSR10
	narg--;
	{object scan=env0;
	CLV0= &CAR(scan);                         /*  VAR             */}
	if(type_of((V1))==t_cons||(V1)==Cnil){
	goto L450;}
	VALUES(0) = Cnil;
	RETURN(1);
L450:
	if((CAR((V1)))==(VV[5])){
	goto L452;}
	VALUES(0) = Cnil;
	RETURN(1);
L452:
	VALUES(0) = ((*CLV0)==(CAR(CADDR((V1))))?Ct:Cnil);
	RETURN(1);
}
/*	function definition for REPLACEABLE                           */
static L9(int narg, object V1, object V2)
{ VT11 VLEX11 CLSR11
TTL:
	{object V3= CAR((V2));
	if((V3!= VV[5]))goto L454;
	if(!(((V1))==(CAR(CADDR((V2)))))){
	goto L456;}
	{frame_ptr fr; int V4;
	fr=frs_sch_catch((V1));
	if (fr==NULL) FEerror("The tag ~s is undefined.",1,(V1));
	VALUES(0)=Ct;
	V4=1;
	unwind(fr,(V1),V4+1);}
L456:
	VALUES(0) = Ct;
	RETURN(1);
L454:
	if((V3!= VV[57])
	&& (V3!= VV[68]))goto L459;
	VALUES(0) = Ct;
	RETURN(1);
L459:
	if((V3!= VV[69]))goto L460;
	{register object V5;
	object V6;                                /*  ARG             */
	V5= CADDDR((V2));
	V6= Cnil;
L464:
	if(!((V5)==Cnil)){
	goto L465;}
	VALUES(0) = Ct;
	RETURN(1);
L465:
	V6= CAR((V5));
	L9(2,(V1),(V6))                           /*  REPLACEABLE     */;
	if(VALUES(0)==Cnil){
	goto L471;}
	(*LK22)(1,CONS((V6),Cnil))                /*  ARGS-CAUSE-SIDE-EFFECT*/;
	if(VALUES(0)==Cnil){
	goto L470;}
L471:
	VALUES(0) = Cnil;
	RETURN(1);
L470:
	V5= CDR((V5));
	goto L464;
	}
L460:
	if((V3!= VV[70]))goto L478;
	V2= CADDDR((V2));
	goto TTL;
L478:
	VALUES(0) = Cnil;
	RETURN(1);}
}
/*	function definition for C2LET*                                */
static L10(int narg, object V1, object V2, object V3)
{ VT12 VLEX12 CLSR12
	bds_check;
TTL:
	{register object V4;                      /*  BLOCK-P         */
	object V5;                                /*  ENV-GROWS       */
	V4= Cnil;
	bds_bind(VV[6],(VV[6]->s.s_dbind));       /*  *UNWIND-EXIT*   */
	bds_bind(VV[7],(VV[7]->s.s_dbind));       /*  *ENV*           */
	bds_bind(VV[8],(VV[8]->s.s_dbind));       /*  *ENV-LVL*       */
	V5= Cnil;
	{object V6;                               /*  VL              */
	register object V7;                       /*  FL              */
	register object V8;                       /*  VAR             */
	object V9;                                /*  FORM            */
	object V10;                               /*  KIND            */
	V6= (V1);
	V7= (V2);
	V8= Cnil;
	V9= Cnil;
	V10= Cnil;
L486:
	if(!((V6)==Cnil)){
	goto L487;}
	goto L484;
L487:
	V9= CAR((V7));
	V8= CAR((V6));
	(*LK15)(1,(V8))                           /*  LOCAL           */;
	V10= VALUES(0);
	(*LK17)(1,(V8))                           /*  UNBOXED         */;
	if(VALUES(0)!=Cnil){
	goto L496;}
	{object V12= CAR((V9));
	if((V12!= VV[57]))goto L500;
	L14(3,(V8),(V3),CDR((V7)))                /*  CAN-BE-REPLACED**/;
	if(VALUES(0)==Cnil){
	goto L499;}
	elt_set((V8),4,VV[9]);
	elt_set((V8),5,CADDR((V9)));
	goto L499;
L500:
	if((V12!= VV[5]))goto L504;
	{object V13;                              /*  VREF1           */
	object V14;                               /*  VAR1            */
	V13= CADDR((V9));
	V14= CAR((V13));
	L14(3,(V8),(V3),CDR((V7)))                /*  CAN-BE-REPLACED**/;
	if(VALUES(0)==Cnil){
	goto L499;}
	if((memq(((V14))->v.v_self[4],VV[23]))==Cnil){
	goto L499;}
	if((((V14))->v.v_self[2])!=Cnil){
	goto L499;}
	(*LK12)(2,(V14),CDR((V7)))                /*  VAR-CHANGED-IN-FORMS*/;
	if(VALUES(0)!=Cnil){
	goto L499;}
	if((memql((V14),(CADR((V3)))->v.v_self[1]))!=Cnil){
	goto L499;}
	elt_set((V8),4,VV[9]);
	elt_set((V8),5,CONS(VV[5],(V13)));
	goto L499;
	}
L504:}
L499:
	if(((V5))!=Cnil){
	goto L496;}
	V5= ((V8))->v.v_self[2];
L496:
	if(((V10))==Cnil){
	goto L521;}
	if((((V8))->v.v_self[4])==(VV[9])){
	goto L521;}
	(*LK16)(0)                                /*  NEXT-LCL        */;
	elt_set((V8),5,VALUES(0));
	(*LK18)(1,code_char('\12'))               /*  WT1             */;
	(*LK18)(1,code_char('\11'))               /*  WT1             */;
	if(((V4))!=Cnil){
	goto L531;}
	princ_char(123,symbol_value(VV[13]));
	V4= Ct;
L531:
	(*LK18)(1,(VV[14]->s.s_dbind))            /*  WT1             */;
	(*LK24)(1,(V8))                           /*  REGISTER        */;
	(*LK18)(1,VALUES(0))                      /*  WT1             */;
	(*LK25)(1,(V10))                          /*  REP-TYPE        */;
	(*LK18)(1,VALUES(0))                      /*  WT1             */;
	(*LK26)(1,((V8))->v.v_self[5])            /*  WT-LCL          */;
	princ_char(59,symbol_value(VV[13]));
	(*LK27)(1,((V8))->v.v_self[0])            /*  WT-COMMENT      */;
L521:
	V6= CDR((V6));
	V7= CDR((V7));
	goto L486;
	}
L484:
	L6(1,(V5))                                /*  ENV-GROWS       */;
	if(VALUES(0)==Cnil){
	goto L550;}
	if(((V4))!=Cnil){
	goto L553;}
	(*LK18)(1,code_char('\12'))               /*  WT1             */;
	(*LK18)(1,code_char('\11'))               /*  WT1             */;
	princ_str("{ ",symbol_value(VV[13]));
	V4= Ct;
L553:
	{object V6;                               /*  ENV-LVL         */
	V6= (VV[8]->s.s_dbind);
	princ_str("object env",symbol_value(VV[13]));
	(VV[8]->s.s_dbind)= number_plus((VV[8]->s.s_dbind),MAKE_FIXNUM(1));
	(*LK18)(1,(VV[8]->s.s_dbind))             /*  WT1             */;
	princ_str(" = env",symbol_value(VV[13]));
	(*LK18)(1,(V6))                           /*  WT1             */;
	princ_char(59,symbol_value(VV[13]));
	}
L550:
	{object V6;                               /*  VL              */
	object V7;                                /*  FL              */
	register object V8;                       /*  VAR             */
	register object V9;                       /*  FORM            */
	V6= (V1);
	V7= (V2);
	V8= Cnil;
	V9= Cnil;
L569:
	if(((V6))!=Cnil){
	goto L570;}
	goto L567;
L570:
	V8= CAR((V6));
	V9= CAR((V7));
	{object V11= ((V8))->v.v_self[4];
	if((V11!= VV[71])
	&& (V11!= VV[72])
	&& (V11!= VV[73])
	&& (V11!= VV[74])
	&& (V11!= VV[25]))goto L578;
	{object V12;
	V12= list(2,VV[5],(V8));
	bds_bind(VV[16],V12);                     /*  *DESTINATION*   */
	(*LK19)(1,(V9))                           /*  C2EXPR*         */;
	bds_unwind1;
	goto L577;
	}
L578:
	if((V11!= VV[9]))goto L580;
	goto L577;
L580:
	{object V13= CAR((V9));
	if((V13!= VV[57]))goto L581;
	(*LK20)(2,CADDR((V9)),(V8))               /*  BIND            */;
	goto L577;
L581:
	if((V13!= VV[5]))goto L582;
	(*LK20)(2,CONS(VV[5],CADDR((V9))),(V8))   /*  BIND            */;
	goto L577;
L582:
	(*LK28)(2,(V8),(V9))                      /*  BIND-INIT       */;}}
L577:
	V6= CDR((V6));
	V7= CDR((V7));
	goto L569;
	}
L567:
	(*LK21)(1,(V3))                           /*  C2EXPR          */;
	if(((V4))==Cnil){
	goto L589;}
	(*LK18)(1,code_char('\12'))               /*  WT1             */;
	(*LK18)(1,code_char('\11'))               /*  WT1             */;
	princ_char(125,symbol_value(VV[13]));
	{int V6;
	VALUES(0)=Cnil;
	V6=1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V6);}
L589:
	{int V7;
	VALUES(0)=Cnil;
	V7=1;
	bds_unwind1;
	bds_unwind1;
	bds_unwind1;
	RETURN(V7);}
	}
}
/*	function definition for DISCARDED                             */
static L11(int narg, object V1, object V2, object V3)
{ VT13 VLEX13 CLSR13
TTL:
	(*LK22)(1,CONS((V2),Cnil))                /*  ARGS-CAUSE-SIDE-EFFECT*/;
	if((VALUES(0))==Cnil){
	goto L594;}
	VALUES(0) = Cnil;
	RETURN(1);
L594:
	if(!(number_compare(((V1))->v.v_self[1],MAKE_FIXNUM(1))<0)){
	goto L597;}
	VALUES(0) = Ct;
	RETURN(1);
L597:
	if(number_compare(((V1))->v.v_self[1],MAKE_FIXNUM(1))==0){
	goto L599;}
	VALUES(0) = Cnil;
	RETURN(1);
L599:
	LC12(1,(V3))                              /*  LAST-FORM       */;
	if(((V1))==(VALUES(0))){
	goto L601;}
	VALUES(0) = Cnil;
	RETURN(1);
L601:
	VALUES(0) = ((VV[24])==((VV[16]->s.s_dbind))?Ct:Cnil);
	RETURN(1);
}
/*	local function LAST-FORM                                      */
static LC12(int narg, object V1)
{ VT14 VLEX14 CLSR14
TTL:
	{object V2= CAR((V1));
	if((V2!= VV[76]))goto L604;
	Llast(1,CADDR((V1)))                      /*  LAST            */;
	V1= CAR(VALUES(0));
	goto TTL;
L604:
	if((V2== VV[2])
	|| (V2== VV[20])
	|| (V2== VV[77])
	|| (V2== VV[78])
	|| (V2== VV[79]))goto L609;
	if((V2!= VV[80]))goto L608;
L609:
	Llast(1,(V1))                             /*  LAST            */;
	V1= CAR(VALUES(0));
	goto TTL;
L608:
	if((V2!= VV[5]))goto L613;
	VALUES(0) = CAR(CADDR((V1)));
	RETURN(1);
L613:
	VALUES(0) = (V1);
	RETURN(1);}
}
/*	function definition for CAN-BE-REPLACED                       */
static L13(int narg, object V1, object V2)
{ VT15 VLEX15 CLSR15
TTL:
	if((((V1))->v.v_self[4])==(VV[25])){
	goto L614;}
	VALUES(0) = Cnil;
	RETURN(1);
L614:
	if(number_compare(((V1))->v.v_self[1],(VV[26]->s.s_dbind))<0){
	goto L616;}
	VALUES(0) = Cnil;
	RETURN(1);
L616:
	VALUES(0) = memql((V1),(CADR((V2)))->v.v_self[1]);
	VALUES(0) = ((VALUES(0))==Cnil?Ct:Cnil);
	RETURN(1);
}
/*	function definition for CAN-BE-REPLACED*                      */
static L14(int narg, object V1, object V2, object V3)
{ VT16 VLEX16 CLSR16
TTL:
	L13(2,(V1),(V2))                          /*  CAN-BE-REPLACED */;
	if(VALUES(0)!=Cnil){
	goto L619;}
	VALUES(0) = Cnil;
	RETURN(1);
L619:
	{register object V4;
	object V5;                                /*  FORM            */
	V4= (V3);
	V5= Cnil;
L624:
	if(!((V4)==Cnil)){
	goto L625;}
	VALUES(0) = Ct;
	RETURN(1);
L625:
	V5= CAR((V4));
	if((memql((V1),(CADR((V5)))->v.v_self[1]))==Cnil){
	goto L630;}
	VALUES(0) = Cnil;
	RETURN(1);
L630:
	V4= CDR((V4));
	goto L624;
	}
}
static LKF28(int narg, ...) {TRAMPOLINK(VV[75],&LK28);}
static LKF27(int narg, ...) {TRAMPOLINK(VV[67],&LK27);}
static LKF26(int narg, ...) {TRAMPOLINK(VV[66],&LK26);}
static LKF25(int narg, ...) {TRAMPOLINK(VV[65],&LK25);}
static LKF24(int narg, ...) {TRAMPOLINK(VV[64],&LK24);}
static LKF23(int narg, ...) {TRAMPOLINK(VV[63],&LK23);}
static LKF22(int narg, ...) {TRAMPOLINK(VV[62],&LK22);}
static LKF21(int narg, ...) {TRAMPOLINK(VV[61],&LK21);}
static LKF20(int narg, ...) {TRAMPOLINK(VV[60],&LK20);}
static LKF19(int narg, ...) {TRAMPOLINK(VV[59],&LK19);}
static LKF18(int narg, ...) {TRAMPOLINK(VV[58],&LK18);}
static LKF17(int narg, ...) {TRAMPOLINK(VV[56],&LK17);}
static LKF16(int narg, ...) {TRAMPOLINK(VV[55],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[54],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[53],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[52],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[51],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[50],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[49],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[48],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[47],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[46],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[45],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[44],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[43],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[42],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[41],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[40],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[39],&LK0);}
