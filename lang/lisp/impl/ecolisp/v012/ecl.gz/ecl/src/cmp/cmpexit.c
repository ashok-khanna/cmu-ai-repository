
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "cmpexit.h"
init_cmpexit(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_cmpexit; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	VV[0]->s.s_stype=(short)stp_special;
	if(VV[0]->s.s_dbind == OBJNULL){
	(VV[0]->s.s_dbind)= MAKE_FIXNUM(0);}
	VV[1]->s.s_stype=(short)stp_special;
	VV[2]->s.s_stype=(short)stp_special;
	MF0(VV[28],L1);
	MF0(VV[29],L2);
	MF0(VV[30],L4);
	MF0(VV[31],L5);
}
/*	function definition for UNWIND-BDS                            */
static L1(int narg, object V1, object V2)
{ VT3 VLEX3 CLSR3
TTL:
	if(((V1))==Cnil){
	goto L2;}
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("bds_unwind(",symbol_value(VV[3]));
	(*LK1)(1,(V1))                            /*  WT-LCL          */;
	princ_str(");",symbol_value(VV[3]));
L2:
	{register int V3;                         /*  N               */
	V3= 0;
L13:
	if(!((V3)>=(fix((V2))))){
	goto L14;}
	VALUES(0) = Cnil;
	RETURN(1);
L14:
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("bds_unwind1;",symbol_value(VV[3]));
	V3= (V3)+1;
	goto L13;
	}
}
/*	function definition for UNWIND-EXIT                           */
static L2(int narg, object V1, ...)
{ VT4 VLEX4 CLSR4
	bds_check;
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if (i==narg) goto L24;
	V2= va_arg(args, object);
	i++;
	goto L25;
L24:
	V2= Cnil;
L25:
	{register object V3;                      /*  BDS-LCL         */
	register int V4;                          /*  BDS-BIND        */
	V3= Cnil;
	V4= 0;
	if(!(type_of((VV[4]->s.s_dbind))==t_cons)){
	goto L29;}
	{object V5= CAR((VV[4]->s.s_dbind));
	if((V5!= VV[5]))goto L32;
	(*LK2)(2,(V1),CADR((VV[4]->s.s_dbind)))   /*  SET-JUMP-TRUE   */;
	if(!(((V1))==(Ct))){
	goto L29;}
	VALUES(0) = Cnil;
	RETURN(1);
L32:
	if((V5!= VV[6]))goto L36;
	(*LK3)(2,(V1),CADR((VV[4]->s.s_dbind)))   /*  SET-JUMP-FALSE  */;
	if(!(((V1))==(Cnil))){
	goto L29;}
	VALUES(0) = Cnil;
	RETURN(1);
L36:}
L29:
	{register object V5;
	register object V6;                       /*  UE              */
	V5= (VV[2]->s.s_dbind);
	V6= Cnil;
L43:
	if(!((V5)==Cnil)){
	goto L44;}
	RETURN((*LK4)(0)                          /*  BABOON          */);
L44:
	V6= CAR((V5));
	if(!(type_of((V6))==t_cons)){
	goto L51;}
	if(!(((V6))==((VV[1]->s.s_dbind)))){
	goto L54;}
	if(!(type_of((VV[4]->s.s_dbind))==t_cons)){
	goto L58;}
	if((CAR((VV[4]->s.s_dbind)))==(VV[5])){
	goto L57;}
	if(!((CAR((VV[4]->s.s_dbind)))==(VV[6]))){
	goto L58;}
L57:
	L1(2,(V3),MAKE_FIXNUM(V4))                /*  UNWIND-BDS      */;
	goto L56;
L58:
	if(((V3))!=Cnil){
	goto L64;}
	if(!((V4)>0)){
	goto L65;}
L64:
	if(!(type_of((V1))==t_cons)){
	goto L70;}
	if(!((CAR((V1)))==(VV[7]))){
	goto L74;}
	if((memq((CADR((V1)))->v.v_self[4],VV[8]))!=Cnil){
	goto L73;}
L74:
	LC3(1,(V1))                               /*  SINGLE-VALUED-CALL*/;
	if(VALUES(0)==Cnil){
	goto L70;}
L73:
	if(!(type_of((VV[4]->s.s_dbind))==t_cons)){
	goto L70;}
	if((memq(CAR((VV[4]->s.s_dbind)),VV[9]))==Cnil){
	goto L70;}
	{object V8;                               /*  TEMP            */
	bds_bind(VV[10],(VV[10]->s.s_dbind));     /*  *TEMP*          */
	(*LK5)(0)                                 /*  NEXT-TEMP       */;
	V8= list(2,VV[11],VALUES(0));
	bds_bind(VV[4],(V8));                     /*  *DESTINATION*   */
	(*LK6)(1,(V1))                            /*  SET-LOC         */;
	bds_unwind1;
	L1(2,(V3),MAKE_FIXNUM(V4))                /*  UNWIND-BDS      */;
	(*LK6)(1,(V8))                            /*  SET-LOC         */;
	bds_unwind1;
	goto L56;
	}
L70:
	(*LK6)(1,(V1))                            /*  SET-LOC         */;
	L1(2,(V3),MAKE_FIXNUM(V4))                /*  UNWIND-BDS      */;
	goto L56;
L65:
	(*LK6)(1,(V1))                            /*  SET-LOC         */;
L56:
	if(((V2))==Cnil){
	goto L87;}
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	CDR((VV[1]->s.s_dbind)) = Ct;
	princ_str("goto L",symbol_value(VV[3]));
	(*LK0)(1,CAR((VV[1]->s.s_dbind)))         /*  WT1             */;
	princ_char(59,symbol_value(VV[3]));
L87:
	VALUES(0) = Cnil;
	RETURN(1);
L54:
	V2= Ct;
	goto L49;
L51:
	if(!(numberp((V6)))){
	goto L99;}
	V3= (V6);
	V4= 0;
	goto L49;
L99:
	if(((V6)!= VV[23]))goto L104;
	V4= (V4)+(1);
	goto L49;
L104:
	if(((V6)!= VV[12]))goto L106;
	if(((VV[1]->s.s_dbind))==(VV[12])){
	goto L107;}
	(*LK4)(0)                                 /*  BABOON          */;
L107:
	if(!(type_of((V1))==t_cons)){
	goto L112;}
	if(!((CAR((V1)))==(VV[13]))){
	goto L112;}
	if(((V3))!=Cnil){
	goto L117;}
	if(!((V4)>0)){
	goto L116;}
L117:
	L1(2,(V3),MAKE_FIXNUM(V4))                /*  UNWIND-BDS      */;
L116:
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("RETURN(",symbol_value(VV[3]));
	(*LK0)(1,CADR((V1)))                      /*  WT1             */;
	princ_str(");",symbol_value(VV[3]));
	goto L110;
L112:
	if(((V3))!=Cnil){
	goto L126;}
	if(!((V4)>0)){
	goto L127;}
L126:
	{object V9;                               /*  NR              */
	(*LK7)(0)                                 /*  NEXT-LCL        */;
	V9= list(2,VV[14],VALUES(0));
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{int ",symbol_value(VV[3]));
	(*LK0)(1,(V9))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[3]));
	(*LK8)(2,(V1),(V9))                       /*  SET-VALUES      */;
	L1(2,(V3),MAKE_FIXNUM(V4))                /*  UNWIND-BDS      */;
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("RETURN(",symbol_value(VV[3]));
	(*LK0)(1,(V9))                            /*  WT1             */;
	princ_str(");}",symbol_value(VV[3]));
	goto L110;
	}
L127:
	if(!(type_of((V1))==t_cons)){
	goto L147;}
	if((memq(CAR((V1)),VV[15]))==Cnil){
	goto L147;}
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("RETURN(",symbol_value(VV[3]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	princ_str(");",symbol_value(VV[3]));
	goto L110;
L147:
	(*LK6)(1,(V1))                            /*  SET-LOC         */;
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("RETURN(1);",symbol_value(VV[3]));
L110:
	VALUES(0) = Cnil;
	RETURN(1);
L106:
	if(((V6)!= VV[41]))goto L160;
	if(!(((VV[1]->s.s_dbind))==((V6)))){
	goto L49;}
	if(((V3))!=Cnil){
	goto L164;}
	if(!((V4)>0)){
	goto L165;}
L164:
	{object V10;                              /*  LCL             */
	(*LK7)(0)                                 /*  NEXT-LCL        */;
	V10= VALUES(0);
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{int ",symbol_value(VV[3]));
	(*LK1)(1,(V10))                           /*  WT-LCL          */;
	princ_str("= ",symbol_value(VV[3]));
	(*LK9)(1,(V1))                            /*  WT-FIXNUM-LOC   */;
	princ_char(59,symbol_value(VV[3]));
	L1(2,(V3),MAKE_FIXNUM(V4))                /*  UNWIND-BDS      */;
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("return(",symbol_value(VV[3]));
	(*LK1)(1,(V10))                           /*  WT-LCL          */;
	princ_str(");}",symbol_value(VV[3]));
	goto L163;
	}
L165:
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("return(",symbol_value(VV[3]));
	(*LK9)(1,(V1))                            /*  WT-FIXNUM-LOC   */;
	princ_str(");",symbol_value(VV[3]));
L163:
	VALUES(0) = Cnil;
	RETURN(1);
L160:
	if(((V6)!= VV[43]))goto L193;
	if(!(((VV[1]->s.s_dbind))==((V6)))){
	goto L49;}
	if(((V3))!=Cnil){
	goto L197;}
	if(!((V4)>0)){
	goto L198;}
L197:
	{object V11;                              /*  LCL             */
	(*LK7)(0)                                 /*  NEXT-LCL        */;
	V11= VALUES(0);
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{unsigned char ",symbol_value(VV[3]));
	(*LK1)(1,(V11))                           /*  WT-LCL          */;
	princ_str("= ",symbol_value(VV[3]));
	(*LK10)(1,(V1))                           /*  WT-CHARACTER-LOC*/;
	princ_char(59,symbol_value(VV[3]));
	L1(2,(V3),MAKE_FIXNUM(V4))                /*  UNWIND-BDS      */;
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("return(",symbol_value(VV[3]));
	(*LK1)(1,(V11))                           /*  WT-LCL          */;
	princ_str(");}",symbol_value(VV[3]));
	goto L196;
	}
L198:
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("return(",symbol_value(VV[3]));
	(*LK10)(1,(V1))                           /*  WT-CHARACTER-LOC*/;
	princ_str(");",symbol_value(VV[3]));
L196:
	VALUES(0) = Cnil;
	RETURN(1);
L193:
	if(((V6)!= VV[45]))goto L226;
	if(!(((VV[1]->s.s_dbind))==((V6)))){
	goto L49;}
	if(((V3))!=Cnil){
	goto L230;}
	if(!((V4)>0)){
	goto L231;}
L230:
	{object V12;                              /*  LCL             */
	(*LK7)(0)                                 /*  NEXT-LCL        */;
	V12= VALUES(0);
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{int ",symbol_value(VV[3]));
	(*LK1)(1,(V12))                           /*  WT-LCL          */;
	princ_str("= ",symbol_value(VV[3]));
	(*LK11)(1,(V1))                           /*  WT-LONG-FLOAT-LOC*/;
	princ_char(59,symbol_value(VV[3]));
	L1(2,(V3),MAKE_FIXNUM(V4))                /*  UNWIND-BDS      */;
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("return(",symbol_value(VV[3]));
	(*LK1)(1,(V12))                           /*  WT-LCL          */;
	princ_str(");}",symbol_value(VV[3]));
	goto L229;
	}
L231:
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("return(",symbol_value(VV[3]));
	(*LK11)(1,(V1))                           /*  WT-LONG-FLOAT-LOC*/;
	princ_str(");",symbol_value(VV[3]));
L229:
	VALUES(0) = Cnil;
	RETURN(1);
L226:
	if(((V6)!= VV[47]))goto L259;
	if(!(((VV[1]->s.s_dbind))==((V6)))){
	goto L49;}
	if(((V3))!=Cnil){
	goto L263;}
	if(!((V4)>0)){
	goto L264;}
L263:
	{object V13;                              /*  LCL             */
	(*LK7)(0)                                 /*  NEXT-LCL        */;
	V13= VALUES(0);
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{int ",symbol_value(VV[3]));
	(*LK1)(1,(V13))                           /*  WT-LCL          */;
	princ_str("= ",symbol_value(VV[3]));
	(*LK12)(1,(V1))                           /*  WT-SHORT-FLOAT-LOC*/;
	princ_char(59,symbol_value(VV[3]));
	L1(2,(V3),MAKE_FIXNUM(V4))                /*  UNWIND-BDS      */;
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("return(",symbol_value(VV[3]));
	(*LK1)(1,(V13))                           /*  WT-LCL          */;
	princ_str(");}",symbol_value(VV[3]));
	goto L262;
	}
L264:
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("return(",symbol_value(VV[3]));
	(*LK12)(1,(V1))                           /*  WT-SHORT-FLOAT-LOC*/;
	princ_str(");",symbol_value(VV[3]));
L262:
	VALUES(0) = Cnil;
	RETURN(1);
L259:
	if(((V6)!= VV[49]))goto L292;
	if(!(((VV[1]->s.s_dbind))==((V6)))){
	goto L49;}
	if(((V3))!=Cnil){
	goto L296;}
	if(!((V4)>0)){
	goto L297;}
L296:
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{object x =",symbol_value(VV[3]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	if(!((CAR((V1)))==(VV[16]))){
	goto L309;}
	VALUES(0) = VV[17];
	goto L307;
L309:
	VALUES(0) = VV[18];
L307:
	(*LK0)(1,VALUES(0))                       /*  WT1             */;
	princ_char(59,symbol_value(VV[3]));
	L1(2,(V3),MAKE_FIXNUM(V4))                /*  UNWIND-BDS      */;
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("return(x);}",symbol_value(VV[3]));
	goto L295;
L297:
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("return(",symbol_value(VV[3]));
	(*LK0)(1,(V1))                            /*  WT1             */;
	if(!((CAR((V1)))==(VV[16]))){
	goto L323;}
	VALUES(0) = VV[19];
	goto L321;
L323:
	VALUES(0) = VV[20];
L321:
	(*LK0)(1,VALUES(0))                       /*  WT1             */;
	princ_str(");",symbol_value(VV[3]));
L295:
	VALUES(0) = Cnil;
	RETURN(1);
L292:
	if(((V6)!= VV[25]))goto L326;
	if(!(type_of((V1))==t_cons)){
	goto L327;}
	LC3(1,(V1))                               /*  SINGLE-VALUED-CALL*/;
	if(VALUES(0)==Cnil){
	goto L327;}
	if(!(type_of((VV[4]->s.s_dbind))==t_cons)){
	goto L333;}
	if(!((CAR((VV[4]->s.s_dbind)))==(VV[21]))){
	goto L333;}
	(*LK6)(1,(V1))                            /*  SET-LOC         */;
	V1= (VV[4]->s.s_dbind);
	goto L327;
L333:
	{object V15;
	(*LK5)(0)                                 /*  NEXT-TEMP       */;
	V15= list(2,VV[11],VALUES(0));
	bds_bind(VV[4],V15);                      /*  *DESTINATION*   */
	(*LK6)(1,(V1))                            /*  SET-LOC         */;
	V1= (VV[4]->s.s_dbind);
	bds_unwind1;
	}
L327:
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("frs_pop();",symbol_value(VV[3]));
	goto L49;
L326:
	if(((V6)!= VV[26]))goto L346;
	goto L49;
L346:
	if(((V6)!= VV[27]))goto L347;
	V2= Ct;
	goto L49;
L347:
	(*LK4)(0)                                 /*  BABOON          */;
L49:
	V5= CDR((V5));
	goto L43;
	}
	}
	}
}
/*	local function SINGLE-VALUED-CALL                             */
static LC3(int narg, object V1)
{ VT5 VLEX5 CLSR5
TTL:
	VALUES(0) = memq(CAR((V1)),VV[22]);
	RETURN(1);
}
/*	function definition for UNWIND-NO-EXIT                        */
static L4(int narg, object V1)
{ VT6 VLEX6 CLSR6
TTL:
	{register object V2;                      /*  BDS-LCL         */
	register int V3;                          /*  BDS-BIND        */
	V2= Cnil;
	V3= 0;
	{register object V4;
	register object V5;                       /*  UE              */
	V4= (VV[2]->s.s_dbind);
	V5= Cnil;
L357:
	if(!((V4)==Cnil)){
	goto L358;}
	RETURN((*LK4)(0)                          /*  BABOON          */);
L358:
	V5= CAR((V4));
	if(!(type_of((V5))==t_cons)){
	goto L365;}
	if(!(((V5))==((V1)))){
	goto L363;}
	L1(2,(V2),MAKE_FIXNUM(V3))                /*  UNWIND-BDS      */;
	VALUES(0) = Cnil;
	RETURN(1);
L365:
	if(!(numberp((V5)))){
	goto L371;}
	V2= (V5);
	V3= 0;
	goto L363;
L371:
	if(!(((V5))==(VV[23]))){
	goto L377;}
	V3= (V3)+(1);
	goto L363;
L377:
	if((memql((V5),VV[24]))==Cnil){
	goto L381;}
	if(!(((V1))==((V5)))){
	goto L384;}
	L1(2,(V2),MAKE_FIXNUM(V3))                /*  UNWIND-BDS      */;
	VALUES(0) = Cnil;
	RETURN(1);
L384:
	(*LK4)(0)                                 /*  BABOON          */;
	goto L363;
L381:
	if(!(((V5))==(VV[25]))){
	goto L388;}
	(*LK0)(1,code_char('\12'))                /*  WT1             */;
	(*LK0)(1,code_char('\11'))                /*  WT1             */;
	princ_str("frs_pop();",symbol_value(VV[3]));
	goto L363;
L388:
	if(!(((V5))==(VV[26]))){
	goto L394;}
	if(!(((V1))==(VV[26]))){
	goto L397;}
	L1(2,(V2),MAKE_FIXNUM(V3))                /*  UNWIND-BDS      */;
	VALUES(0) = Cnil;
	RETURN(1);
L397:
	(*LK4)(0)                                 /*  BABOON          */;
	goto L363;
L394:
	{object V10;
	V10= (((V5))==(VV[27])?Ct:Cnil);
	if(((V10))==Cnil){
	goto L402;}
	goto L363;
L402:
	(*LK4)(0)                                 /*  BABOON          */;
	}
L363:
	V4= CDR((V4));
	goto L357;
	}
	}
}
/*	function definition for TAIL-RECURSION-POSSIBLE               */
static L5(int narg)
{ VT7 VLEX7 CLSR7
TTL:
	{register object V1;
	register object V2;                       /*  UE              */
	V1= (VV[2]->s.s_dbind);
	V2= Cnil;
L410:
	if(!((V1)==Cnil)){
	goto L411;}
	RETURN((*LK4)(0)                          /*  BABOON          */);
L411:
	V2= CAR((V1));
	if(!(((V2))==(VV[26]))){
	goto L418;}
	VALUES(0) = Ct;
	RETURN(1);
L418:
	if(numberp((V2))){
	goto L420;}
	if(((V2))==(VV[23])){
	goto L420;}
	if(!(((V2))==(VV[25]))){
	goto L421;}
L420:
	VALUES(0) = Cnil;
	RETURN(1);
L421:
	{object V6;
	if(!(type_of((V2))==t_cons)){
	goto L428;}
	V6= Ct;
	goto L427;
L428:
	V6= (((V2))==(VV[27])?Ct:Cnil);
L427:
	if(((V6))==Cnil){
	goto L431;}
	goto L416;
L431:
	(*LK4)(0)                                 /*  BABOON          */;
	}
L416:
	V1= CDR((V1));
	goto L410;
	}
}
static LKF12(int narg, ...) {TRAMPOLINK(VV[48],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[46],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[44],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[42],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[40],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[39],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[38],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[37],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[36],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[35],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[34],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[33],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[32],&LK0);}
