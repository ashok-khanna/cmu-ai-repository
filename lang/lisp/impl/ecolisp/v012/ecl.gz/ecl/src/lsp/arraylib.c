
/* (c) Copyright G. Attardi, 1993. All rights reserved. */
#include <ecl.h>
#include "arraylib.h"
init_arraylib(int size, object data_stream)
{VT2
	Cblock.cd_start=(char *)init_arraylib; Cblock.cd_size=size;
	Cblock.cd_data=read_VV(VV,VM1,data_stream);
	funcall(2,symbol_function(VV[12]),VV[0])  /*  PROCLAIM        */;
	MF0key(VV[13],L1,8,L1keys);
	MF0(VV[14],L2);
	MF0(VV[15],L3);
	MF0(VV[16],L4);
	MF0(VV[17],L5);
	MF0(VV[18],L6);
	MF0(VV[19],L7);
	MF0(VV[20],L8);
	MF0(VV[21],L8);
	MF0(VV[22],L10);
	MF0(VV[23],L11);
	MF0(VV[24],L12);
	MF0(VV[25],L13);
	MF0(VV[26],L14);
	MF0(VV[27],L15);
	MF0(VV[28],L16);
	MF0(VV[29],L17);
	MF0(VV[30],L18);
	MF0(VV[31],L19);
	MF0(VV[32],L20);
	MF0(VV[33],L21);
	MF0(VV[34],L22);
	MF0(VV[35],L23);
	MF0key(VV[36],L24,7,L24keys);
}
/*	function definition for MAKE-ARRAY                            */
static L1(int narg, object V1, ...)
{ VT3 VLEX3 CLSR3
	cs_check;
	{int i=1;
	register object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	object V10;
	object V11;
	va_list args; va_start(args, V1);
	if(narg<1) FEtoo_few_arguments(&narg);
	narg -= i;
	{ object keyvars[16];
	parse_key(narg,args,8,L1keys,keyvars,OBJNULL,FALSE);
	if(keyvars[8]==Cnil){
	V2= Ct;
	}else{
	V2= keyvars[0];}
	V3= keyvars[1];
	V4= keyvars[9];
	V5= keyvars[2];
	V6= keyvars[10];
	V7= keyvars[3];
	V8= keyvars[4];
	V9= keyvars[5];
	if(keyvars[14]==Cnil){
	V10= MAKE_FIXNUM(0);
	}else{
	V10= keyvars[6];}
	V11= keyvars[7];
	}
	if(eql(Ct,(V2))){
	goto L6;}
	if(((V2))!=Cnil){
	goto L7;}
L6:
	V2= Ct;
	goto L5;
L7:
	if(!(eql((V2),VV[1]))){
	goto L12;}
	V2= VV[2];
	goto L5;
L12:
	{register object V12;
	object V13;                               /*  V               */
	V12= VV[3];
	V13= Cnil;
L17:
	if(!(endp((V12)))){
	goto L18;}
	V2= Ct;
	goto L5;
L18:
	V13= car((V12));
	(*LK0)(2,(V2),(V13))                      /*  SUBTYPEP        */;
	if(VALUES(0)==Cnil){
	goto L23;}
	V2= (V13);
	goto L5;
L23:
	V12= cdr((V12));
	goto L17;
	}
L5:
	if(type_of((V1))==t_fixnum||type_of((V1))==t_bignum){
	goto L29;}
	if(!((length((V1)))==(1))){
	goto L35;}
	V1= car((V1));
	if(((V1))==Cnil){
	goto L30;}
	goto L33;
L35:
	goto L30;
L33:
L29:
	{object V12;                              /*  X               */
	siLmake_vector(7,(V2),(V1),(V7),(V8),(V9),(V10),(V11))/*  MAKE-VECTOR*/;
	V12= VALUES(0);
	if(((V4))==Cnil){
	goto L39;}
	{object V13;                              /*  N               */
	register int V14;                         /*  I               */
	V14= 0;
L44:
	if(!((V14)>=(fix((V1))))){
	goto L45;}
	goto L39;
L45:
	aset1((V12),V14,(V3));
	V14= (V14)+1;
	goto L44;
	}
L39:
	if(((V6))==Cnil){
	goto L52;}
	{object V13;                              /*  N               */
	register int V14;                         /*  I               */
	V14= 0;
L57:
	if(!((V14)>=(fix((V1))))){
	goto L58;}
	goto L52;
L58:
	aset1((V12),V14,elt((V5),V14));
	V14= (V14)+1;
	goto L57;
	}
L52:
	VALUES(0) = (V12);
	RETURN(1);
	}
L30:
	if(((V8))==Cnil){
	goto L66;}
	RETURN(Lerror(2,VV[4],MAKE_FIXNUM(length((V1))))/*  ERROR     */);
L66:
	{object V13;                              /*  X               */
	{ int V14, i=0;
	T0= (V2);
	T1= (V7);
	T2= (V9);
	T3= (V10);
	T4= (V11);
	T5= (V1);
	V14=length(T5);
	VALUES(i++)=T0;
	VALUES(i++)=T1;
	VALUES(i++)=T2;
	VALUES(i++)=T3;
	VALUES(i++)=T4;
	V14+=i;
	for (; i<V14;i++,T5=CDR(T5))
		VALUES(i)=CAR(T5);
	APPLY(V14,siLmake_pure_array,&VALUES(0))  /*  MAKE-PURE-ARRAY */;
	V13= VALUES(0);
	}
	if((memql(MAKE_FIXNUM(0),(V1)))!=Cnil){
	goto L75;}
	if(((V4))==Cnil){
	goto L78;}
	{object V14;                              /*  CURSOR          */
	Lmake_list(3,MAKE_FIXNUM(length((V1))),VV[5],MAKE_FIXNUM(0))/*  MAKE-LIST*/;
	V14= VALUES(0);
L83:
	{ int V15, i=0;
	T0= (V3);
	T1= (V13);
	T2= (V14);
	V15=length(T2);
	VALUES(i++)=T0;
	VALUES(i++)=T1;
	V15+=i;
	for (; i<V15;i++,T2=CDR(T2))
		VALUES(i)=CAR(T2);
	APPLY(V15,siLaset,&VALUES(0))             /*  ASET            */;
	}
	L2(2,(V14),(V1))                          /*  INCREMENT-CURSOR*/;
	if(VALUES(0)==Cnil){
	goto L89;}
	goto L78;
L89:
	goto L83;
	}
L78:
	if(((V6))==Cnil){
	goto L75;}
	{object V14;                              /*  CURSOR          */
	Lmake_list(3,MAKE_FIXNUM(length((V1))),VV[5],MAKE_FIXNUM(0))/*  MAKE-LIST*/;
	V14= VALUES(0);
L98:
	{ int V15, i=0;
	L3(2,(V5),(V14))                          /*  SEQUENCE-CURSOR */;
	T0= VALUES(0);
	T1= (V13);
	T2= (V14);
	V15=length(T2);
	VALUES(i++)=T0;
	VALUES(i++)=T1;
	V15+=i;
	for (; i<V15;i++,T2=CDR(T2))
		VALUES(i)=CAR(T2);
	APPLY(V15,siLaset,&VALUES(0))             /*  ASET            */;
	}
	L2(2,(V14),(V1))                          /*  INCREMENT-CURSOR*/;
	if(VALUES(0)==Cnil){
	goto L104;}
	goto L75;
L104:
	goto L98;
	}
L75:
	VALUES(0) = (V13);
	RETURN(1);
	}
	}
}
/*	function definition for INCREMENT-CURSOR                      */
static L2(int narg, object V1, object V2)
{ VT4 VLEX4 CLSR4
	cs_check;
	check_arg(2);
TTL:
	if(((V1))!=Cnil){
	goto L110;}
	VALUES(0) = Ct;
	RETURN(1);
L110:
	{object V3;                               /*  CARRY           */
	L2(2,cdr((V1)),cdr((V2)))                 /*  INCREMENT-CURSOR*/;
	V3= VALUES(0);
	if(((V3))==Cnil){
	goto L114;}
	Lcar(1,(V1))                              /*  CAR             */;
	{int V4= (fix(VALUES(0)))+1;
	Lcar(1,(V2))                              /*  CAR             */;
	if(!((V4)>=(fix(VALUES(0))))){
	goto L117;}}
	if(type_of((V1))!=t_cons)FEwrong_type_argument(Scons,(V1));
	CAR((V1)) = MAKE_FIXNUM(0);
	VALUES(0) = Ct;
	RETURN(1);
L117:
	Lcar(1,(V1))                              /*  CAR             */;
	if(type_of((V1))!=t_cons)FEwrong_type_argument(Scons,(V1));
	CAR((V1)) = MAKE_FIXNUM((fix(VALUES(0)))+1);
	VALUES(0) = Cnil;
	RETURN(1);
L114:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SEQUENCE-CURSOR                       */
static L3(int narg, object V1, object V2)
{ VT5 VLEX5 CLSR5
	cs_check;
	check_arg(2);
TTL:
	if(((V2))!=Cnil){
	goto L125;}
	VALUES(0) = (V1);
	RETURN(1);
L125:
	Lcar(1,(V2))                              /*  CAR             */;
	V1= elt((V1),fix(VALUES(0)));
	V2= cdr((V2));
	goto TTL;
}
/*	function definition for VECTOR                                */
static L4(int narg, ...)
{ VT6 VLEX6 CLSR6
	cs_check;
	{int i=0;
	object V1;
	va_list args; va_start(args, narg);
	narg -= i;
	V1=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V1;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	RETURN(L1(5,CONS(MAKE_FIXNUM(length((V1))),Cnil),VV[6],Ct,VV[7],(V1))/*  MAKE-ARRAY*/);
	}
}
/*	function definition for ARRAY-DIMENSIONS                      */
static L5(int narg, object V1)
{ VT7 VLEX7 CLSR7
	cs_check;
	check_arg(1);
TTL:
	{register object V2;                      /*  I               */
	object V3;                                /*  D               */
	Larray_rank(1,(V1))                       /*  ARRAY-RANK      */;
	V2= VALUES(0);
	V3= Cnil;
L133:
	if(!(number_compare((V2),MAKE_FIXNUM(0))==0)){
	goto L134;}
	VALUES(0) = (V3);
	RETURN(1);
L134:
	V2= one_minus((V2));
	Larray_dimension(2,(V1),(V2))             /*  ARRAY-DIMENSION */;
	V3= CONS(VALUES(0),(V3));
	goto L133;
	}
}
/*	function definition for ARRAY-IN-BOUNDS-P                     */
static L6(int narg, object V1, ...)
{ VT8 VLEX8 CLSR8
	cs_check;
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if(narg<1) FEtoo_few_arguments(&narg);
	narg -= i;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{object V3;                               /*  R               */
	Larray_rank(1,(V1))                       /*  ARRAY-RANK      */;
	V3= VALUES(0);
	if(!(number_compare((V3),MAKE_FIXNUM(length((V2))))!=0)){
	goto L145;}
	Lerror(3,VV[8],(V3),MAKE_FIXNUM(length((V2))))/*  ERROR       */;
L145:
	{register object V4;                      /*  I               */
	register object V5;                       /*  S               */
	V4= MAKE_FIXNUM(0);
	V5= (V2);
L149:
	if(!(number_compare((V4),(V3))>=0)){
	goto L150;}
	VALUES(0) = Ct;
	RETURN(1);
L150:
	if(number_compare(car((V5)),MAKE_FIXNUM(0))<0){
	goto L154;}
	{object V7= car((V5));
	Larray_dimension(2,(V1),(V4))             /*  ARRAY-DIMENSION */;
	if(!(number_compare(V7,VALUES(0))>=0)){
	goto L153;}}
L154:
	VALUES(0) = Cnil;
	RETURN(1);
L153:
	V4= one_plus((V4));
	V5= cdr((V5));
	goto L149;
	}
	}
	}
}
/*	function definition for ARRAY-ROW-MAJOR-INDEX                 */
static L7(int narg, object V1, ...)
{ VT9 VLEX9 CLSR9
	cs_check;
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if(narg<1) FEtoo_few_arguments(&narg);
	narg -= i;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{object V3;                               /*  I               */
	object V4;                                /*  J               */
	register object V5;                       /*  S               */
	V3= MAKE_FIXNUM(0);
	V4= MAKE_FIXNUM(0);
	V5= (V2);
L164:
	if(((V5))!=Cnil){
	goto L165;}
	VALUES(0) = (V4);
	RETURN(1);
L165:
	{object V7;
	V7= one_plus((V3));
	Larray_dimension(2,(V1),(V3))             /*  ARRAY-DIMENSION */;
	V4= number_plus(number_times((V4),VALUES(0)),car((V5)));
	V5= cdr((V5));
	V3= (V7);}
	goto L164;
	}
	}
}
/*	function definition for BIT                                   */
static L8(int narg, object V1, ...)
{ VT10 VLEX10 CLSR10
	cs_check;
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if(narg<1) FEtoo_few_arguments(&narg);
	narg -= i;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{ int V3, i=0;
	T0= (V1);
	T1= (V2);
	V3=length(T1);
	VALUES(i++)=T0;
	V3+=i;
	for (; i<V3;i++,T1=CDR(T1))
		VALUES(i)=CAR(T1);
	RETURN(APPLY(V3,Laref,&VALUES(0))         /*  AREF            */);
	}
	}
}
/*	function definition for BIT-AND                               */
static L10(int narg, object V1, object V2, ...)
{ VT11 VLEX11 CLSR11
	cs_check;
	{int i=2;
	object V3;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	if(narg>3) FEtoo_many_arguments(&narg);
	if (i==narg) goto L176;
	V3= va_arg(args, object);
	i++;
	goto L177;
L176:
	V3= Cnil;
L177:
	RETURN(siLbit_array_op(4,MAKE_FIXNUM(1),(V1),(V2),(V3))/*  BIT-ARRAY-OP*/);
	}
}
/*	function definition for BIT-IOR                               */
static L11(int narg, object V1, object V2, ...)
{ VT12 VLEX12 CLSR12
	cs_check;
	{int i=2;
	object V3;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	if(narg>3) FEtoo_many_arguments(&narg);
	if (i==narg) goto L179;
	V3= va_arg(args, object);
	i++;
	goto L180;
L179:
	V3= Cnil;
L180:
	RETURN(siLbit_array_op(4,MAKE_FIXNUM(7),(V1),(V2),(V3))/*  BIT-ARRAY-OP*/);
	}
}
/*	function definition for BIT-XOR                               */
static L12(int narg, object V1, object V2, ...)
{ VT13 VLEX13 CLSR13
	cs_check;
	{int i=2;
	object V3;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	if(narg>3) FEtoo_many_arguments(&narg);
	if (i==narg) goto L182;
	V3= va_arg(args, object);
	i++;
	goto L183;
L182:
	V3= Cnil;
L183:
	RETURN(siLbit_array_op(4,MAKE_FIXNUM(6),(V1),(V2),(V3))/*  BIT-ARRAY-OP*/);
	}
}
/*	function definition for BIT-EQV                               */
static L13(int narg, object V1, object V2, ...)
{ VT14 VLEX14 CLSR14
	cs_check;
	{int i=2;
	object V3;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	if(narg>3) FEtoo_many_arguments(&narg);
	if (i==narg) goto L185;
	V3= va_arg(args, object);
	i++;
	goto L186;
L185:
	V3= Cnil;
L186:
	RETURN(siLbit_array_op(4,MAKE_FIXNUM(9),(V1),(V2),(V3))/*  BIT-ARRAY-OP*/);
	}
}
/*	function definition for BIT-NAND                              */
static L14(int narg, object V1, object V2, ...)
{ VT15 VLEX15 CLSR15
	cs_check;
	{int i=2;
	object V3;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	if(narg>3) FEtoo_many_arguments(&narg);
	if (i==narg) goto L188;
	V3= va_arg(args, object);
	i++;
	goto L189;
L188:
	V3= Cnil;
L189:
	RETURN(siLbit_array_op(4,MAKE_FIXNUM(14),(V1),(V2),(V3))/*  BIT-ARRAY-OP*/);
	}
}
/*	function definition for BIT-NOR                               */
static L15(int narg, object V1, object V2, ...)
{ VT16 VLEX16 CLSR16
	cs_check;
	{int i=2;
	object V3;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	if(narg>3) FEtoo_many_arguments(&narg);
	if (i==narg) goto L191;
	V3= va_arg(args, object);
	i++;
	goto L192;
L191:
	V3= Cnil;
L192:
	RETURN(siLbit_array_op(4,MAKE_FIXNUM(8),(V1),(V2),(V3))/*  BIT-ARRAY-OP*/);
	}
}
/*	function definition for BIT-ANDC1                             */
static L16(int narg, object V1, object V2, ...)
{ VT17 VLEX17 CLSR17
	cs_check;
	{int i=2;
	object V3;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	if(narg>3) FEtoo_many_arguments(&narg);
	if (i==narg) goto L194;
	V3= va_arg(args, object);
	i++;
	goto L195;
L194:
	V3= Cnil;
L195:
	RETURN(siLbit_array_op(4,MAKE_FIXNUM(4),(V1),(V2),(V3))/*  BIT-ARRAY-OP*/);
	}
}
/*	function definition for BIT-ANDC2                             */
static L17(int narg, object V1, object V2, ...)
{ VT18 VLEX18 CLSR18
	cs_check;
	{int i=2;
	object V3;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	if(narg>3) FEtoo_many_arguments(&narg);
	if (i==narg) goto L197;
	V3= va_arg(args, object);
	i++;
	goto L198;
L197:
	V3= Cnil;
L198:
	RETURN(siLbit_array_op(4,MAKE_FIXNUM(2),(V1),(V2),(V3))/*  BIT-ARRAY-OP*/);
	}
}
/*	function definition for BIT-ORC1                              */
static L18(int narg, object V1, object V2, ...)
{ VT19 VLEX19 CLSR19
	cs_check;
	{int i=2;
	object V3;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	if(narg>3) FEtoo_many_arguments(&narg);
	if (i==narg) goto L200;
	V3= va_arg(args, object);
	i++;
	goto L201;
L200:
	V3= Cnil;
L201:
	RETURN(siLbit_array_op(4,MAKE_FIXNUM(13),(V1),(V2),(V3))/*  BIT-ARRAY-OP*/);
	}
}
/*	function definition for BIT-ORC2                              */
static L19(int narg, object V1, object V2, ...)
{ VT20 VLEX20 CLSR20
	cs_check;
	{int i=2;
	object V3;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	if(narg>3) FEtoo_many_arguments(&narg);
	if (i==narg) goto L203;
	V3= va_arg(args, object);
	i++;
	goto L204;
L203:
	V3= Cnil;
L204:
	RETURN(siLbit_array_op(4,MAKE_FIXNUM(11),(V1),(V2),(V3))/*  BIT-ARRAY-OP*/);
	}
}
/*	function definition for BIT-NOT                               */
static L20(int narg, object V1, ...)
{ VT21 VLEX21 CLSR21
	cs_check;
	{int i=1;
	object V2;
	va_list args; va_start(args, V1);
	if(narg<1) FEtoo_few_arguments(&narg);
	if(narg>2) FEtoo_many_arguments(&narg);
	if (i==narg) goto L206;
	V2= va_arg(args, object);
	i++;
	goto L207;
L206:
	V2= Cnil;
L207:
	RETURN(siLbit_array_op(4,MAKE_FIXNUM(12),(V1),(V1),(V2))/*  BIT-ARRAY-OP*/);
	}
}
/*	function definition for VECTOR-PUSH                           */
static L21(int narg, object V1, object V2)
{ VT22 VLEX22 CLSR22
	cs_check;
	check_arg(2);
TTL:
	{register int V3;                         /*  FP              */
	Lfill_pointer(1,(V2))                     /*  FILL-POINTER    */;
	V3= fix(VALUES(0));
	Larray_dimension(2,(V2),MAKE_FIXNUM(0))   /*  ARRAY-DIMENSION */;
	if(!((V3)<(fix(VALUES(0))))){
	goto L211;}
	aset1((V2),V3,(V1));
	siLfill_pointer_set(2,(V2),MAKE_FIXNUM((V3)+1))/*  FILL-POINTER-SET*/;
	VALUES(0) = MAKE_FIXNUM(V3);
	RETURN(1);
L211:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for VECTOR-PUSH-EXTEND                    */
static L22(int narg, object V1, object V2, ...)
{ VT23 VLEX23 CLSR23
	cs_check;
	{int i=2;
	object V3;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	if(narg>3) FEtoo_many_arguments(&narg);
	if (i==narg) goto L216;
	V3= va_arg(args, object);
	i++;
	goto L217;
L216:
	V3= Cnil;
L217:
	{register int V4;                         /*  FP              */
	Lfill_pointer(1,(V2))                     /*  FILL-POINTER    */;
	V4= fix(VALUES(0));
	Larray_dimension(2,(V2),MAKE_FIXNUM(0))   /*  ARRAY-DIMENSION */;
	if(!((V4)<(fix(VALUES(0))))){
	goto L221;}
	aset1((V2),V4,(V1));
	siLfill_pointer_set(2,(V2),MAKE_FIXNUM((V4)+1))/*  FILL-POINTER-SET*/;
	VALUES(0) = MAKE_FIXNUM(V4);
	RETURN(1);
L221:
	Larray_dimension(2,(V2),MAKE_FIXNUM(0))   /*  ARRAY-DIMENSION */;
	T0= VALUES(0);
	if((V3)!=Cnil){
	VALUES(0) = (V3);
	goto L228;}
	Larray_dimension(2,(V2),MAKE_FIXNUM(0))   /*  ARRAY-DIMENSION */;
	if(!((fix(VALUES(0)))>(0))){
	goto L230;}
	Larray_dimension(2,(V2),MAKE_FIXNUM(0))   /*  ARRAY-DIMENSION */;
	goto L228;
L230:
	VALUES(0) = MAKE_FIXNUM(5);
L228:
	{object V5= CONS(number_plus(T0,VALUES(0)),Cnil);
	Larray_element_type(1,(V2))               /*  ARRAY-ELEMENT-TYPE*/;
	L24(6,(V2),V5,VV[6],VALUES(0),VV[9],MAKE_FIXNUM(V4))/*  ADJUST-ARRAY*/;}
	aset1((V2),V4,(V1));
	siLfill_pointer_set(2,(V2),MAKE_FIXNUM((V4)+1))/*  FILL-POINTER-SET*/;
	VALUES(0) = MAKE_FIXNUM(V4);
	RETURN(1);
	}
	}
}
/*	function definition for VECTOR-POP                            */
static L23(int narg, object V1)
{ VT24 VLEX24 CLSR24
	cs_check;
	check_arg(1);
TTL:
	{int V2;                                  /*  FP              */
	Lfill_pointer(1,(V1))                     /*  FILL-POINTER    */;
	V2= fix(VALUES(0));
	if(!((V2)==(0))){
	goto L237;}
	Lerror(2,VV[10],(V1))                     /*  ERROR           */;
L237:
	siLfill_pointer_set(2,(V1),MAKE_FIXNUM((V2)-1))/*  FILL-POINTER-SET*/;
	VALUES(0) = aref1((V1),(V2)-1);
	RETURN(1);
	}
}
/*	function definition for ADJUST-ARRAY                          */
static L24(int narg, object V1, object V2, ...)
{ VT25 VLEX25 CLSR25
	cs_check;
	{int i=2;
	register object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	object V10;
	va_list args; va_start(args, V2);
	if(narg<2) FEtoo_few_arguments(&narg);
	narg -= i;
	V3=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object keyvars[14];
	parse_key(narg,args,7,L24keys,keyvars,V3,FALSE);
	V4= keyvars[0];
	V5= keyvars[1];
	V6= keyvars[2];
	V7= keyvars[3];
	V8= keyvars[4];
	V9= keyvars[5];
	V10= keyvars[6];
	}
	if(!(type_of((V2))==t_fixnum||type_of((V2))==t_bignum)){
	goto L241;}
	V2= CONS((V2),Cnil);
L241:
	{object V11;                              /*  ELEMENT-TYPE    */
	Larray_element_type(1,(V1))               /*  ARRAY-ELEMENT-TYPE*/;
	V11= VALUES(0);
	if(((V11))==(Ct)){
	goto L245;}
	V3= CONS((V11),(V3));
	V3= CONS(VV[6],(V3));
	}
L245:
	{object V11;                              /*  X               */
	{ int V12, i=0;
	T0= (V2);
	T1= VV[11];
	T2= Ct;
	T3= (V3);
	V12=length(T3);
	VALUES(i++)=T0;
	VALUES(i++)=T1;
	VALUES(i++)=T2;
	V12+=i;
	for (; i<V12;i++,T3=CDR(T3))
		VALUES(i)=CAR(T3);
	APPLY(V12,L1,&VALUES(0))                  /*  MAKE-ARRAY      */;
	V11= VALUES(0);
	}
	{register object V12;                     /*  CURSOR          */
	Lmake_list(3,MAKE_FIXNUM(length((V2))),VV[5],MAKE_FIXNUM(0))/*  MAKE-LIST*/;
	V12= VALUES(0);
L260:
	{ int V13, i=0;
	T0= (V1);
	T1= (V12);
	V13=length(T1);
	VALUES(i++)=T0;
	V13+=i;
	for (; i<V13;i++,T1=CDR(T1))
		VALUES(i)=CAR(T1);
	APPLY(V13,L6,&VALUES(0))                  /*  ARRAY-IN-BOUNDS-P*/;
	if(VALUES(0)==Cnil){
	goto L262;}
	}
	{ int V13, i=0;
	{ int V14, i=0;
	T1= (V1);
	T2= (V12);
	V14=length(T2);
	VALUES(i++)=T1;
	V14+=i;
	for (; i<V14;i++,T2=CDR(T2))
		VALUES(i)=CAR(T2);
	APPLY(V14,Laref,&VALUES(0))               /*  AREF            */;
	T0= VALUES(0);
	}
	T1= (V11);
	T2= (V12);
	V13=length(T2);
	VALUES(i++)=T0;
	VALUES(i++)=T1;
	V13+=i;
	for (; i<V13;i++,T2=CDR(T2))
		VALUES(i)=CAR(T2);
	APPLY(V13,siLaset,&VALUES(0))             /*  ASET            */;
	}
L262:
	L2(2,(V12),(V2))                          /*  INCREMENT-CURSOR*/;
	if(VALUES(0)==Cnil){
	goto L272;}
	goto L257;
L272:
	goto L260;
	}
L257:
	RETURN(siLreplace_array(2,(V1),(V11))     /*  REPLACE-ARRAY   */);
	}
	}
}
static LKF0(int narg, ...) {TRAMPOLINK(VV[40],&LK0);}
