
#include "input.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
   print(aref(VVprotect,147),Cnil);
	VV[0]->s.s_stype=(short)stp_special;
	if(VV[0]->s.s_dbind == OBJNULL){
	(VV[0]->s.s_dbind)= Cnil;}
	siLAmake_constant(2,VV[1],MAKE_FIXNUM(64))/*  *MAKE-CONSTANT  */;
	VV[4]->s.s_stype=(short)stp_special;
	if(VV[4]->s.s_dbind == OBJNULL){
	funcall(4,VV[639]->s.s_gfdef,MAKE_FIXNUM(64),VV[3],Cnil)/*  MAKE-ARRAY*/;
	(VV[4]->s.s_dbind)= VALUES(0);}
	(void)putprop(VV[4],VV[2],siSvariable_documentation);
	
	VV[6]->s.s_stype=(short)stp_special;
	if(VV[6]->s.s_dbind == OBJNULL){
	funcall(4,VV[639]->s.s_gfdef,MAKE_FIXNUM(64),VV[3],Cnil)/*  MAKE-ARRAY*/;
	(VV[6]->s.s_dbind)= VALUES(0);}
	(void)putprop(VV[6],VV[5],siSvariable_documentation);
	
	VV[8]->s.s_stype=(short)stp_special;
	if(VV[8]->s.s_dbind == OBJNULL){
	funcall(4,VV[639]->s.s_gfdef,MAKE_FIXNUM(64),VV[3],Cnil)/*  MAKE-ARRAY*/;
	(VV[8]->s.s_dbind)= VALUES(0);}
	(void)putprop(VV[8],VV[7],siSvariable_documentation);
	
	VV[10]->s.s_stype=(short)stp_special;
	if(VV[10]->s.s_dbind == OBJNULL){
	funcall(4,VV[639]->s.s_gfdef,MAKE_FIXNUM(64),VV[3],Cnil)/*  MAKE-ARRAY*/;
	(VV[10]->s.s_dbind)= VALUES(0);}
	(void)putprop(VV[10],VV[9],siSvariable_documentation);
	
	funcall(2,VV[640]->s.s_gfdef,VV[11])      /*  PROCLAIM        */;
	MF0(VV[641],L1);
	(void)putprop(VV[641],VV[Vdeb641],VV[642]);
	MF0(VV[643],L2);
	(void)putprop(VV[643],VV[Vdeb643],VV[642]);
	siLAmake_special(1,VV[13])                /*  *MAKE-SPECIAL   */;
	(VV[13]->s.s_dbind)= MAKE_FIXNUM(35);
	VV[14]->s.s_stype=(short)stp_special;
	if(VV[14]->s.s_dbind == OBJNULL){
	(VV[14]->s.s_dbind)= Cnil;}
	MM0(VV[644],L3);
	MF0(VV[645],L4);
	(void)putprop(VV[645],VV[Vdeb645],VV[642]);
	MF0(VV[135],L5);
	(void)putprop(VV[135],VV[Vdeb135],VV[642]);
	MF0(VV[646],L6);
	(void)putprop(VV[646],VV[Vdeb646],VV[642]);
	MF0(VV[647],L7);
	(void)putprop(VV[647],VV[Vdeb647],VV[642]);
	MM0(VV[648],L8);
	MF0(VV[649],L9);
	(void)putprop(VV[649],VV[Vdeb649],VV[642]);
	VV[42]->s.s_stype=(short)stp_special;
	if(VV[42]->s.s_dbind == OBJNULL){
	(VV[42]->s.s_dbind)= Cnil;}
	MF0(VV[650],L10);
	(void)putprop(VV[650],VV[Vdeb650],VV[642]);
	MF0(VV[651],L11);
	(void)putprop(VV[651],VV[Vdeb651],VV[642]);
	VV[45]->s.s_stype=(short)stp_special;
	if(VV[45]->s.s_dbind == OBJNULL){
	funcall(4,VV[639]->s.s_gfdef,MAKE_FIXNUM(32),VV[3],Cnil)/*  MAKE-ARRAY*/;
	(VV[45]->s.s_dbind)= VALUES(0);}
	MF0(VV[652],L12);
	(void)putprop(VV[652],VV[Vdeb652],VV[642]);
	MF0(VV[653],L13);
	(void)putprop(VV[653],VV[Vdeb653],VV[642]);
	MF0(VV[654],L14);
	(void)putprop(VV[654],VV[Vdeb654],VV[642]);
	MF0(VV[655],L15);
	(void)putprop(VV[655],VV[Vdeb655],VV[642]);
	MF0(VV[656],L16);
	(void)putprop(VV[656],VV[Vdeb656],VV[642]);
	MF0(VV[657],L17);
	(void)putprop(VV[657],VV[Vdeb657],VV[642]);
	VV[658] = make_cfun(LC19,Cnil,&Cblock);
	MF0(VV[659],L18);
	(void)putprop(VV[659],VV[Vdeb659],VV[642]);
	MF0(VV[660],L20);
	(void)putprop(VV[660],VV[Vdeb660],VV[642]);
	VV[661] = make_cfun(LC22,Cnil,&Cblock);
	MF0(VV[662],L21);
	(void)putprop(VV[662],VV[Vdeb662],VV[642]);
	VV[663] = make_cfun(LC24,Cnil,&Cblock);
	MF0(VV[664],L23);
	(void)putprop(VV[664],VV[Vdeb664],VV[642]);
	MF0(VV[665],L25);
	(void)putprop(VV[665],VV[Vdeb665],VV[642]);
	MF0key(VV[666],L26,2,L26keys);
	(void)putprop(VV[666],VV[Vdeb666],VV[642]);
	MF0(VV[667],L27);
	(void)putprop(VV[667],VV[Vdeb667],VV[642]);
	MM0(VV[668],L28);
	((VV[4]->s.s_dbind))->v.v_self[2]= VV[61];
	putprop(VV[61],MAKE_FIXNUM(2),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[3]= VV[62];
	putprop(VV[62],MAKE_FIXNUM(3),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[4]= VV[63];
	putprop(VV[63],MAKE_FIXNUM(4),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[5]= VV[64];
	putprop(VV[64],MAKE_FIXNUM(5),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[6]= VV[65];
	putprop(VV[65],MAKE_FIXNUM(6),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[7]= VV[66];
	putprop(VV[66],MAKE_FIXNUM(7),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[8]= VV[67];
	putprop(VV[67],MAKE_FIXNUM(8),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[9]= VV[68];
	putprop(VV[68],MAKE_FIXNUM(9),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[10]= VV[69];
	putprop(VV[69],MAKE_FIXNUM(10),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[11]= VV[70];
	putprop(VV[70],MAKE_FIXNUM(11),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[12]= VV[71];
	putprop(VV[71],MAKE_FIXNUM(12),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[13]= VV[72];
	putprop(VV[72],MAKE_FIXNUM(13),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[14]= VV[73];
	putprop(VV[73],MAKE_FIXNUM(14),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[15]= VV[74];
	putprop(VV[74],MAKE_FIXNUM(15),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[16]= VV[75];
	putprop(VV[75],MAKE_FIXNUM(16),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[17]= VV[76];
	putprop(VV[76],MAKE_FIXNUM(17),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[18]= VV[77];
	putprop(VV[77],MAKE_FIXNUM(18),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[19]= VV[78];
	putprop(VV[78],MAKE_FIXNUM(19),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[20]= VV[79];
	putprop(VV[79],MAKE_FIXNUM(20),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[21]= VV[80];
	putprop(VV[80],MAKE_FIXNUM(21),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[22]= VV[81];
	putprop(VV[81],MAKE_FIXNUM(22),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[23]= VV[82];
	putprop(VV[82],MAKE_FIXNUM(23),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[24]= VV[83];
	putprop(VV[83],MAKE_FIXNUM(24),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[25]= VV[84];
	putprop(VV[84],MAKE_FIXNUM(25),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[26]= VV[85];
	putprop(VV[85],MAKE_FIXNUM(26),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[27]= VV[86];
	putprop(VV[86],MAKE_FIXNUM(27),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[28]= VV[87];
	putprop(VV[87],MAKE_FIXNUM(28),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[29]= VV[88];
	putprop(VV[88],MAKE_FIXNUM(29),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[30]= VV[89];
	putprop(VV[89],MAKE_FIXNUM(30),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[31]= VV[90];
	putprop(VV[90],MAKE_FIXNUM(31),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[32]= VV[91];
	putprop(VV[91],MAKE_FIXNUM(32),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[33]= VV[92];
	putprop(VV[92],MAKE_FIXNUM(33),VV[23]);
	((VV[4]->s.s_dbind))->v.v_self[34]= VV[93];
	putprop(VV[93],MAKE_FIXNUM(34),VV[23]);
	VV[669] = make_cfun(LC32,Cnil,&Cblock);
	(void)putprop(VV[101],VV[52],siSpretty_print_format);
	
	MM0(VV[101],L29);
	MF0(VV[99],L36);
	(void)putprop(VV[99],VV[Vdeb99],VV[642]);
	MF0(VV[670],L37);
	(void)putprop(VV[670],VV[Vdeb670],VV[642]);
	MF0(VV[671],L38);
	(void)putprop(VV[671],VV[Vdeb671],VV[642]);
	MF0key(VV[672],L39,13,L39keys);
	(void)putprop(VV[672],VV[Vdeb672],VV[642]);
	{register int V1;                         /*  EVENT-CODE      */
	VALUES(0) = getf(VV[61]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L84;
	V1= fix(VALUES(0));
	goto L83;
L84:
	L5(1,VV[61])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V1= fix(VALUES(0));
L83:
	{object V2= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[670]->s.s_gfdef);
	(V2)->v.v_self[V1]= VALUES(0);}
	{object V2= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[671]->s.s_gfdef);
	(V2)->v.v_self[V1]= VALUES(0);}
	{object V2= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[672]->s.s_gfdef);
	(V2)->v.v_self[V1]= VALUES(0);}
	}
	{register int V3;                         /*  EVENT-CODE      */
	VALUES(0) = getf(VV[62]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L93;
	V3= fix(VALUES(0));
	goto L92;
L93:
	L5(1,VV[62])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V3= fix(VALUES(0));
L92:
	{object V4= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[670]->s.s_gfdef);
	(V4)->v.v_self[V3]= VALUES(0);}
	{object V4= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[671]->s.s_gfdef);
	(V4)->v.v_self[V3]= VALUES(0);}
	{object V4= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[672]->s.s_gfdef);
	(V4)->v.v_self[V3]= VALUES(0);}
	}
	{register int V5;                         /*  EVENT-CODE      */
	VALUES(0) = getf(VV[63]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L102;
	V5= fix(VALUES(0));
	goto L101;
L102:
	L5(1,VV[63])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V5= fix(VALUES(0));
L101:
	{object V6= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[670]->s.s_gfdef);
	(V6)->v.v_self[V5]= VALUES(0);}
	{object V6= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[671]->s.s_gfdef);
	(V6)->v.v_self[V5]= VALUES(0);}
	{object V6= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[672]->s.s_gfdef);
	(V6)->v.v_self[V5]= VALUES(0);}
	}
	{register int V7;                         /*  EVENT-CODE      */
	VALUES(0) = getf(VV[64]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L111;
	V7= fix(VALUES(0));
	goto L110;
L111:
	L5(1,VV[64])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V7= fix(VALUES(0));
L110:
	{object V8= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[670]->s.s_gfdef);
	(V8)->v.v_self[V7]= VALUES(0);}
	{object V8= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[671]->s.s_gfdef);
	(V8)->v.v_self[V7]= VALUES(0);}
	{object V8= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[672]->s.s_gfdef);
	(V8)->v.v_self[V7]= VALUES(0);}
	}
	MF0(VV[673],L40);
	(void)putprop(VV[673],VV[Vdeb673],VV[642]);
	MF0(VV[674],L41);
	(void)putprop(VV[674],VV[Vdeb674],VV[642]);
	MF0key(VV[675],L42,13,L42keys);
	(void)putprop(VV[675],VV[Vdeb675],VV[642]);
	{register int V9;                         /*  EVENT-CODE      */
	VALUES(0) = getf(VV[65]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L121;
	V9= fix(VALUES(0));
	goto L120;
L121:
	L5(1,VV[65])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V9= fix(VALUES(0));
L120:
	{object V10= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[673]->s.s_gfdef);
	(V10)->v.v_self[V9]= VALUES(0);}
	{object V10= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[674]->s.s_gfdef);
	(V10)->v.v_self[V9]= VALUES(0);}
	{object V10= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[675]->s.s_gfdef);
	(V10)->v.v_self[V9]= VALUES(0);}
	}
	MF0(VV[676],L43);
	(void)putprop(VV[676],VV[Vdeb676],VV[642]);
	MF0(VV[677],L44);
	(void)putprop(VV[677],VV[Vdeb677],VV[642]);
	MF0key(VV[678],L45,15,L45keys);
	(void)putprop(VV[678],VV[Vdeb678],VV[642]);
	{register int V11;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[66]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L131;
	V11= fix(VALUES(0));
	goto L130;
L131:
	L5(1,VV[66])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V11= fix(VALUES(0));
L130:
	{object V12= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[676]->s.s_gfdef);
	(V12)->v.v_self[V11]= VALUES(0);}
	{object V12= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[677]->s.s_gfdef);
	(V12)->v.v_self[V11]= VALUES(0);}
	{object V12= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[678]->s.s_gfdef);
	(V12)->v.v_self[V11]= VALUES(0);}
	}
	{register int V13;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[67]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L140;
	V13= fix(VALUES(0));
	goto L139;
L140:
	L5(1,VV[67])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V13= fix(VALUES(0));
L139:
	{object V14= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[676]->s.s_gfdef);
	(V14)->v.v_self[V13]= VALUES(0);}
	{object V14= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[677]->s.s_gfdef);
	(V14)->v.v_self[V13]= VALUES(0);}
	{object V14= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[678]->s.s_gfdef);
	(V14)->v.v_self[V13]= VALUES(0);}
	}
	MF0(VV[679],L46);
	(void)putprop(VV[679],VV[Vdeb679],VV[642]);
	MF0(VV[680],L47);
	(void)putprop(VV[680],VV[Vdeb680],VV[642]);
	MF0key(VV[681],L48,5,L48keys);
	(void)putprop(VV[681],VV[Vdeb681],VV[642]);
	{register int V15;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[68]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L150;
	V15= fix(VALUES(0));
	goto L149;
L150:
	L5(1,VV[68])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V15= fix(VALUES(0));
L149:
	{object V16= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[679]->s.s_gfdef);
	(V16)->v.v_self[V15]= VALUES(0);}
	{object V16= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[680]->s.s_gfdef);
	(V16)->v.v_self[V15]= VALUES(0);}
	{object V16= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[681]->s.s_gfdef);
	(V16)->v.v_self[V15]= VALUES(0);}
	}
	{register int V17;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[69]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L159;
	V17= fix(VALUES(0));
	goto L158;
L159:
	L5(1,VV[69])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V17= fix(VALUES(0));
L158:
	{object V18= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[679]->s.s_gfdef);
	(V18)->v.v_self[V17]= VALUES(0);}
	{object V18= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[680]->s.s_gfdef);
	(V18)->v.v_self[V17]= VALUES(0);}
	{object V18= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[681]->s.s_gfdef);
	(V18)->v.v_self[V17]= VALUES(0);}
	}
	MF0(VV[682],L49);
	(void)putprop(VV[682],VV[Vdeb682],VV[642]);
	MF0(VV[683],L50);
	(void)putprop(VV[683],VV[Vdeb683],VV[642]);
	MF0key(VV[684],L51,1,L51keys);
	(void)putprop(VV[684],VV[Vdeb684],VV[642]);
	{register int V19;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[70]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L169;
	V19= fix(VALUES(0));
	goto L168;
L169:
	L5(1,VV[70])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V19= fix(VALUES(0));
L168:
	{object V20= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[682]->s.s_gfdef);
	(V20)->v.v_self[V19]= VALUES(0);}
	{object V20= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[683]->s.s_gfdef);
	(V20)->v.v_self[V19]= VALUES(0);}
	{object V20= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[684]->s.s_gfdef);
	(V20)->v.v_self[V19]= VALUES(0);}
	}
	MF0(VV[685],L52);
	(void)putprop(VV[685],VV[Vdeb685],VV[642]);
	MF0(VV[686],L53);
	(void)putprop(VV[686],VV[Vdeb686],VV[642]);
	MF0key(VV[687],L54,8,L54keys);
	(void)putprop(VV[687],VV[Vdeb687],VV[642]);
	{register int V21;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[71]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L179;
	V21= fix(VALUES(0));
	goto L178;
L179:
	L5(1,VV[71])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V21= fix(VALUES(0));
L178:
	{object V22= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[685]->s.s_gfdef);
	(V22)->v.v_self[V21]= VALUES(0);}
	{object V22= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[686]->s.s_gfdef);
	(V22)->v.v_self[V21]= VALUES(0);}
	{object V22= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[687]->s.s_gfdef);
	(V22)->v.v_self[V21]= VALUES(0);}
	}
	MF0(VV[688],L55);
	(void)putprop(VV[688],VV[Vdeb688],VV[642]);
	MF0(VV[689],L56);
	(void)putprop(VV[689],VV[Vdeb689],VV[642]);
	MF0key(VV[690],L57,10,L57keys);
	(void)putprop(VV[690],VV[Vdeb690],VV[642]);
	{register int V23;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[72]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L189;
	V23= fix(VALUES(0));
	goto L188;
L189:
	L5(1,VV[72])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V23= fix(VALUES(0));
L188:
	{object V24= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[688]->s.s_gfdef);
	(V24)->v.v_self[V23]= VALUES(0);}
	{object V24= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[689]->s.s_gfdef);
	(V24)->v.v_self[V23]= VALUES(0);}
	{object V24= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[690]->s.s_gfdef);
	(V24)->v.v_self[V23]= VALUES(0);}
	}
	MF0(VV[691],L58);
	(void)putprop(VV[691],VV[Vdeb691],VV[642]);
	MF0(VV[692],L59);
	(void)putprop(VV[692],VV[Vdeb692],VV[642]);
	MF0key(VV[693],L60,5,L60keys);
	(void)putprop(VV[693],VV[Vdeb693],VV[642]);
	{register int V25;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[73]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L199;
	V25= fix(VALUES(0));
	goto L198;
L199:
	L5(1,VV[73])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V25= fix(VALUES(0));
L198:
	{object V26= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[691]->s.s_gfdef);
	(V26)->v.v_self[V25]= VALUES(0);}
	{object V26= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[692]->s.s_gfdef);
	(V26)->v.v_self[V25]= VALUES(0);}
	{object V26= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[693]->s.s_gfdef);
	(V26)->v.v_self[V25]= VALUES(0);}
	}
	MF0(VV[694],L61);
	(void)putprop(VV[694],VV[Vdeb694],VV[642]);
	MF0(VV[695],L62);
	(void)putprop(VV[695],VV[Vdeb695],VV[642]);
	MF0key(VV[696],L63,4,L63keys);
	(void)putprop(VV[696],VV[Vdeb696],VV[642]);
	{register int V27;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[74]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L209;
	V27= fix(VALUES(0));
	goto L208;
L209:
	L5(1,VV[74])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V27= fix(VALUES(0));
L208:
	{object V28= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[694]->s.s_gfdef);
	(V28)->v.v_self[V27]= VALUES(0);}
	{object V28= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[695]->s.s_gfdef);
	(V28)->v.v_self[V27]= VALUES(0);}
	{object V28= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[696]->s.s_gfdef);
	(V28)->v.v_self[V27]= VALUES(0);}
	}
	MF0(VV[697],L64);
	(void)putprop(VV[697],VV[Vdeb697],VV[642]);
	MF0(VV[698],L65);
	(void)putprop(VV[698],VV[Vdeb698],VV[642]);
	MF0key(VV[699],L66,10,L66keys);
	(void)putprop(VV[699],VV[Vdeb699],VV[642]);
	{register int V29;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[75]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L219;
	V29= fix(VALUES(0));
	goto L218;
L219:
	L5(1,VV[75])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V29= fix(VALUES(0));
L218:
	{object V30= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[697]->s.s_gfdef);
	(V30)->v.v_self[V29]= VALUES(0);}
	{object V30= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[698]->s.s_gfdef);
	(V30)->v.v_self[V29]= VALUES(0);}
	{object V30= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[699]->s.s_gfdef);
	(V30)->v.v_self[V29]= VALUES(0);}
	}
	MF0(VV[700],L67);
	(void)putprop(VV[700],VV[Vdeb700],VV[642]);
	MF0(VV[701],L68);
	(void)putprop(VV[701],VV[Vdeb701],VV[642]);
	MF0key(VV[702],L69,3,L69keys);
	(void)putprop(VV[702],VV[Vdeb702],VV[642]);
	{register int V31;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[76]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L229;
	V31= fix(VALUES(0));
	goto L228;
L229:
	L5(1,VV[76])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V31= fix(VALUES(0));
L228:
	{object V32= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[700]->s.s_gfdef);
	(V32)->v.v_self[V31]= VALUES(0);}
	{object V32= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[701]->s.s_gfdef);
	(V32)->v.v_self[V31]= VALUES(0);}
	{object V32= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[702]->s.s_gfdef);
	(V32)->v.v_self[V31]= VALUES(0);}
	}
	MF0(VV[703],L70);
	(void)putprop(VV[703],VV[Vdeb703],VV[642]);
	MF0(VV[704],L71);
	(void)putprop(VV[704],VV[Vdeb704],VV[642]);
	MF0key(VV[705],L72,4,L72keys);
	(void)putprop(VV[705],VV[Vdeb705],VV[642]);
	{register int V33;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[77]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L239;
	V33= fix(VALUES(0));
	goto L238;
L239:
	L5(1,VV[77])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V33= fix(VALUES(0));
L238:
	{object V34= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[703]->s.s_gfdef);
	(V34)->v.v_self[V33]= VALUES(0);}
	{object V34= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[704]->s.s_gfdef);
	(V34)->v.v_self[V33]= VALUES(0);}
	{object V34= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[705]->s.s_gfdef);
	(V34)->v.v_self[V33]= VALUES(0);}
	}
	MF0(VV[706],L73);
	(void)putprop(VV[706],VV[Vdeb706],VV[642]);
	MF0(VV[707],L74);
	(void)putprop(VV[707],VV[Vdeb707],VV[642]);
	MF0key(VV[708],L75,4,L75keys);
	(void)putprop(VV[708],VV[Vdeb708],VV[642]);
	{register int V35;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[78]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L249;
	V35= fix(VALUES(0));
	goto L248;
L249:
	L5(1,VV[78])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V35= fix(VALUES(0));
L248:
	{object V36= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[706]->s.s_gfdef);
	(V36)->v.v_self[V35]= VALUES(0);}
	{object V36= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[707]->s.s_gfdef);
	(V36)->v.v_self[V35]= VALUES(0);}
	{object V36= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[708]->s.s_gfdef);
	(V36)->v.v_self[V35]= VALUES(0);}
	}
	MF0(VV[709],L76);
	(void)putprop(VV[709],VV[Vdeb709],VV[642]);
	MF0(VV[710],L77);
	(void)putprop(VV[710],VV[Vdeb710],VV[642]);
	MF0key(VV[711],L78,4,L78keys);
	(void)putprop(VV[711],VV[Vdeb711],VV[642]);
	{register int V37;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[79]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L259;
	V37= fix(VALUES(0));
	goto L258;
L259:
	L5(1,VV[79])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V37= fix(VALUES(0));
L258:
	{object V38= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[709]->s.s_gfdef);
	(V38)->v.v_self[V37]= VALUES(0);}
	{object V38= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[710]->s.s_gfdef);
	(V38)->v.v_self[V37]= VALUES(0);}
	{object V38= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[711]->s.s_gfdef);
	(V38)->v.v_self[V37]= VALUES(0);}
	}
	MF0(VV[712],L79);
	(void)putprop(VV[712],VV[Vdeb712],VV[642]);
	MF0(VV[713],L80);
	(void)putprop(VV[713],VV[Vdeb713],VV[642]);
	MF0key(VV[714],L81,7,L81keys);
	(void)putprop(VV[714],VV[Vdeb714],VV[642]);
	{register int V39;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[80]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L269;
	V39= fix(VALUES(0));
	goto L268;
L269:
	L5(1,VV[80])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V39= fix(VALUES(0));
L268:
	{object V40= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[712]->s.s_gfdef);
	(V40)->v.v_self[V39]= VALUES(0);}
	{object V40= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[713]->s.s_gfdef);
	(V40)->v.v_self[V39]= VALUES(0);}
	{object V40= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[714]->s.s_gfdef);
	(V40)->v.v_self[V39]= VALUES(0);}
	}
	MF0(VV[715],L82);
	(void)putprop(VV[715],VV[Vdeb715],VV[642]);
	MF0(VV[716],L83);
	(void)putprop(VV[716],VV[Vdeb716],VV[642]);
	MF0key(VV[717],L84,10,L84keys);
	(void)putprop(VV[717],VV[Vdeb717],VV[642]);
	{register int V41;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[81]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L279;
	V41= fix(VALUES(0));
	goto L278;
L279:
	L5(1,VV[81])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V41= fix(VALUES(0));
L278:
	{object V42= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[715]->s.s_gfdef);
	(V42)->v.v_self[V41]= VALUES(0);}
	{object V42= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[716]->s.s_gfdef);
	(V42)->v.v_self[V41]= VALUES(0);}
	{object V42= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[717]->s.s_gfdef);
	(V42)->v.v_self[V41]= VALUES(0);}
	}
	MF0(VV[718],L85);
	(void)putprop(VV[718],VV[Vdeb718],VV[642]);
	MF0(VV[719],L86);
	(void)putprop(VV[719],VV[Vdeb719],VV[642]);
	MF0key(VV[720],L87,12,L87keys);
	(void)putprop(VV[720],VV[Vdeb720],VV[642]);
	{register int V43;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[82]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L289;
	V43= fix(VALUES(0));
	goto L288;
L289:
	L5(1,VV[82])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V43= fix(VALUES(0));
L288:
	{object V44= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[718]->s.s_gfdef);
	(V44)->v.v_self[V43]= VALUES(0);}
	{object V44= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[719]->s.s_gfdef);
	(V44)->v.v_self[V43]= VALUES(0);}
	{object V44= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[720]->s.s_gfdef);
	(V44)->v.v_self[V43]= VALUES(0);}
	}
	MF0(VV[721],L88);
	(void)putprop(VV[721],VV[Vdeb721],VV[642]);
	MF0(VV[722],L89);
	(void)putprop(VV[722],VV[Vdeb722],VV[642]);
	MF0key(VV[723],L90,5,L90keys);
	(void)putprop(VV[723],VV[Vdeb723],VV[642]);
	{register int V45;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[83]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L299;
	V45= fix(VALUES(0));
	goto L298;
L299:
	L5(1,VV[83])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V45= fix(VALUES(0));
L298:
	{object V46= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[721]->s.s_gfdef);
	(V46)->v.v_self[V45]= VALUES(0);}
	{object V46= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[722]->s.s_gfdef);
	(V46)->v.v_self[V45]= VALUES(0);}
	{object V46= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[723]->s.s_gfdef);
	(V46)->v.v_self[V45]= VALUES(0);}
	}
	MF0(VV[724],L91);
	(void)putprop(VV[724],VV[Vdeb724],VV[642]);
	MF0(VV[725],L92);
	(void)putprop(VV[725],VV[Vdeb725],VV[642]);
	MF0key(VV[726],L93,5,L93keys);
	(void)putprop(VV[726],VV[Vdeb726],VV[642]);
	{register int V47;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[84]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L309;
	V47= fix(VALUES(0));
	goto L308;
L309:
	L5(1,VV[84])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V47= fix(VALUES(0));
L308:
	{object V48= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[724]->s.s_gfdef);
	(V48)->v.v_self[V47]= VALUES(0);}
	{object V48= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[725]->s.s_gfdef);
	(V48)->v.v_self[V47]= VALUES(0);}
	{object V48= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[726]->s.s_gfdef);
	(V48)->v.v_self[V47]= VALUES(0);}
	}
	MF0(VV[727],L94);
	(void)putprop(VV[727],VV[Vdeb727],VV[642]);
	MF0(VV[728],L95);
	(void)putprop(VV[728],VV[Vdeb728],VV[642]);
	MF0key(VV[729],L96,5,L96keys);
	(void)putprop(VV[729],VV[Vdeb729],VV[642]);
	{register int V49;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[85]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L319;
	V49= fix(VALUES(0));
	goto L318;
L319:
	L5(1,VV[85])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V49= fix(VALUES(0));
L318:
	{object V50= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[727]->s.s_gfdef);
	(V50)->v.v_self[V49]= VALUES(0);}
	{object V50= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[728]->s.s_gfdef);
	(V50)->v.v_self[V49]= VALUES(0);}
	{object V50= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[729]->s.s_gfdef);
	(V50)->v.v_self[V49]= VALUES(0);}
	}
	MF0(VV[730],L97);
	(void)putprop(VV[730],VV[Vdeb730],VV[642]);
	MF0(VV[731],L98);
	(void)putprop(VV[731],VV[Vdeb731],VV[642]);
	MF0key(VV[732],L99,5,L99keys);
	(void)putprop(VV[732],VV[Vdeb732],VV[642]);
	{register int V51;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[86]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L329;
	V51= fix(VALUES(0));
	goto L328;
L329:
	L5(1,VV[86])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V51= fix(VALUES(0));
L328:
	{object V52= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[730]->s.s_gfdef);
	(V52)->v.v_self[V51]= VALUES(0);}
	{object V52= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[731]->s.s_gfdef);
	(V52)->v.v_self[V51]= VALUES(0);}
	{object V52= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[732]->s.s_gfdef);
	(V52)->v.v_self[V51]= VALUES(0);}
	}
	MF0(VV[733],L100);
	(void)putprop(VV[733],VV[Vdeb733],VV[642]);
	MF0(VV[734],L101);
	(void)putprop(VV[734],VV[Vdeb734],VV[642]);
	MF0key(VV[735],L102,6,L102keys);
	(void)putprop(VV[735],VV[Vdeb735],VV[642]);
	{register int V53;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[87]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L339;
	V53= fix(VALUES(0));
	goto L338;
L339:
	L5(1,VV[87])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V53= fix(VALUES(0));
L338:
	{object V54= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[733]->s.s_gfdef);
	(V54)->v.v_self[V53]= VALUES(0);}
	{object V54= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[734]->s.s_gfdef);
	(V54)->v.v_self[V53]= VALUES(0);}
	{object V54= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[735]->s.s_gfdef);
	(V54)->v.v_self[V53]= VALUES(0);}
	}
	MF0(VV[736],L103);
	(void)putprop(VV[736],VV[Vdeb736],VV[642]);
	MF0(VV[737],L104);
	(void)putprop(VV[737],VV[Vdeb737],VV[642]);
	MF0key(VV[738],L105,5,L105keys);
	(void)putprop(VV[738],VV[Vdeb738],VV[642]);
	{register int V55;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[88]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L349;
	V55= fix(VALUES(0));
	goto L348;
L349:
	L5(1,VV[88])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V55= fix(VALUES(0));
L348:
	{object V56= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[736]->s.s_gfdef);
	(V56)->v.v_self[V55]= VALUES(0);}
	{object V56= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[737]->s.s_gfdef);
	(V56)->v.v_self[V55]= VALUES(0);}
	{object V56= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[738]->s.s_gfdef);
	(V56)->v.v_self[V55]= VALUES(0);}
	}
	MF0(VV[739],L106);
	(void)putprop(VV[739],VV[Vdeb739],VV[642]);
	MF0(VV[740],L107);
	(void)putprop(VV[740],VV[Vdeb740],VV[642]);
	MF0key(VV[741],L108,8,L108keys);
	(void)putprop(VV[741],VV[Vdeb741],VV[642]);
	{register int V57;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[89]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L359;
	V57= fix(VALUES(0));
	goto L358;
L359:
	L5(1,VV[89])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V57= fix(VALUES(0));
L358:
	{object V58= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[739]->s.s_gfdef);
	(V58)->v.v_self[V57]= VALUES(0);}
	{object V58= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[740]->s.s_gfdef);
	(V58)->v.v_self[V57]= VALUES(0);}
	{object V58= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[741]->s.s_gfdef);
	(V58)->v.v_self[V57]= VALUES(0);}
	}
	MF0(VV[742],L109);
	(void)putprop(VV[742],VV[Vdeb742],VV[642]);
	MF0(VV[743],L110);
	(void)putprop(VV[743],VV[Vdeb743],VV[642]);
	MF0key(VV[744],L111,7,L111keys);
	(void)putprop(VV[744],VV[Vdeb744],VV[642]);
	{register int V59;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[90]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L369;
	V59= fix(VALUES(0));
	goto L368;
L369:
	L5(1,VV[90])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V59= fix(VALUES(0));
L368:
	{object V60= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[742]->s.s_gfdef);
	(V60)->v.v_self[V59]= VALUES(0);}
	{object V60= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[743]->s.s_gfdef);
	(V60)->v.v_self[V59]= VALUES(0);}
	{object V60= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[744]->s.s_gfdef);
	(V60)->v.v_self[V59]= VALUES(0);}
	}
	MF0(VV[745],L112);
	(void)putprop(VV[745],VV[Vdeb745],VV[642]);
	MF0(VV[746],L113);
	(void)putprop(VV[746],VV[Vdeb746],VV[642]);
	MF0key(VV[747],L114,6,L114keys);
	(void)putprop(VV[747],VV[Vdeb747],VV[642]);
	{register int V61;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[91]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L379;
	V61= fix(VALUES(0));
	goto L378;
L379:
	L5(1,VV[91])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V61= fix(VALUES(0));
L378:
	{object V62= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[745]->s.s_gfdef);
	(V62)->v.v_self[V61]= VALUES(0);}
	{object V62= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[746]->s.s_gfdef);
	(V62)->v.v_self[V61]= VALUES(0);}
	{object V62= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[747]->s.s_gfdef);
	(V62)->v.v_self[V61]= VALUES(0);}
	}
	MF0(VV[748],L115);
	(void)putprop(VV[748],VV[Vdeb748],VV[642]);
	MF0(VV[749],L116);
	(void)putprop(VV[749],VV[Vdeb749],VV[642]);
	MF0key(VV[750],L117,6,L117keys);
	(void)putprop(VV[750],VV[Vdeb750],VV[642]);
	{register int V63;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[92]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L389;
	V63= fix(VALUES(0));
	goto L388;
L389:
	L5(1,VV[92])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V63= fix(VALUES(0));
L388:
	{object V64= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[748]->s.s_gfdef);
	(V64)->v.v_self[V63]= VALUES(0);}
	{object V64= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[749]->s.s_gfdef);
	(V64)->v.v_self[V63]= VALUES(0);}
	{object V64= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[750]->s.s_gfdef);
	(V64)->v.v_self[V63]= VALUES(0);}
	}
	MF0(VV[751],L118);
	(void)putprop(VV[751],VV[Vdeb751],VV[642]);
	MF0(VV[752],L119);
	(void)putprop(VV[752],VV[Vdeb752],VV[642]);
	MF0key(VV[753],L120,4,L120keys);
	(void)putprop(VV[753],VV[Vdeb753],VV[642]);
	{register int V65;                        /*  EVENT-CODE      */
	VALUES(0) = getf(VV[93]->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L399;
	V65= fix(VALUES(0));
	goto L398;
L399:
	L5(1,VV[93])                              /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	V65= fix(VALUES(0));
L398:
	{object V66= (VV[6]->s.s_dbind);
	VALUES(0) = (VV[751]->s.s_gfdef);
	(V66)->v.v_self[V65]= VALUES(0);}
	{object V66= (VV[8]->s.s_dbind);
	VALUES(0) = (VV[752]->s.s_gfdef);
	(V66)->v.v_self[V65]= VALUES(0);}
	{object V66= (VV[10]->s.s_dbind);
	VALUES(0) = (VV[753]->s.s_gfdef);
	(V66)->v.v_self[V65]= VALUES(0);}
	}
	MF0(VV[754],L121);
	(void)putprop(VV[754],VV[Vdeb754],VV[642]);
	MF0(VV[755],L122);
	(void)putprop(VV[755],VV[Vdeb755],VV[642]);
	MF0(VV[756],L123);
	(void)putprop(VV[756],VV[Vdeb756],VV[642]);
	MF0(VV[757],L124);
	(void)putprop(VV[757],VV[Vdeb757],VV[642]);
	(void)putprop(VV[322],VV[52],siSpretty_print_format);
	
	MM0(VV[322],L125);
	MF0(VV[333],L126);
	(void)putprop(VV[333],VV[Vdeb333],VV[642]);
	MF0key(VV[758],L127,5,L127keys);
	(void)putprop(VV[758],VV[Vdeb758],VV[642]);
	MF0key(VV[759],L128,2,L128keys);
	(void)putprop(VV[759],VV[Vdeb759],VV[642]);
	MF0(VV[315],L129);
	(void)putprop(VV[315],VV[Vdeb315],VV[642]);
	MF0(VV[316],L130);
	(void)putprop(VV[316],VV[Vdeb316],VV[642]);
	putprop(VV[315],VV[316],VV[317]);
	remprop(VV[315],VV[318]);
	remprop(VV[315],VV[319]);
	putprop(VV[315],Cnil,VV[320]);
	(void)putprop(VV[760],VV[52],siSpretty_print_format);
	
	MM0(VV[760],L131);
	(void)putprop(VV[321],VV[52],siSpretty_print_format);
	
	MM0(VV[321],L133);
	MF0(VV[761],L134);
	(void)putprop(VV[761],VV[Vdeb761],VV[642]);
	MF0(VV[762],L135);
	(void)putprop(VV[762],VV[Vdeb762],VV[642]);
	(void)putprop(VV[323],VV[52],siSpretty_print_format);
	
	MM0(VV[323],L136);
	(void)putprop(VV[329],VV[52],siSpretty_print_format);
	
	MM0(VV[329],L139);
	siLAmake_special(1,VV[337])               /*  *MAKE-SPECIAL   */;
	(VV[337]->s.s_dbind)= VV[338];
	MF0(VV[763],L144);
	(void)putprop(VV[763],VV[Vdeb763],VV[642]);
	MF0(VV[764],L145);
	(void)putprop(VV[764],VV[Vdeb764],VV[642]);
	MF0(VV[765],L146);
	(void)putprop(VV[765],VV[Vdeb765],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[345],VV[346],VV[347],Cnil,VV[348],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[345])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[345],VV[349],Cnil,Cnil,VV[350],VV[351],Cnil,VV[37],Cnil,VV[352],MAKE_FIXNUM(8),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[769],L147,8,L147keys);
	(void)putprop(VV[769],VV[Vdeb769],VV[642]);
	MF0(VV[353],L148);
	(void)putprop(VV[353],VV[Vdeb353],VV[642]);
	MF0(VV[770],L149);
	(void)putprop(VV[770],VV[Vdeb770],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[355],VV[356],VV[357],Cnil,VV[358],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[355])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[355],VV[359],Cnil,Cnil,VV[360],VV[361],Cnil,VV[345],Cnil,VV[362],MAKE_FIXNUM(9),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[771],L150,9,L150keys);
	(void)putprop(VV[771],VV[Vdeb771],VV[642]);
	MF0(VV[363],L151);
	(void)putprop(VV[363],VV[Vdeb363],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[365],VV[366],VV[367],Cnil,VV[368],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[365])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[365],VV[369],Cnil,Cnil,VV[370],VV[371],Cnil,VV[345],Cnil,VV[372],MAKE_FIXNUM(9),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[772],L153,9,L153keys);
	(void)putprop(VV[772],VV[Vdeb772],VV[642]);
	MF0(VV[373],L154);
	(void)putprop(VV[373],VV[Vdeb373],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[375],VV[376],Cnil,Cnil,VV[377],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[375])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[375],VV[378],Cnil,Cnil,Cnil,VV[379],Cnil,VV[345],Cnil,VV[380],MAKE_FIXNUM(8),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[773],L156,8,L156keys);
	(void)putprop(VV[773],VV[Vdeb773],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[381],VV[382],Cnil,Cnil,VV[383],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[381])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[381],VV[384],Cnil,Cnil,Cnil,VV[385],Cnil,VV[345],Cnil,VV[386],MAKE_FIXNUM(8),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[774],L157,8,L157keys);
	(void)putprop(VV[774],VV[Vdeb774],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[387],VV[388],VV[389],Cnil,VV[390],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[387])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[387],VV[391],Cnil,Cnil,VV[392],VV[393],Cnil,VV[345],Cnil,VV[394],MAKE_FIXNUM(9),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[775],L158,9,L158keys);
	(void)putprop(VV[775],VV[Vdeb775],VV[642]);
	MF0(VV[395],L159);
	(void)putprop(VV[395],VV[Vdeb395],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[397],VV[398],Cnil,Cnil,VV[399],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[397])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[397],VV[400],Cnil,Cnil,Cnil,VV[401],Cnil,VV[355],Cnil,VV[402],MAKE_FIXNUM(9),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[776],L161,9,L161keys);
	(void)putprop(VV[776],VV[Vdeb776],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[403],VV[404],Cnil,Cnil,VV[405],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[403])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[403],VV[406],Cnil,Cnil,Cnil,VV[407],Cnil,VV[355],Cnil,VV[408],MAKE_FIXNUM(9),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[777],L162,9,L162keys);
	(void)putprop(VV[777],VV[Vdeb777],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[409],VV[410],Cnil,Cnil,VV[411],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[409])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[409],VV[412],Cnil,Cnil,Cnil,VV[413],Cnil,VV[355],Cnil,VV[414],MAKE_FIXNUM(9),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[778],L163,9,L163keys);
	(void)putprop(VV[778],VV[Vdeb778],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[415],VV[416],Cnil,Cnil,VV[417],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[415])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[415],VV[418],Cnil,Cnil,Cnil,VV[419],Cnil,VV[355],Cnil,VV[420],MAKE_FIXNUM(9),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[779],L164,9,L164keys);
	(void)putprop(VV[779],VV[Vdeb779],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[421],VV[422],Cnil,Cnil,VV[423],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[421])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[421],VV[424],Cnil,Cnil,Cnil,VV[425],Cnil,VV[355],Cnil,VV[426],MAKE_FIXNUM(9),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[780],L165,9,L165keys);
	(void)putprop(VV[780],VV[Vdeb780],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[427],VV[428],Cnil,Cnil,VV[429],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[427])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[427],VV[430],Cnil,Cnil,Cnil,VV[431],Cnil,VV[355],Cnil,VV[432],MAKE_FIXNUM(9),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[781],L166,9,L166keys);
	(void)putprop(VV[781],VV[Vdeb781],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[433],VV[434],Cnil,Cnil,VV[435],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[433])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[433],VV[436],Cnil,Cnil,Cnil,VV[437],Cnil,VV[345],Cnil,VV[438],MAKE_FIXNUM(8),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[782],L167,8,L167keys);
	(void)putprop(VV[782],VV[Vdeb782],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[439],VV[440],Cnil,Cnil,VV[441],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[439])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[439],VV[442],Cnil,Cnil,Cnil,VV[443],Cnil,VV[345],Cnil,VV[444],MAKE_FIXNUM(8),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[783],L168,8,L168keys);
	(void)putprop(VV[783],VV[Vdeb783],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[445],VV[446],Cnil,Cnil,VV[447],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[445])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[445],VV[448],Cnil,Cnil,Cnil,VV[449],Cnil,VV[345],Cnil,VV[450],MAKE_FIXNUM(8),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[784],L169,8,L169keys);
	(void)putprop(VV[784],VV[Vdeb784],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[451],VV[452],Cnil,Cnil,VV[453],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[451])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[451],VV[454],Cnil,Cnil,Cnil,VV[455],Cnil,VV[345],Cnil,VV[456],MAKE_FIXNUM(8),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[785],L170,8,L170keys);
	(void)putprop(VV[785],VV[Vdeb785],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[457],VV[458],Cnil,Cnil,VV[459],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[457])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[457],VV[460],Cnil,Cnil,Cnil,VV[461],Cnil,VV[355],Cnil,VV[462],MAKE_FIXNUM(9),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[786],L171,9,L171keys);
	(void)putprop(VV[786],VV[Vdeb786],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[463],VV[464],VV[465],Cnil,VV[466],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[463])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[463],VV[467],Cnil,Cnil,VV[468],VV[469],Cnil,VV[345],Cnil,VV[470],MAKE_FIXNUM(9),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[787],L172,9,L172keys);
	(void)putprop(VV[787],VV[Vdeb787],VV[642]);
	MF0(VV[471],L173);
	(void)putprop(VV[471],VV[Vdeb471],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[473],VV[474],Cnil,Cnil,VV[475],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[473])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[473],VV[476],Cnil,Cnil,Cnil,VV[477],Cnil,VV[355],Cnil,VV[478],MAKE_FIXNUM(9),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[788],L175,9,L175keys);
	(void)putprop(VV[788],VV[Vdeb788],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[479],VV[480],Cnil,Cnil,VV[481],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[479])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[479],VV[482],Cnil,Cnil,Cnil,VV[483],Cnil,VV[345],Cnil,VV[484],MAKE_FIXNUM(8),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[789],L176,8,L176keys);
	(void)putprop(VV[789],VV[Vdeb789],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[485],VV[486],VV[487],Cnil,VV[488],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[485])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[485],VV[489],Cnil,Cnil,VV[490],VV[491],Cnil,VV[492],Cnil,VV[493],MAKE_FIXNUM(4),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[790],L177,4,L177keys);
	(void)putprop(VV[790],VV[Vdeb790],VV[642]);
	MF0(VV[494],L178);
	(void)putprop(VV[494],VV[Vdeb494],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[47],VV[496],VV[497],Cnil,VV[498],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[47])      /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[47],VV[499],Cnil,Cnil,VV[500],VV[501],Cnil,VV[37],Cnil,VV[502],MAKE_FIXNUM(2),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[791],L180,2,L180keys);
	(void)putprop(VV[791],VV[Vdeb791],VV[642]);
	MF0(VV[503],L181);
	(void)putprop(VV[503],VV[Vdeb503],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[505],VV[506],VV[507],Cnil,VV[508],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[505])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[505],VV[509],Cnil,Cnil,VV[510],VV[511],Cnil,VV[37],Cnil,VV[512],MAKE_FIXNUM(5),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[792],L183,5,L183keys);
	(void)putprop(VV[792],VV[Vdeb792],VV[642]);
	MF0(VV[513],L184);
	(void)putprop(VV[513],VV[Vdeb513],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[515],VV[516],VV[517],Cnil,VV[518],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[515])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[515],VV[519],Cnil,Cnil,VV[520],VV[521],Cnil,VV[37],Cnil,VV[522],MAKE_FIXNUM(6),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[793],L186,6,L186keys);
	(void)putprop(VV[793],VV[Vdeb793],VV[642]);
	MF0(VV[523],L187);
	(void)putprop(VV[523],VV[Vdeb523],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[525],VV[526],VV[527],Cnil,VV[528],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[525])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[525],VV[529],Cnil,Cnil,VV[530],VV[531],Cnil,VV[37],Cnil,VV[532],MAKE_FIXNUM(4),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[794],L189,4,L189keys);
	(void)putprop(VV[794],VV[Vdeb794],VV[642]);
	MF0(VV[533],L190);
	(void)putprop(VV[533],VV[Vdeb533],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[535],VV[536],VV[537],Cnil,VV[538],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[535])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[535],VV[539],Cnil,Cnil,VV[540],VV[541],Cnil,VV[37],Cnil,VV[542],MAKE_FIXNUM(3),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[795],L192,3,L192keys);
	(void)putprop(VV[795],VV[Vdeb795],VV[642]);
	MF0(VV[543],L193);
	(void)putprop(VV[543],VV[Vdeb543],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[545],VV[546],VV[547],Cnil,VV[548],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[545])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[545],VV[549],Cnil,Cnil,VV[550],VV[551],Cnil,VV[37],Cnil,VV[552],MAKE_FIXNUM(4),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[796],L195,4,L195keys);
	(void)putprop(VV[796],VV[Vdeb796],VV[642]);
	MF0(VV[553],L196);
	(void)putprop(VV[553],VV[Vdeb553],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[555],VV[556],VV[557],Cnil,VV[558],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[555])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[555],VV[559],Cnil,Cnil,VV[560],VV[561],Cnil,VV[37],Cnil,VV[562],MAKE_FIXNUM(5),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[797],L198,5,L198keys);
	(void)putprop(VV[797],VV[Vdeb797],VV[642]);
	MF0(VV[563],L199);
	(void)putprop(VV[563],VV[Vdeb563],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[565],VV[566],VV[567],Cnil,VV[568],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[565])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[565],VV[569],Cnil,Cnil,VV[570],VV[571],Cnil,VV[37],Cnil,VV[572],MAKE_FIXNUM(2),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[798],L201,2,L201keys);
	(void)putprop(VV[798],VV[Vdeb798],VV[642]);
	MF0(VV[573],L202);
	(void)putprop(VV[573],VV[Vdeb573],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[576],VV[577],VV[578],Cnil,VV[579],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[576])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[576],VV[580],Cnil,Cnil,VV[581],VV[582],Cnil,VV[37],Cnil,VV[583],MAKE_FIXNUM(2),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[799],L204,2,L204keys);
	(void)putprop(VV[799],VV[Vdeb799],VV[642]);
	MF0(VV[584],L205);
	(void)putprop(VV[584],VV[Vdeb584],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[586],VV[587],VV[588],Cnil,VV[589],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[586])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[586],VV[590],Cnil,Cnil,VV[591],VV[592],Cnil,VV[37],Cnil,VV[593],MAKE_FIXNUM(2),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[800],L207,2,L207keys);
	(void)putprop(VV[800],VV[Vdeb800],VV[642]);
	MF0(VV[594],L208);
	(void)putprop(VV[594],VV[Vdeb594],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[28],VV[596],VV[597],Cnil,VV[598],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[28])      /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[28],VV[599],Cnil,Cnil,VV[600],VV[601],Cnil,VV[37],Cnil,VV[602],MAKE_FIXNUM(3),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[801],L210,3,L210keys);
	(void)putprop(VV[801],VV[Vdeb801],VV[642]);
	MF0(VV[603],L211);
	(void)putprop(VV[603],VV[Vdeb603],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[31],VV[605],VV[606],Cnil,VV[607],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[31])      /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[31],VV[608],Cnil,Cnil,VV[609],VV[610],Cnil,VV[37],Cnil,VV[611],MAKE_FIXNUM(3),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[802],L213,3,L213keys);
	(void)putprop(VV[802],VV[Vdeb802],VV[642]);
	MF0(VV[612],L214);
	(void)putprop(VV[612],VV[Vdeb612],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[614],VV[615],VV[616],Cnil,VV[617],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[614])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[614],VV[618],Cnil,Cnil,VV[619],VV[620],Cnil,VV[37],Cnil,VV[621],MAKE_FIXNUM(3),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[803],L216,3,L216keys);
	(void)putprop(VV[803],VV[Vdeb803],VV[642]);
	MF0(VV[622],L217);
	(void)putprop(VV[622],VV[Vdeb622],VV[642]);
	funcall(2,VV[766]->s.s_gfdef,VV[344])     /*  FIND-CLASS      */;
	funcall(9,VV[767]->s.s_gfdef,VALUES(0),VV[141],VV[624],VV[625],Cnil,VV[626],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[766]->s.s_gfdef,VV[141])     /*  FIND-CLASS      */;
	funcall(13,VV[768]->s.s_gfdef,VV[141],VV[627],Cnil,Cnil,VV[628],VV[629],Cnil,VV[37],Cnil,VV[630],MAKE_FIXNUM(2),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[804],L219,2,L219keys);
	(void)putprop(VV[804],VV[Vdeb804],VV[642]);
	MF0(VV[631],L220);
	(void)putprop(VV[631],VV[Vdeb631],VV[642]);
	MF0(VV[805],L222);
	(void)putprop(VV[805],VV[Vdeb805],VV[642]);
	MM0(VV[806],L223);
	MF0(VV[807],L224);
	(void)putprop(VV[807],VV[Vdeb807],VV[642]);
	MF0(VV[808],L225);
	(void)putprop(VV[808],VV[Vdeb808],VV[642]);
	VV[809] = make_cfun(LC226,Cnil,&Cblock);
	VALUES(0) = VV[809];
	putprop(VV[365],VALUES(0),VV[339]);
	VALUES(0) = (VV[807]->s.s_gfdef);
	putprop(VV[345],VALUES(0),VV[339]);
	VV[810] = make_cfun(LC227,Cnil,&Cblock);
	VALUES(0) = VV[810];
	putprop(VV[463],VALUES(0),VV[339]);
	VALUES(0) = (VV[808]->s.s_gfdef);
	putprop(VV[473],VALUES(0),VV[339]);
	VALUES(0) = (VV[808]->s.s_gfdef);
	putprop(VV[457],VALUES(0),VV[339]);
	VV[811] = make_cfun(LC228,Cnil,&Cblock);
	VALUES(0) = VV[811];
	putprop(VV[387],VALUES(0),VV[339]);
	VALUES(0) = (VV[808]->s.s_gfdef);
	putprop(VV[403],VALUES(0),VV[339]);
	VALUES(0) = (VV[808]->s.s_gfdef);
	putprop(VV[415],VALUES(0),VV[339]);
	VALUES(0) = (VV[807]->s.s_gfdef);
	putprop(VV[445],VALUES(0),VV[339]);
	VALUES(0) = (VV[808]->s.s_gfdef);
	putprop(VV[409],VALUES(0),VV[339]);
	VALUES(0) = (VV[807]->s.s_gfdef);
	putprop(VV[375],VALUES(0),VV[339]);
	VALUES(0) = (VV[807]->s.s_gfdef);
	putprop(VV[381],VALUES(0),VV[339]);
	VALUES(0) = (VV[808]->s.s_gfdef);
	putprop(VV[397],VALUES(0),VV[339]);
	VALUES(0) = (VV[808]->s.s_gfdef);
	putprop(VV[421],VALUES(0),VV[339]);
	VALUES(0) = (VV[808]->s.s_gfdef);
	putprop(VV[427],VALUES(0),VV[339]);
	VALUES(0) = (VV[807]->s.s_gfdef);
	putprop(VV[451],VALUES(0),VV[339]);
	VALUES(0) = (VV[807]->s.s_gfdef);
	putprop(VV[439],VALUES(0),VV[339]);
	VALUES(0) = (VV[807]->s.s_gfdef);
	putprop(VV[479],VALUES(0),VV[339]);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	local function CLOSURE                                        */
static LC228(int narg, object V1, object V2)
{ VT3 VLEX3 CLSR3
	RETURN(L224(3,(V1),(V2),VV[638])          /*  DECODE-CORE-ERROR*/);
}
/*	local function CLOSURE                                        */
static LC227(int narg, object V1, object V2)
{ VT4 VLEX4 CLSR4
	RETURN(L224(3,(V1),(V2),VV[637])          /*  DECODE-CORE-ERROR*/);
}
/*	local function CLOSURE                                        */
static LC226(int narg, object V1, object V2)
{ VT5 VLEX5 CLSR5
	{object V3= aref1(((V2))->in.in_slots[1],1);
	L224(2,(V1),(V2))                         /*  DECODE-CORE-ERROR*/;
	VALUES(0) = listA(3,VV[636],(V3),VALUES(0));
	RETURN(1);}
}
/*	local function CLOSURE                                        */
static LC32(int narg, object V1, object V2, object V3, object V4)
{ VT6 VLEX6 CLSR6
	if(!(type_of((V3))!=t_cons)){
	goto L664;}
	RETURN(LC31(4,(V1),(V2),(V3),(V4))        /*  EVENT-GET       */);
L664:
	{object V5;
	object V6= (V3);
	if(V6==Cnil){
	VALUES(0) = Cnil;
	RETURN(1);}
	T0=V5=CONS(Cnil,Cnil);
L666:
	{object V7;                               /*  ITEM            */
	LC31(4,(V1),(V2),CAR(V6),(V4))            /*  EVENT-GET       */;
	CDR(V5)= VALUES(0);
	}
	while(CDR(V5)!=Cnil)V5=CDR(V5);
	if((V6=CDR(V6))==Cnil){
	T0=CDR(T0);
	VALUES(0) = T0;
	RETURN(1);}
	goto L666;}
}
/*	local function CLOSURE                                        */
static LC24(int narg, object V1)
{ VT7 VLEX7 CLSR7
	VALUES(0) = (((((V1))->in.in_slots[1]==Cnil?Ct:Cnil))==Cnil?Ct:Cnil);
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC22(int narg, object V1)
{ VT8 VLEX8 CLSR8
	if(!(((((V1))->in.in_slots[66]==Cnil?Ct:Cnil))==Cnil)){
	goto L668;}
	VALUES(0) = Ct;
	RETURN(1);
L668:
	if((((V1))->in.in_slots[63])!=Cnil){
	goto L670;}
	VALUES(0) = Cnil;
	RETURN(1);
L670:
	if((memql(VV[50],((V1))->in.in_slots[64]))!=Cnil){
	goto L672;}
	VALUES(0) = Cnil;
	RETURN(1);
L672:
	VALUES(0) = Ct;
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC19(int narg, object V1, object V2, ...)
{ VT9 VLEX9 CLSR9
	{register object V3;
	va_list args; va_start(args, V2);
	narg -=2;
	V3=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object p=V3;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	Lapply(2,(V2),(V3))                       /*  APPLY           */;
	if(VALUES(0)==Cnil)goto L674;
	RETURN(1);
L674:
	if(!(((V1))->in.in_slots[61]==Cnil)){
	goto L676;}
	VALUES(0) = Ct;
	RETURN(1);
L676:
	VALUES(0) = (((((V1))->in.in_slots[10]==Cnil?Ct:Cnil))==Cnil?Ct:Cnil);
	RETURN(1);
	}
}
/*	local function EVENT-GET                                      */
static LC31(int narg, object V1, object V2, object V3, object V4)
{ VT10 VLEX10 CLSR10
TTL:
	if((memql((V1),VV[97]))!=Cnil){
	goto L679;}
	(*LK0)(1,(V3))                            /*  KINTERN         */;
	T0= VALUES(0);
	(*LK1)(1,(V1))                            /*  GETIFY          */;
	VALUES(0) = list(2,T0,listA(3,VALUES(0),(V2),(V4)));
	RETURN(1);
L679:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for ALLOCATE-EVENT                        */
static L1(int narg)
{ VT11 VLEX11 CLSR11
TTL:
L686:
	{register object V1;
	V1= (VV[0]->s.s_dbind);
	if(((V1))!=Cnil){
	goto L689;}
	VALUES(0) = Cnil;
	goto L684;
L689:
	if(!(((VV[0]->s.s_dbind))==((V1)))){
	goto L694;}
	(VV[0]->s.s_dbind)= ((V1))->in.in_slots[2];
	goto L692;
L694:
	goto L687;
L692:
	((V1))->in.in_slots[2]= Cnil;
	VALUES(0) = (V1);
	goto L684;
	}
L687:
	goto L686;
L684:
	if(VALUES(0)==Cnil)goto L683;
	RETURN(1);
L683:
	RETURN((*LK2)(1,MAKE_FIXNUM(32))          /*  MAKE-REPLY-BUFFER*/);
}
/*	function definition for DEALLOCATE-EVENT                      */
static L2(int narg, object V1)
{ VT12 VLEX12 CLSR12
TTL:
	((V1))->in.in_slots[0]= MAKE_FIXNUM(32);
	{volatile object V2;
	V2= (V1);
L702:
	{register object V3;
	V3= (VV[0]->s.s_dbind);
	((V2))->in.in_slots[2]= (V3);
	if(!(((VV[0]->s.s_dbind))==((V3)))){
	goto L708;}
	(VV[0]->s.s_dbind)= (V2);
	goto L706;
L708:
	goto L703;
L706:
	VALUES(0) = (V2);
	RETURN(1);
	}
L703:
	goto L702;
	}
}
/*	macro definition for DEFINE-EXTENSION                         */
static L3(int narg, object V1, object V2)
{ VT13 VLEX13 CLSR13
	{object V3=CDR(V1),V4,V5,V6;
	V4= CAR(V3);
	V3=CDR(V3);
	{object V7;
	V7=getf(V3,VV[817],OBJNULL);
	if(V7==OBJNULL){
	V5= Cnil;
	} else {
	V5= V7;}
	V7=getf(V3,VV[818],OBJNULL);
	if(V7==OBJNULL){
	V6= Cnil;
	} else {
	V6= V7;}}
	{object V8;                               /*  NAME-SYMBOL     */
	object V9;
	object V10;                               /*  EVENT-LIST      */
	(*LK0)(1,(V4))                            /*  KINTERN         */;
	V9= VALUES(0);
	{object V11;
	object V12= (V5);
	if(V12==Cnil){
	V10= Cnil;
	goto L716;}
	T0=V11=CONS(Cnil,Cnil);
L717:
	L4(1,CAR(V12))                            /*  CANONICALIZE-EVENT-NAME*/;
	CAR(V11)= VALUES(0);
	if((V12=CDR(V12))==Cnil){
	V10= T0;
	goto L716;}
	V11=CDR(V11)=CONS(Cnil,Cnil);
	goto L717;}
L716:
	V8= V9;
	{object V11= list(2,VV[20],(V8));
	{object V12= list(2,VV[20],(V10));
	{object V13= list(4,VV[19],(V11),(V12),list(2,VV[20],(V6)));
	VALUES(0) = list(3,VV[15],VV[16],list(3,VV[17],VV[14],list(3,VV[18],(V13),listA(3,VV[21],list(2,VV[20],(V8)),VV[22]))));
	RETURN(1);}}}
	}}
}
/*	function definition for CANONICALIZE-EVENT-NAME               */
static L4(int narg, object V1)
{ VT14 VLEX14 CLSR14
TTL:
	RETURN((*LK0)(1,(V1))                     /*  KINTERN         */);
}
/*	function definition for ALLOCATE-EXTENSION-EVENT-CODE         */
static L5(int narg, object V1)
{ VT15 VLEX15 CLSR15
TTL:
	{volatile object V2;                      /*  EVENT-CODE      */
	V2= getf((V1)->s.s_plist,VV[23],Cnil);
	if(((V2))!=Cnil){
	goto L720;}
	{volatile object V3;
	volatile object V4;                       /*  EXTENSION       */
	V3= (VV[14]->s.s_dbind);
	V4= Cnil;
L729:
	if(!((V3)==Cnil)){
	goto L730;}
	goto L725;
L730:
	V4= CAR((V3));
	if((memql((V1),CADR((V4))))==Cnil){
	goto L735;}
	goto L723;
L735:
	V3= CDR((V3));
	goto L729;
	}
L725:
	(*LK3)(2,(V1),VV[24])                     /*  X-TYPE-ERROR    */;
L723:
	(*LK4)(4,Cnil,(VV[4]->s.s_dbind),VV[25],(VV[13]->s.s_dbind))/*  POSITION*/;
	V2= VALUES(0);
	(((VV[4]->s.s_dbind))->v.v_self[fix((V2))]=((V1)));
	putprop((V1),(V2),VV[23]);
L720:
	VALUES(0) = (V2);
	RETURN(1);
	}
}
/*	function definition for GET-INTERNAL-EVENT-CODE               */
static L6(int narg, object V1, object V2)
{ VT16 VLEX16 CLSR16
	{register int V3;
	V3= fix(V2);
TTL:
	V3= ((127) & (V3));
	if(!((V3)<(fix((VV[13]->s.s_dbind))))){
	goto L747;}
	VALUES(0) = MAKE_FIXNUM(V3);
	RETURN(1);
L747:
	{int V4;                                  /*  CODE-OFFSET     */
	object V5;                                /*  EVENT-EXTENSIONS*/
	register int V6;                          /*  CODE            */
	V4= (V3)-(fix((VV[13]->s.s_dbind)));
	V5= ((V1))->in.in_slots[57];
	if(!((V4)<(((V5))->v.v_fillp))){
	goto L753;}
	V6= fix(((V5))->v.v_self[V4]);
	goto L751;
L753:
	V6= 0;
L751:
	if(!((V6)==0)){
	goto L755;}
	(*LK5)(6,VV[27],VV[28],VV[29],MAKE_FIXNUM(V6),VV[30],(V1))/*  X-CERROR*/;
L755:
	VALUES(0) = MAKE_FIXNUM(V6);
	RETURN(1);
	}
	}
}
/*	function definition for GET-EXTERNAL-EVENT-CODE               */
static L7(int narg, object V1, object V2)
{ VT17 VLEX17 CLSR17
TTL:
	{register object V3;                      /*  CODE            */
	L134(1,(V2))                              /*  GET-EVENT-CODE  */;
	V3= VALUES(0);
	if(!(number_compare((V3),(VV[13]->s.s_dbind))>=0)){
	goto L759;}
	{object V4= (VV[13]->s.s_dbind);
	(*LK4)(2,(V3),((V1))->in.in_slots[57])    /*  POSITION        */;
	if(VALUES(0)==Cnil)goto L764;
	goto L763;
L764:
	(*LK6)(5,VV[31],VV[30],(V1),VV[32],(V2))  /*  X-ERROR         */;
L763:
	V3= number_plus(MAKE_FIXNUM(V4),VALUES(0));}
L759:
	VALUES(0) = (V3);
	RETURN(1);
	}
}
/*	macro definition for EXTENSION-OPCODE                         */
static L8(int narg, object V1, object V2)
{ VT18 VLEX18 CLSR18
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	{object V6;                               /*  NAME-SYMBOL     */
	(*LK0)(1,(V5))                            /*  KINTERN         */;
	V6= VALUES(0);
	{object V7= list(2,VV[20],(V6));
	{object V8= list(2,VV[34],list(3,VV[35],(V7),list(2,VV[36],(V4))));
	VALUES(0) = list(3,VV[33],(V8),list(6,VV[37],VV[38],VV[39],list(2,VV[20],(V6)),VV[30],(V4)));
	RETURN(1);}}
	}}
}
/*	function definition for INITIALIZE-EXTENSIONS                 */
static L9(int narg, object V1)
{ VT19 VLEX19 CLSR19
TTL:
	{volatile object V2;                      /*  EVENT-EXTENSIONS*/
	volatile object V3;                       /*  EXTENSION-ALIST */
	(*LK7)(5,MAKE_FIXNUM(16),VV[40],VV[41],VV[3],MAKE_FIXNUM(0))/*  MAKE-ARRAY*/;
	V2= VALUES(0);
	V3= Cnil;
	{volatile object V4;
	volatile object V5;                       /*  EXTENSION       */
	V4= (VV[14]->s.s_dbind);
	V5= Cnil;
L772:
	if(!((V4)==Cnil)){
	goto L773;}
	goto L768;
L773:
	V5= CAR((V4));
	{volatile object V7;                      /*  NAME            */
	volatile object V8;                       /*  EVENTS          */
	V7= CAR((V5));
	V8= CADR((V5));
	{ int V9;
	volatile object V10;                      /*  MAJOR-OPCODE    */
	volatile object V11;                      /*  FIRST-EVENT     */
	volatile object V12;                      /*  FIRST-ERROR     */
	V9=(*LK8)(2,(V1),(V7))                    /*  QUERY-EXTENSION */;
	if (V9--==0) goto L782;
	V10= VALUES(0);
	if (V9--==0) goto L783;
	V11= VALUES(1);
	if (V9--==0) goto L784;
	V12= VALUES(2);
	goto L785;
L782:
	V10= Cnil;
L783:
	V11= Cnil;
L784:
	V12= Cnil;
L785:
	if(((V10))==Cnil){
	goto L778;}
	if(!(number_compare(MAKE_FIXNUM(0),(V10))<0)){
	goto L778;}
	V3= CONS(list(4,(V7),(V10),(V11),(V12)),(V3));
	if(!(number_compare(MAKE_FIXNUM(0),(V11))<0)){
	goto L778;}
	{register int V13;                        /*  MAX-EVENT       */
	V13= fix(number_minus(number_plus((V11),MAKE_FIXNUM(length((V8)))),(VV[13]->s.s_dbind)));
	if(!((V13)>=(((V2))->v.v_fillp))){
	goto L794;}
	{object V14;                              /*  NEW-EXTENSIONS  */
	(*LK7)(5,number_plus(MAKE_FIXNUM(V13),MAKE_FIXNUM(16)),VV[40],VV[41],VV[3],MAKE_FIXNUM(0))/*  MAKE-ARRAY*/;
	V14= VALUES(0);
	(*LK9)(2,(V14),(V2))                      /*  REPLACE         */;
	V2= (V14);
	}
	}
L794:
	{volatile object V13;
	volatile object V14;                      /*  EVENT           */
	V13= (V8);
	V14= Cnil;
L804:
	if(!((V13)==Cnil)){
	goto L805;}
	goto L778;
L805:
	V14= CAR((V13));
	{object V16;
	object V17;
	V16= (V2);
	V17= number_minus((V11),(VV[13]->s.s_dbind));
	L134(1,(V14))                             /*  GET-EVENT-CODE  */;
	aset1((V16),fix((V17)),VALUES(0));
	}
	V11= number_plus((V11),MAKE_FIXNUM(1));
	V13= CDR((V13));
	goto L804;
	}}
	}
L778:
	V4= CDR((V4));
	goto L772;
	}
L768:
	((V1))->in.in_slots[57]= (V2);
	((V1))->in.in_slots[56]= (V3);
	VALUES(0) = (V3);
	RETURN(1);
	}
}
/*	function definition for START-PENDING-COMMAND                 */
static L10(int narg, object V1)
{ VT20 VLEX20 CLSR20
TTL:
	{volatile object V2;                      /*  PENDING-COMMAND */
L827:
	{register object V3;
	V3= (VV[42]->s.s_dbind);
	if(((V3))!=Cnil){
	goto L830;}
	VALUES(0) = Cnil;
	goto L825;
L830:
	if(!(((VV[42]->s.s_dbind))==((V3)))){
	goto L835;}
	(VV[42]->s.s_dbind)= ((V3))->in.in_slots[3];
	goto L833;
L835:
	goto L828;
L833:
	((V3))->in.in_slots[3]= Cnil;
	VALUES(0) = (V3);
	goto L825;
	}
L828:
	goto L827;
L825:
	if(VALUES(0)==Cnil)goto L824;
	V2= VALUES(0);
	goto L823;
L824:
	(*LK10)(0)                                /*  MAKE-PENDING-COMMAND*/;
	V2= VALUES(0);
L823:
	((V2))->in.in_slots[1]= Cnil;
	(*LK11)(0)                                /*  CURRENT-PROCESS */;
	((V2))->in.in_slots[2]= VALUES(0);
	(*LK12)(2,MAKE_FIXNUM(16),MAKE_FIXNUM(0)) /*  BYTE            */;
	T0= VALUES(0);
	(*LK13)(2,T0,one_plus(((V1))->in.in_slots[3]))/*  LDB         */;
	((V2))->in.in_slots[0]= VALUES(0);
	{volatile object V3;
	volatile object V4;
	V4= ((V1))->in.in_slots[62];
	V3= (V2);
	if(((V4))!=Cnil){
	goto L850;}
	((V1))->in.in_slots[62]= (V3);
	goto L847;
L850:
	{volatile object V5;
	volatile object V6;
	V5= (V4);
	V6= ((V5))->in.in_slots[3];
L855:
	if(((V6))!=Cnil){
	goto L856;}
	((V5))->in.in_slots[3]= (V3);
	goto L847;
L856:
	V5= (V6);
	V6= ((V5))->in.in_slots[3];
	goto L855;
	}
	}
L847:
	VALUES(0) = (V2);
	RETURN(1);
	}
}
/*	function definition for STOP-PENDING-COMMAND                  */
static L11(int narg, object V1, object V2)
{ VT21 VLEX21 CLSR21
TTL:
	{volatile object V3;
	volatile object V4;
	V4= ((V1))->in.in_slots[62];
	V3= (V2);
	if(((V4))==Cnil){
	goto L868;}
	if(!(((V4))==((V3)))){
	goto L872;}
	((V1))->in.in_slots[62]= ((V3))->in.in_slots[3];
	V4= ((V3))->in.in_slots[3];
	goto L868;
L872:
	{volatile object V5;
	volatile object V6;
	V5= (V4);
	V6= ((V5))->in.in_slots[3];
L878:
	if(((V6))==Cnil){
	goto L880;}
	if(!(((V6))==((V3)))){
	goto L879;}
L880:
	if(!(((V6))==((V3)))){
	goto L868;}
	((V5))->in.in_slots[3]= ((V3))->in.in_slots[3];
	goto L868;
L879:
	V5= (V6);
	V6= ((V5))->in.in_slots[3];
	goto L878;
	}
L868:
	((V3))->in.in_slots[3]= Cnil;
	}
L893:
	{object V3;                               /*  REPLY-BUFFER    */
	{register object V4;
	V4= ((V2))->in.in_slots[1];
	if(((V4))==Cnil){
	goto L897;}
	{object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	V5= (V2);
	V6= (V4);
	V7= ((V5))->in.in_slots[1];
	V8= ((V6))->in.in_slots[2];
	V9= Cnil;
	((V5))->in.in_slots[1]= (V8);
	((V6))->in.in_slots[2]= (V9);
	}
L897:
	V3= (V4);
	}
	if(((V3))==Cnil){
	goto L908;}
	L13(1,(V3))                               /*  DEALLOCATE-REPLY-BUFFER*/;
	goto L894;
L908:
	goto L865;
	}
L894:
	goto L893;
L865:
	((V2))->in.in_slots[2]= Cnil;
	{volatile object V3;
	V3= (V2);
L914:
	{object V4;
	V4= (VV[42]->s.s_dbind);
	((V3))->in.in_slots[3]= (V4);
	if(!(((VV[42]->s.s_dbind))==((V4)))){
	goto L920;}
	(VV[42]->s.s_dbind)= (V3);
	goto L918;
L920:
	goto L915;
L918:
	goto L912;
	}
L915:
	goto L914;
	}
L912:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for ALLOCATE-REPLY-BUFFER                 */
static L12(int narg, object V1)
{ VT22 VLEX22 CLSR22
	{volatile int V2;
	V2= fix(V1);
TTL:
	if(!((V2)<=(32))){
	goto L926;}
	RETURN(L1(0)                              /*  ALLOCATE-EVENT  */);
L926:
	{volatile int V3;                         /*  INDEX           */
	Linteger_length(1,MAKE_FIXNUM((V2)-1))    /*  INTEGER-LENGTH  */;
	V3= fix(VALUES(0));
L932:
	{register object V4;
	V4= ((VV[45]->s.s_dbind))->v.v_self[V3];
	if(((V4))!=Cnil){
	goto L936;}
	VALUES(0) = Cnil;
	goto L930;
L936:
	if(!((((VV[45]->s.s_dbind))->v.v_self[V3])==((V4)))){
	goto L941;}
	((VV[45]->s.s_dbind))->v.v_self[V3]= ((V4))->in.in_slots[2];
	goto L939;
L941:
	goto L933;
L939:
	((V4))->in.in_slots[2]= Cnil;
	VALUES(0) = (V4);
	goto L930;
	}
L933:
	goto L932;
L930:
	if(VALUES(0)==Cnil)goto L929;
	RETURN(1);
L929:
	Lash(2,MAKE_FIXNUM(1),MAKE_FIXNUM(V3))    /*  ASH             */;
	RETURN((*LK2)(1,VALUES(0))                /*  MAKE-REPLY-BUFFER*/);
	}
	}
}
/*	function definition for DEALLOCATE-REPLY-BUFFER               */
static L13(int narg, object V1)
{ VT23 VLEX23 CLSR23
TTL:
	{volatile int V2;                         /*  SIZE            */
	V2= fix(((V1))->in.in_slots[0]);
	if(!((V2)<=(32))){
	goto L949;}
	RETURN(L2(1,(V1))                         /*  DEALLOCATE-EVENT*/);
L949:
	{volatile int V3;                         /*  INDEX           */
	Linteger_length(1,MAKE_FIXNUM((V2)-1))    /*  INTEGER-LENGTH  */;
	V3= fix(VALUES(0));
	{volatile object V4;
	V4= (V1);
L953:
	{register object V5;
	V5= ((VV[45]->s.s_dbind))->v.v_self[V3];
	((V4))->in.in_slots[2]= (V5);
	if(!((((VV[45]->s.s_dbind))->v.v_self[V3])==((V5)))){
	goto L960;}
	((VV[45]->s.s_dbind))->v.v_self[V3]= (V4);
	goto L958;
L960:
	goto L954;
L958:
	VALUES(0) = (V4);
	RETURN(1);
	}
L954:
	goto L953;
	}
	}
	}
}
/*	function definition for READ-ERROR-INPUT                      */
static L14(int narg, object V1, object V2, object V3, object V4)
{ VT24 VLEX24 CLSR24
	{volatile int V5;
	V5= fix(V2);
TTL:
	{volatile object V6;                      /*  COMMAND         */
	{volatile object V7;                      /*  PENDING-COMMAND */
	V7= ((V1))->in.in_slots[62];
L970:
	if(((V7))!=Cnil){
	goto L971;}
	V6= Cnil;
	goto L967;
L971:
	if(!((fix(((V7))->in.in_slots[0]))==(V5))){
	goto L974;}
	V6= (V7);
	goto L967;
L974:
	V7= ((V7))->in.in_slots[3];
	goto L970;
	}
L967:
	if(((V6))==Cnil){
	goto L981;}
	{volatile object V7;
	volatile object V8;
	V8= ((V6))->in.in_slots[1];
	V7= (V3);
	if(((V8))!=Cnil){
	goto L986;}
	((V6))->in.in_slots[1]= (V7);
	goto L983;
L986:
	{volatile object V9;
	volatile object V10;
	V9= (V8);
	V10= ((V9))->in.in_slots[2];
L991:
	if(((V10))!=Cnil){
	goto L992;}
	((V9))->in.in_slots[2]= (V7);
	goto L983;
L992:
	V9= (V10);
	V10= ((V9))->in.in_slots[2];
	goto L991;
	}
	}
L983:
	(*LK14)(1,((V6))->in.in_slots[2])         /*  PROCESS-WAKEUP  */;
	goto L966;
L981:
	if((memql(VV[46],((V1))->in.in_slots[64]))==Cnil){
	goto L1002;}
	goto L965;
L1002:
	{volatile object V7;
	volatile object V8;
	V8= ((V1))->in.in_slots[63];
	V7= (V3);
	if(((V8))!=Cnil){
	goto L1006;}
	((V1))->in.in_slots[63]= (V7);
	goto L966;
L1006:
	{volatile object V9;
	volatile object V10;
	V9= (V8);
	V10= ((V9))->in.in_slots[2];
L1011:
	if(((V10))!=Cnil){
	goto L1012;}
	((V9))->in.in_slots[2]= (V7);
	goto L966;
L1012:
	V9= (V10);
	V10= ((V9))->in.in_slots[2];
	goto L1011;
	}
	}
	}
L966:
	VALUES(0) = Cnil;
	RETURN(1);
L965:
	L17(2,(V1),(V4))                          /*  NOTE-INPUT-COMPLETE*/;
	T0= (VV[764]->s.s_gfdef);
	{object V13;
	L144(3,(V1),(V3),Ct)                      /*  MAKE-ERROR      */;
	V13= VALUES(0);
	L2(1,(V3))                                /*  DEALLOCATE-EVENT*/;
	VALUES(0) = (V13);
	}
	Lapply(3,T0,(V1),VALUES(0))               /*  APPLY           */;
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for READ-REPLY-INPUT                      */
static L15(int narg, object V1, object V2, object V3, object V4)
{ VT25 VLEX25 CLSR25
	{volatile int V5;
	volatile int V6;
	V5= fix(V2);
	V6= fix(V3);
TTL:
	{ int V7; object (V8);
	V8= new_frame_id();
	if ((V7=frs_push(FRS_CATCH,(V8)))!=0) V7--;
	else {
	{ int V9; volatile bool unwinding = FALSE;
	if ((V9=frs_push(FRS_PROTECT,Cnil))) {
	V9--; unwinding = TRUE;} else {
	if(!((32)<(V6))){
	goto L1029;}
	{volatile object V10;                     /*  REPBUF          */
	V10= Cnil;
	{ int V11; volatile bool unwinding = FALSE;
	if ((V11=frs_push(FRS_PROTECT,Cnil))) {
	V11--; unwinding = TRUE;} else {
	L12(1,MAKE_FIXNUM(V6))                    /*  ALLOCATE-REPLY-BUFFER*/;
	V10= VALUES(0);
	(*LK15)(4,((V10))->in.in_slots[1],((V4))->in.in_slots[1],MAKE_FIXNUM(0),MAKE_FIXNUM(32))/*  BUFFER-REPLACE*/;
	{object V12;
	object V13;
	V12= (V4);
	V13= (V10);
	V4= (V13);
	V10= Cnil;
	VALUES(0) = (V12);
	}
	V11=L2(1,VALUES(0))                       /*  DEALLOCATE-EVENT*/;
	}
	frs_pop();
	MV_SAVE(V11);
	if(((V10))==Cnil){
	goto L1044;}
	L13(1,(V10))                              /*  DEALLOCATE-REPLY-BUFFER*/;
L1044:
	MV_RESTORE(V11);
	if (unwinding) unwind(nlj_fr,nlj_tag,V11+1);
	else {}}
	}
	(*LK16)(4,(V1),((V4))->in.in_slots[1],MAKE_FIXNUM(32),MAKE_FIXNUM(V6))/*  BUFFER-INPUT*/;
	if(VALUES(0)==Cnil){
	goto L1047;}
	{ int V10;
	VALUES(0)=Ct;
	V10=1;
	unwind(frs_sch((V8)),Cnil,V10+1);}
L1047:
	((V4))->in.in_slots[3]= MAKE_FIXNUM(V6);
L1029:
	{volatile object V10;                     /*  COMMAND         */
	{volatile object V11;                     /*  PENDING-COMMAND */
	V11= ((V1))->in.in_slots[62];
L1055:
	if(((V11))!=Cnil){
	goto L1056;}
	V10= Cnil;
	goto L1052;
L1056:
	if(!((fix(((V11))->in.in_slots[0]))==(V5))){
	goto L1059;}
	V10= (V11);
	goto L1052;
L1059:
	V11= ((V11))->in.in_slots[3];
	goto L1055;
	}
L1052:
	if(((V10))==Cnil){
	goto L1051;}
	{volatile object V11;
	volatile object V12;
	{object V13;
	V13= (V4);
	V4= Cnil;
	V11= (V13);
	}
	V12= ((V10))->in.in_slots[1];
	if(((V12))!=Cnil){
	goto L1074;}
	((V10))->in.in_slots[1]= (V11);
	goto L1067;
L1074:
	{volatile object V13;
	volatile object V14;
	V13= (V12);
	V14= ((V13))->in.in_slots[2];
L1079:
	if(((V14))!=Cnil){
	goto L1080;}
	((V13))->in.in_slots[2]= (V11);
	goto L1067;
L1080:
	V13= (V14);
	V14= ((V13))->in.in_slots[2];
	goto L1079;
	}
	}
L1067:
	(*LK14)(1,((V10))->in.in_slots[2])        /*  PROCESS-WAKEUP  */;
	}
L1051:
	VALUES(0)=Cnil;
	V9=1;
	}
	frs_pop();
	MV_SAVE(V9);
	if(((V4))==Cnil){
	goto L1089;}
	L13(1,(V4))                               /*  DEALLOCATE-REPLY-BUFFER*/;
L1089:
	MV_RESTORE(V9);
	if (unwinding) unwind(nlj_fr,nlj_tag,V9+1);
	else {
	V7=V9;}}}
	frs_pop();
	RETURN(V7);
	}
	}
}
/*	function definition for READ-EVENT-INPUT                      */
static L16(int narg, object V1, object V2, object V3)
{ VT26 VLEX26 CLSR26
TTL:
	L6(2,(V1),(V2))                           /*  GET-INTERNAL-EVENT-CODE*/;
	((V3))->in.in_slots[0]= VALUES(0);
	L27(2,(V3),(V1))                          /*  ENQUEUE-EVENT   */;
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for NOTE-INPUT-COMPLETE                   */
static L17(int narg, object V1, object V2)
{ VT27 VLEX27 CLSR27
TTL:
	if(!((((V1))->in.in_slots[61])==((V2)))){
	goto L1096;}
	((V1))->in.in_slots[61]= Cnil;
	{object V3;                               /*  PROCESS         */
	V3= ((V1))->in.in_slots[65];
	if(((V3))==Cnil){
	goto L1099;}
	(*LK14)(1,(V3))                           /*  PROCESS-WAKEUP  */;
	}
L1099:
	if((((V1))->in.in_slots[61])!=Cnil){
	goto L1104;}
	{volatile object V3;                      /*  COMMAND         */
	V3= ((V1))->in.in_slots[62];
L1108:
	if(((V3))!=Cnil){
	goto L1109;}
	VALUES(0) = Cnil;
	RETURN(1);
L1109:
	(*LK14)(1,((V3))->in.in_slots[2])         /*  PROCESS-WAKEUP  */;
	V3= ((V3))->in.in_slots[3];
	goto L1108;
	}
L1104:
	VALUES(0) = Cnil;
	RETURN(1);
L1096:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for READ-INPUT                            */
static L18(int narg, object V1, object V2, object V3, object V4, ...)
{ VT28 VLEX28 CLSR28
	{volatile object V5;
	va_list args; va_start(args, V4);
	narg -=4;
	V5=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object p=V5;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{ int V6; object (V7);
	V7= new_frame_id();
	if ((V6=frs_push(FRS_CATCH,(V7)))!=0) V6--;
	else {
	{volatile object V8;                      /*  REPLY-BUFFER    */
	volatile object V9;                       /*  TOKEN           */
	(*LK11)(0)                                /*  CURRENT-PROCESS */;
	if(VALUES(0)==Cnil)goto L1118;
	V9= VALUES(0);
	goto L1117;
L1118:
	V9= CONS(Cnil,Cnil);
L1117:
	V8= Cnil;
	{ int V10; volatile bool unwinding = FALSE;
	if ((V10=frs_push(FRS_PROTECT,Cnil))) {
	V10--; unwinding = TRUE;} else {
L1122:
	if((((V1))->in.in_slots[10])==Cnil){
	goto L1124;}
	(*LK6)(3,VV[47],VV[30],(V1))              /*  X-ERROR         */;
L1124:
	Lapply(2,(V4),(V5))                       /*  APPLY           */;
	if(VALUES(0)==Cnil){
	goto L1127;}
	{ int V11;
	VALUES(0)=Cnil;
	V11=1;
	unwind(frs_sch((V7)),Cnil,V11+1);}
L1127:
	if(((V3))==Cnil){
	goto L1131;}
	if((((V1))->in.in_slots[61])==((V9))){
	goto L1135;}
	if(!((((V1))->in.in_slots[61])==(Cnil))){
	goto L1140;}
	((V1))->in.in_slots[61]= (V9);
	goto L1138;
L1140:
	goto L1132;
L1138:
L1135:
	(*LK17)(1,(V1))                           /*  BUFFER-LISTEN   */;
	if(VALUES(0)!=Cnil){
	goto L1131;}
L1132:
	goto L1123;
L1131:
	if((((V1))->in.in_slots[61])==((V9))){
	goto L1144;}
	if(!((((V1))->in.in_slots[61])==(Cnil))){
	goto L1150;}
	((V1))->in.in_slots[61]= (V9);
	goto L1144;
L1150:
	if(!(eql((V2),MAKE_FIXNUM(0)))){
	goto L1155;}
	{ int V12;
	VALUES(0)=VV[48];
	V12=1;
	unwind(frs_sch((V7)),Cnil,V12+1);}
L1155:
	T0= (VV[844]->s.s_gfdef);
	VALUES(0) = VV[658];
	Lapply(6,T0,VV[49],VALUES(0),(V1),(V4),(V5))/*  APPLY         */;
	goto L1122;
L1144:
	L1(0)                                     /*  ALLOCATE-EVENT  */;
	V8= VALUES(0);
	{object V12;                              /*  %REPLY-BUFFER   */
	V12= (V8);
	{register int V13;                        /*  BUFFER-BOFFSET  */
	register object V14;                      /*  BUFFER-BBUF     */
	V13= 0;
	V14= ((V12))->in.in_slots[1];
	{register int V15;                        /*  TYPE            */
	V15= 0;
	if(eql((V2),MAKE_FIXNUM(0))){
	goto L1168;}
	{object V16;                              /*  EOF-P           */
	(*LK18)(2,(V1),(V2))                      /*  BUFFER-INPUT-WAIT*/;
	V16= VALUES(0);
	if(((V16))==Cnil){
	goto L1168;}
	{ int V17;
	VALUES(0)=(V16);
	V17=1;
	unwind(frs_sch((V7)),Cnil,V17+1);}
	}
L1168:
	{object V16;                              /*  EOF-P           */
	if(((V3))==Cnil){
	goto L1180;}
	VALUES(0) = MAKE_FIXNUM(0);
	goto L1178;
L1180:
	VALUES(0) = (V2);
L1178:
	(*LK16)(5,(V1),(V14),MAKE_FIXNUM(0),MAKE_FIXNUM(32),VALUES(0))/*  BUFFER-INPUT*/;
	V16= VALUES(0);
	if(((V16))==Cnil){
	goto L1176;}
	if(!(((V16))==(VV[48]))){
	goto L1184;}
	if(((V3))==Cnil){
	goto L1188;}
	goto L1123;
L1188:
	{ int V17;
	VALUES(0)=VV[48];
	V17=1;
	unwind(frs_sch((V7)),Cnil,V17+1);}
L1184:
	((V1))->in.in_slots[10]= Ct;
	{ int V17;
	VALUES(0)=(V16);
	V17=1;
	unwind(frs_sch((V7)),Cnil,V17+1);}
	}
L1176:
	((V8))->in.in_slots[3]= MAKE_FIXNUM(32);
	V15= ((V14))->ust.ust_self[(V13)+(0)];
	if(!((V15)==(1))){
	goto L1175;}
	{object V16;                              /*  VALUE           */
	{int V17= (*(unsigned short *)(((V14))->ust.ust_self+((V13)+(2))));
	{int V18= (32)+(((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(4)))))*(4));
	{object V19;
	object V20;
	V19= (V8);
	V20= Cnil;
	V8= (V20);
	VALUES(0) = (V19);
	}
	L15(4,(V1),MAKE_FIXNUM(V17),MAKE_FIXNUM(V18),VALUES(0))/*  READ-REPLY-INPUT*/;
	V16= VALUES(0);}}
	if(((V16))==Cnil){
	goto L1203;}
	{ int V17;
	VALUES(0)=(V16);
	V17=1;
	unwind(frs_sch((V7)),Cnil,V17+1);}
L1203:
	goto L1122;
	}
L1175:
	if(!((V15)==0)){
	goto L1208;}
	{int V16= (*(unsigned short *)(((V14))->ust.ust_self+((V13)+(2))));
	{object V17;
	object V18;
	V17= (V8);
	V18= Cnil;
	V8= (V18);
	VALUES(0) = (V17);
	}
	L14(4,(V1),MAKE_FIXNUM(V16),VALUES(0),(V9))/*  READ-ERROR-INPUT*/;
	goto L1162;}
L1208:
	{int V17= ((V14))->ust.ust_self[(V13)+(0)];
	{object V18;
	object V19;
	V18= (V8);
	V19= Cnil;
	V8= (V19);
	VALUES(0) = (V18);
	}
	L16(3,(V1),MAKE_FIXNUM(V17),VALUES(0))    /*  READ-EVENT-INPUT*/;}
	}
	}
	}
L1162:
	goto L1122;
L1123:
	L17(2,(V1),(V9))                          /*  NOTE-INPUT-COMPLETE*/;
	(*LK19)(1,(V1))                           /*  DISPLAY-FORCE-OUTPUT*/;
	V3= Cnil;
	goto L1122;
	}
	frs_pop();
	MV_SAVE(V10);
	if(((V8))==Cnil){
	goto L1226;}
	L13(1,(V8))                               /*  DEALLOCATE-REPLY-BUFFER*/;
L1226:
	L17(2,(V1),(V9))                          /*  NOTE-INPUT-COMPLETE*/;
	MV_RESTORE(V10);
	if (unwinding) unwind(nlj_fr,nlj_tag,V10+1);
	else {
	V6=V10;}}
	}}
	frs_pop();
	RETURN(V6);
	}
	}
}
/*	function definition for REPORT-ASYNCHRONOUS-ERRORS            */
static L20(int narg, object V1, object V2)
{ VT29 VLEX29 CLSR29
TTL:
	if((((V1))->in.in_slots[63])==Cnil){
	goto L1230;}
	if((memql((V2),((V1))->in.in_slots[64]))==Cnil){
	goto L1230;}
	{volatile object V3;                      /*  ABORTED         */
	V3= Ct;
	{ int V4; volatile bool unwinding = FALSE;
	if ((V4=frs_push(FRS_PROTECT,Cnil))) {
	V4--; unwinding = TRUE;} else {
L1236:
	{register object V5;                      /*  ERROR           */
	{register object V6;
	V6= ((V1))->in.in_slots[63];
	if(((V6))==Cnil){
	goto L1240;}
	{register object V7;
	register object V8;
	object V9;
	object V10;
	object V11;
	V7= (V1);
	V8= (V6);
	V9= ((V7))->in.in_slots[63];
	V10= ((V8))->in.in_slots[2];
	V11= Cnil;
	((V7))->in.in_slots[63]= (V10);
	((V8))->in.in_slots[2]= (V11);
	}
L1240:
	V5= (V6);
	}
	if(((V5))==Cnil){
	goto L1251;}
	T0= (VV[764]->s.s_gfdef);
	{object V6;
	L144(3,(V1),(V5),Ct)                      /*  MAKE-ERROR      */;
	V6= VALUES(0);
	L2(1,(V5))                                /*  DEALLOCATE-EVENT*/;
	VALUES(0) = (V6);
	}
	Lapply(3,T0,(V1),VALUES(0))               /*  APPLY           */;
	goto L1237;
L1251:
	V3= Cnil;
	VALUES(0)=Cnil;
	V4=1;
	goto L1234;
	}
L1237:
	goto L1236;
L1234:
	}
	frs_pop();
	MV_SAVE(V4);
	if(((V3))==Cnil){
	goto L1259;}
L1263:
	{register object V5;                      /*  REPLY-BUFFER    */
	{register object V6;
	V6= ((V1))->in.in_slots[63];
	if(((V6))==Cnil){
	goto L1267;}
	{register object V7;
	register object V8;
	object V9;
	object V10;
	object V11;
	V7= (V1);
	V8= (V6);
	V9= ((V7))->in.in_slots[63];
	V10= ((V8))->in.in_slots[2];
	V11= Cnil;
	((V7))->in.in_slots[63]= (V10);
	((V8))->in.in_slots[2]= (V11);
	}
L1267:
	V5= (V6);
	}
	if(((V5))==Cnil){
	goto L1278;}
	L2(1,(V5))                                /*  DEALLOCATE-EVENT*/;
	goto L1264;
L1278:
	goto L1259;
	}
L1264:
	goto L1263;
L1259:
	MV_RESTORE(V4);
	if (unwinding) unwind(nlj_fr,nlj_tag,V4+1);
	else {
	RETURN(V4);}}
	}
L1230:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WAIT-FOR-EVENT                        */
static L21(int narg, object V1, object V2, object V3)
{ VT30 VLEX30 CLSR30
TTL:
	{volatile object V4;                      /*  EVENT-PROCESS-P */
	V4= (((eql((V2),MAKE_FIXNUM(0))?Ct:Cnil))==Cnil?Ct:Cnil);
	{ int V5; volatile bool unwinding = FALSE;
	if ((V5=frs_push(FRS_PROTECT,Cnil))) {
	V5--; unwinding = TRUE;} else {
L1284:
	if(((V4))==Cnil){
	goto L1286;}
	if(!((((V1))->in.in_slots[65])==(Cnil))){
	goto L1286;}
	(*LK11)(0)                                /*  CURRENT-PROCESS */;
	((V1))->in.in_slots[65]= VALUES(0);
L1286:
	{register object V6;                      /*  EOF             */
	VALUES(0) = VV[661];
	L18(5,(V1),(V2),(V3),VALUES(0),(V1))      /*  READ-INPUT      */;
	V6= VALUES(0);
	if(((V6))==Cnil){
	goto L1293;}
	VALUES(0)=(V6);
	V5=1;
	goto L1282;
	}
L1293:
	if(((V4))==Cnil){
	goto L1298;}
	L20(2,(V1),VV[50])                        /*  REPORT-ASYNCHRONOUS-ERRORS*/;
L1298:
	if((((V1))->in.in_slots[66])==Cnil){
	goto L1285;}
	VALUES(0)=Cnil;
	V5=1;
	goto L1282;
L1285:
	goto L1284;
L1282:
	}
	frs_pop();
	MV_SAVE(V5);
	if(((V4))==Cnil){
	goto L1304;}
	T0= ((V1))->in.in_slots[65];
	(*LK11)(0)                                /*  CURRENT-PROCESS */;
	if(!((T0)==(VALUES(0)))){
	goto L1304;}
	((V1))->in.in_slots[65]= Cnil;
L1304:
	MV_RESTORE(V5);
	if (unwinding) unwind(nlj_fr,nlj_tag,V5+1);
	else {
	RETURN(V5);}}
	}
}
/*	function definition for READ-REPLY                            */
static L23(int narg, object V1, object V2)
{ VT31 VLEX31 CLSR31
TTL:
L1312:
	VALUES(0) = VV[663];
	L18(5,(V1),Cnil,Cnil,VALUES(0),(V2))      /*  READ-INPUT      */;
	if(VALUES(0)==Cnil){
	goto L1314;}
	(*LK6)(3,VV[47],VV[30],(V1))              /*  X-ERROR         */;
L1314:
	{register object V3;                      /*  REPLY-BUFFER    */
	{register object V4;
	V4= ((V2))->in.in_slots[1];
	if(((V4))==Cnil){
	goto L1320;}
	{register object V5;
	register object V6;
	object V7;
	object V8;
	object V9;
	V5= (V2);
	V6= (V4);
	V7= ((V5))->in.in_slots[1];
	V8= ((V6))->in.in_slots[2];
	V9= Cnil;
	((V5))->in.in_slots[1]= (V8);
	((V6))->in.in_slots[2]= (V9);
	}
L1320:
	V3= (V4);
	}
	{object V4;                               /*  %REPLY-BUFFER   */
	V4= (V3);
	{register int V5;                         /*  BUFFER-BOFFSET  */
	register object V6;                       /*  BUFFER-BBUF     */
	V5= 0;
	V6= ((V4))->in.in_slots[1];
	{object V7= MAKE_FIXNUM(((V6))->ust.ust_self[(V5)+(0)]);
	if(!eql(V7,VV[51]))goto L1334;
	T0= (VV[764]->s.s_gfdef);
	{object V8;
	L144(3,(V1),(V3),Cnil)                    /*  MAKE-ERROR      */;
	V8= VALUES(0);
	L13(1,(V3))                               /*  DEALLOCATE-REPLY-BUFFER*/;
	VALUES(0) = (V8);
	}
	Lapply(3,T0,(V1),VALUES(0))               /*  APPLY           */;
	goto L1313;
L1334:
	if(!eql(V7,VV[52]))goto L1339;
	VALUES(0) = (V3);
	RETURN(1);
L1339:
	FEerror("The ECASE key value ~s is illegal.",1,V7);}
	}
	}
	}
L1313:
	goto L1312;
}
/*	function definition for EVENT-LISTEN                          */
static L25(int narg, object V1, ...)
{ VT32 VLEX32 CLSR32
	{int i=1;
	volatile object V2;
	va_list args; va_start(args, V1);
	if (i==narg) goto L1341;
	V2= va_arg(args, object);
	i++;
	goto L1342;
L1341:
	V2= MAKE_FIXNUM(0);
L1342:
	{volatile object V3;                      /*  CURRENT-EVENT-SYMBOL*/
	volatile object V4;                       /*  CURRENT-EVENT   */
	volatile object V5;                       /*  QUEUE           */
	V3= CAR(((V1))->in.in_slots[67]);
	if(((V3))->s.s_dbind!=OBJNULL){
	goto L1346;}
	V4= Cnil;
	goto L1345;
L1346:
	Lsymbol_value(1,(V3))                     /*  SYMBOL-VALUE    */;
	V4= VALUES(0);
L1345:
	if(((V4))==Cnil){
	goto L1350;}
	V5= ((V4))->in.in_slots[2];
	goto L1348;
L1350:
	V5= ((V1))->in.in_slots[24];
L1348:
	if(((V5))==Cnil){
	goto L1353;}
	{volatile object V6;
	volatile int V7;
	V7= 0;
	V6= (V5);
L1358:
	if(((V6))!=Cnil){
	goto L1359;}
	VALUES(0) = MAKE_FIXNUM(V7);
	goto L1355;
L1359:
	V6= ((V6))->in.in_slots[2];
	V7= (V7)+1;
	goto L1358;
	}
L1355:
	VALUES(1) = Cnil;
	VALUES(0) = VALUES(0);
	RETURN(2);
L1353:
	{volatile object V6;                      /*  EOF-OR-TIMEOUT  */
	L21(3,(V1),(V2),Cnil)                     /*  WAIT-FOR-EVENT  */;
	V6= VALUES(0);
	if(((V6))==Cnil){
	goto L1368;}
	VALUES(1) = (V6);
	VALUES(0) = Cnil;
	RETURN(2);
L1368:
	{volatile object V7;
	volatile int V8;
	V7= ((V1))->in.in_slots[66];
	V8= 0;
L1374:
	if(((V7))!=Cnil){
	goto L1375;}
	VALUES(0) = MAKE_FIXNUM(V8);
	goto L1370;
L1375:
	V7= ((V7))->in.in_slots[2];
	V8= (V8)+1;
	goto L1374;
	}
L1370:
	VALUES(1) = Cnil;
	VALUES(0) = VALUES(0);
	RETURN(2);
	}
	}
	}
}
/*	function definition for QUEUE-EVENT                           */
static L26(int narg, object V1, object V2, ...)
{ VT33 VLEX33 CLSR33
	{object V3;
	object V4;
	object V5;
	va_list args; va_start(args, V2);
	narg -=2;
	V3=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ int n=narg; object p=V3;
	 for(;n-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{ object keyvars[4];
	va_start(args,V2);
	parse_key(narg,args,2,L26keys,keyvars,V3,TRUE);
	V4= keyvars[0];
	V5= keyvars[1];
	}
	if((getf((V2)->s.s_plist,VV[23],Cnil))!=Cnil){
	goto L1382;}
	(*LK3)(2,(V2),VV[24])                     /*  X-TYPE-ERROR    */;
L1382:
	{register object V6;                      /*  EVENT           */
	register object V7;                       /*  BUFFER          */
	register int V8;                          /*  EVENT-CODE      */
	L1(0)                                     /*  ALLOCATE-EVENT  */;
	V6= VALUES(0);
	V7= ((V6))->in.in_slots[1];
	V8= fix(getf((V2)->s.s_plist,VV[23],Cnil));
	if((MAKE_FIXNUM(V8))!=Cnil){
	goto L1388;}
	(*LK3)(2,(V2),VV[24])                     /*  X-TYPE-ERROR    */;
L1388:
	((V6))->in.in_slots[0]= MAKE_FIXNUM(V8);
	if((((V1))->in.in_slots[10])==Cnil){
	goto L1393;}
	(*LK6)(3,VV[47],VV[30],(V1))              /*  X-ERROR         */;
L1393:
	Lapply(3,((VV[10]->s.s_dbind))->v.v_self[V8],(V1),(V3))/*  APPLY*/;
	(*LK15)(5,(V7),((V1))->in.in_slots[7],MAKE_FIXNUM(0),MAKE_FIXNUM(32),MAKE_FIXNUM((12)+(fix(((V1))->in.in_slots[6]))))/*  BUFFER-REPLACE*/;
	if(((V5))==Cnil){
	goto L1401;}
	Llogior(2,MAKE_FIXNUM(V8),MAKE_FIXNUM(128))/*  LOGIOR         */;
	goto L1399;
L1401:
	VALUES(0) = MAKE_FIXNUM(V8);
L1399:
	((V7))->ust.ust_self[fix(MAKE_FIXNUM(0))]= char_code(VALUES(0));
	aset1((V7),2,MAKE_FIXNUM(0));
	aset1((V7),3,MAKE_FIXNUM(0));
	if(((V4))==Cnil){
	goto L1405;}
	RETURN(L27(2,(V6),(V1))                   /*  ENQUEUE-EVENT   */);
L1405:
	{register object V9;
	V9= (V6);
	if((((V1))->in.in_slots[23])!=Cnil){
	goto L1409;}
	((V1))->in.in_slots[24]= (V9);
	VALUES(0) = (V9);
	((V1))->in.in_slots[23]= VALUES(0);
	goto L1407;
L1409:
	{object V10;
	object V11;
	V10= ((V9))->in.in_slots[2];
	V11= ((V1))->in.in_slots[24];
	((V9))->in.in_slots[2]= (V11);
	((V1))->in.in_slots[24]= (V9);
	}
L1407:
	VALUES(0) = (V9);
	RETURN(1);
	}
	}
	}
}
/*	function definition for ENQUEUE-EVENT                         */
static L27(int narg, object V1, object V2)
{ VT34 VLEX34 CLSR34
TTL:
	{volatile int V3;                         /*  EVENT-CODE      */
	volatile object V4;                       /*  EVENT-KEY       */
	V3= fix(((V1))->in.in_slots[0]);
	if((V3)<(((VV[4]->s.s_dbind))->v.v_fillp)){
	goto L1418;}
	V4= Cnil;
	goto L1417;
L1418:
	V4= ((VV[4]->s.s_dbind))->v.v_self[V3];
L1417:
	if(((V4))!=Cnil){
	goto L1421;}
	{ int V5; volatile bool unwinding = FALSE;
	if ((V5=frs_push(FRS_PROTECT,Cnil))) {
	V5--; unwinding = TRUE;} else {
	V5=Lcerror(3,VV[53],VV[54],(V4))          /*  CERROR          */;
	}
	frs_pop();
	MV_SAVE(V5);
	L2(1,(V1))                                /*  DEALLOCATE-EVENT*/;
	MV_RESTORE(V5);
	if (unwinding) unwind(nlj_fr,nlj_tag,V5+1);
	else {
	RETURN(V5);}}
L1421:
	{volatile object V6;
	V6= (V1);
	if((((V2))->in.in_slots[23])!=Cnil){
	goto L1428;}
	{volatile object V7;
	volatile object V8;
	V8= ((V2))->in.in_slots[24];
	V7= (V6);
	if(((V8))!=Cnil){
	goto L1432;}
	((V2))->in.in_slots[24]= (V7);
	goto L1426;
L1432:
	{volatile object V9;
	volatile object V10;
	V9= (V8);
	V10= ((V9))->in.in_slots[2];
L1437:
	if(((V10))!=Cnil){
	goto L1438;}
	((V9))->in.in_slots[2]= (V7);
	goto L1426;
L1438:
	V9= (V10);
	V10= ((V9))->in.in_slots[2];
	goto L1437;
	}
	}
L1428:
	{volatile object V12;
	volatile object V13;
	V13= (((V2))->in.in_slots[23])->in.in_slots[2];
	V12= (V6);
	if(((V13))!=Cnil){
	goto L1449;}
	(((V2))->in.in_slots[23])->in.in_slots[2]= (V12);
	goto L1426;
L1449:
	{volatile object V14;
	volatile object V15;
	V14= (V13);
	V15= ((V14))->in.in_slots[2];
L1454:
	if(((V15))!=Cnil){
	goto L1455;}
	((V14))->in.in_slots[2]= (V12);
	goto L1426;
L1455:
	V14= (V15);
	V15= ((V14))->in.in_slots[2];
	goto L1454;
	}
	}
L1426:
	((V2))->in.in_slots[23]= (V6);
	}
	if((((V2))->in.in_slots[66])!=Cnil){
	goto L1465;}
	((V2))->in.in_slots[66]= (V1);
	VALUES(0) = (V1);
	RETURN(1);
L1465:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	macro definition for DEFINE-EVENT                             */
static L28(int narg, object V1, object V2)
{ VT35 VLEX35 CLSR35
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	{object V6= list(3,VV[57],VV[4],list(3,VV[58],VV[41],(V5)));
	{object V7= list(3,VV[56],(V6),list(2,VV[20],(V4)));
	VALUES(0) = list(4,VV[15],VV[55],(V7),list(3,VV[56],list(3,VV[59],list(2,VV[20],(V4)),VV[60]),(V5)));
	RETURN(1);}}}
}
/*	macro definition for DECLARE-EVENT                            */
static L29(int narg, object V1, object V2)
{ VT36 VLEX36 CLSR36
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= V3;
	if(!(type_of((V4))!=t_cons)){
	goto L1467;}
	V4= CONS((V4),Cnil);
L1467:
	{object V6;
	object V7= (V4);
	if(V7==Cnil){
	V4= Cnil;
	goto L1472;}
	T0=V6=CONS(Cnil,Cnil);
L1473:
	L4(1,CAR(V7))                             /*  CANONICALIZE-EVENT-NAME*/;
	CAR(V6)= VALUES(0);
	if((V7=CDR(V7))==Cnil){
	V4= T0;
	goto L1472;}
	V6=CDR(V6)=CONS(Cnil,Cnil);
	goto L1473;}
L1472:
	{register object V6;                      /*  NAME            */
	object V7;                                /*  GET-MACRO       */
	object V8;                                /*  GET-FUNCTION    */
	object V9;                                /*  PUT-FUNCTION    */
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  KEYWORDS        */
	V6= CAR((V4));
	(*LK20)(2,(V6),VV[94])                    /*  XINTERN         */;
	V7= VALUES(0);
	(*LK20)(2,(V6),VV[95])                    /*  XINTERN         */;
	V8= VALUES(0);
	(*LK20)(2,(V6),VV[96])                    /*  XINTERN         */;
	V9= VALUES(0);
	{ int V10;
	object V11;                               /*  GET-CODE        */
	object V12;                               /*  GET-INDEX       */
	object V13;                               /*  GET-SIZES       */
	VALUES(0) = VV[669];
	V10=(*LK21)(4,MAKE_FIXNUM(2),(V5),Cnil,VALUES(0))/*  GET-PUT-ITEMS*/;
	if (V10--==0) goto L1481;
	V11= VALUES(0);
	if (V10--==0) goto L1482;
	V12= VALUES(1);
	if (V10--==0) goto L1483;
	V13= VALUES(2);
	goto L1484;
L1481:
	V11= Cnil;
L1482:
	V12= Cnil;
L1483:
	V13= Cnil;
L1484:
	{ int V14;
	object V15;                               /*  PUT-CODE        */
	object V16;                               /*  PUT-INDEX       */
	object V17;                               /*  PUT-SIZES       */
	VALUES(0) = make_cclosure(LC34,env0,&Cblock);
	V14=(*LK21)(4,MAKE_FIXNUM(2),(V5),Ct,VALUES(0))/*  GET-PUT-ITEMS*/;
	if (V14--==0) goto L1487;
	V15= VALUES(0);
	if (V14--==0) goto L1488;
	V16= VALUES(1);
	if (V14--==0) goto L1489;
	V17= VALUES(2);
	goto L1490;
L1487:
	V15= Cnil;
L1488:
	V16= Cnil;
L1489:
	V17= Cnil;
L1490:
	{object V18= list(2,(V6),VV[101]);
	{object V19;
	object V20= (V11);
	if(V20==Cnil){
	VALUES(0) = Cnil;
	goto L1491;}
	T0=V19=CONS(Cnil,Cnil);
L1492:
	Lmacroexpand(1,CAR(V20))                  /*  MACROEXPAND     */;
	CAR(V19)= VALUES(0);
	if((V20=CDR(V20))==Cnil){
	VALUES(0) = T0;
	goto L1491;}
	V19=CDR(V19)=CONS(Cnil,Cnil);
	goto L1492;}
L1491:
	{object V19= list(4,VV[102],(V7),VV[103],list(4,VV[104],VV[26],VV[105],list(3,VV[106],list(10,VV[107],VV[30],VV[108],VV[109],VV[110],VV[29],VV[111],VV[112],VV[113],list(2,VV[20],VALUES(0))),VV[114])));
	{object V20= list(5,VV[119],VV[30],VV[26],VV[120],listA(3,MAKE_FIXNUM(8),MAKE_FIXNUM(16),(V13)));
	LlistA(11,VV[121],VV[122],VV[30],VV[26],VV[109],VV[123],VV[29],VV[124],VV[112],VV[125],(V11))/*  LIST**/;
	{object V21= list(6,VV[102],(V8),VV[115],VV[116],VV[117],list(3,VV[118],(V20),VALUES(0)));
	*CLV0= nreverse(*CLV0);
	{object V22= listA(3,VV[26],VV[126],append(*CLV0,VV[127]));
	if((memql(VV[129],*CLV0))==Cnil){
	goto L1498;}
	T0= VV[130];
	goto L1496;
L1498:
	T0= Cnil;
L1496:
	{object V23= list(6,VV[102],(V9),(V22),VV[128],T0,listA(3,VV[131],listA(4,VV[26],VV[120],(V17),VV[132]),(V15)));
	{object V24;
	object V25= (V4);
	if(V25==Cnil){
	T1= Cnil;
	goto L1500;}
	T2=V24=CONS(Cnil,Cnil);
L1501:
	{object V26;                              /*  NAME            */
	V26= CAR(V25);
	L5(1,(V26))                               /*  ALLOCATE-EXTENSION-EVENT-CODE*/;
	{object V27= list(3,VV[59],list(2,VV[20],(V26)),VV[134]);
	{object V28= CONS(list(2,VV[23],list(3,VV[33],(V27),list(2,VV[135],list(2,VV[20],(V26))))),Cnil);
	{object V29= list(3,VV[56],VV[137],list(2,VV[138],(V7)));
	{object V30= list(3,VV[56],VV[139],list(2,VV[138],(V8)));
	CAR(V24)= list(6,VV[133],(V28),VV[136],(V29),(V30),list(3,VV[56],VV[140],list(2,VV[138],(V9))));}}}}
	}
	if((V25=CDR(V25))==Cnil){
	T1= T2;
	goto L1500;}
	V24=CDR(V24)=CONS(Cnil,Cnil);
	goto L1501;}
L1500:
	VALUES(0) = listA(6,VV[100],(V18),(V19),(V21),(V23),append(T1,CONS(list(2,VV[20],(V6)),Cnil)));
	RETURN(1);}}}}}}}}
	}}
}
/*	closure CLOSURE                                               */
static LC34(int narg, object env0, object V1, object V2, object V3, object V4)
{ VT37 VLEX37 CLSR37
	narg--;
	{object scan=env0;
	CLV0= &CAR(scan);                         /*  KEYWORDS        */}
	if((memql((V1),VV[98]))!=Cnil){
	goto L1505;}
	if(!(type_of((V3))!=t_cons)){
	goto L1508;}
	*CLV0= CONS((V3),*CLV0);
	(*LK22)(1,(V1))                           /*  PUTIFY          */;
	VALUES(0) = CONS(listA(4,VALUES(0),(V2),(V3),(V4)),Cnil);
	RETURN(1);
L1508:
	{object V5;                               /*  NAMES           */
	{object V6;
	object V7= (V3);
	if(V7==Cnil){
	V5= Cnil;
	goto L1513;}
	T0=V6=CONS(Cnil,Cnil);
L1514:
	{object V8;                               /*  NAME            */
	(*LK0)(1,CAR(V7))                         /*  KINTERN         */;
	CAR(V6)= VALUES(0);
	}
	if((V7=CDR(V7))==Cnil){
	V5= T0;
	goto L1513;}
	V6=CDR(V6)=CONS(Cnil,Cnil);
	goto L1514;}
L1513:
	*CLV0= append((V3),*CLV0);
	(*LK22)(1,(V1))                           /*  PUTIFY          */;
	T0= VALUES(0);
	VALUES(0) = CONS(listA(4,T0,(V2),listA(3,VV[99],list(2,VV[20],(V5)),(V3)),(V4)),Cnil);
	RETURN(1);
	}
L1505:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for CHECK-CONSISTENCY                     */
static L36(int narg, object V1, ...)
{ VT38 VLEX38 CLSR38
	{volatile object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	V2=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object p=V2;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{volatile object V3;                      /*  VALUE           */
	V3= CAR((V2));
	{volatile object V4;
	volatile object V5;                       /*  ARG             */
	V4= CDR((V2));
	V5= Cnil;
L1524:
	if(!((V4)==Cnil)){
	goto L1525;}
	goto L1520;
L1525:
	V5= CAR((V4));
	if(((V3))==Cnil){
	goto L1532;}
	if(((V5))==Cnil){
	goto L1530;}
	if(((V5))==((V3))){
	goto L1530;}
	{object V7;
	object V8= (V1);
	object V9= (V2);
	if(V8==Cnil||V9==Cnil){
	VALUES(0) = Cnil;
	goto L1538;}
	T0=V7=CONS(Cnil,Cnil);
L1539:
	CDR(V7)= list(2,CAR(V8),CAR(V9));
	while(CDR(V7)!=Cnil)V7=CDR(V7);
	if((V8=CDR(V8))==Cnil||(V9=CDR(V9))==Cnil){
	T0=CDR(T0);
	VALUES(0) = T0;
	goto L1538;}
	goto L1539;}
L1538:
	(*LK6)(3,VV[141],VV[142],VALUES(0))       /*  X-ERROR         */;
	goto L1530;
L1532:
	V3= (V5);
L1530:
	V4= CDR((V4));
	goto L1524;
	}
L1520:
	VALUES(0) = (V3);
	RETURN(1);
	}
	}
}
/*	function definition for KEY-PRESS-EVENT-GET-MACRO             */
static L37(int narg, object V1, object V2, object V3)
{ VT39 VLEX39 CLSR39
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[147]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for KEY-PRESS-EVENT-GET                   */
static L38(int narg, object V1, object V2, object V3)
{ VT40 VLEX40 CLSR40
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	register object V5;                       /*  %BUFFER         */
	V5= (V1);
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{int V11= ((V7))->ust.ust_self[(V6)+(1)];
	{int V12= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	{int V13;
	V13= (*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4))));
	if(!((V13)==0)){
	goto L1554;}
	T0= Cnil;
	goto L1551;
L1554:
	{int V14;
	V14= (*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4))));
	if((MAKE_FIXNUM(V14))==Cnil){
	goto L1558;}
	T0= MAKE_FIXNUM(V14);
	goto L1551;
L1558:
	T0= Cnil;
	}
	}
L1551:
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(8)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T1= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(12)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T2= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(12)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T3= VALUES(0);
	{int V13;
	V13= (*(unsigned long *)(((V7))->ust.ust_self+((V6)+(16))));
	if(!((V13)==0)){
	goto L1566;}
	T4= Cnil;
	goto L1563;
L1566:
	{object V14;
	(*LK23)(2,(V5),MAKE_FIXNUM(V13))          /*  LOOKUP-WINDOW   */;
	V14= VALUES(0);
	if(((V14))==Cnil){
	goto L1570;}
	T4= (V14);
	goto L1563;
L1570:
	T4= Cnil;
	}
	}
L1563:
	{int V13= (*(short *)(((V7))->st.st_self+((V6)+(20))));
	{int V14= (*(short *)(((V7))->st.st_self+((V6)+(22))));
	{int V15= (*(short *)(((V7))->st.st_self+((V6)+(24))));
	{int V16= (*(short *)(((V7))->st.st_self+((V6)+(26))));
	{int V17= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(28))));
	RETURN(funcall(35,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[148],MAKE_FIXNUM(V11),VV[149],MAKE_FIXNUM(V12),VV[150],T0,VV[151],T1,VV[152],T2,VV[153],T3,VV[154],T4,VV[155],MAKE_FIXNUM(V13),VV[156],MAKE_FIXNUM(V14),VV[157],MAKE_FIXNUM(V15),VV[158],MAKE_FIXNUM(V16),VV[159],MAKE_FIXNUM(V17),VV[160],((((V7))->ust.ust_self[(V6)+(30)])>0?Ct:Cnil)));}}}}}}}}}}
	}
	}
}
/*	function definition for KEY-PRESS-EVENT-PUT                   */
static L39(int narg, object V1, ...)
{ VT41 VLEX41 CLSR41
	{object V2;
	object V3;
	register object V4;
	object V5;
	object V6;
	object V7;
	register object V8;
	object V9;
	object V10;
	object V11;
	object V12;
	object V13;
	object V14;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[26];
	parse_key(narg,args,13,L39keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	V7= keyvars[5];
	V8= keyvars[6];
	V9= keyvars[7];
	V10= keyvars[8];
	V11= keyvars[9];
	V12= keyvars[10];
	V13= keyvars[11];
	V14= keyvars[12];
	}
	if(((V3))!=Cnil){
	goto L1572;}
	V3= ((V1))->in.in_slots[3];
L1572:
	{object V15;                              /*  %BUFFER         */
	{register int V16;                        /*  BUFFER-BOFFSET  */
	register object V17;                      /*  BUFFER-BBUF     */
	V16= (fix(((V1))->in.in_slots[6]))+(12);
	V17= ((V1))->in.in_slots[7];
	(((V17))->ust.ust_self[(V16)+(1)]=(fix((V2))));
	((*(unsigned short *)(((V17))->ust.ust_self+((V16)+(2))))=fix((V3)));
	if(!((V4)==Cnil)){
	goto L1585;}
	((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(4))))=0);
	goto L1583;
L1585:
	(*LK24)(2,(V4),VV[161])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1588;}
	((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(4))))=fix((V4)));
	goto L1583;
L1588:
	(*LK3)(2,(V4),VV[162])                    /*  X-TYPE-ERROR    */;
L1583:
	((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(8))))=fix(((V5))->in.in_slots[0]));
	L36(3,VV[164],(V7),(V6))                  /*  CHECK-CONSISTENCY*/;
	((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(12))))=fix((VALUES(0))->in.in_slots[0]));
	if(!((V8)==Cnil)){
	goto L1595;}
	((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(16))))=0);
	goto L1593;
L1595:
	(*LK25)(1,(V8))                           /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L1598;}
	((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(16))))=fix(((V8))->in.in_slots[0]));
	goto L1593;
L1598:
	(*LK3)(2,(V8),VV[165])                    /*  X-TYPE-ERROR    */;
L1593:
	((*(short *)(((V17))->st.st_self+((V16)+(20))))=fix((V9)));
	((*(short *)(((V17))->st.st_self+((V16)+(22))))=fix((V10)));
	((*(short *)(((V17))->st.st_self+((V16)+(24))))=fix((V11)));
	((*(short *)(((V17))->st.st_self+((V16)+(26))))=fix((V12)));
	((*(unsigned short *)(((V17))->ust.ust_self+((V16)+(28))))=fix((V13)));
	if(((V14))==Cnil){
	goto L1607;}
	T0= MAKE_FIXNUM(1);
	goto L1605;
L1607:
	T0= MAKE_FIXNUM(0);
L1605:
	VALUES(0) = MAKE_FIXNUM((((V17))->ust.ust_self[(V16)+(30)]=(fix(T0))));
	RETURN(1);
	}
	}
	}
}
/*	function definition for MOTION-NOTIFY-EVENT-GET-MACRO         */
static L40(int narg, object V1, object V2, object V3)
{ VT42 VLEX42 CLSR42
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[166]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for MOTION-NOTIFY-EVENT-GET               */
static L41(int narg, object V1, object V2, object V3)
{ VT43 VLEX43 CLSR43
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	register object V5;                       /*  %BUFFER         */
	V5= (V1);
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{object V11= ((((V7))->ust.ust_self[(V6)+(1)])>0?Ct:Cnil);
	{int V12= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	{int V13;
	V13= (*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4))));
	if(!((V13)==0)){
	goto L1618;}
	T0= Cnil;
	goto L1615;
L1618:
	{int V14;
	V14= (*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4))));
	if((MAKE_FIXNUM(V14))==Cnil){
	goto L1622;}
	T0= MAKE_FIXNUM(V14);
	goto L1615;
L1622:
	T0= Cnil;
	}
	}
L1615:
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(8)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T1= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(12)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T2= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(12)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T3= VALUES(0);
	{int V13;
	V13= (*(unsigned long *)(((V7))->ust.ust_self+((V6)+(16))));
	if(!((V13)==0)){
	goto L1630;}
	T4= Cnil;
	goto L1627;
L1630:
	{object V14;
	(*LK23)(2,(V5),MAKE_FIXNUM(V13))          /*  LOOKUP-WINDOW   */;
	V14= VALUES(0);
	if(((V14))==Cnil){
	goto L1634;}
	T4= (V14);
	goto L1627;
L1634:
	T4= Cnil;
	}
	}
L1627:
	{int V13= (*(short *)(((V7))->st.st_self+((V6)+(20))));
	{int V14= (*(short *)(((V7))->st.st_self+((V6)+(22))));
	{int V15= (*(short *)(((V7))->st.st_self+((V6)+(24))));
	{int V16= (*(short *)(((V7))->st.st_self+((V6)+(26))));
	{int V17= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(28))));
	RETURN(funcall(35,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[167],(V11),VV[149],MAKE_FIXNUM(V12),VV[150],T0,VV[151],T1,VV[152],T2,VV[153],T3,VV[154],T4,VV[155],MAKE_FIXNUM(V13),VV[156],MAKE_FIXNUM(V14),VV[157],MAKE_FIXNUM(V15),VV[158],MAKE_FIXNUM(V16),VV[159],MAKE_FIXNUM(V17),VV[160],((((V7))->ust.ust_self[(V6)+(30)])>0?Ct:Cnil)));}}}}}}}}}}
	}
	}
}
/*	function definition for MOTION-NOTIFY-EVENT-PUT               */
static L42(int narg, object V1, ...)
{ VT44 VLEX44 CLSR44
	{object V2;
	object V3;
	register object V4;
	object V5;
	object V6;
	object V7;
	register object V8;
	object V9;
	object V10;
	object V11;
	object V12;
	object V13;
	object V14;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[26];
	parse_key(narg,args,13,L42keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	V7= keyvars[5];
	V8= keyvars[6];
	V9= keyvars[7];
	V10= keyvars[8];
	V11= keyvars[9];
	V12= keyvars[10];
	V13= keyvars[11];
	V14= keyvars[12];
	}
	if(((V3))!=Cnil){
	goto L1636;}
	V3= ((V1))->in.in_slots[3];
L1636:
	{object V15;                              /*  %BUFFER         */
	{register int V16;                        /*  BUFFER-BOFFSET  */
	register object V17;                      /*  BUFFER-BBUF     */
	V16= (fix(((V1))->in.in_slots[6]))+(12);
	V17= ((V1))->in.in_slots[7];
	if(((V2))==Cnil){
	goto L1648;}
	T0= MAKE_FIXNUM(1);
	goto L1646;
L1648:
	T0= MAKE_FIXNUM(0);
L1646:
	(((V17))->ust.ust_self[(V16)+(1)]=(fix(T0)));
	((*(unsigned short *)(((V17))->ust.ust_self+((V16)+(2))))=fix((V3)));
	if(!((V4)==Cnil)){
	goto L1653;}
	((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(4))))=0);
	goto L1651;
L1653:
	(*LK24)(2,(V4),VV[161])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1656;}
	((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(4))))=fix((V4)));
	goto L1651;
L1656:
	(*LK3)(2,(V4),VV[168])                    /*  X-TYPE-ERROR    */;
L1651:
	((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(8))))=fix(((V5))->in.in_slots[0]));
	L36(3,VV[169],(V7),(V6))                  /*  CHECK-CONSISTENCY*/;
	((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(12))))=fix((VALUES(0))->in.in_slots[0]));
	if(!((V8)==Cnil)){
	goto L1663;}
	((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(16))))=0);
	goto L1661;
L1663:
	(*LK25)(1,(V8))                           /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L1666;}
	((*(unsigned long *)(((V17))->ust.ust_self+((V16)+(16))))=fix(((V8))->in.in_slots[0]));
	goto L1661;
L1666:
	(*LK3)(2,(V8),VV[170])                    /*  X-TYPE-ERROR    */;
L1661:
	((*(short *)(((V17))->st.st_self+((V16)+(20))))=fix((V9)));
	((*(short *)(((V17))->st.st_self+((V16)+(22))))=fix((V10)));
	((*(short *)(((V17))->st.st_self+((V16)+(24))))=fix((V11)));
	((*(short *)(((V17))->st.st_self+((V16)+(26))))=fix((V12)));
	((*(unsigned short *)(((V17))->ust.ust_self+((V16)+(28))))=fix((V13)));
	if(((V14))==Cnil){
	goto L1675;}
	T0= MAKE_FIXNUM(1);
	goto L1673;
L1675:
	T0= MAKE_FIXNUM(0);
L1673:
	VALUES(0) = MAKE_FIXNUM((((V17))->ust.ust_self[(V16)+(30)]=(fix(T0))));
	RETURN(1);
	}
	}
	}
}
/*	function definition for ENTER-NOTIFY-EVENT-GET-MACRO          */
static L43(int narg, object V1, object V2, object V3)
{ VT45 VLEX45 CLSR45
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[171]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for ENTER-NOTIFY-EVENT-GET                */
static L44(int narg, object V1, object V2, object V3)
{ VT46 VLEX46 CLSR46
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	register object V5;                       /*  %BUFFER         */
	V5= (V1);
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{int V11;
	V11= ((V7))->ust.ust_self[(V6)+(1)];
	if((V11)<(5)){
	goto L1685;}
	T0= Cnil;
	goto L1683;
L1685:
	T0= (VV[173])->v.v_self[V11];
	}
L1683:
	{int V11= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	{int V12;
	V12= (*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4))));
	if(!((V12)==0)){
	goto L1690;}
	T1= Cnil;
	goto L1687;
L1690:
	{int V13;
	V13= (*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4))));
	if((MAKE_FIXNUM(V13))==Cnil){
	goto L1694;}
	T1= MAKE_FIXNUM(V13);
	goto L1687;
L1694:
	T1= Cnil;
	}
	}
L1687:
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(8)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T2= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(12)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T3= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(12)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T4= VALUES(0);
	{int V12;
	V12= (*(unsigned long *)(((V7))->ust.ust_self+((V6)+(16))));
	if(!((V12)==0)){
	goto L1702;}
	T5= Cnil;
	goto L1699;
L1702:
	{object V13;
	(*LK23)(2,(V5),MAKE_FIXNUM(V12))          /*  LOOKUP-WINDOW   */;
	V13= VALUES(0);
	if(((V13))==Cnil){
	goto L1706;}
	T5= (V13);
	goto L1699;
L1706:
	T5= Cnil;
	}
	}
L1699:
	{int V12= (*(short *)(((V7))->st.st_self+((V6)+(20))));
	{int V13= (*(short *)(((V7))->st.st_self+((V6)+(22))));
	{int V14= (*(short *)(((V7))->st.st_self+((V6)+(24))));
	{int V15= (*(short *)(((V7))->st.st_self+((V6)+(26))));
	{int V16= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(28))));
	{int V17;
	V17= ((V7))->ust.ust_self[(V6)+(30)];
	if((V17)<(3)){
	goto L1710;}
	T6= Cnil;
	goto L1708;
L1710:
	T6= (VV[175])->v.v_self[V17];
	}
L1708:
	{object V17= ((((V7))->ust.ust_self[(V6)+(31)] >> 0) & 1?Ct:Cnil);
	RETURN(funcall(39,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[172],T0,VV[149],MAKE_FIXNUM(V11),VV[150],T1,VV[151],T2,VV[152],T3,VV[153],T4,VV[154],T5,VV[155],MAKE_FIXNUM(V12),VV[156],MAKE_FIXNUM(V13),VV[157],MAKE_FIXNUM(V14),VV[158],MAKE_FIXNUM(V15),VV[159],MAKE_FIXNUM(V16),VV[174],T6,VV[176],(V17),VV[160],((((V7))->ust.ust_self[(V6)+(31)] >> 1) & 1?Ct:Cnil)));}}}}}}}}}}
	}
	}
}
/*	function definition for ENTER-NOTIFY-EVENT-PUT                */
static L45(int narg, object V1, ...)
{ VT47 VLEX47 CLSR47
	{object V2;
	object V3;
	register object V4;
	object V5;
	object V6;
	object V7;
	register object V8;
	object V9;
	object V10;
	object V11;
	object V12;
	object V13;
	object V14;
	object V15;
	object V16;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[30];
	parse_key(narg,args,15,L45keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	V7= keyvars[5];
	V8= keyvars[6];
	V9= keyvars[7];
	V10= keyvars[8];
	V11= keyvars[9];
	V12= keyvars[10];
	V13= keyvars[11];
	V14= keyvars[12];
	V15= keyvars[13];
	V16= keyvars[14];
	}
	if(((V3))!=Cnil){
	goto L1712;}
	V3= ((V1))->in.in_slots[3];
L1712:
	{object V17;                              /*  %BUFFER         */
	{register int V18;                        /*  BUFFER-BOFFSET  */
	register object V19;                      /*  BUFFER-BBUF     */
	V18= (fix(((V1))->in.in_slots[6]))+(12);
	V19= ((V1))->in.in_slots[7];
	VALUES(0) = (VV[870]->s.s_gfdef);
	(*LK4)(4,(V2),VV[177],VV[178],VALUES(0))  /*  POSITION        */;
	T0= VALUES(0);
	{int V20= (((V19))->ust.ust_self[(V18)+(2)]=(fix(T0)));
	(((V19))->ust.ust_self[(V18)+(1)]=(V20));}
	((*(unsigned short *)(((V19))->ust.ust_self+((V18)+(2))))=fix((V3)));
	if(!((V4)==Cnil)){
	goto L1727;}
	((*(unsigned long *)(((V19))->ust.ust_self+((V18)+(4))))=0);
	goto L1725;
L1727:
	(*LK24)(2,(V4),VV[161])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1730;}
	((*(unsigned long *)(((V19))->ust.ust_self+((V18)+(4))))=fix((V4)));
	goto L1725;
L1730:
	(*LK3)(2,(V4),VV[179])                    /*  X-TYPE-ERROR    */;
L1725:
	((*(unsigned long *)(((V19))->ust.ust_self+((V18)+(8))))=fix(((V5))->in.in_slots[0]));
	L36(3,VV[180],(V7),(V6))                  /*  CHECK-CONSISTENCY*/;
	((*(unsigned long *)(((V19))->ust.ust_self+((V18)+(12))))=fix((VALUES(0))->in.in_slots[0]));
	if(!((V8)==Cnil)){
	goto L1737;}
	((*(unsigned long *)(((V19))->ust.ust_self+((V18)+(16))))=0);
	goto L1735;
L1737:
	(*LK25)(1,(V8))                           /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L1740;}
	((*(unsigned long *)(((V19))->ust.ust_self+((V18)+(16))))=fix(((V8))->in.in_slots[0]));
	goto L1735;
L1740:
	(*LK3)(2,(V8),VV[181])                    /*  X-TYPE-ERROR    */;
L1735:
	((*(short *)(((V19))->st.st_self+((V18)+(20))))=fix((V9)));
	((*(short *)(((V19))->st.st_self+((V18)+(22))))=fix((V10)));
	((*(short *)(((V19))->st.st_self+((V18)+(24))))=fix((V11)));
	((*(short *)(((V19))->st.st_self+((V18)+(26))))=fix((V12)));
	((*(unsigned short *)(((V19))->ust.ust_self+((V18)+(28))))=fix((V13)));
	VALUES(0) = (VV[870]->s.s_gfdef);
	(*LK4)(4,(V14),VV[182],VV[178],VALUES(0)) /*  POSITION        */;
	T0= VALUES(0);
	(((V19))->ust.ust_self[(V18)+(30)]=(fix(T0)));
	if(((V15))==Cnil){
	goto L1753;}
	T0= MAKE_FIXNUM(1);
	goto L1751;
L1753:
	T0= MAKE_FIXNUM(0);
L1751:
	(((V19))->ust.ust_self[(V18)+(31)]=(fix(T0)));
	if(((V16))==Cnil){
	goto L1757;}
	T0= MAKE_FIXNUM(1);
	goto L1755;
L1757:
	T0= MAKE_FIXNUM(0);
L1755:
	(*LK12)(2,MAKE_FIXNUM(1),MAKE_FIXNUM(1))  /*  BYTE            */;
	T1= VALUES(0);
	(*LK26)(3,T0,T1,MAKE_FIXNUM(((V19))->ust.ust_self[(V18)+(31)]))/*  DPB*/;
	T2= VALUES(0);
	VALUES(0) = MAKE_FIXNUM((((V19))->ust.ust_self[(V18)+(31)]=(fix(T2))));
	RETURN(1);
	}
	}
	}
}
/*	function definition for FOCUS-IN-EVENT-GET-MACRO              */
static L46(int narg, object V1, object V2, object V3)
{ VT48 VLEX48 CLSR48
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[183]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for FOCUS-IN-EVENT-GET                    */
static L47(int narg, object V1, object V2, object V3)
{ VT49 VLEX49 CLSR49
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	object V5;                                /*  %BUFFER         */
	V5= (V1);
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{int V11;
	V11= ((V7))->ust.ust_self[(V6)+(1)];
	if((V11)<(8)){
	goto L1769;}
	T0= Cnil;
	goto L1767;
L1769:
	T0= (VV[184])->v.v_self[V11];
	}
L1767:
	{int V11= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T1= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T2= VALUES(0);
	{int V12;
	V12= ((V7))->ust.ust_self[(V6)+(8)];
	if((V12)<(4)){
	goto L1775;}
	VALUES(0) = Cnil;
	goto L1773;
L1775:
	VALUES(0) = (VV[185])->v.v_self[V12];
	}
L1773:
	RETURN(funcall(19,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[172],T0,VV[149],MAKE_FIXNUM(V11),VV[152],T1,VV[153],T2,VV[174],VALUES(0)));}}}}
	}
	}
}
/*	function definition for FOCUS-IN-EVENT-PUT                    */
static L48(int narg, object V1, ...)
{ VT50 VLEX50 CLSR50
	{object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[10];
	parse_key(narg,args,5,L48keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	}
	if(((V3))!=Cnil){
	goto L1777;}
	V3= ((V1))->in.in_slots[3];
L1777:
	{object V7;                               /*  %BUFFER         */
	{register int V8;                         /*  BUFFER-BOFFSET  */
	register object V9;                       /*  BUFFER-BBUF     */
	V8= (fix(((V1))->in.in_slots[6]))+(12);
	V9= ((V1))->in.in_slots[7];
	VALUES(0) = (VV[870]->s.s_gfdef);
	(*LK4)(4,(V2),VV[186],VV[178],VALUES(0))  /*  POSITION        */;
	T0= VALUES(0);
	{int V10= (((V9))->ust.ust_self[(V8)+(2)]=(fix(T0)));
	(((V9))->ust.ust_self[(V8)+(1)]=(V10));}
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=fix((V3)));
	L36(3,VV[187],(V5),(V4))                  /*  CHECK-CONSISTENCY*/;
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(4))))=fix((VALUES(0))->in.in_slots[0]));
	VALUES(0) = (VV[870]->s.s_gfdef);
	(*LK4)(4,(V6),VV[188],VV[178],VALUES(0))  /*  POSITION        */;
	T0= VALUES(0);
	VALUES(0) = MAKE_FIXNUM((((V9))->ust.ust_self[(V8)+(8)]=(fix(T0))));
	RETURN(1);
	}
	}
	}
}
/*	function definition for KEYMAP-NOTIFY-EVENT-GET-MACRO         */
static L49(int narg, object V1, object V2, object V3)
{ VT51 VLEX51 CLSR51
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[189]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for KEYMAP-NOTIFY-EVENT-GET               */
static L50(int narg, object V1, object V2, object V3)
{ VT52 VLEX52 CLSR52
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	object V5;                                /*  %BUFFER         */
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	(*LK27)(3,(V7),MAKE_FIXNUM(0),Cnil)       /*  READ-BITVECTOR256*/;
	RETURN(funcall(11,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[190],VALUES(0)));}}}
	}
	}
}
/*	function definition for KEYMAP-NOTIFY-EVENT-PUT               */
static L51(int narg, object V1, ...)
{ VT53 VLEX53 CLSR53
	{object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[2];
	parse_key(narg,args,1,L51keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	}
	{object V3;                               /*  %BUFFER         */
	{int V4;                                  /*  BUFFER-BOFFSET  */
	object V5;                                /*  BUFFER-BBUF     */
	V4= (fix(((V1))->in.in_slots[6]))+(12);
	V5= ((V1))->in.in_slots[7];
	RETURN((*LK28)(3,(V1),MAKE_FIXNUM((V4)+(0)),(V2))/*  WRITE-BITVECTOR256*/);
	}
	}
	}
}
/*	function definition for EXPOSURE-EVENT-GET-MACRO              */
static L52(int narg, object V1, object V2, object V3)
{ VT54 VLEX54 CLSR54
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[191]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for EXPOSURE-EVENT-GET                    */
static L53(int narg, object V1, object V2, object V3)
{ VT55 VLEX55 CLSR55
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	object V5;                                /*  %BUFFER         */
	V5= (V1);
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{int V11= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T0= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T1= VALUES(0);
	{int V12= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(8))));
	{int V13= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(10))));
	{int V14= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(12))));
	{int V15= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(14))));
	RETURN(funcall(25,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[149],MAKE_FIXNUM(V11),VV[152],T0,VV[153],T1,VV[157],MAKE_FIXNUM(V12),VV[158],MAKE_FIXNUM(V13),VV[192],MAKE_FIXNUM(V14),VV[193],MAKE_FIXNUM(V15),VV[194],MAKE_FIXNUM((*(unsigned short *)(((V7))->ust.ust_self+((V6)+(16)))))));}}}}}}}}
	}
	}
}
/*	function definition for EXPOSURE-EVENT-PUT                    */
static L54(int narg, object V1, ...)
{ VT56 VLEX56 CLSR56
	{object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[16];
	parse_key(narg,args,8,L54keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	V7= keyvars[5];
	V8= keyvars[6];
	V9= keyvars[7];
	}
	if(((V2))!=Cnil){
	goto L1815;}
	V2= ((V1))->in.in_slots[3];
L1815:
	{object V10;                              /*  %BUFFER         */
	{register int V11;                        /*  BUFFER-BOFFSET  */
	register object V12;                      /*  BUFFER-BBUF     */
	V11= (fix(((V1))->in.in_slots[6]))+(12);
	V12= ((V1))->in.in_slots[7];
	((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(2))))=fix((V2)));
	L36(3,VV[195],(V4),(V3))                  /*  CHECK-CONSISTENCY*/;
	((*(unsigned long *)(((V12))->ust.ust_self+((V11)+(4))))=fix((VALUES(0))->in.in_slots[0]));
	((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(8))))=fix((V5)));
	((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(10))))=fix((V6)));
	((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(12))))=fix((V7)));
	((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(14))))=fix((V8)));
	VALUES(0) = MAKE_FIXNUM(((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(16))))=fix((V9))));
	RETURN(1);
	}
	}
	}
}
/*	function definition for GRAPHICS-EXPOSURE-EVENT-GET-MACRO     */
static L55(int narg, object V1, object V2, object V3)
{ VT57 VLEX57 CLSR57
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[196]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for GRAPHICS-EXPOSURE-EVENT-GET           */
static L56(int narg, object V1, object V2, object V3)
{ VT58 VLEX58 CLSR58
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	object V5;                                /*  %BUFFER         */
	V5= (V1);
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{int V11= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	(*LK29)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-DRAWABLE*/;
	T0= VALUES(0);
	(*LK29)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-DRAWABLE*/;
	T1= VALUES(0);
	{int V12= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(8))));
	{int V13= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(10))));
	{int V14= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(12))));
	{int V15= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(14))));
	{int V16= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(16))));
	{int V17= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(18))));
	RETURN(funcall(29,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[149],MAKE_FIXNUM(V11),VV[197],T0,VV[153],T1,VV[157],MAKE_FIXNUM(V12),VV[158],MAKE_FIXNUM(V13),VV[192],MAKE_FIXNUM(V14),VV[193],MAKE_FIXNUM(V15),VV[198],MAKE_FIXNUM(V16),VV[194],MAKE_FIXNUM(V17),VV[199],MAKE_FIXNUM(((V7))->ust.ust_self[(V6)+(20)])));}}}}}}}}}}
	}
	}
}
/*	function definition for GRAPHICS-EXPOSURE-EVENT-PUT           */
static L57(int narg, object V1, ...)
{ VT59 VLEX59 CLSR59
	{object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	object V10;
	object V11;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[20];
	parse_key(narg,args,10,L57keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	V7= keyvars[5];
	V8= keyvars[6];
	V9= keyvars[7];
	V10= keyvars[8];
	V11= keyvars[9];
	}
	if(((V2))!=Cnil){
	goto L1839;}
	V2= ((V1))->in.in_slots[3];
L1839:
	{object V12;                              /*  %BUFFER         */
	{register int V13;                        /*  BUFFER-BOFFSET  */
	register object V14;                      /*  BUFFER-BBUF     */
	V13= (fix(((V1))->in.in_slots[6]))+(12);
	V14= ((V1))->in.in_slots[7];
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(2))))=fix((V2)));
	L36(3,VV[200],(V4),(V3))                  /*  CHECK-CONSISTENCY*/;
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(4))))=fix((VALUES(0))->in.in_slots[0]));
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(8))))=fix((V5)));
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(10))))=fix((V6)));
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(12))))=fix((V7)));
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(14))))=fix((V8)));
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(16))))=fix((V9)));
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(18))))=fix((V10)));
	VALUES(0) = MAKE_FIXNUM((((V14))->ust.ust_self[(V13)+(20)]=(fix((V11)))));
	RETURN(1);
	}
	}
	}
}
/*	function definition for NO-EXPOSURE-EVENT-GET-MACRO           */
static L58(int narg, object V1, object V2, object V3)
{ VT60 VLEX60 CLSR60
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[202]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for NO-EXPOSURE-EVENT-GET                 */
static L59(int narg, object V1, object V2, object V3)
{ VT61 VLEX61 CLSR61
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	object V5;                                /*  %BUFFER         */
	V5= (V1);
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{int V11= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	(*LK29)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-DRAWABLE*/;
	T0= VALUES(0);
	(*LK29)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-DRAWABLE*/;
	T1= VALUES(0);
	{int V12= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(8))));
	RETURN(funcall(19,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[149],MAKE_FIXNUM(V11),VV[197],T0,VV[153],T1,VV[198],MAKE_FIXNUM(V12),VV[199],MAKE_FIXNUM(((V7))->ust.ust_self[(V6)+(10)])));}}}}}
	}
	}
}
/*	function definition for NO-EXPOSURE-EVENT-PUT                 */
static L60(int narg, object V1, ...)
{ VT62 VLEX62 CLSR62
	{object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[10];
	parse_key(narg,args,5,L60keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	}
	if(((V2))!=Cnil){
	goto L1865;}
	V2= ((V1))->in.in_slots[3];
L1865:
	{object V7;                               /*  %BUFFER         */
	{register int V8;                         /*  BUFFER-BOFFSET  */
	register object V9;                       /*  BUFFER-BBUF     */
	V8= (fix(((V1))->in.in_slots[6]))+(12);
	V9= ((V1))->in.in_slots[7];
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=fix((V2)));
	L36(3,VV[203],(V4),(V3))                  /*  CHECK-CONSISTENCY*/;
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(4))))=fix((VALUES(0))->in.in_slots[0]));
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(8))))=fix((V5)));
	VALUES(0) = MAKE_FIXNUM((((V9))->ust.ust_self[(V8)+(10)]=(fix((V6)))));
	RETURN(1);
	}
	}
	}
}
/*	function definition for VISIBILITY-NOTIFY-EVENT-GET-MACRO     */
static L61(int narg, object V1, object V2, object V3)
{ VT63 VLEX63 CLSR63
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[204]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for VISIBILITY-NOTIFY-EVENT-GET           */
static L62(int narg, object V1, object V2, object V3)
{ VT64 VLEX64 CLSR64
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	object V5;                                /*  %BUFFER         */
	V5= (V1);
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{int V11= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T0= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T1= VALUES(0);
	{int V12;
	V12= ((V7))->ust.ust_self[(V6)+(8)];
	if((V12)<(3)){
	goto L1888;}
	VALUES(0) = Cnil;
	goto L1886;
L1888:
	VALUES(0) = (VV[205])->v.v_self[V12];
	}
L1886:
	RETURN(funcall(17,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[149],MAKE_FIXNUM(V11),VV[152],T0,VV[153],T1,VV[159],VALUES(0)));}}}}
	}
	}
}
/*	function definition for VISIBILITY-NOTIFY-EVENT-PUT           */
static L63(int narg, object V1, ...)
{ VT65 VLEX65 CLSR65
	{object V2;
	object V3;
	object V4;
	object V5;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[8];
	parse_key(narg,args,4,L63keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	}
	if(((V2))!=Cnil){
	goto L1890;}
	V2= ((V1))->in.in_slots[3];
L1890:
	{object V6;                               /*  %BUFFER         */
	{register int V7;                         /*  BUFFER-BOFFSET  */
	register object V8;                       /*  BUFFER-BBUF     */
	V7= (fix(((V1))->in.in_slots[6]))+(12);
	V8= ((V1))->in.in_slots[7];
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(2))))=fix((V2)));
	L36(3,VV[206],(V4),(V3))                  /*  CHECK-CONSISTENCY*/;
	((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(4))))=fix((VALUES(0))->in.in_slots[0]));
	VALUES(0) = (VV[870]->s.s_gfdef);
	(*LK4)(4,(V5),VV[207],VV[178],VALUES(0))  /*  POSITION        */;
	T0= VALUES(0);
	VALUES(0) = MAKE_FIXNUM((((V8))->ust.ust_self[(V7)+(8)]=(fix(T0))));
	RETURN(1);
	}
	}
	}
}
/*	function definition for CREATE-NOTIFY-EVENT-GET-MACRO         */
static L64(int narg, object V1, object V2, object V3)
{ VT66 VLEX66 CLSR66
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[208]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for CREATE-NOTIFY-EVENT-GET               */
static L65(int narg, object V1, object V2, object V3)
{ VT67 VLEX67 CLSR67
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	register object V5;                       /*  %BUFFER         */
	V5= (V1);
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{int V11= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T0= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T1= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(8)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T2= VALUES(0);
	{int V12= (*(short *)(((V7))->st.st_self+((V6)+(12))));
	{int V13= (*(short *)(((V7))->st.st_self+((V6)+(14))));
	{int V14= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(16))));
	{int V15= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(18))));
	{int V16= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(20))));
	RETURN(funcall(29,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[149],MAKE_FIXNUM(V11),VV[209],T0,VV[153],T1,VV[152],T2,VV[157],MAKE_FIXNUM(V12),VV[158],MAKE_FIXNUM(V13),VV[192],MAKE_FIXNUM(V14),VV[193],MAKE_FIXNUM(V15),VV[210],MAKE_FIXNUM(V16),VV[211],((((V7))->ust.ust_self[(V6)+(22)])>0?Ct:Cnil)));}}}}}}}}}
	}
	}
}
/*	function definition for CREATE-NOTIFY-EVENT-PUT               */
static L66(int narg, object V1, ...)
{ VT68 VLEX68 CLSR68
	{object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	object V10;
	object V11;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[20];
	parse_key(narg,args,10,L66keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	V7= keyvars[5];
	V8= keyvars[6];
	V9= keyvars[7];
	V10= keyvars[8];
	V11= keyvars[9];
	}
	if(((V2))!=Cnil){
	goto L1913;}
	V2= ((V1))->in.in_slots[3];
L1913:
	{object V12;                              /*  %BUFFER         */
	{register int V13;                        /*  BUFFER-BOFFSET  */
	register object V14;                      /*  BUFFER-BBUF     */
	V13= (fix(((V1))->in.in_slots[6]))+(12);
	V14= ((V1))->in.in_slots[7];
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(2))))=fix((V2)));
	L36(3,VV[212],(V4),(V3))                  /*  CHECK-CONSISTENCY*/;
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(4))))=fix((VALUES(0))->in.in_slots[0]));
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(8))))=fix(((V5))->in.in_slots[0]));
	((*(short *)(((V14))->st.st_self+((V13)+(12))))=fix((V6)));
	((*(short *)(((V14))->st.st_self+((V13)+(14))))=fix((V7)));
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(16))))=fix((V8)));
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(18))))=fix((V9)));
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(20))))=fix((V10)));
	if(((V11))==Cnil){
	goto L1933;}
	T0= MAKE_FIXNUM(1);
	goto L1931;
L1933:
	T0= MAKE_FIXNUM(0);
L1931:
	VALUES(0) = MAKE_FIXNUM((((V14))->ust.ust_self[(V13)+(22)]=(fix(T0))));
	RETURN(1);
	}
	}
	}
}
/*	function definition for DESTROY-NOTIFY-EVENT-GET-MACRO        */
static L67(int narg, object V1, object V2, object V3)
{ VT69 VLEX69 CLSR69
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[213]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for DESTROY-NOTIFY-EVENT-GET              */
static L68(int narg, object V1, object V2, object V3)
{ VT70 VLEX70 CLSR70
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	object V5;                                /*  %BUFFER         */
	V5= (V1);
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{int V11= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T0= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(8)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	RETURN(funcall(15,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[149],MAKE_FIXNUM(V11),VV[153],T0,VV[152],VALUES(0)));}}}}
	}
	}
}
/*	function definition for DESTROY-NOTIFY-EVENT-PUT              */
static L69(int narg, object V1, ...)
{ VT71 VLEX71 CLSR71
	{object V2;
	object V3;
	object V4;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[6];
	parse_key(narg,args,3,L69keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	}
	if(((V2))!=Cnil){
	goto L1943;}
	V2= ((V1))->in.in_slots[3];
L1943:
	{object V5;                               /*  %BUFFER         */
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= (fix(((V1))->in.in_slots[6]))+(12);
	V7= ((V1))->in.in_slots[7];
	((*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))))=fix((V2)));
	((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4))))=fix(((V3))->in.in_slots[0]));
	VALUES(0) = MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(8))))=fix(((V4))->in.in_slots[0])));
	RETURN(1);
	}
	}
	}
}
/*	function definition for UNMAP-NOTIFY-EVENT-GET-MACRO          */
static L70(int narg, object V1, object V2, object V3)
{ VT72 VLEX72 CLSR72
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[214]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for UNMAP-NOTIFY-EVENT-GET                */
static L71(int narg, object V1, object V2, object V3)
{ VT73 VLEX73 CLSR73
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	object V5;                                /*  %BUFFER         */
	V5= (V1);
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{int V11= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T0= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(8)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T1= VALUES(0);
	RETURN(funcall(17,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[149],MAKE_FIXNUM(V11),VV[153],T0,VV[152],T1,VV[215],((((V7))->ust.ust_self[(V6)+(12)])>0?Ct:Cnil)));}}}}
	}
	}
}
/*	function definition for UNMAP-NOTIFY-EVENT-PUT                */
static L72(int narg, object V1, ...)
{ VT74 VLEX74 CLSR74
	{object V2;
	object V3;
	object V4;
	object V5;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[8];
	parse_key(narg,args,4,L72keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	}
	if(((V2))!=Cnil){
	goto L1962;}
	V2= ((V1))->in.in_slots[3];
L1962:
	{object V6;                               /*  %BUFFER         */
	{register int V7;                         /*  BUFFER-BOFFSET  */
	register object V8;                       /*  BUFFER-BBUF     */
	V7= (fix(((V1))->in.in_slots[6]))+(12);
	V8= ((V1))->in.in_slots[7];
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(2))))=fix((V2)));
	((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(4))))=fix(((V3))->in.in_slots[0]));
	((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(8))))=fix(((V4))->in.in_slots[0]));
	if(((V5))==Cnil){
	goto L1976;}
	T0= MAKE_FIXNUM(1);
	goto L1974;
L1976:
	T0= MAKE_FIXNUM(0);
L1974:
	VALUES(0) = MAKE_FIXNUM((((V8))->ust.ust_self[(V7)+(12)]=(fix(T0))));
	RETURN(1);
	}
	}
	}
}
/*	function definition for MAP-NOTIFY-EVENT-GET-MACRO            */
static L73(int narg, object V1, object V2, object V3)
{ VT75 VLEX75 CLSR75
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[216]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for MAP-NOTIFY-EVENT-GET                  */
static L74(int narg, object V1, object V2, object V3)
{ VT76 VLEX76 CLSR76
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	object V5;                                /*  %BUFFER         */
	V5= (V1);
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{int V11= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T0= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(8)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T1= VALUES(0);
	RETURN(funcall(17,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[149],MAKE_FIXNUM(V11),VV[153],T0,VV[152],T1,VV[211],((((V7))->ust.ust_self[(V6)+(12)])>0?Ct:Cnil)));}}}}
	}
	}
}
/*	function definition for MAP-NOTIFY-EVENT-PUT                  */
static L75(int narg, object V1, ...)
{ VT77 VLEX77 CLSR77
	{object V2;
	object V3;
	object V4;
	object V5;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[8];
	parse_key(narg,args,4,L75keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	}
	if(((V2))!=Cnil){
	goto L1986;}
	V2= ((V1))->in.in_slots[3];
L1986:
	{object V6;                               /*  %BUFFER         */
	{register int V7;                         /*  BUFFER-BOFFSET  */
	register object V8;                       /*  BUFFER-BBUF     */
	V7= (fix(((V1))->in.in_slots[6]))+(12);
	V8= ((V1))->in.in_slots[7];
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(2))))=fix((V2)));
	((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(4))))=fix(((V3))->in.in_slots[0]));
	((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(8))))=fix(((V4))->in.in_slots[0]));
	if(((V5))==Cnil){
	goto L2000;}
	T0= MAKE_FIXNUM(1);
	goto L1998;
L2000:
	T0= MAKE_FIXNUM(0);
L1998:
	VALUES(0) = MAKE_FIXNUM((((V8))->ust.ust_self[(V7)+(12)]=(fix(T0))));
	RETURN(1);
	}
	}
	}
}
/*	function definition for MAP-REQUEST-EVENT-GET-MACRO           */
static L76(int narg, object V1, object V2, object V3)
{ VT78 VLEX78 CLSR78
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[217]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for MAP-REQUEST-EVENT-GET                 */
static L77(int narg, object V1, object V2, object V3)
{ VT79 VLEX79 CLSR79
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	register object V5;                       /*  %BUFFER         */
	V5= (V1);
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{int V11= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T0= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T1= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(8)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	RETURN(funcall(17,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[149],MAKE_FIXNUM(V11),VV[209],T0,VV[153],T1,VV[152],VALUES(0)));}}}}
	}
	}
}
/*	function definition for MAP-REQUEST-EVENT-PUT                 */
static L78(int narg, object V1, ...)
{ VT80 VLEX80 CLSR80
	{object V2;
	object V3;
	object V4;
	object V5;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[8];
	parse_key(narg,args,4,L78keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	}
	if(((V2))!=Cnil){
	goto L2011;}
	V2= ((V1))->in.in_slots[3];
L2011:
	{object V6;                               /*  %BUFFER         */
	{register int V7;                         /*  BUFFER-BOFFSET  */
	register object V8;                       /*  BUFFER-BBUF     */
	V7= (fix(((V1))->in.in_slots[6]))+(12);
	V8= ((V1))->in.in_slots[7];
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(2))))=fix((V2)));
	L36(3,VV[218],(V4),(V3))                  /*  CHECK-CONSISTENCY*/;
	((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(4))))=fix((VALUES(0))->in.in_slots[0]));
	VALUES(0) = MAKE_FIXNUM(((*(unsigned long *)(((V8))->ust.ust_self+((V7)+(8))))=fix(((V5))->in.in_slots[0])));
	RETURN(1);
	}
	}
	}
}
/*	function definition for REPARENT-NOTIFY-EVENT-GET-MACRO       */
static L79(int narg, object V1, object V2, object V3)
{ VT81 VLEX81 CLSR81
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[219]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for REPARENT-NOTIFY-EVENT-GET             */
static L80(int narg, object V1, object V2, object V3)
{ VT82 VLEX82 CLSR82
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	register object V5;                       /*  %BUFFER         */
	V5= (V1);
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{int V11= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T0= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(8)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T1= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(12)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T2= VALUES(0);
	{int V12= (*(short *)(((V7))->st.st_self+((V6)+(16))));
	{int V13= (*(short *)(((V7))->st.st_self+((V6)+(18))));
	RETURN(funcall(23,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[149],MAKE_FIXNUM(V11),VV[153],T0,VV[152],T1,VV[209],T2,VV[157],MAKE_FIXNUM(V12),VV[158],MAKE_FIXNUM(V13),VV[211],((((V7))->ust.ust_self[(V6)+(20)])>0?Ct:Cnil)));}}}}}}
	}
	}
}
/*	function definition for REPARENT-NOTIFY-EVENT-PUT             */
static L81(int narg, object V1, ...)
{ VT83 VLEX83 CLSR83
	{object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[14];
	parse_key(narg,args,7,L81keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	V7= keyvars[5];
	V8= keyvars[6];
	}
	if(((V2))!=Cnil){
	goto L2032;}
	V2= ((V1))->in.in_slots[3];
L2032:
	{object V9;                               /*  %BUFFER         */
	{register int V10;                        /*  BUFFER-BOFFSET  */
	register object V11;                      /*  BUFFER-BBUF     */
	V10= (fix(((V1))->in.in_slots[6]))+(12);
	V11= ((V1))->in.in_slots[7];
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(2))))=fix((V2)));
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(4))))=fix(((V3))->in.in_slots[0]));
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(8))))=fix(((V4))->in.in_slots[0]));
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(12))))=fix(((V5))->in.in_slots[0]));
	((*(short *)(((V11))->st.st_self+((V10)+(16))))=fix((V6)));
	((*(short *)(((V11))->st.st_self+((V10)+(18))))=fix((V7)));
	if(((V8))==Cnil){
	goto L2049;}
	T0= MAKE_FIXNUM(1);
	goto L2047;
L2049:
	T0= MAKE_FIXNUM(0);
L2047:
	VALUES(0) = MAKE_FIXNUM((((V11))->ust.ust_self[(V10)+(20)]=(fix(T0))));
	RETURN(1);
	}
	}
	}
}
/*	function definition for CONFIGURE-NOTIFY-EVENT-GET-MACRO      */
static L82(int narg, object V1, object V2, object V3)
{ VT84 VLEX84 CLSR84
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[220]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for CONFIGURE-NOTIFY-EVENT-GET            */
static L83(int narg, object V1, object V2, object V3)
{ VT85 VLEX85 CLSR85
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	register object V5;                       /*  %BUFFER         */
	V5= (V1);
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{int V11= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T0= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(8)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T1= VALUES(0);
	{int V12;
	V12= (*(unsigned long *)(((V7))->ust.ust_self+((V6)+(12))));
	if(!((V12)==0)){
	goto L2062;}
	T2= Cnil;
	goto L2059;
L2062:
	{object V13;
	(*LK23)(2,(V5),MAKE_FIXNUM(V12))          /*  LOOKUP-WINDOW   */;
	V13= VALUES(0);
	if(((V13))==Cnil){
	goto L2066;}
	T2= (V13);
	goto L2059;
L2066:
	T2= Cnil;
	}
	}
L2059:
	{int V12= (*(short *)(((V7))->st.st_self+((V6)+(16))));
	{int V13= (*(short *)(((V7))->st.st_self+((V6)+(18))));
	{int V14= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(20))));
	{int V15= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(22))));
	{int V16= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(24))));
	RETURN(funcall(29,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[149],MAKE_FIXNUM(V11),VV[153],T0,VV[152],T1,VV[221],T2,VV[157],MAKE_FIXNUM(V12),VV[158],MAKE_FIXNUM(V13),VV[192],MAKE_FIXNUM(V14),VV[193],MAKE_FIXNUM(V15),VV[210],MAKE_FIXNUM(V16),VV[211],((((V7))->ust.ust_self[(V6)+(26)])>0?Ct:Cnil)));}}}}}}}}}
	}
	}
}
/*	function definition for CONFIGURE-NOTIFY-EVENT-PUT            */
static L84(int narg, object V1, ...)
{ VT86 VLEX86 CLSR86
	{object V2;
	object V3;
	object V4;
	register object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	object V10;
	object V11;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[20];
	parse_key(narg,args,10,L84keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	V7= keyvars[5];
	V8= keyvars[6];
	V9= keyvars[7];
	V10= keyvars[8];
	V11= keyvars[9];
	}
	if(((V2))!=Cnil){
	goto L2068;}
	V2= ((V1))->in.in_slots[3];
L2068:
	{object V12;                              /*  %BUFFER         */
	{register int V13;                        /*  BUFFER-BOFFSET  */
	register object V14;                      /*  BUFFER-BBUF     */
	V13= (fix(((V1))->in.in_slots[6]))+(12);
	V14= ((V1))->in.in_slots[7];
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(2))))=fix((V2)));
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(4))))=fix(((V3))->in.in_slots[0]));
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(8))))=fix(((V4))->in.in_slots[0]));
	if(!((V5)==Cnil)){
	goto L2082;}
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(12))))=0);
	goto L2080;
L2082:
	(*LK25)(1,(V5))                           /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L2085;}
	((*(unsigned long *)(((V14))->ust.ust_self+((V13)+(12))))=fix(((V5))->in.in_slots[0]));
	goto L2080;
L2085:
	(*LK3)(2,(V5),VV[222])                    /*  X-TYPE-ERROR    */;
L2080:
	((*(short *)(((V14))->st.st_self+((V13)+(16))))=fix((V6)));
	((*(short *)(((V14))->st.st_self+((V13)+(18))))=fix((V7)));
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(20))))=fix((V8)));
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(22))))=fix((V9)));
	((*(unsigned short *)(((V14))->ust.ust_self+((V13)+(24))))=fix((V10)));
	if(((V11))==Cnil){
	goto L2094;}
	T0= MAKE_FIXNUM(1);
	goto L2092;
L2094:
	T0= MAKE_FIXNUM(0);
L2092:
	VALUES(0) = MAKE_FIXNUM((((V14))->ust.ust_self[(V13)+(26)]=(fix(T0))));
	RETURN(1);
	}
	}
	}
}
/*	function definition for CONFIGURE-REQUEST-EVENT-GET-MACRO     */
static L85(int narg, object V1, object V2, object V3)
{ VT87 VLEX87 CLSR87
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[223]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for CONFIGURE-REQUEST-EVENT-GET           */
static L86(int narg, object V1, object V2, object V3)
{ VT88 VLEX88 CLSR88
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	register object V5;                       /*  %BUFFER         */
	V5= (V1);
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{int V11;
	V11= ((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(1)))) & 0x1fffffff);
	if((V11)<(5)){
	goto L2104;}
	T0= Cnil;
	goto L2102;
L2104:
	T0= (VV[225])->v.v_self[V11];
	}
L2102:
	{int V11= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T1= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T2= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(8)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T3= VALUES(0);
	{int V12;
	V12= (*(unsigned long *)(((V7))->ust.ust_self+((V6)+(12))));
	if(!((V12)==0)){
	goto L2112;}
	T4= Cnil;
	goto L2109;
L2112:
	{object V13;
	(*LK23)(2,(V5),MAKE_FIXNUM(V12))          /*  LOOKUP-WINDOW   */;
	V13= VALUES(0);
	if(((V13))==Cnil){
	goto L2116;}
	T4= (V13);
	goto L2109;
L2116:
	T4= Cnil;
	}
	}
L2109:
	{int V12= (*(short *)(((V7))->st.st_self+((V6)+(16))));
	{int V13= (*(short *)(((V7))->st.st_self+((V6)+(18))));
	{int V14= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(20))));
	{int V15= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(22))));
	{int V16= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(24))));
	RETURN(funcall(33,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[224],T0,VV[149],MAKE_FIXNUM(V11),VV[209],T1,VV[153],T2,VV[152],T3,VV[221],T4,VV[157],MAKE_FIXNUM(V12),VV[158],MAKE_FIXNUM(V13),VV[192],MAKE_FIXNUM(V14),VV[193],MAKE_FIXNUM(V15),VV[210],MAKE_FIXNUM(V16),VV[226],MAKE_FIXNUM((*(unsigned short *)(((V7))->ust.ust_self+((V6)+(26)))))));}}}}}}}}}
	}
	}
}
/*	function definition for CONFIGURE-REQUEST-EVENT-PUT           */
static L87(int narg, object V1, ...)
{ VT89 VLEX89 CLSR89
	{object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	register object V7;
	object V8;
	object V9;
	object V10;
	object V11;
	object V12;
	object V13;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[24];
	parse_key(narg,args,12,L87keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	V7= keyvars[5];
	V8= keyvars[6];
	V9= keyvars[7];
	V10= keyvars[8];
	V11= keyvars[9];
	V12= keyvars[10];
	V13= keyvars[11];
	}
	if(((V3))!=Cnil){
	goto L2118;}
	V3= ((V1))->in.in_slots[3];
L2118:
	{object V14;                              /*  %BUFFER         */
	{register int V15;                        /*  BUFFER-BOFFSET  */
	register object V16;                      /*  BUFFER-BBUF     */
	V15= (fix(((V1))->in.in_slots[6]))+(12);
	V16= ((V1))->in.in_slots[7];
	VALUES(0) = (VV[870]->s.s_gfdef);
	(*LK4)(4,(V2),VV[227],VV[178],VALUES(0))  /*  POSITION        */;
	T0= VALUES(0);
	{int V17= ((*(unsigned long *)(((V16))->ust.ust_self+((V15)+(2))))=fix(T0));
	(((V16))->ust.ust_self[(V15)+(1)]=(V17));}
	((*(unsigned short *)(((V16))->ust.ust_self+((V15)+(2))))=fix((V3)));
	L36(3,VV[228],(V5),(V4))                  /*  CHECK-CONSISTENCY*/;
	((*(unsigned long *)(((V16))->ust.ust_self+((V15)+(4))))=fix((VALUES(0))->in.in_slots[0]));
	((*(unsigned long *)(((V16))->ust.ust_self+((V15)+(8))))=fix(((V6))->in.in_slots[0]));
	if(!((V7)==Cnil)){
	goto L2136;}
	((*(unsigned long *)(((V16))->ust.ust_self+((V15)+(12))))=0);
	goto L2134;
L2136:
	(*LK25)(1,(V7))                           /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L2139;}
	((*(unsigned long *)(((V16))->ust.ust_self+((V15)+(12))))=fix(((V7))->in.in_slots[0]));
	goto L2134;
L2139:
	(*LK3)(2,(V7),VV[229])                    /*  X-TYPE-ERROR    */;
L2134:
	((*(short *)(((V16))->st.st_self+((V15)+(16))))=fix((V8)));
	((*(short *)(((V16))->st.st_self+((V15)+(18))))=fix((V9)));
	((*(unsigned short *)(((V16))->ust.ust_self+((V15)+(20))))=fix((V10)));
	((*(unsigned short *)(((V16))->ust.ust_self+((V15)+(22))))=fix((V11)));
	((*(unsigned short *)(((V16))->ust.ust_self+((V15)+(24))))=fix((V12)));
	VALUES(0) = MAKE_FIXNUM(((*(unsigned short *)(((V16))->ust.ust_self+((V15)+(26))))=fix((V13))));
	RETURN(1);
	}
	}
	}
}
/*	function definition for GRAVITY-NOTIFY-EVENT-GET-MACRO        */
static L88(int narg, object V1, object V2, object V3)
{ VT90 VLEX90 CLSR90
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[230]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for GRAVITY-NOTIFY-EVENT-GET              */
static L89(int narg, object V1, object V2, object V3)
{ VT91 VLEX91 CLSR91
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	object V5;                                /*  %BUFFER         */
	V5= (V1);
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{int V11= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T0= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(8)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T1= VALUES(0);
	{int V12= (*(short *)(((V7))->st.st_self+((V6)+(12))));
	RETURN(funcall(19,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[149],MAKE_FIXNUM(V11),VV[153],T0,VV[152],T1,VV[157],MAKE_FIXNUM(V12),VV[158],MAKE_FIXNUM((*(short *)(((V7))->st.st_self+((V6)+(14)))))));}}}}}
	}
	}
}
/*	function definition for GRAVITY-NOTIFY-EVENT-PUT              */
static L90(int narg, object V1, ...)
{ VT92 VLEX92 CLSR92
	{object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[10];
	parse_key(narg,args,5,L90keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	}
	if(((V2))!=Cnil){
	goto L2154;}
	V2= ((V1))->in.in_slots[3];
L2154:
	{object V7;                               /*  %BUFFER         */
	{register int V8;                         /*  BUFFER-BOFFSET  */
	register object V9;                       /*  BUFFER-BBUF     */
	V8= (fix(((V1))->in.in_slots[6]))+(12);
	V9= ((V1))->in.in_slots[7];
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=fix((V2)));
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(4))))=fix(((V3))->in.in_slots[0]));
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(8))))=fix(((V4))->in.in_slots[0]));
	((*(short *)(((V9))->st.st_self+((V8)+(12))))=fix((V5)));
	VALUES(0) = MAKE_FIXNUM(((*(short *)(((V9))->st.st_self+((V8)+(14))))=fix((V6))));
	RETURN(1);
	}
	}
	}
}
/*	function definition for RESIZE-REQUEST-EVENT-GET-MACRO        */
static L91(int narg, object V1, object V2, object V3)
{ VT93 VLEX93 CLSR93
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[231]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for RESIZE-REQUEST-EVENT-GET              */
static L92(int narg, object V1, object V2, object V3)
{ VT94 VLEX94 CLSR94
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	object V5;                                /*  %BUFFER         */
	V5= (V1);
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{int V11= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T0= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T1= VALUES(0);
	{int V12= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(8))));
	RETURN(funcall(19,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[149],MAKE_FIXNUM(V11),VV[152],T0,VV[153],T1,VV[192],MAKE_FIXNUM(V12),VV[193],MAKE_FIXNUM((*(unsigned short *)(((V7))->ust.ust_self+((V6)+(10)))))));}}}}}
	}
	}
}
/*	function definition for RESIZE-REQUEST-EVENT-PUT              */
static L93(int narg, object V1, ...)
{ VT95 VLEX95 CLSR95
	{object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[10];
	parse_key(narg,args,5,L93keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	}
	if(((V2))!=Cnil){
	goto L2175;}
	V2= ((V1))->in.in_slots[3];
L2175:
	{object V7;                               /*  %BUFFER         */
	{register int V8;                         /*  BUFFER-BOFFSET  */
	register object V9;                       /*  BUFFER-BBUF     */
	V8= (fix(((V1))->in.in_slots[6]))+(12);
	V9= ((V1))->in.in_slots[7];
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=fix((V2)));
	L36(3,VV[232],(V4),(V3))                  /*  CHECK-CONSISTENCY*/;
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(4))))=fix((VALUES(0))->in.in_slots[0]));
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(8))))=fix((V5)));
	VALUES(0) = MAKE_FIXNUM(((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(10))))=fix((V6))));
	RETURN(1);
	}
	}
	}
}
/*	function definition for CIRCULATE-NOTIFY-EVENT-GET-MACRO      */
static L94(int narg, object V1, object V2, object V3)
{ VT96 VLEX96 CLSR96
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[233]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for CIRCULATE-NOTIFY-EVENT-GET            */
static L95(int narg, object V1, object V2, object V3)
{ VT97 VLEX97 CLSR97
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	register object V5;                       /*  %BUFFER         */
	V5= (V1);
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{int V11= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T0= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(8)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T1= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(12)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T2= VALUES(0);
	{int V12;
	V12= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(16))));
	if((V12)<(2)){
	goto L2199;}
	VALUES(0) = Cnil;
	goto L2197;
L2199:
	VALUES(0) = (VV[235])->v.v_self[V12];
	}
L2197:
	RETURN(funcall(19,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[149],MAKE_FIXNUM(V11),VV[153],T0,VV[152],T1,VV[209],T2,VV[234],VALUES(0)));}}}}
	}
	}
}
/*	function definition for CIRCULATE-NOTIFY-EVENT-PUT            */
static L96(int narg, object V1, ...)
{ VT98 VLEX98 CLSR98
	{object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[10];
	parse_key(narg,args,5,L96keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	}
	if(((V2))!=Cnil){
	goto L2201;}
	V2= ((V1))->in.in_slots[3];
L2201:
	{object V7;                               /*  %BUFFER         */
	{register int V8;                         /*  BUFFER-BOFFSET  */
	register object V9;                       /*  BUFFER-BBUF     */
	V8= (fix(((V1))->in.in_slots[6]))+(12);
	V9= ((V1))->in.in_slots[7];
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=fix((V2)));
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(4))))=fix(((V3))->in.in_slots[0]));
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(8))))=fix(((V4))->in.in_slots[0]));
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(12))))=fix(((V5))->in.in_slots[0]));
	VALUES(0) = (VV[870]->s.s_gfdef);
	(*LK4)(4,(V6),VV[236],VV[178],VALUES(0))  /*  POSITION        */;
	T0= VALUES(0);
	VALUES(0) = MAKE_FIXNUM(((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(16))))=fix(T0)));
	RETURN(1);
	}
	}
	}
}
/*	function definition for CIRCULATE-REQUEST-EVENT-GET-MACRO     */
static L97(int narg, object V1, object V2, object V3)
{ VT99 VLEX99 CLSR99
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[237]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for CIRCULATE-REQUEST-EVENT-GET           */
static L98(int narg, object V1, object V2, object V3)
{ VT100 VLEX100 CLSR100
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	register object V5;                       /*  %BUFFER         */
	V5= (V1);
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{int V11= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T0= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T1= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(8)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T2= VALUES(0);
	{int V12;
	V12= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(16))));
	if((V12)<(2)){
	goto L2227;}
	VALUES(0) = Cnil;
	goto L2225;
L2227:
	VALUES(0) = (VV[238])->v.v_self[V12];
	}
L2225:
	RETURN(funcall(19,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[149],MAKE_FIXNUM(V11),VV[209],T0,VV[153],T1,VV[152],T2,VV[234],VALUES(0)));}}}}
	}
	}
}
/*	function definition for CIRCULATE-REQUEST-EVENT-PUT           */
static L99(int narg, object V1, ...)
{ VT101 VLEX101 CLSR101
	{object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[10];
	parse_key(narg,args,5,L99keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	}
	if(((V2))!=Cnil){
	goto L2229;}
	V2= ((V1))->in.in_slots[3];
L2229:
	{object V7;                               /*  %BUFFER         */
	{register int V8;                         /*  BUFFER-BOFFSET  */
	register object V9;                       /*  BUFFER-BBUF     */
	V8= (fix(((V1))->in.in_slots[6]))+(12);
	V9= ((V1))->in.in_slots[7];
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=fix((V2)));
	L36(3,VV[239],(V4),(V3))                  /*  CHECK-CONSISTENCY*/;
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(4))))=fix((VALUES(0))->in.in_slots[0]));
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(8))))=fix(((V5))->in.in_slots[0]));
	VALUES(0) = (VV[870]->s.s_gfdef);
	(*LK4)(4,(V6),VV[240],VV[178],VALUES(0))  /*  POSITION        */;
	T0= VALUES(0);
	VALUES(0) = MAKE_FIXNUM(((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(16))))=fix(T0)));
	RETURN(1);
	}
	}
	}
}
/*	function definition for PROPERTY-NOTIFY-EVENT-GET-MACRO       */
static L100(int narg, object V1, object V2, object V3)
{ VT102 VLEX102 CLSR102
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[241]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for PROPERTY-NOTIFY-EVENT-GET             */
static L101(int narg, object V1, object V2, object V3)
{ VT103 VLEX103 CLSR103
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	register object V5;                       /*  %BUFFER         */
	V5= (V1);
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{int V11= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T0= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T1= VALUES(0);
	(*LK30)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(8)))) & 0x1fffffff)))/*  ATOM-NAME*/;
	T2= VALUES(0);
	{int V12;
	V12= (*(unsigned long *)(((V7))->ust.ust_self+((V6)+(12))));
	if(!((V12)==0)){
	goto L2256;}
	T3= Cnil;
	goto L2253;
L2256:
	{int V13;
	V13= (*(unsigned long *)(((V7))->ust.ust_self+((V6)+(12))));
	if((MAKE_FIXNUM(V13))==Cnil){
	goto L2260;}
	T3= MAKE_FIXNUM(V13);
	goto L2253;
L2260:
	T3= Cnil;
	}
	}
L2253:
	{int V12;
	V12= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(16))));
	if((V12)<(2)){
	goto L2264;}
	VALUES(0) = Cnil;
	goto L2262;
L2264:
	VALUES(0) = (VV[243])->v.v_self[V12];
	}
L2262:
	RETURN(funcall(21,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[149],MAKE_FIXNUM(V11),VV[152],T0,VV[153],T1,VV[242],T2,VV[150],T3,VV[159],VALUES(0)));}}}}
	}
	}
}
/*	function definition for PROPERTY-NOTIFY-EVENT-PUT             */
static L102(int narg, object V1, ...)
{ VT104 VLEX104 CLSR104
	{object V2;
	object V3;
	object V4;
	object V5;
	register object V6;
	object V7;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[12];
	parse_key(narg,args,6,L102keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	V7= keyvars[5];
	}
	if(((V2))!=Cnil){
	goto L2266;}
	V2= ((V1))->in.in_slots[3];
L2266:
	{object V8;                               /*  %BUFFER         */
	{register int V9;                         /*  BUFFER-BOFFSET  */
	register object V10;                      /*  BUFFER-BBUF     */
	V9= (fix(((V1))->in.in_slots[6]))+(12);
	V10= ((V1))->in.in_slots[7];
	((*(unsigned short *)(((V10))->ust.ust_self+((V9)+(2))))=fix((V2)));
	L36(3,VV[244],(V4),(V3))                  /*  CHECK-CONSISTENCY*/;
	((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(4))))=fix((VALUES(0))->in.in_slots[0]));
	(*LK31)(2,(V5),(V1))                      /*  ATOM-ID         */;
	if(VALUES(0)==Cnil)goto L2280;
	T0= VALUES(0);
	goto L2279;
L2280:
	Lerror(1,VV[245])                         /*  ERROR           */;
	T0= VALUES(0);
L2279:
	((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(8))))=fix(T0));
	if(!((V6)==Cnil)){
	goto L2284;}
	((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(12))))=0);
	goto L2282;
L2284:
	(*LK24)(2,(V6),VV[161])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2287;}
	((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(12))))=fix((V6)));
	goto L2282;
L2287:
	(*LK3)(2,(V6),VV[246])                    /*  X-TYPE-ERROR    */;
L2282:
	VALUES(0) = (VV[870]->s.s_gfdef);
	(*LK4)(4,(V7),VV[247],VV[178],VALUES(0))  /*  POSITION        */;
	T0= VALUES(0);
	VALUES(0) = MAKE_FIXNUM(((*(unsigned short *)(((V10))->ust.ust_self+((V9)+(16))))=fix(T0)));
	RETURN(1);
	}
	}
	}
}
/*	function definition for SELECTION-CLEAR-EVENT-GET-MACRO       */
static L103(int narg, object V1, object V2, object V3)
{ VT105 VLEX105 CLSR105
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[248]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for SELECTION-CLEAR-EVENT-GET             */
static L104(int narg, object V1, object V2, object V3)
{ VT106 VLEX106 CLSR106
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	register object V5;                       /*  %BUFFER         */
	V5= (V1);
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{int V11= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	{int V12;
	V12= (*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4))));
	if(!((V12)==0)){
	goto L2300;}
	T0= Cnil;
	goto L2297;
L2300:
	{int V13;
	V13= (*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4))));
	if((MAKE_FIXNUM(V13))==Cnil){
	goto L2304;}
	T0= MAKE_FIXNUM(V13);
	goto L2297;
L2304:
	T0= Cnil;
	}
	}
L2297:
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(8)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T1= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(8)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T2= VALUES(0);
	(*LK30)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(12)))) & 0x1fffffff)))/*  ATOM-NAME*/;
	RETURN(funcall(19,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[149],MAKE_FIXNUM(V11),VV[150],T0,VV[152],T1,VV[153],T2,VV[249],VALUES(0)));}}}}
	}
	}
}
/*	function definition for SELECTION-CLEAR-EVENT-PUT             */
static L105(int narg, object V1, ...)
{ VT107 VLEX107 CLSR107
	{object V2;
	register object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[10];
	parse_key(narg,args,5,L105keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	}
	if(((V2))!=Cnil){
	goto L2309;}
	V2= ((V1))->in.in_slots[3];
L2309:
	{object V7;                               /*  %BUFFER         */
	{register int V8;                         /*  BUFFER-BOFFSET  */
	register object V9;                       /*  BUFFER-BBUF     */
	V8= (fix(((V1))->in.in_slots[6]))+(12);
	V9= ((V1))->in.in_slots[7];
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=fix((V2)));
	if(!((V3)==Cnil)){
	goto L2321;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(4))))=0);
	goto L2319;
L2321:
	(*LK24)(2,(V3),VV[161])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2324;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(4))))=fix((V3)));
	goto L2319;
L2324:
	(*LK3)(2,(V3),VV[250])                    /*  X-TYPE-ERROR    */;
L2319:
	L36(3,VV[251],(V5),(V4))                  /*  CHECK-CONSISTENCY*/;
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(8))))=fix((VALUES(0))->in.in_slots[0]));
	(*LK31)(2,(V6),(V1))                      /*  ATOM-ID         */;
	if(VALUES(0)==Cnil)goto L2329;
	T0= VALUES(0);
	goto L2328;
L2329:
	Lerror(1,VV[245])                         /*  ERROR           */;
	T0= VALUES(0);
L2328:
	VALUES(0) = MAKE_FIXNUM(((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(12))))=fix(T0)));
	RETURN(1);
	}
	}
	}
}
/*	function definition for SELECTION-REQUEST-EVENT-GET-MACRO     */
static L106(int narg, object V1, object V2, object V3)
{ VT108 VLEX108 CLSR108
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[252]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for SELECTION-REQUEST-EVENT-GET           */
static L107(int narg, object V1, object V2, object V3)
{ VT109 VLEX109 CLSR109
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	register object V5;                       /*  %BUFFER         */
	V5= (V1);
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{int V11= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	{int V12;
	V12= (*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4))));
	if(!((V12)==0)){
	goto L2340;}
	T0= Cnil;
	goto L2337;
L2340:
	{int V13;
	V13= (*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4))));
	if((MAKE_FIXNUM(V13))==Cnil){
	goto L2344;}
	T0= MAKE_FIXNUM(V13);
	goto L2337;
L2344:
	T0= Cnil;
	}
	}
L2337:
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(8)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T1= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(8)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T2= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(12)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T3= VALUES(0);
	(*LK30)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(16)))) & 0x1fffffff)))/*  ATOM-NAME*/;
	T4= VALUES(0);
	(*LK30)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(20)))) & 0x1fffffff)))/*  ATOM-NAME*/;
	T5= VALUES(0);
	{int V12;
	V12= (*(unsigned long *)(((V7))->ust.ust_self+((V6)+(24))));
	if(!((V12)==0)){
	goto L2354;}
	VALUES(0) = Cnil;
	goto L2351;
L2354:
	{object V13;
	(*LK30)(2,(V5),MAKE_FIXNUM(V12))          /*  ATOM-NAME       */;
	V13= VALUES(0);
	if(((V13))==Cnil){
	goto L2358;}
	VALUES(0) = (V13);
	goto L2351;
L2358:
	VALUES(0) = Cnil;
	}
	}
L2351:
	RETURN(funcall(25,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[149],MAKE_FIXNUM(V11),VV[150],T0,VV[152],T1,VV[153],T2,VV[253],T3,VV[249],T4,VV[254],T5,VV[255],VALUES(0)));}}}}
	}
	}
}
/*	function definition for SELECTION-REQUEST-EVENT-PUT           */
static L108(int narg, object V1, ...)
{ VT110 VLEX110 CLSR110
	{object V2;
	register object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	register object V9;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[16];
	parse_key(narg,args,8,L108keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	V7= keyvars[5];
	V8= keyvars[6];
	V9= keyvars[7];
	}
	if(((V2))!=Cnil){
	goto L2360;}
	V2= ((V1))->in.in_slots[3];
L2360:
	{register object V10;                     /*  %BUFFER         */
	V10= (V1);
	{register int V11;                        /*  BUFFER-BOFFSET  */
	register object V12;                      /*  BUFFER-BBUF     */
	V11= (fix(((V1))->in.in_slots[6]))+(12);
	V12= ((V10))->in.in_slots[7];
	((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(2))))=fix((V2)));
	if(!((V3)==Cnil)){
	goto L2372;}
	((*(unsigned long *)(((V12))->ust.ust_self+((V11)+(4))))=0);
	goto L2370;
L2372:
	(*LK24)(2,(V3),VV[161])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2375;}
	((*(unsigned long *)(((V12))->ust.ust_self+((V11)+(4))))=fix((V3)));
	goto L2370;
L2375:
	(*LK3)(2,(V3),VV[256])                    /*  X-TYPE-ERROR    */;
L2370:
	L36(3,VV[257],(V5),(V4))                  /*  CHECK-CONSISTENCY*/;
	((*(unsigned long *)(((V12))->ust.ust_self+((V11)+(8))))=fix((VALUES(0))->in.in_slots[0]));
	((*(unsigned long *)(((V12))->ust.ust_self+((V11)+(12))))=fix(((V6))->in.in_slots[0]));
	(*LK31)(2,(V7),(V10))                     /*  ATOM-ID         */;
	if(VALUES(0)==Cnil)goto L2382;
	T0= VALUES(0);
	goto L2381;
L2382:
	Lerror(1,VV[245])                         /*  ERROR           */;
	T0= VALUES(0);
L2381:
	((*(unsigned long *)(((V12))->ust.ust_self+((V11)+(16))))=fix(T0));
	(*LK31)(2,(V8),(V10))                     /*  ATOM-ID         */;
	if(VALUES(0)==Cnil)goto L2386;
	T0= VALUES(0);
	goto L2385;
L2386:
	Lerror(1,VV[245])                         /*  ERROR           */;
	T0= VALUES(0);
L2385:
	((*(unsigned long *)(((V12))->ust.ust_self+((V11)+(20))))=fix(T0));
	if(!((V9)==Cnil)){
	goto L2389;}
	VALUES(0) = MAKE_FIXNUM(((*(unsigned long *)(((V12))->ust.ust_self+((V11)+(24))))=0));
	RETURN(1);
L2389:
	(*LK24)(2,(V9),VV[144])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2392;}
	(*LK31)(2,(V9),(V10))                     /*  ATOM-ID         */;
	if(VALUES(0)==Cnil)goto L2395;
	T0= VALUES(0);
	goto L2394;
L2395:
	Lerror(1,VV[245])                         /*  ERROR           */;
	T0= VALUES(0);
L2394:
	VALUES(0) = MAKE_FIXNUM(((*(unsigned long *)(((V12))->ust.ust_self+((V11)+(24))))=fix(T0)));
	RETURN(1);
L2392:
	RETURN((*LK3)(2,(V9),VV[258])             /*  X-TYPE-ERROR    */);
	}
	}
	}
}
/*	function definition for SELECTION-NOTIFY-EVENT-GET-MACRO      */
static L109(int narg, object V1, object V2, object V3)
{ VT111 VLEX111 CLSR111
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[259]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for SELECTION-NOTIFY-EVENT-GET            */
static L110(int narg, object V1, object V2, object V3)
{ VT112 VLEX112 CLSR112
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	register object V5;                       /*  %BUFFER         */
	V5= (V1);
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{int V11= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	{int V12;
	V12= (*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4))));
	if(!((V12)==0)){
	goto L2406;}
	T0= Cnil;
	goto L2403;
L2406:
	{int V13;
	V13= (*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4))));
	if((MAKE_FIXNUM(V13))==Cnil){
	goto L2410;}
	T0= MAKE_FIXNUM(V13);
	goto L2403;
L2410:
	T0= Cnil;
	}
	}
L2403:
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(8)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T1= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(8)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T2= VALUES(0);
	(*LK30)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(12)))) & 0x1fffffff)))/*  ATOM-NAME*/;
	T3= VALUES(0);
	(*LK30)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(16)))) & 0x1fffffff)))/*  ATOM-NAME*/;
	T4= VALUES(0);
	{int V12;
	V12= (*(unsigned long *)(((V7))->ust.ust_self+((V6)+(20))));
	if(!((V12)==0)){
	goto L2419;}
	VALUES(0) = Cnil;
	goto L2416;
L2419:
	{object V13;
	(*LK30)(2,(V5),MAKE_FIXNUM(V12))          /*  ATOM-NAME       */;
	V13= VALUES(0);
	if(((V13))==Cnil){
	goto L2423;}
	VALUES(0) = (V13);
	goto L2416;
L2423:
	VALUES(0) = Cnil;
	}
	}
L2416:
	RETURN(funcall(23,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[149],MAKE_FIXNUM(V11),VV[150],T0,VV[152],T1,VV[153],T2,VV[249],T3,VV[254],T4,VV[255],VALUES(0)));}}}}
	}
	}
}
/*	function definition for SELECTION-NOTIFY-EVENT-PUT            */
static L111(int narg, object V1, ...)
{ VT113 VLEX113 CLSR113
	{object V2;
	register object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	register object V8;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[14];
	parse_key(narg,args,7,L111keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	V7= keyvars[5];
	V8= keyvars[6];
	}
	if(((V2))!=Cnil){
	goto L2425;}
	V2= ((V1))->in.in_slots[3];
L2425:
	{register object V9;                      /*  %BUFFER         */
	V9= (V1);
	{register int V10;                        /*  BUFFER-BOFFSET  */
	register object V11;                      /*  BUFFER-BBUF     */
	V10= (fix(((V1))->in.in_slots[6]))+(12);
	V11= ((V9))->in.in_slots[7];
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(2))))=fix((V2)));
	if(!((V3)==Cnil)){
	goto L2437;}
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(4))))=0);
	goto L2435;
L2437:
	(*LK24)(2,(V3),VV[161])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2440;}
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(4))))=fix((V3)));
	goto L2435;
L2440:
	(*LK3)(2,(V3),VV[260])                    /*  X-TYPE-ERROR    */;
L2435:
	L36(3,VV[261],(V5),(V4))                  /*  CHECK-CONSISTENCY*/;
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(8))))=fix((VALUES(0))->in.in_slots[0]));
	(*LK31)(2,(V6),(V9))                      /*  ATOM-ID         */;
	if(VALUES(0)==Cnil)goto L2446;
	T0= VALUES(0);
	goto L2445;
L2446:
	Lerror(1,VV[245])                         /*  ERROR           */;
	T0= VALUES(0);
L2445:
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(12))))=fix(T0));
	(*LK31)(2,(V7),(V9))                      /*  ATOM-ID         */;
	if(VALUES(0)==Cnil)goto L2450;
	T0= VALUES(0);
	goto L2449;
L2450:
	Lerror(1,VV[245])                         /*  ERROR           */;
	T0= VALUES(0);
L2449:
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(16))))=fix(T0));
	if(!((V8)==Cnil)){
	goto L2453;}
	VALUES(0) = MAKE_FIXNUM(((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(20))))=0));
	RETURN(1);
L2453:
	(*LK24)(2,(V8),VV[144])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2456;}
	(*LK31)(2,(V8),(V9))                      /*  ATOM-ID         */;
	if(VALUES(0)==Cnil)goto L2459;
	T0= VALUES(0);
	goto L2458;
L2459:
	Lerror(1,VV[245])                         /*  ERROR           */;
	T0= VALUES(0);
L2458:
	VALUES(0) = MAKE_FIXNUM(((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(20))))=fix(T0)));
	RETURN(1);
L2456:
	RETURN((*LK3)(2,(V8),VV[262])             /*  X-TYPE-ERROR    */);
	}
	}
	}
}
/*	function definition for COLORMAP-NOTIFY-EVENT-GET-MACRO       */
static L112(int narg, object V1, object V2, object V3)
{ VT114 VLEX114 CLSR114
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[263]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for COLORMAP-NOTIFY-EVENT-GET             */
static L113(int narg, object V1, object V2, object V3)
{ VT115 VLEX115 CLSR115
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	register object V5;                       /*  %BUFFER         */
	V5= (V1);
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{int V11= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T0= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T1= VALUES(0);
	{int V12;
	V12= (*(unsigned long *)(((V7))->ust.ust_self+((V6)+(8))));
	if(!((V12)==0)){
	goto L2472;}
	T2= Cnil;
	goto L2469;
L2472:
	{object V13;
	(*LK32)(2,(V5),MAKE_FIXNUM(V12))          /*  LOOKUP-COLORMAP */;
	V13= VALUES(0);
	if(((V13))==Cnil){
	goto L2476;}
	T2= (V13);
	goto L2469;
L2476:
	T2= Cnil;
	}
	}
L2469:
	{object V12= ((((V7))->ust.ust_self[(V6)+(12)])>0?Ct:Cnil);
	RETURN(funcall(21,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[149],MAKE_FIXNUM(V11),VV[152],T0,VV[153],T1,VV[264],T2,VV[265],(V12),VV[266],((((V7))->ust.ust_self[(V6)+(13)])>0?Ct:Cnil)));}}}}}
	}
	}
}
/*	function definition for COLORMAP-NOTIFY-EVENT-PUT             */
static L114(int narg, object V1, ...)
{ VT116 VLEX116 CLSR116
	{object V2;
	object V3;
	object V4;
	register object V5;
	object V6;
	object V7;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[12];
	parse_key(narg,args,6,L114keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	V7= keyvars[5];
	}
	if(((V2))!=Cnil){
	goto L2478;}
	V2= ((V1))->in.in_slots[3];
L2478:
	{object V8;                               /*  %BUFFER         */
	{register int V9;                         /*  BUFFER-BOFFSET  */
	register object V10;                      /*  BUFFER-BBUF     */
	V9= (fix(((V1))->in.in_slots[6]))+(12);
	V10= ((V1))->in.in_slots[7];
	((*(unsigned short *)(((V10))->ust.ust_self+((V9)+(2))))=fix((V2)));
	L36(3,VV[267],(V4),(V3))                  /*  CHECK-CONSISTENCY*/;
	((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(4))))=fix((VALUES(0))->in.in_slots[0]));
	if(!((V5)==Cnil)){
	goto L2492;}
	((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(8))))=0);
	goto L2490;
L2492:
	(*LK33)(1,(V5))                           /*  COLORMAP-P      */;
	if(VALUES(0)==Cnil){
	goto L2495;}
	((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(8))))=fix(((V5))->in.in_slots[0]));
	goto L2490;
L2495:
	(*LK3)(2,(V5),VV[269])                    /*  X-TYPE-ERROR    */;
L2490:
	if(((V6))==Cnil){
	goto L2500;}
	T0= MAKE_FIXNUM(1);
	goto L2498;
L2500:
	T0= MAKE_FIXNUM(0);
L2498:
	(((V10))->ust.ust_self[(V9)+(12)]=(fix(T0)));
	if(((V7))==Cnil){
	goto L2504;}
	T0= MAKE_FIXNUM(1);
	goto L2502;
L2504:
	T0= MAKE_FIXNUM(0);
L2502:
	VALUES(0) = MAKE_FIXNUM((((V10))->ust.ust_self[(V9)+(13)]=(fix(T0))));
	RETURN(1);
	}
	}
	}
}
/*	function definition for CLIENT-MESSAGE-EVENT-GET-MACRO        */
static L115(int narg, object V1, object V2, object V3)
{ VT117 VLEX117 CLSR117
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[270]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for CLIENT-MESSAGE-EVENT-GET              */
static L116(int narg, object V1, object V2, object V3)
{ VT118 VLEX118 CLSR118
TTL:
	{volatile object V4;                      /*  %REPLY-BUFFER   */
	volatile object V5;                       /*  %BUFFER         */
	V5= (V1);
	{volatile int V6;                         /*  BUFFER-BOFFSET  */
	volatile object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{int V11= ((V7))->ust.ust_self[(V6)+(1)];
	{int V12= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T0= VALUES(0);
	(*LK23)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(4)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	T1= VALUES(0);
	(*LK30)(2,(V5),MAKE_FIXNUM(((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(8)))) & 0x1fffffff)))/*  ATOM-NAME*/;
	T2= VALUES(0);
	{volatile int V13;                        /*  FORMAT          */
	volatile object V14;                      /*  SEQUENCE        */
	V13= ((V7))->ust.ust_self[(V6)+(1)];
	Lceiling(2,MAKE_FIXNUM(160),MAKE_FIXNUM(V13))/*  CEILING      */;
	T3= VALUES(0);
	(*LK7)(3,T3,VV[40],list(2,VV[274],MAKE_FIXNUM(V13)))/*  MAKE-ARRAY*/;
	V14= VALUES(0);
	{volatile object V15;                     /*  I               */
	volatile object V16;                      /*  J               */
	V15= MAKE_FIXNUM(12);
	V16= MAKE_FIXNUM(0);
L2521:
	if(!(number_compare((V15),MAKE_FIXNUM(32))>=0)){
	goto L2522;}
	goto L2519;
L2522:
	{register object V18;
	V18= MAKE_FIXNUM(V13);
	if(!(eql((V18),MAKE_FIXNUM(8)))){
	goto L2527;}
	{object V19;
	object V20;
	V19= (V14);
	V20= (V16);
	aset1((V19),fix((V20)),MAKE_FIXNUM(((V7))->ust.ust_self[(V6)+(fix((V15)))]));
	}
	V15= number_plus((V15),MAKE_FIXNUM(1));
	goto L2525;
L2527:
	if(!(eql((V18),MAKE_FIXNUM(16)))){
	goto L2534;}
	{object V19;
	object V20;
	V19= (V14);
	V20= (V16);
	aset1((V19),fix((V20)),MAKE_FIXNUM((*(unsigned short *)(((V7))->ust.ust_self+((V6)+(fix((V15))))))));
	}
	V15= number_plus((V15),MAKE_FIXNUM(2));
	goto L2525;
L2534:
	if(!(eql((V18),MAKE_FIXNUM(32)))){
	goto L2525;}
	{object V19;
	object V20;
	V19= (V14);
	V20= (V16);
	aset1((V19),fix((V20)),MAKE_FIXNUM((*(unsigned long *)(((V7))->ust.ust_self+((V6)+(fix((V15))))))));
	}
	V15= number_plus((V15),MAKE_FIXNUM(4));
	}
L2525:
	V16= one_plus((V16));
	goto L2521;
	}
L2519:
	VALUES(0) = (V14);
	}
	RETURN(funcall(21,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[271],MAKE_FIXNUM(V11),VV[149],MAKE_FIXNUM(V12),VV[152],T0,VV[153],T1,VV[272],T2,VV[273],VALUES(0)));}}}}}
	}
	}
}
/*	function definition for CLIENT-MESSAGE-EVENT-PUT              */
static L117(int narg, object V1, ...)
{ VT119 VLEX119 CLSR119
	{object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	register object V7;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[12];
	parse_key(narg,args,6,L117keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	V6= keyvars[4];
	V7= keyvars[5];
	}
	if(((V3))!=Cnil){
	goto L2549;}
	V3= ((V1))->in.in_slots[3];
L2549:
	{register object V8;                      /*  %BUFFER         */
	V8= (V1);
	{register int V9;                         /*  BUFFER-BOFFSET  */
	register object V10;                      /*  BUFFER-BBUF     */
	V9= (fix(((V1))->in.in_slots[6]))+(12);
	V10= ((V8))->in.in_slots[7];
	(((V10))->ust.ust_self[(V9)+(1)]=(fix((V2))));
	((*(unsigned short *)(((V10))->ust.ust_self+((V9)+(2))))=fix((V3)));
	L36(3,VV[275],(V5),(V4))                  /*  CHECK-CONSISTENCY*/;
	((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(4))))=fix((VALUES(0))->in.in_slots[0]));
	(*LK31)(2,(V6),(V8))                      /*  ATOM-ID         */;
	if(VALUES(0)==Cnil)goto L2564;
	T0= VALUES(0);
	goto L2563;
L2564:
	Lerror(1,VV[245])                         /*  ERROR           */;
	T0= VALUES(0);
L2563:
	((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(8))))=fix(T0));
	if(!eql((V2),VV[276]))goto L2566;
	{object V11= MAKE_FIXNUM(length((V7)));
	RETURN((*LK34)(6,(V8),MAKE_FIXNUM((V9)+(12)),(V7),MAKE_FIXNUM(0),(number_compare(V11,MAKE_FIXNUM(20))<=0?V11:MAKE_FIXNUM(20)),Cnil)/*  WRITE-SEQUENCE-CARD8*/);}
L2566:
	if(!eql((V2),VV[277]))goto L2567;
	{object V12= MAKE_FIXNUM(length((V7)));
	RETURN((*LK35)(6,(V8),MAKE_FIXNUM((V9)+(12)),(V7),MAKE_FIXNUM(0),(number_compare(V12,MAKE_FIXNUM(10))<=0?V12:MAKE_FIXNUM(10)),Cnil)/*  WRITE-SEQUENCE-CARD16*/);}
L2567:
	if(!eql((V2),VV[278]))goto L2568;
	{object V13= MAKE_FIXNUM(length((V7)));
	RETURN((*LK36)(6,(V8),MAKE_FIXNUM((V9)+(12)),(V7),MAKE_FIXNUM(0),(number_compare(V13,MAKE_FIXNUM(5))<=0?V13:MAKE_FIXNUM(5)),Cnil)/*  WRITE-SEQUENCE-CARD32*/);}
L2568:
	FEerror("The ECASE key value ~s is illegal.",1,(V2));
	}
	}
	}
}
/*	function definition for MAPPING-NOTIFY-EVENT-GET-MACRO        */
static L118(int narg, object V1, object V2, object V3)
{ VT120 VLEX120 CLSR120
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	Lgetf(2,listA(9,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[29],VV[145],VV[112],VV[146],VV[279]),(V3))/*  GETF*/;
	RETURN(Lsubst(3,(V1),VV[143],VALUES(0))   /*  SUBST           */);}
}
/*	function definition for MAPPING-NOTIFY-EVENT-GET              */
static L119(int narg, object V1, object V2, object V3)
{ VT121 VLEX121 CLSR121
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	object V5;                                /*  %BUFFER         */
	{register int V6;                         /*  BUFFER-BOFFSET  */
	register object V7;                       /*  BUFFER-BBUF     */
	V6= 0;
	V7= ((V2))->in.in_slots[1];
	{object V8= ((VV[4]->s.s_dbind))->v.v_self[fix(((V2))->in.in_slots[0])];
	{int V9= ((127) & (((V7))->ust.ust_self[(V6)+(0)]));
	{object V10= ((((V7))->ust.ust_self[(V6)+(0)] >> 7) & 1?Ct:Cnil);
	{int V11= (*(unsigned short *)(((V7))->ust.ust_self+((V6)+(2))));
	{int V12;
	V12= ((V7))->ust.ust_self[(V6)+(4)];
	if((V12)<(3)){
	goto L2577;}
	T0= Cnil;
	goto L2575;
L2577:
	T0= (VV[281])->v.v_self[V12];
	}
L2575:
	{int V12= ((V7))->ust.ust_self[(V6)+(5)];
	RETURN(funcall(17,(V3),VV[30],(V1),VV[109],(V8),VV[29],MAKE_FIXNUM(V9),VV[112],(V10),VV[149],MAKE_FIXNUM(V11),VV[280],T0,VV[25],MAKE_FIXNUM(V12),VV[194],MAKE_FIXNUM(((V7))->ust.ust_self[(V6)+(6)])));}}}}}
	}
	}
}
/*	function definition for MAPPING-NOTIFY-EVENT-PUT              */
static L120(int narg, object V1, ...)
{ VT122 VLEX122 CLSR122
	{object V2;
	object V3;
	object V4;
	object V5;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[8];
	parse_key(narg,args,4,L120keys,keyvars,OBJNULL,TRUE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	}
	if(((V2))!=Cnil){
	goto L2579;}
	V2= ((V1))->in.in_slots[3];
L2579:
	{object V6;                               /*  %BUFFER         */
	{register int V7;                         /*  BUFFER-BOFFSET  */
	register object V8;                       /*  BUFFER-BBUF     */
	V7= (fix(((V1))->in.in_slots[6]))+(12);
	V8= ((V1))->in.in_slots[7];
	((*(unsigned short *)(((V8))->ust.ust_self+((V7)+(2))))=fix((V2)));
	VALUES(0) = (VV[870]->s.s_gfdef);
	(*LK4)(4,(V3),VV[282],VV[178],VALUES(0))  /*  POSITION        */;
	T0= VALUES(0);
	(((V8))->ust.ust_self[(V7)+(4)]=(fix(T0)));
	(((V8))->ust.ust_self[(V7)+(5)]=(fix((V4))));
	VALUES(0) = MAKE_FIXNUM((((V8))->ust.ust_self[(V7)+(6)]=(fix((V5)))));
	RETURN(1);
	}
	}
	}
}
/*	function definition for EVENT-LOOP-SETUP                      */
static L121(int narg, object V1)
{ VT123 VLEX123 CLSR123
TTL:
	{object V2;                               /*  PROGV-VARS      */
	object V3;                                /*  CURRENT-EVENT-SYMBOL*/
	object V4;                                /*  CURRENT-EVENT-DISCARDED-P-SYMBOL*/
	V2= ((V1))->in.in_slots[67];
	V3= CAR((V2));
	V4= CADR((V2));
	if(!(((V3))->s.s_dbind!=OBJNULL)){
	goto L2598;}
	{object V5;                               /*  EVENT           */
	Lsymbol_value(1,(V3))                     /*  SYMBOL-VALUE    */;
	V5= VALUES(0);
	if((V5)==Cnil){
	VALUES(0) = Cnil;
	goto L2596;}
	VALUES(0) = ((V5))->in.in_slots[2];
	goto L2596;
	}
L2598:
	VALUES(0) = ((V1))->in.in_slots[24];
L2596:
	VALUES(3) = (V4);
	VALUES(2) = (V3);
	VALUES(1) = list(2,VALUES(0),Cnil);
	VALUES(0) = (V2);
	RETURN(4);
	}
}
/*	function definition for EVENT-LOOP-STEP-BEFORE                */
static L122(int narg, object V1, object V2, object V3, object V4)
{ VT124 VLEX124 CLSR124
TTL:
	Lsymbol_value(1,(V4))                     /*  SYMBOL-VALUE    */;
	if(VALUES(0)!=Cnil){
	goto L2601;}
	{object V5;                               /*  EOF-OR-TIMEOUT  */
	L21(3,(V1),(V2),(V3))                     /*  WAIT-FOR-EVENT  */;
	V5= VALUES(0);
	if(((V5))==Cnil){
	goto L2604;}
	VALUES(1) = (V5);
	VALUES(0) = Cnil;
	RETURN(2);
	}
L2604:
	Lset(2,(V4),((V1))->in.in_slots[66])      /*  SET             */;
L2601:
	{object V5;                               /*  EVENT           */
	Lsymbol_value(1,(V4))                     /*  SYMBOL-VALUE    */;
	V5= VALUES(0);
	if(!(((V5))==(((V1))->in.in_slots[66]))){
	goto L2609;}
	((V1))->in.in_slots[66]= ((V5))->in.in_slots[2];
L2609:
	VALUES(1) = Cnil;
	VALUES(0) = (V5);
	RETURN(2);
	}
}
/*	function definition for DEQUEUE-EVENT                         */
static L123(int narg, object V1, object V2)
{ VT125 VLEX125 CLSR125
TTL:
	{volatile object V3;                      /*  NEXT            */
	volatile object V4;                       /*  HEAD            */
	V3= ((V2))->in.in_slots[2];
	V4= ((V1))->in.in_slots[24];
	if(!(((V2))==(((V1))->in.in_slots[66]))){
	goto L2614;}
	((V1))->in.in_slots[66]= (V3);
L2614:
	if(!(((V2))==((V4)))){
	goto L2619;}
	{object V5;
	V5= ((V1))->in.in_slots[24];
	if(((V5))==Cnil){
	goto L2622;}
	if(!(((V5))==(((V1))->in.in_slots[23]))){
	goto L2625;}
	((V1))->in.in_slots[23]= ((V5))->in.in_slots[2];
L2625:
	((V1))->in.in_slots[24]= ((V5))->in.in_slots[2];
L2622:
	goto L2617;
	}
L2619:
	if(((V4))!=Cnil){
	goto L2629;}
	V3= Cnil;
	goto L2617;
L2629:
	{volatile object V6;                      /*  PREVIOUS        */
	volatile object V7;                       /*  CURRENT         */
	V6= (V4);
	V7= ((V6))->in.in_slots[2];
L2635:
	if(((V7))==Cnil){
	goto L2637;}
	if(!(((V2))==((V7)))){
	goto L2636;}
L2637:
	if(!(((V2))==((V7)))){
	goto L2617;}
	if(!(((V7))==(((V1))->in.in_slots[23]))){
	goto L2643;}
	((V1))->in.in_slots[23]= (V6);
L2643:
	((V6))->in.in_slots[2]= (V3);
	goto L2617;
L2636:
	V6= (V7);
	V7= ((V6))->in.in_slots[2];
	goto L2635;
	}
L2617:
	VALUES(0) = (V3);
	RETURN(1);
	}
}
/*	function definition for EVENT-LOOP-STEP-AFTER                 */
static L124(int narg, object V1, object V2, object V3, object V4, object V5, ...)
{ VT126 VLEX126 CLSR126
	{int i=5;
	object V6;
	va_list args; va_start(args, V5);
	if (i==narg) goto L2651;
	V6= va_arg(args, object);
	i++;
	goto L2652;
L2651:
	V6= Cnil;
L2652:
	if(((V3))==Cnil){
	goto L2654;}
	if(((V6))!=Cnil){
	goto L2654;}
	Lsymbol_value(1,(V5))                     /*  SYMBOL-VALUE    */;
	if(VALUES(0)!=Cnil){
	goto L2654;}
	L126(1,(V1))                              /*  DISCARD-CURRENT-EVENT*/;
L2654:
	{object V7;                               /*  NEXT            */
	V7= ((V2))->in.in_slots[2];
	Lsymbol_value(1,(V5))                     /*  SYMBOL-VALUE    */;
	if(VALUES(0)==Cnil){
	goto L2662;}
	Lset(2,(V5),Cnil)                         /*  SET             */;
	L123(2,(V1),(V2))                         /*  DEQUEUE-EVENT   */;
	V7= VALUES(0);
	L2(1,(V2))                                /*  DEALLOCATE-EVENT*/;
L2662:
	RETURN(Lset(2,(V4),(V7))                  /*  SET             */);
	}
	}
}
/*	macro definition for EVENT-LOOP                               */
static L125(int narg, object V1, object V2)
{ VT127 VLEX127 CLSR127
	{object V3=CDR(V1),V4,V5,V6,V7,V8,V9;
	{object V10= CAR(V3);
	V4= CAR(V10);
	V10=CDR(V10);
	V5= CAR(V10);
	V10=CDR(V10);
	V6= CAR(V10);
	V10=CDR(V10);
	V7= CAR(V10);
	V10=CDR(V10);
	V8= CAR(V10);}
	V3=CDR(V3);
	V9= V3;
	{object V11= list(2,VV[283],(V4));
	{object V12= list(2,VV[284],(V6));
	{object V13= list(2,VV[285],(V7));
	{object V14= list(4,(V11),(V12),(V13),list(2,VV[286],(V8)));
	if((V6)==Cnil){
	VALUES(0) = Cnil;
	goto L2668;}
	VALUES(0) = VV[289];
L2668:
	{object V15= CONS(VV[283],VALUES(0));
	{object V16= CONS(list(2,(V5),VV[305]),Cnil);
	VALUES(0) = list(4,VV[133],(V14),VV[287],list(3,VV[288],(V15),list(5,VV[290],VV[291],VV[292],VV[293],list(4,VV[294],VV[295],VV[296],list(2,VV[297],list(6,VV[290],VV[298],VV[299],VV[300],VV[301],list(3,VV[133],VV[302],list(3,VV[303],list(3,VV[304],listA(4,VV[133],(V16),list(2,VV[306],list(3,VV[307],VV[12],(V5))),(V9)),VV[308]),VV[309]))))))));
	RETURN(1);}}}}}}}
}
/*	function definition for DISCARD-CURRENT-EVENT                 */
static L126(int narg, object V1)
{ VT128 VLEX128 CLSR128
TTL:
	{object V2;                               /*  SYMBOLS         */
	object V3;                                /*  EVENT           */
	V2= ((V1))->in.in_slots[67];
	{object V4;                               /*  CURRENT-EVENT-SYMBOL*/
	V4= CAR((V2));
	if(!(((V4))->s.s_dbind!=OBJNULL)){
	goto L2673;}
	Lsymbol_value(1,(V4))                     /*  SYMBOL-VALUE    */;
	V3= VALUES(0);
	goto L2670;
L2673:
	V3= Cnil;
	}
L2670:
	if(((V3))==Cnil){
	goto L2676;}
	{object V4;                               /*  CURRENT-EVENT-DISCARDED-P-SYMBOL*/
	V4= CADR((V2));
	if(!(((V4))->s.s_dbind!=OBJNULL)){
	goto L2678;}
	Lset(2,(V4),Ct)                           /*  SET             */;
	}
L2678:
	VALUES(0) = (((((V3))->in.in_slots[2]==Cnil?Ct:Cnil))==Cnil?Ct:Cnil);
	RETURN(1);
L2676:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for PROCESS-EVENT                         */
static L127(int narg, object V1, ...)
{ VT129 VLEX129 CLSR129
	{volatile object V2;
	volatile object V3;
	volatile object V4;
	volatile object V5;
	volatile object V6;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[10];
	parse_key(narg,args,5,L127keys,keyvars,OBJNULL,FALSE);
	V2= keyvars[0];
	V3= keyvars[1];
	V4= keyvars[2];
	V5= keyvars[3];
	if(keyvars[9]==Cnil){
	V6= Ct;
	}else{
	V6= keyvars[4];}
	}
	{volatile object V7;                      /*  .DISPLAY.       */
	volatile object V8;                       /*  .TIMEOUT.       */
	volatile object V9;                       /*  .FORCE-OUTPUT-P.*/
	volatile object V10;                      /*  .DISCARD-P.     */
	V7= (V1);
	V8= (V3);
	V9= (V6);
	V10= (V5);
	{ int V11;
	volatile object V12;                      /*  .PROGV-VARS.    */
	volatile object V13;                      /*  .PROGV-VALS.    */
	volatile object V14;                      /*  .CURRENT-EVENT-SYMBOL.*/
	volatile object V15;                      /*  .CURRENT-EVENT-DISCARDED-P-SYMBOL.*/
	V11=L121(1,(V7))                          /*  EVENT-LOOP-SETUP*/;
	if (V11--==0) goto L2684;
	V12= VALUES(0);
	if (V11--==0) goto L2685;
	V13= VALUES(1);
	if (V11--==0) goto L2686;
	V14= VALUES(2);
	if (V11--==0) goto L2687;
	V15= VALUES(3);
	goto L2688;
L2684:
	V12= Cnil;
L2685:
	V13= Cnil;
L2686:
	V14= Cnil;
L2687:
	V15= Cnil;
L2688:
	{object V17,V18;
	bds_ptr V16=bds_top;
	V17= (V12);
	V18= (V13);
	while(!endp(V17)) {
	if(endp(V18))bds_bind(CAR(V17),OBJNULL);
	else{bds_bind(CAR(V17),CAR(V18));
	V18=CDR(V18);}
	V17=CDR(V17);}
	{ int V16; object (V17);
	V17= new_frame_id();
	if ((V16=frs_push(FRS_CATCH,(V17)))!=0) V16--;
	else {
L2693:
	{ int V18;
	volatile object V19;                      /*  .EVENT.         */
	volatile object V20;                      /*  .EOF-OR-TIMEOUT.*/
	V18=L122(4,(V7),(V8),(V9),(V14))          /*  EVENT-LOOP-STEP-BEFORE*/;
	if (V18--==0) goto L2696;
	V19= VALUES(0);
	if (V18--==0) goto L2697;
	V20= VALUES(1);
	goto L2698;
L2696:
	V19= Cnil;
L2697:
	V20= Cnil;
L2698:
	if(((V19))!=Cnil){
	goto L2699;}
	VALUES(1) = (V20);
	VALUES(0) = Cnil;
	bds_unwind(V16);
	RETURN(2);
L2699:
	{volatile object V21;                     /*  .ABORTED.       */
	V21= Ct;
	{ int V22; volatile bool unwinding = FALSE;
	if ((V22=frs_push(FRS_PROTECT,Cnil))) {
	V22--; unwinding = TRUE;} else {
	{register object V23;                     /*  EVENT           */
	V23= (V19);
	{register int V24;                        /*  EVENT-CODE      */
	register object V25;                      /*  EVENT-DECODER   */
	V24= fix(((V23))->in.in_slots[0]);
	if((V24)<(((VV[8]->s.s_dbind))->v.v_fillp)){
	goto L2706;}
	V25= Cnil;
	goto L2705;
L2706:
	V25= ((VV[8]->s.s_dbind))->v.v_self[V24];
L2705:
	if(((V25))==Cnil){
	goto L2709;}
	{register object V26;                     /*  EVENT-HANDLER   */
	Lfunctionp(1,(V2))                        /*  FUNCTIONP       */;
	if(VALUES(0)==Cnil){
	goto L2713;}
	V26= (V2);
	goto L2711;
L2713:
	(*LK24)(2,(V2),VV[129])                   /*  TYPEP           */;
	if(VALUES(0)!=Cnil){
	goto L2715;}
	V26= Cnil;
	goto L2711;
L2715:
	if((V24)<(length((V2)))){
	goto L2717;}
	V26= Cnil;
	goto L2711;
L2717:
	V26= elt((V2),V24);
L2711:
	if(((V26))==Cnil){
	goto L2720;}
	{register object V27;                     /*  RESULT          */
	funcall(4,(V25),(V1),(V23),(V26));
	V27= VALUES(0);
	if(((V27))==Cnil){
	goto L2703;}
	if(((V4))!=Cnil){
	goto L2725;}
	L126(1,(V1))                              /*  DISCARD-CURRENT-EVENT*/;
L2725:
	{ int V28;
	VALUES(0)=(V27);
	V28=1;
	unwind(frs_sch((V17)),Cnil,V28+1);}
	}
L2720:
	Lcerror(3,VV[310],VV[311],((VV[4]->s.s_dbind))->v.v_self[V24])/*  CERROR*/;
	goto L2703;
	}
L2709:
	Lcerror(3,VV[312],VV[313],MAKE_FIXNUM(V24))/*  CERROR         */;
	}
	}
L2703:
	V21= Cnil;
	VALUES(0)=Cnil;
	V22=1;
	}
	frs_pop();
	MV_SAVE(V22);
	L124(6,(V7),(V19),(V10),(V14),(V15),(V21))/*  EVENT-LOOP-STEP-AFTER*/;
	MV_RESTORE(V22);
	if (unwinding) unwind(nlj_fr,nlj_tag,V22+1);
	else {}}
	}}
	goto L2693;}
	frs_pop();
	bds_unwind(V16);
	RETURN(V16);
	}}}
	}
	}
}
/*	function definition for MAKE-EVENT-HANDLERS                   */
static L128(int narg, ...)
{ VT130 VLEX130 CLSR130
	{object V1;
	object V2;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[4];
	parse_key(narg,args,2,L128keys,keyvars,OBJNULL,FALSE);
	if(keyvars[2]==Cnil){
	V1= VV[314];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	}
	RETURN((*LK37)(4,(V1),MAKE_FIXNUM(64),VV[3],(V2))/*  MAKE-SEQUENCE*/);
	}
}
/*	function definition for EVENT-HANDLER                         */
static L129(int narg, object V1, object V2)
{ VT131 VLEX131 CLSR131
TTL:
	{object V3= (VV[4]->s.s_dbind);
	VALUES(0) = (VV[870]->s.s_gfdef);
	(*LK4)(4,(V2),V3,VV[178],VALUES(0))       /*  POSITION        */;
	VALUES(0) = elt((V1),fix(VALUES(0)));
	RETURN(1);}
}
/*	function definition for SET-EVENT-HANDLER                     */
static L130(int narg, object V1, object V2, object V3)
{ VT132 VLEX132 CLSR132
TTL:
	{object V4= (VV[4]->s.s_dbind);
	VALUES(0) = (VV[870]->s.s_gfdef);
	(*LK4)(4,(V2),V4,VV[178],VALUES(0))       /*  POSITION        */;
	VALUES(0) = elt_set((V1),fix(VALUES(0)),(V3));
	RETURN(1);}
}
/*	macro definition for EVENT-CASE                               */
static L131(int narg, object V1, object V2)
{ VT133 VLEX133 CLSR133
	{object V3=CDR(V1),V4,V5;
	{object V6= CAR(V3);
	V4= V6;}
	V3=CDR(V3);
	V5= V3;
	{object V7;
	object V8= (V5);
	if(V8==Cnil){
	VALUES(0) = Cnil;
	goto L2737;}
	T0=V7=CONS(Cnil,Cnil);
L2738:
	{object V9;                               /*  CLAUSE          */
	V9= CAR(V8);
	{object V10= CAR((V9));
	{object V11= CADR((V9));
	CAR(V7)= list(3,(V10),(V11),CONS(VV[304],CDDR((V9))));}}
	}
	if((V8=CDR(V8))==Cnil){
	VALUES(0) = T0;
	goto L2737;}
	V7=CDR(V7)=CONS(Cnil,Cnil);
	goto L2738;}
L2737:
	VALUES(0) = listA(3,VV[321],(V4),VALUES(0));
	RETURN(1);}
}
/*	macro definition for EVENT-COND                               */
static L133(int narg, object V1, object V2)
{ VT134 VLEX134 CLSR134
	{object V3=CDR(V1),V4,V5,V6,V7,V8,V9;
	{object V10= CAR(V3);
	V4= CAR(V10);
	V10=CDR(V10);
	{object V11;
	V11=getf(V10,VV[48],OBJNULL);
	if(V11==OBJNULL){
	V5= Cnil;
	} else {
	V5= V11;}
	V11=getf(V10,VV[964],OBJNULL);
	if(V11==OBJNULL){
	V6= Cnil;
	} else {
	V6= V11;}
	V11=getf(V10,VV[965],OBJNULL);
	if(V11==OBJNULL){
	V7= Cnil;
	} else {
	V7= V11;}
	V11=getf(V10,VV[966],OBJNULL);
	if(V11==OBJNULL){
	V8= Ct;
	} else {
	V8= V11;}}}
	V3=CDR(V3);
	V9= V3;
	{object V12;                              /*  EVENT           */
	object V13;
	register object V14;                      /*  DISP            */
	object V15;
	object V16;                               /*  PEEK            */
	Lgensym(0)                                /*  GENSYM          */;
	V13= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V15= VALUES(0);
	Lgensym(0)                                /*  GENSYM          */;
	V16= VALUES(0);
	V12= V13;
	V14= V15;
	{object V17= list(2,(V14),(V4));
	{object V18= list(2,(V17),list(2,(V16),(V6)));
	{object V19= list(2,VV[306],list(3,VV[307],VV[26],(V14)));
	{object V20= list(5,(V14),(V12),(V5),(V8),(V7));
	VALUES(0) = list(4,VV[133],(V18),(V19),list(3,VV[322],(V20),listA(3,VV[323],list(3,(V14),(V12),(V16)),(V9))));
	RETURN(1);}}}}
	}}
}
/*	function definition for GET-EVENT-CODE                        */
static L134(int narg, object V1)
{ VT135 VLEX135 CLSR135
TTL:
	VALUES(0) = getf((V1)->s.s_plist,VV[23],Cnil);
	if(VALUES(0)==Cnil)goto L2747;
	RETURN(1);
L2747:
	RETURN((*LK3)(2,(V1),VV[24])              /*  X-TYPE-ERROR    */);
}
/*	function definition for UNIVERSAL-EVENT-GET-MACRO             */
static L135(int narg, object V1, object V2, object V3)
{ VT136 VLEX136 CLSR136
TTL:
	{object V4= list(3,VV[58],VV[26],(V1));
	RETURN(Lgetf(2,listA(5,VV[30],(V4),VV[109],list(3,VV[58],VV[144],(V2)),VV[324]),(V3))/*  GETF*/);}
}
/*	macro definition for EVENT-DISPATCH                           */
static L136(int narg, object V1, object V2)
{ VT137 VLEX137 CLSR137
	{object V3=CDR(V1),V4,V5,V6,V7;
	{object V8= CAR(V3);
	V4= CAR(V8);
	V8=CDR(V8);
	V5= CAR(V8);
	V8=CDR(V8);
	V6= CAR(V8);}
	V3=CDR(V3);
	V7= V3;
	{volatile object V9;                      /*  EVENT-KEY       */
	volatile object V10;
	volatile object V11;                      /*  ALL-EVENTS      */
	Lgensym(0)                                /*  GENSYM          */;
	V10= VALUES(0);
	(*LK7)(5,MAKE_FIXNUM(64),VV[40],VV[325],VV[3],MAKE_FIXNUM(0))/*  MAKE-ARRAY*/;
	V11= VALUES(0);
	V9= V10;
	{object V12= CONS((V5),Cnil);
	{object V13= CONS(list(2,(V9),list(3,VV[57],VV[4],list(2,VV[23],(V5)))),Cnil);
	{object V14;
	object V15= (V7);
	if(V15==Cnil){
	VALUES(0) = Cnil;
	goto L2751;}
	T0=V14=CONS(Cnil,Cnil);
L2752:
	{volatile object V16;                     /*  CLAUSE          */
	V16= CAR(V15);
	{volatile object V17;                     /*  EVENTS          */
	volatile object V18;                      /*  ARGLIST         */
	volatile object V19;                      /*  TEST-FORM       */
	volatile object V20;                      /*  BODY-FORMS      */
	V17= CAR((V16));
	V18= CADR((V16));
	V19= CADDR((V16));
	V20= CDDDR((V16));
	if((memql((V17),VV[327]))==Cnil){
	goto L2759;}
	{volatile object V21;                     /*  KEYS            */
	{volatile int V22;                        /*  I               */
	volatile object V23;                      /*  KEY             */
	volatile object V24;                      /*  RESULT          */
	V22= 0;
	V23= Cnil;
	V24= Cnil;
L2764:
	if(!((V22)>=(64))){
	goto L2765;}
	V21= (V24);
	goto L2761;
L2765:
	V23= ((VV[4]->s.s_dbind))->v.v_self[V22];
	if(((V23))==Cnil){
	goto L2770;}
	if(!(number_compare(MAKE_FIXNUM(0),aref1((V11),V22))==0)){
	goto L2770;}
	V24= CONS((V23),(V24));
L2770:
	V22= (V22)+1;
	goto L2764;
	}
L2761:
	if((V21)!=Cnil){
	VALUES(0) = (V21);
	goto L2779;}
	VALUES(0) = VV[330];
L2779:
	{object V22= listA(4,(V4),(V9),VALUES(0),(V18));
	LC137(4,(V4),(V6),(V19),(V20))            /*  EVENT-CLAUSE    */;
	CAR(V14)= list(2,VV[328],list(3,VV[329],(V22),VALUES(0)));
	goto L2753;}
	}
L2759:
	{volatile object V23;                     /*  TRUE-EVENTS     */
	V23= Cnil;
	if(!(type_of((V17))==t_cons)){
	goto L2783;}
	{object V24;
	object V25= (V17);
	if(V25==Cnil){
	V23= Cnil;
	goto L2786;}
	T1=V24=CONS(Cnil,Cnil);
L2787:
	L4(1,CAR(V25))                            /*  CANONICALIZE-EVENT-NAME*/;
	CAR(V24)= VALUES(0);
	if((V25=CDR(V25))==Cnil){
	V23= T1;
	goto L2786;}
	V24=CDR(V24)=CONS(Cnil,Cnil);
	goto L2787;}
L2786:
	{volatile object V24;
	volatile object V25;                      /*  EVENT           */
	V24= (V23);
	V25= Cnil;
L2792:
	if(!((V24)==Cnil)){
	goto L2793;}
	goto L2781;
L2793:
	V25= CAR((V24));
	{register object V27;
	register object V28;
	V27= (V11);
	L134(1,(V25))                             /*  GET-EVENT-CODE  */;
	V28= VALUES(0);
	aset1((V27),fix((V28)),MAKE_FIXNUM(1));
	}
	V24= CDR((V24));
	goto L2792;
	}
L2783:
	L4(1,(V17))                               /*  CANONICALIZE-EVENT-NAME*/;
	V23= VALUES(0);
	{object V29;
	L134(1,(V23))                             /*  GET-EVENT-CODE  */;
	V29= VALUES(0);
	aset1((V11),fix((V29)),MAKE_FIXNUM(1));
	}
L2781:
	{object V24= listA(4,(V4),(V9),(V23),(V18));
	LC137(4,(V4),(V6),(V19),(V20))            /*  EVENT-CLAUSE    */;
	CAR(V14)= list(2,(V23),list(3,VV[329],(V24),VALUES(0)));}
	}
	}
	}
L2753:
	if((V15=CDR(V15))==Cnil){
	VALUES(0) = T0;
	goto L2751;}
	V14=CDR(V14)=CONS(Cnil,Cnil);
	goto L2752;}
L2751:
	VALUES(0) = list(3,VV[118],(V12),list(3,VV[133],(V13),listA(3,VV[326],(V9),VALUES(0))));
	RETURN(1);}}
	}}
}
/*	local function EVENT-CLAUSE                                   */
static LC137(int narg, object V1, object V2, object V3, object V4)
{ VT138 VLEX138 CLSR138
TTL:
	if(((V4))==Cnil){
	goto L2809;}
	{object V5= list(3,VV[332],(V2),list(2,VV[333],(V1)));
	VALUES(0) = list(4,VV[331],(V3),(V5),list(2,VV[334],CONS(VV[304],(V4))));
	RETURN(1);}
L2809:
	{object V6;                               /*  RESULT          */
	Lgensym(0)                                /*  GENSYM          */;
	V6= VALUES(0);
	{object V7= CONS(list(2,(V6),(V3)),Cnil);
	{object V8= list(3,VV[332],(V2),list(2,VV[333],(V1)));
	VALUES(0) = list(3,VV[133],(V7),list(4,VV[331],(V6),(V8),list(2,VV[334],(V6))));
	RETURN(1);}}
	}
}
/*	macro definition for BINDING-EVENT-VALUES                     */
static L139(int narg, object V1, object V2)
{ VT139 VLEX139 CLSR139
	{object V3=CDR(V1),V4,V5,V6,V7,V8;
	{object V9= CAR(V3);
	V4= CAR(V9);
	V9=CDR(V9);
	V5= CAR(V9);
	V9=CDR(V9);
	V6= CAR(V9);
	V9=CDR(V9);
	V7= V9;}
	V3=CDR(V3);
	V8= V3;
	if(type_of((V6))==t_cons){
	goto L2812;}
	V6= CONS((V6),Cnil);
L2812:
	{volatile object V10;                     /*  VARS            */
	volatile object V11;                      /*  MULTIPLE-P      */
	{object V12;
	object V13= (V7);
	if(V13==Cnil){
	V10= Cnil;
	goto L2816;}
	T0=V12=CONS(Cnil,Cnil);
L2817:
	{volatile object V14;                     /*  VAR             */
	CAR(V12)= CONS(CAR(V13),Cnil);
	}
	if((V13=CDR(V13))==Cnil){
	V10= T0;
	goto L2816;}
	V12=CDR(V12)=CONS(Cnil,Cnil);
	goto L2817;}
L2816:
	V11= Cnil;
	{volatile object V12;                     /*  KEYS            */
	volatile object V13;                      /*  TEMP            */
	V12= (V6);
	V13= Cnil;
L2821:
	if(!((V12)==Cnil)){
	goto L2822;}
	goto L2819;
L2822:
	{volatile object V15;                     /*  KEY             */
	volatile object V16;                      /*  BINDER          */
	V15= CAR((V12));
	if(((V15)!= VV[330]))goto L2828;
	V16= (VV[762]->s.s_gfdef);
	goto L2827;
L2828:
	{object V17= (VV[6]->s.s_dbind);
	L134(1,(V15))                             /*  GET-EVENT-CODE  */;
	V16= (V17)->v.v_self[fix(VALUES(0))];}
L2827:
	{volatile object V17;
	volatile object V18;                      /*  VAR             */
	V17= (V10);
	V18= Cnil;
L2833:
	if(!((V17)==Cnil)){
	goto L2834;}
	goto L2825;
L2834:
	V18= CAR((V17));
	{register object V20;                     /*  CODE            */
	LC142(1,CAR((V18)))                       /*  VAR-KEY         */;
	funcall(4,(V16),(V4),(V5),VALUES(0));
	V20= VALUES(0);
	if(((V20))!=Cnil){
	goto L2842;}
	LC142(1,CAR((V18)))                       /*  VAR-KEY         */;
	(*LK38)(3,VV[335],VALUES(0),(V15))        /*  WARN            */;
L2842:
	{object V21= CDR((V18));
	T0= (VV[976]->s.s_gfdef);
	VALUES(0) = (VV[977]->s.s_gfdef);
	Lmember(6,(V20),(V21),VV[336],T0,VV[178],VALUES(0))/*  MEMBER */;
	V13= VALUES(0);}
	if(((V13))==Cnil){
	goto L2847;}
	{register object V21;
	register object V22;
	V21= (V13);
	V22= CONS((V15),CAAR((V21)));
	CAR(CAR((V21))) = (V22);
	goto L2839;
	}
L2847:
	{register object V23;
	register object V24;
	V23= (V18);
	V24= CONS(CONS(CONS((V15),Cnil),(V20)),CDR((V23)));
	CDR((V23)) = (V24);
	}
	}
L2839:
	V17= CDR((V17));
	goto L2833;
	}
	}
L2825:
	V12= CDR((V12));
	goto L2821;
	}
L2819:
	{object V12;
	object V13= (V10);
	if(V13==Cnil){
	T0= Cnil;
	goto L2864;}
	T1=V12=CONS(Cnil,Cnil);
L2865:
	{volatile object V14;                     /*  VAR             */
	V14= CAR(V13);
	if((CDDR((V14)))==Cnil){
	goto L2868;}
	V11= Ct;
	LC143(1,CAR((V14)))                       /*  VAR-SYMBOL      */;
	CAR(V12)= VALUES(0);
	goto L2866;
L2868:
	LC143(1,CAR((V14)))                       /*  VAR-SYMBOL      */;
	T2= VALUES(0);
	CAR(V12)= list(2,T2,CDADR((V14)));
	}
L2866:
	if((V13=CDR(V13))==Cnil){
	T0= T1;
	goto L2864;}
	V12=CDR(V12)=CONS(Cnil,Cnil);
	goto L2865;}
L2864:
	if(((V11))==Cnil){
	goto L2875;}
	{volatile object V12;                     /*  KEYS            */
	volatile object V13;                      /*  CLAUSES         */
	volatile object V14;                      /*  CLAUSE          */
	volatile object V15;                      /*  TEMP            */
	V12= (V6);
	V13= Cnil;
	V14= Cnil;
	V15= Cnil;
L2879:
	if(!((V12)==Cnil)){
	goto L2880;}
	{volatile object V17;
	volatile object V18;                      /*  CLAUSE          */
	V17= (V13);
	V18= Cnil;
L2887:
	if(!((V17)==Cnil)){
	goto L2888;}
	goto L2883;
L2888:
	V18= CAR((V17));
	if((CDAR((V18)))!=Cnil){
	goto L2893;}
	{register object V20;
	register object V21;
	V20= (V18);
	V21= CAAR((V18));
	CAR((V20)) = (V21);
	}
L2893:
	V17= CDR((V17));
	goto L2887;
	}
L2883:
	VALUES(0) = (V13);
	goto L2877;
L2880:
	{volatile object V17;
	volatile object V18;                      /*  VAR             */
	V17= (V10);
	V18= Cnil;
L2906:
	if(!((V17)==Cnil)){
	goto L2907;}
	goto L2902;
L2907:
	V18= CAR((V17));
	if((CDDR((V18)))==Cnil){
	goto L2912;}
	{volatile object V20;
	volatile object V21;                      /*  EVENTS          */
	V20= CDR((V18));
	V21= Cnil;
L2918:
	if(!((V20)==Cnil)){
	goto L2919;}
	goto L2912;
L2919:
	V21= CAR((V20));
	if((memql(CAR((V12)),CAR((V21))))==Cnil){
	goto L2924;}
	{object V23= CDR((V21));
	T1= (VV[978]->s.s_gfdef);
	VALUES(0) = (VV[977]->s.s_gfdef);
	Lmember(6,(V23),(V14),VV[336],T1,VV[178],VALUES(0))/*  MEMBER */;
	V15= VALUES(0);}
	if(((V15))==Cnil){
	goto L2928;}
	V14= nconc((V14),CONS(list(3,VV[17],CAR((V18)),CADR(CAR((V15)))),Cnil));
	goto L2924;
L2928:
	V14= CONS(list(3,VV[17],CAR((V18)),CDR((V21))),(V14));
L2924:
	V20= CDR((V20));
	goto L2918;
	}
L2912:
	V17= CDR((V17));
	goto L2906;
	}
L2902:
	if(((V14))==Cnil){
	goto L2941;}
	T1= (VV[976]->s.s_gfdef);
	VALUES(0) = (VV[977]->s.s_gfdef);
	Lmember(6,(V14),(V13),VV[336],T1,VV[178],VALUES(0))/*  MEMBER */;
	V15= VALUES(0);
	if(((V15))==Cnil){
	goto L2945;}
	{register object V23;
	register object V24;
	V23= (V15);
	V24= CONS(CAR((V12)),CAAR((V23)));
	CAR(CAR((V23))) = (V24);
	goto L2941;
	}
L2945:
	V13= CONS(CONS(CONS(CAR((V12)),Cnil),(V14)),(V13));
L2941:
	V12= CDR((V12));
	V14= Cnil;
	goto L2879;
	}
L2877:
	VALUES(0) = listA(3,VV[326],(V5),VALUES(0));
	goto L2873;
L2875:
	VALUES(0) = Cnil;
L2873:
	VALUES(0) = listA(4,VV[133],T0,VALUES(0),(V8));
	RETURN(1);
	}}
}
/*	local function VAR-KEY                                        */
static LC142(int narg, object V1)
{ VT140 VLEX140 CLSR140
TTL:
	if(!(type_of((V1))==t_cons)){
	goto L2960;}
	VALUES(0) = CAR((V1));
	goto L2958;
L2960:
	VALUES(0) = (V1);
L2958:
	RETURN((*LK0)(1,VALUES(0))                /*  KINTERN         */);
}
/*	local function VAR-SYMBOL                                     */
static LC143(int narg, object V1)
{ VT141 VLEX141 CLSR141
TTL:
	if(!(type_of((V1))==t_cons)){
	goto L2963;}
	VALUES(0) = CADR((V1));
	RETURN(1);
L2963:
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for MAKE-ERROR                            */
static L144(int narg, object V1, object V2, object V3)
{ VT142 VLEX142 CLSR142
TTL:
	{object V4;                               /*  %REPLY-BUFFER   */
	{int V5;                                  /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= 0;
	V6= ((V2))->in.in_slots[1];
	{int V7;                                  /*  ERROR-CODE      */
	object V8;                                /*  ERROR-KEY       */
	object V9;                                /*  ERROR-DECODE-FUNCTION*/
	V7= ((V6))->ust.ust_self[(V5)+(1)];
	L222(2,(V1),MAKE_FIXNUM(V7))              /*  GET-ERROR-KEY   */;
	V8= VALUES(0);
	V9= getf((V8)->s.s_plist,VV[339],Cnil);
	T0= ((V1))->in.in_slots[3];
	funcall(3,(V9),(V1),(V2));
	VALUES(0) = listA(7,MAKE_FIXNUM(V7),(V8),VV[340],(V3),VV[341],T0,VALUES(0));
	RETURN(1);
	}
	}
	}
}
/*	function definition for REPORT-ERROR                          */
static L145(int narg, object V1, object V2, object V3, ...)
{ VT143 VLEX143 CLSR143
	{object V4;
	va_list args; va_start(args, V3);
	narg -=3;
	V4=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object p=V4;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{object V5;                               /*  HANDLER         */
	V5= ((V1))->in.in_slots[48];
	(*LK24)(2,(V5),VV[129])                   /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2977;}
	VALUES(0) = elt((V5),fix((V2)));
	goto L2975;
L2977:
	VALUES(0) = (V5);
L2975:
	RETURN(Lapply(4,VALUES(0),(V1),(V3),(V4)) /*  APPLY           */);
	}
	}
}
/*	function definition for REQUEST-NAME                          */
static L146(int narg, object V1, ...)
{ VT144 VLEX144 CLSR144
	{int i=1;
	volatile object V2;
	va_list args; va_start(args, V1);
	if (i==narg) goto L2979;
	V2= va_arg(args, object);
	i++;
	goto L2980;
L2979:
	V2= Cnil;
L2980:
	if(!(number_compare((V1),MAKE_FIXNUM(length((VV[342]->s.s_dbind))))<0)){
	goto L2983;}
	VALUES(0) = ((VV[342]->s.s_dbind))->v.v_self[fix((V1))];
	RETURN(1);
L2983:
	{volatile object V3;
	volatile object V4;                       /*  EXTENSION       */
	if((V2)==Cnil){
	V3= Cnil;
	goto L2985;}
	V3= ((V2))->in.in_slots[56];
L2985:
	V4= Cnil;
L2988:
	if(!((V3)==Cnil)){
	goto L2989;}
	VALUES(0) = VV[343];
	RETURN(1);
L2989:
	V4= CAR((V3));
	if(!(number_compare((V1),CADR((V4)))==0)){
	goto L2994;}
	VALUES(0) = CAR((V4));
	RETURN(1);
L2994:
	V3= CDR((V3));
	goto L2988;
	}
	}
}
/*	function definition for MAKE-REQUEST-ERROR                    */
static L147(int narg, ...)
{ VT145 VLEX145 CLSR145
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[16];
	parse_key(narg,args,8,L147keys,keyvars,OBJNULL,FALSE);
	if(keyvars[8]==Cnil){
	V1= VV[353];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	V7= keyvars[6];
	V8= keyvars[7];
	}
	(*LK39)(1,VV[345])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(9,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for .REQUEST-ERROR-REPORTER.              */
static L148(int narg, object V1, object V2)
{ VT146 VLEX146 CLSR146
TTL:
	L149(2,(V1),(V2))                         /*  REPORT-REQUEST-ERROR*/;
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for REPORT-REQUEST-ERROR                  */
static L149(int narg, object V1, object V2)
{ VT147 VLEX147 CLSR147
TTL:
	{object V3;                               /*  ERROR-KEY       */
	object V4;                                /*  ASYNCHRONOUS    */
	object V5;                                /*  MAJOR           */
	object V6;                                /*  MINOR           */
	object V7;                                /*  SEQUENCE        */
	object V8;                                /*  CURRENT-SEQUENCE*/
	V3= ((V1))->in.in_slots[2];
	V4= ((V1))->in.in_slots[7];
	V5= ((V1))->in.in_slots[3];
	V6= ((V1))->in.in_slots[4];
	V7= ((V1))->in.in_slots[5];
	V8= ((V1))->in.in_slots[6];
	{object V9= (number_compare((V7),(V8))==0?Ct:Cnil);
	L146(2,(V5),((V1))->in.in_slots[1])       /*  REQUEST-NAME    */;
	RETURN(Lformat(10,(V2),VV[354],(V4),(V3),(V9),(V7),(V8),(V5),(V6),VALUES(0))/*  FORMAT*/);}
	}
}
/*	function definition for MAKE-RESOURCE-ERROR                   */
static L150(int narg, ...)
{ VT148 VLEX148 CLSR148
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[18];
	parse_key(narg,args,9,L150keys,keyvars,OBJNULL,FALSE);
	if(keyvars[9]==Cnil){
	V1= VV[363];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	V7= keyvars[6];
	V8= keyvars[7];
	V9= keyvars[8];
	}
	(*LK39)(1,VV[355])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(10,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8),(V9))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for .RESOURCE-ERROR-REPORTER.             */
static L151(int narg, object V1, object V2)
{ VT149 VLEX149 CLSR149
TTL:
	{object V3;                               /*  CONDITION       */
	object V4;                                /*  STREAM          */
	L149(2,(V1),(V2))                         /*  REPORT-REQUEST-ERROR*/;
	Lformat(3,(V2),VV[364],((V1))->in.in_slots[8])/*  FORMAT      */;
	}
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for MAKE-UNKNOWN-ERROR                    */
static L153(int narg, ...)
{ VT150 VLEX150 CLSR150
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[18];
	parse_key(narg,args,9,L153keys,keyvars,OBJNULL,FALSE);
	if(keyvars[9]==Cnil){
	V1= VV[373];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	V7= keyvars[6];
	V8= keyvars[7];
	V9= keyvars[8];
	}
	(*LK39)(1,VV[365])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(10,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8),(V9))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for .UNKNOWN-ERROR-REPORTER.              */
static L154(int narg, object V1, object V2)
{ VT151 VLEX151 CLSR151
TTL:
	{object V3;                               /*  CONDITION       */
	object V4;                                /*  STREAM          */
	L149(2,(V1),(V2))                         /*  REPORT-REQUEST-ERROR*/;
	Lformat(3,(V2),VV[374],((V1))->in.in_slots[8])/*  FORMAT      */;
	}
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for MAKE-ACCESS-ERROR                     */
static L156(int narg, ...)
{ VT152 VLEX152 CLSR152
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[16];
	parse_key(narg,args,8,L156keys,keyvars,OBJNULL,FALSE);
	if(keyvars[8]==Cnil){
	V1= VV[353];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	V7= keyvars[6];
	V8= keyvars[7];
	}
	(*LK39)(1,VV[375])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(9,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for MAKE-ALLOC-ERROR                      */
static L157(int narg, ...)
{ VT153 VLEX153 CLSR153
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[16];
	parse_key(narg,args,8,L157keys,keyvars,OBJNULL,FALSE);
	if(keyvars[8]==Cnil){
	V1= VV[353];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	V7= keyvars[6];
	V8= keyvars[7];
	}
	(*LK39)(1,VV[381])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(9,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for MAKE-ATOM-ERROR                       */
static L158(int narg, ...)
{ VT154 VLEX154 CLSR154
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[18];
	parse_key(narg,args,9,L158keys,keyvars,OBJNULL,FALSE);
	if(keyvars[9]==Cnil){
	V1= VV[395];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	V7= keyvars[6];
	V8= keyvars[7];
	V9= keyvars[8];
	}
	(*LK39)(1,VV[387])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(10,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8),(V9))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for .ATOM-ERROR-REPORTER.                 */
static L159(int narg, object V1, object V2)
{ VT155 VLEX155 CLSR155
TTL:
	{object V3;                               /*  CONDITION       */
	object V4;                                /*  STREAM          */
	L149(2,(V1),(V2))                         /*  REPORT-REQUEST-ERROR*/;
	Lformat(3,(V2),VV[396],((V1))->in.in_slots[8])/*  FORMAT      */;
	}
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for MAKE-COLORMAP-ERROR                   */
static L161(int narg, ...)
{ VT156 VLEX156 CLSR156
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[18];
	parse_key(narg,args,9,L161keys,keyvars,OBJNULL,FALSE);
	if(keyvars[9]==Cnil){
	V1= VV[363];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	V7= keyvars[6];
	V8= keyvars[7];
	V9= keyvars[8];
	}
	(*LK39)(1,VV[397])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(10,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8),(V9))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for MAKE-CURSOR-ERROR                     */
static L162(int narg, ...)
{ VT157 VLEX157 CLSR157
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[18];
	parse_key(narg,args,9,L162keys,keyvars,OBJNULL,FALSE);
	if(keyvars[9]==Cnil){
	V1= VV[363];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	V7= keyvars[6];
	V8= keyvars[7];
	V9= keyvars[8];
	}
	(*LK39)(1,VV[403])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(10,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8),(V9))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for MAKE-DRAWABLE-ERROR                   */
static L163(int narg, ...)
{ VT158 VLEX158 CLSR158
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[18];
	parse_key(narg,args,9,L163keys,keyvars,OBJNULL,FALSE);
	if(keyvars[9]==Cnil){
	V1= VV[363];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	V7= keyvars[6];
	V8= keyvars[7];
	V9= keyvars[8];
	}
	(*LK39)(1,VV[409])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(10,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8),(V9))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for MAKE-FONT-ERROR                       */
static L164(int narg, ...)
{ VT159 VLEX159 CLSR159
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[18];
	parse_key(narg,args,9,L164keys,keyvars,OBJNULL,FALSE);
	if(keyvars[9]==Cnil){
	V1= VV[363];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	V7= keyvars[6];
	V8= keyvars[7];
	V9= keyvars[8];
	}
	(*LK39)(1,VV[415])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(10,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8),(V9))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for MAKE-GCONTEXT-ERROR                   */
static L165(int narg, ...)
{ VT160 VLEX160 CLSR160
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[18];
	parse_key(narg,args,9,L165keys,keyvars,OBJNULL,FALSE);
	if(keyvars[9]==Cnil){
	V1= VV[363];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	V7= keyvars[6];
	V8= keyvars[7];
	V9= keyvars[8];
	}
	(*LK39)(1,VV[421])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(10,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8),(V9))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for MAKE-ID-CHOICE-ERROR                  */
static L166(int narg, ...)
{ VT161 VLEX161 CLSR161
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[18];
	parse_key(narg,args,9,L166keys,keyvars,OBJNULL,FALSE);
	if(keyvars[9]==Cnil){
	V1= VV[363];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	V7= keyvars[6];
	V8= keyvars[7];
	V9= keyvars[8];
	}
	(*LK39)(1,VV[427])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(10,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8),(V9))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for MAKE-ILLEGAL-REQUEST-ERROR            */
static L167(int narg, ...)
{ VT162 VLEX162 CLSR162
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[16];
	parse_key(narg,args,8,L167keys,keyvars,OBJNULL,FALSE);
	if(keyvars[8]==Cnil){
	V1= VV[353];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	V7= keyvars[6];
	V8= keyvars[7];
	}
	(*LK39)(1,VV[433])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(9,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for MAKE-LENGTH-ERROR                     */
static L168(int narg, ...)
{ VT163 VLEX163 CLSR163
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[16];
	parse_key(narg,args,8,L168keys,keyvars,OBJNULL,FALSE);
	if(keyvars[8]==Cnil){
	V1= VV[353];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	V7= keyvars[6];
	V8= keyvars[7];
	}
	(*LK39)(1,VV[439])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(9,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for MAKE-MATCH-ERROR                      */
static L169(int narg, ...)
{ VT164 VLEX164 CLSR164
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[16];
	parse_key(narg,args,8,L169keys,keyvars,OBJNULL,FALSE);
	if(keyvars[8]==Cnil){
	V1= VV[353];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	V7= keyvars[6];
	V8= keyvars[7];
	}
	(*LK39)(1,VV[445])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(9,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for MAKE-NAME-ERROR                       */
static L170(int narg, ...)
{ VT165 VLEX165 CLSR165
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[16];
	parse_key(narg,args,8,L170keys,keyvars,OBJNULL,FALSE);
	if(keyvars[8]==Cnil){
	V1= VV[353];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	V7= keyvars[6];
	V8= keyvars[7];
	}
	(*LK39)(1,VV[451])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(9,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for MAKE-PIXMAP-ERROR                     */
static L171(int narg, ...)
{ VT166 VLEX166 CLSR166
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[18];
	parse_key(narg,args,9,L171keys,keyvars,OBJNULL,FALSE);
	if(keyvars[9]==Cnil){
	V1= VV[363];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	V7= keyvars[6];
	V8= keyvars[7];
	V9= keyvars[8];
	}
	(*LK39)(1,VV[457])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(10,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8),(V9))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for MAKE-VALUE-ERROR                      */
static L172(int narg, ...)
{ VT167 VLEX167 CLSR167
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[18];
	parse_key(narg,args,9,L172keys,keyvars,OBJNULL,FALSE);
	if(keyvars[9]==Cnil){
	V1= VV[471];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	V7= keyvars[6];
	V8= keyvars[7];
	V9= keyvars[8];
	}
	(*LK39)(1,VV[463])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(10,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8),(V9))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for .VALUE-ERROR-REPORTER.                */
static L173(int narg, object V1, object V2)
{ VT168 VLEX168 CLSR168
TTL:
	{object V3;                               /*  CONDITION       */
	object V4;                                /*  STREAM          */
	L149(2,(V1),(V2))                         /*  REPORT-REQUEST-ERROR*/;
	Lformat(3,(V2),VV[472],((V1))->in.in_slots[8])/*  FORMAT      */;
	}
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for MAKE-WINDOW-ERROR                     */
static L175(int narg, ...)
{ VT169 VLEX169 CLSR169
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[18];
	parse_key(narg,args,9,L175keys,keyvars,OBJNULL,FALSE);
	if(keyvars[9]==Cnil){
	V1= VV[363];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	V7= keyvars[6];
	V8= keyvars[7];
	V9= keyvars[8];
	}
	(*LK39)(1,VV[473])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(10,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8),(V9))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for MAKE-IMPLEMENTATION-ERROR             */
static L176(int narg, ...)
{ VT170 VLEX170 CLSR170
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[16];
	parse_key(narg,args,8,L176keys,keyvars,OBJNULL,FALSE);
	if(keyvars[8]==Cnil){
	V1= VV[353];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	V7= keyvars[6];
	V8= keyvars[7];
	}
	(*LK39)(1,VV[479])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(9,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for MAKE-X-TYPE-ERROR                     */
static L177(int narg, ...)
{ VT171 VLEX171 CLSR171
	{object V1;
	object V2;
	object V3;
	object V4;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[8];
	parse_key(narg,args,4,L177keys,keyvars,OBJNULL,FALSE);
	if(keyvars[4]==Cnil){
	V1= VV[494];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	}
	(*LK39)(1,VV[485])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(5,VALUES(0),(V1),(V2),(V3),(V4))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for .X-TYPE-ERROR-REPORTER.               */
static L178(int narg, object V1, object V2)
{ VT172 VLEX172 CLSR172
TTL:
	{object V3;                               /*  CONDITION       */
	object V4;                                /*  STREAM          */
	V3= (V1);
	T0= ((V3))->in.in_slots[1];
	VALUES(0) = ((V3))->in.in_slots[3];
	if(VALUES(0)==Cnil)goto L3061;
	goto L3060;
L3061:
	VALUES(0) = ((V3))->in.in_slots[2];
L3060:
	Lformat(4,(V2),VV[495],T0,VALUES(0))      /*  FORMAT          */;
	}
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for MAKE-CLOSED-DISPLAY                   */
static L180(int narg, ...)
{ VT173 VLEX173 CLSR173
	{object V1;
	object V2;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[4];
	parse_key(narg,args,2,L180keys,keyvars,OBJNULL,FALSE);
	if(keyvars[2]==Cnil){
	V1= VV[503];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	}
	(*LK39)(1,VV[47])                         /*  FIND-CLASS      */;
	RETURN(siLmake_structure(3,VALUES(0),(V1),(V2))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for .CLOSED-DISPLAY-REPORTER.             */
static L181(int narg, object V1, object V2)
{ VT174 VLEX174 CLSR174
TTL:
	{object V3;                               /*  CONDITION       */
	object V4;                                /*  STREAM          */
	Lformat(3,(V2),VV[504],((V1))->in.in_slots[1])/*  FORMAT      */;
	}
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for MAKE-LOOKUP-ERROR                     */
static L183(int narg, ...)
{ VT175 VLEX175 CLSR175
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[10];
	parse_key(narg,args,5,L183keys,keyvars,OBJNULL,FALSE);
	if(keyvars[5]==Cnil){
	V1= VV[513];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	}
	(*LK39)(1,VV[505])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(6,VALUES(0),(V1),(V2),(V3),(V4),(V5))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for .LOOKUP-ERROR-REPORTER.               */
static L184(int narg, object V1, object V2)
{ VT176 VLEX176 CLSR176
TTL:
	{register object V3;                      /*  CONDITION       */
	object V4;                                /*  STREAM          */
	V3= (V1);
	Lformat(6,(V2),VV[514],((V3))->in.in_slots[1],((V3))->in.in_slots[2],((V3))->in.in_slots[3],((V3))->in.in_slots[4])/*  FORMAT*/;
	}
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for MAKE-CONNECTION-FAILURE               */
static L186(int narg, ...)
{ VT177 VLEX177 CLSR177
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[12];
	parse_key(narg,args,6,L186keys,keyvars,OBJNULL,FALSE);
	if(keyvars[6]==Cnil){
	V1= VV[523];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	}
	(*LK39)(1,VV[515])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(7,VALUES(0),(V1),(V2),(V3),(V4),(V5),(V6))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for .CONNECTION-FAILURE-REPORTER.         */
static L187(int narg, object V1, object V2)
{ VT178 VLEX178 CLSR178
TTL:
	{register object V3;                      /*  CONDITION       */
	object V4;                                /*  STREAM          */
	V3= (V1);
	Lformat(7,(V2),VV[524],((V3))->in.in_slots[1],((V3))->in.in_slots[2],((V3))->in.in_slots[3],((V3))->in.in_slots[4],((V3))->in.in_slots[5])/*  FORMAT*/;
	}
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for MAKE-REPLY-LENGTH-ERROR               */
static L189(int narg, ...)
{ VT179 VLEX179 CLSR179
	{object V1;
	object V2;
	object V3;
	object V4;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[8];
	parse_key(narg,args,4,L189keys,keyvars,OBJNULL,FALSE);
	if(keyvars[4]==Cnil){
	V1= VV[533];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	}
	(*LK39)(1,VV[525])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(5,VALUES(0),(V1),(V2),(V3),(V4))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for .REPLY-LENGTH-ERROR-REPORTER.         */
static L190(int narg, object V1, object V2)
{ VT180 VLEX180 CLSR180
TTL:
	{object V3;                               /*  CONDITION       */
	object V4;                                /*  STREAM          */
	V3= (V1);
	Lformat(5,(V2),VV[534],((V3))->in.in_slots[1],((V3))->in.in_slots[2],((V3))->in.in_slots[3])/*  FORMAT*/;
	}
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for MAKE-REPLY-TIMEOUT                    */
static L192(int narg, ...)
{ VT181 VLEX181 CLSR181
	{object V1;
	object V2;
	object V3;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[6];
	parse_key(narg,args,3,L192keys,keyvars,OBJNULL,FALSE);
	if(keyvars[3]==Cnil){
	V1= VV[543];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	}
	(*LK39)(1,VV[535])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(4,VALUES(0),(V1),(V2),(V3))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for .REPLY-TIMEOUT-REPORTER.              */
static L193(int narg, object V1, object V2)
{ VT182 VLEX182 CLSR182
TTL:
	{object V3;                               /*  CONDITION       */
	object V4;                                /*  STREAM          */
	Lformat(4,(V2),VV[544],((V1))->in.in_slots[1],((V1))->in.in_slots[2])/*  FORMAT*/;
	}
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for MAKE-SEQUENCE-ERROR                   */
static L195(int narg, ...)
{ VT183 VLEX183 CLSR183
	{object V1;
	object V2;
	object V3;
	object V4;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[8];
	parse_key(narg,args,4,L195keys,keyvars,OBJNULL,FALSE);
	if(keyvars[4]==Cnil){
	V1= VV[553];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	}
	(*LK39)(1,VV[545])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(5,VALUES(0),(V1),(V2),(V3),(V4))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for .SEQUENCE-ERROR-REPORTER.             */
static L196(int narg, object V1, object V2)
{ VT184 VLEX184 CLSR184
TTL:
	{object V3;                               /*  CONDITION       */
	object V4;                                /*  STREAM          */
	V3= (V1);
	Lformat(5,(V2),VV[554],((V3))->in.in_slots[1],((V3))->in.in_slots[2],((V3))->in.in_slots[3])/*  FORMAT*/;
	}
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for MAKE-UNEXPECTED-REPLY                 */
static L198(int narg, ...)
{ VT185 VLEX185 CLSR185
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[10];
	parse_key(narg,args,5,L198keys,keyvars,OBJNULL,FALSE);
	if(keyvars[5]==Cnil){
	V1= VV[563];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	}
	(*LK39)(1,VV[555])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(6,VALUES(0),(V1),(V2),(V3),(V4),(V5))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for .UNEXPECTED-REPLY-REPORTER.           */
static L199(int narg, object V1, object V2)
{ VT186 VLEX186 CLSR186
TTL:
	{register object V3;                      /*  CONDITION       */
	object V4;                                /*  STREAM          */
	V3= (V1);
	Lformat(6,(V2),VV[564],((V3))->in.in_slots[1],((V3))->in.in_slots[3],((V3))->in.in_slots[2],((V3))->in.in_slots[4])/*  FORMAT*/;
	}
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for MAKE-MISSING-PARAMETER                */
static L201(int narg, ...)
{ VT187 VLEX187 CLSR187
	{object V1;
	object V2;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[4];
	parse_key(narg,args,2,L201keys,keyvars,OBJNULL,FALSE);
	if(keyvars[2]==Cnil){
	V1= VV[573];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	}
	(*LK39)(1,VV[565])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(3,VALUES(0),(V1),(V2))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for .MISSING-PARAMETER-REPORTER.          */
static L202(int narg, object V1, object V2)
{ VT188 VLEX188 CLSR188
TTL:
	{object V3;                               /*  CONDITION       */
	object V4;                                /*  STREAM          */
	{object V5;                               /*  PARM            */
	V5= ((V1))->in.in_slots[1];
	if(!(type_of((V5))==t_cons)){
	goto L3089;}
	Lformat(3,(V2),VV[574],(V5))              /*  FORMAT          */;
	goto L3086;
L3089:
	Lformat(3,(V2),VV[575],(V5))              /*  FORMAT          */;
	}
	}
L3086:
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for MAKE-INVALID-FONT                     */
static L204(int narg, ...)
{ VT189 VLEX189 CLSR189
	{object V1;
	object V2;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[4];
	parse_key(narg,args,2,L204keys,keyvars,OBJNULL,FALSE);
	if(keyvars[2]==Cnil){
	V1= VV[584];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	}
	(*LK39)(1,VV[576])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(3,VALUES(0),(V1),(V2))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for .INVALID-FONT-REPORTER.               */
static L205(int narg, object V1, object V2)
{ VT190 VLEX190 CLSR190
TTL:
	{object V3;                               /*  CONDITION       */
	object V4;                                /*  STREAM          */
	Lformat(3,(V2),VV[585],((V1))->in.in_slots[1])/*  FORMAT      */;
	}
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for MAKE-DEVICE-BUSY                      */
static L207(int narg, ...)
{ VT191 VLEX191 CLSR191
	{object V1;
	object V2;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[4];
	parse_key(narg,args,2,L207keys,keyvars,OBJNULL,FALSE);
	if(keyvars[2]==Cnil){
	V1= VV[594];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	}
	(*LK39)(1,VV[586])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(3,VALUES(0),(V1),(V2))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for .DEVICE-BUSY-REPORTER.                */
static L208(int narg, object V1, object V2)
{ VT192 VLEX192 CLSR192
TTL:
	{object V3;                               /*  CONDITION       */
	object V4;                                /*  STREAM          */
	Lformat(3,(V2),VV[595],((V1))->in.in_slots[1])/*  FORMAT      */;
	}
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for MAKE-UNIMPLEMENTED-EVENT              */
static L210(int narg, ...)
{ VT193 VLEX193 CLSR193
	{object V1;
	object V2;
	object V3;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[6];
	parse_key(narg,args,3,L210keys,keyvars,OBJNULL,FALSE);
	if(keyvars[3]==Cnil){
	V1= VV[603];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	}
	(*LK39)(1,VV[28])                         /*  FIND-CLASS      */;
	RETURN(siLmake_structure(4,VALUES(0),(V1),(V2),(V3))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for .UNIMPLEMENTED-EVENT-REPORTER.        */
static L211(int narg, object V1, object V2)
{ VT194 VLEX194 CLSR194
TTL:
	{object V3;                               /*  CONDITION       */
	object V4;                                /*  STREAM          */
	Lformat(4,(V2),VV[604],((V1))->in.in_slots[2],((V1))->in.in_slots[1])/*  FORMAT*/;
	}
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for MAKE-UNDEFINED-EVENT                  */
static L213(int narg, ...)
{ VT195 VLEX195 CLSR195
	{object V1;
	object V2;
	object V3;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[6];
	parse_key(narg,args,3,L213keys,keyvars,OBJNULL,FALSE);
	if(keyvars[3]==Cnil){
	V1= VV[612];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	}
	(*LK39)(1,VV[31])                         /*  FIND-CLASS      */;
	RETURN(siLmake_structure(4,VALUES(0),(V1),(V2),(V3))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for .UNDEFINED-EVENT-REPORTER.            */
static L214(int narg, object V1, object V2)
{ VT196 VLEX196 CLSR196
TTL:
	{object V3;                               /*  CONDITION       */
	object V4;                                /*  STREAM          */
	Lformat(4,(V2),VV[613],((V1))->in.in_slots[2],((V1))->in.in_slots[1])/*  FORMAT*/;
	}
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for MAKE-ABSENT-EXTENSION                 */
static L216(int narg, ...)
{ VT197 VLEX197 CLSR197
	{object V1;
	object V2;
	object V3;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[6];
	parse_key(narg,args,3,L216keys,keyvars,OBJNULL,FALSE);
	if(keyvars[3]==Cnil){
	V1= VV[622];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	}
	(*LK39)(1,VV[614])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(4,VALUES(0),(V1),(V2),(V3))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for .ABSENT-EXTENSION-REPORTER.           */
static L217(int narg, object V1, object V2)
{ VT198 VLEX198 CLSR198
TTL:
	{object V3;                               /*  CONDITION       */
	object V4;                                /*  STREAM          */
	Lformat(4,(V2),VV[623],((V1))->in.in_slots[1],((V1))->in.in_slots[2])/*  FORMAT*/;
	}
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for MAKE-INCONSISTENT-PARAMETERS          */
static L219(int narg, ...)
{ VT199 VLEX199 CLSR199
	{object V1;
	object V2;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[4];
	parse_key(narg,args,2,L219keys,keyvars,OBJNULL,FALSE);
	if(keyvars[2]==Cnil){
	V1= VV[631];
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	}
	(*LK39)(1,VV[141])                        /*  FIND-CLASS      */;
	RETURN(siLmake_structure(3,VALUES(0),(V1),(V2))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for .INCONSISTENT-PARAMETERS-REPORTER.    */
static L220(int narg, object V1, object V2)
{ VT200 VLEX200 CLSR200
TTL:
	{object V3;                               /*  CONDITION       */
	object V4;                                /*  STREAM          */
	Lformat(3,(V2),VV[632],((V1))->in.in_slots[1])/*  FORMAT      */;
	}
	VALUES(0) = (V1);
	RETURN(1);
}
/*	function definition for GET-ERROR-KEY                         */
static L222(int narg, object V1, object V2)
{ VT201 VLEX201 CLSR201
	{volatile int V3;
	V3= fix(V2);
TTL:
	if(!((V3)<(length((VV[337]->s.s_dbind))))){
	goto L3110;}
	VALUES(0) = ((VV[337]->s.s_dbind))->v.v_self[V3];
	RETURN(1);
L3110:
	{volatile object V4;
	volatile object V5;                       /*  ENTRY           */
	V4= ((V1))->in.in_slots[56];
	V5= Cnil;
L3115:
	if(!((V4)==Cnil)){
	goto L3116;}
	VALUES(0) = VV[365];
	RETURN(1);
L3116:
	V5= CAR((V4));
	{register object V7;                      /*  EVENT-NAME      */
	register int V8;                          /*  FIRST-ERROR     */
	register object V9;                       /*  ERRORS          */
	V7= CAR((V5));
	V8= fix(CADDDR((V5)));
	VALUES(0) = assql((V7),(VV[14]->s.s_dbind));
	V9= CADDR(VALUES(0));
	if(((V9))==Cnil){
	goto L3121;}
	Lmonotonically_nondecreasing(3,MAKE_FIXNUM(V8),MAKE_FIXNUM(V3),MAKE_FIXNUM((V8)+((length((V9)))-(1))))/*  <=*/;
	if(VALUES(0)==Cnil){
	goto L3121;}
	VALUES(0) = nth((V3)-(V8),(V9));
	RETURN(1);
	}
L3121:
	V4= CDR((V4));
	goto L3115;
	}
	}
}
/*	macro definition for DEFINE-ERROR                             */
static L223(int narg, object V1, object V2)
{ VT202 VLEX202 CLSR202
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	(*LK40)(2,(V4),(VV[337]->s.s_dbind))      /*  FIND            */;
	if(VALUES(0)!=Cnil){
	goto L3133;}
	{volatile object V6;
	volatile object V7;                       /*  EXTENSION       */
	V6= (VV[14]->s.s_dbind);
	V7= Cnil;
L3141:
	if(!((V6)==Cnil)){
	goto L3142;}
	goto L3137;
L3142:
	V7= CAR((V6));
	if((memql((V4),CADDR((V7))))==Cnil){
	goto L3147;}
	goto L3133;
L3147:
	V6= CDR((V6));
	goto L3141;
	}
L3137:
	(*LK3)(2,(V4),VV[633])                    /*  X-TYPE-ERROR    */;
L3133:
	{object V6= list(3,VV[59],list(2,VV[20],(V4)),VV[634]);
	VALUES(0) = list(3,VV[56],(V6),list(2,VV[138],(V5)));
	RETURN(1);}}
}
/*	function definition for DECODE-CORE-ERROR                     */
static L224(int narg, object V1, object V2, ...)
{ VT203 VLEX203 CLSR203
	{int i=2;
	object V3;
	va_list args; va_start(args, V2);
	if (i==narg) goto L3153;
	V3= va_arg(args, object);
	i++;
	goto L3154;
L3153:
	V3= Cnil;
L3154:
	{object V4;                               /*  %REPLY-BUFFER   */
	{register int V5;                         /*  BUFFER-BOFFSET  */
	register object V6;                       /*  BUFFER-BBUF     */
	V5= 0;
	V6= ((V2))->in.in_slots[1];
	{object V7;                               /*  SEQUENCE        */
	object V8;                                /*  MINOR-CODE      */
	object V9;                                /*  MAJOR-CODE      */
	object V10;                               /*  RESULT          */
	V7= MAKE_FIXNUM((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(2)))));
	V8= MAKE_FIXNUM((*(unsigned short *)(((V6))->ust.ust_self+((V5)+(8)))));
	V9= MAKE_FIXNUM(((V6))->ust.ust_self[(V5)+(10)]);
	V10= list(6,VV[199],(V9),VV[198],(V8),VV[149],(V7));
	if(((V3))==Cnil){
	goto L3165;}
	V10= listA(3,(V3),MAKE_FIXNUM((*(unsigned long *)(((V6))->ust.ust_self+((V5)+(4))))),(V10));
L3165:
	VALUES(0) = (V10);
	RETURN(1);
	}
	}
	}
	}
}
/*	function definition for DECODE-RESOURCE-ERROR                 */
static L225(int narg, object V1, object V2)
{ VT204 VLEX204 CLSR204
TTL:
	RETURN(L224(3,(V1),(V2),VV[635])          /*  DECODE-CORE-ERROR*/);
}
static LKF40(int narg, ...) {TRAMPOLINK(VV[1057],&LK40);}
static LKF39(int narg, ...) {TRAMPOLINK(VV[766],&LK39);}
static LKF38(int narg, ...) {TRAMPOLINK(VV[975],&LK38);}
static LKF37(int narg, ...) {TRAMPOLINK(VV[969],&LK37);}
static LKF36(int narg, ...) {TRAMPOLINK(VV[953],&LK36);}
static LKF35(int narg, ...) {TRAMPOLINK(VV[952],&LK35);}
static LKF34(int narg, ...) {TRAMPOLINK(VV[951],&LK34);}
static LKF33(int narg, ...) {TRAMPOLINK(VV[947],&LK33);}
static LKF32(int narg, ...) {TRAMPOLINK(VV[945],&LK32);}
static LKF31(int narg, ...) {TRAMPOLINK(VV[933],&LK31);}
static LKF30(int narg, ...) {TRAMPOLINK(VV[931],&LK30);}
static LKF29(int narg, ...) {TRAMPOLINK(VV[885],&LK29);}
static LKF28(int narg, ...) {TRAMPOLINK(VV[879],&LK28);}
static LKF27(int narg, ...) {TRAMPOLINK(VV[877],&LK27);}
static LKF26(int narg, ...) {TRAMPOLINK(VV[871],&LK26);}
static LKF25(int narg, ...) {TRAMPOLINK(VV[863],&LK25);}
static LKF24(int narg, ...) {TRAMPOLINK(VV[862],&LK24);}
static LKF23(int narg, ...) {TRAMPOLINK(VV[860],&LK23);}
static LKF22(int narg, ...) {TRAMPOLINK(VV[857],&LK22);}
static LKF21(int narg, ...) {TRAMPOLINK(VV[856],&LK21);}
static LKF20(int narg, ...) {TRAMPOLINK(VV[855],&LK20);}
static LKF19(int narg, ...) {TRAMPOLINK(VV[846],&LK19);}
static LKF18(int narg, ...) {TRAMPOLINK(VV[845],&LK18);}
static LKF17(int narg, ...) {TRAMPOLINK(VV[843],&LK17);}
static LKF16(int narg, ...) {TRAMPOLINK(VV[839],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[838],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[836],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[831],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[830],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[829],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[828],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[826],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[825],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[639],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[37],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[822],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[820],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[485],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[814],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[813],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[812],&LK0);}
