
/* (c) Copyright G. Attardi, 1993. */
#define VT2
#define VLEX2
#define CLSR2
static L1(int, object);
#define VT3
#define VLEX3
#define CLSR3
static L2(int, object, object);
#define VT4
#define VLEX4
#define CLSR4
static L3(int, object);
int Ladjoin();
#define VT5
#define VLEX5
#define CLSR5
static L4(int, object, object, object);
#define VT6
#define VLEX6
#define CLSR6
static struct codeblock Cblock;
#define VM6 0
#define VM5 0
#define VM4 0
#define VM3 0
#define VM2 0
#define VM1 49
static object VV[49];
static LKF0(int, ...);
static (*LK0)(int, ...)=LKF0;
static LKF1(int, ...);
static (*LK1)(int, ...)=LKF1;
static LKF2(int, ...);
static (*LK2)(int, ...)=LKF2;
static LKF3(int, ...);
static (*LK3)(int, ...)=LKF3;
static LKF4(int, ...);
static (*LK4)(int, ...)=LKF4;
static LKF5(int, ...);
static (*LK5)(int, ...)=LKF5;
static LKF6(int, ...);
static (*LK6)(int, ...)=LKF6;
static LKF7(int, ...);
static (*LK7)(int, ...)=LKF7;
static LKF8(int, ...);
static (*LK8)(int, ...)=LKF8;
static LKF9(int, ...);
static (*LK9)(int, ...)=LKF9;
static LKF10(int, ...);
static (*LK10)(int, ...)=LKF10;
static LKF11(int, ...);
static (*LK11)(int, ...)=LKF11;
static LKF12(int, ...);
static (*LK12)(int, ...)=LKF12;
static LKF13(int, ...);
static (*LK13)(int, ...)=LKF13;
static LKF14(int, ...);
static (*LK14)(int, ...)=LKF14;
static LKF15(int, ...);
static (*LK15)(int, ...)=LKF15;
static LKF16(int, ...);
static (*LK16)(int, ...)=LKF16;
