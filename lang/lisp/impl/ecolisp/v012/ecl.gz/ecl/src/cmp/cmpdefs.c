
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "cmpdefs.h"
init_cmpdefs(int size, object data_stream)
{VT2 CLSR2
	Cblock.cd_start=(char *)init_cmpdefs; Cblock.cd_size=size;
	Cblock.cd_data=read_VV(VV,VM1,data_stream);
	funcall(13,VV[43]->s.s_gfdef,VV[0],VV[1],VV[2],Cnil,VV[3],VV[4],VV[5],Cnil,Cnil,VV[6],MAKE_FIXNUM(3),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[44],L1,3,L1keys);
	funcall(13,VV[43]->s.s_gfdef,VV[7],VV[8],VV[2],Ct,VV[9],VV[10],VV[11],VV[0],Cnil,VV[12],MAKE_FIXNUM(7),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[45],L2,6,L2keys);
	funcall(5,VV[46]->s.s_gfdef,VV[7],VV[2],Ct,MAKE_FIXNUM(3))/*  MAKE-PREDICATE*/;
	siLfset(2,VV[14],VALUES(0))               /*  FSET            */;
	funcall(13,VV[43]->s.s_gfdef,VV[15],VV[16],VV[2],Ct,VV[17],VV[18],VV[19],VV[0],Cnil,VV[20],MAKE_FIXNUM(9),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[47],L3,8,L3keys);
	funcall(5,VV[46]->s.s_gfdef,VV[15],VV[2],Ct,MAKE_FIXNUM(3))/*  MAKE-PREDICATE*/;
	siLfset(2,VV[21],VALUES(0))               /*  FSET            */;
	funcall(13,VV[43]->s.s_gfdef,VV[22],VV[23],VV[2],Ct,VV[24],VV[25],VV[26],VV[0],Cnil,VV[27],MAKE_FIXNUM(8),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[48],L4,7,L4keys);
	funcall(5,VV[46]->s.s_gfdef,VV[22],VV[2],Ct,MAKE_FIXNUM(3))/*  MAKE-PREDICATE*/;
	siLfset(2,VV[28],VALUES(0))               /*  FSET            */;
	funcall(13,VV[43]->s.s_gfdef,VV[29],VV[30],VV[2],Ct,VV[31],VV[32],VV[33],VV[0],Cnil,VV[34],MAKE_FIXNUM(8),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[49],L5,7,L5keys);
	funcall(5,VV[46]->s.s_gfdef,VV[29],VV[2],Ct,MAKE_FIXNUM(3))/*  MAKE-PREDICATE*/;
	siLfset(2,VV[35],VALUES(0))               /*  FSET            */;
	funcall(13,VV[43]->s.s_gfdef,VV[36],VV[37],VV[2],Ct,VV[38],VV[39],VV[40],Cnil,Cnil,VV[41],MAKE_FIXNUM(7),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[50],L6,6,L6keys);
	funcall(5,VV[46]->s.s_gfdef,VV[36],VV[2],Ct,MAKE_FIXNUM(0))/*  MAKE-PREDICATE*/;
	siLfset(2,VV[42],VALUES(0))               /*  FSET            */;
}
/*	function definition for MAKE-REF                              */
static L1(int narg, ...)
{ VT3 VLEX3 CLSR3
	{object V1;
	object V2;
	object V3;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[6];
	parse_key(narg,args,3,L1keys,keyvars,OBJNULL,FALSE);
	V1= keyvars[0];
	if(keyvars[4]==Cnil){
	V2= MAKE_FIXNUM(0);
	}else{
	V2= keyvars[1];}
	V3= keyvars[2];
	}
	RETURN((*LK0)(3,(V1),(V2),(V3))           /*  VECTOR          */);
	}
}
/*	function definition for MAKE-VAR                              */
static L2(int narg, ...)
{ VT4 VLEX4 CLSR4
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[12];
	parse_key(narg,args,6,L2keys,keyvars,OBJNULL,FALSE);
	V1= keyvars[0];
	if(keyvars[7]==Cnil){
	V2= MAKE_FIXNUM(0);
	}else{
	V2= keyvars[1];}
	V3= keyvars[2];
	V4= keyvars[3];
	if(keyvars[10]==Cnil){
	V5= VV[13];
	}else{
	V5= keyvars[4];}
	if(keyvars[11]==Cnil){
	V6= Ct;
	}else{
	V6= keyvars[5];}
	}
	RETURN((*LK0)(7,(V1),(V2),(V3),VV[7],(V4),(V5),(V6))/*  VECTOR*/);
	}
}
/*	function definition for MAKE-FUN                              */
static L3(int narg, ...)
{ VT5 VLEX5 CLSR5
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[16];
	parse_key(narg,args,8,L3keys,keyvars,OBJNULL,FALSE);
	V1= keyvars[0];
	if(keyvars[9]==Cnil){
	V2= MAKE_FIXNUM(0);
	}else{
	V2= keyvars[1];}
	V3= keyvars[2];
	V4= keyvars[3];
	if(keyvars[12]==Cnil){
	V5= MAKE_FIXNUM(0);
	}else{
	V5= keyvars[4];}
	if(keyvars[13]==Cnil){
	V6= MAKE_FIXNUM(0);
	}else{
	V6= keyvars[5];}
	V7= keyvars[6];
	V8= keyvars[7];
	}
	RETURN((*LK0)(9,(V1),(V2),(V3),VV[15],(V4),(V5),(V6),(V7),(V8))/*  VECTOR*/);
	}
}
/*	function definition for MAKE-BLK                              */
static L4(int narg, ...)
{ VT6 VLEX6 CLSR6
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[14];
	parse_key(narg,args,7,L4keys,keyvars,OBJNULL,FALSE);
	V1= keyvars[0];
	if(keyvars[8]==Cnil){
	V2= MAKE_FIXNUM(0);
	}else{
	V2= keyvars[1];}
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	V7= keyvars[6];
	}
	RETURN((*LK0)(8,(V1),(V2),(V3),VV[22],(V4),(V5),(V6),(V7))/*  VECTOR*/);
	}
}
/*	function definition for MAKE-TAG                              */
static L5(int narg, ...)
{ VT7 VLEX7 CLSR7
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[14];
	parse_key(narg,args,7,L5keys,keyvars,OBJNULL,FALSE);
	V1= keyvars[0];
	if(keyvars[8]==Cnil){
	V2= MAKE_FIXNUM(0);
	}else{
	V2= keyvars[1];}
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	V7= keyvars[6];
	}
	RETURN((*LK0)(8,(V1),(V2),(V3),VV[29],(V4),(V5),(V6),(V7))/*  VECTOR*/);
	}
}
/*	function definition for MAKE-INFO                             */
static L6(int narg, ...)
{ VT8 VLEX8 CLSR8
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[12];
	parse_key(narg,args,6,L6keys,keyvars,OBJNULL,FALSE);
	V1= keyvars[0];
	V2= keyvars[1];
	if(keyvars[8]==Cnil){
	V3= Ct;
	}else{
	V3= keyvars[2];}
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	}
	RETURN((*LK0)(7,VV[36],(V1),(V2),(V3),(V4),(V5),(V6))/*  VECTOR*/);
	}
}
static LKF0(int narg, ...) {TRAMPOLINK(VV[2],&LK0);}
