
#include "attributes.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	siLAmake_constant(2,VV[0],MAKE_FIXNUM(44))/*  *MAKE-CONSTANT  */;
	siLAmake_constant(2,VV[1],MAKE_FIXNUM(24))/*  *MAKE-CONSTANT  */;
	Lmax(3,MAKE_FIXNUM(44),MAKE_FIXNUM(24),fixnum_times(16,4))/*  MAX*/;
	siLAmake_constant(2,VV[2],VALUES(0))      /*  *MAKE-CONSTANT  */;
	VV[3]->s.s_stype=(short)stp_special;
	if(VV[3]->s.s_dbind == OBJNULL){
	(VV[3]->s.s_dbind)= Cnil;}
	VV[4]->s.s_stype=(short)stp_special;
	if(VV[4]->s.s_dbind == OBJNULL){
	(VV[4]->s.s_dbind)= Cnil;}
	MF0(VV[116],L1);
	(void)putprop(VV[116],VV[Vdeb116],VV[117]);
	MF0(VV[118],L2);
	(void)putprop(VV[118],VV[Vdeb118],VV[117]);
	MM0(VV[119],L3);
	MM0(VV[120],L4);
	MM0(VV[121],L5);
	MM0(VV[122],L6);
	VV[11]=string_to_object(VV[11]);
	MM0(VV[123],L7);
	MM0(VV[124],L8);
	(void)putprop(VV[125],VV[23],siSpretty_print_format);
	
	MM0(VV[125],L9);
	MF0(VV[22],L10);
	(void)putprop(VV[22],VV[Vdeb22],VV[117]);
	MF0(VV[126],L11);
	(void)putprop(VV[126],VV[Vdeb126],VV[117]);
	MF0(VV[127],L12);
	(void)putprop(VV[127],VV[Vdeb127],VV[117]);
	MF0(VV[34],L13);
	(void)putprop(VV[34],VV[Vdeb34],VV[117]);
	MF0(VV[40],L14);
	(void)putprop(VV[40],VV[Vdeb40],VV[117]);
	MF0(VV[128],L15);
	(void)putprop(VV[128],VV[Vdeb128],VV[117]);
	MF0(VV[129],L16);
	(void)putprop(VV[129],VV[Vdeb129],VV[117]);
	(void)putprop(VV[130],VV[23],siSpretty_print_format);
	
	MM0(VV[130],L17);
	(void)putprop(VV[131],VV[23],siSpretty_print_format);
	
	MM0(VV[131],L18);
	MF0(VV[132],L19);
	(void)putprop(VV[132],VV[Vdeb132],VV[117]);
	MF0(VV[133],L20);
	(void)putprop(VV[133],VV[Vdeb133],VV[117]);
	MF0(VV[134],L21);
	(void)putprop(VV[134],VV[Vdeb134],VV[117]);
	MF0(VV[49],L22);
	(void)putprop(VV[49],VV[Vdeb49],VV[117]);
	putprop(VV[48],VV[49],VV[50]);
	remprop(VV[48],VV[51]);
	remprop(VV[48],VV[52]);
	putprop(VV[48],Cnil,VV[53]);
	MF0(VV[57],L23);
	(void)putprop(VV[57],VV[Vdeb57],VV[117]);
	putprop(VV[56],VV[57],VV[50]);
	remprop(VV[56],VV[51]);
	remprop(VV[56],VV[52]);
	putprop(VV[56],Cnil,VV[53]);
	MF0(VV[61],L24);
	(void)putprop(VV[61],VV[Vdeb61],VV[117]);
	MF0(VV[62],L25);
	(void)putprop(VV[62],VV[Vdeb62],VV[117]);
	putprop(VV[61],VV[62],VV[50]);
	remprop(VV[61],VV[51]);
	remprop(VV[61],VV[52]);
	putprop(VV[61],Cnil,VV[53]);
	MF0(VV[66],L26);
	(void)putprop(VV[66],VV[Vdeb66],VV[117]);
	MF0(VV[67],L27);
	(void)putprop(VV[67],VV[Vdeb67],VV[117]);
	putprop(VV[66],VV[67],VV[50]);
	remprop(VV[66],VV[51]);
	remprop(VV[66],VV[52]);
	putprop(VV[66],Cnil,VV[53]);
	MF0(VV[71],L28);
	(void)putprop(VV[71],VV[Vdeb71],VV[117]);
	MF0(VV[72],L29);
	(void)putprop(VV[72],VV[Vdeb72],VV[117]);
	putprop(VV[71],VV[72],VV[50]);
	remprop(VV[71],VV[51]);
	remprop(VV[71],VV[52]);
	putprop(VV[71],Cnil,VV[53]);
	MF0(VV[73],L30);
	(void)putprop(VV[73],VV[Vdeb73],VV[117]);
	MF0(VV[74],L31);
	(void)putprop(VV[74],VV[Vdeb74],VV[117]);
	putprop(VV[73],VV[74],VV[50]);
	remprop(VV[73],VV[51]);
	remprop(VV[73],VV[52]);
	putprop(VV[73],Cnil,VV[53]);
	MF0(VV[75],L32);
	(void)putprop(VV[75],VV[Vdeb75],VV[117]);
	MF0(VV[76],L33);
	(void)putprop(VV[76],VV[Vdeb76],VV[117]);
	putprop(VV[75],VV[76],VV[50]);
	remprop(VV[75],VV[51]);
	remprop(VV[75],VV[52]);
	putprop(VV[75],Cnil,VV[53]);
	MF0(VV[80],L34);
	(void)putprop(VV[80],VV[Vdeb80],VV[117]);
	MF0(VV[81],L35);
	(void)putprop(VV[81],VV[Vdeb81],VV[117]);
	putprop(VV[80],VV[81],VV[50]);
	remprop(VV[80],VV[51]);
	remprop(VV[80],VV[52]);
	putprop(VV[80],Cnil,VV[53]);
	MF0(VV[85],L36);
	(void)putprop(VV[85],VV[Vdeb85],VV[117]);
	MF0(VV[86],L37);
	(void)putprop(VV[86],VV[Vdeb86],VV[117]);
	putprop(VV[85],VV[86],VV[50]);
	remprop(VV[85],VV[51]);
	remprop(VV[85],VV[52]);
	putprop(VV[85],Cnil,VV[53]);
	MF0(VV[87],L38);
	(void)putprop(VV[87],VV[Vdeb87],VV[117]);
	putprop(VV[87],VV[88],VV[51]);
	remprop(VV[87],VV[50]);
	remprop(VV[87],VV[52]);
	putprop(VV[87],Cnil,VV[53]);
	MF0(VV[89],L39);
	(void)putprop(VV[89],VV[Vdeb89],VV[117]);
	putprop(VV[89],VV[90],VV[51]);
	remprop(VV[89],VV[50]);
	remprop(VV[89],VV[52]);
	putprop(VV[89],Cnil,VV[53]);
	MF0(VV[93],L40);
	(void)putprop(VV[93],VV[Vdeb93],VV[117]);
	MF0(VV[94],L41);
	(void)putprop(VV[94],VV[Vdeb94],VV[117]);
	putprop(VV[93],VV[94],VV[50]);
	remprop(VV[93],VV[51]);
	remprop(VV[93],VV[52]);
	putprop(VV[93],Cnil,VV[53]);
	MF0(VV[96],L42);
	(void)putprop(VV[96],VV[Vdeb96],VV[117]);
	MF0(VV[99],L43);
	(void)putprop(VV[99],VV[Vdeb99],VV[117]);
	putprop(VV[96],VV[99],VV[50]);
	remprop(VV[96],VV[51]);
	remprop(VV[96],VV[52]);
	putprop(VV[96],Cnil,VV[53]);
	MF0(VV[135],L44);
	(void)putprop(VV[135],VV[Vdeb135],VV[117]);
	MF0(VV[136],L45);
	(void)putprop(VV[136],VV[Vdeb136],VV[117]);
	MF0(VV[137],L46);
	(void)putprop(VV[137],VV[Vdeb137],VV[117]);
	MF0(VV[138],L47);
	(void)putprop(VV[138],VV[Vdeb138],VV[117]);
	MF0(VV[102],L48);
	(void)putprop(VV[102],VV[Vdeb102],VV[117]);
	MF0(VV[103],L49);
	(void)putprop(VV[103],VV[Vdeb103],VV[117]);
	putprop(VV[102],VV[103],VV[50]);
	remprop(VV[102],VV[51]);
	remprop(VV[102],VV[52]);
	putprop(VV[102],Cnil,VV[53]);
	MF0(VV[104],L50);
	(void)putprop(VV[104],VV[Vdeb104],VV[117]);
	MF0(VV[105],L51);
	(void)putprop(VV[105],VV[Vdeb105],VV[117]);
	putprop(VV[104],VV[105],VV[50]);
	remprop(VV[104],VV[51]);
	remprop(VV[104],VV[52]);
	putprop(VV[104],Cnil,VV[53]);
	MF0(VV[106],L52);
	(void)putprop(VV[106],VV[Vdeb106],VV[117]);
	MF0(VV[107],L53);
	(void)putprop(VV[107],VV[Vdeb107],VV[117]);
	putprop(VV[106],VV[107],VV[50]);
	remprop(VV[106],VV[51]);
	remprop(VV[106],VV[52]);
	putprop(VV[106],Cnil,VV[53]);
	MF0(VV[108],L54);
	(void)putprop(VV[108],VV[Vdeb108],VV[117]);
	MF0(VV[109],L55);
	(void)putprop(VV[109],VV[Vdeb109],VV[117]);
	putprop(VV[108],VV[109],VV[50]);
	remprop(VV[108],VV[51]);
	remprop(VV[108],VV[52]);
	putprop(VV[108],Cnil,VV[53]);
	MF0(VV[139],L56);
	(void)putprop(VV[139],VV[Vdeb139],VV[117]);
	MF0(VV[110],L57);
	(void)putprop(VV[110],VV[Vdeb110],VV[117]);
	MF0(VV[111],L58);
	(void)putprop(VV[111],VV[Vdeb111],VV[117]);
	putprop(VV[110],VV[111],VV[50]);
	remprop(VV[110],VV[51]);
	remprop(VV[110],VV[52]);
	putprop(VV[110],Cnil,VV[53]);
	MF0(VV[140],L59);
	(void)putprop(VV[140],VV[Vdeb140],VV[117]);
	putprop(VV[114],VV[115],VV[51]);
	remprop(VV[114],VV[50]);
	remprop(VV[114],VV[52]);
	putprop(VV[114],Cnil,VV[53]);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	function definition for ALLOCATE-CONTEXT                      */
static L1(int narg)
{ VT3 VLEX3 CLSR3
TTL:
L108:
	{register object V1;
	V1= (VV[4]->s.s_dbind);
	if(((V1))!=Cnil){
	goto L111;}
	VALUES(0) = Cnil;
	goto L106;
L111:
	if(!(((VV[4]->s.s_dbind))==((V1)))){
	goto L116;}
	(VV[4]->s.s_dbind)= ((V1))->in.in_slots[2];
	goto L114;
L116:
	goto L109;
L114:
	((V1))->in.in_slots[2]= Cnil;
	VALUES(0) = (V1);
	goto L106;
	}
L109:
	goto L108;
L106:
	if(VALUES(0)==Cnil)goto L105;
	RETURN(1);
L105:
	RETURN((*LK0)(1,MAKE_FIXNUM(64))          /*  MAKE-REPLY-BUFFER*/);
}
/*	function definition for DEALLOCATE-CONTEXT                    */
static L2(int narg, object V1)
{ VT4 VLEX4 CLSR4
TTL:
	{volatile object V2;
	V2= (V1);
L123:
	{register object V3;
	V3= (VV[4]->s.s_dbind);
	((V2))->in.in_slots[2]= (V3);
	if(!(((VV[4]->s.s_dbind))==((V3)))){
	goto L129;}
	(VV[4]->s.s_dbind)= (V2);
	goto L127;
L129:
	goto L124;
L127:
	VALUES(0) = (V2);
	RETURN(1);
	}
L124:
	goto L123;
	}
}
/*	macro definition for STATE-ATTRIBUTES                         */
static L3(int narg, object V1, object V2)
{ VT5 VLEX5 CLSR5
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(2,VV[6],(V4));
	RETURN(1);}
}
/*	macro definition for STATE-ATTRIBUTE-CHANGES                  */
static L4(int narg, object V1, object V2)
{ VT6 VLEX6 CLSR6
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(2,VV[7],(V4));
	RETURN(1);}
}
/*	macro definition for STATE-GEOMETRY                           */
static L5(int narg, object V1, object V2)
{ VT7 VLEX7 CLSR7
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(2,VV[8],(V4));
	RETURN(1);}
}
/*	macro definition for STATE-GEOMETRY-CHANGES                   */
static L6(int narg, object V1, object V2)
{ VT8 VLEX8 CLSR8
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(2,VV[9],(V4));
	RETURN(1);}
}
/*	macro definition for DRAWABLE-EQUAL-FUNCTION                  */
static L7(int narg, object V1, object V2)
{ VT9 VLEX9 CLSR9
	{object V3=CDR(V1);
	if((memql(VV[10],VV[11]))==Cnil){
	goto L135;}
	VALUES(0) = VV[12];
	RETURN(1);
L135:
	VALUES(0) = VV[13];
	RETURN(1);}
}
/*	macro definition for WINDOW-EQUAL-FUNCTION                    */
static L8(int narg, object V1, object V2)
{ VT10 VLEX10 CLSR10
	{object V3=CDR(V1);
	if((memql(VV[14],VV[11]))==Cnil){
	goto L138;}
	VALUES(0) = VV[15];
	RETURN(1);
L138:
	VALUES(0) = VV[16];
	RETURN(1);}
}
/*	macro definition for WITH-STATE                               */
static L9(int narg, object V1, object V2)
{ VT11 VLEX11 CLSR11
	{object V3=CDR(V1),V4,V5;
	{object V6= CAR(V3);
	V4= CAR(V6);}
	V3=CDR(V3);
	V5= V3;
	{object V7;                               /*  STATE-ENTRY     */
	Lgensym(0)                                /*  GENSYM          */;
	V7= VALUES(0);
	{object V8= listA(3,(V7),(V4),VV[18]);
	{object V9= list(3,VV[3],(V7),VV[3]);
	{object V10= CONS(VV[21],(V5));
	VALUES(0) = list(3,VV[17],(V8),list(3,VV[19],(V9),list(3,VV[20],(V10),list(2,VV[22],(V7)))));
	RETURN(1);}}}
	}}
}
/*	function definition for CLEANUP-STATE-ENTRY                   */
static L10(int narg, object V1)
{ VT12 VLEX12 CLSR12
TTL:
	{object V2;                               /*  ENTRY           */
	V2= CADR((V1));
	if(((V2))==Cnil){
	goto L141;}
	L2(1,(V2))                                /*  DEALLOCATE-CONTEXT*/;
	}
L141:
	{object V2;                               /*  ENTRY           */
	V2= CADDR((V1));
	if(((V2))==Cnil){
	goto L145;}
	L15(2,CAR((V1)),(V2))                     /*  PUT-WINDOW-ATTRIBUTE-CHANGES*/;
	(*LK1)(1,(V2))                            /*  DEALLOCATE-GCONTEXT-STATE*/;
	}
L145:
	{object V2;                               /*  ENTRY           */
	V2= CADDDR((V1));
	if(((V2))==Cnil){
	goto L150;}
	L2(1,(V2))                                /*  DEALLOCATE-CONTEXT*/;
	}
L150:
	{object V2;                               /*  ENTRY           */
	Lfifth(1,(V1))                            /*  FIFTH           */;
	V2= VALUES(0);
	if(((V2))==Cnil){
	goto L156;}
	L16(2,CAR((V1)),(V2))                     /*  PUT-DRAWABLE-GEOMETRY-CHANGES*/;
	RETURN((*LK1)(1,(V2))                     /*  DEALLOCATE-GCONTEXT-STATE*/);
L156:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for CHANGE-WINDOW-ATTRIBUTE               */
static L11(int narg, object V1, object V2, object V3)
{ VT13 VLEX13 CLSR13
	{int V4;
	V4= fix(V2);
TTL:
	{object V5;                               /*  STATE-ENTRY     */
	register object V6;                       /*  CHANGES         */
	V5= Cnil;
	V6= Cnil;
	if(((VV[3]->s.s_dbind))==Cnil){
	goto L160;}
	Lassoc(4,(V1),(VV[3]->s.s_dbind),VV[24],VV[25])/*  ASSOC      */;
	V5= VALUES(0);
	if(((V5))==Cnil){
	goto L160;}
	V6= CADDR((V5));
	if(((V6))!=Cnil){
	goto L167;}
	(*LK2)(0)                                 /*  ALLOCATE-GCONTEXT-STATE*/;
	V6= VALUES(0);
	CAR(CDDR((V5))) = (V6);
	aset1((V6),0,MAKE_FIXNUM(0));
L167:
	{object V7= aref1((V6),0);
	Lash(2,MAKE_FIXNUM(1),MAKE_FIXNUM(V4))    /*  ASH             */;
	Llogior(2,(V7),VALUES(0))                 /*  LOGIOR          */;
	aset1((V6),fix(MAKE_FIXNUM(0)),VALUES(0));}
	VALUES(0) = aset1((V6),fix(one_plus(MAKE_FIXNUM(V4))),(V3));
	RETURN(1);
L160:
	{register object V7;                      /*  .DISPLAY.       */
	V7= ((V1))->in.in_slots[1];
	if((((V7))->in.in_slots[10])==Cnil){
	goto L178;}
	(*LK3)(3,VV[27],VV[28],(V7))              /*  X-ERROR         */;
L178:
	{ int V8;
	{register object V9;                      /*  %BUFFER         */
	V9= (V7);
	if(!(((fix(((V9))->in.in_slots[6]))+(160))>=(fix(((V9))->in.in_slots[2])))){
	goto L182;}
	(*LK4)(1,(V9))                            /*  BUFFER-FLUSH    */;
L182:
	{register int V10;                        /*  BUFFER-BOFFSET  */
	register object V11;                      /*  BUFFER-BBUF     */
	V10= fix(((V9))->in.in_slots[6]);
	V11= ((V9))->in.in_slots[7];
	((V7))->in.in_slots[4]= MAKE_FIXNUM(V10);
	(((V11))->ust.ust_self[(V10)+(0)]=(2));
	(*LK5)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L193;}
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L191;
L193:
	(*LK6)(2,(V1),VV[14])                     /*  X-TYPE-ERROR    */;
L191:
	{object V12;                              /*  .VALUE.         */
	Lash(2,MAKE_FIXNUM(1),MAKE_FIXNUM(V4))    /*  ASH             */;
	V12= VALUES(0);
	(*LK7)(2,(V12),VV[29])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L198;}
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(8))))=fix((V12)));
	goto L195;
L198:
	(*LK6)(2,(V12),VV[29])                    /*  X-TYPE-ERROR    */;
	}
L195:
	(*LK7)(2,(V3),VV[29])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L202;}
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(12))))=fix((V3)));
	goto L200;
L202:
	(*LK6)(2,(V3),VV[29])                     /*  X-TYPE-ERROR    */;
L200:
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(2))))=4);
	((V7))->in.in_slots[6]= MAKE_FIXNUM((V10)+(16));
	V8=(*LK8)(1,(V7))                         /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V8);
	(*LK9)(1,(V7))                            /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V8);
	RETURN(V8);}
	}
	}
	}
}
/*	function definition for CHANGE-DRAWABLE-GEOMETRY              */
static L12(int narg, object V1, object V2, object V3)
{ VT14 VLEX14 CLSR14
	{int V4;
	register int V5;
	V4= fix(V2);
	V5= fix(V3);
TTL:
	{object V6;                               /*  STATE-ENTRY     */
	register object V7;                       /*  CHANGES         */
	V6= Cnil;
	V7= Cnil;
	if(((VV[3]->s.s_dbind))==Cnil){
	goto L208;}
	Lassoc(4,(V1),(VV[3]->s.s_dbind),VV[24],VV[25])/*  ASSOC      */;
	V6= VALUES(0);
	if(((V6))==Cnil){
	goto L208;}
	Lfifth(1,(V6))                            /*  FIFTH           */;
	V7= VALUES(0);
	if(((V7))!=Cnil){
	goto L215;}
	(*LK2)(0)                                 /*  ALLOCATE-GCONTEXT-STATE*/;
	V7= VALUES(0);
	CAR(CDDDDR((V6))) = (V7);
	aset1((V7),0,MAKE_FIXNUM(0));
L215:
	{object V8= aref1((V7),0);
	Lash(2,MAKE_FIXNUM(1),MAKE_FIXNUM(V4))    /*  ASH             */;
	Llogior(2,(V8),VALUES(0))                 /*  LOGIOR          */;
	aset1((V7),fix(MAKE_FIXNUM(0)),VALUES(0));}
	VALUES(0) = aset1((V7),fix(one_plus(MAKE_FIXNUM(V4))),MAKE_FIXNUM(V5));
	RETURN(1);
L208:
	{register object V8;                      /*  .DISPLAY.       */
	V8= ((V1))->in.in_slots[1];
	if((((V8))->in.in_slots[10])==Cnil){
	goto L226;}
	(*LK3)(3,VV[27],VV[28],(V8))              /*  X-ERROR         */;
L226:
	{ int V9;
	{register object V10;                     /*  %BUFFER         */
	V10= (V8);
	if(!(((fix(((V10))->in.in_slots[6]))+(160))>=(fix(((V10))->in.in_slots[2])))){
	goto L230;}
	(*LK4)(1,(V10))                           /*  BUFFER-FLUSH    */;
L230:
	{register int V11;                        /*  BUFFER-BOFFSET  */
	register object V12;                      /*  BUFFER-BBUF     */
	V11= fix(((V10))->in.in_slots[6]);
	V12= ((V10))->in.in_slots[7];
	((V8))->in.in_slots[4]= MAKE_FIXNUM(V11);
	(((V12))->ust.ust_self[(V11)+(0)]=(12));
	(*LK10)(1,(V1))                           /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L241;}
	((*(unsigned long *)(((V12))->ust.ust_self+((V11)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L239;
L241:
	(*LK6)(2,(V1),VV[10])                     /*  X-TYPE-ERROR    */;
L239:
	{object V13;                              /*  .VALUE.         */
	Lash(2,MAKE_FIXNUM(1),MAKE_FIXNUM(V4))    /*  ASH             */;
	V13= VALUES(0);
	(*LK7)(2,(V13),VV[30])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L246;}
	((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(8))))=fix((V13)));
	goto L243;
L246:
	(*LK6)(2,(V13),VV[30])                    /*  X-TYPE-ERROR    */;
	}
L243:
	(*LK7)(2,MAKE_FIXNUM(V5),VV[31])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L250;}
	((*(unsigned long *)(((V12))->ust.ust_self+((V11)+(12))))=V5);
	goto L248;
L250:
	(*LK6)(2,MAKE_FIXNUM(V5),VV[31])          /*  X-TYPE-ERROR    */;
L248:
	((*(unsigned short *)(((V12))->ust.ust_self+((V11)+(2))))=4);
	((V8))->in.in_slots[6]= MAKE_FIXNUM((V11)+(16));
	V9=(*LK8)(1,(V8))                         /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V9);
	(*LK9)(1,(V8))                            /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V9);
	RETURN(V9);}
	}
	}
	}
}
/*	function definition for GET-WINDOW-ATTRIBUTES-BUFFER          */
static L13(int narg, object V1)
{ VT15 VLEX15 CLSR15
TTL:
	{volatile object V2;                      /*  STATE-ENTRY     */
	volatile object V3;                       /*  CHANGES         */
	V2= Cnil;
	V3= Cnil;
	if((VV[3]->s.s_dbind)==Cnil){
	VALUES(0) = Cnil;
	goto L256;}
	Lassoc(4,(V1),(VV[3]->s.s_dbind),VV[24],VV[25])/*  ASSOC      */;
	V2= VALUES(0);
	if(((V2))!=Cnil){
	goto L257;}
	VALUES(0) = Cnil;
	goto L256;
L257:
	V3= CADDR((V2));
	if((V3)==Cnil){
	goto L260;}
	VALUES(0) = Cnil;
	goto L256;
L260:
	VALUES(0) = CADR((V2));
L256:
	if(VALUES(0)==Cnil)goto L255;
	RETURN(1);
L255:
	{volatile object V4;                      /*  DISPLAY         */
	V4= ((V1))->in.in_slots[1];
	if((((V4))->in.in_slots[10])==Cnil){
	goto L264;}
	(*LK3)(3,VV[27],VV[28],(V4))              /*  X-ERROR         */;
L264:
	if(((V3))==Cnil){
	goto L267;}
	L15(2,(V1),(V3))                          /*  PUT-WINDOW-ATTRIBUTE-CHANGES*/;
	(*LK1)(1,CADDR((V2)))                     /*  DEALLOCATE-GCONTEXT-STATE*/;
	CAR(CDDR((V2))) = Cnil;
L267:
	{volatile object V5;                      /*  .DISPLAY.       */
	volatile object V6;                       /*  .PENDING-COMMAND.*/
	volatile object V7;                       /*  .REPLY-BUFFER.  */
	V5= (V4);
	V6= Cnil;
	V7= Cnil;
	{ int V8; volatile bool unwinding = FALSE;
	if ((V8=frs_push(FRS_PROTECT,Cnil))) {
	V8--; unwinding = TRUE;} else {
	(*LK11)(1,(V5))                           /*  START-PENDING-COMMAND*/;
	V6= VALUES(0);
	{register object V9;                      /*  %BUFFER         */
	V9= (V5);
	if(!(((fix(((V9))->in.in_slots[6]))+(160))>=(fix(((V9))->in.in_slots[2])))){
	goto L280;}
	(*LK4)(1,(V9))                            /*  BUFFER-FLUSH    */;
L280:
	{register int V10;                        /*  BUFFER-BOFFSET  */
	object V11;                               /*  BUFFER-BBUF     */
	V10= fix(((V9))->in.in_slots[6]);
	V11= ((V9))->in.in_slots[7];
	((V5))->in.in_slots[4]= MAKE_FIXNUM(V10);
	(((V11))->ust.ust_self[(V10)+(0)]=(3));
	(*LK5)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L291;}
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L289;
L291:
	(*LK6)(2,(V1),VV[14])                     /*  X-TYPE-ERROR    */;
L289:
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(2))))=2);
	((V5))->in.in_slots[6]= MAKE_FIXNUM((V10)+(8));
	(*LK8)(1,(V5))                            /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK12)(1,(V5))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK9)(1,(V5))                            /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK13)(2,(V5),(V6))                      /*  READ-REPLY      */;
	V7= VALUES(0);
	{int V9;                                  /*  SIZE            */
	V9= fix(((V7))->in.in_slots[3]);
	{object V10;                              /*  %REPLY-BUFFER   */
	object V11;                               /*  %BUFFER         */
	{object V12;                              /*  BUFFER-BBUF     */
	V12= ((V7))->in.in_slots[1];
	{object V13;                              /*  REPBUF          */
	VALUES(0) = CADR((V2));
	if(VALUES(0)==Cnil)goto L305;
	V13= VALUES(0);
	goto L304;
L305:
	L1(0)                                     /*  ALLOCATE-CONTEXT*/;
	V13= VALUES(0);
L304:
	(*LK14)(4,((V13))->in.in_slots[1],(V12),MAKE_FIXNUM(0),MAKE_FIXNUM(V9))/*  BUFFER-REPLACE*/;
	if(((V2))==Cnil){
	goto L308;}
	CAR(CDR((V2))) = (V13);
L308:
	VALUES(0)=(V13);
	V8=1;
	}
	}
	}
	}
	}
	frs_pop();
	MV_SAVE(V8);
	if(((V7))==Cnil){
	goto L313;}
	(*LK15)(1,(V7))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L313:
	if(((V6))==Cnil){
	goto L312;}
	(*LK16)(2,(V5),(V6))                      /*  STOP-PENDING-COMMAND*/;
L312:
	MV_RESTORE(V8);
	if (unwinding) unwind(nlj_fr,nlj_tag,V8+1);
	else {
	RETURN(V8);}}
	}
	}
	}
}
/*	function definition for GET-DRAWABLE-GEOMETRY-BUFFER          */
static L14(int narg, object V1)
{ VT16 VLEX16 CLSR16
TTL:
	{volatile object V2;                      /*  STATE-ENTRY     */
	volatile object V3;                       /*  CHANGES         */
	V2= Cnil;
	V3= Cnil;
	if((VV[3]->s.s_dbind)==Cnil){
	VALUES(0) = Cnil;
	goto L319;}
	Lassoc(4,(V1),(VV[3]->s.s_dbind),VV[24],VV[25])/*  ASSOC      */;
	V2= VALUES(0);
	if(((V2))!=Cnil){
	goto L320;}
	VALUES(0) = Cnil;
	goto L319;
L320:
	Lfifth(1,(V2))                            /*  FIFTH           */;
	V3= VALUES(0);
	if((V3)==Cnil){
	goto L323;}
	VALUES(0) = Cnil;
	goto L319;
L323:
	VALUES(0) = CADDDR((V2));
L319:
	if(VALUES(0)==Cnil)goto L318;
	RETURN(1);
L318:
	{volatile object V4;                      /*  DISPLAY         */
	V4= ((V1))->in.in_slots[1];
	if((((V4))->in.in_slots[10])==Cnil){
	goto L327;}
	(*LK3)(3,VV[27],VV[28],(V4))              /*  X-ERROR         */;
L327:
	if(((V3))==Cnil){
	goto L330;}
	L16(2,(V1),(V3))                          /*  PUT-DRAWABLE-GEOMETRY-CHANGES*/;
	Lfifth(1,(V2))                            /*  FIFTH           */;
	(*LK1)(1,VALUES(0))                       /*  DEALLOCATE-GCONTEXT-STATE*/;
	CAR(CDDDDR((V2))) = Cnil;
L330:
	{volatile object V5;                      /*  .DISPLAY.       */
	volatile object V6;                       /*  .PENDING-COMMAND.*/
	volatile object V7;                       /*  .REPLY-BUFFER.  */
	V5= (V4);
	V6= Cnil;
	V7= Cnil;
	{ int V8; volatile bool unwinding = FALSE;
	if ((V8=frs_push(FRS_PROTECT,Cnil))) {
	V8--; unwinding = TRUE;} else {
	(*LK11)(1,(V5))                           /*  START-PENDING-COMMAND*/;
	V6= VALUES(0);
	{register object V9;                      /*  %BUFFER         */
	V9= (V5);
	if(!(((fix(((V9))->in.in_slots[6]))+(160))>=(fix(((V9))->in.in_slots[2])))){
	goto L344;}
	(*LK4)(1,(V9))                            /*  BUFFER-FLUSH    */;
L344:
	{register int V10;                        /*  BUFFER-BOFFSET  */
	object V11;                               /*  BUFFER-BBUF     */
	V10= fix(((V9))->in.in_slots[6]);
	V11= ((V9))->in.in_slots[7];
	((V5))->in.in_slots[4]= MAKE_FIXNUM(V10);
	(((V11))->ust.ust_self[(V10)+(0)]=(14));
	(*LK10)(1,(V1))                           /*  DRAWABLE-P      */;
	if(VALUES(0)==Cnil){
	goto L355;}
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L353;
L355:
	(*LK6)(2,(V1),VV[10])                     /*  X-TYPE-ERROR    */;
L353:
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(2))))=2);
	((V5))->in.in_slots[6]= MAKE_FIXNUM((V10)+(8));
	(*LK8)(1,(V5))                            /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	(*LK12)(1,(V5))                           /*  BUFFER-FORCE-OUTPUT*/;
	(*LK9)(1,(V5))                            /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	(*LK13)(2,(V5),(V6))                      /*  READ-REPLY      */;
	V7= VALUES(0);
	{int V9;                                  /*  SIZE            */
	V9= fix(((V7))->in.in_slots[3]);
	{object V10;                              /*  %REPLY-BUFFER   */
	object V11;                               /*  %BUFFER         */
	{object V12;                              /*  BUFFER-BBUF     */
	V12= ((V7))->in.in_slots[1];
	{object V13;                              /*  REPBUF          */
	VALUES(0) = CADDDR((V2));
	if(VALUES(0)==Cnil)goto L369;
	V13= VALUES(0);
	goto L368;
L369:
	L1(0)                                     /*  ALLOCATE-CONTEXT*/;
	V13= VALUES(0);
L368:
	(*LK14)(4,((V13))->in.in_slots[1],(V12),MAKE_FIXNUM(0),MAKE_FIXNUM(V9))/*  BUFFER-REPLACE*/;
	if(((V2))==Cnil){
	goto L372;}
	CAR(CDDDR((V2))) = (V13);
L372:
	VALUES(0)=(V13);
	V8=1;
	}
	}
	}
	}
	}
	frs_pop();
	MV_SAVE(V8);
	if(((V7))==Cnil){
	goto L377;}
	(*LK15)(1,(V7))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L377:
	if(((V6))==Cnil){
	goto L376;}
	(*LK16)(2,(V5),(V6))                      /*  STOP-PENDING-COMMAND*/;
L376:
	MV_RESTORE(V8);
	if (unwinding) unwind(nlj_fr,nlj_tag,V8+1);
	else {
	RETURN(V8);}}
	}
	}
	}
}
/*	function definition for PUT-WINDOW-ATTRIBUTE-CHANGES          */
static L15(int narg, object V1, object V2)
{ VT17 VLEX17 CLSR17
TTL:
	{volatile object V3;                      /*  DISPLAY         */
	volatile object V4;                       /*  MASK            */
	V3= ((V1))->in.in_slots[1];
	V4= ((V2))->v.v_self[0];
	{volatile object V5;                      /*  .DISPLAY.       */
	V5= (V3);
	if((((V5))->in.in_slots[10])==Cnil){
	goto L384;}
	(*LK3)(3,VV[27],VV[28],(V5))              /*  X-ERROR         */;
L384:
	{ int V6;
	{volatile object V7;                      /*  %BUFFER         */
	V7= (V5);
	if(!(((fix(((V7))->in.in_slots[6]))+(160))>=(fix(((V7))->in.in_slots[2])))){
	goto L388;}
	(*LK4)(1,(V7))                            /*  BUFFER-FLUSH    */;
L388:
	{volatile int V8;                         /*  BUFFER-BOFFSET  */
	volatile object V9;                       /*  BUFFER-BBUF     */
	V8= fix(((V7))->in.in_slots[6]);
	V9= ((V7))->in.in_slots[7];
	((V5))->in.in_slots[4]= MAKE_FIXNUM(V8);
	(((V9))->ust.ust_self[(V8)+(0)]=(2));
	(*LK5)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L399;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L397;
L399:
	(*LK6)(2,(V1),VV[14])                     /*  X-TYPE-ERROR    */;
L397:
	(*LK7)(2,(V4),VV[29])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L403;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(8))))=fix((V4)));
	goto L401;
L403:
	(*LK6)(2,(V4),VV[29])                     /*  X-TYPE-ERROR    */;
L401:
	{volatile object V10;                     /*  .VALUE.         */
	{volatile object V11;                     /*  BITS            */
	volatile int V12;                         /*  REQUEST-SIZE    */
	volatile int V13;                         /*  I               */
	V12= 2;
	V13= 1;
	V11= (V4);
L410:
	if(!(number_compare(MAKE_FIXNUM(0),(V11))==0)){
	goto L411;}
	V12= (V12)+(1);
	T0= MAKE_FIXNUM(V12);
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=fix(T0));
	{register object V15;
	register object V16;
	V15= (V3);
	V16= MAKE_FIXNUM((fix(((V15))->in.in_slots[6]))+((V12)*(4)));
	((V15))->in.in_slots[6]= (V16);
	V10= (V16);
	goto L406;
	}
L411:
	Loddp(1,(V11))                            /*  ODDP            */;
	if(VALUES(0)==Cnil){
	goto L419;}
	{object V17= ((V2))->v.v_self[V13];
	V12= (V12)+(1);
	VALUES(0) = MAKE_FIXNUM(V12);
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+((fix(VALUES(0)))*(4)))))=fix((V17)));}
L419:
	Lash(2,(V11),MAKE_FIXNUM(-1))             /*  SHIFT>>         */;
	V11= VALUES(0);
	V13= (V13)+(1);
	goto L410;
	}
L406:
	}
	V6=(*LK8)(1,(V5))                         /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V6);
	(*LK9)(1,(V5))                            /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V6);
	RETURN(V6);}
	}
	}
}
/*	function definition for PUT-DRAWABLE-GEOMETRY-CHANGES         */
static L16(int narg, object V1, object V2)
{ VT18 VLEX18 CLSR18
TTL:
	{volatile object V3;                      /*  DISPLAY         */
	volatile int V4;                          /*  MASK            */
	V3= ((V1))->in.in_slots[1];
	V4= fix(((V2))->v.v_self[0]);
	{volatile object V5;                      /*  .DISPLAY.       */
	V5= (V3);
	if((((V5))->in.in_slots[10])==Cnil){
	goto L431;}
	(*LK3)(3,VV[27],VV[28],(V5))              /*  X-ERROR         */;
L431:
	{ int V6;
	{volatile object V7;                      /*  %BUFFER         */
	V7= (V5);
	if(!(((fix(((V7))->in.in_slots[6]))+(160))>=(fix(((V7))->in.in_slots[2])))){
	goto L435;}
	(*LK4)(1,(V7))                            /*  BUFFER-FLUSH    */;
L435:
	{volatile int V8;                         /*  BUFFER-BOFFSET  */
	volatile object V9;                       /*  BUFFER-BBUF     */
	V8= fix(((V7))->in.in_slots[6]);
	V9= ((V7))->in.in_slots[7];
	((V5))->in.in_slots[4]= MAKE_FIXNUM(V8);
	(((V9))->ust.ust_self[(V8)+(0)]=(12));
	(*LK5)(1,(V1))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L446;}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(4))))=fix(((V1))->in.in_slots[0]));
	goto L444;
L446:
	(*LK6)(2,(V1),VV[14])                     /*  X-TYPE-ERROR    */;
L444:
	(*LK7)(2,MAKE_FIXNUM(V4),VV[30])          /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L450;}
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(8))))=V4);
	goto L448;
L450:
	(*LK6)(2,MAKE_FIXNUM(V4),VV[30])          /*  X-TYPE-ERROR    */;
L448:
	{volatile object V10;                     /*  .VALUE.         */
	{volatile int V11;                        /*  BITS            */
	volatile int V12;                         /*  REQUEST-SIZE    */
	volatile int V13;                         /*  I               */
	V11= V4;
	V12= 2;
	V13= 1;
L458:
	if(!((V11)==0)){
	goto L459;}
	V12= (V12)+(1);
	T0= MAKE_FIXNUM(V12);
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(2))))=fix(T0));
	{register object V15;
	register object V16;
	V15= (V3);
	V16= MAKE_FIXNUM((fix(((V15))->in.in_slots[6]))+((V12)*(4)));
	((V15))->in.in_slots[6]= (V16);
	V10= (V16);
	goto L453;
	}
L459:
	Loddp(1,MAKE_FIXNUM(V11))                 /*  ODDP            */;
	if(VALUES(0)==Cnil){
	goto L467;}
	{object V17= ((V2))->v.v_self[V13];
	V12= (V12)+(1);
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+((V12)*(4)))))=fix((V17)));}
L467:
	V11= ((V11) >> (- (-1)));
	V13= (V13)+(1);
	goto L458;
	}
L453:
	}
	V6=(*LK8)(1,(V5))                         /*  BUFFER-NEW-REQUEST-NUMBER*/;
	}
	}
	MV_SAVE(V6);
	(*LK9)(1,(V5))                            /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V6);
	RETURN(V6);}
	}
	}
}
/*	macro definition for WITH-ATTRIBUTES                          */
static L17(int narg, object V1, object V2)
{ VT19 VLEX19 CLSR19
	{object V3=CDR(V1),V4,V5,V6;
	{object V7= CAR(V3);
	V4= CAR(V7);
	V7=CDR(V7);
	V5= V7;}
	V3=CDR(V3);
	V6= V3;
	{object V8= CONS(list(2,VV[33],list(2,VV[34],(V4))),Cnil);
	VALUES(0) = list(4,VV[32],(V8),VV[35],list(3,VV[36],listA(3,VV[37],CONS(VV[33],(V5)),(V6)),VV[38]));
	RETURN(1);}}
}
/*	macro definition for WITH-GEOMETRY                            */
static L18(int narg, object V1, object V2)
{ VT20 VLEX20 CLSR20
	{object V3=CDR(V1),V4,V5,V6;
	{object V7= CAR(V3);
	V4= CAR(V7);
	V7=CDR(V7);
	V5= V7;}
	V3=CDR(V3);
	V6= V3;
	{object V8= CONS(list(2,VV[39],list(2,VV[40],(V4))),Cnil);
	VALUES(0) = list(4,VV[32],(V8),VV[41],list(3,VV[36],listA(3,VV[37],CONS(VV[39],(V5)),(V6)),VV[42]));
	RETURN(1);}}
}
/*	function definition for WINDOW-VISUAL                         */
static L19(int narg, object V1)
{ VT21 VLEX21 CLSR21
TTL:
	{object V2;                               /*  .WITH-ATTRIBUTES-REPLY-BUFFER.*/
	L13(1,(V1))                               /*  GET-WINDOW-ATTRIBUTES-BUFFER*/;
	V2= VALUES(0);
	{int V3;
	{object V4;                               /*  %REPLY-BUFFER   */
	{int V5;                                  /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= 0;
	V6= ((V2))->in.in_slots[1];
	V3= ((*(unsigned long *)(((V6))->ust.ust_self+((V5)+(8)))) & 0x1fffffff);
	}
	}
	if(((VV[3]->s.s_dbind))!=Cnil){
	goto L482;}
	L2(1,(V2))                                /*  DEALLOCATE-CONTEXT*/;
L482:
	VALUES(0) = MAKE_FIXNUM(V3);
	RETURN(1);
	}
	}
}
/*	function definition for WINDOW-VISUAL-INFO                    */
static L20(int narg, object V1)
{ VT22 VLEX22 CLSR22
TTL:
	{object V2;                               /*  .WITH-ATTRIBUTES-REPLY-BUFFER.*/
	L13(1,(V1))                               /*  GET-WINDOW-ATTRIBUTES-BUFFER*/;
	V2= VALUES(0);
	{object V3;
	{object V4;                               /*  %REPLY-BUFFER   */
	{int V5;                                  /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= 0;
	V6= ((V2))->in.in_slots[1];
	T0= ((V1))->in.in_slots[1];
	(*LK17)(2,T0,MAKE_FIXNUM(((*(unsigned long *)(((V6))->ust.ust_self+((V5)+(8)))) & 0x1fffffff)))/*  VISUAL-INFO*/;
	V3= VALUES(0);
	}
	}
	if(((VV[3]->s.s_dbind))!=Cnil){
	goto L492;}
	L2(1,(V2))                                /*  DEALLOCATE-CONTEXT*/;
L492:
	VALUES(0) = (V3);
	RETURN(1);
	}
	}
}
/*	function definition for WINDOW-CLASS                          */
static L21(int narg, object V1)
{ VT23 VLEX23 CLSR23
TTL:
	{object V2;                               /*  .WITH-ATTRIBUTES-REPLY-BUFFER.*/
	L13(1,(V1))                               /*  GET-WINDOW-ATTRIBUTES-BUFFER*/;
	V2= VALUES(0);
	{object V3;
	{object V4;                               /*  %REPLY-BUFFER   */
	{int V5;                                  /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= 0;
	V6= ((V2))->in.in_slots[1];
	{int V7;
	V7= (*(unsigned short *)(((V6))->ust.ust_self+((V5)+(12))));
	if((V7)<(3)){
	goto L502;}
	V3= Cnil;
	goto L496;
L502:
	V3= (VV[43])->v.v_self[V7];
	}
	}
	}
L496:
	if(((VV[3]->s.s_dbind))!=Cnil){
	goto L504;}
	L2(1,(V2))                                /*  DEALLOCATE-CONTEXT*/;
L504:
	VALUES(0) = (V3);
	RETURN(1);
	}
	}
}
/*	function definition for SET-WINDOW-BACKGROUND                 */
static L22(int narg, object V1, object V2)
{ VT24 VLEX24 CLSR24
TTL:
	if(!(((V2))==(VV[44]))){
	goto L509;}
	L11(3,(V1),MAKE_FIXNUM(0),MAKE_FIXNUM(0)) /*  CHANGE-WINDOW-ATTRIBUTE*/;
	goto L507;
L509:
	if(!(((V2))==(VV[45]))){
	goto L512;}
	L11(3,(V1),MAKE_FIXNUM(0),MAKE_FIXNUM(1)) /*  CHANGE-WINDOW-ATTRIBUTE*/;
	goto L507;
L512:
	if(!(type_of((V2))==t_fixnum||type_of((V2))==t_bignum)){
	goto L515;}
	L11(3,(V1),MAKE_FIXNUM(0),MAKE_FIXNUM(0)) /*  CHANGE-WINDOW-ATTRIBUTE*/;
	L11(3,(V1),MAKE_FIXNUM(1),(V2))           /*  CHANGE-WINDOW-ATTRIBUTE*/;
	goto L507;
L515:
	(*LK18)(1,(V2))                           /*  PIXMAP-P        */;
	if(VALUES(0)==Cnil){
	goto L519;}
	L11(3,(V1),MAKE_FIXNUM(0),((V2))->in.in_slots[0])/*  CHANGE-WINDOW-ATTRIBUTE*/;
	goto L507;
L519:
	(*LK6)(2,(V2),VV[47])                     /*  X-TYPE-ERROR    */;
L507:
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for SET-WINDOW-BORDER                     */
static L23(int narg, object V1, object V2)
{ VT25 VLEX25 CLSR25
TTL:
	if(!(((V2))==(VV[54]))){
	goto L523;}
	L11(3,(V1),MAKE_FIXNUM(2),MAKE_FIXNUM(0)) /*  CHANGE-WINDOW-ATTRIBUTE*/;
	goto L521;
L523:
	(*LK18)(1,(V2))                           /*  PIXMAP-P        */;
	if(VALUES(0)==Cnil){
	goto L526;}
	L11(3,(V1),MAKE_FIXNUM(2),((V2))->in.in_slots[0])/*  CHANGE-WINDOW-ATTRIBUTE*/;
	goto L521;
L526:
	if(!(type_of((V2))==t_fixnum||type_of((V2))==t_bignum)){
	goto L529;}
	L11(3,(V1),MAKE_FIXNUM(3),(V2))           /*  CHANGE-WINDOW-ATTRIBUTE*/;
	goto L521;
L529:
	(*LK6)(2,(V2),VV[55])                     /*  X-TYPE-ERROR    */;
L521:
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for WINDOW-BIT-GRAVITY                    */
static L24(int narg, object V1)
{ VT26 VLEX26 CLSR26
TTL:
	{object V2;                               /*  .WITH-ATTRIBUTES-REPLY-BUFFER.*/
	L13(1,(V1))                               /*  GET-WINDOW-ATTRIBUTES-BUFFER*/;
	V2= VALUES(0);
	{object V3;
	{object V4;                               /*  %REPLY-BUFFER   */
	{int V5;                                  /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= 0;
	V6= ((V2))->in.in_slots[1];
	{int V7;
	V7= ((V6))->ust.ust_self[(V5)+(14)];
	if((V7)<(11)){
	goto L538;}
	V3= Cnil;
	goto L532;
L538:
	V3= (VV[58])->v.v_self[V7];
	}
	}
	}
L532:
	if(((VV[3]->s.s_dbind))!=Cnil){
	goto L540;}
	L2(1,(V2))                                /*  DEALLOCATE-CONTEXT*/;
L540:
	VALUES(0) = (V3);
	RETURN(1);
	}
	}
}
/*	function definition for SET-WINDOW-BIT-GRAVITY                */
static L25(int narg, object V1, object V2)
{ VT27 VLEX27 CLSR27
TTL:
	VALUES(0) = (VV[25]->s.s_gfdef);
	(*LK19)(4,(V2),VV[59],VV[24],VALUES(0))   /*  POSITION        */;
	if(VALUES(0)==Cnil)goto L545;
	goto L544;
L545:
	(*LK6)(2,(V2),VV[60])                     /*  X-TYPE-ERROR    */;
L544:
	L11(3,(V1),MAKE_FIXNUM(4),VALUES(0))      /*  CHANGE-WINDOW-ATTRIBUTE*/;
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for WINDOW-GRAVITY                        */
static L26(int narg, object V1)
{ VT28 VLEX28 CLSR28
TTL:
	{object V2;                               /*  .WITH-ATTRIBUTES-REPLY-BUFFER.*/
	L13(1,(V1))                               /*  GET-WINDOW-ATTRIBUTES-BUFFER*/;
	V2= VALUES(0);
	{object V3;
	{object V4;                               /*  %REPLY-BUFFER   */
	{int V5;                                  /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= 0;
	V6= ((V2))->in.in_slots[1];
	{int V7;
	V7= ((V6))->ust.ust_self[(V5)+(15)];
	if((V7)<(11)){
	goto L555;}
	V3= Cnil;
	goto L549;
L555:
	V3= (VV[63])->v.v_self[V7];
	}
	}
	}
L549:
	if(((VV[3]->s.s_dbind))!=Cnil){
	goto L557;}
	L2(1,(V2))                                /*  DEALLOCATE-CONTEXT*/;
L557:
	VALUES(0) = (V3);
	RETURN(1);
	}
	}
}
/*	function definition for SET-WINDOW-GRAVITY                    */
static L27(int narg, object V1, object V2)
{ VT29 VLEX29 CLSR29
TTL:
	VALUES(0) = (VV[25]->s.s_gfdef);
	(*LK19)(4,(V2),VV[64],VV[24],VALUES(0))   /*  POSITION        */;
	if(VALUES(0)==Cnil)goto L562;
	goto L561;
L562:
	(*LK6)(2,(V2),VV[65])                     /*  X-TYPE-ERROR    */;
L561:
	L11(3,(V1),MAKE_FIXNUM(5),VALUES(0))      /*  CHANGE-WINDOW-ATTRIBUTE*/;
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for WINDOW-BACKING-STORE                  */
static L28(int narg, object V1)
{ VT30 VLEX30 CLSR30
TTL:
	{object V2;                               /*  .WITH-ATTRIBUTES-REPLY-BUFFER.*/
	L13(1,(V1))                               /*  GET-WINDOW-ATTRIBUTES-BUFFER*/;
	V2= VALUES(0);
	{object V3;
	{object V4;                               /*  %REPLY-BUFFER   */
	{int V5;                                  /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= 0;
	V6= ((V2))->in.in_slots[1];
	{int V7;
	V7= ((V6))->ust.ust_self[(V5)+(1)];
	if((V7)<(3)){
	goto L572;}
	V3= Cnil;
	goto L566;
L572:
	V3= (VV[68])->v.v_self[V7];
	}
	}
	}
L566:
	if(((VV[3]->s.s_dbind))!=Cnil){
	goto L574;}
	L2(1,(V2))                                /*  DEALLOCATE-CONTEXT*/;
L574:
	VALUES(0) = (V3);
	RETURN(1);
	}
	}
}
/*	function definition for SET-WINDOW-BACKING-STORE              */
static L29(int narg, object V1, object V2)
{ VT31 VLEX31 CLSR31
TTL:
	{int V3;
	VALUES(0) = (VV[25]->s.s_gfdef);
	(*LK19)(4,(V2),VV[69],VV[24],VALUES(0))   /*  POSITION        */;
	V3= fix(VALUES(0));
	if(MAKE_FIXNUM(V3)==Cnil){
	VALUES(0) = Cnil;
	goto L580;}
	VALUES(0) = MAKE_FIXNUM(V3);
	}
L580:
	if(VALUES(0)==Cnil)goto L579;
	goto L578;
L579:
	(*LK6)(2,(V2),VV[70])                     /*  X-TYPE-ERROR    */;
L578:
	L11(3,(V1),MAKE_FIXNUM(6),VALUES(0))      /*  CHANGE-WINDOW-ATTRIBUTE*/;
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for WINDOW-BACKING-PLANES                 */
static L30(int narg, object V1)
{ VT32 VLEX32 CLSR32
TTL:
	{object V2;                               /*  .WITH-ATTRIBUTES-REPLY-BUFFER.*/
	L13(1,(V1))                               /*  GET-WINDOW-ATTRIBUTES-BUFFER*/;
	V2= VALUES(0);
	{int V3;
	{object V4;                               /*  %REPLY-BUFFER   */
	{int V5;                                  /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= 0;
	V6= ((V2))->in.in_slots[1];
	V3= (*(unsigned long *)(((V6))->ust.ust_self+((V5)+(16))));
	}
	}
	if(((VV[3]->s.s_dbind))!=Cnil){
	goto L589;}
	L2(1,(V2))                                /*  DEALLOCATE-CONTEXT*/;
L589:
	VALUES(0) = MAKE_FIXNUM(V3);
	RETURN(1);
	}
	}
}
/*	function definition for SET-WINDOW-BACKING-PLANES             */
static L31(int narg, object V1, object V2)
{ VT33 VLEX33 CLSR33
TTL:
	(*LK7)(2,(V2),VV[29])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L595;}
	VALUES(0) = (V2);
	goto L593;
L595:
	(*LK6)(2,(V2),VV[29])                     /*  X-TYPE-ERROR    */;
L593:
	L11(3,(V1),MAKE_FIXNUM(7),VALUES(0))      /*  CHANGE-WINDOW-ATTRIBUTE*/;
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for WINDOW-BACKING-PIXEL                  */
static L32(int narg, object V1)
{ VT34 VLEX34 CLSR34
TTL:
	{object V2;                               /*  .WITH-ATTRIBUTES-REPLY-BUFFER.*/
	L13(1,(V1))                               /*  GET-WINDOW-ATTRIBUTES-BUFFER*/;
	V2= VALUES(0);
	{int V3;
	{object V4;                               /*  %REPLY-BUFFER   */
	{int V5;                                  /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= 0;
	V6= ((V2))->in.in_slots[1];
	V3= (*(unsigned long *)(((V6))->ust.ust_self+((V5)+(20))));
	}
	}
	if(((VV[3]->s.s_dbind))!=Cnil){
	goto L603;}
	L2(1,(V2))                                /*  DEALLOCATE-CONTEXT*/;
L603:
	VALUES(0) = MAKE_FIXNUM(V3);
	RETURN(1);
	}
	}
}
/*	function definition for SET-WINDOW-BACKING-PIXEL              */
static L33(int narg, object V1, object V2)
{ VT35 VLEX35 CLSR35
TTL:
	(*LK7)(2,(V2),VV[29])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L609;}
	VALUES(0) = (V2);
	goto L607;
L609:
	(*LK6)(2,(V2),VV[29])                     /*  X-TYPE-ERROR    */;
L607:
	L11(3,(V1),MAKE_FIXNUM(8),VALUES(0))      /*  CHANGE-WINDOW-ATTRIBUTE*/;
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for WINDOW-SAVE-UNDER                     */
static L34(int narg, object V1)
{ VT36 VLEX36 CLSR36
TTL:
	{object V2;                               /*  .WITH-ATTRIBUTES-REPLY-BUFFER.*/
	L13(1,(V1))                               /*  GET-WINDOW-ATTRIBUTES-BUFFER*/;
	V2= VALUES(0);
	{object V3;
	{object V4;                               /*  %REPLY-BUFFER   */
	{int V5;                                  /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= 0;
	V6= ((V2))->in.in_slots[1];
	{int V7;
	V7= ((V6))->ust.ust_self[(V5)+(24)];
	if((V7)<(2)){
	goto L618;}
	V3= Cnil;
	goto L612;
L618:
	V3= (VV[77])->v.v_self[V7];
	}
	}
	}
L612:
	if(((VV[3]->s.s_dbind))!=Cnil){
	goto L620;}
	L2(1,(V2))                                /*  DEALLOCATE-CONTEXT*/;
L620:
	VALUES(0) = (V3);
	RETURN(1);
	}
	}
}
/*	function definition for SET-WINDOW-SAVE-UNDER                 */
static L35(int narg, object V1, object V2)
{ VT37 VLEX37 CLSR37
TTL:
	{int V3;
	VALUES(0) = (VV[25]->s.s_gfdef);
	(*LK19)(4,(V2),VV[78],VV[24],VALUES(0))   /*  POSITION        */;
	V3= fix(VALUES(0));
	if(MAKE_FIXNUM(V3)==Cnil){
	VALUES(0) = Cnil;
	goto L626;}
	VALUES(0) = MAKE_FIXNUM(V3);
	}
L626:
	if(VALUES(0)==Cnil)goto L625;
	goto L624;
L625:
	(*LK6)(2,(V2),VV[79])                     /*  X-TYPE-ERROR    */;
L624:
	L11(3,(V1),MAKE_FIXNUM(10),VALUES(0))     /*  CHANGE-WINDOW-ATTRIBUTE*/;
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for WINDOW-OVERRIDE-REDIRECT              */
static L36(int narg, object V1)
{ VT38 VLEX38 CLSR38
TTL:
	{object V2;                               /*  .WITH-ATTRIBUTES-REPLY-BUFFER.*/
	L13(1,(V1))                               /*  GET-WINDOW-ATTRIBUTES-BUFFER*/;
	V2= VALUES(0);
	{object V3;
	{object V4;                               /*  %REPLY-BUFFER   */
	{int V5;                                  /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= 0;
	V6= ((V2))->in.in_slots[1];
	{int V7;
	V7= ((V6))->ust.ust_self[(V5)+(27)];
	if((V7)<(2)){
	goto L636;}
	V3= Cnil;
	goto L630;
L636:
	V3= (VV[82])->v.v_self[V7];
	}
	}
	}
L630:
	if(((VV[3]->s.s_dbind))!=Cnil){
	goto L638;}
	L2(1,(V2))                                /*  DEALLOCATE-CONTEXT*/;
L638:
	VALUES(0) = (V3);
	RETURN(1);
	}
	}
}
/*	function definition for SET-WINDOW-OVERRIDE-REDIRECT          */
static L37(int narg, object V1, object V2)
{ VT39 VLEX39 CLSR39
TTL:
	{int V3;
	VALUES(0) = (VV[25]->s.s_gfdef);
	(*LK19)(4,(V2),VV[83],VV[24],VALUES(0))   /*  POSITION        */;
	V3= fix(VALUES(0));
	if(MAKE_FIXNUM(V3)==Cnil){
	VALUES(0) = Cnil;
	goto L644;}
	VALUES(0) = MAKE_FIXNUM(V3);
	}
L644:
	if(VALUES(0)==Cnil)goto L643;
	goto L642;
L643:
	(*LK6)(2,(V2),VV[84])                     /*  X-TYPE-ERROR    */;
L642:
	L11(3,(V1),MAKE_FIXNUM(9),VALUES(0))      /*  CHANGE-WINDOW-ATTRIBUTE*/;
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for WINDOW-EVENT-MASK                     */
static L38(int narg, object V1)
{ VT40 VLEX40 CLSR40
TTL:
	{object V2;                               /*  .WITH-ATTRIBUTES-REPLY-BUFFER.*/
	L13(1,(V1))                               /*  GET-WINDOW-ATTRIBUTES-BUFFER*/;
	V2= VALUES(0);
	{int V3;
	{object V4;                               /*  %REPLY-BUFFER   */
	{int V5;                                  /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= 0;
	V6= ((V2))->in.in_slots[1];
	V3= (*(unsigned long *)(((V6))->ust.ust_self+((V5)+(36))));
	}
	}
	if(((VV[3]->s.s_dbind))!=Cnil){
	goto L653;}
	L2(1,(V2))                                /*  DEALLOCATE-CONTEXT*/;
L653:
	VALUES(0) = MAKE_FIXNUM(V3);
	RETURN(1);
	}
	}
}
/*	function definition for WINDOW-DO-NOT-PROPAGATE-MASK          */
static L39(int narg, object V1)
{ VT41 VLEX41 CLSR41
TTL:
	{object V2;                               /*  .WITH-ATTRIBUTES-REPLY-BUFFER.*/
	L13(1,(V1))                               /*  GET-WINDOW-ATTRIBUTES-BUFFER*/;
	V2= VALUES(0);
	{int V3;
	{object V4;                               /*  %REPLY-BUFFER   */
	{int V5;                                  /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= 0;
	V6= ((V2))->in.in_slots[1];
	V3= (*(unsigned long *)(((V6))->ust.ust_self+((V5)+(40))));
	}
	}
	if(((VV[3]->s.s_dbind))!=Cnil){
	goto L662;}
	L2(1,(V2))                                /*  DEALLOCATE-CONTEXT*/;
L662:
	VALUES(0) = MAKE_FIXNUM(V3);
	RETURN(1);
	}
	}
}
/*	function definition for WINDOW-COLORMAP                       */
static L40(int narg, object V1)
{ VT42 VLEX42 CLSR42
TTL:
	{object V2;                               /*  .WITH-ATTRIBUTES-REPLY-BUFFER.*/
	L13(1,(V1))                               /*  GET-WINDOW-ATTRIBUTES-BUFFER*/;
	V2= VALUES(0);
	{object V3;
	{object V4;                               /*  %REPLY-BUFFER   */
	{int V5;                                  /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= 0;
	V6= ((V2))->in.in_slots[1];
	{int V7;                                  /*  ID              */
	V7= ((*(unsigned long *)(((V6))->ust.ust_self+((V5)+(28)))) & 0x1fffffff);
	if(!((V7)==0)){
	goto L673;}
	V3= Cnil;
	goto L666;
L673:
	(*LK20)(2,((V1))->in.in_slots[1],MAKE_FIXNUM(V7))/*  LOOKUP-COLORMAP*/;
	V3= VALUES(0);
	}
	}
	}
L666:
	if(((VV[3]->s.s_dbind))!=Cnil){
	goto L675;}
	L2(1,(V2))                                /*  DEALLOCATE-CONTEXT*/;
L675:
	VALUES(0) = (V3);
	RETURN(1);
	}
	}
}
/*	function definition for SET-WINDOW-COLORMAP                   */
static L41(int narg, object V1, object V2)
{ VT43 VLEX43 CLSR43
TTL:
	{object V3;
	if(((V2))==(VV[54])){
	goto L681;}
	V3= Cnil;
	goto L680;
L681:
	V3= MAKE_FIXNUM(0);
L680:
	if(((V3))==Cnil){
	goto L684;}
	VALUES(0) = (V3);
	goto L679;
L684:
	(*LK21)(1,(V2))                           /*  COLORMAP-P      */;
	if(VALUES(0)==Cnil){
	goto L687;}
	VALUES(0) = ((V2))->in.in_slots[0];
	goto L679;
L687:
	(*LK6)(2,(V2),VV[92])                     /*  X-TYPE-ERROR    */;
	}
L679:
	L11(3,(V1),MAKE_FIXNUM(13),VALUES(0))     /*  CHANGE-WINDOW-ATTRIBUTE*/;
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for WINDOW-CURSOR                         */
static L42(int narg, object V1)
{ VT44 VLEX44 CLSR44
TTL:
	RETURN(Lerror(2,VV[95],VV[96])            /*  ERROR           */);
}
/*	function definition for SET-WINDOW-CURSOR                     */
static L43(int narg, object V1, object V2)
{ VT45 VLEX45 CLSR45
TTL:
	{object V3;
	if(((V2))==(VV[44])){
	goto L693;}
	V3= Cnil;
	goto L692;
L693:
	V3= MAKE_FIXNUM(0);
L692:
	if(((V3))==Cnil){
	goto L696;}
	VALUES(0) = (V3);
	goto L691;
L696:
	(*LK22)(1,(V2))                           /*  CURSOR-P        */;
	if(VALUES(0)==Cnil){
	goto L699;}
	VALUES(0) = ((V2))->in.in_slots[0];
	goto L691;
L699:
	(*LK6)(2,(V2),VV[98])                     /*  X-TYPE-ERROR    */;
	}
L691:
	L11(3,(V1),MAKE_FIXNUM(14),VALUES(0))     /*  CHANGE-WINDOW-ATTRIBUTE*/;
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for WINDOW-COLORMAP-INSTALLED-P           */
static L44(int narg, object V1)
{ VT46 VLEX46 CLSR46
TTL:
	{object V2;                               /*  .WITH-ATTRIBUTES-REPLY-BUFFER.*/
	L13(1,(V1))                               /*  GET-WINDOW-ATTRIBUTES-BUFFER*/;
	V2= VALUES(0);
	{object V3;
	{object V4;                               /*  %REPLY-BUFFER   */
	{int V5;                                  /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= 0;
	V6= ((V2))->in.in_slots[1];
	V3= ((((V6))->ust.ust_self[(V5)+(25)])>0?Ct:Cnil);
	}
	}
	if(((VV[3]->s.s_dbind))!=Cnil){
	goto L707;}
	L2(1,(V2))                                /*  DEALLOCATE-CONTEXT*/;
L707:
	VALUES(0) = (V3);
	RETURN(1);
	}
	}
}
/*	function definition for WINDOW-ALL-EVENT-MASKS                */
static L45(int narg, object V1)
{ VT47 VLEX47 CLSR47
TTL:
	{object V2;                               /*  .WITH-ATTRIBUTES-REPLY-BUFFER.*/
	L13(1,(V1))                               /*  GET-WINDOW-ATTRIBUTES-BUFFER*/;
	V2= VALUES(0);
	{int V3;
	{object V4;                               /*  %REPLY-BUFFER   */
	{int V5;                                  /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= 0;
	V6= ((V2))->in.in_slots[1];
	V3= (*(unsigned long *)(((V6))->ust.ust_self+((V5)+(32))));
	}
	}
	if(((VV[3]->s.s_dbind))!=Cnil){
	goto L716;}
	L2(1,(V2))                                /*  DEALLOCATE-CONTEXT*/;
L716:
	VALUES(0) = MAKE_FIXNUM(V3);
	RETURN(1);
	}
	}
}
/*	function definition for WINDOW-MAP-STATE                      */
static L46(int narg, object V1)
{ VT48 VLEX48 CLSR48
TTL:
	{object V2;                               /*  .WITH-ATTRIBUTES-REPLY-BUFFER.*/
	L13(1,(V1))                               /*  GET-WINDOW-ATTRIBUTES-BUFFER*/;
	V2= VALUES(0);
	{object V3;
	{object V4;                               /*  %REPLY-BUFFER   */
	{int V5;                                  /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= 0;
	V6= ((V2))->in.in_slots[1];
	{int V7;
	V7= ((V6))->ust.ust_self[(V5)+(26)];
	if((V7)<(3)){
	goto L726;}
	V3= Cnil;
	goto L720;
L726:
	V3= (VV[100])->v.v_self[V7];
	}
	}
	}
L720:
	if(((VV[3]->s.s_dbind))!=Cnil){
	goto L728;}
	L2(1,(V2))                                /*  DEALLOCATE-CONTEXT*/;
L728:
	VALUES(0) = (V3);
	RETURN(1);
	}
	}
}
/*	function definition for DRAWABLE-ROOT                         */
static L47(int narg, object V1)
{ VT49 VLEX49 CLSR49
TTL:
	{object V2;                               /*  .WITH-GEOMETRY-REPLY-BUFFER.*/
	L14(1,(V1))                               /*  GET-DRAWABLE-GEOMETRY-BUFFER*/;
	V2= VALUES(0);
	{object V3;
	{object V4;                               /*  %REPLY-BUFFER   */
	{int V5;                                  /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= 0;
	V6= ((V2))->in.in_slots[1];
	T0= ((V1))->in.in_slots[1];
	(*LK23)(2,T0,MAKE_FIXNUM(((*(unsigned long *)(((V6))->ust.ust_self+((V5)+(8)))) & 0x1fffffff)))/*  LOOKUP-WINDOW*/;
	V3= VALUES(0);
	}
	}
	if(((VV[3]->s.s_dbind))!=Cnil){
	goto L738;}
	L2(1,(V2))                                /*  DEALLOCATE-CONTEXT*/;
L738:
	VALUES(0) = (V3);
	RETURN(1);
	}
	}
}
/*	function definition for DRAWABLE-X                            */
static L48(int narg, object V1)
{ VT50 VLEX50 CLSR50
TTL:
	{object V2;                               /*  .WITH-GEOMETRY-REPLY-BUFFER.*/
	L14(1,(V1))                               /*  GET-DRAWABLE-GEOMETRY-BUFFER*/;
	V2= VALUES(0);
	{int V3;
	{object V4;                               /*  %REPLY-BUFFER   */
	{int V5;                                  /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= 0;
	V6= ((V2))->in.in_slots[1];
	V3= (*(short *)(((V6))->st.st_self+((V5)+(12))));
	}
	}
	if(((VV[3]->s.s_dbind))!=Cnil){
	goto L747;}
	L2(1,(V2))                                /*  DEALLOCATE-CONTEXT*/;
L747:
	VALUES(0) = MAKE_FIXNUM(V3);
	RETURN(1);
	}
	}
}
/*	function definition for SET-DRAWABLE-X                        */
static L49(int narg, object V1, object V2)
{ VT51 VLEX51 CLSR51
TTL:
	(*LK7)(2,(V2),VV[101])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L753;}
	VALUES(0) = MAKE_FIXNUM(((unsigned short)(fix((V2)))));
	goto L751;
L753:
	(*LK6)(2,(V2),VV[101])                    /*  X-TYPE-ERROR    */;
L751:
	L12(3,(V1),MAKE_FIXNUM(0),VALUES(0))      /*  CHANGE-DRAWABLE-GEOMETRY*/;
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for DRAWABLE-Y                            */
static L50(int narg, object V1)
{ VT52 VLEX52 CLSR52
TTL:
	{object V2;                               /*  .WITH-GEOMETRY-REPLY-BUFFER.*/
	L14(1,(V1))                               /*  GET-DRAWABLE-GEOMETRY-BUFFER*/;
	V2= VALUES(0);
	{int V3;
	{object V4;                               /*  %REPLY-BUFFER   */
	{int V5;                                  /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= 0;
	V6= ((V2))->in.in_slots[1];
	V3= (*(short *)(((V6))->st.st_self+((V5)+(14))));
	}
	}
	if(((VV[3]->s.s_dbind))!=Cnil){
	goto L761;}
	L2(1,(V2))                                /*  DEALLOCATE-CONTEXT*/;
L761:
	VALUES(0) = MAKE_FIXNUM(V3);
	RETURN(1);
	}
	}
}
/*	function definition for SET-DRAWABLE-Y                        */
static L51(int narg, object V1, object V2)
{ VT53 VLEX53 CLSR53
TTL:
	(*LK7)(2,(V2),VV[101])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L767;}
	VALUES(0) = MAKE_FIXNUM(((unsigned short)(fix((V2)))));
	goto L765;
L767:
	(*LK6)(2,(V2),VV[101])                    /*  X-TYPE-ERROR    */;
L765:
	L12(3,(V1),MAKE_FIXNUM(1),VALUES(0))      /*  CHANGE-DRAWABLE-GEOMETRY*/;
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for DRAWABLE-WIDTH                        */
static L52(int narg, object V1)
{ VT54 VLEX54 CLSR54
TTL:
	{object V2;                               /*  .WITH-GEOMETRY-REPLY-BUFFER.*/
	L14(1,(V1))                               /*  GET-DRAWABLE-GEOMETRY-BUFFER*/;
	V2= VALUES(0);
	{int V3;
	{object V4;                               /*  %REPLY-BUFFER   */
	{int V5;                                  /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= 0;
	V6= ((V2))->in.in_slots[1];
	V3= (*(unsigned short *)(((V6))->ust.ust_self+((V5)+(16))));
	}
	}
	if(((VV[3]->s.s_dbind))!=Cnil){
	goto L775;}
	L2(1,(V2))                                /*  DEALLOCATE-CONTEXT*/;
L775:
	VALUES(0) = MAKE_FIXNUM(V3);
	RETURN(1);
	}
	}
}
/*	function definition for SET-DRAWABLE-WIDTH                    */
static L53(int narg, object V1, object V2)
{ VT55 VLEX55 CLSR55
TTL:
	(*LK7)(2,(V2),VV[30])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L781;}
	VALUES(0) = (V2);
	goto L779;
L781:
	(*LK6)(2,(V2),VV[30])                     /*  X-TYPE-ERROR    */;
L779:
	L12(3,(V1),MAKE_FIXNUM(2),VALUES(0))      /*  CHANGE-DRAWABLE-GEOMETRY*/;
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for DRAWABLE-HEIGHT                       */
static L54(int narg, object V1)
{ VT56 VLEX56 CLSR56
TTL:
	{object V2;                               /*  .WITH-GEOMETRY-REPLY-BUFFER.*/
	L14(1,(V1))                               /*  GET-DRAWABLE-GEOMETRY-BUFFER*/;
	V2= VALUES(0);
	{int V3;
	{object V4;                               /*  %REPLY-BUFFER   */
	{int V5;                                  /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= 0;
	V6= ((V2))->in.in_slots[1];
	V3= (*(unsigned short *)(((V6))->ust.ust_self+((V5)+(18))));
	}
	}
	if(((VV[3]->s.s_dbind))!=Cnil){
	goto L789;}
	L2(1,(V2))                                /*  DEALLOCATE-CONTEXT*/;
L789:
	VALUES(0) = MAKE_FIXNUM(V3);
	RETURN(1);
	}
	}
}
/*	function definition for SET-DRAWABLE-HEIGHT                   */
static L55(int narg, object V1, object V2)
{ VT57 VLEX57 CLSR57
TTL:
	(*LK7)(2,(V2),VV[30])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L795;}
	VALUES(0) = (V2);
	goto L793;
L795:
	(*LK6)(2,(V2),VV[30])                     /*  X-TYPE-ERROR    */;
L793:
	L12(3,(V1),MAKE_FIXNUM(3),VALUES(0))      /*  CHANGE-DRAWABLE-GEOMETRY*/;
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for DRAWABLE-DEPTH                        */
static L56(int narg, object V1)
{ VT58 VLEX58 CLSR58
TTL:
	{object V2;                               /*  .WITH-GEOMETRY-REPLY-BUFFER.*/
	L14(1,(V1))                               /*  GET-DRAWABLE-GEOMETRY-BUFFER*/;
	V2= VALUES(0);
	{int V3;
	{object V4;                               /*  %REPLY-BUFFER   */
	{int V5;                                  /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= 0;
	V6= ((V2))->in.in_slots[1];
	V3= ((V6))->ust.ust_self[(V5)+(1)];
	}
	}
	if(((VV[3]->s.s_dbind))!=Cnil){
	goto L803;}
	L2(1,(V2))                                /*  DEALLOCATE-CONTEXT*/;
L803:
	VALUES(0) = MAKE_FIXNUM(V3);
	RETURN(1);
	}
	}
}
/*	function definition for DRAWABLE-BORDER-WIDTH                 */
static L57(int narg, object V1)
{ VT59 VLEX59 CLSR59
TTL:
	{object V2;                               /*  .WITH-GEOMETRY-REPLY-BUFFER.*/
	L14(1,(V1))                               /*  GET-DRAWABLE-GEOMETRY-BUFFER*/;
	V2= VALUES(0);
	{int V3;
	{object V4;                               /*  %REPLY-BUFFER   */
	{int V5;                                  /*  BUFFER-BOFFSET  */
	object V6;                                /*  BUFFER-BBUF     */
	V5= 0;
	V6= ((V2))->in.in_slots[1];
	V3= (*(unsigned short *)(((V6))->ust.ust_self+((V5)+(20))));
	}
	}
	if(((VV[3]->s.s_dbind))!=Cnil){
	goto L812;}
	L2(1,(V2))                                /*  DEALLOCATE-CONTEXT*/;
L812:
	VALUES(0) = MAKE_FIXNUM(V3);
	RETURN(1);
	}
	}
}
/*	function definition for SET-DRAWABLE-BORDER-WIDTH             */
static L58(int narg, object V1, object V2)
{ VT60 VLEX60 CLSR60
TTL:
	(*LK7)(2,(V2),VV[30])                     /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L818;}
	VALUES(0) = (V2);
	goto L816;
L818:
	(*LK6)(2,(V2),VV[30])                     /*  X-TYPE-ERROR    */;
L816:
	L12(3,(V1),MAKE_FIXNUM(4),VALUES(0))      /*  CHANGE-DRAWABLE-GEOMETRY*/;
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for SET-WINDOW-PRIORITY                   */
static L59(int narg, object V1, object V2, object V3)
{ VT61 VLEX61 CLSR61
	bds_check;
TTL:
	{object V4;
	V4= list(5,(V2),Cnil,Cnil,Cnil,Cnil);
	{object V5;
	V5= CONS((V4),(VV[3]->s.s_dbind));
	bds_bind(VV[3],V5);                       /*  *WINDOW-ATTRIBUTES**/
	{int V6;
	VALUES(0) = (VV[25]->s.s_gfdef);
	(*LK19)(4,(V1),VV[112],VV[24],VALUES(0))  /*  POSITION        */;
	V6= fix(VALUES(0));
	if(MAKE_FIXNUM(V6)==Cnil){
	VALUES(0) = Cnil;
	goto L827;}
	VALUES(0) = MAKE_FIXNUM(V6);
	}
L827:
	if(VALUES(0)==Cnil)goto L826;
	goto L825;
L826:
	(*LK6)(2,(V1),VV[113])                    /*  X-TYPE-ERROR    */;
L825:
	L12(3,(V2),MAKE_FIXNUM(6),VALUES(0))      /*  CHANGE-DRAWABLE-GEOMETRY*/;
	if(((V3))==Cnil){
	goto L823;}
	(*LK5)(1,(V3))                            /*  WINDOW-P        */;
	if(VALUES(0)==Cnil){
	goto L834;}
	VALUES(0) = ((V3))->in.in_slots[0];
	goto L832;
L834:
	(*LK6)(2,(V3),VV[14])                     /*  X-TYPE-ERROR    */;
L832:
	L12(3,(V2),MAKE_FIXNUM(5),VALUES(0))      /*  CHANGE-DRAWABLE-GEOMETRY*/;
L823:
	L10(1,(V4))                               /*  CLEANUP-STATE-ENTRY*/;
	bds_unwind1;
	}
	}
	VALUES(0) = (V1);
	RETURN(1);
}
static LKF23(int narg, ...) {TRAMPOLINK(VV[201],&LK23);}
static LKF22(int narg, ...) {TRAMPOLINK(VV[196],&LK22);}
static LKF21(int narg, ...) {TRAMPOLINK(VV[193],&LK21);}
static LKF20(int narg, ...) {TRAMPOLINK(VV[191],&LK20);}
static LKF19(int narg, ...) {TRAMPOLINK(VV[175],&LK19);}
static LKF18(int narg, ...) {TRAMPOLINK(VV[171],&LK18);}
static LKF17(int narg, ...) {TRAMPOLINK(VV[168],&LK17);}
static LKF16(int narg, ...) {TRAMPOLINK(VV[162],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[161],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[160],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[159],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[158],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[157],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[155],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[153],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[152],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[151],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[150],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[149],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[148],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[147],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[146],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[144],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[141],&LK0);}
