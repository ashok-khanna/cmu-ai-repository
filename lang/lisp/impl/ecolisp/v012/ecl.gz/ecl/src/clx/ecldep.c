
#include "ecldep.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	putprop(VV[0],VV[2],VV[1]);
	VV[67] = make_cfun(LC1,Cnil,&Cblock);
	VALUES(0) = VV[67];
	putprop(VV[0],VALUES(0),VV[3]);
	putprop(VV[0],Cnil,VV[5]);
	MF0(VV[68],L2);
	MF0(VV[7],L3);
	funcall(2,VV[69]->s.s_gfdef,VV[6])        /*  PROCLAIM        */;
	putprop(VV[7],VV[9],VV[8]);
	MF0(VV[11],L4);
	funcall(2,VV[69]->s.s_gfdef,VV[10])       /*  PROCLAIM        */;
	putprop(VV[11],VV[12],VV[8]);
	MF0(VV[14],L5);
	funcall(2,VV[69]->s.s_gfdef,VV[13])       /*  PROCLAIM        */;
	putprop(VV[14],VV[15],VV[8]);
	MF0(VV[17],L6);
	funcall(2,VV[69]->s.s_gfdef,VV[16])       /*  PROCLAIM        */;
	putprop(VV[17],VV[18],VV[8]);
	MF0(VV[20],L7);
	funcall(2,VV[69]->s.s_gfdef,VV[19])       /*  PROCLAIM        */;
	putprop(VV[20],VV[21],VV[8]);
	MF0(VV[23],L8);
	funcall(2,VV[69]->s.s_gfdef,VV[22])       /*  PROCLAIM        */;
	putprop(VV[23],VV[24],VV[8]);
	MF0(VV[26],L9);
	funcall(2,VV[69]->s.s_gfdef,VV[25])       /*  PROCLAIM        */;
	putprop(VV[26],VV[27],VV[8]);
	MF0(VV[29],L10);
	funcall(2,VV[69]->s.s_gfdef,VV[28])       /*  PROCLAIM        */;
	putprop(VV[29],VV[30],VV[8]);
	MF0(VV[32],L11);
	funcall(2,VV[69]->s.s_gfdef,VV[31])       /*  PROCLAIM        */;
	putprop(VV[32],VV[33],VV[8]);
	MF0(VV[35],L12);
	funcall(2,VV[69]->s.s_gfdef,VV[34])       /*  PROCLAIM        */;
	putprop(VV[35],VV[36],VV[8]);
	MF0(VV[38],L13);
	funcall(2,VV[69]->s.s_gfdef,VV[37])       /*  PROCLAIM        */;
	putprop(VV[38],VV[39],VV[8]);
	MF0(VV[41],L14);
	funcall(2,VV[69]->s.s_gfdef,VV[40])       /*  PROCLAIM        */;
	putprop(VV[41],VV[42],VV[8]);
	MF0(VV[44],L15);
	funcall(2,VV[69]->s.s_gfdef,VV[43])       /*  PROCLAIM        */;
	putprop(VV[44],VV[45],VV[8]);
	MF0(VV[47],L16);
	funcall(2,VV[69]->s.s_gfdef,VV[46])       /*  PROCLAIM        */;
	putprop(VV[47],VV[48],VV[8]);
	MF0(VV[50],L17);
	funcall(2,VV[69]->s.s_gfdef,VV[49])       /*  PROCLAIM        */;
	putprop(VV[50],VV[51],VV[8]);
	MF0(VV[53],L18);
	funcall(2,VV[69]->s.s_gfdef,VV[52])       /*  PROCLAIM        */;
	putprop(VV[53],VV[54],VV[8]);
	MF0(VV[56],L19);
	funcall(2,VV[69]->s.s_gfdef,VV[55])       /*  PROCLAIM        */;
	putprop(VV[56],VV[57],VV[8]);
	MF0(VV[59],L20);
	funcall(2,VV[69]->s.s_gfdef,VV[58])       /*  PROCLAIM        */;
	putprop(VV[59],VV[60],VV[8]);
	MF0(VV[62],L21);
	funcall(2,VV[69]->s.s_gfdef,VV[61])       /*  PROCLAIM        */;
	putprop(VV[62],VV[63],VV[8]);
	MF0(VV[65],L22);
	funcall(2,VV[69]->s.s_gfdef,VV[64])       /*  PROCLAIM        */;
	putprop(VV[65],VV[66],VV[8]);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	local function CLOSURE                                        */
static LC1(int narg)
{ VT3 VLEX3 CLSR3
	VALUES(0) = VV[4];
	RETURN(1);
}
/*	function definition for LITTLE-ENDIAN-P                       */
static L2(int narg)
{
	object x;
	x=Cnil;
    { int whichbyte = 1;
      if (*(char *) &whichbyte) x=Ct;};
	VALUES(0)=x;
	RETURN(1);
}
/*	function definition for CARD8->INT8                           */
static L3(int narg, object V1)
{
	int x;
	x=(object_to_int(V1)) & 0x80 ? ((object_to_int(V1))-0x100) : (object_to_int(V1));
	VALUES(0)=MAKE_FIXNUM(x);
	RETURN(1);
}
/*	function definition for INT8->CARD8                           */
static L4(int narg, object V1)
{
	int x;
	x=(object_to_int(V1));
	VALUES(0)=MAKE_FIXNUM(x);
	RETURN(1);
}
/*	function definition for CARD16->INT16                         */
static L5(int narg, object V1)
{
	int x;
	x=((short)(object_to_int(V1)));
	VALUES(0)=MAKE_FIXNUM(x);
	RETURN(1);
}
/*	function definition for INT16->CARD16                         */
static L6(int narg, object V1)
{
	int x;
	x=((unsigned short)(object_to_int(V1)));
	VALUES(0)=MAKE_FIXNUM(x);
	RETURN(1);
}
/*	function definition for CARD32->INT32                         */
static L7(int narg, object V1)
{
	int x;
	x=(object_to_int(V1));
	VALUES(0)=MAKE_FIXNUM(x);
	RETURN(1);
}
/*	function definition for INT32->CARD32                         */
static L8(int narg, object V1)
{
	int x;
	x=(object_to_int(V1));
	VALUES(0)=MAKE_FIXNUM(x);
	RETURN(1);
}
/*	function definition for AREF-CARD8                            */
static L9(int narg, object V1, object V2)
{
	int x;
	x=(V1)->ust.ust_self[object_to_int(V2)];
	VALUES(0)=MAKE_FIXNUM(x);
	RETURN(1);
}
/*	function definition for ASET-CARD8                            */
static L10(int narg, object V1, object V2, object V3)
{
	int x;
	x=((V2)->ust.ust_self[object_to_int(V3)]=(object_to_int(V1)));
	VALUES(0)=MAKE_FIXNUM(x);
	RETURN(1);
}
/*	function definition for AREF-INT8                             */
static L11(int narg, object V1, object V2)
{
	int x;
	x=(V1)->st.st_self[object_to_int(V2)];
	VALUES(0)=MAKE_FIXNUM(x);
	RETURN(1);
}
/*	function definition for ASET-INT8                             */
static L12(int narg, object V1, object V2, object V3)
{
	int x;
	x=((V2)->st.st_self[object_to_int(V3)]=(object_to_int(V1)));
	VALUES(0)=MAKE_FIXNUM(x);
	RETURN(1);
}
/*	function definition for AREF-CARD16                           */
static L13(int narg, object V1, object V2)
{
	int x;
	x=(*(unsigned short *)((V1)->ust.ust_self+(object_to_int(V2))));
	VALUES(0)=MAKE_FIXNUM(x);
	RETURN(1);
}
/*	function definition for ASET-CARD16                           */
static L14(int narg, object V1, object V2, object V3)
{
	int x;
	x=((*(unsigned short *)((V2)->ust.ust_self+(object_to_int(V3))))=object_to_int(V1));
	VALUES(0)=MAKE_FIXNUM(x);
	RETURN(1);
}
/*	function definition for AREF-INT16                            */
static L15(int narg, object V1, object V2)
{
	int x;
	x=(*(short *)((V1)->st.st_self+(object_to_int(V2))));
	VALUES(0)=MAKE_FIXNUM(x);
	RETURN(1);
}
/*	function definition for ASET-INT16                            */
static L16(int narg, object V1, object V2, object V3)
{
	int x;
	x=((*(short *)((V2)->st.st_self+(object_to_int(V3))))=object_to_int(V1));
	VALUES(0)=MAKE_FIXNUM(x);
	RETURN(1);
}
/*	function definition for AREF-CARD32                           */
static L17(int narg, object V1, object V2)
{
	int x;
	x=(*(unsigned long *)((V1)->ust.ust_self+(object_to_int(V2))));
	VALUES(0)=MAKE_FIXNUM(x);
	RETURN(1);
}
/*	function definition for ASET-CARD32                           */
static L18(int narg, object V1, object V2, object V3)
{
	int x;
	x=((*(unsigned long *)((V2)->ust.ust_self+(object_to_int(V3))))=object_to_int(V1));
	VALUES(0)=MAKE_FIXNUM(x);
	RETURN(1);
}
/*	function definition for AREF-INT32                            */
static L19(int narg, object V1, object V2)
{
	int x;
	x=(*(long *)((V1)->ust.ust_self+(object_to_int(V2))));
	VALUES(0)=MAKE_FIXNUM(x);
	RETURN(1);
}
/*	function definition for ASET-INT32                            */
static L20(int narg, object V1, object V2, object V3)
{
	int x;
	x=((*(long *)((V2)->ust.ust_self+(object_to_int(V3))))=object_to_int(V1));
	VALUES(0)=MAKE_FIXNUM(x);
	RETURN(1);
}
/*	function definition for AREF-CARD29                           */
static L21(int narg, object V1, object V2)
{
	int x;
	x=((*(unsigned long *)((V1)->ust.ust_self+(object_to_int(V2)))) & 0x1fffffff);
	VALUES(0)=MAKE_FIXNUM(x);
	RETURN(1);
}
/*	function definition for ASET-CARD29                           */
static L22(int narg, object V1, object V2, object V3)
{
	int x;
	x=((*(unsigned long *)((V2)->ust.ust_self+(object_to_int(V3))))=object_to_int(V1));
	VALUES(0)=MAKE_FIXNUM(x);
	RETURN(1);
}
