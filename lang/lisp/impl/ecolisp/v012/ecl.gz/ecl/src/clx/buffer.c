
#include "buffer.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	siLAmake_constant(2,VV[0],MAKE_FIXNUM(160))/*  *MAKE-CONSTANT */;
	(void)putprop(VV[85],VV[22],siSpretty_print_format);
	
	MM0(VV[85],L1);
	MF0(VV[6],L2);
	(void)putprop(VV[6],VV[Vdeb6],VV[86]);
	MM0(VV[87],L3);
	MM0(VV[88],L4);
	MM0(VV[89],L5);
	MM0(VV[90],L6);
	MM0(VV[91],L7);
	MM0(VV[92],L8);
	MM0(VV[93],L9);
	MM0(VV[94],L10);
	(void)putprop(VV[95],VV[22],siSpretty_print_format);
	
	MM0(VV[95],L11);
	(void)putprop(VV[35],VV[22],siSpretty_print_format);
	
	MM0(VV[35],L12);
	MF0(VV[96],L13);
	(void)putprop(VV[96],VV[Vdeb96],VV[86]);
	MF0(VV[97],L14);
	(void)putprop(VV[97],VV[Vdeb97],VV[86]);
	MF0(VV[98],L15);
	(void)putprop(VV[98],VV[Vdeb98],VV[86]);
	MF0(VV[99],L16);
	(void)putprop(VV[99],VV[Vdeb99],VV[86]);
	funcall(2,VV[100]->s.s_gfdef,VV[57])      /*  PROCLAIM        */;
	MF0(VV[101],L17);
	(void)putprop(VV[101],VV[Vdeb101],VV[86]);
	MF0(VV[102],L18);
	(void)putprop(VV[102],VV[Vdeb102],VV[86]);
	MF0(VV[103],L19);
	(void)putprop(VV[103],VV[Vdeb103],VV[86]);
	funcall(2,VV[104]->s.s_gfdef,VV[58])      /*  FIND-CLASS      */;
	funcall(9,VV[105]->s.s_gfdef,VALUES(0),VV[59],VV[60],VV[61],Cnil,VV[62],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[104]->s.s_gfdef,VV[59])      /*  FIND-CLASS      */;
	funcall(13,VV[106]->s.s_gfdef,VV[59],VV[63],Cnil,Cnil,VV[64],VV[65],Cnil,Cnil,Cnil,VV[66],MAKE_FIXNUM(4),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[107],L20,4,L20keys);
	(void)putprop(VV[107],VV[Vdeb107],VV[86]);
	MF0(VV[108],L21);
	(void)putprop(VV[108],VV[Vdeb108],VV[86]);
	MF0(VV[109],L22);
	(void)putprop(VV[109],VV[Vdeb109],VV[86]);
	MF0(VV[110],L23);
	(void)putprop(VV[110],VV[Vdeb110],VV[86]);
	(void)putprop(VV[111],VV[22],siSpretty_print_format);
	
	MM0(VV[111],L24);
	MF0(VV[112],L25);
	(void)putprop(VV[112],VV[Vdeb112],VV[86]);
	MF0key(VV[113],L26,1,L26keys);
	(void)putprop(VV[113],VV[Vdeb113],VV[86]);
	MF0(VV[114],L27);
	(void)putprop(VV[114],VV[Vdeb114],VV[86]);
	MF0(VV[115],L28);
	(void)putprop(VV[115],VV[Vdeb115],VV[86]);
	MF0(VV[116],L29);
	(void)putprop(VV[116],VV[Vdeb116],VV[86]);
	MF0(VV[117],L30);
	(void)putprop(VV[117],VV[Vdeb117],VV[86]);
	MF0(VV[118],L31);
	(void)putprop(VV[118],VV[Vdeb118],VV[86]);
	MF0(VV[119],L33);
	(void)putprop(VV[119],VV[Vdeb119],VV[86]);
	MF0(VV[120],L34);
	(void)putprop(VV[120],VV[Vdeb120],VV[86]);
	MF0(VV[121],L35);
	(void)putprop(VV[121],VV[Vdeb121],VV[86]);
	MF0(VV[122],L36);
	(void)putprop(VV[122],VV[Vdeb122],VV[86]);
	MF0(VV[123],L37);
	(void)putprop(VV[123],VV[Vdeb123],VV[86]);
	MF0(VV[124],L38);
	(void)putprop(VV[124],VV[Vdeb124],VV[86]);
	MF0(VV[125],L39);
	(void)putprop(VV[125],VV[Vdeb125],VV[86]);
	MF0(VV[126],L40);
	(void)putprop(VV[126],VV[Vdeb126],VV[86]);
	MF0(VV[127],L42);
	(void)putprop(VV[127],VV[Vdeb127],VV[86]);
	MF0(VV[128],L43);
	(void)putprop(VV[128],VV[Vdeb128],VV[86]);
	MF0(VV[129],L44);
	(void)putprop(VV[129],VV[Vdeb129],VV[86]);
	MF0(VV[130],L45);
	(void)putprop(VV[130],VV[Vdeb130],VV[86]);
	MF0(VV[131],L46);
	(void)putprop(VV[131],VV[Vdeb131],VV[86]);
	MF0(VV[132],L47);
	(void)putprop(VV[132],VV[Vdeb132],VV[86]);
	MF0(VV[133],L48);
	(void)putprop(VV[133],VV[Vdeb133],VV[86]);
	MF0(VV[134],L49);
	(void)putprop(VV[134],VV[Vdeb134],VV[86]);
	MF0(VV[135],L51);
	(void)putprop(VV[135],VV[Vdeb135],VV[86]);
	MF0(VV[136],L52);
	(void)putprop(VV[136],VV[Vdeb136],VV[86]);
	MF0(VV[137],L53);
	(void)putprop(VV[137],VV[Vdeb137],VV[86]);
	MF0(VV[138],L54);
	(void)putprop(VV[138],VV[Vdeb138],VV[86]);
	MF0(VV[139],L55);
	(void)putprop(VV[139],VV[Vdeb139],VV[86]);
	MF0(VV[140],L56);
	(void)putprop(VV[140],VV[Vdeb140],VV[86]);
	MF0(VV[141],L57);
	(void)putprop(VV[141],VV[Vdeb141],VV[86]);
	MF0(VV[142],L58);
	(void)putprop(VV[142],VV[Vdeb142],VV[86]);
	MF0(VV[143],L60);
	(void)putprop(VV[143],VV[Vdeb143],VV[86]);
	MF0(VV[144],L62);
	(void)putprop(VV[144],VV[Vdeb144],VV[86]);
	MF0(VV[145],L63);
	(void)putprop(VV[145],VV[Vdeb145],VV[86]);
	MF0(VV[146],L64);
	(void)putprop(VV[146],VV[Vdeb146],VV[86]);
	MF0(VV[147],L65);
	(void)putprop(VV[147],VV[Vdeb147],VV[86]);
	MF0(VV[148],L66);
	(void)putprop(VV[148],VV[Vdeb148],VV[86]);
	MF0(VV[149],L67);
	(void)putprop(VV[149],VV[Vdeb149],VV[86]);
	MF0(VV[150],L68);
	(void)putprop(VV[150],VV[Vdeb150],VV[86]);
	MF0(VV[151],L69);
	(void)putprop(VV[151],VV[Vdeb151],VV[86]);
	MF0(VV[152],L71);
	(void)putprop(VV[152],VV[Vdeb152],VV[86]);
	MF0(VV[153],L72);
	(void)putprop(VV[153],VV[Vdeb153],VV[86]);
	MF0(VV[154],L73);
	(void)putprop(VV[154],VV[Vdeb154],VV[86]);
	MF0(VV[155],L74);
	(void)putprop(VV[155],VV[Vdeb155],VV[86]);
	MF0(VV[156],L75);
	(void)putprop(VV[156],VV[Vdeb156],VV[86]);
	MF0(VV[157],L76);
	(void)putprop(VV[157],VV[Vdeb157],VV[86]);
	MF0(VV[158],L77);
	(void)putprop(VV[158],VV[Vdeb158],VV[86]);
	MF0(VV[159],L78);
	(void)putprop(VV[159],VV[Vdeb159],VV[86]);
	MF0(VV[160],L79);
	(void)putprop(VV[160],VV[Vdeb160],VV[86]);
	MF0(VV[161],L80);
	(void)putprop(VV[161],VV[Vdeb161],VV[86]);
	MF0(VV[162],L81);
	(void)putprop(VV[162],VV[Vdeb162],VV[86]);
	MF0(VV[163],L82);
	(void)putprop(VV[163],VV[Vdeb163],VV[86]);
	MF0(VV[164],L83);
	(void)putprop(VV[164],VV[Vdeb164],VV[86]);
	MF0(VV[165],L84);
	(void)putprop(VV[165],VV[Vdeb165],VV[86]);
	MF0(VV[166],L85);
	(void)putprop(VV[166],VV[Vdeb166],VV[86]);
	MF0(VV[167],L86);
	(void)putprop(VV[167],VV[Vdeb167],VV[86]);
	MF0(VV[168],L87);
	(void)putprop(VV[168],VV[Vdeb168],VV[86]);
	MF0(VV[169],L88);
	(void)putprop(VV[169],VV[Vdeb169],VV[86]);
	MF0(VV[170],L89);
	(void)putprop(VV[170],VV[Vdeb170],VV[86]);
	MF0(VV[171],L90);
	(void)putprop(VV[171],VV[Vdeb171],VV[86]);
	MF0(VV[172],L91);
	(void)putprop(VV[172],VV[Vdeb172],VV[86]);
	MF0(VV[173],L92);
	(void)putprop(VV[173],VV[Vdeb173],VV[86]);
	MF0(VV[174],L94);
	(void)putprop(VV[174],VV[Vdeb174],VV[86]);
	MF0(VV[175],L95);
	(void)putprop(VV[175],VV[Vdeb175],VV[86]);
	MF0(VV[176],L96);
	(void)putprop(VV[176],VV[Vdeb176],VV[86]);
	MF0(VV[177],L97);
	(void)putprop(VV[177],VV[Vdeb177],VV[86]);
	MF0(VV[178],L98);
	(void)putprop(VV[178],VV[Vdeb178],VV[86]);
	MF0(VV[179],L99);
	(void)putprop(VV[179],VV[Vdeb179],VV[86]);
	MF0(VV[180],L100);
	(void)putprop(VV[180],VV[Vdeb180],VV[86]);
	MF0(VV[181],L101);
	(void)putprop(VV[181],VV[Vdeb181],VV[86]);
	MF0(VV[182],L102);
	(void)putprop(VV[182],VV[Vdeb182],VV[86]);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	macro definition for WITH-BUFFER                              */
static L1(int narg, object V1, object V2)
{ VT3 VLEX3 CLSR3
	{object V3=CDR(V1),V4,V5,V6,V7;
	{object V8= CAR(V3);
	V4= CAR(V8);
	V8=CDR(V8);
	{object V9;
	V9=getf(V8,VV[21],OBJNULL);
	if(V9==OBJNULL){
	V5= Cnil;
	} else {
	V5= V9;}
	V9=getf(V8,VV[183],OBJNULL);
	if(V9==OBJNULL){
	V6= Cnil;
	} else {
	V6= V9;}}}
	V3=CDR(V3);
	V7= V3;
	if(((V6))!=Cnil){
	goto L13;}
	Lmacroexpand(2,VV[3],(V2))                /*  MACROEXPAND     */;
	if(VALUES(0)==Cnil){
	goto L13;}
	{object V10= CONS(listA(3,VV[5],Cnil,(V7)),Cnil);
	VALUES(0) = list(3,VV[4],(V10),list(4,VV[6],(V4),(V5),VV[7]));
	goto L11;}
L13:
	{register object V11;                     /*  BUF             */
	if(type_of((V4))==t_symbol){
	goto L18;}
	Lconstantp(1,(V4))                        /*  CONSTANTP       */;
	if(VALUES(0)==Cnil){
	goto L19;}
L18:
	V11= (V4);
	goto L17;
L19:
	V11= VV[8];
L17:
	if(((V11))==((V4))){
	goto L25;}
	T0= CONS(list(2,(V11),(V4)),Cnil);
	goto L23;
L25:
	T0= Cnil;
L23:
	if(((V11))==((V4))){
	goto L29;}
	T1= CONS(list(2,VV[10],list(3,VV[11],VV[12],(V11))),Cnil);
	goto L27;
L29:
	T1= Cnil;
L27:
	(*LK0)(0)                                 /*  DECLARE-BUFMAC  */;
	T2= VALUES(0);
	{object V12= list(2,VV[14],(V11));
	{object V13= list(3,VV[13],(V12),list(4,VV[15],VV[16],VV[17],(V11)));
	{object V14= list(2,VV[19],(V11));
	if((V5)==Cnil){
	VALUES(0) = Cnil;
	goto L32;}
	VALUES(0) = list(2,VV[21],(V5));
L32:
	VALUES(0) = listA(3,VV[9],T0,append(T1,list(3,T2,(V13),listA(3,VV[18],listA(4,(V14),(V11),VV[20],VALUES(0)),(V7)))));}}}
	}
L11:
	VALUES(0) = list(3,VV[1],VV[2],VALUES(0));
	RETURN(1);}
}
/*	function definition for WITH-BUFFER-FUNCTION                  */
static L2(int narg, object V1, object V2, object V3)
{ VT4 VLEX4 CLSR4
TTL:
	if((((V1))->in.in_slots[10])==Cnil){
	goto L33;}
	(*LK1)(3,VV[23],VV[17],(V1))              /*  X-ERROR         */;
L33:
	RETURN(funcall(1,(V3)));
}
/*	macro definition for READ-CARD8                               */
static L3(int narg, object V1, object V2)
{ VT5 VLEX5 CLSR5
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(3,VV[24],VV[25],list(3,VV[26],VV[27],(V4)));
	RETURN(1);}
}
/*	macro definition for READ-INT8                                */
static L4(int narg, object V1, object V2)
{ VT6 VLEX6 CLSR6
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(3,VV[28],VV[25],list(3,VV[26],VV[27],(V4)));
	RETURN(1);}
}
/*	macro definition for READ-CARD16                              */
static L5(int narg, object V1, object V2)
{ VT7 VLEX7 CLSR7
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(3,VV[29],VV[25],list(3,VV[26],VV[27],(V4)));
	RETURN(1);}
}
/*	macro definition for READ-INT16                               */
static L6(int narg, object V1, object V2)
{ VT8 VLEX8 CLSR8
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(3,VV[30],VV[25],list(3,VV[26],VV[27],(V4)));
	RETURN(1);}
}
/*	macro definition for READ-CARD32                              */
static L7(int narg, object V1, object V2)
{ VT9 VLEX9 CLSR9
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(3,VV[31],VV[25],list(3,VV[26],VV[27],(V4)));
	RETURN(1);}
}
/*	macro definition for READ-INT32                               */
static L8(int narg, object V1, object V2)
{ VT10 VLEX10 CLSR10
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(3,VV[32],VV[25],list(3,VV[26],VV[27],(V4)));
	RETURN(1);}
}
/*	macro definition for READ-CARD29                              */
static L9(int narg, object V1, object V2)
{ VT11 VLEX11 CLSR11
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(3,VV[33],VV[25],list(3,VV[26],VV[27],(V4)));
	RETURN(1);}
}
/*	macro definition for EVENT-CODE                               */
static L10(int narg, object V1, object V2)
{ VT12 VLEX12 CLSR12
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(2,VV[34],(V4));
	RETURN(1);}
}
/*	macro definition for READING-EVENT                            */
static L11(int narg, object V1, object V2)
{ VT13 VLEX13 CLSR13
	{object V3=CDR(V1),V4,V5,V6;
	{object V7= CAR(V3);
	V4= CAR(V7);
	V7=CDR(V7);
	V5= V7;}
	V3=CDR(V3);
	V6= V3;
	VALUES(0) = listA(3,VV[35],CONS((V4),(V5)),(V6));
	RETURN(1);}
}
/*	macro definition for WITH-BUFFER-INPUT                        */
static L12(int narg, object V1, object V2)
{ VT14 VLEX14 CLSR14
	{object V3=CDR(V1),V4,V5,V6,V7,V8;
	{object V9= CAR(V3);
	V4= CAR(V9);
	V9=CDR(V9);
	{object V10;
	V10=getf(V9,VV[17],OBJNULL);
	if(V10==OBJNULL){
	V5= Cnil;
	} else {
	V5= V10;}
	V10=getf(V9,VV[186],OBJNULL);
	if(V10==OBJNULL){
	V6= VV[36];
	} else {
	V6= V10;}
	V10=getf(V9,VV[187],OBJNULL);
	if(V10==OBJNULL){
	V7= Cnil;
	} else {
	V7= V10;}}}
	V3=CDR(V3);
	V8= V3;
	if(type_of((V6))==t_cons||(V6)==Cnil){
	goto L39;}
	V6= CONS((V6),Cnil);
L39:
	(*LK2)(2,(V6),VV[37])                     /*  SET-DIFFERENCE  */;
	if(VALUES(0)==Cnil){
	goto L43;}
	Lerror(2,VV[38],(V6))                     /*  ERROR           */;
L43:
	{object V11= list(2,VV[39],(V4));
	if((V5)==Cnil){
	VALUES(0) = Cnil;
	goto L46;}
	VALUES(0) = CONS(list(2,VV[40],(V5)),Cnil);
L46:
	{object V12= CONS((V11),VALUES(0));
	if((V5)==Cnil){
	VALUES(0) = Cnil;
	goto L47;}
	VALUES(0) = VV[42];
L47:
	{object V13= listA(3,VV[10],VV[41],VALUES(0));
	(*LK0)(0)                                 /*  DECLARE-BUFMAC  */;
	T0= VALUES(0);
	if((V5)==Cnil){
	T1= Cnil;
	goto L49;}
	T1= VV[43];
L49:
	if((V7)!=Cnil){
	VALUES(0) = (V7);
	goto L50;}
	VALUES(0) = MAKE_FIXNUM(0);
L50:
	VALUES(0) = listA(5,VV[9],(V12),(V13),T0,append(T1,CONS(listA(7,VV[44],list(2,list(2,VV[27],list(3,VV[45],VV[46],VALUES(0))),VV[47]),VV[48],VV[49],VV[27],VV[25],(V8)),Cnil)));
	RETURN(1);}}}}
}
/*	function definition for MAKE-BUFFER                           */
static L13(int narg, object V1, object V2, ...)
{ VT15 VLEX15 CLSR15
	{object V3;
	va_list args; va_start(args, V2);
	narg -=2;
	V3=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object p=V3;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	{object V4;                               /*  BYTE-OUTPUT     */
	(*LK3)(5,(V1),VV[50],VV[51],VV[52],code_char('\0'))/*  MAKE-ARRAY*/;
	V4= VALUES(0);
	RETURN(Lapply(6,(V2),VV[53],(V1),VV[54],(V4),(V3))/*  APPLY   */);
	}
	}
}
/*	function definition for MAKE-REPLY-BUFFER                     */
static L14(int narg, object V1)
{ VT16 VLEX16 CLSR16
TTL:
	{object V2;                               /*  BYTE-INPUT      */
	(*LK3)(5,(V1),VV[50],VV[51],VV[52],code_char('\0'))/*  MAKE-ARRAY*/;
	V2= VALUES(0);
	RETURN((*LK4)(4,VV[53],(V1),VV[55],(V2))  /*  MAKE-REPLY-BUFFER-INTERNAL*/);
	}
}
/*	function definition for BUFFER-ENSURE-SIZE                    */
static L15(int narg, object V1, object V2)
{ VT17 VLEX17 CLSR17
	{int V3;
	V3= fix(V2);
TTL:
	if(!((V3)>(fix(((V1))->in.in_slots[2])))){
	goto L54;}
	if((((V1))->in.in_slots[10])==Cnil){
	goto L56;}
	(*LK1)(3,VV[23],VV[17],(V1))              /*  X-ERROR         */;
L56:
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	{object V4;                               /*  NEW-BUFFER-SIZE */
	object V5;                                /*  NEW-BUFFER      */
	Linteger_length(1,MAKE_FIXNUM((V3)-1))    /*  INTEGER-LENGTH  */;
	Lash(2,MAKE_FIXNUM(1),VALUES(0))          /*  ASH             */;
	V4= VALUES(0);
	(*LK3)(5,(V4),VV[50],VV[56],VV[52],MAKE_FIXNUM(0))/*  MAKE-ARRAY*/;
	V5= VALUES(0);
	((V1))->in.in_slots[7]= (V5);
	VALUES(0) = (V5);
	RETURN(1);
	}
L54:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for BUFFER-PAD-REQUEST                    */
static L16(int narg, object V1, object V2)
{ VT18 VLEX18 CLSR18
	{int V3;
	V3= fix(V2);
TTL:
	if((V3)==0){
	goto L64;}
	if(!(((fix(((V1))->in.in_slots[6]))+(V3))>(fix(((V1))->in.in_slots[2])))){
	goto L66;}
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
L66:
	{object V4;
	V4= MAKE_FIXNUM((fix(((V1))->in.in_slots[6]))+(V3));
	((V1))->in.in_slots[6]= (V4);
	}
	{int V4= fix(((V1))->in.in_slots[6]);
	if(((V4>=0&&4>0?(V4)%(4):imod(V4,4)))==0){
	goto L72;}}
	RETURN(L23(1,(V1))                        /*  BUFFER-FLUSH    */);
L72:
	VALUES(0) = Cnil;
	RETURN(1);
L64:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for BUFFER-NEW-REQUEST-NUMBER             */
static L17(int narg, object V1)
{ VT19 VLEX19 CLSR19
TTL:
	(*LK5)(2,MAKE_FIXNUM(16),MAKE_FIXNUM(0))  /*  BYTE            */;
	T0= VALUES(0);
	(*LK6)(2,T0,one_plus(((V1))->in.in_slots[3]))/*  LDB          */;
	((V1))->in.in_slots[3]= VALUES(0);
	VALUES(0) = VALUES(0);
	RETURN(1);
}
/*	function definition for WITH-BUFFER-REQUEST-FUNCTION          */
static L18(int narg, object V1, object V2, object V3)
{ VT20 VLEX20 CLSR20
TTL:
	if((((V1))->in.in_slots[10])==Cnil){
	goto L76;}
	(*LK1)(3,VV[23],VV[17],(V1))              /*  X-ERROR         */;
L76:
	{ int V4;
	if(((V2))==Cnil){
	goto L80;}
	(*LK7)(1,(V2))                            /*  FORCE-GCONTEXT-CHANGES-INTERNAL*/;
L80:
	V4=funcall(2,(V3),(V1));
	MV_SAVE(V4);
	(*LK8)(1,(V1))                            /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V4);
	RETURN(V4);}
}
/*	function definition for WITH-BUFFER-REQUEST-FUNCTION-NOLOCK   */
static L19(int narg, object V1, object V2, object V3)
{ VT21 VLEX21 CLSR21
TTL:
	{ int V4;
	if(((V2))==Cnil){
	goto L85;}
	(*LK7)(1,(V2))                            /*  FORCE-GCONTEXT-CHANGES-INTERNAL*/;
L85:
	V4=funcall(2,(V3),(V1));
	MV_SAVE(V4);
	(*LK8)(1,(V1))                            /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	MV_RESTORE(V4);
	RETURN(V4);}
}
/*	function definition for MAKE-PENDING-COMMAND                  */
static L20(int narg, ...)
{ VT22 VLEX22 CLSR22
	{object V1;
	object V2;
	object V3;
	object V4;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[8];
	parse_key(narg,args,4,L20keys,keyvars,OBJNULL,FALSE);
	if(keyvars[4]==Cnil){
	V1= MAKE_FIXNUM(0);
	}else{
	V1= keyvars[0];}
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	}
	(*LK9)(1,VV[59])                          /*  FIND-CLASS      */;
	RETURN(siLmake_structure(5,VALUES(0),(V1),(V2),(V3),(V4))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for WITH-BUFFER-REQUEST-AND-REPLY-FUNCTION*/
static L21(int narg, object V1, object V2, object V3, object V4)
{ VT23 VLEX23 CLSR23
TTL:
	{volatile object V5;                      /*  PENDING-COMMAND */
	volatile object V6;                       /*  REPLY-BUFFER    */
	V5= Cnil;
	V6= Cnil;
	{ int V7; volatile bool unwinding = FALSE;
	if ((V7=frs_push(FRS_PROTECT,Cnil))) {
	V7--; unwinding = TRUE;} else {
	if((((V1))->in.in_slots[10])==Cnil){
	goto L93;}
	(*LK1)(3,VV[23],VV[17],(V1))              /*  X-ERROR         */;
L93:
	(*LK10)(1,(V1))                           /*  START-PENDING-COMMAND*/;
	V5= VALUES(0);
	funcall(2,(V3),(V1));
	L25(1,(V1))                               /*  BUFFER-FORCE-OUTPUT*/;
	(*LK8)(1,(V1))                            /*  DISPLAY-INVOKE-AFTER-FUNCTION*/;
	if(((V2))==Cnil){
	goto L101;}
L104:
	(*LK11)(2,(V1),(V5))                      /*  READ-REPLY      */;
	V6= VALUES(0);
	funcall(3,(V4),(V1),(V6));
	if(VALUES(0)==Cnil){
	goto L108;}
	VALUES(0)=Cnil;
	V7=1;
	goto L91;
L108:
	{register object V8;
	register object V9;
	V8= (V6);
	V9= Cnil;
	V6= (V9);
	VALUES(0) = (V8);
	}
	(*LK12)(1,VALUES(0))                      /*  DEALLOCATE-REPLY-BUFFER*/;
	goto L104;
L101:
	(*LK11)(2,(V1),(V5))                      /*  READ-REPLY      */;
	V6= VALUES(0);
	V7=funcall(3,(V4),(V1),(V6));
L91:
	}
	frs_pop();
	MV_SAVE(V7);
	if(((V6))==Cnil){
	goto L120;}
	(*LK12)(1,(V6))                           /*  DEALLOCATE-REPLY-BUFFER*/;
L120:
	if(((V5))==Cnil){
	goto L119;}
	(*LK13)(2,(V1),(V5))                      /*  STOP-PENDING-COMMAND*/;
L119:
	MV_RESTORE(V7);
	if (unwinding) unwind(nlj_fr,nlj_tag,V7+1);
	else {
	RETURN(V7);}}
	}
}
/*	function definition for BUFFER-WRITE                          */
static L22(int narg, object V1, object V2, object V3, object V4)
{ VT24 VLEX24 CLSR24
TTL:
	if((((V2))->in.in_slots[10])==Cnil){
	goto L125;}
	(*LK1)(3,VV[23],VV[17],(V2))              /*  X-ERROR         */;
L125:
	if((((V2))->in.in_slots[10])!=Cnil){
	goto L128;}
	T0= ((V2))->in.in_slots[12];
	funcall(5,T0,(V1),(V2),(V3),(V4));
L128:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for BUFFER-FLUSH                          */
static L23(int narg, object V1)
{ VT25 VLEX25 CLSR25
TTL:
	if((((V1))->in.in_slots[11])!=Cnil){
	goto L132;}
	{int V2;                                  /*  BOFFSET         */
	V2= fix(((V1))->in.in_slots[6]);
	if(!((V2)>0)){
	goto L132;}
	L22(4,((V1))->in.in_slots[7],(V1),MAKE_FIXNUM(0),MAKE_FIXNUM(V2))/*  BUFFER-WRITE*/;
	((V1))->in.in_slots[6]= MAKE_FIXNUM(0);
	((V1))->in.in_slots[4]= Cnil;
	}
L132:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	macro definition for WITH-BUFFER-FLUSH-INHIBITED              */
static L24(int narg, object V1, object V2)
{ VT26 VLEX26 CLSR26
	{object V3=CDR(V1),V4,V5;
	{object V6= CAR(V3);
	V4= CAR(V6);}
	V3=CDR(V3);
	V5= V3;
	{register object V7;                      /*  BUF             */
	if(type_of((V4))==t_symbol){
	goto L141;}
	Lconstantp(1,(V4))                        /*  CONSTANTP       */;
	if(VALUES(0)==Cnil){
	goto L142;}
L141:
	V7= (V4);
	goto L140;
L142:
	V7= VV[8];
L140:
	if(((((V7))==((V4))?Ct:Cnil))==Cnil){
	goto L147;}
	T0= Cnil;
	goto L146;
L147:
	T0= CONS(list(2,(V7),(V4)),Cnil);
L146:
	{object V8= append(T0,CONS(list(2,VV[67],list(2,VV[68],(V7))),Cnil));
	{object V9= listA(3,VV[70],list(3,VV[71],list(2,VV[68],(V7)),Ct),(V5));
	VALUES(0) = list(3,VV[44],(V8),list(3,VV[69],(V9),list(3,VV[71],list(2,VV[68],(V7)),VV[67])));
	RETURN(1);}}
	}}
}
/*	function definition for BUFFER-FORCE-OUTPUT                   */
static L25(int narg, object V1)
{ VT27 VLEX27 CLSR27
TTL:
	if((((V1))->in.in_slots[10])==Cnil){
	goto L149;}
	(*LK1)(3,VV[23],VV[17],(V1))              /*  X-ERROR         */;
L149:
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	if((((V1))->in.in_slots[10])!=Cnil){
	goto L153;}
	T0= ((V1))->in.in_slots[13];
	funcall(2,T0,(V1));
L153:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for CLOSE-BUFFER                          */
static L26(int narg, object V1, ...)
{ VT28 VLEX28 CLSR28
	{object V2;
	va_list args; va_start(args, V1);
	narg -=1;
	{ object keyvars[2];
	parse_key(narg,args,1,L26keys,keyvars,OBJNULL,FALSE);
	V2= keyvars[0];
	}
	if((((V1))->in.in_slots[1])==Cnil){
	goto L157;}
	if((((V1))->in.in_slots[10])!=Cnil){
	goto L160;}
	T0= ((V1))->in.in_slots[14];
	funcall(4,T0,(V1),VV[72],(V2));
L160:
	((V1))->in.in_slots[10]= Ct;
	((V1))->in.in_slots[1]= Cnil;
	((V1))->in.in_slots[9]= Cnil;
L157:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for BUFFER-INPUT                          */
static L27(int narg, object V1, object V2, object V3, object V4, ...)
{ VT29 VLEX29 CLSR29
	{int V5;
	int V6;int i=4;
	object V7;
	va_list args; va_start(args, V4);
	V5= fix(V3);
	V6= fix(V4);
	if (i==narg) goto L166;
	V7= va_arg(args, object);
	i++;
	goto L167;
L166:
	V7= Cnil;
L167:
	if((((V1))->in.in_slots[10])==Cnil){
	goto L169;}
	(*LK1)(3,VV[23],VV[17],(V1))              /*  X-ERROR         */;
L169:
	if((V5)==(V6)){
	goto L173;}
	{object V8;                               /*  RESULT          */
	T0= ((V1))->in.in_slots[15];
	funcall(6,T0,(V1),(V2),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),(V7));
	V8= VALUES(0);
	if(((V8))==Cnil){
	goto L177;}
	if(((V8))==(VV[21])){
	goto L177;}
	L26(1,(V1))                               /*  CLOSE-BUFFER    */;
L177:
	VALUES(0) = (V8);
	RETURN(1);
	}
L173:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for BUFFER-INPUT-WAIT                     */
static L28(int narg, object V1, object V2)
{ VT30 VLEX30 CLSR30
TTL:
	if((((V1))->in.in_slots[10])==Cnil){
	goto L182;}
	(*LK1)(3,VV[23],VV[17],(V1))              /*  X-ERROR         */;
L182:
	{object V3;                               /*  RESULT          */
	T0= ((V1))->in.in_slots[16];
	funcall(3,T0,(V1),(V2));
	V3= VALUES(0);
	if(((V3))==Cnil){
	goto L187;}
	if(((V3))==(VV[21])){
	goto L187;}
	L26(1,(V1))                               /*  CLOSE-BUFFER    */;
L187:
	VALUES(0) = (V3);
	RETURN(1);
	}
}
/*	function definition for BUFFER-LISTEN                         */
static L29(int narg, object V1)
{ VT31 VLEX31 CLSR31
TTL:
	if(!(((((V1))->in.in_slots[10]==Cnil?Ct:Cnil))==Cnil)){
	goto L192;}
	VALUES(0) = Ct;
	RETURN(1);
L192:
	T0= ((V1))->in.in_slots[17];
	RETURN(funcall(2,T0,(V1)));
}
/*	function definition for READ-SEQUENCE-STRING                  */
static L30(int narg, object V1, object V2, object V3, object V4, ...)
{ VT32 VLEX32 CLSR32
	{volatile int V5;int i=4;
	volatile int V6;
	va_list args; va_start(args, V4);
	V5= fix(V3);
	if (i==narg) goto L195;
	V6= fix(va_arg(args, object));
	i++;
	goto L196;
L195:
	V6= 0;
L196:
	{volatile object V7;                      /*  BUFFER-BBUF     */
	V7= (V1);
	{volatile object V8;                      /*  RESULT          */
	(*LK14)(2,(V4),MAKE_FIXNUM(V5))           /*  MAKE-SEQUENCE   */;
	V8= VALUES(0);
	{volatile int V9;                         /*  INDEX           */
	volatile int V10;                         /*  COUNT           */
	volatile int V11;                         /*  STRING-LENGTH   */
	volatile object V12;                      /*  STRING          */
	V9= 0;
	V10= 0;
	V11= 0;
	V12= VV[73];
L205:
	if(!((V10)>=(V5))){
	goto L206;}
	VALUES(0) = (V8);
	RETURN(1);
L206:
	V11= ((V7))->ust.ust_self[(V6)+(V9)];
	(*LK14)(2,VV[74],MAKE_FIXNUM(V11))        /*  MAKE-SEQUENCE   */;
	V12= VALUES(0);
	{volatile int V14;                        /*  I               */
	volatile int V15;                         /*  J               */
	V14= (V9)+1;
	V15= 0;
L217:
	if(!((V15)>=(V11))){
	goto L218;}
	elt_set((V8),V10,(V12));
	goto L213;
L218:
	{register object V17;
	register object V18;
	V17= (V12);
	V18= MAKE_FIXNUM(V15);
	(*LK15)(1,MAKE_FIXNUM(((V7))->ust.ust_self[(V6)+(V14)]))/*  CARD8->CHAR*/;
	((V17))->ust.ust_self[fix((V18))]= char_code(VALUES(0));
	}
	V14= (V14)+1;
	V15= (V15)+1;
	goto L217;
	}
L213:
	V9= ((V9)+(1))+(V11);
	V10= (V10)+1;
	goto L205;
	}
	}
	}
	}
}
/*	function definition for READ-SEQUENCE-CHAR                    */
static L31(int narg, object V1, object V2, object V3, ...)
{ VT33 VLEX33 CLSR33
	{int V4;int i=3;
	object V5;
	int V6;
	int V7;
	va_list args; va_start(args, V3);
	V4= fix(V3);
	if (i==narg) goto L234;
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(va_arg(args, object),env0));/*  TRANSFORM */
	i++;
	if (i==narg) goto L235;
	V5= va_arg(args, object);
	i++;
	if (i==narg) goto L236;
	V6= fix(va_arg(args, object));
	i++;
	if (i==narg) goto L237;
	V7= fix(va_arg(args, object));
	i++;
	goto L238;
L234:
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  TRANSFORM       */
L235:
	V5= Cnil;
L236:
	V6= 0;
L237:
	V7= 0;
L238:
	if((*CLV0)==Cnil){
	goto L244;}
	{ object V8;
	V8= make_cclosure(LC32,env0,&Cblock);
	RETURN(L39(7,(V1),(V2),MAKE_FIXNUM(V4),(V8),(V5),MAKE_FIXNUM(V6),MAKE_FIXNUM(V7))/*  READ-SEQUENCE-CARD8*/);
	}
L244:
	VALUES(0) = (VV[220]->s.s_gfdef);
	RETURN(L39(7,(V1),(V2),MAKE_FIXNUM(V4),VALUES(0),(V5),MAKE_FIXNUM(V6),MAKE_FIXNUM(V7))/*  READ-SEQUENCE-CARD8*/);
	}
}
/*	closure CARD8->CHAR->TRANSFORM                                */
static LC32(int narg, object env0, object V1)
{ VT34 VLEX34 CLSR34
	narg--;
	{object scan=env0;
	CLV0= &CAR(scan);                         /*  TRANSFORM       */}
TTL:
	(*LK15)(1,(V1))                           /*  CARD8->CHAR     */;
	RETURN(funcall(2,*CLV0,VALUES(0)));
}
/*	function definition for READ-LIST-CARD8                       */
static L33(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT35 VLEX35 CLSR35
TTL:
	{volatile object V6;                      /*  %REPLY-BUFFER   */
	{volatile int V7;                         /*  BUFFER-BOFFSET  */
	volatile object V8;                       /*  BUFFER-BBUF     */
	V7= fix((V5));
	V8= ((V1))->in.in_slots[1];
	{volatile int V9;                         /*  J               */
	volatile object V10;                      /*  LST             */
	volatile int V11;                         /*  INDEX           */
	V9= fix((V2));
	V10= nthcdr(fix((V4)),(V3));
	V11= 0;
L256:
	if(!((V9)==0)){
	goto L257;}
	VALUES(0) = Cnil;
	RETURN(1);
L257:
	{register object V13;
	register int V14;
	V13= (V10);
	V14= ((V8))->ust.ust_self[(V7)+(V11)];
	CAR((V13)) = MAKE_FIXNUM(V14);
	}
	V9= (V9)-(1);
	V10= CDR((V10));
	V11= (V11)+(1);
	goto L256;
	}
	}
	}
}
/*	function definition for READ-LIST-CARD8-WITH-TRANSFORM        */
static L34(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT36 VLEX36 CLSR36
TTL:
	{volatile object V7;                      /*  %REPLY-BUFFER   */
	{volatile int V8;                         /*  BUFFER-BOFFSET  */
	volatile object V9;                       /*  BUFFER-BBUF     */
	V8= fix((V6));
	V9= ((V1))->in.in_slots[1];
	{volatile int V10;                        /*  J               */
	volatile object V11;                      /*  LST             */
	volatile int V12;                         /*  INDEX           */
	V10= fix((V2));
	V11= nthcdr(fix((V5)),(V3));
	V12= 0;
L279:
	if(!((V10)==0)){
	goto L280;}
	VALUES(0) = Cnil;
	RETURN(1);
L280:
	{register object V14;
	register object V15;
	V14= (V11);
	funcall(2,(V4),MAKE_FIXNUM(((V9))->ust.ust_self[(V8)+(V12)]));
	V15= VALUES(0);
	CAR((V14)) = (V15);
	}
	V10= (V10)-(1);
	V11= CDR((V11));
	V12= (V12)+(1);
	goto L279;
	}
	}
	}
}
/*	function definition for READ-SIMPLE-ARRAY-CARD8               */
static L35(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT37 VLEX37 CLSR37
	{int V6;
	V6= fix(V4);
TTL:
	{object V7;                               /*  DATA            */
	{object V8;                               /*  %REPLY-BUFFER   */
	{object V9;                               /*  BUFFER-BBUF     */
	V9= ((V1))->in.in_slots[1];
	RETURN((*LK16)(5,(V3),(V9),MAKE_FIXNUM(V6),MAKE_FIXNUM((V6)+(fix((V2)))),(V5))/*  BUFFER-REPLACE*/);
	}
	}
	}
	}
}
/*	function definition for READ-SIMPLE-ARRAY-CARD8-WITH-TRANSFORM*/
static L36(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT38 VLEX38 CLSR38
	{volatile int V7;
	V7= fix(V5);
TTL:
	{volatile object V8;                      /*  DATA            */
	V8= (V3);
	{volatile object V9;                      /*  %REPLY-BUFFER   */
	{volatile int V10;                        /*  BUFFER-BOFFSET  */
	volatile object V11;                      /*  BUFFER-BBUF     */
	V10= fix((V6));
	V11= ((V1))->in.in_slots[1];
	{volatile int V12;                        /*  J               */
	volatile int V13;                         /*  END             */
	volatile int V14;                         /*  INDEX           */
	V12= V7;
	V13= (V7)+(fix((V2)));
	V14= 0;
L305:
	if(!((V12)>=(V13))){
	goto L306;}
	VALUES(0) = Cnil;
	RETURN(1);
L306:
	funcall(2,(V4),MAKE_FIXNUM(((V11))->ust.ust_self[(V10)+(V14)]));
	((V8))->ust.ust_self[V12]= fix(VALUES(0));
	V12= (V12)+(1);
	V14= (V14)+(1);
	goto L305;
	}
	}
	}
	}
	}
}
/*	function definition for READ-VECTOR-CARD8                     */
static L37(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT39 VLEX39 CLSR39
	{volatile int V6;
	V6= fix(V4);
TTL:
	{volatile object V7;                      /*  DATA            */
	V7= (V3);
	{volatile object V8;                      /*  %REPLY-BUFFER   */
	{volatile int V9;                         /*  BUFFER-BOFFSET  */
	volatile object V10;                      /*  BUFFER-BBUF     */
	V9= fix((V5));
	V10= ((V1))->in.in_slots[1];
	{volatile int V11;                        /*  J               */
	volatile int V12;                         /*  END             */
	volatile int V13;                         /*  INDEX           */
	V11= V6;
	V12= (V6)+(fix((V2)));
	V13= 0;
L324:
	if(!((V11)>=(V12))){
	goto L325;}
	VALUES(0) = Cnil;
	RETURN(1);
L325:
	((V7))->ust.ust_self[V11]= ((V10))->ust.ust_self[(V9)+(V13)];
	V11= (V11)+(1);
	V13= (V13)+(1);
	goto L324;
	}
	}
	}
	}
	}
}
/*	function definition for READ-VECTOR-CARD8-WITH-TRANSFORM      */
static L38(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT40 VLEX40 CLSR40
	{volatile int V7;
	V7= fix(V5);
TTL:
	{volatile object V8;                      /*  DATA            */
	V8= (V3);
	{volatile object V9;                      /*  %REPLY-BUFFER   */
	{volatile int V10;                        /*  BUFFER-BOFFSET  */
	volatile object V11;                      /*  BUFFER-BBUF     */
	V10= fix((V6));
	V11= ((V1))->in.in_slots[1];
	{volatile int V12;                        /*  J               */
	volatile int V13;                         /*  END             */
	volatile int V14;                         /*  INDEX           */
	V12= V7;
	V13= (V7)+(fix((V2)));
	V14= 0;
L342:
	if(!((V12)>=(V13))){
	goto L343;}
	VALUES(0) = Cnil;
	RETURN(1);
L343:
	funcall(2,(V4),MAKE_FIXNUM(((V11))->ust.ust_self[(V10)+(V14)]));
	((V8))->ust.ust_self[V12]= fix(VALUES(0));
	V12= (V12)+(1);
	V14= (V14)+(1);
	goto L342;
	}
	}
	}
	}
	}
}
/*	function definition for READ-SEQUENCE-CARD8                   */
static L39(int narg, object V1, object V2, object V3, ...)
{ VT41 VLEX41 CLSR41
	{register int V4;int i=3;
	register object V5;
	object V6;
	register int V7;
	register int V8;
	va_list args; va_start(args, V3);
	V4= fix(V3);
	if (i==narg) goto L353;
	V5= va_arg(args, object);
	i++;
	if (i==narg) goto L354;
	V6= va_arg(args, object);
	i++;
	if (i==narg) goto L355;
	V7= fix(va_arg(args, object));
	i++;
	if (i==narg) goto L356;
	V8= fix(va_arg(args, object));
	i++;
	goto L357;
L353:
	V5= Cnil;
L354:
	V6= Cnil;
L355:
	V7= 0;
L356:
	V8= 0;
L357:
	{register object V9;                      /*  RESULT          */
	if((V6)!=Cnil){
	V9= (V6);
	goto L362;}
	(*LK14)(2,(V2),MAKE_FIXNUM(V4))           /*  MAKE-SEQUENCE   */;
	V9= VALUES(0);
L362:
	{object V10;
	(*LK17)(2,(V9),VV[76])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L365;}
	if(((V5))==Cnil){
	goto L368;}
	L34(6,(V1),MAKE_FIXNUM(V4),(V9),(V5),MAKE_FIXNUM(V7),MAKE_FIXNUM(V8))/*  READ-LIST-CARD8-WITH-TRANSFORM*/;
	goto L363;
L368:
	L33(5,(V1),MAKE_FIXNUM(V4),(V9),MAKE_FIXNUM(V7),MAKE_FIXNUM(V8))/*  READ-LIST-CARD8*/;
	goto L363;
L365:
	(*LK17)(2,(V9),VV[77])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L371;}
	if(((V5))==Cnil){
	goto L374;}
	L36(6,(V1),MAKE_FIXNUM(V4),(V9),(V5),MAKE_FIXNUM(V7),MAKE_FIXNUM(V8))/*  READ-SIMPLE-ARRAY-CARD8-WITH-TRANSFORM*/;
	goto L363;
L374:
	L35(5,(V1),MAKE_FIXNUM(V4),(V9),MAKE_FIXNUM(V7),MAKE_FIXNUM(V8))/*  READ-SIMPLE-ARRAY-CARD8*/;
	goto L363;
L371:
	if(((V5))==Cnil){
	goto L377;}
	L38(6,(V1),MAKE_FIXNUM(V4),(V9),(V5),MAKE_FIXNUM(V7),MAKE_FIXNUM(V8))/*  READ-VECTOR-CARD8-WITH-TRANSFORM*/;
	goto L363;
L377:
	L37(5,(V1),MAKE_FIXNUM(V4),(V9),MAKE_FIXNUM(V7),MAKE_FIXNUM(V8))/*  READ-VECTOR-CARD8*/;
	}
L363:
	VALUES(0) = (V9);
	RETURN(1);
	}
	}
}
/*	function definition for READ-SEQUENCE-INT8                    */
static L40(int narg, object V1, object V2, object V3, ...)
{ VT42 VLEX42 CLSR42
	{int V4;int i=3;
	object V5;
	int V6;
	int V7;
	va_list args; va_start(args, V3);
	V4= fix(V3);
	if (i==narg) goto L379;
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(va_arg(args, object),env0));/*  TRANSFORM */
	i++;
	if (i==narg) goto L380;
	V5= va_arg(args, object);
	i++;
	if (i==narg) goto L381;
	V6= fix(va_arg(args, object));
	i++;
	if (i==narg) goto L382;
	V7= fix(va_arg(args, object));
	i++;
	goto L383;
L379:
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  TRANSFORM       */
L380:
	V5= Cnil;
L381:
	V6= 0;
L382:
	V7= 0;
L383:
	if((*CLV0)==Cnil){
	goto L389;}
	{ object V8;
	V8= make_cclosure(LC41,env0,&Cblock);
	RETURN(L39(7,(V1),(V2),MAKE_FIXNUM(V4),(V8),(V5),MAKE_FIXNUM(V6),MAKE_FIXNUM(V7))/*  READ-SEQUENCE-CARD8*/);
	}
L389:
	VALUES(0) = (VV[232]->s.s_gfdef);
	RETURN(L39(7,(V1),(V2),MAKE_FIXNUM(V4),VALUES(0),(V5),MAKE_FIXNUM(V6),MAKE_FIXNUM(V7))/*  READ-SEQUENCE-CARD8*/);
	}
}
/*	closure CARD8->INT8->TRANSFORM                                */
static LC41(int narg, object env0, object V1)
{ VT43 VLEX43 CLSR43
	narg--;
	{object scan=env0;
	CLV0= &CAR(scan);                         /*  TRANSFORM       */}
TTL:
	RETURN(funcall(2,*CLV0,MAKE_FIXNUM((fix((V1))) & 0x80 ? ((fix((V1)))-0x100) : (fix((V1))))));
}
/*	function definition for READ-LIST-CARD16                      */
static L42(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT44 VLEX44 CLSR44
TTL:
	{volatile object V6;                      /*  %REPLY-BUFFER   */
	{volatile int V7;                         /*  BUFFER-BOFFSET  */
	volatile object V8;                       /*  BUFFER-BBUF     */
	V7= fix((V5));
	V8= ((V1))->in.in_slots[1];
	{volatile int V9;                         /*  J               */
	volatile object V10;                      /*  LST             */
	volatile int V11;                         /*  INDEX           */
	V9= fix((V2));
	V10= nthcdr(fix((V4)),(V3));
	V11= 0;
L400:
	if(!((V9)==0)){
	goto L401;}
	VALUES(0) = Cnil;
	RETURN(1);
L401:
	{register object V13;
	register int V14;
	V13= (V10);
	V14= (*(unsigned short *)(((V8))->ust.ust_self+((V7)+(V11))));
	CAR((V13)) = MAKE_FIXNUM(V14);
	}
	V9= (V9)-(1);
	V10= CDR((V10));
	V11= (V11)+(2);
	goto L400;
	}
	}
	}
}
/*	function definition for READ-LIST-CARD16-WITH-TRANSFORM       */
static L43(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT45 VLEX45 CLSR45
TTL:
	{volatile object V7;                      /*  %REPLY-BUFFER   */
	{volatile int V8;                         /*  BUFFER-BOFFSET  */
	volatile object V9;                       /*  BUFFER-BBUF     */
	V8= fix((V6));
	V9= ((V1))->in.in_slots[1];
	{volatile int V10;                        /*  J               */
	volatile object V11;                      /*  LST             */
	volatile int V12;                         /*  INDEX           */
	V10= fix((V2));
	V11= nthcdr(fix((V5)),(V3));
	V12= 0;
L423:
	if(!((V10)==0)){
	goto L424;}
	VALUES(0) = Cnil;
	RETURN(1);
L424:
	{register object V14;
	register object V15;
	V14= (V11);
	funcall(2,(V4),MAKE_FIXNUM((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(V12))))));
	V15= VALUES(0);
	CAR((V14)) = (V15);
	}
	V10= (V10)-(1);
	V11= CDR((V11));
	V12= (V12)+(2);
	goto L423;
	}
	}
	}
}
/*	function definition for READ-SIMPLE-ARRAY-CARD16              */
static L44(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT46 VLEX46 CLSR46
	{volatile int V6;
	V6= fix(V4);
TTL:
	{volatile object V7;                      /*  DATA            */
	V7= (V3);
	{volatile object V8;                      /*  %REPLY-BUFFER   */
	{volatile int V9;                         /*  BUFFER-BOFFSET  */
	volatile object V10;                      /*  BUFFER-BBUF     */
	V9= fix((V5));
	V10= ((V1))->in.in_slots[1];
	{volatile int V11;                        /*  J               */
	volatile int V12;                         /*  END             */
	volatile int V13;                         /*  INDEX           */
	V11= V6;
	V12= (V6)+(fix((V2)));
	V13= 0;
L446:
	if(!((V11)>=(V12))){
	goto L447;}
	VALUES(0) = Cnil;
	RETURN(1);
L447:
	{register object V15;
	register object V16;
	V15= (V7);
	V16= MAKE_FIXNUM(V11);
	((V15))->fixa.fixa_self[fix((V16))]= (*(unsigned short *)(((V10))->ust.ust_self+((V9)+(V13))));
	}
	V11= (V11)+(1);
	V13= (V13)+(2);
	goto L446;
	}
	}
	}
	}
	}
}
/*	function definition for READ-SIMPLE-ARRAY-CARD16-WITH-TRANSFORM*/
static L45(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT47 VLEX47 CLSR47
	{volatile int V7;
	V7= fix(V5);
TTL:
	{volatile object V8;                      /*  DATA            */
	V8= (V3);
	{volatile object V9;                      /*  %REPLY-BUFFER   */
	{volatile int V10;                        /*  BUFFER-BOFFSET  */
	volatile object V11;                      /*  BUFFER-BBUF     */
	V10= fix((V6));
	V11= ((V1))->in.in_slots[1];
	{volatile int V12;                        /*  J               */
	volatile int V13;                         /*  END             */
	volatile int V14;                         /*  INDEX           */
	V12= V7;
	V13= (V7)+(fix((V2)));
	V14= 0;
L466:
	if(!((V12)>=(V13))){
	goto L467;}
	VALUES(0) = Cnil;
	RETURN(1);
L467:
	{register object V16;
	register object V17;
	V16= (V8);
	V17= MAKE_FIXNUM(V12);
	funcall(2,(V4),MAKE_FIXNUM((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(V14))))));
	((V16))->fixa.fixa_self[fix((V17))]= fix(VALUES(0));
	}
	V12= (V12)+(1);
	V14= (V14)+(2);
	goto L466;
	}
	}
	}
	}
	}
}
/*	function definition for READ-VECTOR-CARD16                    */
static L46(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT48 VLEX48 CLSR48
	{volatile int V6;
	V6= fix(V4);
TTL:
	{volatile object V7;                      /*  DATA            */
	V7= (V3);
	{volatile object V8;                      /*  %REPLY-BUFFER   */
	{volatile int V9;                         /*  BUFFER-BOFFSET  */
	volatile object V10;                      /*  BUFFER-BBUF     */
	V9= fix((V5));
	V10= ((V1))->in.in_slots[1];
	{volatile int V11;                        /*  J               */
	volatile int V12;                         /*  END             */
	volatile int V13;                         /*  INDEX           */
	V11= V6;
	V12= (V6)+(fix((V2)));
	V13= 0;
L487:
	if(!((V11)>=(V12))){
	goto L488;}
	VALUES(0) = Cnil;
	RETURN(1);
L488:
	{register object V15;
	register object V16;
	V15= (V7);
	V16= MAKE_FIXNUM(V11);
	((V15))->v.v_self[fix((V16))]= MAKE_FIXNUM((*(unsigned short *)(((V10))->ust.ust_self+((V9)+(V13)))));
	}
	V11= (V11)+(1);
	V13= (V13)+(2);
	goto L487;
	}
	}
	}
	}
	}
}
/*	function definition for READ-VECTOR-CARD16-WITH-TRANSFORM     */
static L47(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT49 VLEX49 CLSR49
	{volatile int V7;
	V7= fix(V5);
TTL:
	{volatile object V8;                      /*  DATA            */
	V8= (V3);
	{volatile object V9;                      /*  %REPLY-BUFFER   */
	{volatile int V10;                        /*  BUFFER-BOFFSET  */
	volatile object V11;                      /*  BUFFER-BBUF     */
	V10= fix((V6));
	V11= ((V1))->in.in_slots[1];
	{volatile int V12;                        /*  J               */
	volatile int V13;                         /*  END             */
	volatile int V14;                         /*  INDEX           */
	V12= V7;
	V13= (V7)+(fix((V2)));
	V14= 0;
L507:
	if(!((V12)>=(V13))){
	goto L508;}
	VALUES(0) = Cnil;
	RETURN(1);
L508:
	{register object V16;
	register object V17;
	V16= (V8);
	V17= MAKE_FIXNUM(V12);
	funcall(2,(V4),MAKE_FIXNUM((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(V14))))));
	((V16))->v.v_self[fix((V17))]= VALUES(0);
	}
	V12= (V12)+(1);
	V14= (V14)+(2);
	goto L507;
	}
	}
	}
	}
	}
}
/*	function definition for READ-SEQUENCE-CARD16                  */
static L48(int narg, object V1, object V2, object V3, ...)
{ VT50 VLEX50 CLSR50
	{register int V4;int i=3;
	register object V5;
	object V6;
	register int V7;
	register int V8;
	va_list args; va_start(args, V3);
	V4= fix(V3);
	if (i==narg) goto L520;
	V5= va_arg(args, object);
	i++;
	if (i==narg) goto L521;
	V6= va_arg(args, object);
	i++;
	if (i==narg) goto L522;
	V7= fix(va_arg(args, object));
	i++;
	if (i==narg) goto L523;
	V8= fix(va_arg(args, object));
	i++;
	goto L524;
L520:
	V5= Cnil;
L521:
	V6= Cnil;
L522:
	V7= 0;
L523:
	V8= 0;
L524:
	{register object V9;                      /*  RESULT          */
	if((V6)!=Cnil){
	V9= (V6);
	goto L529;}
	(*LK14)(2,(V2),MAKE_FIXNUM(V4))           /*  MAKE-SEQUENCE   */;
	V9= VALUES(0);
L529:
	{object V10;
	(*LK17)(2,(V9),VV[76])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L532;}
	if(((V5))==Cnil){
	goto L535;}
	L43(6,(V1),MAKE_FIXNUM(V4),(V9),(V5),MAKE_FIXNUM(V7),MAKE_FIXNUM(V8))/*  READ-LIST-CARD16-WITH-TRANSFORM*/;
	goto L530;
L535:
	L42(5,(V1),MAKE_FIXNUM(V4),(V9),MAKE_FIXNUM(V7),MAKE_FIXNUM(V8))/*  READ-LIST-CARD16*/;
	goto L530;
L532:
	(*LK17)(2,(V9),VV[78])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L538;}
	if(((V5))==Cnil){
	goto L541;}
	L45(6,(V1),MAKE_FIXNUM(V4),(V9),(V5),MAKE_FIXNUM(V7),MAKE_FIXNUM(V8))/*  READ-SIMPLE-ARRAY-CARD16-WITH-TRANSFORM*/;
	goto L530;
L541:
	L44(5,(V1),MAKE_FIXNUM(V4),(V9),MAKE_FIXNUM(V7),MAKE_FIXNUM(V8))/*  READ-SIMPLE-ARRAY-CARD16*/;
	goto L530;
L538:
	if(((V5))==Cnil){
	goto L544;}
	L47(6,(V1),MAKE_FIXNUM(V4),(V9),(V5),MAKE_FIXNUM(V7),MAKE_FIXNUM(V8))/*  READ-VECTOR-CARD16-WITH-TRANSFORM*/;
	goto L530;
L544:
	L46(5,(V1),MAKE_FIXNUM(V4),(V9),MAKE_FIXNUM(V7),MAKE_FIXNUM(V8))/*  READ-VECTOR-CARD16*/;
	}
L530:
	VALUES(0) = (V9);
	RETURN(1);
	}
	}
}
/*	function definition for READ-SEQUENCE-INT16                   */
static L49(int narg, object V1, object V2, object V3, ...)
{ VT51 VLEX51 CLSR51
	{int V4;int i=3;
	object V5;
	int V6;
	int V7;
	va_list args; va_start(args, V3);
	V4= fix(V3);
	if (i==narg) goto L546;
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(va_arg(args, object),env0));/*  TRANSFORM */
	i++;
	if (i==narg) goto L547;
	V5= va_arg(args, object);
	i++;
	if (i==narg) goto L548;
	V6= fix(va_arg(args, object));
	i++;
	if (i==narg) goto L549;
	V7= fix(va_arg(args, object));
	i++;
	goto L550;
L546:
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  TRANSFORM       */
L547:
	V5= Cnil;
L548:
	V6= 0;
L549:
	V7= 0;
L550:
	if((*CLV0)==Cnil){
	goto L556;}
	{ object V8;
	V8= make_cclosure(LC50,env0,&Cblock);
	RETURN(L48(7,(V1),(V2),MAKE_FIXNUM(V4),(V8),(V5),MAKE_FIXNUM(V6),MAKE_FIXNUM(V7))/*  READ-SEQUENCE-CARD16*/);
	}
L556:
	VALUES(0) = (VV[241]->s.s_gfdef);
	RETURN(L48(7,(V1),(V2),MAKE_FIXNUM(V4),VALUES(0),(V5),MAKE_FIXNUM(V6),MAKE_FIXNUM(V7))/*  READ-SEQUENCE-CARD16*/);
	}
}
/*	closure CARD16->INT16->TRANSFORM                              */
static LC50(int narg, object env0, object V1)
{ VT52 VLEX52 CLSR52
	narg--;
	{object scan=env0;
	CLV0= &CAR(scan);                         /*  TRANSFORM       */}
TTL:
	RETURN(funcall(2,*CLV0,MAKE_FIXNUM(((short)(fix((V1)))))));
}
/*	function definition for READ-LIST-CARD32                      */
static L51(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT53 VLEX53 CLSR53
TTL:
	{volatile object V6;                      /*  %REPLY-BUFFER   */
	{volatile int V7;                         /*  BUFFER-BOFFSET  */
	volatile object V8;                       /*  BUFFER-BBUF     */
	V7= fix((V5));
	V8= ((V1))->in.in_slots[1];
	{volatile int V9;                         /*  J               */
	volatile object V10;                      /*  LST             */
	volatile int V11;                         /*  INDEX           */
	V9= fix((V2));
	V10= nthcdr(fix((V4)),(V3));
	V11= 0;
L567:
	if(!((V9)==0)){
	goto L568;}
	VALUES(0) = Cnil;
	RETURN(1);
L568:
	{register object V13;
	register int V14;
	V13= (V10);
	V14= (*(unsigned long *)(((V8))->ust.ust_self+((V7)+(V11))));
	CAR((V13)) = MAKE_FIXNUM(V14);
	}
	V9= (V9)-(1);
	V10= CDR((V10));
	V11= (V11)+(4);
	goto L567;
	}
	}
	}
}
/*	function definition for READ-LIST-CARD32-WITH-TRANSFORM       */
static L52(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT54 VLEX54 CLSR54
TTL:
	{volatile object V7;                      /*  %REPLY-BUFFER   */
	{volatile int V8;                         /*  BUFFER-BOFFSET  */
	volatile object V9;                       /*  BUFFER-BBUF     */
	V8= fix((V6));
	V9= ((V1))->in.in_slots[1];
	{volatile int V10;                        /*  J               */
	volatile object V11;                      /*  LST             */
	volatile int V12;                         /*  INDEX           */
	V10= fix((V2));
	V11= nthcdr(fix((V5)),(V3));
	V12= 0;
L590:
	if(!((V10)==0)){
	goto L591;}
	VALUES(0) = Cnil;
	RETURN(1);
L591:
	{register object V14;
	register object V15;
	V14= (V11);
	funcall(2,(V4),MAKE_FIXNUM((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(V12))))));
	V15= VALUES(0);
	CAR((V14)) = (V15);
	}
	V10= (V10)-(1);
	V11= CDR((V11));
	V12= (V12)+(4);
	goto L590;
	}
	}
	}
}
/*	function definition for READ-SIMPLE-ARRAY-CARD32              */
static L53(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT55 VLEX55 CLSR55
	{volatile int V6;
	V6= fix(V4);
TTL:
	{volatile object V7;                      /*  DATA            */
	V7= (V3);
	{volatile object V8;                      /*  %REPLY-BUFFER   */
	{volatile int V9;                         /*  BUFFER-BOFFSET  */
	volatile object V10;                      /*  BUFFER-BBUF     */
	V9= fix((V5));
	V10= ((V1))->in.in_slots[1];
	{volatile int V11;                        /*  J               */
	volatile int V12;                         /*  END             */
	volatile int V13;                         /*  INDEX           */
	V11= V6;
	V12= (V6)+(fix((V2)));
	V13= 0;
L613:
	if(!((V11)>=(V12))){
	goto L614;}
	VALUES(0) = Cnil;
	RETURN(1);
L614:
	{register object V15;
	register object V16;
	V15= (V7);
	V16= MAKE_FIXNUM(V11);
	((V15))->v.v_self[fix((V16))]= MAKE_FIXNUM((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(V13)))));
	}
	V11= (V11)+(1);
	V13= (V13)+(4);
	goto L613;
	}
	}
	}
	}
	}
}
/*	function definition for READ-SIMPLE-ARRAY-CARD32-WITH-TRANSFORM*/
static L54(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT56 VLEX56 CLSR56
	{volatile int V7;
	V7= fix(V5);
TTL:
	{volatile object V8;                      /*  DATA            */
	V8= (V3);
	{volatile object V9;                      /*  %REPLY-BUFFER   */
	{volatile int V10;                        /*  BUFFER-BOFFSET  */
	volatile object V11;                      /*  BUFFER-BBUF     */
	V10= fix((V6));
	V11= ((V1))->in.in_slots[1];
	{volatile int V12;                        /*  J               */
	volatile int V13;                         /*  END             */
	volatile int V14;                         /*  INDEX           */
	V12= V7;
	V13= (V7)+(fix((V2)));
	V14= 0;
L633:
	if(!((V12)>=(V13))){
	goto L634;}
	VALUES(0) = Cnil;
	RETURN(1);
L634:
	{register object V16;
	register object V17;
	V16= (V8);
	V17= MAKE_FIXNUM(V12);
	funcall(2,(V4),MAKE_FIXNUM((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(V14))))));
	((V16))->v.v_self[fix((V17))]= VALUES(0);
	}
	V12= (V12)+(1);
	V14= (V14)+(4);
	goto L633;
	}
	}
	}
	}
	}
}
/*	function definition for READ-VECTOR-CARD32                    */
static L55(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT57 VLEX57 CLSR57
	{volatile int V6;
	V6= fix(V4);
TTL:
	{volatile object V7;                      /*  DATA            */
	V7= (V3);
	{volatile object V8;                      /*  %REPLY-BUFFER   */
	{volatile int V9;                         /*  BUFFER-BOFFSET  */
	volatile object V10;                      /*  BUFFER-BBUF     */
	V9= fix((V5));
	V10= ((V1))->in.in_slots[1];
	{volatile int V11;                        /*  J               */
	volatile int V12;                         /*  END             */
	volatile int V13;                         /*  INDEX           */
	V11= V6;
	V12= (V6)+(fix((V2)));
	V13= 0;
L654:
	if(!((V11)>=(V12))){
	goto L655;}
	VALUES(0) = Cnil;
	RETURN(1);
L655:
	{register object V15;
	register object V16;
	V15= (V7);
	V16= MAKE_FIXNUM(V11);
	((V15))->v.v_self[fix((V16))]= MAKE_FIXNUM((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(V13)))));
	}
	V11= (V11)+(1);
	V13= (V13)+(4);
	goto L654;
	}
	}
	}
	}
	}
}
/*	function definition for READ-VECTOR-CARD32-WITH-TRANSFORM     */
static L56(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT58 VLEX58 CLSR58
	{volatile int V7;
	V7= fix(V5);
TTL:
	{volatile object V8;                      /*  DATA            */
	V8= (V3);
	{volatile object V9;                      /*  %REPLY-BUFFER   */
	{volatile int V10;                        /*  BUFFER-BOFFSET  */
	volatile object V11;                      /*  BUFFER-BBUF     */
	V10= fix((V6));
	V11= ((V1))->in.in_slots[1];
	{volatile int V12;                        /*  J               */
	volatile int V13;                         /*  END             */
	volatile int V14;                         /*  INDEX           */
	V12= V7;
	V13= (V7)+(fix((V2)));
	V14= 0;
L674:
	if(!((V12)>=(V13))){
	goto L675;}
	VALUES(0) = Cnil;
	RETURN(1);
L675:
	{register object V16;
	register object V17;
	V16= (V8);
	V17= MAKE_FIXNUM(V12);
	funcall(2,(V4),MAKE_FIXNUM((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(V14))))));
	((V16))->v.v_self[fix((V17))]= VALUES(0);
	}
	V12= (V12)+(1);
	V14= (V14)+(4);
	goto L674;
	}
	}
	}
	}
	}
}
/*	function definition for READ-SEQUENCE-CARD32                  */
static L57(int narg, object V1, object V2, object V3, ...)
{ VT59 VLEX59 CLSR59
	{register int V4;int i=3;
	register object V5;
	object V6;
	register int V7;
	register int V8;
	va_list args; va_start(args, V3);
	V4= fix(V3);
	if (i==narg) goto L687;
	V5= va_arg(args, object);
	i++;
	if (i==narg) goto L688;
	V6= va_arg(args, object);
	i++;
	if (i==narg) goto L689;
	V7= fix(va_arg(args, object));
	i++;
	if (i==narg) goto L690;
	V8= fix(va_arg(args, object));
	i++;
	goto L691;
L687:
	V5= Cnil;
L688:
	V6= Cnil;
L689:
	V7= 0;
L690:
	V8= 0;
L691:
	{register object V9;                      /*  RESULT          */
	if((V6)!=Cnil){
	V9= (V6);
	goto L696;}
	(*LK14)(2,(V2),MAKE_FIXNUM(V4))           /*  MAKE-SEQUENCE   */;
	V9= VALUES(0);
L696:
	{object V10;
	(*LK17)(2,(V9),VV[76])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L699;}
	if(((V5))==Cnil){
	goto L702;}
	L52(6,(V1),MAKE_FIXNUM(V4),(V9),(V5),MAKE_FIXNUM(V7),MAKE_FIXNUM(V8))/*  READ-LIST-CARD32-WITH-TRANSFORM*/;
	goto L697;
L702:
	L51(5,(V1),MAKE_FIXNUM(V4),(V9),MAKE_FIXNUM(V7),MAKE_FIXNUM(V8))/*  READ-LIST-CARD32*/;
	goto L697;
L699:
	(*LK17)(2,(V9),VV[79])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L705;}
	if(((V5))==Cnil){
	goto L708;}
	L54(6,(V1),MAKE_FIXNUM(V4),(V9),(V5),MAKE_FIXNUM(V7),MAKE_FIXNUM(V8))/*  READ-SIMPLE-ARRAY-CARD32-WITH-TRANSFORM*/;
	goto L697;
L708:
	L53(5,(V1),MAKE_FIXNUM(V4),(V9),MAKE_FIXNUM(V7),MAKE_FIXNUM(V8))/*  READ-SIMPLE-ARRAY-CARD32*/;
	goto L697;
L705:
	if(((V5))==Cnil){
	goto L711;}
	L56(6,(V1),MAKE_FIXNUM(V4),(V9),(V5),MAKE_FIXNUM(V7),MAKE_FIXNUM(V8))/*  READ-VECTOR-CARD32-WITH-TRANSFORM*/;
	goto L697;
L711:
	L55(5,(V1),MAKE_FIXNUM(V4),(V9),MAKE_FIXNUM(V7),MAKE_FIXNUM(V8))/*  READ-VECTOR-CARD32*/;
	}
L697:
	VALUES(0) = (V9);
	RETURN(1);
	}
	}
}
/*	function definition for READ-SEQUENCE-INT32                   */
static L58(int narg, object V1, object V2, object V3, ...)
{ VT60 VLEX60 CLSR60
	{int V4;int i=3;
	object V5;
	int V6;
	int V7;
	va_list args; va_start(args, V3);
	V4= fix(V3);
	if (i==narg) goto L713;
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(va_arg(args, object),env0));/*  TRANSFORM */
	i++;
	if (i==narg) goto L714;
	V5= va_arg(args, object);
	i++;
	if (i==narg) goto L715;
	V6= fix(va_arg(args, object));
	i++;
	if (i==narg) goto L716;
	V7= fix(va_arg(args, object));
	i++;
	goto L717;
L713:
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  TRANSFORM       */
L714:
	V5= Cnil;
L715:
	V6= 0;
L716:
	V7= 0;
L717:
	if((*CLV0)==Cnil){
	goto L723;}
	{ object V8;
	V8= make_cclosure(LC59,env0,&Cblock);
	RETURN(L57(7,(V1),(V2),MAKE_FIXNUM(V4),(V8),(V5),MAKE_FIXNUM(V6),MAKE_FIXNUM(V7))/*  READ-SEQUENCE-CARD32*/);
	}
L723:
	VALUES(0) = (VV[250]->s.s_gfdef);
	RETURN(L57(7,(V1),(V2),MAKE_FIXNUM(V4),VALUES(0),(V5),MAKE_FIXNUM(V6),MAKE_FIXNUM(V7))/*  READ-SEQUENCE-CARD32*/);
	}
}
/*	closure CARD32->INT32->TRANSFORM                              */
static LC59(int narg, object env0, object V1)
{ VT61 VLEX61 CLSR61
	narg--;
	{object scan=env0;
	CLV0= &CAR(scan);                         /*  TRANSFORM       */}
TTL:
	RETURN(funcall(2,*CLV0,MAKE_FIXNUM((fix((V1))))));
}
/*	function definition for WRITE-SEQUENCE-CHAR                   */
static L60(int narg, object V1, object V2, object V3, ...)
{ VT62 VLEX62 CLSR62
	{int V4;int i=3;
	int V5;
	int V6;
	va_list args; va_start(args, V3);
	V4= fix(V2);
	if (i==narg) goto L726;
	V5= fix(va_arg(args, object));
	i++;
	if (i==narg) goto L727;
	V6= fix(va_arg(args, object));
	i++;
	if (i==narg) goto L728;
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(va_arg(args, object),env0));/*  TRANSFORM */
	i++;
	goto L729;
L726:
	V5= 0;
L727:
	V6= length((V3));
L728:
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  TRANSFORM       */
L729:
	if((*CLV0)==Cnil){
	goto L734;}
	{ object V7;
	V7= make_cclosure(LC61,env0,&Cblock);
	RETURN(L68(6,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),(V7))/*  WRITE-SEQUENCE-CARD8*/);
	}
L734:
	VALUES(0) = (VV[252]->s.s_gfdef);
	RETURN(L68(6,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),VALUES(0))/*  WRITE-SEQUENCE-CARD8*/);
	}
}
/*	closure TRANSFORM->CHAR->CARD8                                */
static LC61(int narg, object env0, object V1)
{ VT63 VLEX63 CLSR63
	narg--;
	{object scan=env0;
	CLV0= &CAR(scan);                         /*  TRANSFORM       */}
TTL:
	funcall(2,*CLV0,(V1));
	RETURN((*LK18)(1,VALUES(0))               /*  CHAR->CARD8     */);
}
/*	function definition for WRITE-LIST-CARD8                      */
static L62(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT64 VLEX64 CLSR64
	{volatile int V6;
	V6= fix(V4);
TTL:
	{volatile object V7;                      /*  %BUFFER         */
	{volatile int V8;                         /*  BUFFER-BOFFSET  */
	volatile object V9;                       /*  BUFFER-BBUF     */
	V8= fix((V2));
	V9= ((V1))->in.in_slots[7];
	{volatile object V10;                     /*  LST             */
	volatile int V11;                         /*  LEN             */
	volatile int V12;                         /*  CHUNK           */
	V10= nthcdr(V6,(V3));
	V11= (fix((V5)))-(V6);
	{int V13= (fix(((V1))->in.in_slots[2]))-(V8);
	V12= (V11)<=(V13)?V11:V13;}
L749:
	if((V11)>0){
	goto L750;}
	goto L744;
L750:
	{volatile int V14;
	volatile int V15;                         /*  J               */
	V14= V12;
	V15= 0;
L757:
	if(!((V15)>=(V14))){
	goto L758;}
	goto L753;
L758:
	{register object V17;
	V17= CAR((V10));
	V10= CDR((V10));
	T0= (V17);
	}
	(((V9))->ust.ust_self[(V8)+(V15)]=(fix(T0)));
	V15= (V15)+1;
	goto L757;
	}
L753:
	V8= (V8)+(V12);
	if(!((V11)>0)){
	goto L771;}
	if(!((V8)>=(fix(((V1))->in.in_slots[2])))){
	goto L771;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V8);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V8= fix(((V1))->in.in_slots[6]);
L771:
	V11= (V11)-(V12);
	{int V17= (fix(((V1))->in.in_slots[2]))-(V8);
	V12= (V11)<=(V17)?V11:V17;}
	goto L749;
	}
L744:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V8)+(3)) & (-4)));
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-LIST-CARD8-WITH-TRANSFORM       */
static L63(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT65 VLEX65 CLSR65
	{volatile int V7;
	V7= fix(V4);
TTL:
	{volatile object V8;                      /*  %BUFFER         */
	{volatile int V9;                         /*  BUFFER-BOFFSET  */
	volatile object V10;                      /*  BUFFER-BBUF     */
	V9= fix((V2));
	V10= ((V1))->in.in_slots[7];
	{volatile object V11;                     /*  LST             */
	volatile int V12;                         /*  LEN             */
	volatile int V13;                         /*  CHUNK           */
	V11= nthcdr(V7,(V3));
	V12= (fix((V5)))-(V7);
	{int V14= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V14)?V12:V14;}
L795:
	if((V12)>0){
	goto L796;}
	goto L790;
L796:
	{volatile int V15;
	volatile int V16;                         /*  J               */
	V15= V13;
	V16= 0;
L803:
	if(!((V16)>=(V15))){
	goto L804;}
	goto L799;
L804:
	{register object V18;
	V18= CAR((V11));
	V11= CDR((V11));
	VALUES(0) = (V18);
	}
	funcall(2,(V6),VALUES(0));
	T0= VALUES(0);
	(((V10))->ust.ust_self[(V9)+(V16)]=(fix(T0)));
	V16= (V16)+1;
	goto L803;
	}
L799:
	V9= (V9)+(V13);
	if(!((V12)>0)){
	goto L818;}
	if(!((V9)>=(fix(((V1))->in.in_slots[2])))){
	goto L818;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V9);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V9= fix(((V1))->in.in_slots[6]);
L818:
	V12= (V12)-(V13);
	{int V18= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V18)?V12:V18;}
	goto L795;
	}
L790:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V9)+(3)) & (-4)));
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-SIMPLE-ARRAY-CARD8              */
static L64(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT66 VLEX66 CLSR66
	{volatile int V6;
	V6= fix(V4);
TTL:
	{volatile object V7;                      /*  DATA            */
	V7= (V3);
	{volatile object V8;                      /*  %BUFFER         */
	{volatile int V9;                         /*  BUFFER-BOFFSET  */
	volatile object V10;                      /*  BUFFER-BBUF     */
	V9= fix((V2));
	V10= ((V1))->in.in_slots[7];
	{volatile int V11;                        /*  INDEX           */
	volatile int V12;                         /*  LEN             */
	volatile int V13;                         /*  CHUNK           */
	V11= V6;
	V12= (fix((V5)))-(V6);
	{int V14= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V14)?V12:V14;}
L842:
	if((V12)>0){
	goto L843;}
	goto L837;
L843:
	(*LK16)(5,(V10),(V7),MAKE_FIXNUM(V9),MAKE_FIXNUM((V9)+(V13)),MAKE_FIXNUM(V11))/*  BUFFER-REPLACE*/;
	V9= (V9)+(V13);
	if(!((V12)>0)){
	goto L849;}
	if(!((V9)>=(fix(((V1))->in.in_slots[2])))){
	goto L849;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V9);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V9= fix(((V1))->in.in_slots[6]);
L849:
	V11= (V11)+(V13);
	V12= (V12)-(V13);
	{int V15= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V15)?V12:V15;}
	goto L842;
	}
L837:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V9)+(3)) & (-4)));
	}
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-SIMPLE-ARRAY-CARD8-WITH-TRANSFORM*/
static L65(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT67 VLEX67 CLSR67
	{volatile int V7;
	V7= fix(V4);
TTL:
	{volatile object V8;                      /*  DATA            */
	V8= (V3);
	{volatile object V9;                      /*  %BUFFER         */
	{volatile int V10;                        /*  BUFFER-BOFFSET  */
	volatile object V11;                      /*  BUFFER-BBUF     */
	V10= fix((V2));
	V11= ((V1))->in.in_slots[7];
	{volatile int V12;                        /*  INDEX           */
	volatile int V13;                         /*  LEN             */
	volatile int V14;                         /*  CHUNK           */
	V12= V7;
	V13= (fix((V5)))-(V7);
	{int V15= (fix(((V1))->in.in_slots[2]))-(V10);
	V14= (V13)<=(V15)?V13:V15;}
L875:
	if((V13)>0){
	goto L876;}
	goto L870;
L876:
	{volatile int V16;
	volatile int V17;                         /*  J               */
	V16= V14;
	V17= 0;
L883:
	if(!((V17)>=(V16))){
	goto L884;}
	goto L879;
L884:
	funcall(2,(V6),aref1((V8),V12));
	T0= VALUES(0);
	(((V11))->ust.ust_self[(V10)+(V17)]=(fix(T0)));
	V12= (V12)+(1);
	V17= (V17)+1;
	goto L883;
	}
L879:
	V10= (V10)+(V14);
	if(!((V13)>0)){
	goto L896;}
	if(!((V10)>=(fix(((V1))->in.in_slots[2])))){
	goto L896;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V10);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V10= fix(((V1))->in.in_slots[6]);
L896:
	V13= (V13)-(V14);
	{int V19= (fix(((V1))->in.in_slots[2]))-(V10);
	V14= (V13)<=(V19)?V13:V19;}
	goto L875;
	}
L870:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V10)+(3)) & (-4)));
	}
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-VECTOR-CARD8                    */
static L66(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT68 VLEX68 CLSR68
	{volatile int V6;
	V6= fix(V4);
TTL:
	{volatile object V7;                      /*  DATA            */
	V7= (V3);
	{volatile object V8;                      /*  %BUFFER         */
	{volatile int V9;                         /*  BUFFER-BOFFSET  */
	volatile object V10;                      /*  BUFFER-BBUF     */
	V9= fix((V2));
	V10= ((V1))->in.in_slots[7];
	{volatile int V11;                        /*  INDEX           */
	volatile int V12;                         /*  LEN             */
	volatile int V13;                         /*  CHUNK           */
	V11= V6;
	V12= (fix((V5)))-(V6);
	{int V14= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V14)?V12:V14;}
L920:
	if((V12)>0){
	goto L921;}
	goto L915;
L921:
	{volatile int V15;
	volatile int V16;                         /*  J               */
	V15= V13;
	V16= 0;
L928:
	if(!((V16)>=(V15))){
	goto L929;}
	goto L924;
L929:
	(((V10))->ust.ust_self[(V9)+(V16)]=(((V7))->ust.ust_self[V11]));
	V11= (V11)+(1);
	V16= (V16)+1;
	goto L928;
	}
L924:
	V9= (V9)+(V13);
	if(!((V12)>0)){
	goto L940;}
	if(!((V9)>=(fix(((V1))->in.in_slots[2])))){
	goto L940;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V9);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V9= fix(((V1))->in.in_slots[6]);
L940:
	V12= (V12)-(V13);
	{int V18= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V18)?V12:V18;}
	goto L920;
	}
L915:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V9)+(3)) & (-4)));
	}
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-VECTOR-CARD8-WITH-TRANSFORM     */
static L67(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT69 VLEX69 CLSR69
	{volatile int V7;
	V7= fix(V4);
TTL:
	{volatile object V8;                      /*  DATA            */
	V8= (V3);
	{volatile object V9;                      /*  %BUFFER         */
	{volatile int V10;                        /*  BUFFER-BOFFSET  */
	volatile object V11;                      /*  BUFFER-BBUF     */
	V10= fix((V2));
	V11= ((V1))->in.in_slots[7];
	{volatile int V12;                        /*  INDEX           */
	volatile int V13;                         /*  LEN             */
	volatile int V14;                         /*  CHUNK           */
	V12= V7;
	V13= (fix((V5)))-(V7);
	{int V15= (fix(((V1))->in.in_slots[2]))-(V10);
	V14= (V13)<=(V15)?V13:V15;}
L964:
	if((V13)>0){
	goto L965;}
	goto L959;
L965:
	{volatile int V16;
	volatile int V17;                         /*  J               */
	V16= V14;
	V17= 0;
L972:
	if(!((V17)>=(V16))){
	goto L973;}
	goto L968;
L973:
	funcall(2,(V6),aref1((V8),V12));
	T0= VALUES(0);
	(((V11))->ust.ust_self[(V10)+(V17)]=(fix(T0)));
	V12= (V12)+(1);
	V17= (V17)+1;
	goto L972;
	}
L968:
	V10= (V10)+(V14);
	if(!((V13)>0)){
	goto L985;}
	if(!((V10)>=(fix(((V1))->in.in_slots[2])))){
	goto L985;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V10);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V10= fix(((V1))->in.in_slots[6]);
L985:
	V13= (V13)-(V14);
	{int V19= (fix(((V1))->in.in_slots[2]))-(V10);
	V14= (V13)<=(V19)?V13:V19;}
	goto L964;
	}
L959:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V10)+(3)) & (-4)));
	}
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-SEQUENCE-CARD8                  */
static L68(int narg, object V1, object V2, object V3, ...)
{ VT70 VLEX70 CLSR70
	{register int V4;int i=3;
	register int V5;
	register int V6;
	register object V7;
	va_list args; va_start(args, V3);
	V4= fix(V2);
	if (i==narg) goto L998;
	V5= fix(va_arg(args, object));
	i++;
	if (i==narg) goto L999;
	V6= fix(va_arg(args, object));
	i++;
	if (i==narg) goto L1000;
	V7= va_arg(args, object);
	i++;
	goto L1001;
L998:
	V5= 0;
L999:
	V6= length((V3));
L1000:
	V7= Cnil;
L1001:
	{object V8;
	(*LK17)(2,(V3),VV[76])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1006;}
	if(((V7))==Cnil){
	goto L1009;}
	RETURN(L63(6,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),(V7))/*  WRITE-LIST-CARD8-WITH-TRANSFORM*/);
L1009:
	RETURN(L62(5,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6))/*  WRITE-LIST-CARD8*/);
L1006:
	(*LK17)(2,(V3),VV[77])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1012;}
	if(((V7))==Cnil){
	goto L1015;}
	RETURN(L65(6,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),(V7))/*  WRITE-SIMPLE-ARRAY-CARD8-WITH-TRANSFORM*/);
L1015:
	RETURN(L64(5,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6))/*  WRITE-SIMPLE-ARRAY-CARD8*/);
L1012:
	if(((V7))==Cnil){
	goto L1018;}
	RETURN(L67(6,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),(V7))/*  WRITE-VECTOR-CARD8-WITH-TRANSFORM*/);
L1018:
	RETURN(L66(5,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6))/*  WRITE-VECTOR-CARD8*/);
	}
	}
}
/*	function definition for WRITE-SEQUENCE-INT8                   */
static L69(int narg, object V1, object V2, object V3, ...)
{ VT71 VLEX71 CLSR71
	{int V4;int i=3;
	int V5;
	int V6;
	va_list args; va_start(args, V3);
	V4= fix(V2);
	if (i==narg) goto L1020;
	V5= fix(va_arg(args, object));
	i++;
	if (i==narg) goto L1021;
	V6= fix(va_arg(args, object));
	i++;
	if (i==narg) goto L1022;
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(va_arg(args, object),env0));/*  TRANSFORM */
	i++;
	goto L1023;
L1020:
	V5= 0;
L1021:
	V6= length((V3));
L1022:
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  TRANSFORM       */
L1023:
	if((*CLV0)==Cnil){
	goto L1028;}
	{ object V7;
	V7= make_cclosure(LC70,env0,&Cblock);
	RETURN(L68(6,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),(V7))/*  WRITE-SEQUENCE-CARD8*/);
	}
L1028:
	VALUES(0) = (VV[261]->s.s_gfdef);
	RETURN(L68(6,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),VALUES(0))/*  WRITE-SEQUENCE-CARD8*/);
	}
}
/*	closure TRANSFORM->INT8->CARD8                                */
static LC70(int narg, object env0, object V1)
{ VT72 VLEX72 CLSR72
	narg--;
	{object scan=env0;
	CLV0= &CAR(scan);                         /*  TRANSFORM       */}
TTL:
	funcall(2,*CLV0,(V1));
	VALUES(0) = MAKE_FIXNUM((fix(VALUES(0))));
	RETURN(1);
}
/*	function definition for WRITE-LIST-CARD16                     */
static L71(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT73 VLEX73 CLSR73
	{volatile int V6;
	V6= fix(V4);
TTL:
	{volatile object V7;                      /*  %BUFFER         */
	{volatile int V8;                         /*  BUFFER-BOFFSET  */
	volatile object V9;                       /*  BUFFER-BBUF     */
	V8= fix((V2));
	V9= ((V1))->in.in_slots[7];
	{volatile object V10;                     /*  LST             */
	volatile int V11;                         /*  LEN             */
	volatile int V12;                         /*  CHUNK           */
	V10= nthcdr(V6,(V3));
	V11= (((fix((V5)))-(V6)) << (1));
	{int V13= (fix(((V1))->in.in_slots[2]))-(V8);
	V12= (V11)<=(V13)?V11:V13;}
L1043:
	if((V11)>0){
	goto L1044;}
	goto L1038;
L1044:
	{volatile int V14;                        /*  J               */
	V14= 0;
L1050:
	if(!((V14)>=(V12))){
	goto L1051;}
	goto L1047;
L1051:
	{register object V16;
	V16= CAR((V10));
	V10= CDR((V10));
	T0= (V16);
	}
	((*(unsigned short *)(((V9))->ust.ust_self+((V8)+(V14))))=fix(T0));
	V14= (V14)+(2);
	goto L1050;
	}
L1047:
	V8= (V8)+(V12);
	if(!((V11)>0)){
	goto L1064;}
	if(!((V8)>=(fix(((V1))->in.in_slots[2])))){
	goto L1064;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V8);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V8= fix(((V1))->in.in_slots[6]);
L1064:
	V11= (V11)-(V12);
	{int V16= (fix(((V1))->in.in_slots[2]))-(V8);
	V12= (V11)<=(V16)?V11:V16;}
	goto L1043;
	}
L1038:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V8)+(3)) & (-4)));
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-LIST-CARD16-WITH-TRANSFORM      */
static L72(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT74 VLEX74 CLSR74
	{volatile int V7;
	V7= fix(V4);
TTL:
	{volatile object V8;                      /*  %BUFFER         */
	{volatile int V9;                         /*  BUFFER-BOFFSET  */
	volatile object V10;                      /*  BUFFER-BBUF     */
	V9= fix((V2));
	V10= ((V1))->in.in_slots[7];
	{volatile object V11;                     /*  LST             */
	volatile int V12;                         /*  LEN             */
	volatile int V13;                         /*  CHUNK           */
	V11= nthcdr(V7,(V3));
	V12= (((fix((V5)))-(V7)) << (1));
	{int V14= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V14)?V12:V14;}
L1088:
	if((V12)>0){
	goto L1089;}
	goto L1083;
L1089:
	{volatile int V15;                        /*  J               */
	V15= 0;
L1095:
	if(!((V15)>=(V13))){
	goto L1096;}
	goto L1092;
L1096:
	{register object V17;
	V17= CAR((V11));
	V11= CDR((V11));
	VALUES(0) = (V17);
	}
	funcall(2,(V6),VALUES(0));
	T0= VALUES(0);
	((*(unsigned short *)(((V10))->ust.ust_self+((V9)+(V15))))=fix(T0));
	V15= (V15)+(2);
	goto L1095;
	}
L1092:
	V9= (V9)+(V13);
	if(!((V12)>0)){
	goto L1110;}
	if(!((V9)>=(fix(((V1))->in.in_slots[2])))){
	goto L1110;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V9);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V9= fix(((V1))->in.in_slots[6]);
L1110:
	V12= (V12)-(V13);
	{int V17= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V17)?V12:V17;}
	goto L1088;
	}
L1083:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V9)+(3)) & (-4)));
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-SIMPLE-ARRAY-CARD16             */
static L73(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT75 VLEX75 CLSR75
	{volatile int V6;
	V6= fix(V4);
TTL:
	{volatile object V7;                      /*  DATA            */
	V7= (V3);
	{volatile object V8;                      /*  %BUFFER         */
	{volatile int V9;                         /*  BUFFER-BOFFSET  */
	volatile object V10;                      /*  BUFFER-BBUF     */
	V9= fix((V2));
	V10= ((V1))->in.in_slots[7];
	{volatile int V11;                        /*  INDEX           */
	volatile int V12;                         /*  LEN             */
	volatile int V13;                         /*  CHUNK           */
	V11= V6;
	V12= (((fix((V5)))-(V6)) << (1));
	{int V14= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V14)?V12:V14;}
L1134:
	if((V12)>0){
	goto L1135;}
	goto L1129;
L1135:
	{volatile int V15;                        /*  J               */
	V15= 0;
L1141:
	if(!((V15)>=(V13))){
	goto L1142;}
	goto L1138;
L1142:
	((*(unsigned short *)(((V10))->ust.ust_self+((V9)+(V15))))=((V7))->fixa.fixa_self[V11]);
	V11= (V11)+(1);
	V15= (V15)+(2);
	goto L1141;
	}
L1138:
	V9= (V9)+(V13);
	if(!((V12)>0)){
	goto L1153;}
	if(!((V9)>=(fix(((V1))->in.in_slots[2])))){
	goto L1153;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V9);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V9= fix(((V1))->in.in_slots[6]);
L1153:
	V12= (V12)-(V13);
	{int V17= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V17)?V12:V17;}
	goto L1134;
	}
L1129:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V9)+(3)) & (-4)));
	}
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-SIMPLE-ARRAY-CARD16-WITH-TRANSFORM*/
static L74(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT76 VLEX76 CLSR76
	{volatile int V7;
	V7= fix(V4);
TTL:
	{volatile object V8;                      /*  DATA            */
	V8= (V3);
	{volatile object V9;                      /*  %BUFFER         */
	{volatile int V10;                        /*  BUFFER-BOFFSET  */
	volatile object V11;                      /*  BUFFER-BBUF     */
	V10= fix((V2));
	V11= ((V1))->in.in_slots[7];
	{volatile int V12;                        /*  INDEX           */
	volatile int V13;                         /*  LEN             */
	volatile int V14;                         /*  CHUNK           */
	V12= V7;
	V13= (((fix((V5)))-(V7)) << (1));
	{int V15= (fix(((V1))->in.in_slots[2]))-(V10);
	V14= (V13)<=(V15)?V13:V15;}
L1177:
	if((V13)>0){
	goto L1178;}
	goto L1172;
L1178:
	{volatile int V16;                        /*  J               */
	V16= 0;
L1184:
	if(!((V16)>=(V14))){
	goto L1185;}
	goto L1181;
L1185:
	funcall(2,(V6),((V8))->v.v_self[V12]);
	T0= VALUES(0);
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(V16))))=fix(T0));
	V12= (V12)+(1);
	V16= (V16)+(2);
	goto L1184;
	}
L1181:
	V10= (V10)+(V14);
	if(!((V13)>0)){
	goto L1197;}
	if(!((V10)>=(fix(((V1))->in.in_slots[2])))){
	goto L1197;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V10);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V10= fix(((V1))->in.in_slots[6]);
L1197:
	V13= (V13)-(V14);
	{int V18= (fix(((V1))->in.in_slots[2]))-(V10);
	V14= (V13)<=(V18)?V13:V18;}
	goto L1177;
	}
L1172:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V10)+(3)) & (-4)));
	}
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-VECTOR-CARD16                   */
static L75(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT77 VLEX77 CLSR77
	{volatile int V6;
	V6= fix(V4);
TTL:
	{volatile object V7;                      /*  DATA            */
	V7= (V3);
	{volatile object V8;                      /*  %BUFFER         */
	{volatile int V9;                         /*  BUFFER-BOFFSET  */
	volatile object V10;                      /*  BUFFER-BBUF     */
	V9= fix((V2));
	V10= ((V1))->in.in_slots[7];
	{volatile int V11;                        /*  INDEX           */
	volatile int V12;                         /*  LEN             */
	volatile int V13;                         /*  CHUNK           */
	V11= V6;
	V12= (((fix((V5)))-(V6)) << (1));
	{int V14= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V14)?V12:V14;}
L1221:
	if((V12)>0){
	goto L1222;}
	goto L1216;
L1222:
	{volatile int V15;                        /*  J               */
	V15= 0;
L1228:
	if(!((V15)>=(V13))){
	goto L1229;}
	goto L1225;
L1229:
	((*(unsigned short *)(((V10))->ust.ust_self+((V9)+(V15))))=fix(((V7))->v.v_self[V11]));
	V11= (V11)+(1);
	V15= (V15)+(2);
	goto L1228;
	}
L1225:
	V9= (V9)+(V13);
	if(!((V12)>0)){
	goto L1240;}
	if(!((V9)>=(fix(((V1))->in.in_slots[2])))){
	goto L1240;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V9);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V9= fix(((V1))->in.in_slots[6]);
L1240:
	V12= (V12)-(V13);
	{int V17= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V17)?V12:V17;}
	goto L1221;
	}
L1216:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V9)+(3)) & (-4)));
	}
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-VECTOR-CARD16-WITH-TRANSFORM    */
static L76(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT78 VLEX78 CLSR78
	{volatile int V7;
	V7= fix(V4);
TTL:
	{volatile object V8;                      /*  DATA            */
	V8= (V3);
	{volatile object V9;                      /*  %BUFFER         */
	{volatile int V10;                        /*  BUFFER-BOFFSET  */
	volatile object V11;                      /*  BUFFER-BBUF     */
	V10= fix((V2));
	V11= ((V1))->in.in_slots[7];
	{volatile int V12;                        /*  INDEX           */
	volatile int V13;                         /*  LEN             */
	volatile int V14;                         /*  CHUNK           */
	V12= V7;
	V13= (((fix((V5)))-(V7)) << (1));
	{int V15= (fix(((V1))->in.in_slots[2]))-(V10);
	V14= (V13)<=(V15)?V13:V15;}
L1264:
	if((V13)>0){
	goto L1265;}
	goto L1259;
L1265:
	{volatile int V16;                        /*  J               */
	V16= 0;
L1271:
	if(!((V16)>=(V14))){
	goto L1272;}
	goto L1268;
L1272:
	funcall(2,(V6),((V8))->v.v_self[V12]);
	T0= VALUES(0);
	((*(unsigned short *)(((V11))->ust.ust_self+((V10)+(V16))))=fix(T0));
	V12= (V12)+(1);
	V16= (V16)+(2);
	goto L1271;
	}
L1268:
	V10= (V10)+(V14);
	if(!((V13)>0)){
	goto L1284;}
	if(!((V10)>=(fix(((V1))->in.in_slots[2])))){
	goto L1284;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V10);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V10= fix(((V1))->in.in_slots[6]);
L1284:
	V13= (V13)-(V14);
	{int V18= (fix(((V1))->in.in_slots[2]))-(V10);
	V14= (V13)<=(V18)?V13:V18;}
	goto L1264;
	}
L1259:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V10)+(3)) & (-4)));
	}
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-SEQUENCE-CARD16                 */
static L77(int narg, object V1, object V2, object V3, ...)
{ VT79 VLEX79 CLSR79
	{register int V4;int i=3;
	register int V5;
	register int V6;
	register object V7;
	va_list args; va_start(args, V3);
	V4= fix(V2);
	if (i==narg) goto L1297;
	V5= fix(va_arg(args, object));
	i++;
	if (i==narg) goto L1298;
	V6= fix(va_arg(args, object));
	i++;
	if (i==narg) goto L1299;
	V7= va_arg(args, object);
	i++;
	goto L1300;
L1297:
	V5= 0;
L1298:
	V6= length((V3));
L1299:
	V7= Cnil;
L1300:
	{object V8;
	(*LK17)(2,(V3),VV[76])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1305;}
	if(((V7))==Cnil){
	goto L1308;}
	RETURN(L72(6,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),(V7))/*  WRITE-LIST-CARD16-WITH-TRANSFORM*/);
L1308:
	RETURN(L71(5,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6))/*  WRITE-LIST-CARD16*/);
L1305:
	(*LK17)(2,(V3),VV[80])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1311;}
	if(((V7))==Cnil){
	goto L1314;}
	RETURN(L74(6,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),(V7))/*  WRITE-SIMPLE-ARRAY-CARD16-WITH-TRANSFORM*/);
L1314:
	RETURN(L73(5,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6))/*  WRITE-SIMPLE-ARRAY-CARD16*/);
L1311:
	if(((V7))==Cnil){
	goto L1317;}
	RETURN(L76(6,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),(V7))/*  WRITE-VECTOR-CARD16-WITH-TRANSFORM*/);
L1317:
	RETURN(L75(5,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6))/*  WRITE-VECTOR-CARD16*/);
	}
	}
}
/*	function definition for WRITE-LIST-INT16                      */
static L78(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT80 VLEX80 CLSR80
	{volatile int V6;
	V6= fix(V4);
TTL:
	{volatile object V7;                      /*  %BUFFER         */
	{volatile int V8;                         /*  BUFFER-BOFFSET  */
	volatile object V9;                       /*  BUFFER-BBUF     */
	V8= fix((V2));
	V9= ((V1))->in.in_slots[7];
	{volatile object V10;                     /*  LST             */
	volatile int V11;                         /*  LEN             */
	volatile int V12;                         /*  CHUNK           */
	V10= nthcdr(V6,(V3));
	V11= (((fix((V5)))-(V6)) << (1));
	{int V13= (fix(((V1))->in.in_slots[2]))-(V8);
	V12= (V11)<=(V13)?V11:V13;}
L1330:
	if((V11)>0){
	goto L1331;}
	goto L1325;
L1331:
	{volatile int V14;                        /*  J               */
	V14= 0;
L1337:
	if(!((V14)>=(V12))){
	goto L1338;}
	goto L1334;
L1338:
	{register object V16;
	V16= CAR((V10));
	V10= CDR((V10));
	T0= (V16);
	}
	((*(short *)(((V9))->st.st_self+((V8)+(V14))))=fix(T0));
	V14= (V14)+(2);
	goto L1337;
	}
L1334:
	V8= (V8)+(V12);
	if(!((V11)>0)){
	goto L1351;}
	if(!((V8)>=(fix(((V1))->in.in_slots[2])))){
	goto L1351;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V8);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V8= fix(((V1))->in.in_slots[6]);
L1351:
	V11= (V11)-(V12);
	{int V16= (fix(((V1))->in.in_slots[2]))-(V8);
	V12= (V11)<=(V16)?V11:V16;}
	goto L1330;
	}
L1325:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V8)+(3)) & (-4)));
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-LIST-INT16-WITH-TRANSFORM       */
static L79(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT81 VLEX81 CLSR81
	{volatile int V7;
	V7= fix(V4);
TTL:
	{volatile object V8;                      /*  %BUFFER         */
	{volatile int V9;                         /*  BUFFER-BOFFSET  */
	volatile object V10;                      /*  BUFFER-BBUF     */
	V9= fix((V2));
	V10= ((V1))->in.in_slots[7];
	{volatile object V11;                     /*  LST             */
	volatile int V12;                         /*  LEN             */
	volatile int V13;                         /*  CHUNK           */
	V11= nthcdr(V7,(V3));
	V12= (((fix((V5)))-(V7)) << (1));
	{int V14= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V14)?V12:V14;}
L1375:
	if((V12)>0){
	goto L1376;}
	goto L1370;
L1376:
	{volatile int V15;                        /*  J               */
	V15= 0;
L1382:
	if(!((V15)>=(V13))){
	goto L1383;}
	goto L1379;
L1383:
	{register object V17;
	V17= CAR((V11));
	V11= CDR((V11));
	VALUES(0) = (V17);
	}
	funcall(2,(V6),VALUES(0));
	T0= VALUES(0);
	((*(short *)(((V10))->st.st_self+((V9)+(V15))))=fix(T0));
	V15= (V15)+(2);
	goto L1382;
	}
L1379:
	V9= (V9)+(V13);
	if(!((V12)>0)){
	goto L1397;}
	if(!((V9)>=(fix(((V1))->in.in_slots[2])))){
	goto L1397;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V9);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V9= fix(((V1))->in.in_slots[6]);
L1397:
	V12= (V12)-(V13);
	{int V17= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V17)?V12:V17;}
	goto L1375;
	}
L1370:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V9)+(3)) & (-4)));
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-SIMPLE-ARRAY-INT16              */
static L80(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT82 VLEX82 CLSR82
	{volatile int V6;
	V6= fix(V4);
TTL:
	{volatile object V7;                      /*  DATA            */
	V7= (V3);
	{volatile object V8;                      /*  %BUFFER         */
	{volatile int V9;                         /*  BUFFER-BOFFSET  */
	volatile object V10;                      /*  BUFFER-BBUF     */
	V9= fix((V2));
	V10= ((V1))->in.in_slots[7];
	{volatile int V11;                        /*  INDEX           */
	volatile int V12;                         /*  LEN             */
	volatile int V13;                         /*  CHUNK           */
	V11= V6;
	V12= (((fix((V5)))-(V6)) << (1));
	{int V14= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V14)?V12:V14;}
L1421:
	if((V12)>0){
	goto L1422;}
	goto L1416;
L1422:
	{volatile int V15;                        /*  J               */
	V15= 0;
L1428:
	if(!((V15)>=(V13))){
	goto L1429;}
	goto L1425;
L1429:
	((*(short *)(((V10))->st.st_self+((V9)+(V15))))=((V7))->fixa.fixa_self[V11]);
	V11= (V11)+(1);
	V15= (V15)+(2);
	goto L1428;
	}
L1425:
	V9= (V9)+(V13);
	if(!((V12)>0)){
	goto L1440;}
	if(!((V9)>=(fix(((V1))->in.in_slots[2])))){
	goto L1440;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V9);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V9= fix(((V1))->in.in_slots[6]);
L1440:
	V12= (V12)-(V13);
	{int V17= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V17)?V12:V17;}
	goto L1421;
	}
L1416:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V9)+(3)) & (-4)));
	}
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-SIMPLE-ARRAY-INT16-WITH-TRANSFORM*/
static L81(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT83 VLEX83 CLSR83
	{volatile int V7;
	V7= fix(V4);
TTL:
	{volatile object V8;                      /*  DATA            */
	V8= (V3);
	{volatile object V9;                      /*  %BUFFER         */
	{volatile int V10;                        /*  BUFFER-BOFFSET  */
	volatile object V11;                      /*  BUFFER-BBUF     */
	V10= fix((V2));
	V11= ((V1))->in.in_slots[7];
	{volatile int V12;                        /*  INDEX           */
	volatile int V13;                         /*  LEN             */
	volatile int V14;                         /*  CHUNK           */
	V12= V7;
	V13= (((fix((V5)))-(V7)) << (1));
	{int V15= (fix(((V1))->in.in_slots[2]))-(V10);
	V14= (V13)<=(V15)?V13:V15;}
L1464:
	if((V13)>0){
	goto L1465;}
	goto L1459;
L1465:
	{volatile int V16;                        /*  J               */
	V16= 0;
L1471:
	if(!((V16)>=(V14))){
	goto L1472;}
	goto L1468;
L1472:
	funcall(2,(V6),((V8))->v.v_self[V12]);
	T0= VALUES(0);
	((*(short *)(((V11))->st.st_self+((V10)+(V16))))=fix(T0));
	V12= (V12)+(1);
	V16= (V16)+(2);
	goto L1471;
	}
L1468:
	V10= (V10)+(V14);
	if(!((V13)>0)){
	goto L1484;}
	if(!((V10)>=(fix(((V1))->in.in_slots[2])))){
	goto L1484;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V10);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V10= fix(((V1))->in.in_slots[6]);
L1484:
	V13= (V13)-(V14);
	{int V18= (fix(((V1))->in.in_slots[2]))-(V10);
	V14= (V13)<=(V18)?V13:V18;}
	goto L1464;
	}
L1459:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V10)+(3)) & (-4)));
	}
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-VECTOR-INT16                    */
static L82(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT84 VLEX84 CLSR84
	{volatile int V6;
	V6= fix(V4);
TTL:
	{volatile object V7;                      /*  DATA            */
	V7= (V3);
	{volatile object V8;                      /*  %BUFFER         */
	{volatile int V9;                         /*  BUFFER-BOFFSET  */
	volatile object V10;                      /*  BUFFER-BBUF     */
	V9= fix((V2));
	V10= ((V1))->in.in_slots[7];
	{volatile int V11;                        /*  INDEX           */
	volatile int V12;                         /*  LEN             */
	volatile int V13;                         /*  CHUNK           */
	V11= V6;
	V12= (((fix((V5)))-(V6)) << (1));
	{int V14= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V14)?V12:V14;}
L1508:
	if((V12)>0){
	goto L1509;}
	goto L1503;
L1509:
	{volatile int V15;                        /*  J               */
	V15= 0;
L1515:
	if(!((V15)>=(V13))){
	goto L1516;}
	goto L1512;
L1516:
	((*(short *)(((V10))->st.st_self+((V9)+(V15))))=fix(((V7))->v.v_self[V11]));
	V11= (V11)+(1);
	V15= (V15)+(2);
	goto L1515;
	}
L1512:
	V9= (V9)+(V13);
	if(!((V12)>0)){
	goto L1527;}
	if(!((V9)>=(fix(((V1))->in.in_slots[2])))){
	goto L1527;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V9);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V9= fix(((V1))->in.in_slots[6]);
L1527:
	V12= (V12)-(V13);
	{int V17= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V17)?V12:V17;}
	goto L1508;
	}
L1503:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V9)+(3)) & (-4)));
	}
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-VECTOR-INT16-WITH-TRANSFORM     */
static L83(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT85 VLEX85 CLSR85
	{volatile int V7;
	V7= fix(V4);
TTL:
	{volatile object V8;                      /*  DATA            */
	V8= (V3);
	{volatile object V9;                      /*  %BUFFER         */
	{volatile int V10;                        /*  BUFFER-BOFFSET  */
	volatile object V11;                      /*  BUFFER-BBUF     */
	V10= fix((V2));
	V11= ((V1))->in.in_slots[7];
	{volatile int V12;                        /*  INDEX           */
	volatile int V13;                         /*  LEN             */
	volatile int V14;                         /*  CHUNK           */
	V12= V7;
	V13= (((fix((V5)))-(V7)) << (1));
	{int V15= (fix(((V1))->in.in_slots[2]))-(V10);
	V14= (V13)<=(V15)?V13:V15;}
L1551:
	if((V13)>0){
	goto L1552;}
	goto L1546;
L1552:
	{volatile int V16;                        /*  J               */
	V16= 0;
L1558:
	if(!((V16)>=(V14))){
	goto L1559;}
	goto L1555;
L1559:
	funcall(2,(V6),((V8))->v.v_self[V12]);
	T0= VALUES(0);
	((*(short *)(((V11))->st.st_self+((V10)+(V16))))=fix(T0));
	V12= (V12)+(1);
	V16= (V16)+(2);
	goto L1558;
	}
L1555:
	V10= (V10)+(V14);
	if(!((V13)>0)){
	goto L1571;}
	if(!((V10)>=(fix(((V1))->in.in_slots[2])))){
	goto L1571;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V10);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V10= fix(((V1))->in.in_slots[6]);
L1571:
	V13= (V13)-(V14);
	{int V18= (fix(((V1))->in.in_slots[2]))-(V10);
	V14= (V13)<=(V18)?V13:V18;}
	goto L1551;
	}
L1546:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V10)+(3)) & (-4)));
	}
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-SEQUENCE-INT16                  */
static L84(int narg, object V1, object V2, object V3, ...)
{ VT86 VLEX86 CLSR86
	{register int V4;int i=3;
	register int V5;
	register int V6;
	register object V7;
	va_list args; va_start(args, V3);
	V4= fix(V2);
	if (i==narg) goto L1584;
	V5= fix(va_arg(args, object));
	i++;
	if (i==narg) goto L1585;
	V6= fix(va_arg(args, object));
	i++;
	if (i==narg) goto L1586;
	V7= va_arg(args, object);
	i++;
	goto L1587;
L1584:
	V5= 0;
L1585:
	V6= length((V3));
L1586:
	V7= Cnil;
L1587:
	{object V8;
	(*LK17)(2,(V3),VV[76])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1592;}
	if(((V7))==Cnil){
	goto L1595;}
	RETURN(L79(6,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),(V7))/*  WRITE-LIST-INT16-WITH-TRANSFORM*/);
L1595:
	RETURN(L78(5,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6))/*  WRITE-LIST-INT16*/);
L1592:
	(*LK17)(2,(V3),VV[81])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1598;}
	if(((V7))==Cnil){
	goto L1601;}
	RETURN(L81(6,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),(V7))/*  WRITE-SIMPLE-ARRAY-INT16-WITH-TRANSFORM*/);
L1601:
	RETURN(L80(5,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6))/*  WRITE-SIMPLE-ARRAY-INT16*/);
L1598:
	if(((V7))==Cnil){
	goto L1604;}
	RETURN(L83(6,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),(V7))/*  WRITE-VECTOR-INT16-WITH-TRANSFORM*/);
L1604:
	RETURN(L82(5,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6))/*  WRITE-VECTOR-INT16*/);
	}
	}
}
/*	function definition for WRITE-LIST-CARD32                     */
static L85(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT87 VLEX87 CLSR87
	{volatile int V6;
	V6= fix(V4);
TTL:
	{volatile object V7;                      /*  %BUFFER         */
	{volatile int V8;                         /*  BUFFER-BOFFSET  */
	volatile object V9;                       /*  BUFFER-BBUF     */
	V8= fix((V2));
	V9= ((V1))->in.in_slots[7];
	{volatile object V10;                     /*  LST             */
	volatile int V11;                         /*  LEN             */
	volatile int V12;                         /*  CHUNK           */
	V10= nthcdr(V6,(V3));
	V11= (((fix((V5)))-(V6)) << (2));
	{int V13= (fix(((V1))->in.in_slots[2]))-(V8);
	V12= (V11)<=(V13)?V11:V13;}
L1617:
	if((V11)>0){
	goto L1618;}
	goto L1612;
L1618:
	{volatile int V14;                        /*  J               */
	V14= 0;
L1624:
	if(!((V14)>=(V12))){
	goto L1625;}
	goto L1621;
L1625:
	{register object V16;
	V16= CAR((V10));
	V10= CDR((V10));
	T0= (V16);
	}
	((*(unsigned long *)(((V9))->ust.ust_self+((V8)+(V14))))=fix(T0));
	V14= (V14)+(4);
	goto L1624;
	}
L1621:
	V8= (V8)+(V12);
	if(!((V11)>0)){
	goto L1638;}
	if(!((V8)>=(fix(((V1))->in.in_slots[2])))){
	goto L1638;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V8);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V8= fix(((V1))->in.in_slots[6]);
L1638:
	V11= (V11)-(V12);
	{int V16= (fix(((V1))->in.in_slots[2]))-(V8);
	V12= (V11)<=(V16)?V11:V16;}
	goto L1617;
	}
L1612:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V8)+(3)) & (-4)));
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-LIST-CARD32-WITH-TRANSFORM      */
static L86(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT88 VLEX88 CLSR88
	{volatile int V7;
	V7= fix(V4);
TTL:
	{volatile object V8;                      /*  %BUFFER         */
	{volatile int V9;                         /*  BUFFER-BOFFSET  */
	volatile object V10;                      /*  BUFFER-BBUF     */
	V9= fix((V2));
	V10= ((V1))->in.in_slots[7];
	{volatile object V11;                     /*  LST             */
	volatile int V12;                         /*  LEN             */
	volatile int V13;                         /*  CHUNK           */
	V11= nthcdr(V7,(V3));
	V12= (((fix((V5)))-(V7)) << (2));
	{int V14= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V14)?V12:V14;}
L1662:
	if((V12)>0){
	goto L1663;}
	goto L1657;
L1663:
	{volatile int V15;                        /*  J               */
	V15= 0;
L1669:
	if(!((V15)>=(V13))){
	goto L1670;}
	goto L1666;
L1670:
	{register object V17;
	V17= CAR((V11));
	V11= CDR((V11));
	VALUES(0) = (V17);
	}
	funcall(2,(V6),VALUES(0));
	T0= VALUES(0);
	((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(V15))))=fix(T0));
	V15= (V15)+(4);
	goto L1669;
	}
L1666:
	V9= (V9)+(V13);
	if(!((V12)>0)){
	goto L1684;}
	if(!((V9)>=(fix(((V1))->in.in_slots[2])))){
	goto L1684;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V9);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V9= fix(((V1))->in.in_slots[6]);
L1684:
	V12= (V12)-(V13);
	{int V17= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V17)?V12:V17;}
	goto L1662;
	}
L1657:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V9)+(3)) & (-4)));
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-SIMPLE-ARRAY-CARD32             */
static L87(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT89 VLEX89 CLSR89
	{volatile int V6;
	V6= fix(V4);
TTL:
	{volatile object V7;                      /*  DATA            */
	V7= (V3);
	{volatile object V8;                      /*  %BUFFER         */
	{volatile int V9;                         /*  BUFFER-BOFFSET  */
	volatile object V10;                      /*  BUFFER-BBUF     */
	V9= fix((V2));
	V10= ((V1))->in.in_slots[7];
	{volatile int V11;                        /*  INDEX           */
	volatile int V12;                         /*  LEN             */
	volatile int V13;                         /*  CHUNK           */
	V11= V6;
	V12= (((fix((V5)))-(V6)) << (2));
	{int V14= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V14)?V12:V14;}
L1708:
	if((V12)>0){
	goto L1709;}
	goto L1703;
L1709:
	{volatile int V15;                        /*  J               */
	V15= 0;
L1715:
	if(!((V15)>=(V13))){
	goto L1716;}
	goto L1712;
L1716:
	((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(V15))))=fix(((V7))->v.v_self[V11]));
	V11= (V11)+(1);
	V15= (V15)+(4);
	goto L1715;
	}
L1712:
	V9= (V9)+(V13);
	if(!((V12)>0)){
	goto L1727;}
	if(!((V9)>=(fix(((V1))->in.in_slots[2])))){
	goto L1727;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V9);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V9= fix(((V1))->in.in_slots[6]);
L1727:
	V12= (V12)-(V13);
	{int V17= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V17)?V12:V17;}
	goto L1708;
	}
L1703:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V9)+(3)) & (-4)));
	}
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-SIMPLE-ARRAY-CARD32-WITH-TRANSFORM*/
static L88(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT90 VLEX90 CLSR90
	{volatile int V7;
	V7= fix(V4);
TTL:
	{volatile object V8;                      /*  DATA            */
	V8= (V3);
	{volatile object V9;                      /*  %BUFFER         */
	{volatile int V10;                        /*  BUFFER-BOFFSET  */
	volatile object V11;                      /*  BUFFER-BBUF     */
	V10= fix((V2));
	V11= ((V1))->in.in_slots[7];
	{volatile int V12;                        /*  INDEX           */
	volatile int V13;                         /*  LEN             */
	volatile int V14;                         /*  CHUNK           */
	V12= V7;
	V13= (((fix((V5)))-(V7)) << (2));
	{int V15= (fix(((V1))->in.in_slots[2]))-(V10);
	V14= (V13)<=(V15)?V13:V15;}
L1751:
	if((V13)>0){
	goto L1752;}
	goto L1746;
L1752:
	{volatile int V16;                        /*  J               */
	V16= 0;
L1758:
	if(!((V16)>=(V14))){
	goto L1759;}
	goto L1755;
L1759:
	funcall(2,(V6),((V8))->v.v_self[V12]);
	T0= VALUES(0);
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(V16))))=fix(T0));
	V12= (V12)+(1);
	V16= (V16)+(4);
	goto L1758;
	}
L1755:
	V10= (V10)+(V14);
	if(!((V13)>0)){
	goto L1771;}
	if(!((V10)>=(fix(((V1))->in.in_slots[2])))){
	goto L1771;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V10);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V10= fix(((V1))->in.in_slots[6]);
L1771:
	V13= (V13)-(V14);
	{int V18= (fix(((V1))->in.in_slots[2]))-(V10);
	V14= (V13)<=(V18)?V13:V18;}
	goto L1751;
	}
L1746:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V10)+(3)) & (-4)));
	}
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-VECTOR-CARD32                   */
static L89(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT91 VLEX91 CLSR91
	{volatile int V6;
	V6= fix(V4);
TTL:
	{volatile object V7;                      /*  DATA            */
	V7= (V3);
	{volatile object V8;                      /*  %BUFFER         */
	{volatile int V9;                         /*  BUFFER-BOFFSET  */
	volatile object V10;                      /*  BUFFER-BBUF     */
	V9= fix((V2));
	V10= ((V1))->in.in_slots[7];
	{volatile int V11;                        /*  INDEX           */
	volatile int V12;                         /*  LEN             */
	volatile int V13;                         /*  CHUNK           */
	V11= V6;
	V12= (((fix((V5)))-(V6)) << (2));
	{int V14= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V14)?V12:V14;}
L1795:
	if((V12)>0){
	goto L1796;}
	goto L1790;
L1796:
	{volatile int V15;                        /*  J               */
	V15= 0;
L1802:
	if(!((V15)>=(V13))){
	goto L1803;}
	goto L1799;
L1803:
	((*(unsigned long *)(((V10))->ust.ust_self+((V9)+(V15))))=fix(((V7))->v.v_self[V11]));
	V11= (V11)+(1);
	V15= (V15)+(4);
	goto L1802;
	}
L1799:
	V9= (V9)+(V13);
	if(!((V12)>0)){
	goto L1814;}
	if(!((V9)>=(fix(((V1))->in.in_slots[2])))){
	goto L1814;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V9);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V9= fix(((V1))->in.in_slots[6]);
L1814:
	V12= (V12)-(V13);
	{int V17= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V17)?V12:V17;}
	goto L1795;
	}
L1790:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V9)+(3)) & (-4)));
	}
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-VECTOR-CARD32-WITH-TRANSFORM    */
static L90(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT92 VLEX92 CLSR92
	{volatile int V7;
	V7= fix(V4);
TTL:
	{volatile object V8;                      /*  DATA            */
	V8= (V3);
	{volatile object V9;                      /*  %BUFFER         */
	{volatile int V10;                        /*  BUFFER-BOFFSET  */
	volatile object V11;                      /*  BUFFER-BBUF     */
	V10= fix((V2));
	V11= ((V1))->in.in_slots[7];
	{volatile int V12;                        /*  INDEX           */
	volatile int V13;                         /*  LEN             */
	volatile int V14;                         /*  CHUNK           */
	V12= V7;
	V13= (((fix((V5)))-(V7)) << (2));
	{int V15= (fix(((V1))->in.in_slots[2]))-(V10);
	V14= (V13)<=(V15)?V13:V15;}
L1838:
	if((V13)>0){
	goto L1839;}
	goto L1833;
L1839:
	{volatile int V16;                        /*  J               */
	V16= 0;
L1845:
	if(!((V16)>=(V14))){
	goto L1846;}
	goto L1842;
L1846:
	funcall(2,(V6),((V8))->v.v_self[V12]);
	T0= VALUES(0);
	((*(unsigned long *)(((V11))->ust.ust_self+((V10)+(V16))))=fix(T0));
	V12= (V12)+(1);
	V16= (V16)+(4);
	goto L1845;
	}
L1842:
	V10= (V10)+(V14);
	if(!((V13)>0)){
	goto L1858;}
	if(!((V10)>=(fix(((V1))->in.in_slots[2])))){
	goto L1858;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V10);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V10= fix(((V1))->in.in_slots[6]);
L1858:
	V13= (V13)-(V14);
	{int V18= (fix(((V1))->in.in_slots[2]))-(V10);
	V14= (V13)<=(V18)?V13:V18;}
	goto L1838;
	}
L1833:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V10)+(3)) & (-4)));
	}
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-SEQUENCE-CARD32                 */
static L91(int narg, object V1, object V2, object V3, ...)
{ VT93 VLEX93 CLSR93
	{register int V4;int i=3;
	register int V5;
	register int V6;
	register object V7;
	va_list args; va_start(args, V3);
	V4= fix(V2);
	if (i==narg) goto L1871;
	V5= fix(va_arg(args, object));
	i++;
	if (i==narg) goto L1872;
	V6= fix(va_arg(args, object));
	i++;
	if (i==narg) goto L1873;
	V7= va_arg(args, object);
	i++;
	goto L1874;
L1871:
	V5= 0;
L1872:
	V6= length((V3));
L1873:
	V7= Cnil;
L1874:
	{object V8;
	(*LK17)(2,(V3),VV[76])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1879;}
	if(((V7))==Cnil){
	goto L1882;}
	RETURN(L86(6,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),(V7))/*  WRITE-LIST-CARD32-WITH-TRANSFORM*/);
L1882:
	RETURN(L85(5,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6))/*  WRITE-LIST-CARD32*/);
L1879:
	(*LK17)(2,(V3),VV[82])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L1885;}
	if(((V7))==Cnil){
	goto L1888;}
	RETURN(L88(6,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),(V7))/*  WRITE-SIMPLE-ARRAY-CARD32-WITH-TRANSFORM*/);
L1888:
	RETURN(L87(5,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6))/*  WRITE-SIMPLE-ARRAY-CARD32*/);
L1885:
	if(((V7))==Cnil){
	goto L1891;}
	RETURN(L90(6,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),(V7))/*  WRITE-VECTOR-CARD32-WITH-TRANSFORM*/);
L1891:
	RETURN(L89(5,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6))/*  WRITE-VECTOR-CARD32*/);
	}
	}
}
/*	function definition for WRITE-SEQUENCE-INT32                  */
static L92(int narg, object V1, object V2, object V3, ...)
{ VT94 VLEX94 CLSR94
	{int V4;int i=3;
	int V5;
	int V6;
	va_list args; va_start(args, V3);
	V4= fix(V2);
	if (i==narg) goto L1893;
	V5= fix(va_arg(args, object));
	i++;
	if (i==narg) goto L1894;
	V6= fix(va_arg(args, object));
	i++;
	if (i==narg) goto L1895;
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(va_arg(args, object),env0));/*  TRANSFORM */
	i++;
	goto L1896;
L1893:
	V5= 0;
L1894:
	V6= length((V3));
L1895:
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(Cnil,env0));          /*  TRANSFORM       */
L1896:
	if((*CLV0)==Cnil){
	goto L1901;}
	{ object V7;
	V7= make_cclosure(LC93,env0,&Cblock);
	RETURN(L91(6,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),(V7))/*  WRITE-SEQUENCE-CARD32*/);
	}
L1901:
	VALUES(0) = (VV[284]->s.s_gfdef);
	RETURN(L91(6,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),VALUES(0))/*  WRITE-SEQUENCE-CARD32*/);
	}
}
/*	closure TRANSFORM->INT32->CARD32                              */
static LC93(int narg, object env0, object V1)
{ VT95 VLEX95 CLSR95
	narg--;
	{object scan=env0;
	CLV0= &CAR(scan);                         /*  TRANSFORM       */}
TTL:
	funcall(2,*CLV0,(V1));
	VALUES(0) = MAKE_FIXNUM((fix(VALUES(0))));
	RETURN(1);
}
/*	function definition for READ-BITVECTOR256                     */
static L94(int narg, object V1, object V2, object V3)
{ VT96 VLEX96 CLSR96
TTL:
	{volatile object V4;                      /*  RESULT          */
	if((V3)!=Cnil){
	V4= (V3);
	goto L1905;}
	(*LK3)(5,MAKE_FIXNUM(256),VV[50],VV[83],VV[52],MAKE_FIXNUM(0))/*  MAKE-ARRAY*/;
	V4= VALUES(0);
L1905:
	{volatile int V5;                         /*  I               */
	volatile int V6;                          /*  J               */
	V5= (fix((V2)))+(1);
	V6= 8;
L1910:
	if(!((V6)>=(256))){
	goto L1911;}
	goto L1906;
L1911:
	{volatile int V8;                         /*  BYTE            */
	volatile int V9;                          /*  K               */
	V8= ((V1))->ust.ust_self[V5];
	V9= V6;
L1918:
	if(!((V8)==0)){
	goto L1919;}
	if(((V3))==Cnil){
	goto L1914;}
	{volatile int V11;                        /*  END             */
	V11= (V6)+(8);
L1926:
	if(!((V9)==(V11))){
	goto L1927;}
	goto L1914;
L1927:
	aset1((V4),V9,MAKE_FIXNUM(0));
	V9= (V9)+(1);
	goto L1926;
	}
L1919:
	aset1((V4),V9,MAKE_FIXNUM(((V8) & (1))));
	V8= ((V8) >> (- (-1)));
	V9= (V9)+(1);
	goto L1918;
	}
L1914:
	V5= (V5)+(1);
	V6= (V6)+(8);
	goto L1910;
	}
L1906:
	VALUES(0) = (V4);
	RETURN(1);
	}
}
/*	function definition for WRITE-BITVECTOR256                    */
static L95(int narg, object V1, object V2, object V3)
{ VT97 VLEX97 CLSR97
TTL:
	{volatile object V4;                      /*  %BUFFER         */
	{volatile int V5;                         /*  BUFFER-BOFFSET  */
	volatile object V6;                       /*  BUFFER-BBUF     */
	V5= fix((V2));
	V6= ((V1))->in.in_slots[7];
	{volatile int V7;                         /*  I               */
	volatile int V8;                          /*  J               */
	V7= (V5)+(1);
	V8= 8;
L1952:
	if(!((V8)>=(256))){
	goto L1953;}
	VALUES(0) = Cnil;
	RETURN(1);
L1953:
	{volatile int V10;                        /*  BYTE            */
	volatile int V11;                         /*  BIT             */
	V10= 0;
	V11= (V8)+(7);
L1960:
	if(!((V11)<(V8))){
	goto L1961;}
	(((V6))->ust.ust_self[V7]=(V10));
	goto L1956;
L1961:
	{int V13= ((V10) << (1));
	Llogior(2,MAKE_FIXNUM(V13),aref1((V3),V11))/*  LOGIOR         */;
	V10= fix(VALUES(0));}
	V11= (V11)-(1);
	goto L1960;
	}
L1956:
	V7= (V7)+(1);
	V8= (V8)+(8);
	goto L1952;
	}
	}
	}
}
/*	function definition for WRITE-LIST-CHAR2B                     */
static L96(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT98 VLEX98 CLSR98
	{volatile int V6;
	V6= fix(V4);
TTL:
	{volatile object V7;                      /*  %BUFFER         */
	{volatile int V8;                         /*  BUFFER-BOFFSET  */
	volatile object V9;                       /*  BUFFER-BBUF     */
	V8= fix((V2));
	V9= ((V1))->in.in_slots[7];
	{volatile object V10;                     /*  LST             */
	volatile int V11;                         /*  LEN             */
	volatile int V12;                         /*  CHUNK           */
	V10= nthcdr(V6,(V3));
	V11= (((fix((V5)))-(V6)) << (1));
	{int V13= (fix(((V1))->in.in_slots[2]))-(V8);
	V12= (V11)<=(V13)?V11:V13;}
L1985:
	if((V11)>0){
	goto L1986;}
	goto L1980;
L1986:
	{volatile int V14;                        /*  J               */
	V14= 0;
L1992:
	if(!((V14)>=((V12)-1))){
	goto L1993;}
	V12= V14;
	goto L1989;
L1993:
	{register int V16;                        /*  %ITEM           */
	register int V17;                         /*  %BYTE-INDEX     */
	{register object V18;
	V18= CAR((V10));
	V10= CDR((V10));
	V16= fix((V18));
	}
	V17= (V8)+(V14);
	(((V9))->ust.ust_self[V17]=(((((~(-1 << (8))) << (8)) & (V16)) >> (8))));
	(((V9))->ust.ust_self[(V17)+(1)]=(((((~(-1 << (8))) << (0)) & (V16)) >> (0))));
	}
	V14= (V14)+(2);
	goto L1992;
	}
L1989:
	V8= (V8)+(V12);
	if(!((V11)>0)){
	goto L2009;}
	if(!((V8)>=(fix(((V1))->in.in_slots[2])))){
	goto L2009;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V8);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V8= fix(((V1))->in.in_slots[6]);
L2009:
	V11= (V11)-(V12);
	{int V18= (fix(((V1))->in.in_slots[2]))-(V8);
	V12= (V11)<=(V18)?V11:V18;}
	goto L1985;
	}
L1980:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V8)+(3)) & (-4)));
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-LIST-CHAR2B-WITH-TRANSFORM      */
static L97(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT99 VLEX99 CLSR99
	{volatile int V7;
	V7= fix(V4);
TTL:
	{volatile object V8;                      /*  %BUFFER         */
	{volatile int V9;                         /*  BUFFER-BOFFSET  */
	volatile object V10;                      /*  BUFFER-BBUF     */
	V9= fix((V2));
	V10= ((V1))->in.in_slots[7];
	{volatile object V11;                     /*  LST             */
	volatile int V12;                         /*  LEN             */
	volatile int V13;                         /*  CHUNK           */
	V11= nthcdr(V7,(V3));
	V12= (((fix((V5)))-(V7)) << (1));
	{int V14= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V14)?V12:V14;}
L2033:
	if((V12)>0){
	goto L2034;}
	goto L2028;
L2034:
	{volatile int V15;                        /*  J               */
	V15= 0;
L2040:
	if(!((V15)>=((V13)-1))){
	goto L2041;}
	V13= V15;
	goto L2037;
L2041:
	{register int V17;                        /*  %ITEM           */
	register int V18;                         /*  %BYTE-INDEX     */
	{register object V19;
	V19= CAR((V11));
	V11= CDR((V11));
	VALUES(0) = (V19);
	}
	funcall(2,(V6),VALUES(0));
	V17= fix(VALUES(0));
	V18= (V9)+(V15);
	(((V10))->ust.ust_self[V18]=(((((~(-1 << (8))) << (8)) & (V17)) >> (8))));
	(((V10))->ust.ust_self[(V18)+(1)]=(((((~(-1 << (8))) << (0)) & (V17)) >> (0))));
	}
	V15= (V15)+(2);
	goto L2040;
	}
L2037:
	V9= (V9)+(V13);
	if(!((V12)>0)){
	goto L2058;}
	if(!((V9)>=(fix(((V1))->in.in_slots[2])))){
	goto L2058;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V9);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V9= fix(((V1))->in.in_slots[6]);
L2058:
	V12= (V12)-(V13);
	{int V19= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V19)?V12:V19;}
	goto L2033;
	}
L2028:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V9)+(3)) & (-4)));
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-SIMPLE-ARRAY-CHAR2B             */
static L98(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT100 VLEX100 CLSR100
	{volatile int V6;
	V6= fix(V4);
TTL:
	{volatile object V7;                      /*  DATA            */
	V7= (V3);
	{volatile object V8;                      /*  %BUFFER         */
	{volatile int V9;                         /*  BUFFER-BOFFSET  */
	volatile object V10;                      /*  BUFFER-BBUF     */
	V9= fix((V2));
	V10= ((V1))->in.in_slots[7];
	{volatile int V11;                        /*  INDEX           */
	volatile int V12;                         /*  LEN             */
	volatile int V13;                         /*  CHUNK           */
	V11= V6;
	V12= (((fix((V5)))-(V6)) << (1));
	{int V14= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V14)?V12:V14;}
L2082:
	if((V12)>0){
	goto L2083;}
	goto L2077;
L2083:
	{volatile int V15;                        /*  J               */
	V15= 0;
L2089:
	if(!((V15)>=((V13)-1))){
	goto L2090;}
	V13= V15;
	goto L2086;
L2090:
	{register int V17;                        /*  %ITEM           */
	register int V18;                         /*  %BYTE-INDEX     */
	V17= ((V7))->fixa.fixa_self[V11];
	V18= (V9)+(V15);
	(((V10))->ust.ust_self[V18]=(((((~(-1 << (8))) << (8)) & (V17)) >> (8))));
	(((V10))->ust.ust_self[(V18)+(1)]=(((((~(-1 << (8))) << (0)) & (V17)) >> (0))));
	}
	V11= (V11)+(1);
	V15= (V15)+(2);
	goto L2089;
	}
L2086:
	V9= (V9)+(V13);
	if(!((V12)>0)){
	goto L2105;}
	if(!((V9)>=(fix(((V1))->in.in_slots[2])))){
	goto L2105;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V9);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V9= fix(((V1))->in.in_slots[6]);
L2105:
	V12= (V12)-(V13);
	{int V19= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V19)?V12:V19;}
	goto L2082;
	}
L2077:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V9)+(3)) & (-4)));
	}
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-SIMPLE-ARRAY-CHAR2B-WITH-TRANSFORM*/
static L99(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT101 VLEX101 CLSR101
	{volatile int V7;
	V7= fix(V4);
TTL:
	{volatile object V8;                      /*  DATA            */
	V8= (V3);
	{volatile object V9;                      /*  %BUFFER         */
	{volatile int V10;                        /*  BUFFER-BOFFSET  */
	volatile object V11;                      /*  BUFFER-BBUF     */
	V10= fix((V2));
	V11= ((V1))->in.in_slots[7];
	{volatile int V12;                        /*  INDEX           */
	volatile int V13;                         /*  LEN             */
	volatile int V14;                         /*  CHUNK           */
	V12= V7;
	V13= (((fix((V5)))-(V7)) << (1));
	{int V15= (fix(((V1))->in.in_slots[2]))-(V10);
	V14= (V13)<=(V15)?V13:V15;}
L2129:
	if((V13)>0){
	goto L2130;}
	goto L2124;
L2130:
	{volatile int V16;                        /*  J               */
	V16= 0;
L2136:
	if(!((V16)>=((V14)-1))){
	goto L2137;}
	V14= V16;
	goto L2133;
L2137:
	{register int V18;                        /*  %ITEM           */
	register int V19;                         /*  %BYTE-INDEX     */
	funcall(2,(V6),((V8))->v.v_self[V12]);
	V18= fix(VALUES(0));
	V19= (V10)+(V16);
	(((V11))->ust.ust_self[V19]=(((((~(-1 << (8))) << (8)) & (V18)) >> (8))));
	(((V11))->ust.ust_self[(V19)+(1)]=(((((~(-1 << (8))) << (0)) & (V18)) >> (0))));
	}
	V12= (V12)+(1);
	V16= (V16)+(2);
	goto L2136;
	}
L2133:
	V10= (V10)+(V14);
	if(!((V13)>0)){
	goto L2152;}
	if(!((V10)>=(fix(((V1))->in.in_slots[2])))){
	goto L2152;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V10);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V10= fix(((V1))->in.in_slots[6]);
L2152:
	V13= (V13)-(V14);
	{int V20= (fix(((V1))->in.in_slots[2]))-(V10);
	V14= (V13)<=(V20)?V13:V20;}
	goto L2129;
	}
L2124:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V10)+(3)) & (-4)));
	}
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-VECTOR-CHAR2B                   */
static L100(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT102 VLEX102 CLSR102
	{volatile int V6;
	V6= fix(V4);
TTL:
	{volatile object V7;                      /*  DATA            */
	V7= (V3);
	{volatile object V8;                      /*  %BUFFER         */
	{volatile int V9;                         /*  BUFFER-BOFFSET  */
	volatile object V10;                      /*  BUFFER-BBUF     */
	V9= fix((V2));
	V10= ((V1))->in.in_slots[7];
	{volatile int V11;                        /*  INDEX           */
	volatile int V12;                         /*  LEN             */
	volatile int V13;                         /*  CHUNK           */
	V11= V6;
	V12= (((fix((V5)))-(V6)) << (1));
	{int V14= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V14)?V12:V14;}
L2176:
	if((V12)>0){
	goto L2177;}
	goto L2171;
L2177:
	{volatile int V15;                        /*  J               */
	V15= 0;
L2183:
	if(!((V15)>=((V13)-1))){
	goto L2184;}
	V13= V15;
	goto L2180;
L2184:
	{register int V17;                        /*  %ITEM           */
	register int V18;                         /*  %BYTE-INDEX     */
	V17= fix(((V7))->v.v_self[V11]);
	V18= (V9)+(V15);
	(((V10))->ust.ust_self[V18]=(((((~(-1 << (8))) << (8)) & (V17)) >> (8))));
	(((V10))->ust.ust_self[(V18)+(1)]=(((((~(-1 << (8))) << (0)) & (V17)) >> (0))));
	}
	V11= (V11)+(1);
	V15= (V15)+(2);
	goto L2183;
	}
L2180:
	V9= (V9)+(V13);
	if(!((V12)>0)){
	goto L2199;}
	if(!((V9)>=(fix(((V1))->in.in_slots[2])))){
	goto L2199;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V9);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V9= fix(((V1))->in.in_slots[6]);
L2199:
	V12= (V12)-(V13);
	{int V19= (fix(((V1))->in.in_slots[2]))-(V9);
	V13= (V12)<=(V19)?V12:V19;}
	goto L2176;
	}
L2171:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V9)+(3)) & (-4)));
	}
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-VECTOR-CHAR2B-WITH-TRANSFORM    */
static L101(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT103 VLEX103 CLSR103
	{volatile int V7;
	V7= fix(V4);
TTL:
	{volatile object V8;                      /*  DATA            */
	V8= (V3);
	{volatile object V9;                      /*  %BUFFER         */
	{volatile int V10;                        /*  BUFFER-BOFFSET  */
	volatile object V11;                      /*  BUFFER-BBUF     */
	V10= fix((V2));
	V11= ((V1))->in.in_slots[7];
	{volatile int V12;                        /*  INDEX           */
	volatile int V13;                         /*  LEN             */
	volatile int V14;                         /*  CHUNK           */
	V12= V7;
	V13= (((fix((V5)))-(V7)) << (1));
	{int V15= (fix(((V1))->in.in_slots[2]))-(V10);
	V14= (V13)<=(V15)?V13:V15;}
L2223:
	if((V13)>0){
	goto L2224;}
	goto L2218;
L2224:
	{volatile int V16;                        /*  J               */
	V16= 0;
L2230:
	if(!((V16)>=((V14)-1))){
	goto L2231;}
	V14= V16;
	goto L2227;
L2231:
	{register int V18;                        /*  %ITEM           */
	register int V19;                         /*  %BYTE-INDEX     */
	funcall(2,(V6),((V8))->v.v_self[V12]);
	V18= fix(VALUES(0));
	V19= (V10)+(V16);
	(((V11))->ust.ust_self[V19]=(((((~(-1 << (8))) << (8)) & (V18)) >> (8))));
	(((V11))->ust.ust_self[(V19)+(1)]=(((((~(-1 << (8))) << (0)) & (V18)) >> (0))));
	}
	V12= (V12)+(1);
	V16= (V16)+(2);
	goto L2230;
	}
L2227:
	V10= (V10)+(V14);
	if(!((V13)>0)){
	goto L2246;}
	if(!((V10)>=(fix(((V1))->in.in_slots[2])))){
	goto L2246;}
	((V1))->in.in_slots[6]= MAKE_FIXNUM(V10);
	L23(1,(V1))                               /*  BUFFER-FLUSH    */;
	V10= fix(((V1))->in.in_slots[6]);
L2246:
	V13= (V13)-(V14);
	{int V20= (fix(((V1))->in.in_slots[2]))-(V10);
	V14= (V13)<=(V20)?V13:V20;}
	goto L2223;
	}
L2218:
	((V1))->in.in_slots[6]= MAKE_FIXNUM((((V10)+(3)) & (-4)));
	}
	}
	}
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for WRITE-SEQUENCE-CHAR2B                 */
static L102(int narg, object V1, object V2, object V3, ...)
{ VT104 VLEX104 CLSR104
	{register int V4;int i=3;
	register int V5;
	register int V6;
	register object V7;
	va_list args; va_start(args, V3);
	V4= fix(V2);
	if (i==narg) goto L2259;
	V5= fix(va_arg(args, object));
	i++;
	if (i==narg) goto L2260;
	V6= fix(va_arg(args, object));
	i++;
	if (i==narg) goto L2261;
	V7= va_arg(args, object);
	i++;
	goto L2262;
L2259:
	V5= 0;
L2260:
	V6= length((V3));
L2261:
	V7= Cnil;
L2262:
	{object V8;
	(*LK17)(2,(V3),VV[76])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2267;}
	if(((V7))==Cnil){
	goto L2270;}
	RETURN(L97(6,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),(V7))/*  WRITE-LIST-CHAR2B-WITH-TRANSFORM*/);
L2270:
	RETURN(L96(5,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6))/*  WRITE-LIST-CHAR2B*/);
L2267:
	(*LK17)(2,(V3),VV[84])                    /*  TYPEP           */;
	if(VALUES(0)==Cnil){
	goto L2273;}
	if(((V7))==Cnil){
	goto L2276;}
	RETURN(L99(6,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),(V7))/*  WRITE-SIMPLE-ARRAY-CHAR2B-WITH-TRANSFORM*/);
L2276:
	RETURN(L98(5,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6))/*  WRITE-SIMPLE-ARRAY-CHAR2B*/);
L2273:
	if(((V7))==Cnil){
	goto L2279;}
	RETURN(L101(6,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6),(V7))/*  WRITE-VECTOR-CHAR2B-WITH-TRANSFORM*/);
L2279:
	RETURN(L100(5,(V1),MAKE_FIXNUM(V4),(V3),MAKE_FIXNUM(V5),MAKE_FIXNUM(V6))/*  WRITE-VECTOR-CHAR2B*/);
	}
	}
}
static LKF18(int narg, ...) {TRAMPOLINK(VV[252],&LK18);}
static LKF17(int narg, ...) {TRAMPOLINK(VV[230],&LK17);}
static LKF16(int narg, ...) {TRAMPOLINK(VV[225],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[220],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[219],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[210],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[209],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[208],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[207],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[104],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[199],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[198],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[196],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[195],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[191],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[189],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[188],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[15],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[184],&LK0);}
