
#include "change.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	funcall(2,VV[19]->s.s_gfdef,VV[0])        /*  FIND-CLASS      */;
	funcall(9,VV[20]->s.s_gfdef,VALUES(0),VV[1],Cnil,Cnil,Cnil,Cnil,Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[19]->s.s_gfdef,VV[1])        /*  FIND-CLASS      */;
	VV[21] = make_cfun(LC1,Cnil,&Cblock);
	VALUES(0) = VV[21];
	funcall(8,VV[22]->s.s_gfdef,VV[2],Cnil,VV[3],VV[4],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VALUES(0) = VV[21];
	funcall(8,VV[22]->s.s_gfdef,VV[5],Cnil,VV[6],VV[7],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[23] = make_cfun(LC3,Cnil,&Cblock);
	VALUES(0) = VV[23];
	funcall(8,VV[22]->s.s_gfdef,VV[8],Cnil,VV[9],VV[10],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	VV[24] = make_cfun(LC4,Cnil,&Cblock);
	VALUES(0) = VV[24];
	funcall(8,VV[22]->s.s_gfdef,VV[11],Cnil,VV[12],VV[13],Cnil,Cnil,VALUES(0))/*  INSTALL-METHOD*/;
	MF0(VV[25],L5);
	(void)putprop(VV[25],VV[Vdeb25],VV[26]);
	MF0(VV[27],L6);
	(void)putprop(VV[27],VV[Vdeb27],VV[26]);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	local function CLOSURE                                        */
static LC4(int narg, object V1, object V2, object V3)
{ VT3 VLEX3 CLSR3
	L5(1,(V2))                                /*  UPDATE-INSTANCE */;
	RETURN((*LK0)(3,(V1),(V2),(V3))           /*  (SETF SLOT-VALUE)*/);
}
/*	local function CLOSURE                                        */
static LC3(int narg, object V1, object V2)
{ VT4 VLEX4 CLSR4
	L5(1,(V1))                                /*  UPDATE-INSTANCE */;
	RETURN((*LK1)(2,(V1),(V2))                /*  SLOT-VALUE      */);
}
/*	local function CLOSURE                                        */
static LC1(int narg, object V1, object V2)
{ VT5 VLEX5 CLSR5
	VALUES(0) = (V2);
	RETURN(1);
}
/*	function definition for UPDATE-INSTANCE                       */
static L5(int narg, object V1)
{ VT6 VLEX6 CLSR6
TTL:
	{register object V2;                      /*  OLD-CLASS       */
	register object V3;                       /*  NEW-CLASS       */
	register object V4;                       /*  OLD-INSTANCE-SLOT-NAMES*/
	object V5;                                /*  OLD-CLASS-SLOT-NAMES*/
	register object V6;                       /*  NEW-INSTANCE-SLOT-NAMES*/
	object V7;                                /*  NEW-CLASS-SLOT-NAMES*/
	object V8;                                /*  DISCARDED-SLOTS */
	object V9;                                /*  ADDED-SLOTS     */
	object V10;                               /*  RETAINED-INSTANCE-SLOTS*/
	object V11;                               /*  PROPERTY-LIST   */
	register object V12;                      /*  POSITION        */
	(*LK2)(1,(V1))                            /*  CLASS-OF        */;
	V2= VALUES(0);
	(*LK1)(2,(V2),VV[14])                     /*  SLOT-VALUE      */;
	V3= VALUES(0);
	T1=VV[30]->s.s_gfdef;
	{object V13;
	object V14= ((V2))->in.in_slots[3];
	if(V14==Cnil){
	V4= Cnil;
	goto L16;}
	T0=V13=CONS(Cnil,Cnil);
L17:
	(*LK3)(1,CAR(V14))                        /*  SLOTD-NAME      */;
	CAR(V13)= VALUES(0);
	if((V14=CDR(V14))==Cnil){
	V4= T0;
	goto L16;}
	V13=CDR(V13)=CONS(Cnil,Cnil);
	goto L17;}
L16:
	T1=VV[30]->s.s_gfdef;
	(*LK4)(1,(V2))                            /*  CLASS-CLASS-SLOTS*/;
	{object V13;
	object V14= VALUES(0);
	if(V14==Cnil){
	V5= Cnil;
	goto L19;}
	T0=V13=CONS(Cnil,Cnil);
L20:
	(*LK3)(1,CAR(V14))                        /*  SLOTD-NAME      */;
	CAR(V13)= VALUES(0);
	if((V14=CDR(V14))==Cnil){
	V5= T0;
	goto L19;}
	V13=CDR(V13)=CONS(Cnil,Cnil);
	goto L20;}
L19:
	T1=VV[30]->s.s_gfdef;
	{object V13;
	object V14= ((V3))->in.in_slots[3];
	if(V14==Cnil){
	V6= Cnil;
	goto L23;}
	T0=V13=CONS(Cnil,Cnil);
L24:
	(*LK3)(1,CAR(V14))                        /*  SLOTD-NAME      */;
	CAR(V13)= VALUES(0);
	if((V14=CDR(V14))==Cnil){
	V6= T0;
	goto L23;}
	V13=CDR(V13)=CONS(Cnil,Cnil);
	goto L24;}
L23:
	T1=VV[30]->s.s_gfdef;
	(*LK4)(1,(V3))                            /*  CLASS-CLASS-SLOTS*/;
	{object V13;
	object V14= VALUES(0);
	if(V14==Cnil){
	V7= Cnil;
	goto L26;}
	T0=V13=CONS(Cnil,Cnil);
L27:
	(*LK3)(1,CAR(V14))                        /*  SLOTD-NAME      */;
	CAR(V13)= VALUES(0);
	if((V14=CDR(V14))==Cnil){
	V7= T0;
	goto L26;}
	V13=CDR(V13)=CONS(Cnil,Cnil);
	goto L27;}
L26:
	V8= Cnil;
	V9= Cnil;
	V10= Cnil;
	V11= Cnil;
	V12= Cnil;
	if(equal((V4),(V6))){
	goto L35;}
	(*LK5)(2,(V4),(V6))                       /*  SET-DIFFERENCE  */;
	V8= VALUES(0);
	{register object V13;
	object V14;                               /*  SLOT-NAME       */
	V13= (V8);
	V14= Cnil;
L44:
	if(!((V13)==Cnil)){
	goto L45;}
	goto L40;
L45:
	V14= CAR((V13));
	VALUES(0) = (VV[33]->s.s_gfdef);
	(*LK6)(4,(V14),(V4),VV[15],VALUES(0))     /*  POSITION        */;
	V12= VALUES(0);
	siLinstance_ref(2,(V1),(V12))             /*  INSTANCE-REF    */;
	V11= CONS(CONS((V14),VALUES(0)),(V11));
	V13= CDR((V13));
	goto L44;
	}
L40:
	{register object V13;                     /*  NEW-SLOTS       */
	register object V14;                      /*  NEW-SLOT        */
	register int V15;                         /*  I               */
	V13= (V6);
	V14= CAR((V13));
	V15= 0;
L63:
	if(((V13))!=Cnil){
	goto L64;}
	goto L35;
L64:
	VALUES(0) = (VV[33]->s.s_gfdef);
	(*LK6)(4,(V14),(V4),VV[15],VALUES(0))     /*  POSITION        */;
	V12= VALUES(0);
	if(((V12))==Cnil){
	goto L72;}
	siLinstance_ref(2,(V1),(V12))             /*  INSTANCE-REF    */;
	V10= CONS(CONS(MAKE_FIXNUM(V15),VALUES(0)),(V10));
	goto L70;
L72:
	{register object x= (V14),V17= (V5);
	while(V17!=Cnil)
	if(eql(x, CAR(V17))){
	goto L70;
	}else V17=CDR(V17);}
	V9= CONS((V14),(V9));
L70:
	V13= CDR((V13));
	V14= CAR((V13));
	V15= (V15)+1;
	goto L63;
	}
L35:
	(*LK7)(3,(V1),(V3),MAKE_FIXNUM(length((V6))))/*  CHANGE-INSTANCE*/;
	{register object V13;
	object V14;                               /*  L               */
	V13= (V10);
	V14= Cnil;
L91:
	if(!((V13)==Cnil)){
	goto L92;}
	goto L87;
L92:
	V14= CAR((V13));
	Lcar(1,(V14))                             /*  CAR             */;
	T0= VALUES(0);
	siLinstance_set(3,(V1),T0,CDR((V14)))     /*  INSTANCE-SET    */;
	V13= CDR((V13));
	goto L91;
	}
L87:
	{register object V13;
	register object V14;                      /*  CLASS-SLOT-INFO */
	(*LK8)(1,(V2))                            /*  CLASS-CLASS-SLOTS-VALUES*/;
	V13= VALUES(0);
	V14= Cnil;
L106:
	if(!((V13)==Cnil)){
	goto L107;}
	goto L102;
L107:
	V14= CAR((V13));
	{object V16;                              /*  SLOT-NAME       */
	V16= CAR((V14));
	VALUES(0) = (VV[33]->s.s_gfdef);
	(*LK6)(4,(V16),(V6),VV[15],VALUES(0))     /*  POSITION        */;
	V12= VALUES(0);
	if(((V12))==Cnil){
	goto L115;}
	siLinstance_set(3,(V1),(V12),CDR((V14)))  /*  INSTANCE-SET    */;
	goto L112;
L115:
	{register object x= (V16),V17= (V7);
	while(V17!=Cnil)
	if(eql(x, CAR(V17))){
	goto L120;
	}else V17=CDR(V17);
	goto L112;}
L120:
	{object V17;
	{object V18= CONS((V16),CDR((V14)));
	(*LK8)(1,(V3))                            /*  CLASS-CLASS-SLOTS-VALUES*/;
	V17= CONS(V18,VALUES(0));}
	(*LK9)(2,(V17),(V3))                      /*  (SETF CLASS-CLASS-SLOTS-VALUES)*/;
	}
	}
L112:
	V13= CDR((V13));
	goto L106;
	}
L102:
	RETURN((*LK10)(4,(V1),(V9),(V8),(V11))    /*  UPDATE-INSTANCE-FOR-REDEFINED-CLASS*/);
	}
}
/*	function definition for REMOVE-OPTIONAL-SLOT-ACCESSORS        */
static L6(int narg, object V1)
{ VT7 VLEX7 CLSR7
TTL:
	{register object V2;                      /*  CLASS-NAME      */
	V2= ((V1))->in.in_slots[0];
	{object V3;
	object V4;                                /*  SLOTD           */
	V3= ((V1))->in.in_slots[3];
	V4= Cnil;
L130:
	if(!((V3)==Cnil)){
	goto L131;}
	VALUES(0) = Cnil;
	RETURN(1);
L131:
	V4= CAR((V3));
	{object V6;
	object V7;                                /*  ACCESSOR        */
	{object V8= CDR(CDR(CDR((V4))));
	V6= CAR(V8);}
	V7= Cnil;
L140:
	if(!((V6)==Cnil)){
	goto L141;}
	goto L136;
L141:
	V7= CAR((V6));
	{object V9;                               /*  GFUN            */
	register object V10;                      /*  GF-OBJECT       */
	object V11;                               /*  SETF-ACCESSOR   */
	object V12;                               /*  SETF-GFUN       */
	object V13;                               /*  SETF-GF-OBJECT  */
	register object V14;                      /*  FOUND           */
	V9= symbol_function((V7));
	siLgfun_instance(1,(V9))                  /*  GFUN-INSTANCE   */;
	V10= VALUES(0);
	V11= list(2,VV[16],(V7));
	V12= symbol_function((V11));
	siLgfun_instance(1,(V12))                 /*  GFUN-INSTANCE   */;
	V13= VALUES(0);
	V14= Cnil;
	(*LK11)(4,(V10),Cnil,CONS((V2),Cnil),Cnil)/*  FIND-METHOD     */;
	V14= VALUES(0);
	if(((V14))==Cnil){
	goto L153;}
	(*LK12)(2,(V10),(V14))                    /*  REMOVE-METHOD   */;
L153:
	(*LK11)(4,(V10),VV[17],CONS((V2),Cnil),Cnil)/*  FIND-METHOD   */;
	V14= VALUES(0);
	if(((V14))==Cnil){
	goto L157;}
	(*LK12)(2,(V10),(V14))                    /*  REMOVE-METHOD   */;
L157:
	(*LK11)(4,(V10),VV[18],CONS((V2),Cnil),Cnil)/*  FIND-METHOD   */;
	V14= VALUES(0);
	if(((V14))==Cnil){
	goto L161;}
	(*LK12)(2,(V10),(V14))                    /*  REMOVE-METHOD   */;
L161:
	(*LK13)(1,(V10))                          /*  METHODS         */;
	if(VALUES(0)!=Cnil){
	goto L165;}
	Lfmakunbound(1,(V7))                      /*  FMAKUNBOUND     */;
L165:
	(*LK11)(4,(V13),Cnil,list(2,Cnil,(V2)),Cnil)/*  FIND-METHOD   */;
	V14= VALUES(0);
	if(((V14))==Cnil){
	goto L168;}
	(*LK12)(2,(V13),(V14))                    /*  REMOVE-METHOD   */;
L168:
	(*LK11)(4,(V13),VV[17],list(2,Cnil,(V2)),Cnil)/*  FIND-METHOD */;
	V14= VALUES(0);
	if(((V14))==Cnil){
	goto L172;}
	(*LK12)(2,(V13),(V14))                    /*  REMOVE-METHOD   */;
L172:
	(*LK11)(4,(V13),VV[18],list(2,Cnil,(V2)),Cnil)/*  FIND-METHOD */;
	V14= VALUES(0);
	if(((V14))==Cnil){
	goto L176;}
	(*LK12)(2,(V13),(V14))                    /*  REMOVE-METHOD   */;
L176:
	(*LK13)(1,(V10))                          /*  METHODS         */;
	if(VALUES(0)!=Cnil){
	goto L146;}
	Lfmakunbound(1,(V11))                     /*  FMAKUNBOUND     */;
	}
L146:
	V6= CDR((V6));
	goto L140;
	}
L136:
	{object V15;
	object V16;                               /*  READER          */
	{object V17= CDR(CDR(CDR(CDR((V4)))));
	V15= CAR(V17);}
	V16= Cnil;
L189:
	if(!((V15)==Cnil)){
	goto L190;}
	goto L185;
L190:
	V16= CAR((V15));
	{object V18;                              /*  GFUN            */
	register object V19;                      /*  GF-OBJECT       */
	object V20;                               /*  FOUND           */
	V18= symbol_function((V16));
	siLgfun_instance(1,(V18))                 /*  GFUN-INSTANCE   */;
	V19= VALUES(0);
	V20= Cnil;
	(*LK11)(4,(V19),Cnil,CONS((V2),Cnil),Cnil)/*  FIND-METHOD     */;
	V20= VALUES(0);
	if(((V20))==Cnil){
	goto L199;}
	(*LK12)(2,(V19),(V20))                    /*  REMOVE-METHOD   */;
L199:
	(*LK11)(4,(V19),VV[17],CONS((V2),Cnil),Cnil)/*  FIND-METHOD   */;
	V20= VALUES(0);
	if(((V20))==Cnil){
	goto L203;}
	(*LK12)(2,(V19),(V20))                    /*  REMOVE-METHOD   */;
L203:
	(*LK11)(4,(V19),VV[18],CONS((V2),Cnil),Cnil)/*  FIND-METHOD   */;
	V20= VALUES(0);
	if(((V20))==Cnil){
	goto L207;}
	(*LK12)(2,(V19),(V20))                    /*  REMOVE-METHOD   */;
L207:
	(*LK13)(1,(V19))                          /*  METHODS         */;
	if(VALUES(0)!=Cnil){
	goto L195;}
	Lfmakunbound(1,(V16))                     /*  FMAKUNBOUND     */;
	}
L195:
	V15= CDR((V15));
	goto L189;
	}
L185:
	{object V21;
	object V22;                               /*  WRITER          */
	{object V23= CDR(CDR(CDR(CDR(CDR((V4))))));
	V21= CAR(V23);}
	V22= Cnil;
L220:
	if(!((V21)==Cnil)){
	goto L221;}
	goto L216;
L221:
	V22= CAR((V21));
	{object V24;                              /*  GFUN            */
	register object V25;                      /*  GF-OBJECT       */
	object V26;                               /*  FOUND           */
	V24= symbol_function((V22));
	siLgfun_instance(1,(V24))                 /*  GFUN-INSTANCE   */;
	V25= VALUES(0);
	V26= Cnil;
	(*LK11)(4,(V25),Cnil,CONS((V2),Cnil),Cnil)/*  FIND-METHOD     */;
	V26= VALUES(0);
	if(((V26))==Cnil){
	goto L230;}
	(*LK12)(2,(V25),(V26))                    /*  REMOVE-METHOD   */;
L230:
	(*LK11)(4,(V25),VV[17],CONS((V2),Cnil),Cnil)/*  FIND-METHOD   */;
	V26= VALUES(0);
	if(((V26))==Cnil){
	goto L234;}
	(*LK12)(2,(V25),(V26))                    /*  REMOVE-METHOD   */;
L234:
	(*LK11)(4,(V25),VV[18],CONS((V2),Cnil),Cnil)/*  FIND-METHOD   */;
	V26= VALUES(0);
	if(((V26))==Cnil){
	goto L238;}
	(*LK12)(2,(V25),(V26))                    /*  REMOVE-METHOD   */;
L238:
	(*LK13)(1,(V25))                          /*  METHODS         */;
	if(VALUES(0)!=Cnil){
	goto L226;}
	Lfmakunbound(1,(V22))                     /*  FMAKUNBOUND     */;
	}
L226:
	V21= CDR((V21));
	goto L220;
	}
L216:
	V3= CDR((V3));
	goto L130;
	}
	}
}
static LKF13(int narg, ...) {TRAMPOLINK(VV[42],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[41],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[40],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[38],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[37],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[36],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[35],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[34],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[32],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[31],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[30],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[29],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[8],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[28],&LK0);}
