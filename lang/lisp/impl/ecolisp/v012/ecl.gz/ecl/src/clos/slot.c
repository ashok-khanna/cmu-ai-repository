
#include "slot.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	VV[0]->s.s_stype=(short)stp_special;
	if(VV[0]->s.s_dbind == OBJNULL){
	(VV[0]->s.s_dbind)= Cnil;}
	VV[1]->s.s_stype=(short)stp_special;
	if(VV[1]->s.s_dbind == OBJNULL){
	(VV[1]->s.s_dbind)= Cnil;}
	funcall(13,VV[13]->s.s_gfdef,VV[2],VV[3],VV[4],Cnil,VV[5],VV[6],VV[7],Cnil,Cnil,VV[8],MAKE_FIXNUM(9),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[14],L1,9,L1keys);
	(void)putprop(VV[14],VV[Vdeb14],VV[15]);
	MF0(VV[16],L2);
	(void)putprop(VV[16],VV[Vdeb16],VV[15]);
	MF0(VV[17],L3);
	(void)putprop(VV[17],VV[Vdeb17],VV[15]);
	MF0(VV[18],L4);
	(void)putprop(VV[18],VV[Vdeb18],VV[15]);
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	function definition for MAKE-SLOTD                            */
static L1(int narg, ...)
{ VT3 VLEX3 CLSR3
	{object V1;
	object V2;
	object V3;
	object V4;
	object V5;
	object V6;
	object V7;
	object V8;
	object V9;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[18];
	parse_key(narg,args,9,L1keys,keyvars,OBJNULL,FALSE);
	V1= keyvars[0];
	V2= keyvars[1];
	V3= keyvars[2];
	V4= keyvars[3];
	V5= keyvars[4];
	V6= keyvars[5];
	V7= keyvars[6];
	V8= keyvars[7];
	V9= keyvars[8];
	}
	VALUES(0) = list(9,(V1),(V2),(V3),(V4),(V5),(V6),(V7),(V8),(V9));
	RETURN(1);
	}
}
/*	function definition for PARSE-CLASS-SLOT                      */
static L2(int narg, object V1)
{ VT4 VLEX4 CLSR4
TTL:
	{register object V2;                      /*  NAME            */
	object V3;                                /*  INITARGS        */
	object V4;                                /*  INITFORM        */
	object V5;                                /*  ACCESSORS       */
	object V6;                                /*  READERS         */
	object V7;                                /*  WRITERS         */
	object V8;                                /*  ALLOCATION      */
	object V9;                                /*  TYPE            */
	object V10;                               /*  DOCUMENTATION   */
	register object V11;                      /*  SLOTD           */
	L1(0)                                     /*  MAKE-SLOTD      */;
	V11= VALUES(0);
	V2= Cnil;
	V3= Cnil;
	V4= VV[0];
	V5= Cnil;
	V6= Cnil;
	V7= Cnil;
	V8= VV[9];
	V9= Ct;
	V10= Cnil;
	if(!(type_of((V1))==t_symbol)){
	goto L8;}
	V2= (V1);
	goto L6;
L8:
	if((CDR((V1)))!=Cnil){
	goto L12;}
	V2= CAR((V1));
	goto L6;
L12:
	V2= CAR((V1));
	{register object V12;                     /*  OPTIONS         */
	register object V13;                      /*  OPTION          */
	register object V14;                      /*  VALUE           */
	V12= CDR((V1));
	V13= Cnil;
	V14= Cnil;
L19:
	if(((V12))!=Cnil){
	goto L21;}
	goto L6;
L21:
	{object V15;
	V15= CAR((V12));
	V12= CDR((V12));
	V13= (V15);
	}
	{object V15;
	V15= CAR((V12));
	V12= CDR((V12));
	V14= (V15);
	}
	L4(1,(V13))                               /*  LEGAL-SLOT-OPTION-P*/;
	if(VALUES(0)!=Cnil){
	goto L34;}
	Lerror(3,VV[10],(V1),(V13))               /*  ERROR           */;
L34:
	if(((V13)!= VV[29]))goto L37;
	V3= CONS((V14),(V3));
	goto L20;
L37:
	if(((V13)!= VV[21]))goto L39;
	V4= (V14);
	goto L20;
L39:
	if(((V13)!= VV[30]))goto L41;
	V5= CONS((V14),(V5));
	goto L20;
L41:
	if(((V13)!= VV[31]))goto L43;
	V6= CONS((V14),(V6));
	goto L20;
L43:
	if(((V13)!= VV[32]))goto L45;
	V7= CONS((V14),(V7));
	goto L20;
L45:
	if(((V13)!= VV[25]))goto L47;
	V8= (V14);
	goto L20;
L47:
	if(((V13)!= VV[26]))goto L49;
	if(((V14))!=Cnil){
	goto L52;}
	Lerror(1,VV[11])                          /*  ERROR           */;
	V9= VALUES(0);
	goto L50;
L52:
	V9= (V14);
L50:
	goto L20;
L49:
	if(((V13)!= VV[27]))goto L54;
	V10= CONS((V14),(V10));
	goto L20;
L54:
L20:
	goto L19;
	}
L6:
	CAR((V11))= (V2);
	CAR(CDR((V11)))= (V3);
	CAR(CDR(CDR((V11))))= (V4);
	CAR(CDR(CDR(CDR((V11)))))= (V5);
	CAR(CDR(CDR(CDR(CDR((V11))))))= (V6);
	CAR(CDR(CDR(CDR(CDR(CDR((V11)))))))= (V7);
	CAR(CDR(CDR(CDR(CDR(CDR(CDR((V11))))))))= (V8);
	CAR(CDR(CDR(CDR(CDR(CDR(CDR(CDR((V11)))))))))= (V9);
	{object V12= CDR(CDR(CDR(CDR(CDR(CDR(CDR(CDR((V11)))))))));}
	VALUES(0) = (V11);
	RETURN(1);
	}
}
/*	function definition for PARSE-CLASS-SLOTS                     */
static L3(int narg, object V1)
{ VT5 VLEX5 CLSR5
TTL:
	{register object V2;                      /*  SCAN            */
	object V3;                                /*  COLLECT         */
	V2= (V1);
	V3= Cnil;
L68:
	if(((V2))!=Cnil){
	goto L69;}
	VALUES(0) = nreverse((V3));
	RETURN(1);
L69:
	L2(1,CAR((V2)))                           /*  PARSE-CLASS-SLOT*/;
	V3= CONS(VALUES(0),(V3));
	V2= CDR((V2));
	goto L68;
	}
}
/*	function definition for LEGAL-SLOT-OPTION-P                   */
static L4(int narg, object V1)
{ VT6 VLEX6 CLSR6
TTL:
	{register object x= (V1),V2= VV[12];
	while(V2!=Cnil)
	if(eql(x, CAR(V2))){
	VALUES(0) = V2;
	RETURN(1);
	}else V2=CDR(V2);
	VALUES(0) = Cnil;
	RETURN(1);}
}
