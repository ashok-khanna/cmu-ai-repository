/*
    page.h  -- Page macros.
*/
/*
    Copyright (c) 1990, Giuseppe Attardi.

    ECoLisp is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    See file '../Copyright' for full details.
*/

#define page(p)		(((int)(char *)(p) - DATA_START) / LISP_PAGESIZE)
#define	pagetochar(x)	((char *)(((x) * LISP_PAGESIZE) + DATA_START))
#define round_to_page(x) (((int)(x) + LISP_PAGESIZE - 1) / LISP_PAGESIZE)

extern int real_maxpage;
extern int new_holepage;

#define	available_pages	\
	(real_maxpage-page(heap_end)-new_holepage-2*nrbpage-real_maxpage/32)

#define	round_up(n)	(((n) + 03) & ~03)
