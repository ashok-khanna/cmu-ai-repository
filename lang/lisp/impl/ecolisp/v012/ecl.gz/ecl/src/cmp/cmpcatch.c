
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "cmpcatch.h"
init_cmpcatch(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_cmpcatch; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	MF0(VV[16],L1);
	MF0(VV[18],L2);
	MF0(VV[24],L3);
	MF0(VV[19],L4);
	MF0(VV[20],L5);
	MF0(VV[21],L6);
	MF0(VV[22],L7);
	putprop(VV[2],VV[16],VV[15]);
	putprop(VV[2],VV[18],VV[17]);
	putprop(VV[8],VV[19],VV[15]);
	putprop(VV[8],VV[20],VV[17]);
	putprop(VV[12],VV[21],VV[15]);
	putprop(VV[12],VV[22],VV[17]);
	putprop(VV[7],VV[24],VV[23]);
}
/*	function definition for C1CATCH                               */
static L1(int narg, object V1)
{ VT3 VLEX3 CLSR3
TTL:
	{object V2;                               /*  INFO            */
	object V3;                                /*  TAG             */
	(*LK0)(2,VV[0],Ct)                        /*  MAKE-INFO       */;
	V2= VALUES(0);
	V3= Cnil;
	(VV[1]->s.s_dbind)= number_plus((VV[1]->s.s_dbind),MAKE_FIXNUM(1));
	if(!((V1)==Cnil)){
	goto L12;}
	(*LK1)(3,VV[2],MAKE_FIXNUM(1),MAKE_FIXNUM(0))/*  TOO-FEW-ARGS */;
L12:
	(*LK2)(1,CAR((V1)))                       /*  C1EXPR          */;
	V3= VALUES(0);
	(*LK3)(2,(V2),CADR((V3)))                 /*  ADD-INFO        */;
	(*LK4)(1,CDR((V1)))                       /*  C1PROGN         */;
	V1= VALUES(0);
	(*LK3)(2,(V2),CADR((V1)))                 /*  ADD-INFO        */;
	VALUES(0) = list(4,VV[2],(V2),(V3),(V1));
	RETURN(1);
	}
}
/*	function definition for C2CATCH                               */
static L2(int narg, object V1, object V2)
{ VT4 VLEX4 CLSR4
	bds_check;
TTL:
	{register object V3;                      /*  NR              */
	object V4;                                /*  VALUES_NR       */
	(*LK5)(0)                                 /*  NEXT-LCL        */;
	V3= list(2,VV[3],VALUES(0));
	V4= list(2,VV[4],(V3));
	(*LK6)(1,code_char('\12'))                /*  WT1             */;
	(*LK6)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{ int ",symbol_value(VV[5]));
	(*LK6)(1,(V3))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[5]));
	{object V5;
	V5= list(2,VV[7],(V3));
	bds_bind(VV[6],V5);                       /*  *DESTINATION*   */
	(*LK7)(1,(V1))                            /*  C2EXPR*         */;
	bds_unwind1;
	}
	princ_str(" {",symbol_value(VV[5]));
	bds_bind(VV[6],(V4));                     /*  *DESTINATION*   */
	(*LK7)(1,(V2))                            /*  C2EXPR*         */;
	bds_unwind1;
	(*LK6)(1,code_char('\12'))                /*  WT1             */;
	(*LK6)(1,code_char('\11'))                /*  WT1             */;
	princ_char(125,symbol_value(VV[5]));
	(*LK6)(1,code_char('\12'))                /*  WT1             */;
	(*LK6)(1,code_char('\11'))                /*  WT1             */;
	princ_str("else ",symbol_value(VV[5]));
	(*LK6)(1,(V3))                            /*  WT1             */;
	princ_str("--;",symbol_value(VV[5]));
	(*LK6)(1,code_char('\12'))                /*  WT1             */;
	(*LK6)(1,code_char('\11'))                /*  WT1             */;
	princ_str("frs_pop();",symbol_value(VV[5]));
	(*LK8)(1,(V4))                            /*  UNWIND-EXIT     */;
	princ_char(125,symbol_value(VV[5]));
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-PUSH-CATCH-FRAME                  */
static L3(int narg, object V1, object V2)
{ VT5 VLEX5 CLSR5
TTL:
	if(!(type_of((V2))==t_cons)){
	goto L51;}
	if(!((CAR((V2)))==(VV[4]))){
	goto L51;}
	V2= CADR((V2));
L51:
	(*LK6)(1,code_char('\12'))                /*  WT1             */;
	(*LK6)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if ((",symbol_value(VV[5]));
	(*LK6)(1,(V2))                            /*  WT1             */;
	princ_str("=frs_push(FRS_CATCH,",symbol_value(VV[5]));
	(*LK6)(1,(V1))                            /*  WT1             */;
	princ_str("))==0)",symbol_value(VV[5]));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for C1UNWIND-PROTECT                      */
static L4(int narg, object V1)
{ VT6 VLEX6 CLSR6
	bds_check;
TTL:
	{object V2;                               /*  INFO            */
	object V3;                                /*  FORM            */
	(*LK0)(2,VV[0],Ct)                        /*  MAKE-INFO       */;
	V2= VALUES(0);
	V3= Cnil;
	(VV[1]->s.s_dbind)= number_plus((VV[1]->s.s_dbind),MAKE_FIXNUM(1));
	if(!((V1)==Cnil)){
	goto L68;}
	(*LK1)(3,VV[8],MAKE_FIXNUM(1),MAKE_FIXNUM(0))/*  TOO-FEW-ARGS */;
L68:
	{object V4;
	object V5;
	V4= CONS(VV[8],(VV[9]->s.s_dbind));
	V5= CONS(VV[8],(VV[10]->s.s_dbind));
	bds_bind(VV[9],V4);                       /*  *BLOCKS*        */
	bds_bind(VV[10],V5);                      /*  *TAGS*          */
	(*LK2)(1,CAR((V1)))                       /*  C1EXPR          */;
	V3= VALUES(0);
	bds_unwind1;
	bds_unwind1;
	}
	(*LK3)(2,(V2),CADR((V3)))                 /*  ADD-INFO        */;
	(*LK4)(1,CDR((V1)))                       /*  C1PROGN         */;
	V1= VALUES(0);
	(*LK3)(2,(V2),CADR((V1)))                 /*  ADD-INFO        */;
	VALUES(0) = list(4,VV[8],(V2),(V3),(V1));
	RETURN(1);
	}
}
/*	function definition for C2UNWIND-PROTECT                      */
static L5(int narg, object V1, object V2)
{ VT7 VLEX7 CLSR7
	bds_check;
TTL:
	{register object V3;                      /*  NR              */
	object V4;                                /*  VALUES_NR       */
	(*LK5)(0)                                 /*  NEXT-LCL        */;
	V3= list(2,VV[3],VALUES(0));
	V4= list(2,VV[4],(V3));
	(*LK6)(1,code_char('\12'))                /*  WT1             */;
	(*LK6)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{ int ",symbol_value(VV[5]));
	(*LK6)(1,(V3))                            /*  WT1             */;
	princ_str("; volatile bool unwinding = FALSE;",symbol_value(VV[5]));
	(*LK6)(1,code_char('\12'))                /*  WT1             */;
	(*LK6)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if ((",symbol_value(VV[5]));
	(*LK6)(1,(V3))                            /*  WT1             */;
	princ_str("=frs_push(FRS_PROTECT,Cnil))) {",symbol_value(VV[5]));
	(*LK6)(1,code_char('\12'))                /*  WT1             */;
	(*LK6)(1,code_char('\11'))                /*  WT1             */;
	(*LK6)(1,(V3))                            /*  WT1             */;
	princ_str("--; unwinding = TRUE;} else {",symbol_value(VV[5]));
	bds_bind(VV[6],(V4));                     /*  *DESTINATION*   */
	(*LK7)(1,(V1))                            /*  C2EXPR*         */;
	bds_unwind1;
	(*LK6)(1,code_char('\12'))                /*  WT1             */;
	(*LK6)(1,code_char('\11'))                /*  WT1             */;
	princ_char(125,symbol_value(VV[5]));
	(*LK6)(1,code_char('\12'))                /*  WT1             */;
	(*LK6)(1,code_char('\11'))                /*  WT1             */;
	princ_str("frs_pop();",symbol_value(VV[5]));
	(*LK6)(1,code_char('\12'))                /*  WT1             */;
	(*LK6)(1,code_char('\11'))                /*  WT1             */;
	princ_str("MV_SAVE(",symbol_value(VV[5]));
	(*LK6)(1,(V3))                            /*  WT1             */;
	princ_str(");",symbol_value(VV[5]));
	bds_bind(VV[6],VV[11]);                   /*  *DESTINATION*   */
	(*LK7)(1,(V2))                            /*  C2EXPR*         */;
	bds_unwind1;
	(*LK6)(1,code_char('\12'))                /*  WT1             */;
	(*LK6)(1,code_char('\11'))                /*  WT1             */;
	princ_str("MV_RESTORE(",symbol_value(VV[5]));
	(*LK6)(1,(V3))                            /*  WT1             */;
	princ_str(");",symbol_value(VV[5]));
	(*LK6)(1,code_char('\12'))                /*  WT1             */;
	(*LK6)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if (unwinding) unwind(nlj_fr,nlj_tag,",symbol_value(VV[5]));
	(*LK6)(1,(V3))                            /*  WT1             */;
	princ_str("+1);",symbol_value(VV[5]));
	(*LK6)(1,code_char('\12'))                /*  WT1             */;
	(*LK6)(1,code_char('\11'))                /*  WT1             */;
	princ_str("else {",symbol_value(VV[5]));
	(*LK8)(1,(V4))                            /*  UNWIND-EXIT     */;
	princ_str("}}",symbol_value(VV[5]));
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for C1THROW                               */
static L6(int narg, object V1)
{ VT8 VLEX8 CLSR8
TTL:
	{object V2;                               /*  INFO            */
	object V3;                                /*  TAG             */
	(*LK0)(0)                                 /*  MAKE-INFO       */;
	V2= VALUES(0);
	V3= Cnil;
	if((V1)==Cnil){
	goto L136;}
	if(!(CDR((V1))==Cnil)){
	goto L135;}
L136:
	(*LK1)(3,VV[12],MAKE_FIXNUM(2),MAKE_FIXNUM(length((V1))))/*  TOO-FEW-ARGS*/;
L135:
	if(CDDR((V1))==Cnil){
	goto L140;}
	(*LK9)(3,VV[12],MAKE_FIXNUM(2),MAKE_FIXNUM(length((V1))))/*  TOO-MANY-ARGS*/;
L140:
	(*LK2)(1,CAR((V1)))                       /*  C1EXPR          */;
	V3= VALUES(0);
	(*LK3)(2,(V2),CADR((V3)))                 /*  ADD-INFO        */;
	(*LK2)(1,CADR((V1)))                      /*  C1EXPR          */;
	V1= VALUES(0);
	(*LK3)(2,(V2),CADR((V1)))                 /*  ADD-INFO        */;
	VALUES(0) = list(4,VV[12],(V2),(V3),(V1));
	RETURN(1);
	}
}
/*	function definition for C2THROW                               */
static L7(int narg, object V1, object V2)
{ VT9 VLEX9 CLSR9
	bds_check;
TTL:
	{register object V3;                      /*  LOC             */
	object V4;                                /*  NR              */
	V3= Cnil;
	(*LK5)(0)                                 /*  NEXT-LCL        */;
	V4= list(2,VV[3],VALUES(0));
	(*LK6)(1,code_char('\12'))                /*  WT1             */;
	(*LK6)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{frame_ptr fr; int ",symbol_value(VV[5]));
	(*LK6)(1,(V4))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[5]));
	{object V5= CAR((V1));
	if((V5!= VV[35]))goto L159;
	V3= CADDR((V1));
	goto L158;
L159:
	if((V5!= VV[13]))goto L161;
	V3= CONS(VV[13],CADDR((V1)));
	goto L158;
L161:
	(*LK10)(0)                                /*  NEXT-TEMP       */;
	V3= list(2,VV[14],VALUES(0));
	bds_bind(VV[6],(V3));                     /*  *DESTINATION*   */
	(*LK7)(1,(V1))                            /*  C2EXPR*         */;
	bds_unwind1;}
L158:
	(*LK6)(1,code_char('\12'))                /*  WT1             */;
	(*LK6)(1,code_char('\11'))                /*  WT1             */;
	princ_str("fr=frs_sch_catch(",symbol_value(VV[5]));
	(*LK6)(1,(V3))                            /*  WT1             */;
	princ_str(");",symbol_value(VV[5]));
	(*LK6)(1,code_char('\12'))                /*  WT1             */;
	(*LK6)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if (fr==NULL) FEerror(\"The tag ~s is undefined.\",1,",symbol_value(VV[5]));
	(*LK6)(1,(V3))                            /*  WT1             */;
	princ_str(");",symbol_value(VV[5]));
	{object V5;
	V5= list(2,VV[4],(V4));
	bds_bind(VV[6],V5);                       /*  *DESTINATION*   */
	(*LK7)(1,(V2))                            /*  C2EXPR*         */;
	bds_unwind1;
	}
	(*LK6)(1,code_char('\12'))                /*  WT1             */;
	(*LK6)(1,code_char('\11'))                /*  WT1             */;
	princ_str("unwind(fr,",symbol_value(VV[5]));
	(*LK6)(1,(V3))                            /*  WT1             */;
	princ_char(44,symbol_value(VV[5]));
	(*LK6)(1,(V4))                            /*  WT1             */;
	princ_str("+1);}",symbol_value(VV[5]));
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
static LKF10(int narg, ...) {TRAMPOLINK(VV[36],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[34],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[33],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[32],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[31],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[30],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[29],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[28],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[27],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[26],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[25],&LK0);}
