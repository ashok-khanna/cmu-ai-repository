
/* (c) Copyright G. Attardi, 1993. All rights reserved. */
#define VT2
#define VLEX2
#define CLSR2
static L1(int narg, object, ...);
static intUobject L1keys[8]={6,5,7,11,9,37,38,39};
int siLmake_vector();
int Lerror();
int siLmake_pure_array();
int Lmake_list();
int siLaset();
int Lmake_list();
int siLaset();
#define VT3 object T0,T1,T2,T3,T4,T5;
#define VLEX3
#define CLSR3
static L2(int narg, object, object);
int Lcar();
int Lcar();
int Lcar();
#define VT4
#define VLEX4
#define CLSR4
static L3(int narg, object, object);
int Lcar();
#define VT5
#define VLEX5
#define CLSR5
static L4(int narg, ...);
#define VT6
#define VLEX6
#define CLSR6
static L5(int narg, object);
int Larray_rank();
int Larray_dimension();
#define VT7
#define VLEX7
#define CLSR7
static L6(int narg, object, ...);
int Larray_rank();
int Lerror();
int Larray_dimension();
#define VT8
#define VLEX8
#define CLSR8
static L7(int narg, object, ...);
int Larray_dimension();
#define VT9
#define VLEX9
#define CLSR9
static L8(int narg, object, ...);
int Laref();
#define VT10 object T0,T1;
#define VLEX10
#define CLSR10
static L10(int narg, object, object, ...);
int siLbit_array_op();
#define VT11
#define VLEX11
#define CLSR11
static L11(int narg, object, object, ...);
int siLbit_array_op();
#define VT12
#define VLEX12
#define CLSR12
static L12(int narg, object, object, ...);
int siLbit_array_op();
#define VT13
#define VLEX13
#define CLSR13
static L13(int narg, object, object, ...);
int siLbit_array_op();
#define VT14
#define VLEX14
#define CLSR14
static L14(int narg, object, object, ...);
int siLbit_array_op();
#define VT15
#define VLEX15
#define CLSR15
static L15(int narg, object, object, ...);
int siLbit_array_op();
#define VT16
#define VLEX16
#define CLSR16
static L16(int narg, object, object, ...);
int siLbit_array_op();
#define VT17
#define VLEX17
#define CLSR17
static L17(int narg, object, object, ...);
int siLbit_array_op();
#define VT18
#define VLEX18
#define CLSR18
static L18(int narg, object, object, ...);
int siLbit_array_op();
#define VT19
#define VLEX19
#define CLSR19
static L19(int narg, object, object, ...);
int siLbit_array_op();
#define VT20
#define VLEX20
#define CLSR20
static L20(int narg, object, ...);
int siLbit_array_op();
#define VT21
#define VLEX21
#define CLSR21
static L21(int narg, object, object);
int Lfill_pointer();
int Larray_dimension();
int siLfill_pointer_set();
#define VT22
#define VLEX22
#define CLSR22
static L22(int narg, object, object, ...);
int Lfill_pointer();
int Larray_dimension();
int siLfill_pointer_set();
int Larray_dimension();
int Larray_dimension();
int Larray_dimension();
int Larray_element_type();
int siLfill_pointer_set();
#define VT23 object T0;
#define VLEX23
#define CLSR23
static L23(int narg, object);
int Lfill_pointer();
int Lerror();
int siLfill_pointer_set();
#define VT24
#define VLEX24
#define CLSR24
static L24(int narg, object, object, ...);
static intUobject L24keys[7]={6,5,7,9,37,38,39};
int Larray_element_type();
int Lmake_list();
int Laref();
int siLaset();
int siLreplace_array();
#define VT25 object T0,T1,T2,T3;
#define VLEX25
#define CLSR25
static struct codeblock Cblock;
#define VM25 4
#define VM24 0
#define VM23 1
#define VM22 0
#define VM21 0
#define VM20 0
#define VM19 0
#define VM18 0
#define VM17 0
#define VM16 0
#define VM15 0
#define VM14 0
#define VM13 0
#define VM12 0
#define VM11 0
#define VM10 2
#define VM9 0
#define VM8 0
#define VM7 0
#define VM6 0
#define VM5 0
#define VM4 0
#define VM3 6
#define VM2 0
#define VM1 41
static object VV[41];
static LKF0(int, ...);
static (*LK0)(int, ...)=LKF0;
