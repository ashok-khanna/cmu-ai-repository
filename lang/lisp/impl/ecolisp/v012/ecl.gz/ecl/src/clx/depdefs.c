
#include "depdefs.h"
init_code(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_code; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	MM0(VV[150],L1);
	funcall(2,VV[1]->s.s_gfdef,VV[3])         /*  PROCLAIM        */;
	funcall(2,VV[1]->s.s_gfdef,VV[4])         /*  PROCLAIM        */;
	funcall(2,VV[1]->s.s_gfdef,VV[5])         /*  PROCLAIM        */;
	funcall(2,VV[1]->s.s_gfdef,VV[6])         /*  PROCLAIM        */;
	funcall(2,VV[1]->s.s_gfdef,VV[7])         /*  PROCLAIM        */;
	funcall(2,VV[1]->s.s_gfdef,VV[8])         /*  PROCLAIM        */;
	(void)putprop(VV[151],VV[13],siSpretty_print_format);
	
	MM0(VV[151],L3);
	(void)putprop(VV[104],VV[13],siSpretty_print_format);
	
	MM0(VV[104],L4);
	siLAmake_constant(2,VV[14],VV[15])        /*  *MAKE-CONSTANT  */;
	MM0(VV[152],L5);
	MM0(VV[153],L6);
	MM0(VV[154],L7);
	funcall(1,VV[155]->s.s_gfdef)             /*  LITTLE-ENDIAN-P */;
	if(VALUES(0)==Cnil){
	goto L9;}
	Ladjoin(2,VV[20],(VV[19]->s.s_dbind))     /*  ADJOIN          */;
	(VV[19]->s.s_dbind)= VALUES(0);
L9:
	putprop(VV[21],VV[23],VV[22]);
	VV[156] = make_cfun(LC8,Cnil,&Cblock);
	VALUES(0) = VV[156];
	putprop(VV[21],VALUES(0),VV[24]);
	putprop(VV[21],Cnil,VV[26]);
	MF0(VV[157],L9);
	(void)putprop(VV[157],VV[Vdeb157],VV[158]);
	MF0(VV[159],L10);
	(void)putprop(VV[159],VV[Vdeb159],VV[158]);
	MM0(VV[160],L11);
	MM0(VV[161],L12);
	MM0(VV[162],L13);
	MM0(VV[163],L14);
	MM0(VV[164],L15);
	MM0(VV[165],L16);
	MM0(VV[166],L17);
	MM0(VV[167],L18);
	MM0(VV[168],L19);
	MM0(VV[169],L20);
	MM0(VV[170],L21);
	MM0(VV[171],L22);
	MM0(VV[172],L23);
	MM0(VV[173],L24);
	MM0(VV[174],L25);
	MM0(VV[175],L26);
	MM0(VV[176],L27);
	MM0(VV[177],L28);
	MM0(VV[178],L29);
	MM0(VV[179],L30);
	MM0(VV[180],L31);
	MM0(VV[181],L32);
	MM0(VV[182],L33);
	MM0(VV[183],L34);
	MM0(VV[184],L35);
	siLAmake_constant(2,VV[56],MAKE_FIXNUM(32))/*  *MAKE-CONSTANT */;
	VV[58]->s.s_stype=(short)stp_special;
	if(VV[58]->s.s_dbind == OBJNULL){
	funcall(3,VV[185]->s.s_gfdef,VV[57],MAKE_FIXNUM(0))/*  MAKE-SEQUENCE*/;
	(VV[58]->s.s_dbind)= VALUES(0);}
	funcall(2,VV[1]->s.s_gfdef,VV[59])        /*  PROCLAIM        */;
	funcall(2,VV[186]->s.s_gfdef,VV[60])      /*  FIND-CLASS      */;
	funcall(9,VV[187]->s.s_gfdef,VALUES(0),VV[61],VV[62],VV[63],Cnil,VV[64],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[186]->s.s_gfdef,VV[61])      /*  FIND-CLASS      */;
	funcall(13,VV[188]->s.s_gfdef,VV[61],VV[65],Cnil,Cnil,VV[66],VV[67],Cnil,Cnil,Cnil,VV[68],MAKE_FIXNUM(4),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0key(VV[189],L36,4,L36keys);
	(void)putprop(VV[189],VV[Vdeb189],VV[158]);
	siLAmake_constant(2,VV[69],MAKE_FIXNUM(256))/*  *MAKE-CONSTANT*/;
	putprop(VV[70],VV[71],VV[22]);
	VV[190] = make_cfun(LC37,Cnil,&Cblock);
	VALUES(0) = VV[190];
	putprop(VV[70],VALUES(0),VV[24]);
	putprop(VV[70],Cnil,VV[26]);
	siLAmake_special(1,VV[74])                /*  *MAKE-SPECIAL   */;
	Lfind_package(1,VV[75])                   /*  FIND-PACKAGE    */;
	(VV[74]->s.s_dbind)= VALUES(0);
	MF0(VV[191],L38);
	(void)putprop(VV[191],VV[Vdeb191],VV[158]);
	siLAmake_special(1,VV[77])                /*  *MAKE-SPECIAL   */;
	Lfind_package(1,VV[78])                   /*  FIND-PACKAGE    */;
	(VV[77]->s.s_dbind)= VALUES(0);
	MF0(VV[192],L39);
	(void)putprop(VV[192],VV[Vdeb192],VV[158]);
	VV[80]->s.s_stype=(short)stp_special;
	if(VV[80]->s.s_dbind == OBJNULL){
	(VV[80]->s.s_dbind)= Cnil;}
	(void)putprop(VV[80],VV[79],siSvariable_documentation);
	
	(void)putprop(VV[97],VV[13],siSpretty_print_format);
	
	MM0(VV[97],L40);
	funcall(2,VV[186]->s.s_gfdef,VV[60])      /*  FIND-CLASS      */;
	funcall(9,VV[187]->s.s_gfdef,VALUES(0),VV[127],VV[128],VV[129],Cnil,VV[130],Cnil,Cnil)/*  DEFINE-A-CLASS*/;
	funcall(2,VV[186]->s.s_gfdef,VV[127])     /*  FIND-CLASS      */;
	funcall(13,VV[188]->s.s_gfdef,VV[127],VV[131],Cnil,Cnil,VV[132],VV[133],Cnil,Cnil,Cnil,Cnil,MAKE_FIXNUM(18),Cnil)/*  DEFINE-STRUCTURE*/;
	MF0(VV[144],L47);
	(void)putprop(VV[144],VV[Vdeb144],VV[158]);
	(void)putprop(VV[193],VV[13],siSpretty_print_format);
	
	MM0(VV[193],L48);
	siLAmake_constant(2,VV[146],Cnil)         /*  *MAKE-CONSTANT  */;
	siLAmake_constant(2,VV[147],Cnil)         /*  *MAKE-CONSTANT  */;
	siLAmake_constant(2,VV[148],MAKE_FIXNUM(32))/*  *MAKE-CONSTANT*/;
	siLAmake_constant(2,VV[149],MAKE_FIXNUM(32))/*  *MAKE-CONSTANT*/;
	Cblock.cd_start=(char *)end_init;
	Cblock.cd_size-=(char *)end_init - (char *)init_code;
	insert_contblock((char *)init_code,(char *)end_init - (char *)init_code);
}
static end_init() {}
/*	local function CLOSURE                                        */
static LC37(int narg)
{ VT3 VLEX3 CLSR3
	VALUES(0) = list(3,VV[72],VV[73],CONS(MAKE_FIXNUM(256),Cnil));
	RETURN(1);
}
/*	local function CLOSURE                                        */
static LC8(int narg)
{ VT4 VLEX4 CLSR4
	VALUES(0) = list(3,VV[25],MAKE_FIXNUM(0),MAKE_FIXNUM(16777216));
	RETURN(1);
}
/*	macro definition for DECLAIM                                  */
static L1(int narg, object V1, object V2)
{ VT5 VLEX5 CLSR5
	{object V3=CDR(V1),V4;
	V4= V3;
	if((CDR((V4)))==Cnil){
	goto L57;}
	{object V5;
	object V6= (V4);
	if(V6==Cnil){
	VALUES(0) = Cnil;
	goto L59;}
	T0=V5=CONS(Cnil,Cnil);
L60:
	{object V7;                               /*  DECL-SPEC       */
	CAR(V5)= list(2,VV[1],list(2,VV[2],CAR(V6)));
	}
	if((V6=CDR(V6))==Cnil){
	VALUES(0) = T0;
	goto L59;}
	V5=CDR(V5)=CONS(Cnil,Cnil);
	goto L60;}
L59:
	VALUES(0) = CONS(VV[0],VALUES(0));
	RETURN(1);
L57:
	VALUES(0) = list(2,VV[1],list(2,VV[2],CAR((V4))));
	RETURN(1);}
}
/*	macro definition for WITH-VECTOR                              */
static L3(int narg, object V1, object V2)
{ VT6 VLEX6 CLSR6
	{object V3=CDR(V1),V4,V5,V6;
	{object V7= CAR(V3);
	V4= CAR(V7);
	V7=CDR(V7);
	V5= CAR(V7);}
	V3=CDR(V3);
	V6= V3;
	{object V8= CONS(list(2,(V4),(V4)),Cnil);
	{object V9= list(3,VV[11],(V5),(V4));
	VALUES(0) = listA(4,VV[9],(V8),list(3,VV[10],(V9),list(2,VV[12],(V4))),(V6));
	RETURN(1);}}}
}
/*	macro definition for WITHIN-DEFINITION                        */
static L4(int narg, object V1, object V2)
{ VT7 VLEX7 CLSR7
	{object V3=CDR(V1),V4,V5,V6;
	{object V7= CAR(V3);
	V4= CAR(V7);
	V7=CDR(V7);
	V5= CAR(V7);}
	V3=CDR(V3);
	V6= V3;
	VALUES(0) = CONS(VV[0],(V6));
	RETURN(1);}
}
/*	macro definition for RESOURCE-ID-MAP-TEST                     */
static L5(int narg, object V1, object V2)
{ VT8 VLEX8 CLSR8
	{object V3=CDR(V1);
	VALUES(0) = VV[16];
	RETURN(1);}
}
/*	macro definition for ATOM-CACHE-MAP-TEST                      */
static L6(int narg, object V1, object V2)
{ VT9 VLEX9 CLSR9
	{object V3=CDR(V1);
	VALUES(0) = VV[17];
	RETURN(1);}
}
/*	macro definition for KEYSYM->CHARACTER-MAP-TEST               */
static L7(int narg, object V1, object V2)
{ VT10 VLEX10 CLSR10
	{object V3=CDR(V1);
	VALUES(0) = VV[18];
	RETURN(1);}
}
/*	function definition for MAKE-INDEX-TYPED                      */
static L9(int narg, object V1)
{ VT11 VLEX11 CLSR11
TTL:
	Lconstantp(1,(V1))                        /*  CONSTANTP       */;
	if(VALUES(0)==Cnil){
	goto L63;}
	VALUES(0) = (V1);
	RETURN(1);
L63:
	VALUES(0) = list(3,VV[27],VV[21],(V1));
	RETURN(1);
}
/*	function definition for MAKE-INDEX-OP                         */
static L10(int narg, object V1, object V2)
{ VT12 VLEX12 CLSR12
TTL:
	{object V3= MAKE_FIXNUM(length((V2)));
	if(!eql(V3,VV[29]))goto L66;
	VALUES(0) = CONS((V1),Cnil);
	goto L65;
L66:
	if(!eql(V3,VV[13]))goto L67;
	L9(1,CAR((V2)))                           /*  MAKE-INDEX-TYPED*/;
	VALUES(0) = list(2,(V1),VALUES(0));
	goto L65;
L67:
	if(!eql(V3,VV[30]))goto L69;
	L9(1,CAR((V2)))                           /*  MAKE-INDEX-TYPED*/;
	T0= VALUES(0);
	L9(1,CADR((V2)))                          /*  MAKE-INDEX-TYPED*/;
	VALUES(0) = list(3,(V1),T0,VALUES(0));
	goto L65;
L69:
	Lsubseq(3,(V2),MAKE_FIXNUM(0),one_minus(MAKE_FIXNUM(length((V2)))))/*  SUBSEQ*/;
	L10(2,(V1),VALUES(0))                     /*  MAKE-INDEX-OP   */;
	T1= VALUES(0);
	Llast(1,(V2))                             /*  LAST            */;
	L9(1,CAR(VALUES(0)))                      /*  MAKE-INDEX-TYPED*/;
	VALUES(0) = list(3,(V1),T1,VALUES(0));}
L65:
	VALUES(0) = list(3,VV[27],VV[21],list(2,VV[28],VALUES(0)));
	RETURN(1);
}
/*	macro definition for INDEX+                                   */
static L11(int narg, object V1, object V2)
{ VT13 VLEX13 CLSR13
	{object V3=CDR(V1),V4;
	V4= V3;
	RETURN(L10(2,VV[31],(V4))                 /*  MAKE-INDEX-OP   */);}
}
/*	macro definition for INDEX-LOGAND                             */
static L12(int narg, object V1, object V2)
{ VT14 VLEX14 CLSR14
	{object V3=CDR(V1),V4;
	V4= V3;
	RETURN(L10(2,VV[32],(V4))                 /*  MAKE-INDEX-OP   */);}
}
/*	macro definition for INDEX-LOGIOR                             */
static L13(int narg, object V1, object V2)
{ VT15 VLEX15 CLSR15
	{object V3=CDR(V1),V4;
	V4= V3;
	RETURN(L10(2,VV[33],(V4))                 /*  MAKE-INDEX-OP   */);}
}
/*	macro definition for INDEX-                                   */
static L14(int narg, object V1, object V2)
{ VT16 VLEX16 CLSR16
	{object V3=CDR(V1),V4;
	V4= V3;
	RETURN(L10(2,VV[34],(V4))                 /*  MAKE-INDEX-OP   */);}
}
/*	macro definition for INDEX*                                   */
static L15(int narg, object V1, object V2)
{ VT17 VLEX17 CLSR17
	{object V3=CDR(V1),V4;
	V4= V3;
	RETURN(L10(2,VV[35],(V4))                 /*  MAKE-INDEX-OP   */);}
}
/*	macro definition for INDEX1+                                  */
static L16(int narg, object V1, object V2)
{ VT18 VLEX18 CLSR18
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	RETURN(L10(2,VV[36],CONS((V4),Cnil))      /*  MAKE-INDEX-OP   */);}
}
/*	macro definition for INDEX1-                                  */
static L17(int narg, object V1, object V2)
{ VT19 VLEX19 CLSR19
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	RETURN(L10(2,VV[37],CONS((V4),Cnil))      /*  MAKE-INDEX-OP   */);}
}
/*	macro definition for INDEX-INCF                               */
static L18(int narg, object V1, object V2)
{ VT20 VLEX20 CLSR20
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	if(endp(V3)){
	V5= MAKE_FIXNUM(1);
	} else {
	V5= CAR(V3);}
	RETURN(L10(2,VV[38],list(2,(V4),(V5)))    /*  MAKE-INDEX-OP   */);}
}
/*	macro definition for INDEX-DECF                               */
static L19(int narg, object V1, object V2)
{ VT21 VLEX21 CLSR21
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	if(endp(V3)){
	V5= MAKE_FIXNUM(1);
	} else {
	V5= CAR(V3);}
	RETURN(L10(2,VV[39],list(2,(V4),(V5)))    /*  MAKE-INDEX-OP   */);}
}
/*	macro definition for INDEX-MIN                                */
static L20(int narg, object V1, object V2)
{ VT22 VLEX22 CLSR22
	{object V3=CDR(V1),V4;
	V4= V3;
	RETURN(L10(2,VV[40],(V4))                 /*  MAKE-INDEX-OP   */);}
}
/*	macro definition for INDEX-MAX                                */
static L21(int narg, object V1, object V2)
{ VT23 VLEX23 CLSR23
	{object V3=CDR(V1),V4;
	V4= V3;
	RETURN(L10(2,VV[41],(V4))                 /*  MAKE-INDEX-OP   */);}
}
/*	macro definition for INDEX-FLOOR                              */
static L22(int narg, object V1, object V2)
{ VT24 VLEX24 CLSR24
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	RETURN(L10(2,VV[42],list(2,(V4),(V5)))    /*  MAKE-INDEX-OP   */);}
}
/*	macro definition for INDEX-CEILING                            */
static L23(int narg, object V1, object V2)
{ VT25 VLEX25 CLSR25
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	RETURN(L10(2,VV[43],list(2,(V4),(V5)))    /*  MAKE-INDEX-OP   */);}
}
/*	macro definition for INDEX-TRUNCATE                           */
static L24(int narg, object V1, object V2)
{ VT26 VLEX26 CLSR26
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	RETURN(L10(2,VV[44],list(2,(V4),(V5)))    /*  MAKE-INDEX-OP   */);}
}
/*	macro definition for INDEX-MOD                                */
static L25(int narg, object V1, object V2)
{ VT27 VLEX27 CLSR27
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	RETURN(L10(2,VV[45],list(2,(V4),(V5)))    /*  MAKE-INDEX-OP   */);}
}
/*	macro definition for INDEX-ASH                                */
static L26(int narg, object V1, object V2)
{ VT28 VLEX28 CLSR28
	{object V3=CDR(V1),V4,V5;
	V4= CAR(V3);
	V3=CDR(V3);
	V5= CAR(V3);
	RETURN(L10(2,VV[46],list(2,(V4),(V5)))    /*  MAKE-INDEX-OP   */);}
}
/*	macro definition for INDEX-PLUSP                              */
static L27(int narg, object V1, object V2)
{ VT29 VLEX29 CLSR29
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(2,VV[47],list(3,VV[27],VV[21],(V4)));
	RETURN(1);}
}
/*	macro definition for INDEX-ZEROP                              */
static L28(int narg, object V1, object V2)
{ VT30 VLEX30 CLSR30
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(2,VV[48],list(3,VV[27],VV[21],(V4)));
	RETURN(1);}
}
/*	macro definition for INDEX-EVENP                              */
static L29(int narg, object V1, object V2)
{ VT31 VLEX31 CLSR31
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(2,VV[49],list(3,VV[27],VV[21],(V4)));
	RETURN(1);}
}
/*	macro definition for INDEX-ODDP                               */
static L30(int narg, object V1, object V2)
{ VT32 VLEX32 CLSR32
	{object V3=CDR(V1),V4;
	V4= CAR(V3);
	VALUES(0) = list(2,VV[50],list(3,VV[27],VV[21],(V4)));
	RETURN(1);}
}
/*	macro definition for INDEX>                                   */
static L31(int narg, object V1, object V2)
{ VT33 VLEX33 CLSR33
	{object V3=CDR(V1),V4;
	V4= V3;
	{object V5;
	object V6= (V4);
	if(V6==Cnil){
	VALUES(0) = Cnil;
	goto L78;}
	T0=V5=CONS(Cnil,Cnil);
L79:
	L9(1,CAR(V6))                             /*  MAKE-INDEX-TYPED*/;
	CAR(V5)= VALUES(0);
	if((V6=CDR(V6))==Cnil){
	VALUES(0) = T0;
	goto L78;}
	V5=CDR(V5)=CONS(Cnil,Cnil);
	goto L79;}
L78:
	VALUES(0) = CONS(VV[51],VALUES(0));
	RETURN(1);}
}
/*	macro definition for INDEX=                                   */
static L32(int narg, object V1, object V2)
{ VT34 VLEX34 CLSR34
	{object V3=CDR(V1),V4;
	V4= V3;
	{object V5;
	object V6= (V4);
	if(V6==Cnil){
	VALUES(0) = Cnil;
	goto L81;}
	T0=V5=CONS(Cnil,Cnil);
L82:
	L9(1,CAR(V6))                             /*  MAKE-INDEX-TYPED*/;
	CAR(V5)= VALUES(0);
	if((V6=CDR(V6))==Cnil){
	VALUES(0) = T0;
	goto L81;}
	V5=CDR(V5)=CONS(Cnil,Cnil);
	goto L82;}
L81:
	VALUES(0) = CONS(VV[52],VALUES(0));
	RETURN(1);}
}
/*	macro definition for INDEX<                                   */
static L33(int narg, object V1, object V2)
{ VT35 VLEX35 CLSR35
	{object V3=CDR(V1),V4;
	V4= V3;
	{object V5;
	object V6= (V4);
	if(V6==Cnil){
	VALUES(0) = Cnil;
	goto L84;}
	T0=V5=CONS(Cnil,Cnil);
L85:
	L9(1,CAR(V6))                             /*  MAKE-INDEX-TYPED*/;
	CAR(V5)= VALUES(0);
	if((V6=CDR(V6))==Cnil){
	VALUES(0) = T0;
	goto L84;}
	V5=CDR(V5)=CONS(Cnil,Cnil);
	goto L85;}
L84:
	VALUES(0) = CONS(VV[53],VALUES(0));
	RETURN(1);}
}
/*	macro definition for INDEX>=                                  */
static L34(int narg, object V1, object V2)
{ VT36 VLEX36 CLSR36
	{object V3=CDR(V1),V4;
	V4= V3;
	{object V5;
	object V6= (V4);
	if(V6==Cnil){
	VALUES(0) = Cnil;
	goto L87;}
	T0=V5=CONS(Cnil,Cnil);
L88:
	L9(1,CAR(V6))                             /*  MAKE-INDEX-TYPED*/;
	CAR(V5)= VALUES(0);
	if((V6=CDR(V6))==Cnil){
	VALUES(0) = T0;
	goto L87;}
	V5=CDR(V5)=CONS(Cnil,Cnil);
	goto L88;}
L87:
	VALUES(0) = CONS(VV[54],VALUES(0));
	RETURN(1);}
}
/*	macro definition for INDEX<=                                  */
static L35(int narg, object V1, object V2)
{ VT37 VLEX37 CLSR37
	{object V3=CDR(V1),V4;
	V4= V3;
	{object V5;
	object V6= (V4);
	if(V6==Cnil){
	VALUES(0) = Cnil;
	goto L90;}
	T0=V5=CONS(Cnil,Cnil);
L91:
	L9(1,CAR(V6))                             /*  MAKE-INDEX-TYPED*/;
	CAR(V5)= VALUES(0);
	if((V6=CDR(V6))==Cnil){
	VALUES(0) = T0;
	goto L90;}
	V5=CDR(V5)=CONS(Cnil,Cnil);
	goto L91;}
L90:
	VALUES(0) = CONS(VV[55],VALUES(0));
	RETURN(1);}
}
/*	function definition for MAKE-REPLY-BUFFER-INTERNAL            */
static L36(int narg, ...)
{ VT38 VLEX38 CLSR38
	{object V1;
	object V2;
	object V3;
	object V4;
	va_list args; va_start(args, narg);
	narg -=0;
	{ object keyvars[8];
	parse_key(narg,args,4,L36keys,keyvars,OBJNULL,FALSE);
	if(keyvars[4]==Cnil){
	V1= MAKE_FIXNUM(0);
	}else{
	V1= keyvars[0];}
	if(keyvars[5]==Cnil){
	V2= (VV[58]->s.s_dbind);
	}else{
	V2= keyvars[1];}
	V3= keyvars[2];
	if(keyvars[7]==Cnil){
	V4= MAKE_FIXNUM(0);
	}else{
	V4= keyvars[3];}
	}
	(*LK0)(1,VV[61])                          /*  FIND-CLASS      */;
	RETURN(siLmake_structure(5,VALUES(0),(V1),(V2),(V3),(V4))/*  MAKE-STRUCTURE*/);
	}
}
/*	function definition for XINTERN                               */
static L38(int narg, ...)
{ VT39 VLEX39 CLSR39
	{object V1;
	va_list args; va_start(args, narg);
	narg -=0;
	V1=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object p=V1;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	T0= (VV[201]->s.s_gfdef);
	{object V2;
	object V3= (V1);
	if(V3==Cnil){
	VALUES(0) = Cnil;
	goto L98;}
	T1=V2=CONS(Cnil,Cnil);
L99:
	CAR(V2)= coerce_to_string(CAR(V3));
	if((V3=CDR(V3))==Cnil){
	VALUES(0) = T1;
	goto L98;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L99;}
L98:
	Lapply(3,T0,VV[76],VALUES(0))             /*  APPLY           */;
	RETURN(Lintern(2,VALUES(0),(VV[74]->s.s_dbind))/*  INTERN     */);
	}
}
/*	function definition for KINTERN                               */
static L39(int narg, object V1)
{ VT40 VLEX40 CLSR40
TTL:
	RETURN(Lintern(2,coerce_to_string((V1)),(VV[77]->s.s_dbind))/*  INTERN*/);
}
/*	macro definition for DEF-CLX-CLASS                            */
static L40(int narg, object V1, object V2)
{ VT41 VLEX41 CLSR41
	bds_check;
	{object V3=CDR(V1),V4,V5;
	{object V6= CAR(V3);
	env0 = Cnil;
	CLV0=&CAR(env0=CONS(CAR(V6),env0));       /*  NAME            */
	V6=CDR(V6);
	V4= V6;}
	V3=CDR(V3);
	V5= V3;
	if(!(type_of((VV[80]->s.s_dbind))==t_cons||(VV[80]->s.s_dbind)==Cnil)){
	goto L102;}
	if((memql(*CLV0,(VV[80]->s.s_dbind)))==Cnil){
	goto L103;}
L102:
	{volatile object V7;
	volatile object V8;                       /*  INCLUDE         */
	volatile object V9;                       /*  PRINT-FUNCTION  */
	volatile object V10;                      /*  COPIER          */
	volatile object V11;                      /*  PREDICATE       */object env1 = env0;
	Lfind_package(1,VV[81])                   /*  FIND-PACKAGE    */;
	if(VALUES(0)==Cnil)goto L108;
	V7= VALUES(0);
	goto L107;
L108:
	Lfind_package(1,VV[82])                   /*  FIND-PACKAGE    */;
	if(VALUES(0)==Cnil)goto L110;
	V7= VALUES(0);
	goto L107;
L110:
	{object V12;                              /*  LISP-PKG        */
	Lfind_package(1,VV[83])                   /*  FIND-PACKAGE    */;
	V12= VALUES(0);
	Lfind_symbol(2,coerce_to_string(VV[84]),(V12))/*  FIND-SYMBOL */;
	if(VALUES(0)!=Cnil){
	goto L113;}
	V7= Cnil;
	goto L107;
L113:
	V7= (V12);
	}
L107:
	lex0[0]=V7;                               /*  CLOS-PACKAGE    */
	CLV1=&CAR(env1=CONS(Ct,env1));            /*  CONSTRUCTOR     */
	CLV2=&CAR(env1=CONS(Ct,env1));            /*  CONSTRUCTOR-ARGS*/
	V8= Cnil;
	V9= Cnil;
	V10= Ct;
	V11= Ct;
	{volatile object V12;
	volatile object V13;                      /*  OPTION          */
	V12= (V4);
	V13= Cnil;
L119:
	if(!((V12)==Cnil)){
	goto L120;}
	goto L115;
L120:
	V13= CAR((V12));
	{register object V15;
	{register object V16;
	V16= CAR((V13));
	V13= CDR((V13));
	V15= (V16);
	}
	if(!(eql((V15),VV[85]))){
	goto L131;}
	{register object V16;
	V16= CAR((V13));
	V13= CDR((V13));
	*CLV1= (V16);
	}
	if(((V13))!=Cnil){
	goto L140;}
	*CLV2= Ct;
	goto L138;
L140:
	{register object V16;
	V16= CAR((V13));
	V13= CDR((V13));
	*CLV2= (V16);
	}
L138:
	goto L125;
L131:
	if(!(eql((V15),VV[86]))){
	goto L146;}
	{register object V16;
	V16= CAR((V13));
	V13= CDR((V13));
	V8= (V16);
	}
	goto L125;
L146:
	if(!(eql((V15),VV[87]))){
	goto L153;}
	{register object V16;
	V16= CAR((V13));
	V13= CDR((V13));
	V9= (V16);
	}
	goto L125;
L153:
	if(!(eql((V15),VV[88]))){
	goto L160;}
	{register object V16;
	V16= CAR((V13));
	V13= CDR((V13));
	V10= (V16);
	}
	goto L125;
L160:
	if(!(eql((V15),VV[89]))){
	goto L167;}
	{register object V16;
	V16= CAR((V13));
	V13= CDR((V13));
	V11= (V16);
	}
	goto L125;
L167:
	bds_bind(VV[90],MAKE_FIXNUM(4));          /*  *PRINT-LEVEL*   */
	bds_bind(VV[91],MAKE_FIXNUM(4));          /*  *PRINT-LENGTH*  */
	Lerror(8,VV[92],VV[93],(V15),VV[85],VV[86],VV[87],VV[88],VV[89])/*  ERROR*/;
	bds_unwind1;
	bds_unwind1;
	}
L125:
	V12= CDR((V12));
	goto L119;
	}
L115:
	if(!((*CLV1)==(Ct))){
	goto L176;}
	LC44(2,VV[94],*CLV0)                      /*  CINTERN         */;
	*CLV1= VALUES(0);
L176:
	if(!(((V10))==(Ct))){
	goto L180;}
	LC44(2,VV[95],*CLV0)                      /*  CINTERN         */;
	V10= VALUES(0);
L180:
	if(!(((V11))==(Ct))){
	goto L184;}
	LC44(2,*CLV0,VV[96])                      /*  CINTERN         */;
	V11= VALUES(0);
L184:
	if(((V8))==Cnil){
	goto L188;}
	V5= append(getf((V8)->s.s_plist,VV[97],Cnil),(V5));
L188:
	{volatile int V12;                        /*  N-SLOTS         */
	volatile object V13;                      /*  SLOT-NAMES      */
	volatile object V14;                      /*  SLOT-INITFORMS  */
	volatile object V15;                      /*  SLOT-TYPES      */
	V12= length((V5));
	Lmake_list(1,MAKE_FIXNUM(V12))            /*  MAKE-LIST       */;
	V13= VALUES(0);
	Lmake_list(1,MAKE_FIXNUM(V12))            /*  MAKE-LIST       */;
	V14= VALUES(0);
	Lmake_list(1,MAKE_FIXNUM(V12))            /*  MAKE-LIST       */;
	V15= VALUES(0);
	{volatile object V16;
	volatile int V17;                         /*  I               */
	V16= MAKE_FIXNUM(V12);
	V17= 0;
L200:
	if(!(number_compare(MAKE_FIXNUM(V17),(V16))>=0)){
	goto L201;}
	goto L196;
L201:
	{register object V19;                     /*  SLOT            */
	V19= elt((V5),V17);
	{register object V20;
	V20= CAR((V19));
	V19= CDR((V19));
	VALUES(0) = (V20);
	}
	elt_set((V13),V17,VALUES(0));
	{register object V20;
	V20= CAR((V19));
	V19= CDR((V19));
	VALUES(0) = (V20);
	}
	elt_set((V14),V17,VALUES(0));
	Lgetf(3,(V19),VV[98],Ct)                  /*  GETF            */;
	elt_set((V15),V17,VALUES(0));
	}
	V17= (V17)+1;
	goto L200;
	}
L196:
	{object V16= list(3,VV[102],list(2,VV[2],*CLV0),VV[103]);
	{object V17= list(3,VV[99],VV[100],list(3,VV[101],(V16),list(2,VV[2],(V5))));
	{object V18= list(2,*CLV0,VV[97]);
	LC46(lex0,1,VV[84])                       /*  CLOSINTERN      */;
	T0= VALUES(0);
	if((V8)==Cnil){
	T1= Cnil;
	goto L221;}
	T1= CONS((V8),Cnil);
L221:
	VALUES(0) = make_cclosure(LC41,env1,&Cblock);
	(*LK1)(5,VV[105],VALUES(0),(V13),(V14),(V15))/*  MAP          */;
	{object V19= list(4,T0,*CLV0,T1,VALUES(0));
	if((*CLV1)==Cnil){
	goto L226;}
	if(!((*CLV2)==(Ct))){
	goto L229;}
	LC46(lex0,1,VV[113])                      /*  CLOSINTERN      */;
	{object V20= list(2,VV[112],VALUES(0));
	T2= list(4,VV[109],*CLV1,VV[110],list(4,VV[111],(V20),list(2,VV[2],*CLV0),VV[114]));
	goto L224;}
L229:
	LC46(lex0,1,VV[113])                      /*  CLOSINTERN      */;
	T3= VALUES(0);
	{object V21= list(2,VV[2],*CLV0);
	{object V22;
	object V23= *CLV2;
	if(V23==Cnil){
	VALUES(0) = Cnil;
	goto L233;}
	T4=V22=CONS(Cnil,Cnil);
L234:
	{volatile object V24;                     /*  SLOT-NAME       */
	V24= CAR(V23);
	if((memql((V24),(V13)))!=Cnil){
	goto L236;}
	CDR(V22)= Cnil;
	goto L235;
L236:
	LC45(1,(V24))                             /*  KINTERN         */;
	CDR(V22)= list(2,VALUES(0),(V24));
	}
L235:
	while(CDR(V22)!=Cnil)V22=CDR(V22);
	if((V23=CDR(V23))==Cnil){
	T4=CDR(T4);
	VALUES(0) = T4;
	goto L233;}
	goto L234;}
L233:
	T2= list(4,VV[109],*CLV1,*CLV2,listA(3,T3,(V21),VALUES(0)));
	goto L224;}
L226:
	T2= Cnil;
L224:
	if(((V11))==Cnil){
	goto L241;}
	T3= list(4,VV[109],(V11),VV[115],list(3,VV[116],VV[117],list(2,VV[2],*CLV0)));
	goto L239;
L241:
	T3= Cnil;
L239:
	if(((V10))==Cnil){
	goto L245;}
	LC46(lex0,1,VV[118])                      /*  CLOSINTERN      */;
	T5= VALUES(0);
	{object V20= CONS(list(2,VV[119],*CLV0),Cnil);
	LC46(lex0,1,VV[120])                      /*  CLOSINTERN      */;
	T6= VALUES(0);
	LC46(lex0,1,VV[113])                      /*  CLOSINTERN      */;
	T7= VALUES(0);
	{object V21= list(2,VV[2],*CLV0);
	{object V22;
	object V23= (V13);
	if(V23==Cnil){
	VALUES(0) = Cnil;
	goto L250;}
	T8=V22=CONS(Cnil,Cnil);
L251:
	{volatile object V24;                     /*  SLOT-NAME       */
	LC45(1,CAR(V23))                          /*  KINTERN         */;
	CDR(V22)= list(2,VALUES(0),CAR(V23));
	}
	while(CDR(V22)!=Cnil)V22=CDR(V22);
	if((V23=CDR(V23))==Cnil){
	T8=CDR(T8);
	VALUES(0) = T8;
	goto L250;}
	goto L251;}
L250:
	T4= list(4,T5,(V10),(V20),list(4,T6,(V13),VV[119],listA(3,T7,(V21),VALUES(0))));
	goto L243;}}
L245:
	T4= Cnil;
L243:
	if(((V9))==Cnil){
	goto L256;}
	LC46(lex0,1,VV[118])                      /*  CLOSINTERN      */;
	T5= VALUES(0);
	LC46(lex0,1,VV[121])                      /*  CLOSINTERN      */;
	T6= VALUES(0);
	{object V20= list(2,list(2,VV[117],*CLV0),VV[122]);
	VALUES(0) = list(4,T5,T6,(V20),CONS((V9),VV[123]));
	goto L254;}
L256:
	VALUES(0) = Cnil;
L254:
	VALUES(0) = list(3,VV[0],(V17),list(7,VV[104],(V18),(V19),T2,T3,T4,VALUES(0)));
	RETURN(1);}}}}
	}
	}
L103:
	{object V20= list(2,*CLV0,VV[97]);
	VALUES(0) = list(3,VV[104],(V20),listA(3,VV[126],CONS(*CLV0,(V4)),(V5)));
	RETURN(1);}}
}
/*	local function CINTERN                                        */
static LC44(int narg, ...)
{ VT42 VLEX42 CLSR42
	{object V1;
	va_list args; va_start(args, narg);
	narg -=0;
	V1=(Lmake_list(1,MAKE_FIXNUM(narg)), VALUES(0));
	{ object p=V1;
	 for(;narg-->0;p=CDR(p))
	   CAR(p)=va_arg(args, object);}
	T0= (VV[201]->s.s_gfdef);
	{object V2;
	object V3= (V1);
	if(V3==Cnil){
	VALUES(0) = Cnil;
	goto L261;}
	T1=V2=CONS(Cnil,Cnil);
L262:
	CAR(V2)= symbol_name(CAR(V3));
	if((V3=CDR(V3))==Cnil){
	VALUES(0) = T1;
	goto L261;}
	V2=CDR(V2)=CONS(Cnil,Cnil);
	goto L262;}
L261:
	Lapply(3,T0,VV[124],VALUES(0))            /*  APPLY           */;
	RETURN(Lintern(2,VALUES(0),(VV[125]->s.s_dbind))/*  INTERN    */);
	}
}
/*	local function KINTERN                                        */
static LC45(int narg, object V1)
{ VT43 VLEX43 CLSR43
TTL:
	{object V2= symbol_name((V1));
	Lfind_package(1,VV[78])                   /*  FIND-PACKAGE    */;
	RETURN(Lintern(2,(V2),VALUES(0))          /*  INTERN          */);}
}
/*	local function CLOSINTERN                                     */
static LC46(object *lex0,int narg, object V1)
{ VT44 VLEX44 CLSR44
TTL:
	RETURN(Lintern(2,symbol_name((V1)),lex0[0])/*  INTERN         */);
}
/*	closure CLOSURE                                               */
static LC41(int narg, object env0, object V1, object V2, object V3)
{ VT45 VLEX45 CLSR45
	narg--;
	{object scan=env0;
	CLV2= &CAR(scan);                         /*  CONSTRUCTOR-ARGS*/ scan=CDR(scan);
	CLV1= &CAR(scan);                         /*  CONSTRUCTOR     */ scan=CDR(scan);
	CLV0= &CAR(scan);                         /*  KINTERN         */}
	LC44(3,*CLV0,VV[34],(V1))                 /*  CINTERN         */;
	T0= VALUES(0);
	if((*CLV1)==Cnil){
	goto L269;}
	if((*CLV2)==(Ct)){
	goto L268;}
	if((memql((V1),*CLV2))==Cnil){
	goto L269;}
L268:
	LC45(1,(V1))                              /*  KINTERN         */;
	VALUES(0) = list(2,VV[108],VALUES(0));
	goto L267;
L269:
	VALUES(0) = Cnil;
L267:
	VALUES(0) = listA(8,(V1),VV[106],(V2),VV[98],(V3),VV[107],T0,VALUES(0));
	RETURN(1);
}
/*	function definition for PRINT-UNREADABLE-OBJECT-FUNCTION      */
static L47(int narg, object V1, object V2, object V3, object V4, object V5)
{ VT46 VLEX46 CLSR46
TTL:
	princ(VV[134],(V2));
	if(((V3))==Cnil){
	goto L277;}
	{register object V6;                      /*  TYPE            */
	object V7;
	register object V8;                       /*  PCL-PACKAGE     */
	V7= TYPE_OF((V1));
	Lfind_package(1,VV[82])                   /*  FIND-PACKAGE    */;
	V8= VALUES(0);
	V6= V7;
	if(((V8))==Cnil){
	goto L282;}
	if(!(type_of((V6))==t_symbol)){
	goto L282;}
	Lsymbol_package(1,(V6))                   /*  SYMBOL-PACKAGE  */;
	if(!((VALUES(0))==((V8)))){
	goto L282;}
	if(!(string_equal(symbol_name((V6)),VV[135]))){
	goto L282;}
	Lintern(2,symbol_name(VV[136]),(V8))      /*  INTERN          */;
	T0= VALUES(0);
	Lintern(2,symbol_name(VV[137]),(V8))      /*  INTERN          */;
	T1= VALUES(0);
	funcall(2,T1,(V1));
	funcall(2,T0,VALUES(0));
	V6= VALUES(0);
L282:
	prin1((V6),(V2));
	}
L277:
	if(((V3))==Cnil){
	goto L296;}
	if(((V5))==Cnil){
	goto L296;}
	princ(VV[138],(V2));
L296:
	if(((V5))==Cnil){
	goto L301;}
	funcall(1,(V5));
L301:
	if(((V3))!=Cnil){
	goto L306;}
	if(((V5))==Cnil){
	goto L304;}
L306:
	if(((V4))==Cnil){
	goto L304;}
	princ(VV[139],(V2));
L304:
	if(((V4))==Cnil){
	goto L311;}
	princ(VV[140],(V2));
L311:
	princ(VV[141],(V2));
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	macro definition for PRINT-UNREADABLE-OBJECT                  */
static L48(int narg, object V1, object V2)
{ VT47 VLEX47 CLSR47
	{object V3=CDR(V1),V4,V5,V6,V7,V8;
	{object V9= CAR(V3);
	V4= CAR(V9);
	V9=CDR(V9);
	V5= CAR(V9);
	V9=CDR(V9);
	{object V10;
	V10=getf(V9,VV[98],OBJNULL);
	if(V10==OBJNULL){
	V6= Cnil;
	} else {
	V6= V10;}
	V10=getf(V9,VV[206],OBJNULL);
	if(V10==OBJNULL){
	V7= Cnil;
	} else {
	V7= V10;}}}
	V3=CDR(V3);
	V8= V3;
	if(((V8))==Cnil){
	goto L318;}
	{object V11= CONS(listA(3,VV[143],Cnil,(V8)),Cnil);
	VALUES(0) = list(3,VV[142],(V11),list(6,VV[144],(V4),(V5),(V6),(V7),VV[145]));
	RETURN(1);}
L318:
	VALUES(0) = list(6,VV[144],(V4),(V5),(V6),(V7),Cnil);
	RETURN(1);}
}
static LKF1(int narg, ...) {TRAMPOLINK(VV[204],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[186],&LK0);}
