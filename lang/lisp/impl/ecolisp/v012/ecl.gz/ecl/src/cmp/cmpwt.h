
/* (c) Copyright G. Attardi, 1993. */
#define VT2
#define VLEX2
#define CLSR2
static L1(int, object, ...);
int Lsymbol_package();
int Lformat();
int Lsymbol_name();
int Lformat();
#define VT3
#define VLEX3
#define CLSR3
static L2(int, object);
int Lformat();
#define VT4
#define VLEX4
#define CLSR4
static L3(int, object);
int Lapply();
#define VT5
#define VLEX5
#define CLSR5
static L4(int, object);
int Lcompiled_function_p();
int siLcompiled_function_name();
#define VT6
#define VLEX6
#define CLSR6
static L5(int);
#define VT7
#define VLEX7
#define CLSR7
static L6(int);
int Lfile_length();
int Lformat();
#define VT8
#define VLEX8
#define CLSR8
static L7(int, object);
#define VT9
#define VLEX9
#define CLSR9
static struct codeblock Cblock;
#define VM9 0
#define VM8 0
#define VM7 0
#define VM6 0
#define VM5 0
#define VM4 0
#define VM3 0
#define VM2 0
#define VM1 37
static object VV[37];
static LKF0(int, ...);
static (*LK0)(int, ...)=LKF0;
static LKF1(int, ...);
static (*LK1)(int, ...)=LKF1;
static LKF2(int, ...);
static (*LK2)(int, ...)=LKF2;
static LKF3(int, ...);
static (*LK3)(int, ...)=LKF3;
