
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "cmpvar.h"
init_cmpvar(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_cmpvar; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	VV[0]->s.s_stype=(short)stp_special;
	if(VV[0]->s.s_dbind == OBJNULL){
	(VV[0]->s.s_dbind)= Cnil;}
	VV[1]->s.s_stype=(short)stp_special;
	if(VV[1]->s.s_dbind == OBJNULL){
	(VV[1]->s.s_dbind)= Cnil;}
	VV[2]->s.s_stype=(short)stp_special;
	if(VV[2]->s.s_dbind == OBJNULL){
	(VV[2]->s.s_dbind)= Cnil;}
	MF0(VV[72],L1);
	VV[3]->s.s_stype=(short)stp_special;
	if(VV[3]->s.s_dbind == OBJNULL){
	(VV[3]->s.s_dbind)= MAKE_FIXNUM(3);}
	funcall(2,VV[73]->s.s_gfdef,VV[4])        /*  PROCLAIM        */;
	MF0(VV[74],L2);
	MF0(VV[75],L3);
	MF0(VV[76],L4);
	MF0(VV[77],L5);
	MF0(VV[78],L6);
	MF0(VV[79],L7);
	MF0(VV[80],L8);
	MF0(VV[56],L9);
	MF0(VV[57],L10);
	MF0(VV[69],L11);
	MF0(VV[67],L12);
	MF0(VV[70],L13);
	MF0(VV[71],L14);
	MF0(VV[81],L15);
	MF0(VV[82],L16);
	MF0(VV[59],L17);
	MF0(VV[83],L18);
	MF0(VV[60],L19);
	MF0(VV[61],L20);
	MF0(VV[62],L21);
	MF0(VV[64],L22);
	MF0(VV[84],L23);
	MF0(VV[65],L24);
	putprop(VV[22],VV[56],VV[55]);
	putprop(VV[43],VV[57],VV[55]);
	putprop(VV[36],VV[59],VV[58]);
	putprop(VV[36],VV[60],VV[55]);
	putprop(VV[44],VV[61],VV[58]);
	putprop(VV[44],VV[62],VV[55]);
	putprop(VV[52],VV[64],VV[63]);
	putprop(VV[52],VV[65],VV[55]);
	putprop(VV[22],VV[67],VV[66]);
	putprop(VV[22],VV[69],VV[68]);
	putprop(VV[35],VV[70],VV[66]);
	putprop(VV[35],VV[71],VV[68]);
}
/*	function definition for SCH-GLOBAL                            */
static L1(int narg, object V1)
{ VT3 VLEX3 CLSR3
TTL:
	{register object V2;
	object V3;                                /*  VAR             */
	V2= (VV[1]->s.s_dbind);
	V3= Cnil;
L21:
	if(!((V2)==Cnil)){
	goto L22;}
	VALUES(0) = Cnil;
	RETURN(1);
L22:
	V3= CAR((V2));
	if(!((((V3))->v.v_self[0])==((V1)))){
	goto L27;}
	VALUES(0) = (V3);
	RETURN(1);
L27:
	V2= CDR((V2));
	goto L21;
	}
}
/*	function definition for CHECK-GLOBAL                          */
static L2(int narg, object V1)
{ VT4 VLEX4 CLSR4
TTL:
	{object V2;                               /*  X               */
	V2= assql((V1),(VV[5]->s.s_dbind));
	if(((V2))==Cnil){
	goto L35;}
	{register object V3;
	register object V4;                       /*  TLF             */
	V3= (VV[6]->s.s_dbind);
	V4= Cnil;
L40:
	if(!((V3)==Cnil)){
	goto L41;}
	VALUES(0) = Cnil;
	RETURN(1);
L41:
	V4= CAR((V3));
	if(!((CAR((V4)))==(VV[7]))){
	goto L48;}
	if(number_compare((CADR((V4)))->v.v_self[5],CADR((V2)))==0){
	goto L47;}
L48:
	if(!((CAR((V4)))==(VV[8]))){
	goto L46;}
	if(!(number_compare(CADR((V4)),CADR((V2)))==0)){
	goto L46;}
L47:
	VALUES(0) = (V4);
	RETURN(1);
L46:
	V3= CDR((V3));
	goto L40;
	}
L35:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for C1MAKE-VAR                            */
static L3(int narg, object V1, object V2, object V3, object V4)
{ VT5 VLEX5 CLSR5
TTL:
	{register object V5;                      /*  X               */
	V5= Cnil;
	{register object V6;                      /*  VAR             */
	(*LK0)(2,VV[9],(V1))                      /*  MAKE-VAR        */;
	V6= VALUES(0);
	if(type_of((V1))==t_symbol){
	goto L60;}
	(*LK1)(2,VV[10],(V1))                     /*  CMPERR          */;
L60:
	Lconstantp(1,(V1))                        /*  CONSTANTP       */;
	if(VALUES(0)==Cnil){
	goto L63;}
	(*LK1)(2,VV[11],(V1))                     /*  CMPERR          */;
L63:
	if((memql((V1),(V2)))!=Cnil){
	goto L67;}
	siLspecialp(1,(V1))                       /*  SPECIALP        */;
	if(VALUES(0)!=Cnil){
	goto L67;}
	L2(1,(V1))                                /*  CHECK-GLOBAL    */;
	if(VALUES(0)==Cnil){
	goto L68;}
L67:
	elt_set((V6),4,VV[12]);
	(*LK2)(1,(V1))                            /*  ADD-SYMBOL      */;
	elt_set((V6),5,VALUES(0));
	V5= assql((V1),(V4));
	if(((V5))==Cnil){
	goto L79;}
	elt_set((V6),6,CDR((V5)));
	goto L77;
L79:
	V5= getf((V1)->s.s_plist,VV[13],Cnil);
	if(((V5))==Cnil){
	goto L77;}
	elt_set((V6),6,(V5));
L77:
	(VV[2]->s.s_dbind)= Ct;
	goto L66;
L68:
	{register object V7;
	register object V8;                       /*  V               */
	V7= (V4);
	V8= Cnil;
L90:
	if(!((V7)==Cnil)){
	goto L91;}
	goto L86;
L91:
	V8= CAR((V7));
	if(!((CAR((V8)))==((V1)))){
	goto L96;}
	{object V10= CDR((V8));
	if((V10!= VV[88]))goto L99;
	elt_set((V6),1,number_plus(((V6))->v.v_self[1],MAKE_FIXNUM(100)));
	goto L96;
L99:
	elt_set((V6),6,CDR((V8)));}
L96:
	V7= CDR((V7));
	goto L90;
	}
L86:
	elt_set((V6),4,VV[14]);
L66:
	if((memql((V1),(V3)))==Cnil){
	goto L103;}
	elt_set((V6),1,MAKE_FIXNUM(-1));
L103:
	VALUES(0) = (V6);
	RETURN(1);
	}
	}
}
/*	function definition for CHECK-VREF                            */
static L4(int narg, object V1)
{ VT6 VLEX6 CLSR6
TTL:
	if(!((((V1))->v.v_self[4])==(VV[14]))){
	goto L107;}
	if((((V1))->v.v_self[2])!=Cnil){
	goto L107;}
	if(!(number_compare(MAKE_FIXNUM(0),((V1))->v.v_self[1])==0)){
	goto L111;}
	(*LK3)(2,VV[15],((V1))->v.v_self[0])      /*  CMPWARN         */;
L111:
	if((((V1))->v.v_self[5])==(VV[16])){
	goto L115;}
	if(!(number_compare(((V1))->v.v_self[1],MAKE_FIXNUM(1))>0)){
	goto L119;}
	{register object V2;                      /*  TYPE            */
	V2= ((V1))->v.v_self[6];
	(*LK4)(2,VV[17],(V2))                     /*  TYPE>=          */;
	if(VALUES(0)==Cnil){
	goto L123;}
	VALUES(0) = VV[17];
	goto L117;
L123:
	(*LK4)(2,VV[18],(V2))                     /*  TYPE>=          */;
	if(VALUES(0)==Cnil){
	goto L126;}
	VALUES(0) = VV[18];
	goto L117;
L126:
	(*LK4)(2,VV[19],(V2))                     /*  TYPE>=          */;
	if(VALUES(0)==Cnil){
	goto L129;}
	VALUES(0) = VV[19];
	goto L117;
L129:
	(*LK4)(2,VV[20],(V2))                     /*  TYPE>=          */;
	if(VALUES(0)==Cnil){
	goto L132;}
	VALUES(0) = VV[20];
	goto L117;
L132:
	VALUES(0) = VV[21];
	goto L117;
	}
L119:
	VALUES(0) = VV[21];
L117:
	VALUES(0) = elt_set((V1),4,VALUES(0));
	RETURN(1);
L115:
	VALUES(0) = Cnil;
	RETURN(1);
L107:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for C1VAR                                 */
static L5(int narg, object V1)
{ VT7 VLEX7 CLSR7
TTL:
	{register object V2;                      /*  INFO            */
	object V3;
	register object V4;                       /*  VREF            */
	(*LK5)(0)                                 /*  MAKE-INFO       */;
	V3= VALUES(0);
	L6(1,(V1))                                /*  C1VREF          */;
	V4= VALUES(0);
	V2= V3;
	elt_set((V2),2,CONS(CAR((V4)),((V2))->v.v_self[2]));
	elt_set((V2),6,CONS(CAR((V4)),((V2))->v.v_self[6]));
	elt_set((V2),3,(CAR((V4)))->v.v_self[6]);
	VALUES(0) = list(3,VV[22],(V2),(V4));
	RETURN(1);
	}
}
/*	function definition for C1VREF                                */
static L6(int narg, object V1)
{ VT8 VLEX8 CLSR8
TTL:
	{object V2;                               /*  CCB             */
	object V3;                                /*  CLB             */
	V2= Cnil;
	V3= Cnil;
	{register object V4;
	register object V5;                       /*  VAR             */
	V4= (VV[0]->s.s_dbind);
	V5= Cnil;
L145:
	if(!((V4)==Cnil)){
	goto L146;}
	goto L141;
L146:
	V5= CAR((V4));
	if(!(((V5))==(VV[23]))){
	goto L153;}
	V2= Ct;
	goto L151;
L153:
	if(!(((V5))==(VV[24]))){
	goto L157;}
	V3= Ct;
	goto L151;
L157:
	if(!((((V5))->v.v_self[0])==((V1)))){
	goto L151;}
	if(!(number_compare(MAKE_FIXNUM(0),((V5))->v.v_self[1])>0)){
	goto L162;}
	(*LK3)(2,VV[25],(V1))                     /*  CMPWARN         */;
	elt_set((V5),1,MAKE_FIXNUM(0));
L162:
	if(((V2))==Cnil){
	goto L168;}
	elt_set((V5),2,Ct);
	elt_set((V5),5,VV[21]);
	goto L166;
L168:
	if(((V3))==Cnil){
	goto L166;}
	if(!((((V5))->v.v_self[4])==(VV[14]))){
	goto L166;}
	elt_set((V5),5,VV[16]);
L166:
	elt_set((V5),1,number_plus(((V5))->v.v_self[1],MAKE_FIXNUM(1)));
	VALUES(0) = CONS((V5),Cnil);
	RETURN(1);
L151:
	V4= CDR((V4));
	goto L145;
	}
L141:
	{register object V4;                      /*  VAR             */
	L1(1,(V1))                                /*  SCH-GLOBAL      */;
	V4= VALUES(0);
	if(((V4))!=Cnil){
	goto L180;}
	if(((VV[26]->s.s_dbind))==Cnil){
	goto L185;}
	siLspecialp(1,(V1))                       /*  SPECIALP        */;
	if(VALUES(0)!=Cnil){
	goto L183;}
	(*LK6)(1,(V1))                            /*  UNDEFINED-VARIABLE*/;
	goto L183;
L185:
	siLspecialp(1,(V1))                       /*  SPECIALP        */;
	if(VALUES(0)!=Cnil){
	goto L183;}
	L2(1,(V1))                                /*  CHECK-GLOBAL    */;
	if(VALUES(0)!=Cnil){
	goto L183;}
	(*LK6)(1,(V1))                            /*  UNDEFINED-VARIABLE*/;
L183:
	(*LK2)(1,(V1))                            /*  ADD-SYMBOL      */;
	T0= VALUES(0);
	VALUES(0) = getf((V1)->s.s_plist,VV[13],Cnil);
	if(VALUES(0)==Cnil)goto L197;
	goto L196;
L197:
	VALUES(0) = Ct;
L196:
	(*LK0)(8,VV[9],(V1),VV[27],VV[28],VV[29],T0,VV[30],VALUES(0))/*  MAKE-VAR*/;
	V4= VALUES(0);
	(VV[1]->s.s_dbind)= CONS((V4),(VV[1]->s.s_dbind));
L180:
	VALUES(0) = CONS((V4),Cnil);
	RETURN(1);
	}
	}
}
/*	function definition for UNBOXED                               */
static L7(int narg, object V1)
{ VT9 VLEX9 CLSR9
TTL:
	VALUES(0) = memq(((V1))->v.v_self[4],VV[31]);
	RETURN(1);
}
/*	function definition for LOCAL                                 */
static L8(int narg, object V1)
{ VT10 VLEX10 CLSR10
TTL:
	VALUES(0) = memq(((V1))->v.v_self[4],VV[32]);
	VALUES(0) = CAR(VALUES(0));
	RETURN(1);
}
/*	function definition for C2VAR                                 */
static L9(int narg, object V1)
{ VT11 VLEX11 CLSR11
TTL:
	RETURN((*LK7)(1,CONS(VV[22],(V1)))        /*  UNWIND-EXIT     */);
}
/*	function definition for C2LOCATION                            */
static L10(int narg, object V1)
{ VT12 VLEX12 CLSR12
TTL:
	RETURN((*LK7)(1,(V1))                     /*  UNWIND-EXIT     */);
}
/*	function definition for WT-VAR                                */
static L11(int narg, object V1)
{ VT13 VLEX13 CLSR13
TTL:
	{register object V2;                      /*  VAR-LOC         */
	V2= ((V1))->v.v_self[5];
	{object V3= ((V1))->v.v_self[4];
	if((V3!= VV[14]))goto L202;
	if((((V1))->v.v_self[2])==Cnil){
	goto L204;}
	RETURN(L15(1,(V2))                        /*  WT-ENV          */);
L204:
	RETURN(L14(1,(V2))                        /*  WT-LEX          */);
L202:
	if((V3!= VV[12]))goto L206;
	princ_str("(VV[",symbol_value(VV[33]));
	(*LK8)(1,(V2))                            /*  WT1             */;
	princ_str("]->s.s_dbind)",symbol_value(VV[33]));
	VALUES(0) = Cnil;
	RETURN(1);
L206:
	if((V3!= VV[95]))goto L210;
	(*LK8)(1,(V2))                            /*  WT1             */;
	VALUES(0) = Cnil;
	RETURN(1);
L210:
	if((V3!= VV[28]))goto L212;
	if(((VV[34]->s.s_dbind))==Cnil){
	goto L214;}
	princ_str("symbol_value(VV[",symbol_value(VV[33]));
	(*LK8)(1,(V2))                            /*  WT1             */;
	princ_str("])",symbol_value(VV[33]));
	VALUES(0) = Cnil;
	RETURN(1);
L214:
	princ_str("(VV[",symbol_value(VV[33]));
	(*LK8)(1,(V2))                            /*  WT1             */;
	princ_str("]->s.s_dbind)",symbol_value(VV[33]));
	VALUES(0) = Cnil;
	RETURN(1);
L212:
	{object V4= ((V1))->v.v_self[4];
	if((V4!= VV[17]))goto L223;
	princ_str("MAKE_FIXNUM",symbol_value(VV[33]));
	goto L222;
L223:
	if((V4!= VV[18]))goto L225;
	princ_str("code_char",symbol_value(VV[33]));
	goto L222;
L225:
	if((V4!= VV[19]))goto L227;
	princ_str("make_longfloat",symbol_value(VV[33]));
	goto L222;
L227:
	if((V4!= VV[20]))goto L229;
	princ_str("make_shortfloat",symbol_value(VV[33]));
	goto L222;
L229:
	if((V4!= VV[21]))goto L231;
	goto L222;
L231:
	(*LK9)(0)                                 /*  BABOON          */;}
L222:
	princ_char(40,symbol_value(VV[33]));
	(*LK10)(1,(V2))                           /*  WT-LCL          */;
	princ_char(41,symbol_value(VV[33]));
	VALUES(0) = Cnil;
	RETURN(1);}
	}
}
/*	function definition for SET-VAR                               */
static L12(int narg, object V1, object V2)
{ VT14 VLEX14 CLSR14
TTL:
	{register object V3;                      /*  VAR-LOC         */
	V3= ((V2))->v.v_self[5];
	if(!(type_of((V1))==t_cons)){
	goto L237;}
	if(!((CAR((V1)))==(VV[22]))){
	goto L237;}
	if((CADR((V1)))==((V2))){
	goto L238;}
L237:
	{object V4= ((V2))->v.v_self[4];
	if((V4!= VV[14]))goto L244;
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	if((((V2))->v.v_self[2])==Cnil){
	goto L250;}
	L15(1,(V3))                               /*  WT-ENV          */;
	goto L248;
L250:
	L14(1,(V3))                               /*  WT-LEX          */;
L248:
	princ_str("= ",symbol_value(VV[33]));
	(*LK8)(1,(V1))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[33]));
	VALUES(0) = Cnil;
	RETURN(1);
L244:
	if((V4!= VV[12]))goto L255;
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	princ_str("(VV[",symbol_value(VV[33]));
	(*LK8)(1,(V3))                            /*  WT1             */;
	princ_str("]->s.s_dbind)= ",symbol_value(VV[33]));
	(*LK8)(1,(V1))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[33]));
	VALUES(0) = Cnil;
	RETURN(1);
L255:
	if((V4!= VV[28]))goto L263;
	if(((VV[34]->s.s_dbind))==Cnil){
	goto L265;}
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	princ_str("setq(VV[",symbol_value(VV[33]));
	(*LK8)(1,(V3))                            /*  WT1             */;
	princ_str("],",symbol_value(VV[33]));
	(*LK8)(1,(V1))                            /*  WT1             */;
	princ_str(");",symbol_value(VV[33]));
	VALUES(0) = Cnil;
	RETURN(1);
L265:
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	princ_str("(VV[",symbol_value(VV[33]));
	(*LK8)(1,(V3))                            /*  WT1             */;
	princ_str("]->s.s_dbind)= ",symbol_value(VV[33]));
	(*LK8)(1,(V1))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[33]));
	VALUES(0) = Cnil;
	RETURN(1);
L263:
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	(*LK10)(1,(V3))                           /*  WT-LCL          */;
	princ_str("= ",symbol_value(VV[33]));
	{object V5= ((V2))->v.v_self[4];
	if((V5!= VV[17]))goto L288;
	(*LK11)(1,(V1))                           /*  WT-FIXNUM-LOC   */;
	goto L287;
L288:
	if((V5!= VV[18]))goto L289;
	(*LK12)(1,(V1))                           /*  WT-CHARACTER-LOC*/;
	goto L287;
L289:
	if((V5!= VV[19]))goto L290;
	(*LK13)(1,(V1))                           /*  WT-LONG-FLOAT-LOC*/;
	goto L287;
L290:
	if((V5!= VV[20]))goto L291;
	(*LK14)(1,(V1))                           /*  WT-SHORT-FLOAT-LOC*/;
	goto L287;
L291:
	if((V5!= VV[21]))goto L292;
	(*LK15)(1,(V1))                           /*  WT-LOC          */;
	goto L287;
L292:
	(*LK9)(0)                                 /*  BABOON          */;}
L287:
	princ_char(59,symbol_value(VV[33]));
	VALUES(0) = Cnil;
	RETURN(1);}
L238:
	VALUES(0) = Cnil;
	RETURN(1);
	}
}
/*	function definition for SET-LEX                               */
static L13(int narg, object V1, object V2)
{ VT15 VLEX15 CLSR15
TTL:
	if(!(type_of((V1))==t_cons)){
	goto L294;}
	if(!((CAR((V1)))==(VV[35]))){
	goto L294;}
	if(equal(CADR((V1)),(V2))){
	goto L295;}
L294:
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	L14(1,(V2))                               /*  WT-LEX          */;
	princ_str("= ",symbol_value(VV[33]));
	(*LK8)(1,(V1))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[33]));
	VALUES(0) = Cnil;
	RETURN(1);
L295:
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for WT-LEX                                */
static L14(int narg, object V1)
{ VT16 VLEX16 CLSR16
TTL:
	if(!(type_of((V1))==t_cons)){
	goto L309;}
	princ_str("lex",symbol_value(VV[33]));
	(*LK8)(1,CAR((V1)))                       /*  WT1             */;
	princ_char(91,symbol_value(VV[33]));
	(*LK8)(1,CDR((V1)))                       /*  WT1             */;
	princ_char(93,symbol_value(VV[33]));
	VALUES(0) = Cnil;
	RETURN(1);
L309:
	RETURN((*LK10)(1,(V1))                    /*  WT-LCL          */);
}
/*	function definition for WT-ENV                                */
static L15(int narg, object V1)
{ VT17 VLEX17 CLSR17
TTL:
	princ_str("*CLV",symbol_value(VV[33]));
	(*LK8)(1,(V1))                            /*  WT1             */;
	VALUES(0) = Cnil;
	RETURN(1);
}
/*	function definition for C1ADD-GLOBALS                         */
static L16(int narg, object V1)
{ VT18 VLEX18 CLSR18
TTL:
	{register object V2;
	register object V3;                       /*  NAME            */
	V2= (V1);
	V3= Cnil;
L321:
	if(!((V2)==Cnil)){
	goto L322;}
	VALUES(0) = Cnil;
	RETURN(1);
L322:
	V3= CAR((V2));
	(*LK2)(1,(V3))                            /*  ADD-SYMBOL      */;
	T0= VALUES(0);
	{object V5;                               /*  X               */
	V5= getf((V3)->s.s_plist,VV[13],Cnil);
	if(((V5))==Cnil){
	goto L333;}
	VALUES(0) = (V5);
	goto L330;
L333:
	VALUES(0) = Ct;
	}
L330:
	(*LK0)(8,VV[9],(V3),VV[27],VV[28],VV[29],T0,VV[30],VALUES(0))/*  MAKE-VAR*/;
	(VV[0]->s.s_dbind)= CONS(VALUES(0),(VV[0]->s.s_dbind));
	V2= CDR((V2));
	goto L321;
	}
}
/*	function definition for C1SETQ                                */
static L17(int narg, object V1)
{ VT19 VLEX19 CLSR19
TTL:
	if(!((V1)==Cnil)){
	goto L340;}
	RETURN((*LK16)(0)                         /*  C1NIL           */);
L340:
	if(!(CDR((V1))==Cnil)){
	goto L343;}
	RETURN((*LK17)(3,VV[36],MAKE_FIXNUM(2),MAKE_FIXNUM(1))/*  TOO-FEW-ARGS*/);
L343:
	if(!(CDDR((V1))==Cnil)){
	goto L346;}
	RETURN(L18(2,CAR((V1)),CADR((V1)))        /*  C1SETQ1         */);
L346:
	{register object V2;                      /*  PAIRS           */
	object V3;                                /*  FORMS           */
	V2= (V1);
	V3= Cnil;
L349:
	if(!((V2)==Cnil)){
	goto L350;}
	RETURN((*LK18)(1,CONS(VV[37],nreverse((V3))))/*  C1EXPR       */);
L350:
	if(!(CDR((V2))==Cnil)){
	goto L353;}
	(*LK1)(2,VV[38],CAR((V2)))                /*  CMPERR          */;
L353:
	V3= CONS(list(3,VV[36],CAR((V2)),CADR((V2))),(V3));
	V2= CDDR((V2));
	goto L349;
	}
}
/*	function definition for C1SETQ1                               */
static L18(int narg, object V1, object V2)
{ VT20 VLEX20 CLSR20
TTL:
	{register object V3;                      /*  INFO            */
	register object V4;                       /*  TYPE            */
	register object V5;                       /*  FORM1           */
	register object V6;                       /*  NAME1           */
	(*LK5)(0)                                 /*  MAKE-INFO       */;
	V3= VALUES(0);
	V4= Cnil;
	V5= Cnil;
	V6= Cnil;
	if(type_of((V1))==t_symbol){
	goto L365;}
	(*LK1)(2,VV[39],(V1))                     /*  CMPERR          */;
L365:
	Lconstantp(1,(V1))                        /*  CONSTANTP       */;
	if(VALUES(0)==Cnil){
	goto L368;}
	(*LK1)(2,VV[40],(V1))                     /*  CMPERR          */;
L368:
	L6(1,(V1))                                /*  C1VREF          */;
	V6= VALUES(0);
	Ladjoin(2,CAR((V6)),((V3))->v.v_self[1])  /*  ADJOIN          */;
	elt_set((V3),1,VALUES(0));
	Ladjoin(2,CAR((V6)),((V3))->v.v_self[2])  /*  ADJOIN          */;
	elt_set((V3),2,VALUES(0));
	Ladjoin(2,CAR((V6)),((V3))->v.v_self[6])  /*  ADJOIN          */;
	elt_set((V3),6,VALUES(0));
	(*LK18)(1,(V2))                           /*  C1EXPR          */;
	V5= VALUES(0);
	(*LK19)(2,(V3),CADR((V5)))                /*  ADD-INFO        */;
	(*LK20)(2,(CAR((V6)))->v.v_self[6],(CADR((V5)))->v.v_self[3])/*  TYPE-AND*/;
	V4= VALUES(0);
	if(((V4))!=Cnil){
	goto L384;}
	(*LK3)(3,VV[41],(V1),(V2))                /*  CMPWARN         */;
	V4= Ct;
L384:
	if(((V4))==((CADR((V5)))->v.v_self[3])){
	goto L389;}
	{object V7;                               /*  INFO1           */
	(*LK21)(1,CADR((V5)))                     /*  COPY-INFO       */;
	V7= VALUES(0);
	elt_set((V7),3,(V4));
	V5= listA(3,CAR((V5)),(V7),CDDR((V5)));
	}
L389:
	elt_set((V3),3,(V4));
	VALUES(0) = list(4,VV[36],(V3),(V6),(V5));
	RETURN(1);
	}
}
/*	function definition for C2SETQ                                */
static L19(int narg, object V1, object V2)
{ VT21 VLEX21 CLSR21
	bds_check;
TTL:
	{object V3;                               /*  DEST            */
	V3= CONS(VV[22],(V1));
	bds_bind(VV[42],(V3));                    /*  *DESTINATION*   */
	(*LK22)(1,(V2))                           /*  C2EXPR*         */;
	bds_unwind1;
	if(!((CAR((V2)))==(VV[43]))){
	goto L399;}
	RETURN(L10(1,CADDR((V2)))                 /*  C2LOCATION      */);
L399:
	RETURN((*LK7)(1,(V3))                     /*  UNWIND-EXIT     */);
	}
}
/*	function definition for C1PROGV                               */
static L20(int narg, object V1)
{ VT22 VLEX22 CLSR22
TTL:
	{object V2;                               /*  SYMBOLS         */
	object V3;                                /*  VALUES          */
	register object V4;                       /*  INFO            */
	object V5;                                /*  FORMS           */
	V2= Cnil;
	V3= Cnil;
	(*LK5)(0)                                 /*  MAKE-INFO       */;
	V4= VALUES(0);
	V5= Cnil;
	if((V1)==Cnil){
	goto L406;}
	if(!(CDR((V1))==Cnil)){
	goto L405;}
L406:
	(*LK17)(3,VV[44],MAKE_FIXNUM(2),MAKE_FIXNUM(length((V1))))/*  TOO-FEW-ARGS*/;
L405:
	(*LK23)(2,CAR((V1)),(V4))                 /*  C1EXPR*         */;
	V2= VALUES(0);
	(*LK23)(2,CADR((V1)),(V4))                /*  C1EXPR*         */;
	V3= VALUES(0);
	(*LK24)(1,CDDR((V1)))                     /*  C1PROGN         */;
	V5= VALUES(0);
	(*LK19)(2,(V4),CADR((V5)))                /*  ADD-INFO        */;
	VALUES(0) = list(5,VV[44],(V4),(V2),(V3),(V5));
	RETURN(1);
	}
}
/*	function definition for C2PROGV                               */
static L21(int narg, object V1, object V2, object V3)
{ VT23 VLEX23 CLSR23
	bds_check;
TTL:
	bds_bind(VV[45],(VV[45]->s.s_dbind));     /*  *UNWIND-EXIT*   */
	{object V4;                               /*  LCL             */
	register object V5;                       /*  SYM-LOC         */
	register object V6;                       /*  VAL-LOC         */
	bds_bind(VV[46],(VV[46]->s.s_dbind));     /*  *LCL*           */
	(*LK25)(0)                                /*  NEXT-LCL        */;
	V4= VALUES(0);
	(*LK25)(0)                                /*  NEXT-LCL        */;
	V5= list(2,VV[47],VALUES(0));
	(*LK25)(0)                                /*  NEXT-LCL        */;
	V6= list(2,VV[47],VALUES(0));
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	princ_str("{object ",symbol_value(VV[33]));
	(*LK8)(1,(V5))                            /*  WT1             */;
	princ_char(44,symbol_value(VV[33]));
	(*LK8)(1,(V6))                            /*  WT1             */;
	princ_char(59,symbol_value(VV[33]));
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	princ_str("bds_ptr ",symbol_value(VV[33]));
	(*LK10)(1,(V4))                           /*  WT-LCL          */;
	princ_str("=bds_top;",symbol_value(VV[33]));
	(VV[45]->s.s_dbind)= CONS((V4),(VV[45]->s.s_dbind));
	bds_bind(VV[42],(V5));                    /*  *DESTINATION*   */
	(*LK22)(1,(V1))                           /*  C2EXPR*         */;
	bds_unwind1;
	bds_bind(VV[42],(V6));                    /*  *DESTINATION*   */
	(*LK22)(1,(V2))                           /*  C2EXPR*         */;
	bds_unwind1;
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	princ_str("while(!endp(",symbol_value(VV[33]));
	(*LK8)(1,(V5))                            /*  WT1             */;
	princ_str(")) {",symbol_value(VV[33]));
	if(((VV[34]->s.s_dbind))==Cnil){
	goto L448;}
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(type_of(CAR(",symbol_value(VV[33]));
	(*LK8)(1,(V5))                            /*  WT1             */;
	princ_str("))!=t_symbol)",symbol_value(VV[33]));
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	princ_str("FEinvalid_variable(\"~s is not a symbol.\",CAR(",symbol_value(VV[33]));
	(*LK8)(1,(V5))                            /*  WT1             */;
	princ_str("));",symbol_value(VV[33]));
L448:
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	princ_str("if(endp(",symbol_value(VV[33]));
	(*LK8)(1,(V6))                            /*  WT1             */;
	princ_str("))bds_bind(CAR(",symbol_value(VV[33]));
	(*LK8)(1,(V5))                            /*  WT1             */;
	princ_str("),OBJNULL);",symbol_value(VV[33]));
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	princ_str("else{bds_bind(CAR(",symbol_value(VV[33]));
	(*LK8)(1,(V5))                            /*  WT1             */;
	princ_str("),CAR(",symbol_value(VV[33]));
	(*LK8)(1,(V6))                            /*  WT1             */;
	princ_str("));",symbol_value(VV[33]));
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	(*LK8)(1,(V6))                            /*  WT1             */;
	princ_str("=CDR(",symbol_value(VV[33]));
	(*LK8)(1,(V6))                            /*  WT1             */;
	princ_str(");}",symbol_value(VV[33]));
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	(*LK8)(1,(V5))                            /*  WT1             */;
	princ_str("=CDR(",symbol_value(VV[33]));
	(*LK8)(1,(V5))                            /*  WT1             */;
	princ_str(");}",symbol_value(VV[33]));
	bds_unwind1;
	}
	(*LK26)(1,(V3))                           /*  C2EXPR          */;
	princ_char(125,symbol_value(VV[33]));
	{int V4;
	VALUES(0)=Cnil;
	V4=1;
	bds_unwind1;
	RETURN(V4);}
}
/*	function definition for C1PSETQ                               */
static L22(int narg, object V1)
{ VT24 VLEX24 CLSR24
TTL:
	{object V2;                               /*  VREFS           */
	register object V3;                       /*  FORMS           */
	object V4;                                /*  INFO            */
	V2= Cnil;
	V3= Cnil;
	(*LK5)(2,VV[30],VV[48])                   /*  MAKE-INFO       */;
	V4= VALUES(0);
	{register object V5;                      /*  L               */
	V5= (V1);
L498:
	if(!((V5)==Cnil)){
	goto L499;}
	goto L496;
L499:
	if(type_of(CAR((V5)))==t_symbol){
	goto L502;}
	(*LK1)(2,VV[49],CAR((V5)))                /*  CMPERR          */;
L502:
	Lconstantp(1,CAR((V5)))                   /*  CONSTANTP       */;
	if(VALUES(0)==Cnil){
	goto L505;}
	(*LK1)(2,VV[50],CAR((V5)))                /*  CMPERR          */;
L505:
	if(!(CDR((V5))==Cnil)){
	goto L508;}
	(*LK1)(2,VV[51],CAR((V5)))                /*  CMPERR          */;
L508:
	{object V7;                               /*  VREF            */
	register object V8;                       /*  FORM            */
	object V9;                                /*  TYPE            */
	L6(1,CAR((V5)))                           /*  C1VREF          */;
	V7= VALUES(0);
	(*LK18)(1,CADR((V5)))                     /*  C1EXPR          */;
	V8= VALUES(0);
	(*LK20)(2,(CAR((V7)))->v.v_self[6],(CADR((V8)))->v.v_self[3])/*  TYPE-AND*/;
	V9= VALUES(0);
	if(equal((V9),(CADR((V8)))->v.v_self[3])){
	goto L515;}
	{object V10;                              /*  INFO1           */
	(*LK21)(1,CADR((V8)))                     /*  COPY-INFO       */;
	V10= VALUES(0);
	elt_set((V10),3,(V9));
	V8= listA(3,CAR((V8)),(V10),CDDR((V8)));
	}
L515:
	V2= CONS((V7),(V2));
	V3= CONS((V8),(V3));
	elt_set((V4),1,CONS(CAR((V7)),((V4))->v.v_self[1]));
	(*LK19)(2,(V4),CADAR((V3)))               /*  ADD-INFO        */;
	}
	V5= CDDR((V5));
	goto L498;
	}
L496:
	{object V5= nreverse((V2));
	VALUES(0) = list(4,VV[52],(V4),V5,nreverse((V3)));
	RETURN(1);}
	}
}
/*	function definition for VAR-REFERRED-IN-FORMS                 */
static L23(int narg, object V1, object V2)
{ VT25 VLEX25 CLSR25
TTL:
	{object V3= ((V1))->v.v_self[4];
	if((V3== VV[14])
	|| (V3== VV[95])
	|| (V3== VV[17])
	|| (V3== VV[18])
	|| (V3== VV[19]))goto L530;
	if((V3!= VV[20])
	&& (V3!= VV[21]))goto L529;
L530:
	{register object V4;
	object V5;                                /*  FORM            */
	V4= (V2);
	V5= Cnil;
L534:
	if(!((V4)==Cnil)){
	goto L535;}
	VALUES(0) = Cnil;
	RETURN(1);
L535:
	V5= CAR((V4));
	if((memql((V1),(CADR((V5)))->v.v_self[2]))==Cnil){
	goto L540;}
	VALUES(0) = Ct;
	RETURN(1);
L540:
	V4= CDR((V4));
	goto L534;
	}
L529:
	{register object V8;
	object V9;                                /*  FORM            */
	V8= (V2);
	V9= Cnil;
L549:
	if(!((V8)==Cnil)){
	goto L550;}
	VALUES(0) = Cnil;
	RETURN(1);
L550:
	V9= CAR((V8));
	if((memql((V1),(CADR((V9)))->v.v_self[2]))!=Cnil){
	goto L556;}
	if(((CADR((V9)))->v.v_self[4])==Cnil){
	goto L555;}
L556:
	VALUES(0) = Ct;
	RETURN(1);
L555:
	V8= CDR((V8));
	goto L549;
	}}
}
/*	function definition for C2PSETQ                               */
static L24(int narg, object V1, object V2)
{ VT26 VLEX26 CLSR26
	bds_check;
TTL:
	{register object V3;                      /*  SAVES           */
	object V4;                                /*  BLOCKS          */
	bds_bind(VV[46],(VV[46]->s.s_dbind));     /*  *LCL*           */
	V3= Cnil;
	V4= MAKE_FIXNUM(0);
	{register object V5;                      /*  VREFS           */
	register object V6;                       /*  FORMS           */
	register object V7;                       /*  VAR             */
	register object V8;                       /*  FORM            */
	V5= (V1);
	V6= (V2);
	V7= Cnil;
	V8= Cnil;
L567:
	if(((V5))!=Cnil){
	goto L568;}
	goto L565;
L568:
	V7= CAAR((V5));
	V8= CAR((V6));
	(*LK27)(2,(V7),CDR((V6)))                 /*  VAR-CHANGED-IN-FORMS*/;
	if(VALUES(0)!=Cnil){
	goto L576;}
	L23(2,(V7),CDR((V6)))                     /*  VAR-REFERRED-IN-FORMS*/;
	if(VALUES(0)==Cnil){
	goto L577;}
L576:
	{object V10= CAR((V8));
	if((V10!= VV[43]))goto L581;
	V3= CONS(CONS((V7),CADDR((V8))),(V3));
	goto L575;
L581:
	L8(1,(V7))                                /*  LOCAL           */;
	if(VALUES(0)==Cnil){
	goto L584;}
	{object V11;                              /*  KIND            */
	object V12;                               /*  LCL             */
	object V13;                               /*  TEMP            */
	V11= ((V7))->v.v_self[4];
	(*LK25)(0)                                /*  NEXT-LCL        */;
	V12= VALUES(0);
	(*LK0)(4,VV[27],(V11),VV[29],(V12))       /*  MAKE-VAR        */;
	V13= list(2,VV[22],VALUES(0));
	(*LK8)(1,code_char('\12'))                /*  WT1             */;
	(*LK8)(1,code_char('\11'))                /*  WT1             */;
	princ_char(123,symbol_value(VV[33]));
	(*LK8)(1,(VV[53]->s.s_dbind))             /*  WT1             */;
	(*LK28)(1,(V11))                          /*  REP-TYPE        */;
	(*LK8)(1,VALUES(0))                       /*  WT1             */;
	(*LK10)(1,(V12))                          /*  WT-LCL          */;
	princ_char(59,symbol_value(VV[33]));
	V4= number_plus((V4),MAKE_FIXNUM(1));
	bds_bind(VV[42],(V13));                   /*  *DESTINATION*   */
	(*LK22)(1,(V8))                           /*  C2EXPR*         */;
	bds_unwind1;
	V3= CONS(CONS((V7),(V13)),(V3));
	goto L575;
	}
L584:
	{object V14;
	(*LK29)(0)                                /*  NEXT-TEMP       */;
	V14= list(2,VV[54],VALUES(0));
	bds_bind(VV[42],V14);                     /*  *DESTINATION*   */
	(*LK22)(1,(V8))                           /*  C2EXPR*         */;
	V3= CONS(CONS((V7),(VV[42]->s.s_dbind)),(V3));
	bds_unwind1;
	goto L575;
	}}
L577:
	{object V15;
	V15= CONS(VV[22],CAR((V5)));
	bds_bind(VV[42],V15);                     /*  *DESTINATION*   */
	(*LK22)(1,(V8))                           /*  C2EXPR*         */;
	bds_unwind1;
	}
L575:
	V5= CDR((V5));
	V6= CDR((V6));
	goto L567;
	}
L565:
	{object V5;
	object V6;                                /*  SAVE            */
	V5= (V3);
	V6= Cnil;
L617:
	if(!((V5)==Cnil)){
	goto L618;}
	goto L613;
L618:
	V6= CAR((V5));
	L12(2,CDR((V6)),CAR((V6)))                /*  SET-VAR         */;
	V5= CDR((V5));
	goto L617;
	}
L613:
	{register int V5;                         /*  I               */
	V5= 0;
L630:
	if(!(number_compare(MAKE_FIXNUM(V5),(V4))>=0)){
	goto L631;}
	goto L627;
L631:
	princ_char(125,symbol_value(VV[33]));
	V5= (V5)+1;
	goto L630;
	}
L627:
	{int V5;
	V5=(*LK7)(1,Cnil)                         /*  UNWIND-EXIT     */;
	bds_unwind1;
	RETURN(V5);}
	}
}
static LKF29(int narg, ...) {TRAMPOLINK(VV[115],&LK29);}
static LKF28(int narg, ...) {TRAMPOLINK(VV[114],&LK28);}
static LKF27(int narg, ...) {TRAMPOLINK(VV[113],&LK27);}
static LKF26(int narg, ...) {TRAMPOLINK(VV[112],&LK26);}
static LKF25(int narg, ...) {TRAMPOLINK(VV[111],&LK25);}
static LKF24(int narg, ...) {TRAMPOLINK(VV[110],&LK24);}
static LKF23(int narg, ...) {TRAMPOLINK(VV[109],&LK23);}
static LKF22(int narg, ...) {TRAMPOLINK(VV[108],&LK22);}
static LKF21(int narg, ...) {TRAMPOLINK(VV[107],&LK21);}
static LKF20(int narg, ...) {TRAMPOLINK(VV[106],&LK20);}
static LKF19(int narg, ...) {TRAMPOLINK(VV[105],&LK19);}
static LKF18(int narg, ...) {TRAMPOLINK(VV[104],&LK18);}
static LKF17(int narg, ...) {TRAMPOLINK(VV[103],&LK17);}
static LKF16(int narg, ...) {TRAMPOLINK(VV[102],&LK16);}
static LKF15(int narg, ...) {TRAMPOLINK(VV[68],&LK15);}
static LKF14(int narg, ...) {TRAMPOLINK(VV[101],&LK14);}
static LKF13(int narg, ...) {TRAMPOLINK(VV[100],&LK13);}
static LKF12(int narg, ...) {TRAMPOLINK(VV[99],&LK12);}
static LKF11(int narg, ...) {TRAMPOLINK(VV[98],&LK11);}
static LKF10(int narg, ...) {TRAMPOLINK(VV[97],&LK10);}
static LKF9(int narg, ...) {TRAMPOLINK(VV[96],&LK9);}
static LKF8(int narg, ...) {TRAMPOLINK(VV[94],&LK8);}
static LKF7(int narg, ...) {TRAMPOLINK(VV[93],&LK7);}
static LKF6(int narg, ...) {TRAMPOLINK(VV[92],&LK6);}
static LKF5(int narg, ...) {TRAMPOLINK(VV[91],&LK5);}
static LKF4(int narg, ...) {TRAMPOLINK(VV[90],&LK4);}
static LKF3(int narg, ...) {TRAMPOLINK(VV[89],&LK3);}
static LKF2(int narg, ...) {TRAMPOLINK(VV[87],&LK2);}
static LKF1(int narg, ...) {TRAMPOLINK(VV[86],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[85],&LK0);}
