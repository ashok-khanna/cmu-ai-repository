
/* (c) Copyright G. Attardi, 1993. */
#include <ecl.h>
#include "evalmacros.h"
init_evalmacros(int size, object data_stream)
{VT2 CLSR2
	volatile object VVprotect;
	Cblock.cd_start=(char *)init_evalmacros; Cblock.cd_size=size;
	VVprotect=Cblock.cd_data=read_VV(VV,VM1,data_stream);
	MM0(VV[49],L1);
	MM0(VV[50],L2);
	MM0(VV[51],L3);
	MM0(VV[52],L4);
	MM0(VV[53],L5);
	MM0(VV[54],L6);
	MM0(VV[55],L7);
	MM0(VV[56],L8);
	MM0(VV[36],L9);
	MM0(VV[57],L10);
	MM0(VV[11],L11);
	MM0(VV[5],L12);
	MM0(VV[58],L13);
	MM0(VV[59],L14);
	MM0(VV[60],L15);
	MM0(VV[61],L16);
	MM0(VV[33],L17);
	MM0(VV[62],L18);
	MM0(VV[63],L19);
	MF0(VV[64],L20);
	MM0(VV[65],L21);
	MM0(VV[41],L22);
	MM0(VV[66],L23);
	MM0(VV[35],L24);
	MM0(VV[67],L25);
	MM0(VV[68],L26);
}
/*	macro definition for DEFVAR                                   */
static L1(int narg, object V1, object V2)
{ VT3 VLEX3 CLSR3
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6,V7;
	if(endp(V3))FEinvalid_macro_call(VV[49]);
	V4= CAR(V3);
	V3=CDR(V3);
	if(endp(V3)){
	V5= Cnil;
	V6= Cnil;
	} else {
	V5= CAR(V3);
	V6= Ct;
	V3=CDR(V3);}
	if(endp(V3)){
	V7= Cnil;
	} else {
	V7= CAR(V3);
	V3=CDR(V3);}
	if(!endp(V3))FEinvalid_macro_call(VV[49]);
	{object V8= list(2,VV[1],list(2,VV[2],(V4)));
	if(((V7))==Cnil){
	goto L5;}
	T0= CONS(list(4,VV[3],list(2,VV[2],(V4)),(V7),VV[4]),Cnil);
	goto L3;
L5:
	T0= Cnil;
L3:
	if(((V6))==Cnil){
	goto L9;}
	{object V9= list(2,VV[6],list(2,VV[2],(V4)));
	T1= CONS(list(3,VV[5],(V9),list(3,VV[7],(V4),(V5))),Cnil);
	goto L7;}
L9:
	T1= Cnil;
L7:
	Lappend(3,T0,T1,CONS(list(2,VV[2],(V4)),Cnil))/*  APPEND      */;
	VALUES(0) = listA(3,VV[0],(V8),VALUES(0));
	RETURN(1);}}
}
/*	macro definition for DEFPARAMETER                             */
static L2(int narg, object V1, object V2)
{ VT4 VLEX4 CLSR4
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6;
	if(endp(V3))FEinvalid_macro_call(VV[50]);
	V4= CAR(V3);
	V3=CDR(V3);
	if(endp(V3))FEinvalid_macro_call(VV[50]);
	V5= CAR(V3);
	V3=CDR(V3);
	if(endp(V3)){
	V6= Cnil;
	} else {
	V6= CAR(V3);
	V3=CDR(V3);}
	if(!endp(V3))FEinvalid_macro_call(VV[50]);
	{object V7= list(2,VV[1],list(2,VV[2],(V4)));
	if(((V6))==Cnil){
	goto L15;}
	T0= CONS(list(4,VV[3],list(2,VV[2],(V4)),(V6),VV[8]),Cnil);
	goto L13;
L15:
	T0= Cnil;
L13:
	{object V8= list(3,VV[7],(V4),(V5));
	{object V9= list(2,VV[12],list(2,VV[2],(V5)));
	{object V10= list(3,VV[9],VV[10],list(3,VV[11],(V9),list(2,VV[13],list(2,VV[2],list(3,VV[14],TYPE_OF((V5)),(V4))))));
	VALUES(0) = listA(3,VV[0],(V7),append(T0,list(3,(V8),(V10),list(2,VV[2],(V4)))));
	RETURN(1);}}}}}
}
/*	macro definition for DEFCONSTANT                              */
static L3(int narg, object V1, object V2)
{ VT5 VLEX5 CLSR5
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6;
	if(endp(V3))FEinvalid_macro_call(VV[51]);
	V4= CAR(V3);
	V3=CDR(V3);
	if(endp(V3))FEinvalid_macro_call(VV[51]);
	V5= CAR(V3);
	V3=CDR(V3);
	if(endp(V3)){
	V6= Cnil;
	} else {
	V6= CAR(V3);
	V3=CDR(V3);}
	if(!endp(V3))FEinvalid_macro_call(VV[51]);
	{object V7= list(3,VV[15],list(2,VV[2],(V4)),(V5));
	if(((V6))==Cnil){
	goto L20;}
	T0= CONS(list(4,VV[3],list(2,VV[2],(V4)),(V6),VV[16]),Cnil);
	goto L18;
L20:
	T0= Cnil;
L18:
	VALUES(0) = listA(3,VV[0],(V7),append(T0,CONS(list(2,VV[2],(V4)),Cnil)));
	RETURN(1);}}
}
/*	macro definition for AND                                      */
static L4(int narg, object V1, object V2)
{ VT6 VLEX6 CLSR6
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4;
	V4= V3;
	if(!(endp((V4)))){
	goto L23;}
	VALUES(0) = Ct;
	RETURN(1);
L23:
	{volatile object V5;                      /*  RES             */
	volatile object V6;                       /*  INSERT          */
	volatile object V7;                       /*  FS              */
	V5= VV[17];
	V6= (V5);
	V7= (V4);
L29:
	if(!(endp(cdr((V7))))){
	goto L30;}
	if(type_of((V6))!=t_cons)FEwrong_type_argument(Scons,(V6));
	CAR((V6)) = car((V7));
	VALUES(0) = car((V5));
	RETURN(1);
L30:
	if(type_of((V6))!=t_cons)FEwrong_type_argument(Scons,(V6));
	CAR((V6)) = list(3,VV[18],car((V7)),Cnil);
	VALUES(0) = (V6);
	V6= cddar(VALUES(0));
	V7= cdr((V7));
	goto L29;
	}}
}
/*	macro definition for OR                                       */
static L5(int narg, object V1, object V2)
{ VT7 VLEX7 CLSR7
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4;
	V4= V3;
	if(!(endp((V4)))){
	goto L41;}
	VALUES(0) = Cnil;
	RETURN(1);
L41:
	{volatile object V5;                      /*  X               */
	V5= reverse((V4));
	{volatile object V6;                      /*  FORMS           */
	volatile object V7;                       /*  FORM            */
	V6= cdr((V5));
	V7= car((V5));
L47:
	if(!(endp((V6)))){
	goto L48;}
	VALUES(0) = (V7);
	RETURN(1);
L48:
	{volatile object V9;
	V9= cdr((V6));
	{register object V10;                     /*  TEMP            */
	Lgensym(0)                                /*  GENSYM          */;
	V10= VALUES(0);
	{object V11= CONS(list(2,(V10),car((V6))),Cnil);
	V7= list(3,VV[19],(V11),list(4,VV[18],(V10),(V10),(V7)));}
	}
	V6= (V9);}
	goto L47;
	}
	}}
}
/*	macro definition for LOCALLY                                  */
static L6(int narg, object V1, object V2)
{ VT8 VLEX8 CLSR8
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4;
	V4= V3;
	VALUES(0) = listA(3,VV[19],Cnil,(V4));
	RETURN(1);}
}
/*	macro definition for LOOP                                     */
static L7(int narg, object V1, object V2)
{ VT9 VLEX9 CLSR9
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5;
	V4= V3;
	Lgensym(0)                                /*  GENSYM          */;
	V5= VALUES(0);
	{object V6= CONS(VV[0],(V4));
	VALUES(0) = list(3,VV[20],Cnil,list(4,VV[21],(V5),(V6),list(2,VV[22],(V5))));
	RETURN(1);}}
}
/*	macro definition for DEFUN                                    */
static L8(int narg, object V1, object V2)
{ VT10 VLEX10 CLSR10
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6;
	if(endp(V3))FEinvalid_macro_call(VV[56]);
	V4= CAR(V3);
	V3=CDR(V3);
	if(endp(V3))FEinvalid_macro_call(VV[56]);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= V3;
	{ int V7;
	object V8;                                /*  DOC             */
	object V9;                                /*  DECL            */
	object V10;                               /*  BODY            */
	V7=(*LK0)(2,(V6),Cnil)                    /*  FIND-DOC        */;
	if (V7--==0) goto L58;
	V8= VALUES(0);
	if (V7--==0) goto L59;
	V9= VALUES(1);
	if (V7--==0) goto L60;
	V10= VALUES(2);
	goto L61;
L58:
	V8= Cnil;
L59:
	V9= Cnil;
L60:
	V10= Cnil;
L61:
	{object V11= list(2,VV[24],list(2,VV[2],(V4)));
	{object V12= list(3,VV[23],(V11),list(2,VV[25],listA(3,VV[26],(V5),append((V9),CONS(listA(3,VV[20],(V4),(V10)),Cnil)))));
	if(((V8))==Cnil){
	goto L64;}
	T0= CONS(list(3,VV[23],list(3,VV[27],list(2,VV[2],(V4)),VV[28]),(V8)),Cnil);
	goto L62;
L64:
	T0= Cnil;
L62:
	VALUES(0) = listA(3,VV[0],(V12),append(T0,CONS(list(2,VV[2],(V4)),Cnil)));
	RETURN(1);}}}}
}
/*	macro definition for PSETQ                                    */
static L9(int narg, object V1, object V2)
{ VT11 VLEX11 CLSR11
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4;
	V4= V3;
	{volatile object V5;                      /*  L               */
	volatile object V6;                       /*  FORMS           */
	volatile object V7;                       /*  BINDINGS        */
	V5= (V4);
	V6= Cnil;
	V7= Cnil;
L67:
	if(!(endp((V5)))){
	goto L68;}
	{object V9= nreverse((V7));
	VALUES(0) = listA(3,VV[29],(V9),nreverse(CONS(Cnil,(V6))));
	RETURN(1);}
L68:
	{register object V10;                     /*  SYM             */
	Lgensym(0)                                /*  GENSYM          */;
	V10= VALUES(0);
	V7= CONS(list(2,(V10),cadr((V5))),(V7));
	V6= CONS(list(3,VV[7],car((V5)),(V10)),(V6));
	}
	V5= cddr((V5));
	goto L67;
	}}
}
/*	macro definition for COND                                     */
static L10(int narg, object V1, object V2)
{ VT12 VLEX12 CLSR12
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5;
	V4= V3;
	V5= Cnil;
	{volatile object V6;
	volatile object V7;                       /*  L               */
	V6= reverse((V4));
	V7= Cnil;
L83:
	if(!(endp((V6)))){
	goto L84;}
	VALUES(0) = (V5);
	RETURN(1);
L84:
	V7= car((V6));
	if(!(endp(cdr((V7))))){
	goto L91;}
	if(!((car((V7)))==(Ct))){
	goto L94;}
	V5= Ct;
	goto L89;
L94:
	{register object V9;                      /*  SYM             */
	Lgensym(0)                                /*  GENSYM          */;
	V9= VALUES(0);
	{object V10= CONS(list(2,(V9),car((V7))),Cnil);
	V5= list(3,VV[19],(V10),list(4,VV[18],(V9),(V9),(V5)));}
	goto L89;
	}
L91:
	if(!((car((V7)))==(Ct))){
	goto L100;}
	if(!(endp(cddr((V7))))){
	goto L104;}
	V5= cadr((V7));
	goto L102;
L104:
	V5= CONS(VV[0],cdr((V7)));
L102:
	goto L89;
L100:
	if(!(endp(cddr((V7))))){
	goto L108;}
	V5= list(4,VV[18],car((V7)),cadr((V7)),(V5));
	goto L106;
L108:
	{object V10= car((V7));
	V5= list(4,VV[18],(V10),CONS(VV[0],cdr((V7))),(V5));}
L106:
L89:
	V6= cdr((V6));
	goto L83;
	}}
}
/*	macro definition for WHEN                                     */
static L11(int narg, object V1, object V2)
{ VT13 VLEX13 CLSR13
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5;
	if(endp(V3))FEinvalid_macro_call(VV[11]);
	V4= CAR(V3);
	V3=CDR(V3);
	V5= V3;
	VALUES(0) = list(3,VV[18],(V4),CONS(VV[0],(V5)));
	RETURN(1);}
}
/*	macro definition for UNLESS                                   */
static L12(int narg, object V1, object V2)
{ VT14 VLEX14 CLSR14
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5;
	if(endp(V3))FEinvalid_macro_call(VV[5]);
	V4= CAR(V3);
	V3=CDR(V3);
	V5= V3;
	{object V6= list(2,VV[30],(V4));
	VALUES(0) = list(3,VV[18],(V6),CONS(VV[0],(V5)));
	RETURN(1);}}
}
/*	macro definition for PROG                                     */
static L13(int narg, object V1, object V2)
{ VT15 VLEX15 CLSR15
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6;
	if(endp(V3))FEinvalid_macro_call(VV[58]);
	V4= CAR(V3);
	V3=CDR(V3);
	V5= V3;
	V6= Cnil;
	{ int V7;
	V7=(*LK1)(1,(V5))                         /*  FIND-DECLARATIONS*/;
	if (V7>0) {
	V6= VALUES(0);
	V7--;
	} else {
	V6= Cnil;}
	if (V7>0) {
	V5= VALUES(1);
	} else {
	V5= Cnil;}
	
	}
	VALUES(0) = list(3,VV[20],Cnil,listA(3,VV[19],(V4),append((V6),CONS(CONS(VV[21],(V5)),Cnil))));
	RETURN(1);}
}
/*	macro definition for PROG*                                    */
static L14(int narg, object V1, object V2)
{ VT16 VLEX16 CLSR16
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6;
	if(endp(V3))FEinvalid_macro_call(VV[59]);
	V4= CAR(V3);
	V3=CDR(V3);
	V5= V3;
	V6= Cnil;
	{ int V7;
	V7=(*LK1)(1,(V5))                         /*  FIND-DECLARATIONS*/;
	if (V7>0) {
	V6= VALUES(0);
	V7--;
	} else {
	V6= Cnil;}
	if (V7>0) {
	V5= VALUES(1);
	} else {
	V5= Cnil;}
	
	}
	VALUES(0) = list(3,VV[20],Cnil,listA(3,VV[29],(V4),append((V6),CONS(CONS(VV[21],(V5)),Cnil))));
	RETURN(1);}
}
/*	macro definition for PROG1                                    */
static L15(int narg, object V1, object V2)
{ VT17 VLEX17 CLSR17
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6;
	if(endp(V3))FEinvalid_macro_call(VV[60]);
	V4= CAR(V3);
	V3=CDR(V3);
	V5= V3;
	Lgensym(0)                                /*  GENSYM          */;
	V6= VALUES(0);
	{object V7= CONS(list(2,(V6),(V4)),Cnil);
	VALUES(0) = listA(3,VV[19],(V7),append((V5),CONS((V6),Cnil)));
	RETURN(1);}}
}
/*	macro definition for PROG2                                    */
static L16(int narg, object V1, object V2)
{ VT18 VLEX18 CLSR18
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6,V7;
	if(endp(V3))FEinvalid_macro_call(VV[61]);
	V4= CAR(V3);
	V3=CDR(V3);
	if(endp(V3))FEinvalid_macro_call(VV[61]);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= V3;
	Lgensym(0)                                /*  GENSYM          */;
	V7= VALUES(0);
	{object V8= CONS(list(2,(V7),(V5)),Cnil);
	VALUES(0) = list(3,VV[0],(V4),listA(3,VV[19],(V8),append((V6),CONS((V7),Cnil))));
	RETURN(1);}}
}
/*	macro definition for MULTIPLE-VALUE-LIST                      */
static L17(int narg, object V1, object V2)
{ VT19 VLEX19 CLSR19
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4;
	if(endp(V3))FEinvalid_macro_call(VV[33]);
	V4= CAR(V3);
	V3=CDR(V3);
	if(!endp(V3))FEinvalid_macro_call(VV[33]);
	VALUES(0) = list(3,VV[31],VV[32],(V4));
	RETURN(1);}
}
/*	macro definition for MULTIPLE-VALUE-SETQ                      */
static L18(int narg, object V1, object V2)
{ VT20 VLEX20 CLSR20
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5;
	if(endp(V3))FEinvalid_macro_call(VV[62]);
	V4= CAR(V3);
	V3=CDR(V3);
	if(endp(V3))FEinvalid_macro_call(VV[62]);
	V5= CAR(V3);
	V3=CDR(V3);
	if(!endp(V3))FEinvalid_macro_call(VV[62]);
	{volatile object V6;                      /*  VL              */
	volatile object V7;                       /*  SYM             */
	volatile object V8;                       /*  FORMS           */
	volatile int V9;                          /*  N               */
	Lgensym(0)                                /*  GENSYM          */;
	V7= VALUES(0);
	V9= 0;
	V6= (V4);
	V8= Cnil;
L124:
	if(!(endp((V6)))){
	goto L125;}
	VALUES(0) = listA(3,VV[19],CONS(list(2,(V7),list(2,VV[33],(V5))),Cnil),(V8));
	RETURN(1);
L125:
	{object V11= car((V6));
	V8= CONS(list(3,VV[7],(V11),list(3,VV[34],MAKE_FIXNUM(V9),(V7))),(V8));}
	V6= cdr((V6));
	V9= (V9)+1;
	goto L124;
	}}
}
/*	macro definition for MULTIPLE-VALUE-BIND                      */
static L19(int narg, object V1, object V2)
{ VT21 VLEX21 CLSR21
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6;
	if(endp(V3))FEinvalid_macro_call(VV[63]);
	V4= CAR(V3);
	V3=CDR(V3);
	if(endp(V3))FEinvalid_macro_call(VV[63]);
	V5= CAR(V3);
	V3=CDR(V3);
	V6= V3;
	{volatile object V7;                      /*  VL              */
	volatile object V8;                       /*  SYM             */
	volatile object V9;                       /*  BIND            */
	volatile int V10;                         /*  N               */
	Lgensym(0)                                /*  GENSYM          */;
	V8= VALUES(0);
	V10= 0;
	V7= (V4);
	V9= Cnil;
L137:
	if(!(endp((V7)))){
	goto L138;}
	{object V12= list(2,(V8),list(2,VV[33],(V5)));
	VALUES(0) = listA(3,VV[29],CONS((V12),nreverse((V9))),(V6));
	RETURN(1);}
L138:
	{object V13= car((V7));
	V9= CONS(list(2,(V13),list(3,VV[34],MAKE_FIXNUM(V10),(V8))),(V9));}
	V7= cdr((V7));
	V10= (V10)+1;
	goto L137;
	}}
}
/*	function definition for DO/DO*-EXPAND                         */
static L20(int narg, object V1, object V2, object V3, object V4, object V5, object V6)
{ VT22 VLEX22 CLSR22
	cs_check;
	check_arg(6);
TTL:
	{object V7;                               /*  DECL            */
	object V8;                                /*  LABEL           */
	register object V9;                       /*  VL              */
	register object V10;                      /*  STEP            */
	V7= Cnil;
	Lgensym(0)                                /*  GENSYM          */;
	V8= VALUES(0);
	V9= Cnil;
	V10= Cnil;
	{ int V11;
	V11=(*LK1)(1,(V4))                        /*  FIND-DECLARATIONS*/;
	if (V11>0) {
	V7= VALUES(0);
	V11--;
	} else {
	V7= Cnil;}
	if (V11>0) {
	V4= VALUES(1);
	} else {
	V4= Cnil;}
	
	}
	{volatile object V11;
	volatile object V12;                      /*  C               */
	V11= (V1);
	V12= Cnil;
L157:
	if(!(endp((V11)))){
	goto L158;}
	goto L153;
L158:
	V12= car((V11));
	if(!(type_of((V12))==t_symbol)){
	goto L163;}
	V12= CONS((V12),Cnil);
L163:
	V9= CONS(list(2,car((V12)),cadr((V12))),(V9));
	if(endp(cddr((V12)))){
	goto L169;}
	V10= CONS(car((V12)),(V10));
	V10= CONS(caddr((V12)),(V10));
L169:
	V11= cdr((V11));
	goto L157;
	}
L153:
	{object V11= nreverse((V9));
	{object V12= list(3,VV[18],(V2),list(2,VV[35],CONS(VV[0],(V3))));
	{object V13= CONS((V6),nreverse((V10)));
	VALUES(0) = list(3,VV[20],Cnil,listA(3,(V5),(V11),append((V7),CONS(listA(4,VV[21],(V8),(V12),append((V4),list(2,(V13),list(2,VV[22],(V8))))),Cnil))));
	RETURN(1);}}}
	}
}
/*	macro definition for DO                                       */
static L21(int narg, object V1, object V2)
{ VT23 VLEX23 CLSR23
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6,V7;
	if(endp(V3))FEinvalid_macro_call(VV[65]);
	V4= CAR(V3);
	V3=CDR(V3);
	if(endp(V3))FEinvalid_macro_call(VV[65]);
	{object V8= CAR(V3);
	if(endp(V8))FEinvalid_macro_call(VV[65]);
	V5= CAR(V8);
	V8=CDR(V8);
	V6= V8;}
	V3=CDR(V3);
	V7= V3;
	RETURN(L20(6,(V4),(V5),(V6),(V7),VV[19],VV[36])/*  DO/DO*-EXPAND*/);}
}
/*	macro definition for DO*                                      */
static L22(int narg, object V1, object V2)
{ VT24 VLEX24 CLSR24
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6,V7;
	if(endp(V3))FEinvalid_macro_call(VV[41]);
	V4= CAR(V3);
	V3=CDR(V3);
	if(endp(V3))FEinvalid_macro_call(VV[41]);
	{object V8= CAR(V3);
	if(endp(V8))FEinvalid_macro_call(VV[41]);
	V5= CAR(V8);
	V8=CDR(V8);
	V6= V8;}
	V3=CDR(V3);
	V7= V3;
	RETURN(L20(6,(V4),(V5),(V6),(V7),VV[29],VV[7])/*  DO/DO*-EXPAND*/);}
}
/*	macro definition for CASE                                     */
static L23(int narg, object V1, object V2)
{ VT25 VLEX25 CLSR25
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6,V7;
	if(endp(V3))FEinvalid_macro_call(VV[66]);
	V4= CAR(V3);
	V3=CDR(V3);
	V5= V3;
	V6= Cnil;
	Lgensym(0)                                /*  GENSYM          */;
	V7= VALUES(0);
	{volatile object V8;
	volatile object V9;                       /*  CLAUSE          */
	V8= reverse((V5));
	V9= Cnil;
L183:
	if(!(endp((V8)))){
	goto L184;}
	VALUES(0) = list(3,VV[19],CONS(list(2,(V7),(V4)),Cnil),(V6));
	RETURN(1);
L184:
	V9= car((V8));
	if((car((V9)))==(Ct)){
	goto L190;}
	if(!((car((V9)))==(VV[37]))){
	goto L191;}
L190:
	V6= CONS(VV[0],cdr((V9)));
	goto L189;
L191:
	if(!(type_of(car((V9)))==t_cons)){
	goto L197;}
	{object V11= list(3,VV[38],(V7),list(2,VV[2],car((V9))));
	V6= list(4,VV[18],(V11),CONS(VV[0],cdr((V9))),(V6));}
	goto L189;
L197:
	if((car((V9)))==Cnil){
	goto L189;}
	{object V11= list(3,VV[39],(V7),list(2,VV[2],car((V9))));
	V6= list(4,VV[18],(V11),CONS(VV[0],cdr((V9))),(V6));}
L189:
	V8= cdr((V8));
	goto L183;
	}}
}
/*	macro definition for RETURN                                   */
static L24(int narg, object V1, object V2)
{ VT26 VLEX26 CLSR26
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4;
	if(endp(V3)){
	V4= Cnil;
	} else {
	V4= CAR(V3);
	V3=CDR(V3);}
	if(!endp(V3))FEinvalid_macro_call(VV[35]);
	VALUES(0) = list(3,VV[40],Cnil,(V4));
	RETURN(1);}
}
/*	macro definition for DOLIST                                   */
static L25(int narg, object V1, object V2)
{ VT27 VLEX27 CLSR27
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6,V7,V8,V9;
	if(endp(V3))FEinvalid_macro_call(VV[67]);
	{object V10= CAR(V3);
	if(endp(V10))FEinvalid_macro_call(VV[67]);
	V4= CAR(V10);
	V10=CDR(V10);
	if(endp(V10))FEinvalid_macro_call(VV[67]);
	V5= CAR(V10);
	V10=CDR(V10);
	if(endp(V10)){
	V6= Cnil;
	} else {
	V6= CAR(V10);
	V10=CDR(V10);}
	if(!endp(V10))FEinvalid_macro_call(VV[67]);}
	V3=CDR(V3);
	V7= V3;
	Lgensym(0)                                /*  GENSYM          */;
	V8= VALUES(0);
	V9= Cnil;
	{ int V11;
	V11=(*LK1)(1,(V7))                        /*  FIND-DECLARATIONS*/;
	if (V11>0) {
	V9= VALUES(0);
	V11--;
	} else {
	V9= Cnil;}
	if (V11>0) {
	V7= VALUES(1);
	} else {
	V7= Cnil;}
	
	}
	{object V11= list(3,(V8),(V5),list(2,VV[42],(V8)));
	{object V12= list(2,(V11),CONS((V4),Cnil));
	{object V13= list(2,list(2,VV[43],(V8)),(V6));
	VALUES(0) = listA(4,VV[41],(V12),(V13),append((V9),CONS(list(3,VV[7],(V4),list(2,VV[44],(V8))),(V7))));
	RETURN(1);}}}}
}
/*	macro definition for DOTIMES                                  */
static L26(int narg, object V1, object V2)
{ VT28 VLEX28 CLSR28
	cs_check;
	check_arg(2);
	{object V3=CDR(V1),V4,V5,V6,V7,V8;
	if(endp(V3))FEinvalid_macro_call(VV[68]);
	{object V9= CAR(V3);
	if(endp(V9))FEinvalid_macro_call(VV[68]);
	V4= CAR(V9);
	V9=CDR(V9);
	if(endp(V9))FEinvalid_macro_call(VV[68]);
	V5= CAR(V9);
	V9=CDR(V9);
	if(endp(V9)){
	V6= Cnil;
	} else {
	V6= CAR(V9);
	V9=CDR(V9);}
	if(!endp(V9))FEinvalid_macro_call(VV[68]);}
	V3=CDR(V3);
	V7= V3;
	Lgensym(0)                                /*  GENSYM          */;
	V8= VALUES(0);
	{object V10= list(2,(V8),(V5));
	{object V11= list(2,(V10),list(3,(V4),MAKE_FIXNUM(0),list(2,VV[45],(V4))));
	{object V12= list(2,list(3,VV[46],(V4),(V8)),(V6));
	VALUES(0) = listA(5,VV[41],(V11),(V12),list(2,VV[47],list(2,VV[48],(V4))),(V7));
	RETURN(1);}}}}
}
static LKF1(int narg, ...) {TRAMPOLINK(VV[70],&LK1);}
static LKF0(int narg, ...) {TRAMPOLINK(VV[69],&LK0);}
