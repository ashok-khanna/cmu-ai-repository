/*
:comment "Compiled at 12:31:55 pm on Sunday, June 12, 1994"
:comment "Compiler Configuration: DEFAULT"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w -g -O "
:version 0
:package (IN-PACKAGE (QUOTE PCL)) 
:end-package-info 0
:sym NIL
:sym QUOTE
:sym EVAL-WHEN
:sym MAKE-PROGN
:sym DEFMETHOD
:sym DEFCLASS
:sym CLASS
:sym METHOD
:sym METHOD-COMBINATION
:sym LISP::MEMQ
:sym CAPITALIZE-WORDS
:sym FORMAT
:sf MAKE-TOP-LEVEL-FORM "p_pcl_MAKE_2DTOP_2DLEVEL_2DFORM"
:sym PROGN
:sf MAKE-PROGN "p_pcl_MAKE_2DPROGN"
:sym EXPAND-DEFCLASS
:sm DEFCLASS "m_pcl_DEFCLASS"
:sym COPY-TREE
:sym STANDARD-CLASS
:sym :METACLASS
:sym LEGAL-CLASS-NAME-P
:sym ERROR
:sym REMOVE
:sym T
:sym *INITFUNCTIONS*
:sym *ACCESSORS*
:sym CANONICALIZE-SLOT-SPECIFICATION
:sym CANONICALIZE-DEFCLASS-OPTION
:sym DO-STANDARD-DEFSETFS-FOR-DEFCLASS
:sym *DEFCLASS-TIMES*
:sym LOAD-DEFCLASS
:sym LIST
:sym APPEND
:sym LET
:sym MAKE-TOP-LEVEL-FORM
:sf EXPAND-DEFCLASS "p_pcl_EXPAND_2DDEFCLASS"
:sym EQUAL
:sym FUNCTION
:sym TRUE
:sym FALSE
:sym ZERO
:sym IDENTITY
:sym LISP::ASSOC/4
:sym LISP::GENSYM/1
:sym LAMBDA
:sf MAKE-INITFUNCTION "p_pcl_MAKE_2DINITFUNCTION"
:sym KEYWORDP
:sym :NAME
:sym :INITFORM
:sym GETF
:sym :ACCESSOR
:sym SETF
:sym :READER
:sym :WRITER
:sym :INITARG
:sym :READERS
:sym :WRITERS
:sym :INITARGS
:sym LIST*
:sym :INITFUNCTION
:sym MAKE-INITFUNCTION
:sf CANONICALIZE-SLOT-SPECIFICATION "p_pcl_CANONICALIZE_2DSLOT_2DSPECIFICATION"
:sym :DEFAULT-INITARGS
:sym NREVERSE
:sym :DIRECT-DEFAULT-INITARGS
:sf CANONICALIZE-DEFCLASS-OPTION "p_pcl_CANONICALIZE_2DDEFCLASS_2DOPTION"
:sym EARLY-CLASS-DEFINITION
:sf MAKE-EARLY-CLASS-DEFINITION "p_pcl_MAKE_2DEARLY_2DCLASS_2DDEFINITION"
:sym NTH
:sf ECD-CLASS-NAME "p_pcl_ECD_2DCLASS_2DNAME"
:sf ECD-SOURCE "p_pcl_ECD_2DSOURCE"
:sf ECD-METACLASS "p_pcl_ECD_2DMETACLASS"
:sf ECD-SUPERCLASS-NAMES "p_pcl_ECD_2DSUPERCLASS_2DNAMES"
:sf ECD-CANONICAL-SLOTS "p_pcl_ECD_2DCANONICAL_2DSLOTS"
:sf ECD-OTHER-INITARGS "p_pcl_ECD_2DOTHER_2DINITARGS"
:proclaim (QUOTE (NOTINLINE LOAD-DEFCLASS))
:sym LOAD-TRUENAME
:sym MAKE-EARLY-CLASS-DEFINITION
:sym *EARLY-CLASS-DEFINITIONS*
:sym :KEY
:sym ECD-CLASS-NAME
:sym FIND
:sf LOAD-DEFCLASS "p_pcl_LOAD_2DDEFCLASS"
:sym LOAD
:sym EVAL
:sym :VAR
:sym LISP::DEFINE-VARIABLE
:sym *DEFMETHOD-TIMES*
:sym *DEFGENERIC-TIMES*
:sym LISP::DEFINE-MACRO
:sym :PARAMETER
:sf DEFCLASS_INIT229 "p_pcl_DEFCLASS_5FINIT229"
:init DEFCLASS_INIT229
:pinfo PCL::CANONICALIZE-SLOT-SPECIFICATION (PCL:CLASS-NAME PCL::SPEC) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::MAKE-EARLY-CLASS-DEFINITION (PCL::NAME PCL::SOURCE PCL::METACLASS PCL::SUPERCLASS-NAMES PCL::CANONICAL-SLOTS PCL::OTHER-INITARGS) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::MAKE-INITFUNCTION (PCL::INITFORM) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::LOAD-DEFCLASS (PCL::NAME PCL::METACLASS PCL::SUPERS PCL::CANONICAL-SLOTS PCL::CANONICAL-OPTIONS PCL::ACCESSOR-NAMES) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::ECD-CLASS-NAME (PCL::ECD) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::ECD-SOURCE (PCL::ECD) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::ECD-SUPERCLASS-NAMES (PCL::ECD) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::ECD-METACLASS (PCL::ECD) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::MAKE-PROGN (&REST PCL::FORMS) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::EXPAND-DEFCLASS (PCL::NAME PCL::SUPERS PCL::SLOTS PCL::OPTIONS) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::ECD-OTHER-INITARGS (PCL::ECD) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::CANONICALIZE-DEFCLASS-OPTION (PCL:CLASS-NAME PCL::OPTION) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::ECD-CANONICAL-SLOTS (PCL::ECD) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::DEFCLASS_INIT229 NIL NIL NIL NIL NIL NIL NIL T
:pinfo PCL::MAKE-TOP-LEVEL-FORM (PCL::NAME PCL::TIMES PCL::FORM) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_pcl_MAKE_2DTOP_2DLEVEL_2DFORM();
extern LP p_pcl_MAKE_2DTOP_2DLEVEL_2DFORM_2DDEFINITION_2DNAME1194();
extern SYMBOL s_lsp_NIL; 
extern SYMBOL s_lsp_QUOTE; 
extern SYMBOL s_lsp_EVAL_2DWHEN; 
extern SYMBOL s_pcl_MAKE_2DPROGN; 
extern SYMBOL s_pcl_DEFMETHOD; 
extern SYMBOL s_pcl_DEFCLASS; 
extern SYMBOL s_pcl_CLASS; 
extern SYMBOL s_pcl_METHOD; 
extern SYMBOL s_pcl_METHOD_2DCOMBINATION; 
MAKE_CONS(k1199,LREF(s_pcl_METHOD_2DCOMBINATION),LREF(s_lsp_NIL));
MAKE_CONS(k1198,LREF(s_pcl_METHOD),LREF(k1199));
MAKE_CONS(k1197,LREF(s_pcl_CLASS),LREF(k1198));
MAKE_CONS(k1196,LREF(s_pcl_DEFCLASS),LREF(k1197));
MAKE_CONS(k1195,LREF(s_pcl_DEFMETHOD),LREF(k1196));
extern SYMBOL s_lsp_MEMQ; 
MAKE_SIMPLE_STRING(k1200,9,"~A~{ ~S~}");
extern SYMBOL s_pcl_CAPITALIZE_2DWORDS; 
extern SYMBOL s_lsp_FORMAT; 
MAKE_SIMPLE_STRING(k1201,2,"~S");
extern LP p_pcl_MAKE_2DPROGN();
extern LP p_pcl_MAKE_2DPROGN_2DCOLLECT_2DFORMS1202();
extern SYMBOL s_lsp_PROGN; 
extern LP m_pcl_DEFCLASS();
extern SYMBOL s_pcl_EXPAND_2DDEFCLASS; 
extern LP p_pcl_EXPAND_2DDEFCLASS();
extern SYMBOL s_lsp_COPY_2DTREE; 
extern SYMBOL s_pcl_STANDARD_2DCLASS; 
extern SYMBOL s_key_METACLASS; 
extern SYMBOL s_pcl_LEGAL_2DCLASS_2DNAME_2DP; 
static struct {unsigned long header; char string[91+1];}
k1203  = {((91 << 8) + TYPE_SIMPLE_STRING), 
"The value of the :metaclass option (~S) is not a~%~\n                      legal class name."};
extern SYMBOL s_lsp_ERROR; 
extern SYMBOL s_lsp_REMOVE; 
extern SYMBOL s_lsp_T; 
MAKE_SIMPLE_STRING(k1204,34,"~S is not a legal defclass option.");
extern SYMBOL s_pcl__2AINITFUNCTIONS_2A; 
extern SYMBOL s_pcl__2AACCESSORS_2A; 
extern SYMBOL s_pcl_CANONICALIZE_2DSLOT_2DSPECIFICATION; 
extern SYMBOL s_pcl_CANONICALIZE_2DDEFCLASS_2DOPTION; 
extern SYMBOL s_pcl_DO_2DSTANDARD_2DDEFSETFS_2DFOR_2DDEFCLASS; 
extern SYMBOL s_pcl__2ADEFCLASS_2DTIMES_2A; 
extern SYMBOL s_pcl_LOAD_2DDEFCLASS; 
extern SYMBOL s_lsp_LIST; 
extern SYMBOL s_lsp_APPEND; 
extern SYMBOL s_lsp_LET; 
extern SYMBOL s_pcl_MAKE_2DTOP_2DLEVEL_2DFORM; 
extern LP p_pcl_MAKE_2DINITFUNCTION();
MAKE_CONS(k1206,LREF(s_lsp_T),LREF(s_lsp_NIL));
MAKE_CONS(k1205,LREF(s_lsp_QUOTE),LREF(k1206));
extern SYMBOL s_lsp_EQUAL; 
extern SYMBOL s_lsp_FUNCTION; 
extern SYMBOL s_pcl_TRUE; 
MAKE_CONS(k1208,LREF(s_pcl_TRUE),LREF(s_lsp_NIL));
MAKE_CONS(k1207,LREF(s_lsp_FUNCTION),LREF(k1208));
MAKE_CONS(k1210,LREF(s_lsp_NIL),LREF(s_lsp_NIL));
MAKE_CONS(k1209,LREF(s_lsp_QUOTE),LREF(k1210));
extern SYMBOL s_pcl_FALSE; 
MAKE_CONS(k1212,LREF(s_pcl_FALSE),LREF(s_lsp_NIL));
MAKE_CONS(k1211,LREF(s_lsp_FUNCTION),LREF(k1212));
MAKE_CONS(k1214,(LP) 0,LREF(s_lsp_NIL));
MAKE_CONS(k1213,LREF(s_lsp_QUOTE),LREF(k1214));
extern SYMBOL s_pcl_ZERO; 
MAKE_CONS(k1216,LREF(s_pcl_ZERO),LREF(s_lsp_NIL));
MAKE_CONS(k1215,LREF(s_lsp_FUNCTION),LREF(k1216));
extern SYMBOL s_lsp_IDENTITY; 
extern SYMBOL s_lsp_ASSOC_2F4; 
extern SYMBOL s_lsp_GENSYM_2F1; 
extern SYMBOL s_lsp_LAMBDA; 
extern LP p_pcl_CANONICALIZE_2DSLOT_2DSPECIFICATION();
extern SYMBOL s_lsp_KEYWORDP; 
MAKE_CONS(k1217,LREF(s_lsp_T),LREF(k1210));
extern SYMBOL s_key_NAME; 
extern SYMBOL s_key_INITFORM; 
extern SYMBOL s_lsp_GETF; 
MAKE_SIMPLE_STRING(k1218,51,"Malformed plist in doplist, odd number of elements.");
extern SYMBOL s_key_ACCESSOR; 
extern SYMBOL s_lsp_SETF; 
extern SYMBOL s_key_READER; 
extern SYMBOL s_key_WRITER; 
extern SYMBOL s_key_INITARG; 
MAKE_SIMPLE_STRING(k1219,33,"Odd-length property list in REMF.");
extern SYMBOL s_key_READERS; 
extern SYMBOL s_key_WRITERS; 
extern SYMBOL s_key_INITARGS; 
extern SYMBOL s_lsp_LIST_2A; 
extern SYMBOL s_key_INITFUNCTION; 
extern SYMBOL s_pcl_MAKE_2DINITFUNCTION; 
static struct {unsigned long header; char string[91+1];}
k1220  = {((91 << 8) + TYPE_SIMPLE_STRING), 
"In DEFCLASS ~S, the slot specification ~S is obsolete.~%~\n                 Convert it to ~S"};
MAKE_SIMPLE_STRING(k1221,37,"~S is not a legal slot specification.");
extern LP p_pcl_CANONICALIZE_2DDEFCLASS_2DOPTION();
extern SYMBOL s_key_DEFAULT_2DINITARGS; 
extern SYMBOL s_lsp_NREVERSE; 
extern SYMBOL s_key_DIRECT_2DDEFAULT_2DINITARGS; 
MAKE_CONS(k1223,LREF(s_key_DIRECT_2DDEFAULT_2DINITARGS),LREF(s_lsp_NIL));
MAKE_CONS(k1222,LREF(s_lsp_QUOTE),LREF(k1223));
extern LP p_pcl_MAKE_2DEARLY_2DCLASS_2DDEFINITION();
extern SYMBOL s_pcl_EARLY_2DCLASS_2DDEFINITION; 
extern LP p_pcl_ECD_2DCLASS_2DNAME();
extern SYMBOL s_lsp_NTH; 
extern LP p_pcl_ECD_2DSOURCE();
extern LP p_pcl_ECD_2DMETACLASS();
extern LP p_pcl_ECD_2DSUPERCLASS_2DNAMES();
extern LP p_pcl_ECD_2DCANONICAL_2DSLOTS();
extern LP p_pcl_ECD_2DOTHER_2DINITARGS();
extern LP p_pcl_LOAD_2DDEFCLASS();
extern SYMBOL s_pcl_LOAD_2DTRUENAME; 
extern SYMBOL s_pcl_MAKE_2DEARLY_2DCLASS_2DDEFINITION; 
extern SYMBOL s_pcl__2AEARLY_2DCLASS_2DDEFINITIONS_2A; 
extern SYMBOL s_key_KEY; 
extern SYMBOL s_pcl_ECD_2DCLASS_2DNAME; 
extern SYMBOL s_lsp_FIND; 
extern LP p_pcl_DEFCLASS_5FINIT229();
extern SYMBOL s_lsp_LOAD; 
extern SYMBOL s_lsp_EVAL; 
MAKE_CONS(k1225,LREF(s_lsp_EVAL),LREF(s_lsp_NIL));
MAKE_CONS(k1224,LREF(s_lsp_LOAD),LREF(k1225));
extern SYMBOL s_key_VAR; 
extern SYMBOL s_lsp_DEFINE_2DVARIABLE; 
extern SYMBOL s_pcl__2ADEFMETHOD_2DTIMES_2A; 
extern SYMBOL s_pcl__2ADEFGENERIC_2DTIMES_2A; 
extern SYMBOL s_lsp_DEFINE_2DMACRO; 
extern SYMBOL s_key_PARAMETER; 


extern LP c_eql();
extern LP c_cons();


LP p_pcl_MAKE_2DTOP_2DLEVEL_2DFORM(argc, v_NAME_0, v_TIMES_1, v_FORM_2)
      ARGC argc;  LP v_NAME_0; LP v_TIMES_1; LP v_FORM_2;
{
LP v_Y_18; LP v_X_17; LP v_Y_15; 
LP v_X_14; LP v_Y_12; LP v_X_11; 
LP v_Y_9; LP v_X_8; LP v_Y_6; 
LP v_X_5; LP f_DEFINITION_2DNAME_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; 
if (argc != 3) wna(argc,3);
t0 = NEW_OE(1);
SET_OE_SLOT(t0,0,v_NAME_0);
t1 = MAKE_CLOSURE(p_pcl_MAKE_2DTOP_2DLEVEL_2DFORM_2DDEFINITION_2DNAME1194,t0);
f_DEFINITION_2DNAME_4 = t1;
CODE_PTR(COERCE_TO_FUNCTION(f_DEFINITION_2DNAME_4))(0);
v_X_5 = GET_OE_SLOT(t0,0);
v_Y_6 = LREF(s_lsp_NIL);
v_Y_9 = (c_cons((GET_OE_SLOT(t0,0)), (LREF(s_lsp_NIL))));
t3 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_9)));
v_X_11 = v_FORM_2;
v_Y_12 = LREF(s_lsp_NIL);
v_Y_15 = (c_cons((v_FORM_2), (LREF(s_lsp_NIL))));
v_Y_18 = (c_cons((v_TIMES_1), (v_Y_15)));
t4 = (c_cons((LREF(s_lsp_EVAL_2DWHEN)), (v_Y_18)));
t2 = ICALL(s_pcl_MAKE_2DPROGN) (MV_CALL(argc,2), t3, t4);
return(t2);
}

LP p_pcl_MAKE_2DTOP_2DLEVEL_2DFORM_2DDEFINITION_2DNAME1194(argc)
      ARGC argc; 
{
LP v_X_15; LP v_G1435_14; LP v_Y_12; 
LP v_X_11; LP v_X_9; LP v_X_7; 
LP v_X_5; LP v_X_3; LP v_X_1; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; 
if (argc != 0) wna(argc,0);
t0 = OE;
v_X_7 = GET_OE_SLOT(t0,0);
v_X_9 = v_X_7;
v_X_11 = v_X_7;
v_Y_12 = LREF(s_lsp_NIL);
v_G1435_14 = (((v_X_7) == (LREF(s_lsp_NIL))) ? T : NIL);
if (v_G1435_14 != NIL) {
t3 = v_G1435_14;
} else {
v_X_15 = v_X_7;
t3 = (OTHER_PTRP((v_X_7)) && (TAG((v_X_7)) == 15) ? T : NIL);
}
if (t3 != NIL) {
v_X_5 = GET_OE_SLOT(t0,0);
t4 = ((LP) DEREF((GET_OE_SLOT(t0,0)) + 0 * 4));
t2 = ICALL(s_lsp_MEMQ) (2, t4, LREF(k1195));
} else {
t2 = LREF(s_lsp_NIL);
}
if (t2 != NIL) {
v_X_1 = GET_OE_SLOT(t0,0);
t6 = ((LP) DEREF((GET_OE_SLOT(t0,0)) + 0 * 4));
t5 = ICALL(s_pcl_CAPITALIZE_2DWORDS) (2, t6, LREF(s_lsp_NIL));
v_X_3 = GET_OE_SLOT(t0,0);
t7 = ((LP) DEREF((GET_OE_SLOT(t0,0)) + 1 * 4));
t1 = ICALL(s_lsp_FORMAT) (MV_CALL(argc,4), LREF(s_lsp_NIL), LREF(k1200), t5, t7);
return(t1);
} else {
t1 = ICALL(s_lsp_FORMAT) (MV_CALL(argc,3), LREF(s_lsp_NIL), LREF(k1201), GET_OE_SLOT(t0,0));
return(t1);
}
}

LP p_pcl_MAKE_2DPROGN(va_alist) va_dcl
{
LP v_Y_5; LP v_X_4; LP f_COLLECT_2DFORMS_3; 
LP v_PROGN_2DFORM_2; LP v_FORMS_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


t0 = NEW_OE(2);
real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTIFY(v_FORMS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_PROGN_2DFORM_2 = LREF(s_lsp_NIL);
SET_OE_SLOT(t0,0,v_PROGN_2DFORM_2);
t1 = MAKE_CLOSURE(p_pcl_MAKE_2DPROGN_2DCOLLECT_2DFORMS1202,t0);
f_COLLECT_2DFORMS_3 = t1;
SET_OE_SLOT(t0,1,f_COLLECT_2DFORMS_3);
CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,1)))(1, v_FORMS_0);
v_Y_5 = GET_OE_SLOT(t0,0);
t2 = (c_cons((LREF(s_lsp_PROGN)), (v_Y_5)));
return(t2);
}

LP p_pcl_MAKE_2DPROGN_2DCOLLECT_2DFORMS1202(argc, v_FORMS_0)
      ARGC argc;  LP v_FORMS_0;
{
LP v_Y_41; LP v_X_40; LP v_X_38; 
LP v_X_36; LP v_G1438_35; LP v_Y_33; 
LP v_X_32; LP v_X_30; LP v_X_28; 
LP v_X_26; LP v_Y_24; LP v_X_23; 
LP v_X_21; LP v_X_19; LP v_C_17; 
LP v_S1437_16; LP v_Y_14; LP v_X_13; 
LP v_VALUE1436_12; LP v_X_10; LP v_X_8; 
LP v_X_6; LP v_C_4; LP v_X_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; 
if (argc != 1) wna(argc,1);
t0 = OE;
v_X_38 = v_FORMS_0;
v_X_40 = v_FORMS_0;
v_Y_41 = LREF(s_lsp_NIL);
if (v_FORMS_0 != NIL) {
v_X_2 = v_FORMS_0;
t2 = ((LP) DEREF((v_FORMS_0) + 1 * 4));
CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,1)))(1, t2);
v_X_26 = v_FORMS_0;
v_X_28 = ((LP) DEREF((v_FORMS_0) + 0 * 4));
v_X_30 = v_X_28;
v_X_32 = v_X_28;
v_Y_33 = LREF(s_lsp_NIL);
v_G1438_35 = (((v_X_28) == (LREF(s_lsp_NIL))) ? T : NIL);
if (v_G1438_35 != NIL) {
t4 = v_G1438_35;
} else {
v_X_36 = v_X_28;
t4 = (OTHER_PTRP((v_X_28)) && (TAG((v_X_28)) == 15) ? T : NIL);
}
if (t4 != NIL) {
v_C_17 = v_FORMS_0;
v_X_19 = v_FORMS_0;
v_X_21 = ((LP) DEREF((v_FORMS_0) + 0 * 4));
v_X_23 = ((LP) DEREF((v_X_21) + 0 * 4));
t3 = (((v_X_23) == (LREF(s_lsp_PROGN))) ? T : NIL);
} else {
t3 = LREF(s_lsp_NIL);
}
if (t3 != NIL) {
v_C_4 = v_FORMS_0;
v_X_6 = v_FORMS_0;
v_X_8 = ((LP) DEREF((v_FORMS_0) + 0 * 4));
t5 = ((LP) DEREF((v_X_8) + 1 * 4));
t1 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,1)))(MV_CALL(argc,1), t5);
return(t1);
} else {
v_X_10 = v_FORMS_0;
v_VALUE1436_12 = ((LP) DEREF((v_FORMS_0) + 0 * 4));
v_Y_14 = GET_OE_SLOT(t0,0);
v_S1437_16 = (c_cons((v_VALUE1436_12), (v_Y_14)));
SET_OE_SLOT(t0,0,v_S1437_16);
return(v_S1437_16);
}
} else {
return(LREF(s_lsp_NIL));
}
}

LP m_pcl_DEFCLASS(argc, v_WHOLE1439_0, v_ENV1440_1)
      ARGC argc;  LP v_WHOLE1439_0; LP v_ENV1440_1;
{
LP v_OPTIONS_30; LP v_DIRECT_2DSLOTS_29; LP v_S1460_28; 
LP v_X_26; LP v_VALUE1459_25; LP v_X_23; 
LP v_LIST1458_22; LP v_DIRECT_2DSUPERCLASSES_21; LP v_S1457_20; 
LP v_X_18; LP v_VALUE1456_17; LP v_X_15; 
LP v_LIST1455_14; LP v_NAME_13; LP v_S1454_12; 
LP v_X_10; LP v_VALUE1453_9; LP v_X_7; 
LP v_LIST1452_6; LP v_L1451_5; LP v_X_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE1439_0;
v_L1451_5 = ((LP) DEREF((v_WHOLE1439_0) + 1 * 4));
v_LIST1452_6 = v_L1451_5;
v_X_7 = v_LIST1452_6;
v_VALUE1453_9 = ((LP) DEREF((v_LIST1452_6) + 0 * 4));
v_X_10 = v_LIST1452_6;
v_S1454_12 = ((LP) DEREF((v_LIST1452_6) + 1 * 4));
v_L1451_5 = v_S1454_12;
v_NAME_13 = v_VALUE1453_9;
v_LIST1455_14 = v_L1451_5;
v_X_15 = v_LIST1455_14;
v_VALUE1456_17 = ((LP) DEREF((v_LIST1455_14) + 0 * 4));
v_X_18 = v_LIST1455_14;
v_S1457_20 = ((LP) DEREF((v_LIST1455_14) + 1 * 4));
v_L1451_5 = v_S1457_20;
v_DIRECT_2DSUPERCLASSES_21 = v_VALUE1456_17;
v_LIST1458_22 = v_L1451_5;
v_X_23 = v_LIST1458_22;
v_VALUE1459_25 = ((LP) DEREF((v_LIST1458_22) + 0 * 4));
v_X_26 = v_LIST1458_22;
v_S1460_28 = ((LP) DEREF((v_LIST1458_22) + 1 * 4));
v_L1451_5 = v_S1460_28;
v_DIRECT_2DSLOTS_29 = v_VALUE1459_25;
v_OPTIONS_30 = v_L1451_5;
t0 = ICALL(s_pcl_EXPAND_2DDEFCLASS) (MV_CALL(argc,4), v_NAME_13, v_DIRECT_2DSUPERCLASSES_21, v_DIRECT_2DSLOTS_29, v_OPTIONS_30);
return(t0);
}

LP p_pcl_EXPAND_2DDEFCLASS(argc, v_NAME_0, v_SUPERS_1, v_SLOTS_2, v_OPTIONS_3)
      ARGC argc;  LP v_NAME_0; LP v_SUPERS_1; LP v_SLOTS_2; LP v_OPTIONS_3;
{
LP v_Y_179; LP v_X_178; LP v_Y_176; 
LP v_X_175; LP v_Y_173; LP v_X_172; 
LP v_Y_170; LP v_X_169; LP v_Y_167; 
LP v_X_166; LP v_SYMBOL_164; LP v_Y_162; 
LP v_X_161; LP v_X_159; LP v_Y_157; 
LP v_X_156; LP v_Y_154; LP v_X_153; 
LP v_Y_151; LP v_X_150; LP v_Y_148; 
LP v_X_147; LP v_Y_145; LP v_X_144; 
LP v_Y_142; LP v_X_141; LP v_Y_139; 
LP v_X_138; LP v_X_136; LP v_V_134; 
LP v_X_133; LP v_NEW_2DCDR_131; LP v_C_130; 
LP v_Y_128; LP v_X_127; LP v_X_125; 
LP v_X_123; LP v_X_121; LP v_LOOPVAR_2D228_117; 
LP v_LOOPVAR_2D227_116; LP v_LOOPVAR_2D226_115; LP v_LOOP_2DLIST_2D225_114; 
LP v_L1465_113; LP v_SYMBOL_111; LP v_SYMBOL_109; 
LP v_Y_107; LP v_X_106; LP v_Y_104; 
LP v_X_103; LP v_SYMBOL_101; LP v_OTHER_2DINITARGS_100; 
LP v_CANONICAL_2DSLOTS_99; LP v_X_97; LP v_V_95; 
LP v_X_94; LP v_NEW_2DCDR_92; LP v_C_91; 
LP v_Y_89; LP v_X_88; LP v_OPTION_87; 
LP v_X_85; LP v_X_83; LP v_LOOPVAR_2D224_79; 
LP v_LOOPVAR_2D223_78; LP v_LOOPVAR_2D222_77; LP v_LOOP_2DLIST_2D221_76; 
LP v_L1464_75; LP v_X_73; LP v_V_71; 
LP v_X_70; LP v_NEW_2DCDR_68; LP v_C_67; 
LP v_Y_65; LP v_X_64; LP v_SPEC_63; 
LP v_X_61; LP v_X_59; LP v_LOOPVAR_2D220_55; 
LP v_LOOPVAR_2D219_54; LP v_LOOPVAR_2D218_53; LP v_LOOP_2DLIST_2D217_52; 
LP v_L1463_51; LP v__2AACCESSORS_2A_50; LP v__2AINITFUNCTIONS_2A_49; 
LP v_X_47; LP v_G1462_46; LP v_Y_44; 
LP v_X_43; LP v_X_41; LP v_X_39; 
LP v_Y_37; LP v_X_36; LP v_X_34; 
LP v_S1461_33; LP v_X_31; LP v_X_29; 
LP v_C_27; LP v_X_25; LP v_X_23; 
LP v_C_21; LP v_X_19; LP v_X_17; 
LP v_C_15; LP v_X_13; LP v_X_11; 
LP v_LOOP_2DLIST_2D216_7; LP v_OPTION_6; LP v_METACLASS_5; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; LP t145; LP t146; LP t147; LP t148; LP t149; 
LP t150; LP t151; LP t152; LP t153; LP t154; LP t155; 
LP t156; LP t157; LP t158; LP t159; LP t160; LP t161; 
LP t162; LP t163; LP t164; LP t165; LP t166; LP t167; 
LP t168; LP t169; LP t170; LP t171; LP t172; LP t173; 
LP t174; LP t175; LP t176; 
if (argc != 4) wna(argc,4);
v_SUPERS_1 = ICALL(s_lsp_COPY_2DTREE) (1, v_SUPERS_1);
v_SLOTS_2 = ICALL(s_lsp_COPY_2DTREE) (1, v_SLOTS_2);
v_OPTIONS_3 = ICALL(s_lsp_COPY_2DTREE) (1, v_OPTIONS_3);
v_METACLASS_5 = LREF(s_pcl_STANDARD_2DCLASS);
v_OPTION_6 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D216_7 = v_OPTIONS_3;
t_NEXT_2DLOOP_9:;
if (v_LOOP_2DLIST_2D216_7 == NIL) {
goto t_END_2DLOOP_10;
}
v_X_11 = v_LOOP_2DLIST_2D216_7;
v_OPTION_6 = ((LP) DEREF((v_X_11) + 0 * 4));
v_X_13 = v_LOOP_2DLIST_2D216_7;
v_LOOP_2DLIST_2D216_7 = ((LP) DEREF((v_X_13) + 1 * 4));
v_X_39 = v_OPTION_6;
v_X_41 = v_X_39;
v_X_43 = v_X_39;
v_Y_44 = LREF(s_lsp_NIL);
v_G1462_46 = (((v_X_39) == (LREF(s_lsp_NIL))) ? T : NIL);
if (v_G1462_46 != NIL) {
t0 = v_G1462_46;
} else {
v_X_47 = v_X_39;
t0 = (OTHER_PTRP((v_X_39)) && (TAG((v_X_39)) == 15) ? T : NIL);
}
if (t0 != NIL) {
v_X_34 = v_OPTION_6;
v_X_36 = ((LP) DEREF((v_X_34) + 0 * 4));
if (((v_X_36) == (LREF(s_key_METACLASS)))) {
v_C_21 = v_OPTION_6;
v_X_23 = v_C_21;
v_X_25 = ((LP) DEREF((v_C_21) + 1 * 4));
t3 = ((LP) DEREF((v_X_25) + 0 * 4));
t2 = ICALL(s_pcl_LEGAL_2DCLASS_2DNAME_2DP) (1, t3);
if (t2 == NIL) {
v_C_15 = v_OPTION_6;
v_X_17 = v_C_15;
v_X_19 = ((LP) DEREF((v_C_15) + 1 * 4));
t4 = ((LP) DEREF((v_X_19) + 0 * 4));
ICALL(s_lsp_ERROR) (2, LREF(k1203), t4);
}
v_C_27 = v_OPTION_6;
v_X_29 = v_C_27;
v_X_31 = ((LP) DEREF((v_C_27) + 1 * 4));
v_METACLASS_5 = ((LP) DEREF((v_X_31) + 0 * 4));
v_S1461_33 = ICALL(s_lsp_REMOVE) (2, v_OPTION_6, v_OPTIONS_3);
v_OPTIONS_3 = v_S1461_33;
goto b_NIL_8;
}
} else {
ICALL(s_lsp_ERROR) (2, LREF(k1204), v_OPTION_6);
}
goto t_NEXT_2DLOOP_9;
goto t_END_2DLOOP_10;
t_END_2DLOOP_10:;
goto b_NIL_8;
b_NIL_8:;
v__2AINITFUNCTIONS_2A_49 = LREF(s_lsp_NIL);
v__2AACCESSORS_2A_50 = LREF(s_lsp_NIL);
BEGIN_SPEC_BIND(s_pcl__2AINITFUNCTIONS_2A,LREF(s_lsp_NIL));
BEGIN_SPEC_BIND(s_pcl__2AACCESSORS_2A,LREF(s_lsp_NIL));
v_L1463_51 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D217_52 = v_SLOTS_2;
v_LOOPVAR_2D218_53 = LREF(s_lsp_NIL);
v_LOOPVAR_2D219_54 = LREF(s_lsp_NIL);
v_LOOPVAR_2D220_55 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_57:;
if (v_LOOP_2DLIST_2D217_52 == NIL) {
goto t_END_2DLOOP_58;
}
v_X_59 = v_LOOP_2DLIST_2D217_52;
v_L1463_51 = ((LP) DEREF((v_X_59) + 0 * 4));
v_X_61 = v_LOOP_2DLIST_2D217_52;
v_LOOP_2DLIST_2D217_52 = ((LP) DEREF((v_X_61) + 1 * 4));
v_SPEC_63 = v_L1463_51;
v_X_64 = ICALL(s_pcl_CANONICALIZE_2DSLOT_2DSPECIFICATION) (2, v_NAME_0, v_SPEC_63);
v_LOOPVAR_2D220_55 = (c_cons((v_X_64), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D219_54 != NIL) {
v_C_67 = v_LOOPVAR_2D219_54;
v_NEW_2DCDR_68 = v_LOOPVAR_2D220_55;
v_V_71 = v_NEW_2DCDR_68;
((LP) (DEREF((v_C_67) + 1 * 4) = (LD) (v_V_71)));
v_X_73 = v_C_67;
v_LOOPVAR_2D219_54 = ((LP) DEREF((v_X_73) + 1 * 4));
} else {
v_LOOPVAR_2D218_53 = v_LOOPVAR_2D220_55;
v_LOOPVAR_2D219_54 = v_LOOPVAR_2D218_53;
}
goto t_NEXT_2DLOOP_57;
goto t_END_2DLOOP_58;
t_END_2DLOOP_58:;
v_CANONICAL_2DSLOTS_99 = v_LOOPVAR_2D218_53;
goto b_NIL_56;
v_CANONICAL_2DSLOTS_99 = NIL;
v_CANONICAL_2DSLOTS_99 = v_CANONICAL_2DSLOTS_99;
b_NIL_56:;
v_L1464_75 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D221_76 = v_OPTIONS_3;
v_LOOPVAR_2D222_77 = LREF(s_lsp_NIL);
v_LOOPVAR_2D223_78 = LREF(s_lsp_NIL);
v_LOOPVAR_2D224_79 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_81:;
if (v_LOOP_2DLIST_2D221_76 == NIL) {
goto t_END_2DLOOP_82;
}
v_X_83 = v_LOOP_2DLIST_2D221_76;
v_L1464_75 = ((LP) DEREF((v_X_83) + 0 * 4));
v_X_85 = v_LOOP_2DLIST_2D221_76;
v_LOOP_2DLIST_2D221_76 = ((LP) DEREF((v_X_85) + 1 * 4));
v_OPTION_87 = v_L1464_75;
v_X_88 = ICALL(s_pcl_CANONICALIZE_2DDEFCLASS_2DOPTION) (2, v_NAME_0, v_OPTION_87);
v_LOOPVAR_2D224_79 = (c_cons((v_X_88), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D223_78 != NIL) {
v_C_91 = v_LOOPVAR_2D223_78;
v_NEW_2DCDR_92 = v_LOOPVAR_2D224_79;
v_V_95 = v_NEW_2DCDR_92;
((LP) (DEREF((v_C_91) + 1 * 4) = (LD) (v_V_95)));
v_X_97 = v_C_91;
v_LOOPVAR_2D223_78 = ((LP) DEREF((v_X_97) + 1 * 4));
} else {
v_LOOPVAR_2D222_77 = v_LOOPVAR_2D224_79;
v_LOOPVAR_2D223_78 = v_LOOPVAR_2D222_77;
}
goto t_NEXT_2DLOOP_81;
goto t_END_2DLOOP_82;
t_END_2DLOOP_82:;
v_OTHER_2DINITARGS_100 = v_LOOPVAR_2D222_77;
goto b_NIL_80;
v_OTHER_2DINITARGS_100 = NIL;
v_OTHER_2DINITARGS_100 = v_OTHER_2DINITARGS_100;
b_NIL_80:;
v_SYMBOL_101 = LREF(s_pcl__2AACCESSORS_2A);
t5 = ((LP) DEREF((LREF(s_pcl__2AACCESSORS_2A)) + 0 * 4));
ICALL(s_pcl_DO_2DSTANDARD_2DDEFSETFS_2DFOR_2DDEFCLASS) (1, t5);
v_X_103 = v_NAME_0;
v_Y_104 = LREF(s_lsp_NIL);
v_Y_107 = (c_cons((v_NAME_0), (LREF(s_lsp_NIL))));
t7 = (c_cons((LREF(s_pcl_DEFCLASS)), (v_Y_107)));
v_SYMBOL_109 = LREF(s_pcl__2ADEFCLASS_2DTIMES_2A);
t8 = ((LP) DEREF((LREF(s_pcl__2ADEFCLASS_2DTIMES_2A)) + 0 * 4));
v_L1465_113 = LREF(s_lsp_NIL);
v_SYMBOL_111 = LREF(s_pcl__2AINITFUNCTIONS_2A);
v_LOOP_2DLIST_2D225_114 = ((LP) DEREF((LREF(s_pcl__2AINITFUNCTIONS_2A)) + 0 * 4));
v_LOOPVAR_2D226_115 = LREF(s_lsp_NIL);
v_LOOPVAR_2D227_116 = LREF(s_lsp_NIL);
v_LOOPVAR_2D228_117 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_119:;
if (v_LOOP_2DLIST_2D225_114 == NIL) {
goto t_END_2DLOOP_120;
}
v_X_121 = v_LOOP_2DLIST_2D225_114;
v_L1465_113 = ((LP) DEREF((v_X_121) + 0 * 4));
v_X_123 = v_LOOP_2DLIST_2D225_114;
v_LOOP_2DLIST_2D225_114 = ((LP) DEREF((v_X_123) + 1 * 4));
v_X_125 = v_L1465_113;
v_X_127 = ((LP) DEREF((v_X_125) + 1 * 4));
v_LOOPVAR_2D228_117 = (c_cons((v_X_127), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D227_116 != NIL) {
v_C_130 = v_LOOPVAR_2D227_116;
v_NEW_2DCDR_131 = v_LOOPVAR_2D228_117;
v_V_134 = v_NEW_2DCDR_131;
((LP) (DEREF((v_C_130) + 1 * 4) = (LD) (v_V_134)));
v_X_136 = v_C_130;
v_LOOPVAR_2D227_116 = ((LP) DEREF((v_X_136) + 1 * 4));
} else {
v_LOOPVAR_2D226_115 = v_LOOPVAR_2D228_117;
v_LOOPVAR_2D227_116 = v_LOOPVAR_2D226_115;
}
goto t_NEXT_2DLOOP_119;
goto t_END_2DLOOP_120;
t_END_2DLOOP_120:;
v_X_175 = v_LOOPVAR_2D226_115;
goto b_NIL_118;
v_X_175 = NIL;
v_X_175 = v_X_175;
b_NIL_118:;
v_X_138 = v_NAME_0;
v_Y_139 = LREF(s_lsp_NIL);
v_Y_142 = (c_cons((v_NAME_0), (LREF(s_lsp_NIL))));
t9 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_142)));
v_X_144 = v_METACLASS_5;
v_Y_148 = (c_cons((v_X_144), (LREF(s_lsp_NIL))));
t10 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_148)));
v_X_150 = v_SUPERS_1;
v_Y_154 = (c_cons((v_X_150), (LREF(s_lsp_NIL))));
t11 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_154)));
v_X_156 = LREF(s_lsp_LIST);
v_Y_157 = v_CANONICAL_2DSLOTS_99;
t12 = (c_cons((LREF(s_lsp_LIST)), (v_CANONICAL_2DSLOTS_99)));
v_X_159 = LREF(s_lsp_APPEND);
t13 = ((LP) DEREF((LREF(s_lsp_APPEND)) + 4 * 4));
v_Y_162 = p_lsp_APPLY(2, COERCE_TO_FUNCTION(t13), v_OTHER_2DINITARGS_100);
t14 = (c_cons((LREF(s_lsp_LIST)), (v_Y_162)));
v_SYMBOL_164 = LREF(s_pcl__2AACCESSORS_2A);
v_X_166 = ((LP) DEREF((LREF(s_pcl__2AACCESSORS_2A)) + 0 * 4));
v_Y_170 = (c_cons((v_X_166), (LREF(s_lsp_NIL))));
t15 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_170)));
v_X_172 = ICALL(s_lsp_LIST) (7, LREF(s_pcl_LOAD_2DDEFCLASS), t9, t10, t11, t12, t14, t15);
v_Y_176 = (c_cons((v_X_172), (LREF(s_lsp_NIL))));
v_Y_179 = (c_cons((v_X_175), (v_Y_176)));
t16 = (c_cons((LREF(s_lsp_LET)), (v_Y_179)));
t6 = ICALL(s_pcl_MAKE_2DTOP_2DLEVEL_2DFORM) (MV_CALL(argc,3), t7, t8, t16);
END_SPEC_BIND(s_pcl__2AACCESSORS_2A);
END_SPEC_BIND(s_pcl__2AINITFUNCTIONS_2A);
return(t6);
}

LP p_pcl_MAKE_2DINITFUNCTION(argc, v_INITFORM_0)
      ARGC argc;  LP v_INITFORM_0;
{
LP v_G1470_63; LP v_Y_61; LP v_X_60; 
LP v_G1469_59; LP v_Y_57; LP v_X_56; 
LP v_G1468_55; LP v_Y_53; LP v_X_52; 
LP v_X_50; LP v_X_48; LP v_C_46; 
LP v_V_44; LP v_X_43; LP v_S1467_42; 
LP v_Y_40; LP v_X_39; LP v_SYMBOL_37; 
LP v_VALUE1466_36; LP v_Y_34; LP v_X_33; 
LP v_Y_31; LP v_X_30; LP v_Y_28; 
LP v_X_27; LP v_Y_25; LP v_X_24; 
LP v_Y_22; LP v_X_21; LP v_Y_19; 
LP v_X_18; LP v_Y_16; LP v_X_15; 
LP v_Y_13; LP v_X_12; LP v_X_10; 
LP v_X_9; LP v_ENTRY_8; LP v_X_6; 
LP v_X_4; LP v_SYMBOL_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 

if (argc != 1) wna(argc,1);
v_X_60 = v_INITFORM_0;
v_Y_61 = LREF(s_lsp_T);
v_G1470_63 = (((v_INITFORM_0) == (LREF(s_lsp_T))) ? T : NIL);
if (v_G1470_63 != NIL) {
t1 = v_G1470_63;
} else {
t1 = ICALL(s_lsp_EQUAL) (2, v_INITFORM_0, LREF(k1205));
}
if (t1 != NIL) {
return(LREF(k1207));
} else {
v_X_56 = v_INITFORM_0;
v_Y_57 = LREF(s_lsp_NIL);
v_G1469_59 = (((v_INITFORM_0) == (LREF(s_lsp_NIL))) ? T : NIL);
if (v_G1469_59 != NIL) {
t2 = v_G1469_59;
} else {
t2 = ICALL(s_lsp_EQUAL) (2, v_INITFORM_0, LREF(k1209));
}
if (t2 != NIL) {
return(LREF(k1211));
} else {
v_X_52 = v_INITFORM_0;
v_Y_53 = (LP) 0;
v_G1468_55 = (((int) (v_INITFORM_0) == (int) ((LP) 0)) ? T : NIL);
if (v_G1468_55 != NIL) {
t3 = v_G1468_55;
} else {
t3 = ICALL(s_lsp_EQUAL) (2, v_INITFORM_0, LREF(k1213));
}
if (t3 != NIL) {
return(LREF(k1215));
} else {
v_SYMBOL_2 = LREF(s_pcl__2AINITFUNCTIONS_2A);
t4 = ((LP) DEREF((LREF(s_pcl__2AINITFUNCTIONS_2A)) + 0 * 4));
v_X_4 = LREF(s_lsp_EQUAL);
t5 = ((LP) DEREF((LREF(s_lsp_EQUAL)) + 4 * 4));
v_X_6 = LREF(s_lsp_IDENTITY);
t6 = ((LP) DEREF((LREF(s_lsp_IDENTITY)) + 4 * 4));
v_ENTRY_8 = ICALL(s_lsp_ASSOC_2F4) (4, v_INITFORM_0, t4, t5, t6);
if (v_ENTRY_8 == NIL) {
v_X_10 = LREF(s_lsp_NIL);
v_X_30 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(s_lsp_NIL));
v_X_12 = v_INITFORM_0;
v_Y_13 = LREF(s_lsp_NIL);
v_Y_16 = (c_cons((v_INITFORM_0), (LREF(s_lsp_NIL))));
v_Y_19 = (c_cons((LREF(s_lsp_NIL)), (v_Y_16)));
v_X_21 = (c_cons((LREF(s_lsp_LAMBDA)), (v_Y_19)));
v_Y_25 = (c_cons((v_X_21), (LREF(s_lsp_NIL))));
v_X_27 = (c_cons((LREF(s_lsp_FUNCTION)), (v_Y_25)));
v_Y_31 = (c_cons((v_X_27), (LREF(s_lsp_NIL))));
v_Y_34 = (c_cons((v_X_30), (v_Y_31)));
v_ENTRY_8 = (c_cons((v_INITFORM_0), (v_Y_34)));
v_VALUE1466_36 = v_ENTRY_8;
v_SYMBOL_37 = LREF(s_pcl__2AINITFUNCTIONS_2A);
v_Y_40 = ((LP) DEREF((LREF(s_pcl__2AINITFUNCTIONS_2A)) + 0 * 4));
v_S1467_42 = (c_cons((v_VALUE1466_36), (v_Y_40)));
v_V_44 = v_S1467_42;
((LP) (DEREF((LREF(s_pcl__2AINITFUNCTIONS_2A)) + 0 * 4) = (LD) (v_V_44)));
}
v_C_46 = v_ENTRY_8;
v_X_48 = v_C_46;
v_X_50 = ((LP) DEREF((v_C_46) + 1 * 4));
t0 = ((LP) DEREF((v_X_50) + 0 * 4));
return(t0);
}
}
}
}

LP p_pcl_CANONICALIZE_2DSLOT_2DSPECIFICATION(argc, v_CLASS_2DNAME_0, v_SPEC_1)
      ARGC argc;  LP v_CLASS_2DNAME_0; LP v_SPEC_1;
{
LP v_S_439; LP v_Y_437; LP v_X_436; 
LP v_X_434; LP v_X_432; LP v_X_430; 
LP v_X_428; LP v_X_426; LP v_C_424; 
LP v_Y_422; LP v_X_421; LP v_Y_419; 
LP v_X_418; LP v_Y_416; LP v_X_415; 
LP v_Y_413; LP v_X_412; LP v_Y_410; 
LP v_X_409; LP v_Y_407; LP v_X_406; 
LP v_Y_404; LP v_X_403; LP v_Y_401; 
LP v_X_400; LP v_Y_398; LP v_X_397; 
LP v_Y_395; LP v_X_394; LP v_Y_392; 
LP v_X_391; LP v_Y_389; LP v_X_388; 
LP v_Y_386; LP v_X_385; LP v_X_383; 
LP v_X_381; LP v_X_379; LP v_X_377; 
LP v_Y_375; LP v_X_374; LP v_X_372; 
LP v_X_370; LP v_X_368; LP v_C_366; 
LP v_V_364; LP v_X_363; LP v_NEW_2DCDR_361; 
LP v_C_360; LP v_X_358; LP v_X_356; 
LP v_C_354; LP v_X_352; LP v_Y_350; 
LP v_X_349; LP v_X_347; LP v_X_345; 
LP v_X_343; LP v_TMP1525_342; LP v_TMP1524_341; 
LP v_X_339; LP v_X_337; LP v_C_335; 
LP v_S1521_332; LP v_S1520_331; LP v_S1519_329; 
LP v_S1518_328; LP v_Y_323; LP v_X_322; 
LP v_X_320; LP v_X_318; LP v_X_316; 
LP v_X_314; LP v_Y_312; LP v_X_311; 
LP v_X_309; LP v_X_307; LP v_X_305; 
LP v_C_303; LP v_V_301; LP v_X_300; 
LP v_NEW_2DCDR_298; LP v_C_297; LP v_X_295; 
LP v_X_293; LP v_C_291; LP v_X_289; 
LP v_Y_287; LP v_X_286; LP v_X_284; 
LP v_X_282; LP v_X_280; LP v_TMP1517_279; 
LP v_TMP1516_278; LP v_X_276; LP v_X_274; 
LP v_C_272; LP v_S1513_269; LP v_S1512_268; 
LP v_S1511_266; LP v_S1510_265; LP v_Y_260; 
LP v_X_259; LP v_X_257; LP v_X_255; 
LP v_X_253; LP v_X_251; LP v_Y_249; 
LP v_X_248; LP v_X_246; LP v_X_244; 
LP v_X_242; LP v_C_240; LP v_V_238; 
LP v_X_237; LP v_NEW_2DCDR_235; LP v_C_234; 
LP v_X_232; LP v_X_230; LP v_C_228; 
LP v_X_226; LP v_Y_224; LP v_X_223; 
LP v_X_221; LP v_X_219; LP v_X_217; 
LP v_TMP1509_216; LP v_TMP1508_215; LP v_X_213; 
LP v_X_211; LP v_C_209; LP v_S1505_206; 
LP v_S1504_205; LP v_S1503_203; LP v_S1502_202; 
LP v_Y_197; LP v_X_196; LP v_X_194; 
LP v_X_192; LP v_X_190; LP v_X_188; 
LP v_Y_186; LP v_X_185; LP v_X_183; 
LP v_X_181; LP v_X_179; LP v_C_177; 
LP v_V_175; LP v_X_174; LP v_NEW_2DCDR_172; 
LP v_C_171; LP v_X_169; LP v_X_167; 
LP v_C_165; LP v_X_163; LP v_Y_161; 
LP v_X_160; LP v_X_158; LP v_X_156; 
LP v_X_154; LP v_TMP1501_153; LP v_TMP1500_152; 
LP v_X_150; LP v_X_148; LP v_C_146; 
LP v_S1497_143; LP v_S1496_142; LP v_S1495_140; 
LP v_S1494_139; LP v_Y_134; LP v_X_133; 
LP v_Y_131; LP v_X_130; LP v_Y_128; 
LP v_X_127; LP v_Y_125; LP v_X_124; 
LP v_S1493_123; LP v_Y_121; LP v_X_120; 
LP v_VALUE1492_119; LP v_S1491_118; LP v_Y_116; 
LP v_X_115; LP v_VALUE1490_114; LP v_S1489_113; 
LP v_Y_111; LP v_X_110; LP v_VALUE1488_109; 
LP v_S1487_108; LP v_Y_106; LP v_X_105; 
LP v_VALUE1486_104; LP v_Y_102; LP v_X_101; 
LP v_Y_99; LP v_X_98; LP v_S1485_97; 
LP v_Y_95; LP v_X_94; LP v_VALUE1484_93; 
LP v_V_91; LP v_X_90; LP v_S1483_89; 
LP v_Y_87; LP v_X_86; LP v_SYMBOL_84; 
LP v_VALUE1482_83; LP v_KEY1481_82; LP v_S1480_81; 
LP v_X_79; LP v_VALUE1479_78; LP v_X_76; 
LP v_LIST1478_75; LP v_S1477_74; LP v_X_72; 
LP v_VALUE1476_71; LP v_X_69; LP v_LIST1475_68; 
LP v_VAL_64; LP v_KEY_63; LP v__2EPLIST_2DTAIL_2E_62; 
LP v_INITFORM_61; LP v_UNSUPPLIED_60; LP v_Y_58; 
LP v_X_57; LP v_INITARGS_56; LP v_WRITERS_55; 
LP v_READERS_54; LP v_NAME_53; LP v_S1473_52; 
LP v_X_50; LP v_VALUE1472_49; LP v_X_47; 
LP v_LIST1471_46; LP v_Y_44; LP v_X_43; 
LP v_Y_41; LP v_X_40; LP v_Y_38; 
LP v_X_37; LP v_X_35; LP v_X_33; 
LP v_C_31; LP v_X_29; LP v_Y_27; 
LP v_X_26; LP v_Y_24; LP v_X_23; 
LP v_Y_21; LP v_X_20; LP v_Y_18; 
LP v_X_17; LP v_X_15; LP v_Y_13; 
LP v_X_12; LP v_Y_10; LP v_X_9; 
LP v_Y_7; LP v_X_6; LP v_Y_4; 
LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; LP t145; LP t146; LP t147; LP t148; LP t149; 
LP t150; LP t151; LP t152; LP t153; LP t154; LP t155; 
LP t156; LP t157; LP t158; LP t159; LP t160; LP t161; 
LP t162; LP t163; LP t164; LP t165; LP t166; LP t167; 
LP t168; LP t169; LP t170; LP t171; LP t172; LP t173; 
LP t174; LP t175; LP t176; LP t177; LP t178; LP t179; 
LP t180; LP t181; LP t182; LP t183; LP t184; LP t185; 
LP t186; LP t187; LP t188; LP t189; LP t190; LP t191; 
LP t192; LP t193; LP t194; LP t195; LP t196; LP t197; 
LP t198; LP t199; LP t200; LP t201; LP t202; LP t203; 
LP t204; LP t205; LP t206; LP t207; LP t208; LP t209; 
LP t210; LP t211; LP t212; LP t213; LP t214; LP t215; 
LP t216; LP t217; LP t218; LP t219; LP t220; LP t221; 
LP t222; LP t223; LP t224; LP t225; LP t226; LP t227; 
LP t228; LP t229; LP t230; LP t231; LP t232; LP t233; 
LP t234; LP t235; LP t236; LP t237; LP t238; LP t239; 
LP t240; LP t241; LP t242; LP t243; LP t244; LP t245; 
LP t246; LP t247; LP t248; LP t249; LP t250; LP t251; 
LP t252; LP t253; LP t254; LP t255; LP t256; LP t257; 
LP t258; LP t259; LP t260; LP t261; LP t262; LP t263; 
LP t264; LP t265; LP t266; LP t267; LP t268; LP t269; 
LP t270; LP t271; LP t272; LP t273; LP t274; LP t275; 
LP t276; LP t277; LP t278; LP t279; LP t280; LP t281; 
LP t282; LP t283; LP t284; LP t285; LP t286; LP t287; 
LP t288; LP t289; LP t290; LP t291; LP t292; LP t293; 
LP t294; LP t295; LP t296; LP t297; LP t298; LP t299; 
LP t300; LP t301; LP t302; LP t303; LP t304; LP t305; 
LP t306; LP t307; LP t308; LP t309; LP t310; LP t311; 
LP t312; LP t313; LP t314; LP t315; LP t316; LP t317; 
LP t318; LP t319; LP t320; LP t321; LP t322; LP t323; 
LP t324; LP t325; LP t326; LP t327; LP t328; LP t329; 
LP t330; LP t331; LP t332; LP t333; LP t334; LP t335; 
LP t336; LP t337; LP t338; LP t339; LP t340; LP t341; 
LP t342; LP t343; LP t344; LP t345; LP t346; LP t347; 
LP t348; LP t349; LP t350; LP t351; LP t352; LP t353; 
LP t354; LP t355; LP t356; LP t357; LP t358; LP t359; 
LP t360; LP t361; LP t362; LP t363; LP t364; LP t365; 
LP t366; LP t367; LP t368; LP t369; LP t370; LP t371; 
LP t372; LP t373; LP t374; LP t375; LP t376; LP t377; 
LP t378; LP t379; LP t380; LP t381; LP t382; LP t383; 
LP t384; LP t385; LP t386; LP t387; LP t388; LP t389; 
LP t390; LP t391; LP t392; LP t393; LP t394; LP t395; 
LP t396; LP t397; LP t398; LP t399; LP t400; LP t401; 
LP t402; LP t403; LP t404; LP t405; LP t406; LP t407; 
LP t408; LP t409; LP t410; LP t411; LP t412; LP t413; 
LP t414; LP t415; LP t416; 
if (argc != 2) wna(argc,2);
v_S_439 = v_SPEC_1;
if (OTHER_PTRP((v_S_439)) && (TAG((v_S_439)) == 3)) {
t3 = ICALL(s_lsp_KEYWORDP) (1, v_SPEC_1);
if (t3 != NIL) {
t1 = LREF(s_lsp_NIL);
} else {
v_X_434 = ICALL(s_lsp_MEMQ) (2, v_SPEC_1, LREF(k1217));
v_X_436 = v_X_434;
v_Y_437 = LREF(s_lsp_NIL);
t1 = (((v_X_434) == (LREF(s_lsp_NIL))) ? T : NIL);
}
} else {
t1 = LREF(s_lsp_NIL);
}
if (t1 != NIL) {
v_X_3 = v_SPEC_1;
v_Y_7 = (c_cons((v_X_3), (LREF(s_lsp_NIL))));
v_X_9 = (c_cons((LREF(s_key_NAME)), (v_Y_7)));
v_Y_13 = (c_cons((v_X_9), (LREF(s_lsp_NIL))));
t0 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_13)));
return(t0);
} else {
v_X_432 = v_SPEC_1;
if (OTHER_PTRP((v_X_432)) && (TAG((v_X_432)) == 15)) {
v_X_430 = v_SPEC_1;
t5 = ((LP) DEREF((v_X_430) + 1 * 4));
if (t5 != NIL) {
v_C_424 = v_SPEC_1;
v_X_426 = v_C_424;
v_X_428 = ((LP) DEREF((v_C_424) + 1 * 4));
t6 = ((LP) DEREF((v_X_428) + 1 * 4));
if (t6 != NIL) {
v_LIST1471_46 = v_SPEC_1;
v_X_47 = v_LIST1471_46;
v_VALUE1472_49 = ((LP) DEREF((v_LIST1471_46) + 0 * 4));
v_X_50 = v_LIST1471_46;
v_S1473_52 = ((LP) DEREF((v_LIST1471_46) + 1 * 4));
v_SPEC_1 = v_S1473_52;
v_NAME_53 = v_VALUE1472_49;
v_READERS_54 = LREF(s_lsp_NIL);
v_WRITERS_55 = LREF(s_lsp_NIL);
v_INITARGS_56 = LREF(s_lsp_NIL);
v_X_57 = LREF(s_lsp_NIL);
v_Y_58 = LREF(s_lsp_NIL);
v_UNSUPPLIED_60 = (c_cons((LREF(s_lsp_NIL)), (LREF(s_lsp_NIL))));
v_INITFORM_61 = ICALL(s_lsp_GETF) (3, v_SPEC_1, LREF(s_key_INITFORM), v_UNSUPPLIED_60);
v__2EPLIST_2DTAIL_2E_62 = v_SPEC_1;
v_KEY_63 = LREF(s_lsp_NIL);
v_VAL_64 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_66:;
if (v__2EPLIST_2DTAIL_2E_62 == NIL) {
goto b_NIL_65;
}
v_LIST1475_68 = v__2EPLIST_2DTAIL_2E_62;
v_X_69 = v_LIST1475_68;
v_VALUE1476_71 = ((LP) DEREF((v_LIST1475_68) + 0 * 4));
v_X_72 = v_LIST1475_68;
v_S1477_74 = ((LP) DEREF((v_LIST1475_68) + 1 * 4));
v__2EPLIST_2DTAIL_2E_62 = v_S1477_74;
v_KEY_63 = v_VALUE1476_71;
if (v__2EPLIST_2DTAIL_2E_62 == NIL) {
ICALL(s_lsp_ERROR) (1, LREF(k1218));
}
v_LIST1478_75 = v__2EPLIST_2DTAIL_2E_62;
v_X_76 = v_LIST1478_75;
v_VALUE1479_78 = ((LP) DEREF((v_LIST1478_75) + 0 * 4));
v_X_79 = v_LIST1478_75;
v_S1480_81 = ((LP) DEREF((v_LIST1478_75) + 1 * 4));
v__2EPLIST_2DTAIL_2E_62 = v_S1480_81;
v_VAL_64 = v_VALUE1479_78;
v_KEY1481_82 = v_KEY_63;
v_X_133 = v_KEY1481_82;
v_Y_134 = LREF(s_key_ACCESSOR);
t7 = (c_eql((v_KEY1481_82), (LREF(s_key_ACCESSOR))));
if (t7 != NIL) {
v_VALUE1482_83 = v_VAL_64;
v_SYMBOL_84 = LREF(s_pcl__2AACCESSORS_2A);
v_Y_87 = ((LP) DEREF((LREF(s_pcl__2AACCESSORS_2A)) + 0 * 4));
v_S1483_89 = (c_cons((v_VALUE1482_83), (v_Y_87)));
v_V_91 = v_S1483_89;
((LP) (DEREF((LREF(s_pcl__2AACCESSORS_2A)) + 0 * 4) = (LD) (v_V_91)));
v_VALUE1484_93 = v_VAL_64;
v_Y_95 = v_READERS_54;
v_S1485_97 = (c_cons((v_VALUE1484_93), (v_Y_95)));
v_READERS_54 = v_S1485_97;
v_X_98 = v_VAL_64;
v_Y_102 = (c_cons((v_X_98), (LREF(s_lsp_NIL))));
v_VALUE1486_104 = (c_cons((LREF(s_lsp_SETF)), (v_Y_102)));
v_Y_106 = v_WRITERS_55;
v_S1487_108 = (c_cons((v_VALUE1486_104), (v_Y_106)));
v_WRITERS_55 = v_S1487_108;
} else {
v_X_130 = v_KEY1481_82;
v_Y_131 = LREF(s_key_READER);
t8 = (c_eql((v_KEY1481_82), (LREF(s_key_READER))));
if (t8 != NIL) {
v_VALUE1488_109 = v_VAL_64;
v_Y_111 = v_READERS_54;
v_S1489_113 = (c_cons((v_VALUE1488_109), (v_Y_111)));
v_READERS_54 = v_S1489_113;
} else {
v_X_127 = v_KEY1481_82;
v_Y_128 = LREF(s_key_WRITER);
t9 = (c_eql((v_KEY1481_82), (LREF(s_key_WRITER))));
if (t9 != NIL) {
v_VALUE1490_114 = v_VAL_64;
v_Y_116 = v_WRITERS_55;
v_S1491_118 = (c_cons((v_VALUE1490_114), (v_Y_116)));
v_WRITERS_55 = v_S1491_118;
} else {
v_X_124 = v_KEY1481_82;
v_Y_125 = LREF(s_key_INITARG);
t10 = (c_eql((v_KEY1481_82), (LREF(s_key_INITARG))));
if (t10 != NIL) {
v_VALUE1492_119 = v_VAL_64;
v_Y_121 = v_INITARGS_56;
v_S1493_123 = (c_cons((v_VALUE1492_119), (v_Y_121)));
v_INITARGS_56 = v_S1493_123;
} else {
}
}
}
}
goto t_NEXT_2DLOOP_66;
goto t_END_2DLOOP_67;
t_END_2DLOOP_67:;
b_NIL_65:;
t_NEXT_2DLOOP_137:;
v_S1494_139 = v_SPEC_1;
v_S1495_140 = LREF(s_key_ACCESSOR);
v_S1496_142 = v_S1494_139;
v_S1497_143 = LREF(s_lsp_NIL);
goto t_TEST1498_145;
t_LOOP1499_144:;
v_C_146 = v_S1496_142;
v_X_148 = v_C_146;
v_X_150 = ((LP) DEREF((v_C_146) + 1 * 4));
v_TMP1500_152 = ((LP) DEREF((v_X_150) + 1 * 4));
v_TMP1501_153 = v_S1496_142;
v_S1496_142 = v_TMP1500_152;
v_S1497_143 = v_TMP1501_153;
t_TEST1498_145:;
v_X_154 = v_S1496_142;
v_X_156 = v_X_154;
v_X_158 = (OTHER_PTRP((v_X_154)) && (TAG((v_X_154)) == 15) ? T : NIL);
v_X_160 = v_X_158;
v_Y_161 = LREF(s_lsp_NIL);
if (v_X_158 == NIL) {
t11 = LREF(s_lsp_NIL);
goto b_NIL_141;
}
v_X_188 = v_S1496_142;
v_X_190 = ((LP) DEREF((v_X_188) + 1 * 4));
v_X_192 = v_X_190;
v_X_194 = (OTHER_PTRP((v_X_190)) && (TAG((v_X_190)) == 15) ? T : NIL);
v_X_196 = v_X_194;
v_Y_197 = LREF(s_lsp_NIL);
if (v_X_194 != NIL) {
v_X_183 = v_S1496_142;
v_X_185 = ((LP) DEREF((v_X_183) + 0 * 4));
if (((v_X_185) == (LREF(s_key_ACCESSOR)))) {
if (v_S1497_143 != NIL) {
v_X_163 = v_S1497_143;
v_C_171 = ((LP) DEREF((v_X_163) + 1 * 4));
v_C_165 = v_S1496_142;
v_X_167 = v_C_165;
v_X_169 = ((LP) DEREF((v_C_165) + 1 * 4));
v_NEW_2DCDR_172 = ((LP) DEREF((v_X_169) + 1 * 4));
v_V_175 = v_NEW_2DCDR_172;
((LP) (DEREF((v_C_171) + 1 * 4) = (LD) (v_V_175)));
t11 = LREF(s_lsp_T);
goto b_NIL_141;
} else {
v_C_177 = v_S1494_139;
v_X_179 = v_C_177;
v_X_181 = ((LP) DEREF((v_C_177) + 1 * 4));
v_S1494_139 = ((LP) DEREF((v_X_181) + 1 * 4));
v_SPEC_1 = v_S1494_139;
t11 = LREF(s_lsp_T);
goto b_NIL_141;
}
}
} else {
ICALL(s_lsp_ERROR) (1, LREF(k1219));
}
goto t_LOOP1499_144;
t11 = NIL;
b_NIL_141:;
if (t11 == NIL) {
goto b_NIL_136;
}
goto t_NEXT_2DLOOP_137;
goto t_END_2DLOOP_138;
t_END_2DLOOP_138:;
b_NIL_136:;
t_NEXT_2DLOOP_200:;
v_S1502_202 = v_SPEC_1;
v_S1503_203 = LREF(s_key_READER);
v_S1504_205 = v_S1502_202;
v_S1505_206 = LREF(s_lsp_NIL);
goto t_TEST1506_208;
t_LOOP1507_207:;
v_C_209 = v_S1504_205;
v_X_211 = v_C_209;
v_X_213 = ((LP) DEREF((v_C_209) + 1 * 4));
v_TMP1508_215 = ((LP) DEREF((v_X_213) + 1 * 4));
v_TMP1509_216 = v_S1504_205;
v_S1504_205 = v_TMP1508_215;
v_S1505_206 = v_TMP1509_216;
t_TEST1506_208:;
v_X_217 = v_S1504_205;
v_X_219 = v_X_217;
v_X_221 = (OTHER_PTRP((v_X_217)) && (TAG((v_X_217)) == 15) ? T : NIL);
v_X_223 = v_X_221;
v_Y_224 = LREF(s_lsp_NIL);
if (v_X_221 == NIL) {
t13 = LREF(s_lsp_NIL);
goto b_NIL_204;
}
v_X_251 = v_S1504_205;
v_X_253 = ((LP) DEREF((v_X_251) + 1 * 4));
v_X_255 = v_X_253;
v_X_257 = (OTHER_PTRP((v_X_253)) && (TAG((v_X_253)) == 15) ? T : NIL);
v_X_259 = v_X_257;
v_Y_260 = LREF(s_lsp_NIL);
if (v_X_257 != NIL) {
v_X_246 = v_S1504_205;
v_X_248 = ((LP) DEREF((v_X_246) + 0 * 4));
if (((v_X_248) == (LREF(s_key_READER)))) {
if (v_S1505_206 != NIL) {
v_X_226 = v_S1505_206;
v_C_234 = ((LP) DEREF((v_X_226) + 1 * 4));
v_C_228 = v_S1504_205;
v_X_230 = v_C_228;
v_X_232 = ((LP) DEREF((v_C_228) + 1 * 4));
v_NEW_2DCDR_235 = ((LP) DEREF((v_X_232) + 1 * 4));
v_V_238 = v_NEW_2DCDR_235;
((LP) (DEREF((v_C_234) + 1 * 4) = (LD) (v_V_238)));
t13 = LREF(s_lsp_T);
goto b_NIL_204;
} else {
v_C_240 = v_S1502_202;
v_X_242 = v_C_240;
v_X_244 = ((LP) DEREF((v_C_240) + 1 * 4));
v_S1502_202 = ((LP) DEREF((v_X_244) + 1 * 4));
v_SPEC_1 = v_S1502_202;
t13 = LREF(s_lsp_T);
goto b_NIL_204;
}
}
} else {
ICALL(s_lsp_ERROR) (1, LREF(k1219));
}
goto t_LOOP1507_207;
t13 = NIL;
b_NIL_204:;
if (t13 == NIL) {
goto b_NIL_199;
}
goto t_NEXT_2DLOOP_200;
goto t_END_2DLOOP_201;
t_END_2DLOOP_201:;
b_NIL_199:;
t_NEXT_2DLOOP_263:;
v_S1510_265 = v_SPEC_1;
v_S1511_266 = LREF(s_key_WRITER);
v_S1512_268 = v_S1510_265;
v_S1513_269 = LREF(s_lsp_NIL);
goto t_TEST1514_271;
t_LOOP1515_270:;
v_C_272 = v_S1512_268;
v_X_274 = v_C_272;
v_X_276 = ((LP) DEREF((v_C_272) + 1 * 4));
v_TMP1516_278 = ((LP) DEREF((v_X_276) + 1 * 4));
v_TMP1517_279 = v_S1512_268;
v_S1512_268 = v_TMP1516_278;
v_S1513_269 = v_TMP1517_279;
t_TEST1514_271:;
v_X_280 = v_S1512_268;
v_X_282 = v_X_280;
v_X_284 = (OTHER_PTRP((v_X_280)) && (TAG((v_X_280)) == 15) ? T : NIL);
v_X_286 = v_X_284;
v_Y_287 = LREF(s_lsp_NIL);
if (v_X_284 == NIL) {
t15 = LREF(s_lsp_NIL);
goto b_NIL_267;
}
v_X_314 = v_S1512_268;
v_X_316 = ((LP) DEREF((v_X_314) + 1 * 4));
v_X_318 = v_X_316;
v_X_320 = (OTHER_PTRP((v_X_316)) && (TAG((v_X_316)) == 15) ? T : NIL);
v_X_322 = v_X_320;
v_Y_323 = LREF(s_lsp_NIL);
if (v_X_320 != NIL) {
v_X_309 = v_S1512_268;
v_X_311 = ((LP) DEREF((v_X_309) + 0 * 4));
if (((v_X_311) == (LREF(s_key_WRITER)))) {
if (v_S1513_269 != NIL) {
v_X_289 = v_S1513_269;
v_C_297 = ((LP) DEREF((v_X_289) + 1 * 4));
v_C_291 = v_S1512_268;
v_X_293 = v_C_291;
v_X_295 = ((LP) DEREF((v_C_291) + 1 * 4));
v_NEW_2DCDR_298 = ((LP) DEREF((v_X_295) + 1 * 4));
v_V_301 = v_NEW_2DCDR_298;
((LP) (DEREF((v_C_297) + 1 * 4) = (LD) (v_V_301)));
t15 = LREF(s_lsp_T);
goto b_NIL_267;
} else {
v_C_303 = v_S1510_265;
v_X_305 = v_C_303;
v_X_307 = ((LP) DEREF((v_C_303) + 1 * 4));
v_S1510_265 = ((LP) DEREF((v_X_307) + 1 * 4));
v_SPEC_1 = v_S1510_265;
t15 = LREF(s_lsp_T);
goto b_NIL_267;
}
}
} else {
ICALL(s_lsp_ERROR) (1, LREF(k1219));
}
goto t_LOOP1515_270;
t15 = NIL;
b_NIL_267:;
if (t15 == NIL) {
goto b_NIL_262;
}
goto t_NEXT_2DLOOP_263;
goto t_END_2DLOOP_264;
t_END_2DLOOP_264:;
b_NIL_262:;
t_NEXT_2DLOOP_326:;
v_S1518_328 = v_SPEC_1;
v_S1519_329 = LREF(s_key_INITARG);
v_S1520_331 = v_S1518_328;
v_S1521_332 = LREF(s_lsp_NIL);
goto t_TEST1522_334;
t_LOOP1523_333:;
v_C_335 = v_S1520_331;
v_X_337 = v_C_335;
v_X_339 = ((LP) DEREF((v_C_335) + 1 * 4));
v_TMP1524_341 = ((LP) DEREF((v_X_339) + 1 * 4));
v_TMP1525_342 = v_S1520_331;
v_S1520_331 = v_TMP1524_341;
v_S1521_332 = v_TMP1525_342;
t_TEST1522_334:;
v_X_343 = v_S1520_331;
v_X_345 = v_X_343;
v_X_347 = (OTHER_PTRP((v_X_343)) && (TAG((v_X_343)) == 15) ? T : NIL);
v_X_349 = v_X_347;
v_Y_350 = LREF(s_lsp_NIL);
if (v_X_347 == NIL) {
t17 = LREF(s_lsp_NIL);
goto b_NIL_330;
}
v_X_377 = v_S1520_331;
v_X_379 = ((LP) DEREF((v_X_377) + 1 * 4));
v_X_381 = v_X_379;
v_X_383 = (OTHER_PTRP((v_X_379)) && (TAG((v_X_379)) == 15) ? T : NIL);
v_X_385 = v_X_383;
v_Y_386 = LREF(s_lsp_NIL);
if (v_X_383 != NIL) {
v_X_372 = v_S1520_331;
v_X_374 = ((LP) DEREF((v_X_372) + 0 * 4));
if (((v_X_374) == (LREF(s_key_INITARG)))) {
if (v_S1521_332 != NIL) {
v_X_352 = v_S1521_332;
v_C_360 = ((LP) DEREF((v_X_352) + 1 * 4));
v_C_354 = v_S1520_331;
v_X_356 = v_C_354;
v_X_358 = ((LP) DEREF((v_C_354) + 1 * 4));
v_NEW_2DCDR_361 = ((LP) DEREF((v_X_358) + 1 * 4));
v_V_364 = v_NEW_2DCDR_361;
((LP) (DEREF((v_C_360) + 1 * 4) = (LD) (v_V_364)));
t17 = LREF(s_lsp_T);
goto b_NIL_330;
} else {
v_C_366 = v_S1518_328;
v_X_368 = v_C_366;
v_X_370 = ((LP) DEREF((v_C_366) + 1 * 4));
v_S1518_328 = ((LP) DEREF((v_X_370) + 1 * 4));
v_SPEC_1 = v_S1518_328;
t17 = LREF(s_lsp_T);
goto b_NIL_330;
}
}
} else {
ICALL(s_lsp_ERROR) (1, LREF(k1219));
}
goto t_LOOP1523_333;
t17 = NIL;
b_NIL_330:;
if (t17 == NIL) {
goto b_NIL_325;
}
goto t_NEXT_2DLOOP_326;
goto t_END_2DLOOP_327;
t_END_2DLOOP_327:;
b_NIL_325:;
v_X_388 = v_NAME_53;
v_Y_389 = LREF(s_lsp_NIL);
v_Y_392 = (c_cons((v_NAME_53), (LREF(s_lsp_NIL))));
t19 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_392)));
v_X_394 = v_READERS_54;
v_Y_398 = (c_cons((v_X_394), (LREF(s_lsp_NIL))));
t20 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_398)));
v_X_400 = v_WRITERS_55;
v_Y_404 = (c_cons((v_X_400), (LREF(s_lsp_NIL))));
t21 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_404)));
v_X_406 = v_INITARGS_56;
v_Y_410 = (c_cons((v_X_406), (LREF(s_lsp_NIL))));
t22 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_410)));
v_X_412 = v_SPEC_1;
v_Y_416 = (c_cons((v_X_412), (LREF(s_lsp_NIL))));
t23 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_416)));
v_SPEC_1 = ICALL(s_lsp_LIST) (9, LREF(s_key_NAME), t19, LREF(s_key_READERS), t20, LREF(s_key_WRITERS), t21, LREF(s_key_INITARGS), t22, t23);
v_X_421 = v_INITFORM_61;
v_Y_422 = v_UNSUPPLIED_60;
if (((v_INITFORM_61) == (v_UNSUPPLIED_60))) {
v_Y_419 = v_SPEC_1;
t0 = (c_cons((LREF(s_lsp_LIST_2A)), (v_Y_419)));
return(t0);
} else {
t25 = ICALL(s_pcl_MAKE_2DINITFUNCTION) (1, v_INITFORM_61);
t0 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,4), LREF(s_lsp_LIST_2A), LREF(s_key_INITFUNCTION), t25, v_SPEC_1);
return(t0);
}
} else {
v_X_29 = v_SPEC_1;
v_X_43 = ((LP) DEREF((v_X_29) + 0 * 4));
v_C_31 = v_SPEC_1;
v_X_33 = v_C_31;
v_X_35 = ((LP) DEREF((v_C_31) + 1 * 4));
v_X_37 = ((LP) DEREF((v_X_35) + 0 * 4));
v_Y_41 = (c_cons((v_X_37), (LREF(s_lsp_NIL))));
v_Y_44 = (c_cons((LREF(s_key_INITFORM)), (v_Y_41)));
t26 = (c_cons((v_X_43), (v_Y_44)));
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,4), LREF(k1220), v_CLASS_2DNAME_0, v_SPEC_1, t26);
return(t0);
}
} else {
v_X_15 = v_SPEC_1;
v_X_17 = ((LP) DEREF((v_X_15) + 0 * 4));
v_Y_21 = (c_cons((v_X_17), (LREF(s_lsp_NIL))));
v_X_23 = (c_cons((LREF(s_key_NAME)), (v_Y_21)));
v_Y_27 = (c_cons((v_X_23), (LREF(s_lsp_NIL))));
t0 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_27)));
return(t0);
}
} else {
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,2), LREF(k1221), v_SPEC_1);
return(t0);
}
}
}

LP p_pcl_CANONICALIZE_2DDEFCLASS_2DOPTION(argc, v_CLASS_2DNAME_0, v_OPTION_1)
      ARGC argc;  LP v_CLASS_2DNAME_0; LP v_OPTION_1;
{
LP v_Y_78; LP v_X_77; LP v_Y_75; 
LP v_X_74; LP v_Y_72; LP v_X_71; 
LP v_Y_69; LP v_X_68; LP v_Y_66; 
LP v_X_65; LP v_X_63; LP v_Y_61; 
LP v_X_60; LP v_Y_58; LP v_X_57; 
LP v_X_55; LP v_Y_53; LP v_X_52; 
LP v_Y_50; LP v_X_49; LP v_Y_47; 
LP v_X_46; LP v_S1534_45; LP v_Y_43; 
LP v_X_42; LP v_VALUE1533_41; LP v_Y_39; 
LP v_X_38; LP v_Y_36; LP v_X_35; 
LP v_Y_33; LP v_X_32; LP v_Y_30; 
LP v_X_29; LP v_S1532_28; LP v_X_26; 
LP v_VALUE1531_25; LP v_X_23; LP v_LIST1530_22; 
LP v_S1529_21; LP v_X_19; LP v_VALUE1528_18; 
LP v_X_16; LP v_LIST1527_15; LP v_TAIL_11; 
LP v_VAL_10; LP v_KEY_9; LP v_X_7; 
LP v_CANONICAL_6; LP v_KEY1526_5; LP v_X_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 

if (argc != 2) wna(argc,2);
v_X_3 = v_OPTION_1;
v_KEY1526_5 = ((LP) DEREF((v_OPTION_1) + 0 * 4));
v_X_77 = v_KEY1526_5;
v_Y_78 = LREF(s_key_DEFAULT_2DINITARGS);
t1 = (c_eql((v_KEY1526_5), (LREF(s_key_DEFAULT_2DINITARGS))));
if (t1 != NIL) {
v_CANONICAL_6 = LREF(s_lsp_NIL);
v_KEY_9 = LREF(s_lsp_NIL);
v_VAL_10 = LREF(s_lsp_NIL);
v_X_7 = v_OPTION_1;
v_TAIL_11 = ((LP) DEREF((v_OPTION_1) + 1 * 4));
t_NEXT_2DLOOP_13:;
if (v_TAIL_11 == NIL) {
goto b_NIL_12;
}
v_LIST1527_15 = v_TAIL_11;
v_X_16 = v_LIST1527_15;
v_VALUE1528_18 = ((LP) DEREF((v_LIST1527_15) + 0 * 4));
v_X_19 = v_LIST1527_15;
v_S1529_21 = ((LP) DEREF((v_LIST1527_15) + 1 * 4));
v_TAIL_11 = v_S1529_21;
v_KEY_9 = v_VALUE1528_18;
v_LIST1530_22 = v_TAIL_11;
v_X_23 = v_LIST1530_22;
v_VALUE1531_25 = ((LP) DEREF((v_LIST1530_22) + 0 * 4));
v_X_26 = v_LIST1530_22;
v_S1532_28 = ((LP) DEREF((v_LIST1530_22) + 1 * 4));
v_TAIL_11 = v_S1532_28;
v_VAL_10 = v_VALUE1531_25;
v_X_29 = v_KEY_9;
v_Y_33 = (c_cons((v_X_29), (LREF(s_lsp_NIL))));
t2 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_33)));
t3 = ICALL(s_pcl_MAKE_2DINITFUNCTION) (1, v_VAL_10);
v_X_35 = v_VAL_10;
v_Y_39 = (c_cons((v_X_35), (LREF(s_lsp_NIL))));
t4 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_39)));
v_VALUE1533_41 = ICALL(s_lsp_LIST) (4, LREF(s_lsp_LIST), t2, t3, t4);
v_Y_43 = v_CANONICAL_6;
v_S1534_45 = (c_cons((v_VALUE1533_41), (v_Y_43)));
v_CANONICAL_6 = v_S1534_45;
goto t_NEXT_2DLOOP_13;
goto t_END_2DLOOP_14;
t_END_2DLOOP_14:;
b_NIL_12:;
v_Y_47 = ICALL(s_lsp_NREVERSE) (1, v_CANONICAL_6);
v_X_49 = (c_cons((LREF(s_lsp_LIST)), (v_Y_47)));
v_Y_53 = (c_cons((v_X_49), (LREF(s_lsp_NIL))));
t0 = (c_cons((LREF(k1222)), (v_Y_53)));
return(t0);
} else {
v_X_55 = v_OPTION_1;
v_X_57 = ((LP) DEREF((v_OPTION_1) + 0 * 4));
v_Y_61 = (c_cons((v_X_57), (LREF(s_lsp_NIL))));
v_X_74 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_61)));
v_X_63 = v_OPTION_1;
v_X_65 = ((LP) DEREF((v_OPTION_1) + 1 * 4));
v_Y_69 = (c_cons((v_X_65), (LREF(s_lsp_NIL))));
v_X_71 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_69)));
v_Y_75 = (c_cons((v_X_71), (LREF(s_lsp_NIL))));
t0 = (c_cons((v_X_74), (v_Y_75)));
return(t0);
}
}

LP p_pcl_MAKE_2DEARLY_2DCLASS_2DDEFINITION(argc, v_NAME_0, v_SOURCE_1, v_METACLASS_2, v_SUPERCLASS_2DNAMES_3, v_CANONICAL_2DSLOTS_4, v_OTHER_2DINITARGS_5)
      ARGC argc;  LP v_NAME_0; LP v_SOURCE_1; LP v_METACLASS_2; LP v_SUPERCLASS_2DNAMES_3; LP v_CANONICAL_2DSLOTS_4; LP v_OTHER_2DINITARGS_5;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 6) wna(argc,6);
t0 = ICALL(s_lsp_LIST) (MV_CALL(argc,7), LREF(s_pcl_EARLY_2DCLASS_2DDEFINITION), v_NAME_0, v_SOURCE_1, v_METACLASS_2, v_SUPERCLASS_2DNAMES_3, v_CANONICAL_2DSLOTS_4, v_OTHER_2DINITARGS_5);
return(t0);
}

LP p_pcl_ECD_2DCLASS_2DNAME(argc, v_ECD_0)
      ARGC argc;  LP v_ECD_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_NTH) (MV_CALL(argc,2), (LP) 2, v_ECD_0);
return(t0);
}

LP p_pcl_ECD_2DSOURCE(argc, v_ECD_0)
      ARGC argc;  LP v_ECD_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_NTH) (MV_CALL(argc,2), (LP) 4, v_ECD_0);
return(t0);
}

LP p_pcl_ECD_2DMETACLASS(argc, v_ECD_0)
      ARGC argc;  LP v_ECD_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_NTH) (MV_CALL(argc,2), (LP) 6, v_ECD_0);
return(t0);
}

LP p_pcl_ECD_2DSUPERCLASS_2DNAMES(argc, v_ECD_0)
      ARGC argc;  LP v_ECD_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_NTH) (MV_CALL(argc,2), (LP) 8, v_ECD_0);
return(t0);
}

LP p_pcl_ECD_2DCANONICAL_2DSLOTS(argc, v_ECD_0)
      ARGC argc;  LP v_ECD_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_NTH) (MV_CALL(argc,2), (LP) 10, v_ECD_0);
return(t0);
}

LP p_pcl_ECD_2DOTHER_2DINITARGS(argc, v_ECD_0)
      ARGC argc;  LP v_ECD_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_NTH) (MV_CALL(argc,2), (LP) 12, v_ECD_0);
return(t0);
}

LP p_pcl_LOAD_2DDEFCLASS(argc, v_NAME_0, v_METACLASS_1, v_SUPERS_2, v_CANONICAL_2DSLOTS_3, v_CANONICAL_2DOPTIONS_4, v_ACCESSOR_2DNAMES_5)
      ARGC argc;  LP v_NAME_0; LP v_METACLASS_1; LP v_SUPERS_2; LP v_CANONICAL_2DSLOTS_3; LP v_CANONICAL_2DOPTIONS_4; LP v_ACCESSOR_2DNAMES_5;
{
LP v_V_21; LP v_X_20; LP v_Y_18; 
LP v_X_17; LP v_SYMBOL_15; LP v_EXISTING_14; 
LP v_ECD_13; LP v_X_11; LP v_SYMBOL_9; 
LP v_X_7; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; 
if (argc != 6) wna(argc,6);
v_SUPERS_2 = ICALL(s_lsp_COPY_2DTREE) (1, v_SUPERS_2);
v_CANONICAL_2DSLOTS_3 = ICALL(s_lsp_COPY_2DTREE) (1, v_CANONICAL_2DSLOTS_3);
v_CANONICAL_2DOPTIONS_4 = ICALL(s_lsp_COPY_2DTREE) (1, v_CANONICAL_2DOPTIONS_4);
ICALL(s_pcl_DO_2DSTANDARD_2DDEFSETFS_2DFOR_2DDEFCLASS) (1, v_ACCESSOR_2DNAMES_5);
t0 = ICALL(s_pcl_LOAD_2DTRUENAME) (0);
v_X_7 = LREF(s_lsp_APPEND);
t2 = ((LP) DEREF((LREF(s_lsp_APPEND)) + 4 * 4));
t1 = p_lsp_APPLY(2, COERCE_TO_FUNCTION(t2), v_CANONICAL_2DOPTIONS_4);
v_ECD_13 = ICALL(s_pcl_MAKE_2DEARLY_2DCLASS_2DDEFINITION) (6, v_NAME_0, t0, v_METACLASS_1, v_SUPERS_2, v_CANONICAL_2DSLOTS_3, t1);
v_SYMBOL_9 = LREF(s_pcl__2AEARLY_2DCLASS_2DDEFINITIONS_2A);
t3 = ((LP) DEREF((LREF(s_pcl__2AEARLY_2DCLASS_2DDEFINITIONS_2A)) + 0 * 4));
v_X_11 = LREF(s_pcl_ECD_2DCLASS_2DNAME);
t4 = ((LP) DEREF((LREF(s_pcl_ECD_2DCLASS_2DNAME)) + 4 * 4));
v_EXISTING_14 = ICALL(s_lsp_FIND) (4, v_NAME_0, t3, LREF(s_key_KEY), t4);
v_SYMBOL_15 = LREF(s_pcl__2AEARLY_2DCLASS_2DDEFINITIONS_2A);
t5 = ((LP) DEREF((LREF(s_pcl__2AEARLY_2DCLASS_2DDEFINITIONS_2A)) + 0 * 4));
v_Y_18 = ICALL(s_lsp_REMOVE) (2, v_EXISTING_14, t5);
v_V_21 = (c_cons((v_ECD_13), (v_Y_18)));
((LP) (DEREF((LREF(s_pcl__2AEARLY_2DCLASS_2DDEFINITIONS_2A)) + 0 * 4) = (LD) (v_V_21)));
return(v_ECD_13);
}

LP p_pcl_DEFCLASS_5FINIT229(argc)
      ARGC argc; 
{
LP v_X_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; 
if (argc != 0) wna(argc,0);
ICALL(s_lsp_DEFINE_2DVARIABLE) (4, LREF(s_pcl__2ADEFCLASS_2DTIMES_2A), LREF(k1224), LREF(s_lsp_NIL), LREF(s_key_VAR));
ICALL(s_lsp_DEFINE_2DVARIABLE) (4, LREF(s_pcl__2ADEFMETHOD_2DTIMES_2A), LREF(k1224), LREF(s_lsp_NIL), LREF(s_key_VAR));
ICALL(s_lsp_DEFINE_2DVARIABLE) (4, LREF(s_pcl__2ADEFGENERIC_2DTIMES_2A), LREF(k1224), LREF(s_lsp_NIL), LREF(s_key_VAR));
v_X_1 = LREF(s_pcl_DEFCLASS);
t0 = ((LP) DEREF((LREF(s_pcl_DEFCLASS)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_pcl_DEFCLASS), t0);
t1 = ICALL(s_lsp_DEFINE_2DVARIABLE) (MV_CALL(argc,4), LREF(s_pcl__2AEARLY_2DCLASS_2DDEFINITIONS_2A), LREF(s_lsp_NIL), LREF(s_lsp_NIL), LREF(s_key_PARAMETER));
return(t1);
}

