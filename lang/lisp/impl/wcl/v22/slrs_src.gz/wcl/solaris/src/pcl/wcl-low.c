/*
:comment "Compiled at 12:31:40 pm on Sunday, June 12, 1994"
:comment "Compiler Configuration: DEFAULT"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w -g -O "
:version 0
:package (IN-PACKAGE (QUOTE PCL)) 
:end-package-info 0
:sym NIL
:sym SIMPLE-VECTOR
:sym THE
:sym FIXNUM
:sym SVREF
:sm %SVREF "m_pcl__25SVREF"
:sym *PRINT-BASE*
:sym LISP::OBJECT->POINTER
:sym LISP::WRITE-OBJECT
:sf PRINTING-RANDOM-THING-INTERNAL "p_pcl_PRINTING_2DRANDOM_2DTHING_2DINTERNAL"
:sym %SVREF
:sym LISP::DEFINE-MACRO
:sym LISP::DEFINE-SETF
:sym LISP::GENSYM/1
:sym SETF
:sf WCL-LOW_INIT210 "p_pcl_WCL_2DLOW_5FINIT210"
:init WCL-LOW_INIT210
:pinfo PCL::WCL-LOW_INIT210 NIL NIL NIL NIL NIL NIL NIL T
:pinfo PCL::PRINTING-RANDOM-THING-INTERNAL (PCL::THING STREAM) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP m_pcl__25SVREF();
extern SYMBOL s_lsp_NIL; 
extern SYMBOL s_lsp_SIMPLE_2DVECTOR; 
extern SYMBOL s_lsp_THE; 
extern SYMBOL s_lsp_FIXNUM; 
extern SYMBOL s_lsp_SVREF; 
extern LP p_pcl_PRINTING_2DRANDOM_2DTHING_2DINTERNAL();
extern SYMBOL s_lsp__2APRINT_2DBASE_2A; 
extern SYMBOL s_lsp_OBJECT_2D_3EPOINTER; 
extern SYMBOL s_lsp_WRITE_2DOBJECT; 
extern LP p_pcl_WCL_2DLOW_5FINIT210();
extern SYMBOL s_pcl__25SVREF; 
extern SYMBOL s_lsp_DEFINE_2DMACRO; 
extern LP p_pcl_WCL_2DLOW_5FINIT210_2Danon11651166();
MAKE_PROCEDURE(k1169,p_pcl_WCL_2DLOW_5FINIT210_2Danon11651166);
extern SYMBOL s_lsp_DEFINE_2DSETF; 
MAKE_SIMPLE_STRING(k1170,1,"S");
extern SYMBOL s_lsp_GENSYM_2F1; 
MAKE_SIMPLE_STRING(k1171,1,"T");
extern LP p_pcl_WCL_2DLOW_5FINIT210_2Danon11651166WCL_2DLOW_5FINIT210_2Danon11671168();
MAKE_PROCEDURE(k1172,p_pcl_WCL_2DLOW_5FINIT210_2Danon11651166WCL_2DLOW_5FINIT210_2Danon11671168);
extern SYMBOL s_lsp_SETF; 


extern LP c_cons();


LP m_pcl__25SVREF(argc, v_WHOLE1339_0, v_ENV1340_1)
      ARGC argc;  LP v_WHOLE1339_0; LP v_ENV1340_1;
{
LP v_Y_47; LP v_X_46; LP v_Y_44; 
LP v_X_43; LP v_Y_41; LP v_X_40; 
LP v_Y_38; LP v_X_37; LP v_Y_35; 
LP v_X_34; LP v_Y_32; LP v_X_31; 
LP v_Y_29; LP v_X_28; LP v_Y_26; 
LP v_X_25; LP v_Y_23; LP v_X_22; 
LP v_INDEX_21; LP v_S1354_20; LP v_X_18; 
LP v_VALUE1353_17; LP v_X_15; LP v_LIST1352_14; 
LP v_VECTOR_13; LP v_S1351_12; LP v_X_10; 
LP v_VALUE1350_9; LP v_X_7; LP v_LIST1349_6; 
LP v_L1348_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE1339_0;
v_L1348_5 = ((LP) DEREF((v_WHOLE1339_0) + 1 * 4));
v_LIST1349_6 = v_L1348_5;
v_X_7 = v_LIST1349_6;
v_VALUE1350_9 = ((LP) DEREF((v_LIST1349_6) + 0 * 4));
v_X_10 = v_LIST1349_6;
v_S1351_12 = ((LP) DEREF((v_LIST1349_6) + 1 * 4));
v_L1348_5 = v_S1351_12;
v_VECTOR_13 = v_VALUE1350_9;
v_LIST1352_14 = v_L1348_5;
v_X_15 = v_LIST1352_14;
v_VALUE1353_17 = ((LP) DEREF((v_LIST1352_14) + 0 * 4));
v_X_18 = v_LIST1352_14;
v_S1354_20 = ((LP) DEREF((v_LIST1352_14) + 1 * 4));
v_L1348_5 = v_S1354_20;
v_INDEX_21 = v_VALUE1353_17;
v_X_22 = v_VECTOR_13;
v_Y_23 = LREF(s_lsp_NIL);
v_Y_26 = (c_cons((v_VECTOR_13), (LREF(s_lsp_NIL))));
v_Y_29 = (c_cons((LREF(s_lsp_SIMPLE_2DVECTOR)), (v_Y_26)));
v_X_43 = (c_cons((LREF(s_lsp_THE)), (v_Y_29)));
v_X_31 = v_INDEX_21;
v_Y_32 = LREF(s_lsp_NIL);
v_Y_35 = (c_cons((v_INDEX_21), (LREF(s_lsp_NIL))));
v_Y_38 = (c_cons((LREF(s_lsp_FIXNUM)), (v_Y_35)));
v_X_40 = (c_cons((LREF(s_lsp_THE)), (v_Y_38)));
v_Y_44 = (c_cons((v_X_40), (LREF(s_lsp_NIL))));
v_Y_47 = (c_cons((v_X_43), (v_Y_44)));
t0 = (c_cons((LREF(s_lsp_SVREF)), (v_Y_47)));
return(t0);
}

LP p_pcl_PRINTING_2DRANDOM_2DTHING_2DINTERNAL(argc, v_THING_0, v_STREAM_1)
      ARGC argc;  LP v_THING_0; LP v_STREAM_1;
{
LP v__2APRINT_2DBASE_2A_3; 
LP t0; LP t1; LP t2; LP t3; 
if (argc != 2) wna(argc,2);
v__2APRINT_2DBASE_2A_3 = (LP) 32;
BEGIN_SPEC_BIND(s_lsp__2APRINT_2DBASE_2A,(LP) 32);
t1 = ICALL(s_lsp_OBJECT_2D_3EPOINTER) (1, v_THING_0);
t0 = ICALL(s_lsp_WRITE_2DOBJECT) (MV_CALL(argc,2), t1, v_STREAM_1);
END_SPEC_BIND(s_lsp__2APRINT_2DBASE_2A);
return(t0);
}

LP p_pcl_WCL_2DLOW_5FINIT210(argc)
      ARGC argc; 
{
LP v_X_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 0) wna(argc,0);
v_X_1 = LREF(s_pcl__25SVREF);
t0 = ((LP) DEREF((LREF(s_pcl__25SVREF)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_pcl__25SVREF), t0);
t1 = ICALL(s_lsp_DEFINE_2DSETF) (MV_CALL(argc,2), LREF(s_pcl__25SVREF), LREF(k1169));
return(t1);
}

LP p_pcl_WCL_2DLOW_5FINIT210_2Danon11651166(argc, v_ACCESS_0, v_ENV_1)
      ARGC argc;  LP v_ACCESS_0; LP v_ENV_1;
{
LP v_Y_45; LP v_X_44; LP v_X_42; 
LP v_LIST_40; LP v_Y_38; LP v_X_37; 
LP v_X_35; LP v_TVARS_34; LP v_SVAR_33; 
LP v_X_31; LP v_V_29; LP v_X_28; 
LP v_NEW_2DCDR_26; LP v_C_25; LP v_Y_23; 
LP v_X_22; LP v_X_20; LP v_X_19; 
LP v_X_17; LP v_X_15; LP v_LOOPVAR_2D214_11; 
LP v_LOOPVAR_2D213_10; LP v_LOOPVAR_2D212_9; LP v_LOOP_2DLIST_2D211_8; 
LP v_ARG_7; LP v_X_5; LP v_X_3; 
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; 
if (argc != 2) wna(argc,2);
v_X_3 = LREF(k1170);
v_SVAR_33 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(k1170));
v_ARG_7 = LREF(s_lsp_NIL);
v_X_5 = v_ACCESS_0;
v_LOOP_2DLIST_2D211_8 = ((LP) DEREF((v_ACCESS_0) + 1 * 4));
v_LOOPVAR_2D212_9 = LREF(s_lsp_NIL);
v_LOOPVAR_2D213_10 = LREF(s_lsp_NIL);
v_LOOPVAR_2D214_11 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_13:;
if (v_LOOP_2DLIST_2D211_8 == NIL) {
goto t_END_2DLOOP_14;
}
v_X_15 = v_LOOP_2DLIST_2D211_8;
v_ARG_7 = ((LP) DEREF((v_X_15) + 0 * 4));
v_X_17 = v_LOOP_2DLIST_2D211_8;
v_LOOP_2DLIST_2D211_8 = ((LP) DEREF((v_X_17) + 1 * 4));
v_X_20 = LREF(k1171);
v_X_22 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(k1171));
v_LOOPVAR_2D214_11 = (c_cons((v_X_22), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D213_10 != NIL) {
v_C_25 = v_LOOPVAR_2D213_10;
v_NEW_2DCDR_26 = v_LOOPVAR_2D214_11;
v_V_29 = v_NEW_2DCDR_26;
((LP) (DEREF((v_C_25) + 1 * 4) = (LD) (v_V_29)));
v_X_31 = v_C_25;
v_LOOPVAR_2D213_10 = ((LP) DEREF((v_X_31) + 1 * 4));
} else {
v_LOOPVAR_2D212_9 = v_LOOPVAR_2D214_11;
v_LOOPVAR_2D213_10 = v_LOOPVAR_2D212_9;
}
goto t_NEXT_2DLOOP_13;
goto t_END_2DLOOP_14;
t_END_2DLOOP_14:;
v_TVARS_34 = v_LOOPVAR_2D212_9;
goto b_NIL_12;
v_TVARS_34 = NIL;
v_TVARS_34 = v_TVARS_34;
b_NIL_12:;
v_X_35 = v_ACCESS_0;
t0 = ((LP) DEREF((v_ACCESS_0) + 1 * 4));
v_X_37 = v_SVAR_33;
v_Y_38 = LREF(s_lsp_NIL);
t1 = (c_cons((v_SVAR_33), (LREF(s_lsp_NIL))));
t2 = p_lsp_APPLY(3, COERCE_TO_FUNCTION(LREF(k1172)), v_SVAR_33, v_TVARS_34);
v_LIST_40 = v_ACCESS_0;
v_X_42 = v_ACCESS_0;
v_X_44 = ((LP) DEREF((v_ACCESS_0) + 0 * 4));
t3 = (c_cons((v_X_44), (v_TVARS_34)));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,5);
SET_MV_RETURN_VALUE(argc,1,t0);
SET_MV_RETURN_VALUE(argc,2,t1);
SET_MV_RETURN_VALUE(argc,3,t2);
SET_MV_RETURN_VALUE(argc,4,t3);
}
return(v_TVARS_34);
}

LP p_pcl_WCL_2DLOW_5FINIT210_2Danon11651166WCL_2DLOW_5FINIT210_2Danon11671168(argc, v_NEW_2DVALUE_0, v_VECTOR_1, v_INDEX_2)
      ARGC argc;  LP v_NEW_2DVALUE_0; LP v_VECTOR_1; LP v_INDEX_2;
{
LP v_Y_37; LP v_X_36; LP v_Y_34; 
LP v_X_33; LP v_Y_31; LP v_X_30; 
LP v_Y_28; LP v_X_27; LP v_Y_25; 
LP v_X_24; LP v_Y_22; LP v_X_21; 
LP v_Y_19; LP v_X_18; LP v_Y_16; 
LP v_X_15; LP v_Y_13; LP v_X_12; 
LP v_Y_10; LP v_X_9; LP v_Y_7; 
LP v_X_6; LP v_Y_4; LP v_X_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; 
if (argc != 3) wna(argc,3);
v_X_3 = v_VECTOR_1;
v_Y_4 = LREF(s_lsp_NIL);
v_Y_7 = (c_cons((v_VECTOR_1), (LREF(s_lsp_NIL))));
v_Y_10 = (c_cons((LREF(s_lsp_SIMPLE_2DVECTOR)), (v_Y_7)));
v_X_24 = (c_cons((LREF(s_lsp_THE)), (v_Y_10)));
v_X_12 = v_INDEX_2;
v_Y_13 = LREF(s_lsp_NIL);
v_Y_16 = (c_cons((v_INDEX_2), (LREF(s_lsp_NIL))));
v_Y_19 = (c_cons((LREF(s_lsp_FIXNUM)), (v_Y_16)));
v_X_21 = (c_cons((LREF(s_lsp_THE)), (v_Y_19)));
v_Y_25 = (c_cons((v_X_21), (LREF(s_lsp_NIL))));
v_Y_28 = (c_cons((v_X_24), (v_Y_25)));
v_X_33 = (c_cons((LREF(s_lsp_SVREF)), (v_Y_28)));
v_X_30 = v_NEW_2DVALUE_0;
v_Y_31 = LREF(s_lsp_NIL);
v_Y_34 = (c_cons((v_NEW_2DVALUE_0), (LREF(s_lsp_NIL))));
v_Y_37 = (c_cons((v_X_33), (v_Y_34)));
t0 = (c_cons((LREF(s_lsp_SETF)), (v_Y_37)));
return(t0);
}

