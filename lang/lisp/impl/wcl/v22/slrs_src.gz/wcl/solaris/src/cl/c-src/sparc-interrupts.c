/*  (C) Copyright 1990-1994 by Wade L. Hennessey. All rights reserved. */

#include "lisp.h"
#include <signal.h>

extern void lisp_debug();

signal_handler (sig,code,scp)
     int sig, code;
     struct sigcontext *scp;

{
  printf("WCL: Ignoring signal number %d, aborting to top-level\n",sig);
  abort_to_top_level();
}



