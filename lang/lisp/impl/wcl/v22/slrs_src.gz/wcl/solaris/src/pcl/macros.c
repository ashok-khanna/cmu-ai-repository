/*
:comment "Compiled at 12:30:42 pm on Sunday, June 12, 1994"
:comment "Compiler Configuration: DEFAULT"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w -g -O "
:version 0
:package (IN-PACKAGE (QUOTE PCL)) 
:end-package-info 0
:proclaim (QUOTE (DECLARATION VALUES ARGLIST INDENTATION CLASS VARIABLE-REBINDING PCL-FAST-CALL))
:sym MEMBER
:sym :TEST
:sym FUNCTION
:sym EQ
:sym NIL
:sym LIST*
:sm MEMQ "m_pcl_MEMQ"
:sym ASSOC
:sm ASSQ "m_pcl_ASSQ"
:sym RASSOC
:sm RASSQ "m_pcl_RASSQ"
:sym DELETE
:sm DELQ "m_pcl_DELQ"
:sym POSITION
:sm POSQ "m_pcl_POSQ"
:sym NOT
:sm NEQ "m_pcl_NEQ"
:sym CAR
:sym CADR
:sym CADDR
:sym CADDDR
:sym NTH
:sym CDDDDR
:sf MAKE-CAXR "p_pcl_MAKE_2DCAXR"
:sym IDENTITY
:sym CDR
:sym CDDR
:sym CDDDR
:sf MAKE-CDXR "p_pcl_MAKE_2DCDXR"
:sym T
:sf TRUE "p_pcl_TRUE"
:sf FALSE "p_pcl_FALSE"
:sf ZERO "p_pcl_ZERO"
:sym MAKE-PLIST
:sf MAKE-PLIST "p_pcl_MAKE_2DPLIST"
:sym REMTAIL
:sf REMTAIL "p_pcl_REMTAIL"
:sym LISP::GENSYM/1
:sym IF
:sym OR
:sym SYMBOLP
:sym NUMBERP
:sym LISTP
:sym QUOTE
:sym AND
:sym LIST
:sym LET
:sym GENSYM
:sym PUSH
:sym REVERSE
:sym WRAPPED-BODY
:sym MAPCAR
:sym LET*
:sm ONCE-ONLY "m_pcl_ONCE_2DONLY"
:sym STRINGP
:sym DECLARE
:sym MACROEXPAND-1
:sym NREVERSE
:sf EXTRACT-DECLARATIONS "p_pcl_EXTRACT_2DDECLARATIONS"
:sym *KEYWORD-PACKAGE*
:sym LISP::COERCE-TO-PACKAGE
:sym LISP::INTERN/2
:sf MAKE-KEYWORD "p_pcl_MAKE_2DKEYWORD"
:sym COPY-LIST
:sym STRING
:sym CONCATENATE
:sf STRING-APPEND "p_pcl_STRING_2DAPPEND"
:sym *PACKAGE*
:sym STRING-APPEND
:sf SYMBOL-APPEND "p_pcl_SYMBOL_2DAPPEND"
:sym EQL
:sym :PRETTY-NAME
:sym LISP::MEMQL
:sym ERROR
:sm CHECK-MEMBER "m_pcl_CHECK_2DMEMBER"
:sym ASSQ
:sym CONS
:sym SETF
:sym PROGN
:sm ALIST-ENTRY "m_pcl_ALIST_2DENTRY"
:sym EXTRACT-DECLARATIONS
:sym DESTRUCTURE
:sym .DESTRUCTURE-FORM.
:sym LISP::APPEND/2
:sm DESTRUCTURING-BIND "m_pcl_DESTRUCTURING_2DBIND"
:sym *DESTRUCTURE-VARS*
:sym SETQ
:sym DESTRUCTURE-INTERNAL
:sym LISP::NCONC/2
:sym LENGTH
:sym LISP::SEQ-TEST
:sym LISP::DELETE/8
:sf DESTRUCTURE "p_pcl_DESTRUCTURE"
:sym IGNORE
:sym LISP::MEMQ
:sym MAKE-CDXR
:sym POP
:sym MAKE-CAXR
:sf DESTRUCTURE-INTERNAL "p_pcl_DESTRUCTURE_2DINTERNAL"
:sym :INITIAL-VALUE
:sym HEAD
:sym LAST
:sym TAIL
:sym VALUES
:sym LAMBDA
:sym VALUE
:sym NULL
:sym UNLESS
:sym MEMQ
:sym RPLACD
:sm COLLECTING-ONCE "m_pcl_COLLECTING_2DONCE"
:sym .PLIST-TAIL.
:sym LOOP
:sym WHEN
:sym RETURN
:sm DOPLIST "m_pcl_DOPLIST"
:sm IF* "m_pcl_IF_2A"
:sym FORMAT
:sym PRINTING-RANDOM-THING-INTERNAL
:sm PRINTING-RANDOM-THING "m_pcl_PRINTING_2DRANDOM_2DTHING"
:sf PRINTING-RANDOM-THING-INTERNAL "p_pcl_PRINTING_2DRANDOM_2DTHING_2DINTERNAL"
:sym COPY-SEQ
:sym ELT
:sym BOTH-CASE-P
:sym LOWER-CASE-P
:sym CHAR-UPCASE
:sym LISP::SET-ELT
:sym CHAR-DOWNCASE
:sym CHAR-EQUAL
:sf CAPITALIZE-WORDS "p_pcl_CAPITALIZE_2DWORDS"
:sym KEYWORDP
:sf LEGAL-CLASS-NAME-P "p_pcl_LEGAL_2DCLASS_2DNAME_2DP"
:sym *FIND-CLASS*
:sym GETHASH
:sym LEGAL-CLASS-NAME-P
:sf FIND-CLASS "p_pcl_FIND_2DCLASS"
:sym LISP::SET-GETHASH
:sf |SETF PCL FIND-CLASS| "p_pcl_SETF_20PCL_20FIND_2DCLASS"
:sym FIND-CLASS
:sym CLASS-WRAPPER
:sf FIND-WRAPPER "p_pcl_FIND_2DWRAPPER"
:sym .GATHERING1.
:sym MACROLET
:sym GATHER1
:sym X
:sym GATHER
:sym GATHERING
:sm GATHERING1 "m_pcl_GATHERING1"
:sym :SIZE
:sym LIMIT
:sym RESULT
:sym MAKE-ARRAY
:sym INDEX
:sym =
:sym SVREF
:sym INCF
:sm VECTORIZING "m_pcl_VECTORIZING"
:sym :BY
:sym ENDP
:sym FUNCALL
:sym FINISH
:sym PROG1
:sm *LIST-ELEMENTS "m_pcl__2ALIST_2DELEMENTS"
:sm *LIST-TAILS "m_pcl__2ALIST_2DTAILS"
:sym LISP::DEFINE-MACRO
:sym RASSQ
:sym DELQ
:sym POSQ
:sym NEQ
:sym ONCE-ONLY
:sym KEYWORD
:sym FIND-PACKAGE
:sym :VAR
:sym LISP::DEFINE-VARIABLE
:sym CHECK-MEMBER
:sym ALIST-ENTRY
:sym DESTRUCTURING-BIND
:sym COLLECTING-ONCE
:sym DOPLIST
:sym IF*
:sym PRINTING-RANDOM-THING
:sym LISP::MAKE-HASH-TABLE-1
:sym LISP::DEFINE-SETF
:sym GATHERING1
:sym VECTORIZING
:sym *LIST-ELEMENTS
:sym *LIST-TAILS
:sym |SETF PCL FIND-CLASS|
:sf MACROS_INIT187 "p_pcl_MACROS_5FINIT187"
:init MACROS_INIT187
:pinfo PCL::|SETF PCL FIND-CLASS| (PCL::NEW-VALUE SYMBOL) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::SYMBOL-APPEND (PCL::SYM1 PCL::SYM2 &OPTIONAL (PACKAGE *PACKAGE*)) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::DESTRUCTURE (PCL::PATTERN PCL::FORM) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::LEGAL-CLASS-NAME-P (PCL::X) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::MAKE-CAXR (PCL::N PCL::FORM) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::CAPITALIZE-WORDS (STRING &OPTIONAL (PCL::DASHES-P T)) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::EXTRACT-DECLARATIONS (PCL::BODY &OPTIONAL PCL::ENVIRONMENT) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::MACROS_INIT187 NIL NIL NIL NIL NIL NIL NIL T
:pinfo PCL::ZERO (&REST IGNORE) NIL NIL NIL NIL NIL NIL T
:pinfo PCL:FIND-CLASS (SYMBOL &OPTIONAL (PCL::ERRORP T) PCL::ENVIRONMENT) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::STRING-APPEND (&REST PCL::STRINGS) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::PRINTING-RANDOM-THING-INTERNAL (PCL::THING STREAM) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::MAKE-CDXR (PCL::N PCL::FORM) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::MAKE-PLIST (PCL::KEYS PCL::VALS) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::FALSE (&REST IGNORE) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::TRUE (&REST IGNORE) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::MAKE-KEYWORD (SYMBOL) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::FIND-WRAPPER (SYMBOL) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::DESTRUCTURE-INTERNAL (PCL::PATTERN PCL::FORM) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::REMTAIL (LIST PCL::TAIL) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP m_pcl_MEMQ();
extern SYMBOL s_lsp_MEMBER; 
extern SYMBOL s_key_TEST; 
extern SYMBOL s_lsp_FUNCTION; 
extern SYMBOL s_lsp_EQ; 
extern SYMBOL s_lsp_NIL; 
MAKE_CONS(k931,LREF(s_lsp_EQ),LREF(s_lsp_NIL));
MAKE_CONS(k930,LREF(s_lsp_FUNCTION),LREF(k931));
MAKE_CONS(k929,LREF(k930),LREF(s_lsp_NIL));
MAKE_CONS(k928,LREF(s_key_TEST),LREF(k929));
extern SYMBOL s_lsp_LIST_2A; 
extern LP m_pcl_ASSQ();
extern SYMBOL s_lsp_ASSOC; 
extern LP m_pcl_RASSQ();
extern SYMBOL s_lsp_RASSOC; 
extern LP m_pcl_DELQ();
extern SYMBOL s_lsp_DELETE; 
extern LP m_pcl_POSQ();
extern SYMBOL s_lsp_POSITION; 
extern LP m_pcl_NEQ();
extern SYMBOL s_lsp_NOT; 
extern LP p_pcl_MAKE_2DCAXR();
extern SYMBOL s_lsp_CAR; 
extern SYMBOL s_lsp_CADR; 
extern SYMBOL s_lsp_CADDR; 
extern SYMBOL s_lsp_CADDDR; 
MAKE_CONS(k936,LREF(s_lsp_CADDDR),LREF(s_lsp_NIL));
MAKE_CONS(k935,LREF(s_lsp_CADDR),LREF(k936));
MAKE_CONS(k934,LREF(s_lsp_CADR),LREF(k935));
MAKE_CONS(k933,LREF(s_lsp_CAR),LREF(k934));
extern SYMBOL s_lsp_NTH; 
extern SYMBOL s_lsp_CDDDDR; 
extern LP p_pcl_MAKE_2DCDXR();
extern SYMBOL s_lsp_IDENTITY; 
extern SYMBOL s_lsp_CDR; 
extern SYMBOL s_lsp_CDDR; 
extern SYMBOL s_lsp_CDDDR; 
MAKE_CONS(k942,LREF(s_lsp_CDDDDR),LREF(s_lsp_NIL));
MAKE_CONS(k941,LREF(s_lsp_CDDDR),LREF(k942));
MAKE_CONS(k940,LREF(s_lsp_CDDR),LREF(k941));
MAKE_CONS(k939,LREF(s_lsp_CDR),LREF(k940));
MAKE_CONS(k938,LREF(s_lsp_IDENTITY),LREF(k939));
extern LP p_pcl_TRUE();
extern SYMBOL s_lsp_T; 
extern LP p_pcl_FALSE();
extern LP p_pcl_ZERO();
extern LP p_pcl_MAKE_2DPLIST();
extern SYMBOL s_pcl_MAKE_2DPLIST; 
extern LP p_pcl_REMTAIL();
extern SYMBOL s_pcl_REMTAIL; 
extern LP m_pcl_ONCE_2DONLY();
extern SYMBOL s_lsp_GENSYM_2F1; 
extern SYMBOL s_lsp_IF; 
extern SYMBOL s_lsp_OR; 
extern SYMBOL s_lsp_SYMBOLP; 
extern SYMBOL s_lsp_NUMBERP; 
extern SYMBOL s_lsp_LISTP; 
extern SYMBOL s_lsp_QUOTE; 
MAKE_CONS(k947,LREF(s_lsp_FUNCTION),LREF(s_lsp_NIL));
MAKE_CONS(k946,LREF(s_lsp_QUOTE),LREF(k947));
MAKE_CONS(k945,LREF(k946),LREF(s_lsp_NIL));
MAKE_CONS(k944,LREF(s_lsp_QUOTE),LREF(k945));
MAKE_CONS(k943,LREF(k944),LREF(s_lsp_NIL));
extern SYMBOL s_lsp_AND; 
extern SYMBOL s_lsp_LIST; 
extern SYMBOL s_lsp_LET; 
extern SYMBOL s_lsp_GENSYM; 
MAKE_CONS(k949,LREF(s_lsp_GENSYM),LREF(s_lsp_NIL));
MAKE_CONS(k948,LREF(k949),LREF(s_lsp_NIL));
extern SYMBOL s_lsp_PUSH; 
extern SYMBOL s_lsp_REVERSE; 
extern SYMBOL s_pcl_WRAPPED_2DBODY; 
MAKE_CONS(k951,LREF(s_lsp_LET),LREF(s_lsp_NIL));
MAKE_CONS(k950,LREF(s_lsp_QUOTE),LREF(k951));
extern SYMBOL s_lsp_MAPCAR; 
MAKE_CONS(k953,LREF(s_lsp_LIST),LREF(s_lsp_NIL));
MAKE_CONS(k952,LREF(s_lsp_FUNCTION),LREF(k953));
MAKE_CONS(k954,LREF(s_pcl_WRAPPED_2DBODY),LREF(s_lsp_NIL));
extern SYMBOL s_lsp_LET_2A; 
extern LP p_pcl_EXTRACT_2DDECLARATIONS();
extern SYMBOL s_lsp_STRINGP; 
extern SYMBOL s_lsp_DECLARE; 
extern SYMBOL s_lsp_MACROEXPAND_2D1; 
extern SYMBOL s_lsp_NREVERSE; 
extern LP p_pcl_MAKE_2DKEYWORD();
extern SYMBOL s_pcl__2AKEYWORD_2DPACKAGE_2A; 
extern SYMBOL s_lsp_COERCE_2DTO_2DPACKAGE; 
extern SYMBOL s_lsp_INTERN_2F2; 
extern LP p_pcl_STRING_2DAPPEND();
extern SYMBOL s_lsp_COPY_2DLIST; 
extern SYMBOL s_lsp_STRING; 
extern SYMBOL s_lsp_CONCATENATE; 
extern LP p_pcl_SYMBOL_2DAPPEND();
extern SYMBOL s_lsp__2APACKAGE_2A; 
extern SYMBOL s_pcl_STRING_2DAPPEND; 
extern LP m_pcl_CHECK_2DMEMBER();
extern LP p_pcl_CHECK_2DMEMBER_2Danon956957();
extern SYMBOL s_lsp_EQL; 
extern SYMBOL s_key_PRETTY_2DNAME; 
extern SYMBOL s_lsp_MEMQL; 
extern SYMBOL s_lsp_ERROR; 
MAKE_SIMPLE_STRING(k958,37,"The value of ~A, ~S is not one of ~S.");
extern LP m_pcl_ALIST_2DENTRY();
extern SYMBOL s_pcl_ASSQ; 
extern SYMBOL s_lsp_CONS; 
extern SYMBOL s_lsp_SETF; 
extern SYMBOL s_lsp_PROGN; 
extern LP m_pcl_DESTRUCTURING_2DBIND();
extern SYMBOL s_pcl_EXTRACT_2DDECLARATIONS; 
extern SYMBOL s_pcl_DESTRUCTURE; 
extern SYMBOL s_pcl__2EDESTRUCTURE_2DFORM_2E; 
MAKE_CONS(k962,LREF(s_pcl__2EDESTRUCTURE_2DFORM_2E),LREF(s_lsp_NIL));
MAKE_CONS(k961,LREF(s_lsp_PROGN),LREF(k962));
extern SYMBOL s_lsp_APPEND_2F2; 
extern LP p_pcl_DESTRUCTURE();
extern SYMBOL s_pcl__2ADESTRUCTURE_2DVARS_2A; 
extern SYMBOL s_lsp_SETQ; 
extern SYMBOL s_pcl_DESTRUCTURE_2DINTERNAL; 
extern SYMBOL s_lsp_NCONC_2F2; 
extern SYMBOL s_lsp_LENGTH; 
extern SYMBOL s_lsp_SEQ_2DTEST; 
extern SYMBOL s_lsp_DELETE_2F8; 
extern LP p_pcl_DESTRUCTURE_2DINTERNAL();
extern LP p_pcl_DESTRUCTURE_2DINTERNAL_2DMAKE_2DPOP963();
extern SYMBOL s_lsp_IGNORE; 
MAKE_CONS(k965,LREF(s_lsp_IGNORE),LREF(s_lsp_NIL));
MAKE_CONS(k964,LREF(s_lsp_NIL),LREF(k965));
extern SYMBOL s_lsp_MEMQ; 
MAKE_CONS(k966,LREF(s_lsp_NIL),LREF(s_lsp_NIL));
extern SYMBOL s_pcl_MAKE_2DCDXR; 
extern SYMBOL s_lsp_POP; 
extern SYMBOL s_pcl_MAKE_2DCAXR; 
extern LP m_pcl_COLLECTING_2DONCE();
extern LP p_pcl_COLLECTING_2DONCE_2Danon967968();
MAKE_PROCEDURE(k969,p_pcl_COLLECTING_2DONCE_2Danon967968);
extern SYMBOL s_key_INITIAL_2DVALUE; 
extern SYMBOL s_pcl_HEAD; 
extern SYMBOL s_lsp_LAST; 
MAKE_CONS(k971,LREF(s_pcl_HEAD),LREF(s_lsp_NIL));
MAKE_CONS(k970,LREF(s_lsp_LAST),LREF(k971));
extern SYMBOL s_pcl_TAIL; 
extern SYMBOL s_lsp_VALUES; 
extern SYMBOL s_lsp_LAMBDA; 
extern SYMBOL s_pcl_VALUE; 
MAKE_CONS(k979,LREF(s_pcl_VALUE),LREF(s_lsp_NIL));
extern SYMBOL s_lsp_NULL; 
MAKE_CONS(k983,LREF(s_lsp_NULL),LREF(k971));
MAKE_CONS(k991,LREF(s_lsp_LIST),LREF(k979));
MAKE_CONS(k990,LREF(k991),LREF(s_lsp_NIL));
MAKE_CONS(k989,LREF(s_pcl_TAIL),LREF(k990));
MAKE_CONS(k988,LREF(s_lsp_SETQ),LREF(k989));
MAKE_CONS(k987,LREF(k988),LREF(s_lsp_NIL));
MAKE_CONS(k986,LREF(s_pcl_HEAD),LREF(k987));
MAKE_CONS(k985,LREF(s_lsp_SETQ),LREF(k986));
extern SYMBOL s_lsp_UNLESS; 
extern SYMBOL s_pcl_MEMQ; 
MAKE_CONS(k996,LREF(s_pcl_VALUE),LREF(k971));
MAKE_CONS(k995,LREF(s_pcl_MEMQ),LREF(k996));
extern SYMBOL s_lsp_RPLACD; 
MAKE_CONS(k1003,LREF(s_lsp_RPLACD),LREF(k989));
MAKE_CONS(k1002,LREF(k1003),LREF(s_lsp_NIL));
MAKE_CONS(k1001,LREF(s_lsp_CDR),LREF(k1002));
MAKE_CONS(k1000,LREF(k1001),LREF(s_lsp_NIL));
MAKE_CONS(k999,LREF(s_pcl_TAIL),LREF(k1000));
MAKE_CONS(k998,LREF(s_lsp_SETQ),LREF(k999));
MAKE_CONS(k997,LREF(k998),LREF(s_lsp_NIL));
MAKE_CONS(k994,LREF(k995),LREF(k997));
MAKE_CONS(k993,LREF(s_lsp_UNLESS),LREF(k994));
MAKE_CONS(k992,LREF(k993),LREF(s_lsp_NIL));
MAKE_CONS(k984,LREF(k985),LREF(k992));
MAKE_CONS(k982,LREF(k983),LREF(k984));
MAKE_CONS(k981,LREF(s_lsp_IF),LREF(k982));
MAKE_CONS(k980,LREF(k981),LREF(s_lsp_NIL));
MAKE_CONS(k978,LREF(k979),LREF(k980));
MAKE_CONS(k977,LREF(s_lsp_LAMBDA),LREF(k978));
MAKE_CONS(k976,LREF(k977),LREF(s_lsp_NIL));
MAKE_CONS(k975,LREF(s_lsp_FUNCTION),LREF(k976));
MAKE_CONS(k1008,LREF(s_lsp_NIL),LREF(k971));
MAKE_CONS(k1007,LREF(s_lsp_LAMBDA),LREF(k1008));
MAKE_CONS(k1006,LREF(k1007),LREF(s_lsp_NIL));
MAKE_CONS(k1005,LREF(s_lsp_FUNCTION),LREF(k1006));
MAKE_CONS(k1004,LREF(k1005),LREF(s_lsp_NIL));
MAKE_CONS(k974,LREF(k975),LREF(k1004));
MAKE_CONS(k973,LREF(s_lsp_VALUES),LREF(k974));
MAKE_CONS(k972,LREF(k973),LREF(s_lsp_NIL));
extern LP m_pcl_DOPLIST();
extern SYMBOL s_pcl__2EPLIST_2DTAIL_2E; 
extern SYMBOL s_lsp_LOOP; 
extern SYMBOL s_lsp_WHEN; 
MAKE_CONS(k1013,LREF(s_pcl__2EPLIST_2DTAIL_2E),LREF(s_lsp_NIL));
MAKE_CONS(k1012,LREF(s_lsp_NULL),LREF(k1013));
extern SYMBOL s_lsp_RETURN; 
MAKE_CONS(k1015,LREF(s_lsp_RETURN),LREF(k966));
MAKE_CONS(k1014,LREF(k1015),LREF(s_lsp_NIL));
MAKE_CONS(k1011,LREF(k1012),LREF(k1014));
MAKE_CONS(k1010,LREF(s_lsp_WHEN),LREF(k1011));
MAKE_CONS(k1017,LREF(s_lsp_POP),LREF(k1013));
MAKE_CONS(k1016,LREF(k1017),LREF(s_lsp_NIL));
MAKE_SIMPLE_STRING(k1023,51,"Malformed plist in doplist, odd number of elements.");
MAKE_CONS(k1022,LREF(k1023),LREF(s_lsp_NIL));
MAKE_CONS(k1021,LREF(s_lsp_ERROR),LREF(k1022));
MAKE_CONS(k1020,LREF(k1021),LREF(s_lsp_NIL));
MAKE_CONS(k1019,LREF(k1012),LREF(k1020));
MAKE_CONS(k1018,LREF(s_lsp_WHEN),LREF(k1019));
extern LP m_pcl_IF_2A();
extern LP m_pcl_PRINTING_2DRANDOM_2DTHING();
extern SYMBOL s_lsp_FORMAT; 
MAKE_SIMPLE_STRING(k1025,2,"#<");
MAKE_CONS(k1024,LREF(k1025),LREF(s_lsp_NIL));
MAKE_SIMPLE_STRING(k1027,1," ");
MAKE_CONS(k1026,LREF(k1027),LREF(s_lsp_NIL));
extern SYMBOL s_pcl_PRINTING_2DRANDOM_2DTHING_2DINTERNAL; 
MAKE_SIMPLE_STRING(k1029,1,">");
MAKE_CONS(k1028,LREF(k1029),LREF(s_lsp_NIL));
extern LP p_pcl_PRINTING_2DRANDOM_2DTHING_2DINTERNAL();
extern LP p_pcl_CAPITALIZE_2DWORDS();
extern SYMBOL s_lsp_COPY_2DSEQ; 
extern SYMBOL s_lsp_ELT; 
extern SYMBOL s_lsp_BOTH_2DCASE_2DP; 
extern SYMBOL s_lsp_LOWER_2DCASE_2DP; 
extern SYMBOL s_lsp_CHAR_2DUPCASE; 
extern SYMBOL s_lsp_SET_2DELT; 
extern SYMBOL s_lsp_CHAR_2DDOWNCASE; 
extern SYMBOL s_lsp_CHAR_2DEQUAL; 
extern LP p_pcl_LEGAL_2DCLASS_2DNAME_2DP();
extern SYMBOL s_lsp_KEYWORDP; 
extern LP p_pcl_FIND_2DCLASS();
extern SYMBOL s_pcl__2AFIND_2DCLASS_2A; 
extern SYMBOL s_lsp_GETHASH; 
extern SYMBOL s_pcl_LEGAL_2DCLASS_2DNAME_2DP; 
MAKE_SIMPLE_STRING(k1030,19,"No class named: ~S.");
MAKE_SIMPLE_STRING(k1031,29,"~S is not a legal class name.");
extern LP p_pcl_SETF_20PCL_20FIND_2DCLASS();
extern SYMBOL s_lsp_SET_2DGETHASH; 
extern LP p_pcl_FIND_2DWRAPPER();
extern SYMBOL s_pcl_FIND_2DCLASS; 
extern SYMBOL s_pcl_CLASS_2DWRAPPER; 
extern LP m_pcl_GATHERING1();
extern SYMBOL s_pcl__2EGATHERING1_2E; 
extern SYMBOL s_lsp_MACROLET; 
extern SYMBOL s_pcl_GATHER1; 
extern SYMBOL s_pcl_X; 
MAKE_CONS(k1035,LREF(s_pcl_X),LREF(s_lsp_NIL));
extern SYMBOL s_iterate_GATHER; 
MAKE_CONS(k1040,LREF(s_iterate_GATHER),LREF(s_lsp_NIL));
MAKE_CONS(k1039,LREF(s_lsp_QUOTE),LREF(k1040));
MAKE_CONS(k1045,LREF(s_pcl__2EGATHERING1_2E),LREF(s_lsp_NIL));
MAKE_CONS(k1044,LREF(k1045),LREF(s_lsp_NIL));
MAKE_CONS(k1043,LREF(s_lsp_QUOTE),LREF(k1044));
MAKE_CONS(k1042,LREF(k1043),LREF(s_lsp_NIL));
MAKE_CONS(k1041,LREF(s_pcl_X),LREF(k1042));
MAKE_CONS(k1038,LREF(k1039),LREF(k1041));
MAKE_CONS(k1037,LREF(s_lsp_LIST_2A),LREF(k1038));
MAKE_CONS(k1036,LREF(k1037),LREF(s_lsp_NIL));
MAKE_CONS(k1034,LREF(k1035),LREF(k1036));
MAKE_CONS(k1033,LREF(s_pcl_GATHER1),LREF(k1034));
MAKE_CONS(k1032,LREF(k1033),LREF(s_lsp_NIL));
extern SYMBOL s_iterate_GATHERING; 
extern LP m_pcl_VECTORIZING();
extern LP p_pcl_VECTORIZING_2Danon10461047();
MAKE_PROCEDURE(k1048,p_pcl_VECTORIZING_2Danon10461047);
extern SYMBOL s_key_SIZE; 
extern SYMBOL s_pcl_LIMIT; 
extern SYMBOL s_pcl_RESULT; 
extern SYMBOL s_lsp_MAKE_2DARRAY; 
MAKE_CONS(k1053,LREF(s_pcl_LIMIT),LREF(s_lsp_NIL));
MAKE_CONS(k1052,LREF(s_lsp_MAKE_2DARRAY),LREF(k1053));
MAKE_CONS(k1051,LREF(k1052),LREF(s_lsp_NIL));
MAKE_CONS(k1050,LREF(s_pcl_RESULT),LREF(k1051));
extern SYMBOL s_pcl_INDEX; 
MAKE_CONS(k1056,(LP) 0,LREF(s_lsp_NIL));
MAKE_CONS(k1055,LREF(s_pcl_INDEX),LREF(k1056));
MAKE_CONS(k1054,LREF(k1055),LREF(s_lsp_NIL));
MAKE_CONS(k1049,LREF(k1050),LREF(k1054));
extern SYMBOL s_lsp__3D; 
MAKE_CONS(k1068,LREF(s_pcl_INDEX),LREF(k1053));
MAKE_CONS(k1067,LREF(s_lsp__3D),LREF(k1068));
MAKE_SIMPLE_STRING(k1072,40,"vectorizing more elements than promised.");
MAKE_CONS(k1071,LREF(k1072),LREF(s_lsp_NIL));
MAKE_CONS(k1070,LREF(s_lsp_ERROR),LREF(k1071));
extern SYMBOL s_lsp_SVREF; 
MAKE_CONS(k1080,LREF(s_pcl_INDEX),LREF(s_lsp_NIL));
MAKE_CONS(k1079,LREF(s_pcl_RESULT),LREF(k1080));
MAKE_CONS(k1078,LREF(s_lsp_SVREF),LREF(k1079));
MAKE_CONS(k1077,LREF(k1078),LREF(k979));
MAKE_CONS(k1076,LREF(s_lsp_SETF),LREF(k1077));
extern SYMBOL s_lsp_INCF; 
MAKE_CONS(k1082,LREF(s_lsp_INCF),LREF(k1080));
MAKE_CONS(k1081,LREF(k1082),LREF(k979));
MAKE_CONS(k1075,LREF(k1076),LREF(k1081));
MAKE_CONS(k1074,LREF(s_lsp_PROGN),LREF(k1075));
MAKE_CONS(k1073,LREF(k1074),LREF(s_lsp_NIL));
MAKE_CONS(k1069,LREF(k1070),LREF(k1073));
MAKE_CONS(k1066,LREF(k1067),LREF(k1069));
MAKE_CONS(k1065,LREF(s_lsp_IF),LREF(k1066));
MAKE_CONS(k1064,LREF(k1065),LREF(s_lsp_NIL));
MAKE_CONS(k1063,LREF(k979),LREF(k1064));
MAKE_CONS(k1062,LREF(s_lsp_LAMBDA),LREF(k1063));
MAKE_CONS(k1061,LREF(k1062),LREF(s_lsp_NIL));
MAKE_CONS(k1060,LREF(s_lsp_FUNCTION),LREF(k1061));
MAKE_CONS(k1088,LREF(s_pcl_RESULT),LREF(s_lsp_NIL));
MAKE_CONS(k1087,LREF(s_lsp_NIL),LREF(k1088));
MAKE_CONS(k1086,LREF(s_lsp_LAMBDA),LREF(k1087));
MAKE_CONS(k1085,LREF(k1086),LREF(s_lsp_NIL));
MAKE_CONS(k1084,LREF(s_lsp_FUNCTION),LREF(k1085));
MAKE_CONS(k1083,LREF(k1084),LREF(s_lsp_NIL));
MAKE_CONS(k1059,LREF(k1060),LREF(k1083));
MAKE_CONS(k1058,LREF(s_lsp_VALUES),LREF(k1059));
MAKE_CONS(k1057,LREF(k1058),LREF(s_lsp_NIL));
extern LP m_pcl__2ALIST_2DELEMENTS();
extern LP p_pcl__2ALIST_2DELEMENTS_2Danon10891090();
extern SYMBOL s_key_BY; 
extern SYMBOL s_lsp_ENDP; 
MAKE_CONS(k1092,LREF(s_pcl_TAIL),LREF(s_lsp_NIL));
MAKE_CONS(k1091,LREF(s_lsp_ENDP),LREF(k1092));
extern SYMBOL s_lsp_FUNCALL; 
extern SYMBOL s_pcl_FINISH; 
MAKE_CONS(k1094,LREF(s_pcl_FINISH),LREF(s_lsp_NIL));
MAKE_CONS(k1093,LREF(s_lsp_FUNCALL),LREF(k1094));
MAKE_CONS(k1095,LREF(s_lsp_CAR),LREF(k1092));
extern SYMBOL s_lsp_PROG1; 
extern LP m_pcl__2ALIST_2DTAILS();
extern LP p_pcl__2ALIST_2DTAILS_2Danon10961097();
MAKE_CONS(k1100,LREF(k1093),LREF(k1092));
MAKE_CONS(k1099,LREF(k1091),LREF(k1100));
MAKE_CONS(k1098,LREF(s_lsp_IF),LREF(k1099));
extern LP p_pcl_MACROS_5FINIT187();
extern SYMBOL s_lsp_DEFINE_2DMACRO; 
extern SYMBOL s_pcl_RASSQ; 
extern SYMBOL s_pcl_DELQ; 
extern SYMBOL s_pcl_POSQ; 
extern SYMBOL s_pcl_NEQ; 
extern SYMBOL s_pcl_ONCE_2DONLY; 
extern SYMBOL s_lsp_KEYWORD; 
extern SYMBOL s_lsp_FIND_2DPACKAGE; 
extern SYMBOL s_key_VAR; 
extern SYMBOL s_lsp_DEFINE_2DVARIABLE; 
extern SYMBOL s_pcl_CHECK_2DMEMBER; 
extern SYMBOL s_pcl_ALIST_2DENTRY; 
extern SYMBOL s_pcl_DESTRUCTURING_2DBIND; 
extern SYMBOL s_pcl_COLLECTING_2DONCE; 
extern SYMBOL s_pcl_DOPLIST; 
extern SYMBOL s_pcl_IF_2A; 
extern SYMBOL s_pcl_PRINTING_2DRANDOM_2DTHING; 
MAKE_FLOAT(k1105,2.0);
MAKE_FLOAT(k1106,0.6);
extern SYMBOL s_lsp_MAKE_2DHASH_2DTABLE_2D1; 
extern LP p_pcl_MACROS_5FINIT187_2Danon11011102();
MAKE_PROCEDURE(k1107,p_pcl_MACROS_5FINIT187_2Danon11011102);
extern SYMBOL s_lsp_DEFINE_2DSETF; 
extern SYMBOL s_pcl_GATHERING1; 
extern SYMBOL s_pcl_VECTORIZING; 
extern SYMBOL s_pcl__2ALIST_2DELEMENTS; 
extern SYMBOL s_pcl__2ALIST_2DTAILS; 
MAKE_SIMPLE_STRING(k1108,1,"S");
MAKE_SIMPLE_STRING(k1109,1,"T");
extern LP p_pcl_MACROS_5FINIT187_2Danon11011102MACROS_5FINIT187_2Danon11031104();
MAKE_PROCEDURE(k1110,p_pcl_MACROS_5FINIT187_2Danon11011102MACROS_5FINIT187_2Danon11031104);
extern SYMBOL s_pcl_SETF_20PCL_20FIND_2DCLASS; 


extern LP add();
extern LP num_equal_p();
extern LP subtract();
extern LP lessp();
extern LP c_cons();


LP m_pcl_MEMQ(argc, v_WHOLE775_0, v_ENV776_1)
      ARGC argc;  LP v_WHOLE775_0; LP v_ENV776_1;
{
LP v_LIST_21; LP v_S790_20; LP v_X_18; 
LP v_VALUE789_17; LP v_X_15; LP v_LIST788_14; 
LP v_ITEM_13; LP v_S787_12; LP v_X_10; 
LP v_VALUE786_9; LP v_X_7; LP v_LIST785_6; 
LP v_L784_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE775_0;
v_L784_5 = ((LP) DEREF((v_WHOLE775_0) + 1 * 4));
v_LIST785_6 = v_L784_5;
v_X_7 = v_LIST785_6;
v_VALUE786_9 = ((LP) DEREF((v_LIST785_6) + 0 * 4));
v_X_10 = v_LIST785_6;
v_S787_12 = ((LP) DEREF((v_LIST785_6) + 1 * 4));
v_L784_5 = v_S787_12;
v_ITEM_13 = v_VALUE786_9;
v_LIST788_14 = v_L784_5;
v_X_15 = v_LIST788_14;
v_VALUE789_17 = ((LP) DEREF((v_LIST788_14) + 0 * 4));
v_X_18 = v_LIST788_14;
v_S790_20 = ((LP) DEREF((v_LIST788_14) + 1 * 4));
v_L784_5 = v_S790_20;
v_LIST_21 = v_VALUE789_17;
t0 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,4), LREF(s_lsp_MEMBER), v_ITEM_13, v_LIST_21, LREF(k928));
return(t0);
}

LP m_pcl_ASSQ(argc, v_WHOLE791_0, v_ENV792_1)
      ARGC argc;  LP v_WHOLE791_0; LP v_ENV792_1;
{
LP v_LIST_21; LP v_S806_20; LP v_X_18; 
LP v_VALUE805_17; LP v_X_15; LP v_LIST804_14; 
LP v_ITEM_13; LP v_S803_12; LP v_X_10; 
LP v_VALUE802_9; LP v_X_7; LP v_LIST801_6; 
LP v_L800_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE791_0;
v_L800_5 = ((LP) DEREF((v_WHOLE791_0) + 1 * 4));
v_LIST801_6 = v_L800_5;
v_X_7 = v_LIST801_6;
v_VALUE802_9 = ((LP) DEREF((v_LIST801_6) + 0 * 4));
v_X_10 = v_LIST801_6;
v_S803_12 = ((LP) DEREF((v_LIST801_6) + 1 * 4));
v_L800_5 = v_S803_12;
v_ITEM_13 = v_VALUE802_9;
v_LIST804_14 = v_L800_5;
v_X_15 = v_LIST804_14;
v_VALUE805_17 = ((LP) DEREF((v_LIST804_14) + 0 * 4));
v_X_18 = v_LIST804_14;
v_S806_20 = ((LP) DEREF((v_LIST804_14) + 1 * 4));
v_L800_5 = v_S806_20;
v_LIST_21 = v_VALUE805_17;
t0 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,4), LREF(s_lsp_ASSOC), v_ITEM_13, v_LIST_21, LREF(k928));
return(t0);
}

LP m_pcl_RASSQ(argc, v_WHOLE807_0, v_ENV808_1)
      ARGC argc;  LP v_WHOLE807_0; LP v_ENV808_1;
{
LP v_LIST_21; LP v_S822_20; LP v_X_18; 
LP v_VALUE821_17; LP v_X_15; LP v_LIST820_14; 
LP v_ITEM_13; LP v_S819_12; LP v_X_10; 
LP v_VALUE818_9; LP v_X_7; LP v_LIST817_6; 
LP v_L816_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE807_0;
v_L816_5 = ((LP) DEREF((v_WHOLE807_0) + 1 * 4));
v_LIST817_6 = v_L816_5;
v_X_7 = v_LIST817_6;
v_VALUE818_9 = ((LP) DEREF((v_LIST817_6) + 0 * 4));
v_X_10 = v_LIST817_6;
v_S819_12 = ((LP) DEREF((v_LIST817_6) + 1 * 4));
v_L816_5 = v_S819_12;
v_ITEM_13 = v_VALUE818_9;
v_LIST820_14 = v_L816_5;
v_X_15 = v_LIST820_14;
v_VALUE821_17 = ((LP) DEREF((v_LIST820_14) + 0 * 4));
v_X_18 = v_LIST820_14;
v_S822_20 = ((LP) DEREF((v_LIST820_14) + 1 * 4));
v_L816_5 = v_S822_20;
v_LIST_21 = v_VALUE821_17;
t0 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,4), LREF(s_lsp_RASSOC), v_ITEM_13, v_LIST_21, LREF(k928));
return(t0);
}

LP m_pcl_DELQ(argc, v_WHOLE823_0, v_ENV824_1)
      ARGC argc;  LP v_WHOLE823_0; LP v_ENV824_1;
{
LP v_LIST_21; LP v_S838_20; LP v_X_18; 
LP v_VALUE837_17; LP v_X_15; LP v_LIST836_14; 
LP v_ITEM_13; LP v_S835_12; LP v_X_10; 
LP v_VALUE834_9; LP v_X_7; LP v_LIST833_6; 
LP v_L832_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE823_0;
v_L832_5 = ((LP) DEREF((v_WHOLE823_0) + 1 * 4));
v_LIST833_6 = v_L832_5;
v_X_7 = v_LIST833_6;
v_VALUE834_9 = ((LP) DEREF((v_LIST833_6) + 0 * 4));
v_X_10 = v_LIST833_6;
v_S835_12 = ((LP) DEREF((v_LIST833_6) + 1 * 4));
v_L832_5 = v_S835_12;
v_ITEM_13 = v_VALUE834_9;
v_LIST836_14 = v_L832_5;
v_X_15 = v_LIST836_14;
v_VALUE837_17 = ((LP) DEREF((v_LIST836_14) + 0 * 4));
v_X_18 = v_LIST836_14;
v_S838_20 = ((LP) DEREF((v_LIST836_14) + 1 * 4));
v_L832_5 = v_S838_20;
v_LIST_21 = v_VALUE837_17;
t0 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,4), LREF(s_lsp_DELETE), v_ITEM_13, v_LIST_21, LREF(k928));
return(t0);
}

LP m_pcl_POSQ(argc, v_WHOLE839_0, v_ENV840_1)
      ARGC argc;  LP v_WHOLE839_0; LP v_ENV840_1;
{
LP v_LIST_21; LP v_S854_20; LP v_X_18; 
LP v_VALUE853_17; LP v_X_15; LP v_LIST852_14; 
LP v_ITEM_13; LP v_S851_12; LP v_X_10; 
LP v_VALUE850_9; LP v_X_7; LP v_LIST849_6; 
LP v_L848_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE839_0;
v_L848_5 = ((LP) DEREF((v_WHOLE839_0) + 1 * 4));
v_LIST849_6 = v_L848_5;
v_X_7 = v_LIST849_6;
v_VALUE850_9 = ((LP) DEREF((v_LIST849_6) + 0 * 4));
v_X_10 = v_LIST849_6;
v_S851_12 = ((LP) DEREF((v_LIST849_6) + 1 * 4));
v_L848_5 = v_S851_12;
v_ITEM_13 = v_VALUE850_9;
v_LIST852_14 = v_L848_5;
v_X_15 = v_LIST852_14;
v_VALUE853_17 = ((LP) DEREF((v_LIST852_14) + 0 * 4));
v_X_18 = v_LIST852_14;
v_S854_20 = ((LP) DEREF((v_LIST852_14) + 1 * 4));
v_L848_5 = v_S854_20;
v_LIST_21 = v_VALUE853_17;
t0 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,4), LREF(s_lsp_POSITION), v_ITEM_13, v_LIST_21, LREF(k928));
return(t0);
}

LP m_pcl_NEQ(argc, v_WHOLE855_0, v_ENV856_1)
      ARGC argc;  LP v_WHOLE855_0; LP v_ENV856_1;
{
LP v_Y_35; LP v_X_34; LP v_Y_32; 
LP v_X_31; LP v_Y_29; LP v_X_28; 
LP v_Y_26; LP v_X_25; LP v_Y_23; 
LP v_X_22; LP v_Y_21; LP v_S870_20; 
LP v_X_18; LP v_VALUE869_17; LP v_X_15; 
LP v_LIST868_14; LP v_X_13; LP v_S867_12; 
LP v_X_10; LP v_VALUE866_9; LP v_X_7; 
LP v_LIST865_6; LP v_L864_5; LP v_X_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE855_0;
v_L864_5 = ((LP) DEREF((v_WHOLE855_0) + 1 * 4));
v_LIST865_6 = v_L864_5;
v_X_7 = v_LIST865_6;
v_VALUE866_9 = ((LP) DEREF((v_LIST865_6) + 0 * 4));
v_X_10 = v_LIST865_6;
v_S867_12 = ((LP) DEREF((v_LIST865_6) + 1 * 4));
v_L864_5 = v_S867_12;
v_X_13 = v_VALUE866_9;
v_LIST868_14 = v_L864_5;
v_X_15 = v_LIST868_14;
v_VALUE869_17 = ((LP) DEREF((v_LIST868_14) + 0 * 4));
v_X_18 = v_LIST868_14;
v_S870_20 = ((LP) DEREF((v_LIST868_14) + 1 * 4));
v_L864_5 = v_S870_20;
v_Y_21 = v_VALUE869_17;
v_X_22 = v_Y_21;
v_Y_23 = LREF(s_lsp_NIL);
v_Y_26 = (c_cons((v_Y_21), (LREF(s_lsp_NIL))));
v_Y_29 = (c_cons((v_X_13), (v_Y_26)));
v_X_31 = (c_cons((LREF(s_lsp_EQ)), (v_Y_29)));
v_Y_35 = (c_cons((v_X_31), (LREF(s_lsp_NIL))));
t0 = (c_cons((LREF(s_lsp_NOT)), (v_Y_35)));
return(t0);
}

LP p_pcl_MAKE_2DCAXR(argc, v_N_0, v_FORM_1)
      ARGC argc;  LP v_N_0; LP v_FORM_1;
{
LP v_Y_13; LP v_X_12; LP v_Y_10; 
LP v_X_9; LP v_Y_7; LP v_X_6; 
LP v_Y_4; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; 
if (argc != 2) wna(argc,2);
START932:
t1 = (lessp((v_N_0), ((LP) 8)));
if (t1 != NIL) {
v_X_6 = ICALL(s_lsp_NTH) (2, v_N_0, LREF(k933));
v_X_3 = v_FORM_1;
v_Y_4 = LREF(s_lsp_NIL);
v_Y_7 = (c_cons((v_FORM_1), (LREF(s_lsp_NIL))));
t0 = (c_cons((v_X_6), (v_Y_7)));
return(t0);
} else {
t2 = (subtract((v_N_0), ((LP) 8)));
v_X_9 = v_FORM_1;
v_Y_10 = LREF(s_lsp_NIL);
v_Y_13 = (c_cons((v_FORM_1), (LREF(s_lsp_NIL))));
t3 = (c_cons((LREF(s_lsp_CDDDDR)), (v_Y_13)));
v_N_0 = t2; v_FORM_1 = t3; 
goto START932;
}
}

LP p_pcl_MAKE_2DCDXR(argc, v_N_0, v_FORM_1)
      ARGC argc;  LP v_N_0; LP v_FORM_1;
{
LP v_N_15; LP v_Y_13; LP v_X_12; 
LP v_Y_10; LP v_X_9; LP v_Y_7; 
LP v_X_6; LP v_Y_4; LP v_X_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; 
if (argc != 2) wna(argc,2);
START937:
v_N_15 = v_N_0;
t1 = (num_equal_p((v_N_0), ((LP) 0)));
if (t1 != NIL) {
return(v_FORM_1);
} else {
t2 = (lessp((v_N_0), ((LP) 10)));
if (t2 != NIL) {
v_X_6 = ICALL(s_lsp_NTH) (2, v_N_0, LREF(k938));
v_X_3 = v_FORM_1;
v_Y_4 = LREF(s_lsp_NIL);
v_Y_7 = (c_cons((v_FORM_1), (LREF(s_lsp_NIL))));
t0 = (c_cons((v_X_6), (v_Y_7)));
return(t0);
} else {
t3 = (subtract((v_N_0), ((LP) 8)));
v_X_9 = v_FORM_1;
v_Y_10 = LREF(s_lsp_NIL);
v_Y_13 = (c_cons((v_FORM_1), (LREF(s_lsp_NIL))));
t4 = (c_cons((LREF(s_lsp_CDDDDR)), (v_Y_13)));
v_N_0 = t3; v_FORM_1 = t4; 
goto START937;
}
}
}

LP p_pcl_TRUE(va_alist) va_dcl
{
LP v_IGNORE_0; 
LP t0; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTIFY(v_IGNORE_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
return(LREF(s_lsp_T));
}

LP p_pcl_FALSE(va_alist) va_dcl
{
LP v_IGNORE_0; 
LP t0; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTIFY(v_IGNORE_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
return(LREF(s_lsp_NIL));
}

LP p_pcl_ZERO(va_alist) va_dcl
{
LP v_IGNORE_0; 
LP t0; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTIFY(v_IGNORE_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
return((LP) 0);
}

LP p_pcl_MAKE_2DPLIST(argc, v_KEYS_0, v_VALS_1)
      ARGC argc;  LP v_KEYS_0; LP v_VALS_1;
{
LP v_X_9; LP v_X_7; LP v_X_5; 
LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; 
if (argc != 2) wna(argc,2);
if (v_VALS_1 != NIL) {
v_X_3 = v_KEYS_0;
t1 = ((LP) DEREF((v_KEYS_0) + 0 * 4));
v_X_5 = v_VALS_1;
t2 = ((LP) DEREF((v_VALS_1) + 0 * 4));
v_X_7 = v_KEYS_0;
t4 = ((LP) DEREF((v_KEYS_0) + 1 * 4));
v_X_9 = v_VALS_1;
t5 = ((LP) DEREF((v_VALS_1) + 1 * 4));
t3 = ICALL(s_pcl_MAKE_2DPLIST) (2, t4, t5);
t0 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,3), t1, t2, t3);
return(t0);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_pcl_REMTAIL(argc, v_LIST_0, v_TAIL_1)
      ARGC argc;  LP v_LIST_0; LP v_TAIL_1;
{
LP v_Y_11; LP v_X_10; LP v_Y_8; 
LP v_X_7; LP v_X_5; LP v_X_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 

if (argc != 2) wna(argc,2);
v_X_10 = v_LIST_0;
v_Y_11 = v_TAIL_1;
if (((v_LIST_0) == (v_TAIL_1))) {
return(LREF(s_lsp_NIL));
} else {
v_X_3 = v_LIST_0;
v_X_7 = ((LP) DEREF((v_LIST_0) + 0 * 4));
v_X_5 = v_LIST_0;
t2 = ((LP) DEREF((v_LIST_0) + 1 * 4));
v_Y_8 = ICALL(s_pcl_REMTAIL) (2, t2, v_TAIL_1);
t0 = (c_cons((v_X_7), (v_Y_8)));
return(t0);
}
}

LP m_pcl_ONCE_2DONLY(argc, v_WHOLE871_0, v_ENV872_1)
      ARGC argc;  LP v_WHOLE871_0; LP v_ENV872_1;
{
LP v_Y_168; LP v_X_167; LP v_Y_165; 
LP v_X_164; LP v_Y_162; LP v_X_161; 
LP v_Y_159; LP v_X_158; LP v_Y_156; 
LP v_X_155; LP v_Y_153; LP v_X_152; 
LP v_Y_150; LP v_X_149; LP v_Y_147; 
LP v_X_146; LP v_Y_144; LP v_X_143; 
LP v_Y_141; LP v_X_140; LP v_Y_138; 
LP v_X_137; LP v_Y_135; LP v_X_134; 
LP v_X_132; LP v_V_130; LP v_X_129; 
LP v_NEW_2DCDR_127; LP v_C_126; LP v_Y_124; 
LP v_X_123; LP v_Y_121; LP v_X_120; 
LP v_Y_118; LP v_X_117; LP v_X_115; 
LP v_X_113; LP v_X_111; LP v_X_109; 
LP v_LOOPVAR_2D165_105; LP v_LOOPVAR_2D164_104; LP v_LOOPVAR_2D163_103; 
LP v_LOOP_2DLIST_2D162_102; LP v_L886_101; LP v_LOOP_2DLIST_2D161_100; 
LP v_L885_99; LP v_S884_98; LP v_Y_96; 
LP v_X_95; LP v_VALUE883_94; LP v_Y_92; 
LP v_X_91; LP v_Y_89; LP v_X_88; 
LP v_Y_86; LP v_X_85; LP v_Y_83; 
LP v_X_82; LP v_Y_80; LP v_X_79; 
LP v_Y_77; LP v_X_76; LP v_Y_74; 
LP v_X_73; LP v_Y_71; LP v_X_70; 
LP v_Y_68; LP v_X_67; LP v_Y_65; 
LP v_X_64; LP v_Y_62; LP v_X_61; 
LP v_Y_59; LP v_X_58; LP v_Y_56; 
LP v_X_55; LP v_Y_53; LP v_X_52; 
LP v_Y_50; LP v_X_49; LP v_Y_47; 
LP v_X_46; LP v_Y_44; LP v_X_43; 
LP v_Y_41; LP v_X_40; LP v_Y_38; 
LP v_X_37; LP v_X_35; LP v_X_33; 
LP v_LOOP_2DLIST_2D160_29; LP v_VAR_28; LP v_EXPAND_2DTIME_2DVAL_2DFORMS_27; 
LP v_RUN_2DTIME_2DVALS_26; LP v_RUN_2DTIME_2DVARS_25; LP v_GENSYM_2DVAR_24; 
LP v_X_22; LP v_X_21; LP v_X_19; 
LP v_X_18; LP v_X_16; LP v_X_15; 
LP v_BODY_14; LP v_VARS_13; LP v_S882_12; 
LP v_X_10; LP v_VALUE881_9; LP v_X_7; 
LP v_LIST880_6; LP v_L879_5; LP v_X_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; LP t145; LP t146; LP t147; LP t148; LP t149; 
LP t150; LP t151; LP t152; LP t153; LP t154; LP t155; 
LP t156; LP t157; LP t158; LP t159; LP t160; LP t161; 
LP t162; LP t163; LP t164; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE871_0;
v_L879_5 = ((LP) DEREF((v_WHOLE871_0) + 1 * 4));
v_LIST880_6 = v_L879_5;
v_X_7 = v_LIST880_6;
v_VALUE881_9 = ((LP) DEREF((v_LIST880_6) + 0 * 4));
v_X_10 = v_LIST880_6;
v_S882_12 = ((LP) DEREF((v_LIST880_6) + 1 * 4));
v_L879_5 = v_S882_12;
v_VARS_13 = v_VALUE881_9;
v_BODY_14 = v_L879_5;
v_X_16 = LREF(s_lsp_NIL);
v_GENSYM_2DVAR_24 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(s_lsp_NIL));
v_X_19 = LREF(s_lsp_NIL);
v_RUN_2DTIME_2DVARS_25 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(s_lsp_NIL));
v_X_22 = LREF(s_lsp_NIL);
v_RUN_2DTIME_2DVALS_26 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(s_lsp_NIL));
v_EXPAND_2DTIME_2DVAL_2DFORMS_27 = LREF(s_lsp_NIL);
v_VAR_28 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D160_29 = v_VARS_13;
t_NEXT_2DLOOP_31:;
if (v_LOOP_2DLIST_2D160_29 == NIL) {
goto t_END_2DLOOP_32;
}
v_X_33 = v_LOOP_2DLIST_2D160_29;
v_VAR_28 = ((LP) DEREF((v_X_33) + 0 * 4));
v_X_35 = v_LOOP_2DLIST_2D160_29;
v_LOOP_2DLIST_2D160_29 = ((LP) DEREF((v_X_35) + 1 * 4));
v_X_37 = v_VAR_28;
v_Y_41 = (c_cons((v_X_37), (LREF(s_lsp_NIL))));
t1 = (c_cons((LREF(s_lsp_SYMBOLP)), (v_Y_41)));
v_X_43 = v_VAR_28;
v_Y_47 = (c_cons((v_X_43), (LREF(s_lsp_NIL))));
t2 = (c_cons((LREF(s_lsp_NUMBERP)), (v_Y_47)));
v_X_49 = v_VAR_28;
v_Y_53 = (c_cons((v_X_49), (LREF(s_lsp_NIL))));
v_X_64 = (c_cons((LREF(s_lsp_LISTP)), (v_Y_53)));
v_X_55 = v_VAR_28;
v_Y_59 = (c_cons((v_X_55), (LREF(s_lsp_NIL))));
t3 = (c_cons((LREF(s_lsp_CAR)), (v_Y_59)));
v_X_61 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_MEMBER), t3, LREF(k943));
v_Y_65 = (c_cons((v_X_61), (LREF(s_lsp_NIL))));
v_Y_68 = (c_cons((v_X_64), (v_Y_65)));
t4 = (c_cons((LREF(s_lsp_AND)), (v_Y_68)));
t0 = ICALL(s_lsp_LIST) (4, LREF(s_lsp_OR), t1, t2, t4);
v_X_70 = v_GENSYM_2DVAR_24;
v_Y_71 = LREF(k948);
v_X_73 = (c_cons((v_GENSYM_2DVAR_24), (LREF(k948))));
t6 = (c_cons((v_X_73), (LREF(s_lsp_NIL))));
v_X_76 = v_RUN_2DTIME_2DVARS_25;
v_Y_77 = LREF(s_lsp_NIL);
v_Y_80 = (c_cons((v_RUN_2DTIME_2DVARS_25), (LREF(s_lsp_NIL))));
v_Y_83 = (c_cons((v_GENSYM_2DVAR_24), (v_Y_80)));
t7 = (c_cons((LREF(s_lsp_PUSH)), (v_Y_83)));
v_X_88 = v_VAR_28;
v_X_85 = v_RUN_2DTIME_2DVALS_26;
v_Y_86 = LREF(s_lsp_NIL);
v_Y_89 = (c_cons((v_RUN_2DTIME_2DVALS_26), (LREF(s_lsp_NIL))));
v_Y_92 = (c_cons((v_X_88), (v_Y_89)));
t8 = (c_cons((LREF(s_lsp_PUSH)), (v_Y_92)));
t5 = ICALL(s_lsp_LIST) (5, LREF(s_lsp_LET), t6, t7, t8, v_GENSYM_2DVAR_24);
v_VALUE883_94 = ICALL(s_lsp_LIST) (4, LREF(s_lsp_IF), t0, v_VAR_28, t5);
v_Y_96 = v_EXPAND_2DTIME_2DVAL_2DFORMS_27;
v_S884_98 = (c_cons((v_VALUE883_94), (v_Y_96)));
v_EXPAND_2DTIME_2DVAL_2DFORMS_27 = v_S884_98;
goto t_NEXT_2DLOOP_31;
goto t_END_2DLOOP_32;
t_END_2DLOOP_32:;
goto b_NIL_30;
b_NIL_30:;
v_L885_99 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D161_100 = v_VARS_13;
v_L886_101 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D162_102 = ICALL(s_lsp_REVERSE) (1, v_EXPAND_2DTIME_2DVAL_2DFORMS_27);
v_LOOPVAR_2D163_103 = LREF(s_lsp_NIL);
v_LOOPVAR_2D164_104 = LREF(s_lsp_NIL);
v_LOOPVAR_2D165_105 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_107:;
if (v_LOOP_2DLIST_2D161_100 == NIL) {
goto t_END_2DLOOP_108;
}
v_X_109 = v_LOOP_2DLIST_2D161_100;
v_L885_99 = ((LP) DEREF((v_X_109) + 0 * 4));
v_X_111 = v_LOOP_2DLIST_2D161_100;
v_LOOP_2DLIST_2D161_100 = ((LP) DEREF((v_X_111) + 1 * 4));
if (v_LOOP_2DLIST_2D162_102 == NIL) {
goto t_END_2DLOOP_108;
}
v_X_113 = v_LOOP_2DLIST_2D162_102;
v_L886_101 = ((LP) DEREF((v_X_113) + 0 * 4));
v_X_115 = v_LOOP_2DLIST_2D162_102;
v_LOOP_2DLIST_2D162_102 = ((LP) DEREF((v_X_115) + 1 * 4));
v_X_120 = v_L885_99;
v_X_117 = v_L886_101;
v_Y_121 = (c_cons((v_X_117), (LREF(s_lsp_NIL))));
v_X_123 = (c_cons((v_X_120), (v_Y_121)));
v_LOOPVAR_2D165_105 = (c_cons((v_X_123), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D164_104 != NIL) {
v_C_126 = v_LOOPVAR_2D164_104;
v_NEW_2DCDR_127 = v_LOOPVAR_2D165_105;
v_V_130 = v_NEW_2DCDR_127;
((LP) (DEREF((v_C_126) + 1 * 4) = (LD) (v_V_130)));
v_X_132 = v_C_126;
v_LOOPVAR_2D164_104 = ((LP) DEREF((v_X_132) + 1 * 4));
} else {
v_LOOPVAR_2D163_103 = v_LOOPVAR_2D165_105;
v_LOOPVAR_2D164_104 = v_LOOPVAR_2D163_103;
}
goto t_NEXT_2DLOOP_107;
goto t_END_2DLOOP_108;
t_END_2DLOOP_108:;
t9 = v_LOOPVAR_2D163_103;
goto b_NIL_106;
t9 = NIL;
b_NIL_106:;
v_X_134 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_LET), t9, v_BODY_14);
v_Y_138 = (c_cons((v_X_134), (LREF(s_lsp_NIL))));
v_X_140 = (c_cons((LREF(s_pcl_WRAPPED_2DBODY)), (v_Y_138)));
v_Y_144 = (c_cons((v_X_140), (LREF(s_lsp_NIL))));
v_Y_147 = (c_cons((v_RUN_2DTIME_2DVALS_26), (v_Y_144)));
v_X_164 = (c_cons((v_RUN_2DTIME_2DVARS_25), (v_Y_147)));
v_X_149 = v_RUN_2DTIME_2DVARS_25;
v_Y_150 = LREF(s_lsp_NIL);
v_Y_153 = (c_cons((v_RUN_2DTIME_2DVARS_25), (LREF(s_lsp_NIL))));
t11 = (c_cons((LREF(s_lsp_REVERSE)), (v_Y_153)));
v_X_155 = v_RUN_2DTIME_2DVALS_26;
v_Y_156 = LREF(s_lsp_NIL);
v_Y_159 = (c_cons((v_RUN_2DTIME_2DVALS_26), (LREF(s_lsp_NIL))));
t12 = (c_cons((LREF(s_lsp_REVERSE)), (v_Y_159)));
t10 = ICALL(s_lsp_LIST) (4, LREF(s_lsp_MAPCAR), LREF(k952), t11, t12);
v_X_161 = ICALL(s_lsp_LIST_2A) (4, LREF(s_lsp_LIST), LREF(k950), t10, LREF(k954));
v_Y_165 = (c_cons((v_X_161), (LREF(s_lsp_NIL))));
v_Y_168 = (c_cons((v_X_164), (v_Y_165)));
t13 = (c_cons((LREF(s_lsp_LET_2A)), (v_Y_168)));
return(t13);
}

LP p_pcl_EXTRACT_2DDECLARATIONS(va_alist) va_dcl
{
LP v_Y_80; LP v_X_79; LP v_Y_77; 
LP v_X_76; LP v_X_74; LP v_G905_73; 
LP v_Y_71; LP v_X_70; LP v_X_68; 
LP v_X_66; LP v_Y_64; LP v_X_63; 
LP v_X_61; LP v_G904_60; LP v_Y_58; 
LP v_X_57; LP v_X_55; LP v_Y_53; 
LP v_X_52; LP v_MACROP_51; LP v_NEWFORM_50; 
LP v_S903_45; LP v_Y_43; LP v_X_42; 
LP v_VALUE902_41; LP v_X_39; LP v_X_37; 
LP v_LOOP_2DLIST_2D167_33; LP v_DECLARATION_32; LP v_X_30; 
LP v_S901_29; LP v_X_27; LP v_VALUE900_26; 
LP v_X_24; LP v_LIST899_23; LP v_X_21; 
LP v_X_15; LP v_X_13; LP v_S898_12; 
LP v_X_10; LP v_VALUE897_9; LP v_X_7; 
LP v_LIST896_6; LP v_FORM_5; LP v_DECLARATIONS_4; 
LP v_DOCUMENTATION_3; LP v_BODY_0; LP v_ENVIRONMENT_1; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_BODY_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_ENVIRONMENT_1 = NIL;
} else {
v_ENVIRONMENT_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
v_DOCUMENTATION_3 = LREF(s_lsp_NIL);
v_DECLARATIONS_4 = LREF(s_lsp_NIL);
v_FORM_5 = LREF(s_lsp_NIL);
v_X_15 = v_BODY_0;
t2 = ((LP) DEREF((v_X_15) + 0 * 4));
t1 = ICALL(s_lsp_STRINGP) (1, t2);
if (t1 != NIL) {
v_X_13 = v_BODY_0;
t0 = ((LP) DEREF((v_X_13) + 1 * 4));
} else {
t0 = LREF(s_lsp_NIL);
}
if (t0 != NIL) {
v_LIST896_6 = v_BODY_0;
v_X_7 = v_LIST896_6;
v_VALUE897_9 = ((LP) DEREF((v_LIST896_6) + 0 * 4));
v_X_10 = v_LIST896_6;
v_S898_12 = ((LP) DEREF((v_LIST896_6) + 1 * 4));
v_BODY_0 = v_S898_12;
v_DOCUMENTATION_3 = v_VALUE897_9;
}
t_NEXT_2DLOOP_19:;
if (v_BODY_0 == NIL) {
goto b_OUTER_17;
}
v_X_21 = v_BODY_0;
v_FORM_5 = ((LP) DEREF((v_X_21) + 0 * 4));
t_NEXT_2DLOOP_48:;
v_X_66 = v_FORM_5;
v_X_68 = v_X_66;
v_X_70 = v_X_66;
v_Y_71 = LREF(s_lsp_NIL);
v_G905_73 = (((v_X_66) == (LREF(s_lsp_NIL))) ? T : NIL);
if (v_G905_73 != NIL) {
t4 = v_G905_73;
} else {
v_X_74 = v_X_66;
t4 = (OTHER_PTRP((v_X_66)) && (TAG((v_X_66)) == 15) ? T : NIL);
}
if (t4 != NIL) {
v_X_61 = v_FORM_5;
v_X_63 = ((LP) DEREF((v_X_61) + 0 * 4));
if (((v_X_63) == (LREF(s_lsp_DECLARE)))) {
t3 = LREF(s_lsp_T);
goto b_INNER_46;
} else {
{
int real_argc;
BEGIN_MV_CALL(mv_holder955,0);
t6 = ICALL(s_lsp_MACROEXPAND_2D1) (MV_CALL(mv_holder955,2), v_FORM_5, v_ENVIRONMENT_1);
SET_MV_RETURN_VALUE(mv_holder955,0,t6);
if SV_RETURN_P(mv_holder955) SET_MV_RETURN_COUNT(mv_holder955,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder955);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_NEWFORM_50 = NIL;
} else {
v_NEWFORM_50 = NEXT_VAR_VALUE(mv_holder955);
}
if (real_argc < 2) {
v_MACROP_51 = NIL;
} else {
v_MACROP_51 = NEXT_VAR_VALUE(mv_holder955);
}
END_VAR_VALUES;
END_MV_CALL;
v_Y_53 = v_FORM_5;
v_X_55 = (((v_NEWFORM_50) == (v_Y_53)) ? T : NIL);
v_X_57 = v_X_55;
v_Y_58 = LREF(s_lsp_NIL);
v_G904_60 = (((v_X_55) == (LREF(s_lsp_NIL))) ? T : NIL);
if (v_G904_60 != NIL) {
t7 = v_G904_60;
} else {
t7 = v_MACROP_51;
}
if (t7 != NIL) {
v_FORM_5 = v_NEWFORM_50;
} else {
goto b_OUTER_17;
}
}
}
} else {
goto b_OUTER_17;
}
goto t_NEXT_2DLOOP_48;
goto t_END_2DLOOP_49;
t_END_2DLOOP_49:;
t3 = NIL;
b_INNER_46:;
if (t3 != NIL) {
v_LIST899_23 = v_BODY_0;
v_X_24 = v_LIST899_23;
v_VALUE900_26 = ((LP) DEREF((v_LIST899_23) + 0 * 4));
v_X_27 = v_LIST899_23;
v_S901_29 = ((LP) DEREF((v_LIST899_23) + 1 * 4));
v_BODY_0 = v_S901_29;
v_DECLARATION_32 = LREF(s_lsp_NIL);
v_X_30 = v_FORM_5;
v_LOOP_2DLIST_2D167_33 = ((LP) DEREF((v_X_30) + 1 * 4));
t_NEXT_2DLOOP_35:;
if (v_LOOP_2DLIST_2D167_33 == NIL) {
goto t_END_2DLOOP_36;
}
v_X_37 = v_LOOP_2DLIST_2D167_33;
v_DECLARATION_32 = ((LP) DEREF((v_X_37) + 0 * 4));
v_X_39 = v_LOOP_2DLIST_2D167_33;
v_LOOP_2DLIST_2D167_33 = ((LP) DEREF((v_X_39) + 1 * 4));
v_VALUE902_41 = v_DECLARATION_32;
v_Y_43 = v_DECLARATIONS_4;
v_S903_45 = (c_cons((v_VALUE902_41), (v_Y_43)));
v_DECLARATIONS_4 = v_S903_45;
goto t_NEXT_2DLOOP_35;
goto t_END_2DLOOP_36;
t_END_2DLOOP_36:;
goto b_NIL_34;
b_NIL_34:;
}
goto t_NEXT_2DLOOP_19;
goto t_END_2DLOOP_20;
t_END_2DLOOP_20:;
b_OUTER_17:;
if (v_DECLARATIONS_4 != NIL) {
v_Y_77 = ICALL(s_lsp_NREVERSE) (1, v_DECLARATIONS_4);
v_X_79 = (c_cons((LREF(s_lsp_DECLARE)), (v_Y_77)));
t8 = (c_cons((v_X_79), (LREF(s_lsp_NIL))));
} else {
t8 = LREF(s_lsp_NIL);
}
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,3);
SET_MV_RETURN_VALUE(argc,1,t8);
SET_MV_RETURN_VALUE(argc,2,v_BODY_0);
}
return(v_DOCUMENTATION_3);
}

LP p_pcl_MAKE_2DKEYWORD(argc, v_SYMBOL_0)
      ARGC argc;  LP v_SYMBOL_0;
{
LP v_P_11; LP v_NAME_10; LP v_SYMBOL_8; 
LP v_X_6; LP v_NAME_2; LP v_SYMBOL_4; 
LP v_P_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; 
if (argc != 1) wna(argc,1);
v_X_6 = v_SYMBOL_0;
v_NAME_10 = ((LP) DEREF((v_SYMBOL_0) + 7 * 4));
v_SYMBOL_8 = LREF(s_pcl__2AKEYWORD_2DPACKAGE_2A);
v_P_11 = ((LP) DEREF((LREF(s_pcl__2AKEYWORD_2DPACKAGE_2A)) + 0 * 4));
t1 = ICALL(s_lsp_COERCE_2DTO_2DPACKAGE) (1, v_P_11);
t0 = ICALL(s_lsp_INTERN_2F2) (MV_CALL(argc,2), v_NAME_10, t1);
return(t0);
}

LP p_pcl_STRING_2DAPPEND(va_alist) va_dcl
{
LP v_V_17; LP v_X_16; LP v_NEW_2DCAR_14; 
LP v_C_13; LP v_X_11; LP v_X_9; 
LP v_TMP911_8; LP v_X_6; LP v_STRING_2DLOC_3; 
LP v_STRINGS_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTIFY(v_STRINGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_STRINGS_0 = ICALL(s_lsp_COPY_2DLIST) (1, v_STRINGS_0);
v_STRING_2DLOC_3 = v_STRINGS_0;
goto t_TEST909_5;
t_LOOP910_4:;
v_X_6 = v_STRING_2DLOC_3;
v_TMP911_8 = ((LP) DEREF((v_X_6) + 1 * 4));
v_STRING_2DLOC_3 = v_TMP911_8;
t_TEST909_5:;
if (v_STRING_2DLOC_3 == NIL) {
v_X_9 = LREF(s_lsp_CONCATENATE);
t2 = ((LP) DEREF((LREF(s_lsp_CONCATENATE)) + 4 * 4));
t1 = p_lsp_APPLY(MV_CALL(argc,3), COERCE_TO_FUNCTION(t2), LREF(s_lsp_STRING), v_STRINGS_0);
return(t1);
return(NIL);
}
v_C_13 = v_STRING_2DLOC_3;
v_X_11 = v_STRING_2DLOC_3;
t3 = ((LP) DEREF((v_X_11) + 0 * 4));
v_NEW_2DCAR_14 = ICALL(s_lsp_STRING) (1, t3);
v_V_17 = v_NEW_2DCAR_14;
((LP) (DEREF((v_C_13) + 0 * 4) = (LD) (v_V_17)));
goto t_LOOP910_4;
return(NIL);
}

LP p_pcl_SYMBOL_2DAPPEND(va_alist) va_dcl
{
LP v_P_11; LP v_NAME_10; LP v_NAME_6; 
LP v_SYMBOL_8; LP v_P_7; LP v_SYM2_1; 
LP v_SYM1_0; LP v_SYMBOL_3; LP v_PACKAGE_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_SYM1_0 = NEXT_VAR_ARG;
v_SYM2_1 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 2) wna_low(real_argc,2);
if (real_argc > 3) wna_high(real_argc,3);
if (real_argc < 3) {
v_SYMBOL_3 = LREF(s_lsp__2APACKAGE_2A);
t0 = ((LP) DEREF((v_SYMBOL_3) + 0 * 4));
v_PACKAGE_2 = t0;
} else {
v_PACKAGE_2 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
v_NAME_10 = ICALL(s_pcl_STRING_2DAPPEND) (2, v_SYM1_0, v_SYM2_1);
t2 = ICALL(s_lsp_COERCE_2DTO_2DPACKAGE) (1, v_PACKAGE_2);
t1 = ICALL(s_lsp_INTERN_2F2) (MV_CALL(argc,2), v_NAME_10, t2);
return(t1);
}

LP m_pcl_CHECK_2DMEMBER(argc, v_WHOLE912_0, v_ENV913_1)
      ARGC argc;  LP v_WHOLE912_0; LP v_ENV913_1;
{
LP v_LIST_21; LP v_S942_20; LP v_X_18; 
LP v_VALUE941_17; LP v_X_15; LP v_LIST940_14; 
LP v_PLACE_13; LP v_S939_12; LP v_X_10; 
LP v_VALUE938_9; LP v_X_7; LP v_LIST937_6; 
LP v_L936_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; 
if (argc != 2) wna(argc,2);
t0 = NEW_OE(2);
v_X_3 = v_WHOLE912_0;
v_L936_5 = ((LP) DEREF((v_WHOLE912_0) + 1 * 4));
v_LIST937_6 = v_L936_5;
v_X_7 = v_LIST937_6;
v_VALUE938_9 = ((LP) DEREF((v_LIST937_6) + 0 * 4));
v_X_10 = v_LIST937_6;
v_S939_12 = ((LP) DEREF((v_LIST937_6) + 1 * 4));
v_L936_5 = v_S939_12;
v_PLACE_13 = v_VALUE938_9;
SET_OE_SLOT(t0,1,v_PLACE_13);
v_LIST940_14 = v_L936_5;
v_X_15 = v_LIST940_14;
v_VALUE941_17 = ((LP) DEREF((v_LIST940_14) + 0 * 4));
v_X_18 = v_LIST940_14;
v_S942_20 = ((LP) DEREF((v_LIST940_14) + 1 * 4));
v_L936_5 = v_S942_20;
v_LIST_21 = v_VALUE941_17;
SET_OE_SLOT(t0,0,v_LIST_21);
t2 = MAKE_CLOSURE(p_pcl_CHECK_2DMEMBER_2Danon956957,t0);
t1 = p_lsp_APPLY(MV_CALL(argc,2), COERCE_TO_FUNCTION(t2), v_L936_5);
return(t1);
}

LP p_pcl_CHECK_2DMEMBER_2Danon956957(va_alist) va_dcl
{
LP v_Y_131; LP v_X_130; LP v_Y_128; 
LP v_X_127; LP v_Y_125; LP v_X_124; 
LP v_X_122; LP v_V_120; LP v_X_119; 
LP v_NEW_2DCDR_117; LP v_C_116; LP v_Y_114; 
LP v_X_113; LP v_Y_111; LP v_X_110; 
LP v_Y_108; LP v_X_107; LP v_X_105; 
LP v_X_103; LP v_X_101; LP v_X_99; 
LP v_LOOPVAR_2D172_95; LP v_LOOPVAR_2D171_94; LP v_LOOPVAR_2D170_93; 
LP v_LOOP_2DLIST_2D169_92; LP v_L962_91; LP v_LOOP_2DLIST_2D168_90; 
LP v_L961_89; LP v_WRAPPED_2DBODY_88; LP v_Y_86; 
LP v_X_85; LP v_Y_83; LP v_X_82; 
LP v_Y_80; LP v_X_79; LP v_Y_77; 
LP v_X_76; LP v_Y_74; LP v_X_73; 
LP v_LIST_72; LP v_PLACE_71; LP v_X_69; 
LP v_G960_68; LP v_Y_66; LP v_X_65; 
LP v_X_63; LP v_X_61; LP v_X_59; 
LP v_G959_58; LP v_X_56; LP v_G958_55; 
LP v_S_53; LP v_S957_52; LP v_Y_50; 
LP v_X_49; LP v_VALUE956_48; LP v_S955_47; 
LP v_Y_45; LP v_X_44; LP v_VALUE954_43; 
LP v_KEYS944_42; LP v_X_40; LP v_X_39; 
LP v_X_37; LP v_G953_36; LP v_Y_34; 
LP v_X_33; LP v_X_31; LP v_X_29; 
LP v_X_27; LP v_G952_26; LP v_X_24; 
LP v_G951_23; LP v_S_21; LP v_S950_20; 
LP v_Y_18; LP v_X_17; LP v_VALUE949_16; 
LP v_S948_15; LP v_Y_13; LP v_X_12; 
LP v_VALUE947_11; LP v_KEYS944_10; LP v_X_8; 
LP v_X_7; LP v_KEYS946_6; LP v_KEYS945_5; 
LP v_KEYS943_4; LP v_PRETTY_2DNAME_3; LP v_X_1; 
LP v_TEST_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


t0 = OE;
real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
DYNAMIC_RESTIFY(v_KEYS943_4,1,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_TEST_0,LREF(s_key_TEST),v_KEYS943_4)
v_X_1 = LREF(s_lsp_EQL);
t1 = ((LP) DEREF((v_X_1) + 4 * 4));
v_TEST_0 = t1;
END_KEY_INIT
BEGIN_KEY_INIT(v_PRETTY_2DNAME_3,LREF(s_key_PRETTY_2DNAME),v_KEYS943_4)
v_PRETTY_2DNAME_3 = GET_OE_SLOT(t0,1);
END_KEY_INIT
END_VAR_ARGS;
v_KEYS945_5 = LREF(s_lsp_NIL);
v_KEYS946_6 = LREF(s_lsp_NIL);
v_S_21 = GET_OE_SLOT(t0,1);
v_G951_23 = (OTHER_PTRP((GET_OE_SLOT(t0,1))) && (TAG((GET_OE_SLOT(t0,1))) == 3) ? T : NIL);
if (v_G951_23 != NIL) {
t2 = v_G951_23;
} else {
v_X_24 = GET_OE_SLOT(t0,1);
v_G952_26 = ((FIXNUMP((GET_OE_SLOT(t0,1))) || (((HEADER((GET_OE_SLOT(t0,1)))) & 0x3) == 0x1)) ? T : NIL);
if (v_G952_26 != NIL) {
t2 = v_G952_26;
} else {
v_X_29 = GET_OE_SLOT(t0,1);
v_X_31 = v_X_29;
v_X_33 = v_X_29;
v_Y_34 = LREF(s_lsp_NIL);
v_G953_36 = (((v_X_29) == (LREF(s_lsp_NIL))) ? T : NIL);
if (v_G953_36 != NIL) {
t3 = v_G953_36;
} else {
v_X_37 = v_X_29;
t3 = (OTHER_PTRP((v_X_29)) && (TAG((v_X_29)) == 15) ? T : NIL);
}
if (t3 != NIL) {
v_X_27 = GET_OE_SLOT(t0,1);
t4 = ((LP) DEREF((GET_OE_SLOT(t0,1)) + 0 * 4));
t2 = ICALL(s_lsp_MEMQL) (2, t4, LREF(k946));
} else {
t2 = LREF(s_lsp_NIL);
}
}
}
if (t2 != NIL) {
v_PLACE_71 = GET_OE_SLOT(t0,1);
} else {
v_X_8 = LREF(s_lsp_NIL);
v_KEYS944_10 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(s_lsp_NIL));
v_VALUE947_11 = v_KEYS944_10;
v_Y_13 = v_KEYS945_5;
v_S948_15 = (c_cons((v_KEYS944_10), (v_Y_13)));
v_KEYS945_5 = v_S948_15;
v_VALUE949_16 = GET_OE_SLOT(t0,1);
v_Y_18 = v_KEYS946_6;
v_S950_20 = (c_cons((GET_OE_SLOT(t0,1)), (v_Y_18)));
v_KEYS946_6 = v_S950_20;
v_PLACE_71 = v_KEYS944_10;
}
v_S_53 = GET_OE_SLOT(t0,0);
v_G958_55 = (OTHER_PTRP((GET_OE_SLOT(t0,0))) && (TAG((GET_OE_SLOT(t0,0))) == 3) ? T : NIL);
if (v_G958_55 != NIL) {
t5 = v_G958_55;
} else {
v_X_56 = GET_OE_SLOT(t0,0);
v_G959_58 = ((FIXNUMP((GET_OE_SLOT(t0,0))) || (((HEADER((GET_OE_SLOT(t0,0)))) & 0x3) == 0x1)) ? T : NIL);
if (v_G959_58 != NIL) {
t5 = v_G959_58;
} else {
v_X_61 = GET_OE_SLOT(t0,0);
v_X_63 = v_X_61;
v_X_65 = v_X_61;
v_Y_66 = LREF(s_lsp_NIL);
v_G960_68 = (((v_X_61) == (LREF(s_lsp_NIL))) ? T : NIL);
if (v_G960_68 != NIL) {
t6 = v_G960_68;
} else {
v_X_69 = v_X_61;
t6 = (OTHER_PTRP((v_X_61)) && (TAG((v_X_61)) == 15) ? T : NIL);
}
if (t6 != NIL) {
v_X_59 = GET_OE_SLOT(t0,0);
t7 = ((LP) DEREF((GET_OE_SLOT(t0,0)) + 0 * 4));
t5 = ICALL(s_lsp_MEMQL) (2, t7, LREF(k946));
} else {
t5 = LREF(s_lsp_NIL);
}
}
}
if (t5 != NIL) {
v_LIST_72 = GET_OE_SLOT(t0,0);
} else {
v_X_40 = LREF(s_lsp_NIL);
v_KEYS944_42 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(s_lsp_NIL));
v_VALUE954_43 = v_KEYS944_42;
v_Y_45 = v_KEYS945_5;
v_S955_47 = (c_cons((v_KEYS944_42), (v_Y_45)));
v_KEYS945_5 = v_S955_47;
v_VALUE956_48 = GET_OE_SLOT(t0,0);
v_Y_50 = v_KEYS946_6;
v_S957_52 = (c_cons((GET_OE_SLOT(t0,0)), (v_Y_50)));
v_KEYS946_6 = v_S957_52;
v_LIST_72 = v_KEYS944_42;
}
v_X_82 = ICALL(s_lsp_LIST) (5, LREF(s_lsp_MEMBER), v_PLACE_71, v_LIST_72, LREF(s_key_TEST), v_TEST_0);
v_X_73 = v_PRETTY_2DNAME_3;
v_Y_74 = LREF(s_lsp_NIL);
v_Y_77 = (c_cons((v_PRETTY_2DNAME_3), (LREF(s_lsp_NIL))));
t8 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_77)));
v_X_79 = ICALL(s_lsp_LIST) (5, LREF(s_lsp_ERROR), LREF(k958), t8, v_PLACE_71, v_LIST_72);
v_Y_83 = (c_cons((v_X_79), (LREF(s_lsp_NIL))));
v_Y_86 = (c_cons((v_X_82), (v_Y_83)));
v_WRAPPED_2DBODY_88 = (c_cons((LREF(s_lsp_OR)), (v_Y_86)));
v_L961_89 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D168_90 = ICALL(s_lsp_REVERSE) (1, v_KEYS945_5);
v_L962_91 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D169_92 = ICALL(s_lsp_REVERSE) (1, v_KEYS946_6);
v_LOOPVAR_2D170_93 = LREF(s_lsp_NIL);
v_LOOPVAR_2D171_94 = LREF(s_lsp_NIL);
v_LOOPVAR_2D172_95 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_97:;
if (v_LOOP_2DLIST_2D168_90 == NIL) {
goto t_END_2DLOOP_98;
}
v_X_99 = v_LOOP_2DLIST_2D168_90;
v_L961_89 = ((LP) DEREF((v_X_99) + 0 * 4));
v_X_101 = v_LOOP_2DLIST_2D168_90;
v_LOOP_2DLIST_2D168_90 = ((LP) DEREF((v_X_101) + 1 * 4));
if (v_LOOP_2DLIST_2D169_92 == NIL) {
goto t_END_2DLOOP_98;
}
v_X_103 = v_LOOP_2DLIST_2D169_92;
v_L962_91 = ((LP) DEREF((v_X_103) + 0 * 4));
v_X_105 = v_LOOP_2DLIST_2D169_92;
v_LOOP_2DLIST_2D169_92 = ((LP) DEREF((v_X_105) + 1 * 4));
v_X_110 = v_L961_89;
v_X_107 = v_L962_91;
v_Y_111 = (c_cons((v_X_107), (LREF(s_lsp_NIL))));
v_X_113 = (c_cons((v_X_110), (v_Y_111)));
v_LOOPVAR_2D172_95 = (c_cons((v_X_113), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D171_94 != NIL) {
v_C_116 = v_LOOPVAR_2D171_94;
v_NEW_2DCDR_117 = v_LOOPVAR_2D172_95;
v_V_120 = v_NEW_2DCDR_117;
((LP) (DEREF((v_C_116) + 1 * 4) = (LD) (v_V_120)));
v_X_122 = v_C_116;
v_LOOPVAR_2D171_94 = ((LP) DEREF((v_X_122) + 1 * 4));
} else {
v_LOOPVAR_2D170_93 = v_LOOPVAR_2D172_95;
v_LOOPVAR_2D171_94 = v_LOOPVAR_2D170_93;
}
goto t_NEXT_2DLOOP_97;
goto t_END_2DLOOP_98;
t_END_2DLOOP_98:;
v_X_127 = v_LOOPVAR_2D170_93;
goto b_NIL_96;
v_X_127 = NIL;
v_X_127 = v_X_127;
b_NIL_96:;
v_X_124 = v_WRAPPED_2DBODY_88;
v_Y_125 = LREF(s_lsp_NIL);
v_Y_128 = (c_cons((v_WRAPPED_2DBODY_88), (LREF(s_lsp_NIL))));
v_Y_131 = (c_cons((v_X_127), (v_Y_128)));
t9 = (c_cons((LREF(s_lsp_LET)), (v_Y_131)));
return(t9);
}

LP m_pcl_ALIST_2DENTRY(argc, v_WHOLE963_0, v_ENV964_1)
      ARGC argc;  LP v_WHOLE963_0; LP v_ENV964_1;
{
LP v_Y_198; LP v_X_197; LP v_Y_195; 
LP v_X_194; LP v_Y_192; LP v_X_191; 
LP v_X_189; LP v_V_187; LP v_X_186; 
LP v_NEW_2DCDR_184; LP v_C_183; LP v_Y_181; 
LP v_X_180; LP v_Y_178; LP v_X_177; 
LP v_Y_175; LP v_X_174; LP v_X_172; 
LP v_X_170; LP v_X_168; LP v_X_166; 
LP v_LOOPVAR_2D177_162; LP v_LOOPVAR_2D176_161; LP v_LOOPVAR_2D175_160; 
LP v_LOOP_2DLIST_2D174_159; LP v_L1018_158; LP v_LOOP_2DLIST_2D173_157; 
LP v_L1017_156; LP v_WRAPPED_2DBODY_155; LP v_Y_153; 
LP v_X_152; LP v_Y_150; LP v_X_149; 
LP v_Y_147; LP v_X_146; LP v_Y_144; 
LP v_X_143; LP v_Y_141; LP v_X_140; 
LP v_Y_138; LP v_X_137; LP v_Y_135; 
LP v_X_134; LP v_Y_132; LP v_X_131; 
LP v_Y_129; LP v_X_128; LP v_Y_126; 
LP v_X_125; LP v_Y_123; LP v_X_122; 
LP v_Y_120; LP v_X_119; LP v_Y_117; 
LP v_X_116; LP v_Y_114; LP v_X_113; 
LP v_Y_111; LP v_X_110; LP v_Y_108; 
LP v_X_107; LP v_Y_105; LP v_X_104; 
LP v_Y_102; LP v_X_101; LP v_Y_99; 
LP v_X_98; LP v_KEY_97; LP v_ALIST_96; 
LP v_X_94; LP v_G1016_93; LP v_Y_91; 
LP v_X_90; LP v_X_88; LP v_X_86; 
LP v_X_84; LP v_G1015_83; LP v_X_81; 
LP v_G1014_80; LP v_S_78; LP v_S1013_77; 
LP v_Y_75; LP v_X_74; LP v_VALUE1012_73; 
LP v_S1011_72; LP v_Y_70; LP v_X_69; 
LP v_VALUE1010_68; LP v_S1000_67; LP v_X_65; 
LP v_X_64; LP v_X_62; LP v_G1009_61; 
LP v_Y_59; LP v_X_58; LP v_X_56; 
LP v_X_54; LP v_X_52; LP v_G1008_51; 
LP v_X_49; LP v_G1007_48; LP v_S_46; 
LP v_S1006_45; LP v_Y_43; LP v_X_42; 
LP v_VALUE1005_41; LP v_S1004_40; LP v_Y_38; 
LP v_X_37; LP v_VALUE1003_36; LP v_S1000_35; 
LP v_X_33; LP v_X_32; LP v_S1002_31; 
LP v_S1001_30; LP v_MAKE_2DENTRY_2DFN_29; LP v_S999_28; 
LP v_X_26; LP v_VALUE998_25; LP v_X_23; 
LP v_LIST997_22; LP v_KEY_21; LP v_S996_20; 
LP v_X_18; LP v_VALUE995_17; LP v_X_15; 
LP v_LIST994_14; LP v_ALIST_13; LP v_S993_12; 
LP v_X_10; LP v_VALUE992_9; LP v_X_7; 
LP v_LIST991_6; LP v_L990_5; LP v_X_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; LP t145; LP t146; LP t147; LP t148; LP t149; 
LP t150; LP t151; LP t152; LP t153; LP t154; LP t155; 
LP t156; LP t157; LP t158; LP t159; LP t160; LP t161; 
LP t162; LP t163; LP t164; LP t165; LP t166; LP t167; 
LP t168; LP t169; LP t170; LP t171; LP t172; LP t173; 
LP t174; LP t175; LP t176; LP t177; LP t178; LP t179; 
LP t180; LP t181; LP t182; LP t183; LP t184; LP t185; 
LP t186; LP t187; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE963_0;
v_L990_5 = ((LP) DEREF((v_WHOLE963_0) + 1 * 4));
v_LIST991_6 = v_L990_5;
v_X_7 = v_LIST991_6;
v_VALUE992_9 = ((LP) DEREF((v_LIST991_6) + 0 * 4));
v_X_10 = v_LIST991_6;
v_S993_12 = ((LP) DEREF((v_LIST991_6) + 1 * 4));
v_L990_5 = v_S993_12;
v_ALIST_13 = v_VALUE992_9;
v_LIST994_14 = v_L990_5;
v_X_15 = v_LIST994_14;
v_VALUE995_17 = ((LP) DEREF((v_LIST994_14) + 0 * 4));
v_X_18 = v_LIST994_14;
v_S996_20 = ((LP) DEREF((v_LIST994_14) + 1 * 4));
v_L990_5 = v_S996_20;
v_KEY_21 = v_VALUE995_17;
v_LIST997_22 = v_L990_5;
v_X_23 = v_LIST997_22;
v_VALUE998_25 = ((LP) DEREF((v_LIST997_22) + 0 * 4));
v_X_26 = v_LIST997_22;
v_S999_28 = ((LP) DEREF((v_LIST997_22) + 1 * 4));
v_L990_5 = v_S999_28;
v_MAKE_2DENTRY_2DFN_29 = v_VALUE998_25;
v_S1001_30 = LREF(s_lsp_NIL);
v_S1002_31 = LREF(s_lsp_NIL);
v_S_46 = v_ALIST_13;
v_G1007_48 = (OTHER_PTRP((v_ALIST_13)) && (TAG((v_ALIST_13)) == 3) ? T : NIL);
if (v_G1007_48 != NIL) {
t0 = v_G1007_48;
} else {
v_X_49 = v_ALIST_13;
v_G1008_51 = ((FIXNUMP((v_ALIST_13)) || (((HEADER((v_ALIST_13))) & 0x3) == 0x1)) ? T : NIL);
if (v_G1008_51 != NIL) {
t0 = v_G1008_51;
} else {
v_X_54 = v_ALIST_13;
v_X_56 = v_X_54;
v_X_58 = v_X_54;
v_Y_59 = LREF(s_lsp_NIL);
v_G1009_61 = (((v_X_54) == (LREF(s_lsp_NIL))) ? T : NIL);
if (v_G1009_61 != NIL) {
t1 = v_G1009_61;
} else {
v_X_62 = v_X_54;
t1 = (OTHER_PTRP((v_X_54)) && (TAG((v_X_54)) == 15) ? T : NIL);
}
if (t1 != NIL) {
v_X_52 = v_ALIST_13;
t2 = ((LP) DEREF((v_ALIST_13) + 0 * 4));
t0 = ICALL(s_lsp_MEMQL) (2, t2, LREF(k946));
} else {
t0 = LREF(s_lsp_NIL);
}
}
}
if (t0 != NIL) {
v_ALIST_96 = v_ALIST_13;
} else {
v_X_33 = LREF(s_lsp_NIL);
v_S1000_35 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(s_lsp_NIL));
v_VALUE1003_36 = v_S1000_35;
v_Y_38 = v_S1001_30;
v_S1004_40 = (c_cons((v_S1000_35), (v_Y_38)));
v_S1001_30 = v_S1004_40;
v_VALUE1005_41 = v_ALIST_13;
v_Y_43 = v_S1002_31;
v_S1006_45 = (c_cons((v_ALIST_13), (v_Y_43)));
v_S1002_31 = v_S1006_45;
v_ALIST_96 = v_S1000_35;
}
v_S_78 = v_KEY_21;
v_G1014_80 = (OTHER_PTRP((v_KEY_21)) && (TAG((v_KEY_21)) == 3) ? T : NIL);
if (v_G1014_80 != NIL) {
t3 = v_G1014_80;
} else {
v_X_81 = v_KEY_21;
v_G1015_83 = ((FIXNUMP((v_KEY_21)) || (((HEADER((v_KEY_21))) & 0x3) == 0x1)) ? T : NIL);
if (v_G1015_83 != NIL) {
t3 = v_G1015_83;
} else {
v_X_86 = v_KEY_21;
v_X_88 = v_X_86;
v_X_90 = v_X_86;
v_Y_91 = LREF(s_lsp_NIL);
v_G1016_93 = (((v_X_86) == (LREF(s_lsp_NIL))) ? T : NIL);
if (v_G1016_93 != NIL) {
t4 = v_G1016_93;
} else {
v_X_94 = v_X_86;
t4 = (OTHER_PTRP((v_X_86)) && (TAG((v_X_86)) == 15) ? T : NIL);
}
if (t4 != NIL) {
v_X_84 = v_KEY_21;
t5 = ((LP) DEREF((v_KEY_21) + 0 * 4));
t3 = ICALL(s_lsp_MEMQL) (2, t5, LREF(k946));
} else {
t3 = LREF(s_lsp_NIL);
}
}
}
if (t3 != NIL) {
v_KEY_97 = v_KEY_21;
} else {
v_X_65 = LREF(s_lsp_NIL);
v_S1000_67 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(s_lsp_NIL));
v_VALUE1010_68 = v_S1000_67;
v_Y_70 = v_S1001_30;
v_S1011_72 = (c_cons((v_S1000_67), (v_Y_70)));
v_S1001_30 = v_S1011_72;
v_VALUE1012_73 = v_KEY_21;
v_Y_75 = v_S1002_31;
v_S1013_77 = (c_cons((v_KEY_21), (v_Y_75)));
v_S1002_31 = v_S1013_77;
v_KEY_97 = v_S1000_67;
}
v_X_98 = v_ALIST_96;
v_Y_99 = LREF(s_lsp_NIL);
v_Y_102 = (c_cons((v_ALIST_96), (LREF(s_lsp_NIL))));
v_Y_105 = (c_cons((v_KEY_97), (v_Y_102)));
v_X_149 = (c_cons((LREF(s_pcl_ASSQ)), (v_Y_105)));
v_X_107 = v_KEY_97;
v_Y_108 = LREF(s_lsp_NIL);
v_Y_111 = (c_cons((v_KEY_97), (LREF(s_lsp_NIL))));
v_X_116 = (c_cons((v_MAKE_2DENTRY_2DFN_29), (v_Y_111)));
v_X_113 = v_ALIST_96;
v_Y_114 = LREF(s_lsp_NIL);
v_Y_117 = (c_cons((v_ALIST_96), (LREF(s_lsp_NIL))));
v_Y_120 = (c_cons((v_X_116), (v_Y_117)));
v_X_122 = (c_cons((LREF(s_lsp_CONS)), (v_Y_120)));
v_Y_126 = (c_cons((v_X_122), (LREF(s_lsp_NIL))));
v_Y_129 = (c_cons((v_ALIST_96), (v_Y_126)));
v_X_140 = (c_cons((LREF(s_lsp_SETF)), (v_Y_129)));
v_X_131 = v_ALIST_96;
v_Y_132 = LREF(s_lsp_NIL);
v_Y_135 = (c_cons((v_ALIST_96), (LREF(s_lsp_NIL))));
v_X_137 = (c_cons((LREF(s_lsp_CAR)), (v_Y_135)));
v_Y_141 = (c_cons((v_X_137), (LREF(s_lsp_NIL))));
v_Y_144 = (c_cons((v_X_140), (v_Y_141)));
v_X_146 = (c_cons((LREF(s_lsp_PROGN)), (v_Y_144)));
v_Y_150 = (c_cons((v_X_146), (LREF(s_lsp_NIL))));
v_Y_153 = (c_cons((v_X_149), (v_Y_150)));
v_WRAPPED_2DBODY_155 = (c_cons((LREF(s_lsp_OR)), (v_Y_153)));
v_L1017_156 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D173_157 = ICALL(s_lsp_REVERSE) (1, v_S1001_30);
v_L1018_158 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D174_159 = ICALL(s_lsp_REVERSE) (1, v_S1002_31);
v_LOOPVAR_2D175_160 = LREF(s_lsp_NIL);
v_LOOPVAR_2D176_161 = LREF(s_lsp_NIL);
v_LOOPVAR_2D177_162 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_164:;
if (v_LOOP_2DLIST_2D173_157 == NIL) {
goto t_END_2DLOOP_165;
}
v_X_166 = v_LOOP_2DLIST_2D173_157;
v_L1017_156 = ((LP) DEREF((v_X_166) + 0 * 4));
v_X_168 = v_LOOP_2DLIST_2D173_157;
v_LOOP_2DLIST_2D173_157 = ((LP) DEREF((v_X_168) + 1 * 4));
if (v_LOOP_2DLIST_2D174_159 == NIL) {
goto t_END_2DLOOP_165;
}
v_X_170 = v_LOOP_2DLIST_2D174_159;
v_L1018_158 = ((LP) DEREF((v_X_170) + 0 * 4));
v_X_172 = v_LOOP_2DLIST_2D174_159;
v_LOOP_2DLIST_2D174_159 = ((LP) DEREF((v_X_172) + 1 * 4));
v_X_177 = v_L1017_156;
v_X_174 = v_L1018_158;
v_Y_178 = (c_cons((v_X_174), (LREF(s_lsp_NIL))));
v_X_180 = (c_cons((v_X_177), (v_Y_178)));
v_LOOPVAR_2D177_162 = (c_cons((v_X_180), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D176_161 != NIL) {
v_C_183 = v_LOOPVAR_2D176_161;
v_NEW_2DCDR_184 = v_LOOPVAR_2D177_162;
v_V_187 = v_NEW_2DCDR_184;
((LP) (DEREF((v_C_183) + 1 * 4) = (LD) (v_V_187)));
v_X_189 = v_C_183;
v_LOOPVAR_2D176_161 = ((LP) DEREF((v_X_189) + 1 * 4));
} else {
v_LOOPVAR_2D175_160 = v_LOOPVAR_2D177_162;
v_LOOPVAR_2D176_161 = v_LOOPVAR_2D175_160;
}
goto t_NEXT_2DLOOP_164;
goto t_END_2DLOOP_165;
t_END_2DLOOP_165:;
v_X_194 = v_LOOPVAR_2D175_160;
goto b_NIL_163;
v_X_194 = NIL;
v_X_194 = v_X_194;
b_NIL_163:;
v_X_191 = v_WRAPPED_2DBODY_155;
v_Y_192 = LREF(s_lsp_NIL);
v_Y_195 = (c_cons((v_WRAPPED_2DBODY_155), (LREF(s_lsp_NIL))));
v_Y_198 = (c_cons((v_X_194), (v_Y_195)));
t6 = (c_cons((LREF(s_lsp_LET)), (v_Y_198)));
return(t6);
}

LP m_pcl_DESTRUCTURING_2DBIND(argc, v_WHOLE1019_0, v_ENV1020_1)
      ARGC argc;  LP v_WHOLE1019_0; LP v_ENV1020_1;
{
LP v_Y_29; LP v_X_28; LP v_BINDS_27; 
LP v_SETQS_26; LP v_BODY_25; LP v_DECLARES_24; 
LP v_IGNORE_23; LP v_BODY_22; LP v_FORM_21; 
LP v_S1034_20; LP v_X_18; LP v_VALUE1033_17; 
LP v_X_15; LP v_LIST1032_14; LP v_PATTERN_13; 
LP v_S1031_12; LP v_X_10; LP v_VALUE1030_9; 
LP v_X_7; LP v_LIST1029_6; LP v_L1028_5; 
LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE1019_0;
v_L1028_5 = ((LP) DEREF((v_WHOLE1019_0) + 1 * 4));
v_LIST1029_6 = v_L1028_5;
v_X_7 = v_LIST1029_6;
v_VALUE1030_9 = ((LP) DEREF((v_LIST1029_6) + 0 * 4));
v_X_10 = v_LIST1029_6;
v_S1031_12 = ((LP) DEREF((v_LIST1029_6) + 1 * 4));
v_L1028_5 = v_S1031_12;
v_PATTERN_13 = v_VALUE1030_9;
v_LIST1032_14 = v_L1028_5;
v_X_15 = v_LIST1032_14;
v_VALUE1033_17 = ((LP) DEREF((v_LIST1032_14) + 0 * 4));
v_X_18 = v_LIST1032_14;
v_S1034_20 = ((LP) DEREF((v_LIST1032_14) + 1 * 4));
v_L1028_5 = v_S1034_20;
v_FORM_21 = v_VALUE1033_17;
v_BODY_22 = v_L1028_5;
{
int real_argc;
BEGIN_MV_CALL(mv_holder959,0);
t0 = ICALL(s_pcl_EXTRACT_2DDECLARATIONS) (MV_CALL(mv_holder959,1), v_BODY_22);
SET_MV_RETURN_VALUE(mv_holder959,0,t0);
if SV_RETURN_P(mv_holder959) SET_MV_RETURN_COUNT(mv_holder959,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder959);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_IGNORE_23 = NIL;
} else {
v_IGNORE_23 = NEXT_VAR_VALUE(mv_holder959);
}
if (real_argc < 2) {
v_DECLARES_24 = NIL;
} else {
v_DECLARES_24 = NEXT_VAR_VALUE(mv_holder959);
}
if (real_argc < 3) {
v_BODY_25 = NIL;
} else {
v_BODY_25 = NEXT_VAR_VALUE(mv_holder959);
}
END_VAR_VALUES;
END_MV_CALL;
{
int real_argc;
BEGIN_MV_CALL(mv_holder960,0);
t1 = ICALL(s_pcl_DESTRUCTURE) (MV_CALL(mv_holder960,2), v_PATTERN_13, v_FORM_21);
SET_MV_RETURN_VALUE(mv_holder960,0,t1);
if SV_RETURN_P(mv_holder960) SET_MV_RETURN_COUNT(mv_holder960,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder960);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_SETQS_26 = NIL;
} else {
v_SETQS_26 = NEXT_VAR_VALUE(mv_holder960);
}
if (real_argc < 2) {
v_BINDS_27 = NIL;
} else {
v_BINDS_27 = NEXT_VAR_VALUE(mv_holder960);
}
END_VAR_VALUES;
END_MV_CALL;
v_X_28 = LREF(k961);
v_Y_29 = v_BODY_25;
t5 = (c_cons((LREF(k961)), (v_BODY_25)));
t4 = ICALL(s_lsp_APPEND_2F2) (2, v_SETQS_26, t5);
t3 = ICALL(s_lsp_APPEND_2F2) (2, v_DECLARES_24, t4);
t2 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,3), LREF(s_lsp_LET), v_BINDS_27, t3);
return(t2);
}
}
}

LP p_pcl_DESTRUCTURE(argc, v_PATTERN_0, v_FORM_1)
      ARGC argc;  LP v_PATTERN_0; LP v_FORM_1;
{
LP v_KEY_43; LP v_COUNT_42; LP v_END_41; 
LP v_START_40; LP v_TEST_2DNOT_39; LP v_TEST_38; 
LP v_FROM_2DEND_37; LP v_SEQUENCE_36; LP v_ITEM_35; 
LP v_SYMBOL_33; LP v_SEQUENCE_21; LP v_ITEM_20; 
LP v_X_31; LP v_KEY_30; LP v_COUNT_29; 
LP v_END_28; LP v_START_27; LP v_TEST_2DNOT_26; 
LP v_X_24; LP v_TEST_23; LP v_FROM_2DEND_22; 
LP v_Y_18; LP v_X_17; LP v_Y_15; 
LP v_X_14; LP v_Y_12; LP v_X_11; 
LP v_Y_9; LP v_X_8; LP v_V_6; 
LP v_X_5; LP v_SETQS_4; LP v__2ADESTRUCTURE_2DVARS_2A_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; 
if (argc != 2) wna(argc,2);
v_SETQS_4 = LREF(s_lsp_NIL);
BEGIN_SPEC_BIND(s_pcl__2ADESTRUCTURE_2DVARS_2A,LREF(s_lsp_NIL));
v_V_6 = LREF(k962);
((LP) (DEREF((LREF(s_pcl__2ADESTRUCTURE_2DVARS_2A)) + 0 * 4) = (LD) (v_V_6)));
v_X_8 = v_FORM_1;
v_Y_12 = (c_cons((v_X_8), (LREF(s_lsp_NIL))));
v_Y_15 = (c_cons((LREF(s_pcl__2EDESTRUCTURE_2DFORM_2E)), (v_Y_12)));
v_X_17 = (c_cons((LREF(s_lsp_SETQ)), (v_Y_15)));
v_SETQS_4 = (c_cons((v_X_17), (LREF(s_lsp_NIL))));
v_FORM_1 = LREF(s_pcl__2EDESTRUCTURE_2DFORM_2E);
t2 = ICALL(s_pcl_DESTRUCTURE_2DINTERNAL) (2, v_PATTERN_0, v_FORM_1);
t1 = ICALL(s_lsp_NREVERSE) (1, t2);
t0 = ICALL(s_lsp_NCONC_2F2) (2, v_SETQS_4, t1);
v_SYMBOL_33 = LREF(s_pcl__2ADESTRUCTURE_2DVARS_2A);
v_SEQUENCE_36 = ((LP) DEREF((LREF(s_pcl__2ADESTRUCTURE_2DVARS_2A)) + 0 * 4));
v_X_24 = LREF(s_lsp_EQL);
v_TEST_38 = ((LP) DEREF((LREF(s_lsp_EQL)) + 4 * 4));
v_END_41 = LREF(s_lsp_NIL);
v_X_31 = LREF(s_lsp_IDENTITY);
v_KEY_43 = ((LP) DEREF((LREF(s_lsp_IDENTITY)) + 4 * 4));
v_END_41 = ICALL(s_lsp_LENGTH) (1, v_SEQUENCE_36);
t4 = ICALL(s_lsp_SEQ_2DTEST) (2, v_TEST_38, LREF(s_lsp_NIL));
t3 = ICALL(s_lsp_DELETE_2F8) (8, LREF(s_lsp_NIL), v_SEQUENCE_36, LREF(s_lsp_NIL), t4, (LP) 0, v_END_41, (LP) 2147483646, v_KEY_43);
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,t3);
}
END_SPEC_BIND(s_pcl__2ADESTRUCTURE_2DVARS_2A);
return(t0);
}

LP p_pcl_DESTRUCTURE_2DINTERNAL(argc, v_PATTERN_0, v_FORM_1)
      ARGC argc;  LP v_PATTERN_0; LP v_FORM_1;
{
LP v_S_115; LP v_X_113; LP v_S_111; 
LP v_X_109; LP v_V_107; LP v_X_106; 
LP v_S1078_105; LP v_Y_103; LP v_X_102; 
LP v_SYMBOL_100; LP v_VALUE1077_99; LP v_X_97; 
LP v_S1076_96; LP v_Y_94; LP v_X_93; 
LP v_VALUE1075_92; LP v_X_90; LP v_X_88; 
LP v_S_86; LP v_X_84; LP v_X_82; 
LP v_Y_80; LP v_X_79; LP v_Y_77; 
LP v_X_76; LP v_X_74; LP v_S_72; 
LP v_X_70; LP v_X_68; LP v_X_66; 
LP v_C_64; LP v_S1074_63; LP v_Y_61; 
LP v_X_60; LP v_VALUE1073_59; LP v_S1072_58; 
LP v_S1071_57; LP v_Y_55; LP v_X_54; 
LP v_VALUE1070_53; LP v_S1069_52; LP v_V_50; 
LP v_X_49; LP v_S1068_48; LP v_Y_46; 
LP v_X_45; LP v_SYMBOL_43; LP v_VALUE1067_42; 
LP v_X_40; LP v_S1066_39; LP v_Y_37; 
LP v_X_36; LP v_VALUE1065_35; LP v_X_33; 
LP v_S1064_32; LP v_Y_30; LP v_X_29; 
LP v_VALUE1063_28; LP v_V_26; LP v_X_25; 
LP v_S1062_24; LP v_Y_22; LP v_X_21; 
LP v_SYMBOL_19; LP v_VALUE1061_18; LP v_TMP1060_17; 
LP v_X_15; LP v_PAT_12; LP f_MAKE_2DPOP_10; 
LP v_SETQS_9; LP v_VAR_8; LP v_PENDING_2DPOPS_7; 
LP v_GENSYM_6; LP v_X_4; LP v_X_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; 
if (argc != 2) wna(argc,2);
t0 = NEW_OE(1);
v_X_4 = LREF(s_lsp_NIL);
v_GENSYM_6 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(s_lsp_NIL));
v_PENDING_2DPOPS_7 = (LP) 0;
v_VAR_8 = LREF(s_lsp_NIL);
v_SETQS_9 = LREF(s_lsp_NIL);
SET_OE_SLOT(t0,0,v_PENDING_2DPOPS_7);
t1 = MAKE_CLOSURE(p_pcl_DESTRUCTURE_2DINTERNAL_2DMAKE_2DPOP963,t0);
f_MAKE_2DPOP_10 = t1;
v_PAT_12 = v_PATTERN_0;
goto t_TEST1058_14;
t_LOOP1059_13:;
v_X_15 = v_PAT_12;
v_TMP1060_17 = ((LP) DEREF((v_X_15) + 1 * 4));
v_PAT_12 = v_TMP1060_17;
t_TEST1058_14:;
if (v_PAT_12 == NIL) {
goto b_NIL_11;
}
v_X_113 = v_PAT_12;
v_VAR_8 = ((LP) DEREF((v_X_113) + 0 * 4));
v_S_115 = v_VAR_8;
if (OTHER_PTRP((v_S_115)) && (TAG((v_S_115)) == 3)) {
t3 = ICALL(s_lsp_MEMQ) (2, v_VAR_8, LREF(k964));
if (t3 == NIL) {
v_VALUE1061_18 = v_VAR_8;
v_SYMBOL_19 = LREF(s_pcl__2ADESTRUCTURE_2DVARS_2A);
v_Y_22 = ((LP) DEREF((LREF(s_pcl__2ADESTRUCTURE_2DVARS_2A)) + 0 * 4));
v_S1062_24 = (c_cons((v_VALUE1061_18), (v_Y_22)));
v_V_26 = v_S1062_24;
((LP) (DEREF((LREF(s_pcl__2ADESTRUCTURE_2DVARS_2A)) + 0 * 4) = (LD) (v_V_26)));
}
v_X_74 = v_PAT_12;
t4 = ((LP) DEREF((v_X_74) + 1 * 4));
if (t4 != NIL) {
v_X_70 = v_PAT_12;
v_S_72 = ((LP) DEREF((v_X_70) + 1 * 4));
if (OTHER_PTRP((v_S_72)) && (TAG((v_S_72)) == 3)) {
v_X_33 = v_PAT_12;
t6 = ((LP) DEREF((v_X_33) + 1 * 4));
v_VALUE1065_35 = CODE_PTR(COERCE_TO_FUNCTION(f_MAKE_2DPOP_10))(3, v_VAR_8, v_FORM_1, t6);
v_Y_37 = v_SETQS_9;
v_S1066_39 = (c_cons((v_VALUE1065_35), (v_Y_37)));
v_SETQS_9 = v_S1066_39;
v_X_40 = v_PAT_12;
v_VALUE1067_42 = ((LP) DEREF((v_X_40) + 1 * 4));
v_SYMBOL_43 = LREF(s_pcl__2ADESTRUCTURE_2DVARS_2A);
v_Y_46 = ((LP) DEREF((LREF(s_pcl__2ADESTRUCTURE_2DVARS_2A)) + 0 * 4));
v_S1068_48 = (c_cons((v_VALUE1067_42), (v_Y_46)));
v_V_50 = v_S1068_48;
((LP) (DEREF((LREF(s_pcl__2ADESTRUCTURE_2DVARS_2A)) + 0 * 4) = (LD) (v_V_50)));
goto b_NIL_11;
} else {
t7 = ICALL(s_lsp_MEMQ) (2, v_VAR_8, LREF(k964));
if (t7 != NIL) {
v_S1069_52 = (add((GET_OE_SLOT(t0,0)), ((LP) 2)));
SET_OE_SLOT(t0,0,v_S1069_52);
} else {
v_C_64 = v_PAT_12;
v_X_66 = v_C_64;
v_X_68 = ((LP) DEREF((v_C_64) + 1 * 4));
t9 = ((LP) DEREF((v_X_68) + 0 * 4));
t8 = ICALL(s_lsp_MEMQ) (2, t9, LREF(k964));
if (t8 != NIL) {
v_VALUE1070_53 = CODE_PTR(COERCE_TO_FUNCTION(f_MAKE_2DPOP_10))(3, v_VAR_8, v_FORM_1, LREF(s_lsp_NIL));
v_Y_55 = v_SETQS_9;
v_S1071_57 = (c_cons((v_VALUE1070_53), (v_Y_55)));
v_SETQS_9 = v_S1071_57;
v_S1072_58 = (add((GET_OE_SLOT(t0,0)), ((LP) 2)));
SET_OE_SLOT(t0,0,v_S1072_58);
} else {
v_VALUE1073_59 = CODE_PTR(COERCE_TO_FUNCTION(f_MAKE_2DPOP_10))(3, v_VAR_8, v_FORM_1, v_FORM_1);
v_Y_61 = v_SETQS_9;
v_S1074_63 = (c_cons((v_VALUE1073_59), (v_Y_61)));
v_SETQS_9 = v_S1074_63;
}
}
}
} else {
v_VALUE1063_28 = CODE_PTR(COERCE_TO_FUNCTION(f_MAKE_2DPOP_10))(3, v_VAR_8, v_FORM_1, LREF(s_lsp_NIL));
v_Y_30 = v_SETQS_9;
v_S1064_32 = (c_cons((v_VALUE1063_28), (v_Y_30)));
v_SETQS_9 = v_S1064_32;
}
} else {
v_X_76 = v_GENSYM_6;
v_Y_77 = LREF(k966);
v_X_79 = (c_cons((v_GENSYM_6), (LREF(k966))));
t10 = (c_cons((v_X_79), (LREF(s_lsp_NIL))));
v_X_84 = v_PAT_12;
v_S_86 = ((LP) DEREF((v_X_84) + 1 * 4));
if (OTHER_PTRP((v_S_86)) && (TAG((v_S_86)) == 3)) {
v_X_82 = v_PAT_12;
t12 = ((LP) DEREF((v_X_82) + 1 * 4));
} else {
t12 = v_FORM_1;
}
t11 = CODE_PTR(COERCE_TO_FUNCTION(f_MAKE_2DPOP_10))(3, v_GENSYM_6, v_FORM_1, t12);
v_X_90 = v_PAT_12;
if (OTHER_PTRP((v_X_90)) && (TAG((v_X_90)) == 15)) {
v_X_88 = v_PAT_12;
t16 = ((LP) DEREF((v_X_88) + 0 * 4));
} else {
t16 = v_PAT_12;
}
t15 = ICALL(s_pcl_DESTRUCTURE_2DINTERNAL) (2, t16, v_GENSYM_6);
t14 = ICALL(s_lsp_NREVERSE) (1, t15);
v_VALUE1075_92 = ICALL(s_lsp_LIST_2A) (4, LREF(s_lsp_LET), t10, t11, t14);
v_Y_94 = v_SETQS_9;
v_S1076_96 = (c_cons((v_VALUE1075_92), (v_Y_94)));
v_SETQS_9 = v_S1076_96;
v_X_109 = v_PAT_12;
v_S_111 = ((LP) DEREF((v_X_109) + 1 * 4));
if (OTHER_PTRP((v_S_111)) && (TAG((v_S_111)) == 3)) {
v_X_97 = v_PAT_12;
v_VALUE1077_99 = ((LP) DEREF((v_X_97) + 1 * 4));
v_SYMBOL_100 = LREF(s_pcl__2ADESTRUCTURE_2DVARS_2A);
v_Y_103 = ((LP) DEREF((LREF(s_pcl__2ADESTRUCTURE_2DVARS_2A)) + 0 * 4));
v_S1078_105 = (c_cons((v_VALUE1077_99), (v_Y_103)));
v_V_107 = v_S1078_105;
((LP) (DEREF((LREF(s_pcl__2ADESTRUCTURE_2DVARS_2A)) + 0 * 4) = (LD) (v_V_107)));
goto b_NIL_11;
}
}
goto t_LOOP1059_13;
b_NIL_11:;
return(v_SETQS_9);
}

LP p_pcl_DESTRUCTURE_2DINTERNAL_2DMAKE_2DPOP963(argc, v_VAR_0, v_FORM_1, v_POP_2DINTO_2)
      ARGC argc;  LP v_VAR_0; LP v_FORM_1; LP v_POP_2DINTO_2;
{
LP v_VALUE1057_87; LP v_N_85; LP v_Y_83; 
LP v_X_82; LP v_Y_80; LP v_X_79; 
LP v_Y_77; LP v_X_76; LP v_Y_74; 
LP v_X_73; LP v_Y_71; LP v_X_70; 
LP v_Y_68; LP v_X_67; LP v_Y_65; 
LP v_X_64; LP v_Y_62; LP v_X_61; 
LP v_Y_59; LP v_X_58; LP v_Y_56; 
LP v_X_55; LP v_Y_53; LP v_X_52; 
LP v_Y_50; LP v_X_49; LP v_Y_47; 
LP v_X_46; LP v_Y_44; LP v_X_43; 
LP v_Y_41; LP v_X_40; LP v_Y_38; 
LP v_X_37; LP v_Y_35; LP v_X_34; 
LP v_Y_32; LP v_X_31; LP v_Y_29; 
LP v_X_28; LP v_Y_26; LP v_X_25; 
LP v_Y_23; LP v_X_22; LP v_Y_20; 
LP v_X_19; LP v_Y_17; LP v_X_16; 
LP v_Y_14; LP v_X_13; LP v_Y_11; 
LP v_X_10; LP v_Y_8; LP v_X_7; 
LP v_Y_5; LP v_X_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; 
if (argc != 3) wna(argc,3);
t0 = OE;
v_N_85 = GET_OE_SLOT(t0,0);
t1 = (num_equal_p((v_N_85), ((LP) 0)));
if (t1 != NIL) {
if (v_VAR_0 != NIL) {
v_X_4 = v_FORM_1;
v_Y_5 = LREF(s_lsp_NIL);
v_Y_8 = (c_cons((v_FORM_1), (LREF(s_lsp_NIL))));
v_X_10 = (c_cons((LREF(s_lsp_CAR)), (v_Y_8)));
v_Y_14 = (c_cons((v_X_10), (LREF(s_lsp_NIL))));
v_Y_17 = (c_cons((v_VAR_0), (v_Y_14)));
v_X_37 = (c_cons((LREF(s_lsp_SETQ)), (v_Y_17)));
} else {
v_X_37 = LREF(s_lsp_NIL);
}
if (v_POP_2DINTO_2 != NIL) {
v_X_19 = v_FORM_1;
v_Y_20 = LREF(s_lsp_NIL);
v_Y_23 = (c_cons((v_FORM_1), (LREF(s_lsp_NIL))));
v_X_25 = (c_cons((LREF(s_lsp_CDR)), (v_Y_23)));
v_Y_29 = (c_cons((v_X_25), (LREF(s_lsp_NIL))));
v_Y_32 = (c_cons((v_POP_2DINTO_2), (v_Y_29)));
v_X_34 = (c_cons((LREF(s_lsp_SETQ)), (v_Y_32)));
} else {
v_X_34 = LREF(s_lsp_NIL);
}
v_Y_38 = (c_cons((v_X_34), (LREF(s_lsp_NIL))));
v_Y_41 = (c_cons((v_X_37), (v_Y_38)));
v_VALUE1057_87 = (c_cons((LREF(s_lsp_PROGN)), (v_Y_41)));
} else {
if (v_POP_2DINTO_2 != NIL) {
v_X_52 = ICALL(s_pcl_MAKE_2DCDXR) (2, GET_OE_SLOT(t0,0), v_FORM_1);
v_Y_56 = (c_cons((v_X_52), (LREF(s_lsp_NIL))));
v_Y_59 = (c_cons((v_POP_2DINTO_2), (v_Y_56)));
v_X_79 = (c_cons((LREF(s_lsp_SETQ)), (v_Y_59)));
if (v_VAR_0 != NIL) {
v_X_61 = v_POP_2DINTO_2;
v_Y_62 = LREF(s_lsp_NIL);
v_Y_65 = (c_cons((v_POP_2DINTO_2), (LREF(s_lsp_NIL))));
v_X_67 = (c_cons((LREF(s_lsp_POP)), (v_Y_65)));
v_Y_71 = (c_cons((v_X_67), (LREF(s_lsp_NIL))));
v_Y_74 = (c_cons((v_VAR_0), (v_Y_71)));
v_X_76 = (c_cons((LREF(s_lsp_SETQ)), (v_Y_74)));
} else {
v_X_76 = LREF(s_lsp_NIL);
}
v_Y_80 = (c_cons((v_X_76), (LREF(s_lsp_NIL))));
v_Y_83 = (c_cons((v_X_79), (v_Y_80)));
v_VALUE1057_87 = (c_cons((LREF(s_lsp_PROGN)), (v_Y_83)));
} else {
if (v_VAR_0 != NIL) {
v_X_43 = ICALL(s_pcl_MAKE_2DCAXR) (2, GET_OE_SLOT(t0,0), v_FORM_1);
v_Y_47 = (c_cons((v_X_43), (LREF(s_lsp_NIL))));
v_Y_50 = (c_cons((v_VAR_0), (v_Y_47)));
v_VALUE1057_87 = (c_cons((LREF(s_lsp_SETQ)), (v_Y_50)));
} else {
v_VALUE1057_87 = LREF(s_lsp_NIL);
}
}
}
SET_OE_SLOT(t0,0,(LP) 0);
return(v_VALUE1057_87);
}

LP m_pcl_COLLECTING_2DONCE(argc, v_WHOLE1079_0, v_ENV1080_1)
      ARGC argc;  LP v_WHOLE1079_0; LP v_ENV1080_1;
{
LP v_L1082_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE1079_0;
v_L1082_5 = ((LP) DEREF((v_WHOLE1079_0) + 1 * 4));
t0 = p_lsp_APPLY(MV_CALL(argc,2), COERCE_TO_FUNCTION(LREF(k969)), v_L1082_5);
return(t0);
}

LP p_pcl_COLLECTING_2DONCE_2Danon967968(va_alist) va_dcl
{
LP v_Y_18; LP v_X_17; LP v_Y_15; 
LP v_X_14; LP v_Y_12; LP v_X_11; 
LP v_Y_9; LP v_X_8; LP v_Y_6; 
LP v_X_5; LP v_Y_3; LP v_X_2; 
LP v_KEYS1083_1; LP v_INITIAL_2DVALUE_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
DYNAMIC_RESTIFY(v_KEYS1083_1,1,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_INITIAL_2DVALUE_0,LREF(s_key_INITIAL_2DVALUE),v_KEYS1083_1)
v_INITIAL_2DVALUE_0 = NIL;
END_KEY_INIT
END_VAR_ARGS;
v_X_2 = v_INITIAL_2DVALUE_0;
v_Y_3 = LREF(s_lsp_NIL);
v_Y_6 = (c_cons((v_INITIAL_2DVALUE_0), (LREF(s_lsp_NIL))));
v_X_17 = (c_cons((LREF(s_pcl_HEAD)), (v_Y_6)));
if (v_INITIAL_2DVALUE_0 != NIL) {
v_X_8 = LREF(k970);
} else {
v_X_8 = LREF(s_lsp_NIL);
}
v_Y_12 = (c_cons((v_X_8), (LREF(s_lsp_NIL))));
v_X_14 = (c_cons((LREF(s_pcl_TAIL)), (v_Y_12)));
v_Y_18 = (c_cons((v_X_14), (LREF(s_lsp_NIL))));
t1 = (c_cons((v_X_17), (v_Y_18)));
t0 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,3), LREF(s_lsp_LET_2A), t1, LREF(k972));
return(t0);
}

LP m_pcl_DOPLIST(argc, v_WHOLE1084_0, v_ENV_1)
      ARGC argc;  LP v_WHOLE1084_0; LP v_ENV_1;
{
LP v_Y_61; LP v_X_60; LP v_Y_58; 
LP v_X_57; LP v_Y_55; LP v_X_54; 
LP v_Y_52; LP v_X_51; LP v_Y_49; 
LP v_X_48; LP v_Y_46; LP v_X_45; 
LP v_Y_43; LP v_X_42; LP v_BOD_41; 
LP v_DECLS_40; LP v_DOC_39; LP v_BODY_38; 
LP v_PLIST_37; LP v_S1112_36; LP v_X_34; 
LP v_VALUE1111_33; LP v_X_31; LP v_LIST1110_30; 
LP v_VAL_29; LP v_S1109_28; LP v_X_26; 
LP v_VALUE1108_25; LP v_X_23; LP v_LIST1107_22; 
LP v_KEY_21; LP v_S1106_20; LP v_X_18; 
LP v_VALUE1105_17; LP v_X_15; LP v_LIST1104_14; 
LP v_L1100_13; LP v_S1103_12; LP v_X_10; 
LP v_VALUE1102_9; LP v_X_7; LP v_LIST1101_6; 
LP v_L1099_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE1084_0;
v_L1099_5 = ((LP) DEREF((v_WHOLE1084_0) + 1 * 4));
v_LIST1101_6 = v_L1099_5;
v_X_7 = v_LIST1101_6;
v_VALUE1102_9 = ((LP) DEREF((v_LIST1101_6) + 0 * 4));
v_X_10 = v_LIST1101_6;
v_S1103_12 = ((LP) DEREF((v_LIST1101_6) + 1 * 4));
v_L1099_5 = v_S1103_12;
v_L1100_13 = v_VALUE1102_9;
v_LIST1104_14 = v_L1100_13;
v_X_15 = v_LIST1104_14;
v_VALUE1105_17 = ((LP) DEREF((v_LIST1104_14) + 0 * 4));
v_X_18 = v_LIST1104_14;
v_S1106_20 = ((LP) DEREF((v_LIST1104_14) + 1 * 4));
v_L1100_13 = v_S1106_20;
v_KEY_21 = v_VALUE1105_17;
v_LIST1107_22 = v_L1100_13;
v_X_23 = v_LIST1107_22;
v_VALUE1108_25 = ((LP) DEREF((v_LIST1107_22) + 0 * 4));
v_X_26 = v_LIST1107_22;
v_S1109_28 = ((LP) DEREF((v_LIST1107_22) + 1 * 4));
v_L1100_13 = v_S1109_28;
v_VAL_29 = v_VALUE1108_25;
v_LIST1110_30 = v_L1099_5;
v_X_31 = v_LIST1110_30;
v_VALUE1111_33 = ((LP) DEREF((v_LIST1110_30) + 0 * 4));
v_X_34 = v_LIST1110_30;
v_S1112_36 = ((LP) DEREF((v_LIST1110_30) + 1 * 4));
v_L1099_5 = v_S1112_36;
v_PLIST_37 = v_VALUE1111_33;
v_BODY_38 = v_L1099_5;
{
int real_argc;
BEGIN_MV_CALL(mv_holder1009,0);
t0 = ICALL(s_pcl_EXTRACT_2DDECLARATIONS) (MV_CALL(mv_holder1009,2), v_BODY_38, v_ENV_1);
SET_MV_RETURN_VALUE(mv_holder1009,0,t0);
if SV_RETURN_P(mv_holder1009) SET_MV_RETURN_COUNT(mv_holder1009,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder1009);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_DOC_39 = NIL;
} else {
v_DOC_39 = NEXT_VAR_VALUE(mv_holder1009);
}
if (real_argc < 2) {
v_DECLS_40 = NIL;
} else {
v_DECLS_40 = NEXT_VAR_VALUE(mv_holder1009);
}
if (real_argc < 3) {
v_BOD_41 = NIL;
} else {
v_BOD_41 = NEXT_VAR_VALUE(mv_holder1009);
}
END_VAR_VALUES;
END_MV_CALL;
v_X_42 = v_PLIST_37;
v_Y_43 = LREF(s_lsp_NIL);
v_Y_46 = (c_cons((v_PLIST_37), (LREF(s_lsp_NIL))));
v_X_54 = (c_cons((LREF(s_pcl__2EPLIST_2DTAIL_2E)), (v_Y_46)));
v_X_48 = v_VAL_29;
v_Y_49 = LREF(s_lsp_NIL);
v_Y_52 = (c_cons((v_VAL_29), (LREF(s_lsp_NIL))));
v_Y_55 = (c_cons((v_KEY_21), (v_Y_52)));
t2 = (c_cons((v_X_54), (v_Y_55)));
t4 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_SETQ), v_KEY_21, LREF(k1016));
t5 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_SETQ), v_VAL_29, LREF(k1016));
v_X_57 = LREF(s_lsp_PROGN);
v_Y_58 = v_BOD_41;
t6 = (c_cons((LREF(s_lsp_PROGN)), (v_BOD_41)));
v_X_60 = ICALL(s_lsp_LIST) (6, LREF(s_lsp_LOOP), LREF(k1010), t4, LREF(k1018), t5, t6);
t7 = (c_cons((v_X_60), (LREF(s_lsp_NIL))));
t3 = ICALL(s_lsp_APPEND_2F2) (2, v_DECLS_40, t7);
t1 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,3), LREF(s_lsp_LET), t2, t3);
return(t1);
}
}

LP m_pcl_IF_2A(argc, v_WHOLE1113_0, v_ENV1114_1)
      ARGC argc;  LP v_WHOLE1113_0; LP v_ENV1114_1;
{
LP v_Y_24; LP v_X_23; LP v_FALSE_22; 
LP v_TRUE_21; LP v_S1128_20; LP v_X_18; 
LP v_VALUE1127_17; LP v_X_15; LP v_LIST1126_14; 
LP v_CONDITION_13; LP v_S1125_12; LP v_X_10; 
LP v_VALUE1124_9; LP v_X_7; LP v_LIST1123_6; 
LP v_L1122_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE1113_0;
v_L1122_5 = ((LP) DEREF((v_WHOLE1113_0) + 1 * 4));
v_LIST1123_6 = v_L1122_5;
v_X_7 = v_LIST1123_6;
v_VALUE1124_9 = ((LP) DEREF((v_LIST1123_6) + 0 * 4));
v_X_10 = v_LIST1123_6;
v_S1125_12 = ((LP) DEREF((v_LIST1123_6) + 1 * 4));
v_L1122_5 = v_S1125_12;
v_CONDITION_13 = v_VALUE1124_9;
v_LIST1126_14 = v_L1122_5;
v_X_15 = v_LIST1126_14;
v_VALUE1127_17 = ((LP) DEREF((v_LIST1126_14) + 0 * 4));
v_X_18 = v_LIST1126_14;
v_S1128_20 = ((LP) DEREF((v_LIST1126_14) + 1 * 4));
v_L1122_5 = v_S1128_20;
v_TRUE_21 = v_VALUE1127_17;
v_FALSE_22 = v_L1122_5;
v_X_23 = LREF(s_lsp_PROGN);
v_Y_24 = v_FALSE_22;
t1 = (c_cons((LREF(s_lsp_PROGN)), (v_FALSE_22)));
t0 = ICALL(s_lsp_LIST) (MV_CALL(argc,4), LREF(s_lsp_IF), v_CONDITION_13, v_TRUE_21, t1);
return(t0);
}

LP m_pcl_PRINTING_2DRANDOM_2DTHING(argc, v_WHOLE1129_0, v_ENV1130_1)
      ARGC argc;  LP v_WHOLE1129_0; LP v_ENV1130_1;
{
LP v_Y_127; LP v_X_126; LP v_Y_124; 
LP v_X_123; LP v_Y_121; LP v_X_120; 
LP v_X_118; LP v_V_116; LP v_X_115; 
LP v_NEW_2DCDR_113; LP v_C_112; LP v_Y_110; 
LP v_X_109; LP v_Y_107; LP v_X_106; 
LP v_Y_104; LP v_X_103; LP v_X_101; 
LP v_X_99; LP v_X_97; LP v_X_95; 
LP v_LOOPVAR_2D182_91; LP v_LOOPVAR_2D181_90; LP v_LOOPVAR_2D180_89; 
LP v_LOOP_2DLIST_2D179_88; LP v_L1173_87; LP v_LOOP_2DLIST_2D178_86; 
LP v_L1172_85; LP v_WRAPPED_2DBODY_84; LP v_Y_82; 
LP v_X_81; LP v_Y_79; LP v_X_78; 
LP v_Y_76; LP v_X_75; LP v_Y_73; 
LP v_X_72; LP v_Y_70; LP v_X_69; 
LP v_Y_67; LP v_X_66; LP v_STREAM_65; 
LP v_X_63; LP v_G1171_62; LP v_Y_60; 
LP v_X_59; LP v_X_57; LP v_X_55; 
LP v_X_53; LP v_G1170_52; LP v_X_50; 
LP v_G1169_49; LP v_S_47; LP v_S1168_46; 
LP v_Y_44; LP v_X_43; LP v_VALUE1167_42; 
LP v_S1166_41; LP v_Y_39; LP v_X_38; 
LP v_VALUE1165_37; LP v_S1162_36; LP v_X_34; 
LP v_X_33; LP v_S1164_32; LP v_S1163_31; 
LP v_BODY_30; LP v_STREAM_29; LP v_S1161_28; 
LP v_X_26; LP v_VALUE1160_25; LP v_X_23; 
LP v_LIST1159_22; LP v_THING_21; LP v_S1158_20; 
LP v_X_18; LP v_VALUE1157_17; LP v_X_15; 
LP v_LIST1156_14; LP v_L1152_13; LP v_S1155_12; 
LP v_X_10; LP v_VALUE1154_9; LP v_X_7; 
LP v_LIST1153_6; LP v_L1151_5; LP v_X_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE1129_0;
v_L1151_5 = ((LP) DEREF((v_WHOLE1129_0) + 1 * 4));
v_LIST1153_6 = v_L1151_5;
v_X_7 = v_LIST1153_6;
v_VALUE1154_9 = ((LP) DEREF((v_LIST1153_6) + 0 * 4));
v_X_10 = v_LIST1153_6;
v_S1155_12 = ((LP) DEREF((v_LIST1153_6) + 1 * 4));
v_L1151_5 = v_S1155_12;
v_L1152_13 = v_VALUE1154_9;
v_LIST1156_14 = v_L1152_13;
v_X_15 = v_LIST1156_14;
v_VALUE1157_17 = ((LP) DEREF((v_LIST1156_14) + 0 * 4));
v_X_18 = v_LIST1156_14;
v_S1158_20 = ((LP) DEREF((v_LIST1156_14) + 1 * 4));
v_L1152_13 = v_S1158_20;
v_THING_21 = v_VALUE1157_17;
v_LIST1159_22 = v_L1152_13;
v_X_23 = v_LIST1159_22;
v_VALUE1160_25 = ((LP) DEREF((v_LIST1159_22) + 0 * 4));
v_X_26 = v_LIST1159_22;
v_S1161_28 = ((LP) DEREF((v_LIST1159_22) + 1 * 4));
v_L1152_13 = v_S1161_28;
v_STREAM_29 = v_VALUE1160_25;
v_BODY_30 = v_L1151_5;
v_S1163_31 = LREF(s_lsp_NIL);
v_S1164_32 = LREF(s_lsp_NIL);
v_S_47 = v_STREAM_29;
v_G1169_49 = (OTHER_PTRP((v_STREAM_29)) && (TAG((v_STREAM_29)) == 3) ? T : NIL);
if (v_G1169_49 != NIL) {
t0 = v_G1169_49;
} else {
v_X_50 = v_STREAM_29;
v_G1170_52 = ((FIXNUMP((v_STREAM_29)) || (((HEADER((v_STREAM_29))) & 0x3) == 0x1)) ? T : NIL);
if (v_G1170_52 != NIL) {
t0 = v_G1170_52;
} else {
v_X_55 = v_STREAM_29;
v_X_57 = v_X_55;
v_X_59 = v_X_55;
v_Y_60 = LREF(s_lsp_NIL);
v_G1171_62 = (((v_X_55) == (LREF(s_lsp_NIL))) ? T : NIL);
if (v_G1171_62 != NIL) {
t1 = v_G1171_62;
} else {
v_X_63 = v_X_55;
t1 = (OTHER_PTRP((v_X_55)) && (TAG((v_X_55)) == 15) ? T : NIL);
}
if (t1 != NIL) {
v_X_53 = v_STREAM_29;
t2 = ((LP) DEREF((v_STREAM_29) + 0 * 4));
t0 = ICALL(s_lsp_MEMQL) (2, t2, LREF(k946));
} else {
t0 = LREF(s_lsp_NIL);
}
}
}
if (t0 != NIL) {
v_STREAM_65 = v_STREAM_29;
} else {
v_X_34 = LREF(s_lsp_NIL);
v_S1162_36 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(s_lsp_NIL));
v_VALUE1165_37 = v_S1162_36;
v_Y_39 = v_S1163_31;
v_S1166_41 = (c_cons((v_S1162_36), (v_Y_39)));
v_S1163_31 = v_S1166_41;
v_VALUE1167_42 = v_STREAM_29;
v_Y_44 = v_S1164_32;
v_S1168_46 = (c_cons((v_STREAM_29), (v_Y_44)));
v_S1164_32 = v_S1168_46;
v_STREAM_65 = v_S1162_36;
}
t3 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_FORMAT), v_STREAM_65, LREF(k1024));
v_X_81 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_FORMAT), v_STREAM_65, LREF(k1026));
v_X_66 = v_STREAM_65;
v_Y_67 = LREF(s_lsp_NIL);
v_Y_70 = (c_cons((v_STREAM_65), (LREF(s_lsp_NIL))));
v_Y_73 = (c_cons((v_THING_21), (v_Y_70)));
v_X_78 = (c_cons((LREF(s_pcl_PRINTING_2DRANDOM_2DTHING_2DINTERNAL)), (v_Y_73)));
v_X_75 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_FORMAT), v_STREAM_65, LREF(k1028));
v_Y_79 = (c_cons((v_X_75), (LREF(s_lsp_NIL))));
v_Y_82 = (c_cons((v_X_78), (v_Y_79)));
t5 = (c_cons((v_X_81), (v_Y_82)));
t4 = ICALL(s_lsp_APPEND_2F2) (2, v_BODY_30, t5);
v_WRAPPED_2DBODY_84 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_PROGN), t3, t4);
v_L1172_85 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D178_86 = ICALL(s_lsp_REVERSE) (1, v_S1163_31);
v_L1173_87 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D179_88 = ICALL(s_lsp_REVERSE) (1, v_S1164_32);
v_LOOPVAR_2D180_89 = LREF(s_lsp_NIL);
v_LOOPVAR_2D181_90 = LREF(s_lsp_NIL);
v_LOOPVAR_2D182_91 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_93:;
if (v_LOOP_2DLIST_2D178_86 == NIL) {
goto t_END_2DLOOP_94;
}
v_X_95 = v_LOOP_2DLIST_2D178_86;
v_L1172_85 = ((LP) DEREF((v_X_95) + 0 * 4));
v_X_97 = v_LOOP_2DLIST_2D178_86;
v_LOOP_2DLIST_2D178_86 = ((LP) DEREF((v_X_97) + 1 * 4));
if (v_LOOP_2DLIST_2D179_88 == NIL) {
goto t_END_2DLOOP_94;
}
v_X_99 = v_LOOP_2DLIST_2D179_88;
v_L1173_87 = ((LP) DEREF((v_X_99) + 0 * 4));
v_X_101 = v_LOOP_2DLIST_2D179_88;
v_LOOP_2DLIST_2D179_88 = ((LP) DEREF((v_X_101) + 1 * 4));
v_X_106 = v_L1172_85;
v_X_103 = v_L1173_87;
v_Y_107 = (c_cons((v_X_103), (LREF(s_lsp_NIL))));
v_X_109 = (c_cons((v_X_106), (v_Y_107)));
v_LOOPVAR_2D182_91 = (c_cons((v_X_109), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D181_90 != NIL) {
v_C_112 = v_LOOPVAR_2D181_90;
v_NEW_2DCDR_113 = v_LOOPVAR_2D182_91;
v_V_116 = v_NEW_2DCDR_113;
((LP) (DEREF((v_C_112) + 1 * 4) = (LD) (v_V_116)));
v_X_118 = v_C_112;
v_LOOPVAR_2D181_90 = ((LP) DEREF((v_X_118) + 1 * 4));
} else {
v_LOOPVAR_2D180_89 = v_LOOPVAR_2D182_91;
v_LOOPVAR_2D181_90 = v_LOOPVAR_2D180_89;
}
goto t_NEXT_2DLOOP_93;
goto t_END_2DLOOP_94;
t_END_2DLOOP_94:;
v_X_123 = v_LOOPVAR_2D180_89;
goto b_NIL_92;
v_X_123 = NIL;
v_X_123 = v_X_123;
b_NIL_92:;
v_X_120 = v_WRAPPED_2DBODY_84;
v_Y_121 = LREF(s_lsp_NIL);
v_Y_124 = (c_cons((v_WRAPPED_2DBODY_84), (LREF(s_lsp_NIL))));
v_Y_127 = (c_cons((v_X_123), (v_Y_124)));
t6 = (c_cons((LREF(s_lsp_LET)), (v_Y_127)));
return(t6);
}

LP p_pcl_PRINTING_2DRANDOM_2DTHING_2DINTERNAL(argc, v_THING_0, v_STREAM_1)
      ARGC argc;  LP v_THING_0; LP v_STREAM_1;
{

LP t0; 
if (argc != 2) wna(argc,2);
return(LREF(s_lsp_NIL));
}

LP p_pcl_CAPITALIZE_2DWORDS(va_alist) va_dcl
{
LP v_T1184_19; LP v_T1183_18; LP v_S1182_17; 
LP v_T1181_16; LP v_T1180_15; LP v_S1179_14; 
LP v_T1178_13; LP v_T1177_12; LP v_S1176_11; 
LP v_I_8; LP v_CHAR_7; LP v_LENGTH_6; 
LP v_FLAG_5; LP v_STRING_3; LP v_STRING_0; 
LP v_DASHES_2DP_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_STRING_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_DASHES_2DP_1 = LREF(s_lsp_T);
} else {
v_DASHES_2DP_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t0 = ICALL(s_lsp_STRING) (1, v_STRING_0);
v_STRING_3 = ICALL(s_lsp_COPY_2DSEQ) (1, t0);
v_FLAG_5 = LREF(s_lsp_T);
v_LENGTH_6 = ICALL(s_lsp_LENGTH) (1, v_STRING_3);
v_CHAR_7 = LREF(s_lsp_NIL);
v_I_8 = (LP) 0;
goto t_TEST1174_10;
t_LOOP1175_9:;
v_I_8 = (add((v_I_8), ((LP) 2)));
t_TEST1174_10:;
t2 = (num_equal_p((v_I_8), (v_LENGTH_6)));
if (t2 != NIL) {
return(v_STRING_3);
return(NIL);
}
v_CHAR_7 = ICALL(s_lsp_ELT) (2, v_STRING_3, v_I_8);
t3 = ICALL(s_lsp_BOTH_2DCASE_2DP) (1, v_CHAR_7);
if (t3 != NIL) {
if (v_FLAG_5 != NIL) {
v_FLAG_5 = ICALL(s_lsp_LOWER_2DCASE_2DP) (1, v_CHAR_7);
if (v_FLAG_5 != NIL) {
v_S1176_11 = ICALL(s_lsp_CHAR_2DUPCASE) (1, v_CHAR_7);
v_T1177_12 = v_STRING_3;
v_T1178_13 = v_I_8;
ICALL(s_lsp_SET_2DELT) (3, v_STRING_3, v_T1178_13, v_S1176_11);
}
} else {
if (v_FLAG_5 == NIL) {
v_S1179_14 = ICALL(s_lsp_CHAR_2DDOWNCASE) (1, v_CHAR_7);
v_T1180_15 = v_STRING_3;
v_T1181_16 = v_I_8;
ICALL(s_lsp_SET_2DELT) (3, v_STRING_3, v_T1181_16, v_S1179_14);
}
}
v_FLAG_5 = LREF(s_lsp_NIL);
} else {
t4 = ICALL(s_lsp_CHAR_2DEQUAL) (2, v_CHAR_7, LREF(char_tab[45]));
if (t4 != NIL) {
v_FLAG_5 = LREF(s_lsp_T);
if (v_DASHES_2DP_1 == NIL) {
v_S1182_17 = LREF(char_tab[32]);
v_T1183_18 = v_STRING_3;
v_T1184_19 = v_I_8;
ICALL(s_lsp_SET_2DELT) (3, v_STRING_3, v_T1184_19, LREF(char_tab[32]));
}
} else {
v_FLAG_5 = LREF(s_lsp_NIL);
}
}
goto t_LOOP1175_9;
return(NIL);
}

LP p_pcl_LEGAL_2DCLASS_2DNAME_2DP(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{
LP v_S_7; LP v_Y_5; LP v_X_4; 
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 

if (argc != 1) wna(argc,1);
v_S_7 = v_X_0;
if (OTHER_PTRP((v_X_0)) && (TAG((v_X_0)) == 3)) {
v_X_2 = ICALL(s_lsp_KEYWORDP) (1, v_X_0);
v_X_4 = v_X_2;
v_Y_5 = LREF(s_lsp_NIL);
t0 = (((v_X_2) == (LREF(s_lsp_NIL))) ? T : NIL);
return(t0);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_pcl_FIND_2DCLASS(va_alist) va_dcl
{
LP v_G1185_6; LP v_SYMBOL_4; LP v_SYMBOL_0; 
LP v_ENVIRONMENT_2; LP v_ERRORP_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_SYMBOL_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 3) wna_high(real_argc,3);
if (real_argc < 2) {
v_ERRORP_1 = LREF(s_lsp_T);
} else {
v_ERRORP_1 = NEXT_VAR_ARG;
}
if (real_argc < 3) {
v_ENVIRONMENT_2 = NIL;
} else {
v_ENVIRONMENT_2 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
v_SYMBOL_4 = LREF(s_pcl__2AFIND_2DCLASS_2A);
t0 = ((LP) DEREF((LREF(s_pcl__2AFIND_2DCLASS_2A)) + 0 * 4));
v_G1185_6 = ICALL(s_lsp_GETHASH) (2, v_SYMBOL_0, t0);
if (v_G1185_6 != NIL) {
return(v_G1185_6);
} else {
if (v_ERRORP_1 != NIL) {
t2 = ICALL(s_pcl_LEGAL_2DCLASS_2DNAME_2DP) (1, v_SYMBOL_0);
if (t2 != NIL) {
t1 = ICALL(s_lsp_ERROR) (MV_CALL(argc,2), LREF(k1030), v_SYMBOL_0);
return(t1);
} else {
t1 = ICALL(s_lsp_ERROR) (MV_CALL(argc,2), LREF(k1031), v_SYMBOL_0);
return(t1);
}
} else {
return(LREF(s_lsp_NIL));
}
}
}

LP p_pcl_SETF_20PCL_20FIND_2DCLASS(argc, v_NEW_2DVALUE_0, v_SYMBOL_1)
      ARGC argc;  LP v_NEW_2DVALUE_0; LP v_SYMBOL_1;
{
LP v_T1188_7; LP v_SYMBOL_5; LP v_T1187_4; 
LP v_S1186_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 2) wna(argc,2);
t1 = ICALL(s_pcl_LEGAL_2DCLASS_2DNAME_2DP) (1, v_SYMBOL_1);
if (t1 != NIL) {
v_S1186_3 = v_NEW_2DVALUE_0;
v_T1187_4 = v_SYMBOL_1;
v_SYMBOL_5 = LREF(s_pcl__2AFIND_2DCLASS_2A);
v_T1188_7 = ((LP) DEREF((LREF(s_pcl__2AFIND_2DCLASS_2A)) + 0 * 4));
t0 = ICALL(s_lsp_SET_2DGETHASH) (MV_CALL(argc,3), v_SYMBOL_1, v_T1188_7, v_NEW_2DVALUE_0);
return(t0);
} else {
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,2), LREF(k1031), v_SYMBOL_1);
return(t0);
}
}

LP p_pcl_FIND_2DWRAPPER(argc, v_SYMBOL_0)
      ARGC argc;  LP v_SYMBOL_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t1 = ICALL(s_pcl_FIND_2DCLASS) (1, v_SYMBOL_0);
t0 = ICALL(s_pcl_CLASS_2DWRAPPER) (MV_CALL(argc,1), t1);
return(t0);
}

LP m_pcl_GATHERING1(argc, v_WHOLE1189_0, v_ENV1190_1)
      ARGC argc;  LP v_WHOLE1189_0; LP v_ENV1190_1;
{
LP v_Y_31; LP v_X_30; LP v_Y_28; 
LP v_X_27; LP v_Y_25; LP v_X_24; 
LP v_Y_22; LP v_X_21; LP v_Y_19; 
LP v_X_18; LP v_Y_16; LP v_X_15; 
LP v_BODY_14; LP v_GATHERER_13; LP v_S1198_12; 
LP v_X_10; LP v_VALUE1197_9; LP v_X_7; 
LP v_LIST1196_6; LP v_L1195_5; LP v_X_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE1189_0;
v_L1195_5 = ((LP) DEREF((v_WHOLE1189_0) + 1 * 4));
v_LIST1196_6 = v_L1195_5;
v_X_7 = v_LIST1196_6;
v_VALUE1197_9 = ((LP) DEREF((v_LIST1196_6) + 0 * 4));
v_X_10 = v_LIST1196_6;
v_S1198_12 = ((LP) DEREF((v_LIST1196_6) + 1 * 4));
v_L1195_5 = v_S1198_12;
v_GATHERER_13 = v_VALUE1197_9;
v_BODY_14 = v_L1195_5;
v_X_15 = v_GATHERER_13;
v_Y_16 = LREF(s_lsp_NIL);
v_Y_19 = (c_cons((v_GATHERER_13), (LREF(s_lsp_NIL))));
v_X_21 = (c_cons((LREF(s_pcl__2EGATHERING1_2E)), (v_Y_19)));
v_X_27 = (c_cons((v_X_21), (LREF(s_lsp_NIL))));
v_X_24 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_MACROLET), LREF(k1032), v_BODY_14);
v_Y_28 = (c_cons((v_X_24), (LREF(s_lsp_NIL))));
v_Y_31 = (c_cons((v_X_27), (v_Y_28)));
t0 = (c_cons((LREF(s_iterate_GATHERING)), (v_Y_31)));
return(t0);
}

LP m_pcl_VECTORIZING(argc, v_WHOLE1199_0, v_ENV1200_1)
      ARGC argc;  LP v_WHOLE1199_0; LP v_ENV1200_1;
{
LP v_L1202_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE1199_0;
v_L1202_5 = ((LP) DEREF((v_WHOLE1199_0) + 1 * 4));
t0 = p_lsp_APPLY(MV_CALL(argc,2), COERCE_TO_FUNCTION(LREF(k1048)), v_L1202_5);
return(t0);
}

LP p_pcl_VECTORIZING_2Danon10461047(va_alist) va_dcl
{
LP v_Y_9; LP v_X_8; LP v_Y_6; 
LP v_X_5; LP v_Y_3; LP v_X_2; 
LP v_KEYS1203_1; LP v_SIZE_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
DYNAMIC_RESTIFY(v_KEYS1203_1,1,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_SIZE_0,LREF(s_key_SIZE),v_KEYS1203_1)
v_SIZE_0 = (LP) 0;
END_KEY_INIT
END_VAR_ARGS;
v_X_2 = v_SIZE_0;
v_Y_3 = LREF(s_lsp_NIL);
v_Y_6 = (c_cons((v_SIZE_0), (LREF(s_lsp_NIL))));
v_X_8 = (c_cons((LREF(s_pcl_LIMIT)), (v_Y_6)));
t1 = (c_cons((v_X_8), (LREF(k1049))));
t0 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,3), LREF(s_lsp_LET_2A), t1, LREF(k1057));
return(t0);
}

LP m_pcl__2ALIST_2DELEMENTS(argc, v_WHOLE1204_0, v_ENV1205_1)
      ARGC argc;  LP v_WHOLE1204_0; LP v_ENV1205_1;
{
LP v_LIST_13; LP v_S1213_12; LP v_X_10; 
LP v_VALUE1212_9; LP v_X_7; LP v_LIST1211_6; 
LP v_L1210_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 2) wna(argc,2);
t0 = NEW_OE(1);
v_X_3 = v_WHOLE1204_0;
v_L1210_5 = ((LP) DEREF((v_WHOLE1204_0) + 1 * 4));
v_LIST1211_6 = v_L1210_5;
v_X_7 = v_LIST1211_6;
v_VALUE1212_9 = ((LP) DEREF((v_LIST1211_6) + 0 * 4));
v_X_10 = v_LIST1211_6;
v_S1213_12 = ((LP) DEREF((v_LIST1211_6) + 1 * 4));
v_L1210_5 = v_S1213_12;
v_LIST_13 = v_VALUE1212_9;
SET_OE_SLOT(t0,0,v_LIST_13);
t2 = MAKE_CLOSURE(p_pcl__2ALIST_2DELEMENTS_2Danon10891090,t0);
t1 = p_lsp_APPLY(MV_CALL(argc,2), COERCE_TO_FUNCTION(t2), v_L1210_5);
return(t1);
}

LP p_pcl__2ALIST_2DELEMENTS_2Danon10891090(va_alist) va_dcl
{
LP v_Y_53; LP v_X_52; LP v_Y_50; 
LP v_X_49; LP v_Y_47; LP v_X_46; 
LP v_Y_44; LP v_X_43; LP v_Y_41; 
LP v_X_40; LP v_Y_38; LP v_X_37; 
LP v_Y_35; LP v_X_34; LP v_Y_32; 
LP v_X_31; LP v_Y_29; LP v_X_28; 
LP v_Y_26; LP v_X_25; LP v_Y_23; 
LP v_X_22; LP v_Y_20; LP v_X_19; 
LP v_Y_17; LP v_X_16; LP v_Y_14; 
LP v_X_13; LP v_Y_11; LP v_X_10; 
LP v_Y_8; LP v_X_7; LP v_Y_5; 
LP v_X_4; LP v_KEYS1214_3; LP v_X_1; 
LP v_BY_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


t0 = OE;
real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
DYNAMIC_RESTIFY(v_KEYS1214_3,1,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_BY_0,LREF(s_key_BY),v_KEYS1214_3)
v_X_1 = LREF(s_lsp_CDR);
t1 = ((LP) DEREF((v_X_1) + 4 * 4));
v_BY_0 = t1;
END_KEY_INIT
END_VAR_ARGS;
v_X_4 = GET_OE_SLOT(t0,0);
v_Y_5 = LREF(s_lsp_NIL);
v_Y_8 = (c_cons((GET_OE_SLOT(t0,0)), (LREF(s_lsp_NIL))));
v_X_10 = (c_cons((LREF(s_pcl_TAIL)), (v_Y_8)));
v_X_49 = (c_cons((v_X_10), (LREF(s_lsp_NIL))));
v_X_13 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_FUNCALL), v_BY_0, LREF(k1092));
v_Y_17 = (c_cons((v_X_13), (LREF(s_lsp_NIL))));
v_Y_20 = (c_cons((LREF(s_pcl_TAIL)), (v_Y_17)));
v_X_22 = (c_cons((LREF(s_lsp_SETQ)), (v_Y_20)));
v_Y_26 = (c_cons((v_X_22), (LREF(s_lsp_NIL))));
v_Y_29 = (c_cons((LREF(k1095)), (v_Y_26)));
t2 = (c_cons((LREF(s_lsp_PROG1)), (v_Y_29)));
v_X_31 = ICALL(s_lsp_LIST) (4, LREF(s_lsp_IF), LREF(k1091), LREF(k1093), t2);
v_Y_35 = (c_cons((v_X_31), (LREF(s_lsp_NIL))));
v_Y_38 = (c_cons((LREF(k1094)), (v_Y_35)));
v_X_40 = (c_cons((LREF(s_lsp_LAMBDA)), (v_Y_38)));
v_Y_44 = (c_cons((v_X_40), (LREF(s_lsp_NIL))));
v_X_46 = (c_cons((LREF(s_lsp_FUNCTION)), (v_Y_44)));
v_Y_50 = (c_cons((v_X_46), (LREF(s_lsp_NIL))));
v_Y_53 = (c_cons((v_X_49), (v_Y_50)));
t3 = (c_cons((LREF(s_lsp_LET)), (v_Y_53)));
return(t3);
}

LP m_pcl__2ALIST_2DTAILS(argc, v_WHOLE1215_0, v_ENV1216_1)
      ARGC argc;  LP v_WHOLE1215_0; LP v_ENV1216_1;
{
LP v_LIST_13; LP v_S1224_12; LP v_X_10; 
LP v_VALUE1223_9; LP v_X_7; LP v_LIST1222_6; 
LP v_L1221_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 2) wna(argc,2);
t0 = NEW_OE(1);
v_X_3 = v_WHOLE1215_0;
v_L1221_5 = ((LP) DEREF((v_WHOLE1215_0) + 1 * 4));
v_LIST1222_6 = v_L1221_5;
v_X_7 = v_LIST1222_6;
v_VALUE1223_9 = ((LP) DEREF((v_LIST1222_6) + 0 * 4));
v_X_10 = v_LIST1222_6;
v_S1224_12 = ((LP) DEREF((v_LIST1222_6) + 1 * 4));
v_L1221_5 = v_S1224_12;
v_LIST_13 = v_VALUE1223_9;
SET_OE_SLOT(t0,0,v_LIST_13);
t2 = MAKE_CLOSURE(p_pcl__2ALIST_2DTAILS_2Danon10961097,t0);
t1 = p_lsp_APPLY(MV_CALL(argc,2), COERCE_TO_FUNCTION(t2), v_L1221_5);
return(t1);
}

LP p_pcl__2ALIST_2DTAILS_2Danon10961097(va_alist) va_dcl
{
LP v_Y_53; LP v_X_52; LP v_Y_50; 
LP v_X_49; LP v_Y_47; LP v_X_46; 
LP v_Y_44; LP v_X_43; LP v_Y_41; 
LP v_X_40; LP v_Y_38; LP v_X_37; 
LP v_Y_35; LP v_X_34; LP v_Y_32; 
LP v_X_31; LP v_Y_29; LP v_X_28; 
LP v_Y_26; LP v_X_25; LP v_Y_23; 
LP v_X_22; LP v_Y_20; LP v_X_19; 
LP v_Y_17; LP v_X_16; LP v_Y_14; 
LP v_X_13; LP v_Y_11; LP v_X_10; 
LP v_Y_8; LP v_X_7; LP v_Y_5; 
LP v_X_4; LP v_KEYS1225_3; LP v_X_1; 
LP v_BY_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


t0 = OE;
real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
DYNAMIC_RESTIFY(v_KEYS1225_3,1,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_BY_0,LREF(s_key_BY),v_KEYS1225_3)
v_X_1 = LREF(s_lsp_CDR);
t1 = ((LP) DEREF((v_X_1) + 4 * 4));
v_BY_0 = t1;
END_KEY_INIT
END_VAR_ARGS;
v_X_4 = GET_OE_SLOT(t0,0);
v_Y_5 = LREF(s_lsp_NIL);
v_Y_8 = (c_cons((GET_OE_SLOT(t0,0)), (LREF(s_lsp_NIL))));
v_X_10 = (c_cons((LREF(s_pcl_TAIL)), (v_Y_8)));
v_X_49 = (c_cons((v_X_10), (LREF(s_lsp_NIL))));
v_X_13 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_FUNCALL), v_BY_0, LREF(k1092));
v_Y_17 = (c_cons((v_X_13), (LREF(s_lsp_NIL))));
v_Y_20 = (c_cons((LREF(s_pcl_TAIL)), (v_Y_17)));
v_X_22 = (c_cons((LREF(s_lsp_SETQ)), (v_Y_20)));
v_Y_26 = (c_cons((v_X_22), (LREF(s_lsp_NIL))));
v_Y_29 = (c_cons((LREF(k1098)), (v_Y_26)));
v_X_31 = (c_cons((LREF(s_lsp_PROG1)), (v_Y_29)));
v_Y_35 = (c_cons((v_X_31), (LREF(s_lsp_NIL))));
v_Y_38 = (c_cons((LREF(k1094)), (v_Y_35)));
v_X_40 = (c_cons((LREF(s_lsp_LAMBDA)), (v_Y_38)));
v_Y_44 = (c_cons((v_X_40), (LREF(s_lsp_NIL))));
v_X_46 = (c_cons((LREF(s_lsp_FUNCTION)), (v_Y_44)));
v_Y_50 = (c_cons((v_X_46), (LREF(s_lsp_NIL))));
v_Y_53 = (c_cons((v_X_49), (v_Y_50)));
t2 = (c_cons((LREF(s_lsp_LET)), (v_Y_53)));
return(t2);
}

LP p_pcl_MACROS_5FINIT187(argc)
      ARGC argc; 
{
LP v_X_48; LP v_X_46; LP v_X_44; 
LP v_X_42; LP v_REHASH_2DTHRESHOLD_40; LP v_REHASH_2DSIZE_39; 
LP v_SIZE_38; LP v_TEST_37; LP v_X_35; 
LP v_REHASH_2DTHRESHOLD_34; LP v_REHASH_2DSIZE_33; LP v_SIZE_32; 
LP v_X_30; LP v_TEST_29; LP v_X_27; 
LP v_X_25; LP v_X_23; LP v_X_21; 
LP v_X_19; LP v_X_17; LP v_X_15; 
LP v_X_13; LP v_X_11; LP v_X_9; 
LP v_X_7; LP v_X_5; LP v_X_3; 
LP v_X_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; 
if (argc != 0) wna(argc,0);
v_X_1 = LREF(s_pcl_MEMQ);
t0 = ((LP) DEREF((LREF(s_pcl_MEMQ)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_pcl_MEMQ), t0);
v_X_3 = LREF(s_pcl_ASSQ);
t1 = ((LP) DEREF((LREF(s_pcl_ASSQ)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_pcl_ASSQ), t1);
v_X_5 = LREF(s_pcl_RASSQ);
t2 = ((LP) DEREF((LREF(s_pcl_RASSQ)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_pcl_RASSQ), t2);
v_X_7 = LREF(s_pcl_DELQ);
t3 = ((LP) DEREF((LREF(s_pcl_DELQ)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_pcl_DELQ), t3);
v_X_9 = LREF(s_pcl_POSQ);
t4 = ((LP) DEREF((LREF(s_pcl_POSQ)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_pcl_POSQ), t4);
v_X_11 = LREF(s_pcl_NEQ);
t5 = ((LP) DEREF((LREF(s_pcl_NEQ)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_pcl_NEQ), t5);
v_X_13 = LREF(s_pcl_ONCE_2DONLY);
t6 = ((LP) DEREF((LREF(s_pcl_ONCE_2DONLY)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_pcl_ONCE_2DONLY), t6);
t7 = ICALL(s_lsp_FIND_2DPACKAGE) (1, LREF(s_lsp_KEYWORD));
ICALL(s_lsp_DEFINE_2DVARIABLE) (4, LREF(s_pcl__2AKEYWORD_2DPACKAGE_2A), t7, LREF(s_lsp_NIL), LREF(s_key_VAR));
v_X_15 = LREF(s_pcl_CHECK_2DMEMBER);
t8 = ((LP) DEREF((LREF(s_pcl_CHECK_2DMEMBER)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_pcl_CHECK_2DMEMBER), t8);
v_X_17 = LREF(s_pcl_ALIST_2DENTRY);
t9 = ((LP) DEREF((LREF(s_pcl_ALIST_2DENTRY)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_pcl_ALIST_2DENTRY), t9);
v_X_19 = LREF(s_pcl_DESTRUCTURING_2DBIND);
t10 = ((LP) DEREF((LREF(s_pcl_DESTRUCTURING_2DBIND)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_pcl_DESTRUCTURING_2DBIND), t10);
v_X_21 = LREF(s_pcl_COLLECTING_2DONCE);
t11 = ((LP) DEREF((LREF(s_pcl_COLLECTING_2DONCE)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_pcl_COLLECTING_2DONCE), t11);
v_X_23 = LREF(s_pcl_DOPLIST);
t12 = ((LP) DEREF((LREF(s_pcl_DOPLIST)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_pcl_DOPLIST), t12);
v_X_25 = LREF(s_pcl_IF_2A);
t13 = ((LP) DEREF((LREF(s_pcl_IF_2A)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_pcl_IF_2A), t13);
v_X_27 = LREF(s_pcl_PRINTING_2DRANDOM_2DTHING);
t14 = ((LP) DEREF((LREF(s_pcl_PRINTING_2DRANDOM_2DTHING)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_pcl_PRINTING_2DRANDOM_2DTHING), t14);
v_X_35 = LREF(s_lsp_EQ);
v_TEST_37 = ((LP) DEREF((LREF(s_lsp_EQ)) + 4 * 4));
t15 = ICALL(s_lsp_MAKE_2DHASH_2DTABLE_2D1) (4, v_TEST_37, (LP) 130, LREF(k1105), LREF(k1106));
ICALL(s_lsp_DEFINE_2DVARIABLE) (4, LREF(s_pcl__2AFIND_2DCLASS_2A), t15, LREF(s_lsp_NIL), LREF(s_key_VAR));
ICALL(s_lsp_DEFINE_2DSETF) (2, LREF(s_pcl_FIND_2DCLASS), LREF(k1107));
v_X_42 = LREF(s_pcl_GATHERING1);
t16 = ((LP) DEREF((LREF(s_pcl_GATHERING1)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_pcl_GATHERING1), t16);
v_X_44 = LREF(s_pcl_VECTORIZING);
t17 = ((LP) DEREF((LREF(s_pcl_VECTORIZING)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_pcl_VECTORIZING), t17);
v_X_46 = LREF(s_pcl__2ALIST_2DELEMENTS);
t18 = ((LP) DEREF((LREF(s_pcl__2ALIST_2DELEMENTS)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_pcl__2ALIST_2DELEMENTS), t18);
v_X_48 = LREF(s_pcl__2ALIST_2DTAILS);
t20 = ((LP) DEREF((LREF(s_pcl__2ALIST_2DTAILS)) + 4 * 4));
t19 = ICALL(s_lsp_DEFINE_2DMACRO) (MV_CALL(argc,2), LREF(s_pcl__2ALIST_2DTAILS), t20);
return(t19);
}

LP p_pcl_MACROS_5FINIT187_2Danon11011102(argc, v_ACCESS_0, v_ENV_1)
      ARGC argc;  LP v_ACCESS_0; LP v_ENV_1;
{
LP v_Y_45; LP v_X_44; LP v_X_42; 
LP v_LIST_40; LP v_Y_38; LP v_X_37; 
LP v_X_35; LP v_TVARS_34; LP v_SVAR_33; 
LP v_X_31; LP v_V_29; LP v_X_28; 
LP v_NEW_2DCDR_26; LP v_C_25; LP v_Y_23; 
LP v_X_22; LP v_X_20; LP v_X_19; 
LP v_X_17; LP v_X_15; LP v_LOOPVAR_2D191_11; 
LP v_LOOPVAR_2D190_10; LP v_LOOPVAR_2D189_9; LP v_LOOP_2DLIST_2D188_8; 
LP v_ARG_7; LP v_X_5; LP v_X_3; 
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; 
if (argc != 2) wna(argc,2);
v_X_3 = LREF(k1108);
v_SVAR_33 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(k1108));
v_ARG_7 = LREF(s_lsp_NIL);
v_X_5 = v_ACCESS_0;
v_LOOP_2DLIST_2D188_8 = ((LP) DEREF((v_ACCESS_0) + 1 * 4));
v_LOOPVAR_2D189_9 = LREF(s_lsp_NIL);
v_LOOPVAR_2D190_10 = LREF(s_lsp_NIL);
v_LOOPVAR_2D191_11 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_13:;
if (v_LOOP_2DLIST_2D188_8 == NIL) {
goto t_END_2DLOOP_14;
}
v_X_15 = v_LOOP_2DLIST_2D188_8;
v_ARG_7 = ((LP) DEREF((v_X_15) + 0 * 4));
v_X_17 = v_LOOP_2DLIST_2D188_8;
v_LOOP_2DLIST_2D188_8 = ((LP) DEREF((v_X_17) + 1 * 4));
v_X_20 = LREF(k1109);
v_X_22 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(k1109));
v_LOOPVAR_2D191_11 = (c_cons((v_X_22), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D190_10 != NIL) {
v_C_25 = v_LOOPVAR_2D190_10;
v_NEW_2DCDR_26 = v_LOOPVAR_2D191_11;
v_V_29 = v_NEW_2DCDR_26;
((LP) (DEREF((v_C_25) + 1 * 4) = (LD) (v_V_29)));
v_X_31 = v_C_25;
v_LOOPVAR_2D190_10 = ((LP) DEREF((v_X_31) + 1 * 4));
} else {
v_LOOPVAR_2D189_9 = v_LOOPVAR_2D191_11;
v_LOOPVAR_2D190_10 = v_LOOPVAR_2D189_9;
}
goto t_NEXT_2DLOOP_13;
goto t_END_2DLOOP_14;
t_END_2DLOOP_14:;
v_TVARS_34 = v_LOOPVAR_2D189_9;
goto b_NIL_12;
v_TVARS_34 = NIL;
v_TVARS_34 = v_TVARS_34;
b_NIL_12:;
v_X_35 = v_ACCESS_0;
t0 = ((LP) DEREF((v_ACCESS_0) + 1 * 4));
v_X_37 = v_SVAR_33;
v_Y_38 = LREF(s_lsp_NIL);
t1 = (c_cons((v_SVAR_33), (LREF(s_lsp_NIL))));
t2 = p_lsp_APPLY(3, COERCE_TO_FUNCTION(LREF(k1110)), v_SVAR_33, v_TVARS_34);
v_LIST_40 = v_ACCESS_0;
v_X_42 = v_ACCESS_0;
v_X_44 = ((LP) DEREF((v_ACCESS_0) + 0 * 4));
t3 = (c_cons((v_X_44), (v_TVARS_34)));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,5);
SET_MV_RETURN_VALUE(argc,1,t0);
SET_MV_RETURN_VALUE(argc,2,t1);
SET_MV_RETURN_VALUE(argc,3,t2);
SET_MV_RETURN_VALUE(argc,4,t3);
}
return(v_TVARS_34);
}

LP p_pcl_MACROS_5FINIT187_2Danon11011102MACROS_5FINIT187_2Danon11031104(va_alist) va_dcl
{
LP v_Y_11; LP v_X_10; LP v_Y_8; 
LP v_X_7; LP v_Y_5; LP v_X_4; 
LP v_SYMBOL_1; LP v_NEW_2DVALUE_0; LP v_ENVIRONMENT_3; 
LP v_ERRORP_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_NEW_2DVALUE_0 = NEXT_VAR_ARG;
v_SYMBOL_1 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 2) wna_low(real_argc,2);
if (real_argc > 4) wna_high(real_argc,4);
if (real_argc < 3) {
v_ERRORP_2 = LREF(s_lsp_T);
} else {
v_ERRORP_2 = NEXT_VAR_ARG;
}
if (real_argc < 4) {
v_ENVIRONMENT_3 = NIL;
} else {
v_ENVIRONMENT_3 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
v_X_4 = v_SYMBOL_1;
v_Y_5 = LREF(s_lsp_NIL);
v_Y_8 = (c_cons((v_SYMBOL_1), (LREF(s_lsp_NIL))));
v_Y_11 = (c_cons((v_NEW_2DVALUE_0), (v_Y_8)));
t0 = (c_cons((LREF(s_pcl_SETF_20PCL_20FIND_2DCLASS)), (v_Y_11)));
return(t0);
}

