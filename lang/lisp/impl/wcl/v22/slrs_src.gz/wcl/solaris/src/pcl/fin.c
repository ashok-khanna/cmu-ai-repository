/*
:comment "Compiled at 12:31:46 pm on Sunday, June 12, 1994"
:comment "Compiler Configuration: DEFAULT"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w -g -O "
:version 0
:package (IN-PACKAGE (QUOTE PCL)) 
:end-package-info 0
:sym QUOTE
:sym FUNCALLABLE-INSTANCE-DATA
:sym NIL
:sym WRAPPER
:sym SLOTS
:sym :TEST
:sym EQ
:sym POSITION
:sym WARN
:sym ERROR
:sym FUNCTION
:sym LIST*
:sm FUNCALLABLE-INSTANCE-DATA-POSITION "m_pcl_FUNCALLABLE_2DINSTANCE_2DDATA_2DPOSITION"
:sf CALLED-FIN-WITHOUT-FUNCTION "p_pcl_CALLED_2DFIN_2DWITHOUT_2DFUNCTION"
:proclaim (QUOTE (INLINE FIN-REF))
:sf FIN-REF "p_pcl_FIN_2DREF"
:proclaim (QUOTE (INLINE SET-FIN-REF))
:sf SET-FIN-REF "p_pcl_SET_2DFIN_2DREF"
:proclaim (QUOTE (INLINE FUNCALLABLE-INSTANCE-P))
:sf FUNCALLABLE-INSTANCE-P "p_pcl_FUNCALLABLE_2DINSTANCE_2DP"
:sf DEFAULT-FUNCALLABLE-INSTANCE-FUNCTION "p_pcl_DEFAULT_2DFUNCALLABLE_2DINSTANCE_2DFUNCTION"
:sym DEFAULT-FUNCALLABLE-INSTANCE-FUNCTION
:sym SET-FUNCALLABLE-INSTANCE-FUNCTION
:sf ALLOCATE-FUNCALLABLE-INSTANCE-1 "p_pcl_ALLOCATE_2DFUNCALLABLE_2DINSTANCE_2D1"
:sf MAKE-TRAMPOLINE "p_pcl_MAKE_2DTRAMPOLINE"
:proclaim (QUOTE (INLINE COPY-PROCEDURE-CODE-POINTER))
:sf COPY-PROCEDURE-CODE-POINTER "p_pcl_COPY_2DPROCEDURE_2DCODE_2DPOINTER"
:sym MAKE-TRAMPOLINE
:sf SET-FUNCALLABLE-INSTANCE-FUNCTION "p_pcl_SET_2DFUNCALLABLE_2DINSTANCE_2DFUNCTION"
:sym LISP::QUOTED-CONSTANT-P
:sym FIN-REF
:sm FUNCALLABLE-INSTANCE-DATA-1 "m_pcl_FUNCALLABLE_2DINSTANCE_2DDATA_2D1"
:sym FUNCALLABLE-INSTANCE-P
:sm FSC-INSTANCE-P "m_pcl_FSC_2DINSTANCE_2DP"
:sym FUNCALLABLE-INSTANCE-DATA-1
:sym WRAPPER-CLASS
:sm FSC-INSTANCE-CLASS "m_pcl_FSC_2DINSTANCE_2DCLASS"
:sm FSC-INSTANCE-WRAPPER "m_pcl_FSC_2DINSTANCE_2DWRAPPER"
:sm FSC-INSTANCE-SLOTS "m_pcl_FSC_2DINSTANCE_2DSLOTS"
:sym ALLOCATE-FUNCALLABLE-INSTANCE-1
:sym *SLOT-UNBOUND*
:sym LISP::MAKE-SIMPLE-ARRAY
:sf ALLOCATE-FUNCALLABLE-INSTANCE "p_pcl_ALLOCATE_2DFUNCALLABLE_2DINSTANCE"
:sym :CONSTANT
:sym LISP::DEFINE-VARIABLE
:sym FUNCALLABLE-INSTANCE-DATA-POSITION
:sym LISP::DEFINE-MACRO
:sym SET-FIN-REF
:sym LISP::DEFINE-SETF
:sym FSC-INSTANCE-P
:sym FSC-INSTANCE-CLASS
:sym FSC-INSTANCE-WRAPPER
:sym FSC-INSTANCE-SLOTS
:sf FIN_INIT215 "p_pcl_FIN_5FINIT215"
:init FIN_INIT215
:pinfo PCL::FUNCALLABLE-INSTANCE-P (PCL::X) NIL NIL NIL (LAMBDA (PCL::X) (DECLARE) (BLOCK PCL::FUNCALLABLE-INSTANCE-P (AND (%TAG= PCL::X TYPE-PROCEDURE) (%EQ (%OBJECT-LENGTH PCL::X) FUNCALLABLE-INSTANCE-FLAG)))) NIL T T
:pinfo PCL::ALLOCATE-FUNCALLABLE-INSTANCE (PCL::WRAPPER PCL::NUMBER-OF-STATIC-SLOTS) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::SET-FUNCALLABLE-INSTANCE-FUNCTION (PCL::FIN PCL::NEW-PROCEDURE) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::FIN-REF (PCL::FIN PCL::I) NIL NIL NIL (LAMBDA (PCL::FIN PCL::I) (DECLARE) (BLOCK PCL::FIN-REF (%32BIT-REF PCL::FIN PCL::I))) NIL T T
:pinfo PCL::DEFAULT-FUNCALLABLE-INSTANCE-FUNCTION (&REST PCL::ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::SET-FIN-REF (PCL::FIN PCL::I PCL::VALUE) NIL NIL NIL (LAMBDA (PCL::FIN PCL::I PCL::VALUE) (DECLARE) (BLOCK PCL::SET-FIN-REF (%32BIT-DEF PCL::FIN PCL::I PCL::VALUE) PCL::VALUE)) NIL T T
:pinfo PCL::FIN_INIT215 NIL NIL NIL NIL NIL NIL NIL T
:pinfo PCL::CALLED-FIN-WITHOUT-FUNCTION NIL NIL NIL NIL NIL NIL NIL T
:pinfo PCL::ALLOCATE-FUNCALLABLE-INSTANCE-1 NIL NIL NIL NIL NIL NIL NIL T
:pinfo PCL::MAKE-TRAMPOLINE (FUNCTION) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::COPY-PROCEDURE-CODE-POINTER (PCL::DEST-PROC PCL::SRC-PROC) NIL NIL NIL (LAMBDA (PCL::DEST-PROC PCL::SRC-PROC) (DECLARE) (BLOCK PCL::COPY-PROCEDURE-CODE-POINTER (%32BIT-DEF PCL::DEST-PROC 0 (%32BIT-REF PCL::SRC-PROC 0)))) NIL T T
:end
*/

#include "lisp.h"

extern LP m_pcl_FUNCALLABLE_2DINSTANCE_2DDATA_2DPOSITION();
extern SYMBOL s_lsp_QUOTE; 
extern SYMBOL s_pcl_FUNCALLABLE_2DINSTANCE_2DDATA; 
extern SYMBOL s_lsp_NIL; 
extern SYMBOL s_pcl_WRAPPER; 
extern SYMBOL s_pcl_SLOTS; 
MAKE_CONS(k1174,LREF(s_pcl_SLOTS),LREF(s_lsp_NIL));
MAKE_CONS(k1173,LREF(s_pcl_WRAPPER),LREF(k1174));
extern SYMBOL s_key_TEST; 
extern SYMBOL s_lsp_EQ; 
extern SYMBOL s_lsp_POSITION; 
MAKE_SIMPLE_STRING(k1175,38,"Unknown funcallable-instance data: ~S.");
extern SYMBOL s_lsp_WARN; 
extern SYMBOL s_lsp_ERROR; 
extern SYMBOL s_lsp_FUNCTION; 
MAKE_CONS(k1180,LREF(s_lsp_EQ),LREF(s_lsp_NIL));
MAKE_CONS(k1179,LREF(s_lsp_FUNCTION),LREF(k1180));
MAKE_CONS(k1178,LREF(k1179),LREF(s_lsp_NIL));
MAKE_CONS(k1177,LREF(s_key_TEST),LREF(k1178));
MAKE_CONS(k1176,LREF(s_pcl_FUNCALLABLE_2DINSTANCE_2DDATA),LREF(k1177));
extern SYMBOL s_lsp_LIST_2A; 
extern LP p_pcl_CALLED_2DFIN_2DWITHOUT_2DFUNCTION();
static struct {unsigned long header; char string[111+1];}
k1181  = {((111 << 8) + TYPE_SIMPLE_STRING), 
"Attempt to funcall a funcallable-instance without first~%~\n          setting its funcallable-instance-function."};
extern LP p_pcl_FIN_2DREF();
extern LP p_pcl_SET_2DFIN_2DREF();
extern LP p_pcl_FUNCALLABLE_2DINSTANCE_2DP();
extern LP p_pcl_DEFAULT_2DFUNCALLABLE_2DINSTANCE_2DFUNCTION();
MAKE_SIMPLE_STRING(k1182,61,"Default funcallable instance handler called with args ~{~A ~}");
extern LP p_pcl_ALLOCATE_2DFUNCALLABLE_2DINSTANCE_2D1();
extern SYMBOL s_pcl_DEFAULT_2DFUNCALLABLE_2DINSTANCE_2DFUNCTION; 
extern SYMBOL s_pcl_SET_2DFUNCALLABLE_2DINSTANCE_2DFUNCTION; 
extern LP p_pcl_MAKE_2DTRAMPOLINE();
extern LP p_pcl_MAKE_2DTRAMPOLINE_2Danon11831184();
extern LP p_pcl_COPY_2DPROCEDURE_2DCODE_2DPOINTER();
extern LP p_pcl_SET_2DFUNCALLABLE_2DINSTANCE_2DFUNCTION();
extern SYMBOL s_pcl_MAKE_2DTRAMPOLINE; 
MAKE_SIMPLE_STRING(k1185,20,"~A is not a function");
MAKE_SIMPLE_STRING(k1186,32,"~A is not a funcallable-instance");
extern LP m_pcl_FUNCALLABLE_2DINSTANCE_2DDATA_2D1();
extern SYMBOL s_lsp_QUOTED_2DCONSTANT_2DP; 
extern SYMBOL s_pcl_FIN_2DREF; 
MAKE_SIMPLE_STRING(k1187,30,"data-name ~A is not a constant");
extern LP m_pcl_FSC_2DINSTANCE_2DP();
extern SYMBOL s_pcl_FUNCALLABLE_2DINSTANCE_2DP; 
extern LP m_pcl_FSC_2DINSTANCE_2DCLASS();
extern SYMBOL s_pcl_FUNCALLABLE_2DINSTANCE_2DDATA_2D1; 
MAKE_CONS(k1190,LREF(s_pcl_WRAPPER),LREF(s_lsp_NIL));
MAKE_CONS(k1189,LREF(s_lsp_QUOTE),LREF(k1190));
MAKE_CONS(k1188,LREF(k1189),LREF(s_lsp_NIL));
extern SYMBOL s_pcl_WRAPPER_2DCLASS; 
extern LP m_pcl_FSC_2DINSTANCE_2DWRAPPER();
extern LP m_pcl_FSC_2DINSTANCE_2DSLOTS();
MAKE_CONS(k1192,LREF(s_lsp_QUOTE),LREF(k1174));
MAKE_CONS(k1191,LREF(k1192),LREF(s_lsp_NIL));
extern LP p_pcl_ALLOCATE_2DFUNCALLABLE_2DINSTANCE();
extern SYMBOL s_pcl_ALLOCATE_2DFUNCALLABLE_2DINSTANCE_2D1; 
extern SYMBOL s_pcl__2ASLOT_2DUNBOUND_2A; 
extern SYMBOL s_lsp_MAKE_2DSIMPLE_2DARRAY; 
extern LP p_pcl_FIN_5FINIT215();
static struct {unsigned long header; char string[158+1];}
k1193  = {((158 << 8) + TYPE_SIMPLE_STRING), 
"These are the 'data-slots' which funcallable instances have so that\n   the meta-class funcallable-standard-class can store class, and static\n   slots in them."};
extern SYMBOL s_key_CONSTANT; 
extern SYMBOL s_lsp_DEFINE_2DVARIABLE; 
extern SYMBOL s_pcl_FUNCALLABLE_2DINSTANCE_2DDATA_2DPOSITION; 
extern SYMBOL s_lsp_DEFINE_2DMACRO; 
extern SYMBOL s_pcl_SET_2DFIN_2DREF; 
extern SYMBOL s_lsp_DEFINE_2DSETF; 
extern SYMBOL s_pcl_FSC_2DINSTANCE_2DP; 
extern SYMBOL s_pcl_FSC_2DINSTANCE_2DCLASS; 
extern SYMBOL s_pcl_FSC_2DINSTANCE_2DWRAPPER; 
extern SYMBOL s_pcl_FSC_2DINSTANCE_2DSLOTS; 


extern LP add();
extern LP alloc_words();
extern LP c_cons();


LP m_pcl_FUNCALLABLE_2DINSTANCE_2DDATA_2DPOSITION(argc, v_WHOLE1355_0, v_ENV1356_1)
      ARGC argc;  LP v_WHOLE1355_0; LP v_ENV1356_1;
{
LP v_X_57; LP v_Y_55; LP v_X_54; 
LP v_X_52; LP v_S_50; LP v_Y_48; 
LP v_X_47; LP v_Y_45; LP v_X_44; 
LP v_Y_42; LP v_X_41; LP v_Y_39; 
LP v_X_38; LP v_Y_36; LP v_X_35; 
LP v_X_33; LP v_X_31; LP v_C_29; 
LP v_X_27; LP v_X_25; LP v_C_23; 
LP v_G1366_22; LP v_X_20; LP v_X_18; 
LP v_X_16; LP v_C_14; LP v_DATA_13; 
LP v_S1365_12; LP v_X_10; LP v_VALUE1364_9; 
LP v_X_7; LP v_LIST1363_6; LP v_L1362_5; 
LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE1355_0;
v_L1362_5 = ((LP) DEREF((v_WHOLE1355_0) + 1 * 4));
v_LIST1363_6 = v_L1362_5;
v_X_7 = v_LIST1363_6;
v_VALUE1364_9 = ((LP) DEREF((v_LIST1363_6) + 0 * 4));
v_X_10 = v_LIST1363_6;
v_S1365_12 = ((LP) DEREF((v_LIST1363_6) + 1 * 4));
v_L1362_5 = v_S1365_12;
v_DATA_13 = v_VALUE1364_9;
v_X_57 = v_DATA_13;
if (OTHER_PTRP((v_DATA_13)) && (TAG((v_DATA_13)) == 15)) {
v_X_52 = v_DATA_13;
v_X_54 = ((LP) DEREF((v_DATA_13) + 0 * 4));
if (((v_X_54) == (LREF(s_lsp_QUOTE)))) {
v_S_50 = LREF(s_pcl_FUNCALLABLE_2DINSTANCE_2DDATA);
t1 = ((LDREF((LREF(s_pcl_FUNCALLABLE_2DINSTANCE_2DDATA)),SYMBOL,value) != UBV_MARKER) ? T : NIL);
} else {
t1 = LREF(s_lsp_NIL);
}
} else {
t1 = LREF(s_lsp_NIL);
}
if (t1 != NIL) {
v_C_14 = v_DATA_13;
v_X_16 = v_DATA_13;
v_X_18 = ((LP) DEREF((v_DATA_13) + 1 * 4));
t4 = ((LP) DEREF((v_X_18) + 0 * 4));
v_X_20 = LREF(s_lsp_EQ);
t5 = ((LP) DEREF((LREF(s_lsp_EQ)) + 4 * 4));
v_G1366_22 = ICALL(s_lsp_POSITION) (4, t4, LREF(k1173), LREF(s_key_TEST), t5);
if (v_G1366_22 != NIL) {
return(v_G1366_22);
} else {
v_C_23 = v_DATA_13;
v_X_25 = v_DATA_13;
v_X_27 = ((LP) DEREF((v_DATA_13) + 1 * 4));
t6 = ((LP) DEREF((v_X_27) + 0 * 4));
ICALL(s_lsp_WARN) (2, LREF(k1175), t6);
v_C_29 = v_DATA_13;
v_X_31 = v_DATA_13;
v_X_33 = ((LP) DEREF((v_DATA_13) + 1 * 4));
v_X_35 = ((LP) DEREF((v_X_33) + 0 * 4));
v_Y_39 = (c_cons((v_X_35), (LREF(s_lsp_NIL))));
v_X_41 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_39)));
v_Y_45 = (c_cons((v_X_41), (LREF(s_lsp_NIL))));
v_Y_48 = (c_cons((LREF(k1175)), (v_Y_45)));
t0 = (c_cons((LREF(s_lsp_ERROR)), (v_Y_48)));
return(t0);
}
} else {
t0 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,3), LREF(s_lsp_POSITION), v_DATA_13, LREF(k1176));
return(t0);
}
}

LP p_pcl_CALLED_2DFIN_2DWITHOUT_2DFUNCTION(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,1), LREF(k1181));
return(t0);
}

LP p_pcl_FIN_2DREF(argc, v_FIN_0, v_I_1)
      ARGC argc;  LP v_FIN_0; LP v_I_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = ((LP) DEREF((v_FIN_0) + FX_TO_INT(v_I_1) * 4));
return(t0);
}

LP p_pcl_SET_2DFIN_2DREF(argc, v_FIN_0, v_I_1, v_VALUE_2)
      ARGC argc;  LP v_FIN_0; LP v_I_1; LP v_VALUE_2;
{

LP t0; LP t1; 
if (argc != 3) wna(argc,3);
((LP) (DEREF((v_FIN_0) + FX_TO_INT(v_I_1) * 4) = (LD) (v_VALUE_2)));
return(v_VALUE_2);
}

LP p_pcl_FUNCALLABLE_2DINSTANCE_2DP(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
if (argc != 1) wna(argc,1);
if (OTHER_PTRP((v_X_0)) && (TAG((v_X_0)) == 39)) {
t2 = INT_TO_FX((LP) (DEREF((v_X_0) - 4) >> 8));
t0 = (((t2) == ((LP) 11356)) ? T : NIL);
return(t0);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_pcl_DEFAULT_2DFUNCALLABLE_2DINSTANCE_2DFUNCTION(va_alist) va_dcl
{
LP v_ARGS_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,2), LREF(k1182), v_ARGS_0);
return(t0);
}

LP p_pcl_ALLOCATE_2DFUNCALLABLE_2DINSTANCE_2D1(argc)
      ARGC argc; 
{
LP v_VALUE_19; LP v_I_18; LP v_FIN_17; 
LP v_T1372_16; LP v_T1371_15; LP v_S1370_14; 
LP v_VALUE_12; LP v_I_11; LP v_FIN_10; 
LP v_T1369_9; LP v_T1368_8; LP v_S1367_7; 
LP v_X_5; LP v_FLAG_3; LP v_P_2; 
LP v_FIN_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; 
if (argc != 0) wna(argc,0);
v_FIN_1 = (alloc_words(3, 39));
v_P_2 = v_FIN_1;
v_FLAG_3 = (LP) 11356;
((LP) ((HEADER((v_FIN_1)) = TAG((v_FIN_1)) + (5678 << 8))));
v_X_5 = LREF(s_pcl_DEFAULT_2DFUNCALLABLE_2DINSTANCE_2DFUNCTION);
t0 = ((LP) DEREF((LREF(s_pcl_DEFAULT_2DFUNCALLABLE_2DINSTANCE_2DFUNCTION)) + 4 * 4));
ICALL(s_pcl_SET_2DFUNCALLABLE_2DINSTANCE_2DFUNCTION) (2, v_FIN_1, t0);
v_S1367_7 = LREF(s_lsp_NIL);
v_T1368_8 = v_FIN_1;
v_T1369_9 = (LP) 2;
v_VALUE_12 = LREF(s_lsp_NIL);
((LP) (DEREF((v_FIN_1) + 1 * 4) = (LD) (v_VALUE_12)));
v_S1370_14 = LREF(s_lsp_NIL);
v_T1371_15 = v_FIN_1;
v_T1372_16 = (LP) 4;
v_VALUE_19 = LREF(s_lsp_NIL);
((LP) (DEREF((v_FIN_1) + 2 * 4) = (LD) (v_VALUE_19)));
return(v_FIN_1);
}

LP p_pcl_MAKE_2DTRAMPOLINE(argc, v_FUNCTION_0)
      ARGC argc;  LP v_FUNCTION_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = NEW_OE(1);
SET_OE_SLOT(t0,0,v_FUNCTION_0);
t1 = MAKE_CLOSURE(p_pcl_MAKE_2DTRAMPOLINE_2Danon11831184,t0);
return(t1);
}

LP p_pcl_MAKE_2DTRAMPOLINE_2Danon11831184(va_alist) va_dcl
{
LP v_ARGS_0; 
LP t0; LP t1; LP t2; LP t3; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


t0 = OE;
real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
t1 = p_lsp_APPLY(MV_CALL(argc,2), COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)), v_ARGS_0);
return(t1);
}

LP p_pcl_COPY_2DPROCEDURE_2DCODE_2DPOINTER(argc, v_DEST_2DPROC_0, v_SRC_2DPROC_1)
      ARGC argc;  LP v_DEST_2DPROC_0; LP v_SRC_2DPROC_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 2) wna(argc,2);
t1 = ((LP) DEREF((v_SRC_2DPROC_1) + 0 * 4));
t0 = ((LP) (DEREF((v_DEST_2DPROC_0) + 0 * 4) = (LD) (t1)));
return(t0);
}

LP p_pcl_SET_2DFUNCALLABLE_2DINSTANCE_2DFUNCTION(argc, v_FIN_0, v_NEW_2DPROCEDURE_1)
      ARGC argc;  LP v_FIN_0; LP v_NEW_2DPROCEDURE_1;
{
LP v_X_13; LP v_X_11; LP v_S_9; 
LP v_SRC_2DPROC_7; LP v_DEST_2DPROC_6; LP v_SRC_2DPROC_4; 
LP v_DEST_2DPROC_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; 
if (argc != 2) wna(argc,2);
v_X_13 = v_FIN_0;
if (OTHER_PTRP((v_X_13)) && (TAG((v_X_13)) == 39)) {
t2 = INT_TO_FX((LP) (DEREF((v_X_13) - 4) >> 8));
t0 = (((t2) == ((LP) 11356)) ? T : NIL);
} else {
t0 = LREF(s_lsp_NIL);
}
if (t0 != NIL) {
v_X_11 = v_NEW_2DPROCEDURE_1;
if (OTHER_PTRP((v_NEW_2DPROCEDURE_1)) && (TAG((v_NEW_2DPROCEDURE_1)) == 39)) {
v_DEST_2DPROC_3 = v_FIN_0;
v_SRC_2DPROC_4 = v_NEW_2DPROCEDURE_1;
t4 = ((LP) DEREF((v_NEW_2DPROCEDURE_1) + 0 * 4));
((LP) (DEREF((v_FIN_0) + 0 * 4) = (LD) (t4)));
} else {
v_S_9 = v_NEW_2DPROCEDURE_1;
if (OTHER_PTRP((v_NEW_2DPROCEDURE_1)) && (TAG((v_NEW_2DPROCEDURE_1)) == 3)) {
v_SRC_2DPROC_7 = ICALL(s_pcl_MAKE_2DTRAMPOLINE) (1, v_NEW_2DPROCEDURE_1);
t6 = ((LP) DEREF((v_SRC_2DPROC_7) + 0 * 4));
((LP) (DEREF((v_FIN_0) + 0 * 4) = (LD) (t6)));
} else {
ICALL(s_lsp_ERROR) (2, LREF(k1185), v_NEW_2DPROCEDURE_1);
}
}
} else {
ICALL(s_lsp_ERROR) (2, LREF(k1186), v_FIN_0);
}
return(v_FIN_0);
}

LP m_pcl_FUNCALLABLE_2DINSTANCE_2DDATA_2D1(argc, v_WHOLE1373_0, v_ENV1374_1)
      ARGC argc;  LP v_WHOLE1373_0; LP v_ENV1374_1;
{
LP v_Y_41; LP v_X_40; LP v_Y_38; 
LP v_X_37; LP v_Y_35; LP v_X_34; 
LP v_X_32; LP v_X_30; LP v_X_28; 
LP v_X_26; LP v_C_24; LP v_LIST_22; 
LP v_DATA_2DNAME_21; LP v_S1388_20; LP v_X_18; 
LP v_VALUE1387_17; LP v_X_15; LP v_LIST1386_14; 
LP v_FIN_13; LP v_S1385_12; LP v_X_10; 
LP v_VALUE1384_9; LP v_X_7; LP v_LIST1383_6; 
LP v_L1382_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE1373_0;
v_L1382_5 = ((LP) DEREF((v_WHOLE1373_0) + 1 * 4));
v_LIST1383_6 = v_L1382_5;
v_X_7 = v_LIST1383_6;
v_VALUE1384_9 = ((LP) DEREF((v_LIST1383_6) + 0 * 4));
v_X_10 = v_LIST1383_6;
v_S1385_12 = ((LP) DEREF((v_LIST1383_6) + 1 * 4));
v_L1382_5 = v_S1385_12;
v_FIN_13 = v_VALUE1384_9;
v_LIST1386_14 = v_L1382_5;
v_X_15 = v_LIST1386_14;
v_VALUE1387_17 = ((LP) DEREF((v_LIST1386_14) + 0 * 4));
v_X_18 = v_LIST1386_14;
v_S1388_20 = ((LP) DEREF((v_LIST1386_14) + 1 * 4));
v_L1382_5 = v_S1388_20;
v_DATA_2DNAME_21 = v_VALUE1387_17;
t1 = ICALL(s_lsp_QUOTED_2DCONSTANT_2DP) (1, v_DATA_2DNAME_21);
if (t1 != NIL) {
v_LIST_22 = v_DATA_2DNAME_21;
v_C_24 = v_DATA_2DNAME_21;
v_X_26 = v_DATA_2DNAME_21;
v_X_28 = ((LP) DEREF((v_DATA_2DNAME_21) + 1 * 4));
t2 = ((LP) DEREF((v_X_28) + 0 * 4));
v_X_30 = LREF(s_lsp_EQ);
t3 = ((LP) DEREF((LREF(s_lsp_EQ)) + 4 * 4));
v_X_32 = ICALL(s_lsp_POSITION) (4, t2, LREF(k1173), LREF(s_key_TEST), t3);
v_X_34 = (add((v_X_32), ((LP) 2)));
v_Y_38 = (c_cons((v_X_34), (LREF(s_lsp_NIL))));
v_Y_41 = (c_cons((v_FIN_13), (v_Y_38)));
t0 = (c_cons((LREF(s_pcl_FIN_2DREF)), (v_Y_41)));
return(t0);
} else {
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,2), LREF(k1187), v_DATA_2DNAME_21);
return(t0);
}
}

LP m_pcl_FSC_2DINSTANCE_2DP(argc, v_WHOLE1389_0, v_ENV1390_1)
      ARGC argc;  LP v_WHOLE1389_0; LP v_ENV1390_1;
{
LP v_Y_18; LP v_X_17; LP v_Y_15; 
LP v_X_14; LP v_FIN_13; LP v_S1398_12; 
LP v_X_10; LP v_VALUE1397_9; LP v_X_7; 
LP v_LIST1396_6; LP v_L1395_5; LP v_X_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE1389_0;
v_L1395_5 = ((LP) DEREF((v_WHOLE1389_0) + 1 * 4));
v_LIST1396_6 = v_L1395_5;
v_X_7 = v_LIST1396_6;
v_VALUE1397_9 = ((LP) DEREF((v_LIST1396_6) + 0 * 4));
v_X_10 = v_LIST1396_6;
v_S1398_12 = ((LP) DEREF((v_LIST1396_6) + 1 * 4));
v_L1395_5 = v_S1398_12;
v_FIN_13 = v_VALUE1397_9;
v_X_14 = v_FIN_13;
v_Y_15 = LREF(s_lsp_NIL);
v_Y_18 = (c_cons((v_FIN_13), (LREF(s_lsp_NIL))));
t0 = (c_cons((LREF(s_pcl_FUNCALLABLE_2DINSTANCE_2DP)), (v_Y_18)));
return(t0);
}

LP m_pcl_FSC_2DINSTANCE_2DCLASS(argc, v_WHOLE1399_0, v_ENV1400_1)
      ARGC argc;  LP v_WHOLE1399_0; LP v_ENV1400_1;
{
LP v_Y_18; LP v_X_17; LP v_Y_15; 
LP v_X_14; LP v_FIN_13; LP v_S1408_12; 
LP v_X_10; LP v_VALUE1407_9; LP v_X_7; 
LP v_LIST1406_6; LP v_L1405_5; LP v_X_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE1399_0;
v_L1405_5 = ((LP) DEREF((v_WHOLE1399_0) + 1 * 4));
v_LIST1406_6 = v_L1405_5;
v_X_7 = v_LIST1406_6;
v_VALUE1407_9 = ((LP) DEREF((v_LIST1406_6) + 0 * 4));
v_X_10 = v_LIST1406_6;
v_S1408_12 = ((LP) DEREF((v_LIST1406_6) + 1 * 4));
v_L1405_5 = v_S1408_12;
v_FIN_13 = v_VALUE1407_9;
v_X_14 = ICALL(s_lsp_LIST_2A) (3, LREF(s_pcl_FUNCALLABLE_2DINSTANCE_2DDATA_2D1), v_FIN_13, LREF(k1188));
v_Y_18 = (c_cons((v_X_14), (LREF(s_lsp_NIL))));
t0 = (c_cons((LREF(s_pcl_WRAPPER_2DCLASS)), (v_Y_18)));
return(t0);
}

LP m_pcl_FSC_2DINSTANCE_2DWRAPPER(argc, v_WHOLE1409_0, v_ENV1410_1)
      ARGC argc;  LP v_WHOLE1409_0; LP v_ENV1410_1;
{
LP v_FIN_13; LP v_S1418_12; LP v_X_10; 
LP v_VALUE1417_9; LP v_X_7; LP v_LIST1416_6; 
LP v_L1415_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE1409_0;
v_L1415_5 = ((LP) DEREF((v_WHOLE1409_0) + 1 * 4));
v_LIST1416_6 = v_L1415_5;
v_X_7 = v_LIST1416_6;
v_VALUE1417_9 = ((LP) DEREF((v_LIST1416_6) + 0 * 4));
v_X_10 = v_LIST1416_6;
v_S1418_12 = ((LP) DEREF((v_LIST1416_6) + 1 * 4));
v_L1415_5 = v_S1418_12;
v_FIN_13 = v_VALUE1417_9;
t0 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,3), LREF(s_pcl_FUNCALLABLE_2DINSTANCE_2DDATA_2D1), v_FIN_13, LREF(k1188));
return(t0);
}

LP m_pcl_FSC_2DINSTANCE_2DSLOTS(argc, v_WHOLE1419_0, v_ENV1420_1)
      ARGC argc;  LP v_WHOLE1419_0; LP v_ENV1420_1;
{
LP v_FIN_13; LP v_S1428_12; LP v_X_10; 
LP v_VALUE1427_9; LP v_X_7; LP v_LIST1426_6; 
LP v_L1425_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE1419_0;
v_L1425_5 = ((LP) DEREF((v_WHOLE1419_0) + 1 * 4));
v_LIST1426_6 = v_L1425_5;
v_X_7 = v_LIST1426_6;
v_VALUE1427_9 = ((LP) DEREF((v_LIST1426_6) + 0 * 4));
v_X_10 = v_LIST1426_6;
v_S1428_12 = ((LP) DEREF((v_LIST1426_6) + 1 * 4));
v_L1425_5 = v_S1428_12;
v_FIN_13 = v_VALUE1427_9;
t0 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,3), LREF(s_pcl_FUNCALLABLE_2DINSTANCE_2DDATA_2D1), v_FIN_13, LREF(k1191));
return(t0);
}

LP p_pcl_ALLOCATE_2DFUNCALLABLE_2DINSTANCE(argc, v_WRAPPER_0, v_NUMBER_2DOF_2DSTATIC_2DSLOTS_1)
      ARGC argc;  LP v_WRAPPER_0; LP v_NUMBER_2DOF_2DSTATIC_2DSLOTS_1;
{
LP v_VALUE_19; LP v_I_18; LP v_FIN_17; 
LP v_T1434_16; LP v_T1433_15; LP v_S1432_14; 
LP v_VALUE_12; LP v_I_11; LP v_FIN_10; 
LP v_T1431_9; LP v_T1430_8; LP v_S1429_7; 
LP v_SLOTS_6; LP v_FIN_5; LP v_SYMBOL_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
if (argc != 2) wna(argc,2);
v_FIN_5 = ICALL(s_pcl_ALLOCATE_2DFUNCALLABLE_2DINSTANCE_2D1) (0);
v_SYMBOL_3 = LREF(s_pcl__2ASLOT_2DUNBOUND_2A);
t0 = ((LP) DEREF((LREF(s_pcl__2ASLOT_2DUNBOUND_2A)) + 0 * 4));
v_SLOTS_6 = ICALL(s_lsp_MAKE_2DSIMPLE_2DARRAY) (5, v_NUMBER_2DOF_2DSTATIC_2DSLOTS_1, (LP) 128, (LP) 64, t0, LREF(s_lsp_NIL));
v_S1429_7 = v_WRAPPER_0;
v_T1430_8 = v_FIN_5;
v_T1431_9 = (LP) 2;
v_VALUE_12 = v_WRAPPER_0;
((LP) (DEREF((v_FIN_5) + 1 * 4) = (LD) (v_VALUE_12)));
v_S1432_14 = v_SLOTS_6;
v_T1433_15 = v_FIN_5;
v_T1434_16 = (LP) 4;
v_VALUE_19 = v_SLOTS_6;
((LP) (DEREF((v_FIN_5) + 2 * 4) = (LD) (v_VALUE_19)));
return(v_FIN_5);
}

LP p_pcl_FIN_5FINIT215(argc)
      ARGC argc; 
{
LP v_X_11; LP v_X_9; LP v_X_7; 
LP v_X_5; LP v_X_3; LP v_X_1; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; 
if (argc != 0) wna(argc,0);
ICALL(s_lsp_DEFINE_2DVARIABLE) (4, LREF(s_pcl_FUNCALLABLE_2DINSTANCE_2DDATA), LREF(k1173), LREF(k1193), LREF(s_key_CONSTANT));
v_X_1 = LREF(s_pcl_FUNCALLABLE_2DINSTANCE_2DDATA_2DPOSITION);
t0 = ((LP) DEREF((LREF(s_pcl_FUNCALLABLE_2DINSTANCE_2DDATA_2DPOSITION)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_pcl_FUNCALLABLE_2DINSTANCE_2DDATA_2DPOSITION), t0);
ICALL(s_lsp_DEFINE_2DSETF) (2, LREF(s_pcl_FIN_2DREF), LREF(s_pcl_SET_2DFIN_2DREF));
v_X_3 = LREF(s_pcl_FUNCALLABLE_2DINSTANCE_2DDATA_2D1);
t1 = ((LP) DEREF((LREF(s_pcl_FUNCALLABLE_2DINSTANCE_2DDATA_2D1)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_pcl_FUNCALLABLE_2DINSTANCE_2DDATA_2D1), t1);
v_X_5 = LREF(s_pcl_FSC_2DINSTANCE_2DP);
t2 = ((LP) DEREF((LREF(s_pcl_FSC_2DINSTANCE_2DP)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_pcl_FSC_2DINSTANCE_2DP), t2);
v_X_7 = LREF(s_pcl_FSC_2DINSTANCE_2DCLASS);
t3 = ((LP) DEREF((LREF(s_pcl_FSC_2DINSTANCE_2DCLASS)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_pcl_FSC_2DINSTANCE_2DCLASS), t3);
v_X_9 = LREF(s_pcl_FSC_2DINSTANCE_2DWRAPPER);
t4 = ((LP) DEREF((LREF(s_pcl_FSC_2DINSTANCE_2DWRAPPER)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_pcl_FSC_2DINSTANCE_2DWRAPPER), t4);
v_X_11 = LREF(s_pcl_FSC_2DINSTANCE_2DSLOTS);
t6 = ((LP) DEREF((LREF(s_pcl_FSC_2DINSTANCE_2DSLOTS)) + 4 * 4));
t5 = ICALL(s_lsp_DEFINE_2DMACRO) (MV_CALL(argc,2), LREF(s_pcl_FSC_2DINSTANCE_2DSLOTS), t6);
return(t5);
}

