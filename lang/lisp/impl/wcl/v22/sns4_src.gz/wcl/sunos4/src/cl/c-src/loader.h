/*  (C) Copyright 1990-1993 by Wade L. Hennessey. All rights reserved. */

/* DELETE THIS FILE????? */

void init_loader( char *a0);
extern unsigned load_file(char *fileName);
long symbol_value(char *symbol);

/* Debug:

add-file <name> <text start>

*/
