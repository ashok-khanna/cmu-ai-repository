/*
:comment "Compiled at 6:22:18 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: DEFAULT"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O "
:version 0
:package (IN-PACKAGE (QUOTE PCL)) 
:end-package-info 0
:sym PRINT-OBJECT
:sf PRINT-STD-INSTANCE "p_pcl_PRINT_2DSTD_2DINSTANCE"
:sym T
:sym FIX-EARLY-GENERIC-FUNCTIONS
:sym COMPLETE
:sym *BOOT-STATE*
:sf FIXUP_INIT1447 "p_pcl_FIXUP_5FINIT1447"
:init FIXUP_INIT1447
:pinfo PCL::FIXUP_INIT1447 NIL NIL NIL NIL NIL NIL NIL T
:pinfo PCL::PRINT-STD-INSTANCE (PCL::INSTANCE STREAM PCL::DEPTH) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_pcl_PRINT_2DSTD_2DINSTANCE();
extern SYMBOL s_pcl_PRINT_2DOBJECT; 
extern LP p_pcl_FIXUP_5FINIT1447();
extern SYMBOL s_lsp_T; 
extern SYMBOL s_pcl_FIX_2DEARLY_2DGENERIC_2DFUNCTIONS; 
extern SYMBOL s_pcl_COMPLETE; 
extern SYMBOL s_pcl__2ABOOT_2DSTATE_2A; 




LP p_pcl_PRINT_2DSTD_2DINSTANCE(argc, v_INSTANCE_0, v_STREAM_1, v_DEPTH_2)
      ARGC argc;  LP v_INSTANCE_0; LP v_STREAM_1; LP v_DEPTH_2;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 3) wna(argc,3);
t0 = ICALL(s_pcl_PRINT_2DOBJECT) (MV_CALL(argc,2), v_INSTANCE_0, v_STREAM_1);
return(t0);
}

LP p_pcl_FIXUP_5FINIT1447(argc)
      ARGC argc; 
{
LP v_V_2; LP v_X_1; 
LP t0; LP t1; LP t2; 
if (argc != 0) wna(argc,0);
ICALL(s_pcl_FIX_2DEARLY_2DGENERIC_2DFUNCTIONS) (1, LREF(s_lsp_T));
v_V_2 = LREF(s_pcl_COMPLETE);
((LP) (DEREF((LREF(s_pcl__2ABOOT_2DSTATE_2A)) + 0 * 4) = (LD) (v_V_2)));
return(v_V_2);
}

