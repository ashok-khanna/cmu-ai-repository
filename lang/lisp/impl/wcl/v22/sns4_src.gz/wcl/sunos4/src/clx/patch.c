/*
:comment "Compiled at 5:50:27 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: Debug Library"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O2 -fPIC"
:version 0
:package (IN-PACKAGE "XLIB") 
:end-package-info 0
:sym READ-INPUT418
:sym NIL
:sym CLOSED-DISPLAY
:sym :DISPLAY
:sym ERROR
:sym T
:sym BUFFER-LISTEN
:sym :TIMEOUT
:sym PROCESS-BLOCK
:sym ALLOCATE-EVENT
:sym BUFFER-INPUT-WAIT
:sym BUFFER-INPUT
:sym READ-REPLY-INPUT
:sym READ-ERROR-INPUT
:sym READ-EVENT-INPUT
:sym NOTE-INPUT-COMPLETE
:sym DISPLAY-FORCE-OUTPUT
:sym DEALLOCATE-REPLY-BUFFER
:sf READ-INPUT "p_xlib_READ_2DINPUT"
:pinfo XLIB::READ-INPUT (XLIB:DISPLAY XLIB::TIMEOUT XLIB::FORCE-OUTPUT-P XLIB::PREDICATE &REST XLIB::PREDICATE-ARGS) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_xlib_READ_2DINPUT();
extern SYMBOL s_xlib_READ_2DINPUT418; 
extern SYMBOL s_lsp_NIL; 
extern SYMBOL s_xlib_CLOSED_2DDISPLAY; 
extern SYMBOL s_key_DISPLAY; 
extern SYMBOL s_lsp_ERROR; 
extern SYMBOL s_lsp_T; 
extern SYMBOL s_xlib_BUFFER_2DLISTEN; 
extern SYMBOL s_key_TIMEOUT; 
MAKE_SIMPLE_STRING(k6511,14,"CLX Input Lock");
extern LP p_xlib_READ_2DINPUT_2Danon65096510();
MAKE_PROCEDURE(k6512,p_xlib_READ_2DINPUT_2Danon65096510);
extern SYMBOL s_xlib_PROCESS_2DBLOCK; 
extern SYMBOL s_xlib_ALLOCATE_2DEVENT; 
extern SYMBOL s_xlib_BUFFER_2DINPUT_2DWAIT; 
extern SYMBOL s_xlib_BUFFER_2DINPUT; 
extern SYMBOL s_xlib_READ_2DREPLY_2DINPUT; 
extern SYMBOL s_xlib_READ_2DERROR_2DINPUT; 
extern SYMBOL s_xlib_READ_2DEVENT_2DINPUT; 
extern SYMBOL s_xlib_NOTE_2DINPUT_2DCOMPLETE; 
extern SYMBOL s_xlib_DISPLAY_2DFORCE_2DOUTPUT; 
extern SYMBOL s_xlib_DEALLOCATE_2DREPLY_2DBUFFER; 


extern LP num_equal_p();
extern LP multiply();
extern LP add();
extern LP c_cons();


LP p_xlib_READ_2DINPUT(va_alist) va_dcl
{
LP v_Y_148; LP v_X_147; LP v_X_145; 
LP v_N_143; LP v_S20714_142; LP v_S20713_141; 
LP v_I_139; LP v_A_138; LP v_S20712_137; 
LP v_S20711_136; LP v_I_134; LP v_A_133; 
LP v_I_131; LP v_A_130; LP v_VALUE_129; 
LP v_S20710_128; LP v_T20709_127; LP v_I_125; 
LP v_A_124; LP v_I_122; LP v_A_121; 
LP v_VALUE_119; LP v_N_118; LP v_S_117; 
LP v_VALUE_115; LP v_S_114; LP v_T20708_113; 
LP v_S20707_112; LP v_VALUE_110; LP v_N_109; 
LP v_S_108; LP v_VALUE_106; LP v_S_105; 
LP v_T20706_104; LP v_S20705_103; LP v_Y_101; 
LP v_X_100; LP v_EOF_2DP_99; LP v_Y_97; 
LP v_X_96; LP v_EOF_2DP_95; LP v_TYPE_94; 
LP v_BUFFER_2DBBUF_93; LP v_I_91; LP v_S_90; 
LP v_S_88; LP v_BUFFER_2DBOFFSET_87; LP v__25REPLY_2DBUFFER_86; 
LP v_Y_84; LP v_X_83; LP v_I_81; 
LP v_S_80; LP v_S_78; LP v_VALUE_76; 
LP v_N_75; LP v_S_74; LP v_VALUE_72; 
LP v_S_71; LP v_T20704_70; LP v_S20703_69; 
LP v_G20702_68; LP v_Y_66; LP v_X_65; 
LP v_I_63; LP v_S_62; LP v_S_60; 
LP v_Y_58; LP v_X_57; LP v_X_55; 
LP v_Y_53; LP v_X_52; LP v_X_50; 
LP v_G20697_49; LP v_Y_47; LP v_X_46; 
LP v_I_44; LP v_S_43; LP v_S_41; 
LP v_Y_39; LP v_X_38; LP v_X_36; 
LP v_Y_34; LP v_X_33; LP v_I_31; 
LP v_S_30; LP v_S_28; LP v_VALUE_26; 
LP v_N_25; LP v_S_24; LP v_VALUE_22; 
LP v_S_21; LP v_T20699_20; LP v_S20698_19; 
LP v_I_17; LP v_S_16; LP v_S_14; 
LP v_TOKEN_11; LP v_REPLY_2DBUFFER_10; LP v_Y_8; 
LP v_X_7; LP v_G20696_6; LP v_PREDICATE_3; 
LP v_FORCE_2DOUTPUT_2DP_2; LP v_TIMEOUT_1; LP v_DISPLAY_0; 
LP v_PREDICATE_2DARGS_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; LP t145; LP t146; LP t147; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_DISPLAY_0 = NEXT_VAR_ARG;
v_TIMEOUT_1 = NEXT_VAR_ARG;
v_FORCE_2DOUTPUT_2DP_2 = NEXT_VAR_ARG;
v_PREDICATE_3 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 4) wna_low(real_argc,4);
RESTIFY(v_PREDICATE_2DARGS_4,5,NEXT_VAR_ARG);
END_VAR_ARGS;
BEGIN_CATCH(LREF(s_xlib_READ_2DINPUT418),argc);
v_REPLY_2DBUFFER_10 = LREF(s_lsp_NIL);
v_G20696_6 = LREF(s_lsp_NIL);
if (v_G20696_6 != NIL) {
v_TOKEN_11 = v_G20696_6;
} else {
v_X_7 = LREF(s_lsp_NIL);
v_Y_8 = LREF(s_lsp_NIL);
v_TOKEN_11 = (c_cons((LREF(s_lsp_NIL)), (LREF(s_lsp_NIL))));
}
BEGIN_UW_PROTECT_BODY
t_LOOP_12:;
v_S_14 = v_DISPLAY_0;
v_S_16 = v_DISPLAY_0;
v_I_17 = (LP) 22;
t1 = ((LP) DEREF((v_DISPLAY_0) + 11 * 4));
if (t1 != NIL) {
ICALL(s_lsp_ERROR) (3, LREF(s_xlib_CLOSED_2DDISPLAY), LREF(s_key_DISPLAY), v_DISPLAY_0);
}
t2 = p_lsp_APPLY(2, COERCE_TO_FUNCTION(v_PREDICATE_3), v_PREDICATE_2DARGS_4);
if (t2 != NIL) {
BEGIN_MV_CALL(dynamicblock_mv_holder6508,0);
THROW(LREF(s_xlib_READ_2DINPUT418),LREF(s_lsp_NIL),dynamicblock_mv_holder6508);
END_MV_CALL;
}
if (v_FORCE_2DOUTPUT_2DP_2 != NIL) {
v_S_41 = v_DISPLAY_0;
v_S_43 = v_DISPLAY_0;
v_I_44 = (LP) 124;
v_X_46 = ((LP) DEREF((v_DISPLAY_0) + 62 * 4));
if (((v_X_46) == (v_TOKEN_11))) {
v_G20697_49 = LREF(s_lsp_NIL);
} else {
v_S_28 = v_DISPLAY_0;
v_S_30 = v_DISPLAY_0;
v_I_31 = (LP) 124;
v_X_33 = ((LP) DEREF((v_DISPLAY_0) + 62 * 4));
if (v_X_33 != NIL) {
v_X_36 = LREF(s_lsp_NIL);
} else {
v_S20698_19 = v_TOKEN_11;
v_T20699_20 = v_DISPLAY_0;
v_S_21 = v_DISPLAY_0;
v_VALUE_22 = v_TOKEN_11;
v_S_24 = v_DISPLAY_0;
v_N_25 = (LP) 124;
v_VALUE_26 = v_TOKEN_11;
((LP) (DEREF((v_DISPLAY_0) + 62 * 4) = (LD) (v_TOKEN_11)));
v_X_36 = LREF(s_lsp_T);
}
v_X_38 = v_X_36;
v_Y_39 = LREF(s_lsp_NIL);
v_G20697_49 = (((v_X_36) == (LREF(s_lsp_NIL))) ? T : NIL);
}
if (v_G20697_49 != NIL) {
t3 = v_G20697_49;
} else {
v_X_50 = ICALL(s_xlib_BUFFER_2DLISTEN) (1, v_DISPLAY_0);
v_X_52 = v_X_50;
v_Y_53 = LREF(s_lsp_NIL);
t3 = (((v_X_50) == (LREF(s_lsp_NIL))) ? T : NIL);
}
} else {
t3 = LREF(s_lsp_NIL);
}
if (t3 != NIL) {
goto t_FORCE_2DOUTPUT_13;
}
v_S_60 = v_DISPLAY_0;
v_S_62 = v_DISPLAY_0;
v_I_63 = (LP) 124;
v_X_65 = ((LP) DEREF((v_DISPLAY_0) + 62 * 4));
v_G20702_68 = (((v_X_65) == (v_TOKEN_11)) ? T : NIL);
if (v_G20702_68 != NIL) {
t5 = v_G20702_68;
} else {
v_S_78 = v_DISPLAY_0;
v_S_80 = v_DISPLAY_0;
v_I_81 = (LP) 124;
v_X_83 = ((LP) DEREF((v_DISPLAY_0) + 62 * 4));
if (v_X_83 != NIL) {
t5 = LREF(s_lsp_NIL);
} else {
v_S20703_69 = v_TOKEN_11;
v_T20704_70 = v_DISPLAY_0;
v_S_71 = v_DISPLAY_0;
v_VALUE_72 = v_TOKEN_11;
v_S_74 = v_DISPLAY_0;
v_N_75 = (LP) 124;
v_VALUE_76 = v_TOKEN_11;
((LP) (DEREF((v_DISPLAY_0) + 62 * 4) = (LD) (v_TOKEN_11)));
t5 = LREF(s_lsp_T);
}
}
if (t5 == NIL) {
v_X_57 = v_TIMEOUT_1;
v_Y_58 = (LP) 0;
if (((int) (v_TIMEOUT_1) == (int) ((LP) 0))) {
BEGIN_MV_CALL(dynamicblock_mv_holder6508,0);
THROW(LREF(s_xlib_READ_2DINPUT418),LREF(s_key_TIMEOUT),dynamicblock_mv_holder6508);
END_MV_CALL;
} else {
v_X_55 = LREF(s_xlib_PROCESS_2DBLOCK);
t7 = ((LP) DEREF((LREF(s_xlib_PROCESS_2DBLOCK)) + 4 * 4));
p_lsp_APPLY(6, COERCE_TO_FUNCTION(t7), LREF(k6511), LREF(k6512), v_DISPLAY_0, v_PREDICATE_3, v_PREDICATE_2DARGS_4);
}
goto t_LOOP_12;
}
v_REPLY_2DBUFFER_10 = ICALL(s_xlib_ALLOCATE_2DEVENT) (0);
v__25REPLY_2DBUFFER_86 = v_REPLY_2DBUFFER_10;
v_BUFFER_2DBOFFSET_87 = (LP) 0;
v_S_88 = v__25REPLY_2DBUFFER_86;
v_S_90 = v__25REPLY_2DBUFFER_86;
v_I_91 = (LP) 4;
v_BUFFER_2DBBUF_93 = ((LP) DEREF((v__25REPLY_2DBUFFER_86) + 2 * 4));
v_TYPE_94 = (LP) 0;
v_X_96 = v_TIMEOUT_1;
v_Y_97 = (LP) 0;
if (((int) (v_TIMEOUT_1) == (int) ((LP) 0)) == 0) {
v_EOF_2DP_95 = ICALL(s_xlib_BUFFER_2DINPUT_2DWAIT) (2, v_DISPLAY_0, v_TIMEOUT_1);
if (v_EOF_2DP_95 != NIL) {
BEGIN_MV_CALL(dynamicblock_mv_holder6508,0);
THROW(LREF(s_xlib_READ_2DINPUT418),v_EOF_2DP_95,dynamicblock_mv_holder6508);
END_MV_CALL;
} else {
}
}
if (v_FORCE_2DOUTPUT_2DP_2 != NIL) {
t9 = (LP) 0;
} else {
t9 = v_TIMEOUT_1;
}
v_EOF_2DP_99 = ICALL(s_xlib_BUFFER_2DINPUT) (5, v_DISPLAY_0, v_BUFFER_2DBBUF_93, (LP) 0, (LP) 64, t9);
if (v_EOF_2DP_99 != NIL) {
v_X_100 = v_EOF_2DP_99;
v_Y_101 = LREF(s_key_TIMEOUT);
if (((v_EOF_2DP_99) == (LREF(s_key_TIMEOUT)))) {
if (v_FORCE_2DOUTPUT_2DP_2 != NIL) {
goto t_FORCE_2DOUTPUT_13;
} else {
BEGIN_MV_CALL(dynamicblock_mv_holder6508,0);
THROW(LREF(s_xlib_READ_2DINPUT418),LREF(s_key_TIMEOUT),dynamicblock_mv_holder6508);
END_MV_CALL;
}
}
v_S20705_103 = LREF(s_lsp_T);
v_T20706_104 = v_DISPLAY_0;
v_S_105 = v_DISPLAY_0;
v_VALUE_106 = LREF(s_lsp_T);
v_S_108 = v_DISPLAY_0;
v_N_109 = (LP) 22;
v_VALUE_110 = LREF(s_lsp_T);
((LP) (DEREF((v_DISPLAY_0) + 11 * 4) = (LD) (LREF(s_lsp_T))));
BEGIN_MV_CALL(dynamicblock_mv_holder6508,0);
THROW(LREF(s_xlib_READ_2DINPUT418),v_EOF_2DP_99,dynamicblock_mv_holder6508);
END_MV_CALL;
} else {
}
v_S20707_112 = (LP) 64;
v_T20708_113 = v_REPLY_2DBUFFER_10;
v_S_114 = v_T20708_113;
v_VALUE_115 = (LP) 64;
v_S_117 = v_T20708_113;
v_N_118 = (LP) 8;
v_VALUE_119 = (LP) 64;
((LP) (DEREF((v_T20708_113) + 4 * 4) = (LD) ((LP) 64)));
t12 = (add((v_BUFFER_2DBOFFSET_87), ((LP) 0)));
v_I_131 = t12;
v_TYPE_94 = (LP) INT_TO_FX(((unsigned char (*)) (v_BUFFER_2DBBUF_93 - 1))[FX_TO_INT(v_I_131)]);
if (((int) (v_TYPE_94) == (int) ((LP) 2))) {
t13 = (add((v_BUFFER_2DBOFFSET_87), ((LP) 4)));
v_I_122 = t13;
t15 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_122)) >> (1)));
t14 = INT_TO_FX((LP) (*(((unsigned short *) ((int) (v_BUFFER_2DBBUF_93) - 1)) + FX_TO_INT(t15))));
t18 = (add((v_BUFFER_2DBOFFSET_87), ((LP) 8)));
v_I_125 = t18;
t20 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_125)) >> (2)));
t19 = UINT32_TO_INTEGER((LP) (*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_93) - 1)) + FX_TO_INT(t20))));
t17 = (multiply((t19), ((LP) 8)));
t16 = (add(((LP) 64), (t17)));
v_T20709_127 = v_REPLY_2DBUFFER_10;
v_S20710_128 = LREF(s_lsp_NIL);
v_REPLY_2DBUFFER_10 = LREF(s_lsp_NIL);
v_VALUE_129 = ICALL(s_xlib_READ_2DREPLY_2DINPUT) (4, v_DISPLAY_0, t14, t16, v_T20709_127);
if (v_VALUE_129 != NIL) {
BEGIN_MV_CALL(dynamicblock_mv_holder6508,0);
THROW(LREF(s_xlib_READ_2DINPUT418),v_VALUE_129,dynamicblock_mv_holder6508);
END_MV_CALL;
}
goto t_LOOP_12;
}
v_N_143 = v_TYPE_94;
t21 = (num_equal_p((v_N_143), ((LP) 0)));
if (t21 != NIL) {
t22 = (add((v_BUFFER_2DBOFFSET_87), ((LP) 4)));
v_I_134 = t22;
t24 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_134)) >> (1)));
t23 = INT_TO_FX((LP) (*(((unsigned short *) ((int) (v_BUFFER_2DBBUF_93) - 1)) + FX_TO_INT(t24))));
v_S20711_136 = v_REPLY_2DBUFFER_10;
v_S20712_137 = LREF(s_lsp_NIL);
v_REPLY_2DBUFFER_10 = LREF(s_lsp_NIL);
ICALL(s_xlib_READ_2DERROR_2DINPUT) (4, v_DISPLAY_0, t23, v_S20711_136, v_TOKEN_11);
} else {
t25 = (add((v_BUFFER_2DBOFFSET_87), ((LP) 0)));
v_I_139 = t25;
t26 = (LP) INT_TO_FX(((unsigned char (*)) (v_BUFFER_2DBBUF_93 - 1))[FX_TO_INT(v_I_139)]);
v_S20713_141 = v_REPLY_2DBUFFER_10;
v_S20714_142 = LREF(s_lsp_NIL);
v_REPLY_2DBUFFER_10 = LREF(s_lsp_NIL);
ICALL(s_xlib_READ_2DEVENT_2DINPUT) (3, v_DISPLAY_0, t26, v_S20713_141);
}
goto t_LOOP_12;
t_FORCE_2DOUTPUT_13:;
ICALL(s_xlib_NOTE_2DINPUT_2DCOMPLETE) (2, v_DISPLAY_0, v_TOKEN_11);
ICALL(s_xlib_DISPLAY_2DFORCE_2DOUTPUT) (1, v_DISPLAY_0);
v_FORCE_2DOUTPUT_2DP_2 = LREF(s_lsp_NIL);
goto t_LOOP_12;
BEGIN_UW_PROTECT_CLEANUP
v_X_145 = v_REPLY_2DBUFFER_10;
v_X_147 = v_X_145;
v_Y_148 = LREF(s_lsp_NIL);
if (v_X_145 != NIL) {
ICALL(s_xlib_DEALLOCATE_2DREPLY_2DBUFFER) (1, v_REPLY_2DBUFFER_10);
}
t27 = ICALL(s_xlib_NOTE_2DINPUT_2DCOMPLETE) (2, v_DISPLAY_0, v_TOKEN_11);
CONTINUE_FROM_PROTECT
t0 = NIL;
END_CATCH(t0);
return(t0);
}

LP p_xlib_READ_2DINPUT_2Danon65096510(va_alist) va_dcl
{
LP v_Y_28; LP v_X_27; LP v_X_25; 
LP v_Y_23; LP v_X_22; LP v_X_20; 
LP v_I_18; LP v_S_17; LP v_S_15; 
LP v_G20701_14; LP v_Y_12; LP v_X_11; 
LP v_X_9; LP v_I_7; LP v_S_6; 
LP v_S_4; LP v_G20700_3; LP v_PREDICATE_1; 
LP v_DISPLAY_0; LP v_PREDICATE_2DARGS_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_DISPLAY_0 = NEXT_VAR_ARG;
v_PREDICATE_1 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 2) wna_low(real_argc,2);
RESTIFY(v_PREDICATE_2DARGS_2,3,NEXT_VAR_ARG);
END_VAR_ARGS;
v_G20700_3 = p_lsp_APPLY(2, COERCE_TO_FUNCTION(v_PREDICATE_1), v_PREDICATE_2DARGS_2);
if (v_G20700_3 != NIL) {
return(v_G20700_3);
} else {
v_S_4 = v_DISPLAY_0;
v_S_6 = v_DISPLAY_0;
v_I_7 = (LP) 124;
v_X_9 = ((LP) DEREF((v_DISPLAY_0) + 62 * 4));
v_X_11 = v_X_9;
v_Y_12 = LREF(s_lsp_NIL);
v_G20701_14 = (((v_X_9) == (LREF(s_lsp_NIL))) ? T : NIL);
if (v_G20701_14 != NIL) {
return(v_G20701_14);
} else {
v_S_15 = v_DISPLAY_0;
v_S_17 = v_DISPLAY_0;
v_I_18 = (LP) 22;
v_X_20 = ((LP) DEREF((v_DISPLAY_0) + 11 * 4));
v_X_22 = v_X_20;
v_Y_23 = LREF(s_lsp_NIL);
v_X_25 = (((v_X_20) == (LREF(s_lsp_NIL))) ? T : NIL);
v_X_27 = v_X_25;
v_Y_28 = LREF(s_lsp_NIL);
t0 = (((v_X_25) == (LREF(s_lsp_NIL))) ? T : NIL);
return(t0);
}
}
}

