
long c_symbol_value(name)
     char *name;
{
  return(0);
}

void init_loader(a0)
     char *a0;
{

}

void signal_debug_info(filename, text_start)
     char* filename; unsigned long text_start;
{
}

unsigned load_compiled_file(fileName)
     char *fileName;
{
  printf("HEY! Solaris loader doesn't work\n");
  return(0);
}

pc_to_procedure_name(pc)
     unsigned long pc;
{
  printf("HEY! pc_to_procedure name doesn't work on SPARC!\n");
  return(0);
}

