/*
:comment "Compiled at 4:03:17 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: Debug Library"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O2 -fPIC"
:version 0
:end-package-info 0
:sym TYPE-MACROEXPAND
:sym ATOM
:sym NIL
:sym CONS
:sym FIRST
:sym SYMBOLP
:sym SYMBOL-HASH-CODE
:sym T
:sym EQ
:sym ARRAY
:sym SIMPLE-ARRAY
:sym SYMBOL
:sym OR
:sym AND
:sym NOT
:sym MEMBER
:sym SATISFIES
:sym CHARACTER
:sym FLOAT
:sym INTEGER
:sym SECOND
:sym THIRD
:sym NUMBERP
:sym EXPT
:sym 1-
:sym ERROR
:sf TYPE->ELEMENT-TYPE-TAG "p_lsp_TYPE_2D_3EELEMENT_2DTYPE_2DTAG"
:sym COMPLETE-DELAYED-DEFSTRUCTS
:sym *
:sym QUOTE
:sym CDR
:sym RATOI
:sym COMPLEX
:sym EQUAL
:sym NULL
:sym LISTP
:sym REWRITE-COMBINED-TYPE
:sym CHARACTERP
:sym FLOATP
:sym FIXNUMP
:sym BITP
:sym INTEGER-RANGE-P
:sym LIST
:sym INTEGERP
:sym *STRUCTURE-INFO*
:sym UNSAFE-SYMBOL-VALUE
:sym GETHASH
:sym STRUCTURE-ELT
:sym PREDICATE-NAME
:sym REWRITE-ARRAY-TYPEP
:sf REWRITE-TYPEP "p_lsp_REWRITE_2DTYPEP"
:sym GENSYM
:sym LET
:sym REST
:sym CAR
:sym REWRITE-TYPEP
:sym RPLACD
:sf REWRITE-COMBINED-TYPE "p_lsp_REWRITE_2DCOMBINED_2DTYPE"
:sym LENGTH
:sym TYPE->ELEMENT-TYPE-TAG
:sym EQL
:sym STRING-P
:sym FLOAT-VECTOR-P
:sym BIT-VECTOR-P
:sym SIGNED-8BIT-VECTOR-P
:sym UNSIGNED-8BIT-VECTOR-P
:sym SIGNED-16BIT-VECTOR-P
:sym UNSIGNED-16BIT-VECTOR-P
:sym SIGNED-32BIT-VECTOR-P
:sym UNSIGNED-32BIT-VECTOR-P
:sym VECTOR-P
:sym ARRAY-TYPE-P
:sym ARRAY-P
:sym STRING
:sym CONCATENATE
:sym *LISP-PACKAGE*
:sym INTERN
:sf REWRITE-ARRAY-TYPEP "p_lsp_REWRITE_2DARRAY_2DTYPEP"
:sym *TYPE-MACRO-EXPANDERS*
:sym EXPAND-MACRO
:sym EXPAND-INNER-TYPES
:sf TYPE-MACROEXPAND "p_lsp_TYPE_2DMACROEXPAND"
:sym CDDR
:sym LIST*
:sf EXPAND-INNER-TYPES "p_lsp_EXPAND_2DINNER_2DTYPES"
:sym COPY-LIST
:sym LAST
:sf COLLECT-CASES "p_lsp_COLLECT_2DCASES"
:sym STRING-EQUAL
:sym :SUN-4
:sym :IRIS
:sym WARN
:sf PROCESSOR+OS->MACHINE-TYPE "p_lsp_PROCESSOR_2BOS_2D_3EMACHINE_2DTYPE"
:sym :BIG-ENDIAN
:sym :DECSTATION
:sym :LITTLE-ENDIAN
:sf MACHINE-BYTE-ORDER "p_lsp_MACHINE_2DBYTE_2DORDER"
:sym :START
:sym POSITION
:sym SUBSEQ
:sym 1+
:sf UNIX->LISP-PATH-LIST "p_lsp_UNIX_2D_3ELISP_2DPATH_2DLIST"
:sym CONSP
:sym *SETF-METHODS*
:sym FORMAT
:sym SYMBOL-PACKAGE
:sf SETF-FUNCTION-SYMBOL "p_lsp_SETF_2DFUNCTION_2DSYMBOL"
:sym SETF-FUNCTION-SYMBOL
:sym SET-SYMBOL-FUNCTION
:sym DEFSETF
:sym CADR
:sym &REST
:sym ALL-ARGS
:sym NEW-VALUE
:sym EVAL
:sf SET-FDEFINITION "p_lsp_SET_2DFDEFINITION"
:pinfo UNIX->LISP-PATH-LIST (STRING) NIL NIL NIL NIL NIL NIL T
:pinfo SETF-FUNCTION-SYMBOL (FUNCTION-SPECIFIER) NIL NIL NIL NIL NIL NIL T
:pinfo TYPE-MACROEXPAND (FORM &OPTIONAL LOCAL-MACRO-ENV ALREADY-EXPANDED?) NIL NIL NIL NIL NIL NIL T
:pinfo MACHINE-BYTE-ORDER (MACHINE-TYPE) NIL NIL NIL NIL NIL NIL T
:pinfo REWRITE-ARRAY-TYPEP (FORM TYPE SECOND THIRD) NIL NIL NIL NIL NIL NIL T
:pinfo PROCESSOR+OS->MACHINE-TYPE (PROCESSOR OS) NIL NIL NIL NIL NIL NIL T
:pinfo REWRITE-TYPEP (FORM ANY-TYPE) NIL NIL NIL NIL NIL NIL T
:pinfo EXPAND-INNER-TYPES (TYPE) NIL NIL NIL NIL NIL NIL T
:pinfo SET-FDEFINITION (NEW-VALUE FUNCTION-SPECIFIER) NIL NIL NIL NIL NIL NIL T
:pinfo COLLECT-CASES (CASES) NIL NIL NIL NIL NIL NIL T
:pinfo TYPE->ELEMENT-TYPE-TAG (ELEMENT-TYPE) NIL NIL NIL NIL NIL NIL T
:pinfo REWRITE-COMBINED-TYPE (FORM TYPE) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_lsp_TYPE_2D_3EELEMENT_2DTYPE_2DTAG();
extern SYMBOL s_lsp_TYPE_2DMACROEXPAND; 
extern SYMBOL s_lsp_ATOM; 
extern SYMBOL s_lsp_NIL; 
extern SYMBOL s_lsp_CONS; 
extern SYMBOL s_lsp_FIRST; 
extern SYMBOL s_lsp_SYMBOLP; 
extern SYMBOL s_lsp_SYMBOL_2DHASH_2DCODE; 
extern SYMBOL s_lsp_T; 
extern SYMBOL s_lsp_EQ; 
extern SYMBOL s_lsp_ARRAY; 
extern SYMBOL s_lsp_SIMPLE_2DARRAY; 
extern SYMBOL s_lsp_SYMBOL; 
extern SYMBOL s_lsp_OR; 
extern SYMBOL s_lsp_AND; 
extern SYMBOL s_lsp_NOT; 
extern SYMBOL s_lsp_MEMBER; 
extern SYMBOL s_lsp_SATISFIES; 
extern SYMBOL s_lsp_CHARACTER; 
extern SYMBOL s_lsp_FLOAT; 
MAKE_FLOAT(k1768,0.0);
extern SYMBOL s_lsp_INTEGER; 
extern SYMBOL s_lsp_SECOND; 
extern SYMBOL s_lsp_THIRD; 
extern SYMBOL s_lsp_NUMBERP; 
extern SYMBOL s_lsp_EXPT; 
extern SYMBOL s_lsp_1_2D; 
MAKE_SIMPLE_STRING(k1769,30,"~A is not a legal element-type");
extern SYMBOL s_lsp_ERROR; 
extern LP p_lsp_REWRITE_2DTYPEP();
extern SYMBOL s_lsp_COMPLETE_2DDELAYED_2DDEFSTRUCTS; 
extern SYMBOL s_lsp__2A; 
extern SYMBOL s_lsp_QUOTE; 
extern SYMBOL s_lsp_CDR; 
extern SYMBOL s_lsp_RATOI; 
extern SYMBOL s_lsp_COMPLEX; 
MAKE_CONS(k1776,LREF(s_lsp_COMPLEX),LREF(s_lsp_NIL));
MAKE_CONS(k1775,LREF(s_lsp_RATOI),LREF(k1776));
MAKE_CONS(k1774,LREF(s_lsp_FLOAT),LREF(k1775));
MAKE_CONS(k1773,LREF(s_lsp_INTEGER),LREF(k1774));
MAKE_CONS(k1772,LREF(s_lsp_OR),LREF(k1773));
extern SYMBOL s_lsp_EQUAL; 
extern SYMBOL s_lsp_NULL; 
MAKE_CONS(k1779,LREF(s_lsp_CONS),LREF(s_lsp_NIL));
MAKE_CONS(k1778,LREF(s_lsp_NULL),LREF(k1779));
MAKE_CONS(k1777,LREF(s_lsp_OR),LREF(k1778));
extern SYMBOL s_lsp_LISTP; 
extern SYMBOL s_lsp_REWRITE_2DCOMBINED_2DTYPE; 
extern SYMBOL s_lsp_CHARACTERP; 
extern SYMBOL s_lsp_FLOATP; 
extern SYMBOL s_lsp_FIXNUMP; 
extern SYMBOL s_lsp_BITP; 
extern SYMBOL s_lsp_INTEGER_2DRANGE_2DP; 
extern SYMBOL s_lsp_LIST; 
extern SYMBOL s_lsp_INTEGERP; 
extern SYMBOL s_lsp__2ASTRUCTURE_2DINFO_2A; 
extern SYMBOL s_lsp_UNSAFE_2DSYMBOL_2DVALUE; 
extern SYMBOL s_lsp_GETHASH; 
extern SYMBOL s_lsp_STRUCTURE_2DELT; 
extern SYMBOL s_lsp_PREDICATE_2DNAME; 
extern SYMBOL s_lsp_REWRITE_2DARRAY_2DTYPEP; 
extern LP p_lsp_REWRITE_2DCOMBINED_2DTYPE();
MAKE_SIMPLE_STRING(k1780,3,"TMP");
extern SYMBOL s_lsp_GENSYM; 
extern SYMBOL s_lsp_LET; 
extern SYMBOL s_lsp_REST; 
extern SYMBOL s_lsp_CAR; 
extern SYMBOL s_lsp_REWRITE_2DTYPEP; 
extern SYMBOL s_lsp_RPLACD; 
extern LP p_lsp_REWRITE_2DARRAY_2DTYPEP();
extern LP p_lsp_REWRITE_2DARRAY_2DTYPEP_2DPRED1781();
extern SYMBOL s_lsp_LENGTH; 
extern SYMBOL s_lsp_TYPE_2D_3EELEMENT_2DTYPE_2DTAG; 
extern SYMBOL s_lsp_EQL; 
extern SYMBOL s_lsp_STRING_2DP; 
extern SYMBOL s_lsp_FLOAT_2DVECTOR_2DP; 
extern SYMBOL s_lsp_BIT_2DVECTOR_2DP; 
extern SYMBOL s_lsp_SIGNED_2D8BIT_2DVECTOR_2DP; 
extern SYMBOL s_lsp_UNSIGNED_2D8BIT_2DVECTOR_2DP; 
extern SYMBOL s_lsp_SIGNED_2D16BIT_2DVECTOR_2DP; 
extern SYMBOL s_lsp_UNSIGNED_2D16BIT_2DVECTOR_2DP; 
extern SYMBOL s_lsp_SIGNED_2D32BIT_2DVECTOR_2DP; 
extern SYMBOL s_lsp_UNSIGNED_2D32BIT_2DVECTOR_2DP; 
extern SYMBOL s_lsp_VECTOR_2DP; 
extern SYMBOL s_lsp_ARRAY_2DTYPE_2DP; 
extern SYMBOL s_lsp_ARRAY_2DP; 
extern SYMBOL s_lsp_STRING; 
MAKE_SIMPLE_STRING(k1782,7,"SIMPLE-");
extern SYMBOL s_lsp_CONCATENATE; 
extern SYMBOL s_lsp__2ALISP_2DPACKAGE_2A; 
extern SYMBOL s_lsp_INTERN; 
extern LP p_lsp_TYPE_2DMACROEXPAND();
extern SYMBOL s_lsp__2ATYPE_2DMACRO_2DEXPANDERS_2A; 
extern SYMBOL s_lsp_EXPAND_2DMACRO; 
extern SYMBOL s_lsp_EXPAND_2DINNER_2DTYPES; 
extern LP p_lsp_EXPAND_2DINNER_2DTYPES();
extern SYMBOL s_lsp_CDDR; 
MAKE_CONS(k1784,LREF(s_lsp__2A),LREF(s_lsp_NIL));
extern SYMBOL s_lsp_LIST_2A; 
extern LP p_lsp_COLLECT_2DCASES();
extern SYMBOL s_lsp_COPY_2DLIST; 
extern SYMBOL s_lsp_LAST; 
extern LP p_lsp_PROCESSOR_2BOS_2D_3EMACHINE_2DTYPE();
MAKE_SIMPLE_STRING(k1785,5,"sunos");
extern SYMBOL s_lsp_STRING_2DEQUAL; 
MAKE_SIMPLE_STRING(k1786,5,"sparc");
extern SYMBOL s_key_SUN_2D4; 
MAKE_SIMPLE_STRING(k1787,4,"irix");
MAKE_SIMPLE_STRING(k1788,4,"mips");
extern SYMBOL s_key_IRIS; 
MAKE_SIMPLE_STRING(k1789,40,"Machine type not known for ~A running ~A");
extern SYMBOL s_lsp_WARN; 
extern LP p_lsp_MACHINE_2DBYTE_2DORDER();
extern SYMBOL s_key_BIG_2DENDIAN; 
extern SYMBOL s_key_DECSTATION; 
extern SYMBOL s_key_LITTLE_2DENDIAN; 
extern LP p_lsp_UNIX_2D_3ELISP_2DPATH_2DLIST();
extern LP p_lsp_UNIX_2D_3ELISP_2DPATH_2DLIST_2DDOIT1790();
extern SYMBOL s_key_START; 
extern SYMBOL s_lsp_POSITION; 
extern SYMBOL s_lsp_SUBSEQ; 
extern SYMBOL s_lsp_1_2B; 
extern LP p_lsp_SETF_2DFUNCTION_2DSYMBOL();
extern SYMBOL s_lsp_CONSP; 
extern SYMBOL s_lsp__2ASETF_2DMETHODS_2A; 
MAKE_SIMPLE_STRING(k1791,6,"SET-~A");
extern SYMBOL s_lsp_FORMAT; 
extern SYMBOL s_lsp_SYMBOL_2DPACKAGE; 
extern LP p_lsp_SET_2DFDEFINITION();
extern SYMBOL s_lsp_SETF_2DFUNCTION_2DSYMBOL; 
extern SYMBOL s_lsp_SET_2DSYMBOL_2DFUNCTION; 
extern SYMBOL s_lsp_DEFSETF; 
extern SYMBOL s_lsp_CADR; 
extern SYMBOL s_lsp__26REST; 
extern SYMBOL s_lsp_ALL_2DARGS; 
MAKE_CONS(k1793,LREF(s_lsp_ALL_2DARGS),LREF(s_lsp_NIL));
MAKE_CONS(k1792,LREF(s_lsp__26REST),LREF(k1793));
extern SYMBOL s_lsp_NEW_2DVALUE; 
MAKE_CONS(k1794,LREF(s_lsp_NEW_2DVALUE),LREF(s_lsp_NIL));
MAKE_CONS(k1795,LREF(s_lsp_NEW_2DVALUE),LREF(k1793));
extern SYMBOL s_lsp_EVAL; 


extern LP subtract();
extern LP leq_p();
extern LP num_equal_p();
extern LP geq_p();


LP p_lsp_TYPE_2D_3EELEMENT_2DTYPE_2DTAG(argc, v_ELEMENT_2DTYPE_0)
      ARGC argc;  LP v_ELEMENT_2DTYPE_0;
{
LP v_HIGH_9; LP v_LOW_8; LP v_KEY2167_5; 
LP v_TYPE_3; LP v_EXP_2DTYPE_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; 
if (argc != 1) wna(argc,1);
v_EXP_2DTYPE_2 = ICALL(s_lsp_TYPE_2DMACROEXPAND) (1, v_ELEMENT_2DTYPE_0);
t0 = ICALL(s_lsp_ATOM) (1, v_EXP_2DTYPE_2);
if (t0 != NIL) {
v_TYPE_3 = ICALL(s_lsp_CONS) (2, v_EXP_2DTYPE_2, LREF(s_lsp_NIL));
} else {
v_TYPE_3 = v_EXP_2DTYPE_2;
}
v_KEY2167_5 = ICALL(s_lsp_FIRST) (1, v_TYPE_3);
t2 = ICALL(s_lsp_SYMBOLP) (1, v_KEY2167_5);
if (t2 != NIL) {
t5 = ICALL(s_lsp_SYMBOL_2DHASH_2DCODE) (1, v_KEY2167_5);
t4 = ((LP) ((int) (t5) % (int) ((LP) 56)));
switch ((int) t4) {
case 50:
t6 = ICALL(s_lsp_EQ) (2, v_KEY2167_5, LREF(s_lsp_T));
if (t6 != NIL) {
goto t_C2170_7;
} else {
goto t_DEFAULT_2DTAG2168_6;
}
break;
case 40:
t7 = ICALL(s_lsp_EQ) (2, v_KEY2167_5, LREF(s_lsp_ARRAY));
if (t7 != NIL) {
goto t_C2170_7;
} else {
goto t_DEFAULT_2DTAG2168_6;
}
break;
case 20:
t8 = ICALL(s_lsp_EQ) (2, v_KEY2167_5, LREF(s_lsp_SIMPLE_2DARRAY));
if (t8 != NIL) {
goto t_C2170_7;
} else {
goto t_DEFAULT_2DTAG2168_6;
}
break;
case 24:
t9 = ICALL(s_lsp_EQ) (2, v_KEY2167_5, LREF(s_lsp_SYMBOL));
if (t9 != NIL) {
goto t_C2170_7;
} else {
goto t_DEFAULT_2DTAG2168_6;
}
break;
case 6:
t10 = ICALL(s_lsp_EQ) (2, v_KEY2167_5, LREF(s_lsp_OR));
if (t10 != NIL) {
goto t_C2170_7;
} else {
goto t_DEFAULT_2DTAG2168_6;
}
break;
case 36:
t11 = ICALL(s_lsp_EQ) (2, v_KEY2167_5, LREF(s_lsp_AND));
if (t11 != NIL) {
goto t_C2170_7;
} else {
goto t_DEFAULT_2DTAG2168_6;
}
break;
case 32:
t12 = ICALL(s_lsp_EQ) (2, v_KEY2167_5, LREF(s_lsp_NOT));
if (t12 != NIL) {
goto t_C2170_7;
} else {
goto t_DEFAULT_2DTAG2168_6;
}
break;
case 4:
t13 = ICALL(s_lsp_EQ) (2, v_KEY2167_5, LREF(s_lsp_MEMBER));
if (t13 != NIL) {
goto t_C2170_7;
} else {
goto t_DEFAULT_2DTAG2168_6;
}
break;
case 8:
t14 = ICALL(s_lsp_EQ) (2, v_KEY2167_5, LREF(s_lsp_SATISFIES));
if (t14 != NIL) {
goto t_C2170_7;
} else {
goto t_DEFAULT_2DTAG2168_6;
}
break;
case 28:
t15 = ICALL(s_lsp_EQ) (2, v_KEY2167_5, LREF(s_lsp_CHARACTER));
if (t15 != NIL) {
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,3);
SET_MV_RETURN_VALUE(argc,1,(LP) 16);
SET_MV_RETURN_VALUE(argc,2,LREF(char_tab[0]));
}
return((LP) 48);
} else {
goto t_DEFAULT_2DTAG2168_6;
}
break;
case 38:
t16 = ICALL(s_lsp_EQ) (2, v_KEY2167_5, LREF(s_lsp_FLOAT));
if (t16 != NIL) {
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,3);
SET_MV_RETURN_VALUE(argc,1,(LP) 128);
SET_MV_RETURN_VALUE(argc,2,LREF(k1768));
}
return((LP) 144);
} else {
goto t_DEFAULT_2DTAG2168_6;
}
break;
case 2:
t17 = ICALL(s_lsp_EQ) (2, v_KEY2167_5, LREF(s_lsp_INTEGER));
if (t17 != NIL) {
v_LOW_8 = ICALL(s_lsp_SECOND) (1, v_TYPE_3);
v_HIGH_9 = ICALL(s_lsp_THIRD) (1, v_TYPE_3);
t19 = ICALL(s_lsp_NUMBERP) (1, v_LOW_8);
if (t19 != NIL) {
t18 = ICALL(s_lsp_NUMBERP) (1, v_HIGH_9);
} else {
t18 = LREF(s_lsp_NIL);
}
if (t18 != NIL) {
t20 = (geq_p((v_LOW_8), ((LP) 0)));
if (t20 != NIL) {
t21 = (num_equal_p((v_HIGH_9), ((LP) 2)));
if (t21 != NIL) {
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,3);
SET_MV_RETURN_VALUE(argc,1,(LP) 2);
SET_MV_RETURN_VALUE(argc,2,(LP) 0);
}
return((LP) 0);
} else {
t24 = ICALL(s_lsp_EXPT) (2, (LP) 4, (LP) 16);
t23 = ICALL(s_lsp_1_2D) (1, t24);
t22 = (leq_p((v_HIGH_9), (t23)));
if (t22 != NIL) {
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,3);
SET_MV_RETURN_VALUE(argc,1,(LP) 16);
SET_MV_RETURN_VALUE(argc,2,(LP) 0);
}
return((LP) 32);
} else {
t27 = ICALL(s_lsp_EXPT) (2, (LP) 4, (LP) 32);
t26 = ICALL(s_lsp_1_2D) (1, t27);
t25 = (leq_p((v_HIGH_9), (t26)));
if (t25 != NIL) {
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,3);
SET_MV_RETURN_VALUE(argc,1,(LP) 32);
SET_MV_RETURN_VALUE(argc,2,(LP) 0);
}
return((LP) 80);
} else {
t30 = ICALL(s_lsp_EXPT) (2, (LP) 4, (LP) 64);
t29 = ICALL(s_lsp_1_2D) (1, t30);
t28 = (leq_p((v_HIGH_9), (t29)));
if (t28 != NIL) {
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,3);
SET_MV_RETURN_VALUE(argc,1,(LP) 64);
SET_MV_RETURN_VALUE(argc,2,(LP) 0);
}
return((LP) 112);
} else {
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,(LP) 64);
}
return((LP) 128);
}
}
}
}
} else {
t34 = ICALL(s_lsp_EXPT) (2, (LP) 4, (LP) 14);
t33 = (subtract(((LP) 0), (t34)));
t32 = (geq_p((v_LOW_8), (t33)));
if (t32 != NIL) {
t36 = ICALL(s_lsp_EXPT) (2, (LP) 4, (LP) 14);
t35 = ICALL(s_lsp_1_2D) (1, t36);
t31 = (leq_p((v_HIGH_9), (t35)));
} else {
t31 = LREF(s_lsp_NIL);
}
if (t31 != NIL) {
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,3);
SET_MV_RETURN_VALUE(argc,1,(LP) 16);
SET_MV_RETURN_VALUE(argc,2,(LP) 0);
}
return((LP) 16);
} else {
t40 = ICALL(s_lsp_EXPT) (2, (LP) 4, (LP) 30);
t39 = (subtract(((LP) 0), (t40)));
t38 = (geq_p((v_LOW_8), (t39)));
if (t38 != NIL) {
t42 = ICALL(s_lsp_EXPT) (2, (LP) 4, (LP) 30);
t41 = ICALL(s_lsp_1_2D) (1, t42);
t37 = (leq_p((v_HIGH_9), (t41)));
} else {
t37 = LREF(s_lsp_NIL);
}
if (t37 != NIL) {
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,3);
SET_MV_RETURN_VALUE(argc,1,(LP) 32);
SET_MV_RETURN_VALUE(argc,2,(LP) 0);
}
return((LP) 64);
} else {
t46 = ICALL(s_lsp_EXPT) (2, (LP) 4, (LP) 62);
t45 = (subtract(((LP) 0), (t46)));
t44 = (geq_p((v_LOW_8), (t45)));
if (t44 != NIL) {
t48 = ICALL(s_lsp_EXPT) (2, (LP) 4, (LP) 62);
t47 = ICALL(s_lsp_1_2D) (1, t48);
t43 = (leq_p((v_HIGH_9), (t47)));
} else {
t43 = LREF(s_lsp_NIL);
}
if (t43 != NIL) {
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,3);
SET_MV_RETURN_VALUE(argc,1,(LP) 64);
SET_MV_RETURN_VALUE(argc,2,(LP) 0);
}
return((LP) 96);
} else {
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,3);
SET_MV_RETURN_VALUE(argc,1,(LP) 64);
SET_MV_RETURN_VALUE(argc,2,LREF(s_lsp_NIL));
}
return((LP) 128);
}
}
}
}
} else {
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,3);
SET_MV_RETURN_VALUE(argc,1,(LP) 64);
SET_MV_RETURN_VALUE(argc,2,(LP) 0);
}
return((LP) 128);
}
} else {
goto t_DEFAULT_2DTAG2168_6;
}
break;
default:
goto t_DEFAULT_2DTAG2168_6;
break;
}
return(t3);
}
t_DEFAULT_2DTAG2168_6:;
t49 = ICALL(s_lsp_ERROR) (MV_CALL(argc,2), LREF(k1769), v_ELEMENT_2DTYPE_0);
return(t49);
return(NIL);
t_C2170_7:;
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,3);
SET_MV_RETURN_VALUE(argc,1,(LP) 64);
SET_MV_RETURN_VALUE(argc,2,LREF(s_lsp_NIL));
}
return((LP) 128);
return(NIL);
return(NIL);
}

LP p_lsp_REWRITE_2DTYPEP(argc, v_FORM_0, v_ANY_2DTYPE_1)
      ARGC argc;  LP v_FORM_0; LP v_ANY_2DTYPE_1;
{
LP v_S_16; LP v_G2176_15; LP v_REWRITE_3F_14; 
LP v_NEW_2DTYPE_13; LP v_INFO_12; LP v_KEY2171_8; 
LP v_THIRD_6; LP v_SECOND_5; LP v_TYPE_4; 
LP v_MEXP_2DTYPE_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; LP t145; LP t146; LP t147; LP t148; LP t149; 
LP t150; LP t151; 
if (argc != 2) wna(argc,2);
START1771:
ICALL(s_lsp_COMPLETE_2DDELAYED_2DDEFSTRUCTS) (0);
v_MEXP_2DTYPE_3 = ICALL(s_lsp_TYPE_2DMACROEXPAND) (1, v_ANY_2DTYPE_1);
t1 = ICALL(s_lsp_EQ) (2, v_MEXP_2DTYPE_3, LREF(s_lsp_T));
if (t1 != NIL) {
return(LREF(s_lsp_T));
} else {
if (v_MEXP_2DTYPE_3 != NIL) {
t2 = ICALL(s_lsp_ATOM) (1, v_MEXP_2DTYPE_3);
if (t2 != NIL) {
v_TYPE_4 = ICALL(s_lsp_CONS) (2, v_MEXP_2DTYPE_3, LREF(s_lsp_NIL));
} else {
v_TYPE_4 = v_MEXP_2DTYPE_3;
}
t3 = ICALL(s_lsp_SECOND) (1, v_TYPE_4);
if (t3 != NIL) {
v_SECOND_5 = ICALL(s_lsp_SECOND) (1, v_TYPE_4);
} else {
v_SECOND_5 = LREF(s_lsp__2A);
}
t4 = ICALL(s_lsp_THIRD) (1, v_TYPE_4);
if (t4 != NIL) {
v_THIRD_6 = ICALL(s_lsp_THIRD) (1, v_TYPE_4);
} else {
v_THIRD_6 = LREF(s_lsp__2A);
}
v_KEY2171_8 = ICALL(s_lsp_FIRST) (1, v_TYPE_4);
t5 = ICALL(s_lsp_SYMBOLP) (1, v_KEY2171_8);
if (t5 != NIL) {
t8 = ICALL(s_lsp_SYMBOL_2DHASH_2DCODE) (1, v_KEY2171_8);
t7 = ((LP) ((int) (t8) % (int) ((LP) 56)));
switch ((int) t7) {
case 4:
t9 = ICALL(s_lsp_EQ) (2, v_KEY2171_8, LREF(s_lsp_MEMBER));
if (t9 != NIL) {
t14 = ICALL(s_lsp_CDR) (1, v_MEXP_2DTYPE_3);
t13 = ICALL(s_lsp_CONS) (2, t14, LREF(s_lsp_NIL));
t12 = ICALL(s_lsp_CONS) (2, LREF(s_lsp_QUOTE), t13);
t11 = ICALL(s_lsp_CONS) (2, t12, LREF(s_lsp_NIL));
t10 = ICALL(s_lsp_CONS) (2, v_FORM_0, t11);
t6 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), LREF(s_lsp_MEMBER), t10);
return(t6);
} else {
goto t_DEFAULT_2DTAG2172_9;
}
break;
case 36:
t15 = ICALL(s_lsp_EQ) (2, v_KEY2171_8, LREF(s_lsp_AND));
if (t15 != NIL) {
goto t_C2175_10;
} else {
goto t_DEFAULT_2DTAG2172_9;
}
break;
case 32:
t16 = ICALL(s_lsp_EQ) (2, v_KEY2171_8, LREF(s_lsp_NOT));
if (t16 != NIL) {
goto t_C2175_10;
} else {
goto t_DEFAULT_2DTAG2172_9;
}
break;
case 6:
t17 = ICALL(s_lsp_EQ) (2, v_KEY2171_8, LREF(s_lsp_OR));
if (t17 != NIL) {
t18 = ICALL(s_lsp_EQUAL) (2, v_TYPE_4, LREF(k1772));
if (t18 != NIL) {
t19 = ICALL(s_lsp_CONS) (2, v_FORM_0, LREF(s_lsp_NIL));
t6 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), LREF(s_lsp_NUMBERP), t19);
return(t6);
} else {
t20 = ICALL(s_lsp_EQUAL) (2, v_TYPE_4, LREF(k1777));
if (t20 != NIL) {
t21 = ICALL(s_lsp_CONS) (2, v_FORM_0, LREF(s_lsp_NIL));
t6 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), LREF(s_lsp_LISTP), t21);
return(t6);
} else {
t6 = ICALL(s_lsp_REWRITE_2DCOMBINED_2DTYPE) (MV_CALL(argc,2), v_FORM_0, v_TYPE_4);
return(t6);
}
}
} else {
goto t_DEFAULT_2DTAG2172_9;
}
break;
case 24:
t22 = ICALL(s_lsp_EQ) (2, v_KEY2171_8, LREF(s_lsp_SYMBOL));
if (t22 != NIL) {
t23 = ICALL(s_lsp_CONS) (2, v_FORM_0, LREF(s_lsp_NIL));
t6 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), LREF(s_lsp_SYMBOLP), t23);
return(t6);
} else {
goto t_DEFAULT_2DTAG2172_9;
}
break;
case 28:
t24 = ICALL(s_lsp_EQ) (2, v_KEY2171_8, LREF(s_lsp_CHARACTER));
if (t24 != NIL) {
t25 = ICALL(s_lsp_CONS) (2, v_FORM_0, LREF(s_lsp_NIL));
t6 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), LREF(s_lsp_CHARACTERP), t25);
return(t6);
} else {
goto t_DEFAULT_2DTAG2172_9;
}
break;
case 38:
t26 = ICALL(s_lsp_EQ) (2, v_KEY2171_8, LREF(s_lsp_FLOAT));
if (t26 != NIL) {
t27 = ICALL(s_lsp_CONS) (2, v_FORM_0, LREF(s_lsp_NIL));
t6 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), LREF(s_lsp_FLOATP), t27);
return(t6);
} else {
goto t_DEFAULT_2DTAG2172_9;
}
break;
case 2:
t28 = ICALL(s_lsp_EQ) (2, v_KEY2171_8, LREF(s_lsp_INTEGER));
if (t28 != NIL) {
t29 = ICALL(s_lsp_CDR) (1, v_TYPE_4);
if (t29 != NIL) {
t31 = ICALL(s_lsp_FIXNUMP) (1, v_SECOND_5);
if (t31 != NIL) {
t30 = ICALL(s_lsp_FIXNUMP) (1, v_THIRD_6);
} else {
t30 = LREF(s_lsp_NIL);
}
if (t30 != NIL) {
t33 = (num_equal_p((v_SECOND_5), ((LP) -2147483648)));
if (t33 != NIL) {
t32 = (num_equal_p((v_THIRD_6), ((LP) 2147483646)));
} else {
t32 = LREF(s_lsp_NIL);
}
if (t32 != NIL) {
t34 = ICALL(s_lsp_CONS) (2, v_FORM_0, LREF(s_lsp_NIL));
t6 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), LREF(s_lsp_FIXNUMP), t34);
return(t6);
} else {
t36 = (num_equal_p((v_SECOND_5), ((LP) 0)));
if (t36 != NIL) {
t35 = (num_equal_p((v_THIRD_6), ((LP) 2)));
} else {
t35 = LREF(s_lsp_NIL);
}
if (t35 != NIL) {
t37 = ICALL(s_lsp_CONS) (2, v_FORM_0, LREF(s_lsp_NIL));
t6 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), LREF(s_lsp_BITP), t37);
return(t6);
} else {
t39 = ICALL(s_lsp_CONS) (2, v_SECOND_5, LREF(s_lsp_NIL));
t38 = ICALL(s_lsp_CONS) (2, LREF(s_lsp_QUOTE), t39);
t41 = ICALL(s_lsp_CONS) (2, v_THIRD_6, LREF(s_lsp_NIL));
t40 = ICALL(s_lsp_CONS) (2, LREF(s_lsp_QUOTE), t41);
t6 = ICALL(s_lsp_LIST) (MV_CALL(argc,4), LREF(s_lsp_INTEGER_2DRANGE_2DP), v_FORM_0, t38, t40);
return(t6);
}
}
} else {
t43 = ICALL(s_lsp_CONS) (2, v_SECOND_5, LREF(s_lsp_NIL));
t42 = ICALL(s_lsp_CONS) (2, LREF(s_lsp_QUOTE), t43);
t45 = ICALL(s_lsp_CONS) (2, v_THIRD_6, LREF(s_lsp_NIL));
t44 = ICALL(s_lsp_CONS) (2, LREF(s_lsp_QUOTE), t45);
t6 = ICALL(s_lsp_LIST) (MV_CALL(argc,4), LREF(s_lsp_INTEGER_2DRANGE_2DP), v_FORM_0, t42, t44);
return(t6);
}
} else {
t46 = ICALL(s_lsp_CONS) (2, v_FORM_0, LREF(s_lsp_NIL));
t6 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), LREF(s_lsp_INTEGERP), t46);
return(t6);
}
} else {
goto t_DEFAULT_2DTAG2172_9;
}
break;
case 20:
t47 = ICALL(s_lsp_EQ) (2, v_KEY2171_8, LREF(s_lsp_SIMPLE_2DARRAY));
if (t47 != NIL) {
goto t_C2174_11;
} else {
goto t_DEFAULT_2DTAG2172_9;
}
break;
case 40:
t48 = ICALL(s_lsp_EQ) (2, v_KEY2171_8, LREF(s_lsp_ARRAY));
if (t48 != NIL) {
goto t_C2174_11;
} else {
goto t_DEFAULT_2DTAG2172_9;
}
break;
case 8:
t49 = ICALL(s_lsp_EQ) (2, v_KEY2171_8, LREF(s_lsp_SATISFIES));
if (t49 != NIL) {
t50 = ICALL(s_lsp_SECOND) (1, v_TYPE_4);
t51 = ICALL(s_lsp_CONS) (2, v_FORM_0, LREF(s_lsp_NIL));
t6 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t50, t51);
return(t6);
} else {
goto t_DEFAULT_2DTAG2172_9;
}
break;
default:
goto t_DEFAULT_2DTAG2172_9;
break;
}
return(t6);
}
t_DEFAULT_2DTAG2172_9:;
t52 = ICALL(s_lsp_FIRST) (1, v_TYPE_4);
t53 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ASTRUCTURE_2DINFO_2A));
v_INFO_12 = ICALL(s_lsp_GETHASH) (2, t52, t53);
v_G2176_15 = ICALL(s_lsp_NULL) (1, v_INFO_12);
if (v_G2176_15 != NIL) {
t55 = v_G2176_15;
} else {
v_S_16 = v_INFO_12;
t56 = ICALL(s_lsp_STRUCTURE_2DELT) (2, v_INFO_12, (LP) 24);
t55 = ICALL(s_lsp_NOT) (1, t56);
}
if (t55 != NIL) {
{
int real_argc;
BEGIN_MV_CALL(mv_holder1770,0);
t57 = ICALL(s_lsp_TYPE_2DMACROEXPAND) (MV_CALL(mv_holder1770,1), v_TYPE_4);
SET_MV_RETURN_VALUE(mv_holder1770,0,t57);
if SV_RETURN_P(mv_holder1770) SET_MV_RETURN_COUNT(mv_holder1770,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder1770);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_NEW_2DTYPE_13 = NIL;
} else {
v_NEW_2DTYPE_13 = NEXT_VAR_VALUE(mv_holder1770);
}
if (real_argc < 2) {
v_REWRITE_3F_14 = NIL;
} else {
v_REWRITE_3F_14 = NEXT_VAR_VALUE(mv_holder1770);
}
END_VAR_VALUES;
END_MV_CALL;
if (v_REWRITE_3F_14 != NIL) {
v_ANY_2DTYPE_1 = v_NEW_2DTYPE_13; 
goto START1771;
} else {
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,LREF(s_lsp_T));
}
return(LREF(s_lsp_NIL));
}
}
} else {
t58 = ICALL(s_lsp_PREDICATE_2DNAME) (1, v_INFO_12);
t59 = ICALL(s_lsp_CONS) (2, v_FORM_0, LREF(s_lsp_NIL));
t54 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t58, t59);
return(t54);
}
return(t54);
t_C2175_10:;
t60 = ICALL(s_lsp_REWRITE_2DCOMBINED_2DTYPE) (MV_CALL(argc,2), v_FORM_0, v_TYPE_4);
return(t60);
return(NIL);
t_C2174_11:;
t61 = ICALL(s_lsp_REWRITE_2DARRAY_2DTYPEP) (MV_CALL(argc,4), v_FORM_0, v_TYPE_4, v_SECOND_5, v_THIRD_6);
return(t61);
return(NIL);
return(NIL);
} else {
return(LREF(s_lsp_NIL));
}
}
}

LP p_lsp_REWRITE_2DCOMBINED_2DTYPE(argc, v_FORM_0, v_TYPE_1)
      ARGC argc;  LP v_FORM_0; LP v_TYPE_1;
{
LP v_X_12; LP v_LOOPVAR_2D737_8; LP v_LOOPVAR_2D736_7; 
LP v_LOOPVAR_2D735_6; LP v_LOOP_2DLIST_2D734_5; LP v_L2177_4; 
LP v_TMP_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; 
if (argc != 2) wna(argc,2);
v_TMP_3 = ICALL(s_lsp_GENSYM) (1, LREF(k1780));
t4 = ICALL(s_lsp_CONS) (2, v_FORM_0, LREF(s_lsp_NIL));
t3 = ICALL(s_lsp_CONS) (2, v_TMP_3, t4);
t2 = ICALL(s_lsp_CONS) (2, t3, LREF(s_lsp_NIL));
t7 = ICALL(s_lsp_FIRST) (1, v_TYPE_1);
v_L2177_4 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D734_5 = ICALL(s_lsp_REST) (1, v_TYPE_1);
v_LOOPVAR_2D735_6 = LREF(s_lsp_NIL);
v_LOOPVAR_2D736_7 = LREF(s_lsp_NIL);
v_LOOPVAR_2D737_8 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_10:;
if (v_LOOP_2DLIST_2D734_5 == NIL) {
goto t_END_2DLOOP_11;
}
v_L2177_4 = ICALL(s_lsp_CAR) (1, v_LOOP_2DLIST_2D734_5);
v_LOOP_2DLIST_2D734_5 = ICALL(s_lsp_CDR) (1, v_LOOP_2DLIST_2D734_5);
v_X_12 = v_L2177_4;
t9 = ICALL(s_lsp_REWRITE_2DTYPEP) (2, v_TMP_3, v_X_12);
v_LOOPVAR_2D737_8 = ICALL(s_lsp_CONS) (2, t9, LREF(s_lsp_NIL));
if (v_LOOPVAR_2D736_7 != NIL) {
t10 = ICALL(s_lsp_RPLACD) (2, v_LOOPVAR_2D736_7, v_LOOPVAR_2D737_8);
v_LOOPVAR_2D736_7 = ICALL(s_lsp_CDR) (1, t10);
} else {
v_LOOPVAR_2D735_6 = v_LOOPVAR_2D737_8;
v_LOOPVAR_2D736_7 = v_LOOPVAR_2D735_6;
}
goto t_NEXT_2DLOOP_10;
goto t_END_2DLOOP_11;
t_END_2DLOOP_11:;
t8 = v_LOOPVAR_2D735_6;
goto b_NIL_9;
t8 = NIL;
b_NIL_9:;
t6 = ICALL(s_lsp_CONS) (2, t7, t8);
t5 = ICALL(s_lsp_CONS) (2, t6, LREF(s_lsp_NIL));
t1 = ICALL(s_lsp_CONS) (2, t2, t5);
t0 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), LREF(s_lsp_LET), t1);
return(t0);
}

LP p_lsp_REWRITE_2DARRAY_2DTYPEP(argc, v_FORM_0, v_TYPE_1, v_SECOND_2, v_THIRD_3)
      ARGC argc;  LP v_FORM_0; LP v_TYPE_1; LP v_SECOND_2; LP v_THIRD_3;
{
LP v_KEY2178_8; LP v_TYPE_2DCODE_7; LP v_ELEMENT_2DTYPE_6; 
LP f_PRED_5; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; 
if (argc != 4) wna(argc,4);
t0 = NEW_OE(1);
SET_OE_SLOT(t0,0,v_TYPE_1);
t1 = MAKE_CLOSURE(p_lsp_REWRITE_2DARRAY_2DTYPEP_2DPRED1781,t0);
f_PRED_5 = t1;
t2 = ICALL(s_lsp_EQ) (2, v_SECOND_2, LREF(s_lsp__2A));
if (t2 != NIL) {
v_ELEMENT_2DTYPE_6 = LREF(s_lsp_T);
} else {
v_ELEMENT_2DTYPE_6 = v_SECOND_2;
}
t4 = ICALL(s_lsp_CDR) (1, GET_OE_SLOT(t0,0));
if (t4 != NIL) {
t6 = ICALL(s_lsp_LISTP) (1, v_THIRD_3);
if (t6 != NIL) {
t7 = ICALL(s_lsp_LENGTH) (1, v_THIRD_3);
t5 = (num_equal_p((t7), ((LP) 2)));
} else {
t5 = LREF(s_lsp_NIL);
}
if (t5 != NIL) {
v_TYPE_2DCODE_7 = ICALL(s_lsp_TYPE_2D_3EELEMENT_2DTYPE_2DTAG) (1, v_ELEMENT_2DTYPE_6);
v_KEY2178_8 = v_TYPE_2DCODE_7;
t8 = ICALL(s_lsp_EQL) (2, v_KEY2178_8, (LP) 48);
if (t8 != NIL) {
t9 = CODE_PTR(COERCE_TO_FUNCTION(f_PRED_5))(1, LREF(s_lsp_STRING_2DP));
t10 = ICALL(s_lsp_CONS) (2, v_FORM_0, LREF(s_lsp_NIL));
t3 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t9, t10);
return(t3);
} else {
t11 = ICALL(s_lsp_EQL) (2, v_KEY2178_8, (LP) 144);
if (t11 != NIL) {
t12 = CODE_PTR(COERCE_TO_FUNCTION(f_PRED_5))(1, LREF(s_lsp_FLOAT_2DVECTOR_2DP));
t13 = ICALL(s_lsp_CONS) (2, v_FORM_0, LREF(s_lsp_NIL));
t3 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t12, t13);
return(t3);
} else {
t14 = ICALL(s_lsp_EQL) (2, v_KEY2178_8, (LP) 0);
if (t14 != NIL) {
t15 = CODE_PTR(COERCE_TO_FUNCTION(f_PRED_5))(1, LREF(s_lsp_BIT_2DVECTOR_2DP));
t16 = ICALL(s_lsp_CONS) (2, v_FORM_0, LREF(s_lsp_NIL));
t3 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t15, t16);
return(t3);
} else {
t17 = ICALL(s_lsp_EQL) (2, v_KEY2178_8, (LP) 16);
if (t17 != NIL) {
t18 = CODE_PTR(COERCE_TO_FUNCTION(f_PRED_5))(1, LREF(s_lsp_SIGNED_2D8BIT_2DVECTOR_2DP));
t19 = ICALL(s_lsp_CONS) (2, v_FORM_0, LREF(s_lsp_NIL));
t3 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t18, t19);
return(t3);
} else {
t20 = ICALL(s_lsp_EQL) (2, v_KEY2178_8, (LP) 32);
if (t20 != NIL) {
t21 = CODE_PTR(COERCE_TO_FUNCTION(f_PRED_5))(1, LREF(s_lsp_UNSIGNED_2D8BIT_2DVECTOR_2DP));
t22 = ICALL(s_lsp_CONS) (2, v_FORM_0, LREF(s_lsp_NIL));
t3 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t21, t22);
return(t3);
} else {
t23 = ICALL(s_lsp_EQL) (2, v_KEY2178_8, (LP) 64);
if (t23 != NIL) {
t24 = CODE_PTR(COERCE_TO_FUNCTION(f_PRED_5))(1, LREF(s_lsp_SIGNED_2D16BIT_2DVECTOR_2DP));
t25 = ICALL(s_lsp_CONS) (2, v_FORM_0, LREF(s_lsp_NIL));
t3 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t24, t25);
return(t3);
} else {
t26 = ICALL(s_lsp_EQL) (2, v_KEY2178_8, (LP) 80);
if (t26 != NIL) {
t27 = CODE_PTR(COERCE_TO_FUNCTION(f_PRED_5))(1, LREF(s_lsp_UNSIGNED_2D16BIT_2DVECTOR_2DP));
t28 = ICALL(s_lsp_CONS) (2, v_FORM_0, LREF(s_lsp_NIL));
t3 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t27, t28);
return(t3);
} else {
t29 = ICALL(s_lsp_EQL) (2, v_KEY2178_8, (LP) 96);
if (t29 != NIL) {
t30 = CODE_PTR(COERCE_TO_FUNCTION(f_PRED_5))(1, LREF(s_lsp_SIGNED_2D32BIT_2DVECTOR_2DP));
t31 = ICALL(s_lsp_CONS) (2, v_FORM_0, LREF(s_lsp_NIL));
t3 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t30, t31);
return(t3);
} else {
t32 = ICALL(s_lsp_EQL) (2, v_KEY2178_8, (LP) 112);
if (t32 != NIL) {
t33 = CODE_PTR(COERCE_TO_FUNCTION(f_PRED_5))(1, LREF(s_lsp_UNSIGNED_2D32BIT_2DVECTOR_2DP));
t34 = ICALL(s_lsp_CONS) (2, v_FORM_0, LREF(s_lsp_NIL));
t3 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t33, t34);
return(t3);
} else {
t35 = CODE_PTR(COERCE_TO_FUNCTION(f_PRED_5))(1, LREF(s_lsp_VECTOR_2DP));
t36 = ICALL(s_lsp_CONS) (2, v_FORM_0, LREF(s_lsp_NIL));
t3 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t35, t36);
return(t3);
}
}
}
}
}
}
}
}
}
} else {
t37 = CODE_PTR(COERCE_TO_FUNCTION(f_PRED_5))(1, LREF(s_lsp_ARRAY_2DTYPE_2DP));
t39 = ICALL(s_lsp_CONS) (2, v_ELEMENT_2DTYPE_6, LREF(s_lsp_NIL));
t38 = ICALL(s_lsp_CONS) (2, LREF(s_lsp_QUOTE), t39);
t41 = ICALL(s_lsp_CONS) (2, v_THIRD_3, LREF(s_lsp_NIL));
t40 = ICALL(s_lsp_CONS) (2, LREF(s_lsp_QUOTE), t41);
t3 = ICALL(s_lsp_LIST) (MV_CALL(argc,4), t37, v_FORM_0, t38, t40);
return(t3);
}
} else {
t42 = CODE_PTR(COERCE_TO_FUNCTION(f_PRED_5))(1, LREF(s_lsp_ARRAY_2DP));
t43 = ICALL(s_lsp_CONS) (2, v_FORM_0, LREF(s_lsp_NIL));
t3 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t42, t43);
return(t3);
}
}

LP p_lsp_REWRITE_2DARRAY_2DTYPEP_2DPRED1781(argc, v_NAME_0)
      ARGC argc;  LP v_NAME_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 

if (argc != 1) wna(argc,1);
t0 = OE;
t3 = ICALL(s_lsp_FIRST) (1, GET_OE_SLOT(t0,0));
t2 = ICALL(s_lsp_EQ) (2, t3, LREF(s_lsp_SIMPLE_2DARRAY));
if (t2 != NIL) {
t5 = ICALL(s_lsp_STRING) (1, v_NAME_0);
t4 = ICALL(s_lsp_CONCATENATE) (3, LREF(s_lsp_STRING), LREF(k1782), t5);
t6 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ALISP_2DPACKAGE_2A));
t1 = ICALL(s_lsp_INTERN) (MV_CALL(argc,2), t4, t6);
return(t1);
} else {
return(v_NAME_0);
}
}

LP p_lsp_TYPE_2DMACROEXPAND(va_alist) va_dcl
{
LP v_G2179_7; LP v_EXPANDED_3F_6; LP v_NEW_2DFORM_5; 
LP v_LIST_2DFORM_4; LP v_FORM_0; LP v_ALREADY_2DEXPANDED_3F_2; 
LP v_LOCAL_2DMACRO_2DENV_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_FORM_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 3) wna_high(real_argc,3);
if (real_argc < 2) {
v_LOCAL_2DMACRO_2DENV_1 = NIL;
} else {
v_LOCAL_2DMACRO_2DENV_1 = NEXT_VAR_ARG;
}
if (real_argc < 3) {
v_ALREADY_2DEXPANDED_3F_2 = NIL;
} else {
v_ALREADY_2DEXPANDED_3F_2 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t0 = ICALL(s_lsp_LISTP) (1, v_FORM_0);
if (t0 != NIL) {
v_LIST_2DFORM_4 = v_FORM_0;
} else {
v_LIST_2DFORM_4 = ICALL(s_lsp_CONS) (2, v_FORM_0, LREF(s_lsp_NIL));
}
{
int real_argc;
BEGIN_MV_CALL(mv_holder1783,0);
t2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ATYPE_2DMACRO_2DEXPANDERS_2A));
t1 = ICALL(s_lsp_EXPAND_2DMACRO) (MV_CALL(mv_holder1783,5), v_LIST_2DFORM_4, t2, v_LOCAL_2DMACRO_2DENV_1, LREF(s_lsp_T), LREF(s_lsp_NIL));
SET_MV_RETURN_VALUE(mv_holder1783,0,t1);
if SV_RETURN_P(mv_holder1783) SET_MV_RETURN_COUNT(mv_holder1783,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder1783);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_NEW_2DFORM_5 = NIL;
} else {
v_NEW_2DFORM_5 = NEXT_VAR_VALUE(mv_holder1783);
}
if (real_argc < 2) {
v_EXPANDED_3F_6 = NIL;
} else {
v_EXPANDED_3F_6 = NEXT_VAR_VALUE(mv_holder1783);
}
END_VAR_VALUES;
END_MV_CALL;
if (v_EXPANDED_3F_6 != NIL) {
t3 = ICALL(s_lsp_TYPE_2DMACROEXPAND) (MV_CALL(argc,3), v_NEW_2DFORM_5, v_LOCAL_2DMACRO_2DENV_1, LREF(s_lsp_T));
return(t3);
} else {
t4 = ICALL(s_lsp_EXPAND_2DINNER_2DTYPES) (1, v_FORM_0);
v_G2179_7 = v_ALREADY_2DEXPANDED_3F_2;
if (v_G2179_7 != NIL) {
t5 = v_G2179_7;
} else {
t5 = v_EXPANDED_3F_6;
}
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,t5);
}
return(t4);
}
}
}

LP p_lsp_EXPAND_2DINNER_2DTYPES(argc, v_TYPE_0)
      ARGC argc;  LP v_TYPE_0;
{
LP v_G2181_3; LP v_G2180_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 

if (argc != 1) wna(argc,1);
t2 = ICALL(s_lsp_LISTP) (1, v_TYPE_0);
if (t2 != NIL) {
t3 = ICALL(s_lsp_FIRST) (1, v_TYPE_0);
v_G2181_3 = ICALL(s_lsp_EQ) (2, t3, LREF(s_lsp_ARRAY));
if (v_G2181_3 != NIL) {
t4 = v_G2181_3;
} else {
t5 = ICALL(s_lsp_FIRST) (1, v_TYPE_0);
t4 = ICALL(s_lsp_EQ) (2, t5, LREF(s_lsp_SIMPLE_2DARRAY));
}
if (t4 != NIL) {
t7 = ICALL(s_lsp_SECOND) (1, v_TYPE_0);
t6 = ICALL(s_lsp_NULL) (1, t7);
t1 = ICALL(s_lsp_NOT) (1, t6);
} else {
t1 = LREF(s_lsp_NIL);
}
} else {
t1 = LREF(s_lsp_NIL);
}
if (t1 != NIL) {
t8 = ICALL(s_lsp_FIRST) (1, v_TYPE_0);
t10 = ICALL(s_lsp_SECOND) (1, v_TYPE_0);
t9 = ICALL(s_lsp_TYPE_2DMACROEXPAND) (1, t10);
v_G2180_2 = ICALL(s_lsp_CDDR) (1, v_TYPE_0);
if (v_G2180_2 != NIL) {
t11 = v_G2180_2;
} else {
t11 = LREF(k1784);
}
t0 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,3), t8, t9, t11);
return(t0);
} else {
return(v_TYPE_0);
}
}

LP p_lsp_COLLECT_2DCASES(argc, v_CASES_0)
      ARGC argc;  LP v_CASES_0;
{
LP v_LOOPVAR_2D741_7; LP v_LOOPVAR_2D740_6; LP v_LOOPVAR_2D739_5; 
LP v_LOOP_2DLIST_2D738_4; LP v_IGNORE_3; LP v_CASE_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 

if (argc != 1) wna(argc,1);
v_CASE_2 = LREF(s_lsp_NIL);
v_IGNORE_3 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D738_4 = v_CASES_0;
v_LOOPVAR_2D739_5 = LREF(s_lsp_NIL);
v_LOOPVAR_2D740_6 = LREF(s_lsp_NIL);
v_LOOPVAR_2D741_7 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_9:;
if (v_LOOP_2DLIST_2D738_4 == NIL) {
goto t_END_2DLOOP_10;
}
t1 = ICALL(s_lsp_CAR) (1, v_LOOP_2DLIST_2D738_4);
v_CASE_2 = ICALL(s_lsp_CAR) (1, t1);
t2 = ICALL(s_lsp_CAR) (1, v_LOOP_2DLIST_2D738_4);
v_IGNORE_3 = ICALL(s_lsp_CDR) (1, t2);
v_LOOP_2DLIST_2D738_4 = ICALL(s_lsp_CDR) (1, v_LOOP_2DLIST_2D738_4);
t4 = ICALL(s_lsp_LISTP) (1, v_CASE_2);
if (t4 != NIL) {
t3 = v_CASE_2;
} else {
t3 = ICALL(s_lsp_CONS) (2, v_CASE_2, LREF(s_lsp_NIL));
}
v_LOOPVAR_2D741_7 = ICALL(s_lsp_COPY_2DLIST) (1, t3);
if (v_LOOPVAR_2D741_7 != NIL) {
if (v_LOOPVAR_2D740_6 != NIL) {
t6 = ICALL(s_lsp_RPLACD) (2, v_LOOPVAR_2D740_6, v_LOOPVAR_2D741_7);
t5 = ICALL(s_lsp_CDR) (1, t6);
} else {
v_LOOPVAR_2D739_5 = v_LOOPVAR_2D741_7;
t5 = v_LOOPVAR_2D739_5;
}
v_LOOPVAR_2D740_6 = ICALL(s_lsp_LAST) (1, t5);
}
goto t_NEXT_2DLOOP_9;
goto t_END_2DLOOP_10;
t_END_2DLOOP_10:;
return(v_LOOPVAR_2D739_5);
return(NIL);
return(NIL);
}

LP p_lsp_PROCESSOR_2BOS_2D_3EMACHINE_2DTYPE(argc, v_PROCESSOR_0, v_OS_1)
      ARGC argc;  LP v_PROCESSOR_0; LP v_OS_1;
{
LP v_TYPE_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_STRING_2DEQUAL) (2, v_OS_1, LREF(k1785));
if (t0 != NIL) {
t1 = ICALL(s_lsp_STRING_2DEQUAL) (2, v_PROCESSOR_0, LREF(k1786));
if (t1 != NIL) {
v_TYPE_3 = LREF(s_key_SUN_2D4);
} else {
v_TYPE_3 = LREF(s_lsp_NIL);
}
} else {
t2 = ICALL(s_lsp_STRING_2DEQUAL) (2, v_OS_1, LREF(k1787));
if (t2 != NIL) {
t3 = ICALL(s_lsp_STRING_2DEQUAL) (2, v_PROCESSOR_0, LREF(k1788));
if (t3 != NIL) {
v_TYPE_3 = LREF(s_key_IRIS);
} else {
v_TYPE_3 = LREF(s_lsp_NIL);
}
} else {
v_TYPE_3 = LREF(s_lsp_NIL);
}
}
if (v_TYPE_3 != NIL) {
return(v_TYPE_3);
} else {
t4 = ICALL(s_lsp_WARN) (MV_CALL(argc,3), LREF(k1789), v_PROCESSOR_0, v_OS_1);
return(t4);
}
}

LP p_lsp_MACHINE_2DBYTE_2DORDER(argc, v_MACHINE_2DTYPE_0)
      ARGC argc;  LP v_MACHINE_2DTYPE_0;
{
LP v_KEY2182_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
if (argc != 1) wna(argc,1);
v_KEY2182_2 = v_MACHINE_2DTYPE_0;
t1 = ICALL(s_lsp_EQL) (2, v_KEY2182_2, LREF(s_key_SUN_2D4));
if (t1 != NIL) {
return(LREF(s_key_BIG_2DENDIAN));
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY2182_2, LREF(s_key_IRIS));
if (t2 != NIL) {
return(LREF(s_key_BIG_2DENDIAN));
} else {
t3 = ICALL(s_lsp_EQL) (2, v_KEY2182_2, LREF(s_key_DECSTATION));
if (t3 != NIL) {
return(LREF(s_key_LITTLE_2DENDIAN));
} else {
return(LREF(s_lsp_NIL));
}
}
}
}

LP p_lsp_UNIX_2D_3ELISP_2DPATH_2DLIST(argc, v_STRING_0)
      ARGC argc;  LP v_STRING_0;
{
LP f_DOIT_3; LP v_LEN_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = NEW_OE(3);
SET_OE_SLOT(t0,2,v_STRING_0);
v_LEN_2 = ICALL(s_lsp_LENGTH) (1, GET_OE_SLOT(t0,2));
SET_OE_SLOT(t0,1,v_LEN_2);
t1 = MAKE_CLOSURE(p_lsp_UNIX_2D_3ELISP_2DPATH_2DLIST_2DDOIT1790,t0);
f_DOIT_3 = t1;
SET_OE_SLOT(t0,0,f_DOIT_3);
t2 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(MV_CALL(argc,1), (LP) 0);
return(t2);
}

LP p_lsp_UNIX_2D_3ELISP_2DPATH_2DLIST_2DDOIT1790(argc, v_START_0)
      ARGC argc;  LP v_START_0;
{
LP v_END_3; LP v_G2183_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; 
if (argc != 1) wna(argc,1);
t0 = OE;
t2 = (geq_p((v_START_0), (GET_OE_SLOT(t0,1))));
if (t2 != NIL) {
return(LREF(s_lsp_NIL));
} else {
v_G2183_2 = ICALL(s_lsp_POSITION) (4, LREF(char_tab[58]), GET_OE_SLOT(t0,2), LREF(s_key_START), v_START_0);
if (v_G2183_2 != NIL) {
v_END_3 = v_G2183_2;
} else {
v_END_3 = GET_OE_SLOT(t0,1);
}
t3 = ICALL(s_lsp_SUBSEQ) (3, GET_OE_SLOT(t0,2), v_START_0, v_END_3);
t5 = ICALL(s_lsp_1_2B) (1, v_END_3);
t4 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(1, t5);
t1 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t3, t4);
return(t1);
}
}

LP p_lsp_SETF_2DFUNCTION_2DSYMBOL(argc, v_FUNCTION_2DSPECIFIER_0)
      ARGC argc;  LP v_FUNCTION_2DSPECIFIER_0;
{
LP v_G2184_3; LP v_ACCESSOR_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; 
if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_CONSP) (1, v_FUNCTION_2DSPECIFIER_0);
if (t1 != NIL) {
v_ACCESSOR_2 = ICALL(s_lsp_SECOND) (1, v_FUNCTION_2DSPECIFIER_0);
t2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ASETF_2DMETHODS_2A));
v_G2184_3 = ICALL(s_lsp_GETHASH) (2, v_ACCESSOR_2, t2);
if (v_G2184_3 != NIL) {
return(v_G2184_3);
} else {
t3 = ICALL(s_lsp_FORMAT) (3, LREF(s_lsp_NIL), LREF(k1791), v_ACCESSOR_2);
t4 = ICALL(s_lsp_SYMBOL_2DPACKAGE) (1, v_ACCESSOR_2);
t0 = ICALL(s_lsp_INTERN) (MV_CALL(argc,2), t3, t4);
return(t0);
}
} else {
return(v_FUNCTION_2DSPECIFIER_0);
}
}

LP p_lsp_SET_2DFDEFINITION(argc, v_NEW_2DVALUE_0, v_FUNCTION_2DSPECIFIER_1)
      ARGC argc;  LP v_NEW_2DVALUE_0; LP v_FUNCTION_2DSPECIFIER_1;
{
LP v_T2188_6; LP v_S2187_5; LP v_T2186_4; 
LP v_S2185_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; 
if (argc != 2) wna(argc,2);
t1 = ICALL(s_lsp_CONSP) (1, v_FUNCTION_2DSPECIFIER_1);
if (t1 != NIL) {
v_S2185_3 = v_NEW_2DVALUE_0;
v_T2186_4 = ICALL(s_lsp_SETF_2DFUNCTION_2DSYMBOL) (1, v_FUNCTION_2DSPECIFIER_1);
ICALL(s_lsp_SET_2DSYMBOL_2DFUNCTION) (2, v_T2186_4, v_NEW_2DVALUE_0);
t3 = ICALL(s_lsp_CADR) (1, v_FUNCTION_2DSPECIFIER_1);
t7 = ICALL(s_lsp_SETF_2DFUNCTION_2DSYMBOL) (1, v_FUNCTION_2DSPECIFIER_1);
t6 = ICALL(s_lsp_CONS) (2, t7, LREF(s_lsp_NIL));
t5 = ICALL(s_lsp_CONS) (2, LREF(s_lsp_QUOTE), t6);
t4 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_LIST_2A), t5, LREF(k1795));
t2 = ICALL(s_lsp_LIST) (5, LREF(s_lsp_DEFSETF), t3, LREF(k1792), LREF(k1794), t4);
t0 = ICALL(s_lsp_EVAL) (MV_CALL(argc,1), t2);
return(t0);
} else {
v_S2187_5 = v_NEW_2DVALUE_0;
v_T2188_6 = v_FUNCTION_2DSPECIFIER_1;
t0 = ICALL(s_lsp_SET_2DSYMBOL_2DFUNCTION) (MV_CALL(argc,2), v_FUNCTION_2DSPECIFIER_1, v_NEW_2DVALUE_0);
return(t0);
}
}

