/*
:comment "Compiled at 4:20:53 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: Debug Library"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O2 -fPIC"
:version 0
:end-package-info 0
:proclaim (QUOTE (INLINE BOUNDP))
:sym SYMBOLP
:sym SYMBOL
:sym WTA
:sf BOUNDP "p_lsp_BOUNDP"
:sym CLEAR-SYMBOL-FLAG
:sf CLEAR-MACRO-NAME-FLAG "p_lsp_CLEAR_2DMACRO_2DNAME_2DFLAG"
:sym FIXNUMP
:sym FIXNUM
:sf CLEAR-SYMBOL-FLAG "p_lsp_CLEAR_2DSYMBOL_2DFLAG"
:sym WARN
:sf COPY-SYMBOL "p_lsp_COPY_2DSYMBOL"
:sym :DEFMETHOD
:sym EQ
:sym SET-SYMBOL-FUNCTION
:sym CLEAR-MACRO-NAME-FLAG
:sf DEFINE-FUNCTION "p_lsp_DEFINE_2DFUNCTION"
:sym :VAR
:sym EQL
:sym PROCLAIM-SPECIAL-VARIABLE
:sym NIL
:sym SET
:sym :PARAMETER
:sym :CONSTANT
:sym *CONSTANT-REDEFINITION-VERBOSE*
:sym UNSAFE-SYMBOL-VALUE
:sym CONSTANT-VAR?
:sym DEFINE-CONSTANT
:sf DEFINE-VARIABLE "p_lsp_DEFINE_2DVARIABLE"
:sym SET-SYMBOL-FLAG
:sym CONSTANT-VALUE
:sym SET-GET
:sf PROCLAIM-CONSTANT-VARIABLE "p_lsp_PROCLAIM_2DCONSTANT_2DVARIABLE"
:sym PROCLAIM-CONSTANT-VARIABLE
:sf DEFINE-CONSTANT "p_lsp_DEFINE_2DCONSTANT"
:sym *UNBOUND*
:sym GET
:sym ERROR
:sf CONSTANT-EXPR "p_lsp_CONSTANT_2DEXPR"
:sym SPECIAL-VAR?
:sym :SPECIAL
:sf PROCLAIMED-SPECIAL? "p_lsp_PROCLAIMED_2DSPECIAL_3F"
:sf PROCLAIM-SPECIAL-VARIABLE "p_lsp_PROCLAIM_2DSPECIAL_2DVARIABLE"
:proclaim (QUOTE (INLINE CONSTANT-VAR?))
:sym SYMBOL-FLAG
:sf CONSTANT-VAR? "p_lsp_CONSTANT_2DVAR_3F"
:sf DELETE-PROPERTY "p_lsp_DELETE_2DPROPERTY"
:sym CONSP
:sym FUNCTION-SPECIFIER
:sym SETF-FUNCTION-SYMBOL
:sf FBOUNDP "p_lsp_FBOUNDP"
:sym UNSAFE-SYMBOL-FUNCTION
:sf FDEFINITION "p_lsp_FDEFINITION"
:sf FMAKUNBOUND "p_lsp_FMAKUNBOUND"
:sym *GENSYM-COUNTER*
:sym SIMPLE-STRING-P
:sym *GENSYM-PREFIX*
:sym STRING+NUMBER->STRING
:sym MAKE-SYMBOL
:sf GENSYM/1 "p_lsp_GENSYM_2F1"
:proclaim (QUOTE (INLINE GENSYM))
:sym GENSYM/1
:sf GENSYM "p_lsp_GENSYM"
:proclaim (QUOTE (INLINE GENTEMP))
:sym *PACKAGE*
:sym GENTEMP/2
:sf GENTEMP "p_lsp_GENTEMP"
:sym *GENTEMP-COUNTER*
:sym COERCE-TO-PACKAGE
:sym INTERN/2
:sf GENTEMP/2 "p_lsp_GENTEMP_2F2"
:sym FILL-STRING-WITH-INTEGER
:sf STRING+NUMBER->STRING "p_lsp_STRING_2BNUMBER_2D_3ESTRING"
:sym MAKE-SIMPLE-STRING
:sf FILL-STRING-WITH-INTEGER "p_lsp_FILL_2DSTRING_2DWITH_2DINTEGER"
:sym MEMQ
:sf GET-PROPERTIES "p_lsp_GET_2DPROPERTIES"
:proclaim (QUOTE (INLINE GET))
:sym SYMBOL-PLIST
:sym LOOKUP-PROP
:sf GET "p_lsp_GET"
:sf GETF "p_lsp_GETF"
:sym SYMBOL-PACKAGE
:sym *KEYWORD-PACKAGE*
:sf KEYWORDP "p_lsp_KEYWORDP"
:sf LOOKUP-PROP "p_lsp_LOOKUP_2DPROP"
:sf MACRO-NAME? "p_lsp_MACRO_2DNAME_3F"
:proclaim (QUOTE (INLINE MAKE-SYMBOL))
:sym SXHASH/SIMPLE-STRING
:sf MAKE-SYMBOL "p_lsp_MAKE_2DSYMBOL"
:sf MAKE-STATIC-SYMBOL "p_lsp_MAKE_2DSTATIC_2DSYMBOL"
:proclaim (QUOTE (INLINE MAKUNBOUND))
:sf MAKUNBOUND "p_lsp_MAKUNBOUND"
:proclaim (QUOTE (INLINE SYMBOL-PRINT-ESCAPE-FLAG-VALID?))
:sf SYMBOL-PRINT-ESCAPE-FLAG-VALID? "p_lsp_SYMBOL_2DPRINT_2DESCAPE_2DFLAG_2DVALID_3F"
:proclaim (QUOTE (INLINE SYMBOL-PRINT-ESCAPE?))
:sf SYMBOL-PRINT-ESCAPE? "p_lsp_SYMBOL_2DPRINT_2DESCAPE_3F"
:proclaim (QUOTE (INLINE SET-SYMBOL-PRINT-ESCAPE-FLAG-VALID?))
:sf SET-SYMBOL-PRINT-ESCAPE-FLAG-VALID? "p_lsp_SET_2DSYMBOL_2DPRINT_2DESCAPE_2DFLAG_2DVALID_3F"
:proclaim (QUOTE (INLINE SET-SYMBOL-PRINT-ESCAPE))
:sf SET-SYMBOL-PRINT-ESCAPE "p_lsp_SET_2DSYMBOL_2DPRINT_2DESCAPE"
:sym ATOM
:sym T
:sym SET-SYMBOL-PLIST
:sf REMPROP "p_lsp_REMPROP"
:proclaim (QUOTE (INLINE SET-GET))
:sym UPDATE-PROP
:sf SET-GET "p_lsp_SET_2DGET"
:sf SET-MACRO-NAME-FLAG "p_lsp_SET_2DMACRO_2DNAME_2DFLAG"
:sf SET-SYMBOL-FLAG "p_lsp_SET_2DSYMBOL_2DFLAG"
:proclaim (QUOTE (INLINE SET-SYMBOL-FUNCTION))
:sym COMPILED-FUNCTION-P
:sym COMPILED-FUNCTION
:sf SET-SYMBOL-FUNCTION "p_lsp_SET_2DSYMBOL_2DFUNCTION"
:proclaim (QUOTE (INLINE SET-SYMBOL-HASH-CODE))
:sf SET-SYMBOL-HASH-CODE "p_lsp_SET_2DSYMBOL_2DHASH_2DCODE"
:proclaim (QUOTE (INLINE SET-SYMBOL-PACKAGE))
:sym PACKAGEP
:sym PACKAGE
:sf SET-SYMBOL-PACKAGE "p_lsp_SET_2DSYMBOL_2DPACKAGE"
:proclaim (QUOTE (INLINE SET-SYMBOL-PLIST))
:sym LISTP
:sym LIST
:sf SET-SYMBOL-PLIST "p_lsp_SET_2DSYMBOL_2DPLIST"
:proclaim (QUOTE (INLINE SET))
:sf SET "p_lsp_SET"
:sf SPECIAL-VAR? "p_lsp_SPECIAL_2DVAR_3F"
:proclaim (QUOTE (INLINE SYMBOL-FLAG))
:sf SYMBOL-FLAG "p_lsp_SYMBOL_2DFLAG"
:proclaim (QUOTE (INLINE UNSAFE-SYMBOL-FUNCTION))
:sf UNSAFE-SYMBOL-FUNCTION "p_lsp_UNSAFE_2DSYMBOL_2DFUNCTION"
:sym SYMBOL-FUNCTION-ERROR
:sf SYMBOL-FUNCTION "p_lsp_SYMBOL_2DFUNCTION"
:proclaim (QUOTE (INLINE UNSAFE-SYMBOL-VALUE))
:sf UNSAFE-SYMBOL-VALUE "p_lsp_UNSAFE_2DSYMBOL_2DVALUE"
:sf SYMBOL-VALUE "p_lsp_SYMBOL_2DVALUE"
:proclaim (QUOTE (INLINE SYMBOL-HASH-CODE))
:sf SYMBOL-HASH-CODE "p_lsp_SYMBOL_2DHASH_2DCODE"
:proclaim (QUOTE (INLINE SYMBOL-NAME))
:sf SYMBOL-NAME "p_lsp_SYMBOL_2DNAME"
:sym *LISP-PACKAGE*
:sf SYMBOL-PACKAGE "p_lsp_SYMBOL_2DPACKAGE"
:proclaim (QUOTE (INLINE SYMBOL-PLIST))
:sf SYMBOL-PLIST "p_lsp_SYMBOL_2DPLIST"
:sf UPDATE-PROP "p_lsp_UPDATE_2DPROP"
:sym FDEFINITION
:sym DEFINE-SETF
:sym SET-FDEFINITION
:sf SYMBOLS_INIT1127 "p_lsp_SYMBOLS_5FINIT1127"
:init SYMBOLS_INIT1127
:pinfo SET-GET (SYMBOL INDICATOR VALUE) NIL NIL NIL (LAMBDA (SYMBOL INDICATOR VALUE) (DECLARE) (BLOCK SET-GET (SETF (SYMBOL-PLIST SYMBOL) (UPDATE-PROP (SYMBOL-PLIST SYMBOL) INDICATOR VALUE)))) NIL T T
:pinfo SET-SYMBOL-PRINT-ESCAPE-FLAG-VALID? (S) NIL NIL NIL (LAMBDA (S) (DECLARE) (BLOCK SET-SYMBOL-PRINT-ESCAPE-FLAG-VALID? (SET-SYMBOL-FLAG S PRINT-ESCAPE-FLAG-VALID?) S)) NIL T T
:pinfo SET-SYMBOL-PRINT-ESCAPE (S) NIL NIL NIL (LAMBDA (S) (DECLARE) (BLOCK SET-SYMBOL-PRINT-ESCAPE (SET-SYMBOL-FLAG S PRINT-ESCAPE-FLAG) S)) NIL T T
:pinfo KEYWORDP (S) NIL NIL NIL NIL NIL NIL T
:pinfo GENTEMP (&OPTIONAL (PREFIX "T") (PACKAGE *PACKAGE*)) NIL NIL NIL (LAMBDA (&OPTIONAL (PREFIX "T") (PACKAGE *PACKAGE*)) (DECLARE) (BLOCK GENTEMP (GENTEMP/2 PREFIX PACKAGE))) NIL T T
:pinfo SYMBOL-NAME (X) NIL (SYMBOL) NIL (LAMBDA (X) (DECLARE) (BLOCK SYMBOL-NAME (%SYMREF X SYMBOL-NAME-OFFSET))) NIL T T
:pinfo PROCLAIM-SPECIAL-VARIABLE (S) NIL NIL NIL NIL NIL NIL T
:pinfo BOUNDP (S) NIL (SYMBOL) NIL (LAMBDA (S) (DECLARE) (BLOCK BOUNDP (%BOUNDP S))) NIL T T
:pinfo DELETE-PROPERTY (LIST INDICATOR) NIL NIL NIL NIL NIL NIL T
:pinfo LOOKUP-PROP (PLIST INDICATOR DEFAULT) NIL NIL NIL NIL NIL NIL T
:pinfo SPECIAL-VAR? (S) NIL NIL NIL NIL NIL NIL T
:pinfo FDEFINITION (F) NIL (FUNCTION-SPECIFIER) NIL NIL NIL NIL T
:pinfo UNSAFE-SYMBOL-VALUE (SYMBOL) NIL NIL NIL (LAMBDA (SYMBOL) (DECLARE) (BLOCK UNSAFE-SYMBOL-VALUE (%SYMREF SYMBOL SYMBOL-VALUE-OFFSET))) NIL T T
:pinfo GETF (PLACE INDICATOR &OPTIONAL (DEFAULT NIL)) NIL NIL NIL NIL NIL NIL T
:pinfo MACRO-NAME? (S) NIL NIL NIL NIL NIL NIL T
:pinfo FMAKUNBOUND (F) NIL (FUNCTION-SPECIFIER) NIL NIL NIL NIL T
:pinfo SYMBOL-FUNCTION (SYMBOL) NIL NIL NIL NIL NIL NIL T
:pinfo GENTEMP/2 (PREFIX PACKAGE) NIL NIL NIL NIL NIL NIL T
:pinfo GENSYM (&OPTIONAL X) NIL NIL NIL (LAMBDA (&OPTIONAL X) (DECLARE) (BLOCK GENSYM (GENSYM/1 X))) NIL T T
:pinfo MAKE-STATIC-SYMBOL (NAME HASH-CODE) NIL NIL NIL NIL NIL NIL T
:pinfo GET (SYMBOL INDICATOR &OPTIONAL DEFAULT) NIL NIL NIL (LAMBDA (SYMBOL INDICATOR &OPTIONAL DEFAULT) (DECLARE) (BLOCK GET (LOOKUP-PROP (SYMBOL-PLIST SYMBOL) INDICATOR DEFAULT))) NIL T T
:pinfo SYMBOL-FLAG (S FLAG) NIL (SYMBOL FIXNUM) NIL (LAMBDA (S FLAG) (DECLARE) (BLOCK SYMBOL-FLAG (%BIT-TEST (%32BIT-REF S SYMBOL-SELF-LINK-OFFSET) SYMBOL-FLAGS-OFFSET FLAG))) NIL T T
:pinfo FBOUNDP (F) NIL (FUNCTION-SPECIFIER) NIL NIL NIL NIL T
:pinfo STRING+NUMBER->STRING (STRING N) NIL NIL NIL NIL NIL NIL T
:pinfo SET-SYMBOL-FUNCTION (X F) NIL (SYMBOL COMPILED-FUNCTION) NIL (LAMBDA (X F) (DECLARE) (BLOCK SET-SYMBOL-FUNCTION (%SYMDEF X SYMBOL-FUNCTION-OFFSET F) F)) NIL T T
:pinfo SET-SYMBOL-FLAG (S FLAG) NIL (SYMBOL FIXNUM) NIL NIL NIL NIL T
:pinfo SET-SYMBOL-PLIST (SYMBOL VALUE) NIL (SYMBOL LIST) NIL (LAMBDA (SYMBOL VALUE) (DECLARE) (BLOCK SET-SYMBOL-PLIST (%SYMDEF SYMBOL SYMBOL-PLIST-OFFSET VALUE) VALUE)) NIL T T
:pinfo FILL-STRING-WITH-INTEGER (EXTRA NEXT INTEGER) NIL NIL NIL NIL NIL NIL T
:pinfo SET-MACRO-NAME-FLAG (S) NIL NIL NIL NIL NIL NIL T
:pinfo CLEAR-SYMBOL-FLAG (S FLAG) NIL (SYMBOL FIXNUM) NIL NIL NIL NIL T
:pinfo SET-SYMBOL-PACKAGE (SYMBOL VALUE) NIL (SYMBOL PACKAGE) NIL (LAMBDA (SYMBOL VALUE) (DECLARE) (BLOCK SET-SYMBOL-PACKAGE (%SYMDEF SYMBOL SYMBOL-PACKAGE-OFFSET (IF (NULL SYMBOL) SYMBOL VALUE)) VALUE)) NIL T T
:pinfo PROCLAIMED-SPECIAL? (S) NIL NIL NIL NIL NIL NIL T
:pinfo DEFINE-CONSTANT (NAME VALUE) NIL NIL NIL NIL NIL NIL T
:pinfo SYMBOLS_INIT1127 NIL NIL NIL NIL NIL NIL NIL T
:pinfo UPDATE-PROP (PLIST INDICATOR VALUE) NIL NIL NIL NIL NIL NIL T
:pinfo REMPROP (SYMBOL INDICATOR) NIL NIL NIL NIL NIL NIL T
:pinfo CONSTANT-VAR? (S) NIL NIL NIL (LAMBDA (S) (DECLARE) (BLOCK CONSTANT-VAR? (= (SYMBOL-FLAG S CONSTANT-SYMBOL-FLAG) 1))) NIL T T
:pinfo SYMBOL-PRINT-ESCAPE? (S) NIL NIL NIL (LAMBDA (S) (DECLARE) (BLOCK SYMBOL-PRINT-ESCAPE? (%= (SYMBOL-FLAG S PRINT-ESCAPE-FLAG) 1))) NIL T T
:pinfo DEFINE-VARIABLE (NAME VALUE DOC-STRING TYPE) NIL NIL NIL NIL NIL NIL T
:pinfo GENSYM/1 (X) NIL NIL NIL NIL NIL NIL T
:pinfo SYMBOL-HASH-CODE (SYMBOL) NIL (SYMBOL) NIL (LAMBDA (SYMBOL) (DECLARE) (BLOCK SYMBOL-HASH-CODE (%SYMREF SYMBOL SYMBOL-HASHCODE-OFFSET))) NIL T T
:pinfo SET-SYMBOL-HASH-CODE (SYMBOL N) NIL (SYMBOL FIXNUM) NIL (LAMBDA (SYMBOL N) (DECLARE) (BLOCK SET-SYMBOL-HASH-CODE (%SYMDEF SYMBOL SYMBOL-HASHCODE-OFFSET N) N)) NIL T T
:pinfo UNSAFE-SYMBOL-FUNCTION (X) NIL (SYMBOL) NIL (LAMBDA (X) (DECLARE) (BLOCK UNSAFE-SYMBOL-FUNCTION (%SYMREF X SYMBOL-FUNCTION-OFFSET))) NIL T T
:pinfo CLEAR-MACRO-NAME-FLAG (S) NIL NIL NIL NIL NIL NIL T
:pinfo SYMBOL-PLIST (SYMBOL) NIL (SYMBOL) NIL (LAMBDA (SYMBOL) (DECLARE) (BLOCK SYMBOL-PLIST (%SYMREF SYMBOL SYMBOL-PLIST-OFFSET))) NIL T T
:pinfo DEFINE-FUNCTION (NAME KIND IN-TYPES OUT-TYPES BODY SAFE-FUNCTION FUNCTION) NIL NIL NIL NIL NIL NIL T
:pinfo SET (X V) NIL NIL NIL (LAMBDA (X V) (DECLARE) (BLOCK SET (%SYMDEF X SYMBOL-VALUE-OFFSET V) V)) NIL T T
:pinfo MAKUNBOUND (S) NIL (SYMBOL) NIL (LAMBDA (S) (DECLARE) (BLOCK MAKUNBOUND (%MAKUNBOUND S) S)) NIL T T
:pinfo SYMBOL-VALUE (SYMBOL) NIL NIL NIL NIL NIL NIL T
:pinfo PROCLAIM-CONSTANT-VARIABLE (S INIT-FORM) NIL NIL NIL NIL NIL NIL T
:pinfo SYMBOL-PRINT-ESCAPE-FLAG-VALID? (S) NIL NIL NIL (LAMBDA (S) (DECLARE) (BLOCK SYMBOL-PRINT-ESCAPE-FLAG-VALID? (%= (SYMBOL-FLAG S PRINT-ESCAPE-FLAG-VALID?) 1))) NIL T T
:pinfo MAKE-SYMBOL (NAME) NIL NIL NIL (LAMBDA (NAME) (DECLARE) (BLOCK MAKE-SYMBOL (MAKE_SYMBOL NAME (SXHASH/SIMPLE-STRING NAME)))) NIL T T
:pinfo COPY-SYMBOL (SYMBOL) NIL NIL NIL NIL NIL NIL T
:pinfo SYMBOL-PACKAGE (SYMBOL) NIL (SYMBOL) NIL NIL NIL NIL T
:pinfo GET-PROPERTIES (PLACE INDICATOR-LIST) NIL NIL NIL NIL NIL NIL T
:pinfo CONSTANT-EXPR (VARIABLE) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_lsp_BOUNDP();
extern SYMBOL s_lsp_SYMBOLP; 
extern SYMBOL s_lsp_SYMBOL; 
extern SYMBOL s_lsp_WTA; 
extern LP p_lsp_CLEAR_2DMACRO_2DNAME_2DFLAG();
extern SYMBOL s_lsp_CLEAR_2DSYMBOL_2DFLAG; 
extern LP p_lsp_CLEAR_2DSYMBOL_2DFLAG();
extern SYMBOL s_lsp_FIXNUMP; 
extern SYMBOL s_lsp_FIXNUM; 
extern LP p_lsp_COPY_2DSYMBOL();
MAKE_SIMPLE_STRING(k3690,17,"write COPY-SYMBOL");
extern SYMBOL s_lsp_WARN; 
extern LP p_lsp_DEFINE_2DFUNCTION();
extern SYMBOL s_key_DEFMETHOD; 
extern SYMBOL s_lsp_EQ; 
extern SYMBOL s_lsp_SET_2DSYMBOL_2DFUNCTION; 
extern SYMBOL s_lsp_CLEAR_2DMACRO_2DNAME_2DFLAG; 
extern LP p_lsp_DEFINE_2DVARIABLE();
extern SYMBOL s_key_VAR; 
extern SYMBOL s_lsp_EQL; 
extern SYMBOL s_lsp_PROCLAIM_2DSPECIAL_2DVARIABLE; 
extern SYMBOL s_lsp_NIL; 
extern SYMBOL s_lsp_SET; 
extern SYMBOL s_key_PARAMETER; 
extern SYMBOL s_key_CONSTANT; 
extern SYMBOL s_lsp__2ACONSTANT_2DREDEFINITION_2DVERBOSE_2A; 
extern SYMBOL s_lsp_UNSAFE_2DSYMBOL_2DVALUE; 
extern SYMBOL s_lsp_CONSTANT_2DVAR_3F; 
MAKE_SIMPLE_STRING(k3691,22,"Redefining constant ~A");
extern SYMBOL s_lsp_DEFINE_2DCONSTANT; 
extern LP p_lsp_PROCLAIM_2DCONSTANT_2DVARIABLE();
extern SYMBOL s_lsp_SET_2DSYMBOL_2DFLAG; 
extern SYMBOL s_lsp_CONSTANT_2DVALUE; 
extern SYMBOL s_lsp_SET_2DGET; 
extern LP p_lsp_DEFINE_2DCONSTANT();
extern SYMBOL s_lsp_PROCLAIM_2DCONSTANT_2DVARIABLE; 
extern LP p_lsp_CONSTANT_2DEXPR();
extern SYMBOL s_lsp__2AUNBOUND_2A; 
extern SYMBOL s_lsp_GET; 
MAKE_SIMPLE_STRING(k3692,32,"Cannot find value of constant ~A");
extern SYMBOL s_lsp_ERROR; 
extern LP p_lsp_PROCLAIMED_2DSPECIAL_3F();
extern SYMBOL s_lsp_SPECIAL_2DVAR_3F; 
extern SYMBOL s_key_SPECIAL; 
extern LP p_lsp_PROCLAIM_2DSPECIAL_2DVARIABLE();
extern LP p_lsp_CONSTANT_2DVAR_3F();
extern SYMBOL s_lsp_SYMBOL_2DFLAG; 
extern LP p_lsp_DELETE_2DPROPERTY();
MAKE_SIMPLE_STRING(k3693,21,"Write delete-property");
extern LP p_lsp_FBOUNDP();
extern SYMBOL s_lsp_CONSP; 
extern SYMBOL s_lsp_FUNCTION_2DSPECIFIER; 
extern SYMBOL s_lsp_SETF_2DFUNCTION_2DSYMBOL; 
extern LP p_lsp_FDEFINITION();
extern SYMBOL s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION; 
extern LP p_lsp_FMAKUNBOUND();
extern LP p_lsp_GENSYM_2F1();
extern SYMBOL s_lsp__2AGENSYM_2DCOUNTER_2A; 
extern SYMBOL s_lsp_SIMPLE_2DSTRING_2DP; 
extern SYMBOL s_lsp__2AGENSYM_2DPREFIX_2A; 
extern SYMBOL s_lsp_STRING_2BNUMBER_2D_3ESTRING; 
extern SYMBOL s_lsp_MAKE_2DSYMBOL; 
extern LP p_lsp_GENSYM();
extern SYMBOL s_lsp_GENSYM_2F1; 
extern LP p_lsp_GENTEMP();
MAKE_SIMPLE_STRING(k3694,1,"T");
extern SYMBOL s_lsp__2APACKAGE_2A; 
extern SYMBOL s_lsp_GENTEMP_2F2; 
extern LP p_lsp_GENTEMP_2F2();
extern SYMBOL s_lsp__2AGENTEMP_2DCOUNTER_2A; 
extern SYMBOL s_lsp_COERCE_2DTO_2DPACKAGE; 
extern SYMBOL s_lsp_INTERN_2F2; 
extern LP p_lsp_STRING_2BNUMBER_2D_3ESTRING();
extern SYMBOL s_lsp_FILL_2DSTRING_2DWITH_2DINTEGER; 
extern LP p_lsp_FILL_2DSTRING_2DWITH_2DINTEGER();
extern SYMBOL s_lsp_MAKE_2DSIMPLE_2DSTRING; 
extern LP p_lsp_GET_2DPROPERTIES();
extern SYMBOL s_lsp_MEMQ; 
extern LP p_lsp_GET();
extern SYMBOL s_lsp_SYMBOL_2DPLIST; 
extern SYMBOL s_lsp_LOOKUP_2DPROP; 
extern LP p_lsp_GETF();
extern LP p_lsp_KEYWORDP();
extern SYMBOL s_lsp_SYMBOL_2DPACKAGE; 
extern SYMBOL s_lsp__2AKEYWORD_2DPACKAGE_2A; 
extern LP p_lsp_LOOKUP_2DPROP();
extern LP p_lsp_MACRO_2DNAME_3F();
extern LP p_lsp_MAKE_2DSYMBOL();
extern SYMBOL s_lsp_SXHASH_2FSIMPLE_2DSTRING; 
extern LP p_lsp_MAKE_2DSTATIC_2DSYMBOL();
extern LP p_lsp_MAKUNBOUND();
extern LP p_lsp_SYMBOL_2DPRINT_2DESCAPE_2DFLAG_2DVALID_3F();
extern LP p_lsp_SYMBOL_2DPRINT_2DESCAPE_3F();
extern LP p_lsp_SET_2DSYMBOL_2DPRINT_2DESCAPE_2DFLAG_2DVALID_3F();
extern LP p_lsp_SET_2DSYMBOL_2DPRINT_2DESCAPE();
extern LP p_lsp_REMPROP();
extern SYMBOL s_lsp_ATOM; 
MAKE_SIMPLE_STRING(k3695,33,"Odd-length property list in REMF.");
extern SYMBOL s_lsp_T; 
extern SYMBOL s_lsp_SET_2DSYMBOL_2DPLIST; 
extern LP p_lsp_SET_2DGET();
extern SYMBOL s_lsp_UPDATE_2DPROP; 
extern LP p_lsp_SET_2DMACRO_2DNAME_2DFLAG();
extern LP p_lsp_SET_2DSYMBOL_2DFLAG();
extern LP p_lsp_SET_2DSYMBOL_2DFUNCTION();
extern SYMBOL s_lsp_COMPILED_2DFUNCTION_2DP; 
extern SYMBOL s_lsp_COMPILED_2DFUNCTION; 
extern LP p_lsp_SET_2DSYMBOL_2DHASH_2DCODE();
extern LP p_lsp_SET_2DSYMBOL_2DPACKAGE();
extern SYMBOL s_lsp_PACKAGEP; 
extern SYMBOL s_lsp_PACKAGE; 
extern LP p_lsp_SET_2DSYMBOL_2DPLIST();
extern SYMBOL s_lsp_LISTP; 
extern SYMBOL s_lsp_LIST; 
extern LP p_lsp_SET();
extern LP p_lsp_SPECIAL_2DVAR_3F();
extern LP p_lsp_SYMBOL_2DFLAG();
extern LP p_lsp_UNSAFE_2DSYMBOL_2DFUNCTION();
extern LP p_lsp_SYMBOL_2DFUNCTION();
extern SYMBOL s_lsp_SYMBOL_2DFUNCTION_2DERROR; 
extern LP p_lsp_UNSAFE_2DSYMBOL_2DVALUE();
extern LP p_lsp_SYMBOL_2DVALUE();
MAKE_SIMPLE_STRING(k3696,28,"The variable ~A is not bound");
extern LP p_lsp_SYMBOL_2DHASH_2DCODE();
extern LP p_lsp_SYMBOL_2DNAME();
extern LP p_lsp_SYMBOL_2DPACKAGE();
extern SYMBOL s_lsp__2ALISP_2DPACKAGE_2A; 
extern LP p_lsp_SYMBOL_2DPLIST();
extern LP p_lsp_UPDATE_2DPROP();
extern LP p_lsp_SYMBOLS_5FINIT1127();
extern SYMBOL s_lsp_FDEFINITION; 
extern LP p_lsp_SYMBOLS_5FINIT1127_2Danon36973698();
MAKE_PROCEDURE(k3701,p_lsp_SYMBOLS_5FINIT1127_2Danon36973698);
extern SYMBOL s_lsp_DEFINE_2DSETF; 
MAKE_SIMPLE_STRING(k3702,1,"S");
extern LP p_lsp_SYMBOLS_5FINIT1127_2Danon36973698SYMBOLS_5FINIT1127_2Danon36993700();
MAKE_PROCEDURE(k3703,p_lsp_SYMBOLS_5FINIT1127_2Danon36973698SYMBOLS_5FINIT1127_2Danon36993700);
extern SYMBOL s_lsp_SET_2DFDEFINITION; 


extern LP c_cons();
extern void switch_to_dynamic_space();
extern void switch_to_static_space();
extern LP make_symbol();
extern LP add();
extern LP num_equal_p();


LP p_lsp_BOUNDP(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_SYMBOLP) (1, v_S_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_S_0, LREF(s_lsp_SYMBOL), (LP) 0);
}
t1 = ((LDREF((v_S_0),SYMBOL,value) != UBV_MARKER) ? T : NIL);
return(t1);
}

LP p_lsp_CLEAR_2DMACRO_2DNAME_2DFLAG(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; 
if (argc != 1) wna(argc,1);
ICALL(s_lsp_CLEAR_2DSYMBOL_2DFLAG) (2, v_S_0, (LP) 4);
return(v_S_0);
}

LP p_lsp_CLEAR_2DSYMBOL_2DFLAG(argc, v_S_0, v_FLAG_1)
      ARGC argc;  LP v_S_0; LP v_FLAG_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 

if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_SYMBOLP) (1, v_S_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_S_0, LREF(s_lsp_SYMBOL), (LP) 0);
}
t1 = ICALL(s_lsp_FIXNUMP) (1, v_FLAG_1);
if (t1 == NIL) {
ICALL(s_lsp_WTA) (3, v_FLAG_1, LREF(s_lsp_FIXNUM), (LP) 0);
}
t3 = ((LP) DEREF((v_S_0) + 2 * 4));
t2 = (((t3) + 6 * 4));
((LP) (DEREF((t2)) = ((~(1 << FX_TO_INT(v_FLAG_1))) & DEREF((t2)))));
return(v_S_0);
}

LP p_lsp_COPY_2DSYMBOL(argc, v_SYMBOL_0)
      ARGC argc;  LP v_SYMBOL_0;
{

LP t0; LP t1; 
if (argc != 1) wna(argc,1);
ICALL(s_lsp_WARN) (1, LREF(k3690));
return(v_SYMBOL_0);
}

LP p_lsp_DEFINE_2DFUNCTION(argc, v_NAME_0, v_KIND_1, v_IN_2DTYPES_2, v_OUT_2DTYPES_3, v_BODY_4, v_SAFE_2DFUNCTION_5, v_FUNCTION_6)
      ARGC argc;  LP v_NAME_0; LP v_KIND_1; LP v_IN_2DTYPES_2; LP v_OUT_2DTYPES_3; LP v_BODY_4; LP v_SAFE_2DFUNCTION_5; LP v_FUNCTION_6;
{
LP v_T5252_9; LP v_S5251_8; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 7) wna(argc,7);
t0 = ICALL(s_lsp_EQ) (2, v_KIND_1, LREF(s_key_DEFMETHOD));
if (t0 != NIL) {
v_S5251_8 = v_SAFE_2DFUNCTION_5;
} else {
v_S5251_8 = v_FUNCTION_6;
}
v_T5252_9 = v_NAME_0;
ICALL(s_lsp_SET_2DSYMBOL_2DFUNCTION) (2, v_NAME_0, v_S5251_8);
ICALL(s_lsp_CLEAR_2DMACRO_2DNAME_2DFLAG) (1, v_NAME_0);
return(v_NAME_0);
}

LP p_lsp_DEFINE_2DVARIABLE(argc, v_NAME_0, v_VALUE_1, v_DOC_2DSTRING_2, v_TYPE_3)
      ARGC argc;  LP v_NAME_0; LP v_VALUE_1; LP v_DOC_2DSTRING_2; LP v_TYPE_3;
{
LP v_T5257_12; LP v_S5256_11; LP v_T5255_10; 
LP v_S5254_9; LP v_KEY5253_8; LP v_BOUND_3F_7; 
LP v_S_5; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; 
if (argc != 4) wna(argc,4);
v_S_5 = v_NAME_0;
v_BOUND_3F_7 = ((LDREF((v_NAME_0),SYMBOL,value) != UBV_MARKER) ? T : NIL);
v_KEY5253_8 = v_TYPE_3;
t0 = ICALL(s_lsp_EQL) (2, v_KEY5253_8, LREF(s_key_VAR));
if (t0 != NIL) {
ICALL(s_lsp_PROCLAIM_2DSPECIAL_2DVARIABLE) (1, v_NAME_0);
if (v_BOUND_3F_7 != NIL) {
} else {
v_S5254_9 = v_VALUE_1;
v_T5255_10 = v_NAME_0;
ICALL(s_lsp_SET) (2, v_NAME_0, v_VALUE_1);
}
} else {
t1 = ICALL(s_lsp_EQL) (2, v_KEY5253_8, LREF(s_key_PARAMETER));
if (t1 != NIL) {
ICALL(s_lsp_PROCLAIM_2DSPECIAL_2DVARIABLE) (1, v_NAME_0);
v_S5256_11 = v_VALUE_1;
v_T5257_12 = v_NAME_0;
ICALL(s_lsp_SET) (2, v_NAME_0, v_VALUE_1);
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY5253_8, LREF(s_key_CONSTANT));
if (t2 != NIL) {
t4 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ACONSTANT_2DREDEFINITION_2DVERBOSE_2A));
if (t4 != NIL) {
if (v_BOUND_3F_7 != NIL) {
t3 = ICALL(s_lsp_CONSTANT_2DVAR_3F) (1, v_NAME_0);
} else {
t3 = LREF(s_lsp_NIL);
}
} else {
t3 = LREF(s_lsp_NIL);
}
if (t3 != NIL) {
ICALL(s_lsp_WARN) (2, LREF(k3691), v_NAME_0);
}
ICALL(s_lsp_DEFINE_2DCONSTANT) (2, v_NAME_0, v_VALUE_1);
} else {
}
}
}
return(v_NAME_0);
}

LP p_lsp_PROCLAIM_2DCONSTANT_2DVARIABLE(argc, v_S_0, v_INIT_2DFORM_1)
      ARGC argc;  LP v_S_0; LP v_INIT_2DFORM_1;
{
LP v_T5260_5; LP v_T5259_4; LP v_S5258_3; 

LP t0; LP t1; LP t2; LP t3; 
if (argc != 2) wna(argc,2);
ICALL(s_lsp_SET_2DSYMBOL_2DFLAG) (2, v_S_0, (LP) 2);
ICALL(s_lsp_CLEAR_2DSYMBOL_2DFLAG) (2, v_S_0, (LP) 0);
v_S5258_3 = v_INIT_2DFORM_1;
v_T5259_4 = v_S_0;
v_T5260_5 = LREF(s_lsp_CONSTANT_2DVALUE);
ICALL(s_lsp_SET_2DGET) (3, v_S_0, LREF(s_lsp_CONSTANT_2DVALUE), v_S5258_3);
return(v_S_0);
}

LP p_lsp_DEFINE_2DCONSTANT(argc, v_NAME_0, v_VALUE_1)
      ARGC argc;  LP v_NAME_0; LP v_VALUE_1;
{
LP v_T5262_4; LP v_S5261_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
ICALL(s_lsp_PROCLAIM_2DCONSTANT_2DVARIABLE) (2, v_NAME_0, v_VALUE_1);
v_S5261_3 = v_VALUE_1;
v_T5262_4 = v_NAME_0;
t0 = ICALL(s_lsp_SET) (MV_CALL(argc,2), v_NAME_0, v_VALUE_1);
return(t0);
}

LP p_lsp_CONSTANT_2DEXPR(argc, v_VARIABLE_0)
      ARGC argc;  LP v_VARIABLE_0;
{
LP v_S_3; LP v_V_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AUNBOUND_2A));
v_V_2 = ICALL(s_lsp_GET) (3, v_VARIABLE_0, LREF(s_lsp_CONSTANT_2DVALUE), t0);
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AUNBOUND_2A));
t2 = ICALL(s_lsp_EQ) (2, v_V_2, t3);
if (t2 != NIL) {
v_S_3 = v_VARIABLE_0;
if ((LDREF((v_VARIABLE_0),SYMBOL,value) != UBV_MARKER)) {
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (MV_CALL(argc,1), v_VARIABLE_0);
return(t1);
} else {
t1 = ICALL(s_lsp_ERROR) (MV_CALL(argc,2), LREF(k3692), v_VARIABLE_0);
return(t1);
}
} else {
return(v_V_2);
}
}

LP p_lsp_PROCLAIMED_2DSPECIAL_3F(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; 
if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_CONSTANT_2DVAR_3F) (1, v_S_0);
if (t1 != NIL) {
return(LREF(s_key_CONSTANT));
} else {
t2 = ICALL(s_lsp_SPECIAL_2DVAR_3F) (1, v_S_0);
if (t2 != NIL) {
return(LREF(s_key_SPECIAL));
} else {
return(LREF(s_lsp_NIL));
}
}
}

LP p_lsp_PROCLAIM_2DSPECIAL_2DVARIABLE(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; 
if (argc != 1) wna(argc,1);
ICALL(s_lsp_SET_2DSYMBOL_2DFLAG) (2, v_S_0, (LP) 0);
ICALL(s_lsp_CLEAR_2DSYMBOL_2DFLAG) (2, v_S_0, (LP) 2);
return(v_S_0);
}

LP p_lsp_CONSTANT_2DVAR_3F(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_SYMBOL_2DFLAG) (2, v_S_0, (LP) 2);
t0 = (num_equal_p((t1), ((LP) 2)));
return(t0);
}

LP p_lsp_DELETE_2DPROPERTY(argc, v_LIST_0, v_INDICATOR_1)
      ARGC argc;  LP v_LIST_0; LP v_INDICATOR_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,1), LREF(k3693));
return(t0);
}

LP p_lsp_FBOUNDP(argc, v_F_0)
      ARGC argc;  LP v_F_0;
{
LP v_X_10; LP v_X_8; LP v_C_6; 
LP v_LIST_4; LP v_G5264_3; LP v_TMP5263_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; 
if (argc != 1) wna(argc,1);
v_TMP5263_2 = v_F_0;
v_G5264_3 = ICALL(s_lsp_SYMBOLP) (1, v_TMP5263_2);
if (v_G5264_3 != NIL) {
t0 = v_G5264_3;
} else {
t0 = ICALL(s_lsp_CONSP) (1, v_TMP5263_2);
}
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_F_0, LREF(s_lsp_FUNCTION_2DSPECIFIER), (LP) 0);
}
t2 = ICALL(s_lsp_CONSP) (1, v_F_0);
if (t2 != NIL) {
v_LIST_4 = v_F_0;
v_C_6 = v_F_0;
v_X_8 = v_F_0;
v_X_10 = ((LP) DEREF((v_F_0) + 1 * 4));
t4 = ((LP) DEREF((v_X_10) + 0 * 4));
t3 = ICALL(s_lsp_SETF_2DFUNCTION_2DSYMBOL) (1, t4);
t1 = ((LDREF((t3),SYMBOL,function) != (LP) LREF(ubf_procedure)) ? T : NIL);
return(t1);
} else {
t1 = ((LDREF((v_F_0),SYMBOL,function) != (LP) LREF(ubf_procedure)) ? T : NIL);
return(t1);
}
}

LP p_lsp_FDEFINITION(argc, v_F_0)
      ARGC argc;  LP v_F_0;
{
LP v_G5266_3; LP v_TMP5265_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 1) wna(argc,1);
v_TMP5265_2 = v_F_0;
v_G5266_3 = ICALL(s_lsp_SYMBOLP) (1, v_TMP5265_2);
if (v_G5266_3 != NIL) {
t0 = v_G5266_3;
} else {
t0 = ICALL(s_lsp_CONSP) (1, v_TMP5265_2);
}
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_F_0, LREF(s_lsp_FUNCTION_2DSPECIFIER), (LP) 0);
}
t2 = ICALL(s_lsp_CONSP) (1, v_F_0);
if (t2 != NIL) {
t3 = ICALL(s_lsp_SETF_2DFUNCTION_2DSYMBOL) (1, v_F_0);
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (MV_CALL(argc,1), t3);
return(t1);
} else {
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (MV_CALL(argc,1), v_F_0);
return(t1);
}
}

LP p_lsp_FMAKUNBOUND(argc, v_F_0)
      ARGC argc;  LP v_F_0;
{
LP v_G5268_3; LP v_TMP5267_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 1) wna(argc,1);
v_TMP5267_2 = v_F_0;
v_G5268_3 = ICALL(s_lsp_SYMBOLP) (1, v_TMP5267_2);
if (v_G5268_3 != NIL) {
t0 = v_G5268_3;
} else {
t0 = ICALL(s_lsp_CONSP) (1, v_TMP5267_2);
}
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_F_0, LREF(s_lsp_FUNCTION_2DSPECIFIER), (LP) 0);
}
t1 = ICALL(s_lsp_CONSP) (1, v_F_0);
if (t1 != NIL) {
t2 = ICALL(s_lsp_SETF_2DFUNCTION_2DSYMBOL) (1, v_F_0);
((LDREF((t2),SYMBOL,function) = (LP) LREF(ubf_procedure)));
} else {
((LDREF((v_F_0),SYMBOL,function) = (LP) LREF(ubf_procedure)));
}
return(v_F_0);
}

LP p_lsp_GENSYM_2F1(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{
LP v_NAME_5; LP v_N_4; LP v_KEY5270_3; 
LP v_S5269_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AGENSYM_2DCOUNTER_2A));
v_S5269_2 = (add((t0), ((LP) 2)));
ICALL(s_lsp_SET) (2, LREF(s_lsp__2AGENSYM_2DCOUNTER_2A), v_S5269_2);
if (v_X_0 != NIL) {
v_KEY5270_3 = v_X_0;
t1 = ICALL(s_lsp_SIMPLE_2DSTRING_2DP) (1, v_KEY5270_3);
if (t1 != NIL) {
ICALL(s_lsp_SET) (2, LREF(s_lsp__2AGENSYM_2DPREFIX_2A), v_X_0);
v_N_4 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AGENSYM_2DCOUNTER_2A));
} else {
t2 = ICALL(s_lsp_FIXNUMP) (1, v_KEY5270_3);
if (t2 != NIL) {
v_N_4 = v_X_0;
} else {
v_N_4 = LREF(s_lsp_NIL);
}
}
} else {
v_N_4 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AGENSYM_2DCOUNTER_2A));
}
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AGENSYM_2DPREFIX_2A));
v_NAME_5 = ICALL(s_lsp_STRING_2BNUMBER_2D_3ESTRING) (2, t3, v_N_4);
t4 = ICALL(s_lsp_MAKE_2DSYMBOL) (MV_CALL(argc,1), v_NAME_5);
return(t4);
}

LP p_lsp_GENSYM(va_alist) va_dcl
{
LP v_X_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
if (real_argc > 1) wna_high(real_argc,1);
if (real_argc < 1) {
v_X_0 = NIL;
} else {
v_X_0 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t0 = ICALL(s_lsp_GENSYM_2F1) (MV_CALL(argc,1), v_X_0);
return(t0);
}

LP p_lsp_GENTEMP(va_alist) va_dcl
{
LP v_PACKAGE_1; LP v_PREFIX_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 1) {
v_PREFIX_0 = LREF(k3694);
} else {
v_PREFIX_0 = NEXT_VAR_ARG;
}
if (real_argc < 2) {
t0 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2APACKAGE_2A));
v_PACKAGE_1 = t0;
} else {
v_PACKAGE_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t1 = ICALL(s_lsp_GENTEMP_2F2) (MV_CALL(argc,2), v_PREFIX_0, v_PACKAGE_1);
return(t1);
}

LP p_lsp_GENTEMP_2F2(argc, v_PREFIX_0, v_PACKAGE_1)
      ARGC argc;  LP v_PREFIX_0; LP v_PACKAGE_1;
{
LP v_P_8; LP v_NAME_7; LP v_NAME_5; 
LP v_P_6; LP v_NAME_4; LP v_S5271_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 

if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AGENTEMP_2DCOUNTER_2A));
v_S5271_3 = (add((t0), ((LP) 2)));
ICALL(s_lsp_SET) (2, LREF(s_lsp__2AGENTEMP_2DCOUNTER_2A), v_S5271_3);
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AGENTEMP_2DCOUNTER_2A));
v_NAME_4 = ICALL(s_lsp_STRING_2BNUMBER_2D_3ESTRING) (2, v_PREFIX_0, t1);
v_NAME_7 = v_NAME_4;
v_P_8 = v_PACKAGE_1;
t3 = ICALL(s_lsp_COERCE_2DTO_2DPACKAGE) (1, v_PACKAGE_1);
t2 = ICALL(s_lsp_INTERN_2F2) (MV_CALL(argc,2), v_NAME_4, t3);
return(t2);
}

LP p_lsp_STRING_2BNUMBER_2D_3ESTRING(argc, v_STRING_0, v_N_1)
      ARGC argc;  LP v_STRING_0; LP v_N_1;
{
LP v_V5275_13; LP v_T5274_12; LP v_T5273_11; 
LP v_S5272_10; LP v_LOOP_2DBIND_2D1126_6; LP v_I_5; 
LP v_NEW_4; LP v_STRLEN_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
if (argc != 2) wna(argc,2);
v_STRLEN_3 = INT_TO_FX((LP) (DEREF((v_STRING_0) - 4) >> 8));
v_NEW_4 = ICALL(s_lsp_FILL_2DSTRING_2DWITH_2DINTEGER) (3, v_STRLEN_3, (LP) 2, v_N_1);
v_I_5 = (LP) 0;
t_NEXT_2DLOOP_8:;
if (((int) (v_I_5) >= (int) (v_STRLEN_3))) {
goto t_END_2DLOOP_9;
}
v_S5272_10 = NEW_CHAR((LP) *((v_STRING_0) - 1 + FX_TO_INT(v_I_5)));
v_T5273_11 = v_NEW_4;
v_T5274_12 = v_I_5;
v_V5275_13 = v_S5272_10;
((LP) (*((v_NEW_4) - 1 + FX_TO_INT(v_T5274_12)) = (char) RAW_CHAR(v_V5275_13)));
v_I_5 = (((LP) ((int) (v_I_5) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_8;
goto t_END_2DLOOP_9;
t_END_2DLOOP_9:;
return(v_NEW_4);
}

LP p_lsp_FILL_2DSTRING_2DWITH_2DINTEGER(argc, v_EXTRA_0, v_NEXT_1, v_INTEGER_2)
      ARGC argc;  LP v_EXTRA_0; LP v_NEXT_1; LP v_INTEGER_2;
{
LP v_V5279_21; LP v_T5278_20; LP v_T5277_19; 
LP v_S5276_18; LP v_N_16; LP v_C_14; 
LP v_C_12; LP v_STRING_11; LP v_INITIAL_2DELEMENT_9; 
LP v_N_8; LP v_N_6; LP v_INITIAL_2DELEMENT_7; 
LP v_REMAINDER_5; LP v_QUOTIENT_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; 
if (argc != 3) wna(argc,3);
v_QUOTIENT_4 = ((LP) INT_TO_FX((int) (v_INTEGER_2) / (int) ((LP) 20)));
v_REMAINDER_5 = ((LP) ((int) (v_INTEGER_2) % (int) ((LP) 20)));
if (((int) (v_QUOTIENT_4) == (int) ((LP) 0))) {
v_N_8 = (((LP) ((int) (v_EXTRA_0) + (int) (v_NEXT_1))));
v_STRING_11 = ICALL(s_lsp_MAKE_2DSIMPLE_2DSTRING) (2, v_N_8, LREF(char_tab[0]));
} else {
t1 = (((LP) ((int) (v_NEXT_1) + (int) ((LP) 2))));
v_STRING_11 = ICALL(s_lsp_FILL_2DSTRING_2DWITH_2DINTEGER) (3, v_EXTRA_0, t1, v_QUOTIENT_4);
}
if (((int) (v_REMAINDER_5) > (int) ((LP) 18))) {
v_C_12 = LREF(char_tab[65]);
t3 = INT_TO_FX(((int) RAW_CHAR(LREF(char_tab[65]))));
t4 = (((LP) ((int) (v_REMAINDER_5) - (int) ((LP) 20))));
v_N_16 = (((LP) ((int) (t3) + (int) (t4))));
} else {
v_C_14 = LREF(char_tab[48]);
t5 = INT_TO_FX(((int) RAW_CHAR(LREF(char_tab[48]))));
v_N_16 = (((LP) ((int) (t5) + (int) (v_REMAINDER_5))));
}
if (((int) (v_N_16) >= (int) ((LP) 512))) {
v_S5276_18 = LREF(s_lsp_NIL);
} else {
v_S5276_18 = NEW_CHAR(((unsigned char) FX_TO_INT(v_N_16)));
}
v_T5277_19 = v_STRING_11;
t7 = INT_TO_FX((LP) (DEREF((v_STRING_11) - 4) >> 8));
v_T5278_20 = (((LP) ((int) (t7) - (int) (v_NEXT_1))));
v_V5279_21 = v_S5276_18;
((LP) (*((v_STRING_11) - 1 + FX_TO_INT(v_T5278_20)) = (char) RAW_CHAR(v_V5279_21)));
return(v_STRING_11);
}

LP p_lsp_GET_2DPROPERTIES(argc, v_PLACE_0, v_INDICATOR_2DLIST_1)
      ARGC argc;  LP v_PLACE_0; LP v_INDICATOR_2DLIST_1;
{
LP v_X_25; LP v_X_23; LP v_C_21; 
LP v_X_19; LP v_X_17; LP v_X_15; 
LP v_C_13; LP v_LIST_11; LP v_X_9; 
LP v_LIST_7; LP v_PLIST_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 

if (argc != 2) wna(argc,2);
v_PLIST_3 = v_PLACE_0;
t_NEXT_2DLOOP_5:;
if (v_PLIST_3 == NIL) {
goto t_END_2DLOOP_6;
}
v_X_19 = v_PLIST_3;
t2 = ((LP) DEREF((v_X_19) + 0 * 4));
t1 = ICALL(s_lsp_MEMQ) (2, t2, v_INDICATOR_2DLIST_1);
if (t1 != NIL) {
v_LIST_7 = v_PLIST_3;
v_X_9 = v_LIST_7;
t3 = ((LP) DEREF((v_LIST_7) + 0 * 4));
v_LIST_11 = v_PLIST_3;
v_C_13 = v_LIST_11;
v_X_15 = v_LIST_11;
v_X_17 = ((LP) DEREF((v_LIST_11) + 1 * 4));
t4 = ((LP) DEREF((v_X_17) + 0 * 4));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,3);
SET_MV_RETURN_VALUE(argc,1,t4);
SET_MV_RETURN_VALUE(argc,2,v_PLIST_3);
}
return(t3);
return(NIL);
}
v_C_21 = v_PLIST_3;
v_X_23 = v_C_21;
v_X_25 = ((LP) DEREF((v_C_21) + 1 * 4));
v_PLIST_3 = ((LP) DEREF((v_X_25) + 1 * 4));
goto t_NEXT_2DLOOP_5;
goto t_END_2DLOOP_6;
t_END_2DLOOP_6:;
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,3);
SET_MV_RETURN_VALUE(argc,1,LREF(s_lsp_NIL));
SET_MV_RETURN_VALUE(argc,2,LREF(s_lsp_NIL));
}
return(LREF(s_lsp_NIL));
return(NIL);
return(NIL);
}

LP p_lsp_GET(va_alist) va_dcl
{
LP v_INDICATOR_1; LP v_SYMBOL_0; LP v_DEFAULT_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_SYMBOL_0 = NEXT_VAR_ARG;
v_INDICATOR_1 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 2) wna_low(real_argc,2);
if (real_argc > 3) wna_high(real_argc,3);
if (real_argc < 3) {
v_DEFAULT_2 = NIL;
} else {
v_DEFAULT_2 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t1 = ICALL(s_lsp_SYMBOL_2DPLIST) (1, v_SYMBOL_0);
t0 = ICALL(s_lsp_LOOKUP_2DPROP) (MV_CALL(argc,3), t1, v_INDICATOR_1, v_DEFAULT_2);
return(t0);
}

LP p_lsp_GETF(va_alist) va_dcl
{
LP v_INDICATOR_1; LP v_PLACE_0; LP v_DEFAULT_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_PLACE_0 = NEXT_VAR_ARG;
v_INDICATOR_1 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 2) wna_low(real_argc,2);
if (real_argc > 3) wna_high(real_argc,3);
if (real_argc < 3) {
v_DEFAULT_2 = LREF(s_lsp_NIL);
} else {
v_DEFAULT_2 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t0 = ICALL(s_lsp_LOOKUP_2DPROP) (MV_CALL(argc,3), v_PLACE_0, v_INDICATOR_1, v_DEFAULT_2);
return(t0);
}

LP p_lsp_KEYWORDP(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_SYMBOLP) (1, v_S_0);
if (t1 != NIL) {
t2 = ICALL(s_lsp_SYMBOL_2DPACKAGE) (1, v_S_0);
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AKEYWORD_2DPACKAGE_2A));
t0 = ICALL(s_lsp_EQ) (MV_CALL(argc,2), t2, t3);
return(t0);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_LOOKUP_2DPROP(argc, v_PLIST_0, v_INDICATOR_1, v_DEFAULT_2)
      ARGC argc;  LP v_PLIST_0; LP v_INDICATOR_1; LP v_DEFAULT_2;
{
LP v_X_24; LP v_X_22; LP v_C_20; 
LP v_X_18; LP v_LIST_16; LP v_X_14; 
LP v_X_12; LP v_C_10; LP v_LIST_8; 
LP v_L_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; 
if (argc != 3) wna(argc,3);
v_L_4 = v_PLIST_0;
t_NEXT_2DLOOP_6:;
if (v_L_4 == NIL) {
goto t_END_2DLOOP_7;
}
v_LIST_16 = v_L_4;
v_X_18 = v_LIST_16;
t2 = ((LP) DEREF((v_LIST_16) + 0 * 4));
t1 = ICALL(s_lsp_EQ) (2, v_INDICATOR_1, t2);
if (t1 != NIL) {
v_LIST_8 = v_L_4;
v_C_10 = v_LIST_8;
v_X_12 = v_LIST_8;
v_X_14 = ((LP) DEREF((v_LIST_8) + 1 * 4));
t3 = ((LP) DEREF((v_X_14) + 0 * 4));
return(t3);
return(NIL);
}
v_C_20 = v_L_4;
v_X_22 = v_C_20;
v_X_24 = ((LP) DEREF((v_C_20) + 1 * 4));
v_L_4 = ((LP) DEREF((v_X_24) + 1 * 4));
goto t_NEXT_2DLOOP_6;
goto t_END_2DLOOP_7;
t_END_2DLOOP_7:;
return(v_DEFAULT_2);
return(NIL);
return(NIL);
}

LP p_lsp_MACRO_2DNAME_3F(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_SYMBOL_2DFLAG) (2, v_S_0, (LP) 4);
t0 = (num_equal_p((t1), ((LP) 2)));
return(t0);
}

LP p_lsp_MAKE_2DSYMBOL(argc, v_NAME_0)
      ARGC argc;  LP v_NAME_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_SXHASH_2FSIMPLE_2DSTRING) (1, v_NAME_0);
t0 = (make_symbol((v_NAME_0), (t1)));
return(t0);
}

LP p_lsp_MAKE_2DSTATIC_2DSYMBOL(argc, v_NAME_0, v_HASH_2DCODE_1)
      ARGC argc;  LP v_NAME_0; LP v_HASH_2DCODE_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
BEGIN_UW_PROTECT_BODY
(switch_to_static_space());
t0 = (make_symbol((v_NAME_0), (v_HASH_2DCODE_1)));
BEGIN_UW_PROTECT_CLEANUP
(switch_to_dynamic_space());
CONTINUE_FROM_PROTECT
return(t0);
}

LP p_lsp_MAKUNBOUND(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_SYMBOLP) (1, v_S_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_S_0, LREF(s_lsp_SYMBOL), (LP) 0);
}
(LDREF((v_S_0),SYMBOL,value) = UBV_MARKER);
return(v_S_0);
}

LP p_lsp_SYMBOL_2DPRINT_2DESCAPE_2DFLAG_2DVALID_3F(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_SYMBOL_2DFLAG) (2, v_S_0, (LP) 8);
t0 = (((int) (t1) == (int) ((LP) 2)) ? T : NIL);
return(t0);
}

LP p_lsp_SYMBOL_2DPRINT_2DESCAPE_3F(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_SYMBOL_2DFLAG) (2, v_S_0, (LP) 6);
t0 = (((int) (t1) == (int) ((LP) 2)) ? T : NIL);
return(t0);
}

LP p_lsp_SET_2DSYMBOL_2DPRINT_2DESCAPE_2DFLAG_2DVALID_3F(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; 
if (argc != 1) wna(argc,1);
ICALL(s_lsp_SET_2DSYMBOL_2DFLAG) (2, v_S_0, (LP) 8);
return(v_S_0);
}

LP p_lsp_SET_2DSYMBOL_2DPRINT_2DESCAPE(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; 
if (argc != 1) wna(argc,1);
ICALL(s_lsp_SET_2DSYMBOL_2DFLAG) (2, v_S_0, (LP) 6);
return(v_S_0);
}

LP p_lsp_REMPROP(argc, v_SYMBOL_0, v_INDICATOR_1)
      ARGC argc;  LP v_SYMBOL_0; LP v_INDICATOR_1;
{
LP v_X_41; LP v_X_39; LP v_X_37; 
LP v_X_35; LP v_C_33; LP v_V_31; 
LP v_X_30; LP v_NEW_2DCDR_28; LP v_C_27; 
LP v_X_25; LP v_X_23; LP v_C_21; 
LP v_X_19; LP v_TMP5288_18; LP v_TMP5287_17; 
LP v_X_15; LP v_X_13; LP v_C_11; 
LP v_T5284_8; LP v_T5283_7; LP v_T5282_5; 
LP v_S5280_4; LP v_T5281_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; 
if (argc != 2) wna(argc,2);
v_T5281_3 = v_SYMBOL_0;
v_S5280_4 = ICALL(s_lsp_SYMBOL_2DPLIST) (1, v_T5281_3);
v_T5282_5 = v_INDICATOR_1;
v_T5283_7 = v_S5280_4;
v_T5284_8 = LREF(s_lsp_NIL);
goto t_TEST5285_10;
t_LOOP5286_9:;
v_C_11 = v_T5283_7;
v_X_13 = v_C_11;
v_X_15 = ((LP) DEREF((v_C_11) + 1 * 4));
v_TMP5287_17 = ((LP) DEREF((v_X_15) + 1 * 4));
v_TMP5288_18 = v_T5283_7;
v_T5283_7 = v_TMP5287_17;
v_T5284_8 = v_TMP5288_18;
t_TEST5285_10:;
t1 = ICALL(s_lsp_ATOM) (1, v_T5283_7);
if (t1 != NIL) {
return(LREF(s_lsp_NIL));
return(NIL);
}
v_X_41 = v_T5283_7;
t3 = ((LP) DEREF((v_X_41) + 1 * 4));
t2 = ICALL(s_lsp_ATOM) (1, t3);
if (t2 != NIL) {
ICALL(s_lsp_ERROR) (1, LREF(k3695));
} else {
v_X_39 = v_T5283_7;
t5 = ((LP) DEREF((v_X_39) + 0 * 4));
t4 = ICALL(s_lsp_EQ) (2, t5, v_INDICATOR_1);
if (t4 != NIL) {
if (v_T5284_8 != NIL) {
v_X_19 = v_T5284_8;
v_C_27 = ((LP) DEREF((v_X_19) + 1 * 4));
v_C_21 = v_T5283_7;
v_X_23 = v_C_21;
v_X_25 = ((LP) DEREF((v_C_21) + 1 * 4));
v_NEW_2DCDR_28 = ((LP) DEREF((v_X_25) + 1 * 4));
v_V_31 = v_NEW_2DCDR_28;
((LP) (DEREF((v_C_27) + 1 * 4) = (LD) (v_V_31)));
return(LREF(s_lsp_T));
return(NIL);
} else {
v_C_33 = v_S5280_4;
v_X_35 = v_C_33;
v_X_37 = ((LP) DEREF((v_C_33) + 1 * 4));
v_S5280_4 = ((LP) DEREF((v_X_37) + 1 * 4));
ICALL(s_lsp_SET_2DSYMBOL_2DPLIST) (2, v_T5281_3, v_S5280_4);
return(LREF(s_lsp_T));
return(NIL);
}
}
}
goto t_LOOP5286_9;
return(NIL);
}

LP p_lsp_SET_2DGET(argc, v_SYMBOL_0, v_INDICATOR_1, v_VALUE_2)
      ARGC argc;  LP v_SYMBOL_0; LP v_INDICATOR_1; LP v_VALUE_2;
{
LP v_T5290_5; LP v_S5289_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 3) wna(argc,3);
t0 = ICALL(s_lsp_SYMBOL_2DPLIST) (1, v_SYMBOL_0);
v_S5289_4 = ICALL(s_lsp_UPDATE_2DPROP) (3, t0, v_INDICATOR_1, v_VALUE_2);
v_T5290_5 = v_SYMBOL_0;
t1 = ICALL(s_lsp_SET_2DSYMBOL_2DPLIST) (MV_CALL(argc,2), v_SYMBOL_0, v_S5289_4);
return(t1);
}

LP p_lsp_SET_2DMACRO_2DNAME_2DFLAG(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; 
if (argc != 1) wna(argc,1);
ICALL(s_lsp_SET_2DSYMBOL_2DFLAG) (2, v_S_0, (LP) 4);
return(v_S_0);
}

LP p_lsp_SET_2DSYMBOL_2DFLAG(argc, v_S_0, v_FLAG_1)
      ARGC argc;  LP v_S_0; LP v_FLAG_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 

if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_SYMBOLP) (1, v_S_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_S_0, LREF(s_lsp_SYMBOL), (LP) 0);
}
t1 = ICALL(s_lsp_FIXNUMP) (1, v_FLAG_1);
if (t1 == NIL) {
ICALL(s_lsp_WTA) (3, v_FLAG_1, LREF(s_lsp_FIXNUM), (LP) 0);
}
t3 = ((LP) DEREF((v_S_0) + 2 * 4));
t2 = (((t3) + 6 * 4));
((LP) (DEREF((t2)) = ((1 << FX_TO_INT(v_FLAG_1)) | DEREF((t2)))));
return(v_S_0);
}

LP p_lsp_SET_2DSYMBOL_2DFUNCTION(argc, v_X_0, v_F_1)
      ARGC argc;  LP v_X_0; LP v_F_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_SYMBOLP) (1, v_X_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_X_0, LREF(s_lsp_SYMBOL), (LP) 0);
}
t1 = ICALL(s_lsp_COMPILED_2DFUNCTION_2DP) (1, v_F_1);
if (t1 == NIL) {
ICALL(s_lsp_WTA) (3, v_F_1, LREF(s_lsp_COMPILED_2DFUNCTION), (LP) 0);
}
((LP) (DEREF((v_X_0) + 4 * 4) = (LD) (v_F_1)));
return(v_F_1);
}

LP p_lsp_SET_2DSYMBOL_2DHASH_2DCODE(argc, v_SYMBOL_0, v_N_1)
      ARGC argc;  LP v_SYMBOL_0; LP v_N_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_SYMBOLP) (1, v_SYMBOL_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_SYMBOL_0, LREF(s_lsp_SYMBOL), (LP) 0);
}
t1 = ICALL(s_lsp_FIXNUMP) (1, v_N_1);
if (t1 == NIL) {
ICALL(s_lsp_WTA) (3, v_N_1, LREF(s_lsp_FIXNUM), (LP) 0);
}
((LP) (DEREF((v_SYMBOL_0) + 5 * 4) = (LD) (v_N_1)));
return(v_N_1);
}

LP p_lsp_SET_2DSYMBOL_2DPACKAGE(argc, v_SYMBOL_0, v_VALUE_1)
      ARGC argc;  LP v_SYMBOL_0; LP v_VALUE_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_SYMBOLP) (1, v_SYMBOL_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_SYMBOL_0, LREF(s_lsp_SYMBOL), (LP) 0);
}
t1 = ICALL(s_lsp_PACKAGEP) (1, v_VALUE_1);
if (t1 == NIL) {
ICALL(s_lsp_WTA) (3, v_VALUE_1, LREF(s_lsp_PACKAGE), (LP) 0);
}
if (v_SYMBOL_0 != NIL) {
t2 = v_VALUE_1;
} else {
t2 = v_SYMBOL_0;
}
((LP) (DEREF((v_SYMBOL_0) + 1 * 4) = (LD) (t2)));
return(v_VALUE_1);
}

LP p_lsp_SET_2DSYMBOL_2DPLIST(argc, v_SYMBOL_0, v_VALUE_1)
      ARGC argc;  LP v_SYMBOL_0; LP v_VALUE_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_SYMBOLP) (1, v_SYMBOL_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_SYMBOL_0, LREF(s_lsp_SYMBOL), (LP) 0);
}
t1 = ICALL(s_lsp_LISTP) (1, v_VALUE_1);
if (t1 == NIL) {
ICALL(s_lsp_WTA) (3, v_VALUE_1, LREF(s_lsp_LIST), (LP) 0);
}
((LP) (DEREF((v_SYMBOL_0) + 3 * 4) = (LD) (v_VALUE_1)));
return(v_VALUE_1);
}

LP p_lsp_SET(argc, v_X_0, v_V_1)
      ARGC argc;  LP v_X_0; LP v_V_1;
{

LP t0; LP t1; 
if (argc != 2) wna(argc,2);
((LP) (DEREF((v_X_0) + 0 * 4) = (LD) (v_V_1)));
return(v_V_1);
}

LP p_lsp_SPECIAL_2DVAR_3F(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_SYMBOL_2DFLAG) (2, v_S_0, (LP) 0);
t0 = (num_equal_p((t1), ((LP) 2)));
return(t0);
}

LP p_lsp_SYMBOL_2DFLAG(argc, v_S_0, v_FLAG_1)
      ARGC argc;  LP v_S_0; LP v_FLAG_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_SYMBOLP) (1, v_S_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_S_0, LREF(s_lsp_SYMBOL), (LP) 0);
}
t1 = ICALL(s_lsp_FIXNUMP) (1, v_FLAG_1);
if (t1 == NIL) {
ICALL(s_lsp_WTA) (3, v_FLAG_1, LREF(s_lsp_FIXNUM), (LP) 0);
}
t3 = ((LP) DEREF((v_S_0) + 2 * 4));
t2 = INT_TO_FX((((unsigned int) (DEREF((t3) + 6 * 4)) >> FX_TO_INT(v_FLAG_1)) & 1));
return(t2);
}

LP p_lsp_UNSAFE_2DSYMBOL_2DFUNCTION(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_SYMBOLP) (1, v_X_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_X_0, LREF(s_lsp_SYMBOL), (LP) 0);
}
t1 = ((LP) DEREF((v_X_0) + 4 * 4));
return(t1);
}

LP p_lsp_SYMBOL_2DFUNCTION(argc, v_SYMBOL_0)
      ARGC argc;  LP v_SYMBOL_0;
{
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 1) wna(argc,1);
if ((LDREF((v_SYMBOL_0),SYMBOL,function) != (LP) LREF(ubf_procedure))) {
v_X_2 = v_SYMBOL_0;
t0 = ((LP) DEREF((v_SYMBOL_0) + 4 * 4));
return(t0);
} else {
t0 = ICALL(s_lsp_SYMBOL_2DFUNCTION_2DERROR) (MV_CALL(argc,1), v_SYMBOL_0);
return(t0);
}
}

LP p_lsp_UNSAFE_2DSYMBOL_2DVALUE(argc, v_SYMBOL_0)
      ARGC argc;  LP v_SYMBOL_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ((LP) DEREF((v_SYMBOL_0) + 0 * 4));
return(t0);
}

LP p_lsp_SYMBOL_2DVALUE(argc, v_SYMBOL_0)
      ARGC argc;  LP v_SYMBOL_0;
{
LP v_SYMBOL_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 1) wna(argc,1);
if ((LDREF((v_SYMBOL_0),SYMBOL,value) != UBV_MARKER)) {
v_SYMBOL_2 = v_SYMBOL_0;
t0 = ((LP) DEREF((v_SYMBOL_0) + 0 * 4));
return(t0);
} else {
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,2), LREF(k3696), v_SYMBOL_0);
return(t0);
}
}

LP p_lsp_SYMBOL_2DHASH_2DCODE(argc, v_SYMBOL_0)
      ARGC argc;  LP v_SYMBOL_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_SYMBOLP) (1, v_SYMBOL_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_SYMBOL_0, LREF(s_lsp_SYMBOL), (LP) 0);
}
t1 = ((LP) DEREF((v_SYMBOL_0) + 5 * 4));
return(t1);
}

LP p_lsp_SYMBOL_2DNAME(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_SYMBOLP) (1, v_X_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_X_0, LREF(s_lsp_SYMBOL), (LP) 0);
}
t1 = ((LP) DEREF((v_X_0) + 7 * 4));
return(t1);
}

LP p_lsp_SYMBOL_2DPACKAGE(argc, v_SYMBOL_0)
      ARGC argc;  LP v_SYMBOL_0;
{
LP v_SYMBOL_3; LP v_REAL_2DSYMBOL_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_SYMBOLP) (1, v_SYMBOL_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_SYMBOL_0, LREF(s_lsp_SYMBOL), (LP) 0);
}
v_REAL_2DSYMBOL_2 = ((LP) DEREF((v_SYMBOL_0) + 2 * 4));
t2 = ICALL(s_lsp_EQ) (2, v_REAL_2DSYMBOL_2, LREF(s_lsp_NIL));
if (t2 != NIL) {
v_SYMBOL_3 = LREF(s_lsp__2ALISP_2DPACKAGE_2A);
t1 = ((LP) DEREF((LREF(s_lsp__2ALISP_2DPACKAGE_2A)) + 0 * 4));
return(t1);
} else {
t1 = ((LP) DEREF((v_REAL_2DSYMBOL_2) + 1 * 4));
return(t1);
}
}

LP p_lsp_SYMBOL_2DPLIST(argc, v_SYMBOL_0)
      ARGC argc;  LP v_SYMBOL_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_SYMBOLP) (1, v_SYMBOL_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_SYMBOL_0, LREF(s_lsp_SYMBOL), (LP) 0);
}
t1 = ((LP) DEREF((v_SYMBOL_0) + 3 * 4));
return(t1);
}

LP p_lsp_UPDATE_2DPROP(argc, v_PLIST_0, v_INDICATOR_1, v_VALUE_2)
      ARGC argc;  LP v_PLIST_0; LP v_INDICATOR_1; LP v_VALUE_2;
{
LP v_Y_29; LP v_X_28; LP v_Y_26; 
LP v_X_25; LP v_X_23; LP v_X_21; 
LP v_C_19; LP v_X_17; LP v_LIST_15; 
LP v_V_13; LP v_X_12; LP v_X_10; 
LP v_T5292_9; LP v_S5291_8; LP v_L_4; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; 
if (argc != 3) wna(argc,3);
v_L_4 = v_PLIST_0;
t_NEXT_2DLOOP_6:;
if (v_L_4 == NIL) {
goto t_END_2DLOOP_7;
}
v_LIST_15 = v_L_4;
v_X_17 = v_LIST_15;
t2 = ((LP) DEREF((v_LIST_15) + 0 * 4));
t1 = ICALL(s_lsp_EQ) (2, v_INDICATOR_1, t2);
if (t1 != NIL) {
v_S5291_8 = v_VALUE_2;
v_T5292_9 = v_L_4;
v_X_10 = v_T5292_9;
v_X_12 = ((LP) DEREF((v_T5292_9) + 1 * 4));
v_V_13 = v_VALUE_2;
((LP) (DEREF((v_X_12) + 0 * 4) = (LD) (v_V_13)));
return(v_PLIST_0);
return(NIL);
}
v_C_19 = v_L_4;
v_X_21 = v_C_19;
v_X_23 = ((LP) DEREF((v_C_19) + 1 * 4));
v_L_4 = ((LP) DEREF((v_X_23) + 1 * 4));
goto t_NEXT_2DLOOP_6;
goto t_END_2DLOOP_7;
t_END_2DLOOP_7:;
v_X_25 = v_VALUE_2;
v_Y_26 = v_PLIST_0;
v_Y_29 = (c_cons((v_VALUE_2), (v_PLIST_0)));
t3 = (c_cons((v_INDICATOR_1), (v_Y_29)));
return(t3);
return(NIL);
return(NIL);
}

LP p_lsp_SYMBOLS_5FINIT1127(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 0) wna(argc,0);
t0 = ICALL(s_lsp_DEFINE_2DSETF) (MV_CALL(argc,2), LREF(s_lsp_FDEFINITION), LREF(k3701));
return(t0);
}

LP p_lsp_SYMBOLS_5FINIT1127_2Danon36973698(argc, v_ACCESS_0, v_ENV_1)
      ARGC argc;  LP v_ACCESS_0; LP v_ENV_1;
{
LP v_Y_45; LP v_X_44; LP v_X_42; 
LP v_LIST_40; LP v_Y_38; LP v_X_37; 
LP v_X_35; LP v_TVARS_34; LP v_SVAR_33; 
LP v_X_31; LP v_V_29; LP v_X_28; 
LP v_NEW_2DCDR_26; LP v_C_25; LP v_Y_23; 
LP v_X_22; LP v_X_20; LP v_X_19; 
LP v_X_17; LP v_X_15; LP v_LOOPVAR_2D1131_11; 
LP v_LOOPVAR_2D1130_10; LP v_LOOPVAR_2D1129_9; LP v_LOOP_2DLIST_2D1128_8; 
LP v_ARG_7; LP v_X_5; LP v_X_3; 
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; 
if (argc != 2) wna(argc,2);
v_X_3 = LREF(k3702);
v_SVAR_33 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(k3702));
v_ARG_7 = LREF(s_lsp_NIL);
v_X_5 = v_ACCESS_0;
v_LOOP_2DLIST_2D1128_8 = ((LP) DEREF((v_ACCESS_0) + 1 * 4));
v_LOOPVAR_2D1129_9 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1130_10 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1131_11 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_13:;
if (v_LOOP_2DLIST_2D1128_8 == NIL) {
goto t_END_2DLOOP_14;
}
v_X_15 = v_LOOP_2DLIST_2D1128_8;
v_ARG_7 = ((LP) DEREF((v_X_15) + 0 * 4));
v_X_17 = v_LOOP_2DLIST_2D1128_8;
v_LOOP_2DLIST_2D1128_8 = ((LP) DEREF((v_X_17) + 1 * 4));
v_X_20 = LREF(k3694);
v_X_22 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(k3694));
v_LOOPVAR_2D1131_11 = (c_cons((v_X_22), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D1130_10 != NIL) {
v_C_25 = v_LOOPVAR_2D1130_10;
v_NEW_2DCDR_26 = v_LOOPVAR_2D1131_11;
v_V_29 = v_NEW_2DCDR_26;
((LP) (DEREF((v_C_25) + 1 * 4) = (LD) (v_V_29)));
v_X_31 = v_C_25;
v_LOOPVAR_2D1130_10 = ((LP) DEREF((v_X_31) + 1 * 4));
} else {
v_LOOPVAR_2D1129_9 = v_LOOPVAR_2D1131_11;
v_LOOPVAR_2D1130_10 = v_LOOPVAR_2D1129_9;
}
goto t_NEXT_2DLOOP_13;
goto t_END_2DLOOP_14;
t_END_2DLOOP_14:;
v_TVARS_34 = v_LOOPVAR_2D1129_9;
goto b_NIL_12;
v_TVARS_34 = NIL;
v_TVARS_34 = v_TVARS_34;
b_NIL_12:;
v_X_35 = v_ACCESS_0;
t0 = ((LP) DEREF((v_ACCESS_0) + 1 * 4));
v_X_37 = v_SVAR_33;
v_Y_38 = LREF(s_lsp_NIL);
t1 = (c_cons((v_SVAR_33), (LREF(s_lsp_NIL))));
t2 = p_lsp_APPLY(3, COERCE_TO_FUNCTION(LREF(k3703)), v_SVAR_33, v_TVARS_34);
v_LIST_40 = v_ACCESS_0;
v_X_42 = v_ACCESS_0;
v_X_44 = ((LP) DEREF((v_ACCESS_0) + 0 * 4));
t3 = (c_cons((v_X_44), (v_TVARS_34)));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,5);
SET_MV_RETURN_VALUE(argc,1,t0);
SET_MV_RETURN_VALUE(argc,2,t1);
SET_MV_RETURN_VALUE(argc,3,t2);
SET_MV_RETURN_VALUE(argc,4,t3);
}
return(v_TVARS_34);
}

LP p_lsp_SYMBOLS_5FINIT1127_2Danon36973698SYMBOLS_5FINIT1127_2Danon36993700(argc, v_NEW_2DVALUE_0, v_FUNCTION_2DSPECIFIER_1)
      ARGC argc;  LP v_NEW_2DVALUE_0; LP v_FUNCTION_2DSPECIFIER_1;
{
LP v_Y_9; LP v_X_8; LP v_Y_6; 
LP v_X_5; LP v_Y_3; LP v_X_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 2) wna(argc,2);
v_X_2 = v_FUNCTION_2DSPECIFIER_1;
v_Y_3 = LREF(s_lsp_NIL);
v_Y_6 = (c_cons((v_FUNCTION_2DSPECIFIER_1), (LREF(s_lsp_NIL))));
v_Y_9 = (c_cons((v_NEW_2DVALUE_0), (v_Y_6)));
t0 = (c_cons((LREF(s_lsp_SET_2DFDEFINITION)), (v_Y_9)));
return(t0);
}

