/*
:comment "Compiled at 4:44:57 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: Debug Library"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O2 -fPIC"
:version 0
:end-package-info 0
:sym NIL
:sym READ-CHAR/3
:sym SKIP-TO-NEXT-FORM-1
:sf SKIP-TO-NEXT-FORM "p_lsp_SKIP_2DTO_2DNEXT_2DFORM"
:sym *READTABLE*
:sym T
:sym UNREAD-CHAR/2
:sf SKIP-TO-NEXT-FORM-1 "p_lsp_SKIP_2DTO_2DNEXT_2DFORM_2D1"
:sym LINE-NUMBER-STREAM-P
:sym *OPEN-PAREN-COUNT*
:sym SKIP-TO-NEXT-FORM
:sym READ-LIST-WITH-LINES
:sym *SOURCE-TABLE*
:sym SET-GETHASH
:sym CHAR-MACRO-OPEN-PAREN
:sf CHAR-MACRO-OPEN-PAREN-WITH-LINES "p_lsp_CHAR_2DMACRO_2DOPEN_2DPAREN_2DWITH_2DLINES"
:sym READ/4
:sym MAKE-LINE-SYMBOL
:sym *CLOSE-PAREN-MARKER*
:sym *DOT-MARKER*
:sym ERROR
:sf READ-LIST-WITH-LINES "p_lsp_READ_2DLIST_2DWITH_2DLINES"
:sym MAKE-DEFAULT-READTABLE
:sym CHAR-MACRO-OPEN-PAREN-WITH-LINES
:sym SET-MACRO-CHARACTER
:sf MAKE-LINE-NUMBER-READTABLE "p_lsp_MAKE_2DLINE_2DNUMBER_2DREADTABLE"
:sym LINE-SYMBOL-LINE
:sym GETHASH
:sf SOURCE-LINE "p_lsp_SOURCE_2DLINE"
:pinfo READ-LIST-WITH-LINES (STREAM) NIL NIL NIL NIL NIL NIL T
:pinfo SOURCE-LINE (FORM) NIL NIL NIL NIL NIL NIL T
:pinfo SKIP-TO-NEXT-FORM (STREAM) NIL NIL NIL NIL NIL NIL T
:pinfo MAKE-LINE-NUMBER-READTABLE NIL NIL NIL NIL NIL NIL NIL T
:pinfo CHAR-MACRO-OPEN-PAREN-WITH-LINES (STREAM CHAR) NIL NIL NIL NIL NIL NIL T
:pinfo SKIP-TO-NEXT-FORM-1 (STREAM CHAR) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_lsp_SKIP_2DTO_2DNEXT_2DFORM();
extern SYMBOL s_lsp_NIL; 
extern SYMBOL s_lsp_READ_2DCHAR_2F3; 
extern SYMBOL s_lsp_SKIP_2DTO_2DNEXT_2DFORM_2D1; 
extern LP p_lsp_SKIP_2DTO_2DNEXT_2DFORM_2D1();
extern SYMBOL s_lsp__2AREADTABLE_2A; 
extern SYMBOL s_lsp_T; 
extern SYMBOL s_lsp_UNREAD_2DCHAR_2F2; 
extern LP p_lsp_CHAR_2DMACRO_2DOPEN_2DPAREN_2DWITH_2DLINES();
extern SYMBOL s_lsp_LINE_2DNUMBER_2DSTREAM_2DP; 
extern SYMBOL s_lsp__2AOPEN_2DPAREN_2DCOUNT_2A; 
extern SYMBOL s_lsp_SKIP_2DTO_2DNEXT_2DFORM; 
extern SYMBOL s_lsp_READ_2DLIST_2DWITH_2DLINES; 
extern SYMBOL s_lsp__2ASOURCE_2DTABLE_2A; 
extern SYMBOL s_lsp_SET_2DGETHASH; 
extern SYMBOL s_lsp_CHAR_2DMACRO_2DOPEN_2DPAREN; 
extern LP p_lsp_READ_2DLIST_2DWITH_2DLINES();
extern SYMBOL s_lsp_READ_2F4; 
extern SYMBOL s_lsp_MAKE_2DLINE_2DSYMBOL; 
extern SYMBOL s_lsp__2ACLOSE_2DPAREN_2DMARKER_2A; 
extern SYMBOL s_lsp__2ADOT_2DMARKER_2A; 
MAKE_SIMPLE_STRING(k10761,44,"A closing parenthesis is missing after a dot");
extern SYMBOL s_lsp_ERROR; 
extern LP p_lsp_MAKE_2DLINE_2DNUMBER_2DREADTABLE();
extern SYMBOL s_lsp_MAKE_2DDEFAULT_2DREADTABLE; 
extern SYMBOL s_lsp_CHAR_2DMACRO_2DOPEN_2DPAREN_2DWITH_2DLINES; 
extern SYMBOL s_lsp_SET_2DMACRO_2DCHARACTER; 
extern LP p_lsp_SOURCE_2DLINE();
extern SYMBOL s_lsp_LINE_2DSYMBOL_2DLINE; 
extern SYMBOL s_lsp_GETHASH; 


extern LP c_cons();
extern LP c_eql();
extern LP add();
extern LP num_equal_p();


LP p_lsp_SKIP_2DTO_2DNEXT_2DFORM(argc, v_STREAM_0)
      ARGC argc;  LP v_STREAM_0;
{
LP v_RECURSIVEP_11; LP v_EOF_2DVALUE_10; LP v_EOF_2DERROR_2DP_9; 
LP v_STREAM_8; LP v_RECURSIVEP_7; LP v_EOF_2DVALUE_6; 
LP v_EOF_2DERROR_2DP_5; LP v_SYMBOL_3; LP v_STREAM_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 

if (argc != 1) wna(argc,1);
v_STREAM_8 = v_STREAM_0;
v_EOF_2DERROR_2DP_9 = LREF(s_lsp_NIL);
v_EOF_2DVALUE_10 = v_STREAM_0;
v_RECURSIVEP_11 = LREF(s_lsp_NIL);
t1 = ICALL(s_lsp_READ_2DCHAR_2F3) (3, v_STREAM_0, LREF(s_lsp_NIL), v_STREAM_0);
t0 = ICALL(s_lsp_SKIP_2DTO_2DNEXT_2DFORM_2D1) (MV_CALL(argc,2), v_STREAM_0, t1);
return(t0);
}

LP p_lsp_SKIP_2DTO_2DNEXT_2DFORM_2D1(argc, v_STREAM_0, v_CHAR_1)
      ARGC argc;  LP v_STREAM_0; LP v_CHAR_1;
{
LP v_C_63; LP v_I_61; LP v_S_60; 
LP v_S_58; LP v_SYMBOL_56; LP v_CHAR2_54; 
LP v_CHAR1_53; LP v_Y_51; LP v_X_50; 
LP v_STREAM_48; LP v_CHAR_47; LP v_CHAR_43; 
LP v_SYMBOL_45; LP v_STREAM_44; LP v_RECURSIVEP_41; 
LP v_EOF_2DVALUE_40; LP v_EOF_2DERROR_2DP_39; LP v_STREAM_38; 
LP v_RECURSIVEP_37; LP v_EOF_2DVALUE_36; LP v_EOF_2DERROR_2DP_35; 
LP v_SYMBOL_33; LP v_STREAM_32; LP v_CHAR2_30; 
LP v_CHAR1_29; LP v_RECURSIVEP_27; LP v_EOF_2DVALUE_26; 
LP v_EOF_2DERROR_2DP_25; LP v_STREAM_24; LP v_RECURSIVEP_23; 
LP v_EOF_2DVALUE_22; LP v_EOF_2DERROR_2DP_21; LP v_SYMBOL_19; 
LP v_STREAM_18; LP v_CH_14; LP v_RECURSIVEP_12; 
LP v_EOF_2DVALUE_11; LP v_EOF_2DERROR_2DP_10; LP v_STREAM_9; 
LP v_RECURSIVEP_8; LP v_EOF_2DVALUE_7; LP v_EOF_2DERROR_2DP_6; 
LP v_SYMBOL_4; LP v_STREAM_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 

if (argc != 2) wna(argc,2);
START10760:
v_SYMBOL_56 = LREF(s_lsp__2AREADTABLE_2A);
v_S_58 = ((LP) DEREF((LREF(s_lsp__2AREADTABLE_2A)) + 0 * 4));
v_S_60 = v_S_58;
v_I_61 = (LP) 2;
t3 = ((LP) DEREF((v_S_58) + 1 * 4));
v_C_63 = v_CHAR_1;
t4 = INT_TO_FX(((int) RAW_CHAR(v_CHAR_1)));
t2 = ((LP) DEREF((t3) + FX_TO_INT(t4) * 4));
t1 = (num_equal_p((t2), ((LP) 0)));
if (t1 != NIL) {
v_STREAM_9 = v_STREAM_0;
v_EOF_2DERROR_2DP_10 = LREF(s_lsp_NIL);
v_EOF_2DVALUE_11 = v_STREAM_0;
v_RECURSIVEP_12 = LREF(s_lsp_NIL);
t5 = ICALL(s_lsp_READ_2DCHAR_2F3) (3, v_STREAM_0, LREF(s_lsp_NIL), v_STREAM_0);
v_CHAR_1 = t5; 
goto START10760;
} else {
v_CHAR1_53 = v_CHAR_1;
v_CHAR2_54 = LREF(char_tab[59]);
if (((v_CHAR_1) == (LREF(char_tab[59])))) {
v_CH_14 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_16:;
v_STREAM_24 = v_STREAM_0;
v_EOF_2DERROR_2DP_25 = LREF(s_lsp_NIL);
v_EOF_2DVALUE_26 = LREF(char_tab[10]);
v_RECURSIVEP_27 = LREF(s_lsp_T);
v_CH_14 = ICALL(s_lsp_READ_2DCHAR_2F3) (3, v_STREAM_0, LREF(s_lsp_NIL), LREF(char_tab[10]));
v_CHAR1_29 = v_CH_14;
if (((v_CHAR1_29) == (LREF(char_tab[10])))) {
goto t_END_2DLOOP_17;
}
goto t_NEXT_2DLOOP_16;
goto t_END_2DLOOP_17;
t_END_2DLOOP_17:;
v_STREAM_38 = v_STREAM_0;
v_EOF_2DERROR_2DP_39 = LREF(s_lsp_NIL);
v_EOF_2DVALUE_40 = v_STREAM_0;
v_RECURSIVEP_41 = LREF(s_lsp_NIL);
t8 = ICALL(s_lsp_READ_2DCHAR_2F3) (3, v_STREAM_0, LREF(s_lsp_NIL), v_STREAM_0);
v_CHAR_1 = t8; 
goto START10760;
} else {
v_X_50 = v_STREAM_0;
v_Y_51 = v_CHAR_1;
if (((v_STREAM_0) == (v_CHAR_1))) {
return(v_STREAM_0);
} else {
v_CHAR_47 = v_CHAR_1;
v_STREAM_48 = v_STREAM_0;
t0 = ICALL(s_lsp_UNREAD_2DCHAR_2F2) (MV_CALL(argc,2), v_CHAR_1, v_STREAM_0);
return(t0);
}
}
}
}

LP p_lsp_CHAR_2DMACRO_2DOPEN_2DPAREN_2DWITH_2DLINES(argc, v_STREAM_0, v_CHAR_1)
      ARGC argc;  LP v_STREAM_0; LP v_CHAR_1;
{
LP v_T5887_17; LP v_SYMBOL_15; LP v_T5886_14; 
LP v_S5885_13; LP v_L_12; LP v_LINE_11; 
LP v_I_9; LP v_S_8; LP v_S_6; 
LP v__2AOPEN_2DPAREN_2DCOUNT_2A_5; LP v_SYMBOL_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; 
if (argc != 2) wna(argc,2);
t1 = ICALL(s_lsp_LINE_2DNUMBER_2DSTREAM_2DP) (1, v_STREAM_0);
if (t1 != NIL) {
v_SYMBOL_3 = LREF(s_lsp__2AOPEN_2DPAREN_2DCOUNT_2A);
t2 = ((LP) DEREF((LREF(s_lsp__2AOPEN_2DPAREN_2DCOUNT_2A)) + 0 * 4));
v__2AOPEN_2DPAREN_2DCOUNT_2A_5 = (add((t2), ((LP) 2)));
BEGIN_SPEC_BIND(s_lsp__2AOPEN_2DPAREN_2DCOUNT_2A,v__2AOPEN_2DPAREN_2DCOUNT_2A_5);
ICALL(s_lsp_SKIP_2DTO_2DNEXT_2DFORM) (1, v_STREAM_0);
v_S_6 = v_STREAM_0;
v_S_8 = v_STREAM_0;
v_I_9 = (LP) 32;
v_LINE_11 = ((LP) DEREF((v_STREAM_0) + 16 * 4));
v_L_12 = ICALL(s_lsp_READ_2DLIST_2DWITH_2DLINES) (1, v_STREAM_0);
v_S5885_13 = v_LINE_11;
v_T5886_14 = v_L_12;
v_SYMBOL_15 = LREF(s_lsp__2ASOURCE_2DTABLE_2A);
v_T5887_17 = ((LP) DEREF((LREF(s_lsp__2ASOURCE_2DTABLE_2A)) + 0 * 4));
ICALL(s_lsp_SET_2DGETHASH) (3, v_L_12, v_T5887_17, v_LINE_11);
END_SPEC_BIND(s_lsp__2AOPEN_2DPAREN_2DCOUNT_2A);
return(v_L_12);
} else {
t0 = ICALL(s_lsp_CHAR_2DMACRO_2DOPEN_2DPAREN) (MV_CALL(argc,2), v_STREAM_0, v_CHAR_1);
return(t0);
}
}

LP p_lsp_READ_2DLIST_2DWITH_2DLINES(argc, v_STREAM_0)
      ARGC argc;  LP v_STREAM_0;
{
LP v_Y_50; LP v_X_49; LP v_SYMBOL_47; 
LP v_Y_45; LP v_X_44; LP v_SYMBOL_42; 
LP v_X_40; LP v_G5896_39; LP v_X_37; 
LP v_G5895_36; LP v_X_34; LP v_T5894_33; 
LP v_SYMBOL_31; LP v_T5893_30; LP v_S5892_29; 
LP v_T5891_28; LP v_SYMBOL_26; LP v_T5890_25; 
LP v_S5889_24; LP v_L_23; LP v_Y_21; 
LP v_X_20; LP v_Y_18; LP v_X_17; 
LP v_SYMBOL_15; LP v_CLOSE_14; LP v_CDR_13; 
LP v_KEY5888_12; LP v_ITEM_11; LP v_S_9; 
LP v_X_8; LP v_LINE_7; LP v_I_5; 
LP v_S_4; LP v_S_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; 
if (argc != 1) wna(argc,1);
ICALL(s_lsp_SKIP_2DTO_2DNEXT_2DFORM) (1, v_STREAM_0);
v_S_2 = v_STREAM_0;
v_S_4 = v_STREAM_0;
v_I_5 = (LP) 32;
v_LINE_7 = ((LP) DEREF((v_STREAM_0) + 16 * 4));
v_X_8 = ICALL(s_lsp_READ_2F4) (4, v_STREAM_0, LREF(s_lsp_T), LREF(s_lsp_NIL), LREF(s_lsp_T));
v_S_9 = v_X_8;
if (OTHER_PTRP((v_X_8)) && (TAG((v_X_8)) == 3)) {
v_ITEM_11 = ICALL(s_lsp_MAKE_2DLINE_2DSYMBOL) (2, v_X_8, v_LINE_7);
} else {
v_ITEM_11 = v_X_8;
}
v_KEY5888_12 = v_ITEM_11;
v_SYMBOL_47 = LREF(s_lsp__2ACLOSE_2DPAREN_2DMARKER_2A);
v_Y_50 = ((LP) DEREF((LREF(s_lsp__2ACLOSE_2DPAREN_2DMARKER_2A)) + 0 * 4));
t2 = (c_eql((v_KEY5888_12), (v_Y_50)));
if (t2 != NIL) {
return(LREF(s_lsp_NIL));
} else {
v_SYMBOL_42 = LREF(s_lsp__2ADOT_2DMARKER_2A);
v_Y_45 = ((LP) DEREF((LREF(s_lsp__2ADOT_2DMARKER_2A)) + 0 * 4));
t3 = (c_eql((v_KEY5888_12), (v_Y_45)));
if (t3 != NIL) {
v_CDR_13 = ICALL(s_lsp_READ_2F4) (4, v_STREAM_0, LREF(s_lsp_T), LREF(s_lsp_NIL), LREF(s_lsp_T));
v_CLOSE_14 = ICALL(s_lsp_READ_2F4) (4, v_STREAM_0, LREF(s_lsp_T), LREF(s_lsp_NIL), LREF(s_lsp_T));
v_SYMBOL_15 = LREF(s_lsp__2ACLOSE_2DPAREN_2DMARKER_2A);
v_Y_18 = ((LP) DEREF((LREF(s_lsp__2ACLOSE_2DPAREN_2DMARKER_2A)) + 0 * 4));
if (((v_CLOSE_14) == (v_Y_18)) == 0) {
ICALL(s_lsp_ERROR) (1, LREF(k10761));
}
return(v_CDR_13);
} else {
v_Y_21 = ICALL(s_lsp_READ_2DLIST_2DWITH_2DLINES) (1, v_STREAM_0);
v_L_23 = (c_cons((v_ITEM_11), (v_Y_21)));
v_X_34 = v_ITEM_11;
v_G5895_36 = (OTHER_PTRP((v_ITEM_11)) && (TAG((v_ITEM_11)) == 15) ? T : NIL);
if (v_G5895_36 != NIL) {
t5 = v_G5895_36;
} else {
v_X_37 = v_ITEM_11;
v_G5896_39 = (FIXNUMP((v_ITEM_11)) ? T : NIL);
if (v_G5896_39 != NIL) {
t5 = v_G5896_39;
} else {
v_X_40 = v_ITEM_11;
t5 = (OTHER_PTRP((v_ITEM_11)) && (TAG((v_ITEM_11)) == 7) ? T : NIL);
}
}
if (t5 != NIL) {
v_S5889_24 = v_LINE_7;
v_T5890_25 = v_L_23;
v_SYMBOL_26 = LREF(s_lsp__2ASOURCE_2DTABLE_2A);
v_T5891_28 = ((LP) DEREF((LREF(s_lsp__2ASOURCE_2DTABLE_2A)) + 0 * 4));
ICALL(s_lsp_SET_2DGETHASH) (3, v_L_23, v_T5891_28, v_LINE_7);
} else {
v_S5892_29 = v_LINE_7;
v_T5893_30 = v_ITEM_11;
v_SYMBOL_31 = LREF(s_lsp__2ASOURCE_2DTABLE_2A);
v_T5894_33 = ((LP) DEREF((LREF(s_lsp__2ASOURCE_2DTABLE_2A)) + 0 * 4));
ICALL(s_lsp_SET_2DGETHASH) (3, v_ITEM_11, v_T5894_33, v_LINE_7);
}
return(v_L_23);
}
}
}

LP p_lsp_MAKE_2DLINE_2DNUMBER_2DREADTABLE(argc)
      ARGC argc; 
{
LP v_X_2; LP v_RT_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 0) wna(argc,0);
v_RT_1 = ICALL(s_lsp_MAKE_2DDEFAULT_2DREADTABLE) (0);
v_X_2 = LREF(s_lsp_CHAR_2DMACRO_2DOPEN_2DPAREN_2DWITH_2DLINES);
t0 = ((LP) DEREF((LREF(s_lsp_CHAR_2DMACRO_2DOPEN_2DPAREN_2DWITH_2DLINES)) + 4 * 4));
ICALL(s_lsp_SET_2DMACRO_2DCHARACTER) (4, LREF(char_tab[40]), t0, LREF(s_lsp_NIL), v_RT_1);
return(v_RT_1);
}

LP p_lsp_SOURCE_2DLINE(argc, v_FORM_0)
      ARGC argc;  LP v_FORM_0;
{
LP v_S_4; LP v_SYMBOL_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 1) wna(argc,1);
v_S_4 = v_FORM_0;
if (OTHER_PTRP((v_FORM_0)) && (TAG((v_FORM_0)) == 11)) {
t0 = ICALL(s_lsp_LINE_2DSYMBOL_2DLINE) (MV_CALL(argc,1), v_FORM_0);
return(t0);
} else {
v_SYMBOL_2 = LREF(s_lsp__2ASOURCE_2DTABLE_2A);
t2 = ((LP) DEREF((LREF(s_lsp__2ASOURCE_2DTABLE_2A)) + 0 * 4));
t0 = ICALL(s_lsp_GETHASH) (MV_CALL(argc,2), v_FORM_0, t2);
return(t0);
}
}

