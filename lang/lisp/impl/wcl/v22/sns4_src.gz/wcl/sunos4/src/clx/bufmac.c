/*
:comment "Compiled at 5:12:50 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: Debug Library"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O2 -fPIC"
:version 0
:package (IN-PACKAGE :XLIB) 
:end-package-info 0
:sym ASET-CARD8
:sym NIL
:sym CARD8
:sym THE
:sym BUFFER-BBUF
:sym BUFFER-BOFFSET
:sym INDEX+
:sym LIST
:sm WRITE-CARD8 "m_xlib_WRITE_2DCARD8"
:sym ASET-INT8
:sym INT8
:sm WRITE-INT8 "m_xlib_WRITE_2DINT8"
:sym ASET-CARD16
:sym CARD16
:sm WRITE-CARD16 "m_xlib_WRITE_2DCARD16"
:sym ASET-INT16
:sym INT16
:sm WRITE-INT16 "m_xlib_WRITE_2DINT16"
:sym ASET-CARD32
:sym CARD32
:sm WRITE-CARD32 "m_xlib_WRITE_2DCARD32"
:sym ASET-INT32
:sym INT32
:sm WRITE-INT32 "m_xlib_WRITE_2DINT32"
:sym ASET-CARD29
:sym CARD29
:sm WRITE-CARD29 "m_xlib_WRITE_2DCARD29"
:sym LET
:sym %ITEM
:sym %BYTE-INDEX
:sym DECLARE
:sym TYPE
:sym ARRAY-INDEX
:sym LDB
:sym BYTE
:sym LIST*
:sm WRITE-CHAR2B "m_xlib_WRITE_2DCHAR2B"
:sym .BOFFSET.
:sym SETQ
:sm SET-BUFFER-OFFSET "m_xlib_SET_2DBUFFER_2DOFFSET"
:sym SET-BUFFER-OFFSET
:sm ADVANCE-BUFFER-OFFSET "m_xlib_ADVANCE_2DBUFFER_2DOFFSET"
:sym :SIZES
:sym :LENGTH
:sym :INDEX
:sym %BUFFER
:sym DISPLAY
:sym DECLARE-BUFMAC
:sym WHEN
:sym INDEX>=
:sym BUFFER-SIZE
:sym BUFFER-FLUSH
:sym LET*
:sym BUFFER-OBUF8
:sym BUFFER-BYTES
:sym ARRAY-REGISTER
:sm WITH-BUFFER-OUTPUT "m_xlib_WITH_2DBUFFER_2DOUTPUT"
:sym LENGTH
:sym ERROR
:sym INDEX-INCREMENT
:sym WITH-BUFFER-OUTPUT
:sym BUFFER
:sym BOFFSET
:sym ADJOIN
:sym REVERSE
:sym DO*
:sym LEN
:sym INDEX-
:sym END
:sym START
:sym LISP::TRUNCATE/2
:sym INDEX-ASH
:sym CHUNK
:sym INDEX-MIN
:sym LISP::APPEND/2
:sym NOT
:sym INDEX-PLUSP
:sym INDEX-INCF
:sym AND
:sym SETF
:sym LROUND
:sm WRITING-BUFFER-CHUNKS "m_xlib_WRITING_2DBUFFER_2DCHUNKS"
:sym WRITE-CARD8
:sym LISP::DEFINE-MACRO
:sym WRITE-INT8
:sym WRITE-CARD16
:sym WRITE-INT16
:sym WRITE-CARD32
:sym WRITE-INT32
:sym WRITE-CARD29
:sym WRITE-CHAR2B
:sym ADVANCE-BUFFER-OFFSET
:sym WRITING-BUFFER-CHUNKS
:sf BUFMAC_INIT172 "p_xlib_BUFMAC_5FINIT172"
:init BUFMAC_INIT172
:pinfo XLIB::BUFMAC_INIT172 NIL NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP m_xlib_WRITE_2DCARD8();
extern SYMBOL s_xlib_ASET_2DCARD8; 
extern SYMBOL s_lsp_NIL; 
extern SYMBOL s_xlib_CARD8; 
extern SYMBOL s_lsp_THE; 
extern SYMBOL s_xlib_BUFFER_2DBBUF; 
extern SYMBOL s_xlib_BUFFER_2DBOFFSET; 
extern SYMBOL s_xlib_INDEX_2B; 
extern SYMBOL s_lsp_LIST; 
extern LP m_xlib_WRITE_2DINT8();
extern SYMBOL s_xlib_ASET_2DINT8; 
extern SYMBOL s_xlib_INT8; 
extern LP m_xlib_WRITE_2DCARD16();
extern SYMBOL s_xlib_ASET_2DCARD16; 
extern SYMBOL s_xlib_CARD16; 
extern LP m_xlib_WRITE_2DINT16();
extern SYMBOL s_xlib_ASET_2DINT16; 
extern SYMBOL s_xlib_INT16; 
extern LP m_xlib_WRITE_2DCARD32();
extern SYMBOL s_xlib_ASET_2DCARD32; 
extern SYMBOL s_xlib_CARD32; 
extern LP m_xlib_WRITE_2DINT32();
extern SYMBOL s_xlib_ASET_2DINT32; 
extern SYMBOL s_xlib_INT32; 
extern LP m_xlib_WRITE_2DCARD29();
extern SYMBOL s_xlib_ASET_2DCARD29; 
extern SYMBOL s_xlib_CARD29; 
extern LP m_xlib_WRITE_2DCHAR2B();
extern SYMBOL s_lsp_LET; 
extern SYMBOL s_xlib__25ITEM; 
extern SYMBOL s_xlib__25BYTE_2DINDEX; 
extern SYMBOL s_lsp_DECLARE; 
extern SYMBOL s_lsp_TYPE; 
MAKE_CONS(k2424,LREF(s_xlib__25ITEM),LREF(s_lsp_NIL));
MAKE_CONS(k2423,LREF(s_xlib_CARD16),LREF(k2424));
MAKE_CONS(k2422,LREF(s_lsp_TYPE),LREF(k2423));
extern SYMBOL s_xlib_ARRAY_2DINDEX; 
MAKE_CONS(k2428,LREF(s_xlib__25BYTE_2DINDEX),LREF(s_lsp_NIL));
MAKE_CONS(k2427,LREF(s_xlib_ARRAY_2DINDEX),LREF(k2428));
MAKE_CONS(k2426,LREF(s_lsp_TYPE),LREF(k2427));
MAKE_CONS(k2425,LREF(k2426),LREF(s_lsp_NIL));
MAKE_CONS(k2421,LREF(k2422),LREF(k2425));
MAKE_CONS(k2420,LREF(s_lsp_DECLARE),LREF(k2421));
extern SYMBOL s_lsp_LDB; 
extern SYMBOL s_lsp_BYTE; 
MAKE_CONS(k2439,(LP) 16,LREF(s_lsp_NIL));
MAKE_CONS(k2438,(LP) 16,LREF(k2439));
MAKE_CONS(k2437,LREF(s_lsp_BYTE),LREF(k2438));
MAKE_CONS(k2436,LREF(k2437),LREF(k2424));
MAKE_CONS(k2435,LREF(s_lsp_LDB),LREF(k2436));
MAKE_CONS(k2434,LREF(k2435),LREF(s_lsp_NIL));
MAKE_CONS(k2433,LREF(s_xlib_CARD8),LREF(k2434));
MAKE_CONS(k2432,LREF(s_lsp_THE),LREF(k2433));
MAKE_CONS(k2440,LREF(s_xlib_BUFFER_2DBBUF),LREF(k2428));
MAKE_CONS(k2431,LREF(k2432),LREF(k2440));
MAKE_CONS(k2430,LREF(s_xlib_ASET_2DCARD8),LREF(k2431));
MAKE_CONS(k2451,(LP) 0,LREF(s_lsp_NIL));
MAKE_CONS(k2450,(LP) 16,LREF(k2451));
MAKE_CONS(k2449,LREF(s_lsp_BYTE),LREF(k2450));
MAKE_CONS(k2448,LREF(k2449),LREF(k2424));
MAKE_CONS(k2447,LREF(s_lsp_LDB),LREF(k2448));
MAKE_CONS(k2446,LREF(k2447),LREF(s_lsp_NIL));
MAKE_CONS(k2445,LREF(s_xlib_CARD8),LREF(k2446));
MAKE_CONS(k2444,LREF(s_lsp_THE),LREF(k2445));
MAKE_CONS(k2456,(LP) 2,LREF(s_lsp_NIL));
MAKE_CONS(k2455,LREF(s_xlib__25BYTE_2DINDEX),LREF(k2456));
MAKE_CONS(k2454,LREF(s_xlib_INDEX_2B),LREF(k2455));
MAKE_CONS(k2453,LREF(k2454),LREF(s_lsp_NIL));
MAKE_CONS(k2452,LREF(s_xlib_BUFFER_2DBBUF),LREF(k2453));
MAKE_CONS(k2443,LREF(k2444),LREF(k2452));
MAKE_CONS(k2442,LREF(s_xlib_ASET_2DCARD8),LREF(k2443));
MAKE_CONS(k2441,LREF(k2442),LREF(s_lsp_NIL));
MAKE_CONS(k2429,LREF(k2430),LREF(k2441));
MAKE_CONS(k2419,LREF(k2420),LREF(k2429));
extern SYMBOL s_lsp_LIST_2A; 
extern LP m_xlib_SET_2DBUFFER_2DOFFSET();
extern SYMBOL s_xlib__2EBOFFSET_2E; 
MAKE_CONS(k2462,LREF(s_xlib__2EBOFFSET_2E),LREF(s_lsp_NIL));
MAKE_CONS(k2461,LREF(s_xlib_ARRAY_2DINDEX),LREF(k2462));
MAKE_CONS(k2460,LREF(s_lsp_TYPE),LREF(k2461));
MAKE_CONS(k2459,LREF(k2460),LREF(s_lsp_NIL));
MAKE_CONS(k2458,LREF(s_lsp_DECLARE),LREF(k2459));
extern SYMBOL s_lsp_SETQ; 
MAKE_CONS(k2465,LREF(s_xlib_BUFFER_2DBOFFSET),LREF(k2462));
MAKE_CONS(k2464,LREF(s_lsp_SETQ),LREF(k2465));
MAKE_CONS(k2463,LREF(k2464),LREF(s_lsp_NIL));
MAKE_CONS(k2457,LREF(k2458),LREF(k2463));
extern LP m_xlib_ADVANCE_2DBUFFER_2DOFFSET();
extern SYMBOL s_xlib_SET_2DBUFFER_2DOFFSET; 
extern LP m_xlib_WITH_2DBUFFER_2DOUTPUT();
extern LP p_xlib_WITH_2DBUFFER_2DOUTPUT_2Danon24662467();
extern SYMBOL s_key_SIZES; 
MAKE_CONS(k2470,(LP) 64,LREF(s_lsp_NIL));
MAKE_CONS(k2469,(LP) 32,LREF(k2470));
MAKE_CONS(k2468,(LP) 16,LREF(k2469));
extern SYMBOL s_key_LENGTH; 
extern SYMBOL s_key_INDEX; 
extern SYMBOL s_xlib__25BUFFER; 
extern SYMBOL s_xlib_DISPLAY; 
MAKE_CONS(k2475,LREF(s_xlib__25BUFFER),LREF(s_lsp_NIL));
MAKE_CONS(k2474,LREF(s_xlib_DISPLAY),LREF(k2475));
MAKE_CONS(k2473,LREF(s_lsp_TYPE),LREF(k2474));
MAKE_CONS(k2472,LREF(k2473),LREF(s_lsp_NIL));
MAKE_CONS(k2471,LREF(s_lsp_DECLARE),LREF(k2472));
extern SYMBOL s_xlib_DECLARE_2DBUFMAC; 
extern SYMBOL s_lsp_WHEN; 
extern SYMBOL s_xlib_INDEX_3E_3D; 
MAKE_CONS(k2476,LREF(s_xlib_BUFFER_2DBOFFSET),LREF(k2475));
extern SYMBOL s_xlib_BUFFER_2DSIZE; 
MAKE_CONS(k2478,LREF(s_xlib_BUFFER_2DSIZE),LREF(k2475));
MAKE_CONS(k2477,LREF(k2478),LREF(s_lsp_NIL));
extern SYMBOL s_xlib_BUFFER_2DFLUSH; 
MAKE_CONS(k2480,LREF(s_xlib_BUFFER_2DFLUSH),LREF(k2475));
MAKE_CONS(k2479,LREF(k2480),LREF(s_lsp_NIL));
extern SYMBOL s_lsp_LET_2A; 
extern SYMBOL s_xlib_BUFFER_2DOBUF8; 
MAKE_CONS(k2484,LREF(s_xlib_BUFFER_2DOBUF8),LREF(k2475));
MAKE_CONS(k2483,LREF(k2484),LREF(s_lsp_NIL));
MAKE_CONS(k2482,LREF(s_xlib_BUFFER_2DBBUF),LREF(k2483));
MAKE_CONS(k2481,LREF(k2482),LREF(s_lsp_NIL));
MAKE_CONS(k2489,LREF(s_xlib_BUFFER_2DBOFFSET),LREF(s_lsp_NIL));
MAKE_CONS(k2488,LREF(s_xlib_ARRAY_2DINDEX),LREF(k2489));
MAKE_CONS(k2487,LREF(s_lsp_TYPE),LREF(k2488));
MAKE_CONS(k2486,LREF(k2487),LREF(s_lsp_NIL));
MAKE_CONS(k2485,LREF(s_lsp_DECLARE),LREF(k2486));
extern SYMBOL s_xlib_BUFFER_2DBYTES; 
MAKE_CONS(k2494,LREF(s_xlib_BUFFER_2DBBUF),LREF(s_lsp_NIL));
MAKE_CONS(k2493,LREF(s_xlib_BUFFER_2DBYTES),LREF(k2494));
MAKE_CONS(k2492,LREF(s_lsp_TYPE),LREF(k2493));
extern SYMBOL s_xlib_ARRAY_2DREGISTER; 
MAKE_CONS(k2496,LREF(s_xlib_ARRAY_2DREGISTER),LREF(k2494));
MAKE_CONS(k2495,LREF(k2496),LREF(s_lsp_NIL));
MAKE_CONS(k2491,LREF(k2492),LREF(k2495));
MAKE_CONS(k2490,LREF(s_lsp_DECLARE),LREF(k2491));
extern LP m_xlib_WRITING_2DBUFFER_2DCHUNKS();
extern SYMBOL s_lsp_LENGTH; 
MAKE_SIMPLE_STRING(k2497,48,"writing-buffer-chunks called with too many forms");
extern SYMBOL s_lsp_ERROR; 
extern SYMBOL s_xlib_INDEX_2DINCREMENT; 
extern SYMBOL s_xlib_WITH_2DBUFFER_2DOUTPUT; 
extern SYMBOL s_xlib_BUFFER; 
extern SYMBOL s_xlib_BOFFSET; 
extern SYMBOL s_lsp_ADJOIN; 
extern SYMBOL s_lsp_REVERSE; 
extern SYMBOL s_lsp_DO_2A; 
extern SYMBOL s_xlib_LEN; 
extern SYMBOL s_xlib_INDEX_2D; 
extern SYMBOL s_xlib_END; 
extern SYMBOL s_xlib_START; 
MAKE_CONS(k2500,LREF(s_xlib_START),LREF(s_lsp_NIL));
MAKE_CONS(k2499,LREF(s_xlib_END),LREF(k2500));
MAKE_CONS(k2498,LREF(s_xlib_INDEX_2D),LREF(k2499));
extern SYMBOL s_lsp_TRUNCATE_2F2; 
extern SYMBOL s_xlib_INDEX_2DASH; 
extern SYMBOL s_xlib_CHUNK; 
MAKE_CONS(k2504,LREF(s_xlib_CHUNK),LREF(s_lsp_NIL));
MAKE_CONS(k2503,LREF(s_xlib_LEN),LREF(k2504));
MAKE_CONS(k2502,LREF(s_xlib_INDEX_2D),LREF(k2503));
MAKE_CONS(k2501,LREF(k2502),LREF(s_lsp_NIL));
extern SYMBOL s_xlib_INDEX_2DMIN; 
MAKE_CONS(k2514,LREF(s_xlib_BUFFER),LREF(s_lsp_NIL));
MAKE_CONS(k2513,LREF(s_xlib_BUFFER_2DSIZE),LREF(k2514));
MAKE_CONS(k2512,LREF(k2513),LREF(k2489));
MAKE_CONS(k2511,LREF(s_xlib_INDEX_2D),LREF(k2512));
MAKE_CONS(k2510,LREF(k2511),LREF(s_lsp_NIL));
MAKE_CONS(k2509,LREF(s_xlib_LEN),LREF(k2510));
MAKE_CONS(k2508,LREF(s_xlib_INDEX_2DMIN),LREF(k2509));
MAKE_CONS(k2515,LREF(k2508),LREF(s_lsp_NIL));
MAKE_CONS(k2507,LREF(k2508),LREF(k2515));
MAKE_CONS(k2506,LREF(s_xlib_CHUNK),LREF(k2507));
MAKE_CONS(k2505,LREF(k2506),LREF(s_lsp_NIL));
extern SYMBOL s_lsp_APPEND_2F2; 
extern SYMBOL s_lsp_NOT; 
extern SYMBOL s_xlib_INDEX_2DPLUSP; 
MAKE_CONS(k2520,LREF(s_xlib_LEN),LREF(s_lsp_NIL));
MAKE_CONS(k2519,LREF(s_xlib_INDEX_2DPLUSP),LREF(k2520));
MAKE_CONS(k2518,LREF(k2519),LREF(s_lsp_NIL));
MAKE_CONS(k2517,LREF(s_lsp_NOT),LREF(k2518));
MAKE_CONS(k2516,LREF(k2517),LREF(s_lsp_NIL));
MAKE_CONS(k2523,LREF(s_xlib_ARRAY_2DINDEX),LREF(k2503));
MAKE_CONS(k2522,LREF(s_lsp_TYPE),LREF(k2523));
MAKE_CONS(k2521,LREF(k2522),LREF(s_lsp_NIL));
extern SYMBOL s_xlib_INDEX_2DINCF; 
MAKE_CONS(k2526,LREF(s_xlib_BUFFER_2DBOFFSET),LREF(k2504));
MAKE_CONS(k2525,LREF(s_xlib_INDEX_2DINCF),LREF(k2526));
extern SYMBOL s_lsp_AND; 
MAKE_CONS(k2535,LREF(k2513),LREF(s_lsp_NIL));
MAKE_CONS(k2534,LREF(s_xlib_BUFFER_2DBOFFSET),LREF(k2535));
MAKE_CONS(k2533,LREF(s_xlib_INDEX_3E_3D),LREF(k2534));
MAKE_CONS(k2532,LREF(k2533),LREF(s_lsp_NIL));
MAKE_CONS(k2531,LREF(k2519),LREF(k2532));
MAKE_CONS(k2530,LREF(s_lsp_AND),LREF(k2531));
extern SYMBOL s_lsp_SETF; 
MAKE_CONS(k2539,LREF(s_xlib_BUFFER_2DBOFFSET),LREF(k2514));
MAKE_CONS(k2538,LREF(k2539),LREF(k2489));
MAKE_CONS(k2537,LREF(s_lsp_SETF),LREF(k2538));
MAKE_CONS(k2541,LREF(s_xlib_BUFFER_2DFLUSH),LREF(k2514));
MAKE_CONS(k2545,LREF(k2539),LREF(s_lsp_NIL));
MAKE_CONS(k2544,LREF(s_xlib_BUFFER_2DBOFFSET),LREF(k2545));
MAKE_CONS(k2543,LREF(s_lsp_SETQ),LREF(k2544));
MAKE_CONS(k2542,LREF(k2543),LREF(s_lsp_NIL));
MAKE_CONS(k2540,LREF(k2541),LREF(k2542));
MAKE_CONS(k2536,LREF(k2537),LREF(k2540));
MAKE_CONS(k2529,LREF(k2530),LREF(k2536));
MAKE_CONS(k2528,LREF(s_lsp_WHEN),LREF(k2529));
MAKE_CONS(k2527,LREF(k2528),LREF(s_lsp_NIL));
MAKE_CONS(k2524,LREF(k2525),LREF(k2527));
extern SYMBOL s_xlib_LROUND; 
MAKE_CONS(k2550,LREF(s_xlib_LROUND),LREF(k2489));
MAKE_CONS(k2549,LREF(k2550),LREF(s_lsp_NIL));
MAKE_CONS(k2548,LREF(k2539),LREF(k2549));
MAKE_CONS(k2547,LREF(s_lsp_SETF),LREF(k2548));
MAKE_CONS(k2546,LREF(k2547),LREF(s_lsp_NIL));
extern LP p_xlib_BUFMAC_5FINIT172();
extern SYMBOL s_xlib_WRITE_2DCARD8; 
extern SYMBOL s_lsp_DEFINE_2DMACRO; 
extern SYMBOL s_xlib_WRITE_2DINT8; 
extern SYMBOL s_xlib_WRITE_2DCARD16; 
extern SYMBOL s_xlib_WRITE_2DINT16; 
extern SYMBOL s_xlib_WRITE_2DCARD32; 
extern SYMBOL s_xlib_WRITE_2DINT32; 
extern SYMBOL s_xlib_WRITE_2DCARD29; 
extern SYMBOL s_xlib_WRITE_2DCHAR2B; 
extern SYMBOL s_xlib_ADVANCE_2DBUFFER_2DOFFSET; 
extern SYMBOL s_xlib_WRITING_2DBUFFER_2DCHUNKS; 


extern LP num_equal_p();
extern LP multiply();
extern LP greaterp();
extern LP c_cons();


LP m_xlib_WRITE_2DCARD8(argc, v_WHOLE5013_0, v_ENV5014_1)
      ARGC argc;  LP v_WHOLE5013_0; LP v_ENV5014_1;
{
LP v_Y_38; LP v_X_37; LP v_Y_35; 
LP v_X_34; LP v_Y_32; LP v_X_31; 
LP v_Y_29; LP v_X_28; LP v_Y_26; 
LP v_X_25; LP v_Y_23; LP v_X_22; 
LP v_ITEM_21; LP v_S5028_20; LP v_X_18; 
LP v_VALUE5027_17; LP v_X_15; LP v_LIST5026_14; 
LP v_BYTE_2DINDEX_13; LP v_S5025_12; LP v_X_10; 
LP v_VALUE5024_9; LP v_X_7; LP v_LIST5023_6; 
LP v_L5022_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE5013_0;
v_L5022_5 = ((LP) DEREF((v_WHOLE5013_0) + 1 * 4));
v_LIST5023_6 = v_L5022_5;
v_X_7 = v_LIST5023_6;
v_VALUE5024_9 = ((LP) DEREF((v_LIST5023_6) + 0 * 4));
v_X_10 = v_LIST5023_6;
v_S5025_12 = ((LP) DEREF((v_LIST5023_6) + 1 * 4));
v_L5022_5 = v_S5025_12;
v_BYTE_2DINDEX_13 = v_VALUE5024_9;
v_LIST5026_14 = v_L5022_5;
v_X_15 = v_LIST5026_14;
v_VALUE5027_17 = ((LP) DEREF((v_LIST5026_14) + 0 * 4));
v_X_18 = v_LIST5026_14;
v_S5028_20 = ((LP) DEREF((v_LIST5026_14) + 1 * 4));
v_L5022_5 = v_S5028_20;
v_ITEM_21 = v_VALUE5027_17;
v_X_22 = v_ITEM_21;
v_Y_23 = LREF(s_lsp_NIL);
v_Y_26 = (c_cons((v_ITEM_21), (LREF(s_lsp_NIL))));
v_Y_29 = (c_cons((LREF(s_xlib_CARD8)), (v_Y_26)));
t1 = (c_cons((LREF(s_lsp_THE)), (v_Y_29)));
v_X_31 = v_BYTE_2DINDEX_13;
v_Y_32 = LREF(s_lsp_NIL);
v_Y_35 = (c_cons((v_BYTE_2DINDEX_13), (LREF(s_lsp_NIL))));
v_Y_38 = (c_cons((LREF(s_xlib_BUFFER_2DBOFFSET)), (v_Y_35)));
t2 = (c_cons((LREF(s_xlib_INDEX_2B)), (v_Y_38)));
t0 = ICALL(s_lsp_LIST) (MV_CALL(argc,4), LREF(s_xlib_ASET_2DCARD8), t1, LREF(s_xlib_BUFFER_2DBBUF), t2);
return(t0);
}

LP m_xlib_WRITE_2DINT8(argc, v_WHOLE5029_0, v_ENV5030_1)
      ARGC argc;  LP v_WHOLE5029_0; LP v_ENV5030_1;
{
LP v_Y_38; LP v_X_37; LP v_Y_35; 
LP v_X_34; LP v_Y_32; LP v_X_31; 
LP v_Y_29; LP v_X_28; LP v_Y_26; 
LP v_X_25; LP v_Y_23; LP v_X_22; 
LP v_ITEM_21; LP v_S5044_20; LP v_X_18; 
LP v_VALUE5043_17; LP v_X_15; LP v_LIST5042_14; 
LP v_BYTE_2DINDEX_13; LP v_S5041_12; LP v_X_10; 
LP v_VALUE5040_9; LP v_X_7; LP v_LIST5039_6; 
LP v_L5038_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE5029_0;
v_L5038_5 = ((LP) DEREF((v_WHOLE5029_0) + 1 * 4));
v_LIST5039_6 = v_L5038_5;
v_X_7 = v_LIST5039_6;
v_VALUE5040_9 = ((LP) DEREF((v_LIST5039_6) + 0 * 4));
v_X_10 = v_LIST5039_6;
v_S5041_12 = ((LP) DEREF((v_LIST5039_6) + 1 * 4));
v_L5038_5 = v_S5041_12;
v_BYTE_2DINDEX_13 = v_VALUE5040_9;
v_LIST5042_14 = v_L5038_5;
v_X_15 = v_LIST5042_14;
v_VALUE5043_17 = ((LP) DEREF((v_LIST5042_14) + 0 * 4));
v_X_18 = v_LIST5042_14;
v_S5044_20 = ((LP) DEREF((v_LIST5042_14) + 1 * 4));
v_L5038_5 = v_S5044_20;
v_ITEM_21 = v_VALUE5043_17;
v_X_22 = v_ITEM_21;
v_Y_23 = LREF(s_lsp_NIL);
v_Y_26 = (c_cons((v_ITEM_21), (LREF(s_lsp_NIL))));
v_Y_29 = (c_cons((LREF(s_xlib_INT8)), (v_Y_26)));
t1 = (c_cons((LREF(s_lsp_THE)), (v_Y_29)));
v_X_31 = v_BYTE_2DINDEX_13;
v_Y_32 = LREF(s_lsp_NIL);
v_Y_35 = (c_cons((v_BYTE_2DINDEX_13), (LREF(s_lsp_NIL))));
v_Y_38 = (c_cons((LREF(s_xlib_BUFFER_2DBOFFSET)), (v_Y_35)));
t2 = (c_cons((LREF(s_xlib_INDEX_2B)), (v_Y_38)));
t0 = ICALL(s_lsp_LIST) (MV_CALL(argc,4), LREF(s_xlib_ASET_2DINT8), t1, LREF(s_xlib_BUFFER_2DBBUF), t2);
return(t0);
}

LP m_xlib_WRITE_2DCARD16(argc, v_WHOLE5045_0, v_ENV5046_1)
      ARGC argc;  LP v_WHOLE5045_0; LP v_ENV5046_1;
{
LP v_Y_38; LP v_X_37; LP v_Y_35; 
LP v_X_34; LP v_Y_32; LP v_X_31; 
LP v_Y_29; LP v_X_28; LP v_Y_26; 
LP v_X_25; LP v_Y_23; LP v_X_22; 
LP v_ITEM_21; LP v_S5060_20; LP v_X_18; 
LP v_VALUE5059_17; LP v_X_15; LP v_LIST5058_14; 
LP v_BYTE_2DINDEX_13; LP v_S5057_12; LP v_X_10; 
LP v_VALUE5056_9; LP v_X_7; LP v_LIST5055_6; 
LP v_L5054_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE5045_0;
v_L5054_5 = ((LP) DEREF((v_WHOLE5045_0) + 1 * 4));
v_LIST5055_6 = v_L5054_5;
v_X_7 = v_LIST5055_6;
v_VALUE5056_9 = ((LP) DEREF((v_LIST5055_6) + 0 * 4));
v_X_10 = v_LIST5055_6;
v_S5057_12 = ((LP) DEREF((v_LIST5055_6) + 1 * 4));
v_L5054_5 = v_S5057_12;
v_BYTE_2DINDEX_13 = v_VALUE5056_9;
v_LIST5058_14 = v_L5054_5;
v_X_15 = v_LIST5058_14;
v_VALUE5059_17 = ((LP) DEREF((v_LIST5058_14) + 0 * 4));
v_X_18 = v_LIST5058_14;
v_S5060_20 = ((LP) DEREF((v_LIST5058_14) + 1 * 4));
v_L5054_5 = v_S5060_20;
v_ITEM_21 = v_VALUE5059_17;
v_X_22 = v_ITEM_21;
v_Y_23 = LREF(s_lsp_NIL);
v_Y_26 = (c_cons((v_ITEM_21), (LREF(s_lsp_NIL))));
v_Y_29 = (c_cons((LREF(s_xlib_CARD16)), (v_Y_26)));
t1 = (c_cons((LREF(s_lsp_THE)), (v_Y_29)));
v_X_31 = v_BYTE_2DINDEX_13;
v_Y_32 = LREF(s_lsp_NIL);
v_Y_35 = (c_cons((v_BYTE_2DINDEX_13), (LREF(s_lsp_NIL))));
v_Y_38 = (c_cons((LREF(s_xlib_BUFFER_2DBOFFSET)), (v_Y_35)));
t2 = (c_cons((LREF(s_xlib_INDEX_2B)), (v_Y_38)));
t0 = ICALL(s_lsp_LIST) (MV_CALL(argc,4), LREF(s_xlib_ASET_2DCARD16), t1, LREF(s_xlib_BUFFER_2DBBUF), t2);
return(t0);
}

LP m_xlib_WRITE_2DINT16(argc, v_WHOLE5061_0, v_ENV5062_1)
      ARGC argc;  LP v_WHOLE5061_0; LP v_ENV5062_1;
{
LP v_Y_38; LP v_X_37; LP v_Y_35; 
LP v_X_34; LP v_Y_32; LP v_X_31; 
LP v_Y_29; LP v_X_28; LP v_Y_26; 
LP v_X_25; LP v_Y_23; LP v_X_22; 
LP v_ITEM_21; LP v_S5076_20; LP v_X_18; 
LP v_VALUE5075_17; LP v_X_15; LP v_LIST5074_14; 
LP v_BYTE_2DINDEX_13; LP v_S5073_12; LP v_X_10; 
LP v_VALUE5072_9; LP v_X_7; LP v_LIST5071_6; 
LP v_L5070_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE5061_0;
v_L5070_5 = ((LP) DEREF((v_WHOLE5061_0) + 1 * 4));
v_LIST5071_6 = v_L5070_5;
v_X_7 = v_LIST5071_6;
v_VALUE5072_9 = ((LP) DEREF((v_LIST5071_6) + 0 * 4));
v_X_10 = v_LIST5071_6;
v_S5073_12 = ((LP) DEREF((v_LIST5071_6) + 1 * 4));
v_L5070_5 = v_S5073_12;
v_BYTE_2DINDEX_13 = v_VALUE5072_9;
v_LIST5074_14 = v_L5070_5;
v_X_15 = v_LIST5074_14;
v_VALUE5075_17 = ((LP) DEREF((v_LIST5074_14) + 0 * 4));
v_X_18 = v_LIST5074_14;
v_S5076_20 = ((LP) DEREF((v_LIST5074_14) + 1 * 4));
v_L5070_5 = v_S5076_20;
v_ITEM_21 = v_VALUE5075_17;
v_X_22 = v_ITEM_21;
v_Y_23 = LREF(s_lsp_NIL);
v_Y_26 = (c_cons((v_ITEM_21), (LREF(s_lsp_NIL))));
v_Y_29 = (c_cons((LREF(s_xlib_INT16)), (v_Y_26)));
t1 = (c_cons((LREF(s_lsp_THE)), (v_Y_29)));
v_X_31 = v_BYTE_2DINDEX_13;
v_Y_32 = LREF(s_lsp_NIL);
v_Y_35 = (c_cons((v_BYTE_2DINDEX_13), (LREF(s_lsp_NIL))));
v_Y_38 = (c_cons((LREF(s_xlib_BUFFER_2DBOFFSET)), (v_Y_35)));
t2 = (c_cons((LREF(s_xlib_INDEX_2B)), (v_Y_38)));
t0 = ICALL(s_lsp_LIST) (MV_CALL(argc,4), LREF(s_xlib_ASET_2DINT16), t1, LREF(s_xlib_BUFFER_2DBBUF), t2);
return(t0);
}

LP m_xlib_WRITE_2DCARD32(argc, v_WHOLE5077_0, v_ENV5078_1)
      ARGC argc;  LP v_WHOLE5077_0; LP v_ENV5078_1;
{
LP v_Y_38; LP v_X_37; LP v_Y_35; 
LP v_X_34; LP v_Y_32; LP v_X_31; 
LP v_Y_29; LP v_X_28; LP v_Y_26; 
LP v_X_25; LP v_Y_23; LP v_X_22; 
LP v_ITEM_21; LP v_S5092_20; LP v_X_18; 
LP v_VALUE5091_17; LP v_X_15; LP v_LIST5090_14; 
LP v_BYTE_2DINDEX_13; LP v_S5089_12; LP v_X_10; 
LP v_VALUE5088_9; LP v_X_7; LP v_LIST5087_6; 
LP v_L5086_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE5077_0;
v_L5086_5 = ((LP) DEREF((v_WHOLE5077_0) + 1 * 4));
v_LIST5087_6 = v_L5086_5;
v_X_7 = v_LIST5087_6;
v_VALUE5088_9 = ((LP) DEREF((v_LIST5087_6) + 0 * 4));
v_X_10 = v_LIST5087_6;
v_S5089_12 = ((LP) DEREF((v_LIST5087_6) + 1 * 4));
v_L5086_5 = v_S5089_12;
v_BYTE_2DINDEX_13 = v_VALUE5088_9;
v_LIST5090_14 = v_L5086_5;
v_X_15 = v_LIST5090_14;
v_VALUE5091_17 = ((LP) DEREF((v_LIST5090_14) + 0 * 4));
v_X_18 = v_LIST5090_14;
v_S5092_20 = ((LP) DEREF((v_LIST5090_14) + 1 * 4));
v_L5086_5 = v_S5092_20;
v_ITEM_21 = v_VALUE5091_17;
v_X_22 = v_ITEM_21;
v_Y_23 = LREF(s_lsp_NIL);
v_Y_26 = (c_cons((v_ITEM_21), (LREF(s_lsp_NIL))));
v_Y_29 = (c_cons((LREF(s_xlib_CARD32)), (v_Y_26)));
t1 = (c_cons((LREF(s_lsp_THE)), (v_Y_29)));
v_X_31 = v_BYTE_2DINDEX_13;
v_Y_32 = LREF(s_lsp_NIL);
v_Y_35 = (c_cons((v_BYTE_2DINDEX_13), (LREF(s_lsp_NIL))));
v_Y_38 = (c_cons((LREF(s_xlib_BUFFER_2DBOFFSET)), (v_Y_35)));
t2 = (c_cons((LREF(s_xlib_INDEX_2B)), (v_Y_38)));
t0 = ICALL(s_lsp_LIST) (MV_CALL(argc,4), LREF(s_xlib_ASET_2DCARD32), t1, LREF(s_xlib_BUFFER_2DBBUF), t2);
return(t0);
}

LP m_xlib_WRITE_2DINT32(argc, v_WHOLE5093_0, v_ENV5094_1)
      ARGC argc;  LP v_WHOLE5093_0; LP v_ENV5094_1;
{
LP v_Y_38; LP v_X_37; LP v_Y_35; 
LP v_X_34; LP v_Y_32; LP v_X_31; 
LP v_Y_29; LP v_X_28; LP v_Y_26; 
LP v_X_25; LP v_Y_23; LP v_X_22; 
LP v_ITEM_21; LP v_S5108_20; LP v_X_18; 
LP v_VALUE5107_17; LP v_X_15; LP v_LIST5106_14; 
LP v_BYTE_2DINDEX_13; LP v_S5105_12; LP v_X_10; 
LP v_VALUE5104_9; LP v_X_7; LP v_LIST5103_6; 
LP v_L5102_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE5093_0;
v_L5102_5 = ((LP) DEREF((v_WHOLE5093_0) + 1 * 4));
v_LIST5103_6 = v_L5102_5;
v_X_7 = v_LIST5103_6;
v_VALUE5104_9 = ((LP) DEREF((v_LIST5103_6) + 0 * 4));
v_X_10 = v_LIST5103_6;
v_S5105_12 = ((LP) DEREF((v_LIST5103_6) + 1 * 4));
v_L5102_5 = v_S5105_12;
v_BYTE_2DINDEX_13 = v_VALUE5104_9;
v_LIST5106_14 = v_L5102_5;
v_X_15 = v_LIST5106_14;
v_VALUE5107_17 = ((LP) DEREF((v_LIST5106_14) + 0 * 4));
v_X_18 = v_LIST5106_14;
v_S5108_20 = ((LP) DEREF((v_LIST5106_14) + 1 * 4));
v_L5102_5 = v_S5108_20;
v_ITEM_21 = v_VALUE5107_17;
v_X_22 = v_ITEM_21;
v_Y_23 = LREF(s_lsp_NIL);
v_Y_26 = (c_cons((v_ITEM_21), (LREF(s_lsp_NIL))));
v_Y_29 = (c_cons((LREF(s_xlib_INT32)), (v_Y_26)));
t1 = (c_cons((LREF(s_lsp_THE)), (v_Y_29)));
v_X_31 = v_BYTE_2DINDEX_13;
v_Y_32 = LREF(s_lsp_NIL);
v_Y_35 = (c_cons((v_BYTE_2DINDEX_13), (LREF(s_lsp_NIL))));
v_Y_38 = (c_cons((LREF(s_xlib_BUFFER_2DBOFFSET)), (v_Y_35)));
t2 = (c_cons((LREF(s_xlib_INDEX_2B)), (v_Y_38)));
t0 = ICALL(s_lsp_LIST) (MV_CALL(argc,4), LREF(s_xlib_ASET_2DINT32), t1, LREF(s_xlib_BUFFER_2DBBUF), t2);
return(t0);
}

LP m_xlib_WRITE_2DCARD29(argc, v_WHOLE5109_0, v_ENV5110_1)
      ARGC argc;  LP v_WHOLE5109_0; LP v_ENV5110_1;
{
LP v_Y_38; LP v_X_37; LP v_Y_35; 
LP v_X_34; LP v_Y_32; LP v_X_31; 
LP v_Y_29; LP v_X_28; LP v_Y_26; 
LP v_X_25; LP v_Y_23; LP v_X_22; 
LP v_ITEM_21; LP v_S5124_20; LP v_X_18; 
LP v_VALUE5123_17; LP v_X_15; LP v_LIST5122_14; 
LP v_BYTE_2DINDEX_13; LP v_S5121_12; LP v_X_10; 
LP v_VALUE5120_9; LP v_X_7; LP v_LIST5119_6; 
LP v_L5118_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE5109_0;
v_L5118_5 = ((LP) DEREF((v_WHOLE5109_0) + 1 * 4));
v_LIST5119_6 = v_L5118_5;
v_X_7 = v_LIST5119_6;
v_VALUE5120_9 = ((LP) DEREF((v_LIST5119_6) + 0 * 4));
v_X_10 = v_LIST5119_6;
v_S5121_12 = ((LP) DEREF((v_LIST5119_6) + 1 * 4));
v_L5118_5 = v_S5121_12;
v_BYTE_2DINDEX_13 = v_VALUE5120_9;
v_LIST5122_14 = v_L5118_5;
v_X_15 = v_LIST5122_14;
v_VALUE5123_17 = ((LP) DEREF((v_LIST5122_14) + 0 * 4));
v_X_18 = v_LIST5122_14;
v_S5124_20 = ((LP) DEREF((v_LIST5122_14) + 1 * 4));
v_L5118_5 = v_S5124_20;
v_ITEM_21 = v_VALUE5123_17;
v_X_22 = v_ITEM_21;
v_Y_23 = LREF(s_lsp_NIL);
v_Y_26 = (c_cons((v_ITEM_21), (LREF(s_lsp_NIL))));
v_Y_29 = (c_cons((LREF(s_xlib_CARD29)), (v_Y_26)));
t1 = (c_cons((LREF(s_lsp_THE)), (v_Y_29)));
v_X_31 = v_BYTE_2DINDEX_13;
v_Y_32 = LREF(s_lsp_NIL);
v_Y_35 = (c_cons((v_BYTE_2DINDEX_13), (LREF(s_lsp_NIL))));
v_Y_38 = (c_cons((LREF(s_xlib_BUFFER_2DBOFFSET)), (v_Y_35)));
t2 = (c_cons((LREF(s_xlib_INDEX_2B)), (v_Y_38)));
t0 = ICALL(s_lsp_LIST) (MV_CALL(argc,4), LREF(s_xlib_ASET_2DCARD29), t1, LREF(s_xlib_BUFFER_2DBBUF), t2);
return(t0);
}

LP m_xlib_WRITE_2DCHAR2B(argc, v_WHOLE5125_0, v_ENV5126_1)
      ARGC argc;  LP v_WHOLE5125_0; LP v_ENV5126_1;
{
LP v_Y_47; LP v_X_46; LP v_Y_44; 
LP v_X_43; LP v_Y_41; LP v_X_40; 
LP v_Y_38; LP v_X_37; LP v_Y_35; 
LP v_X_34; LP v_Y_32; LP v_X_31; 
LP v_Y_29; LP v_X_28; LP v_Y_26; 
LP v_X_25; LP v_Y_23; LP v_X_22; 
LP v_ITEM_21; LP v_S5140_20; LP v_X_18; 
LP v_VALUE5139_17; LP v_X_15; LP v_LIST5138_14; 
LP v_BYTE_2DINDEX_13; LP v_S5137_12; LP v_X_10; 
LP v_VALUE5136_9; LP v_X_7; LP v_LIST5135_6; 
LP v_L5134_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE5125_0;
v_L5134_5 = ((LP) DEREF((v_WHOLE5125_0) + 1 * 4));
v_LIST5135_6 = v_L5134_5;
v_X_7 = v_LIST5135_6;
v_VALUE5136_9 = ((LP) DEREF((v_LIST5135_6) + 0 * 4));
v_X_10 = v_LIST5135_6;
v_S5137_12 = ((LP) DEREF((v_LIST5135_6) + 1 * 4));
v_L5134_5 = v_S5137_12;
v_BYTE_2DINDEX_13 = v_VALUE5136_9;
v_LIST5138_14 = v_L5134_5;
v_X_15 = v_LIST5138_14;
v_VALUE5139_17 = ((LP) DEREF((v_LIST5138_14) + 0 * 4));
v_X_18 = v_LIST5138_14;
v_S5140_20 = ((LP) DEREF((v_LIST5138_14) + 1 * 4));
v_L5134_5 = v_S5140_20;
v_ITEM_21 = v_VALUE5139_17;
v_X_22 = v_ITEM_21;
v_Y_23 = LREF(s_lsp_NIL);
v_Y_26 = (c_cons((v_ITEM_21), (LREF(s_lsp_NIL))));
v_X_46 = (c_cons((LREF(s_xlib__25ITEM)), (v_Y_26)));
v_X_28 = v_BYTE_2DINDEX_13;
v_Y_29 = LREF(s_lsp_NIL);
v_Y_32 = (c_cons((v_BYTE_2DINDEX_13), (LREF(s_lsp_NIL))));
v_Y_35 = (c_cons((LREF(s_xlib_BUFFER_2DBOFFSET)), (v_Y_32)));
v_X_37 = (c_cons((LREF(s_xlib_INDEX_2B)), (v_Y_35)));
v_Y_41 = (c_cons((v_X_37), (LREF(s_lsp_NIL))));
v_X_43 = (c_cons((LREF(s_xlib__25BYTE_2DINDEX)), (v_Y_41)));
v_Y_47 = (c_cons((v_X_43), (LREF(s_lsp_NIL))));
t1 = (c_cons((v_X_46), (v_Y_47)));
t0 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,3), LREF(s_lsp_LET), t1, LREF(k2419));
return(t0);
}

LP m_xlib_SET_2DBUFFER_2DOFFSET(argc, v_WHOLE5141_0, v_ENV_1)
      ARGC argc;  LP v_WHOLE5141_0; LP v_ENV_1;
{
LP v_Y_21; LP v_X_20; LP v_Y_18; 
LP v_X_17; LP v_Y_15; LP v_X_14; 
LP v_VALUE_13; LP v_S5149_12; LP v_X_10; 
LP v_VALUE5148_9; LP v_X_7; LP v_LIST5147_6; 
LP v_L5146_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE5141_0;
v_L5146_5 = ((LP) DEREF((v_WHOLE5141_0) + 1 * 4));
v_LIST5147_6 = v_L5146_5;
v_X_7 = v_LIST5147_6;
v_VALUE5148_9 = ((LP) DEREF((v_LIST5147_6) + 0 * 4));
v_X_10 = v_LIST5147_6;
v_S5149_12 = ((LP) DEREF((v_LIST5147_6) + 1 * 4));
v_L5146_5 = v_S5149_12;
v_VALUE_13 = v_VALUE5148_9;
v_X_14 = v_VALUE_13;
v_Y_15 = LREF(s_lsp_NIL);
v_Y_18 = (c_cons((v_VALUE_13), (LREF(s_lsp_NIL))));
v_X_20 = (c_cons((LREF(s_xlib__2EBOFFSET_2E)), (v_Y_18)));
t1 = (c_cons((v_X_20), (LREF(s_lsp_NIL))));
t0 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,3), LREF(s_lsp_LET), t1, LREF(k2457));
return(t0);
}

LP m_xlib_ADVANCE_2DBUFFER_2DOFFSET(argc, v_WHOLE5150_0, v_ENV5151_1)
      ARGC argc;  LP v_WHOLE5150_0; LP v_ENV5151_1;
{
LP v_Y_27; LP v_X_26; LP v_Y_24; 
LP v_X_23; LP v_Y_21; LP v_X_20; 
LP v_Y_18; LP v_X_17; LP v_Y_15; 
LP v_X_14; LP v_VALUE_13; LP v_S5159_12; 
LP v_X_10; LP v_VALUE5158_9; LP v_X_7; 
LP v_LIST5157_6; LP v_L5156_5; LP v_X_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE5150_0;
v_L5156_5 = ((LP) DEREF((v_WHOLE5150_0) + 1 * 4));
v_LIST5157_6 = v_L5156_5;
v_X_7 = v_LIST5157_6;
v_VALUE5158_9 = ((LP) DEREF((v_LIST5157_6) + 0 * 4));
v_X_10 = v_LIST5157_6;
v_S5159_12 = ((LP) DEREF((v_LIST5157_6) + 1 * 4));
v_L5156_5 = v_S5159_12;
v_VALUE_13 = v_VALUE5158_9;
v_X_14 = v_VALUE_13;
v_Y_15 = LREF(s_lsp_NIL);
v_Y_18 = (c_cons((v_VALUE_13), (LREF(s_lsp_NIL))));
v_Y_21 = (c_cons((LREF(s_xlib_BUFFER_2DBOFFSET)), (v_Y_18)));
v_X_23 = (c_cons((LREF(s_xlib_INDEX_2B)), (v_Y_21)));
v_Y_27 = (c_cons((v_X_23), (LREF(s_lsp_NIL))));
t0 = (c_cons((LREF(s_xlib_SET_2DBUFFER_2DOFFSET)), (v_Y_27)));
return(t0);
}

LP m_xlib_WITH_2DBUFFER_2DOUTPUT(argc, v_WHOLE5160_0, v_ENV5161_1)
      ARGC argc;  LP v_WHOLE5160_0; LP v_ENV5161_1;
{
LP v_BUFFER_21; LP v_S5178_20; LP v_X_18; 
LP v_VALUE5177_17; LP v_X_15; LP v_LIST5176_14; 
LP v_L5172_13; LP v_S5175_12; LP v_X_10; 
LP v_VALUE5174_9; LP v_X_7; LP v_LIST5173_6; 
LP v_L5171_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; 
if (argc != 2) wna(argc,2);
t0 = NEW_OE(2);
v_X_3 = v_WHOLE5160_0;
v_L5171_5 = ((LP) DEREF((v_WHOLE5160_0) + 1 * 4));
SET_OE_SLOT(t0,1,v_L5171_5);
v_LIST5173_6 = GET_OE_SLOT(t0,1);
v_X_7 = v_LIST5173_6;
v_VALUE5174_9 = ((LP) DEREF((v_LIST5173_6) + 0 * 4));
v_X_10 = v_LIST5173_6;
v_S5175_12 = ((LP) DEREF((v_LIST5173_6) + 1 * 4));
SET_OE_SLOT(t0,1,v_S5175_12);
v_L5172_13 = v_VALUE5174_9;
v_LIST5176_14 = v_L5172_13;
v_X_15 = v_LIST5176_14;
v_VALUE5177_17 = ((LP) DEREF((v_LIST5176_14) + 0 * 4));
v_X_18 = v_LIST5176_14;
v_S5178_20 = ((LP) DEREF((v_LIST5176_14) + 1 * 4));
v_L5172_13 = v_S5178_20;
v_BUFFER_21 = v_VALUE5177_17;
SET_OE_SLOT(t0,0,v_BUFFER_21);
t2 = MAKE_CLOSURE(p_xlib_WITH_2DBUFFER_2DOUTPUT_2Danon24662467,t0);
t1 = p_lsp_APPLY(MV_CALL(argc,2), COERCE_TO_FUNCTION(t2), v_L5172_13);
return(t1);
}

LP p_xlib_WITH_2DBUFFER_2DOUTPUT_2Danon24662467(va_alist) va_dcl
{
LP v_Y_53; LP v_X_52; LP v_Y_50; 
LP v_X_49; LP v_Y_47; LP v_X_46; 
LP v_Y_44; LP v_X_43; LP v_Y_41; 
LP v_X_40; LP v_Y_38; LP v_X_37; 
LP v_G5181_36; LP v_Y_34; LP v_X_33; 
LP v_Y_31; LP v_X_30; LP v_Y_28; 
LP v_X_27; LP v_Y_25; LP v_X_24; 
LP v_Y_22; LP v_X_21; LP v_Y_19; 
LP v_X_18; LP v_X_16; LP v_G5180_15; 
LP v_Y_13; LP v_X_12; LP v_X_10; 
LP v_X_8; LP v_Y_6; LP v_X_5; 
LP v_BODY_4; LP v_KEYS5179_3; LP v_INDEX_2; 
LP v_LENGTH_1; LP v_SIZES_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


t0 = OE;
real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
DYNAMIC_RESTIFY(v_KEYS5179_3,1,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_SIZES_0,LREF(s_key_SIZES),v_KEYS5179_3)
v_SIZES_0 = LREF(k2468);
END_KEY_INIT
BEGIN_KEY_INIT(v_LENGTH_1,LREF(s_key_LENGTH),v_KEYS5179_3)
v_LENGTH_1 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_INDEX_2,LREF(s_key_INDEX),v_KEYS5179_3)
v_INDEX_2 = NIL;
END_KEY_INIT
END_VAR_ARGS;
v_BODY_4 = GET_OE_SLOT(t0,1);
v_X_8 = v_SIZES_0;
v_X_10 = v_X_8;
v_X_12 = v_X_8;
v_Y_13 = LREF(s_lsp_NIL);
v_G5180_15 = (((v_X_8) == (LREF(s_lsp_NIL))) ? T : NIL);
if (v_G5180_15 != NIL) {
t1 = v_G5180_15;
} else {
v_X_16 = v_X_8;
t1 = (OTHER_PTRP((v_X_8)) && (TAG((v_X_8)) == 15) ? T : NIL);
}
if (t1 == NIL) {
v_X_5 = v_SIZES_0;
v_SIZES_0 = (c_cons((v_X_5), (LREF(s_lsp_NIL))));
}
v_X_18 = GET_OE_SLOT(t0,0);
v_Y_19 = LREF(s_lsp_NIL);
v_Y_22 = (c_cons((GET_OE_SLOT(t0,0)), (LREF(s_lsp_NIL))));
v_X_24 = (c_cons((LREF(s_xlib__25BUFFER)), (v_Y_22)));
t3 = (c_cons((v_X_24), (LREF(s_lsp_NIL))));
t4 = ICALL(s_xlib_DECLARE_2DBUFMAC) (0);
if (v_LENGTH_1 != NIL) {
v_X_27 = v_LENGTH_1;
v_Y_28 = LREF(s_lsp_NIL);
v_Y_31 = (c_cons((v_LENGTH_1), (LREF(s_lsp_NIL))));
v_Y_34 = (c_cons((LREF(k2476)), (v_Y_31)));
t7 = (c_cons((LREF(s_xlib_INDEX_2B)), (v_Y_34)));
t6 = ICALL(s_lsp_LIST_2A) (3, LREF(s_xlib_INDEX_3E_3D), t7, LREF(k2477));
t5 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_WHEN), t6, LREF(k2479));
} else {
t5 = LREF(s_lsp_NIL);
}
v_G5181_36 = v_INDEX_2;
if (v_G5181_36 != NIL) {
v_X_37 = v_G5181_36;
} else {
v_X_37 = LREF(k2476);
}
v_Y_41 = (c_cons((v_X_37), (LREF(s_lsp_NIL))));
v_Y_44 = (c_cons((LREF(s_xlib_ARRAY_2DINDEX)), (v_Y_41)));
v_X_46 = (c_cons((LREF(s_lsp_THE)), (v_Y_44)));
v_Y_50 = (c_cons((v_X_46), (LREF(s_lsp_NIL))));
v_X_52 = (c_cons((LREF(s_xlib_BUFFER_2DBOFFSET)), (v_Y_50)));
t9 = (c_cons((v_X_52), (LREF(k2481))));
t8 = ICALL(s_lsp_LIST_2A) (7, LREF(s_lsp_LET_2A), t9, LREF(k2485), LREF(k2490), LREF(s_xlib_BUFFER_2DBOFFSET), LREF(s_xlib_BUFFER_2DBBUF), v_BODY_4);
t2 = ICALL(s_lsp_LIST) (MV_CALL(argc,6), LREF(s_lsp_LET), t3, LREF(k2471), t4, t5, t8);
return(t2);
}

LP m_xlib_WRITING_2DBUFFER_2DCHUNKS(argc, v_WHOLE5182_0, v_ENV5183_1)
      ARGC argc;  LP v_WHOLE5182_0; LP v_ENV5183_1;
{
LP v_Y_55; LP v_X_54; LP v_Y_52; 
LP v_X_51; LP v_Y_49; LP v_X_48; 
LP v_Y_46; LP v_X_45; LP v_Y_43; 
LP v_X_42; LP v_DIVISOR_40; LP v_N_39; 
LP v_N_37; LP v_DIVISOR_38; LP v_FORM_36; 
LP v_X_34; LP v_LIST_32; LP v_SIZE_31; 
LP v_BODY_30; LP v_DECLS_29; LP v_S5203_28; 
LP v_X_26; LP v_VALUE5202_25; LP v_X_23; 
LP v_LIST5201_22; LP v_ARGS_21; LP v_S5200_20; 
LP v_X_18; LP v_VALUE5199_17; LP v_X_15; 
LP v_LIST5198_14; LP v_TYPE_13; LP v_S5197_12; 
LP v_X_10; LP v_VALUE5196_9; LP v_X_7; 
LP v_LIST5195_6; LP v_L5194_5; LP v_X_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE5182_0;
v_L5194_5 = ((LP) DEREF((v_WHOLE5182_0) + 1 * 4));
v_LIST5195_6 = v_L5194_5;
v_X_7 = v_LIST5195_6;
v_VALUE5196_9 = ((LP) DEREF((v_LIST5195_6) + 0 * 4));
v_X_10 = v_LIST5195_6;
v_S5197_12 = ((LP) DEREF((v_LIST5195_6) + 1 * 4));
v_L5194_5 = v_S5197_12;
v_TYPE_13 = v_VALUE5196_9;
v_LIST5198_14 = v_L5194_5;
v_X_15 = v_LIST5198_14;
v_VALUE5199_17 = ((LP) DEREF((v_LIST5198_14) + 0 * 4));
v_X_18 = v_LIST5198_14;
v_S5200_20 = ((LP) DEREF((v_LIST5198_14) + 1 * 4));
v_L5194_5 = v_S5200_20;
v_ARGS_21 = v_VALUE5199_17;
v_LIST5201_22 = v_L5194_5;
v_X_23 = v_LIST5201_22;
v_VALUE5202_25 = ((LP) DEREF((v_LIST5201_22) + 0 * 4));
v_X_26 = v_LIST5201_22;
v_S5203_28 = ((LP) DEREF((v_LIST5201_22) + 1 * 4));
v_L5194_5 = v_S5203_28;
v_DECLS_29 = v_VALUE5202_25;
v_BODY_30 = v_L5194_5;
t1 = ICALL(s_lsp_LENGTH) (1, v_BODY_30);
t0 = (greaterp((t1), ((LP) 4)));
if (t0 != NIL) {
ICALL(s_lsp_ERROR) (1, LREF(k2497));
}
t2 = ICALL(s_xlib_INDEX_2DINCREMENT) (1, v_TYPE_13);
v_SIZE_31 = (multiply(((LP) 16), (t2)));
v_LIST_32 = v_BODY_30;
v_X_34 = v_BODY_30;
v_FORM_36 = ((LP) DEREF((v_BODY_30) + 0 * 4));
t6 = ICALL(s_lsp_ADJOIN) (2, v_SIZE_31, LREF(k2439));
t5 = ICALL(s_lsp_REVERSE) (1, t6);
t4 = ICALL(s_lsp_LIST) (5, LREF(s_xlib_BUFFER), LREF(s_key_INDEX), LREF(s_xlib_BOFFSET), LREF(s_key_SIZES), t5);
t10 = (num_equal_p((v_SIZE_31), ((LP) 16)));
if (t10 != NIL) {
t9 = LREF(k2498);
} else {
v_N_39 = v_SIZE_31;
v_DIVISOR_40 = (LP) 32;
v_X_42 = ICALL(s_lsp_TRUNCATE_2F2) (2, v_SIZE_31, (LP) 32);
v_Y_46 = (c_cons((v_X_42), (LREF(s_lsp_NIL))));
v_Y_49 = (c_cons((LREF(k2498)), (v_Y_46)));
t9 = (c_cons((LREF(s_xlib_INDEX_2DASH)), (v_Y_49)));
}
v_X_51 = ICALL(s_lsp_LIST_2A) (3, LREF(s_xlib_LEN), t9, LREF(k2501));
t11 = (c_cons((v_X_51), (LREF(k2505))));
t8 = ICALL(s_lsp_APPEND_2F2) (2, v_ARGS_21, t11);
v_Y_55 = ICALL(s_lsp_APPEND_2F2) (2, v_DECLS_29, LREF(k2521));
t12 = (c_cons((LREF(s_lsp_DECLARE)), (v_Y_55)));
t7 = ICALL(s_lsp_LIST_2A) (6, LREF(s_lsp_DO_2A), t8, LREF(k2516), t12, v_FORM_36, LREF(k2524));
t3 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,4), LREF(s_xlib_WITH_2DBUFFER_2DOUTPUT), t4, t7, LREF(k2546));
return(t3);
}

LP p_xlib_BUFMAC_5FINIT172(argc)
      ARGC argc; 
{
LP v_X_23; LP v_X_21; LP v_X_19; 
LP v_X_17; LP v_X_15; LP v_X_13; 
LP v_X_11; LP v_X_9; LP v_X_7; 
LP v_X_5; LP v_X_3; LP v_X_1; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; 
if (argc != 0) wna(argc,0);
v_X_1 = LREF(s_xlib_WRITE_2DCARD8);
t0 = ((LP) DEREF((LREF(s_xlib_WRITE_2DCARD8)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_xlib_WRITE_2DCARD8), t0);
v_X_3 = LREF(s_xlib_WRITE_2DINT8);
t1 = ((LP) DEREF((LREF(s_xlib_WRITE_2DINT8)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_xlib_WRITE_2DINT8), t1);
v_X_5 = LREF(s_xlib_WRITE_2DCARD16);
t2 = ((LP) DEREF((LREF(s_xlib_WRITE_2DCARD16)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_xlib_WRITE_2DCARD16), t2);
v_X_7 = LREF(s_xlib_WRITE_2DINT16);
t3 = ((LP) DEREF((LREF(s_xlib_WRITE_2DINT16)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_xlib_WRITE_2DINT16), t3);
v_X_9 = LREF(s_xlib_WRITE_2DCARD32);
t4 = ((LP) DEREF((LREF(s_xlib_WRITE_2DCARD32)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_xlib_WRITE_2DCARD32), t4);
v_X_11 = LREF(s_xlib_WRITE_2DINT32);
t5 = ((LP) DEREF((LREF(s_xlib_WRITE_2DINT32)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_xlib_WRITE_2DINT32), t5);
v_X_13 = LREF(s_xlib_WRITE_2DCARD29);
t6 = ((LP) DEREF((LREF(s_xlib_WRITE_2DCARD29)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_xlib_WRITE_2DCARD29), t6);
v_X_15 = LREF(s_xlib_WRITE_2DCHAR2B);
t7 = ((LP) DEREF((LREF(s_xlib_WRITE_2DCHAR2B)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_xlib_WRITE_2DCHAR2B), t7);
v_X_17 = LREF(s_xlib_SET_2DBUFFER_2DOFFSET);
t8 = ((LP) DEREF((LREF(s_xlib_SET_2DBUFFER_2DOFFSET)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_xlib_SET_2DBUFFER_2DOFFSET), t8);
v_X_19 = LREF(s_xlib_ADVANCE_2DBUFFER_2DOFFSET);
t9 = ((LP) DEREF((LREF(s_xlib_ADVANCE_2DBUFFER_2DOFFSET)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_xlib_ADVANCE_2DBUFFER_2DOFFSET), t9);
v_X_21 = LREF(s_xlib_WITH_2DBUFFER_2DOUTPUT);
t10 = ((LP) DEREF((LREF(s_xlib_WITH_2DBUFFER_2DOUTPUT)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_xlib_WITH_2DBUFFER_2DOUTPUT), t10);
v_X_23 = LREF(s_xlib_WRITING_2DBUFFER_2DCHUNKS);
t12 = ((LP) DEREF((LREF(s_xlib_WRITING_2DBUFFER_2DCHUNKS)) + 4 * 4));
t11 = ICALL(s_lsp_DEFINE_2DMACRO) (MV_CALL(argc,2), LREF(s_xlib_WRITING_2DBUFFER_2DCHUNKS), t12);
return(t11);
}

