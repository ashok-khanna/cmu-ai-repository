/*
:comment "Compiled at 5:56:59 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: DEFAULT"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g  "
:version 0
:end-package-info 0
:sym PROBE-FILE
:sym FIND-ROOT-DIRECTORY
:sym *ROOT-DIRECTORY*
:sym :CL
:sym :CLX
:sym NIL
:sym *DEFAULT-LIBRARIES*
:sym T
:sym *WCL-VERSION*
:sym OS-VERSION
:sym MACHINE-INSTANCE
:sym FORMAT
:sym *CL-VERSION*
:sym *CL-BUILD-DATE*
:sym *COMPILER-VERSION*
:sym *COMPILER-BUILD-DATE*
:sym XLIB::*CLX-VERSION*
:sym XLIB::*CLX-BUILD-DATE*
:sym PRINT-COPYRIGHT
:sym LOAD-INIT-FILE
:sym REPL
:sf LMAIN "p_lsp_LMAIN"
:pinfo LMAIN NIL NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_lsp_LMAIN();
MAKE_SIMPLE_STRING(k12039,24,"/auto/u/wade/wcl/sunos4/");
extern SYMBOL s_lsp_PROBE_2DFILE; 
extern SYMBOL s_lsp_FIND_2DROOT_2DDIRECTORY; 
extern SYMBOL s_lsp__2AROOT_2DDIRECTORY_2A; 
extern SYMBOL s_key_CL; 
extern SYMBOL s_key_CLX; 
extern SYMBOL s_lsp_NIL; 
MAKE_CONS(k12041,LREF(s_key_CLX),LREF(s_lsp_NIL));
MAKE_CONS(k12040,LREF(s_key_CL),LREF(k12041));
extern SYMBOL s_lsp__2ADEFAULT_2DLIBRARIES_2A; 
extern SYMBOL s_lsp_T; 
MAKE_SIMPLE_STRING(k12042,69,";;; WCL ~A Development Environment for SPARC running SunOS ~A on ~A~%");
extern SYMBOL s_lsp__2AWCL_2DVERSION_2A; 
extern SYMBOL s_lsp_OS_2DVERSION; 
extern SYMBOL s_lsp_MACHINE_2DINSTANCE; 
extern SYMBOL s_lsp_FORMAT; 
MAKE_SIMPLE_STRING(k12043,40,";;; Common Lisp ~A library built at ~A~%");
extern SYMBOL s_lsp__2ACL_2DVERSION_2A; 
extern SYMBOL s_lsp__2ACL_2DBUILD_2DDATE_2A; 
MAKE_SIMPLE_STRING(k12044,37,";;; Compiler ~A library built at ~A~%");
extern SYMBOL s_lsp__2ACOMPILER_2DVERSION_2A; 
extern SYMBOL s_lsp__2ACOMPILER_2DBUILD_2DDATE_2A; 
MAKE_SIMPLE_STRING(k12045,32,";;; CLX ~A library built at ~A~%");
extern SYMBOL s_xlib__2ACLX_2DVERSION_2A; 
extern SYMBOL s_xlib__2ACLX_2DBUILD_2DDATE_2A; 
extern SYMBOL s_lsp_PRINT_2DCOPYRIGHT; 
extern SYMBOL s_lsp_LOAD_2DINIT_2DFILE; 
extern SYMBOL s_lsp_REPL; 




LP p_lsp_LMAIN(argc)
      ARGC argc; 
{
LP v_SYMBOL_22; LP v_SYMBOL_20; LP v_SYMBOL_18; 
LP v_SYMBOL_16; LP v_SYMBOL_14; LP v_SYMBOL_12; 
LP v_SYMBOL_10; LP v_V_8; LP v_X_7; 
LP v_S20721_6; LP v_V_4; LP v_X_3; 
LP v_S20719_2; LP v_G20720_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; 
if (argc != 0) wna(argc,0);
v_G20720_1 = ICALL(s_lsp_PROBE_2DFILE) (1, LREF(k12039));
if (v_G20720_1 != NIL) {
v_S20719_2 = v_G20720_1;
} else {
v_S20719_2 = ICALL(s_lsp_FIND_2DROOT_2DDIRECTORY) (0);
}
v_V_4 = v_S20719_2;
((LP) (DEREF((LREF(s_lsp__2AROOT_2DDIRECTORY_2A)) + 0 * 4) = (LD) (v_V_4)));
v_S20721_6 = LREF(k12040);
v_V_8 = LREF(k12040);
((LP) (DEREF((LREF(s_lsp__2ADEFAULT_2DLIBRARIES_2A)) + 0 * 4) = (LD) (v_V_8)));
v_SYMBOL_10 = LREF(s_lsp__2AWCL_2DVERSION_2A);
t0 = ((LP) DEREF((LREF(s_lsp__2AWCL_2DVERSION_2A)) + 0 * 4));
t1 = ICALL(s_lsp_OS_2DVERSION) (0);
t2 = ICALL(s_lsp_MACHINE_2DINSTANCE) (0);
ICALL(s_lsp_FORMAT) (5, LREF(s_lsp_T), LREF(k12042), t0, t1, t2);
v_SYMBOL_12 = LREF(s_lsp__2ACL_2DVERSION_2A);
t3 = ((LP) DEREF((LREF(s_lsp__2ACL_2DVERSION_2A)) + 0 * 4));
v_SYMBOL_14 = LREF(s_lsp__2ACL_2DBUILD_2DDATE_2A);
t4 = ((LP) DEREF((LREF(s_lsp__2ACL_2DBUILD_2DDATE_2A)) + 0 * 4));
ICALL(s_lsp_FORMAT) (4, LREF(s_lsp_T), LREF(k12043), t3, t4);
v_SYMBOL_16 = LREF(s_lsp__2ACOMPILER_2DVERSION_2A);
t5 = ((LP) DEREF((LREF(s_lsp__2ACOMPILER_2DVERSION_2A)) + 0 * 4));
v_SYMBOL_18 = LREF(s_lsp__2ACOMPILER_2DBUILD_2DDATE_2A);
t6 = ((LP) DEREF((LREF(s_lsp__2ACOMPILER_2DBUILD_2DDATE_2A)) + 0 * 4));
ICALL(s_lsp_FORMAT) (4, LREF(s_lsp_T), LREF(k12044), t5, t6);
v_SYMBOL_20 = LREF(s_xlib__2ACLX_2DVERSION_2A);
t7 = ((LP) DEREF((LREF(s_xlib__2ACLX_2DVERSION_2A)) + 0 * 4));
v_SYMBOL_22 = LREF(s_xlib__2ACLX_2DBUILD_2DDATE_2A);
t8 = ((LP) DEREF((LREF(s_xlib__2ACLX_2DBUILD_2DDATE_2A)) + 0 * 4));
ICALL(s_lsp_FORMAT) (4, LREF(s_lsp_T), LREF(k12045), t7, t8);
ICALL(s_lsp_PRINT_2DCOPYRIGHT) (0);
ICALL(s_lsp_LOAD_2DINIT_2DFILE) (0);
t9 = ICALL(s_lsp_REPL) (MV_CALL(argc,0));
return(t9);
}

