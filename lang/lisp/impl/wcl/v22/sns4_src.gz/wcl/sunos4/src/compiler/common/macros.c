/*
:comment "Compiled at 4:42:37 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: Debug Library"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O2 -fPIC"
:version 0
:end-package-info 0
:sym PARSE-IN/OUT
:sym DEFINE-PRIMITIVE
:sym NIL
:sym QUOTE
:sym FUNCTION
:sym C-TYPE-NAME->C-TYPE-OBJECT
:sym MAPCAR
:sym LAMBDA
:sym LIST*
:sym LIST
:sym COMPILE
:sym LOAD
:sym EVAL
:sym EVAL-WHEN
:sm DEFPRIMITIVE "m_lsp_DEFPRIMITIVE"
:sym FORMAT
:sym *C-STREAM*
:sm EMIT-C "m_lsp_EMIT_2DC"
:sym EMIT-SOURCE-LINE
:sym PROGN
:sm EMIT-LC "m_lsp_EMIT_2DLC"
:sym *K-STREAM*
:sm EMIT-K "m_lsp_EMIT_2DK"
:sym *WIN-STREAM*
:sm EMIT-WIN "m_lsp_EMIT_2DWIN"
:sym DEFPRIMITIVE
:sym DEFINE-MACRO
:sym EMIT-C
:sym EMIT-LC
:sym EMIT-K
:sym EMIT-WIN
:sf MACROS_INIT1176 "p_lsp_MACROS_5FINIT1176"
:init MACROS_INIT1176
:pinfo MACROS_INIT1176 NIL NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP m_lsp_DEFPRIMITIVE();
extern SYMBOL s_lsp_PARSE_2DIN_2FOUT; 
extern SYMBOL s_lsp_DEFINE_2DPRIMITIVE; 
extern SYMBOL s_lsp_NIL; 
extern SYMBOL s_lsp_QUOTE; 
extern SYMBOL s_lsp_FUNCTION; 
extern SYMBOL s_lsp_C_2DTYPE_2DNAME_2D_3EC_2DTYPE_2DOBJECT; 
MAKE_CONS(k10586,LREF(s_lsp_C_2DTYPE_2DNAME_2D_3EC_2DTYPE_2DOBJECT),LREF(s_lsp_NIL));
MAKE_CONS(k10585,LREF(s_lsp_FUNCTION),LREF(k10586));
extern SYMBOL s_lsp_MAPCAR; 
extern SYMBOL s_lsp_LAMBDA; 
extern SYMBOL s_lsp_LIST_2A; 
extern SYMBOL s_lsp_LIST; 
extern SYMBOL s_lsp_COMPILE; 
extern SYMBOL s_lsp_LOAD; 
extern SYMBOL s_lsp_EVAL; 
MAKE_CONS(k10589,LREF(s_lsp_EVAL),LREF(s_lsp_NIL));
MAKE_CONS(k10588,LREF(s_lsp_LOAD),LREF(k10589));
MAKE_CONS(k10587,LREF(s_lsp_COMPILE),LREF(k10588));
extern SYMBOL s_lsp_EVAL_2DWHEN; 
extern LP m_lsp_EMIT_2DC();
extern SYMBOL s_lsp_FORMAT; 
extern SYMBOL s_lsp__2AC_2DSTREAM_2A; 
extern LP m_lsp_EMIT_2DLC();
extern SYMBOL s_lsp_EMIT_2DSOURCE_2DLINE; 
extern SYMBOL s_lsp_PROGN; 
extern LP m_lsp_EMIT_2DK();
extern SYMBOL s_lsp__2AK_2DSTREAM_2A; 
extern LP m_lsp_EMIT_2DWIN();
extern SYMBOL s_lsp__2AWIN_2DSTREAM_2A; 
extern LP p_lsp_MACROS_5FINIT1176();
extern SYMBOL s_lsp_DEFPRIMITIVE; 
extern SYMBOL s_lsp_DEFINE_2DMACRO; 
extern SYMBOL s_lsp_EMIT_2DC; 
extern SYMBOL s_lsp_EMIT_2DLC; 
extern SYMBOL s_lsp_EMIT_2DK; 
extern SYMBOL s_lsp_EMIT_2DWIN; 


extern LP c_cons();


LP m_lsp_DEFPRIMITIVE(argc, v_WHOLE5634_0, v_ENV5635_1)
      ARGC argc;  LP v_WHOLE5634_0; LP v_ENV5635_1;
{
LP v_Y_88; LP v_X_87; LP v_Y_85; 
LP v_X_84; LP v_Y_82; LP v_X_81; 
LP v_Y_79; LP v_X_78; LP v_Y_76; 
LP v_X_75; LP v_Y_73; LP v_X_72; 
LP v_Y_70; LP v_X_69; LP v_Y_67; 
LP v_X_66; LP v_Y_64; LP v_X_63; 
LP v_Y_61; LP v_X_60; LP v_Y_58; 
LP v_X_57; LP v_Y_55; LP v_X_54; 
LP v_Y_52; LP v_X_51; LP v_Y_49; 
LP v_X_48; LP v_Y_46; LP v_X_45; 
LP v_Y_43; LP v_X_42; LP v_Y_40; 
LP v_X_39; LP v_Y_37; LP v_X_36; 
LP v_Y_34; LP v_X_33; LP v_Y_31; 
LP v_X_30; LP v_Y_28; LP v_X_27; 
LP v_OUT_2DTYPES_26; LP v_IN_2DTYPES_25; LP v_OUTS_24; 
LP v_INS_23; LP v_BODY_22; LP v_IN_2FOUT_21; 
LP v_S5649_20; LP v_X_18; LP v_VALUE5648_17; 
LP v_X_15; LP v_LIST5647_14; LP v_NAME_13; 
LP v_S5646_12; LP v_X_10; LP v_VALUE5645_9; 
LP v_X_7; LP v_LIST5644_6; LP v_L5643_5; 
LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE5634_0;
v_L5643_5 = ((LP) DEREF((v_WHOLE5634_0) + 1 * 4));
v_LIST5644_6 = v_L5643_5;
v_X_7 = v_LIST5644_6;
v_VALUE5645_9 = ((LP) DEREF((v_LIST5644_6) + 0 * 4));
v_X_10 = v_LIST5644_6;
v_S5646_12 = ((LP) DEREF((v_LIST5644_6) + 1 * 4));
v_L5643_5 = v_S5646_12;
v_NAME_13 = v_VALUE5645_9;
v_LIST5647_14 = v_L5643_5;
v_X_15 = v_LIST5647_14;
v_VALUE5648_17 = ((LP) DEREF((v_LIST5647_14) + 0 * 4));
v_X_18 = v_LIST5647_14;
v_S5649_20 = ((LP) DEREF((v_LIST5647_14) + 1 * 4));
v_L5643_5 = v_S5649_20;
v_IN_2FOUT_21 = v_VALUE5648_17;
v_BODY_22 = v_L5643_5;
{
int real_argc;
BEGIN_MV_CALL(mv_holder10584,0);
t0 = ICALL(s_lsp_PARSE_2DIN_2FOUT) (MV_CALL(mv_holder10584,1), v_IN_2FOUT_21);
SET_MV_RETURN_VALUE(mv_holder10584,0,t0);
if SV_RETURN_P(mv_holder10584) SET_MV_RETURN_COUNT(mv_holder10584,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder10584);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_INS_23 = NIL;
} else {
v_INS_23 = NEXT_VAR_VALUE(mv_holder10584);
}
if (real_argc < 2) {
v_OUTS_24 = NIL;
} else {
v_OUTS_24 = NEXT_VAR_VALUE(mv_holder10584);
}
if (real_argc < 3) {
v_IN_2DTYPES_25 = NIL;
} else {
v_IN_2DTYPES_25 = NEXT_VAR_VALUE(mv_holder10584);
}
if (real_argc < 4) {
v_OUT_2DTYPES_26 = NIL;
} else {
v_OUT_2DTYPES_26 = NEXT_VAR_VALUE(mv_holder10584);
}
END_VAR_VALUES;
END_MV_CALL;
v_X_27 = v_NAME_13;
v_Y_28 = LREF(s_lsp_NIL);
v_Y_31 = (c_cons((v_NAME_13), (LREF(s_lsp_NIL))));
t1 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_31)));
v_X_33 = v_INS_23;
v_Y_34 = LREF(s_lsp_NIL);
v_Y_37 = (c_cons((v_INS_23), (LREF(s_lsp_NIL))));
t2 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_37)));
v_X_39 = v_OUTS_24;
v_Y_40 = LREF(s_lsp_NIL);
v_Y_43 = (c_cons((v_OUTS_24), (LREF(s_lsp_NIL))));
t3 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_43)));
v_X_45 = v_IN_2DTYPES_25;
v_Y_46 = LREF(s_lsp_NIL);
v_Y_49 = (c_cons((v_IN_2DTYPES_25), (LREF(s_lsp_NIL))));
v_X_51 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_49)));
v_Y_55 = (c_cons((v_X_51), (LREF(s_lsp_NIL))));
v_Y_58 = (c_cons((LREF(k10585)), (v_Y_55)));
t4 = (c_cons((LREF(s_lsp_MAPCAR)), (v_Y_58)));
v_X_60 = v_OUT_2DTYPES_26;
v_Y_61 = LREF(s_lsp_NIL);
v_Y_64 = (c_cons((v_OUT_2DTYPES_26), (LREF(s_lsp_NIL))));
v_X_66 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_64)));
v_Y_70 = (c_cons((v_X_66), (LREF(s_lsp_NIL))));
v_Y_73 = (c_cons((LREF(k10585)), (v_Y_70)));
t5 = (c_cons((LREF(s_lsp_MAPCAR)), (v_Y_73)));
v_X_75 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_LAMBDA), v_INS_23, v_BODY_22);
v_Y_79 = (c_cons((v_X_75), (LREF(s_lsp_NIL))));
t6 = (c_cons((LREF(s_lsp_FUNCTION)), (v_Y_79)));
v_X_81 = ICALL(s_lsp_LIST) (7, LREF(s_lsp_DEFINE_2DPRIMITIVE), t1, t2, t3, t4, t5, t6);
v_Y_85 = (c_cons((v_X_81), (LREF(s_lsp_NIL))));
v_Y_88 = (c_cons((LREF(k10587)), (v_Y_85)));
t7 = (c_cons((LREF(s_lsp_EVAL_2DWHEN)), (v_Y_88)));
return(t7);
}
}

LP m_lsp_EMIT_2DC(argc, v_WHOLE5650_0, v_ENV5651_1)
      ARGC argc;  LP v_WHOLE5650_0; LP v_ENV5651_1;
{
LP v_ARGS_14; LP v_STRING_13; LP v_S5659_12; 
LP v_X_10; LP v_VALUE5658_9; LP v_X_7; 
LP v_LIST5657_6; LP v_L5656_5; LP v_X_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE5650_0;
v_L5656_5 = ((LP) DEREF((v_WHOLE5650_0) + 1 * 4));
v_LIST5657_6 = v_L5656_5;
v_X_7 = v_LIST5657_6;
v_VALUE5658_9 = ((LP) DEREF((v_LIST5657_6) + 0 * 4));
v_X_10 = v_LIST5657_6;
v_S5659_12 = ((LP) DEREF((v_LIST5657_6) + 1 * 4));
v_L5656_5 = v_S5659_12;
v_STRING_13 = v_VALUE5658_9;
v_ARGS_14 = v_L5656_5;
t0 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,4), LREF(s_lsp_FORMAT), LREF(s_lsp__2AC_2DSTREAM_2A), v_STRING_13, v_ARGS_14);
return(t0);
}

LP m_lsp_EMIT_2DLC(argc, v_WHOLE5660_0, v_ENV5661_1)
      ARGC argc;  LP v_WHOLE5660_0; LP v_ENV5661_1;
{
LP v_Y_36; LP v_X_35; LP v_Y_33; 
LP v_X_32; LP v_Y_30; LP v_X_29; 
LP v_Y_27; LP v_X_26; LP v_Y_24; 
LP v_X_23; LP v_ARGS_22; LP v_STRING_21; 
LP v_S5675_20; LP v_X_18; LP v_VALUE5674_17; 
LP v_X_15; LP v_LIST5673_14; LP v_TREE_13; 
LP v_S5672_12; LP v_X_10; LP v_VALUE5671_9; 
LP v_X_7; LP v_LIST5670_6; LP v_L5669_5; 
LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE5660_0;
v_L5669_5 = ((LP) DEREF((v_WHOLE5660_0) + 1 * 4));
v_LIST5670_6 = v_L5669_5;
v_X_7 = v_LIST5670_6;
v_VALUE5671_9 = ((LP) DEREF((v_LIST5670_6) + 0 * 4));
v_X_10 = v_LIST5670_6;
v_S5672_12 = ((LP) DEREF((v_LIST5670_6) + 1 * 4));
v_L5669_5 = v_S5672_12;
v_TREE_13 = v_VALUE5671_9;
v_LIST5673_14 = v_L5669_5;
v_X_15 = v_LIST5673_14;
v_VALUE5674_17 = ((LP) DEREF((v_LIST5673_14) + 0 * 4));
v_X_18 = v_LIST5673_14;
v_S5675_20 = ((LP) DEREF((v_LIST5673_14) + 1 * 4));
v_L5669_5 = v_S5675_20;
v_STRING_21 = v_VALUE5674_17;
v_ARGS_22 = v_L5669_5;
v_X_23 = v_TREE_13;
v_Y_24 = LREF(s_lsp_NIL);
v_Y_27 = (c_cons((v_TREE_13), (LREF(s_lsp_NIL))));
v_X_32 = (c_cons((LREF(s_lsp_EMIT_2DSOURCE_2DLINE)), (v_Y_27)));
v_X_29 = ICALL(s_lsp_LIST_2A) (4, LREF(s_lsp_FORMAT), LREF(s_lsp__2AC_2DSTREAM_2A), v_STRING_21, v_ARGS_22);
v_Y_33 = (c_cons((v_X_29), (LREF(s_lsp_NIL))));
v_Y_36 = (c_cons((v_X_32), (v_Y_33)));
t0 = (c_cons((LREF(s_lsp_PROGN)), (v_Y_36)));
return(t0);
}

LP m_lsp_EMIT_2DK(argc, v_WHOLE5676_0, v_ENV5677_1)
      ARGC argc;  LP v_WHOLE5676_0; LP v_ENV5677_1;
{
LP v_ARGS_14; LP v_STRING_13; LP v_S5685_12; 
LP v_X_10; LP v_VALUE5684_9; LP v_X_7; 
LP v_LIST5683_6; LP v_L5682_5; LP v_X_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE5676_0;
v_L5682_5 = ((LP) DEREF((v_WHOLE5676_0) + 1 * 4));
v_LIST5683_6 = v_L5682_5;
v_X_7 = v_LIST5683_6;
v_VALUE5684_9 = ((LP) DEREF((v_LIST5683_6) + 0 * 4));
v_X_10 = v_LIST5683_6;
v_S5685_12 = ((LP) DEREF((v_LIST5683_6) + 1 * 4));
v_L5682_5 = v_S5685_12;
v_STRING_13 = v_VALUE5684_9;
v_ARGS_14 = v_L5682_5;
t0 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,4), LREF(s_lsp_FORMAT), LREF(s_lsp__2AK_2DSTREAM_2A), v_STRING_13, v_ARGS_14);
return(t0);
}

LP m_lsp_EMIT_2DWIN(argc, v_WHOLE5686_0, v_ENV5687_1)
      ARGC argc;  LP v_WHOLE5686_0; LP v_ENV5687_1;
{
LP v_ARGS_14; LP v_STRING_13; LP v_S5695_12; 
LP v_X_10; LP v_VALUE5694_9; LP v_X_7; 
LP v_LIST5693_6; LP v_L5692_5; LP v_X_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE5686_0;
v_L5692_5 = ((LP) DEREF((v_WHOLE5686_0) + 1 * 4));
v_LIST5693_6 = v_L5692_5;
v_X_7 = v_LIST5693_6;
v_VALUE5694_9 = ((LP) DEREF((v_LIST5693_6) + 0 * 4));
v_X_10 = v_LIST5693_6;
v_S5695_12 = ((LP) DEREF((v_LIST5693_6) + 1 * 4));
v_L5692_5 = v_S5695_12;
v_STRING_13 = v_VALUE5694_9;
v_ARGS_14 = v_L5692_5;
t0 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,4), LREF(s_lsp_FORMAT), LREF(s_lsp__2AWIN_2DSTREAM_2A), v_STRING_13, v_ARGS_14);
return(t0);
}

LP p_lsp_MACROS_5FINIT1176(argc)
      ARGC argc; 
{
LP v_X_9; LP v_X_7; LP v_X_5; 
LP v_X_3; LP v_X_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; 
if (argc != 0) wna(argc,0);
v_X_1 = LREF(s_lsp_DEFPRIMITIVE);
t0 = ((LP) DEREF((LREF(s_lsp_DEFPRIMITIVE)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_lsp_DEFPRIMITIVE), t0);
v_X_3 = LREF(s_lsp_EMIT_2DC);
t1 = ((LP) DEREF((LREF(s_lsp_EMIT_2DC)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_lsp_EMIT_2DC), t1);
v_X_5 = LREF(s_lsp_EMIT_2DLC);
t2 = ((LP) DEREF((LREF(s_lsp_EMIT_2DLC)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_lsp_EMIT_2DLC), t2);
v_X_7 = LREF(s_lsp_EMIT_2DK);
t3 = ((LP) DEREF((LREF(s_lsp_EMIT_2DK)) + 4 * 4));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_lsp_EMIT_2DK), t3);
v_X_9 = LREF(s_lsp_EMIT_2DWIN);
t5 = ((LP) DEREF((LREF(s_lsp_EMIT_2DWIN)) + 4 * 4));
t4 = ICALL(s_lsp_DEFINE_2DMACRO) (MV_CALL(argc,2), LREF(s_lsp_EMIT_2DWIN), t5);
return(t4);
}

