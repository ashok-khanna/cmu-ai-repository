/*
:comment "Compiled at 4:29:44 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: DEFAULT"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O "
:version 0
:end-package-info 0
:sym T
:sym *WCL-VERSION*
:sym OS-VERSION
:sym MACHINE-INSTANCE
:sym FORMAT
:sym *CL-VERSION*
:sym *CL-BUILD-DATE*
:sym PRINT-COPYRIGHT
:sym LOAD-INIT-FILE
:sym REPL
:sf LMAIN "p_lsp_LMAIN"
:pinfo LMAIN NIL NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_lsp_LMAIN();
extern SYMBOL s_lsp_T; 
MAKE_SIMPLE_STRING(k9907,67,";;; WCL ~A Evaluator Environment for SPARC running SunOS ~A on ~A~%");
extern SYMBOL s_lsp__2AWCL_2DVERSION_2A; 
extern SYMBOL s_lsp_OS_2DVERSION; 
extern SYMBOL s_lsp_MACHINE_2DINSTANCE; 
extern SYMBOL s_lsp_FORMAT; 
MAKE_SIMPLE_STRING(k9908,40,";;; Common Lisp ~A library built at ~A~%");
extern SYMBOL s_lsp__2ACL_2DVERSION_2A; 
extern SYMBOL s_lsp__2ACL_2DBUILD_2DDATE_2A; 
extern SYMBOL s_lsp_PRINT_2DCOPYRIGHT; 
extern SYMBOL s_lsp_LOAD_2DINIT_2DFILE; 
extern SYMBOL s_lsp_REPL; 




LP p_lsp_LMAIN(argc)
      ARGC argc; 
{
LP v_SYMBOL_5; LP v_SYMBOL_3; LP v_SYMBOL_1; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; 
if (argc != 0) wna(argc,0);
v_SYMBOL_1 = LREF(s_lsp__2AWCL_2DVERSION_2A);
t0 = ((LP) DEREF((LREF(s_lsp__2AWCL_2DVERSION_2A)) + 0 * 4));
t1 = ICALL(s_lsp_OS_2DVERSION) (0);
t2 = ICALL(s_lsp_MACHINE_2DINSTANCE) (0);
ICALL(s_lsp_FORMAT) (5, LREF(s_lsp_T), LREF(k9907), t0, t1, t2);
v_SYMBOL_3 = LREF(s_lsp__2ACL_2DVERSION_2A);
t3 = ((LP) DEREF((LREF(s_lsp__2ACL_2DVERSION_2A)) + 0 * 4));
v_SYMBOL_5 = LREF(s_lsp__2ACL_2DBUILD_2DDATE_2A);
t4 = ((LP) DEREF((LREF(s_lsp__2ACL_2DBUILD_2DDATE_2A)) + 0 * 4));
ICALL(s_lsp_FORMAT) (4, LREF(s_lsp_T), LREF(k9908), t3, t4);
ICALL(s_lsp_PRINT_2DCOPYRIGHT) (0);
ICALL(s_lsp_LOAD_2DINIT_2DFILE) (0);
t5 = ICALL(s_lsp_REPL) (MV_CALL(argc,0));
return(t5);
}

