/*
:comment "Compiled at 3:51:39 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: Debug Library"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O2 -fPIC"
:version 0
:end-package-info 0
:c-type IOBUF #S(C-STRUCT-INFO NAME IOBUF SLOTS (#S(C-STRUCT-SLOT NAME COUNT C-NAME "COUNT" TYPE INT) #S(C-STRUCT-SLOT NAME POINTER C-NAME "POINTER" TYPE CHAR*) #S(C-STRUCT-SLOT NAME BASE C-NAME "BASE" TYPE CHAR*) #S(C-STRUCT-SLOT NAME BUFFER-SIZE C-NAME "BUFFER_2DSIZE" TYPE INT) #S(C-STRUCT-SLOT NAME FLAG C-NAME "FLAG" TYPE SHORT) #S(C-STRUCT-SLOT NAME FILE C-NAME "FILE" TYPE CHAR)))
:sym :COUNT
:sym :POINTER
:sym :BASE
:sym :BUFFER-SIZE
:sym :FLAG
:sym :FILE
:sym NEW-FPTR
:sf MAKE-IOBUF "p_lsp_MAKE_2DIOBUF"
:sym T
:sf IOBUF-P "p_lsp_IOBUF_2DP"
:proclaim (QUOTE (INLINE IOBUF-COUNT))
:sf IOBUF-COUNT "p_lsp_IOBUF_2DCOUNT"
:proclaim (QUOTE (INLINE IOBUF-POINTER))
:sf IOBUF-POINTER "p_lsp_IOBUF_2DPOINTER"
:proclaim (QUOTE (INLINE IOBUF-BASE))
:sf IOBUF-BASE "p_lsp_IOBUF_2DBASE"
:proclaim (QUOTE (INLINE IOBUF-BUFFER-SIZE))
:sf IOBUF-BUFFER-SIZE "p_lsp_IOBUF_2DBUFFER_2DSIZE"
:proclaim (QUOTE (INLINE IOBUF-FLAG))
:sf IOBUF-FLAG "p_lsp_IOBUF_2DFLAG"
:proclaim (QUOTE (INLINE IOBUF-FILE))
:sf IOBUF-FILE "p_lsp_IOBUF_2DFILE"
:c-type DIRDESC #S(C-STRUCT-INFO NAME DIRDESC SLOTS (#S(C-STRUCT-SLOT NAME FILE-DESC C-NAME "FILE_2DDESC" TYPE INT) #S(C-STRUCT-SLOT NAME LOC C-NAME "LOC" TYPE LONG) #S(C-STRUCT-SLOT NAME SIZE C-NAME "SIZE" TYPE LONG) #S(C-STRUCT-SLOT NAME BSIZE C-NAME "BSIZE" TYPE LONG) #S(C-STRUCT-SLOT NAME OFF C-NAME "OFF" TYPE LONG) #S(C-STRUCT-SLOT NAME DATA-BUFFER C-NAME "DATA_2DBUFFER" TYPE CHAR*)))
:sym :FILE-DESC
:sym :LOC
:sym :SIZE
:sym :BSIZE
:sym :OFF
:sym :DATA-BUFFER
:sf MAKE-DIRDESC "p_lsp_MAKE_2DDIRDESC"
:sf DIRDESC-P "p_lsp_DIRDESC_2DP"
:proclaim (QUOTE (INLINE DIRDESC-FILE-DESC))
:sf DIRDESC-FILE-DESC "p_lsp_DIRDESC_2DFILE_2DDESC"
:proclaim (QUOTE (INLINE DIRDESC-LOC))
:sf DIRDESC-LOC "p_lsp_DIRDESC_2DLOC"
:proclaim (QUOTE (INLINE DIRDESC-SIZE))
:sf DIRDESC-SIZE "p_lsp_DIRDESC_2DSIZE"
:proclaim (QUOTE (INLINE DIRDESC-BSIZE))
:sf DIRDESC-BSIZE "p_lsp_DIRDESC_2DBSIZE"
:proclaim (QUOTE (INLINE DIRDESC-OFF))
:sf DIRDESC-OFF "p_lsp_DIRDESC_2DOFF"
:proclaim (QUOTE (INLINE DIRDESC-DATA-BUFFER))
:sf DIRDESC-DATA-BUFFER "p_lsp_DIRDESC_2DDATA_2DBUFFER"
:c-type DIRENT #S(C-STRUCT-INFO NAME DIRENT SLOTS (#S(C-STRUCT-SLOT NAME OFFSET C-NAME "OFFSET" TYPE INT) #S(C-STRUCT-SLOT NAME FILENO C-NAME "FILENO" TYPE INT) #S(C-STRUCT-SLOT NAME RECLEN C-NAME "RECLEN" TYPE SHORT) #S(C-STRUCT-SLOT NAME NAMLEN C-NAME "NAMLEN" TYPE SHORT) #S(C-STRUCT-SLOT NAME NAME C-NAME "NAME" TYPE (ARRAY CHAR 256))))
:sym :OFFSET
:sym :FILENO
:sym :RECLEN
:sym :NAMLEN
:sym :NAME
:sf MAKE-DIRENT "p_lsp_MAKE_2DDIRENT"
:sf DIRENT-P "p_lsp_DIRENT_2DP"
:proclaim (QUOTE (INLINE DIRENT-OFFSET))
:sf DIRENT-OFFSET "p_lsp_DIRENT_2DOFFSET"
:proclaim (QUOTE (INLINE DIRENT-FILENO))
:sf DIRENT-FILENO "p_lsp_DIRENT_2DFILENO"
:proclaim (QUOTE (INLINE DIRENT-RECLEN))
:sf DIRENT-RECLEN "p_lsp_DIRENT_2DRECLEN"
:proclaim (QUOTE (INLINE DIRENT-NAMLEN))
:sf DIRENT-NAMLEN "p_lsp_DIRENT_2DNAMLEN"
:proclaim (QUOTE (INLINE DIRENT-NAME))
:sf DIRENT-NAME "p_lsp_DIRENT_2DNAME"
:c-type FILE-PTR (IOBUF *)
:c-type DIRDESC-PTR (DIRDESC *)
:c-type DIRENT-PTR (DIRENT *)
:sym DIRDESC
:sf OPENDIR "p_lsp_OPENDIR"
:sf CLOSEDIR "p_lsp_CLOSEDIR"
:sym DIRENT
:sf READDIR "p_lsp_READDIR"
:sf ALLOC_MEMORY "p_lsp_ALLOC_5FMEMORY"
:sf ALLOC_WORDS "p_lsp_ALLOC_5FWORDS"
:sf ALLOC_SHORTS "p_lsp_ALLOC_5FSHORTS"
:sf ALLOC_BYTES "p_lsp_ALLOC_5FBYTES"
:sf ALLOC_BITS "p_lsp_ALLOC_5FBITS"
:sf C_CONS "p_lsp_C_5FCONS"
:sf LISP_BREAK "p_lsp_LISP_5FBREAK"
:sf LISP_DEBUG "p_lsp_LISP_5FDEBUG"
:sf COMMAND_LINE_ARGUMENT "p_lsp_COMMAND_5FLINE_5FARGUMENT"
:sf APPLY_FUNCTION "p_lsp_APPLY_5FFUNCTION"
:sf INITIALIZE_ARRAY "p_lsp_INITIALIZE_5FARRAY"
:sf PRINT_DOUBLE_FLOAT "p_lsp_PRINT_5FDOUBLE_5FFLOAT"
:sf DOUBLE_FLOAT_TO_STRING "p_lsp_DOUBLE_5FFLOAT_5FTO_5FSTRING"
:sf ILOGB "p_lsp_ILOGB"
:sf ADD "p_lsp_ADD"
:sf MULTIPLY "p_lsp_MULTIPLY"
:sf SUBTRACT "p_lsp_SUBTRACT"
:sf DIVIDE "p_lsp_DIVIDE"
:sf INTEGER_ADD "p_lsp_INTEGER_5FADD"
:sf INTEGER_SUBTRACT "p_lsp_INTEGER_5FSUBTRACT"
:sf INTEGER_MULTIPLY "p_lsp_INTEGER_5FMULTIPLY"
:sf C_EQL "p_lsp_C_5FEQL"
:sf NUM_EQUAL_P "p_lsp_NUM_5FEQUAL_5FP"
:sf GREATERP "p_lsp_GREATERP"
:sf GEQ_P "p_lsp_GEQ_5FP"
:sf LESSP "p_lsp_LESSP"
:sf LEQ_P "p_lsp_LEQ_5FP"
:sf MAKE_SYMBOL "p_lsp_MAKE_5FSYMBOL"
:sym IOBUF
:sf FOPEN "p_lsp_FOPEN"
:sf FDOPEN "p_lsp_FDOPEN"
:sf FCLOSE "p_lsp_FCLOSE"
:sf FFLUSH "p_lsp_FFLUSH"
:sf FSEEK "p_lsp_FSEEK"
:sf FTELL "p_lsp_FTELL"
:sf UNLINK "p_lsp_UNLINK"
:sf FGETC "p_lsp_FGETC"
:sf UNGETC "p_lsp_UNGETC"
:sf FPUTC "p_lsp_FPUTC"
:sf FPUTS "p_lsp_FPUTS"
:sf GET_FILE_PTR "p_lsp_GET_5FFILE_5FPTR"
:sf STRTOL "p_lsp_STRTOL"
:sf STRTOD "p_lsp_STRTOD"
:sf STRCMP "p_lsp_STRCMP"
:sf EXIT "p_lsp_EXIT"
:sf SYSTEM "p_lsp_SYSTEM"
:sf POPEN "p_lsp_POPEN"
:sf PCLOSE "p_lsp_PCLOSE"
:sf STRING_COLUMN "p_lsp_STRING_5FCOLUMN"
:sf FIXNUM_TO_BIGNUM "p_lsp_FIXNUM_5FTO_5FBIGNUM"
:sf BIGNUM_DIV "p_lsp_BIGNUM_5FDIV"
:sf BIGNUM_REM "p_lsp_BIGNUM_5FREM"
:sf BIGNUM_TO_DOUBLE "p_lsp_BIGNUM_5FTO_5FDOUBLE"
:sf INT_LENGTH "p_lsp_INT_5FLENGTH"
:sf DOUBLE_TRUNCATE "p_lsp_DOUBLE_5FTRUNCATE"
:sf DOUBLE_FLOOR "p_lsp_DOUBLE_5FFLOOR"
:sf CEIL "p_lsp_CEIL"
:sf FLOAT_SIGNIFICAND "p_lsp_FLOAT_5FSIGNIFICAND"
:sf FLOAT_EXPONENT "p_lsp_FLOAT_5FEXPONENT"
:sf LDEXP "p_lsp_LDEXP"
:sf FMOD "p_lsp_FMOD"
:sf RINT "p_lsp_RINT"
:sf REMAINDER "p_lsp_REMAINDER"
:sf POW "p_lsp_POW"
:sf DOUBLE_LOG "p_lsp_DOUBLE_5FLOG"
:sf DOUBLE_LOG10 "p_lsp_DOUBLE_5FLOG10"
:sf DOUBLE_SQRT "p_lsp_DOUBLE_5FSQRT"
:sf DOUBLE_EXP "p_lsp_DOUBLE_5FEXP"
:sf DOUBLE_SIN "p_lsp_DOUBLE_5FSIN"
:sf DOUBLE_COS "p_lsp_DOUBLE_5FCOS"
:sf DOUBLE_TAN "p_lsp_DOUBLE_5FTAN"
:sf DOUBLE_ASIN "p_lsp_DOUBLE_5FASIN"
:sf DOUBLE_ACOS "p_lsp_DOUBLE_5FACOS"
:sf DOUBLE_ATAN2 "p_lsp_DOUBLE_5FATAN2"
:sf HEAP_START "p_lsp_HEAP_5FSTART"
:sf HEAP_FRONTIER "p_lsp_HEAP_5FFRONTIER"
:sf HEAP_FRONTIER_LIMIT "p_lsp_HEAP_5FFRONTIER_5FLIMIT"
:sf HEAP_PAGE_SIZE "p_lsp_HEAP_5FPAGE_5FSIZE"
:sf TOTAL_HEAP_PAGES "p_lsp_TOTAL_5FHEAP_5FPAGES"
:sf FREE_HEAP_PAGES "p_lsp_FREE_5FHEAP_5FPAGES"
:sf TOTAL_STATIC_PAGES "p_lsp_TOTAL_5FSTATIC_5FPAGES"
:sf FREE_STATIC_BYTES "p_lsp_FREE_5FSTATIC_5FBYTES"
:sf UNIX_TIME_OF_DAY "p_lsp_UNIX_5FTIME_5FOF_5FDAY"
:sf UNIX_TIMEZONE "p_lsp_UNIX_5FTIMEZONE"
:sf UNIX_DAYLIGHT_SAVINGS_TIME "p_lsp_UNIX_5FDAYLIGHT_5FSAVINGS_5FTIME"
:sf INTERNAL_REAL_TIME "p_lsp_INTERNAL_5FREAL_5FTIME"
:sf INTERNAL_SYSTEM_RUN_TIME "p_lsp_INTERNAL_5FSYSTEM_5FRUN_5FTIME"
:sf INTERNAL_USER_RUN_TIME "p_lsp_INTERNAL_5FUSER_5FRUN_5FTIME"
:sf C_SLEEP "p_lsp_C_5FSLEEP"
:sf C_AREF "p_lsp_C_5FAREF"
:sf C_SET_AREF "p_lsp_C_5FSET_5FAREF"
:sf VREF "p_lsp_VREF"
:sf SET_VREF "p_lsp_SET_5FVREF"
:sf CONNECT_TO_SERVER "p_lsp_CONNECT_5FTO_5FSERVER"
:sf PC_TO_PROCEDURE_NAME "p_lsp_PC_5FTO_5FPROCEDURE_5FNAME"
:sf LOAD_COMPILED_FILE "p_lsp_LOAD_5FCOMPILED_5FFILE"
:sf C_SYMBOL_VALUE "p_lsp_C_5FSYMBOL_5FVALUE"
:sf FULL_GC "p_lsp_FULL_5FGC"
:sf GC_CALL_COUNT "p_lsp_GC_5FCALL_5FCOUNT"
:sf SET_GC_MESSAGES "p_lsp_SET_5FGC_5FMESSAGES"
:sf INTERN_STATIC_SYMBOLS "p_lsp_INTERN_5FSTATIC_5FSYMBOLS"
:sf SWITCH_TO_STATIC_SPACE "p_lsp_SWITCH_5FTO_5FSTATIC_5FSPACE"
:sf SWITCH_TO_DYNAMIC_SPACE "p_lsp_SWITCH_5FTO_5FDYNAMIC_5FSPACE"
:sf OBJECT_SIZE "p_lsp_OBJECT_5FSIZE"
:sf FILE_WRITE_DATE "p_lsp_FILE_5FWRITE_5FDATE"
:sf PROBE_FILE "p_lsp_PROBE_5FFILE"
:sf FILE_LENGTH "p_lsp_FILE_5FLENGTH"
:sf FILE_LISTEN "p_lsp_FILE_5FLISTEN"
:sf WRITE_BYTE "p_lsp_WRITE_5FBYTE"
:sf READ_BYTE "p_lsp_READ_5FBYTE"
:sf READ_VECTOR "p_lsp_READ_5FVECTOR"
:sf WRITE_VECTOR "p_lsp_WRITE_5FVECTOR"
:sf CHDIR "p_lsp_CHDIR"
:sf GETPID "p_lsp_GETPID"
:sf GETENV "p_lsp_GETENV"
:sf PUTENV "p_lsp_PUTENV"
:sf CLOSURE_OE "p_lsp_CLOSURE_5FOE"
:sf MAKE_EVAL_CLOSURE "p_lsp_MAKE_5FEVAL_5FCLOSURE"
:sf GETHOSTNAME "p_lsp_GETHOSTNAME"
:sf GETOSVERSION "p_lsp_GETOSVERSION"
:sf GETWD "p_lsp_GETWD"
:sf INITSTATE "p_lsp_INITSTATE"
:sf C_RANDOM "p_lsp_C_5FRANDOM"
:sf SETSTATE "p_lsp_SETSTATE"
:sf USLEEP "p_lsp_USLEEP"
:sym DIRENT-PTR
:sf FOREIGN_INIT644 "p_lsp_FOREIGN_5FINIT644"
:init FOREIGN_INIT644
:finfo C_AREF "c_aref" (ARRAY INDICES) (RESULT) (T T) (T)
:finfo FSEEK "fseek" (STREAM OFFSET FLAG) (STATUS) (FILE-PTR INT INT) (INT)
:finfo FGETC "fgetc" (STREAM) (C) (FILE-PTR) (INT)
:finfo PROBE_FILE "probe_file" (FILENAME) (STATUS) (CHAR*) (T)
:pinfo DIRDESC-DATA-BUFFER (S) NIL NIL NIL (LAMBDA (S) (DECLARE) (BLOCK DIRDESC-DATA-BUFFER (C-STRUCT-REF S DIRDESC DATA-BUFFER))) NIL T T
:pinfo DIRENT-P (S) NIL NIL NIL NIL NIL NIL T
:finfo GETHOSTNAME "gethostname" (NAME NAMELEN) (STATUS) (CHAR* INT) (INT)
:pinfo DIRDESC-LOC (S) NIL NIL NIL (LAMBDA (S) (DECLARE) (BLOCK DIRDESC-LOC (C-STRUCT-REF S DIRDESC LOC))) NIL T T
:finfo STRCMP "strcmp" (S1 S2) (R) (CHAR* CHAR*) (INT)
:finfo ALLOC_WORDS "alloc_words" (LEN TYPE) (S) (INT INT) (T)
:pinfo DIRENT-OFFSET (S) NIL NIL NIL (LAMBDA (S) (DECLARE) (BLOCK DIRENT-OFFSET (C-STRUCT-REF S DIRENT OFFSET))) NIL T T
:pinfo DIRDESC-FILE-DESC (S) NIL NIL NIL (LAMBDA (S) (DECLARE) (BLOCK DIRDESC-FILE-DESC (C-STRUCT-REF S DIRDESC FILE-DESC))) NIL T T
:finfo INTEGER_MULTIPLY "integer_multiply" (X Y) (SUM) (T T) (T)
:finfo INTERNAL_USER_RUN_TIME "internal_user_run_time" NIL (RESULT) NIL (INT)
:finfo DIVIDE "divide" (X Y) (SUM) (T T) (T)
:pinfo DIRENT-RECLEN (S) NIL NIL NIL (LAMBDA (S) (DECLARE) (BLOCK DIRENT-RECLEN (C-STRUCT-REF S DIRENT RECLEN))) NIL T T
:pinfo IOBUF-BASE (S) NIL NIL NIL (LAMBDA (S) (DECLARE) (BLOCK IOBUF-BASE (C-STRUCT-REF S IOBUF BASE))) NIL T T
:finfo DOUBLE_SIN "sin" (X) (R) (DOUBLE) (DOUBLE)
:finfo LESSP "lessp" (X Y) (FLAG) (T T) (T)
:finfo READDIR "readdir" (DIRP) (DP) (DIRDESC-PTR) (DIRENT-PTR)
:finfo BIGNUM_TO_DOUBLE "bignum_to_double" (X) (R) (T) (DOUBLE)
:finfo BIGNUM_REM "bignum_rem" (X Y) (R) (T T) (T)
:finfo CONNECT_TO_SERVER "connect_to_server" (HOST DISPLAY) (VALUE) (CHAR* INT) (INT)
:finfo NUM_EQUAL_P "num_equal_p" (X Y) (FLAG) (T T) (T)
:finfo CEIL "ceil" (X) (RESULT) (DOUBLE) (DOUBLE)
:pinfo DIRDESC-BSIZE (S) NIL NIL NIL (LAMBDA (S) (DECLARE) (BLOCK DIRDESC-BSIZE (C-STRUCT-REF S DIRDESC BSIZE))) NIL T T
:finfo HEAP_FRONTIER "heap_frontier" NIL (RESULT) NIL (INT)
:finfo UNIX_TIMEZONE "unix_timezone" NIL (RESULT) NIL (INT)
:finfo ALLOC_BYTES "alloc_bytes" (LEN TYPE) (S) (INT INT) (T)
:finfo OPENDIR "opendir" (DIRNAME) (DIRP) (CHAR*) (DIRDESC-PTR)
:finfo FLOAT_SIGNIFICAND "float_significand" (X) (RESULT) (DOUBLE) (DOUBLE)
:finfo C_CONS "c_cons" (CAR CDR) (C) (T T) (T)
:finfo FDOPEN "fdopen" (FILE-DESC TYPE) (FILE) (INT CHAR*) (FILE-PTR)
:finfo FULL_GC "full_gc" NIL (V) NIL (VOID)
:finfo DOUBLE_EXP "exp" (X) (RESULT) (DOUBLE) (DOUBLE)
:finfo FMOD "fmod" (X Y) (RESULT) (DOUBLE DOUBLE) (DOUBLE)
:finfo WRITE_VECTOR "write_vector" (FILE ELEMENT-SIZE VECTOR START END) (COUNT) (FILE-PTR INT T INT INT) (T)
:finfo LISP_BREAK "lisp_break" NIL (V) NIL (VOID)
:finfo READ_BYTE "read_byte" (FILE ELEMENT-TYPE EOF-ERROR-P EOF-VALUE) (VALUE) (FILE-PTR INT T T) (T)
:finfo SETSTATE "setstate" (DATA) (R) (CHAR*) (VOID)
:finfo TOTAL_STATIC_PAGES "total_static_pages" NIL (RESULT) NIL (INT)
:finfo APPLY_FUNCTION "apply_function" (ARGC F L) (R) (T T T) (T)
:pinfo FOREIGN_INIT644 NIL NIL NIL NIL NIL NIL NIL T
:finfo GREATERP "greaterp" (X Y) (FLAG) (T T) (T)
:finfo DOUBLE_TRUNCATE "double_truncate" (X Y) (RESULT) (DOUBLE DOUBLE) (INT)
:finfo INTERNAL_SYSTEM_RUN_TIME "internal_system_run_time" NIL (RESULT) NIL (INT)
:pinfo MAKE-DIRENT (&KEY OFFSET FILENO RECLEN NAMLEN NAME) NIL NIL NIL NIL NIL NIL T
:finfo ALLOC_MEMORY "alloc_memory" (LEN WORD-SIZE TYPE) (S) (INT INT INT) (T)
:finfo MULTIPLY "multiply" (X Y) (SUM) (T T) (T)
:finfo C_EQL "c_eql" (X Y) (FLAG) (T T) (T)
:finfo DOUBLE_ASIN "asin" (X) (R) (DOUBLE) (DOUBLE)
:finfo DOUBLE_FLOAT_TO_STRING "double_float_to_string" (N STREAM) (LEN) (DOUBLE CHAR*) (INT)
:finfo CLOSURE_OE "closure_oe" (PROCEDURE) (OE) (T) (T)
:finfo INITSTATE "initstate" (SEED DATA LEN) (R) (INT CHAR* INT) (VOID)
:pinfo IOBUF-POINTER (S) NIL NIL NIL (LAMBDA (S) (DECLARE) (BLOCK IOBUF-POINTER (C-STRUCT-REF S IOBUF POINTER))) NIL T T
:finfo RINT "rint" (X) (RESULT) (DOUBLE) (DOUBLE)
:finfo LISP_DEBUG "lisp_debug" NIL (V) NIL (VOID)
:finfo ILOGB "ilogb" (F) (EXPONENT) (DOUBLE) (INT)
:pinfo IOBUF-FLAG (S) NIL NIL NIL (LAMBDA (S) (DECLARE) (BLOCK IOBUF-FLAG (C-STRUCT-REF S IOBUF FLAG))) NIL T T
:finfo ALLOC_BITS "alloc_bits" (LEN TYPE) (S) (INT INT) (T)
:finfo INT_LENGTH "int_length" (X) (LEN) (INT) (INT)
:finfo HEAP_START "heap_start" NIL (RESULT) NIL (INT)
:finfo LOAD_COMPILED_FILE "load_compiled_file" (NAME) (VALUE) (CHAR*) (INT)
:pinfo IOBUF-BUFFER-SIZE (S) NIL NIL NIL (LAMBDA (S) (DECLARE) (BLOCK IOBUF-BUFFER-SIZE (C-STRUCT-REF S IOBUF BUFFER-SIZE))) NIL T T
:finfo FIXNUM_TO_BIGNUM "fixnum_to_bignum" (X) (B) (T) (T)
:finfo UNLINK "unlink" (PATH) (STATUS) (CHAR*) (INT)
:finfo C_RANDOM "random" NIL (R) NIL (UINT32)
:finfo LDEXP "ldexp" (SIGNIFICAND EXPONENT) (RESULT) (DOUBLE INT) (DOUBLE)
:finfo DOUBLE_LOG10 "log10" (X) (RESULT) (DOUBLE) (DOUBLE)
:finfo CHDIR "chdir" (PATH) (V) (CHAR*) (INT)
:pinfo IOBUF-P (S) NIL NIL NIL NIL NIL NIL T
:finfo PC_TO_PROCEDURE_NAME "pc_to_procedure_name" (PC BUFFER) (LEN) (INT CHAR*) (INT)
:finfo OBJECT_SIZE "object_size" (PTR) (SIZE-IN-BYTES) (T) (INT)
:finfo INTEGER_SUBTRACT "integer_subtract" (X Y) (SUM) (T T) (T)
:finfo POW "pow" (X Y) (RESULT) (DOUBLE DOUBLE) (DOUBLE)
:pinfo DIRDESC-OFF (S) NIL NIL NIL (LAMBDA (S) (DECLARE) (BLOCK DIRDESC-OFF (C-STRUCT-REF S DIRDESC OFF))) NIL T T
:finfo DOUBLE_SQRT "sqrt" (X) (RESULT) (DOUBLE) (DOUBLE)
:finfo FILE_LENGTH "file_length" (FILE) (DATE) (FILE-PTR) (INT)
:finfo REMAINDER "remainder" (X Y) (REMAINDER) (DOUBLE DOUBLE) (DOUBLE)
:finfo FILE_WRITE_DATE "file_write_date" (FILENAME) (DATE) (CHAR*) (INT)
:finfo GC_CALL_COUNT "gc_call_count" NIL (C) NIL (INT)
:finfo FREE_HEAP_PAGES "free_heap_pages" NIL (RESULT) NIL (INT)
:finfo C_SYMBOL_VALUE "c_symbol_value" (NAME) (VALUE) (CHAR*) (T)
:finfo ALLOC_SHORTS "alloc_shorts" (LEN TYPE) (S) (INT INT) (T)
:finfo POPEN "popen" (COMMAND TYPE) (FILE) (CHAR* CHAR*) (FILE-PTR)
:finfo LEQ_P "leq_p" (X Y) (FLAG) (T T) (T)
:finfo FFLUSH "fflush" (STREAM) (STATUS) (FILE-PTR) (INT)
:finfo TOTAL_HEAP_PAGES "total_heap_pages" NIL (RESULT) NIL (INT)
:finfo C_SET_AREF "c_set_aref" (VALUE ARRAY INDICES) (RESULT) (T T T) (T)
:finfo HEAP_PAGE_SIZE "heap_page_size" NIL (RESULT) NIL (INT)
:finfo VREF "vref" (VECTOR INDEX) (RESULT) (T T) (T)
:finfo GETWD "getwd" (PATH) (V) (CHAR*) (INT)
:finfo FPUTC "fputc" (C STREAM) (STATUS) (CHAR FILE-PTR) (INT)
:finfo UNIX_DAYLIGHT_SAVINGS_TIME "unix_daylight_savings_time" NIL (RESULT) NIL (INT)
:finfo DOUBLE_COS "cos" (X) (R) (DOUBLE) (DOUBLE)
:finfo ADD "add" (X Y) (SUM) (T T) (T)
:finfo FPUTS "fputs" (C STREAM) (V) (CHAR* FILE-PTR) (VOID)
:pinfo DIRENT-FILENO (S) NIL NIL NIL (LAMBDA (S) (DECLARE) (BLOCK DIRENT-FILENO (C-STRUCT-REF S DIRENT FILENO))) NIL T T
:finfo FCLOSE "fclose" (STREAM) (STATUS) (FILE-PTR) (INT)
:finfo UNGETC "ungetc" (C STREAM) (C) (CHAR FILE-PTR) (INT)
:finfo CLOSEDIR "closedir" (DIRP) (R) (DIRDESC-PTR) (INT)
:finfo SUBTRACT "subtract" (X Y) (SUM) (T T) (T)
:finfo INITIALIZE_ARRAY "initialize_array" (A ELEMENT_TYPE_TAG ELEMENT_SIZE ELEMENT) (VALUE) (T INT INT T) (T)
:finfo DOUBLE_FLOOR "floor" (X) (RESULT) (DOUBLE) (DOUBLE)
:finfo WRITE_BYTE "write_byte" (DATA FILE ELEMENT-TYPE) (STATUS) (INT FILE-PTR INT) (INT)
:finfo HEAP_FRONTIER_LIMIT "heap_frontier_limit" NIL (RESULT) NIL (INT)
:finfo MAKE_SYMBOL "make_symbol" (NAME HASH-CODE) (SYM) (T T) (T)
:pinfo DIRENT-NAME (S) NIL NIL NIL (LAMBDA (S) (DECLARE) (BLOCK DIRENT-NAME (C-STRUCT-REF S DIRENT NAME))) NIL T T
:finfo GETPID "getpid" NIL (PID) NIL (INT)
:finfo COMMAND_LINE_ARGUMENT "command_line_argument" (N) (ARG) (INT) (T)
:pinfo DIRDESC-SIZE (S) NIL NIL NIL (LAMBDA (S) (DECLARE) (BLOCK DIRDESC-SIZE (C-STRUCT-REF S DIRDESC SIZE))) NIL T T
:pinfo MAKE-IOBUF (&KEY COUNT POINTER BASE BUFFER-SIZE FLAG FILE) NIL NIL NIL NIL NIL NIL T
:finfo DOUBLE_LOG "log" (X) (RESULT) (DOUBLE) (DOUBLE)
:finfo GEQ_P "geq_p" (X Y) (FLAG) (T T) (T)
:pinfo MAKE-DIRDESC (&KEY FILE-DESC LOC SIZE BSIZE OFF DATA-BUFFER) NIL NIL NIL NIL NIL NIL T
:finfo DOUBLE_TAN "tan" (X) (R) (DOUBLE) (DOUBLE)
:finfo FREE_STATIC_BYTES "free_static_bytes" NIL (RESULT) NIL (INT)
:finfo FILE_LISTEN "file_listen" (FILE) (FLAG) (FILE-PTR) (INT)
:finfo GETENV "getenv" (NAME) (VALUE) (CHAR*) (CHAR*)
:finfo EXIT "exit" (STATUS) (V) (INT) (VOID)
:pinfo IOBUF-COUNT (S) NIL NIL NIL (LAMBDA (S) (DECLARE) (BLOCK IOBUF-COUNT (C-STRUCT-REF S IOBUF COUNT))) NIL T T
:finfo SET_VREF "set_vref" (VALUE VECTOR INDEX) (RESULT) (T T T) (T)
:finfo USLEEP "usleep" (USECONDS) (R) (INT) (VOID)
:finfo STRTOD "strtod" (DIGITS EPTR) (F) (CHAR* INT) (DOUBLE)
:finfo DOUBLE_ATAN2 "atan2" (Y X) (R) (DOUBLE DOUBLE) (DOUBLE)
:finfo FLOAT_EXPONENT "float_exponent" (X) (RESULT) (DOUBLE) (INT)
:finfo SWITCH_TO_STATIC_SPACE "switch_to_static_space" NIL (V) NIL (VOID)
:finfo STRING_COLUMN "string_column" (STRING CURRENT) (NEW) (CHAR* INT) (INT)
:finfo STRTOL "strtol" (DIGITS EPTR BASE) (N) (CHAR* INT INT) (INT)
:finfo DOUBLE_ACOS "acos" (X) (R) (DOUBLE) (DOUBLE)
:finfo INTERNAL_REAL_TIME "internal_real_time" NIL (RESULT) NIL (INT)
:finfo SYSTEM "system" (COMMAND) (STATUS) (CHAR*) (INT)
:finfo INTERN_STATIC_SYMBOLS "intern_static_symbols" NIL (V) NIL (VOID)
:pinfo IOBUF-FILE (S) NIL NIL NIL (LAMBDA (S) (DECLARE) (BLOCK IOBUF-FILE (C-STRUCT-REF S IOBUF FILE))) NIL T T
:finfo FOPEN "fopen" (FNAME TYPE) (FILE) (CHAR* CHAR*) (FILE-PTR)
:finfo GET_FILE_PTR "get_file_ptr" (INDEX) (STREAM) (INT) (FILE-PTR)
:finfo UNIX_TIME_OF_DAY "unix_time_of_day" NIL (RESULT) NIL (INT)
:finfo SET_GC_MESSAGES "set_gc_messages" (N) (VALUE) (INT) (INT)
:pinfo DIRENT-NAMLEN (S) NIL NIL NIL (LAMBDA (S) (DECLARE) (BLOCK DIRENT-NAMLEN (C-STRUCT-REF S DIRENT NAMLEN))) NIL T T
:finfo C_SLEEP "sleep" (SECONDS) (DIFF) (INT) (INT)
:finfo SWITCH_TO_DYNAMIC_SPACE "switch_to_dynamic_space" NIL (V) NIL (VOID)
:finfo PCLOSE "pclose" (FILE) (STATUS) (FILE-PTR) (INT)
:finfo GETOSVERSION "getosversion" (NAME NAMELEN) (STATUS) (CHAR* INT) (INT)
:finfo INTEGER_ADD "integer_add" (X Y) (SUM) (T T) (T)
:finfo READ_VECTOR "read_vector" (FILE ELEMENT-SIZE VECTOR START END EOF-ERROR-P EOF-VALUE) (COUNT) (FILE-PTR INT T INT INT T T) (T)
:finfo PUTENV "putenv" (STRING) (VALUE) (CHAR*) (INT)
:finfo FTELL "ftell" (STREAM) (LENGTH) (FILE-PTR) (INT)
:finfo BIGNUM_DIV "bignum_div" (X Y) (Q) (T T) (T)
:finfo MAKE_EVAL_CLOSURE "make_eval_closure" (NAME FORMAL-ARGS BODY VENV FENV TENV BENV) (CLOSURE) (T T T T T T T) (T)
:finfo PRINT_DOUBLE_FLOAT "print_double_float" (N STREAM) (LEN) (DOUBLE FILE-PTR) (INT)
:pinfo DIRDESC-P (S) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_lsp_MAKE_2DIOBUF();
extern SYMBOL s_key_COUNT; 
extern SYMBOL s_key_POINTER; 
extern SYMBOL s_key_BASE; 
extern SYMBOL s_key_BUFFER_2DSIZE; 
extern SYMBOL s_key_FLAG; 
extern SYMBOL s_key_FILE; 
extern SYMBOL s_lsp_NEW_2DFPTR; 
extern LP p_lsp_IOBUF_2DP();
extern SYMBOL s_lsp_T; 
extern LP p_lsp_IOBUF_2DCOUNT();
extern LP p_lsp_IOBUF_2DPOINTER();
extern LP p_lsp_IOBUF_2DBASE();
extern LP p_lsp_IOBUF_2DBUFFER_2DSIZE();
extern LP p_lsp_IOBUF_2DFLAG();
extern LP p_lsp_IOBUF_2DFILE();
extern LP p_lsp_MAKE_2DDIRDESC();
extern SYMBOL s_key_FILE_2DDESC; 
extern SYMBOL s_key_LOC; 
extern SYMBOL s_key_SIZE; 
extern SYMBOL s_key_BSIZE; 
extern SYMBOL s_key_OFF; 
extern SYMBOL s_key_DATA_2DBUFFER; 
extern LP p_lsp_DIRDESC_2DP();
extern LP p_lsp_DIRDESC_2DFILE_2DDESC();
extern LP p_lsp_DIRDESC_2DLOC();
extern LP p_lsp_DIRDESC_2DSIZE();
extern LP p_lsp_DIRDESC_2DBSIZE();
extern LP p_lsp_DIRDESC_2DOFF();
extern LP p_lsp_DIRDESC_2DDATA_2DBUFFER();
extern LP p_lsp_MAKE_2DDIRENT();
extern SYMBOL s_key_OFFSET; 
extern SYMBOL s_key_FILENO; 
extern SYMBOL s_key_RECLEN; 
extern SYMBOL s_key_NAMLEN; 
extern SYMBOL s_key_NAME; 
extern LP p_lsp_DIRENT_2DP();
extern LP p_lsp_DIRENT_2DOFFSET();
extern LP p_lsp_DIRENT_2DFILENO();
extern LP p_lsp_DIRENT_2DRECLEN();
extern LP p_lsp_DIRENT_2DNAMLEN();
extern LP p_lsp_DIRENT_2DNAME();
extern LP p_lsp_OPENDIR();
extern SYMBOL s_lsp_DIRDESC; 
extern LP p_lsp_CLOSEDIR();
extern LP p_lsp_READDIR();
extern SYMBOL s_lsp_DIRENT; 
extern LP p_lsp_ALLOC_5FMEMORY();
extern LP p_lsp_ALLOC_5FWORDS();
extern LP p_lsp_ALLOC_5FSHORTS();
extern LP p_lsp_ALLOC_5FBYTES();
extern LP p_lsp_ALLOC_5FBITS();
extern LP p_lsp_C_5FCONS();
extern LP p_lsp_LISP_5FBREAK();
extern LP p_lsp_LISP_5FDEBUG();
extern LP p_lsp_COMMAND_5FLINE_5FARGUMENT();
extern LP p_lsp_APPLY_5FFUNCTION();
extern LP p_lsp_INITIALIZE_5FARRAY();
extern LP p_lsp_PRINT_5FDOUBLE_5FFLOAT();
extern LP p_lsp_DOUBLE_5FFLOAT_5FTO_5FSTRING();
extern LP p_lsp_ILOGB();
extern LP p_lsp_ADD();
extern LP p_lsp_MULTIPLY();
extern LP p_lsp_SUBTRACT();
extern LP p_lsp_DIVIDE();
extern LP p_lsp_INTEGER_5FADD();
extern LP p_lsp_INTEGER_5FSUBTRACT();
extern LP p_lsp_INTEGER_5FMULTIPLY();
extern LP p_lsp_C_5FEQL();
extern LP p_lsp_NUM_5FEQUAL_5FP();
extern LP p_lsp_GREATERP();
extern LP p_lsp_GEQ_5FP();
extern LP p_lsp_LESSP();
extern LP p_lsp_LEQ_5FP();
extern LP p_lsp_MAKE_5FSYMBOL();
extern LP p_lsp_FOPEN();
extern SYMBOL s_lsp_IOBUF; 
extern LP p_lsp_FDOPEN();
extern LP p_lsp_FCLOSE();
extern LP p_lsp_FFLUSH();
extern LP p_lsp_FSEEK();
extern LP p_lsp_FTELL();
extern LP p_lsp_UNLINK();
extern LP p_lsp_FGETC();
extern LP p_lsp_UNGETC();
extern LP p_lsp_FPUTC();
extern LP p_lsp_FPUTS();
extern LP p_lsp_GET_5FFILE_5FPTR();
extern LP p_lsp_STRTOL();
extern LP p_lsp_STRTOD();
extern LP p_lsp_STRCMP();
extern LP p_lsp_EXIT();
extern LP p_lsp_SYSTEM();
extern LP p_lsp_POPEN();
extern LP p_lsp_PCLOSE();
extern LP p_lsp_STRING_5FCOLUMN();
extern LP p_lsp_FIXNUM_5FTO_5FBIGNUM();
extern LP p_lsp_BIGNUM_5FDIV();
extern LP p_lsp_BIGNUM_5FREM();
extern LP p_lsp_BIGNUM_5FTO_5FDOUBLE();
extern LP p_lsp_INT_5FLENGTH();
extern LP p_lsp_DOUBLE_5FTRUNCATE();
extern LP p_lsp_DOUBLE_5FFLOOR();
extern LP p_lsp_CEIL();
extern LP p_lsp_FLOAT_5FSIGNIFICAND();
extern LP p_lsp_FLOAT_5FEXPONENT();
extern LP p_lsp_LDEXP();
extern LP p_lsp_FMOD();
extern LP p_lsp_RINT();
extern LP p_lsp_REMAINDER();
extern LP p_lsp_POW();
extern LP p_lsp_DOUBLE_5FLOG();
extern LP p_lsp_DOUBLE_5FLOG10();
extern LP p_lsp_DOUBLE_5FSQRT();
extern LP p_lsp_DOUBLE_5FEXP();
extern LP p_lsp_DOUBLE_5FSIN();
extern LP p_lsp_DOUBLE_5FCOS();
extern LP p_lsp_DOUBLE_5FTAN();
extern LP p_lsp_DOUBLE_5FASIN();
extern LP p_lsp_DOUBLE_5FACOS();
extern LP p_lsp_DOUBLE_5FATAN2();
extern LP p_lsp_HEAP_5FSTART();
extern LP p_lsp_HEAP_5FFRONTIER();
extern LP p_lsp_HEAP_5FFRONTIER_5FLIMIT();
extern LP p_lsp_HEAP_5FPAGE_5FSIZE();
extern LP p_lsp_TOTAL_5FHEAP_5FPAGES();
extern LP p_lsp_FREE_5FHEAP_5FPAGES();
extern LP p_lsp_TOTAL_5FSTATIC_5FPAGES();
extern LP p_lsp_FREE_5FSTATIC_5FBYTES();
extern LP p_lsp_UNIX_5FTIME_5FOF_5FDAY();
extern LP p_lsp_UNIX_5FTIMEZONE();
extern LP p_lsp_UNIX_5FDAYLIGHT_5FSAVINGS_5FTIME();
extern LP p_lsp_INTERNAL_5FREAL_5FTIME();
extern LP p_lsp_INTERNAL_5FSYSTEM_5FRUN_5FTIME();
extern LP p_lsp_INTERNAL_5FUSER_5FRUN_5FTIME();
extern LP p_lsp_C_5FSLEEP();
extern LP p_lsp_C_5FAREF();
extern LP p_lsp_C_5FSET_5FAREF();
extern LP p_lsp_VREF();
extern LP p_lsp_SET_5FVREF();
extern LP p_lsp_CONNECT_5FTO_5FSERVER();
extern LP p_lsp_PC_5FTO_5FPROCEDURE_5FNAME();
extern LP p_lsp_LOAD_5FCOMPILED_5FFILE();
extern LP p_lsp_C_5FSYMBOL_5FVALUE();
extern LP p_lsp_FULL_5FGC();
extern LP p_lsp_GC_5FCALL_5FCOUNT();
extern LP p_lsp_SET_5FGC_5FMESSAGES();
extern LP p_lsp_INTERN_5FSTATIC_5FSYMBOLS();
extern LP p_lsp_SWITCH_5FTO_5FSTATIC_5FSPACE();
extern LP p_lsp_SWITCH_5FTO_5FDYNAMIC_5FSPACE();
extern LP p_lsp_OBJECT_5FSIZE();
extern LP p_lsp_FILE_5FWRITE_5FDATE();
extern LP p_lsp_PROBE_5FFILE();
extern LP p_lsp_FILE_5FLENGTH();
extern LP p_lsp_FILE_5FLISTEN();
extern LP p_lsp_WRITE_5FBYTE();
extern LP p_lsp_READ_5FBYTE();
extern LP p_lsp_READ_5FVECTOR();
extern LP p_lsp_WRITE_5FVECTOR();
extern LP p_lsp_CHDIR();
extern LP p_lsp_GETPID();
extern LP p_lsp_GETENV();
extern LP p_lsp_PUTENV();
extern LP p_lsp_CLOSURE_5FOE();
extern LP p_lsp_MAKE_5FEVAL_5FCLOSURE();
extern LP p_lsp_GETHOSTNAME();
extern LP p_lsp_GETOSVERSION();
extern LP p_lsp_GETWD();
extern LP p_lsp_INITSTATE();
extern LP p_lsp_C_5FRANDOM();
extern LP p_lsp_SETSTATE();
extern LP p_lsp_USLEEP();
extern LP p_lsp_FOREIGN_5FINIT644();
extern SYMBOL s_lsp_DIRENT_2DPTR; 


extern void usleep();
extern void setstate();
extern unsigned long random();
extern void initstate();
extern int getwd();
extern int getosversion();
extern int gethostname();
extern LP make_eval_closure();
extern LP closure_oe();
extern int putenv();
extern char * getenv();
extern int getpid();
extern int chdir();
extern LP write_vector();
extern LP read_vector();
extern LP read_byte();
extern int write_byte();
extern int file_listen();
extern int file_length();
extern LP probe_file();
extern int file_write_date();
extern int object_size();
extern void switch_to_dynamic_space();
extern void switch_to_static_space();
extern void intern_static_symbols();
extern int set_gc_messages();
extern int gc_call_count();
extern void full_gc();
extern LP c_symbol_value();
extern int load_compiled_file();
extern int pc_to_procedure_name();
extern int connect_to_server();
extern LP set_vref();
extern LP vref();
extern LP c_set_aref();
extern LP c_aref();
extern int sleep();
extern int internal_user_run_time();
extern int internal_system_run_time();
extern int internal_real_time();
extern int unix_daylight_savings_time();
extern int unix_timezone();
extern int unix_time_of_day();
extern int free_static_bytes();
extern int total_static_pages();
extern int free_heap_pages();
extern int total_heap_pages();
extern int heap_page_size();
extern int heap_frontier_limit();
extern int heap_frontier();
extern int heap_start();
extern double atan2();
extern double acos();
extern double asin();
extern double tan();
extern double cos();
extern double sin();
extern double exp();
extern double sqrt();
extern double log10();
extern double log();
extern double pow();
extern double remainder();
extern double rint();
extern double fmod();
extern double ldexp();
extern int float_exponent();
extern double float_significand();
extern double ceil();
extern double floor();
extern int double_truncate();
extern int int_length();
extern double bignum_to_double();
extern LP bignum_rem();
extern LP bignum_div();
extern LP fixnum_to_bignum();
extern int string_column();
extern int pclose();
extern struct IOBUF * popen();
extern int system();
extern void exit();
extern int strcmp();
extern double strtod();
extern int strtol();
extern struct IOBUF * get_file_ptr();
extern void fputs();
extern int fputc();
extern int ungetc();
extern int fgetc();
extern int unlink();
extern int ftell();
extern int fseek();
extern int fflush();
extern int fclose();
extern struct IOBUF * fdopen();
extern struct IOBUF * fopen();
extern LP make_symbol();
extern LP leq_p();
extern LP lessp();
extern LP geq_p();
extern LP greaterp();
extern LP num_equal_p();
extern LP c_eql();
extern LP integer_multiply();
extern LP integer_subtract();
extern LP integer_add();
extern LP divide();
extern LP subtract();
extern LP multiply();
extern LP add();
extern int ilogb();
extern int double_float_to_string();
extern int print_double_float();
extern LP initialize_array();
extern LP apply_function();
extern LP command_line_argument();
extern void lisp_debug();
extern void lisp_break();
extern LP c_cons();
extern LP alloc_bits();
extern LP alloc_bytes();
extern LP alloc_shorts();
extern LP alloc_words();
extern LP alloc_memory();
extern struct DIRENT * readdir();
extern int closedir();
extern struct DIRDESC * opendir();
struct DIRENT {
int OFFSET;
int FILENO;
short RECLEN;
short NAMLEN;
char NAME[256];
};
struct DIRDESC {
int FILE_2DDESC;
int LOC;
int SIZE;
int BSIZE;
int OFF;
char *DATA_2DBUFFER;
};
struct IOBUF {
int COUNT;
char *POINTER;
char *BASE;
int BUFFER_2DSIZE;
short FLAG;
char FILE;
};


LP p_lsp_MAKE_2DIOBUF(va_alist) va_dcl
{
LP v_S_8; LP v_KEYS1454_6; LP v_FILE_5; 
LP v_FLAG_4; LP v_BUFFER_2DSIZE_3; LP v_BASE_2; 
LP v_POINTER_1; LP v_COUNT_0; 
LP t0; LP t1; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
DYNAMIC_RESTIFY(v_KEYS1454_6,1,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_COUNT_0,LREF(s_key_COUNT),v_KEYS1454_6)
v_COUNT_0 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_POINTER_1,LREF(s_key_POINTER),v_KEYS1454_6)
v_POINTER_1 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_BASE_2,LREF(s_key_BASE),v_KEYS1454_6)
v_BASE_2 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_BUFFER_2DSIZE_3,LREF(s_key_BUFFER_2DSIZE),v_KEYS1454_6)
v_BUFFER_2DSIZE_3 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_FLAG_4,LREF(s_key_FLAG),v_KEYS1454_6)
v_FLAG_4 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_FILE_5,LREF(s_key_FILE),v_KEYS1454_6)
v_FILE_5 = NIL;
END_KEY_INIT
END_VAR_ARGS;
t0 = sizeof(struct IOBUF);
v_S_8 = ICALL(s_lsp_NEW_2DFPTR) (1, t0);
return(v_S_8);
}

LP p_lsp_IOBUF_2DP(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; 
if (argc != 1) wna(argc,1);
return(LREF(s_lsp_T));
}

LP p_lsp_IOBUF_2DCOUNT(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX((((struct IOBUF *) (RAW_FPTR(v_S_0)))->COUNT));
return(t0);
}

LP p_lsp_IOBUF_2DPOINTER(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = c_to_lisp_string((LP) (((struct IOBUF *) (RAW_FPTR(v_S_0)))->POINTER));
return(t0);
}

LP p_lsp_IOBUF_2DBASE(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = c_to_lisp_string((LP) (((struct IOBUF *) (RAW_FPTR(v_S_0)))->BASE));
return(t0);
}

LP p_lsp_IOBUF_2DBUFFER_2DSIZE(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX((((struct IOBUF *) (RAW_FPTR(v_S_0)))->BUFFER_2DSIZE));
return(t0);
}

LP p_lsp_IOBUF_2DFLAG(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX((((struct IOBUF *) (RAW_FPTR(v_S_0)))->FLAG));
return(t0);
}

LP p_lsp_IOBUF_2DFILE(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = NEW_CHAR((((struct IOBUF *) (RAW_FPTR(v_S_0)))->FILE));
return(t0);
}

LP p_lsp_MAKE_2DDIRDESC(va_alist) va_dcl
{
LP v_S_8; LP v_KEYS1455_6; LP v_DATA_2DBUFFER_5; 
LP v_OFF_4; LP v_BSIZE_3; LP v_SIZE_2; 
LP v_LOC_1; LP v_FILE_2DDESC_0; 
LP t0; LP t1; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
DYNAMIC_RESTIFY(v_KEYS1455_6,1,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_FILE_2DDESC_0,LREF(s_key_FILE_2DDESC),v_KEYS1455_6)
v_FILE_2DDESC_0 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_LOC_1,LREF(s_key_LOC),v_KEYS1455_6)
v_LOC_1 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_SIZE_2,LREF(s_key_SIZE),v_KEYS1455_6)
v_SIZE_2 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_BSIZE_3,LREF(s_key_BSIZE),v_KEYS1455_6)
v_BSIZE_3 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_OFF_4,LREF(s_key_OFF),v_KEYS1455_6)
v_OFF_4 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_DATA_2DBUFFER_5,LREF(s_key_DATA_2DBUFFER),v_KEYS1455_6)
v_DATA_2DBUFFER_5 = NIL;
END_KEY_INIT
END_VAR_ARGS;
t0 = sizeof(struct DIRDESC);
v_S_8 = ICALL(s_lsp_NEW_2DFPTR) (1, t0);
return(v_S_8);
}

LP p_lsp_DIRDESC_2DP(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; 
if (argc != 1) wna(argc,1);
return(LREF(s_lsp_T));
}

LP p_lsp_DIRDESC_2DFILE_2DDESC(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX((((struct DIRDESC *) (RAW_FPTR(v_S_0)))->FILE_2DDESC));
return(t0);
}

LP p_lsp_DIRDESC_2DLOC(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX((((struct DIRDESC *) (RAW_FPTR(v_S_0)))->LOC));
return(t0);
}

LP p_lsp_DIRDESC_2DSIZE(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX((((struct DIRDESC *) (RAW_FPTR(v_S_0)))->SIZE));
return(t0);
}

LP p_lsp_DIRDESC_2DBSIZE(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX((((struct DIRDESC *) (RAW_FPTR(v_S_0)))->BSIZE));
return(t0);
}

LP p_lsp_DIRDESC_2DOFF(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX((((struct DIRDESC *) (RAW_FPTR(v_S_0)))->OFF));
return(t0);
}

LP p_lsp_DIRDESC_2DDATA_2DBUFFER(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = c_to_lisp_string((LP) (((struct DIRDESC *) (RAW_FPTR(v_S_0)))->DATA_2DBUFFER));
return(t0);
}

LP p_lsp_MAKE_2DDIRENT(va_alist) va_dcl
{
LP v_S_7; LP v_KEYS1456_5; LP v_NAME_4; 
LP v_NAMLEN_3; LP v_RECLEN_2; LP v_FILENO_1; 
LP v_OFFSET_0; 
LP t0; LP t1; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
DYNAMIC_RESTIFY(v_KEYS1456_5,1,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_OFFSET_0,LREF(s_key_OFFSET),v_KEYS1456_5)
v_OFFSET_0 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_FILENO_1,LREF(s_key_FILENO),v_KEYS1456_5)
v_FILENO_1 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_RECLEN_2,LREF(s_key_RECLEN),v_KEYS1456_5)
v_RECLEN_2 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_NAMLEN_3,LREF(s_key_NAMLEN),v_KEYS1456_5)
v_NAMLEN_3 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_NAME_4,LREF(s_key_NAME),v_KEYS1456_5)
v_NAME_4 = NIL;
END_KEY_INIT
END_VAR_ARGS;
t0 = sizeof(struct DIRENT);
v_S_7 = ICALL(s_lsp_NEW_2DFPTR) (1, t0);
return(v_S_7);
}

LP p_lsp_DIRENT_2DP(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; 
if (argc != 1) wna(argc,1);
return(LREF(s_lsp_T));
}

LP p_lsp_DIRENT_2DOFFSET(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX((((struct DIRENT *) (RAW_FPTR(v_S_0)))->OFFSET));
return(t0);
}

LP p_lsp_DIRENT_2DFILENO(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX((((struct DIRENT *) (RAW_FPTR(v_S_0)))->FILENO));
return(t0);
}

LP p_lsp_DIRENT_2DRECLEN(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX((((struct DIRENT *) (RAW_FPTR(v_S_0)))->RECLEN));
return(t0);
}

LP p_lsp_DIRENT_2DNAMLEN(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX((((struct DIRENT *) (RAW_FPTR(v_S_0)))->NAMLEN));
return(t0);
}

LP p_lsp_DIRENT_2DNAME(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = c_to_lisp_string((LP) (((struct DIRENT *) (RAW_FPTR(v_S_0)))->NAME));
return(t0);
}

LP p_lsp_OPENDIR(argc, v_DIRNAME_0)
      ARGC argc;  LP v_DIRNAME_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = NEW_FPTR(LREF(s_lsp_DIRDESC), opendir(lisp_to_c_array(v_DIRNAME_0)));
return(t0);
}

LP p_lsp_CLOSEDIR(argc, v_DIRP_0)
      ARGC argc;  LP v_DIRP_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX(closedir(RAW_FPTR(v_DIRP_0)));
return(t0);
}

LP p_lsp_READDIR(argc, v_DIRP_0)
      ARGC argc;  LP v_DIRP_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = NEW_FPTR(LREF(s_lsp_DIRENT), readdir(RAW_FPTR(v_DIRP_0)));
return(t0);
}

LP p_lsp_ALLOC_5FMEMORY(argc, v_LEN_0, v_WORD_2DSIZE_1, v_TYPE_2)
      ARGC argc;  LP v_LEN_0; LP v_WORD_2DSIZE_1; LP v_TYPE_2;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 3) wna(argc,3);
t0 = (alloc_memory(FX_TO_INT(v_LEN_0), FX_TO_INT(v_WORD_2DSIZE_1), FX_TO_INT(v_TYPE_2)));
return(t0);
}

LP p_lsp_ALLOC_5FWORDS(argc, v_LEN_0, v_TYPE_1)
      ARGC argc;  LP v_LEN_0; LP v_TYPE_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = (alloc_words(FX_TO_INT(v_LEN_0), FX_TO_INT(v_TYPE_1)));
return(t0);
}

LP p_lsp_ALLOC_5FSHORTS(argc, v_LEN_0, v_TYPE_1)
      ARGC argc;  LP v_LEN_0; LP v_TYPE_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = (alloc_shorts(FX_TO_INT(v_LEN_0), FX_TO_INT(v_TYPE_1)));
return(t0);
}

LP p_lsp_ALLOC_5FBYTES(argc, v_LEN_0, v_TYPE_1)
      ARGC argc;  LP v_LEN_0; LP v_TYPE_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = (alloc_bytes(FX_TO_INT(v_LEN_0), FX_TO_INT(v_TYPE_1)));
return(t0);
}

LP p_lsp_ALLOC_5FBITS(argc, v_LEN_0, v_TYPE_1)
      ARGC argc;  LP v_LEN_0; LP v_TYPE_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = (alloc_bits(FX_TO_INT(v_LEN_0), FX_TO_INT(v_TYPE_1)));
return(t0);
}

LP p_lsp_C_5FCONS(argc, v_CAR_0, v_CDR_1)
      ARGC argc;  LP v_CAR_0; LP v_CDR_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = (c_cons((v_CAR_0), (v_CDR_1)));
return(t0);
}

LP p_lsp_LISP_5FBREAK(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
(lisp_break());
return(NIL);
}

LP p_lsp_LISP_5FDEBUG(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
(lisp_debug());
return(NIL);
}

LP p_lsp_COMMAND_5FLINE_5FARGUMENT(argc, v_N_0)
      ARGC argc;  LP v_N_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = (command_line_argument(FX_TO_INT(v_N_0)));
return(t0);
}

LP p_lsp_APPLY_5FFUNCTION(argc, v_ARGC_0, v_F_1, v_L_2)
      ARGC argc;  LP v_ARGC_0; LP v_F_1; LP v_L_2;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 3) wna(argc,3);
t0 = (apply_function((v_ARGC_0), (v_F_1), (v_L_2)));
return(t0);
}

LP p_lsp_INITIALIZE_5FARRAY(argc, v_A_0, v_ELEMENT_5FTYPE_5FTAG_1, v_ELEMENT_5FSIZE_2, v_ELEMENT_3)
      ARGC argc;  LP v_A_0; LP v_ELEMENT_5FTYPE_5FTAG_1; LP v_ELEMENT_5FSIZE_2; LP v_ELEMENT_3;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 4) wna(argc,4);
t0 = (initialize_array((v_A_0), FX_TO_INT(v_ELEMENT_5FTYPE_5FTAG_1), FX_TO_INT(v_ELEMENT_5FSIZE_2), (v_ELEMENT_3)));
return(t0);
}

LP p_lsp_PRINT_5FDOUBLE_5FFLOAT(argc, v_N_0, v_STREAM_1)
      ARGC argc;  LP v_N_0; LP v_STREAM_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = INT_TO_FX(print_double_float(RAW_FLOAT(v_N_0), RAW_FPTR(v_STREAM_1)));
return(t0);
}

LP p_lsp_DOUBLE_5FFLOAT_5FTO_5FSTRING(argc, v_N_0, v_STREAM_1)
      ARGC argc;  LP v_N_0; LP v_STREAM_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = INT_TO_FX(double_float_to_string(RAW_FLOAT(v_N_0), lisp_to_c_array(v_STREAM_1)));
return(t0);
}

LP p_lsp_ILOGB(argc, v_F_0)
      ARGC argc;  LP v_F_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX(ilogb(RAW_FLOAT(v_F_0)));
return(t0);
}

LP p_lsp_ADD(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = (add((v_X_0), (v_Y_1)));
return(t0);
}

LP p_lsp_MULTIPLY(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = (multiply((v_X_0), (v_Y_1)));
return(t0);
}

LP p_lsp_SUBTRACT(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = (subtract((v_X_0), (v_Y_1)));
return(t0);
}

LP p_lsp_DIVIDE(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = (divide((v_X_0), (v_Y_1)));
return(t0);
}

LP p_lsp_INTEGER_5FADD(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = (integer_add((v_X_0), (v_Y_1)));
return(t0);
}

LP p_lsp_INTEGER_5FSUBTRACT(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = (integer_subtract((v_X_0), (v_Y_1)));
return(t0);
}

LP p_lsp_INTEGER_5FMULTIPLY(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = (integer_multiply((v_X_0), (v_Y_1)));
return(t0);
}

LP p_lsp_C_5FEQL(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = (c_eql((v_X_0), (v_Y_1)));
return(t0);
}

LP p_lsp_NUM_5FEQUAL_5FP(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = (num_equal_p((v_X_0), (v_Y_1)));
return(t0);
}

LP p_lsp_GREATERP(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = (greaterp((v_X_0), (v_Y_1)));
return(t0);
}

LP p_lsp_GEQ_5FP(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = (geq_p((v_X_0), (v_Y_1)));
return(t0);
}

LP p_lsp_LESSP(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = (lessp((v_X_0), (v_Y_1)));
return(t0);
}

LP p_lsp_LEQ_5FP(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = (leq_p((v_X_0), (v_Y_1)));
return(t0);
}

LP p_lsp_MAKE_5FSYMBOL(argc, v_NAME_0, v_HASH_2DCODE_1)
      ARGC argc;  LP v_NAME_0; LP v_HASH_2DCODE_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = (make_symbol((v_NAME_0), (v_HASH_2DCODE_1)));
return(t0);
}

LP p_lsp_FOPEN(argc, v_FNAME_0, v_TYPE_1)
      ARGC argc;  LP v_FNAME_0; LP v_TYPE_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = NEW_FPTR(LREF(s_lsp_IOBUF), fopen(lisp_to_c_array(v_FNAME_0), lisp_to_c_array(v_TYPE_1)));
return(t0);
}

LP p_lsp_FDOPEN(argc, v_FILE_2DDESC_0, v_TYPE_1)
      ARGC argc;  LP v_FILE_2DDESC_0; LP v_TYPE_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = NEW_FPTR(LREF(s_lsp_IOBUF), fdopen(FX_TO_INT(v_FILE_2DDESC_0), lisp_to_c_array(v_TYPE_1)));
return(t0);
}

LP p_lsp_FCLOSE(argc, v_STREAM_0)
      ARGC argc;  LP v_STREAM_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX(fclose(RAW_FPTR(v_STREAM_0)));
return(t0);
}

LP p_lsp_FFLUSH(argc, v_STREAM_0)
      ARGC argc;  LP v_STREAM_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX(fflush(RAW_FPTR(v_STREAM_0)));
return(t0);
}

LP p_lsp_FSEEK(argc, v_STREAM_0, v_OFFSET_1, v_FLAG_2)
      ARGC argc;  LP v_STREAM_0; LP v_OFFSET_1; LP v_FLAG_2;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 3) wna(argc,3);
t0 = INT_TO_FX(fseek(RAW_FPTR(v_STREAM_0), FX_TO_INT(v_OFFSET_1), FX_TO_INT(v_FLAG_2)));
return(t0);
}

LP p_lsp_FTELL(argc, v_STREAM_0)
      ARGC argc;  LP v_STREAM_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX(ftell(RAW_FPTR(v_STREAM_0)));
return(t0);
}

LP p_lsp_UNLINK(argc, v_PATH_0)
      ARGC argc;  LP v_PATH_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX(unlink(lisp_to_c_array(v_PATH_0)));
return(t0);
}

LP p_lsp_FGETC(argc, v_STREAM_0)
      ARGC argc;  LP v_STREAM_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX(fgetc(RAW_FPTR(v_STREAM_0)));
return(t0);
}

LP p_lsp_UNGETC(argc, v_C_0, v_STREAM_1)
      ARGC argc;  LP v_C_0; LP v_STREAM_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = INT_TO_FX(ungetc(RAW_CHAR(v_C_0), RAW_FPTR(v_STREAM_1)));
return(t0);
}

LP p_lsp_FPUTC(argc, v_C_0, v_STREAM_1)
      ARGC argc;  LP v_C_0; LP v_STREAM_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = INT_TO_FX(fputc(RAW_CHAR(v_C_0), RAW_FPTR(v_STREAM_1)));
return(t0);
}

LP p_lsp_FPUTS(argc, v_C_0, v_STREAM_1)
      ARGC argc;  LP v_C_0; LP v_STREAM_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
(fputs(lisp_to_c_array(v_C_0), RAW_FPTR(v_STREAM_1)));
return(NIL);
}

LP p_lsp_GET_5FFILE_5FPTR(argc, v_INDEX_0)
      ARGC argc;  LP v_INDEX_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = NEW_FPTR(LREF(s_lsp_IOBUF), get_file_ptr(FX_TO_INT(v_INDEX_0)));
return(t0);
}

LP p_lsp_STRTOL(argc, v_DIGITS_0, v_EPTR_1, v_BASE_2)
      ARGC argc;  LP v_DIGITS_0; LP v_EPTR_1; LP v_BASE_2;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 3) wna(argc,3);
t0 = INT_TO_FX(strtol(lisp_to_c_array(v_DIGITS_0), FX_TO_INT(v_EPTR_1), FX_TO_INT(v_BASE_2)));
return(t0);
}

LP p_lsp_STRTOD(argc, v_DIGITS_0, v_EPTR_1)
      ARGC argc;  LP v_DIGITS_0; LP v_EPTR_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = NEW_FLOAT(strtod(lisp_to_c_array(v_DIGITS_0), FX_TO_INT(v_EPTR_1)));
return(t0);
}

LP p_lsp_STRCMP(argc, v_S1_0, v_S2_1)
      ARGC argc;  LP v_S1_0; LP v_S2_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = INT_TO_FX(strcmp(lisp_to_c_array(v_S1_0), lisp_to_c_array(v_S2_1)));
return(t0);
}

LP p_lsp_EXIT(argc, v_STATUS_0)
      ARGC argc;  LP v_STATUS_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
(exit(FX_TO_INT(v_STATUS_0)));
return(NIL);
}

LP p_lsp_SYSTEM(argc, v_COMMAND_0)
      ARGC argc;  LP v_COMMAND_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX(system(lisp_to_c_array(v_COMMAND_0)));
return(t0);
}

LP p_lsp_POPEN(argc, v_COMMAND_0, v_TYPE_1)
      ARGC argc;  LP v_COMMAND_0; LP v_TYPE_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = NEW_FPTR(LREF(s_lsp_IOBUF), popen(lisp_to_c_array(v_COMMAND_0), lisp_to_c_array(v_TYPE_1)));
return(t0);
}

LP p_lsp_PCLOSE(argc, v_FILE_0)
      ARGC argc;  LP v_FILE_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX(pclose(RAW_FPTR(v_FILE_0)));
return(t0);
}

LP p_lsp_STRING_5FCOLUMN(argc, v_STRING_0, v_CURRENT_1)
      ARGC argc;  LP v_STRING_0; LP v_CURRENT_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = INT_TO_FX(string_column(lisp_to_c_array(v_STRING_0), FX_TO_INT(v_CURRENT_1)));
return(t0);
}

LP p_lsp_FIXNUM_5FTO_5FBIGNUM(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = (fixnum_to_bignum((v_X_0)));
return(t0);
}

LP p_lsp_BIGNUM_5FDIV(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = (bignum_div((v_X_0), (v_Y_1)));
return(t0);
}

LP p_lsp_BIGNUM_5FREM(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = (bignum_rem((v_X_0), (v_Y_1)));
return(t0);
}

LP p_lsp_BIGNUM_5FTO_5FDOUBLE(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = NEW_FLOAT(bignum_to_double((v_X_0)));
return(t0);
}

LP p_lsp_INT_5FLENGTH(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX(int_length(FX_TO_INT(v_X_0)));
return(t0);
}

LP p_lsp_DOUBLE_5FTRUNCATE(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = INT_TO_FX(double_truncate(RAW_FLOAT(v_X_0), RAW_FLOAT(v_Y_1)));
return(t0);
}

LP p_lsp_DOUBLE_5FFLOOR(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = NEW_FLOAT(floor(RAW_FLOAT(v_X_0)));
return(t0);
}

LP p_lsp_CEIL(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = NEW_FLOAT(ceil(RAW_FLOAT(v_X_0)));
return(t0);
}

LP p_lsp_FLOAT_5FSIGNIFICAND(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = NEW_FLOAT(float_significand(RAW_FLOAT(v_X_0)));
return(t0);
}

LP p_lsp_FLOAT_5FEXPONENT(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX(float_exponent(RAW_FLOAT(v_X_0)));
return(t0);
}

LP p_lsp_LDEXP(argc, v_SIGNIFICAND_0, v_EXPONENT_1)
      ARGC argc;  LP v_SIGNIFICAND_0; LP v_EXPONENT_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = NEW_FLOAT(ldexp(RAW_FLOAT(v_SIGNIFICAND_0), FX_TO_INT(v_EXPONENT_1)));
return(t0);
}

LP p_lsp_FMOD(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = NEW_FLOAT(fmod(RAW_FLOAT(v_X_0), RAW_FLOAT(v_Y_1)));
return(t0);
}

LP p_lsp_RINT(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = NEW_FLOAT(rint(RAW_FLOAT(v_X_0)));
return(t0);
}

LP p_lsp_REMAINDER(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = NEW_FLOAT(remainder(RAW_FLOAT(v_X_0), RAW_FLOAT(v_Y_1)));
return(t0);
}

LP p_lsp_POW(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = NEW_FLOAT(pow(RAW_FLOAT(v_X_0), RAW_FLOAT(v_Y_1)));
return(t0);
}

LP p_lsp_DOUBLE_5FLOG(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = NEW_FLOAT(log(RAW_FLOAT(v_X_0)));
return(t0);
}

LP p_lsp_DOUBLE_5FLOG10(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = NEW_FLOAT(log10(RAW_FLOAT(v_X_0)));
return(t0);
}

LP p_lsp_DOUBLE_5FSQRT(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = NEW_FLOAT(sqrt(RAW_FLOAT(v_X_0)));
return(t0);
}

LP p_lsp_DOUBLE_5FEXP(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = NEW_FLOAT(exp(RAW_FLOAT(v_X_0)));
return(t0);
}

LP p_lsp_DOUBLE_5FSIN(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = NEW_FLOAT(sin(RAW_FLOAT(v_X_0)));
return(t0);
}

LP p_lsp_DOUBLE_5FCOS(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = NEW_FLOAT(cos(RAW_FLOAT(v_X_0)));
return(t0);
}

LP p_lsp_DOUBLE_5FTAN(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = NEW_FLOAT(tan(RAW_FLOAT(v_X_0)));
return(t0);
}

LP p_lsp_DOUBLE_5FASIN(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = NEW_FLOAT(asin(RAW_FLOAT(v_X_0)));
return(t0);
}

LP p_lsp_DOUBLE_5FACOS(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = NEW_FLOAT(acos(RAW_FLOAT(v_X_0)));
return(t0);
}

LP p_lsp_DOUBLE_5FATAN2(argc, v_Y_0, v_X_1)
      ARGC argc;  LP v_Y_0; LP v_X_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = NEW_FLOAT(atan2(RAW_FLOAT(v_Y_0), RAW_FLOAT(v_X_1)));
return(t0);
}

LP p_lsp_HEAP_5FSTART(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
t0 = INT_TO_FX(heap_start());
return(t0);
}

LP p_lsp_HEAP_5FFRONTIER(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
t0 = INT_TO_FX(heap_frontier());
return(t0);
}

LP p_lsp_HEAP_5FFRONTIER_5FLIMIT(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
t0 = INT_TO_FX(heap_frontier_limit());
return(t0);
}

LP p_lsp_HEAP_5FPAGE_5FSIZE(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
t0 = INT_TO_FX(heap_page_size());
return(t0);
}

LP p_lsp_TOTAL_5FHEAP_5FPAGES(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
t0 = INT_TO_FX(total_heap_pages());
return(t0);
}

LP p_lsp_FREE_5FHEAP_5FPAGES(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
t0 = INT_TO_FX(free_heap_pages());
return(t0);
}

LP p_lsp_TOTAL_5FSTATIC_5FPAGES(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
t0 = INT_TO_FX(total_static_pages());
return(t0);
}

LP p_lsp_FREE_5FSTATIC_5FBYTES(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
t0 = INT_TO_FX(free_static_bytes());
return(t0);
}

LP p_lsp_UNIX_5FTIME_5FOF_5FDAY(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
t0 = INT_TO_FX(unix_time_of_day());
return(t0);
}

LP p_lsp_UNIX_5FTIMEZONE(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
t0 = INT_TO_FX(unix_timezone());
return(t0);
}

LP p_lsp_UNIX_5FDAYLIGHT_5FSAVINGS_5FTIME(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
t0 = INT_TO_FX(unix_daylight_savings_time());
return(t0);
}

LP p_lsp_INTERNAL_5FREAL_5FTIME(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
t0 = INT_TO_FX(internal_real_time());
return(t0);
}

LP p_lsp_INTERNAL_5FSYSTEM_5FRUN_5FTIME(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
t0 = INT_TO_FX(internal_system_run_time());
return(t0);
}

LP p_lsp_INTERNAL_5FUSER_5FRUN_5FTIME(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
t0 = INT_TO_FX(internal_user_run_time());
return(t0);
}

LP p_lsp_C_5FSLEEP(argc, v_SECONDS_0)
      ARGC argc;  LP v_SECONDS_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX(sleep(FX_TO_INT(v_SECONDS_0)));
return(t0);
}

LP p_lsp_C_5FAREF(argc, v_ARRAY_0, v_INDICES_1)
      ARGC argc;  LP v_ARRAY_0; LP v_INDICES_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = (c_aref((v_ARRAY_0), (v_INDICES_1)));
return(t0);
}

LP p_lsp_C_5FSET_5FAREF(argc, v_VALUE_0, v_ARRAY_1, v_INDICES_2)
      ARGC argc;  LP v_VALUE_0; LP v_ARRAY_1; LP v_INDICES_2;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 3) wna(argc,3);
t0 = (c_set_aref((v_VALUE_0), (v_ARRAY_1), (v_INDICES_2)));
return(t0);
}

LP p_lsp_VREF(argc, v_VECTOR_0, v_INDEX_1)
      ARGC argc;  LP v_VECTOR_0; LP v_INDEX_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = (vref((v_VECTOR_0), (v_INDEX_1)));
return(t0);
}

LP p_lsp_SET_5FVREF(argc, v_VALUE_0, v_VECTOR_1, v_INDEX_2)
      ARGC argc;  LP v_VALUE_0; LP v_VECTOR_1; LP v_INDEX_2;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 3) wna(argc,3);
t0 = (set_vref((v_VALUE_0), (v_VECTOR_1), (v_INDEX_2)));
return(t0);
}

LP p_lsp_CONNECT_5FTO_5FSERVER(argc, v_HOST_0, v_DISPLAY_1)
      ARGC argc;  LP v_HOST_0; LP v_DISPLAY_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = INT_TO_FX(connect_to_server(lisp_to_c_array(v_HOST_0), FX_TO_INT(v_DISPLAY_1)));
return(t0);
}

LP p_lsp_PC_5FTO_5FPROCEDURE_5FNAME(argc, v_PC_0, v_BUFFER_1)
      ARGC argc;  LP v_PC_0; LP v_BUFFER_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = INT_TO_FX(pc_to_procedure_name(FX_TO_INT(v_PC_0), lisp_to_c_array(v_BUFFER_1)));
return(t0);
}

LP p_lsp_LOAD_5FCOMPILED_5FFILE(argc, v_NAME_0)
      ARGC argc;  LP v_NAME_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX(load_compiled_file(lisp_to_c_array(v_NAME_0)));
return(t0);
}

LP p_lsp_C_5FSYMBOL_5FVALUE(argc, v_NAME_0)
      ARGC argc;  LP v_NAME_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = (c_symbol_value(lisp_to_c_array(v_NAME_0)));
return(t0);
}

LP p_lsp_FULL_5FGC(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
(full_gc());
return(NIL);
}

LP p_lsp_GC_5FCALL_5FCOUNT(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
t0 = INT_TO_FX(gc_call_count());
return(t0);
}

LP p_lsp_SET_5FGC_5FMESSAGES(argc, v_N_0)
      ARGC argc;  LP v_N_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX(set_gc_messages(FX_TO_INT(v_N_0)));
return(t0);
}

LP p_lsp_INTERN_5FSTATIC_5FSYMBOLS(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
(intern_static_symbols());
return(NIL);
}

LP p_lsp_SWITCH_5FTO_5FSTATIC_5FSPACE(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
(switch_to_static_space());
return(NIL);
}

LP p_lsp_SWITCH_5FTO_5FDYNAMIC_5FSPACE(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
(switch_to_dynamic_space());
return(NIL);
}

LP p_lsp_OBJECT_5FSIZE(argc, v_PTR_0)
      ARGC argc;  LP v_PTR_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX(object_size((v_PTR_0)));
return(t0);
}

LP p_lsp_FILE_5FWRITE_5FDATE(argc, v_FILENAME_0)
      ARGC argc;  LP v_FILENAME_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX(file_write_date(lisp_to_c_array(v_FILENAME_0)));
return(t0);
}

LP p_lsp_PROBE_5FFILE(argc, v_FILENAME_0)
      ARGC argc;  LP v_FILENAME_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = (probe_file(lisp_to_c_array(v_FILENAME_0)));
return(t0);
}

LP p_lsp_FILE_5FLENGTH(argc, v_FILE_0)
      ARGC argc;  LP v_FILE_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX(file_length(RAW_FPTR(v_FILE_0)));
return(t0);
}

LP p_lsp_FILE_5FLISTEN(argc, v_FILE_0)
      ARGC argc;  LP v_FILE_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX(file_listen(RAW_FPTR(v_FILE_0)));
return(t0);
}

LP p_lsp_WRITE_5FBYTE(argc, v_DATA_0, v_FILE_1, v_ELEMENT_2DTYPE_2)
      ARGC argc;  LP v_DATA_0; LP v_FILE_1; LP v_ELEMENT_2DTYPE_2;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 3) wna(argc,3);
t0 = INT_TO_FX(write_byte(FX_TO_INT(v_DATA_0), RAW_FPTR(v_FILE_1), FX_TO_INT(v_ELEMENT_2DTYPE_2)));
return(t0);
}

LP p_lsp_READ_5FBYTE(argc, v_FILE_0, v_ELEMENT_2DTYPE_1, v_EOF_2DERROR_2DP_2, v_EOF_2DVALUE_3)
      ARGC argc;  LP v_FILE_0; LP v_ELEMENT_2DTYPE_1; LP v_EOF_2DERROR_2DP_2; LP v_EOF_2DVALUE_3;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 4) wna(argc,4);
t0 = (read_byte(RAW_FPTR(v_FILE_0), FX_TO_INT(v_ELEMENT_2DTYPE_1), (v_EOF_2DERROR_2DP_2), (v_EOF_2DVALUE_3)));
return(t0);
}

LP p_lsp_READ_5FVECTOR(argc, v_FILE_0, v_ELEMENT_2DSIZE_1, v_VECTOR_2, v_START_3, v_END_4, v_EOF_2DERROR_2DP_5, v_EOF_2DVALUE_6)
      ARGC argc;  LP v_FILE_0; LP v_ELEMENT_2DSIZE_1; LP v_VECTOR_2; LP v_START_3; LP v_END_4; LP v_EOF_2DERROR_2DP_5; LP v_EOF_2DVALUE_6;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 7) wna(argc,7);
t0 = (read_vector(RAW_FPTR(v_FILE_0), FX_TO_INT(v_ELEMENT_2DSIZE_1), (v_VECTOR_2), FX_TO_INT(v_START_3), FX_TO_INT(v_END_4), (v_EOF_2DERROR_2DP_5), (v_EOF_2DVALUE_6)));
return(t0);
}

LP p_lsp_WRITE_5FVECTOR(argc, v_FILE_0, v_ELEMENT_2DSIZE_1, v_VECTOR_2, v_START_3, v_END_4)
      ARGC argc;  LP v_FILE_0; LP v_ELEMENT_2DSIZE_1; LP v_VECTOR_2; LP v_START_3; LP v_END_4;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 5) wna(argc,5);
t0 = (write_vector(RAW_FPTR(v_FILE_0), FX_TO_INT(v_ELEMENT_2DSIZE_1), (v_VECTOR_2), FX_TO_INT(v_START_3), FX_TO_INT(v_END_4)));
return(t0);
}

LP p_lsp_CHDIR(argc, v_PATH_0)
      ARGC argc;  LP v_PATH_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX(chdir(lisp_to_c_array(v_PATH_0)));
return(t0);
}

LP p_lsp_GETPID(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
t0 = INT_TO_FX(getpid());
return(t0);
}

LP p_lsp_GETENV(argc, v_NAME_0)
      ARGC argc;  LP v_NAME_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = c_to_lisp_string((LP) getenv(lisp_to_c_array(v_NAME_0)));
return(t0);
}

LP p_lsp_PUTENV(argc, v_STRING_0)
      ARGC argc;  LP v_STRING_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX(putenv(lisp_to_c_array(v_STRING_0)));
return(t0);
}

LP p_lsp_CLOSURE_5FOE(argc, v_PROCEDURE_0)
      ARGC argc;  LP v_PROCEDURE_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = (closure_oe((v_PROCEDURE_0)));
return(t0);
}

LP p_lsp_MAKE_5FEVAL_5FCLOSURE(argc, v_NAME_0, v_FORMAL_2DARGS_1, v_BODY_2, v_VENV_3, v_FENV_4, v_TENV_5, v_BENV_6)
      ARGC argc;  LP v_NAME_0; LP v_FORMAL_2DARGS_1; LP v_BODY_2; LP v_VENV_3; LP v_FENV_4; LP v_TENV_5; LP v_BENV_6;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 7) wna(argc,7);
t0 = (make_eval_closure((v_NAME_0), (v_FORMAL_2DARGS_1), (v_BODY_2), (v_VENV_3), (v_FENV_4), (v_TENV_5), (v_BENV_6)));
return(t0);
}

LP p_lsp_GETHOSTNAME(argc, v_NAME_0, v_NAMELEN_1)
      ARGC argc;  LP v_NAME_0; LP v_NAMELEN_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = INT_TO_FX(gethostname(lisp_to_c_array(v_NAME_0), FX_TO_INT(v_NAMELEN_1)));
return(t0);
}

LP p_lsp_GETOSVERSION(argc, v_NAME_0, v_NAMELEN_1)
      ARGC argc;  LP v_NAME_0; LP v_NAMELEN_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = INT_TO_FX(getosversion(lisp_to_c_array(v_NAME_0), FX_TO_INT(v_NAMELEN_1)));
return(t0);
}

LP p_lsp_GETWD(argc, v_PATH_0)
      ARGC argc;  LP v_PATH_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = INT_TO_FX(getwd(lisp_to_c_array(v_PATH_0)));
return(t0);
}

LP p_lsp_INITSTATE(argc, v_SEED_0, v_DATA_1, v_LEN_2)
      ARGC argc;  LP v_SEED_0; LP v_DATA_1; LP v_LEN_2;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 3) wna(argc,3);
(initstate(FX_TO_INT(v_SEED_0), lisp_to_c_array(v_DATA_1), FX_TO_INT(v_LEN_2)));
return(NIL);
}

LP p_lsp_C_5FRANDOM(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
t0 = UINT32_TO_INTEGER(random());
return(t0);
}

LP p_lsp_SETSTATE(argc, v_DATA_0)
      ARGC argc;  LP v_DATA_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
(setstate(lisp_to_c_array(v_DATA_0)));
return(NIL);
}

LP p_lsp_USLEEP(argc, v_USECONDS_0)
      ARGC argc;  LP v_USECONDS_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
(usleep(FX_TO_INT(v_USECONDS_0)));
return(NIL);
}

LP p_lsp_FOREIGN_5FINIT644(argc)
      ARGC argc; 
{

LP t0; 
if (argc != 0) wna(argc,0);
return(LREF(s_lsp_DIRENT_2DPTR));
}

