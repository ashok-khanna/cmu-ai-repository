/*
:comment "Compiled at 6:09:48 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: DEFAULT"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O "
:version 0
:package (IN-PACKAGE (QUOTE PCL)) 
:end-package-info 0
:sym DEFAULT-TEST-CONVERTER
:sym DEFAULT-CODE-CONVERTER
:sym DEFAULT-CONSTANT-CONVERTER
:sym COMPUTE-CONSTANTS
:sym GET-FUNCTION-GENERATOR
:sf GET-FUNCTION "p_pcl_GET_2DFUNCTION"
:sym CONSTANTP
:sym .CONSTANT.
:sf DEFAULT-TEST-CONVERTER "p_pcl_DEFAULT_2DTEST_2DCONVERTER"
:sym NIL
:sym LISP::GENSYM/1
:sf DEFAULT-CODE-CONVERTER "p_pcl_DEFAULT_2DCODE_2DCONVERTER"
:sym QUOTE
:sf DEFAULT-CONSTANT-CONVERTER "p_pcl_DEFAULT_2DCONSTANT_2DCONVERTER"
:sym *FGENS*
:sym LISP::NCONC/2
:sf STORE-FGEN "p_pcl_STORE_2DFGEN"
:sym :KEY
:sym FGEN-TEST
:sym :TEST
:sym EQUAL
:sym FIND
:sf LOOKUP-FGEN "p_pcl_LOOKUP_2DFGEN"
:sym LISP::MAKE-SIMPLE-ARRAY
:sym LISP::SET-SVREF
:sf MAKE-FGEN "p_pcl_MAKE_2DFGEN"
:sym SVREF
:sf FGEN-TEST "p_pcl_FGEN_2DTEST"
:sf FGEN-GENSYMS "p_pcl_FGEN_2DGENSYMS"
:sf FGEN-GENERATOR "p_pcl_FGEN_2DGENERATOR"
:sf FGEN-GENERATOR-LAMBDA "p_pcl_FGEN_2DGENERATOR_2DLAMBDA"
:sf FGEN-SYSTEM "p_pcl_FGEN_2DSYSTEM"
:sym COMPUTE-TEST
:sym LOOKUP-FGEN
:sym FGEN-GENERATOR
:sym GET-NEW-FUNCTION-GENERATOR
:sf GET-FUNCTION-GENERATOR "p_pcl_GET_2DFUNCTION_2DGENERATOR"
:sym GET-NEW-FUNCTION-GENERATOR-INTERNAL
:sym COMPILE-LAMBDA
:sym MAKE-FGEN
:sym STORE-FGEN
:sf GET-NEW-FUNCTION-GENERATOR "p_pcl_GET_2DNEW_2DFUNCTION_2DGENERATOR"
:sym COMPUTE-CODE
:sym FUNCTION
:sym LAMBDA
:sf GET-NEW-FUNCTION-GENERATOR-INTERNAL "p_pcl_GET_2DNEW_2DFUNCTION_2DGENERATOR_2DINTERNAL"
:sym WALK-FORM
:sym :EVAL
:sf COMPUTE-TEST "p_pcl_COMPUTE_2DTEST"
:sym LISP::APPEND/2
:sf COMPUTE-CODE "p_pcl_COMPUTE_2DCODE"
:sym T
:sf COMPUTE-CONSTANTS "p_pcl_COMPUTE_2DCONSTANTS"
:sym PRECOMPILE-FUNCTION-GENERATORS
:sym LOAD
:sym FGEN-SYSTEM
:sym LOAD-FUNCTION-GENERATOR
:sym FGEN-GENSYMS
:sym FGEN-GENERATOR-LAMBDA
:sym LIST
:sym PROGN
:sym MAKE-TOP-LEVEL-FORM
:sm PRECOMPILE-FUNCTION-GENERATORS "m_pcl_PRECOMPILE_2DFUNCTION_2DGENERATORS"
:sf LOAD-FUNCTION-GENERATOR "p_pcl_LOAD_2DFUNCTION_2DGENERATOR"
:sym :VAR
:sym LISP::DEFINE-VARIABLE
:sym LISP::DEFINE-MACRO
:sf FNGEN_INIT272 "p_pcl_FNGEN_5FINIT272"
:init FNGEN_INIT272
:pinfo PCL::FGEN-GENERATOR (PCL::FGEN) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::GET-FUNCTION-GENERATOR (LAMBDA PCL::TEST-CONVERTER PCL::CODE-CONVERTER) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::DEFAULT-CODE-CONVERTER (PCL::FORM) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::LOAD-FUNCTION-GENERATOR (PCL::TEST PCL::GENSYMS PCL::GENERATOR PCL::GENERATOR-LAMBDA PCL::SYSTEM) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::DEFAULT-TEST-CONVERTER (PCL::FORM) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::COMPUTE-CODE (LAMBDA PCL::CODE-CONVERTER) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::FGEN-GENERATOR-LAMBDA (PCL::FGEN) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::GET-NEW-FUNCTION-GENERATOR-INTERNAL (LAMBDA PCL::CODE-CONVERTER) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::FNGEN_INIT272 NIL NIL NIL NIL NIL NIL NIL T
:pinfo PCL::STORE-FGEN (PCL::FGEN) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::FGEN-TEST (PCL::FGEN) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::DEFAULT-CONSTANT-CONVERTER (PCL::FORM) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::FGEN-SYSTEM (PCL::FGEN) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::MAKE-FGEN (PCL::TEST PCL::GENSYMS PCL::GENERATOR PCL::GENERATOR-LAMBDA PCL::SYSTEM) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::COMPUTE-TEST (LAMBDA PCL::TEST-CONVERTER) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::GET-NEW-FUNCTION-GENERATOR (LAMBDA PCL::TEST PCL::CODE-CONVERTER) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::FGEN-GENSYMS (PCL::FGEN) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::GET-FUNCTION (LAMBDA &OPTIONAL (PCL::TEST-CONVERTER (FUNCTION PCL::DEFAULT-TEST-CONVERTER)) (PCL::CODE-CONVERTER (FUNCTION PCL::DEFAULT-CODE-CONVERTER)) (PCL::CONSTANT-CONVERTER (FUNCTION PCL::DEFAULT-CONSTANT-CONVERTER))) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::COMPUTE-CONSTANTS (LAMBDA PCL::CONSTANT-CONVERTER) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::LOOKUP-FGEN (PCL::TEST) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_pcl_GET_2DFUNCTION();
extern SYMBOL s_pcl_DEFAULT_2DTEST_2DCONVERTER; 
extern SYMBOL s_pcl_DEFAULT_2DCODE_2DCONVERTER; 
extern SYMBOL s_pcl_DEFAULT_2DCONSTANT_2DCONVERTER; 
extern SYMBOL s_pcl_COMPUTE_2DCONSTANTS; 
extern SYMBOL s_pcl_GET_2DFUNCTION_2DGENERATOR; 
extern LP p_pcl_DEFAULT_2DTEST_2DCONVERTER();
extern SYMBOL s_lsp_CONSTANTP; 
extern SYMBOL s_pcl__2ECONSTANT_2E; 
extern LP p_pcl_DEFAULT_2DCODE_2DCONVERTER();
extern SYMBOL s_lsp_NIL; 
extern SYMBOL s_lsp_GENSYM_2F1; 
extern LP p_pcl_DEFAULT_2DCONSTANT_2DCONVERTER();
extern SYMBOL s_lsp_QUOTE; 
extern LP p_pcl_STORE_2DFGEN();
extern SYMBOL s_pcl__2AFGENS_2A; 
extern SYMBOL s_lsp_NCONC_2F2; 
extern LP p_pcl_LOOKUP_2DFGEN();
extern SYMBOL s_key_KEY; 
extern SYMBOL s_pcl_FGEN_2DTEST; 
extern SYMBOL s_key_TEST; 
extern SYMBOL s_lsp_EQUAL; 
extern SYMBOL s_lsp_FIND; 
extern LP p_pcl_MAKE_2DFGEN();
extern SYMBOL s_lsp_MAKE_2DSIMPLE_2DARRAY; 
extern SYMBOL s_lsp_SET_2DSVREF; 
extern LP p_pcl_FGEN_2DTEST();
extern SYMBOL s_lsp_SVREF; 
extern LP p_pcl_FGEN_2DGENSYMS();
extern LP p_pcl_FGEN_2DGENERATOR();
extern LP p_pcl_FGEN_2DGENERATOR_2DLAMBDA();
extern LP p_pcl_FGEN_2DSYSTEM();
extern LP p_pcl_GET_2DFUNCTION_2DGENERATOR();
extern SYMBOL s_pcl_COMPUTE_2DTEST; 
extern SYMBOL s_pcl_LOOKUP_2DFGEN; 
extern SYMBOL s_pcl_FGEN_2DGENERATOR; 
extern SYMBOL s_pcl_GET_2DNEW_2DFUNCTION_2DGENERATOR; 
extern LP p_pcl_GET_2DNEW_2DFUNCTION_2DGENERATOR();
extern SYMBOL s_pcl_GET_2DNEW_2DFUNCTION_2DGENERATOR_2DINTERNAL; 
extern SYMBOL s_pcl_COMPILE_2DLAMBDA; 
extern SYMBOL s_pcl_MAKE_2DFGEN; 
extern SYMBOL s_pcl_STORE_2DFGEN; 
extern LP p_pcl_GET_2DNEW_2DFUNCTION_2DGENERATOR_2DINTERNAL();
extern SYMBOL s_pcl_COMPUTE_2DCODE; 
extern SYMBOL s_lsp_FUNCTION; 
extern SYMBOL s_lsp_LAMBDA; 
extern LP p_pcl_COMPUTE_2DTEST();
extern LP p_pcl_COMPUTE_2DTEST_2Danon14931494();
extern SYMBOL s_walker_WALK_2DFORM; 
extern SYMBOL s_key_EVAL; 
extern LP p_pcl_COMPUTE_2DCODE();
extern LP p_pcl_COMPUTE_2DCODE_2Danon14951496();
extern SYMBOL s_lsp_APPEND_2F2; 
extern LP p_pcl_COMPUTE_2DCONSTANTS();
extern LP p_pcl_COMPUTE_2DCONSTANTS_2Danon14981499();
extern SYMBOL s_lsp_T; 
extern LP m_pcl_PRECOMPILE_2DFUNCTION_2DGENERATORS();
extern LP p_pcl_PRECOMPILE_2DFUNCTION_2DGENERATORS_2Danon15001501();
MAKE_PROCEDURE(k1502,p_pcl_PRECOMPILE_2DFUNCTION_2DGENERATORS_2Danon15001501);
extern SYMBOL s_pcl_PRECOMPILE_2DFUNCTION_2DGENERATORS; 
extern SYMBOL s_lsp_LOAD; 
MAKE_CONS(k1503,LREF(s_lsp_LOAD),LREF(s_lsp_NIL));
extern SYMBOL s_pcl_FGEN_2DSYSTEM; 
extern SYMBOL s_pcl_LOAD_2DFUNCTION_2DGENERATOR; 
extern SYMBOL s_pcl_FGEN_2DGENSYMS; 
extern SYMBOL s_pcl_FGEN_2DGENERATOR_2DLAMBDA; 
extern SYMBOL s_lsp_LIST; 
extern SYMBOL s_lsp_PROGN; 
extern SYMBOL s_pcl_MAKE_2DTOP_2DLEVEL_2DFORM; 
extern LP p_pcl_LOAD_2DFUNCTION_2DGENERATOR();
extern LP p_pcl_FNGEN_5FINIT272();
extern SYMBOL s_key_VAR; 
extern SYMBOL s_lsp_DEFINE_2DVARIABLE; 
extern SYMBOL s_lsp_DEFINE_2DMACRO; 


extern LP c_cons();


LP p_pcl_GET_2DFUNCTION(va_alist) va_dcl
{
LP v_LAMBDA_0; LP v_X_8; LP v_CONSTANT_2DCONVERTER_7; 
LP v_X_5; LP v_CODE_2DCONVERTER_4; LP v_X_2; 
LP v_TEST_2DCONVERTER_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_LAMBDA_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 4) wna_high(real_argc,4);
if (real_argc < 2) {
v_X_2 = LREF(s_pcl_DEFAULT_2DTEST_2DCONVERTER);
t0 = ((LP) DEREF((v_X_2) + 4 * 4));
v_TEST_2DCONVERTER_1 = t0;
} else {
v_TEST_2DCONVERTER_1 = NEXT_VAR_ARG;
}
if (real_argc < 3) {
v_X_5 = LREF(s_pcl_DEFAULT_2DCODE_2DCONVERTER);
t1 = ((LP) DEREF((v_X_5) + 4 * 4));
v_CODE_2DCONVERTER_4 = t1;
} else {
v_CODE_2DCONVERTER_4 = NEXT_VAR_ARG;
}
if (real_argc < 4) {
v_X_8 = LREF(s_pcl_DEFAULT_2DCONSTANT_2DCONVERTER);
t2 = ((LP) DEREF((v_X_8) + 4 * 4));
v_CONSTANT_2DCONVERTER_7 = t2;
} else {
v_CONSTANT_2DCONVERTER_7 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t4 = ICALL(s_pcl_COMPUTE_2DCONSTANTS) (2, v_LAMBDA_0, v_CONSTANT_2DCONVERTER_7);
t5 = ICALL(s_pcl_GET_2DFUNCTION_2DGENERATOR) (3, v_LAMBDA_0, v_TEST_2DCONVERTER_1, v_CODE_2DCONVERTER_4);
t3 = p_lsp_APPLY(MV_CALL(argc,2), COERCE_TO_FUNCTION(t5), t4);
return(t3);
}

LP p_pcl_DEFAULT_2DTEST_2DCONVERTER(argc, v_FORM_0)
      ARGC argc;  LP v_FORM_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_CONSTANTP) (1, v_FORM_0);
if (t1 != NIL) {
return(LREF(s_pcl__2ECONSTANT_2E));
} else {
return(v_FORM_0);
}
}

LP p_pcl_DEFAULT_2DCODE_2DCONVERTER(argc, v_FORM_0)
      ARGC argc;  LP v_FORM_0;
{
LP v_Y_7; LP v_X_6; LP v_GENSYM_5; 
LP v_X_3; LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_CONSTANTP) (1, v_FORM_0);
if (t1 != NIL) {
v_X_3 = LREF(s_lsp_NIL);
v_GENSYM_5 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(s_lsp_NIL));
v_X_6 = v_GENSYM_5;
v_Y_7 = LREF(s_lsp_NIL);
t2 = (c_cons((v_GENSYM_5), (LREF(s_lsp_NIL))));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,t2);
}
return(v_GENSYM_5);
} else {
return(v_FORM_0);
}
}

LP p_pcl_DEFAULT_2DCONSTANT_2DCONVERTER(argc, v_FORM_0)
      ARGC argc;  LP v_FORM_0;
{
LP v_Y_16; LP v_X_15; LP v_X_13; 
LP v_Y_11; LP v_X_10; LP v_X_8; 
LP v_X_6; LP v_X_4; LP v_C_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; 
if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_CONSTANTP) (1, v_FORM_0);
if (t1 != NIL) {
v_X_13 = v_FORM_0;
if (OTHER_PTRP((v_FORM_0)) && (TAG((v_FORM_0)) == 15)) {
v_X_8 = v_FORM_0;
v_X_10 = ((LP) DEREF((v_FORM_0) + 0 * 4));
t2 = (((v_X_10) == (LREF(s_lsp_QUOTE))) ? T : NIL);
} else {
t2 = LREF(s_lsp_NIL);
}
if (t2 != NIL) {
v_C_2 = v_FORM_0;
v_X_4 = v_FORM_0;
v_X_6 = ((LP) DEREF((v_FORM_0) + 1 * 4));
v_X_15 = ((LP) DEREF((v_X_6) + 0 * 4));
} else {
v_X_15 = v_FORM_0;
}
t0 = (c_cons((v_X_15), (LREF(s_lsp_NIL))));
return(t0);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_pcl_STORE_2DFGEN(argc, v_FGEN_0)
      ARGC argc;  LP v_FGEN_0;
{
LP v_V_8; LP v_X_7; LP v_Y_5; 
LP v_X_4; LP v_SYMBOL_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; 
if (argc != 1) wna(argc,1);
v_SYMBOL_2 = LREF(s_pcl__2AFGENS_2A);
t0 = ((LP) DEREF((LREF(s_pcl__2AFGENS_2A)) + 0 * 4));
v_X_4 = v_FGEN_0;
v_Y_5 = LREF(s_lsp_NIL);
t1 = (c_cons((v_FGEN_0), (LREF(s_lsp_NIL))));
v_V_8 = ICALL(s_lsp_NCONC_2F2) (2, t0, t1);
((LP) (DEREF((LREF(s_pcl__2AFGENS_2A)) + 0 * 4) = (LD) (v_V_8)));
return(v_V_8);
}

LP p_pcl_LOOKUP_2DFGEN(argc, v_TEST_0)
      ARGC argc;  LP v_TEST_0;
{
LP v_X_6; LP v_X_4; LP v_SYMBOL_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; 
if (argc != 1) wna(argc,1);
v_SYMBOL_2 = LREF(s_pcl__2AFGENS_2A);
t1 = ((LP) DEREF((LREF(s_pcl__2AFGENS_2A)) + 0 * 4));
v_X_4 = LREF(s_pcl_FGEN_2DTEST);
t2 = ((LP) DEREF((LREF(s_pcl_FGEN_2DTEST)) + 4 * 4));
v_X_6 = LREF(s_lsp_EQUAL);
t3 = ((LP) DEREF((LREF(s_lsp_EQUAL)) + 4 * 4));
t0 = ICALL(s_lsp_FIND) (MV_CALL(argc,6), v_TEST_0, t1, LREF(s_key_KEY), t2, LREF(s_key_TEST), t3);
return(t0);
}

LP p_pcl_MAKE_2DFGEN(argc, v_TEST_0, v_GENSYMS_1, v_GENERATOR_2, v_GENERATOR_2DLAMBDA_3, v_SYSTEM_4)
      ARGC argc;  LP v_TEST_0; LP v_GENSYMS_1; LP v_GENERATOR_2; LP v_GENERATOR_2DLAMBDA_3; LP v_SYSTEM_4;
{
LP v_T1745_21; LP v_T1744_20; LP v_S1743_19; 
LP v_T1742_18; LP v_T1741_17; LP v_S1740_16; 
LP v_T1739_15; LP v_T1738_14; LP v_S1737_13; 
LP v_T1736_12; LP v_T1735_11; LP v_S1734_10; 
LP v_T1733_9; LP v_T1732_8; LP v_S1731_7; 
LP v_NEW_6; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; 
if (argc != 5) wna(argc,5);
v_NEW_6 = ICALL(s_lsp_MAKE_2DSIMPLE_2DARRAY) (5, (LP) 12, (LP) 128, (LP) 64, LREF(s_lsp_NIL), LREF(s_lsp_NIL));
v_S1731_7 = v_TEST_0;
v_T1732_8 = v_NEW_6;
v_T1733_9 = (LP) 0;
ICALL(s_lsp_SET_2DSVREF) (3, v_NEW_6, (LP) 0, v_TEST_0);
v_S1734_10 = v_GENSYMS_1;
v_T1735_11 = v_NEW_6;
v_T1736_12 = (LP) 2;
ICALL(s_lsp_SET_2DSVREF) (3, v_NEW_6, (LP) 2, v_GENSYMS_1);
v_S1737_13 = v_GENERATOR_2;
v_T1738_14 = v_NEW_6;
v_T1739_15 = (LP) 4;
ICALL(s_lsp_SET_2DSVREF) (3, v_NEW_6, (LP) 4, v_GENERATOR_2);
v_S1740_16 = v_GENERATOR_2DLAMBDA_3;
v_T1741_17 = v_NEW_6;
v_T1742_18 = (LP) 6;
ICALL(s_lsp_SET_2DSVREF) (3, v_NEW_6, (LP) 6, v_GENERATOR_2DLAMBDA_3);
v_S1743_19 = v_SYSTEM_4;
v_T1744_20 = v_NEW_6;
v_T1745_21 = (LP) 8;
ICALL(s_lsp_SET_2DSVREF) (3, v_NEW_6, (LP) 8, v_SYSTEM_4);
return(v_NEW_6);
}

LP p_pcl_FGEN_2DTEST(argc, v_FGEN_0)
      ARGC argc;  LP v_FGEN_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_SVREF) (MV_CALL(argc,2), v_FGEN_0, (LP) 0);
return(t0);
}

LP p_pcl_FGEN_2DGENSYMS(argc, v_FGEN_0)
      ARGC argc;  LP v_FGEN_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_SVREF) (MV_CALL(argc,2), v_FGEN_0, (LP) 2);
return(t0);
}

LP p_pcl_FGEN_2DGENERATOR(argc, v_FGEN_0)
      ARGC argc;  LP v_FGEN_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_SVREF) (MV_CALL(argc,2), v_FGEN_0, (LP) 4);
return(t0);
}

LP p_pcl_FGEN_2DGENERATOR_2DLAMBDA(argc, v_FGEN_0)
      ARGC argc;  LP v_FGEN_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_SVREF) (MV_CALL(argc,2), v_FGEN_0, (LP) 6);
return(t0);
}

LP p_pcl_FGEN_2DSYSTEM(argc, v_FGEN_0)
      ARGC argc;  LP v_FGEN_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_SVREF) (MV_CALL(argc,2), v_FGEN_0, (LP) 8);
return(t0);
}

LP p_pcl_GET_2DFUNCTION_2DGENERATOR(argc, v_LAMBDA_0, v_TEST_2DCONVERTER_1, v_CODE_2DCONVERTER_2)
      ARGC argc;  LP v_LAMBDA_0; LP v_TEST_2DCONVERTER_1; LP v_CODE_2DCONVERTER_2;
{
LP v_FGEN_5; LP v_TEST_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
if (argc != 3) wna(argc,3);
v_TEST_4 = ICALL(s_pcl_COMPUTE_2DTEST) (2, v_LAMBDA_0, v_TEST_2DCONVERTER_1);
v_FGEN_5 = ICALL(s_pcl_LOOKUP_2DFGEN) (1, v_TEST_4);
if (v_FGEN_5 != NIL) {
t0 = ICALL(s_pcl_FGEN_2DGENERATOR) (MV_CALL(argc,1), v_FGEN_5);
return(t0);
} else {
t0 = ICALL(s_pcl_GET_2DNEW_2DFUNCTION_2DGENERATOR) (MV_CALL(argc,3), v_LAMBDA_0, v_TEST_4, v_CODE_2DCONVERTER_2);
return(t0);
}
}

LP p_pcl_GET_2DNEW_2DFUNCTION_2DGENERATOR(argc, v_LAMBDA_0, v_TEST_1, v_CODE_2DCONVERTER_2)
      ARGC argc;  LP v_LAMBDA_0; LP v_TEST_1; LP v_CODE_2DCONVERTER_2;
{
LP v_FGEN_7; LP v_GENERATOR_6; LP v_GENERATOR_2DLAMBDA_5; 
LP v_GENSYMS_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 3) wna(argc,3);
{
int real_argc;
BEGIN_MV_CALL(mv_holder1491,0);
t0 = ICALL(s_pcl_GET_2DNEW_2DFUNCTION_2DGENERATOR_2DINTERNAL) (MV_CALL(mv_holder1491,2), v_LAMBDA_0, v_CODE_2DCONVERTER_2);
SET_MV_RETURN_VALUE(mv_holder1491,0,t0);
if SV_RETURN_P(mv_holder1491) SET_MV_RETURN_COUNT(mv_holder1491,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder1491);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_GENSYMS_4 = NIL;
} else {
v_GENSYMS_4 = NEXT_VAR_VALUE(mv_holder1491);
}
if (real_argc < 2) {
v_GENERATOR_2DLAMBDA_5 = NIL;
} else {
v_GENERATOR_2DLAMBDA_5 = NEXT_VAR_VALUE(mv_holder1491);
}
END_VAR_VALUES;
END_MV_CALL;
v_GENERATOR_6 = ICALL(s_pcl_COMPILE_2DLAMBDA) (1, v_GENERATOR_2DLAMBDA_5);
v_FGEN_7 = ICALL(s_pcl_MAKE_2DFGEN) (5, v_TEST_1, v_GENSYMS_4, v_GENERATOR_6, v_GENERATOR_2DLAMBDA_5, LREF(s_lsp_NIL));
ICALL(s_pcl_STORE_2DFGEN) (1, v_FGEN_7);
return(v_GENERATOR_6);
}
}

LP p_pcl_GET_2DNEW_2DFUNCTION_2DGENERATOR_2DINTERNAL(argc, v_LAMBDA_0, v_CODE_2DCONVERTER_1)
      ARGC argc;  LP v_LAMBDA_0; LP v_CODE_2DCONVERTER_1;
{
LP v_Y_18; LP v_X_17; LP v_Y_15; 
LP v_X_14; LP v_Y_12; LP v_X_11; 
LP v_Y_9; LP v_X_8; LP v_Y_6; 
LP v_X_5; LP v_GENSYMS_4; LP v_CODE_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; 
if (argc != 2) wna(argc,2);
{
int real_argc;
BEGIN_MV_CALL(mv_holder1492,0);
t0 = ICALL(s_pcl_COMPUTE_2DCODE) (MV_CALL(mv_holder1492,2), v_LAMBDA_0, v_CODE_2DCONVERTER_1);
SET_MV_RETURN_VALUE(mv_holder1492,0,t0);
if SV_RETURN_P(mv_holder1492) SET_MV_RETURN_COUNT(mv_holder1492,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder1492);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_CODE_3 = NIL;
} else {
v_CODE_3 = NEXT_VAR_VALUE(mv_holder1492);
}
if (real_argc < 2) {
v_GENSYMS_4 = NIL;
} else {
v_GENSYMS_4 = NEXT_VAR_VALUE(mv_holder1492);
}
END_VAR_VALUES;
END_MV_CALL;
v_X_5 = v_CODE_3;
v_Y_6 = LREF(s_lsp_NIL);
v_Y_9 = (c_cons((v_CODE_3), (LREF(s_lsp_NIL))));
v_X_11 = (c_cons((LREF(s_lsp_FUNCTION)), (v_Y_9)));
v_Y_15 = (c_cons((v_X_11), (LREF(s_lsp_NIL))));
v_Y_18 = (c_cons((v_GENSYMS_4), (v_Y_15)));
t1 = (c_cons((LREF(s_lsp_LAMBDA)), (v_Y_18)));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,t1);
}
return(v_GENSYMS_4);
}
}

LP p_pcl_COMPUTE_2DTEST(argc, v_LAMBDA_0, v_TEST_2DCONVERTER_1)
      ARGC argc;  LP v_LAMBDA_0; LP v_TEST_2DCONVERTER_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 2) wna(argc,2);
t0 = NEW_OE(1);
SET_OE_SLOT(t0,0,v_TEST_2DCONVERTER_1);
t2 = MAKE_CLOSURE(p_pcl_COMPUTE_2DTEST_2Danon14931494,t0);
t1 = ICALL(s_walker_WALK_2DFORM) (MV_CALL(argc,3), v_LAMBDA_0, LREF(s_lsp_NIL), t2);
return(t1);
}

LP p_pcl_COMPUTE_2DTEST_2Danon14931494(argc, v_F_0, v_C_1, v_E_2)
      ARGC argc;  LP v_F_0; LP v_C_1; LP v_E_2;
{
LP v_Y_18; LP v_X_17; LP v_X_15; 
LP v_Y_13; LP v_X_12; LP v_Y_10; 
LP v_X_9; LP v_X_7; LP v_Y_5; 
LP v_X_4; LP v_CONVERTED_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; 
if (argc != 3) wna(argc,3);
t0 = OE;
v_X_12 = v_C_1;
v_Y_13 = LREF(s_key_EVAL);
v_X_15 = (((v_C_1) == (LREF(s_key_EVAL))) ? T : NIL);
v_X_17 = v_X_15;
v_Y_18 = LREF(s_lsp_NIL);
if (v_X_15 != NIL) {
v_CONVERTED_3 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(1, v_F_0);
v_X_4 = v_CONVERTED_3;
v_Y_5 = v_F_0;
v_X_7 = (((v_CONVERTED_3) == (v_F_0)) ? T : NIL);
v_X_9 = v_X_7;
v_Y_10 = LREF(s_lsp_NIL);
t2 = (((v_X_7) == (LREF(s_lsp_NIL))) ? T : NIL);
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,t2);
}
return(v_CONVERTED_3);
} else {
return(v_F_0);
}
}

LP p_pcl_COMPUTE_2DCODE(argc, v_LAMBDA_0, v_CODE_2DCONVERTER_1)
      ARGC argc;  LP v_LAMBDA_0; LP v_CODE_2DCONVERTER_1;
{
LP v_GENSYMS_3; 
LP t0; LP t1; LP t2; 
if (argc != 2) wna(argc,2);
t0 = NEW_OE(2);
SET_OE_SLOT(t0,0,v_CODE_2DCONVERTER_1);
v_GENSYMS_3 = LREF(s_lsp_NIL);
SET_OE_SLOT(t0,1,v_GENSYMS_3);
t2 = MAKE_CLOSURE(p_pcl_COMPUTE_2DCODE_2Danon14951496,t0);
t1 = ICALL(s_walker_WALK_2DFORM) (3, v_LAMBDA_0, LREF(s_lsp_NIL), t2);
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,GET_OE_SLOT(t0,1));
}
return(t1);
}

LP p_pcl_COMPUTE_2DCODE_2Danon14951496(argc, v_F_0, v_C_1, v_E_2)
      ARGC argc;  LP v_F_0; LP v_C_1; LP v_E_2;
{
LP v_Y_19; LP v_X_18; LP v_X_16; 
LP v_Y_14; LP v_X_13; LP v_Y_11; 
LP v_X_10; LP v_X_8; LP v_Y_6; 
LP v_X_5; LP v_GENS_4; LP v_CONVERTED_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; 
if (argc != 3) wna(argc,3);
t0 = OE;
v_X_13 = v_C_1;
v_Y_14 = LREF(s_key_EVAL);
v_X_16 = (((v_C_1) == (LREF(s_key_EVAL))) ? T : NIL);
v_X_18 = v_X_16;
v_Y_19 = LREF(s_lsp_NIL);
if (v_X_16 != NIL) {
{
int real_argc;
BEGIN_MV_CALL(mv_holder1497,0);
t2 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(MV_CALL(mv_holder1497,1), v_F_0);
SET_MV_RETURN_VALUE(mv_holder1497,0,t2);
if SV_RETURN_P(mv_holder1497) SET_MV_RETURN_COUNT(mv_holder1497,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder1497);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_CONVERTED_3 = NIL;
} else {
v_CONVERTED_3 = NEXT_VAR_VALUE(mv_holder1497);
}
if (real_argc < 2) {
v_GENS_4 = NIL;
} else {
v_GENS_4 = NEXT_VAR_VALUE(mv_holder1497);
}
END_VAR_VALUES;
END_MV_CALL;
if (v_GENS_4 != NIL) {
t3 = ICALL(s_lsp_APPEND_2F2) (2, GET_OE_SLOT(t0,1), v_GENS_4);
SET_OE_SLOT(t0,1,t3);
}
v_X_5 = v_CONVERTED_3;
v_Y_6 = v_F_0;
v_X_8 = (((v_CONVERTED_3) == (v_F_0)) ? T : NIL);
v_X_10 = v_X_8;
v_Y_11 = LREF(s_lsp_NIL);
t4 = (((v_X_8) == (LREF(s_lsp_NIL))) ? T : NIL);
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,t4);
}
return(v_CONVERTED_3);
}
} else {
return(v_F_0);
}
}

LP p_pcl_COMPUTE_2DCONSTANTS(argc, v_LAMBDA_0, v_CONSTANT_2DCONVERTER_1)
      ARGC argc;  LP v_LAMBDA_0; LP v_CONSTANT_2DCONVERTER_1;
{
LP v_L1749_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 2) wna(argc,2);
t0 = NEW_OE(2);
SET_OE_SLOT(t0,1,v_CONSTANT_2DCONVERTER_1);
v_L1749_3 = LREF(s_lsp_NIL);
SET_OE_SLOT(t0,0,v_L1749_3);
t1 = MAKE_CLOSURE(p_pcl_COMPUTE_2DCONSTANTS_2Danon14981499,t0);
ICALL(s_walker_WALK_2DFORM) (3, v_LAMBDA_0, LREF(s_lsp_NIL), t1);
return(GET_OE_SLOT(t0,0));
}

LP p_pcl_COMPUTE_2DCONSTANTS_2Danon14981499(argc, v_F_0, v_C_1, v_E_2)
      ARGC argc;  LP v_F_0; LP v_C_1; LP v_E_2;
{
LP v_Y_6; LP v_X_5; LP v_VALUE_4; 
LP v_CONSTS_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; 
if (argc != 3) wna(argc,3);
t0 = OE;
v_X_5 = v_C_1;
v_Y_6 = LREF(s_key_EVAL);
if (((v_C_1) == (LREF(s_key_EVAL)))) {
v_CONSTS_3 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,1)))(1, v_F_0);
if (v_CONSTS_3 != NIL) {
v_VALUE_4 = v_CONSTS_3;
t3 = ICALL(s_lsp_APPEND_2F2) (2, GET_OE_SLOT(t0,0), v_CONSTS_3);
SET_OE_SLOT(t0,0,t3);
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,LREF(s_lsp_T));
}
return(v_F_0);
} else {
return(v_F_0);
}
} else {
return(v_F_0);
}
}

LP m_pcl_PRECOMPILE_2DFUNCTION_2DGENERATORS(argc, v_WHOLE1762_0, v_ENV1763_1)
      ARGC argc;  LP v_WHOLE1762_0; LP v_ENV1763_1;
{
LP v_L1780_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE1762_0;
v_L1780_5 = ((LP) DEREF((v_WHOLE1762_0) + 1 * 4));
t0 = p_lsp_APPLY(MV_CALL(argc,2), COERCE_TO_FUNCTION(LREF(k1502)), v_L1780_5);
return(t0);
}

LP p_pcl_PRECOMPILE_2DFUNCTION_2DGENERATORS_2Danon15001501(va_alist) va_dcl
{
LP v_Y_75; LP v_X_74; LP v_Y_72; 
LP v_X_71; LP v_G1789_70; LP v_Y_68; 
LP v_X_67; LP v_X_65; LP v_X_63; 
LP v_V_61; LP v_X_60; LP v_NEW_2DCDR_58; 
LP v_C_57; LP v_Y_55; LP v_X_54; 
LP v_Y_52; LP v_X_51; LP v_VALUE_50; 
LP v_Y_48; LP v_X_47; LP v_Y_45; 
LP v_X_44; LP v_Y_42; LP v_X_41; 
LP v_Y_39; LP v_X_38; LP v_Y_36; 
LP v_X_35; LP v_Y_33; LP v_X_32; 
LP v_Y_30; LP v_X_29; LP v_Y_27; 
LP v_X_26; LP v_Y_24; LP v_X_23; 
LP v_Y_21; LP v_X_20; LP v_X_18; 
LP v_X_16; LP v_LOOP_2DLIST_2D271_12; LP v_FGEN_11; 
LP v_SYMBOL_9; LP v_L1782_8; LP v_L1781_7; 
LP v_Y_5; LP v_X_4; LP v_Y_2; 
LP v_X_1; LP v_SYSTEM_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
if (real_argc > 1) wna_high(real_argc,1);
if (real_argc < 1) {
v_SYSTEM_0 = NIL;
} else {
v_SYSTEM_0 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
v_X_1 = v_SYSTEM_0;
v_Y_2 = LREF(s_lsp_NIL);
v_Y_5 = (c_cons((v_SYSTEM_0), (LREF(s_lsp_NIL))));
t1 = (c_cons((LREF(s_pcl_PRECOMPILE_2DFUNCTION_2DGENERATORS)), (v_Y_5)));
v_L1781_7 = LREF(s_lsp_NIL);
v_L1782_8 = LREF(s_lsp_NIL);
v_FGEN_11 = LREF(s_lsp_NIL);
v_SYMBOL_9 = LREF(s_pcl__2AFGENS_2A);
v_LOOP_2DLIST_2D271_12 = ((LP) DEREF((LREF(s_pcl__2AFGENS_2A)) + 0 * 4));
t_NEXT_2DLOOP_14:;
if (v_LOOP_2DLIST_2D271_12 == NIL) {
goto t_END_2DLOOP_15;
}
v_X_16 = v_LOOP_2DLIST_2D271_12;
v_FGEN_11 = ((LP) DEREF((v_X_16) + 0 * 4));
v_X_18 = v_LOOP_2DLIST_2D271_12;
v_LOOP_2DLIST_2D271_12 = ((LP) DEREF((v_X_18) + 1 * 4));
v_X_65 = ICALL(s_pcl_FGEN_2DSYSTEM) (1, v_FGEN_11);
v_X_67 = v_X_65;
v_Y_68 = LREF(s_lsp_NIL);
v_G1789_70 = (((v_X_65) == (LREF(s_lsp_NIL))) ? T : NIL);
if (v_G1789_70 != NIL) {
t2 = v_G1789_70;
} else {
v_X_71 = ICALL(s_pcl_FGEN_2DSYSTEM) (1, v_FGEN_11);
t2 = (((v_X_71) == (v_SYSTEM_0)) ? T : NIL);
}
if (t2 != NIL) {
v_X_20 = ICALL(s_pcl_FGEN_2DTEST) (1, v_FGEN_11);
v_Y_24 = (c_cons((v_X_20), (LREF(s_lsp_NIL))));
t3 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_24)));
v_X_26 = ICALL(s_pcl_FGEN_2DGENSYMS) (1, v_FGEN_11);
v_Y_30 = (c_cons((v_X_26), (LREF(s_lsp_NIL))));
t4 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_30)));
v_X_32 = ICALL(s_pcl_FGEN_2DGENERATOR_2DLAMBDA) (1, v_FGEN_11);
v_Y_36 = (c_cons((v_X_32), (LREF(s_lsp_NIL))));
t5 = (c_cons((LREF(s_lsp_FUNCTION)), (v_Y_36)));
v_X_38 = ICALL(s_pcl_FGEN_2DGENERATOR_2DLAMBDA) (1, v_FGEN_11);
v_Y_42 = (c_cons((v_X_38), (LREF(s_lsp_NIL))));
t6 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_42)));
v_X_44 = v_SYSTEM_0;
v_Y_45 = LREF(s_lsp_NIL);
v_Y_48 = (c_cons((v_SYSTEM_0), (LREF(s_lsp_NIL))));
t7 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_48)));
v_VALUE_50 = ICALL(s_lsp_LIST) (6, LREF(s_pcl_LOAD_2DFUNCTION_2DGENERATOR), t3, t4, t5, t6, t7);
if (v_L1781_7 != NIL) {
v_C_57 = v_L1782_8;
v_X_54 = v_VALUE_50;
v_Y_55 = LREF(s_lsp_NIL);
v_NEW_2DCDR_58 = (c_cons((v_VALUE_50), (LREF(s_lsp_NIL))));
v_V_61 = v_NEW_2DCDR_58;
((LP) (DEREF((v_C_57) + 1 * 4) = (LD) (v_V_61)));
v_X_63 = v_C_57;
v_L1782_8 = ((LP) DEREF((v_X_63) + 1 * 4));
} else {
v_X_51 = v_VALUE_50;
v_Y_52 = LREF(s_lsp_NIL);
v_L1782_8 = (c_cons((v_VALUE_50), (LREF(s_lsp_NIL))));
v_L1781_7 = v_L1782_8;
}
}
goto t_NEXT_2DLOOP_14;
goto t_END_2DLOOP_15;
t_END_2DLOOP_15:;
goto b_NIL_13;
b_NIL_13:;
v_Y_75 = v_L1781_7;
t8 = (c_cons((LREF(s_lsp_PROGN)), (v_Y_75)));
t0 = ICALL(s_pcl_MAKE_2DTOP_2DLEVEL_2DFORM) (MV_CALL(argc,3), t1, LREF(k1503), t8);
return(t0);
}

LP p_pcl_LOAD_2DFUNCTION_2DGENERATOR(argc, v_TEST_0, v_GENSYMS_1, v_GENERATOR_2, v_GENERATOR_2DLAMBDA_3, v_SYSTEM_4)
      ARGC argc;  LP v_TEST_0; LP v_GENSYMS_1; LP v_GENERATOR_2; LP v_GENERATOR_2DLAMBDA_3; LP v_SYSTEM_4;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 5) wna(argc,5);
t1 = ICALL(s_pcl_MAKE_2DFGEN) (5, v_TEST_0, v_GENSYMS_1, v_GENERATOR_2, v_GENERATOR_2DLAMBDA_3, v_SYSTEM_4);
t0 = ICALL(s_pcl_STORE_2DFGEN) (MV_CALL(argc,1), t1);
return(t0);
}

LP p_pcl_FNGEN_5FINIT272(argc)
      ARGC argc; 
{
LP v_X_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 0) wna(argc,0);
ICALL(s_lsp_DEFINE_2DVARIABLE) (4, LREF(s_pcl__2AFGENS_2A), LREF(s_lsp_NIL), LREF(s_lsp_NIL), LREF(s_key_VAR));
v_X_1 = LREF(s_pcl_PRECOMPILE_2DFUNCTION_2DGENERATORS);
t1 = ((LP) DEREF((LREF(s_pcl_PRECOMPILE_2DFUNCTION_2DGENERATORS)) + 4 * 4));
t0 = ICALL(s_lsp_DEFINE_2DMACRO) (MV_CALL(argc,2), LREF(s_pcl_PRECOMPILE_2DFUNCTION_2DGENERATORS), t1);
return(t0);
}

