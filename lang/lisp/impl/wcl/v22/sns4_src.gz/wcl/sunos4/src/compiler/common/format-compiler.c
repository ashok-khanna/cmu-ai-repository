/*
:comment "Compiled at 1:25:55 am on Wednesday, June 15, 1994"
:comment "Compiler Configuration: DEFAULT"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w -g -O -DSYSV -fPIC"
:version 0
:end-package-info 0
:sym NIL
:sym GENSYM/1
:sym LENGTH
:sym APPEND/2
:sym REVERSE
:sym PROGN
:sym LET
:sym LIST*
:sym WITH-OUTPUT-TO-STRING
:sym ELT
:sym CHAR-UPCASE
:sym PRINC
:sym PRIN1
:sym WRITE-CHAR
:sym TERPRI
:sym WRITE
:sym :BASE
:sym :STREAM
:sym LIST
:sym WRITE-STRING
:sym :ABORT
:sym SUBSEQ-1
:sf COMPILE-FORMAT "p_lsp_COMPILE_2DFORMAT"
:pinfo COMPILE-FORMAT (WHOLE STREAM-FORM STR ARGS) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_lsp_COMPILE_2DFORMAT();
extern SYMBOL s_lsp_NIL; 
MAKE_SIMPLE_STRING(k2,6,"STREAM");
extern SYMBOL s_lsp_GENSYM_2F1; 
extern LP p_lsp_COMPILE_2DFORMAT_2DWRITE_2DCONST_2DSTRING0();
extern LP p_lsp_COMPILE_2DFORMAT_2DMUNCH1();
extern SYMBOL s_lsp_LENGTH; 
extern SYMBOL s_lsp_APPEND_2F2; 
extern SYMBOL s_lsp_REVERSE; 
MAKE_CONS(k3,LREF(s_lsp_NIL),LREF(s_lsp_NIL));
extern SYMBOL s_lsp_PROGN; 
extern SYMBOL s_lsp_LET; 
extern SYMBOL s_lsp_LIST_2A; 
extern SYMBOL s_lsp_WITH_2DOUTPUT_2DTO_2DSTRING; 
extern SYMBOL s_lsp_ELT; 
extern SYMBOL s_lsp_CHAR_2DUPCASE; 
extern SYMBOL s_lsp_PRINC; 
extern SYMBOL s_lsp_PRIN1; 
extern SYMBOL s_lsp_WRITE_2DCHAR; 
extern SYMBOL s_lsp_TERPRI; 
extern SYMBOL s_lsp_WRITE; 
extern SYMBOL s_key_BASE; 
extern SYMBOL s_key_STREAM; 
extern SYMBOL s_lsp_LIST; 
MAKE_SIMPLE_STRING(k4,1,"~");
extern SYMBOL s_lsp_WRITE_2DSTRING; 
extern SYMBOL s_key_ABORT; 
extern SYMBOL s_lsp_SUBSEQ_2D1; 


extern LP num_equal_p();
extern LP c_eql();
extern LP add();
extern LP lessp();
extern LP vref();
extern LP c_cons();
extern LP geq_p();


LP p_lsp_COMPILE_2DFORMAT(argc, v_WHOLE_0, v_STREAM_2DFORM_1, v_STR_2, v_ARGS_3)
      ARGC argc;  LP v_WHOLE_0; LP v_STREAM_2DFORM_1; LP v_STR_2; LP v_ARGS_3;
{
LP f_MUNCH_30; LP f_WRITE_2DCONST_2DSTRING_29; LP v_STREAM_28; 
LP v_Y_26; LP v_X_25; LP v_X_23; 
LP v_G82_22; LP v_Y_20; LP v_X_19; 
LP v_X_17; LP v_Y_15; LP v_X_14; 
LP v_X_12; LP v_X_10; LP v_X_8; 
LP v_X_6; LP v_X_5; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 

if (argc != 4) wna(argc,4);
t0 = NEW_OE(7);
SET_OE_SLOT(t0,1,v_WHOLE_0);
SET_OE_SLOT(t0,3,v_STREAM_2DFORM_1);
SET_OE_SLOT(t0,6,v_STR_2);
SET_OE_SLOT(t0,2,v_ARGS_3);
v_X_8 = GET_OE_SLOT(t0,3);
v_X_10 = GET_OE_SLOT(t0,3);
v_X_12 = (OTHER_PTRP((GET_OE_SLOT(t0,3))) && (TAG((GET_OE_SLOT(t0,3))) == 15) ? T : NIL);
v_X_14 = v_X_12;
v_Y_15 = LREF(s_lsp_NIL);
v_X_17 = (((v_X_12) == (LREF(s_lsp_NIL))) ? T : NIL);
v_X_19 = v_X_17;
v_Y_20 = LREF(s_lsp_NIL);
v_G82_22 = (((v_X_17) == (LREF(s_lsp_NIL))) ? T : NIL);
if (v_G82_22 != NIL) {
t1 = v_G82_22;
} else {
v_X_23 = GET_OE_SLOT(t0,3);
v_X_25 = GET_OE_SLOT(t0,3);
v_Y_26 = LREF(s_lsp_NIL);
t1 = (((GET_OE_SLOT(t0,3)) == (LREF(s_lsp_NIL))) ? T : NIL);
}
if (t1 != NIL) {
v_X_6 = LREF(k2);
v_STREAM_28 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(k2));
} else {
v_STREAM_28 = GET_OE_SLOT(t0,3);
}
SET_OE_SLOT(t0,5,v_STREAM_28);
t2 = MAKE_CLOSURE(p_lsp_COMPILE_2DFORMAT_2DWRITE_2DCONST_2DSTRING0,t0);
f_WRITE_2DCONST_2DSTRING_29 = t2;
SET_OE_SLOT(t0,4,f_WRITE_2DCONST_2DSTRING_29);
t3 = MAKE_CLOSURE(p_lsp_COMPILE_2DFORMAT_2DMUNCH1,t0);
f_MUNCH_30 = t3;
SET_OE_SLOT(t0,0,f_MUNCH_30);
t4 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(MV_CALL(argc,4), (LP) 0, (LP) 0, (LP) 0, LREF(s_lsp_NIL));
return(t4);
}

LP p_lsp_COMPILE_2DFORMAT_2DMUNCH1(argc, v_START_0, v_END_1, v_ARGI_2, v_OUT_3)
      ARGC argc;  LP v_START_0; LP v_END_1; LP v_ARGI_2; LP v_OUT_3;
{
LP v_CHAR2_88; LP v_CHAR1_87; LP v_X_85; 
LP v_Y_83; LP v_X_82; LP v_Y_80; 
LP v_X_79; LP v_X_77; LP v_KEY86_76; 
LP v_FORM_75; LP v_X_73; LP v_Y_71; 
LP v_X_70; LP v_Y_68; LP v_X_67; 
LP v_Y_65; LP v_X_64; LP v_Y_62; 
LP v_X_61; LP v_Y_59; LP v_X_58; 
LP v_Y_56; LP v_X_55; LP v_Y_53; 
LP v_X_52; LP v_Y_50; LP v_X_49; 
LP v_Y_47; LP v_X_46; LP v_Y_44; 
LP v_X_43; LP v_Y_41; LP v_X_40; 
LP v_Y_38; LP v_X_37; LP v_Y_35; 
LP v_X_34; LP v_Y_32; LP v_X_31; 
LP v_KEY83_29; LP v_X_27; LP v_NEXT_2DARG_25; 
LP v_CONST_2DSTR_24; LP v_Y_22; LP v_X_21; 
LP v_Y_19; LP v_X_18; LP v_Y_16; 
LP v_X_15; LP v_Y_13; LP v_X_12; 
LP v_Y_10; LP v_X_9; LP v_Y_7; 
LP v_X_6; LP v_BODY_5; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; 
if (argc != 4) wna(argc,4);
t0 = OE;
t3 = ICALL(s_lsp_LENGTH) (1, GET_OE_SLOT(t0,6));
t2 = (geq_p((v_END_1), (t3)));
if (t2 != NIL) {
t5 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,4)))(2, v_START_0, v_END_1);
t4 = ICALL(s_lsp_APPEND_2F2) (2, t5, v_OUT_3);
v_BODY_5 = ICALL(s_lsp_REVERSE) (1, t4);
v_X_21 = GET_OE_SLOT(t0,3);
v_Y_22 = GET_OE_SLOT(t0,5);
if (((GET_OE_SLOT(t0,3)) == (GET_OE_SLOT(t0,5)))) {
v_Y_7 = ICALL(s_lsp_APPEND_2F2) (2, v_BODY_5, LREF(k3));
t1 = (c_cons((LREF(s_lsp_PROGN)), (v_Y_7)));
return(t1);
} else {
if (GET_OE_SLOT(t0,3) != NIL) {
v_X_12 = GET_OE_SLOT(t0,3);
v_Y_13 = LREF(s_lsp_NIL);
v_Y_16 = (c_cons((GET_OE_SLOT(t0,3)), (LREF(s_lsp_NIL))));
v_X_18 = (c_cons((GET_OE_SLOT(t0,5)), (v_Y_16)));
t7 = (c_cons((v_X_18), (LREF(s_lsp_NIL))));
t8 = ICALL(s_lsp_APPEND_2F2) (2, v_BODY_5, LREF(k3));
t1 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,3), LREF(s_lsp_LET), t7, t8);
return(t1);
} else {
v_X_9 = GET_OE_SLOT(t0,5);
v_Y_10 = LREF(s_lsp_NIL);
t9 = (c_cons((GET_OE_SLOT(t0,5)), (LREF(s_lsp_NIL))));
t1 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,3), LREF(s_lsp_WITH_2DOUTPUT_2DTO_2DSTRING), t9, v_BODY_5);
return(t1);
}
}
} else {
v_CHAR1_87 = (vref((GET_OE_SLOT(t0,6)), (v_END_1)));
if (((v_CHAR1_87) == (LREF(char_tab[126])))) {
v_CONST_2DSTR_24 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,4)))(2, v_START_0, v_END_1);
t12 = ICALL(s_lsp_LENGTH) (1, GET_OE_SLOT(t0,2));
t11 = (lessp((v_ARGI_2), (t12)));
if (t11 != NIL) {
v_NEXT_2DARG_25 = ICALL(s_lsp_ELT) (2, GET_OE_SLOT(t0,2), v_ARGI_2);
} else {
v_NEXT_2DARG_25 = LREF(s_lsp_NIL);
}
v_X_27 = v_END_1;
t14 = (add((v_END_1), ((LP) 2)));
t13 = (vref((GET_OE_SLOT(t0,6)), (t14)));
v_KEY83_29 = ICALL(s_lsp_CHAR_2DUPCASE) (1, t13);
v_X_73 = v_KEY83_29;
if (OTHER_PTRP((v_KEY83_29)) && (TAG((v_KEY83_29)) == 7)) {
t17 = INT_TO_FX(((int) RAW_CHAR(v_KEY83_29)));
switch ((int) t17) {
case 130:
v_X_31 = GET_OE_SLOT(t0,5);
v_Y_32 = LREF(s_lsp_NIL);
v_Y_35 = (c_cons((GET_OE_SLOT(t0,5)), (LREF(s_lsp_NIL))));
v_Y_38 = (c_cons((v_NEXT_2DARG_25), (v_Y_35)));
t16 = (c_cons((LREF(s_lsp_PRINC)), (v_Y_38)));
break;
case 166:
v_X_40 = GET_OE_SLOT(t0,5);
v_Y_41 = LREF(s_lsp_NIL);
v_Y_44 = (c_cons((GET_OE_SLOT(t0,5)), (LREF(s_lsp_NIL))));
v_Y_47 = (c_cons((v_NEXT_2DARG_25), (v_Y_44)));
t16 = (c_cons((LREF(s_lsp_PRIN1)), (v_Y_47)));
break;
case 134:
v_X_49 = GET_OE_SLOT(t0,5);
v_Y_50 = LREF(s_lsp_NIL);
v_Y_53 = (c_cons((GET_OE_SLOT(t0,5)), (LREF(s_lsp_NIL))));
v_Y_56 = (c_cons((v_NEXT_2DARG_25), (v_Y_53)));
t16 = (c_cons((LREF(s_lsp_WRITE_2DCHAR)), (v_Y_56)));
break;
case 74:
v_X_58 = GET_OE_SLOT(t0,5);
v_Y_59 = LREF(s_lsp_NIL);
v_Y_62 = (c_cons((GET_OE_SLOT(t0,5)), (LREF(s_lsp_NIL))));
t16 = (c_cons((LREF(s_lsp_TERPRI)), (v_Y_62)));
break;
case 176:
t16 = ICALL(s_lsp_LIST) (6, LREF(s_lsp_WRITE), v_NEXT_2DARG_25, LREF(s_key_BASE), (LP) 32, LREF(s_key_STREAM), GET_OE_SLOT(t0,5));
break;
case 136:
t16 = ICALL(s_lsp_LIST) (6, LREF(s_lsp_WRITE), v_NEXT_2DARG_25, LREF(s_key_BASE), (LP) 20, LREF(s_key_STREAM), GET_OE_SLOT(t0,5));
break;
case 158:
t16 = ICALL(s_lsp_LIST) (6, LREF(s_lsp_WRITE), v_NEXT_2DARG_25, LREF(s_key_BASE), (LP) 16, LREF(s_key_STREAM), GET_OE_SLOT(t0,5));
break;
case 132:
t16 = ICALL(s_lsp_LIST) (6, LREF(s_lsp_WRITE), v_NEXT_2DARG_25, LREF(s_key_BASE), (LP) 4, LREF(s_key_STREAM), GET_OE_SLOT(t0,5));
break;
case 252:
v_X_64 = GET_OE_SLOT(t0,5);
v_Y_65 = LREF(s_lsp_NIL);
v_Y_68 = (c_cons((GET_OE_SLOT(t0,5)), (LREF(s_lsp_NIL))));
v_Y_71 = (c_cons((LREF(k4)), (v_Y_68)));
t16 = (c_cons((LREF(s_lsp_WRITE_2DSTRING)), (v_Y_71)));
break;
default:
goto t_DEFAULT_2DTAG84_30;
break;
}
v_FORM_75 = t16;
goto b_CASE85_26;
}
t_DEFAULT_2DTAG84_30:;
v_FORM_75 = LREF(s_key_ABORT);
goto b_CASE85_26;
v_FORM_75 = NIL;
v_FORM_75 = v_FORM_75;
b_CASE85_26:;
v_KEY86_76 = v_FORM_75;
v_X_82 = v_FORM_75;
v_Y_83 = LREF(s_key_ABORT);
t18 = (c_eql((v_FORM_75), (LREF(s_key_ABORT))));
if (t18 != NIL) {
return(GET_OE_SLOT(t0,1));
} else {
t19 = (add((v_END_1), ((LP) 4)));
t20 = (add((v_END_1), ((LP) 4)));
v_X_77 = v_ARGI_2;
t21 = (add((v_ARGI_2), ((LP) 2)));
v_Y_80 = ICALL(s_lsp_APPEND_2F2) (2, v_CONST_2DSTR_24, v_OUT_3);
t22 = (c_cons((v_FORM_75), (v_Y_80)));
t1 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(MV_CALL(argc,4), t19, t20, t21, t22);
return(t1);
}
} else {
v_X_85 = v_END_1;
t23 = (add((v_END_1), ((LP) 2)));
t1 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(MV_CALL(argc,4), v_START_0, t23, v_ARGI_2, v_OUT_3);
return(t1);
}
}
}

LP p_lsp_COMPILE_2DFORMAT_2DWRITE_2DCONST_2DSTRING0(argc, v_START_0, v_END_1)
      ARGC argc;  LP v_START_0; LP v_END_1;
{
LP v_Y_20; LP v_X_19; LP v_Y_17; 
LP v_X_16; LP v_Y_14; LP v_X_13; 
LP v_Y_11; LP v_X_10; LP v_END_8; 
LP v_START_7; LP v_SEQ_6; LP v_START_4; 
LP v_SEQ_3; LP v_END_5; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; 
if (argc != 2) wna(argc,2);
t0 = OE;
t2 = (num_equal_p((v_START_0), (v_END_1)));
if (t2 != NIL) {
return(LREF(s_lsp_NIL));
} else {
v_SEQ_6 = GET_OE_SLOT(t0,6);
v_START_7 = v_START_0;
v_END_8 = v_END_1;
v_X_13 = ICALL(s_lsp_SUBSEQ_2D1) (3, GET_OE_SLOT(t0,6), v_START_0, v_END_1);
v_X_10 = GET_OE_SLOT(t0,5);
v_Y_11 = LREF(s_lsp_NIL);
v_Y_14 = (c_cons((GET_OE_SLOT(t0,5)), (LREF(s_lsp_NIL))));
v_Y_17 = (c_cons((v_X_13), (v_Y_14)));
v_X_19 = (c_cons((LREF(s_lsp_WRITE_2DSTRING)), (v_Y_17)));
t1 = (c_cons((v_X_19), (LREF(s_lsp_NIL))));
return(t1);
}
}

