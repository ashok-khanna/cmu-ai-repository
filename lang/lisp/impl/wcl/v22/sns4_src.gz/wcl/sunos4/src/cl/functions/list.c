/*
:comment "Compiled at 4:08:17 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: Debug Library"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O2 -fPIC"
:version 0
:end-package-info 0
:proclaim (QUOTE (INLINE CONS))
:sf CONS "p_lsp_CONS"
:proclaim (QUOTE (INLINE CAR))
:sym LISTP
:sym LIST
:sym WTA
:sf CAR "p_lsp_CAR"
:proclaim (QUOTE (INLINE CDR))
:sf CDR "p_lsp_CDR"
:proclaim (QUOTE (INLINE SET-CAR))
:sf SET-CAR "p_lsp_SET_2DCAR"
:proclaim (QUOTE (INLINE SET-CDR))
:sf SET-CDR "p_lsp_SET_2DCDR"
:proclaim (QUOTE (INLINE RPLACA))
:sf RPLACA "p_lsp_RPLACA"
:proclaim (QUOTE (INLINE RPLACD))
:sf RPLACD "p_lsp_RPLACD"
:proclaim (QUOTE (INLINE CAAAAR))
:sf CAAAAR "p_lsp_CAAAAR"
:proclaim (QUOTE (INLINE CAAADR))
:sf CAAADR "p_lsp_CAAADR"
:proclaim (QUOTE (INLINE CAAAR))
:sf CAAAR "p_lsp_CAAAR"
:proclaim (QUOTE (INLINE CAADAR))
:sf CAADAR "p_lsp_CAADAR"
:proclaim (QUOTE (INLINE CAADDR))
:sf CAADDR "p_lsp_CAADDR"
:proclaim (QUOTE (INLINE CAADR))
:sf CAADR "p_lsp_CAADR"
:proclaim (QUOTE (INLINE CAAR))
:sf CAAR "p_lsp_CAAR"
:proclaim (QUOTE (INLINE CADAAR))
:sf CADAAR "p_lsp_CADAAR"
:proclaim (QUOTE (INLINE CADADR))
:sf CADADR "p_lsp_CADADR"
:proclaim (QUOTE (INLINE CADAR))
:sf CADAR "p_lsp_CADAR"
:proclaim (QUOTE (INLINE CADDAR))
:sf CADDAR "p_lsp_CADDAR"
:proclaim (QUOTE (INLINE CADDDR))
:sf CADDDR "p_lsp_CADDDR"
:proclaim (QUOTE (INLINE CADDR))
:sf CADDR "p_lsp_CADDR"
:proclaim (QUOTE (INLINE CADR))
:sf CADR "p_lsp_CADR"
:proclaim (QUOTE (INLINE CDAAAR))
:sf CDAAAR "p_lsp_CDAAAR"
:proclaim (QUOTE (INLINE CDAADR))
:sf CDAADR "p_lsp_CDAADR"
:proclaim (QUOTE (INLINE CDAAR))
:sf CDAAR "p_lsp_CDAAR"
:proclaim (QUOTE (INLINE CDADAR))
:sf CDADAR "p_lsp_CDADAR"
:proclaim (QUOTE (INLINE CDADDR))
:sf CDADDR "p_lsp_CDADDR"
:proclaim (QUOTE (INLINE CDADR))
:sf CDADR "p_lsp_CDADR"
:proclaim (QUOTE (INLINE CDAR))
:sf CDAR "p_lsp_CDAR"
:proclaim (QUOTE (INLINE CDDAAR))
:sf CDDAAR "p_lsp_CDDAAR"
:proclaim (QUOTE (INLINE CDDADR))
:sf CDDADR "p_lsp_CDDADR"
:proclaim (QUOTE (INLINE CDDAR))
:sf CDDAR "p_lsp_CDDAR"
:proclaim (QUOTE (INLINE CDDDAR))
:sf CDDDAR "p_lsp_CDDDAR"
:proclaim (QUOTE (INLINE CDDDDR))
:sf CDDDDR "p_lsp_CDDDDR"
:proclaim (QUOTE (INLINE CDDDR))
:sf CDDDR "p_lsp_CDDDR"
:proclaim (QUOTE (INLINE CDDR))
:sf CDDR "p_lsp_CDDR"
:proclaim (QUOTE (INLINE FIRST))
:sf FIRST "p_lsp_FIRST"
:proclaim (QUOTE (INLINE SECOND))
:sf SECOND "p_lsp_SECOND"
:proclaim (QUOTE (INLINE THIRD))
:sf THIRD "p_lsp_THIRD"
:proclaim (QUOTE (INLINE FOURTH))
:sf FOURTH "p_lsp_FOURTH"
:proclaim (QUOTE (INLINE FIFTH))
:sym NTH
:sf FIFTH "p_lsp_FIFTH"
:proclaim (QUOTE (INLINE SIXTH))
:sf SIXTH "p_lsp_SIXTH"
:proclaim (QUOTE (INLINE SEVENTH))
:sf SEVENTH "p_lsp_SEVENTH"
:proclaim (QUOTE (INLINE EIGHTH))
:sf EIGHTH "p_lsp_EIGHTH"
:proclaim (QUOTE (INLINE NINTH))
:sf NINTH "p_lsp_NINTH"
:proclaim (QUOTE (INLINE TENTH))
:sf TENTH "p_lsp_TENTH"
:sym T
:sym NIL
:sf ACCUMULATE-RL "p_lsp_ACCUMULATE_2DRL"
:sf ACONS "p_lsp_ACONS"
:sym MEMBER/4
:sf ADJOIN/4 "p_lsp_ADJOIN_2F4"
:sym :TEST
:sym :TEST-NOT
:sym :KEY
:sym IDENTITY
:sym UNSAFE-SYMBOL-FUNCTION
:sym EQL
:sym ADJOIN/4
:sym NOT
:sf ADJOIN "p_lsp_ADJOIN"
:sym APPEND/2
:sf APPEND/2 "p_lsp_APPEND_2F2"
:sym LENGTH
:sym ACCUMULATE-RL
:sf APPEND "p_lsp_APPEND"
:sf ASSOC/4 "p_lsp_ASSOC_2F4"
:sym ASSOC/4
:sf ASSOC "p_lsp_ASSOC"
:sym EQ
:sf ASSQ "p_lsp_ASSQ"
:sf ASSQL "p_lsp_ASSQL"
:sf BUTLAST/2 "p_lsp_BUTLAST_2F2"
:sym BUTLAST/2
:sf BUTLAST "p_lsp_BUTLAST"
:sym ATOM
:sym ERROR
:sym NULL
:sf COPY-ALIST "p_lsp_COPY_2DALIST"
:sym COPY-LIST
:sf COPY-LIST "p_lsp_COPY_2DLIST"
:sym COPY-TREE
:sf COPY-TREE "p_lsp_COPY_2DTREE"
:proclaim (QUOTE (INLINE ENDP))
:sf ENDP "p_lsp_ENDP"
:sf INTERSECTION "p_lsp_INTERSECTION"
:sym CONSP
:sf LAST "p_lsp_LAST"
:sf LDIFF "p_lsp_LDIFF"
:sf LENGTH/LIST "p_lsp_LENGTH_2FLIST"
:sf LIST-LENGTH "p_lsp_LIST_2DLENGTH"
:sym LIST*-1
:sf LIST*-1 "p_lsp_LIST_2A_2D1"
:sf LIST* "p_lsp_LIST_2A"
:sf LIST "p_lsp_LIST"
:sf MAKE-LIST-1 "p_lsp_MAKE_2DLIST_2D1"
:sym :INITIAL-ELEMENT
:sym MAKE-LIST-1
:sf MAKE-LIST "p_lsp_MAKE_2DLIST"
:sf MAPC "p_lsp_MAPC"
:sym MAPCAN/2
:sym NCONC/2
:sf MAPCAN/2 "p_lsp_MAPCAN_2F2"
:sf MAPCAN "p_lsp_MAPCAN"
:sym MAPCAR/2
:sf MAPCAR/2 "p_lsp_MAPCAR_2F2"
:sf MAPCAR "p_lsp_MAPCAR"
:sf MEMBER/4 "p_lsp_MEMBER_2F4"
:sf MEMBER-IF "p_lsp_MEMBER_2DIF"
:sf MEMBER "p_lsp_MEMBER"
:sf MEMQ "p_lsp_MEMQ"
:sym MEMQ
:sf MEMQL "p_lsp_MEMQL"
:sym 1-
:sf NBUTLAST "p_lsp_NBUTLAST"
:sf NCONC/2 "p_lsp_NCONC_2F2"
:sf NCONC "p_lsp_NCONC"
:sf NINTERSECTION "p_lsp_NINTERSECTION"
:sym NREVERSE
:sf NRECONC "p_lsp_NRECONC"
:sf NREVERSE/LIST "p_lsp_NREVERSE_2FLIST"
:sf NSET-DIFFERENCE "p_lsp_NSET_2DDIFFERENCE"
:sf NSET-EXCLUSIVE-OR "p_lsp_NSET_2DEXCLUSIVE_2DOR"
:sf NSUBST "p_lsp_NSUBST"
:sf NTH "p_lsp_NTH"
:sf NTHCDR "p_lsp_NTHCDR"
:sf NUNION "p_lsp_NUNION"
:sf PAIRLIS/3 "p_lsp_PAIRLIS_2F3"
:proclaim (QUOTE (INLINE PAIRLIS))
:sym PAIRLIS/3
:sf PAIRLIS "p_lsp_PAIRLIS"
:sf RASSOC/4 "p_lsp_RASSOC_2F4"
:sym RASSOC/4
:sf RASSOC "p_lsp_RASSOC"
:proclaim (QUOTE (INLINE REST))
:sf REST "p_lsp_REST"
:sf REVAPPEND "p_lsp_REVAPPEND"
:sf REVERSE/LIST "p_lsp_REVERSE_2FLIST"
:sf SET-DIFFERENCE "p_lsp_SET_2DDIFFERENCE"
:sf SET-EXCLUSIVE-OR "p_lsp_SET_2DEXCLUSIVE_2DOR"
:sf SET-NTH "p_lsp_SET_2DNTH"
:sym SUBLIS/4
:sf SUBLIS/4 "p_lsp_SUBLIS_2F4"
:sf SUBLIS "p_lsp_SUBLIS"
:sf SUBSETP "p_lsp_SUBSETP"
:sym SUBST
:sf SUBST "p_lsp_SUBST"
:sf UNION "p_lsp_UNION"
:pinfo NUNION (LIST1 LIST2 &KEY (KEY (FUNCTION IDENTITY)) (TEST (FUNCTION EQL) TESTP) (TEST-NOT NIL NOTP)) NIL NIL NIL NIL NIL NIL T
:pinfo MEMBER-IF (TEST LIST &KEY (KEY (FUNCTION IDENTITY))) NIL NIL NIL NIL NIL NIL T
:pinfo CADR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CADR (CAR (CDR C)))) NIL T T
:pinfo CONS (X Y) NIL NIL NIL (LAMBDA (X Y) (DECLARE) (BLOCK CONS (C_CONS X Y))) NIL T T
:pinfo ASSQ (X A-LIST) NIL NIL NIL NIL NIL NIL T
:pinfo CAADDR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CAADDR (CAR (CAR (CDR (CDR C)))))) NIL T T
:pinfo CADAR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CADAR (CAR (CDR (CAR C))))) NIL T T
:pinfo ADJOIN/4 (ITEM LIST TEST KEY) NIL NIL NIL NIL NIL NIL T
:pinfo SET-CAR (X V) NIL (LIST T) NIL (LAMBDA (X V) (DECLARE) (BLOCK SET-CAR (%32BIT-DEF X 0 V) V)) NIL T T
:pinfo FIRST (LIST) NIL NIL NIL (LAMBDA (LIST) (DECLARE) (BLOCK FIRST (CAR LIST))) NIL T T
:pinfo CADADR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CADADR (CAR (CDR (CAR (CDR C)))))) NIL T T
:pinfo CDAAR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CDAAR (CDR (CAR (CAR C))))) NIL T T
:pinfo BUTLAST (LIST &OPTIONAL (N 1)) NIL NIL NIL NIL NIL NIL T
:pinfo COPY-ALIST (ALIST) NIL NIL NIL NIL NIL NIL T
:pinfo COPY-LIST (LIST) NIL NIL NIL NIL NIL NIL T
:pinfo MEMBER/4 (X LIST TEST KEY) NIL NIL NIL NIL NIL NIL T
:pinfo NREVERSE/LIST (L) NIL NIL NIL NIL NIL NIL T
:pinfo NTHCDR (I L) NIL NIL NIL NIL NIL NIL T
:pinfo RASSOC/4 (X A-LIST TEST KEY) NIL NIL NIL NIL NIL NIL T
:pinfo SET-DIFFERENCE (LIST1 LIST2 &KEY (KEY (FUNCTION IDENTITY)) (TEST (FUNCTION EQL) TESTP) (TEST-NOT NIL NOTP)) NIL NIL NIL NIL NIL NIL T
:pinfo CAAR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CAAR (CAR (CAR C)))) NIL T T
:pinfo CDDDDR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CDDDDR (CDR (CDR (CDR (CDR C)))))) NIL T T
:pinfo COPY-TREE (TREE) NIL NIL NIL NIL NIL NIL T
:pinfo LENGTH/LIST (X) NIL NIL NIL NIL NIL NIL T
:pinfo SET-EXCLUSIVE-OR (LIST1 LIST2 &KEY (KEY (FUNCTION IDENTITY)) (TEST (FUNCTION EQL) TESTP) (TEST-NOT NIL NOTP)) NIL NIL NIL NIL NIL NIL T
:pinfo MAPCAR/2 (FUNC ARG-LISTS) NIL NIL NIL NIL NIL NIL T
:pinfo RPLACA (C NEW-CAR) NIL NIL NIL (LAMBDA (C NEW-CAR) (DECLARE) (BLOCK RPLACA (SET-CAR C NEW-CAR) C)) NIL T T
:pinfo CAADAR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CAADAR (CAR (CAR (CDR (CAR C)))))) NIL T T
:pinfo LIST-LENGTH (X) NIL NIL NIL NIL NIL NIL T
:pinfo RPLACD (C NEW-CDR) NIL NIL NIL (LAMBDA (C NEW-CDR) (DECLARE) (BLOCK RPLACD (SET-CDR C NEW-CDR) C)) NIL T T
:pinfo FIFTH (LIST) NIL NIL NIL (LAMBDA (LIST) (DECLARE) (BLOCK FIFTH (NTH 4 LIST))) NIL T T
:pinfo CADAAR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CADAAR (CAR (CDR (CAR (CAR C)))))) NIL T T
:pinfo MEMBER (X LIST &KEY TEST TEST-NOT (KEY (FUNCTION IDENTITY))) NIL NIL NIL NIL NIL NIL T
:pinfo NTH (I L) NIL NIL NIL NIL NIL NIL T
:pinfo CDDDAR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CDDDAR (CDR (CDR (CDR (CAR C)))))) NIL T T
:pinfo ACONS (KEY DATA A-LIST) NIL NIL NIL NIL NIL NIL T
:pinfo SUBST (NEW OLD TREE) NIL NIL NIL NIL NIL NIL T
:pinfo LIST (&REST L) NIL NIL NIL NIL NIL NIL T
:pinfo CDDDR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CDDDR (CDR (CDR (CDR C))))) NIL T T
:pinfo NCONC (&RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo MAKE-LIST-1 (SIZE INITIAL-ELEMENT) NIL NIL NIL NIL NIL NIL T
:pinfo MEMQ (E L) NIL NIL NIL NIL NIL NIL T
:pinfo REST (LIST) NIL NIL NIL (LAMBDA (LIST) (DECLARE) (BLOCK REST (CDR LIST))) NIL T T
:pinfo CDDR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CDDR (CDR (CDR C)))) NIL T T
:pinfo SET-NTH (I L VALUE) NIL NIL NIL NIL NIL NIL T
:pinfo SUBSETP (LIST1 LIST2 &KEY (KEY (FUNCTION IDENTITY)) (TEST (FUNCTION EQL) TESTP) (TEST-NOT NIL NOTP)) NIL NIL NIL NIL NIL NIL T
:pinfo LIST*-1 (REST) NIL NIL NIL NIL NIL NIL T
:pinfo MAKE-LIST (SIZE &KEY INITIAL-ELEMENT) NIL NIL NIL NIL NIL NIL T
:pinfo BUTLAST/2 (LIST N) NIL NIL NIL NIL NIL NIL T
:pinfo MAPCAN (FUNC &REST ARG-LISTS) NIL NIL NIL NIL NIL NIL T
:pinfo SIXTH (LIST) NIL NIL NIL (LAMBDA (LIST) (DECLARE) (BLOCK SIXTH (NTH 5 LIST))) NIL T T
:pinfo SUBLIS (ALIST TREE &KEY TEST TEST-NOT (KEY (FUNCTION IDENTITY))) NIL NIL NIL NIL NIL NIL T
:pinfo MAPCAR (FUNC &REST ARG-LISTS) NIL NIL NIL NIL NIL NIL T
:pinfo CADDDR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CADDDR (CAR (CDR (CDR (CDR C)))))) NIL T T
:pinfo CDAADR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CDAADR (CDR (CAR (CAR (CDR C)))))) NIL T T
:pinfo CDDAR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CDDAR (CDR (CDR (CAR C))))) NIL T T
:pinfo RASSOC (X A-LIST &KEY TEST TEST-NOT (KEY (FUNCTION IDENTITY))) NIL NIL NIL NIL NIL NIL T
:pinfo CDAR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CDAR (CDR (CAR C)))) NIL T T
:pinfo SEVENTH (LIST) NIL NIL NIL (LAMBDA (LIST) (DECLARE) (BLOCK SEVENTH (NTH 6 LIST))) NIL T T
:pinfo MAPC (FUNCTION LIST) NIL NIL NIL NIL NIL NIL T
:pinfo ASSQL (X A-LIST) NIL NIL NIL NIL NIL NIL T
:pinfo MAPCAN/2 (FUNC ARG-LISTS) NIL NIL NIL NIL NIL NIL T
:pinfo UNION (LIST1 LIST2 &KEY (KEY (FUNCTION IDENTITY)) (TEST (FUNCTION EQL) TESTP) (TEST-NOT NIL NOTP)) NIL NIL NIL NIL NIL NIL T
:pinfo SECOND (LIST) NIL NIL NIL (LAMBDA (LIST) (DECLARE) (BLOCK SECOND (CADR LIST))) NIL T T
:pinfo CADDAR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CADDAR (CAR (CDR (CDR (CAR C)))))) NIL T T
:pinfo CDAAAR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CDAAAR (CDR (CAR (CAR (CAR C)))))) NIL T T
:pinfo FOURTH (LIST) NIL NIL NIL (LAMBDA (LIST) (DECLARE) (BLOCK FOURTH (CADDDR LIST))) NIL T T
:pinfo NINTH (LIST) NIL NIL NIL (LAMBDA (LIST) (DECLARE) (BLOCK NINTH (NTH 8 LIST))) NIL T T
:pinfo ASSOC (X A-LIST &KEY TEST TEST-NOT (KEY (FUNCTION IDENTITY))) NIL NIL NIL NIL NIL NIL T
:pinfo ENDP (X) NIL NIL NIL (LAMBDA (X) (DECLARE) (BLOCK ENDP (NULL X))) NIL T T
:pinfo LAST (L) NIL NIL NIL NIL NIL NIL T
:pinfo LIST* (&REST ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo NCONC/2 (X Y) NIL NIL NIL NIL NIL NIL T
:pinfo NSET-EXCLUSIVE-OR (LIST1 LIST2 &KEY (TEST (FUNCTION EQL)) (TEST-NOT NIL NOTP) (KEY (FUNCTION IDENTITY))) NIL NIL NIL NIL NIL NIL T
:pinfo REVAPPEND (X Y) NIL NIL NIL NIL NIL NIL T
:pinfo REVERSE/LIST (S) NIL NIL NIL NIL NIL NIL T
:pinfo CAADR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CAADR (CAR (CAR (CDR C))))) NIL T T
:pinfo SUBLIS/4 (ALIST TREE TEST KEY) NIL NIL NIL NIL NIL NIL T
:pinfo EIGHTH (LIST) NIL NIL NIL (LAMBDA (LIST) (DECLARE) (BLOCK EIGHTH (NTH 7 LIST))) NIL T T
:pinfo NBUTLAST (LIST &OPTIONAL (N 1)) NIL NIL NIL NIL NIL NIL T
:pinfo APPEND/2 (X Y) NIL (LIST T) NIL NIL NIL NIL T
:pinfo TENTH (LIST) NIL NIL NIL (LAMBDA (LIST) (DECLARE) (BLOCK TENTH (NTH 9 LIST))) NIL T T
:pinfo LDIFF (LIST SUBLIST) NIL NIL NIL NIL NIL NIL T
:pinfo CAAADR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CAAADR (CAR (CAR (CAR (CDR C)))))) NIL T T
:pinfo CAAAR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CAAAR (CAR (CAR (CAR C))))) NIL T T
:pinfo NINTERSECTION (LIST1 LIST2 &KEY (KEY (FUNCTION IDENTITY)) (TEST (FUNCTION EQL) TESTP) (TEST-NOT NIL NOTP)) NIL NIL NIL NIL NIL NIL T
:pinfo THIRD (LIST) NIL NIL NIL (LAMBDA (LIST) (DECLARE) (BLOCK THIRD (CADDR LIST))) NIL T T
:pinfo NSUBST (NEW OLD TREE &KEY (KEY (FUNCTION IDENTITY)) (TEST (FUNCTION EQL) TESTP) (TEST-NOT NIL NOTP)) NIL NIL NIL NIL NIL NIL T
:pinfo INTERSECTION (LIST1 LIST2 &KEY (KEY (FUNCTION IDENTITY)) (TEST (FUNCTION EQL) TESTP) (TEST-NOT NIL NOTP)) NIL NIL NIL NIL NIL NIL T
:pinfo PAIRLIS (KEYS VALUES &OPTIONAL A-LIST) NIL NIL NIL (LAMBDA (KEYS VALUES &OPTIONAL A-LIST) (DECLARE) (BLOCK PAIRLIS (PAIRLIS/3 KEYS VALUES A-LIST))) NIL T T
:pinfo CDADDR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CDADDR (CDR (CAR (CDR (CDR C)))))) NIL T T
:pinfo MEMQL (E L) NIL NIL NIL NIL NIL NIL T
:pinfo NSET-DIFFERENCE (LIST1 LIST2 &KEY (KEY (FUNCTION IDENTITY)) (TEST (FUNCTION EQL) TESTP) (TEST-NOT NIL NOTP)) NIL NIL NIL NIL NIL NIL T
:pinfo PAIRLIS/3 (KEYS VALUES A-LIST) NIL NIL NIL NIL NIL NIL T
:pinfo ACCUMULATE-RL (OP N ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo CDDADR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CDDADR (CDR (CDR (CAR (CDR C)))))) NIL T T
:pinfo CDR (X) NIL (LIST) NIL (LAMBDA (X) (DECLARE) (BLOCK CDR (%32BIT-REF X 1))) NIL T T
:pinfo NRECONC (X Y) NIL NIL NIL NIL NIL NIL T
:pinfo CAAAAR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CAAAAR (CAR (CAR (CAR (CAR C)))))) NIL T T
:pinfo CDADAR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CDADAR (CDR (CAR (CDR (CAR C)))))) NIL T T
:pinfo APPEND (&RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo CDDAAR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CDDAAR (CDR (CDR (CAR (CAR C)))))) NIL T T
:pinfo ADJOIN (ITEM LIST &KEY TEST TEST-NOT (KEY (FUNCTION IDENTITY))) NIL NIL NIL NIL NIL NIL T
:pinfo CAR (X) NIL (LIST) NIL (LAMBDA (X) (DECLARE) (BLOCK CAR (%32BIT-REF X 0))) NIL T T
:pinfo CADDR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CADDR (CAR (CDR (CDR C))))) NIL T T
:pinfo SET-CDR (X V) NIL (LIST T) NIL (LAMBDA (X V) (DECLARE) (BLOCK SET-CDR (%32BIT-DEF X 1 V) V)) NIL T T
:pinfo CDADR (C) NIL NIL NIL (LAMBDA (C) (DECLARE) (BLOCK CDADR (CDR (CAR (CDR C))))) NIL T T
:pinfo ASSOC/4 (X A-LIST TEST KEY) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_lsp_CONS();
extern LP p_lsp_CAR();
extern SYMBOL s_lsp_LISTP; 
extern SYMBOL s_lsp_LIST; 
extern SYMBOL s_lsp_WTA; 
extern LP p_lsp_CDR();
extern LP p_lsp_SET_2DCAR();
extern LP p_lsp_SET_2DCDR();
extern LP p_lsp_RPLACA();
extern LP p_lsp_RPLACD();
extern LP p_lsp_CAAAAR();
extern LP p_lsp_CAAADR();
extern LP p_lsp_CAAAR();
extern LP p_lsp_CAADAR();
extern LP p_lsp_CAADDR();
extern LP p_lsp_CAADR();
extern LP p_lsp_CAAR();
extern LP p_lsp_CADAAR();
extern LP p_lsp_CADADR();
extern LP p_lsp_CADAR();
extern LP p_lsp_CADDAR();
extern LP p_lsp_CADDDR();
extern LP p_lsp_CADDR();
extern LP p_lsp_CADR();
extern LP p_lsp_CDAAAR();
extern LP p_lsp_CDAADR();
extern LP p_lsp_CDAAR();
extern LP p_lsp_CDADAR();
extern LP p_lsp_CDADDR();
extern LP p_lsp_CDADR();
extern LP p_lsp_CDAR();
extern LP p_lsp_CDDAAR();
extern LP p_lsp_CDDADR();
extern LP p_lsp_CDDAR();
extern LP p_lsp_CDDDAR();
extern LP p_lsp_CDDDDR();
extern LP p_lsp_CDDDR();
extern LP p_lsp_CDDR();
extern LP p_lsp_FIRST();
extern LP p_lsp_SECOND();
extern LP p_lsp_THIRD();
extern LP p_lsp_FOURTH();
extern LP p_lsp_FIFTH();
extern SYMBOL s_lsp_NTH; 
extern LP p_lsp_SIXTH();
extern LP p_lsp_SEVENTH();
extern LP p_lsp_EIGHTH();
extern LP p_lsp_NINTH();
extern LP p_lsp_TENTH();
extern LP p_lsp_ACCUMULATE_2DRL();
extern SYMBOL s_lsp_T; 
extern SYMBOL s_lsp_NIL; 
extern LP p_lsp_ACONS();
extern LP p_lsp_ADJOIN_2F4();
extern SYMBOL s_lsp_MEMBER_2F4; 
extern LP p_lsp_ADJOIN();
extern SYMBOL s_key_TEST; 
extern SYMBOL s_key_TEST_2DNOT; 
extern SYMBOL s_key_KEY; 
extern SYMBOL s_lsp_IDENTITY; 
extern SYMBOL s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION; 
extern LP p_lsp_ADJOIN_2Danon21532154();
extern SYMBOL s_lsp_EQL; 
extern SYMBOL s_lsp_ADJOIN_2F4; 
extern SYMBOL s_lsp_NOT; 
extern LP p_lsp_APPEND_2F2();
extern SYMBOL s_lsp_APPEND_2F2; 
extern LP p_lsp_APPEND();
extern SYMBOL s_lsp_LENGTH; 
extern SYMBOL s_lsp_ACCUMULATE_2DRL; 
extern LP p_lsp_ASSOC_2F4();
extern LP p_lsp_ASSOC();
extern LP p_lsp_ASSOC_2Danon21552156();
extern SYMBOL s_lsp_ASSOC_2F4; 
extern LP p_lsp_ASSQ();
extern SYMBOL s_lsp_EQ; 
extern LP p_lsp_ASSQL();
extern LP p_lsp_BUTLAST_2F2();
extern LP p_lsp_BUTLAST();
extern SYMBOL s_lsp_BUTLAST_2F2; 
extern LP p_lsp_COPY_2DALIST();
extern SYMBOL s_lsp_ATOM; 
MAKE_SIMPLE_STRING(k2157,17,"~S is not a list.");
extern SYMBOL s_lsp_ERROR; 
extern SYMBOL s_lsp_NULL; 
extern LP p_lsp_COPY_2DLIST();
extern SYMBOL s_lsp_COPY_2DLIST; 
extern LP p_lsp_COPY_2DTREE();
extern SYMBOL s_lsp_COPY_2DTREE; 
extern LP p_lsp_ENDP();
extern LP p_lsp_INTERSECTION();
MAKE_SIMPLE_STRING(k2160,32,"Test and test-not both supplied.");
extern LP p_lsp_INTERSECTION_2Danon21582159();
extern LP p_lsp_LAST();
extern SYMBOL s_lsp_CONSP; 
extern LP p_lsp_LDIFF();
extern LP p_lsp_LENGTH_2FLIST();
extern LP p_lsp_LIST_2DLENGTH();
extern LP p_lsp_LIST_2A_2D1();
extern SYMBOL s_lsp_LIST_2A_2D1; 
extern LP p_lsp_LIST_2A();
extern LP p_lsp_LIST();
extern LP p_lsp_MAKE_2DLIST_2D1();
extern LP p_lsp_MAKE_2DLIST();
extern SYMBOL s_key_INITIAL_2DELEMENT; 
extern SYMBOL s_lsp_MAKE_2DLIST_2D1; 
extern LP p_lsp_MAPC();
extern LP p_lsp_MAPCAN_2F2();
extern SYMBOL s_lsp_MAPCAN_2F2; 
extern SYMBOL s_lsp_NCONC_2F2; 
extern LP p_lsp_MAPCAN();
extern LP p_lsp_MAPCAR_2F2();
extern SYMBOL s_lsp_MAPCAR_2F2; 
extern LP p_lsp_MAPCAR();
extern LP p_lsp_MEMBER_2F4();
extern LP p_lsp_MEMBER_2DIF();
extern LP p_lsp_MEMBER();
extern LP p_lsp_MEMBER_2Danon21632164();
extern LP p_lsp_MEMQ();
extern LP p_lsp_MEMQL();
extern SYMBOL s_lsp_MEMQ; 
extern LP p_lsp_NBUTLAST();
extern SYMBOL s_lsp_1_2D; 
extern LP p_lsp_NCONC_2F2();
extern LP p_lsp_NCONC();
extern LP p_lsp_NINTERSECTION();
extern LP p_lsp_NINTERSECTION_2Danon21662167();
extern LP p_lsp_NRECONC();
extern SYMBOL s_lsp_NREVERSE; 
extern LP p_lsp_NREVERSE_2FLIST();
extern LP p_lsp_NREVERSE_2FLIST_2DDOIT2168();
extern LP p_lsp_NSET_2DDIFFERENCE();
extern LP p_lsp_NSET_2DDIFFERENCE_2Danon21692170();
extern LP p_lsp_NSET_2DEXCLUSIVE_2DOR();
extern LP p_lsp_NSUBST();
extern LP p_lsp_NSUBST_2DS2171();
extern LP p_lsp_NTH();
extern LP p_lsp_NTHCDR();
extern LP p_lsp_NUNION();
extern LP p_lsp_NUNION_2Danon21742175();
extern LP p_lsp_PAIRLIS_2F3();
extern LP p_lsp_PAIRLIS();
extern SYMBOL s_lsp_PAIRLIS_2F3; 
extern LP p_lsp_RASSOC_2F4();
extern LP p_lsp_RASSOC();
extern LP p_lsp_RASSOC_2Danon21772178();
extern SYMBOL s_lsp_RASSOC_2F4; 
extern LP p_lsp_REST();
extern LP p_lsp_REVAPPEND();
extern LP p_lsp_REVERSE_2FLIST();
extern LP p_lsp_REVERSE_2FLIST_2DDOIT2179();
extern LP p_lsp_SET_2DDIFFERENCE();
extern LP p_lsp_SET_2DDIFFERENCE_2Danon21802181();
extern LP p_lsp_SET_2DEXCLUSIVE_2DOR();
extern LP p_lsp_SET_2DEXCLUSIVE_2DOR_2Danon21822183();
extern LP p_lsp_SET_2DEXCLUSIVE_2DOR_2Danon21842185();
extern LP p_lsp_SET_2DNTH();
extern LP p_lsp_SUBLIS_2F4();
extern SYMBOL s_lsp_SUBLIS_2F4; 
extern LP p_lsp_SUBLIS();
extern LP p_lsp_SUBLIS_2Danon21872188();
extern LP p_lsp_SUBSETP();
extern LP p_lsp_SUBSETP_2Danon21892190();
extern LP p_lsp_SUBST();
extern SYMBOL s_lsp_SUBST; 
extern LP p_lsp_UNION();
extern LP p_lsp_UNION_2Danon21912192();


extern LP num_equal_p();
extern LP greaterp();
extern LP add();
extern LP leq_p();
extern LP subtract();
extern LP c_cons();


LP p_lsp_CONS(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = (c_cons((v_X_0), (v_Y_1)));
return(t0);
}

LP p_lsp_CAR(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_LISTP) (1, v_X_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_X_0, LREF(s_lsp_LIST), (LP) 0);
}
t1 = ((LP) DEREF((v_X_0) + 0 * 4));
return(t1);
}

LP p_lsp_CDR(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_LISTP) (1, v_X_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_X_0, LREF(s_lsp_LIST), (LP) 0);
}
t1 = ((LP) DEREF((v_X_0) + 1 * 4));
return(t1);
}

LP p_lsp_SET_2DCAR(argc, v_X_0, v_V_1)
      ARGC argc;  LP v_X_0; LP v_V_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_LISTP) (1, v_X_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_X_0, LREF(s_lsp_LIST), (LP) 0);
}
((LP) (DEREF((v_X_0) + 0 * 4) = (LD) (v_V_1)));
return(v_V_1);
}

LP p_lsp_SET_2DCDR(argc, v_X_0, v_V_1)
      ARGC argc;  LP v_X_0; LP v_V_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_LISTP) (1, v_X_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_X_0, LREF(s_lsp_LIST), (LP) 0);
}
((LP) (DEREF((v_X_0) + 1 * 4) = (LD) (v_V_1)));
return(v_V_1);
}

LP p_lsp_RPLACA(argc, v_C_0, v_NEW_2DCAR_1)
      ARGC argc;  LP v_C_0; LP v_NEW_2DCAR_1;
{
LP v_V_4; LP v_X_3; 
LP t0; LP t1; 
if (argc != 2) wna(argc,2);
v_V_4 = v_NEW_2DCAR_1;
((LP) (DEREF((v_C_0) + 0 * 4) = (LD) (v_V_4)));
return(v_C_0);
}

LP p_lsp_RPLACD(argc, v_C_0, v_NEW_2DCDR_1)
      ARGC argc;  LP v_C_0; LP v_NEW_2DCDR_1;
{
LP v_V_4; LP v_X_3; 
LP t0; LP t1; 
if (argc != 2) wna(argc,2);
v_V_4 = v_NEW_2DCDR_1;
((LP) (DEREF((v_C_0) + 1 * 4) = (LD) (v_V_4)));
return(v_C_0);
}

LP p_lsp_CAAAAR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_8; LP v_X_6; LP v_X_4; 
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 0 * 4));
v_X_6 = ((LP) DEREF((v_X_4) + 0 * 4));
v_X_8 = ((LP) DEREF((v_X_6) + 0 * 4));
t0 = ((LP) DEREF((v_X_8) + 0 * 4));
return(t0);
}

LP p_lsp_CAAADR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_8; LP v_X_6; LP v_X_4; 
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 1 * 4));
v_X_6 = ((LP) DEREF((v_X_4) + 0 * 4));
v_X_8 = ((LP) DEREF((v_X_6) + 0 * 4));
t0 = ((LP) DEREF((v_X_8) + 0 * 4));
return(t0);
}

LP p_lsp_CAAAR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_6; LP v_X_4; LP v_X_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 0 * 4));
v_X_6 = ((LP) DEREF((v_X_4) + 0 * 4));
t0 = ((LP) DEREF((v_X_6) + 0 * 4));
return(t0);
}

LP p_lsp_CAADAR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_8; LP v_X_6; LP v_X_4; 
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 0 * 4));
v_X_6 = ((LP) DEREF((v_X_4) + 1 * 4));
v_X_8 = ((LP) DEREF((v_X_6) + 0 * 4));
t0 = ((LP) DEREF((v_X_8) + 0 * 4));
return(t0);
}

LP p_lsp_CAADDR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_8; LP v_X_6; LP v_X_4; 
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 1 * 4));
v_X_6 = ((LP) DEREF((v_X_4) + 1 * 4));
v_X_8 = ((LP) DEREF((v_X_6) + 0 * 4));
t0 = ((LP) DEREF((v_X_8) + 0 * 4));
return(t0);
}

LP p_lsp_CAADR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_6; LP v_X_4; LP v_X_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 1 * 4));
v_X_6 = ((LP) DEREF((v_X_4) + 0 * 4));
t0 = ((LP) DEREF((v_X_6) + 0 * 4));
return(t0);
}

LP p_lsp_CAAR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_4; LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 0 * 4));
t0 = ((LP) DEREF((v_X_4) + 0 * 4));
return(t0);
}

LP p_lsp_CADAAR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_8; LP v_X_6; LP v_X_4; 
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 0 * 4));
v_X_6 = ((LP) DEREF((v_X_4) + 0 * 4));
v_X_8 = ((LP) DEREF((v_X_6) + 1 * 4));
t0 = ((LP) DEREF((v_X_8) + 0 * 4));
return(t0);
}

LP p_lsp_CADADR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_8; LP v_X_6; LP v_X_4; 
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 1 * 4));
v_X_6 = ((LP) DEREF((v_X_4) + 0 * 4));
v_X_8 = ((LP) DEREF((v_X_6) + 1 * 4));
t0 = ((LP) DEREF((v_X_8) + 0 * 4));
return(t0);
}

LP p_lsp_CADAR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_6; LP v_X_4; LP v_X_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 0 * 4));
v_X_6 = ((LP) DEREF((v_X_4) + 1 * 4));
t0 = ((LP) DEREF((v_X_6) + 0 * 4));
return(t0);
}

LP p_lsp_CADDAR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_8; LP v_X_6; LP v_X_4; 
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 0 * 4));
v_X_6 = ((LP) DEREF((v_X_4) + 1 * 4));
v_X_8 = ((LP) DEREF((v_X_6) + 1 * 4));
t0 = ((LP) DEREF((v_X_8) + 0 * 4));
return(t0);
}

LP p_lsp_CADDDR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_8; LP v_X_6; LP v_X_4; 
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 1 * 4));
v_X_6 = ((LP) DEREF((v_X_4) + 1 * 4));
v_X_8 = ((LP) DEREF((v_X_6) + 1 * 4));
t0 = ((LP) DEREF((v_X_8) + 0 * 4));
return(t0);
}

LP p_lsp_CADDR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_6; LP v_X_4; LP v_X_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 1 * 4));
v_X_6 = ((LP) DEREF((v_X_4) + 1 * 4));
t0 = ((LP) DEREF((v_X_6) + 0 * 4));
return(t0);
}

LP p_lsp_CADR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_4; LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 1 * 4));
t0 = ((LP) DEREF((v_X_4) + 0 * 4));
return(t0);
}

LP p_lsp_CDAAAR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_8; LP v_X_6; LP v_X_4; 
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 0 * 4));
v_X_6 = ((LP) DEREF((v_X_4) + 0 * 4));
v_X_8 = ((LP) DEREF((v_X_6) + 0 * 4));
t0 = ((LP) DEREF((v_X_8) + 1 * 4));
return(t0);
}

LP p_lsp_CDAADR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_8; LP v_X_6; LP v_X_4; 
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 1 * 4));
v_X_6 = ((LP) DEREF((v_X_4) + 0 * 4));
v_X_8 = ((LP) DEREF((v_X_6) + 0 * 4));
t0 = ((LP) DEREF((v_X_8) + 1 * 4));
return(t0);
}

LP p_lsp_CDAAR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_6; LP v_X_4; LP v_X_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 0 * 4));
v_X_6 = ((LP) DEREF((v_X_4) + 0 * 4));
t0 = ((LP) DEREF((v_X_6) + 1 * 4));
return(t0);
}

LP p_lsp_CDADAR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_8; LP v_X_6; LP v_X_4; 
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 0 * 4));
v_X_6 = ((LP) DEREF((v_X_4) + 1 * 4));
v_X_8 = ((LP) DEREF((v_X_6) + 0 * 4));
t0 = ((LP) DEREF((v_X_8) + 1 * 4));
return(t0);
}

LP p_lsp_CDADDR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_8; LP v_X_6; LP v_X_4; 
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 1 * 4));
v_X_6 = ((LP) DEREF((v_X_4) + 1 * 4));
v_X_8 = ((LP) DEREF((v_X_6) + 0 * 4));
t0 = ((LP) DEREF((v_X_8) + 1 * 4));
return(t0);
}

LP p_lsp_CDADR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_6; LP v_X_4; LP v_X_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 1 * 4));
v_X_6 = ((LP) DEREF((v_X_4) + 0 * 4));
t0 = ((LP) DEREF((v_X_6) + 1 * 4));
return(t0);
}

LP p_lsp_CDAR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_4; LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 0 * 4));
t0 = ((LP) DEREF((v_X_4) + 1 * 4));
return(t0);
}

LP p_lsp_CDDAAR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_8; LP v_X_6; LP v_X_4; 
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 0 * 4));
v_X_6 = ((LP) DEREF((v_X_4) + 0 * 4));
v_X_8 = ((LP) DEREF((v_X_6) + 1 * 4));
t0 = ((LP) DEREF((v_X_8) + 1 * 4));
return(t0);
}

LP p_lsp_CDDADR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_8; LP v_X_6; LP v_X_4; 
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 1 * 4));
v_X_6 = ((LP) DEREF((v_X_4) + 0 * 4));
v_X_8 = ((LP) DEREF((v_X_6) + 1 * 4));
t0 = ((LP) DEREF((v_X_8) + 1 * 4));
return(t0);
}

LP p_lsp_CDDAR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_6; LP v_X_4; LP v_X_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 0 * 4));
v_X_6 = ((LP) DEREF((v_X_4) + 1 * 4));
t0 = ((LP) DEREF((v_X_6) + 1 * 4));
return(t0);
}

LP p_lsp_CDDDAR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_8; LP v_X_6; LP v_X_4; 
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 0 * 4));
v_X_6 = ((LP) DEREF((v_X_4) + 1 * 4));
v_X_8 = ((LP) DEREF((v_X_6) + 1 * 4));
t0 = ((LP) DEREF((v_X_8) + 1 * 4));
return(t0);
}

LP p_lsp_CDDDDR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_8; LP v_X_6; LP v_X_4; 
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 1 * 4));
v_X_6 = ((LP) DEREF((v_X_4) + 1 * 4));
v_X_8 = ((LP) DEREF((v_X_6) + 1 * 4));
t0 = ((LP) DEREF((v_X_8) + 1 * 4));
return(t0);
}

LP p_lsp_CDDDR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_6; LP v_X_4; LP v_X_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 1 * 4));
v_X_6 = ((LP) DEREF((v_X_4) + 1 * 4));
t0 = ((LP) DEREF((v_X_6) + 1 * 4));
return(t0);
}

LP p_lsp_CDDR(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_X_4; LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 1) wna(argc,1);
v_X_2 = v_C_0;
v_X_4 = ((LP) DEREF((v_C_0) + 1 * 4));
t0 = ((LP) DEREF((v_X_4) + 1 * 4));
return(t0);
}

LP p_lsp_FIRST(argc, v_LIST_0)
      ARGC argc;  LP v_LIST_0;
{
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; 
if (argc != 1) wna(argc,1);
v_X_2 = v_LIST_0;
t0 = ((LP) DEREF((v_LIST_0) + 0 * 4));
return(t0);
}

LP p_lsp_SECOND(argc, v_LIST_0)
      ARGC argc;  LP v_LIST_0;
{
LP v_X_6; LP v_X_4; LP v_C_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 1) wna(argc,1);
v_C_2 = v_LIST_0;
v_X_4 = v_LIST_0;
v_X_6 = ((LP) DEREF((v_LIST_0) + 1 * 4));
t0 = ((LP) DEREF((v_X_6) + 0 * 4));
return(t0);
}

LP p_lsp_THIRD(argc, v_LIST_0)
      ARGC argc;  LP v_LIST_0;
{
LP v_X_8; LP v_X_6; LP v_X_4; 
LP v_C_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 1) wna(argc,1);
v_C_2 = v_LIST_0;
v_X_4 = v_LIST_0;
v_X_6 = ((LP) DEREF((v_LIST_0) + 1 * 4));
v_X_8 = ((LP) DEREF((v_X_6) + 1 * 4));
t0 = ((LP) DEREF((v_X_8) + 0 * 4));
return(t0);
}

LP p_lsp_FOURTH(argc, v_LIST_0)
      ARGC argc;  LP v_LIST_0;
{
LP v_X_10; LP v_X_8; LP v_X_6; 
LP v_X_4; LP v_C_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 1) wna(argc,1);
v_C_2 = v_LIST_0;
v_X_4 = v_LIST_0;
v_X_6 = ((LP) DEREF((v_LIST_0) + 1 * 4));
v_X_8 = ((LP) DEREF((v_X_6) + 1 * 4));
v_X_10 = ((LP) DEREF((v_X_8) + 1 * 4));
t0 = ((LP) DEREF((v_X_10) + 0 * 4));
return(t0);
}

LP p_lsp_FIFTH(argc, v_LIST_0)
      ARGC argc;  LP v_LIST_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_NTH) (MV_CALL(argc,2), (LP) 8, v_LIST_0);
return(t0);
}

LP p_lsp_SIXTH(argc, v_LIST_0)
      ARGC argc;  LP v_LIST_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_NTH) (MV_CALL(argc,2), (LP) 10, v_LIST_0);
return(t0);
}

LP p_lsp_SEVENTH(argc, v_LIST_0)
      ARGC argc;  LP v_LIST_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_NTH) (MV_CALL(argc,2), (LP) 12, v_LIST_0);
return(t0);
}

LP p_lsp_EIGHTH(argc, v_LIST_0)
      ARGC argc;  LP v_LIST_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_NTH) (MV_CALL(argc,2), (LP) 14, v_LIST_0);
return(t0);
}

LP p_lsp_NINTH(argc, v_LIST_0)
      ARGC argc;  LP v_LIST_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_NTH) (MV_CALL(argc,2), (LP) 16, v_LIST_0);
return(t0);
}

LP p_lsp_TENTH(argc, v_LIST_0)
      ARGC argc;  LP v_LIST_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_NTH) (MV_CALL(argc,2), (LP) 18, v_LIST_0);
return(t0);
}

LP p_lsp_ACCUMULATE_2DRL(argc, v_OP_0, v_N_1, v_ARGS_2)
      ARGC argc;  LP v_OP_0; LP v_N_1; LP v_ARGS_2;
{
LP v_LOOP_2DITER_2DFLAG_2D853_6; LP v_RESULT_5; LP v_I_4; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; 
if (argc != 3) wna(argc,3);
v_I_4 = (subtract((v_N_1), ((LP) 4)));
t1 = (subtract((v_N_1), ((LP) 4)));
t0 = ((LP) DEREF((v_ARGS_2) + FX_TO_INT(t1) * 4));
t3 = (subtract((v_N_1), ((LP) 2)));
t2 = ((LP) DEREF((v_ARGS_2) + FX_TO_INT(t3) * 4));
v_RESULT_5 = CODE_PTR(COERCE_TO_FUNCTION(v_OP_0))(2, t0, t2);
v_LOOP_2DITER_2DFLAG_2D853_6 = LREF(s_lsp_T);
t_NEXT_2DLOOP_8:;
if (((int) (v_I_4) < (int) ((LP) 0))) {
goto t_END_2DLOOP_9;
}
if (v_LOOP_2DITER_2DFLAG_2D853_6 == NIL) {
t6 = ((LP) DEREF((v_ARGS_2) + FX_TO_INT(v_I_4) * 4));
v_RESULT_5 = CODE_PTR(COERCE_TO_FUNCTION(v_OP_0))(2, t6, v_RESULT_5);
}
v_LOOP_2DITER_2DFLAG_2D853_6 = LREF(s_lsp_NIL);
v_I_4 = (((LP) ((int) (v_I_4) - (int) ((LP) 2))));
goto t_NEXT_2DLOOP_8;
goto t_END_2DLOOP_9;
t_END_2DLOOP_9:;
return(v_RESULT_5);
return(NIL);
return(NIL);
}

LP p_lsp_ACONS(argc, v_KEY_0, v_DATA_1, v_A_2DLIST_2)
      ARGC argc;  LP v_KEY_0; LP v_DATA_1; LP v_A_2DLIST_2;
{
LP v_Y_8; LP v_X_7; LP v_Y_5; 
LP v_X_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 3) wna(argc,3);
v_X_4 = v_KEY_0;
v_Y_5 = v_DATA_1;
v_X_7 = (c_cons((v_KEY_0), (v_DATA_1)));
t0 = (c_cons((v_X_7), (v_A_2DLIST_2)));
return(t0);
}

LP p_lsp_ADJOIN_2F4(argc, v_ITEM_0, v_LIST_1, v_TEST_2, v_KEY_3)
      ARGC argc;  LP v_ITEM_0; LP v_LIST_1; LP v_TEST_2; LP v_KEY_3;
{
LP v_Y_6; LP v_X_5; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; 
if (argc != 4) wna(argc,4);
t1 = ICALL(s_lsp_MEMBER_2F4) (4, v_ITEM_0, v_LIST_1, v_TEST_2, v_KEY_3);
if (t1 != NIL) {
return(v_LIST_1);
} else {
v_X_5 = v_ITEM_0;
v_Y_6 = v_LIST_1;
t0 = (c_cons((v_ITEM_0), (v_LIST_1)));
return(t0);
}
}

LP p_lsp_ADJOIN(va_alist) va_dcl
{
LP v_LIST_1; LP v_ITEM_0; LP v_KEYS3111_5; 
LP v_KEY_4; LP v_TEST_2DNOT_3; LP v_TEST_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 

DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_ITEM_0 = NEXT_VAR_ARG;
v_LIST_1 = NEXT_VAR_ARG;


t0 = NEW_OE(1);
real_argc = REAL_ARGC(argc);
if (real_argc < 2) wna_low(real_argc,2);
DYNAMIC_RESTIFY(v_KEYS3111_5,3,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_TEST_2,LREF(s_key_TEST),v_KEYS3111_5)
v_TEST_2 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_TEST_2DNOT_3,LREF(s_key_TEST_2DNOT),v_KEYS3111_5)
v_TEST_2DNOT_3 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_KEY_4,LREF(s_key_KEY),v_KEYS3111_5)
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_IDENTITY));
v_KEY_4 = t1;
END_KEY_INIT
END_VAR_ARGS;
SET_OE_SLOT(t0,0,v_TEST_2DNOT_3);
if (v_TEST_2 != NIL) {
t3 = v_TEST_2;
} else {
if (GET_OE_SLOT(t0,0) != NIL) {
t4 = MAKE_CLOSURE(p_lsp_ADJOIN_2Danon21532154,t0);
t3 = t4;
} else {
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_EQL));
}
}
t2 = ICALL(s_lsp_ADJOIN_2F4) (MV_CALL(argc,4), v_ITEM_0, v_LIST_1, t3, v_KEY_4);
return(t2);
}

LP p_lsp_ADJOIN_2Danon21532154(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = OE;
t2 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(2, v_X_0, v_Y_1);
t1 = ICALL(s_lsp_NOT) (MV_CALL(argc,1), t2);
return(t1);
}

LP p_lsp_APPEND_2F2(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{
LP v_Y_8; LP v_X_7; LP v_X_5; 
LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_LISTP) (1, v_X_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_X_0, LREF(s_lsp_LIST), (LP) 0);
}
if (v_X_0 != NIL) {
v_X_3 = v_X_0;
v_X_7 = ((LP) DEREF((v_X_0) + 0 * 4));
v_X_5 = v_X_0;
t2 = ((LP) DEREF((v_X_0) + 1 * 4));
v_Y_8 = ICALL(s_lsp_APPEND_2F2) (2, t2, v_Y_1);
t1 = (c_cons((v_X_7), (v_Y_8)));
return(t1);
} else {
return(v_Y_1);
}
}

LP p_lsp_APPEND(va_alist) va_dcl
{
LP v_KEY3112_3; LP v_N_2; LP v_ARGS_0; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; 
RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTVIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_2 = ICALL(s_lsp_LENGTH) (1, v_ARGS_0);
v_KEY3112_3 = v_N_2;
t1 = ICALL(s_lsp_EQL) (2, v_KEY3112_3, (LP) 0);
if (t1 != NIL) {
return(LREF(s_lsp_NIL));
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY3112_3, (LP) 2);
if (t2 != NIL) {
t0 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
return(t0);
} else {
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_APPEND_2F2));
t0 = ICALL(s_lsp_ACCUMULATE_2DRL) (MV_CALL(argc,3), t3, v_N_2, v_ARGS_0);
return(t0);
}
}
}

LP p_lsp_ASSOC_2F4(argc, v_X_0, v_A_2DLIST_1, v_TEST_2, v_KEY_3)
      ARGC argc;  LP v_X_0; LP v_A_2DLIST_1; LP v_TEST_2; LP v_KEY_3;
{
LP v_X_14; LP v_X_12; LP v_X_10; 
LP v_LOOP_2DLIST_2D854_6; LP v_ENTRY_5; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; 
if (argc != 4) wna(argc,4);
v_ENTRY_5 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D854_6 = v_A_2DLIST_1;
t_NEXT_2DLOOP_8:;
if (v_LOOP_2DLIST_2D854_6 == NIL) {
goto t_END_2DLOOP_9;
}
v_X_10 = v_LOOP_2DLIST_2D854_6;
v_ENTRY_5 = ((LP) DEREF((v_X_10) + 0 * 4));
v_X_12 = v_LOOP_2DLIST_2D854_6;
v_LOOP_2DLIST_2D854_6 = ((LP) DEREF((v_X_12) + 1 * 4));
v_X_14 = v_ENTRY_5;
t3 = ((LP) DEREF((v_X_14) + 0 * 4));
t2 = CODE_PTR(COERCE_TO_FUNCTION(v_KEY_3))(1, t3);
t1 = CODE_PTR(COERCE_TO_FUNCTION(v_TEST_2))(2, t2, v_X_0);
if (t1 != NIL) {
return(v_ENTRY_5);
return(NIL);
}
goto t_NEXT_2DLOOP_8;
goto t_END_2DLOOP_9;
t_END_2DLOOP_9:;
return(NIL);
}

LP p_lsp_ASSOC(va_alist) va_dcl
{
LP v_A_2DLIST_1; LP v_X_0; LP v_KEYS3113_5; 
LP v_KEY_4; LP v_TEST_2DNOT_3; LP v_TEST_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 

DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_X_0 = NEXT_VAR_ARG;
v_A_2DLIST_1 = NEXT_VAR_ARG;


t0 = NEW_OE(1);
real_argc = REAL_ARGC(argc);
if (real_argc < 2) wna_low(real_argc,2);
DYNAMIC_RESTIFY(v_KEYS3113_5,3,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_TEST_2,LREF(s_key_TEST),v_KEYS3113_5)
v_TEST_2 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_TEST_2DNOT_3,LREF(s_key_TEST_2DNOT),v_KEYS3113_5)
v_TEST_2DNOT_3 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_KEY_4,LREF(s_key_KEY),v_KEYS3113_5)
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_IDENTITY));
v_KEY_4 = t1;
END_KEY_INIT
END_VAR_ARGS;
SET_OE_SLOT(t0,0,v_TEST_2DNOT_3);
if (v_TEST_2 != NIL) {
t3 = v_TEST_2;
} else {
if (GET_OE_SLOT(t0,0) != NIL) {
t4 = MAKE_CLOSURE(p_lsp_ASSOC_2Danon21552156,t0);
t3 = t4;
} else {
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_EQL));
}
}
t2 = ICALL(s_lsp_ASSOC_2F4) (MV_CALL(argc,4), v_X_0, v_A_2DLIST_1, t3, v_KEY_4);
return(t2);
}

LP p_lsp_ASSOC_2Danon21552156(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = OE;
t2 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(2, v_X_0, v_Y_1);
t1 = ICALL(s_lsp_NOT) (MV_CALL(argc,1), t2);
return(t1);
}

LP p_lsp_ASSQ(argc, v_X_0, v_A_2DLIST_1)
      ARGC argc;  LP v_X_0; LP v_A_2DLIST_1;
{
LP v_X_12; LP v_X_10; LP v_X_8; 
LP v_LOOP_2DLIST_2D855_4; LP v_ENTRY_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; 
if (argc != 2) wna(argc,2);
v_ENTRY_3 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D855_4 = v_A_2DLIST_1;
t_NEXT_2DLOOP_6:;
if (v_LOOP_2DLIST_2D855_4 == NIL) {
goto t_END_2DLOOP_7;
}
v_X_8 = v_LOOP_2DLIST_2D855_4;
v_ENTRY_3 = ((LP) DEREF((v_X_8) + 0 * 4));
v_X_10 = v_LOOP_2DLIST_2D855_4;
v_LOOP_2DLIST_2D855_4 = ((LP) DEREF((v_X_10) + 1 * 4));
v_X_12 = v_ENTRY_3;
t2 = ((LP) DEREF((v_X_12) + 0 * 4));
t1 = ICALL(s_lsp_EQ) (2, t2, v_X_0);
if (t1 != NIL) {
return(v_ENTRY_3);
return(NIL);
}
goto t_NEXT_2DLOOP_6;
goto t_END_2DLOOP_7;
t_END_2DLOOP_7:;
return(NIL);
}

LP p_lsp_ASSQL(argc, v_X_0, v_A_2DLIST_1)
      ARGC argc;  LP v_X_0; LP v_A_2DLIST_1;
{
LP v_X_12; LP v_X_10; LP v_X_8; 
LP v_LOOP_2DLIST_2D856_4; LP v_ENTRY_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; 
if (argc != 2) wna(argc,2);
v_ENTRY_3 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D856_4 = v_A_2DLIST_1;
t_NEXT_2DLOOP_6:;
if (v_LOOP_2DLIST_2D856_4 == NIL) {
goto t_END_2DLOOP_7;
}
v_X_8 = v_LOOP_2DLIST_2D856_4;
v_ENTRY_3 = ((LP) DEREF((v_X_8) + 0 * 4));
v_X_10 = v_LOOP_2DLIST_2D856_4;
v_LOOP_2DLIST_2D856_4 = ((LP) DEREF((v_X_10) + 1 * 4));
v_X_12 = v_ENTRY_3;
t2 = ((LP) DEREF((v_X_12) + 0 * 4));
t1 = ICALL(s_lsp_EQL) (2, t2, v_X_0);
if (t1 != NIL) {
return(v_ENTRY_3);
return(NIL);
}
goto t_NEXT_2DLOOP_6;
goto t_END_2DLOOP_7;
t_END_2DLOOP_7:;
return(NIL);
}

LP p_lsp_BUTLAST_2F2(argc, v_LIST_0, v_N_1)
      ARGC argc;  LP v_LIST_0; LP v_N_1;
{
LP v_X_27; LP v_V_25; LP v_X_24; 
LP v_NEW_2DCDR_22; LP v_C_21; LP v_Y_19; 
LP v_X_18; LP v_X_16; LP v_X_14; 
LP v_LOOPVAR_2D861_10; LP v_LOOPVAR_2D860_9; LP v_LOOPVAR_2D859_8; 
LP v_LOOP_2DLIST_2D858_7; LP v_X_6; LP v_LOOP_2DBIND_2D857_5; 
LP v_I_4; LP v_LEN_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; 
if (argc != 2) wna(argc,2);
v_LEN_3 = ICALL(s_lsp_LENGTH) (1, v_LIST_0);
t1 = (leq_p((v_N_1), (v_LEN_3)));
if (t1 != NIL) {
v_I_4 = (LP) 0;
v_LOOP_2DBIND_2D857_5 = (subtract((v_LEN_3), (v_N_1)));
v_X_6 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D858_7 = v_LIST_0;
v_LOOPVAR_2D859_8 = LREF(s_lsp_NIL);
v_LOOPVAR_2D860_9 = LREF(s_lsp_NIL);
v_LOOPVAR_2D861_10 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_12:;
if (((int) (v_I_4) >= (int) (v_LOOP_2DBIND_2D857_5))) {
goto t_END_2DLOOP_13;
}
if (v_LOOP_2DLIST_2D858_7 == NIL) {
goto t_END_2DLOOP_13;
}
v_X_14 = v_LOOP_2DLIST_2D858_7;
v_X_6 = ((LP) DEREF((v_X_14) + 0 * 4));
v_X_16 = v_LOOP_2DLIST_2D858_7;
v_LOOP_2DLIST_2D858_7 = ((LP) DEREF((v_X_16) + 1 * 4));
v_X_18 = v_X_6;
v_LOOPVAR_2D861_10 = (c_cons((v_X_18), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D860_9 != NIL) {
v_C_21 = v_LOOPVAR_2D860_9;
v_NEW_2DCDR_22 = v_LOOPVAR_2D861_10;
v_V_25 = v_NEW_2DCDR_22;
((LP) (DEREF((v_C_21) + 1 * 4) = (LD) (v_V_25)));
v_X_27 = v_C_21;
v_LOOPVAR_2D860_9 = ((LP) DEREF((v_X_27) + 1 * 4));
} else {
v_LOOPVAR_2D859_8 = v_LOOPVAR_2D861_10;
v_LOOPVAR_2D860_9 = v_LOOPVAR_2D859_8;
}
v_I_4 = (((LP) ((int) (v_I_4) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_12;
goto t_END_2DLOOP_13;
t_END_2DLOOP_13:;
return(v_LOOPVAR_2D859_8);
return(NIL);
return(NIL);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_BUTLAST(va_alist) va_dcl
{
LP v_LIST_0; LP v_N_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_LIST_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_N_1 = (LP) 2;
} else {
v_N_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t0 = ICALL(s_lsp_BUTLAST_2F2) (MV_CALL(argc,2), v_LIST_0, v_N_1);
return(t0);
}

LP p_lsp_COPY_2DALIST(argc, v_ALIST_0)
      ARGC argc;  LP v_ALIST_0;
{
LP v_V_70; LP v_X_69; LP v_NEW_2DCDR_67; 
LP v_C_66; LP v_TMP3117_65; LP v_TMP3116_64; 
LP v_X_62; LP v_V_60; LP v_X_59; 
LP v_NEW_2DCDR_57; LP v_C_56; LP v_Y_54; 
LP v_X_53; LP v_X_51; LP v_Y_49; 
LP v_X_48; LP v_X_46; LP v_X_44; 
LP v_C_42; LP v_X_40; LP v_X_38; 
LP v_C_36; LP v_X_34; LP v_X_32; 
LP v_SPLICE_29; LP v_X_28; LP v_X_26; 
LP v_RESULT_24; LP v_Y_22; LP v_X_21; 
LP v_X_19; LP v_Y_17; LP v_X_16; 
LP v_X_14; LP v_X_12; LP v_C_10; 
LP v_X_8; LP v_X_6; LP v_C_4; 
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; 
if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_ATOM) (1, v_ALIST_0);
if (t1 != NIL) {
if (v_ALIST_0 != NIL) {
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,2), LREF(k2157), v_ALIST_0);
return(t0);
} else {
return(LREF(s_lsp_NIL));
}
} else {
v_X_19 = v_ALIST_0;
t3 = ((LP) DEREF((v_ALIST_0) + 0 * 4));
t2 = ICALL(s_lsp_ATOM) (1, t3);
if (t2 != NIL) {
v_X_2 = v_ALIST_0;
v_X_21 = ((LP) DEREF((v_ALIST_0) + 0 * 4));
} else {
v_C_4 = v_ALIST_0;
v_X_6 = v_ALIST_0;
v_X_8 = ((LP) DEREF((v_ALIST_0) + 0 * 4));
v_X_16 = ((LP) DEREF((v_X_8) + 0 * 4));
v_C_10 = v_ALIST_0;
v_X_12 = v_ALIST_0;
v_X_14 = ((LP) DEREF((v_ALIST_0) + 0 * 4));
v_Y_17 = ((LP) DEREF((v_X_14) + 1 * 4));
v_X_21 = (c_cons((v_X_16), (v_Y_17)));
}
v_RESULT_24 = (c_cons((v_X_21), (LREF(s_lsp_NIL))));
v_X_26 = v_ALIST_0;
v_X_28 = ((LP) DEREF((v_ALIST_0) + 1 * 4));
v_SPLICE_29 = v_RESULT_24;
goto t_TEST3114_31;
t_LOOP3115_30:;
v_X_32 = v_X_28;
v_TMP3116_64 = ((LP) DEREF((v_X_32) + 1 * 4));
v_C_56 = v_SPLICE_29;
v_X_51 = v_X_28;
t5 = ((LP) DEREF((v_X_51) + 0 * 4));
t4 = ICALL(s_lsp_ATOM) (1, t5);
if (t4 != NIL) {
v_X_34 = v_X_28;
v_X_53 = ((LP) DEREF((v_X_34) + 0 * 4));
} else {
v_C_36 = v_X_28;
v_X_38 = v_C_36;
v_X_40 = ((LP) DEREF((v_C_36) + 0 * 4));
v_X_48 = ((LP) DEREF((v_X_40) + 0 * 4));
v_C_42 = v_X_28;
v_X_44 = v_C_42;
v_X_46 = ((LP) DEREF((v_C_42) + 0 * 4));
v_Y_49 = ((LP) DEREF((v_X_46) + 1 * 4));
v_X_53 = (c_cons((v_X_48), (v_Y_49)));
}
v_NEW_2DCDR_57 = (c_cons((v_X_53), (LREF(s_lsp_NIL))));
v_V_60 = v_NEW_2DCDR_57;
((LP) (DEREF((v_C_56) + 1 * 4) = (LD) (v_V_60)));
v_X_62 = v_C_56;
v_TMP3117_65 = ((LP) DEREF((v_X_62) + 1 * 4));
v_X_28 = v_TMP3116_64;
v_SPLICE_29 = v_TMP3117_65;
t_TEST3114_31:;
t6 = ICALL(s_lsp_ATOM) (1, v_X_28);
if (t6 != NIL) {
t7 = ICALL(s_lsp_NULL) (1, v_X_28);
if (t7 == NIL) {
v_C_66 = v_SPLICE_29;
v_NEW_2DCDR_67 = v_X_28;
v_V_70 = v_NEW_2DCDR_67;
((LP) (DEREF((v_C_66) + 1 * 4) = (LD) (v_V_70)));
}
return(v_RESULT_24);
return(NIL);
}
goto t_LOOP3115_30;
return(NIL);
}
}

LP p_lsp_COPY_2DLIST(argc, v_LIST_0)
      ARGC argc;  LP v_LIST_0;
{
LP v_Y_7; LP v_X_6; LP v_X_4; 
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; 
if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_ATOM) (1, v_LIST_0);
if (t1 != NIL) {
return(v_LIST_0);
} else {
v_X_2 = v_LIST_0;
v_X_6 = ((LP) DEREF((v_LIST_0) + 0 * 4));
v_X_4 = v_LIST_0;
t2 = ((LP) DEREF((v_LIST_0) + 1 * 4));
v_Y_7 = ICALL(s_lsp_COPY_2DLIST) (1, t2);
t0 = (c_cons((v_X_6), (v_Y_7)));
return(t0);
}
}

LP p_lsp_COPY_2DTREE(argc, v_TREE_0)
      ARGC argc;  LP v_TREE_0;
{
LP v_Y_7; LP v_X_6; LP v_X_4; 
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; 
if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_ATOM) (1, v_TREE_0);
if (t1 != NIL) {
return(v_TREE_0);
} else {
v_X_2 = v_TREE_0;
t2 = ((LP) DEREF((v_TREE_0) + 0 * 4));
v_X_6 = ICALL(s_lsp_COPY_2DTREE) (1, t2);
v_X_4 = v_TREE_0;
t3 = ((LP) DEREF((v_TREE_0) + 1 * 4));
v_Y_7 = ICALL(s_lsp_COPY_2DTREE) (1, t3);
t0 = (c_cons((v_X_6), (v_Y_7)));
return(t0);
}
}

LP p_lsp_ENDP(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_NULL) (MV_CALL(argc,1), v_X_0);
return(t0);
}

LP p_lsp_INTERSECTION(va_alist) va_dcl
{
LP v_S3120_23; LP v_Y_21; LP v_X_20; 
LP v_VALUE3119_19; LP v_X_17; LP v_X_15; 
LP v_LOOP_2DLIST_2D862_11; LP v_ELT_10; LP v_RES_9; 
LP v_LIST2_1; LP v_LIST1_0; LP v_KEYS3118_7; 
LP v_NOTP_6; LP v_TEST_2DNOT_5; LP v_TESTP_4; 
LP v_TEST_3; LP v_KEY_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_LIST1_0 = NEXT_VAR_ARG;
v_LIST2_1 = NEXT_VAR_ARG;


t0 = NEW_OE(1);
real_argc = REAL_ARGC(argc);
if (real_argc < 2) wna_low(real_argc,2);
DYNAMIC_RESTIFY(v_KEYS3118_7,3,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_KEY_2,LREF(s_key_KEY),v_KEYS3118_7)
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_IDENTITY));
v_KEY_2 = t1;
END_KEY_INIT
v_TESTP_4 = T;
BEGIN_KEY_INIT(v_TEST_3,LREF(s_key_TEST),v_KEYS3118_7)
v_TESTP_4 = NIL;
t2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_EQL));
v_TEST_3 = t2;
END_KEY_INIT
v_NOTP_6 = T;
BEGIN_KEY_INIT(v_TEST_2DNOT_5,LREF(s_key_TEST_2DNOT),v_KEYS3118_7)
v_NOTP_6 = NIL;
v_TEST_2DNOT_5 = LREF(s_lsp_NIL);
END_KEY_INIT
END_VAR_ARGS;
SET_OE_SLOT(t0,0,v_TEST_2DNOT_5);
v_RES_9 = LREF(s_lsp_NIL);
v_ELT_10 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D862_11 = v_LIST1_0;
t_NEXT_2DLOOP_13:;
if (v_LOOP_2DLIST_2D862_11 == NIL) {
goto t_END_2DLOOP_14;
}
v_X_15 = v_LOOP_2DLIST_2D862_11;
v_ELT_10 = ((LP) DEREF((v_X_15) + 0 * 4));
v_X_17 = v_LOOP_2DLIST_2D862_11;
v_LOOP_2DLIST_2D862_11 = ((LP) DEREF((v_X_17) + 1 * 4));
if (v_TESTP_4 != NIL) {
t4 = v_NOTP_6;
} else {
t4 = LREF(s_lsp_NIL);
}
if (t4 != NIL) {
t3 = ICALL(s_lsp_ERROR) (1, LREF(k2160));
} else {
if (v_NOTP_6 != NIL) {
t5 = CODE_PTR(COERCE_TO_FUNCTION(v_KEY_2))(1, v_ELT_10);
t6 = MAKE_CLOSURE(p_lsp_INTERSECTION_2Danon21582159,t0);
t3 = ICALL(s_lsp_MEMBER_2F4) (4, t5, v_LIST2_1, t6, v_KEY_2);
} else {
t7 = CODE_PTR(COERCE_TO_FUNCTION(v_KEY_2))(1, v_ELT_10);
t3 = ICALL(s_lsp_MEMBER_2F4) (4, t7, v_LIST2_1, v_TEST_3, v_KEY_2);
}
}
if (t3 != NIL) {
v_VALUE3119_19 = v_ELT_10;
v_Y_21 = v_RES_9;
v_S3120_23 = (c_cons((v_VALUE3119_19), (v_Y_21)));
v_RES_9 = v_S3120_23;
}
goto t_NEXT_2DLOOP_13;
goto t_END_2DLOOP_14;
t_END_2DLOOP_14:;
goto b_NIL_12;
b_NIL_12:;
return(v_RES_9);
}

LP p_lsp_INTERSECTION_2Danon21582159(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = OE;
t2 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(2, v_X_0, v_Y_1);
t1 = ICALL(s_lsp_NOT) (MV_CALL(argc,1), t2);
return(t1);
}

LP p_lsp_LAST(argc, v_L_0)
      ARGC argc;  LP v_L_0;
{
LP v_X_4; LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 1) wna(argc,1);
START2161:
v_X_4 = v_L_0;
t2 = ((LP) DEREF((v_L_0) + 1 * 4));
t1 = ICALL(s_lsp_CONSP) (1, t2);
if (t1 != NIL) {
v_X_2 = v_L_0;
t3 = ((LP) DEREF((v_L_0) + 1 * 4));
v_L_0 = t3; 
goto START2161;
} else {
return(v_L_0);
}
}

LP p_lsp_LDIFF(argc, v_LIST_0, v_SUBLIST_1)
      ARGC argc;  LP v_LIST_0; LP v_SUBLIST_1;
{
LP v_X_28; LP v_V_26; LP v_X_25; 
LP v_NEW_2DCDR_23; LP v_C_22; LP v_Y_20; 
LP v_X_19; LP v_X_17; LP v_G3123_16; 
LP v_X_14; LP v_X_12; LP v_SPLICE_9; 
LP v_RESULT_8; LP v_Y_6; LP v_X_5; 
LP v_LIST_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; 
if (argc != 2) wna(argc,2);
v_LIST_4 = v_LIST_0;
v_X_5 = LREF(s_lsp_NIL);
v_Y_6 = LREF(s_lsp_NIL);
v_RESULT_8 = (c_cons((LREF(s_lsp_NIL)), (LREF(s_lsp_NIL))));
v_SPLICE_9 = v_RESULT_8;
goto t_TEST3121_11;
t_LOOP3122_10:;
v_X_12 = v_LIST_4;
v_LIST_4 = ((LP) DEREF((v_X_12) + 1 * 4));
t_TEST3121_11:;
v_G3123_16 = ICALL(s_lsp_NULL) (1, v_LIST_4);
if (v_G3123_16 != NIL) {
t1 = v_G3123_16;
} else {
t1 = ICALL(s_lsp_EQ) (2, v_LIST_4, v_SUBLIST_1);
}
if (t1 != NIL) {
v_X_14 = v_RESULT_8;
t2 = ((LP) DEREF((v_RESULT_8) + 1 * 4));
return(t2);
return(NIL);
}
v_C_22 = v_SPLICE_9;
v_X_17 = v_LIST_4;
v_X_19 = ((LP) DEREF((v_X_17) + 0 * 4));
v_NEW_2DCDR_23 = (c_cons((v_X_19), (LREF(s_lsp_NIL))));
v_V_26 = v_NEW_2DCDR_23;
((LP) (DEREF((v_C_22) + 1 * 4) = (LD) (v_V_26)));
v_X_28 = v_C_22;
v_SPLICE_9 = ((LP) DEREF((v_X_28) + 1 * 4));
goto t_LOOP3122_10;
return(NIL);
}

LP p_lsp_LENGTH_2FLIST(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{
LP v_X_10; LP v_X_8; LP v_LEN_4; 
LP v_LOOP_2DLIST_2D863_3; LP v_E_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 

if (argc != 1) wna(argc,1);
v_E_2 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D863_3 = v_X_0;
v_LEN_4 = (LP) 0;
t_NEXT_2DLOOP_6:;
if (v_LOOP_2DLIST_2D863_3 == NIL) {
goto t_END_2DLOOP_7;
}
v_X_8 = v_LOOP_2DLIST_2D863_3;
v_E_2 = ((LP) DEREF((v_X_8) + 0 * 4));
v_X_10 = v_LOOP_2DLIST_2D863_3;
v_LOOP_2DLIST_2D863_3 = ((LP) DEREF((v_X_10) + 1 * 4));
if (v_X_0 != NIL) {
v_LEN_4 = (((LP) ((int) (v_LEN_4) + (int) ((LP) 2))));
}
goto t_NEXT_2DLOOP_6;
goto t_END_2DLOOP_7;
t_END_2DLOOP_7:;
return(v_LEN_4);
return(NIL);
return(NIL);
}

LP p_lsp_LIST_2DLENGTH(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{
LP v_X_23; LP v_X_21; LP v_X_19; 
LP v_TMP3128_18; LP v_TMP3127_17; LP v_TMP3126_16; 
LP v_X_14; LP v_X_12; LP v_X_10; 
LP v_C_8; LP v_SLOW_5; LP v_FAST_4; 
LP v_N_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; 
if (argc != 1) wna(argc,1);
v_N_3 = (LP) 0;
v_FAST_4 = v_X_0;
v_SLOW_5 = v_X_0;
goto t_TEST3124_7;
t_LOOP3125_6:;
v_TMP3126_16 = (add((v_N_3), ((LP) 4)));
v_C_8 = v_FAST_4;
v_X_10 = v_C_8;
v_X_12 = ((LP) DEREF((v_C_8) + 1 * 4));
v_TMP3127_17 = ((LP) DEREF((v_X_12) + 1 * 4));
v_X_14 = v_SLOW_5;
v_TMP3128_18 = ((LP) DEREF((v_X_14) + 1 * 4));
v_N_3 = v_TMP3126_16;
v_FAST_4 = v_TMP3127_17;
v_SLOW_5 = v_TMP3128_18;
t_TEST3124_7:;
v_X_19 = v_FAST_4;
t1 = ICALL(s_lsp_NULL) (1, v_X_19);
if (t1 != NIL) {
return(v_N_3);
return(NIL);
}
v_X_21 = v_FAST_4;
v_X_23 = ((LP) DEREF((v_X_21) + 1 * 4));
t2 = ICALL(s_lsp_NULL) (1, v_X_23);
if (t2 != NIL) {
t3 = (add((v_N_3), ((LP) 2)));
return(t3);
return(NIL);
}
t5 = ICALL(s_lsp_EQ) (2, v_FAST_4, v_SLOW_5);
if (t5 != NIL) {
t4 = (greaterp((v_N_3), ((LP) 0)));
} else {
t4 = LREF(s_lsp_NIL);
}
if (t4 != NIL) {
return(LREF(s_lsp_NIL));
return(NIL);
}
goto t_LOOP3125_6;
return(NIL);
}

LP p_lsp_LIST_2A_2D1(argc, v_REST_0)
      ARGC argc;  LP v_REST_0;
{
LP v_X_11; LP v_Y_9; LP v_X_8; 
LP v_X_6; LP v_X_4; LP v_X_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; 
if (argc != 1) wna(argc,1);
v_X_11 = v_REST_0;
t1 = ((LP) DEREF((v_REST_0) + 1 * 4));
if (t1 != NIL) {
v_X_4 = v_REST_0;
v_X_8 = ((LP) DEREF((v_REST_0) + 0 * 4));
v_X_6 = v_REST_0;
t2 = ((LP) DEREF((v_REST_0) + 1 * 4));
v_Y_9 = ICALL(s_lsp_LIST_2A_2D1) (1, t2);
t0 = (c_cons((v_X_8), (v_Y_9)));
return(t0);
} else {
v_X_2 = v_REST_0;
t0 = ((LP) DEREF((v_REST_0) + 0 * 4));
return(t0);
}
}

LP p_lsp_LIST_2A(va_alist) va_dcl
{
LP v_ARGS_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
DYNAMIC_RESTIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
t0 = ICALL(s_lsp_LIST_2A_2D1) (MV_CALL(argc,1), v_ARGS_0);
return(t0);
}

LP p_lsp_LIST(va_alist) va_dcl
{
LP v_L_0; 
LP t0; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTIFY(v_L_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
return(v_L_0);
}

LP p_lsp_MAKE_2DLIST_2D1(argc, v_SIZE_0, v_INITIAL_2DELEMENT_1)
      ARGC argc;  LP v_SIZE_0; LP v_INITIAL_2DELEMENT_1;
{
LP v_X_20; LP v_V_18; LP v_X_17; 
LP v_NEW_2DCDR_15; LP v_C_14; LP v_Y_12; 
LP v_X_11; LP v_LOOPVAR_2D867_7; LP v_LOOPVAR_2D866_6; 
LP v_LOOPVAR_2D865_5; LP v_LOOP_2DBIND_2D864_4; LP v_I_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; 
if (argc != 2) wna(argc,2);
v_I_3 = (LP) 0;
v_LOOPVAR_2D865_5 = LREF(s_lsp_NIL);
v_LOOPVAR_2D866_6 = LREF(s_lsp_NIL);
v_LOOPVAR_2D867_7 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_9:;
if (((int) (v_I_3) >= (int) (v_SIZE_0))) {
goto t_END_2DLOOP_10;
}
v_X_11 = v_INITIAL_2DELEMENT_1;
v_Y_12 = LREF(s_lsp_NIL);
v_LOOPVAR_2D867_7 = (c_cons((v_INITIAL_2DELEMENT_1), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D866_6 != NIL) {
v_C_14 = v_LOOPVAR_2D866_6;
v_NEW_2DCDR_15 = v_LOOPVAR_2D867_7;
v_V_18 = v_NEW_2DCDR_15;
((LP) (DEREF((v_C_14) + 1 * 4) = (LD) (v_V_18)));
v_X_20 = v_C_14;
v_LOOPVAR_2D866_6 = ((LP) DEREF((v_X_20) + 1 * 4));
} else {
v_LOOPVAR_2D865_5 = v_LOOPVAR_2D867_7;
v_LOOPVAR_2D866_6 = v_LOOPVAR_2D865_5;
}
v_I_3 = (((LP) ((int) (v_I_3) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_9;
goto t_END_2DLOOP_10;
t_END_2DLOOP_10:;
return(v_LOOPVAR_2D865_5);
return(NIL);
return(NIL);
}

LP p_lsp_MAKE_2DLIST(va_alist) va_dcl
{
LP v_SIZE_0; LP v_KEYS3129_2; LP v_INITIAL_2DELEMENT_1; 

LP t0; LP t1; LP t2; LP t3; LP t4; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_SIZE_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
DYNAMIC_RESTIFY(v_KEYS3129_2,2,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_INITIAL_2DELEMENT_1,LREF(s_key_INITIAL_2DELEMENT),v_KEYS3129_2)
v_INITIAL_2DELEMENT_1 = NIL;
END_KEY_INIT
END_VAR_ARGS;
t0 = ICALL(s_lsp_MAKE_2DLIST_2D1) (MV_CALL(argc,2), v_SIZE_0, v_INITIAL_2DELEMENT_1);
return(t0);
}

LP p_lsp_MAPC(argc, v_FUNCTION_0, v_LIST_1)
      ARGC argc;  LP v_FUNCTION_0; LP v_LIST_1;
{
LP v_X_14; LP v_X_12; LP v_LOOP_2DLIST_2D868_8; 
LP v_L3130_7; LP v_X_5; LP v_X_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; 
if (argc != 2) wna(argc,2);
if (v_LIST_1 != NIL) {
v_X_3 = v_LIST_1;
t1 = ((LP) DEREF((v_LIST_1) + 0 * 4));
CODE_PTR(COERCE_TO_FUNCTION(v_FUNCTION_0))(1, t1);
v_L3130_7 = LREF(s_lsp_NIL);
v_X_5 = v_LIST_1;
v_LOOP_2DLIST_2D868_8 = ((LP) DEREF((v_LIST_1) + 1 * 4));
t_NEXT_2DLOOP_10:;
if (v_LOOP_2DLIST_2D868_8 == NIL) {
goto t_END_2DLOOP_11;
}
v_X_12 = v_LOOP_2DLIST_2D868_8;
v_L3130_7 = ((LP) DEREF((v_X_12) + 0 * 4));
v_X_14 = v_LOOP_2DLIST_2D868_8;
v_LOOP_2DLIST_2D868_8 = ((LP) DEREF((v_X_14) + 1 * 4));
CODE_PTR(COERCE_TO_FUNCTION(v_FUNCTION_0))(1, v_L3130_7);
goto t_NEXT_2DLOOP_10;
goto t_END_2DLOOP_11;
t_END_2DLOOP_11:;
return(NIL);
} else {
return(v_LIST_1);
}
}

LP p_lsp_MAPCAN_2F2(argc, v_FUNC_0, v_ARG_2DLISTS_1)
      ARGC argc;  LP v_FUNC_0; LP v_ARG_2DLISTS_1;
{
LP v_X_42; LP v_V_40; LP v_X_39; 
LP v_NEW_2DCDR_37; LP v_C_36; LP v_Y_34; 
LP v_X_33; LP v_X_31; LP v_X_29; 
LP v_V_27; LP v_X_26; LP v_NEW_2DCDR_24; 
LP v_C_23; LP v_Y_21; LP v_X_20; 
LP v_X_18; LP v_X_16; LP v_X_14; 
LP v_LOOPVAR_2D873_10; LP v_LOOPVAR_2D872_9; LP v_REST_8; 
LP v_LOOPVAR_2D871_7; LP v_LOOPVAR_2D870_6; LP v_ARGS_5; 
LP v_LOOP_2DLIST_2D869_4; LP v_A_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 

if (argc != 2) wna(argc,2);
v_A_3 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D869_4 = v_ARG_2DLISTS_1;
v_ARGS_5 = LREF(s_lsp_NIL);
v_LOOPVAR_2D870_6 = LREF(s_lsp_NIL);
v_LOOPVAR_2D871_7 = LREF(s_lsp_NIL);
v_REST_8 = LREF(s_lsp_NIL);
v_LOOPVAR_2D872_9 = LREF(s_lsp_NIL);
v_LOOPVAR_2D873_10 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_12:;
if (v_LOOP_2DLIST_2D869_4 == NIL) {
goto t_END_2DLOOP_13;
}
v_X_14 = v_LOOP_2DLIST_2D869_4;
v_A_3 = ((LP) DEREF((v_X_14) + 0 * 4));
v_X_16 = v_LOOP_2DLIST_2D869_4;
v_LOOP_2DLIST_2D869_4 = ((LP) DEREF((v_X_16) + 1 * 4));
if (v_A_3 == NIL) {
return(LREF(s_lsp_NIL));
return(NIL);
}
v_X_18 = v_A_3;
v_X_20 = ((LP) DEREF((v_X_18) + 0 * 4));
v_LOOPVAR_2D871_7 = (c_cons((v_X_20), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D870_6 != NIL) {
v_C_23 = v_LOOPVAR_2D870_6;
v_NEW_2DCDR_24 = v_LOOPVAR_2D871_7;
v_V_27 = v_NEW_2DCDR_24;
((LP) (DEREF((v_C_23) + 1 * 4) = (LD) (v_V_27)));
v_X_29 = v_C_23;
v_LOOPVAR_2D870_6 = ((LP) DEREF((v_X_29) + 1 * 4));
} else {
v_ARGS_5 = v_LOOPVAR_2D871_7;
v_LOOPVAR_2D870_6 = v_ARGS_5;
}
v_X_31 = v_A_3;
v_X_33 = ((LP) DEREF((v_X_31) + 1 * 4));
v_LOOPVAR_2D873_10 = (c_cons((v_X_33), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D872_9 != NIL) {
v_C_36 = v_LOOPVAR_2D872_9;
v_NEW_2DCDR_37 = v_LOOPVAR_2D873_10;
v_V_40 = v_NEW_2DCDR_37;
((LP) (DEREF((v_C_36) + 1 * 4) = (LD) (v_V_40)));
v_X_42 = v_C_36;
v_LOOPVAR_2D872_9 = ((LP) DEREF((v_X_42) + 1 * 4));
} else {
v_REST_8 = v_LOOPVAR_2D873_10;
v_LOOPVAR_2D872_9 = v_REST_8;
}
goto t_NEXT_2DLOOP_12;
goto t_END_2DLOOP_13;
t_END_2DLOOP_13:;
t2 = p_lsp_APPLY(2, COERCE_TO_FUNCTION(v_FUNC_0), v_ARGS_5);
t3 = ICALL(s_lsp_MAPCAN_2F2) (2, v_FUNC_0, v_REST_8);
t1 = ICALL(s_lsp_NCONC_2F2) (MV_CALL(argc,2), t2, t3);
return(t1);
return(NIL);
return(NIL);
}

LP p_lsp_MAPCAN(va_alist) va_dcl
{
LP v_FUNC_0; LP v_ARG_2DLISTS_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_FUNC_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
DYNAMIC_RESTIFY(v_ARG_2DLISTS_1,2,NEXT_VAR_ARG);
END_VAR_ARGS;
t0 = ICALL(s_lsp_MAPCAN_2F2) (MV_CALL(argc,2), v_FUNC_0, v_ARG_2DLISTS_1);
return(t0);
}

LP p_lsp_MAPCAR_2F2(argc, v_FUNC_0, v_ARG_2DLISTS_1)
      ARGC argc;  LP v_FUNC_0; LP v_ARG_2DLISTS_1;
{
LP v_Y_45; LP v_X_44; LP v_X_42; 
LP v_V_40; LP v_X_39; LP v_NEW_2DCDR_37; 
LP v_C_36; LP v_Y_34; LP v_X_33; 
LP v_X_31; LP v_X_29; LP v_V_27; 
LP v_X_26; LP v_NEW_2DCDR_24; LP v_C_23; 
LP v_Y_21; LP v_X_20; LP v_X_18; 
LP v_X_16; LP v_X_14; LP v_LOOPVAR_2D878_10; 
LP v_LOOPVAR_2D877_9; LP v_REST_8; LP v_LOOPVAR_2D876_7; 
LP v_LOOPVAR_2D875_6; LP v_ARGS_5; LP v_LOOP_2DLIST_2D874_4; 
LP v_A_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; 
if (argc != 2) wna(argc,2);
v_A_3 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D874_4 = v_ARG_2DLISTS_1;
v_ARGS_5 = LREF(s_lsp_NIL);
v_LOOPVAR_2D875_6 = LREF(s_lsp_NIL);
v_LOOPVAR_2D876_7 = LREF(s_lsp_NIL);
v_REST_8 = LREF(s_lsp_NIL);
v_LOOPVAR_2D877_9 = LREF(s_lsp_NIL);
v_LOOPVAR_2D878_10 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_12:;
if (v_LOOP_2DLIST_2D874_4 == NIL) {
goto t_END_2DLOOP_13;
}
v_X_14 = v_LOOP_2DLIST_2D874_4;
v_A_3 = ((LP) DEREF((v_X_14) + 0 * 4));
v_X_16 = v_LOOP_2DLIST_2D874_4;
v_LOOP_2DLIST_2D874_4 = ((LP) DEREF((v_X_16) + 1 * 4));
if (v_A_3 == NIL) {
return(LREF(s_lsp_NIL));
return(NIL);
}
v_X_18 = v_A_3;
v_X_20 = ((LP) DEREF((v_X_18) + 0 * 4));
v_LOOPVAR_2D876_7 = (c_cons((v_X_20), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D875_6 != NIL) {
v_C_23 = v_LOOPVAR_2D875_6;
v_NEW_2DCDR_24 = v_LOOPVAR_2D876_7;
v_V_27 = v_NEW_2DCDR_24;
((LP) (DEREF((v_C_23) + 1 * 4) = (LD) (v_V_27)));
v_X_29 = v_C_23;
v_LOOPVAR_2D875_6 = ((LP) DEREF((v_X_29) + 1 * 4));
} else {
v_ARGS_5 = v_LOOPVAR_2D876_7;
v_LOOPVAR_2D875_6 = v_ARGS_5;
}
v_X_31 = v_A_3;
v_X_33 = ((LP) DEREF((v_X_31) + 1 * 4));
v_LOOPVAR_2D878_10 = (c_cons((v_X_33), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D877_9 != NIL) {
v_C_36 = v_LOOPVAR_2D877_9;
v_NEW_2DCDR_37 = v_LOOPVAR_2D878_10;
v_V_40 = v_NEW_2DCDR_37;
((LP) (DEREF((v_C_36) + 1 * 4) = (LD) (v_V_40)));
v_X_42 = v_C_36;
v_LOOPVAR_2D877_9 = ((LP) DEREF((v_X_42) + 1 * 4));
} else {
v_REST_8 = v_LOOPVAR_2D878_10;
v_LOOPVAR_2D877_9 = v_REST_8;
}
goto t_NEXT_2DLOOP_12;
goto t_END_2DLOOP_13;
t_END_2DLOOP_13:;
v_X_44 = p_lsp_APPLY(2, COERCE_TO_FUNCTION(v_FUNC_0), v_ARGS_5);
v_Y_45 = ICALL(s_lsp_MAPCAR_2F2) (2, v_FUNC_0, v_REST_8);
t1 = (c_cons((v_X_44), (v_Y_45)));
return(t1);
return(NIL);
return(NIL);
}

LP p_lsp_MAPCAR(va_alist) va_dcl
{
LP v_FUNC_0; LP v_ARG_2DLISTS_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_FUNC_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
DYNAMIC_RESTIFY(v_ARG_2DLISTS_1,2,NEXT_VAR_ARG);
END_VAR_ARGS;
t0 = ICALL(s_lsp_MAPCAR_2F2) (MV_CALL(argc,2), v_FUNC_0, v_ARG_2DLISTS_1);
return(t0);
}

LP p_lsp_MEMBER_2F4(argc, v_X_0, v_LIST_1, v_TEST_2, v_KEY_3)
      ARGC argc;  LP v_X_0; LP v_LIST_1; LP v_TEST_2; LP v_KEY_3;
{
LP v_X_7; LP v_X_5; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 

if (argc != 4) wna(argc,4);
START2162:
t1 = ICALL(s_lsp_ATOM) (1, v_LIST_1);
if (t1 != NIL) {
return(LREF(s_lsp_NIL));
} else {
v_X_7 = v_LIST_1;
t4 = ((LP) DEREF((v_LIST_1) + 0 * 4));
t3 = CODE_PTR(COERCE_TO_FUNCTION(v_KEY_3))(1, t4);
t2 = CODE_PTR(COERCE_TO_FUNCTION(v_TEST_2))(2, t3, v_X_0);
if (t2 != NIL) {
return(v_LIST_1);
} else {
v_X_5 = v_LIST_1;
t5 = ((LP) DEREF((v_LIST_1) + 1 * 4));
v_LIST_1 = t5; 
goto START2162;
}
}
}

LP p_lsp_MEMBER_2DIF(va_alist) va_dcl
{
LP v_X_11; LP v_X_9; LP v_REST_5; 
LP v_LIST_1; LP v_TEST_0; LP v_KEYS3131_3; 
LP v_KEY_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_TEST_0 = NEXT_VAR_ARG;
v_LIST_1 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 2) wna_low(real_argc,2);
DYNAMIC_RESTIFY(v_KEYS3131_3,3,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_KEY_2,LREF(s_key_KEY),v_KEYS3131_3)
t0 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_IDENTITY));
v_KEY_2 = t0;
END_KEY_INIT
END_VAR_ARGS;
v_REST_5 = v_LIST_1;
t_NEXT_2DLOOP_7:;
if (v_REST_5 == NIL) {
goto t_END_2DLOOP_8;
}
v_X_9 = v_REST_5;
t4 = ((LP) DEREF((v_X_9) + 0 * 4));
t3 = CODE_PTR(COERCE_TO_FUNCTION(v_KEY_2))(1, t4);
t2 = CODE_PTR(COERCE_TO_FUNCTION(v_TEST_0))(1, t3);
if (t2 != NIL) {
return(v_REST_5);
return(NIL);
}
v_X_11 = v_REST_5;
v_REST_5 = ((LP) DEREF((v_X_11) + 1 * 4));
goto t_NEXT_2DLOOP_7;
goto t_END_2DLOOP_8;
t_END_2DLOOP_8:;
return(LREF(s_lsp_NIL));
return(NIL);
return(NIL);
}

LP p_lsp_MEMBER(va_alist) va_dcl
{
LP v_LIST_1; LP v_X_0; LP v_KEYS3132_5; 
LP v_KEY_4; LP v_TEST_2DNOT_3; LP v_TEST_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 

DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_X_0 = NEXT_VAR_ARG;
v_LIST_1 = NEXT_VAR_ARG;


t0 = NEW_OE(1);
real_argc = REAL_ARGC(argc);
if (real_argc < 2) wna_low(real_argc,2);
DYNAMIC_RESTIFY(v_KEYS3132_5,3,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_TEST_2,LREF(s_key_TEST),v_KEYS3132_5)
v_TEST_2 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_TEST_2DNOT_3,LREF(s_key_TEST_2DNOT),v_KEYS3132_5)
v_TEST_2DNOT_3 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_KEY_4,LREF(s_key_KEY),v_KEYS3132_5)
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_IDENTITY));
v_KEY_4 = t1;
END_KEY_INIT
END_VAR_ARGS;
SET_OE_SLOT(t0,0,v_TEST_2DNOT_3);
if (v_TEST_2 != NIL) {
t3 = v_TEST_2;
} else {
if (GET_OE_SLOT(t0,0) != NIL) {
t4 = MAKE_CLOSURE(p_lsp_MEMBER_2Danon21632164,t0);
t3 = t4;
} else {
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_EQL));
}
}
t2 = ICALL(s_lsp_MEMBER_2F4) (MV_CALL(argc,4), v_X_0, v_LIST_1, t3, v_KEY_4);
return(t2);
}

LP p_lsp_MEMBER_2Danon21632164(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = OE;
t2 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(2, v_X_0, v_Y_1);
t1 = ICALL(s_lsp_NOT) (MV_CALL(argc,1), t2);
return(t1);
}

LP p_lsp_MEMQ(argc, v_E_0, v_L_1)
      ARGC argc;  LP v_E_0; LP v_L_1;
{
LP v_X_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; 
if (argc != 2) wna(argc,2);
START2165:
t1 = ICALL(s_lsp_ATOM) (1, v_L_1);
if (t1 != NIL) {
return(LREF(s_lsp_NIL));
} else {
v_X_5 = v_L_1;
t3 = ((LP) DEREF((v_L_1) + 0 * 4));
t2 = ICALL(s_lsp_EQ) (2, v_E_0, t3);
if (t2 != NIL) {
return(v_L_1);
} else {
v_X_3 = v_L_1;
t4 = ((LP) DEREF((v_L_1) + 1 * 4));
v_L_1 = t4; 
goto START2165;
}
}
}

LP p_lsp_MEMQL(argc, v_E_0, v_L_1)
      ARGC argc;  LP v_E_0; LP v_L_1;
{
LP v_X_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; 
if (argc != 2) wna(argc,2);
t1 = ICALL(s_lsp_ATOM) (1, v_L_1);
if (t1 != NIL) {
return(LREF(s_lsp_NIL));
} else {
v_X_5 = v_L_1;
t3 = ((LP) DEREF((v_L_1) + 0 * 4));
t2 = ICALL(s_lsp_EQL) (2, v_E_0, t3);
if (t2 != NIL) {
return(v_L_1);
} else {
v_X_3 = v_L_1;
t4 = ((LP) DEREF((v_L_1) + 1 * 4));
t0 = ICALL(s_lsp_MEMQ) (MV_CALL(argc,2), v_E_0, t4);
return(t0);
}
}
}

LP p_lsp_NBUTLAST(va_alist) va_dcl
{
LP v_V_21; LP v_X_20; LP v_NEW_2DCDR_18; 
LP v_C_17; LP v_TMP3137_16; LP v_TMP3136_15; 
LP v_TMP3135_14; LP v_X_12; LP v_COUNT_9; 
LP v_2ND_8; LP v_1ST_7; LP v_X_5; 
LP v_LENGTH_3; LP v_LIST_0; LP v_N_1; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_LIST_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_N_1 = (LP) 2;
} else {
v_N_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
if (((int) (v_N_1) < (int) ((LP) 0))) {
v_N_1 = (LP) 0;
}
t1 = ICALL(s_lsp_LENGTH) (1, v_LIST_0);
v_LENGTH_3 = ICALL(s_lsp_1_2D) (1, t1);
if (((int) (v_LENGTH_3) < (int) (v_N_1))) {
return(LREF(s_lsp_NIL));
} else {
v_X_5 = v_LIST_0;
v_1ST_7 = ((LP) DEREF((v_LIST_0) + 1 * 4));
v_2ND_8 = v_LIST_0;
v_COUNT_9 = v_LENGTH_3;
goto t_TEST3133_11;
t_LOOP3134_10:;
v_X_12 = v_1ST_7;
v_TMP3135_14 = ((LP) DEREF((v_X_12) + 1 * 4));
v_TMP3136_15 = v_1ST_7;
v_TMP3137_16 = ICALL(s_lsp_1_2D) (1, v_COUNT_9);
v_1ST_7 = v_TMP3135_14;
v_2ND_8 = v_TMP3136_15;
v_COUNT_9 = v_TMP3137_16;
t_TEST3133_11:;
t4 = (num_equal_p((v_COUNT_9), (v_N_1)));
if (t4 != NIL) {
v_C_17 = v_2ND_8;
v_V_21 = LREF(s_lsp_NIL);
((LP) (DEREF((v_C_17) + 1 * 4) = (LD) (v_V_21)));
return(v_LIST_0);
return(NIL);
}
goto t_LOOP3134_10;
return(NIL);
}
}

LP p_lsp_NCONC_2F2(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{
LP v_X_14; LP v_X_12; LP v_V_10; 
LP v_X_9; LP v_T3139_8; LP v_S3138_7; 
LP v_C_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; 
if (argc != 2) wna(argc,2);
if (v_X_0 != NIL) {
v_C_3 = v_X_0;
t_NEXT_2DLOOP_5:;
if (v_C_3 == NIL) {
goto t_END_2DLOOP_6;
}
v_X_12 = v_C_3;
t2 = ((LP) DEREF((v_X_12) + 1 * 4));
t1 = ICALL(s_lsp_ATOM) (1, t2);
if (t1 != NIL) {
v_S3138_7 = v_Y_1;
v_T3139_8 = v_C_3;
v_V_10 = v_Y_1;
((LP) (DEREF((v_T3139_8) + 1 * 4) = (LD) (v_V_10)));
return(v_X_0);
return(NIL);
}
v_X_14 = v_C_3;
v_C_3 = ((LP) DEREF((v_X_14) + 1 * 4));
goto t_NEXT_2DLOOP_5;
goto t_END_2DLOOP_6;
t_END_2DLOOP_6:;
return(NIL);
} else {
return(v_Y_1);
}
}

LP p_lsp_NCONC(va_alist) va_dcl
{
LP v_KEY3140_3; LP v_N_2; LP v_ARGS_0; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; 
RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTVIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_2 = ICALL(s_lsp_LENGTH) (1, v_ARGS_0);
v_KEY3140_3 = v_N_2;
t1 = ICALL(s_lsp_EQL) (2, v_KEY3140_3, (LP) 0);
if (t1 != NIL) {
return(LREF(s_lsp_NIL));
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY3140_3, (LP) 2);
if (t2 != NIL) {
t0 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
return(t0);
} else {
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_NCONC_2F2));
t0 = ICALL(s_lsp_ACCUMULATE_2DRL) (MV_CALL(argc,3), t3, v_N_2, v_ARGS_0);
return(t0);
}
}
}

LP p_lsp_NINTERSECTION(va_alist) va_dcl
{
LP v_X_29; LP v_X_27; LP v_X_25; 
LP v_S3147_24; LP v_V_22; LP v_X_21; 
LP v_T3146_20; LP v_S3145_19; LP v_S3144_18; 
LP v_X_16; LP v_TEMP_15; LP v_X_13; 
LP v_RES_9; LP v_LIST2_1; LP v_LIST1_0; 
LP v_KEYS3141_7; LP v_NOTP_6; LP v_TEST_2DNOT_5; 
LP v_TESTP_4; LP v_TEST_3; LP v_KEY_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_LIST1_0 = NEXT_VAR_ARG;
v_LIST2_1 = NEXT_VAR_ARG;


t0 = NEW_OE(1);
real_argc = REAL_ARGC(argc);
if (real_argc < 2) wna_low(real_argc,2);
DYNAMIC_RESTIFY(v_KEYS3141_7,3,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_KEY_2,LREF(s_key_KEY),v_KEYS3141_7)
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_IDENTITY));
v_KEY_2 = t1;
END_KEY_INIT
v_TESTP_4 = T;
BEGIN_KEY_INIT(v_TEST_3,LREF(s_key_TEST),v_KEYS3141_7)
v_TESTP_4 = NIL;
t2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_EQL));
v_TEST_3 = t2;
END_KEY_INIT
v_NOTP_6 = T;
BEGIN_KEY_INIT(v_TEST_2DNOT_5,LREF(s_key_TEST_2DNOT),v_KEYS3141_7)
v_NOTP_6 = NIL;
v_TEST_2DNOT_5 = LREF(s_lsp_NIL);
END_KEY_INIT
END_VAR_ARGS;
SET_OE_SLOT(t0,0,v_TEST_2DNOT_5);
if (v_TESTP_4 != NIL) {
t3 = v_NOTP_6;
} else {
t3 = LREF(s_lsp_NIL);
}
if (t3 != NIL) {
ICALL(s_lsp_ERROR) (1, LREF(k2160));
}
v_RES_9 = LREF(s_lsp_NIL);
goto t_TEST3142_12;
t_LOOP3143_11:;
t_TEST3142_12:;
v_X_13 = v_LIST1_0;
t4 = ICALL(s_lsp_NULL) (1, v_X_13);
if (t4 != NIL) {
goto b_NIL_10;
}
if (v_TESTP_4 != NIL) {
t6 = v_NOTP_6;
} else {
t6 = LREF(s_lsp_NIL);
}
if (t6 != NIL) {
t5 = ICALL(s_lsp_ERROR) (1, LREF(k2160));
} else {
if (v_NOTP_6 != NIL) {
v_X_27 = v_LIST1_0;
t8 = ((LP) DEREF((v_X_27) + 0 * 4));
t7 = CODE_PTR(COERCE_TO_FUNCTION(v_KEY_2))(1, t8);
t9 = MAKE_CLOSURE(p_lsp_NINTERSECTION_2Danon21662167,t0);
t5 = ICALL(s_lsp_MEMBER_2F4) (4, t7, v_LIST2_1, t9, v_KEY_2);
} else {
v_X_29 = v_LIST1_0;
t11 = ((LP) DEREF((v_X_29) + 0 * 4));
t10 = CODE_PTR(COERCE_TO_FUNCTION(v_KEY_2))(1, t11);
t5 = ICALL(s_lsp_MEMBER_2F4) (4, t10, v_LIST2_1, v_TEST_3, v_KEY_2);
}
}
if (t5 != NIL) {
v_TEMP_15 = v_LIST1_0;
v_X_16 = v_LIST1_0;
v_S3144_18 = ((LP) DEREF((v_X_16) + 1 * 4));
v_LIST1_0 = v_S3144_18;
v_S3145_19 = v_RES_9;
v_T3146_20 = v_TEMP_15;
v_V_22 = v_S3145_19;
((LP) (DEREF((v_TEMP_15) + 1 * 4) = (LD) (v_V_22)));
v_S3147_24 = v_TEMP_15;
v_RES_9 = v_TEMP_15;
} else {
v_X_25 = v_LIST1_0;
v_LIST1_0 = ((LP) DEREF((v_X_25) + 1 * 4));
}
goto t_LOOP3143_11;
b_NIL_10:;
return(v_RES_9);
}

LP p_lsp_NINTERSECTION_2Danon21662167(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = OE;
t2 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(2, v_X_0, v_Y_1);
t1 = ICALL(s_lsp_NOT) (MV_CALL(argc,1), t2);
return(t1);
}

LP p_lsp_NRECONC(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 2) wna(argc,2);
t1 = ICALL(s_lsp_NREVERSE) (1, v_X_0);
t0 = ICALL(s_lsp_NCONC_2F2) (MV_CALL(argc,2), t1, v_Y_1);
return(t0);
}

LP p_lsp_NREVERSE_2FLIST(argc, v_L_0)
      ARGC argc;  LP v_L_0;
{
LP f_DOIT_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = NEW_OE(1);
t1 = MAKE_CLOSURE(p_lsp_NREVERSE_2FLIST_2DDOIT2168,t0);
f_DOIT_2 = t1;
SET_OE_SLOT(t0,0,f_DOIT_2);
if (v_L_0 != NIL) {
t2 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(MV_CALL(argc,2), LREF(s_lsp_NIL), v_L_0);
return(t2);
} else {
return(v_L_0);
}
}

LP p_lsp_NREVERSE_2FLIST_2DDOIT2168(argc, v_HEAD_0, v_TAIL_1)
      ARGC argc;  LP v_HEAD_0; LP v_TAIL_1;
{
LP v_V_9; LP v_X_8; LP v_T3149_7; 
LP v_S3148_6; LP v_REST_5; LP v_X_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 2) wna(argc,2);
t0 = OE;
v_X_3 = v_TAIL_1;
v_REST_5 = ((LP) DEREF((v_TAIL_1) + 1 * 4));
v_S3148_6 = v_HEAD_0;
v_T3149_7 = v_TAIL_1;
v_V_9 = v_HEAD_0;
((LP) (DEREF((v_TAIL_1) + 1 * 4) = (LD) (v_V_9)));
if (v_REST_5 != NIL) {
t1 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(MV_CALL(argc,2), v_TAIL_1, v_REST_5);
return(t1);
} else {
return(v_TAIL_1);
}
}

LP p_lsp_NSET_2DDIFFERENCE(va_alist) va_dcl
{
LP v_X_29; LP v_X_27; LP v_X_25; 
LP v_S3156_24; LP v_V_22; LP v_X_21; 
LP v_T3155_20; LP v_S3154_19; LP v_S3153_18; 
LP v_X_16; LP v_TEMP_15; LP v_X_13; 
LP v_RES_9; LP v_LIST2_1; LP v_LIST1_0; 
LP v_KEYS3150_7; LP v_NOTP_6; LP v_TEST_2DNOT_5; 
LP v_TESTP_4; LP v_TEST_3; LP v_KEY_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_LIST1_0 = NEXT_VAR_ARG;
v_LIST2_1 = NEXT_VAR_ARG;


t0 = NEW_OE(1);
real_argc = REAL_ARGC(argc);
if (real_argc < 2) wna_low(real_argc,2);
DYNAMIC_RESTIFY(v_KEYS3150_7,3,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_KEY_2,LREF(s_key_KEY),v_KEYS3150_7)
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_IDENTITY));
v_KEY_2 = t1;
END_KEY_INIT
v_TESTP_4 = T;
BEGIN_KEY_INIT(v_TEST_3,LREF(s_key_TEST),v_KEYS3150_7)
v_TESTP_4 = NIL;
t2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_EQL));
v_TEST_3 = t2;
END_KEY_INIT
v_NOTP_6 = T;
BEGIN_KEY_INIT(v_TEST_2DNOT_5,LREF(s_key_TEST_2DNOT),v_KEYS3150_7)
v_NOTP_6 = NIL;
v_TEST_2DNOT_5 = LREF(s_lsp_NIL);
END_KEY_INIT
END_VAR_ARGS;
SET_OE_SLOT(t0,0,v_TEST_2DNOT_5);
if (v_TESTP_4 != NIL) {
t3 = v_NOTP_6;
} else {
t3 = LREF(s_lsp_NIL);
}
if (t3 != NIL) {
ICALL(s_lsp_ERROR) (1, LREF(k2160));
}
v_RES_9 = LREF(s_lsp_NIL);
goto t_TEST3151_12;
t_LOOP3152_11:;
t_TEST3151_12:;
v_X_13 = v_LIST1_0;
t4 = ICALL(s_lsp_NULL) (1, v_X_13);
if (t4 != NIL) {
goto b_NIL_10;
}
if (v_TESTP_4 != NIL) {
t6 = v_NOTP_6;
} else {
t6 = LREF(s_lsp_NIL);
}
if (t6 != NIL) {
t5 = ICALL(s_lsp_ERROR) (1, LREF(k2160));
} else {
if (v_NOTP_6 != NIL) {
v_X_27 = v_LIST1_0;
t8 = ((LP) DEREF((v_X_27) + 0 * 4));
t7 = CODE_PTR(COERCE_TO_FUNCTION(v_KEY_2))(1, t8);
t9 = MAKE_CLOSURE(p_lsp_NSET_2DDIFFERENCE_2Danon21692170,t0);
t5 = ICALL(s_lsp_MEMBER_2F4) (4, t7, v_LIST2_1, t9, v_KEY_2);
} else {
v_X_29 = v_LIST1_0;
t11 = ((LP) DEREF((v_X_29) + 0 * 4));
t10 = CODE_PTR(COERCE_TO_FUNCTION(v_KEY_2))(1, t11);
t5 = ICALL(s_lsp_MEMBER_2F4) (4, t10, v_LIST2_1, v_TEST_3, v_KEY_2);
}
}
if (t5 != NIL) {
v_X_25 = v_LIST1_0;
v_LIST1_0 = ((LP) DEREF((v_X_25) + 1 * 4));
} else {
v_TEMP_15 = v_LIST1_0;
v_X_16 = v_LIST1_0;
v_S3153_18 = ((LP) DEREF((v_X_16) + 1 * 4));
v_LIST1_0 = v_S3153_18;
v_S3154_19 = v_RES_9;
v_T3155_20 = v_TEMP_15;
v_V_22 = v_S3154_19;
((LP) (DEREF((v_TEMP_15) + 1 * 4) = (LD) (v_V_22)));
v_S3156_24 = v_TEMP_15;
v_RES_9 = v_TEMP_15;
}
goto t_LOOP3152_11;
b_NIL_10:;
return(v_RES_9);
}

LP p_lsp_NSET_2DDIFFERENCE_2Danon21692170(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = OE;
t2 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(2, v_X_0, v_Y_1);
t1 = ICALL(s_lsp_NOT) (MV_CALL(argc,1), t2);
return(t1);
}

LP p_lsp_NSET_2DEXCLUSIVE_2DOR(va_alist) va_dcl
{
LP v_X_60; LP v_X_58; LP v_X_56; 
LP v_X_54; LP v_V_52; LP v_X_51; 
LP v_NEW_2DCDR_49; LP v_C_48; LP v_X_46; 
LP v_X_44; LP v_V_42; LP v_X_41; 
LP v_NEW_2DCDR_39; LP v_C_38; LP v_X_36; 
LP v_X_34; LP v_X_32; LP v_TMP3163_31; 
LP v_X_29; LP v_SPLICEY_26; LP v_Y_25; 
LP v_X_22; LP v_V_20; LP v_X_19; 
LP v_NEW_2DCDR_17; LP v_C_16; LP v_TMP3160_15; 
LP v_X_13; LP v_SPLICEX_10; LP v_X_9; 
LP v_LIST2_1; LP v_LIST1_0; LP v_KEYS3157_6; 
LP v_KEY_5; LP v_NOTP_4; LP v_TEST_2DNOT_3; 
LP v_TEST_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_LIST1_0 = NEXT_VAR_ARG;
v_LIST2_1 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 2) wna_low(real_argc,2);
DYNAMIC_RESTIFY(v_KEYS3157_6,3,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_TEST_2,LREF(s_key_TEST),v_KEYS3157_6)
t0 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_EQL));
v_TEST_2 = t0;
END_KEY_INIT
v_NOTP_4 = T;
BEGIN_KEY_INIT(v_TEST_2DNOT_3,LREF(s_key_TEST_2DNOT),v_KEYS3157_6)
v_NOTP_4 = NIL;
v_TEST_2DNOT_3 = LREF(s_lsp_NIL);
END_KEY_INIT
BEGIN_KEY_INIT(v_KEY_5,LREF(s_key_KEY),v_KEYS3157_6)
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_IDENTITY));
v_KEY_5 = t1;
END_KEY_INIT
END_VAR_ARGS;
v_X_9 = v_LIST1_0;
v_SPLICEX_10 = LREF(s_lsp_NIL);
goto t_TEST3158_12;
t_LOOP3159_11:;
v_X_13 = v_X_9;
v_TMP3160_15 = ((LP) DEREF((v_X_13) + 1 * 4));
v_X_9 = v_TMP3160_15;
t_TEST3158_12:;
v_X_22 = v_X_9;
t3 = ICALL(s_lsp_NULL) (1, v_X_22);
if (t3 != NIL) {
if (v_SPLICEX_10 != NIL) {
v_C_16 = v_SPLICEX_10;
v_NEW_2DCDR_17 = v_LIST2_1;
v_V_20 = v_NEW_2DCDR_17;
((LP) (DEREF((v_C_16) + 1 * 4) = (LD) (v_V_20)));
} else {
v_LIST1_0 = v_LIST2_1;
}
return(v_LIST1_0);
return(NIL);
}
v_Y_25 = v_LIST2_1;
v_SPLICEY_26 = LREF(s_lsp_NIL);
goto t_TEST3161_28;
t_LOOP3162_27:;
v_X_29 = v_Y_25;
v_TMP3163_31 = ((LP) DEREF((v_X_29) + 1 * 4));
v_Y_25 = v_TMP3163_31;
t_TEST3161_28:;
v_X_32 = v_Y_25;
t4 = ICALL(s_lsp_NULL) (1, v_X_32);
if (t4 != NIL) {
v_SPLICEX_10 = v_X_9;
goto b_NIL_24;
}
if (v_NOTP_4 != NIL) {
v_X_54 = v_X_9;
t8 = ((LP) DEREF((v_X_54) + 0 * 4));
t7 = CODE_PTR(COERCE_TO_FUNCTION(v_KEY_5))(1, t8);
v_X_56 = v_Y_25;
t10 = ((LP) DEREF((v_X_56) + 0 * 4));
t9 = CODE_PTR(COERCE_TO_FUNCTION(v_KEY_5))(1, t10);
t6 = CODE_PTR(COERCE_TO_FUNCTION(v_TEST_2DNOT_3))(2, t7, t9);
t5 = ICALL(s_lsp_NOT) (1, t6);
} else {
v_X_58 = v_X_9;
t12 = ((LP) DEREF((v_X_58) + 0 * 4));
t11 = CODE_PTR(COERCE_TO_FUNCTION(v_KEY_5))(1, t12);
v_X_60 = v_Y_25;
t14 = ((LP) DEREF((v_X_60) + 0 * 4));
t13 = CODE_PTR(COERCE_TO_FUNCTION(v_KEY_5))(1, t14);
t5 = CODE_PTR(COERCE_TO_FUNCTION(v_TEST_2))(2, t11, t13);
}
if (t5 != NIL) {
if (v_SPLICEX_10 != NIL) {
v_C_38 = v_SPLICEX_10;
v_X_36 = v_X_9;
v_NEW_2DCDR_39 = ((LP) DEREF((v_X_36) + 1 * 4));
v_V_42 = v_NEW_2DCDR_39;
((LP) (DEREF((v_C_38) + 1 * 4) = (LD) (v_V_42)));
} else {
v_X_34 = v_X_9;
v_LIST1_0 = ((LP) DEREF((v_X_34) + 1 * 4));
}
if (v_SPLICEY_26 != NIL) {
v_C_48 = v_SPLICEY_26;
v_X_46 = v_Y_25;
v_NEW_2DCDR_49 = ((LP) DEREF((v_X_46) + 1 * 4));
v_V_52 = v_NEW_2DCDR_49;
((LP) (DEREF((v_C_48) + 1 * 4) = (LD) (v_V_52)));
} else {
v_X_44 = v_Y_25;
v_LIST2_1 = ((LP) DEREF((v_X_44) + 1 * 4));
}
goto b_NIL_24;
} else {
v_SPLICEY_26 = v_Y_25;
}
goto t_LOOP3162_27;
b_NIL_24:;
goto t_LOOP3159_11;
return(NIL);
}

LP p_lsp_NSUBST(va_alist) va_dcl
{
LP f_S_10; LP v_TREE_2; LP v_OLD_1; 
LP v_NEW_0; LP v_KEYS3164_8; LP v_NOTP_7; 
LP v_TEST_2DNOT_6; LP v_TESTP_5; LP v_TEST_4; 
LP v_KEY_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_NEW_0 = NEXT_VAR_ARG;
v_OLD_1 = NEXT_VAR_ARG;
v_TREE_2 = NEXT_VAR_ARG;


t0 = NEW_OE(8);
real_argc = REAL_ARGC(argc);
if (real_argc < 3) wna_low(real_argc,3);
DYNAMIC_RESTIFY(v_KEYS3164_8,4,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_KEY_3,LREF(s_key_KEY),v_KEYS3164_8)
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_IDENTITY));
v_KEY_3 = t1;
END_KEY_INIT
v_TESTP_5 = T;
BEGIN_KEY_INIT(v_TEST_4,LREF(s_key_TEST),v_KEYS3164_8)
v_TESTP_5 = NIL;
t2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_EQL));
v_TEST_4 = t2;
END_KEY_INIT
v_NOTP_7 = T;
BEGIN_KEY_INIT(v_TEST_2DNOT_6,LREF(s_key_TEST_2DNOT),v_KEYS3164_8)
v_NOTP_7 = NIL;
v_TEST_2DNOT_6 = LREF(s_lsp_NIL);
END_KEY_INIT
END_VAR_ARGS;
SET_OE_SLOT(t0,7,v_NEW_0);
SET_OE_SLOT(t0,6,v_OLD_1);
SET_OE_SLOT(t0,5,v_KEY_3);
SET_OE_SLOT(t0,4,v_TEST_4);
SET_OE_SLOT(t0,1,v_TESTP_5);
SET_OE_SLOT(t0,3,v_TEST_2DNOT_6);
SET_OE_SLOT(t0,2,v_NOTP_7);
t3 = MAKE_CLOSURE(p_lsp_NSUBST_2DS2171,t0);
f_S_10 = t3;
SET_OE_SLOT(t0,0,f_S_10);
t4 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(MV_CALL(argc,1), v_TREE_2);
return(t4);
}

LP p_lsp_NSUBST_2DS2171(argc, v_SUBTREE_0)
      ARGC argc;  LP v_SUBTREE_0;
{
LP v_V_24; LP v_X_23; LP v_T3172_22; 
LP v_S3171_21; LP v_X_19; LP v_V_17; 
LP v_X_16; LP v_T3170_15; LP v_S3169_14; 
LP v_V_12; LP v_X_11; LP v_T3168_10; 
LP v_S3167_9; LP v_X_7; LP v_SUBTREE_4; 
LP v_LAST_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; 
if (argc != 1) wna(argc,1);
t0 = OE;
if (GET_OE_SLOT(t0,1) != NIL) {
t3 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,5)))(1, v_SUBTREE_0);
t2 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,4)))(2, GET_OE_SLOT(t0,6), t3);
} else {
if (GET_OE_SLOT(t0,2) != NIL) {
t5 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,5)))(1, v_SUBTREE_0);
t4 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,3)))(2, GET_OE_SLOT(t0,6), t5);
t2 = ICALL(s_lsp_NOT) (1, t4);
} else {
t6 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,5)))(1, v_SUBTREE_0);
t2 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,4)))(2, GET_OE_SLOT(t0,6), t6);
}
}
if (t2 != NIL) {
return(GET_OE_SLOT(t0,7));
} else {
t7 = ICALL(s_lsp_ATOM) (1, v_SUBTREE_0);
if (t7 != NIL) {
return(v_SUBTREE_0);
} else {
v_LAST_3 = LREF(s_lsp_NIL);
v_SUBTREE_4 = v_SUBTREE_0;
goto t_TEST3165_6;
t_LOOP3166_5:;
v_LAST_3 = v_SUBTREE_4;
v_X_7 = v_SUBTREE_4;
v_SUBTREE_4 = ((LP) DEREF((v_X_7) + 1 * 4));
t_TEST3165_6:;
t8 = ICALL(s_lsp_ATOM) (1, v_SUBTREE_4);
if (t8 != NIL) {
if (GET_OE_SLOT(t0,1) != NIL) {
t11 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,5)))(1, v_SUBTREE_4);
t10 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,4)))(2, GET_OE_SLOT(t0,6), t11);
} else {
if (GET_OE_SLOT(t0,2) != NIL) {
t13 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,5)))(1, v_SUBTREE_4);
t12 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,3)))(2, GET_OE_SLOT(t0,6), t13);
t10 = ICALL(s_lsp_NOT) (1, t12);
} else {
t14 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,5)))(1, v_SUBTREE_4);
t10 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,4)))(2, GET_OE_SLOT(t0,6), t14);
}
}
if (t10 != NIL) {
v_S3167_9 = GET_OE_SLOT(t0,7);
v_T3168_10 = v_LAST_3;
v_V_12 = GET_OE_SLOT(t0,7);
((LP) (DEREF((v_T3168_10) + 1 * 4) = (LD) (v_V_12)));
t9 = v_V_12;
} else {
t9 = LREF(s_lsp_NIL);
}
goto b_NIL_2;
}
if (GET_OE_SLOT(t0,1) != NIL) {
t16 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,5)))(1, v_SUBTREE_4);
t15 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,4)))(2, GET_OE_SLOT(t0,6), t16);
} else {
if (GET_OE_SLOT(t0,2) != NIL) {
t18 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,5)))(1, v_SUBTREE_4);
t17 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,3)))(2, GET_OE_SLOT(t0,6), t18);
t15 = ICALL(s_lsp_NOT) (1, t17);
} else {
t19 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,5)))(1, v_SUBTREE_4);
t15 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,4)))(2, GET_OE_SLOT(t0,6), t19);
}
}
if (t15 != NIL) {
v_S3169_14 = GET_OE_SLOT(t0,7);
v_T3170_15 = v_LAST_3;
v_V_17 = GET_OE_SLOT(t0,7);
((LP) (DEREF((v_T3170_15) + 1 * 4) = (LD) (v_V_17)));
goto b_NIL_2;
} else {
v_X_19 = v_SUBTREE_4;
t20 = ((LP) DEREF((v_X_19) + 0 * 4));
v_S3171_21 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(1, t20);
v_T3172_22 = v_SUBTREE_4;
v_V_24 = v_S3171_21;
((LP) (DEREF((v_T3172_22) + 0 * 4) = (LD) (v_V_24)));
}
goto t_LOOP3166_5;
b_NIL_2:;
return(v_SUBTREE_0);
}
}
}

LP p_lsp_NTH(argc, v_I_0, v_L_1)
      ARGC argc;  LP v_I_0; LP v_L_1;
{
LP v_X_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; 
if (argc != 2) wna(argc,2);
START2172:
t1 = (num_equal_p((v_I_0), ((LP) 0)));
if (t1 != NIL) {
v_X_3 = v_L_1;
t0 = ((LP) DEREF((v_L_1) + 0 * 4));
return(t0);
} else {
t2 = (subtract((v_I_0), ((LP) 2)));
v_X_5 = v_L_1;
t3 = ((LP) DEREF((v_L_1) + 1 * 4));
v_I_0 = t2; v_L_1 = t3; 
goto START2172;
}
}

LP p_lsp_NTHCDR(argc, v_I_0, v_L_1)
      ARGC argc;  LP v_I_0; LP v_L_1;
{
LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; 
if (argc != 2) wna(argc,2);
START2173:
t1 = (num_equal_p((v_I_0), ((LP) 0)));
if (t1 != NIL) {
return(v_L_1);
} else {
t2 = (subtract((v_I_0), ((LP) 2)));
v_X_3 = v_L_1;
t3 = ((LP) DEREF((v_L_1) + 1 * 4));
v_I_0 = t2; v_L_1 = t3; 
goto START2173;
}
}

LP p_lsp_NUNION(va_alist) va_dcl
{
LP v_X_30; LP v_X_28; LP v_S3180_27; 
LP v_X_25; LP v_S3179_24; LP v_V_22; 
LP v_X_21; LP v_T3178_20; LP v_S3177_19; 
LP v_S3176_18; LP v_X_16; LP v_TEMP_15; 
LP v_X_13; LP v_RES_9; LP v_LIST2_1; 
LP v_LIST1_0; LP v_KEYS3173_7; LP v_NOTP_6; 
LP v_TEST_2DNOT_5; LP v_TESTP_4; LP v_TEST_3; 
LP v_KEY_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_LIST1_0 = NEXT_VAR_ARG;
v_LIST2_1 = NEXT_VAR_ARG;


t0 = NEW_OE(1);
real_argc = REAL_ARGC(argc);
if (real_argc < 2) wna_low(real_argc,2);
DYNAMIC_RESTIFY(v_KEYS3173_7,3,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_KEY_2,LREF(s_key_KEY),v_KEYS3173_7)
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_IDENTITY));
v_KEY_2 = t1;
END_KEY_INIT
v_TESTP_4 = T;
BEGIN_KEY_INIT(v_TEST_3,LREF(s_key_TEST),v_KEYS3173_7)
v_TESTP_4 = NIL;
t2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_EQL));
v_TEST_3 = t2;
END_KEY_INIT
v_NOTP_6 = T;
BEGIN_KEY_INIT(v_TEST_2DNOT_5,LREF(s_key_TEST_2DNOT),v_KEYS3173_7)
v_NOTP_6 = NIL;
v_TEST_2DNOT_5 = LREF(s_lsp_NIL);
END_KEY_INIT
END_VAR_ARGS;
SET_OE_SLOT(t0,0,v_TEST_2DNOT_5);
if (v_TESTP_4 != NIL) {
t3 = v_NOTP_6;
} else {
t3 = LREF(s_lsp_NIL);
}
if (t3 != NIL) {
ICALL(s_lsp_ERROR) (1, LREF(k2160));
}
v_RES_9 = v_LIST2_1;
goto t_TEST3174_12;
t_LOOP3175_11:;
t_TEST3174_12:;
v_X_13 = v_LIST1_0;
t4 = ICALL(s_lsp_NULL) (1, v_X_13);
if (t4 != NIL) {
goto b_NIL_10;
}
if (v_TESTP_4 != NIL) {
t6 = v_NOTP_6;
} else {
t6 = LREF(s_lsp_NIL);
}
if (t6 != NIL) {
t5 = ICALL(s_lsp_ERROR) (1, LREF(k2160));
} else {
if (v_NOTP_6 != NIL) {
v_X_28 = v_LIST1_0;
t8 = ((LP) DEREF((v_X_28) + 0 * 4));
t7 = CODE_PTR(COERCE_TO_FUNCTION(v_KEY_2))(1, t8);
t9 = MAKE_CLOSURE(p_lsp_NUNION_2Danon21742175,t0);
t5 = ICALL(s_lsp_MEMBER_2F4) (4, t7, v_LIST2_1, t9, v_KEY_2);
} else {
v_X_30 = v_LIST1_0;
t11 = ((LP) DEREF((v_X_30) + 0 * 4));
t10 = CODE_PTR(COERCE_TO_FUNCTION(v_KEY_2))(1, t11);
t5 = ICALL(s_lsp_MEMBER_2F4) (4, t10, v_LIST2_1, v_TEST_3, v_KEY_2);
}
}
if (t5 != NIL) {
v_X_25 = v_LIST1_0;
v_S3180_27 = ((LP) DEREF((v_X_25) + 1 * 4));
v_LIST1_0 = v_S3180_27;
} else {
v_TEMP_15 = v_LIST1_0;
v_X_16 = v_LIST1_0;
v_S3176_18 = ((LP) DEREF((v_X_16) + 1 * 4));
v_LIST1_0 = v_S3176_18;
v_S3177_19 = v_RES_9;
v_T3178_20 = v_TEMP_15;
v_V_22 = v_S3177_19;
((LP) (DEREF((v_TEMP_15) + 1 * 4) = (LD) (v_V_22)));
v_S3179_24 = v_TEMP_15;
v_RES_9 = v_TEMP_15;
}
goto t_LOOP3175_11;
b_NIL_10:;
return(v_RES_9);
}

LP p_lsp_NUNION_2Danon21742175(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = OE;
t2 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(2, v_X_0, v_Y_1);
t1 = ICALL(s_lsp_NOT) (MV_CALL(argc,1), t2);
return(t1);
}

LP p_lsp_PAIRLIS_2F3(argc, v_KEYS_0, v_VALUES_1, v_A_2DLIST_2)
      ARGC argc;  LP v_KEYS_0; LP v_VALUES_1; LP v_A_2DLIST_2;
{
LP v_G3181_18; LP v_Y_16; LP v_X_15; 
LP v_Y_13; LP v_X_12; LP v_X_10; 
LP v_X_8; LP v_X_6; LP v_X_4; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; 
if (argc != 3) wna(argc,3);
START2176:
v_G3181_18 = ICALL(s_lsp_NULL) (1, v_KEYS_0);
if (v_G3181_18 != NIL) {
t1 = v_G3181_18;
} else {
t1 = ICALL(s_lsp_NULL) (1, v_VALUES_1);
}
if (t1 != NIL) {
return(v_A_2DLIST_2);
} else {
v_X_4 = v_KEYS_0;
t2 = ((LP) DEREF((v_KEYS_0) + 1 * 4));
v_X_6 = v_VALUES_1;
t3 = ((LP) DEREF((v_VALUES_1) + 1 * 4));
v_X_8 = v_KEYS_0;
v_X_12 = ((LP) DEREF((v_KEYS_0) + 0 * 4));
v_X_10 = v_VALUES_1;
v_Y_13 = ((LP) DEREF((v_VALUES_1) + 0 * 4));
v_X_15 = (c_cons((v_X_12), (v_Y_13)));
t4 = (c_cons((v_X_15), (v_A_2DLIST_2)));
v_KEYS_0 = t2; v_VALUES_1 = t3; v_A_2DLIST_2 = t4; 
goto START2176;
}
}

LP p_lsp_PAIRLIS(va_alist) va_dcl
{
LP v_VALUES_1; LP v_KEYS_0; LP v_A_2DLIST_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_KEYS_0 = NEXT_VAR_ARG;
v_VALUES_1 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 2) wna_low(real_argc,2);
if (real_argc > 3) wna_high(real_argc,3);
if (real_argc < 3) {
v_A_2DLIST_2 = NIL;
} else {
v_A_2DLIST_2 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t0 = ICALL(s_lsp_PAIRLIS_2F3) (MV_CALL(argc,3), v_KEYS_0, v_VALUES_1, v_A_2DLIST_2);
return(t0);
}

LP p_lsp_RASSOC_2F4(argc, v_X_0, v_A_2DLIST_1, v_TEST_2, v_KEY_3)
      ARGC argc;  LP v_X_0; LP v_A_2DLIST_1; LP v_TEST_2; LP v_KEY_3;
{
LP v_X_14; LP v_X_12; LP v_X_10; 
LP v_LOOP_2DLIST_2D879_6; LP v_ENTRY_5; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; 
if (argc != 4) wna(argc,4);
v_ENTRY_5 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D879_6 = v_A_2DLIST_1;
t_NEXT_2DLOOP_8:;
if (v_LOOP_2DLIST_2D879_6 == NIL) {
goto t_END_2DLOOP_9;
}
v_X_10 = v_LOOP_2DLIST_2D879_6;
v_ENTRY_5 = ((LP) DEREF((v_X_10) + 0 * 4));
v_X_12 = v_LOOP_2DLIST_2D879_6;
v_LOOP_2DLIST_2D879_6 = ((LP) DEREF((v_X_12) + 1 * 4));
v_X_14 = v_ENTRY_5;
t3 = ((LP) DEREF((v_X_14) + 1 * 4));
t2 = CODE_PTR(COERCE_TO_FUNCTION(v_KEY_3))(1, t3);
t1 = CODE_PTR(COERCE_TO_FUNCTION(v_TEST_2))(2, t2, v_X_0);
if (t1 != NIL) {
return(v_ENTRY_5);
return(NIL);
}
goto t_NEXT_2DLOOP_8;
goto t_END_2DLOOP_9;
t_END_2DLOOP_9:;
return(NIL);
}

LP p_lsp_RASSOC(va_alist) va_dcl
{
LP v_A_2DLIST_1; LP v_X_0; LP v_KEYS3182_5; 
LP v_KEY_4; LP v_TEST_2DNOT_3; LP v_TEST_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 

DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_X_0 = NEXT_VAR_ARG;
v_A_2DLIST_1 = NEXT_VAR_ARG;


t0 = NEW_OE(1);
real_argc = REAL_ARGC(argc);
if (real_argc < 2) wna_low(real_argc,2);
DYNAMIC_RESTIFY(v_KEYS3182_5,3,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_TEST_2,LREF(s_key_TEST),v_KEYS3182_5)
v_TEST_2 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_TEST_2DNOT_3,LREF(s_key_TEST_2DNOT),v_KEYS3182_5)
v_TEST_2DNOT_3 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_KEY_4,LREF(s_key_KEY),v_KEYS3182_5)
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_IDENTITY));
v_KEY_4 = t1;
END_KEY_INIT
END_VAR_ARGS;
SET_OE_SLOT(t0,0,v_TEST_2DNOT_3);
if (v_TEST_2 != NIL) {
t3 = v_TEST_2;
} else {
if (GET_OE_SLOT(t0,0) != NIL) {
t4 = MAKE_CLOSURE(p_lsp_RASSOC_2Danon21772178,t0);
t3 = t4;
} else {
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_EQL));
}
}
t2 = ICALL(s_lsp_RASSOC_2F4) (MV_CALL(argc,4), v_X_0, v_A_2DLIST_1, t3, v_KEY_4);
return(t2);
}

LP p_lsp_RASSOC_2Danon21772178(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = OE;
t2 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(2, v_X_0, v_Y_1);
t1 = ICALL(s_lsp_NOT) (MV_CALL(argc,1), t2);
return(t1);
}

LP p_lsp_REST(argc, v_LIST_0)
      ARGC argc;  LP v_LIST_0;
{
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; 
if (argc != 1) wna(argc,1);
v_X_2 = v_LIST_0;
t0 = ((LP) DEREF((v_LIST_0) + 1 * 4));
return(t0);
}

LP p_lsp_REVAPPEND(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{
LP v_X_17; LP v_TMP3186_16; LP v_TMP3185_15; 
LP v_Y_13; LP v_X_12; LP v_X_10; 
LP v_X_8; LP v_RESULT_5; LP v_TOP_4; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 

if (argc != 2) wna(argc,2);
v_TOP_4 = v_X_0;
v_RESULT_5 = v_Y_1;
goto t_TEST3183_7;
t_LOOP3184_6:;
v_X_8 = v_TOP_4;
v_TMP3185_15 = ((LP) DEREF((v_X_8) + 1 * 4));
v_X_10 = v_TOP_4;
v_X_12 = ((LP) DEREF((v_X_10) + 0 * 4));
v_Y_13 = v_RESULT_5;
v_TMP3186_16 = (c_cons((v_X_12), (v_Y_13)));
v_TOP_4 = v_TMP3185_15;
v_RESULT_5 = v_TMP3186_16;
t_TEST3183_7:;
v_X_17 = v_TOP_4;
t1 = ICALL(s_lsp_NULL) (1, v_X_17);
if (t1 != NIL) {
return(v_RESULT_5);
return(NIL);
}
goto t_LOOP3184_6;
return(NIL);
}

LP p_lsp_REVERSE_2FLIST(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{
LP f_DOIT_2; 
LP t0; LP t1; LP t2; LP t3; 
if (argc != 1) wna(argc,1);
t0 = NEW_OE(1);
t1 = MAKE_CLOSURE(p_lsp_REVERSE_2FLIST_2DDOIT2179,t0);
f_DOIT_2 = t1;
SET_OE_SLOT(t0,0,f_DOIT_2);
t2 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(MV_CALL(argc,2), LREF(s_lsp_NIL), v_S_0);
return(t2);
}

LP p_lsp_REVERSE_2FLIST_2DDOIT2179(argc, v_NEW_0, v_REST_1)
      ARGC argc;  LP v_NEW_0; LP v_REST_1;
{
LP v_X_8; LP v_Y_6; LP v_X_5; 
LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; 
if (argc != 2) wna(argc,2);
t0 = OE;
if (v_REST_1 != NIL) {
v_X_3 = v_REST_1;
v_X_5 = ((LP) DEREF((v_REST_1) + 0 * 4));
t2 = (c_cons((v_X_5), (v_NEW_0)));
v_X_8 = v_REST_1;
t3 = ((LP) DEREF((v_REST_1) + 1 * 4));
t1 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(MV_CALL(argc,2), t2, t3);
return(t1);
} else {
return(v_NEW_0);
}
}

LP p_lsp_SET_2DDIFFERENCE(va_alist) va_dcl
{
LP v_S3189_23; LP v_Y_21; LP v_X_20; 
LP v_VALUE3188_19; LP v_X_17; LP v_X_15; 
LP v_LOOP_2DLIST_2D880_11; LP v_ELT_10; LP v_RES_9; 
LP v_LIST2_1; LP v_LIST1_0; LP v_KEYS3187_7; 
LP v_NOTP_6; LP v_TEST_2DNOT_5; LP v_TESTP_4; 
LP v_TEST_3; LP v_KEY_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_LIST1_0 = NEXT_VAR_ARG;
v_LIST2_1 = NEXT_VAR_ARG;


t0 = NEW_OE(1);
real_argc = REAL_ARGC(argc);
if (real_argc < 2) wna_low(real_argc,2);
DYNAMIC_RESTIFY(v_KEYS3187_7,3,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_KEY_2,LREF(s_key_KEY),v_KEYS3187_7)
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_IDENTITY));
v_KEY_2 = t1;
END_KEY_INIT
v_TESTP_4 = T;
BEGIN_KEY_INIT(v_TEST_3,LREF(s_key_TEST),v_KEYS3187_7)
v_TESTP_4 = NIL;
t2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_EQL));
v_TEST_3 = t2;
END_KEY_INIT
v_NOTP_6 = T;
BEGIN_KEY_INIT(v_TEST_2DNOT_5,LREF(s_key_TEST_2DNOT),v_KEYS3187_7)
v_NOTP_6 = NIL;
v_TEST_2DNOT_5 = LREF(s_lsp_NIL);
END_KEY_INIT
END_VAR_ARGS;
SET_OE_SLOT(t0,0,v_TEST_2DNOT_5);
if (v_TESTP_4 != NIL) {
t3 = v_NOTP_6;
} else {
t3 = LREF(s_lsp_NIL);
}
if (t3 != NIL) {
ICALL(s_lsp_ERROR) (1, LREF(k2160));
}
if (v_LIST2_1 != NIL) {
v_RES_9 = LREF(s_lsp_NIL);
v_ELT_10 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D880_11 = v_LIST1_0;
t_NEXT_2DLOOP_13:;
if (v_LOOP_2DLIST_2D880_11 == NIL) {
goto t_END_2DLOOP_14;
}
v_X_15 = v_LOOP_2DLIST_2D880_11;
v_ELT_10 = ((LP) DEREF((v_X_15) + 0 * 4));
v_X_17 = v_LOOP_2DLIST_2D880_11;
v_LOOP_2DLIST_2D880_11 = ((LP) DEREF((v_X_17) + 1 * 4));
if (v_TESTP_4 != NIL) {
t6 = v_NOTP_6;
} else {
t6 = LREF(s_lsp_NIL);
}
if (t6 != NIL) {
t5 = ICALL(s_lsp_ERROR) (1, LREF(k2160));
} else {
if (v_NOTP_6 != NIL) {
t7 = CODE_PTR(COERCE_TO_FUNCTION(v_KEY_2))(1, v_ELT_10);
t8 = MAKE_CLOSURE(p_lsp_SET_2DDIFFERENCE_2Danon21802181,t0);
t5 = ICALL(s_lsp_MEMBER_2F4) (4, t7, v_LIST2_1, t8, v_KEY_2);
} else {
t9 = CODE_PTR(COERCE_TO_FUNCTION(v_KEY_2))(1, v_ELT_10);
t5 = ICALL(s_lsp_MEMBER_2F4) (4, t9, v_LIST2_1, v_TEST_3, v_KEY_2);
}
}
if (t5 == NIL) {
v_VALUE3188_19 = v_ELT_10;
v_Y_21 = v_RES_9;
v_S3189_23 = (c_cons((v_VALUE3188_19), (v_Y_21)));
v_RES_9 = v_S3189_23;
}
goto t_NEXT_2DLOOP_13;
goto t_END_2DLOOP_14;
t_END_2DLOOP_14:;
goto b_NIL_12;
b_NIL_12:;
return(v_RES_9);
} else {
return(v_LIST1_0);
}
}

LP p_lsp_SET_2DDIFFERENCE_2Danon21802181(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = OE;
t2 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(2, v_X_0, v_Y_1);
t1 = ICALL(s_lsp_NOT) (MV_CALL(argc,1), t2);
return(t1);
}

LP p_lsp_SET_2DEXCLUSIVE_2DOR(va_alist) va_dcl
{
LP v_Y_32; LP v_X_31; LP v_X_29; 
LP v_X_27; LP v_LOOP_2DLIST_2D882_23; LP v_ELT_22; 
LP v_Y_20; LP v_X_19; LP v_X_17; 
LP v_X_15; LP v_LOOP_2DLIST_2D881_11; LP v_ELT_10; 
LP v_RESULT_9; LP v_LIST2_1; LP v_LIST1_0; 
LP v_KEYS3190_7; LP v_NOTP_6; LP v_TEST_2DNOT_5; 
LP v_TESTP_4; LP v_TEST_3; LP v_KEY_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_LIST1_0 = NEXT_VAR_ARG;
v_LIST2_1 = NEXT_VAR_ARG;


t0 = NEW_OE(1);
real_argc = REAL_ARGC(argc);
if (real_argc < 2) wna_low(real_argc,2);
DYNAMIC_RESTIFY(v_KEYS3190_7,3,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_KEY_2,LREF(s_key_KEY),v_KEYS3190_7)
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_IDENTITY));
v_KEY_2 = t1;
END_KEY_INIT
v_TESTP_4 = T;
BEGIN_KEY_INIT(v_TEST_3,LREF(s_key_TEST),v_KEYS3190_7)
v_TESTP_4 = NIL;
t2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_EQL));
v_TEST_3 = t2;
END_KEY_INIT
v_NOTP_6 = T;
BEGIN_KEY_INIT(v_TEST_2DNOT_5,LREF(s_key_TEST_2DNOT),v_KEYS3190_7)
v_NOTP_6 = NIL;
v_TEST_2DNOT_5 = LREF(s_lsp_NIL);
END_KEY_INIT
END_VAR_ARGS;
SET_OE_SLOT(t0,0,v_TEST_2DNOT_5);
v_RESULT_9 = LREF(s_lsp_NIL);
v_ELT_10 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D881_11 = v_LIST1_0;
t_NEXT_2DLOOP_13:;
if (v_LOOP_2DLIST_2D881_11 == NIL) {
goto t_END_2DLOOP_14;
}
v_X_15 = v_LOOP_2DLIST_2D881_11;
v_ELT_10 = ((LP) DEREF((v_X_15) + 0 * 4));
v_X_17 = v_LOOP_2DLIST_2D881_11;
v_LOOP_2DLIST_2D881_11 = ((LP) DEREF((v_X_17) + 1 * 4));
if (v_TESTP_4 != NIL) {
t4 = v_NOTP_6;
} else {
t4 = LREF(s_lsp_NIL);
}
if (t4 != NIL) {
t3 = ICALL(s_lsp_ERROR) (1, LREF(k2160));
} else {
if (v_NOTP_6 != NIL) {
t5 = CODE_PTR(COERCE_TO_FUNCTION(v_KEY_2))(1, v_ELT_10);
t6 = MAKE_CLOSURE(p_lsp_SET_2DEXCLUSIVE_2DOR_2Danon21822183,t0);
t3 = ICALL(s_lsp_MEMBER_2F4) (4, t5, v_LIST2_1, t6, v_KEY_2);
} else {
t7 = CODE_PTR(COERCE_TO_FUNCTION(v_KEY_2))(1, v_ELT_10);
t3 = ICALL(s_lsp_MEMBER_2F4) (4, t7, v_LIST2_1, v_TEST_3, v_KEY_2);
}
}
if (t3 == NIL) {
v_X_19 = v_ELT_10;
v_Y_20 = v_RESULT_9;
v_RESULT_9 = (c_cons((v_X_19), (v_Y_20)));
}
goto t_NEXT_2DLOOP_13;
goto t_END_2DLOOP_14;
t_END_2DLOOP_14:;
goto b_NIL_12;
b_NIL_12:;
v_ELT_22 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D882_23 = v_LIST2_1;
t_NEXT_2DLOOP_25:;
if (v_LOOP_2DLIST_2D882_23 == NIL) {
goto t_END_2DLOOP_26;
}
v_X_27 = v_LOOP_2DLIST_2D882_23;
v_ELT_22 = ((LP) DEREF((v_X_27) + 0 * 4));
v_X_29 = v_LOOP_2DLIST_2D882_23;
v_LOOP_2DLIST_2D882_23 = ((LP) DEREF((v_X_29) + 1 * 4));
if (v_TESTP_4 != NIL) {
t9 = v_NOTP_6;
} else {
t9 = LREF(s_lsp_NIL);
}
if (t9 != NIL) {
t8 = ICALL(s_lsp_ERROR) (1, LREF(k2160));
} else {
if (v_NOTP_6 != NIL) {
t10 = CODE_PTR(COERCE_TO_FUNCTION(v_KEY_2))(1, v_ELT_22);
t11 = MAKE_CLOSURE(p_lsp_SET_2DEXCLUSIVE_2DOR_2Danon21842185,t0);
t8 = ICALL(s_lsp_MEMBER_2F4) (4, t10, v_LIST1_0, t11, v_KEY_2);
} else {
t12 = CODE_PTR(COERCE_TO_FUNCTION(v_KEY_2))(1, v_ELT_22);
t8 = ICALL(s_lsp_MEMBER_2F4) (4, t12, v_LIST1_0, v_TEST_3, v_KEY_2);
}
}
if (t8 == NIL) {
v_X_31 = v_ELT_22;
v_Y_32 = v_RESULT_9;
v_RESULT_9 = (c_cons((v_X_31), (v_Y_32)));
}
goto t_NEXT_2DLOOP_25;
goto t_END_2DLOOP_26;
t_END_2DLOOP_26:;
goto b_NIL_24;
b_NIL_24:;
return(v_RESULT_9);
}

LP p_lsp_SET_2DEXCLUSIVE_2DOR_2Danon21842185(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = OE;
t2 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(2, v_X_0, v_Y_1);
t1 = ICALL(s_lsp_NOT) (MV_CALL(argc,1), t2);
return(t1);
}

LP p_lsp_SET_2DEXCLUSIVE_2DOR_2Danon21822183(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = OE;
t2 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(2, v_X_0, v_Y_1);
t1 = ICALL(s_lsp_NOT) (MV_CALL(argc,1), t2);
return(t1);
}

LP p_lsp_SET_2DNTH(argc, v_I_0, v_L_1, v_VALUE_2)
      ARGC argc;  LP v_I_0; LP v_L_1; LP v_VALUE_2;
{
LP v_X_9; LP v_V_7; LP v_X_6; 
LP v_T3192_5; LP v_S3191_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 

if (argc != 3) wna(argc,3);
START2186:
if (((int) (v_I_0) == (int) ((LP) 0))) {
v_S3191_4 = v_VALUE_2;
v_T3192_5 = v_L_1;
v_V_7 = v_VALUE_2;
((LP) (DEREF((v_L_1) + 0 * 4) = (LD) (v_V_7)));
return(v_V_7);
} else {
t2 = ICALL(s_lsp_1_2D) (1, v_I_0);
v_X_9 = v_L_1;
t3 = ((LP) DEREF((v_L_1) + 1 * 4));
v_I_0 = t2; v_L_1 = t3; 
goto START2186;
}
}

LP p_lsp_SUBLIS_2F4(argc, v_ALIST_0, v_TREE_1, v_TEST_2, v_KEY_3)
      ARGC argc;  LP v_ALIST_0; LP v_TREE_1; LP v_TEST_2; LP v_KEY_3;
{
LP v_X_13; LP v_Y_11; LP v_X_10; 
LP v_X_8; LP v_X_6; LP v_SUBST_5; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; 
if (argc != 4) wna(argc,4);
v_SUBST_5 = ICALL(s_lsp_ASSOC_2F4) (4, v_TREE_1, v_ALIST_0, v_TEST_2, v_KEY_3);
if (v_SUBST_5 != NIL) {
v_X_13 = v_SUBST_5;
t0 = ((LP) DEREF((v_SUBST_5) + 1 * 4));
return(t0);
} else {
t1 = ICALL(s_lsp_ATOM) (1, v_TREE_1);
if (t1 != NIL) {
return(v_TREE_1);
} else {
v_X_6 = v_TREE_1;
t2 = ((LP) DEREF((v_TREE_1) + 0 * 4));
v_X_10 = ICALL(s_lsp_SUBLIS_2F4) (4, v_ALIST_0, t2, v_TEST_2, v_KEY_3);
v_X_8 = v_TREE_1;
t3 = ((LP) DEREF((v_TREE_1) + 1 * 4));
v_Y_11 = ICALL(s_lsp_SUBLIS_2F4) (4, v_ALIST_0, t3, v_TEST_2, v_KEY_3);
t0 = (c_cons((v_X_10), (v_Y_11)));
return(t0);
}
}
}

LP p_lsp_SUBLIS(va_alist) va_dcl
{
LP v_TREE_1; LP v_ALIST_0; LP v_KEYS3193_5; 
LP v_KEY_4; LP v_TEST_2DNOT_3; LP v_TEST_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 

DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_ALIST_0 = NEXT_VAR_ARG;
v_TREE_1 = NEXT_VAR_ARG;


t0 = NEW_OE(1);
real_argc = REAL_ARGC(argc);
if (real_argc < 2) wna_low(real_argc,2);
DYNAMIC_RESTIFY(v_KEYS3193_5,3,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_TEST_2,LREF(s_key_TEST),v_KEYS3193_5)
v_TEST_2 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_TEST_2DNOT_3,LREF(s_key_TEST_2DNOT),v_KEYS3193_5)
v_TEST_2DNOT_3 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_KEY_4,LREF(s_key_KEY),v_KEYS3193_5)
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_IDENTITY));
v_KEY_4 = t1;
END_KEY_INIT
END_VAR_ARGS;
SET_OE_SLOT(t0,0,v_TEST_2DNOT_3);
if (v_TEST_2 != NIL) {
t3 = v_TEST_2;
} else {
if (GET_OE_SLOT(t0,0) != NIL) {
t4 = MAKE_CLOSURE(p_lsp_SUBLIS_2Danon21872188,t0);
t3 = t4;
} else {
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_EQL));
}
}
t2 = ICALL(s_lsp_SUBLIS_2F4) (MV_CALL(argc,4), v_ALIST_0, v_TREE_1, t3, v_KEY_4);
return(t2);
}

LP p_lsp_SUBLIS_2Danon21872188(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = OE;
t2 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(2, v_X_0, v_Y_1);
t1 = ICALL(s_lsp_NOT) (MV_CALL(argc,1), t2);
return(t1);
}

LP p_lsp_SUBSETP(va_alist) va_dcl
{
LP v_X_16; LP v_X_14; LP v_LOOP_2DLIST_2D883_10; 
LP v_ELT_9; LP v_LIST2_1; LP v_LIST1_0; 
LP v_KEYS3194_7; LP v_NOTP_6; LP v_TEST_2DNOT_5; 
LP v_TESTP_4; LP v_TEST_3; LP v_KEY_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_LIST1_0 = NEXT_VAR_ARG;
v_LIST2_1 = NEXT_VAR_ARG;


t0 = NEW_OE(1);
real_argc = REAL_ARGC(argc);
if (real_argc < 2) wna_low(real_argc,2);
DYNAMIC_RESTIFY(v_KEYS3194_7,3,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_KEY_2,LREF(s_key_KEY),v_KEYS3194_7)
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_IDENTITY));
v_KEY_2 = t1;
END_KEY_INIT
v_TESTP_4 = T;
BEGIN_KEY_INIT(v_TEST_3,LREF(s_key_TEST),v_KEYS3194_7)
v_TESTP_4 = NIL;
t2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_EQL));
v_TEST_3 = t2;
END_KEY_INIT
v_NOTP_6 = T;
BEGIN_KEY_INIT(v_TEST_2DNOT_5,LREF(s_key_TEST_2DNOT),v_KEYS3194_7)
v_NOTP_6 = NIL;
v_TEST_2DNOT_5 = LREF(s_lsp_NIL);
END_KEY_INIT
END_VAR_ARGS;
SET_OE_SLOT(t0,0,v_TEST_2DNOT_5);
v_ELT_9 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D883_10 = v_LIST1_0;
t_NEXT_2DLOOP_12:;
if (v_LOOP_2DLIST_2D883_10 == NIL) {
goto t_END_2DLOOP_13;
}
v_X_14 = v_LOOP_2DLIST_2D883_10;
v_ELT_9 = ((LP) DEREF((v_X_14) + 0 * 4));
v_X_16 = v_LOOP_2DLIST_2D883_10;
v_LOOP_2DLIST_2D883_10 = ((LP) DEREF((v_X_16) + 1 * 4));
if (v_TESTP_4 != NIL) {
t5 = v_NOTP_6;
} else {
t5 = LREF(s_lsp_NIL);
}
if (t5 != NIL) {
t4 = ICALL(s_lsp_ERROR) (1, LREF(k2160));
} else {
if (v_NOTP_6 != NIL) {
t6 = CODE_PTR(COERCE_TO_FUNCTION(v_KEY_2))(1, v_ELT_9);
t7 = MAKE_CLOSURE(p_lsp_SUBSETP_2Danon21892190,t0);
t4 = ICALL(s_lsp_MEMBER_2F4) (4, t6, v_LIST2_1, t7, v_KEY_2);
} else {
t8 = CODE_PTR(COERCE_TO_FUNCTION(v_KEY_2))(1, v_ELT_9);
t4 = ICALL(s_lsp_MEMBER_2F4) (4, t8, v_LIST2_1, v_TEST_3, v_KEY_2);
}
}
if (t4 == NIL) {
return(LREF(s_lsp_NIL));
return(NIL);
}
goto t_NEXT_2DLOOP_12;
goto t_END_2DLOOP_13;
t_END_2DLOOP_13:;
goto b_NIL_11;
b_NIL_11:;
return(LREF(s_lsp_T));
}

LP p_lsp_SUBSETP_2Danon21892190(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = OE;
t2 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(2, v_X_0, v_Y_1);
t1 = ICALL(s_lsp_NOT) (MV_CALL(argc,1), t2);
return(t1);
}

LP p_lsp_SUBST(argc, v_NEW_0, v_OLD_1, v_TREE_2)
      ARGC argc;  LP v_NEW_0; LP v_OLD_1; LP v_TREE_2;
{
LP v_Y_9; LP v_X_8; LP v_X_6; 
LP v_X_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; 
if (argc != 3) wna(argc,3);
t1 = ICALL(s_lsp_ATOM) (1, v_TREE_2);
if (t1 != NIL) {
t2 = ICALL(s_lsp_EQL) (2, v_TREE_2, v_OLD_1);
if (t2 != NIL) {
return(v_NEW_0);
} else {
return(v_TREE_2);
}
} else {
v_X_4 = v_TREE_2;
t3 = ((LP) DEREF((v_TREE_2) + 0 * 4));
v_X_8 = ICALL(s_lsp_SUBST) (3, v_NEW_0, v_OLD_1, t3);
v_X_6 = v_TREE_2;
t4 = ((LP) DEREF((v_TREE_2) + 1 * 4));
v_Y_9 = ICALL(s_lsp_SUBST) (3, v_NEW_0, v_OLD_1, t4);
t0 = (c_cons((v_X_8), (v_Y_9)));
return(t0);
}
}

LP p_lsp_UNION(va_alist) va_dcl
{
LP v_S3197_23; LP v_Y_21; LP v_X_20; 
LP v_VALUE3196_19; LP v_X_17; LP v_X_15; 
LP v_LOOP_2DLIST_2D884_11; LP v_ELT_10; LP v_RES_9; 
LP v_LIST2_1; LP v_LIST1_0; LP v_KEYS3195_7; 
LP v_NOTP_6; LP v_TEST_2DNOT_5; LP v_TESTP_4; 
LP v_TEST_3; LP v_KEY_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_LIST1_0 = NEXT_VAR_ARG;
v_LIST2_1 = NEXT_VAR_ARG;


t0 = NEW_OE(1);
real_argc = REAL_ARGC(argc);
if (real_argc < 2) wna_low(real_argc,2);
DYNAMIC_RESTIFY(v_KEYS3195_7,3,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_KEY_2,LREF(s_key_KEY),v_KEYS3195_7)
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_IDENTITY));
v_KEY_2 = t1;
END_KEY_INIT
v_TESTP_4 = T;
BEGIN_KEY_INIT(v_TEST_3,LREF(s_key_TEST),v_KEYS3195_7)
v_TESTP_4 = NIL;
t2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_EQL));
v_TEST_3 = t2;
END_KEY_INIT
v_NOTP_6 = T;
BEGIN_KEY_INIT(v_TEST_2DNOT_5,LREF(s_key_TEST_2DNOT),v_KEYS3195_7)
v_NOTP_6 = NIL;
v_TEST_2DNOT_5 = LREF(s_lsp_NIL);
END_KEY_INIT
END_VAR_ARGS;
SET_OE_SLOT(t0,0,v_TEST_2DNOT_5);
if (v_TESTP_4 != NIL) {
t3 = v_NOTP_6;
} else {
t3 = LREF(s_lsp_NIL);
}
if (t3 != NIL) {
ICALL(s_lsp_ERROR) (1, LREF(k2160));
}
v_RES_9 = v_LIST2_1;
v_ELT_10 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D884_11 = v_LIST1_0;
t_NEXT_2DLOOP_13:;
if (v_LOOP_2DLIST_2D884_11 == NIL) {
goto t_END_2DLOOP_14;
}
v_X_15 = v_LOOP_2DLIST_2D884_11;
v_ELT_10 = ((LP) DEREF((v_X_15) + 0 * 4));
v_X_17 = v_LOOP_2DLIST_2D884_11;
v_LOOP_2DLIST_2D884_11 = ((LP) DEREF((v_X_17) + 1 * 4));
if (v_TESTP_4 != NIL) {
t5 = v_NOTP_6;
} else {
t5 = LREF(s_lsp_NIL);
}
if (t5 != NIL) {
t4 = ICALL(s_lsp_ERROR) (1, LREF(k2160));
} else {
if (v_NOTP_6 != NIL) {
t6 = CODE_PTR(COERCE_TO_FUNCTION(v_KEY_2))(1, v_ELT_10);
t7 = MAKE_CLOSURE(p_lsp_UNION_2Danon21912192,t0);
t4 = ICALL(s_lsp_MEMBER_2F4) (4, t6, v_LIST2_1, t7, v_KEY_2);
} else {
t8 = CODE_PTR(COERCE_TO_FUNCTION(v_KEY_2))(1, v_ELT_10);
t4 = ICALL(s_lsp_MEMBER_2F4) (4, t8, v_LIST2_1, v_TEST_3, v_KEY_2);
}
}
if (t4 == NIL) {
v_VALUE3196_19 = v_ELT_10;
v_Y_21 = v_RES_9;
v_S3197_23 = (c_cons((v_VALUE3196_19), (v_Y_21)));
v_RES_9 = v_S3197_23;
}
goto t_NEXT_2DLOOP_13;
goto t_END_2DLOOP_14;
t_END_2DLOOP_14:;
goto b_NIL_12;
b_NIL_12:;
return(v_RES_9);
}

LP p_lsp_UNION_2Danon21912192(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = OE;
t2 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(2, v_X_0, v_Y_1);
t1 = ICALL(s_lsp_NOT) (MV_CALL(argc,1), t2);
return(t1);
}

