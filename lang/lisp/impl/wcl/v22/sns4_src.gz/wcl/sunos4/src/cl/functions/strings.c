/*
:comment "Compiled at 4:20:38 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: Debug Library"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O2 -fPIC"
:version 0
:end-package-info 0
:proclaim (QUOTE (INLINE MAKE-STRING))
:sym :INITIAL-ELEMENT
:sym MAKE-SIMPLE-STRING
:sf MAKE-STRING "p_lsp_MAKE_2DSTRING"
:sym :START
:sym :END
:sym ERROR
:sf NSTRING-CAPITALIZE "p_lsp_NSTRING_2DCAPITALIZE"
:sf NSTRING-UPCASE "p_lsp_NSTRING_2DUPCASE"
:proclaim (QUOTE (INLINE SIMPLE-STRING=))
:sym SIMPLE-STRING-P
:sym SIMPLE-STRING
:sym WTA
:sf SIMPLE-STRING= "p_lsp_SIMPLE_2DSTRING_3D"
:sf STRING-CAPITALIZE "p_lsp_STRING_2DCAPITALIZE"
:sym LENGTH
:sym MAX
:sym T
:sym NIL
:sf STRING-COMPARE "p_lsp_STRING_2DCOMPARE"
:proclaim (QUOTE (INLINE STRING-DOWNCASE))
:sym STRING-DOWNCASE/3
:sf STRING-DOWNCASE "p_lsp_STRING_2DDOWNCASE"
:sym STRING
:sym NSTRING-DOWNCASE/4
:sf STRING-DOWNCASE/3 "p_lsp_STRING_2DDOWNCASE_2F3"
:proclaim (QUOTE (INLINE NSTRING-DOWNCASE))
:sf NSTRING-DOWNCASE "p_lsp_NSTRING_2DDOWNCASE"
:sym CHAR-DOWNCASE
:sf NSTRING-DOWNCASE/4 "p_lsp_NSTRING_2DDOWNCASE_2F4"
:sf STRING= "p_lsp_STRING_3D"
:sym :START-1
:sym :LIMIT-1
:sym :START-2
:sym :LIMIT-2
:sym CHAR-EQUAL
:sf STRING-EQUAL "p_lsp_STRING_2DEQUAL"
:sym TRIM-LEFT-INDEX
:sym SUBSEQ-1
:sf STRING-LEFT-TRIM "p_lsp_STRING_2DLEFT_2DTRIM"
:sym :START1
:sym :END1
:sym :START2
:sym :END2
:sym CHAR-LESSP/2
:sym UNSAFE-SYMBOL-FUNCTION
:sym STRING-COMPARE
:sf STRING-LESSP "p_lsp_STRING_2DLESSP"
:sym TRIM-RIGHT-INDEX
:sf STRING-RIGHT-TRIM "p_lsp_STRING_2DRIGHT_2DTRIM"
:sf STRING-TRIM "p_lsp_STRING_2DTRIM"
:sym CHAR-UPCASE
:sf STRING-UPCASE "p_lsp_STRING_2DUPCASE"
:sym STRING-P
:sym SYMBOLP
:sym SYMBOL-NAME
:sym CHARACTERP
:sym SYMBOL
:sym CHARACTER
:sf STRING "p_lsp_STRING"
:sym FIND
:sf TRIM-LEFT-INDEX "p_lsp_TRIM_2DLEFT_2DINDEX"
:sf TRIM-RIGHT-INDEX "p_lsp_TRIM_2DRIGHT_2DINDEX"
:pinfo STRING-COMPARE (S1 S2 COMPARE) NIL NIL NIL NIL NIL NIL T
:pinfo NSTRING-CAPITALIZE (STRING &KEY START END) NIL NIL NIL NIL NIL NIL T
:pinfo STRING (X) NIL NIL NIL NIL NIL NIL T
:pinfo STRING-RIGHT-TRIM (CHAR-BAG STRING) NIL NIL NIL NIL NIL NIL T
:pinfo STRING-DOWNCASE (S &KEY (START 0) END) NIL NIL NIL (LAMBDA (S &KEY (START 0) END) (DECLARE) (BLOCK STRING-DOWNCASE (STRING-DOWNCASE/3 S START END))) NIL T T
:pinfo STRING-EQUAL (S1 S2 &KEY (START-1 0) LIMIT-1 (START-2 0) LIMIT-2) NIL NIL NIL NIL NIL NIL T
:pinfo NSTRING-UPCASE (STRING &KEY START END) NIL NIL NIL NIL NIL NIL T
:pinfo SIMPLE-STRING= (S1 S2) NIL (SIMPLE-STRING SIMPLE-STRING) NIL (LAMBDA (S1 S2) (DECLARE) (BLOCK SIMPLE-STRING= (%= (STRCMP S1 S2) 0))) NIL T T
:pinfo STRING-DOWNCASE/3 (S START END) NIL NIL NIL NIL NIL NIL T
:pinfo STRING-CAPITALIZE (STRING &KEY START END) NIL NIL NIL NIL NIL NIL T
:pinfo MAKE-STRING (N &KEY (INITIAL-ELEMENT #\Null)) NIL NIL NIL (LAMBDA (N &KEY (INITIAL-ELEMENT #\Null)) (DECLARE) (BLOCK MAKE-STRING (MAKE-SIMPLE-STRING N INITIAL-ELEMENT))) NIL T T
:pinfo NSTRING-DOWNCASE (STRING &KEY (START 0) END) NIL NIL NIL (LAMBDA (STRING &KEY (START 0) END) (DECLARE) (BLOCK NSTRING-DOWNCASE (NSTRING-DOWNCASE/4 STRING STRING START (OR END (LENGTH STRING))))) NIL T T
:pinfo NSTRING-DOWNCASE/4 (NEW OLD START END) NIL NIL NIL NIL NIL NIL T
:pinfo TRIM-RIGHT-INDEX (CHAR-BAG STRING) NIL NIL NIL NIL NIL NIL T
:pinfo STRING-TRIM (CHAR-BAG STRING) NIL NIL NIL NIL NIL NIL T
:pinfo STRING= (S1 S2) NIL NIL NIL NIL NIL NIL T
:pinfo STRING-UPCASE (S) NIL NIL NIL NIL NIL NIL T
:pinfo STRING-LEFT-TRIM (CHAR-BAG STRING) NIL NIL NIL NIL NIL NIL T
:pinfo STRING-LESSP (S1 S2 &KEY START1 END1 START2 END2) NIL NIL NIL NIL NIL NIL T
:pinfo TRIM-LEFT-INDEX (CHAR-BAG STRING) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_lsp_MAKE_2DSTRING();
extern SYMBOL s_key_INITIAL_2DELEMENT; 
extern SYMBOL s_lsp_MAKE_2DSIMPLE_2DSTRING; 
extern LP p_lsp_NSTRING_2DCAPITALIZE();
extern SYMBOL s_key_START; 
extern SYMBOL s_key_END; 
MAKE_SIMPLE_STRING(k3685,8,"write me");
extern SYMBOL s_lsp_ERROR; 
extern LP p_lsp_NSTRING_2DUPCASE();
extern LP p_lsp_SIMPLE_2DSTRING_3D();
extern SYMBOL s_lsp_SIMPLE_2DSTRING_2DP; 
extern SYMBOL s_lsp_SIMPLE_2DSTRING; 
extern SYMBOL s_lsp_WTA; 
extern LP p_lsp_STRING_2DCAPITALIZE();
extern LP p_lsp_STRING_2DCOMPARE();
extern SYMBOL s_lsp_LENGTH; 
extern SYMBOL s_lsp_MAX; 
extern SYMBOL s_lsp_T; 
extern SYMBOL s_lsp_NIL; 
extern LP p_lsp_STRING_2DDOWNCASE();
extern SYMBOL s_lsp_STRING_2DDOWNCASE_2F3; 
extern LP p_lsp_STRING_2DDOWNCASE_2F3();
extern SYMBOL s_lsp_STRING; 
extern SYMBOL s_lsp_NSTRING_2DDOWNCASE_2F4; 
extern LP p_lsp_NSTRING_2DDOWNCASE();
extern LP p_lsp_NSTRING_2DDOWNCASE_2F4();
extern SYMBOL s_lsp_CHAR_2DDOWNCASE; 
extern LP p_lsp_STRING_3D();
extern LP p_lsp_STRING_2DEQUAL();
extern SYMBOL s_key_START_2D1; 
extern SYMBOL s_key_LIMIT_2D1; 
extern SYMBOL s_key_START_2D2; 
extern SYMBOL s_key_LIMIT_2D2; 
extern SYMBOL s_lsp_CHAR_2DEQUAL; 
extern LP p_lsp_STRING_2DLEFT_2DTRIM();
extern SYMBOL s_lsp_TRIM_2DLEFT_2DINDEX; 
extern SYMBOL s_lsp_SUBSEQ_2D1; 
extern LP p_lsp_STRING_2DLESSP();
extern SYMBOL s_key_START1; 
extern SYMBOL s_key_END1; 
extern SYMBOL s_key_START2; 
extern SYMBOL s_key_END2; 
extern SYMBOL s_lsp_CHAR_2DLESSP_2F2; 
extern SYMBOL s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION; 
extern SYMBOL s_lsp_STRING_2DCOMPARE; 
extern LP p_lsp_STRING_2DRIGHT_2DTRIM();
extern SYMBOL s_lsp_TRIM_2DRIGHT_2DINDEX; 
extern LP p_lsp_STRING_2DTRIM();
extern LP p_lsp_STRING_2DUPCASE();
extern SYMBOL s_lsp_CHAR_2DUPCASE; 
extern LP p_lsp_STRING();
extern SYMBOL s_lsp_STRING_2DP; 
extern SYMBOL s_lsp_SYMBOLP; 
extern SYMBOL s_lsp_SYMBOL_2DNAME; 
extern SYMBOL s_lsp_CHARACTERP; 
MAKE_SIMPLE_STRING(k3686,36,"~S is not one of these types:~{ ~A~}");
extern SYMBOL s_lsp_SYMBOL; 
extern SYMBOL s_lsp_CHARACTER; 
MAKE_CONS(k3689,LREF(s_lsp_CHARACTER),LREF(s_lsp_NIL));
MAKE_CONS(k3688,LREF(s_lsp_SYMBOL),LREF(k3689));
MAKE_CONS(k3687,LREF(s_lsp_STRING),LREF(k3688));
extern LP p_lsp_TRIM_2DLEFT_2DINDEX();
extern SYMBOL s_lsp_FIND; 
extern LP p_lsp_TRIM_2DRIGHT_2DINDEX();


extern LP set_vref();
extern LP subtract();
extern LP vref();
extern LP num_equal_p();
extern int strcmp();


LP p_lsp_MAKE_2DSTRING(va_alist) va_dcl
{
LP v_N_0; LP v_KEYS5226_2; LP v_INITIAL_2DELEMENT_1; 

LP t0; LP t1; LP t2; LP t3; LP t4; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_N_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
DYNAMIC_RESTIFY(v_KEYS5226_2,2,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_INITIAL_2DELEMENT_1,LREF(s_key_INITIAL_2DELEMENT),v_KEYS5226_2)
v_INITIAL_2DELEMENT_1 = LREF(char_tab[0]);
END_KEY_INIT
END_VAR_ARGS;
t0 = ICALL(s_lsp_MAKE_2DSIMPLE_2DSTRING) (MV_CALL(argc,2), v_N_0, v_INITIAL_2DELEMENT_1);
return(t0);
}

LP p_lsp_NSTRING_2DCAPITALIZE(va_alist) va_dcl
{
LP v_STRING_0; LP v_KEYS5227_3; LP v_END_2; 
LP v_START_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_STRING_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
DYNAMIC_RESTIFY(v_KEYS5227_3,2,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_START_1,LREF(s_key_START),v_KEYS5227_3)
v_START_1 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_END_2,LREF(s_key_END),v_KEYS5227_3)
v_END_2 = NIL;
END_KEY_INIT
END_VAR_ARGS;
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,1), LREF(k3685));
return(t0);
}

LP p_lsp_NSTRING_2DUPCASE(va_alist) va_dcl
{
LP v_STRING_0; LP v_KEYS5228_3; LP v_END_2; 
LP v_START_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_STRING_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
DYNAMIC_RESTIFY(v_KEYS5228_3,2,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_START_1,LREF(s_key_START),v_KEYS5228_3)
v_START_1 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_END_2,LREF(s_key_END),v_KEYS5228_3)
v_END_2 = NIL;
END_KEY_INIT
END_VAR_ARGS;
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,1), LREF(k3685));
return(t0);
}

LP p_lsp_SIMPLE_2DSTRING_3D(argc, v_S1_0, v_S2_1)
      ARGC argc;  LP v_S1_0; LP v_S2_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_SIMPLE_2DSTRING_2DP) (1, v_S1_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_S1_0, LREF(s_lsp_SIMPLE_2DSTRING), (LP) 0);
}
t1 = ICALL(s_lsp_SIMPLE_2DSTRING_2DP) (1, v_S2_1);
if (t1 == NIL) {
ICALL(s_lsp_WTA) (3, v_S2_1, LREF(s_lsp_SIMPLE_2DSTRING), (LP) 0);
}
t3 = INT_TO_FX(strcmp(lisp_to_c_array(v_S1_0), lisp_to_c_array(v_S2_1)));
t2 = (((int) (t3) == (int) ((LP) 0)) ? T : NIL);
return(t2);
}

LP p_lsp_STRING_2DCAPITALIZE(va_alist) va_dcl
{
LP v_STRING_0; LP v_KEYS5229_3; LP v_END_2; 
LP v_START_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_STRING_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
DYNAMIC_RESTIFY(v_KEYS5229_3,2,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_START_1,LREF(s_key_START),v_KEYS5229_3)
v_START_1 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_END_2,LREF(s_key_END),v_KEYS5229_3)
v_END_2 = NIL;
END_KEY_INIT
END_VAR_ARGS;
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,1), LREF(k3685));
return(t0);
}

LP p_lsp_STRING_2DCOMPARE(argc, v_S1_0, v_S2_1, v_COMPARE_2)
      ARGC argc;  LP v_S1_0; LP v_S2_1; LP v_COMPARE_2;
{
LP v_LOOP_2DBIND_2D1113_7; LP v_I_6; LP v_L2_5; 
LP v_L1_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; 
if (argc != 3) wna(argc,3);
v_L1_4 = ICALL(s_lsp_LENGTH) (1, v_S1_0);
v_L2_5 = ICALL(s_lsp_LENGTH) (1, v_S2_1);
t1 = (num_equal_p((v_L1_4), (v_L2_5)));
if (t1 != NIL) {
v_I_6 = (LP) 0;
v_LOOP_2DBIND_2D1113_7 = ICALL(s_lsp_MAX) (2, v_L1_4, v_L2_5);
t_NEXT_2DLOOP_9:;
if (((int) (v_I_6) >= (int) (v_LOOP_2DBIND_2D1113_7))) {
goto t_END_2DLOOP_10;
}
t3 = (num_equal_p((v_I_6), (v_L1_4)));
if (t3 != NIL) {
return(LREF(s_lsp_T));
return(NIL);
}
t4 = (num_equal_p((v_I_6), (v_L2_5)));
if (t4 != NIL) {
return(LREF(s_lsp_NIL));
return(NIL);
}
t6 = (vref((v_S1_0), (v_I_6)));
t7 = (vref((v_S2_1), (v_I_6)));
t5 = CODE_PTR(COERCE_TO_FUNCTION(v_COMPARE_2))(2, t6, t7);
if (t5 == NIL) {
return(LREF(s_lsp_NIL));
return(NIL);
}
v_I_6 = (((LP) ((int) (v_I_6) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_9;
goto t_END_2DLOOP_10;
t_END_2DLOOP_10:;
return(LREF(s_lsp_T));
return(NIL);
return(NIL);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_STRING_2DDOWNCASE(va_alist) va_dcl
{
LP v_S_0; LP v_KEYS5230_3; LP v_END_2; 
LP v_START_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_S_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
DYNAMIC_RESTIFY(v_KEYS5230_3,2,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_START_1,LREF(s_key_START),v_KEYS5230_3)
v_START_1 = (LP) 0;
END_KEY_INIT
BEGIN_KEY_INIT(v_END_2,LREF(s_key_END),v_KEYS5230_3)
v_END_2 = NIL;
END_KEY_INIT
END_VAR_ARGS;
t0 = ICALL(s_lsp_STRING_2DDOWNCASE_2F3) (MV_CALL(argc,3), v_S_0, v_START_1, v_END_2);
return(t0);
}

LP p_lsp_STRING_2DDOWNCASE_2F3(argc, v_S_0, v_START_1, v_END_2)
      ARGC argc;  LP v_S_0; LP v_START_1; LP v_END_2;
{
LP v_INITIAL_2DELEMENT_10; LP v_N_9; LP v_N_7; 
LP v_INITIAL_2DELEMENT_8; LP v_LAST_6; LP v_G5231_5; 
LP v_STRING_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 3) wna(argc,3);
v_STRING_4 = ICALL(s_lsp_STRING) (1, v_S_0);
v_G5231_5 = v_END_2;
if (v_G5231_5 != NIL) {
v_LAST_6 = v_G5231_5;
} else {
v_LAST_6 = ICALL(s_lsp_LENGTH) (1, v_STRING_4);
}
v_N_9 = (subtract((v_LAST_6), (v_START_1)));
t1 = ICALL(s_lsp_MAKE_2DSIMPLE_2DSTRING) (2, v_N_9, LREF(char_tab[0]));
t0 = ICALL(s_lsp_NSTRING_2DDOWNCASE_2F4) (MV_CALL(argc,4), t1, v_STRING_4, v_START_1, v_LAST_6);
return(t0);
}

LP p_lsp_NSTRING_2DDOWNCASE(va_alist) va_dcl
{
LP v_G5233_5; LP v_STRING_0; LP v_KEYS5232_3; 
LP v_END_2; LP v_START_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_STRING_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
DYNAMIC_RESTIFY(v_KEYS5232_3,2,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_START_1,LREF(s_key_START),v_KEYS5232_3)
v_START_1 = (LP) 0;
END_KEY_INIT
BEGIN_KEY_INIT(v_END_2,LREF(s_key_END),v_KEYS5232_3)
v_END_2 = NIL;
END_KEY_INIT
END_VAR_ARGS;
v_G5233_5 = v_END_2;
if (v_G5233_5 != NIL) {
t1 = v_G5233_5;
} else {
t1 = ICALL(s_lsp_LENGTH) (1, v_STRING_0);
}
t0 = ICALL(s_lsp_NSTRING_2DDOWNCASE_2F4) (MV_CALL(argc,4), v_STRING_0, v_STRING_0, v_START_1, t1);
return(t0);
}

LP p_lsp_NSTRING_2DDOWNCASE_2F4(argc, v_NEW_0, v_OLD_1, v_START_2, v_END_3)
      ARGC argc;  LP v_NEW_0; LP v_OLD_1; LP v_START_2; LP v_END_3;
{
LP v_T5236_12; LP v_T5235_11; LP v_S5234_10; 
LP v_LOOP_2DBIND_2D1114_6; LP v_I_5; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; 
if (argc != 4) wna(argc,4);
v_I_5 = v_START_2;
t_NEXT_2DLOOP_8:;
if (((int) (v_I_5) >= (int) (v_END_3))) {
goto t_END_2DLOOP_9;
}
t1 = (vref((v_OLD_1), (v_I_5)));
v_S5234_10 = ICALL(s_lsp_CHAR_2DDOWNCASE) (1, t1);
v_T5235_11 = v_NEW_0;
v_T5236_12 = v_I_5;
(set_vref((v_S5234_10), (v_NEW_0), (v_T5236_12)));
v_I_5 = (((LP) ((int) (v_I_5) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_8;
goto t_END_2DLOOP_9;
t_END_2DLOOP_9:;
return(v_NEW_0);
}

LP p_lsp_STRING_3D(argc, v_S1_0, v_S2_1)
      ARGC argc;  LP v_S1_0; LP v_S2_1;
{
LP v_CHAR2_16; LP v_CHAR1_15; LP v_LOOP_2DBIND_2D1115_11; 
LP v_I_10; LP v_L2_9; LP v_L1_8; 
LP v_S2_6; LP v_S1_5; LP v_X2_4; 
LP v_X1_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 

if (argc != 2) wna(argc,2);
v_X1_3 = ICALL(s_lsp_STRING) (1, v_S1_0);
v_X2_4 = ICALL(s_lsp_STRING) (1, v_S2_1);
t2 = ICALL(s_lsp_SIMPLE_2DSTRING_2DP) (1, v_S1_0);
if (t2 != NIL) {
t1 = ICALL(s_lsp_SIMPLE_2DSTRING_2DP) (1, v_S2_1);
} else {
t1 = LREF(s_lsp_NIL);
}
if (t1 != NIL) {
v_S1_5 = v_S1_0;
v_S2_6 = v_S2_1;
t3 = INT_TO_FX(strcmp(lisp_to_c_array(v_S1_0), lisp_to_c_array(v_S2_1)));
t0 = (((int) (t3) == (int) ((LP) 0)) ? T : NIL);
return(t0);
} else {
v_L1_8 = ICALL(s_lsp_LENGTH) (1, v_X1_3);
v_L2_9 = ICALL(s_lsp_LENGTH) (1, v_X2_4);
t4 = (num_equal_p((v_L1_8), (v_L2_9)));
if (t4 != NIL) {
v_I_10 = (LP) 0;
t_NEXT_2DLOOP_13:;
if (((int) (v_I_10) >= (int) (v_L1_8))) {
goto t_END_2DLOOP_14;
}
v_CHAR1_15 = (vref((v_X1_3), (v_I_10)));
v_CHAR2_16 = (vref((v_X2_4), (v_I_10)));
if (((v_CHAR1_15) == (v_CHAR2_16)) == 0) {
return(LREF(s_lsp_NIL));
return(NIL);
}
v_I_10 = (((LP) ((int) (v_I_10) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_13;
goto t_END_2DLOOP_14;
t_END_2DLOOP_14:;
return(LREF(s_lsp_T));
return(NIL);
return(NIL);
} else {
return(LREF(s_lsp_NIL));
}
}
}

LP p_lsp_STRING_2DEQUAL(va_alist) va_dcl
{
LP v_LOOP_2DITER_2DFLAG_2D1118_18; LP v_LOOP_2DBIND_2D1117_17; LP v_I2_16; 
LP v_LOOP_2DBIND_2D1116_15; LP v_I1_14; LP v_END_2D2_13; 
LP v_G5239_12; LP v_END_2D1_11; LP v_G5238_10; 
LP v_STRING_2D2_9; LP v_STRING_2D1_8; LP v_S2_1; 
LP v_S1_0; LP v_KEYS5237_6; LP v_LIMIT_2D2_5; 
LP v_START_2D2_4; LP v_LIMIT_2D1_3; LP v_START_2D1_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_S1_0 = NEXT_VAR_ARG;
v_S2_1 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 2) wna_low(real_argc,2);
DYNAMIC_RESTIFY(v_KEYS5237_6,3,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_START_2D1_2,LREF(s_key_START_2D1),v_KEYS5237_6)
v_START_2D1_2 = (LP) 0;
END_KEY_INIT
BEGIN_KEY_INIT(v_LIMIT_2D1_3,LREF(s_key_LIMIT_2D1),v_KEYS5237_6)
v_LIMIT_2D1_3 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_START_2D2_4,LREF(s_key_START_2D2),v_KEYS5237_6)
v_START_2D2_4 = (LP) 0;
END_KEY_INIT
BEGIN_KEY_INIT(v_LIMIT_2D2_5,LREF(s_key_LIMIT_2D2),v_KEYS5237_6)
v_LIMIT_2D2_5 = NIL;
END_KEY_INIT
END_VAR_ARGS;
v_STRING_2D1_8 = ICALL(s_lsp_STRING) (1, v_S1_0);
v_STRING_2D2_9 = ICALL(s_lsp_STRING) (1, v_S2_1);
v_G5238_10 = v_LIMIT_2D1_3;
if (v_G5238_10 != NIL) {
v_END_2D1_11 = v_G5238_10;
} else {
v_END_2D1_11 = ICALL(s_lsp_LENGTH) (1, v_STRING_2D1_8);
}
v_G5239_12 = v_LIMIT_2D2_5;
if (v_G5239_12 != NIL) {
v_END_2D2_13 = v_G5239_12;
} else {
v_END_2D2_13 = ICALL(s_lsp_LENGTH) (1, v_STRING_2D2_9);
}
t2 = (subtract((v_END_2D1_11), (v_START_2D1_2)));
t3 = (subtract((v_END_2D2_13), (v_START_2D2_4)));
t1 = (num_equal_p((t2), (t3)));
if (t1 != NIL) {
v_I1_14 = v_START_2D1_2;
v_I2_16 = v_START_2D2_4;
v_LOOP_2DITER_2DFLAG_2D1118_18 = LREF(s_lsp_T);
t_NEXT_2DLOOP_20:;
if (((int) (v_I1_14) >= (int) (v_END_2D1_11))) {
goto t_END_2DLOOP_21;
}
if (v_LOOP_2DITER_2DFLAG_2D1118_18 == NIL) {
v_I2_16 = (((LP) ((int) (v_I2_16) + (int) ((LP) 2))));
}
if (((int) (v_I2_16) >= (int) (v_END_2D2_13))) {
goto t_END_2DLOOP_21;
}
t7 = (vref((v_STRING_2D1_8), (v_I1_14)));
t8 = (vref((v_STRING_2D2_9), (v_I2_16)));
t6 = ICALL(s_lsp_CHAR_2DEQUAL) (2, t7, t8);
if (t6 == NIL) {
return(LREF(s_lsp_NIL));
return(NIL);
}
v_LOOP_2DITER_2DFLAG_2D1118_18 = LREF(s_lsp_NIL);
v_I1_14 = (((LP) ((int) (v_I1_14) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_20;
goto t_END_2DLOOP_21;
t_END_2DLOOP_21:;
return(LREF(s_lsp_T));
return(NIL);
return(NIL);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_STRING_2DLEFT_2DTRIM(argc, v_CHAR_2DBAG_0, v_STRING_1)
      ARGC argc;  LP v_CHAR_2DBAG_0; LP v_STRING_1;
{
LP v_END_8; LP v_START_7; LP v_SEQ_6; 
LP v_START_4; LP v_SEQ_3; LP v_END_5; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 2) wna(argc,2);
v_SEQ_6 = v_STRING_1;
v_START_7 = ICALL(s_lsp_TRIM_2DLEFT_2DINDEX) (2, v_CHAR_2DBAG_0, v_STRING_1);
v_END_8 = LREF(s_lsp_NIL);
v_END_8 = ICALL(s_lsp_LENGTH) (1, v_SEQ_6);
t0 = ICALL(s_lsp_SUBSEQ_2D1) (MV_CALL(argc,3), v_SEQ_6, v_START_7, v_END_8);
return(t0);
}

LP p_lsp_STRING_2DLESSP(va_alist) va_dcl
{
LP v_S2_1; LP v_S1_0; LP v_KEYS5240_6; 
LP v_END2_5; LP v_START2_4; LP v_END1_3; 
LP v_START1_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_S1_0 = NEXT_VAR_ARG;
v_S2_1 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 2) wna_low(real_argc,2);
DYNAMIC_RESTIFY(v_KEYS5240_6,3,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_START1_2,LREF(s_key_START1),v_KEYS5240_6)
v_START1_2 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_END1_3,LREF(s_key_END1),v_KEYS5240_6)
v_END1_3 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_START2_4,LREF(s_key_START2),v_KEYS5240_6)
v_START2_4 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_END2_5,LREF(s_key_END2),v_KEYS5240_6)
v_END2_5 = NIL;
END_KEY_INIT
END_VAR_ARGS;
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_CHAR_2DLESSP_2F2));
t0 = ICALL(s_lsp_STRING_2DCOMPARE) (MV_CALL(argc,3), v_S1_0, v_S2_1, t1);
return(t0);
}

LP p_lsp_STRING_2DRIGHT_2DTRIM(argc, v_CHAR_2DBAG_0, v_STRING_1)
      ARGC argc;  LP v_CHAR_2DBAG_0; LP v_STRING_1;
{
LP v_END_8; LP v_START_7; LP v_SEQ_6; 
LP v_START_4; LP v_SEQ_3; LP v_END_5; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 2) wna(argc,2);
v_END_8 = ICALL(s_lsp_TRIM_2DRIGHT_2DINDEX) (2, v_CHAR_2DBAG_0, v_STRING_1);
t0 = ICALL(s_lsp_SUBSEQ_2D1) (MV_CALL(argc,3), v_STRING_1, (LP) 0, v_END_8);
return(t0);
}

LP p_lsp_STRING_2DTRIM(argc, v_CHAR_2DBAG_0, v_STRING_1)
      ARGC argc;  LP v_CHAR_2DBAG_0; LP v_STRING_1;
{
LP v_END_8; LP v_START_7; LP v_SEQ_6; 
LP v_START_4; LP v_SEQ_3; LP v_END_5; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
if (argc != 2) wna(argc,2);
v_START_7 = ICALL(s_lsp_TRIM_2DLEFT_2DINDEX) (2, v_CHAR_2DBAG_0, v_STRING_1);
v_END_8 = ICALL(s_lsp_TRIM_2DRIGHT_2DINDEX) (2, v_CHAR_2DBAG_0, v_STRING_1);
t0 = ICALL(s_lsp_SUBSEQ_2D1) (MV_CALL(argc,3), v_STRING_1, v_START_7, v_END_8);
return(t0);
}

LP p_lsp_STRING_2DUPCASE(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{
LP v_V5244_18; LP v_T5243_17; LP v_T5242_16; 
LP v_S5241_15; LP v_LOOP_2DBIND_2D1119_11; LP v_I_10; 
LP v_NEW_9; LP v_INITIAL_2DELEMENT_7; LP v_N_6; 
LP v_N_4; LP v_INITIAL_2DELEMENT_5; LP v_LEN_3; 
LP v_STRING_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; 
if (argc != 1) wna(argc,1);
v_STRING_2 = ICALL(s_lsp_STRING) (1, v_S_0);
v_LEN_3 = ICALL(s_lsp_LENGTH) (1, v_STRING_2);
v_N_6 = v_LEN_3;
v_INITIAL_2DELEMENT_7 = LREF(char_tab[0]);
v_NEW_9 = ICALL(s_lsp_MAKE_2DSIMPLE_2DSTRING) (2, v_LEN_3, LREF(char_tab[0]));
v_I_10 = (LP) 0;
t_NEXT_2DLOOP_13:;
if (((int) (v_I_10) >= (int) (v_LEN_3))) {
goto t_END_2DLOOP_14;
}
t2 = (vref((v_STRING_2), (v_I_10)));
v_S5241_15 = ICALL(s_lsp_CHAR_2DUPCASE) (1, t2);
v_T5242_16 = v_NEW_9;
v_T5243_17 = v_I_10;
v_V5244_18 = v_S5241_15;
((LP) (*((v_NEW_9) - 1 + FX_TO_INT(v_T5243_17)) = (char) RAW_CHAR(v_V5244_18)));
v_I_10 = (((LP) ((int) (v_I_10) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_13;
goto t_END_2DLOOP_14;
t_END_2DLOOP_14:;
return(v_NEW_9);
return(NIL);
return(NIL);
}

LP p_lsp_STRING(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{
LP v_V5250_13; LP v_T5249_12; LP v_T5248_11; 
LP v_S5247_10; LP v_S_9; LP v_INITIAL_2DELEMENT_7; 
LP v_N_6; LP v_N_4; LP v_INITIAL_2DELEMENT_5; 
LP v_KEY5246_3; LP v_KEY5245_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 

if (argc != 1) wna(argc,1);
v_KEY5245_2 = v_X_0;
v_KEY5246_3 = v_KEY5245_2;
t1 = ICALL(s_lsp_STRING_2DP) (1, v_KEY5246_3);
if (t1 != NIL) {
return(v_X_0);
} else {
t2 = ICALL(s_lsp_SYMBOLP) (1, v_KEY5246_3);
if (t2 != NIL) {
t0 = ICALL(s_lsp_SYMBOL_2DNAME) (MV_CALL(argc,1), v_X_0);
return(t0);
} else {
t3 = ICALL(s_lsp_CHARACTERP) (1, v_KEY5246_3);
if (t3 != NIL) {
v_N_6 = (LP) 2;
v_INITIAL_2DELEMENT_7 = LREF(char_tab[0]);
v_S_9 = ICALL(s_lsp_MAKE_2DSIMPLE_2DSTRING) (2, (LP) 2, LREF(char_tab[0]));
v_S5247_10 = v_X_0;
v_T5248_11 = v_S_9;
v_T5249_12 = (LP) 0;
v_V5250_13 = v_X_0;
((LP) (*((v_S_9) - 1 + 0) = (char) RAW_CHAR(v_V5250_13)));
return(v_S_9);
} else {
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,3), LREF(k3686), v_KEY5245_2, LREF(k3687));
return(t0);
}
}
}
}

LP p_lsp_TRIM_2DLEFT_2DINDEX(argc, v_CHAR_2DBAG_0, v_STRING_1)
      ARGC argc;  LP v_CHAR_2DBAG_0; LP v_STRING_1;
{
LP v_LOOP_2DBIND_2D1120_5; LP v_I_4; LP v_LEN_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 

if (argc != 2) wna(argc,2);
v_LEN_3 = ICALL(s_lsp_LENGTH) (1, v_STRING_1);
v_I_4 = (LP) 0;
t_NEXT_2DLOOP_7:;
if (((int) (v_I_4) >= (int) (v_LEN_3))) {
goto t_END_2DLOOP_8;
}
t3 = (vref((v_STRING_1), (v_I_4)));
t2 = ICALL(s_lsp_FIND) (2, t3, v_CHAR_2DBAG_0);
if (t2 == NIL) {
return(v_I_4);
return(NIL);
}
v_I_4 = (((LP) ((int) (v_I_4) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_7;
goto t_END_2DLOOP_8;
t_END_2DLOOP_8:;
return(v_LEN_3);
return(NIL);
return(NIL);
}

LP p_lsp_TRIM_2DRIGHT_2DINDEX(argc, v_CHAR_2DBAG_0, v_STRING_1)
      ARGC argc;  LP v_CHAR_2DBAG_0; LP v_STRING_1;
{
LP v_I_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; 
if (argc != 2) wna(argc,2);
v_I_3 = ICALL(s_lsp_LENGTH) (1, v_STRING_1);
t_NEXT_2DLOOP_5:;
if (((int) (v_I_3) <= (int) ((LP) 0))) {
goto t_END_2DLOOP_6;
}
t4 = (subtract((v_I_3), ((LP) 2)));
t3 = (vref((v_STRING_1), (t4)));
t2 = ICALL(s_lsp_FIND) (2, t3, v_CHAR_2DBAG_0);
if (t2 == NIL) {
return(v_I_3);
return(NIL);
}
v_I_3 = (((LP) ((int) (v_I_3) - (int) ((LP) 2))));
goto t_NEXT_2DLOOP_5;
goto t_END_2DLOOP_6;
t_END_2DLOOP_6:;
return((LP) 0);
return(NIL);
return(NIL);
}

