/*
:comment "Compiled at 6:26:39 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: DEFAULT"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O "
:version 0
:package (IN-PACKAGE (QUOTE PCL)) 
:end-package-info 0
:end
*/

#include "lisp.h"





