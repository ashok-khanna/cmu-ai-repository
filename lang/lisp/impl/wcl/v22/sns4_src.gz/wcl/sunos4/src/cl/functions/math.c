/*
:comment "Compiled at 4:12:47 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: Debug Library"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O2 -fPIC"
:version 0
:end-package-info 0
:sym PLUSP
:sf ABS "p_lsp_ABS"
:proclaim (QUOTE (INLINE ACOS))
:sym FLOAT
:sf ACOS "p_lsp_ACOS"
:sym NUMBERP
:sym ERROR
:sf ARITH-ERROR "p_lsp_ARITH_2DERROR"
:sym INTEGERP
:sym INTEGER
:sym WTA
:sym FIXNUMP
:sym FIXNUM
:sym ABS
:sym TRUNCATE
:sf ASH "p_lsp_ASH"
:proclaim (QUOTE (INLINE ASIN))
:sf ASIN "p_lsp_ASIN"
:sf ATAN/2 "p_lsp_ATAN_2F2"
:sym ATAN/2
:sf ATAN "p_lsp_ATAN"
:sym ENSURE-BIGNUM
:sf BIGNUM-DIV "p_lsp_BIGNUM_2DDIV"
:sf BIGNUM-REM "p_lsp_BIGNUM_2DREM"
:sym EQL
:sym LOGNOT
:sym LOGAND/2
:sym LOGIOR/2
:sym LOGXOR
:sym LOGEQV
:sym LOGNAND
:sym LOGNOR
:sym LOGANDC1
:sym LOGANDC2
:sym LOGORC1
:sym LOGORC2
:sym NIL
:sf BOOLE "p_lsp_BOOLE"
:sym FORMAT
:sf WRITE-BYTE-SPECIFIER "p_lsp_WRITE_2DBYTE_2DSPECIFIER"
:proclaim (QUOTE (INLINE BYTE))
:sym MAKE-BYTE/2
:sf BYTE "p_lsp_BYTE"
:sym BYTE-P
:sym BYTE-SPECIFIER
:sym LDB-1
:sf LDB "p_lsp_LDB"
:sym LDB/FIXNUM
:sym LDB/BIGNUM
:sym BIGNUM
:sf LDB-1 "p_lsp_LDB_2D1"
:proclaim (QUOTE (INLINE LDB/FIXNUM))
:sf LDB/FIXNUM "p_lsp_LDB_2FFIXNUM"
:sym ASH
:sf LDB/BIGNUM "p_lsp_LDB_2FBIGNUM"
:sym DPB-1
:sf DPB "p_lsp_DPB"
:sym DPB/FIXNUM
:sym DPB/BIGNUM
:sf DPB-1 "p_lsp_DPB_2D1"
:sf DPB/FIXNUM "p_lsp_DPB_2FFIXNUM"
:sym MASK-FIELD-1
:sf DPB/BIGNUM "p_lsp_DPB_2FBIGNUM"
:sym LDB
:sym NOT
:sf LDB-TEST "p_lsp_LDB_2DTEST"
:sf MASK-FIELD "p_lsp_MASK_2DFIELD"
:sf MASK-FIELD-1 "p_lsp_MASK_2DFIELD_2D1"
:sym DPB
:sf DEPOSIT-FIELD "p_lsp_DEPOSIT_2DFIELD"
:proclaim (QUOTE (INLINE CEILING/FIXNUM))
:sym 1+
:sf CEILING/FIXNUM "p_lsp_CEILING_2FFIXNUM"
:proclaim (QUOTE (INLINE CEILING/FLOAT))
:sf CEILING/FLOAT "p_lsp_CEILING_2FFLOAT"
:sf CEILING "p_lsp_CEILING"
:proclaim (QUOTE (INLINE COMPLEX))
:sym MAKE-COMPLEX
:sf COMPLEX "p_lsp_COMPLEX"
:sf MAKE-COMPLEX "p_lsp_MAKE_2DCOMPLEX"
:proclaim (QUOTE (INLINE COS))
:sf COS "p_lsp_COS"
:sym FLOATP
:sf DECODE-FLOAT "p_lsp_DECODE_2DFLOAT"
:sf INTEGER-DECODE-FLOAT "p_lsp_INTEGER_2DDECODE_2DFLOAT"
:sym LENGTH
:sym T
:sf / "p_lsp__2F"
:sf ENSURE-BIGNUM "p_lsp_ENSURE_2DBIGNUM"
:sf ENSURE-FIXNUM "p_lsp_ENSURE_2DFIXNUM"
:sym REM
:sym ZEROP
:sf EVENP "p_lsp_EVENP"
:proclaim (QUOTE (INLINE EXP))
:sf EXP "p_lsp_EXP"
:sym EXPT/FIXNUM
:sym EXPT/FLOAT
:sf EXPT "p_lsp_EXPT"
:sf EXPT/FIXNUM "p_lsp_EXPT_2FFIXNUM"
:sf EXPT/FLOAT "p_lsp_EXPT_2FFLOAT"
:sf FFLOOR "p_lsp_FFLOOR"
:sf FLOAT-RADIX "p_lsp_FLOAT_2DRADIX"
:proclaim (QUOTE (INLINE FLOAT))
:sym FLOAT-1
:sf FLOAT "p_lsp_FLOAT"
:sym NUMERATOR
:sym DENOMINATOR
:sf FLOAT-1 "p_lsp_FLOAT_2D1"
:proclaim (QUOTE (INLINE FLOOR/FIXNUM))
:sf FLOOR/FIXNUM "p_lsp_FLOOR_2FFIXNUM"
:proclaim (QUOTE (INLINE FLOOR/FLOAT))
:sf FLOOR/FLOAT "p_lsp_FLOOR_2FFLOAT"
:sf FLOOR "p_lsp_FLOOR"
:sym FLOOR
:sf FLOOR/1V "p_lsp_FLOOR_2F1V"
:sf GCD/2 "p_lsp_GCD_2F2"
:sym GCD/2
:sf GCD "p_lsp_GCD"
:sym MEMQL
:sf >= "p_lsp__3E_3D"
:sf > "p_lsp__3E"
:sym COMPLEXP
:sym COMPLEX
:sf IMAGPART "p_lsp_IMAGPART"
:sf INTEGER-LENGTH "p_lsp_INTEGER_2DLENGTH"
:sym MAX
:sym GCD
:sym MIN
:sf LCM/2 "p_lsp_LCM_2F2"
:sym LCM/2
:sf LCM "p_lsp_LCM"
:sf <= "p_lsp__3C_3D"
:sf < "p_lsp__3C"
:proclaim (QUOTE (INLINE LOG/10))
:sf LOG/10 "p_lsp_LOG_2F10"
:sf LOG/E "p_lsp_LOG_2FE"
:sym LOG/E
:sf LOG "p_lsp_LOG"
:sf LOGAND/2 "p_lsp_LOGAND_2F2"
:sf LOGAND "p_lsp_LOGAND"
:sf LOGANDC1 "p_lsp_LOGANDC1"
:sf LOGANDC2 "p_lsp_LOGANDC2"
:sf LOGEQV/2 "p_lsp_LOGEQV_2F2"
:sym LOGEQV/2
:sf LOGEQV "p_lsp_LOGEQV"
:proclaim (QUOTE (INLINE LOGIOR/2))
:sf LOGIOR/2 "p_lsp_LOGIOR_2F2"
:sf LOGIOR "p_lsp_LOGIOR"
:sf LOGNAND "p_lsp_LOGNAND"
:proclaim (QUOTE (INLINE LOGNOR))
:sf LOGNOR "p_lsp_LOGNOR"
:proclaim (QUOTE (INLINE LOGNOT))
:sf LOGNOT "p_lsp_LOGNOT"
:sym LDB-TEST
:sf LOGBITP "p_lsp_LOGBITP"
:sf LOGTEST "p_lsp_LOGTEST"
:proclaim (QUOTE (INLINE LOGORC1))
:sf LOGORC1 "p_lsp_LOGORC1"
:proclaim (QUOTE (INLINE LOGORC2))
:sf LOGORC2 "p_lsp_LOGORC2"
:proclaim (QUOTE (INLINE LOGXOR/2))
:sf LOGXOR/2 "p_lsp_LOGXOR_2F2"
:sf LOGXOR "p_lsp_LOGXOR"
:sf MAKE-RATIO "p_lsp_MAKE_2DRATIO"
:proclaim (QUOTE (INLINE MAX/2))
:sf MAX/2 "p_lsp_MAX_2F2"
:sf MAX "p_lsp_MAX"
:proclaim (QUOTE (INLINE MIN/2))
:sf MIN/2 "p_lsp_MIN_2F2"
:sf MIN "p_lsp_MIN"
:sf - "p_lsp__2D"
:proclaim (QUOTE (INLINE MINUSP))
:sf MINUSP "p_lsp_MINUSP"
:sf MOD "p_lsp_MOD"
:sf = "p_lsp__3D"
:sf NUM-NOT-EQUAL-P "p_lsp_NUM_2DNOT_2DEQUAL_2DP"
:sym NUM-NOT-EQUAL-P
:sf /= "p_lsp__2F_3D"
:sym RATIOP
:sym RATIO
:sf NUMERATOR "p_lsp_NUMERATOR"
:sf DENOMINATOR "p_lsp_DENOMINATOR"
:sym EVENP
:sf ODDP "p_lsp_ODDP"
:proclaim (QUOTE (INLINE 1-))
:sf 1- "p_lsp_1_2D"
:proclaim (QUOTE (INLINE 1+))
:sf 1+ "p_lsp_1_2B"
:sf + "p_lsp__2B"
:proclaim (QUOTE (INLINE PLUSP))
:sf PLUSP "p_lsp_PLUSP"
:sym RATIONAL
:sf RATIONALIZE "p_lsp_RATIONALIZE"
:sym *
:sym INTEGER-RANGE-P
:sym RATIONAL/FLOAT
:sf RATIONAL "p_lsp_RATIONAL"
:sym WARN
:sf RATIONAL/FLOAT "p_lsp_RATIONAL_2FFLOAT"
:sf REALPART "p_lsp_REALPART"
:sf REM "p_lsp_REM"
:sym ODDP
:sf ROUND/2 "p_lsp_ROUND_2F2"
:proclaim (QUOTE (INLINE ROUND))
:sym ROUND/2
:sf ROUND "p_lsp_ROUND"
:sf SCALE-FLOAT "p_lsp_SCALE_2DFLOAT"
:sym RATIONALP
:sf SIGNUM "p_lsp_SIGNUM"
:proclaim (QUOTE (INLINE SIN))
:sf SIN "p_lsp_SIN"
:sf SQRT "p_lsp_SQRT"
:sf TAN "p_lsp_TAN"
:sf * "p_lsp__2A"
:proclaim (QUOTE (INLINE TRUNCATE))
:sym TRUNCATE/2
:sf TRUNCATE "p_lsp_TRUNCATE"
:sym TRUNCATE-FLOAT/2
:sym BIGNUM-DIV
:sym BIGNUM-REM
:sf TRUNCATE/2 "p_lsp_TRUNCATE_2F2"
:sf TRUNCATE-FLOAT/2 "p_lsp_TRUNCATE_2DFLOAT_2F2"
:proclaim (QUOTE (INLINE ZEROP))
:sf ZEROP "p_lsp_ZEROP"
:pinfo LOGEQV (ARG-1 &RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo MAKE-RATIO (NUMERATOR DENOMINATOR) NIL NIL NIL NIL NIL NIL T
:pinfo TRUNCATE (N &OPTIONAL (DIVISOR 1)) NIL NIL NIL (LAMBDA (N &OPTIONAL (DIVISOR 1)) (DECLARE) (BLOCK TRUNCATE (TRUNCATE/2 N DIVISOR))) NIL T T
:pinfo LOGTEST (X Y) NIL NIL NIL NIL NIL NIL T
:pinfo DPB/BIGNUM (VALUE SIZE POSITION N) NIL NIL NIL NIL NIL NIL T
:pinfo MASK-FIELD (BYTE-SPEC N) NIL NIL NIL NIL NIL NIL T
:pinfo GCD/2 (X Y) NIL NIL NIL NIL NIL NIL T
:pinfo LDB/FIXNUM (SIZE POSITION N) NIL NIL NIL (LAMBDA (SIZE POSITION N) (DECLARE) (BLOCK LDB/FIXNUM (%LOAD-FIELD (%FIELD-MASK SIZE) POSITION N))) NIL T T
:pinfo LOGNOR (I1 I2) NIL NIL NIL (LAMBDA (I1 I2) (DECLARE) (BLOCK LOGNOR (LOGNOT (LOGIOR I1 I2)))) NIL T T
:pinfo LOGNOT (X) NIL (FIXNUM) NIL (LAMBDA (X) (DECLARE) (BLOCK LOGNOT (%LOGNOT X))) NIL T T
:pinfo DEPOSIT-FIELD (VALUE BYTE-SPEC N) NIL NIL NIL NIL NIL NIL T
:pinfo ARITH-ERROR (X Y) NIL NIL NIL NIL NIL NIL T
:pinfo /= (&RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo ROUND (N &OPTIONAL (DIVISOR 1)) NIL NIL NIL (LAMBDA (N &OPTIONAL (DIVISOR 1)) (DECLARE) (BLOCK ROUND (ROUND/2 N DIVISOR))) NIL T T
:pinfo LOGEQV/2 (X Y) NIL (FIXNUM FIXNUM) NIL NIL NIL NIL T
:pinfo LOGIOR (ARG-1 &RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo ASH (N COUNT) NIL (INTEGER FIXNUM) NIL NIL NIL NIL T
:pinfo MAX/2 (X Y) NIL NIL NIL (LAMBDA (X Y) (DECLARE) (BLOCK MAX/2 (IF (> X Y) X Y))) NIL T T
:pinfo + (&RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo RATIONAL/FLOAT (F) NIL NIL NIL NIL NIL NIL T
:pinfo - (&RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo * (X &RESTV OTHERS) NIL NIL NIL NIL NIL NIL T
:pinfo / (X &RESTV OTHERS) NIL NIL NIL NIL NIL NIL T
:pinfo COMPLEX (REALPART &OPTIONAL (IMAGPART 0)) NIL NIL NIL (LAMBDA (REALPART &OPTIONAL (IMAGPART 0)) (DECLARE) (BLOCK COMPLEX (MAKE-COMPLEX REALPART IMAGPART))) NIL T T
:pinfo WRITE-BYTE-SPECIFIER (BYTE-SPEC STREAM DEPTH) NIL NIL NIL NIL NIL NIL T
:pinfo ACOS (X) NIL NIL NIL (LAMBDA (X) (DECLARE) (BLOCK ACOS (DOUBLE_ACOS (FLOAT X)))) NIL T T
:pinfo LOGXOR/2 (X Y) NIL (FIXNUM FIXNUM) NIL (LAMBDA (X Y) (DECLARE) (BLOCK LOGXOR/2 (%LOGXOR X Y))) NIL T T
:pinfo LOGIOR/2 (X Y) NIL (FIXNUM FIXNUM) NIL (LAMBDA (X Y) (DECLARE) (BLOCK LOGIOR/2 (%LOGIOR X Y))) NIL T T
:pinfo BIGNUM-REM (X Y) NIL NIL NIL NIL NIL NIL T
:pinfo < (&RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo = (&RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo > (&RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo FLOOR (X &OPTIONAL (Y 1)) NIL NIL NIL NIL NIL NIL T
:pinfo MAX (ARG-1 &RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo NUMERATOR (R) NIL (RATIO) NIL NIL NIL NIL T
:pinfo LOGNAND (I1 I2) NIL NIL NIL NIL NIL NIL T
:pinfo LOGORC1 (I1 I2) NIL NIL NIL (LAMBDA (I1 I2) (DECLARE) (BLOCK LOGORC1 (LOGIOR (LOGNOT I1) I2))) NIL T T
:pinfo LDB/BIGNUM (SIZE POSITION N) NIL NIL NIL NIL NIL NIL T
:pinfo FLOAT-RADIX (X) NIL (FLOAT) NIL NIL NIL NIL T
:pinfo LOG (N &OPTIONAL BASE) NIL NIL NIL NIL NIL NIL T
:pinfo LOGORC2 (I1 I2) NIL NIL NIL (LAMBDA (I1 I2) (DECLARE) (BLOCK LOGORC2 (LOGIOR I1 (LOGNOT I2)))) NIL T T
:pinfo LOGAND (ARG-1 &RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo DPB-1 (VALUE SIZE POSITION N) NIL NIL NIL NIL NIL NIL T
:pinfo COS (X) NIL NIL NIL (LAMBDA (X) (DECLARE) (BLOCK COS (DOUBLE_COS (FLOAT X)))) NIL T T
:pinfo FLOOR/FLOAT (X Y) NIL NIL NIL (LAMBDA (X Y) (DECLARE) (BLOCK FLOOR/FLOAT (VALUES (DOUBLE_TRUNCATE (DOUBLE_FLOOR (/ X Y)) 1.0) (FMOD X Y)))) NIL T T
:pinfo ZEROP (N) NIL NIL NIL (LAMBDA (N) (DECLARE) (BLOCK ZEROP (= N 0))) NIL T T
:pinfo LOGBITP (INDEX N) NIL (FIXNUM INTEGER) NIL NIL NIL NIL T
:pinfo REALPART (C) NIL (COMPLEX) NIL NIL NIL NIL T
:pinfo ASIN (X) NIL NIL NIL (LAMBDA (X) (DECLARE) (BLOCK ASIN (DOUBLE_ASIN (FLOAT X)))) NIL T T
:pinfo GCD (&RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo NUM-NOT-EQUAL-P (N1 N2) NIL NIL NIL NIL NIL NIL T
:pinfo DENOMINATOR (R) NIL (RATIO) NIL NIL NIL NIL T
:pinfo REM (X Y) NIL (T T) NIL NIL NIL NIL T
:pinfo ATAN (Y &OPTIONAL (X 0)) NIL NIL NIL NIL NIL NIL T
:pinfo MASK-FIELD-1 (SIZE POSITION N) NIL NIL NIL NIL NIL NIL T
:pinfo IMAGPART (C) NIL (COMPLEX) NIL NIL NIL NIL T
:pinfo LOG/E (N) NIL NIL NIL NIL NIL NIL T
:pinfo >= (&RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo SIGNUM (N) NIL NIL NIL NIL NIL NIL T
:pinfo FLOOR/FIXNUM (X Y) NIL NIL NIL (LAMBDA (X Y) (DECLARE) (BLOCK FLOOR/FIXNUM (VALUES (%DIV X Y) (%REM X Y)))) NIL T T
:pinfo SCALE-FLOAT (X EXPONENT) NIL (FLOAT FIXNUM) NIL NIL NIL NIL T
:pinfo CEILING/FIXNUM (X Y) NIL NIL NIL (LAMBDA (X Y) (DECLARE) (BLOCK CEILING/FIXNUM (LET ((Q (%DIV X Y)) (R (%REM X Y))) (VALUES (IF (= 0 R) Q (1+ Q)) (- R Y))))) NIL T T
:pinfo DECODE-FLOAT (X) NIL (FLOAT) NIL NIL NIL NIL T
:pinfo FLOAT-1 (N) NIL NIL NIL NIL NIL NIL T
:pinfo LDB-1 (SIZE POSITION N) NIL NIL NIL NIL NIL NIL T
:pinfo MIN/2 (X Y) NIL NIL NIL (LAMBDA (X Y) (DECLARE) (BLOCK MIN/2 (IF (< X Y) X Y))) NIL T T
:pinfo BYTE (SIZE POSITION) NIL NIL NIL (LAMBDA (SIZE POSITION) (DECLARE) (BLOCK BYTE (MAKE-BYTE :SIZE SIZE :POSITION POSITION))) NIL T T
:pinfo DPB (VALUE BYTE-SPEC N) NIL (INTEGER BYTE-SPECIFIER INTEGER) NIL NIL NIL NIL T
:pinfo <= (&RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo EXPT/FLOAT (N POWER) NIL NIL NIL NIL NIL NIL T
:pinfo LCM/2 (N M) NIL NIL NIL NIL NIL NIL T
:pinfo ENSURE-FIXNUM (N) NIL NIL NIL NIL NIL NIL T
:pinfo SIN (X) NIL NIL NIL (LAMBDA (X) (DECLARE) (BLOCK SIN (DOUBLE_SIN (FLOAT X)))) NIL T T
:pinfo TRUNCATE/2 (N DIVISOR) NIL NIL NIL NIL NIL NIL T
:pinfo BOOLE (OP I1 I2) NIL NIL NIL NIL NIL NIL T
:pinfo EXP (N) NIL NIL NIL (LAMBDA (N) (DECLARE) (BLOCK EXP (DOUBLE_EXP (FLOAT N)))) NIL T T
:pinfo INTEGER-DECODE-FLOAT (X) NIL (FLOAT) NIL NIL NIL NIL T
:pinfo EVENP (INTEGER) NIL NIL NIL NIL NIL NIL T
:pinfo MOD (X Y) NIL NIL NIL NIL NIL NIL T
:pinfo LOGAND/2 (X Y) NIL (INTEGER INTEGER) NIL NIL NIL NIL T
:pinfo TAN (X) NIL NIL NIL NIL NIL NIL T
:pinfo SQRT (X) NIL NIL NIL NIL NIL NIL T
:pinfo BIGNUM-DIV (X Y) NIL NIL NIL NIL NIL NIL T
:pinfo INTEGER-LENGTH (N) NIL (INTEGER) NIL NIL NIL NIL T
:pinfo RATIONALIZE (N) NIL NIL NIL NIL NIL NIL T
:pinfo LDB (BYTE-SPEC N) NIL (BYTE-SPECIFIER INTEGER) NIL NIL NIL NIL T
:pinfo CEILING/FLOAT (X Y) NIL NIL NIL (LAMBDA (X Y) (DECLARE) (BLOCK CEILING/FLOAT (VALUES (DOUBLE_TRUNCATE (CEIL (/ X Y)) 1.0) (- (FMOD X Y) Y)))) NIL T T
:pinfo CEILING (X &OPTIONAL (Y 1)) NIL NIL NIL NIL NIL NIL T
:pinfo DPB/FIXNUM (VALUE SIZE POSITION N) NIL NIL NIL NIL NIL NIL T
:pinfo FLOAT (N &OPTIONAL OTHER) NIL NIL NIL (LAMBDA (N &OPTIONAL OTHER) (DECLARE) (BLOCK FLOAT (FLOAT-1 N))) NIL T T
:pinfo FFLOOR (X &OPTIONAL (Y 1.0)) NIL NIL NIL NIL NIL NIL T
:pinfo PLUSP (N) NIL NIL NIL (LAMBDA (N) (DECLARE) (BLOCK PLUSP (> N 0))) NIL T T
:pinfo ROUND/2 (NUMBER DIVISOR) NIL NIL NIL NIL NIL NIL T
:pinfo LDB-TEST (BYTE-SPEC N) NIL NIL NIL NIL NIL NIL T
:pinfo ATAN/2 (Y X) NIL NIL NIL NIL NIL NIL T
:pinfo ODDP (INTEGER) NIL NIL NIL NIL NIL NIL T
:pinfo LOGXOR (ARG-1 &RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo LCM (&RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo ABS (N) NIL NIL NIL NIL NIL NIL T
:pinfo EXPT (N POWER) NIL NIL NIL NIL NIL NIL T
:pinfo EXPT/FIXNUM (N POWER) NIL NIL NIL NIL NIL NIL T
:pinfo TRUNCATE-FLOAT/2 (N DIVISOR) NIL NIL NIL NIL NIL NIL T
:pinfo LOGANDC1 (I1 I2) NIL NIL NIL NIL NIL NIL T
:pinfo ENSURE-BIGNUM (X) NIL NIL NIL NIL NIL NIL T
:pinfo LOGANDC2 (I1 I2) NIL NIL NIL NIL NIL NIL T
:pinfo 1+ (X) NIL NIL NIL (LAMBDA (X) (DECLARE) (BLOCK 1+ (+ X 1))) NIL T T
:pinfo FLOOR/1V (X &OPTIONAL (Y 1)) NIL NIL NIL NIL NIL NIL T
:pinfo LOG/10 (N) NIL NIL NIL (LAMBDA (N) (DECLARE) (BLOCK LOG/10 (DOUBLE_LOG10 (FLOAT N)))) NIL T T
:pinfo MIN (ARG-1 &RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo 1- (X) NIL NIL NIL (LAMBDA (X) (DECLARE) (BLOCK 1- (- X 1))) NIL T T
:pinfo MAKE-COMPLEX (REALPART IMAGPART) NIL NIL NIL NIL NIL NIL T
:pinfo RATIONAL (N) NIL NIL NIL NIL NIL NIL T
:pinfo MINUSP (N) NIL NIL NIL (LAMBDA (N) (DECLARE) (BLOCK MINUSP (< N 0))) NIL T T
:end
*/

#include "lisp.h"

extern LP p_lsp_ABS();
extern SYMBOL s_lsp_PLUSP; 
extern LP p_lsp_ACOS();
extern SYMBOL s_lsp_FLOAT; 
extern LP p_lsp_ARITH_2DERROR();
MAKE_SIMPLE_STRING(k2396,18,"~S is not a number");
extern SYMBOL s_lsp_NUMBERP; 
extern SYMBOL s_lsp_ERROR; 
extern LP p_lsp_ASH();
extern SYMBOL s_lsp_INTEGERP; 
extern SYMBOL s_lsp_INTEGER; 
extern SYMBOL s_lsp_WTA; 
extern SYMBOL s_lsp_FIXNUMP; 
extern SYMBOL s_lsp_FIXNUM; 
extern SYMBOL s_lsp_ABS; 
extern SYMBOL s_lsp_TRUNCATE; 
extern LP p_lsp_ASIN();
extern LP p_lsp_ATAN_2F2();
extern LP p_lsp_ATAN();
extern SYMBOL s_lsp_ATAN_2F2; 
extern LP p_lsp_BIGNUM_2DDIV();
extern SYMBOL s_lsp_ENSURE_2DBIGNUM; 
extern LP p_lsp_BIGNUM_2DREM();
extern LP p_lsp_BOOLE();
extern SYMBOL s_lsp_EQL; 
extern SYMBOL s_lsp_LOGNOT; 
extern SYMBOL s_lsp_LOGAND_2F2; 
extern SYMBOL s_lsp_LOGIOR_2F2; 
extern SYMBOL s_lsp_LOGXOR; 
extern SYMBOL s_lsp_LOGEQV; 
extern SYMBOL s_lsp_LOGNAND; 
extern SYMBOL s_lsp_LOGNOR; 
extern SYMBOL s_lsp_LOGANDC1; 
extern SYMBOL s_lsp_LOGANDC2; 
extern SYMBOL s_lsp_LOGORC1; 
extern SYMBOL s_lsp_LOGORC2; 
extern SYMBOL s_lsp_NIL; 
extern LP p_lsp_WRITE_2DBYTE_2DSPECIFIER();
MAKE_SIMPLE_STRING(k2397,12,"(BYTE ~D ~D)");
extern SYMBOL s_lsp_FORMAT; 
extern LP p_lsp_BYTE();
extern SYMBOL s_lsp_MAKE_2DBYTE_2F2; 
extern LP p_lsp_LDB();
extern SYMBOL s_lsp_BYTE_2DP; 
extern SYMBOL s_lsp_BYTE_2DSPECIFIER; 
extern SYMBOL s_lsp_LDB_2D1; 
extern LP p_lsp_LDB_2D1();
extern SYMBOL s_lsp_LDB_2FFIXNUM; 
extern SYMBOL s_lsp_LDB_2FBIGNUM; 
MAKE_SIMPLE_STRING(k2398,36,"~S is not one of these types:~{ ~A~}");
extern SYMBOL s_lsp_BIGNUM; 
MAKE_CONS(k2400,LREF(s_lsp_BIGNUM),LREF(s_lsp_NIL));
MAKE_CONS(k2399,LREF(s_lsp_FIXNUM),LREF(k2400));
extern LP p_lsp_LDB_2FFIXNUM();
extern LP p_lsp_LDB_2FBIGNUM();
extern SYMBOL s_lsp_ASH; 
extern LP p_lsp_DPB();
extern SYMBOL s_lsp_DPB_2D1; 
extern LP p_lsp_DPB_2D1();
extern SYMBOL s_lsp_DPB_2FFIXNUM; 
extern SYMBOL s_lsp_DPB_2FBIGNUM; 
extern LP p_lsp_DPB_2FFIXNUM();
extern LP p_lsp_DPB_2FBIGNUM();
extern SYMBOL s_lsp_MASK_2DFIELD_2D1; 
extern LP p_lsp_LDB_2DTEST();
extern SYMBOL s_lsp_LDB; 
extern SYMBOL s_lsp_NOT; 
extern LP p_lsp_MASK_2DFIELD();
extern LP p_lsp_MASK_2DFIELD_2D1();
extern LP p_lsp_DEPOSIT_2DFIELD();
extern SYMBOL s_lsp_DPB; 
extern LP p_lsp_CEILING_2FFIXNUM();
extern SYMBOL s_lsp_1_2B; 
extern LP p_lsp_CEILING_2FFLOAT();
MAKE_FLOAT(k2401,1.0);
extern LP p_lsp_CEILING();
extern LP p_lsp_COMPLEX();
extern SYMBOL s_lsp_MAKE_2DCOMPLEX; 
extern LP p_lsp_MAKE_2DCOMPLEX();
extern LP p_lsp_COS();
extern LP p_lsp_DECODE_2DFLOAT();
extern SYMBOL s_lsp_FLOATP; 
MAKE_FLOAT(k2402,-1.0);
extern LP p_lsp_INTEGER_2DDECODE_2DFLOAT();
MAKE_SIMPLE_STRING(k2403,27,"write integer-decode-float!");
extern LP p_lsp__2F();
extern SYMBOL s_lsp_LENGTH; 
extern SYMBOL s_lsp_T; 
extern LP p_lsp_ENSURE_2DBIGNUM();
extern LP p_lsp_ENSURE_2DFIXNUM();
MAKE_CONS(k2404,LREF(s_lsp_FIXNUM),LREF(s_lsp_NIL));
extern LP p_lsp_EVENP();
extern SYMBOL s_lsp_REM; 
extern SYMBOL s_lsp_ZEROP; 
extern LP p_lsp_EXP();
extern LP p_lsp_EXPT();
extern SYMBOL s_lsp_EXPT_2FFIXNUM; 
extern SYMBOL s_lsp_EXPT_2FFLOAT; 
extern LP p_lsp_EXPT_2FFIXNUM();
extern LP p_lsp_EXPT_2FFLOAT();
extern LP p_lsp_FFLOOR();
extern LP p_lsp_FLOAT_2DRADIX();
extern LP p_lsp_FLOAT();
extern SYMBOL s_lsp_FLOAT_2D1; 
extern LP p_lsp_FLOAT_2D1();
extern SYMBOL s_lsp_NUMERATOR; 
extern SYMBOL s_lsp_DENOMINATOR; 
MAKE_SIMPLE_STRING(k2405,18,"~A is not a number");
extern LP p_lsp_FLOOR_2FFIXNUM();
extern LP p_lsp_FLOOR_2FFLOAT();
extern LP p_lsp_FLOOR();
extern LP p_lsp_FLOOR_2F1V();
extern SYMBOL s_lsp_FLOOR; 
extern LP p_lsp_GCD_2F2();
extern LP p_lsp_GCD();
extern SYMBOL s_lsp_GCD_2F2; 
extern LP p_lsp__3E_3D();
MAKE_CONS(k2408,(LP) 2,LREF(s_lsp_NIL));
MAKE_CONS(k2407,(LP) 0,LREF(k2408));
extern SYMBOL s_lsp_MEMQL; 
extern LP p_lsp__3E();
extern LP p_lsp_IMAGPART();
extern SYMBOL s_lsp_COMPLEXP; 
extern SYMBOL s_lsp_COMPLEX; 
extern LP p_lsp_INTEGER_2DLENGTH();
MAKE_SIMPLE_STRING(k2409,32,"write integer-length for bignums");
extern LP p_lsp_LCM_2F2();
extern SYMBOL s_lsp_MAX; 
extern SYMBOL s_lsp_GCD; 
extern SYMBOL s_lsp_MIN; 
extern LP p_lsp_LCM();
extern SYMBOL s_lsp_LCM_2F2; 
extern LP p_lsp__3C_3D();
extern LP p_lsp__3C();
extern LP p_lsp_LOG_2F10();
extern LP p_lsp_LOG_2FE();
extern LP p_lsp_LOG();
extern SYMBOL s_lsp_LOG_2FE; 
extern LP p_lsp_LOGAND_2F2();
MAKE_SIMPLE_STRING(k2410,24,"Fix LOGAND/2 for bignums");
extern LP p_lsp_LOGAND();
extern LP p_lsp_LOGANDC1();
extern LP p_lsp_LOGANDC2();
extern LP p_lsp_LOGEQV_2F2();
MAKE_SIMPLE_STRING(k2411,12,"write LOGEQV");
extern LP p_lsp_LOGEQV();
extern SYMBOL s_lsp_LOGEQV_2F2; 
extern LP p_lsp_LOGIOR_2F2();
extern LP p_lsp_LOGIOR();
extern LP p_lsp_LOGNAND();
extern LP p_lsp_LOGNOR();
extern LP p_lsp_LOGNOT();
extern LP p_lsp_LOGBITP();
extern SYMBOL s_lsp_LDB_2DTEST; 
extern LP p_lsp_LOGTEST();
extern LP p_lsp_LOGORC1();
extern LP p_lsp_LOGORC2();
extern LP p_lsp_LOGXOR_2F2();
extern LP p_lsp_LOGXOR();
extern LP p_lsp_MAKE_2DRATIO();
MAKE_SIMPLE_STRING(k2412,25,"Cannot divide by 0: ~A/~A");
extern LP p_lsp_MAX_2F2();
extern LP p_lsp_MAX();
extern LP p_lsp_MIN_2F2();
extern LP p_lsp_MIN();
extern LP p_lsp__2D();
extern LP p_lsp_MINUSP();
extern LP p_lsp_MOD();
extern LP p_lsp__3D();
extern LP p_lsp_NUM_2DNOT_2DEQUAL_2DP();
extern LP p_lsp__2F_3D();
extern SYMBOL s_lsp_NUM_2DNOT_2DEQUAL_2DP; 
extern LP p_lsp_NUMERATOR();
extern SYMBOL s_lsp_RATIOP; 
extern SYMBOL s_lsp_RATIO; 
extern LP p_lsp_DENOMINATOR();
extern LP p_lsp_ODDP();
extern SYMBOL s_lsp_EVENP; 
extern LP p_lsp_1_2D();
extern LP p_lsp_1_2B();
extern LP p_lsp__2B();
extern LP p_lsp_PLUSP();
extern LP p_lsp_RATIONALIZE();
extern SYMBOL s_lsp_RATIONAL; 
extern LP p_lsp_RATIONAL();
extern SYMBOL s_lsp__2A; 
extern SYMBOL s_lsp_INTEGER_2DRANGE_2DP; 
extern SYMBOL s_lsp_RATIONAL_2FFLOAT; 
MAKE_SIMPLE_STRING(k2413,48,"~A should be a rational or floating point number");
extern LP p_lsp_RATIONAL_2FFLOAT();
MAKE_SIMPLE_STRING(k2415,41,"rational/float: FIX ME! ~A converts to ~A");
extern SYMBOL s_lsp_WARN; 
extern LP p_lsp_REALPART();
extern LP p_lsp_REM();
extern LP p_lsp_ROUND_2F2();
extern SYMBOL s_lsp_ODDP; 
extern LP p_lsp_ROUND();
extern SYMBOL s_lsp_ROUND_2F2; 
extern LP p_lsp_SCALE_2DFLOAT();
extern LP p_lsp_SIGNUM();
extern SYMBOL s_lsp_RATIONALP; 
extern LP p_lsp_SIN();
extern LP p_lsp_SQRT();
extern LP p_lsp_TAN();
extern LP p_lsp__2A();
extern LP p_lsp_TRUNCATE();
extern SYMBOL s_lsp_TRUNCATE_2F2; 
extern LP p_lsp_TRUNCATE_2F2();
extern SYMBOL s_lsp_TRUNCATE_2DFLOAT_2F2; 
MAKE_CONS(k2419,LREF(s_lsp_RATIO),LREF(s_lsp_NIL));
MAKE_CONS(k2418,LREF(s_lsp_FLOAT),LREF(k2419));
MAKE_CONS(k2417,LREF(s_lsp_FIXNUM),LREF(k2418));
extern SYMBOL s_lsp_BIGNUM_2DDIV; 
extern SYMBOL s_lsp_BIGNUM_2DREM; 
MAKE_CONS(k2421,LREF(s_lsp_FLOAT),LREF(s_lsp_NIL));
MAKE_CONS(k2420,LREF(s_lsp_INTEGER),LREF(k2421));
MAKE_CONS(k2423,LREF(s_lsp_BIGNUM),LREF(k2421));
MAKE_CONS(k2422,LREF(s_lsp_FIXNUM),LREF(k2423));
extern LP p_lsp_TRUNCATE_2DFLOAT_2F2();
extern LP p_lsp_ZEROP();


extern double tan();
extern double sqrt();
extern double sin();
extern double ldexp();
extern double log();
extern double log10();
extern LP leq_p();
extern int int_length();
extern LP add();
extern LP greaterp();
extern double bignum_to_double();
extern double floor();
extern double pow();
extern LP geq_p();
extern double exp();
extern LP fixnum_to_bignum();
extern LP lessp();
extern int float_exponent();
extern double float_significand();
extern double cos();
extern LP alloc_words();
extern double fmod();
extern int double_truncate();
extern double ceil();
extern LP divide();
extern LP num_equal_p();
extern LP bignum_rem();
extern LP bignum_div();
extern double atan2();
extern double asin();
extern LP multiply();
extern double acos();
extern LP subtract();


LP p_lsp_ABS(argc, v_N_0)
      ARGC argc;  LP v_N_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_PLUSP) (1, v_N_0);
if (t1 != NIL) {
return(v_N_0);
} else {
t0 = (subtract(((LP) 0), (v_N_0)));
return(t0);
}
}

LP p_lsp_ACOS(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_FLOAT) (1, v_X_0);
t0 = NEW_FLOAT(acos(RAW_FLOAT(t1)));
return(t0);
}

LP p_lsp_ARITH_2DERROR(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 2) wna(argc,2);
t2 = ICALL(s_lsp_NUMBERP) (1, v_X_0);
if (t2 != NIL) {
t1 = v_Y_1;
} else {
t1 = v_X_0;
}
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,2), LREF(k2396), t1);
return(t0);
}

LP p_lsp_ASH(argc, v_N_0, v_COUNT_1)
      ARGC argc;  LP v_N_0; LP v_COUNT_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_INTEGERP) (1, v_N_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_N_0, LREF(s_lsp_INTEGER), (LP) 0);
}
t1 = ICALL(s_lsp_FIXNUMP) (1, v_COUNT_1);
if (t1 == NIL) {
ICALL(s_lsp_WTA) (3, v_COUNT_1, LREF(s_lsp_FIXNUM), (LP) 0);
}
t3 = ICALL(s_lsp_PLUSP) (1, v_COUNT_1);
if (t3 != NIL) {
t4 = INT_TO_FX(((unsigned long) (1) << FX_TO_INT(v_COUNT_1)));
t2 = (multiply((v_N_0), (t4)));
return(t2);
} else {
t7 = ICALL(s_lsp_ABS) (1, v_COUNT_1);
t6 = INT_TO_FX(((unsigned long) (1) << FX_TO_INT(t7)));
t5 = ICALL(s_lsp_TRUNCATE) (2, v_N_0, t6);
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,1);
}
return(t5);
}
}

LP p_lsp_ASIN(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_FLOAT) (1, v_X_0);
t0 = NEW_FLOAT(asin(RAW_FLOAT(t1)));
return(t0);
}

LP p_lsp_ATAN_2F2(argc, v_Y_0, v_X_1)
      ARGC argc;  LP v_Y_0; LP v_X_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 2) wna(argc,2);
t1 = ICALL(s_lsp_FLOAT) (1, v_Y_0);
t2 = ICALL(s_lsp_FLOAT) (1, v_X_1);
t0 = NEW_FLOAT(atan2(RAW_FLOAT(t1), RAW_FLOAT(t2)));
return(t0);
}

LP p_lsp_ATAN(va_alist) va_dcl
{
LP v_Y_0; LP v_X_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_Y_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_X_1 = (LP) 0;
} else {
v_X_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t0 = ICALL(s_lsp_ATAN_2F2) (MV_CALL(argc,2), v_Y_0, v_X_1);
return(t0);
}

LP p_lsp_BIGNUM_2DDIV(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 2) wna(argc,2);
t1 = ICALL(s_lsp_ENSURE_2DBIGNUM) (1, v_X_0);
t2 = ICALL(s_lsp_ENSURE_2DBIGNUM) (1, v_Y_1);
t0 = (bignum_div((t1), (t2)));
return(t0);
}

LP p_lsp_BIGNUM_2DREM(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 2) wna(argc,2);
t1 = ICALL(s_lsp_ENSURE_2DBIGNUM) (1, v_X_0);
t2 = ICALL(s_lsp_ENSURE_2DBIGNUM) (1, v_Y_1);
t0 = (bignum_rem((t1), (t2)));
return(t0);
}

LP p_lsp_BOOLE(argc, v_OP_0, v_I1_1, v_I2_2)
      ARGC argc;  LP v_OP_0; LP v_I1_1; LP v_I2_2;
{
LP v_KEY3696_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; 
if (argc != 3) wna(argc,3);
v_KEY3696_4 = v_OP_0;
t1 = ICALL(s_lsp_EQL) (2, v_KEY3696_4, (LP) 0);
if (t1 != NIL) {
return((LP) 0);
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY3696_4, (LP) 2);
if (t2 != NIL) {
return((LP) 2);
} else {
t3 = ICALL(s_lsp_EQL) (2, v_KEY3696_4, (LP) 4);
if (t3 != NIL) {
return(v_I1_1);
} else {
t4 = ICALL(s_lsp_EQL) (2, v_KEY3696_4, (LP) 6);
if (t4 != NIL) {
return(v_I2_2);
} else {
t5 = ICALL(s_lsp_EQL) (2, v_KEY3696_4, (LP) 8);
if (t5 != NIL) {
t0 = ICALL(s_lsp_LOGNOT) (MV_CALL(argc,1), v_I1_1);
return(t0);
} else {
t6 = ICALL(s_lsp_EQL) (2, v_KEY3696_4, (LP) 10);
if (t6 != NIL) {
t0 = ICALL(s_lsp_LOGNOT) (MV_CALL(argc,1), v_I2_2);
return(t0);
} else {
t7 = ICALL(s_lsp_EQL) (2, v_KEY3696_4, (LP) 12);
if (t7 != NIL) {
t0 = ICALL(s_lsp_LOGAND_2F2) (MV_CALL(argc,2), v_I1_1, v_I2_2);
return(t0);
} else {
t8 = ICALL(s_lsp_EQL) (2, v_KEY3696_4, (LP) 14);
if (t8 != NIL) {
t0 = ICALL(s_lsp_LOGIOR_2F2) (MV_CALL(argc,2), v_I1_1, v_I2_2);
return(t0);
} else {
t9 = ICALL(s_lsp_EQL) (2, v_KEY3696_4, (LP) 16);
if (t9 != NIL) {
t0 = ICALL(s_lsp_LOGXOR) (MV_CALL(argc,2), v_I1_1, v_I2_2);
return(t0);
} else {
t10 = ICALL(s_lsp_EQL) (2, v_KEY3696_4, (LP) 18);
if (t10 != NIL) {
t0 = ICALL(s_lsp_LOGEQV) (MV_CALL(argc,2), v_I1_1, v_I2_2);
return(t0);
} else {
t11 = ICALL(s_lsp_EQL) (2, v_KEY3696_4, (LP) 20);
if (t11 != NIL) {
t0 = ICALL(s_lsp_LOGNAND) (MV_CALL(argc,2), v_I1_1, v_I2_2);
return(t0);
} else {
t12 = ICALL(s_lsp_EQL) (2, v_KEY3696_4, (LP) 22);
if (t12 != NIL) {
t0 = ICALL(s_lsp_LOGNOR) (MV_CALL(argc,2), v_I1_1, v_I2_2);
return(t0);
} else {
t13 = ICALL(s_lsp_EQL) (2, v_KEY3696_4, (LP) 24);
if (t13 != NIL) {
t0 = ICALL(s_lsp_LOGANDC1) (MV_CALL(argc,2), v_I1_1, v_I2_2);
return(t0);
} else {
t14 = ICALL(s_lsp_EQL) (2, v_KEY3696_4, (LP) 26);
if (t14 != NIL) {
t0 = ICALL(s_lsp_LOGANDC2) (MV_CALL(argc,2), v_I1_1, v_I2_2);
return(t0);
} else {
t15 = ICALL(s_lsp_EQL) (2, v_KEY3696_4, (LP) 28);
if (t15 != NIL) {
t0 = ICALL(s_lsp_LOGORC1) (MV_CALL(argc,2), v_I1_1, v_I2_2);
return(t0);
} else {
t16 = ICALL(s_lsp_EQL) (2, v_KEY3696_4, (LP) 30);
if (t16 != NIL) {
t0 = ICALL(s_lsp_LOGORC2) (MV_CALL(argc,2), v_I1_1, v_I2_2);
return(t0);
} else {
return(LREF(s_lsp_NIL));
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}
}

LP p_lsp_WRITE_2DBYTE_2DSPECIFIER(argc, v_BYTE_2DSPEC_0, v_STREAM_1, v_DEPTH_2)
      ARGC argc;  LP v_BYTE_2DSPEC_0; LP v_STREAM_1; LP v_DEPTH_2;
{
LP v_I_12; LP v_S_11; LP v_S_9; 
LP v_I_7; LP v_S_6; LP v_S_4; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; 
if (argc != 3) wna(argc,3);
v_S_4 = v_BYTE_2DSPEC_0;
v_S_6 = v_BYTE_2DSPEC_0;
v_I_7 = (LP) 2;
t1 = ((LP) DEREF((v_BYTE_2DSPEC_0) + 1 * 4));
v_S_9 = v_BYTE_2DSPEC_0;
v_S_11 = v_BYTE_2DSPEC_0;
v_I_12 = (LP) 4;
t2 = ((LP) DEREF((v_BYTE_2DSPEC_0) + 2 * 4));
t0 = ICALL(s_lsp_FORMAT) (MV_CALL(argc,4), v_STREAM_1, LREF(k2397), t1, t2);
return(t0);
}

LP p_lsp_BYTE(argc, v_SIZE_0, v_POSITION_1)
      ARGC argc;  LP v_SIZE_0; LP v_POSITION_1;
{
LP v_POSITION_6; LP v_SIZE_5; LP v_POSITION_4; 
LP v_SIZE_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
v_SIZE_5 = v_SIZE_0;
v_POSITION_6 = v_POSITION_1;
t0 = ICALL(s_lsp_MAKE_2DBYTE_2F2) (MV_CALL(argc,2), v_SIZE_0, v_POSITION_1);
return(t0);
}

LP p_lsp_LDB(argc, v_BYTE_2DSPEC_0, v_N_1)
      ARGC argc;  LP v_BYTE_2DSPEC_0; LP v_N_1;
{
LP v_I_11; LP v_S_10; LP v_S_8; 
LP v_I_6; LP v_S_5; LP v_S_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_BYTE_2DP) (1, v_BYTE_2DSPEC_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_BYTE_2DSPEC_0, LREF(s_lsp_BYTE_2DSPECIFIER), (LP) 0);
}
t1 = ICALL(s_lsp_INTEGERP) (1, v_N_1);
if (t1 == NIL) {
ICALL(s_lsp_WTA) (3, v_N_1, LREF(s_lsp_INTEGER), (LP) 0);
}
v_S_3 = v_BYTE_2DSPEC_0;
v_S_5 = v_BYTE_2DSPEC_0;
v_I_6 = (LP) 2;
t3 = ((LP) DEREF((v_BYTE_2DSPEC_0) + 1 * 4));
v_S_8 = v_BYTE_2DSPEC_0;
v_S_10 = v_BYTE_2DSPEC_0;
v_I_11 = (LP) 4;
t4 = ((LP) DEREF((v_BYTE_2DSPEC_0) + 2 * 4));
t2 = ICALL(s_lsp_LDB_2D1) (MV_CALL(argc,3), t3, t4, v_N_1);
return(t2);
}

LP p_lsp_LDB_2D1(argc, v_SIZE_0, v_POSITION_1, v_N_2)
      ARGC argc;  LP v_SIZE_0; LP v_POSITION_1; LP v_N_2;
{
LP v_KEY3700_6; LP v_KEY3697_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 3) wna(argc,3);
v_KEY3697_4 = v_N_2;
v_KEY3700_6 = v_KEY3697_4;
t2 = ICALL(s_lsp_FIXNUMP) (1, v_KEY3700_6);
if (t2 != NIL) {
t1 = ICALL(s_lsp_LDB_2FFIXNUM) (MV_CALL(argc,3), v_SIZE_0, v_POSITION_1, v_N_2);
return(t1);
} else {
t3 = INT_TO_FX(((int) TAG((v_KEY3700_6))));
switch ((int) t3) {
case 2:
t1 = ICALL(s_lsp_LDB_2FBIGNUM) (MV_CALL(argc,3), v_SIZE_0, v_POSITION_1, v_N_2);
return(t1);
break;
default:
goto t_DEFAULT_2DTAG3699_7;
break;
}
}
return(t1);
t_DEFAULT_2DTAG3699_7:;
t4 = ICALL(s_lsp_ERROR) (MV_CALL(argc,3), LREF(k2398), v_KEY3697_4, LREF(k2399));
return(t4);
return(NIL);
return(NIL);
}

LP p_lsp_LDB_2FFIXNUM(argc, v_SIZE_0, v_POSITION_1, v_N_2)
      ARGC argc;  LP v_SIZE_0; LP v_POSITION_1; LP v_N_2;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 3) wna(argc,3);
t1 = INT_TO_FX(((1 << FX_TO_INT(v_SIZE_0)) - 1));
t0 = INT_TO_FX((((int) FX_TO_INT(v_N_2) >> (int) FX_TO_INT(v_POSITION_1) ) & (int) FX_TO_INT(t1)));
return(t0);
}

LP p_lsp_LDB_2FBIGNUM(argc, v_SIZE_0, v_POSITION_1, v_N_2)
      ARGC argc;  LP v_SIZE_0; LP v_POSITION_1; LP v_N_2;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; 
if (argc != 3) wna(argc,3);
t2 = (subtract(((LP) 0), (v_POSITION_1)));
t1 = ICALL(s_lsp_ASH) (2, v_N_2, t2);
t4 = ICALL(s_lsp_ASH) (2, (LP) 2, v_SIZE_0);
t3 = (subtract(((LP) 0), (t4)));
t0 = ICALL(s_lsp_LOGANDC2) (MV_CALL(argc,2), t1, t3);
return(t0);
}

LP p_lsp_DPB(argc, v_VALUE_0, v_BYTE_2DSPEC_1, v_N_2)
      ARGC argc;  LP v_VALUE_0; LP v_BYTE_2DSPEC_1; LP v_N_2;
{
LP v_I_12; LP v_S_11; LP v_S_9; 
LP v_I_7; LP v_S_6; LP v_S_4; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; 
if (argc != 3) wna(argc,3);
t0 = ICALL(s_lsp_INTEGERP) (1, v_VALUE_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_VALUE_0, LREF(s_lsp_INTEGER), (LP) 0);
}
t1 = ICALL(s_lsp_BYTE_2DP) (1, v_BYTE_2DSPEC_1);
if (t1 == NIL) {
ICALL(s_lsp_WTA) (3, v_BYTE_2DSPEC_1, LREF(s_lsp_BYTE_2DSPECIFIER), (LP) 0);
}
t2 = ICALL(s_lsp_INTEGERP) (1, v_N_2);
if (t2 == NIL) {
ICALL(s_lsp_WTA) (3, v_N_2, LREF(s_lsp_INTEGER), (LP) 0);
}
v_S_4 = v_BYTE_2DSPEC_1;
v_S_6 = v_BYTE_2DSPEC_1;
v_I_7 = (LP) 2;
t4 = ((LP) DEREF((v_BYTE_2DSPEC_1) + 1 * 4));
v_S_9 = v_BYTE_2DSPEC_1;
v_S_11 = v_BYTE_2DSPEC_1;
v_I_12 = (LP) 4;
t5 = ((LP) DEREF((v_BYTE_2DSPEC_1) + 2 * 4));
t3 = ICALL(s_lsp_DPB_2D1) (MV_CALL(argc,4), v_VALUE_0, t4, t5, v_N_2);
return(t3);
}

LP p_lsp_DPB_2D1(argc, v_VALUE_0, v_SIZE_1, v_POSITION_2, v_N_3)
      ARGC argc;  LP v_VALUE_0; LP v_SIZE_1; LP v_POSITION_2; LP v_N_3;
{
LP v_KEY3704_7; LP v_KEY3701_5; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 4) wna(argc,4);
v_KEY3701_5 = v_N_3;
v_KEY3704_7 = v_KEY3701_5;
t2 = ICALL(s_lsp_FIXNUMP) (1, v_KEY3704_7);
if (t2 != NIL) {
t1 = ICALL(s_lsp_DPB_2FFIXNUM) (MV_CALL(argc,4), v_VALUE_0, v_SIZE_1, v_POSITION_2, v_N_3);
return(t1);
} else {
t3 = INT_TO_FX(((int) TAG((v_KEY3704_7))));
switch ((int) t3) {
case 2:
t1 = ICALL(s_lsp_DPB_2FBIGNUM) (MV_CALL(argc,4), v_VALUE_0, v_SIZE_1, v_POSITION_2, v_N_3);
return(t1);
break;
default:
goto t_DEFAULT_2DTAG3703_8;
break;
}
}
return(t1);
t_DEFAULT_2DTAG3703_8:;
t4 = ICALL(s_lsp_ERROR) (MV_CALL(argc,3), LREF(k2398), v_KEY3701_5, LREF(k2399));
return(t4);
return(NIL);
return(NIL);
}

LP p_lsp_DPB_2FFIXNUM(argc, v_VALUE_0, v_SIZE_1, v_POSITION_2, v_N_3)
      ARGC argc;  LP v_VALUE_0; LP v_SIZE_1; LP v_POSITION_2; LP v_N_3;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 4) wna(argc,4);
t0 = ICALL(s_lsp_DPB_2FBIGNUM) (MV_CALL(argc,4), v_VALUE_0, v_SIZE_1, v_POSITION_2, v_N_3);
return(t0);
}

LP p_lsp_DPB_2FBIGNUM(argc, v_VALUE_0, v_SIZE_1, v_POSITION_2, v_N_3)
      ARGC argc;  LP v_VALUE_0; LP v_SIZE_1; LP v_POSITION_2; LP v_N_3;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 4) wna(argc,4);
t1 = ICALL(s_lsp_MASK_2DFIELD_2D1) (3, v_SIZE_1, v_POSITION_2, v_N_3);
t5 = ICALL(s_lsp_ASH) (2, (LP) 2, v_SIZE_1);
t4 = (subtract(((LP) 0), (t5)));
t3 = ICALL(s_lsp_LOGANDC2) (2, v_VALUE_0, t4);
t2 = ICALL(s_lsp_ASH) (2, t3, v_POSITION_2);
t0 = ICALL(s_lsp_LOGXOR) (MV_CALL(argc,3), v_N_3, t1, t2);
return(t0);
}

LP p_lsp_LDB_2DTEST(argc, v_BYTE_2DSPEC_0, v_N_1)
      ARGC argc;  LP v_BYTE_2DSPEC_0; LP v_N_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 2) wna(argc,2);
t2 = ICALL(s_lsp_LDB) (2, v_BYTE_2DSPEC_0, v_N_1);
t1 = (num_equal_p((t2), ((LP) 0)));
t0 = ICALL(s_lsp_NOT) (MV_CALL(argc,1), t1);
return(t0);
}

LP p_lsp_MASK_2DFIELD(argc, v_BYTE_2DSPEC_0, v_N_1)
      ARGC argc;  LP v_BYTE_2DSPEC_0; LP v_N_1;
{
LP v_I_11; LP v_S_10; LP v_S_8; 
LP v_I_6; LP v_S_5; LP v_S_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; 
if (argc != 2) wna(argc,2);
v_S_3 = v_BYTE_2DSPEC_0;
v_S_5 = v_BYTE_2DSPEC_0;
v_I_6 = (LP) 2;
t1 = ((LP) DEREF((v_BYTE_2DSPEC_0) + 1 * 4));
v_S_8 = v_BYTE_2DSPEC_0;
v_S_10 = v_BYTE_2DSPEC_0;
v_I_11 = (LP) 4;
t2 = ((LP) DEREF((v_BYTE_2DSPEC_0) + 2 * 4));
t0 = ICALL(s_lsp_MASK_2DFIELD_2D1) (MV_CALL(argc,2), t1, t2);
return(t0);
}

LP p_lsp_MASK_2DFIELD_2D1(argc, v_SIZE_0, v_POSITION_1, v_N_2)
      ARGC argc;  LP v_SIZE_0; LP v_POSITION_1; LP v_N_2;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 3) wna(argc,3);
t1 = ICALL(s_lsp_LDB_2D1) (3, v_SIZE_0, v_POSITION_1, v_N_2);
t0 = ICALL(s_lsp_ASH) (MV_CALL(argc,2), t1, v_POSITION_1);
return(t0);
}

LP p_lsp_DEPOSIT_2DFIELD(argc, v_VALUE_0, v_BYTE_2DSPEC_1, v_N_2)
      ARGC argc;  LP v_VALUE_0; LP v_BYTE_2DSPEC_1; LP v_N_2;
{
LP v_I_7; LP v_S_6; LP v_S_4; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 3) wna(argc,3);
v_S_4 = v_BYTE_2DSPEC_1;
v_S_6 = v_BYTE_2DSPEC_1;
v_I_7 = (LP) 4;
t3 = ((LP) DEREF((v_BYTE_2DSPEC_1) + 2 * 4));
t2 = (subtract(((LP) 0), (t3)));
t1 = ICALL(s_lsp_ASH) (2, v_VALUE_0, t2);
t0 = ICALL(s_lsp_DPB) (MV_CALL(argc,3), t1, v_BYTE_2DSPEC_1, v_N_2);
return(t0);
}

LP p_lsp_CEILING_2FFIXNUM(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{
LP v_R_4; LP v_Q_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 2) wna(argc,2);
v_Q_3 = ((LP) INT_TO_FX((int) (v_X_0) / (int) (v_Y_1)));
v_R_4 = ((LP) ((int) (v_X_0) % (int) (v_Y_1)));
t1 = (num_equal_p(((LP) 0), (v_R_4)));
if (t1 != NIL) {
t0 = v_Q_3;
} else {
t0 = ICALL(s_lsp_1_2B) (1, v_Q_3);
}
t2 = (subtract((v_R_4), (v_Y_1)));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,t2);
}
return(t0);
}

LP p_lsp_CEILING_2FFLOAT(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 2) wna(argc,2);
t2 = (divide((v_X_0), (v_Y_1)));
t1 = NEW_FLOAT(ceil(RAW_FLOAT(t2)));
t0 = INT_TO_FX(double_truncate(RAW_FLOAT(t1), RAW_FLOAT(LREF(k2401))));
t4 = NEW_FLOAT(fmod(RAW_FLOAT(v_X_0), RAW_FLOAT(v_Y_1)));
t3 = (subtract((t4), (v_Y_1)));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,t3);
}
return(t0);
}

LP p_lsp_CEILING(va_alist) va_dcl
{
LP v_Y_9; LP v_X_8; LP v_R_7; 
LP v_Q_6; LP v_Y_4; LP v_X_3; 
LP v_X_0; LP v_Y_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_X_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_Y_1 = (LP) 2;
} else {
v_Y_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t2 = ICALL(s_lsp_FIXNUMP) (1, v_X_0);
if (t2 != NIL) {
t1 = ICALL(s_lsp_FIXNUMP) (1, v_Y_1);
} else {
t1 = LREF(s_lsp_NIL);
}
if (t1 != NIL) {
v_X_3 = v_X_0;
v_Y_4 = v_Y_1;
v_Q_6 = ((LP) INT_TO_FX((int) (v_X_3) / (int) (v_Y_4)));
v_R_7 = ((LP) ((int) (v_X_3) % (int) (v_Y_4)));
t4 = (num_equal_p(((LP) 0), (v_R_7)));
if (t4 != NIL) {
t3 = v_Q_6;
} else {
t3 = ICALL(s_lsp_1_2B) (1, v_Q_6);
}
t5 = (subtract((v_R_7), (v_Y_4)));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,t5);
}
return(t3);
} else {
v_X_8 = ICALL(s_lsp_FLOAT) (1, v_X_0);
v_Y_9 = ICALL(s_lsp_FLOAT) (1, v_Y_1);
t8 = (divide((v_X_8), (v_Y_9)));
t7 = NEW_FLOAT(ceil(RAW_FLOAT(t8)));
t6 = INT_TO_FX(double_truncate(RAW_FLOAT(t7), RAW_FLOAT(LREF(k2401))));
t10 = NEW_FLOAT(fmod(RAW_FLOAT(v_X_8), RAW_FLOAT(v_Y_9)));
t9 = (subtract((t10), (v_Y_9)));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,t9);
}
return(t6);
}
}

LP p_lsp_COMPLEX(va_alist) va_dcl
{
LP v_REALPART_0; LP v_IMAGPART_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_REALPART_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_IMAGPART_1 = (LP) 0;
} else {
v_IMAGPART_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t0 = ICALL(s_lsp_MAKE_2DCOMPLEX) (MV_CALL(argc,2), v_REALPART_0, v_IMAGPART_1);
return(t0);
}

LP p_lsp_MAKE_2DCOMPLEX(argc, v_REALPART_0, v_IMAGPART_1)
      ARGC argc;  LP v_REALPART_0; LP v_IMAGPART_1;
{
LP v_C_3; 
LP t0; LP t1; LP t2; LP t3; 
if (argc != 2) wna(argc,2);
v_C_3 = (alloc_words(2, 13));
((LP) (DEREF((v_C_3) + 0 * 4) = (LD) (v_REALPART_0)));
((LP) (DEREF((v_C_3) + 1 * 4) = (LD) (v_IMAGPART_1)));
return(v_C_3);
}

LP p_lsp_COS(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_FLOAT) (1, v_X_0);
t0 = NEW_FLOAT(cos(RAW_FLOAT(t1)));
return(t0);
}

LP p_lsp_DECODE_2DFLOAT(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_FLOATP) (1, v_X_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_X_0, LREF(s_lsp_FLOAT), (LP) 0);
}
t1 = NEW_FLOAT(float_significand(RAW_FLOAT(v_X_0)));
t2 = INT_TO_FX(float_exponent(RAW_FLOAT(v_X_0)));
t4 = (lessp((v_X_0), ((LP) 0)));
if (t4 != NIL) {
t3 = LREF(k2402);
} else {
t3 = LREF(k2401);
}
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,3);
SET_MV_RETURN_VALUE(argc,1,t2);
SET_MV_RETURN_VALUE(argc,2,t3);
}
return(t1);
}

LP p_lsp_INTEGER_2DDECODE_2DFLOAT(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_FLOATP) (1, v_X_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_X_0, LREF(s_lsp_FLOAT), (LP) 0);
}
t1 = ICALL(s_lsp_ERROR) (MV_CALL(argc,1), LREF(k2403));
return(t1);
}

LP p_lsp__2F(va_alist) va_dcl
{
LP v_LOOP_2DITER_2DFLAG_2D932_8; LP v_RESULT_7; LP v_LOOP_2DBIND_2D931_6; 
LP v_I_5; LP v_KEY3705_4; LP v_N_3; 
LP v_X_0; LP v_OTHERS_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 

RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_X_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
RESTVIFY(v_OTHERS_1,2,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_3 = ICALL(s_lsp_LENGTH) (1, v_OTHERS_1);
v_KEY3705_4 = v_N_3;
t1 = ICALL(s_lsp_EQL) (2, v_KEY3705_4, (LP) 0);
if (t1 != NIL) {
return(v_X_0);
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY3705_4, (LP) 2);
if (t2 != NIL) {
t3 = ((LP) DEREF((v_OTHERS_1) + 0 * 4));
t0 = (divide((v_X_0), (t3)));
return(t0);
} else {
v_I_5 = (LP) 2;
t4 = ((LP) DEREF((v_OTHERS_1) + 0 * 4));
t5 = ((LP) DEREF((v_OTHERS_1) + 1 * 4));
v_RESULT_7 = (divide((t4), (t5)));
v_LOOP_2DITER_2DFLAG_2D932_8 = LREF(s_lsp_T);
t_NEXT_2DLOOP_10:;
if (((int) (v_I_5) >= (int) (v_N_3))) {
goto t_END_2DLOOP_11;
}
if (v_LOOP_2DITER_2DFLAG_2D932_8 == NIL) {
t8 = ((LP) DEREF((v_OTHERS_1) + FX_TO_INT(v_I_5) * 4));
v_RESULT_7 = (divide((v_RESULT_7), (t8)));
}
v_LOOP_2DITER_2DFLAG_2D932_8 = LREF(s_lsp_NIL);
v_I_5 = (((LP) ((int) (v_I_5) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_10;
goto t_END_2DLOOP_11;
t_END_2DLOOP_11:;
t6 = v_RESULT_7;
goto b_NIL_9;
t6 = NIL;
b_NIL_9:;
t0 = (divide((v_X_0), (t6)));
return(t0);
}
}
}

LP p_lsp_ENSURE_2DBIGNUM(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{
LP v_KEY3709_4; LP v_KEY3706_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 1) wna(argc,1);
v_KEY3706_2 = v_X_0;
v_KEY3709_4 = v_KEY3706_2;
t2 = ICALL(s_lsp_FIXNUMP) (1, v_KEY3709_4);
if (t2 != NIL) {
t1 = (fixnum_to_bignum((v_X_0)));
return(t1);
} else {
t3 = INT_TO_FX(((int) TAG((v_KEY3709_4))));
switch ((int) t3) {
case 2:
return(v_X_0);
break;
default:
goto t_DEFAULT_2DTAG3708_5;
break;
}
}
return(t1);
t_DEFAULT_2DTAG3708_5:;
t4 = ICALL(s_lsp_ERROR) (MV_CALL(argc,3), LREF(k2398), v_KEY3706_2, LREF(k2399));
return(t4);
return(NIL);
return(NIL);
}

LP p_lsp_ENSURE_2DFIXNUM(argc, v_N_0)
      ARGC argc;  LP v_N_0;
{
LP v_KEY3713_4; LP v_KEY3710_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
if (argc != 1) wna(argc,1);
v_KEY3710_2 = v_N_0;
v_KEY3713_4 = v_KEY3710_2;
t2 = ICALL(s_lsp_FIXNUMP) (1, v_KEY3713_4);
if (t2 != NIL) {
return(v_N_0);
} else {
t3 = INT_TO_FX(((int) TAG((v_KEY3713_4))));
switch ((int) t3) {
default:
goto t_DEFAULT_2DTAG3712_5;
break;
}
}
return(t1);
t_DEFAULT_2DTAG3712_5:;
t4 = ICALL(s_lsp_ERROR) (MV_CALL(argc,3), LREF(k2398), v_KEY3710_2, LREF(k2404));
return(t4);
return(NIL);
return(NIL);
}

LP p_lsp_EVENP(argc, v_INTEGER_0)
      ARGC argc;  LP v_INTEGER_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_REM) (2, v_INTEGER_0, (LP) 4);
t0 = ICALL(s_lsp_ZEROP) (MV_CALL(argc,1), t1);
return(t0);
}

LP p_lsp_EXP(argc, v_N_0)
      ARGC argc;  LP v_N_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_FLOAT) (1, v_N_0);
t0 = NEW_FLOAT(exp(RAW_FLOAT(t1)));
return(t0);
}

LP p_lsp_EXPT(argc, v_N_0, v_POWER_1)
      ARGC argc;  LP v_N_0; LP v_POWER_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 2) wna(argc,2);
t2 = ICALL(s_lsp_FIXNUMP) (1, v_N_0);
if (t2 != NIL) {
t1 = ICALL(s_lsp_FIXNUMP) (1, v_POWER_1);
} else {
t1 = LREF(s_lsp_NIL);
}
if (t1 != NIL) {
t0 = ICALL(s_lsp_EXPT_2FFIXNUM) (MV_CALL(argc,2), v_N_0, v_POWER_1);
return(t0);
} else {
t0 = ICALL(s_lsp_EXPT_2FFLOAT) (MV_CALL(argc,2), v_N_0, v_POWER_1);
return(t0);
}
}

LP p_lsp_EXPT_2FFIXNUM(argc, v_N_0, v_POWER_1)
      ARGC argc;  LP v_N_0; LP v_POWER_1;
{
LP v_LOOP_2DITER_2DFLAG_2D934_11; LP v_RESULT_10; LP v_I_9; 
LP v_LOOP_2DITER_2DFLAG_2D933_5; LP v_RESULT_4; LP v_I_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; 
if (argc != 2) wna(argc,2);
t1 = (geq_p((v_POWER_1), ((LP) 0)));
if (t1 != NIL) {
v_I_3 = v_POWER_1;
v_RESULT_4 = (LP) 2;
v_LOOP_2DITER_2DFLAG_2D933_5 = LREF(s_lsp_T);
t_NEXT_2DLOOP_7:;
if (((int) (v_I_3) < (int) ((LP) 0))) {
goto t_END_2DLOOP_8;
}
if (v_LOOP_2DITER_2DFLAG_2D933_5 == NIL) {
v_RESULT_4 = (multiply((v_RESULT_4), (v_N_0)));
}
v_LOOP_2DITER_2DFLAG_2D933_5 = LREF(s_lsp_NIL);
v_I_3 = (((LP) ((int) (v_I_3) - (int) ((LP) 2))));
goto t_NEXT_2DLOOP_7;
goto t_END_2DLOOP_8;
t_END_2DLOOP_8:;
return(v_RESULT_4);
return(NIL);
return(NIL);
} else {
v_I_9 = v_POWER_1;
v_RESULT_10 = (LP) 2;
v_LOOP_2DITER_2DFLAG_2D934_11 = LREF(s_lsp_T);
t_NEXT_2DLOOP_13:;
if (((int) (v_I_9) > (int) ((LP) 0))) {
goto t_END_2DLOOP_14;
}
if (v_LOOP_2DITER_2DFLAG_2D934_11 == NIL) {
v_RESULT_10 = (divide((v_RESULT_10), (v_N_0)));
}
v_LOOP_2DITER_2DFLAG_2D934_11 = LREF(s_lsp_NIL);
v_I_9 = (((LP) ((int) (v_I_9) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_13;
goto t_END_2DLOOP_14;
t_END_2DLOOP_14:;
return(v_RESULT_10);
return(NIL);
return(NIL);
}
}

LP p_lsp_EXPT_2FFLOAT(argc, v_N_0, v_POWER_1)
      ARGC argc;  LP v_N_0; LP v_POWER_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 2) wna(argc,2);
t1 = ICALL(s_lsp_FLOAT) (1, v_N_0);
t2 = ICALL(s_lsp_FLOAT) (1, v_POWER_1);
t0 = NEW_FLOAT(pow(RAW_FLOAT(t1), RAW_FLOAT(t2)));
return(t0);
}

LP p_lsp_FFLOOR(va_alist) va_dcl
{
LP v_FLOAT_2DY_4; LP v_FLOAT_2DX_3; LP v_X_0; 
LP v_Y_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_X_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_Y_1 = LREF(k2401);
} else {
v_Y_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
v_FLOAT_2DX_3 = ICALL(s_lsp_FLOAT) (1, v_X_0);
v_FLOAT_2DY_4 = ICALL(s_lsp_FLOAT) (1, v_Y_1);
t1 = (divide((v_FLOAT_2DX_3), (v_FLOAT_2DY_4)));
t0 = NEW_FLOAT(floor(RAW_FLOAT(t1)));
t2 = NEW_FLOAT(fmod(RAW_FLOAT(v_FLOAT_2DX_3), RAW_FLOAT(v_FLOAT_2DY_4)));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,t2);
}
return(t0);
}

LP p_lsp_FLOAT_2DRADIX(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_FLOATP) (1, v_X_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_X_0, LREF(s_lsp_FLOAT), (LP) 0);
}
return((LP) 4);
}

LP p_lsp_FLOAT(va_alist) va_dcl
{
LP v_N_0; LP v_OTHER_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_N_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_OTHER_1 = NIL;
} else {
v_OTHER_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t0 = ICALL(s_lsp_FLOAT_2D1) (MV_CALL(argc,1), v_N_0);
return(t0);
}

LP p_lsp_FLOAT_2D1(argc, v_N_0)
      ARGC argc;  LP v_N_0;
{
LP v_OTHER_13; LP v_N_12; LP v_N_10; 
LP v_OTHER_11; LP v_OTHER_8; LP v_N_7; 
LP v_N_5; LP v_OTHER_6; LP v_KEY3716_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; 
if (argc != 1) wna(argc,1);
v_KEY3716_3 = v_N_0;
t2 = ICALL(s_lsp_FIXNUMP) (1, v_KEY3716_3);
if (t2 != NIL) {
t1 = NEW_FLOAT(((double) FX_TO_INT(v_N_0)));
return(t1);
} else {
t3 = INT_TO_FX(((int) TAG((v_KEY3716_3))));
switch ((int) t3) {
case 18:
v_N_7 = ICALL(s_lsp_NUMERATOR) (1, v_N_0);
t4 = ICALL(s_lsp_FLOAT_2D1) (1, v_N_7);
v_N_12 = ICALL(s_lsp_DENOMINATOR) (1, v_N_0);
t5 = ICALL(s_lsp_FLOAT_2D1) (1, v_N_12);
t1 = (divide((t4), (t5)));
return(t1);
break;
case 2:
t1 = NEW_FLOAT(bignum_to_double((v_N_0)));
return(t1);
break;
case 10:
return(v_N_0);
break;
default:
goto t_DEFAULT_2DTAG3715_4;
break;
}
}
return(t1);
t_DEFAULT_2DTAG3715_4:;
t6 = ICALL(s_lsp_ERROR) (MV_CALL(argc,2), LREF(k2405), v_N_0);
return(t6);
return(NIL);
return(NIL);
}

LP p_lsp_FLOOR_2FFIXNUM(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; 
if (argc != 2) wna(argc,2);
t0 = ((LP) INT_TO_FX((int) (v_X_0) / (int) (v_Y_1)));
t1 = ((LP) ((int) (v_X_0) % (int) (v_Y_1)));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,t1);
}
return(t0);
}

LP p_lsp_FLOOR_2FFLOAT(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t2 = (divide((v_X_0), (v_Y_1)));
t1 = NEW_FLOAT(floor(RAW_FLOAT(t2)));
t0 = INT_TO_FX(double_truncate(RAW_FLOAT(t1), RAW_FLOAT(LREF(k2401))));
t3 = NEW_FLOAT(fmod(RAW_FLOAT(v_X_0), RAW_FLOAT(v_Y_1)));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,t3);
}
return(t0);
}

LP p_lsp_FLOOR(va_alist) va_dcl
{
LP v_Y_17; LP v_X_16; LP v_OTHER_14; 
LP v_N_13; LP v_N_11; LP v_OTHER_12; 
LP v_OTHER_9; LP v_N_8; LP v_N_6; 
LP v_OTHER_7; LP v_Y_4; LP v_X_3; 
LP v_X_0; LP v_Y_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_X_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_Y_1 = (LP) 2;
} else {
v_Y_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t2 = ICALL(s_lsp_FIXNUMP) (1, v_X_0);
if (t2 != NIL) {
t1 = ICALL(s_lsp_FIXNUMP) (1, v_Y_1);
} else {
t1 = LREF(s_lsp_NIL);
}
if (t1 != NIL) {
v_X_3 = v_X_0;
v_Y_4 = v_Y_1;
t3 = ((LP) INT_TO_FX((int) (v_X_3) / (int) (v_Y_4)));
t4 = ((LP) ((int) (v_X_3) % (int) (v_Y_4)));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,t4);
}
return(t3);
} else {
v_N_8 = v_X_0;
v_OTHER_9 = LREF(s_lsp_NIL);
v_X_16 = ICALL(s_lsp_FLOAT_2D1) (1, v_X_0);
v_N_13 = v_Y_1;
v_OTHER_14 = LREF(s_lsp_NIL);
v_Y_17 = ICALL(s_lsp_FLOAT_2D1) (1, v_Y_1);
t7 = (divide((v_X_16), (v_Y_17)));
t6 = NEW_FLOAT(floor(RAW_FLOAT(t7)));
t5 = INT_TO_FX(double_truncate(RAW_FLOAT(t6), RAW_FLOAT(LREF(k2401))));
t8 = NEW_FLOAT(fmod(RAW_FLOAT(v_X_16), RAW_FLOAT(v_Y_17)));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,t8);
}
return(t5);
}
}

LP p_lsp_FLOOR_2F1V(va_alist) va_dcl
{
LP v_X_0; LP v_Y_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_X_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_Y_1 = (LP) 2;
} else {
v_Y_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t0 = ICALL(s_lsp_FLOOR) (MV_CALL(argc,2), v_X_0, v_Y_1);
return(t0);
}

LP p_lsp_GCD_2F2(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{
LP v_REM_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 2) wna(argc,2);
START2406:
v_REM_3 = ICALL(s_lsp_REM) (2, v_X_0, v_Y_1);
t1 = (num_equal_p((v_REM_3), ((LP) 0)));
if (t1 != NIL) {
return(v_Y_1);
} else {
v_X_0 = v_Y_1; v_Y_1 = v_REM_3; 
goto START2406;
}
}

LP p_lsp_GCD(va_alist) va_dcl
{
LP v_LOOP_2DITER_2DFLAG_2D936_11; LP v_RESULT_10; LP v_LOOP_2DBIND_2D935_9; 
LP v_I_8; LP v_X_6; LP v_LIST_4; 
LP v_KEY3717_3; LP v_N_2; LP v_ARGS_0; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; 
RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTVIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_2 = ICALL(s_lsp_LENGTH) (1, v_ARGS_0);
v_KEY3717_3 = v_N_2;
t1 = ICALL(s_lsp_EQL) (2, v_KEY3717_3, (LP) 0);
if (t1 != NIL) {
return((LP) 0);
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY3717_3, (LP) 2);
if (t2 != NIL) {
v_LIST_4 = v_ARGS_0;
v_X_6 = v_ARGS_0;
t0 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
return(t0);
} else {
v_I_8 = (LP) 2;
t3 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t4 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
v_RESULT_10 = ICALL(s_lsp_GCD_2F2) (2, t3, t4);
v_LOOP_2DITER_2DFLAG_2D936_11 = LREF(s_lsp_T);
t_NEXT_2DLOOP_13:;
if (((int) (v_I_8) >= (int) (v_N_2))) {
goto t_END_2DLOOP_14;
}
if (v_LOOP_2DITER_2DFLAG_2D936_11 == NIL) {
t6 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(v_I_8) * 4));
v_RESULT_10 = ICALL(s_lsp_GCD_2F2) (2, v_RESULT_10, t6);
}
v_LOOP_2DITER_2DFLAG_2D936_11 = LREF(s_lsp_NIL);
v_I_8 = (((LP) ((int) (v_I_8) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_13;
goto t_END_2DLOOP_14;
t_END_2DLOOP_14:;
return(v_RESULT_10);
return(NIL);
return(NIL);
}
}
}

LP p_lsp__3E_3D(va_alist) va_dcl
{
LP v_LOOP_2DITER_2DFLAG_2D938_7; LP v_RESULT_6; LP v_LOOP_2DBIND_2D937_5; 
LP v_I_4; LP v_KEY3718_3; LP v_N_2; 
LP v_ARGS_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; 
RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTVIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_2 = ICALL(s_lsp_LENGTH) (1, v_ARGS_0);
v_KEY3718_3 = v_N_2;
t1 = ICALL(s_lsp_MEMQL) (2, v_KEY3718_3, LREF(k2407));
if (t1 != NIL) {
return(LREF(s_lsp_T));
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY3718_3, (LP) 4);
if (t2 != NIL) {
t3 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t4 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
t0 = (geq_p((t3), (t4)));
return(t0);
} else {
v_I_4 = (LP) 2;
t5 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t6 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
v_RESULT_6 = (geq_p((t5), (t6)));
v_LOOP_2DITER_2DFLAG_2D938_7 = LREF(s_lsp_T);
t_NEXT_2DLOOP_9:;
if (((int) (v_I_4) >= (int) (v_N_2))) {
goto t_END_2DLOOP_10;
}
if (v_LOOP_2DITER_2DFLAG_2D938_7 == NIL) {
t9 = (subtract((v_I_4), ((LP) 2)));
t8 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(t9) * 4));
t10 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(v_I_4) * 4));
v_RESULT_6 = (geq_p((t8), (t10)));
}
if (v_RESULT_6 == NIL) {
return(v_RESULT_6);
return(NIL);
}
v_LOOP_2DITER_2DFLAG_2D938_7 = LREF(s_lsp_NIL);
v_I_4 = (((LP) ((int) (v_I_4) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_9;
goto t_END_2DLOOP_10;
t_END_2DLOOP_10:;
return(v_RESULT_6);
return(NIL);
return(NIL);
}
}
}

LP p_lsp__3E(va_alist) va_dcl
{
LP v_LOOP_2DITER_2DFLAG_2D940_7; LP v_RESULT_6; LP v_LOOP_2DBIND_2D939_5; 
LP v_I_4; LP v_KEY3719_3; LP v_N_2; 
LP v_ARGS_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; 
RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTVIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_2 = ICALL(s_lsp_LENGTH) (1, v_ARGS_0);
v_KEY3719_3 = v_N_2;
t1 = ICALL(s_lsp_MEMQL) (2, v_KEY3719_3, LREF(k2407));
if (t1 != NIL) {
return(LREF(s_lsp_T));
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY3719_3, (LP) 4);
if (t2 != NIL) {
t3 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t4 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
t0 = (greaterp((t3), (t4)));
return(t0);
} else {
v_I_4 = (LP) 2;
t5 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t6 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
v_RESULT_6 = (greaterp((t5), (t6)));
v_LOOP_2DITER_2DFLAG_2D940_7 = LREF(s_lsp_T);
t_NEXT_2DLOOP_9:;
if (((int) (v_I_4) >= (int) (v_N_2))) {
goto t_END_2DLOOP_10;
}
if (v_LOOP_2DITER_2DFLAG_2D940_7 == NIL) {
t9 = (subtract((v_I_4), ((LP) 2)));
t8 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(t9) * 4));
t10 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(v_I_4) * 4));
v_RESULT_6 = (greaterp((t8), (t10)));
}
if (v_RESULT_6 == NIL) {
return(v_RESULT_6);
return(NIL);
}
v_LOOP_2DITER_2DFLAG_2D940_7 = LREF(s_lsp_NIL);
v_I_4 = (((LP) ((int) (v_I_4) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_9;
goto t_END_2DLOOP_10;
t_END_2DLOOP_10:;
return(v_RESULT_6);
return(NIL);
return(NIL);
}
}
}

LP p_lsp_IMAGPART(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_COMPLEXP) (1, v_C_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_C_0, LREF(s_lsp_COMPLEX), (LP) 0);
}
t1 = ((LP) DEREF((v_C_0) + 1 * 4));
return(t1);
}

LP p_lsp_INTEGER_2DLENGTH(argc, v_N_0)
      ARGC argc;  LP v_N_0;
{
LP v_KEY3723_5; LP v_KEY3720_3; LP v_X_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_INTEGERP) (1, v_N_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_N_0, LREF(s_lsp_INTEGER), (LP) 0);
}
t1 = (lessp((v_N_0), ((LP) 0)));
if (t1 != NIL) {
t2 = (add((v_N_0), ((LP) 2)));
v_X_2 = (subtract(((LP) 0), (t2)));
} else {
v_X_2 = v_N_0;
}
v_KEY3720_3 = v_X_2;
v_KEY3723_5 = v_KEY3720_3;
t5 = ICALL(s_lsp_FIXNUMP) (1, v_KEY3723_5);
if (t5 != NIL) {
t4 = INT_TO_FX(int_length(FX_TO_INT(v_X_2)));
return(t4);
} else {
t6 = INT_TO_FX(((int) TAG((v_KEY3723_5))));
switch ((int) t6) {
case 2:
t4 = ICALL(s_lsp_ERROR) (MV_CALL(argc,1), LREF(k2409));
return(t4);
break;
default:
goto t_DEFAULT_2DTAG3722_6;
break;
}
}
return(t4);
t_DEFAULT_2DTAG3722_6:;
t7 = ICALL(s_lsp_ERROR) (MV_CALL(argc,3), LREF(k2398), v_KEY3720_3, LREF(k2399));
return(t7);
return(NIL);
return(NIL);
}

LP p_lsp_LCM_2F2(argc, v_N_0, v_M_1)
      ARGC argc;  LP v_N_0; LP v_M_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; 
if (argc != 2) wna(argc,2);
t2 = ICALL(s_lsp_MAX) (2, v_N_0, v_M_1);
t3 = ICALL(s_lsp_GCD) (2, v_N_0, v_M_1);
t1 = (divide((t2), (t3)));
t4 = ICALL(s_lsp_MIN) (2, v_N_0, v_M_1);
t0 = (multiply((t1), (t4)));
return(t0);
}

LP p_lsp_LCM(va_alist) va_dcl
{
LP v_LOOP_2DITER_2DFLAG_2D942_11; LP v_RESULT_10; LP v_LOOP_2DBIND_2D941_9; 
LP v_I_8; LP v_X_6; LP v_LIST_4; 
LP v_KEY3724_3; LP v_N_2; LP v_ARGS_0; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; 
RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTVIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_2 = ICALL(s_lsp_LENGTH) (1, v_ARGS_0);
v_KEY3724_3 = v_N_2;
t1 = ICALL(s_lsp_EQL) (2, v_KEY3724_3, (LP) 0);
if (t1 != NIL) {
return((LP) 2);
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY3724_3, (LP) 2);
if (t2 != NIL) {
v_LIST_4 = v_ARGS_0;
v_X_6 = v_ARGS_0;
t0 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
return(t0);
} else {
v_I_8 = (LP) 2;
t3 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t4 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
v_RESULT_10 = ICALL(s_lsp_LCM_2F2) (2, t3, t4);
v_LOOP_2DITER_2DFLAG_2D942_11 = LREF(s_lsp_T);
t_NEXT_2DLOOP_13:;
if (((int) (v_I_8) >= (int) (v_N_2))) {
goto t_END_2DLOOP_14;
}
if (v_LOOP_2DITER_2DFLAG_2D942_11 == NIL) {
t6 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(v_I_8) * 4));
v_RESULT_10 = ICALL(s_lsp_LCM_2F2) (2, v_RESULT_10, t6);
}
v_LOOP_2DITER_2DFLAG_2D942_11 = LREF(s_lsp_NIL);
v_I_8 = (((LP) ((int) (v_I_8) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_13;
goto t_END_2DLOOP_14;
t_END_2DLOOP_14:;
return(v_RESULT_10);
return(NIL);
return(NIL);
}
}
}

LP p_lsp__3C_3D(va_alist) va_dcl
{
LP v_LOOP_2DITER_2DFLAG_2D944_7; LP v_RESULT_6; LP v_LOOP_2DBIND_2D943_5; 
LP v_I_4; LP v_KEY3725_3; LP v_N_2; 
LP v_ARGS_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; 
RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTVIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_2 = ICALL(s_lsp_LENGTH) (1, v_ARGS_0);
v_KEY3725_3 = v_N_2;
t1 = ICALL(s_lsp_MEMQL) (2, v_KEY3725_3, LREF(k2407));
if (t1 != NIL) {
return(LREF(s_lsp_T));
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY3725_3, (LP) 4);
if (t2 != NIL) {
t3 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t4 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
t0 = (leq_p((t3), (t4)));
return(t0);
} else {
v_I_4 = (LP) 2;
t5 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t6 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
v_RESULT_6 = (leq_p((t5), (t6)));
v_LOOP_2DITER_2DFLAG_2D944_7 = LREF(s_lsp_T);
t_NEXT_2DLOOP_9:;
if (((int) (v_I_4) >= (int) (v_N_2))) {
goto t_END_2DLOOP_10;
}
if (v_LOOP_2DITER_2DFLAG_2D944_7 == NIL) {
t9 = (subtract((v_I_4), ((LP) 2)));
t8 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(t9) * 4));
t10 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(v_I_4) * 4));
v_RESULT_6 = (leq_p((t8), (t10)));
}
if (v_RESULT_6 == NIL) {
return(v_RESULT_6);
return(NIL);
}
v_LOOP_2DITER_2DFLAG_2D944_7 = LREF(s_lsp_NIL);
v_I_4 = (((LP) ((int) (v_I_4) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_9;
goto t_END_2DLOOP_10;
t_END_2DLOOP_10:;
return(v_RESULT_6);
return(NIL);
return(NIL);
}
}
}

LP p_lsp__3C(va_alist) va_dcl
{
LP v_LOOP_2DITER_2DFLAG_2D946_7; LP v_RESULT_6; LP v_LOOP_2DBIND_2D945_5; 
LP v_I_4; LP v_KEY3726_3; LP v_N_2; 
LP v_ARGS_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; 
RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTVIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_2 = ICALL(s_lsp_LENGTH) (1, v_ARGS_0);
v_KEY3726_3 = v_N_2;
t1 = ICALL(s_lsp_MEMQL) (2, v_KEY3726_3, LREF(k2407));
if (t1 != NIL) {
return(LREF(s_lsp_T));
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY3726_3, (LP) 4);
if (t2 != NIL) {
t3 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t4 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
t0 = (lessp((t3), (t4)));
return(t0);
} else {
v_I_4 = (LP) 2;
t5 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t6 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
v_RESULT_6 = (lessp((t5), (t6)));
v_LOOP_2DITER_2DFLAG_2D946_7 = LREF(s_lsp_T);
t_NEXT_2DLOOP_9:;
if (((int) (v_I_4) >= (int) (v_N_2))) {
goto t_END_2DLOOP_10;
}
if (v_LOOP_2DITER_2DFLAG_2D946_7 == NIL) {
t9 = (subtract((v_I_4), ((LP) 2)));
t8 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(t9) * 4));
t10 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(v_I_4) * 4));
v_RESULT_6 = (lessp((t8), (t10)));
}
if (v_RESULT_6 == NIL) {
return(v_RESULT_6);
return(NIL);
}
v_LOOP_2DITER_2DFLAG_2D946_7 = LREF(s_lsp_NIL);
v_I_4 = (((LP) ((int) (v_I_4) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_9;
goto t_END_2DLOOP_10;
t_END_2DLOOP_10:;
return(v_RESULT_6);
return(NIL);
return(NIL);
}
}
}

LP p_lsp_LOG_2F10(argc, v_N_0)
      ARGC argc;  LP v_N_0;
{
LP v_OTHER_5; LP v_N_4; LP v_N_2; 
LP v_OTHER_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; 
if (argc != 1) wna(argc,1);
v_N_4 = v_N_0;
v_OTHER_5 = LREF(s_lsp_NIL);
t1 = ICALL(s_lsp_FLOAT_2D1) (1, v_N_0);
t0 = NEW_FLOAT(log10(RAW_FLOAT(t1)));
return(t0);
}

LP p_lsp_LOG_2FE(argc, v_N_0)
      ARGC argc;  LP v_N_0;
{
LP v_OTHER_5; LP v_N_4; LP v_N_2; 
LP v_OTHER_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; 
if (argc != 1) wna(argc,1);
v_N_4 = v_N_0;
v_OTHER_5 = LREF(s_lsp_NIL);
t1 = ICALL(s_lsp_FLOAT_2D1) (1, v_N_0);
t0 = NEW_FLOAT(log(RAW_FLOAT(t1)));
return(t0);
}

LP p_lsp_LOG(va_alist) va_dcl
{
LP v_OTHER_13; LP v_N_12; LP v_N_10; 
LP v_OTHER_11; LP v_KEY3727_9; LP v_F_8; 
LP v_OTHER_6; LP v_N_5; LP v_N_3; 
LP v_OTHER_4; LP v_N_0; LP v_BASE_1; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_N_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_BASE_1 = NIL;
} else {
v_BASE_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
v_N_5 = v_N_0;
v_OTHER_6 = LREF(s_lsp_NIL);
v_F_8 = ICALL(s_lsp_FLOAT_2D1) (1, v_N_0);
v_KEY3727_9 = v_BASE_1;
t1 = ICALL(s_lsp_EQL) (2, v_BASE_1, LREF(s_lsp_NIL));
if (t1 != NIL) {
t0 = ICALL(s_lsp_LOG_2FE) (MV_CALL(argc,1), v_F_8);
return(t0);
} else {
t2 = ICALL(s_lsp_LOG_2FE) (1, v_F_8);
v_N_12 = v_BASE_1;
v_OTHER_13 = LREF(s_lsp_NIL);
t4 = ICALL(s_lsp_FLOAT_2D1) (1, v_BASE_1);
t3 = ICALL(s_lsp_LOG_2FE) (1, t4);
t0 = (divide((t2), (t3)));
return(t0);
}
}

LP p_lsp_LOGAND_2F2(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_INTEGERP) (1, v_X_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_X_0, LREF(s_lsp_INTEGER), (LP) 0);
}
t1 = ICALL(s_lsp_INTEGERP) (1, v_Y_1);
if (t1 == NIL) {
ICALL(s_lsp_WTA) (3, v_Y_1, LREF(s_lsp_INTEGER), (LP) 0);
}
t4 = ICALL(s_lsp_FIXNUMP) (1, v_X_0);
if (t4 != NIL) {
t3 = ICALL(s_lsp_FIXNUMP) (1, v_Y_1);
} else {
t3 = LREF(s_lsp_NIL);
}
if (t3 != NIL) {
t2 = (((LP) ((int) (v_X_0) & (int) (v_Y_1))));
return(t2);
} else {
t2 = ICALL(s_lsp_ERROR) (MV_CALL(argc,1), LREF(k2410));
return(t2);
}
}

LP p_lsp_LOGAND(va_alist) va_dcl
{
LP v_LOOP_2DITER_2DFLAG_2D948_8; LP v_RESULT_7; LP v_LOOP_2DBIND_2D947_6; 
LP v_I_5; LP v_KEY3728_4; LP v_N_3; 
LP v_ARG_2D1_0; LP v_ARGS_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 

RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_ARG_2D1_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
RESTVIFY(v_ARGS_1,2,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_3 = ICALL(s_lsp_LENGTH) (1, v_ARGS_1);
v_KEY3728_4 = v_N_3;
t1 = ICALL(s_lsp_EQL) (2, v_KEY3728_4, (LP) 0);
if (t1 != NIL) {
return(v_ARG_2D1_0);
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY3728_4, (LP) 2);
if (t2 != NIL) {
t3 = ((LP) DEREF((v_ARGS_1) + 0 * 4));
t0 = ICALL(s_lsp_LOGAND_2F2) (MV_CALL(argc,2), v_ARG_2D1_0, t3);
return(t0);
} else {
v_I_5 = (LP) 2;
t4 = ((LP) DEREF((v_ARGS_1) + 0 * 4));
t5 = ((LP) DEREF((v_ARGS_1) + 1 * 4));
v_RESULT_7 = ICALL(s_lsp_LOGAND_2F2) (2, t4, t5);
v_LOOP_2DITER_2DFLAG_2D948_8 = LREF(s_lsp_T);
t_NEXT_2DLOOP_10:;
if (((int) (v_I_5) >= (int) (v_N_3))) {
goto t_END_2DLOOP_11;
}
if (v_LOOP_2DITER_2DFLAG_2D948_8 == NIL) {
t8 = ((LP) DEREF((v_ARGS_1) + FX_TO_INT(v_I_5) * 4));
v_RESULT_7 = ICALL(s_lsp_LOGAND_2F2) (2, v_RESULT_7, t8);
}
v_LOOP_2DITER_2DFLAG_2D948_8 = LREF(s_lsp_NIL);
v_I_5 = (((LP) ((int) (v_I_5) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_10;
goto t_END_2DLOOP_11;
t_END_2DLOOP_11:;
t6 = v_RESULT_7;
goto b_NIL_9;
t6 = NIL;
b_NIL_9:;
t0 = ICALL(s_lsp_LOGAND_2F2) (MV_CALL(argc,2), v_ARG_2D1_0, t6);
return(t0);
}
}
}

LP p_lsp_LOGANDC1(argc, v_I1_0, v_I2_1)
      ARGC argc;  LP v_I1_0; LP v_I2_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 2) wna(argc,2);
t1 = ICALL(s_lsp_LOGNOT) (1, v_I1_0);
t0 = ICALL(s_lsp_LOGAND_2F2) (MV_CALL(argc,2), t1, v_I2_1);
return(t0);
}

LP p_lsp_LOGANDC2(argc, v_I1_0, v_I2_1)
      ARGC argc;  LP v_I1_0; LP v_I2_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 2) wna(argc,2);
t1 = ICALL(s_lsp_LOGNOT) (1, v_I2_1);
t0 = ICALL(s_lsp_LOGAND_2F2) (MV_CALL(argc,2), v_I1_0, t1);
return(t0);
}

LP p_lsp_LOGEQV_2F2(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_FIXNUMP) (1, v_X_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_X_0, LREF(s_lsp_FIXNUM), (LP) 0);
}
t1 = ICALL(s_lsp_FIXNUMP) (1, v_Y_1);
if (t1 == NIL) {
ICALL(s_lsp_WTA) (3, v_Y_1, LREF(s_lsp_FIXNUM), (LP) 0);
}
t2 = ICALL(s_lsp_ERROR) (MV_CALL(argc,1), LREF(k2411));
return(t2);
}

LP p_lsp_LOGEQV(va_alist) va_dcl
{
LP v_LOOP_2DITER_2DFLAG_2D950_8; LP v_RESULT_7; LP v_LOOP_2DBIND_2D949_6; 
LP v_I_5; LP v_KEY3729_4; LP v_N_3; 
LP v_ARG_2D1_0; LP v_ARGS_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 

RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_ARG_2D1_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
RESTVIFY(v_ARGS_1,2,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_3 = ICALL(s_lsp_LENGTH) (1, v_ARGS_1);
v_KEY3729_4 = v_N_3;
t1 = ICALL(s_lsp_EQL) (2, v_KEY3729_4, (LP) 0);
if (t1 != NIL) {
return(v_ARG_2D1_0);
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY3729_4, (LP) 2);
if (t2 != NIL) {
t3 = ((LP) DEREF((v_ARGS_1) + 0 * 4));
t0 = ICALL(s_lsp_LOGEQV_2F2) (MV_CALL(argc,2), v_ARG_2D1_0, t3);
return(t0);
} else {
v_I_5 = (LP) 2;
t4 = ((LP) DEREF((v_ARGS_1) + 0 * 4));
t5 = ((LP) DEREF((v_ARGS_1) + 1 * 4));
v_RESULT_7 = ICALL(s_lsp_LOGEQV_2F2) (2, t4, t5);
v_LOOP_2DITER_2DFLAG_2D950_8 = LREF(s_lsp_T);
t_NEXT_2DLOOP_10:;
if (((int) (v_I_5) >= (int) (v_N_3))) {
goto t_END_2DLOOP_11;
}
if (v_LOOP_2DITER_2DFLAG_2D950_8 == NIL) {
t8 = ((LP) DEREF((v_ARGS_1) + FX_TO_INT(v_I_5) * 4));
v_RESULT_7 = ICALL(s_lsp_LOGEQV_2F2) (2, v_RESULT_7, t8);
}
v_LOOP_2DITER_2DFLAG_2D950_8 = LREF(s_lsp_NIL);
v_I_5 = (((LP) ((int) (v_I_5) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_10;
goto t_END_2DLOOP_11;
t_END_2DLOOP_11:;
t6 = v_RESULT_7;
goto b_NIL_9;
t6 = NIL;
b_NIL_9:;
t0 = ICALL(s_lsp_LOGEQV_2F2) (MV_CALL(argc,2), v_ARG_2D1_0, t6);
return(t0);
}
}
}

LP p_lsp_LOGIOR_2F2(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_FIXNUMP) (1, v_X_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_X_0, LREF(s_lsp_FIXNUM), (LP) 0);
}
t1 = ICALL(s_lsp_FIXNUMP) (1, v_Y_1);
if (t1 == NIL) {
ICALL(s_lsp_WTA) (3, v_Y_1, LREF(s_lsp_FIXNUM), (LP) 0);
}
t2 = (((LP) ((int) (v_X_0) | (int) (v_Y_1))));
return(t2);
}

LP p_lsp_LOGIOR(va_alist) va_dcl
{
LP v_Y_22; LP v_X_21; LP v_Y_19; 
LP v_X_18; LP v_LOOP_2DITER_2DFLAG_2D952_14; LP v_RESULT_13; 
LP v_Y_11; LP v_X_10; LP v_LOOP_2DBIND_2D951_9; 
LP v_I_8; LP v_Y_6; LP v_X_5; 
LP v_KEY3730_4; LP v_N_3; LP v_ARG_2D1_0; 
LP v_ARGS_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 

RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_ARG_2D1_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
RESTVIFY(v_ARGS_1,2,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_3 = ICALL(s_lsp_LENGTH) (1, v_ARGS_1);
v_KEY3730_4 = v_N_3;
t1 = ICALL(s_lsp_EQL) (2, v_KEY3730_4, (LP) 0);
if (t1 != NIL) {
return(v_ARG_2D1_0);
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY3730_4, (LP) 2);
if (t2 != NIL) {
v_Y_6 = ((LP) DEREF((v_ARGS_1) + 0 * 4));
t0 = (((LP) ((int) (v_ARG_2D1_0) | (int) (v_Y_6))));
return(t0);
} else {
v_I_8 = (LP) 2;
v_X_10 = ((LP) DEREF((v_ARGS_1) + 0 * 4));
v_Y_11 = ((LP) DEREF((v_ARGS_1) + 1 * 4));
v_RESULT_13 = (((LP) ((int) (v_X_10) | (int) (v_Y_11))));
v_LOOP_2DITER_2DFLAG_2D952_14 = LREF(s_lsp_T);
t_NEXT_2DLOOP_16:;
if (((int) (v_I_8) >= (int) (v_N_3))) {
goto t_END_2DLOOP_17;
}
if (v_LOOP_2DITER_2DFLAG_2D952_14 == NIL) {
v_X_18 = v_RESULT_13;
v_Y_19 = ((LP) DEREF((v_ARGS_1) + FX_TO_INT(v_I_8) * 4));
v_RESULT_13 = (((LP) ((int) (v_X_18) | (int) (v_Y_19))));
}
v_LOOP_2DITER_2DFLAG_2D952_14 = LREF(s_lsp_NIL);
v_I_8 = (((LP) ((int) (v_I_8) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_16;
goto t_END_2DLOOP_17;
t_END_2DLOOP_17:;
v_Y_22 = v_RESULT_13;
goto b_NIL_15;
v_Y_22 = NIL;
v_Y_22 = v_Y_22;
b_NIL_15:;
t0 = (((LP) ((int) (v_ARG_2D1_0) | (int) (v_Y_22))));
return(t0);
}
}
}

LP p_lsp_LOGNAND(argc, v_I1_0, v_I2_1)
      ARGC argc;  LP v_I1_0; LP v_I2_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 2) wna(argc,2);
t1 = ICALL(s_lsp_LOGAND_2F2) (2, v_I1_0, v_I2_1);
t0 = ICALL(s_lsp_LOGNOT) (MV_CALL(argc,1), t1);
return(t0);
}

LP p_lsp_LOGNOR(argc, v_I1_0, v_I2_1)
      ARGC argc;  LP v_I1_0; LP v_I2_1;
{
LP v_Y_4; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
if (argc != 2) wna(argc,2);
v_X_3 = v_I1_0;
v_Y_4 = v_I2_1;
t1 = (((LP) ((int) (v_I1_0) | (int) (v_I2_1))));
t0 = ICALL(s_lsp_LOGNOT) (MV_CALL(argc,1), t1);
return(t0);
}

LP p_lsp_LOGNOT(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_FIXNUMP) (1, v_X_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_X_0, LREF(s_lsp_FIXNUM), (LP) 0);
}
t1 = INT_TO_FX(((int) ~(FX_TO_INT(v_X_0))));
return(t1);
}

LP p_lsp_LOGBITP(argc, v_INDEX_0, v_N_1)
      ARGC argc;  LP v_INDEX_0; LP v_N_1;
{
LP v_POSITION_9; LP v_SIZE_8; LP v_POSITION_7; 
LP v_SIZE_6; LP v_POSITION_4; LP v_SIZE_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_FIXNUMP) (1, v_INDEX_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_INDEX_0, LREF(s_lsp_FIXNUM), (LP) 0);
}
t1 = ICALL(s_lsp_INTEGERP) (1, v_N_1);
if (t1 == NIL) {
ICALL(s_lsp_WTA) (3, v_N_1, LREF(s_lsp_INTEGER), (LP) 0);
}
t4 = ICALL(s_lsp_FIXNUMP) (1, v_N_1);
if (t4 != NIL) {
t3 = (lessp((v_INDEX_0), ((LP) 64)));
} else {
t3 = LREF(s_lsp_NIL);
}
if (t3 != NIL) {
t2 = ( ((((unsigned long) FX_TO_INT(v_N_1)) >> FX_TO_INT(v_INDEX_0)) & 1) ? T : NIL);
return(t2);
} else {
v_SIZE_3 = (LP) 2;
v_POSITION_4 = v_INDEX_0;
v_SIZE_8 = (LP) 2;
v_POSITION_9 = v_INDEX_0;
t5 = ICALL(s_lsp_MAKE_2DBYTE_2F2) (2, (LP) 2, v_INDEX_0);
t2 = ICALL(s_lsp_LDB_2DTEST) (MV_CALL(argc,2), t5, v_N_1);
return(t2);
}
}

LP p_lsp_LOGTEST(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 2) wna(argc,2);
t2 = ICALL(s_lsp_LOGAND_2F2) (2, v_X_0, v_Y_1);
t1 = (num_equal_p((t2), ((LP) 0)));
t0 = ICALL(s_lsp_NOT) (MV_CALL(argc,1), t1);
return(t0);
}

LP p_lsp_LOGORC1(argc, v_I1_0, v_I2_1)
      ARGC argc;  LP v_I1_0; LP v_I2_1;
{
LP v_Y_6; LP v_X_5; LP v_X_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 2) wna(argc,2);
v_X_3 = v_I1_0;
v_X_5 = INT_TO_FX(((int) ~(FX_TO_INT(v_I1_0))));
t0 = (((LP) ((int) (v_X_5) | (int) (v_I2_1))));
return(t0);
}

LP p_lsp_LOGORC2(argc, v_I1_0, v_I2_1)
      ARGC argc;  LP v_I1_0; LP v_I2_1;
{
LP v_Y_6; LP v_X_5; LP v_X_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 2) wna(argc,2);
v_X_3 = v_I2_1;
v_Y_6 = INT_TO_FX(((int) ~(FX_TO_INT(v_I2_1))));
t0 = (((LP) ((int) (v_I1_0) | (int) (v_Y_6))));
return(t0);
}

LP p_lsp_LOGXOR_2F2(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_FIXNUMP) (1, v_X_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_X_0, LREF(s_lsp_FIXNUM), (LP) 0);
}
t1 = ICALL(s_lsp_FIXNUMP) (1, v_Y_1);
if (t1 == NIL) {
ICALL(s_lsp_WTA) (3, v_Y_1, LREF(s_lsp_FIXNUM), (LP) 0);
}
t2 = (((LP) ((int) (v_X_0) ^ (int) (v_Y_1))));
return(t2);
}

LP p_lsp_LOGXOR(va_alist) va_dcl
{
LP v_Y_22; LP v_X_21; LP v_Y_19; 
LP v_X_18; LP v_LOOP_2DITER_2DFLAG_2D954_14; LP v_RESULT_13; 
LP v_Y_11; LP v_X_10; LP v_LOOP_2DBIND_2D953_9; 
LP v_I_8; LP v_Y_6; LP v_X_5; 
LP v_KEY3731_4; LP v_N_3; LP v_ARG_2D1_0; 
LP v_ARGS_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 

RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_ARG_2D1_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
RESTVIFY(v_ARGS_1,2,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_3 = ICALL(s_lsp_LENGTH) (1, v_ARGS_1);
v_KEY3731_4 = v_N_3;
t1 = ICALL(s_lsp_EQL) (2, v_KEY3731_4, (LP) 0);
if (t1 != NIL) {
return(v_ARG_2D1_0);
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY3731_4, (LP) 2);
if (t2 != NIL) {
v_Y_6 = ((LP) DEREF((v_ARGS_1) + 0 * 4));
t0 = (((LP) ((int) (v_ARG_2D1_0) ^ (int) (v_Y_6))));
return(t0);
} else {
v_I_8 = (LP) 2;
v_X_10 = ((LP) DEREF((v_ARGS_1) + 0 * 4));
v_Y_11 = ((LP) DEREF((v_ARGS_1) + 1 * 4));
v_RESULT_13 = (((LP) ((int) (v_X_10) ^ (int) (v_Y_11))));
v_LOOP_2DITER_2DFLAG_2D954_14 = LREF(s_lsp_T);
t_NEXT_2DLOOP_16:;
if (((int) (v_I_8) >= (int) (v_N_3))) {
goto t_END_2DLOOP_17;
}
if (v_LOOP_2DITER_2DFLAG_2D954_14 == NIL) {
v_X_18 = v_RESULT_13;
v_Y_19 = ((LP) DEREF((v_ARGS_1) + FX_TO_INT(v_I_8) * 4));
v_RESULT_13 = (((LP) ((int) (v_X_18) ^ (int) (v_Y_19))));
}
v_LOOP_2DITER_2DFLAG_2D954_14 = LREF(s_lsp_NIL);
v_I_8 = (((LP) ((int) (v_I_8) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_16;
goto t_END_2DLOOP_17;
t_END_2DLOOP_17:;
v_Y_22 = v_RESULT_13;
goto b_NIL_15;
v_Y_22 = NIL;
v_Y_22 = v_Y_22;
b_NIL_15:;
t0 = (((LP) ((int) (v_ARG_2D1_0) ^ (int) (v_Y_22))));
return(t0);
}
}
}

LP p_lsp_MAKE_2DRATIO(argc, v_NUMERATOR_0, v_DENOMINATOR_1)
      ARGC argc;  LP v_NUMERATOR_0; LP v_DENOMINATOR_1;
{
LP v_R_6; LP v_D_5; LP v_N_4; 
LP v_GCD_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 

if (argc != 2) wna(argc,2);
v_GCD_3 = ICALL(s_lsp_GCD_2F2) (2, v_NUMERATOR_0, v_DENOMINATOR_1);
v_N_4 = (divide((v_NUMERATOR_0), (v_GCD_3)));
v_D_5 = (divide((v_DENOMINATOR_1), (v_GCD_3)));
t1 = (num_equal_p((v_D_5), ((LP) 2)));
if (t1 != NIL) {
return(v_N_4);
} else {
t2 = (num_equal_p((v_N_4), ((LP) 0)));
if (t2 != NIL) {
return((LP) 0);
} else {
t3 = (num_equal_p((v_D_5), ((LP) 0)));
if (t3 != NIL) {
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,3), LREF(k2412), v_N_4, v_D_5);
return(t0);
} else {
v_R_6 = (alloc_words(2, 9));
((LP) (DEREF((v_R_6) + 0 * 4) = (LD) (v_N_4)));
((LP) (DEREF((v_R_6) + 1 * 4) = (LD) (v_D_5)));
return(v_R_6);
}
}
}
}

LP p_lsp_MAX_2F2(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 2) wna(argc,2);
t1 = (greaterp((v_X_0), (v_Y_1)));
if (t1 != NIL) {
return(v_X_0);
} else {
return(v_Y_1);
}
}

LP p_lsp_MAX(va_alist) va_dcl
{
LP v_Y_22; LP v_X_21; LP v_Y_19; 
LP v_X_18; LP v_LOOP_2DITER_2DFLAG_2D956_14; LP v_RESULT_13; 
LP v_Y_11; LP v_X_10; LP v_LOOP_2DBIND_2D955_9; 
LP v_I_8; LP v_Y_6; LP v_X_5; 
LP v_KEY3732_4; LP v_N_3; LP v_ARG_2D1_0; 
LP v_ARGS_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; 
RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_ARG_2D1_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
RESTVIFY(v_ARGS_1,2,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_3 = ICALL(s_lsp_LENGTH) (1, v_ARGS_1);
v_KEY3732_4 = v_N_3;
t1 = ICALL(s_lsp_EQL) (2, v_KEY3732_4, (LP) 0);
if (t1 != NIL) {
return(v_ARG_2D1_0);
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY3732_4, (LP) 2);
if (t2 != NIL) {
v_X_5 = v_ARG_2D1_0;
v_Y_6 = ((LP) DEREF((v_ARGS_1) + 0 * 4));
t3 = (greaterp((v_X_5), (v_Y_6)));
if (t3 != NIL) {
return(v_X_5);
} else {
return(v_Y_6);
}
} else {
v_X_21 = v_ARG_2D1_0;
v_I_8 = (LP) 2;
v_X_10 = ((LP) DEREF((v_ARGS_1) + 0 * 4));
v_Y_11 = ((LP) DEREF((v_ARGS_1) + 1 * 4));
t4 = (greaterp((v_X_10), (v_Y_11)));
if (t4 != NIL) {
v_RESULT_13 = v_X_10;
} else {
v_RESULT_13 = v_Y_11;
}
v_LOOP_2DITER_2DFLAG_2D956_14 = LREF(s_lsp_T);
t_NEXT_2DLOOP_16:;
if (((int) (v_I_8) >= (int) (v_N_3))) {
goto t_END_2DLOOP_17;
}
if (v_LOOP_2DITER_2DFLAG_2D956_14 == NIL) {
v_X_18 = v_RESULT_13;
v_Y_19 = ((LP) DEREF((v_ARGS_1) + FX_TO_INT(v_I_8) * 4));
t6 = (greaterp((v_X_18), (v_Y_19)));
if (t6 != NIL) {
v_RESULT_13 = v_X_18;
} else {
v_RESULT_13 = v_Y_19;
}
}
v_LOOP_2DITER_2DFLAG_2D956_14 = LREF(s_lsp_NIL);
v_I_8 = (((LP) ((int) (v_I_8) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_16;
goto t_END_2DLOOP_17;
t_END_2DLOOP_17:;
v_Y_22 = v_RESULT_13;
goto b_NIL_15;
v_Y_22 = NIL;
v_Y_22 = v_Y_22;
b_NIL_15:;
t7 = (greaterp((v_X_21), (v_Y_22)));
if (t7 != NIL) {
return(v_X_21);
} else {
return(v_Y_22);
}
}
}
}

LP p_lsp_MIN_2F2(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 2) wna(argc,2);
t1 = (lessp((v_X_0), (v_Y_1)));
if (t1 != NIL) {
return(v_X_0);
} else {
return(v_Y_1);
}
}

LP p_lsp_MIN(va_alist) va_dcl
{
LP v_Y_22; LP v_X_21; LP v_Y_19; 
LP v_X_18; LP v_LOOP_2DITER_2DFLAG_2D958_14; LP v_RESULT_13; 
LP v_Y_11; LP v_X_10; LP v_LOOP_2DBIND_2D957_9; 
LP v_I_8; LP v_Y_6; LP v_X_5; 
LP v_KEY3733_4; LP v_N_3; LP v_ARG_2D1_0; 
LP v_ARGS_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; 
RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_ARG_2D1_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
RESTVIFY(v_ARGS_1,2,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_3 = ICALL(s_lsp_LENGTH) (1, v_ARGS_1);
v_KEY3733_4 = v_N_3;
t1 = ICALL(s_lsp_EQL) (2, v_KEY3733_4, (LP) 0);
if (t1 != NIL) {
return(v_ARG_2D1_0);
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY3733_4, (LP) 2);
if (t2 != NIL) {
v_X_5 = v_ARG_2D1_0;
v_Y_6 = ((LP) DEREF((v_ARGS_1) + 0 * 4));
t3 = (lessp((v_X_5), (v_Y_6)));
if (t3 != NIL) {
return(v_X_5);
} else {
return(v_Y_6);
}
} else {
v_X_21 = v_ARG_2D1_0;
v_I_8 = (LP) 2;
v_X_10 = ((LP) DEREF((v_ARGS_1) + 0 * 4));
v_Y_11 = ((LP) DEREF((v_ARGS_1) + 1 * 4));
t4 = (lessp((v_X_10), (v_Y_11)));
if (t4 != NIL) {
v_RESULT_13 = v_X_10;
} else {
v_RESULT_13 = v_Y_11;
}
v_LOOP_2DITER_2DFLAG_2D958_14 = LREF(s_lsp_T);
t_NEXT_2DLOOP_16:;
if (((int) (v_I_8) >= (int) (v_N_3))) {
goto t_END_2DLOOP_17;
}
if (v_LOOP_2DITER_2DFLAG_2D958_14 == NIL) {
v_X_18 = v_RESULT_13;
v_Y_19 = ((LP) DEREF((v_ARGS_1) + FX_TO_INT(v_I_8) * 4));
t6 = (lessp((v_X_18), (v_Y_19)));
if (t6 != NIL) {
v_RESULT_13 = v_X_18;
} else {
v_RESULT_13 = v_Y_19;
}
}
v_LOOP_2DITER_2DFLAG_2D958_14 = LREF(s_lsp_NIL);
v_I_8 = (((LP) ((int) (v_I_8) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_16;
goto t_END_2DLOOP_17;
t_END_2DLOOP_17:;
v_Y_22 = v_RESULT_13;
goto b_NIL_15;
v_Y_22 = NIL;
v_Y_22 = v_Y_22;
b_NIL_15:;
t7 = (lessp((v_X_21), (v_Y_22)));
if (t7 != NIL) {
return(v_X_21);
} else {
return(v_Y_22);
}
}
}
}

LP p_lsp__2D(va_alist) va_dcl
{
LP v_LOOP_2DITER_2DFLAG_2D960_11; LP v_RESULT_10; LP v_LOOP_2DBIND_2D959_9; 
LP v_I_8; LP v_X_6; LP v_LIST_4; 
LP v_KEY3734_3; LP v_N_2; LP v_ARGS_0; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 

RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTVIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_2 = ICALL(s_lsp_LENGTH) (1, v_ARGS_0);
v_KEY3734_3 = v_N_2;
t1 = ICALL(s_lsp_EQL) (2, v_KEY3734_3, (LP) 0);
if (t1 != NIL) {
return((LP) 0);
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY3734_3, (LP) 2);
if (t2 != NIL) {
v_LIST_4 = v_ARGS_0;
v_X_6 = v_ARGS_0;
t3 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t0 = (subtract(((LP) 0), (t3)));
return(t0);
} else {
v_I_8 = (LP) 2;
t4 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t5 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
v_RESULT_10 = (subtract((t4), (t5)));
v_LOOP_2DITER_2DFLAG_2D960_11 = LREF(s_lsp_T);
t_NEXT_2DLOOP_13:;
if (((int) (v_I_8) >= (int) (v_N_2))) {
goto t_END_2DLOOP_14;
}
if (v_LOOP_2DITER_2DFLAG_2D960_11 == NIL) {
t7 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(v_I_8) * 4));
v_RESULT_10 = (subtract((v_RESULT_10), (t7)));
}
v_LOOP_2DITER_2DFLAG_2D960_11 = LREF(s_lsp_NIL);
v_I_8 = (((LP) ((int) (v_I_8) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_13;
goto t_END_2DLOOP_14;
t_END_2DLOOP_14:;
return(v_RESULT_10);
return(NIL);
return(NIL);
}
}
}

LP p_lsp_MINUSP(argc, v_N_0)
      ARGC argc;  LP v_N_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = (lessp((v_N_0), ((LP) 0)));
return(t0);
}

LP p_lsp_MOD(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 

if (argc != 2) wna(argc,2);
t2 = ICALL(s_lsp_FIXNUMP) (1, v_X_0);
if (t2 != NIL) {
t1 = ICALL(s_lsp_FIXNUMP) (1, v_Y_1);
} else {
t1 = LREF(s_lsp_NIL);
}
if (t1 != NIL) {
t0 = ((LP) ((int) (v_X_0) % (int) (v_Y_1)));
return(t0);
} else {
t3 = ICALL(s_lsp_ENSURE_2DBIGNUM) (1, v_X_0);
t4 = ICALL(s_lsp_ENSURE_2DBIGNUM) (1, v_Y_1);
t0 = (bignum_rem((t3), (t4)));
return(t0);
}
}

LP p_lsp__3D(va_alist) va_dcl
{
LP v_LOOP_2DITER_2DFLAG_2D962_7; LP v_RESULT_6; LP v_LOOP_2DBIND_2D961_5; 
LP v_I_4; LP v_KEY3735_3; LP v_N_2; 
LP v_ARGS_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; 
RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTVIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_2 = ICALL(s_lsp_LENGTH) (1, v_ARGS_0);
v_KEY3735_3 = v_N_2;
t1 = ICALL(s_lsp_MEMQL) (2, v_KEY3735_3, LREF(k2407));
if (t1 != NIL) {
return(LREF(s_lsp_T));
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY3735_3, (LP) 4);
if (t2 != NIL) {
t3 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t4 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
t0 = (num_equal_p((t3), (t4)));
return(t0);
} else {
v_I_4 = (LP) 2;
t5 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t6 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
v_RESULT_6 = (num_equal_p((t5), (t6)));
v_LOOP_2DITER_2DFLAG_2D962_7 = LREF(s_lsp_T);
t_NEXT_2DLOOP_9:;
if (((int) (v_I_4) >= (int) (v_N_2))) {
goto t_END_2DLOOP_10;
}
if (v_LOOP_2DITER_2DFLAG_2D962_7 == NIL) {
t9 = (subtract((v_I_4), ((LP) 2)));
t8 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(t9) * 4));
t10 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(v_I_4) * 4));
v_RESULT_6 = (num_equal_p((t8), (t10)));
}
if (v_RESULT_6 == NIL) {
return(v_RESULT_6);
return(NIL);
}
v_LOOP_2DITER_2DFLAG_2D962_7 = LREF(s_lsp_NIL);
v_I_4 = (((LP) ((int) (v_I_4) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_9;
goto t_END_2DLOOP_10;
t_END_2DLOOP_10:;
return(v_RESULT_6);
return(NIL);
return(NIL);
}
}
}

LP p_lsp_NUM_2DNOT_2DEQUAL_2DP(argc, v_N1_0, v_N2_1)
      ARGC argc;  LP v_N1_0; LP v_N2_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 2) wna(argc,2);
t1 = (num_equal_p((v_N1_0), (v_N2_1)));
t0 = ICALL(s_lsp_NOT) (MV_CALL(argc,1), t1);
return(t0);
}

LP p_lsp__2F_3D(va_alist) va_dcl
{
LP v_LOOP_2DITER_2DFLAG_2D964_7; LP v_RESULT_6; LP v_LOOP_2DBIND_2D963_5; 
LP v_I_4; LP v_KEY3736_3; LP v_N_2; 
LP v_ARGS_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; 
RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTVIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_2 = ICALL(s_lsp_LENGTH) (1, v_ARGS_0);
v_KEY3736_3 = v_N_2;
t1 = ICALL(s_lsp_MEMQL) (2, v_KEY3736_3, LREF(k2407));
if (t1 != NIL) {
return(LREF(s_lsp_T));
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY3736_3, (LP) 4);
if (t2 != NIL) {
t3 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t4 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
t0 = ICALL(s_lsp_NUM_2DNOT_2DEQUAL_2DP) (MV_CALL(argc,2), t3, t4);
return(t0);
} else {
v_I_4 = (LP) 2;
t5 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t6 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
v_RESULT_6 = ICALL(s_lsp_NUM_2DNOT_2DEQUAL_2DP) (2, t5, t6);
v_LOOP_2DITER_2DFLAG_2D964_7 = LREF(s_lsp_T);
t_NEXT_2DLOOP_9:;
if (((int) (v_I_4) >= (int) (v_N_2))) {
goto t_END_2DLOOP_10;
}
if (v_LOOP_2DITER_2DFLAG_2D964_7 == NIL) {
t9 = (subtract((v_I_4), ((LP) 2)));
t8 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(t9) * 4));
t10 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(v_I_4) * 4));
v_RESULT_6 = ICALL(s_lsp_NUM_2DNOT_2DEQUAL_2DP) (2, t8, t10);
}
if (v_RESULT_6 == NIL) {
return(v_RESULT_6);
return(NIL);
}
v_LOOP_2DITER_2DFLAG_2D964_7 = LREF(s_lsp_NIL);
v_I_4 = (((LP) ((int) (v_I_4) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_9;
goto t_END_2DLOOP_10;
t_END_2DLOOP_10:;
return(v_RESULT_6);
return(NIL);
return(NIL);
}
}
}

LP p_lsp_NUMERATOR(argc, v_R_0)
      ARGC argc;  LP v_R_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_RATIOP) (1, v_R_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_R_0, LREF(s_lsp_RATIO), (LP) 0);
}
t1 = ((LP) DEREF((v_R_0) + 0 * 4));
return(t1);
}

LP p_lsp_DENOMINATOR(argc, v_R_0)
      ARGC argc;  LP v_R_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_RATIOP) (1, v_R_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_R_0, LREF(s_lsp_RATIO), (LP) 0);
}
t1 = ((LP) DEREF((v_R_0) + 1 * 4));
return(t1);
}

LP p_lsp_ODDP(argc, v_INTEGER_0)
      ARGC argc;  LP v_INTEGER_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_EVENP) (1, v_INTEGER_0);
t0 = ICALL(s_lsp_NOT) (MV_CALL(argc,1), t1);
return(t0);
}

LP p_lsp_1_2D(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = (subtract((v_X_0), ((LP) 2)));
return(t0);
}

LP p_lsp_1_2B(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = (add((v_X_0), ((LP) 2)));
return(t0);
}

LP p_lsp__2B(va_alist) va_dcl
{
LP v_LOOP_2DITER_2DFLAG_2D966_11; LP v_RESULT_10; LP v_LOOP_2DBIND_2D965_9; 
LP v_I_8; LP v_X_6; LP v_LIST_4; 
LP v_KEY3737_3; LP v_N_2; LP v_ARGS_0; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; 
RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTVIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_2 = ICALL(s_lsp_LENGTH) (1, v_ARGS_0);
v_KEY3737_3 = v_N_2;
t1 = ICALL(s_lsp_EQL) (2, v_KEY3737_3, (LP) 0);
if (t1 != NIL) {
return((LP) 0);
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY3737_3, (LP) 2);
if (t2 != NIL) {
v_LIST_4 = v_ARGS_0;
v_X_6 = v_ARGS_0;
t0 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
return(t0);
} else {
v_I_8 = (LP) 2;
t3 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t4 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
v_RESULT_10 = (add((t3), (t4)));
v_LOOP_2DITER_2DFLAG_2D966_11 = LREF(s_lsp_T);
t_NEXT_2DLOOP_13:;
if (((int) (v_I_8) >= (int) (v_N_2))) {
goto t_END_2DLOOP_14;
}
if (v_LOOP_2DITER_2DFLAG_2D966_11 == NIL) {
t6 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(v_I_8) * 4));
v_RESULT_10 = (add((v_RESULT_10), (t6)));
}
v_LOOP_2DITER_2DFLAG_2D966_11 = LREF(s_lsp_NIL);
v_I_8 = (((LP) ((int) (v_I_8) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_13;
goto t_END_2DLOOP_14;
t_END_2DLOOP_14:;
return(v_RESULT_10);
return(NIL);
return(NIL);
}
}
}

LP p_lsp_PLUSP(argc, v_N_0)
      ARGC argc;  LP v_N_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = (greaterp((v_N_0), ((LP) 0)));
return(t0);
}

LP p_lsp_RATIONALIZE(argc, v_N_0)
      ARGC argc;  LP v_N_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_RATIONAL) (MV_CALL(argc,1), v_N_0);
return(t0);
}

LP p_lsp_RATIONAL(argc, v_N_0)
      ARGC argc;  LP v_N_0;
{
LP v_KEY3738_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; 
if (argc != 1) wna(argc,1);
v_KEY3738_2 = v_N_0;
t1 = ICALL(s_lsp_INTEGER_2DRANGE_2DP) (3, v_KEY3738_2, LREF(s_lsp__2A), LREF(s_lsp__2A));
if (t1 != NIL) {
return(v_N_0);
} else {
t2 = ICALL(s_lsp_FLOATP) (1, v_KEY3738_2);
if (t2 != NIL) {
t0 = ICALL(s_lsp_RATIONAL_2FFLOAT) (MV_CALL(argc,1), v_N_0);
return(t0);
} else {
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,2), LREF(k2413), v_N_0);
return(t0);
}
}
}

LP p_lsp_RATIONAL_2FFLOAT(argc, v_F_0)
      ARGC argc;  LP v_F_0;
{
LP v_FRACTION_3; LP v_WHOLE_2; 
LP t0; LP t1; LP t2; 
if (argc != 1) wna(argc,1);
{
int real_argc;
BEGIN_MV_CALL(mv_holder2414,0);
t0 = ICALL(s_lsp_TRUNCATE) (MV_CALL(mv_holder2414,1), v_F_0);
SET_MV_RETURN_VALUE(mv_holder2414,0,t0);
if SV_RETURN_P(mv_holder2414) SET_MV_RETURN_COUNT(mv_holder2414,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder2414);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_WHOLE_2 = NIL;
} else {
v_WHOLE_2 = NEXT_VAR_VALUE(mv_holder2414);
}
if (real_argc < 2) {
v_FRACTION_3 = NIL;
} else {
v_FRACTION_3 = NEXT_VAR_VALUE(mv_holder2414);
}
END_VAR_VALUES;
END_MV_CALL;
ICALL(s_lsp_WARN) (3, LREF(k2415), v_F_0, v_WHOLE_2);
return(v_WHOLE_2);
}
}

LP p_lsp_REALPART(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_COMPLEXP) (1, v_C_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_C_0, LREF(s_lsp_COMPLEX), (LP) 0);
}
t1 = ((LP) DEREF((v_C_0) + 0 * 4));
return(t1);
}

LP p_lsp_REM(argc, v_X_0, v_Y_1)
      ARGC argc;  LP v_X_0; LP v_Y_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; 
if (argc != 2) wna(argc,2);
t2 = ICALL(s_lsp_FIXNUMP) (1, v_X_0);
if (t2 != NIL) {
t1 = ICALL(s_lsp_FIXNUMP) (1, v_Y_1);
} else {
t1 = LREF(s_lsp_NIL);
}
if (t1 != NIL) {
t0 = ((LP) ((int) (v_X_0) % (int) (v_Y_1)));
return(t0);
} else {
t3 = ICALL(s_lsp_ENSURE_2DBIGNUM) (1, v_X_0);
t4 = ICALL(s_lsp_ENSURE_2DBIGNUM) (1, v_Y_1);
t0 = (bignum_rem((t3), (t4)));
return(t0);
}
}

LP p_lsp_ROUND_2F2(argc, v_NUMBER_0, v_DIVISOR_1)
      ARGC argc;  LP v_NUMBER_0; LP v_DIVISOR_1;
{
LP v_G3740_12; LP v_G3739_11; LP v__2DTHRESH_10; 
LP v_N_8; LP v_N_6; LP v_THRESH_5; 
LP v_REM_4; LP v_TRU_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; 
if (argc != 2) wna(argc,2);
{
int real_argc;
BEGIN_MV_CALL(mv_holder2416,0);
t0 = ICALL(s_lsp_TRUNCATE) (MV_CALL(mv_holder2416,2), v_NUMBER_0, v_DIVISOR_1);
SET_MV_RETURN_VALUE(mv_holder2416,0,t0);
if SV_RETURN_P(mv_holder2416) SET_MV_RETURN_COUNT(mv_holder2416,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder2416);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_TRU_3 = NIL;
} else {
v_TRU_3 = NEXT_VAR_VALUE(mv_holder2416);
}
if (real_argc < 2) {
v_REM_4 = NIL;
} else {
v_REM_4 = NEXT_VAR_VALUE(mv_holder2416);
}
END_VAR_VALUES;
END_MV_CALL;
t1 = ICALL(s_lsp_ABS) (1, v_DIVISOR_1);
v_THRESH_5 = (divide((t1), ((LP) 4)));
v_G3740_12 = (greaterp((v_REM_4), (v_THRESH_5)));
if (v_G3740_12 != NIL) {
t3 = v_G3740_12;
} else {
t4 = (num_equal_p((v_REM_4), (v_THRESH_5)));
if (t4 != NIL) {
t3 = ICALL(s_lsp_ODDP) (1, v_TRU_3);
} else {
t3 = LREF(s_lsp_NIL);
}
}
if (t3 != NIL) {
v_N_6 = v_DIVISOR_1;
t5 = (lessp((v_DIVISOR_1), ((LP) 0)));
if (t5 != NIL) {
t6 = (subtract((v_TRU_3), ((LP) 2)));
t7 = (add((v_REM_4), (v_DIVISOR_1)));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,t7);
}
return(t6);
} else {
t8 = (add((v_TRU_3), ((LP) 2)));
t9 = (subtract((v_REM_4), (v_DIVISOR_1)));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,t9);
}
return(t8);
}
} else {
v__2DTHRESH_10 = (subtract(((LP) 0), (v_THRESH_5)));
v_G3739_11 = (lessp((v_REM_4), (v__2DTHRESH_10)));
if (v_G3739_11 != NIL) {
t10 = v_G3739_11;
} else {
t11 = (num_equal_p((v_REM_4), (v__2DTHRESH_10)));
if (t11 != NIL) {
t10 = ICALL(s_lsp_ODDP) (1, v_TRU_3);
} else {
t10 = LREF(s_lsp_NIL);
}
}
if (t10 != NIL) {
v_N_8 = v_DIVISOR_1;
t12 = (lessp((v_DIVISOR_1), ((LP) 0)));
if (t12 != NIL) {
t13 = (add((v_TRU_3), ((LP) 2)));
t14 = (subtract((v_REM_4), (v_DIVISOR_1)));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,t14);
}
return(t13);
} else {
t15 = (subtract((v_TRU_3), ((LP) 2)));
t16 = (add((v_REM_4), (v_DIVISOR_1)));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,t16);
}
return(t15);
}
} else {
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,v_REM_4);
}
return(v_TRU_3);
}
}
}
}

LP p_lsp_ROUND(va_alist) va_dcl
{
LP v_N_0; LP v_DIVISOR_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_N_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_DIVISOR_1 = (LP) 2;
} else {
v_DIVISOR_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t0 = ICALL(s_lsp_ROUND_2F2) (MV_CALL(argc,2), v_N_0, v_DIVISOR_1);
return(t0);
}

LP p_lsp_SCALE_2DFLOAT(argc, v_X_0, v_EXPONENT_1)
      ARGC argc;  LP v_X_0; LP v_EXPONENT_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_FLOATP) (1, v_X_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_X_0, LREF(s_lsp_FLOAT), (LP) 0);
}
t1 = ICALL(s_lsp_FIXNUMP) (1, v_EXPONENT_1);
if (t1 == NIL) {
ICALL(s_lsp_WTA) (3, v_EXPONENT_1, LREF(s_lsp_FIXNUM), (LP) 0);
}
t2 = NEW_FLOAT(ldexp(RAW_FLOAT(v_X_0), FX_TO_INT(v_EXPONENT_1)));
return(t2);
}

LP p_lsp_SIGNUM(argc, v_N_0)
      ARGC argc;  LP v_N_0;
{
LP v_N_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; 
if (argc != 1) wna(argc,1);
t1 = (num_equal_p((v_N_0), ((LP) 0)));
if (t1 != NIL) {
return(v_N_0);
} else {
t2 = ICALL(s_lsp_RATIONALP) (1, v_N_0);
if (t2 != NIL) {
v_N_2 = v_N_0;
t3 = (greaterp((v_N_0), ((LP) 0)));
if (t3 != NIL) {
return((LP) 2);
} else {
return((LP) -2);
}
} else {
t4 = ICALL(s_lsp_ABS) (1, v_N_0);
t0 = (divide((v_N_0), (t4)));
return(t0);
}
}
}

LP p_lsp_SIN(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{
LP v_OTHER_5; LP v_N_4; LP v_N_2; 
LP v_OTHER_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; 
if (argc != 1) wna(argc,1);
v_N_4 = v_X_0;
v_OTHER_5 = LREF(s_lsp_NIL);
t1 = ICALL(s_lsp_FLOAT_2D1) (1, v_X_0);
t0 = NEW_FLOAT(sin(RAW_FLOAT(t1)));
return(t0);
}

LP p_lsp_SQRT(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{
LP v_N_17; LP v_OTHER_15; LP v_N_14; 
LP v_N_12; LP v_OTHER_13; LP v_IMAGPART_10; 
LP v_REALPART_9; LP v_OTHER_7; LP v_N_6; 
LP v_N_4; LP v_OTHER_5; LP v_REALPART_2; 
LP v_IMAGPART_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; 
if (argc != 1) wna(argc,1);
v_N_17 = v_X_0;
t1 = (lessp((v_X_0), ((LP) 0)));
if (t1 != NIL) {
v_N_6 = (subtract(((LP) 0), (v_X_0)));
t2 = ICALL(s_lsp_FLOAT_2D1) (1, v_N_6);
v_IMAGPART_10 = NEW_FLOAT(sqrt(RAW_FLOAT(t2)));
t0 = ICALL(s_lsp_MAKE_2DCOMPLEX) (MV_CALL(argc,2), (LP) 0, v_IMAGPART_10);
return(t0);
} else {
v_N_14 = v_X_0;
v_OTHER_15 = LREF(s_lsp_NIL);
t3 = ICALL(s_lsp_FLOAT_2D1) (1, v_X_0);
t0 = NEW_FLOAT(sqrt(RAW_FLOAT(t3)));
return(t0);
}
}

LP p_lsp_TAN(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{
LP v_OTHER_5; LP v_N_4; LP v_N_2; 
LP v_OTHER_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; 
if (argc != 1) wna(argc,1);
v_N_4 = v_X_0;
v_OTHER_5 = LREF(s_lsp_NIL);
t1 = ICALL(s_lsp_FLOAT_2D1) (1, v_X_0);
t0 = NEW_FLOAT(tan(RAW_FLOAT(t1)));
return(t0);
}

LP p_lsp__2A(va_alist) va_dcl
{
LP v_LOOP_2DITER_2DFLAG_2D968_8; LP v_RESULT_7; LP v_LOOP_2DBIND_2D967_6; 
LP v_I_5; LP v_KEY3741_4; LP v_N_3; 
LP v_X_0; LP v_OTHERS_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 

RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_X_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
RESTVIFY(v_OTHERS_1,2,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_3 = ICALL(s_lsp_LENGTH) (1, v_OTHERS_1);
v_KEY3741_4 = v_N_3;
t1 = ICALL(s_lsp_EQL) (2, v_KEY3741_4, (LP) 0);
if (t1 != NIL) {
return(v_X_0);
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY3741_4, (LP) 2);
if (t2 != NIL) {
t3 = ((LP) DEREF((v_OTHERS_1) + 0 * 4));
t0 = (multiply((v_X_0), (t3)));
return(t0);
} else {
v_I_5 = (LP) 2;
t4 = ((LP) DEREF((v_OTHERS_1) + 0 * 4));
t5 = ((LP) DEREF((v_OTHERS_1) + 1 * 4));
v_RESULT_7 = (multiply((t4), (t5)));
v_LOOP_2DITER_2DFLAG_2D968_8 = LREF(s_lsp_T);
t_NEXT_2DLOOP_10:;
if (((int) (v_I_5) >= (int) (v_N_3))) {
goto t_END_2DLOOP_11;
}
if (v_LOOP_2DITER_2DFLAG_2D968_8 == NIL) {
t8 = ((LP) DEREF((v_OTHERS_1) + FX_TO_INT(v_I_5) * 4));
v_RESULT_7 = (multiply((v_RESULT_7), (t8)));
}
v_LOOP_2DITER_2DFLAG_2D968_8 = LREF(s_lsp_NIL);
v_I_5 = (((LP) ((int) (v_I_5) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_10;
goto t_END_2DLOOP_11;
t_END_2DLOOP_11:;
t6 = v_RESULT_7;
goto b_NIL_9;
t6 = NIL;
b_NIL_9:;
t0 = (multiply((v_X_0), (t6)));
return(t0);
}
}
}

LP p_lsp_TRUNCATE(va_alist) va_dcl
{
LP v_N_0; LP v_DIVISOR_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_N_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_DIVISOR_1 = (LP) 2;
} else {
v_DIVISOR_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t0 = ICALL(s_lsp_TRUNCATE_2F2) (MV_CALL(argc,2), v_N_0, v_DIVISOR_1);
return(t0);
}

LP p_lsp_TRUNCATE_2F2(argc, v_N_0, v_DIVISOR_1)
      ARGC argc;  LP v_N_0; LP v_DIVISOR_1;
{
LP v_OTHER_36; LP v_N_35; LP v_N_33; 
LP v_OTHER_34; LP v_KEY3751_32; LP v_KEY3750_31; 
LP v_OTHER_29; LP v_N_28; LP v_N_26; 
LP v_OTHER_27; LP v_OTHER_24; LP v_N_23; 
LP v_N_21; LP v_OTHER_22; LP v_OTHER_19; 
LP v_N_18; LP v_N_16; LP v_OTHER_17; 
LP v_OTHER_14; LP v_N_13; LP v_N_11; 
LP v_OTHER_12; LP v_KEY3749_9; LP v_KEY3746_7; 
LP v_KEY3745_5; LP v_KEY3742_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; 
if (argc != 2) wna(argc,2);
v_KEY3742_3 = v_N_0;
v_KEY3745_5 = v_KEY3742_3;
t2 = ICALL(s_lsp_FIXNUMP) (1, v_KEY3745_5);
if (t2 != NIL) {
v_KEY3746_7 = v_DIVISOR_1;
v_KEY3749_9 = v_KEY3746_7;
t4 = ICALL(s_lsp_FIXNUMP) (1, v_KEY3749_9);
if (t4 != NIL) {
t5 = ((LP) INT_TO_FX((int) (v_N_0) / (int) (v_DIVISOR_1)));
t6 = ((LP) ((int) (v_N_0) % (int) (v_DIVISOR_1)));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,t6);
}
return(t5);
} else {
t7 = INT_TO_FX(((int) TAG((v_KEY3749_9))));
switch ((int) t7) {
case 18:
v_N_13 = v_N_0;
v_OTHER_14 = LREF(s_lsp_NIL);
t8 = ICALL(s_lsp_FLOAT_2D1) (1, v_N_0);
v_N_18 = v_DIVISOR_1;
v_OTHER_19 = LREF(s_lsp_NIL);
t9 = ICALL(s_lsp_FLOAT_2D1) (1, v_DIVISOR_1);
t3 = ICALL(s_lsp_TRUNCATE_2DFLOAT_2F2) (MV_CALL(argc,2), t8, t9);
return(t3);
break;
case 10:
v_N_23 = v_N_0;
v_OTHER_24 = LREF(s_lsp_NIL);
t10 = ICALL(s_lsp_FLOAT_2D1) (1, v_N_0);
t3 = ICALL(s_lsp_TRUNCATE_2DFLOAT_2F2) (MV_CALL(argc,2), t10, v_DIVISOR_1);
return(t3);
break;
default:
goto t_DEFAULT_2DTAG3748_10;
break;
}
}
return(t3);
t_DEFAULT_2DTAG3748_10:;
t11 = ICALL(s_lsp_ERROR) (MV_CALL(argc,3), LREF(k2398), v_KEY3746_7, LREF(k2417));
return(t11);
return(NIL);
return(NIL);
} else {
t12 = INT_TO_FX(((int) TAG((v_KEY3745_5))));
switch ((int) t12) {
case 10:
v_N_28 = v_DIVISOR_1;
v_OTHER_29 = LREF(s_lsp_NIL);
t13 = ICALL(s_lsp_FLOAT_2D1) (1, v_DIVISOR_1);
t1 = ICALL(s_lsp_TRUNCATE_2DFLOAT_2F2) (MV_CALL(argc,2), v_N_0, t13);
return(t1);
break;
case 2:
v_KEY3750_31 = v_DIVISOR_1;
v_KEY3751_32 = v_KEY3750_31;
t14 = ICALL(s_lsp_INTEGERP) (1, v_KEY3751_32);
if (t14 != NIL) {
t15 = ICALL(s_lsp_BIGNUM_2DDIV) (2, v_N_0, v_DIVISOR_1);
t16 = ICALL(s_lsp_BIGNUM_2DREM) (2, v_N_0, v_DIVISOR_1);
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,t16);
}
return(t15);
} else {
t17 = ICALL(s_lsp_FLOATP) (1, v_KEY3751_32);
if (t17 != NIL) {
v_N_35 = v_N_0;
v_OTHER_36 = LREF(s_lsp_NIL);
t18 = ICALL(s_lsp_FLOAT_2D1) (1, v_N_0);
t1 = ICALL(s_lsp_TRUNCATE_2DFLOAT_2F2) (MV_CALL(argc,2), t18, v_DIVISOR_1);
return(t1);
} else {
t1 = ICALL(s_lsp_ERROR) (MV_CALL(argc,3), LREF(k2398), v_KEY3750_31, LREF(k2420));
return(t1);
}
}
break;
default:
goto t_DEFAULT_2DTAG3744_6;
break;
}
}
return(t1);
t_DEFAULT_2DTAG3744_6:;
t19 = ICALL(s_lsp_ERROR) (MV_CALL(argc,3), LREF(k2398), v_KEY3742_3, LREF(k2422));
return(t19);
return(NIL);
return(NIL);
}

LP p_lsp_TRUNCATE_2DFLOAT_2F2(argc, v_N_0, v_DIVISOR_1)
      ARGC argc;  LP v_N_0; LP v_DIVISOR_1;
{

LP t0; LP t1; LP t2; 
if (argc != 2) wna(argc,2);
t0 = INT_TO_FX(double_truncate(RAW_FLOAT(v_N_0), RAW_FLOAT(v_DIVISOR_1)));
t1 = NEW_FLOAT(fmod(RAW_FLOAT(v_N_0), RAW_FLOAT(v_DIVISOR_1)));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,t1);
}
return(t0);
}

LP p_lsp_ZEROP(argc, v_N_0)
      ARGC argc;  LP v_N_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = (num_equal_p((v_N_0), ((LP) 0)));
return(t0);
}

