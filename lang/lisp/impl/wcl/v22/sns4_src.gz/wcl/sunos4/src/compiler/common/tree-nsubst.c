/*
:comment "Compiled at 4:48:08 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: Debug Library"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O2 -fPIC"
:version 0
:end-package-info 0
:sym NIL
:sym SEQ
:sym PROC
:sym TOP-LEVEL-PROC
:sym INNER-PROC
:sym TAG-SEQ
:sym SCOPE-SEQ
:sym PROGN
:sym VALUES-SEQ
:sym NAMED-LOCAL
:sym INLINE-MV-CALL
:sym SPEC-BIND-SEQ
:sym SCOPE-CONTROL-TRANSFER
:sym TREE-NSUBST-SCOPE-CONTROL-TRANSFER
:sym UNWIND-PROTECT
:sym TREE-NSUBST-UNWIND-PROTECT
:sym VAR-DEF
:sym TREE-NSUBST-VAR-DEF
:sym MVALUES
:sym TREE-NSUBST-VALUES
:sym IF
:sym TREE-NSUBST-IF
:sym SWITCH
:sym TREE-NSUBST-SWITCH
:sym FUNCTION-CALL
:sym C-STRUCT-OP
:sym C-STRUCT-DEF
:sym C-STRUCT-REF
:sym PRIMITIVE-CALL
:sym UNNAMED-CALL
:sym FOREIGN-CALL
:sym NAMED-CALL
:sym CONTROL-POINT
:sym TAG-CONTROL-POINT
:sym DYNAMIC-TAG-CONTROL-POINT
:sym STATIC-TAG-CONTROL-POINT
:sym SCOPE-CONTROL-POINT
:sym DYNAMIC-SCOPE-CONTROL-POINT
:sym CATCH-CONTROL-POINT
:sym DYNAMIC-BLOCK-CONTROL-POINT
:sym STATIC-SCOPE-CONTROL-POINT
:sym TREE-NSUBST-SEQ
:sym TREE-NSUBST-FUNCTION-CALL
:sym TREE-NSUBST-CONTROL-POINT
:sf TREE-NSUBST "p_lsp_TREE_2DNSUBST"
:sym TREE-NSUBST
:sf TREE-NSUBST-LIST "p_lsp_TREE_2DNSUBST_2DLIST"
:sym VALUES-SEQ-P
:sym TREE-NSUBST-LIST
:sym SCOPE-SEQ-P
:sf TREE-NSUBST-SEQ "p_lsp_TREE_2DNSUBST_2DSEQ"
:sf TREE-NSUBST-VALUES "p_lsp_TREE_2DNSUBST_2DVALUES"
:sf TREE-NSUBST-VAR-DEF "p_lsp_TREE_2DNSUBST_2DVAR_2DDEF"
:sym UNNAMED-CALL-P
:sf TREE-NSUBST-FUNCTION-CALL "p_lsp_TREE_2DNSUBST_2DFUNCTION_2DCALL"
:sf TREE-NSUBST-IF "p_lsp_TREE_2DNSUBST_2DIF"
:sf TREE-NSUBST-SWITCH "p_lsp_TREE_2DNSUBST_2DSWITCH"
:sf TREE-NSUBST-SCOPE-CONTROL-TRANSFER "p_lsp_TREE_2DNSUBST_2DSCOPE_2DCONTROL_2DTRANSFER"
:sym MEMQL
:sf TREE-NSUBST-CONTROL-POINT "p_lsp_TREE_2DNSUBST_2DCONTROL_2DPOINT"
:sf TREE-NSUBST-UNWIND-PROTECT "p_lsp_TREE_2DNSUBST_2DUNWIND_2DPROTECT"
:pinfo TREE-NSUBST-VALUES (NEW OLD TREE) NIL NIL NIL NIL NIL NIL T
:pinfo TREE-NSUBST (NEW OLD TREE) NIL NIL NIL NIL NIL NIL T
:pinfo TREE-NSUBST-SEQ (NEW OLD TREE) NIL NIL NIL NIL NIL NIL T
:pinfo TREE-NSUBST-IF (NEW OLD TREE) NIL NIL NIL NIL NIL NIL T
:pinfo TREE-NSUBST-CONTROL-POINT (NEW OLD TREE) NIL NIL NIL NIL NIL NIL T
:pinfo TREE-NSUBST-SWITCH (NEW OLD TREE) NIL NIL NIL NIL NIL NIL T
:pinfo TREE-NSUBST-UNWIND-PROTECT (NEW OLD TREE) NIL NIL NIL NIL NIL NIL T
:pinfo TREE-NSUBST-SCOPE-CONTROL-TRANSFER (NEW OLD TREE) NIL NIL NIL NIL NIL NIL T
:pinfo TREE-NSUBST-FUNCTION-CALL (NEW OLD TREE) NIL NIL NIL NIL NIL NIL T
:pinfo TREE-NSUBST-VAR-DEF (NEW OLD TREE) NIL NIL NIL NIL NIL NIL T
:pinfo TREE-NSUBST-LIST (NEW OLD L) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_lsp_TREE_2DNSUBST();
extern SYMBOL s_lsp_NIL; 
extern SYMBOL s_lsp_SEQ; 
extern SYMBOL s_lsp_PROC; 
extern SYMBOL s_lsp_TOP_2DLEVEL_2DPROC; 
extern SYMBOL s_lsp_INNER_2DPROC; 
extern SYMBOL s_lsp_TAG_2DSEQ; 
extern SYMBOL s_lsp_SCOPE_2DSEQ; 
extern SYMBOL s_lsp_PROGN; 
extern SYMBOL s_lsp_VALUES_2DSEQ; 
extern SYMBOL s_lsp_NAMED_2DLOCAL; 
extern SYMBOL s_lsp_INLINE_2DMV_2DCALL; 
extern SYMBOL s_lsp_SPEC_2DBIND_2DSEQ; 
extern SYMBOL s_lsp_SCOPE_2DCONTROL_2DTRANSFER; 
extern SYMBOL s_lsp_TREE_2DNSUBST_2DSCOPE_2DCONTROL_2DTRANSFER; 
extern SYMBOL s_lsp_UNWIND_2DPROTECT; 
extern SYMBOL s_lsp_TREE_2DNSUBST_2DUNWIND_2DPROTECT; 
extern SYMBOL s_lsp_VAR_2DDEF; 
extern SYMBOL s_lsp_TREE_2DNSUBST_2DVAR_2DDEF; 
extern SYMBOL s_lsp_MVALUES; 
extern SYMBOL s_lsp_TREE_2DNSUBST_2DVALUES; 
extern SYMBOL s_lsp_IF; 
extern SYMBOL s_lsp_TREE_2DNSUBST_2DIF; 
extern SYMBOL s_lsp_SWITCH; 
extern SYMBOL s_lsp_TREE_2DNSUBST_2DSWITCH; 
extern SYMBOL s_lsp_FUNCTION_2DCALL; 
extern SYMBOL s_lsp_C_2DSTRUCT_2DOP; 
extern SYMBOL s_lsp_C_2DSTRUCT_2DDEF; 
extern SYMBOL s_lsp_C_2DSTRUCT_2DREF; 
extern SYMBOL s_lsp_PRIMITIVE_2DCALL; 
extern SYMBOL s_lsp_UNNAMED_2DCALL; 
extern SYMBOL s_lsp_FOREIGN_2DCALL; 
extern SYMBOL s_lsp_NAMED_2DCALL; 
extern SYMBOL s_lsp_CONTROL_2DPOINT; 
extern SYMBOL s_lsp_TAG_2DCONTROL_2DPOINT; 
extern SYMBOL s_lsp_DYNAMIC_2DTAG_2DCONTROL_2DPOINT; 
extern SYMBOL s_lsp_STATIC_2DTAG_2DCONTROL_2DPOINT; 
extern SYMBOL s_lsp_SCOPE_2DCONTROL_2DPOINT; 
extern SYMBOL s_lsp_DYNAMIC_2DSCOPE_2DCONTROL_2DPOINT; 
extern SYMBOL s_lsp_CATCH_2DCONTROL_2DPOINT; 
extern SYMBOL s_lsp_DYNAMIC_2DBLOCK_2DCONTROL_2DPOINT; 
extern SYMBOL s_lsp_STATIC_2DSCOPE_2DCONTROL_2DPOINT; 
extern SYMBOL s_lsp_TREE_2DNSUBST_2DSEQ; 
extern SYMBOL s_lsp_TREE_2DNSUBST_2DFUNCTION_2DCALL; 
extern SYMBOL s_lsp_TREE_2DNSUBST_2DCONTROL_2DPOINT; 
extern LP p_lsp_TREE_2DNSUBST_2DLIST();
extern SYMBOL s_lsp_TREE_2DNSUBST; 
extern LP p_lsp_TREE_2DNSUBST_2DSEQ();
extern SYMBOL s_lsp_VALUES_2DSEQ_2DP; 
extern SYMBOL s_lsp_TREE_2DNSUBST_2DLIST; 
extern SYMBOL s_lsp_SCOPE_2DSEQ_2DP; 
extern LP p_lsp_TREE_2DNSUBST_2DVALUES();
extern LP p_lsp_TREE_2DNSUBST_2DVAR_2DDEF();
extern LP p_lsp_TREE_2DNSUBST_2DFUNCTION_2DCALL();
extern SYMBOL s_lsp_UNNAMED_2DCALL_2DP; 
extern LP p_lsp_TREE_2DNSUBST_2DIF();
extern LP p_lsp_TREE_2DNSUBST_2DSWITCH();
extern LP p_lsp_TREE_2DNSUBST_2DSCOPE_2DCONTROL_2DTRANSFER();
extern LP p_lsp_TREE_2DNSUBST_2DCONTROL_2DPOINT();
MAKE_CONS(k10864,LREF(s_lsp_DYNAMIC_2DTAG_2DCONTROL_2DPOINT),LREF(s_lsp_NIL));
extern SYMBOL s_lsp_MEMQL; 
MAKE_CONS(k10867,LREF(s_lsp_DYNAMIC_2DBLOCK_2DCONTROL_2DPOINT),LREF(s_lsp_NIL));
MAKE_CONS(k10866,LREF(s_lsp_CATCH_2DCONTROL_2DPOINT),LREF(k10867));
MAKE_CONS(k10865,LREF(s_lsp_DYNAMIC_2DSCOPE_2DCONTROL_2DPOINT),LREF(k10866));
extern LP p_lsp_TREE_2DNSUBST_2DUNWIND_2DPROTECT();




LP p_lsp_TREE_2DNSUBST(argc, v_NEW_0, v_OLD_1, v_TREE_2)
      ARGC argc;  LP v_NEW_0; LP v_OLD_1; LP v_TREE_2;
{
LP v_Y_143; LP v_X_142; LP v_Y_140; 
LP v_X_139; LP v_X_137; LP v_X_135; 
LP v_S_133; LP v_SYMBOL_131; LP v_Y_129; 
LP v_X_128; LP v_Y_126; LP v_X_125; 
LP v_Y_123; LP v_X_122; LP v_Y_120; 
LP v_X_119; LP v_Y_117; LP v_X_116; 
LP v_Y_114; LP v_X_113; LP v_Y_111; 
LP v_X_110; LP v_Y_108; LP v_X_107; 
LP v_Y_105; LP v_X_104; LP v_Y_102; 
LP v_X_101; LP v_Y_99; LP v_X_98; 
LP v_Y_96; LP v_X_95; LP v_Y_93; 
LP v_X_92; LP v_Y_90; LP v_X_89; 
LP v_Y_87; LP v_X_86; LP v_Y_84; 
LP v_X_83; LP v_Y_81; LP v_X_80; 
LP v_Y_78; LP v_X_77; LP v_Y_75; 
LP v_X_74; LP v_Y_72; LP v_X_71; 
LP v_Y_69; LP v_X_68; LP v_Y_66; 
LP v_X_65; LP v_Y_63; LP v_X_62; 
LP v_Y_60; LP v_X_59; LP v_Y_57; 
LP v_X_56; LP v_Y_54; LP v_X_53; 
LP v_Y_51; LP v_X_50; LP v_Y_48; 
LP v_X_47; LP v_Y_45; LP v_X_44; 
LP v_Y_42; LP v_X_41; LP v_Y_39; 
LP v_X_38; LP v_Y_36; LP v_X_35; 
LP v_Y_33; LP v_X_32; LP v_Y_30; 
LP v_X_29; LP v_KEY6544_24; LP v_S_22; 
LP v_KEY6543_19; LP v_VALUE_16; LP v_N_15; 
LP v_S_14; LP v_VALUE_12; LP v_S_11; 
LP v_T6540_10; LP v_S6539_9; LP v_I_7; 
LP v_S_6; LP v_S_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; LP t145; LP t146; LP t147; LP t148; LP t149; 
LP t150; LP t151; LP t152; LP t153; LP t154; LP t155; 
LP t156; LP t157; LP t158; LP t159; LP t160; LP t161; 
LP t162; LP t163; LP t164; LP t165; LP t166; LP t167; 
LP t168; LP t169; LP t170; LP t171; LP t172; LP t173; 
LP t174; LP t175; LP t176; LP t177; LP t178; LP t179; 
LP t180; LP t181; LP t182; LP t183; LP t184; LP t185; 
LP t186; LP t187; LP t188; LP t189; LP t190; LP t191; 
LP t192; LP t193; LP t194; LP t195; LP t196; LP t197; 
LP t198; LP t199; LP t200; LP t201; LP t202; LP t203; 
LP t204; LP t205; LP t206; LP t207; LP t208; LP t209; 
LP t210; LP t211; LP t212; LP t213; LP t214; LP t215; 
LP t216; LP t217; LP t218; LP t219; LP t220; LP t221; 
LP t222; LP t223; LP t224; LP t225; LP t226; LP t227; 
LP t228; LP t229; LP t230; LP t231; LP t232; LP t233; 
LP t234; 
if (argc != 3) wna(argc,3);
v_X_142 = v_OLD_1;
v_Y_143 = v_TREE_2;
if (((v_OLD_1) == (v_TREE_2))) {
v_S_4 = v_OLD_1;
v_S_6 = v_OLD_1;
v_I_7 = (LP) 2;
v_S6539_9 = ((LP) DEREF((v_OLD_1) + 1 * 4));
v_T6540_10 = v_NEW_0;
v_S_11 = v_NEW_0;
v_VALUE_12 = v_S6539_9;
v_S_14 = v_NEW_0;
v_N_15 = (LP) 2;
v_VALUE_16 = v_S6539_9;
((LP) (DEREF((v_NEW_0) + 1 * 4) = (LD) (v_S6539_9)));
return(v_NEW_0);
} else {
v_X_137 = v_TREE_2;
v_X_139 = v_TREE_2;
v_Y_140 = LREF(s_lsp_NIL);
if (v_TREE_2 != NIL) {
v_KEY6543_19 = v_TREE_2;
v_X_135 = v_KEY6543_19;
if (FIXNUMP((v_KEY6543_19))) {
goto t_DEFAULT_2DTAG6542_20;
} else {
t4 = INT_TO_FX(((int) TAG((v_KEY6543_19))));
switch ((int) t4) {
case 94:
v_S_22 = v_KEY6543_19;
v_KEY6544_24 = ((LP) DEREF((v_KEY6543_19) + 0 * 4));
v_S_133 = v_KEY6544_24;
if (OTHER_PTRP((v_KEY6544_24)) && (TAG((v_KEY6544_24)) == 3)) {
v_SYMBOL_131 = v_KEY6544_24;
t8 = ((LP) DEREF((v_KEY6544_24) + 5 * 4));
t7 = ((LP) ((int) (t8) % (int) ((LP) 358)));
switch ((int) t7) {
case 74:
v_X_29 = v_KEY6544_24;
v_Y_30 = LREF(s_lsp_SEQ);
if (((v_KEY6544_24) == (LREF(s_lsp_SEQ)))) {
goto t_C6549_26;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 334:
v_X_32 = v_KEY6544_24;
v_Y_33 = LREF(s_lsp_PROC);
if (((v_KEY6544_24) == (LREF(s_lsp_PROC)))) {
goto t_C6549_26;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 190:
v_X_35 = v_KEY6544_24;
v_Y_36 = LREF(s_lsp_TOP_2DLEVEL_2DPROC);
if (((v_KEY6544_24) == (LREF(s_lsp_TOP_2DLEVEL_2DPROC)))) {
goto t_C6549_26;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 180:
v_X_38 = v_KEY6544_24;
v_Y_39 = LREF(s_lsp_INNER_2DPROC);
if (((v_KEY6544_24) == (LREF(s_lsp_INNER_2DPROC)))) {
goto t_C6549_26;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 238:
v_X_41 = v_KEY6544_24;
v_Y_42 = LREF(s_lsp_TAG_2DSEQ);
if (((v_KEY6544_24) == (LREF(s_lsp_TAG_2DSEQ)))) {
goto t_C6549_26;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 106:
v_X_44 = v_KEY6544_24;
v_Y_45 = LREF(s_lsp_SCOPE_2DSEQ);
if (((v_KEY6544_24) == (LREF(s_lsp_SCOPE_2DSEQ)))) {
goto t_C6549_26;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 228:
v_X_47 = v_KEY6544_24;
v_Y_48 = LREF(s_lsp_PROGN);
if (((v_KEY6544_24) == (LREF(s_lsp_PROGN)))) {
goto t_C6549_26;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 296:
v_X_50 = v_KEY6544_24;
v_Y_51 = LREF(s_lsp_VALUES_2DSEQ);
if (((v_KEY6544_24) == (LREF(s_lsp_VALUES_2DSEQ)))) {
goto t_C6549_26;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 256:
v_X_53 = v_KEY6544_24;
v_Y_54 = LREF(s_lsp_NAMED_2DLOCAL);
if (((v_KEY6544_24) == (LREF(s_lsp_NAMED_2DLOCAL)))) {
goto t_C6549_26;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 54:
v_X_56 = v_KEY6544_24;
v_Y_57 = LREF(s_lsp_INLINE_2DMV_2DCALL);
if (((v_KEY6544_24) == (LREF(s_lsp_INLINE_2DMV_2DCALL)))) {
goto t_C6549_26;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 166:
v_X_59 = v_KEY6544_24;
v_Y_60 = LREF(s_lsp_SPEC_2DBIND_2DSEQ);
if (((v_KEY6544_24) == (LREF(s_lsp_SPEC_2DBIND_2DSEQ)))) {
goto t_C6549_26;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 168:
v_X_62 = v_KEY6544_24;
v_Y_63 = LREF(s_lsp_SCOPE_2DCONTROL_2DTRANSFER);
if (((v_KEY6544_24) == (LREF(s_lsp_SCOPE_2DCONTROL_2DTRANSFER)))) {
t6 = ICALL(s_lsp_TREE_2DNSUBST_2DSCOPE_2DCONTROL_2DTRANSFER) (MV_CALL(argc,3), v_NEW_0, v_OLD_1, v_TREE_2);
return(t6);
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 356:
v_X_65 = v_KEY6544_24;
v_Y_66 = LREF(s_lsp_UNWIND_2DPROTECT);
if (((v_KEY6544_24) == (LREF(s_lsp_UNWIND_2DPROTECT)))) {
t6 = ICALL(s_lsp_TREE_2DNSUBST_2DUNWIND_2DPROTECT) (MV_CALL(argc,3), v_NEW_0, v_OLD_1, v_TREE_2);
return(t6);
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 338:
v_X_68 = v_KEY6544_24;
v_Y_69 = LREF(s_lsp_VAR_2DDEF);
if (((v_KEY6544_24) == (LREF(s_lsp_VAR_2DDEF)))) {
t6 = ICALL(s_lsp_TREE_2DNSUBST_2DVAR_2DDEF) (MV_CALL(argc,3), v_NEW_0, v_OLD_1, v_TREE_2);
return(t6);
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 108:
v_X_71 = v_KEY6544_24;
v_Y_72 = LREF(s_lsp_MVALUES);
if (((v_KEY6544_24) == (LREF(s_lsp_MVALUES)))) {
t6 = ICALL(s_lsp_TREE_2DNSUBST_2DVALUES) (MV_CALL(argc,3), v_NEW_0, v_OLD_1, v_TREE_2);
return(t6);
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 330:
v_X_74 = v_KEY6544_24;
v_Y_75 = LREF(s_lsp_IF);
if (((v_KEY6544_24) == (LREF(s_lsp_IF)))) {
t6 = ICALL(s_lsp_TREE_2DNSUBST_2DIF) (MV_CALL(argc,3), v_NEW_0, v_OLD_1, v_TREE_2);
return(t6);
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 92:
v_X_77 = v_KEY6544_24;
v_Y_78 = LREF(s_lsp_SWITCH);
if (((v_KEY6544_24) == (LREF(s_lsp_SWITCH)))) {
t6 = ICALL(s_lsp_TREE_2DNSUBST_2DSWITCH) (MV_CALL(argc,3), v_NEW_0, v_OLD_1, v_TREE_2);
return(t6);
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 214:
v_X_80 = v_KEY6544_24;
v_Y_81 = LREF(s_lsp_FUNCTION_2DCALL);
if (((v_KEY6544_24) == (LREF(s_lsp_FUNCTION_2DCALL)))) {
goto t_C6548_27;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 250:
v_X_83 = v_KEY6544_24;
v_Y_84 = LREF(s_lsp_C_2DSTRUCT_2DOP);
if (((v_KEY6544_24) == (LREF(s_lsp_C_2DSTRUCT_2DOP)))) {
goto t_C6548_27;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 262:
v_X_86 = v_KEY6544_24;
v_Y_87 = LREF(s_lsp_C_2DSTRUCT_2DDEF);
if (((v_KEY6544_24) == (LREF(s_lsp_C_2DSTRUCT_2DDEF)))) {
goto t_C6548_27;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 234:
v_X_89 = v_KEY6544_24;
v_Y_90 = LREF(s_lsp_C_2DSTRUCT_2DREF);
if (((v_KEY6544_24) == (LREF(s_lsp_C_2DSTRUCT_2DREF)))) {
goto t_C6548_27;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 60:
v_X_92 = v_KEY6544_24;
v_Y_93 = LREF(s_lsp_PRIMITIVE_2DCALL);
if (((v_KEY6544_24) == (LREF(s_lsp_PRIMITIVE_2DCALL)))) {
goto t_C6548_27;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 56:
v_X_95 = v_KEY6544_24;
v_Y_96 = LREF(s_lsp_UNNAMED_2DCALL);
if (((v_KEY6544_24) == (LREF(s_lsp_UNNAMED_2DCALL)))) {
goto t_C6548_27;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 2:
v_X_98 = v_KEY6544_24;
v_Y_99 = LREF(s_lsp_FOREIGN_2DCALL);
if (((v_KEY6544_24) == (LREF(s_lsp_FOREIGN_2DCALL)))) {
goto t_C6548_27;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 310:
v_X_101 = v_KEY6544_24;
v_Y_102 = LREF(s_lsp_NAMED_2DCALL);
if (((v_KEY6544_24) == (LREF(s_lsp_NAMED_2DCALL)))) {
goto t_C6548_27;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 32:
v_X_104 = v_KEY6544_24;
v_Y_105 = LREF(s_lsp_CONTROL_2DPOINT);
if (((v_KEY6544_24) == (LREF(s_lsp_CONTROL_2DPOINT)))) {
goto t_C6547_28;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 138:
v_X_107 = v_KEY6544_24;
v_Y_108 = LREF(s_lsp_TAG_2DCONTROL_2DPOINT);
if (((v_KEY6544_24) == (LREF(s_lsp_TAG_2DCONTROL_2DPOINT)))) {
goto t_C6547_28;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 12:
v_X_110 = v_KEY6544_24;
v_Y_111 = LREF(s_lsp_DYNAMIC_2DTAG_2DCONTROL_2DPOINT);
if (((v_KEY6544_24) == (LREF(s_lsp_DYNAMIC_2DTAG_2DCONTROL_2DPOINT)))) {
goto t_C6547_28;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 18:
v_X_113 = v_KEY6544_24;
v_Y_114 = LREF(s_lsp_STATIC_2DTAG_2DCONTROL_2DPOINT);
if (((v_KEY6544_24) == (LREF(s_lsp_STATIC_2DTAG_2DCONTROL_2DPOINT)))) {
goto t_C6547_28;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 4:
v_X_116 = v_KEY6544_24;
v_Y_117 = LREF(s_lsp_SCOPE_2DCONTROL_2DPOINT);
if (((v_KEY6544_24) == (LREF(s_lsp_SCOPE_2DCONTROL_2DPOINT)))) {
goto t_C6547_28;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 82:
v_X_119 = v_KEY6544_24;
v_Y_120 = LREF(s_lsp_DYNAMIC_2DSCOPE_2DCONTROL_2DPOINT);
if (((v_KEY6544_24) == (LREF(s_lsp_DYNAMIC_2DSCOPE_2DCONTROL_2DPOINT)))) {
goto t_C6547_28;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 80:
v_X_122 = v_KEY6544_24;
v_Y_123 = LREF(s_lsp_CATCH_2DCONTROL_2DPOINT);
if (((v_KEY6544_24) == (LREF(s_lsp_CATCH_2DCONTROL_2DPOINT)))) {
goto t_C6547_28;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 200:
v_X_125 = v_KEY6544_24;
v_Y_126 = LREF(s_lsp_DYNAMIC_2DBLOCK_2DCONTROL_2DPOINT);
if (((v_KEY6544_24) == (LREF(s_lsp_DYNAMIC_2DBLOCK_2DCONTROL_2DPOINT)))) {
goto t_C6547_28;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
case 100:
v_X_128 = v_KEY6544_24;
v_Y_129 = LREF(s_lsp_STATIC_2DSCOPE_2DCONTROL_2DPOINT);
if (((v_KEY6544_24) == (LREF(s_lsp_STATIC_2DSCOPE_2DCONTROL_2DPOINT)))) {
goto t_C6547_28;
} else {
goto t_DEFAULT_2DTAG6545_25;
}
break;
default:
goto t_DEFAULT_2DTAG6545_25;
break;
}
return(t6);
}
t_DEFAULT_2DTAG6545_25:;
goto t_DEFAULT_2DTAG6542_20;
return(NIL);
t_C6549_26:;
t43 = ICALL(s_lsp_TREE_2DNSUBST_2DSEQ) (MV_CALL(argc,3), v_NEW_0, v_OLD_1, v_TREE_2);
return(t43);
return(NIL);
t_C6548_27:;
t44 = ICALL(s_lsp_TREE_2DNSUBST_2DFUNCTION_2DCALL) (MV_CALL(argc,3), v_NEW_0, v_OLD_1, v_TREE_2);
return(t44);
return(NIL);
t_C6547_28:;
t45 = ICALL(s_lsp_TREE_2DNSUBST_2DCONTROL_2DPOINT) (MV_CALL(argc,3), v_NEW_0, v_OLD_1, v_TREE_2);
return(t45);
return(NIL);
return(NIL);
break;
default:
goto t_DEFAULT_2DTAG6542_20;
break;
}
}
return(t2);
t_DEFAULT_2DTAG6542_20:;
return(v_TREE_2);
return(NIL);
return(NIL);
} else {
return(LREF(s_lsp_NIL));
}
}
}

LP p_lsp_TREE_2DNSUBST_2DLIST(argc, v_NEW_0, v_OLD_1, v_L_2)
      ARGC argc;  LP v_NEW_0; LP v_OLD_1; LP v_L_2;
{
LP v_X_15; LP v_V_13; LP v_X_12; 
LP v_T6551_11; LP v_S6550_10; LP v_X_8; 
LP v_REST_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 

if (argc != 3) wna(argc,3);
v_REST_4 = v_L_2;
t_NEXT_2DLOOP_6:;
if (v_REST_4 == NIL) {
goto t_END_2DLOOP_7;
}
v_X_8 = v_REST_4;
t1 = ((LP) DEREF((v_X_8) + 0 * 4));
v_S6550_10 = ICALL(s_lsp_TREE_2DNSUBST) (3, v_NEW_0, v_OLD_1, t1);
v_T6551_11 = v_REST_4;
v_V_13 = v_S6550_10;
((LP) (DEREF((v_T6551_11) + 0 * 4) = (LD) (v_V_13)));
v_X_15 = v_REST_4;
v_REST_4 = ((LP) DEREF((v_X_15) + 1 * 4));
goto t_NEXT_2DLOOP_6;
goto t_END_2DLOOP_7;
t_END_2DLOOP_7:;
return(v_L_2);
return(NIL);
return(NIL);
}

LP p_lsp_TREE_2DNSUBST_2DSEQ(argc, v_NEW_0, v_OLD_1, v_TREE_2)
      ARGC argc;  LP v_NEW_0; LP v_OLD_1; LP v_TREE_2;
{
LP v_VALUE_45; LP v_N_44; LP v_S_43; 
LP v_VALUE_41; LP v_S_40; LP v_T6555_39; 
LP v_S6554_38; LP v_Y_36; LP v_X_35; 
LP v_X_33; LP v_X_31; LP v_X_29; 
LP v_BODY_28; LP v_I_26; LP v_S_25; 
LP v_S_23; LP v_VALUE_21; LP v_N_20; 
LP v_S_19; LP v_VALUE_17; LP v_S_16; 
LP v_T6553_15; LP v_S6552_14; LP v_I_12; 
LP v_S_11; LP v_S_9; LP v_I_7; 
LP v_S_6; LP v_S_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; 
if (argc != 3) wna(argc,3);
t0 = ICALL(s_lsp_VALUES_2DSEQ_2DP) (1, v_TREE_2);
if (t0 != NIL) {
v_S_4 = v_TREE_2;
v_S_6 = v_TREE_2;
v_I_7 = (LP) 14;
t1 = ((LP) DEREF((v_TREE_2) + 7 * 4));
ICALL(s_lsp_TREE_2DNSUBST_2DLIST) (3, v_NEW_0, v_OLD_1, t1);
}
t2 = ICALL(s_lsp_SCOPE_2DSEQ_2DP) (1, v_TREE_2);
if (t2 != NIL) {
v_S_9 = v_TREE_2;
v_S_11 = v_TREE_2;
v_I_12 = (LP) 14;
t3 = ((LP) DEREF((v_TREE_2) + 7 * 4));
v_S6552_14 = ICALL(s_lsp_TREE_2DNSUBST_2DSEQ) (3, v_NEW_0, v_OLD_1, t3);
v_T6553_15 = v_TREE_2;
v_S_16 = v_TREE_2;
v_VALUE_17 = v_S6552_14;
v_S_19 = v_TREE_2;
v_N_20 = (LP) 14;
v_VALUE_21 = v_S6552_14;
((LP) (DEREF((v_TREE_2) + 7 * 4) = (LD) (v_S6552_14)));
}
v_S_23 = v_TREE_2;
v_S_25 = v_TREE_2;
v_I_26 = (LP) 12;
v_BODY_28 = ((LP) DEREF((v_TREE_2) + 6 * 4));
v_X_29 = v_BODY_28;
v_X_31 = v_BODY_28;
v_X_33 = (OTHER_PTRP((v_BODY_28)) && (TAG((v_BODY_28)) == 15) ? T : NIL);
v_X_35 = v_X_33;
v_Y_36 = LREF(s_lsp_NIL);
if (v_X_33 != NIL) {
v_S6554_38 = ICALL(s_lsp_TREE_2DNSUBST_2DLIST) (3, v_NEW_0, v_OLD_1, v_BODY_28);
} else {
v_S6554_38 = ICALL(s_lsp_TREE_2DNSUBST) (3, v_NEW_0, v_OLD_1, v_BODY_28);
}
v_T6555_39 = v_TREE_2;
v_S_40 = v_TREE_2;
v_VALUE_41 = v_S6554_38;
v_S_43 = v_TREE_2;
v_N_44 = (LP) 12;
v_VALUE_45 = v_S6554_38;
((LP) (DEREF((v_TREE_2) + 6 * 4) = (LD) (v_S6554_38)));
return(v_TREE_2);
}

LP p_lsp_TREE_2DNSUBST_2DVALUES(argc, v_NEW_0, v_OLD_1, v_TREE_2)
      ARGC argc;  LP v_NEW_0; LP v_OLD_1; LP v_TREE_2;
{
LP v_I_7; LP v_S_6; LP v_S_4; 

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 3) wna(argc,3);
v_S_4 = v_TREE_2;
v_S_6 = v_TREE_2;
v_I_7 = (LP) 12;
t0 = ((LP) DEREF((v_TREE_2) + 6 * 4));
ICALL(s_lsp_TREE_2DNSUBST_2DLIST) (3, v_NEW_0, v_OLD_1, t0);
return(v_TREE_2);
}

LP p_lsp_TREE_2DNSUBST_2DVAR_2DDEF(argc, v_NEW_0, v_OLD_1, v_TREE_2)
      ARGC argc;  LP v_NEW_0; LP v_OLD_1; LP v_TREE_2;
{
LP v_VALUE_16; LP v_N_15; LP v_S_14; 
LP v_VALUE_12; LP v_S_11; LP v_T6557_10; 
LP v_S6556_9; LP v_I_7; LP v_S_6; 
LP v_S_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
if (argc != 3) wna(argc,3);
v_S_4 = v_TREE_2;
v_S_6 = v_TREE_2;
v_I_7 = (LP) 16;
t0 = ((LP) DEREF((v_TREE_2) + 8 * 4));
v_S6556_9 = ICALL(s_lsp_TREE_2DNSUBST) (3, v_NEW_0, v_OLD_1, t0);
v_T6557_10 = v_TREE_2;
v_S_11 = v_TREE_2;
v_VALUE_12 = v_S6556_9;
v_S_14 = v_TREE_2;
v_N_15 = (LP) 16;
v_VALUE_16 = v_S6556_9;
((LP) (DEREF((v_TREE_2) + 8 * 4) = (LD) (v_S6556_9)));
return(v_TREE_2);
}

LP p_lsp_TREE_2DNSUBST_2DFUNCTION_2DCALL(argc, v_NEW_0, v_OLD_1, v_TREE_2)
      ARGC argc;  LP v_NEW_0; LP v_OLD_1; LP v_TREE_2;
{
LP v_I_21; LP v_S_20; LP v_S_18; 
LP v_VALUE_16; LP v_N_15; LP v_S_14; 
LP v_VALUE_12; LP v_S_11; LP v_T6559_10; 
LP v_S6558_9; LP v_I_7; LP v_S_6; 
LP v_S_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; 
if (argc != 3) wna(argc,3);
t0 = ICALL(s_lsp_UNNAMED_2DCALL_2DP) (1, v_TREE_2);
if (t0 != NIL) {
v_S_4 = v_TREE_2;
v_S_6 = v_TREE_2;
v_I_7 = (LP) 20;
t1 = ((LP) DEREF((v_TREE_2) + 10 * 4));
v_S6558_9 = ICALL(s_lsp_TREE_2DNSUBST) (3, v_NEW_0, v_OLD_1, t1);
v_T6559_10 = v_TREE_2;
v_S_11 = v_TREE_2;
v_VALUE_12 = v_S6558_9;
v_S_14 = v_TREE_2;
v_N_15 = (LP) 20;
v_VALUE_16 = v_S6558_9;
((LP) (DEREF((v_TREE_2) + 10 * 4) = (LD) (v_S6558_9)));
}
v_S_18 = v_TREE_2;
v_S_20 = v_TREE_2;
v_I_21 = (LP) 12;
t2 = ((LP) DEREF((v_TREE_2) + 6 * 4));
ICALL(s_lsp_TREE_2DNSUBST_2DLIST) (3, v_NEW_0, v_OLD_1, t2);
return(v_TREE_2);
}

LP p_lsp_TREE_2DNSUBST_2DIF(argc, v_NEW_0, v_OLD_1, v_TREE_2)
      ARGC argc;  LP v_NEW_0; LP v_OLD_1; LP v_TREE_2;
{
LP v_VALUE_44; LP v_N_43; LP v_S_42; 
LP v_VALUE_40; LP v_S_39; LP v_T6565_38; 
LP v_S6564_37; LP v_I_35; LP v_S_34; 
LP v_S_32; LP v_VALUE_30; LP v_N_29; 
LP v_S_28; LP v_VALUE_26; LP v_S_25; 
LP v_T6563_24; LP v_S6562_23; LP v_I_21; 
LP v_S_20; LP v_S_18; LP v_VALUE_16; 
LP v_N_15; LP v_S_14; LP v_VALUE_12; 
LP v_S_11; LP v_T6561_10; LP v_S6560_9; 
LP v_I_7; LP v_S_6; LP v_S_4; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; 
if (argc != 3) wna(argc,3);
v_S_4 = v_TREE_2;
v_S_6 = v_TREE_2;
v_I_7 = (LP) 14;
t0 = ((LP) DEREF((v_TREE_2) + 7 * 4));
v_S6560_9 = ICALL(s_lsp_TREE_2DNSUBST) (3, v_NEW_0, v_OLD_1, t0);
v_T6561_10 = v_TREE_2;
v_S_11 = v_TREE_2;
v_VALUE_12 = v_S6560_9;
v_S_14 = v_TREE_2;
v_N_15 = (LP) 14;
v_VALUE_16 = v_S6560_9;
((LP) (DEREF((v_TREE_2) + 7 * 4) = (LD) (v_S6560_9)));
v_S_18 = v_TREE_2;
v_S_20 = v_TREE_2;
v_I_21 = (LP) 16;
t1 = ((LP) DEREF((v_TREE_2) + 8 * 4));
v_S6562_23 = ICALL(s_lsp_TREE_2DNSUBST) (3, v_NEW_0, v_OLD_1, t1);
v_T6563_24 = v_TREE_2;
v_S_25 = v_TREE_2;
v_VALUE_26 = v_S6562_23;
v_S_28 = v_TREE_2;
v_N_29 = (LP) 16;
v_VALUE_30 = v_S6562_23;
((LP) (DEREF((v_TREE_2) + 8 * 4) = (LD) (v_S6562_23)));
v_S_32 = v_TREE_2;
v_S_34 = v_TREE_2;
v_I_35 = (LP) 18;
t2 = ((LP) DEREF((v_TREE_2) + 9 * 4));
v_S6564_37 = ICALL(s_lsp_TREE_2DNSUBST) (3, v_NEW_0, v_OLD_1, t2);
v_T6565_38 = v_TREE_2;
v_S_39 = v_TREE_2;
v_VALUE_40 = v_S6564_37;
v_S_42 = v_TREE_2;
v_N_43 = (LP) 18;
v_VALUE_44 = v_S6564_37;
((LP) (DEREF((v_TREE_2) + 9 * 4) = (LD) (v_S6564_37)));
return(v_TREE_2);
}

LP p_lsp_TREE_2DNSUBST_2DSWITCH(argc, v_NEW_0, v_OLD_1, v_TREE_2)
      ARGC argc;  LP v_NEW_0; LP v_OLD_1; LP v_TREE_2;
{
LP v_VALUE_44; LP v_N_43; LP v_S_42; 
LP v_VALUE_40; LP v_S_39; LP v_T6571_38; 
LP v_S6570_37; LP v_I_35; LP v_S_34; 
LP v_S_32; LP v_VALUE_30; LP v_N_29; 
LP v_S_28; LP v_VALUE_26; LP v_S_25; 
LP v_T6569_24; LP v_S6568_23; LP v_I_21; 
LP v_S_20; LP v_S_18; LP v_VALUE_16; 
LP v_N_15; LP v_S_14; LP v_VALUE_12; 
LP v_S_11; LP v_T6567_10; LP v_S6566_9; 
LP v_I_7; LP v_S_6; LP v_S_4; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; 
if (argc != 3) wna(argc,3);
v_S_4 = v_TREE_2;
v_S_6 = v_TREE_2;
v_I_7 = (LP) 14;
t0 = ((LP) DEREF((v_TREE_2) + 7 * 4));
v_S6566_9 = ICALL(s_lsp_TREE_2DNSUBST) (3, v_NEW_0, v_OLD_1, t0);
v_T6567_10 = v_TREE_2;
v_S_11 = v_TREE_2;
v_VALUE_12 = v_S6566_9;
v_S_14 = v_TREE_2;
v_N_15 = (LP) 14;
v_VALUE_16 = v_S6566_9;
((LP) (DEREF((v_TREE_2) + 7 * 4) = (LD) (v_S6566_9)));
v_S_18 = v_TREE_2;
v_S_20 = v_TREE_2;
v_I_21 = (LP) 18;
t1 = ((LP) DEREF((v_TREE_2) + 9 * 4));
v_S6568_23 = ICALL(s_lsp_TREE_2DNSUBST_2DLIST) (3, v_NEW_0, v_OLD_1, t1);
v_T6569_24 = v_TREE_2;
v_S_25 = v_TREE_2;
v_VALUE_26 = v_S6568_23;
v_S_28 = v_TREE_2;
v_N_29 = (LP) 18;
v_VALUE_30 = v_S6568_23;
((LP) (DEREF((v_TREE_2) + 9 * 4) = (LD) (v_S6568_23)));
v_S_32 = v_TREE_2;
v_S_34 = v_TREE_2;
v_I_35 = (LP) 20;
t2 = ((LP) DEREF((v_TREE_2) + 10 * 4));
v_S6570_37 = ICALL(s_lsp_TREE_2DNSUBST) (3, v_NEW_0, v_OLD_1, t2);
v_T6571_38 = v_TREE_2;
v_S_39 = v_TREE_2;
v_VALUE_40 = v_S6570_37;
v_S_42 = v_TREE_2;
v_N_43 = (LP) 20;
v_VALUE_44 = v_S6570_37;
((LP) (DEREF((v_TREE_2) + 10 * 4) = (LD) (v_S6570_37)));
return(v_TREE_2);
}

LP p_lsp_TREE_2DNSUBST_2DSCOPE_2DCONTROL_2DTRANSFER(argc, v_NEW_0, v_OLD_1, v_TREE_2)
      ARGC argc;  LP v_NEW_0; LP v_OLD_1; LP v_TREE_2;
{
LP v_VALUE_30; LP v_N_29; LP v_S_28; 
LP v_VALUE_26; LP v_S_25; LP v_T6575_24; 
LP v_S6574_23; LP v_I_21; LP v_S_20; 
LP v_S_18; LP v_VALUE_16; LP v_N_15; 
LP v_S_14; LP v_VALUE_12; LP v_S_11; 
LP v_T6573_10; LP v_S6572_9; LP v_I_7; 
LP v_S_6; LP v_S_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; 
if (argc != 3) wna(argc,3);
v_S_4 = v_TREE_2;
v_S_6 = v_TREE_2;
v_I_7 = (LP) 16;
t0 = ((LP) DEREF((v_TREE_2) + 8 * 4));
v_S6572_9 = ICALL(s_lsp_TREE_2DNSUBST) (3, v_NEW_0, v_OLD_1, t0);
v_T6573_10 = v_TREE_2;
v_S_11 = v_TREE_2;
v_VALUE_12 = v_S6572_9;
v_S_14 = v_TREE_2;
v_N_15 = (LP) 16;
v_VALUE_16 = v_S6572_9;
((LP) (DEREF((v_TREE_2) + 8 * 4) = (LD) (v_S6572_9)));
v_S_18 = v_TREE_2;
v_S_20 = v_TREE_2;
v_I_21 = (LP) 12;
t1 = ((LP) DEREF((v_TREE_2) + 6 * 4));
v_S6574_23 = ICALL(s_lsp_TREE_2DNSUBST) (3, v_NEW_0, v_OLD_1, t1);
v_T6575_24 = v_TREE_2;
v_S_25 = v_TREE_2;
v_VALUE_26 = v_S6574_23;
v_S_28 = v_TREE_2;
v_N_29 = (LP) 12;
v_VALUE_30 = v_S6574_23;
((LP) (DEREF((v_TREE_2) + 6 * 4) = (LD) (v_S6574_23)));
return(v_TREE_2);
}

LP p_lsp_TREE_2DNSUBST_2DCONTROL_2DPOINT(argc, v_NEW_0, v_OLD_1, v_TREE_2)
      ARGC argc;  LP v_NEW_0; LP v_OLD_1; LP v_TREE_2;
{
LP v_X_38; LP v_VALUE_36; LP v_N_35; 
LP v_S_34; LP v_VALUE_32; LP v_S_31; 
LP v_T6583_30; LP v_S6582_29; LP v_I_27; 
LP v_S_26; LP v_S_24; LP v_VALUE_22; 
LP v_N_21; LP v_S_20; LP v_VALUE_18; 
LP v_S_17; LP v_T6581_16; LP v_S6580_15; 
LP v_I_13; LP v_S_12; LP v_S_10; 
LP v_KEY6579_9; LP v_S_7; LP v_KEY6578_5; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 

if (argc != 3) wna(argc,3);
v_KEY6578_5 = v_TREE_2;
v_X_38 = v_KEY6578_5;
if (FIXNUMP((v_KEY6578_5))) {
goto t_DEFAULT_2DTAG6577_6;
} else {
t2 = INT_TO_FX(((int) TAG((v_KEY6578_5))));
switch ((int) t2) {
case 94:
v_S_7 = v_KEY6578_5;
v_KEY6579_9 = ((LP) DEREF((v_KEY6578_5) + 0 * 4));
t3 = ICALL(s_lsp_MEMQL) (2, v_KEY6579_9, LREF(k10864));
if (t3 != NIL) {
v_S_10 = v_TREE_2;
v_S_12 = v_TREE_2;
v_I_13 = (LP) 22;
t4 = ((LP) DEREF((v_TREE_2) + 11 * 4));
v_S6580_15 = ICALL(s_lsp_TREE_2DNSUBST) (3, v_NEW_0, v_OLD_1, t4);
v_T6581_16 = v_TREE_2;
v_S_17 = v_TREE_2;
v_VALUE_18 = v_S6580_15;
v_S_20 = v_TREE_2;
v_N_21 = (LP) 22;
v_VALUE_22 = v_S6580_15;
t0 = ((LP) (DEREF((v_TREE_2) + 11 * 4) = (LD) (v_S6580_15)));
} else {
t5 = ICALL(s_lsp_MEMQL) (2, v_KEY6579_9, LREF(k10865));
if (t5 != NIL) {
v_S_24 = v_TREE_2;
v_S_26 = v_TREE_2;
v_I_27 = (LP) 22;
t6 = ((LP) DEREF((v_TREE_2) + 11 * 4));
v_S6582_29 = ICALL(s_lsp_TREE_2DNSUBST) (3, v_NEW_0, v_OLD_1, t6);
v_T6583_30 = v_TREE_2;
v_S_31 = v_TREE_2;
v_VALUE_32 = v_S6582_29;
v_S_34 = v_TREE_2;
v_N_35 = (LP) 22;
v_VALUE_36 = v_S6582_29;
t0 = ((LP) (DEREF((v_TREE_2) + 11 * 4) = (LD) (v_S6582_29)));
} else {
goto t_DEFAULT_2DTAG6577_6;
}
}
break;
default:
goto t_DEFAULT_2DTAG6577_6;
break;
}
}
goto b_TYPECASE6576_4;
t_DEFAULT_2DTAG6577_6:;
goto b_TYPECASE6576_4;
b_TYPECASE6576_4:;
return(v_TREE_2);
}

LP p_lsp_TREE_2DNSUBST_2DUNWIND_2DPROTECT(argc, v_NEW_0, v_OLD_1, v_TREE_2)
      ARGC argc;  LP v_NEW_0; LP v_OLD_1; LP v_TREE_2;
{
LP v_VALUE_30; LP v_N_29; LP v_S_28; 
LP v_VALUE_26; LP v_S_25; LP v_T6587_24; 
LP v_S6586_23; LP v_I_21; LP v_S_20; 
LP v_S_18; LP v_VALUE_16; LP v_N_15; 
LP v_S_14; LP v_VALUE_12; LP v_S_11; 
LP v_T6585_10; LP v_S6584_9; LP v_I_7; 
LP v_S_6; LP v_S_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; 
if (argc != 3) wna(argc,3);
v_S_4 = v_TREE_2;
v_S_6 = v_TREE_2;
v_I_7 = (LP) 14;
t0 = ((LP) DEREF((v_TREE_2) + 7 * 4));
v_S6584_9 = ICALL(s_lsp_TREE_2DNSUBST) (3, v_NEW_0, v_OLD_1, t0);
v_T6585_10 = v_TREE_2;
v_S_11 = v_TREE_2;
v_VALUE_12 = v_S6584_9;
v_S_14 = v_TREE_2;
v_N_15 = (LP) 14;
v_VALUE_16 = v_S6584_9;
((LP) (DEREF((v_TREE_2) + 7 * 4) = (LD) (v_S6584_9)));
v_S_18 = v_TREE_2;
v_S_20 = v_TREE_2;
v_I_21 = (LP) 12;
t1 = ((LP) DEREF((v_TREE_2) + 6 * 4));
v_S6586_23 = ICALL(s_lsp_TREE_2DNSUBST) (3, v_NEW_0, v_OLD_1, t1);
v_T6587_24 = v_TREE_2;
v_S_25 = v_TREE_2;
v_VALUE_26 = v_S6586_23;
v_S_28 = v_TREE_2;
v_N_29 = (LP) 12;
v_VALUE_30 = v_S6586_23;
((LP) (DEREF((v_TREE_2) + 6 * 4) = (LD) (v_S6586_23)));
return(v_TREE_2);
}

