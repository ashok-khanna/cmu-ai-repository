/*
:comment "Compiled at 3:52:24 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: Debug Library"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O2 -fPIC"
:version 0
:end-package-info 0
:SV *COMMA* "COMMA"
:SV *COMMA-ATSIGN* "COMMA-ATSIGN"
:SV *COMMA-DOT* "COMMA-DOT"
:SV *BQ-LIST* "BQ-LIST"
:SV *BQ-APPEND* "BQ-APPEND"
:SV *BQ-LIST** "BQ-LIST*"
:SV *BQ-NCONC* "BQ-NCONC"
:SV *BQ-CLOBBERABLE* "BQ-CLOBBERABLE"
:SV *BQ-QUOTE* "BQ-QUOTE"
:SV *BQ-COUNT* 0
:sym CDR
:sym CAR
:sym BQ-COMPLETELY-PROCESS
:sm BACKQUOTE "m_lsp_BACKQUOTE"
:sym *BQ-QUOTE-NIL*
:sym *BQ-QUOTE*
:sym UNSAFE-SYMBOL-VALUE
:sym NIL
:sym CONS
:sym :VAR
:sym DEFINE-VARIABLE
:sym *BQ-SIMPLIFY*
:sym T
:sym :PARAMETER
:sym BACKQUOTE
:sym UNSAFE-SYMBOL-FUNCTION
:sym DEFINE-MACRO
:sf BQ_INIT646 "p_lsp_BQ_5FINIT646"
:init BQ_INIT646
:pinfo BQ_INIT646 NIL NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP m_lsp_BACKQUOTE();
extern SYMBOL s_lsp_CDR; 
extern SYMBOL s_lsp_CAR; 
extern SYMBOL s_lsp_BQ_2DCOMPLETELY_2DPROCESS; 
extern LP p_lsp_BQ_5FINIT646();
extern SYMBOL s_lsp__2ABQ_2DQUOTE_2DNIL_2A; 
extern SYMBOL s_lsp__2ABQ_2DQUOTE_2A; 
extern SYMBOL s_lsp_UNSAFE_2DSYMBOL_2DVALUE; 
extern SYMBOL s_lsp_NIL; 
extern SYMBOL s_lsp_CONS; 
extern SYMBOL s_key_VAR; 
extern SYMBOL s_lsp_DEFINE_2DVARIABLE; 
extern SYMBOL s_lsp__2ABQ_2DSIMPLIFY_2A; 
extern SYMBOL s_lsp_T; 
extern SYMBOL s_key_PARAMETER; 
extern SYMBOL s_lsp_BACKQUOTE; 
extern SYMBOL s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION; 
extern SYMBOL s_lsp_DEFINE_2DMACRO; 




LP m_lsp_BACKQUOTE(argc, v_WHOLE1623_0, v_ENV1624_1)
      ARGC argc;  LP v_WHOLE1623_0; LP v_ENV1624_1;
{
LP v_X_7; LP v_S1632_6; LP v_VALUE1631_5; 
LP v_LIST1630_4; LP v_L1629_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
if (argc != 2) wna(argc,2);
v_L1629_3 = ICALL(s_lsp_CDR) (1, v_WHOLE1623_0);
v_LIST1630_4 = v_L1629_3;
v_VALUE1631_5 = ICALL(s_lsp_CAR) (1, v_LIST1630_4);
v_S1632_6 = ICALL(s_lsp_CDR) (1, v_LIST1630_4);
v_L1629_3 = v_S1632_6;
v_X_7 = v_VALUE1631_5;
t0 = ICALL(s_lsp_BQ_2DCOMPLETELY_2DPROCESS) (MV_CALL(argc,1), v_X_7);
return(t0);
}

LP p_lsp_BQ_5FINIT646(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 0) wna(argc,0);
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DQUOTE_2A));
t2 = ICALL(s_lsp_CONS) (2, LREF(s_lsp_NIL), LREF(s_lsp_NIL));
t0 = ICALL(s_lsp_CONS) (2, t1, t2);
ICALL(s_lsp_DEFINE_2DVARIABLE) (4, LREF(s_lsp__2ABQ_2DQUOTE_2DNIL_2A), t0, LREF(s_lsp_NIL), LREF(s_key_VAR));
ICALL(s_lsp_DEFINE_2DVARIABLE) (4, LREF(s_lsp__2ABQ_2DSIMPLIFY_2A), LREF(s_lsp_T), LREF(s_lsp_NIL), LREF(s_key_PARAMETER));
t4 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_BACKQUOTE));
t3 = ICALL(s_lsp_DEFINE_2DMACRO) (MV_CALL(argc,2), LREF(s_lsp_BACKQUOTE), t4);
return(t3);
}

