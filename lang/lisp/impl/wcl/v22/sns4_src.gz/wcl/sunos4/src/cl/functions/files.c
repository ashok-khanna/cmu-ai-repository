/*
:comment "Compiled at 4:05:12 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: Debug Library"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O2 -fPIC"
:version 0
:end-package-info 0
:sym NAMESTRING
:sym T
:sym ERROR
:sf DELETE-FILE "p_lsp_DELETE_2DFILE"
:sf ENOUGH-NAMESTRING "p_lsp_ENOUGH_2DNAMESTRING"
:sym FILE-STREAM-P
:sym FILE-STREAM
:sym WTA
:sym WARN
:sym NIL
:sf FILE-AUTHOR "p_lsp_FILE_2DAUTHOR"
:sf FILE-LENGTH "p_lsp_FILE_2DLENGTH"
:sym :START
:sym EQL
:sym :END
:sym FIXNUMP
:sym FILE-LENGTH
:sf FILE-POSITION "p_lsp_FILE_2DPOSITION"
:sym UNIX->UNIVERSAL-TIME
:sf FILE-WRITE-DATE "p_lsp_FILE_2DWRITE_2DDATE"
:sym :HOST
:sym :DEVICE
:sym :DIRECTORY
:sym :NAME
:sym :TYPE
:sym :DEFAULTS
:sym PATHNAME
:sym PATHNAME-HOST
:sym PATHNAME-DEVICE
:sym PATHNAME-DIRECTORY
:sym PATHNAME-NAME
:sym PATHNAME-TYPE
:sym MAKE-PHYSICAL-PATHNAME/7
:sf MAKE-PATHNAME "p_lsp_MAKE_2DPATHNAME"
:sym *DEFAULT-PATHNAME-DEFAULTS*
:sym UNSAFE-SYMBOL-VALUE
:sym CAR
:sym :RELATIVE
:sym EQ
:sym CDR
:sym APPEND/2
:sym :UP
:sym BUTLAST
:sym MAKE-PATHNAME
:sf MERGE-PATHNAMES "p_lsp_MERGE_2DPATHNAMES"
:sym PATHNAMEP
:sym PATHNAME->STRING
:sym STRING-P
:sym STREAMP
:sym SYMBOLP
:sym SYMBOL-NAME
:sym PHYSICAL-PATHNAME
:sym STRING
:sym STREAM
:sym SYMBOL
:sf NAMESTRING "p_lsp_NAMESTRING"
:sym :JUNK-ALLOWED
:sym LENGTH
:sym PARSE-NAMESTRING-1
:sf PARSE-NAMESTRING "p_lsp_PARSE_2DNAMESTRING"
:sym :ABSOLUTE
:sym NAMESTRING->DIRLIST
:sym CONS
:sym :HOME
:sym :FROM-END
:sym POSITION
:sym 1+
:sym :NAMESTRING
:sym SUBSEQ
:sym NULL-STRING->NIL
:sf PARSE-NAMESTRING-1 "p_lsp_PARSE_2DNAMESTRING_2D1"
:sf NULL-STRING->NIL "p_lsp_NULL_2DSTRING_2D_3ENIL"
:sf NAMESTRING->DIRLIST "p_lsp_NAMESTRING_2D_3EDIRLIST"
:sf PATHNAME-DEVICE "p_lsp_PATHNAME_2DDEVICE"
:sf PATHNAME-DIRECTORY "p_lsp_PATHNAME_2DDIRECTORY"
:sf PATHNAME-HOST "p_lsp_PATHNAME_2DHOST"
:sf PATHNAME-NAME "p_lsp_PATHNAME_2DNAME"
:sf NIL->EMPTY-STRING "p_lsp_NIL_2D_3EEMPTY_2DSTRING"
:sym NIL->EMPTY-STRING
:sym FORMAT
:sf PATHNAME->STRING "p_lsp_PATHNAME_2D_3ESTRING"
:sf PATHNAME-TYPE "p_lsp_PATHNAME_2DTYPE"
:sf PATHNAME-VERSION "p_lsp_PATHNAME_2DVERSION"
:sym PARSE-NAMESTRING
:sf PATHNAME "p_lsp_PATHNAME"
:sym STRINGP
:sf PROBE-FILE "p_lsp_PROBE_2DFILE"
:sf TRUENAME "p_lsp_TRUENAME"
:sym DIRDESC
:sym DIRENT
:sym MERGE-PATHNAMES
:sym RPLACD
:sf DIRECTORY "p_lsp_DIRECTORY"
:sf ED "p_lsp_ED"
:sym CONCATENATE
:sf FILE-NAMESTRING "p_lsp_FILE_2DNAMESTRING"
:sf DIRECTORY-NAMESTRING "p_lsp_DIRECTORY_2DNAMESTRING"
:sf HOST-NAMESTRING "p_lsp_HOST_2DNAMESTRING"
:pinfo PARSE-NAMESTRING-1 (NAMESTRING END) NIL NIL NIL NIL NIL NIL T
:pinfo PATHNAME-HOST (P) NIL NIL NIL NIL NIL NIL T
:pinfo ENOUGH-NAMESTRING (NAME) NIL NIL NIL NIL NIL NIL T
:pinfo PATHNAME-DIRECTORY (P) NIL NIL NIL NIL NIL NIL T
:pinfo DELETE-FILE (PATHNAME) NIL NIL NIL NIL NIL NIL T
:pinfo MERGE-PATHNAMES (NAME &OPTIONAL (DEFAULTS *DEFAULT-PATHNAME-DEFAULTS*) DEFAULT-VERSION) NIL NIL NIL NIL NIL NIL T
:pinfo FILE-NAMESTRING (FILE) NIL NIL NIL NIL NIL NIL T
:pinfo PATHNAME (X) NIL NIL NIL NIL NIL NIL T
:pinfo FILE-POSITION (STREAM &OPTIONAL POSITION) NIL NIL NIL NIL NIL NIL T
:pinfo ED (&OPTIONAL PATHNAME) NIL NIL NIL NIL NIL NIL T
:pinfo FILE-LENGTH (STREAM) NIL (FILE-STREAM) NIL NIL NIL NIL T
:pinfo PATHNAME-TYPE (P) NIL NIL NIL NIL NIL NIL T
:pinfo PATHNAME-VERSION (P) NIL NIL NIL NIL NIL NIL T
:pinfo PROBE-FILE (PATHNAME) NIL NIL NIL NIL NIL NIL T
:pinfo PARSE-NAMESTRING (NAMESTRING &OPTIONAL HOST (DEFAULTS *DEFAULT-PATHNAME-DEFAULTS*) &KEY (START 0) END JUNK-ALLOWED) NIL NIL NIL NIL NIL NIL T
:pinfo MAKE-PATHNAME (&KEY (HOST NIL HOST?) (DEVICE NIL DEVICE?) (DIRECTORY NIL DIRECTORY?) (NAME NIL NAME?) (TYPE NIL TYPE?) DEFAULTS) NIL NIL NIL NIL NIL NIL T
:pinfo NULL-STRING->NIL (STRING) NIL NIL NIL NIL NIL NIL T
:pinfo PATHNAME-NAME (P) NIL NIL NIL NIL NIL NIL T
:pinfo DIRECTORY (DIR) NIL NIL NIL NIL NIL NIL T
:pinfo NAMESTRING (NAME) NIL NIL NIL NIL NIL NIL T
:pinfo PATHNAME->STRING (P) NIL NIL NIL NIL NIL NIL T
:pinfo DIRECTORY-NAMESTRING (FILE) NIL NIL NIL NIL NIL NIL T
:pinfo NIL->EMPTY-STRING (X) NIL NIL NIL NIL NIL NIL T
:pinfo NAMESTRING->DIRLIST (NAMESTRING LAST) NIL NIL NIL NIL NIL NIL T
:pinfo TRUENAME (PATHNAME) NIL NIL NIL NIL NIL NIL T
:pinfo PATHNAME-DEVICE (P) NIL NIL NIL NIL NIL NIL T
:pinfo HOST-NAMESTRING (FILE) NIL NIL NIL NIL NIL NIL T
:pinfo FILE-AUTHOR (STREAM) NIL (FILE-STREAM) NIL NIL NIL NIL T
:pinfo FILE-WRITE-DATE (FILENAME) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_lsp_DELETE_2DFILE();
extern SYMBOL s_lsp_NAMESTRING; 
extern SYMBOL s_lsp_T; 
MAKE_SIMPLE_STRING(k1859,21,"Cannot delete file ~A");
extern SYMBOL s_lsp_ERROR; 
extern LP p_lsp_ENOUGH_2DNAMESTRING();
extern LP p_lsp_FILE_2DAUTHOR();
extern SYMBOL s_lsp_FILE_2DSTREAM_2DP; 
extern SYMBOL s_lsp_FILE_2DSTREAM; 
extern SYMBOL s_lsp_WTA; 
MAKE_SIMPLE_STRING(k1860,17,"write FILE-AUTHOR");
extern SYMBOL s_lsp_WARN; 
extern SYMBOL s_lsp_NIL; 
extern LP p_lsp_FILE_2DLENGTH();
extern LP p_lsp_FILE_2DPOSITION();
extern SYMBOL s_key_START; 
extern SYMBOL s_lsp_EQL; 
extern SYMBOL s_key_END; 
extern SYMBOL s_lsp_FIXNUMP; 
extern SYMBOL s_lsp_FILE_2DLENGTH; 
MAKE_SIMPLE_STRING(k1861,38,"~D is not a legal file-position for ~A");
extern LP p_lsp_FILE_2DWRITE_2DDATE();
extern SYMBOL s_lsp_UNIX_2D_3EUNIVERSAL_2DTIME; 
extern LP p_lsp_MAKE_2DPATHNAME();
extern SYMBOL s_key_HOST; 
extern SYMBOL s_key_DEVICE; 
extern SYMBOL s_key_DIRECTORY; 
extern SYMBOL s_key_NAME; 
extern SYMBOL s_key_TYPE; 
extern SYMBOL s_key_DEFAULTS; 
extern SYMBOL s_lsp_PATHNAME; 
extern SYMBOL s_lsp_PATHNAME_2DHOST; 
extern SYMBOL s_lsp_PATHNAME_2DDEVICE; 
extern SYMBOL s_lsp_PATHNAME_2DDIRECTORY; 
extern SYMBOL s_lsp_PATHNAME_2DNAME; 
extern SYMBOL s_lsp_PATHNAME_2DTYPE; 
extern SYMBOL s_lsp_MAKE_2DPHYSICAL_2DPATHNAME_2F7; 
extern LP p_lsp_MERGE_2DPATHNAMES();
extern SYMBOL s_lsp__2ADEFAULT_2DPATHNAME_2DDEFAULTS_2A; 
extern SYMBOL s_lsp_UNSAFE_2DSYMBOL_2DVALUE; 
extern SYMBOL s_lsp_CAR; 
extern SYMBOL s_key_RELATIVE; 
extern SYMBOL s_lsp_EQ; 
extern SYMBOL s_lsp_CDR; 
extern SYMBOL s_lsp_APPEND_2F2; 
extern SYMBOL s_key_UP; 
extern SYMBOL s_lsp_BUTLAST; 
extern SYMBOL s_lsp_MAKE_2DPATHNAME; 
extern LP p_lsp_NAMESTRING();
extern SYMBOL s_lsp_PATHNAMEP; 
extern SYMBOL s_lsp_PATHNAME_2D_3ESTRING; 
extern SYMBOL s_lsp_STRING_2DP; 
extern SYMBOL s_lsp_STREAMP; 
extern SYMBOL s_lsp_SYMBOLP; 
extern SYMBOL s_lsp_SYMBOL_2DNAME; 
MAKE_SIMPLE_STRING(k1863,36,"~S is not one of these types:~{ ~A~}");
extern SYMBOL s_lsp_PHYSICAL_2DPATHNAME; 
extern SYMBOL s_lsp_STRING; 
extern SYMBOL s_lsp_STREAM; 
extern SYMBOL s_lsp_SYMBOL; 
MAKE_CONS(k1867,LREF(s_lsp_SYMBOL),LREF(s_lsp_NIL));
MAKE_CONS(k1866,LREF(s_lsp_STREAM),LREF(k1867));
MAKE_CONS(k1865,LREF(s_lsp_STRING),LREF(k1866));
MAKE_CONS(k1864,LREF(s_lsp_PHYSICAL_2DPATHNAME),LREF(k1865));
extern LP p_lsp_PARSE_2DNAMESTRING();
extern SYMBOL s_key_JUNK_2DALLOWED; 
extern SYMBOL s_lsp_LENGTH; 
extern SYMBOL s_lsp_PARSE_2DNAMESTRING_2D1; 
extern LP p_lsp_PARSE_2DNAMESTRING_2D1();
extern SYMBOL s_key_ABSOLUTE; 
extern SYMBOL s_lsp_NAMESTRING_2D_3EDIRLIST; 
extern SYMBOL s_lsp_CONS; 
extern SYMBOL s_key_HOME; 
extern SYMBOL s_key_FROM_2DEND; 
extern SYMBOL s_lsp_POSITION; 
extern SYMBOL s_lsp_1_2B; 
extern SYMBOL s_key_NAMESTRING; 
extern SYMBOL s_lsp_SUBSEQ; 
extern SYMBOL s_lsp_NULL_2DSTRING_2D_3ENIL; 
extern LP p_lsp_NULL_2DSTRING_2D_3ENIL();
extern LP p_lsp_NAMESTRING_2D_3EDIRLIST();
extern LP p_lsp_PATHNAME_2DDEVICE();
extern LP p_lsp_PATHNAME_2DDIRECTORY();
extern LP p_lsp_PATHNAME_2DHOST();
extern LP p_lsp_PATHNAME_2DNAME();
extern LP p_lsp_NIL_2D_3EEMPTY_2DSTRING();
MAKE_SIMPLE_STRING(k1868,0,"");
extern LP p_lsp_PATHNAME_2D_3ESTRING();
MAKE_SIMPLE_STRING(k1869,15,"~A~{~A/~}~A~A~A");
MAKE_SIMPLE_STRING(k1870,1,"/");
MAKE_SIMPLE_STRING(k1871,2,"./");
MAKE_SIMPLE_STRING(k1872,3,"../");
extern SYMBOL s_lsp_NIL_2D_3EEMPTY_2DSTRING; 
MAKE_SIMPLE_STRING(k1873,1,".");
extern SYMBOL s_lsp_FORMAT; 
extern LP p_lsp_PATHNAME_2DTYPE();
extern LP p_lsp_PATHNAME_2DVERSION();
extern LP p_lsp_PATHNAME();
extern SYMBOL s_lsp_PARSE_2DNAMESTRING; 
MAKE_CONS(k1876,LREF(s_lsp_STREAM),LREF(s_lsp_NIL));
MAKE_CONS(k1875,LREF(s_lsp_PATHNAME),LREF(k1876));
MAKE_CONS(k1874,LREF(s_lsp_STRING),LREF(k1875));
extern LP p_lsp_PROBE_2DFILE();
extern SYMBOL s_lsp_STRINGP; 
extern LP p_lsp_TRUENAME();
MAKE_SIMPLE_STRING(k1877,26,"The file ~S does not exist");
extern LP p_lsp_DIRECTORY();
extern SYMBOL s_lsp_DIRDESC; 
extern SYMBOL s_lsp_DIRENT; 
extern SYMBOL s_lsp_MERGE_2DPATHNAMES; 
extern SYMBOL s_lsp_RPLACD; 
extern LP p_lsp_ED();
MAKE_SIMPLE_STRING(k1878,19,"No editor available");
extern LP p_lsp_FILE_2DNAMESTRING();
extern SYMBOL s_lsp_CONCATENATE; 
extern LP p_lsp_DIRECTORY_2DNAMESTRING();
extern LP p_lsp_HOST_2DNAMESTRING();


extern int closedir();
struct DIRENT {
int OFFSET;
int FILENO;
short RECLEN;
short NAMLEN;
char NAME[256];
};
extern struct DIRENT * readdir();
extern struct DIRDESC * opendir();
extern LP probe_file();
extern LP vref();
extern LP geq_p();
extern int file_write_date();
extern int ftell();
extern LP leq_p();
extern int fseek();
extern int file_length();
extern LP num_equal_p();
extern int unlink();


LP p_lsp_DELETE_2DFILE(argc, v_PATHNAME_0)
      ARGC argc;  LP v_PATHNAME_0;
{
LP v_STATUS_3; LP v_FILENAME_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
if (argc != 1) wna(argc,1);
v_FILENAME_2 = ICALL(s_lsp_NAMESTRING) (1, v_PATHNAME_0);
v_STATUS_3 = INT_TO_FX(unlink(lisp_to_c_array(v_FILENAME_2)));
t1 = (num_equal_p((v_STATUS_3), ((LP) 0)));
if (t1 != NIL) {
return(LREF(s_lsp_T));
} else {
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,2), LREF(k1859), v_FILENAME_2);
return(t0);
}
}

LP p_lsp_ENOUGH_2DNAMESTRING(argc, v_NAME_0)
      ARGC argc;  LP v_NAME_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_NAMESTRING) (MV_CALL(argc,1), v_NAME_0);
return(t0);
}

LP p_lsp_FILE_2DAUTHOR(argc, v_STREAM_0)
      ARGC argc;  LP v_STREAM_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_FILE_2DSTREAM_2DP) (1, v_STREAM_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_STREAM_0, LREF(s_lsp_FILE_2DSTREAM), (LP) 0);
}
ICALL(s_lsp_WARN) (1, LREF(k1860));
return(LREF(s_lsp_NIL));
}

LP p_lsp_FILE_2DLENGTH(argc, v_STREAM_0)
      ARGC argc;  LP v_STREAM_0;
{
LP v_I_5; LP v_S_4; LP v_S_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_FILE_2DSTREAM_2DP) (1, v_STREAM_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_STREAM_0, LREF(s_lsp_FILE_2DSTREAM), (LP) 0);
}
v_S_2 = v_STREAM_0;
v_S_4 = v_STREAM_0;
v_I_5 = (LP) 6;
t2 = ((LP) DEREF((v_STREAM_0) + 3 * 4));
t1 = INT_TO_FX(file_length(RAW_FPTR(t2)));
return(t1);
}

LP p_lsp_FILE_2DPOSITION(va_alist) va_dcl
{
LP v_KEY2499_15; LP v_FPTR_14; LP v_I_12; 
LP v_S_11; LP v_S_9; LP v_G2498_8; 
LP v_I_6; LP v_S_5; LP v_S_3; 
LP v_STREAM_0; LP v_POSITION_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 

int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_STREAM_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_POSITION_1 = NIL;
} else {
v_POSITION_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
v_S_3 = v_STREAM_0;
v_S_5 = v_STREAM_0;
v_I_6 = (LP) 6;
v_G2498_8 = ((LP) DEREF((v_STREAM_0) + 3 * 4));
if (v_G2498_8 != NIL) {
v_FPTR_14 = v_G2498_8;
} else {
v_S_9 = v_STREAM_0;
v_S_11 = v_STREAM_0;
v_I_12 = (LP) 8;
v_FPTR_14 = ((LP) DEREF((v_STREAM_0) + 4 * 4));
}
if (v_POSITION_1 != NIL) {
v_KEY2499_15 = v_POSITION_1;
t1 = ICALL(s_lsp_EQL) (2, v_KEY2499_15, LREF(s_key_START));
if (t1 != NIL) {
INT_TO_FX(fseek(RAW_FPTR(v_FPTR_14), 0, 0));
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY2499_15, LREF(s_key_END));
if (t2 != NIL) {
INT_TO_FX(fseek(RAW_FPTR(v_FPTR_14), 0, 2));
} else {
t4 = ICALL(s_lsp_FIXNUMP) (1, v_POSITION_1);
if (t4 != NIL) {
t5 = ICALL(s_lsp_FILE_2DLENGTH) (1, v_STREAM_0);
t3 = (leq_p((v_POSITION_1), (t5)));
} else {
t3 = LREF(s_lsp_NIL);
}
if (t3 != NIL) {
INT_TO_FX(fseek(RAW_FPTR(v_FPTR_14), FX_TO_INT(v_POSITION_1), 0));
} else {
ICALL(s_lsp_ERROR) (3, LREF(k1861), v_POSITION_1, v_STREAM_0);
}
}
}
return(LREF(s_lsp_T));
} else {
t0 = INT_TO_FX(ftell(RAW_FPTR(v_FPTR_14)));
return(t0);
}
}

LP p_lsp_FILE_2DWRITE_2DDATE(argc, v_FILENAME_0)
      ARGC argc;  LP v_FILENAME_0;
{
LP v_DATE_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_NAMESTRING) (1, v_FILENAME_0);
v_DATE_2 = INT_TO_FX(file_write_date(lisp_to_c_array(t0)));
t2 = (num_equal_p((v_DATE_2), ((LP) -2)));
if (t2 != NIL) {
return(LREF(s_lsp_NIL));
} else {
t1 = ICALL(s_lsp_UNIX_2D_3EUNIVERSAL_2DTIME) (MV_CALL(argc,1), v_DATE_2);
return(t1);
}
}

LP p_lsp_MAKE_2DPATHNAME(va_alist) va_dcl
{
LP v_NAMESTRING_27; LP v_VERSION_26; LP v_TYPE_25; 
LP v_NAME_24; LP v_DIRECTORY_23; LP v_DEVICE_22; 
LP v_HOST_21; LP v_NAMESTRING_20; LP v_VERSION_19; 
LP v_TYPE_18; LP v_NAME_17; LP v_DIRECTORY_16; 
LP v_DEVICE_15; LP v_HOST_14; LP v_DEFAULT_2DPATHNAME_13; 
LP v_KEYS2500_11; LP v_DEFAULTS_10; LP v_TYPE_3F_9; 
LP v_TYPE_8; LP v_NAME_3F_7; LP v_NAME_6; 
LP v_DIRECTORY_3F_5; LP v_DIRECTORY_4; LP v_DEVICE_3F_3; 
LP v_DEVICE_2; LP v_HOST_3F_1; LP v_HOST_0; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
DYNAMIC_RESTIFY(v_KEYS2500_11,1,NEXT_VAR_ARG);
v_HOST_3F_1 = T;
BEGIN_KEY_INIT(v_HOST_0,LREF(s_key_HOST),v_KEYS2500_11)
v_HOST_3F_1 = NIL;
v_HOST_0 = LREF(s_lsp_NIL);
END_KEY_INIT
v_DEVICE_3F_3 = T;
BEGIN_KEY_INIT(v_DEVICE_2,LREF(s_key_DEVICE),v_KEYS2500_11)
v_DEVICE_3F_3 = NIL;
v_DEVICE_2 = LREF(s_lsp_NIL);
END_KEY_INIT
v_DIRECTORY_3F_5 = T;
BEGIN_KEY_INIT(v_DIRECTORY_4,LREF(s_key_DIRECTORY),v_KEYS2500_11)
v_DIRECTORY_3F_5 = NIL;
v_DIRECTORY_4 = LREF(s_lsp_NIL);
END_KEY_INIT
v_NAME_3F_7 = T;
BEGIN_KEY_INIT(v_NAME_6,LREF(s_key_NAME),v_KEYS2500_11)
v_NAME_3F_7 = NIL;
v_NAME_6 = LREF(s_lsp_NIL);
END_KEY_INIT
v_TYPE_3F_9 = T;
BEGIN_KEY_INIT(v_TYPE_8,LREF(s_key_TYPE),v_KEYS2500_11)
v_TYPE_3F_9 = NIL;
v_TYPE_8 = LREF(s_lsp_NIL);
END_KEY_INIT
BEGIN_KEY_INIT(v_DEFAULTS_10,LREF(s_key_DEFAULTS),v_KEYS2500_11)
v_DEFAULTS_10 = NIL;
END_KEY_INIT
END_VAR_ARGS;
if (v_DEFAULTS_10 != NIL) {
v_DEFAULT_2DPATHNAME_13 = ICALL(s_lsp_PATHNAME) (1, v_DEFAULTS_10);
} else {
v_DEFAULT_2DPATHNAME_13 = LREF(s_lsp_NIL);
}
if (v_HOST_3F_1 != NIL) {
v_HOST_21 = v_HOST_0;
} else {
if (v_DEFAULTS_10 != NIL) {
v_HOST_21 = ICALL(s_lsp_PATHNAME_2DHOST) (1, v_DEFAULTS_10);
} else {
v_HOST_21 = LREF(s_lsp_NIL);
}
}
if (v_DEVICE_3F_3 != NIL) {
v_DEVICE_22 = v_DEVICE_2;
} else {
if (v_DEFAULTS_10 != NIL) {
v_DEVICE_22 = ICALL(s_lsp_PATHNAME_2DDEVICE) (1, v_DEFAULTS_10);
} else {
v_DEVICE_22 = LREF(s_lsp_NIL);
}
}
if (v_DIRECTORY_3F_5 != NIL) {
v_DIRECTORY_23 = v_DIRECTORY_4;
} else {
if (v_DEFAULTS_10 != NIL) {
v_DIRECTORY_23 = ICALL(s_lsp_PATHNAME_2DDIRECTORY) (1, v_DEFAULTS_10);
} else {
v_DIRECTORY_23 = LREF(s_lsp_NIL);
}
}
if (v_NAME_3F_7 != NIL) {
v_NAME_24 = v_NAME_6;
} else {
if (v_DEFAULTS_10 != NIL) {
v_NAME_24 = ICALL(s_lsp_PATHNAME_2DNAME) (1, v_DEFAULTS_10);
} else {
v_NAME_24 = LREF(s_lsp_NIL);
}
}
if (v_TYPE_3F_9 != NIL) {
v_TYPE_25 = v_TYPE_8;
} else {
if (v_DEFAULTS_10 != NIL) {
v_TYPE_25 = ICALL(s_lsp_PATHNAME_2DTYPE) (1, v_DEFAULTS_10);
} else {
v_TYPE_25 = LREF(s_lsp_NIL);
}
}
t0 = ICALL(s_lsp_MAKE_2DPHYSICAL_2DPATHNAME_2F7) (MV_CALL(argc,7), v_HOST_21, v_DEVICE_22, v_DIRECTORY_23, v_NAME_24, v_TYPE_25, LREF(s_lsp_NIL), LREF(s_lsp_NIL));
return(t0);
}

LP p_lsp_MERGE_2DPATHNAMES(va_alist) va_dcl
{
LP v_G2502_10; LP v_G2501_9; LP v_DIR_8; 
LP v_SECONDARY_2DDIR_7; LP v_PRIMARY_2DDIR_6; LP v_SECONDARY_5; 
LP v_PRIMARY_4; LP v_NAME_0; LP v_DEFAULT_2DVERSION_2; 
LP v_DEFAULTS_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 

int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_NAME_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 3) wna_high(real_argc,3);
if (real_argc < 2) {
t0 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ADEFAULT_2DPATHNAME_2DDEFAULTS_2A));
v_DEFAULTS_1 = t0;
} else {
v_DEFAULTS_1 = NEXT_VAR_ARG;
}
if (real_argc < 3) {
v_DEFAULT_2DVERSION_2 = NIL;
} else {
v_DEFAULT_2DVERSION_2 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
v_PRIMARY_4 = ICALL(s_lsp_PATHNAME) (1, v_NAME_0);
v_SECONDARY_5 = ICALL(s_lsp_PATHNAME) (1, v_DEFAULTS_1);
v_PRIMARY_2DDIR_6 = ICALL(s_lsp_PATHNAME_2DDIRECTORY) (1, v_PRIMARY_4);
v_SECONDARY_2DDIR_7 = ICALL(s_lsp_PATHNAME_2DDIRECTORY) (1, v_SECONDARY_5);
if (v_PRIMARY_2DDIR_6 != NIL) {
if (v_SECONDARY_2DDIR_7 != NIL) {
t2 = ICALL(s_lsp_CAR) (1, v_PRIMARY_2DDIR_6);
t1 = ICALL(s_lsp_EQ) (2, t2, LREF(s_key_RELATIVE));
if (t1 != NIL) {
t3 = ICALL(s_lsp_CDR) (1, v_PRIMARY_2DDIR_6);
v_DIR_8 = ICALL(s_lsp_APPEND_2F2) (2, v_SECONDARY_2DDIR_7, t3);
} else {
t5 = ICALL(s_lsp_CAR) (1, v_PRIMARY_2DDIR_6);
t4 = ICALL(s_lsp_EQ) (2, t5, LREF(s_key_UP));
if (t4 != NIL) {
t6 = ICALL(s_lsp_BUTLAST) (1, v_SECONDARY_2DDIR_7);
t7 = ICALL(s_lsp_CDR) (1, v_PRIMARY_2DDIR_6);
v_DIR_8 = ICALL(s_lsp_APPEND_2F2) (2, t6, t7);
} else {
v_DIR_8 = v_PRIMARY_2DDIR_6;
}
}
} else {
v_DIR_8 = v_PRIMARY_2DDIR_6;
}
} else {
v_DIR_8 = v_SECONDARY_2DDIR_7;
}
v_G2501_9 = ICALL(s_lsp_PATHNAME_2DNAME) (1, v_PRIMARY_4);
if (v_G2501_9 != NIL) {
t9 = v_G2501_9;
} else {
t9 = ICALL(s_lsp_PATHNAME_2DNAME) (1, v_SECONDARY_5);
}
v_G2502_10 = ICALL(s_lsp_PATHNAME_2DTYPE) (1, v_PRIMARY_4);
if (v_G2502_10 != NIL) {
t10 = v_G2502_10;
} else {
t10 = ICALL(s_lsp_PATHNAME_2DTYPE) (1, v_SECONDARY_5);
}
t8 = ICALL(s_lsp_MAKE_2DPATHNAME) (MV_CALL(argc,10), LREF(s_key_HOST), LREF(s_lsp_NIL), LREF(s_key_DEVICE), LREF(s_lsp_NIL), LREF(s_key_DIRECTORY), v_DIR_8, LREF(s_key_NAME), t9, LREF(s_key_TYPE), t10);
return(t8);
}

LP p_lsp_NAMESTRING(argc, v_NAME_0)
      ARGC argc;  LP v_NAME_0;
{
LP v_I_26; LP v_S_25; LP v_S_23; 
LP v_I_21; LP v_S_20; LP v_S_18; 
LP v_I_16; LP v_S_15; LP v_S_13; 
LP v_VALUE_11; LP v_N_10; LP v_S_9; 
LP v_VALUE_7; LP v_S_6; LP v_T2506_5; 
LP v_S2505_4; LP v_KEY2504_3; LP v_KEY2503_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; 
if (argc != 1) wna(argc,1);
START1862:
v_KEY2503_2 = v_NAME_0;
v_KEY2504_3 = v_KEY2503_2;
t1 = ICALL(s_lsp_PATHNAMEP) (1, v_KEY2504_3);
if (t1 != NIL) {
v_S_18 = v_NAME_0;
v_S_20 = v_NAME_0;
v_I_21 = (LP) 14;
t2 = ((LP) DEREF((v_NAME_0) + 7 * 4));
if (t2 != NIL) {
v_S_13 = v_NAME_0;
v_S_15 = v_NAME_0;
v_I_16 = (LP) 14;
t0 = ((LP) DEREF((v_NAME_0) + 7 * 4));
return(t0);
} else {
t3 = ICALL(s_lsp_PATHNAME) (1, v_NAME_0);
v_S2505_4 = ICALL(s_lsp_PATHNAME_2D_3ESTRING) (1, t3);
v_T2506_5 = v_NAME_0;
v_S_6 = v_NAME_0;
v_VALUE_7 = v_S2505_4;
v_S_9 = v_NAME_0;
v_N_10 = (LP) 14;
v_VALUE_11 = v_S2505_4;
t0 = ((LP) (DEREF((v_NAME_0) + 7 * 4) = (LD) (v_S2505_4)));
return(t0);
}
} else {
t4 = ICALL(s_lsp_STRING_2DP) (1, v_KEY2504_3);
if (t4 != NIL) {
return(v_NAME_0);
} else {
t5 = ICALL(s_lsp_STREAMP) (1, v_KEY2504_3);
if (t5 != NIL) {
v_S_23 = v_NAME_0;
v_S_25 = v_NAME_0;
v_I_26 = (LP) 30;
t6 = ((LP) DEREF((v_NAME_0) + 15 * 4));
v_NAME_0 = t6; 
goto START1862;
} else {
t7 = ICALL(s_lsp_SYMBOLP) (1, v_KEY2504_3);
if (t7 != NIL) {
t0 = ICALL(s_lsp_SYMBOL_2DNAME) (MV_CALL(argc,1), v_NAME_0);
return(t0);
} else {
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,3), LREF(k1863), v_KEY2503_2, LREF(k1864));
return(t0);
}
}
}
}
}

LP p_lsp_PARSE_2DNAMESTRING(va_alist) va_dcl
{
LP v_LAST_10; LP v_G2508_9; LP v_STRING_8; 
LP v_NAMESTRING_0; LP v_KEYS2507_6; LP v_JUNK_2DALLOWED_5; 
LP v_END_4; LP v_START_3; LP v_DEFAULTS_2; 
LP v_HOST_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_NAMESTRING_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc < 2) {
v_HOST_1 = NIL;
} else {
v_HOST_1 = NEXT_VAR_ARG;
}
if (real_argc < 3) {
t0 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ADEFAULT_2DPATHNAME_2DDEFAULTS_2A));
v_DEFAULTS_2 = t0;
} else {
v_DEFAULTS_2 = NEXT_VAR_ARG;
}
DYNAMIC_RESTIFY(v_KEYS2507_6,4,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_START_3,LREF(s_key_START),v_KEYS2507_6)
v_START_3 = (LP) 0;
END_KEY_INIT
BEGIN_KEY_INIT(v_END_4,LREF(s_key_END),v_KEYS2507_6)
v_END_4 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_JUNK_2DALLOWED_5,LREF(s_key_JUNK_2DALLOWED),v_KEYS2507_6)
v_JUNK_2DALLOWED_5 = NIL;
END_KEY_INIT
END_VAR_ARGS;
v_STRING_8 = ICALL(s_lsp_STRING) (1, v_NAMESTRING_0);
v_G2508_9 = v_END_4;
if (v_G2508_9 != NIL) {
v_LAST_10 = v_G2508_9;
} else {
v_LAST_10 = ICALL(s_lsp_LENGTH) (1, v_STRING_8);
}
t1 = ICALL(s_lsp_PARSE_2DNAMESTRING_2D1) (2, v_STRING_8, v_LAST_10);
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,v_LAST_10);
}
return(t1);
}

LP p_lsp_PARSE_2DNAMESTRING_2D1(argc, v_NAMESTRING_0, v_END_1)
      ARGC argc;  LP v_NAMESTRING_0; LP v_END_1;
{
LP v_CHAR2_31; LP v_CHAR1_30; LP v_G2509_29; 
LP v_TYPE_2DSTART_28; LP v_DOT_27; LP v_FILENAME_2DSTART_26; 
LP v_LAST_2DSLASH_25; LP v_DIRLIST_24; LP v_CHAR2_22; 
LP v_CHAR1_21; LP v_CHAR2_19; LP v_CHAR1_18; 
LP v_CHAR2_16; LP v_CHAR1_15; LP v_CHAR2_13; 
LP v_CHAR1_12; LP v_CHAR2_10; LP v_CHAR1_9; 
LP v_CHAR2_7; LP v_CHAR1_6; LP v_L_5; 
LP v_SECOND_2DCHAR_4; LP v_FIRST_2DCHAR_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; 
if (argc != 2) wna(argc,2);
t1 = (geq_p((v_END_1), ((LP) 4)));
if (t1 != NIL) {
v_FIRST_2DCHAR_3 = (vref((v_NAMESTRING_0), ((LP) 0)));
v_SECOND_2DCHAR_4 = (vref((v_NAMESTRING_0), ((LP) 2)));
v_CHAR1_21 = v_FIRST_2DCHAR_3;
v_CHAR2_22 = LREF(char_tab[47]);
if (((v_FIRST_2DCHAR_3) == (LREF(char_tab[47])))) {
t3 = ICALL(s_lsp_NAMESTRING_2D_3EDIRLIST) (2, v_NAMESTRING_0, (LP) 0);
v_DIRLIST_24 = ICALL(s_lsp_CONS) (2, LREF(s_key_ABSOLUTE), t3);
} else {
v_CHAR1_18 = v_FIRST_2DCHAR_3;
v_CHAR2_19 = LREF(char_tab[126]);
if (((v_FIRST_2DCHAR_3) == (LREF(char_tab[126])))) {
t5 = ICALL(s_lsp_NAMESTRING_2D_3EDIRLIST) (2, v_NAMESTRING_0, (LP) 2);
v_DIRLIST_24 = ICALL(s_lsp_CONS) (2, LREF(s_key_HOME), t5);
} else {
v_CHAR1_15 = v_FIRST_2DCHAR_3;
v_CHAR2_16 = LREF(char_tab[46]);
if (((v_FIRST_2DCHAR_3) == (LREF(char_tab[46])))) {
v_CHAR1_12 = v_SECOND_2DCHAR_4;
v_CHAR2_13 = LREF(char_tab[47]);
t6 = (((v_SECOND_2DCHAR_4) == (LREF(char_tab[47]))) ? T : NIL);
} else {
t6 = LREF(s_lsp_NIL);
}
if (t6 != NIL) {
t8 = ICALL(s_lsp_NAMESTRING_2D_3EDIRLIST) (2, v_NAMESTRING_0, (LP) 4);
v_DIRLIST_24 = ICALL(s_lsp_CONS) (2, LREF(s_key_RELATIVE), t8);
} else {
v_CHAR1_9 = v_FIRST_2DCHAR_3;
v_CHAR2_10 = LREF(char_tab[46]);
if (((v_FIRST_2DCHAR_3) == (LREF(char_tab[46])))) {
v_CHAR1_6 = v_SECOND_2DCHAR_4;
v_CHAR2_7 = LREF(char_tab[46]);
t9 = (((v_SECOND_2DCHAR_4) == (LREF(char_tab[46]))) ? T : NIL);
} else {
t9 = LREF(s_lsp_NIL);
}
if (t9 != NIL) {
t11 = ICALL(s_lsp_NAMESTRING_2D_3EDIRLIST) (2, v_NAMESTRING_0, (LP) 4);
v_DIRLIST_24 = ICALL(s_lsp_CONS) (2, LREF(s_key_UP), t11);
} else {
v_L_5 = ICALL(s_lsp_NAMESTRING_2D_3EDIRLIST) (2, v_NAMESTRING_0, (LP) -2);
if (v_L_5 != NIL) {
v_DIRLIST_24 = ICALL(s_lsp_CONS) (2, LREF(s_key_RELATIVE), v_L_5);
} else {
v_DIRLIST_24 = v_L_5;
}
}
}
}
}
v_LAST_2DSLASH_25 = ICALL(s_lsp_POSITION) (4, LREF(char_tab[47]), v_NAMESTRING_0, LREF(s_key_FROM_2DEND), LREF(s_lsp_T));
if (v_LAST_2DSLASH_25 != NIL) {
v_FILENAME_2DSTART_26 = ICALL(s_lsp_1_2B) (1, v_LAST_2DSLASH_25);
} else {
v_FILENAME_2DSTART_26 = (LP) 0;
}
v_DOT_27 = ICALL(s_lsp_POSITION) (4, LREF(char_tab[46]), v_NAMESTRING_0, LREF(s_key_START), v_FILENAME_2DSTART_26);
if (v_DOT_27 != NIL) {
v_TYPE_2DSTART_28 = ICALL(s_lsp_1_2B) (1, v_DOT_27);
} else {
v_TYPE_2DSTART_28 = v_END_1;
}
v_G2509_29 = v_DOT_27;
if (v_G2509_29 != NIL) {
t14 = v_G2509_29;
} else {
t14 = v_END_1;
}
t13 = ICALL(s_lsp_SUBSEQ) (3, v_NAMESTRING_0, v_FILENAME_2DSTART_26, t14);
t12 = ICALL(s_lsp_NULL_2DSTRING_2D_3ENIL) (1, t13);
t16 = ICALL(s_lsp_SUBSEQ) (3, v_NAMESTRING_0, v_TYPE_2DSTART_28, v_END_1);
t15 = ICALL(s_lsp_NULL_2DSTRING_2D_3ENIL) (1, t16);
t0 = ICALL(s_lsp_MAKE_2DPATHNAME) (MV_CALL(argc,12), LREF(s_key_NAMESTRING), v_NAMESTRING_0, LREF(s_key_HOST), LREF(s_lsp_NIL), LREF(s_key_DEVICE), LREF(s_lsp_NIL), LREF(s_key_DIRECTORY), v_DIRLIST_24, LREF(s_key_NAME), t12, LREF(s_key_TYPE), t15);
return(t0);
} else {
t17 = ICALL(s_lsp_NULL_2DSTRING_2D_3ENIL) (1, v_NAMESTRING_0);
t20 = (num_equal_p((v_END_1), ((LP) 2)));
if (t20 != NIL) {
v_CHAR1_30 = (vref((v_NAMESTRING_0), ((LP) 0)));
t19 = (((v_CHAR1_30) == (LREF(char_tab[46]))) ? T : NIL);
} else {
t19 = LREF(s_lsp_NIL);
}
if (t19 != NIL) {
t18 = ICALL(s_lsp_CONS) (2, LREF(s_key_RELATIVE), LREF(s_lsp_NIL));
} else {
t18 = LREF(s_lsp_NIL);
}
t0 = ICALL(s_lsp_MAKE_2DPATHNAME) (MV_CALL(argc,6), LREF(s_key_NAMESTRING), v_NAMESTRING_0, LREF(s_key_NAME), t17, LREF(s_key_DIRECTORY), t18);
return(t0);
}
}

LP p_lsp_NULL_2DSTRING_2D_3ENIL(argc, v_STRING_0)
      ARGC argc;  LP v_STRING_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 1) wna(argc,1);
t2 = ICALL(s_lsp_LENGTH) (1, v_STRING_0);
t1 = (num_equal_p((t2), ((LP) 0)));
if (t1 != NIL) {
return(LREF(s_lsp_NIL));
} else {
return(v_STRING_0);
}
}

LP p_lsp_NAMESTRING_2D_3EDIRLIST(argc, v_NAMESTRING_0, v_LAST_1)
      ARGC argc;  LP v_NAMESTRING_0; LP v_LAST_1;
{
LP v_NEXT_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_1_2B) (1, v_LAST_1);
v_NEXT_3 = ICALL(s_lsp_POSITION) (4, LREF(char_tab[47]), v_NAMESTRING_0, LREF(s_key_START), t0);
if (v_NEXT_3 != NIL) {
t3 = ICALL(s_lsp_1_2B) (1, v_LAST_1);
t2 = ICALL(s_lsp_SUBSEQ) (3, v_NAMESTRING_0, t3, v_NEXT_3);
t4 = ICALL(s_lsp_NAMESTRING_2D_3EDIRLIST) (2, v_NAMESTRING_0, v_NEXT_3);
t1 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t2, t4);
return(t1);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_PATHNAME_2DDEVICE(argc, v_P_0)
      ARGC argc;  LP v_P_0;
{
LP v_I_5; LP v_S_4; LP v_S_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
v_S_2 = ICALL(s_lsp_PATHNAME) (1, v_P_0);
v_S_4 = v_S_2;
v_I_5 = (LP) 4;
t0 = ((LP) DEREF((v_S_2) + 2 * 4));
return(t0);
}

LP p_lsp_PATHNAME_2DDIRECTORY(argc, v_P_0)
      ARGC argc;  LP v_P_0;
{
LP v_I_5; LP v_S_4; LP v_S_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
v_S_2 = ICALL(s_lsp_PATHNAME) (1, v_P_0);
v_S_4 = v_S_2;
v_I_5 = (LP) 6;
t0 = ((LP) DEREF((v_S_2) + 3 * 4));
return(t0);
}

LP p_lsp_PATHNAME_2DHOST(argc, v_P_0)
      ARGC argc;  LP v_P_0;
{
LP v_I_5; LP v_S_4; LP v_S_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
v_S_2 = ICALL(s_lsp_PATHNAME) (1, v_P_0);
v_S_4 = v_S_2;
v_I_5 = (LP) 2;
t0 = ((LP) DEREF((v_S_2) + 1 * 4));
return(t0);
}

LP p_lsp_PATHNAME_2DNAME(argc, v_P_0)
      ARGC argc;  LP v_P_0;
{
LP v_I_5; LP v_S_4; LP v_S_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
v_S_2 = ICALL(s_lsp_PATHNAME) (1, v_P_0);
v_S_4 = v_S_2;
v_I_5 = (LP) 8;
t0 = ((LP) DEREF((v_S_2) + 4 * 4));
return(t0);
}

LP p_lsp_NIL_2D_3EEMPTY_2DSTRING(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
if (v_X_0 != NIL) {
return(v_X_0);
} else {
return(LREF(k1868));
}
}

LP p_lsp_PATHNAME_2D_3ESTRING(argc, v_P_0)
      ARGC argc;  LP v_P_0;
{
LP v_KEY2510_3; LP v_DIRLIST_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; 
if (argc != 1) wna(argc,1);
v_DIRLIST_2 = ICALL(s_lsp_PATHNAME_2DDIRECTORY) (1, v_P_0);
v_KEY2510_3 = ICALL(s_lsp_CAR) (1, v_DIRLIST_2);
t2 = ICALL(s_lsp_EQL) (2, v_KEY2510_3, LREF(s_key_ABSOLUTE));
if (t2 != NIL) {
t1 = LREF(k1870);
} else {
t3 = ICALL(s_lsp_EQL) (2, v_KEY2510_3, LREF(s_key_RELATIVE));
if (t3 != NIL) {
t1 = LREF(k1871);
} else {
t4 = ICALL(s_lsp_EQL) (2, v_KEY2510_3, LREF(s_key_UP));
if (t4 != NIL) {
t1 = LREF(k1872);
} else {
t1 = LREF(k1868);
}
}
}
t5 = ICALL(s_lsp_CDR) (1, v_DIRLIST_2);
t7 = ICALL(s_lsp_PATHNAME_2DNAME) (1, v_P_0);
t6 = ICALL(s_lsp_NIL_2D_3EEMPTY_2DSTRING) (1, t7);
t9 = ICALL(s_lsp_PATHNAME_2DTYPE) (1, v_P_0);
if (t9 != NIL) {
t8 = LREF(k1873);
} else {
t8 = LREF(k1868);
}
t11 = ICALL(s_lsp_PATHNAME_2DTYPE) (1, v_P_0);
t10 = ICALL(s_lsp_NIL_2D_3EEMPTY_2DSTRING) (1, t11);
t0 = ICALL(s_lsp_FORMAT) (MV_CALL(argc,7), LREF(s_lsp_NIL), LREF(k1869), t1, t5, t6, t8, t10);
return(t0);
}

LP p_lsp_PATHNAME_2DTYPE(argc, v_P_0)
      ARGC argc;  LP v_P_0;
{
LP v_I_5; LP v_S_4; LP v_S_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
v_S_2 = ICALL(s_lsp_PATHNAME) (1, v_P_0);
v_S_4 = v_S_2;
v_I_5 = (LP) 10;
t0 = ((LP) DEREF((v_S_2) + 5 * 4));
return(t0);
}

LP p_lsp_PATHNAME_2DVERSION(argc, v_P_0)
      ARGC argc;  LP v_P_0;
{
LP v_I_5; LP v_S_4; LP v_S_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
v_S_2 = ICALL(s_lsp_PATHNAME) (1, v_P_0);
v_S_4 = v_S_2;
v_I_5 = (LP) 12;
t0 = ((LP) DEREF((v_S_2) + 6 * 4));
return(t0);
}

LP p_lsp_PATHNAME(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{
LP v_I_7; LP v_S_6; LP v_S_4; 
LP v_KEY2512_3; LP v_KEY2511_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; 
if (argc != 1) wna(argc,1);
v_KEY2511_2 = v_X_0;
v_KEY2512_3 = v_KEY2511_2;
t1 = ICALL(s_lsp_STRING_2DP) (1, v_KEY2512_3);
if (t1 != NIL) {
t2 = ICALL(s_lsp_PARSE_2DNAMESTRING) (1, v_X_0);
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,1);
}
return(t2);
} else {
t3 = ICALL(s_lsp_PATHNAMEP) (1, v_KEY2512_3);
if (t3 != NIL) {
return(v_X_0);
} else {
t4 = ICALL(s_lsp_STREAMP) (1, v_KEY2512_3);
if (t4 != NIL) {
v_S_4 = v_X_0;
v_S_6 = v_X_0;
v_I_7 = (LP) 30;
t0 = ((LP) DEREF((v_X_0) + 15 * 4));
return(t0);
} else {
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,3), LREF(k1863), v_KEY2511_2, LREF(k1874));
return(t0);
}
}
}
}

LP p_lsp_PROBE_2DFILE(argc, v_PATHNAME_0)
      ARGC argc;  LP v_PATHNAME_0;
{
LP v_TRUENAME_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_NAMESTRING) (1, v_PATHNAME_0);
v_TRUENAME_2 = (probe_file(lisp_to_c_array(t0)));
t2 = ICALL(s_lsp_STRINGP) (1, v_TRUENAME_2);
if (t2 != NIL) {
t1 = ICALL(s_lsp_PATHNAME) (MV_CALL(argc,1), v_TRUENAME_2);
return(t1);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_TRUENAME(argc, v_PATHNAME_0)
      ARGC argc;  LP v_PATHNAME_0;
{
LP v_TRUENAME_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_NAMESTRING) (1, v_PATHNAME_0);
v_TRUENAME_2 = (probe_file(lisp_to_c_array(t0)));
t2 = (num_equal_p((v_TRUENAME_2), ((LP) 0)));
if (t2 != NIL) {
t1 = ICALL(s_lsp_ERROR) (MV_CALL(argc,2), LREF(k1877), v_PATHNAME_0);
return(t1);
} else {
return(v_TRUENAME_2);
}
}

LP p_lsp_DIRECTORY(argc, v_DIR_0)
      ARGC argc;  LP v_DIR_0;
{
LP v_S_12; LP v_LOOPVAR_2D822_8; LP v_LOOPVAR_2D821_7; 
LP v_LOOPVAR_2D820_6; LP v_DIRENT_5; LP v_DIRP_4; 
LP v_NAME_3; LP v_PATH_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 

if (argc != 1) wna(argc,1);
v_PATH_2 = ICALL(s_lsp_PATHNAME) (1, v_DIR_0);
v_NAME_3 = ICALL(s_lsp_NAMESTRING) (1, v_PATH_2);
v_DIRP_4 = NEW_FPTR(LREF(s_lsp_DIRDESC), opendir(lisp_to_c_array(v_NAME_3)));
v_DIRENT_5 = LREF(s_lsp_NIL);
v_LOOPVAR_2D820_6 = LREF(s_lsp_NIL);
v_LOOPVAR_2D821_7 = LREF(s_lsp_NIL);
v_LOOPVAR_2D822_8 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_10:;
v_DIRENT_5 = NEW_FPTR(LREF(s_lsp_DIRENT), readdir(RAW_FPTR(v_DIRP_4)));
t1 = ICALL(s_lsp_EQ) (2, v_DIRENT_5, (LP) 0);
if (t1 != NIL) {
goto t_END_2DLOOP_11;
}
v_S_12 = v_DIRENT_5;
t3 = c_to_lisp_string((LP) (((struct DIRENT *) (RAW_FPTR(v_S_12)))->NAME));
t2 = ICALL(s_lsp_MERGE_2DPATHNAMES) (2, t3, v_PATH_2);
v_LOOPVAR_2D822_8 = ICALL(s_lsp_CONS) (2, t2, LREF(s_lsp_NIL));
if (v_LOOPVAR_2D821_7 != NIL) {
t4 = ICALL(s_lsp_RPLACD) (2, v_LOOPVAR_2D821_7, v_LOOPVAR_2D822_8);
v_LOOPVAR_2D821_7 = ICALL(s_lsp_CDR) (1, t4);
} else {
v_LOOPVAR_2D820_6 = v_LOOPVAR_2D822_8;
v_LOOPVAR_2D821_7 = v_LOOPVAR_2D820_6;
}
goto t_NEXT_2DLOOP_10;
goto t_END_2DLOOP_11;
t_END_2DLOOP_11:;
INT_TO_FX(closedir(RAW_FPTR(v_DIRP_4)));
return(v_LOOPVAR_2D820_6);
return(NIL);
return(NIL);
}

LP p_lsp_ED(va_alist) va_dcl
{
LP v_PATHNAME_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
if (real_argc > 1) wna_high(real_argc,1);
if (real_argc < 1) {
v_PATHNAME_0 = NIL;
} else {
v_PATHNAME_0 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t0 = ICALL(s_lsp_WARN) (MV_CALL(argc,1), LREF(k1878));
return(t0);
}

LP p_lsp_FILE_2DNAMESTRING(argc, v_FILE_0)
      ARGC argc;  LP v_FILE_0;
{
LP v_PATHNAME_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
v_PATHNAME_2 = ICALL(s_lsp_PATHNAME) (1, v_FILE_0);
t1 = ICALL(s_lsp_PATHNAME_2DNAME) (1, v_FILE_0);
t2 = ICALL(s_lsp_PATHNAME_2DTYPE) (1, v_FILE_0);
t0 = ICALL(s_lsp_CONCATENATE) (MV_CALL(argc,4), LREF(s_lsp_STRING), t1, LREF(k1873), t2);
return(t0);
}

LP p_lsp_DIRECTORY_2DNAMESTRING(argc, v_FILE_0)
      ARGC argc;  LP v_FILE_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 1) wna(argc,1);
t2 = ICALL(s_lsp_PATHNAME_2DDIRECTORY) (1, v_FILE_0);
t1 = ICALL(s_lsp_MAKE_2DPATHNAME) (2, LREF(s_key_DIRECTORY), t2);
t0 = ICALL(s_lsp_NAMESTRING) (MV_CALL(argc,1), t1);
return(t0);
}

LP p_lsp_HOST_2DNAMESTRING(argc, v_FILE_0)
      ARGC argc;  LP v_FILE_0;
{

LP t0; 
if (argc != 1) wna(argc,1);
return(LREF(k1868));
}

