/*
:comment "Compiled at 4:47:49 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: Debug Library"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O2 -fPIC"
:version 0
:end-package-info 0
:sym NIL
:sym SEQ
:sym PROC
:sym TOP-LEVEL-PROC
:sym INNER-PROC
:sym TAG-SEQ
:sym SCOPE-SEQ
:sym PROGN
:sym VALUES-SEQ
:sym NAMED-LOCAL
:sym INLINE-MV-CALL
:sym SPEC-BIND-SEQ
:sym SCOPE-CONTROL-TRANSFER
:sym BETA-SCOPE-CONTROL-TRANSFER
:sym UNWIND-PROTECT
:sym BETA-UNWIND-PROTECT
:sym VAR-REF
:sym BETA-VAR-REF
:sym VAR-DEF
:sym BETA-VAR-DEF
:sym MVALUES
:sym BETA-VALUES
:sym IF
:sym BETA-IF
:sym SWITCH
:sym BETA-SWITCH
:sym FUNCTION-CALL
:sym C-STRUCT-OP
:sym C-STRUCT-DEF
:sym C-STRUCT-REF
:sym PRIMITIVE-CALL
:sym UNNAMED-CALL
:sym FOREIGN-CALL
:sym NAMED-CALL
:sym CONTROL-POINT
:sym TAG-CONTROL-POINT
:sym DYNAMIC-TAG-CONTROL-POINT
:sym STATIC-TAG-CONTROL-POINT
:sym SCOPE-CONTROL-POINT
:sym DYNAMIC-SCOPE-CONTROL-POINT
:sym CATCH-CONTROL-POINT
:sym DYNAMIC-BLOCK-CONTROL-POINT
:sym STATIC-SCOPE-CONTROL-POINT
:sym BETA-SEQ
:sym BETA-FUNCTION-CALL
:sym BETA-CONTROL-POINT
:sf BETA "p_lsp_BETA"
:sym BETA
:sf BETA-LIST "p_lsp_BETA_2DLIST"
:sym BETA-LIST
:sf BETA-BODY "p_lsp_BETA_2DBODY"
:sym MEMQL
:sym BETA-PROGN
:sym BETA-NAMED-LOCAL
:sym VALUES-SEQ-P
:sym SCOPE-SEQ-P
:sym BETA-BODY
:sf BETA-SEQ "p_lsp_BETA_2DSEQ"
:sym LENGTH
:sf BETA-PROGN "p_lsp_BETA_2DPROGN"
:sym COLLECT-BETA-PAIRS
:sym ACONS
:sf BETA-NAMED-LOCAL "p_lsp_BETA_2DNAMED_2DLOCAL"
:sym PROPAGATE-OUT-TYPE
:sym BETA-VALUE?
:sym VARIABLE-VAR-P
:sym :DYNAMIC
:sym NREVERSE
:sf COLLECT-BETA-PAIRS "p_lsp_COLLECT_2DBETA_2DPAIRS"
:sym T
:sf PROPAGATE-OUT-TYPE "p_lsp_PROPAGATE_2DOUT_2DTYPE"
:sym CONSTANT-P
:sym VAR-REF-P
:sf BETA-VALUE? "p_lsp_BETA_2DVALUE_3F"
:sf BETA-VALUES "p_lsp_BETA_2DVALUES"
:sym ASSQ
:sym MERGE-OUT-TYPE
:sf BETA-VAR-REF "p_lsp_BETA_2DVAR_2DREF"
:sf BETA-VAR-DEF "p_lsp_BETA_2DVAR_2DDEF"
:sym UNNAMED-CALL-P
:sf BETA-FUNCTION-CALL "p_lsp_BETA_2DFUNCTION_2DCALL"
:sf BETA-IF "p_lsp_BETA_2DIF"
:sf BETA-SWITCH "p_lsp_BETA_2DSWITCH"
:sf BETA-SCOPE-CONTROL-TRANSFER "p_lsp_BETA_2DSCOPE_2DCONTROL_2DTRANSFER"
:sf BETA-CONTROL-POINT "p_lsp_BETA_2DCONTROL_2DPOINT"
:sf BETA-UNWIND-PROTECT "p_lsp_BETA_2DUNWIND_2DPROTECT"
:pinfo BETA-FUNCTION-CALL (TREE ENV) NIL NIL NIL NIL NIL NIL T
:pinfo BETA-CONTROL-POINT (TREE ENV) NIL NIL NIL NIL NIL NIL T
:pinfo BETA-VALUE? (VAL) NIL NIL NIL NIL NIL NIL T
:pinfo BETA-VAR-REF (TREE ENV) NIL NIL NIL NIL NIL NIL T
:pinfo BETA-VALUES (TREE ENV) NIL NIL NIL NIL NIL NIL T
:pinfo BETA-SCOPE-CONTROL-TRANSFER (TREE ENV) NIL NIL NIL NIL NIL NIL T
:pinfo BETA-IF (TREE ENV) NIL NIL NIL NIL NIL NIL T
:pinfo BETA (TREE ENV) NIL NIL NIL NIL NIL NIL T
:pinfo BETA-LIST (L ENV) NIL NIL NIL NIL NIL NIL T
:pinfo BETA-PROGN (TREE ENV) NIL NIL NIL NIL NIL NIL T
:pinfo COLLECT-BETA-PAIRS (ORIG-VARS ORIG-VALS NEW-VARS NEW-VALS ENV) NIL NIL NIL NIL NIL NIL T
:pinfo PROPAGATE-OUT-TYPE (VAR VAL) NIL NIL NIL NIL NIL NIL T
:pinfo BETA-UNWIND-PROTECT (TREE ENV) NIL NIL NIL NIL NIL NIL T
:pinfo BETA-BODY (BODY ENV) NIL NIL NIL NIL NIL NIL T
:pinfo BETA-NAMED-LOCAL (TREE ENV) NIL NIL NIL NIL NIL NIL T
:pinfo BETA-VAR-DEF (TREE ENV) NIL NIL NIL NIL NIL NIL T
:pinfo BETA-SEQ (TREE ENV) NIL NIL NIL NIL NIL NIL T
:pinfo BETA-SWITCH (TREE ENV) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_lsp_BETA();
extern SYMBOL s_lsp_NIL; 
extern SYMBOL s_lsp_SEQ; 
extern SYMBOL s_lsp_PROC; 
extern SYMBOL s_lsp_TOP_2DLEVEL_2DPROC; 
extern SYMBOL s_lsp_INNER_2DPROC; 
extern SYMBOL s_lsp_TAG_2DSEQ; 
extern SYMBOL s_lsp_SCOPE_2DSEQ; 
extern SYMBOL s_lsp_PROGN; 
extern SYMBOL s_lsp_VALUES_2DSEQ; 
extern SYMBOL s_lsp_NAMED_2DLOCAL; 
extern SYMBOL s_lsp_INLINE_2DMV_2DCALL; 
extern SYMBOL s_lsp_SPEC_2DBIND_2DSEQ; 
extern SYMBOL s_lsp_SCOPE_2DCONTROL_2DTRANSFER; 
extern SYMBOL s_lsp_BETA_2DSCOPE_2DCONTROL_2DTRANSFER; 
extern SYMBOL s_lsp_UNWIND_2DPROTECT; 
extern SYMBOL s_lsp_BETA_2DUNWIND_2DPROTECT; 
extern SYMBOL s_lsp_VAR_2DREF; 
extern SYMBOL s_lsp_BETA_2DVAR_2DREF; 
extern SYMBOL s_lsp_VAR_2DDEF; 
extern SYMBOL s_lsp_BETA_2DVAR_2DDEF; 
extern SYMBOL s_lsp_MVALUES; 
extern SYMBOL s_lsp_BETA_2DVALUES; 
extern SYMBOL s_lsp_IF; 
extern SYMBOL s_lsp_BETA_2DIF; 
extern SYMBOL s_lsp_SWITCH; 
extern SYMBOL s_lsp_BETA_2DSWITCH; 
extern SYMBOL s_lsp_FUNCTION_2DCALL; 
extern SYMBOL s_lsp_C_2DSTRUCT_2DOP; 
extern SYMBOL s_lsp_C_2DSTRUCT_2DDEF; 
extern SYMBOL s_lsp_C_2DSTRUCT_2DREF; 
extern SYMBOL s_lsp_PRIMITIVE_2DCALL; 
extern SYMBOL s_lsp_UNNAMED_2DCALL; 
extern SYMBOL s_lsp_FOREIGN_2DCALL; 
extern SYMBOL s_lsp_NAMED_2DCALL; 
extern SYMBOL s_lsp_CONTROL_2DPOINT; 
extern SYMBOL s_lsp_TAG_2DCONTROL_2DPOINT; 
extern SYMBOL s_lsp_DYNAMIC_2DTAG_2DCONTROL_2DPOINT; 
extern SYMBOL s_lsp_STATIC_2DTAG_2DCONTROL_2DPOINT; 
extern SYMBOL s_lsp_SCOPE_2DCONTROL_2DPOINT; 
extern SYMBOL s_lsp_DYNAMIC_2DSCOPE_2DCONTROL_2DPOINT; 
extern SYMBOL s_lsp_CATCH_2DCONTROL_2DPOINT; 
extern SYMBOL s_lsp_DYNAMIC_2DBLOCK_2DCONTROL_2DPOINT; 
extern SYMBOL s_lsp_STATIC_2DSCOPE_2DCONTROL_2DPOINT; 
extern SYMBOL s_lsp_BETA_2DSEQ; 
extern SYMBOL s_lsp_BETA_2DFUNCTION_2DCALL; 
extern SYMBOL s_lsp_BETA_2DCONTROL_2DPOINT; 
extern LP p_lsp_BETA_2DLIST();
extern SYMBOL s_lsp_BETA; 
extern LP p_lsp_BETA_2DBODY();
extern SYMBOL s_lsp_BETA_2DLIST; 
extern LP p_lsp_BETA_2DSEQ();
MAKE_CONS(k10855,LREF(s_lsp_PROGN),LREF(s_lsp_NIL));
extern SYMBOL s_lsp_MEMQL; 
extern SYMBOL s_lsp_BETA_2DPROGN; 
MAKE_CONS(k10856,LREF(s_lsp_NAMED_2DLOCAL),LREF(s_lsp_NIL));
extern SYMBOL s_lsp_BETA_2DNAMED_2DLOCAL; 
extern SYMBOL s_lsp_VALUES_2DSEQ_2DP; 
extern SYMBOL s_lsp_SCOPE_2DSEQ_2DP; 
extern SYMBOL s_lsp_BETA_2DBODY; 
extern LP p_lsp_BETA_2DPROGN();
extern SYMBOL s_lsp_LENGTH; 
extern LP p_lsp_BETA_2DNAMED_2DLOCAL();
extern SYMBOL s_lsp_COLLECT_2DBETA_2DPAIRS; 
extern SYMBOL s_lsp_ACONS; 
extern LP p_lsp_COLLECT_2DBETA_2DPAIRS();
extern SYMBOL s_lsp_PROPAGATE_2DOUT_2DTYPE; 
extern SYMBOL s_lsp_BETA_2DVALUE_3F; 
extern SYMBOL s_lsp_VARIABLE_2DVAR_2DP; 
extern SYMBOL s_key_DYNAMIC; 
extern SYMBOL s_lsp_NREVERSE; 
extern LP p_lsp_PROPAGATE_2DOUT_2DTYPE();
extern SYMBOL s_lsp_T; 
extern LP p_lsp_BETA_2DVALUE_3F();
extern SYMBOL s_lsp_CONSTANT_2DP; 
extern SYMBOL s_lsp_VAR_2DREF_2DP; 
extern LP p_lsp_BETA_2DVALUES();
extern LP p_lsp_BETA_2DVAR_2DREF();
extern SYMBOL s_lsp_ASSQ; 
extern SYMBOL s_lsp_MERGE_2DOUT_2DTYPE; 
extern LP p_lsp_BETA_2DVAR_2DDEF();
extern LP p_lsp_BETA_2DFUNCTION_2DCALL();
extern SYMBOL s_lsp_UNNAMED_2DCALL_2DP; 
extern LP p_lsp_BETA_2DIF();
extern LP p_lsp_BETA_2DSWITCH();
extern LP p_lsp_BETA_2DSCOPE_2DCONTROL_2DTRANSFER();
extern LP p_lsp_BETA_2DCONTROL_2DPOINT();
MAKE_CONS(k10860,LREF(s_lsp_DYNAMIC_2DTAG_2DCONTROL_2DPOINT),LREF(s_lsp_NIL));
MAKE_CONS(k10863,LREF(s_lsp_DYNAMIC_2DBLOCK_2DCONTROL_2DPOINT),LREF(s_lsp_NIL));
MAKE_CONS(k10862,LREF(s_lsp_CATCH_2DCONTROL_2DPOINT),LREF(k10863));
MAKE_CONS(k10861,LREF(s_lsp_DYNAMIC_2DSCOPE_2DCONTROL_2DPOINT),LREF(k10862));
extern LP p_lsp_BETA_2DUNWIND_2DPROTECT();


extern LP c_cons();
extern LP leq_p();
extern LP num_equal_p();


LP p_lsp_BETA(argc, v_TREE_0, v_ENV_1)
      ARGC argc;  LP v_TREE_0; LP v_ENV_1;
{
LP v_Y_128; LP v_X_127; LP v_X_125; 
LP v_X_123; LP v_S_121; LP v_SYMBOL_119; 
LP v_Y_117; LP v_X_116; LP v_Y_114; 
LP v_X_113; LP v_Y_111; LP v_X_110; 
LP v_Y_108; LP v_X_107; LP v_Y_105; 
LP v_X_104; LP v_Y_102; LP v_X_101; 
LP v_Y_99; LP v_X_98; LP v_Y_96; 
LP v_X_95; LP v_Y_93; LP v_X_92; 
LP v_Y_90; LP v_X_89; LP v_Y_87; 
LP v_X_86; LP v_Y_84; LP v_X_83; 
LP v_Y_81; LP v_X_80; LP v_Y_78; 
LP v_X_77; LP v_Y_75; LP v_X_74; 
LP v_Y_72; LP v_X_71; LP v_Y_69; 
LP v_X_68; LP v_Y_66; LP v_X_65; 
LP v_Y_63; LP v_X_62; LP v_Y_60; 
LP v_X_59; LP v_Y_57; LP v_X_56; 
LP v_Y_54; LP v_X_53; LP v_Y_51; 
LP v_X_50; LP v_Y_48; LP v_X_47; 
LP v_Y_45; LP v_X_44; LP v_Y_42; 
LP v_X_41; LP v_Y_39; LP v_X_38; 
LP v_Y_36; LP v_X_35; LP v_Y_33; 
LP v_X_32; LP v_Y_30; LP v_X_29; 
LP v_Y_27; LP v_X_26; LP v_Y_24; 
LP v_X_23; LP v_Y_21; LP v_X_20; 
LP v_Y_18; LP v_X_17; LP v_Y_15; 
LP v_X_14; LP v_KEY6474_9; LP v_S_7; 
LP v_KEY6473_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; LP t145; LP t146; LP t147; LP t148; LP t149; 
LP t150; LP t151; LP t152; LP t153; LP t154; LP t155; 
LP t156; LP t157; LP t158; LP t159; LP t160; LP t161; 
LP t162; LP t163; LP t164; LP t165; LP t166; LP t167; 
LP t168; LP t169; LP t170; LP t171; LP t172; LP t173; 
LP t174; LP t175; LP t176; LP t177; LP t178; LP t179; 
LP t180; LP t181; LP t182; LP t183; LP t184; LP t185; 
LP t186; LP t187; LP t188; LP t189; LP t190; LP t191; 
LP t192; LP t193; LP t194; LP t195; LP t196; LP t197; 
LP t198; LP t199; LP t200; LP t201; LP t202; LP t203; 
LP t204; LP t205; LP t206; LP t207; LP t208; LP t209; 
LP t210; LP t211; LP t212; LP t213; LP t214; LP t215; 
LP t216; LP t217; LP t218; LP t219; LP t220; LP t221; 
LP t222; LP t223; LP t224; LP t225; LP t226; LP t227; 
LP t228; LP t229; LP t230; LP t231; LP t232; 
if (argc != 2) wna(argc,2);
v_X_125 = v_TREE_0;
v_X_127 = v_TREE_0;
v_Y_128 = LREF(s_lsp_NIL);
if (v_TREE_0 != NIL) {
v_KEY6473_4 = v_TREE_0;
v_X_123 = v_KEY6473_4;
if (FIXNUMP((v_KEY6473_4))) {
goto t_DEFAULT_2DTAG6472_5;
} else {
t3 = INT_TO_FX(((int) TAG((v_KEY6473_4))));
switch ((int) t3) {
case 94:
v_S_7 = v_KEY6473_4;
v_KEY6474_9 = ((LP) DEREF((v_KEY6473_4) + 0 * 4));
v_S_121 = v_KEY6474_9;
if (OTHER_PTRP((v_KEY6474_9)) && (TAG((v_KEY6474_9)) == 3)) {
v_SYMBOL_119 = v_KEY6474_9;
t7 = ((LP) DEREF((v_KEY6474_9) + 5 * 4));
t6 = ((LP) ((int) (t7) % (int) ((LP) 428)));
switch ((int) t6) {
case 200:
v_X_14 = v_KEY6474_9;
v_Y_15 = LREF(s_lsp_SEQ);
if (((v_KEY6474_9) == (LREF(s_lsp_SEQ)))) {
goto t_C6479_11;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 224:
v_X_17 = v_KEY6474_9;
v_Y_18 = LREF(s_lsp_PROC);
if (((v_KEY6474_9) == (LREF(s_lsp_PROC)))) {
goto t_C6479_11;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 158:
v_X_20 = v_KEY6474_9;
v_Y_21 = LREF(s_lsp_TOP_2DLEVEL_2DPROC);
if (((v_KEY6474_9) == (LREF(s_lsp_TOP_2DLEVEL_2DPROC)))) {
goto t_C6479_11;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 250:
v_X_23 = v_KEY6474_9;
v_Y_24 = LREF(s_lsp_INNER_2DPROC);
if (((v_KEY6474_9) == (LREF(s_lsp_INNER_2DPROC)))) {
goto t_C6479_11;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 70:
v_X_26 = v_KEY6474_9;
v_Y_27 = LREF(s_lsp_TAG_2DSEQ);
if (((v_KEY6474_9) == (LREF(s_lsp_TAG_2DSEQ)))) {
goto t_C6479_11;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 106:
v_X_29 = v_KEY6474_9;
v_Y_30 = LREF(s_lsp_SCOPE_2DSEQ);
if (((v_KEY6474_9) == (LREF(s_lsp_SCOPE_2DSEQ)))) {
goto t_C6479_11;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 118:
v_X_32 = v_KEY6474_9;
v_Y_33 = LREF(s_lsp_PROGN);
if (((v_KEY6474_9) == (LREF(s_lsp_PROGN)))) {
goto t_C6479_11;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 96:
v_X_35 = v_KEY6474_9;
v_Y_36 = LREF(s_lsp_VALUES_2DSEQ);
if (((v_KEY6474_9) == (LREF(s_lsp_VALUES_2DSEQ)))) {
goto t_C6479_11;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 416:
v_X_38 = v_KEY6474_9;
v_Y_39 = LREF(s_lsp_NAMED_2DLOCAL);
if (((v_KEY6474_9) == (LREF(s_lsp_NAMED_2DLOCAL)))) {
goto t_C6479_11;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 252:
v_X_41 = v_KEY6474_9;
v_Y_42 = LREF(s_lsp_INLINE_2DMV_2DCALL);
if (((v_KEY6474_9) == (LREF(s_lsp_INLINE_2DMV_2DCALL)))) {
goto t_C6479_11;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 76:
v_X_44 = v_KEY6474_9;
v_Y_45 = LREF(s_lsp_SPEC_2DBIND_2DSEQ);
if (((v_KEY6474_9) == (LREF(s_lsp_SPEC_2DBIND_2DSEQ)))) {
goto t_C6479_11;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 204:
v_X_47 = v_KEY6474_9;
v_Y_48 = LREF(s_lsp_SCOPE_2DCONTROL_2DTRANSFER);
if (((v_KEY6474_9) == (LREF(s_lsp_SCOPE_2DCONTROL_2DTRANSFER)))) {
t5 = ICALL(s_lsp_BETA_2DSCOPE_2DCONTROL_2DTRANSFER) (MV_CALL(argc,2), v_TREE_0, v_ENV_1);
return(t5);
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 326:
v_X_50 = v_KEY6474_9;
v_Y_51 = LREF(s_lsp_UNWIND_2DPROTECT);
if (((v_KEY6474_9) == (LREF(s_lsp_UNWIND_2DPROTECT)))) {
t5 = ICALL(s_lsp_BETA_2DUNWIND_2DPROTECT) (MV_CALL(argc,2), v_TREE_0, v_ENV_1);
return(t5);
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 228:
v_X_53 = v_KEY6474_9;
v_Y_54 = LREF(s_lsp_VAR_2DREF);
if (((v_KEY6474_9) == (LREF(s_lsp_VAR_2DREF)))) {
t5 = ICALL(s_lsp_BETA_2DVAR_2DREF) (MV_CALL(argc,2), v_TREE_0, v_ENV_1);
return(t5);
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 408:
v_X_56 = v_KEY6474_9;
v_Y_57 = LREF(s_lsp_VAR_2DDEF);
if (((v_KEY6474_9) == (LREF(s_lsp_VAR_2DDEF)))) {
t5 = ICALL(s_lsp_BETA_2DVAR_2DDEF) (MV_CALL(argc,2), v_TREE_0, v_ENV_1);
return(t5);
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 28:
v_X_59 = v_KEY6474_9;
v_Y_60 = LREF(s_lsp_MVALUES);
if (((v_KEY6474_9) == (LREF(s_lsp_MVALUES)))) {
t5 = ICALL(s_lsp_BETA_2DVALUES) (MV_CALL(argc,2), v_TREE_0, v_ENV_1);
return(t5);
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 126:
v_X_62 = v_KEY6474_9;
v_Y_63 = LREF(s_lsp_IF);
if (((v_KEY6474_9) == (LREF(s_lsp_IF)))) {
t5 = ICALL(s_lsp_BETA_2DIF) (MV_CALL(argc,2), v_TREE_0, v_ENV_1);
return(t5);
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 308:
v_X_65 = v_KEY6474_9;
v_Y_66 = LREF(s_lsp_SWITCH);
if (((v_KEY6474_9) == (LREF(s_lsp_SWITCH)))) {
t5 = ICALL(s_lsp_BETA_2DSWITCH) (MV_CALL(argc,2), v_TREE_0, v_ENV_1);
return(t5);
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 104:
v_X_68 = v_KEY6474_9;
v_Y_69 = LREF(s_lsp_FUNCTION_2DCALL);
if (((v_KEY6474_9) == (LREF(s_lsp_FUNCTION_2DCALL)))) {
goto t_C6478_12;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 160:
v_X_71 = v_KEY6474_9;
v_Y_72 = LREF(s_lsp_C_2DSTRUCT_2DOP);
if (((v_KEY6474_9) == (LREF(s_lsp_C_2DSTRUCT_2DOP)))) {
goto t_C6478_12;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 402:
v_X_74 = v_KEY6474_9;
v_Y_75 = LREF(s_lsp_C_2DSTRUCT_2DDEF);
if (((v_KEY6474_9) == (LREF(s_lsp_C_2DSTRUCT_2DDEF)))) {
goto t_C6478_12;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 222:
v_X_77 = v_KEY6474_9;
v_Y_78 = LREF(s_lsp_C_2DSTRUCT_2DREF);
if (((v_KEY6474_9) == (LREF(s_lsp_C_2DSTRUCT_2DREF)))) {
goto t_C6478_12;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 80:
v_X_80 = v_KEY6474_9;
v_Y_81 = LREF(s_lsp_PRIMITIVE_2DCALL);
if (((v_KEY6474_9) == (LREF(s_lsp_PRIMITIVE_2DCALL)))) {
goto t_C6478_12;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 310:
v_X_83 = v_KEY6474_9;
v_Y_84 = LREF(s_lsp_UNNAMED_2DCALL);
if (((v_KEY6474_9) == (LREF(s_lsp_UNNAMED_2DCALL)))) {
goto t_C6478_12;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 54:
v_X_86 = v_KEY6474_9;
v_Y_87 = LREF(s_lsp_FOREIGN_2DCALL);
if (((v_KEY6474_9) == (LREF(s_lsp_FOREIGN_2DCALL)))) {
goto t_C6478_12;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 424:
v_X_89 = v_KEY6474_9;
v_Y_90 = LREF(s_lsp_NAMED_2DCALL);
if (((v_KEY6474_9) == (LREF(s_lsp_NAMED_2DCALL)))) {
goto t_C6478_12;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 306:
v_X_92 = v_KEY6474_9;
v_Y_93 = LREF(s_lsp_CONTROL_2DPOINT);
if (((v_KEY6474_9) == (LREF(s_lsp_CONTROL_2DPOINT)))) {
goto t_C6477_13;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 248:
v_X_95 = v_KEY6474_9;
v_Y_96 = LREF(s_lsp_TAG_2DCONTROL_2DPOINT);
if (((v_KEY6474_9) == (LREF(s_lsp_TAG_2DCONTROL_2DPOINT)))) {
goto t_C6477_13;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 112:
v_X_98 = v_KEY6474_9;
v_Y_99 = LREF(s_lsp_DYNAMIC_2DTAG_2DCONTROL_2DPOINT);
if (((v_KEY6474_9) == (LREF(s_lsp_DYNAMIC_2DTAG_2DCONTROL_2DPOINT)))) {
goto t_C6477_13;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 284:
v_X_101 = v_KEY6474_9;
v_Y_102 = LREF(s_lsp_STATIC_2DTAG_2DCONTROL_2DPOINT);
if (((v_KEY6474_9) == (LREF(s_lsp_STATIC_2DTAG_2DCONTROL_2DPOINT)))) {
goto t_C6477_13;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 92:
v_X_104 = v_KEY6474_9;
v_Y_105 = LREF(s_lsp_SCOPE_2DCONTROL_2DPOINT);
if (((v_KEY6474_9) == (LREF(s_lsp_SCOPE_2DCONTROL_2DPOINT)))) {
goto t_C6477_13;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 192:
v_X_107 = v_KEY6474_9;
v_Y_108 = LREF(s_lsp_DYNAMIC_2DSCOPE_2DCONTROL_2DPOINT);
if (((v_KEY6474_9) == (LREF(s_lsp_DYNAMIC_2DSCOPE_2DCONTROL_2DPOINT)))) {
goto t_C6477_13;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 62:
v_X_110 = v_KEY6474_9;
v_Y_111 = LREF(s_lsp_CATCH_2DCONTROL_2DPOINT);
if (((v_KEY6474_9) == (LREF(s_lsp_CATCH_2DCONTROL_2DPOINT)))) {
goto t_C6477_13;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 410:
v_X_113 = v_KEY6474_9;
v_Y_114 = LREF(s_lsp_DYNAMIC_2DBLOCK_2DCONTROL_2DPOINT);
if (((v_KEY6474_9) == (LREF(s_lsp_DYNAMIC_2DBLOCK_2DCONTROL_2DPOINT)))) {
goto t_C6477_13;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
case 388:
v_X_116 = v_KEY6474_9;
v_Y_117 = LREF(s_lsp_STATIC_2DSCOPE_2DCONTROL_2DPOINT);
if (((v_KEY6474_9) == (LREF(s_lsp_STATIC_2DSCOPE_2DCONTROL_2DPOINT)))) {
goto t_C6477_13;
} else {
goto t_DEFAULT_2DTAG6475_10;
}
break;
default:
goto t_DEFAULT_2DTAG6475_10;
break;
}
return(t5);
}
t_DEFAULT_2DTAG6475_10:;
goto t_DEFAULT_2DTAG6472_5;
return(NIL);
t_C6479_11:;
t43 = ICALL(s_lsp_BETA_2DSEQ) (MV_CALL(argc,2), v_TREE_0, v_ENV_1);
return(t43);
return(NIL);
t_C6478_12:;
t44 = ICALL(s_lsp_BETA_2DFUNCTION_2DCALL) (MV_CALL(argc,2), v_TREE_0, v_ENV_1);
return(t44);
return(NIL);
t_C6477_13:;
t45 = ICALL(s_lsp_BETA_2DCONTROL_2DPOINT) (MV_CALL(argc,2), v_TREE_0, v_ENV_1);
return(t45);
return(NIL);
return(NIL);
break;
default:
goto t_DEFAULT_2DTAG6472_5;
break;
}
}
return(t1);
t_DEFAULT_2DTAG6472_5:;
return(v_TREE_0);
return(NIL);
return(NIL);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_BETA_2DLIST(argc, v_L_0, v_ENV_1)
      ARGC argc;  LP v_L_0; LP v_ENV_1;
{
LP v_X_14; LP v_V_12; LP v_X_11; 
LP v_T6481_10; LP v_S6480_9; LP v_X_7; 
LP v_REST_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 

if (argc != 2) wna(argc,2);
v_REST_3 = v_L_0;
t_NEXT_2DLOOP_5:;
if (v_REST_3 == NIL) {
goto t_END_2DLOOP_6;
}
v_X_7 = v_REST_3;
t1 = ((LP) DEREF((v_X_7) + 0 * 4));
v_S6480_9 = ICALL(s_lsp_BETA) (2, t1, v_ENV_1);
v_T6481_10 = v_REST_3;
v_V_12 = v_S6480_9;
((LP) (DEREF((v_T6481_10) + 0 * 4) = (LD) (v_V_12)));
v_X_14 = v_REST_3;
v_REST_3 = ((LP) DEREF((v_X_14) + 1 * 4));
goto t_NEXT_2DLOOP_5;
goto t_END_2DLOOP_6;
t_END_2DLOOP_6:;
return(v_L_0);
return(NIL);
return(NIL);
}

LP p_lsp_BETA_2DBODY(argc, v_BODY_0, v_ENV_1)
      ARGC argc;  LP v_BODY_0; LP v_ENV_1;
{
LP v_Y_10; LP v_X_9; LP v_X_7; 
LP v_X_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 2) wna(argc,2);
v_X_3 = v_BODY_0;
v_X_5 = v_BODY_0;
v_X_7 = (OTHER_PTRP((v_BODY_0)) && (TAG((v_BODY_0)) == 15) ? T : NIL);
v_X_9 = v_X_7;
v_Y_10 = LREF(s_lsp_NIL);
if (v_X_7 != NIL) {
t0 = ICALL(s_lsp_BETA_2DLIST) (MV_CALL(argc,2), v_BODY_0, v_ENV_1);
return(t0);
} else {
t0 = ICALL(s_lsp_BETA) (MV_CALL(argc,2), v_BODY_0, v_ENV_1);
return(t0);
}
}

LP p_lsp_BETA_2DSEQ(argc, v_TREE_0, v_ENV_1)
      ARGC argc;  LP v_TREE_0; LP v_ENV_1;
{
LP v_VALUE_42; LP v_N_41; LP v_S_40; 
LP v_VALUE_38; LP v_S_37; LP v_T6489_36; 
LP v_S6488_35; LP v_I_33; LP v_S_32; 
LP v_S_30; LP v_VALUE_28; LP v_N_27; 
LP v_S_26; LP v_VALUE_24; LP v_S_23; 
LP v_T6487_22; LP v_S6486_21; LP v_I_19; 
LP v_S_18; LP v_S_16; LP v_I_14; 
LP v_S_13; LP v_S_11; LP v_X_9; 
LP v_KEY6485_8; LP v_S_6; LP v_KEY6484_4; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 

if (argc != 2) wna(argc,2);
v_KEY6484_4 = v_TREE_0;
v_X_9 = v_KEY6484_4;
if (FIXNUMP((v_KEY6484_4))) {
goto t_DEFAULT_2DTAG6483_5;
} else {
t3 = INT_TO_FX(((int) TAG((v_KEY6484_4))));
switch ((int) t3) {
case 94:
v_S_6 = v_KEY6484_4;
v_KEY6485_8 = ((LP) DEREF((v_KEY6484_4) + 0 * 4));
t4 = ICALL(s_lsp_MEMQL) (2, v_KEY6485_8, LREF(k10855));
if (t4 != NIL) {
t1 = ICALL(s_lsp_BETA_2DPROGN) (MV_CALL(argc,2), v_TREE_0, v_ENV_1);
return(t1);
} else {
t5 = ICALL(s_lsp_MEMQL) (2, v_KEY6485_8, LREF(k10856));
if (t5 != NIL) {
t1 = ICALL(s_lsp_BETA_2DNAMED_2DLOCAL) (MV_CALL(argc,2), v_TREE_0, v_ENV_1);
return(t1);
} else {
goto t_DEFAULT_2DTAG6483_5;
}
}
break;
default:
goto t_DEFAULT_2DTAG6483_5;
break;
}
}
return(t1);
t_DEFAULT_2DTAG6483_5:;
t6 = ICALL(s_lsp_VALUES_2DSEQ_2DP) (1, v_TREE_0);
if (t6 != NIL) {
v_S_11 = v_TREE_0;
v_S_13 = v_TREE_0;
v_I_14 = (LP) 14;
t7 = ((LP) DEREF((v_TREE_0) + 7 * 4));
ICALL(s_lsp_BETA_2DLIST) (2, t7, v_ENV_1);
}
t8 = ICALL(s_lsp_SCOPE_2DSEQ_2DP) (1, v_TREE_0);
if (t8 != NIL) {
v_S_16 = v_TREE_0;
v_S_18 = v_TREE_0;
v_I_19 = (LP) 14;
t9 = ((LP) DEREF((v_TREE_0) + 7 * 4));
v_S6486_21 = ICALL(s_lsp_BETA) (2, t9, v_ENV_1);
v_T6487_22 = v_TREE_0;
v_S_23 = v_TREE_0;
v_VALUE_24 = v_S6486_21;
v_S_26 = v_TREE_0;
v_N_27 = (LP) 14;
v_VALUE_28 = v_S6486_21;
((LP) (DEREF((v_TREE_0) + 7 * 4) = (LD) (v_S6486_21)));
}
v_S_30 = v_TREE_0;
v_S_32 = v_TREE_0;
v_I_33 = (LP) 12;
t10 = ((LP) DEREF((v_TREE_0) + 6 * 4));
v_S6488_35 = ICALL(s_lsp_BETA_2DBODY) (2, t10, v_ENV_1);
v_T6489_36 = v_TREE_0;
v_S_37 = v_TREE_0;
v_VALUE_38 = v_S6488_35;
v_S_40 = v_TREE_0;
v_N_41 = (LP) 12;
v_VALUE_42 = v_S6488_35;
((LP) (DEREF((v_TREE_0) + 6 * 4) = (LD) (v_S6488_35)));
return(v_TREE_0);
return(NIL);
return(NIL);
}

LP p_lsp_BETA_2DPROGN(argc, v_TREE_0, v_ENV_1)
      ARGC argc;  LP v_TREE_0; LP v_ENV_1;
{
LP v_Y_27; LP v_X_26; LP v_X_24; 
LP v_X_22; LP v_X_20; LP v_VALUE_18; 
LP v_N_17; LP v_S_16; LP v_VALUE_14; 
LP v_S_13; LP v_T6491_12; LP v_S6490_11; 
LP v_X_9; LP v_BETA_2DBODY_8; LP v_I_6; 
LP v_S_5; LP v_S_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; 
if (argc != 2) wna(argc,2);
v_S_3 = v_TREE_0;
v_S_5 = v_TREE_0;
v_I_6 = (LP) 12;
t0 = ((LP) DEREF((v_TREE_0) + 6 * 4));
v_BETA_2DBODY_8 = ICALL(s_lsp_BETA_2DBODY) (2, t0, v_ENV_1);
v_X_20 = v_BETA_2DBODY_8;
v_X_22 = v_BETA_2DBODY_8;
v_X_24 = (OTHER_PTRP((v_BETA_2DBODY_8)) && (TAG((v_BETA_2DBODY_8)) == 15) ? T : NIL);
v_X_26 = v_X_24;
v_Y_27 = LREF(s_lsp_NIL);
if (v_X_24 != NIL) {
t3 = ICALL(s_lsp_LENGTH) (1, v_BETA_2DBODY_8);
t2 = (num_equal_p((t3), ((LP) 2)));
if (t2 != NIL) {
v_X_9 = v_BETA_2DBODY_8;
t1 = ((LP) DEREF((v_BETA_2DBODY_8) + 0 * 4));
return(t1);
} else {
v_S6490_11 = v_BETA_2DBODY_8;
v_T6491_12 = v_TREE_0;
v_S_13 = v_TREE_0;
v_VALUE_14 = v_BETA_2DBODY_8;
v_S_16 = v_TREE_0;
v_N_17 = (LP) 12;
v_VALUE_18 = v_BETA_2DBODY_8;
((LP) (DEREF((v_TREE_0) + 6 * 4) = (LD) (v_BETA_2DBODY_8)));
return(v_TREE_0);
}
} else {
return(v_BETA_2DBODY_8);
}
}

LP p_lsp_BETA_2DNAMED_2DLOCAL(argc, v_TREE_0, v_ENV_1)
      ARGC argc;  LP v_TREE_0; LP v_ENV_1;
{
LP v_VALUE_77; LP v_N_76; LP v_S_75; 
LP v_VALUE_73; LP v_S_72; LP v_T6499_71; 
LP v_S6498_70; LP v_VALUE_68; LP v_N_67; 
LP v_S_66; LP v_VALUE_64; LP v_S_63; 
LP v_T6497_62; LP v_S6496_61; LP v_VALUE_59; 
LP v_N_58; LP v_S_57; LP v_VALUE_55; 
LP v_S_54; LP v_T6495_53; LP v_S6494_52; 
LP v_VALUE_50; LP v_N_49; LP v_S_48; 
LP v_VALUE_46; LP v_S_45; LP v_T6493_44; 
LP v_S6492_43; LP v_I_41; LP v_S_40; 
LP v_S_38; LP v_BETA_2DBODY_37; LP v_X_35; 
LP v_LIST_33; LP v_X_31; LP v_LIST_29; 
LP v_I_27; LP v_S_26; LP v_S_24; 
LP v_NEW_2DENV_23; LP v_NEW_2DVALS_22; LP v_NEW_2DVARS_21; 
LP v_BODY_20; LP v_VALUES_19; LP v_VARS_18; 
LP v_I_16; LP v_S_15; LP v_S_13; 
LP v_I_11; LP v_S_10; LP v_S_8; 
LP v_I_6; LP v_S_5; LP v_S_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 

if (argc != 2) wna(argc,2);
v_S_3 = v_TREE_0;
v_S_5 = v_TREE_0;
v_I_6 = (LP) 16;
v_VARS_18 = ((LP) DEREF((v_TREE_0) + 8 * 4));
v_S_8 = v_TREE_0;
v_S_10 = v_TREE_0;
v_I_11 = (LP) 14;
t0 = ((LP) DEREF((v_TREE_0) + 7 * 4));
v_VALUES_19 = ICALL(s_lsp_BETA_2DLIST) (2, t0, v_ENV_1);
v_S_13 = v_TREE_0;
v_S_15 = v_TREE_0;
v_I_16 = (LP) 12;
v_BODY_20 = ((LP) DEREF((v_TREE_0) + 6 * 4));
{
int real_argc;
BEGIN_MV_CALL(mv_holder10857,0);
t1 = ICALL(s_lsp_COLLECT_2DBETA_2DPAIRS) (MV_CALL(mv_holder10857,5), v_VARS_18, v_VALUES_19, LREF(s_lsp_NIL), LREF(s_lsp_NIL), v_ENV_1);
SET_MV_RETURN_VALUE(mv_holder10857,0,t1);
if SV_RETURN_P(mv_holder10857) SET_MV_RETURN_COUNT(mv_holder10857,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder10857);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_NEW_2DVARS_21 = NIL;
} else {
v_NEW_2DVARS_21 = NEXT_VAR_VALUE(mv_holder10857);
}
if (real_argc < 2) {
v_NEW_2DVALS_22 = NIL;
} else {
v_NEW_2DVALS_22 = NEXT_VAR_VALUE(mv_holder10857);
}
if (real_argc < 3) {
v_NEW_2DENV_23 = NIL;
} else {
v_NEW_2DENV_23 = NEXT_VAR_VALUE(mv_holder10857);
}
END_VAR_VALUES;
END_MV_CALL;
if (v_NEW_2DVARS_21 != NIL) {
v_S6494_52 = v_NEW_2DVARS_21;
v_T6495_53 = v_TREE_0;
v_S_54 = v_TREE_0;
v_VALUE_55 = v_NEW_2DVARS_21;
v_S_57 = v_TREE_0;
v_N_58 = (LP) 16;
v_VALUE_59 = v_NEW_2DVARS_21;
((LP) (DEREF((v_TREE_0) + 8 * 4) = (LD) (v_NEW_2DVARS_21)));
v_S6496_61 = v_NEW_2DVALS_22;
v_T6497_62 = v_TREE_0;
v_S_63 = v_TREE_0;
v_VALUE_64 = v_NEW_2DVALS_22;
v_S_66 = v_TREE_0;
v_N_67 = (LP) 14;
v_VALUE_68 = v_NEW_2DVALS_22;
((LP) (DEREF((v_TREE_0) + 7 * 4) = (LD) (v_NEW_2DVALS_22)));
v_S6498_70 = ICALL(s_lsp_BETA_2DBODY) (2, v_BODY_20, v_NEW_2DENV_23);
v_T6499_71 = v_TREE_0;
v_S_72 = v_TREE_0;
v_VALUE_73 = v_S6498_70;
v_S_75 = v_TREE_0;
v_N_76 = (LP) 12;
v_VALUE_77 = v_S6498_70;
((LP) (DEREF((v_TREE_0) + 6 * 4) = (LD) (v_S6498_70)));
return(v_TREE_0);
} else {
v_S_24 = v_TREE_0;
v_S_26 = v_TREE_0;
v_I_27 = (LP) 16;
v_LIST_29 = ((LP) DEREF((v_TREE_0) + 8 * 4));
v_X_31 = v_LIST_29;
t4 = ((LP) DEREF((v_LIST_29) + 0 * 4));
v_LIST_33 = v_VALUES_19;
v_X_35 = v_VALUES_19;
t5 = ((LP) DEREF((v_VALUES_19) + 0 * 4));
t3 = ICALL(s_lsp_ACONS) (3, t4, t5, v_NEW_2DENV_23);
v_BETA_2DBODY_37 = ICALL(s_lsp_BETA) (2, v_BODY_20, t3);
v_S_38 = v_TREE_0;
v_S_40 = v_TREE_0;
v_I_41 = (LP) 6;
v_S6492_43 = ((LP) DEREF((v_TREE_0) + 3 * 4));
v_T6493_44 = v_BETA_2DBODY_37;
v_S_45 = v_BETA_2DBODY_37;
v_VALUE_46 = v_S6492_43;
v_S_48 = v_BETA_2DBODY_37;
v_N_49 = (LP) 6;
v_VALUE_50 = v_S6492_43;
((LP) (DEREF((v_BETA_2DBODY_37) + 3 * 4) = (LD) (v_S6492_43)));
return(v_TREE_0);
}
}
}

LP p_lsp_COLLECT_2DBETA_2DPAIRS(argc, v_ORIG_2DVARS_0, v_ORIG_2DVALS_1, v_NEW_2DVARS_2, v_NEW_2DVALS_3, v_ENV_4)
      ARGC argc;  LP v_ORIG_2DVARS_0; LP v_ORIG_2DVALS_1; LP v_NEW_2DVARS_2; LP v_NEW_2DVALS_3; LP v_ENV_4;
{
LP v_I_47; LP v_S_46; LP v_S_44; 
LP v_I_42; LP v_S_41; LP v_S_39; 
LP v_Y_37; LP v_X_36; LP v_I_34; 
LP v_S_33; LP v_S_31; LP v_Y_29; 
LP v_X_28; LP v_Y_26; LP v_X_25; 
LP v_X_23; LP v_X_21; LP v_X_19; 
LP v_X_17; LP v_Y_15; LP v_X_14; 
LP v_X_12; LP v_VAL_11; LP v_VAR_10; 
LP v_X_8; LP v_X_6; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; 
if (argc != 5) wna(argc,5);
START10859:
if (v_ORIG_2DVARS_0 != NIL) {
v_X_6 = v_ORIG_2DVARS_0;
v_VAR_10 = ((LP) DEREF((v_ORIG_2DVARS_0) + 0 * 4));
v_X_8 = v_ORIG_2DVALS_1;
v_VAL_11 = ((LP) DEREF((v_ORIG_2DVALS_1) + 0 * 4));
v_X_12 = v_VAL_11;
v_X_14 = v_VAL_11;
v_Y_15 = LREF(s_lsp_NIL);
if (v_VAL_11 != NIL) {
ICALL(s_lsp_PROPAGATE_2DOUT_2DTYPE) (2, v_VAR_10, v_VAL_11);
}
t2 = ICALL(s_lsp_BETA_2DVALUE_3F) (1, v_VAL_11);
if (t2 != NIL) {
t3 = ICALL(s_lsp_VARIABLE_2DVAR_2DP) (1, v_VAR_10);
if (t3 != NIL) {
v_S_44 = v_VAR_10;
v_S_46 = v_VAR_10;
v_I_47 = (LP) 12;
t5 = ((LP) DEREF((v_VAR_10) + 6 * 4));
t4 = (leq_p((t5), ((LP) 2)));
if (t4 != NIL) {
v_S_39 = v_VAR_10;
v_S_41 = v_VAR_10;
v_I_42 = (LP) 14;
t7 = ((LP) DEREF((v_VAR_10) + 7 * 4));
t6 = (num_equal_p((t7), ((LP) 0)));
if (t6 != NIL) {
v_S_31 = v_VAR_10;
v_S_33 = v_VAR_10;
v_I_34 = (LP) 16;
v_X_36 = ((LP) DEREF((v_VAR_10) + 8 * 4));
t1 = (((v_X_36) == (LREF(s_key_DYNAMIC))) ? T : NIL);
} else {
t1 = LREF(s_lsp_NIL);
}
} else {
t1 = LREF(s_lsp_NIL);
}
} else {
t1 = LREF(s_lsp_NIL);
}
} else {
t1 = LREF(s_lsp_NIL);
}
if (t1 != NIL) {
v_X_17 = v_ORIG_2DVARS_0;
t8 = ((LP) DEREF((v_ORIG_2DVARS_0) + 1 * 4));
v_X_19 = v_ORIG_2DVALS_1;
t9 = ((LP) DEREF((v_ORIG_2DVALS_1) + 1 * 4));
t10 = ICALL(s_lsp_ACONS) (3, v_VAR_10, v_VAL_11, v_ENV_4);
v_ORIG_2DVARS_0 = t8; v_ORIG_2DVALS_1 = t9; v_ENV_4 = t10; 
goto START10859;
} else {
v_X_21 = v_ORIG_2DVARS_0;
t11 = ((LP) DEREF((v_ORIG_2DVARS_0) + 1 * 4));
v_X_23 = v_ORIG_2DVALS_1;
t12 = ((LP) DEREF((v_ORIG_2DVALS_1) + 1 * 4));
v_X_25 = v_VAR_10;
v_Y_26 = v_NEW_2DVARS_2;
t13 = (c_cons((v_VAR_10), (v_NEW_2DVARS_2)));
v_X_28 = v_VAL_11;
v_Y_29 = v_NEW_2DVALS_3;
t14 = (c_cons((v_VAL_11), (v_NEW_2DVALS_3)));
v_ORIG_2DVARS_0 = t11; v_ORIG_2DVALS_1 = t12; v_NEW_2DVARS_2 = t13; v_NEW_2DVALS_3 = t14; 
goto START10859;
}
} else {
t15 = ICALL(s_lsp_NREVERSE) (1, v_NEW_2DVARS_2);
t16 = ICALL(s_lsp_NREVERSE) (1, v_NEW_2DVALS_3);
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,3);
SET_MV_RETURN_VALUE(argc,1,t16);
SET_MV_RETURN_VALUE(argc,2,v_ENV_4);
}
return(t15);
}
}

LP p_lsp_PROPAGATE_2DOUT_2DTYPE(argc, v_VAR_0, v_VAL_1)
      ARGC argc;  LP v_VAR_0; LP v_VAL_1;
{
LP v_I_30; LP v_S_29; LP v_S_27; 
LP v_Y_25; LP v_X_24; LP v_VALUE_22; 
LP v_N_21; LP v_S_20; LP v_VALUE_18; 
LP v_S_17; LP v_T6501_16; LP v_S6500_15; 
LP v_VAL_2DTYPE_14; LP v_VAR_2DTYPE_13; LP v_I_11; 
LP v_S_10; LP v_S_8; LP v_I_6; 
LP v_S_5; LP v_S_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; 
if (argc != 2) wna(argc,2);
v_S_3 = v_VAR_0;
v_S_5 = v_VAR_0;
v_I_6 = (LP) 8;
v_VAR_2DTYPE_13 = ((LP) DEREF((v_VAR_0) + 4 * 4));
v_S_8 = v_VAL_1;
v_S_10 = v_VAL_1;
v_I_11 = (LP) 6;
v_VAL_2DTYPE_14 = ((LP) DEREF((v_VAL_1) + 3 * 4));
v_S_27 = v_VAR_0;
v_S_29 = v_VAR_0;
v_I_30 = (LP) 14;
t3 = ((LP) DEREF((v_VAR_0) + 7 * 4));
t2 = (num_equal_p((t3), ((LP) 0)));
if (t2 != NIL) {
v_X_24 = v_VAR_2DTYPE_13;
v_Y_25 = LREF(s_lsp_T);
t1 = (((v_VAR_2DTYPE_13) == (LREF(s_lsp_T))) ? T : NIL);
} else {
t1 = LREF(s_lsp_NIL);
}
if (t1 != NIL) {
v_S6500_15 = v_VAL_2DTYPE_14;
v_T6501_16 = v_VAR_0;
v_S_17 = v_VAR_0;
v_VALUE_18 = v_VAL_2DTYPE_14;
v_S_20 = v_VAR_0;
v_N_21 = (LP) 8;
v_VALUE_22 = v_VAL_2DTYPE_14;
t0 = ((LP) (DEREF((v_VAR_0) + 4 * 4) = (LD) (v_VAL_2DTYPE_14)));
return(t0);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_BETA_2DVALUE_3F(argc, v_VAL_0)
      ARGC argc;  LP v_VAL_0;
{
LP v_I_11; LP v_S_10; LP v_S_8; 
LP v_I_6; LP v_S_5; LP v_S_3; 
LP v_G6502_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 1) wna(argc,1);
v_G6502_2 = ICALL(s_lsp_CONSTANT_2DP) (1, v_VAL_0);
if (v_G6502_2 != NIL) {
return(v_G6502_2);
} else {
t1 = ICALL(s_lsp_VAR_2DREF_2DP) (1, v_VAL_0);
if (t1 != NIL) {
v_S_3 = v_VAL_0;
v_S_5 = v_VAL_0;
v_I_6 = (LP) 12;
v_S_8 = ((LP) DEREF((v_VAL_0) + 6 * 4));
v_S_10 = v_S_8;
v_I_11 = (LP) 14;
t2 = ((LP) DEREF((v_S_8) + 7 * 4));
t0 = (num_equal_p((t2), ((LP) 0)));
return(t0);
} else {
return(LREF(s_lsp_NIL));
}
}
}

LP p_lsp_BETA_2DVALUES(argc, v_TREE_0, v_ENV_1)
      ARGC argc;  LP v_TREE_0; LP v_ENV_1;
{
LP v_I_6; LP v_S_5; LP v_S_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
v_S_3 = v_TREE_0;
v_S_5 = v_TREE_0;
v_I_6 = (LP) 12;
t0 = ((LP) DEREF((v_TREE_0) + 6 * 4));
ICALL(s_lsp_BETA_2DLIST) (2, t0, v_ENV_1);
return(v_TREE_0);
}

LP p_lsp_BETA_2DVAR_2DREF(argc, v_TREE_0, v_ENV_1)
      ARGC argc;  LP v_TREE_0; LP v_ENV_1;
{
LP v_I_48; LP v_S_47; LP v_S_45; 
LP v_VALUE_43; LP v_N_42; LP v_S_41; 
LP v_VALUE_39; LP v_S_38; LP v_T6506_37; 
LP v_S6505_36; LP v_I_34; LP v_S_33; 
LP v_S_31; LP v_NEW_30; LP v_X_28; 
LP v_ENTRY_27; LP v_I_25; LP v_S_24; 
LP v_S_22; LP v_VALUE_20; LP v_N_19; 
LP v_S_18; LP v_VALUE_16; LP v_S_15; 
LP v_T6504_14; LP v_S6503_13; LP v_I_11; 
LP v_S_10; LP v_S_8; LP v_I_6; 
LP v_S_5; LP v_S_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; 
if (argc != 2) wna(argc,2);
v_S_3 = v_TREE_0;
v_S_5 = v_TREE_0;
v_I_6 = (LP) 12;
v_S_8 = ((LP) DEREF((v_TREE_0) + 6 * 4));
v_S_10 = v_S_8;
v_I_11 = (LP) 8;
v_S6503_13 = ((LP) DEREF((v_S_8) + 4 * 4));
v_T6504_14 = v_TREE_0;
v_S_15 = v_TREE_0;
v_VALUE_16 = v_S6503_13;
v_S_18 = v_TREE_0;
v_N_19 = (LP) 6;
v_VALUE_20 = v_S6503_13;
((LP) (DEREF((v_TREE_0) + 3 * 4) = (LD) (v_S6503_13)));
v_S_22 = v_TREE_0;
v_S_24 = v_TREE_0;
v_I_25 = (LP) 12;
t0 = ((LP) DEREF((v_TREE_0) + 6 * 4));
v_ENTRY_27 = ICALL(s_lsp_ASSQ) (2, t0, v_ENV_1);
if (v_ENTRY_27 != NIL) {
v_X_28 = v_ENTRY_27;
v_NEW_30 = ((LP) DEREF((v_ENTRY_27) + 1 * 4));
v_S_31 = v_TREE_0;
v_S_33 = v_TREE_0;
v_I_34 = (LP) 2;
v_S6505_36 = ((LP) DEREF((v_TREE_0) + 1 * 4));
v_T6506_37 = v_NEW_30;
v_S_38 = v_NEW_30;
v_VALUE_39 = v_S6505_36;
v_S_41 = v_NEW_30;
v_N_42 = (LP) 2;
v_VALUE_43 = v_S6505_36;
((LP) (DEREF((v_NEW_30) + 1 * 4) = (LD) (v_S6505_36)));
v_S_45 = v_TREE_0;
v_S_47 = v_TREE_0;
v_I_48 = (LP) 6;
t2 = ((LP) DEREF((v_TREE_0) + 3 * 4));
ICALL(s_lsp_MERGE_2DOUT_2DTYPE) (2, v_NEW_30, t2);
return(v_NEW_30);
} else {
return(v_TREE_0);
}
}

LP p_lsp_BETA_2DVAR_2DDEF(argc, v_TREE_0, v_ENV_1)
      ARGC argc;  LP v_TREE_0; LP v_ENV_1;
{
LP v_VALUE_15; LP v_N_14; LP v_S_13; 
LP v_VALUE_11; LP v_S_10; LP v_T6508_9; 
LP v_S6507_8; LP v_I_6; LP v_S_5; 
LP v_S_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
if (argc != 2) wna(argc,2);
v_S_3 = v_TREE_0;
v_S_5 = v_TREE_0;
v_I_6 = (LP) 16;
t0 = ((LP) DEREF((v_TREE_0) + 8 * 4));
v_S6507_8 = ICALL(s_lsp_BETA) (2, t0, v_ENV_1);
v_T6508_9 = v_TREE_0;
v_S_10 = v_TREE_0;
v_VALUE_11 = v_S6507_8;
v_S_13 = v_TREE_0;
v_N_14 = (LP) 16;
v_VALUE_15 = v_S6507_8;
((LP) (DEREF((v_TREE_0) + 8 * 4) = (LD) (v_S6507_8)));
return(v_TREE_0);
}

LP p_lsp_BETA_2DFUNCTION_2DCALL(argc, v_TREE_0, v_ENV_1)
      ARGC argc;  LP v_TREE_0; LP v_ENV_1;
{
LP v_I_20; LP v_S_19; LP v_S_17; 
LP v_VALUE_15; LP v_N_14; LP v_S_13; 
LP v_VALUE_11; LP v_S_10; LP v_T6510_9; 
LP v_S6509_8; LP v_I_6; LP v_S_5; 
LP v_S_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_UNNAMED_2DCALL_2DP) (1, v_TREE_0);
if (t0 != NIL) {
v_S_3 = v_TREE_0;
v_S_5 = v_TREE_0;
v_I_6 = (LP) 20;
t1 = ((LP) DEREF((v_TREE_0) + 10 * 4));
v_S6509_8 = ICALL(s_lsp_BETA) (2, t1, v_ENV_1);
v_T6510_9 = v_TREE_0;
v_S_10 = v_TREE_0;
v_VALUE_11 = v_S6509_8;
v_S_13 = v_TREE_0;
v_N_14 = (LP) 20;
v_VALUE_15 = v_S6509_8;
((LP) (DEREF((v_TREE_0) + 10 * 4) = (LD) (v_S6509_8)));
}
v_S_17 = v_TREE_0;
v_S_19 = v_TREE_0;
v_I_20 = (LP) 12;
t2 = ((LP) DEREF((v_TREE_0) + 6 * 4));
ICALL(s_lsp_BETA_2DLIST) (2, t2, v_ENV_1);
return(v_TREE_0);
}

LP p_lsp_BETA_2DIF(argc, v_TREE_0, v_ENV_1)
      ARGC argc;  LP v_TREE_0; LP v_ENV_1;
{
LP v_VALUE_43; LP v_N_42; LP v_S_41; 
LP v_VALUE_39; LP v_S_38; LP v_T6516_37; 
LP v_S6515_36; LP v_I_34; LP v_S_33; 
LP v_S_31; LP v_VALUE_29; LP v_N_28; 
LP v_S_27; LP v_VALUE_25; LP v_S_24; 
LP v_T6514_23; LP v_S6513_22; LP v_I_20; 
LP v_S_19; LP v_S_17; LP v_VALUE_15; 
LP v_N_14; LP v_S_13; LP v_VALUE_11; 
LP v_S_10; LP v_T6512_9; LP v_S6511_8; 
LP v_I_6; LP v_S_5; LP v_S_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; 
if (argc != 2) wna(argc,2);
v_S_3 = v_TREE_0;
v_S_5 = v_TREE_0;
v_I_6 = (LP) 14;
t0 = ((LP) DEREF((v_TREE_0) + 7 * 4));
v_S6511_8 = ICALL(s_lsp_BETA) (2, t0, v_ENV_1);
v_T6512_9 = v_TREE_0;
v_S_10 = v_TREE_0;
v_VALUE_11 = v_S6511_8;
v_S_13 = v_TREE_0;
v_N_14 = (LP) 14;
v_VALUE_15 = v_S6511_8;
((LP) (DEREF((v_TREE_0) + 7 * 4) = (LD) (v_S6511_8)));
v_S_17 = v_TREE_0;
v_S_19 = v_TREE_0;
v_I_20 = (LP) 16;
t1 = ((LP) DEREF((v_TREE_0) + 8 * 4));
v_S6513_22 = ICALL(s_lsp_BETA) (2, t1, v_ENV_1);
v_T6514_23 = v_TREE_0;
v_S_24 = v_TREE_0;
v_VALUE_25 = v_S6513_22;
v_S_27 = v_TREE_0;
v_N_28 = (LP) 16;
v_VALUE_29 = v_S6513_22;
((LP) (DEREF((v_TREE_0) + 8 * 4) = (LD) (v_S6513_22)));
v_S_31 = v_TREE_0;
v_S_33 = v_TREE_0;
v_I_34 = (LP) 18;
t2 = ((LP) DEREF((v_TREE_0) + 9 * 4));
v_S6515_36 = ICALL(s_lsp_BETA) (2, t2, v_ENV_1);
v_T6516_37 = v_TREE_0;
v_S_38 = v_TREE_0;
v_VALUE_39 = v_S6515_36;
v_S_41 = v_TREE_0;
v_N_42 = (LP) 18;
v_VALUE_43 = v_S6515_36;
((LP) (DEREF((v_TREE_0) + 9 * 4) = (LD) (v_S6515_36)));
return(v_TREE_0);
}

LP p_lsp_BETA_2DSWITCH(argc, v_TREE_0, v_ENV_1)
      ARGC argc;  LP v_TREE_0; LP v_ENV_1;
{
LP v_VALUE_43; LP v_N_42; LP v_S_41; 
LP v_VALUE_39; LP v_S_38; LP v_T6522_37; 
LP v_S6521_36; LP v_I_34; LP v_S_33; 
LP v_S_31; LP v_VALUE_29; LP v_N_28; 
LP v_S_27; LP v_VALUE_25; LP v_S_24; 
LP v_T6520_23; LP v_S6519_22; LP v_I_20; 
LP v_S_19; LP v_S_17; LP v_VALUE_15; 
LP v_N_14; LP v_S_13; LP v_VALUE_11; 
LP v_S_10; LP v_T6518_9; LP v_S6517_8; 
LP v_I_6; LP v_S_5; LP v_S_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; 
if (argc != 2) wna(argc,2);
v_S_3 = v_TREE_0;
v_S_5 = v_TREE_0;
v_I_6 = (LP) 14;
t0 = ((LP) DEREF((v_TREE_0) + 7 * 4));
v_S6517_8 = ICALL(s_lsp_BETA) (2, t0, v_ENV_1);
v_T6518_9 = v_TREE_0;
v_S_10 = v_TREE_0;
v_VALUE_11 = v_S6517_8;
v_S_13 = v_TREE_0;
v_N_14 = (LP) 14;
v_VALUE_15 = v_S6517_8;
((LP) (DEREF((v_TREE_0) + 7 * 4) = (LD) (v_S6517_8)));
v_S_17 = v_TREE_0;
v_S_19 = v_TREE_0;
v_I_20 = (LP) 18;
t1 = ((LP) DEREF((v_TREE_0) + 9 * 4));
v_S6519_22 = ICALL(s_lsp_BETA_2DLIST) (2, t1, v_ENV_1);
v_T6520_23 = v_TREE_0;
v_S_24 = v_TREE_0;
v_VALUE_25 = v_S6519_22;
v_S_27 = v_TREE_0;
v_N_28 = (LP) 18;
v_VALUE_29 = v_S6519_22;
((LP) (DEREF((v_TREE_0) + 9 * 4) = (LD) (v_S6519_22)));
v_S_31 = v_TREE_0;
v_S_33 = v_TREE_0;
v_I_34 = (LP) 20;
t2 = ((LP) DEREF((v_TREE_0) + 10 * 4));
v_S6521_36 = ICALL(s_lsp_BETA) (2, t2, v_ENV_1);
v_T6522_37 = v_TREE_0;
v_S_38 = v_TREE_0;
v_VALUE_39 = v_S6521_36;
v_S_41 = v_TREE_0;
v_N_42 = (LP) 20;
v_VALUE_43 = v_S6521_36;
((LP) (DEREF((v_TREE_0) + 10 * 4) = (LD) (v_S6521_36)));
return(v_TREE_0);
}

LP p_lsp_BETA_2DSCOPE_2DCONTROL_2DTRANSFER(argc, v_TREE_0, v_ENV_1)
      ARGC argc;  LP v_TREE_0; LP v_ENV_1;
{
LP v_VALUE_29; LP v_N_28; LP v_S_27; 
LP v_VALUE_25; LP v_S_24; LP v_T6526_23; 
LP v_S6525_22; LP v_I_20; LP v_S_19; 
LP v_S_17; LP v_VALUE_15; LP v_N_14; 
LP v_S_13; LP v_VALUE_11; LP v_S_10; 
LP v_T6524_9; LP v_S6523_8; LP v_I_6; 
LP v_S_5; LP v_S_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; 
if (argc != 2) wna(argc,2);
v_S_3 = v_TREE_0;
v_S_5 = v_TREE_0;
v_I_6 = (LP) 16;
t0 = ((LP) DEREF((v_TREE_0) + 8 * 4));
v_S6523_8 = ICALL(s_lsp_BETA) (2, t0, v_ENV_1);
v_T6524_9 = v_TREE_0;
v_S_10 = v_TREE_0;
v_VALUE_11 = v_S6523_8;
v_S_13 = v_TREE_0;
v_N_14 = (LP) 16;
v_VALUE_15 = v_S6523_8;
((LP) (DEREF((v_TREE_0) + 8 * 4) = (LD) (v_S6523_8)));
v_S_17 = v_TREE_0;
v_S_19 = v_TREE_0;
v_I_20 = (LP) 12;
t1 = ((LP) DEREF((v_TREE_0) + 6 * 4));
v_S6525_22 = ICALL(s_lsp_BETA) (2, t1, v_ENV_1);
v_T6526_23 = v_TREE_0;
v_S_24 = v_TREE_0;
v_VALUE_25 = v_S6525_22;
v_S_27 = v_TREE_0;
v_N_28 = (LP) 12;
v_VALUE_29 = v_S6525_22;
((LP) (DEREF((v_TREE_0) + 6 * 4) = (LD) (v_S6525_22)));
return(v_TREE_0);
}

LP p_lsp_BETA_2DCONTROL_2DPOINT(argc, v_TREE_0, v_ENV_1)
      ARGC argc;  LP v_TREE_0; LP v_ENV_1;
{
LP v_X_37; LP v_VALUE_35; LP v_N_34; 
LP v_S_33; LP v_VALUE_31; LP v_S_30; 
LP v_T6534_29; LP v_S6533_28; LP v_I_26; 
LP v_S_25; LP v_S_23; LP v_VALUE_21; 
LP v_N_20; LP v_S_19; LP v_VALUE_17; 
LP v_S_16; LP v_T6532_15; LP v_S6531_14; 
LP v_I_12; LP v_S_11; LP v_S_9; 
LP v_KEY6530_8; LP v_S_6; LP v_KEY6529_4; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 

if (argc != 2) wna(argc,2);
v_KEY6529_4 = v_TREE_0;
v_X_37 = v_KEY6529_4;
if (FIXNUMP((v_KEY6529_4))) {
goto t_DEFAULT_2DTAG6528_5;
} else {
t2 = INT_TO_FX(((int) TAG((v_KEY6529_4))));
switch ((int) t2) {
case 94:
v_S_6 = v_KEY6529_4;
v_KEY6530_8 = ((LP) DEREF((v_KEY6529_4) + 0 * 4));
t3 = ICALL(s_lsp_MEMQL) (2, v_KEY6530_8, LREF(k10860));
if (t3 != NIL) {
v_S_9 = v_TREE_0;
v_S_11 = v_TREE_0;
v_I_12 = (LP) 22;
t4 = ((LP) DEREF((v_TREE_0) + 11 * 4));
v_S6531_14 = ICALL(s_lsp_BETA) (2, t4, v_ENV_1);
v_T6532_15 = v_TREE_0;
v_S_16 = v_TREE_0;
v_VALUE_17 = v_S6531_14;
v_S_19 = v_TREE_0;
v_N_20 = (LP) 22;
v_VALUE_21 = v_S6531_14;
t0 = ((LP) (DEREF((v_TREE_0) + 11 * 4) = (LD) (v_S6531_14)));
} else {
t5 = ICALL(s_lsp_MEMQL) (2, v_KEY6530_8, LREF(k10861));
if (t5 != NIL) {
v_S_23 = v_TREE_0;
v_S_25 = v_TREE_0;
v_I_26 = (LP) 22;
t6 = ((LP) DEREF((v_TREE_0) + 11 * 4));
v_S6533_28 = ICALL(s_lsp_BETA) (2, t6, v_ENV_1);
v_T6534_29 = v_TREE_0;
v_S_30 = v_TREE_0;
v_VALUE_31 = v_S6533_28;
v_S_33 = v_TREE_0;
v_N_34 = (LP) 22;
v_VALUE_35 = v_S6533_28;
t0 = ((LP) (DEREF((v_TREE_0) + 11 * 4) = (LD) (v_S6533_28)));
} else {
goto t_DEFAULT_2DTAG6528_5;
}
}
break;
default:
goto t_DEFAULT_2DTAG6528_5;
break;
}
}
goto b_TYPECASE6527_3;
t_DEFAULT_2DTAG6528_5:;
goto b_TYPECASE6527_3;
b_TYPECASE6527_3:;
return(v_TREE_0);
}

LP p_lsp_BETA_2DUNWIND_2DPROTECT(argc, v_TREE_0, v_ENV_1)
      ARGC argc;  LP v_TREE_0; LP v_ENV_1;
{
LP v_VALUE_29; LP v_N_28; LP v_S_27; 
LP v_VALUE_25; LP v_S_24; LP v_T6538_23; 
LP v_S6537_22; LP v_I_20; LP v_S_19; 
LP v_S_17; LP v_VALUE_15; LP v_N_14; 
LP v_S_13; LP v_VALUE_11; LP v_S_10; 
LP v_T6536_9; LP v_S6535_8; LP v_I_6; 
LP v_S_5; LP v_S_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; 
if (argc != 2) wna(argc,2);
v_S_3 = v_TREE_0;
v_S_5 = v_TREE_0;
v_I_6 = (LP) 14;
t0 = ((LP) DEREF((v_TREE_0) + 7 * 4));
v_S6535_8 = ICALL(s_lsp_BETA) (2, t0, v_ENV_1);
v_T6536_9 = v_TREE_0;
v_S_10 = v_TREE_0;
v_VALUE_11 = v_S6535_8;
v_S_13 = v_TREE_0;
v_N_14 = (LP) 14;
v_VALUE_15 = v_S6535_8;
((LP) (DEREF((v_TREE_0) + 7 * 4) = (LD) (v_S6535_8)));
v_S_17 = v_TREE_0;
v_S_19 = v_TREE_0;
v_I_20 = (LP) 12;
t1 = ((LP) DEREF((v_TREE_0) + 6 * 4));
v_S6537_22 = ICALL(s_lsp_BETA) (2, t1, v_ENV_1);
v_T6538_23 = v_TREE_0;
v_S_24 = v_TREE_0;
v_VALUE_25 = v_S6537_22;
v_S_27 = v_TREE_0;
v_N_28 = (LP) 12;
v_VALUE_29 = v_S6537_22;
((LP) (DEREF((v_TREE_0) + 6 * 4) = (LD) (v_S6537_22)));
return(v_TREE_0);
}

