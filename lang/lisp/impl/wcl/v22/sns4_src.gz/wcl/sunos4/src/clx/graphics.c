/*
:comment "Compiled at 5:38:26 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: Debug Library"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O2 -fPIC"
:version 0
:package (IN-PACKAGE :XLIB) 
:end-package-info 0
:sym CLOSED-DISPLAY
:sym :DISPLAY
:sym ERROR
:sym FORCE-GCONTEXT-CHANGES-INTERNAL
:sym BUFFER-FLUSH
:sym *INHIBIT-APPENDING*
:sym NIL
:sym ASH
:sym LISP::LDB-1
:sym DISPLAY-INVOKE-AFTER-FUNCTION
:sf DRAW-POINT "p_xlib_DRAW_2DPOINT"
:sym LENGTH
:sym CEILING
:sym WRITE-SEQUENCE-INT16
:sym VALUES-LIST
:sf DRAW-POINTS "p_xlib_DRAW_2DPOINTS"
:sf DRAW-LINE "p_xlib_DRAW_2DLINE"
:sym :RELATIVE-P
:sym :FILL-P
:sym :SHAPE
:sym :COMPLEX
:sym FILL-POLYGON
:sf DRAW-LINES "p_xlib_DRAW_2DLINES"
:sym :NON-CONVEX
:sym :CONVEX
:sym :TEST
:sym EQ
:sym POSITION
:sf FILL-POLYGON "p_xlib_FILL_2DPOLYGON"
:sf DRAW-SEGMENTS "p_xlib_DRAW_2DSEGMENTS"
:sf DRAW-RECTANGLE "p_xlib_DRAW_2DRECTANGLE"
:sf DRAW-RECTANGLES "p_xlib_DRAW_2DRECTANGLES"
:sym RADIANS->INT16
:sf DRAW-ARC "p_xlib_DRAW_2DARC"
:sf DRAW-ARCS-LIST "p_xlib_DRAW_2DARCS_2DLIST"
:sf DRAW-ARCS-VECTOR "p_xlib_DRAW_2DARCS_2DVECTOR"
:sym DRAW-ARCS-LIST
:sym DRAW-ARCS-VECTOR
:sym LIST
:sym VECTOR
:sf DRAW-ARCS "p_xlib_DRAW_2DARCS"
:sym :START
:sym :DEPTH
:sym MISSING-PARAMETER
:sym :PARAMETER
:sym DEPTH
:sym *REQUIRED-ARG-DUMMY*
:sym :X
:sym X
:sym :Y
:sym Y
:sym :WIDTH
:sym WIDTH
:sym :HEIGHT
:sym HEIGHT
:sym :LEFT-PAD
:sym :FORMAT
:sym FORMAT
:sym :BITMAP
:sym :XY-PIXMAP
:sym :Z-PIXMAP
:sym WRITE-SEQUENCE-CARD8
:sf PUT-RAW-IMAGE "p_xlib_PUT_2DRAW_2DIMAGE"
:sym :DATA
:sym :PLANE-MASK
:sym :RESULT-TYPE
:sym CARD8
:sym START-PENDING-COMMAND
:sym BUFFER-FORCE-OUTPUT
:sym READ-REPLY
:sym READ-SEQUENCE-CARD8
:sym VISUAL-INFO
:sym DEALLOCATE-REPLY-BUFFER
:sym STOP-PENDING-COMMAND
:sf GET-RAW-IMAGE "p_xlib_GET_2DRAW_2DIMAGE"
:sym :VAR
:sym LISP::DEFINE-VARIABLE
:sf GRAPHICS_INIT312 "p_xlib_GRAPHICS_5FINIT312"
:init GRAPHICS_INIT312
:pinfo XLIB:DRAW-LINES (XLIB:DRAWABLE XLIB:GCONTEXT XLIB::POINTS &KEY XLIB::RELATIVE-P XLIB::FILL-P (XLIB::SHAPE :COMPLEX)) NIL NIL NIL NIL NIL NIL T
:pinfo XLIB:DRAW-POINT (XLIB:DRAWABLE XLIB:GCONTEXT XLIB::X XLIB::Y) NIL NIL NIL NIL NIL NIL T
:pinfo XLIB::DRAW-ARCS-LIST (XLIB:DRAWABLE XLIB:GCONTEXT XLIB::ARCS &OPTIONAL XLIB::FILL-P) NIL NIL NIL NIL NIL NIL T
:pinfo XLIB::FILL-POLYGON (XLIB:DRAWABLE XLIB:GCONTEXT XLIB::POINTS XLIB::RELATIVE-P XLIB::SHAPE) NIL NIL NIL NIL NIL NIL T
:pinfo XLIB:DRAW-RECTANGLES (XLIB:DRAWABLE XLIB:GCONTEXT XLIB::RECTANGLES &OPTIONAL XLIB::FILL-P) NIL NIL NIL NIL NIL NIL T
:pinfo XLIB::GRAPHICS_INIT312 NIL NIL NIL NIL NIL NIL NIL T
:pinfo XLIB:PUT-RAW-IMAGE (XLIB:DRAWABLE XLIB:GCONTEXT XLIB::DATA &KEY (XLIB::START 0) (XLIB::DEPTH (XLIB::REQUIRED-ARG XLIB::DEPTH)) (XLIB::X (XLIB::REQUIRED-ARG XLIB::X)) (XLIB::Y (XLIB::REQUIRED-ARG XLIB::Y)) (XLIB::WIDTH (XLIB::REQUIRED-ARG XLIB::WIDTH)) (XLIB::HEIGHT (XLIB::REQUIRED-ARG XLIB::HEIGHT)) (XLIB::LEFT-PAD 0) (FORMAT (XLIB::REQUIRED-ARG FORMAT))) NIL NIL NIL NIL NIL NIL T
:pinfo XLIB:DRAW-POINTS (XLIB:DRAWABLE XLIB:GCONTEXT XLIB::POINTS &OPTIONAL XLIB::RELATIVE-P) NIL NIL NIL NIL NIL NIL T
:pinfo XLIB:DRAW-ARCS (XLIB:DRAWABLE XLIB:GCONTEXT XLIB::ARCS &OPTIONAL XLIB::FILL-P) NIL NIL NIL NIL NIL NIL T
:pinfo XLIB:DRAW-LINE (XLIB:DRAWABLE XLIB:GCONTEXT XLIB::X1 XLIB::Y1 XLIB::X2 XLIB::Y2 &OPTIONAL XLIB::RELATIVE-P) NIL NIL NIL NIL NIL NIL T
:pinfo XLIB:DRAW-SEGMENTS (XLIB:DRAWABLE XLIB:GCONTEXT XLIB::SEGMENTS) NIL NIL NIL NIL NIL NIL T
:pinfo XLIB:DRAW-RECTANGLE (XLIB:DRAWABLE XLIB:GCONTEXT XLIB::X XLIB::Y XLIB::WIDTH XLIB::HEIGHT &OPTIONAL XLIB::FILL-P) NIL NIL NIL NIL NIL NIL T
:pinfo XLIB::DRAW-ARCS-VECTOR (XLIB:DRAWABLE XLIB:GCONTEXT XLIB::ARCS &OPTIONAL XLIB::FILL-P) NIL NIL NIL NIL NIL NIL T
:pinfo XLIB:GET-RAW-IMAGE (XLIB:DRAWABLE &KEY XLIB::DATA (XLIB::START 0) (XLIB::X (XLIB::REQUIRED-ARG XLIB::X)) (XLIB::Y (XLIB::REQUIRED-ARG XLIB::Y)) (XLIB::WIDTH (XLIB::REQUIRED-ARG XLIB::WIDTH)) (XLIB::HEIGHT (XLIB::REQUIRED-ARG XLIB::HEIGHT)) (XLIB::PLANE-MASK 4294967295) (FORMAT (XLIB::REQUIRED-ARG FORMAT)) (XLIB::RESULT-TYPE (QUOTE (VECTOR XLIB:CARD8)))) NIL NIL NIL NIL NIL NIL T
:pinfo XLIB:DRAW-ARC (XLIB:DRAWABLE XLIB:GCONTEXT XLIB::X XLIB::Y XLIB::WIDTH XLIB::HEIGHT XLIB::ANGLE1 XLIB::ANGLE2 &OPTIONAL XLIB::FILL-P) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_xlib_DRAW_2DPOINT();
extern SYMBOL s_xlib_CLOSED_2DDISPLAY; 
extern SYMBOL s_key_DISPLAY; 
extern SYMBOL s_lsp_ERROR; 
extern SYMBOL s_xlib_FORCE_2DGCONTEXT_2DCHANGES_2DINTERNAL; 
extern SYMBOL s_xlib_BUFFER_2DFLUSH; 
extern SYMBOL s_xlib__2AINHIBIT_2DAPPENDING_2A; 
extern SYMBOL s_lsp_NIL; 
extern SYMBOL s_lsp_ASH; 
extern SYMBOL s_lsp_LDB_2D1; 
extern SYMBOL s_xlib_DISPLAY_2DINVOKE_2DAFTER_2DFUNCTION; 
extern LP p_xlib_DRAW_2DPOINTS();
extern SYMBOL s_lsp_LENGTH; 
extern SYMBOL s_lsp_CEILING; 
extern SYMBOL s_xlib_WRITE_2DSEQUENCE_2DINT16; 
extern SYMBOL s_lsp_VALUES_2DLIST; 
extern LP p_xlib_DRAW_2DLINE();
extern LP p_xlib_DRAW_2DLINES();
extern SYMBOL s_key_RELATIVE_2DP; 
extern SYMBOL s_key_FILL_2DP; 
extern SYMBOL s_key_SHAPE; 
extern SYMBOL s_key_COMPLEX; 
extern SYMBOL s_xlib_FILL_2DPOLYGON; 
extern LP p_xlib_FILL_2DPOLYGON();
extern SYMBOL s_key_NON_2DCONVEX; 
extern SYMBOL s_key_CONVEX; 
static struct {unsigned long header; LP cells[3];} 
k5794 = {0x340, 
{((LP)LREF(s_key_COMPLEX)),((LP)LREF(s_key_NON_2DCONVEX)),((LP)LREF(s_key_CONVEX))}};
extern SYMBOL s_key_TEST; 
extern SYMBOL s_lsp_EQ; 
extern SYMBOL s_lsp_POSITION; 
extern LP p_xlib_DRAW_2DSEGMENTS();
extern LP p_xlib_DRAW_2DRECTANGLE();
extern LP p_xlib_DRAW_2DRECTANGLES();
extern LP p_xlib_DRAW_2DARC();
extern SYMBOL s_xlib_RADIANS_2D_3EINT16; 
extern LP p_xlib_DRAW_2DARCS_2DLIST();
extern LP p_xlib_DRAW_2DARCS_2DVECTOR();
extern LP p_xlib_DRAW_2DARCS();
extern SYMBOL s_xlib_DRAW_2DARCS_2DLIST; 
extern SYMBOL s_xlib_DRAW_2DARCS_2DVECTOR; 
MAKE_SIMPLE_STRING(k5799,36,"~S is not one of these types:~{ ~A~}");
extern SYMBOL s_lsp_LIST; 
extern SYMBOL s_lsp_VECTOR; 
MAKE_CONS(k5801,LREF(s_lsp_VECTOR),LREF(s_lsp_NIL));
MAKE_CONS(k5800,LREF(s_lsp_LIST),LREF(k5801));
extern LP p_xlib_PUT_2DRAW_2DIMAGE();
extern SYMBOL s_key_START; 
extern SYMBOL s_key_DEPTH; 
extern SYMBOL s_xlib_MISSING_2DPARAMETER; 
extern SYMBOL s_key_PARAMETER; 
extern SYMBOL s_xlib_DEPTH; 
extern SYMBOL s_xlib__2AREQUIRED_2DARG_2DDUMMY_2A; 
extern SYMBOL s_key_X; 
extern SYMBOL s_xlib_X; 
extern SYMBOL s_key_Y; 
extern SYMBOL s_xlib_Y; 
extern SYMBOL s_key_WIDTH; 
extern SYMBOL s_xlib_WIDTH; 
extern SYMBOL s_key_HEIGHT; 
extern SYMBOL s_xlib_HEIGHT; 
extern SYMBOL s_key_LEFT_2DPAD; 
extern SYMBOL s_key_FORMAT; 
extern SYMBOL s_lsp_FORMAT; 
extern SYMBOL s_key_BITMAP; 
extern SYMBOL s_key_XY_2DPIXMAP; 
extern SYMBOL s_key_Z_2DPIXMAP; 
static struct {unsigned long header; LP cells[3];} 
k5803 = {0x340, 
{((LP)LREF(s_key_BITMAP)),((LP)LREF(s_key_XY_2DPIXMAP)),((LP)LREF(s_key_Z_2DPIXMAP))}};
extern SYMBOL s_xlib_WRITE_2DSEQUENCE_2DCARD8; 
extern LP p_xlib_GET_2DRAW_2DIMAGE();
extern SYMBOL s_key_DATA; 
extern SYMBOL s_key_PLANE_2DMASK; 
static struct {unsigned long header; unsigned long len; int sign; unsigned long digits[1];} k5804 = 
{0xC01, 1, 1, {0xFFFFFFFF}};
extern SYMBOL s_key_RESULT_2DTYPE; 
extern SYMBOL s_xlib_CARD8; 
MAKE_CONS(k5806,LREF(s_xlib_CARD8),LREF(s_lsp_NIL));
MAKE_CONS(k5805,LREF(s_lsp_VECTOR),LREF(k5806));
extern SYMBOL s_xlib_START_2DPENDING_2DCOMMAND; 
static struct {unsigned long header; LP cells[3];} 
k5807 = {0x340, 
{((LP)LREF(s_lsp_ERROR)),((LP)LREF(s_key_XY_2DPIXMAP)),((LP)LREF(s_key_Z_2DPIXMAP))}};
extern SYMBOL s_xlib_BUFFER_2DFORCE_2DOUTPUT; 
extern SYMBOL s_xlib_READ_2DREPLY; 
extern SYMBOL s_xlib_READ_2DSEQUENCE_2DCARD8; 
extern SYMBOL s_xlib_VISUAL_2DINFO; 
extern SYMBOL s_xlib_DEALLOCATE_2DREPLY_2DBUFFER; 
extern SYMBOL s_xlib_STOP_2DPENDING_2DCOMMAND; 
extern LP p_xlib_GRAPHICS_5FINIT312();
extern SYMBOL s_key_VAR; 
extern SYMBOL s_lsp_DEFINE_2DVARIABLE; 


extern LP multiply();
extern LP vref();
extern LP geq_p();
extern LP subtract();
extern LP num_equal_p();
extern LP add();


LP p_xlib_DRAW_2DPOINT(argc, v_DRAWABLE_0, v_GCONTEXT_1, v_X_2, v_Y_3)
      ARGC argc;  LP v_DRAWABLE_0; LP v_GCONTEXT_1; LP v_X_2; LP v_Y_3;
{
LP v_SYMBOL_173; LP v_I_171; LP v_A_170; 
LP v__2EBOFFSET_2E_169; LP v_G14672_168; LP v_I_166; 
LP v_A_165; LP v_I_163; LP v_A_162; 
LP v_I_160; LP v_S_159; LP v_S_157; 
LP v_I_155; LP v_A_154; LP v_I_152; 
LP v_S_151; LP v_S_149; LP v__2EBOFFSET_2E_148; 
LP v_VALUE_146; LP v_N_145; LP v_S_144; 
LP v_VALUE_142; LP v_S_141; LP v_T14671_140; 
LP v_S14670_139; LP v_VALUE_137; LP v_N_136; 
LP v_S_135; LP v_VALUE_133; LP v_S_132; 
LP v_T14669_131; LP v_S14668_130; LP v_VALUE_128; 
LP v_N_127; LP v_S_126; LP v_VALUE_124; 
LP v_S_123; LP v_T14667_122; LP v_S14666_121; 
LP v_X_119; LP v_I_117; LP v_S_116; 
LP v_S_114; LP v_BUFFER_112; LP v_I_110; 
LP v_A_109; LP v_V_108; LP v_I_106; 
LP v_A_105; LP v_V_104; LP v_I_102; 
LP v_A_101; LP v_V_100; LP v_I_98; 
LP v_S_97; LP v_S_95; LP v_I_93; 
LP v_A_92; LP v_V_91; LP v_I_89; 
LP v_S_88; LP v_S_86; LP v_I_84; 
LP v_A_83; LP v_V_82; LP v_T14665_81; 
LP v_T14664_80; LP v_S14663_79; LP v_I_77; 
LP v_A_76; LP v_V_75; LP v_T14662_74; 
LP v_T14661_73; LP v_S14660_72; LP v_I_70; 
LP v_A_69; LP v_V_68; LP v_VALUE_66; 
LP v_N_65; LP v_S_64; LP v_VALUE_62; 
LP v_S_61; LP v_T14659_60; LP v_S14658_59; 
LP v_I_57; LP v_A_56; LP v_V_55; 
LP v_I_53; LP v_A_52; LP v_V_51; 
LP v__2EBOFFSET_2E_50; LP v_I_48; LP v_A_47; 
LP v_V_46; LP v_CURRENT_2DBOFFSET_45; LP v_LAST_2DREQUEST_2DBYTE_44; 
LP v_I_42; LP v_S_41; LP v_S_39; 
LP v_BUFFER_2DBBUF_38; LP v_I_36; LP v_S_35; 
LP v_S_33; LP v_BUFFER_2DBOFFSET_32; LP v_I_30; 
LP v_S_29; LP v_S_27; LP v_I_25; 
LP v_S_24; LP v_S_22; LP v_I_20; 
LP v_S_19; LP v_S_17; LP v__25BUFFER_16; 
LP v_I_14; LP v_S_13; LP v_S_11; 
LP v_DISPLAY_10; LP v_I_8; LP v_S_7; 
LP v_S_5; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; 
if (argc != 4) wna(argc,4);
v_S_5 = v_DRAWABLE_0;
v_S_7 = v_DRAWABLE_0;
v_I_8 = (LP) 4;
v_DISPLAY_10 = ((LP) DEREF((v_DRAWABLE_0) + 2 * 4));
v_S_11 = v_DISPLAY_10;
v_S_13 = v_DISPLAY_10;
v_I_14 = (LP) 22;
t0 = ((LP) DEREF((v_DISPLAY_10) + 11 * 4));
if (t0 != NIL) {
ICALL(s_lsp_ERROR) (3, LREF(s_xlib_CLOSED_2DDISPLAY), LREF(s_key_DISPLAY), v_DISPLAY_10);
}
ICALL(s_xlib_FORCE_2DGCONTEXT_2DCHANGES_2DINTERNAL) (1, v_GCONTEXT_1);
v__25BUFFER_16 = v_DISPLAY_10;
v_S_17 = v__25BUFFER_16;
v_S_19 = v__25BUFFER_16;
v_I_20 = (LP) 14;
t3 = ((LP) DEREF((v__25BUFFER_16) + 7 * 4));
t2 = (add((t3), ((LP) 320)));
v_S_22 = v__25BUFFER_16;
v_S_24 = v__25BUFFER_16;
v_I_25 = (LP) 6;
t4 = ((LP) DEREF((v__25BUFFER_16) + 3 * 4));
if (((int) (t2) >= (int) (t4))) {
ICALL(s_xlib_BUFFER_2DFLUSH) (1, v__25BUFFER_16);
}
v_S_27 = v__25BUFFER_16;
v_S_29 = v__25BUFFER_16;
v_I_30 = (LP) 14;
v_BUFFER_2DBOFFSET_32 = ((LP) DEREF((v__25BUFFER_16) + 7 * 4));
v_S_33 = v__25BUFFER_16;
v_S_35 = v__25BUFFER_16;
v_I_36 = (LP) 16;
v_BUFFER_2DBBUF_38 = ((LP) DEREF((v__25BUFFER_16) + 8 * 4));
v_S_39 = v_DISPLAY_10;
v_S_41 = v_DISPLAY_10;
v_I_42 = (LP) 10;
v_LAST_2DREQUEST_2DBYTE_44 = ((LP) DEREF((v_DISPLAY_10) + 5 * 4));
v_CURRENT_2DBOFFSET_45 = v_BUFFER_2DBOFFSET_32;
v_SYMBOL_173 = LREF(s_xlib__2AINHIBIT_2DAPPENDING_2A);
t6 = ((LP) DEREF((LREF(s_xlib__2AINHIBIT_2DAPPENDING_2A)) + 0 * 4));
if (t6 != NIL) {
t5 = LREF(s_lsp_NIL);
} else {
if (v_LAST_2DREQUEST_2DBYTE_44 != NIL) {
v_A_170 = v_BUFFER_2DBBUF_38;
v_I_171 = v_LAST_2DREQUEST_2DBYTE_44;
t8 = (LP) INT_TO_FX(((unsigned char (*)) (v_BUFFER_2DBBUF_38 - 1))[FX_TO_INT(v_LAST_2DREQUEST_2DBYTE_44)]);
t7 = (num_equal_p((t8), ((LP) 128)));
if (t7 != NIL) {
v__2EBOFFSET_2E_148 = v_LAST_2DREQUEST_2DBYTE_44;
v_BUFFER_2DBOFFSET_32 = v_LAST_2DREQUEST_2DBYTE_44;
t10 = (add((v_BUFFER_2DBOFFSET_32), ((LP) 2)));
v_I_166 = t10;
t11 = (LP) INT_TO_FX(((unsigned char (*)) (v_BUFFER_2DBBUF_38 - 1))[FX_TO_INT(v_I_166)]);
t9 = (num_equal_p(((LP) 0), (t11)));
if (t9 != NIL) {
v_S_157 = v_DRAWABLE_0;
v_S_159 = v_DRAWABLE_0;
v_I_160 = (LP) 2;
t13 = ((LP) DEREF((v_DRAWABLE_0) + 1 * 4));
t14 = (add((v_BUFFER_2DBOFFSET_32), ((LP) 8)));
v_I_163 = t14;
t16 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_163)) >> (2)));
t15 = INT_TO_FX((LP) (*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_38) - 1)) + FX_TO_INT(t16))));
t12 = (num_equal_p((t13), (t15)));
if (t12 != NIL) {
v_S_149 = v_GCONTEXT_1;
v_S_151 = v_GCONTEXT_1;
v_I_152 = (LP) 2;
t17 = ((LP) DEREF((v_GCONTEXT_1) + 1 * 4));
t18 = (add((v_BUFFER_2DBOFFSET_32), ((LP) 16)));
v_I_155 = t18;
t20 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_155)) >> (2)));
t19 = INT_TO_FX((LP) (*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_38) - 1)) + FX_TO_INT(t20))));
v_G14672_168 = (num_equal_p((t17), (t19)));
} else {
v_G14672_168 = LREF(s_lsp_NIL);
}
} else {
v_G14672_168 = LREF(s_lsp_NIL);
}
if (v_G14672_168 != NIL) {
t5 = v_G14672_168;
} else {
v__2EBOFFSET_2E_169 = v_CURRENT_2DBOFFSET_45;
v_BUFFER_2DBOFFSET_32 = v_CURRENT_2DBOFFSET_45;
t5 = LREF(s_lsp_NIL);
}
} else {
t5 = LREF(s_lsp_NIL);
}
} else {
t5 = LREF(s_lsp_NIL);
}
}
if (t5 != NIL) {
t23 = (subtract((v_CURRENT_2DBOFFSET_45), (v_LAST_2DREQUEST_2DBYTE_44)));
t22 = ICALL(s_lsp_ASH) (2, t23, (LP) -4);
t21 = (add(((LP) 2), (t22)));
v_V_46 = t21;
t24 = (add((v_BUFFER_2DBOFFSET_32), ((LP) 4)));
v_I_48 = t24;
t25 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_48)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_38) - 1))+FX_TO_INT(t25))) = (unsigned short) FX_TO_INT(v_V_46)));
v__2EBOFFSET_2E_50 = v_CURRENT_2DBOFFSET_45;
v_BUFFER_2DBOFFSET_32 = v_CURRENT_2DBOFFSET_45;
v_V_51 = v_X_2;
t26 = (add((v_BUFFER_2DBOFFSET_32), ((LP) 0)));
v_I_53 = t26;
t27 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_53)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_38) - 1)) + FX_TO_INT(t27))) = (short) FX_TO_INT(v_V_51)));
v_V_55 = v_Y_3;
t28 = (add((v_BUFFER_2DBOFFSET_32), ((LP) 4)));
v_I_57 = t28;
t29 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_57)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_38) - 1)) + FX_TO_INT(t29))) = (short) FX_TO_INT(v_V_55)));
t30 = (add((v_BUFFER_2DBOFFSET_32), ((LP) 8)));
v_S14658_59 = t30;
v_T14659_60 = v_DISPLAY_10;
v_S_61 = v_DISPLAY_10;
v_VALUE_62 = v_S14658_59;
v_S_64 = v_DISPLAY_10;
v_N_65 = (LP) 14;
v_VALUE_66 = v_S14658_59;
((LP) (DEREF((v_DISPLAY_10) + 7 * 4) = (LD) (v_S14658_59)));
} else {
t31 = (add((v_BUFFER_2DBOFFSET_32), ((LP) 0)));
v_I_70 = t31;
v_S14660_72 = (LP) 128;
v_T14661_73 = v_BUFFER_2DBBUF_38;
v_T14662_74 = v_I_70;
((unsigned char (*)) (v_BUFFER_2DBBUF_38 - 1))[FX_TO_INT(v_I_70)] = (unsigned char)FX_TO_INT((LP) 128);
t32 = (add((v_BUFFER_2DBOFFSET_32), ((LP) 2)));
v_I_77 = t32;
v_S14663_79 = (LP) 0;
v_T14664_80 = v_BUFFER_2DBBUF_38;
v_T14665_81 = v_I_77;
((unsigned char (*)) (v_BUFFER_2DBBUF_38 - 1))[FX_TO_INT(v_I_77)] = (unsigned char)FX_TO_INT((LP) 0);
v_V_82 = (LP) 8;
t33 = (add((v_BUFFER_2DBOFFSET_32), ((LP) 4)));
v_I_84 = t33;
t34 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_84)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_38) - 1))+FX_TO_INT(t34))) = (unsigned short) FX_TO_INT(v_V_82)));
v_S_86 = v_DRAWABLE_0;
v_S_88 = v_DRAWABLE_0;
v_I_89 = (LP) 2;
v_V_91 = ((LP) DEREF((v_DRAWABLE_0) + 1 * 4));
t35 = (add((v_BUFFER_2DBOFFSET_32), ((LP) 8)));
v_I_93 = t35;
t36 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_93)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_38) - 1)) + FX_TO_INT(t36))) = (unsigned long) FX_TO_INT(v_V_91)));
v_S_95 = v_GCONTEXT_1;
v_S_97 = v_GCONTEXT_1;
v_I_98 = (LP) 2;
v_V_100 = ((LP) DEREF((v_GCONTEXT_1) + 1 * 4));
t37 = (add((v_BUFFER_2DBOFFSET_32), ((LP) 16)));
v_I_102 = t37;
t38 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_102)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_38) - 1)) + FX_TO_INT(t38))) = (unsigned long) FX_TO_INT(v_V_100)));
v_V_104 = v_X_2;
t39 = (add((v_BUFFER_2DBOFFSET_32), ((LP) 24)));
v_I_106 = t39;
t40 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_106)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_38) - 1)) + FX_TO_INT(t40))) = (short) FX_TO_INT(v_V_104)));
v_V_108 = v_Y_3;
t41 = (add((v_BUFFER_2DBOFFSET_32), ((LP) 28)));
v_I_110 = t41;
t42 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_110)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_38) - 1)) + FX_TO_INT(t42))) = (short) FX_TO_INT(v_V_108)));
v_BUFFER_112 = v_DISPLAY_10;
v_S_114 = v_BUFFER_112;
v_S_116 = v_BUFFER_112;
v_I_117 = (LP) 8;
v_X_119 = ((LP) DEREF((v_BUFFER_112) + 4 * 4));
t43 = (add((v_X_119), ((LP) 2)));
v_S14666_121 = ICALL(s_lsp_LDB_2D1) (3, (LP) 32, (LP) 0, t43);
v_T14667_122 = v_BUFFER_112;
v_S_123 = v_BUFFER_112;
v_VALUE_124 = v_S14666_121;
v_S_126 = v_BUFFER_112;
v_N_127 = (LP) 8;
v_VALUE_128 = v_S14666_121;
((LP) (DEREF((v_BUFFER_112) + 4 * 4) = (LD) (v_S14666_121)));
v_S14668_130 = v_BUFFER_2DBOFFSET_32;
v_T14669_131 = v_DISPLAY_10;
v_S_132 = v_DISPLAY_10;
v_VALUE_133 = v_S14668_130;
v_S_135 = v_DISPLAY_10;
v_N_136 = (LP) 10;
v_VALUE_137 = v_S14668_130;
((LP) (DEREF((v_DISPLAY_10) + 5 * 4) = (LD) (v_S14668_130)));
t44 = (add((v_BUFFER_2DBOFFSET_32), ((LP) 32)));
v_S14670_139 = t44;
v_T14671_140 = v_DISPLAY_10;
v_S_141 = v_DISPLAY_10;
v_VALUE_142 = v_S14670_139;
v_S_144 = v_DISPLAY_10;
v_N_145 = (LP) 14;
v_VALUE_146 = v_S14670_139;
((LP) (DEREF((v_DISPLAY_10) + 7 * 4) = (LD) (v_S14670_139)));
}
t45 = ICALL(s_xlib_DISPLAY_2DINVOKE_2DAFTER_2DFUNCTION) (MV_CALL(argc,1), v_DISPLAY_10);
return(t45);
}

LP p_xlib_DRAW_2DPOINTS(va_alist) va_dcl
{
LP v_VALUE_102; LP v_N_101; LP v_S_100; 
LP v_VALUE_98; LP v_S_97; LP v_T14779_96; 
LP v_S14778_95; LP v_X_93; LP v_I_91; 
LP v_S_90; LP v_S_88; LP v_BUFFER_86; 
LP v_I_84; LP v_A_83; LP v_V_82; 
LP v_T14777_81; LP v_I_79; LP v_A_78; 
LP v_V_77; LP v_I_75; LP v_S_74; 
LP v_S_72; LP v_I_70; LP v_A_69; 
LP v_V_68; LP v_I_66; LP v_S_65; 
LP v_S_63; LP v_T14776_62; LP v_T14775_61; 
LP v_S14774_60; LP v_I_58; LP v_A_57; 
LP v_V_56; LP v_T14773_55; LP v_T14772_54; 
LP v_S14771_53; LP v_I_51; LP v_A_50; 
LP v_V_49; LP v_VALUE_47; LP v_N_46; 
LP v_S_45; LP v_VALUE_43; LP v_S_42; 
LP v_T14770_41; LP v_S14769_40; LP v_BUFFER_2DBBUF_39; 
LP v_I_37; LP v_S_36; LP v_S_34; 
LP v_BUFFER_2DBOFFSET_33; LP v_I_31; LP v_S_30; 
LP v_S_28; LP v_I_26; LP v_S_25; 
LP v_S_23; LP v_I_21; LP v_S_20; 
LP v_S_18; LP v__25BUFFER_17; LP v_MV14768_16; 
LP v_I_14; LP v_S_13; LP v_S_11; 
LP v__2EDISPLAY_2E_10; LP v_I_8; LP v_S_7; 
LP v_S_5; LP v_POINTS_2; LP v_GCONTEXT_1; 
LP v_DRAWABLE_0; LP v_RELATIVE_2DP_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_DRAWABLE_0 = NEXT_VAR_ARG;
v_GCONTEXT_1 = NEXT_VAR_ARG;
v_POINTS_2 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 3) wna_low(real_argc,3);
if (real_argc > 4) wna_high(real_argc,4);
if (real_argc < 4) {
v_RELATIVE_2DP_3 = NIL;
} else {
v_RELATIVE_2DP_3 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
v_S_5 = v_DRAWABLE_0;
v_S_7 = v_DRAWABLE_0;
v_I_8 = (LP) 4;
v__2EDISPLAY_2E_10 = ((LP) DEREF((v_DRAWABLE_0) + 2 * 4));
v_S_11 = v__2EDISPLAY_2E_10;
v_S_13 = v__2EDISPLAY_2E_10;
v_I_14 = (LP) 22;
t0 = ((LP) DEREF((v__2EDISPLAY_2E_10) + 11 * 4));
if (t0 != NIL) {
ICALL(s_lsp_ERROR) (3, LREF(s_xlib_CLOSED_2DDISPLAY), LREF(s_key_DISPLAY), v__2EDISPLAY_2E_10);
}
ICALL(s_xlib_FORCE_2DGCONTEXT_2DCHANGES_2DINTERNAL) (1, v_GCONTEXT_1);
{
int real_argc;
BEGIN_MV_CALL(mv_holder5791,0);
v__25BUFFER_17 = v__2EDISPLAY_2E_10;
v_S_18 = v__25BUFFER_17;
v_S_20 = v__25BUFFER_17;
v_I_21 = (LP) 14;
t3 = ((LP) DEREF((v__25BUFFER_17) + 7 * 4));
t2 = (add((t3), ((LP) 320)));
v_S_23 = v__25BUFFER_17;
v_S_25 = v__25BUFFER_17;
v_I_26 = (LP) 6;
t4 = ((LP) DEREF((v__25BUFFER_17) + 3 * 4));
if (((int) (t2) >= (int) (t4))) {
ICALL(s_xlib_BUFFER_2DFLUSH) (1, v__25BUFFER_17);
}
v_S_28 = v__25BUFFER_17;
v_S_30 = v__25BUFFER_17;
v_I_31 = (LP) 14;
v_BUFFER_2DBOFFSET_33 = ((LP) DEREF((v__25BUFFER_17) + 7 * 4));
v_S_34 = v__25BUFFER_17;
v_S_36 = v__25BUFFER_17;
v_I_37 = (LP) 16;
v_BUFFER_2DBBUF_39 = ((LP) DEREF((v__25BUFFER_17) + 8 * 4));
v_S14769_40 = v_BUFFER_2DBOFFSET_33;
v_T14770_41 = v__2EDISPLAY_2E_10;
v_S_42 = v__2EDISPLAY_2E_10;
v_VALUE_43 = v_BUFFER_2DBOFFSET_33;
v_S_45 = v__2EDISPLAY_2E_10;
v_N_46 = (LP) 10;
v_VALUE_47 = v_BUFFER_2DBOFFSET_33;
((LP) (DEREF((v__2EDISPLAY_2E_10) + 5 * 4) = (LD) (v_BUFFER_2DBOFFSET_33)));
t5 = (add((v_BUFFER_2DBOFFSET_33), ((LP) 0)));
v_I_51 = t5;
v_S14771_53 = (LP) 128;
v_T14772_54 = v_BUFFER_2DBBUF_39;
v_T14773_55 = v_I_51;
((unsigned char (*)) (v_BUFFER_2DBBUF_39 - 1))[FX_TO_INT(v_I_51)] = (unsigned char)FX_TO_INT((LP) 128);
if (v_RELATIVE_2DP_3 != NIL) {
v_V_56 = (LP) 2;
} else {
v_V_56 = (LP) 0;
}
t6 = (add((v_BUFFER_2DBOFFSET_33), ((LP) 2)));
v_I_58 = t6;
v_S14774_60 = v_V_56;
v_T14775_61 = v_BUFFER_2DBBUF_39;
v_T14776_62 = v_I_58;
((unsigned char (*)) (v_BUFFER_2DBBUF_39 - 1))[FX_TO_INT(v_I_58)] = (unsigned char)FX_TO_INT(v_V_56);
v_S_63 = v_DRAWABLE_0;
v_S_65 = v_DRAWABLE_0;
v_I_66 = (LP) 2;
v_V_68 = ((LP) DEREF((v_DRAWABLE_0) + 1 * 4));
t7 = (add((v_BUFFER_2DBOFFSET_33), ((LP) 8)));
v_I_70 = t7;
t8 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_70)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_39) - 1)) + FX_TO_INT(t8))) = (unsigned long) FX_TO_INT(v_V_68)));
v_S_72 = v_GCONTEXT_1;
v_S_74 = v_GCONTEXT_1;
v_I_75 = (LP) 2;
v_V_77 = ((LP) DEREF((v_GCONTEXT_1) + 1 * 4));
t9 = (add((v_BUFFER_2DBOFFSET_33), ((LP) 16)));
v_I_79 = t9;
t10 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_79)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_39) - 1)) + FX_TO_INT(t10))) = (unsigned long) FX_TO_INT(v_V_77)));
v_T14777_81 = ICALL(s_lsp_LENGTH) (1, v_POINTS_2);
t13 = (subtract((v_T14777_81), ((LP) 0)));
t12 = ICALL(s_lsp_CEILING) (2, t13, (LP) 4);
t11 = (add((t12), ((LP) 6)));
v_V_82 = t11;
t14 = (add((v_BUFFER_2DBOFFSET_33), ((LP) 4)));
v_I_84 = t14;
t15 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_84)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_39) - 1))+FX_TO_INT(t15))) = (unsigned short) FX_TO_INT(v_V_82)));
t16 = (add((v_BUFFER_2DBOFFSET_33), ((LP) 24)));
ICALL(s_xlib_WRITE_2DSEQUENCE_2DINT16) (6, v__25BUFFER_17, t16, v_POINTS_2, (LP) 0, v_T14777_81, LREF(s_lsp_NIL));
v_BUFFER_86 = v__2EDISPLAY_2E_10;
v_S_88 = v_BUFFER_86;
v_S_90 = v_BUFFER_86;
v_I_91 = (LP) 8;
v_X_93 = ((LP) DEREF((v_BUFFER_86) + 4 * 4));
t17 = (add((v_X_93), ((LP) 2)));
v_S14778_95 = ICALL(s_lsp_LDB_2D1) (3, (LP) 32, (LP) 0, t17);
v_T14779_96 = v_BUFFER_86;
v_S_97 = v_BUFFER_86;
v_VALUE_98 = v_S14778_95;
v_S_100 = v_BUFFER_86;
v_N_101 = (LP) 8;
v_VALUE_102 = v_S14778_95;
t18 = ((LP) (DEREF((v_BUFFER_86) + 4 * 4) = (LD) (v_S14778_95)));
SET_MV_RETURN_VALUE(mv_holder5791,0,t18);
if SV_RETURN_P(mv_holder5791) SET_MV_RETURN_COUNT(mv_holder5791,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder5791);
BEGIN_VAR_VALUES;
RESTIFY(v_MV14768_16,1,NEXT_VAR_VALUE(mv_holder5791));
END_VAR_VALUES;
END_MV_CALL;
ICALL(s_xlib_DISPLAY_2DINVOKE_2DAFTER_2DFUNCTION) (1, v__2EDISPLAY_2E_10);
t19 = ICALL(s_lsp_VALUES_2DLIST) (MV_CALL(argc,1), v_MV14768_16);
return(t19);
}
}

LP p_xlib_DRAW_2DLINE(va_alist) va_dcl
{
LP v_SYMBOL_184; LP v_I_182; LP v_A_181; 
LP v__2EBOFFSET_2E_180; LP v_G14803_179; LP v_I_177; 
LP v_A_176; LP v_I_174; LP v_S_173; 
LP v_S_171; LP v_I_169; LP v_A_168; 
LP v_I_166; LP v_S_165; LP v_S_163; 
LP v__2EBOFFSET_2E_162; LP v_VALUE_160; LP v_N_159; 
LP v_S_158; LP v_VALUE_156; LP v_S_155; 
LP v_T14802_154; LP v_S14801_153; LP v_VALUE_151; 
LP v_N_150; LP v_S_149; LP v_VALUE_147; 
LP v_S_146; LP v_T14800_145; LP v_S14799_144; 
LP v_VALUE_142; LP v_N_141; LP v_S_140; 
LP v_VALUE_138; LP v_S_137; LP v_T14798_136; 
LP v_S14797_135; LP v_X_133; LP v_I_131; 
LP v_S_130; LP v_S_128; LP v_BUFFER_126; 
LP v_I_124; LP v_A_123; LP v_V_122; 
LP v_I_120; LP v_A_119; LP v_V_118; 
LP v_I_116; LP v_A_115; LP v_V_114; 
LP v_I_112; LP v_A_111; LP v_V_110; 
LP v_I_108; LP v_A_107; LP v_V_106; 
LP v_I_104; LP v_S_103; LP v_S_101; 
LP v_I_99; LP v_A_98; LP v_V_97; 
LP v_I_95; LP v_S_94; LP v_S_92; 
LP v_I_90; LP v_A_89; LP v_V_88; 
LP v_T14796_87; LP v_T14795_86; LP v_S14794_85; 
LP v_I_83; LP v_A_82; LP v_V_81; 
LP v_VALUE_79; LP v_N_78; LP v_S_77; 
LP v_VALUE_75; LP v_S_74; LP v_T14793_73; 
LP v_S14792_72; LP v_I_70; LP v_A_69; 
LP v_V_68; LP v_I_66; LP v_A_65; 
LP v_V_64; LP v_I_62; LP v_A_61; 
LP v_V_60; LP v_I_58; LP v_A_57; 
LP v_V_56; LP v__2EBOFFSET_2E_55; LP v_I_53; 
LP v_A_52; LP v_V_51; LP v_CURRENT_2DBOFFSET_50; 
LP v_LAST_2DREQUEST_2DBYTE_49; LP v_I_47; LP v_S_46; 
LP v_S_44; LP v_BUFFER_2DBBUF_43; LP v_I_41; 
LP v_S_40; LP v_S_38; LP v_BUFFER_2DBOFFSET_37; 
LP v_I_35; LP v_S_34; LP v_S_32; 
LP v_I_30; LP v_S_29; LP v_S_27; 
LP v_I_25; LP v_S_24; LP v_S_22; 
LP v__25BUFFER_21; LP v_I_19; LP v_S_18; 
LP v_S_16; LP v_S14781_15; LP v_S14780_14; 
LP v_DISPLAY_13; LP v_I_11; LP v_S_10; 
LP v_S_8; LP v_Y2_5; LP v_X2_4; 
LP v_Y1_3; LP v_X1_2; LP v_GCONTEXT_1; 
LP v_DRAWABLE_0; LP v_RELATIVE_2DP_6; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; LP t145; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_DRAWABLE_0 = NEXT_VAR_ARG;
v_GCONTEXT_1 = NEXT_VAR_ARG;
v_X1_2 = NEXT_VAR_ARG;
v_Y1_3 = NEXT_VAR_ARG;
v_X2_4 = NEXT_VAR_ARG;
v_Y2_5 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 6) wna_low(real_argc,6);
if (real_argc > 7) wna_high(real_argc,7);
if (real_argc < 7) {
v_RELATIVE_2DP_6 = NIL;
} else {
v_RELATIVE_2DP_6 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
v_S_8 = v_DRAWABLE_0;
v_S_10 = v_DRAWABLE_0;
v_I_11 = (LP) 4;
v_DISPLAY_13 = ((LP) DEREF((v_DRAWABLE_0) + 2 * 4));
if (v_RELATIVE_2DP_6 != NIL) {
v_S14780_14 = (add((v_X2_4), (v_X1_2)));
v_X2_4 = v_S14780_14;
v_S14781_15 = (add((v_Y2_5), (v_Y1_3)));
v_Y2_5 = v_S14781_15;
}
v_S_16 = v_DISPLAY_13;
v_S_18 = v_DISPLAY_13;
v_I_19 = (LP) 22;
t0 = ((LP) DEREF((v_DISPLAY_13) + 11 * 4));
if (t0 != NIL) {
ICALL(s_lsp_ERROR) (3, LREF(s_xlib_CLOSED_2DDISPLAY), LREF(s_key_DISPLAY), v_DISPLAY_13);
}
ICALL(s_xlib_FORCE_2DGCONTEXT_2DCHANGES_2DINTERNAL) (1, v_GCONTEXT_1);
v__25BUFFER_21 = v_DISPLAY_13;
v_S_22 = v__25BUFFER_21;
v_S_24 = v__25BUFFER_21;
v_I_25 = (LP) 14;
t3 = ((LP) DEREF((v__25BUFFER_21) + 7 * 4));
t2 = (add((t3), ((LP) 320)));
v_S_27 = v__25BUFFER_21;
v_S_29 = v__25BUFFER_21;
v_I_30 = (LP) 6;
t4 = ((LP) DEREF((v__25BUFFER_21) + 3 * 4));
if (((int) (t2) >= (int) (t4))) {
ICALL(s_xlib_BUFFER_2DFLUSH) (1, v__25BUFFER_21);
}
v_S_32 = v__25BUFFER_21;
v_S_34 = v__25BUFFER_21;
v_I_35 = (LP) 14;
v_BUFFER_2DBOFFSET_37 = ((LP) DEREF((v__25BUFFER_21) + 7 * 4));
v_S_38 = v__25BUFFER_21;
v_S_40 = v__25BUFFER_21;
v_I_41 = (LP) 16;
v_BUFFER_2DBBUF_43 = ((LP) DEREF((v__25BUFFER_21) + 8 * 4));
v_S_44 = v_DISPLAY_13;
v_S_46 = v_DISPLAY_13;
v_I_47 = (LP) 10;
v_LAST_2DREQUEST_2DBYTE_49 = ((LP) DEREF((v_DISPLAY_13) + 5 * 4));
v_CURRENT_2DBOFFSET_50 = v_BUFFER_2DBOFFSET_37;
v_SYMBOL_184 = LREF(s_xlib__2AINHIBIT_2DAPPENDING_2A);
t6 = ((LP) DEREF((LREF(s_xlib__2AINHIBIT_2DAPPENDING_2A)) + 0 * 4));
if (t6 != NIL) {
t5 = LREF(s_lsp_NIL);
} else {
if (v_LAST_2DREQUEST_2DBYTE_49 != NIL) {
v_A_181 = v_BUFFER_2DBBUF_43;
v_I_182 = v_LAST_2DREQUEST_2DBYTE_49;
t8 = (LP) INT_TO_FX(((unsigned char (*)) (v_BUFFER_2DBBUF_43 - 1))[FX_TO_INT(v_LAST_2DREQUEST_2DBYTE_49)]);
t7 = (num_equal_p((t8), ((LP) 132)));
if (t7 != NIL) {
v__2EBOFFSET_2E_162 = v_LAST_2DREQUEST_2DBYTE_49;
v_BUFFER_2DBOFFSET_37 = v_LAST_2DREQUEST_2DBYTE_49;
v_S_171 = v_DRAWABLE_0;
v_S_173 = v_DRAWABLE_0;
v_I_174 = (LP) 2;
t10 = ((LP) DEREF((v_DRAWABLE_0) + 1 * 4));
t11 = (add((v_BUFFER_2DBOFFSET_37), ((LP) 8)));
v_I_177 = t11;
t13 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_177)) >> (2)));
t12 = INT_TO_FX((LP) (*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_43) - 1)) + FX_TO_INT(t13))));
t9 = (num_equal_p((t10), (t12)));
if (t9 != NIL) {
v_S_163 = v_GCONTEXT_1;
v_S_165 = v_GCONTEXT_1;
v_I_166 = (LP) 2;
t14 = ((LP) DEREF((v_GCONTEXT_1) + 1 * 4));
t15 = (add((v_BUFFER_2DBOFFSET_37), ((LP) 16)));
v_I_169 = t15;
t17 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_169)) >> (2)));
t16 = INT_TO_FX((LP) (*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_43) - 1)) + FX_TO_INT(t17))));
v_G14803_179 = (num_equal_p((t14), (t16)));
} else {
v_G14803_179 = LREF(s_lsp_NIL);
}
if (v_G14803_179 != NIL) {
t5 = v_G14803_179;
} else {
v__2EBOFFSET_2E_180 = v_CURRENT_2DBOFFSET_50;
v_BUFFER_2DBOFFSET_37 = v_CURRENT_2DBOFFSET_50;
t5 = LREF(s_lsp_NIL);
}
} else {
t5 = LREF(s_lsp_NIL);
}
} else {
t5 = LREF(s_lsp_NIL);
}
}
if (t5 != NIL) {
t20 = (subtract((v_CURRENT_2DBOFFSET_50), (v_LAST_2DREQUEST_2DBYTE_49)));
t19 = ICALL(s_lsp_ASH) (2, t20, (LP) -4);
t18 = (add(((LP) 4), (t19)));
v_V_51 = t18;
t21 = (add((v_BUFFER_2DBOFFSET_37), ((LP) 4)));
v_I_53 = t21;
t22 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_53)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_43) - 1))+FX_TO_INT(t22))) = (unsigned short) FX_TO_INT(v_V_51)));
v__2EBOFFSET_2E_55 = v_CURRENT_2DBOFFSET_50;
v_BUFFER_2DBOFFSET_37 = v_CURRENT_2DBOFFSET_50;
v_V_56 = v_X1_2;
t23 = (add((v_BUFFER_2DBOFFSET_37), ((LP) 0)));
v_I_58 = t23;
t24 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_58)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_43) - 1)) + FX_TO_INT(t24))) = (short) FX_TO_INT(v_V_56)));
v_V_60 = v_Y1_3;
t25 = (add((v_BUFFER_2DBOFFSET_37), ((LP) 4)));
v_I_62 = t25;
t26 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_62)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_43) - 1)) + FX_TO_INT(t26))) = (short) FX_TO_INT(v_V_60)));
v_V_64 = v_X2_4;
t27 = (add((v_BUFFER_2DBOFFSET_37), ((LP) 8)));
v_I_66 = t27;
t28 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_66)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_43) - 1)) + FX_TO_INT(t28))) = (short) FX_TO_INT(v_V_64)));
v_V_68 = v_Y2_5;
t29 = (add((v_BUFFER_2DBOFFSET_37), ((LP) 12)));
v_I_70 = t29;
t30 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_70)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_43) - 1)) + FX_TO_INT(t30))) = (short) FX_TO_INT(v_V_68)));
t31 = (add((v_BUFFER_2DBOFFSET_37), ((LP) 16)));
v_S14792_72 = t31;
v_T14793_73 = v_DISPLAY_13;
v_S_74 = v_DISPLAY_13;
v_VALUE_75 = v_S14792_72;
v_S_77 = v_DISPLAY_13;
v_N_78 = (LP) 14;
v_VALUE_79 = v_S14792_72;
((LP) (DEREF((v_DISPLAY_13) + 7 * 4) = (LD) (v_S14792_72)));
} else {
t32 = (add((v_BUFFER_2DBOFFSET_37), ((LP) 0)));
v_I_83 = t32;
v_S14794_85 = (LP) 132;
v_T14795_86 = v_BUFFER_2DBBUF_43;
v_T14796_87 = v_I_83;
((unsigned char (*)) (v_BUFFER_2DBBUF_43 - 1))[FX_TO_INT(v_I_83)] = (unsigned char)FX_TO_INT((LP) 132);
v_V_88 = (LP) 10;
t33 = (add((v_BUFFER_2DBOFFSET_37), ((LP) 4)));
v_I_90 = t33;
t34 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_90)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_43) - 1))+FX_TO_INT(t34))) = (unsigned short) FX_TO_INT(v_V_88)));
v_S_92 = v_DRAWABLE_0;
v_S_94 = v_DRAWABLE_0;
v_I_95 = (LP) 2;
v_V_97 = ((LP) DEREF((v_DRAWABLE_0) + 1 * 4));
t35 = (add((v_BUFFER_2DBOFFSET_37), ((LP) 8)));
v_I_99 = t35;
t36 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_99)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_43) - 1)) + FX_TO_INT(t36))) = (unsigned long) FX_TO_INT(v_V_97)));
v_S_101 = v_GCONTEXT_1;
v_S_103 = v_GCONTEXT_1;
v_I_104 = (LP) 2;
v_V_106 = ((LP) DEREF((v_GCONTEXT_1) + 1 * 4));
t37 = (add((v_BUFFER_2DBOFFSET_37), ((LP) 16)));
v_I_108 = t37;
t38 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_108)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_43) - 1)) + FX_TO_INT(t38))) = (unsigned long) FX_TO_INT(v_V_106)));
v_V_110 = v_X1_2;
t39 = (add((v_BUFFER_2DBOFFSET_37), ((LP) 24)));
v_I_112 = t39;
t40 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_112)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_43) - 1)) + FX_TO_INT(t40))) = (short) FX_TO_INT(v_V_110)));
v_V_114 = v_Y1_3;
t41 = (add((v_BUFFER_2DBOFFSET_37), ((LP) 28)));
v_I_116 = t41;
t42 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_116)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_43) - 1)) + FX_TO_INT(t42))) = (short) FX_TO_INT(v_V_114)));
v_V_118 = v_X2_4;
t43 = (add((v_BUFFER_2DBOFFSET_37), ((LP) 32)));
v_I_120 = t43;
t44 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_120)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_43) - 1)) + FX_TO_INT(t44))) = (short) FX_TO_INT(v_V_118)));
v_V_122 = v_Y2_5;
t45 = (add((v_BUFFER_2DBOFFSET_37), ((LP) 36)));
v_I_124 = t45;
t46 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_124)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_43) - 1)) + FX_TO_INT(t46))) = (short) FX_TO_INT(v_V_122)));
v_BUFFER_126 = v_DISPLAY_13;
v_S_128 = v_BUFFER_126;
v_S_130 = v_BUFFER_126;
v_I_131 = (LP) 8;
v_X_133 = ((LP) DEREF((v_BUFFER_126) + 4 * 4));
t47 = (add((v_X_133), ((LP) 2)));
v_S14797_135 = ICALL(s_lsp_LDB_2D1) (3, (LP) 32, (LP) 0, t47);
v_T14798_136 = v_BUFFER_126;
v_S_137 = v_BUFFER_126;
v_VALUE_138 = v_S14797_135;
v_S_140 = v_BUFFER_126;
v_N_141 = (LP) 8;
v_VALUE_142 = v_S14797_135;
((LP) (DEREF((v_BUFFER_126) + 4 * 4) = (LD) (v_S14797_135)));
v_S14799_144 = v_BUFFER_2DBOFFSET_37;
v_T14800_145 = v_DISPLAY_13;
v_S_146 = v_DISPLAY_13;
v_VALUE_147 = v_S14799_144;
v_S_149 = v_DISPLAY_13;
v_N_150 = (LP) 10;
v_VALUE_151 = v_S14799_144;
((LP) (DEREF((v_DISPLAY_13) + 5 * 4) = (LD) (v_S14799_144)));
t48 = (add((v_BUFFER_2DBOFFSET_37), ((LP) 40)));
v_S14801_153 = t48;
v_T14802_154 = v_DISPLAY_13;
v_S_155 = v_DISPLAY_13;
v_VALUE_156 = v_S14801_153;
v_S_158 = v_DISPLAY_13;
v_N_159 = (LP) 14;
v_VALUE_160 = v_S14801_153;
((LP) (DEREF((v_DISPLAY_13) + 7 * 4) = (LD) (v_S14801_153)));
}
t49 = ICALL(s_xlib_DISPLAY_2DINVOKE_2DAFTER_2DFUNCTION) (MV_CALL(argc,1), v_DISPLAY_13);
return(t49);
}

LP p_xlib_DRAW_2DLINES(va_alist) va_dcl
{
LP v_VALUE_105; LP v_N_104; LP v_S_103; 
LP v_VALUE_101; LP v_S_100; LP v_T14911_99; 
LP v_S14910_98; LP v_X_96; LP v_I_94; 
LP v_S_93; LP v_S_91; LP v_BUFFER_89; 
LP v_I_87; LP v_A_86; LP v_V_85; 
LP v_T14909_84; LP v_I_82; LP v_A_81; 
LP v_V_80; LP v_I_78; LP v_S_77; 
LP v_S_75; LP v_I_73; LP v_A_72; 
LP v_V_71; LP v_I_69; LP v_S_68; 
LP v_S_66; LP v_T14908_65; LP v_T14907_64; 
LP v_S14906_63; LP v_I_61; LP v_A_60; 
LP v_V_59; LP v_T14905_58; LP v_T14904_57; 
LP v_S14903_56; LP v_I_54; LP v_A_53; 
LP v_V_52; LP v_VALUE_50; LP v_N_49; 
LP v_S_48; LP v_VALUE_46; LP v_S_45; 
LP v_T14902_44; LP v_S14901_43; LP v_BUFFER_2DBBUF_42; 
LP v_I_40; LP v_S_39; LP v_S_37; 
LP v_BUFFER_2DBOFFSET_36; LP v_I_34; LP v_S_33; 
LP v_S_31; LP v_I_29; LP v_S_28; 
LP v_S_26; LP v_I_24; LP v_S_23; 
LP v_S_21; LP v__25BUFFER_20; LP v_MV14900_19; 
LP v_I_17; LP v_S_16; LP v_S_14; 
LP v__2EDISPLAY_2E_13; LP v_I_11; LP v_S_10; 
LP v_S_8; LP v_POINTS_2; LP v_GCONTEXT_1; 
LP v_DRAWABLE_0; LP v_KEYS14889_6; LP v_SHAPE_5; 
LP v_FILL_2DP_4; LP v_RELATIVE_2DP_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_DRAWABLE_0 = NEXT_VAR_ARG;
v_GCONTEXT_1 = NEXT_VAR_ARG;
v_POINTS_2 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 3) wna_low(real_argc,3);
DYNAMIC_RESTIFY(v_KEYS14889_6,4,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_RELATIVE_2DP_3,LREF(s_key_RELATIVE_2DP),v_KEYS14889_6)
v_RELATIVE_2DP_3 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_FILL_2DP_4,LREF(s_key_FILL_2DP),v_KEYS14889_6)
v_FILL_2DP_4 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_SHAPE_5,LREF(s_key_SHAPE),v_KEYS14889_6)
v_SHAPE_5 = LREF(s_key_COMPLEX);
END_KEY_INIT
END_VAR_ARGS;
if (v_FILL_2DP_4 != NIL) {
t0 = ICALL(s_xlib_FILL_2DPOLYGON) (MV_CALL(argc,5), v_DRAWABLE_0, v_GCONTEXT_1, v_POINTS_2, v_RELATIVE_2DP_3, v_SHAPE_5);
return(t0);
} else {
v_S_8 = v_DRAWABLE_0;
v_S_10 = v_DRAWABLE_0;
v_I_11 = (LP) 4;
v__2EDISPLAY_2E_13 = ((LP) DEREF((v_DRAWABLE_0) + 2 * 4));
v_S_14 = v__2EDISPLAY_2E_13;
v_S_16 = v__2EDISPLAY_2E_13;
v_I_17 = (LP) 22;
t1 = ((LP) DEREF((v__2EDISPLAY_2E_13) + 11 * 4));
if (t1 != NIL) {
ICALL(s_lsp_ERROR) (3, LREF(s_xlib_CLOSED_2DDISPLAY), LREF(s_key_DISPLAY), v__2EDISPLAY_2E_13);
}
ICALL(s_xlib_FORCE_2DGCONTEXT_2DCHANGES_2DINTERNAL) (1, v_GCONTEXT_1);
{
int real_argc;
BEGIN_MV_CALL(mv_holder5792,0);
v__25BUFFER_20 = v__2EDISPLAY_2E_13;
v_S_21 = v__25BUFFER_20;
v_S_23 = v__25BUFFER_20;
v_I_24 = (LP) 14;
t4 = ((LP) DEREF((v__25BUFFER_20) + 7 * 4));
t3 = (add((t4), ((LP) 320)));
v_S_26 = v__25BUFFER_20;
v_S_28 = v__25BUFFER_20;
v_I_29 = (LP) 6;
t5 = ((LP) DEREF((v__25BUFFER_20) + 3 * 4));
if (((int) (t3) >= (int) (t5))) {
ICALL(s_xlib_BUFFER_2DFLUSH) (1, v__25BUFFER_20);
}
v_S_31 = v__25BUFFER_20;
v_S_33 = v__25BUFFER_20;
v_I_34 = (LP) 14;
v_BUFFER_2DBOFFSET_36 = ((LP) DEREF((v__25BUFFER_20) + 7 * 4));
v_S_37 = v__25BUFFER_20;
v_S_39 = v__25BUFFER_20;
v_I_40 = (LP) 16;
v_BUFFER_2DBBUF_42 = ((LP) DEREF((v__25BUFFER_20) + 8 * 4));
v_S14901_43 = v_BUFFER_2DBOFFSET_36;
v_T14902_44 = v__2EDISPLAY_2E_13;
v_S_45 = v__2EDISPLAY_2E_13;
v_VALUE_46 = v_BUFFER_2DBOFFSET_36;
v_S_48 = v__2EDISPLAY_2E_13;
v_N_49 = (LP) 10;
v_VALUE_50 = v_BUFFER_2DBOFFSET_36;
((LP) (DEREF((v__2EDISPLAY_2E_13) + 5 * 4) = (LD) (v_BUFFER_2DBOFFSET_36)));
t6 = (add((v_BUFFER_2DBOFFSET_36), ((LP) 0)));
v_I_54 = t6;
v_S14903_56 = (LP) 130;
v_T14904_57 = v_BUFFER_2DBBUF_42;
v_T14905_58 = v_I_54;
((unsigned char (*)) (v_BUFFER_2DBBUF_42 - 1))[FX_TO_INT(v_I_54)] = (unsigned char)FX_TO_INT((LP) 130);
if (v_RELATIVE_2DP_3 != NIL) {
v_V_59 = (LP) 2;
} else {
v_V_59 = (LP) 0;
}
t7 = (add((v_BUFFER_2DBOFFSET_36), ((LP) 2)));
v_I_61 = t7;
v_S14906_63 = v_V_59;
v_T14907_64 = v_BUFFER_2DBBUF_42;
v_T14908_65 = v_I_61;
((unsigned char (*)) (v_BUFFER_2DBBUF_42 - 1))[FX_TO_INT(v_I_61)] = (unsigned char)FX_TO_INT(v_V_59);
v_S_66 = v_DRAWABLE_0;
v_S_68 = v_DRAWABLE_0;
v_I_69 = (LP) 2;
v_V_71 = ((LP) DEREF((v_DRAWABLE_0) + 1 * 4));
t8 = (add((v_BUFFER_2DBOFFSET_36), ((LP) 8)));
v_I_73 = t8;
t9 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_73)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_42) - 1)) + FX_TO_INT(t9))) = (unsigned long) FX_TO_INT(v_V_71)));
v_S_75 = v_GCONTEXT_1;
v_S_77 = v_GCONTEXT_1;
v_I_78 = (LP) 2;
v_V_80 = ((LP) DEREF((v_GCONTEXT_1) + 1 * 4));
t10 = (add((v_BUFFER_2DBOFFSET_36), ((LP) 16)));
v_I_82 = t10;
t11 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_82)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_42) - 1)) + FX_TO_INT(t11))) = (unsigned long) FX_TO_INT(v_V_80)));
v_T14909_84 = ICALL(s_lsp_LENGTH) (1, v_POINTS_2);
t14 = (subtract((v_T14909_84), ((LP) 0)));
t13 = ICALL(s_lsp_CEILING) (2, t14, (LP) 4);
t12 = (add((t13), ((LP) 6)));
v_V_85 = t12;
t15 = (add((v_BUFFER_2DBOFFSET_36), ((LP) 4)));
v_I_87 = t15;
t16 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_87)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_42) - 1))+FX_TO_INT(t16))) = (unsigned short) FX_TO_INT(v_V_85)));
t17 = (add((v_BUFFER_2DBOFFSET_36), ((LP) 24)));
ICALL(s_xlib_WRITE_2DSEQUENCE_2DINT16) (6, v__25BUFFER_20, t17, v_POINTS_2, (LP) 0, v_T14909_84, LREF(s_lsp_NIL));
v_BUFFER_89 = v__2EDISPLAY_2E_13;
v_S_91 = v_BUFFER_89;
v_S_93 = v_BUFFER_89;
v_I_94 = (LP) 8;
v_X_96 = ((LP) DEREF((v_BUFFER_89) + 4 * 4));
t18 = (add((v_X_96), ((LP) 2)));
v_S14910_98 = ICALL(s_lsp_LDB_2D1) (3, (LP) 32, (LP) 0, t18);
v_T14911_99 = v_BUFFER_89;
v_S_100 = v_BUFFER_89;
v_VALUE_101 = v_S14910_98;
v_S_103 = v_BUFFER_89;
v_N_104 = (LP) 8;
v_VALUE_105 = v_S14910_98;
t19 = ((LP) (DEREF((v_BUFFER_89) + 4 * 4) = (LD) (v_S14910_98)));
SET_MV_RETURN_VALUE(mv_holder5792,0,t19);
if SV_RETURN_P(mv_holder5792) SET_MV_RETURN_COUNT(mv_holder5792,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder5792);
BEGIN_VAR_VALUES;
RESTIFY(v_MV14900_19,1,NEXT_VAR_VALUE(mv_holder5792));
END_VAR_VALUES;
END_MV_CALL;
ICALL(s_xlib_DISPLAY_2DINVOKE_2DAFTER_2DFUNCTION) (1, v__2EDISPLAY_2E_13);
t0 = ICALL(s_lsp_VALUES_2DLIST) (MV_CALL(argc,1), v_MV14900_19);
return(t0);
}
}
}

LP p_xlib_FILL_2DPOLYGON(argc, v_DRAWABLE_0, v_GCONTEXT_1, v_POINTS_2, v_RELATIVE_2DP_3, v_SHAPE_4)
      ARGC argc;  LP v_DRAWABLE_0; LP v_GCONTEXT_1; LP v_POINTS_2; LP v_RELATIVE_2DP_3; LP v_SHAPE_4;
{
LP v_VALUE_112; LP v_N_111; LP v_S_110; 
LP v_VALUE_108; LP v_S_107; LP v_T14936_106; 
LP v_S14935_105; LP v_X_103; LP v_I_101; 
LP v_S_100; LP v_S_98; LP v_BUFFER_96; 
LP v_I_94; LP v_A_93; LP v_V_92; 
LP v_T14934_91; LP v_T14933_90; LP v_T14932_89; 
LP v_S14931_88; LP v_I_86; LP v_A_85; 
LP v_V_84; LP v_T14930_83; LP v_T14929_82; 
LP v_S14928_81; LP v_I_79; LP v_A_78; 
LP v_V_77; LP v_X_75; LP v_I_73; 
LP v_A_72; LP v_V_71; LP v_I_69; 
LP v_S_68; LP v_S_66; LP v_I_64; 
LP v_A_63; LP v_V_62; LP v_I_60; 
LP v_S_59; LP v_S_57; LP v_T14927_56; 
LP v_T14926_55; LP v_S14925_54; LP v_I_52; 
LP v_A_51; LP v_V_50; LP v_VALUE_48; 
LP v_N_47; LP v_S_46; LP v_VALUE_44; 
LP v_S_43; LP v_T14924_42; LP v_S14923_41; 
LP v_BUFFER_2DBBUF_40; LP v_I_38; LP v_S_37; 
LP v_S_35; LP v_BUFFER_2DBOFFSET_34; LP v_I_32; 
LP v_S_31; LP v_S_29; LP v_I_27; 
LP v_S_26; LP v_S_24; LP v_I_22; 
LP v_S_21; LP v_S_19; LP v__25BUFFER_18; 
LP v_MV14922_17; LP v_I_15; LP v_S_14; 
LP v_S_12; LP v__2EDISPLAY_2E_11; LP v_I_9; 
LP v_S_8; LP v_S_6; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; 
if (argc != 5) wna(argc,5);
v_S_6 = v_DRAWABLE_0;
v_S_8 = v_DRAWABLE_0;
v_I_9 = (LP) 4;
v__2EDISPLAY_2E_11 = ((LP) DEREF((v_DRAWABLE_0) + 2 * 4));
v_S_12 = v__2EDISPLAY_2E_11;
v_S_14 = v__2EDISPLAY_2E_11;
v_I_15 = (LP) 22;
t0 = ((LP) DEREF((v__2EDISPLAY_2E_11) + 11 * 4));
if (t0 != NIL) {
ICALL(s_lsp_ERROR) (3, LREF(s_xlib_CLOSED_2DDISPLAY), LREF(s_key_DISPLAY), v__2EDISPLAY_2E_11);
}
ICALL(s_xlib_FORCE_2DGCONTEXT_2DCHANGES_2DINTERNAL) (1, v_GCONTEXT_1);
{
int real_argc;
BEGIN_MV_CALL(mv_holder5793,0);
v__25BUFFER_18 = v__2EDISPLAY_2E_11;
v_S_19 = v__25BUFFER_18;
v_S_21 = v__25BUFFER_18;
v_I_22 = (LP) 14;
t3 = ((LP) DEREF((v__25BUFFER_18) + 7 * 4));
t2 = (add((t3), ((LP) 320)));
v_S_24 = v__25BUFFER_18;
v_S_26 = v__25BUFFER_18;
v_I_27 = (LP) 6;
t4 = ((LP) DEREF((v__25BUFFER_18) + 3 * 4));
if (((int) (t2) >= (int) (t4))) {
ICALL(s_xlib_BUFFER_2DFLUSH) (1, v__25BUFFER_18);
}
v_S_29 = v__25BUFFER_18;
v_S_31 = v__25BUFFER_18;
v_I_32 = (LP) 14;
v_BUFFER_2DBOFFSET_34 = ((LP) DEREF((v__25BUFFER_18) + 7 * 4));
v_S_35 = v__25BUFFER_18;
v_S_37 = v__25BUFFER_18;
v_I_38 = (LP) 16;
v_BUFFER_2DBBUF_40 = ((LP) DEREF((v__25BUFFER_18) + 8 * 4));
v_S14923_41 = v_BUFFER_2DBOFFSET_34;
v_T14924_42 = v__2EDISPLAY_2E_11;
v_S_43 = v__2EDISPLAY_2E_11;
v_VALUE_44 = v_BUFFER_2DBOFFSET_34;
v_S_46 = v__2EDISPLAY_2E_11;
v_N_47 = (LP) 10;
v_VALUE_48 = v_BUFFER_2DBOFFSET_34;
((LP) (DEREF((v__2EDISPLAY_2E_11) + 5 * 4) = (LD) (v_BUFFER_2DBOFFSET_34)));
t5 = (add((v_BUFFER_2DBOFFSET_34), ((LP) 0)));
v_I_52 = t5;
v_S14925_54 = (LP) 138;
v_T14926_55 = v_BUFFER_2DBBUF_40;
v_T14927_56 = v_I_52;
((unsigned char (*)) (v_BUFFER_2DBBUF_40 - 1))[FX_TO_INT(v_I_52)] = (unsigned char)FX_TO_INT((LP) 138);
v_S_57 = v_DRAWABLE_0;
v_S_59 = v_DRAWABLE_0;
v_I_60 = (LP) 2;
v_V_62 = ((LP) DEREF((v_DRAWABLE_0) + 1 * 4));
t6 = (add((v_BUFFER_2DBOFFSET_34), ((LP) 8)));
v_I_64 = t6;
t7 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_64)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_40) - 1)) + FX_TO_INT(t7))) = (unsigned long) FX_TO_INT(v_V_62)));
v_S_66 = v_GCONTEXT_1;
v_S_68 = v_GCONTEXT_1;
v_I_69 = (LP) 2;
v_V_71 = ((LP) DEREF((v_GCONTEXT_1) + 1 * 4));
t8 = (add((v_BUFFER_2DBOFFSET_34), ((LP) 16)));
v_I_73 = t8;
t9 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_73)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_40) - 1)) + FX_TO_INT(t9))) = (unsigned long) FX_TO_INT(v_V_71)));
v_X_75 = LREF(s_lsp_EQ);
t10 = ((LP) DEREF((LREF(s_lsp_EQ)) + 4 * 4));
v_V_77 = ICALL(s_lsp_POSITION) (4, v_SHAPE_4, LREF(k5794), LREF(s_key_TEST), t10);
t11 = (add((v_BUFFER_2DBOFFSET_34), ((LP) 24)));
v_I_79 = t11;
v_S14928_81 = v_V_77;
v_T14929_82 = v_BUFFER_2DBBUF_40;
v_T14930_83 = v_I_79;
((unsigned char (*)) (v_BUFFER_2DBBUF_40 - 1))[FX_TO_INT(v_I_79)] = (unsigned char)FX_TO_INT(v_V_77);
if (v_RELATIVE_2DP_3 != NIL) {
v_V_84 = (LP) 2;
} else {
v_V_84 = (LP) 0;
}
t12 = (add((v_BUFFER_2DBOFFSET_34), ((LP) 26)));
v_I_86 = t12;
v_S14931_88 = v_V_84;
v_T14932_89 = v_BUFFER_2DBBUF_40;
v_T14933_90 = v_I_86;
((unsigned char (*)) (v_BUFFER_2DBBUF_40 - 1))[FX_TO_INT(v_I_86)] = (unsigned char)FX_TO_INT(v_V_84);
v_T14934_91 = ICALL(s_lsp_LENGTH) (1, v_POINTS_2);
t15 = (subtract((v_T14934_91), ((LP) 0)));
t14 = ICALL(s_lsp_CEILING) (2, t15, (LP) 4);
t13 = (add((t14), ((LP) 8)));
v_V_92 = t13;
t16 = (add((v_BUFFER_2DBOFFSET_34), ((LP) 4)));
v_I_94 = t16;
t17 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_94)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_40) - 1))+FX_TO_INT(t17))) = (unsigned short) FX_TO_INT(v_V_92)));
t18 = (add((v_BUFFER_2DBOFFSET_34), ((LP) 32)));
ICALL(s_xlib_WRITE_2DSEQUENCE_2DINT16) (6, v__25BUFFER_18, t18, v_POINTS_2, (LP) 0, v_T14934_91, LREF(s_lsp_NIL));
v_BUFFER_96 = v__2EDISPLAY_2E_11;
v_S_98 = v_BUFFER_96;
v_S_100 = v_BUFFER_96;
v_I_101 = (LP) 8;
v_X_103 = ((LP) DEREF((v_BUFFER_96) + 4 * 4));
t19 = (add((v_X_103), ((LP) 2)));
v_S14935_105 = ICALL(s_lsp_LDB_2D1) (3, (LP) 32, (LP) 0, t19);
v_T14936_106 = v_BUFFER_96;
v_S_107 = v_BUFFER_96;
v_VALUE_108 = v_S14935_105;
v_S_110 = v_BUFFER_96;
v_N_111 = (LP) 8;
v_VALUE_112 = v_S14935_105;
t20 = ((LP) (DEREF((v_BUFFER_96) + 4 * 4) = (LD) (v_S14935_105)));
SET_MV_RETURN_VALUE(mv_holder5793,0,t20);
if SV_RETURN_P(mv_holder5793) SET_MV_RETURN_COUNT(mv_holder5793,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder5793);
BEGIN_VAR_VALUES;
RESTIFY(v_MV14922_17,1,NEXT_VAR_VALUE(mv_holder5793));
END_VAR_VALUES;
END_MV_CALL;
ICALL(s_xlib_DISPLAY_2DINVOKE_2DAFTER_2DFUNCTION) (1, v__2EDISPLAY_2E_11);
t21 = ICALL(s_lsp_VALUES_2DLIST) (MV_CALL(argc,1), v_MV14922_17);
return(t21);
}
}

LP p_xlib_DRAW_2DSEGMENTS(argc, v_DRAWABLE_0, v_GCONTEXT_1, v_SEGMENTS_2)
      ARGC argc;  LP v_DRAWABLE_0; LP v_GCONTEXT_1; LP v_SEGMENTS_2;
{
LP v_VALUE_94; LP v_N_93; LP v_S_92; 
LP v_VALUE_90; LP v_S_89; LP v_T14955_88; 
LP v_S14954_87; LP v_X_85; LP v_I_83; 
LP v_S_82; LP v_S_80; LP v_BUFFER_78; 
LP v_I_76; LP v_A_75; LP v_V_74; 
LP v_T14953_73; LP v_I_71; LP v_A_70; 
LP v_V_69; LP v_I_67; LP v_S_66; 
LP v_S_64; LP v_I_62; LP v_A_61; 
LP v_V_60; LP v_I_58; LP v_S_57; 
LP v_S_55; LP v_T14952_54; LP v_T14951_53; 
LP v_S14950_52; LP v_I_50; LP v_A_49; 
LP v_V_48; LP v_VALUE_46; LP v_N_45; 
LP v_S_44; LP v_VALUE_42; LP v_S_41; 
LP v_T14949_40; LP v_S14948_39; LP v_BUFFER_2DBBUF_38; 
LP v_I_36; LP v_S_35; LP v_S_33; 
LP v_BUFFER_2DBOFFSET_32; LP v_I_30; LP v_S_29; 
LP v_S_27; LP v_I_25; LP v_S_24; 
LP v_S_22; LP v_I_20; LP v_S_19; 
LP v_S_17; LP v__25BUFFER_16; LP v_MV14947_15; 
LP v_I_13; LP v_S_12; LP v_S_10; 
LP v__2EDISPLAY_2E_9; LP v_I_7; LP v_S_6; 
LP v_S_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; 
if (argc != 3) wna(argc,3);
v_S_4 = v_DRAWABLE_0;
v_S_6 = v_DRAWABLE_0;
v_I_7 = (LP) 4;
v__2EDISPLAY_2E_9 = ((LP) DEREF((v_DRAWABLE_0) + 2 * 4));
v_S_10 = v__2EDISPLAY_2E_9;
v_S_12 = v__2EDISPLAY_2E_9;
v_I_13 = (LP) 22;
t0 = ((LP) DEREF((v__2EDISPLAY_2E_9) + 11 * 4));
if (t0 != NIL) {
ICALL(s_lsp_ERROR) (3, LREF(s_xlib_CLOSED_2DDISPLAY), LREF(s_key_DISPLAY), v__2EDISPLAY_2E_9);
}
ICALL(s_xlib_FORCE_2DGCONTEXT_2DCHANGES_2DINTERNAL) (1, v_GCONTEXT_1);
{
int real_argc;
BEGIN_MV_CALL(mv_holder5795,0);
v__25BUFFER_16 = v__2EDISPLAY_2E_9;
v_S_17 = v__25BUFFER_16;
v_S_19 = v__25BUFFER_16;
v_I_20 = (LP) 14;
t3 = ((LP) DEREF((v__25BUFFER_16) + 7 * 4));
t2 = (add((t3), ((LP) 320)));
v_S_22 = v__25BUFFER_16;
v_S_24 = v__25BUFFER_16;
v_I_25 = (LP) 6;
t4 = ((LP) DEREF((v__25BUFFER_16) + 3 * 4));
if (((int) (t2) >= (int) (t4))) {
ICALL(s_xlib_BUFFER_2DFLUSH) (1, v__25BUFFER_16);
}
v_S_27 = v__25BUFFER_16;
v_S_29 = v__25BUFFER_16;
v_I_30 = (LP) 14;
v_BUFFER_2DBOFFSET_32 = ((LP) DEREF((v__25BUFFER_16) + 7 * 4));
v_S_33 = v__25BUFFER_16;
v_S_35 = v__25BUFFER_16;
v_I_36 = (LP) 16;
v_BUFFER_2DBBUF_38 = ((LP) DEREF((v__25BUFFER_16) + 8 * 4));
v_S14948_39 = v_BUFFER_2DBOFFSET_32;
v_T14949_40 = v__2EDISPLAY_2E_9;
v_S_41 = v__2EDISPLAY_2E_9;
v_VALUE_42 = v_BUFFER_2DBOFFSET_32;
v_S_44 = v__2EDISPLAY_2E_9;
v_N_45 = (LP) 10;
v_VALUE_46 = v_BUFFER_2DBOFFSET_32;
((LP) (DEREF((v__2EDISPLAY_2E_9) + 5 * 4) = (LD) (v_BUFFER_2DBOFFSET_32)));
t5 = (add((v_BUFFER_2DBOFFSET_32), ((LP) 0)));
v_I_50 = t5;
v_S14950_52 = (LP) 132;
v_T14951_53 = v_BUFFER_2DBBUF_38;
v_T14952_54 = v_I_50;
((unsigned char (*)) (v_BUFFER_2DBBUF_38 - 1))[FX_TO_INT(v_I_50)] = (unsigned char)FX_TO_INT((LP) 132);
v_S_55 = v_DRAWABLE_0;
v_S_57 = v_DRAWABLE_0;
v_I_58 = (LP) 2;
v_V_60 = ((LP) DEREF((v_DRAWABLE_0) + 1 * 4));
t6 = (add((v_BUFFER_2DBOFFSET_32), ((LP) 8)));
v_I_62 = t6;
t7 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_62)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_38) - 1)) + FX_TO_INT(t7))) = (unsigned long) FX_TO_INT(v_V_60)));
v_S_64 = v_GCONTEXT_1;
v_S_66 = v_GCONTEXT_1;
v_I_67 = (LP) 2;
v_V_69 = ((LP) DEREF((v_GCONTEXT_1) + 1 * 4));
t8 = (add((v_BUFFER_2DBOFFSET_32), ((LP) 16)));
v_I_71 = t8;
t9 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_71)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_38) - 1)) + FX_TO_INT(t9))) = (unsigned long) FX_TO_INT(v_V_69)));
v_T14953_73 = ICALL(s_lsp_LENGTH) (1, v_SEGMENTS_2);
t12 = (subtract((v_T14953_73), ((LP) 0)));
t11 = ICALL(s_lsp_CEILING) (2, t12, (LP) 4);
t10 = (add((t11), ((LP) 6)));
v_V_74 = t10;
t13 = (add((v_BUFFER_2DBOFFSET_32), ((LP) 4)));
v_I_76 = t13;
t14 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_76)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_38) - 1))+FX_TO_INT(t14))) = (unsigned short) FX_TO_INT(v_V_74)));
t15 = (add((v_BUFFER_2DBOFFSET_32), ((LP) 24)));
ICALL(s_xlib_WRITE_2DSEQUENCE_2DINT16) (6, v__25BUFFER_16, t15, v_SEGMENTS_2, (LP) 0, v_T14953_73, LREF(s_lsp_NIL));
v_BUFFER_78 = v__2EDISPLAY_2E_9;
v_S_80 = v_BUFFER_78;
v_S_82 = v_BUFFER_78;
v_I_83 = (LP) 8;
v_X_85 = ((LP) DEREF((v_BUFFER_78) + 4 * 4));
t16 = (add((v_X_85), ((LP) 2)));
v_S14954_87 = ICALL(s_lsp_LDB_2D1) (3, (LP) 32, (LP) 0, t16);
v_T14955_88 = v_BUFFER_78;
v_S_89 = v_BUFFER_78;
v_VALUE_90 = v_S14954_87;
v_S_92 = v_BUFFER_78;
v_N_93 = (LP) 8;
v_VALUE_94 = v_S14954_87;
t17 = ((LP) (DEREF((v_BUFFER_78) + 4 * 4) = (LD) (v_S14954_87)));
SET_MV_RETURN_VALUE(mv_holder5795,0,t17);
if SV_RETURN_P(mv_holder5795) SET_MV_RETURN_COUNT(mv_holder5795,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder5795);
BEGIN_VAR_VALUES;
RESTIFY(v_MV14947_15,1,NEXT_VAR_VALUE(mv_holder5795));
END_VAR_VALUES;
END_MV_CALL;
ICALL(s_xlib_DISPLAY_2DINVOKE_2DAFTER_2DFUNCTION) (1, v__2EDISPLAY_2E_9);
t18 = ICALL(s_lsp_VALUES_2DLIST) (MV_CALL(argc,1), v_MV14947_15);
return(t18);
}
}

LP p_xlib_DRAW_2DRECTANGLE(va_alist) va_dcl
{
LP v_SYMBOL_183; LP v_I_181; LP v_A_180; 
LP v__2EBOFFSET_2E_179; LP v_G14977_178; LP v_I_176; 
LP v_A_175; LP v_I_173; LP v_S_172; 
LP v_S_170; LP v_I_168; LP v_A_167; 
LP v_I_165; LP v_S_164; LP v_S_162; 
LP v__2EBOFFSET_2E_161; LP v_VALUE_159; LP v_N_158; 
LP v_S_157; LP v_VALUE_155; LP v_S_154; 
LP v_T14976_153; LP v_S14975_152; LP v_VALUE_150; 
LP v_N_149; LP v_S_148; LP v_VALUE_146; 
LP v_S_145; LP v_T14974_144; LP v_S14973_143; 
LP v_VALUE_141; LP v_N_140; LP v_S_139; 
LP v_VALUE_137; LP v_S_136; LP v_T14972_135; 
LP v_S14971_134; LP v_X_132; LP v_I_130; 
LP v_S_129; LP v_S_127; LP v_BUFFER_125; 
LP v_I_123; LP v_A_122; LP v_V_121; 
LP v_I_119; LP v_A_118; LP v_V_117; 
LP v_I_115; LP v_A_114; LP v_V_113; 
LP v_I_111; LP v_A_110; LP v_V_109; 
LP v_I_107; LP v_A_106; LP v_V_105; 
LP v_I_103; LP v_S_102; LP v_S_100; 
LP v_I_98; LP v_A_97; LP v_V_96; 
LP v_I_94; LP v_S_93; LP v_S_91; 
LP v_I_89; LP v_A_88; LP v_V_87; 
LP v_T14970_86; LP v_T14969_85; LP v_S14968_84; 
LP v_I_82; LP v_A_81; LP v_V_80; 
LP v_VALUE_78; LP v_N_77; LP v_S_76; 
LP v_VALUE_74; LP v_S_73; LP v_T14967_72; 
LP v_S14966_71; LP v_I_69; LP v_A_68; 
LP v_V_67; LP v_I_65; LP v_A_64; 
LP v_V_63; LP v_I_61; LP v_A_60; 
LP v_V_59; LP v_I_57; LP v_A_56; 
LP v_V_55; LP v__2EBOFFSET_2E_54; LP v_I_52; 
LP v_A_51; LP v_V_50; LP v_CURRENT_2DBOFFSET_49; 
LP v_LAST_2DREQUEST_2DBYTE_48; LP v_I_46; LP v_S_45; 
LP v_S_43; LP v_BUFFER_2DBBUF_42; LP v_I_40; 
LP v_S_39; LP v_S_37; LP v_BUFFER_2DBOFFSET_36; 
LP v_I_34; LP v_S_33; LP v_S_31; 
LP v_I_29; LP v_S_28; LP v_S_26; 
LP v_I_24; LP v_S_23; LP v_S_21; 
LP v__25BUFFER_20; LP v_I_18; LP v_S_17; 
LP v_S_15; LP v_REQUEST_14; LP v_DISPLAY_13; 
LP v_I_11; LP v_S_10; LP v_S_8; 
LP v_HEIGHT_5; LP v_WIDTH_4; LP v_Y_3; 
LP v_X_2; LP v_GCONTEXT_1; LP v_DRAWABLE_0; 
LP v_FILL_2DP_6; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 

int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_DRAWABLE_0 = NEXT_VAR_ARG;
v_GCONTEXT_1 = NEXT_VAR_ARG;
v_X_2 = NEXT_VAR_ARG;
v_Y_3 = NEXT_VAR_ARG;
v_WIDTH_4 = NEXT_VAR_ARG;
v_HEIGHT_5 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 6) wna_low(real_argc,6);
if (real_argc > 7) wna_high(real_argc,7);
if (real_argc < 7) {
v_FILL_2DP_6 = NIL;
} else {
v_FILL_2DP_6 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
v_S_8 = v_DRAWABLE_0;
v_S_10 = v_DRAWABLE_0;
v_I_11 = (LP) 4;
v_DISPLAY_13 = ((LP) DEREF((v_DRAWABLE_0) + 2 * 4));
if (v_FILL_2DP_6 != NIL) {
v_REQUEST_14 = (LP) 140;
} else {
v_REQUEST_14 = (LP) 134;
}
v_S_15 = v_DISPLAY_13;
v_S_17 = v_DISPLAY_13;
v_I_18 = (LP) 22;
t0 = ((LP) DEREF((v_DISPLAY_13) + 11 * 4));
if (t0 != NIL) {
ICALL(s_lsp_ERROR) (3, LREF(s_xlib_CLOSED_2DDISPLAY), LREF(s_key_DISPLAY), v_DISPLAY_13);
}
ICALL(s_xlib_FORCE_2DGCONTEXT_2DCHANGES_2DINTERNAL) (1, v_GCONTEXT_1);
v__25BUFFER_20 = v_DISPLAY_13;
v_S_21 = v__25BUFFER_20;
v_S_23 = v__25BUFFER_20;
v_I_24 = (LP) 14;
t3 = ((LP) DEREF((v__25BUFFER_20) + 7 * 4));
t2 = (add((t3), ((LP) 320)));
v_S_26 = v__25BUFFER_20;
v_S_28 = v__25BUFFER_20;
v_I_29 = (LP) 6;
t4 = ((LP) DEREF((v__25BUFFER_20) + 3 * 4));
if (((int) (t2) >= (int) (t4))) {
ICALL(s_xlib_BUFFER_2DFLUSH) (1, v__25BUFFER_20);
}
v_S_31 = v__25BUFFER_20;
v_S_33 = v__25BUFFER_20;
v_I_34 = (LP) 14;
v_BUFFER_2DBOFFSET_36 = ((LP) DEREF((v__25BUFFER_20) + 7 * 4));
v_S_37 = v__25BUFFER_20;
v_S_39 = v__25BUFFER_20;
v_I_40 = (LP) 16;
v_BUFFER_2DBBUF_42 = ((LP) DEREF((v__25BUFFER_20) + 8 * 4));
v_S_43 = v_DISPLAY_13;
v_S_45 = v_DISPLAY_13;
v_I_46 = (LP) 10;
v_LAST_2DREQUEST_2DBYTE_48 = ((LP) DEREF((v_DISPLAY_13) + 5 * 4));
v_CURRENT_2DBOFFSET_49 = v_BUFFER_2DBOFFSET_36;
v_SYMBOL_183 = LREF(s_xlib__2AINHIBIT_2DAPPENDING_2A);
t6 = ((LP) DEREF((LREF(s_xlib__2AINHIBIT_2DAPPENDING_2A)) + 0 * 4));
if (t6 != NIL) {
t5 = LREF(s_lsp_NIL);
} else {
if (v_LAST_2DREQUEST_2DBYTE_48 != NIL) {
v_A_180 = v_BUFFER_2DBBUF_42;
v_I_181 = v_LAST_2DREQUEST_2DBYTE_48;
t8 = (LP) INT_TO_FX(((unsigned char (*)) (v_BUFFER_2DBBUF_42 - 1))[FX_TO_INT(v_LAST_2DREQUEST_2DBYTE_48)]);
t7 = (num_equal_p((t8), (v_REQUEST_14)));
if (t7 != NIL) {
v__2EBOFFSET_2E_161 = v_LAST_2DREQUEST_2DBYTE_48;
v_BUFFER_2DBOFFSET_36 = v_LAST_2DREQUEST_2DBYTE_48;
v_S_170 = v_DRAWABLE_0;
v_S_172 = v_DRAWABLE_0;
v_I_173 = (LP) 2;
t10 = ((LP) DEREF((v_DRAWABLE_0) + 1 * 4));
t11 = (add((v_BUFFER_2DBOFFSET_36), ((LP) 8)));
v_I_176 = t11;
t13 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_176)) >> (2)));
t12 = INT_TO_FX((LP) (*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_42) - 1)) + FX_TO_INT(t13))));
t9 = (num_equal_p((t10), (t12)));
if (t9 != NIL) {
v_S_162 = v_GCONTEXT_1;
v_S_164 = v_GCONTEXT_1;
v_I_165 = (LP) 2;
t14 = ((LP) DEREF((v_GCONTEXT_1) + 1 * 4));
t15 = (add((v_BUFFER_2DBOFFSET_36), ((LP) 16)));
v_I_168 = t15;
t17 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_168)) >> (2)));
t16 = INT_TO_FX((LP) (*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_42) - 1)) + FX_TO_INT(t17))));
v_G14977_178 = (num_equal_p((t14), (t16)));
} else {
v_G14977_178 = LREF(s_lsp_NIL);
}
if (v_G14977_178 != NIL) {
t5 = v_G14977_178;
} else {
v__2EBOFFSET_2E_179 = v_CURRENT_2DBOFFSET_49;
v_BUFFER_2DBOFFSET_36 = v_CURRENT_2DBOFFSET_49;
t5 = LREF(s_lsp_NIL);
}
} else {
t5 = LREF(s_lsp_NIL);
}
} else {
t5 = LREF(s_lsp_NIL);
}
}
if (t5 != NIL) {
t20 = (subtract((v_CURRENT_2DBOFFSET_49), (v_LAST_2DREQUEST_2DBYTE_48)));
t19 = ICALL(s_lsp_ASH) (2, t20, (LP) -4);
t18 = (add(((LP) 4), (t19)));
v_V_50 = t18;
t21 = (add((v_BUFFER_2DBOFFSET_36), ((LP) 4)));
v_I_52 = t21;
t22 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_52)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_42) - 1))+FX_TO_INT(t22))) = (unsigned short) FX_TO_INT(v_V_50)));
v__2EBOFFSET_2E_54 = v_CURRENT_2DBOFFSET_49;
v_BUFFER_2DBOFFSET_36 = v_CURRENT_2DBOFFSET_49;
v_V_55 = v_X_2;
t23 = (add((v_BUFFER_2DBOFFSET_36), ((LP) 0)));
v_I_57 = t23;
t24 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_57)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_42) - 1)) + FX_TO_INT(t24))) = (short) FX_TO_INT(v_V_55)));
v_V_59 = v_Y_3;
t25 = (add((v_BUFFER_2DBOFFSET_36), ((LP) 4)));
v_I_61 = t25;
t26 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_61)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_42) - 1)) + FX_TO_INT(t26))) = (short) FX_TO_INT(v_V_59)));
v_V_63 = v_WIDTH_4;
t27 = (add((v_BUFFER_2DBOFFSET_36), ((LP) 8)));
v_I_65 = t27;
t28 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_65)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_42) - 1))+FX_TO_INT(t28))) = (unsigned short) FX_TO_INT(v_V_63)));
v_V_67 = v_HEIGHT_5;
t29 = (add((v_BUFFER_2DBOFFSET_36), ((LP) 12)));
v_I_69 = t29;
t30 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_69)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_42) - 1))+FX_TO_INT(t30))) = (unsigned short) FX_TO_INT(v_V_67)));
t31 = (add((v_BUFFER_2DBOFFSET_36), ((LP) 16)));
v_S14966_71 = t31;
v_T14967_72 = v_DISPLAY_13;
v_S_73 = v_DISPLAY_13;
v_VALUE_74 = v_S14966_71;
v_S_76 = v_DISPLAY_13;
v_N_77 = (LP) 14;
v_VALUE_78 = v_S14966_71;
((LP) (DEREF((v_DISPLAY_13) + 7 * 4) = (LD) (v_S14966_71)));
} else {
t32 = (add((v_BUFFER_2DBOFFSET_36), ((LP) 0)));
v_I_82 = t32;
v_S14968_84 = v_REQUEST_14;
v_T14969_85 = v_BUFFER_2DBBUF_42;
v_T14970_86 = v_I_82;
((unsigned char (*)) (v_BUFFER_2DBBUF_42 - 1))[FX_TO_INT(v_I_82)] = (unsigned char)FX_TO_INT(v_REQUEST_14);
v_V_87 = (LP) 10;
t33 = (add((v_BUFFER_2DBOFFSET_36), ((LP) 4)));
v_I_89 = t33;
t34 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_89)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_42) - 1))+FX_TO_INT(t34))) = (unsigned short) FX_TO_INT(v_V_87)));
v_S_91 = v_DRAWABLE_0;
v_S_93 = v_DRAWABLE_0;
v_I_94 = (LP) 2;
v_V_96 = ((LP) DEREF((v_DRAWABLE_0) + 1 * 4));
t35 = (add((v_BUFFER_2DBOFFSET_36), ((LP) 8)));
v_I_98 = t35;
t36 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_98)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_42) - 1)) + FX_TO_INT(t36))) = (unsigned long) FX_TO_INT(v_V_96)));
v_S_100 = v_GCONTEXT_1;
v_S_102 = v_GCONTEXT_1;
v_I_103 = (LP) 2;
v_V_105 = ((LP) DEREF((v_GCONTEXT_1) + 1 * 4));
t37 = (add((v_BUFFER_2DBOFFSET_36), ((LP) 16)));
v_I_107 = t37;
t38 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_107)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_42) - 1)) + FX_TO_INT(t38))) = (unsigned long) FX_TO_INT(v_V_105)));
v_V_109 = v_X_2;
t39 = (add((v_BUFFER_2DBOFFSET_36), ((LP) 24)));
v_I_111 = t39;
t40 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_111)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_42) - 1)) + FX_TO_INT(t40))) = (short) FX_TO_INT(v_V_109)));
v_V_113 = v_Y_3;
t41 = (add((v_BUFFER_2DBOFFSET_36), ((LP) 28)));
v_I_115 = t41;
t42 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_115)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_42) - 1)) + FX_TO_INT(t42))) = (short) FX_TO_INT(v_V_113)));
v_V_117 = v_WIDTH_4;
t43 = (add((v_BUFFER_2DBOFFSET_36), ((LP) 32)));
v_I_119 = t43;
t44 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_119)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_42) - 1))+FX_TO_INT(t44))) = (unsigned short) FX_TO_INT(v_V_117)));
v_V_121 = v_HEIGHT_5;
t45 = (add((v_BUFFER_2DBOFFSET_36), ((LP) 36)));
v_I_123 = t45;
t46 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_123)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_42) - 1))+FX_TO_INT(t46))) = (unsigned short) FX_TO_INT(v_V_121)));
v_BUFFER_125 = v_DISPLAY_13;
v_S_127 = v_BUFFER_125;
v_S_129 = v_BUFFER_125;
v_I_130 = (LP) 8;
v_X_132 = ((LP) DEREF((v_BUFFER_125) + 4 * 4));
t47 = (add((v_X_132), ((LP) 2)));
v_S14971_134 = ICALL(s_lsp_LDB_2D1) (3, (LP) 32, (LP) 0, t47);
v_T14972_135 = v_BUFFER_125;
v_S_136 = v_BUFFER_125;
v_VALUE_137 = v_S14971_134;
v_S_139 = v_BUFFER_125;
v_N_140 = (LP) 8;
v_VALUE_141 = v_S14971_134;
((LP) (DEREF((v_BUFFER_125) + 4 * 4) = (LD) (v_S14971_134)));
v_S14973_143 = v_BUFFER_2DBOFFSET_36;
v_T14974_144 = v_DISPLAY_13;
v_S_145 = v_DISPLAY_13;
v_VALUE_146 = v_S14973_143;
v_S_148 = v_DISPLAY_13;
v_N_149 = (LP) 10;
v_VALUE_150 = v_S14973_143;
((LP) (DEREF((v_DISPLAY_13) + 5 * 4) = (LD) (v_S14973_143)));
t48 = (add((v_BUFFER_2DBOFFSET_36), ((LP) 40)));
v_S14975_152 = t48;
v_T14976_153 = v_DISPLAY_13;
v_S_154 = v_DISPLAY_13;
v_VALUE_155 = v_S14975_152;
v_S_157 = v_DISPLAY_13;
v_N_158 = (LP) 14;
v_VALUE_159 = v_S14975_152;
((LP) (DEREF((v_DISPLAY_13) + 7 * 4) = (LD) (v_S14975_152)));
}
t49 = ICALL(s_xlib_DISPLAY_2DINVOKE_2DAFTER_2DFUNCTION) (MV_CALL(argc,1), v_DISPLAY_13);
return(t49);
}

LP p_xlib_DRAW_2DRECTANGLES(va_alist) va_dcl
{
LP v_VALUE_95; LP v_N_94; LP v_S_93; 
LP v_VALUE_91; LP v_S_90; LP v_T15081_89; 
LP v_S15080_88; LP v_X_86; LP v_I_84; 
LP v_S_83; LP v_S_81; LP v_BUFFER_79; 
LP v_I_77; LP v_A_76; LP v_V_75; 
LP v_T15079_74; LP v_I_72; LP v_A_71; 
LP v_V_70; LP v_I_68; LP v_S_67; 
LP v_S_65; LP v_I_63; LP v_A_62; 
LP v_V_61; LP v_I_59; LP v_S_58; 
LP v_S_56; LP v_T15078_55; LP v_T15077_54; 
LP v_S15076_53; LP v_I_51; LP v_A_50; 
LP v_V_49; LP v_VALUE_47; LP v_N_46; 
LP v_S_45; LP v_VALUE_43; LP v_S_42; 
LP v_T15075_41; LP v_S15074_40; LP v_BUFFER_2DBBUF_39; 
LP v_I_37; LP v_S_36; LP v_S_34; 
LP v_BUFFER_2DBOFFSET_33; LP v_I_31; LP v_S_30; 
LP v_S_28; LP v_I_26; LP v_S_25; 
LP v_S_23; LP v_I_21; LP v_S_20; 
LP v_S_18; LP v__25BUFFER_17; LP v_MV15073_16; 
LP v_I_14; LP v_S_13; LP v_S_11; 
LP v__2EDISPLAY_2E_10; LP v_I_8; LP v_S_7; 
LP v_S_5; LP v_RECTANGLES_2; LP v_GCONTEXT_1; 
LP v_DRAWABLE_0; LP v_FILL_2DP_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_DRAWABLE_0 = NEXT_VAR_ARG;
v_GCONTEXT_1 = NEXT_VAR_ARG;
v_RECTANGLES_2 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 3) wna_low(real_argc,3);
if (real_argc > 4) wna_high(real_argc,4);
if (real_argc < 4) {
v_FILL_2DP_3 = NIL;
} else {
v_FILL_2DP_3 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
v_S_5 = v_DRAWABLE_0;
v_S_7 = v_DRAWABLE_0;
v_I_8 = (LP) 4;
v__2EDISPLAY_2E_10 = ((LP) DEREF((v_DRAWABLE_0) + 2 * 4));
v_S_11 = v__2EDISPLAY_2E_10;
v_S_13 = v__2EDISPLAY_2E_10;
v_I_14 = (LP) 22;
t0 = ((LP) DEREF((v__2EDISPLAY_2E_10) + 11 * 4));
if (t0 != NIL) {
ICALL(s_lsp_ERROR) (3, LREF(s_xlib_CLOSED_2DDISPLAY), LREF(s_key_DISPLAY), v__2EDISPLAY_2E_10);
}
ICALL(s_xlib_FORCE_2DGCONTEXT_2DCHANGES_2DINTERNAL) (1, v_GCONTEXT_1);
{
int real_argc;
BEGIN_MV_CALL(mv_holder5796,0);
v__25BUFFER_17 = v__2EDISPLAY_2E_10;
v_S_18 = v__25BUFFER_17;
v_S_20 = v__25BUFFER_17;
v_I_21 = (LP) 14;
t3 = ((LP) DEREF((v__25BUFFER_17) + 7 * 4));
t2 = (add((t3), ((LP) 320)));
v_S_23 = v__25BUFFER_17;
v_S_25 = v__25BUFFER_17;
v_I_26 = (LP) 6;
t4 = ((LP) DEREF((v__25BUFFER_17) + 3 * 4));
if (((int) (t2) >= (int) (t4))) {
ICALL(s_xlib_BUFFER_2DFLUSH) (1, v__25BUFFER_17);
}
v_S_28 = v__25BUFFER_17;
v_S_30 = v__25BUFFER_17;
v_I_31 = (LP) 14;
v_BUFFER_2DBOFFSET_33 = ((LP) DEREF((v__25BUFFER_17) + 7 * 4));
v_S_34 = v__25BUFFER_17;
v_S_36 = v__25BUFFER_17;
v_I_37 = (LP) 16;
v_BUFFER_2DBBUF_39 = ((LP) DEREF((v__25BUFFER_17) + 8 * 4));
v_S15074_40 = v_BUFFER_2DBOFFSET_33;
v_T15075_41 = v__2EDISPLAY_2E_10;
v_S_42 = v__2EDISPLAY_2E_10;
v_VALUE_43 = v_BUFFER_2DBOFFSET_33;
v_S_45 = v__2EDISPLAY_2E_10;
v_N_46 = (LP) 10;
v_VALUE_47 = v_BUFFER_2DBOFFSET_33;
((LP) (DEREF((v__2EDISPLAY_2E_10) + 5 * 4) = (LD) (v_BUFFER_2DBOFFSET_33)));
if (v_FILL_2DP_3 != NIL) {
v_V_49 = (LP) 140;
} else {
v_V_49 = (LP) 134;
}
t5 = (add((v_BUFFER_2DBOFFSET_33), ((LP) 0)));
v_I_51 = t5;
v_S15076_53 = v_V_49;
v_T15077_54 = v_BUFFER_2DBBUF_39;
v_T15078_55 = v_I_51;
((unsigned char (*)) (v_BUFFER_2DBBUF_39 - 1))[FX_TO_INT(v_I_51)] = (unsigned char)FX_TO_INT(v_V_49);
v_S_56 = v_DRAWABLE_0;
v_S_58 = v_DRAWABLE_0;
v_I_59 = (LP) 2;
v_V_61 = ((LP) DEREF((v_DRAWABLE_0) + 1 * 4));
t6 = (add((v_BUFFER_2DBOFFSET_33), ((LP) 8)));
v_I_63 = t6;
t7 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_63)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_39) - 1)) + FX_TO_INT(t7))) = (unsigned long) FX_TO_INT(v_V_61)));
v_S_65 = v_GCONTEXT_1;
v_S_67 = v_GCONTEXT_1;
v_I_68 = (LP) 2;
v_V_70 = ((LP) DEREF((v_GCONTEXT_1) + 1 * 4));
t8 = (add((v_BUFFER_2DBOFFSET_33), ((LP) 16)));
v_I_72 = t8;
t9 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_72)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_39) - 1)) + FX_TO_INT(t9))) = (unsigned long) FX_TO_INT(v_V_70)));
v_T15079_74 = ICALL(s_lsp_LENGTH) (1, v_RECTANGLES_2);
t12 = (subtract((v_T15079_74), ((LP) 0)));
t11 = ICALL(s_lsp_CEILING) (2, t12, (LP) 4);
t10 = (add((t11), ((LP) 6)));
v_V_75 = t10;
t13 = (add((v_BUFFER_2DBOFFSET_33), ((LP) 4)));
v_I_77 = t13;
t14 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_77)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_39) - 1))+FX_TO_INT(t14))) = (unsigned short) FX_TO_INT(v_V_75)));
t15 = (add((v_BUFFER_2DBOFFSET_33), ((LP) 24)));
ICALL(s_xlib_WRITE_2DSEQUENCE_2DINT16) (6, v__25BUFFER_17, t15, v_RECTANGLES_2, (LP) 0, v_T15079_74, LREF(s_lsp_NIL));
v_BUFFER_79 = v__2EDISPLAY_2E_10;
v_S_81 = v_BUFFER_79;
v_S_83 = v_BUFFER_79;
v_I_84 = (LP) 8;
v_X_86 = ((LP) DEREF((v_BUFFER_79) + 4 * 4));
t16 = (add((v_X_86), ((LP) 2)));
v_S15080_88 = ICALL(s_lsp_LDB_2D1) (3, (LP) 32, (LP) 0, t16);
v_T15081_89 = v_BUFFER_79;
v_S_90 = v_BUFFER_79;
v_VALUE_91 = v_S15080_88;
v_S_93 = v_BUFFER_79;
v_N_94 = (LP) 8;
v_VALUE_95 = v_S15080_88;
t17 = ((LP) (DEREF((v_BUFFER_79) + 4 * 4) = (LD) (v_S15080_88)));
SET_MV_RETURN_VALUE(mv_holder5796,0,t17);
if SV_RETURN_P(mv_holder5796) SET_MV_RETURN_COUNT(mv_holder5796,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder5796);
BEGIN_VAR_VALUES;
RESTIFY(v_MV15073_16,1,NEXT_VAR_VALUE(mv_holder5796));
END_VAR_VALUES;
END_MV_CALL;
ICALL(s_xlib_DISPLAY_2DINVOKE_2DAFTER_2DFUNCTION) (1, v__2EDISPLAY_2E_10);
t18 = ICALL(s_lsp_VALUES_2DLIST) (MV_CALL(argc,1), v_MV15073_16);
return(t18);
}
}

LP p_xlib_DRAW_2DARC(va_alist) va_dcl
{
LP v_SYMBOL_201; LP v_I_199; LP v_A_198; 
LP v__2EBOFFSET_2E_197; LP v_G15119_196; LP v_I_194; 
LP v_A_193; LP v_I_191; LP v_S_190; 
LP v_S_188; LP v_I_186; LP v_A_185; 
LP v_I_183; LP v_S_182; LP v_S_180; 
LP v__2EBOFFSET_2E_179; LP v_VALUE_177; LP v_N_176; 
LP v_S_175; LP v_VALUE_173; LP v_S_172; 
LP v_T15118_171; LP v_S15117_170; LP v_VALUE_168; 
LP v_N_167; LP v_S_166; LP v_VALUE_164; 
LP v_S_163; LP v_T15116_162; LP v_S15115_161; 
LP v_VALUE_159; LP v_N_158; LP v_S_157; 
LP v_VALUE_155; LP v_S_154; LP v_T15114_153; 
LP v_S15113_152; LP v_X_150; LP v_I_148; 
LP v_S_147; LP v_S_145; LP v_BUFFER_143; 
LP v_I_141; LP v_A_140; LP v_V_139; 
LP v_I_137; LP v_A_136; LP v_V_135; 
LP v_I_133; LP v_A_132; LP v_V_131; 
LP v_I_129; LP v_A_128; LP v_V_127; 
LP v_I_125; LP v_A_124; LP v_V_123; 
LP v_I_121; LP v_A_120; LP v_V_119; 
LP v_I_117; LP v_A_116; LP v_V_115; 
LP v_I_113; LP v_S_112; LP v_S_110; 
LP v_I_108; LP v_A_107; LP v_V_106; 
LP v_I_104; LP v_S_103; LP v_S_101; 
LP v_I_99; LP v_A_98; LP v_V_97; 
LP v_T15112_96; LP v_T15111_95; LP v_S15110_94; 
LP v_I_92; LP v_A_91; LP v_V_90; 
LP v_VALUE_88; LP v_N_87; LP v_S_86; 
LP v_VALUE_84; LP v_S_83; LP v_T15109_82; 
LP v_S15108_81; LP v_I_79; LP v_A_78; 
LP v_V_77; LP v_I_75; LP v_A_74; 
LP v_V_73; LP v_I_71; LP v_A_70; 
LP v_V_69; LP v_I_67; LP v_A_66; 
LP v_V_65; LP v_I_63; LP v_A_62; 
LP v_V_61; LP v_I_59; LP v_A_58; 
LP v_V_57; LP v__2EBOFFSET_2E_56; LP v_I_54; 
LP v_A_53; LP v_V_52; LP v_CURRENT_2DBOFFSET_51; 
LP v_LAST_2DREQUEST_2DBYTE_50; LP v_I_48; LP v_S_47; 
LP v_S_45; LP v_BUFFER_2DBBUF_44; LP v_I_42; 
LP v_S_41; LP v_S_39; LP v_BUFFER_2DBOFFSET_38; 
LP v_I_36; LP v_S_35; LP v_S_33; 
LP v_I_31; LP v_S_30; LP v_S_28; 
LP v_I_26; LP v_S_25; LP v_S_23; 
LP v__25BUFFER_22; LP v_I_20; LP v_S_19; 
LP v_S_17; LP v_REQUEST_16; LP v_DISPLAY_15; 
LP v_I_13; LP v_S_12; LP v_S_10; 
LP v_ANGLE2_7; LP v_ANGLE1_6; LP v_HEIGHT_5; 
LP v_WIDTH_4; LP v_Y_3; LP v_X_2; 
LP v_GCONTEXT_1; LP v_DRAWABLE_0; LP v_FILL_2DP_8; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; LP t145; LP t146; LP t147; LP t148; LP t149; 
LP t150; LP t151; LP t152; LP t153; LP t154; LP t155; 
LP t156; LP t157; LP t158; LP t159; LP t160; LP t161; 
LP t162; LP t163; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_DRAWABLE_0 = NEXT_VAR_ARG;
v_GCONTEXT_1 = NEXT_VAR_ARG;
v_X_2 = NEXT_VAR_ARG;
v_Y_3 = NEXT_VAR_ARG;
v_WIDTH_4 = NEXT_VAR_ARG;
v_HEIGHT_5 = NEXT_VAR_ARG;
v_ANGLE1_6 = NEXT_VAR_ARG;
v_ANGLE2_7 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 8) wna_low(real_argc,8);
if (real_argc > 9) wna_high(real_argc,9);
if (real_argc < 9) {
v_FILL_2DP_8 = NIL;
} else {
v_FILL_2DP_8 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
v_S_10 = v_DRAWABLE_0;
v_S_12 = v_DRAWABLE_0;
v_I_13 = (LP) 4;
v_DISPLAY_15 = ((LP) DEREF((v_DRAWABLE_0) + 2 * 4));
if (v_FILL_2DP_8 != NIL) {
v_REQUEST_16 = (LP) 142;
} else {
v_REQUEST_16 = (LP) 136;
}
v_S_17 = v_DISPLAY_15;
v_S_19 = v_DISPLAY_15;
v_I_20 = (LP) 22;
t0 = ((LP) DEREF((v_DISPLAY_15) + 11 * 4));
if (t0 != NIL) {
ICALL(s_lsp_ERROR) (3, LREF(s_xlib_CLOSED_2DDISPLAY), LREF(s_key_DISPLAY), v_DISPLAY_15);
}
ICALL(s_xlib_FORCE_2DGCONTEXT_2DCHANGES_2DINTERNAL) (1, v_GCONTEXT_1);
v__25BUFFER_22 = v_DISPLAY_15;
v_S_23 = v__25BUFFER_22;
v_S_25 = v__25BUFFER_22;
v_I_26 = (LP) 14;
t3 = ((LP) DEREF((v__25BUFFER_22) + 7 * 4));
t2 = (add((t3), ((LP) 320)));
v_S_28 = v__25BUFFER_22;
v_S_30 = v__25BUFFER_22;
v_I_31 = (LP) 6;
t4 = ((LP) DEREF((v__25BUFFER_22) + 3 * 4));
if (((int) (t2) >= (int) (t4))) {
ICALL(s_xlib_BUFFER_2DFLUSH) (1, v__25BUFFER_22);
}
v_S_33 = v__25BUFFER_22;
v_S_35 = v__25BUFFER_22;
v_I_36 = (LP) 14;
v_BUFFER_2DBOFFSET_38 = ((LP) DEREF((v__25BUFFER_22) + 7 * 4));
v_S_39 = v__25BUFFER_22;
v_S_41 = v__25BUFFER_22;
v_I_42 = (LP) 16;
v_BUFFER_2DBBUF_44 = ((LP) DEREF((v__25BUFFER_22) + 8 * 4));
v_S_45 = v_DISPLAY_15;
v_S_47 = v_DISPLAY_15;
v_I_48 = (LP) 10;
v_LAST_2DREQUEST_2DBYTE_50 = ((LP) DEREF((v_DISPLAY_15) + 5 * 4));
v_CURRENT_2DBOFFSET_51 = v_BUFFER_2DBOFFSET_38;
v_SYMBOL_201 = LREF(s_xlib__2AINHIBIT_2DAPPENDING_2A);
t6 = ((LP) DEREF((LREF(s_xlib__2AINHIBIT_2DAPPENDING_2A)) + 0 * 4));
if (t6 != NIL) {
t5 = LREF(s_lsp_NIL);
} else {
if (v_LAST_2DREQUEST_2DBYTE_50 != NIL) {
v_A_198 = v_BUFFER_2DBBUF_44;
v_I_199 = v_LAST_2DREQUEST_2DBYTE_50;
t8 = (LP) INT_TO_FX(((unsigned char (*)) (v_BUFFER_2DBBUF_44 - 1))[FX_TO_INT(v_LAST_2DREQUEST_2DBYTE_50)]);
t7 = (num_equal_p((t8), (v_REQUEST_16)));
if (t7 != NIL) {
v__2EBOFFSET_2E_179 = v_LAST_2DREQUEST_2DBYTE_50;
v_BUFFER_2DBOFFSET_38 = v_LAST_2DREQUEST_2DBYTE_50;
v_S_188 = v_DRAWABLE_0;
v_S_190 = v_DRAWABLE_0;
v_I_191 = (LP) 2;
t10 = ((LP) DEREF((v_DRAWABLE_0) + 1 * 4));
t11 = (add((v_BUFFER_2DBOFFSET_38), ((LP) 8)));
v_I_194 = t11;
t13 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_194)) >> (2)));
t12 = INT_TO_FX((LP) (*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_44) - 1)) + FX_TO_INT(t13))));
t9 = (num_equal_p((t10), (t12)));
if (t9 != NIL) {
v_S_180 = v_GCONTEXT_1;
v_S_182 = v_GCONTEXT_1;
v_I_183 = (LP) 2;
t14 = ((LP) DEREF((v_GCONTEXT_1) + 1 * 4));
t15 = (add((v_BUFFER_2DBOFFSET_38), ((LP) 16)));
v_I_186 = t15;
t17 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_186)) >> (2)));
t16 = INT_TO_FX((LP) (*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_44) - 1)) + FX_TO_INT(t17))));
v_G15119_196 = (num_equal_p((t14), (t16)));
} else {
v_G15119_196 = LREF(s_lsp_NIL);
}
if (v_G15119_196 != NIL) {
t5 = v_G15119_196;
} else {
v__2EBOFFSET_2E_197 = v_CURRENT_2DBOFFSET_51;
v_BUFFER_2DBOFFSET_38 = v_CURRENT_2DBOFFSET_51;
t5 = LREF(s_lsp_NIL);
}
} else {
t5 = LREF(s_lsp_NIL);
}
} else {
t5 = LREF(s_lsp_NIL);
}
}
if (t5 != NIL) {
t20 = (subtract((v_CURRENT_2DBOFFSET_51), (v_LAST_2DREQUEST_2DBYTE_50)));
t19 = ICALL(s_lsp_ASH) (2, t20, (LP) -4);
t18 = (add(((LP) 6), (t19)));
v_V_52 = t18;
t21 = (add((v_BUFFER_2DBOFFSET_38), ((LP) 4)));
v_I_54 = t21;
t22 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_54)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_44) - 1))+FX_TO_INT(t22))) = (unsigned short) FX_TO_INT(v_V_52)));
v__2EBOFFSET_2E_56 = v_CURRENT_2DBOFFSET_51;
v_BUFFER_2DBOFFSET_38 = v_CURRENT_2DBOFFSET_51;
v_V_57 = v_X_2;
t23 = (add((v_BUFFER_2DBOFFSET_38), ((LP) 0)));
v_I_59 = t23;
t24 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_59)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_44) - 1)) + FX_TO_INT(t24))) = (short) FX_TO_INT(v_V_57)));
v_V_61 = v_Y_3;
t25 = (add((v_BUFFER_2DBOFFSET_38), ((LP) 4)));
v_I_63 = t25;
t26 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_63)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_44) - 1)) + FX_TO_INT(t26))) = (short) FX_TO_INT(v_V_61)));
v_V_65 = v_WIDTH_4;
t27 = (add((v_BUFFER_2DBOFFSET_38), ((LP) 8)));
v_I_67 = t27;
t28 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_67)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_44) - 1))+FX_TO_INT(t28))) = (unsigned short) FX_TO_INT(v_V_65)));
v_V_69 = v_HEIGHT_5;
t29 = (add((v_BUFFER_2DBOFFSET_38), ((LP) 12)));
v_I_71 = t29;
t30 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_71)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_44) - 1))+FX_TO_INT(t30))) = (unsigned short) FX_TO_INT(v_V_69)));
v_V_73 = ICALL(s_xlib_RADIANS_2D_3EINT16) (1, v_ANGLE1_6);
t31 = (add((v_BUFFER_2DBOFFSET_38), ((LP) 16)));
v_I_75 = t31;
t32 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_75)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_44) - 1)) + FX_TO_INT(t32))) = (short) FX_TO_INT(v_V_73)));
v_V_77 = ICALL(s_xlib_RADIANS_2D_3EINT16) (1, v_ANGLE2_7);
t33 = (add((v_BUFFER_2DBOFFSET_38), ((LP) 20)));
v_I_79 = t33;
t34 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_79)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_44) - 1)) + FX_TO_INT(t34))) = (short) FX_TO_INT(v_V_77)));
t35 = (add((v_BUFFER_2DBOFFSET_38), ((LP) 24)));
v_S15108_81 = t35;
v_T15109_82 = v_DISPLAY_15;
v_S_83 = v_DISPLAY_15;
v_VALUE_84 = v_S15108_81;
v_S_86 = v_DISPLAY_15;
v_N_87 = (LP) 14;
v_VALUE_88 = v_S15108_81;
((LP) (DEREF((v_DISPLAY_15) + 7 * 4) = (LD) (v_S15108_81)));
} else {
t36 = (add((v_BUFFER_2DBOFFSET_38), ((LP) 0)));
v_I_92 = t36;
v_S15110_94 = v_REQUEST_16;
v_T15111_95 = v_BUFFER_2DBBUF_44;
v_T15112_96 = v_I_92;
((unsigned char (*)) (v_BUFFER_2DBBUF_44 - 1))[FX_TO_INT(v_I_92)] = (unsigned char)FX_TO_INT(v_REQUEST_16);
v_V_97 = (LP) 12;
t37 = (add((v_BUFFER_2DBOFFSET_38), ((LP) 4)));
v_I_99 = t37;
t38 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_99)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_44) - 1))+FX_TO_INT(t38))) = (unsigned short) FX_TO_INT(v_V_97)));
v_S_101 = v_DRAWABLE_0;
v_S_103 = v_DRAWABLE_0;
v_I_104 = (LP) 2;
v_V_106 = ((LP) DEREF((v_DRAWABLE_0) + 1 * 4));
t39 = (add((v_BUFFER_2DBOFFSET_38), ((LP) 8)));
v_I_108 = t39;
t40 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_108)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_44) - 1)) + FX_TO_INT(t40))) = (unsigned long) FX_TO_INT(v_V_106)));
v_S_110 = v_GCONTEXT_1;
v_S_112 = v_GCONTEXT_1;
v_I_113 = (LP) 2;
v_V_115 = ((LP) DEREF((v_GCONTEXT_1) + 1 * 4));
t41 = (add((v_BUFFER_2DBOFFSET_38), ((LP) 16)));
v_I_117 = t41;
t42 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_117)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_44) - 1)) + FX_TO_INT(t42))) = (unsigned long) FX_TO_INT(v_V_115)));
v_V_119 = v_X_2;
t43 = (add((v_BUFFER_2DBOFFSET_38), ((LP) 24)));
v_I_121 = t43;
t44 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_121)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_44) - 1)) + FX_TO_INT(t44))) = (short) FX_TO_INT(v_V_119)));
v_V_123 = v_Y_3;
t45 = (add((v_BUFFER_2DBOFFSET_38), ((LP) 28)));
v_I_125 = t45;
t46 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_125)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_44) - 1)) + FX_TO_INT(t46))) = (short) FX_TO_INT(v_V_123)));
v_V_127 = v_WIDTH_4;
t47 = (add((v_BUFFER_2DBOFFSET_38), ((LP) 32)));
v_I_129 = t47;
t48 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_129)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_44) - 1))+FX_TO_INT(t48))) = (unsigned short) FX_TO_INT(v_V_127)));
v_V_131 = v_HEIGHT_5;
t49 = (add((v_BUFFER_2DBOFFSET_38), ((LP) 36)));
v_I_133 = t49;
t50 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_133)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_44) - 1))+FX_TO_INT(t50))) = (unsigned short) FX_TO_INT(v_V_131)));
v_V_135 = ICALL(s_xlib_RADIANS_2D_3EINT16) (1, v_ANGLE1_6);
t51 = (add((v_BUFFER_2DBOFFSET_38), ((LP) 40)));
v_I_137 = t51;
t52 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_137)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_44) - 1)) + FX_TO_INT(t52))) = (short) FX_TO_INT(v_V_135)));
v_V_139 = ICALL(s_xlib_RADIANS_2D_3EINT16) (1, v_ANGLE2_7);
t53 = (add((v_BUFFER_2DBOFFSET_38), ((LP) 44)));
v_I_141 = t53;
t54 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_141)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_44) - 1)) + FX_TO_INT(t54))) = (short) FX_TO_INT(v_V_139)));
v_BUFFER_143 = v_DISPLAY_15;
v_S_145 = v_BUFFER_143;
v_S_147 = v_BUFFER_143;
v_I_148 = (LP) 8;
v_X_150 = ((LP) DEREF((v_BUFFER_143) + 4 * 4));
t55 = (add((v_X_150), ((LP) 2)));
v_S15113_152 = ICALL(s_lsp_LDB_2D1) (3, (LP) 32, (LP) 0, t55);
v_T15114_153 = v_BUFFER_143;
v_S_154 = v_BUFFER_143;
v_VALUE_155 = v_S15113_152;
v_S_157 = v_BUFFER_143;
v_N_158 = (LP) 8;
v_VALUE_159 = v_S15113_152;
((LP) (DEREF((v_BUFFER_143) + 4 * 4) = (LD) (v_S15113_152)));
v_S15115_161 = v_BUFFER_2DBOFFSET_38;
v_T15116_162 = v_DISPLAY_15;
v_S_163 = v_DISPLAY_15;
v_VALUE_164 = v_S15115_161;
v_S_166 = v_DISPLAY_15;
v_N_167 = (LP) 10;
v_VALUE_168 = v_S15115_161;
((LP) (DEREF((v_DISPLAY_15) + 5 * 4) = (LD) (v_S15115_161)));
t56 = (add((v_BUFFER_2DBOFFSET_38), ((LP) 48)));
v_S15117_170 = t56;
v_T15118_171 = v_DISPLAY_15;
v_S_172 = v_DISPLAY_15;
v_VALUE_173 = v_S15117_170;
v_S_175 = v_DISPLAY_15;
v_N_176 = (LP) 14;
v_VALUE_177 = v_S15117_170;
((LP) (DEREF((v_DISPLAY_15) + 7 * 4) = (LD) (v_S15117_170)));
}
t57 = ICALL(s_xlib_DISPLAY_2DINVOKE_2DAFTER_2DFUNCTION) (MV_CALL(argc,1), v_DISPLAY_15);
return(t57);
}

LP p_xlib_DRAW_2DARCS_2DLIST(va_alist) va_dcl
{
LP v_VALUE_214; LP v_N_213; LP v_S_212; 
LP v_VALUE_210; LP v_S_209; LP v_T15246_208; 
LP v_S15245_207; LP v_X_205; LP v_I_203; 
LP v_S_202; LP v_S_200; LP v_BUFFER_198; 
LP v__2EVALUE_2E_197; LP v__2EBOFFSET_2E_196; LP v_I_194; 
LP v_A_193; LP v_V_192; LP v_S15244_191; 
LP v_X_189; LP v_VALUE15243_188; LP v_X_186; 
LP v_LIST15242_185; LP v_I_183; LP v_A_182; 
LP v_V_181; LP v_S15241_180; LP v_X_178; 
LP v_VALUE15240_177; LP v_X_175; LP v_LIST15239_174; 
LP v_I_172; LP v_A_171; LP v_V_170; 
LP v_S15238_169; LP v_X_167; LP v_VALUE15237_166; 
LP v_X_164; LP v_LIST15236_163; LP v_I_161; 
LP v_A_160; LP v_V_159; LP v_S15235_158; 
LP v_X_156; LP v_VALUE15234_155; LP v_X_153; 
LP v_LIST15233_152; LP v_I_150; LP v_A_149; 
LP v_V_148; LP v_S15232_147; LP v_X_145; 
LP v_VALUE15231_144; LP v_X_142; LP v_LIST15230_141; 
LP v_I_139; LP v_A_138; LP v_V_137; 
LP v_S15229_136; LP v_X_134; LP v_VALUE15228_133; 
LP v_X_131; LP v_LIST15227_130; LP v__2EBOFFSET_2E_129; 
LP v_I_127; LP v_S_126; LP v_S_124; 
LP v_VALUE_122; LP v_N_121; LP v_S_120; 
LP v_VALUE_118; LP v_S_117; LP v_T15226_116; 
LP v_S15225_115; LP v_Y_113; LP v_X_112; 
LP v_X_110; LP v_X_108; LP v_VALUE_106; 
LP v_N_105; LP v_S_104; LP v_VALUE_102; 
LP v_S_101; LP v_T15224_100; LP v_S15223_99; 
LP v_ARC_96; LP v__2EVALUE_2E_94; LP v__2EBOFFSET_2E_93; 
LP v__2EVALUE_2E_92; LP v_I_90; LP v_A_89; 
LP v_V_88; LP v_I_86; LP v_A_85; 
LP v_V_84; LP v_I_82; LP v_S_81; 
LP v_S_79; LP v_I_77; LP v_A_76; 
LP v_V_75; LP v_I_73; LP v_S_72; 
LP v_S_70; LP v_T15220_69; LP v_T15219_68; 
LP v_S15218_67; LP v_I_65; LP v_A_64; 
LP v_V_63; LP v_VALUE_61; LP v_N_60; 
LP v_S_59; LP v_VALUE_57; LP v_S_56; 
LP v_T15217_55; LP v_S15216_54; LP v_BUFFER_2DBBUF_53; 
LP v_I_51; LP v_S_50; LP v_S_48; 
LP v_BUFFER_2DBOFFSET_47; LP v_I_45; LP v_S_44; 
LP v_S_42; LP v_I_40; LP v_S_39; 
LP v_S_37; LP v_I_35; LP v_S_34; 
LP v_S_32; LP v__25BUFFER_31; LP v_MV15215_30; 
LP v_I_28; LP v_S_27; LP v_S_25; 
LP v__2EDISPLAY_2E_24; LP v_I_22; LP v_S_21; 
LP v_S_19; LP v_REQUEST_18; LP v_LENGTH_17; 
LP v_LIMIT_16; LP v_I_14; LP v_S_13; 
LP v_S_11; LP v_DISPLAY_10; LP v_I_8; 
LP v_S_7; LP v_S_5; LP v_ARCS_2; 
LP v_GCONTEXT_1; LP v_DRAWABLE_0; LP v_FILL_2DP_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; LP t145; LP t146; LP t147; LP t148; LP t149; 

int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_DRAWABLE_0 = NEXT_VAR_ARG;
v_GCONTEXT_1 = NEXT_VAR_ARG;
v_ARCS_2 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 3) wna_low(real_argc,3);
if (real_argc > 4) wna_high(real_argc,4);
if (real_argc < 4) {
v_FILL_2DP_3 = NIL;
} else {
v_FILL_2DP_3 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
v_S_5 = v_DRAWABLE_0;
v_S_7 = v_DRAWABLE_0;
v_I_8 = (LP) 4;
v_DISPLAY_10 = ((LP) DEREF((v_DRAWABLE_0) + 2 * 4));
v_S_11 = v_DISPLAY_10;
v_S_13 = v_DISPLAY_10;
v_I_14 = (LP) 6;
t1 = ((LP) DEREF((v_DISPLAY_10) + 3 * 4));
t0 = (subtract((t1), ((LP) 24)));
v_LIMIT_16 = t0;
v_LENGTH_17 = ICALL(s_lsp_LENGTH) (1, v_ARCS_2);
if (v_FILL_2DP_3 != NIL) {
v_REQUEST_18 = (LP) 142;
} else {
v_REQUEST_18 = (LP) 136;
}
v_S_19 = v_DRAWABLE_0;
v_S_21 = v_DRAWABLE_0;
v_I_22 = (LP) 4;
v__2EDISPLAY_2E_24 = ((LP) DEREF((v_DRAWABLE_0) + 2 * 4));
v_S_25 = v__2EDISPLAY_2E_24;
v_S_27 = v__2EDISPLAY_2E_24;
v_I_28 = (LP) 22;
t2 = ((LP) DEREF((v__2EDISPLAY_2E_24) + 11 * 4));
if (t2 != NIL) {
ICALL(s_lsp_ERROR) (3, LREF(s_xlib_CLOSED_2DDISPLAY), LREF(s_key_DISPLAY), v__2EDISPLAY_2E_24);
}
ICALL(s_xlib_FORCE_2DGCONTEXT_2DCHANGES_2DINTERNAL) (1, v_GCONTEXT_1);
{
int real_argc;
BEGIN_MV_CALL(mv_holder5797,0);
v__25BUFFER_31 = v__2EDISPLAY_2E_24;
v_S_32 = v__25BUFFER_31;
v_S_34 = v__25BUFFER_31;
v_I_35 = (LP) 14;
t5 = ((LP) DEREF((v__25BUFFER_31) + 7 * 4));
t4 = (add((t5), ((LP) 320)));
v_S_37 = v__25BUFFER_31;
v_S_39 = v__25BUFFER_31;
v_I_40 = (LP) 6;
t6 = ((LP) DEREF((v__25BUFFER_31) + 3 * 4));
if (((int) (t4) >= (int) (t6))) {
ICALL(s_xlib_BUFFER_2DFLUSH) (1, v__25BUFFER_31);
}
v_S_42 = v__25BUFFER_31;
v_S_44 = v__25BUFFER_31;
v_I_45 = (LP) 14;
v_BUFFER_2DBOFFSET_47 = ((LP) DEREF((v__25BUFFER_31) + 7 * 4));
v_S_48 = v__25BUFFER_31;
v_S_50 = v__25BUFFER_31;
v_I_51 = (LP) 16;
v_BUFFER_2DBBUF_53 = ((LP) DEREF((v__25BUFFER_31) + 8 * 4));
v_S15216_54 = v_BUFFER_2DBOFFSET_47;
v_T15217_55 = v__2EDISPLAY_2E_24;
v_S_56 = v__2EDISPLAY_2E_24;
v_VALUE_57 = v_S15216_54;
v_S_59 = v__2EDISPLAY_2E_24;
v_N_60 = (LP) 10;
v_VALUE_61 = v_S15216_54;
((LP) (DEREF((v__2EDISPLAY_2E_24) + 5 * 4) = (LD) (v_S15216_54)));
t7 = (add((v_BUFFER_2DBOFFSET_47), ((LP) 0)));
v_I_65 = t7;
v_S15218_67 = v_REQUEST_18;
v_T15219_68 = v_BUFFER_2DBBUF_53;
v_T15220_69 = v_I_65;
((unsigned char (*)) (v_BUFFER_2DBBUF_53 - 1))[FX_TO_INT(v_I_65)] = (unsigned char)FX_TO_INT(v_REQUEST_18);
v_S_70 = v_DRAWABLE_0;
v_S_72 = v_DRAWABLE_0;
v_I_73 = (LP) 2;
v_V_75 = ((LP) DEREF((v_DRAWABLE_0) + 1 * 4));
t8 = (add((v_BUFFER_2DBOFFSET_47), ((LP) 8)));
v_I_77 = t8;
t9 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_77)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_53) - 1)) + FX_TO_INT(t9))) = (unsigned long) FX_TO_INT(v_V_75)));
v_S_79 = v_GCONTEXT_1;
v_S_81 = v_GCONTEXT_1;
v_I_82 = (LP) 2;
v_V_84 = ((LP) DEREF((v_GCONTEXT_1) + 1 * 4));
t10 = (add((v_BUFFER_2DBOFFSET_47), ((LP) 16)));
v_I_86 = t10;
t11 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_86)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_53) - 1)) + FX_TO_INT(t11))) = (unsigned long) FX_TO_INT(v_V_84)));
t13 = ICALL(s_lsp_ASH) (2, v_LENGTH_17, (LP) -2);
t12 = (add((t13), ((LP) 6)));
v_V_88 = t12;
t14 = (add((v_BUFFER_2DBOFFSET_47), ((LP) 4)));
v_I_90 = t14;
t15 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_90)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_53) - 1))+FX_TO_INT(t15))) = (unsigned short) FX_TO_INT(v_V_88)));
v__2EVALUE_2E_92 = v_V_88;
t16 = (add((v_BUFFER_2DBOFFSET_47), ((LP) 24)));
v__2EBOFFSET_2E_93 = t16;
v_BUFFER_2DBOFFSET_47 = v__2EBOFFSET_2E_93;
v__2EVALUE_2E_94 = v_BUFFER_2DBOFFSET_47;
v_ARC_96 = v_ARCS_2;
goto t_TEST15221_98;
t_LOOP15222_97:;
t_TEST15221_98:;
v_X_108 = v_ARC_96;
v_X_110 = v_X_108;
v_X_112 = v_X_108;
v_Y_113 = LREF(s_lsp_NIL);
if (v_X_108 == NIL) {
v_S15223_99 = v_BUFFER_2DBOFFSET_47;
v_T15224_100 = v_DISPLAY_10;
v_S_101 = v_DISPLAY_10;
v_VALUE_102 = v_S15223_99;
v_S_104 = v_DISPLAY_10;
v_N_105 = (LP) 14;
v_VALUE_106 = v_S15223_99;
t17 = ((LP) (DEREF((v_DISPLAY_10) + 7 * 4) = (LD) (v_S15223_99)));
v__2EVALUE_2E_197 = t17;
goto b_NIL_95;
}
t18 = (geq_p((v_BUFFER_2DBOFFSET_47), (v_LIMIT_16)));
if (t18 != NIL) {
v_S15225_115 = v_BUFFER_2DBOFFSET_47;
v_T15226_116 = v_DISPLAY_10;
v_S_117 = v_DISPLAY_10;
v_VALUE_118 = v_S15225_115;
v_S_120 = v_DISPLAY_10;
v_N_121 = (LP) 14;
v_VALUE_122 = v_S15225_115;
((LP) (DEREF((v_DISPLAY_10) + 7 * 4) = (LD) (v_S15225_115)));
ICALL(s_xlib_BUFFER_2DFLUSH) (1, v_DISPLAY_10);
v_S_124 = v_DISPLAY_10;
v_S_126 = v_DISPLAY_10;
v_I_127 = (LP) 14;
v__2EBOFFSET_2E_129 = ((LP) DEREF((v_DISPLAY_10) + 7 * 4));
v_BUFFER_2DBOFFSET_47 = v__2EBOFFSET_2E_129;
}
v_LIST15227_130 = v_ARC_96;
v_X_131 = v_LIST15227_130;
v_VALUE15228_133 = ((LP) DEREF((v_LIST15227_130) + 0 * 4));
v_X_134 = v_LIST15227_130;
v_S15229_136 = ((LP) DEREF((v_LIST15227_130) + 1 * 4));
v_ARC_96 = v_S15229_136;
v_V_137 = v_VALUE15228_133;
t19 = (add((v_BUFFER_2DBOFFSET_47), ((LP) 0)));
v_I_139 = t19;
t20 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_139)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_53) - 1)) + FX_TO_INT(t20))) = (short) FX_TO_INT(v_V_137)));
v_LIST15230_141 = v_ARC_96;
v_X_142 = v_LIST15230_141;
v_VALUE15231_144 = ((LP) DEREF((v_LIST15230_141) + 0 * 4));
v_X_145 = v_LIST15230_141;
v_S15232_147 = ((LP) DEREF((v_LIST15230_141) + 1 * 4));
v_ARC_96 = v_S15232_147;
v_V_148 = v_VALUE15231_144;
t21 = (add((v_BUFFER_2DBOFFSET_47), ((LP) 4)));
v_I_150 = t21;
t22 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_150)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_53) - 1)) + FX_TO_INT(t22))) = (short) FX_TO_INT(v_V_148)));
v_LIST15233_152 = v_ARC_96;
v_X_153 = v_LIST15233_152;
v_VALUE15234_155 = ((LP) DEREF((v_LIST15233_152) + 0 * 4));
v_X_156 = v_LIST15233_152;
v_S15235_158 = ((LP) DEREF((v_LIST15233_152) + 1 * 4));
v_ARC_96 = v_S15235_158;
v_V_159 = v_VALUE15234_155;
t23 = (add((v_BUFFER_2DBOFFSET_47), ((LP) 8)));
v_I_161 = t23;
t24 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_161)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_53) - 1))+FX_TO_INT(t24))) = (unsigned short) FX_TO_INT(v_V_159)));
v_LIST15236_163 = v_ARC_96;
v_X_164 = v_LIST15236_163;
v_VALUE15237_166 = ((LP) DEREF((v_LIST15236_163) + 0 * 4));
v_X_167 = v_LIST15236_163;
v_S15238_169 = ((LP) DEREF((v_LIST15236_163) + 1 * 4));
v_ARC_96 = v_S15238_169;
v_V_170 = v_VALUE15237_166;
t25 = (add((v_BUFFER_2DBOFFSET_47), ((LP) 12)));
v_I_172 = t25;
t26 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_172)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_53) - 1))+FX_TO_INT(t26))) = (unsigned short) FX_TO_INT(v_V_170)));
v_LIST15239_174 = v_ARC_96;
v_X_175 = v_LIST15239_174;
v_VALUE15240_177 = ((LP) DEREF((v_LIST15239_174) + 0 * 4));
v_X_178 = v_LIST15239_174;
v_S15241_180 = ((LP) DEREF((v_LIST15239_174) + 1 * 4));
v_ARC_96 = v_S15241_180;
v_V_181 = ICALL(s_xlib_RADIANS_2D_3EINT16) (1, v_VALUE15240_177);
t27 = (add((v_BUFFER_2DBOFFSET_47), ((LP) 16)));
v_I_183 = t27;
t28 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_183)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_53) - 1)) + FX_TO_INT(t28))) = (short) FX_TO_INT(v_V_181)));
v_LIST15242_185 = v_ARC_96;
v_X_186 = v_LIST15242_185;
v_VALUE15243_188 = ((LP) DEREF((v_LIST15242_185) + 0 * 4));
v_X_189 = v_LIST15242_185;
v_S15244_191 = ((LP) DEREF((v_LIST15242_185) + 1 * 4));
v_ARC_96 = v_S15244_191;
v_V_192 = ICALL(s_xlib_RADIANS_2D_3EINT16) (1, v_VALUE15243_188);
t29 = (add((v_BUFFER_2DBOFFSET_47), ((LP) 20)));
v_I_194 = t29;
t30 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_194)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_53) - 1)) + FX_TO_INT(t30))) = (short) FX_TO_INT(v_V_192)));
t31 = (add((v_BUFFER_2DBOFFSET_47), ((LP) 24)));
v__2EBOFFSET_2E_196 = t31;
v_BUFFER_2DBOFFSET_47 = v__2EBOFFSET_2E_196;
goto t_LOOP15222_97;
v__2EVALUE_2E_197 = NIL;
v__2EVALUE_2E_197 = v__2EVALUE_2E_197;
b_NIL_95:;
v_BUFFER_198 = v__2EDISPLAY_2E_24;
v_S_200 = v_BUFFER_198;
v_S_202 = v_BUFFER_198;
v_I_203 = (LP) 8;
v_X_205 = ((LP) DEREF((v_BUFFER_198) + 4 * 4));
t32 = (add((v_X_205), ((LP) 2)));
v_S15245_207 = ICALL(s_lsp_LDB_2D1) (3, (LP) 32, (LP) 0, t32);
v_T15246_208 = v_BUFFER_198;
v_S_209 = v_BUFFER_198;
v_VALUE_210 = v_S15245_207;
v_S_212 = v_BUFFER_198;
v_N_213 = (LP) 8;
v_VALUE_214 = v_S15245_207;
t33 = ((LP) (DEREF((v_BUFFER_198) + 4 * 4) = (LD) (v_S15245_207)));
SET_MV_RETURN_VALUE(mv_holder5797,0,t33);
if SV_RETURN_P(mv_holder5797) SET_MV_RETURN_COUNT(mv_holder5797,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder5797);
BEGIN_VAR_VALUES;
RESTIFY(v_MV15215_30,1,NEXT_VAR_VALUE(mv_holder5797));
END_VAR_VALUES;
END_MV_CALL;
ICALL(s_xlib_DISPLAY_2DINVOKE_2DAFTER_2DFUNCTION) (1, v__2EDISPLAY_2E_24);
t34 = ICALL(s_lsp_VALUES_2DLIST) (MV_CALL(argc,1), v_MV15215_30);
return(t34);
}
}

LP p_xlib_DRAW_2DARCS_2DVECTOR(va_alist) va_dcl
{
LP v_VALUE_167; LP v_N_166; LP v_S_165; 
LP v_VALUE_163; LP v_S_162; LP v_T15271_161; 
LP v_S15270_160; LP v_X_158; LP v_I_156; 
LP v_S_155; LP v_S_153; LP v_BUFFER_151; 
LP v__2EVALUE_2E_150; LP v__2EBOFFSET_2E_149; LP v_I_147; 
LP v_A_146; LP v_V_145; LP v_I_143; 
LP v_A_142; LP v_V_141; LP v_I_139; 
LP v_A_138; LP v_V_137; LP v_I_135; 
LP v_A_134; LP v_V_133; LP v_I_131; 
LP v_A_130; LP v_V_129; LP v_I_127; 
LP v_A_126; LP v_V_125; LP v__2EBOFFSET_2E_124; 
LP v_I_122; LP v_S_121; LP v_S_119; 
LP v_VALUE_117; LP v_N_116; LP v_S_115; 
LP v_VALUE_113; LP v_S_112; LP v_T15269_111; 
LP v_S15268_110; LP v_VALUE_108; LP v_N_107; 
LP v_S_106; LP v_VALUE_104; LP v_S_103; 
LP v_T15267_102; LP v_S15266_101; LP v_TMP15265_100; 
LP v_LENGTH_97; LP v_N_96; LP v__2EVALUE_2E_94; 
LP v__2EBOFFSET_2E_93; LP v__2EVALUE_2E_92; LP v_I_90; 
LP v_A_89; LP v_V_88; LP v_I_86; 
LP v_A_85; LP v_V_84; LP v_I_82; 
LP v_S_81; LP v_S_79; LP v_I_77; 
LP v_A_76; LP v_V_75; LP v_I_73; 
LP v_S_72; LP v_S_70; LP v_T15262_69; 
LP v_T15261_68; LP v_S15260_67; LP v_I_65; 
LP v_A_64; LP v_V_63; LP v_VALUE_61; 
LP v_N_60; LP v_S_59; LP v_VALUE_57; 
LP v_S_56; LP v_T15259_55; LP v_S15258_54; 
LP v_BUFFER_2DBBUF_53; LP v_I_51; LP v_S_50; 
LP v_S_48; LP v_BUFFER_2DBOFFSET_47; LP v_I_45; 
LP v_S_44; LP v_S_42; LP v_I_40; 
LP v_S_39; LP v_S_37; LP v_I_35; 
LP v_S_34; LP v_S_32; LP v__25BUFFER_31; 
LP v_MV15257_30; LP v_I_28; LP v_S_27; 
LP v_S_25; LP v__2EDISPLAY_2E_24; LP v_I_22; 
LP v_S_21; LP v_S_19; LP v_REQUEST_18; 
LP v_LENGTH_17; LP v_LIMIT_16; LP v_I_14; 
LP v_S_13; LP v_S_11; LP v_DISPLAY_10; 
LP v_I_8; LP v_S_7; LP v_S_5; 
LP v_ARCS_2; LP v_GCONTEXT_1; LP v_DRAWABLE_0; 
LP v_FILL_2DP_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_DRAWABLE_0 = NEXT_VAR_ARG;
v_GCONTEXT_1 = NEXT_VAR_ARG;
v_ARCS_2 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 3) wna_low(real_argc,3);
if (real_argc > 4) wna_high(real_argc,4);
if (real_argc < 4) {
v_FILL_2DP_3 = NIL;
} else {
v_FILL_2DP_3 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
v_S_5 = v_DRAWABLE_0;
v_S_7 = v_DRAWABLE_0;
v_I_8 = (LP) 4;
v_DISPLAY_10 = ((LP) DEREF((v_DRAWABLE_0) + 2 * 4));
v_S_11 = v_DISPLAY_10;
v_S_13 = v_DISPLAY_10;
v_I_14 = (LP) 6;
t1 = ((LP) DEREF((v_DISPLAY_10) + 3 * 4));
t0 = (subtract((t1), ((LP) 24)));
v_LIMIT_16 = t0;
v_LENGTH_17 = ICALL(s_lsp_LENGTH) (1, v_ARCS_2);
if (v_FILL_2DP_3 != NIL) {
v_REQUEST_18 = (LP) 142;
} else {
v_REQUEST_18 = (LP) 136;
}
v_S_19 = v_DRAWABLE_0;
v_S_21 = v_DRAWABLE_0;
v_I_22 = (LP) 4;
v__2EDISPLAY_2E_24 = ((LP) DEREF((v_DRAWABLE_0) + 2 * 4));
v_S_25 = v__2EDISPLAY_2E_24;
v_S_27 = v__2EDISPLAY_2E_24;
v_I_28 = (LP) 22;
t2 = ((LP) DEREF((v__2EDISPLAY_2E_24) + 11 * 4));
if (t2 != NIL) {
ICALL(s_lsp_ERROR) (3, LREF(s_xlib_CLOSED_2DDISPLAY), LREF(s_key_DISPLAY), v__2EDISPLAY_2E_24);
}
ICALL(s_xlib_FORCE_2DGCONTEXT_2DCHANGES_2DINTERNAL) (1, v_GCONTEXT_1);
{
int real_argc;
BEGIN_MV_CALL(mv_holder5798,0);
v__25BUFFER_31 = v__2EDISPLAY_2E_24;
v_S_32 = v__25BUFFER_31;
v_S_34 = v__25BUFFER_31;
v_I_35 = (LP) 14;
t5 = ((LP) DEREF((v__25BUFFER_31) + 7 * 4));
t4 = (add((t5), ((LP) 320)));
v_S_37 = v__25BUFFER_31;
v_S_39 = v__25BUFFER_31;
v_I_40 = (LP) 6;
t6 = ((LP) DEREF((v__25BUFFER_31) + 3 * 4));
if (((int) (t4) >= (int) (t6))) {
ICALL(s_xlib_BUFFER_2DFLUSH) (1, v__25BUFFER_31);
}
v_S_42 = v__25BUFFER_31;
v_S_44 = v__25BUFFER_31;
v_I_45 = (LP) 14;
v_BUFFER_2DBOFFSET_47 = ((LP) DEREF((v__25BUFFER_31) + 7 * 4));
v_S_48 = v__25BUFFER_31;
v_S_50 = v__25BUFFER_31;
v_I_51 = (LP) 16;
v_BUFFER_2DBBUF_53 = ((LP) DEREF((v__25BUFFER_31) + 8 * 4));
v_S15258_54 = v_BUFFER_2DBOFFSET_47;
v_T15259_55 = v__2EDISPLAY_2E_24;
v_S_56 = v__2EDISPLAY_2E_24;
v_VALUE_57 = v_S15258_54;
v_S_59 = v__2EDISPLAY_2E_24;
v_N_60 = (LP) 10;
v_VALUE_61 = v_S15258_54;
((LP) (DEREF((v__2EDISPLAY_2E_24) + 5 * 4) = (LD) (v_S15258_54)));
t7 = (add((v_BUFFER_2DBOFFSET_47), ((LP) 0)));
v_I_65 = t7;
v_S15260_67 = v_REQUEST_18;
v_T15261_68 = v_BUFFER_2DBBUF_53;
v_T15262_69 = v_I_65;
((unsigned char (*)) (v_BUFFER_2DBBUF_53 - 1))[FX_TO_INT(v_I_65)] = (unsigned char)FX_TO_INT(v_REQUEST_18);
v_S_70 = v_DRAWABLE_0;
v_S_72 = v_DRAWABLE_0;
v_I_73 = (LP) 2;
v_V_75 = ((LP) DEREF((v_DRAWABLE_0) + 1 * 4));
t8 = (add((v_BUFFER_2DBOFFSET_47), ((LP) 8)));
v_I_77 = t8;
t9 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_77)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_53) - 1)) + FX_TO_INT(t9))) = (unsigned long) FX_TO_INT(v_V_75)));
v_S_79 = v_GCONTEXT_1;
v_S_81 = v_GCONTEXT_1;
v_I_82 = (LP) 2;
v_V_84 = ((LP) DEREF((v_GCONTEXT_1) + 1 * 4));
t10 = (add((v_BUFFER_2DBOFFSET_47), ((LP) 16)));
v_I_86 = t10;
t11 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_86)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_53) - 1)) + FX_TO_INT(t11))) = (unsigned long) FX_TO_INT(v_V_84)));
t13 = ICALL(s_lsp_ASH) (2, v_LENGTH_17, (LP) -2);
t12 = (add((t13), ((LP) 6)));
v_V_88 = t12;
t14 = (add((v_BUFFER_2DBOFFSET_47), ((LP) 4)));
v_I_90 = t14;
t15 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_90)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_53) - 1))+FX_TO_INT(t15))) = (unsigned short) FX_TO_INT(v_V_88)));
v__2EVALUE_2E_92 = v_V_88;
t16 = (add((v_BUFFER_2DBOFFSET_47), ((LP) 24)));
v__2EBOFFSET_2E_93 = t16;
v_BUFFER_2DBOFFSET_47 = v__2EBOFFSET_2E_93;
v__2EVALUE_2E_94 = v_BUFFER_2DBOFFSET_47;
v_N_96 = (LP) 0;
v_LENGTH_97 = ICALL(s_lsp_LENGTH) (1, v_ARCS_2);
goto t_TEST15263_99;
t_LOOP15264_98:;
t17 = (add((v_N_96), ((LP) 12)));
v_TMP15265_100 = t17;
v_N_96 = v_TMP15265_100;
t_TEST15263_99:;
t18 = (geq_p((v_N_96), (v_LENGTH_97)));
if (t18 != NIL) {
v_S15266_101 = v_BUFFER_2DBOFFSET_47;
v_T15267_102 = v_DISPLAY_10;
v_S_103 = v_DISPLAY_10;
v_VALUE_104 = v_S15266_101;
v_S_106 = v_DISPLAY_10;
v_N_107 = (LP) 14;
v_VALUE_108 = v_S15266_101;
t19 = ((LP) (DEREF((v_DISPLAY_10) + 7 * 4) = (LD) (v_S15266_101)));
v__2EVALUE_2E_150 = t19;
goto b_NIL_95;
}
t20 = (geq_p((v_BUFFER_2DBOFFSET_47), (v_LIMIT_16)));
if (t20 != NIL) {
v_S15268_110 = v_BUFFER_2DBOFFSET_47;
v_T15269_111 = v_DISPLAY_10;
v_S_112 = v_DISPLAY_10;
v_VALUE_113 = v_S15268_110;
v_S_115 = v_DISPLAY_10;
v_N_116 = (LP) 14;
v_VALUE_117 = v_S15268_110;
((LP) (DEREF((v_DISPLAY_10) + 7 * 4) = (LD) (v_S15268_110)));
ICALL(s_xlib_BUFFER_2DFLUSH) (1, v_DISPLAY_10);
v_S_119 = v_DISPLAY_10;
v_S_121 = v_DISPLAY_10;
v_I_122 = (LP) 14;
v__2EBOFFSET_2E_124 = ((LP) DEREF((v_DISPLAY_10) + 7 * 4));
v_BUFFER_2DBOFFSET_47 = v__2EBOFFSET_2E_124;
}
t21 = (add((v_N_96), ((LP) 0)));
v_V_125 = (vref((v_ARCS_2), (t21)));
t22 = (add((v_BUFFER_2DBOFFSET_47), ((LP) 0)));
v_I_127 = t22;
t23 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_127)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_53) - 1)) + FX_TO_INT(t23))) = (short) FX_TO_INT(v_V_125)));
t24 = (add((v_N_96), ((LP) 2)));
v_V_129 = (vref((v_ARCS_2), (t24)));
t25 = (add((v_BUFFER_2DBOFFSET_47), ((LP) 4)));
v_I_131 = t25;
t26 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_131)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_53) - 1)) + FX_TO_INT(t26))) = (short) FX_TO_INT(v_V_129)));
t27 = (add((v_N_96), ((LP) 4)));
v_V_133 = (vref((v_ARCS_2), (t27)));
t28 = (add((v_BUFFER_2DBOFFSET_47), ((LP) 8)));
v_I_135 = t28;
t29 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_135)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_53) - 1))+FX_TO_INT(t29))) = (unsigned short) FX_TO_INT(v_V_133)));
t30 = (add((v_N_96), ((LP) 6)));
v_V_137 = (vref((v_ARCS_2), (t30)));
t31 = (add((v_BUFFER_2DBOFFSET_47), ((LP) 12)));
v_I_139 = t31;
t32 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_139)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_53) - 1))+FX_TO_INT(t32))) = (unsigned short) FX_TO_INT(v_V_137)));
t34 = (add((v_N_96), ((LP) 8)));
t33 = (vref((v_ARCS_2), (t34)));
v_V_141 = ICALL(s_xlib_RADIANS_2D_3EINT16) (1, t33);
t35 = (add((v_BUFFER_2DBOFFSET_47), ((LP) 16)));
v_I_143 = t35;
t36 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_143)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_53) - 1)) + FX_TO_INT(t36))) = (short) FX_TO_INT(v_V_141)));
t38 = (add((v_N_96), ((LP) 10)));
t37 = (vref((v_ARCS_2), (t38)));
v_V_145 = ICALL(s_xlib_RADIANS_2D_3EINT16) (1, t37);
t39 = (add((v_BUFFER_2DBOFFSET_47), ((LP) 20)));
v_I_147 = t39;
t40 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_147)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_53) - 1)) + FX_TO_INT(t40))) = (short) FX_TO_INT(v_V_145)));
t41 = (add((v_BUFFER_2DBOFFSET_47), ((LP) 24)));
v__2EBOFFSET_2E_149 = t41;
v_BUFFER_2DBOFFSET_47 = v__2EBOFFSET_2E_149;
goto t_LOOP15264_98;
v__2EVALUE_2E_150 = NIL;
v__2EVALUE_2E_150 = v__2EVALUE_2E_150;
b_NIL_95:;
v_BUFFER_151 = v__2EDISPLAY_2E_24;
v_S_153 = v_BUFFER_151;
v_S_155 = v_BUFFER_151;
v_I_156 = (LP) 8;
v_X_158 = ((LP) DEREF((v_BUFFER_151) + 4 * 4));
t42 = (add((v_X_158), ((LP) 2)));
v_S15270_160 = ICALL(s_lsp_LDB_2D1) (3, (LP) 32, (LP) 0, t42);
v_T15271_161 = v_BUFFER_151;
v_S_162 = v_BUFFER_151;
v_VALUE_163 = v_S15270_160;
v_S_165 = v_BUFFER_151;
v_N_166 = (LP) 8;
v_VALUE_167 = v_S15270_160;
t43 = ((LP) (DEREF((v_BUFFER_151) + 4 * 4) = (LD) (v_S15270_160)));
SET_MV_RETURN_VALUE(mv_holder5798,0,t43);
if SV_RETURN_P(mv_holder5798) SET_MV_RETURN_COUNT(mv_holder5798,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder5798);
BEGIN_VAR_VALUES;
RESTIFY(v_MV15257_30,1,NEXT_VAR_VALUE(mv_holder5798));
END_VAR_VALUES;
END_MV_CALL;
ICALL(s_xlib_DISPLAY_2DINVOKE_2DAFTER_2DFUNCTION) (1, v__2EDISPLAY_2E_24);
t44 = ICALL(s_lsp_VALUES_2DLIST) (MV_CALL(argc,1), v_MV15257_30);
return(t44);
}
}

LP p_xlib_DRAW_2DARCS(va_alist) va_dcl
{
LP v_X_19; LP v_G15274_18; LP v_Y_16; 
LP v_X_15; LP v_X_13; LP v_X_11; 
LP v_X_9; LP v_X_7; LP v_KEY15273_6; 
LP v_KEY15272_5; LP v_ARCS_2; LP v_GCONTEXT_1; 
LP v_DRAWABLE_0; LP v_FILL_2DP_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_DRAWABLE_0 = NEXT_VAR_ARG;
v_GCONTEXT_1 = NEXT_VAR_ARG;
v_ARCS_2 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 3) wna_low(real_argc,3);
if (real_argc > 4) wna_high(real_argc,4);
if (real_argc < 4) {
v_FILL_2DP_3 = NIL;
} else {
v_FILL_2DP_3 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
v_KEY15272_5 = v_ARCS_2;
v_KEY15273_6 = v_KEY15272_5;
v_X_11 = v_KEY15273_6;
v_X_13 = v_X_11;
v_X_15 = v_X_11;
v_Y_16 = LREF(s_lsp_NIL);
v_G15274_18 = (((v_X_11) == (LREF(s_lsp_NIL))) ? T : NIL);
if (v_G15274_18 != NIL) {
t1 = v_G15274_18;
} else {
v_X_19 = v_X_11;
t1 = (OTHER_PTRP((v_X_11)) && (TAG((v_X_11)) == 15) ? T : NIL);
}
if (t1 != NIL) {
t0 = ICALL(s_xlib_DRAW_2DARCS_2DLIST) (MV_CALL(argc,4), v_DRAWABLE_0, v_GCONTEXT_1, v_ARCS_2, v_FILL_2DP_3);
return(t0);
} else {
v_X_7 = v_KEY15273_6;
v_X_9 = v_KEY15273_6;
if (OTHER_PTRP((v_KEY15273_6)) && ((HEADER((v_KEY15273_6)) & 3) == 0)) {
t0 = ICALL(s_xlib_DRAW_2DARCS_2DVECTOR) (MV_CALL(argc,4), v_DRAWABLE_0, v_GCONTEXT_1, v_ARCS_2, v_FILL_2DP_3);
return(t0);
} else {
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,3), LREF(k5799), v_KEY15272_5, LREF(k5800));
return(t0);
}
}
}

LP p_xlib_PUT_2DRAW_2DIMAGE(va_alist) va_dcl
{
LP v_VALUE_158; LP v_N_157; LP v_S_156; 
LP v_VALUE_154; LP v_S_153; LP v_T15312_152; 
LP v_S15311_151; LP v_X_149; LP v_I_147; 
LP v_S_146; LP v_S_144; LP v_BUFFER_142; 
LP v_I_140; LP v_A_139; LP v_V_138; 
LP v_T15310_137; LP v_T15309_136; LP v_T15308_135; 
LP v_S15307_134; LP v_I_132; LP v_A_131; 
LP v_V_130; LP v_T15306_129; LP v_T15305_128; 
LP v_S15304_127; LP v_I_125; LP v_A_124; 
LP v_V_123; LP v_I_121; LP v_A_120; 
LP v_V_119; LP v_I_117; LP v_A_116; 
LP v_V_115; LP v_I_113; LP v_A_112; 
LP v_V_111; LP v_I_109; LP v_A_108; 
LP v_V_107; LP v_I_105; LP v_A_104; 
LP v_V_103; LP v_I_101; LP v_S_100; 
LP v_S_98; LP v_I_96; LP v_A_95; 
LP v_V_94; LP v_I_92; LP v_S_91; 
LP v_S_89; LP v_T15303_88; LP v_T15302_87; 
LP v_S15301_86; LP v_I_84; LP v_A_83; 
LP v_V_82; LP v_I_80; LP v_A_79; 
LP v_V_78; LP v_X_76; LP v_T15291_75; 
LP v_T15290_74; LP v_S15289_73; LP v_I_71; 
LP v_A_70; LP v_V_69; LP v_VALUE_67; 
LP v_N_66; LP v_S_65; LP v_VALUE_63; 
LP v_S_62; LP v_T15288_61; LP v_S15287_60; 
LP v_BUFFER_2DBBUF_59; LP v_I_57; LP v_S_56; 
LP v_S_54; LP v_BUFFER_2DBOFFSET_53; LP v_I_51; 
LP v_S_50; LP v_S_48; LP v_I_46; 
LP v_S_45; LP v_S_43; LP v_I_41; 
LP v_S_40; LP v_S_38; LP v__25BUFFER_37; 
LP v_MV15286_36; LP v_I_34; LP v_S_33; 
LP v_S_31; LP v__2EDISPLAY_2E_30; LP v_I_28; 
LP v_S_27; LP v_S_25; LP v_DATA_2; 
LP v_GCONTEXT_1; LP v_DRAWABLE_0; LP v_KEYS15275_23; 
LP v_SYMBOL_21; LP v_FORMAT_20; LP v_LEFT_2DPAD_19; 
LP v_SYMBOL_17; LP v_HEIGHT_16; LP v_SYMBOL_14; 
LP v_WIDTH_13; LP v_SYMBOL_11; LP v_Y_10; 
LP v_SYMBOL_8; LP v_X_7; LP v_SYMBOL_5; 
LP v_DEPTH_4; LP v_START_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_DRAWABLE_0 = NEXT_VAR_ARG;
v_GCONTEXT_1 = NEXT_VAR_ARG;
v_DATA_2 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 3) wna_low(real_argc,3);
DYNAMIC_RESTIFY(v_KEYS15275_23,4,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_START_3,LREF(s_key_START),v_KEYS15275_23)
v_START_3 = (LP) 0;
END_KEY_INIT
BEGIN_KEY_INIT(v_DEPTH_4,LREF(s_key_DEPTH),v_KEYS15275_23)
ICALL(s_lsp_ERROR) (3, LREF(s_xlib_MISSING_2DPARAMETER), LREF(s_key_PARAMETER), LREF(s_xlib_DEPTH));
v_SYMBOL_5 = LREF(s_xlib__2AREQUIRED_2DARG_2DDUMMY_2A);
t0 = ((LP) DEREF((v_SYMBOL_5) + 0 * 4));
v_DEPTH_4 = t0;
END_KEY_INIT
BEGIN_KEY_INIT(v_X_7,LREF(s_key_X),v_KEYS15275_23)
ICALL(s_lsp_ERROR) (3, LREF(s_xlib_MISSING_2DPARAMETER), LREF(s_key_PARAMETER), LREF(s_xlib_X));
v_SYMBOL_8 = LREF(s_xlib__2AREQUIRED_2DARG_2DDUMMY_2A);
t1 = ((LP) DEREF((v_SYMBOL_8) + 0 * 4));
v_X_7 = t1;
END_KEY_INIT
BEGIN_KEY_INIT(v_Y_10,LREF(s_key_Y),v_KEYS15275_23)
ICALL(s_lsp_ERROR) (3, LREF(s_xlib_MISSING_2DPARAMETER), LREF(s_key_PARAMETER), LREF(s_xlib_Y));
v_SYMBOL_11 = LREF(s_xlib__2AREQUIRED_2DARG_2DDUMMY_2A);
t2 = ((LP) DEREF((v_SYMBOL_11) + 0 * 4));
v_Y_10 = t2;
END_KEY_INIT
BEGIN_KEY_INIT(v_WIDTH_13,LREF(s_key_WIDTH),v_KEYS15275_23)
ICALL(s_lsp_ERROR) (3, LREF(s_xlib_MISSING_2DPARAMETER), LREF(s_key_PARAMETER), LREF(s_xlib_WIDTH));
v_SYMBOL_14 = LREF(s_xlib__2AREQUIRED_2DARG_2DDUMMY_2A);
t3 = ((LP) DEREF((v_SYMBOL_14) + 0 * 4));
v_WIDTH_13 = t3;
END_KEY_INIT
BEGIN_KEY_INIT(v_HEIGHT_16,LREF(s_key_HEIGHT),v_KEYS15275_23)
ICALL(s_lsp_ERROR) (3, LREF(s_xlib_MISSING_2DPARAMETER), LREF(s_key_PARAMETER), LREF(s_xlib_HEIGHT));
v_SYMBOL_17 = LREF(s_xlib__2AREQUIRED_2DARG_2DDUMMY_2A);
t4 = ((LP) DEREF((v_SYMBOL_17) + 0 * 4));
v_HEIGHT_16 = t4;
END_KEY_INIT
BEGIN_KEY_INIT(v_LEFT_2DPAD_19,LREF(s_key_LEFT_2DPAD),v_KEYS15275_23)
v_LEFT_2DPAD_19 = (LP) 0;
END_KEY_INIT
BEGIN_KEY_INIT(v_FORMAT_20,LREF(s_key_FORMAT),v_KEYS15275_23)
ICALL(s_lsp_ERROR) (3, LREF(s_xlib_MISSING_2DPARAMETER), LREF(s_key_PARAMETER), LREF(s_lsp_FORMAT));
v_SYMBOL_21 = LREF(s_xlib__2AREQUIRED_2DARG_2DDUMMY_2A);
t5 = ((LP) DEREF((v_SYMBOL_21) + 0 * 4));
v_FORMAT_20 = t5;
END_KEY_INIT
END_VAR_ARGS;
v_S_25 = v_DRAWABLE_0;
v_S_27 = v_DRAWABLE_0;
v_I_28 = (LP) 4;
v__2EDISPLAY_2E_30 = ((LP) DEREF((v_DRAWABLE_0) + 2 * 4));
v_S_31 = v__2EDISPLAY_2E_30;
v_S_33 = v__2EDISPLAY_2E_30;
v_I_34 = (LP) 22;
t6 = ((LP) DEREF((v__2EDISPLAY_2E_30) + 11 * 4));
if (t6 != NIL) {
ICALL(s_lsp_ERROR) (3, LREF(s_xlib_CLOSED_2DDISPLAY), LREF(s_key_DISPLAY), v__2EDISPLAY_2E_30);
}
ICALL(s_xlib_FORCE_2DGCONTEXT_2DCHANGES_2DINTERNAL) (1, v_GCONTEXT_1);
{
int real_argc;
BEGIN_MV_CALL(mv_holder5802,0);
v__25BUFFER_37 = v__2EDISPLAY_2E_30;
v_S_38 = v__25BUFFER_37;
v_S_40 = v__25BUFFER_37;
v_I_41 = (LP) 14;
t9 = ((LP) DEREF((v__25BUFFER_37) + 7 * 4));
t8 = (add((t9), ((LP) 320)));
v_S_43 = v__25BUFFER_37;
v_S_45 = v__25BUFFER_37;
v_I_46 = (LP) 6;
t10 = ((LP) DEREF((v__25BUFFER_37) + 3 * 4));
if (((int) (t8) >= (int) (t10))) {
ICALL(s_xlib_BUFFER_2DFLUSH) (1, v__25BUFFER_37);
}
v_S_48 = v__25BUFFER_37;
v_S_50 = v__25BUFFER_37;
v_I_51 = (LP) 14;
v_BUFFER_2DBOFFSET_53 = ((LP) DEREF((v__25BUFFER_37) + 7 * 4));
v_S_54 = v__25BUFFER_37;
v_S_56 = v__25BUFFER_37;
v_I_57 = (LP) 16;
v_BUFFER_2DBBUF_59 = ((LP) DEREF((v__25BUFFER_37) + 8 * 4));
v_S15287_60 = v_BUFFER_2DBOFFSET_53;
v_T15288_61 = v__2EDISPLAY_2E_30;
v_S_62 = v__2EDISPLAY_2E_30;
v_VALUE_63 = v_BUFFER_2DBOFFSET_53;
v_S_65 = v__2EDISPLAY_2E_30;
v_N_66 = (LP) 10;
v_VALUE_67 = v_BUFFER_2DBOFFSET_53;
((LP) (DEREF((v__2EDISPLAY_2E_30) + 5 * 4) = (LD) (v_BUFFER_2DBOFFSET_53)));
t11 = (add((v_BUFFER_2DBOFFSET_53), ((LP) 0)));
v_I_71 = t11;
v_S15289_73 = (LP) 144;
v_T15290_74 = v_BUFFER_2DBBUF_59;
v_T15291_75 = v_I_71;
((unsigned char (*)) (v_BUFFER_2DBBUF_59 - 1))[FX_TO_INT(v_I_71)] = (unsigned char)FX_TO_INT((LP) 144);
v_X_76 = LREF(s_lsp_EQ);
t12 = ((LP) DEREF((LREF(s_lsp_EQ)) + 4 * 4));
v_V_78 = ICALL(s_lsp_POSITION) (4, v_FORMAT_20, LREF(k5803), LREF(s_key_TEST), t12);
t13 = (add((v_BUFFER_2DBOFFSET_53), ((LP) 8)));
v_I_80 = t13;
t14 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_80)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_59) - 1)) + FX_TO_INT(t14))) = (unsigned long) FX_TO_INT(v_V_78)));
v_V_82 = v_V_78;
t15 = (add((v_BUFFER_2DBOFFSET_53), ((LP) 2)));
v_I_84 = t15;
v_S15301_86 = v_V_82;
v_T15302_87 = v_BUFFER_2DBBUF_59;
v_T15303_88 = v_I_84;
((unsigned char (*)) (v_BUFFER_2DBBUF_59 - 1))[FX_TO_INT(v_I_84)] = (unsigned char)FX_TO_INT(v_V_82);
v_S_89 = v_DRAWABLE_0;
v_S_91 = v_DRAWABLE_0;
v_I_92 = (LP) 2;
v_V_94 = ((LP) DEREF((v_DRAWABLE_0) + 1 * 4));
t16 = (add((v_BUFFER_2DBOFFSET_53), ((LP) 8)));
v_I_96 = t16;
t17 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_96)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_59) - 1)) + FX_TO_INT(t17))) = (unsigned long) FX_TO_INT(v_V_94)));
v_S_98 = v_GCONTEXT_1;
v_S_100 = v_GCONTEXT_1;
v_I_101 = (LP) 2;
v_V_103 = ((LP) DEREF((v_GCONTEXT_1) + 1 * 4));
t18 = (add((v_BUFFER_2DBOFFSET_53), ((LP) 16)));
v_I_105 = t18;
t19 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_105)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_59) - 1)) + FX_TO_INT(t19))) = (unsigned long) FX_TO_INT(v_V_103)));
v_V_107 = v_WIDTH_13;
t20 = (add((v_BUFFER_2DBOFFSET_53), ((LP) 24)));
v_I_109 = t20;
t21 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_109)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_59) - 1))+FX_TO_INT(t21))) = (unsigned short) FX_TO_INT(v_V_107)));
v_V_111 = v_HEIGHT_16;
t22 = (add((v_BUFFER_2DBOFFSET_53), ((LP) 28)));
v_I_113 = t22;
t23 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_113)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_59) - 1))+FX_TO_INT(t23))) = (unsigned short) FX_TO_INT(v_V_111)));
v_V_115 = v_X_7;
t24 = (add((v_BUFFER_2DBOFFSET_53), ((LP) 32)));
v_I_117 = t24;
t25 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_117)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_59) - 1)) + FX_TO_INT(t25))) = (short) FX_TO_INT(v_V_115)));
v_V_119 = v_Y_10;
t26 = (add((v_BUFFER_2DBOFFSET_53), ((LP) 36)));
v_I_121 = t26;
t27 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_121)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_59) - 1)) + FX_TO_INT(t27))) = (short) FX_TO_INT(v_V_119)));
t28 = (add((v_BUFFER_2DBOFFSET_53), ((LP) 40)));
v_I_125 = t28;
v_S15304_127 = v_LEFT_2DPAD_19;
v_T15305_128 = v_BUFFER_2DBBUF_59;
v_T15306_129 = v_I_125;
((unsigned char (*)) (v_BUFFER_2DBBUF_59 - 1))[FX_TO_INT(v_I_125)] = (unsigned char)FX_TO_INT(v_LEFT_2DPAD_19);
t29 = (add((v_BUFFER_2DBOFFSET_53), ((LP) 42)));
v_I_132 = t29;
v_S15307_134 = v_DEPTH_4;
v_T15308_135 = v_BUFFER_2DBBUF_59;
v_T15309_136 = v_I_132;
((unsigned char (*)) (v_BUFFER_2DBBUF_59 - 1))[FX_TO_INT(v_I_132)] = (unsigned char)FX_TO_INT(v_DEPTH_4);
v_T15310_137 = ICALL(s_lsp_LENGTH) (1, v_DATA_2);
t32 = (subtract((v_T15310_137), (v_START_3)));
t31 = ICALL(s_lsp_CEILING) (2, t32, (LP) 8);
t30 = (add((t31), ((LP) 12)));
v_V_138 = t30;
t33 = (add((v_BUFFER_2DBOFFSET_53), ((LP) 4)));
v_I_140 = t33;
t34 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_140)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_59) - 1))+FX_TO_INT(t34))) = (unsigned short) FX_TO_INT(v_V_138)));
t35 = (add((v_BUFFER_2DBOFFSET_53), ((LP) 48)));
ICALL(s_xlib_WRITE_2DSEQUENCE_2DCARD8) (6, v__25BUFFER_37, t35, v_DATA_2, v_START_3, v_T15310_137, LREF(s_lsp_NIL));
v_BUFFER_142 = v__2EDISPLAY_2E_30;
v_S_144 = v_BUFFER_142;
v_S_146 = v_BUFFER_142;
v_I_147 = (LP) 8;
v_X_149 = ((LP) DEREF((v_BUFFER_142) + 4 * 4));
t36 = (add((v_X_149), ((LP) 2)));
v_S15311_151 = ICALL(s_lsp_LDB_2D1) (3, (LP) 32, (LP) 0, t36);
v_T15312_152 = v_BUFFER_142;
v_S_153 = v_BUFFER_142;
v_VALUE_154 = v_S15311_151;
v_S_156 = v_BUFFER_142;
v_N_157 = (LP) 8;
v_VALUE_158 = v_S15311_151;
t37 = ((LP) (DEREF((v_BUFFER_142) + 4 * 4) = (LD) (v_S15311_151)));
SET_MV_RETURN_VALUE(mv_holder5802,0,t37);
if SV_RETURN_P(mv_holder5802) SET_MV_RETURN_COUNT(mv_holder5802,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder5802);
BEGIN_VAR_VALUES;
RESTIFY(v_MV15286_36,1,NEXT_VAR_VALUE(mv_holder5802));
END_VAR_VALUES;
END_MV_CALL;
ICALL(s_xlib_DISPLAY_2DINVOKE_2DAFTER_2DFUNCTION) (1, v__2EDISPLAY_2E_30);
t38 = ICALL(s_lsp_VALUES_2DLIST) (MV_CALL(argc,1), v_MV15286_36);
return(t38);
}
}

LP p_xlib_GET_2DRAW_2DIMAGE(va_alist) va_dcl
{
LP v_VISUAL_168; LP v_LENGTH_167; LP v_DEPTH_166; 
LP v_I_164; LP v_A_163; LP v_I_161; 
LP v_A_160; LP v_I_158; LP v_A_157; 
LP v_BUFFER_2DBBUF_156; LP v_I_154; LP v_S_153; 
LP v_S_151; LP v_BUFFER_2DBOFFSET_150; LP v__25BUFFER_149; 
LP v__25REPLY_2DBUFFER_148; LP v_VALUE_146; LP v_N_145; 
LP v_S_144; LP v_VALUE_142; LP v_S_141; 
LP v_T15344_140; LP v_S15343_139; LP v_X_137; 
LP v_I_135; LP v_S_134; LP v_S_132; 
LP v_BUFFER_130; LP v_VALUE_128; LP v_N_127; 
LP v_S_126; LP v_VALUE_124; LP v_S_123; 
LP v_T15342_122; LP v_S15341_121; LP v_I_119; 
LP v_A_118; LP v_V_117; LP v_I_115; 
LP v_A_114; LP v_V_113; LP v_I_111; 
LP v_A_110; LP v_V_109; LP v_I_107; 
LP v_A_106; LP v_V_105; LP v_I_103; 
LP v_A_102; LP v_V_101; LP v_I_99; 
LP v_A_98; LP v_V_97; LP v_I_95; 
LP v_A_94; LP v_V_93; LP v_I_91; 
LP v_S_90; LP v_S_88; LP v_T15340_87; 
LP v_T15339_86; LP v_S15338_85; LP v_I_83; 
LP v_A_82; LP v_V_81; LP v_I_79; 
LP v_A_78; LP v_V_77; LP v_X_75; 
LP v_T15328_74; LP v_T15327_73; LP v_S15326_72; 
LP v_I_70; LP v_A_69; LP v_V_68; 
LP v_VALUE_66; LP v_N_65; LP v_S_64; 
LP v_VALUE_62; LP v_S_61; LP v_T15325_60; 
LP v_S15324_59; LP v_BUFFER_2DBBUF_58; LP v_I_56; 
LP v_S_55; LP v_S_53; LP v_BUFFER_2DBOFFSET_52; 
LP v_I_50; LP v_S_49; LP v_S_47; 
LP v_I_45; LP v_S_44; LP v_S_42; 
LP v_I_40; LP v_S_39; LP v_S_37; 
LP v__25BUFFER_36; LP v_I_34; LP v_S_33; 
LP v_S_31; LP v__2EREPLY_2DBUFFER_2E_30; LP v__2EPENDING_2DCOMMAND_2E_29; 
LP v__2EDISPLAY_2E_28; LP v_DISPLAY_27; LP v_I_25; 
LP v_S_24; LP v_S_22; LP v_DRAWABLE_0; 
LP v_KEYS15313_20; LP v_RESULT_2DTYPE_19; LP v_SYMBOL_17; 
LP v_FORMAT_16; LP v_PLANE_2DMASK_15; LP v_SYMBOL_13; 
LP v_HEIGHT_12; LP v_SYMBOL_10; LP v_WIDTH_9; 
LP v_SYMBOL_7; LP v_Y_6; LP v_SYMBOL_4; 
LP v_X_3; LP v_START_2; LP v_DATA_1; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_DRAWABLE_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
DYNAMIC_RESTIFY(v_KEYS15313_20,2,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_DATA_1,LREF(s_key_DATA),v_KEYS15313_20)
v_DATA_1 = NIL;
END_KEY_INIT
BEGIN_KEY_INIT(v_START_2,LREF(s_key_START),v_KEYS15313_20)
v_START_2 = (LP) 0;
END_KEY_INIT
BEGIN_KEY_INIT(v_X_3,LREF(s_key_X),v_KEYS15313_20)
ICALL(s_lsp_ERROR) (3, LREF(s_xlib_MISSING_2DPARAMETER), LREF(s_key_PARAMETER), LREF(s_xlib_X));
v_SYMBOL_4 = LREF(s_xlib__2AREQUIRED_2DARG_2DDUMMY_2A);
t0 = ((LP) DEREF((v_SYMBOL_4) + 0 * 4));
v_X_3 = t0;
END_KEY_INIT
BEGIN_KEY_INIT(v_Y_6,LREF(s_key_Y),v_KEYS15313_20)
ICALL(s_lsp_ERROR) (3, LREF(s_xlib_MISSING_2DPARAMETER), LREF(s_key_PARAMETER), LREF(s_xlib_Y));
v_SYMBOL_7 = LREF(s_xlib__2AREQUIRED_2DARG_2DDUMMY_2A);
t1 = ((LP) DEREF((v_SYMBOL_7) + 0 * 4));
v_Y_6 = t1;
END_KEY_INIT
BEGIN_KEY_INIT(v_WIDTH_9,LREF(s_key_WIDTH),v_KEYS15313_20)
ICALL(s_lsp_ERROR) (3, LREF(s_xlib_MISSING_2DPARAMETER), LREF(s_key_PARAMETER), LREF(s_xlib_WIDTH));
v_SYMBOL_10 = LREF(s_xlib__2AREQUIRED_2DARG_2DDUMMY_2A);
t2 = ((LP) DEREF((v_SYMBOL_10) + 0 * 4));
v_WIDTH_9 = t2;
END_KEY_INIT
BEGIN_KEY_INIT(v_HEIGHT_12,LREF(s_key_HEIGHT),v_KEYS15313_20)
ICALL(s_lsp_ERROR) (3, LREF(s_xlib_MISSING_2DPARAMETER), LREF(s_key_PARAMETER), LREF(s_xlib_HEIGHT));
v_SYMBOL_13 = LREF(s_xlib__2AREQUIRED_2DARG_2DDUMMY_2A);
t3 = ((LP) DEREF((v_SYMBOL_13) + 0 * 4));
v_HEIGHT_12 = t3;
END_KEY_INIT
BEGIN_KEY_INIT(v_PLANE_2DMASK_15,LREF(s_key_PLANE_2DMASK),v_KEYS15313_20)
v_PLANE_2DMASK_15 = LREF(k5804);
END_KEY_INIT
BEGIN_KEY_INIT(v_FORMAT_16,LREF(s_key_FORMAT),v_KEYS15313_20)
ICALL(s_lsp_ERROR) (3, LREF(s_xlib_MISSING_2DPARAMETER), LREF(s_key_PARAMETER), LREF(s_lsp_FORMAT));
v_SYMBOL_17 = LREF(s_xlib__2AREQUIRED_2DARG_2DDUMMY_2A);
t4 = ((LP) DEREF((v_SYMBOL_17) + 0 * 4));
v_FORMAT_16 = t4;
END_KEY_INIT
BEGIN_KEY_INIT(v_RESULT_2DTYPE_19,LREF(s_key_RESULT_2DTYPE),v_KEYS15313_20)
v_RESULT_2DTYPE_19 = LREF(k5805);
END_KEY_INIT
END_VAR_ARGS;
v_S_22 = v_DRAWABLE_0;
v_S_24 = v_DRAWABLE_0;
v_I_25 = (LP) 4;
v_DISPLAY_27 = ((LP) DEREF((v_DRAWABLE_0) + 2 * 4));
v__2EDISPLAY_2E_28 = v_DISPLAY_27;
v__2EPENDING_2DCOMMAND_2E_29 = LREF(s_lsp_NIL);
v__2EREPLY_2DBUFFER_2E_30 = LREF(s_lsp_NIL);
BEGIN_UW_PROTECT_BODY
v_S_31 = v__2EDISPLAY_2E_28;
v_S_33 = v__2EDISPLAY_2E_28;
v_I_34 = (LP) 22;
t5 = ((LP) DEREF((v__2EDISPLAY_2E_28) + 11 * 4));
if (t5 != NIL) {
ICALL(s_lsp_ERROR) (3, LREF(s_xlib_CLOSED_2DDISPLAY), LREF(s_key_DISPLAY), v__2EDISPLAY_2E_28);
}
v__2EPENDING_2DCOMMAND_2E_29 = ICALL(s_xlib_START_2DPENDING_2DCOMMAND) (1, v__2EDISPLAY_2E_28);
v__25BUFFER_36 = v__2EDISPLAY_2E_28;
v_S_37 = v__25BUFFER_36;
v_S_39 = v__25BUFFER_36;
v_I_40 = (LP) 14;
t8 = ((LP) DEREF((v__25BUFFER_36) + 7 * 4));
t7 = (add((t8), ((LP) 320)));
v_S_42 = v__25BUFFER_36;
v_S_44 = v__25BUFFER_36;
v_I_45 = (LP) 6;
t9 = ((LP) DEREF((v__25BUFFER_36) + 3 * 4));
if (((int) (t7) >= (int) (t9))) {
ICALL(s_xlib_BUFFER_2DFLUSH) (1, v__25BUFFER_36);
}
v_S_47 = v__25BUFFER_36;
v_S_49 = v__25BUFFER_36;
v_I_50 = (LP) 14;
v_BUFFER_2DBOFFSET_52 = ((LP) DEREF((v__25BUFFER_36) + 7 * 4));
v_S_53 = v__25BUFFER_36;
v_S_55 = v__25BUFFER_36;
v_I_56 = (LP) 16;
v_BUFFER_2DBBUF_58 = ((LP) DEREF((v__25BUFFER_36) + 8 * 4));
v_S15324_59 = v_BUFFER_2DBOFFSET_52;
v_T15325_60 = v__2EDISPLAY_2E_28;
v_S_61 = v__2EDISPLAY_2E_28;
v_VALUE_62 = v_BUFFER_2DBOFFSET_52;
v_S_64 = v__2EDISPLAY_2E_28;
v_N_65 = (LP) 10;
v_VALUE_66 = v_BUFFER_2DBOFFSET_52;
((LP) (DEREF((v__2EDISPLAY_2E_28) + 5 * 4) = (LD) (v_BUFFER_2DBOFFSET_52)));
t10 = (add((v_BUFFER_2DBOFFSET_52), ((LP) 0)));
v_I_70 = t10;
v_S15326_72 = (LP) 146;
v_T15327_73 = v_BUFFER_2DBBUF_58;
v_T15328_74 = v_I_70;
((unsigned char (*)) (v_BUFFER_2DBBUF_58 - 1))[FX_TO_INT(v_I_70)] = (unsigned char)FX_TO_INT((LP) 146);
v_X_75 = LREF(s_lsp_EQ);
t11 = ((LP) DEREF((LREF(s_lsp_EQ)) + 4 * 4));
v_V_77 = ICALL(s_lsp_POSITION) (4, v_FORMAT_16, LREF(k5807), LREF(s_key_TEST), t11);
t12 = (add((v_BUFFER_2DBOFFSET_52), ((LP) 8)));
v_I_79 = t12;
t13 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_79)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_58) - 1)) + FX_TO_INT(t13))) = (unsigned long) FX_TO_INT(v_V_77)));
v_V_81 = v_V_77;
t14 = (add((v_BUFFER_2DBOFFSET_52), ((LP) 2)));
v_I_83 = t14;
v_S15338_85 = v_V_81;
v_T15339_86 = v_BUFFER_2DBBUF_58;
v_T15340_87 = v_I_83;
((unsigned char (*)) (v_BUFFER_2DBBUF_58 - 1))[FX_TO_INT(v_I_83)] = (unsigned char)FX_TO_INT(v_V_81);
v_S_88 = v_DRAWABLE_0;
v_S_90 = v_DRAWABLE_0;
v_I_91 = (LP) 2;
v_V_93 = ((LP) DEREF((v_DRAWABLE_0) + 1 * 4));
t15 = (add((v_BUFFER_2DBOFFSET_52), ((LP) 8)));
v_I_95 = t15;
t16 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_95)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_58) - 1)) + FX_TO_INT(t16))) = (unsigned long) FX_TO_INT(v_V_93)));
v_V_97 = v_X_3;
t17 = (add((v_BUFFER_2DBOFFSET_52), ((LP) 16)));
v_I_99 = t17;
t18 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_99)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_58) - 1)) + FX_TO_INT(t18))) = (short) FX_TO_INT(v_V_97)));
v_V_101 = v_Y_6;
t19 = (add((v_BUFFER_2DBOFFSET_52), ((LP) 20)));
v_I_103 = t19;
t20 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_103)) >> (1)));
((LP) ((*(((short *) ((int) (v_BUFFER_2DBBUF_58) - 1)) + FX_TO_INT(t20))) = (short) FX_TO_INT(v_V_101)));
v_V_105 = v_WIDTH_9;
t21 = (add((v_BUFFER_2DBOFFSET_52), ((LP) 24)));
v_I_107 = t21;
t22 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_107)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_58) - 1))+FX_TO_INT(t22))) = (unsigned short) FX_TO_INT(v_V_105)));
v_V_109 = v_HEIGHT_12;
t23 = (add((v_BUFFER_2DBOFFSET_52), ((LP) 28)));
v_I_111 = t23;
t24 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_111)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_58) - 1))+FX_TO_INT(t24))) = (unsigned short) FX_TO_INT(v_V_109)));
v_V_113 = v_PLANE_2DMASK_15;
t25 = (add((v_BUFFER_2DBOFFSET_52), ((LP) 32)));
v_I_115 = t25;
t26 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_115)) >> (2)));
((LP) ((*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_58) - 1)) + FX_TO_INT(t26))) = (unsigned long) INTEGER_TO_UINT32(v_V_113)));
v_V_117 = (LP) 10;
t27 = (add((v_BUFFER_2DBOFFSET_52), ((LP) 4)));
v_I_119 = t27;
t28 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_119)) >> (1)));
((LP) ((*(((unsigned short *) ((int)(v_BUFFER_2DBBUF_58) - 1))+FX_TO_INT(t28))) = (unsigned short) FX_TO_INT(v_V_117)));
t29 = (add((v_BUFFER_2DBOFFSET_52), ((LP) 40)));
v_S15341_121 = t29;
v_T15342_122 = v__2EDISPLAY_2E_28;
v_S_123 = v__2EDISPLAY_2E_28;
v_VALUE_124 = v_S15341_121;
v_S_126 = v__2EDISPLAY_2E_28;
v_N_127 = (LP) 14;
v_VALUE_128 = v_S15341_121;
((LP) (DEREF((v__2EDISPLAY_2E_28) + 7 * 4) = (LD) (v_S15341_121)));
v_BUFFER_130 = v__2EDISPLAY_2E_28;
v_S_132 = v_BUFFER_130;
v_S_134 = v_BUFFER_130;
v_I_135 = (LP) 8;
v_X_137 = ((LP) DEREF((v_BUFFER_130) + 4 * 4));
t30 = (add((v_X_137), ((LP) 2)));
v_S15343_139 = ICALL(s_lsp_LDB_2D1) (3, (LP) 32, (LP) 0, t30);
v_T15344_140 = v_BUFFER_130;
v_S_141 = v_BUFFER_130;
v_VALUE_142 = v_S15343_139;
v_S_144 = v_BUFFER_130;
v_N_145 = (LP) 8;
v_VALUE_146 = v_S15343_139;
((LP) (DEREF((v_BUFFER_130) + 4 * 4) = (LD) (v_S15343_139)));
ICALL(s_xlib_BUFFER_2DFORCE_2DOUTPUT) (1, v__2EDISPLAY_2E_28);
ICALL(s_xlib_DISPLAY_2DINVOKE_2DAFTER_2DFUNCTION) (1, v__2EDISPLAY_2E_28);
v__2EREPLY_2DBUFFER_2E_30 = ICALL(s_xlib_READ_2DREPLY) (2, v__2EDISPLAY_2E_28, v__2EPENDING_2DCOMMAND_2E_29);
v__25REPLY_2DBUFFER_148 = v__2EREPLY_2DBUFFER_2E_30;
v_BUFFER_2DBOFFSET_150 = (LP) 0;
v_S_151 = v__25REPLY_2DBUFFER_148;
v_S_153 = v__25REPLY_2DBUFFER_148;
v_I_154 = (LP) 4;
v_BUFFER_2DBBUF_156 = ((LP) DEREF((v__25REPLY_2DBUFFER_148) + 2 * 4));
t31 = (add((v_BUFFER_2DBOFFSET_150), ((LP) 2)));
v_I_158 = t31;
v_DEPTH_166 = (LP) INT_TO_FX(((unsigned char (*)) (v_BUFFER_2DBBUF_156 - 1))[FX_TO_INT(v_I_158)]);
t32 = (add((v_BUFFER_2DBOFFSET_150), ((LP) 8)));
v_I_161 = t32;
t34 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_161)) >> (2)));
t33 = UINT32_TO_INTEGER((LP) (*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_156) - 1)) + FX_TO_INT(t34))));
v_LENGTH_167 = (multiply(((LP) 8), (t33)));
t35 = (add((v_BUFFER_2DBOFFSET_150), ((LP) 16)));
v_I_164 = t35;
t36 = INT_TO_FX(((unsigned long) (FX_TO_INT(v_I_164)) >> (2)));
v_VISUAL_168 = INT_TO_FX((LP) (*(((unsigned long *) ((int) (v_BUFFER_2DBBUF_156) - 1)) + FX_TO_INT(t36))));
t37 = ICALL(s_xlib_READ_2DSEQUENCE_2DCARD8) (7, v__25REPLY_2DBUFFER_148, v_RESULT_2DTYPE_19, v_LENGTH_167, LREF(s_lsp_NIL), v_DATA_1, v_START_2, (LP) 64);
t38 = ICALL(s_xlib_VISUAL_2DINFO) (2, v_DISPLAY_27, v_VISUAL_168);
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,3);
SET_MV_RETURN_VALUE(argc,1,v_DEPTH_166);
SET_MV_RETURN_VALUE(argc,2,t38);
}
BEGIN_UW_PROTECT_CLEANUP
if (v__2EREPLY_2DBUFFER_2E_30 != NIL) {
ICALL(s_xlib_DEALLOCATE_2DREPLY_2DBUFFER) (1, v__2EREPLY_2DBUFFER_2E_30);
}
if (v__2EPENDING_2DCOMMAND_2E_29 != NIL) {
t39 = ICALL(s_xlib_STOP_2DPENDING_2DCOMMAND) (2, v__2EDISPLAY_2E_28, v__2EPENDING_2DCOMMAND_2E_29);
} else {
t39 = LREF(s_lsp_NIL);
}
CONTINUE_FROM_PROTECT
return(t37);
}

LP p_xlib_GRAPHICS_5FINIT312(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
t0 = ICALL(s_lsp_DEFINE_2DVARIABLE) (MV_CALL(argc,4), LREF(s_xlib__2AINHIBIT_2DAPPENDING_2A), LREF(s_lsp_NIL), LREF(s_lsp_NIL), LREF(s_key_VAR));
return(t0);
}

