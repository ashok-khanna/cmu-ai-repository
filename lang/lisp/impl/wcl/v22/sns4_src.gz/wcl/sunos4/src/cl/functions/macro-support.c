/*
:comment "Compiled at 4:12:16 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: Debug Library"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O2 -fPIC"
:version 0
:end-package-info 0
:sym NIL
:sf COLLECT "p_lsp_COLLECT"
:sym *COMPILER-MACRO-EXPANDERS*
:sym UNSAFE-SYMBOL-VALUE
:sym GETHASH
:sf COMPILER-MACRO-FUNCTION "p_lsp_COMPILER_2DMACRO_2DFUNCTION"
:sym EXPAND-MACRO
:sf COMPILER-MACROEXPAND-1 "p_lsp_COMPILER_2DMACROEXPAND_2D1"
:sym COMPILER-MACROEXPAND
:sf COMPILER-MACROEXPAND-W "p_lsp_COMPILER_2DMACROEXPAND_2DW"
:sym T
:sf COMPILER-MACROEXPAND "p_lsp_COMPILER_2DMACROEXPAND"
:sym NULL
:sym *MACRO-EXPANDERS*
:sym EQ
:sym SET-MACRO-NAME-FLAG
:sym SET-SYMBOL-FUNCTION
:sym :EXPANSION-FUNCTION
:sym :ORIGINAL-ARG-LIST
:sym SET-GETHASH
:sf DEFINE-MACRO-FUNCTION "p_lsp_DEFINE_2DMACRO_2DFUNCTION"
:sym *SETF-METHODS*
:sf DEFINE-SETF "p_lsp_DEFINE_2DSETF"
:sym EVERY-N
:sf EVERY-EVEN "p_lsp_EVERY_2DEVEN"
:sym 1-
:sf EVERY-N "p_lsp_EVERY_2DN"
:sf EVERY-ODD "p_lsp_EVERY_2DODD"
:sym ATOM
:sym LOOKUP-SYMBOL-MACRO-DEF
:sym LOOKUP-MACRO-EXPANDER
:sym *MACROEXPAND-HOOK*
:sym NOT
:sf EXPAND-MACRO "p_lsp_EXPAND_2DMACRO"
:sym ASSQ
:sf LOOKUP-MACRO-EXPANDER "p_lsp_LOOKUP_2DMACRO_2DEXPANDER"
:sf LOOKUP-SYMBOL-MACRO-DEF "p_lsp_LOOKUP_2DSYMBOL_2DMACRO_2DDEF"
:sym GET-SETF-METHOD-1
:sf GET-SETF-METHOD-W "p_lsp_GET_2DSETF_2DMETHOD_2DW"
:sf GET-SETF-METHOD "p_lsp_GET_2DSETF_2DMETHOD"
:sym SYMBOLP
:sym GENSYM
:sym SETQ
:sym LISTP
:sym APPEND/2
:sym *DELAY-STRUCTURE-DEFS?*
:sym COMPLETE-DELAYED-DEFSTRUCTS
:sym GET-SETF-METHOD-W
:sym ERROR
:sym MACROEXPAND-W
:sym SYMBOL
:sym LIST
:sf GET-SETF-METHOD-1 "p_lsp_GET_2DSETF_2DMETHOD_2D1"
:sym &OPTIONAL
:sym &REST
:sym &RESTV
:sym &KEY
:sym &ALLOW-OTHER-KEYS
:sym &AUX
:sym &WHOLE
:sym &ENVIRONMENT
:sym &BODY
:sym MEMQ
:sf INSERT-OPTIONAL-DEFAULT "p_lsp_INSERT_2DOPTIONAL_2DDEFAULT"
:sf MACRO-ARG-LIST "p_lsp_MACRO_2DARG_2DLIST"
:sf MACRO-FUNCTION "p_lsp_MACRO_2DFUNCTION"
:sf MACROEXPAND-1 "p_lsp_MACROEXPAND_2D1"
:sf MACROEXPAND-1-W "p_lsp_MACROEXPAND_2D1_2DW"
:sf MACROEXPAND-W "p_lsp_MACROEXPAND_2DW"
:sf MACROEXPAND "p_lsp_MACROEXPAND"
:sym N-LIST
:sf N-LIST "p_lsp_N_2DLIST"
:sym STRING
:sym CONCATENATE
:sym UNSAFE-SYMBOL-FUNCTION
:sym INTERN
:sf NAMES->SYMBOL "p_lsp_NAMES_2D_3ESYMBOL"
:sym STRINGP
:sym DECLARE
:sf PARSE-BODY "p_lsp_PARSE_2DBODY"
:sym =>
:sym POSITION
:sym SUBSEQ
:sym 1+
:sf PARSE-IN/OUT "p_lsp_PARSE_2DIN_2FOUT"
:sym SUBST
:sym UPTO
:sym QUOTE
:sym INSERT-OPTIONAL-DEFAULT
:sym CDR
:sym DESTRUCTURING-BIND
:sym BLOCK
:sym LAMBDA
:sym FUNCTION
:sf PARSE-MACRO-DEFINITION "p_lsp_PARSE_2DMACRO_2DDEFINITION"
:sf QUOTED-CONSTANT-P "p_lsp_QUOTED_2DCONSTANT_2DP"
:sym REMHASH
:sf REMOVE-COMPILER-MACRO-EXPANDER "p_lsp_REMOVE_2DCOMPILER_2DMACRO_2DEXPANDER"
:sf REMOVE-MACRO-EXPANDER "p_lsp_REMOVE_2DMACRO_2DEXPANDER"
:sym *TYPE-MACRO-EXPANDERS*
:sf REMOVE-TYPE-MACRO-EXPANDER "p_lsp_REMOVE_2DTYPE_2DMACRO_2DEXPANDER"
:sf SAME-LENGTH-P "p_lsp_SAME_2DLENGTH_2DP"
:sf TREE-FIND "p_lsp_TREE_2DFIND"
:sym REVERSE
:sym MEMQL
:sym NREVERSE
:sf UPTO "p_lsp_UPTO"
:sym WALK
:sf WALK "p_lsp_WALK"
:sym PARSE-BODY
:sym LIST*
:sf WRAP-IN-BLOCK "p_lsp_WRAP_2DIN_2DBLOCK"
:pinfo PARSE-MACRO-DEFINITION (NAME ARGS OPTIONAL-DEFAULT BODY) NIL NIL NIL NIL NIL NIL T
:pinfo QUOTED-CONSTANT-P (L) NIL NIL NIL NIL NIL NIL T
:pinfo COMPILER-MACROEXPAND-1 (FORM &OPTIONAL LOCAL-MACRO-ENV) NIL NIL NIL NIL NIL NIL T
:pinfo MACROEXPAND-W (FORM &OPTIONAL LOCAL-MACRO-ENV) NIL NIL NIL NIL NIL NIL T
:pinfo MACRO-ARG-LIST (SYMBOL TABLE) NIL NIL NIL NIL NIL NIL T
:pinfo COLLECT (FUNC ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo GET-SETF-METHOD-1 (ACCESS ENV MACROEXPANDED? ORIGINAL) NIL NIL NIL NIL NIL NIL T
:pinfo PARSE-BODY (BODY) NIL NIL NIL NIL NIL NIL T
:pinfo REMOVE-COMPILER-MACRO-EXPANDER (NAME) NIL NIL NIL NIL NIL NIL T
:pinfo COMPILER-MACROEXPAND-W (FORM &OPTIONAL LOCAL-MACRO-ENV) NIL NIL NIL NIL NIL NIL T
:pinfo NAMES->SYMBOL (&REST NAMES) NIL NIL NIL NIL NIL NIL T
:pinfo INSERT-OPTIONAL-DEFAULT (LAMBDA-LIST DEFAULT) NIL NIL NIL NIL NIL NIL T
:pinfo SAME-LENGTH-P (L1 L2) NIL NIL NIL NIL NIL NIL T
:pinfo EVERY-EVEN (L) NIL NIL NIL NIL NIL NIL T
:pinfo GET-SETF-METHOD-W (ACCESS &OPTIONAL ENV) NIL NIL NIL NIL NIL NIL T
:pinfo REMOVE-TYPE-MACRO-EXPANDER (NAME) NIL NIL NIL NIL NIL NIL T
:pinfo COMPILER-MACRO-FUNCTION (NAME &OPTIONAL ENV) NIL NIL NIL NIL NIL NIL T
:pinfo TREE-FIND (E TREE) NIL NIL NIL NIL NIL NIL T
:pinfo MACROEXPAND-1-W (FORM &OPTIONAL LOCAL-MACRO-ENV) NIL NIL NIL NIL NIL NIL T
:pinfo DEFINE-SETF (ACCESSOR UPDATER) NIL NIL NIL NIL NIL NIL T
:pinfo EVERY-ODD (L) NIL NIL NIL NIL NIL NIL T
:pinfo LOOKUP-MACRO-EXPANDER (NAME TABLE MENV) NIL NIL NIL NIL NIL NIL T
:pinfo N-LIST (N INIT-FUNC) NIL NIL NIL NIL NIL NIL T
:pinfo LOOKUP-SYMBOL-MACRO-DEF (NAME MENV) NIL NIL NIL NIL NIL NIL T
:pinfo GET-SETF-METHOD (ACCESS &OPTIONAL ENV) NIL NIL NIL NIL NIL NIL T
:pinfo PARSE-IN/OUT (SPEC) NIL NIL NIL NIL NIL NIL T
:pinfo EXPAND-MACRO (FORM TABLE MENV REPEAT? ORIGINAL-CALL-IS-A-MACRO?) NIL NIL NIL NIL NIL NIL T
:pinfo DEFINE-MACRO-FUNCTION (SYMBOL FUNCTION ARG-LIST TABLE CONSTRUCTOR) NIL NIL NIL NIL NIL NIL T
:pinfo REMOVE-MACRO-EXPANDER (NAME) NIL NIL NIL NIL NIL NIL T
:pinfo UPTO (E L) NIL NIL NIL NIL NIL NIL T
:pinfo WALK (FUNC L) NIL NIL NIL NIL NIL NIL T
:pinfo MACROEXPAND (FORM &OPTIONAL LOCAL-MACRO-ENV) NIL NIL NIL NIL NIL NIL T
:pinfo COMPILER-MACROEXPAND (FORM &OPTIONAL LOCAL-MACRO-ENV) NIL NIL NIL NIL NIL NIL T
:pinfo EVERY-N (N L) NIL NIL NIL NIL NIL NIL T
:pinfo MACROEXPAND-1 (FORM &OPTIONAL LOCAL-MACRO-ENV) NIL NIL NIL NIL NIL NIL T
:pinfo MACRO-FUNCTION (SYMBOL) NIL NIL NIL NIL NIL NIL T
:pinfo WRAP-IN-BLOCK (BLOCK-NAME DECLS+BODY) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_lsp_COLLECT();
extern SYMBOL s_lsp_NIL; 
extern LP p_lsp_COMPILER_2DMACRO_2DFUNCTION();
extern SYMBOL s_lsp__2ACOMPILER_2DMACRO_2DEXPANDERS_2A; 
extern SYMBOL s_lsp_UNSAFE_2DSYMBOL_2DVALUE; 
extern SYMBOL s_lsp_GETHASH; 
extern LP p_lsp_COMPILER_2DMACROEXPAND_2D1();
extern SYMBOL s_lsp_EXPAND_2DMACRO; 
extern LP p_lsp_COMPILER_2DMACROEXPAND_2DW();
extern SYMBOL s_lsp_COMPILER_2DMACROEXPAND; 
extern LP p_lsp_COMPILER_2DMACROEXPAND();
extern SYMBOL s_lsp_T; 
extern LP p_lsp_DEFINE_2DMACRO_2DFUNCTION();
extern SYMBOL s_lsp_NULL; 
extern SYMBOL s_lsp__2AMACRO_2DEXPANDERS_2A; 
extern SYMBOL s_lsp_EQ; 
extern SYMBOL s_lsp_SET_2DMACRO_2DNAME_2DFLAG; 
extern SYMBOL s_lsp_SET_2DSYMBOL_2DFUNCTION; 
extern SYMBOL s_key_EXPANSION_2DFUNCTION; 
extern SYMBOL s_key_ORIGINAL_2DARG_2DLIST; 
extern SYMBOL s_lsp_SET_2DGETHASH; 
extern LP p_lsp_DEFINE_2DSETF();
extern SYMBOL s_lsp__2ASETF_2DMETHODS_2A; 
extern LP p_lsp_EVERY_2DEVEN();
extern SYMBOL s_lsp_EVERY_2DN; 
extern LP p_lsp_EVERY_2DN();
extern LP p_lsp_EVERY_2DN_2DDOIT2366();
extern SYMBOL s_lsp_1_2D; 
extern LP p_lsp_EVERY_2DODD();
extern LP p_lsp_EXPAND_2DMACRO();
extern SYMBOL s_lsp_ATOM; 
extern SYMBOL s_lsp_LOOKUP_2DSYMBOL_2DMACRO_2DDEF; 
extern SYMBOL s_lsp_LOOKUP_2DMACRO_2DEXPANDER; 
extern SYMBOL s_lsp__2AMACROEXPAND_2DHOOK_2A; 
extern SYMBOL s_lsp_NOT; 
extern LP p_lsp_LOOKUP_2DMACRO_2DEXPANDER();
extern SYMBOL s_lsp_ASSQ; 
extern LP p_lsp_LOOKUP_2DSYMBOL_2DMACRO_2DDEF();
extern LP p_lsp_GET_2DSETF_2DMETHOD_2DW();
extern SYMBOL s_lsp_GET_2DSETF_2DMETHOD_2D1; 
extern LP p_lsp_GET_2DSETF_2DMETHOD();
extern LP p_lsp_GET_2DSETF_2DMETHOD_2D1();
extern SYMBOL s_lsp_SYMBOLP; 
MAKE_SIMPLE_STRING(k2369,1,"S");
extern SYMBOL s_lsp_GENSYM; 
extern SYMBOL s_lsp_SETQ; 
extern SYMBOL s_lsp_LISTP; 
MAKE_SIMPLE_STRING(k2370,1,"T");
extern SYMBOL s_lsp_APPEND_2F2; 
extern SYMBOL s_lsp__2ADELAY_2DSTRUCTURE_2DDEFS_3F_2A; 
extern SYMBOL s_lsp_COMPLETE_2DDELAYED_2DDEFSTRUCTS; 
extern SYMBOL s_lsp_GET_2DSETF_2DMETHOD_2DW; 
MAKE_SIMPLE_STRING(k2371,27,"No SETF method found for ~A");
extern SYMBOL s_lsp_ERROR; 
extern SYMBOL s_lsp_MACROEXPAND_2DW; 
MAKE_SIMPLE_STRING(k2372,36,"~S is not one of these types:~{ ~A~}");
extern SYMBOL s_lsp_SYMBOL; 
extern SYMBOL s_lsp_LIST; 
MAKE_CONS(k2374,LREF(s_lsp_LIST),LREF(s_lsp_NIL));
MAKE_CONS(k2373,LREF(s_lsp_SYMBOL),LREF(k2374));
extern LP p_lsp_INSERT_2DOPTIONAL_2DDEFAULT();
extern SYMBOL s_lsp__26OPTIONAL; 
extern SYMBOL s_lsp__26REST; 
extern SYMBOL s_lsp__26RESTV; 
extern SYMBOL s_lsp__26KEY; 
extern SYMBOL s_lsp__26ALLOW_2DOTHER_2DKEYS; 
extern SYMBOL s_lsp__26AUX; 
extern SYMBOL s_lsp__26WHOLE; 
extern SYMBOL s_lsp__26ENVIRONMENT; 
extern SYMBOL s_lsp__26BODY; 
MAKE_CONS(k2383,LREF(s_lsp__26BODY),LREF(s_lsp_NIL));
MAKE_CONS(k2382,LREF(s_lsp__26ENVIRONMENT),LREF(k2383));
MAKE_CONS(k2381,LREF(s_lsp__26WHOLE),LREF(k2382));
MAKE_CONS(k2380,LREF(s_lsp__26AUX),LREF(k2381));
MAKE_CONS(k2379,LREF(s_lsp__26ALLOW_2DOTHER_2DKEYS),LREF(k2380));
MAKE_CONS(k2378,LREF(s_lsp__26KEY),LREF(k2379));
MAKE_CONS(k2377,LREF(s_lsp__26RESTV),LREF(k2378));
MAKE_CONS(k2376,LREF(s_lsp__26REST),LREF(k2377));
MAKE_CONS(k2375,LREF(s_lsp__26OPTIONAL),LREF(k2376));
extern SYMBOL s_lsp_MEMQ; 
extern LP p_lsp_MACRO_2DARG_2DLIST();
extern LP p_lsp_MACRO_2DFUNCTION();
extern LP p_lsp_MACROEXPAND_2D1();
extern LP p_lsp_MACROEXPAND_2D1_2DW();
extern LP p_lsp_MACROEXPAND_2DW();
extern LP p_lsp_MACROEXPAND();
extern LP p_lsp_N_2DLIST();
extern SYMBOL s_lsp_N_2DLIST; 
extern LP p_lsp_NAMES_2D_3ESYMBOL();
extern SYMBOL s_lsp_STRING; 
extern SYMBOL s_lsp_CONCATENATE; 
extern SYMBOL s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION; 
extern SYMBOL s_lsp_INTERN; 
extern LP p_lsp_PARSE_2DBODY();
extern LP p_lsp_PARSE_2DBODY_2DSEPARATE2384();
extern SYMBOL s_lsp_STRINGP; 
extern SYMBOL s_lsp_DECLARE; 
extern LP p_lsp_PARSE_2DIN_2FOUT();
extern SYMBOL s_lsp__3D_3E; 
extern SYMBOL s_lsp_POSITION; 
extern SYMBOL s_lsp_SUBSEQ; 
extern SYMBOL s_lsp_1_2B; 
extern LP p_lsp_PARSE_2DMACRO_2DDEFINITION();
extern SYMBOL s_lsp_SUBST; 
MAKE_SIMPLE_STRING(k2388,5,"WHOLE");
extern SYMBOL s_lsp_UPTO; 
MAKE_SIMPLE_STRING(k2389,3,"ENV");
extern SYMBOL s_lsp_QUOTE; 
extern SYMBOL s_lsp_INSERT_2DOPTIONAL_2DDEFAULT; 
extern SYMBOL s_lsp_CDR; 
MAKE_CONS(k2391,LREF(s_lsp_NIL),LREF(s_lsp_NIL));
MAKE_CONS(k2390,LREF(s_lsp_NIL),LREF(k2391));
extern SYMBOL s_lsp_DESTRUCTURING_2DBIND; 
extern SYMBOL s_lsp_BLOCK; 
extern SYMBOL s_lsp_LAMBDA; 
extern SYMBOL s_lsp_FUNCTION; 
extern LP p_lsp_QUOTED_2DCONSTANT_2DP();
extern LP p_lsp_REMOVE_2DCOMPILER_2DMACRO_2DEXPANDER();
extern SYMBOL s_lsp_REMHASH; 
extern LP p_lsp_REMOVE_2DMACRO_2DEXPANDER();
extern LP p_lsp_REMOVE_2DTYPE_2DMACRO_2DEXPANDER();
extern SYMBOL s_lsp__2ATYPE_2DMACRO_2DEXPANDERS_2A; 
extern LP p_lsp_SAME_2DLENGTH_2DP();
extern LP p_lsp_TREE_2DFIND();
extern LP p_lsp_TREE_2DFIND_2DLOOPY2393();
extern LP p_lsp_UPTO();
extern SYMBOL s_lsp_REVERSE; 
extern SYMBOL s_lsp_MEMQL; 
extern SYMBOL s_lsp_NREVERSE; 
extern LP p_lsp_WALK();
extern SYMBOL s_lsp_WALK; 
extern LP p_lsp_WRAP_2DIN_2DBLOCK();
extern SYMBOL s_lsp_PARSE_2DBODY; 
extern SYMBOL s_lsp_LIST_2A; 


extern LP c_cons();
extern LP num_equal_p();


LP p_lsp_COLLECT(argc, v_FUNC_0, v_ARGS_1)
      ARGC argc;  LP v_FUNC_0; LP v_ARGS_1;
{
LP v_TMP3676_17; LP v_TMP3675_16; LP v_X_14; 
LP v_X_12; LP v_RESULT_9; LP v_REST_8; 
LP v_X_6; LP v_X_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; 
if (argc != 2) wna(argc,2);
v_X_4 = v_ARGS_1;
v_REST_8 = ((LP) DEREF((v_ARGS_1) + 1 * 4));
v_X_6 = v_ARGS_1;
v_RESULT_9 = ((LP) DEREF((v_ARGS_1) + 0 * 4));
goto t_TEST3673_11;
t_LOOP3674_10:;
v_X_12 = v_REST_8;
v_TMP3675_16 = ((LP) DEREF((v_X_12) + 1 * 4));
v_X_14 = v_REST_8;
t1 = ((LP) DEREF((v_X_14) + 0 * 4));
v_TMP3676_17 = CODE_PTR(COERCE_TO_FUNCTION(v_FUNC_0))(2, v_RESULT_9, t1);
v_REST_8 = v_TMP3675_16;
v_RESULT_9 = v_TMP3676_17;
t_TEST3673_11:;
if (v_REST_8 == NIL) {
return(v_RESULT_9);
return(NIL);
}
goto t_LOOP3674_10;
return(NIL);
}

LP p_lsp_COMPILER_2DMACRO_2DFUNCTION(va_alist) va_dcl
{
LP v_NAME_0; LP v_ENV_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_NAME_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_ENV_1 = NIL;
} else {
v_ENV_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ACOMPILER_2DMACRO_2DEXPANDERS_2A));
t0 = ICALL(s_lsp_GETHASH) (MV_CALL(argc,2), v_NAME_0, t1);
return(t0);
}

LP p_lsp_COMPILER_2DMACROEXPAND_2D1(va_alist) va_dcl
{
LP v_FORM_0; LP v_LOCAL_2DMACRO_2DENV_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_FORM_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_LOCAL_2DMACRO_2DENV_1 = NIL;
} else {
v_LOCAL_2DMACRO_2DENV_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ACOMPILER_2DMACRO_2DEXPANDERS_2A));
t0 = ICALL(s_lsp_EXPAND_2DMACRO) (MV_CALL(argc,5), v_FORM_0, t1, v_LOCAL_2DMACRO_2DENV_1, LREF(s_lsp_NIL), LREF(s_lsp_NIL));
return(t0);
}

LP p_lsp_COMPILER_2DMACROEXPAND_2DW(va_alist) va_dcl
{
LP v_FORM_0; LP v_LOCAL_2DMACRO_2DENV_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_FORM_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_LOCAL_2DMACRO_2DENV_1 = NIL;
} else {
v_LOCAL_2DMACRO_2DENV_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t0 = ICALL(s_lsp_COMPILER_2DMACROEXPAND) (MV_CALL(argc,2), v_FORM_0, v_LOCAL_2DMACRO_2DENV_1);
return(t0);
}

LP p_lsp_COMPILER_2DMACROEXPAND(va_alist) va_dcl
{
LP v_FORM_0; LP v_LOCAL_2DMACRO_2DENV_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_FORM_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_LOCAL_2DMACRO_2DENV_1 = NIL;
} else {
v_LOCAL_2DMACRO_2DENV_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ACOMPILER_2DMACRO_2DEXPANDERS_2A));
t0 = ICALL(s_lsp_EXPAND_2DMACRO) (MV_CALL(argc,5), v_FORM_0, t1, v_LOCAL_2DMACRO_2DENV_1, LREF(s_lsp_T), LREF(s_lsp_NIL));
return(t0);
}

LP p_lsp_DEFINE_2DMACRO_2DFUNCTION(argc, v_SYMBOL_0, v_FUNCTION_1, v_ARG_2DLIST_2, v_TABLE_3, v_CONSTRUCTOR_4)
      ARGC argc;  LP v_SYMBOL_0; LP v_FUNCTION_1; LP v_ARG_2DLIST_2; LP v_TABLE_3; LP v_CONSTRUCTOR_4;
{
LP v_T3681_10; LP v_T3680_9; LP v_S3679_8; 
LP v_T3678_7; LP v_S3677_6; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; 
if (argc != 5) wna(argc,5);
t0 = ICALL(s_lsp_NULL) (1, v_TABLE_3);
if (t0 == NIL) {
t2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AMACRO_2DEXPANDERS_2A));
t1 = ICALL(s_lsp_EQ) (2, v_TABLE_3, t2);
if (t1 != NIL) {
ICALL(s_lsp_SET_2DMACRO_2DNAME_2DFLAG) (1, v_SYMBOL_0);
v_S3677_6 = v_FUNCTION_1;
v_T3678_7 = v_SYMBOL_0;
ICALL(s_lsp_SET_2DSYMBOL_2DFUNCTION) (2, v_SYMBOL_0, v_FUNCTION_1);
}
v_S3679_8 = CODE_PTR(COERCE_TO_FUNCTION(v_CONSTRUCTOR_4))(4, LREF(s_key_EXPANSION_2DFUNCTION), v_FUNCTION_1, LREF(s_key_ORIGINAL_2DARG_2DLIST), v_ARG_2DLIST_2);
v_T3680_9 = v_SYMBOL_0;
v_T3681_10 = v_TABLE_3;
ICALL(s_lsp_SET_2DGETHASH) (3, v_SYMBOL_0, v_TABLE_3, v_S3679_8);
}
return(v_SYMBOL_0);
}

LP p_lsp_DEFINE_2DSETF(argc, v_ACCESSOR_0, v_UPDATER_1)
      ARGC argc;  LP v_ACCESSOR_0; LP v_UPDATER_1;
{
LP v_T3684_5; LP v_T3683_4; LP v_S3682_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 2) wna(argc,2);
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ASETF_2DMETHODS_2A));
t0 = ICALL(s_lsp_NULL) (1, t1);
if (t0 == NIL) {
v_S3682_3 = v_UPDATER_1;
v_T3683_4 = v_ACCESSOR_0;
v_T3684_5 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ASETF_2DMETHODS_2A));
ICALL(s_lsp_SET_2DGETHASH) (3, v_ACCESSOR_0, v_T3684_5, v_UPDATER_1);
}
return(v_ACCESSOR_0);
}

LP p_lsp_EVERY_2DEVEN(argc, v_L_0)
      ARGC argc;  LP v_L_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_EVERY_2DN) (MV_CALL(argc,2), (LP) 4, v_L_0);
return(t0);
}

LP p_lsp_EVERY_2DN(argc, v_N_0, v_L_1)
      ARGC argc;  LP v_N_0; LP v_L_1;
{
LP f_DOIT_3; 
LP t0; LP t1; LP t2; LP t3; 
if (argc != 2) wna(argc,2);
t0 = NEW_OE(2);
SET_OE_SLOT(t0,1,v_N_0);
t1 = MAKE_CLOSURE(p_lsp_EVERY_2DN_2DDOIT2366,t0);
f_DOIT_3 = t1;
SET_OE_SLOT(t0,0,f_DOIT_3);
t2 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(MV_CALL(argc,2), (LP) 2, v_L_1);
return(t2);
}

LP p_lsp_EVERY_2DN_2DDOIT2366(argc, v_I_0, v_REST_1)
      ARGC argc;  LP v_I_0; LP v_REST_1;
{
LP v_X_10; LP v_Y_8; LP v_X_7; 
LP v_X_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 

if (argc != 2) wna(argc,2);
t0 = OE;
if (v_REST_1 != NIL) {
t2 = (num_equal_p((v_I_0), ((LP) 2)));
if (t2 != NIL) {
v_X_3 = v_REST_1;
v_X_7 = ((LP) DEREF((v_REST_1) + 0 * 4));
v_X_5 = v_REST_1;
t3 = ((LP) DEREF((v_REST_1) + 1 * 4));
v_Y_8 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(2, GET_OE_SLOT(t0,1), t3);
t1 = (c_cons((v_X_7), (v_Y_8)));
return(t1);
} else {
t4 = ICALL(s_lsp_1_2D) (1, v_I_0);
v_X_10 = v_REST_1;
t5 = ((LP) DEREF((v_REST_1) + 1 * 4));
t1 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(MV_CALL(argc,2), t4, t5);
return(t1);
}
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_EVERY_2DODD(argc, v_L_0)
      ARGC argc;  LP v_L_0;
{
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
if (argc != 1) wna(argc,1);
v_X_2 = v_L_0;
t1 = ((LP) DEREF((v_L_0) + 1 * 4));
t0 = ICALL(s_lsp_EVERY_2DN) (MV_CALL(argc,2), (LP) 4, t1);
return(t0);
}

LP p_lsp_EXPAND_2DMACRO(argc, v_FORM_0, v_TABLE_1, v_MENV_2, v_REPEAT_3F_3, v_ORIGINAL_2DCALL_2DIS_2DA_2DMACRO_3F_4)
      ARGC argc;  LP v_FORM_0; LP v_TABLE_1; LP v_MENV_2; LP v_REPEAT_3F_3; LP v_ORIGINAL_2DCALL_2DIS_2DA_2DMACRO_3F_4;
{
LP v_X_24; LP v_EXP_23; LP v_I_21; 
LP v_S_20; LP v_S_18; LP v_EXPANDER_17; 
LP v_X_15; LP v_X_13; LP v_X_11; 
LP v_C_9; LP v_LIST_7; LP v_DEF_6; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; 
if (argc != 5) wna(argc,5);
START2367:
t1 = ICALL(s_lsp_ATOM) (1, v_FORM_0);
if (t1 != NIL) {
v_DEF_6 = ICALL(s_lsp_LOOKUP_2DSYMBOL_2DMACRO_2DDEF) (2, v_FORM_0, v_MENV_2);
if (v_DEF_6 != NIL) {
v_LIST_7 = v_DEF_6;
v_C_9 = v_DEF_6;
v_X_11 = v_DEF_6;
v_X_13 = ((LP) DEREF((v_DEF_6) + 1 * 4));
t2 = ((LP) DEREF((v_X_13) + 0 * 4));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,LREF(s_lsp_T));
}
return(t2);
} else {
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,v_ORIGINAL_2DCALL_2DIS_2DA_2DMACRO_3F_4);
}
return(v_FORM_0);
}
} else {
v_X_24 = v_FORM_0;
t4 = ((LP) DEREF((v_FORM_0) + 0 * 4));
t3 = ICALL(s_lsp_ATOM) (1, t4);
if (t3 != NIL) {
v_X_15 = v_FORM_0;
t5 = ((LP) DEREF((v_FORM_0) + 0 * 4));
v_EXPANDER_17 = ICALL(s_lsp_LOOKUP_2DMACRO_2DEXPANDER) (3, t5, v_TABLE_1, v_MENV_2);
if (v_EXPANDER_17 != NIL) {
v_S_18 = v_EXPANDER_17;
v_S_20 = v_EXPANDER_17;
v_I_21 = (LP) 4;
t6 = ((LP) DEREF((v_EXPANDER_17) + 2 * 4));
t7 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AMACROEXPAND_2DHOOK_2A));
v_EXP_23 = CODE_PTR(COERCE_TO_FUNCTION(t7))(3, t6, v_FORM_0, v_MENV_2);
if (v_REPEAT_3F_3 != NIL) {
t9 = ICALL(s_lsp_EQ) (2, v_FORM_0, v_EXP_23);
t8 = ICALL(s_lsp_NOT) (1, t9);
} else {
t8 = LREF(s_lsp_NIL);
}
if (t8 != NIL) {
v_FORM_0 = v_EXP_23; v_ORIGINAL_2DCALL_2DIS_2DA_2DMACRO_3F_4 = LREF(s_lsp_T); 
goto START2367;
} else {
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,LREF(s_lsp_T));
}
return(v_EXP_23);
}
} else {
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,v_ORIGINAL_2DCALL_2DIS_2DA_2DMACRO_3F_4);
}
return(v_FORM_0);
}
} else {
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,v_ORIGINAL_2DCALL_2DIS_2DA_2DMACRO_3F_4);
}
return(v_FORM_0);
}
}
}

LP p_lsp_LOOKUP_2DMACRO_2DEXPANDER(argc, v_NAME_0, v_TABLE_1, v_MENV_2)
      ARGC argc;  LP v_NAME_0; LP v_TABLE_1; LP v_MENV_2;
{
LP v_X_10; LP v_LOCAL_9; LP v_I_7; 
LP v_S_6; LP v_S_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 3) wna(argc,3);
t0 = ICALL(s_lsp_NULL) (1, v_MENV_2);
if (t0 != NIL) {
v_LOCAL_9 = LREF(s_lsp_NIL);
} else {
v_S_4 = v_MENV_2;
v_S_6 = v_MENV_2;
v_I_7 = (LP) 2;
t1 = ((LP) DEREF((v_MENV_2) + 1 * 4));
v_LOCAL_9 = ICALL(s_lsp_ASSQ) (2, v_NAME_0, t1);
}
if (v_LOCAL_9 != NIL) {
v_X_10 = v_LOCAL_9;
t2 = ((LP) DEREF((v_LOCAL_9) + 1 * 4));
return(t2);
} else {
t2 = ICALL(s_lsp_GETHASH) (MV_CALL(argc,2), v_NAME_0, v_TABLE_1);
return(t2);
}
}

LP p_lsp_LOOKUP_2DSYMBOL_2DMACRO_2DDEF(argc, v_NAME_0, v_MENV_1)
      ARGC argc;  LP v_NAME_0; LP v_MENV_1;
{
LP v_I_6; LP v_S_5; LP v_S_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 2) wna(argc,2);
t1 = ICALL(s_lsp_NULL) (1, v_MENV_1);
if (t1 != NIL) {
return(LREF(s_lsp_NIL));
} else {
v_S_3 = v_MENV_1;
v_S_5 = v_MENV_1;
v_I_6 = (LP) 4;
t2 = ((LP) DEREF((v_MENV_1) + 2 * 4));
t0 = ICALL(s_lsp_ASSQ) (MV_CALL(argc,2), v_NAME_0, t2);
return(t0);
}
}

LP p_lsp_GET_2DSETF_2DMETHOD_2DW(va_alist) va_dcl
{
LP v_ACCESS_0; LP v_ENV_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_ACCESS_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_ENV_1 = NIL;
} else {
v_ENV_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t0 = ICALL(s_lsp_GET_2DSETF_2DMETHOD_2D1) (MV_CALL(argc,4), v_ACCESS_0, v_ENV_1, LREF(s_lsp_NIL), v_ACCESS_0);
return(t0);
}

LP p_lsp_GET_2DSETF_2DMETHOD(va_alist) va_dcl
{
LP v_ACCESS_0; LP v_ENV_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_ACCESS_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_ENV_1 = NIL;
} else {
v_ENV_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t0 = ICALL(s_lsp_GET_2DSETF_2DMETHOD_2D1) (MV_CALL(argc,4), v_ACCESS_0, v_ENV_1, LREF(s_lsp_NIL), v_ACCESS_0);
return(t0);
}

LP p_lsp_GET_2DSETF_2DMETHOD_2D1(argc, v_ACCESS_0, v_ENV_1, v_MACROEXPANDED_3F_2, v_ORIGINAL_3)
      ARGC argc;  LP v_ACCESS_0; LP v_ENV_1; LP v_MACROEXPANDED_3F_2; LP v_ORIGINAL_3;
{
LP v_Y_66; LP v_X_65; LP v_X_63; 
LP v_LIST_61; LP v_Y_59; LP v_X_58; 
LP v_Y_56; LP v_X_55; LP v_Y_53; 
LP v_X_52; LP v_X_50; LP v_TVARS_49; 
LP v_SVAR_48; LP v_X_46; LP v_V_44; 
LP v_X_43; LP v_NEW_2DCDR_41; LP v_C_40; 
LP v_Y_38; LP v_X_37; LP v_X_35; 
LP v_X_33; LP v_LOOPVAR_2D905_29; LP v_LOOPVAR_2D904_28; 
LP v_LOOPVAR_2D903_27; LP v_LOOP_2DLIST_2D902_26; LP v_ARG_25; 
LP v_X_23; LP v_EXPANDER_22; LP v_X_20; 
LP v_Y_18; LP v_X_17; LP v_Y_15; 
LP v_X_14; LP v_Y_12; LP v_X_11; 
LP v_Y_9; LP v_X_8; LP v_SVAR_7; 
LP v_KEY3686_6; LP v_KEY3685_5; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; 
if (argc != 4) wna(argc,4);
START2368:
v_KEY3685_5 = v_ACCESS_0;
v_KEY3686_6 = v_KEY3685_5;
t1 = ICALL(s_lsp_SYMBOLP) (1, v_KEY3686_6);
if (t1 != NIL) {
v_SVAR_7 = ICALL(s_lsp_GENSYM) (1, LREF(k2369));
v_X_8 = v_SVAR_7;
v_Y_9 = LREF(s_lsp_NIL);
t2 = (c_cons((v_SVAR_7), (LREF(s_lsp_NIL))));
v_X_11 = v_SVAR_7;
v_Y_12 = LREF(s_lsp_NIL);
v_Y_15 = (c_cons((v_SVAR_7), (LREF(s_lsp_NIL))));
v_Y_18 = (c_cons((v_ACCESS_0), (v_Y_15)));
t3 = (c_cons((LREF(s_lsp_SETQ)), (v_Y_18)));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,5);
SET_MV_RETURN_VALUE(argc,1,LREF(s_lsp_NIL));
SET_MV_RETURN_VALUE(argc,2,t2);
SET_MV_RETURN_VALUE(argc,3,t3);
SET_MV_RETURN_VALUE(argc,4,v_ACCESS_0);
}
return(LREF(s_lsp_NIL));
} else {
t4 = ICALL(s_lsp_LISTP) (1, v_KEY3686_6);
if (t4 != NIL) {
v_X_20 = v_ACCESS_0;
t5 = ((LP) DEREF((v_ACCESS_0) + 0 * 4));
t6 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ASETF_2DMETHODS_2A));
v_EXPANDER_22 = ICALL(s_lsp_GETHASH) (2, t5, t6);
if (v_EXPANDER_22 != NIL) {
t7 = ICALL(s_lsp_SYMBOLP) (1, v_EXPANDER_22);
if (t7 != NIL) {
v_SVAR_48 = ICALL(s_lsp_GENSYM) (1, LREF(k2369));
v_ARG_25 = LREF(s_lsp_NIL);
v_X_23 = v_ACCESS_0;
v_LOOP_2DLIST_2D902_26 = ((LP) DEREF((v_ACCESS_0) + 1 * 4));
v_LOOPVAR_2D903_27 = LREF(s_lsp_NIL);
v_LOOPVAR_2D904_28 = LREF(s_lsp_NIL);
v_LOOPVAR_2D905_29 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_31:;
if (v_LOOP_2DLIST_2D902_26 == NIL) {
goto t_END_2DLOOP_32;
}
v_X_33 = v_LOOP_2DLIST_2D902_26;
v_ARG_25 = ((LP) DEREF((v_X_33) + 0 * 4));
v_X_35 = v_LOOP_2DLIST_2D902_26;
v_LOOP_2DLIST_2D902_26 = ((LP) DEREF((v_X_35) + 1 * 4));
v_X_37 = ICALL(s_lsp_GENSYM) (1, LREF(k2370));
v_LOOPVAR_2D905_29 = (c_cons((v_X_37), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D904_28 != NIL) {
v_C_40 = v_LOOPVAR_2D904_28;
v_NEW_2DCDR_41 = v_LOOPVAR_2D905_29;
v_V_44 = v_NEW_2DCDR_41;
((LP) (DEREF((v_C_40) + 1 * 4) = (LD) (v_V_44)));
v_X_46 = v_C_40;
v_LOOPVAR_2D904_28 = ((LP) DEREF((v_X_46) + 1 * 4));
} else {
v_LOOPVAR_2D903_27 = v_LOOPVAR_2D905_29;
v_LOOPVAR_2D904_28 = v_LOOPVAR_2D903_27;
}
goto t_NEXT_2DLOOP_31;
goto t_END_2DLOOP_32;
t_END_2DLOOP_32:;
v_TVARS_49 = v_LOOPVAR_2D903_27;
goto b_NIL_30;
v_TVARS_49 = NIL;
v_TVARS_49 = v_TVARS_49;
b_NIL_30:;
v_X_50 = v_ACCESS_0;
t8 = ((LP) DEREF((v_ACCESS_0) + 1 * 4));
v_X_52 = v_SVAR_48;
v_Y_53 = LREF(s_lsp_NIL);
t9 = (c_cons((v_SVAR_48), (LREF(s_lsp_NIL))));
v_X_55 = v_SVAR_48;
v_Y_56 = LREF(s_lsp_NIL);
t10 = (c_cons((v_SVAR_48), (LREF(s_lsp_NIL))));
v_Y_59 = ICALL(s_lsp_APPEND_2F2) (2, v_TVARS_49, t10);
t11 = (c_cons((v_EXPANDER_22), (v_Y_59)));
v_LIST_61 = v_ACCESS_0;
v_X_63 = v_ACCESS_0;
v_X_65 = ((LP) DEREF((v_ACCESS_0) + 0 * 4));
t12 = (c_cons((v_X_65), (v_TVARS_49)));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,5);
SET_MV_RETURN_VALUE(argc,1,t8);
SET_MV_RETURN_VALUE(argc,2,t9);
SET_MV_RETURN_VALUE(argc,3,t11);
SET_MV_RETURN_VALUE(argc,4,t12);
}
return(v_TVARS_49);
} else {
t0 = CODE_PTR(COERCE_TO_FUNCTION(v_EXPANDER_22))(MV_CALL(argc,2), v_ACCESS_0, v_ENV_1);
return(t0);
}
} else {
t13 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ADELAY_2DSTRUCTURE_2DDEFS_3F_2A));
if (t13 != NIL) {
ICALL(s_lsp_COMPLETE_2DDELAYED_2DDEFSTRUCTS) (0);
t0 = ICALL(s_lsp_GET_2DSETF_2DMETHOD_2DW) (MV_CALL(argc,2), v_ACCESS_0, v_ENV_1);
return(t0);
} else {
if (v_MACROEXPANDED_3F_2 != NIL) {
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,2), LREF(k2371), v_ORIGINAL_3);
return(t0);
} else {
t14 = ICALL(s_lsp_MACROEXPAND_2DW) (2, v_ACCESS_0, v_ENV_1);
v_ACCESS_0 = t14; v_MACROEXPANDED_3F_2 = LREF(s_lsp_T); v_ORIGINAL_3 = v_ACCESS_0; 
goto START2368;
}
}
}
} else {
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,3), LREF(k2372), v_KEY3685_5, LREF(k2373));
return(t0);
}
}
}

LP p_lsp_INSERT_2DOPTIONAL_2DDEFAULT(argc, v_LAMBDA_2DLIST_0, v_DEFAULT_1)
      ARGC argc;  LP v_LAMBDA_2DLIST_0; LP v_DEFAULT_1;
{
LP v_X_32; LP v_V_30; LP v_X_29; 
LP v_NEW_2DCDR_27; LP v_C_26; LP v_Y_24; 
LP v_X_23; LP v_Y_21; LP v_X_20; 
LP v_Y_18; LP v_X_17; LP v_G3687_16; 
LP v_X_14; LP v_X_12; LP v_LOOPVAR_2D909_8; 
LP v_LOOPVAR_2D908_7; LP v_LOOPVAR_2D907_6; LP v_OPTIONAL_3F_5; 
LP v_LOOP_2DLIST_2D906_4; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; 
if (argc != 2) wna(argc,2);
v_X_3 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D906_4 = v_LAMBDA_2DLIST_0;
v_OPTIONAL_3F_5 = LREF(s_lsp_NIL);
v_LOOPVAR_2D907_6 = LREF(s_lsp_NIL);
v_LOOPVAR_2D908_7 = LREF(s_lsp_NIL);
v_LOOPVAR_2D909_8 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_10:;
if (v_LOOP_2DLIST_2D906_4 == NIL) {
goto t_END_2DLOOP_11;
}
v_X_12 = v_LOOP_2DLIST_2D906_4;
v_X_3 = ((LP) DEREF((v_X_12) + 0 * 4));
v_X_14 = v_LOOP_2DLIST_2D906_4;
v_LOOP_2DLIST_2D906_4 = ((LP) DEREF((v_X_14) + 1 * 4));
if (v_OPTIONAL_3F_5 != NIL) {
t1 = ICALL(s_lsp_MEMQ) (2, v_X_3, LREF(k2375));
v_G3687_16 = ICALL(s_lsp_NOT) (1, t1);
} else {
v_G3687_16 = LREF(s_lsp_NIL);
}
if (v_G3687_16 != NIL) {
v_OPTIONAL_3F_5 = v_G3687_16;
} else {
v_OPTIONAL_3F_5 = ICALL(s_lsp_EQ) (2, v_X_3, LREF(s_lsp__26OPTIONAL));
}
t3 = ICALL(s_lsp_EQ) (2, v_X_3, LREF(s_lsp__26OPTIONAL));
if (t3 != NIL) {
t2 = LREF(s_lsp_NIL);
} else {
if (v_OPTIONAL_3F_5 != NIL) {
t2 = ICALL(s_lsp_SYMBOLP) (1, v_X_3);
} else {
t2 = LREF(s_lsp_NIL);
}
}
if (t2 != NIL) {
v_X_20 = v_X_3;
v_X_17 = v_DEFAULT_1;
v_Y_18 = LREF(s_lsp_NIL);
v_Y_21 = (c_cons((v_DEFAULT_1), (LREF(s_lsp_NIL))));
v_X_23 = (c_cons((v_X_20), (v_Y_21)));
} else {
v_X_23 = v_X_3;
}
v_LOOPVAR_2D909_8 = (c_cons((v_X_23), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D908_7 != NIL) {
v_C_26 = v_LOOPVAR_2D908_7;
v_NEW_2DCDR_27 = v_LOOPVAR_2D909_8;
v_V_30 = v_NEW_2DCDR_27;
((LP) (DEREF((v_C_26) + 1 * 4) = (LD) (v_V_30)));
v_X_32 = v_C_26;
v_LOOPVAR_2D908_7 = ((LP) DEREF((v_X_32) + 1 * 4));
} else {
v_LOOPVAR_2D907_6 = v_LOOPVAR_2D909_8;
v_LOOPVAR_2D908_7 = v_LOOPVAR_2D907_6;
}
goto t_NEXT_2DLOOP_10;
goto t_END_2DLOOP_11;
t_END_2DLOOP_11:;
return(v_LOOPVAR_2D907_6);
return(NIL);
return(NIL);
}

LP p_lsp_MACRO_2DARG_2DLIST(argc, v_SYMBOL_0, v_TABLE_1)
      ARGC argc;  LP v_SYMBOL_0; LP v_TABLE_1;
{
LP v_I_7; LP v_S_6; LP v_S_4; 
LP v_EXPANDER_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 2) wna(argc,2);
v_EXPANDER_3 = ICALL(s_lsp_LOOKUP_2DMACRO_2DEXPANDER) (3, v_SYMBOL_0, v_TABLE_1, LREF(s_lsp_NIL));
if (v_EXPANDER_3 != NIL) {
v_S_4 = v_EXPANDER_3;
v_S_6 = v_EXPANDER_3;
v_I_7 = (LP) 2;
t0 = ((LP) DEREF((v_EXPANDER_3) + 1 * 4));
return(t0);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_MACRO_2DFUNCTION(argc, v_SYMBOL_0)
      ARGC argc;  LP v_SYMBOL_0;
{
LP v_I_6; LP v_S_5; LP v_S_3; 
LP v_EXPANDER_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AMACRO_2DEXPANDERS_2A));
v_EXPANDER_2 = ICALL(s_lsp_LOOKUP_2DMACRO_2DEXPANDER) (3, v_SYMBOL_0, t0, LREF(s_lsp_NIL));
if (v_EXPANDER_2 != NIL) {
v_S_3 = v_EXPANDER_2;
v_S_5 = v_EXPANDER_2;
v_I_6 = (LP) 4;
t1 = ((LP) DEREF((v_EXPANDER_2) + 2 * 4));
return(t1);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_MACROEXPAND_2D1(va_alist) va_dcl
{
LP v_FORM_0; LP v_LOCAL_2DMACRO_2DENV_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_FORM_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_LOCAL_2DMACRO_2DENV_1 = NIL;
} else {
v_LOCAL_2DMACRO_2DENV_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AMACRO_2DEXPANDERS_2A));
t0 = ICALL(s_lsp_EXPAND_2DMACRO) (MV_CALL(argc,5), v_FORM_0, t1, v_LOCAL_2DMACRO_2DENV_1, LREF(s_lsp_NIL), LREF(s_lsp_NIL));
return(t0);
}

LP p_lsp_MACROEXPAND_2D1_2DW(va_alist) va_dcl
{
LP v_FORM_0; LP v_LOCAL_2DMACRO_2DENV_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_FORM_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_LOCAL_2DMACRO_2DENV_1 = NIL;
} else {
v_LOCAL_2DMACRO_2DENV_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AMACRO_2DEXPANDERS_2A));
t0 = ICALL(s_lsp_EXPAND_2DMACRO) (MV_CALL(argc,5), v_FORM_0, t1, v_LOCAL_2DMACRO_2DENV_1, LREF(s_lsp_NIL), LREF(s_lsp_NIL));
return(t0);
}

LP p_lsp_MACROEXPAND_2DW(va_alist) va_dcl
{
LP v_FORM_0; LP v_LOCAL_2DMACRO_2DENV_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_FORM_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_LOCAL_2DMACRO_2DENV_1 = NIL;
} else {
v_LOCAL_2DMACRO_2DENV_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AMACRO_2DEXPANDERS_2A));
t0 = ICALL(s_lsp_EXPAND_2DMACRO) (MV_CALL(argc,5), v_FORM_0, t1, v_LOCAL_2DMACRO_2DENV_1, LREF(s_lsp_T), LREF(s_lsp_NIL));
return(t0);
}

LP p_lsp_MACROEXPAND(va_alist) va_dcl
{
LP v_FORM_0; LP v_LOCAL_2DMACRO_2DENV_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_FORM_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_LOCAL_2DMACRO_2DENV_1 = NIL;
} else {
v_LOCAL_2DMACRO_2DENV_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AMACRO_2DEXPANDERS_2A));
t0 = ICALL(s_lsp_EXPAND_2DMACRO) (MV_CALL(argc,5), v_FORM_0, t1, v_LOCAL_2DMACRO_2DENV_1, LREF(s_lsp_T), LREF(s_lsp_NIL));
return(t0);
}

LP p_lsp_N_2DLIST(argc, v_N_0, v_INIT_2DFUNC_1)
      ARGC argc;  LP v_N_0; LP v_INIT_2DFUNC_1;
{
LP v_Y_4; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 

if (argc != 2) wna(argc,2);
t1 = (num_equal_p((v_N_0), ((LP) 0)));
if (t1 != NIL) {
return(LREF(s_lsp_NIL));
} else {
v_X_3 = CODE_PTR(COERCE_TO_FUNCTION(v_INIT_2DFUNC_1))(0);
t2 = ICALL(s_lsp_1_2D) (1, v_N_0);
v_Y_4 = ICALL(s_lsp_N_2DLIST) (2, t2, v_INIT_2DFUNC_1);
t0 = (c_cons((v_X_3), (v_Y_4)));
return(t0);
}
}

LP p_lsp_NAMES_2D_3ESYMBOL(va_alist) va_dcl
{
LP v_X_23; LP v_V_21; LP v_X_20; 
LP v_NEW_2DCDR_18; LP v_C_17; LP v_Y_15; 
LP v_X_14; LP v_X_12; LP v_X_10; 
LP v_LOOPVAR_2D913_6; LP v_LOOPVAR_2D912_5; LP v_LOOPVAR_2D911_4; 
LP v_LOOP_2DLIST_2D910_3; LP v_L3688_2; LP v_NAMES_0; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTIFY(v_NAMES_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_L3688_2 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D910_3 = v_NAMES_0;
v_LOOPVAR_2D911_4 = LREF(s_lsp_NIL);
v_LOOPVAR_2D912_5 = LREF(s_lsp_NIL);
v_LOOPVAR_2D913_6 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_8:;
if (v_LOOP_2DLIST_2D910_3 == NIL) {
goto t_END_2DLOOP_9;
}
v_X_10 = v_LOOP_2DLIST_2D910_3;
v_L3688_2 = ((LP) DEREF((v_X_10) + 0 * 4));
v_X_12 = v_LOOP_2DLIST_2D910_3;
v_LOOP_2DLIST_2D910_3 = ((LP) DEREF((v_X_12) + 1 * 4));
v_X_14 = ICALL(s_lsp_STRING) (1, v_L3688_2);
v_LOOPVAR_2D913_6 = (c_cons((v_X_14), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D912_5 != NIL) {
v_C_17 = v_LOOPVAR_2D912_5;
v_NEW_2DCDR_18 = v_LOOPVAR_2D913_6;
v_V_21 = v_NEW_2DCDR_18;
((LP) (DEREF((v_C_17) + 1 * 4) = (LD) (v_V_21)));
v_X_23 = v_C_17;
v_LOOPVAR_2D912_5 = ((LP) DEREF((v_X_23) + 1 * 4));
} else {
v_LOOPVAR_2D911_4 = v_LOOPVAR_2D913_6;
v_LOOPVAR_2D912_5 = v_LOOPVAR_2D911_4;
}
goto t_NEXT_2DLOOP_8;
goto t_END_2DLOOP_9;
t_END_2DLOOP_9:;
t2 = v_LOOPVAR_2D911_4;
goto b_NIL_7;
t2 = NIL;
b_NIL_7:;
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_CONCATENATE));
t1 = p_lsp_APPLY(3, COERCE_TO_FUNCTION(t3), LREF(s_lsp_STRING), t2);
t0 = ICALL(s_lsp_INTERN) (MV_CALL(argc,1), t1);
return(t0);
}

LP p_lsp_PARSE_2DBODY(argc, v_BODY_0)
      ARGC argc;  LP v_BODY_0;
{
LP v_X_7; LP v_X_5; LP v_X_3; 
LP f_SEPARATE_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; 
if (argc != 1) wna(argc,1);
t0 = NEW_OE(1);
t1 = MAKE_CLOSURE(p_lsp_PARSE_2DBODY_2DSEPARATE2384,t0);
f_SEPARATE_2 = t1;
SET_OE_SLOT(t0,0,f_SEPARATE_2);
v_X_7 = v_BODY_0;
t5 = ((LP) DEREF((v_BODY_0) + 0 * 4));
t4 = ICALL(s_lsp_STRINGP) (1, t5);
if (t4 != NIL) {
v_X_5 = v_BODY_0;
t6 = ((LP) DEREF((v_BODY_0) + 1 * 4));
if (t6 != NIL) {
v_X_3 = v_BODY_0;
t3 = ((LP) DEREF((v_BODY_0) + 1 * 4));
} else {
t3 = v_BODY_0;
}
} else {
t3 = v_BODY_0;
}
t2 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(MV_CALL(argc,2), t3, LREF(s_lsp_NIL));
return(t2);
}

LP p_lsp_PARSE_2DBODY_2DSEPARATE2384(argc, v_REST_0, v_DECLS_1)
      ARGC argc;  LP v_REST_0; LP v_DECLS_1;
{
LP v_X_11; LP v_G3689_10; LP v_X_8; 
LP v_X_6; LP v_FORM_5; LP v_X_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; 
if (argc != 2) wna(argc,2);
t0 = OE;
v_X_3 = v_REST_0;
v_FORM_5 = ((LP) DEREF((v_REST_0) + 0 * 4));
v_G3689_10 = ICALL(s_lsp_ATOM) (1, v_FORM_5);
if (v_G3689_10 != NIL) {
t2 = v_G3689_10;
} else {
v_X_11 = v_FORM_5;
t4 = ((LP) DEREF((v_FORM_5) + 0 * 4));
t3 = ICALL(s_lsp_EQ) (2, t4, LREF(s_lsp_DECLARE));
t2 = ICALL(s_lsp_NOT) (1, t3);
}
if (t2 != NIL) {
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,v_DECLS_1);
}
return(v_REST_0);
} else {
v_X_6 = v_REST_0;
t5 = ((LP) DEREF((v_REST_0) + 1 * 4));
v_X_8 = v_FORM_5;
t7 = ((LP) DEREF((v_FORM_5) + 1 * 4));
t6 = ICALL(s_lsp_APPEND_2F2) (2, t7, v_DECLS_1);
t1 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(MV_CALL(argc,2), t5, t6);
return(t1);
}
}

LP p_lsp_PARSE_2DIN_2FOUT(argc, v_SPEC_0)
      ARGC argc;  LP v_SPEC_0;
{
LP v_X_118; LP v_V_116; LP v_X_115; 
LP v_NEW_2DCDR_113; LP v_C_112; LP v_Y_110; 
LP v_X_109; LP v_X_107; LP v_X_105; 
LP v_C_103; LP v_LIST_101; LP v_X_99; 
LP v_X_97; LP v_LOOPVAR_2D929_93; LP v_LOOPVAR_2D928_92; 
LP v_LOOPVAR_2D927_91; LP v_LOOP_2DLIST_2D926_90; LP v_L3693_89; 
LP v_X_87; LP v_V_85; LP v_X_84; 
LP v_NEW_2DCDR_82; LP v_C_81; LP v_Y_79; 
LP v_X_78; LP v_X_76; LP v_X_74; 
LP v_C_72; LP v_LIST_70; LP v_X_68; 
LP v_X_66; LP v_LOOPVAR_2D925_62; LP v_LOOPVAR_2D924_61; 
LP v_LOOPVAR_2D923_60; LP v_LOOP_2DLIST_2D922_59; LP v_L3692_58; 
LP v_X_56; LP v_V_54; LP v_X_53; 
LP v_NEW_2DCDR_51; LP v_C_50; LP v_Y_48; 
LP v_X_47; LP v_X_45; LP v_LIST_43; 
LP v_X_41; LP v_X_39; LP v_LOOPVAR_2D921_35; 
LP v_LOOPVAR_2D920_34; LP v_LOOPVAR_2D919_33; LP v_LOOP_2DLIST_2D918_32; 
LP v_L3691_31; LP v_X_29; LP v_V_27; 
LP v_X_26; LP v_NEW_2DCDR_24; LP v_C_23; 
LP v_Y_21; LP v_X_20; LP v_X_18; 
LP v_LIST_16; LP v_X_14; LP v_X_12; 
LP v_LOOPVAR_2D917_8; LP v_LOOPVAR_2D916_7; LP v_LOOPVAR_2D915_6; 
LP v_LOOP_2DLIST_2D914_5; LP v_L3690_4; LP v_O_3; 
LP v_I_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; 
if (argc != 1) wna(argc,1);
{
int real_argc;
BEGIN_MV_CALL(mv_holder2385,0);
t1 = ICALL(s_lsp_MEMQ) (2, LREF(s_lsp__3D_3E), v_SPEC_0);
if (t1 != NIL) {
t3 = ICALL(s_lsp_POSITION) (2, LREF(s_lsp__3D_3E), v_SPEC_0);
t2 = ICALL(s_lsp_SUBSEQ) (3, v_SPEC_0, (LP) 0, t3);
t6 = ICALL(s_lsp_POSITION) (2, LREF(s_lsp__3D_3E), v_SPEC_0);
t5 = ICALL(s_lsp_1_2B) (1, t6);
t4 = ICALL(s_lsp_SUBSEQ) (2, v_SPEC_0, t5);
SET_MV_RETURN_FLAG(mv_holder2385);
SET_MV_RETURN_COUNT(mv_holder2385,2);
SET_MV_RETURN_VALUE(mv_holder2385,1,t4);
t0 = t2;
} else {
SET_MV_RETURN_FLAG(mv_holder2385);
SET_MV_RETURN_COUNT(mv_holder2385,2);
SET_MV_RETURN_VALUE(mv_holder2385,1,LREF(s_lsp_NIL));
t0 = v_SPEC_0;
}
SET_MV_RETURN_VALUE(mv_holder2385,0,t0);
if SV_RETURN_P(mv_holder2385) SET_MV_RETURN_COUNT(mv_holder2385,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder2385);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_I_2 = NIL;
} else {
v_I_2 = NEXT_VAR_VALUE(mv_holder2385);
}
if (real_argc < 2) {
v_O_3 = NIL;
} else {
v_O_3 = NEXT_VAR_VALUE(mv_holder2385);
}
END_VAR_VALUES;
END_MV_CALL;
v_L3690_4 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D914_5 = v_I_2;
v_LOOPVAR_2D915_6 = LREF(s_lsp_NIL);
v_LOOPVAR_2D916_7 = LREF(s_lsp_NIL);
v_LOOPVAR_2D917_8 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_10:;
if (v_LOOP_2DLIST_2D914_5 == NIL) {
goto t_END_2DLOOP_11;
}
v_X_12 = v_LOOP_2DLIST_2D914_5;
v_L3690_4 = ((LP) DEREF((v_X_12) + 0 * 4));
v_X_14 = v_LOOP_2DLIST_2D914_5;
v_LOOP_2DLIST_2D914_5 = ((LP) DEREF((v_X_14) + 1 * 4));
v_LIST_16 = v_L3690_4;
v_X_18 = v_LIST_16;
v_X_20 = ((LP) DEREF((v_LIST_16) + 0 * 4));
v_LOOPVAR_2D917_8 = (c_cons((v_X_20), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D916_7 != NIL) {
v_C_23 = v_LOOPVAR_2D916_7;
v_NEW_2DCDR_24 = v_LOOPVAR_2D917_8;
v_V_27 = v_NEW_2DCDR_24;
((LP) (DEREF((v_C_23) + 1 * 4) = (LD) (v_V_27)));
v_X_29 = v_C_23;
v_LOOPVAR_2D916_7 = ((LP) DEREF((v_X_29) + 1 * 4));
} else {
v_LOOPVAR_2D915_6 = v_LOOPVAR_2D917_8;
v_LOOPVAR_2D916_7 = v_LOOPVAR_2D915_6;
}
goto t_NEXT_2DLOOP_10;
goto t_END_2DLOOP_11;
t_END_2DLOOP_11:;
t7 = v_LOOPVAR_2D915_6;
goto b_NIL_9;
t7 = NIL;
b_NIL_9:;
v_L3691_31 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D918_32 = v_O_3;
v_LOOPVAR_2D919_33 = LREF(s_lsp_NIL);
v_LOOPVAR_2D920_34 = LREF(s_lsp_NIL);
v_LOOPVAR_2D921_35 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_37:;
if (v_LOOP_2DLIST_2D918_32 == NIL) {
goto t_END_2DLOOP_38;
}
v_X_39 = v_LOOP_2DLIST_2D918_32;
v_L3691_31 = ((LP) DEREF((v_X_39) + 0 * 4));
v_X_41 = v_LOOP_2DLIST_2D918_32;
v_LOOP_2DLIST_2D918_32 = ((LP) DEREF((v_X_41) + 1 * 4));
v_LIST_43 = v_L3691_31;
v_X_45 = v_LIST_43;
v_X_47 = ((LP) DEREF((v_LIST_43) + 0 * 4));
v_LOOPVAR_2D921_35 = (c_cons((v_X_47), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D920_34 != NIL) {
v_C_50 = v_LOOPVAR_2D920_34;
v_NEW_2DCDR_51 = v_LOOPVAR_2D921_35;
v_V_54 = v_NEW_2DCDR_51;
((LP) (DEREF((v_C_50) + 1 * 4) = (LD) (v_V_54)));
v_X_56 = v_C_50;
v_LOOPVAR_2D920_34 = ((LP) DEREF((v_X_56) + 1 * 4));
} else {
v_LOOPVAR_2D919_33 = v_LOOPVAR_2D921_35;
v_LOOPVAR_2D920_34 = v_LOOPVAR_2D919_33;
}
goto t_NEXT_2DLOOP_37;
goto t_END_2DLOOP_38;
t_END_2DLOOP_38:;
t8 = v_LOOPVAR_2D919_33;
goto b_NIL_36;
t8 = NIL;
b_NIL_36:;
v_L3692_58 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D922_59 = v_I_2;
v_LOOPVAR_2D923_60 = LREF(s_lsp_NIL);
v_LOOPVAR_2D924_61 = LREF(s_lsp_NIL);
v_LOOPVAR_2D925_62 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_64:;
if (v_LOOP_2DLIST_2D922_59 == NIL) {
goto t_END_2DLOOP_65;
}
v_X_66 = v_LOOP_2DLIST_2D922_59;
v_L3692_58 = ((LP) DEREF((v_X_66) + 0 * 4));
v_X_68 = v_LOOP_2DLIST_2D922_59;
v_LOOP_2DLIST_2D922_59 = ((LP) DEREF((v_X_68) + 1 * 4));
v_LIST_70 = v_L3692_58;
v_C_72 = v_LIST_70;
v_X_74 = v_LIST_70;
v_X_76 = ((LP) DEREF((v_LIST_70) + 1 * 4));
v_X_78 = ((LP) DEREF((v_X_76) + 0 * 4));
v_LOOPVAR_2D925_62 = (c_cons((v_X_78), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D924_61 != NIL) {
v_C_81 = v_LOOPVAR_2D924_61;
v_NEW_2DCDR_82 = v_LOOPVAR_2D925_62;
v_V_85 = v_NEW_2DCDR_82;
((LP) (DEREF((v_C_81) + 1 * 4) = (LD) (v_V_85)));
v_X_87 = v_C_81;
v_LOOPVAR_2D924_61 = ((LP) DEREF((v_X_87) + 1 * 4));
} else {
v_LOOPVAR_2D923_60 = v_LOOPVAR_2D925_62;
v_LOOPVAR_2D924_61 = v_LOOPVAR_2D923_60;
}
goto t_NEXT_2DLOOP_64;
goto t_END_2DLOOP_65;
t_END_2DLOOP_65:;
t9 = v_LOOPVAR_2D923_60;
goto b_NIL_63;
t9 = NIL;
b_NIL_63:;
v_L3693_89 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D926_90 = v_O_3;
v_LOOPVAR_2D927_91 = LREF(s_lsp_NIL);
v_LOOPVAR_2D928_92 = LREF(s_lsp_NIL);
v_LOOPVAR_2D929_93 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_95:;
if (v_LOOP_2DLIST_2D926_90 == NIL) {
goto t_END_2DLOOP_96;
}
v_X_97 = v_LOOP_2DLIST_2D926_90;
v_L3693_89 = ((LP) DEREF((v_X_97) + 0 * 4));
v_X_99 = v_LOOP_2DLIST_2D926_90;
v_LOOP_2DLIST_2D926_90 = ((LP) DEREF((v_X_99) + 1 * 4));
v_LIST_101 = v_L3693_89;
v_C_103 = v_LIST_101;
v_X_105 = v_LIST_101;
v_X_107 = ((LP) DEREF((v_LIST_101) + 1 * 4));
v_X_109 = ((LP) DEREF((v_X_107) + 0 * 4));
v_LOOPVAR_2D929_93 = (c_cons((v_X_109), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D928_92 != NIL) {
v_C_112 = v_LOOPVAR_2D928_92;
v_NEW_2DCDR_113 = v_LOOPVAR_2D929_93;
v_V_116 = v_NEW_2DCDR_113;
((LP) (DEREF((v_C_112) + 1 * 4) = (LD) (v_V_116)));
v_X_118 = v_C_112;
v_LOOPVAR_2D928_92 = ((LP) DEREF((v_X_118) + 1 * 4));
} else {
v_LOOPVAR_2D927_91 = v_LOOPVAR_2D929_93;
v_LOOPVAR_2D928_92 = v_LOOPVAR_2D927_91;
}
goto t_NEXT_2DLOOP_95;
goto t_END_2DLOOP_96;
t_END_2DLOOP_96:;
t10 = v_LOOPVAR_2D927_91;
goto b_NIL_94;
t10 = NIL;
b_NIL_94:;
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,4);
SET_MV_RETURN_VALUE(argc,1,t8);
SET_MV_RETURN_VALUE(argc,2,t9);
SET_MV_RETURN_VALUE(argc,3,t10);
}
return(t7);
}
}

LP p_lsp_PARSE_2DMACRO_2DDEFINITION(argc, v_NAME_0, v_ARGS_1, v_OPTIONAL_2DDEFAULT_2, v_BODY_3)
      ARGC argc;  LP v_NAME_0; LP v_ARGS_1; LP v_OPTIONAL_2DDEFAULT_2; LP v_BODY_3;
{
LP v_X_91; LP v_X_89; LP v_X_87; 
LP v_C_85; LP v_X_83; LP v_X_81; 
LP v_C_79; LP v_LIST_77; LP v_X_75; 
LP v_X_73; LP v_C_71; LP v_X_69; 
LP v_X_67; LP v_C_65; LP v_LIST_63; 
LP v_ENV_62; LP v_Y_60; LP v_X_59; 
LP v_Y_57; LP v_X_56; LP v_Y_54; 
LP v_X_53; LP v_Y_51; LP v_X_50; 
LP v_Y_48; LP v_X_47; LP v_Y_45; 
LP v_X_44; LP v_Y_42; LP v_X_41; 
LP v_Y_39; LP v_X_38; LP v_Y_36; 
LP v_X_35; LP v_Y_33; LP v_X_32; 
LP v_Y_30; LP v_X_29; LP v_Y_27; 
LP v_X_26; LP v_Y_24; LP v_X_23; 
LP v_Y_21; LP v_X_20; LP v_Y_18; 
LP v_X_17; LP v_DBIND_2DLIST_16; LP v_Y_14; 
LP v_X_13; LP v_Y_11; LP v_X_10; 
LP v_ARGS_2DWITHOUT_2DMACRO_2DSTUFF_9; LP v_ENV_2DARG_8; LP v_ARGS_2DWITHOUT_2DWHOLE_7; 
LP v_WHOLE_2DARG_6; LP v_ARGS_2DWITHOUT_2D_26BODY_5; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; 
if (argc != 4) wna(argc,4);
v_ARGS_2DWITHOUT_2D_26BODY_5 = ICALL(s_lsp_SUBST) (3, LREF(s_lsp__26REST), LREF(s_lsp__26BODY), v_ARGS_1);
{
int real_argc;
BEGIN_MV_CALL(mv_holder2386,0);
v_X_91 = v_ARGS_2DWITHOUT_2D_26BODY_5;
t2 = ((LP) DEREF((v_ARGS_2DWITHOUT_2D_26BODY_5) + 0 * 4));
t1 = ICALL(s_lsp_EQ) (2, t2, LREF(s_lsp__26WHOLE));
if (t1 != NIL) {
v_LIST_77 = v_ARGS_2DWITHOUT_2D_26BODY_5;
v_C_79 = v_ARGS_2DWITHOUT_2D_26BODY_5;
v_X_81 = v_ARGS_2DWITHOUT_2D_26BODY_5;
v_X_83 = ((LP) DEREF((v_ARGS_2DWITHOUT_2D_26BODY_5) + 1 * 4));
t3 = ((LP) DEREF((v_X_83) + 0 * 4));
v_C_85 = v_ARGS_2DWITHOUT_2D_26BODY_5;
v_X_87 = v_ARGS_2DWITHOUT_2D_26BODY_5;
v_X_89 = ((LP) DEREF((v_ARGS_2DWITHOUT_2D_26BODY_5) + 1 * 4));
t4 = ((LP) DEREF((v_X_89) + 1 * 4));
SET_MV_RETURN_FLAG(mv_holder2386);
SET_MV_RETURN_COUNT(mv_holder2386,2);
SET_MV_RETURN_VALUE(mv_holder2386,1,t4);
t0 = t3;
} else {
t5 = ICALL(s_lsp_GENSYM) (1, LREF(k2388));
SET_MV_RETURN_FLAG(mv_holder2386);
SET_MV_RETURN_COUNT(mv_holder2386,2);
SET_MV_RETURN_VALUE(mv_holder2386,1,v_ARGS_2DWITHOUT_2D_26BODY_5);
t0 = t5;
}
SET_MV_RETURN_VALUE(mv_holder2386,0,t0);
if SV_RETURN_P(mv_holder2386) SET_MV_RETURN_COUNT(mv_holder2386,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder2386);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_WHOLE_2DARG_6 = NIL;
} else {
v_WHOLE_2DARG_6 = NEXT_VAR_VALUE(mv_holder2386);
}
if (real_argc < 2) {
v_ARGS_2DWITHOUT_2DWHOLE_7 = NIL;
} else {
v_ARGS_2DWITHOUT_2DWHOLE_7 = NEXT_VAR_VALUE(mv_holder2386);
}
END_VAR_VALUES;
END_MV_CALL;
{
int real_argc;
BEGIN_MV_CALL(mv_holder2387,0);
v_ENV_62 = ICALL(s_lsp_MEMQ) (2, LREF(s_lsp__26ENVIRONMENT), v_ARGS_2DWITHOUT_2DWHOLE_7);
if (v_ENV_62 != NIL) {
v_LIST_63 = v_ENV_62;
v_C_65 = v_ENV_62;
v_X_67 = v_ENV_62;
v_X_69 = ((LP) DEREF((v_ENV_62) + 1 * 4));
t7 = ((LP) DEREF((v_X_69) + 0 * 4));
t9 = ICALL(s_lsp_UPTO) (2, LREF(s_lsp__26ENVIRONMENT), v_ARGS_2DWITHOUT_2DWHOLE_7);
v_C_71 = v_ENV_62;
v_X_73 = v_ENV_62;
v_X_75 = ((LP) DEREF((v_ENV_62) + 1 * 4));
t10 = ((LP) DEREF((v_X_75) + 1 * 4));
t8 = ICALL(s_lsp_APPEND_2F2) (2, t9, t10);
SET_MV_RETURN_FLAG(mv_holder2387);
SET_MV_RETURN_COUNT(mv_holder2387,2);
SET_MV_RETURN_VALUE(mv_holder2387,1,t8);
t6 = t7;
} else {
t11 = ICALL(s_lsp_GENSYM) (1, LREF(k2389));
SET_MV_RETURN_FLAG(mv_holder2387);
SET_MV_RETURN_COUNT(mv_holder2387,2);
SET_MV_RETURN_VALUE(mv_holder2387,1,v_ARGS_2DWITHOUT_2DWHOLE_7);
t6 = t11;
}
SET_MV_RETURN_VALUE(mv_holder2387,0,t6);
if SV_RETURN_P(mv_holder2387) SET_MV_RETURN_COUNT(mv_holder2387,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder2387);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_ENV_2DARG_8 = NIL;
} else {
v_ENV_2DARG_8 = NEXT_VAR_VALUE(mv_holder2387);
}
if (real_argc < 2) {
v_ARGS_2DWITHOUT_2DMACRO_2DSTUFF_9 = NIL;
} else {
v_ARGS_2DWITHOUT_2DMACRO_2DSTUFF_9 = NEXT_VAR_VALUE(mv_holder2387);
}
END_VAR_VALUES;
END_MV_CALL;
if (v_OPTIONAL_2DDEFAULT_2 != NIL) {
v_X_10 = v_OPTIONAL_2DDEFAULT_2;
v_Y_11 = LREF(s_lsp_NIL);
v_Y_14 = (c_cons((v_OPTIONAL_2DDEFAULT_2), (LREF(s_lsp_NIL))));
t12 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_14)));
v_DBIND_2DLIST_16 = ICALL(s_lsp_INSERT_2DOPTIONAL_2DDEFAULT) (2, v_ARGS_2DWITHOUT_2DMACRO_2DSTUFF_9, t12);
} else {
v_DBIND_2DLIST_16 = v_ARGS_2DWITHOUT_2DMACRO_2DSTUFF_9;
}
v_X_17 = v_ENV_2DARG_8;
v_Y_18 = LREF(s_lsp_NIL);
v_Y_21 = (c_cons((v_ENV_2DARG_8), (LREF(s_lsp_NIL))));
v_X_50 = (c_cons((v_WHOLE_2DARG_6), (v_Y_21)));
if (v_DBIND_2DLIST_16 != NIL) {
v_X_23 = v_WHOLE_2DARG_6;
v_Y_24 = LREF(s_lsp_NIL);
v_Y_27 = (c_cons((v_WHOLE_2DARG_6), (LREF(s_lsp_NIL))));
v_X_29 = (c_cons((LREF(s_lsp_CDR)), (v_Y_27)));
v_Y_33 = (c_cons((v_X_29), (LREF(s_lsp_NIL))));
t13 = (c_cons((v_DBIND_2DLIST_16), (v_Y_33)));
} else {
t13 = LREF(k2390);
}
v_Y_36 = ICALL(s_lsp_APPEND_2F2) (2, t13, v_BODY_3);
v_X_38 = (c_cons((LREF(s_lsp_DESTRUCTURING_2DBIND)), (v_Y_36)));
v_Y_42 = (c_cons((v_X_38), (LREF(s_lsp_NIL))));
v_Y_45 = (c_cons((v_NAME_0), (v_Y_42)));
v_X_47 = (c_cons((LREF(s_lsp_BLOCK)), (v_Y_45)));
v_Y_51 = (c_cons((v_X_47), (LREF(s_lsp_NIL))));
v_Y_54 = (c_cons((v_X_50), (v_Y_51)));
v_X_56 = (c_cons((LREF(s_lsp_LAMBDA)), (v_Y_54)));
v_Y_60 = (c_cons((v_X_56), (LREF(s_lsp_NIL))));
t14 = (c_cons((LREF(s_lsp_FUNCTION)), (v_Y_60)));
return(t14);
}
}
}

LP p_lsp_QUOTED_2DCONSTANT_2DP(argc, v_L_0)
      ARGC argc;  LP v_L_0;
{
LP v_X_10; LP v_LIST_8; LP v_X_6; 
LP v_X_4; LP v_C_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 

if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_LISTP) (1, v_L_0);
if (t1 != NIL) {
v_LIST_8 = v_L_0;
v_X_10 = v_L_0;
t3 = ((LP) DEREF((v_L_0) + 0 * 4));
t2 = ICALL(s_lsp_EQ) (2, t3, LREF(s_lsp_QUOTE));
if (t2 != NIL) {
v_C_2 = v_L_0;
v_X_4 = v_L_0;
v_X_6 = ((LP) DEREF((v_L_0) + 1 * 4));
t4 = ((LP) DEREF((v_X_6) + 1 * 4));
t0 = ICALL(s_lsp_NULL) (MV_CALL(argc,1), t4);
return(t0);
} else {
return(LREF(s_lsp_NIL));
}
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_REMOVE_2DCOMPILER_2DMACRO_2DEXPANDER(argc, v_NAME_0)
      ARGC argc;  LP v_NAME_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ACOMPILER_2DMACRO_2DEXPANDERS_2A));
t0 = ICALL(s_lsp_REMHASH) (MV_CALL(argc,2), v_NAME_0, t1);
return(t0);
}

LP p_lsp_REMOVE_2DMACRO_2DEXPANDER(argc, v_NAME_0)
      ARGC argc;  LP v_NAME_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AMACRO_2DEXPANDERS_2A));
t0 = ICALL(s_lsp_REMHASH) (MV_CALL(argc,2), v_NAME_0, t1);
return(t0);
}

LP p_lsp_REMOVE_2DTYPE_2DMACRO_2DEXPANDER(argc, v_NAME_0)
      ARGC argc;  LP v_NAME_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ATYPE_2DMACRO_2DEXPANDERS_2A));
t0 = ICALL(s_lsp_REMHASH) (MV_CALL(argc,2), v_NAME_0, t1);
return(t0);
}

LP p_lsp_SAME_2DLENGTH_2DP(argc, v_L1_0, v_L2_1)
      ARGC argc;  LP v_L1_0; LP v_L2_1;
{
LP v_X_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; 
if (argc != 2) wna(argc,2);
START2392:
t1 = ICALL(s_lsp_EQ) (2, v_L1_0, LREF(s_lsp_NIL));
if (t1 != NIL) {
t0 = ICALL(s_lsp_EQ) (MV_CALL(argc,2), v_L2_1, LREF(s_lsp_NIL));
return(t0);
} else {
t2 = ICALL(s_lsp_EQ) (2, v_L2_1, LREF(s_lsp_NIL));
if (t2 != NIL) {
return(LREF(s_lsp_NIL));
} else {
v_X_3 = v_L1_0;
t3 = ((LP) DEREF((v_L1_0) + 1 * 4));
v_X_5 = v_L2_1;
t4 = ((LP) DEREF((v_L2_1) + 1 * 4));
v_L1_0 = t3; v_L2_1 = t4; 
goto START2392;
}
}
}

LP p_lsp_TREE_2DFIND(argc, v_E_0, v_TREE_1)
      ARGC argc;  LP v_E_0; LP v_TREE_1;
{
LP f_LOOPY_3; 
LP t0; LP t1; LP t2; LP t3; 
if (argc != 2) wna(argc,2);
t0 = NEW_OE(2);
SET_OE_SLOT(t0,1,v_E_0);
t1 = MAKE_CLOSURE(p_lsp_TREE_2DFIND_2DLOOPY2393,t0);
f_LOOPY_3 = t1;
SET_OE_SLOT(t0,0,f_LOOPY_3);
t2 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(MV_CALL(argc,1), v_TREE_1);
return(t2);
}

LP p_lsp_TREE_2DFIND_2DLOOPY2393(argc, v_REST_0)
      ARGC argc;  LP v_REST_0;
{
LP v_X_5; LP v_G3694_4; LP v_X_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 

if (argc != 1) wna(argc,1);
t0 = OE;
t2 = ICALL(s_lsp_ATOM) (1, v_REST_0);
if (t2 != NIL) {
if (v_REST_0 != NIL) {
t1 = ICALL(s_lsp_EQ) (MV_CALL(argc,2), GET_OE_SLOT(t0,1), v_REST_0);
return(t1);
} else {
return(LREF(s_lsp_NIL));
}
} else {
v_X_2 = v_REST_0;
t3 = ((LP) DEREF((v_REST_0) + 0 * 4));
v_G3694_4 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(1, t3);
if (v_G3694_4 != NIL) {
return(v_G3694_4);
} else {
v_X_5 = v_REST_0;
t4 = ((LP) DEREF((v_REST_0) + 1 * 4));
t1 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(MV_CALL(argc,1), t4);
return(t1);
}
}
}

LP p_lsp_UPTO(argc, v_E_0, v_L_1)
      ARGC argc;  LP v_E_0; LP v_L_1;
{
LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 2) wna(argc,2);
t1 = ICALL(s_lsp_REVERSE) (1, v_L_1);
v_X_3 = ICALL(s_lsp_MEMQL) (2, v_E_0, t1);
t2 = ((LP) DEREF((v_X_3) + 1 * 4));
t0 = ICALL(s_lsp_NREVERSE) (MV_CALL(argc,1), t2);
return(t0);
}

LP p_lsp_WALK(argc, v_FUNC_0, v_L_1)
      ARGC argc;  LP v_FUNC_0; LP v_L_1;
{
LP v_X_6; LP v_G3695_5; LP v_X_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 

if (argc != 2) wna(argc,2);
START2394:
t1 = ICALL(s_lsp_ATOM) (1, v_L_1);
if (t1 != NIL) {
if (v_L_1 != NIL) {
t0 = CODE_PTR(COERCE_TO_FUNCTION(v_FUNC_0))(MV_CALL(argc,1), v_L_1);
return(t0);
} else {
return(LREF(s_lsp_NIL));
}
} else {
v_X_3 = v_L_1;
t2 = ((LP) DEREF((v_L_1) + 0 * 4));
v_G3695_5 = ICALL(s_lsp_WALK) (2, v_FUNC_0, t2);
if (v_G3695_5 != NIL) {
return(v_G3695_5);
} else {
v_X_6 = v_L_1;
t3 = ((LP) DEREF((v_L_1) + 1 * 4));
v_L_1 = t3; 
goto START2394;
}
}
}

LP p_lsp_WRAP_2DIN_2DBLOCK(argc, v_BLOCK_2DNAME_0, v_DECLS_2BBODY_1)
      ARGC argc;  LP v_BLOCK_2DNAME_0; LP v_DECLS_2BBODY_1;
{
LP v_Y_12; LP v_X_11; LP v_Y_9; 
LP v_X_8; LP v_Y_6; LP v_X_5; 
LP v_DECLS_4; LP v_BODY_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 

if (argc != 2) wna(argc,2);
{
int real_argc;
BEGIN_MV_CALL(mv_holder2395,0);
t0 = ICALL(s_lsp_PARSE_2DBODY) (MV_CALL(mv_holder2395,1), v_DECLS_2BBODY_1);
SET_MV_RETURN_VALUE(mv_holder2395,0,t0);
if SV_RETURN_P(mv_holder2395) SET_MV_RETURN_COUNT(mv_holder2395,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder2395);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_BODY_3 = NIL;
} else {
v_BODY_3 = NEXT_VAR_VALUE(mv_holder2395);
}
if (real_argc < 2) {
v_DECLS_4 = NIL;
} else {
v_DECLS_4 = NEXT_VAR_VALUE(mv_holder2395);
}
END_VAR_VALUES;
END_MV_CALL;
v_X_5 = LREF(s_lsp_DECLARE);
v_Y_6 = v_DECLS_4;
v_X_11 = (c_cons((LREF(s_lsp_DECLARE)), (v_DECLS_4)));
v_X_8 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_BLOCK), v_BLOCK_2DNAME_0, v_BODY_3);
v_Y_12 = (c_cons((v_X_8), (LREF(s_lsp_NIL))));
t1 = (c_cons((v_X_11), (v_Y_12)));
return(t1);
}
}

