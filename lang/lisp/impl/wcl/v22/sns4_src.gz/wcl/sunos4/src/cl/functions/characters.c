/*
:comment "Compiled at 4:02:48 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: Debug Library"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O2 -fPIC"
:version 0
:end-package-info 0
:sym CHAR>=/2
:sym CHAR<=/2
:sym NIL
:sf ALPHA-CHAR-P "p_lsp_ALPHA_2DCHAR_2DP"
:sym ALPHA-CHAR-P
:sym DIGIT-CHAR-P/2
:sf ALPHANUMERICP "p_lsp_ALPHANUMERICP"
:proclaim (QUOTE (INLINE CHAR-BITS))
:sym CHARACTERP
:sym CHARACTER
:sym WTA
:sf CHAR-BITS "p_lsp_CHAR_2DBITS"
:proclaim (QUOTE (INLINE CHAR-CODE))
:sf CHAR-CODE "p_lsp_CHAR_2DCODE"
:sym CODE-CHAR
:sf CHAR-DOWNCASE "p_lsp_CHAR_2DDOWNCASE"
:proclaim (QUOTE (INLINE CHAR=/2))
:sf CHAR=/2 "p_lsp_CHAR_3D_2F2"
:sym LENGTH
:sym MEMQL
:sym T
:sym EQL
:sf CHAR= "p_lsp_CHAR_3D"
:sym CHAR-DOWNCASE
:sf CHAR-EQUAL/2 "p_lsp_CHAR_2DEQUAL_2F2"
:sym CHAR-EQUAL/2
:sf CHAR-EQUAL "p_lsp_CHAR_2DEQUAL"
:proclaim (QUOTE (INLINE CHAR>=/2))
:sf CHAR>=/2 "p_lsp_CHAR_3E_3D_2F2"
:sf CHAR>= "p_lsp_CHAR_3E_3D"
:sym CHAR>/2
:sf CHAR-GREATERP/2 "p_lsp_CHAR_2DGREATERP_2F2"
:sym CHAR-GREATERP/2
:sf CHAR-GREATERP "p_lsp_CHAR_2DGREATERP"
:sf CHAR>/2 "p_lsp_CHAR_3E_2F2"
:sf CHAR> "p_lsp_CHAR_3E"
:sym CHAR</2
:sf CHAR< "p_lsp_CHAR_3C"
:proclaim (QUOTE (INLINE CHAR<=/2))
:sf CHAR<=/2 "p_lsp_CHAR_3C_3D_2F2"
:sf CHAR<= "p_lsp_CHAR_3C_3D"
:sf CHAR-LESSP/2 "p_lsp_CHAR_2DLESSP_2F2"
:sym CHAR-LESSP/2
:sf CHAR-LESSP "p_lsp_CHAR_2DLESSP"
:proclaim (QUOTE (INLINE CHAR</2))
:sf CHAR</2 "p_lsp_CHAR_3C_2F2"
:sym FORMAT
:sym *CHARACTER-NAMES*
:sym UNSAFE-SYMBOL-VALUE
:sym :TEST
:sym CHAR=
:sym UNSAFE-SYMBOL-FUNCTION
:sym RASSOC
:sym CAR
:sf CHAR-NAME "p_lsp_CHAR_2DNAME"
:sym CHAR/=/2
:sf CHAR/= "p_lsp_CHAR_2F_3D"
:sym CHAR/=
:sf CHAR-NOT-EQUAL/2 "p_lsp_CHAR_2DNOT_2DEQUAL_2F2"
:sym CHAR-NOT-EQUAL/2
:sf CHAR-NOT-EQUAL "p_lsp_CHAR_2DNOT_2DEQUAL"
:sf CHAR-NOT-GREATERP/2 "p_lsp_CHAR_2DNOT_2DGREATERP_2F2"
:sym CHAR-NOT-GREATERP/2
:sf CHAR-NOT-GREATERP "p_lsp_CHAR_2DNOT_2DGREATERP"
:sf CHAR-NOT-LESSP/2 "p_lsp_CHAR_2DNOT_2DLESSP_2F2"
:sym CHAR-NOT-LESSP/2
:sf CHAR-NOT-LESSP "p_lsp_CHAR_2DNOT_2DLESSP"
:sym NOT
:sf CHAR/=/2 "p_lsp_CHAR_2F_3D_2F2"
:sf CHAR-UPCASE "p_lsp_CHAR_2DUPCASE"
:proclaim (QUOTE (INLINE CODE-CHAR))
:sym FIXNUMP
:sym FIXNUM
:sf CODE-CHAR "p_lsp_CODE_2DCHAR"
:sym ERROR
:sf DIGIT-CHAR-P/2 "p_lsp_DIGIT_2DCHAR_2DP_2F2"
:proclaim (QUOTE (INLINE DIGIT-CHAR-P))
:sf DIGIT-CHAR-P "p_lsp_DIGIT_2DCHAR_2DP"
:sym <
:sf LOWER-CASE-P "p_lsp_LOWER_2DCASE_2DP"
:sf BOTH-CASE-P "p_lsp_BOTH_2DCASE_2DP"
:sf GRAPHIC-CHAR-P "p_lsp_GRAPHIC_2DCHAR_2DP"
:sym STRING
:sym STRING-EQUAL
:sym IDENTITY
:sym ASSOC/4
:sym CDR
:sf NAME-CHAR "p_lsp_NAME_2DCHAR"
:proclaim (QUOTE (INLINE SET-CHAR-BIT))
:sym SYMBOLP
:sym SYMBOL
:sf SET-CHAR-BIT "p_lsp_SET_2DCHAR_2DBIT"
:proclaim (QUOTE (INLINE STANDARD-CHAR-P))
:sf STANDARD-CHAR-P "p_lsp_STANDARD_2DCHAR_2DP"
:sf UPPER-CASE-P "p_lsp_UPPER_2DCASE_2DP"
:pinfo CHAR-UPCASE (CHAR) NIL NIL NIL NIL NIL NIL T
:pinfo CHAR>=/2 (CHAR1 CHAR2) NIL (CHARACTER CHARACTER) NIL (LAMBDA (CHAR1 CHAR2) (DECLARE) (BLOCK CHAR>=/2 (%>= (CHAR-CODE CHAR1) (CHAR-CODE CHAR2)))) NIL T T
:pinfo DIGIT-CHAR-P (CHAR &OPTIONAL (RADIX 10)) NIL NIL NIL (LAMBDA (CHAR &OPTIONAL (RADIX 10)) (DECLARE) (BLOCK DIGIT-CHAR-P (DIGIT-CHAR-P/2 CHAR RADIX))) NIL T T
:pinfo CHAR-NOT-LESSP (&RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo ALPHANUMERICP (CHAR) NIL NIL NIL NIL NIL NIL T
:pinfo CHAR-LESSP (&RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo ALPHA-CHAR-P (CHAR) NIL NIL NIL NIL NIL NIL T
:pinfo CHAR-NOT-GREATERP/2 (CHAR1 CHAR2) NIL NIL NIL NIL NIL NIL T
:pinfo CHAR-EQUAL/2 (CHAR1 CHAR2) NIL NIL NIL NIL NIL NIL T
:pinfo CHAR=/2 (CHAR1 CHAR2) NIL (CHARACTER CHARACTER) NIL (LAMBDA (CHAR1 CHAR2) (DECLARE) (BLOCK CHAR=/2 (%EQ CHAR1 CHAR2))) NIL T T
:pinfo CHAR-GREATERP/2 (CHAR1 CHAR2) NIL NIL NIL NIL NIL NIL T
:pinfo CHAR/=/2 (CHAR1 CHAR2) NIL NIL NIL NIL NIL NIL T
:pinfo CHAR-DOWNCASE (CHAR) NIL NIL NIL NIL NIL NIL T
:pinfo CHAR>= (&RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo CHAR-NAME (CHAR) NIL (CHARACTER) NIL NIL NIL NIL T
:pinfo CHAR<= (&RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo CHAR-BITS (C) NIL (CHARACTER) NIL (LAMBDA (C) (DECLARE) (BLOCK CHAR-BITS 0)) NIL T T
:pinfo CHAR-LESSP/2 (CHAR1 CHAR2) NIL NIL NIL NIL NIL NIL T
:pinfo CHAR-NOT-GREATERP (&RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo CHAR-NOT-LESSP/2 (CHAR1 CHAR2) NIL NIL NIL NIL NIL NIL T
:pinfo CHAR-CODE (C) NIL (CHARACTER) NIL (LAMBDA (C) (DECLARE) (BLOCK CHAR-CODE (%CHAR-CODE C))) NIL T T
:pinfo CHAR-NOT-EQUAL (&RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo CHAR-EQUAL (&RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo CHAR< (&RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo CHAR= (&RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo CHAR> (&RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo DIGIT-CHAR-P/2 (CHAR RADIX) NIL NIL NIL NIL NIL NIL T
:pinfo CHAR<=/2 (CHAR1 CHAR2) NIL NIL NIL (LAMBDA (CHAR1 CHAR2) (DECLARE) (BLOCK CHAR<=/2 (%<= (CHAR-CODE CHAR1) (CHAR-CODE CHAR2)))) NIL T T
:pinfo UPPER-CASE-P (CHAR) NIL NIL NIL NIL NIL NIL T
:pinfo LOWER-CASE-P (CHAR) NIL NIL NIL NIL NIL NIL T
:pinfo CHAR-GREATERP (&RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo BOTH-CASE-P (CHAR) NIL NIL NIL NIL NIL NIL T
:pinfo NAME-CHAR (NAME) NIL NIL NIL NIL NIL NIL T
:pinfo CHAR-NOT-EQUAL/2 (CHAR1 CHAR2) NIL NIL NIL NIL NIL NIL T
:pinfo GRAPHIC-CHAR-P (CHAR) NIL NIL NIL NIL NIL NIL T
:pinfo STANDARD-CHAR-P (CHAR) NIL NIL NIL (LAMBDA (CHAR) (DECLARE) (BLOCK STANDARD-CHAR-P (CHARACTERP CHAR))) NIL T T
:pinfo SET-CHAR-BIT (C BIT-NAME VALUE) NIL (CHARACTER SYMBOL FIXNUM) NIL (LAMBDA (C BIT-NAME VALUE) (DECLARE) (BLOCK SET-CHAR-BIT VALUE)) NIL T T
:pinfo CHAR</2 (CHAR1 CHAR2) NIL NIL NIL (LAMBDA (CHAR1 CHAR2) (DECLARE) (BLOCK CHAR</2 (< (CHAR-CODE CHAR1) (CHAR-CODE CHAR2)))) NIL T T
:pinfo CHAR/= (&RESTV ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo CHAR>/2 (CHAR1 CHAR2) NIL NIL NIL NIL NIL NIL T
:pinfo CODE-CHAR (N) NIL (FIXNUM) NIL (LAMBDA (N) (DECLARE) (BLOCK CODE-CHAR (IF (%>= N CHAR-CODE-LIMIT) NIL (%CODE-CHAR N)))) NIL T T
:end
*/

#include "lisp.h"

extern LP p_lsp_ALPHA_2DCHAR_2DP();
extern SYMBOL s_lsp_CHAR_3E_3D_2F2; 
extern SYMBOL s_lsp_CHAR_3C_3D_2F2; 
extern SYMBOL s_lsp_NIL; 
extern LP p_lsp_ALPHANUMERICP();
extern SYMBOL s_lsp_ALPHA_2DCHAR_2DP; 
extern SYMBOL s_lsp_DIGIT_2DCHAR_2DP_2F2; 
extern LP p_lsp_CHAR_2DBITS();
extern SYMBOL s_lsp_CHARACTERP; 
extern SYMBOL s_lsp_CHARACTER; 
extern SYMBOL s_lsp_WTA; 
extern LP p_lsp_CHAR_2DCODE();
extern LP p_lsp_CHAR_2DDOWNCASE();
extern SYMBOL s_lsp_CODE_2DCHAR; 
extern LP p_lsp_CHAR_3D_2F2();
extern LP p_lsp_CHAR_3D();
extern SYMBOL s_lsp_LENGTH; 
MAKE_CONS(k1765,(LP) 2,LREF(s_lsp_NIL));
MAKE_CONS(k1764,(LP) 0,LREF(k1765));
extern SYMBOL s_lsp_MEMQL; 
extern SYMBOL s_lsp_T; 
extern SYMBOL s_lsp_EQL; 
extern LP p_lsp_CHAR_2DEQUAL_2F2();
extern SYMBOL s_lsp_CHAR_2DDOWNCASE; 
extern LP p_lsp_CHAR_2DEQUAL();
extern SYMBOL s_lsp_CHAR_2DEQUAL_2F2; 
extern LP p_lsp_CHAR_3E_3D_2F2();
extern LP p_lsp_CHAR_3E_3D();
extern LP p_lsp_CHAR_2DGREATERP_2F2();
extern SYMBOL s_lsp_CHAR_3E_2F2; 
extern LP p_lsp_CHAR_2DGREATERP();
extern SYMBOL s_lsp_CHAR_2DGREATERP_2F2; 
extern LP p_lsp_CHAR_3E_2F2();
extern LP p_lsp_CHAR_3E();
extern LP p_lsp_CHAR_3C();
extern SYMBOL s_lsp_CHAR_3C_2F2; 
extern LP p_lsp_CHAR_3C_3D_2F2();
extern LP p_lsp_CHAR_3C_3D();
extern LP p_lsp_CHAR_2DLESSP_2F2();
extern LP p_lsp_CHAR_2DLESSP();
extern SYMBOL s_lsp_CHAR_2DLESSP_2F2; 
extern LP p_lsp_CHAR_3C_2F2();
extern LP p_lsp_CHAR_2DNAME();
MAKE_SIMPLE_STRING(k1766,3,"c~X");
extern SYMBOL s_lsp_FORMAT; 
extern SYMBOL s_lsp__2ACHARACTER_2DNAMES_2A; 
extern SYMBOL s_lsp_UNSAFE_2DSYMBOL_2DVALUE; 
extern SYMBOL s_key_TEST; 
extern SYMBOL s_lsp_CHAR_3D; 
extern SYMBOL s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION; 
extern SYMBOL s_lsp_RASSOC; 
extern SYMBOL s_lsp_CAR; 
extern LP p_lsp_CHAR_2F_3D();
extern SYMBOL s_lsp_CHAR_2F_3D_2F2; 
extern LP p_lsp_CHAR_2DNOT_2DEQUAL_2F2();
extern SYMBOL s_lsp_CHAR_2F_3D; 
extern LP p_lsp_CHAR_2DNOT_2DEQUAL();
extern SYMBOL s_lsp_CHAR_2DNOT_2DEQUAL_2F2; 
extern LP p_lsp_CHAR_2DNOT_2DGREATERP_2F2();
extern LP p_lsp_CHAR_2DNOT_2DGREATERP();
extern SYMBOL s_lsp_CHAR_2DNOT_2DGREATERP_2F2; 
extern LP p_lsp_CHAR_2DNOT_2DLESSP_2F2();
extern LP p_lsp_CHAR_2DNOT_2DLESSP();
extern SYMBOL s_lsp_CHAR_2DNOT_2DLESSP_2F2; 
extern LP p_lsp_CHAR_2F_3D_2F2();
extern SYMBOL s_lsp_NOT; 
extern LP p_lsp_CHAR_2DUPCASE();
extern LP p_lsp_CODE_2DCHAR();
extern SYMBOL s_lsp_FIXNUMP; 
extern SYMBOL s_lsp_FIXNUM; 
extern LP p_lsp_DIGIT_2DCHAR_2DP_2F2();
MAKE_SIMPLE_STRING(k1767,26,"radix ~D is larger than 36");
extern SYMBOL s_lsp_ERROR; 
extern LP p_lsp_DIGIT_2DCHAR_2DP();
extern LP p_lsp_LOWER_2DCASE_2DP();
extern SYMBOL s_lsp__3C; 
extern LP p_lsp_BOTH_2DCASE_2DP();
extern LP p_lsp_GRAPHIC_2DCHAR_2DP();
extern LP p_lsp_NAME_2DCHAR();
extern SYMBOL s_lsp_STRING; 
extern SYMBOL s_lsp_STRING_2DEQUAL; 
extern SYMBOL s_lsp_IDENTITY; 
extern SYMBOL s_lsp_ASSOC_2F4; 
extern SYMBOL s_lsp_CDR; 
extern LP p_lsp_SET_2DCHAR_2DBIT();
extern SYMBOL s_lsp_SYMBOLP; 
extern SYMBOL s_lsp_SYMBOL; 
extern LP p_lsp_STANDARD_2DCHAR_2DP();
extern LP p_lsp_UPPER_2DCASE_2DP();


extern LP greaterp();
extern LP lessp();
extern LP add();
extern LP subtract();


LP p_lsp_ALPHA_2DCHAR_2DP(argc, v_CHAR_0)
      ARGC argc;  LP v_CHAR_0;
{
LP v_G2152_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_CHAR_3E_3D_2F2) (2, v_CHAR_0, LREF(char_tab[65]));
if (t0 != NIL) {
v_G2152_2 = ICALL(s_lsp_CHAR_3C_3D_2F2) (2, v_CHAR_0, LREF(char_tab[90]));
} else {
v_G2152_2 = LREF(s_lsp_NIL);
}
if (v_G2152_2 != NIL) {
return(v_G2152_2);
} else {
t2 = ICALL(s_lsp_CHAR_3E_3D_2F2) (2, v_CHAR_0, LREF(char_tab[97]));
if (t2 != NIL) {
t1 = ICALL(s_lsp_CHAR_3C_3D_2F2) (MV_CALL(argc,2), v_CHAR_0, LREF(char_tab[122]));
return(t1);
} else {
return(LREF(s_lsp_NIL));
}
}
}

LP p_lsp_ALPHANUMERICP(argc, v_CHAR_0)
      ARGC argc;  LP v_CHAR_0;
{
LP v_G2153_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
v_G2153_2 = ICALL(s_lsp_ALPHA_2DCHAR_2DP) (1, v_CHAR_0);
if (v_G2153_2 != NIL) {
return(v_G2153_2);
} else {
t0 = ICALL(s_lsp_DIGIT_2DCHAR_2DP_2F2) (MV_CALL(argc,2), v_CHAR_0, (LP) 20);
return(t0);
}
}

LP p_lsp_CHAR_2DBITS(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_CHARACTERP) (1, v_C_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_C_0, LREF(s_lsp_CHARACTER), (LP) 0);
}
return((LP) 0);
}

LP p_lsp_CHAR_2DCODE(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_CHARACTERP) (1, v_C_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_C_0, LREF(s_lsp_CHARACTER), (LP) 0);
}
t1 = INT_TO_FX(((int) RAW_CHAR(v_C_0)));
return(t1);
}

LP p_lsp_CHAR_2DDOWNCASE(argc, v_CHAR_0)
      ARGC argc;  LP v_CHAR_0;
{
LP v_C_6; LP v_C_4; LP v_C_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; 
if (argc != 1) wna(argc,1);
t2 = ICALL(s_lsp_CHAR_3E_3D_2F2) (2, v_CHAR_0, LREF(char_tab[65]));
if (t2 != NIL) {
t1 = ICALL(s_lsp_CHAR_3C_3D_2F2) (2, v_CHAR_0, LREF(char_tab[90]));
} else {
t1 = LREF(s_lsp_NIL);
}
if (t1 != NIL) {
v_C_2 = LREF(char_tab[97]);
t4 = INT_TO_FX(((int) RAW_CHAR(LREF(char_tab[97]))));
v_C_4 = v_CHAR_0;
t6 = INT_TO_FX(((int) RAW_CHAR(v_CHAR_0)));
v_C_6 = LREF(char_tab[65]);
t7 = INT_TO_FX(((int) RAW_CHAR(LREF(char_tab[65]))));
t5 = (subtract((t6), (t7)));
t3 = (add((t4), (t5)));
t0 = ICALL(s_lsp_CODE_2DCHAR) (MV_CALL(argc,1), t3);
return(t0);
} else {
return(v_CHAR_0);
}
}

LP p_lsp_CHAR_3D_2F2(argc, v_CHAR1_0, v_CHAR2_1)
      ARGC argc;  LP v_CHAR1_0; LP v_CHAR2_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_CHARACTERP) (1, v_CHAR1_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_CHAR1_0, LREF(s_lsp_CHARACTER), (LP) 0);
}
t1 = ICALL(s_lsp_CHARACTERP) (1, v_CHAR2_1);
if (t1 == NIL) {
ICALL(s_lsp_WTA) (3, v_CHAR2_1, LREF(s_lsp_CHARACTER), (LP) 0);
}
t2 = (((v_CHAR1_0) == (v_CHAR2_1)) ? T : NIL);
return(t2);
}

LP p_lsp_CHAR_3D(va_alist) va_dcl
{
LP v_CHAR2_18; LP v_CHAR1_17; LP v_LOOP_2DITER_2DFLAG_2D710_13; 
LP v_RESULT_12; LP v_CHAR2_10; LP v_CHAR1_9; 
LP v_LOOP_2DBIND_2D709_8; LP v_I_7; LP v_CHAR2_5; 
LP v_CHAR1_4; LP v_KEY2154_3; LP v_N_2; 
LP v_ARGS_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; 
RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTVIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_2 = ICALL(s_lsp_LENGTH) (1, v_ARGS_0);
v_KEY2154_3 = v_N_2;
t1 = ICALL(s_lsp_MEMQL) (2, v_KEY2154_3, LREF(k1764));
if (t1 != NIL) {
return(LREF(s_lsp_T));
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY2154_3, (LP) 4);
if (t2 != NIL) {
v_CHAR1_4 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
v_CHAR2_5 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
t0 = (((v_CHAR1_4) == (v_CHAR2_5)) ? T : NIL);
return(t0);
} else {
v_I_7 = (LP) 2;
v_CHAR1_9 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
v_CHAR2_10 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
v_RESULT_12 = (((v_CHAR1_9) == (v_CHAR2_10)) ? T : NIL);
v_LOOP_2DITER_2DFLAG_2D710_13 = LREF(s_lsp_T);
t_NEXT_2DLOOP_15:;
if (((int) (v_I_7) >= (int) (v_N_2))) {
goto t_END_2DLOOP_16;
}
if (v_LOOP_2DITER_2DFLAG_2D710_13 == NIL) {
t4 = (subtract((v_I_7), ((LP) 2)));
v_CHAR1_17 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(t4) * 4));
v_CHAR2_18 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(v_I_7) * 4));
v_RESULT_12 = (((v_CHAR1_17) == (v_CHAR2_18)) ? T : NIL);
}
if (v_RESULT_12 == NIL) {
return(v_RESULT_12);
return(NIL);
}
v_LOOP_2DITER_2DFLAG_2D710_13 = LREF(s_lsp_NIL);
v_I_7 = (((LP) ((int) (v_I_7) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_15;
goto t_END_2DLOOP_16;
t_END_2DLOOP_16:;
return(v_RESULT_12);
return(NIL);
return(NIL);
}
}
}

LP p_lsp_CHAR_2DEQUAL_2F2(argc, v_CHAR1_0, v_CHAR2_1)
      ARGC argc;  LP v_CHAR1_0; LP v_CHAR2_1;
{
LP v_CHAR2_4; LP v_CHAR1_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 2) wna(argc,2);
v_CHAR1_3 = ICALL(s_lsp_CHAR_2DDOWNCASE) (1, v_CHAR1_0);
v_CHAR2_4 = ICALL(s_lsp_CHAR_2DDOWNCASE) (1, v_CHAR2_1);
t0 = (((v_CHAR1_3) == (v_CHAR2_4)) ? T : NIL);
return(t0);
}

LP p_lsp_CHAR_2DEQUAL(va_alist) va_dcl
{
LP v_LOOP_2DITER_2DFLAG_2D712_7; LP v_RESULT_6; LP v_LOOP_2DBIND_2D711_5; 
LP v_I_4; LP v_KEY2155_3; LP v_N_2; 
LP v_ARGS_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; 
RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTVIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_2 = ICALL(s_lsp_LENGTH) (1, v_ARGS_0);
v_KEY2155_3 = v_N_2;
t1 = ICALL(s_lsp_MEMQL) (2, v_KEY2155_3, LREF(k1764));
if (t1 != NIL) {
return(LREF(s_lsp_T));
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY2155_3, (LP) 4);
if (t2 != NIL) {
t3 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t4 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
t0 = ICALL(s_lsp_CHAR_2DEQUAL_2F2) (MV_CALL(argc,2), t3, t4);
return(t0);
} else {
v_I_4 = (LP) 2;
t5 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t6 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
v_RESULT_6 = ICALL(s_lsp_CHAR_2DEQUAL_2F2) (2, t5, t6);
v_LOOP_2DITER_2DFLAG_2D712_7 = LREF(s_lsp_T);
t_NEXT_2DLOOP_9:;
if (((int) (v_I_4) >= (int) (v_N_2))) {
goto t_END_2DLOOP_10;
}
if (v_LOOP_2DITER_2DFLAG_2D712_7 == NIL) {
t9 = (subtract((v_I_4), ((LP) 2)));
t8 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(t9) * 4));
t10 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(v_I_4) * 4));
v_RESULT_6 = ICALL(s_lsp_CHAR_2DEQUAL_2F2) (2, t8, t10);
}
if (v_RESULT_6 == NIL) {
return(v_RESULT_6);
return(NIL);
}
v_LOOP_2DITER_2DFLAG_2D712_7 = LREF(s_lsp_NIL);
v_I_4 = (((LP) ((int) (v_I_4) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_9;
goto t_END_2DLOOP_10;
t_END_2DLOOP_10:;
return(v_RESULT_6);
return(NIL);
return(NIL);
}
}
}

LP p_lsp_CHAR_3E_3D_2F2(argc, v_CHAR1_0, v_CHAR2_1)
      ARGC argc;  LP v_CHAR1_0; LP v_CHAR2_1;
{
LP v_C_5; LP v_C_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_CHARACTERP) (1, v_CHAR1_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_CHAR1_0, LREF(s_lsp_CHARACTER), (LP) 0);
}
t1 = ICALL(s_lsp_CHARACTERP) (1, v_CHAR2_1);
if (t1 == NIL) {
ICALL(s_lsp_WTA) (3, v_CHAR2_1, LREF(s_lsp_CHARACTER), (LP) 0);
}
v_C_3 = v_CHAR1_0;
t3 = INT_TO_FX(((int) RAW_CHAR(v_CHAR1_0)));
v_C_5 = v_CHAR2_1;
t4 = INT_TO_FX(((int) RAW_CHAR(v_CHAR2_1)));
t2 = (((int) (t3) >= (int) (t4)) ? T : NIL);
return(t2);
}

LP p_lsp_CHAR_3E_3D(va_alist) va_dcl
{
LP v_C_30; LP v_C_28; LP v_CHAR2_26; 
LP v_CHAR1_25; LP v_LOOP_2DITER_2DFLAG_2D714_21; LP v_RESULT_20; 
LP v_C_18; LP v_C_16; LP v_CHAR2_14; 
LP v_CHAR1_13; LP v_LOOP_2DBIND_2D713_12; LP v_I_11; 
LP v_C_9; LP v_C_7; LP v_CHAR2_5; 
LP v_CHAR1_4; LP v_KEY2156_3; LP v_N_2; 
LP v_ARGS_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; 
RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTVIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_2 = ICALL(s_lsp_LENGTH) (1, v_ARGS_0);
v_KEY2156_3 = v_N_2;
t1 = ICALL(s_lsp_MEMQL) (2, v_KEY2156_3, LREF(k1764));
if (t1 != NIL) {
return(LREF(s_lsp_T));
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY2156_3, (LP) 4);
if (t2 != NIL) {
v_CHAR1_4 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
v_CHAR2_5 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
v_C_7 = v_CHAR1_4;
t3 = INT_TO_FX(((int) RAW_CHAR(v_CHAR1_4)));
v_C_9 = v_CHAR2_5;
t4 = INT_TO_FX(((int) RAW_CHAR(v_CHAR2_5)));
t0 = (((int) (t3) >= (int) (t4)) ? T : NIL);
return(t0);
} else {
v_I_11 = (LP) 2;
v_CHAR1_13 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
v_CHAR2_14 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
v_C_16 = v_CHAR1_13;
t5 = INT_TO_FX(((int) RAW_CHAR(v_CHAR1_13)));
v_C_18 = v_CHAR2_14;
t6 = INT_TO_FX(((int) RAW_CHAR(v_CHAR2_14)));
v_RESULT_20 = (((int) (t5) >= (int) (t6)) ? T : NIL);
v_LOOP_2DITER_2DFLAG_2D714_21 = LREF(s_lsp_T);
t_NEXT_2DLOOP_23:;
if (((int) (v_I_11) >= (int) (v_N_2))) {
goto t_END_2DLOOP_24;
}
if (v_LOOP_2DITER_2DFLAG_2D714_21 == NIL) {
t8 = (subtract((v_I_11), ((LP) 2)));
v_CHAR1_25 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(t8) * 4));
v_CHAR2_26 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(v_I_11) * 4));
v_C_28 = v_CHAR1_25;
t9 = INT_TO_FX(((int) RAW_CHAR(v_CHAR1_25)));
v_C_30 = v_CHAR2_26;
t10 = INT_TO_FX(((int) RAW_CHAR(v_CHAR2_26)));
v_RESULT_20 = (((int) (t9) >= (int) (t10)) ? T : NIL);
}
if (v_RESULT_20 == NIL) {
return(v_RESULT_20);
return(NIL);
}
v_LOOP_2DITER_2DFLAG_2D714_21 = LREF(s_lsp_NIL);
v_I_11 = (((LP) ((int) (v_I_11) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_23;
goto t_END_2DLOOP_24;
t_END_2DLOOP_24:;
return(v_RESULT_20);
return(NIL);
return(NIL);
}
}
}

LP p_lsp_CHAR_2DGREATERP_2F2(argc, v_CHAR1_0, v_CHAR2_1)
      ARGC argc;  LP v_CHAR1_0; LP v_CHAR2_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 2) wna(argc,2);
t1 = ICALL(s_lsp_CHAR_2DDOWNCASE) (1, v_CHAR1_0);
t2 = ICALL(s_lsp_CHAR_2DDOWNCASE) (1, v_CHAR2_1);
t0 = ICALL(s_lsp_CHAR_3E_2F2) (MV_CALL(argc,2), t1, t2);
return(t0);
}

LP p_lsp_CHAR_2DGREATERP(va_alist) va_dcl
{
LP v_LOOP_2DITER_2DFLAG_2D716_7; LP v_RESULT_6; LP v_LOOP_2DBIND_2D715_5; 
LP v_I_4; LP v_KEY2157_3; LP v_N_2; 
LP v_ARGS_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; 
RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTVIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_2 = ICALL(s_lsp_LENGTH) (1, v_ARGS_0);
v_KEY2157_3 = v_N_2;
t1 = ICALL(s_lsp_MEMQL) (2, v_KEY2157_3, LREF(k1764));
if (t1 != NIL) {
return(LREF(s_lsp_T));
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY2157_3, (LP) 4);
if (t2 != NIL) {
t3 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t4 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
t0 = ICALL(s_lsp_CHAR_2DGREATERP_2F2) (MV_CALL(argc,2), t3, t4);
return(t0);
} else {
v_I_4 = (LP) 2;
t5 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t6 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
v_RESULT_6 = ICALL(s_lsp_CHAR_2DGREATERP_2F2) (2, t5, t6);
v_LOOP_2DITER_2DFLAG_2D716_7 = LREF(s_lsp_T);
t_NEXT_2DLOOP_9:;
if (((int) (v_I_4) >= (int) (v_N_2))) {
goto t_END_2DLOOP_10;
}
if (v_LOOP_2DITER_2DFLAG_2D716_7 == NIL) {
t9 = (subtract((v_I_4), ((LP) 2)));
t8 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(t9) * 4));
t10 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(v_I_4) * 4));
v_RESULT_6 = ICALL(s_lsp_CHAR_2DGREATERP_2F2) (2, t8, t10);
}
if (v_RESULT_6 == NIL) {
return(v_RESULT_6);
return(NIL);
}
v_LOOP_2DITER_2DFLAG_2D716_7 = LREF(s_lsp_NIL);
v_I_4 = (((LP) ((int) (v_I_4) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_9;
goto t_END_2DLOOP_10;
t_END_2DLOOP_10:;
return(v_RESULT_6);
return(NIL);
return(NIL);
}
}
}

LP p_lsp_CHAR_3E_2F2(argc, v_CHAR1_0, v_CHAR2_1)
      ARGC argc;  LP v_CHAR1_0; LP v_CHAR2_1;
{
LP v_C_5; LP v_C_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; 
if (argc != 2) wna(argc,2);
v_C_3 = v_CHAR1_0;
t1 = INT_TO_FX(((int) RAW_CHAR(v_CHAR1_0)));
v_C_5 = v_CHAR2_1;
t2 = INT_TO_FX(((int) RAW_CHAR(v_CHAR2_1)));
t0 = (((int) (t1) > (int) (t2)) ? T : NIL);
return(t0);
}

LP p_lsp_CHAR_3E(va_alist) va_dcl
{
LP v_LOOP_2DITER_2DFLAG_2D718_7; LP v_RESULT_6; LP v_LOOP_2DBIND_2D717_5; 
LP v_I_4; LP v_KEY2158_3; LP v_N_2; 
LP v_ARGS_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; 
RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTVIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_2 = ICALL(s_lsp_LENGTH) (1, v_ARGS_0);
v_KEY2158_3 = v_N_2;
t1 = ICALL(s_lsp_MEMQL) (2, v_KEY2158_3, LREF(k1764));
if (t1 != NIL) {
return(LREF(s_lsp_T));
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY2158_3, (LP) 4);
if (t2 != NIL) {
t3 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t4 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
t0 = ICALL(s_lsp_CHAR_3E_2F2) (MV_CALL(argc,2), t3, t4);
return(t0);
} else {
v_I_4 = (LP) 2;
t5 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t6 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
v_RESULT_6 = ICALL(s_lsp_CHAR_3E_2F2) (2, t5, t6);
v_LOOP_2DITER_2DFLAG_2D718_7 = LREF(s_lsp_T);
t_NEXT_2DLOOP_9:;
if (((int) (v_I_4) >= (int) (v_N_2))) {
goto t_END_2DLOOP_10;
}
if (v_LOOP_2DITER_2DFLAG_2D718_7 == NIL) {
t9 = (subtract((v_I_4), ((LP) 2)));
t8 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(t9) * 4));
t10 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(v_I_4) * 4));
v_RESULT_6 = ICALL(s_lsp_CHAR_3E_2F2) (2, t8, t10);
}
if (v_RESULT_6 == NIL) {
return(v_RESULT_6);
return(NIL);
}
v_LOOP_2DITER_2DFLAG_2D718_7 = LREF(s_lsp_NIL);
v_I_4 = (((LP) ((int) (v_I_4) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_9;
goto t_END_2DLOOP_10;
t_END_2DLOOP_10:;
return(v_RESULT_6);
return(NIL);
return(NIL);
}
}
}

LP p_lsp_CHAR_3C(va_alist) va_dcl
{
LP v_LOOP_2DITER_2DFLAG_2D720_7; LP v_RESULT_6; LP v_LOOP_2DBIND_2D719_5; 
LP v_I_4; LP v_KEY2159_3; LP v_N_2; 
LP v_ARGS_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; 
RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTVIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_2 = ICALL(s_lsp_LENGTH) (1, v_ARGS_0);
v_KEY2159_3 = v_N_2;
t1 = ICALL(s_lsp_MEMQL) (2, v_KEY2159_3, LREF(k1764));
if (t1 != NIL) {
return(LREF(s_lsp_T));
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY2159_3, (LP) 4);
if (t2 != NIL) {
t3 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t4 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
t0 = ICALL(s_lsp_CHAR_3C_2F2) (MV_CALL(argc,2), t3, t4);
return(t0);
} else {
v_I_4 = (LP) 2;
t5 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t6 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
v_RESULT_6 = ICALL(s_lsp_CHAR_3C_2F2) (2, t5, t6);
v_LOOP_2DITER_2DFLAG_2D720_7 = LREF(s_lsp_T);
t_NEXT_2DLOOP_9:;
if (((int) (v_I_4) >= (int) (v_N_2))) {
goto t_END_2DLOOP_10;
}
if (v_LOOP_2DITER_2DFLAG_2D720_7 == NIL) {
t9 = (subtract((v_I_4), ((LP) 2)));
t8 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(t9) * 4));
t10 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(v_I_4) * 4));
v_RESULT_6 = ICALL(s_lsp_CHAR_3C_2F2) (2, t8, t10);
}
if (v_RESULT_6 == NIL) {
return(v_RESULT_6);
return(NIL);
}
v_LOOP_2DITER_2DFLAG_2D720_7 = LREF(s_lsp_NIL);
v_I_4 = (((LP) ((int) (v_I_4) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_9;
goto t_END_2DLOOP_10;
t_END_2DLOOP_10:;
return(v_RESULT_6);
return(NIL);
return(NIL);
}
}
}

LP p_lsp_CHAR_3C_3D_2F2(argc, v_CHAR1_0, v_CHAR2_1)
      ARGC argc;  LP v_CHAR1_0; LP v_CHAR2_1;
{
LP v_C_5; LP v_C_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; 
if (argc != 2) wna(argc,2);
v_C_3 = v_CHAR1_0;
t1 = INT_TO_FX(((int) RAW_CHAR(v_CHAR1_0)));
v_C_5 = v_CHAR2_1;
t2 = INT_TO_FX(((int) RAW_CHAR(v_CHAR2_1)));
t0 = (((int) (t1) <= (int) (t2)) ? T : NIL);
return(t0);
}

LP p_lsp_CHAR_3C_3D(va_alist) va_dcl
{
LP v_C_30; LP v_C_28; LP v_CHAR2_26; 
LP v_CHAR1_25; LP v_LOOP_2DITER_2DFLAG_2D722_21; LP v_RESULT_20; 
LP v_C_18; LP v_C_16; LP v_CHAR2_14; 
LP v_CHAR1_13; LP v_LOOP_2DBIND_2D721_12; LP v_I_11; 
LP v_C_9; LP v_C_7; LP v_CHAR2_5; 
LP v_CHAR1_4; LP v_KEY2160_3; LP v_N_2; 
LP v_ARGS_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; 
RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTVIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_2 = ICALL(s_lsp_LENGTH) (1, v_ARGS_0);
v_KEY2160_3 = v_N_2;
t1 = ICALL(s_lsp_MEMQL) (2, v_KEY2160_3, LREF(k1764));
if (t1 != NIL) {
return(LREF(s_lsp_T));
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY2160_3, (LP) 4);
if (t2 != NIL) {
v_CHAR1_4 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
v_CHAR2_5 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
v_C_7 = v_CHAR1_4;
t3 = INT_TO_FX(((int) RAW_CHAR(v_CHAR1_4)));
v_C_9 = v_CHAR2_5;
t4 = INT_TO_FX(((int) RAW_CHAR(v_CHAR2_5)));
t0 = (((int) (t3) <= (int) (t4)) ? T : NIL);
return(t0);
} else {
v_I_11 = (LP) 2;
v_CHAR1_13 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
v_CHAR2_14 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
v_C_16 = v_CHAR1_13;
t5 = INT_TO_FX(((int) RAW_CHAR(v_CHAR1_13)));
v_C_18 = v_CHAR2_14;
t6 = INT_TO_FX(((int) RAW_CHAR(v_CHAR2_14)));
v_RESULT_20 = (((int) (t5) <= (int) (t6)) ? T : NIL);
v_LOOP_2DITER_2DFLAG_2D722_21 = LREF(s_lsp_T);
t_NEXT_2DLOOP_23:;
if (((int) (v_I_11) >= (int) (v_N_2))) {
goto t_END_2DLOOP_24;
}
if (v_LOOP_2DITER_2DFLAG_2D722_21 == NIL) {
t8 = (subtract((v_I_11), ((LP) 2)));
v_CHAR1_25 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(t8) * 4));
v_CHAR2_26 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(v_I_11) * 4));
v_C_28 = v_CHAR1_25;
t9 = INT_TO_FX(((int) RAW_CHAR(v_CHAR1_25)));
v_C_30 = v_CHAR2_26;
t10 = INT_TO_FX(((int) RAW_CHAR(v_CHAR2_26)));
v_RESULT_20 = (((int) (t9) <= (int) (t10)) ? T : NIL);
}
if (v_RESULT_20 == NIL) {
return(v_RESULT_20);
return(NIL);
}
v_LOOP_2DITER_2DFLAG_2D722_21 = LREF(s_lsp_NIL);
v_I_11 = (((LP) ((int) (v_I_11) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_23;
goto t_END_2DLOOP_24;
t_END_2DLOOP_24:;
return(v_RESULT_20);
return(NIL);
return(NIL);
}
}
}

LP p_lsp_CHAR_2DLESSP_2F2(argc, v_CHAR1_0, v_CHAR2_1)
      ARGC argc;  LP v_CHAR1_0; LP v_CHAR2_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 2) wna(argc,2);
t1 = ICALL(s_lsp_CHAR_2DDOWNCASE) (1, v_CHAR1_0);
t2 = ICALL(s_lsp_CHAR_2DDOWNCASE) (1, v_CHAR2_1);
t0 = ICALL(s_lsp_CHAR_3C_2F2) (MV_CALL(argc,2), t1, t2);
return(t0);
}

LP p_lsp_CHAR_2DLESSP(va_alist) va_dcl
{
LP v_LOOP_2DITER_2DFLAG_2D724_7; LP v_RESULT_6; LP v_LOOP_2DBIND_2D723_5; 
LP v_I_4; LP v_KEY2161_3; LP v_N_2; 
LP v_ARGS_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; 
RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTVIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_2 = ICALL(s_lsp_LENGTH) (1, v_ARGS_0);
v_KEY2161_3 = v_N_2;
t1 = ICALL(s_lsp_MEMQL) (2, v_KEY2161_3, LREF(k1764));
if (t1 != NIL) {
return(LREF(s_lsp_T));
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY2161_3, (LP) 4);
if (t2 != NIL) {
t3 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t4 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
t0 = ICALL(s_lsp_CHAR_2DLESSP_2F2) (MV_CALL(argc,2), t3, t4);
return(t0);
} else {
v_I_4 = (LP) 2;
t5 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t6 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
v_RESULT_6 = ICALL(s_lsp_CHAR_2DLESSP_2F2) (2, t5, t6);
v_LOOP_2DITER_2DFLAG_2D724_7 = LREF(s_lsp_T);
t_NEXT_2DLOOP_9:;
if (((int) (v_I_4) >= (int) (v_N_2))) {
goto t_END_2DLOOP_10;
}
if (v_LOOP_2DITER_2DFLAG_2D724_7 == NIL) {
t9 = (subtract((v_I_4), ((LP) 2)));
t8 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(t9) * 4));
t10 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(v_I_4) * 4));
v_RESULT_6 = ICALL(s_lsp_CHAR_2DLESSP_2F2) (2, t8, t10);
}
if (v_RESULT_6 == NIL) {
return(v_RESULT_6);
return(NIL);
}
v_LOOP_2DITER_2DFLAG_2D724_7 = LREF(s_lsp_NIL);
v_I_4 = (((LP) ((int) (v_I_4) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_9;
goto t_END_2DLOOP_10;
t_END_2DLOOP_10:;
return(v_RESULT_6);
return(NIL);
return(NIL);
}
}
}

LP p_lsp_CHAR_3C_2F2(argc, v_CHAR1_0, v_CHAR2_1)
      ARGC argc;  LP v_CHAR1_0; LP v_CHAR2_1;
{
LP v_C_5; LP v_C_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; 
if (argc != 2) wna(argc,2);
v_C_3 = v_CHAR1_0;
t1 = INT_TO_FX(((int) RAW_CHAR(v_CHAR1_0)));
v_C_5 = v_CHAR2_1;
t2 = INT_TO_FX(((int) RAW_CHAR(v_CHAR2_1)));
t0 = (lessp((t1), (t2)));
return(t0);
}

LP p_lsp_CHAR_2DNAME(argc, v_CHAR_0)
      ARGC argc;  LP v_CHAR_0;
{
LP v_CODE_4; LP v_C_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 

if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_CHARACTERP) (1, v_CHAR_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_CHAR_0, LREF(s_lsp_CHARACTER), (LP) 0);
}
v_C_2 = v_CHAR_0;
v_CODE_4 = INT_TO_FX(((int) RAW_CHAR(v_CHAR_0)));
t2 = (greaterp((v_CODE_4), ((LP) 254)));
if (t2 != NIL) {
t1 = ICALL(s_lsp_FORMAT) (MV_CALL(argc,3), LREF(s_lsp_NIL), LREF(k1766), v_CODE_4);
return(t1);
} else {
t4 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ACHARACTER_2DNAMES_2A));
t5 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_CHAR_3D));
t3 = ICALL(s_lsp_RASSOC) (4, v_CHAR_0, t4, LREF(s_key_TEST), t5);
t1 = ICALL(s_lsp_CAR) (MV_CALL(argc,1), t3);
return(t1);
}
}

LP p_lsp_CHAR_2F_3D(va_alist) va_dcl
{
LP v_LOOP_2DITER_2DFLAG_2D726_7; LP v_RESULT_6; LP v_LOOP_2DBIND_2D725_5; 
LP v_I_4; LP v_KEY2162_3; LP v_N_2; 
LP v_ARGS_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; 
RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTVIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_2 = ICALL(s_lsp_LENGTH) (1, v_ARGS_0);
v_KEY2162_3 = v_N_2;
t1 = ICALL(s_lsp_MEMQL) (2, v_KEY2162_3, LREF(k1764));
if (t1 != NIL) {
return(LREF(s_lsp_T));
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY2162_3, (LP) 4);
if (t2 != NIL) {
t3 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t4 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
t0 = ICALL(s_lsp_CHAR_2F_3D_2F2) (MV_CALL(argc,2), t3, t4);
return(t0);
} else {
v_I_4 = (LP) 2;
t5 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t6 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
v_RESULT_6 = ICALL(s_lsp_CHAR_2F_3D_2F2) (2, t5, t6);
v_LOOP_2DITER_2DFLAG_2D726_7 = LREF(s_lsp_T);
t_NEXT_2DLOOP_9:;
if (((int) (v_I_4) >= (int) (v_N_2))) {
goto t_END_2DLOOP_10;
}
if (v_LOOP_2DITER_2DFLAG_2D726_7 == NIL) {
t9 = (subtract((v_I_4), ((LP) 2)));
t8 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(t9) * 4));
t10 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(v_I_4) * 4));
v_RESULT_6 = ICALL(s_lsp_CHAR_2F_3D_2F2) (2, t8, t10);
}
if (v_RESULT_6 == NIL) {
return(v_RESULT_6);
return(NIL);
}
v_LOOP_2DITER_2DFLAG_2D726_7 = LREF(s_lsp_NIL);
v_I_4 = (((LP) ((int) (v_I_4) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_9;
goto t_END_2DLOOP_10;
t_END_2DLOOP_10:;
return(v_RESULT_6);
return(NIL);
return(NIL);
}
}
}

LP p_lsp_CHAR_2DNOT_2DEQUAL_2F2(argc, v_CHAR1_0, v_CHAR2_1)
      ARGC argc;  LP v_CHAR1_0; LP v_CHAR2_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 2) wna(argc,2);
t1 = ICALL(s_lsp_CHAR_2DDOWNCASE) (1, v_CHAR1_0);
t2 = ICALL(s_lsp_CHAR_2DDOWNCASE) (1, v_CHAR2_1);
t0 = ICALL(s_lsp_CHAR_2F_3D) (MV_CALL(argc,2), t1, t2);
return(t0);
}

LP p_lsp_CHAR_2DNOT_2DEQUAL(va_alist) va_dcl
{
LP v_LOOP_2DITER_2DFLAG_2D728_7; LP v_RESULT_6; LP v_LOOP_2DBIND_2D727_5; 
LP v_I_4; LP v_KEY2163_3; LP v_N_2; 
LP v_ARGS_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; 
RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTVIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_2 = ICALL(s_lsp_LENGTH) (1, v_ARGS_0);
v_KEY2163_3 = v_N_2;
t1 = ICALL(s_lsp_MEMQL) (2, v_KEY2163_3, LREF(k1764));
if (t1 != NIL) {
return(LREF(s_lsp_T));
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY2163_3, (LP) 4);
if (t2 != NIL) {
t3 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t4 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
t0 = ICALL(s_lsp_CHAR_2DNOT_2DEQUAL_2F2) (MV_CALL(argc,2), t3, t4);
return(t0);
} else {
v_I_4 = (LP) 2;
t5 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t6 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
v_RESULT_6 = ICALL(s_lsp_CHAR_2DNOT_2DEQUAL_2F2) (2, t5, t6);
v_LOOP_2DITER_2DFLAG_2D728_7 = LREF(s_lsp_T);
t_NEXT_2DLOOP_9:;
if (((int) (v_I_4) >= (int) (v_N_2))) {
goto t_END_2DLOOP_10;
}
if (v_LOOP_2DITER_2DFLAG_2D728_7 == NIL) {
t9 = (subtract((v_I_4), ((LP) 2)));
t8 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(t9) * 4));
t10 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(v_I_4) * 4));
v_RESULT_6 = ICALL(s_lsp_CHAR_2DNOT_2DEQUAL_2F2) (2, t8, t10);
}
if (v_RESULT_6 == NIL) {
return(v_RESULT_6);
return(NIL);
}
v_LOOP_2DITER_2DFLAG_2D728_7 = LREF(s_lsp_NIL);
v_I_4 = (((LP) ((int) (v_I_4) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_9;
goto t_END_2DLOOP_10;
t_END_2DLOOP_10:;
return(v_RESULT_6);
return(NIL);
return(NIL);
}
}
}

LP p_lsp_CHAR_2DNOT_2DGREATERP_2F2(argc, v_CHAR1_0, v_CHAR2_1)
      ARGC argc;  LP v_CHAR1_0; LP v_CHAR2_1;
{
LP v_C_8; LP v_C_6; LP v_CHAR2_4; 
LP v_CHAR1_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 

if (argc != 2) wna(argc,2);
v_CHAR1_3 = ICALL(s_lsp_CHAR_2DDOWNCASE) (1, v_CHAR1_0);
v_CHAR2_4 = ICALL(s_lsp_CHAR_2DDOWNCASE) (1, v_CHAR2_1);
v_C_6 = v_CHAR1_3;
t1 = INT_TO_FX(((int) RAW_CHAR(v_CHAR1_3)));
v_C_8 = v_CHAR2_4;
t2 = INT_TO_FX(((int) RAW_CHAR(v_CHAR2_4)));
t0 = (((int) (t1) >= (int) (t2)) ? T : NIL);
return(t0);
}

LP p_lsp_CHAR_2DNOT_2DGREATERP(va_alist) va_dcl
{
LP v_LOOP_2DITER_2DFLAG_2D730_7; LP v_RESULT_6; LP v_LOOP_2DBIND_2D729_5; 
LP v_I_4; LP v_KEY2164_3; LP v_N_2; 
LP v_ARGS_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; 
RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTVIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_2 = ICALL(s_lsp_LENGTH) (1, v_ARGS_0);
v_KEY2164_3 = v_N_2;
t1 = ICALL(s_lsp_MEMQL) (2, v_KEY2164_3, LREF(k1764));
if (t1 != NIL) {
return(LREF(s_lsp_T));
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY2164_3, (LP) 4);
if (t2 != NIL) {
t3 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t4 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
t0 = ICALL(s_lsp_CHAR_2DNOT_2DGREATERP_2F2) (MV_CALL(argc,2), t3, t4);
return(t0);
} else {
v_I_4 = (LP) 2;
t5 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t6 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
v_RESULT_6 = ICALL(s_lsp_CHAR_2DNOT_2DGREATERP_2F2) (2, t5, t6);
v_LOOP_2DITER_2DFLAG_2D730_7 = LREF(s_lsp_T);
t_NEXT_2DLOOP_9:;
if (((int) (v_I_4) >= (int) (v_N_2))) {
goto t_END_2DLOOP_10;
}
if (v_LOOP_2DITER_2DFLAG_2D730_7 == NIL) {
t9 = (subtract((v_I_4), ((LP) 2)));
t8 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(t9) * 4));
t10 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(v_I_4) * 4));
v_RESULT_6 = ICALL(s_lsp_CHAR_2DNOT_2DGREATERP_2F2) (2, t8, t10);
}
if (v_RESULT_6 == NIL) {
return(v_RESULT_6);
return(NIL);
}
v_LOOP_2DITER_2DFLAG_2D730_7 = LREF(s_lsp_NIL);
v_I_4 = (((LP) ((int) (v_I_4) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_9;
goto t_END_2DLOOP_10;
t_END_2DLOOP_10:;
return(v_RESULT_6);
return(NIL);
return(NIL);
}
}
}

LP p_lsp_CHAR_2DNOT_2DLESSP_2F2(argc, v_CHAR1_0, v_CHAR2_1)
      ARGC argc;  LP v_CHAR1_0; LP v_CHAR2_1;
{
LP v_C_8; LP v_C_6; LP v_CHAR2_4; 
LP v_CHAR1_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 

if (argc != 2) wna(argc,2);
v_CHAR1_3 = ICALL(s_lsp_CHAR_2DDOWNCASE) (1, v_CHAR1_0);
v_CHAR2_4 = ICALL(s_lsp_CHAR_2DDOWNCASE) (1, v_CHAR2_1);
v_C_6 = v_CHAR1_3;
t1 = INT_TO_FX(((int) RAW_CHAR(v_CHAR1_3)));
v_C_8 = v_CHAR2_4;
t2 = INT_TO_FX(((int) RAW_CHAR(v_CHAR2_4)));
t0 = (((int) (t1) <= (int) (t2)) ? T : NIL);
return(t0);
}

LP p_lsp_CHAR_2DNOT_2DLESSP(va_alist) va_dcl
{
LP v_LOOP_2DITER_2DFLAG_2D732_7; LP v_RESULT_6; LP v_LOOP_2DBIND_2D731_5; 
LP v_I_4; LP v_KEY2165_3; LP v_N_2; 
LP v_ARGS_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; 
RESTV_HOLDER(restv_vector);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
RESTVIFY(v_ARGS_0,1,NEXT_VAR_ARG);
END_VAR_ARGS;
v_N_2 = ICALL(s_lsp_LENGTH) (1, v_ARGS_0);
v_KEY2165_3 = v_N_2;
t1 = ICALL(s_lsp_MEMQL) (2, v_KEY2165_3, LREF(k1764));
if (t1 != NIL) {
return(LREF(s_lsp_T));
} else {
t2 = ICALL(s_lsp_EQL) (2, v_KEY2165_3, (LP) 4);
if (t2 != NIL) {
t3 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t4 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
t0 = ICALL(s_lsp_CHAR_2DNOT_2DLESSP_2F2) (MV_CALL(argc,2), t3, t4);
return(t0);
} else {
v_I_4 = (LP) 2;
t5 = ((LP) DEREF((v_ARGS_0) + 0 * 4));
t6 = ((LP) DEREF((v_ARGS_0) + 1 * 4));
v_RESULT_6 = ICALL(s_lsp_CHAR_2DNOT_2DLESSP_2F2) (2, t5, t6);
v_LOOP_2DITER_2DFLAG_2D732_7 = LREF(s_lsp_T);
t_NEXT_2DLOOP_9:;
if (((int) (v_I_4) >= (int) (v_N_2))) {
goto t_END_2DLOOP_10;
}
if (v_LOOP_2DITER_2DFLAG_2D732_7 == NIL) {
t9 = (subtract((v_I_4), ((LP) 2)));
t8 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(t9) * 4));
t10 = ((LP) DEREF((v_ARGS_0) + FX_TO_INT(v_I_4) * 4));
v_RESULT_6 = ICALL(s_lsp_CHAR_2DNOT_2DLESSP_2F2) (2, t8, t10);
}
if (v_RESULT_6 == NIL) {
return(v_RESULT_6);
return(NIL);
}
v_LOOP_2DITER_2DFLAG_2D732_7 = LREF(s_lsp_NIL);
v_I_4 = (((LP) ((int) (v_I_4) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_9;
goto t_END_2DLOOP_10;
t_END_2DLOOP_10:;
return(v_RESULT_6);
return(NIL);
return(NIL);
}
}
}

LP p_lsp_CHAR_2F_3D_2F2(argc, v_CHAR1_0, v_CHAR2_1)
      ARGC argc;  LP v_CHAR1_0; LP v_CHAR2_1;
{
LP v_CHAR2_4; LP v_CHAR1_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
if (argc != 2) wna(argc,2);
v_CHAR1_3 = v_CHAR1_0;
v_CHAR2_4 = v_CHAR2_1;
t1 = (((v_CHAR1_0) == (v_CHAR2_1)) ? T : NIL);
t0 = ICALL(s_lsp_NOT) (MV_CALL(argc,1), t1);
return(t0);
}

LP p_lsp_CHAR_2DUPCASE(argc, v_CHAR_0)
      ARGC argc;  LP v_CHAR_0;
{
LP v_C_20; LP v_C_18; LP v_CHAR2_16; 
LP v_CHAR1_15; LP v_C_13; LP v_C_11; 
LP v_CHAR2_9; LP v_CHAR1_8; LP v_C_6; 
LP v_C_4; LP v_C_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 

if (argc != 1) wna(argc,1);
v_CHAR1_15 = v_CHAR_0;
v_CHAR2_16 = LREF(char_tab[97]);
v_C_18 = v_CHAR_0;
t3 = INT_TO_FX(((int) RAW_CHAR(v_CHAR_0)));
v_C_20 = LREF(char_tab[97]);
t4 = INT_TO_FX(((int) RAW_CHAR(LREF(char_tab[97]))));
if (((int) (t3) >= (int) (t4))) {
v_CHAR1_8 = v_CHAR_0;
v_CHAR2_9 = LREF(char_tab[122]);
v_C_11 = v_CHAR_0;
t5 = INT_TO_FX(((int) RAW_CHAR(v_CHAR_0)));
v_C_13 = LREF(char_tab[122]);
t6 = INT_TO_FX(((int) RAW_CHAR(LREF(char_tab[122]))));
t1 = (((int) (t5) <= (int) (t6)) ? T : NIL);
} else {
t1 = LREF(s_lsp_NIL);
}
if (t1 != NIL) {
v_C_2 = LREF(char_tab[65]);
t8 = INT_TO_FX(((int) RAW_CHAR(LREF(char_tab[65]))));
v_C_4 = v_CHAR_0;
t10 = INT_TO_FX(((int) RAW_CHAR(v_CHAR_0)));
v_C_6 = LREF(char_tab[97]);
t11 = INT_TO_FX(((int) RAW_CHAR(LREF(char_tab[97]))));
t9 = (((LP) ((int) (t10) - (int) (t11))));
t7 = (((LP) ((int) (t8) + (int) (t9))));
t0 = ICALL(s_lsp_CODE_2DCHAR) (MV_CALL(argc,1), t7);
return(t0);
} else {
return(v_CHAR_0);
}
}

LP p_lsp_CODE_2DCHAR(argc, v_N_0)
      ARGC argc;  LP v_N_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_FIXNUMP) (1, v_N_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_N_0, LREF(s_lsp_FIXNUM), (LP) 0);
}
if (((int) (v_N_0) >= (int) ((LP) 512))) {
return(LREF(s_lsp_NIL));
} else {
t1 = NEW_CHAR(((unsigned char) FX_TO_INT(v_N_0)));
return(t1);
}
}

LP p_lsp_DIGIT_2DCHAR_2DP_2F2(argc, v_CHAR_0, v_RADIX_1)
      ARGC argc;  LP v_CHAR_0; LP v_RADIX_1;
{
LP v_WEIGHT_7; LP v_C_5; LP v_C_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; 
if (argc != 2) wna(argc,2);
v_C_3 = v_CHAR_0;
t0 = INT_TO_FX(((int) RAW_CHAR(v_CHAR_0)));
v_C_5 = LREF(char_tab[48]);
t1 = INT_TO_FX(((int) RAW_CHAR(LREF(char_tab[48]))));
v_WEIGHT_7 = (((LP) ((int) (t0) - (int) (t1))));
if (((int) (v_RADIX_1) <= (int) ((LP) 20))) {
if (((int) (v_WEIGHT_7) >= (int) ((LP) 0))) {
t4 = (((int) (v_WEIGHT_7) < (int) (v_RADIX_1)) ? T : NIL);
} else {
t4 = LREF(s_lsp_NIL);
}
if (t4 != NIL) {
return(v_WEIGHT_7);
} else {
return(LREF(s_lsp_NIL));
}
} else {
if (((int) (v_RADIX_1) > (int) ((LP) 72))) {
t2 = ICALL(s_lsp_ERROR) (MV_CALL(argc,2), LREF(k1767), v_RADIX_1);
return(t2);
} else {
if (((int) (v_WEIGHT_7) >= (int) ((LP) 0))) {
t7 = (((int) (v_WEIGHT_7) < (int) ((LP) 20)) ? T : NIL);
} else {
t7 = LREF(s_lsp_NIL);
}
if (t7 != NIL) {
return(v_WEIGHT_7);
} else {
v_WEIGHT_7 = (((LP) ((int) (v_WEIGHT_7) - (int) ((LP) 14))));
if (((int) (v_WEIGHT_7) >= (int) ((LP) 20))) {
t9 = (((int) (v_WEIGHT_7) < (int) (v_RADIX_1)) ? T : NIL);
} else {
t9 = LREF(s_lsp_NIL);
}
if (t9 != NIL) {
return(v_WEIGHT_7);
} else {
v_WEIGHT_7 = (((LP) ((int) (v_WEIGHT_7) - (int) ((LP) 64))));
if (((int) (v_WEIGHT_7) >= (int) ((LP) 20))) {
t11 = (((int) (v_WEIGHT_7) < (int) (v_RADIX_1)) ? T : NIL);
} else {
t11 = LREF(s_lsp_NIL);
}
if (t11 != NIL) {
return(v_WEIGHT_7);
} else {
return(LREF(s_lsp_NIL));
}
}
}
}
}
}

LP p_lsp_DIGIT_2DCHAR_2DP(va_alist) va_dcl
{
LP v_CHAR_0; LP v_RADIX_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_CHAR_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_RADIX_1 = (LP) 20;
} else {
v_RADIX_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t0 = ICALL(s_lsp_DIGIT_2DCHAR_2DP_2F2) (MV_CALL(argc,2), v_CHAR_0, v_RADIX_1);
return(t0);
}

LP p_lsp_LOWER_2DCASE_2DP(argc, v_CHAR_0)
      ARGC argc;  LP v_CHAR_0;
{
LP v_C_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
if (argc != 1) wna(argc,1);
v_C_2 = v_CHAR_0;
t1 = INT_TO_FX(((int) RAW_CHAR(v_CHAR_0)));
t0 = ICALL(s_lsp__3C) (MV_CALL(argc,3), (LP) 192, t1, (LP) 246);
return(t0);
}

LP p_lsp_BOTH_2DCASE_2DP(argc, v_CHAR_0)
      ARGC argc;  LP v_CHAR_0;
{
LP v_G2166_5; LP v_M_4; LP v_C_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
if (argc != 1) wna(argc,1);
v_C_2 = v_CHAR_0;
v_M_4 = INT_TO_FX(((int) RAW_CHAR(v_CHAR_0)));
v_G2166_5 = ICALL(s_lsp__3C) (3, (LP) 128, v_M_4, (LP) 182);
if (v_G2166_5 != NIL) {
return(v_G2166_5);
} else {
t0 = ICALL(s_lsp__3C) (MV_CALL(argc,3), (LP) 192, v_M_4, (LP) 246);
return(t0);
}
}

LP p_lsp_GRAPHIC_2DCHAR_2DP(argc, v_CHAR_0)
      ARGC argc;  LP v_CHAR_0;
{
LP v_C_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
if (argc != 1) wna(argc,1);
v_C_2 = v_CHAR_0;
t1 = INT_TO_FX(((int) RAW_CHAR(v_CHAR_0)));
t0 = ICALL(s_lsp__3C) (MV_CALL(argc,3), (LP) 62, t1, (LP) 254);
return(t0);
}

LP p_lsp_NAME_2DCHAR(argc, v_NAME_0)
      ARGC argc;  LP v_NAME_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 1) wna(argc,1);
t2 = ICALL(s_lsp_STRING) (1, v_NAME_0);
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ACHARACTER_2DNAMES_2A));
t4 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_STRING_2DEQUAL));
t5 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_IDENTITY));
t1 = ICALL(s_lsp_ASSOC_2F4) (4, t2, t3, t4, t5);
t0 = ICALL(s_lsp_CDR) (MV_CALL(argc,1), t1);
return(t0);
}

LP p_lsp_SET_2DCHAR_2DBIT(argc, v_C_0, v_BIT_2DNAME_1, v_VALUE_2)
      ARGC argc;  LP v_C_0; LP v_BIT_2DNAME_1; LP v_VALUE_2;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 3) wna(argc,3);
t0 = ICALL(s_lsp_CHARACTERP) (1, v_C_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_C_0, LREF(s_lsp_CHARACTER), (LP) 0);
}
t1 = ICALL(s_lsp_SYMBOLP) (1, v_BIT_2DNAME_1);
if (t1 == NIL) {
ICALL(s_lsp_WTA) (3, v_BIT_2DNAME_1, LREF(s_lsp_SYMBOL), (LP) 0);
}
t2 = ICALL(s_lsp_FIXNUMP) (1, v_VALUE_2);
if (t2 == NIL) {
ICALL(s_lsp_WTA) (3, v_VALUE_2, LREF(s_lsp_FIXNUM), (LP) 0);
}
return(v_VALUE_2);
}

LP p_lsp_STANDARD_2DCHAR_2DP(argc, v_CHAR_0)
      ARGC argc;  LP v_CHAR_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_CHARACTERP) (MV_CALL(argc,1), v_CHAR_0);
return(t0);
}

LP p_lsp_UPPER_2DCASE_2DP(argc, v_CHAR_0)
      ARGC argc;  LP v_CHAR_0;
{
LP v_C_14; LP v_C_12; LP v_CHAR2_10; 
LP v_CHAR1_9; LP v_C_7; LP v_C_5; 
LP v_CHAR2_3; LP v_CHAR1_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; 
if (argc != 1) wna(argc,1);
v_CHAR1_9 = v_CHAR_0;
v_CHAR2_10 = LREF(char_tab[65]);
v_C_12 = v_CHAR_0;
t2 = INT_TO_FX(((int) RAW_CHAR(v_CHAR_0)));
v_C_14 = LREF(char_tab[65]);
t3 = INT_TO_FX(((int) RAW_CHAR(LREF(char_tab[65]))));
if (((int) (t2) >= (int) (t3))) {
v_CHAR1_2 = v_CHAR_0;
v_CHAR2_3 = LREF(char_tab[90]);
v_C_5 = v_CHAR_0;
t4 = INT_TO_FX(((int) RAW_CHAR(v_CHAR_0)));
v_C_7 = LREF(char_tab[90]);
t5 = INT_TO_FX(((int) RAW_CHAR(LREF(char_tab[90]))));
t0 = (((int) (t4) <= (int) (t5)) ? T : NIL);
return(t0);
} else {
return(LREF(s_lsp_NIL));
}
}

