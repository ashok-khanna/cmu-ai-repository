/*
:comment "Compiled at 4:48:54 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: Debug Library"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O2 -fPIC"
:version 0
:end-package-info 0
:sym SYMBOL-PACKAGE
:sym PACKAGE-ABBREV
:sf SYMBOL-PACKAGE-ABBREV "p_lsp_SYMBOL_2DPACKAGE_2DABBREV"
:sf PROC-PACKAGE-ABBREV "p_lsp_PROC_2DPACKAGE_2DABBREV"
:sf MACRO-PACKAGE-ABBREV "p_lsp_MACRO_2DPACKAGE_2DABBREV"
:sym ALPHA-CHAR-P
:sym DIGIT-CHAR-P/2
:sf LEGAL-C-VAR-CHAR? "p_lsp_LEGAL_2DC_2DVAR_2DCHAR_3F"
:sym FLOOR/1V
:sf DECIMAL-INTEGER-LENGTH "p_lsp_DECIMAL_2DINTEGER_2DLENGTH"
:sym LENGTH
:sym NIL
:sym LEGAL-C-VAR-CHAR?
:sym DECIMAL-INTEGER-LENGTH
:sym MAKE-SIMPLE-STRING
:sym T
:sym *CHAR-CONVERSIONS*
:sym REPLACE/6
:sym REM
:sf LISP->C-NAME "p_lsp_LISP_2D_3EC_2DNAME"
:sym LISP->C-NAME
:sf LISP->C-FIELD-NAME "p_lsp_LISP_2D_3EC_2DFIELD_2DNAME"
:sf LISP->C-FUNCTION-NAME "p_lsp_LISP_2D_3EC_2DFUNCTION_2DNAME"
:sf LISP->C-VARIABLE-NAME "p_lsp_LISP_2D_3EC_2DVARIABLE_2DNAME"
:sf LISP->C-BLOCK-NAME "p_lsp_LISP_2D_3EC_2DBLOCK_2DNAME"
:sf LISP->C-TAG-NAME "p_lsp_LISP_2D_3EC_2DTAG_2DNAME"
:sym SYMBOL-PACKAGE-ABBREV
:sf LISP->C-SYMBOL-NAME "p_lsp_LISP_2D_3EC_2DSYMBOL_2DNAME"
:sym MACRO-PACKAGE-ABBREV
:sym PROC-PACKAGE-ABBREV
:sf LISP->C-PROC-NAME "p_lsp_LISP_2D_3EC_2DPROC_2DNAME"
:pinfo LISP->C-TAG-NAME (NAME ID) NIL NIL NIL NIL NIL NIL T
:pinfo LISP->C-SYMBOL-NAME (SYM) NIL NIL NIL NIL NIL NIL T
:pinfo PROC-PACKAGE-ABBREV (SYM) NIL NIL NIL NIL NIL NIL T
:pinfo LEGAL-C-VAR-CHAR? (CHAR) NIL NIL NIL NIL NIL NIL T
:pinfo LISP->C-FUNCTION-NAME (NAME ID) NIL NIL NIL NIL NIL NIL T
:pinfo DECIMAL-INTEGER-LENGTH (N) NIL NIL NIL NIL NIL NIL T
:pinfo MACRO-PACKAGE-ABBREV (SYM) NIL NIL NIL NIL NIL NIL T
:pinfo LISP->C-PROC-NAME (NAME &OPTIONAL MACRO-FUNCTION?) NIL NIL NIL NIL NIL NIL T
:pinfo LISP->C-FIELD-NAME (NAME) NIL NIL NIL NIL NIL NIL T
:pinfo LISP->C-NAME (LEADER NAME TRAILER) NIL NIL NIL NIL NIL NIL T
:pinfo LISP->C-BLOCK-NAME (NAME ID) NIL NIL NIL NIL NIL NIL T
:pinfo LISP->C-VARIABLE-NAME (NAME ID) NIL NIL NIL NIL NIL NIL T
:pinfo SYMBOL-PACKAGE-ABBREV (SYM) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_lsp_SYMBOL_2DPACKAGE_2DABBREV();
extern SYMBOL s_lsp_SYMBOL_2DPACKAGE; 
extern SYMBOL s_lsp_PACKAGE_2DABBREV; 
extern LP p_lsp_PROC_2DPACKAGE_2DABBREV();
extern LP p_lsp_MACRO_2DPACKAGE_2DABBREV();
extern LP p_lsp_LEGAL_2DC_2DVAR_2DCHAR_3F();
extern SYMBOL s_lsp_ALPHA_2DCHAR_2DP; 
extern SYMBOL s_lsp_DIGIT_2DCHAR_2DP_2F2; 
extern LP p_lsp_DECIMAL_2DINTEGER_2DLENGTH();
extern SYMBOL s_lsp_FLOOR_2F1V; 
extern LP p_lsp_LISP_2D_3EC_2DNAME();
extern SYMBOL s_lsp_LENGTH; 
extern SYMBOL s_lsp_NIL; 
extern SYMBOL s_lsp_LEGAL_2DC_2DVAR_2DCHAR_3F; 
extern SYMBOL s_lsp_DECIMAL_2DINTEGER_2DLENGTH; 
extern SYMBOL s_lsp_MAKE_2DSIMPLE_2DSTRING; 
extern SYMBOL s_lsp_T; 
extern SYMBOL s_lsp__2ACHAR_2DCONVERSIONS_2A; 
extern SYMBOL s_lsp_REPLACE_2F6; 
extern SYMBOL s_lsp_REM; 
extern LP p_lsp_LISP_2D_3EC_2DFIELD_2DNAME();
MAKE_SIMPLE_STRING(k10890,0,"");
extern SYMBOL s_lsp_LISP_2D_3EC_2DNAME; 
extern LP p_lsp_LISP_2D_3EC_2DFUNCTION_2DNAME();
MAKE_SIMPLE_STRING(k10891,2,"f_");
extern LP p_lsp_LISP_2D_3EC_2DVARIABLE_2DNAME();
MAKE_SIMPLE_STRING(k10892,2,"v_");
extern LP p_lsp_LISP_2D_3EC_2DBLOCK_2DNAME();
MAKE_SIMPLE_STRING(k10893,2,"b_");
extern LP p_lsp_LISP_2D_3EC_2DTAG_2DNAME();
MAKE_SIMPLE_STRING(k10894,2,"t_");
extern LP p_lsp_LISP_2D_3EC_2DSYMBOL_2DNAME();
extern SYMBOL s_lsp_SYMBOL_2DPACKAGE_2DABBREV; 
extern LP p_lsp_LISP_2D_3EC_2DPROC_2DNAME();
extern SYMBOL s_lsp_MACRO_2DPACKAGE_2DABBREV; 
extern SYMBOL s_lsp_PROC_2DPACKAGE_2DABBREV; 


extern LP multiply();
extern LP subtract();
extern LP add();
extern LP vref();
extern LP lessp();


LP p_lsp_SYMBOL_2DPACKAGE_2DABBREV(argc, v_SYM_0)
      ARGC argc;  LP v_SYM_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_SYMBOL_2DPACKAGE) (1, v_SYM_0);
t0 = ICALL(s_lsp_PACKAGE_2DABBREV) (MV_CALL(argc,2), t1, (LP) 0);
return(t0);
}

LP p_lsp_PROC_2DPACKAGE_2DABBREV(argc, v_SYM_0)
      ARGC argc;  LP v_SYM_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_SYMBOL_2DPACKAGE) (1, v_SYM_0);
t0 = ICALL(s_lsp_PACKAGE_2DABBREV) (MV_CALL(argc,2), t1, (LP) 2);
return(t0);
}

LP p_lsp_MACRO_2DPACKAGE_2DABBREV(argc, v_SYM_0)
      ARGC argc;  LP v_SYM_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_SYMBOL_2DPACKAGE) (1, v_SYM_0);
t0 = ICALL(s_lsp_PACKAGE_2DABBREV) (MV_CALL(argc,2), t1, (LP) 4);
return(t0);
}

LP p_lsp_LEGAL_2DC_2DVAR_2DCHAR_3F(argc, v_CHAR_0)
      ARGC argc;  LP v_CHAR_0;
{
LP v_RADIX_6; LP v_CHAR_5; LP v_CHAR_3; 
LP v_RADIX_4; LP v_G6672_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
if (argc != 1) wna(argc,1);
v_G6672_2 = ICALL(s_lsp_ALPHA_2DCHAR_2DP) (1, v_CHAR_0);
if (v_G6672_2 != NIL) {
return(v_G6672_2);
} else {
v_CHAR_5 = v_CHAR_0;
v_RADIX_6 = (LP) 20;
t0 = ICALL(s_lsp_DIGIT_2DCHAR_2DP_2F2) (MV_CALL(argc,2), v_CHAR_0, (LP) 20);
return(t0);
}
}

LP p_lsp_DECIMAL_2DINTEGER_2DLENGTH(argc, v_N_0)
      ARGC argc;  LP v_N_0;
{
LP v_LEN_3; LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; 
if (argc != 1) wna(argc,1);
v_X_2 = v_N_0;
v_LEN_3 = (LP) 0;
t_NEXT_2DLOOP_5:;
if (v_X_2 != NIL) {
v_LEN_3 = (((LP) ((int) (v_LEN_3) + (int) ((LP) 2))));
}
t1 = (lessp((v_X_2), ((LP) 20)));
if (t1 != NIL) {
return(v_LEN_3);
return(NIL);
}
v_X_2 = ICALL(s_lsp_FLOOR_2F1V) (2, v_X_2, (LP) 20);
goto t_NEXT_2DLOOP_5;
goto t_END_2DLOOP_6;
t_END_2DLOOP_6:;
return(NIL);
}

LP p_lsp_LISP_2D_3EC_2DNAME(argc, v_LEADER_0, v_NAME_1, v_TRAILER_2)
      ARGC argc;  LP v_LEADER_0; LP v_NAME_1; LP v_TRAILER_2;
{
LP v_Y_90; LP v_X_89; LP v_X_87; 
LP v_V6689_86; LP v_T6688_85; LP v_T6687_84; 
LP v_S6686_83; LP v_N_81; LP v_C_79; 
LP v_LOOP_2DITER_2DFLAG_2D1410_75; LP v_REST_74; LP v_TO_73; 
LP v_I_72; LP v_V6685_71; LP v_T6684_70; 
LP v_T6683_69; LP v_S6682_68; LP v_S6681_67; 
LP v_SOURCE_2DEND_65; LP v_SOURCE_2DSTART_64; LP v_TARGET_2DEND_63; 
LP v_TARGET_2DSTART_62; LP v_SOURCE_2DSEQUENCE_61; LP v_TARGET_2DSEQUENCE_60; 
LP v_C_58; LP v_SYMBOL_56; LP v_SOURCE_2DSEQUENCE_51; 
LP v_TARGET_2DSEQUENCE_50; LP v_SOURCE_2DEND_55; LP v_SOURCE_2DSTART_54; 
LP v_TARGET_2DEND_53; LP v_TARGET_2DSTART_52; LP v_V6680_49; 
LP v_T6679_48; LP v_T6678_47; LP v_S6677_46; 
LP v_SRC_2DCHAR_45; LP v_LOOP_2DITER_2DFLAG_2D1409_41; LP v_LOOP_2DBIND_2D1408_40; 
LP v_TO_39; LP v_LOOP_2DBIND_2D1407_38; LP v_FROM_37; 
LP v_V6676_36; LP v_T6675_35; LP v_T6674_34; 
LP v_S6673_33; LP v_LOOP_2DBIND_2D1406_29; LP v_I_28; 
LP v_C_2DNAME_27; LP v_INITIAL_2DELEMENT_25; LP v_N_24; 
LP v_N_22; LP v_INITIAL_2DELEMENT_23; LP v_C_2DNAME_2DLEN_21; 
LP v_TRAILER_2DLEN_20; LP v_LEADER_2DLEN_19; LP v_LEGAL_2DCHAR_2DCOUNT_18; 
LP v_LOOPVAR_2D1405_14; LP v_LOOP_2DSEQ_2DLIMIT_2D1404_13; LP v_LOOPVAR_2D1402_12; 
LP v_LOOPVAR_2D1403_11; LP v_C_10; LP v_LISP_2DLEN_9; 
LP v_LISP_2DNAME_8; LP v_S_6; LP v_X_4; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; 
if (argc != 3) wna(argc,3);
v_S_6 = v_NAME_1;
if (OTHER_PTRP((v_NAME_1)) && (TAG((v_NAME_1)) == 3)) {
v_X_4 = v_NAME_1;
v_LISP_2DNAME_8 = ((LP) DEREF((v_NAME_1) + 7 * 4));
} else {
v_LISP_2DNAME_8 = v_NAME_1;
}
v_LISP_2DLEN_9 = ICALL(s_lsp_LENGTH) (1, v_LISP_2DNAME_8);
v_C_10 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1403_11 = v_LISP_2DNAME_8;
v_LOOPVAR_2D1402_12 = (LP) 0;
v_LOOP_2DSEQ_2DLIMIT_2D1404_13 = (LP) 0;
v_LOOPVAR_2D1405_14 = (LP) 0;
v_LOOP_2DSEQ_2DLIMIT_2D1404_13 = ICALL(s_lsp_LENGTH) (1, v_LOOPVAR_2D1403_11);
t_NEXT_2DLOOP_16:;
if (((int) (v_LOOPVAR_2D1402_12) >= (int) (v_LOOP_2DSEQ_2DLIMIT_2D1404_13))) {
goto t_END_2DLOOP_17;
}
v_C_10 = (vref((v_LOOPVAR_2D1403_11), (v_LOOPVAR_2D1402_12)));
t2 = ICALL(s_lsp_LEGAL_2DC_2DVAR_2DCHAR_3F) (1, v_C_10);
if (t2 != NIL) {
if (v_C_10 != NIL) {
v_LOOPVAR_2D1405_14 = (((LP) ((int) (v_LOOPVAR_2D1405_14) + (int) ((LP) 2))));
}
}
v_LOOPVAR_2D1402_12 = (((LP) ((int) (v_LOOPVAR_2D1402_12) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_16;
goto t_END_2DLOOP_17;
t_END_2DLOOP_17:;
v_LEGAL_2DCHAR_2DCOUNT_18 = v_LOOPVAR_2D1405_14;
goto b_NIL_15;
v_LEGAL_2DCHAR_2DCOUNT_18 = NIL;
v_LEGAL_2DCHAR_2DCOUNT_18 = v_LEGAL_2DCHAR_2DCOUNT_18;
b_NIL_15:;
v_LEADER_2DLEN_19 = ICALL(s_lsp_LENGTH) (1, v_LEADER_0);
if (v_TRAILER_2 != NIL) {
t3 = ICALL(s_lsp_DECIMAL_2DINTEGER_2DLENGTH) (1, v_TRAILER_2);
v_TRAILER_2DLEN_20 = (add((t3), ((LP) 2)));
} else {
v_TRAILER_2DLEN_20 = (LP) 0;
}
t5 = (add((v_LEADER_2DLEN_19), (v_LISP_2DLEN_9)));
t4 = (add((t5), (v_TRAILER_2DLEN_20)));
t7 = (subtract((v_LISP_2DLEN_9), (v_LEGAL_2DCHAR_2DCOUNT_18)));
t6 = (multiply((t7), ((LP) 4)));
v_C_2DNAME_2DLEN_21 = (add((t4), (t6)));
v_N_24 = v_C_2DNAME_2DLEN_21;
v_INITIAL_2DELEMENT_25 = LREF(char_tab[0]);
v_C_2DNAME_27 = ICALL(s_lsp_MAKE_2DSIMPLE_2DSTRING) (2, v_C_2DNAME_2DLEN_21, LREF(char_tab[0]));
v_I_28 = (LP) 0;
t_NEXT_2DLOOP_31:;
if (((int) (v_I_28) >= (int) (v_LEADER_2DLEN_19))) {
goto t_END_2DLOOP_32;
}
v_S6673_33 = NEW_CHAR((LP) *((v_LEADER_0) - 1 + FX_TO_INT(v_I_28)));
v_T6674_34 = v_C_2DNAME_27;
v_T6675_35 = v_I_28;
v_V6676_36 = v_S6673_33;
((LP) (*((v_C_2DNAME_27) - 1 + FX_TO_INT(v_T6675_35)) = (char) RAW_CHAR(v_V6676_36)));
v_I_28 = (((LP) ((int) (v_I_28) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_31;
goto t_END_2DLOOP_32;
t_END_2DLOOP_32:;
v_FROM_37 = (LP) 0;
v_TO_39 = v_LEADER_2DLEN_19;
v_LOOP_2DITER_2DFLAG_2D1409_41 = LREF(s_lsp_T);
t_NEXT_2DLOOP_43:;
if (((int) (v_FROM_37) >= (int) (v_LISP_2DLEN_9))) {
goto t_END_2DLOOP_44;
}
if (v_LOOP_2DITER_2DFLAG_2D1409_41 == NIL) {
v_TO_39 = (((LP) ((int) (v_TO_39) + (int) ((LP) 2))));
}
if (((int) (v_TO_39) >= (int) (v_C_2DNAME_2DLEN_21))) {
goto t_END_2DLOOP_44;
}
v_SRC_2DCHAR_45 = NEW_CHAR((LP) *((v_LISP_2DNAME_8) - 1 + FX_TO_INT(v_FROM_37)));
t11 = ICALL(s_lsp_LEGAL_2DC_2DVAR_2DCHAR_3F) (1, v_SRC_2DCHAR_45);
if (t11 != NIL) {
v_S6677_46 = v_SRC_2DCHAR_45;
v_T6678_47 = v_C_2DNAME_27;
v_T6679_48 = v_TO_39;
v_V6680_49 = v_SRC_2DCHAR_45;
((LP) (*((v_C_2DNAME_27) - 1 + FX_TO_INT(v_T6679_48)) = (char) RAW_CHAR(v_V6680_49)));
} else {
v_SYMBOL_56 = LREF(s_lsp__2ACHAR_2DCONVERSIONS_2A);
t12 = ((LP) DEREF((LREF(s_lsp__2ACHAR_2DCONVERSIONS_2A)) + 0 * 4));
v_C_58 = v_SRC_2DCHAR_45;
t13 = INT_TO_FX(((int) RAW_CHAR(v_SRC_2DCHAR_45)));
v_SOURCE_2DSEQUENCE_61 = ((LP) DEREF((t12) + FX_TO_INT(t13) * 4));
v_TARGET_2DSTART_62 = v_TO_39;
ICALL(s_lsp_REPLACE_2F6) (6, v_C_2DNAME_27, v_SOURCE_2DSEQUENCE_61, v_TARGET_2DSTART_62, LREF(s_lsp_NIL), (LP) 0, LREF(s_lsp_NIL));
v_S6681_67 = (add((v_TO_39), ((LP) 4)));
v_TO_39 = v_S6681_67;
}
v_LOOP_2DITER_2DFLAG_2D1409_41 = LREF(s_lsp_NIL);
v_FROM_37 = (((LP) ((int) (v_FROM_37) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_43;
goto t_END_2DLOOP_44;
t_END_2DLOOP_44:;
v_X_87 = v_TRAILER_2;
v_X_89 = v_TRAILER_2;
v_Y_90 = LREF(s_lsp_NIL);
if (v_TRAILER_2 != NIL) {
v_S6682_68 = LREF(char_tab[95]);
v_T6683_69 = v_C_2DNAME_27;
v_T6684_70 = (subtract((v_C_2DNAME_2DLEN_21), (v_TRAILER_2DLEN_20)));
v_V6685_71 = LREF(char_tab[95]);
((LP) (*((v_C_2DNAME_27) - 1 + FX_TO_INT(v_T6684_70)) = (char) RAW_CHAR(v_V6685_71)));
v_I_72 = v_TRAILER_2DLEN_20;
v_TO_73 = (subtract((v_C_2DNAME_2DLEN_21), ((LP) 2)));
v_REST_74 = v_TRAILER_2;
v_LOOP_2DITER_2DFLAG_2D1410_75 = LREF(s_lsp_T);
t_NEXT_2DLOOP_77:;
if (((int) (v_I_72) < (int) ((LP) 4))) {
goto t_END_2DLOOP_78;
}
if (v_LOOP_2DITER_2DFLAG_2D1410_75 == NIL) {
v_TO_73 = (((LP) ((int) (v_TO_73) - (int) ((LP) 2))));
}
if (((int) (v_TO_73) < (int) ((LP) 0))) {
goto t_END_2DLOOP_78;
}
if (v_LOOP_2DITER_2DFLAG_2D1410_75 == NIL) {
v_REST_74 = ICALL(s_lsp_FLOOR_2F1V) (2, v_REST_74, (LP) 20);
}
v_C_79 = LREF(char_tab[48]);
t16 = INT_TO_FX(((int) RAW_CHAR(LREF(char_tab[48]))));
t17 = ICALL(s_lsp_REM) (2, v_REST_74, (LP) 20);
v_N_81 = (add((t16), (t17)));
if (((int) (v_N_81) >= (int) ((LP) 512))) {
v_S6686_83 = LREF(s_lsp_NIL);
} else {
v_S6686_83 = NEW_CHAR(((unsigned char) FX_TO_INT(v_N_81)));
}
v_T6687_84 = v_C_2DNAME_27;
v_T6688_85 = v_TO_73;
v_V6689_86 = v_S6686_83;
((LP) (*((v_C_2DNAME_27) - 1 + FX_TO_INT(v_T6688_85)) = (char) RAW_CHAR(v_V6689_86)));
v_LOOP_2DITER_2DFLAG_2D1410_75 = LREF(s_lsp_NIL);
v_I_72 = (((LP) ((int) (v_I_72) - (int) ((LP) 2))));
goto t_NEXT_2DLOOP_77;
goto t_END_2DLOOP_78;
t_END_2DLOOP_78:;
}
return(v_C_2DNAME_27);
}

LP p_lsp_LISP_2D_3EC_2DFIELD_2DNAME(argc, v_NAME_0)
      ARGC argc;  LP v_NAME_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_LISP_2D_3EC_2DNAME) (MV_CALL(argc,3), LREF(k10890), v_NAME_0, LREF(s_lsp_NIL));
return(t0);
}

LP p_lsp_LISP_2D_3EC_2DFUNCTION_2DNAME(argc, v_NAME_0, v_ID_1)
      ARGC argc;  LP v_NAME_0; LP v_ID_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_LISP_2D_3EC_2DNAME) (MV_CALL(argc,3), LREF(k10891), v_NAME_0, v_ID_1);
return(t0);
}

LP p_lsp_LISP_2D_3EC_2DVARIABLE_2DNAME(argc, v_NAME_0, v_ID_1)
      ARGC argc;  LP v_NAME_0; LP v_ID_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_LISP_2D_3EC_2DNAME) (MV_CALL(argc,3), LREF(k10892), v_NAME_0, v_ID_1);
return(t0);
}

LP p_lsp_LISP_2D_3EC_2DBLOCK_2DNAME(argc, v_NAME_0, v_ID_1)
      ARGC argc;  LP v_NAME_0; LP v_ID_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_LISP_2D_3EC_2DNAME) (MV_CALL(argc,3), LREF(k10893), v_NAME_0, v_ID_1);
return(t0);
}

LP p_lsp_LISP_2D_3EC_2DTAG_2DNAME(argc, v_NAME_0, v_ID_1)
      ARGC argc;  LP v_NAME_0; LP v_ID_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_LISP_2D_3EC_2DNAME) (MV_CALL(argc,3), LREF(k10894), v_NAME_0, v_ID_1);
return(t0);
}

LP p_lsp_LISP_2D_3EC_2DSYMBOL_2DNAME(argc, v_SYM_0)
      ARGC argc;  LP v_SYM_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_SYMBOL_2DPACKAGE_2DABBREV) (1, v_SYM_0);
t0 = ICALL(s_lsp_LISP_2D_3EC_2DNAME) (MV_CALL(argc,3), t1, v_SYM_0, LREF(s_lsp_NIL));
return(t0);
}

LP p_lsp_LISP_2D_3EC_2DPROC_2DNAME(va_alist) va_dcl
{
LP v_NAME_0; LP v_MACRO_2DFUNCTION_3F_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_NAME_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_MACRO_2DFUNCTION_3F_1 = NIL;
} else {
v_MACRO_2DFUNCTION_3F_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
if (v_MACRO_2DFUNCTION_3F_1 != NIL) {
t1 = ICALL(s_lsp_MACRO_2DPACKAGE_2DABBREV) (1, v_NAME_0);
} else {
t1 = ICALL(s_lsp_PROC_2DPACKAGE_2DABBREV) (1, v_NAME_0);
}
t0 = ICALL(s_lsp_LISP_2D_3EC_2DNAME) (MV_CALL(argc,3), t1, v_NAME_0, LREF(s_lsp_NIL));
return(t0);
}

