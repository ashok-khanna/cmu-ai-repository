/*
:comment "Compiled at 4:44:25 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: Debug Library"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O2 -fPIC"
:version 0
:end-package-info 0
:SC MAX-NO-COLLISION-TRIES 256
:sym EQL
:sym NIL
:sf DUPLICATES? "p_lsp_DUPLICATES_3F"
:sym EQ
:sym DUPLICATES?
:sym LENGTH
:sym NO-COLLISION-HASH-SIZE-1
:sf NO-COLLISION-HASH-SIZE "p_lsp_NO_2DCOLLISION_2DHASH_2DSIZE"
:sym MAKE-SIMPLE-ARRAY
:sym SXHASH
:sym REM
:sym SBIT
:sym SET-SBIT
:sf NO-COLLISION-HASH-SIZE-1 "p_lsp_NO_2DCOLLISION_2DHASH_2DSIZE_2D1"
:sym NO-COLLISION-HASH-SIZE
:sym GENSYM/1
:sym SYMBOL-HASH-CODE
:sym %REM
:sym %32BIT-REF
:sym LET
:sf FIND->HASHED-SYMBOL-LOOKUP "p_lsp_FIND_2D_3EHASHED_2DSYMBOL_2DLOOKUP"
:sym REVERSE
:sym T
:sym OTHERWISE
:sym MEMQL
:sym PROGN
:sym COPY-LIST
:sym LAST
:sym EQUAL
:sym WARN
:sym SYMBOLP
:sym EVERY
:sym OPTIMIZE-CASE/SYMBOLS
:sym FIXNUMP
:sym OPTIMIZE-CASE/FIXNUMS
:sym CHARACTERP
:sym OPTIMIZE-CASE/CHARS
:sf OPTIMIZE-CASE "p_lsp_OPTIMIZE_2DCASE"
:sym SWITCH
:sym APPEND/2
:sym LIST*
:sf OPTIMIZE-CASE/FIXNUMS "p_lsp_OPTIMIZE_2DCASE_2FFIXNUMS"
:sym TAGBODY
:sym %CHAR-CODE
:sym GO
:sym RETURN-FROM
:sym WHEN
:sym LIST
:sym BLOCK
:sf OPTIMIZE-CASE/CHARS "p_lsp_OPTIMIZE_2DCASE_2FCHARS"
:sym FLATTEN-MULTI-CASES
:sym IF
:sym QUOTE
:sf OPTIMIZE-CASE/SYMBOLS "p_lsp_OPTIMIZE_2DCASE_2FSYMBOLS"
:sf FLATTEN-MULTI-CASES "p_lsp_FLATTEN_2DMULTI_2DCASES"
:sym OPTIMIZE-TYPECASE1231
:sym TYPE-MACROEXPAND
:sym TYPE->TYPE-CODES
:sym :FIXNUM
:sym :STRUCTURE
:sym LOOKUP-STRUCTURE-INFO
:sym ALL-CURRENT-STRUCTURE-CHILDREN
:sym =
:sym OPTIMIZE-TYPECASE-1
:sf OPTIMIZE-TYPECASE "p_lsp_OPTIMIZE_2DTYPECASE"
:sym SATISFIES
:sym STRUCTUREP
:sym COMPILED-FUNCTION-P
:sym FOREIGN-POINTER-P
:sym CONSP
:sym COMPLEXP
:sym RATIOP
:sym BIGNUMP
:sym SYMBOL
:sym CHARACTER
:sym FLOAT
:sym ARRAY
:sym SIMPLE-ARRAY
:sym INTEGER
:sym *FIXNUM-SPEC*
:sym ARRAY-TYPE->TYPE-CODES
:sf TYPE->TYPE-CODES "p_lsp_TYPE_2D_3ETYPE_2DCODES"
:sf ARRAY-TYPE->TYPE-CODES "p_lsp_ARRAY_2DTYPE_2D_3ETYPE_2DCODES"
:sym %TAG
:sym CASE
:sym STRUCTURE-TYPE
:sf OPTIMIZE-TYPECASE-1 "p_lsp_OPTIMIZE_2DTYPECASE_2D1"
:sym :VAR
:sym DEFINE-VARIABLE
:sf TYPE-DISPATCH_INIT1240 "p_lsp_TYPE_2DDISPATCH_5FINIT1240"
:init TYPE-DISPATCH_INIT1240
:pinfo OPTIMIZE-TYPECASE (ORIGINAL KEY-FORM CASES) NIL NIL NIL NIL NIL NIL T
:pinfo OPTIMIZE-TYPECASE-1 (KEY-FORM FIXNUM STRUCTURE STRUCTURE-CASES OTHERS DEFAULT) NIL NIL NIL NIL NIL NIL T
:pinfo NO-COLLISION-HASH-SIZE-1 (SYMBOLS NUM-TRIES SIZE) NIL NIL NIL NIL NIL NIL T
:pinfo DUPLICATES? (LIST &OPTIONAL (TEST (FUNCTION EQL))) NIL NIL NIL NIL NIL NIL T
:pinfo FIND->HASHED-SYMBOL-LOOKUP (KEY SYMBOL-LIST) NIL NIL NIL NIL NIL NIL T
:pinfo OPTIMIZE-CASE/CHARS (KEY-FORM SPECIFIC-CASES DEFAULT) NIL NIL NIL NIL NIL NIL T
:pinfo OPTIMIZE-CASE (ORIGINAL KEY-FORM CASES) NIL NIL NIL NIL NIL NIL T
:pinfo ARRAY-TYPE->TYPE-CODES (ARRAY-SPEC) NIL NIL NIL NIL NIL NIL T
:pinfo OPTIMIZE-CASE/SYMBOLS (ALL-KEYS KEY-FORM SPECIFIC-CASES DEFAULT) NIL NIL NIL NIL NIL NIL T
:pinfo FLATTEN-MULTI-CASES (SPECIFIC-CASES BLOCK-NAME) NIL NIL NIL NIL NIL NIL T
:pinfo TYPE-DISPATCH_INIT1240 NIL NIL NIL NIL NIL NIL NIL T
:pinfo TYPE->TYPE-CODES (TYPE) NIL NIL NIL NIL NIL NIL T
:pinfo NO-COLLISION-HASH-SIZE (SYMBOLS) NIL NIL NIL NIL NIL NIL T
:pinfo OPTIMIZE-CASE/FIXNUMS (KEY-FORM SPECIFIC-CASES DEFAULT) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_lsp_DUPLICATES_3F();
extern SYMBOL s_lsp_EQL; 
extern SYMBOL s_lsp_NIL; 
extern LP p_lsp_NO_2DCOLLISION_2DHASH_2DSIZE();
extern SYMBOL s_lsp_EQ; 
extern SYMBOL s_lsp_DUPLICATES_3F; 
extern SYMBOL s_lsp_LENGTH; 
extern SYMBOL s_lsp_NO_2DCOLLISION_2DHASH_2DSIZE_2D1; 
extern LP p_lsp_NO_2DCOLLISION_2DHASH_2DSIZE_2D1();
extern SYMBOL s_lsp_MAKE_2DSIMPLE_2DARRAY; 
extern SYMBOL s_lsp_SXHASH; 
extern SYMBOL s_lsp_REM; 
extern SYMBOL s_lsp_SBIT; 
extern SYMBOL s_lsp_SET_2DSBIT; 
extern LP p_lsp_FIND_2D_3EHASHED_2DSYMBOL_2DLOOKUP();
extern SYMBOL s_lsp_NO_2DCOLLISION_2DHASH_2DSIZE; 
MAKE_SIMPLE_STRING(k10736,3,"KEY");
extern SYMBOL s_lsp_GENSYM_2F1; 
extern SYMBOL s_lsp_SYMBOL_2DHASH_2DCODE; 
extern SYMBOL s_lsp__25REM; 
extern SYMBOL s_lsp__2532BIT_2DREF; 
extern SYMBOL s_lsp_LET; 
extern LP p_lsp_OPTIMIZE_2DCASE();
extern SYMBOL s_lsp_REVERSE; 
extern SYMBOL s_lsp_T; 
extern SYMBOL s_lsp_OTHERWISE; 
MAKE_CONS(k10739,LREF(s_lsp_OTHERWISE),LREF(s_lsp_NIL));
MAKE_CONS(k10738,LREF(s_lsp_T),LREF(k10739));
extern SYMBOL s_lsp_MEMQL; 
extern SYMBOL s_lsp_PROGN; 
extern SYMBOL s_lsp_COPY_2DLIST; 
extern SYMBOL s_lsp_LAST; 
extern SYMBOL s_lsp_EQUAL; 
MAKE_SIMPLE_STRING(k10740,30,"The key ~A is duplicated in ~A");
extern SYMBOL s_lsp_WARN; 
extern SYMBOL s_lsp_SYMBOLP; 
extern SYMBOL s_lsp_EVERY; 
extern SYMBOL s_lsp_OPTIMIZE_2DCASE_2FSYMBOLS; 
extern SYMBOL s_lsp_FIXNUMP; 
extern SYMBOL s_lsp_OPTIMIZE_2DCASE_2FFIXNUMS; 
extern SYMBOL s_lsp_CHARACTERP; 
extern SYMBOL s_lsp_OPTIMIZE_2DCASE_2FCHARS; 
extern LP p_lsp_OPTIMIZE_2DCASE_2FFIXNUMS();
extern SYMBOL s_lsp_SWITCH; 
extern SYMBOL s_lsp_APPEND_2F2; 
extern SYMBOL s_lsp_LIST_2A; 
extern LP p_lsp_OPTIMIZE_2DCASE_2FCHARS();
MAKE_SIMPLE_STRING(k10741,11,"DEFAULT-TAG");
MAKE_SIMPLE_STRING(k10742,4,"CASE");
extern SYMBOL s_lsp_TAGBODY; 
extern SYMBOL s_lsp__25CHAR_2DCODE; 
extern SYMBOL s_lsp_GO; 
extern SYMBOL s_lsp_RETURN_2DFROM; 
extern SYMBOL s_lsp_WHEN; 
extern SYMBOL s_lsp_LIST; 
extern SYMBOL s_lsp_BLOCK; 
extern LP p_lsp_OPTIMIZE_2DCASE_2FSYMBOLS();
extern SYMBOL s_lsp_FLATTEN_2DMULTI_2DCASES; 
extern SYMBOL s_lsp_IF; 
extern SYMBOL s_lsp_QUOTE; 
extern LP p_lsp_FLATTEN_2DMULTI_2DCASES();
extern LP p_lsp_FLATTEN_2DMULTI_2DCASES_2DDOIT10744();
MAKE_SIMPLE_STRING(k10745,1,"C");
extern LP p_lsp_OPTIMIZE_2DTYPECASE();
extern SYMBOL s_lsp_OPTIMIZE_2DTYPECASE1231; 
extern LP p_lsp_OPTIMIZE_2DTYPECASE_2DFAIL10752();
extern LP p_lsp_OPTIMIZE_2DTYPECASE_2DADD_2DCASE10753();
MAKE_PROCEDURE(k10755,p_lsp_OPTIMIZE_2DTYPECASE_2DADD_2DCASE10753);
extern LP p_lsp_OPTIMIZE_2DTYPECASE_2DCLASSIFY10754();
extern SYMBOL s_lsp_TYPE_2DMACROEXPAND; 
extern SYMBOL s_lsp_TYPE_2D_3ETYPE_2DCODES; 
extern SYMBOL s_key_FIXNUM; 
extern SYMBOL s_key_STRUCTURE; 
extern SYMBOL s_lsp_LOOKUP_2DSTRUCTURE_2DINFO; 
extern SYMBOL s_lsp_ALL_2DCURRENT_2DSTRUCTURE_2DCHILDREN; 
extern SYMBOL s_lsp__3D; 
extern SYMBOL s_lsp_OPTIMIZE_2DTYPECASE_2D1; 
extern LP p_lsp_TYPE_2D_3ETYPE_2DCODES();
extern SYMBOL s_lsp_SATISFIES; 
extern SYMBOL s_lsp_STRUCTUREP; 
extern SYMBOL s_lsp_COMPILED_2DFUNCTION_2DP; 
extern SYMBOL s_lsp_FOREIGN_2DPOINTER_2DP; 
extern SYMBOL s_lsp_CONSP; 
extern SYMBOL s_lsp_COMPLEXP; 
extern SYMBOL s_lsp_RATIOP; 
extern SYMBOL s_lsp_BIGNUMP; 
extern SYMBOL s_lsp_SYMBOL; 
extern SYMBOL s_lsp_CHARACTER; 
extern SYMBOL s_lsp_FLOAT; 
extern SYMBOL s_lsp_ARRAY; 
extern SYMBOL s_lsp_SIMPLE_2DARRAY; 
extern SYMBOL s_lsp_INTEGER; 
extern SYMBOL s_lsp__2AFIXNUM_2DSPEC_2A; 
extern SYMBOL s_lsp_ARRAY_2DTYPE_2D_3ETYPE_2DCODES; 
extern LP p_lsp_ARRAY_2DTYPE_2D_3ETYPE_2DCODES();
extern LP p_lsp_ARRAY_2DTYPE_2D_3ETYPE_2DCODES_2Danon1075610757();
extern LP p_lsp_OPTIMIZE_2DTYPECASE_2D1();
MAKE_SIMPLE_STRING(k10758,8,"TYPECASE");
extern SYMBOL s_lsp__25TAG; 
extern SYMBOL s_lsp_CASE; 
extern SYMBOL s_lsp_STRUCTURE_2DTYPE; 
extern LP p_lsp_TYPE_2DDISPATCH_5FINIT1240();
extern SYMBOL s_key_VAR; 
extern SYMBOL s_lsp_DEFINE_2DVARIABLE; 


extern LP greaterp();
extern LP c_cons();
extern LP add();
extern LP num_equal_p();


LP p_lsp_DUPLICATES_3F(va_alist) va_dcl
{
LP v_X_23; LP v_X_21; LP v_X_19; 
LP v_X_17; LP v_X_15; LP v_L2_11; 
LP v_X_9; LP v_L1_5; LP v_LIST_0; 
LP v_X_2; LP v_TEST_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_LIST_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_X_2 = LREF(s_lsp_EQL);
t0 = ((LP) DEREF((v_X_2) + 4 * 4));
v_TEST_1 = t0;
} else {
v_TEST_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
v_L1_5 = v_LIST_0;
t_NEXT_2DLOOP_7:;
if (v_L1_5 == NIL) {
goto t_END_2DLOOP_8;
}
v_X_9 = v_L1_5;
v_L2_11 = ((LP) DEREF((v_X_9) + 1 * 4));
t_NEXT_2DLOOP_13:;
if (v_L2_11 == NIL) {
goto t_END_2DLOOP_14;
}
v_X_17 = v_L1_5;
t3 = ((LP) DEREF((v_X_17) + 0 * 4));
v_X_19 = v_L2_11;
t4 = ((LP) DEREF((v_X_19) + 0 * 4));
t2 = CODE_PTR(COERCE_TO_FUNCTION(v_TEST_1))(2, t3, t4);
if (t2 != NIL) {
v_X_15 = v_L1_5;
t5 = ((LP) DEREF((v_X_15) + 0 * 4));
return(t5);
return(NIL);
}
v_X_21 = v_L2_11;
v_L2_11 = ((LP) DEREF((v_X_21) + 1 * 4));
goto t_NEXT_2DLOOP_13;
goto t_END_2DLOOP_14;
t_END_2DLOOP_14:;
v_X_23 = v_L1_5;
v_L1_5 = ((LP) DEREF((v_X_23) + 1 * 4));
goto t_NEXT_2DLOOP_7;
goto t_END_2DLOOP_8;
t_END_2DLOOP_8:;
return(LREF(s_lsp_NIL));
}

LP p_lsp_NO_2DCOLLISION_2DHASH_2DSIZE(argc, v_SYMBOLS_0)
      ARGC argc;  LP v_SYMBOLS_0;
{
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; 
if (argc != 1) wna(argc,1);
v_X_2 = LREF(s_lsp_EQ);
t2 = ((LP) DEREF((LREF(s_lsp_EQ)) + 4 * 4));
t1 = ICALL(s_lsp_DUPLICATES_3F) (2, v_SYMBOLS_0, t2);
if (t1 != NIL) {
return(LREF(s_lsp_NIL));
} else {
t3 = ICALL(s_lsp_LENGTH) (1, v_SYMBOLS_0);
t0 = ICALL(s_lsp_NO_2DCOLLISION_2DHASH_2DSIZE_2D1) (MV_CALL(argc,3), v_SYMBOLS_0, (LP) 0, t3);
return(t0);
}
}

LP p_lsp_NO_2DCOLLISION_2DHASH_2DSIZE_2D1(argc, v_SYMBOLS_0, v_NUM_2DTRIES_1, v_SIZE_2)
      ARGC argc;  LP v_SYMBOLS_0; LP v_NUM_2DTRIES_1; LP v_SIZE_2;
{
LP v_X_23; LP v_X_21; LP v_G5844_20; 
LP v_T5847_19; LP v_T5846_18; LP v_S5845_17; 
LP v_INDEX_16; LP v_X_14; LP v_X_12; 
LP v_X_10; LP v_LOOP_2DLIST_2D1197_6; LP v_SYMBOL_5; 
LP v_BITS_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 

if (argc != 3) wna(argc,3);
START10735:
t1 = (num_equal_p((v_NUM_2DTRIES_1), ((LP) 512)));
if (t1 != NIL) {
return(LREF(s_lsp_NIL));
} else {
v_BITS_4 = ICALL(s_lsp_MAKE_2DSIMPLE_2DARRAY) (5, v_SIZE_2, (LP) 0, (LP) 2, (LP) 0, LREF(s_lsp_NIL));
v_SYMBOL_5 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D1197_6 = v_SYMBOLS_0;
t_NEXT_2DLOOP_8:;
if (v_LOOP_2DLIST_2D1197_6 == NIL) {
goto t_END_2DLOOP_9;
}
v_X_10 = v_LOOP_2DLIST_2D1197_6;
v_SYMBOL_5 = ((LP) DEREF((v_X_10) + 0 * 4));
v_X_12 = v_LOOP_2DLIST_2D1197_6;
v_LOOP_2DLIST_2D1197_6 = ((LP) DEREF((v_X_12) + 1 * 4));
v_X_14 = v_SYMBOL_5;
t2 = ICALL(s_lsp_SXHASH) (1, v_X_14);
v_INDEX_16 = ICALL(s_lsp_REM) (2, t2, v_SIZE_2);
t4 = ICALL(s_lsp_SBIT) (2, v_BITS_4, v_INDEX_16);
t3 = (num_equal_p((t4), ((LP) 0)));
if (t3 != NIL) {
v_S5845_17 = (LP) 2;
v_T5846_18 = v_BITS_4;
v_T5847_19 = v_INDEX_16;
ICALL(s_lsp_SET_2DSBIT) (3, (LP) 2, v_BITS_4, v_INDEX_16);
} else {
v_G5844_20 = LREF(s_lsp_NIL);
goto b_NIL_7;
}
goto t_NEXT_2DLOOP_8;
goto t_END_2DLOOP_9;
t_END_2DLOOP_9:;
v_G5844_20 = v_SIZE_2;
goto b_NIL_7;
v_G5844_20 = NIL;
v_G5844_20 = v_G5844_20;
b_NIL_7:;
if (v_G5844_20 != NIL) {
return(v_G5844_20);
} else {
v_X_21 = v_NUM_2DTRIES_1;
t5 = (add((v_NUM_2DTRIES_1), ((LP) 2)));
v_X_23 = v_SIZE_2;
t6 = (add((v_SIZE_2), ((LP) 2)));
v_NUM_2DTRIES_1 = t5; v_SIZE_2 = t6; 
goto START10735;
}
}
}

LP p_lsp_FIND_2D_3EHASHED_2DSYMBOL_2DLOOKUP(argc, v_KEY_0, v_SYMBOL_2DLIST_1)
      ARGC argc;  LP v_KEY_0; LP v_SYMBOL_2DLIST_1;
{
LP v_Y_73; LP v_X_72; LP v_Y_70; 
LP v_X_69; LP v_Y_67; LP v_X_66; 
LP v_Y_64; LP v_X_63; LP v_Y_61; 
LP v_X_60; LP v_Y_58; LP v_X_57; 
LP v_Y_55; LP v_X_54; LP v_Y_52; 
LP v_X_51; LP v_Y_49; LP v_X_48; 
LP v_Y_46; LP v_X_45; LP v_Y_43; 
LP v_X_42; LP v_Y_40; LP v_X_39; 
LP v_Y_37; LP v_X_36; LP v_Y_34; 
LP v_X_33; LP v_Y_31; LP v_X_30; 
LP v_Y_28; LP v_X_27; LP v_Y_25; 
LP v_X_24; LP v_V5851_23; LP v_T5850_22; 
LP v_X_20; LP v_T5849_19; LP v_S5848_18; 
LP v_X_16; LP v_X_14; LP v_LOOP_2DLIST_2D1198_10; 
LP v_S_9; LP v_TMP_8; LP v_X_6; 
LP v_X_5; LP v_TRUTH_2DVECTOR_4; LP v_NO_2DCOLLISION_2DSIZE_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 

if (argc != 2) wna(argc,2);
v_NO_2DCOLLISION_2DSIZE_3 = ICALL(s_lsp_NO_2DCOLLISION_2DHASH_2DSIZE) (1, v_SYMBOL_2DLIST_1);
v_TRUTH_2DVECTOR_4 = ICALL(s_lsp_MAKE_2DSIMPLE_2DARRAY) (5, v_NO_2DCOLLISION_2DSIZE_3, (LP) 128, (LP) 64, (LP) 0, LREF(s_lsp_NIL));
v_X_6 = LREF(k10736);
v_TMP_8 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(k10736));
v_S_9 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D1198_10 = v_SYMBOL_2DLIST_1;
t_NEXT_2DLOOP_12:;
if (v_LOOP_2DLIST_2D1198_10 == NIL) {
goto t_END_2DLOOP_13;
}
v_X_14 = v_LOOP_2DLIST_2D1198_10;
v_S_9 = ((LP) DEREF((v_X_14) + 0 * 4));
v_X_16 = v_LOOP_2DLIST_2D1198_10;
v_LOOP_2DLIST_2D1198_10 = ((LP) DEREF((v_X_16) + 1 * 4));
v_S5848_18 = v_S_9;
v_T5849_19 = v_TRUTH_2DVECTOR_4;
v_X_20 = v_S_9;
t0 = ICALL(s_lsp_SXHASH) (1, v_X_20);
v_T5850_22 = ICALL(s_lsp_REM) (2, t0, v_NO_2DCOLLISION_2DSIZE_3);
v_V5851_23 = v_S5848_18;
((LP) (DEREF((v_TRUTH_2DVECTOR_4) + FX_TO_INT(v_T5850_22) * 4) = (LD) (v_V5851_23)));
goto t_NEXT_2DLOOP_12;
goto t_END_2DLOOP_13;
t_END_2DLOOP_13:;
goto b_NIL_11;
b_NIL_11:;
v_X_24 = v_KEY_0;
v_Y_25 = LREF(s_lsp_NIL);
v_Y_28 = (c_cons((v_KEY_0), (LREF(s_lsp_NIL))));
v_X_30 = (c_cons((v_TMP_8), (v_Y_28)));
v_X_69 = (c_cons((v_X_30), (LREF(s_lsp_NIL))));
v_X_33 = v_TMP_8;
v_Y_34 = LREF(s_lsp_NIL);
v_Y_37 = (c_cons((v_TMP_8), (LREF(s_lsp_NIL))));
v_X_42 = (c_cons((LREF(s_lsp_SYMBOL_2DHASH_2DCODE)), (v_Y_37)));
v_X_39 = v_NO_2DCOLLISION_2DSIZE_3;
v_Y_40 = LREF(s_lsp_NIL);
v_Y_43 = (c_cons((v_NO_2DCOLLISION_2DSIZE_3), (LREF(s_lsp_NIL))));
v_Y_46 = (c_cons((v_X_42), (v_Y_43)));
v_X_48 = (c_cons((LREF(s_lsp__25REM)), (v_Y_46)));
v_Y_52 = (c_cons((v_X_48), (LREF(s_lsp_NIL))));
v_Y_55 = (c_cons((v_TRUTH_2DVECTOR_4), (v_Y_52)));
v_X_57 = (c_cons((LREF(s_lsp__2532BIT_2DREF)), (v_Y_55)));
v_Y_61 = (c_cons((v_X_57), (LREF(s_lsp_NIL))));
v_Y_64 = (c_cons((v_TMP_8), (v_Y_61)));
v_X_66 = (c_cons((LREF(s_lsp_EQ)), (v_Y_64)));
v_Y_70 = (c_cons((v_X_66), (LREF(s_lsp_NIL))));
v_Y_73 = (c_cons((v_X_69), (v_Y_70)));
t1 = (c_cons((LREF(s_lsp_LET)), (v_Y_73)));
return(t1);
}

LP p_lsp_OPTIMIZE_2DCASE(argc, v_ORIGINAL_0, v_KEY_2DFORM_1, v_CASES_2)
      ARGC argc;  LP v_ORIGINAL_0; LP v_KEY_2DFORM_1; LP v_CASES_2;
{
LP v_X_72; LP v_X_70; LP v_C_68; 
LP v_Y_66; LP v_X_65; LP v_X_63; 
LP v_X_61; LP v_C_59; LP v_X_57; 
LP v_REV_56; LP v_X_54; LP v_X_52; 
LP v_X_50; LP v_DUP_3F_49; LP v_X_47; 
LP v_ALL_2DKEYS_46; LP v_X_44; LP v_G5852_43; 
LP v_Y_41; LP v_X_40; LP v_X_38; 
LP v_X_36; LP v_Y_34; LP v_X_33; 
LP v_X_31; LP v_V_29; LP v_X_28; 
LP v_NEW_2DCDR_26; LP v_C_25; LP v_X_23; 
LP v_X_21; LP v_X_19; LP v_X_17; 
LP v_X_15; LP v_LOOPVAR_2D1202_11; LP v_LOOPVAR_2D1201_10; 
LP v_LOOPVAR_2D1200_9; LP v_LOOP_2DLIST_2D1199_8; LP v_CONSEQUENT_7; 
LP v_KEYS_6; LP v_DEFAULT_5; LP v_SPECIFIC_2DCASES_4; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; 
if (argc != 3) wna(argc,3);
{
int real_argc;
BEGIN_MV_CALL(mv_holder10737,0);
v_REV_56 = ICALL(s_lsp_REVERSE) (1, v_CASES_2);
v_C_68 = v_REV_56;
v_X_70 = v_REV_56;
v_X_72 = ((LP) DEREF((v_REV_56) + 0 * 4));
t2 = ((LP) DEREF((v_X_72) + 0 * 4));
t1 = ICALL(s_lsp_MEMQL) (2, t2, LREF(k10738));
if (t1 != NIL) {
v_X_57 = v_REV_56;
t4 = ((LP) DEREF((v_REV_56) + 1 * 4));
t3 = ICALL(s_lsp_REVERSE) (1, t4);
v_C_59 = v_REV_56;
v_X_61 = v_REV_56;
v_X_63 = ((LP) DEREF((v_REV_56) + 0 * 4));
v_Y_66 = ((LP) DEREF((v_X_63) + 1 * 4));
t5 = (c_cons((LREF(s_lsp_PROGN)), (v_Y_66)));
SET_MV_RETURN_FLAG(mv_holder10737);
SET_MV_RETURN_COUNT(mv_holder10737,2);
SET_MV_RETURN_VALUE(mv_holder10737,1,t5);
t0 = t3;
} else {
SET_MV_RETURN_FLAG(mv_holder10737);
SET_MV_RETURN_COUNT(mv_holder10737,2);
SET_MV_RETURN_VALUE(mv_holder10737,1,LREF(s_lsp_NIL));
t0 = v_CASES_2;
}
SET_MV_RETURN_VALUE(mv_holder10737,0,t0);
if SV_RETURN_P(mv_holder10737) SET_MV_RETURN_COUNT(mv_holder10737,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder10737);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_SPECIFIC_2DCASES_4 = NIL;
} else {
v_SPECIFIC_2DCASES_4 = NEXT_VAR_VALUE(mv_holder10737);
}
if (real_argc < 2) {
v_DEFAULT_5 = NIL;
} else {
v_DEFAULT_5 = NEXT_VAR_VALUE(mv_holder10737);
}
END_VAR_VALUES;
END_MV_CALL;
v_KEYS_6 = LREF(s_lsp_NIL);
v_CONSEQUENT_7 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D1199_8 = v_SPECIFIC_2DCASES_4;
v_LOOPVAR_2D1200_9 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1201_10 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1202_11 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_13:;
if (v_LOOP_2DLIST_2D1199_8 == NIL) {
goto t_END_2DLOOP_14;
}
v_X_15 = v_LOOP_2DLIST_2D1199_8;
v_X_17 = ((LP) DEREF((v_X_15) + 0 * 4));
v_KEYS_6 = ((LP) DEREF((v_X_17) + 0 * 4));
v_X_19 = v_LOOP_2DLIST_2D1199_8;
v_X_21 = ((LP) DEREF((v_X_19) + 0 * 4));
v_CONSEQUENT_7 = ((LP) DEREF((v_X_21) + 1 * 4));
v_X_23 = v_LOOP_2DLIST_2D1199_8;
v_LOOP_2DLIST_2D1199_8 = ((LP) DEREF((v_X_23) + 1 * 4));
v_X_36 = v_KEYS_6;
v_X_38 = v_X_36;
v_X_40 = v_X_36;
v_Y_41 = LREF(s_lsp_NIL);
v_G5852_43 = (((v_X_36) == (LREF(s_lsp_NIL))) ? T : NIL);
if (v_G5852_43 != NIL) {
t7 = v_G5852_43;
} else {
v_X_44 = v_X_36;
t7 = (OTHER_PTRP((v_X_36)) && (TAG((v_X_36)) == 15) ? T : NIL);
}
if (t7 != NIL) {
t6 = v_KEYS_6;
} else {
v_X_33 = v_KEYS_6;
t6 = (c_cons((v_X_33), (LREF(s_lsp_NIL))));
}
v_LOOPVAR_2D1202_11 = ICALL(s_lsp_COPY_2DLIST) (1, t6);
if (v_LOOPVAR_2D1202_11 != NIL) {
if (v_LOOPVAR_2D1201_10 != NIL) {
v_C_25 = v_LOOPVAR_2D1201_10;
v_NEW_2DCDR_26 = v_LOOPVAR_2D1202_11;
v_V_29 = v_NEW_2DCDR_26;
((LP) (DEREF((v_C_25) + 1 * 4) = (LD) (v_V_29)));
v_X_31 = v_C_25;
t8 = ((LP) DEREF((v_X_31) + 1 * 4));
} else {
v_LOOPVAR_2D1200_9 = v_LOOPVAR_2D1202_11;
t8 = v_LOOPVAR_2D1200_9;
}
v_LOOPVAR_2D1201_10 = ICALL(s_lsp_LAST) (1, t8);
}
goto t_NEXT_2DLOOP_13;
goto t_END_2DLOOP_14;
t_END_2DLOOP_14:;
v_ALL_2DKEYS_46 = v_LOOPVAR_2D1200_9;
goto b_NIL_12;
v_ALL_2DKEYS_46 = NIL;
v_ALL_2DKEYS_46 = v_ALL_2DKEYS_46;
b_NIL_12:;
v_X_47 = LREF(s_lsp_EQUAL);
t9 = ((LP) DEREF((LREF(s_lsp_EQUAL)) + 4 * 4));
v_DUP_3F_49 = ICALL(s_lsp_DUPLICATES_3F) (2, v_ALL_2DKEYS_46, t9);
if (v_DUP_3F_49 != NIL) {
t10 = ICALL(s_lsp_WARN) (MV_CALL(argc,3), LREF(k10740), v_DUP_3F_49, v_ORIGINAL_0);
return(t10);
} else {
t12 = ICALL(s_lsp_LENGTH) (1, v_ALL_2DKEYS_46);
t11 = (greaterp((t12), ((LP) 8)));
if (t11 != NIL) {
v_X_54 = LREF(s_lsp_SYMBOLP);
t14 = ((LP) DEREF((LREF(s_lsp_SYMBOLP)) + 4 * 4));
t13 = ICALL(s_lsp_EVERY) (2, t14, v_ALL_2DKEYS_46);
if (t13 != NIL) {
t10 = ICALL(s_lsp_OPTIMIZE_2DCASE_2FSYMBOLS) (MV_CALL(argc,4), v_ALL_2DKEYS_46, v_KEY_2DFORM_1, v_SPECIFIC_2DCASES_4, v_DEFAULT_5);
return(t10);
} else {
v_X_52 = LREF(s_lsp_FIXNUMP);
t16 = ((LP) DEREF((LREF(s_lsp_FIXNUMP)) + 4 * 4));
t15 = ICALL(s_lsp_EVERY) (2, t16, v_ALL_2DKEYS_46);
if (t15 != NIL) {
t10 = ICALL(s_lsp_OPTIMIZE_2DCASE_2FFIXNUMS) (MV_CALL(argc,3), v_KEY_2DFORM_1, v_SPECIFIC_2DCASES_4, v_DEFAULT_5);
return(t10);
} else {
v_X_50 = LREF(s_lsp_CHARACTERP);
t18 = ((LP) DEREF((LREF(s_lsp_CHARACTERP)) + 4 * 4));
t17 = ICALL(s_lsp_EVERY) (2, t18, v_ALL_2DKEYS_46);
if (t17 != NIL) {
t10 = ICALL(s_lsp_OPTIMIZE_2DCASE_2FCHARS) (MV_CALL(argc,3), v_KEY_2DFORM_1, v_SPECIFIC_2DCASES_4, v_DEFAULT_5);
return(t10);
} else {
return(v_ORIGINAL_0);
}
}
}
} else {
return(v_ORIGINAL_0);
}
}
}
}

LP p_lsp_OPTIMIZE_2DCASE_2FFIXNUMS(argc, v_KEY_2DFORM_0, v_SPECIFIC_2DCASES_1, v_DEFAULT_2)
      ARGC argc;  LP v_KEY_2DFORM_0; LP v_SPECIFIC_2DCASES_1; LP v_DEFAULT_2;
{
LP v_Y_50; LP v_X_49; LP v_Y_47; 
LP v_X_46; LP v_Y_44; LP v_X_43; 
LP v_X_41; LP v_V_39; LP v_X_38; 
LP v_NEW_2DCDR_36; LP v_C_35; LP v_Y_33; 
LP v_X_32; LP v_Y_30; LP v_X_29; 
LP v_Y_27; LP v_X_26; LP v_Y_24; 
LP v_X_23; LP v_X_21; LP v_X_19; 
LP v_X_17; LP v_X_15; LP v_X_13; 
LP v_LOOPVAR_2D1206_9; LP v_LOOPVAR_2D1205_8; LP v_LOOPVAR_2D1204_7; 
LP v_LOOP_2DLIST_2D1203_6; LP v_CONSEQUENT_5; LP v_KEY_4; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; 
if (argc != 3) wna(argc,3);
v_KEY_4 = LREF(s_lsp_NIL);
v_CONSEQUENT_5 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D1203_6 = v_SPECIFIC_2DCASES_1;
v_LOOPVAR_2D1204_7 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1205_8 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1206_9 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_11:;
if (v_LOOP_2DLIST_2D1203_6 == NIL) {
goto t_END_2DLOOP_12;
}
v_X_13 = v_LOOP_2DLIST_2D1203_6;
v_X_15 = ((LP) DEREF((v_X_13) + 0 * 4));
v_KEY_4 = ((LP) DEREF((v_X_15) + 0 * 4));
v_X_17 = v_LOOP_2DLIST_2D1203_6;
v_X_19 = ((LP) DEREF((v_X_17) + 0 * 4));
v_CONSEQUENT_5 = ((LP) DEREF((v_X_19) + 1 * 4));
v_X_21 = v_LOOP_2DLIST_2D1203_6;
v_LOOP_2DLIST_2D1203_6 = ((LP) DEREF((v_X_21) + 1 * 4));
v_X_29 = v_KEY_4;
v_Y_24 = v_CONSEQUENT_5;
v_X_26 = (c_cons((LREF(s_lsp_PROGN)), (v_Y_24)));
v_Y_30 = (c_cons((v_X_26), (LREF(s_lsp_NIL))));
v_X_32 = (c_cons((v_X_29), (v_Y_30)));
v_LOOPVAR_2D1206_9 = (c_cons((v_X_32), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D1205_8 != NIL) {
v_C_35 = v_LOOPVAR_2D1205_8;
v_NEW_2DCDR_36 = v_LOOPVAR_2D1206_9;
v_V_39 = v_NEW_2DCDR_36;
((LP) (DEREF((v_C_35) + 1 * 4) = (LD) (v_V_39)));
v_X_41 = v_C_35;
v_LOOPVAR_2D1205_8 = ((LP) DEREF((v_X_41) + 1 * 4));
} else {
v_LOOPVAR_2D1204_7 = v_LOOPVAR_2D1206_9;
v_LOOPVAR_2D1205_8 = v_LOOPVAR_2D1204_7;
}
goto t_NEXT_2DLOOP_11;
goto t_END_2DLOOP_12;
t_END_2DLOOP_12:;
t2 = v_LOOPVAR_2D1204_7;
goto b_NIL_10;
t2 = NIL;
b_NIL_10:;
v_X_43 = v_DEFAULT_2;
v_Y_44 = LREF(s_lsp_NIL);
v_Y_47 = (c_cons((v_DEFAULT_2), (LREF(s_lsp_NIL))));
v_X_49 = (c_cons((LREF(s_lsp_T)), (v_Y_47)));
t3 = (c_cons((v_X_49), (LREF(s_lsp_NIL))));
t1 = ICALL(s_lsp_APPEND_2F2) (2, t2, t3);
t0 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,3), LREF(s_lsp_SWITCH), v_KEY_2DFORM_0, t1);
return(t0);
}

LP p_lsp_OPTIMIZE_2DCASE_2FCHARS(argc, v_KEY_2DFORM_0, v_SPECIFIC_2DCASES_1, v_DEFAULT_2)
      ARGC argc;  LP v_KEY_2DFORM_0; LP v_SPECIFIC_2DCASES_1; LP v_DEFAULT_2;
{
LP v_Y_172; LP v_X_171; LP v_Y_169; 
LP v_X_168; LP v_Y_166; LP v_X_165; 
LP v_Y_163; LP v_X_162; LP v_Y_160; 
LP v_X_159; LP v_Y_157; LP v_X_156; 
LP v_Y_154; LP v_X_153; LP v_Y_151; 
LP v_X_150; LP v_Y_148; LP v_X_147; 
LP v_Y_145; LP v_X_144; LP v_Y_142; 
LP v_X_141; LP v_Y_139; LP v_X_138; 
LP v_Y_136; LP v_X_135; LP v_Y_133; 
LP v_X_132; LP v_Y_130; LP v_X_129; 
LP v_Y_127; LP v_X_126; LP v_Y_124; 
LP v_X_123; LP v_Y_121; LP v_X_120; 
LP v_Y_118; LP v_X_117; LP v_Y_115; 
LP v_X_114; LP v_X_112; LP v_V_110; 
LP v_X_109; LP v_NEW_2DCDR_107; LP v_C_106; 
LP v_Y_104; LP v_X_103; LP v_Y_101; 
LP v_X_100; LP v_Y_98; LP v_X_97; 
LP v_Y_95; LP v_X_94; LP v_X_92; 
LP v_V_90; LP v_X_89; LP v_NEW_2DCDR_87; 
LP v_C_86; LP v_Y_84; LP v_X_83; 
LP v_C_81; LP v_X_79; LP v_X_77; 
LP v_LOOPVAR_2D1214_73; LP v_LOOPVAR_2D1213_72; LP v_LOOPVAR_2D1212_71; 
LP v_LOOP_2DLIST_2D1211_70; LP v_K_69; LP v_X_67; 
LP v_G5853_66; LP v_Y_64; LP v_X_63; 
LP v_X_61; LP v_X_59; LP v_Y_57; 
LP v_X_56; LP v_X_54; LP v_X_52; 
LP v_X_50; LP v_X_48; LP v_X_46; 
LP v_LOOPVAR_2D1210_42; LP v_LOOPVAR_2D1209_41; LP v_LOOPVAR_2D1208_40; 
LP v_LOOP_2DLIST_2D1207_39; LP v_CONSEQUENT_38; LP v_KEYS_37; 
LP v_Y_35; LP v_X_34; LP v_Y_32; 
LP v_X_31; LP v_Y_29; LP v_X_28; 
LP v_Y_26; LP v_X_25; LP v_Y_23; 
LP v_X_22; LP v_Y_20; LP v_X_19; 
LP v_Y_17; LP v_X_16; LP v_NAME_15; 
LP v_DEFAULT_2DTAG_14; LP v_KEY_13; LP v_X_11; 
LP v_X_10; LP v_X_8; LP v_X_7; 
LP v_X_5; LP v_X_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; LP t145; LP t146; LP t147; LP t148; LP t149; 
LP t150; LP t151; LP t152; LP t153; LP t154; LP t155; 
LP t156; LP t157; LP t158; LP t159; LP t160; LP t161; 
LP t162; LP t163; 
if (argc != 3) wna(argc,3);
v_X_5 = LREF(k10736);
v_KEY_13 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(k10736));
v_X_8 = LREF(k10741);
v_DEFAULT_2DTAG_14 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(k10741));
v_X_11 = LREF(k10742);
v_NAME_15 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(k10742));
v_X_16 = v_KEY_2DFORM_0;
v_Y_17 = LREF(s_lsp_NIL);
v_Y_20 = (c_cons((v_KEY_2DFORM_0), (LREF(s_lsp_NIL))));
v_X_22 = (c_cons((v_KEY_13), (v_Y_20)));
v_X_159 = (c_cons((v_X_22), (LREF(s_lsp_NIL))));
v_X_25 = v_KEY_13;
v_Y_26 = LREF(s_lsp_NIL);
v_Y_29 = (c_cons((v_KEY_13), (LREF(s_lsp_NIL))));
v_X_141 = (c_cons((LREF(s_lsp_CHARACTERP)), (v_Y_29)));
v_X_31 = v_KEY_13;
v_Y_32 = LREF(s_lsp_NIL);
v_Y_35 = (c_cons((v_KEY_13), (LREF(s_lsp_NIL))));
t0 = (c_cons((LREF(s_lsp__25CHAR_2DCODE)), (v_Y_35)));
v_KEYS_37 = LREF(s_lsp_NIL);
v_CONSEQUENT_38 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D1207_39 = v_SPECIFIC_2DCASES_1;
v_LOOPVAR_2D1208_40 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1209_41 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1210_42 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_44:;
if (v_LOOP_2DLIST_2D1207_39 == NIL) {
goto t_END_2DLOOP_45;
}
v_X_46 = v_LOOP_2DLIST_2D1207_39;
v_X_48 = ((LP) DEREF((v_X_46) + 0 * 4));
v_KEYS_37 = ((LP) DEREF((v_X_48) + 0 * 4));
v_X_50 = v_LOOP_2DLIST_2D1207_39;
v_X_52 = ((LP) DEREF((v_X_50) + 0 * 4));
v_CONSEQUENT_38 = ((LP) DEREF((v_X_52) + 1 * 4));
v_X_54 = v_LOOP_2DLIST_2D1207_39;
v_LOOP_2DLIST_2D1207_39 = ((LP) DEREF((v_X_54) + 1 * 4));
v_K_69 = LREF(s_lsp_NIL);
v_X_59 = v_KEYS_37;
v_X_61 = v_X_59;
v_X_63 = v_X_59;
v_Y_64 = LREF(s_lsp_NIL);
v_G5853_66 = (((v_X_59) == (LREF(s_lsp_NIL))) ? T : NIL);
if (v_G5853_66 != NIL) {
t3 = v_G5853_66;
} else {
v_X_67 = v_X_59;
t3 = (OTHER_PTRP((v_X_59)) && (TAG((v_X_59)) == 15) ? T : NIL);
}
if (t3 != NIL) {
v_LOOP_2DLIST_2D1211_70 = v_KEYS_37;
} else {
v_X_56 = v_KEYS_37;
v_LOOP_2DLIST_2D1211_70 = (c_cons((v_X_56), (LREF(s_lsp_NIL))));
}
v_LOOPVAR_2D1212_71 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1213_72 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1214_73 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_75:;
if (v_LOOP_2DLIST_2D1211_70 == NIL) {
goto t_END_2DLOOP_76;
}
v_X_77 = v_LOOP_2DLIST_2D1211_70;
v_K_69 = ((LP) DEREF((v_X_77) + 0 * 4));
v_X_79 = v_LOOP_2DLIST_2D1211_70;
v_LOOP_2DLIST_2D1211_70 = ((LP) DEREF((v_X_79) + 1 * 4));
v_C_81 = v_K_69;
v_X_83 = INT_TO_FX(((int) RAW_CHAR(v_C_81)));
v_LOOPVAR_2D1214_73 = (c_cons((v_X_83), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D1213_72 != NIL) {
v_C_86 = v_LOOPVAR_2D1213_72;
v_NEW_2DCDR_87 = v_LOOPVAR_2D1214_73;
v_V_90 = v_NEW_2DCDR_87;
((LP) (DEREF((v_C_86) + 1 * 4) = (LD) (v_V_90)));
v_X_92 = v_C_86;
v_LOOPVAR_2D1213_72 = ((LP) DEREF((v_X_92) + 1 * 4));
} else {
v_LOOPVAR_2D1212_71 = v_LOOPVAR_2D1214_73;
v_LOOPVAR_2D1213_72 = v_LOOPVAR_2D1212_71;
}
goto t_NEXT_2DLOOP_75;
goto t_END_2DLOOP_76;
t_END_2DLOOP_76:;
v_X_100 = v_LOOPVAR_2D1212_71;
goto b_NIL_74;
v_X_100 = NIL;
v_X_100 = v_X_100;
b_NIL_74:;
v_Y_95 = v_CONSEQUENT_38;
v_X_97 = (c_cons((LREF(s_lsp_PROGN)), (v_Y_95)));
v_Y_101 = (c_cons((v_X_97), (LREF(s_lsp_NIL))));
v_X_103 = (c_cons((v_X_100), (v_Y_101)));
v_LOOPVAR_2D1210_42 = (c_cons((v_X_103), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D1209_41 != NIL) {
v_C_106 = v_LOOPVAR_2D1209_41;
v_NEW_2DCDR_107 = v_LOOPVAR_2D1210_42;
v_V_110 = v_NEW_2DCDR_107;
((LP) (DEREF((v_C_106) + 1 * 4) = (LD) (v_V_110)));
v_X_112 = v_C_106;
v_LOOPVAR_2D1209_41 = ((LP) DEREF((v_X_112) + 1 * 4));
} else {
v_LOOPVAR_2D1208_40 = v_LOOPVAR_2D1210_42;
v_LOOPVAR_2D1209_41 = v_LOOPVAR_2D1208_40;
}
goto t_NEXT_2DLOOP_44;
goto t_END_2DLOOP_45;
t_END_2DLOOP_45:;
t2 = v_LOOPVAR_2D1208_40;
goto b_NIL_43;
t2 = NIL;
b_NIL_43:;
v_X_114 = v_DEFAULT_2DTAG_14;
v_Y_115 = LREF(s_lsp_NIL);
v_Y_118 = (c_cons((v_DEFAULT_2DTAG_14), (LREF(s_lsp_NIL))));
v_X_120 = (c_cons((LREF(s_lsp_GO)), (v_Y_118)));
v_Y_124 = (c_cons((v_X_120), (LREF(s_lsp_NIL))));
v_X_126 = (c_cons((LREF(s_lsp_T)), (v_Y_124)));
t4 = (c_cons((v_X_126), (LREF(s_lsp_NIL))));
t1 = ICALL(s_lsp_APPEND_2F2) (2, t2, t4);
v_X_129 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_SWITCH), t0, t1);
v_Y_133 = (c_cons((v_X_129), (LREF(s_lsp_NIL))));
v_Y_136 = (c_cons((v_NAME_15), (v_Y_133)));
v_X_138 = (c_cons((LREF(s_lsp_RETURN_2DFROM)), (v_Y_136)));
v_Y_142 = (c_cons((v_X_138), (LREF(s_lsp_NIL))));
v_Y_145 = (c_cons((v_X_141), (v_Y_142)));
t5 = (c_cons((LREF(s_lsp_WHEN)), (v_Y_145)));
v_X_147 = v_DEFAULT_2;
v_Y_148 = LREF(s_lsp_NIL);
v_Y_151 = (c_cons((v_DEFAULT_2), (LREF(s_lsp_NIL))));
v_Y_154 = (c_cons((v_NAME_15), (v_Y_151)));
t6 = (c_cons((LREF(s_lsp_RETURN_2DFROM)), (v_Y_154)));
v_X_156 = ICALL(s_lsp_LIST) (4, LREF(s_lsp_TAGBODY), t5, v_DEFAULT_2DTAG_14, t6);
v_Y_160 = (c_cons((v_X_156), (LREF(s_lsp_NIL))));
v_Y_163 = (c_cons((v_X_159), (v_Y_160)));
v_X_165 = (c_cons((LREF(s_lsp_LET)), (v_Y_163)));
v_Y_169 = (c_cons((v_X_165), (LREF(s_lsp_NIL))));
v_Y_172 = (c_cons((v_NAME_15), (v_Y_169)));
t7 = (c_cons((LREF(s_lsp_BLOCK)), (v_Y_172)));
return(t7);
}

LP p_lsp_OPTIMIZE_2DCASE_2FSYMBOLS(argc, v_ALL_2DKEYS_0, v_KEY_2DFORM_1, v_SPECIFIC_2DCASES_2, v_DEFAULT_3)
      ARGC argc;  LP v_ALL_2DKEYS_0; LP v_KEY_2DFORM_1; LP v_SPECIFIC_2DCASES_2; LP v_DEFAULT_3;
{
LP v_Y_170; LP v_X_169; LP v_Y_167; 
LP v_X_166; LP v_Y_164; LP v_X_163; 
LP v_Y_161; LP v_X_160; LP v_Y_158; 
LP v_X_157; LP v_Y_155; LP v_X_154; 
LP v_Y_152; LP v_X_151; LP v_Y_149; 
LP v_X_148; LP v_Y_146; LP v_X_145; 
LP v_Y_143; LP v_X_142; LP v_Y_140; 
LP v_X_139; LP v_Y_137; LP v_X_136; 
LP v_Y_134; LP v_X_133; LP v_Y_131; 
LP v_X_130; LP v_Y_128; LP v_X_127; 
LP v_Y_125; LP v_X_124; LP v_Y_122; 
LP v_X_121; LP v_Y_119; LP v_X_118; 
LP v_Y_116; LP v_X_115; LP v_Y_113; 
LP v_X_112; LP v_X_110; LP v_V_108; 
LP v_X_107; LP v_NEW_2DCDR_105; LP v_C_104; 
LP v_Y_102; LP v_X_101; LP v_Y_99; 
LP v_X_98; LP v_Y_96; LP v_X_95; 
LP v_Y_93; LP v_X_92; LP v_Y_90; 
LP v_X_89; LP v_Y_87; LP v_X_86; 
LP v_Y_84; LP v_X_83; LP v_Y_81; 
LP v_X_80; LP v_Y_78; LP v_X_77; 
LP v_Y_75; LP v_X_74; LP v_Y_72; 
LP v_X_71; LP v_X_69; LP v_X_67; 
LP v_X_65; LP v_X_63; LP v_X_61; 
LP v_X_59; LP v_LOOPVAR_2D1218_55; LP v_LOOPVAR_2D1217_54; 
LP v_LOOPVAR_2D1216_53; LP v_LOOP_2DLIST_2D1215_52; LP v_CONSEQUENT_51; 
LP v_SYM_50; LP v_Y_48; LP v_X_47; 
LP v_Y_45; LP v_X_44; LP v_Y_42; 
LP v_X_41; LP v_Y_39; LP v_X_38; 
LP v_Y_36; LP v_X_35; LP v_Y_33; 
LP v_X_32; LP v_Y_30; LP v_X_29; 
LP v_Y_27; LP v_X_26; LP v_Y_24; 
LP v_X_23; LP v_Y_21; LP v_X_20; 
LP v_MULTI_2DCONSEQUENTS_19; LP v_FLAT_2DCASES_18; LP v_NAME_17; 
LP v_DEFAULT_2DTAG_16; LP v_KEY_15; LP v_NO_2DCOLLISION_2DSIZE_14; 
LP v_X_12; LP v_X_11; LP v_X_9; 
LP v_X_8; LP v_X_6; LP v_X_5; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; LP t145; LP t146; LP t147; LP t148; LP t149; 
LP t150; LP t151; LP t152; LP t153; LP t154; LP t155; 
LP t156; LP t157; LP t158; LP t159; LP t160; LP t161; 
LP t162; LP t163; LP t164; LP t165; LP t166; LP t167; 
LP t168; 
if (argc != 4) wna(argc,4);
v_NO_2DCOLLISION_2DSIZE_14 = ICALL(s_lsp_NO_2DCOLLISION_2DHASH_2DSIZE) (1, v_ALL_2DKEYS_0);
v_X_6 = LREF(k10736);
v_KEY_15 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(k10736));
v_X_9 = LREF(k10741);
v_DEFAULT_2DTAG_16 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(k10741));
v_X_12 = LREF(k10742);
v_NAME_17 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(k10742));
{
int real_argc;
BEGIN_MV_CALL(mv_holder10743,0);
t0 = ICALL(s_lsp_FLATTEN_2DMULTI_2DCASES) (MV_CALL(mv_holder10743,2), v_SPECIFIC_2DCASES_2, v_NAME_17);
SET_MV_RETURN_VALUE(mv_holder10743,0,t0);
if SV_RETURN_P(mv_holder10743) SET_MV_RETURN_COUNT(mv_holder10743,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder10743);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_FLAT_2DCASES_18 = NIL;
} else {
v_FLAT_2DCASES_18 = NEXT_VAR_VALUE(mv_holder10743);
}
if (real_argc < 2) {
v_MULTI_2DCONSEQUENTS_19 = NIL;
} else {
v_MULTI_2DCONSEQUENTS_19 = NEXT_VAR_VALUE(mv_holder10743);
}
END_VAR_VALUES;
END_MV_CALL;
v_X_20 = v_KEY_2DFORM_1;
v_Y_21 = LREF(s_lsp_NIL);
v_Y_24 = (c_cons((v_KEY_2DFORM_1), (LREF(s_lsp_NIL))));
v_X_26 = (c_cons((v_KEY_15), (v_Y_24)));
v_X_157 = (c_cons((v_X_26), (LREF(s_lsp_NIL))));
v_X_29 = v_KEY_15;
v_Y_30 = LREF(s_lsp_NIL);
v_Y_33 = (c_cons((v_KEY_15), (LREF(s_lsp_NIL))));
v_X_139 = (c_cons((LREF(s_lsp_SYMBOLP)), (v_Y_33)));
v_X_35 = v_KEY_15;
v_Y_36 = LREF(s_lsp_NIL);
v_Y_39 = (c_cons((v_KEY_15), (LREF(s_lsp_NIL))));
v_X_44 = (c_cons((LREF(s_lsp_SYMBOL_2DHASH_2DCODE)), (v_Y_39)));
v_X_41 = v_NO_2DCOLLISION_2DSIZE_14;
v_Y_42 = LREF(s_lsp_NIL);
v_Y_45 = (c_cons((v_NO_2DCOLLISION_2DSIZE_14), (LREF(s_lsp_NIL))));
v_Y_48 = (c_cons((v_X_44), (v_Y_45)));
t1 = (c_cons((LREF(s_lsp__25REM)), (v_Y_48)));
v_SYM_50 = LREF(s_lsp_NIL);
v_CONSEQUENT_51 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D1215_52 = v_FLAT_2DCASES_18;
v_LOOPVAR_2D1216_53 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1217_54 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1218_55 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_57:;
if (v_LOOP_2DLIST_2D1215_52 == NIL) {
goto t_END_2DLOOP_58;
}
v_X_59 = v_LOOP_2DLIST_2D1215_52;
v_X_61 = ((LP) DEREF((v_X_59) + 0 * 4));
v_SYM_50 = ((LP) DEREF((v_X_61) + 0 * 4));
v_X_63 = v_LOOP_2DLIST_2D1215_52;
v_X_65 = ((LP) DEREF((v_X_63) + 0 * 4));
v_CONSEQUENT_51 = ((LP) DEREF((v_X_65) + 1 * 4));
v_X_67 = v_LOOP_2DLIST_2D1215_52;
v_LOOP_2DLIST_2D1215_52 = ((LP) DEREF((v_X_67) + 1 * 4));
v_X_69 = v_SYM_50;
t4 = ICALL(s_lsp_SXHASH) (1, v_X_69);
v_X_98 = ICALL(s_lsp_REM) (2, t4, v_NO_2DCOLLISION_2DSIZE_14);
v_X_71 = v_SYM_50;
v_Y_75 = (c_cons((v_X_71), (LREF(s_lsp_NIL))));
v_X_77 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_75)));
v_Y_81 = (c_cons((v_X_77), (LREF(s_lsp_NIL))));
v_Y_84 = (c_cons((v_KEY_15), (v_Y_81)));
t5 = (c_cons((LREF(s_lsp_EQ)), (v_Y_84)));
v_Y_87 = v_CONSEQUENT_51;
t6 = (c_cons((LREF(s_lsp_PROGN)), (v_Y_87)));
v_X_89 = v_DEFAULT_2DTAG_16;
v_Y_90 = LREF(s_lsp_NIL);
v_Y_93 = (c_cons((v_DEFAULT_2DTAG_16), (LREF(s_lsp_NIL))));
t7 = (c_cons((LREF(s_lsp_GO)), (v_Y_93)));
v_X_95 = ICALL(s_lsp_LIST) (4, LREF(s_lsp_IF), t5, t6, t7);
v_Y_99 = (c_cons((v_X_95), (LREF(s_lsp_NIL))));
v_X_101 = (c_cons((v_X_98), (v_Y_99)));
v_LOOPVAR_2D1218_55 = (c_cons((v_X_101), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D1217_54 != NIL) {
v_C_104 = v_LOOPVAR_2D1217_54;
v_NEW_2DCDR_105 = v_LOOPVAR_2D1218_55;
v_V_108 = v_NEW_2DCDR_105;
((LP) (DEREF((v_C_104) + 1 * 4) = (LD) (v_V_108)));
v_X_110 = v_C_104;
v_LOOPVAR_2D1217_54 = ((LP) DEREF((v_X_110) + 1 * 4));
} else {
v_LOOPVAR_2D1216_53 = v_LOOPVAR_2D1218_55;
v_LOOPVAR_2D1217_54 = v_LOOPVAR_2D1216_53;
}
goto t_NEXT_2DLOOP_57;
goto t_END_2DLOOP_58;
t_END_2DLOOP_58:;
t3 = v_LOOPVAR_2D1216_53;
goto b_NIL_56;
t3 = NIL;
b_NIL_56:;
v_X_112 = v_DEFAULT_2DTAG_16;
v_Y_113 = LREF(s_lsp_NIL);
v_Y_116 = (c_cons((v_DEFAULT_2DTAG_16), (LREF(s_lsp_NIL))));
v_X_118 = (c_cons((LREF(s_lsp_GO)), (v_Y_116)));
v_Y_122 = (c_cons((v_X_118), (LREF(s_lsp_NIL))));
v_X_124 = (c_cons((LREF(s_lsp_T)), (v_Y_122)));
t8 = (c_cons((v_X_124), (LREF(s_lsp_NIL))));
t2 = ICALL(s_lsp_APPEND_2F2) (2, t3, t8);
v_X_127 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_SWITCH), t1, t2);
v_Y_131 = (c_cons((v_X_127), (LREF(s_lsp_NIL))));
v_Y_134 = (c_cons((v_NAME_17), (v_Y_131)));
v_X_136 = (c_cons((LREF(s_lsp_RETURN_2DFROM)), (v_Y_134)));
v_Y_140 = (c_cons((v_X_136), (LREF(s_lsp_NIL))));
v_Y_143 = (c_cons((v_X_139), (v_Y_140)));
t9 = (c_cons((LREF(s_lsp_WHEN)), (v_Y_143)));
v_X_145 = v_DEFAULT_3;
v_Y_146 = LREF(s_lsp_NIL);
v_Y_149 = (c_cons((v_DEFAULT_3), (LREF(s_lsp_NIL))));
v_Y_152 = (c_cons((v_NAME_17), (v_Y_149)));
t10 = (c_cons((LREF(s_lsp_RETURN_2DFROM)), (v_Y_152)));
v_X_154 = ICALL(s_lsp_LIST_2A) (5, LREF(s_lsp_TAGBODY), t9, v_DEFAULT_2DTAG_16, t10, v_MULTI_2DCONSEQUENTS_19);
v_Y_158 = (c_cons((v_X_154), (LREF(s_lsp_NIL))));
v_Y_161 = (c_cons((v_X_157), (v_Y_158)));
v_X_163 = (c_cons((LREF(s_lsp_LET)), (v_Y_161)));
v_Y_167 = (c_cons((v_X_163), (LREF(s_lsp_NIL))));
v_Y_170 = (c_cons((v_NAME_17), (v_Y_167)));
t11 = (c_cons((LREF(s_lsp_BLOCK)), (v_Y_170)));
return(t11);
}
}

LP p_lsp_FLATTEN_2DMULTI_2DCASES(argc, v_SPECIFIC_2DCASES_0, v_BLOCK_2DNAME_1)
      ARGC argc;  LP v_SPECIFIC_2DCASES_0; LP v_BLOCK_2DNAME_1;
{
LP f_DOIT_3; 
LP t0; LP t1; LP t2; LP t3; 
if (argc != 2) wna(argc,2);
t0 = NEW_OE(2);
SET_OE_SLOT(t0,1,v_BLOCK_2DNAME_1);
t1 = MAKE_CLOSURE(p_lsp_FLATTEN_2DMULTI_2DCASES_2DDOIT10744,t0);
f_DOIT_3 = t1;
SET_OE_SLOT(t0,0,f_DOIT_3);
t2 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(MV_CALL(argc,3), v_SPECIFIC_2DCASES_0, LREF(s_lsp_NIL), LREF(s_lsp_NIL));
return(t2);
}

LP p_lsp_FLATTEN_2DMULTI_2DCASES_2DDOIT10744(argc, v_REST_0, v_FLAT_2DCASES_1, v_MULTI_2DCONSEQUENTS_2)
      ARGC argc;  LP v_REST_0; LP v_FLAT_2DCASES_1; LP v_MULTI_2DCONSEQUENTS_2;
{
LP v_X_103; LP v_G5859_102; LP v_Y_100; 
LP v_X_99; LP v_X_97; LP v_X_95; 
LP v_Y_93; LP v_X_92; LP v_Y_90; 
LP v_X_89; LP v_X_87; LP v_G5858_86; 
LP v_Y_84; LP v_X_83; LP v_X_81; 
LP v_X_79; LP v_X_77; LP v_X_75; 
LP v_Y_73; LP v_X_72; LP v_Y_70; 
LP v_X_69; LP v_Y_67; LP v_X_66; 
LP v_Y_64; LP v_X_63; LP v_Y_61; 
LP v_X_60; LP v_Y_58; LP v_X_57; 
LP v_X_55; LP v_V_53; LP v_X_52; 
LP v_NEW_2DCDR_50; LP v_C_49; LP v_Y_47; 
LP v_X_46; LP v_Y_44; LP v_X_43; 
LP v_Y_41; LP v_X_40; LP v_Y_38; 
LP v_X_37; LP v_Y_35; LP v_X_34; 
LP v_X_32; LP v_X_30; LP v_LOOPVAR_2D1222_26; 
LP v_LOOPVAR_2D1221_25; LP v_LOOPVAR_2D1220_24; LP v_LOOP_2DLIST_2D1219_23; 
LP v_K_22; LP v_X_20; LP v_TAG_19; 
LP v_X_17; LP v_X_16; LP v_CONSEQUENT_15; 
LP v_KEY_14; LP v_S5857_13; LP v_X_11; 
LP v_VALUE5856_10; LP v_X_8; LP v_LIST5855_7; 
LP v_L5854_6; LP v_X_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; 
if (argc != 3) wna(argc,3);
t0 = OE;
if (v_REST_0 != NIL) {
v_X_4 = v_REST_0;
v_L5854_6 = ((LP) DEREF((v_REST_0) + 0 * 4));
v_LIST5855_7 = v_L5854_6;
v_X_8 = v_LIST5855_7;
v_VALUE5856_10 = ((LP) DEREF((v_LIST5855_7) + 0 * 4));
v_X_11 = v_LIST5855_7;
v_S5857_13 = ((LP) DEREF((v_LIST5855_7) + 1 * 4));
v_L5854_6 = v_S5857_13;
v_KEY_14 = v_VALUE5856_10;
v_CONSEQUENT_15 = v_L5854_6;
v_X_95 = v_KEY_14;
v_X_97 = v_X_95;
v_X_99 = v_X_95;
v_Y_100 = LREF(s_lsp_NIL);
v_G5859_102 = (((v_X_95) == (LREF(s_lsp_NIL))) ? T : NIL);
if (v_G5859_102 != NIL) {
t3 = v_G5859_102;
} else {
v_X_103 = v_X_95;
t3 = (OTHER_PTRP((v_X_95)) && (TAG((v_X_95)) == 15) ? T : NIL);
}
if (t3 != NIL) {
t4 = ICALL(s_lsp_LENGTH) (1, v_KEY_14);
t2 = (greaterp((t4), ((LP) 2)));
} else {
t2 = LREF(s_lsp_NIL);
}
if (t2 != NIL) {
v_X_17 = LREF(k10745);
v_TAG_19 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(k10745));
v_X_20 = v_REST_0;
t5 = ((LP) DEREF((v_REST_0) + 1 * 4));
v_K_22 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D1219_23 = v_KEY_14;
v_LOOPVAR_2D1220_24 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1221_25 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1222_26 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_28:;
if (v_LOOP_2DLIST_2D1219_23 == NIL) {
goto t_END_2DLOOP_29;
}
v_X_30 = v_LOOP_2DLIST_2D1219_23;
v_K_22 = ((LP) DEREF((v_X_30) + 0 * 4));
v_X_32 = v_LOOP_2DLIST_2D1219_23;
v_LOOP_2DLIST_2D1219_23 = ((LP) DEREF((v_X_32) + 1 * 4));
v_X_43 = v_K_22;
v_X_34 = v_TAG_19;
v_Y_35 = LREF(s_lsp_NIL);
v_Y_38 = (c_cons((v_TAG_19), (LREF(s_lsp_NIL))));
v_X_40 = (c_cons((LREF(s_lsp_GO)), (v_Y_38)));
v_Y_44 = (c_cons((v_X_40), (LREF(s_lsp_NIL))));
v_X_46 = (c_cons((v_X_43), (v_Y_44)));
v_LOOPVAR_2D1222_26 = (c_cons((v_X_46), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D1221_25 != NIL) {
v_C_49 = v_LOOPVAR_2D1221_25;
v_NEW_2DCDR_50 = v_LOOPVAR_2D1222_26;
v_V_53 = v_NEW_2DCDR_50;
((LP) (DEREF((v_C_49) + 1 * 4) = (LD) (v_V_53)));
v_X_55 = v_C_49;
v_LOOPVAR_2D1221_25 = ((LP) DEREF((v_X_55) + 1 * 4));
} else {
v_LOOPVAR_2D1220_24 = v_LOOPVAR_2D1222_26;
v_LOOPVAR_2D1221_25 = v_LOOPVAR_2D1220_24;
}
goto t_NEXT_2DLOOP_28;
goto t_END_2DLOOP_29;
t_END_2DLOOP_29:;
t7 = v_LOOPVAR_2D1220_24;
goto b_NIL_27;
t7 = NIL;
b_NIL_27:;
t6 = ICALL(s_lsp_APPEND_2F2) (2, t7, v_FLAT_2DCASES_1);
v_X_57 = LREF(s_lsp_PROGN);
v_Y_58 = v_CONSEQUENT_15;
v_X_60 = (c_cons((LREF(s_lsp_PROGN)), (v_CONSEQUENT_15)));
v_Y_64 = (c_cons((v_X_60), (LREF(s_lsp_NIL))));
v_Y_67 = (c_cons((GET_OE_SLOT(t0,1)), (v_Y_64)));
v_X_69 = (c_cons((LREF(s_lsp_RETURN_2DFROM)), (v_Y_67)));
v_Y_73 = (c_cons((v_X_69), (LREF(s_lsp_NIL))));
t9 = (c_cons((v_TAG_19), (v_Y_73)));
t8 = ICALL(s_lsp_APPEND_2F2) (2, t9, v_MULTI_2DCONSEQUENTS_2);
t1 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(MV_CALL(argc,3), t5, t6, t8);
return(t1);
} else {
v_X_75 = v_REST_0;
t10 = ((LP) DEREF((v_REST_0) + 1 * 4));
v_X_79 = v_KEY_14;
v_X_81 = v_X_79;
v_X_83 = v_X_79;
v_Y_84 = LREF(s_lsp_NIL);
v_G5858_86 = (((v_X_79) == (LREF(s_lsp_NIL))) ? T : NIL);
if (v_G5858_86 != NIL) {
t11 = v_G5858_86;
} else {
v_X_87 = v_X_79;
t11 = (OTHER_PTRP((v_X_79)) && (TAG((v_X_79)) == 15) ? T : NIL);
}
if (t11 != NIL) {
v_X_77 = v_KEY_14;
v_X_89 = ((LP) DEREF((v_KEY_14) + 0 * 4));
} else {
v_X_89 = v_KEY_14;
}
v_X_92 = (c_cons((v_X_89), (v_CONSEQUENT_15)));
t12 = (c_cons((v_X_92), (v_FLAT_2DCASES_1)));
t1 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(MV_CALL(argc,3), t10, t12, v_MULTI_2DCONSEQUENTS_2);
return(t1);
}
} else {
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,v_MULTI_2DCONSEQUENTS_2);
}
return(v_FLAT_2DCASES_1);
}
}

LP p_lsp_OPTIMIZE_2DTYPECASE(argc, v_ORIGINAL_0, v_KEY_2DFORM_1, v_CASES_2)
      ARGC argc;  LP v_ORIGINAL_0; LP v_KEY_2DFORM_1; LP v_CASES_2;
{
LP v_X_24; LP v_X_22; LP v_C_20; 
LP v_Y_18; LP v_X_17; LP v_X_15; 
LP v_X_13; LP v_C_11; LP v_X_9; 
LP v_REV_8; LP f_CLASSIFY_7; LP f_ADD_2DCASE_6; 
LP f_FAIL_5; LP v_DEFAULT_4; LP v_SPECIFIC_2DCASES_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; 
if (argc != 3) wna(argc,3);
t0 = NEW_OE(6);
SET_OE_SLOT(t0,5,v_ORIGINAL_0);
SET_OE_SLOT(t0,3,v_KEY_2DFORM_1);
BEGIN_CATCH(LREF(s_lsp_OPTIMIZE_2DTYPECASE1231),argc);
{
int real_argc;
BEGIN_MV_CALL(mv_holder10751,0);
v_REV_8 = ICALL(s_lsp_REVERSE) (1, v_CASES_2);
v_C_20 = v_REV_8;
v_X_22 = v_REV_8;
v_X_24 = ((LP) DEREF((v_REV_8) + 0 * 4));
t4 = ((LP) DEREF((v_X_24) + 0 * 4));
t3 = ICALL(s_lsp_MEMQL) (2, t4, LREF(k10738));
if (t3 != NIL) {
v_X_9 = v_REV_8;
t6 = ((LP) DEREF((v_REV_8) + 1 * 4));
t5 = ICALL(s_lsp_REVERSE) (1, t6);
v_C_11 = v_REV_8;
v_X_13 = v_REV_8;
v_X_15 = ((LP) DEREF((v_REV_8) + 0 * 4));
v_Y_18 = ((LP) DEREF((v_X_15) + 1 * 4));
t7 = (c_cons((LREF(s_lsp_PROGN)), (v_Y_18)));
SET_MV_RETURN_FLAG(mv_holder10751);
SET_MV_RETURN_COUNT(mv_holder10751,2);
SET_MV_RETURN_VALUE(mv_holder10751,1,t7);
t2 = t5;
} else {
SET_MV_RETURN_FLAG(mv_holder10751);
SET_MV_RETURN_COUNT(mv_holder10751,2);
SET_MV_RETURN_VALUE(mv_holder10751,1,LREF(s_lsp_NIL));
t2 = v_CASES_2;
}
SET_MV_RETURN_VALUE(mv_holder10751,0,t2);
if SV_RETURN_P(mv_holder10751) SET_MV_RETURN_COUNT(mv_holder10751,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder10751);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_SPECIFIC_2DCASES_3 = NIL;
} else {
v_SPECIFIC_2DCASES_3 = NEXT_VAR_VALUE(mv_holder10751);
}
if (real_argc < 2) {
v_DEFAULT_4 = NIL;
} else {
v_DEFAULT_4 = NEXT_VAR_VALUE(mv_holder10751);
}
END_VAR_VALUES;
END_MV_CALL;
SET_OE_SLOT(t0,2,v_DEFAULT_4);
t8 = MAKE_CLOSURE(p_lsp_OPTIMIZE_2DTYPECASE_2DFAIL10752,t0);
f_FAIL_5 = t8;
f_ADD_2DCASE_6 = LREF(k10755);
t9 = MAKE_CLOSURE(p_lsp_OPTIMIZE_2DTYPECASE_2DCLASSIFY10754,t0);
f_CLASSIFY_7 = t9;
SET_OE_SLOT(t0,4,f_FAIL_5);
SET_OE_SLOT(t0,1,f_ADD_2DCASE_6);
SET_OE_SLOT(t0,0,f_CLASSIFY_7);
t10 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(MV_CALL(argc,5), v_SPECIFIC_2DCASES_3, LREF(s_lsp_NIL), LREF(s_lsp_NIL), LREF(s_lsp_NIL), LREF(s_lsp_NIL));
}
t1 = t10;
END_CATCH(t1);
return(t1);
}

LP p_lsp_OPTIMIZE_2DTYPECASE_2DCLASSIFY10754(argc, v_REST_0, v_FIXNUM_1, v_STRUCTURE_2, v_STRUCTURE_2DCASES_3, v_OTHERS_4)
      ARGC argc;  LP v_REST_0; LP v_FIXNUM_1; LP v_STRUCTURE_2; LP v_STRUCTURE_2DCASES_3; LP v_OTHERS_4;
{
LP v_Y_136; LP v_X_135; LP v_Y_133; 
LP v_X_132; LP v_X_130; LP v_X_128; 
LP v_Y_126; LP v_X_125; LP v_X_123; 
LP v_Y_121; LP v_X_120; LP v_X_118; 
LP v_X_116; LP v_X_114; LP v_INFO_113; 
LP v_X_111; LP v_TYPE_2DCODES_110; LP v_TYPE_109; 
LP v_X_107; LP v_G5873_106; LP v_Y_104; 
LP v_X_103; LP v_X_101; LP v_X_99; 
LP v_Y_97; LP v_X_96; LP v_MEXP_2DTYPE_95; 
LP v_CONSEQUENTS_94; LP v_SOURCE_2DTYPE_93; LP v_S5872_92; 
LP v_X_90; LP v_VALUE5871_89; LP v_X_87; 
LP v_LIST5870_86; LP v_L5869_85; LP v_X_83; 
LP v_Y_81; LP v_X_80; LP v_X_78; 
LP v_Y_76; LP v_X_75; LP v_X_73; 
LP v_Y_71; LP v_X_70; LP v_X_68; 
LP v_G5868_67; LP v_X_65; LP v_G5867_64; 
LP v_X_62; LP v_ALL_2DOTHERS_61; LP v_ALL_2DSTRUCTS_60; 
LP v_X_58; LP v_V_56; LP v_X_55; 
LP v_NEW_2DCDR_53; LP v_C_52; LP v_X_50; 
LP v_X_48; LP v_X_46; LP v_X_44; 
LP v_X_42; LP v_LOOPVAR_2D1239_38; LP v_LOOPVAR_2D1238_37; 
LP v_LOOPVAR_2D1237_36; LP v_LOOP_2DLIST_2D1236_35; LP v_CONSEQUENT_34; 
LP v_TYPES_33; LP v_X_31; LP v_V_29; 
LP v_X_28; LP v_NEW_2DCDR_26; LP v_C_25; 
LP v_X_23; LP v_X_21; LP v_X_19; 
LP v_X_17; LP v_X_15; LP v_LOOPVAR_2D1235_11; 
LP v_LOOPVAR_2D1234_10; LP v_LOOPVAR_2D1233_9; LP v_LOOP_2DLIST_2D1232_8; 
LP v_CONSEQUENT_7; LP v_NAMES_6; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; LP t145; LP t146; LP t147; LP t148; LP t149; 
LP t150; LP t151; LP t152; LP t153; LP t154; LP t155; 
LP t156; LP t157; LP t158; LP t159; 
if (argc != 5) wna(argc,5);
t0 = OE;
if (v_REST_0 != NIL) {
v_X_83 = v_REST_0;
v_L5869_85 = ((LP) DEREF((v_REST_0) + 0 * 4));
v_LIST5870_86 = v_L5869_85;
v_X_87 = v_LIST5870_86;
v_VALUE5871_89 = ((LP) DEREF((v_LIST5870_86) + 0 * 4));
v_X_90 = v_LIST5870_86;
v_S5872_92 = ((LP) DEREF((v_LIST5870_86) + 1 * 4));
v_L5869_85 = v_S5872_92;
v_SOURCE_2DTYPE_93 = v_VALUE5871_89;
v_CONSEQUENTS_94 = v_L5869_85;
v_MEXP_2DTYPE_95 = ICALL(s_lsp_TYPE_2DMACROEXPAND) (1, v_SOURCE_2DTYPE_93);
v_X_99 = v_MEXP_2DTYPE_95;
v_X_101 = v_X_99;
v_X_103 = v_X_99;
v_Y_104 = LREF(s_lsp_NIL);
v_G5873_106 = (((v_X_99) == (LREF(s_lsp_NIL))) ? T : NIL);
if (v_G5873_106 != NIL) {
t2 = v_G5873_106;
} else {
v_X_107 = v_X_99;
t2 = (OTHER_PTRP((v_X_99)) && (TAG((v_X_99)) == 15) ? T : NIL);
}
if (t2 != NIL) {
v_TYPE_109 = v_MEXP_2DTYPE_95;
} else {
v_X_96 = v_MEXP_2DTYPE_95;
v_Y_97 = LREF(s_lsp_NIL);
v_TYPE_109 = (c_cons((v_MEXP_2DTYPE_95), (LREF(s_lsp_NIL))));
}
v_TYPE_2DCODES_110 = ICALL(s_lsp_TYPE_2D_3ETYPE_2DCODES) (1, v_TYPE_109);
if (v_TYPE_2DCODES_110 != NIL) {
v_X_135 = v_TYPE_2DCODES_110;
v_Y_136 = LREF(s_key_FIXNUM);
if (((v_TYPE_2DCODES_110) == (LREF(s_key_FIXNUM)))) {
v_X_123 = v_REST_0;
t4 = ((LP) DEREF((v_REST_0) + 1 * 4));
v_X_125 = LREF(s_lsp_PROGN);
v_Y_126 = v_CONSEQUENTS_94;
t5 = (c_cons((LREF(s_lsp_PROGN)), (v_CONSEQUENTS_94)));
t1 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(MV_CALL(argc,5), t4, t5, v_STRUCTURE_2, v_STRUCTURE_2DCASES_3, v_OTHERS_4);
return(t1);
} else {
v_X_132 = v_TYPE_2DCODES_110;
v_Y_133 = LREF(s_key_STRUCTURE);
if (((v_TYPE_2DCODES_110) == (LREF(s_key_STRUCTURE)))) {
v_X_128 = v_REST_0;
t7 = ((LP) DEREF((v_REST_0) + 1 * 4));
t8 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,1)))(3, (LP) 94, v_CONSEQUENTS_94, v_STRUCTURE_2);
t1 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(MV_CALL(argc,5), t7, v_FIXNUM_1, t8, v_STRUCTURE_2DCASES_3, v_OTHERS_4);
return(t1);
} else {
v_X_130 = v_REST_0;
t9 = ((LP) DEREF((v_REST_0) + 1 * 4));
t10 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,1)))(3, v_TYPE_2DCODES_110, v_CONSEQUENTS_94, v_OTHERS_4);
t1 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(MV_CALL(argc,5), t9, v_FIXNUM_1, v_STRUCTURE_2, v_STRUCTURE_2DCASES_3, t10);
return(t1);
}
}
} else {
v_X_111 = v_TYPE_109;
t11 = ((LP) DEREF((v_TYPE_109) + 0 * 4));
v_INFO_113 = ICALL(s_lsp_LOOKUP_2DSTRUCTURE_2DINFO) (1, t11);
if (v_INFO_113 != NIL) {
v_X_114 = v_REST_0;
t12 = ((LP) DEREF((v_REST_0) + 1 * 4));
v_X_116 = v_TYPE_109;
v_X_120 = ((LP) DEREF((v_TYPE_109) + 0 * 4));
v_X_118 = v_TYPE_109;
t14 = ((LP) DEREF((v_TYPE_109) + 0 * 4));
v_Y_121 = ICALL(s_lsp_ALL_2DCURRENT_2DSTRUCTURE_2DCHILDREN) (1, t14);
t15 = (c_cons((v_X_120), (v_Y_121)));
t13 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,1)))(3, t15, v_CONSEQUENTS_94, v_STRUCTURE_2DCASES_3);
t1 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(MV_CALL(argc,5), t12, v_FIXNUM_1, v_STRUCTURE_2, t13, v_OTHERS_4);
return(t1);
} else {
t1 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,4)))(MV_CALL(argc,0));
return(t1);
}
}
} else {
v_NAMES_6 = LREF(s_lsp_NIL);
v_CONSEQUENT_7 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D1232_8 = v_STRUCTURE_2DCASES_3;
v_LOOPVAR_2D1233_9 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1234_10 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1235_11 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_13:;
if (v_LOOP_2DLIST_2D1232_8 == NIL) {
goto t_END_2DLOOP_14;
}
v_X_15 = v_LOOP_2DLIST_2D1232_8;
v_X_17 = ((LP) DEREF((v_X_15) + 0 * 4));
v_NAMES_6 = ((LP) DEREF((v_X_17) + 0 * 4));
v_X_19 = v_LOOP_2DLIST_2D1232_8;
v_X_21 = ((LP) DEREF((v_X_19) + 0 * 4));
v_CONSEQUENT_7 = ((LP) DEREF((v_X_21) + 1 * 4));
v_X_23 = v_LOOP_2DLIST_2D1232_8;
v_LOOP_2DLIST_2D1232_8 = ((LP) DEREF((v_X_23) + 1 * 4));
v_LOOPVAR_2D1235_11 = ICALL(s_lsp_COPY_2DLIST) (1, v_NAMES_6);
if (v_LOOPVAR_2D1235_11 != NIL) {
if (v_LOOPVAR_2D1234_10 != NIL) {
v_C_25 = v_LOOPVAR_2D1234_10;
v_NEW_2DCDR_26 = v_LOOPVAR_2D1235_11;
v_V_29 = v_NEW_2DCDR_26;
((LP) (DEREF((v_C_25) + 1 * 4) = (LD) (v_V_29)));
v_X_31 = v_C_25;
t16 = ((LP) DEREF((v_X_31) + 1 * 4));
} else {
v_LOOPVAR_2D1233_9 = v_LOOPVAR_2D1235_11;
t16 = v_LOOPVAR_2D1233_9;
}
v_LOOPVAR_2D1234_10 = ICALL(s_lsp_LAST) (1, t16);
}
goto t_NEXT_2DLOOP_13;
goto t_END_2DLOOP_14;
t_END_2DLOOP_14:;
v_ALL_2DSTRUCTS_60 = v_LOOPVAR_2D1233_9;
goto b_NIL_12;
v_ALL_2DSTRUCTS_60 = NIL;
v_ALL_2DSTRUCTS_60 = v_ALL_2DSTRUCTS_60;
b_NIL_12:;
v_TYPES_33 = LREF(s_lsp_NIL);
v_CONSEQUENT_34 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D1236_35 = v_OTHERS_4;
v_LOOPVAR_2D1237_36 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1238_37 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1239_38 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_40:;
if (v_LOOP_2DLIST_2D1236_35 == NIL) {
goto t_END_2DLOOP_41;
}
v_X_42 = v_LOOP_2DLIST_2D1236_35;
v_X_44 = ((LP) DEREF((v_X_42) + 0 * 4));
v_TYPES_33 = ((LP) DEREF((v_X_44) + 0 * 4));
v_X_46 = v_LOOP_2DLIST_2D1236_35;
v_X_48 = ((LP) DEREF((v_X_46) + 0 * 4));
v_CONSEQUENT_34 = ((LP) DEREF((v_X_48) + 1 * 4));
v_X_50 = v_LOOP_2DLIST_2D1236_35;
v_LOOP_2DLIST_2D1236_35 = ((LP) DEREF((v_X_50) + 1 * 4));
v_LOOPVAR_2D1239_38 = ICALL(s_lsp_COPY_2DLIST) (1, v_TYPES_33);
if (v_LOOPVAR_2D1239_38 != NIL) {
if (v_LOOPVAR_2D1238_37 != NIL) {
v_C_52 = v_LOOPVAR_2D1238_37;
v_NEW_2DCDR_53 = v_LOOPVAR_2D1239_38;
v_V_56 = v_NEW_2DCDR_53;
((LP) (DEREF((v_C_52) + 1 * 4) = (LD) (v_V_56)));
v_X_58 = v_C_52;
t17 = ((LP) DEREF((v_X_58) + 1 * 4));
} else {
v_LOOPVAR_2D1237_36 = v_LOOPVAR_2D1239_38;
t17 = v_LOOPVAR_2D1237_36;
}
v_LOOPVAR_2D1238_37 = ICALL(s_lsp_LAST) (1, t17);
}
goto t_NEXT_2DLOOP_40;
goto t_END_2DLOOP_41;
t_END_2DLOOP_41:;
v_ALL_2DOTHERS_61 = v_LOOPVAR_2D1237_36;
goto b_NIL_39;
v_ALL_2DOTHERS_61 = NIL;
v_ALL_2DOTHERS_61 = v_ALL_2DOTHERS_61;
b_NIL_39:;
v_X_62 = LREF(s_lsp__3D);
t18 = ((LP) DEREF((LREF(s_lsp__3D)) + 4 * 4));
v_G5867_64 = ICALL(s_lsp_DUPLICATES_3F) (2, v_ALL_2DOTHERS_61, t18);
if (v_G5867_64 != NIL) {
t19 = v_G5867_64;
} else {
v_X_65 = LREF(s_lsp_EQ);
t20 = ((LP) DEREF((LREF(s_lsp_EQ)) + 4 * 4));
v_G5868_67 = ICALL(s_lsp_DUPLICATES_3F) (2, v_ALL_2DSTRUCTS_60, t20);
if (v_G5868_67 != NIL) {
t19 = v_G5868_67;
} else {
v_X_78 = v_STRUCTURE_2;
v_X_80 = v_STRUCTURE_2;
v_Y_81 = LREF(s_lsp_NIL);
if (v_STRUCTURE_2 != NIL) {
v_X_68 = v_STRUCTURE_2DCASES_3;
v_X_70 = v_STRUCTURE_2DCASES_3;
v_Y_71 = LREF(s_lsp_NIL);
v_X_73 = (((v_STRUCTURE_2DCASES_3) == (LREF(s_lsp_NIL))) ? T : NIL);
v_X_75 = v_X_73;
v_Y_76 = LREF(s_lsp_NIL);
t19 = (((v_X_73) == (LREF(s_lsp_NIL))) ? T : NIL);
} else {
t19 = LREF(s_lsp_NIL);
}
}
}
if (t19 != NIL) {
t1 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,4)))(MV_CALL(argc,0));
return(t1);
} else {
t1 = ICALL(s_lsp_OPTIMIZE_2DTYPECASE_2D1) (MV_CALL(argc,6), GET_OE_SLOT(t0,3), v_FIXNUM_1, v_STRUCTURE_2, v_STRUCTURE_2DCASES_3, v_OTHERS_4, GET_OE_SLOT(t0,2));
return(t1);
}
}
}

LP p_lsp_OPTIMIZE_2DTYPECASE_2DADD_2DCASE10753(argc, v_TYPE_2DCODE_0, v_CONSEQUENT_1, v_EXISTING_2)
      ARGC argc;  LP v_TYPE_2DCODE_0; LP v_CONSEQUENT_1; LP v_EXISTING_2;
{
LP v_Y_14; LP v_X_13; LP v_Y_11; 
LP v_X_10; LP v_Y_8; LP v_X_7; 
LP v_Y_5; LP v_X_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 3) wna(argc,3);
v_X_4 = LREF(s_lsp_PROGN);
v_Y_5 = v_CONSEQUENT_1;
v_X_7 = (c_cons((LREF(s_lsp_PROGN)), (v_CONSEQUENT_1)));
v_Y_11 = (c_cons((v_X_7), (LREF(s_lsp_NIL))));
v_X_13 = (c_cons((v_TYPE_2DCODE_0), (v_Y_11)));
t0 = (c_cons((v_X_13), (v_EXISTING_2)));
return(t0);
}

LP p_lsp_OPTIMIZE_2DTYPECASE_2DFAIL10752(argc)
      ARGC argc; 
{

LP t0; 
if (argc != 0) wna(argc,0);
t0 = OE;
BEGIN_MV_CALL(dynamicblock_mv_holder10750,0);
THROW(LREF(s_lsp_OPTIMIZE_2DTYPECASE1231),GET_OE_SLOT(t0,5),dynamicblock_mv_holder10750);
END_MV_CALL;
}

LP p_lsp_TYPE_2D_3ETYPE_2DCODES(argc, v_TYPE_0)
      ARGC argc;  LP v_TYPE_0;
{
LP v_S_101; LP v_SYMBOL_99; LP v_Y_97; 
LP v_X_96; LP v_SYMBOL_94; LP v_Y_92; 
LP v_X_91; LP v_Y_89; LP v_X_88; 
LP v_Y_86; LP v_X_85; LP v_X_83; 
LP v_Y_81; LP v_X_80; LP v_Y_78; 
LP v_X_77; LP v_Y_75; LP v_X_74; 
LP v_Y_72; LP v_X_71; LP v_Y_69; 
LP v_X_68; LP v_Y_66; LP v_X_65; 
LP v_Y_63; LP v_X_62; LP v_S_60; 
LP v_SYMBOL_58; LP v_Y_56; LP v_X_55; 
LP v_Y_53; LP v_X_52; LP v_Y_50; 
LP v_X_49; LP v_Y_47; LP v_X_46; 
LP v_Y_44; LP v_X_43; LP v_Y_41; 
LP v_X_40; LP v_Y_38; LP v_X_37; 
LP v_Y_35; LP v_X_34; LP v_Y_32; 
LP v_X_31; LP v_Y_29; LP v_X_28; 
LP v_Y_26; LP v_X_25; LP v_Y_23; 
LP v_X_22; LP v_Y_20; LP v_X_19; 
LP v_KEY5878_17; LP v_X_15; LP v_X_13; 
LP v_C_11; LP v_LIST_9; LP v_KEY5874_5; 
LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; 
if (argc != 1) wna(argc,1);
v_X_3 = v_TYPE_0;
v_KEY5874_5 = ((LP) DEREF((v_TYPE_0) + 0 * 4));
v_S_101 = v_KEY5874_5;
if (OTHER_PTRP((v_KEY5874_5)) && (TAG((v_KEY5874_5)) == 3)) {
v_SYMBOL_99 = v_KEY5874_5;
t4 = ((LP) DEREF((v_KEY5874_5) + 5 * 4));
t3 = ((LP) ((int) (t4) % (int) ((LP) 26)));
switch ((int) t3) {
case 12:
v_X_62 = v_KEY5874_5;
v_Y_63 = LREF(s_lsp_SATISFIES);
if (((v_KEY5874_5) == (LREF(s_lsp_SATISFIES)))) {
v_LIST_9 = v_TYPE_0;
v_C_11 = v_TYPE_0;
v_X_13 = v_TYPE_0;
v_X_15 = ((LP) DEREF((v_TYPE_0) + 1 * 4));
v_KEY5878_17 = ((LP) DEREF((v_X_15) + 0 * 4));
v_S_60 = v_KEY5878_17;
if (OTHER_PTRP((v_KEY5878_17)) && (TAG((v_KEY5878_17)) == 3)) {
v_SYMBOL_58 = v_KEY5878_17;
t9 = ((LP) DEREF((v_KEY5878_17) + 5 * 4));
t8 = ((LP) ((int) (t9) % (int) ((LP) 38)));
switch ((int) t8) {
case 6:
v_X_19 = v_KEY5878_17;
v_Y_20 = LREF(s_lsp_STRUCTUREP);
if (((v_KEY5878_17) == (LREF(s_lsp_STRUCTUREP)))) {
return(LREF(s_key_STRUCTURE));
} else {
goto t_DEFAULT_2DTAG5879_18;
}
break;
case 36:
v_X_25 = v_KEY5878_17;
v_Y_26 = LREF(s_lsp_COMPILED_2DFUNCTION_2DP);
if (((v_KEY5878_17) == (LREF(s_lsp_COMPILED_2DFUNCTION_2DP)))) {
v_X_22 = (LP) 78;
v_Y_23 = LREF(s_lsp_NIL);
t7 = (c_cons(((LP) 78), (LREF(s_lsp_NIL))));
return(t7);
} else {
goto t_DEFAULT_2DTAG5879_18;
}
break;
case 30:
v_X_31 = v_KEY5878_17;
v_Y_32 = LREF(s_lsp_FOREIGN_2DPOINTER_2DP);
if (((v_KEY5878_17) == (LREF(s_lsp_FOREIGN_2DPOINTER_2DP)))) {
v_X_28 = (LP) 62;
v_Y_29 = LREF(s_lsp_NIL);
t7 = (c_cons(((LP) 62), (LREF(s_lsp_NIL))));
return(t7);
} else {
goto t_DEFAULT_2DTAG5879_18;
}
break;
case 34:
v_X_37 = v_KEY5878_17;
v_Y_38 = LREF(s_lsp_CONSP);
if (((v_KEY5878_17) == (LREF(s_lsp_CONSP)))) {
v_X_34 = (LP) 30;
v_Y_35 = LREF(s_lsp_NIL);
t7 = (c_cons(((LP) 30), (LREF(s_lsp_NIL))));
return(t7);
} else {
goto t_DEFAULT_2DTAG5879_18;
}
break;
case 0:
v_X_43 = v_KEY5878_17;
v_Y_44 = LREF(s_lsp_COMPLEXP);
if (((v_KEY5878_17) == (LREF(s_lsp_COMPLEXP)))) {
v_X_40 = (LP) 26;
v_Y_41 = LREF(s_lsp_NIL);
t7 = (c_cons(((LP) 26), (LREF(s_lsp_NIL))));
return(t7);
} else {
goto t_DEFAULT_2DTAG5879_18;
}
break;
case 32:
v_X_49 = v_KEY5878_17;
v_Y_50 = LREF(s_lsp_RATIOP);
if (((v_KEY5878_17) == (LREF(s_lsp_RATIOP)))) {
v_X_46 = (LP) 18;
v_Y_47 = LREF(s_lsp_NIL);
t7 = (c_cons(((LP) 18), (LREF(s_lsp_NIL))));
return(t7);
} else {
goto t_DEFAULT_2DTAG5879_18;
}
break;
case 26:
v_X_55 = v_KEY5878_17;
v_Y_56 = LREF(s_lsp_BIGNUMP);
if (((v_KEY5878_17) == (LREF(s_lsp_BIGNUMP)))) {
v_X_52 = (LP) 2;
v_Y_53 = LREF(s_lsp_NIL);
t7 = (c_cons(((LP) 2), (LREF(s_lsp_NIL))));
return(t7);
} else {
goto t_DEFAULT_2DTAG5879_18;
}
break;
default:
goto t_DEFAULT_2DTAG5879_18;
break;
}
return(t7);
}
t_DEFAULT_2DTAG5879_18:;
return(LREF(s_lsp_NIL));
return(NIL);
return(NIL);
} else {
goto t_DEFAULT_2DTAG5875_6;
}
break;
case 24:
v_X_71 = v_KEY5874_5;
v_Y_72 = LREF(s_lsp_SYMBOL);
if (((v_KEY5874_5) == (LREF(s_lsp_SYMBOL)))) {
v_X_65 = (LP) 22;
v_Y_66 = LREF(s_lsp_NIL);
v_Y_69 = (c_cons(((LP) 22), (LREF(s_lsp_NIL))));
t2 = (c_cons(((LP) 6), (v_Y_69)));
return(t2);
} else {
goto t_DEFAULT_2DTAG5875_6;
}
break;
case 14:
v_X_77 = v_KEY5874_5;
v_Y_78 = LREF(s_lsp_CHARACTER);
if (((v_KEY5874_5) == (LREF(s_lsp_CHARACTER)))) {
v_X_74 = (LP) 14;
v_Y_75 = LREF(s_lsp_NIL);
t2 = (c_cons(((LP) 14), (LREF(s_lsp_NIL))));
return(t2);
} else {
goto t_DEFAULT_2DTAG5875_6;
}
break;
case 20:
v_X_85 = v_KEY5874_5;
v_Y_86 = LREF(s_lsp_FLOAT);
if (((v_KEY5874_5) == (LREF(s_lsp_FLOAT)))) {
v_X_83 = v_TYPE_0;
t20 = ((LP) DEREF((v_TYPE_0) + 1 * 4));
if (t20 != NIL) {
return(LREF(s_lsp_NIL));
} else {
v_X_80 = (LP) 10;
v_Y_81 = LREF(s_lsp_NIL);
t2 = (c_cons(((LP) 10), (LREF(s_lsp_NIL))));
return(t2);
}
} else {
goto t_DEFAULT_2DTAG5875_6;
}
break;
case 10:
v_X_88 = v_KEY5874_5;
v_Y_89 = LREF(s_lsp_ARRAY);
if (((v_KEY5874_5) == (LREF(s_lsp_ARRAY)))) {
goto t_C5877_7;
} else {
goto t_DEFAULT_2DTAG5875_6;
}
break;
case 2:
v_X_91 = v_KEY5874_5;
v_Y_92 = LREF(s_lsp_SIMPLE_2DARRAY);
if (((v_KEY5874_5) == (LREF(s_lsp_SIMPLE_2DARRAY)))) {
goto t_C5877_7;
} else {
goto t_DEFAULT_2DTAG5875_6;
}
break;
case 0:
v_X_96 = v_KEY5874_5;
v_Y_97 = LREF(s_lsp_INTEGER);
if (((v_KEY5874_5) == (LREF(s_lsp_INTEGER)))) {
v_SYMBOL_94 = LREF(s_lsp__2AFIXNUM_2DSPEC_2A);
t25 = ((LP) DEREF((LREF(s_lsp__2AFIXNUM_2DSPEC_2A)) + 0 * 4));
t24 = ICALL(s_lsp_EQUAL) (2, v_TYPE_0, t25);
if (t24 != NIL) {
return(LREF(s_key_FIXNUM));
} else {
return(LREF(s_lsp_NIL));
}
} else {
goto t_DEFAULT_2DTAG5875_6;
}
break;
default:
goto t_DEFAULT_2DTAG5875_6;
break;
}
return(t2);
}
t_DEFAULT_2DTAG5875_6:;
return(LREF(s_lsp_NIL));
return(NIL);
t_C5877_7:;
t26 = ICALL(s_lsp_ARRAY_2DTYPE_2D_3ETYPE_2DCODES) (MV_CALL(argc,1), v_TYPE_0);
return(t26);
return(NIL);
return(NIL);
}

LP p_lsp_ARRAY_2DTYPE_2D_3ETYPE_2DCODES(argc, v_ARRAY_2DSPEC_0)
      ARGC argc;  LP v_ARRAY_2DSPEC_0;
{
LP v_ARRAY_2DCLASS_10; LP v_S5884_9; LP v_X_7; 
LP v_VALUE5883_6; LP v_X_4; LP v_LIST5882_3; 
LP v_L5881_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 1) wna(argc,1);
t0 = NEW_OE(1);
v_L5881_2 = v_ARRAY_2DSPEC_0;
v_LIST5882_3 = v_L5881_2;
v_X_4 = v_LIST5882_3;
v_VALUE5883_6 = ((LP) DEREF((v_LIST5882_3) + 0 * 4));
v_X_7 = v_LIST5882_3;
v_S5884_9 = ((LP) DEREF((v_LIST5882_3) + 1 * 4));
v_L5881_2 = v_S5884_9;
v_ARRAY_2DCLASS_10 = v_VALUE5883_6;
SET_OE_SLOT(t0,0,v_ARRAY_2DCLASS_10);
t2 = MAKE_CLOSURE(p_lsp_ARRAY_2DTYPE_2D_3ETYPE_2DCODES_2Danon1075610757,t0);
t1 = p_lsp_APPLY(MV_CALL(argc,2), COERCE_TO_FUNCTION(t2), v_L5881_2);
return(t1);
}

LP p_lsp_ARRAY_2DTYPE_2D_3ETYPE_2DCODES_2Danon1075610757(va_alist) va_dcl
{
LP v_DIMS_1; LP v_TYPE_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


t0 = OE;
real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 1) {
v_TYPE_0 = NIL;
} else {
v_TYPE_0 = NEXT_VAR_ARG;
}
if (real_argc < 2) {
v_DIMS_1 = NIL;
} else {
v_DIMS_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
if (v_DIMS_1 != NIL) {
if (v_TYPE_0 != NIL) {
return(LREF(s_lsp_NIL));
} else {
return(LREF(s_lsp_NIL));
}
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_OPTIMIZE_2DTYPECASE_2D1(argc, v_KEY_2DFORM_0, v_FIXNUM_1, v_STRUCTURE_2, v_STRUCTURE_2DCASES_3, v_OTHERS_4, v_DEFAULT_5)
      ARGC argc;  LP v_KEY_2DFORM_0; LP v_FIXNUM_1; LP v_STRUCTURE_2; LP v_STRUCTURE_2DCASES_3; LP v_OTHERS_4; LP v_DEFAULT_5;
{
LP v_Y_134; LP v_X_133; LP v_Y_131; 
LP v_X_130; LP v_Y_128; LP v_X_127; 
LP v_Y_125; LP v_X_124; LP v_Y_122; 
LP v_X_121; LP v_Y_119; LP v_X_118; 
LP v_Y_116; LP v_X_115; LP v_Y_113; 
LP v_X_112; LP v_Y_110; LP v_X_109; 
LP v_Y_107; LP v_X_106; LP v_Y_104; 
LP v_X_103; LP v_Y_101; LP v_X_100; 
LP v_Y_98; LP v_X_97; LP v_Y_95; 
LP v_X_94; LP v_Y_92; LP v_X_91; 
LP v_Y_89; LP v_X_88; LP v_Y_86; 
LP v_X_85; LP v_Y_83; LP v_X_82; 
LP v_Y_80; LP v_X_79; LP v_Y_77; 
LP v_X_76; LP v_Y_74; LP v_X_73; 
LP v_Y_71; LP v_X_70; LP v_Y_68; 
LP v_X_67; LP v_Y_65; LP v_X_64; 
LP v_Y_62; LP v_X_61; LP v_Y_59; 
LP v_X_58; LP v_Y_56; LP v_X_55; 
LP v_Y_53; LP v_X_52; LP v_Y_50; 
LP v_X_49; LP v_Y_47; LP v_X_46; 
LP v_Y_44; LP v_X_43; LP v_Y_41; 
LP v_X_40; LP v_Y_38; LP v_X_37; 
LP v_Y_35; LP v_X_34; LP v_Y_32; 
LP v_X_31; LP v_Y_29; LP v_X_28; 
LP v_Y_26; LP v_X_25; LP v_Y_23; 
LP v_X_22; LP v_Y_20; LP v_X_19; 
LP v_X_18; LP v_DEFAULT_2DTAG_17; LP v_NAME_16; 
LP v_X_14; LP v_X_13; LP v_X_11; 
LP v_X_10; LP v_X_8; LP v_X_7; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; 
if (argc != 6) wna(argc,6);
v_X_8 = LREF(k10758);
v_NAME_16 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(k10758));
v_X_11 = LREF(k10741);
v_DEFAULT_2DTAG_17 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(k10741));
v_X_14 = LREF(k10736);
v_X_18 = ICALL(s_lsp_GENSYM_2F1) (1, LREF(k10736));
v_X_19 = v_KEY_2DFORM_0;
v_Y_20 = LREF(s_lsp_NIL);
v_Y_23 = (c_cons((v_KEY_2DFORM_0), (LREF(s_lsp_NIL))));
v_X_25 = (c_cons((v_X_18), (v_Y_23)));
v_X_121 = (c_cons((v_X_25), (LREF(s_lsp_NIL))));
v_X_28 = v_X_18;
v_Y_29 = LREF(s_lsp_NIL);
v_Y_32 = (c_cons((v_X_18), (LREF(s_lsp_NIL))));
t0 = (c_cons((LREF(s_lsp_FIXNUMP)), (v_Y_32)));
if (v_FIXNUM_1 != NIL) {
v_X_43 = v_FIXNUM_1;
v_Y_44 = LREF(s_lsp_NIL);
t2 = (c_cons((v_FIXNUM_1), (LREF(s_lsp_NIL))));
} else {
v_X_34 = v_DEFAULT_2DTAG_17;
v_Y_35 = LREF(s_lsp_NIL);
v_Y_38 = (c_cons((v_DEFAULT_2DTAG_17), (LREF(s_lsp_NIL))));
v_X_40 = (c_cons((LREF(s_lsp_GO)), (v_Y_38)));
t2 = (c_cons((v_X_40), (LREF(s_lsp_NIL))));
}
v_X_46 = v_X_18;
v_Y_47 = LREF(s_lsp_NIL);
v_Y_50 = (c_cons((v_X_18), (LREF(s_lsp_NIL))));
t3 = (c_cons((LREF(s_lsp__25TAG)), (v_Y_50)));
if (v_STRUCTURE_2DCASES_3 != NIL) {
v_X_52 = v_X_18;
v_Y_53 = LREF(s_lsp_NIL);
v_Y_56 = (c_cons((v_X_18), (LREF(s_lsp_NIL))));
t7 = (c_cons((LREF(s_lsp_STRUCTURE_2DTYPE)), (v_Y_56)));
v_X_58 = v_DEFAULT_2DTAG_17;
v_Y_59 = LREF(s_lsp_NIL);
v_Y_62 = (c_cons((v_DEFAULT_2DTAG_17), (LREF(s_lsp_NIL))));
v_X_64 = (c_cons((LREF(s_lsp_GO)), (v_Y_62)));
v_Y_68 = (c_cons((v_X_64), (LREF(s_lsp_NIL))));
v_X_70 = (c_cons((LREF(s_lsp_T)), (v_Y_68)));
t9 = (c_cons((v_X_70), (LREF(s_lsp_NIL))));
t8 = ICALL(s_lsp_APPEND_2F2) (2, v_STRUCTURE_2DCASES_3, t9);
v_X_73 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_CASE), t7, t8);
v_Y_77 = (c_cons((v_X_73), (LREF(s_lsp_NIL))));
v_X_79 = (c_cons(((LP) 94), (v_Y_77)));
t6 = (c_cons((v_X_79), (LREF(s_lsp_NIL))));
} else {
if (v_STRUCTURE_2 != NIL) {
t6 = v_STRUCTURE_2;
} else {
t6 = LREF(s_lsp_NIL);
}
}
v_X_82 = v_DEFAULT_2DTAG_17;
v_Y_83 = LREF(s_lsp_NIL);
v_Y_86 = (c_cons((v_DEFAULT_2DTAG_17), (LREF(s_lsp_NIL))));
v_X_88 = (c_cons((LREF(s_lsp_GO)), (v_Y_86)));
v_Y_92 = (c_cons((v_X_88), (LREF(s_lsp_NIL))));
v_X_94 = (c_cons((LREF(s_lsp_T)), (v_Y_92)));
t10 = (c_cons((v_X_94), (LREF(s_lsp_NIL))));
t5 = ICALL(s_lsp_APPEND_2F2) (2, t6, t10);
t4 = ICALL(s_lsp_APPEND_2F2) (2, v_OTHERS_4, t5);
v_X_97 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_SWITCH), t3, t4);
t11 = (c_cons((v_X_97), (LREF(s_lsp_NIL))));
t1 = ICALL(s_lsp_APPEND_2F2) (2, t2, t11);
v_X_100 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_IF), t0, t1);
v_Y_104 = (c_cons((v_X_100), (LREF(s_lsp_NIL))));
v_Y_107 = (c_cons((v_NAME_16), (v_Y_104)));
t12 = (c_cons((LREF(s_lsp_RETURN_2DFROM)), (v_Y_107)));
v_X_109 = v_DEFAULT_5;
v_Y_110 = LREF(s_lsp_NIL);
v_Y_113 = (c_cons((v_DEFAULT_5), (LREF(s_lsp_NIL))));
v_Y_116 = (c_cons((v_NAME_16), (v_Y_113)));
t13 = (c_cons((LREF(s_lsp_RETURN_2DFROM)), (v_Y_116)));
v_X_118 = ICALL(s_lsp_LIST) (4, LREF(s_lsp_TAGBODY), t12, v_DEFAULT_2DTAG_17, t13);
v_Y_122 = (c_cons((v_X_118), (LREF(s_lsp_NIL))));
v_Y_125 = (c_cons((v_X_121), (v_Y_122)));
v_X_127 = (c_cons((LREF(s_lsp_LET)), (v_Y_125)));
v_Y_131 = (c_cons((v_X_127), (LREF(s_lsp_NIL))));
v_Y_134 = (c_cons((v_NAME_16), (v_Y_131)));
t14 = (c_cons((LREF(s_lsp_BLOCK)), (v_Y_134)));
return(t14);
}

LP p_lsp_TYPE_2DDISPATCH_5FINIT1240(argc)
      ARGC argc; 
{
LP v_Y_8; LP v_X_7; LP v_Y_5; 
LP v_X_4; LP v_Y_2; LP v_X_1; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; 
if (argc != 0) wna(argc,0);
v_X_1 = (LP) 2147483646;
v_Y_2 = LREF(s_lsp_NIL);
v_Y_5 = (c_cons(((LP) 2147483646), (LREF(s_lsp_NIL))));
v_Y_8 = (c_cons(((LP) -2147483648), (v_Y_5)));
t1 = (c_cons((LREF(s_lsp_INTEGER)), (v_Y_8)));
t0 = ICALL(s_lsp_DEFINE_2DVARIABLE) (MV_CALL(argc,4), LREF(s_lsp__2AFIXNUM_2DSPEC_2A), t1, LREF(s_lsp_NIL), LREF(s_key_VAR));
return(t0);
}

