/*
:comment "Compiled at 6:26:11 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: DEFAULT"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O "
:version 0
:package (IN-PACKAGE (QUOTE PCL)) 
:end-package-info 0
:sym PARSE-METHOD-OR-SPEC
:sym METHOD-FUNCTION
:sym TRACE-METHOD-INTERNAL
:sym TRACED-METHOD
:sym :METHOD
:sym :FUNCTION
:sym MAKE-INSTANCE
:sym REMOVE-METHOD
:sym ADD-METHOD
:sym *TRACED-METHODS*
:sym EQL
:sym IDENTITY
:sym LISP::ADJOIN/4
:sf TRACE-METHOD "p_pcl_TRACE_2DMETHOD"
:sym NIL
:sym LISP::MEMQ
:sym ERROR
:sym METHOD-GENERIC-FUNCTION
:sym METHOD
:sym SLOT-VALUE
:sym REMOVE
:sf UNTRACE-METHOD "p_pcl_UNTRACE_2DMETHOD"
:sym UNTRACE
:sym EVAL
:sym TRACE
:sym LIST*
:sf TRACE-METHOD-INTERNAL "p_pcl_TRACE_2DMETHOD_2DINTERNAL"
:sym QUOTE
:sym UNDEFMETHOD-1
:sm UNDEFMETHOD "m_pcl_UNDEFMETHOD"
:sf UNDEFMETHOD-1 "p_pcl_UNDEFMETHOD_2D1"
:sym DESCRIBE-OBJECT
:sym OBJECT
:sym STREAM
:sym LOAD-DEFGENERIC
:sym *OLD-DESCRIBE*
:sym :VAR
:sym LISP::DEFINE-VARIABLE
:sym DESCRIBE
:sym STANDARD-METHOD
:sym T
:sym LOAD-DEFMETHOD
:sym STANDARD-OBJECT
:sym SLOTS-TO-INSPECT
:sym STD-CLASS
:sym CLASS
:sym STANDARD-CLASS
:sym :NAME
:sym :READERS
:sym :WRITERS
:sym :INITARGS
:sym FUNCTION
:sym :INITFUNCTION
:sym FALSE
:sym GENERIC-FUNCTION
:sym SETF
:sym :INITFORM
:sym LOAD-DEFCLASS
:sym METHOD-LAMBDA-LIST
:sym M
:sym |isl-cache1683|
:sym :ISL
:sym :ISL-CACHE-SYMBOL
:sym METHOD-SPECIALIZERS
:sym |isl-cache1691|
:sym METHOD-QUALIFIERS
:sym |isl-cache1699|
:sym |isl-cache1707|
:sym ACCESSOR-METHOD-SLOT-NAME
:sym |isl-cache1715|
:sym UNDEFMETHOD
:sym LISP::DEFINE-MACRO
:sym *EMPTY-VECTOR*
:sym SVREF
:sym STD-INSTANCE-P
:sym PRIMARY-PV-CACHE-MISS
:sym ..SLOT-UNBOUND..
:sym CLASS-OF
:sym FORMAT
:sym CLASS-NAME
:sym FIND-CLASS
:sym CLASS-DIRECT-SUPERCLASSES
:sym CLASS-DIRECT-SUBCLASSES
:sym CLASS-PRECEDENCE-LIST
:sym SPECIALIZER-METHODS
:sym LENGTH
:sym CLASS-SLOTS
:sym SLOTD-NAME
:sym SLOTD-ALLOCATION
:sym :INSTANCE
:sym :CLASS
:sym MIN
:sym NREVERSE
:sym SLOT-VALUE-OR-DEFAULT
:sym MAX
:sym *STANDARD-OUTPUT*
:sf ENV_INIT1723 "p_pcl_ENV_5FINIT1723"
:init ENV_INIT1723
:pinfo PCL::UNTRACE-METHOD (&OPTIONAL PCL::SPEC) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::UNDEFMETHOD-1 (PCL::ARGS) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::ENV_INIT1723 NIL NIL NIL NIL NIL NIL NIL T
:pinfo PCL::TRACE-METHOD (PCL::SPEC &REST PCL::OPTIONS) NIL NIL NIL NIL NIL NIL T
:pinfo PCL::TRACE-METHOD-INTERNAL (PCL::OFUNCTION PCL::NAME PCL::OPTIONS) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_pcl_TRACE_2DMETHOD();
extern SYMBOL s_pcl_PARSE_2DMETHOD_2DOR_2DSPEC; 
extern SYMBOL s_pcl_METHOD_2DFUNCTION; 
extern SYMBOL s_pcl_TRACE_2DMETHOD_2DINTERNAL; 
extern SYMBOL s_pcl_TRACED_2DMETHOD; 
extern SYMBOL s_key_METHOD; 
extern SYMBOL s_key_FUNCTION; 
extern SYMBOL s_pcl_MAKE_2DINSTANCE; 
extern SYMBOL s_pcl_REMOVE_2DMETHOD; 
extern SYMBOL s_pcl_ADD_2DMETHOD; 
extern SYMBOL s_pcl__2ATRACED_2DMETHODS_2A; 
extern SYMBOL s_lsp_EQL; 
extern SYMBOL s_lsp_IDENTITY; 
extern SYMBOL s_lsp_ADJOIN_2F4; 
extern LP p_pcl_UNTRACE_2DMETHOD();
extern LP p_pcl_UNTRACE_2DMETHOD_2DUNTRACE_2D15120();
MAKE_PROCEDURE(k5122,p_pcl_UNTRACE_2DMETHOD_2DUNTRACE_2D15120);
extern SYMBOL s_lsp_NIL; 
extern SYMBOL s_lsp_MEMQ; 
MAKE_SIMPLE_STRING(k5123,26,"~S is not a traced method?");
extern SYMBOL s_lsp_ERROR; 
extern SYMBOL s_pcl_METHOD_2DGENERIC_2DFUNCTION; 
extern SYMBOL s_pcl_METHOD; 
extern SYMBOL s_pcl_SLOT_2DVALUE; 
extern SYMBOL s_lsp_REMOVE; 
extern LP p_pcl_TRACE_2DMETHOD_2DINTERNAL();
extern SYMBOL s_lsp_UNTRACE; 
extern SYMBOL s_lsp_EVAL; 
extern SYMBOL s_lsp_TRACE; 
extern SYMBOL s_lsp_LIST_2A; 
extern LP m_pcl_UNDEFMETHOD();
extern SYMBOL s_lsp_QUOTE; 
extern SYMBOL s_pcl_UNDEFMETHOD_2D1; 
extern LP p_pcl_UNDEFMETHOD_2D1();
extern LP p_pcl_ENV_5FINIT1723();
extern SYMBOL s_pcl_DESCRIBE_2DOBJECT; 
extern SYMBOL s_pcl_OBJECT; 
extern SYMBOL s_lsp_STREAM; 
MAKE_CONS(k5149,LREF(s_lsp_STREAM),LREF(s_lsp_NIL));
MAKE_CONS(k5148,LREF(s_pcl_OBJECT),LREF(k5149));
extern SYMBOL s_pcl_LOAD_2DDEFGENERIC; 
extern SYMBOL s_pcl__2AOLD_2DDESCRIBE_2A; 
extern SYMBOL s_key_VAR; 
extern SYMBOL s_lsp_DEFINE_2DVARIABLE; 
extern SYMBOL s_lsp_DESCRIBE; 
extern LP p_pcl_ENV_5FINIT1723_2Danon51255126();
MAKE_PROCEDURE(k5150,p_pcl_ENV_5FINIT1723_2Danon51255126);
extern SYMBOL s_pcl_STANDARD_2DMETHOD; 
extern SYMBOL s_lsp_T; 
extern LP p_pcl_ENV_5FINIT1723_2Danon51275128();
MAKE_PROCEDURE(k5151,p_pcl_ENV_5FINIT1723_2Danon51275128);
extern SYMBOL s_pcl_LOAD_2DDEFMETHOD; 
extern SYMBOL s_pcl_STANDARD_2DOBJECT; 
extern LP p_pcl_ENV_5FINIT1723_2Danon51295130();
extern SYMBOL s_pcl_SLOTS_2DTO_2DINSPECT; 
extern SYMBOL s_pcl_STD_2DCLASS; 
extern SYMBOL s_pcl_CLASS; 
MAKE_CONS(k5153,LREF(s_pcl_OBJECT),LREF(s_lsp_NIL));
MAKE_CONS(k5152,LREF(s_pcl_CLASS),LREF(k5153));
extern LP p_pcl_ENV_5FINIT1723_2Danon51335134();
MAKE_PROCEDURE(k5154,p_pcl_ENV_5FINIT1723_2Danon51335134);
MAKE_CONS(k5155,LREF(s_pcl_CLASS),LREF(k5149));
extern LP p_pcl_ENV_5FINIT1723_2Danon51355136();
MAKE_PROCEDURE(k5156,p_pcl_ENV_5FINIT1723_2Danon51355136);
extern SYMBOL s_pcl_STANDARD_2DCLASS; 
MAKE_CONS(k5157,LREF(s_pcl_METHOD),LREF(s_lsp_NIL));
extern SYMBOL s_key_NAME; 
extern SYMBOL s_key_READERS; 
extern SYMBOL s_key_WRITERS; 
extern SYMBOL s_key_INITARGS; 
MAKE_CONS(k5158,LREF(s_key_METHOD),LREF(s_lsp_NIL));
extern SYMBOL s_lsp_FUNCTION; 
MAKE_CONS(k5159,LREF(s_pcl_METHOD_2DFUNCTION),LREF(s_lsp_NIL));
MAKE_CONS(k5160,LREF(s_key_FUNCTION),LREF(s_lsp_NIL));
extern SYMBOL s_key_INITFUNCTION; 
extern SYMBOL s_pcl_FALSE; 
extern SYMBOL s_pcl_GENERIC_2DFUNCTION; 
MAKE_CONS(k5161,LREF(s_pcl_METHOD_2DGENERIC_2DFUNCTION),LREF(s_lsp_NIL));
extern SYMBOL s_lsp_SETF; 
MAKE_CONS(k5163,LREF(s_lsp_SETF),LREF(k5161));
MAKE_CONS(k5162,LREF(k5163),LREF(s_lsp_NIL));
extern SYMBOL s_key_INITFORM; 
MAKE_CONS(k5165,LREF(s_lsp_NIL),LREF(s_lsp_NIL));
MAKE_CONS(k5164,LREF(s_key_INITFORM),LREF(k5165));
extern SYMBOL s_pcl_LOAD_2DDEFCLASS; 
extern SYMBOL s_pcl_METHOD_2DLAMBDA_2DLIST; 
extern SYMBOL s_pcl_M; 
MAKE_CONS(k5166,LREF(s_pcl_M),LREF(s_lsp_NIL));
extern SYMBOL s_pcl_isl_2Dcache1683; 
extern SYMBOL s_key_ISL; 
MAKE_CONS(k5169,LREF(k5157),LREF(s_lsp_NIL));
extern SYMBOL s_key_ISL_2DCACHE_2DSYMBOL; 
MAKE_CONS(k5171,LREF(s_pcl_isl_2Dcache1683),LREF(s_lsp_NIL));
MAKE_CONS(k5170,LREF(s_key_ISL_2DCACHE_2DSYMBOL),LREF(k5171));
MAKE_CONS(k5168,LREF(k5169),LREF(k5170));
MAKE_CONS(k5167,LREF(s_key_ISL),LREF(k5168));
extern LP p_pcl_ENV_5FINIT1723_2Danon51385139();
MAKE_PROCEDURE(k5172,p_pcl_ENV_5FINIT1723_2Danon51385139);
extern SYMBOL s_pcl_METHOD_2DSPECIALIZERS; 
extern SYMBOL s_pcl_isl_2Dcache1691; 
MAKE_CONS(k5176,LREF(s_pcl_isl_2Dcache1691),LREF(s_lsp_NIL));
MAKE_CONS(k5175,LREF(s_key_ISL_2DCACHE_2DSYMBOL),LREF(k5176));
MAKE_CONS(k5174,LREF(k5169),LREF(k5175));
MAKE_CONS(k5173,LREF(s_key_ISL),LREF(k5174));
extern LP p_pcl_ENV_5FINIT1723_2Danon51405141();
MAKE_PROCEDURE(k5177,p_pcl_ENV_5FINIT1723_2Danon51405141);
extern SYMBOL s_pcl_METHOD_2DQUALIFIERS; 
extern SYMBOL s_pcl_isl_2Dcache1699; 
MAKE_CONS(k5181,LREF(s_pcl_isl_2Dcache1699),LREF(s_lsp_NIL));
MAKE_CONS(k5180,LREF(s_key_ISL_2DCACHE_2DSYMBOL),LREF(k5181));
MAKE_CONS(k5179,LREF(k5169),LREF(k5180));
MAKE_CONS(k5178,LREF(s_key_ISL),LREF(k5179));
extern LP p_pcl_ENV_5FINIT1723_2Danon51425143();
MAKE_PROCEDURE(k5182,p_pcl_ENV_5FINIT1723_2Danon51425143);
extern SYMBOL s_pcl_isl_2Dcache1707; 
MAKE_CONS(k5186,LREF(s_pcl_isl_2Dcache1707),LREF(s_lsp_NIL));
MAKE_CONS(k5185,LREF(s_key_ISL_2DCACHE_2DSYMBOL),LREF(k5186));
MAKE_CONS(k5184,LREF(k5169),LREF(k5185));
MAKE_CONS(k5183,LREF(s_key_ISL),LREF(k5184));
extern LP p_pcl_ENV_5FINIT1723_2Danon51445145();
MAKE_PROCEDURE(k5187,p_pcl_ENV_5FINIT1723_2Danon51445145);
extern SYMBOL s_pcl_ACCESSOR_2DMETHOD_2DSLOT_2DNAME; 
extern SYMBOL s_pcl_isl_2Dcache1715; 
MAKE_CONS(k5191,LREF(s_pcl_isl_2Dcache1715),LREF(s_lsp_NIL));
MAKE_CONS(k5190,LREF(s_key_ISL_2DCACHE_2DSYMBOL),LREF(k5191));
MAKE_CONS(k5189,LREF(k5169),LREF(k5190));
MAKE_CONS(k5188,LREF(s_key_ISL),LREF(k5189));
extern LP p_pcl_ENV_5FINIT1723_2Danon51465147();
MAKE_PROCEDURE(k5192,p_pcl_ENV_5FINIT1723_2Danon51465147);
extern SYMBOL s_pcl_UNDEFMETHOD; 
extern SYMBOL s_lsp_DEFINE_2DMACRO; 
extern SYMBOL s_pcl__2AEMPTY_2DVECTOR_2A; 
extern SYMBOL s_lsp_SVREF; 
extern SYMBOL s_pcl_STD_2DINSTANCE_2DP; 
extern SYMBOL s_pcl_PRIMARY_2DPV_2DCACHE_2DMISS; 
extern SYMBOL s_pcl__2E_2ESLOT_2DUNBOUND_2E_2E; 
extern LP p_pcl_ENV_5FINIT1723_2Danon51355136ENV_5FINIT1723_2DPRETTY_2DCLASS5137();
MAKE_PROCEDURE(k5193,p_pcl_ENV_5FINIT1723_2Danon51355136ENV_5FINIT1723_2DPRETTY_2DCLASS5137);
MAKE_SIMPLE_STRING(k5194,43,"~&~S is a class, it is an instance of ~S.~%");
extern SYMBOL s_pcl_CLASS_2DOF; 
extern SYMBOL s_lsp_FORMAT; 
extern SYMBOL s_pcl_CLASS_2DNAME; 
extern SYMBOL s_pcl_FIND_2DCLASS; 
MAKE_SIMPLE_STRING(k5195,24,"Its proper name is ~S.~%");
MAKE_SIMPLE_STRING(k5196,48,"Its name is ~S, but this is not a proper name.~%");
MAKE_SIMPLE_STRING(k5197,35,"It has no name (the name is NIL).~%");
static struct {unsigned long header; char string[181+1];}
k5198  = {((181 << 8) + TYPE_SIMPLE_STRING), 
"The direct superclasses are: ~:S, and the direct~%~\n           subclasses are: ~:S.  The class precedence list is:~%~S~%~\n           There are ~D methods specialized for this class."};
extern SYMBOL s_pcl_CLASS_2DDIRECT_2DSUPERCLASSES; 
extern SYMBOL s_pcl_CLASS_2DDIRECT_2DSUBCLASSES; 
extern SYMBOL s_pcl_CLASS_2DPRECEDENCE_2DLIST; 
extern SYMBOL s_pcl_SPECIALIZER_2DMETHODS; 
extern SYMBOL s_lsp_LENGTH; 
extern SYMBOL s_pcl_CLASS_2DSLOTS; 
extern LP p_pcl_ENV_5FINIT1723_2Danon51295130ENV_5FINIT1723_2DADJUST_2DSLOT_2DNAME_2DLENGTH5131();
extern LP p_pcl_ENV_5FINIT1723_2Danon51295130ENV_5FINIT1723_2DDESCRIBE_2DSLOT5132();
extern SYMBOL s_pcl_SLOTD_2DNAME; 
extern SYMBOL s_pcl_SLOTD_2DALLOCATION; 
extern SYMBOL s_key_INSTANCE; 
extern SYMBOL s_key_CLASS; 
extern SYMBOL s_lsp_MIN; 
MAKE_SIMPLE_STRING(k5199,32,"~%~S is an instance of class ~S:");
MAKE_SIMPLE_STRING(k5200,49,"~% The following slots have :INSTANCE allocation:");
extern SYMBOL s_lsp_NREVERSE; 
extern SYMBOL s_pcl_SLOT_2DVALUE_2DOR_2DDEFAULT; 
MAKE_SIMPLE_STRING(k5201,46,"~% The following slots have :CLASS allocation:");
MAKE_SIMPLE_STRING(k5202,48,"~% The following slots have allocation as shown:");
MAKE_SIMPLE_STRING(k5203,16,"~% ~A ~S ~VT  ~S");
MAKE_SIMPLE_STRING(k5204,12,"~% ~A~VT  ~S");
extern SYMBOL s_lsp_MAX; 
extern SYMBOL s_lsp__2ASTANDARD_2DOUTPUT_2A; 


extern LP c_eql();
extern LP num_equal_p();
extern LP add();
extern LP c_cons();


LP p_pcl_TRACE_2DMETHOD(va_alist) va_dcl
{
LP v_V_16; LP v_X_15; LP v_S7436_14; 
LP v_X_12; LP v_X_10; LP v_SYMBOL_8; 
LP v_TMETHOD_7; LP v_TFUNCTION_6; LP v_NAME_5; 
LP v_OMETHOD_4; LP v_GF_3; LP v_SPEC_0; 
LP v_OPTIONS_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 

int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_SPEC_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
RESTIFY(v_OPTIONS_1,2,NEXT_VAR_ARG);
END_VAR_ARGS;
{
int real_argc;
BEGIN_MV_CALL(mv_holder5119,0);
t0 = ICALL(s_pcl_PARSE_2DMETHOD_2DOR_2DSPEC) (MV_CALL(mv_holder5119,1), v_SPEC_0);
SET_MV_RETURN_VALUE(mv_holder5119,0,t0);
if SV_RETURN_P(mv_holder5119) SET_MV_RETURN_COUNT(mv_holder5119,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder5119);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_GF_3 = NIL;
} else {
v_GF_3 = NEXT_VAR_VALUE(mv_holder5119);
}
if (real_argc < 2) {
v_OMETHOD_4 = NIL;
} else {
v_OMETHOD_4 = NEXT_VAR_VALUE(mv_holder5119);
}
if (real_argc < 3) {
v_NAME_5 = NIL;
} else {
v_NAME_5 = NEXT_VAR_VALUE(mv_holder5119);
}
END_VAR_VALUES;
END_MV_CALL;
t1 = ICALL(s_pcl_METHOD_2DFUNCTION) (1, v_OMETHOD_4);
v_TFUNCTION_6 = ICALL(s_pcl_TRACE_2DMETHOD_2DINTERNAL) (3, t1, v_NAME_5, v_OPTIONS_1);
v_TMETHOD_7 = ICALL(s_pcl_MAKE_2DINSTANCE) (5, LREF(s_pcl_TRACED_2DMETHOD), LREF(s_key_METHOD), v_OMETHOD_4, LREF(s_key_FUNCTION), v_TFUNCTION_6);
ICALL(s_pcl_REMOVE_2DMETHOD) (2, v_GF_3, v_OMETHOD_4);
ICALL(s_pcl_ADD_2DMETHOD) (2, v_GF_3, v_TMETHOD_7);
v_SYMBOL_8 = LREF(s_pcl__2ATRACED_2DMETHODS_2A);
t2 = ((LP) DEREF((LREF(s_pcl__2ATRACED_2DMETHODS_2A)) + 0 * 4));
v_X_10 = LREF(s_lsp_EQL);
t3 = ((LP) DEREF((LREF(s_lsp_EQL)) + 4 * 4));
v_X_12 = LREF(s_lsp_IDENTITY);
t4 = ((LP) DEREF((LREF(s_lsp_IDENTITY)) + 4 * 4));
v_S7436_14 = ICALL(s_lsp_ADJOIN_2F4) (4, v_TMETHOD_7, t2, t3, t4);
v_V_16 = v_S7436_14;
((LP) (DEREF((LREF(s_pcl__2ATRACED_2DMETHODS_2A)) + 0 * 4) = (LD) (v_V_16)));
return(v_TMETHOD_7);
}
}

LP p_pcl_UNTRACE_2DMETHOD(va_alist) va_dcl
{
LP v_Y_21; LP v_X_20; LP v_X_18; 
LP v_X_16; LP v_X_14; LP v_LOOP_2DLIST_2D1722_10; 
LP v_M_9; LP v_SYMBOL_7; LP v_SYMBOL_5; 
LP v_METHOD_4; LP v_GF_3; LP f_UNTRACE_2D1_2; 
LP v_SPEC_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
if (real_argc > 1) wna_high(real_argc,1);
if (real_argc < 1) {
v_SPEC_0 = NIL;
} else {
v_SPEC_0 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
f_UNTRACE_2D1_2 = LREF(k5122);
v_X_18 = v_SPEC_0;
v_X_20 = v_SPEC_0;
v_Y_21 = LREF(s_lsp_NIL);
if (v_SPEC_0 != NIL) {
{
int real_argc;
BEGIN_MV_CALL(mv_holder5121,0);
t1 = ICALL(s_pcl_PARSE_2DMETHOD_2DOR_2DSPEC) (MV_CALL(mv_holder5121,1), v_SPEC_0);
SET_MV_RETURN_VALUE(mv_holder5121,0,t1);
if SV_RETURN_P(mv_holder5121) SET_MV_RETURN_COUNT(mv_holder5121,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder5121);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_GF_3 = NIL;
} else {
v_GF_3 = NEXT_VAR_VALUE(mv_holder5121);
}
if (real_argc < 2) {
v_METHOD_4 = NIL;
} else {
v_METHOD_4 = NEXT_VAR_VALUE(mv_holder5121);
}
END_VAR_VALUES;
END_MV_CALL;
v_SYMBOL_5 = LREF(s_pcl__2ATRACED_2DMETHODS_2A);
t3 = ((LP) DEREF((LREF(s_pcl__2ATRACED_2DMETHODS_2A)) + 0 * 4));
t2 = ICALL(s_lsp_MEMQ) (2, v_METHOD_4, t3);
if (t2 != NIL) {
t0 = CODE_PTR(COERCE_TO_FUNCTION(f_UNTRACE_2D1_2))(MV_CALL(argc,1), v_METHOD_4);
return(t0);
} else {
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,2), LREF(k5123), v_METHOD_4);
return(t0);
}
}
} else {
v_M_9 = LREF(s_lsp_NIL);
v_SYMBOL_7 = LREF(s_pcl__2ATRACED_2DMETHODS_2A);
v_LOOP_2DLIST_2D1722_10 = ((LP) DEREF((LREF(s_pcl__2ATRACED_2DMETHODS_2A)) + 0 * 4));
t_NEXT_2DLOOP_12:;
if (v_LOOP_2DLIST_2D1722_10 == NIL) {
goto t_END_2DLOOP_13;
}
v_X_14 = v_LOOP_2DLIST_2D1722_10;
v_M_9 = ((LP) DEREF((v_X_14) + 0 * 4));
v_X_16 = v_LOOP_2DLIST_2D1722_10;
v_LOOP_2DLIST_2D1722_10 = ((LP) DEREF((v_X_16) + 1 * 4));
CODE_PTR(COERCE_TO_FUNCTION(f_UNTRACE_2D1_2))(1, v_M_9);
goto t_NEXT_2DLOOP_12;
goto t_END_2DLOOP_13;
t_END_2DLOOP_13:;
return(LREF(s_lsp_NIL));
return(NIL);
return(NIL);
}
}

LP p_pcl_UNTRACE_2DMETHOD_2DUNTRACE_2D15120(argc, v_M_0)
      ARGC argc;  LP v_M_0;
{
LP v_V_6; LP v_X_5; LP v_SYMBOL_3; 
LP v_GF_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 

if (argc != 1) wna(argc,1);
v_GF_2 = ICALL(s_pcl_METHOD_2DGENERIC_2DFUNCTION) (1, v_M_0);
if (v_GF_2 != NIL) {
ICALL(s_pcl_REMOVE_2DMETHOD) (2, v_GF_2, v_M_0);
t1 = ICALL(s_pcl_SLOT_2DVALUE) (2, v_M_0, LREF(s_pcl_METHOD));
ICALL(s_pcl_ADD_2DMETHOD) (2, v_GF_2, t1);
v_SYMBOL_3 = LREF(s_pcl__2ATRACED_2DMETHODS_2A);
t2 = ((LP) DEREF((LREF(s_pcl__2ATRACED_2DMETHODS_2A)) + 0 * 4));
v_V_6 = ICALL(s_lsp_REMOVE) (2, v_M_0, t2);
((LP) (DEREF((LREF(s_pcl__2ATRACED_2DMETHODS_2A)) + 0 * 4) = (LD) (v_V_6)));
return(v_V_6);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_pcl_TRACE_2DMETHOD_2DINTERNAL(argc, v_OFUNCTION_0, v_NAME_1, v_OPTIONS_2)
      ARGC argc;  LP v_OFUNCTION_0; LP v_NAME_1; LP v_OPTIONS_2;
{
LP v_X_15; LP v_F_13; LP v_X_12; 
LP v_T7438_11; LP v_S7437_10; LP v_Y_8; 
LP v_X_7; LP v_Y_5; LP v_X_4; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; 
if (argc != 3) wna(argc,3);
v_X_4 = v_NAME_1;
v_Y_5 = LREF(s_lsp_NIL);
v_Y_8 = (c_cons((v_NAME_1), (LREF(s_lsp_NIL))));
t0 = (c_cons((LREF(s_lsp_UNTRACE)), (v_Y_8)));
ICALL(s_lsp_EVAL) (1, t0);
v_S7437_10 = v_OFUNCTION_0;
v_T7438_11 = v_NAME_1;
v_F_13 = v_OFUNCTION_0;
((LP) (DEREF((v_NAME_1) + 4 * 4) = (LD) (v_F_13)));
t1 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_TRACE), v_NAME_1, v_OPTIONS_2);
ICALL(s_lsp_EVAL) (1, t1);
v_X_15 = v_NAME_1;
t2 = ((LP) DEREF((v_NAME_1) + 4 * 4));
return(t2);
}

LP m_pcl_UNDEFMETHOD(argc, v_WHOLE7439_0, v_ENV7440_1)
      ARGC argc;  LP v_WHOLE7439_0; LP v_ENV7440_1;
{
LP v_Y_17; LP v_X_16; LP v_Y_14; 
LP v_X_13; LP v_Y_11; LP v_X_10; 
LP v_Y_8; LP v_X_7; LP v_ARGS_6; 
LP v_L7442_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; 
if (argc != 2) wna(argc,2);
v_X_3 = v_WHOLE7439_0;
v_L7442_5 = ((LP) DEREF((v_WHOLE7439_0) + 1 * 4));
v_ARGS_6 = v_L7442_5;
v_X_7 = v_L7442_5;
v_Y_8 = LREF(s_lsp_NIL);
v_Y_11 = (c_cons((v_L7442_5), (LREF(s_lsp_NIL))));
v_X_13 = (c_cons((LREF(s_lsp_QUOTE)), (v_Y_11)));
v_Y_17 = (c_cons((v_X_13), (LREF(s_lsp_NIL))));
t0 = (c_cons((LREF(s_pcl_UNDEFMETHOD_2D1)), (v_Y_17)));
return(t0);
}

LP p_pcl_UNDEFMETHOD_2D1(argc, v_ARGS_0)
      ARGC argc;  LP v_ARGS_0;
{
LP v_METHOD_3; LP v_GF_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 1) wna(argc,1);
{
int real_argc;
BEGIN_MV_CALL(mv_holder5124,0);
t0 = ICALL(s_pcl_PARSE_2DMETHOD_2DOR_2DSPEC) (MV_CALL(mv_holder5124,1), v_ARGS_0);
SET_MV_RETURN_VALUE(mv_holder5124,0,t0);
if SV_RETURN_P(mv_holder5124) SET_MV_RETURN_COUNT(mv_holder5124,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder5124);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_GF_2 = NIL;
} else {
v_GF_2 = NEXT_VAR_VALUE(mv_holder5124);
}
if (real_argc < 2) {
v_METHOD_3 = NIL;
} else {
v_METHOD_3 = NEXT_VAR_VALUE(mv_holder5124);
}
END_VAR_VALUES;
END_MV_CALL;
if (v_GF_2 != NIL) {
t2 = v_METHOD_3;
} else {
t2 = LREF(s_lsp_NIL);
}
if (t2 != NIL) {
ICALL(s_pcl_REMOVE_2DMETHOD) (2, v_GF_2, v_METHOD_3);
return(v_METHOD_3);
} else {
return(LREF(s_lsp_NIL));
}
}
}

LP p_pcl_ENV_5FINIT1723(argc)
      ARGC argc; 
{
LP v_X_63; LP v_Y_61; LP v_X_60; 
LP v_Y_58; LP v_X_57; LP v_Y_55; 
LP v_X_54; LP v_Y_52; LP v_X_51; 
LP v_Y_49; LP v_X_48; LP v_Y_46; 
LP v_X_45; LP v_Y_43; LP v_X_42; 
LP v_Y_40; LP v_X_39; LP v_X_37; 
LP v_Y_35; LP v_X_34; LP v_Y_32; 
LP v_X_31; LP v_Y_29; LP v_X_28; 
LP v_Y_26; LP v_X_25; LP v_Y_23; 
LP v_X_22; LP v_Y_20; LP v_X_19; 
LP v_Y_17; LP v_X_16; LP v_Y_14; 
LP v_X_13; LP v_F_11; LP v_X_10; 
LP v_T7407_9; LP v_S7406_8; LP v_SYMBOL_6; 
LP v_V_4; LP v_X_3; LP v_X_1; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; 
if (argc != 0) wna(argc,0);
t0 = NEW_OE(2);
ICALL(s_pcl_LOAD_2DDEFGENERIC) (2, LREF(s_pcl_DESCRIBE_2DOBJECT), LREF(k5148));
ICALL(s_lsp_DEFINE_2DVARIABLE) (4, LREF(s_pcl__2AOLD_2DDESCRIBE_2A), LREF(s_lsp_NIL), LREF(s_lsp_NIL), LREF(s_key_VAR));
v_SYMBOL_6 = LREF(s_pcl__2AOLD_2DDESCRIBE_2A);
t1 = ((LP) DEREF((LREF(s_pcl__2AOLD_2DDESCRIBE_2A)) + 0 * 4));
if (t1 == NIL) {
v_X_1 = LREF(s_lsp_DESCRIBE);
v_V_4 = ((LP) DEREF((LREF(s_lsp_DESCRIBE)) + 4 * 4));
((LP) (DEREF((LREF(s_pcl__2AOLD_2DDESCRIBE_2A)) + 0 * 4) = (LD) (v_V_4)));
}
v_S7406_8 = LREF(k5150);
v_T7407_9 = LREF(s_lsp_DESCRIBE);
v_F_11 = v_S7406_8;
((LP) (DEREF((LREF(s_lsp_DESCRIBE)) + 4 * 4) = (LD) (v_F_11)));
v_X_13 = LREF(s_lsp_T);
v_Y_14 = LREF(s_lsp_NIL);
v_Y_17 = (c_cons((LREF(s_lsp_T)), (LREF(s_lsp_NIL))));
t2 = (c_cons((LREF(s_lsp_T)), (v_Y_17)));
ICALL(s_pcl_LOAD_2DDEFMETHOD) (9, LREF(s_pcl_STANDARD_2DMETHOD), LREF(s_pcl_DESCRIBE_2DOBJECT), LREF(s_lsp_NIL), t2, LREF(k5148), LREF(s_lsp_NIL), LREF(s_lsp_NIL), LREF(s_lsp_NIL), LREF(k5151));
v_X_19 = LREF(s_lsp_T);
v_Y_20 = LREF(s_lsp_NIL);
v_Y_23 = (c_cons((LREF(s_lsp_T)), (LREF(s_lsp_NIL))));
t3 = (c_cons((LREF(s_pcl_STANDARD_2DOBJECT)), (v_Y_23)));
t4 = MAKE_CLOSURE(p_pcl_ENV_5FINIT1723_2Danon51295130,t0);
ICALL(s_pcl_LOAD_2DDEFMETHOD) (9, LREF(s_pcl_STANDARD_2DMETHOD), LREF(s_pcl_DESCRIBE_2DOBJECT), LREF(s_lsp_NIL), t3, LREF(k5148), LREF(s_lsp_NIL), LREF(s_lsp_NIL), LREF(s_lsp_NIL), t4);
v_X_25 = LREF(s_pcl_STANDARD_2DOBJECT);
v_Y_26 = LREF(s_lsp_NIL);
v_Y_29 = (c_cons((LREF(s_pcl_STANDARD_2DOBJECT)), (LREF(s_lsp_NIL))));
t5 = (c_cons((LREF(s_pcl_STD_2DCLASS)), (v_Y_29)));
ICALL(s_pcl_LOAD_2DDEFMETHOD) (9, LREF(s_pcl_STANDARD_2DMETHOD), LREF(s_pcl_SLOTS_2DTO_2DINSPECT), LREF(s_lsp_NIL), t5, LREF(k5152), LREF(s_lsp_NIL), LREF(s_lsp_NIL), LREF(s_lsp_NIL), LREF(k5154));
v_X_31 = LREF(s_lsp_T);
v_Y_32 = LREF(s_lsp_NIL);
v_Y_35 = (c_cons((LREF(s_lsp_T)), (LREF(s_lsp_NIL))));
t6 = (c_cons((LREF(s_pcl_CLASS)), (v_Y_35)));
ICALL(s_pcl_LOAD_2DDEFMETHOD) (9, LREF(s_pcl_STANDARD_2DMETHOD), LREF(s_pcl_DESCRIBE_2DOBJECT), LREF(s_lsp_NIL), t6, LREF(k5155), LREF(s_lsp_NIL), LREF(s_lsp_NIL), LREF(s_lsp_NIL), LREF(k5156));
v_X_45 = ICALL(s_lsp_LIST_2A) (9, LREF(s_key_NAME), LREF(s_pcl_METHOD), LREF(s_key_READERS), LREF(s_lsp_NIL), LREF(s_key_WRITERS), LREF(s_lsp_NIL), LREF(s_key_INITARGS), LREF(k5158), LREF(s_lsp_NIL));
v_X_42 = ICALL(s_lsp_LIST_2A) (9, LREF(s_key_NAME), LREF(s_lsp_FUNCTION), LREF(s_key_READERS), LREF(k5159), LREF(s_key_WRITERS), LREF(s_lsp_NIL), LREF(s_key_INITARGS), LREF(k5160), LREF(s_lsp_NIL));
v_X_37 = LREF(s_pcl_FALSE);
t7 = ((LP) DEREF((LREF(s_pcl_FALSE)) + 4 * 4));
v_X_39 = ICALL(s_lsp_LIST_2A) (11, LREF(s_key_INITFUNCTION), t7, LREF(s_key_NAME), LREF(s_pcl_GENERIC_2DFUNCTION), LREF(s_key_READERS), LREF(k5161), LREF(s_key_WRITERS), LREF(k5162), LREF(s_key_INITARGS), LREF(s_lsp_NIL), LREF(k5164));
v_Y_43 = (c_cons((v_X_39), (LREF(s_lsp_NIL))));
v_Y_46 = (c_cons((v_X_42), (v_Y_43)));
t8 = (c_cons((v_X_45), (v_Y_46)));
ICALL(s_pcl_LOAD_2DDEFCLASS) (6, LREF(s_pcl_TRACED_2DMETHOD), LREF(s_pcl_STANDARD_2DCLASS), LREF(k5157), t8, LREF(s_lsp_NIL), LREF(k5161));
v_X_48 = LREF(s_pcl_TRACED_2DMETHOD);
v_Y_49 = LREF(s_lsp_NIL);
t9 = (c_cons((LREF(s_pcl_TRACED_2DMETHOD)), (LREF(s_lsp_NIL))));
ICALL(s_pcl_LOAD_2DDEFMETHOD) (9, LREF(s_pcl_STANDARD_2DMETHOD), LREF(s_pcl_METHOD_2DLAMBDA_2DLIST), LREF(s_lsp_NIL), t9, LREF(k5166), LREF(s_lsp_NIL), LREF(s_pcl_isl_2Dcache1683), LREF(k5167), LREF(k5172));
v_X_51 = LREF(s_pcl_TRACED_2DMETHOD);
v_Y_52 = LREF(s_lsp_NIL);
t10 = (c_cons((LREF(s_pcl_TRACED_2DMETHOD)), (LREF(s_lsp_NIL))));
ICALL(s_pcl_LOAD_2DDEFMETHOD) (9, LREF(s_pcl_STANDARD_2DMETHOD), LREF(s_pcl_METHOD_2DSPECIALIZERS), LREF(s_lsp_NIL), t10, LREF(k5166), LREF(s_lsp_NIL), LREF(s_pcl_isl_2Dcache1691), LREF(k5173), LREF(k5177));
v_X_54 = LREF(s_pcl_TRACED_2DMETHOD);
v_Y_55 = LREF(s_lsp_NIL);
t11 = (c_cons((LREF(s_pcl_TRACED_2DMETHOD)), (LREF(s_lsp_NIL))));
ICALL(s_pcl_LOAD_2DDEFMETHOD) (9, LREF(s_pcl_STANDARD_2DMETHOD), LREF(s_pcl_METHOD_2DQUALIFIERS), LREF(s_lsp_NIL), t11, LREF(k5166), LREF(s_lsp_NIL), LREF(s_pcl_isl_2Dcache1699), LREF(k5178), LREF(k5182));
v_X_57 = LREF(s_pcl_TRACED_2DMETHOD);
v_Y_58 = LREF(s_lsp_NIL);
t12 = (c_cons((LREF(s_pcl_TRACED_2DMETHOD)), (LREF(s_lsp_NIL))));
ICALL(s_pcl_LOAD_2DDEFMETHOD) (9, LREF(s_pcl_STANDARD_2DMETHOD), LREF(s_pcl_METHOD_2DQUALIFIERS), LREF(s_lsp_NIL), t12, LREF(k5166), LREF(s_lsp_NIL), LREF(s_pcl_isl_2Dcache1707), LREF(k5183), LREF(k5187));
v_X_60 = LREF(s_pcl_TRACED_2DMETHOD);
v_Y_61 = LREF(s_lsp_NIL);
t13 = (c_cons((LREF(s_pcl_TRACED_2DMETHOD)), (LREF(s_lsp_NIL))));
ICALL(s_pcl_LOAD_2DDEFMETHOD) (9, LREF(s_pcl_STANDARD_2DMETHOD), LREF(s_pcl_ACCESSOR_2DMETHOD_2DSLOT_2DNAME), LREF(s_lsp_NIL), t13, LREF(k5166), LREF(s_lsp_NIL), LREF(s_pcl_isl_2Dcache1715), LREF(k5188), LREF(k5192));
ICALL(s_lsp_DEFINE_2DVARIABLE) (4, LREF(s_pcl__2ATRACED_2DMETHODS_2A), LREF(s_lsp_NIL), LREF(s_lsp_NIL), LREF(s_key_VAR));
v_X_63 = LREF(s_pcl_UNDEFMETHOD);
t15 = ((LP) DEREF((LREF(s_pcl_UNDEFMETHOD)) + 4 * 4));
t14 = ICALL(s_lsp_DEFINE_2DMACRO) (MV_CALL(argc,2), LREF(s_pcl_UNDEFMETHOD), t15);
return(t14);
}

LP p_pcl_ENV_5FINIT1723_2Danon51465147(argc, v_M_0)
      ARGC argc;  LP v_M_0;
{
LP v_X_136; LP v_Y_134; LP v_X_133; 
LP v_X_131; LP v_Y_129; LP v_X_128; 
LP v_X_126; LP v_X_124; LP v__2EINDEX_2E_123; 
LP v_S7435_122; LP v_S7586_120; LP v_I_118; 
LP v_S_117; LP v_S_115; LP v_S7585_114; 
LP v_I_112; LP v_S_111; LP v_S_109; 
LP v_S7584_108; LP v_I_106; LP v_FIN_105; 
LP v_S7583_104; LP v_I_102; LP v_FIN_101; 
LP v_X_99; LP v_S7582_98; LP v_S7581_97; 
LP v_S7580_96; LP v_S7579_95; LP v_S7578_94; 
LP v_X_92; LP v_S7577_91; LP v_N_89; 
LP v_Y_87; LP v_X_86; LP v_S7576_85; 
LP v_S7575_84; LP v_X_82; LP v_S7574_81; 
LP v_X_79; LP v_S7573_78; LP v_N_76; 
LP v_Y_74; LP v_X_73; LP v_S7572_72; 
LP v_S7571_71; LP v_S7570_70; LP v_S7569_69; 
LP v_S7568_68; LP v_S7567_67; LP v_S7566_66; 
LP v_S7565_65; LP v_S7564_64; LP v_I_62; 
LP v_S_61; LP v_S_59; LP v_S7563_58; 
LP v_I_56; LP v_S_55; LP v_S_53; 
LP v_S7562_52; LP v_I_50; LP v_FIN_49; 
LP v_S7561_48; LP v_I_46; LP v_FIN_45; 
LP v_X_43; LP v_S7560_42; LP v_REG1_27; 
LP v_REG8_26; LP v_REG0_25; LP v_REG4_24; 
LP v_REG7_23; LP v_REG3_22; LP v_REG2_21; 
LP v_REG5_20; LP v_REG6_19; LP v_SYMBOL_17; 
LP v_SYMBOL_15; LP v_SYMBOL_13; LP v_FIELD_11; 
LP v_MASK_10; LP v_SIZE_9; LP v_CACHE_8; 
LP v__2ESLOTS0_2E_7; LP v__2EPV_2E_6; LP v__2EISL_2E_5; 
LP v_SYMBOL_3; LP v_SYMBOL_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; 
if (argc != 1) wna(argc,1);
v_SYMBOL_1 = LREF(s_pcl_isl_2Dcache1715);
v__2EISL_2E_5 = ((LP) DEREF((LREF(s_pcl_isl_2Dcache1715)) + 0 * 4));
v_SYMBOL_3 = LREF(s_pcl__2AEMPTY_2DVECTOR_2A);
v__2EPV_2E_6 = ((LP) DEREF((LREF(s_pcl__2AEMPTY_2DVECTOR_2A)) + 0 * 4));
v__2ESLOTS0_2E_7 = LREF(s_lsp_NIL);
v_CACHE_8 = ICALL(s_lsp_SVREF) (2, v__2EISL_2E_5, (LP) 2);
v_SIZE_9 = ICALL(s_lsp_SVREF) (2, v__2EISL_2E_5, (LP) 8);
v_MASK_10 = ICALL(s_lsp_SVREF) (2, v__2EISL_2E_5, (LP) 6);
v_FIELD_11 = ICALL(s_lsp_SVREF) (2, v__2EISL_2E_5, (LP) 4);
v_REG6_19 = (LP) 0;
v_REG5_20 = (LP) 0;
v_REG2_21 = (LP) 0;
v_REG3_22 = (LP) 0;
v_SYMBOL_13 = LREF(s_pcl__2AEMPTY_2DVECTOR_2A);
v_REG7_23 = ((LP) DEREF((LREF(s_pcl__2AEMPTY_2DVECTOR_2A)) + 0 * 4));
v_SYMBOL_15 = LREF(s_pcl__2AEMPTY_2DVECTOR_2A);
v_REG4_24 = ((LP) DEREF((LREF(s_pcl__2AEMPTY_2DVECTOR_2A)) + 0 * 4));
v_SYMBOL_17 = LREF(s_pcl__2AEMPTY_2DVECTOR_2A);
v_REG0_25 = ((LP) DEREF((LREF(s_pcl__2AEMPTY_2DVECTOR_2A)) + 0 * 4));
v_REG8_26 = LREF(s_lsp_NIL);
v_REG1_27 = LREF(s_lsp_NIL);
v_S7560_42 = v_M_0;
v_REG1_27 = v_M_0;
t0 = ICALL(s_pcl_STD_2DINSTANCE_2DP) (1, v_REG1_27);
if (t0 != NIL) {
goto t_get_2Dstd_2Dinst_2Dwrapper1717_29;
}
v_X_43 = v_REG1_27;
if (OTHER_PTRP((v_X_43)) && (TAG((v_X_43)) == 39)) {
t3 = INT_TO_FX((LP) (DEREF((v_X_43) - 4) >> 8));
t1 = (((t3) == ((LP) 11356)) ? T : NIL);
} else {
t1 = LREF(s_lsp_NIL);
}
if (t1 != NIL) {
goto t_get_2Dfsc_2Dinst_2Dwrapper1718_28;
}
goto t_PV_2DMISS_35;
t_get_2Dfsc_2Dinst_2Dwrapper1718_28:;
v_FIN_45 = v_REG1_27;
v_S7561_48 = ((LP) DEREF((v_FIN_45) + 1 * 4));
v_REG0_25 = v_S7561_48;
v_FIN_49 = v_REG1_27;
v_S7562_52 = ((LP) DEREF((v_FIN_49) + 2 * 4));
v__2ESLOTS0_2E_7 = v_S7562_52;
goto t_exit_2Demit_2Dfetch_2Dwrapper1716_30;
t_get_2Dstd_2Dinst_2Dwrapper1717_29:;
v_S_53 = v_REG1_27;
v_S_55 = v_S_53;
v_I_56 = (LP) 2;
v_S7563_58 = ((LP) DEREF((v_S_53) + 1 * 4));
v_REG0_25 = v_S7563_58;
v_S_59 = v_REG1_27;
v_S_61 = v_S_59;
v_I_62 = (LP) 4;
v_S7564_64 = ((LP) DEREF((v_S_59) + 2 * 4));
v__2ESLOTS0_2E_7 = v_S7564_64;
t_exit_2Demit_2Dfetch_2Dwrapper1716_30:;
v_S7565_65 = v_CACHE_8;
v_REG4_24 = v_CACHE_8;
v_S7566_66 = v_MASK_10;
v_REG6_19 = v_MASK_10;
v_S7567_67 = v_FIELD_11;
v_REG5_20 = v_FIELD_11;
v_S7568_68 = ICALL(s_lsp_SVREF) (2, v_REG0_25, v_REG5_20);
v_REG5_20 = v_S7568_68;
v_S7569_69 = (((LP) ((int) (v_REG5_20) & (int) (v_REG6_19))));
v_REG3_22 = v_S7569_69;
v_S7570_70 = v_REG3_22;
v_REG2_21 = v_S7570_70;
v_S7571_71 = ICALL(s_lsp_SVREF) (2, v_REG4_24, (LP) 0);
v_REG1_27 = v_S7571_71;
v_S7572_72 = ICALL(s_lsp_SVREF) (2, v_REG4_24, v_REG2_21);
v_REG7_23 = v_S7572_72;
v_X_73 = v_REG7_23;
v_Y_74 = v_REG0_25;
if (((v_X_73) == (v_Y_74))) {
goto t_HIT_2DINTERNAL_34;
}
v_N_76 = v_REG5_20;
if (((int) (v_N_76) == (int) ((LP) 0))) {
goto t_PV_2DMISS_35;
}
v_S7573_78 = v_SIZE_9;
v_REG5_20 = v_SIZE_9;
t_LOOP_31:;
v_X_79 = v_REG2_21;
v_S7574_81 = (add((v_X_79), ((LP) 2)));
v_REG2_21 = v_S7574_81;
v_X_82 = v_REG2_21;
v_S7575_84 = (add((v_X_82), ((LP) 2)));
v_REG2_21 = v_S7575_84;
t_CONTINUE_32:;
if (((int) (v_REG2_21) == (int) (v_REG3_22))) {
goto t_PV_2DMISS_35;
}
if (((int) (v_REG2_21) == (int) (v_REG5_20))) {
goto t_SET_2DLOCATION_2DTO_2DMIN_33;
}
v_S7576_85 = ICALL(s_lsp_SVREF) (2, v_REG4_24, v_REG2_21);
v_REG7_23 = v_S7576_85;
v_X_86 = v_REG7_23;
v_Y_87 = v_REG0_25;
if (((v_X_86) == (v_Y_87))) {
goto t_HIT_2DINTERNAL_34;
}
goto t_LOOP_31;
t_SET_2DLOCATION_2DTO_2DMIN_33:;
v_N_89 = v_REG3_22;
if (((int) (v_N_89) == (int) ((LP) 0))) {
goto t_PV_2DMISS_35;
}
v_S7577_91 = (LP) 4;
v_REG2_21 = (LP) 4;
goto t_CONTINUE_32;
t_HIT_2DINTERNAL_34:;
v_X_92 = v_REG2_21;
v_S7578_94 = (add((v_X_92), ((LP) 2)));
v_REG2_21 = v_S7578_94;
v_S7579_95 = ICALL(s_lsp_SVREF) (2, v_REG4_24, v_REG2_21);
v__2EPV_2E_6 = v_S7579_95;
v_S7580_96 = ICALL(s_lsp_SVREF) (2, v_REG4_24, (LP) 0);
v_REG8_26 = v_S7580_96;
t10 = (num_equal_p((v_REG8_26), (v_REG1_27)));
if (t10 != NIL) {
goto t_HIT_40;
}
t_PV_2DMISS_35:;
v_S7581_97 = ICALL(s_pcl_PRIMARY_2DPV_2DCACHE_2DMISS) (2, v__2EISL_2E_5, v_M_0);
v__2EPV_2E_6 = v_S7581_97;
v_S7582_98 = v_M_0;
v_REG1_27 = v_M_0;
t11 = ICALL(s_pcl_STD_2DINSTANCE_2DP) (1, v_REG1_27);
if (t11 != NIL) {
goto t_get_2Dstd_2Dinst_2Dwrapper1720_37;
}
v_X_99 = v_REG1_27;
if (OTHER_PTRP((v_X_99)) && (TAG((v_X_99)) == 39)) {
t14 = INT_TO_FX((LP) (DEREF((v_X_99) - 4) >> 8));
t12 = (((t14) == ((LP) 11356)) ? T : NIL);
} else {
t12 = LREF(s_lsp_NIL);
}
if (t12 != NIL) {
goto t_get_2Dfsc_2Dinst_2Dwrapper1721_36;
}
goto t_PV_2DWRAPPER_2DMISS_39;
t_get_2Dfsc_2Dinst_2Dwrapper1721_36:;
v_FIN_101 = v_REG1_27;
v_S7583_104 = ((LP) DEREF((v_FIN_101) + 1 * 4));
v_REG0_25 = v_S7583_104;
v_FIN_105 = v_REG1_27;
v_S7584_108 = ((LP) DEREF((v_FIN_105) + 2 * 4));
v__2ESLOTS0_2E_7 = v_S7584_108;
goto t_exit_2Demit_2Dfetch_2Dwrapper1719_38;
t_get_2Dstd_2Dinst_2Dwrapper1720_37:;
v_S_109 = v_REG1_27;
v_S_111 = v_S_109;
v_I_112 = (LP) 2;
v_S7585_114 = ((LP) DEREF((v_S_109) + 1 * 4));
v_REG0_25 = v_S7585_114;
v_S_115 = v_REG1_27;
v_S_117 = v_S_115;
v_I_118 = (LP) 4;
v_S7586_120 = ((LP) DEREF((v_S_115) + 2 * 4));
v__2ESLOTS0_2E_7 = v_S7586_120;
t_exit_2Demit_2Dfetch_2Dwrapper1719_38:;
t_PV_2DWRAPPER_2DMISS_39:;
goto t_EXIT_2DLAP_2DIN_2DLISP_41;
t_HIT_40:;
goto t_EXIT_2DLAP_2DIN_2DLISP_41;
t_EXIT_2DLAP_2DIN_2DLISP_41:;
v_S7435_122 = v_M_0;
v__2EINDEX_2E_123 = ICALL(s_lsp_SVREF) (2, v__2EPV_2E_6, (LP) 0);
v_X_136 = v__2EINDEX_2E_123;
if (FIXNUMP((v_X_136))) {
v__2EINDEX_2E_123 = ICALL(s_lsp_SVREF) (2, v__2ESLOTS0_2E_7, v__2EINDEX_2E_123);
v_X_128 = v__2EINDEX_2E_123;
v_X_131 = (((v_X_128) == (LREF(s_pcl__2E_2ESLOT_2DUNBOUND_2E_2E))) ? T : NIL);
v_X_133 = v_X_131;
v_Y_134 = LREF(s_lsp_NIL);
t17 = (((v_X_131) == (LREF(s_lsp_NIL))) ? T : NIL);
} else {
t17 = LREF(s_lsp_NIL);
}
if (t17 != NIL) {
t16 = v__2EINDEX_2E_123;
} else {
v_X_126 = v__2EINDEX_2E_123;
if (OTHER_PTRP((v_X_126)) && (TAG((v_X_126)) == 15)) {
v_X_124 = v__2EINDEX_2E_123;
t16 = ((LP) DEREF((v_X_124) + 1 * 4));
} else {
t16 = ICALL(s_pcl_SLOT_2DVALUE) (2, v_M_0, LREF(s_pcl_METHOD));
}
}
t15 = ICALL(s_pcl_ACCESSOR_2DMETHOD_2DSLOT_2DNAME) (MV_CALL(argc,1), t16);
return(t15);
}

LP p_pcl_ENV_5FINIT1723_2Danon51445145(argc, v_M_0)
      ARGC argc;  LP v_M_0;
{
LP v_X_136; LP v_Y_134; LP v_X_133; 
LP v_X_131; LP v_Y_129; LP v_X_128; 
LP v_X_126; LP v_X_124; LP v__2EINDEX_2E_123; 
LP v_S7433_122; LP v_S7559_120; LP v_I_118; 
LP v_S_117; LP v_S_115; LP v_S7558_114; 
LP v_I_112; LP v_S_111; LP v_S_109; 
LP v_S7557_108; LP v_I_106; LP v_FIN_105; 
LP v_S7556_104; LP v_I_102; LP v_FIN_101; 
LP v_X_99; LP v_S7555_98; LP v_S7554_97; 
LP v_S7553_96; LP v_S7552_95; LP v_S7551_94; 
LP v_X_92; LP v_S7550_91; LP v_N_89; 
LP v_Y_87; LP v_X_86; LP v_S7549_85; 
LP v_S7548_84; LP v_X_82; LP v_S7547_81; 
LP v_X_79; LP v_S7546_78; LP v_N_76; 
LP v_Y_74; LP v_X_73; LP v_S7545_72; 
LP v_S7544_71; LP v_S7543_70; LP v_S7542_69; 
LP v_S7541_68; LP v_S7540_67; LP v_S7539_66; 
LP v_S7538_65; LP v_S7537_64; LP v_I_62; 
LP v_S_61; LP v_S_59; LP v_S7536_58; 
LP v_I_56; LP v_S_55; LP v_S_53; 
LP v_S7535_52; LP v_I_50; LP v_FIN_49; 
LP v_S7534_48; LP v_I_46; LP v_FIN_45; 
LP v_X_43; LP v_S7533_42; LP v_REG1_27; 
LP v_REG8_26; LP v_REG0_25; LP v_REG4_24; 
LP v_REG7_23; LP v_REG3_22; LP v_REG2_21; 
LP v_REG5_20; LP v_REG6_19; LP v_SYMBOL_17; 
LP v_SYMBOL_15; LP v_SYMBOL_13; LP v_FIELD_11; 
LP v_MASK_10; LP v_SIZE_9; LP v_CACHE_8; 
LP v__2ESLOTS0_2E_7; LP v__2EPV_2E_6; LP v__2EISL_2E_5; 
LP v_SYMBOL_3; LP v_SYMBOL_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; 
if (argc != 1) wna(argc,1);
v_SYMBOL_1 = LREF(s_pcl_isl_2Dcache1707);
v__2EISL_2E_5 = ((LP) DEREF((LREF(s_pcl_isl_2Dcache1707)) + 0 * 4));
v_SYMBOL_3 = LREF(s_pcl__2AEMPTY_2DVECTOR_2A);
v__2EPV_2E_6 = ((LP) DEREF((LREF(s_pcl__2AEMPTY_2DVECTOR_2A)) + 0 * 4));
v__2ESLOTS0_2E_7 = LREF(s_lsp_NIL);
v_CACHE_8 = ICALL(s_lsp_SVREF) (2, v__2EISL_2E_5, (LP) 2);
v_SIZE_9 = ICALL(s_lsp_SVREF) (2, v__2EISL_2E_5, (LP) 8);
v_MASK_10 = ICALL(s_lsp_SVREF) (2, v__2EISL_2E_5, (LP) 6);
v_FIELD_11 = ICALL(s_lsp_SVREF) (2, v__2EISL_2E_5, (LP) 4);
v_REG6_19 = (LP) 0;
v_REG5_20 = (LP) 0;
v_REG2_21 = (LP) 0;
v_REG3_22 = (LP) 0;
v_SYMBOL_13 = LREF(s_pcl__2AEMPTY_2DVECTOR_2A);
v_REG7_23 = ((LP) DEREF((LREF(s_pcl__2AEMPTY_2DVECTOR_2A)) + 0 * 4));
v_SYMBOL_15 = LREF(s_pcl__2AEMPTY_2DVECTOR_2A);
v_REG4_24 = ((LP) DEREF((LREF(s_pcl__2AEMPTY_2DVECTOR_2A)) + 0 * 4));
v_SYMBOL_17 = LREF(s_pcl__2AEMPTY_2DVECTOR_2A);
v_REG0_25 = ((LP) DEREF((LREF(s_pcl__2AEMPTY_2DVECTOR_2A)) + 0 * 4));
v_REG8_26 = LREF(s_lsp_NIL);
v_REG1_27 = LREF(s_lsp_NIL);
v_S7533_42 = v_M_0;
v_REG1_27 = v_M_0;
t0 = ICALL(s_pcl_STD_2DINSTANCE_2DP) (1, v_REG1_27);
if (t0 != NIL) {
goto t_get_2Dstd_2Dinst_2Dwrapper1709_29;
}
v_X_43 = v_REG1_27;
if (OTHER_PTRP((v_X_43)) && (TAG((v_X_43)) == 39)) {
t3 = INT_TO_FX((LP) (DEREF((v_X_43) - 4) >> 8));
t1 = (((t3) == ((LP) 11356)) ? T : NIL);
} else {
t1 = LREF(s_lsp_NIL);
}
if (t1 != NIL) {
goto t_get_2Dfsc_2Dinst_2Dwrapper1710_28;
}
goto t_PV_2DMISS_35;
t_get_2Dfsc_2Dinst_2Dwrapper1710_28:;
v_FIN_45 = v_REG1_27;
v_S7534_48 = ((LP) DEREF((v_FIN_45) + 1 * 4));
v_REG0_25 = v_S7534_48;
v_FIN_49 = v_REG1_27;
v_S7535_52 = ((LP) DEREF((v_FIN_49) + 2 * 4));
v__2ESLOTS0_2E_7 = v_S7535_52;
goto t_exit_2Demit_2Dfetch_2Dwrapper1708_30;
t_get_2Dstd_2Dinst_2Dwrapper1709_29:;
v_S_53 = v_REG1_27;
v_S_55 = v_S_53;
v_I_56 = (LP) 2;
v_S7536_58 = ((LP) DEREF((v_S_53) + 1 * 4));
v_REG0_25 = v_S7536_58;
v_S_59 = v_REG1_27;
v_S_61 = v_S_59;
v_I_62 = (LP) 4;
v_S7537_64 = ((LP) DEREF((v_S_59) + 2 * 4));
v__2ESLOTS0_2E_7 = v_S7537_64;
t_exit_2Demit_2Dfetch_2Dwrapper1708_30:;
v_S7538_65 = v_CACHE_8;
v_REG4_24 = v_CACHE_8;
v_S7539_66 = v_MASK_10;
v_REG6_19 = v_MASK_10;
v_S7540_67 = v_FIELD_11;
v_REG5_20 = v_FIELD_11;
v_S7541_68 = ICALL(s_lsp_SVREF) (2, v_REG0_25, v_REG5_20);
v_REG5_20 = v_S7541_68;
v_S7542_69 = (((LP) ((int) (v_REG5_20) & (int) (v_REG6_19))));
v_REG3_22 = v_S7542_69;
v_S7543_70 = v_REG3_22;
v_REG2_21 = v_S7543_70;
v_S7544_71 = ICALL(s_lsp_SVREF) (2, v_REG4_24, (LP) 0);
v_REG1_27 = v_S7544_71;
v_S7545_72 = ICALL(s_lsp_SVREF) (2, v_REG4_24, v_REG2_21);
v_REG7_23 = v_S7545_72;
v_X_73 = v_REG7_23;
v_Y_74 = v_REG0_25;
if (((v_X_73) == (v_Y_74))) {
goto t_HIT_2DINTERNAL_34;
}
v_N_76 = v_REG5_20;
if (((int) (v_N_76) == (int) ((LP) 0))) {
goto t_PV_2DMISS_35;
}
v_S7546_78 = v_SIZE_9;
v_REG5_20 = v_SIZE_9;
t_LOOP_31:;
v_X_79 = v_REG2_21;
v_S7547_81 = (add((v_X_79), ((LP) 2)));
v_REG2_21 = v_S7547_81;
v_X_82 = v_REG2_21;
v_S7548_84 = (add((v_X_82), ((LP) 2)));
v_REG2_21 = v_S7548_84;
t_CONTINUE_32:;
if (((int) (v_REG2_21) == (int) (v_REG3_22))) {
goto t_PV_2DMISS_35;
}
if (((int) (v_REG2_21) == (int) (v_REG5_20))) {
goto t_SET_2DLOCATION_2DTO_2DMIN_33;
}
v_S7549_85 = ICALL(s_lsp_SVREF) (2, v_REG4_24, v_REG2_21);
v_REG7_23 = v_S7549_85;
v_X_86 = v_REG7_23;
v_Y_87 = v_REG0_25;
if (((v_X_86) == (v_Y_87))) {
goto t_HIT_2DINTERNAL_34;
}
goto t_LOOP_31;
t_SET_2DLOCATION_2DTO_2DMIN_33:;
v_N_89 = v_REG3_22;
if (((int) (v_N_89) == (int) ((LP) 0))) {
goto t_PV_2DMISS_35;
}
v_S7550_91 = (LP) 4;
v_REG2_21 = (LP) 4;
goto t_CONTINUE_32;
t_HIT_2DINTERNAL_34:;
v_X_92 = v_REG2_21;
v_S7551_94 = (add((v_X_92), ((LP) 2)));
v_REG2_21 = v_S7551_94;
v_S7552_95 = ICALL(s_lsp_SVREF) (2, v_REG4_24, v_REG2_21);
v__2EPV_2E_6 = v_S7552_95;
v_S7553_96 = ICALL(s_lsp_SVREF) (2, v_REG4_24, (LP) 0);
v_REG8_26 = v_S7553_96;
t10 = (num_equal_p((v_REG8_26), (v_REG1_27)));
if (t10 != NIL) {
goto t_HIT_40;
}
t_PV_2DMISS_35:;
v_S7554_97 = ICALL(s_pcl_PRIMARY_2DPV_2DCACHE_2DMISS) (2, v__2EISL_2E_5, v_M_0);
v__2EPV_2E_6 = v_S7554_97;
v_S7555_98 = v_M_0;
v_REG1_27 = v_M_0;
t11 = ICALL(s_pcl_STD_2DINSTANCE_2DP) (1, v_REG1_27);
if (t11 != NIL) {
goto t_get_2Dstd_2Dinst_2Dwrapper1712_37;
}
v_X_99 = v_REG1_27;
if (OTHER_PTRP((v_X_99)) && (TAG((v_X_99)) == 39)) {
t14 = INT_TO_FX((LP) (DEREF((v_X_99) - 4) >> 8));
t12 = (((t14) == ((LP) 11356)) ? T : NIL);
} else {
t12 = LREF(s_lsp_NIL);
}
if (t12 != NIL) {
goto t_get_2Dfsc_2Dinst_2Dwrapper1713_36;
}
goto t_PV_2DWRAPPER_2DMISS_39;
t_get_2Dfsc_2Dinst_2Dwrapper1713_36:;
v_FIN_101 = v_REG1_27;
v_S7556_104 = ((LP) DEREF((v_FIN_101) + 1 * 4));
v_REG0_25 = v_S7556_104;
v_FIN_105 = v_REG1_27;
v_S7557_108 = ((LP) DEREF((v_FIN_105) + 2 * 4));
v__2ESLOTS0_2E_7 = v_S7557_108;
goto t_exit_2Demit_2Dfetch_2Dwrapper1711_38;
t_get_2Dstd_2Dinst_2Dwrapper1712_37:;
v_S_109 = v_REG1_27;
v_S_111 = v_S_109;
v_I_112 = (LP) 2;
v_S7558_114 = ((LP) DEREF((v_S_109) + 1 * 4));
v_REG0_25 = v_S7558_114;
v_S_115 = v_REG1_27;
v_S_117 = v_S_115;
v_I_118 = (LP) 4;
v_S7559_120 = ((LP) DEREF((v_S_115) + 2 * 4));
v__2ESLOTS0_2E_7 = v_S7559_120;
t_exit_2Demit_2Dfetch_2Dwrapper1711_38:;
t_PV_2DWRAPPER_2DMISS_39:;
goto t_EXIT_2DLAP_2DIN_2DLISP_41;
t_HIT_40:;
goto t_EXIT_2DLAP_2DIN_2DLISP_41;
t_EXIT_2DLAP_2DIN_2DLISP_41:;
v_S7433_122 = v_M_0;
v__2EINDEX_2E_123 = ICALL(s_lsp_SVREF) (2, v__2EPV_2E_6, (LP) 0);
v_X_136 = v__2EINDEX_2E_123;
if (FIXNUMP((v_X_136))) {
v__2EINDEX_2E_123 = ICALL(s_lsp_SVREF) (2, v__2ESLOTS0_2E_7, v__2EINDEX_2E_123);
v_X_128 = v__2EINDEX_2E_123;
v_X_131 = (((v_X_128) == (LREF(s_pcl__2E_2ESLOT_2DUNBOUND_2E_2E))) ? T : NIL);
v_X_133 = v_X_131;
v_Y_134 = LREF(s_lsp_NIL);
t17 = (((v_X_131) == (LREF(s_lsp_NIL))) ? T : NIL);
} else {
t17 = LREF(s_lsp_NIL);
}
if (t17 != NIL) {
t16 = v__2EINDEX_2E_123;
} else {
v_X_126 = v__2EINDEX_2E_123;
if (OTHER_PTRP((v_X_126)) && (TAG((v_X_126)) == 15)) {
v_X_124 = v__2EINDEX_2E_123;
t16 = ((LP) DEREF((v_X_124) + 1 * 4));
} else {
t16 = ICALL(s_pcl_SLOT_2DVALUE) (2, v_M_0, LREF(s_pcl_METHOD));
}
}
t15 = ICALL(s_pcl_METHOD_2DQUALIFIERS) (MV_CALL(argc,1), t16);
return(t15);
}

LP p_pcl_ENV_5FINIT1723_2Danon51425143(argc, v_M_0)
      ARGC argc;  LP v_M_0;
{
LP v_X_136; LP v_Y_134; LP v_X_133; 
LP v_X_131; LP v_Y_129; LP v_X_128; 
LP v_X_126; LP v_X_124; LP v__2EINDEX_2E_123; 
LP v_S7431_122; LP v_S7532_120; LP v_I_118; 
LP v_S_117; LP v_S_115; LP v_S7531_114; 
LP v_I_112; LP v_S_111; LP v_S_109; 
LP v_S7530_108; LP v_I_106; LP v_FIN_105; 
LP v_S7529_104; LP v_I_102; LP v_FIN_101; 
LP v_X_99; LP v_S7528_98; LP v_S7527_97; 
LP v_S7526_96; LP v_S7525_95; LP v_S7524_94; 
LP v_X_92; LP v_S7523_91; LP v_N_89; 
LP v_Y_87; LP v_X_86; LP v_S7522_85; 
LP v_S7521_84; LP v_X_82; LP v_S7520_81; 
LP v_X_79; LP v_S7519_78; LP v_N_76; 
LP v_Y_74; LP v_X_73; LP v_S7518_72; 
LP v_S7517_71; LP v_S7516_70; LP v_S7515_69; 
LP v_S7514_68; LP v_S7513_67; LP v_S7512_66; 
LP v_S7511_65; LP v_S7510_64; LP v_I_62; 
LP v_S_61; LP v_S_59; LP v_S7509_58; 
LP v_I_56; LP v_S_55; LP v_S_53; 
LP v_S7508_52; LP v_I_50; LP v_FIN_49; 
LP v_S7507_48; LP v_I_46; LP v_FIN_45; 
LP v_X_43; LP v_S7506_42; LP v_REG1_27; 
LP v_REG8_26; LP v_REG0_25; LP v_REG4_24; 
LP v_REG7_23; LP v_REG3_22; LP v_REG2_21; 
LP v_REG5_20; LP v_REG6_19; LP v_SYMBOL_17; 
LP v_SYMBOL_15; LP v_SYMBOL_13; LP v_FIELD_11; 
LP v_MASK_10; LP v_SIZE_9; LP v_CACHE_8; 
LP v__2ESLOTS0_2E_7; LP v__2EPV_2E_6; LP v__2EISL_2E_5; 
LP v_SYMBOL_3; LP v_SYMBOL_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; 
if (argc != 1) wna(argc,1);
v_SYMBOL_1 = LREF(s_pcl_isl_2Dcache1699);
v__2EISL_2E_5 = ((LP) DEREF((LREF(s_pcl_isl_2Dcache1699)) + 0 * 4));
v_SYMBOL_3 = LREF(s_pcl__2AEMPTY_2DVECTOR_2A);
v__2EPV_2E_6 = ((LP) DEREF((LREF(s_pcl__2AEMPTY_2DVECTOR_2A)) + 0 * 4));
v__2ESLOTS0_2E_7 = LREF(s_lsp_NIL);
v_CACHE_8 = ICALL(s_lsp_SVREF) (2, v__2EISL_2E_5, (LP) 2);
v_SIZE_9 = ICALL(s_lsp_SVREF) (2, v__2EISL_2E_5, (LP) 8);
v_MASK_10 = ICALL(s_lsp_SVREF) (2, v__2EISL_2E_5, (LP) 6);
v_FIELD_11 = ICALL(s_lsp_SVREF) (2, v__2EISL_2E_5, (LP) 4);
v_REG6_19 = (LP) 0;
v_REG5_20 = (LP) 0;
v_REG2_21 = (LP) 0;
v_REG3_22 = (LP) 0;
v_SYMBOL_13 = LREF(s_pcl__2AEMPTY_2DVECTOR_2A);
v_REG7_23 = ((LP) DEREF((LREF(s_pcl__2AEMPTY_2DVECTOR_2A)) + 0 * 4));
v_SYMBOL_15 = LREF(s_pcl__2AEMPTY_2DVECTOR_2A);
v_REG4_24 = ((LP) DEREF((LREF(s_pcl__2AEMPTY_2DVECTOR_2A)) + 0 * 4));
v_SYMBOL_17 = LREF(s_pcl__2AEMPTY_2DVECTOR_2A);
v_REG0_25 = ((LP) DEREF((LREF(s_pcl__2AEMPTY_2DVECTOR_2A)) + 0 * 4));
v_REG8_26 = LREF(s_lsp_NIL);
v_REG1_27 = LREF(s_lsp_NIL);
v_S7506_42 = v_M_0;
v_REG1_27 = v_M_0;
t0 = ICALL(s_pcl_STD_2DINSTANCE_2DP) (1, v_REG1_27);
if (t0 != NIL) {
goto t_get_2Dstd_2Dinst_2Dwrapper1701_29;
}
v_X_43 = v_REG1_27;
if (OTHER_PTRP((v_X_43)) && (TAG((v_X_43)) == 39)) {
t3 = INT_TO_FX((LP) (DEREF((v_X_43) - 4) >> 8));
t1 = (((t3) == ((LP) 11356)) ? T : NIL);
} else {
t1 = LREF(s_lsp_NIL);
}
if (t1 != NIL) {
goto t_get_2Dfsc_2Dinst_2Dwrapper1702_28;
}
goto t_PV_2DMISS_35;
t_get_2Dfsc_2Dinst_2Dwrapper1702_28:;
v_FIN_45 = v_REG1_27;
v_S7507_48 = ((LP) DEREF((v_FIN_45) + 1 * 4));
v_REG0_25 = v_S7507_48;
v_FIN_49 = v_REG1_27;
v_S7508_52 = ((LP) DEREF((v_FIN_49) + 2 * 4));
v__2ESLOTS0_2E_7 = v_S7508_52;
goto t_exit_2Demit_2Dfetch_2Dwrapper1700_30;
t_get_2Dstd_2Dinst_2Dwrapper1701_29:;
v_S_53 = v_REG1_27;
v_S_55 = v_S_53;
v_I_56 = (LP) 2;
v_S7509_58 = ((LP) DEREF((v_S_53) + 1 * 4));
v_REG0_25 = v_S7509_58;
v_S_59 = v_REG1_27;
v_S_61 = v_S_59;
v_I_62 = (LP) 4;
v_S7510_64 = ((LP) DEREF((v_S_59) + 2 * 4));
v__2ESLOTS0_2E_7 = v_S7510_64;
t_exit_2Demit_2Dfetch_2Dwrapper1700_30:;
v_S7511_65 = v_CACHE_8;
v_REG4_24 = v_CACHE_8;
v_S7512_66 = v_MASK_10;
v_REG6_19 = v_MASK_10;
v_S7513_67 = v_FIELD_11;
v_REG5_20 = v_FIELD_11;
v_S7514_68 = ICALL(s_lsp_SVREF) (2, v_REG0_25, v_REG5_20);
v_REG5_20 = v_S7514_68;
v_S7515_69 = (((LP) ((int) (v_REG5_20) & (int) (v_REG6_19))));
v_REG3_22 = v_S7515_69;
v_S7516_70 = v_REG3_22;
v_REG2_21 = v_S7516_70;
v_S7517_71 = ICALL(s_lsp_SVREF) (2, v_REG4_24, (LP) 0);
v_REG1_27 = v_S7517_71;
v_S7518_72 = ICALL(s_lsp_SVREF) (2, v_REG4_24, v_REG2_21);
v_REG7_23 = v_S7518_72;
v_X_73 = v_REG7_23;
v_Y_74 = v_REG0_25;
if (((v_X_73) == (v_Y_74))) {
goto t_HIT_2DINTERNAL_34;
}
v_N_76 = v_REG5_20;
if (((int) (v_N_76) == (int) ((LP) 0))) {
goto t_PV_2DMISS_35;
}
v_S7519_78 = v_SIZE_9;
v_REG5_20 = v_SIZE_9;
t_LOOP_31:;
v_X_79 = v_REG2_21;
v_S7520_81 = (add((v_X_79), ((LP) 2)));
v_REG2_21 = v_S7520_81;
v_X_82 = v_REG2_21;
v_S7521_84 = (add((v_X_82), ((LP) 2)));
v_REG2_21 = v_S7521_84;
t_CONTINUE_32:;
if (((int) (v_REG2_21) == (int) (v_REG3_22))) {
goto t_PV_2DMISS_35;
}
if (((int) (v_REG2_21) == (int) (v_REG5_20))) {
goto t_SET_2DLOCATION_2DTO_2DMIN_33;
}
v_S7522_85 = ICALL(s_lsp_SVREF) (2, v_REG4_24, v_REG2_21);
v_REG7_23 = v_S7522_85;
v_X_86 = v_REG7_23;
v_Y_87 = v_REG0_25;
if (((v_X_86) == (v_Y_87))) {
goto t_HIT_2DINTERNAL_34;
}
goto t_LOOP_31;
t_SET_2DLOCATION_2DTO_2DMIN_33:;
v_N_89 = v_REG3_22;
if (((int) (v_N_89) == (int) ((LP) 0))) {
goto t_PV_2DMISS_35;
}
v_S7523_91 = (LP) 4;
v_REG2_21 = (LP) 4;
goto t_CONTINUE_32;
t_HIT_2DINTERNAL_34:;
v_X_92 = v_REG2_21;
v_S7524_94 = (add((v_X_92), ((LP) 2)));
v_REG2_21 = v_S7524_94;
v_S7525_95 = ICALL(s_lsp_SVREF) (2, v_REG4_24, v_REG2_21);
v__2EPV_2E_6 = v_S7525_95;
v_S7526_96 = ICALL(s_lsp_SVREF) (2, v_REG4_24, (LP) 0);
v_REG8_26 = v_S7526_96;
t10 = (num_equal_p((v_REG8_26), (v_REG1_27)));
if (t10 != NIL) {
goto t_HIT_40;
}
t_PV_2DMISS_35:;
v_S7527_97 = ICALL(s_pcl_PRIMARY_2DPV_2DCACHE_2DMISS) (2, v__2EISL_2E_5, v_M_0);
v__2EPV_2E_6 = v_S7527_97;
v_S7528_98 = v_M_0;
v_REG1_27 = v_M_0;
t11 = ICALL(s_pcl_STD_2DINSTANCE_2DP) (1, v_REG1_27);
if (t11 != NIL) {
goto t_get_2Dstd_2Dinst_2Dwrapper1704_37;
}
v_X_99 = v_REG1_27;
if (OTHER_PTRP((v_X_99)) && (TAG((v_X_99)) == 39)) {
t14 = INT_TO_FX((LP) (DEREF((v_X_99) - 4) >> 8));
t12 = (((t14) == ((LP) 11356)) ? T : NIL);
} else {
t12 = LREF(s_lsp_NIL);
}
if (t12 != NIL) {
goto t_get_2Dfsc_2Dinst_2Dwrapper1705_36;
}
goto t_PV_2DWRAPPER_2DMISS_39;
t_get_2Dfsc_2Dinst_2Dwrapper1705_36:;
v_FIN_101 = v_REG1_27;
v_S7529_104 = ((LP) DEREF((v_FIN_101) + 1 * 4));
v_REG0_25 = v_S7529_104;
v_FIN_105 = v_REG1_27;
v_S7530_108 = ((LP) DEREF((v_FIN_105) + 2 * 4));
v__2ESLOTS0_2E_7 = v_S7530_108;
goto t_exit_2Demit_2Dfetch_2Dwrapper1703_38;
t_get_2Dstd_2Dinst_2Dwrapper1704_37:;
v_S_109 = v_REG1_27;
v_S_111 = v_S_109;
v_I_112 = (LP) 2;
v_S7531_114 = ((LP) DEREF((v_S_109) + 1 * 4));
v_REG0_25 = v_S7531_114;
v_S_115 = v_REG1_27;
v_S_117 = v_S_115;
v_I_118 = (LP) 4;
v_S7532_120 = ((LP) DEREF((v_S_115) + 2 * 4));
v__2ESLOTS0_2E_7 = v_S7532_120;
t_exit_2Demit_2Dfetch_2Dwrapper1703_38:;
t_PV_2DWRAPPER_2DMISS_39:;
goto t_EXIT_2DLAP_2DIN_2DLISP_41;
t_HIT_40:;
goto t_EXIT_2DLAP_2DIN_2DLISP_41;
t_EXIT_2DLAP_2DIN_2DLISP_41:;
v_S7431_122 = v_M_0;
v__2EINDEX_2E_123 = ICALL(s_lsp_SVREF) (2, v__2EPV_2E_6, (LP) 0);
v_X_136 = v__2EINDEX_2E_123;
if (FIXNUMP((v_X_136))) {
v__2EINDEX_2E_123 = ICALL(s_lsp_SVREF) (2, v__2ESLOTS0_2E_7, v__2EINDEX_2E_123);
v_X_128 = v__2EINDEX_2E_123;
v_X_131 = (((v_X_128) == (LREF(s_pcl__2E_2ESLOT_2DUNBOUND_2E_2E))) ? T : NIL);
v_X_133 = v_X_131;
v_Y_134 = LREF(s_lsp_NIL);
t17 = (((v_X_131) == (LREF(s_lsp_NIL))) ? T : NIL);
} else {
t17 = LREF(s_lsp_NIL);
}
if (t17 != NIL) {
t16 = v__2EINDEX_2E_123;
} else {
v_X_126 = v__2EINDEX_2E_123;
if (OTHER_PTRP((v_X_126)) && (TAG((v_X_126)) == 15)) {
v_X_124 = v__2EINDEX_2E_123;
t16 = ((LP) DEREF((v_X_124) + 1 * 4));
} else {
t16 = ICALL(s_pcl_SLOT_2DVALUE) (2, v_M_0, LREF(s_pcl_METHOD));
}
}
t15 = ICALL(s_pcl_METHOD_2DQUALIFIERS) (MV_CALL(argc,1), t16);
return(t15);
}

LP p_pcl_ENV_5FINIT1723_2Danon51405141(argc, v_M_0)
      ARGC argc;  LP v_M_0;
{
LP v_X_136; LP v_Y_134; LP v_X_133; 
LP v_X_131; LP v_Y_129; LP v_X_128; 
LP v_X_126; LP v_X_124; LP v__2EINDEX_2E_123; 
LP v_S7429_122; LP v_S7505_120; LP v_I_118; 
LP v_S_117; LP v_S_115; LP v_S7504_114; 
LP v_I_112; LP v_S_111; LP v_S_109; 
LP v_S7503_108; LP v_I_106; LP v_FIN_105; 
LP v_S7502_104; LP v_I_102; LP v_FIN_101; 
LP v_X_99; LP v_S7501_98; LP v_S7500_97; 
LP v_S7499_96; LP v_S7498_95; LP v_S7497_94; 
LP v_X_92; LP v_S7496_91; LP v_N_89; 
LP v_Y_87; LP v_X_86; LP v_S7495_85; 
LP v_S7494_84; LP v_X_82; LP v_S7493_81; 
LP v_X_79; LP v_S7492_78; LP v_N_76; 
LP v_Y_74; LP v_X_73; LP v_S7491_72; 
LP v_S7490_71; LP v_S7489_70; LP v_S7488_69; 
LP v_S7487_68; LP v_S7486_67; LP v_S7485_66; 
LP v_S7484_65; LP v_S7483_64; LP v_I_62; 
LP v_S_61; LP v_S_59; LP v_S7482_58; 
LP v_I_56; LP v_S_55; LP v_S_53; 
LP v_S7481_52; LP v_I_50; LP v_FIN_49; 
LP v_S7480_48; LP v_I_46; LP v_FIN_45; 
LP v_X_43; LP v_S7479_42; LP v_REG1_27; 
LP v_REG8_26; LP v_REG0_25; LP v_REG4_24; 
LP v_REG7_23; LP v_REG3_22; LP v_REG2_21; 
LP v_REG5_20; LP v_REG6_19; LP v_SYMBOL_17; 
LP v_SYMBOL_15; LP v_SYMBOL_13; LP v_FIELD_11; 
LP v_MASK_10; LP v_SIZE_9; LP v_CACHE_8; 
LP v__2ESLOTS0_2E_7; LP v__2EPV_2E_6; LP v__2EISL_2E_5; 
LP v_SYMBOL_3; LP v_SYMBOL_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; 
if (argc != 1) wna(argc,1);
v_SYMBOL_1 = LREF(s_pcl_isl_2Dcache1691);
v__2EISL_2E_5 = ((LP) DEREF((LREF(s_pcl_isl_2Dcache1691)) + 0 * 4));
v_SYMBOL_3 = LREF(s_pcl__2AEMPTY_2DVECTOR_2A);
v__2EPV_2E_6 = ((LP) DEREF((LREF(s_pcl__2AEMPTY_2DVECTOR_2A)) + 0 * 4));
v__2ESLOTS0_2E_7 = LREF(s_lsp_NIL);
v_CACHE_8 = ICALL(s_lsp_SVREF) (2, v__2EISL_2E_5, (LP) 2);
v_SIZE_9 = ICALL(s_lsp_SVREF) (2, v__2EISL_2E_5, (LP) 8);
v_MASK_10 = ICALL(s_lsp_SVREF) (2, v__2EISL_2E_5, (LP) 6);
v_FIELD_11 = ICALL(s_lsp_SVREF) (2, v__2EISL_2E_5, (LP) 4);
v_REG6_19 = (LP) 0;
v_REG5_20 = (LP) 0;
v_REG2_21 = (LP) 0;
v_REG3_22 = (LP) 0;
v_SYMBOL_13 = LREF(s_pcl__2AEMPTY_2DVECTOR_2A);
v_REG7_23 = ((LP) DEREF((LREF(s_pcl__2AEMPTY_2DVECTOR_2A)) + 0 * 4));
v_SYMBOL_15 = LREF(s_pcl__2AEMPTY_2DVECTOR_2A);
v_REG4_24 = ((LP) DEREF((LREF(s_pcl__2AEMPTY_2DVECTOR_2A)) + 0 * 4));
v_SYMBOL_17 = LREF(s_pcl__2AEMPTY_2DVECTOR_2A);
v_REG0_25 = ((LP) DEREF((LREF(s_pcl__2AEMPTY_2DVECTOR_2A)) + 0 * 4));
v_REG8_26 = LREF(s_lsp_NIL);
v_REG1_27 = LREF(s_lsp_NIL);
v_S7479_42 = v_M_0;
v_REG1_27 = v_M_0;
t0 = ICALL(s_pcl_STD_2DINSTANCE_2DP) (1, v_REG1_27);
if (t0 != NIL) {
goto t_get_2Dstd_2Dinst_2Dwrapper1693_29;
}
v_X_43 = v_REG1_27;
if (OTHER_PTRP((v_X_43)) && (TAG((v_X_43)) == 39)) {
t3 = INT_TO_FX((LP) (DEREF((v_X_43) - 4) >> 8));
t1 = (((t3) == ((LP) 11356)) ? T : NIL);
} else {
t1 = LREF(s_lsp_NIL);
}
if (t1 != NIL) {
goto t_get_2Dfsc_2Dinst_2Dwrapper1694_28;
}
goto t_PV_2DMISS_35;
t_get_2Dfsc_2Dinst_2Dwrapper1694_28:;
v_FIN_45 = v_REG1_27;
v_S7480_48 = ((LP) DEREF((v_FIN_45) + 1 * 4));
v_REG0_25 = v_S7480_48;
v_FIN_49 = v_REG1_27;
v_S7481_52 = ((LP) DEREF((v_FIN_49) + 2 * 4));
v__2ESLOTS0_2E_7 = v_S7481_52;
goto t_exit_2Demit_2Dfetch_2Dwrapper1692_30;
t_get_2Dstd_2Dinst_2Dwrapper1693_29:;
v_S_53 = v_REG1_27;
v_S_55 = v_S_53;
v_I_56 = (LP) 2;
v_S7482_58 = ((LP) DEREF((v_S_53) + 1 * 4));
v_REG0_25 = v_S7482_58;
v_S_59 = v_REG1_27;
v_S_61 = v_S_59;
v_I_62 = (LP) 4;
v_S7483_64 = ((LP) DEREF((v_S_59) + 2 * 4));
v__2ESLOTS0_2E_7 = v_S7483_64;
t_exit_2Demit_2Dfetch_2Dwrapper1692_30:;
v_S7484_65 = v_CACHE_8;
v_REG4_24 = v_CACHE_8;
v_S7485_66 = v_MASK_10;
v_REG6_19 = v_MASK_10;
v_S7486_67 = v_FIELD_11;
v_REG5_20 = v_FIELD_11;
v_S7487_68 = ICALL(s_lsp_SVREF) (2, v_REG0_25, v_REG5_20);
v_REG5_20 = v_S7487_68;
v_S7488_69 = (((LP) ((int) (v_REG5_20) & (int) (v_REG6_19))));
v_REG3_22 = v_S7488_69;
v_S7489_70 = v_REG3_22;
v_REG2_21 = v_S7489_70;
v_S7490_71 = ICALL(s_lsp_SVREF) (2, v_REG4_24, (LP) 0);
v_REG1_27 = v_S7490_71;
v_S7491_72 = ICALL(s_lsp_SVREF) (2, v_REG4_24, v_REG2_21);
v_REG7_23 = v_S7491_72;
v_X_73 = v_REG7_23;
v_Y_74 = v_REG0_25;
if (((v_X_73) == (v_Y_74))) {
goto t_HIT_2DINTERNAL_34;
}
v_N_76 = v_REG5_20;
if (((int) (v_N_76) == (int) ((LP) 0))) {
goto t_PV_2DMISS_35;
}
v_S7492_78 = v_SIZE_9;
v_REG5_20 = v_SIZE_9;
t_LOOP_31:;
v_X_79 = v_REG2_21;
v_S7493_81 = (add((v_X_79), ((LP) 2)));
v_REG2_21 = v_S7493_81;
v_X_82 = v_REG2_21;
v_S7494_84 = (add((v_X_82), ((LP) 2)));
v_REG2_21 = v_S7494_84;
t_CONTINUE_32:;
if (((int) (v_REG2_21) == (int) (v_REG3_22))) {
goto t_PV_2DMISS_35;
}
if (((int) (v_REG2_21) == (int) (v_REG5_20))) {
goto t_SET_2DLOCATION_2DTO_2DMIN_33;
}
v_S7495_85 = ICALL(s_lsp_SVREF) (2, v_REG4_24, v_REG2_21);
v_REG7_23 = v_S7495_85;
v_X_86 = v_REG7_23;
v_Y_87 = v_REG0_25;
if (((v_X_86) == (v_Y_87))) {
goto t_HIT_2DINTERNAL_34;
}
goto t_LOOP_31;
t_SET_2DLOCATION_2DTO_2DMIN_33:;
v_N_89 = v_REG3_22;
if (((int) (v_N_89) == (int) ((LP) 0))) {
goto t_PV_2DMISS_35;
}
v_S7496_91 = (LP) 4;
v_REG2_21 = (LP) 4;
goto t_CONTINUE_32;
t_HIT_2DINTERNAL_34:;
v_X_92 = v_REG2_21;
v_S7497_94 = (add((v_X_92), ((LP) 2)));
v_REG2_21 = v_S7497_94;
v_S7498_95 = ICALL(s_lsp_SVREF) (2, v_REG4_24, v_REG2_21);
v__2EPV_2E_6 = v_S7498_95;
v_S7499_96 = ICALL(s_lsp_SVREF) (2, v_REG4_24, (LP) 0);
v_REG8_26 = v_S7499_96;
t10 = (num_equal_p((v_REG8_26), (v_REG1_27)));
if (t10 != NIL) {
goto t_HIT_40;
}
t_PV_2DMISS_35:;
v_S7500_97 = ICALL(s_pcl_PRIMARY_2DPV_2DCACHE_2DMISS) (2, v__2EISL_2E_5, v_M_0);
v__2EPV_2E_6 = v_S7500_97;
v_S7501_98 = v_M_0;
v_REG1_27 = v_M_0;
t11 = ICALL(s_pcl_STD_2DINSTANCE_2DP) (1, v_REG1_27);
if (t11 != NIL) {
goto t_get_2Dstd_2Dinst_2Dwrapper1696_37;
}
v_X_99 = v_REG1_27;
if (OTHER_PTRP((v_X_99)) && (TAG((v_X_99)) == 39)) {
t14 = INT_TO_FX((LP) (DEREF((v_X_99) - 4) >> 8));
t12 = (((t14) == ((LP) 11356)) ? T : NIL);
} else {
t12 = LREF(s_lsp_NIL);
}
if (t12 != NIL) {
goto t_get_2Dfsc_2Dinst_2Dwrapper1697_36;
}
goto t_PV_2DWRAPPER_2DMISS_39;
t_get_2Dfsc_2Dinst_2Dwrapper1697_36:;
v_FIN_101 = v_REG1_27;
v_S7502_104 = ((LP) DEREF((v_FIN_101) + 1 * 4));
v_REG0_25 = v_S7502_104;
v_FIN_105 = v_REG1_27;
v_S7503_108 = ((LP) DEREF((v_FIN_105) + 2 * 4));
v__2ESLOTS0_2E_7 = v_S7503_108;
goto t_exit_2Demit_2Dfetch_2Dwrapper1695_38;
t_get_2Dstd_2Dinst_2Dwrapper1696_37:;
v_S_109 = v_REG1_27;
v_S_111 = v_S_109;
v_I_112 = (LP) 2;
v_S7504_114 = ((LP) DEREF((v_S_109) + 1 * 4));
v_REG0_25 = v_S7504_114;
v_S_115 = v_REG1_27;
v_S_117 = v_S_115;
v_I_118 = (LP) 4;
v_S7505_120 = ((LP) DEREF((v_S_115) + 2 * 4));
v__2ESLOTS0_2E_7 = v_S7505_120;
t_exit_2Demit_2Dfetch_2Dwrapper1695_38:;
t_PV_2DWRAPPER_2DMISS_39:;
goto t_EXIT_2DLAP_2DIN_2DLISP_41;
t_HIT_40:;
goto t_EXIT_2DLAP_2DIN_2DLISP_41;
t_EXIT_2DLAP_2DIN_2DLISP_41:;
v_S7429_122 = v_M_0;
v__2EINDEX_2E_123 = ICALL(s_lsp_SVREF) (2, v__2EPV_2E_6, (LP) 0);
v_X_136 = v__2EINDEX_2E_123;
if (FIXNUMP((v_X_136))) {
v__2EINDEX_2E_123 = ICALL(s_lsp_SVREF) (2, v__2ESLOTS0_2E_7, v__2EINDEX_2E_123);
v_X_128 = v__2EINDEX_2E_123;
v_X_131 = (((v_X_128) == (LREF(s_pcl__2E_2ESLOT_2DUNBOUND_2E_2E))) ? T : NIL);
v_X_133 = v_X_131;
v_Y_134 = LREF(s_lsp_NIL);
t17 = (((v_X_131) == (LREF(s_lsp_NIL))) ? T : NIL);
} else {
t17 = LREF(s_lsp_NIL);
}
if (t17 != NIL) {
t16 = v__2EINDEX_2E_123;
} else {
v_X_126 = v__2EINDEX_2E_123;
if (OTHER_PTRP((v_X_126)) && (TAG((v_X_126)) == 15)) {
v_X_124 = v__2EINDEX_2E_123;
t16 = ((LP) DEREF((v_X_124) + 1 * 4));
} else {
t16 = ICALL(s_pcl_SLOT_2DVALUE) (2, v_M_0, LREF(s_pcl_METHOD));
}
}
t15 = ICALL(s_pcl_METHOD_2DSPECIALIZERS) (MV_CALL(argc,1), t16);
return(t15);
}

LP p_pcl_ENV_5FINIT1723_2Danon51385139(argc, v_M_0)
      ARGC argc;  LP v_M_0;
{
LP v_X_136; LP v_Y_134; LP v_X_133; 
LP v_X_131; LP v_Y_129; LP v_X_128; 
LP v_X_126; LP v_X_124; LP v__2EINDEX_2E_123; 
LP v_S7427_122; LP v_S7478_120; LP v_I_118; 
LP v_S_117; LP v_S_115; LP v_S7477_114; 
LP v_I_112; LP v_S_111; LP v_S_109; 
LP v_S7476_108; LP v_I_106; LP v_FIN_105; 
LP v_S7475_104; LP v_I_102; LP v_FIN_101; 
LP v_X_99; LP v_S7474_98; LP v_S7473_97; 
LP v_S7472_96; LP v_S7471_95; LP v_S7470_94; 
LP v_X_92; LP v_S7469_91; LP v_N_89; 
LP v_Y_87; LP v_X_86; LP v_S7468_85; 
LP v_S7467_84; LP v_X_82; LP v_S7466_81; 
LP v_X_79; LP v_S7465_78; LP v_N_76; 
LP v_Y_74; LP v_X_73; LP v_S7464_72; 
LP v_S7463_71; LP v_S7462_70; LP v_S7461_69; 
LP v_S7460_68; LP v_S7459_67; LP v_S7458_66; 
LP v_S7457_65; LP v_S7456_64; LP v_I_62; 
LP v_S_61; LP v_S_59; LP v_S7455_58; 
LP v_I_56; LP v_S_55; LP v_S_53; 
LP v_S7454_52; LP v_I_50; LP v_FIN_49; 
LP v_S7453_48; LP v_I_46; LP v_FIN_45; 
LP v_X_43; LP v_S7452_42; LP v_REG1_27; 
LP v_REG8_26; LP v_REG0_25; LP v_REG4_24; 
LP v_REG7_23; LP v_REG3_22; LP v_REG2_21; 
LP v_REG5_20; LP v_REG6_19; LP v_SYMBOL_17; 
LP v_SYMBOL_15; LP v_SYMBOL_13; LP v_FIELD_11; 
LP v_MASK_10; LP v_SIZE_9; LP v_CACHE_8; 
LP v__2ESLOTS0_2E_7; LP v__2EPV_2E_6; LP v__2EISL_2E_5; 
LP v_SYMBOL_3; LP v_SYMBOL_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; 
if (argc != 1) wna(argc,1);
v_SYMBOL_1 = LREF(s_pcl_isl_2Dcache1683);
v__2EISL_2E_5 = ((LP) DEREF((LREF(s_pcl_isl_2Dcache1683)) + 0 * 4));
v_SYMBOL_3 = LREF(s_pcl__2AEMPTY_2DVECTOR_2A);
v__2EPV_2E_6 = ((LP) DEREF((LREF(s_pcl__2AEMPTY_2DVECTOR_2A)) + 0 * 4));
v__2ESLOTS0_2E_7 = LREF(s_lsp_NIL);
v_CACHE_8 = ICALL(s_lsp_SVREF) (2, v__2EISL_2E_5, (LP) 2);
v_SIZE_9 = ICALL(s_lsp_SVREF) (2, v__2EISL_2E_5, (LP) 8);
v_MASK_10 = ICALL(s_lsp_SVREF) (2, v__2EISL_2E_5, (LP) 6);
v_FIELD_11 = ICALL(s_lsp_SVREF) (2, v__2EISL_2E_5, (LP) 4);
v_REG6_19 = (LP) 0;
v_REG5_20 = (LP) 0;
v_REG2_21 = (LP) 0;
v_REG3_22 = (LP) 0;
v_SYMBOL_13 = LREF(s_pcl__2AEMPTY_2DVECTOR_2A);
v_REG7_23 = ((LP) DEREF((LREF(s_pcl__2AEMPTY_2DVECTOR_2A)) + 0 * 4));
v_SYMBOL_15 = LREF(s_pcl__2AEMPTY_2DVECTOR_2A);
v_REG4_24 = ((LP) DEREF((LREF(s_pcl__2AEMPTY_2DVECTOR_2A)) + 0 * 4));
v_SYMBOL_17 = LREF(s_pcl__2AEMPTY_2DVECTOR_2A);
v_REG0_25 = ((LP) DEREF((LREF(s_pcl__2AEMPTY_2DVECTOR_2A)) + 0 * 4));
v_REG8_26 = LREF(s_lsp_NIL);
v_REG1_27 = LREF(s_lsp_NIL);
v_S7452_42 = v_M_0;
v_REG1_27 = v_M_0;
t0 = ICALL(s_pcl_STD_2DINSTANCE_2DP) (1, v_REG1_27);
if (t0 != NIL) {
goto t_get_2Dstd_2Dinst_2Dwrapper1685_29;
}
v_X_43 = v_REG1_27;
if (OTHER_PTRP((v_X_43)) && (TAG((v_X_43)) == 39)) {
t3 = INT_TO_FX((LP) (DEREF((v_X_43) - 4) >> 8));
t1 = (((t3) == ((LP) 11356)) ? T : NIL);
} else {
t1 = LREF(s_lsp_NIL);
}
if (t1 != NIL) {
goto t_get_2Dfsc_2Dinst_2Dwrapper1686_28;
}
goto t_PV_2DMISS_35;
t_get_2Dfsc_2Dinst_2Dwrapper1686_28:;
v_FIN_45 = v_REG1_27;
v_S7453_48 = ((LP) DEREF((v_FIN_45) + 1 * 4));
v_REG0_25 = v_S7453_48;
v_FIN_49 = v_REG1_27;
v_S7454_52 = ((LP) DEREF((v_FIN_49) + 2 * 4));
v__2ESLOTS0_2E_7 = v_S7454_52;
goto t_exit_2Demit_2Dfetch_2Dwrapper1684_30;
t_get_2Dstd_2Dinst_2Dwrapper1685_29:;
v_S_53 = v_REG1_27;
v_S_55 = v_S_53;
v_I_56 = (LP) 2;
v_S7455_58 = ((LP) DEREF((v_S_53) + 1 * 4));
v_REG0_25 = v_S7455_58;
v_S_59 = v_REG1_27;
v_S_61 = v_S_59;
v_I_62 = (LP) 4;
v_S7456_64 = ((LP) DEREF((v_S_59) + 2 * 4));
v__2ESLOTS0_2E_7 = v_S7456_64;
t_exit_2Demit_2Dfetch_2Dwrapper1684_30:;
v_S7457_65 = v_CACHE_8;
v_REG4_24 = v_CACHE_8;
v_S7458_66 = v_MASK_10;
v_REG6_19 = v_MASK_10;
v_S7459_67 = v_FIELD_11;
v_REG5_20 = v_FIELD_11;
v_S7460_68 = ICALL(s_lsp_SVREF) (2, v_REG0_25, v_REG5_20);
v_REG5_20 = v_S7460_68;
v_S7461_69 = (((LP) ((int) (v_REG5_20) & (int) (v_REG6_19))));
v_REG3_22 = v_S7461_69;
v_S7462_70 = v_REG3_22;
v_REG2_21 = v_S7462_70;
v_S7463_71 = ICALL(s_lsp_SVREF) (2, v_REG4_24, (LP) 0);
v_REG1_27 = v_S7463_71;
v_S7464_72 = ICALL(s_lsp_SVREF) (2, v_REG4_24, v_REG2_21);
v_REG7_23 = v_S7464_72;
v_X_73 = v_REG7_23;
v_Y_74 = v_REG0_25;
if (((v_X_73) == (v_Y_74))) {
goto t_HIT_2DINTERNAL_34;
}
v_N_76 = v_REG5_20;
if (((int) (v_N_76) == (int) ((LP) 0))) {
goto t_PV_2DMISS_35;
}
v_S7465_78 = v_SIZE_9;
v_REG5_20 = v_SIZE_9;
t_LOOP_31:;
v_X_79 = v_REG2_21;
v_S7466_81 = (add((v_X_79), ((LP) 2)));
v_REG2_21 = v_S7466_81;
v_X_82 = v_REG2_21;
v_S7467_84 = (add((v_X_82), ((LP) 2)));
v_REG2_21 = v_S7467_84;
t_CONTINUE_32:;
if (((int) (v_REG2_21) == (int) (v_REG3_22))) {
goto t_PV_2DMISS_35;
}
if (((int) (v_REG2_21) == (int) (v_REG5_20))) {
goto t_SET_2DLOCATION_2DTO_2DMIN_33;
}
v_S7468_85 = ICALL(s_lsp_SVREF) (2, v_REG4_24, v_REG2_21);
v_REG7_23 = v_S7468_85;
v_X_86 = v_REG7_23;
v_Y_87 = v_REG0_25;
if (((v_X_86) == (v_Y_87))) {
goto t_HIT_2DINTERNAL_34;
}
goto t_LOOP_31;
t_SET_2DLOCATION_2DTO_2DMIN_33:;
v_N_89 = v_REG3_22;
if (((int) (v_N_89) == (int) ((LP) 0))) {
goto t_PV_2DMISS_35;
}
v_S7469_91 = (LP) 4;
v_REG2_21 = (LP) 4;
goto t_CONTINUE_32;
t_HIT_2DINTERNAL_34:;
v_X_92 = v_REG2_21;
v_S7470_94 = (add((v_X_92), ((LP) 2)));
v_REG2_21 = v_S7470_94;
v_S7471_95 = ICALL(s_lsp_SVREF) (2, v_REG4_24, v_REG2_21);
v__2EPV_2E_6 = v_S7471_95;
v_S7472_96 = ICALL(s_lsp_SVREF) (2, v_REG4_24, (LP) 0);
v_REG8_26 = v_S7472_96;
t10 = (num_equal_p((v_REG8_26), (v_REG1_27)));
if (t10 != NIL) {
goto t_HIT_40;
}
t_PV_2DMISS_35:;
v_S7473_97 = ICALL(s_pcl_PRIMARY_2DPV_2DCACHE_2DMISS) (2, v__2EISL_2E_5, v_M_0);
v__2EPV_2E_6 = v_S7473_97;
v_S7474_98 = v_M_0;
v_REG1_27 = v_M_0;
t11 = ICALL(s_pcl_STD_2DINSTANCE_2DP) (1, v_REG1_27);
if (t11 != NIL) {
goto t_get_2Dstd_2Dinst_2Dwrapper1688_37;
}
v_X_99 = v_REG1_27;
if (OTHER_PTRP((v_X_99)) && (TAG((v_X_99)) == 39)) {
t14 = INT_TO_FX((LP) (DEREF((v_X_99) - 4) >> 8));
t12 = (((t14) == ((LP) 11356)) ? T : NIL);
} else {
t12 = LREF(s_lsp_NIL);
}
if (t12 != NIL) {
goto t_get_2Dfsc_2Dinst_2Dwrapper1689_36;
}
goto t_PV_2DWRAPPER_2DMISS_39;
t_get_2Dfsc_2Dinst_2Dwrapper1689_36:;
v_FIN_101 = v_REG1_27;
v_S7475_104 = ((LP) DEREF((v_FIN_101) + 1 * 4));
v_REG0_25 = v_S7475_104;
v_FIN_105 = v_REG1_27;
v_S7476_108 = ((LP) DEREF((v_FIN_105) + 2 * 4));
v__2ESLOTS0_2E_7 = v_S7476_108;
goto t_exit_2Demit_2Dfetch_2Dwrapper1687_38;
t_get_2Dstd_2Dinst_2Dwrapper1688_37:;
v_S_109 = v_REG1_27;
v_S_111 = v_S_109;
v_I_112 = (LP) 2;
v_S7477_114 = ((LP) DEREF((v_S_109) + 1 * 4));
v_REG0_25 = v_S7477_114;
v_S_115 = v_REG1_27;
v_S_117 = v_S_115;
v_I_118 = (LP) 4;
v_S7478_120 = ((LP) DEREF((v_S_115) + 2 * 4));
v__2ESLOTS0_2E_7 = v_S7478_120;
t_exit_2Demit_2Dfetch_2Dwrapper1687_38:;
t_PV_2DWRAPPER_2DMISS_39:;
goto t_EXIT_2DLAP_2DIN_2DLISP_41;
t_HIT_40:;
goto t_EXIT_2DLAP_2DIN_2DLISP_41;
t_EXIT_2DLAP_2DIN_2DLISP_41:;
v_S7427_122 = v_M_0;
v__2EINDEX_2E_123 = ICALL(s_lsp_SVREF) (2, v__2EPV_2E_6, (LP) 0);
v_X_136 = v__2EINDEX_2E_123;
if (FIXNUMP((v_X_136))) {
v__2EINDEX_2E_123 = ICALL(s_lsp_SVREF) (2, v__2ESLOTS0_2E_7, v__2EINDEX_2E_123);
v_X_128 = v__2EINDEX_2E_123;
v_X_131 = (((v_X_128) == (LREF(s_pcl__2E_2ESLOT_2DUNBOUND_2E_2E))) ? T : NIL);
v_X_133 = v_X_131;
v_Y_134 = LREF(s_lsp_NIL);
t17 = (((v_X_131) == (LREF(s_lsp_NIL))) ? T : NIL);
} else {
t17 = LREF(s_lsp_NIL);
}
if (t17 != NIL) {
t16 = v__2EINDEX_2E_123;
} else {
v_X_126 = v__2EINDEX_2E_123;
if (OTHER_PTRP((v_X_126)) && (TAG((v_X_126)) == 15)) {
v_X_124 = v__2EINDEX_2E_123;
t16 = ((LP) DEREF((v_X_124) + 1 * 4));
} else {
t16 = ICALL(s_pcl_SLOT_2DVALUE) (2, v_M_0, LREF(s_pcl_METHOD));
}
}
t15 = ICALL(s_pcl_METHOD_2DLAMBDA_2DLIST) (MV_CALL(argc,1), t16);
return(t15);
}

LP p_pcl_ENV_5FINIT1723_2Danon51355136(argc, v_CLASS_0, v_STREAM_1)
      ARGC argc;  LP v_CLASS_0; LP v_STREAM_1;
{
LP v_X_75; LP v_V_73; LP v_X_72; 
LP v_NEW_2DCDR_70; LP v_C_69; LP v_Y_67; 
LP v_X_66; LP v_X_64; LP v_X_62; 
LP v_LOOPVAR_2D1735_58; LP v_LOOPVAR_2D1734_57; LP v_LOOPVAR_2D1733_56; 
LP v_LOOP_2DLIST_2D1732_55; LP v_L7451_54; LP v_X_52; 
LP v_V_50; LP v_X_49; LP v_NEW_2DCDR_47; 
LP v_C_46; LP v_Y_44; LP v_X_43; 
LP v_X_41; LP v_X_39; LP v_LOOPVAR_2D1731_35; 
LP v_LOOPVAR_2D1730_34; LP v_LOOPVAR_2D1729_33; LP v_LOOP_2DLIST_2D1728_32; 
LP v_L7450_31; LP v_X_29; LP v_V_27; 
LP v_X_26; LP v_NEW_2DCDR_24; LP v_C_23; 
LP v_Y_21; LP v_X_20; LP v_X_18; 
LP v_X_16; LP v_LOOPVAR_2D1727_12; LP v_LOOPVAR_2D1726_11; 
LP v_LOOPVAR_2D1725_10; LP v_LOOP_2DLIST_2D1724_9; LP v_L7449_8; 
LP v_Y_6; LP v_X_5; LP v_NAME_4; 
LP f_PRETTY_2DCLASS_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; 
if (argc != 2) wna(argc,2);
f_PRETTY_2DCLASS_3 = LREF(k5193);
t1 = ICALL(s_pcl_CLASS_2DOF) (1, v_CLASS_0);
t0 = CODE_PTR(COERCE_TO_FUNCTION(f_PRETTY_2DCLASS_3))(1, t1);
ICALL(s_lsp_FORMAT) (4, v_STREAM_1, LREF(k5194), v_CLASS_0, t0);
v_NAME_4 = ICALL(s_pcl_CLASS_2DNAME) (1, v_CLASS_0);
if (v_NAME_4 != NIL) {
v_Y_6 = ICALL(s_pcl_FIND_2DCLASS) (2, v_NAME_4, LREF(s_lsp_NIL));
if (((v_CLASS_0) == (v_Y_6))) {
ICALL(s_lsp_FORMAT) (3, v_STREAM_1, LREF(k5195), v_NAME_4);
} else {
ICALL(s_lsp_FORMAT) (3, v_STREAM_1, LREF(k5196), v_NAME_4);
}
} else {
ICALL(s_lsp_FORMAT) (2, v_STREAM_1, LREF(k5197));
}
v_L7449_8 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D1724_9 = ICALL(s_pcl_CLASS_2DDIRECT_2DSUPERCLASSES) (1, v_CLASS_0);
v_LOOPVAR_2D1725_10 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1726_11 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1727_12 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_14:;
if (v_LOOP_2DLIST_2D1724_9 == NIL) {
goto t_END_2DLOOP_15;
}
v_X_16 = v_LOOP_2DLIST_2D1724_9;
v_L7449_8 = ((LP) DEREF((v_X_16) + 0 * 4));
v_X_18 = v_LOOP_2DLIST_2D1724_9;
v_LOOP_2DLIST_2D1724_9 = ((LP) DEREF((v_X_18) + 1 * 4));
v_X_20 = CODE_PTR(COERCE_TO_FUNCTION(f_PRETTY_2DCLASS_3))(1, v_L7449_8);
v_LOOPVAR_2D1727_12 = (c_cons((v_X_20), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D1726_11 != NIL) {
v_C_23 = v_LOOPVAR_2D1726_11;
v_NEW_2DCDR_24 = v_LOOPVAR_2D1727_12;
v_V_27 = v_NEW_2DCDR_24;
((LP) (DEREF((v_C_23) + 1 * 4) = (LD) (v_V_27)));
v_X_29 = v_C_23;
v_LOOPVAR_2D1726_11 = ((LP) DEREF((v_X_29) + 1 * 4));
} else {
v_LOOPVAR_2D1725_10 = v_LOOPVAR_2D1727_12;
v_LOOPVAR_2D1726_11 = v_LOOPVAR_2D1725_10;
}
goto t_NEXT_2DLOOP_14;
goto t_END_2DLOOP_15;
t_END_2DLOOP_15:;
t4 = v_LOOPVAR_2D1725_10;
goto b_NIL_13;
t4 = NIL;
b_NIL_13:;
v_L7450_31 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D1728_32 = ICALL(s_pcl_CLASS_2DDIRECT_2DSUBCLASSES) (1, v_CLASS_0);
v_LOOPVAR_2D1729_33 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1730_34 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1731_35 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_37:;
if (v_LOOP_2DLIST_2D1728_32 == NIL) {
goto t_END_2DLOOP_38;
}
v_X_39 = v_LOOP_2DLIST_2D1728_32;
v_L7450_31 = ((LP) DEREF((v_X_39) + 0 * 4));
v_X_41 = v_LOOP_2DLIST_2D1728_32;
v_LOOP_2DLIST_2D1728_32 = ((LP) DEREF((v_X_41) + 1 * 4));
v_X_43 = CODE_PTR(COERCE_TO_FUNCTION(f_PRETTY_2DCLASS_3))(1, v_L7450_31);
v_LOOPVAR_2D1731_35 = (c_cons((v_X_43), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D1730_34 != NIL) {
v_C_46 = v_LOOPVAR_2D1730_34;
v_NEW_2DCDR_47 = v_LOOPVAR_2D1731_35;
v_V_50 = v_NEW_2DCDR_47;
((LP) (DEREF((v_C_46) + 1 * 4) = (LD) (v_V_50)));
v_X_52 = v_C_46;
v_LOOPVAR_2D1730_34 = ((LP) DEREF((v_X_52) + 1 * 4));
} else {
v_LOOPVAR_2D1729_33 = v_LOOPVAR_2D1731_35;
v_LOOPVAR_2D1730_34 = v_LOOPVAR_2D1729_33;
}
goto t_NEXT_2DLOOP_37;
goto t_END_2DLOOP_38;
t_END_2DLOOP_38:;
t5 = v_LOOPVAR_2D1729_33;
goto b_NIL_36;
t5 = NIL;
b_NIL_36:;
v_L7451_54 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D1732_55 = ICALL(s_pcl_CLASS_2DPRECEDENCE_2DLIST) (1, v_CLASS_0);
v_LOOPVAR_2D1733_56 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1734_57 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1735_58 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_60:;
if (v_LOOP_2DLIST_2D1732_55 == NIL) {
goto t_END_2DLOOP_61;
}
v_X_62 = v_LOOP_2DLIST_2D1732_55;
v_L7451_54 = ((LP) DEREF((v_X_62) + 0 * 4));
v_X_64 = v_LOOP_2DLIST_2D1732_55;
v_LOOP_2DLIST_2D1732_55 = ((LP) DEREF((v_X_64) + 1 * 4));
v_X_66 = CODE_PTR(COERCE_TO_FUNCTION(f_PRETTY_2DCLASS_3))(1, v_L7451_54);
v_LOOPVAR_2D1735_58 = (c_cons((v_X_66), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D1734_57 != NIL) {
v_C_69 = v_LOOPVAR_2D1734_57;
v_NEW_2DCDR_70 = v_LOOPVAR_2D1735_58;
v_V_73 = v_NEW_2DCDR_70;
((LP) (DEREF((v_C_69) + 1 * 4) = (LD) (v_V_73)));
v_X_75 = v_C_69;
v_LOOPVAR_2D1734_57 = ((LP) DEREF((v_X_75) + 1 * 4));
} else {
v_LOOPVAR_2D1733_56 = v_LOOPVAR_2D1735_58;
v_LOOPVAR_2D1734_57 = v_LOOPVAR_2D1733_56;
}
goto t_NEXT_2DLOOP_60;
goto t_END_2DLOOP_61;
t_END_2DLOOP_61:;
t6 = v_LOOPVAR_2D1733_56;
goto b_NIL_59;
t6 = NIL;
b_NIL_59:;
t8 = ICALL(s_pcl_SPECIALIZER_2DMETHODS) (1, v_CLASS_0);
t7 = ICALL(s_lsp_LENGTH) (1, t8);
t3 = ICALL(s_lsp_FORMAT) (MV_CALL(argc,6), v_STREAM_1, LREF(k5198), t4, t5, t6, t7);
return(t3);
}

LP p_pcl_ENV_5FINIT1723_2Danon51355136ENV_5FINIT1723_2DPRETTY_2DCLASS5137(argc, v_C_0)
      ARGC argc;  LP v_C_0;
{
LP v_G7419_2; 
LP t0; LP t1; LP t2; LP t3; 
if (argc != 1) wna(argc,1);
v_G7419_2 = ICALL(s_pcl_CLASS_2DNAME) (1, v_C_0);
if (v_G7419_2 != NIL) {
return(v_G7419_2);
} else {
return(v_C_0);
}
}

LP p_pcl_ENV_5FINIT1723_2Danon51335134(argc, v_CLASS_0, v_OBJECT_1)
      ARGC argc;  LP v_CLASS_0; LP v_OBJECT_1;
{

LP t0; LP t1; LP t2; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_pcl_CLASS_2DSLOTS) (MV_CALL(argc,1), v_CLASS_0);
return(t0);
}

LP p_pcl_ENV_5FINIT1723_2Danon51295130(argc, v_OBJECT_0, v_STREAM_1)
      ARGC argc;  LP v_OBJECT_0; LP v_STREAM_1;
{
LP v_X_67; LP v_X_65; LP v_LOOP_2DLIST_2D1674_61; 
LP v_SLOTD_60; LP v_X_58; LP v_X_56; 
LP v_LOOP_2DLIST_2D1673_52; LP v_SLOTD_51; LP v_X_49; 
LP v_X_47; LP v_LOOP_2DLIST_2D1672_43; LP v_SLOTD_42; 
LP v_Y_40; LP v_X_39; LP v_Y_37; 
LP v_X_36; LP v_S7417_35; LP v_Y_33; 
LP v_X_32; LP v_VALUE7415_31; LP v_S7414_30; 
LP v_Y_28; LP v_X_27; LP v_VALUE7412_26; 
LP v_S7411_25; LP v_Y_23; LP v_X_22; 
LP v_VALUE7409_21; LP v_KEY7408_20; LP v_X_18; 
LP v_X_16; LP v_LOOP_2DLIST_2D1671_12; LP v_SLOTD_11; 
LP f_DESCRIBE_2DSLOT_10; LP f_ADJUST_2DSLOT_2DNAME_2DLENGTH_9; LP v_OTHER_2DSLOTDS_8; 
LP v_CLASS_2DSLOTDS_7; LP v_INSTANCE_2DSLOTDS_6; LP v_MAX_2DSLOT_2DNAME_2DLENGTH_5; 
LP v_SLOTDS_4; LP v_CLASS_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; 
if (argc != 2) wna(argc,2);
t0 = OE;
SET_OE_SLOT(t0,0,v_STREAM_1);
v_CLASS_3 = ICALL(s_pcl_CLASS_2DOF) (1, v_OBJECT_0);
v_SLOTDS_4 = ICALL(s_pcl_SLOTS_2DTO_2DINSPECT) (2, v_CLASS_3, v_OBJECT_0);
v_MAX_2DSLOT_2DNAME_2DLENGTH_5 = (LP) 0;
SET_OE_SLOT(t0,1,v_MAX_2DSLOT_2DNAME_2DLENGTH_5);
v_INSTANCE_2DSLOTDS_6 = LREF(s_lsp_NIL);
v_CLASS_2DSLOTDS_7 = LREF(s_lsp_NIL);
v_OTHER_2DSLOTDS_8 = LREF(s_lsp_NIL);
t1 = MAKE_CLOSURE(p_pcl_ENV_5FINIT1723_2Danon51295130ENV_5FINIT1723_2DADJUST_2DSLOT_2DNAME_2DLENGTH5131,t0);
f_ADJUST_2DSLOT_2DNAME_2DLENGTH_9 = t1;
t2 = MAKE_CLOSURE(p_pcl_ENV_5FINIT1723_2Danon51295130ENV_5FINIT1723_2DDESCRIBE_2DSLOT5132,t0);
f_DESCRIBE_2DSLOT_10 = t2;
v_SLOTD_11 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D1671_12 = v_SLOTDS_4;
t_NEXT_2DLOOP_14:;
if (v_LOOP_2DLIST_2D1671_12 == NIL) {
goto t_END_2DLOOP_15;
}
v_X_16 = v_LOOP_2DLIST_2D1671_12;
v_SLOTD_11 = ((LP) DEREF((v_X_16) + 0 * 4));
v_X_18 = v_LOOP_2DLIST_2D1671_12;
v_LOOP_2DLIST_2D1671_12 = ((LP) DEREF((v_X_18) + 1 * 4));
t3 = ICALL(s_pcl_SLOTD_2DNAME) (1, v_SLOTD_11);
CODE_PTR(COERCE_TO_FUNCTION(f_ADJUST_2DSLOT_2DNAME_2DLENGTH_9))(1, t3);
v_KEY7408_20 = ICALL(s_pcl_SLOTD_2DALLOCATION) (1, v_SLOTD_11);
v_X_39 = v_KEY7408_20;
v_Y_40 = LREF(s_key_INSTANCE);
t4 = (c_eql((v_KEY7408_20), (LREF(s_key_INSTANCE))));
if (t4 != NIL) {
v_VALUE7409_21 = v_SLOTD_11;
v_Y_23 = v_INSTANCE_2DSLOTDS_6;
v_S7411_25 = (c_cons((v_VALUE7409_21), (v_Y_23)));
v_INSTANCE_2DSLOTDS_6 = v_S7411_25;
} else {
v_X_36 = v_KEY7408_20;
v_Y_37 = LREF(s_key_CLASS);
t5 = (c_eql((v_KEY7408_20), (LREF(s_key_CLASS))));
if (t5 != NIL) {
v_VALUE7412_26 = v_SLOTD_11;
v_Y_28 = v_CLASS_2DSLOTDS_7;
v_S7414_30 = (c_cons((v_VALUE7412_26), (v_Y_28)));
v_CLASS_2DSLOTDS_7 = v_S7414_30;
} else {
v_VALUE7415_31 = v_SLOTD_11;
v_Y_33 = v_OTHER_2DSLOTDS_8;
v_S7417_35 = (c_cons((v_VALUE7415_31), (v_Y_33)));
v_OTHER_2DSLOTDS_8 = v_S7417_35;
}
}
goto t_NEXT_2DLOOP_14;
goto t_END_2DLOOP_15;
t_END_2DLOOP_15:;
goto b_NIL_13;
b_NIL_13:;
t7 = (add((GET_OE_SLOT(t0,1)), ((LP) 6)));
t6 = ICALL(s_lsp_MIN) (2, t7, (LP) 60);
SET_OE_SLOT(t0,1,t6);
ICALL(s_lsp_FORMAT) (4, GET_OE_SLOT(t0,0), LREF(k5199), v_OBJECT_0, v_CLASS_3);
if (v_INSTANCE_2DSLOTDS_6 != NIL) {
ICALL(s_lsp_FORMAT) (2, GET_OE_SLOT(t0,0), LREF(k5200));
v_SLOTD_42 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D1672_43 = ICALL(s_lsp_NREVERSE) (1, v_INSTANCE_2DSLOTDS_6);
t_NEXT_2DLOOP_45:;
if (v_LOOP_2DLIST_2D1672_43 == NIL) {
goto t_END_2DLOOP_46;
}
v_X_47 = v_LOOP_2DLIST_2D1672_43;
v_SLOTD_42 = ((LP) DEREF((v_X_47) + 0 * 4));
v_X_49 = v_LOOP_2DLIST_2D1672_43;
v_LOOP_2DLIST_2D1672_43 = ((LP) DEREF((v_X_49) + 1 * 4));
t8 = ICALL(s_pcl_SLOTD_2DNAME) (1, v_SLOTD_42);
t10 = ICALL(s_pcl_SLOTD_2DNAME) (1, v_SLOTD_42);
t9 = ICALL(s_pcl_SLOT_2DVALUE_2DOR_2DDEFAULT) (2, v_OBJECT_0, t10);
CODE_PTR(COERCE_TO_FUNCTION(f_DESCRIBE_2DSLOT_10))(2, t8, t9);
goto t_NEXT_2DLOOP_45;
goto t_END_2DLOOP_46;
t_END_2DLOOP_46:;
goto b_NIL_44;
b_NIL_44:;
}
if (v_CLASS_2DSLOTDS_7 != NIL) {
ICALL(s_lsp_FORMAT) (2, GET_OE_SLOT(t0,0), LREF(k5201));
v_SLOTD_51 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D1673_52 = ICALL(s_lsp_NREVERSE) (1, v_CLASS_2DSLOTDS_7);
t_NEXT_2DLOOP_54:;
if (v_LOOP_2DLIST_2D1673_52 == NIL) {
goto t_END_2DLOOP_55;
}
v_X_56 = v_LOOP_2DLIST_2D1673_52;
v_SLOTD_51 = ((LP) DEREF((v_X_56) + 0 * 4));
v_X_58 = v_LOOP_2DLIST_2D1673_52;
v_LOOP_2DLIST_2D1673_52 = ((LP) DEREF((v_X_58) + 1 * 4));
t11 = ICALL(s_pcl_SLOTD_2DNAME) (1, v_SLOTD_51);
t13 = ICALL(s_pcl_SLOTD_2DNAME) (1, v_SLOTD_51);
t12 = ICALL(s_pcl_SLOT_2DVALUE_2DOR_2DDEFAULT) (2, v_OBJECT_0, t13);
CODE_PTR(COERCE_TO_FUNCTION(f_DESCRIBE_2DSLOT_10))(2, t11, t12);
goto t_NEXT_2DLOOP_54;
goto t_END_2DLOOP_55;
t_END_2DLOOP_55:;
goto b_NIL_53;
b_NIL_53:;
}
if (v_OTHER_2DSLOTDS_8 != NIL) {
ICALL(s_lsp_FORMAT) (2, GET_OE_SLOT(t0,0), LREF(k5202));
v_SLOTD_60 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D1674_61 = ICALL(s_lsp_NREVERSE) (1, v_OTHER_2DSLOTDS_8);
t_NEXT_2DLOOP_63:;
if (v_LOOP_2DLIST_2D1674_61 == NIL) {
goto t_END_2DLOOP_64;
}
v_X_65 = v_LOOP_2DLIST_2D1674_61;
v_SLOTD_60 = ((LP) DEREF((v_X_65) + 0 * 4));
v_X_67 = v_LOOP_2DLIST_2D1674_61;
v_LOOP_2DLIST_2D1674_61 = ((LP) DEREF((v_X_67) + 1 * 4));
t14 = ICALL(s_pcl_SLOTD_2DNAME) (1, v_SLOTD_60);
t16 = ICALL(s_pcl_SLOTD_2DNAME) (1, v_SLOTD_60);
t15 = ICALL(s_pcl_SLOT_2DVALUE_2DOR_2DDEFAULT) (2, v_OBJECT_0, t16);
t17 = ICALL(s_pcl_SLOTD_2DALLOCATION) (1, v_SLOTD_60);
CODE_PTR(COERCE_TO_FUNCTION(f_DESCRIBE_2DSLOT_10))(3, t14, t15, t17);
goto t_NEXT_2DLOOP_63;
goto t_END_2DLOOP_64;
t_END_2DLOOP_64:;
goto b_NIL_62;
b_NIL_62:;
}
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,0);
}
return(NIL);
}

LP p_pcl_ENV_5FINIT1723_2Danon51295130ENV_5FINIT1723_2DDESCRIBE_2DSLOT5132(va_alist) va_dcl
{
LP v_VALUE_1; LP v_NAME_0; LP v_ALLOC_2DP_3; 
LP v_ALLOCATION_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_NAME_0 = NEXT_VAR_ARG;
v_VALUE_1 = NEXT_VAR_ARG;


t0 = OE;
real_argc = REAL_ARGC(argc);
if (real_argc < 2) wna_low(real_argc,2);
if (real_argc > 3) wna_high(real_argc,3);
if (real_argc < 3) {
v_ALLOCATION_2 = LREF(s_lsp_NIL);
v_ALLOC_2DP_3 = NIL;
} else {
v_ALLOCATION_2 = NEXT_VAR_ARG;
v_ALLOC_2DP_3 = T;
}
END_VAR_ARGS;
if (v_ALLOC_2DP_3 != NIL) {
t2 = (add((GET_OE_SLOT(t0,1)), ((LP) 14)));
t1 = ICALL(s_lsp_FORMAT) (MV_CALL(argc,6), GET_OE_SLOT(t0,0), LREF(k5203), v_NAME_0, v_ALLOCATION_2, t2, v_VALUE_1);
return(t1);
} else {
t1 = ICALL(s_lsp_FORMAT) (MV_CALL(argc,5), GET_OE_SLOT(t0,0), LREF(k5204), v_NAME_0, GET_OE_SLOT(t0,1), v_VALUE_1);
return(t1);
}
}

LP p_pcl_ENV_5FINIT1723_2Danon51295130ENV_5FINIT1723_2DADJUST_2DSLOT_2DNAME_2DLENGTH5131(argc, v_NAME_0)
      ARGC argc;  LP v_NAME_0;
{
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t0 = OE;
v_X_2 = v_NAME_0;
t3 = ((LP) DEREF((v_NAME_0) + 7 * 4));
t2 = ICALL(s_lsp_LENGTH) (1, t3);
t1 = ICALL(s_lsp_MAX) (2, GET_OE_SLOT(t0,1), t2);
SET_OE_SLOT(t0,1,t1);
return(t1);
}

LP p_pcl_ENV_5FINIT1723_2Danon51275128(argc, v_OBJECT_0, v_STREAM_1)
      ARGC argc;  LP v_OBJECT_0; LP v_STREAM_1;
{
LP v_SYMBOL_4; LP v__2ASTANDARD_2DOUTPUT_2A_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 2) wna(argc,2);
v__2ASTANDARD_2DOUTPUT_2A_3 = v_STREAM_1;
BEGIN_SPEC_BIND(s_lsp__2ASTANDARD_2DOUTPUT_2A,v_STREAM_1);
v_SYMBOL_4 = LREF(s_pcl__2AOLD_2DDESCRIBE_2A);
t1 = ((LP) DEREF((LREF(s_pcl__2AOLD_2DDESCRIBE_2A)) + 0 * 4));
t0 = CODE_PTR(COERCE_TO_FUNCTION(t1))(MV_CALL(argc,1), v_OBJECT_0);
END_SPEC_BIND(s_lsp__2ASTANDARD_2DOUTPUT_2A);
return(t0);
}

LP p_pcl_ENV_5FINIT1723_2Danon51255126(argc, v_OBJECT_0)
      ARGC argc;  LP v_OBJECT_0;
{
LP v_SYMBOL_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
v_SYMBOL_1 = LREF(s_lsp__2ASTANDARD_2DOUTPUT_2A);
t0 = ((LP) DEREF((LREF(s_lsp__2ASTANDARD_2DOUTPUT_2A)) + 0 * 4));
ICALL(s_pcl_DESCRIBE_2DOBJECT) (2, v_OBJECT_0, t0);
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,0);
}
return(NIL);
}

