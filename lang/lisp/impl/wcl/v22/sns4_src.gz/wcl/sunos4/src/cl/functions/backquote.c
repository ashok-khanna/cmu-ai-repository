/*
:comment "Compiled at 4:02:17 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: Debug Library"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O2 -fPIC"
:version 0
:end-package-info 0
:sym BQ-PROCESS
:sym *BQ-SIMPLIFY*
:sym UNSAFE-SYMBOL-VALUE
:sym BQ-SIMPLIFY
:sym BQ-REMOVE-TOKENS
:sf BQ-COMPLETELY-PROCESS "p_lsp_BQ_2DCOMPLETELY_2DPROCESS"
:sym ATOM
:sym *BQ-QUOTE*
:sym NIL
:sym CONS
:sym CAR
:sym BACKQUOTE
:sym EQ
:sym CADR
:sym BQ-COMPLETELY-PROCESS
:sym *COMMA*
:sym *COMMA-ATSIGN*
:sym ERROR
:sym *COMMA-DOT*
:sym CDR
:sym BRACKET
:sym *BQ-APPEND*
:sym NRECONC
:sym CDDR
:sym NULL
:sf BQ-PROCESS "p_lsp_BQ_2DPROCESS"
:sym *BQ-LIST*
:sym *BQ-CLOBBERABLE*
:sf BRACKET "p_lsp_BRACKET"
:sym MAPTREE
:sym EQL
:sf MAPTREE "p_lsp_MAPTREE"
:sym CONSP
:sf BQ-SPLICING-FROB "p_lsp_BQ_2DSPLICING_2DFROB"
:sf BQ-FROB "p_lsp_BQ_2DFROB"
:sym UNSAFE-SYMBOL-FUNCTION
:sym BQ-SIMPLIFY-ARGS
:sf BQ-SIMPLIFY "p_lsp_BQ_2DSIMPLIFY"
:sym REVERSE
:sym BQ-ATTACH-APPEND
:sym CAAR
:sym BQ-SPLICING-FROB
:sym CDAR
:sym NOTANY
:sym BQ-ATTACH-CONSES
:sym *BQ-LIST**
:sym LAST
:sym CADAR
:sym BQ-FROB
:sym CDDAR
:sym CAADAR
:sym *BQ-NCONC*
:sf BQ-SIMPLIFY-ARGS "p_lsp_BQ_2DSIMPLIFY_2DARGS"
:sf NULL-OR-QUOTED "p_lsp_NULL_2DOR_2DQUOTED"
:sym NULL-OR-QUOTED
:sym APPEND/2
:sym *BQ-QUOTE-NIL*
:sym EQUAL
:sym LIST*
:sf BQ-ATTACH-APPEND "p_lsp_BQ_2DATTACH_2DAPPEND"
:sym EVERY
:sym RPLACD
:sf BQ-ATTACH-CONSES "p_lsp_BQ_2DATTACH_2DCONSES"
:sym LIST
:sym APPEND
:sym NCONC
:sym QUOTE
:sym CDDDR
:sf BQ-REMOVE-TOKENS "p_lsp_BQ_2DREMOVE_2DTOKENS"
:sym *BQ-COUNT*
:sym 1+
:sym T
:sym READ
:sf CHAR-MACRO-READ-BACKQUOTE "p_lsp_CHAR_2DMACRO_2DREAD_2DBACKQUOTE"
:sym PEEK-CHAR
:sym READ-CHAR
:sf CHAR-MACRO-READ-COMMA "p_lsp_CHAR_2DMACRO_2DREAD_2DCOMMA"
:pinfo BQ-SPLICING-FROB (X) NIL NIL NIL NIL NIL NIL T
:pinfo NULL-OR-QUOTED (X) NIL NIL NIL NIL NIL NIL T
:pinfo CHAR-MACRO-READ-COMMA (STREAM CHAR) NIL NIL NIL NIL NIL NIL T
:pinfo BQ-SIMPLIFY-ARGS (X) NIL NIL NIL NIL NIL NIL T
:pinfo BQ-ATTACH-APPEND (OP ITEM RESULT) NIL NIL NIL NIL NIL NIL T
:pinfo BQ-REMOVE-TOKENS (X) NIL NIL NIL NIL NIL NIL T
:pinfo BQ-ATTACH-CONSES (ITEMS RESULT) NIL NIL NIL NIL NIL NIL T
:pinfo BRACKET (X) NIL NIL NIL NIL NIL NIL T
:pinfo BQ-FROB (X) NIL NIL NIL NIL NIL NIL T
:pinfo CHAR-MACRO-READ-BACKQUOTE (STREAM CHAR) NIL NIL NIL NIL NIL NIL T
:pinfo BQ-SIMPLIFY (X) NIL NIL NIL NIL NIL NIL T
:pinfo MAPTREE (FN X) NIL NIL NIL NIL NIL NIL T
:pinfo BQ-COMPLETELY-PROCESS (X) NIL NIL NIL NIL NIL NIL T
:pinfo BQ-PROCESS (X) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_lsp_BQ_2DCOMPLETELY_2DPROCESS();
extern SYMBOL s_lsp_BQ_2DPROCESS; 
extern SYMBOL s_lsp__2ABQ_2DSIMPLIFY_2A; 
extern SYMBOL s_lsp_UNSAFE_2DSYMBOL_2DVALUE; 
extern SYMBOL s_lsp_BQ_2DSIMPLIFY; 
extern SYMBOL s_lsp_BQ_2DREMOVE_2DTOKENS; 
extern LP p_lsp_BQ_2DPROCESS();
extern SYMBOL s_lsp_ATOM; 
extern SYMBOL s_lsp__2ABQ_2DQUOTE_2A; 
extern SYMBOL s_lsp_NIL; 
extern SYMBOL s_lsp_CONS; 
extern SYMBOL s_lsp_CAR; 
extern SYMBOL s_lsp_BACKQUOTE; 
extern SYMBOL s_lsp_EQ; 
extern SYMBOL s_lsp_CADR; 
extern SYMBOL s_lsp_BQ_2DCOMPLETELY_2DPROCESS; 
extern SYMBOL s_lsp__2ACOMMA_2A; 
extern SYMBOL s_lsp__2ACOMMA_2DATSIGN_2A; 
MAKE_SIMPLE_STRING(k1757,12,",@~S after `");
extern SYMBOL s_lsp_ERROR; 
extern SYMBOL s_lsp__2ACOMMA_2DDOT_2A; 
MAKE_SIMPLE_STRING(k1758,13,",. ~S after `");
extern SYMBOL s_lsp_CDR; 
extern SYMBOL s_lsp_BRACKET; 
extern SYMBOL s_lsp__2ABQ_2DAPPEND_2A; 
extern SYMBOL s_lsp_NRECONC; 
extern SYMBOL s_lsp_CDDR; 
extern SYMBOL s_lsp_NULL; 
MAKE_SIMPLE_STRING(k1759,13,"Malformed ,~S");
MAKE_SIMPLE_STRING(k1760,11,"Dotted ,@~S");
MAKE_SIMPLE_STRING(k1761,11,"Dotted ,.~S");
extern LP p_lsp_BRACKET();
extern SYMBOL s_lsp__2ABQ_2DLIST_2A; 
extern SYMBOL s_lsp__2ABQ_2DCLOBBERABLE_2A; 
extern LP p_lsp_MAPTREE();
extern SYMBOL s_lsp_MAPTREE; 
extern SYMBOL s_lsp_EQL; 
extern LP p_lsp_BQ_2DSPLICING_2DFROB();
extern SYMBOL s_lsp_CONSP; 
extern LP p_lsp_BQ_2DFROB();
extern LP p_lsp_BQ_2DSIMPLIFY();
extern SYMBOL s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION; 
extern SYMBOL s_lsp_BQ_2DSIMPLIFY_2DARGS; 
extern LP p_lsp_BQ_2DSIMPLIFY_2DARGS();
extern SYMBOL s_lsp_REVERSE; 
extern SYMBOL s_lsp_BQ_2DATTACH_2DAPPEND; 
extern SYMBOL s_lsp_CAAR; 
extern SYMBOL s_lsp_BQ_2DSPLICING_2DFROB; 
extern SYMBOL s_lsp_CDAR; 
extern SYMBOL s_lsp_NOTANY; 
extern SYMBOL s_lsp_BQ_2DATTACH_2DCONSES; 
extern SYMBOL s_lsp__2ABQ_2DLIST_2A_2A; 
extern SYMBOL s_lsp_LAST; 
extern SYMBOL s_lsp_CADAR; 
extern SYMBOL s_lsp_BQ_2DFROB; 
extern SYMBOL s_lsp_CDDAR; 
extern SYMBOL s_lsp_CAADAR; 
extern SYMBOL s_lsp__2ABQ_2DNCONC_2A; 
extern LP p_lsp_NULL_2DOR_2DQUOTED();
extern LP p_lsp_BQ_2DATTACH_2DAPPEND();
extern SYMBOL s_lsp_NULL_2DOR_2DQUOTED; 
extern SYMBOL s_lsp_APPEND_2F2; 
extern SYMBOL s_lsp__2ABQ_2DQUOTE_2DNIL_2A; 
extern SYMBOL s_lsp_EQUAL; 
extern SYMBOL s_lsp_LIST_2A; 
extern LP p_lsp_BQ_2DATTACH_2DCONSES();
extern SYMBOL s_lsp_EVERY; 
extern SYMBOL s_lsp_RPLACD; 
extern LP p_lsp_BQ_2DREMOVE_2DTOKENS();
extern SYMBOL s_lsp_LIST; 
extern SYMBOL s_lsp_APPEND; 
extern SYMBOL s_lsp_NCONC; 
extern SYMBOL s_lsp_QUOTE; 
extern SYMBOL s_lsp_CDDDR; 
extern LP p_lsp_CHAR_2DMACRO_2DREAD_2DBACKQUOTE();
extern SYMBOL s_lsp__2ABQ_2DCOUNT_2A; 
extern SYMBOL s_lsp_1_2B; 
extern SYMBOL s_lsp_T; 
extern SYMBOL s_lsp_READ; 
extern LP p_lsp_CHAR_2DMACRO_2DREAD_2DCOMMA();
extern SYMBOL s_lsp_PEEK_2DCHAR; 
extern SYMBOL s_lsp_READ_2DCHAR; 
MAKE_SIMPLE_STRING(k1763,45,"A comma was read without a matching backquote");


extern LP greaterp();


LP p_lsp_BQ_2DCOMPLETELY_2DPROCESS(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{
LP v_RAW_2DRESULT_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
if (argc != 1) wna(argc,1);
v_RAW_2DRESULT_2 = ICALL(s_lsp_BQ_2DPROCESS) (1, v_X_0);
t2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DSIMPLIFY_2A));
if (t2 != NIL) {
t1 = ICALL(s_lsp_BQ_2DSIMPLIFY) (1, v_RAW_2DRESULT_2);
} else {
t1 = v_RAW_2DRESULT_2;
}
t0 = ICALL(s_lsp_BQ_2DREMOVE_2DTOKENS) (MV_CALL(argc,1), t1);
return(t0);
}

LP p_lsp_BQ_2DPROCESS(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{
LP v_TMP2138_8; LP v_TMP2137_7; LP v_Q_4; 
LP v_P_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 

if (argc != 1) wna(argc,1);
START1756:
t1 = ICALL(s_lsp_ATOM) (1, v_X_0);
if (t1 != NIL) {
t2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DQUOTE_2A));
t3 = ICALL(s_lsp_CONS) (2, v_X_0, LREF(s_lsp_NIL));
t0 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t2, t3);
return(t0);
} else {
t5 = ICALL(s_lsp_CAR) (1, v_X_0);
t4 = ICALL(s_lsp_EQ) (2, t5, LREF(s_lsp_BACKQUOTE));
if (t4 != NIL) {
t7 = ICALL(s_lsp_CADR) (1, v_X_0);
t6 = ICALL(s_lsp_BQ_2DCOMPLETELY_2DPROCESS) (1, t7);
v_X_0 = t6; 
goto START1756;
} else {
t9 = ICALL(s_lsp_CAR) (1, v_X_0);
t10 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ACOMMA_2A));
t8 = ICALL(s_lsp_EQ) (2, t9, t10);
if (t8 != NIL) {
t0 = ICALL(s_lsp_CADR) (MV_CALL(argc,1), v_X_0);
return(t0);
} else {
t12 = ICALL(s_lsp_CAR) (1, v_X_0);
t13 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ACOMMA_2DATSIGN_2A));
t11 = ICALL(s_lsp_EQ) (2, t12, t13);
if (t11 != NIL) {
t14 = ICALL(s_lsp_CADR) (1, v_X_0);
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,2), LREF(k1757), t14);
return(t0);
} else {
t16 = ICALL(s_lsp_CAR) (1, v_X_0);
t17 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ACOMMA_2DDOT_2A));
t15 = ICALL(s_lsp_EQ) (2, t16, t17);
if (t15 != NIL) {
t18 = ICALL(s_lsp_CADR) (1, v_X_0);
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,2), LREF(k1758), t18);
return(t0);
} else {
v_P_3 = v_X_0;
v_Q_4 = LREF(s_lsp_NIL);
goto t_TEST2135_6;
t_LOOP2136_5:;
v_TMP2137_7 = ICALL(s_lsp_CDR) (1, v_P_3);
t20 = ICALL(s_lsp_CAR) (1, v_P_3);
t19 = ICALL(s_lsp_BRACKET) (1, t20);
v_TMP2138_8 = ICALL(s_lsp_CONS) (2, t19, v_Q_4);
v_P_3 = v_TMP2137_7;
v_Q_4 = v_TMP2138_8;
t_TEST2135_6:;
t21 = ICALL(s_lsp_ATOM) (1, v_P_3);
if (t21 != NIL) {
t23 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DAPPEND_2A));
t27 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DQUOTE_2A));
t28 = ICALL(s_lsp_CONS) (2, v_P_3, LREF(s_lsp_NIL));
t26 = ICALL(s_lsp_CONS) (2, t27, t28);
t25 = ICALL(s_lsp_CONS) (2, t26, LREF(s_lsp_NIL));
t24 = ICALL(s_lsp_NRECONC) (2, v_Q_4, t25);
t22 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t23, t24);
return(t22);
return(NIL);
}
t30 = ICALL(s_lsp_CAR) (1, v_P_3);
t31 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ACOMMA_2A));
t29 = ICALL(s_lsp_EQ) (2, t30, t31);
if (t29 != NIL) {
t33 = ICALL(s_lsp_CDDR) (1, v_P_3);
t32 = ICALL(s_lsp_NULL) (1, t33);
if (t32 == NIL) {
ICALL(s_lsp_ERROR) (2, LREF(k1759), v_P_3);
}
t35 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DAPPEND_2A));
t38 = ICALL(s_lsp_CADR) (1, v_P_3);
t37 = ICALL(s_lsp_CONS) (2, t38, LREF(s_lsp_NIL));
t36 = ICALL(s_lsp_NRECONC) (2, v_Q_4, t37);
t34 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t35, t36);
return(t34);
return(NIL);
}
t40 = ICALL(s_lsp_CAR) (1, v_P_3);
t41 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ACOMMA_2DATSIGN_2A));
t39 = ICALL(s_lsp_EQ) (2, t40, t41);
if (t39 != NIL) {
ICALL(s_lsp_ERROR) (2, LREF(k1760), v_P_3);
}
t43 = ICALL(s_lsp_CAR) (1, v_P_3);
t44 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ACOMMA_2DDOT_2A));
t42 = ICALL(s_lsp_EQ) (2, t43, t44);
if (t42 != NIL) {
ICALL(s_lsp_ERROR) (2, LREF(k1761), v_P_3);
}
goto t_LOOP2136_5;
return(NIL);
}
}
}
}
}
}

LP p_lsp_BRACKET(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 

if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_ATOM) (1, v_X_0);
if (t1 != NIL) {
t2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DLIST_2A));
t4 = ICALL(s_lsp_BQ_2DPROCESS) (1, v_X_0);
t3 = ICALL(s_lsp_CONS) (2, t4, LREF(s_lsp_NIL));
t0 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t2, t3);
return(t0);
} else {
t6 = ICALL(s_lsp_CAR) (1, v_X_0);
t7 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ACOMMA_2A));
t5 = ICALL(s_lsp_EQ) (2, t6, t7);
if (t5 != NIL) {
t8 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DLIST_2A));
t10 = ICALL(s_lsp_CADR) (1, v_X_0);
t9 = ICALL(s_lsp_CONS) (2, t10, LREF(s_lsp_NIL));
t0 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t8, t9);
return(t0);
} else {
t12 = ICALL(s_lsp_CAR) (1, v_X_0);
t13 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ACOMMA_2DATSIGN_2A));
t11 = ICALL(s_lsp_EQ) (2, t12, t13);
if (t11 != NIL) {
t0 = ICALL(s_lsp_CADR) (MV_CALL(argc,1), v_X_0);
return(t0);
} else {
t15 = ICALL(s_lsp_CAR) (1, v_X_0);
t16 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ACOMMA_2DDOT_2A));
t14 = ICALL(s_lsp_EQ) (2, t15, t16);
if (t14 != NIL) {
t17 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DCLOBBERABLE_2A));
t19 = ICALL(s_lsp_CADR) (1, v_X_0);
t18 = ICALL(s_lsp_CONS) (2, t19, LREF(s_lsp_NIL));
t0 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t17, t18);
return(t0);
} else {
t20 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DLIST_2A));
t22 = ICALL(s_lsp_BQ_2DPROCESS) (1, v_X_0);
t21 = ICALL(s_lsp_CONS) (2, t22, LREF(s_lsp_NIL));
t0 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t20, t21);
return(t0);
}
}
}
}
}

LP p_lsp_MAPTREE(argc, v_FN_0, v_X_1)
      ARGC argc;  LP v_FN_0; LP v_X_1;
{
LP v_D_4; LP v_A_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; 
if (argc != 2) wna(argc,2);
t1 = ICALL(s_lsp_ATOM) (1, v_X_1);
if (t1 != NIL) {
t0 = CODE_PTR(COERCE_TO_FUNCTION(v_FN_0))(MV_CALL(argc,1), v_X_1);
return(t0);
} else {
t2 = ICALL(s_lsp_CAR) (1, v_X_1);
v_A_3 = CODE_PTR(COERCE_TO_FUNCTION(v_FN_0))(1, t2);
t3 = ICALL(s_lsp_CDR) (1, v_X_1);
v_D_4 = ICALL(s_lsp_MAPTREE) (2, v_FN_0, t3);
t6 = ICALL(s_lsp_CAR) (1, v_X_1);
t5 = ICALL(s_lsp_EQL) (2, v_A_3, t6);
if (t5 != NIL) {
t7 = ICALL(s_lsp_CDR) (1, v_X_1);
t4 = ICALL(s_lsp_EQL) (2, v_D_4, t7);
} else {
t4 = LREF(s_lsp_NIL);
}
if (t4 != NIL) {
return(v_X_1);
} else {
t0 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), v_A_3, v_D_4);
return(t0);
}
}
}

LP p_lsp_BQ_2DSPLICING_2DFROB(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{
LP v_G2139_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; 
if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_CONSP) (1, v_X_0);
if (t1 != NIL) {
t2 = ICALL(s_lsp_CAR) (1, v_X_0);
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ACOMMA_2DATSIGN_2A));
v_G2139_2 = ICALL(s_lsp_EQ) (2, t2, t3);
if (v_G2139_2 != NIL) {
return(v_G2139_2);
} else {
t4 = ICALL(s_lsp_CAR) (1, v_X_0);
t5 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ACOMMA_2DDOT_2A));
t0 = ICALL(s_lsp_EQ) (MV_CALL(argc,2), t4, t5);
return(t0);
}
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_BQ_2DFROB(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{
LP v_G2141_3; LP v_G2140_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; 
if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_CONSP) (1, v_X_0);
if (t1 != NIL) {
t2 = ICALL(s_lsp_CAR) (1, v_X_0);
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ACOMMA_2A));
v_G2140_2 = ICALL(s_lsp_EQ) (2, t2, t3);
if (v_G2140_2 != NIL) {
return(v_G2140_2);
} else {
t4 = ICALL(s_lsp_CAR) (1, v_X_0);
t5 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ACOMMA_2DATSIGN_2A));
v_G2141_3 = ICALL(s_lsp_EQ) (2, t4, t5);
if (v_G2141_3 != NIL) {
return(v_G2141_3);
} else {
t6 = ICALL(s_lsp_CAR) (1, v_X_0);
t7 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ACOMMA_2DDOT_2A));
t0 = ICALL(s_lsp_EQ) (MV_CALL(argc,2), t6, t7);
return(t0);
}
}
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_BQ_2DSIMPLIFY(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; 
if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_ATOM) (1, v_X_0);
if (t1 != NIL) {
return(v_X_0);
} else {
t3 = ICALL(s_lsp_CAR) (1, v_X_0);
t4 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DQUOTE_2A));
t2 = ICALL(s_lsp_EQ) (2, t3, t4);
if (t2 != NIL) {
v_X_2 = v_X_0;
} else {
t5 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_BQ_2DSIMPLIFY));
v_X_2 = ICALL(s_lsp_MAPTREE) (2, t5, v_X_0);
}
t7 = ICALL(s_lsp_CAR) (1, v_X_2);
t8 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DAPPEND_2A));
t6 = ICALL(s_lsp_EQ) (2, t7, t8);
if (t6 != NIL) {
t0 = ICALL(s_lsp_BQ_2DSIMPLIFY_2DARGS) (MV_CALL(argc,1), v_X_2);
return(t0);
} else {
return(v_X_2);
}
}
}

LP p_lsp_BQ_2DSIMPLIFY_2DARGS(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{
LP v_TMP2145_9; LP v_TMP2144_8; LP v_RESULT_5; 
LP v_ARGS_4; LP v_R_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 

if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_CDR) (1, v_X_0);
v_R_2 = ICALL(s_lsp_REVERSE) (1, t0);
v_ARGS_4 = ICALL(s_lsp_CDR) (1, v_R_2);
v_RESULT_5 = ICALL(s_lsp_CAR) (1, v_R_2);
goto t_TEST2142_7;
t_LOOP2143_6:;
v_TMP2144_8 = ICALL(s_lsp_CDR) (1, v_ARGS_4);
t3 = ICALL(s_lsp_CAR) (1, v_ARGS_4);
t2 = ICALL(s_lsp_ATOM) (1, t3);
if (t2 != NIL) {
t4 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DAPPEND_2A));
t5 = ICALL(s_lsp_CAR) (1, v_ARGS_4);
v_TMP2145_9 = ICALL(s_lsp_BQ_2DATTACH_2DAPPEND) (3, t4, t5, v_RESULT_5);
} else {
t8 = ICALL(s_lsp_CAAR) (1, v_ARGS_4);
t9 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DLIST_2A));
t7 = ICALL(s_lsp_EQ) (2, t8, t9);
if (t7 != NIL) {
t10 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_BQ_2DSPLICING_2DFROB));
t11 = ICALL(s_lsp_CDAR) (1, v_ARGS_4);
t6 = ICALL(s_lsp_NOTANY) (2, t10, t11);
} else {
t6 = LREF(s_lsp_NIL);
}
if (t6 != NIL) {
t12 = ICALL(s_lsp_CDAR) (1, v_ARGS_4);
v_TMP2145_9 = ICALL(s_lsp_BQ_2DATTACH_2DCONSES) (2, t12, v_RESULT_5);
} else {
t15 = ICALL(s_lsp_CAAR) (1, v_ARGS_4);
t16 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DLIST_2A_2A));
t14 = ICALL(s_lsp_EQ) (2, t15, t16);
if (t14 != NIL) {
t17 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_BQ_2DSPLICING_2DFROB));
t18 = ICALL(s_lsp_CDAR) (1, v_ARGS_4);
t13 = ICALL(s_lsp_NOTANY) (2, t17, t18);
} else {
t13 = LREF(s_lsp_NIL);
}
if (t13 != NIL) {
t22 = ICALL(s_lsp_CDAR) (1, v_ARGS_4);
t21 = ICALL(s_lsp_REVERSE) (1, t22);
t20 = ICALL(s_lsp_CDR) (1, t21);
t19 = ICALL(s_lsp_REVERSE) (1, t20);
t24 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DAPPEND_2A));
t27 = ICALL(s_lsp_CAR) (1, v_ARGS_4);
t26 = ICALL(s_lsp_LAST) (1, t27);
t25 = ICALL(s_lsp_CAR) (1, t26);
t23 = ICALL(s_lsp_BQ_2DATTACH_2DAPPEND) (3, t24, t25, v_RESULT_5);
v_TMP2145_9 = ICALL(s_lsp_BQ_2DATTACH_2DCONSES) (2, t19, t23);
} else {
t30 = ICALL(s_lsp_CAAR) (1, v_ARGS_4);
t31 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DQUOTE_2A));
t29 = ICALL(s_lsp_EQ) (2, t30, t31);
if (t29 != NIL) {
t33 = ICALL(s_lsp_CADAR) (1, v_ARGS_4);
t32 = ICALL(s_lsp_CONSP) (1, t33);
if (t32 != NIL) {
t35 = ICALL(s_lsp_CADAR) (1, v_ARGS_4);
t34 = ICALL(s_lsp_BQ_2DFROB) (1, t35);
if (t34 != NIL) {
t28 = LREF(s_lsp_NIL);
} else {
t36 = ICALL(s_lsp_CDDAR) (1, v_ARGS_4);
t28 = ICALL(s_lsp_NULL) (1, t36);
}
} else {
t28 = LREF(s_lsp_NIL);
}
} else {
t28 = LREF(s_lsp_NIL);
}
if (t28 != NIL) {
t39 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DQUOTE_2A));
t41 = ICALL(s_lsp_CAADAR) (1, v_ARGS_4);
t40 = ICALL(s_lsp_CONS) (2, t41, LREF(s_lsp_NIL));
t38 = ICALL(s_lsp_CONS) (2, t39, t40);
t37 = ICALL(s_lsp_CONS) (2, t38, LREF(s_lsp_NIL));
v_TMP2145_9 = ICALL(s_lsp_BQ_2DATTACH_2DCONSES) (2, t37, v_RESULT_5);
} else {
t43 = ICALL(s_lsp_CAAR) (1, v_ARGS_4);
t44 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DCLOBBERABLE_2A));
t42 = ICALL(s_lsp_EQ) (2, t43, t44);
if (t42 != NIL) {
t45 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DNCONC_2A));
t46 = ICALL(s_lsp_CADAR) (1, v_ARGS_4);
v_TMP2145_9 = ICALL(s_lsp_BQ_2DATTACH_2DAPPEND) (3, t45, t46, v_RESULT_5);
} else {
t47 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DAPPEND_2A));
t48 = ICALL(s_lsp_CAR) (1, v_ARGS_4);
v_TMP2145_9 = ICALL(s_lsp_BQ_2DATTACH_2DAPPEND) (3, t47, t48, v_RESULT_5);
}
}
}
}
}
v_ARGS_4 = v_TMP2144_8;
v_RESULT_5 = v_TMP2145_9;
t_TEST2142_7:;
if (v_ARGS_4 == NIL) {
return(v_RESULT_5);
return(NIL);
}
goto t_LOOP2143_6;
return(NIL);
}

LP p_lsp_NULL_2DOR_2DQUOTED(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{
LP v_G2146_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 1) wna(argc,1);
v_G2146_2 = ICALL(s_lsp_NULL) (1, v_X_0);
if (v_G2146_2 != NIL) {
return(v_G2146_2);
} else {
t1 = ICALL(s_lsp_CONSP) (1, v_X_0);
if (t1 != NIL) {
t2 = ICALL(s_lsp_CAR) (1, v_X_0);
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DQUOTE_2A));
t0 = ICALL(s_lsp_EQ) (MV_CALL(argc,2), t2, t3);
return(t0);
} else {
return(LREF(s_lsp_NIL));
}
}
}

LP p_lsp_BQ_2DATTACH_2DAPPEND(argc, v_OP_0, v_ITEM_1, v_RESULT_2)
      ARGC argc;  LP v_OP_0; LP v_ITEM_1; LP v_RESULT_2;
{
LP v_G2147_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 

if (argc != 3) wna(argc,3);
t2 = ICALL(s_lsp_NULL_2DOR_2DQUOTED) (1, v_ITEM_1);
if (t2 != NIL) {
t1 = ICALL(s_lsp_NULL_2DOR_2DQUOTED) (1, v_RESULT_2);
} else {
t1 = LREF(s_lsp_NIL);
}
if (t1 != NIL) {
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DQUOTE_2A));
t6 = ICALL(s_lsp_CADR) (1, v_ITEM_1);
t7 = ICALL(s_lsp_CADR) (1, v_RESULT_2);
t5 = ICALL(s_lsp_APPEND_2F2) (2, t6, t7);
t4 = ICALL(s_lsp_CONS) (2, t5, LREF(s_lsp_NIL));
t0 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t3, t4);
return(t0);
} else {
v_G2147_4 = ICALL(s_lsp_NULL) (1, v_RESULT_2);
if (v_G2147_4 != NIL) {
t8 = v_G2147_4;
} else {
t9 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DQUOTE_2DNIL_2A));
t8 = ICALL(s_lsp_EQUAL) (2, v_RESULT_2, t9);
}
if (t8 != NIL) {
t10 = ICALL(s_lsp_BQ_2DSPLICING_2DFROB) (1, v_ITEM_1);
if (t10 != NIL) {
t11 = ICALL(s_lsp_CONS) (2, v_ITEM_1, LREF(s_lsp_NIL));
t0 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), v_OP_0, t11);
return(t0);
} else {
return(v_ITEM_1);
}
} else {
t13 = ICALL(s_lsp_CONSP) (1, v_RESULT_2);
if (t13 != NIL) {
t14 = ICALL(s_lsp_CAR) (1, v_RESULT_2);
t12 = ICALL(s_lsp_EQ) (2, t14, v_OP_0);
} else {
t12 = LREF(s_lsp_NIL);
}
if (t12 != NIL) {
t15 = ICALL(s_lsp_CAR) (1, v_RESULT_2);
t16 = ICALL(s_lsp_CDR) (1, v_RESULT_2);
t0 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,3), t15, v_ITEM_1, t16);
return(t0);
} else {
t18 = ICALL(s_lsp_CONS) (2, v_RESULT_2, LREF(s_lsp_NIL));
t17 = ICALL(s_lsp_CONS) (2, v_ITEM_1, t18);
t0 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), v_OP_0, t17);
return(t0);
}
}
}
}

LP p_lsp_BQ_2DATTACH_2DCONSES(argc, v_ITEMS_0, v_RESULT_1)
      ARGC argc;  LP v_ITEMS_0; LP v_RESULT_1;
{
LP v_G2150_12; LP v_G2149_11; LP v_LOOPVAR_2D707_7; 
LP v_LOOPVAR_2D706_6; LP v_LOOPVAR_2D705_5; LP v_LOOP_2DLIST_2D704_4; 
LP v_L2148_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; 
if (argc != 2) wna(argc,2);
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_NULL_2DOR_2DQUOTED));
t2 = ICALL(s_lsp_EVERY) (2, t3, v_ITEMS_0);
if (t2 != NIL) {
t1 = ICALL(s_lsp_NULL_2DOR_2DQUOTED) (1, v_RESULT_1);
} else {
t1 = LREF(s_lsp_NIL);
}
if (t1 != NIL) {
t4 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DQUOTE_2A));
v_L2148_3 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D704_4 = v_ITEMS_0;
v_LOOPVAR_2D705_5 = LREF(s_lsp_NIL);
v_LOOPVAR_2D706_6 = LREF(s_lsp_NIL);
v_LOOPVAR_2D707_7 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_9:;
if (v_LOOP_2DLIST_2D704_4 == NIL) {
goto t_END_2DLOOP_10;
}
v_L2148_3 = ICALL(s_lsp_CAR) (1, v_LOOP_2DLIST_2D704_4);
v_LOOP_2DLIST_2D704_4 = ICALL(s_lsp_CDR) (1, v_LOOP_2DLIST_2D704_4);
t8 = ICALL(s_lsp_CADR) (1, v_L2148_3);
v_LOOPVAR_2D707_7 = ICALL(s_lsp_CONS) (2, t8, LREF(s_lsp_NIL));
if (v_LOOPVAR_2D706_6 != NIL) {
t9 = ICALL(s_lsp_RPLACD) (2, v_LOOPVAR_2D706_6, v_LOOPVAR_2D707_7);
v_LOOPVAR_2D706_6 = ICALL(s_lsp_CDR) (1, t9);
} else {
v_LOOPVAR_2D705_5 = v_LOOPVAR_2D707_7;
v_LOOPVAR_2D706_6 = v_LOOPVAR_2D705_5;
}
goto t_NEXT_2DLOOP_9;
goto t_END_2DLOOP_10;
t_END_2DLOOP_10:;
t7 = v_LOOPVAR_2D705_5;
goto b_NIL_8;
t7 = NIL;
b_NIL_8:;
t10 = ICALL(s_lsp_CADR) (1, v_RESULT_1);
t6 = ICALL(s_lsp_APPEND_2F2) (2, t7, t10);
t5 = ICALL(s_lsp_CONS) (2, t6, LREF(s_lsp_NIL));
t0 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t4, t5);
return(t0);
} else {
v_G2150_12 = ICALL(s_lsp_NULL) (1, v_RESULT_1);
if (v_G2150_12 != NIL) {
t11 = v_G2150_12;
} else {
t12 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DQUOTE_2DNIL_2A));
t11 = ICALL(s_lsp_EQUAL) (2, v_RESULT_1, t12);
}
if (t11 != NIL) {
t13 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DLIST_2A));
t0 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t13, v_ITEMS_0);
return(t0);
} else {
t15 = ICALL(s_lsp_CONSP) (1, v_RESULT_1);
if (t15 != NIL) {
t16 = ICALL(s_lsp_CAR) (1, v_RESULT_1);
t17 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DLIST_2A));
v_G2149_11 = ICALL(s_lsp_EQ) (2, t16, t17);
if (v_G2149_11 != NIL) {
t14 = v_G2149_11;
} else {
t18 = ICALL(s_lsp_CAR) (1, v_RESULT_1);
t19 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DLIST_2A_2A));
t14 = ICALL(s_lsp_EQ) (2, t18, t19);
}
} else {
t14 = LREF(s_lsp_NIL);
}
if (t14 != NIL) {
t20 = ICALL(s_lsp_CAR) (1, v_RESULT_1);
t22 = ICALL(s_lsp_CDR) (1, v_RESULT_1);
t21 = ICALL(s_lsp_APPEND_2F2) (2, v_ITEMS_0, t22);
t0 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t20, t21);
return(t0);
} else {
t23 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DLIST_2A_2A));
t25 = ICALL(s_lsp_CONS) (2, v_RESULT_1, LREF(s_lsp_NIL));
t24 = ICALL(s_lsp_APPEND_2F2) (2, v_ITEMS_0, t25);
t0 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t23, t24);
return(t0);
}
}
}
}

LP p_lsp_BQ_2DREMOVE_2DTOKENS(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; 
if (argc != 1) wna(argc,1);
START1762:
t2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DLIST_2A));
t1 = ICALL(s_lsp_EQ) (2, v_X_0, t2);
if (t1 != NIL) {
return(LREF(s_lsp_LIST));
} else {
t4 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DAPPEND_2A));
t3 = ICALL(s_lsp_EQ) (2, v_X_0, t4);
if (t3 != NIL) {
return(LREF(s_lsp_APPEND));
} else {
t6 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DNCONC_2A));
t5 = ICALL(s_lsp_EQ) (2, v_X_0, t6);
if (t5 != NIL) {
return(LREF(s_lsp_NCONC));
} else {
t8 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DLIST_2A_2A));
t7 = ICALL(s_lsp_EQ) (2, v_X_0, t8);
if (t7 != NIL) {
return(LREF(s_lsp_LIST_2A));
} else {
t10 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DQUOTE_2A));
t9 = ICALL(s_lsp_EQ) (2, v_X_0, t10);
if (t9 != NIL) {
return(LREF(s_lsp_QUOTE));
} else {
t11 = ICALL(s_lsp_ATOM) (1, v_X_0);
if (t11 != NIL) {
return(v_X_0);
} else {
t13 = ICALL(s_lsp_CAR) (1, v_X_0);
t14 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DCLOBBERABLE_2A));
t12 = ICALL(s_lsp_EQ) (2, t13, t14);
if (t12 != NIL) {
t15 = ICALL(s_lsp_CADR) (1, v_X_0);
v_X_0 = t15; 
goto START1762;
} else {
t18 = ICALL(s_lsp_CAR) (1, v_X_0);
t19 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DLIST_2A_2A));
t17 = ICALL(s_lsp_EQ) (2, t18, t19);
if (t17 != NIL) {
t21 = ICALL(s_lsp_CDDR) (1, v_X_0);
t20 = ICALL(s_lsp_CONSP) (1, t21);
if (t20 != NIL) {
t22 = ICALL(s_lsp_CDDDR) (1, v_X_0);
t16 = ICALL(s_lsp_NULL) (1, t22);
} else {
t16 = LREF(s_lsp_NIL);
}
} else {
t16 = LREF(s_lsp_NIL);
}
if (t16 != NIL) {
t24 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_BQ_2DREMOVE_2DTOKENS));
t25 = ICALL(s_lsp_CDR) (1, v_X_0);
t23 = ICALL(s_lsp_MAPTREE) (2, t24, t25);
t0 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), LREF(s_lsp_CONS), t23);
return(t0);
} else {
t26 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_BQ_2DREMOVE_2DTOKENS));
t0 = ICALL(s_lsp_MAPTREE) (MV_CALL(argc,2), t26, v_X_0);
return(t0);
}
}
}
}
}
}
}
}
}

LP p_lsp_CHAR_2DMACRO_2DREAD_2DBACKQUOTE(argc, v_STREAM_0, v_CHAR_1)
      ARGC argc;  LP v_STREAM_0; LP v_CHAR_1;
{
LP v__2ABQ_2DCOUNT_2A_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DCOUNT_2A));
v__2ABQ_2DCOUNT_2A_3 = ICALL(s_lsp_1_2B) (1, t0);
BEGIN_SPEC_BIND(s_lsp__2ABQ_2DCOUNT_2A,v__2ABQ_2DCOUNT_2A_3);
t3 = ICALL(s_lsp_READ) (4, v_STREAM_0, LREF(s_lsp_T), LREF(s_lsp_NIL), LREF(s_lsp_T));
t2 = ICALL(s_lsp_CONS) (2, t3, LREF(s_lsp_NIL));
t1 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), LREF(s_lsp_BACKQUOTE), t2);
END_SPEC_BIND(s_lsp__2ABQ_2DCOUNT_2A);
return(t1);
}

LP p_lsp_CHAR_2DMACRO_2DREAD_2DCOMMA(argc, v_STREAM_0, v_CHAR_1)
      ARGC argc;  LP v_STREAM_0; LP v_CHAR_1;
{
LP v_KEY2151_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; 
if (argc != 2) wna(argc,2);
t2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ABQ_2DCOUNT_2A));
t1 = (greaterp((t2), ((LP) 0)));
if (t1 != NIL) {
v_KEY2151_3 = ICALL(s_lsp_PEEK_2DCHAR) (5, LREF(s_lsp_NIL), v_STREAM_0, LREF(s_lsp_T), LREF(s_lsp_NIL), LREF(s_lsp_T));
t3 = ICALL(s_lsp_EQL) (2, v_KEY2151_3, LREF(char_tab[64]));
if (t3 != NIL) {
ICALL(s_lsp_READ_2DCHAR) (4, v_STREAM_0, LREF(s_lsp_T), LREF(s_lsp_NIL), LREF(s_lsp_T));
t4 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ACOMMA_2DATSIGN_2A));
t6 = ICALL(s_lsp_READ) (4, v_STREAM_0, LREF(s_lsp_T), LREF(s_lsp_NIL), LREF(s_lsp_T));
t5 = ICALL(s_lsp_CONS) (2, t6, LREF(s_lsp_NIL));
t0 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t4, t5);
return(t0);
} else {
t7 = ICALL(s_lsp_EQL) (2, v_KEY2151_3, LREF(char_tab[46]));
if (t7 != NIL) {
ICALL(s_lsp_READ_2DCHAR) (4, v_STREAM_0, LREF(s_lsp_T), LREF(s_lsp_NIL), LREF(s_lsp_T));
t8 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ACOMMA_2DDOT_2A));
t10 = ICALL(s_lsp_READ) (4, v_STREAM_0, LREF(s_lsp_T), LREF(s_lsp_NIL), LREF(s_lsp_T));
t9 = ICALL(s_lsp_CONS) (2, t10, LREF(s_lsp_NIL));
t0 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t8, t9);
return(t0);
} else {
t11 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2ACOMMA_2A));
t13 = ICALL(s_lsp_READ) (4, v_STREAM_0, LREF(s_lsp_T), LREF(s_lsp_NIL), LREF(s_lsp_T));
t12 = ICALL(s_lsp_CONS) (2, t13, LREF(s_lsp_NIL));
t0 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t11, t12);
return(t0);
}
}
} else {
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,1), LREF(k1763));
return(t0);
}
}

