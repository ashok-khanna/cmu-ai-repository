/*
:comment "Compiled at 5:01:16 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: DEFAULT"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O "
:version 0
:end-package-info 0
:sym PROBE-FILE
:sym FIND-ROOT-DIRECTORY
:sym *ROOT-DIRECTORY*
:sym T
:sym *WCL-VERSION*
:sym OS-VERSION
:sym MACHINE-INSTANCE
:sym FORMAT
:sym *CL-VERSION*
:sym *CL-BUILD-DATE*
:sym *COMPILER-VERSION*
:sym *COMPILER-BUILD-DATE*
:sym PRINT-COPYRIGHT
:sym LOAD-INIT-FILE
:sym REPL
:sf LMAIN "p_lsp_LMAIN"
:pinfo LMAIN NIL NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_lsp_LMAIN();
MAKE_SIMPLE_STRING(k16229,24,"/auto/u/wade/wcl/sunos4/");
extern SYMBOL s_lsp_PROBE_2DFILE; 
extern SYMBOL s_lsp_FIND_2DROOT_2DDIRECTORY; 
extern SYMBOL s_lsp__2AROOT_2DDIRECTORY_2A; 
extern SYMBOL s_lsp_T; 
MAKE_SIMPLE_STRING(k16230,69,";;; WCL ~A Development Environment for SPARC running SunOS ~A on ~A~%");
extern SYMBOL s_lsp__2AWCL_2DVERSION_2A; 
extern SYMBOL s_lsp_OS_2DVERSION; 
extern SYMBOL s_lsp_MACHINE_2DINSTANCE; 
extern SYMBOL s_lsp_FORMAT; 
MAKE_SIMPLE_STRING(k16231,40,";;; Common Lisp ~A library built at ~A~%");
extern SYMBOL s_lsp__2ACL_2DVERSION_2A; 
extern SYMBOL s_lsp__2ACL_2DBUILD_2DDATE_2A; 
MAKE_SIMPLE_STRING(k16232,37,";;; Compiler ~A library built at ~A~%");
extern SYMBOL s_lsp__2ACOMPILER_2DVERSION_2A; 
extern SYMBOL s_lsp__2ACOMPILER_2DBUILD_2DDATE_2A; 
extern SYMBOL s_lsp_PRINT_2DCOPYRIGHT; 
extern SYMBOL s_lsp_LOAD_2DINIT_2DFILE; 
extern SYMBOL s_lsp_REPL; 




LP p_lsp_LMAIN(argc)
      ARGC argc; 
{
LP v_SYMBOL_14; LP v_SYMBOL_12; LP v_SYMBOL_10; 
LP v_SYMBOL_8; LP v_SYMBOL_6; LP v_V_4; 
LP v_X_3; LP v_S7639_2; LP v_G7640_1; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; 
if (argc != 0) wna(argc,0);
v_G7640_1 = ICALL(s_lsp_PROBE_2DFILE) (1, LREF(k16229));
if (v_G7640_1 != NIL) {
v_S7639_2 = v_G7640_1;
} else {
v_S7639_2 = ICALL(s_lsp_FIND_2DROOT_2DDIRECTORY) (0);
}
v_V_4 = v_S7639_2;
((LP) (DEREF((LREF(s_lsp__2AROOT_2DDIRECTORY_2A)) + 0 * 4) = (LD) (v_V_4)));
v_SYMBOL_6 = LREF(s_lsp__2AWCL_2DVERSION_2A);
t0 = ((LP) DEREF((LREF(s_lsp__2AWCL_2DVERSION_2A)) + 0 * 4));
t1 = ICALL(s_lsp_OS_2DVERSION) (0);
t2 = ICALL(s_lsp_MACHINE_2DINSTANCE) (0);
ICALL(s_lsp_FORMAT) (5, LREF(s_lsp_T), LREF(k16230), t0, t1, t2);
v_SYMBOL_8 = LREF(s_lsp__2ACL_2DVERSION_2A);
t3 = ((LP) DEREF((LREF(s_lsp__2ACL_2DVERSION_2A)) + 0 * 4));
v_SYMBOL_10 = LREF(s_lsp__2ACL_2DBUILD_2DDATE_2A);
t4 = ((LP) DEREF((LREF(s_lsp__2ACL_2DBUILD_2DDATE_2A)) + 0 * 4));
ICALL(s_lsp_FORMAT) (4, LREF(s_lsp_T), LREF(k16231), t3, t4);
v_SYMBOL_12 = LREF(s_lsp__2ACOMPILER_2DVERSION_2A);
t5 = ((LP) DEREF((LREF(s_lsp__2ACOMPILER_2DVERSION_2A)) + 0 * 4));
v_SYMBOL_14 = LREF(s_lsp__2ACOMPILER_2DBUILD_2DDATE_2A);
t6 = ((LP) DEREF((LREF(s_lsp__2ACOMPILER_2DBUILD_2DDATE_2A)) + 0 * 4));
ICALL(s_lsp_FORMAT) (4, LREF(s_lsp_T), LREF(k16232), t5, t6);
ICALL(s_lsp_PRINT_2DCOPYRIGHT) (0);
ICALL(s_lsp_LOAD_2DINIT_2DFILE) (0);
t7 = ICALL(s_lsp_REPL) (MV_CALL(argc,0));
return(t7);
}

