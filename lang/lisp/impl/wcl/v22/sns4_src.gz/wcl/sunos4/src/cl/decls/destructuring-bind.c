/*
:comment "Compiled at 3:46:10 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: Debug Library"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O2 -fPIC"
:version 0
:end-package-info 0
:sym SECOND
:sym THIRD
:sym CDDDR
:sym LOCALLY
:sym CONS
:sym DBIND-1
:sm DESTRUCTURING-BIND "m_lsp_DESTRUCTURING_2DBIND"
:sym GENSYM
:sym DOT->&REST
:sym LET
:sym NIL
:sym LAMBDA-LIST-REQUIRED-ARGS
:sym CAR
:sym ATOM
:sym POP
:sym CDR
:sym LAMBDA-LIST-HAIRY-ARGS
:sym HAIRY-DBIND
:sf DBIND-1 "p_lsp_DBIND_2D1"
:sym FIRST
:sym &REST
:sym EQ
:sym SYMBOLP
:sym CDDR
:sym NULL
:sym APPLY
:sym FUNCTION
:sym LAMBDA
:sf HAIRY-DBIND "p_lsp_HAIRY_2DDBIND"
:sym POSITION-IF
:sym LENGTH
:sym SUBSEQ
:sym &OPTIONAL
:sym &RESTV
:sym &KEY
:sym &ALLOW-OTHER-KEYS
:sym &AUX
:sym &WHOLE
:sym &ENVIRONMENT
:sym &BODY
:sym MEMQL
:sf LAMBDA-LIST-REQUIRED-ARGS "p_lsp_LAMBDA_2DLIST_2DREQUIRED_2DARGS"
:sym MEMBER-IF
:sf LAMBDA-LIST-HAIRY-ARGS "p_lsp_LAMBDA_2DLIST_2DHAIRY_2DARGS"
:sym LAST
:sym COPY-LIST
:sym NCONC/2
:sf DOT->&REST "p_lsp_DOT_2D_3E_26REST"
:sym LIST*
:sym APPEND/2
:sm DESTRUCTURE "m_lsp_DESTRUCTURE"
:sym PROG1
:sym SETF
:sm POP "m_lsp_POP"
:sm PROG1 "m_lsp_PROG1"
:sm LOCALLY "m_lsp_LOCALLY"
:sym PARSE-BODY
:sym PROGN
:sym RPLACD
:sym DECLARE
:sm LET "m_lsp_LET"
:sym LET*
:sym REST
:sm LET* "m_lsp_LET_2A"
:sym DESTRUCTURING-BIND
:sym UNSAFE-SYMBOL-FUNCTION
:sym DEFINE-MACRO
:sym DESTRUCTURE
:sf DESTRUCTURING-BIND_INIT105 "p_lsp_DESTRUCTURING_2DBIND_5FINIT105"
:init DESTRUCTURING-BIND_INIT105
:pinfo DOT->&REST (LAMBDA-LIST) NIL NIL NIL NIL NIL NIL T
:pinfo DESTRUCTURING-BIND_INIT105 NIL NIL NIL NIL NIL NIL NIL T
:pinfo LAMBDA-LIST-REQUIRED-ARGS (LIST) NIL NIL NIL NIL NIL NIL T
:pinfo DBIND-1 (PATTERN FORM-EXPR BODY) NIL NIL NIL NIL NIL NIL T
:pinfo LAMBDA-LIST-HAIRY-ARGS (LIST) NIL NIL NIL NIL NIL NIL T
:pinfo HAIRY-DBIND (HAIRY FORM BODY) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP m_lsp_DESTRUCTURING_2DBIND();
extern SYMBOL s_lsp_SECOND; 
extern SYMBOL s_lsp_THIRD; 
extern SYMBOL s_lsp_CDDDR; 
extern SYMBOL s_lsp_LOCALLY; 
extern SYMBOL s_lsp_CONS; 
extern SYMBOL s_lsp_DBIND_2D1; 
extern LP p_lsp_DBIND_2D1();
MAKE_SIMPLE_STRING(k185,1,"L");
extern SYMBOL s_lsp_GENSYM; 
extern SYMBOL s_lsp_DOT_2D_3E_26REST; 
extern LP p_lsp_DBIND_2D1_2DPULL_2DAPART184();
extern SYMBOL s_lsp_LET; 
extern SYMBOL s_lsp_NIL; 
extern SYMBOL s_lsp_LAMBDA_2DLIST_2DREQUIRED_2DARGS; 
extern SYMBOL s_lsp_CAR; 
extern SYMBOL s_lsp_ATOM; 
extern SYMBOL s_lsp_POP; 
extern SYMBOL s_lsp_CDR; 
extern SYMBOL s_lsp_LAMBDA_2DLIST_2DHAIRY_2DARGS; 
extern SYMBOL s_lsp_HAIRY_2DDBIND; 
extern LP p_lsp_HAIRY_2DDBIND();
extern SYMBOL s_lsp_FIRST; 
extern SYMBOL s_lsp__26REST; 
extern SYMBOL s_lsp_EQ; 
extern SYMBOL s_lsp_SYMBOLP; 
extern SYMBOL s_lsp_CDDR; 
extern SYMBOL s_lsp_NULL; 
extern SYMBOL s_lsp_APPLY; 
extern SYMBOL s_lsp_FUNCTION; 
extern SYMBOL s_lsp_LAMBDA; 
extern LP p_lsp_LAMBDA_2DLIST_2DREQUIRED_2DARGS();
extern LP p_lsp_LAMBDA_2DLIST_2DREQUIRED_2DARGS_2Danon186187();
MAKE_PROCEDURE(k188,p_lsp_LAMBDA_2DLIST_2DREQUIRED_2DARGS_2Danon186187);
extern SYMBOL s_lsp_POSITION_2DIF; 
extern SYMBOL s_lsp_LENGTH; 
extern SYMBOL s_lsp_SUBSEQ; 
extern SYMBOL s_lsp__26OPTIONAL; 
extern SYMBOL s_lsp__26RESTV; 
extern SYMBOL s_lsp__26KEY; 
extern SYMBOL s_lsp__26ALLOW_2DOTHER_2DKEYS; 
extern SYMBOL s_lsp__26AUX; 
extern SYMBOL s_lsp__26WHOLE; 
extern SYMBOL s_lsp__26ENVIRONMENT; 
extern SYMBOL s_lsp__26BODY; 
MAKE_CONS(k197,LREF(s_lsp__26BODY),LREF(s_lsp_NIL));
MAKE_CONS(k196,LREF(s_lsp__26ENVIRONMENT),LREF(k197));
MAKE_CONS(k195,LREF(s_lsp__26WHOLE),LREF(k196));
MAKE_CONS(k194,LREF(s_lsp__26AUX),LREF(k195));
MAKE_CONS(k193,LREF(s_lsp__26ALLOW_2DOTHER_2DKEYS),LREF(k194));
MAKE_CONS(k192,LREF(s_lsp__26KEY),LREF(k193));
MAKE_CONS(k191,LREF(s_lsp__26RESTV),LREF(k192));
MAKE_CONS(k190,LREF(s_lsp__26REST),LREF(k191));
MAKE_CONS(k189,LREF(s_lsp__26OPTIONAL),LREF(k190));
extern SYMBOL s_lsp_MEMQL; 
extern LP p_lsp_LAMBDA_2DLIST_2DHAIRY_2DARGS();
extern LP p_lsp_LAMBDA_2DLIST_2DHAIRY_2DARGS_2Danon198199();
MAKE_PROCEDURE(k200,p_lsp_LAMBDA_2DLIST_2DHAIRY_2DARGS_2Danon198199);
extern SYMBOL s_lsp_MEMBER_2DIF; 
extern LP p_lsp_DOT_2D_3E_26REST();
extern SYMBOL s_lsp_LAST; 
extern SYMBOL s_lsp_COPY_2DLIST; 
extern SYMBOL s_lsp_NCONC_2F2; 
extern LP m_lsp_DESTRUCTURE();
extern LP p_lsp_DESTRUCTURE_2DWALK_2DVARS201();
MAKE_SIMPLE_STRING(k202,5,"FORM-");
extern SYMBOL s_lsp_LIST_2A; 
extern SYMBOL s_lsp_APPEND_2F2; 
extern LP m_lsp_POP();
MAKE_SIMPLE_STRING(k203,4,"LIST");
extern SYMBOL s_lsp_PROG1; 
extern SYMBOL s_lsp_SETF; 
extern LP m_lsp_PROG1();
MAKE_SIMPLE_STRING(k204,5,"VALUE");
extern LP m_lsp_LOCALLY();
extern LP m_lsp_LET();
extern SYMBOL s_lsp_PARSE_2DBODY; 
extern SYMBOL s_lsp_PROGN; 
extern SYMBOL s_lsp_RPLACD; 
extern SYMBOL s_lsp_DECLARE; 
extern LP m_lsp_LET_2A();
extern SYMBOL s_lsp_LET_2A; 
extern SYMBOL s_lsp_REST; 
extern LP p_lsp_DESTRUCTURING_2DBIND_5FINIT105();
extern SYMBOL s_lsp_DESTRUCTURING_2DBIND; 
extern SYMBOL s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION; 
extern SYMBOL s_lsp_DEFINE_2DMACRO; 
extern SYMBOL s_lsp_DESTRUCTURE; 




LP m_lsp_DESTRUCTURING_2DBIND(argc, v_WHOLE_0, v_ENV_1)
      ARGC argc;  LP v_WHOLE_0; LP v_ENV_1;
{
LP v_BODY_2BDECLS_4; LP v_FORM_3; LP v_LAMBDA_2DLIST_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 2) wna(argc,2);
v_LAMBDA_2DLIST_2 = ICALL(s_lsp_SECOND) (1, v_WHOLE_0);
v_FORM_3 = ICALL(s_lsp_THIRD) (1, v_WHOLE_0);
v_BODY_2BDECLS_4 = ICALL(s_lsp_CDDDR) (1, v_WHOLE_0);
t1 = ICALL(s_lsp_CONS) (2, LREF(s_lsp_LOCALLY), v_BODY_2BDECLS_4);
t0 = ICALL(s_lsp_DBIND_2D1) (MV_CALL(argc,3), v_LAMBDA_2DLIST_2, v_FORM_3, t1);
return(t0);
}

LP p_lsp_DBIND_2D1(argc, v_PATTERN_0, v_FORM_2DEXPR_1, v_BODY_2)
      ARGC argc;  LP v_PATTERN_0; LP v_FORM_2DEXPR_1; LP v_BODY_2;
{
LP f_PULL_2DAPART_6; LP v_LAMBDA_2DLIST_5; LP v_FORM_4; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 3) wna(argc,3);
t0 = NEW_OE(4);
SET_OE_SLOT(t0,2,v_BODY_2);
v_FORM_4 = ICALL(s_lsp_GENSYM) (1, LREF(k185));
v_LAMBDA_2DLIST_5 = ICALL(s_lsp_DOT_2D_3E_26REST) (1, v_PATTERN_0);
SET_OE_SLOT(t0,1,v_FORM_4);
SET_OE_SLOT(t0,3,v_LAMBDA_2DLIST_5);
t1 = MAKE_CLOSURE(p_lsp_DBIND_2D1_2DPULL_2DAPART184,t0);
f_PULL_2DAPART_6 = t1;
SET_OE_SLOT(t0,0,f_PULL_2DAPART_6);
t6 = ICALL(s_lsp_CONS) (2, v_FORM_2DEXPR_1, LREF(s_lsp_NIL));
t5 = ICALL(s_lsp_CONS) (2, GET_OE_SLOT(t0,1), t6);
t4 = ICALL(s_lsp_CONS) (2, t5, LREF(s_lsp_NIL));
t9 = ICALL(s_lsp_LAMBDA_2DLIST_2DREQUIRED_2DARGS) (1, GET_OE_SLOT(t0,3));
t8 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(1, t9);
t7 = ICALL(s_lsp_CONS) (2, t8, LREF(s_lsp_NIL));
t3 = ICALL(s_lsp_CONS) (2, t4, t7);
t2 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), LREF(s_lsp_LET), t3);
return(t2);
}

LP p_lsp_DBIND_2D1_2DPULL_2DAPART184(argc, v_REQUIRED_0)
      ARGC argc;  LP v_REQUIRED_0;
{
LP v_REQ_3; LP v_HAIRY_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; 
if (argc != 1) wna(argc,1);
t0 = OE;
if (v_REQUIRED_0 != NIL) {
v_REQ_3 = ICALL(s_lsp_CAR) (1, v_REQUIRED_0);
t2 = ICALL(s_lsp_ATOM) (1, v_REQ_3);
if (t2 != NIL) {
t8 = ICALL(s_lsp_CONS) (2, GET_OE_SLOT(t0,1), LREF(s_lsp_NIL));
t7 = ICALL(s_lsp_CONS) (2, LREF(s_lsp_POP), t8);
t6 = ICALL(s_lsp_CONS) (2, t7, LREF(s_lsp_NIL));
t5 = ICALL(s_lsp_CONS) (2, v_REQ_3, t6);
t4 = ICALL(s_lsp_CONS) (2, t5, LREF(s_lsp_NIL));
t11 = ICALL(s_lsp_CDR) (1, v_REQUIRED_0);
t10 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(1, t11);
t9 = ICALL(s_lsp_CONS) (2, t10, LREF(s_lsp_NIL));
t3 = ICALL(s_lsp_CONS) (2, t4, t9);
t1 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), LREF(s_lsp_LET), t3);
return(t1);
} else {
t13 = ICALL(s_lsp_CONS) (2, GET_OE_SLOT(t0,1), LREF(s_lsp_NIL));
t12 = ICALL(s_lsp_CONS) (2, LREF(s_lsp_POP), t13);
t15 = ICALL(s_lsp_CDR) (1, v_REQUIRED_0);
t14 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(1, t15);
t1 = ICALL(s_lsp_DBIND_2D1) (MV_CALL(argc,3), v_REQ_3, t12, t14);
return(t1);
}
} else {
v_HAIRY_2 = ICALL(s_lsp_LAMBDA_2DLIST_2DHAIRY_2DARGS) (1, GET_OE_SLOT(t0,3));
if (v_HAIRY_2 != NIL) {
t1 = ICALL(s_lsp_HAIRY_2DDBIND) (MV_CALL(argc,3), v_HAIRY_2, GET_OE_SLOT(t0,1), GET_OE_SLOT(t0,2));
return(t1);
} else {
return(GET_OE_SLOT(t0,2));
}
}
}

LP p_lsp_HAIRY_2DDBIND(argc, v_HAIRY_0, v_FORM_1, v_BODY_2)
      ARGC argc;  LP v_HAIRY_0; LP v_FORM_1; LP v_BODY_2;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; 
if (argc != 3) wna(argc,3);
t3 = ICALL(s_lsp_FIRST) (1, v_HAIRY_0);
t2 = ICALL(s_lsp_EQ) (2, t3, LREF(s_lsp__26REST));
if (t2 != NIL) {
t5 = ICALL(s_lsp_SECOND) (1, v_HAIRY_0);
t4 = ICALL(s_lsp_SYMBOLP) (1, t5);
if (t4 != NIL) {
t6 = ICALL(s_lsp_CDDR) (1, v_HAIRY_0);
t1 = ICALL(s_lsp_NULL) (1, t6);
} else {
t1 = LREF(s_lsp_NIL);
}
} else {
t1 = LREF(s_lsp_NIL);
}
if (t1 != NIL) {
t10 = ICALL(s_lsp_SECOND) (1, v_HAIRY_0);
t11 = ICALL(s_lsp_CONS) (2, v_FORM_1, LREF(s_lsp_NIL));
t9 = ICALL(s_lsp_CONS) (2, t10, t11);
t8 = ICALL(s_lsp_CONS) (2, t9, LREF(s_lsp_NIL));
t12 = ICALL(s_lsp_CONS) (2, v_BODY_2, LREF(s_lsp_NIL));
t7 = ICALL(s_lsp_CONS) (2, t8, t12);
t0 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), LREF(s_lsp_LET), t7);
return(t0);
} else {
t18 = ICALL(s_lsp_CONS) (2, v_BODY_2, LREF(s_lsp_NIL));
t17 = ICALL(s_lsp_CONS) (2, v_HAIRY_0, t18);
t16 = ICALL(s_lsp_CONS) (2, LREF(s_lsp_LAMBDA), t17);
t15 = ICALL(s_lsp_CONS) (2, t16, LREF(s_lsp_NIL));
t14 = ICALL(s_lsp_CONS) (2, LREF(s_lsp_FUNCTION), t15);
t19 = ICALL(s_lsp_CONS) (2, v_FORM_1, LREF(s_lsp_NIL));
t13 = ICALL(s_lsp_CONS) (2, t14, t19);
t0 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), LREF(s_lsp_APPLY), t13);
return(t0);
}
}

LP p_lsp_LAMBDA_2DLIST_2DREQUIRED_2DARGS(argc, v_LIST_0)
      ARGC argc;  LP v_LIST_0;
{
LP v_G244_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 1) wna(argc,1);
v_G244_2 = ICALL(s_lsp_POSITION_2DIF) (2, LREF(k188), v_LIST_0);
if (v_G244_2 != NIL) {
t1 = v_G244_2;
} else {
t1 = ICALL(s_lsp_LENGTH) (1, v_LIST_0);
}
t0 = ICALL(s_lsp_SUBSEQ) (MV_CALL(argc,3), v_LIST_0, (LP) 0, t1);
return(t0);
}

LP p_lsp_LAMBDA_2DLIST_2DREQUIRED_2DARGS_2Danon186187(argc, v_E_0)
      ARGC argc;  LP v_E_0;
{

LP t0; LP t1; LP t2; LP t3; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_MEMQL) (MV_CALL(argc,2), v_E_0, LREF(k189));
return(t0);
}

LP p_lsp_LAMBDA_2DLIST_2DHAIRY_2DARGS(argc, v_LIST_0)
      ARGC argc;  LP v_LIST_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_MEMBER_2DIF) (MV_CALL(argc,2), LREF(k200), v_LIST_0);
return(t0);
}

LP p_lsp_LAMBDA_2DLIST_2DHAIRY_2DARGS_2Danon198199(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_MEMQL) (MV_CALL(argc,2), v_X_0, LREF(k189));
return(t0);
}

LP p_lsp_DOT_2D_3E_26REST(argc, v_LAMBDA_2DLIST_0)
      ARGC argc;  LP v_LAMBDA_2DLIST_0;
{
LP v_END_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 1) wna(argc,1);
v_END_2 = ICALL(s_lsp_LAST) (1, v_LAMBDA_2DLIST_0);
t1 = ICALL(s_lsp_CDR) (1, v_END_2);
if (t1 != NIL) {
t2 = ICALL(s_lsp_COPY_2DLIST) (1, v_LAMBDA_2DLIST_0);
t5 = ICALL(s_lsp_CDR) (1, v_END_2);
t4 = ICALL(s_lsp_CONS) (2, t5, LREF(s_lsp_NIL));
t3 = ICALL(s_lsp_CONS) (2, LREF(s_lsp__26REST), t4);
t0 = ICALL(s_lsp_NCONC_2F2) (MV_CALL(argc,2), t2, t3);
return(t0);
} else {
return(v_LAMBDA_2DLIST_0);
}
}

LP m_lsp_DESTRUCTURE(argc, v_WHOLE245_0, v_ENV246_1)
      ARGC argc;  LP v_WHOLE245_0; LP v_ENV246_1;
{
LP v_F_18; LP f_WALK_2DVARS_17; LP v_BODY_16; 
LP v_FORM_15; LP v_S268_14; LP v_VALUE267_13; 
LP v_LIST266_12; LP v_VARS_11; LP v_S265_10; 
LP v_VALUE264_9; LP v_LIST263_8; LP v_L259_7; 
LP v_S262_6; LP v_VALUE261_5; LP v_LIST260_4; 
LP v_L258_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; 
if (argc != 2) wna(argc,2);
t0 = NEW_OE(1);
v_L258_3 = ICALL(s_lsp_CDR) (1, v_WHOLE245_0);
v_LIST260_4 = v_L258_3;
v_VALUE261_5 = ICALL(s_lsp_CAR) (1, v_LIST260_4);
v_S262_6 = ICALL(s_lsp_CDR) (1, v_LIST260_4);
v_L258_3 = v_S262_6;
v_L259_7 = v_VALUE261_5;
v_LIST263_8 = v_L259_7;
v_VALUE264_9 = ICALL(s_lsp_CAR) (1, v_LIST263_8);
v_S265_10 = ICALL(s_lsp_CDR) (1, v_LIST263_8);
v_L259_7 = v_S265_10;
v_VARS_11 = v_VALUE264_9;
v_LIST266_12 = v_L259_7;
v_VALUE267_13 = ICALL(s_lsp_CAR) (1, v_LIST266_12);
v_S268_14 = ICALL(s_lsp_CDR) (1, v_LIST266_12);
v_L259_7 = v_S268_14;
v_FORM_15 = v_VALUE267_13;
v_BODY_16 = v_L258_3;
t1 = MAKE_CLOSURE(p_lsp_DESTRUCTURE_2DWALK_2DVARS201,t0);
f_WALK_2DVARS_17 = t1;
SET_OE_SLOT(t0,0,f_WALK_2DVARS_17);
v_F_18 = ICALL(s_lsp_GENSYM) (1, LREF(k202));
t6 = ICALL(s_lsp_CONS) (2, v_FORM_15, LREF(s_lsp_NIL));
t5 = ICALL(s_lsp_CONS) (2, v_F_18, t6);
t4 = ICALL(s_lsp_CONS) (2, t5, LREF(s_lsp_NIL));
t9 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(2, v_VARS_11, v_F_18);
t8 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_LET), t9, v_BODY_16);
t7 = ICALL(s_lsp_CONS) (2, t8, LREF(s_lsp_NIL));
t3 = ICALL(s_lsp_CONS) (2, t4, t7);
t2 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), LREF(s_lsp_LET), t3);
return(t2);
}

LP p_lsp_DESTRUCTURE_2DWALK_2DVARS201(argc, v_EXPR_0, v_PATH_1)
      ARGC argc;  LP v_EXPR_0; LP v_PATH_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; 
if (argc != 2) wna(argc,2);
t0 = OE;
t2 = ICALL(s_lsp_ATOM) (1, v_EXPR_0);
if (t2 != NIL) {
if (v_EXPR_0 != NIL) {
t4 = ICALL(s_lsp_CONS) (2, v_PATH_1, LREF(s_lsp_NIL));
t3 = ICALL(s_lsp_CONS) (2, v_EXPR_0, t4);
t1 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t3, LREF(s_lsp_NIL));
return(t1);
} else {
return(v_EXPR_0);
}
} else {
t6 = ICALL(s_lsp_CAR) (1, v_EXPR_0);
t8 = ICALL(s_lsp_CONS) (2, v_PATH_1, LREF(s_lsp_NIL));
t7 = ICALL(s_lsp_CONS) (2, LREF(s_lsp_CAR), t8);
t5 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(2, t6, t7);
t10 = ICALL(s_lsp_CDR) (1, v_EXPR_0);
t12 = ICALL(s_lsp_CONS) (2, v_PATH_1, LREF(s_lsp_NIL));
t11 = ICALL(s_lsp_CONS) (2, LREF(s_lsp_CDR), t12);
t9 = CODE_PTR(COERCE_TO_FUNCTION(GET_OE_SLOT(t0,0)))(2, t10, t11);
t1 = ICALL(s_lsp_APPEND_2F2) (MV_CALL(argc,2), t5, t9);
return(t1);
}
}

LP m_lsp_POP(argc, v_WHOLE_0, v_ENV_1)
      ARGC argc;  LP v_WHOLE_0; LP v_ENV_1;
{
LP v_LIST_3; LP v_VAR_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; 
if (argc != 2) wna(argc,2);
v_VAR_2 = ICALL(s_lsp_SECOND) (1, v_WHOLE_0);
v_LIST_3 = ICALL(s_lsp_GENSYM) (1, LREF(k203));
t4 = ICALL(s_lsp_CONS) (2, v_VAR_2, LREF(s_lsp_NIL));
t3 = ICALL(s_lsp_CONS) (2, v_LIST_3, t4);
t2 = ICALL(s_lsp_CONS) (2, t3, LREF(s_lsp_NIL));
t9 = ICALL(s_lsp_CONS) (2, v_LIST_3, LREF(s_lsp_NIL));
t8 = ICALL(s_lsp_CONS) (2, LREF(s_lsp_CAR), t9);
t15 = ICALL(s_lsp_CONS) (2, v_LIST_3, LREF(s_lsp_NIL));
t14 = ICALL(s_lsp_CONS) (2, LREF(s_lsp_CDR), t15);
t13 = ICALL(s_lsp_CONS) (2, t14, LREF(s_lsp_NIL));
t12 = ICALL(s_lsp_CONS) (2, v_VAR_2, t13);
t11 = ICALL(s_lsp_CONS) (2, LREF(s_lsp_SETF), t12);
t10 = ICALL(s_lsp_CONS) (2, t11, LREF(s_lsp_NIL));
t7 = ICALL(s_lsp_CONS) (2, t8, t10);
t6 = ICALL(s_lsp_CONS) (2, LREF(s_lsp_PROG1), t7);
t5 = ICALL(s_lsp_CONS) (2, t6, LREF(s_lsp_NIL));
t1 = ICALL(s_lsp_CONS) (2, t2, t5);
t0 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), LREF(s_lsp_LET), t1);
return(t0);
}

LP m_lsp_PROG1(argc, v_WHOLE_0, v_ENV_1)
      ARGC argc;  LP v_WHOLE_0; LP v_ENV_1;
{
LP v_VALUE_4; LP v_BODY_3; LP v_FIRST_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; 
if (argc != 2) wna(argc,2);
v_FIRST_2 = ICALL(s_lsp_SECOND) (1, v_WHOLE_0);
v_BODY_3 = ICALL(s_lsp_CDDR) (1, v_WHOLE_0);
v_VALUE_4 = ICALL(s_lsp_GENSYM) (1, LREF(k204));
t3 = ICALL(s_lsp_CONS) (2, v_FIRST_2, LREF(s_lsp_NIL));
t2 = ICALL(s_lsp_CONS) (2, v_VALUE_4, t3);
t1 = ICALL(s_lsp_CONS) (2, t2, LREF(s_lsp_NIL));
t5 = ICALL(s_lsp_CONS) (2, v_VALUE_4, LREF(s_lsp_NIL));
t4 = ICALL(s_lsp_APPEND_2F2) (2, v_BODY_3, t5);
t0 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,3), LREF(s_lsp_LET), t1, t4);
return(t0);
}

LP m_lsp_LOCALLY(argc, v_WHOLE_0, v_ENV_1)
      ARGC argc;  LP v_WHOLE_0; LP v_ENV_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 2) wna(argc,2);
t2 = ICALL(s_lsp_CDR) (1, v_WHOLE_0);
t1 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_LAMBDA), LREF(s_lsp_NIL), t2);
t0 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t1, LREF(s_lsp_NIL));
return(t0);
}

LP m_lsp_LET(argc, v_WHOLE_0, v_ENV_1)
      ARGC argc;  LP v_WHOLE_0; LP v_ENV_1;
{
LP v_SPEC_23; LP v_LOOPVAR_2D104_19; LP v_LOOPVAR_2D103_18; 
LP v_LOOPVAR_2D102_17; LP v_LOOP_2DLIST_2D101_16; LP v_L270_15; 
LP v_SPEC_14; LP v_LOOPVAR_2D100_10; LP v_LOOPVAR_2D99_9; 
LP v_LOOPVAR_2D98_8; LP v_LOOP_2DLIST_2D97_7; LP v_L269_6; 
LP v_DECLS_5; LP v_BODY_4; LP v_BODY_2BDECLS_3; 
LP v_BINDINGS_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; 
if (argc != 2) wna(argc,2);
v_BINDINGS_2 = ICALL(s_lsp_SECOND) (1, v_WHOLE_0);
v_BODY_2BDECLS_3 = ICALL(s_lsp_CDDR) (1, v_WHOLE_0);
{
int real_argc;
BEGIN_MV_CALL(mv_holder205,0);
t0 = ICALL(s_lsp_PARSE_2DBODY) (MV_CALL(mv_holder205,1), v_BODY_2BDECLS_3);
SET_MV_RETURN_VALUE(mv_holder205,0,t0);
if SV_RETURN_P(mv_holder205) SET_MV_RETURN_COUNT(mv_holder205,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder205);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_BODY_4 = NIL;
} else {
v_BODY_4 = NEXT_VAR_VALUE(mv_holder205);
}
if (real_argc < 2) {
v_DECLS_5 = NIL;
} else {
v_DECLS_5 = NEXT_VAR_VALUE(mv_holder205);
}
END_VAR_VALUES;
END_MV_CALL;
if (v_BINDINGS_2 != NIL) {
t2 = LREF(s_lsp_NIL);
} else {
t2 = ICALL(s_lsp_NULL) (1, v_DECLS_5);
}
if (t2 != NIL) {
t1 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), LREF(s_lsp_PROGN), v_BODY_4);
return(t1);
} else {
v_L269_6 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D97_7 = v_BINDINGS_2;
v_LOOPVAR_2D98_8 = LREF(s_lsp_NIL);
v_LOOPVAR_2D99_9 = LREF(s_lsp_NIL);
v_LOOPVAR_2D100_10 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_12:;
if (v_LOOP_2DLIST_2D97_7 == NIL) {
goto t_END_2DLOOP_13;
}
v_L269_6 = ICALL(s_lsp_CAR) (1, v_LOOP_2DLIST_2D97_7);
v_LOOP_2DLIST_2D97_7 = ICALL(s_lsp_CDR) (1, v_LOOP_2DLIST_2D97_7);
v_SPEC_14 = v_L269_6;
t6 = ICALL(s_lsp_ATOM) (1, v_SPEC_14);
if (t6 != NIL) {
t5 = v_SPEC_14;
} else {
t5 = ICALL(s_lsp_FIRST) (1, v_SPEC_14);
}
v_LOOPVAR_2D100_10 = ICALL(s_lsp_CONS) (2, t5, LREF(s_lsp_NIL));
if (v_LOOPVAR_2D99_9 != NIL) {
t7 = ICALL(s_lsp_RPLACD) (2, v_LOOPVAR_2D99_9, v_LOOPVAR_2D100_10);
v_LOOPVAR_2D99_9 = ICALL(s_lsp_CDR) (1, t7);
} else {
v_LOOPVAR_2D98_8 = v_LOOPVAR_2D100_10;
v_LOOPVAR_2D99_9 = v_LOOPVAR_2D98_8;
}
goto t_NEXT_2DLOOP_12;
goto t_END_2DLOOP_13;
t_END_2DLOOP_13:;
t4 = v_LOOPVAR_2D98_8;
goto b_NIL_11;
t4 = NIL;
b_NIL_11:;
t8 = ICALL(s_lsp_CONS) (2, LREF(s_lsp_DECLARE), v_DECLS_5);
t3 = ICALL(s_lsp_LIST_2A) (4, LREF(s_lsp_LAMBDA), t4, t8, v_BODY_4);
v_L270_15 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D101_16 = v_BINDINGS_2;
v_LOOPVAR_2D102_17 = LREF(s_lsp_NIL);
v_LOOPVAR_2D103_18 = LREF(s_lsp_NIL);
v_LOOPVAR_2D104_19 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_21:;
if (v_LOOP_2DLIST_2D101_16 == NIL) {
goto t_END_2DLOOP_22;
}
v_L270_15 = ICALL(s_lsp_CAR) (1, v_LOOP_2DLIST_2D101_16);
v_LOOP_2DLIST_2D101_16 = ICALL(s_lsp_CDR) (1, v_LOOP_2DLIST_2D101_16);
v_SPEC_23 = v_L270_15;
t11 = ICALL(s_lsp_ATOM) (1, v_SPEC_23);
if (t11 != NIL) {
t10 = LREF(s_lsp_NIL);
} else {
t10 = ICALL(s_lsp_SECOND) (1, v_SPEC_23);
}
v_LOOPVAR_2D104_19 = ICALL(s_lsp_CONS) (2, t10, LREF(s_lsp_NIL));
if (v_LOOPVAR_2D103_18 != NIL) {
t12 = ICALL(s_lsp_RPLACD) (2, v_LOOPVAR_2D103_18, v_LOOPVAR_2D104_19);
v_LOOPVAR_2D103_18 = ICALL(s_lsp_CDR) (1, t12);
} else {
v_LOOPVAR_2D102_17 = v_LOOPVAR_2D104_19;
v_LOOPVAR_2D103_18 = v_LOOPVAR_2D102_17;
}
goto t_NEXT_2DLOOP_21;
goto t_END_2DLOOP_22;
t_END_2DLOOP_22:;
t9 = v_LOOPVAR_2D102_17;
goto b_NIL_20;
t9 = NIL;
b_NIL_20:;
t1 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t3, t9);
return(t1);
}
}
}

LP m_lsp_LET_2A(argc, v_WHOLE_0, v_ENV_1)
      ARGC argc;  LP v_WHOLE_0; LP v_ENV_1;
{
LP v_FIRST_2DBINDING_6; LP v_DECLS_5; LP v_BODY_4; 
LP v_BODY_2BDECLS_3; LP v_BINDINGS_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 

if (argc != 2) wna(argc,2);
v_BINDINGS_2 = ICALL(s_lsp_SECOND) (1, v_WHOLE_0);
v_BODY_2BDECLS_3 = ICALL(s_lsp_CDDR) (1, v_WHOLE_0);
{
int real_argc;
BEGIN_MV_CALL(mv_holder206,0);
t0 = ICALL(s_lsp_PARSE_2DBODY) (MV_CALL(mv_holder206,1), v_BODY_2BDECLS_3);
SET_MV_RETURN_VALUE(mv_holder206,0,t0);
if SV_RETURN_P(mv_holder206) SET_MV_RETURN_COUNT(mv_holder206,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder206);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_BODY_4 = NIL;
} else {
v_BODY_4 = NEXT_VAR_VALUE(mv_holder206);
}
if (real_argc < 2) {
v_DECLS_5 = NIL;
} else {
v_DECLS_5 = NEXT_VAR_VALUE(mv_holder206);
}
END_VAR_VALUES;
END_MV_CALL;
if (v_BINDINGS_2 != NIL) {
t3 = ICALL(s_lsp_FIRST) (1, v_BINDINGS_2);
t2 = ICALL(s_lsp_ATOM) (1, t3);
if (t2 != NIL) {
t4 = ICALL(s_lsp_FIRST) (1, v_BINDINGS_2);
t5 = ICALL(s_lsp_CONS) (2, LREF(s_lsp_NIL), LREF(s_lsp_NIL));
v_FIRST_2DBINDING_6 = ICALL(s_lsp_CONS) (2, t4, t5);
} else {
v_FIRST_2DBINDING_6 = ICALL(s_lsp_FIRST) (1, v_BINDINGS_2);
}
if (v_BINDINGS_2 != NIL) {
t9 = ICALL(s_lsp_FIRST) (1, v_FIRST_2DBINDING_6);
t8 = ICALL(s_lsp_CONS) (2, t9, LREF(s_lsp_NIL));
} else {
t8 = LREF(s_lsp_NIL);
}
t12 = ICALL(s_lsp_REST) (1, v_BINDINGS_2);
t13 = ICALL(s_lsp_CONS) (2, LREF(s_lsp_DECLARE), v_DECLS_5);
t11 = ICALL(s_lsp_LIST_2A) (4, LREF(s_lsp_LET_2A), t12, t13, v_BODY_4);
t10 = ICALL(s_lsp_CONS) (2, t11, LREF(s_lsp_NIL));
t7 = ICALL(s_lsp_CONS) (2, t8, t10);
t6 = ICALL(s_lsp_CONS) (2, LREF(s_lsp_LAMBDA), t7);
t15 = ICALL(s_lsp_SECOND) (1, v_FIRST_2DBINDING_6);
t14 = ICALL(s_lsp_CONS) (2, t15, LREF(s_lsp_NIL));
t1 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), t6, t14);
return(t1);
} else {
if (v_DECLS_5 != NIL) {
t1 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), LREF(s_lsp_LOCALLY), v_BODY_2BDECLS_3);
return(t1);
} else {
t1 = ICALL(s_lsp_CONS) (MV_CALL(argc,2), LREF(s_lsp_PROGN), v_BODY_4);
return(t1);
}
}
}
}

LP p_lsp_DESTRUCTURING_2DBIND_5FINIT105(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; 
if (argc != 0) wna(argc,0);
t0 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_DESTRUCTURING_2DBIND));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_lsp_DESTRUCTURING_2DBIND), t0);
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_DESTRUCTURE));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_lsp_DESTRUCTURE), t1);
t2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_POP));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_lsp_POP), t2);
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_PROG1));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_lsp_PROG1), t3);
t4 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_LOCALLY));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_lsp_LOCALLY), t4);
t5 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_LET));
ICALL(s_lsp_DEFINE_2DMACRO) (2, LREF(s_lsp_LET), t5);
t7 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_LET_2A));
t6 = ICALL(s_lsp_DEFINE_2DMACRO) (MV_CALL(argc,2), LREF(s_lsp_LET_2A), t7);
return(t6);
}

