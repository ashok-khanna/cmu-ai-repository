/*
:comment "Compiled at 4:07:55 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: Debug Library"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O2 -fPIC"
:version 0
:end-package-info 0
:sym HASH-TABLE-P
:sym HASH-TABLE
:sym WTA
:sym *EMPTY-BUCKET-MARKER*
:sym UNSAFE-SYMBOL-VALUE
:sym NIL
:sf CLRHASH "p_lsp_CLRHASH"
:sym HASH-KEY->INDEX/3
:sym EQ
:sym T
:sf GETHASH-WITH-KEY "p_lsp_GETHASH_2DWITH_2DKEY"
:sym SXHASH
:sym GETHASH/3
:sf GETHASH "p_lsp_GETHASH"
:sf GETHASH/3 "p_lsp_GETHASH_2F3"
:sf HASH-KEY->INDEX "p_lsp_HASH_2DKEY_2D_3EINDEX"
:sym HASH/3
:sym ERROR
:sf HASH-KEY->INDEX/3 "p_lsp_HASH_2DKEY_2D_3EINDEX_2F3"
:sf SXHASH/SIMPLE-STRING "p_lsp_SXHASH_2FSIMPLE_2DSTRING"
:proclaim (QUOTE (INLINE HASH/3))
:sf HASH/3 "p_lsp_HASH_2F3"
:sf HASH "p_lsp_HASH"
:sym FLOATP
:sym PRIME-CEILING
:sym MAKE-SIMPLE-ARRAY
:sym FLOOR/1V
:sym FRESH-HASH-TABLE/8
:sf MAKE-HASH-TABLE-1 "p_lsp_MAKE_2DHASH_2DTABLE_2D1"
:sf PRIME-CEILING "p_lsp_PRIME_2DCEILING"
:proclaim (QUOTE (INLINE MAKE-HASH-TABLE))
:sym :TEST
:sym EQL
:sym UNSAFE-SYMBOL-FUNCTION
:sym :SIZE
:sym :REHASH-SIZE
:sym :REHASH-THRESHOLD
:sym MAKE-HASH-TABLE-1
:sf MAKE-HASH-TABLE "p_lsp_MAKE_2DHASH_2DTABLE"
:sym FUNCTIONP
:sym FUNCTION
:sf MAPHASH "p_lsp_MAPHASH"
:sym FIXNUMP
:sym CEILING
:sym FLOAT
:sym FIXNUM
:sym SET-GETHASH
:sf REHASH "p_lsp_REHASH"
:sym HASH-KEY->INDEX
:sf REMHASH "p_lsp_REMHASH"
:sym REHASH
:sf SET-GETHASH "p_lsp_SET_2DGETHASH"
:proclaim (QUOTE (INLINE SXHASH-W))
:sf SXHASH-W "p_lsp_SXHASH_2DW"
:proclaim (QUOTE (INLINE SXHASH/SYMBOL))
:sym SYMBOL-HASH-CODE
:sf SXHASH/SYMBOL "p_lsp_SXHASH_2FSYMBOL"
:proclaim (QUOTE (INLINE SXHASH/CHARACTER))
:sf SXHASH/CHARACTER "p_lsp_SXHASH_2FCHARACTER"
:sym SYMBOLP
:sym SIMPLE-STRING-P
:sym SXHASH/SIMPLE-STRING
:sym CHARACTERP
:sf SXHASH "p_lsp_SXHASH"
:pinfo MAPHASH (FUNCTION TABLE) NIL (FUNCTION HASH-TABLE) NIL NIL NIL NIL T
:pinfo MAKE-HASH-TABLE-1 (TEST SIZE REHASH-SIZE REHASH-THRESHOLD) NIL NIL NIL NIL NIL NIL T
:pinfo GETHASH (KEY TABLE) NIL (T HASH-TABLE) NIL NIL NIL NIL T
:pinfo SXHASH/SIMPLE-STRING (S) NIL NIL NIL NIL NIL NIL T
:pinfo REMHASH (KEY TABLE) NIL (T HASH-TABLE) NIL NIL NIL NIL T
:pinfo SET-GETHASH (KEY TABLE VALUE) NIL (T HASH-TABLE T) NIL NIL NIL NIL T
:pinfo SXHASH-W (X) NIL NIL NIL (LAMBDA (X) (DECLARE) (BLOCK SXHASH-W (SXHASH X))) NIL T T
:pinfo GETHASH-WITH-KEY (KEY TABLE HASH-CODE) NIL (T HASH-TABLE T) NIL NIL NIL NIL T
:pinfo PRIME-CEILING (X) NIL NIL NIL NIL NIL NIL T
:pinfo CLRHASH (TABLE) NIL (HASH-TABLE) NIL NIL NIL NIL T
:pinfo MAKE-HASH-TABLE (&KEY (TEST (FUNCTION EQL)) (SIZE 65) (REHASH-SIZE 2.0) (REHASH-THRESHOLD 0.6)) NIL NIL NIL (LAMBDA (&KEY (TEST (FUNCTION EQL)) (SIZE 65) (REHASH-SIZE 2.0) (REHASH-THRESHOLD 0.6)) (DECLARE) (BLOCK MAKE-HASH-TABLE (MAKE-HASH-TABLE-1 TEST SIZE REHASH-SIZE REHASH-THRESHOLD))) NIL T T
:pinfo SXHASH (X) NIL NIL NIL NIL NIL NIL T
:pinfo REHASH (TABLE) NIL NIL NIL NIL NIL NIL T
:pinfo SXHASH/CHARACTER (X) NIL NIL NIL (LAMBDA (X) (DECLARE) (BLOCK SXHASH/CHARACTER (CHAR-CODE X))) NIL T T
:pinfo SXHASH/SYMBOL (X) NIL NIL NIL (LAMBDA (X) (DECLARE) (BLOCK SXHASH/SYMBOL (SYMBOL-HASH-CODE X))) NIL T T
:pinfo HASH-KEY->INDEX (KEY TABLE) NIL NIL NIL NIL NIL NIL T
:pinfo HASH (KEY TABLE) NIL NIL NIL NIL NIL NIL T
:pinfo HASH-KEY->INDEX/3 (KEY TABLE HASH-CODE) NIL NIL NIL NIL NIL NIL T
:pinfo GETHASH/3 (KEY TABLE HASH-CODE) NIL NIL NIL NIL NIL NIL T
:pinfo HASH/3 (KEY TABLE HASH-CODE) NIL NIL NIL (LAMBDA (KEY TABLE HASH-CODE) (DECLARE) (BLOCK HASH/3 (%ASHL (%REM HASH-CODE (HASH-TABLE-SIZE TABLE)) 1))) NIL T T
:end
*/

#include "lisp.h"

extern LP p_lsp_CLRHASH();
extern SYMBOL s_lsp_HASH_2DTABLE_2DP; 
extern SYMBOL s_lsp_HASH_2DTABLE; 
extern SYMBOL s_lsp_WTA; 
extern SYMBOL s_lsp__2AEMPTY_2DBUCKET_2DMARKER_2A; 
extern SYMBOL s_lsp_UNSAFE_2DSYMBOL_2DVALUE; 
extern SYMBOL s_lsp_NIL; 
extern LP p_lsp_GETHASH_2DWITH_2DKEY();
extern SYMBOL s_lsp_HASH_2DKEY_2D_3EINDEX_2F3; 
extern SYMBOL s_lsp_EQ; 
extern SYMBOL s_lsp_T; 
extern LP p_lsp_GETHASH();
extern SYMBOL s_lsp_SXHASH; 
extern SYMBOL s_lsp_GETHASH_2F3; 
extern LP p_lsp_GETHASH_2F3();
extern LP p_lsp_HASH_2DKEY_2D_3EINDEX();
extern LP p_lsp_HASH_2DKEY_2D_3EINDEX_2F3();
extern SYMBOL s_lsp_HASH_2F3; 
MAKE_SIMPLE_STRING(k2014,24,"Internal hashtable error");
extern SYMBOL s_lsp_ERROR; 
extern LP p_lsp_SXHASH_2FSIMPLE_2DSTRING();
extern LP p_lsp_HASH_2F3();
extern LP p_lsp_HASH();
extern LP p_lsp_MAKE_2DHASH_2DTABLE_2D1();
extern SYMBOL s_lsp_FLOATP; 
MAKE_FLOAT(k2015,0.0);
MAKE_FLOAT(k2016,1.0);
static struct {unsigned long header; char string[80+1];}
k2017  = {((80 << 8) + TYPE_SIMPLE_STRING), 
"Rehash-threshold ~A is not a floating-point ~\n            number between 0 and 1"};
extern SYMBOL s_lsp_PRIME_2DCEILING; 
extern SYMBOL s_lsp_MAKE_2DSIMPLE_2DARRAY; 
extern SYMBOL s_lsp_FLOOR_2F1V; 
extern SYMBOL s_lsp_FRESH_2DHASH_2DTABLE_2F8; 
extern LP p_lsp_PRIME_2DCEILING();
extern LP p_lsp_MAKE_2DHASH_2DTABLE();
extern SYMBOL s_key_TEST; 
extern SYMBOL s_lsp_EQL; 
extern SYMBOL s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION; 
extern SYMBOL s_key_SIZE; 
extern SYMBOL s_key_REHASH_2DSIZE; 
MAKE_FLOAT(k2018,2.0);
extern SYMBOL s_key_REHASH_2DTHRESHOLD; 
MAKE_FLOAT(k2019,0.6);
extern SYMBOL s_lsp_MAKE_2DHASH_2DTABLE_2D1; 
extern LP p_lsp_MAPHASH();
extern SYMBOL s_lsp_FUNCTIONP; 
extern SYMBOL s_lsp_FUNCTION; 
extern LP p_lsp_REHASH();
extern SYMBOL s_lsp_FIXNUMP; 
extern SYMBOL s_lsp_CEILING; 
MAKE_SIMPLE_STRING(k2020,36,"~S is not one of these types:~{ ~A~}");
extern SYMBOL s_lsp_FLOAT; 
extern SYMBOL s_lsp_FIXNUM; 
MAKE_CONS(k2022,LREF(s_lsp_FIXNUM),LREF(s_lsp_NIL));
MAKE_CONS(k2021,LREF(s_lsp_FLOAT),LREF(k2022));
extern SYMBOL s_lsp_SET_2DGETHASH; 
extern LP p_lsp_REMHASH();
extern SYMBOL s_lsp_HASH_2DKEY_2D_3EINDEX; 
extern LP p_lsp_SET_2DGETHASH();
extern SYMBOL s_lsp_REHASH; 
extern LP p_lsp_SXHASH_2DW();
extern LP p_lsp_SXHASH_2FSYMBOL();
extern SYMBOL s_lsp_SYMBOL_2DHASH_2DCODE; 
extern LP p_lsp_SXHASH_2FCHARACTER();
extern LP p_lsp_SXHASH();
extern SYMBOL s_lsp_SYMBOLP; 
extern SYMBOL s_lsp_SIMPLE_2DSTRING_2DP; 
extern SYMBOL s_lsp_SXHASH_2FSIMPLE_2DSTRING; 
extern SYMBOL s_lsp_CHARACTERP; 


extern LP subtract();
extern LP add();
extern LP num_equal_p();
extern LP multiply();
extern LP lessp();
extern LP greaterp();


LP p_lsp_CLRHASH(argc, v_TABLE_0)
      ARGC argc;  LP v_TABLE_0;
{
LP v_VALUE_30; LP v_N_29; LP v_S_28; 
LP v_VALUE_26; LP v_S_25; LP v_T3043_24; 
LP v_S3042_23; LP v_V3041_22; LP v_T3040_21; 
LP v_T3039_20; LP v_S3038_19; LP v_LOOP_2DBIND_2D843_15; 
LP v_I_14; LP v_I_12; LP v_S_11; 
LP v_S_9; LP v_EMPTY_8; LP v_BUCKETS_7; 
LP v_I_5; LP v_S_4; LP v_S_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_HASH_2DTABLE_2DP) (1, v_TABLE_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_TABLE_0, LREF(s_lsp_HASH_2DTABLE), (LP) 0);
}
v_S_2 = v_TABLE_0;
v_S_4 = v_TABLE_0;
v_I_5 = (LP) 2;
v_BUCKETS_7 = ((LP) DEREF((v_TABLE_0) + 1 * 4));
v_EMPTY_8 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AEMPTY_2DBUCKET_2DMARKER_2A));
v_I_14 = (LP) 0;
v_S_9 = v_TABLE_0;
v_S_11 = v_TABLE_0;
v_I_12 = (LP) 8;
v_LOOP_2DBIND_2D843_15 = ((LP) DEREF((v_TABLE_0) + 4 * 4));
t_NEXT_2DLOOP_17:;
if (((int) (v_I_14) >= (int) (v_LOOP_2DBIND_2D843_15))) {
goto t_END_2DLOOP_18;
}
v_S3038_19 = v_EMPTY_8;
v_T3039_20 = v_BUCKETS_7;
v_T3040_21 = v_I_14;
v_V3041_22 = v_EMPTY_8;
((LP) (DEREF((v_BUCKETS_7) + FX_TO_INT(v_T3040_21) * 4) = (LD) (v_V3041_22)));
v_I_14 = (((LP) ((int) (v_I_14) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_17;
goto t_END_2DLOOP_18;
t_END_2DLOOP_18:;
goto b_NIL_16;
b_NIL_16:;
v_S3042_23 = (LP) 0;
v_T3043_24 = v_TABLE_0;
v_S_25 = v_TABLE_0;
v_VALUE_26 = (LP) 0;
v_S_28 = v_TABLE_0;
v_N_29 = (LP) 10;
v_VALUE_30 = (LP) 0;
((LP) (DEREF((v_TABLE_0) + 5 * 4) = (LD) ((LP) 0)));
return(v_TABLE_0);
}

LP p_lsp_GETHASH_2DWITH_2DKEY(argc, v_KEY_0, v_TABLE_1, v_HASH_2DCODE_2)
      ARGC argc;  LP v_KEY_0; LP v_TABLE_1; LP v_HASH_2DCODE_2;
{
LP v_I_9; LP v_S_8; LP v_S_6; 
LP v_I_5; LP v_VALUE_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; 
if (argc != 3) wna(argc,3);
t0 = ICALL(s_lsp_HASH_2DTABLE_2DP) (1, v_TABLE_1);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_TABLE_1, LREF(s_lsp_HASH_2DTABLE), (LP) 0);
}
{
int real_argc;
BEGIN_MV_CALL(mv_holder2012,0);
t1 = ICALL(s_lsp_HASH_2DKEY_2D_3EINDEX_2F3) (MV_CALL(mv_holder2012,3), v_KEY_0, v_TABLE_1, v_HASH_2DCODE_2);
SET_MV_RETURN_VALUE(mv_holder2012,0,t1);
if SV_RETURN_P(mv_holder2012) SET_MV_RETURN_COUNT(mv_holder2012,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder2012);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_VALUE_4 = NIL;
} else {
v_VALUE_4 = NEXT_VAR_VALUE(mv_holder2012);
}
if (real_argc < 2) {
v_I_5 = NIL;
} else {
v_I_5 = NEXT_VAR_VALUE(mv_holder2012);
}
END_VAR_VALUES;
END_MV_CALL;
t4 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AEMPTY_2DBUCKET_2DMARKER_2A));
t3 = ICALL(s_lsp_EQ) (2, v_VALUE_4, t4);
if (t3 != NIL) {
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,3);
SET_MV_RETURN_VALUE(argc,1,LREF(s_lsp_NIL));
SET_MV_RETURN_VALUE(argc,2,LREF(s_lsp_NIL));
}
return(LREF(s_lsp_NIL));
} else {
v_S_6 = v_TABLE_1;
v_S_8 = v_TABLE_1;
v_I_9 = (LP) 2;
t6 = ((LP) DEREF((v_TABLE_1) + 1 * 4));
t5 = ((LP) DEREF((t6) + FX_TO_INT(v_I_5) * 4));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,3);
SET_MV_RETURN_VALUE(argc,1,v_VALUE_4);
SET_MV_RETURN_VALUE(argc,2,LREF(s_lsp_T));
}
return(t5);
}
}
}

LP p_lsp_GETHASH(argc, v_KEY_0, v_TABLE_1)
      ARGC argc;  LP v_KEY_0; LP v_TABLE_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_HASH_2DTABLE_2DP) (1, v_TABLE_1);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_TABLE_1, LREF(s_lsp_HASH_2DTABLE), (LP) 0);
}
t2 = ICALL(s_lsp_SXHASH) (1, v_KEY_0);
t1 = ICALL(s_lsp_GETHASH_2F3) (MV_CALL(argc,3), v_KEY_0, v_TABLE_1, t2);
return(t1);
}

LP p_lsp_GETHASH_2F3(argc, v_KEY_0, v_TABLE_1, v_HASH_2DCODE_2)
      ARGC argc;  LP v_KEY_0; LP v_TABLE_1; LP v_HASH_2DCODE_2;
{
LP v_I_5; LP v_VALUE_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
if (argc != 3) wna(argc,3);
{
int real_argc;
BEGIN_MV_CALL(mv_holder2013,0);
t0 = ICALL(s_lsp_HASH_2DKEY_2D_3EINDEX_2F3) (MV_CALL(mv_holder2013,3), v_KEY_0, v_TABLE_1, v_HASH_2DCODE_2);
SET_MV_RETURN_VALUE(mv_holder2013,0,t0);
if SV_RETURN_P(mv_holder2013) SET_MV_RETURN_COUNT(mv_holder2013,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder2013);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_VALUE_4 = NIL;
} else {
v_VALUE_4 = NEXT_VAR_VALUE(mv_holder2013);
}
if (real_argc < 2) {
v_I_5 = NIL;
} else {
v_I_5 = NEXT_VAR_VALUE(mv_holder2013);
}
END_VAR_VALUES;
END_MV_CALL;
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AEMPTY_2DBUCKET_2DMARKER_2A));
t2 = ICALL(s_lsp_EQ) (2, v_VALUE_4, t3);
if (t2 != NIL) {
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,LREF(s_lsp_NIL));
}
return(LREF(s_lsp_NIL));
} else {
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,LREF(s_lsp_T));
}
return(v_VALUE_4);
}
}
}

LP p_lsp_HASH_2DKEY_2D_3EINDEX(argc, v_KEY_0, v_TABLE_1)
      ARGC argc;  LP v_KEY_0; LP v_TABLE_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 2) wna(argc,2);
t1 = ICALL(s_lsp_SXHASH) (1, v_KEY_0);
t0 = ICALL(s_lsp_HASH_2DKEY_2D_3EINDEX_2F3) (MV_CALL(argc,3), v_KEY_0, v_TABLE_1, t1);
return(t0);
}

LP p_lsp_HASH_2DKEY_2D_3EINDEX_2F3(argc, v_KEY_0, v_TABLE_1, v_HASH_2DCODE_2)
      ARGC argc;  LP v_KEY_0; LP v_TABLE_1; LP v_HASH_2DCODE_2;
{
LP v_G3045_37; LP v_X_33; LP v_LOOP_2DBIND_2D845_32; 
LP v_I_31; LP v_G3044_30; LP v_X_26; 
LP v_LOOP_2DBIND_2D844_25; LP v_I_24; LP v_LENGTH_23; 
LP v_EMPTY_22; LP v_TEST_21; LP v_BUCKETS_20; 
LP v_START_19; LP v_I_17; LP v_S_16; 
LP v_S_14; LP v_I_12; LP v_S_11; 
LP v_S_9; LP v_I_7; LP v_S_6; 
LP v_S_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; 
if (argc != 3) wna(argc,3);
v_START_19 = ICALL(s_lsp_HASH_2F3) (3, v_KEY_0, v_TABLE_1, v_HASH_2DCODE_2);
v_S_4 = v_TABLE_1;
v_S_6 = v_TABLE_1;
v_I_7 = (LP) 2;
v_BUCKETS_20 = ((LP) DEREF((v_TABLE_1) + 1 * 4));
v_S_9 = v_TABLE_1;
v_S_11 = v_TABLE_1;
v_I_12 = (LP) 4;
v_TEST_21 = ((LP) DEREF((v_TABLE_1) + 2 * 4));
v_EMPTY_22 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AEMPTY_2DBUCKET_2DMARKER_2A));
v_S_14 = v_TABLE_1;
v_S_16 = v_TABLE_1;
v_I_17 = (LP) 8;
v_LENGTH_23 = ((LP) DEREF((v_TABLE_1) + 4 * 4));
v_I_24 = v_START_19;
v_X_26 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_28:;
if (((int) (v_I_24) >= (int) (v_LENGTH_23))) {
goto t_END_2DLOOP_29;
}
v_X_26 = ((LP) DEREF((v_BUCKETS_20) + FX_TO_INT(v_I_24) * 4));
v_G3044_30 = CODE_PTR(COERCE_TO_FUNCTION(v_TEST_21))(2, v_X_26, v_KEY_0);
if (v_G3044_30 != NIL) {
t2 = v_G3044_30;
} else {
t2 = ICALL(s_lsp_EQ) (2, v_X_26, v_EMPTY_22);
}
if (t2 != NIL) {
t4 = (((LP) ((int) (v_I_24) + (int) ((LP) 2))));
t3 = ((LP) DEREF((v_BUCKETS_20) + FX_TO_INT(t4) * 4));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,v_I_24);
}
return(t3);
return(NIL);
}
v_I_24 = (((LP) ((int) (v_I_24) + (int) ((LP) 4))));
goto t_NEXT_2DLOOP_28;
goto t_END_2DLOOP_29;
t_END_2DLOOP_29:;
v_I_31 = (LP) 0;
v_X_33 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_35:;
if (((int) (v_I_31) >= (int) (v_START_19))) {
goto t_END_2DLOOP_36;
}
v_X_33 = ((LP) DEREF((v_BUCKETS_20) + FX_TO_INT(v_I_31) * 4));
v_G3045_37 = CODE_PTR(COERCE_TO_FUNCTION(v_TEST_21))(2, v_X_33, v_KEY_0);
if (v_G3045_37 != NIL) {
t6 = v_G3045_37;
} else {
t6 = ICALL(s_lsp_EQ) (2, v_X_33, v_EMPTY_22);
}
if (t6 != NIL) {
t8 = (((LP) ((int) (v_I_31) + (int) ((LP) 2))));
t7 = ((LP) DEREF((v_BUCKETS_20) + FX_TO_INT(t8) * 4));
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,2);
SET_MV_RETURN_VALUE(argc,1,v_I_31);
}
return(t7);
return(NIL);
}
v_I_31 = (((LP) ((int) (v_I_31) + (int) ((LP) 4))));
goto t_NEXT_2DLOOP_35;
goto t_END_2DLOOP_36;
t_END_2DLOOP_36:;
t9 = ICALL(s_lsp_ERROR) (MV_CALL(argc,1), LREF(k2014));
return(t9);
}

LP p_lsp_SXHASH_2FSIMPLE_2DSTRING(argc, v_S_0)
      ARGC argc;  LP v_S_0;
{
LP v_C_10; LP v_LOOP_2DITER_2DFLAG_2D847_6; LP v_H_5; 
LP v_LOOP_2DBIND_2D846_4; LP v_I_3; LP v_LEN_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; 
if (argc != 1) wna(argc,1);
v_LEN_2 = INT_TO_FX((LP) (DEREF((v_S_0) - 4) >> 8));
v_I_3 = (LP) -2;
v_H_5 = v_LEN_2;
v_LOOP_2DITER_2DFLAG_2D847_6 = LREF(s_lsp_T);
t_NEXT_2DLOOP_8:;
if (((int) (v_I_3) >= (int) (v_LEN_2))) {
goto t_END_2DLOOP_9;
}
if (v_LOOP_2DITER_2DFLAG_2D847_6 == NIL) {
t3 = ((LP) ((int) (v_H_5) * FX_TO_INT(((LP) 1226))));
v_C_10 = NEW_CHAR((LP) *((v_S_0) - 1 + FX_TO_INT(v_I_3)));
t4 = INT_TO_FX(((int) RAW_CHAR(v_C_10)));
t2 = (((LP) ((int) (t3) + (int) (t4))));
v_H_5 = (((LP) ((int) (t2) & (int) ((LP) 2097150))));
}
v_LOOP_2DITER_2DFLAG_2D847_6 = LREF(s_lsp_NIL);
v_I_3 = (((LP) ((int) (v_I_3) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_8;
goto t_END_2DLOOP_9;
t_END_2DLOOP_9:;
return(v_H_5);
return(NIL);
return(NIL);
}

LP p_lsp_HASH_2F3(argc, v_KEY_0, v_TABLE_1, v_HASH_2DCODE_2)
      ARGC argc;  LP v_KEY_0; LP v_TABLE_1; LP v_HASH_2DCODE_2;
{
LP v_I_7; LP v_S_6; LP v_S_4; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; 
if (argc != 3) wna(argc,3);
v_S_4 = v_TABLE_1;
v_S_6 = v_TABLE_1;
v_I_7 = (LP) 6;
t2 = ((LP) DEREF((v_TABLE_1) + 3 * 4));
t1 = ((LP) ((int) (v_HASH_2DCODE_2) % (int) (t2)));
t0 = INT_TO_FX(((unsigned long) (FX_TO_INT(t1)) << 1));
return(t0);
}

LP p_lsp_HASH(argc, v_KEY_0, v_TABLE_1)
      ARGC argc;  LP v_KEY_0; LP v_TABLE_1;
{
LP v_I_10; LP v_S_9; LP v_S_7; 
LP v_HASH_2DCODE_5; LP v_TABLE_4; LP v_KEY_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; 
if (argc != 2) wna(argc,2);
v_HASH_2DCODE_5 = ICALL(s_lsp_SXHASH) (1, v_KEY_0);
v_S_7 = v_TABLE_1;
v_S_9 = v_TABLE_1;
v_I_10 = (LP) 6;
t2 = ((LP) DEREF((v_TABLE_1) + 3 * 4));
t1 = ((LP) ((int) (v_HASH_2DCODE_5) % (int) (t2)));
t0 = INT_TO_FX(((unsigned long) (FX_TO_INT(t1)) << 1));
return(t0);
}

LP p_lsp_MAKE_2DHASH_2DTABLE_2D1(argc, v_TEST_0, v_SIZE_1, v_REHASH_2DSIZE_2, v_REHASH_2DTHRESHOLD_3)
      ARGC argc;  LP v_TEST_0; LP v_SIZE_1; LP v_REHASH_2DSIZE_2; LP v_REHASH_2DTHRESHOLD_3;
{
LP v_REHASH_2DLIMIT_22; LP v_REHASH_2DTHRESHOLD_21; LP v_REHASH_2DSIZE_20; 
LP v_COUNT_19; LP v_LENGTH_18; LP v_SIZE_17; 
LP v_TEST_16; LP v_BUCKETS_15; LP v_REHASH_2DLIMIT_14; 
LP v_REHASH_2DTHRESHOLD_13; LP v_REHASH_2DSIZE_12; LP v_COUNT_11; 
LP v_LENGTH_10; LP v_SIZE_9; LP v_TEST_8; 
LP v_BUCKETS_7; LP v_LENGTH_6; LP v_REAL_2DSIZE_5; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; 
if (argc != 4) wna(argc,4);
t1 = ICALL(s_lsp_FLOATP) (1, v_REHASH_2DTHRESHOLD_3);
if (t1 != NIL) {
t2 = (greaterp((v_REHASH_2DTHRESHOLD_3), (LREF(k2015))));
if (t2 != NIL) {
t0 = (lessp((v_REHASH_2DTHRESHOLD_3), (LREF(k2016))));
} else {
t0 = LREF(s_lsp_NIL);
}
} else {
t0 = LREF(s_lsp_NIL);
}
if (t0 == NIL) {
ICALL(s_lsp_ERROR) (2, LREF(k2017), v_REHASH_2DTHRESHOLD_3);
}
v_REAL_2DSIZE_5 = ICALL(s_lsp_PRIME_2DCEILING) (1, v_SIZE_1);
v_LENGTH_6 = (multiply((v_REAL_2DSIZE_5), ((LP) 4)));
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AEMPTY_2DBUCKET_2DMARKER_2A));
v_BUCKETS_15 = ICALL(s_lsp_MAKE_2DSIMPLE_2DARRAY) (5, v_LENGTH_6, (LP) 128, (LP) 64, t3, LREF(s_lsp_NIL));
t4 = (multiply((v_REHASH_2DTHRESHOLD_3), (v_REAL_2DSIZE_5)));
v_REHASH_2DLIMIT_22 = ICALL(s_lsp_FLOOR_2F1V) (1, t4);
t5 = ICALL(s_lsp_FRESH_2DHASH_2DTABLE_2F8) (MV_CALL(argc,8), v_BUCKETS_15, v_TEST_0, v_REAL_2DSIZE_5, v_LENGTH_6, (LP) 0, v_REHASH_2DSIZE_2, v_REHASH_2DTHRESHOLD_3, v_REHASH_2DLIMIT_22);
return(t5);
}

LP p_lsp_PRIME_2DCEILING(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 1) wna(argc,1);
t1 = ((LP) ((int) (v_X_0) % (int) ((LP) 4)));
t0 = (num_equal_p((t1), ((LP) 0)));
if (t0 != NIL) {
v_X_0 = (((LP) ((int) ((LP) 2) + (int) (v_X_0))));
}
t3 = ((LP) ((int) (v_X_0) % (int) ((LP) 6)));
t2 = (num_equal_p((t3), ((LP) 0)));
if (t2 != NIL) {
v_X_0 = (((LP) ((int) ((LP) 4) + (int) (v_X_0))));
}
t5 = ((LP) ((int) (v_X_0) % (int) ((LP) 14)));
t4 = (num_equal_p((t5), ((LP) 0)));
if (t4 != NIL) {
v_X_0 = (((LP) ((int) ((LP) 8) + (int) (v_X_0))));
}
return(v_X_0);
}

LP p_lsp_MAKE_2DHASH_2DTABLE(va_alist) va_dcl
{
LP v_KEYS3046_4; LP v_REHASH_2DTHRESHOLD_3; LP v_REHASH_2DSIZE_2; 
LP v_SIZE_1; LP v_TEST_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
DYNAMIC_REST_HOLDER(rest_conses);
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 0) wna_low(real_argc,0);
DYNAMIC_RESTIFY(v_KEYS3046_4,1,NEXT_VAR_ARG);
BEGIN_KEY_INIT(v_TEST_0,LREF(s_key_TEST),v_KEYS3046_4)
t0 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_EQL));
v_TEST_0 = t0;
END_KEY_INIT
BEGIN_KEY_INIT(v_SIZE_1,LREF(s_key_SIZE),v_KEYS3046_4)
v_SIZE_1 = (LP) 130;
END_KEY_INIT
BEGIN_KEY_INIT(v_REHASH_2DSIZE_2,LREF(s_key_REHASH_2DSIZE),v_KEYS3046_4)
v_REHASH_2DSIZE_2 = LREF(k2018);
END_KEY_INIT
BEGIN_KEY_INIT(v_REHASH_2DTHRESHOLD_3,LREF(s_key_REHASH_2DTHRESHOLD),v_KEYS3046_4)
v_REHASH_2DTHRESHOLD_3 = LREF(k2019);
END_KEY_INIT
END_VAR_ARGS;
t1 = ICALL(s_lsp_MAKE_2DHASH_2DTABLE_2D1) (MV_CALL(argc,4), v_TEST_0, v_SIZE_1, v_REHASH_2DSIZE_2, v_REHASH_2DTHRESHOLD_3);
return(t1);
}

LP p_lsp_MAPHASH(argc, v_FUNCTION_0, v_TABLE_1)
      ARGC argc;  LP v_FUNCTION_0; LP v_TABLE_1;
{
LP v_KEY_16; LP v_LOOP_2DBIND_2D848_15; LP v_I_14; 
LP v_I_12; LP v_S_11; LP v_S_9; 
LP v_BUCKETS_8; LP v_I_6; LP v_S_5; 
LP v_S_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_FUNCTIONP) (1, v_FUNCTION_0);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_FUNCTION_0, LREF(s_lsp_FUNCTION), (LP) 0);
}
t1 = ICALL(s_lsp_HASH_2DTABLE_2DP) (1, v_TABLE_1);
if (t1 == NIL) {
ICALL(s_lsp_WTA) (3, v_TABLE_1, LREF(s_lsp_HASH_2DTABLE), (LP) 0);
}
v_S_3 = v_TABLE_1;
v_S_5 = v_TABLE_1;
v_I_6 = (LP) 2;
v_BUCKETS_8 = ((LP) DEREF((v_TABLE_1) + 1 * 4));
v_I_14 = (LP) 0;
v_S_9 = v_TABLE_1;
v_S_11 = v_TABLE_1;
v_I_12 = (LP) 8;
v_LOOP_2DBIND_2D848_15 = ((LP) DEREF((v_TABLE_1) + 4 * 4));
v_KEY_16 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_18:;
if (((int) (v_I_14) >= (int) (v_LOOP_2DBIND_2D848_15))) {
goto t_END_2DLOOP_19;
}
v_KEY_16 = ((LP) DEREF((v_BUCKETS_8) + FX_TO_INT(v_I_14) * 4));
t4 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AEMPTY_2DBUCKET_2DMARKER_2A));
t3 = ICALL(s_lsp_EQ) (2, v_KEY_16, t4);
if (t3 == NIL) {
t6 = (((LP) ((int) (v_I_14) + (int) ((LP) 2))));
t5 = ((LP) DEREF((v_BUCKETS_8) + FX_TO_INT(t6) * 4));
CODE_PTR(COERCE_TO_FUNCTION(v_FUNCTION_0))(2, v_KEY_16, t5);
}
v_I_14 = (((LP) ((int) (v_I_14) + (int) ((LP) 4))));
goto t_NEXT_2DLOOP_18;
goto t_END_2DLOOP_19;
t_END_2DLOOP_19:;
return(LREF(s_lsp_NIL));
}

LP p_lsp_REHASH(argc, v_TABLE_0)
      ARGC argc;  LP v_TABLE_0;
{
LP v_KEY_86; LP v_LOOP_2DBIND_2D849_85; LP v_I_84; 
LP v_VALUE_82; LP v_N_81; LP v_S_80; 
LP v_VALUE_78; LP v_S_77; LP v_T3060_76; 
LP v_S3059_75; LP v_I_73; LP v_S_72; 
LP v_S_70; LP v_VALUE_68; LP v_N_67; 
LP v_S_66; LP v_VALUE_64; LP v_S_63; 
LP v_T3058_62; LP v_S3057_61; LP v_VALUE_59; 
LP v_N_58; LP v_S_57; LP v_VALUE_55; 
LP v_S_54; LP v_T3056_53; LP v_S3055_52; 
LP v_VALUE_50; LP v_N_49; LP v_S_48; 
LP v_VALUE_46; LP v_S_45; LP v_T3054_44; 
LP v_S3053_43; LP v_VALUE_41; LP v_N_40; 
LP v_S_39; LP v_VALUE_37; LP v_S_36; 
LP v_T3052_35; LP v_S3051_34; LP v_EMPTY_33; 
LP v_OLD_2DBUCKETS_32; LP v_I_30; LP v_S_29; 
LP v_S_27; LP v_OLD_2DLENGTH_26; LP v_I_24; 
LP v_S_23; LP v_S_21; LP v_NEW_2DBUCKETS_20; 
LP v_NEW_2DLENGTH_19; LP v_NEW_2DSIZE_18; LP v_KEY3050_16; 
LP v_KEY3047_14; LP v_SIZE_13; LP v_I_11; 
LP v_S_10; LP v_S_8; LP v_REHASH_2DSIZE_7; 
LP v_I_5; LP v_S_4; LP v_S_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; 
if (argc != 1) wna(argc,1);
v_S_2 = v_TABLE_0;
v_S_4 = v_TABLE_0;
v_I_5 = (LP) 12;
v_REHASH_2DSIZE_7 = ((LP) DEREF((v_TABLE_0) + 6 * 4));
v_S_8 = v_TABLE_0;
v_S_10 = v_TABLE_0;
v_I_11 = (LP) 6;
v_SIZE_13 = ((LP) DEREF((v_TABLE_0) + 3 * 4));
v_KEY3047_14 = v_REHASH_2DSIZE_7;
v_KEY3050_16 = v_KEY3047_14;
t2 = ICALL(s_lsp_FIXNUMP) (1, v_KEY3050_16);
if (t2 != NIL) {
t1 = (add((v_REHASH_2DSIZE_7), (v_SIZE_13)));
} else {
t3 = INT_TO_FX(((int) TAG((v_KEY3050_16))));
switch ((int) t3) {
case 10:
t4 = (multiply((v_REHASH_2DSIZE_7), (v_SIZE_13)));
t1 = ICALL(s_lsp_CEILING) (1, t4);
break;
default:
goto t_DEFAULT_2DTAG3049_17;
break;
}
}
t0 = t1;
goto b_TYPECASE3048_15;
t_DEFAULT_2DTAG3049_17:;
t5 = ICALL(s_lsp_ERROR) (3, LREF(k2020), v_KEY3047_14, LREF(k2021));
t0 = t5;
goto b_TYPECASE3048_15;
t0 = NIL;
b_TYPECASE3048_15:;
v_NEW_2DSIZE_18 = ICALL(s_lsp_PRIME_2DCEILING) (1, t0);
v_NEW_2DLENGTH_19 = ((LP) ((int) (v_NEW_2DSIZE_18) * FX_TO_INT(((LP) 4))));
t6 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AEMPTY_2DBUCKET_2DMARKER_2A));
v_NEW_2DBUCKETS_20 = ICALL(s_lsp_MAKE_2DSIMPLE_2DARRAY) (5, v_NEW_2DLENGTH_19, (LP) 128, (LP) 64, t6, LREF(s_lsp_NIL));
v_S_21 = v_TABLE_0;
v_S_23 = v_TABLE_0;
v_I_24 = (LP) 8;
v_OLD_2DLENGTH_26 = ((LP) DEREF((v_TABLE_0) + 4 * 4));
v_S_27 = v_TABLE_0;
v_S_29 = v_TABLE_0;
v_I_30 = (LP) 2;
v_OLD_2DBUCKETS_32 = ((LP) DEREF((v_TABLE_0) + 1 * 4));
v_EMPTY_33 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AEMPTY_2DBUCKET_2DMARKER_2A));
v_S3051_34 = v_NEW_2DBUCKETS_20;
v_T3052_35 = v_TABLE_0;
v_S_36 = v_TABLE_0;
v_VALUE_37 = v_NEW_2DBUCKETS_20;
v_S_39 = v_TABLE_0;
v_N_40 = (LP) 2;
v_VALUE_41 = v_NEW_2DBUCKETS_20;
((LP) (DEREF((v_TABLE_0) + 1 * 4) = (LD) (v_NEW_2DBUCKETS_20)));
v_S3053_43 = v_NEW_2DSIZE_18;
v_T3054_44 = v_TABLE_0;
v_S_45 = v_TABLE_0;
v_VALUE_46 = v_NEW_2DSIZE_18;
v_S_48 = v_TABLE_0;
v_N_49 = (LP) 6;
v_VALUE_50 = v_NEW_2DSIZE_18;
((LP) (DEREF((v_TABLE_0) + 3 * 4) = (LD) (v_NEW_2DSIZE_18)));
v_S3055_52 = v_NEW_2DLENGTH_19;
v_T3056_53 = v_TABLE_0;
v_S_54 = v_TABLE_0;
v_VALUE_55 = v_NEW_2DLENGTH_19;
v_S_57 = v_TABLE_0;
v_N_58 = (LP) 8;
v_VALUE_59 = v_NEW_2DLENGTH_19;
((LP) (DEREF((v_TABLE_0) + 4 * 4) = (LD) (v_NEW_2DLENGTH_19)));
v_S3057_61 = (LP) 0;
v_T3058_62 = v_TABLE_0;
v_S_63 = v_TABLE_0;
v_VALUE_64 = (LP) 0;
v_S_66 = v_TABLE_0;
v_N_67 = (LP) 10;
v_VALUE_68 = (LP) 0;
((LP) (DEREF((v_TABLE_0) + 5 * 4) = (LD) ((LP) 0)));
v_S_70 = v_TABLE_0;
v_S_72 = v_TABLE_0;
v_I_73 = (LP) 14;
t8 = ((LP) DEREF((v_TABLE_0) + 7 * 4));
t7 = (multiply((v_NEW_2DSIZE_18), (t8)));
v_S3059_75 = ICALL(s_lsp_FLOOR_2F1V) (1, t7);
v_T3060_76 = v_TABLE_0;
v_S_77 = v_TABLE_0;
v_VALUE_78 = v_S3059_75;
v_S_80 = v_TABLE_0;
v_N_81 = (LP) 16;
v_VALUE_82 = v_S3059_75;
((LP) (DEREF((v_TABLE_0) + 8 * 4) = (LD) (v_S3059_75)));
v_I_84 = (LP) 0;
v_KEY_86 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_88:;
if (((int) (v_I_84) >= (int) (v_OLD_2DLENGTH_26))) {
goto t_END_2DLOOP_89;
}
v_KEY_86 = ((LP) DEREF((v_OLD_2DBUCKETS_32) + FX_TO_INT(v_I_84) * 4));
t10 = ICALL(s_lsp_EQ) (2, v_KEY_86, v_EMPTY_33);
if (t10 == NIL) {
t12 = (((LP) ((int) (v_I_84) + (int) ((LP) 2))));
t11 = ((LP) DEREF((v_OLD_2DBUCKETS_32) + FX_TO_INT(t12) * 4));
ICALL(s_lsp_SET_2DGETHASH) (3, v_KEY_86, v_TABLE_0, t11);
}
v_I_84 = (((LP) ((int) (v_I_84) + (int) ((LP) 4))));
goto t_NEXT_2DLOOP_88;
goto t_END_2DLOOP_89;
t_END_2DLOOP_89:;
return(v_TABLE_0);
}

LP p_lsp_REMHASH(argc, v_KEY_0, v_TABLE_1)
      ARGC argc;  LP v_KEY_0; LP v_TABLE_1;
{
LP v_VALUE_35; LP v_N_34; LP v_S_33; 
LP v_VALUE_31; LP v_S_30; LP v_T3070_29; 
LP v_S3069_28; LP v_I_26; LP v_S_25; 
LP v_S_23; LP v_V3068_22; LP v_T3067_21; 
LP v_T3066_20; LP v_I_18; LP v_S_17; 
LP v_S_15; LP v_S3065_14; LP v_V3064_13; 
LP v_T3063_12; LP v_T3062_11; LP v_I_9; 
LP v_S_8; LP v_S_6; LP v_S3061_5; 
LP v_I_4; LP v_VALUE_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_HASH_2DTABLE_2DP) (1, v_TABLE_1);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_TABLE_1, LREF(s_lsp_HASH_2DTABLE), (LP) 0);
}
{
int real_argc;
BEGIN_MV_CALL(mv_holder2023,0);
t1 = ICALL(s_lsp_HASH_2DKEY_2D_3EINDEX) (MV_CALL(mv_holder2023,2), v_KEY_0, v_TABLE_1);
SET_MV_RETURN_VALUE(mv_holder2023,0,t1);
if SV_RETURN_P(mv_holder2023) SET_MV_RETURN_COUNT(mv_holder2023,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder2023);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_VALUE_3 = NIL;
} else {
v_VALUE_3 = NEXT_VAR_VALUE(mv_holder2023);
}
if (real_argc < 2) {
v_I_4 = NIL;
} else {
v_I_4 = NEXT_VAR_VALUE(mv_holder2023);
}
END_VAR_VALUES;
END_MV_CALL;
t4 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AEMPTY_2DBUCKET_2DMARKER_2A));
t3 = ICALL(s_lsp_EQ) (2, v_VALUE_3, t4);
if (t3 != NIL) {
return(LREF(s_lsp_NIL));
} else {
v_S3061_5 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AEMPTY_2DBUCKET_2DMARKER_2A));
v_S_6 = v_TABLE_1;
v_S_8 = v_TABLE_1;
v_I_9 = (LP) 2;
v_T3062_11 = ((LP) DEREF((v_TABLE_1) + 1 * 4));
v_T3063_12 = v_I_4;
v_V3064_13 = v_S3061_5;
((LP) (DEREF((v_T3062_11) + FX_TO_INT(v_I_4) * 4) = (LD) (v_V3064_13)));
v_S3065_14 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AEMPTY_2DBUCKET_2DMARKER_2A));
v_S_15 = v_TABLE_1;
v_S_17 = v_TABLE_1;
v_I_18 = (LP) 2;
v_T3066_20 = ((LP) DEREF((v_TABLE_1) + 1 * 4));
v_T3067_21 = (add((v_I_4), ((LP) 2)));
v_V3068_22 = v_S3065_14;
((LP) (DEREF((v_T3066_20) + FX_TO_INT(v_T3067_21) * 4) = (LD) (v_V3068_22)));
v_S_23 = v_TABLE_1;
v_S_25 = v_TABLE_1;
v_I_26 = (LP) 10;
t5 = ((LP) DEREF((v_TABLE_1) + 5 * 4));
v_S3069_28 = (subtract((t5), ((LP) 2)));
v_T3070_29 = v_TABLE_1;
v_S_30 = v_TABLE_1;
v_VALUE_31 = v_S3069_28;
v_S_33 = v_TABLE_1;
v_N_34 = (LP) 10;
v_VALUE_35 = v_S3069_28;
((LP) (DEREF((v_TABLE_1) + 5 * 4) = (LD) (v_S3069_28)));
return(LREF(s_lsp_T));
}
}
}

LP p_lsp_SET_2DGETHASH(argc, v_KEY_0, v_TABLE_1, v_VALUE_2)
      ARGC argc;  LP v_KEY_0; LP v_TABLE_1; LP v_VALUE_2;
{
LP v_I_42; LP v_S_41; LP v_S_39; 
LP v_COUNT_38; LP v_VALUE_36; LP v_N_35; 
LP v_S_34; LP v_VALUE_32; LP v_S_31; 
LP v_T3080_30; LP v_S3079_29; LP v_I_27; 
LP v_S_26; LP v_S_24; LP v_V3078_23; 
LP v_T3077_22; LP v_T3076_21; LP v_I_19; 
LP v_S_18; LP v_S_16; LP v_S3075_15; 
LP v_V3074_14; LP v_T3073_13; LP v_T3072_12; 
LP v_I_10; LP v_S_9; LP v_S_7; 
LP v_S3071_6; LP v_I_5; LP v_CURRENT_2DVALUE_4; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; 
if (argc != 3) wna(argc,3);
t0 = ICALL(s_lsp_HASH_2DTABLE_2DP) (1, v_TABLE_1);
if (t0 == NIL) {
ICALL(s_lsp_WTA) (3, v_TABLE_1, LREF(s_lsp_HASH_2DTABLE), (LP) 0);
}
{
int real_argc;
BEGIN_MV_CALL(mv_holder2024,0);
t1 = ICALL(s_lsp_HASH_2DKEY_2D_3EINDEX) (MV_CALL(mv_holder2024,2), v_KEY_0, v_TABLE_1);
SET_MV_RETURN_VALUE(mv_holder2024,0,t1);
if SV_RETURN_P(mv_holder2024) SET_MV_RETURN_COUNT(mv_holder2024,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder2024);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_CURRENT_2DVALUE_4 = NIL;
} else {
v_CURRENT_2DVALUE_4 = NEXT_VAR_VALUE(mv_holder2024);
}
if (real_argc < 2) {
v_I_5 = NIL;
} else {
v_I_5 = NEXT_VAR_VALUE(mv_holder2024);
}
END_VAR_VALUES;
END_MV_CALL;
v_S3071_6 = v_KEY_0;
v_S_7 = v_TABLE_1;
v_S_9 = v_TABLE_1;
v_I_10 = (LP) 2;
v_T3072_12 = ((LP) DEREF((v_TABLE_1) + 1 * 4));
v_T3073_13 = v_I_5;
v_V3074_14 = v_KEY_0;
((LP) (DEREF((v_T3072_12) + FX_TO_INT(v_I_5) * 4) = (LD) (v_V3074_14)));
v_S3075_15 = v_VALUE_2;
v_S_16 = v_TABLE_1;
v_S_18 = v_TABLE_1;
v_I_19 = (LP) 2;
v_T3076_21 = ((LP) DEREF((v_TABLE_1) + 1 * 4));
v_T3077_22 = (((LP) ((int) (v_I_5) + (int) ((LP) 2))));
v_V3078_23 = v_VALUE_2;
((LP) (DEREF((v_T3076_21) + FX_TO_INT(v_T3077_22) * 4) = (LD) (v_V3078_23)));
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp__2AEMPTY_2DBUCKET_2DMARKER_2A));
t2 = ICALL(s_lsp_EQ) (2, v_CURRENT_2DVALUE_4, t3);
if (t2 != NIL) {
v_S_24 = v_TABLE_1;
v_S_26 = v_TABLE_1;
v_I_27 = (LP) 10;
t4 = ((LP) DEREF((v_TABLE_1) + 5 * 4));
v_S3079_29 = (((LP) ((int) (t4) + (int) ((LP) 2))));
v_T3080_30 = v_TABLE_1;
v_S_31 = v_TABLE_1;
v_VALUE_32 = v_S3079_29;
v_S_34 = v_TABLE_1;
v_N_35 = (LP) 10;
v_VALUE_36 = v_S3079_29;
v_COUNT_38 = ((LP) (DEREF((v_TABLE_1) + 5 * 4) = (LD) (v_S3079_29)));
v_S_39 = v_TABLE_1;
v_S_41 = v_TABLE_1;
v_I_42 = (LP) 16;
t6 = ((LP) DEREF((v_TABLE_1) + 8 * 4));
if (((int) (v_COUNT_38) >= (int) (t6))) {
ICALL(s_lsp_REHASH) (1, v_TABLE_1);
} else {
}
}
return(v_VALUE_2);
}
}

LP p_lsp_SXHASH_2DW(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_SXHASH) (MV_CALL(argc,1), v_X_0);
return(t0);
}

LP p_lsp_SXHASH_2FSYMBOL(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_SYMBOL_2DHASH_2DCODE) (MV_CALL(argc,1), v_X_0);
return(t0);
}

LP p_lsp_SXHASH_2FCHARACTER(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{
LP v_C_2; 
LP t0; LP t1; LP t2; LP t3; 
if (argc != 1) wna(argc,1);
v_C_2 = v_X_0;
t0 = INT_TO_FX(((int) RAW_CHAR(v_X_0)));
return(t0);
}

LP p_lsp_SXHASH(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{
LP v_C_7; LP v_X_5; LP v_X_3; 
LP v_KEY3081_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; 
if (argc != 1) wna(argc,1);
v_KEY3081_2 = v_X_0;
t1 = ICALL(s_lsp_SYMBOLP) (1, v_KEY3081_2);
if (t1 != NIL) {
v_X_3 = v_X_0;
t0 = ICALL(s_lsp_SYMBOL_2DHASH_2DCODE) (MV_CALL(argc,1), v_X_0);
return(t0);
} else {
t2 = ICALL(s_lsp_SIMPLE_2DSTRING_2DP) (1, v_KEY3081_2);
if (t2 != NIL) {
t0 = ICALL(s_lsp_SXHASH_2FSIMPLE_2DSTRING) (MV_CALL(argc,1), v_X_0);
return(t0);
} else {
t3 = ICALL(s_lsp_FIXNUMP) (1, v_KEY3081_2);
if (t3 != NIL) {
return(v_X_0);
} else {
t4 = ICALL(s_lsp_CHARACTERP) (1, v_KEY3081_2);
if (t4 != NIL) {
v_X_5 = v_X_0;
v_C_7 = v_X_0;
t0 = INT_TO_FX(((int) RAW_CHAR(v_X_0)));
return(t0);
} else {
return((LP) 0);
}
}
}
}
}

