/*
:comment "Compiled at 4:50:59 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: Debug Library"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O2 -fPIC"
:version 0
:end-package-info 0
:sym WCL-FIXNUM?
:sym NIL
:sym FORMAT
:sym *CONST-LABELS*
:sym GETHASH
:sym LISP->C-SYMBOL-NAME
:sym *EMIT-SYMBOL-DATA-FUNCTION*
:sym *WIN-STREAM*
:sym *K-STREAM*
:sym SET-GETHASH
:sym GENSTRING
:sym EMIT-VECTOR
:sym ARRAYP
:sym EMIT-MULTI-ARRAY
:sym INNER-PROC-P
:sym EMIT-NULL-OE-PROC
:sym FOREIGN-SYMBOL-P
:sym EMIT-FOREIGN-SYMBOL
:sym EMIT-CONS
:sym EMIT-FLOAT
:sym EMIT-RATIO
:sym EMIT-COMPLEX
:sym COMPILED-FUNCTION-P
:sym EMIT-COMPILED-FUNCTION
:sym EMIT-STRUCTURE
:sym EMIT-BIGNUM
:sym VECTOR
:sym ARRAY
:sym INNER-PROC
:sym FOREIGN-SYMBOL
:sym CONS
:sym FLOAT
:sym RATIO
:sym COMPLEX
:sym COMPILED-FUNCTION
:sym STRUCTURE
:sym INTEGER
:sym ERROR
:sf EMIT-DATA "p_lsp_EMIT_2DDATA"
:sym ASH
:sym EMIT-DATA
:sf EMIT-LREF "p_lsp_EMIT_2DLREF"
:sf EMIT-FOREIGN-SYMBOL "p_lsp_EMIT_2DFOREIGN_2DSYMBOL"
:sf EMIT-FLOAT "p_lsp_EMIT_2DFLOAT"
:sym NUMERATOR
:sym EMIT-LREF
:sym DENOMINATOR
:sf EMIT-RATIO "p_lsp_EMIT_2DRATIO"
:sym REALPART
:sym IMAGPART
:sf EMIT-COMPLEX "p_lsp_EMIT_2DCOMPLEX"
:sf EMIT-CONS "p_lsp_EMIT_2DCONS"
:sf EMIT-NULL-OE-PROC "p_lsp_EMIT_2DNULL_2DOE_2DPROC"
:sym EMIT-SIMPLE-STRING
:sym EMIT-SIMPLE-1D-ARRAY
:sym EMIT-COMPLEX-1D-ARRAY
:sf EMIT-VECTOR "p_lsp_EMIT_2DVECTOR"
:sym EMIT-SIMPLE-MULTI-ARRAY
:sym EMIT-COMPLEX-MULTI-ARRAY
:sf EMIT-MULTI-ARRAY "p_lsp_EMIT_2DMULTI_2DARRAY"
:sym WRITE-CHAR/2
:sym LENGTH
:sym WRITE-STRING/4
:sf EMIT-STRING-USING-C-SYNTAX "p_lsp_EMIT_2DSTRING_2DUSING_2DC_2DSYNTAX"
:sym EMIT-STRING-USING-C-SYNTAX
:sf EMIT-SIMPLE-STRING "p_lsp_EMIT_2DSIMPLE_2DSTRING"
:sym ARRAY-ELEMENT-TYPE
:sym TYPE->ELEMENT-TYPE-TAG
:sym BIT-VECTOR->WORD-LIST
:sym ELT
:sf EMIT-SIMPLE-1D-ARRAY "p_lsp_EMIT_2DSIMPLE_2D1D_2DARRAY"
:sym :DISPLACED-TO
:sym :ELEMENT-TYPE
:sym UNSIGNED-BYTE
:sym MAKE-ARRAY
:sf BIT-VECTOR->WORD-LIST "p_lsp_BIT_2DVECTOR_2D_3EWORD_2DLIST"
:sf EMIT-COMPLEX-1D-ARRAY "p_lsp_EMIT_2DCOMPLEX_2D1D_2DARRAY"
:sf EMIT-COMPLEX-MULTI-ARRAY "p_lsp_EMIT_2DCOMPLEX_2DMULTI_2DARRAY"
:sf EMIT-SIMPLE-MULTI-ARRAY "p_lsp_EMIT_2DSIMPLE_2DMULTI_2DARRAY"
:sym COMPILED-FUNCTION-NAME
:sym LISP->C-PROC-NAME
:sf EMIT-COMPILED-FUNCTION "p_lsp_EMIT_2DCOMPILED_2DFUNCTION"
:sym TYPE-OF
:sym LOOKUP-STRUCTURE-INFO
:sym REF-STRUCTURE-AS-VECTOR
:sf EMIT-STRUCTURE "p_lsp_EMIT_2DSTRUCTURE"
:sf WCL-FIXNUM? "p_lsp_WCL_2DFIXNUM_3F"
:sym ABS
:sym *PRINT-BASE*
:sym WRITE-TO-STRING-1
:sym CEILING
:sym T
:sym MAX
:sym SUBSEQ-1
:sf EMIT-BIGNUM "p_lsp_EMIT_2DBIGNUM"
:pinfo EMIT-SIMPLE-STRING (LABEL X) NIL NIL NIL NIL NIL NIL T
:pinfo EMIT-MULTI-ARRAY (LABEL X) NIL NIL NIL NIL NIL NIL T
:pinfo BIT-VECTOR->WORD-LIST (BIT-VECTOR) NIL NIL NIL NIL NIL NIL T
:pinfo EMIT-FOREIGN-SYMBOL (X) NIL NIL NIL NIL NIL NIL T
:pinfo EMIT-STRING-USING-C-SYNTAX (STRING) NIL NIL NIL NIL NIL NIL T
:pinfo EMIT-COMPLEX-1D-ARRAY (LABEL X) NIL NIL NIL NIL NIL NIL T
:pinfo EMIT-LREF (X) NIL NIL NIL NIL NIL NIL T
:pinfo EMIT-STRUCTURE (LABEL S) NIL NIL NIL NIL NIL NIL T
:pinfo EMIT-FLOAT (LABEL X) NIL NIL NIL NIL NIL NIL T
:pinfo EMIT-CONS (LABEL X) NIL NIL NIL NIL NIL NIL T
:pinfo EMIT-SIMPLE-1D-ARRAY (LABEL X) NIL NIL NIL NIL NIL NIL T
:pinfo EMIT-NULL-OE-PROC (LABEL X) NIL NIL NIL NIL NIL NIL T
:pinfo EMIT-VECTOR (LABEL X) NIL NIL NIL NIL NIL NIL T
:pinfo EMIT-SIMPLE-MULTI-ARRAY (LABEL X) NIL NIL NIL NIL NIL NIL T
:pinfo WCL-FIXNUM? (N) NIL NIL NIL NIL NIL NIL T
:pinfo EMIT-COMPILED-FUNCTION (LABEL X) NIL NIL NIL NIL NIL NIL T
:pinfo EMIT-COMPLEX-MULTI-ARRAY (LABEL X) NIL NIL NIL NIL NIL NIL T
:pinfo EMIT-DATA (X) NIL NIL NIL NIL NIL NIL T
:pinfo EMIT-RATIO (LABEL X) NIL NIL NIL NIL NIL NIL T
:pinfo EMIT-BIGNUM (LABEL N) NIL NIL NIL NIL NIL NIL T
:pinfo EMIT-COMPLEX (LABEL X) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_lsp_EMIT_2DDATA();
extern SYMBOL s_lsp_WCL_2DFIXNUM_3F; 
extern SYMBOL s_lsp_NIL; 
MAKE_SIMPLE_STRING(k11098,12,"char_tab[~D]");
extern SYMBOL s_lsp_FORMAT; 
extern SYMBOL s_lsp__2ACONST_2DLABELS_2A; 
extern SYMBOL s_lsp_GETHASH; 
extern SYMBOL s_lsp_LISP_2D_3EC_2DSYMBOL_2DNAME; 
extern SYMBOL s_lsp__2AEMIT_2DSYMBOL_2DDATA_2DFUNCTION_2A; 
extern SYMBOL s_lsp__2AWIN_2DSTREAM_2A; 
MAKE_SIMPLE_STRING(k11099,9,":sym ~S~%");
extern SYMBOL s_lsp__2AK_2DSTREAM_2A; 
MAKE_SIMPLE_STRING(k11100,20,"extern SYMBOL ~A; ~%");
extern SYMBOL s_lsp_SET_2DGETHASH; 
MAKE_SIMPLE_STRING(k11101,1,"k");
extern SYMBOL s_lsp_GENSTRING; 
extern SYMBOL s_lsp_EMIT_2DVECTOR; 
extern SYMBOL s_lsp_ARRAYP; 
extern SYMBOL s_lsp_EMIT_2DMULTI_2DARRAY; 
extern SYMBOL s_lsp_INNER_2DPROC_2DP; 
extern SYMBOL s_lsp_EMIT_2DNULL_2DOE_2DPROC; 
extern SYMBOL s_lsp_FOREIGN_2DSYMBOL_2DP; 
extern SYMBOL s_lsp_EMIT_2DFOREIGN_2DSYMBOL; 
extern SYMBOL s_lsp_EMIT_2DCONS; 
extern SYMBOL s_lsp_EMIT_2DFLOAT; 
extern SYMBOL s_lsp_EMIT_2DRATIO; 
extern SYMBOL s_lsp_EMIT_2DCOMPLEX; 
extern SYMBOL s_lsp_COMPILED_2DFUNCTION_2DP; 
extern SYMBOL s_lsp_EMIT_2DCOMPILED_2DFUNCTION; 
extern SYMBOL s_lsp_EMIT_2DSTRUCTURE; 
extern SYMBOL s_lsp_EMIT_2DBIGNUM; 
MAKE_SIMPLE_STRING(k11102,36,"~S is not one of these types:~{ ~A~}");
extern SYMBOL s_lsp_VECTOR; 
extern SYMBOL s_lsp_ARRAY; 
extern SYMBOL s_lsp_INNER_2DPROC; 
extern SYMBOL s_lsp_FOREIGN_2DSYMBOL; 
extern SYMBOL s_lsp_CONS; 
extern SYMBOL s_lsp_FLOAT; 
extern SYMBOL s_lsp_RATIO; 
extern SYMBOL s_lsp_COMPLEX; 
extern SYMBOL s_lsp_COMPILED_2DFUNCTION; 
extern SYMBOL s_lsp_STRUCTURE; 
extern SYMBOL s_lsp_INTEGER; 
MAKE_CONS(k11113,LREF(s_lsp_INTEGER),LREF(s_lsp_NIL));
MAKE_CONS(k11112,LREF(s_lsp_STRUCTURE),LREF(k11113));
MAKE_CONS(k11111,LREF(s_lsp_COMPILED_2DFUNCTION),LREF(k11112));
MAKE_CONS(k11110,LREF(s_lsp_COMPLEX),LREF(k11111));
MAKE_CONS(k11109,LREF(s_lsp_RATIO),LREF(k11110));
MAKE_CONS(k11108,LREF(s_lsp_FLOAT),LREF(k11109));
MAKE_CONS(k11107,LREF(s_lsp_CONS),LREF(k11108));
MAKE_CONS(k11106,LREF(s_lsp_FOREIGN_2DSYMBOL),LREF(k11107));
MAKE_CONS(k11105,LREF(s_lsp_INNER_2DPROC),LREF(k11106));
MAKE_CONS(k11104,LREF(s_lsp_ARRAY),LREF(k11105));
MAKE_CONS(k11103,LREF(s_lsp_VECTOR),LREF(k11104));
extern SYMBOL s_lsp_ERROR; 
extern LP p_lsp_EMIT_2DLREF();
MAKE_SIMPLE_STRING(k11114,7,"(LP) ~D");
extern SYMBOL s_lsp_ASH; 
MAKE_SIMPLE_STRING(k11115,8,"LREF(~A)");
extern SYMBOL s_lsp_EMIT_2DDATA; 
extern LP p_lsp_EMIT_2DFOREIGN_2DSYMBOL();
MAKE_SIMPLE_STRING(k11116,3,"fix");
extern LP p_lsp_EMIT_2DFLOAT();
MAKE_SIMPLE_STRING(k11117,20,"MAKE_FLOAT(~A,~F);~%");
extern LP p_lsp_EMIT_2DRATIO();
extern SYMBOL s_lsp_NUMERATOR; 
extern SYMBOL s_lsp_EMIT_2DLREF; 
extern SYMBOL s_lsp_DENOMINATOR; 
MAKE_SIMPLE_STRING(k11118,23,"MAKE_RATIO(~A,~A,~A);~%");
extern LP p_lsp_EMIT_2DCOMPLEX();
extern SYMBOL s_lsp_REALPART; 
extern SYMBOL s_lsp_IMAGPART; 
MAKE_SIMPLE_STRING(k11119,25,"MAKE_COMPLEX(~A,~A,~A);~%");
extern LP p_lsp_EMIT_2DCONS();
MAKE_SIMPLE_STRING(k11120,22,"MAKE_CONS(~A,~A,~A);~%");
extern LP p_lsp_EMIT_2DNULL_2DOE_2DPROC();
MAKE_SIMPLE_STRING(k11121,24,"MAKE_PROCEDURE(~A,~A);~%");
extern LP p_lsp_EMIT_2DVECTOR();
extern SYMBOL s_lsp_EMIT_2DSIMPLE_2DSTRING; 
extern SYMBOL s_lsp_EMIT_2DSIMPLE_2D1D_2DARRAY; 
extern SYMBOL s_lsp_EMIT_2DCOMPLEX_2D1D_2DARRAY; 
extern LP p_lsp_EMIT_2DMULTI_2DARRAY();
extern SYMBOL s_lsp_EMIT_2DSIMPLE_2DMULTI_2DARRAY; 
extern SYMBOL s_lsp_EMIT_2DCOMPLEX_2DMULTI_2DARRAY; 
extern LP p_lsp_EMIT_2DSTRING_2DUSING_2DC_2DSYNTAX();
extern SYMBOL s_lsp_WRITE_2DCHAR_2F2; 
extern SYMBOL s_lsp_LENGTH; 
MAKE_SIMPLE_STRING(k11122,2,"\\n");
extern SYMBOL s_lsp_WRITE_2DSTRING_2F4; 
MAKE_SIMPLE_STRING(k11123,2,"\\\\");
MAKE_SIMPLE_STRING(k11124,2,"\\\"");
extern LP p_lsp_EMIT_2DSIMPLE_2DSTRING();
MAKE_SIMPLE_STRING(k11125,25,"MAKE_SIMPLE_STRING(~A,~D,");
extern SYMBOL s_lsp_EMIT_2DSTRING_2DUSING_2DC_2DSYNTAX; 
MAKE_SIMPLE_STRING(k11126,4,");~%");
MAKE_SIMPLE_STRING(k11127,58,"static struct {unsigned long header; char string[~D+1];}~%");
MAKE_SIMPLE_STRING(k11128,43,"~A  = {((~D << 8) + TYPE_SIMPLE_STRING), ~%");
MAKE_SIMPLE_STRING(k11129,4,"};~%");
extern LP p_lsp_EMIT_2DSIMPLE_2D1D_2DARRAY();
extern SYMBOL s_lsp_ARRAY_2DELEMENT_2DTYPE; 
extern SYMBOL s_lsp_TYPE_2D_3EELEMENT_2DTYPE_2DTAG; 
extern SYMBOL s_lsp_BIT_2DVECTOR_2D_3EWORD_2DLIST; 
extern SYMBOL s_lsp_ELT; 
MAKE_SIMPLE_STRING(k11131,13,"unsigned long");
MAKE_SIMPLE_STRING(k11132,13,"unsigned char");
MAKE_SIMPLE_STRING(k11133,14,"unsigned short");
MAKE_SIMPLE_STRING(k11134,2,"LP");
MAKE_SIMPLE_STRING(k11135,14,"unsiged double");
MAKE_SIMPLE_STRING(k11136,54,"static struct {unsigned long header; ~A cells[~D];} ~%");
MAKE_SIMPLE_STRING(k11137,15,"~A = {0x~X, ~%{");
MAKE_SIMPLE_STRING(k11138,3," 0 ");
MAKE_SIMPLE_STRING(k11139,1,",");
MAKE_SIMPLE_STRING(k11140,8,"((~A)~A)");
MAKE_SIMPLE_STRING(k11141,5,"}};~%");
extern LP p_lsp_BIT_2DVECTOR_2D_3EWORD_2DLIST();
extern SYMBOL s_key_DISPLACED_2DTO; 
extern SYMBOL s_key_ELEMENT_2DTYPE; 
extern SYMBOL s_lsp_UNSIGNED_2DBYTE; 
MAKE_CONS(k11143,(LP) 64,LREF(s_lsp_NIL));
MAKE_CONS(k11142,LREF(s_lsp_UNSIGNED_2DBYTE),LREF(k11143));
extern SYMBOL s_lsp_MAKE_2DARRAY; 
extern LP p_lsp_EMIT_2DCOMPLEX_2D1D_2DARRAY();
MAKE_SIMPLE_STRING(k11144,30,"write complex-1d array emitter");
extern LP p_lsp_EMIT_2DCOMPLEX_2DMULTI_2DARRAY();
MAKE_SIMPLE_STRING(k11145,33,"write complex multi-array emitter");
extern LP p_lsp_EMIT_2DSIMPLE_2DMULTI_2DARRAY();
MAKE_SIMPLE_STRING(k11146,31,"static SIMPLE_MULTI_ARRAY ~A = ");
MAKE_SIMPLE_STRING(k11147,21,"{0x~X, ~A, ~A, ~A};~%");
extern LP p_lsp_EMIT_2DCOMPILED_2DFUNCTION();
extern SYMBOL s_lsp_COMPILED_2DFUNCTION_2DNAME; 
extern SYMBOL s_lsp_LISP_2D_3EC_2DPROC_2DNAME; 
MAKE_SIMPLE_STRING(k11148,19,"~%extern LP ~A();~%");
extern LP p_lsp_EMIT_2DSTRUCTURE();
extern SYMBOL s_lsp_TYPE_2DOF; 
extern SYMBOL s_lsp_LOOKUP_2DSTRUCTURE_2DINFO; 
extern SYMBOL s_lsp_REF_2DSTRUCTURE_2DAS_2DVECTOR; 
MAKE_SIMPLE_STRING(k11149,45,"static struct {unsigned long header; LP type;");
MAKE_SIMPLE_STRING(k11150,17,"LP cells[~D];} ~%");
MAKE_SIMPLE_STRING(k11151,42,"~A = {((~D << 8) + TYPE_STRUCTURE), ~A,~%{");
MAKE_SIMPLE_STRING(k11152,2,"~A");
MAKE_SIMPLE_STRING(k11153,30,"No structure info found for ~A");
extern LP p_lsp_WCL_2DFIXNUM_3F();
extern LP p_lsp_EMIT_2DBIGNUM();
extern SYMBOL s_lsp_ABS; 
extern SYMBOL s_lsp__2APRINT_2DBASE_2A; 
extern SYMBOL s_lsp_WRITE_2DTO_2DSTRING_2D1; 
extern SYMBOL s_lsp_CEILING; 
static struct {unsigned long header; char string[116+1];}
k11154  = {((116 << 8) + TYPE_SIMPLE_STRING), 
"static struct {unsigned long header; unsigned long len; ~\n                     int sign; unsigned long digits[~D];} "};
MAKE_SIMPLE_STRING(k11155,23,"~A = ~%{0x~X, ~D, ~D, {");
extern SYMBOL s_lsp_T; 
MAKE_SIMPLE_STRING(k11156,6,"0x~X~A");
extern SYMBOL s_lsp_MAX; 
extern SYMBOL s_lsp_SUBSEQ_2D1; 
MAKE_SIMPLE_STRING(k11157,0,"");


extern LP greaterp();
extern LP multiply();
extern LP subtract();
extern LP divide();
extern int object_size();
extern LP add();
extern LP c_cons();
extern LP num_equal_p();
extern LP lessp();
extern LP vref();


LP p_lsp_EMIT_2DDATA(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{
LP v_X_57; LP v_X_55; LP v_X_53; 
LP v_X_51; LP v_X_49; LP v_X_47; 
LP v_X_45; LP v_X_43; LP v_X_41; 
LP v_X_39; LP v_G6855_38; LP v_X_36; 
LP v_X_34; LP v_KEY6854_33; LP v_KEY6853_32; 
LP v_T6852_31; LP v_SYMBOL_29; LP v_T6851_28; 
LP v_S6850_27; LP v_LABEL_26; LP v_X_24; 
LP v_T6849_23; LP v_SYMBOL_21; LP v_T6848_20; 
LP v_S6847_19; LP v_SYMBOL_17; LP v_SYMBOL_15; 
LP v_SYMBOL_13; LP v_SYMBOL_11; LP v_LABEL_10; 
LP v_KEY6846_8; LP v_LABEL_6; LP v_SYMBOL_4; 
LP v_C_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; 
if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_WCL_2DFIXNUM_3F) (1, v_X_0);
if (t1 != NIL) {
return(LREF(s_lsp_NIL));
} else {
v_X_57 = v_X_0;
if (OTHER_PTRP((v_X_0)) && (TAG((v_X_0)) == 7)) {
v_C_2 = v_X_0;
t3 = INT_TO_FX(((int) RAW_CHAR(v_X_0)));
t0 = ICALL(s_lsp_FORMAT) (MV_CALL(argc,3), LREF(s_lsp_NIL), LREF(k11098), t3);
return(t0);
} else {
v_SYMBOL_4 = LREF(s_lsp__2ACONST_2DLABELS_2A);
t4 = ((LP) DEREF((LREF(s_lsp__2ACONST_2DLABELS_2A)) + 0 * 4));
v_LABEL_6 = ICALL(s_lsp_GETHASH) (2, v_X_0, t4);
if (v_LABEL_6 != NIL) {
return(v_LABEL_6);
} else {
v_KEY6846_8 = v_X_0;
v_X_24 = v_KEY6846_8;
if (FIXNUMP((v_KEY6846_8))) {
goto t_DEFAULT_2DTAG6845_9;
} else {
t7 = INT_TO_FX(((int) TAG((v_KEY6846_8))));
switch ((int) t7) {
case 6:
case 22:
v_LABEL_10 = ICALL(s_lsp_LISP_2D_3EC_2DSYMBOL_2DNAME) (1, v_X_0);
v_SYMBOL_15 = LREF(s_lsp__2AEMIT_2DSYMBOL_2DDATA_2DFUNCTION_2A);
t8 = ((LP) DEREF((LREF(s_lsp__2AEMIT_2DSYMBOL_2DDATA_2DFUNCTION_2A)) + 0 * 4));
if (t8 != NIL) {
v_SYMBOL_13 = LREF(s_lsp__2AEMIT_2DSYMBOL_2DDATA_2DFUNCTION_2A);
t9 = ((LP) DEREF((LREF(s_lsp__2AEMIT_2DSYMBOL_2DDATA_2DFUNCTION_2A)) + 0 * 4));
CODE_PTR(COERCE_TO_FUNCTION(t9))(1, v_X_0);
} else {
v_SYMBOL_11 = LREF(s_lsp__2AWIN_2DSTREAM_2A);
t10 = ((LP) DEREF((LREF(s_lsp__2AWIN_2DSTREAM_2A)) + 0 * 4));
ICALL(s_lsp_FORMAT) (3, t10, LREF(k11099), v_X_0);
}
v_SYMBOL_17 = LREF(s_lsp__2AK_2DSTREAM_2A);
t11 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
ICALL(s_lsp_FORMAT) (3, t11, LREF(k11100), v_LABEL_10);
v_S6847_19 = v_LABEL_10;
v_T6848_20 = v_X_0;
v_SYMBOL_21 = LREF(s_lsp__2ACONST_2DLABELS_2A);
v_T6849_23 = ((LP) DEREF((LREF(s_lsp__2ACONST_2DLABELS_2A)) + 0 * 4));
t5 = ICALL(s_lsp_SET_2DGETHASH) (MV_CALL(argc,3), v_X_0, v_T6849_23, v_LABEL_10);
return(t5);
break;
default:
goto t_DEFAULT_2DTAG6845_9;
break;
}
}
return(t5);
t_DEFAULT_2DTAG6845_9:;
v_LABEL_26 = ICALL(s_lsp_GENSTRING) (1, LREF(k11101));
v_S6850_27 = v_LABEL_26;
v_T6851_28 = v_X_0;
v_SYMBOL_29 = LREF(s_lsp__2ACONST_2DLABELS_2A);
v_T6852_31 = ((LP) DEREF((LREF(s_lsp__2ACONST_2DLABELS_2A)) + 0 * 4));
ICALL(s_lsp_SET_2DGETHASH) (3, v_X_0, v_T6852_31, v_LABEL_26);
v_KEY6853_32 = v_X_0;
v_KEY6854_33 = v_KEY6853_32;
v_X_53 = v_KEY6854_33;
v_X_55 = v_KEY6854_33;
if (OTHER_PTRP((v_KEY6854_33)) && ((HEADER((v_KEY6854_33)) & 3) == 0)) {
ICALL(s_lsp_EMIT_2DVECTOR) (2, v_LABEL_26, v_X_0);
} else {
v_X_51 = v_KEY6854_33;
t13 = ICALL(s_lsp_ARRAYP) (1, v_KEY6854_33);
if (t13 != NIL) {
ICALL(s_lsp_EMIT_2DMULTI_2DARRAY) (2, v_LABEL_26, v_X_0);
} else {
t14 = ICALL(s_lsp_INNER_2DPROC_2DP) (1, v_KEY6854_33);
if (t14 != NIL) {
ICALL(s_lsp_EMIT_2DNULL_2DOE_2DPROC) (2, v_LABEL_26, v_X_0);
} else {
t15 = ICALL(s_lsp_FOREIGN_2DSYMBOL_2DP) (1, v_KEY6854_33);
if (t15 != NIL) {
ICALL(s_lsp_EMIT_2DFOREIGN_2DSYMBOL) (1, v_X_0);
} else {
v_X_49 = v_KEY6854_33;
if (OTHER_PTRP((v_KEY6854_33)) && (TAG((v_KEY6854_33)) == 15)) {
ICALL(s_lsp_EMIT_2DCONS) (2, v_LABEL_26, v_X_0);
} else {
v_X_47 = v_KEY6854_33;
if (OTHER_PTRP((v_KEY6854_33)) && (TAG((v_KEY6854_33)) == 5)) {
ICALL(s_lsp_EMIT_2DFLOAT) (2, v_LABEL_26, v_X_0);
} else {
v_X_45 = v_KEY6854_33;
if (OTHER_PTRP((v_KEY6854_33)) && (TAG((v_KEY6854_33)) == 9)) {
ICALL(s_lsp_EMIT_2DRATIO) (2, v_LABEL_26, v_X_0);
} else {
v_X_43 = v_KEY6854_33;
if (OTHER_PTRP((v_KEY6854_33)) && (TAG((v_KEY6854_33)) == 13)) {
ICALL(s_lsp_EMIT_2DCOMPLEX) (2, v_LABEL_26, v_X_0);
} else {
t20 = ICALL(s_lsp_COMPILED_2DFUNCTION_2DP) (1, v_KEY6854_33);
if (t20 != NIL) {
ICALL(s_lsp_EMIT_2DCOMPILED_2DFUNCTION) (2, v_LABEL_26, v_X_0);
} else {
v_X_41 = v_KEY6854_33;
if (OTHER_PTRP((v_KEY6854_33)) && (TAG((v_KEY6854_33)) == 47)) {
ICALL(s_lsp_EMIT_2DSTRUCTURE) (2, v_LABEL_26, v_X_0);
} else {
v_X_34 = v_KEY6854_33;
v_X_36 = v_X_34;
v_G6855_38 = (FIXNUMP((v_X_34)) ? T : NIL);
if (v_G6855_38 != NIL) {
t22 = v_G6855_38;
} else {
v_X_39 = v_X_34;
t22 = (OTHER_PTRP((v_X_34)) && (TAG((v_X_34)) == 1) ? T : NIL);
}
if (t22 != NIL) {
ICALL(s_lsp_EMIT_2DBIGNUM) (2, v_LABEL_26, v_X_0);
} else {
ICALL(s_lsp_ERROR) (3, LREF(k11102), v_KEY6853_32, LREF(k11103));
}
}
}
}
}
}
}
}
}
}
}
return(v_LABEL_26);
return(NIL);
return(NIL);
}
}
}
}

LP p_lsp_EMIT_2DLREF(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_WCL_2DFIXNUM_3F) (1, v_X_0);
if (t1 != NIL) {
t2 = ICALL(s_lsp_ASH) (2, v_X_0, (LP) 2);
t0 = ICALL(s_lsp_FORMAT) (MV_CALL(argc,3), LREF(s_lsp_NIL), LREF(k11114), t2);
return(t0);
} else {
t3 = ICALL(s_lsp_EMIT_2DDATA) (1, v_X_0);
t0 = ICALL(s_lsp_FORMAT) (MV_CALL(argc,3), LREF(s_lsp_NIL), LREF(k11115), t3);
return(t0);
}
}

LP p_lsp_EMIT_2DFOREIGN_2DSYMBOL(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; LP t1; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,1), LREF(k11116));
return(t0);
}

LP p_lsp_EMIT_2DFLOAT(argc, v_LABEL_0, v_X_1)
      ARGC argc;  LP v_LABEL_0; LP v_X_1;
{
LP v_SYMBOL_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
if (argc != 2) wna(argc,2);
v_SYMBOL_3 = LREF(s_lsp__2AK_2DSTREAM_2A);
t1 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
t0 = ICALL(s_lsp_FORMAT) (MV_CALL(argc,4), t1, LREF(k11117), v_LABEL_0, v_X_1);
return(t0);
}

LP p_lsp_EMIT_2DRATIO(argc, v_LABEL_0, v_X_1)
      ARGC argc;  LP v_LABEL_0; LP v_X_1;
{
LP v_SYMBOL_5; LP v_DENOMINATOR_4; LP v_NUMERATOR_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_NUMERATOR) (1, v_X_1);
v_NUMERATOR_3 = ICALL(s_lsp_EMIT_2DLREF) (1, t0);
t1 = ICALL(s_lsp_DENOMINATOR) (1, v_X_1);
v_DENOMINATOR_4 = ICALL(s_lsp_EMIT_2DLREF) (1, t1);
v_SYMBOL_5 = LREF(s_lsp__2AK_2DSTREAM_2A);
t3 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
t2 = ICALL(s_lsp_FORMAT) (MV_CALL(argc,5), t3, LREF(k11118), v_LABEL_0, v_NUMERATOR_3, v_DENOMINATOR_4);
return(t2);
}

LP p_lsp_EMIT_2DCOMPLEX(argc, v_LABEL_0, v_X_1)
      ARGC argc;  LP v_LABEL_0; LP v_X_1;
{
LP v_SYMBOL_5; LP v_IMAG_4; LP v_REAL_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_REALPART) (1, v_X_1);
v_REAL_3 = ICALL(s_lsp_EMIT_2DLREF) (1, t0);
t1 = ICALL(s_lsp_IMAGPART) (1, v_X_1);
v_IMAG_4 = ICALL(s_lsp_EMIT_2DLREF) (1, t1);
v_SYMBOL_5 = LREF(s_lsp__2AK_2DSTREAM_2A);
t3 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
t2 = ICALL(s_lsp_FORMAT) (MV_CALL(argc,5), t3, LREF(k11119), v_LABEL_0, v_REAL_3, v_IMAG_4);
return(t2);
}

LP p_lsp_EMIT_2DCONS(argc, v_LABEL_0, v_X_1)
      ARGC argc;  LP v_LABEL_0; LP v_X_1;
{
LP v_SYMBOL_9; LP v_CDR_8; LP v_CAR_7; 
LP v_X_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; 
if (argc != 2) wna(argc,2);
v_X_3 = v_X_1;
t0 = ((LP) DEREF((v_X_1) + 0 * 4));
v_CAR_7 = ICALL(s_lsp_EMIT_2DLREF) (1, t0);
v_X_5 = v_X_1;
t1 = ((LP) DEREF((v_X_1) + 1 * 4));
v_CDR_8 = ICALL(s_lsp_EMIT_2DLREF) (1, t1);
v_SYMBOL_9 = LREF(s_lsp__2AK_2DSTREAM_2A);
t3 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
t2 = ICALL(s_lsp_FORMAT) (MV_CALL(argc,5), t3, LREF(k11120), v_LABEL_0, v_CAR_7, v_CDR_8);
return(t2);
}

LP p_lsp_EMIT_2DNULL_2DOE_2DPROC(argc, v_LABEL_0, v_X_1)
      ARGC argc;  LP v_LABEL_0; LP v_X_1;
{
LP v_I_8; LP v_S_7; LP v_S_5; 
LP v_SYMBOL_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; 
if (argc != 2) wna(argc,2);
v_SYMBOL_3 = LREF(s_lsp__2AK_2DSTREAM_2A);
t1 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
v_S_5 = v_X_1;
v_S_7 = v_X_1;
v_I_8 = (LP) 18;
t2 = ((LP) DEREF((v_X_1) + 9 * 4));
t0 = ICALL(s_lsp_FORMAT) (MV_CALL(argc,4), t1, LREF(k11121), v_LABEL_0, t2);
return(t0);
}

LP p_lsp_EMIT_2DVECTOR(argc, v_LABEL_0, v_X_1)
      ARGC argc;  LP v_LABEL_0; LP v_X_1;
{
LP v_X_5; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; 
if (argc != 2) wna(argc,2);
v_X_5 = v_X_1;
if (OTHER_PTRP((v_X_1)) && (TAG((v_X_1)) == 24)) {
t0 = ICALL(s_lsp_EMIT_2DSIMPLE_2DSTRING) (MV_CALL(argc,2), v_LABEL_0, v_X_1);
return(t0);
} else {
v_X_3 = v_X_1;
if (OTHER_PTRP((v_X_1)) && ((HEADER((v_X_1)) & 5) == 0)) {
t0 = ICALL(s_lsp_EMIT_2DSIMPLE_2D1D_2DARRAY) (MV_CALL(argc,2), v_LABEL_0, v_X_1);
return(t0);
} else {
t0 = ICALL(s_lsp_EMIT_2DCOMPLEX_2D1D_2DARRAY) (MV_CALL(argc,2), v_LABEL_0, v_X_1);
return(t0);
}
}
}

LP p_lsp_EMIT_2DMULTI_2DARRAY(argc, v_LABEL_0, v_X_1)
      ARGC argc;  LP v_LABEL_0; LP v_X_1;
{
LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 2) wna(argc,2);
v_X_3 = v_X_1;
if (OTHER_PTRP((v_X_1)) && ((HEADER((v_X_1)) & 5) == 0)) {
t0 = ICALL(s_lsp_EMIT_2DSIMPLE_2DMULTI_2DARRAY) (MV_CALL(argc,2), v_LABEL_0, v_X_1);
return(t0);
} else {
t0 = ICALL(s_lsp_EMIT_2DCOMPLEX_2DMULTI_2DARRAY) (MV_CALL(argc,2), v_LABEL_0, v_X_1);
return(t0);
}
}

LP p_lsp_EMIT_2DSTRING_2DUSING_2DC_2DSYNTAX(argc, v_STRING_0)
      ARGC argc;  LP v_STRING_0;
{
LP v_STREAM_83; LP v_CHAR_82; LP v_SYMBOL_80; 
LP v_CHAR_76; LP v_SYMBOL_78; LP v_STREAM_77; 
LP v_Y_74; LP v_X_73; LP v_Y_71; 
LP v_X_70; LP v_Y_68; LP v_X_67; 
LP v_STREAM_65; LP v_CHAR_64; LP v_SYMBOL_62; 
LP v_CHAR_58; LP v_SYMBOL_60; LP v_STREAM_59; 
LP v_END_56; LP v_START_55; LP v_STREAM_54; 
LP v_STRING_53; LP v_SYMBOL_51; LP v_STRING_45; 
LP v_END_50; LP v_START_49; LP v_SYMBOL_47; 
LP v_STREAM_46; LP v_END_43; LP v_START_42; 
LP v_STREAM_41; LP v_STRING_40; LP v_SYMBOL_38; 
LP v_STRING_32; LP v_END_37; LP v_START_36; 
LP v_SYMBOL_34; LP v_STREAM_33; LP v_END_30; 
LP v_START_29; LP v_STREAM_28; LP v_STRING_27; 
LP v_SYMBOL_25; LP v_STRING_19; LP v_END_24; 
LP v_START_23; LP v_SYMBOL_21; LP v_STREAM_20; 
LP v_KEY6856_18; LP v_LOOP_2DSEQ_2DLIMIT_2D1489_14; LP v_LOOPVAR_2D1487_13; 
LP v_LOOPVAR_2D1488_12; LP v_C_11; LP v_STREAM_9; 
LP v_CHAR_8; LP v_SYMBOL_6; LP v_CHAR_2; 
LP v_SYMBOL_4; LP v_STREAM_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; 
if (argc != 1) wna(argc,1);
v_SYMBOL_6 = LREF(s_lsp__2AK_2DSTREAM_2A);
v_STREAM_9 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
ICALL(s_lsp_WRITE_2DCHAR_2F2) (2, LREF(char_tab[34]), v_STREAM_9);
v_C_11 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1488_12 = v_STRING_0;
v_LOOPVAR_2D1487_13 = (LP) 0;
v_LOOP_2DSEQ_2DLIMIT_2D1489_14 = (LP) 0;
v_LOOP_2DSEQ_2DLIMIT_2D1489_14 = ICALL(s_lsp_LENGTH) (1, v_LOOPVAR_2D1488_12);
t_NEXT_2DLOOP_16:;
if (((int) (v_LOOPVAR_2D1487_13) >= (int) (v_LOOP_2DSEQ_2DLIMIT_2D1489_14))) {
goto t_END_2DLOOP_17;
}
v_C_11 = (vref((v_LOOPVAR_2D1488_12), (v_LOOPVAR_2D1487_13)));
v_KEY6856_18 = v_C_11;
v_X_73 = v_KEY6856_18;
v_Y_74 = LREF(char_tab[10]);
if (((int) (v_KEY6856_18) == (int) (LREF(char_tab[10])))) {
v_SYMBOL_25 = LREF(s_lsp__2AK_2DSTREAM_2A);
v_STREAM_28 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
ICALL(s_lsp_WRITE_2DSTRING_2F4) (4, LREF(k11122), v_STREAM_28, LREF(s_lsp_NIL), LREF(s_lsp_NIL));
} else {
v_X_70 = v_KEY6856_18;
v_Y_71 = LREF(char_tab[92]);
if (((int) (v_KEY6856_18) == (int) (LREF(char_tab[92])))) {
v_SYMBOL_38 = LREF(s_lsp__2AK_2DSTREAM_2A);
v_STREAM_41 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
ICALL(s_lsp_WRITE_2DSTRING_2F4) (4, LREF(k11123), v_STREAM_41, LREF(s_lsp_NIL), LREF(s_lsp_NIL));
} else {
v_X_67 = v_KEY6856_18;
v_Y_68 = LREF(char_tab[34]);
if (((int) (v_KEY6856_18) == (int) (LREF(char_tab[34])))) {
v_SYMBOL_51 = LREF(s_lsp__2AK_2DSTREAM_2A);
v_STREAM_54 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
ICALL(s_lsp_WRITE_2DSTRING_2F4) (4, LREF(k11124), v_STREAM_54, LREF(s_lsp_NIL), LREF(s_lsp_NIL));
} else {
v_CHAR_64 = v_C_11;
v_SYMBOL_62 = LREF(s_lsp__2AK_2DSTREAM_2A);
v_STREAM_65 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
ICALL(s_lsp_WRITE_2DCHAR_2F2) (2, v_CHAR_64, v_STREAM_65);
}
}
}
v_LOOPVAR_2D1487_13 = (((LP) ((int) (v_LOOPVAR_2D1487_13) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_16;
goto t_END_2DLOOP_17;
t_END_2DLOOP_17:;
v_SYMBOL_80 = LREF(s_lsp__2AK_2DSTREAM_2A);
v_STREAM_83 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
t4 = ICALL(s_lsp_WRITE_2DCHAR_2F2) (MV_CALL(argc,2), LREF(char_tab[34]), v_STREAM_83);
return(t4);
}

LP p_lsp_EMIT_2DSIMPLE_2DSTRING(argc, v_LABEL_0, v_X_1)
      ARGC argc;  LP v_LABEL_0; LP v_X_1;
{
LP v_SYMBOL_12; LP v_SYMBOL_10; LP v_SYMBOL_8; 
LP v_SYMBOL_6; LP v_SYMBOL_4; LP v_LEN_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; 
if (argc != 2) wna(argc,2);
v_LEN_3 = ICALL(s_lsp_LENGTH) (1, v_X_1);
t1 = (lessp((v_LEN_3), ((LP) 160)));
if (t1 != NIL) {
v_SYMBOL_4 = LREF(s_lsp__2AK_2DSTREAM_2A);
t2 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
ICALL(s_lsp_FORMAT) (4, t2, LREF(k11125), v_LABEL_0, v_LEN_3);
ICALL(s_lsp_EMIT_2DSTRING_2DUSING_2DC_2DSYNTAX) (1, v_X_1);
v_SYMBOL_6 = LREF(s_lsp__2AK_2DSTREAM_2A);
t3 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
t0 = ICALL(s_lsp_FORMAT) (MV_CALL(argc,2), t3, LREF(k11126));
return(t0);
} else {
v_SYMBOL_8 = LREF(s_lsp__2AK_2DSTREAM_2A);
t4 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
ICALL(s_lsp_FORMAT) (3, t4, LREF(k11127), v_LEN_3);
v_SYMBOL_10 = LREF(s_lsp__2AK_2DSTREAM_2A);
t5 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
ICALL(s_lsp_FORMAT) (4, t5, LREF(k11128), v_LABEL_0, v_LEN_3);
ICALL(s_lsp_EMIT_2DSTRING_2DUSING_2DC_2DSYNTAX) (1, v_X_1);
v_SYMBOL_12 = LREF(s_lsp__2AK_2DSTREAM_2A);
t6 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
t0 = ICALL(s_lsp_FORMAT) (MV_CALL(argc,2), t6, LREF(k11129));
return(t0);
}
}

LP p_lsp_EMIT_2DSIMPLE_2D1D_2DARRAY(argc, v_LABEL_0, v_X_1)
      ARGC argc;  LP v_LABEL_0; LP v_X_1;
{
LP v_SYMBOL_67; LP v_X_65; LP v_X_63; 
LP v_SYMBOL_61; LP v_Y_59; LP v_X_58; 
LP v_SYMBOL_56; LP v_REST_52; LP v_SYMBOL_50; 
LP v_SYMBOL_48; LP v_SYMBOL_46; LP v_C_2DTYPE_45; 
LP v_Y_43; LP v_X_42; LP v_Y_40; 
LP v_X_39; LP v_Y_37; LP v_X_36; 
LP v_Y_34; LP v_X_33; LP v_Y_31; 
LP v_X_30; LP v_KEY6857_29; LP v_OBJECT_2DLEN_28; 
LP v_OBJECTS_27; LP v_X_25; LP v_V_23; 
LP v_X_22; LP v_NEW_2DCDR_20; LP v_C_19; 
LP v_Y_17; LP v_X_16; LP v_LOOPVAR_2D1495_12; 
LP v_LOOPVAR_2D1494_11; LP v_LOOPVAR_2D1493_10; LP v_LOOP_2DSEQ_2DLIMIT_2D1492_9; 
LP v_LOOPVAR_2D1490_8; LP v_LOOPVAR_2D1491_7; LP v_E_6; 
LP v_DEFAULT_2DINITIAL_2DVALUE_5; LP v_ELEMENT_2DSIZE_4; LP v_ELEMENT_2DTYPE_2DTAG_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; 
if (argc != 2) wna(argc,2);
{
int real_argc;
BEGIN_MV_CALL(mv_holder11130,0);
t1 = ICALL(s_lsp_ARRAY_2DELEMENT_2DTYPE) (1, v_X_1);
t0 = ICALL(s_lsp_TYPE_2D_3EELEMENT_2DTYPE_2DTAG) (MV_CALL(mv_holder11130,1), t1);
SET_MV_RETURN_VALUE(mv_holder11130,0,t0);
if SV_RETURN_P(mv_holder11130) SET_MV_RETURN_COUNT(mv_holder11130,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder11130);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_ELEMENT_2DTYPE_2DTAG_3 = NIL;
} else {
v_ELEMENT_2DTYPE_2DTAG_3 = NEXT_VAR_VALUE(mv_holder11130);
}
if (real_argc < 2) {
v_ELEMENT_2DSIZE_4 = NIL;
} else {
v_ELEMENT_2DSIZE_4 = NEXT_VAR_VALUE(mv_holder11130);
}
if (real_argc < 3) {
v_DEFAULT_2DINITIAL_2DVALUE_5 = NIL;
} else {
v_DEFAULT_2DINITIAL_2DVALUE_5 = NEXT_VAR_VALUE(mv_holder11130);
}
END_VAR_VALUES;
END_MV_CALL;
t2 = (num_equal_p((v_ELEMENT_2DTYPE_2DTAG_3), ((LP) 0)));
if (t2 != NIL) {
v_OBJECTS_27 = ICALL(s_lsp_BIT_2DVECTOR_2D_3EWORD_2DLIST) (1, v_X_1);
} else {
v_E_6 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1491_7 = v_X_1;
v_LOOPVAR_2D1490_8 = (LP) 0;
v_LOOP_2DSEQ_2DLIMIT_2D1492_9 = (LP) 0;
v_LOOPVAR_2D1493_10 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1494_11 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1495_12 = LREF(s_lsp_NIL);
v_LOOP_2DSEQ_2DLIMIT_2D1492_9 = ICALL(s_lsp_LENGTH) (1, v_LOOPVAR_2D1491_7);
t_NEXT_2DLOOP_14:;
if (((int) (v_LOOPVAR_2D1490_8) >= (int) (v_LOOP_2DSEQ_2DLIMIT_2D1492_9))) {
goto t_END_2DLOOP_15;
}
v_E_6 = ICALL(s_lsp_ELT) (2, v_LOOPVAR_2D1491_7, v_LOOPVAR_2D1490_8);
t4 = (num_equal_p((v_ELEMENT_2DTYPE_2DTAG_3), ((LP) 128)));
if (t4 != NIL) {
v_X_16 = ICALL(s_lsp_EMIT_2DLREF) (1, v_E_6);
} else {
v_X_16 = v_E_6;
}
v_LOOPVAR_2D1495_12 = (c_cons((v_X_16), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D1494_11 != NIL) {
v_C_19 = v_LOOPVAR_2D1494_11;
v_NEW_2DCDR_20 = v_LOOPVAR_2D1495_12;
v_V_23 = v_NEW_2DCDR_20;
((LP) (DEREF((v_C_19) + 1 * 4) = (LD) (v_V_23)));
v_X_25 = v_C_19;
v_LOOPVAR_2D1494_11 = ((LP) DEREF((v_X_25) + 1 * 4));
} else {
v_LOOPVAR_2D1493_10 = v_LOOPVAR_2D1495_12;
v_LOOPVAR_2D1494_11 = v_LOOPVAR_2D1493_10;
}
v_LOOPVAR_2D1490_8 = (((LP) ((int) (v_LOOPVAR_2D1490_8) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_14;
goto t_END_2DLOOP_15;
t_END_2DLOOP_15:;
v_OBJECTS_27 = v_LOOPVAR_2D1493_10;
goto b_NIL_13;
v_OBJECTS_27 = NIL;
v_OBJECTS_27 = v_OBJECTS_27;
b_NIL_13:;
}
v_OBJECT_2DLEN_28 = ICALL(s_lsp_LENGTH) (1, v_OBJECTS_27);
v_KEY6857_29 = v_ELEMENT_2DSIZE_4;
v_X_42 = v_KEY6857_29;
v_Y_43 = (LP) 2;
if (((int) (v_KEY6857_29) == (int) ((LP) 2))) {
v_C_2DTYPE_45 = LREF(k11131);
} else {
v_X_39 = v_KEY6857_29;
v_Y_40 = (LP) 16;
if (((int) (v_KEY6857_29) == (int) ((LP) 16))) {
v_C_2DTYPE_45 = LREF(k11132);
} else {
v_X_36 = v_KEY6857_29;
v_Y_37 = (LP) 32;
if (((int) (v_KEY6857_29) == (int) ((LP) 32))) {
v_C_2DTYPE_45 = LREF(k11133);
} else {
v_X_33 = v_KEY6857_29;
v_Y_34 = (LP) 64;
if (((int) (v_KEY6857_29) == (int) ((LP) 64))) {
v_C_2DTYPE_45 = LREF(k11134);
} else {
v_X_30 = v_KEY6857_29;
v_Y_31 = (LP) 128;
if (((int) (v_KEY6857_29) == (int) ((LP) 128))) {
v_C_2DTYPE_45 = LREF(k11135);
} else {
v_C_2DTYPE_45 = LREF(s_lsp_NIL);
}
}
}
}
}
v_SYMBOL_46 = LREF(s_lsp__2AK_2DSTREAM_2A);
t10 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
t12 = (num_equal_p((v_OBJECT_2DLEN_28), ((LP) 0)));
if (t12 != NIL) {
t11 = (LP) 2;
} else {
t11 = v_OBJECT_2DLEN_28;
}
ICALL(s_lsp_FORMAT) (4, t10, LREF(k11136), v_C_2DTYPE_45, t11);
v_SYMBOL_48 = LREF(s_lsp__2AK_2DSTREAM_2A);
t13 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
t16 = ICALL(s_lsp_LENGTH) (1, v_X_1);
t15 = ICALL(s_lsp_ASH) (2, t16, (LP) 16);
t14 = (add((t15), (v_ELEMENT_2DTYPE_2DTAG_3)));
ICALL(s_lsp_FORMAT) (4, t13, LREF(k11137), v_LABEL_0, t14);
t17 = (num_equal_p((v_OBJECT_2DLEN_28), ((LP) 0)));
if (t17 != NIL) {
v_SYMBOL_50 = LREF(s_lsp__2AK_2DSTREAM_2A);
t18 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
ICALL(s_lsp_FORMAT) (2, t18, LREF(k11138));
} else {
v_REST_52 = v_OBJECTS_27;
t_NEXT_2DLOOP_54:;
if (v_REST_52 == NIL) {
goto t_END_2DLOOP_55;
}
v_X_58 = v_REST_52;
if (((v_X_58) == (v_OBJECTS_27)) == 0) {
v_SYMBOL_56 = LREF(s_lsp__2AK_2DSTREAM_2A);
t20 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
ICALL(s_lsp_FORMAT) (2, t20, LREF(k11139));
}
v_SYMBOL_61 = LREF(s_lsp__2AK_2DSTREAM_2A);
t21 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
v_X_63 = v_REST_52;
t22 = ((LP) DEREF((v_X_63) + 0 * 4));
ICALL(s_lsp_FORMAT) (4, t21, LREF(k11140), v_C_2DTYPE_45, t22);
v_X_65 = v_REST_52;
v_REST_52 = ((LP) DEREF((v_X_65) + 1 * 4));
goto t_NEXT_2DLOOP_54;
goto t_END_2DLOOP_55;
t_END_2DLOOP_55:;
}
v_SYMBOL_67 = LREF(s_lsp__2AK_2DSTREAM_2A);
t24 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
t23 = ICALL(s_lsp_FORMAT) (MV_CALL(argc,2), t24, LREF(k11141));
return(t23);
}
}

LP p_lsp_BIT_2DVECTOR_2D_3EWORD_2DLIST(argc, v_BIT_2DVECTOR_0)
      ARGC argc;  LP v_BIT_2DVECTOR_0;
{
LP v_X_23; LP v_V_21; LP v_X_20; 
LP v_NEW_2DCDR_18; LP v_C_17; LP v_Y_15; 
LP v_X_14; LP v_LOOPVAR_2D1499_10; LP v_LOOPVAR_2D1498_9; 
LP v_LOOPVAR_2D1497_8; LP v_LOOP_2DBIND_2D1496_7; LP v_I_6; 
LP v_WORD_2DVECTOR_5; LP v_WORD_2DLEN_4; LP v_X_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; 
if (argc != 1) wna(argc,1);
v_X_2 = v_BIT_2DVECTOR_0;
t0 = INT_TO_FX(object_size((v_BIT_2DVECTOR_0)));
v_WORD_2DLEN_4 = (divide((t0), ((LP) 8)));
v_WORD_2DVECTOR_5 = ICALL(s_lsp_MAKE_2DARRAY) (5, v_WORD_2DLEN_4, LREF(s_key_DISPLACED_2DTO), v_BIT_2DVECTOR_0, LREF(s_key_ELEMENT_2DTYPE), LREF(k11142));
v_I_6 = (LP) 0;
v_LOOPVAR_2D1497_8 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1498_9 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1499_10 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_12:;
if (((int) (v_I_6) >= (int) (v_WORD_2DLEN_4))) {
goto t_END_2DLOOP_13;
}
v_X_14 = (vref((v_WORD_2DVECTOR_5), ((LP) 0)));
v_LOOPVAR_2D1499_10 = (c_cons((v_X_14), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D1498_9 != NIL) {
v_C_17 = v_LOOPVAR_2D1498_9;
v_NEW_2DCDR_18 = v_LOOPVAR_2D1499_10;
v_V_21 = v_NEW_2DCDR_18;
((LP) (DEREF((v_C_17) + 1 * 4) = (LD) (v_V_21)));
v_X_23 = v_C_17;
v_LOOPVAR_2D1498_9 = ((LP) DEREF((v_X_23) + 1 * 4));
} else {
v_LOOPVAR_2D1497_8 = v_LOOPVAR_2D1499_10;
v_LOOPVAR_2D1498_9 = v_LOOPVAR_2D1497_8;
}
v_I_6 = (((LP) ((int) (v_I_6) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_12;
goto t_END_2DLOOP_13;
t_END_2DLOOP_13:;
return(v_LOOPVAR_2D1497_8);
return(NIL);
return(NIL);
}

LP p_lsp_EMIT_2DCOMPLEX_2D1D_2DARRAY(argc, v_LABEL_0, v_X_1)
      ARGC argc;  LP v_LABEL_0; LP v_X_1;
{

LP t0; LP t1; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,1), LREF(k11144));
return(t0);
}

LP p_lsp_EMIT_2DCOMPLEX_2DMULTI_2DARRAY(argc, v_LABEL_0, v_X_1)
      ARGC argc;  LP v_LABEL_0; LP v_X_1;
{

LP t0; LP t1; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,1), LREF(k11145));
return(t0);
}

LP p_lsp_EMIT_2DSIMPLE_2DMULTI_2DARRAY(argc, v_LABEL_0, v_X_1)
      ARGC argc;  LP v_LABEL_0; LP v_X_1;
{
LP v_SYMBOL_17; LP v_SYMBOL_15; LP v_MULTIPLIER_2DVECTOR_14; 
LP v_DIMS_2DVECTOR_13; LP v_UNDERLYING_2DVECTOR_12; LP v_HEADER_11; 
LP v_A_9; LP v_A_7; LP v_A_5; 
LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; 
if (argc != 2) wna(argc,2);
v_X_3 = v_X_1;
t0 = ((LP) DEREF((v_X_1) + -1 * 4));
v_HEADER_11 = UINT32_TO_INTEGER(((int) (t0)));
v_A_5 = v_X_1;
t1 = ((LP) DEREF((v_X_1) + 0 * 4));
v_UNDERLYING_2DVECTOR_12 = ICALL(s_lsp_EMIT_2DLREF) (1, t1);
v_A_7 = v_X_1;
t2 = ((LP) DEREF((v_X_1) + 1 * 4));
v_DIMS_2DVECTOR_13 = ICALL(s_lsp_EMIT_2DLREF) (1, t2);
v_A_9 = v_X_1;
t3 = ((LP) DEREF((v_A_9) + 2 * 4));
v_MULTIPLIER_2DVECTOR_14 = ICALL(s_lsp_EMIT_2DLREF) (1, t3);
v_SYMBOL_15 = LREF(s_lsp__2AK_2DSTREAM_2A);
t4 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
ICALL(s_lsp_FORMAT) (3, t4, LREF(k11146), v_LABEL_0);
v_SYMBOL_17 = LREF(s_lsp__2AK_2DSTREAM_2A);
t6 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
t5 = ICALL(s_lsp_FORMAT) (MV_CALL(argc,6), t6, LREF(k11147), v_HEADER_11, v_UNDERLYING_2DVECTOR_12, v_DIMS_2DVECTOR_13, v_MULTIPLIER_2DVECTOR_14);
return(t5);
}

LP p_lsp_EMIT_2DCOMPILED_2DFUNCTION(argc, v_LABEL_0, v_X_1)
      ARGC argc;  LP v_LABEL_0; LP v_X_1;
{
LP v_SYMBOL_6; LP v_SYMBOL_4; LP v_C_2DNAME_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_COMPILED_2DFUNCTION_2DNAME) (1, v_X_1);
v_C_2DNAME_3 = ICALL(s_lsp_LISP_2D_3EC_2DPROC_2DNAME) (1, t0);
v_SYMBOL_4 = LREF(s_lsp__2AK_2DSTREAM_2A);
t1 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
ICALL(s_lsp_FORMAT) (3, t1, LREF(k11148), v_C_2DNAME_3);
v_SYMBOL_6 = LREF(s_lsp__2AK_2DSTREAM_2A);
t3 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
t2 = ICALL(s_lsp_FORMAT) (MV_CALL(argc,4), t3, LREF(k11121), v_LABEL_0, v_C_2DNAME_3);
return(t2);
}

LP p_lsp_EMIT_2DSTRUCTURE(argc, v_LABEL_0, v_S_1)
      ARGC argc;  LP v_LABEL_0; LP v_S_1;
{
LP v_SYMBOL_60; LP v_X_58; LP v_X_56; 
LP v_SYMBOL_54; LP v_Y_52; LP v_X_51; 
LP v_SYMBOL_49; LP v_REST_45; LP v_SYMBOL_43; 
LP v_SYMBOL_41; LP v_SYMBOL_39; LP v_OBJECTS_38; 
LP v_X_36; LP v_V_34; LP v_X_33; 
LP v_NEW_2DCDR_31; LP v_C_30; LP v_Y_28; 
LP v_X_27; LP v_LOOPVAR_2D1503_23; LP v_LOOPVAR_2D1502_22; 
LP v_LOOPVAR_2D1501_21; LP v_LOOP_2DBIND_2D1500_20; LP v_I_19; 
LP v_X_17; LP v_TYPE_2DLABEL_16; LP v_I_14; 
LP v_S_13; LP v_S_11; LP v_LEN_10; 
LP v_I_8; LP v_S_7; LP v_S_5; 
LP v_INFO_4; LP v_NAME_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; 
if (argc != 2) wna(argc,2);
v_NAME_3 = ICALL(s_lsp_TYPE_2DOF) (1, v_S_1);
v_INFO_4 = ICALL(s_lsp_LOOKUP_2DSTRUCTURE_2DINFO) (1, v_NAME_3);
if (v_INFO_4 != NIL) {
v_S_5 = v_INFO_4;
v_S_7 = v_INFO_4;
v_I_8 = (LP) 8;
v_LEN_10 = ((LP) DEREF((v_INFO_4) + 4 * 4));
v_S_11 = v_INFO_4;
v_S_13 = v_INFO_4;
v_I_14 = (LP) 2;
t1 = ((LP) DEREF((v_INFO_4) + 1 * 4));
v_TYPE_2DLABEL_16 = ICALL(s_lsp_EMIT_2DLREF) (1, t1);
v_I_19 = (LP) 0;
v_X_17 = v_LEN_10;
v_LOOP_2DBIND_2D1500_20 = (subtract((v_LEN_10), ((LP) 2)));
v_LOOPVAR_2D1501_21 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1502_22 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1503_23 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_25:;
if (((int) (v_I_19) >= (int) (v_LOOP_2DBIND_2D1500_20))) {
goto t_END_2DLOOP_26;
}
t3 = ICALL(s_lsp_REF_2DSTRUCTURE_2DAS_2DVECTOR) (2, v_S_1, v_I_19);
v_X_27 = ICALL(s_lsp_EMIT_2DLREF) (1, t3);
v_LOOPVAR_2D1503_23 = (c_cons((v_X_27), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D1502_22 != NIL) {
v_C_30 = v_LOOPVAR_2D1502_22;
v_NEW_2DCDR_31 = v_LOOPVAR_2D1503_23;
v_V_34 = v_NEW_2DCDR_31;
((LP) (DEREF((v_C_30) + 1 * 4) = (LD) (v_V_34)));
v_X_36 = v_C_30;
v_LOOPVAR_2D1502_22 = ((LP) DEREF((v_X_36) + 1 * 4));
} else {
v_LOOPVAR_2D1501_21 = v_LOOPVAR_2D1503_23;
v_LOOPVAR_2D1502_22 = v_LOOPVAR_2D1501_21;
}
v_I_19 = (((LP) ((int) (v_I_19) + (int) ((LP) 2))));
goto t_NEXT_2DLOOP_25;
goto t_END_2DLOOP_26;
t_END_2DLOOP_26:;
v_OBJECTS_38 = v_LOOPVAR_2D1501_21;
goto b_NIL_24;
v_OBJECTS_38 = NIL;
v_OBJECTS_38 = v_OBJECTS_38;
b_NIL_24:;
v_SYMBOL_39 = LREF(s_lsp__2AK_2DSTREAM_2A);
t4 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
ICALL(s_lsp_FORMAT) (2, t4, LREF(k11149));
v_SYMBOL_41 = LREF(s_lsp__2AK_2DSTREAM_2A);
t5 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
ICALL(s_lsp_FORMAT) (3, t5, LREF(k11150), v_LEN_10);
v_SYMBOL_43 = LREF(s_lsp__2AK_2DSTREAM_2A);
t6 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
ICALL(s_lsp_FORMAT) (5, t6, LREF(k11151), v_LABEL_0, v_LEN_10, v_TYPE_2DLABEL_16);
v_REST_45 = v_OBJECTS_38;
t_NEXT_2DLOOP_47:;
if (v_REST_45 == NIL) {
goto t_END_2DLOOP_48;
}
v_X_51 = v_REST_45;
if (((v_X_51) == (v_OBJECTS_38)) == 0) {
v_SYMBOL_49 = LREF(s_lsp__2AK_2DSTREAM_2A);
t8 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
ICALL(s_lsp_FORMAT) (2, t8, LREF(k11139));
}
v_SYMBOL_54 = LREF(s_lsp__2AK_2DSTREAM_2A);
t9 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
v_X_56 = v_REST_45;
t10 = ((LP) DEREF((v_X_56) + 0 * 4));
ICALL(s_lsp_FORMAT) (3, t9, LREF(k11152), t10);
v_X_58 = v_REST_45;
v_REST_45 = ((LP) DEREF((v_X_58) + 1 * 4));
goto t_NEXT_2DLOOP_47;
goto t_END_2DLOOP_48;
t_END_2DLOOP_48:;
v_SYMBOL_60 = LREF(s_lsp__2AK_2DSTREAM_2A);
t11 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
t0 = ICALL(s_lsp_FORMAT) (MV_CALL(argc,2), t11, LREF(k11141));
return(t0);
} else {
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,2), LREF(k11153), v_NAME_3);
return(t0);
}
}

LP p_lsp_WCL_2DFIXNUM_3F(argc, v_N_0)
      ARGC argc;  LP v_N_0;
{
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; 
if (argc != 1) wna(argc,1);
v_X_2 = v_N_0;
t0 = (FIXNUMP((v_N_0)) ? T : NIL);
return(t0);
}

LP p_lsp_EMIT_2DBIGNUM(argc, v_LABEL_0, v_N_1)
      ARGC argc;  LP v_LABEL_0; LP v_N_1;
{
LP v_SYMBOL_31; LP v_END_29; LP v_START_28; 
LP v_SEQ_27; LP v_START_25; LP v_SEQ_24; 
LP v_END_26; LP v_SYMBOL_22; LP v_LOOP_2DITER_2DFLAG_2D1504_18; 
LP v_I_17; LP v_X_15; LP v_HIGH_14; 
LP v_SYMBOL_12; LP v_SYMBOL_10; LP v_HEADER_9; 
LP v_HEADER_2DLEN_8; LP v_BIGNUM_2DLEN_7; LP v_LEN_6; 
LP v_HEX_2DDIGITS_5; LP v__2APRINT_2DBASE_2A_4; LP v_ABS_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 

if (argc != 2) wna(argc,2);
v_ABS_3 = ICALL(s_lsp_ABS) (1, v_N_1);
v__2APRINT_2DBASE_2A_4 = (LP) 32;
BEGIN_SPEC_BIND(s_lsp__2APRINT_2DBASE_2A,(LP) 32);
t0 = ICALL(s_lsp_WRITE_2DTO_2DSTRING_2D1) (1, v_ABS_3);
END_SPEC_BIND(s_lsp__2APRINT_2DBASE_2A);
v_HEX_2DDIGITS_5 = t0;
v_LEN_6 = ICALL(s_lsp_LENGTH) (1, v_HEX_2DDIGITS_5);
v_BIGNUM_2DLEN_7 = ICALL(s_lsp_CEILING) (2, v_LEN_6, (LP) 16);
t1 = (multiply((v_BIGNUM_2DLEN_7), ((LP) 8)));
v_HEADER_2DLEN_8 = (add((t1), ((LP) 16)));
t2 = ICALL(s_lsp_ASH) (2, v_HEADER_2DLEN_8, (LP) 16);
v_HEADER_9 = (add(((LP) 2), (t2)));
v_SYMBOL_10 = LREF(s_lsp__2AK_2DSTREAM_2A);
t3 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
ICALL(s_lsp_FORMAT) (3, t3, LREF(k11154), v_BIGNUM_2DLEN_7);
v_SYMBOL_12 = LREF(s_lsp__2AK_2DSTREAM_2A);
t4 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
t6 = (greaterp((v_N_1), ((LP) 0)));
if (t6 != NIL) {
t5 = (LP) 2;
} else {
t5 = (LP) -2;
}
ICALL(s_lsp_FORMAT) (6, t4, LREF(k11155), v_LABEL_0, v_HEADER_9, v_BIGNUM_2DLEN_7, t5);
v_HIGH_14 = v_LEN_6;
v_X_15 = v_BIGNUM_2DLEN_7;
v_I_17 = (subtract((v_BIGNUM_2DLEN_7), ((LP) 2)));
v_LOOP_2DITER_2DFLAG_2D1504_18 = LREF(s_lsp_T);
t_NEXT_2DLOOP_20:;
if (((int) (v_HIGH_14) < (int) ((LP) 0))) {
goto t_END_2DLOOP_21;
}
if (v_LOOP_2DITER_2DFLAG_2D1504_18 == NIL) {
v_I_17 = (((LP) ((int) (v_I_17) - (int) ((LP) 2))));
}
if (((int) (v_I_17) < (int) ((LP) 0))) {
goto t_END_2DLOOP_21;
}
v_SYMBOL_22 = LREF(s_lsp__2AK_2DSTREAM_2A);
t9 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
t10 = (subtract((v_HIGH_14), ((LP) 16)));
v_START_28 = ICALL(s_lsp_MAX) (2, t10, (LP) 0);
v_END_29 = v_HIGH_14;
t11 = ICALL(s_lsp_SUBSEQ_2D1) (3, v_HEX_2DDIGITS_5, v_START_28, v_END_29);
if (((int) (v_I_17) == (int) ((LP) 0))) {
t12 = LREF(k11157);
} else {
t12 = LREF(k11139);
}
ICALL(s_lsp_FORMAT) (4, t9, LREF(k11156), t11, t12);
v_LOOP_2DITER_2DFLAG_2D1504_18 = LREF(s_lsp_NIL);
v_HIGH_14 = (((LP) ((int) (v_HIGH_14) - (int) ((LP) 16))));
goto t_NEXT_2DLOOP_20;
goto t_END_2DLOOP_21;
t_END_2DLOOP_21:;
v_SYMBOL_31 = LREF(s_lsp__2AK_2DSTREAM_2A);
t15 = ((LP) DEREF((LREF(s_lsp__2AK_2DSTREAM_2A)) + 0 * 4));
t14 = ICALL(s_lsp_FORMAT) (MV_CALL(argc,2), t15, LREF(k11141));
return(t14);
}

