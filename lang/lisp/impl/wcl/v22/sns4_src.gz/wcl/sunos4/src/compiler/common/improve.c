/*
:comment "Compiled at 4:48:22 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: Debug Library"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O2 -fPIC"
:version 0
:end-package-info 0
:sym NIL
:sym SEQ
:sym PROC
:sym TOP-LEVEL-PROC
:sym INNER-PROC
:sym TAG-SEQ
:sym SCOPE-SEQ
:sym PROGN
:sym VALUES-SEQ
:sym NAMED-LOCAL
:sym INLINE-MV-CALL
:sym SPEC-BIND-SEQ
:sym UNWIND-PROTECT
:sym IMPROVE-UNWIND-PROTECT
:sym VAR-REF
:sym IMPROVE-VAR-REF
:sym VAR-DEF
:sym IMPROVE-VAR-DEF
:sym MVALUES
:sym IMPROVE-VALUES
:sym IF
:sym IMPROVE-IF
:sym SWITCH
:sym IMPROVE-SWITCH
:sym FUNCTION-CALL
:sym C-STRUCT-OP
:sym C-STRUCT-DEF
:sym C-STRUCT-REF
:sym PRIMITIVE-CALL
:sym UNNAMED-CALL
:sym FOREIGN-CALL
:sym NAMED-CALL
:sym SCOPE-CONTROL-TRANSFER
:sym IMPROVE-SCOPE-CONTROL-TRANSFER
:sym CONTROL-POINT
:sym TAG-CONTROL-POINT
:sym DYNAMIC-TAG-CONTROL-POINT
:sym STATIC-TAG-CONTROL-POINT
:sym SCOPE-CONTROL-POINT
:sym DYNAMIC-SCOPE-CONTROL-POINT
:sym CATCH-CONTROL-POINT
:sym DYNAMIC-BLOCK-CONTROL-POINT
:sym STATIC-SCOPE-CONTROL-POINT
:sym CONSTANT
:sym IMPROVE-CONSTANT
:sym IMPROVE-SEQ
:sym IMPROVE-FUNCTION-CALL
:sym IMPROVE-CONTROL-POINT
:sf IMPROVE "p_lsp_IMPROVE"
:sf IMPROVE-CONSTANT "p_lsp_IMPROVE_2DCONSTANT"
:sym LAST
:sym IMPROVE
:sf IMPROVE-LIST "p_lsp_IMPROVE_2DLIST"
:sym VALUES-SEQ-P
:sym IMPROVE-LIST
:sym SCOPE-SEQ-P
:sym T
:sf IMPROVE-SEQ "p_lsp_IMPROVE_2DSEQ"
:sf IMPROVE-VALUES "p_lsp_IMPROVE_2DVALUES"
:sf IMPROVE-VAR-REF "p_lsp_IMPROVE_2DVAR_2DREF"
:sf IMPROVE-VAR-DEF "p_lsp_IMPROVE_2DVAR_2DDEF"
:sym UNNAMED-CALL-P
:sym EVERY
:sym TYPE-OF
:sym TYPE-MACROEXPAND
:sym MAKE-CONSTANT/6
:sym FUNCTION-CALL-REWRITE-METHOD
:sym GET-OR-CREATE-PROC-INFO
:sym PROC-INFO
:sym MEMQL
:sym MAKE-NAMED-CALL/9
:sym PRIMITIVE-INFO
:sym MAKE-PRIMITIVE-CALL/8
:sym ERROR
:sym FUNCTION-CALL-SIDE-EFFECTS?
:sym CONSTANT-P
:sym TYPEP
:sf IMPROVE-FUNCTION-CALL "p_lsp_IMPROVE_2DFUNCTION_2DCALL"
:sym NAMED-CALL-P
:sym FOREIGN-CALL-P
:sym CALL-MATCHES-METHOD-TYPE-SIGNATURE?
:sf FUNCTION-CALL-REWRITE-METHOD "p_lsp_FUNCTION_2DCALL_2DREWRITE_2DMETHOD"
:sym SUBTYPEP
:sf CALL-MATCHES-METHOD-TYPE-SIGNATURE? "p_lsp_CALL_2DMATCHES_2DMETHOD_2DTYPE_2DSIGNATURE_3F"
:sym TAIL-LEAVES
:sym LENGTH
:sym PRIMITIVE-CALL-P
:sym %EQ
:sym TREE-NSUBST
:sym C-TYPE-IF-TEST
:sf IMPROVE-IF "p_lsp_IMPROVE_2DIF"
:sf IMPROVE-SWITCH "p_lsp_IMPROVE_2DSWITCH"
:sf IMPROVE-SCOPE-CONTROL-TRANSFER "p_lsp_IMPROVE_2DSCOPE_2DCONTROL_2DTRANSFER"
:sf IMPROVE-CONTROL-POINT "p_lsp_IMPROVE_2DCONTROL_2DPOINT"
:sf IMPROVE-UNWIND-PROTECT "p_lsp_IMPROVE_2DUNWIND_2DPROTECT"
:sym SEQ-P
:sym SCOPE-CONTROL-TRANSFER-P
:sym UNWIND-PROTECT-P
:sym IF-P
:sym APPEND/2
:sym SWITCH-P
:sym COPY-LIST
:sym FUNCTION-CALL-P
:sym VAR-REF-P
:sym VAR-DEF-P
:sym MVALUES-P
:sf TAIL-LEAVES "p_lsp_TAIL_2DLEAVES"
:sym CLEAR-TREE-LEAVES-TAIL-SLOTS
:sf CLEAR-TREE-LEAVES-TAIL-SLOTS "p_lsp_CLEAR_2DTREE_2DLEAVES_2DTAIL_2DSLOTS"
:sf FUNCTION-CALL-SIDE-EFFECTS? "p_lsp_FUNCTION_2DCALL_2DSIDE_2DEFFECTS_3F"
:pinfo IMPROVE-SCOPE-CONTROL-TRANSFER (TREE) NIL NIL NIL NIL NIL NIL T
:pinfo IMPROVE (TREE &OPTIONAL DEAD?) NIL NIL NIL NIL NIL NIL T
:pinfo CALL-MATCHES-METHOD-TYPE-SIGNATURE? (CALL METHOD) NIL NIL NIL NIL NIL NIL T
:pinfo FUNCTION-CALL-SIDE-EFFECTS? (TREE) NIL NIL NIL NIL NIL NIL T
:pinfo IMPROVE-FUNCTION-CALL (TREE DEAD?) NIL NIL NIL NIL NIL NIL T
:pinfo IMPROVE-CONTROL-POINT (TREE) NIL NIL NIL NIL NIL NIL T
:pinfo CLEAR-TREE-LEAVES-TAIL-SLOTS (TREE) NIL NIL NIL NIL NIL NIL T
:pinfo FUNCTION-CALL-REWRITE-METHOD (CALL) NIL NIL NIL NIL NIL NIL T
:pinfo IMPROVE-LIST (L &OPTIONAL DEAD? BODY?) NIL NIL NIL NIL NIL NIL T
:pinfo IMPROVE-CONSTANT (TREE DEAD?) NIL NIL NIL NIL NIL NIL T
:pinfo IMPROVE-SWITCH (TREE DEAD?) NIL NIL NIL NIL NIL NIL T
:pinfo IMPROVE-IF (TREE DEAD?) NIL NIL NIL NIL NIL NIL T
:pinfo IMPROVE-VAR-REF (TREE DEAD?) NIL NIL NIL NIL NIL NIL T
:pinfo IMPROVE-UNWIND-PROTECT (TREE DEAD?) NIL NIL NIL NIL NIL NIL T
:pinfo TAIL-LEAVES (TREE) NIL NIL NIL NIL NIL NIL T
:pinfo IMPROVE-VAR-DEF (TREE) NIL NIL NIL NIL NIL NIL T
:pinfo IMPROVE-SEQ (TREE DEAD?) NIL NIL NIL NIL NIL NIL T
:pinfo IMPROVE-VALUES (TREE DEAD?) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_lsp_IMPROVE();
extern SYMBOL s_lsp_NIL; 
extern SYMBOL s_lsp_SEQ; 
extern SYMBOL s_lsp_PROC; 
extern SYMBOL s_lsp_TOP_2DLEVEL_2DPROC; 
extern SYMBOL s_lsp_INNER_2DPROC; 
extern SYMBOL s_lsp_TAG_2DSEQ; 
extern SYMBOL s_lsp_SCOPE_2DSEQ; 
extern SYMBOL s_lsp_PROGN; 
extern SYMBOL s_lsp_VALUES_2DSEQ; 
extern SYMBOL s_lsp_NAMED_2DLOCAL; 
extern SYMBOL s_lsp_INLINE_2DMV_2DCALL; 
extern SYMBOL s_lsp_SPEC_2DBIND_2DSEQ; 
extern SYMBOL s_lsp_UNWIND_2DPROTECT; 
extern SYMBOL s_lsp_IMPROVE_2DUNWIND_2DPROTECT; 
extern SYMBOL s_lsp_VAR_2DREF; 
extern SYMBOL s_lsp_IMPROVE_2DVAR_2DREF; 
extern SYMBOL s_lsp_VAR_2DDEF; 
extern SYMBOL s_lsp_IMPROVE_2DVAR_2DDEF; 
extern SYMBOL s_lsp_MVALUES; 
extern SYMBOL s_lsp_IMPROVE_2DVALUES; 
extern SYMBOL s_lsp_IF; 
extern SYMBOL s_lsp_IMPROVE_2DIF; 
extern SYMBOL s_lsp_SWITCH; 
extern SYMBOL s_lsp_IMPROVE_2DSWITCH; 
extern SYMBOL s_lsp_FUNCTION_2DCALL; 
extern SYMBOL s_lsp_C_2DSTRUCT_2DOP; 
extern SYMBOL s_lsp_C_2DSTRUCT_2DDEF; 
extern SYMBOL s_lsp_C_2DSTRUCT_2DREF; 
extern SYMBOL s_lsp_PRIMITIVE_2DCALL; 
extern SYMBOL s_lsp_UNNAMED_2DCALL; 
extern SYMBOL s_lsp_FOREIGN_2DCALL; 
extern SYMBOL s_lsp_NAMED_2DCALL; 
extern SYMBOL s_lsp_SCOPE_2DCONTROL_2DTRANSFER; 
extern SYMBOL s_lsp_IMPROVE_2DSCOPE_2DCONTROL_2DTRANSFER; 
extern SYMBOL s_lsp_CONTROL_2DPOINT; 
extern SYMBOL s_lsp_TAG_2DCONTROL_2DPOINT; 
extern SYMBOL s_lsp_DYNAMIC_2DTAG_2DCONTROL_2DPOINT; 
extern SYMBOL s_lsp_STATIC_2DTAG_2DCONTROL_2DPOINT; 
extern SYMBOL s_lsp_SCOPE_2DCONTROL_2DPOINT; 
extern SYMBOL s_lsp_DYNAMIC_2DSCOPE_2DCONTROL_2DPOINT; 
extern SYMBOL s_lsp_CATCH_2DCONTROL_2DPOINT; 
extern SYMBOL s_lsp_DYNAMIC_2DBLOCK_2DCONTROL_2DPOINT; 
extern SYMBOL s_lsp_STATIC_2DSCOPE_2DCONTROL_2DPOINT; 
extern SYMBOL s_lsp_CONSTANT; 
extern SYMBOL s_lsp_IMPROVE_2DCONSTANT; 
extern SYMBOL s_lsp_IMPROVE_2DSEQ; 
extern SYMBOL s_lsp_IMPROVE_2DFUNCTION_2DCALL; 
extern SYMBOL s_lsp_IMPROVE_2DCONTROL_2DPOINT; 
extern LP p_lsp_IMPROVE_2DCONSTANT();
extern LP p_lsp_IMPROVE_2DLIST();
extern SYMBOL s_lsp_LAST; 
extern SYMBOL s_lsp_IMPROVE; 
extern LP p_lsp_IMPROVE_2DSEQ();
extern SYMBOL s_lsp_VALUES_2DSEQ_2DP; 
extern SYMBOL s_lsp_IMPROVE_2DLIST; 
extern SYMBOL s_lsp_SCOPE_2DSEQ_2DP; 
extern SYMBOL s_lsp_T; 
extern LP p_lsp_IMPROVE_2DVALUES();
extern LP p_lsp_IMPROVE_2DVAR_2DREF();
extern LP p_lsp_IMPROVE_2DVAR_2DDEF();
extern LP p_lsp_IMPROVE_2DFUNCTION_2DCALL();
extern SYMBOL s_lsp_UNNAMED_2DCALL_2DP; 
extern LP p_lsp_IMPROVE_2DFUNCTION_2DCALL_2Danon1086810869();
MAKE_PROCEDURE(k10870,p_lsp_IMPROVE_2DFUNCTION_2DCALL_2Danon1086810869);
extern SYMBOL s_lsp_EVERY; 
extern SYMBOL s_lsp_TYPE_2DOF; 
extern SYMBOL s_lsp_TYPE_2DMACROEXPAND; 
extern SYMBOL s_lsp_MAKE_2DCONSTANT_2F6; 
extern SYMBOL s_lsp_FUNCTION_2DCALL_2DREWRITE_2DMETHOD; 
extern SYMBOL s_lsp_GET_2DOR_2DCREATE_2DPROC_2DINFO; 
extern SYMBOL s_lsp_PROC_2DINFO; 
MAKE_CONS(k10871,LREF(s_lsp_PROC_2DINFO),LREF(s_lsp_NIL));
extern SYMBOL s_lsp_MEMQL; 
extern SYMBOL s_lsp_MAKE_2DNAMED_2DCALL_2F9; 
extern SYMBOL s_lsp_PRIMITIVE_2DINFO; 
MAKE_CONS(k10872,LREF(s_lsp_PRIMITIVE_2DINFO),LREF(s_lsp_NIL));
extern SYMBOL s_lsp_MAKE_2DPRIMITIVE_2DCALL_2F8; 
MAKE_SIMPLE_STRING(k10873,36,"~S is not one of these types:~{ ~A~}");
MAKE_CONS(k10874,LREF(s_lsp_PRIMITIVE_2DINFO),LREF(k10871));
extern SYMBOL s_lsp_ERROR; 
extern SYMBOL s_lsp_FUNCTION_2DCALL_2DSIDE_2DEFFECTS_3F; 
extern SYMBOL s_lsp_CONSTANT_2DP; 
extern SYMBOL s_lsp_TYPEP; 
extern LP p_lsp_FUNCTION_2DCALL_2DREWRITE_2DMETHOD();
extern SYMBOL s_lsp_NAMED_2DCALL_2DP; 
extern SYMBOL s_lsp_FOREIGN_2DCALL_2DP; 
extern SYMBOL s_lsp_CALL_2DMATCHES_2DMETHOD_2DTYPE_2DSIGNATURE_3F; 
extern LP p_lsp_CALL_2DMATCHES_2DMETHOD_2DTYPE_2DSIGNATURE_3F();
extern SYMBOL s_lsp_SUBTYPEP; 
extern LP p_lsp_IMPROVE_2DIF();
MAKE_CONS(k10875,LREF(s_lsp_CONSTANT),LREF(s_lsp_NIL));
extern SYMBOL s_lsp_TAIL_2DLEAVES; 
extern SYMBOL s_lsp_LENGTH; 
extern SYMBOL s_lsp_PRIMITIVE_2DCALL_2DP; 
extern SYMBOL s_lsp__25EQ; 
extern SYMBOL s_lsp_TREE_2DNSUBST; 
extern SYMBOL s_lsp_C_2DTYPE_2DIF_2DTEST; 
extern LP p_lsp_IMPROVE_2DSWITCH();
extern LP p_lsp_IMPROVE_2DSCOPE_2DCONTROL_2DTRANSFER();
extern LP p_lsp_IMPROVE_2DCONTROL_2DPOINT();
MAKE_CONS(k10876,LREF(s_lsp_DYNAMIC_2DTAG_2DCONTROL_2DPOINT),LREF(s_lsp_NIL));
MAKE_CONS(k10879,LREF(s_lsp_DYNAMIC_2DBLOCK_2DCONTROL_2DPOINT),LREF(s_lsp_NIL));
MAKE_CONS(k10878,LREF(s_lsp_CATCH_2DCONTROL_2DPOINT),LREF(k10879));
MAKE_CONS(k10877,LREF(s_lsp_DYNAMIC_2DSCOPE_2DCONTROL_2DPOINT),LREF(k10878));
extern LP p_lsp_IMPROVE_2DUNWIND_2DPROTECT();
extern LP p_lsp_TAIL_2DLEAVES();
extern SYMBOL s_lsp_SEQ_2DP; 
extern SYMBOL s_lsp_SCOPE_2DCONTROL_2DTRANSFER_2DP; 
extern SYMBOL s_lsp_UNWIND_2DPROTECT_2DP; 
extern SYMBOL s_lsp_IF_2DP; 
extern SYMBOL s_lsp_APPEND_2F2; 
extern SYMBOL s_lsp_SWITCH_2DP; 
extern SYMBOL s_lsp_COPY_2DLIST; 
extern SYMBOL s_lsp_FUNCTION_2DCALL_2DP; 
extern SYMBOL s_lsp_VAR_2DREF_2DP; 
extern SYMBOL s_lsp_VAR_2DDEF_2DP; 
extern SYMBOL s_lsp_MVALUES_2DP; 
extern LP p_lsp_CLEAR_2DTREE_2DLEAVES_2DTAIL_2DSLOTS();
extern SYMBOL s_lsp_CLEAR_2DTREE_2DLEAVES_2DTAIL_2DSLOTS; 
extern LP p_lsp_FUNCTION_2DCALL_2DSIDE_2DEFFECTS_3F();


extern LP num_equal_p();
extern LP c_cons();


LP p_lsp_IMPROVE(va_alist) va_dcl
{
LP v_Y_131; LP v_X_130; LP v_X_128; 
LP v_X_126; LP v_S_124; LP v_SYMBOL_122; 
LP v_Y_120; LP v_X_119; LP v_Y_117; 
LP v_X_116; LP v_Y_114; LP v_X_113; 
LP v_Y_111; LP v_X_110; LP v_Y_108; 
LP v_X_107; LP v_Y_105; LP v_X_104; 
LP v_Y_102; LP v_X_101; LP v_Y_99; 
LP v_X_98; LP v_Y_96; LP v_X_95; 
LP v_Y_93; LP v_X_92; LP v_Y_90; 
LP v_X_89; LP v_Y_87; LP v_X_86; 
LP v_Y_84; LP v_X_83; LP v_Y_81; 
LP v_X_80; LP v_Y_78; LP v_X_77; 
LP v_Y_75; LP v_X_74; LP v_Y_72; 
LP v_X_71; LP v_Y_69; LP v_X_68; 
LP v_Y_66; LP v_X_65; LP v_Y_63; 
LP v_X_62; LP v_Y_60; LP v_X_59; 
LP v_Y_57; LP v_X_56; LP v_Y_54; 
LP v_X_53; LP v_Y_51; LP v_X_50; 
LP v_Y_48; LP v_X_47; LP v_Y_45; 
LP v_X_44; LP v_Y_42; LP v_X_41; 
LP v_Y_39; LP v_X_38; LP v_Y_36; 
LP v_X_35; LP v_Y_33; LP v_X_32; 
LP v_Y_30; LP v_X_29; LP v_Y_27; 
LP v_X_26; LP v_Y_24; LP v_X_23; 
LP v_Y_21; LP v_X_20; LP v_Y_18; 
LP v_X_17; LP v_Y_15; LP v_X_14; 
LP v_KEY6591_9; LP v_S_7; LP v_KEY6590_4; 
LP v_TREE_0; LP v_DEAD_3F_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; LP t145; LP t146; LP t147; LP t148; LP t149; 
LP t150; LP t151; LP t152; LP t153; LP t154; LP t155; 
LP t156; LP t157; LP t158; LP t159; LP t160; LP t161; 
LP t162; LP t163; LP t164; LP t165; LP t166; LP t167; 
LP t168; LP t169; LP t170; LP t171; LP t172; LP t173; 
LP t174; LP t175; LP t176; LP t177; LP t178; LP t179; 
LP t180; LP t181; LP t182; LP t183; LP t184; LP t185; 
LP t186; LP t187; LP t188; LP t189; LP t190; LP t191; 
LP t192; LP t193; LP t194; LP t195; LP t196; LP t197; 
LP t198; LP t199; LP t200; LP t201; LP t202; LP t203; 
LP t204; LP t205; LP t206; LP t207; LP t208; LP t209; 
LP t210; LP t211; LP t212; LP t213; LP t214; LP t215; 
LP t216; LP t217; LP t218; LP t219; LP t220; LP t221; 
LP t222; LP t223; LP t224; LP t225; LP t226; LP t227; 
LP t228; LP t229; LP t230; LP t231; LP t232; LP t233; 
LP t234; LP t235; LP t236; LP t237; LP t238; LP t239; 
LP t240; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_TREE_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
v_DEAD_3F_1 = NIL;
} else {
v_DEAD_3F_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
v_X_128 = v_TREE_0;
v_X_130 = v_TREE_0;
v_Y_131 = LREF(s_lsp_NIL);
if (v_TREE_0 != NIL) {
v_KEY6590_4 = v_TREE_0;
v_X_126 = v_KEY6590_4;
if (FIXNUMP((v_KEY6590_4))) {
goto t_DEFAULT_2DTAG6589_5;
} else {
t3 = INT_TO_FX(((int) TAG((v_KEY6590_4))));
switch ((int) t3) {
case 94:
v_S_7 = v_KEY6590_4;
v_KEY6591_9 = ((LP) DEREF((v_KEY6590_4) + 0 * 4));
v_S_124 = v_KEY6591_9;
if (OTHER_PTRP((v_KEY6591_9)) && (TAG((v_KEY6591_9)) == 3)) {
v_SYMBOL_122 = v_KEY6591_9;
t7 = ((LP) DEREF((v_KEY6591_9) + 5 * 4));
t6 = ((LP) ((int) (t7) % (int) ((LP) 428)));
switch ((int) t6) {
case 200:
v_X_14 = v_KEY6591_9;
v_Y_15 = LREF(s_lsp_SEQ);
if (((v_KEY6591_9) == (LREF(s_lsp_SEQ)))) {
goto t_C6596_11;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 224:
v_X_17 = v_KEY6591_9;
v_Y_18 = LREF(s_lsp_PROC);
if (((v_KEY6591_9) == (LREF(s_lsp_PROC)))) {
goto t_C6596_11;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 158:
v_X_20 = v_KEY6591_9;
v_Y_21 = LREF(s_lsp_TOP_2DLEVEL_2DPROC);
if (((v_KEY6591_9) == (LREF(s_lsp_TOP_2DLEVEL_2DPROC)))) {
goto t_C6596_11;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 250:
v_X_23 = v_KEY6591_9;
v_Y_24 = LREF(s_lsp_INNER_2DPROC);
if (((v_KEY6591_9) == (LREF(s_lsp_INNER_2DPROC)))) {
goto t_C6596_11;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 70:
v_X_26 = v_KEY6591_9;
v_Y_27 = LREF(s_lsp_TAG_2DSEQ);
if (((v_KEY6591_9) == (LREF(s_lsp_TAG_2DSEQ)))) {
goto t_C6596_11;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 106:
v_X_29 = v_KEY6591_9;
v_Y_30 = LREF(s_lsp_SCOPE_2DSEQ);
if (((v_KEY6591_9) == (LREF(s_lsp_SCOPE_2DSEQ)))) {
goto t_C6596_11;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 118:
v_X_32 = v_KEY6591_9;
v_Y_33 = LREF(s_lsp_PROGN);
if (((v_KEY6591_9) == (LREF(s_lsp_PROGN)))) {
goto t_C6596_11;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 96:
v_X_35 = v_KEY6591_9;
v_Y_36 = LREF(s_lsp_VALUES_2DSEQ);
if (((v_KEY6591_9) == (LREF(s_lsp_VALUES_2DSEQ)))) {
goto t_C6596_11;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 416:
v_X_38 = v_KEY6591_9;
v_Y_39 = LREF(s_lsp_NAMED_2DLOCAL);
if (((v_KEY6591_9) == (LREF(s_lsp_NAMED_2DLOCAL)))) {
goto t_C6596_11;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 252:
v_X_41 = v_KEY6591_9;
v_Y_42 = LREF(s_lsp_INLINE_2DMV_2DCALL);
if (((v_KEY6591_9) == (LREF(s_lsp_INLINE_2DMV_2DCALL)))) {
goto t_C6596_11;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 76:
v_X_44 = v_KEY6591_9;
v_Y_45 = LREF(s_lsp_SPEC_2DBIND_2DSEQ);
if (((v_KEY6591_9) == (LREF(s_lsp_SPEC_2DBIND_2DSEQ)))) {
goto t_C6596_11;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 326:
v_X_47 = v_KEY6591_9;
v_Y_48 = LREF(s_lsp_UNWIND_2DPROTECT);
if (((v_KEY6591_9) == (LREF(s_lsp_UNWIND_2DPROTECT)))) {
t5 = ICALL(s_lsp_IMPROVE_2DUNWIND_2DPROTECT) (MV_CALL(argc,2), v_TREE_0, v_DEAD_3F_1);
return(t5);
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 228:
v_X_50 = v_KEY6591_9;
v_Y_51 = LREF(s_lsp_VAR_2DREF);
if (((v_KEY6591_9) == (LREF(s_lsp_VAR_2DREF)))) {
t5 = ICALL(s_lsp_IMPROVE_2DVAR_2DREF) (MV_CALL(argc,2), v_TREE_0, v_DEAD_3F_1);
return(t5);
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 408:
v_X_53 = v_KEY6591_9;
v_Y_54 = LREF(s_lsp_VAR_2DDEF);
if (((v_KEY6591_9) == (LREF(s_lsp_VAR_2DDEF)))) {
t5 = ICALL(s_lsp_IMPROVE_2DVAR_2DDEF) (MV_CALL(argc,1), v_TREE_0);
return(t5);
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 28:
v_X_56 = v_KEY6591_9;
v_Y_57 = LREF(s_lsp_MVALUES);
if (((v_KEY6591_9) == (LREF(s_lsp_MVALUES)))) {
t5 = ICALL(s_lsp_IMPROVE_2DVALUES) (MV_CALL(argc,2), v_TREE_0, v_DEAD_3F_1);
return(t5);
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 126:
v_X_59 = v_KEY6591_9;
v_Y_60 = LREF(s_lsp_IF);
if (((v_KEY6591_9) == (LREF(s_lsp_IF)))) {
t5 = ICALL(s_lsp_IMPROVE_2DIF) (MV_CALL(argc,2), v_TREE_0, v_DEAD_3F_1);
return(t5);
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 308:
v_X_62 = v_KEY6591_9;
v_Y_63 = LREF(s_lsp_SWITCH);
if (((v_KEY6591_9) == (LREF(s_lsp_SWITCH)))) {
t5 = ICALL(s_lsp_IMPROVE_2DSWITCH) (MV_CALL(argc,2), v_TREE_0, v_DEAD_3F_1);
return(t5);
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 104:
v_X_65 = v_KEY6591_9;
v_Y_66 = LREF(s_lsp_FUNCTION_2DCALL);
if (((v_KEY6591_9) == (LREF(s_lsp_FUNCTION_2DCALL)))) {
goto t_C6595_12;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 160:
v_X_68 = v_KEY6591_9;
v_Y_69 = LREF(s_lsp_C_2DSTRUCT_2DOP);
if (((v_KEY6591_9) == (LREF(s_lsp_C_2DSTRUCT_2DOP)))) {
goto t_C6595_12;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 402:
v_X_71 = v_KEY6591_9;
v_Y_72 = LREF(s_lsp_C_2DSTRUCT_2DDEF);
if (((v_KEY6591_9) == (LREF(s_lsp_C_2DSTRUCT_2DDEF)))) {
goto t_C6595_12;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 222:
v_X_74 = v_KEY6591_9;
v_Y_75 = LREF(s_lsp_C_2DSTRUCT_2DREF);
if (((v_KEY6591_9) == (LREF(s_lsp_C_2DSTRUCT_2DREF)))) {
goto t_C6595_12;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 80:
v_X_77 = v_KEY6591_9;
v_Y_78 = LREF(s_lsp_PRIMITIVE_2DCALL);
if (((v_KEY6591_9) == (LREF(s_lsp_PRIMITIVE_2DCALL)))) {
goto t_C6595_12;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 310:
v_X_80 = v_KEY6591_9;
v_Y_81 = LREF(s_lsp_UNNAMED_2DCALL);
if (((v_KEY6591_9) == (LREF(s_lsp_UNNAMED_2DCALL)))) {
goto t_C6595_12;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 54:
v_X_83 = v_KEY6591_9;
v_Y_84 = LREF(s_lsp_FOREIGN_2DCALL);
if (((v_KEY6591_9) == (LREF(s_lsp_FOREIGN_2DCALL)))) {
goto t_C6595_12;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 424:
v_X_86 = v_KEY6591_9;
v_Y_87 = LREF(s_lsp_NAMED_2DCALL);
if (((v_KEY6591_9) == (LREF(s_lsp_NAMED_2DCALL)))) {
goto t_C6595_12;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 204:
v_X_89 = v_KEY6591_9;
v_Y_90 = LREF(s_lsp_SCOPE_2DCONTROL_2DTRANSFER);
if (((v_KEY6591_9) == (LREF(s_lsp_SCOPE_2DCONTROL_2DTRANSFER)))) {
t5 = ICALL(s_lsp_IMPROVE_2DSCOPE_2DCONTROL_2DTRANSFER) (MV_CALL(argc,1), v_TREE_0);
return(t5);
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 306:
v_X_92 = v_KEY6591_9;
v_Y_93 = LREF(s_lsp_CONTROL_2DPOINT);
if (((v_KEY6591_9) == (LREF(s_lsp_CONTROL_2DPOINT)))) {
goto t_C6594_13;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 248:
v_X_95 = v_KEY6591_9;
v_Y_96 = LREF(s_lsp_TAG_2DCONTROL_2DPOINT);
if (((v_KEY6591_9) == (LREF(s_lsp_TAG_2DCONTROL_2DPOINT)))) {
goto t_C6594_13;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 112:
v_X_98 = v_KEY6591_9;
v_Y_99 = LREF(s_lsp_DYNAMIC_2DTAG_2DCONTROL_2DPOINT);
if (((v_KEY6591_9) == (LREF(s_lsp_DYNAMIC_2DTAG_2DCONTROL_2DPOINT)))) {
goto t_C6594_13;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 284:
v_X_101 = v_KEY6591_9;
v_Y_102 = LREF(s_lsp_STATIC_2DTAG_2DCONTROL_2DPOINT);
if (((v_KEY6591_9) == (LREF(s_lsp_STATIC_2DTAG_2DCONTROL_2DPOINT)))) {
goto t_C6594_13;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 92:
v_X_104 = v_KEY6591_9;
v_Y_105 = LREF(s_lsp_SCOPE_2DCONTROL_2DPOINT);
if (((v_KEY6591_9) == (LREF(s_lsp_SCOPE_2DCONTROL_2DPOINT)))) {
goto t_C6594_13;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 192:
v_X_107 = v_KEY6591_9;
v_Y_108 = LREF(s_lsp_DYNAMIC_2DSCOPE_2DCONTROL_2DPOINT);
if (((v_KEY6591_9) == (LREF(s_lsp_DYNAMIC_2DSCOPE_2DCONTROL_2DPOINT)))) {
goto t_C6594_13;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 62:
v_X_110 = v_KEY6591_9;
v_Y_111 = LREF(s_lsp_CATCH_2DCONTROL_2DPOINT);
if (((v_KEY6591_9) == (LREF(s_lsp_CATCH_2DCONTROL_2DPOINT)))) {
goto t_C6594_13;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 410:
v_X_113 = v_KEY6591_9;
v_Y_114 = LREF(s_lsp_DYNAMIC_2DBLOCK_2DCONTROL_2DPOINT);
if (((v_KEY6591_9) == (LREF(s_lsp_DYNAMIC_2DBLOCK_2DCONTROL_2DPOINT)))) {
goto t_C6594_13;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 388:
v_X_116 = v_KEY6591_9;
v_Y_117 = LREF(s_lsp_STATIC_2DSCOPE_2DCONTROL_2DPOINT);
if (((v_KEY6591_9) == (LREF(s_lsp_STATIC_2DSCOPE_2DCONTROL_2DPOINT)))) {
goto t_C6594_13;
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
case 288:
v_X_119 = v_KEY6591_9;
v_Y_120 = LREF(s_lsp_CONSTANT);
if (((v_KEY6591_9) == (LREF(s_lsp_CONSTANT)))) {
t5 = ICALL(s_lsp_IMPROVE_2DCONSTANT) (MV_CALL(argc,2), v_TREE_0, v_DEAD_3F_1);
return(t5);
} else {
goto t_DEFAULT_2DTAG6592_10;
}
break;
default:
goto t_DEFAULT_2DTAG6592_10;
break;
}
return(t5);
}
t_DEFAULT_2DTAG6592_10:;
goto t_DEFAULT_2DTAG6589_5;
return(NIL);
t_C6596_11:;
t44 = ICALL(s_lsp_IMPROVE_2DSEQ) (MV_CALL(argc,2), v_TREE_0, v_DEAD_3F_1);
return(t44);
return(NIL);
t_C6595_12:;
t45 = ICALL(s_lsp_IMPROVE_2DFUNCTION_2DCALL) (MV_CALL(argc,2), v_TREE_0, v_DEAD_3F_1);
return(t45);
return(NIL);
t_C6594_13:;
t46 = ICALL(s_lsp_IMPROVE_2DCONTROL_2DPOINT) (MV_CALL(argc,1), v_TREE_0);
return(t46);
return(NIL);
return(NIL);
break;
default:
goto t_DEFAULT_2DTAG6589_5;
break;
}
}
return(t1);
t_DEFAULT_2DTAG6589_5:;
return(v_TREE_0);
return(NIL);
return(NIL);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_IMPROVE_2DCONSTANT(argc, v_TREE_0, v_DEAD_3F_1)
      ARGC argc;  LP v_TREE_0; LP v_DEAD_3F_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
if (v_DEAD_3F_1 != NIL) {
return(LREF(s_lsp_NIL));
} else {
return(v_TREE_0);
}
}

LP p_lsp_IMPROVE_2DLIST(va_alist) va_dcl
{
LP v_X_19; LP v_V_17; LP v_X_16; 
LP v_T6598_15; LP v_S6597_14; LP v_Y_12; 
LP v_X_11; LP v_X_9; LP v_REST_5; 
LP v_END_4; LP v_L_0; LP v_BODY_3F_2; 
LP v_DEAD_3F_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_L_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 3) wna_high(real_argc,3);
if (real_argc < 2) {
v_DEAD_3F_1 = NIL;
} else {
v_DEAD_3F_1 = NEXT_VAR_ARG;
}
if (real_argc < 3) {
v_BODY_3F_2 = NIL;
} else {
v_BODY_3F_2 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
v_END_4 = ICALL(s_lsp_LAST) (1, v_L_0);
v_REST_5 = v_L_0;
t_NEXT_2DLOOP_7:;
if (v_REST_5 == NIL) {
goto t_END_2DLOOP_8;
}
v_X_9 = v_REST_5;
t1 = ((LP) DEREF((v_X_9) + 0 * 4));
v_X_11 = v_REST_5;
if (((v_X_11) == (v_END_4))) {
t2 = v_DEAD_3F_1;
} else {
t2 = v_BODY_3F_2;
}
v_S6597_14 = ICALL(s_lsp_IMPROVE) (2, t1, t2);
v_T6598_15 = v_REST_5;
v_V_17 = v_S6597_14;
((LP) (DEREF((v_T6598_15) + 0 * 4) = (LD) (v_V_17)));
v_X_19 = v_REST_5;
v_REST_5 = ((LP) DEREF((v_X_19) + 1 * 4));
goto t_NEXT_2DLOOP_7;
goto t_END_2DLOOP_8;
t_END_2DLOOP_8:;
return(v_L_0);
return(NIL);
return(NIL);
}

LP p_lsp_IMPROVE_2DSEQ(argc, v_TREE_0, v_DEAD_3F_1)
      ARGC argc;  LP v_TREE_0; LP v_DEAD_3F_1;
{
LP v_VALUE_45; LP v_N_44; LP v_S_43; 
LP v_VALUE_41; LP v_S_40; LP v_T6602_39; 
LP v_S6601_38; LP v_X_36; LP v_G6603_35; 
LP v_Y_33; LP v_X_32; LP v_X_30; 
LP v_X_28; LP v_BODY_27; LP v_I_25; 
LP v_S_24; LP v_S_22; LP v_VALUE_20; 
LP v_N_19; LP v_S_18; LP v_VALUE_16; 
LP v_S_15; LP v_T6600_14; LP v_S6599_13; 
LP v_I_11; LP v_S_10; LP v_S_8; 
LP v_I_6; LP v_S_5; LP v_S_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_VALUES_2DSEQ_2DP) (1, v_TREE_0);
if (t0 != NIL) {
v_S_3 = v_TREE_0;
v_S_5 = v_TREE_0;
v_I_6 = (LP) 14;
t1 = ((LP) DEREF((v_TREE_0) + 7 * 4));
ICALL(s_lsp_IMPROVE_2DLIST) (1, t1);
}
t2 = ICALL(s_lsp_SCOPE_2DSEQ_2DP) (1, v_TREE_0);
if (t2 != NIL) {
v_S_8 = v_TREE_0;
v_S_10 = v_TREE_0;
v_I_11 = (LP) 14;
t3 = ((LP) DEREF((v_TREE_0) + 7 * 4));
v_S6599_13 = ICALL(s_lsp_IMPROVE) (1, t3);
v_T6600_14 = v_TREE_0;
v_S_15 = v_TREE_0;
v_VALUE_16 = v_S6599_13;
v_S_18 = v_TREE_0;
v_N_19 = (LP) 14;
v_VALUE_20 = v_S6599_13;
((LP) (DEREF((v_TREE_0) + 7 * 4) = (LD) (v_S6599_13)));
}
v_S_22 = v_TREE_0;
v_S_24 = v_TREE_0;
v_I_25 = (LP) 12;
v_BODY_27 = ((LP) DEREF((v_TREE_0) + 6 * 4));
v_X_28 = v_BODY_27;
v_X_30 = v_X_28;
v_X_32 = v_X_28;
v_Y_33 = LREF(s_lsp_NIL);
v_G6603_35 = (((v_X_28) == (LREF(s_lsp_NIL))) ? T : NIL);
if (v_G6603_35 != NIL) {
t4 = v_G6603_35;
} else {
v_X_36 = v_X_28;
t4 = (OTHER_PTRP((v_X_28)) && (TAG((v_X_28)) == 15) ? T : NIL);
}
if (t4 != NIL) {
v_S6601_38 = ICALL(s_lsp_IMPROVE_2DLIST) (3, v_BODY_27, v_DEAD_3F_1, LREF(s_lsp_T));
} else {
v_S6601_38 = ICALL(s_lsp_IMPROVE) (1, v_BODY_27);
}
v_T6602_39 = v_TREE_0;
v_S_40 = v_TREE_0;
v_VALUE_41 = v_S6601_38;
v_S_43 = v_TREE_0;
v_N_44 = (LP) 12;
v_VALUE_45 = v_S6601_38;
((LP) (DEREF((v_TREE_0) + 6 * 4) = (LD) (v_S6601_38)));
return(v_TREE_0);
}

LP p_lsp_IMPROVE_2DVALUES(argc, v_TREE_0, v_DEAD_3F_1)
      ARGC argc;  LP v_TREE_0; LP v_DEAD_3F_1;
{
LP v_I_6; LP v_S_5; LP v_S_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
v_S_3 = v_TREE_0;
v_S_5 = v_TREE_0;
v_I_6 = (LP) 12;
t0 = ((LP) DEREF((v_TREE_0) + 6 * 4));
ICALL(s_lsp_IMPROVE_2DLIST) (2, t0, v_DEAD_3F_1);
return(v_TREE_0);
}

LP p_lsp_IMPROVE_2DVAR_2DREF(argc, v_TREE_0, v_DEAD_3F_1)
      ARGC argc;  LP v_TREE_0; LP v_DEAD_3F_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 2) wna(argc,2);
if (v_DEAD_3F_1 != NIL) {
return(LREF(s_lsp_NIL));
} else {
return(v_TREE_0);
}
}

LP p_lsp_IMPROVE_2DVAR_2DDEF(argc, v_TREE_0)
      ARGC argc;  LP v_TREE_0;
{
LP v_VALUE_14; LP v_N_13; LP v_S_12; 
LP v_VALUE_10; LP v_S_9; LP v_T6605_8; 
LP v_S6604_7; LP v_I_5; LP v_S_4; 
LP v_S_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; 
if (argc != 1) wna(argc,1);
v_S_2 = v_TREE_0;
v_S_4 = v_TREE_0;
v_I_5 = (LP) 16;
t0 = ((LP) DEREF((v_TREE_0) + 8 * 4));
v_S6604_7 = ICALL(s_lsp_IMPROVE) (1, t0);
v_T6605_8 = v_TREE_0;
v_S_9 = v_TREE_0;
v_VALUE_10 = v_S6604_7;
v_S_12 = v_TREE_0;
v_N_13 = (LP) 16;
v_VALUE_14 = v_S6604_7;
((LP) (DEREF((v_TREE_0) + 8 * 4) = (LD) (v_S6604_7)));
return(v_TREE_0);
}

LP p_lsp_IMPROVE_2DFUNCTION_2DCALL(argc, v_TREE_0, v_DEAD_3F_1)
      ARGC argc;  LP v_TREE_0; LP v_DEAD_3F_1;
{
LP v_Y_233; LP v_X_232; LP v_X_230; 
LP v_I_228; LP v_S_227; LP v_S_225; 
LP v_I_223; LP v_S_222; LP v_S_220; 
LP v_NEW_219; LP v_X_217; LP v_NAME_215; 
LP v_INFO_214; LP v_ARGS_213; LP v_RESULT_2DNAME_212; 
LP v_LINE_211; LP v_OUT_2DTYPE_210; LP v_MV_2DHOLDER_209; 
LP v_TAIL_3F_208; LP v_I_206; LP v_S_205; 
LP v_S_203; LP v_I_201; LP v_S_200; 
LP v_S_198; LP v_I_196; LP v_S_195; 
LP v_S_193; LP v_I_191; LP v_S_190; 
LP v_S_188; LP v_I_186; LP v_S_185; 
LP v_S_183; LP v_NAME_182; LP v_INFO_181; 
LP v_ARGS_180; LP v_RESULT_2DNAME_179; LP v_SYMBOL_177; 
LP v_LINE_176; LP v_OUT_2DTYPE_175; LP v_MV_2DHOLDER_174; 
LP v_TAIL_3F_173; LP v_EMIT_2DAS_2DGOTO_3F_171; LP v_NAME_170; 
LP v_INFO_169; LP v_ARGS_168; LP v_RESULT_2DNAME_167; 
LP v_LINE_166; LP v_OUT_2DTYPE_165; LP v_MV_2DHOLDER_164; 
LP v_TAIL_3F_163; LP v_I_161; LP v_S_160; 
LP v_S_158; LP v_I_156; LP v_S_155; 
LP v_S_153; LP v_I_151; LP v_S_150; 
LP v_S_148; LP v_I_146; LP v_S_145; 
LP v_S_143; LP v_I_141; LP v_S_140; 
LP v_S_138; LP v_I_136; LP v_S_135; 
LP v_S_133; LP v_EMIT_2DAS_2DGOTO_3F_132; LP v_NAME_131; 
LP v_INFO_130; LP v_ARGS_129; LP v_RESULT_2DNAME_128; 
LP v_SYMBOL_126; LP v_LINE_125; LP v_OUT_2DTYPE_124; 
LP v_MV_2DHOLDER_123; LP v_TAIL_3F_122; LP v_KEY6613_121; 
LP v_S_119; LP v_KEY6612_117; LP v_KEY6609_115; 
LP v_INFO_114; LP v_I_112; LP v_S_111; 
LP v_S_109; LP v_Y_107; LP v_X_106; 
LP v_X_104; LP v_METHOD_103; LP v_DATA_101; 
LP v_RESULT_2DNAME_100; LP v_LINE_99; LP v_OUT_2DTYPE_98; 
LP v_MV_2DHOLDER_97; LP v_TAIL_3F_96; LP v_I_94; 
LP v_S_93; LP v_S_91; LP v_I_89; 
LP v_S_88; LP v_S_86; LP v_I_84; 
LP v_S_83; LP v_S_81; LP v_DATA_80; 
LP v_RESULT_2DNAME_79; LP v_SYMBOL_77; LP v_LINE_76; 
LP v_OUT_2DTYPE_75; LP v_MV_2DHOLDER_74; LP v_TAIL_3F_73; 
LP v_CONST_72; LP v_I_70; LP v_S_69; 
LP v_S_67; LP v_X_65; LP v_V_63; 
LP v_X_62; LP v_NEW_2DCDR_60; LP v_C_59; 
LP v_Y_57; LP v_X_56; LP v_I_54; 
LP v_S_53; LP v_S_51; LP v_X_49; 
LP v_X_47; LP v_LOOPVAR_2D1392_43; LP v_LOOPVAR_2D1391_42; 
LP v_LOOPVAR_2D1390_41; LP v_LOOP_2DLIST_2D1389_40; LP v_L6608_39; 
LP v_I_37; LP v_S_36; LP v_S_34; 
LP v_META_2DEVAL_2DARG_2DTYPES_33; LP v_I_31; LP v_S_30; 
LP v_S_28; LP v_INFO_27; LP v_I_25; 
LP v_S_24; LP v_S_22; LP v_I_20; 
LP v_S_19; LP v_S_17; LP v_VALUE_15; 
LP v_N_14; LP v_S_13; LP v_VALUE_11; 
LP v_S_10; LP v_T6607_9; LP v_S6606_8; 
LP v_I_6; LP v_S_5; LP v_S_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; LP t145; LP t146; LP t147; LP t148; LP t149; 
LP t150; LP t151; LP t152; LP t153; LP t154; LP t155; 
LP t156; LP t157; LP t158; LP t159; LP t160; LP t161; 
LP t162; 
if (argc != 2) wna(argc,2);
t0 = ICALL(s_lsp_UNNAMED_2DCALL_2DP) (1, v_TREE_0);
if (t0 != NIL) {
v_S_3 = v_TREE_0;
v_S_5 = v_TREE_0;
v_I_6 = (LP) 20;
t1 = ((LP) DEREF((v_TREE_0) + 10 * 4));
v_S6606_8 = ICALL(s_lsp_IMPROVE) (1, t1);
v_T6607_9 = v_TREE_0;
v_S_10 = v_TREE_0;
v_VALUE_11 = v_S6606_8;
v_S_13 = v_TREE_0;
v_N_14 = (LP) 20;
v_VALUE_15 = v_S6606_8;
((LP) (DEREF((v_TREE_0) + 10 * 4) = (LD) (v_S6606_8)));
}
v_S_17 = v_TREE_0;
v_S_19 = v_TREE_0;
v_I_20 = (LP) 12;
t2 = ((LP) DEREF((v_TREE_0) + 6 * 4));
ICALL(s_lsp_IMPROVE_2DLIST) (1, t2);
v_S_22 = v_TREE_0;
v_S_24 = v_TREE_0;
v_I_25 = (LP) 14;
v_INFO_27 = ((LP) DEREF((v_TREE_0) + 7 * 4));
if (v_INFO_27 != NIL) {
v_S_28 = v_INFO_27;
v_S_30 = v_INFO_27;
v_I_31 = (LP) 12;
v_META_2DEVAL_2DARG_2DTYPES_33 = ((LP) DEREF((v_INFO_27) + 6 * 4));
} else {
v_META_2DEVAL_2DARG_2DTYPES_33 = LREF(s_lsp_NIL);
}
v_X_230 = v_META_2DEVAL_2DARG_2DTYPES_33;
v_X_232 = v_META_2DEVAL_2DARG_2DTYPES_33;
v_Y_233 = LREF(s_lsp_NIL);
if (v_META_2DEVAL_2DARG_2DTYPES_33 != NIL) {
v_S_225 = v_TREE_0;
v_S_227 = v_TREE_0;
v_I_228 = (LP) 12;
t5 = ((LP) DEREF((v_TREE_0) + 6 * 4));
t4 = ICALL(s_lsp_EVERY) (3, LREF(k10870), t5, v_META_2DEVAL_2DARG_2DTYPES_33);
} else {
t4 = LREF(s_lsp_NIL);
}
if (t4 != NIL) {
v_L6608_39 = LREF(s_lsp_NIL);
v_S_34 = v_TREE_0;
v_S_36 = v_TREE_0;
v_I_37 = (LP) 12;
v_LOOP_2DLIST_2D1389_40 = ((LP) DEREF((v_TREE_0) + 6 * 4));
v_LOOPVAR_2D1390_41 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1391_42 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1392_43 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_45:;
if (v_LOOP_2DLIST_2D1389_40 == NIL) {
goto t_END_2DLOOP_46;
}
v_X_47 = v_LOOP_2DLIST_2D1389_40;
v_L6608_39 = ((LP) DEREF((v_X_47) + 0 * 4));
v_X_49 = v_LOOP_2DLIST_2D1389_40;
v_LOOP_2DLIST_2D1389_40 = ((LP) DEREF((v_X_49) + 1 * 4));
v_S_51 = v_L6608_39;
v_S_53 = v_S_51;
v_I_54 = (LP) 12;
v_X_56 = ((LP) DEREF((v_S_51) + 6 * 4));
v_LOOPVAR_2D1392_43 = (c_cons((v_X_56), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D1391_42 != NIL) {
v_C_59 = v_LOOPVAR_2D1391_42;
v_NEW_2DCDR_60 = v_LOOPVAR_2D1392_43;
v_V_63 = v_NEW_2DCDR_60;
((LP) (DEREF((v_C_59) + 1 * 4) = (LD) (v_V_63)));
v_X_65 = v_C_59;
v_LOOPVAR_2D1391_42 = ((LP) DEREF((v_X_65) + 1 * 4));
} else {
v_LOOPVAR_2D1390_41 = v_LOOPVAR_2D1392_43;
v_LOOPVAR_2D1391_42 = v_LOOPVAR_2D1390_41;
}
goto t_NEXT_2DLOOP_45;
goto t_END_2DLOOP_46;
t_END_2DLOOP_46:;
t6 = v_LOOPVAR_2D1390_41;
goto b_NIL_44;
t6 = NIL;
b_NIL_44:;
v_S_67 = v_INFO_27;
v_S_69 = v_INFO_27;
v_I_70 = (LP) 14;
t7 = ((LP) DEREF((v_INFO_27) + 7 * 4));
v_CONST_72 = p_lsp_APPLY(2, COERCE_TO_FUNCTION(t7), t6);
v_S_81 = v_TREE_0;
v_S_83 = v_TREE_0;
v_I_84 = (LP) 2;
v_TAIL_3F_96 = ((LP) DEREF((v_TREE_0) + 1 * 4));
v_S_86 = v_TREE_0;
v_S_88 = v_TREE_0;
v_I_89 = (LP) 4;
v_MV_2DHOLDER_97 = ((LP) DEREF((v_TREE_0) + 2 * 4));
t8 = ICALL(s_lsp_TYPE_2DOF) (1, v_CONST_72);
v_OUT_2DTYPE_98 = ICALL(s_lsp_TYPE_2DMACROEXPAND) (1, t8);
v_S_91 = v_TREE_0;
v_S_93 = v_TREE_0;
v_I_94 = (LP) 8;
v_LINE_99 = ((LP) DEREF((v_TREE_0) + 4 * 4));
t9 = ICALL(s_lsp_MAKE_2DCONSTANT_2F6) (6, v_TAIL_3F_96, v_MV_2DHOLDER_97, v_OUT_2DTYPE_98, v_LINE_99, LREF(s_lsp_NIL), v_CONST_72);
t3 = ICALL(s_lsp_IMPROVE) (MV_CALL(argc,2), t9, v_DEAD_3F_1);
return(t3);
} else {
v_METHOD_103 = ICALL(s_lsp_FUNCTION_2DCALL_2DREWRITE_2DMETHOD) (1, v_TREE_0);
if (v_METHOD_103 != NIL) {
v_S_109 = v_METHOD_103;
v_S_111 = v_METHOD_103;
v_I_112 = (LP) 16;
t10 = ((LP) DEREF((v_METHOD_103) + 8 * 4));
v_INFO_114 = ICALL(s_lsp_GET_2DOR_2DCREATE_2DPROC_2DINFO) (1, t10);
v_KEY6609_115 = v_INFO_114;
v_KEY6612_117 = v_KEY6609_115;
v_X_217 = v_KEY6612_117;
if (FIXNUMP((v_KEY6612_117))) {
goto t_DEFAULT_2DTAG6611_118;
} else {
t13 = INT_TO_FX(((int) TAG((v_KEY6612_117))));
switch ((int) t13) {
case 94:
v_S_119 = v_KEY6612_117;
v_KEY6613_121 = ((LP) DEREF((v_KEY6612_117) + 0 * 4));
t14 = ICALL(s_lsp_MEMQL) (2, v_KEY6613_121, LREF(k10871));
if (t14 != NIL) {
v_S_133 = v_TREE_0;
v_S_135 = v_TREE_0;
v_I_136 = (LP) 2;
v_TAIL_3F_163 = ((LP) DEREF((v_TREE_0) + 1 * 4));
v_S_138 = v_TREE_0;
v_S_140 = v_TREE_0;
v_I_141 = (LP) 4;
v_MV_2DHOLDER_164 = ((LP) DEREF((v_TREE_0) + 2 * 4));
v_S_143 = v_TREE_0;
v_S_145 = v_TREE_0;
v_I_146 = (LP) 6;
v_OUT_2DTYPE_165 = ((LP) DEREF((v_TREE_0) + 3 * 4));
v_S_148 = v_TREE_0;
v_S_150 = v_TREE_0;
v_I_151 = (LP) 8;
v_LINE_166 = ((LP) DEREF((v_TREE_0) + 4 * 4));
v_S_153 = v_TREE_0;
v_S_155 = v_TREE_0;
v_I_156 = (LP) 12;
v_ARGS_168 = ((LP) DEREF((v_TREE_0) + 6 * 4));
v_S_158 = v_INFO_114;
v_S_160 = v_INFO_114;
v_I_161 = (LP) 2;
v_NAME_170 = ((LP) DEREF((v_INFO_114) + 1 * 4));
t11 = ICALL(s_lsp_MAKE_2DNAMED_2DCALL_2F9) (9, v_TAIL_3F_163, v_MV_2DHOLDER_164, v_OUT_2DTYPE_165, v_LINE_166, LREF(s_lsp_NIL), v_ARGS_168, v_INFO_114, v_NAME_170, LREF(s_lsp_NIL));
} else {
t15 = ICALL(s_lsp_MEMQL) (2, v_KEY6613_121, LREF(k10872));
if (t15 != NIL) {
v_S_183 = v_TREE_0;
v_S_185 = v_TREE_0;
v_I_186 = (LP) 2;
v_TAIL_3F_208 = ((LP) DEREF((v_TREE_0) + 1 * 4));
v_S_188 = v_TREE_0;
v_S_190 = v_TREE_0;
v_I_191 = (LP) 4;
v_MV_2DHOLDER_209 = ((LP) DEREF((v_TREE_0) + 2 * 4));
v_S_193 = v_TREE_0;
v_S_195 = v_TREE_0;
v_I_196 = (LP) 6;
v_OUT_2DTYPE_210 = ((LP) DEREF((v_TREE_0) + 3 * 4));
v_S_198 = v_TREE_0;
v_S_200 = v_TREE_0;
v_I_201 = (LP) 8;
v_LINE_211 = ((LP) DEREF((v_TREE_0) + 4 * 4));
v_S_203 = v_TREE_0;
v_S_205 = v_TREE_0;
v_I_206 = (LP) 12;
v_ARGS_213 = ((LP) DEREF((v_TREE_0) + 6 * 4));
t11 = ICALL(s_lsp_MAKE_2DPRIMITIVE_2DCALL_2F8) (8, v_TAIL_3F_208, v_MV_2DHOLDER_209, v_OUT_2DTYPE_210, v_LINE_211, LREF(s_lsp_NIL), v_ARGS_213, v_INFO_114, LREF(s_lsp_NIL));
} else {
goto t_DEFAULT_2DTAG6611_118;
}
}
break;
default:
goto t_DEFAULT_2DTAG6611_118;
break;
}
}
v_NEW_219 = t11;
goto b_TYPECASE6610_116;
t_DEFAULT_2DTAG6611_118:;
t16 = ICALL(s_lsp_ERROR) (3, LREF(k10873), v_KEY6609_115, LREF(k10874));
v_NEW_219 = t16;
goto b_TYPECASE6610_116;
v_NEW_219 = NIL;
v_NEW_219 = v_NEW_219;
b_TYPECASE6610_116:;
v_S_220 = v_METHOD_103;
v_S_222 = v_METHOD_103;
v_I_223 = (LP) 18;
t17 = ((LP) DEREF((v_METHOD_103) + 9 * 4));
CODE_PTR(COERCE_TO_FUNCTION(t17))(1, v_NEW_219);
t3 = ICALL(s_lsp_IMPROVE) (MV_CALL(argc,2), v_NEW_219, v_DEAD_3F_1);
return(t3);
} else {
if (v_DEAD_3F_1 != NIL) {
v_X_104 = ICALL(s_lsp_FUNCTION_2DCALL_2DSIDE_2DEFFECTS_3F) (1, v_TREE_0);
v_X_106 = v_X_104;
v_Y_107 = LREF(s_lsp_NIL);
t18 = (((v_X_104) == (LREF(s_lsp_NIL))) ? T : NIL);
} else {
t18 = LREF(s_lsp_NIL);
}
if (t18 != NIL) {
return(LREF(s_lsp_NIL));
} else {
return(v_TREE_0);
}
}
}
}

LP p_lsp_IMPROVE_2DFUNCTION_2DCALL_2Danon1086810869(argc, v_ARG_0, v_TYPE_1)
      ARGC argc;  LP v_ARG_0; LP v_TYPE_1;
{
LP v_I_5; LP v_S_4; LP v_S_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; 
if (argc != 2) wna(argc,2);
t1 = ICALL(s_lsp_CONSTANT_2DP) (1, v_ARG_0);
if (t1 != NIL) {
v_S_2 = v_ARG_0;
v_S_4 = v_ARG_0;
v_I_5 = (LP) 12;
t2 = ((LP) DEREF((v_ARG_0) + 6 * 4));
t0 = ICALL(s_lsp_TYPEP) (MV_CALL(argc,2), t2, v_TYPE_1);
return(t0);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_FUNCTION_2DCALL_2DREWRITE_2DMETHOD(argc, v_CALL_0)
      ARGC argc;  LP v_CALL_0;
{
LP v_Y_27; LP v_X_26; LP v_X_24; 
LP v_G6615_23; LP v_TMP6614_22; LP v_X_20; 
LP v_X_18; LP v_LOOP_2DLIST_2D1393_14; LP v_METHOD_13; 
LP v_I_11; LP v_S_10; LP v_S_8; 
LP v_INFO_7; LP v_I_5; LP v_S_4; 
LP v_S_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; 
if (argc != 1) wna(argc,1);
v_S_2 = v_CALL_0;
v_S_4 = v_CALL_0;
v_I_5 = (LP) 14;
v_INFO_7 = ((LP) DEREF((v_CALL_0) + 7 * 4));
v_X_24 = v_INFO_7;
v_X_26 = v_INFO_7;
v_Y_27 = LREF(s_lsp_NIL);
if (v_INFO_7 != NIL) {
v_TMP6614_22 = v_CALL_0;
v_G6615_23 = ICALL(s_lsp_NAMED_2DCALL_2DP) (1, v_TMP6614_22);
if (v_G6615_23 != NIL) {
t1 = v_G6615_23;
} else {
t1 = ICALL(s_lsp_FOREIGN_2DCALL_2DP) (1, v_TMP6614_22);
}
if (t1 != NIL) {
v_METHOD_13 = LREF(s_lsp_NIL);
v_S_8 = v_INFO_7;
v_S_10 = v_INFO_7;
v_I_11 = (LP) 16;
v_LOOP_2DLIST_2D1393_14 = ((LP) DEREF((v_INFO_7) + 8 * 4));
t_NEXT_2DLOOP_16:;
if (v_LOOP_2DLIST_2D1393_14 == NIL) {
goto t_END_2DLOOP_17;
}
v_X_18 = v_LOOP_2DLIST_2D1393_14;
v_METHOD_13 = ((LP) DEREF((v_X_18) + 0 * 4));
v_X_20 = v_LOOP_2DLIST_2D1393_14;
v_LOOP_2DLIST_2D1393_14 = ((LP) DEREF((v_X_20) + 1 * 4));
t2 = ICALL(s_lsp_CALL_2DMATCHES_2DMETHOD_2DTYPE_2DSIGNATURE_3F) (2, v_CALL_0, v_METHOD_13);
if (t2 != NIL) {
return(v_METHOD_13);
return(NIL);
}
goto t_NEXT_2DLOOP_16;
goto t_END_2DLOOP_17;
t_END_2DLOOP_17:;
return(LREF(s_lsp_NIL));
return(NIL);
return(NIL);
} else {
return(LREF(s_lsp_NIL));
}
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_CALL_2DMATCHES_2DMETHOD_2DTYPE_2DSIGNATURE_3F(argc, v_CALL_0, v_METHOD_1)
      ARGC argc;  LP v_CALL_0; LP v_METHOD_1;
{
LP v_Y_55; LP v_X_54; LP v_X_52; 
LP v_I_50; LP v_S_49; LP v_S_47; 
LP v_I_45; LP v_S_44; LP v_S_42; 
LP v_X_40; LP v_X_38; LP v_X_36; 
LP v_X_34; LP v_LOOP_2DLIST_2D1395_30; LP v_METHOD_2DARG_2DTYPE_29; 
LP v_I_27; LP v_S_26; LP v_S_24; 
LP v_LOOP_2DLIST_2D1394_23; LP v_ARG_22; LP v_I_20; 
LP v_S_19; LP v_S_17; LP v_X_15; 
LP v_LIST_13; LP v_I_11; LP v_S_10; 
LP v_S_8; LP v_I_6; LP v_S_5; 
LP v_S_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; 
if (argc != 2) wna(argc,2);
v_ARG_22 = LREF(s_lsp_NIL);
v_S_17 = v_CALL_0;
v_S_19 = v_CALL_0;
v_I_20 = (LP) 12;
v_LOOP_2DLIST_2D1394_23 = ((LP) DEREF((v_CALL_0) + 6 * 4));
v_METHOD_2DARG_2DTYPE_29 = LREF(s_lsp_NIL);
v_S_24 = v_METHOD_1;
v_S_26 = v_METHOD_1;
v_I_27 = (LP) 8;
v_LOOP_2DLIST_2D1395_30 = ((LP) DEREF((v_METHOD_1) + 4 * 4));
t_NEXT_2DLOOP_32:;
if (v_LOOP_2DLIST_2D1394_23 == NIL) {
goto t_END_2DLOOP_33;
}
v_X_34 = v_LOOP_2DLIST_2D1394_23;
v_ARG_22 = ((LP) DEREF((v_X_34) + 0 * 4));
v_X_36 = v_LOOP_2DLIST_2D1394_23;
v_LOOP_2DLIST_2D1394_23 = ((LP) DEREF((v_X_36) + 1 * 4));
if (v_LOOP_2DLIST_2D1395_30 == NIL) {
goto t_END_2DLOOP_33;
}
v_X_38 = v_LOOP_2DLIST_2D1395_30;
v_METHOD_2DARG_2DTYPE_29 = ((LP) DEREF((v_X_38) + 0 * 4));
v_X_40 = v_LOOP_2DLIST_2D1395_30;
v_LOOP_2DLIST_2D1395_30 = ((LP) DEREF((v_X_40) + 1 * 4));
v_S_47 = v_ARG_22;
v_S_49 = v_S_47;
v_I_50 = (LP) 6;
v_X_52 = ((LP) DEREF((v_S_47) + 3 * 4));
v_X_54 = v_X_52;
v_Y_55 = LREF(s_lsp_NIL);
if (v_X_52 != NIL) {
v_S_42 = v_ARG_22;
v_S_44 = v_S_42;
v_I_45 = (LP) 6;
t3 = ((LP) DEREF((v_S_42) + 3 * 4));
t2 = ICALL(s_lsp_SUBTYPEP) (2, t3, v_METHOD_2DARG_2DTYPE_29);
} else {
t2 = LREF(s_lsp_NIL);
}
if (t2 == NIL) {
t1 = LREF(s_lsp_NIL);
goto b_NIL_31;
}
goto t_NEXT_2DLOOP_32;
goto t_END_2DLOOP_33;
t_END_2DLOOP_33:;
t1 = LREF(s_lsp_T);
goto b_NIL_31;
t1 = NIL;
b_NIL_31:;
if (t1 != NIL) {
v_S_3 = v_CALL_0;
v_S_5 = v_CALL_0;
v_I_6 = (LP) 6;
t4 = ((LP) DEREF((v_CALL_0) + 3 * 4));
v_S_8 = v_METHOD_1;
v_S_10 = v_METHOD_1;
v_I_11 = (LP) 10;
v_LIST_13 = ((LP) DEREF((v_METHOD_1) + 5 * 4));
v_X_15 = v_LIST_13;
t5 = ((LP) DEREF((v_LIST_13) + 0 * 4));
t0 = ICALL(s_lsp_SUBTYPEP) (MV_CALL(argc,2), t4, t5);
return(t0);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_IMPROVE_2DIF(argc, v_TREE_0, v_DEAD_3F_1)
      ARGC argc;  LP v_TREE_0; LP v_DEAD_3F_1;
{
LP v_Y_210; LP v_X_209; LP v_X_207; 
LP v_X_205; LP v_LIST_203; LP v_Y_201; 
LP v_X_200; LP v_I_198; LP v_S_197; 
LP v_S_195; LP v_X_193; LP v_X_191; 
LP v_C_189; LP v_LIST_187; LP v_Y_185; 
LP v_X_184; LP v_X_182; LP v_I_180; 
LP v_S_179; LP v_S_177; LP v_X_175; 
LP v_X_173; LP v_C_171; LP v_LIST_169; 
LP v_Y_167; LP v_X_166; LP v_SYMBOL_164; 
LP v_X_162; LP v_I_160; LP v_S_159; 
LP v_S_157; LP v_VALUE_155; LP v_N_154; 
LP v_S_153; LP v_VALUE_151; LP v_S_150; 
LP v_T6635_149; LP v_S6634_148; LP v_SYMBOL_146; 
LP v_VALUE_144; LP v_N_143; LP v_S_142; 
LP v_VALUE_140; LP v_S_139; LP v_T6633_138; 
LP v_S6632_137; LP v_Y_135; LP v_X_134; 
LP v_X_132; LP v_LIST_130; LP v_VALUE_128; 
LP v_N_127; LP v_S_126; LP v_VALUE_124; 
LP v_S_123; LP v_T6631_122; LP v_S6630_121; 
LP v_X_119; LP v_LIST_117; LP v_VALUE_115; 
LP v_N_114; LP v_S_113; LP v_VALUE_111; 
LP v_S_110; LP v_VALUE_108; LP v_N_107; 
LP v_S_106; LP v_VALUE_104; LP v_S_103; 
LP v_S6626_102; LP v_I_100; LP v_S_99; 
LP v_S_97; LP v_T6629_96; LP v_S6628_95; 
LP v_I_93; LP v_S_92; LP v_S_90; 
LP v_T6627_89; LP v_ARGS_88; LP v_I_86; 
LP v_S_85; LP v_S_83; LP v_INFO_82; 
LP v_I_80; LP v_S_79; LP v_S_77; 
LP v_CALL_76; LP v_X_74; LP v_LIST_72; 
LP v_LEAVES_71; LP v_X_69; LP v_I_67; 
LP v_S_66; LP v_S_64; LP v_I_62; 
LP v_S_61; LP v_S_59; LP v_I_57; 
LP v_S_56; LP v_S_54; LP v_KEY6625_53; 
LP v_S_51; LP v_KEY6624_49; LP v_ELSE_47; 
LP v_THEN_46; LP v_TEST_45; LP v_VALUE_43; 
LP v_N_42; LP v_S_41; LP v_VALUE_39; 
LP v_S_38; LP v_T6621_37; LP v_S6620_36; 
LP v_I_34; LP v_S_33; LP v_S_31; 
LP v_VALUE_29; LP v_N_28; LP v_S_27; 
LP v_VALUE_25; LP v_S_24; LP v_T6619_23; 
LP v_S6618_22; LP v_I_20; LP v_S_19; 
LP v_S_17; LP v_VALUE_15; LP v_N_14; 
LP v_S_13; LP v_VALUE_11; LP v_S_10; 
LP v_T6617_9; LP v_S6616_8; LP v_I_6; 
LP v_S_5; LP v_S_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; LP t145; LP t146; LP t147; LP t148; LP t149; 
LP t150; 
if (argc != 2) wna(argc,2);
v_S_3 = v_TREE_0;
v_S_5 = v_TREE_0;
v_I_6 = (LP) 14;
t0 = ((LP) DEREF((v_TREE_0) + 7 * 4));
v_S6616_8 = ICALL(s_lsp_IMPROVE) (1, t0);
v_T6617_9 = v_TREE_0;
v_S_10 = v_TREE_0;
v_VALUE_11 = v_S6616_8;
v_S_13 = v_TREE_0;
v_N_14 = (LP) 14;
v_VALUE_15 = v_S6616_8;
v_TEST_45 = ((LP) (DEREF((v_TREE_0) + 7 * 4) = (LD) (v_S6616_8)));
v_S_17 = v_TREE_0;
v_S_19 = v_TREE_0;
v_I_20 = (LP) 16;
t1 = ((LP) DEREF((v_TREE_0) + 8 * 4));
v_S6618_22 = ICALL(s_lsp_IMPROVE) (2, t1, v_DEAD_3F_1);
v_T6619_23 = v_TREE_0;
v_S_24 = v_TREE_0;
v_VALUE_25 = v_S6618_22;
v_S_27 = v_TREE_0;
v_N_28 = (LP) 16;
v_VALUE_29 = v_S6618_22;
v_THEN_46 = ((LP) (DEREF((v_TREE_0) + 8 * 4) = (LD) (v_S6618_22)));
v_S_31 = v_TREE_0;
v_S_33 = v_TREE_0;
v_I_34 = (LP) 18;
t2 = ((LP) DEREF((v_TREE_0) + 9 * 4));
v_S6620_36 = ICALL(s_lsp_IMPROVE) (2, t2, v_DEAD_3F_1);
v_T6621_37 = v_TREE_0;
v_S_38 = v_TREE_0;
v_VALUE_39 = v_S6620_36;
v_S_41 = v_TREE_0;
v_N_42 = (LP) 18;
v_VALUE_43 = v_S6620_36;
v_ELSE_47 = ((LP) (DEREF((v_TREE_0) + 9 * 4) = (LD) (v_S6620_36)));
if (v_THEN_46 != NIL) {
t4 = LREF(s_lsp_NIL);
} else {
v_X_207 = v_ELSE_47;
v_X_209 = v_ELSE_47;
v_Y_210 = LREF(s_lsp_NIL);
t4 = (((v_ELSE_47) == (LREF(s_lsp_NIL))) ? T : NIL);
}
if (t4 != NIL) {
t3 = ICALL(s_lsp_IMPROVE) (MV_CALL(argc,2), v_TEST_45, v_DEAD_3F_1);
return(t3);
} else {
v_KEY6624_49 = v_TEST_45;
v_X_69 = v_KEY6624_49;
if (FIXNUMP((v_KEY6624_49))) {
goto t_DEFAULT_2DTAG6623_50;
} else {
t7 = INT_TO_FX(((int) TAG((v_KEY6624_49))));
switch ((int) t7) {
case 94:
v_S_51 = v_KEY6624_49;
v_KEY6625_53 = ((LP) DEREF((v_KEY6624_49) + 0 * 4));
t8 = ICALL(s_lsp_MEMQL) (2, v_KEY6625_53, LREF(k10875));
if (t8 != NIL) {
v_S_64 = v_TEST_45;
v_S_66 = v_TEST_45;
v_I_67 = (LP) 12;
t9 = ((LP) DEREF((v_TEST_45) + 6 * 4));
if (t9 != NIL) {
v_S_59 = v_TREE_0;
v_S_61 = v_TREE_0;
v_I_62 = (LP) 16;
t5 = ((LP) DEREF((v_TREE_0) + 8 * 4));
return(t5);
} else {
v_S_54 = v_TREE_0;
v_S_56 = v_TREE_0;
v_I_57 = (LP) 18;
t5 = ((LP) DEREF((v_TREE_0) + 9 * 4));
return(t5);
}
} else {
goto t_DEFAULT_2DTAG6623_50;
}
break;
default:
goto t_DEFAULT_2DTAG6623_50;
break;
}
}
return(t5);
t_DEFAULT_2DTAG6623_50:;
v_LEAVES_71 = ICALL(s_lsp_TAIL_2DLEAVES) (1, v_TEST_45);
t12 = ICALL(s_lsp_LENGTH) (1, v_LEAVES_71);
t11 = (num_equal_p((t12), ((LP) 2)));
if (t11 != NIL) {
v_LIST_203 = v_LEAVES_71;
v_X_205 = v_LEAVES_71;
t13 = ((LP) DEREF((v_LEAVES_71) + 0 * 4));
t10 = ICALL(s_lsp_PRIMITIVE_2DCALL_2DP) (1, t13);
} else {
t10 = LREF(s_lsp_NIL);
}
if (t10 != NIL) {
v_LIST_72 = v_LEAVES_71;
v_X_74 = v_LEAVES_71;
v_CALL_76 = ((LP) DEREF((v_LEAVES_71) + 0 * 4));
v_S_77 = v_CALL_76;
v_S_79 = v_CALL_76;
v_I_80 = (LP) 14;
v_INFO_82 = ((LP) DEREF((v_CALL_76) + 7 * 4));
v_S_83 = v_CALL_76;
v_S_85 = v_CALL_76;
v_I_86 = (LP) 12;
v_ARGS_88 = ((LP) DEREF((v_CALL_76) + 6 * 4));
v_S_195 = v_INFO_82;
v_S_197 = v_INFO_82;
v_I_198 = (LP) 2;
v_X_200 = ((LP) DEREF((v_INFO_82) + 1 * 4));
if (((v_X_200) == (LREF(s_lsp__25EQ)))) {
v_LIST_187 = v_ARGS_88;
v_C_189 = v_ARGS_88;
v_X_191 = v_ARGS_88;
v_X_193 = ((LP) DEREF((v_ARGS_88) + 1 * 4));
t17 = ((LP) DEREF((v_X_193) + 0 * 4));
t16 = ICALL(s_lsp_CONSTANT_2DP) (1, t17);
if (t16 != NIL) {
v_LIST_169 = v_ARGS_88;
v_C_171 = v_ARGS_88;
v_X_173 = v_ARGS_88;
v_X_175 = ((LP) DEREF((v_ARGS_88) + 1 * 4));
v_S_177 = ((LP) DEREF((v_X_175) + 0 * 4));
v_S_179 = v_S_177;
v_I_180 = (LP) 12;
v_X_182 = ((LP) DEREF((v_S_177) + 6 * 4));
v_X_184 = v_X_182;
v_Y_185 = LREF(s_lsp_NIL);
t14 = (((v_X_182) == (LREF(s_lsp_NIL))) ? T : NIL);
} else {
t14 = LREF(s_lsp_NIL);
}
} else {
t14 = LREF(s_lsp_NIL);
}
if (t14 != NIL) {
v_T6627_89 = v_TREE_0;
v_S_90 = v_T6627_89;
v_S_92 = v_T6627_89;
v_I_93 = (LP) 16;
v_S6628_95 = ((LP) DEREF((v_T6627_89) + 8 * 4));
v_T6629_96 = v_TREE_0;
v_S_97 = v_T6629_96;
v_S_99 = v_T6629_96;
v_I_100 = (LP) 18;
v_S6626_102 = ((LP) DEREF((v_T6629_96) + 9 * 4));
v_S_103 = v_T6627_89;
v_VALUE_104 = v_S6626_102;
v_S_106 = v_T6627_89;
v_N_107 = (LP) 16;
v_VALUE_108 = v_S6626_102;
((LP) (DEREF((v_T6627_89) + 8 * 4) = (LD) (v_S6626_102)));
v_S_110 = v_T6629_96;
v_VALUE_111 = v_S6628_95;
v_S_113 = v_T6629_96;
v_N_114 = (LP) 18;
v_VALUE_115 = v_S6628_95;
((LP) (DEREF((v_T6629_96) + 9 * 4) = (LD) (v_S6628_95)));
v_X_134 = v_TEST_45;
v_Y_135 = v_CALL_76;
if (((v_TEST_45) == (v_CALL_76))) {
v_LIST_117 = v_ARGS_88;
v_X_119 = v_ARGS_88;
v_S6630_121 = ((LP) DEREF((v_ARGS_88) + 0 * 4));
v_T6631_122 = v_TREE_0;
v_S_123 = v_TREE_0;
v_VALUE_124 = v_S6630_121;
v_S_126 = v_TREE_0;
v_N_127 = (LP) 14;
v_VALUE_128 = v_S6630_121;
((LP) (DEREF((v_TREE_0) + 7 * 4) = (LD) (v_S6630_121)));
} else {
v_LIST_130 = v_ARGS_88;
v_X_132 = v_ARGS_88;
t19 = ((LP) DEREF((v_ARGS_88) + 0 * 4));
ICALL(s_lsp_TREE_2DNSUBST) (3, t19, v_CALL_76, v_TEST_45);
}
ICALL(s_lsp_IMPROVE_2DIF) (2, v_TREE_0, v_DEAD_3F_1);
} else {
v_S_157 = v_INFO_82;
v_S_159 = v_INFO_82;
v_I_160 = (LP) 10;
v_X_162 = ((LP) DEREF((v_INFO_82) + 5 * 4));
v_X_166 = ((LP) DEREF((v_X_162) + 0 * 4));
v_SYMBOL_164 = LREF(s_lsp_C_2DTYPE_2DIF_2DTEST);
v_Y_167 = ((LP) DEREF((LREF(s_lsp_C_2DTYPE_2DIF_2DTEST)) + 0 * 4));
if (((v_X_166) == (v_Y_167))) {
v_S6632_137 = LREF(s_lsp_T);
v_T6633_138 = v_TREE_0;
v_S_139 = v_TREE_0;
v_VALUE_140 = LREF(s_lsp_T);
v_S_142 = v_TREE_0;
v_N_143 = (LP) 12;
v_VALUE_144 = LREF(s_lsp_T);
((LP) (DEREF((v_TREE_0) + 6 * 4) = (LD) (LREF(s_lsp_T))));
v_SYMBOL_146 = LREF(s_lsp_C_2DTYPE_2DIF_2DTEST);
v_S6634_148 = ((LP) DEREF((LREF(s_lsp_C_2DTYPE_2DIF_2DTEST)) + 0 * 4));
v_T6635_149 = v_CALL_76;
v_S_150 = v_CALL_76;
v_VALUE_151 = v_S6634_148;
v_S_153 = v_CALL_76;
v_N_154 = (LP) 6;
v_VALUE_155 = v_S6634_148;
((LP) (DEREF((v_CALL_76) + 3 * 4) = (LD) (v_S6634_148)));
} else {
}
}
}
return(v_TREE_0);
return(NIL);
return(NIL);
}
}

LP p_lsp_IMPROVE_2DSWITCH(argc, v_TREE_0, v_DEAD_3F_1)
      ARGC argc;  LP v_TREE_0; LP v_DEAD_3F_1;
{
LP v_VALUE_43; LP v_N_42; LP v_S_41; 
LP v_VALUE_39; LP v_S_38; LP v_T6641_37; 
LP v_S6640_36; LP v_I_34; LP v_S_33; 
LP v_S_31; LP v_VALUE_29; LP v_N_28; 
LP v_S_27; LP v_VALUE_25; LP v_S_24; 
LP v_T6639_23; LP v_S6638_22; LP v_I_20; 
LP v_S_19; LP v_S_17; LP v_VALUE_15; 
LP v_N_14; LP v_S_13; LP v_VALUE_11; 
LP v_S_10; LP v_T6637_9; LP v_S6636_8; 
LP v_I_6; LP v_S_5; LP v_S_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; 
if (argc != 2) wna(argc,2);
v_S_3 = v_TREE_0;
v_S_5 = v_TREE_0;
v_I_6 = (LP) 14;
t0 = ((LP) DEREF((v_TREE_0) + 7 * 4));
v_S6636_8 = ICALL(s_lsp_IMPROVE) (1, t0);
v_T6637_9 = v_TREE_0;
v_S_10 = v_TREE_0;
v_VALUE_11 = v_S6636_8;
v_S_13 = v_TREE_0;
v_N_14 = (LP) 14;
v_VALUE_15 = v_S6636_8;
((LP) (DEREF((v_TREE_0) + 7 * 4) = (LD) (v_S6636_8)));
v_S_17 = v_TREE_0;
v_S_19 = v_TREE_0;
v_I_20 = (LP) 18;
t1 = ((LP) DEREF((v_TREE_0) + 9 * 4));
v_S6638_22 = ICALL(s_lsp_IMPROVE_2DLIST) (2, t1, v_DEAD_3F_1);
v_T6639_23 = v_TREE_0;
v_S_24 = v_TREE_0;
v_VALUE_25 = v_S6638_22;
v_S_27 = v_TREE_0;
v_N_28 = (LP) 18;
v_VALUE_29 = v_S6638_22;
((LP) (DEREF((v_TREE_0) + 9 * 4) = (LD) (v_S6638_22)));
v_S_31 = v_TREE_0;
v_S_33 = v_TREE_0;
v_I_34 = (LP) 20;
t2 = ((LP) DEREF((v_TREE_0) + 10 * 4));
v_S6640_36 = ICALL(s_lsp_IMPROVE) (2, t2, v_DEAD_3F_1);
v_T6641_37 = v_TREE_0;
v_S_38 = v_TREE_0;
v_VALUE_39 = v_S6640_36;
v_S_41 = v_TREE_0;
v_N_42 = (LP) 20;
v_VALUE_43 = v_S6640_36;
((LP) (DEREF((v_TREE_0) + 10 * 4) = (LD) (v_S6640_36)));
return(v_TREE_0);
}

LP p_lsp_IMPROVE_2DSCOPE_2DCONTROL_2DTRANSFER(argc, v_TREE_0)
      ARGC argc;  LP v_TREE_0;
{
LP v_VALUE_28; LP v_N_27; LP v_S_26; 
LP v_VALUE_24; LP v_S_23; LP v_T6645_22; 
LP v_S6644_21; LP v_I_19; LP v_S_18; 
LP v_S_16; LP v_VALUE_14; LP v_N_13; 
LP v_S_12; LP v_VALUE_10; LP v_S_9; 
LP v_T6643_8; LP v_S6642_7; LP v_I_5; 
LP v_S_4; LP v_S_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; 
if (argc != 1) wna(argc,1);
v_S_2 = v_TREE_0;
v_S_4 = v_TREE_0;
v_I_5 = (LP) 16;
t0 = ((LP) DEREF((v_TREE_0) + 8 * 4));
v_S6642_7 = ICALL(s_lsp_IMPROVE) (1, t0);
v_T6643_8 = v_TREE_0;
v_S_9 = v_TREE_0;
v_VALUE_10 = v_S6642_7;
v_S_12 = v_TREE_0;
v_N_13 = (LP) 16;
v_VALUE_14 = v_S6642_7;
((LP) (DEREF((v_TREE_0) + 8 * 4) = (LD) (v_S6642_7)));
v_S_16 = v_TREE_0;
v_S_18 = v_TREE_0;
v_I_19 = (LP) 12;
t1 = ((LP) DEREF((v_TREE_0) + 6 * 4));
v_S6644_21 = ICALL(s_lsp_IMPROVE) (1, t1);
v_T6645_22 = v_TREE_0;
v_S_23 = v_TREE_0;
v_VALUE_24 = v_S6644_21;
v_S_26 = v_TREE_0;
v_N_27 = (LP) 12;
v_VALUE_28 = v_S6644_21;
((LP) (DEREF((v_TREE_0) + 6 * 4) = (LD) (v_S6644_21)));
return(v_TREE_0);
}

LP p_lsp_IMPROVE_2DCONTROL_2DPOINT(argc, v_TREE_0)
      ARGC argc;  LP v_TREE_0;
{
LP v_X_36; LP v_VALUE_34; LP v_N_33; 
LP v_S_32; LP v_VALUE_30; LP v_S_29; 
LP v_T6653_28; LP v_S6652_27; LP v_I_25; 
LP v_S_24; LP v_S_22; LP v_VALUE_20; 
LP v_N_19; LP v_S_18; LP v_VALUE_16; 
LP v_S_15; LP v_T6651_14; LP v_S6650_13; 
LP v_I_11; LP v_S_10; LP v_S_8; 
LP v_KEY6649_7; LP v_S_5; LP v_KEY6648_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 

if (argc != 1) wna(argc,1);
v_KEY6648_3 = v_TREE_0;
v_X_36 = v_KEY6648_3;
if (FIXNUMP((v_KEY6648_3))) {
goto t_DEFAULT_2DTAG6647_4;
} else {
t2 = INT_TO_FX(((int) TAG((v_KEY6648_3))));
switch ((int) t2) {
case 94:
v_S_5 = v_KEY6648_3;
v_KEY6649_7 = ((LP) DEREF((v_KEY6648_3) + 0 * 4));
t3 = ICALL(s_lsp_MEMQL) (2, v_KEY6649_7, LREF(k10876));
if (t3 != NIL) {
v_S_8 = v_TREE_0;
v_S_10 = v_TREE_0;
v_I_11 = (LP) 22;
t4 = ((LP) DEREF((v_TREE_0) + 11 * 4));
v_S6650_13 = ICALL(s_lsp_IMPROVE) (1, t4);
v_T6651_14 = v_TREE_0;
v_S_15 = v_TREE_0;
v_VALUE_16 = v_S6650_13;
v_S_18 = v_TREE_0;
v_N_19 = (LP) 22;
v_VALUE_20 = v_S6650_13;
t0 = ((LP) (DEREF((v_TREE_0) + 11 * 4) = (LD) (v_S6650_13)));
} else {
t5 = ICALL(s_lsp_MEMQL) (2, v_KEY6649_7, LREF(k10877));
if (t5 != NIL) {
v_S_22 = v_TREE_0;
v_S_24 = v_TREE_0;
v_I_25 = (LP) 22;
t6 = ((LP) DEREF((v_TREE_0) + 11 * 4));
v_S6652_27 = ICALL(s_lsp_IMPROVE) (1, t6);
v_T6653_28 = v_TREE_0;
v_S_29 = v_TREE_0;
v_VALUE_30 = v_S6652_27;
v_S_32 = v_TREE_0;
v_N_33 = (LP) 22;
v_VALUE_34 = v_S6652_27;
t0 = ((LP) (DEREF((v_TREE_0) + 11 * 4) = (LD) (v_S6652_27)));
} else {
goto t_DEFAULT_2DTAG6647_4;
}
}
break;
default:
goto t_DEFAULT_2DTAG6647_4;
break;
}
}
goto b_TYPECASE6646_2;
t_DEFAULT_2DTAG6647_4:;
goto b_TYPECASE6646_2;
b_TYPECASE6646_2:;
return(v_TREE_0);
}

LP p_lsp_IMPROVE_2DUNWIND_2DPROTECT(argc, v_TREE_0, v_DEAD_3F_1)
      ARGC argc;  LP v_TREE_0; LP v_DEAD_3F_1;
{
LP v_VALUE_29; LP v_N_28; LP v_S_27; 
LP v_VALUE_25; LP v_S_24; LP v_T6657_23; 
LP v_S6656_22; LP v_I_20; LP v_S_19; 
LP v_S_17; LP v_VALUE_15; LP v_N_14; 
LP v_S_13; LP v_VALUE_11; LP v_S_10; 
LP v_T6655_9; LP v_S6654_8; LP v_I_6; 
LP v_S_5; LP v_S_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; 
if (argc != 2) wna(argc,2);
v_S_3 = v_TREE_0;
v_S_5 = v_TREE_0;
v_I_6 = (LP) 12;
t0 = ((LP) DEREF((v_TREE_0) + 6 * 4));
v_S6654_8 = ICALL(s_lsp_IMPROVE) (1, t0);
v_T6655_9 = v_TREE_0;
v_S_10 = v_TREE_0;
v_VALUE_11 = v_S6654_8;
v_S_13 = v_TREE_0;
v_N_14 = (LP) 12;
v_VALUE_15 = v_S6654_8;
((LP) (DEREF((v_TREE_0) + 6 * 4) = (LD) (v_S6654_8)));
v_S_17 = v_TREE_0;
v_S_19 = v_TREE_0;
v_I_20 = (LP) 14;
t1 = ((LP) DEREF((v_TREE_0) + 7 * 4));
v_S6656_22 = ICALL(s_lsp_IMPROVE) (2, t1, v_DEAD_3F_1);
v_T6657_23 = v_TREE_0;
v_S_24 = v_TREE_0;
v_VALUE_25 = v_S6656_22;
v_S_27 = v_TREE_0;
v_N_28 = (LP) 14;
v_VALUE_29 = v_S6656_22;
((LP) (DEREF((v_TREE_0) + 7 * 4) = (LD) (v_S6656_22)));
return(v_TREE_0);
}

LP p_lsp_TAIL_2DLEAVES(argc, v_TREE_0)
      ARGC argc;  LP v_TREE_0;
{
LP v_Y_81; LP v_X_80; LP v_X_78; 
LP v_G6663_77; LP v_G6662_76; LP v_G6661_75; 
LP v_G6660_74; LP v_TMP6659_73; LP v_Y_71; 
LP v_X_70; LP v_I_68; LP v_S_67; 
LP v_S_65; LP v_X_63; LP v_V_61; 
LP v_X_60; LP v_NEW_2DCDR_58; LP v_C_57; 
LP v_X_55; LP v_X_53; LP v_LOOPVAR_2D1399_49; 
LP v_LOOPVAR_2D1398_48; LP v_LOOPVAR_2D1397_47; LP v_LOOP_2DLIST_2D1396_46; 
LP v_C_45; LP v_I_43; LP v_S_42; 
LP v_S_40; LP v_I_38; LP v_S_37; 
LP v_S_35; LP v_I_33; LP v_S_32; 
LP v_S_30; LP v_I_28; LP v_S_27; 
LP v_S_25; LP v_I_23; LP v_S_22; 
LP v_S_20; LP v_Y_18; LP v_X_17; 
LP v_X_15; LP v_X_13; LP v_X_11; 
LP v_X_9; LP v_BODY_8; LP v_I_6; 
LP v_S_5; LP v_S_3; LP v_KEY6658_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; 
if (argc != 1) wna(argc,1);
START10883:
v_X_78 = v_TREE_0;
v_X_80 = v_TREE_0;
v_Y_81 = LREF(s_lsp_NIL);
if (v_TREE_0 != NIL) {
v_KEY6658_2 = v_TREE_0;
t1 = ICALL(s_lsp_SEQ_2DP) (1, v_KEY6658_2);
if (t1 != NIL) {
v_S_3 = v_TREE_0;
v_S_5 = v_TREE_0;
v_I_6 = (LP) 12;
v_BODY_8 = ((LP) DEREF((v_TREE_0) + 6 * 4));
v_X_11 = v_BODY_8;
v_X_13 = v_BODY_8;
v_X_15 = (OTHER_PTRP((v_BODY_8)) && (TAG((v_BODY_8)) == 15) ? T : NIL);
v_X_17 = v_X_15;
v_Y_18 = LREF(s_lsp_NIL);
if (v_X_15 != NIL) {
v_X_9 = ICALL(s_lsp_LAST) (1, v_BODY_8);
t2 = ((LP) DEREF((v_X_9) + 0 * 4));
v_TREE_0 = t2; 
goto START10883;
} else {
v_TREE_0 = v_BODY_8; 
goto START10883;
}
} else {
t3 = ICALL(s_lsp_SCOPE_2DCONTROL_2DTRANSFER_2DP) (1, v_KEY6658_2);
if (t3 != NIL) {
v_S_20 = v_TREE_0;
v_S_22 = v_TREE_0;
v_I_23 = (LP) 16;
t4 = ((LP) DEREF((v_TREE_0) + 8 * 4));
v_TREE_0 = t4; 
goto START10883;
} else {
t5 = ICALL(s_lsp_UNWIND_2DPROTECT_2DP) (1, v_KEY6658_2);
if (t5 != NIL) {
v_S_25 = v_TREE_0;
v_S_27 = v_TREE_0;
v_I_28 = (LP) 12;
t6 = ((LP) DEREF((v_TREE_0) + 6 * 4));
v_TREE_0 = t6; 
goto START10883;
} else {
t7 = ICALL(s_lsp_IF_2DP) (1, v_KEY6658_2);
if (t7 != NIL) {
v_S_30 = v_TREE_0;
v_S_32 = v_TREE_0;
v_I_33 = (LP) 16;
t9 = ((LP) DEREF((v_TREE_0) + 8 * 4));
t8 = ICALL(s_lsp_TAIL_2DLEAVES) (1, t9);
v_S_35 = v_TREE_0;
v_S_37 = v_TREE_0;
v_I_38 = (LP) 18;
t11 = ((LP) DEREF((v_TREE_0) + 9 * 4));
t10 = ICALL(s_lsp_TAIL_2DLEAVES) (1, t11);
t0 = ICALL(s_lsp_APPEND_2F2) (MV_CALL(argc,2), t8, t10);
return(t0);
} else {
t12 = ICALL(s_lsp_SWITCH_2DP) (1, v_KEY6658_2);
if (t12 != NIL) {
v_C_45 = LREF(s_lsp_NIL);
v_S_40 = v_TREE_0;
v_S_42 = v_TREE_0;
v_I_43 = (LP) 18;
v_LOOP_2DLIST_2D1396_46 = ((LP) DEREF((v_TREE_0) + 9 * 4));
v_LOOPVAR_2D1397_47 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1398_48 = LREF(s_lsp_NIL);
v_LOOPVAR_2D1399_49 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_51:;
if (v_LOOP_2DLIST_2D1396_46 == NIL) {
goto t_END_2DLOOP_52;
}
v_X_53 = v_LOOP_2DLIST_2D1396_46;
v_C_45 = ((LP) DEREF((v_X_53) + 0 * 4));
v_X_55 = v_LOOP_2DLIST_2D1396_46;
v_LOOP_2DLIST_2D1396_46 = ((LP) DEREF((v_X_55) + 1 * 4));
t14 = ICALL(s_lsp_TAIL_2DLEAVES) (1, v_C_45);
v_LOOPVAR_2D1399_49 = ICALL(s_lsp_COPY_2DLIST) (1, t14);
if (v_LOOPVAR_2D1399_49 != NIL) {
if (v_LOOPVAR_2D1398_48 != NIL) {
v_C_57 = v_LOOPVAR_2D1398_48;
v_NEW_2DCDR_58 = v_LOOPVAR_2D1399_49;
v_V_61 = v_NEW_2DCDR_58;
((LP) (DEREF((v_C_57) + 1 * 4) = (LD) (v_V_61)));
v_X_63 = v_C_57;
t15 = ((LP) DEREF((v_X_63) + 1 * 4));
} else {
v_LOOPVAR_2D1397_47 = v_LOOPVAR_2D1399_49;
t15 = v_LOOPVAR_2D1397_47;
}
v_LOOPVAR_2D1398_48 = ICALL(s_lsp_LAST) (1, t15);
}
goto t_NEXT_2DLOOP_51;
goto t_END_2DLOOP_52;
t_END_2DLOOP_52:;
t13 = v_LOOPVAR_2D1397_47;
goto b_NIL_50;
t13 = NIL;
b_NIL_50:;
v_S_65 = v_TREE_0;
v_S_67 = v_TREE_0;
v_I_68 = (LP) 20;
t17 = ((LP) DEREF((v_TREE_0) + 10 * 4));
t16 = ICALL(s_lsp_TAIL_2DLEAVES) (1, t17);
t0 = ICALL(s_lsp_APPEND_2F2) (MV_CALL(argc,2), t13, t16);
return(t0);
} else {
v_TMP6659_73 = v_KEY6658_2;
v_G6660_74 = ICALL(s_lsp_FUNCTION_2DCALL_2DP) (1, v_TMP6659_73);
if (v_G6660_74 != NIL) {
t18 = v_G6660_74;
} else {
v_G6661_75 = ICALL(s_lsp_VAR_2DREF_2DP) (1, v_TMP6659_73);
if (v_G6661_75 != NIL) {
t18 = v_G6661_75;
} else {
v_G6662_76 = ICALL(s_lsp_CONSTANT_2DP) (1, v_TMP6659_73);
if (v_G6662_76 != NIL) {
t18 = v_G6662_76;
} else {
v_G6663_77 = ICALL(s_lsp_VAR_2DDEF_2DP) (1, v_TMP6659_73);
if (v_G6663_77 != NIL) {
t18 = v_G6663_77;
} else {
t18 = ICALL(s_lsp_MVALUES_2DP) (1, v_TMP6659_73);
}
}
}
}
if (t18 != NIL) {
v_X_70 = v_TREE_0;
v_Y_71 = LREF(s_lsp_NIL);
t0 = (c_cons((v_TREE_0), (LREF(s_lsp_NIL))));
return(t0);
} else {
return(LREF(s_lsp_NIL));
}
}
}
}
}
}
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_CLEAR_2DTREE_2DLEAVES_2DTAIL_2DSLOTS(argc, v_TREE_0)
      ARGC argc;  LP v_TREE_0;
{
LP v_Y_79; LP v_X_78; LP v_X_76; 
LP v_G6671_75; LP v_G6670_74; LP v_G6669_73; 
LP v_G6668_72; LP v_TMP6667_71; LP v_Y_69; 
LP v_X_68; LP v_I_66; LP v_S_65; 
LP v_S_63; LP v_X_61; LP v_X_59; 
LP v_LOOP_2DLIST_2D1400_55; LP v_C_54; LP v_I_52; 
LP v_S_51; LP v_S_49; LP v_I_47; 
LP v_S_46; LP v_S_44; LP v_I_42; 
LP v_S_41; LP v_S_39; LP v_I_37; 
LP v_S_36; LP v_S_34; LP v_I_32; 
LP v_S_31; LP v_S_29; LP v_Y_27; 
LP v_X_26; LP v_X_24; LP v_X_22; 
LP v_X_20; LP v_X_18; LP v_BODY_17; 
LP v_I_15; LP v_S_14; LP v_S_12; 
LP v_KEY6666_11; LP v_VALUE_9; LP v_N_8; 
LP v_S_7; LP v_VALUE_5; LP v_S_4; 
LP v_T6665_3; LP v_S6664_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 

if (argc != 1) wna(argc,1);
START10889:
v_X_76 = v_TREE_0;
v_X_78 = v_TREE_0;
v_Y_79 = LREF(s_lsp_NIL);
if (v_TREE_0 != NIL) {
v_S6664_2 = LREF(s_lsp_NIL);
v_T6665_3 = v_TREE_0;
v_S_4 = v_TREE_0;
v_VALUE_5 = LREF(s_lsp_NIL);
v_S_7 = v_TREE_0;
v_N_8 = (LP) 2;
v_VALUE_9 = LREF(s_lsp_NIL);
((LP) (DEREF((v_TREE_0) + 1 * 4) = (LD) (LREF(s_lsp_NIL))));
v_KEY6666_11 = v_TREE_0;
t1 = ICALL(s_lsp_SEQ_2DP) (1, v_KEY6666_11);
if (t1 != NIL) {
v_S_12 = v_TREE_0;
v_S_14 = v_TREE_0;
v_I_15 = (LP) 12;
v_BODY_17 = ((LP) DEREF((v_TREE_0) + 6 * 4));
v_X_20 = v_BODY_17;
v_X_22 = v_BODY_17;
v_X_24 = (OTHER_PTRP((v_BODY_17)) && (TAG((v_BODY_17)) == 15) ? T : NIL);
v_X_26 = v_X_24;
v_Y_27 = LREF(s_lsp_NIL);
if (v_X_24 != NIL) {
v_X_18 = ICALL(s_lsp_LAST) (1, v_BODY_17);
t2 = ((LP) DEREF((v_X_18) + 0 * 4));
v_TREE_0 = t2; 
goto START10889;
} else {
v_TREE_0 = v_BODY_17; 
goto START10889;
}
} else {
t3 = ICALL(s_lsp_SCOPE_2DCONTROL_2DTRANSFER_2DP) (1, v_KEY6666_11);
if (t3 != NIL) {
v_S_29 = v_TREE_0;
v_S_31 = v_TREE_0;
v_I_32 = (LP) 16;
t4 = ((LP) DEREF((v_TREE_0) + 8 * 4));
v_TREE_0 = t4; 
goto START10889;
} else {
t5 = ICALL(s_lsp_UNWIND_2DPROTECT_2DP) (1, v_KEY6666_11);
if (t5 != NIL) {
v_S_34 = v_TREE_0;
v_S_36 = v_TREE_0;
v_I_37 = (LP) 12;
t6 = ((LP) DEREF((v_TREE_0) + 6 * 4));
v_TREE_0 = t6; 
goto START10889;
} else {
t7 = ICALL(s_lsp_IF_2DP) (1, v_KEY6666_11);
if (t7 != NIL) {
v_S_39 = v_TREE_0;
v_S_41 = v_TREE_0;
v_I_42 = (LP) 16;
t8 = ((LP) DEREF((v_TREE_0) + 8 * 4));
ICALL(s_lsp_CLEAR_2DTREE_2DLEAVES_2DTAIL_2DSLOTS) (1, t8);
v_S_44 = v_TREE_0;
v_S_46 = v_TREE_0;
v_I_47 = (LP) 18;
t9 = ((LP) DEREF((v_TREE_0) + 9 * 4));
v_TREE_0 = t9; 
goto START10889;
} else {
t10 = ICALL(s_lsp_SWITCH_2DP) (1, v_KEY6666_11);
if (t10 != NIL) {
v_C_54 = LREF(s_lsp_NIL);
v_S_49 = v_TREE_0;
v_S_51 = v_TREE_0;
v_I_52 = (LP) 18;
v_LOOP_2DLIST_2D1400_55 = ((LP) DEREF((v_TREE_0) + 9 * 4));
t_NEXT_2DLOOP_57:;
if (v_LOOP_2DLIST_2D1400_55 == NIL) {
goto t_END_2DLOOP_58;
}
v_X_59 = v_LOOP_2DLIST_2D1400_55;
v_C_54 = ((LP) DEREF((v_X_59) + 0 * 4));
v_X_61 = v_LOOP_2DLIST_2D1400_55;
v_LOOP_2DLIST_2D1400_55 = ((LP) DEREF((v_X_61) + 1 * 4));
ICALL(s_lsp_CLEAR_2DTREE_2DLEAVES_2DTAIL_2DSLOTS) (1, v_C_54);
goto t_NEXT_2DLOOP_57;
goto t_END_2DLOOP_58;
t_END_2DLOOP_58:;
v_S_63 = v_TREE_0;
v_S_65 = v_TREE_0;
v_I_66 = (LP) 20;
t11 = ((LP) DEREF((v_TREE_0) + 10 * 4));
v_TREE_0 = t11; 
goto START10889;
} else {
v_TMP6667_71 = v_KEY6666_11;
v_G6668_72 = ICALL(s_lsp_FUNCTION_2DCALL_2DP) (1, v_TMP6667_71);
if (v_G6668_72 != NIL) {
t12 = v_G6668_72;
} else {
v_G6669_73 = ICALL(s_lsp_VAR_2DREF_2DP) (1, v_TMP6667_71);
if (v_G6669_73 != NIL) {
t12 = v_G6669_73;
} else {
v_G6670_74 = ICALL(s_lsp_CONSTANT_2DP) (1, v_TMP6667_71);
if (v_G6670_74 != NIL) {
t12 = v_G6670_74;
} else {
v_G6671_75 = ICALL(s_lsp_VAR_2DDEF_2DP) (1, v_TMP6667_71);
if (v_G6671_75 != NIL) {
t12 = v_G6671_75;
} else {
t12 = ICALL(s_lsp_MVALUES_2DP) (1, v_TMP6667_71);
}
}
}
}
if (t12 != NIL) {
v_X_68 = v_TREE_0;
v_Y_69 = LREF(s_lsp_NIL);
t0 = (c_cons((v_TREE_0), (LREF(s_lsp_NIL))));
return(t0);
} else {
return(LREF(s_lsp_NIL));
}
}
}
}
}
}
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_FUNCTION_2DCALL_2DSIDE_2DEFFECTS_3F(argc, v_TREE_0)
      ARGC argc;  LP v_TREE_0;
{

LP t0; 
if (argc != 1) wna(argc,1);
return(LREF(s_lsp_T));
}

