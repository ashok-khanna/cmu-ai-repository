/*
:comment "Compiled at 4:09:20 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: Debug Library"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O2 -fPIC"
:version 0
:end-package-info 0
:sym LOOP-MAKE-PSETQ
:sym NIL
:sym PROG1
:sym LOOP-MAKE-SETQ
:sf LOOP-MAKE-PSETQ "p_lsp_LOOP_2DMAKE_2DPSETQ"
:sym LOOP-USE-SYSTEM-DESTRUCTURING?
:sym UNSAFE-SYMBOL-VALUE
:sym SETQ
:sym NULL
:sym SYMBOLP
:sym DESETQ
:sym ATOM
:sym CAR
:sym CDR
:sym CADR
:sym CDDR
:sym CAAR
:sym CDAR
:sym MEMQL
:sym NOT
:sym LOOP-DESETQ-TEMPORARY
:sym LOOP-DESETQ-
:sym SYMBOL-NAME
:sym GENTEMP
:sym SET
:sym LIST*
:sym LOOP-DESETQ-INTERNAL
:sym NCONC/2
:sf LOOP-MAKE-DESETQ "p_lsp_LOOP_2DMAKE_2DDESETQ"
:sf LOOP-DESETQ-INTERNAL "p_lsp_LOOP_2DDESETQ_2DINTERNAL"
:sym LOOP-MAKE-DESETQ
:sf LOOP-MAKE-SETQ "p_lsp_LOOP_2DMAKE_2DSETQ"
:sym LOOP-PROG-NAMES
:sym RETURN-FROM
:sym RETURN
:sf LOOP-CONSTRUCT-RETURN "p_lsp_LOOP_2DCONSTRUCT_2DRETURN"
:sym STRING=
:sf LOOP-TEQUAL "p_lsp_LOOP_2DTEQUAL"
:sym UNSAFE-SYMBOL-FUNCTION
:sym IDENTITY
:sym ASSOC/4
:sf LOOP-TASSOC "p_lsp_LOOP_2DTASSOC"
:sym MEMBER/4
:sf LOOP-TMEMBER "p_lsp_LOOP_2DTMEMBER"
:sym LOOP-MACRO-ENVIRONMENT
:sym LOOP-TRANSLATE-1
:sf LOOP-TRANSLATE "p_lsp_LOOP_2DTRANSLATE"
:sym WHEN
:sym NREVERSE
:sym OR
:sym GO
:sym END-LOOP
:sf LOOP-END-TESTIFY "p_lsp_LOOP_2DEND_2DTESTIFY"
:sym LOOP-BEFORE-LOOP
:sym LOOP-AFTER-BODY
:sym EQUAL
:sym LOOP-BODY
:sym DELETE
:sym LOOP-DUPLICATE-CODE
:sym LOOP-SIMPLEP
:sym EQ
:sym LOOP-OUTPUT-GROUP
:sym LOOP-NEVER-STEPPED-VARIABLE
:sf LOOP-OPTIMIZE-DUPLICATED-CODE-ETC "p_lsp_LOOP_2DOPTIMIZE_2DDUPLICATED_2DCODE_2DETC"
:sym LOOP-ITER-FLAG-
:sym T
:sym LOOP-MAKE-VARIABLE
:sym COND
:sym PROGN
:sym UNLESS
:sf LOOP-OUTPUT-GROUP "p_lsp_LOOP_2DOUTPUT_2DGROUP"
:sym LOOP-SOURCE-CODE
:sym LOOP
:sym NIL886
:sym LOOP-ITERATION-VARIABLES
:sym LOOP-ITERATION-VARIABLEP
:sym LOOP-VARIABLES
:sym LOOP-NODECLARE
:sym LOOP-NAMED-VARIABLES
:sym LOOP-DECLARATIONS
:sym LOOP-DESETQ-CROCKS
:sym LOOP-VARIABLE-STACK
:sym LOOP-DECLARATION-STACK
:sym LOOP-DESETQ-STACK
:sym LOOP-PROLOGUE
:sym LOOP-WRAPPERS
:sym LOOP-EMITTED-BODY?
:sym LOOP-EPILOGUE
:sym LOOP-AFTER-EPILOGUE
:sym LOOP-CONDITIONALS
:sym LOOP-WHEN-IT-VARIABLE
:sym LOOP-COLLECT-CRUFT
:sym ERROR
:sym LOOP-OPTIMIZE-DUPLICATED-CODE-ETC
:sym LOOP-BIND-BLOCK
:sym NEXT-LOOP
:sym APPEND/2
:sym TAGBODY
:sym LET
:sym BLOCK
:sym DECLARE
:sym LAMBDA
:sym DO
:sym LOOP-KEYWORD-ALIST
:sym LOOP-TASSOC
:sym LOOP-ITERATION-KEYWORD-ALIST
:sym LOOP-HACK-ITERATION
:sym AND
:sym ELSE
:sym LOOP-TMEMBER
:sf LOOP-TRANSLATE-1 "p_lsp_LOOP_2DTRANSLATE_2D1"
:sf LOOP-BIND-BLOCK "p_lsp_LOOP_2DBIND_2DBLOCK"
:sf LOOP-GET-PROGN-1 "p_lsp_LOOP_2DGET_2DPROGN_2D1"
:sym LOOP-GET-PROGN-1
:sf LOOP-GET-PROGN "p_lsp_LOOP_2DGET_2DPROGN"
:sym WARN
:sf LOOP-GET-FORM "p_lsp_LOOP_2DGET_2DFORM"
:sf LOOP-TYPED-ARITH "p_lsp_LOOP_2DTYPED_2DARITH"
:sym :DATA-TYPE
:sym GET
:sym KEYWORD
:sym FIND-SYMBOL
:sym INITIAL-VALUE
:sym FIXNUM
:sym INTEGER
:sym NUMBER
:sym LOOP-FLOATING-POINT-TYPES
:sym FLONUM
:sym FLOAT
:sym COERCE
:sf LOOP-TYPED-INIT "p_lsp_LOOP_2DTYPED_2DINIT"
:sym ASSQL
:sym LOOP-DECLARE-VARIABLE
:sym LOOP-TYPED-INIT
:sym LOOP-DESTRUCTURE-
:sym LOOP-IGNORE-
:sym IGNORE
:sf LOOP-MAKE-VARIABLE "p_lsp_LOOP_2DMAKE_2DVARIABLE"
:sf LOOP-MAKE-ITERATION-VARIABLE "p_lsp_LOOP_2DMAKE_2DITERATION_2DVARIABLE"
:sym VARIABLE-DECLARATIONS
:sym NOTYPE
:sym LOOP-TEQUAL
:sym TYPE
:sym CONSP
:sf LOOP-DECLARE-VARIABLE "p_lsp_LOOP_2DDECLARE_2DVARIABLE"
:sym CONSTANTP
:sf LOOP-CONSTANTP "p_lsp_LOOP_2DCONSTANTP"
:sym LOOP-CONSTANTP
:sym LOOP-BIND-
:sf LOOP-MAYBE-BIND-FORM "p_lsp_LOOP_2DMAYBE_2DBIND_2DFORM"
:sf LOOP-OPTIONAL-TYPE "p_lsp_LOOP_2DOPTIONAL_2DTYPE"
:sym LAST
:sf LOOP-MAKE-CONDITIONALIZATION "p_lsp_LOOP_2DMAKE_2DCONDITIONALIZATION"
:sym LOOP-MAKE-CONDITIONALIZATION
:sf LOOP-PSEUDO-BODY "p_lsp_LOOP_2DPSEUDO_2DBODY"
:sym LOOP-PSEUDO-BODY
:sf LOOP-EMIT-BODY "p_lsp_LOOP_2DEMIT_2DBODY"
:sf LOOP-DO-NAMED "p_lsp_LOOP_2DDO_2DNAMED"
:sym LOOP-GET-PROGN
:sf LOOP-DO-INITIALLY "p_lsp_LOOP_2DDO_2DINITIALLY"
:sf LOOP-NODECLARE "p_lsp_LOOP_2DNODECLARE"
:sf LOOP-DO-FINALLY "p_lsp_LOOP_2DDO_2DFINALLY"
:sym LOOP-EMIT-BODY
:sf LOOP-DO-DO "p_lsp_LOOP_2DDO_2DDO"
:sym LOOP-GET-FORM
:sym LOOP-CONSTRUCT-RETURN
:sf LOOP-DO-RETURN "p_lsp_LOOP_2DDO_2DRETURN"
:sym SYMBOL-HASH-CODE
:sym COUNT
:sym SUM
:sym NCONC
:sym LIST
:sym APPEND
:sym MAX
:sym MIN
:sym MAXMIN
:sym LOOP-OPTIONAL-TYPE
:sym INTO
:sym LOOP-MAXMIN-
:sym EQL
:sym LOOPVAR-
:sym LOOP-MAKE-ITERATION-VARIABLE
:sym LOOP-MAXMIN-FL-
:sym +
:sym QUOTE
:sym LOOP-TYPED-ARITH
:sym <
:sym >
:sym COPY-LIST
:sym IF
:sym RPLACD
:sym LOOP-CDRIFY
:sf LOOP-DO-COLLECT "p_lsp_LOOP_2DDO_2DCOLLECT"
:sym LENGTH
:sym ZEROP
:sym CDDDR
:sym CDDDDR
:sf LOOP-CDRIFY "p_lsp_LOOP_2DCDRIFY"
:sf LOOP-DO-WHILE "p_lsp_LOOP_2DDO_2DWHILE"
:sym IT
:sf LOOP-DO-WHEN "p_lsp_LOOP_2DDO_2DWHEN"
:sym =
:sym WITH
:sf LOOP-DO-WITH "p_lsp_LOOP_2DDO_2DWITH"
:sym ALWAYS
:sf LOOP-DO-ALWAYS "p_lsp_LOOP_2DDO_2DALWAYS"
:sym THEREIS
:sf LOOP-DO-THEREIS "p_lsp_LOOP_2DDO_2DTHEREIS"
:sym LOOP-SIMPLEP-1
:sf LOOP-SIMPLEP "p_lsp_LOOP_2DSIMPLEP"
:sym FIXNUMP
:sym CAAAR
:sym CAADR
:sym CADAR
:sym CADDR
:sym CDAAR
:sym CDADR
:sym CDDAR
:sym CAAAAR
:sym CAAADR
:sym CAADAR
:sym CAADDR
:sym CADAAR
:sym CADADR
:sym CADDAR
:sym CADDDR
:sym CDAAAR
:sym CDAADR
:sym CDADAR
:sym CDADDR
:sym CDDAAR
:sym CDDADR
:sym CDDDAR
:sym MACROEXPAND-1
:sf LOOP-SIMPLEP-1 "p_lsp_LOOP_2DSIMPLEP_2D1"
:sym LOOP-END-TESTIFY
:sym NRECONC
:sf LOOP-HACK-ITERATION "p_lsp_LOOP_2DHACK_2DITERATION"
:sym FOR
:sym LOOP-FOR-KEYWORD-ALIST
:sf LOOP-DO-FOR "p_lsp_LOOP_2DDO_2DFOR"
:sym LOOP-REPEAT-
:sym REPEAT
:sym PLUSP
:sym 1-
:sf LOOP-DO-REPEAT "p_lsp_LOOP_2DDO_2DREPEAT"
:sym LOOP-IT-
:sf LOOP-WHEN-IT-VARIABLE "p_lsp_LOOP_2DWHEN_2DIT_2DVARIABLE"
:sym THEN
:sf LOOP-FOR-EQUALS "p_lsp_LOOP_2DFOR_2DEQUALS"
:sym FIRST
:sf LOOP-FOR-FIRST "p_lsp_LOOP_2DFOR_2DFIRST"
:sym BY
:sym IN
:sym ON
:sym FUNCTION
:sym LOOP-FN-
:sym FUNCALL
:sym LOOP-LIST-
:sf LOOP-LIST-STEPPER "p_lsp_LOOP_2DLIST_2DSTEPPER"
:sym FROM
:sym UPFROM
:sym DOWNFROM
:sym TO
:sym UPTO
:sym DOWNTO
:sym ABOVE
:sym BELOW
:sym LOOP-GATHER-PREPS
:sym LOOP-SEQUENCER
:sf LOOP-FOR-ARITHMETIC "p_lsp_LOOP_2DFOR_2DARITHMETIC"
:sf LOOP-NAMED-VARIABLE "p_lsp_LOOP_2DNAMED_2DVARIABLE"
:sym EACH
:sym THE
:sym LOOP-PATH-KEYWORD-ALIST
:sym BEING
:sym OF
:sym ITS
:sym HIS
:sym HER
:sym THEIR
:sym DEFAULT-LOOP-PATH
:sym REVERSE
:sf LOOP-FOR-BEING "p_lsp_LOOP_2DFOR_2DBEING"
:sym USING
:sf LOOP-GATHER-PREPS "p_lsp_LOOP_2DGATHER_2DPREPS"
:sym :TEST
:sf LOOP-ADD-PATH "p_lsp_LOOP_2DADD_2DPATH"
:sym 1+
:sym DOWN
:sym UP
:sym LOOP-MAYBE-BIND-FORM
:sym LOOP-STEP-BY-
:sym LOOP-SEQ-LIMIT-
:sym ARGS
:sym >=
:sym <=
:sym -
:sym SUBST
:sf LOOP-SEQUENCER "p_lsp_LOOP_2DSEQUENCER"
:sym INDEX
:sym LOOP-NAMED-VARIABLE
:sym SEQUENCE
:sf LOOP-SEQUENCE-ELEMENTS-PATH "p_lsp_LOOP_2DSEQUENCE_2DELEMENTS_2DPATH"
:sf INITIAL-VALUE "p_lsp_INITIAL_2DVALUE"
:sf VARIABLE-DECLARATIONS "p_lsp_VARIABLE_2DDECLARATIONS"
:pinfo LOOP-GET-FORM (FOR) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-SIMPLEP-1 (X) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-MAKE-DESETQ (X) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-DO-FINALLY NIL NIL NIL NIL NIL NIL NIL T
:pinfo INITIAL-VALUE (X) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-DO-ALWAYS (NEGATE?) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-DO-NAMED NIL NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-OPTIONAL-TYPE NIL NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-CDRIFY (ARGLIST FORM) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-MAKE-ITERATION-VARIABLE (NAME INITIALIZATION DTYPE) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-CONSTRUCT-RETURN (FORM) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-FOR-BEING (VAR VAL DATA-TYPE?) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-MAKE-VARIABLE (NAME INITIALIZATION DTYPE) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-DO-DO NIL NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-FOR-ARITHMETIC (VAR VAL DATA-TYPE? KWD) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-SIMPLEP (EXPR) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-CONSTANTP (FORM) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-MAKE-CONDITIONALIZATION (FORM) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-DO-INITIALLY NIL NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-GET-PROGN NIL NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-MAYBE-BIND-FORM (FORM DATA-TYPE?) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-DO-COLLECT (TYPE) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-SEQUENCE-ELEMENTS-PATH (PATH VARIABLE DATA-TYPE PREP-PHRASES INCLUSIVE? ALLOWED-PREPS DATA) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-GET-PROGN-1 NIL NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-OPTIMIZE-DUPLICATED-CODE-ETC (&AUX BEFORE AFTER GROUPA GROUPB A B LASTDIFF) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-DO-REPEAT NIL NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-TASSOC (KWD ALIST) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-DO-RETURN NIL NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-FOR-EQUALS (VAR VAL DATA-TYPE?) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-LIST-STEPPER (VAR VAL DATA-TYPE? FN) NIL NIL NIL NIL NIL NIL T
:pinfo VARIABLE-DECLARATIONS (TYPE &REST VARS) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-TMEMBER (KWD LIST) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-DO-WHILE (NEGATE? KWD &AUX (FORM (LOOP-GET-FORM KWD))) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-OUTPUT-GROUP (BEFORE AFTER) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-END-TESTIFY (LIST-OF-FORMS) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-BIND-BLOCK NIL NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-ADD-PATH (NAME DATA) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-MAKE-PSETQ (FROBS) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-GATHER-PREPS (PREPS-ALLOWED CROCKP) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-DECLARE-VARIABLE (NAME DTYPE) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-NAMED-VARIABLE (NAME) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-DO-THEREIS NIL NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-MAKE-SETQ (PAIRS) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-TRANSLATE-1 (LOOP-SOURCE-CODE) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-DESETQ-INTERNAL (VAR VAL) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-SEQUENCER (INDEXV INDEXV-TYPE VARIABLE? VTYPE? SEQUENCEV? SEQUENCE-TYPE? STEPHACK? DEFAULT-TOP? CRAP PREP-PHRASES) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-DO-WHEN (NEGATE? KWD) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-TRANSLATE (X LOOP-MACRO-ENVIRONMENT) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-TEQUAL (X1 X2) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-DO-FOR NIL NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-WHEN-IT-VARIABLE NIL NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-TYPED-ARITH (SUBSTITUTABLE-EXPRESSION DATA-TYPE) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-HACK-ITERATION (ENTRY) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-NODECLARE (&AUX (VARLIST (LOOP-POP-SOURCE))) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-EMIT-BODY (FORM) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-DO-WITH NIL NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-FOR-FIRST (VAR VAL DATA-TYPE?) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-TYPED-INIT (DATA-TYPE) NIL NIL NIL NIL NIL NIL T
:pinfo LOOP-PSEUDO-BODY (FORM &AUX (Z (LOOP-MAKE-CONDITIONALIZATION FORM))) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_lsp_LOOP_2DMAKE_2DPSETQ();
extern SYMBOL s_lsp_LOOP_2DMAKE_2DPSETQ; 
extern SYMBOL s_lsp_NIL; 
extern SYMBOL s_lsp_PROG1; 
extern SYMBOL s_lsp_LOOP_2DMAKE_2DSETQ; 
extern LP p_lsp_LOOP_2DMAKE_2DDESETQ();
extern SYMBOL s_lsp_LOOP_2DUSE_2DSYSTEM_2DDESTRUCTURING_3F; 
extern SYMBOL s_lsp_UNSAFE_2DSYMBOL_2DVALUE; 
extern SYMBOL s_lsp_SETQ; 
extern SYMBOL s_lsp_NULL; 
extern SYMBOL s_lsp_SYMBOLP; 
extern SYMBOL s_lsp_DESETQ; 
extern SYMBOL s_lsp_ATOM; 
extern SYMBOL s_lsp_CAR; 
extern SYMBOL s_lsp_CDR; 
extern SYMBOL s_lsp_CADR; 
extern SYMBOL s_lsp_CDDR; 
extern SYMBOL s_lsp_CAAR; 
extern SYMBOL s_lsp_CDAR; 
MAKE_CONS(k2198,LREF(s_lsp_CDAR),LREF(s_lsp_NIL));
MAKE_CONS(k2197,LREF(s_lsp_CAAR),LREF(k2198));
MAKE_CONS(k2196,LREF(s_lsp_CDDR),LREF(k2197));
MAKE_CONS(k2195,LREF(s_lsp_CADR),LREF(k2196));
MAKE_CONS(k2194,LREF(s_lsp_CDR),LREF(k2195));
MAKE_CONS(k2193,LREF(s_lsp_CAR),LREF(k2194));
extern SYMBOL s_lsp_MEMQL; 
extern SYMBOL s_lsp_NOT; 
extern SYMBOL s_lsp_LOOP_2DDESETQ_2DTEMPORARY; 
extern SYMBOL s_lsp_LOOP_2DDESETQ_2D; 
extern SYMBOL s_lsp_SYMBOL_2DNAME; 
extern SYMBOL s_lsp_GENTEMP; 
extern SYMBOL s_lsp_SET; 
extern SYMBOL s_lsp_LIST_2A; 
extern SYMBOL s_lsp_LOOP_2DDESETQ_2DINTERNAL; 
extern SYMBOL s_lsp_NCONC_2F2; 
extern LP p_lsp_LOOP_2DDESETQ_2DINTERNAL();
extern LP p_lsp_LOOP_2DMAKE_2DSETQ();
extern SYMBOL s_lsp_LOOP_2DMAKE_2DDESETQ; 
extern LP p_lsp_LOOP_2DCONSTRUCT_2DRETURN();
extern SYMBOL s_lsp_LOOP_2DPROG_2DNAMES; 
extern SYMBOL s_lsp_RETURN_2DFROM; 
extern SYMBOL s_lsp_RETURN; 
extern LP p_lsp_LOOP_2DTEQUAL();
extern SYMBOL s_lsp_STRING_3D; 
extern LP p_lsp_LOOP_2DTASSOC();
extern SYMBOL s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION; 
extern SYMBOL s_lsp_IDENTITY; 
extern SYMBOL s_lsp_ASSOC_2F4; 
extern LP p_lsp_LOOP_2DTMEMBER();
extern SYMBOL s_lsp_MEMBER_2F4; 
extern LP p_lsp_LOOP_2DTRANSLATE();
extern SYMBOL s_lsp_LOOP_2DMACRO_2DENVIRONMENT; 
extern SYMBOL s_lsp_LOOP_2DTRANSLATE_2D1; 
extern LP p_lsp_LOOP_2DEND_2DTESTIFY();
extern SYMBOL s_lsp_WHEN; 
extern SYMBOL s_lsp_NREVERSE; 
extern SYMBOL s_lsp_OR; 
extern SYMBOL s_lsp_GO; 
extern SYMBOL s_lsp_END_2DLOOP; 
MAKE_CONS(k2201,LREF(s_lsp_END_2DLOOP),LREF(s_lsp_NIL));
MAKE_CONS(k2200,LREF(s_lsp_GO),LREF(k2201));
MAKE_CONS(k2199,LREF(k2200),LREF(s_lsp_NIL));
extern LP p_lsp_LOOP_2DOPTIMIZE_2DDUPLICATED_2DCODE_2DETC();
extern SYMBOL s_lsp_LOOP_2DBEFORE_2DLOOP; 
extern SYMBOL s_lsp_LOOP_2DAFTER_2DBODY; 
extern SYMBOL s_lsp_EQUAL; 
extern SYMBOL s_lsp_LOOP_2DBODY; 
extern SYMBOL s_lsp_DELETE; 
extern SYMBOL s_lsp_LOOP_2DDUPLICATE_2DCODE; 
extern SYMBOL s_lsp_LOOP_2DSIMPLEP; 
extern SYMBOL s_lsp_EQ; 
extern SYMBOL s_lsp_LOOP_2DOUTPUT_2DGROUP; 
extern SYMBOL s_lsp_LOOP_2DNEVER_2DSTEPPED_2DVARIABLE; 
MAKE_CONS(k2202,LREF(s_lsp_NIL),LREF(s_lsp_NIL));
extern LP p_lsp_LOOP_2DOUTPUT_2DGROUP();
extern SYMBOL s_lsp_LOOP_2DITER_2DFLAG_2D; 
extern SYMBOL s_lsp_T; 
extern SYMBOL s_lsp_LOOP_2DMAKE_2DVARIABLE; 
extern SYMBOL s_lsp_COND; 
extern SYMBOL s_lsp_PROGN; 
extern SYMBOL s_lsp_UNLESS; 
extern LP p_lsp_LOOP_2DTRANSLATE_2D1();
extern SYMBOL s_lsp_LOOP_2DSOURCE_2DCODE; 
extern SYMBOL s_lsp_LOOP; 
extern SYMBOL s_lsp_NIL886; 
extern SYMBOL s_lsp_LOOP_2DITERATION_2DVARIABLES; 
extern SYMBOL s_lsp_LOOP_2DITERATION_2DVARIABLEP; 
extern SYMBOL s_lsp_LOOP_2DVARIABLES; 
extern SYMBOL s_lsp_LOOP_2DNODECLARE; 
extern SYMBOL s_lsp_LOOP_2DNAMED_2DVARIABLES; 
extern SYMBOL s_lsp_LOOP_2DDECLARATIONS; 
extern SYMBOL s_lsp_LOOP_2DDESETQ_2DCROCKS; 
extern SYMBOL s_lsp_LOOP_2DVARIABLE_2DSTACK; 
extern SYMBOL s_lsp_LOOP_2DDECLARATION_2DSTACK; 
extern SYMBOL s_lsp_LOOP_2DDESETQ_2DSTACK; 
extern SYMBOL s_lsp_LOOP_2DPROLOGUE; 
extern SYMBOL s_lsp_LOOP_2DWRAPPERS; 
extern SYMBOL s_lsp_LOOP_2DEMITTED_2DBODY_3F; 
extern SYMBOL s_lsp_LOOP_2DEPILOGUE; 
extern SYMBOL s_lsp_LOOP_2DAFTER_2DEPILOGUE; 
extern SYMBOL s_lsp_LOOP_2DCONDITIONALS; 
extern SYMBOL s_lsp_LOOP_2DWHEN_2DIT_2DVARIABLE; 
extern SYMBOL s_lsp_LOOP_2DCOLLECT_2DCRUFT; 
MAKE_SIMPLE_STRING(k2204,19,"Loop error - ~A: ~A");
MAKE_SIMPLE_STRING(k2205,33,"Hanging conditional in loop macro");
extern SYMBOL s_lsp_ERROR; 
extern SYMBOL s_lsp_LOOP_2DOPTIMIZE_2DDUPLICATED_2DCODE_2DETC; 
extern SYMBOL s_lsp_LOOP_2DBIND_2DBLOCK; 
extern SYMBOL s_lsp_NEXT_2DLOOP; 
MAKE_CONS(k2207,LREF(s_lsp_NEXT_2DLOOP),LREF(s_lsp_NIL));
MAKE_CONS(k2206,LREF(s_lsp_GO),LREF(k2207));
extern SYMBOL s_lsp_APPEND_2F2; 
extern SYMBOL s_lsp_TAGBODY; 
extern SYMBOL s_lsp_LET; 
extern SYMBOL s_lsp_BLOCK; 
extern SYMBOL s_lsp_DECLARE; 
extern SYMBOL s_lsp_LAMBDA; 
extern SYMBOL s_lsp_DO; 
extern SYMBOL s_lsp_LOOP_2DKEYWORD_2DALIST; 
extern SYMBOL s_lsp_LOOP_2DTASSOC; 
extern SYMBOL s_lsp_LOOP_2DITERATION_2DKEYWORD_2DALIST; 
extern SYMBOL s_lsp_LOOP_2DHACK_2DITERATION; 
extern SYMBOL s_lsp_AND; 
extern SYMBOL s_lsp_ELSE; 
MAKE_CONS(k2209,LREF(s_lsp_ELSE),LREF(s_lsp_NIL));
MAKE_CONS(k2208,LREF(s_lsp_AND),LREF(k2209));
extern SYMBOL s_lsp_LOOP_2DTMEMBER; 
MAKE_SIMPLE_STRING(k2210,53,"secondary clause misplaced at top level in LOOP macro");
MAKE_SIMPLE_STRING(k2211,29,"unknown keyword in LOOP macro");
extern LP p_lsp_LOOP_2DBIND_2DBLOCK();
extern LP p_lsp_LOOP_2DGET_2DPROGN_2D1();
extern LP p_lsp_LOOP_2DGET_2DPROGN();
extern SYMBOL s_lsp_LOOP_2DGET_2DPROGN_2D1; 
extern LP p_lsp_LOOP_2DGET_2DFORM();
static struct {unsigned long header; char string[333+1];}
k2212  = {((333 << 8) + TYPE_SIMPLE_STRING), 
"LOOP: The use of multiple forms with an implicit PROGN in this context\nis considered obsolete, but is still supported for the time being.\nIf you did not intend to use multiple forms here, you probably omitted a DO.\nIf the use of multiple forms was intentional, put a PROGN in your code.\nThe offending clause -- ~{~S~^ ~} -- ~{~S~^ ~}"};
extern SYMBOL s_lsp_WARN; 
extern LP p_lsp_LOOP_2DTYPED_2DARITH();
extern LP p_lsp_LOOP_2DTYPED_2DINIT();
extern SYMBOL s_key_DATA_2DTYPE; 
extern SYMBOL s_lsp_GET; 
extern SYMBOL s_lsp_KEYWORD; 
extern SYMBOL s_lsp_FIND_2DSYMBOL; 
extern SYMBOL s_lsp_INITIAL_2DVALUE; 
extern SYMBOL s_lsp_FIXNUM; 
extern SYMBOL s_lsp_INTEGER; 
extern SYMBOL s_lsp_NUMBER; 
MAKE_CONS(k2215,LREF(s_lsp_NUMBER),LREF(s_lsp_NIL));
MAKE_CONS(k2214,LREF(s_lsp_INTEGER),LREF(k2215));
MAKE_CONS(k2213,LREF(s_lsp_FIXNUM),LREF(k2214));
extern SYMBOL s_lsp_LOOP_2DFLOATING_2DPOINT_2DTYPES; 
extern SYMBOL s_lsp_FLONUM; 
extern SYMBOL s_lsp_FLOAT; 
MAKE_CONS(k2217,LREF(s_lsp_FLOAT),LREF(s_lsp_NIL));
MAKE_CONS(k2216,LREF(s_lsp_FLONUM),LREF(k2217));
MAKE_FLOAT(k2218,0.0);
extern SYMBOL s_lsp_COERCE; 
extern LP p_lsp_LOOP_2DMAKE_2DVARIABLE();
MAKE_SIMPLE_STRING(k2219,47,"Duplicated iteration variable somewhere in LOOP");
extern SYMBOL s_lsp_ASSQL; 
MAKE_SIMPLE_STRING(k2220,33,"Duplicated var in LOOP bind block");
MAKE_SIMPLE_STRING(k2221,30,"Bad variable somewhere in LOOP");
extern SYMBOL s_lsp_LOOP_2DDECLARE_2DVARIABLE; 
extern SYMBOL s_lsp_LOOP_2DTYPED_2DINIT; 
extern SYMBOL s_lsp_LOOP_2DDESTRUCTURE_2D; 
extern SYMBOL s_lsp_LOOP_2DIGNORE_2D; 
extern SYMBOL s_lsp_IGNORE; 
extern LP p_lsp_LOOP_2DMAKE_2DITERATION_2DVARIABLE();
extern LP p_lsp_LOOP_2DDECLARE_2DVARIABLE();
extern SYMBOL s_lsp_VARIABLE_2DDECLARATIONS; 
extern SYMBOL s_lsp_NOTYPE; 
extern SYMBOL s_lsp_LOOP_2DTEQUAL; 
extern SYMBOL s_lsp_TYPE; 
extern SYMBOL s_lsp_CONSP; 
MAKE_SIMPLE_STRING(k2224,15,"can't hack this");
extern LP p_lsp_LOOP_2DCONSTANTP();
extern SYMBOL s_lsp_CONSTANTP; 
extern LP p_lsp_LOOP_2DMAYBE_2DBIND_2DFORM();
extern SYMBOL s_lsp_LOOP_2DCONSTANTP; 
extern SYMBOL s_lsp_LOOP_2DBIND_2D; 
extern LP p_lsp_LOOP_2DOPTIONAL_2DTYPE();
MAKE_CONS(k2228,LREF(s_lsp_NOTYPE),LREF(s_lsp_NIL));
MAKE_CONS(k2227,LREF(s_lsp_NUMBER),LREF(k2228));
MAKE_CONS(k2226,LREF(s_lsp_INTEGER),LREF(k2227));
MAKE_CONS(k2225,LREF(s_lsp_FIXNUM),LREF(k2226));
extern LP p_lsp_LOOP_2DMAKE_2DCONDITIONALIZATION();
extern SYMBOL s_lsp_LAST; 
MAKE_SIMPLE_STRING(k2229,21,"More ELSEs than WHENs");
extern LP p_lsp_LOOP_2DPSEUDO_2DBODY();
extern SYMBOL s_lsp_LOOP_2DMAKE_2DCONDITIONALIZATION; 
extern LP p_lsp_LOOP_2DEMIT_2DBODY();
extern SYMBOL s_lsp_LOOP_2DPSEUDO_2DBODY; 
extern LP p_lsp_LOOP_2DDO_2DNAMED();
MAKE_SIMPLE_STRING(k2230,32,"Bad name for your loop construct");
MAKE_SIMPLE_STRING(k2231,28,"NAMED clause occurs too late");
MAKE_SIMPLE_STRING(k2232,38,"Too many names for your loop construct");
extern LP p_lsp_LOOP_2DDO_2DINITIALLY();
extern SYMBOL s_lsp_LOOP_2DGET_2DPROGN; 
extern LP p_lsp_LOOP_2DNODECLARE();
MAKE_SIMPLE_STRING(k2233,36,"Bad varlist to nodeclare loop clause");
extern LP p_lsp_LOOP_2DDO_2DFINALLY();
extern LP p_lsp_LOOP_2DDO_2DDO();
extern SYMBOL s_lsp_LOOP_2DEMIT_2DBODY; 
extern LP p_lsp_LOOP_2DDO_2DRETURN();
extern SYMBOL s_lsp_LOOP_2DGET_2DFORM; 
extern SYMBOL s_lsp_LOOP_2DCONSTRUCT_2DRETURN; 
extern LP p_lsp_LOOP_2DDO_2DCOLLECT();
extern SYMBOL s_lsp_SYMBOL_2DHASH_2DCODE; 
extern SYMBOL s_lsp_COUNT; 
extern SYMBOL s_lsp_SUM; 
extern SYMBOL s_lsp_NCONC; 
extern SYMBOL s_lsp_LIST; 
extern SYMBOL s_lsp_APPEND; 
extern SYMBOL s_lsp_MAX; 
extern SYMBOL s_lsp_MIN; 
MAKE_SIMPLE_STRING(k2234,58,"LOOP internal error:  ~S is an unknown collecting keyword.");
extern SYMBOL s_lsp_MAXMIN; 
extern SYMBOL s_lsp_LOOP_2DOPTIONAL_2DTYPE; 
extern SYMBOL s_lsp_INTO; 
MAKE_SIMPLE_STRING(k2235,36,"~A and ~A Unequal data types into ~A");
MAKE_SIMPLE_STRING(k2236,34,"incompatible LOOP collection types");
extern SYMBOL s_lsp_LOOP_2DMAXMIN_2D; 
extern SYMBOL s_lsp_EQL; 
MAKE_CONS(k2239,LREF(s_lsp_SUM),LREF(s_lsp_NIL));
MAKE_CONS(k2238,LREF(s_lsp_MAX),LREF(k2239));
MAKE_CONS(k2237,LREF(s_lsp_MIN),LREF(k2238));
extern SYMBOL s_lsp_LOOPVAR_2D; 
extern SYMBOL s_lsp_LOOP_2DMAKE_2DITERATION_2DVARIABLE; 
extern SYMBOL s_lsp_LOOP_2DMAXMIN_2DFL_2D; 
extern SYMBOL s_lsp__2B; 
MAKE_CONS(k2240,(LP) 2,LREF(s_lsp_NIL));
extern SYMBOL s_lsp_QUOTE; 
MAKE_CONS(k2242,LREF(s_lsp_T),LREF(s_lsp_NIL));
MAKE_CONS(k2241,LREF(s_lsp_QUOTE),LREF(k2242));
extern SYMBOL s_lsp_LOOP_2DTYPED_2DARITH; 
MAKE_CONS(k2244,LREF(s_lsp_MIN),LREF(s_lsp_NIL));
MAKE_CONS(k2243,LREF(s_lsp_MAX),LREF(k2244));
MAKE_CONS(k2246,LREF(s_lsp_FLONUM),LREF(s_lsp_NIL));
MAKE_CONS(k2245,LREF(s_lsp_FIXNUM),LREF(k2246));
extern SYMBOL s_lsp__3C; 
extern SYMBOL s_lsp__3E; 
extern SYMBOL s_lsp_COPY_2DLIST; 
extern SYMBOL s_lsp_IF; 
extern SYMBOL s_lsp_RPLACD; 
extern SYMBOL s_lsp_LOOP_2DCDRIFY; 
extern LP p_lsp_LOOP_2DCDRIFY();
extern SYMBOL s_lsp_LENGTH; 
extern SYMBOL s_lsp_ZEROP; 
extern SYMBOL s_lsp_CDDDR; 
extern SYMBOL s_lsp_CDDDDR; 
extern LP p_lsp_LOOP_2DDO_2DWHILE();
MAKE_SIMPLE_STRING(k2247,35,"not allowed inside LOOP conditional");
extern LP p_lsp_LOOP_2DDO_2DWHEN();
extern SYMBOL s_lsp_IT; 
extern LP p_lsp_LOOP_2DDO_2DWITH();
extern SYMBOL s_lsp__3D; 
extern SYMBOL s_lsp_WITH; 
MAKE_SIMPLE_STRING(k2248,24,"Garbage where = expected");
extern LP p_lsp_LOOP_2DDO_2DALWAYS();
extern SYMBOL s_lsp_ALWAYS; 
extern LP p_lsp_LOOP_2DDO_2DTHEREIS();
extern SYMBOL s_lsp_THEREIS; 
extern LP p_lsp_LOOP_2DSIMPLEP();
extern SYMBOL s_lsp_LOOP_2DSIMPLEP_2D1; 
extern LP p_lsp_LOOP_2DSIMPLEP_2D1();
extern SYMBOL s_lsp_FIXNUMP; 
MAKE_CONS(k2257,LREF(s_lsp_PROGN),LREF(s_lsp_NIL));
MAKE_CONS(k2256,LREF(s_lsp_RETURN),LREF(k2257));
MAKE_CONS(k2255,LREF(s_lsp_GO),LREF(k2256));
MAKE_CONS(k2254,LREF(s_lsp_EQ),LREF(k2255));
MAKE_CONS(k2253,LREF(s_lsp_NOT),LREF(k2254));
MAKE_CONS(k2252,LREF(s_lsp_NULL),LREF(k2253));
MAKE_CONS(k2259,LREF(s_lsp_CDR),LREF(s_lsp_NIL));
MAKE_CONS(k2258,LREF(s_lsp_CAR),LREF(k2259));
MAKE_CONS(k2263,LREF(s_lsp_CDDR),LREF(s_lsp_NIL));
MAKE_CONS(k2262,LREF(s_lsp_CDAR),LREF(k2263));
MAKE_CONS(k2261,LREF(s_lsp_CADR),LREF(k2262));
MAKE_CONS(k2260,LREF(s_lsp_CAAR),LREF(k2261));
extern SYMBOL s_lsp_CAAAR; 
extern SYMBOL s_lsp_CAADR; 
extern SYMBOL s_lsp_CADAR; 
extern SYMBOL s_lsp_CADDR; 
extern SYMBOL s_lsp_CDAAR; 
extern SYMBOL s_lsp_CDADR; 
extern SYMBOL s_lsp_CDDAR; 
MAKE_CONS(k2271,LREF(s_lsp_CDDDR),LREF(s_lsp_NIL));
MAKE_CONS(k2270,LREF(s_lsp_CDDAR),LREF(k2271));
MAKE_CONS(k2269,LREF(s_lsp_CDADR),LREF(k2270));
MAKE_CONS(k2268,LREF(s_lsp_CDAAR),LREF(k2269));
MAKE_CONS(k2267,LREF(s_lsp_CADDR),LREF(k2268));
MAKE_CONS(k2266,LREF(s_lsp_CADAR),LREF(k2267));
MAKE_CONS(k2265,LREF(s_lsp_CAADR),LREF(k2266));
MAKE_CONS(k2264,LREF(s_lsp_CAAAR),LREF(k2265));
extern SYMBOL s_lsp_CAAAAR; 
extern SYMBOL s_lsp_CAAADR; 
extern SYMBOL s_lsp_CAADAR; 
extern SYMBOL s_lsp_CAADDR; 
extern SYMBOL s_lsp_CADAAR; 
extern SYMBOL s_lsp_CADADR; 
extern SYMBOL s_lsp_CADDAR; 
extern SYMBOL s_lsp_CADDDR; 
extern SYMBOL s_lsp_CDAAAR; 
extern SYMBOL s_lsp_CDAADR; 
extern SYMBOL s_lsp_CDADAR; 
extern SYMBOL s_lsp_CDADDR; 
extern SYMBOL s_lsp_CDDAAR; 
extern SYMBOL s_lsp_CDDADR; 
extern SYMBOL s_lsp_CDDDAR; 
MAKE_CONS(k2287,LREF(s_lsp_CDDDDR),LREF(s_lsp_NIL));
MAKE_CONS(k2286,LREF(s_lsp_CDDDAR),LREF(k2287));
MAKE_CONS(k2285,LREF(s_lsp_CDDADR),LREF(k2286));
MAKE_CONS(k2284,LREF(s_lsp_CDDAAR),LREF(k2285));
MAKE_CONS(k2283,LREF(s_lsp_CDADDR),LREF(k2284));
MAKE_CONS(k2282,LREF(s_lsp_CDADAR),LREF(k2283));
MAKE_CONS(k2281,LREF(s_lsp_CDAADR),LREF(k2282));
MAKE_CONS(k2280,LREF(s_lsp_CDAAAR),LREF(k2281));
MAKE_CONS(k2279,LREF(s_lsp_CADDDR),LREF(k2280));
MAKE_CONS(k2278,LREF(s_lsp_CADDAR),LREF(k2279));
MAKE_CONS(k2277,LREF(s_lsp_CADADR),LREF(k2278));
MAKE_CONS(k2276,LREF(s_lsp_CADAAR),LREF(k2277));
MAKE_CONS(k2275,LREF(s_lsp_CAADDR),LREF(k2276));
MAKE_CONS(k2274,LREF(s_lsp_CAADAR),LREF(k2275));
MAKE_CONS(k2273,LREF(s_lsp_CAAADR),LREF(k2274));
MAKE_CONS(k2272,LREF(s_lsp_CAAAAR),LREF(k2273));
extern SYMBOL s_lsp_MACROEXPAND_2D1; 
extern LP p_lsp_LOOP_2DHACK_2DITERATION();
MAKE_SIMPLE_STRING(k2288,44,"Iteration is not allowed to follow body code");
MAKE_SIMPLE_STRING(k2289,48,"Iteration starting inside of conditional in LOOP");
extern SYMBOL s_lsp_LOOP_2DEND_2DTESTIFY; 
extern SYMBOL s_lsp_NRECONC; 
extern LP p_lsp_LOOP_2DDO_2DFOR();
extern SYMBOL s_lsp_FOR; 
extern SYMBOL s_lsp_LOOP_2DFOR_2DKEYWORD_2DALIST; 
MAKE_SIMPLE_STRING(k2290,43,"Unknown keyword in FOR or AS clause in LOOP");
extern LP p_lsp_LOOP_2DDO_2DREPEAT();
extern SYMBOL s_lsp_LOOP_2DREPEAT_2D; 
extern SYMBOL s_lsp_REPEAT; 
extern SYMBOL s_lsp_PLUSP; 
extern SYMBOL s_lsp_1_2D; 
extern LP p_lsp_LOOP_2DWHEN_2DIT_2DVARIABLE();
extern SYMBOL s_lsp_LOOP_2DIT_2D; 
extern LP p_lsp_LOOP_2DFOR_2DEQUALS();
extern SYMBOL s_lsp_THEN; 
MAKE_CONS(k2295,LREF(s_lsp_NIL),LREF(k2202));
MAKE_CONS(k2294,LREF(s_lsp_NIL),LREF(k2295));
MAKE_CONS(k2293,LREF(s_lsp_NIL),LREF(k2294));
MAKE_CONS(k2292,LREF(s_lsp_NIL),LREF(k2293));
MAKE_CONS(k2291,LREF(s_lsp_NIL),LREF(k2292));
extern LP p_lsp_LOOP_2DFOR_2DFIRST();
MAKE_SIMPLE_STRING(k2296,42,"found where THEN expected in FOR ... FIRST");
extern SYMBOL s_lsp_FIRST; 
extern LP p_lsp_LOOP_2DLIST_2DSTEPPER();
extern SYMBOL s_lsp_BY; 
extern SYMBOL s_lsp_IN; 
extern SYMBOL s_lsp_ON; 
extern SYMBOL s_lsp_FUNCTION; 
MAKE_CONS(k2297,LREF(s_lsp_FUNCTION),LREF(k2259));
MAKE_CONS(k2299,LREF(s_lsp_FUNCTION),LREF(s_lsp_NIL));
MAKE_CONS(k2298,LREF(s_lsp_QUOTE),LREF(k2299));
extern SYMBOL s_lsp_LOOP_2DFN_2D; 
extern SYMBOL s_lsp_FUNCALL; 
extern SYMBOL s_lsp_LOOP_2DLIST_2D; 
extern LP p_lsp_LOOP_2DFOR_2DARITHMETIC();
extern SYMBOL s_lsp_FROM; 
extern SYMBOL s_lsp_UPFROM; 
extern SYMBOL s_lsp_DOWNFROM; 
extern SYMBOL s_lsp_TO; 
extern SYMBOL s_lsp_UPTO; 
extern SYMBOL s_lsp_DOWNTO; 
extern SYMBOL s_lsp_ABOVE; 
extern SYMBOL s_lsp_BELOW; 
MAKE_CONS(k2308,LREF(s_lsp_BY),LREF(s_lsp_NIL));
MAKE_CONS(k2307,LREF(s_lsp_BELOW),LREF(k2308));
MAKE_CONS(k2306,LREF(s_lsp_ABOVE),LREF(k2307));
MAKE_CONS(k2305,LREF(s_lsp_DOWNTO),LREF(k2306));
MAKE_CONS(k2304,LREF(s_lsp_UPTO),LREF(k2305));
MAKE_CONS(k2303,LREF(s_lsp_TO),LREF(k2304));
MAKE_CONS(k2302,LREF(s_lsp_DOWNFROM),LREF(k2303));
MAKE_CONS(k2301,LREF(s_lsp_UPFROM),LREF(k2302));
MAKE_CONS(k2300,LREF(s_lsp_FROM),LREF(k2301));
extern SYMBOL s_lsp_LOOP_2DGATHER_2DPREPS; 
extern SYMBOL s_lsp_LOOP_2DSEQUENCER; 
extern LP p_lsp_LOOP_2DNAMED_2DVARIABLE();
extern LP p_lsp_LOOP_2DFOR_2DBEING();
extern SYMBOL s_lsp_EACH; 
extern SYMBOL s_lsp_THE; 
extern SYMBOL s_lsp_LOOP_2DPATH_2DKEYWORD_2DALIST; 
extern SYMBOL s_lsp_BEING; 
MAKE_SIMPLE_STRING(k2309,35,"Malformed BEING EACH clause in LOOP");
extern SYMBOL s_lsp_OF; 
extern SYMBOL s_lsp_ITS; 
extern SYMBOL s_lsp_HIS; 
extern SYMBOL s_lsp_HER; 
extern SYMBOL s_lsp_THEIR; 
MAKE_CONS(k2314,LREF(s_lsp_EACH),LREF(s_lsp_NIL));
MAKE_CONS(k2313,LREF(s_lsp_THEIR),LREF(k2314));
MAKE_CONS(k2312,LREF(s_lsp_HER),LREF(k2313));
MAKE_CONS(k2311,LREF(s_lsp_HIS),LREF(k2312));
MAKE_CONS(k2310,LREF(s_lsp_ITS),LREF(k2311));
MAKE_SIMPLE_STRING(k2315,45,"found where ITS or EACH expected in LOOP path");
MAKE_SIMPLE_STRING(k2318,3,"...");
MAKE_CONS(k2319,LREF(s_lsp_IN),LREF(s_lsp_NIL));
MAKE_CONS(k2317,LREF(k2318),LREF(k2319));
MAKE_CONS(k2316,LREF(s_lsp_BEING),LREF(k2317));
extern SYMBOL s_lsp_DEFAULT_2DLOOP_2DPATH; 
MAKE_SIMPLE_STRING(k2320,29,"Undefined LOOP iteration path");
MAKE_SIMPLE_STRING(k2321,22,"unused USING variables");
extern SYMBOL s_lsp_REVERSE; 
extern LP p_lsp_LOOP_2DGATHER_2DPREPS();
extern SYMBOL s_lsp_USING; 
MAKE_SIMPLE_STRING(k2322,29,"USING used in illegal context");
MAKE_SIMPLE_STRING(k2323,38,"bad variable pair in path USING phrase");
MAKE_SIMPLE_STRING(k2324,43,"Duplicated var substitition in USING phrase");
extern LP p_lsp_LOOP_2DADD_2DPATH();
extern SYMBOL s_key_TEST; 
extern LP p_lsp_LOOP_2DSEQUENCER();
extern SYMBOL s_lsp_1_2B; 
MAKE_CONS(k2325,LREF(s_lsp_OF),LREF(k2319));
MAKE_SIMPLE_STRING(k2326,32,"Sequence duplicated in LOOP path");
MAKE_CONS(k2329,LREF(s_lsp_UPFROM),LREF(s_lsp_NIL));
MAKE_CONS(k2328,LREF(s_lsp_DOWNFROM),LREF(k2329));
MAKE_CONS(k2327,LREF(s_lsp_FROM),LREF(k2328));
MAKE_SIMPLE_STRING(k2330,56,"Iteration start redundantly specified in LOOP sequencing");
extern SYMBOL s_lsp_DOWN; 
extern SYMBOL s_lsp_UP; 
MAKE_SIMPLE_STRING(k2331,53,"Endtest redundantly specified in LOOP sequencing path");
extern SYMBOL s_lsp_LOOP_2DMAYBE_2DBIND_2DFORM; 
extern SYMBOL s_lsp_LOOP_2DSTEP_2DBY_2D; 
MAKE_SIMPLE_STRING(k2332,29,"Illegal prep in sequence path");
MAKE_SIMPLE_STRING(k2333,55,"Conflicting stepping directions in LOOP sequencing path");
MAKE_SIMPLE_STRING(k2334,34,"Missing OF phrase in sequence path");
MAKE_CONS(k2336,LREF(s_lsp_UP),LREF(s_lsp_NIL));
MAKE_CONS(k2335,LREF(s_lsp_NIL),LREF(k2336));
extern SYMBOL s_lsp_LOOP_2DSEQ_2DLIMIT_2D; 
extern SYMBOL s_lsp_ARGS; 
MAKE_CONS(k2337,LREF(s_lsp__3E),LREF(s_lsp_ARGS));
extern SYMBOL s_lsp__3E_3D; 
MAKE_CONS(k2338,LREF(s_lsp__3E_3D),LREF(s_lsp_ARGS));
MAKE_SIMPLE_STRING(k2339,34,"Don't know where to start stepping");
MAKE_CONS(k2340,LREF(s_lsp__3C),LREF(s_lsp_ARGS));
extern SYMBOL s_lsp__3C_3D; 
MAKE_CONS(k2341,LREF(s_lsp__3C_3D),LREF(s_lsp_ARGS));
extern SYMBOL s_lsp__2D; 
extern SYMBOL s_lsp_SUBST; 
extern LP p_lsp_LOOP_2DSEQUENCE_2DELEMENTS_2DPATH();
extern SYMBOL s_lsp_INDEX; 
extern SYMBOL s_lsp_LOOP_2DNAMED_2DVARIABLE; 
extern SYMBOL s_lsp_SEQUENCE; 
MAKE_SIMPLE_STRING(k2342,31,"Can't step sequence inclusively");
extern LP p_lsp_INITIAL_2DVALUE();
extern LP p_lsp_VARIABLE_2DDECLARATIONS();


extern LP add();
extern LP subtract();
extern LP c_cons();


LP p_lsp_LOOP_2DMAKE_2DPSETQ(argc, v_FROBS_0)
      ARGC argc;  LP v_FROBS_0;
{
LP v_Y_41; LP v_X_40; LP v_Y_38; 
LP v_X_37; LP v_X_35; LP v_X_33; 
LP v_C_31; LP v_Y_29; LP v_X_28; 
LP v_Y_26; LP v_X_25; LP v_Y_23; 
LP v_X_22; LP v_X_20; LP v_X_18; 
LP v_C_16; LP v_X_14; LP v_X_12; 
LP v_C_10; LP v_X_8; LP v_X_6; 
LP v_C_4; LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; 
if (argc != 1) wna(argc,1);
if (v_FROBS_0 != NIL) {
v_X_2 = v_FROBS_0;
v_X_40 = ((LP) DEREF((v_FROBS_0) + 0 * 4));
v_C_31 = v_FROBS_0;
v_X_33 = v_FROBS_0;
v_X_35 = ((LP) DEREF((v_FROBS_0) + 1 * 4));
t1 = ((LP) DEREF((v_X_35) + 1 * 4));
if (t1 != NIL) {
v_C_10 = v_FROBS_0;
v_X_12 = v_FROBS_0;
v_X_14 = ((LP) DEREF((v_FROBS_0) + 1 * 4));
v_X_25 = ((LP) DEREF((v_X_14) + 0 * 4));
v_C_16 = v_FROBS_0;
v_X_18 = v_FROBS_0;
v_X_20 = ((LP) DEREF((v_FROBS_0) + 1 * 4));
t2 = ((LP) DEREF((v_X_20) + 1 * 4));
v_X_22 = ICALL(s_lsp_LOOP_2DMAKE_2DPSETQ) (1, t2);
v_Y_26 = (c_cons((v_X_22), (LREF(s_lsp_NIL))));
v_Y_29 = (c_cons((v_X_25), (v_Y_26)));
v_X_37 = (c_cons((LREF(s_lsp_PROG1)), (v_Y_29)));
} else {
v_C_4 = v_FROBS_0;
v_X_6 = v_FROBS_0;
v_X_8 = ((LP) DEREF((v_FROBS_0) + 1 * 4));
v_X_37 = ((LP) DEREF((v_X_8) + 0 * 4));
}
v_Y_41 = (c_cons((v_X_37), (LREF(s_lsp_NIL))));
t3 = (c_cons((v_X_40), (v_Y_41)));
t0 = ICALL(s_lsp_LOOP_2DMAKE_2DSETQ) (MV_CALL(argc,1), t3);
return(t0);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_LOOP_2DMAKE_2DDESETQ(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{
LP v_X_67; LP v_X_65; LP v_C_63; 
LP v_X_61; LP v_X_59; LP v_X_57; 
LP v_X_55; LP v_C_53; LP v_X_51; 
LP v_X_49; LP v_C_47; LP v_G3205_46; 
LP v_X_44; LP v_X_42; LP v_C_40; 
LP v_X_38; LP v_Y_36; LP v_X_35; 
LP v_TMP3204_34; LP v_X_32; LP v_X_30; 
LP v_C_28; LP v_VAL_25; LP v_VAR_24; 
LP v_R_23; LP v_X_22; LP v_Y_19; 
LP v_X_18; LP v_G3201_17; LP v_X_15; 
LP v_X_13; LP v_TMP3200_12; LP v_X_10; 
LP v_X_8; LP v_C_6; LP v_L_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; 
if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DUSE_2DSYSTEM_2DDESTRUCTURING_3F));
if (t1 != NIL) {
v_L_3 = v_X_0;
goto t_TEST3198_5;
t_LOOP3199_4:;
v_C_6 = v_L_3;
v_X_8 = v_C_6;
v_X_10 = ((LP) DEREF((v_C_6) + 1 * 4));
v_TMP3200_12 = ((LP) DEREF((v_X_10) + 1 * 4));
v_L_3 = v_TMP3200_12;
t_TEST3198_5:;
if (v_L_3 == NIL) {
v_X_18 = LREF(s_lsp_SETQ);
goto b_NIL_2;
}
v_X_15 = v_L_3;
t3 = ((LP) DEREF((v_X_15) + 0 * 4));
t2 = ICALL(s_lsp_NULL) (1, t3);
if (t2 != NIL) {
v_G3201_17 = LREF(s_lsp_NIL);
} else {
v_X_13 = v_L_3;
t4 = ((LP) DEREF((v_X_13) + 0 * 4));
v_G3201_17 = ICALL(s_lsp_SYMBOLP) (1, t4);
}
if (v_G3201_17 != NIL) {
} else {
v_X_18 = LREF(s_lsp_DESETQ);
goto b_NIL_2;
}
goto t_LOOP3199_4;
v_X_18 = NIL;
v_X_18 = v_X_18;
b_NIL_2:;
t0 = (c_cons((v_X_18), (v_X_0)));
return(t0);
} else {
v_X_22 = v_X_0;
v_R_23 = LREF(s_lsp_NIL);
v_VAR_24 = LREF(s_lsp_NIL);
v_VAL_25 = LREF(s_lsp_NIL);
goto t_TEST3202_27;
t_LOOP3203_26:;
v_C_28 = v_X_22;
v_X_30 = v_C_28;
v_X_32 = ((LP) DEREF((v_C_28) + 1 * 4));
v_TMP3204_34 = ((LP) DEREF((v_X_32) + 1 * 4));
v_X_22 = v_TMP3204_34;
t_TEST3202_27:;
if (v_X_22 == NIL) {
if (v_R_23 != NIL) {
v_Y_36 = v_R_23;
t5 = (c_cons((LREF(s_lsp_SETQ)), (v_Y_36)));
return(t5);
} else {
return(LREF(s_lsp_NIL));
}
return(t5);
}
v_X_38 = v_X_22;
v_VAR_24 = ((LP) DEREF((v_X_38) + 0 * 4));
v_C_40 = v_X_22;
v_X_42 = v_C_40;
v_X_44 = ((LP) DEREF((v_C_40) + 1 * 4));
v_VAL_25 = ((LP) DEREF((v_X_44) + 0 * 4));
t7 = ICALL(s_lsp_ATOM) (1, v_VAR_24);
if (t7 != NIL) {
t6 = LREF(s_lsp_NIL);
} else {
t8 = ICALL(s_lsp_ATOM) (1, v_VAL_25);
if (t8 != NIL) {
t6 = LREF(s_lsp_NIL);
} else {
v_X_59 = v_VAL_25;
t11 = ((LP) DEREF((v_X_59) + 0 * 4));
t10 = ICALL(s_lsp_MEMQL) (2, t11, LREF(k2193));
if (t10 != NIL) {
v_C_53 = v_VAL_25;
v_X_55 = v_C_53;
v_X_57 = ((LP) DEREF((v_C_53) + 1 * 4));
t12 = ((LP) DEREF((v_X_57) + 0 * 4));
t9 = ICALL(s_lsp_ATOM) (1, t12);
} else {
t9 = LREF(s_lsp_NIL);
}
t6 = ICALL(s_lsp_NOT) (1, t9);
}
}
if (t6 != NIL) {
v_G3205_46 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DDESETQ_2DTEMPORARY));
if (v_G3205_46 != NIL) {
t13 = v_G3205_46;
} else {
t15 = ICALL(s_lsp_SYMBOL_2DNAME) (1, LREF(s_lsp_LOOP_2DDESETQ_2D));
t14 = ICALL(s_lsp_GENTEMP) (1, t15);
t13 = ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DDESETQ_2DTEMPORARY), t14);
}
t16 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DDESETQ_2DTEMPORARY));
v_C_47 = v_X_22;
v_X_49 = v_C_47;
v_X_51 = ((LP) DEREF((v_C_47) + 1 * 4));
t17 = ((LP) DEREF((v_X_51) + 1 * 4));
v_X_22 = ICALL(s_lsp_LIST_2A) (5, t13, v_VAL_25, v_VAR_24, t16, t17);
}
v_X_61 = v_X_22;
t19 = ((LP) DEREF((v_X_61) + 0 * 4));
v_C_63 = v_X_22;
v_X_65 = v_C_63;
v_X_67 = ((LP) DEREF((v_C_63) + 1 * 4));
t20 = ((LP) DEREF((v_X_67) + 0 * 4));
t18 = ICALL(s_lsp_LOOP_2DDESETQ_2DINTERNAL) (2, t19, t20);
v_R_23 = ICALL(s_lsp_NCONC_2F2) (2, v_R_23, t18);
goto t_LOOP3203_26;
return(NIL);
}
}

LP p_lsp_LOOP_2DDESETQ_2DINTERNAL(argc, v_VAR_0, v_VAL_1)
      ARGC argc;  LP v_VAR_0; LP v_VAL_1;
{
LP v_Y_23; LP v_X_22; LP v_Y_20; 
LP v_X_19; LP v_X_17; LP v_Y_15; 
LP v_X_14; LP v_Y_12; LP v_X_11; 
LP v_X_9; LP v_Y_7; LP v_X_6; 
LP v_Y_4; LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 

if (argc != 2) wna(argc,2);
if (v_VAR_0 != NIL) {
t1 = ICALL(s_lsp_ATOM) (1, v_VAR_0);
if (t1 != NIL) {
v_X_3 = v_VAL_1;
v_Y_4 = LREF(s_lsp_NIL);
v_Y_7 = (c_cons((v_VAL_1), (LREF(s_lsp_NIL))));
t0 = (c_cons((v_VAR_0), (v_Y_7)));
return(t0);
} else {
v_X_9 = v_VAR_0;
t3 = ((LP) DEREF((v_VAR_0) + 0 * 4));
v_X_11 = v_VAL_1;
v_Y_12 = LREF(s_lsp_NIL);
v_Y_15 = (c_cons((v_VAL_1), (LREF(s_lsp_NIL))));
t4 = (c_cons((LREF(s_lsp_CAR)), (v_Y_15)));
t2 = ICALL(s_lsp_LOOP_2DDESETQ_2DINTERNAL) (2, t3, t4);
v_X_17 = v_VAR_0;
t6 = ((LP) DEREF((v_VAR_0) + 1 * 4));
v_X_19 = v_VAL_1;
v_Y_20 = LREF(s_lsp_NIL);
v_Y_23 = (c_cons((v_VAL_1), (LREF(s_lsp_NIL))));
t7 = (c_cons((LREF(s_lsp_CDR)), (v_Y_23)));
t5 = ICALL(s_lsp_LOOP_2DDESETQ_2DINTERNAL) (2, t6, t7);
t0 = ICALL(s_lsp_NCONC_2F2) (MV_CALL(argc,2), t2, t5);
return(t0);
}
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_LOOP_2DMAKE_2DSETQ(argc, v_PAIRS_0)
      ARGC argc;  LP v_PAIRS_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 1) wna(argc,1);
if (v_PAIRS_0 != NIL) {
t0 = ICALL(s_lsp_LOOP_2DMAKE_2DDESETQ) (MV_CALL(argc,1), v_PAIRS_0);
return(t0);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_LOOP_2DCONSTRUCT_2DRETURN(argc, v_FORM_0)
      ARGC argc;  LP v_FORM_0;
{
LP v_Y_17; LP v_X_16; LP v_Y_14; 
LP v_X_13; LP v_Y_11; LP v_X_10; 
LP v_Y_8; LP v_X_7; LP v_Y_5; 
LP v_X_4; LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; 
if (argc != 1) wna(argc,1);
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DPROG_2DNAMES));
if (t1 != NIL) {
v_X_2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DPROG_2DNAMES));
v_X_7 = ((LP) DEREF((v_X_2) + 0 * 4));
v_X_4 = v_FORM_0;
v_Y_5 = LREF(s_lsp_NIL);
v_Y_8 = (c_cons((v_FORM_0), (LREF(s_lsp_NIL))));
v_Y_11 = (c_cons((v_X_7), (v_Y_8)));
t0 = (c_cons((LREF(s_lsp_RETURN_2DFROM)), (v_Y_11)));
return(t0);
} else {
v_X_13 = v_FORM_0;
v_Y_14 = LREF(s_lsp_NIL);
v_Y_17 = (c_cons((v_FORM_0), (LREF(s_lsp_NIL))));
t0 = (c_cons((LREF(s_lsp_RETURN)), (v_Y_17)));
return(t0);
}
}

LP p_lsp_LOOP_2DTEQUAL(argc, v_X1_0, v_X2_1)
      ARGC argc;  LP v_X1_0; LP v_X2_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 2) wna(argc,2);
t1 = ICALL(s_lsp_SYMBOLP) (1, v_X1_0);
if (t1 != NIL) {
t0 = ICALL(s_lsp_STRING_3D) (MV_CALL(argc,2), v_X1_0, v_X2_1);
return(t0);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_LOOP_2DTASSOC(argc, v_KWD_0, v_ALIST_1)
      ARGC argc;  LP v_KWD_0; LP v_ALIST_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; 
if (argc != 2) wna(argc,2);
t1 = ICALL(s_lsp_SYMBOLP) (1, v_KWD_0);
if (t1 != NIL) {
t2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_STRING_3D));
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_IDENTITY));
t0 = ICALL(s_lsp_ASSOC_2F4) (MV_CALL(argc,4), v_KWD_0, v_ALIST_1, t2, t3);
return(t0);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_LOOP_2DTMEMBER(argc, v_KWD_0, v_LIST_1)
      ARGC argc;  LP v_KWD_0; LP v_LIST_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; 
if (argc != 2) wna(argc,2);
t1 = ICALL(s_lsp_SYMBOLP) (1, v_KWD_0);
if (t1 != NIL) {
t2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_STRING_3D));
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_IDENTITY));
t0 = ICALL(s_lsp_MEMBER_2F4) (MV_CALL(argc,4), v_KWD_0, v_LIST_1, t2, t3);
return(t0);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_LOOP_2DTRANSLATE(argc, v_X_0, v_LOOP_2DMACRO_2DENVIRONMENT_1)
      ARGC argc;  LP v_X_0; LP v_LOOP_2DMACRO_2DENVIRONMENT_1;
{

LP t0; LP t1; LP t2; LP t3; 
if (argc != 2) wna(argc,2);
BEGIN_SPEC_BIND(s_lsp_LOOP_2DMACRO_2DENVIRONMENT,v_LOOP_2DMACRO_2DENVIRONMENT_1);
t0 = ICALL(s_lsp_LOOP_2DTRANSLATE_2D1) (MV_CALL(argc,1), v_X_0);
END_SPEC_BIND(s_lsp_LOOP_2DMACRO_2DENVIRONMENT);
return(t0);
}

LP p_lsp_LOOP_2DEND_2DTESTIFY(argc, v_LIST_2DOF_2DFORMS_0)
      ARGC argc;  LP v_LIST_2DOF_2DFORMS_0;
{
LP v_X_7; LP v_Y_5; LP v_X_4; 
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; 
if (argc != 1) wna(argc,1);
if (v_LIST_2DOF_2DFORMS_0 != NIL) {
v_LIST_2DOF_2DFORMS_0 = ICALL(s_lsp_NREVERSE) (1, v_LIST_2DOF_2DFORMS_0);
v_X_7 = v_LIST_2DOF_2DFORMS_0;
t2 = ((LP) DEREF((v_X_7) + 1 * 4));
if (t2 != NIL) {
v_Y_5 = v_LIST_2DOF_2DFORMS_0;
t1 = (c_cons((LREF(s_lsp_OR)), (v_Y_5)));
} else {
v_X_2 = v_LIST_2DOF_2DFORMS_0;
t1 = ((LP) DEREF((v_X_2) + 0 * 4));
}
t0 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,3), LREF(s_lsp_WHEN), t1, LREF(k2199));
return(t0);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_LOOP_2DOPTIMIZE_2DDUPLICATED_2DCODE_2DETC(argc)
      ARGC argc; 
{
LP v_S3236_112; LP v_Y_110; LP v_X_109; 
LP v_VALUE3235_108; LP v_S3234_107; LP v_Y_105; 
LP v_X_104; LP v_VALUE3233_103; LP v_S3232_102; 
LP v_Y_100; LP v_X_99; LP v_VALUE3231_98; 
LP v_S3230_97; LP v_Y_95; LP v_X_94; 
LP v_VALUE3229_93; LP v_TEST3228_92; LP v_X_90; 
LP v_X_88; LP v_TMP3227_87; LP v_TMP3226_86; 
LP v_X_84; LP v_X_82; LP v_AA_79; 
LP v_BB_78; LP v_X_75; LP v_X_73; 
LP v_X_71; LP v_X_69; LP v_S3223_68; 
LP v_Y_66; LP v_X_65; LP v_VALUE3222_64; 
LP v_X_62; LP v_X_60; LP v_S3221_59; 
LP v_Y_57; LP v_X_56; LP v_VALUE3220_55; 
LP v_X_53; LP v_X_48; LP v_X_46; 
LP v_X_44; LP v_TMP3217_43; LP v_TMP3216_42; 
LP v_X_40; LP v_X_38; LP v_AA_35; 
LP v_BB_34; LP v_S3213_32; LP v_Y_30; 
LP v_X_29; LP v_VALUE3212_28; LP v_X_26; 
LP v_S3211_25; LP v_Y_23; LP v_X_22; 
LP v_VALUE3210_21; LP v_X_19; LP v_TMP3209_18; 
LP v_TMP3208_17; LP v_X_15; LP v_X_13; 
LP v_L2_10; LP v_L1_9; LP v_LASTDIFF_6; 
LP v_B_5; LP v_A_4; LP v_GROUPB_3; 
LP v_GROUPA_2; LP v_AFTER_1; LP v_BEFORE_0; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; LP t145; LP t146; LP t147; LP t148; LP t149; 
LP t150; LP t151; LP t152; LP t153; LP t154; LP t155; 
LP t156; LP t157; LP t158; LP t159; LP t160; LP t161; 
LP t162; LP t163; LP t164; LP t165; LP t166; LP t167; 
LP t168; LP t169; LP t170; LP t171; LP t172; LP t173; 
LP t174; LP t175; LP t176; LP t177; LP t178; LP t179; 
LP t180; LP t181; LP t182; LP t183; LP t184; LP t185; 
LP t186; LP t187; LP t188; 
if (argc != 0) wna(argc,0);
v_BEFORE_0 = LREF(s_lsp_NIL);
v_AFTER_1 = LREF(s_lsp_NIL);
v_GROUPA_2 = LREF(s_lsp_NIL);
v_GROUPB_3 = LREF(s_lsp_NIL);
v_A_4 = LREF(s_lsp_NIL);
v_B_5 = LREF(s_lsp_NIL);
v_LASTDIFF_6 = LREF(s_lsp_NIL);
t0 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DBEFORE_2DLOOP));
v_L1_9 = ICALL(s_lsp_NREVERSE) (1, t0);
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DAFTER_2DBODY));
v_L2_10 = ICALL(s_lsp_NREVERSE) (1, t1);
goto t_TEST3206_12;
t_LOOP3207_11:;
v_X_13 = v_L1_9;
v_TMP3208_17 = ((LP) DEREF((v_X_13) + 1 * 4));
v_X_15 = v_L2_10;
v_TMP3209_18 = ((LP) DEREF((v_X_15) + 1 * 4));
v_L1_9 = v_TMP3208_17;
v_L2_10 = v_TMP3209_18;
t_TEST3206_12:;
t2 = ICALL(s_lsp_EQUAL) (2, v_L1_9, v_L2_10);
if (t2 != NIL) {
t5 = ICALL(s_lsp_DELETE) (2, LREF(s_lsp_NIL), v_L1_9);
t7 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DBODY));
t6 = ICALL(s_lsp_NREVERSE) (1, t7);
t4 = ICALL(s_lsp_NCONC_2F2) (2, t5, t6);
t3 = ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DBODY), t4);
goto b_NIL_8;
}
v_X_19 = v_L1_9;
v_VALUE3210_21 = ((LP) DEREF((v_X_19) + 0 * 4));
v_Y_23 = v_BEFORE_0;
v_S3211_25 = (c_cons((v_VALUE3210_21), (v_Y_23)));
v_BEFORE_0 = v_S3211_25;
v_X_26 = v_L2_10;
v_VALUE3212_28 = ((LP) DEREF((v_X_26) + 0 * 4));
v_Y_30 = v_AFTER_1;
v_S3213_32 = (c_cons((v_VALUE3212_28), (v_Y_30)));
v_AFTER_1 = v_S3213_32;
goto t_LOOP3207_11;
b_NIL_8:;
t9 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DDUPLICATE_2DCODE));
t8 = ICALL(s_lsp_NULL) (1, t9);
if (t8 != NIL) {
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DBEFORE_2DLOOP), LREF(s_lsp_NIL));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DAFTER_2DBODY), LREF(s_lsp_NIL));
v_BEFORE_0 = ICALL(s_lsp_NREVERSE) (1, v_BEFORE_0);
v_AFTER_1 = ICALL(s_lsp_NREVERSE) (1, v_AFTER_1);
v_BB_34 = v_BEFORE_0;
v_AA_35 = v_AFTER_1;
goto t_TEST3214_37;
t_LOOP3215_36:;
v_X_38 = v_BB_34;
v_TMP3216_42 = ((LP) DEREF((v_X_38) + 1 * 4));
v_X_40 = v_AA_35;
v_TMP3217_43 = ((LP) DEREF((v_X_40) + 1 * 4));
v_BB_34 = v_TMP3216_42;
v_AA_35 = v_TMP3217_43;
t_TEST3214_37:;
if (v_AA_35 == NIL) {
goto b_NIL_33;
}
v_X_46 = v_AA_35;
t11 = ((LP) DEREF((v_X_46) + 0 * 4));
v_X_48 = v_BB_34;
t12 = ((LP) DEREF((v_X_48) + 0 * 4));
t10 = ICALL(s_lsp_EQUAL) (2, t11, t12);
if (t10 != NIL) {
v_X_44 = v_AA_35;
t14 = ((LP) DEREF((v_X_44) + 0 * 4));
t13 = ICALL(s_lsp_LOOP_2DSIMPLEP) (1, t14);
if (t13 == NIL) {
goto b_NIL_33;
}
} else {
v_LASTDIFF_6 = v_AA_35;
}
goto t_LOOP3215_36;
b_NIL_33:;
if (v_LASTDIFF_6 != NIL) {
goto t_TEST3218_52;
t_LOOP3219_51:;
t_TEST3218_52:;
v_X_60 = v_BEFORE_0;
t15 = ((LP) DEREF((v_X_60) + 0 * 4));
if (t15 != NIL) {
v_X_53 = v_BEFORE_0;
v_VALUE3220_55 = ((LP) DEREF((v_X_53) + 0 * 4));
v_Y_57 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DBEFORE_2DLOOP));
v_S3221_59 = (c_cons((v_VALUE3220_55), (v_Y_57)));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DBEFORE_2DLOOP), v_S3221_59);
}
v_X_69 = v_AFTER_1;
t16 = ((LP) DEREF((v_X_69) + 0 * 4));
if (t16 != NIL) {
v_X_62 = v_AFTER_1;
v_VALUE3222_64 = ((LP) DEREF((v_X_62) + 0 * 4));
v_Y_66 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DAFTER_2DBODY));
v_S3223_68 = (c_cons((v_VALUE3222_64), (v_Y_66)));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DAFTER_2DBODY), v_S3223_68);
}
v_X_71 = v_BEFORE_0;
v_BEFORE_0 = ((LP) DEREF((v_X_71) + 1 * 4));
v_X_73 = v_AFTER_1;
v_AFTER_1 = ((LP) DEREF((v_X_73) + 1 * 4));
v_X_75 = v_LASTDIFF_6;
t18 = ((LP) DEREF((v_X_75) + 1 * 4));
t17 = ICALL(s_lsp_EQ) (2, v_AFTER_1, t18);
if (t17 != NIL) {
goto b_NIL_50;
}
goto t_LOOP3219_51;
b_NIL_50:;
t20 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DBEFORE_2DLOOP));
t19 = ICALL(s_lsp_NREVERSE) (1, t20);
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DBEFORE_2DLOOP), t19);
t22 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DAFTER_2DBODY));
t21 = ICALL(s_lsp_NREVERSE) (1, t22);
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DAFTER_2DBODY), t21);
}
v_BB_78 = ICALL(s_lsp_NREVERSE) (1, v_BEFORE_0);
v_AA_79 = ICALL(s_lsp_NREVERSE) (1, v_AFTER_1);
goto t_TEST3224_81;
t_LOOP3225_80:;
v_X_82 = v_BB_78;
v_TMP3226_86 = ((LP) DEREF((v_X_82) + 1 * 4));
v_X_84 = v_AA_79;
v_TMP3227_87 = ((LP) DEREF((v_X_84) + 1 * 4));
v_BB_78 = v_TMP3226_86;
v_AA_79 = v_TMP3227_87;
t_TEST3224_81:;
if (v_AA_79 == NIL) {
goto b_NIL_77;
}
v_X_88 = v_AA_79;
v_A_4 = ((LP) DEREF((v_X_88) + 0 * 4));
v_X_90 = v_BB_78;
v_B_5 = ((LP) DEREF((v_X_90) + 0 * 4));
if (v_A_4 != NIL) {
v_TEST3228_92 = LREF(s_lsp_NIL);
} else {
v_TEST3228_92 = ICALL(s_lsp_NULL) (1, v_B_5);
}
if (v_TEST3228_92 != NIL) {
} else {
t23 = ICALL(s_lsp_EQUAL) (2, v_A_4, v_B_5);
if (t23 != NIL) {
ICALL(s_lsp_LOOP_2DOUTPUT_2DGROUP) (2, v_GROUPB_3, v_GROUPA_2);
v_VALUE3229_93 = v_A_4;
v_Y_95 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DBODY));
v_S3230_97 = (c_cons((v_VALUE3229_93), (v_Y_95)));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DBODY), v_S3230_97);
v_GROUPB_3 = LREF(s_lsp_NIL);
v_GROUPA_2 = LREF(s_lsp_NIL);
} else {
if (v_A_4 != NIL) {
v_VALUE3231_98 = v_A_4;
v_Y_100 = v_GROUPA_2;
v_S3232_102 = (c_cons((v_VALUE3231_98), (v_Y_100)));
v_GROUPA_2 = v_S3232_102;
}
if (v_B_5 != NIL) {
v_VALUE3233_103 = v_B_5;
v_Y_105 = v_GROUPB_3;
v_S3234_107 = (c_cons((v_VALUE3233_103), (v_Y_105)));
v_GROUPB_3 = v_S3234_107;
} else {
}
}
}
goto t_LOOP3225_80;
b_NIL_77:;
ICALL(s_lsp_LOOP_2DOUTPUT_2DGROUP) (2, v_GROUPB_3, v_GROUPA_2);
} else {
t25 = ICALL(s_lsp_DELETE) (2, LREF(s_lsp_NIL), v_BEFORE_0);
t24 = ICALL(s_lsp_NREVERSE) (1, t25);
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DBEFORE_2DLOOP), t24);
t27 = ICALL(s_lsp_DELETE) (2, LREF(s_lsp_NIL), v_AFTER_1);
t26 = ICALL(s_lsp_NREVERSE) (1, t27);
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DAFTER_2DBODY), t26);
}
t28 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DNEVER_2DSTEPPED_2DVARIABLE));
if (t28 != NIL) {
t29 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DNEVER_2DSTEPPED_2DVARIABLE));
v_VALUE3235_108 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_SETQ), t29, LREF(k2202));
v_Y_110 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DAFTER_2DBODY));
v_S3236_112 = (c_cons((v_VALUE3235_108), (v_Y_110)));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DAFTER_2DBODY), v_S3236_112);
}
return(LREF(s_lsp_NIL));
}

LP p_lsp_LOOP_2DOUTPUT_2DGROUP(argc, v_BEFORE_0, v_AFTER_1)
      ARGC argc;  LP v_BEFORE_0; LP v_AFTER_1;
{
LP v_G3240_49; LP v_S3239_48; LP v_Y_46; 
LP v_X_45; LP v_VALUE3238_44; LP v_Y_42; 
LP v_X_41; LP v_Y_39; LP v_X_38; 
LP v_Y_36; LP v_X_35; LP v_Y_33; 
LP v_X_32; LP v_Y_30; LP v_X_29; 
LP v_Y_27; LP v_X_26; LP v_Y_24; 
LP v_X_23; LP v_Y_21; LP v_X_20; 
LP v_Y_18; LP v_X_17; LP v_Y_15; 
LP v_X_14; LP v_Y_12; LP v_X_11; 
LP v_Y_9; LP v_X_8; LP v_Y_6; 
LP v_X_5; LP v_V_4; LP v_G3237_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; 
if (argc != 2) wna(argc,2);
v_G3240_49 = v_AFTER_1;
if (v_G3240_49 != NIL) {
t1 = v_G3240_49;
} else {
t1 = v_BEFORE_0;
}
if (t1 != NIL) {
v_G3237_3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DNEVER_2DSTEPPED_2DVARIABLE));
if (v_G3237_3 != NIL) {
v_V_4 = v_G3237_3;
} else {
t4 = ICALL(s_lsp_SYMBOL_2DNAME) (1, LREF(s_lsp_LOOP_2DITER_2DFLAG_2D));
t3 = ICALL(s_lsp_GENTEMP) (1, t4);
t2 = ICALL(s_lsp_LOOP_2DMAKE_2DVARIABLE) (3, t3, LREF(s_lsp_T), LREF(s_lsp_NIL));
v_V_4 = ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DNEVER_2DSTEPPED_2DVARIABLE), t2);
}
if (v_BEFORE_0 != NIL) {
if (v_AFTER_1 != NIL) {
v_X_29 = v_V_4;
v_Y_30 = v_BEFORE_0;
v_X_38 = (c_cons((v_V_4), (v_BEFORE_0)));
v_X_32 = LREF(s_lsp_T);
v_Y_33 = v_AFTER_1;
v_X_35 = (c_cons((LREF(s_lsp_T)), (v_AFTER_1)));
v_Y_39 = (c_cons((v_X_35), (LREF(s_lsp_NIL))));
v_Y_42 = (c_cons((v_X_38), (v_Y_39)));
v_VALUE3238_44 = (c_cons((LREF(s_lsp_COND)), (v_Y_42)));
} else {
v_X_17 = LREF(s_lsp_PROGN);
v_Y_18 = v_BEFORE_0;
v_X_20 = (c_cons((LREF(s_lsp_PROGN)), (v_BEFORE_0)));
v_Y_24 = (c_cons((v_X_20), (LREF(s_lsp_NIL))));
v_Y_27 = (c_cons((v_V_4), (v_Y_24)));
v_VALUE3238_44 = (c_cons((LREF(s_lsp_WHEN)), (v_Y_27)));
}
} else {
v_X_5 = LREF(s_lsp_PROGN);
v_Y_6 = v_AFTER_1;
v_X_8 = (c_cons((LREF(s_lsp_PROGN)), (v_AFTER_1)));
v_Y_12 = (c_cons((v_X_8), (LREF(s_lsp_NIL))));
v_Y_15 = (c_cons((v_V_4), (v_Y_12)));
v_VALUE3238_44 = (c_cons((LREF(s_lsp_UNLESS)), (v_Y_15)));
}
v_Y_46 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DBODY));
v_S3239_48 = (c_cons((v_VALUE3238_44), (v_Y_46)));
t0 = ICALL(s_lsp_SET) (MV_CALL(argc,2), LREF(s_lsp_LOOP_2DBODY), v_S3239_48);
return(t0);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_LOOP_2DTRANSLATE_2D1(argc, v_LOOP_2DSOURCE_2DCODE_0)
      ARGC argc;  LP v_LOOP_2DSOURCE_2DCODE_0;
{
LP v_Y_226; LP v_X_225; LP v_Y_223; 
LP v_X_222; LP v_Y_220; LP v_X_219; 
LP v_X_217; LP v_X_215; LP v_C_213; 
LP v_X_211; LP v_X_209; LP v_X_207; 
LP v_C_205; LP v_X_203; LP v_X_201; 
LP v_C_199; LP v_X_197; LP v_S3308_196; 
LP v_X_194; LP v_VALUE3307_193; LP v_X_191; 
LP v_LIST3306_190; LP v_Y_188; LP v_X_187; 
LP v_X_185; LP v_TMP3305_184; LP v_X_182; 
LP v_L_179; LP v_X_176; LP v_X_174; 
LP v_X_172; LP v_C_170; LP v_G3302_169; 
LP v_X_167; LP v_X_165; LP v_C_163; 
LP v_TMP3301_162; LP v_X_160; LP v_L_157; 
LP v_Y_154; LP v_X_153; LP v_X_151; 
LP v_S3298_150; LP v_Y_148; LP v_X_147; 
LP v_VALUE3297_146; LP v_X_144; LP v_X_142; 
LP v_C_140; LP v_S3296_139; LP v_Y_137; 
LP v_X_136; LP v_VALUE3295_135; LP v_X_133; 
LP v_S3294_132; LP v_Y_130; LP v_X_129; 
LP v_VALUE3293_128; LP v_S3292_127; LP v_Y_125; 
LP v_X_124; LP v_VALUE3291_123; LP v_TMP3290_122; 
LP v_X_120; LP v_V_117; LP v_L_116; 
LP v_LAMBDA_2DVALS_114; LP v_LAMBDA_2DVARS_113; LP v_S3287_112; 
LP v_Y_110; LP v_X_109; LP v_VALUE3286_108; 
LP v_Y_106; LP v_X_105; LP v_S3285_104; 
LP v_X_102; LP v_VALUE3284_101; LP v_X_99; 
LP v_LIST3283_98; LP v_S3282_97; LP v_Y_95; 
LP v_X_94; LP v_VALUE3281_93; LP v_Y_91; 
LP v_X_90; LP v_X_88; LP v_X_86; 
LP v_X_84; LP v_X_82; LP v_CROCKS_79; 
LP v_DCLS_78; LP v_VARS_77; LP v_Y_74; 
LP v_X_73; LP v_Y_71; LP v_X_70; 
LP v_Y_68; LP v_X_67; LP v_Y_65; 
LP v_X_64; LP v_Y_62; LP v_X_61; 
LP v_Y_59; LP v_X_58; LP v_Y_56; 
LP v_X_55; LP v_Y_53; LP v_X_52; 
LP v_X_50; LP v_S3278_49; LP v_Y_47; 
LP v_X_46; LP v_VALUE3277_45; LP v_X_43; 
LP v_X_41; LP v_X_39; LP v_X_37; 
LP v_C_35; LP v_PROGVARS_32; LP v_TEM_31; 
LP v_KEYWORD_30; LP v_LOOP_2DCOLLECT_2DCRUFT_29; LP v_LOOP_2DPROG_2DNAMES_28; 
LP v_LOOP_2DDESETQ_2DTEMPORARY_27; LP v_LOOP_2DNEVER_2DSTEPPED_2DVARIABLE_26; LP v_LOOP_2DWHEN_2DIT_2DVARIABLE_25; 
LP v_LOOP_2DCONDITIONALS_24; LP v_LOOP_2DAFTER_2DEPILOGUE_23; LP v_LOOP_2DEPILOGUE_22; 
LP v_LOOP_2DAFTER_2DBODY_21; LP v_LOOP_2DEMITTED_2DBODY_3F_20; LP v_LOOP_2DBODY_19; 
LP v_LOOP_2DBEFORE_2DLOOP_18; LP v_LOOP_2DWRAPPERS_17; LP v_LOOP_2DPROLOGUE_16; 
LP v_LOOP_2DDESETQ_2DSTACK_15; LP v_LOOP_2DDECLARATION_2DSTACK_14; LP v_LOOP_2DVARIABLE_2DSTACK_13; 
LP v_LOOP_2DDESETQ_2DCROCKS_12; LP v_LOOP_2DDECLARATIONS_11; LP v_LOOP_2DNAMED_2DVARIABLES_10; 
LP v_LOOP_2DNODECLARE_9; LP v_LOOP_2DVARIABLES_8; LP v_LOOP_2DITERATION_2DVARIABLEP_7; 
LP v_LOOP_2DITERATION_2DVARIABLES_6; LP v_X_4; LP v_X_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; LP t145; LP t146; LP t147; LP t148; LP t149; 
LP t150; LP t151; LP t152; LP t153; LP t154; LP t155; 
LP t156; LP t157; LP t158; LP t159; LP t160; LP t161; 
LP t162; LP t163; LP t164; LP t165; LP t166; LP t167; 
LP t168; LP t169; LP t170; LP t171; LP t172; LP t173; 
LP t174; LP t175; LP t176; LP t177; LP t178; LP t179; 
LP t180; LP t181; LP t182; LP t183; LP t184; LP t185; 
LP t186; LP t187; LP t188; LP t189; LP t190; LP t191; 
LP t192; LP t193; LP t194; LP t195; LP t196; LP t197; 
LP t198; LP t199; LP t200; LP t201; LP t202; LP t203; 
LP t204; LP t205; LP t206; LP t207; LP t208; LP t209; 
LP t210; LP t211; LP t212; LP t213; LP t214; LP t215; 
LP t216; LP t217; LP t218; LP t219; LP t220; LP t221; 
LP t222; LP t223; LP t224; LP t225; LP t226; LP t227; 
LP t228; LP t229; LP t230; LP t231; LP t232; LP t233; 
LP t234; LP t235; LP t236; LP t237; LP t238; LP t239; 
LP t240; LP t241; LP t242; LP t243; LP t244; LP t245; 
LP t246; LP t247; LP t248; LP t249; LP t250; LP t251; 
LP t252; LP t253; LP t254; LP t255; LP t256; LP t257; 
LP t258; LP t259; LP t260; LP t261; LP t262; LP t263; 
LP t264; LP t265; LP t266; LP t267; LP t268; LP t269; 
LP t270; LP t271; LP t272; LP t273; LP t274; LP t275; 
LP t276; LP t277; LP t278; LP t279; LP t280; LP t281; 
LP t282; LP t283; LP t284; LP t285; LP t286; LP t287; 
LP t288; LP t289; LP t290; LP t291; LP t292; LP t293; 
LP t294; LP t295; LP t296; LP t297; LP t298; LP t299; 
LP t300; 
if (argc != 1) wna(argc,1);
BEGIN_SPEC_BIND(s_lsp_LOOP_2DSOURCE_2DCODE,v_LOOP_2DSOURCE_2DCODE_0);
v_X_4 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
t1 = ((LP) DEREF((v_X_4) + 0 * 4));
t0 = ICALL(s_lsp_EQ) (2, t1, LREF(s_lsp_LOOP));
if (t0 != NIL) {
v_X_2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
t2 = ((LP) DEREF((v_X_2) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), t2);
}
BEGIN_CATCH(LREF(s_lsp_NIL886),argc);
v_KEYWORD_30 = LREF(s_lsp_NIL);
v_TEM_31 = LREF(s_lsp_NIL);
v_PROGVARS_32 = LREF(s_lsp_NIL);
BEGIN_SPEC_BIND(s_lsp_LOOP_2DITERATION_2DVARIABLES,LREF(s_lsp_NIL));
BEGIN_SPEC_BIND(s_lsp_LOOP_2DITERATION_2DVARIABLEP,LREF(s_lsp_NIL));
BEGIN_SPEC_BIND(s_lsp_LOOP_2DVARIABLES,LREF(s_lsp_NIL));
BEGIN_SPEC_BIND(s_lsp_LOOP_2DNODECLARE,LREF(s_lsp_NIL));
BEGIN_SPEC_BIND(s_lsp_LOOP_2DNAMED_2DVARIABLES,LREF(s_lsp_NIL));
BEGIN_SPEC_BIND(s_lsp_LOOP_2DDECLARATIONS,LREF(s_lsp_NIL));
BEGIN_SPEC_BIND(s_lsp_LOOP_2DDESETQ_2DCROCKS,LREF(s_lsp_NIL));
BEGIN_SPEC_BIND(s_lsp_LOOP_2DVARIABLE_2DSTACK,LREF(s_lsp_NIL));
BEGIN_SPEC_BIND(s_lsp_LOOP_2DDECLARATION_2DSTACK,LREF(s_lsp_NIL));
BEGIN_SPEC_BIND(s_lsp_LOOP_2DDESETQ_2DSTACK,LREF(s_lsp_NIL));
BEGIN_SPEC_BIND(s_lsp_LOOP_2DPROLOGUE,LREF(s_lsp_NIL));
BEGIN_SPEC_BIND(s_lsp_LOOP_2DWRAPPERS,LREF(s_lsp_NIL));
BEGIN_SPEC_BIND(s_lsp_LOOP_2DBEFORE_2DLOOP,LREF(s_lsp_NIL));
BEGIN_SPEC_BIND(s_lsp_LOOP_2DBODY,LREF(s_lsp_NIL));
BEGIN_SPEC_BIND(s_lsp_LOOP_2DEMITTED_2DBODY_3F,LREF(s_lsp_NIL));
BEGIN_SPEC_BIND(s_lsp_LOOP_2DAFTER_2DBODY,LREF(s_lsp_NIL));
BEGIN_SPEC_BIND(s_lsp_LOOP_2DEPILOGUE,LREF(s_lsp_NIL));
BEGIN_SPEC_BIND(s_lsp_LOOP_2DAFTER_2DEPILOGUE,LREF(s_lsp_NIL));
BEGIN_SPEC_BIND(s_lsp_LOOP_2DCONDITIONALS,LREF(s_lsp_NIL));
BEGIN_SPEC_BIND(s_lsp_LOOP_2DWHEN_2DIT_2DVARIABLE,LREF(s_lsp_NIL));
BEGIN_SPEC_BIND(s_lsp_LOOP_2DNEVER_2DSTEPPED_2DVARIABLE,LREF(s_lsp_NIL));
BEGIN_SPEC_BIND(s_lsp_LOOP_2DDESETQ_2DTEMPORARY,LREF(s_lsp_NIL));
BEGIN_SPEC_BIND(s_lsp_LOOP_2DPROG_2DNAMES,LREF(s_lsp_NIL));
BEGIN_SPEC_BIND(s_lsp_LOOP_2DCOLLECT_2DCRUFT,LREF(s_lsp_NIL));
goto t_TEST3275_34;
t_LOOP3276_33:;
t_TEST3275_34:;
t4 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
if (t4 == NIL) {
BEGIN_MV_CALL(dynamicblock_mv_holder2203,0);
t5 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DCONDITIONALS));
if (t5 != NIL) {
v_C_35 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DCONDITIONALS));
v_X_37 = v_C_35;
v_X_39 = ((LP) DEREF((v_C_35) + 0 * 4));
v_X_41 = ((LP) DEREF((v_X_39) + 1 * 4));
v_X_43 = ((LP) DEREF((v_X_41) + 0 * 4));
t6 = ((LP) DEREF((v_X_43) + 0 * 4));
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2205), t6);
}
ICALL(s_lsp_LOOP_2DOPTIMIZE_2DDUPLICATED_2DCODE_2DETC) (0);
ICALL(s_lsp_LOOP_2DBIND_2DBLOCK) (0);
t7 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DDESETQ_2DTEMPORARY));
if (t7 != NIL) {
v_VALUE3277_45 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DDESETQ_2DTEMPORARY));
v_Y_47 = v_PROGVARS_32;
v_S3278_49 = (c_cons((v_VALUE3277_45), (v_Y_47)));
v_PROGVARS_32 = v_S3278_49;
}
v_X_50 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DPROG_2DNAMES));
v_X_70 = ((LP) DEREF((v_X_50) + 0 * 4));
v_X_61 = v_PROGVARS_32;
t9 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DPROLOGUE));
t8 = ICALL(s_lsp_NREVERSE) (1, t9);
t11 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DBEFORE_2DLOOP));
t12 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DBODY));
t14 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DAFTER_2DBODY));
t18 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DEPILOGUE));
t17 = ICALL(s_lsp_NREVERSE) (1, t18);
t20 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DAFTER_2DEPILOGUE));
t19 = ICALL(s_lsp_NREVERSE) (1, t20);
t16 = ICALL(s_lsp_APPEND_2F2) (2, t17, t19);
t15 = ICALL(s_lsp_LIST_2A) (4, LREF(k2206), LREF(k2200), LREF(s_lsp_END_2DLOOP), t16);
t13 = ICALL(s_lsp_APPEND_2F2) (2, t14, t15);
v_Y_53 = ICALL(s_lsp_APPEND_2F2) (2, t12, t13);
t21 = (c_cons((LREF(s_lsp_NEXT_2DLOOP)), (v_Y_53)));
t10 = ICALL(s_lsp_APPEND_2F2) (2, t11, t21);
v_Y_56 = ICALL(s_lsp_APPEND_2F2) (2, t8, t10);
v_X_58 = (c_cons((LREF(s_lsp_TAGBODY)), (v_Y_56)));
v_Y_62 = (c_cons((v_X_58), (LREF(s_lsp_NIL))));
v_Y_65 = (c_cons((v_X_61), (v_Y_62)));
v_X_67 = (c_cons((LREF(s_lsp_LET)), (v_Y_65)));
v_Y_71 = (c_cons((v_X_67), (LREF(s_lsp_NIL))));
v_Y_74 = (c_cons((v_X_70), (v_Y_71)));
v_TEM_31 = (c_cons((LREF(s_lsp_BLOCK)), (v_Y_74)));
v_VARS_77 = LREF(s_lsp_NIL);
v_DCLS_78 = LREF(s_lsp_NIL);
v_CROCKS_79 = LREF(s_lsp_NIL);
goto t_TEST3279_81;
t_LOOP3280_80:;
t_TEST3279_81:;
t22 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DVARIABLE_2DSTACK));
if (t22 == NIL) {
goto b_NIL_76;
}
v_X_82 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DVARIABLE_2DSTACK));
v_VARS_77 = ((LP) DEREF((v_X_82) + 0 * 4));
v_X_84 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DVARIABLE_2DSTACK));
t23 = ((LP) DEREF((v_X_84) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DVARIABLE_2DSTACK), t23);
v_X_86 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DDECLARATION_2DSTACK));
v_DCLS_78 = ((LP) DEREF((v_X_86) + 0 * 4));
v_X_88 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DDECLARATION_2DSTACK));
t24 = ((LP) DEREF((v_X_88) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DDECLARATION_2DSTACK), t24);
v_X_90 = v_TEM_31;
v_TEM_31 = (c_cons((v_X_90), (LREF(s_lsp_NIL))));
v_LIST3283_98 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DDESETQ_2DSTACK));
v_X_99 = v_LIST3283_98;
v_VALUE3284_101 = ((LP) DEREF((v_LIST3283_98) + 0 * 4));
v_X_102 = v_LIST3283_98;
v_S3285_104 = ((LP) DEREF((v_LIST3283_98) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DDESETQ_2DSTACK), v_S3285_104);
v_CROCKS_79 = v_VALUE3284_101;
if (v_CROCKS_79 != NIL) {
v_VALUE3281_93 = ICALL(s_lsp_LOOP_2DMAKE_2DDESETQ) (1, v_CROCKS_79);
v_Y_95 = v_TEM_31;
v_S3282_97 = (c_cons((v_VALUE3281_93), (v_Y_95)));
v_TEM_31 = v_S3282_97;
}
if (v_DCLS_78 != NIL) {
v_Y_106 = v_DCLS_78;
v_VALUE3286_108 = (c_cons((LREF(s_lsp_DECLARE)), (v_Y_106)));
v_Y_110 = v_TEM_31;
v_S3287_112 = (c_cons((v_VALUE3286_108), (v_Y_110)));
v_TEM_31 = v_S3287_112;
}
v_L_157 = v_VARS_77;
goto t_TEST3299_159;
t_LOOP3300_158:;
v_X_160 = v_L_157;
v_TMP3301_162 = ((LP) DEREF((v_X_160) + 1 * 4));
v_L_157 = v_TMP3301_162;
t_TEST3299_159:;
if (v_L_157 == NIL) {
t25 = LREF(s_lsp_NIL);
goto b_NIL_156;
}
v_X_176 = v_L_157;
t27 = ((LP) DEREF((v_X_176) + 0 * 4));
t26 = ICALL(s_lsp_ATOM) (1, t27);
if (t26 == NIL) {
v_C_163 = v_L_157;
v_X_165 = v_C_163;
v_X_167 = ((LP) DEREF((v_C_163) + 0 * 4));
t28 = ((LP) DEREF((v_X_167) + 0 * 4));
v_G3302_169 = ICALL(s_lsp_NULL) (1, t28);
if (v_G3302_169 != NIL) {
t29 = v_G3302_169;
} else {
v_C_170 = v_L_157;
v_X_172 = v_C_170;
v_X_174 = ((LP) DEREF((v_C_170) + 0 * 4));
t31 = ((LP) DEREF((v_X_174) + 0 * 4));
t30 = ICALL(s_lsp_SYMBOLP) (1, t31);
t29 = ICALL(s_lsp_NOT) (1, t30);
}
if (t29 != NIL) {
t25 = LREF(s_lsp_T);
goto b_NIL_156;
}
}
goto t_LOOP3300_158;
t25 = NIL;
b_NIL_156:;
if (t25 != NIL) {
t32 = ICALL(s_lsp_NREVERSE) (1, v_VARS_77);
v_TEM_31 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_LET), t32, v_TEM_31);
} else {
v_LAMBDA_2DVARS_113 = LREF(s_lsp_NIL);
v_LAMBDA_2DVALS_114 = LREF(s_lsp_NIL);
v_L_116 = v_VARS_77;
v_V_117 = LREF(s_lsp_NIL);
goto t_TEST3288_119;
t_LOOP3289_118:;
v_X_120 = v_L_116;
v_TMP3290_122 = ((LP) DEREF((v_X_120) + 1 * 4));
v_L_116 = v_TMP3290_122;
t_TEST3288_119:;
if (v_L_116 == NIL) {
goto b_NIL_115;
}
v_X_151 = v_L_116;
v_V_117 = ((LP) DEREF((v_X_151) + 0 * 4));
t33 = ICALL(s_lsp_ATOM) (1, v_V_117);
if (t33 != NIL) {
v_VALUE3291_123 = v_V_117;
v_Y_125 = v_LAMBDA_2DVARS_113;
v_S3292_127 = (c_cons((v_VALUE3291_123), (v_Y_125)));
v_LAMBDA_2DVARS_113 = v_S3292_127;
v_VALUE3293_128 = LREF(s_lsp_NIL);
v_Y_130 = v_LAMBDA_2DVALS_114;
v_S3294_132 = (c_cons((LREF(s_lsp_NIL)), (v_Y_130)));
v_LAMBDA_2DVALS_114 = v_S3294_132;
} else {
v_X_133 = v_V_117;
v_VALUE3295_135 = ((LP) DEREF((v_X_133) + 0 * 4));
v_Y_137 = v_LAMBDA_2DVARS_113;
v_S3296_139 = (c_cons((v_VALUE3295_135), (v_Y_137)));
v_LAMBDA_2DVARS_113 = v_S3296_139;
v_C_140 = v_V_117;
v_X_142 = v_C_140;
v_X_144 = ((LP) DEREF((v_C_140) + 1 * 4));
v_VALUE3297_146 = ((LP) DEREF((v_X_144) + 0 * 4));
v_Y_148 = v_LAMBDA_2DVALS_114;
v_S3298_150 = (c_cons((v_VALUE3297_146), (v_Y_148)));
v_LAMBDA_2DVALS_114 = v_S3298_150;
}
goto t_LOOP3289_118;
b_NIL_115:;
v_X_153 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_LAMBDA), v_LAMBDA_2DVARS_113, v_TEM_31);
v_Y_154 = v_LAMBDA_2DVALS_114;
v_TEM_31 = (c_cons((v_X_153), (v_Y_154)));
}
goto t_LOOP3280_80;
b_NIL_76:;
v_L_179 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DWRAPPERS));
goto t_TEST3303_181;
t_LOOP3304_180:;
v_X_182 = v_L_179;
v_TMP3305_184 = ((LP) DEREF((v_X_182) + 1 * 4));
v_L_179 = v_TMP3305_184;
t_TEST3303_181:;
if (v_L_179 == NIL) {
goto b_NIL_178;
}
v_X_185 = v_L_179;
t34 = ((LP) DEREF((v_X_185) + 0 * 4));
v_X_187 = v_TEM_31;
t35 = (c_cons((v_X_187), (LREF(s_lsp_NIL))));
v_TEM_31 = ICALL(s_lsp_APPEND_2F2) (2, t34, t35);
goto t_LOOP3304_180;
b_NIL_178:;
THROW(LREF(s_lsp_NIL886),v_TEM_31,dynamicblock_mv_holder2203);
END_MV_CALL;
}
v_X_197 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_KEYWORD_30 = ((LP) DEREF((v_X_197) + 0 * 4));
t36 = ICALL(s_lsp_SYMBOLP) (1, v_KEYWORD_30);
if (t36 != NIL) {
v_LIST3306_190 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_191 = v_LIST3306_190;
v_VALUE3307_193 = ((LP) DEREF((v_LIST3306_190) + 0 * 4));
v_X_194 = v_LIST3306_190;
v_S3308_196 = ((LP) DEREF((v_LIST3306_190) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3308_196);
} else {
v_KEYWORD_30 = LREF(s_lsp_DO);
}
t37 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DKEYWORD_2DALIST));
v_TEM_31 = ICALL(s_lsp_LOOP_2DTASSOC) (2, v_KEYWORD_30, t37);
if (v_TEM_31 != NIL) {
v_C_199 = v_TEM_31;
v_X_201 = v_C_199;
v_X_203 = ((LP) DEREF((v_C_199) + 1 * 4));
t38 = ((LP) DEREF((v_X_203) + 1 * 4));
v_C_205 = v_TEM_31;
v_X_207 = v_C_205;
v_X_209 = ((LP) DEREF((v_C_205) + 1 * 4));
t39 = ((LP) DEREF((v_X_209) + 0 * 4));
p_lsp_APPLY(2, COERCE_TO_FUNCTION(t39), t38);
} else {
t40 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DITERATION_2DKEYWORD_2DALIST));
v_TEM_31 = ICALL(s_lsp_LOOP_2DTASSOC) (2, v_KEYWORD_30, t40);
if (v_TEM_31 != NIL) {
ICALL(s_lsp_LOOP_2DHACK_2DITERATION) (1, v_TEM_31);
} else {
t41 = ICALL(s_lsp_LOOP_2DTMEMBER) (2, v_KEYWORD_30, LREF(k2208));
if (t41 != NIL) {
v_X_225 = v_KEYWORD_30;
v_X_211 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_222 = ((LP) DEREF((v_X_211) + 0 * 4));
v_C_213 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_215 = v_C_213;
v_X_217 = ((LP) DEREF((v_C_213) + 1 * 4));
v_X_219 = ((LP) DEREF((v_X_217) + 0 * 4));
v_Y_223 = (c_cons((v_X_219), (LREF(s_lsp_NIL))));
v_Y_226 = (c_cons((v_X_222), (v_Y_223)));
t42 = (c_cons((v_X_225), (v_Y_226)));
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2210), t42);
} else {
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2211), v_KEYWORD_30);
}
}
}
goto t_LOOP3276_33;
END_SPEC_BIND(s_lsp_LOOP_2DCOLLECT_2DCRUFT);
END_SPEC_BIND(s_lsp_LOOP_2DPROG_2DNAMES);
END_SPEC_BIND(s_lsp_LOOP_2DDESETQ_2DTEMPORARY);
END_SPEC_BIND(s_lsp_LOOP_2DNEVER_2DSTEPPED_2DVARIABLE);
END_SPEC_BIND(s_lsp_LOOP_2DWHEN_2DIT_2DVARIABLE);
END_SPEC_BIND(s_lsp_LOOP_2DCONDITIONALS);
END_SPEC_BIND(s_lsp_LOOP_2DAFTER_2DEPILOGUE);
END_SPEC_BIND(s_lsp_LOOP_2DEPILOGUE);
END_SPEC_BIND(s_lsp_LOOP_2DAFTER_2DBODY);
END_SPEC_BIND(s_lsp_LOOP_2DEMITTED_2DBODY_3F);
END_SPEC_BIND(s_lsp_LOOP_2DBODY);
END_SPEC_BIND(s_lsp_LOOP_2DBEFORE_2DLOOP);
END_SPEC_BIND(s_lsp_LOOP_2DWRAPPERS);
END_SPEC_BIND(s_lsp_LOOP_2DPROLOGUE);
END_SPEC_BIND(s_lsp_LOOP_2DDESETQ_2DSTACK);
END_SPEC_BIND(s_lsp_LOOP_2DDECLARATION_2DSTACK);
END_SPEC_BIND(s_lsp_LOOP_2DVARIABLE_2DSTACK);
END_SPEC_BIND(s_lsp_LOOP_2DDESETQ_2DCROCKS);
END_SPEC_BIND(s_lsp_LOOP_2DDECLARATIONS);
END_SPEC_BIND(s_lsp_LOOP_2DNAMED_2DVARIABLES);
END_SPEC_BIND(s_lsp_LOOP_2DNODECLARE);
END_SPEC_BIND(s_lsp_LOOP_2DVARIABLES);
END_SPEC_BIND(s_lsp_LOOP_2DITERATION_2DVARIABLEP);
END_SPEC_BIND(s_lsp_LOOP_2DITERATION_2DVARIABLES);
t3 = NIL;
END_CATCH(t3);
END_SPEC_BIND(s_lsp_LOOP_2DSOURCE_2DCODE);
return(t3);
}

LP p_lsp_LOOP_2DBIND_2DBLOCK(argc)
      ARGC argc; 
{
LP v_S3314_15; LP v_Y_13; LP v_X_12; 
LP v_VALUE3313_11; LP v_S3312_10; LP v_Y_8; 
LP v_X_7; LP v_VALUE3311_6; LP v_S3310_5; 
LP v_Y_3; LP v_X_2; LP v_VALUE3309_1; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; 
if (argc != 0) wna(argc,0);
t2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DVARIABLES));
t1 = ICALL(s_lsp_NULL) (1, t2);
if (t1 != NIL) {
return(LREF(s_lsp_NIL));
} else {
v_VALUE3309_1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DVARIABLES));
v_Y_3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DVARIABLE_2DSTACK));
v_S3310_5 = (c_cons((v_VALUE3309_1), (v_Y_3)));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DVARIABLE_2DSTACK), v_S3310_5);
v_VALUE3311_6 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DDECLARATIONS));
v_Y_8 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DDECLARATION_2DSTACK));
v_S3312_10 = (c_cons((v_VALUE3311_6), (v_Y_8)));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DDECLARATION_2DSTACK), v_S3312_10);
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DVARIABLES), LREF(s_lsp_NIL));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DDECLARATIONS), LREF(s_lsp_NIL));
v_VALUE3313_11 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DDESETQ_2DCROCKS));
v_Y_13 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DDESETQ_2DSTACK));
v_S3314_15 = (c_cons((v_VALUE3313_11), (v_Y_13)));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DDESETQ_2DSTACK), v_S3314_15);
t0 = ICALL(s_lsp_SET) (MV_CALL(argc,2), LREF(s_lsp_LOOP_2DDESETQ_2DCROCKS), LREF(s_lsp_NIL));
return(t0);
}
}

LP p_lsp_LOOP_2DGET_2DPROGN_2D1(argc)
      ARGC argc; 
{
LP v_TMP3321_31; LP v_TMP3320_30; LP v_X_28; 
LP v_Y_26; LP v_X_25; LP v_S3324_24; 
LP v_X_22; LP v_VALUE3323_21; LP v_X_19; 
LP v_LIST3322_18; LP v_NEXTFORM_15; LP v_FORMS_14; 
LP v_X_12; LP v_Y_10; LP v_X_9; 
LP v_S3319_8; LP v_X_6; LP v_VALUE3318_5; 
LP v_X_3; LP v_LIST3317_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; 
if (argc != 0) wna(argc,0);
v_LIST3317_2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_3 = v_LIST3317_2;
v_VALUE3318_5 = ((LP) DEREF((v_LIST3317_2) + 0 * 4));
v_X_6 = v_LIST3317_2;
v_S3319_8 = ((LP) DEREF((v_LIST3317_2) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3319_8);
v_X_9 = v_VALUE3318_5;
v_FORMS_14 = (c_cons((v_X_9), (LREF(s_lsp_NIL))));
v_X_12 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_NEXTFORM_15 = ((LP) DEREF((v_X_12) + 0 * 4));
goto t_TEST3315_17;
t_LOOP3316_16:;
v_LIST3322_18 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_19 = v_LIST3322_18;
v_VALUE3323_21 = ((LP) DEREF((v_LIST3322_18) + 0 * 4));
v_X_22 = v_LIST3322_18;
v_S3324_24 = ((LP) DEREF((v_LIST3322_18) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3324_24);
v_X_25 = v_VALUE3323_21;
v_Y_26 = v_FORMS_14;
v_TMP3320_30 = (c_cons((v_X_25), (v_Y_26)));
v_X_28 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_TMP3321_31 = ((LP) DEREF((v_X_28) + 0 * 4));
v_FORMS_14 = v_TMP3320_30;
v_NEXTFORM_15 = v_TMP3321_31;
t_TEST3315_17:;
t1 = ICALL(s_lsp_ATOM) (1, v_NEXTFORM_15);
if (t1 != NIL) {
t2 = ICALL(s_lsp_NREVERSE) (MV_CALL(argc,1), v_FORMS_14);
return(t2);
return(NIL);
}
goto t_LOOP3316_16;
return(NIL);
}

LP p_lsp_LOOP_2DGET_2DPROGN(argc)
      ARGC argc; 
{
LP v_X_7; LP v_Y_5; LP v_X_4; 
LP v_X_2; LP v_FORMS_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; 
if (argc != 0) wna(argc,0);
v_FORMS_1 = ICALL(s_lsp_LOOP_2DGET_2DPROGN_2D1) (0);
v_X_7 = v_FORMS_1;
t1 = ((LP) DEREF((v_FORMS_1) + 1 * 4));
if (t1 != NIL) {
v_X_4 = LREF(s_lsp_PROGN);
v_Y_5 = v_FORMS_1;
t0 = (c_cons((LREF(s_lsp_PROGN)), (v_FORMS_1)));
return(t0);
} else {
v_X_2 = v_FORMS_1;
t0 = ((LP) DEREF((v_FORMS_1) + 0 * 4));
return(t0);
}
}

LP p_lsp_LOOP_2DGET_2DFORM(argc, v_FOR_0)
      ARGC argc;  LP v_FOR_0;
{
LP v_X_11; LP v_Y_9; LP v_X_8; 
LP v_Y_6; LP v_X_5; LP v_X_3; 
LP v_FORMS_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; 
if (argc != 1) wna(argc,1);
v_FORMS_2 = ICALL(s_lsp_LOOP_2DGET_2DPROGN_2D1) (0);
v_X_11 = v_FORMS_2;
t1 = ((LP) DEREF((v_FORMS_2) + 1 * 4));
if (t1 != NIL) {
t3 = ICALL(s_lsp_ATOM) (1, v_FOR_0);
if (t3 != NIL) {
v_X_5 = v_FOR_0;
v_Y_6 = v_FORMS_2;
t2 = (c_cons((v_FOR_0), (v_FORMS_2)));
} else {
t2 = ICALL(s_lsp_APPEND_2F2) (2, v_FOR_0, v_FORMS_2);
}
ICALL(s_lsp_WARN) (2, LREF(k2212), t2);
v_X_8 = LREF(s_lsp_PROGN);
v_Y_9 = v_FORMS_2;
t0 = (c_cons((LREF(s_lsp_PROGN)), (v_FORMS_2)));
return(t0);
} else {
v_X_3 = v_FORMS_2;
t0 = ((LP) DEREF((v_FORMS_2) + 0 * 4));
return(t0);
}
}

LP p_lsp_LOOP_2DTYPED_2DARITH(argc, v_SUBSTITUTABLE_2DEXPRESSION_0, v_DATA_2DTYPE_1)
      ARGC argc;  LP v_SUBSTITUTABLE_2DEXPRESSION_0; LP v_DATA_2DTYPE_1;
{

LP t0; 
if (argc != 2) wna(argc,2);
return(v_SUBSTITUTABLE_2DEXPRESSION_0);
}

LP p_lsp_LOOP_2DTYPED_2DINIT(argc, v_DATA_2DTYPE_0)
      ARGC argc;  LP v_DATA_2DTYPE_0;
{
LP v_G3326_6; LP v_S3325_5; LP v_X_3; 
LP v_TEM_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 

if (argc != 1) wna(argc,1);
v_TEM_2 = LREF(s_lsp_NIL);
v_S3325_5 = v_DATA_2DTYPE_0;
t2 = ICALL(s_lsp_SYMBOLP) (1, v_S3325_5);
if (t2 != NIL) {
v_G3326_6 = ICALL(s_lsp_GET) (2, v_S3325_5, LREF(s_key_DATA_2DTYPE));
if (v_G3326_6 != NIL) {
t1 = v_G3326_6;
} else {
t3 = ICALL(s_lsp_SYMBOL_2DNAME) (1, v_S3325_5);
v_S3325_5 = ICALL(s_lsp_FIND_2DSYMBOL) (2, t3, LREF(s_lsp_KEYWORD));
if (v_S3325_5 != NIL) {
t1 = ICALL(s_lsp_GET) (2, v_S3325_5, LREF(s_key_DATA_2DTYPE));
} else {
t1 = LREF(s_lsp_NIL);
}
}
} else {
t1 = LREF(s_lsp_NIL);
}
if (t1 != NIL) {
t0 = ICALL(s_lsp_INITIAL_2DVALUE) (MV_CALL(argc,1), v_DATA_2DTYPE_0);
return(t0);
} else {
t4 = ICALL(s_lsp_LOOP_2DTMEMBER) (2, v_DATA_2DTYPE_0, LREF(k2213));
if (t4 != NIL) {
return((LP) 0);
} else {
t5 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DFLOATING_2DPOINT_2DTYPES));
v_X_3 = ICALL(s_lsp_LOOP_2DTMEMBER) (2, v_DATA_2DTYPE_0, t5);
v_TEM_2 = ((LP) DEREF((v_X_3) + 0 * 4));
if (v_TEM_2 != NIL) {
t6 = ICALL(s_lsp_MEMQL) (2, v_TEM_2, LREF(k2216));
if (t6 != NIL) {
return(LREF(k2218));
} else {
t0 = ICALL(s_lsp_COERCE) (MV_CALL(argc,2), (LP) 0, v_TEM_2);
return(t0);
}
} else {
return(LREF(s_lsp_NIL));
}
}
}
}

LP p_lsp_LOOP_2DMAKE_2DVARIABLE(argc, v_NAME_0, v_INITIALIZATION_1, v_DTYPE_2)
      ARGC argc;  LP v_NAME_0; LP v_INITIALIZATION_1; LP v_DTYPE_2;
{
LP v_X_75; LP v_X_73; LP v_X_71; 
LP v_X_69; LP v_TCDR_68; LP v_TCAR_67; 
LP v_S3340_66; LP v_Y_64; LP v_X_63; 
LP v_VALUE3339_62; LP v_Y_60; LP v_X_59; 
LP v_Y_57; LP v_X_56; LP v_NEWVAR_55; 
LP v_S3338_54; LP v_Y_52; LP v_X_51; 
LP v_VALUE3337_50; LP v_Y_48; LP v_X_47; 
LP v_Y_45; LP v_X_44; LP v_S3336_43; 
LP v_Y_41; LP v_X_40; LP v_VALUE3334_39; 
LP v_Y_37; LP v_X_36; LP v_Y_34; 
LP v_X_33; LP v_G3335_32; LP v_G3333_31; 
LP v_S3332_30; LP v_Y_28; LP v_X_27; 
LP v_VALUE3331_26; LP v_S3330_25; LP v_Y_23; 
LP v_X_22; LP v_VALUE3329_21; LP v_Y_19; 
LP v_X_18; LP v_Y_16; LP v_X_15; 
LP v_S3328_14; LP v_Y_12; LP v_X_11; 
LP v_VALUE3327_10; LP v_Y_8; LP v_X_7; 
LP v_Y_5; LP v_X_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; LP t145; LP t146; LP t147; 
if (argc != 3) wna(argc,3);
if (v_NAME_0 != NIL) {
t0 = ICALL(s_lsp_ATOM) (1, v_NAME_0);
if (t0 != NIL) {
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DITERATION_2DVARIABLEP));
if (t1 != NIL) {
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DITERATION_2DVARIABLES));
t2 = ICALL(s_lsp_MEMQL) (2, v_NAME_0, t3);
if (t2 != NIL) {
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2219), v_NAME_0);
} else {
v_VALUE3331_26 = v_NAME_0;
v_Y_28 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DITERATION_2DVARIABLES));
v_S3332_30 = (c_cons((v_VALUE3331_26), (v_Y_28)));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DITERATION_2DVARIABLES), v_S3332_30);
}
} else {
t5 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DVARIABLES));
t4 = ICALL(s_lsp_ASSQL) (2, v_NAME_0, t5);
if (t4 != NIL) {
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2220), v_NAME_0);
}
}
v_G3333_31 = ICALL(s_lsp_SYMBOLP) (1, v_NAME_0);
if (v_G3333_31 != NIL) {
} else {
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2221), v_NAME_0);
}
ICALL(s_lsp_LOOP_2DDECLARE_2DVARIABLE) (2, v_NAME_0, v_DTYPE_2);
v_X_36 = v_NAME_0;
v_G3335_32 = v_INITIALIZATION_1;
if (v_G3335_32 != NIL) {
v_X_33 = v_G3335_32;
} else {
v_X_33 = ICALL(s_lsp_LOOP_2DTYPED_2DINIT) (1, v_DTYPE_2);
}
v_Y_37 = (c_cons((v_X_33), (LREF(s_lsp_NIL))));
v_VALUE3334_39 = (c_cons((v_X_36), (v_Y_37)));
v_Y_41 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DVARIABLES));
v_S3336_43 = (c_cons((v_VALUE3334_39), (v_Y_41)));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DVARIABLES), v_S3336_43);
} else {
if (v_INITIALIZATION_1 != NIL) {
t6 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DUSE_2DSYSTEM_2DDESTRUCTURING_3F));
if (t6 != NIL) {
ICALL(s_lsp_LOOP_2DDECLARE_2DVARIABLE) (2, v_NAME_0, v_DTYPE_2);
v_X_47 = v_NAME_0;
v_X_44 = v_INITIALIZATION_1;
v_Y_45 = LREF(s_lsp_NIL);
v_Y_48 = (c_cons((v_INITIALIZATION_1), (LREF(s_lsp_NIL))));
v_VALUE3337_50 = (c_cons((v_X_47), (v_Y_48)));
v_Y_52 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DVARIABLES));
v_S3338_54 = (c_cons((v_VALUE3337_50), (v_Y_52)));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DVARIABLES), v_S3338_54);
} else {
t7 = ICALL(s_lsp_SYMBOL_2DNAME) (1, LREF(s_lsp_LOOP_2DDESTRUCTURE_2D));
v_NEWVAR_55 = ICALL(s_lsp_GENTEMP) (1, t7);
v_X_56 = v_INITIALIZATION_1;
v_Y_57 = LREF(s_lsp_NIL);
v_Y_60 = (c_cons((v_INITIALIZATION_1), (LREF(s_lsp_NIL))));
v_VALUE3339_62 = (c_cons((v_NEWVAR_55), (v_Y_60)));
v_Y_64 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DVARIABLES));
v_S3340_66 = (c_cons((v_VALUE3339_62), (v_Y_64)));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DVARIABLES), v_S3340_66);
t9 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DDESETQ_2DCROCKS));
t8 = ICALL(s_lsp_LIST_2A) (3, v_NAME_0, v_NEWVAR_55, t9);
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DDESETQ_2DCROCKS), t8);
ICALL(s_lsp_LOOP_2DMAKE_2DVARIABLE) (3, v_NAME_0, LREF(s_lsp_NIL), v_DTYPE_2);
}
} else {
v_TCAR_67 = LREF(s_lsp_NIL);
v_TCDR_68 = LREF(s_lsp_NIL);
t10 = ICALL(s_lsp_ATOM) (1, v_DTYPE_2);
if (t10 != NIL) {
v_TCDR_68 = v_DTYPE_2;
v_TCAR_67 = v_TCDR_68;
} else {
v_X_69 = v_DTYPE_2;
v_TCAR_67 = ((LP) DEREF((v_DTYPE_2) + 0 * 4));
v_X_71 = v_DTYPE_2;
v_TCDR_68 = ((LP) DEREF((v_DTYPE_2) + 1 * 4));
}
v_X_73 = v_NAME_0;
t11 = ((LP) DEREF((v_X_73) + 0 * 4));
ICALL(s_lsp_LOOP_2DMAKE_2DVARIABLE) (3, t11, LREF(s_lsp_NIL), v_TCAR_67);
v_X_75 = v_NAME_0;
t12 = ((LP) DEREF((v_X_75) + 1 * 4));
ICALL(s_lsp_LOOP_2DMAKE_2DVARIABLE) (3, t12, LREF(s_lsp_NIL), v_TCDR_68);
}
}
} else {
t13 = ICALL(s_lsp_NULL) (1, v_INITIALIZATION_1);
if (t13 == NIL) {
t14 = ICALL(s_lsp_SYMBOL_2DNAME) (1, LREF(s_lsp_LOOP_2DIGNORE_2D));
v_NAME_0 = ICALL(s_lsp_GENTEMP) (1, t14);
v_X_7 = v_NAME_0;
v_X_4 = v_INITIALIZATION_1;
v_Y_5 = LREF(s_lsp_NIL);
v_Y_8 = (c_cons((v_INITIALIZATION_1), (LREF(s_lsp_NIL))));
v_VALUE3327_10 = (c_cons((v_X_7), (v_Y_8)));
v_Y_12 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DVARIABLES));
v_S3328_14 = (c_cons((v_VALUE3327_10), (v_Y_12)));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DVARIABLES), v_S3328_14);
v_X_15 = v_NAME_0;
v_Y_19 = (c_cons((v_X_15), (LREF(s_lsp_NIL))));
v_VALUE3329_21 = (c_cons((LREF(s_lsp_IGNORE)), (v_Y_19)));
v_Y_23 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DDECLARATIONS));
v_S3330_25 = (c_cons((v_VALUE3329_21), (v_Y_23)));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DDECLARATIONS), v_S3330_25);
}
}
return(v_NAME_0);
}

LP p_lsp_LOOP_2DMAKE_2DITERATION_2DVARIABLE(argc, v_NAME_0, v_INITIALIZATION_1, v_DTYPE_2)
      ARGC argc;  LP v_NAME_0; LP v_INITIALIZATION_1; LP v_DTYPE_2;
{
LP v_LOOP_2DITERATION_2DVARIABLEP_4; 
LP t0; LP t1; LP t2; 
if (argc != 3) wna(argc,3);
v_LOOP_2DITERATION_2DVARIABLEP_4 = LREF(s_lsp_T);
BEGIN_SPEC_BIND(s_lsp_LOOP_2DITERATION_2DVARIABLEP,LREF(s_lsp_T));
t0 = ICALL(s_lsp_LOOP_2DMAKE_2DVARIABLE) (MV_CALL(argc,3), v_NAME_0, v_INITIALIZATION_1, v_DTYPE_2);
END_SPEC_BIND(s_lsp_LOOP_2DITERATION_2DVARIABLEP);
return(t0);
}

LP p_lsp_LOOP_2DDECLARE_2DVARIABLE(argc, v_NAME_0, v_DTYPE_1)
      ARGC argc;  LP v_NAME_0; LP v_DTYPE_1;
{
LP v_G3346_41; LP v_Y_39; LP v_X_38; 
LP v_Y_36; LP v_X_35; LP v_Y_33; 
LP v_X_32; LP v_X_30; LP v_X_28; 
LP v_X_26; LP v_X_24; LP v_X_22; 
LP v_X_20; LP v_G3345_19; LP v_S3344_18; 
LP v_S3343_17; LP v_Y_15; LP v_X_14; 
LP v_VALUE3342_13; LP v_Y_11; LP v_X_10; 
LP v_Y_8; LP v_X_7; LP v_Y_5; 
LP v_X_4; LP v_TEST3341_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; 
if (argc != 2) wna(argc,2);
START2223:
v_G3346_41 = ICALL(s_lsp_NULL) (1, v_NAME_0);
if (v_G3346_41 != NIL) {
t1 = v_G3346_41;
} else {
t1 = ICALL(s_lsp_NULL) (1, v_DTYPE_1);
}
if (t1 != NIL) {
return(LREF(s_lsp_NIL));
} else {
t2 = ICALL(s_lsp_SYMBOLP) (1, v_NAME_0);
if (t2 != NIL) {
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DNODECLARE));
v_TEST3341_3 = ICALL(s_lsp_MEMQL) (2, v_NAME_0, t3);
if (v_TEST3341_3 != NIL) {
return(v_TEST3341_3);
} else {
v_S3344_18 = v_DTYPE_1;
t5 = ICALL(s_lsp_SYMBOLP) (1, v_S3344_18);
if (t5 != NIL) {
v_G3345_19 = ICALL(s_lsp_GET) (2, v_S3344_18, LREF(s_key_DATA_2DTYPE));
if (v_G3345_19 != NIL) {
t4 = v_G3345_19;
} else {
t6 = ICALL(s_lsp_SYMBOL_2DNAME) (1, v_S3344_18);
v_S3344_18 = ICALL(s_lsp_FIND_2DSYMBOL) (2, t6, LREF(s_lsp_KEYWORD));
if (v_S3344_18 != NIL) {
t4 = ICALL(s_lsp_GET) (2, v_S3344_18, LREF(s_key_DATA_2DTYPE));
} else {
t4 = LREF(s_lsp_NIL);
}
}
} else {
t4 = LREF(s_lsp_NIL);
}
if (t4 != NIL) {
t8 = ICALL(s_lsp_VARIABLE_2DDECLARATIONS) (2, v_DTYPE_1, v_NAME_0);
t9 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DDECLARATIONS));
t7 = ICALL(s_lsp_APPEND_2F2) (2, t8, t9);
t0 = ICALL(s_lsp_SET) (MV_CALL(argc,2), LREF(s_lsp_LOOP_2DDECLARATIONS), t7);
return(t0);
} else {
t10 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, v_DTYPE_1, LREF(s_lsp_NOTYPE));
if (t10 != NIL) {
v_X_7 = LREF(s_lsp_T);
} else {
v_X_7 = v_DTYPE_1;
}
v_X_4 = v_NAME_0;
v_Y_5 = LREF(s_lsp_NIL);
v_Y_8 = (c_cons((v_NAME_0), (LREF(s_lsp_NIL))));
v_Y_11 = (c_cons((v_X_7), (v_Y_8)));
v_VALUE3342_13 = (c_cons((LREF(s_lsp_TYPE)), (v_Y_11)));
v_Y_15 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DDECLARATIONS));
v_S3343_17 = (c_cons((v_VALUE3342_13), (v_Y_15)));
t0 = ICALL(s_lsp_SET) (MV_CALL(argc,2), LREF(s_lsp_LOOP_2DDECLARATIONS), v_S3343_17);
return(t0);
}
}
} else {
t11 = ICALL(s_lsp_CONSP) (1, v_NAME_0);
if (t11 != NIL) {
t12 = ICALL(s_lsp_CONSP) (1, v_DTYPE_1);
if (t12 != NIL) {
v_X_20 = v_NAME_0;
t13 = ((LP) DEREF((v_NAME_0) + 0 * 4));
v_X_22 = v_DTYPE_1;
t14 = ((LP) DEREF((v_DTYPE_1) + 0 * 4));
ICALL(s_lsp_LOOP_2DDECLARE_2DVARIABLE) (2, t13, t14);
v_X_24 = v_NAME_0;
t15 = ((LP) DEREF((v_NAME_0) + 1 * 4));
v_X_26 = v_DTYPE_1;
t16 = ((LP) DEREF((v_DTYPE_1) + 1 * 4));
v_NAME_0 = t15; v_DTYPE_1 = t16; 
goto START2223;
} else {
v_X_28 = v_NAME_0;
t17 = ((LP) DEREF((v_NAME_0) + 0 * 4));
ICALL(s_lsp_LOOP_2DDECLARE_2DVARIABLE) (2, t17, v_DTYPE_1);
v_X_30 = v_NAME_0;
t18 = ((LP) DEREF((v_NAME_0) + 1 * 4));
v_NAME_0 = t18; 
goto START2223;
}
} else {
v_X_32 = v_DTYPE_1;
v_Y_33 = LREF(s_lsp_NIL);
v_Y_36 = (c_cons((v_DTYPE_1), (LREF(s_lsp_NIL))));
v_Y_39 = (c_cons((v_NAME_0), (v_Y_36)));
t19 = (c_cons((LREF(s_lsp_LOOP_2DDECLARE_2DVARIABLE)), (v_Y_39)));
t0 = ICALL(s_lsp_ERROR) (MV_CALL(argc,3), LREF(k2204), LREF(k2224), t19);
return(t0);
}
}
}
}

LP p_lsp_LOOP_2DCONSTANTP(argc, v_FORM_0)
      ARGC argc;  LP v_FORM_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_CONSTANTP) (MV_CALL(argc,1), v_FORM_0);
return(t0);
}

LP p_lsp_LOOP_2DMAYBE_2DBIND_2DFORM(argc, v_FORM_0, v_DATA_2DTYPE_3F_1)
      ARGC argc;  LP v_FORM_0; LP v_DATA_2DTYPE_3F_1;
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; 
if (argc != 2) wna(argc,2);
t1 = ICALL(s_lsp_LOOP_2DCONSTANTP) (1, v_FORM_0);
if (t1 != NIL) {
return(v_FORM_0);
} else {
t3 = ICALL(s_lsp_SYMBOL_2DNAME) (1, LREF(s_lsp_LOOP_2DBIND_2D));
t2 = ICALL(s_lsp_GENTEMP) (1, t3);
t0 = ICALL(s_lsp_LOOP_2DMAKE_2DVARIABLE) (MV_CALL(argc,3), t2, v_FORM_0, v_DATA_2DTYPE_3F_1);
return(t0);
}
}

LP p_lsp_LOOP_2DOPTIONAL_2DTYPE(argc)
      ARGC argc; 
{
LP v_G3354_15; LP v_G3351_14; LP v_G3353_13; 
LP v_G3352_12; LP v_G3350_11; LP v_S3349_10; 
LP v_X_8; LP v_VALUE3348_7; LP v_X_5; 
LP v_LIST3347_4; LP v_TOKEN_3; LP v_X_1; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; 
if (argc != 0) wna(argc,0);
v_X_1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_TOKEN_3 = ((LP) DEREF((v_X_1) + 0 * 4));
t1 = ICALL(s_lsp_NULL) (1, v_TOKEN_3);
if (t1 != NIL) {
return(LREF(s_lsp_NIL));
} else {
t2 = ICALL(s_lsp_ATOM) (1, v_TOKEN_3);
v_G3350_11 = ICALL(s_lsp_NOT) (1, t2);
if (v_G3350_11 != NIL) {
t3 = v_G3350_11;
} else {
v_G3352_12 = v_TOKEN_3;
t4 = ICALL(s_lsp_SYMBOLP) (1, v_G3352_12);
if (t4 != NIL) {
v_G3353_13 = ICALL(s_lsp_GET) (2, v_G3352_12, LREF(s_key_DATA_2DTYPE));
if (v_G3353_13 != NIL) {
v_G3351_14 = v_G3353_13;
} else {
t5 = ICALL(s_lsp_SYMBOL_2DNAME) (1, v_G3352_12);
v_G3352_12 = ICALL(s_lsp_FIND_2DSYMBOL) (2, t5, LREF(s_lsp_KEYWORD));
if (v_G3352_12 != NIL) {
v_G3351_14 = ICALL(s_lsp_GET) (2, v_G3352_12, LREF(s_key_DATA_2DTYPE));
} else {
v_G3351_14 = LREF(s_lsp_NIL);
}
}
} else {
v_G3351_14 = LREF(s_lsp_NIL);
}
if (v_G3351_14 != NIL) {
t3 = v_G3351_14;
} else {
v_G3354_15 = ICALL(s_lsp_LOOP_2DTMEMBER) (2, v_TOKEN_3, LREF(k2225));
if (v_G3354_15 != NIL) {
t3 = v_G3354_15;
} else {
t6 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DFLOATING_2DPOINT_2DTYPES));
t3 = ICALL(s_lsp_LOOP_2DTMEMBER) (2, v_TOKEN_3, t6);
}
}
}
if (t3 != NIL) {
v_LIST3347_4 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_5 = v_LIST3347_4;
v_VALUE3348_7 = ((LP) DEREF((v_LIST3347_4) + 0 * 4));
v_X_8 = v_LIST3347_4;
v_S3349_10 = ((LP) DEREF((v_LIST3347_4) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3349_10);
return(v_VALUE3348_7);
} else {
return(LREF(s_lsp_NIL));
}
}
}

LP p_lsp_LOOP_2DMAKE_2DCONDITIONALIZATION(argc, v_FORM_0)
      ARGC argc;  LP v_FORM_0;
{
LP v_X_120; LP v_X_118; LP v_VALUE3366_117; 
LP v_X_115; LP v_V_113; LP v_X_112; 
LP v_NEW_2DCDR_110; LP v_C_109; LP v_Y_107; 
LP v_X_106; LP v_X_104; LP v_X_102; 
LP v_TMP3365_101; LP v_TMP3364_100; LP v_X_98; 
LP v_X_96; LP v_L_93; LP v_PREV_92; 
LP v_X_90; LP v_X_88; LP v_V_85; 
LP v_X_84; LP v_NEW_2DCDR_82; LP v_C_81; 
LP v_Y_79; LP v_X_78; LP v_Y_76; 
LP v_X_75; LP v_X_73; LP v_X_71; 
LP v_V_69; LP v_X_68; LP v_NEW_2DCDR_66; 
LP v_C_65; LP v_Y_63; LP v_X_62; 
LP v_X_60; LP v_X_58; LP v_X_56; 
LP v_Y_54; LP v_X_53; LP v_Y_51; 
LP v_X_50; LP v_Y_48; LP v_X_47; 
LP v_X_45; LP v_X_43; LP v_C_41; 
LP v_X_39; LP v_TEST3361_38; LP v_X_36; 
LP v_X_34; LP v_C_32; LP v_INNERMOST_31; 
LP v_X_29; LP v_S3360_28; LP v_X_26; 
LP v_VALUE3359_25; LP v_X_23; LP v_LIST3358_22; 
LP v_S3357_21; LP v_X_19; LP v_VALUE3356_18; 
LP v_X_16; LP v_LIST3355_15; LP v_V_13; 
LP v_X_12; LP v_NEW_2DCDR_10; LP v_C_9; 
LP v_Y_7; LP v_X_6; LP v_X_4; 
LP v_X_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; LP t145; LP t146; LP t147; LP t148; LP t149; 
LP t150; LP t151; LP t152; LP t153; LP t154; LP t155; 
LP t156; LP t157; LP t158; LP t159; LP t160; LP t161; 
LP t162; LP t163; LP t164; LP t165; LP t166; LP t167; 
LP t168; LP t169; LP t170; LP t171; LP t172; LP t173; 
LP t174; LP t175; LP t176; LP t177; LP t178; LP t179; 
LP t180; LP t181; LP t182; LP t183; LP t184; LP t185; 
LP t186; 
if (argc != 1) wna(argc,1);
t2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DCONDITIONALS));
t1 = ICALL(s_lsp_NULL) (1, t2);
if (t1 != NIL) {
return(v_FORM_0);
} else {
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DCONDITIONALS));
v_X_2 = ICALL(s_lsp_LAST) (1, t3);
t4 = ((LP) DEREF((v_X_2) + 0 * 4));
v_X_4 = ICALL(s_lsp_LAST) (1, t4);
t5 = ((LP) DEREF((v_X_4) + 0 * 4));
v_C_9 = ICALL(s_lsp_LAST) (1, t5);
v_X_6 = v_FORM_0;
v_Y_7 = LREF(s_lsp_NIL);
v_NEW_2DCDR_10 = (c_cons((v_FORM_0), (LREF(s_lsp_NIL))));
v_V_13 = v_NEW_2DCDR_10;
((LP) (DEREF((v_C_9) + 1 * 4) = (LD) (v_V_13)));
v_X_120 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
t7 = ((LP) DEREF((v_X_120) + 0 * 4));
t6 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, t7, LREF(s_lsp_AND));
if (t6 != NIL) {
v_LIST3355_15 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_16 = v_LIST3355_15;
v_VALUE3356_18 = ((LP) DEREF((v_LIST3355_15) + 0 * 4));
v_X_19 = v_LIST3355_15;
v_S3357_21 = ((LP) DEREF((v_LIST3355_15) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3357_21);
return(LREF(s_lsp_NIL));
} else {
v_X_118 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
t9 = ((LP) DEREF((v_X_118) + 0 * 4));
t8 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, t9, LREF(s_lsp_ELSE));
if (t8 != NIL) {
v_LIST3358_22 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_23 = v_LIST3358_22;
v_VALUE3359_25 = ((LP) DEREF((v_LIST3358_22) + 0 * 4));
v_X_26 = v_LIST3358_22;
v_S3360_28 = ((LP) DEREF((v_LIST3358_22) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3360_28);
t10 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DCONDITIONALS));
v_X_29 = ICALL(s_lsp_LAST) (1, t10);
v_INNERMOST_31 = ((LP) DEREF((v_X_29) + 0 * 4));
v_C_32 = v_INNERMOST_31;
v_X_34 = v_INNERMOST_31;
v_X_36 = ((LP) DEREF((v_INNERMOST_31) + 1 * 4));
t11 = ((LP) DEREF((v_X_36) + 1 * 4));
v_TEST3361_38 = ICALL(s_lsp_NULL) (1, t11);
if (v_TEST3361_38 != NIL) {
} else {
v_X_71 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DCONDITIONALS));
t12 = ((LP) DEREF((v_X_71) + 1 * 4));
if (t12 != NIL) {
t13 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DCONDITIONALS));
v_X_56 = ICALL(s_lsp_NREVERSE) (1, t13);
t14 = ((LP) DEREF((v_X_56) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DCONDITIONALS), t14);
v_X_58 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DCONDITIONALS));
t15 = ((LP) DEREF((v_X_58) + 0 * 4));
v_X_60 = ICALL(s_lsp_LAST) (1, t15);
t16 = ((LP) DEREF((v_X_60) + 0 * 4));
v_C_65 = ICALL(s_lsp_LAST) (1, t16);
v_X_62 = v_INNERMOST_31;
v_Y_63 = LREF(s_lsp_NIL);
v_NEW_2DCDR_66 = (c_cons((v_INNERMOST_31), (LREF(s_lsp_NIL))));
v_V_69 = v_NEW_2DCDR_66;
((LP) (DEREF((v_C_65) + 1 * 4) = (LD) (v_V_69)));
t18 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DCONDITIONALS));
t17 = ICALL(s_lsp_NREVERSE) (1, t18);
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DCONDITIONALS), t17);
} else {
v_X_39 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_50 = ((LP) DEREF((v_X_39) + 0 * 4));
v_C_41 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_43 = v_C_41;
v_X_45 = ((LP) DEREF((v_C_41) + 1 * 4));
v_X_47 = ((LP) DEREF((v_X_45) + 0 * 4));
v_Y_51 = (c_cons((v_X_47), (LREF(s_lsp_NIL))));
v_Y_54 = (c_cons((v_X_50), (v_Y_51)));
t19 = (c_cons((LREF(s_lsp_ELSE)), (v_Y_54)));
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2229), t19);
}
}
t20 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DCONDITIONALS));
v_X_73 = ICALL(s_lsp_LAST) (1, t20);
t21 = ((LP) DEREF((v_X_73) + 0 * 4));
v_C_81 = ICALL(s_lsp_LAST) (1, t21);
v_X_75 = LREF(s_lsp_T);
v_Y_76 = LREF(s_lsp_NIL);
v_X_78 = (c_cons((LREF(s_lsp_T)), (LREF(s_lsp_NIL))));
v_NEW_2DCDR_82 = (c_cons((v_X_78), (LREF(s_lsp_NIL))));
v_V_85 = v_NEW_2DCDR_82;
((LP) (DEREF((v_C_81) + 1 * 4) = (LD) (v_V_85)));
return(LREF(s_lsp_NIL));
} else {
v_X_88 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DCONDITIONALS));
v_PREV_92 = ((LP) DEREF((v_X_88) + 0 * 4));
v_X_90 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DCONDITIONALS));
v_L_93 = ((LP) DEREF((v_X_90) + 1 * 4));
goto t_TEST3362_95;
t_LOOP3363_94:;
v_X_96 = v_L_93;
v_TMP3364_100 = ((LP) DEREF((v_X_96) + 0 * 4));
v_X_98 = v_L_93;
v_TMP3365_101 = ((LP) DEREF((v_X_98) + 1 * 4));
v_PREV_92 = v_TMP3364_100;
v_L_93 = v_TMP3365_101;
t_TEST3362_95:;
if (v_L_93 == NIL) {
goto b_NIL_87;
}
v_X_102 = ICALL(s_lsp_LAST) (1, v_PREV_92);
t22 = ((LP) DEREF((v_X_102) + 0 * 4));
v_C_109 = ICALL(s_lsp_LAST) (1, t22);
v_X_104 = v_L_93;
v_X_106 = ((LP) DEREF((v_X_104) + 0 * 4));
v_NEW_2DCDR_110 = (c_cons((v_X_106), (LREF(s_lsp_NIL))));
v_V_113 = v_NEW_2DCDR_110;
((LP) (DEREF((v_C_109) + 1 * 4) = (LD) (v_V_113)));
goto t_LOOP3363_94;
b_NIL_87:;
v_X_115 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DCONDITIONALS));
v_VALUE3366_117 = ((LP) DEREF((v_X_115) + 0 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DCONDITIONALS), LREF(s_lsp_NIL));
return(v_VALUE3366_117);
}
}
}
}

LP p_lsp_LOOP_2DPSEUDO_2DBODY(argc, v_FORM_0)
      ARGC argc;  LP v_FORM_0;
{
LP v_S3372_17; LP v_Y_15; LP v_X_14; 
LP v_VALUE3371_13; LP v_S3370_12; LP v_Y_10; 
LP v_X_9; LP v_VALUE3369_8; LP v_S3368_7; 
LP v_Y_5; LP v_X_4; LP v_VALUE3367_3; 
LP v_Z_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; 
if (argc != 1) wna(argc,1);
v_Z_1 = ICALL(s_lsp_LOOP_2DMAKE_2DCONDITIONALIZATION) (1, v_FORM_0);
t1 = ICALL(s_lsp_NULL) (1, v_Z_1);
if (t1 != NIL) {
return(LREF(s_lsp_NIL));
} else {
t2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DEMITTED_2DBODY_3F));
if (t2 != NIL) {
v_VALUE3367_3 = v_Z_1;
v_Y_5 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DBODY));
v_S3368_7 = (c_cons((v_Z_1), (v_Y_5)));
t0 = ICALL(s_lsp_SET) (MV_CALL(argc,2), LREF(s_lsp_LOOP_2DBODY), v_S3368_7);
return(t0);
} else {
v_VALUE3369_8 = v_Z_1;
v_Y_10 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DBEFORE_2DLOOP));
v_S3370_12 = (c_cons((v_Z_1), (v_Y_10)));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DBEFORE_2DLOOP), v_S3370_12);
v_VALUE3371_13 = v_Z_1;
v_Y_15 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DAFTER_2DBODY));
v_S3372_17 = (c_cons((v_Z_1), (v_Y_15)));
t0 = ICALL(s_lsp_SET) (MV_CALL(argc,2), LREF(s_lsp_LOOP_2DAFTER_2DBODY), v_S3372_17);
return(t0);
}
}
}

LP p_lsp_LOOP_2DEMIT_2DBODY(argc, v_FORM_0)
      ARGC argc;  LP v_FORM_0;
{

LP t0; LP t1; LP t2; LP t3; 
if (argc != 1) wna(argc,1);
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DEMITTED_2DBODY_3F), LREF(s_lsp_T));
t0 = ICALL(s_lsp_LOOP_2DPSEUDO_2DBODY) (MV_CALL(argc,1), v_FORM_0);
return(t0);
}

LP p_lsp_LOOP_2DDO_2DNAMED(argc)
      ARGC argc; 
{
LP v_X_14; LP v_Y_12; LP v_X_11; 
LP v_G3377_10; LP v_G3376_9; LP v_NAME_8; 
LP v_S3375_7; LP v_X_5; LP v_VALUE3374_4; 
LP v_X_2; LP v_LIST3373_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; 
if (argc != 0) wna(argc,0);
v_LIST3373_1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_2 = v_LIST3373_1;
v_VALUE3374_4 = ((LP) DEREF((v_LIST3373_1) + 0 * 4));
v_X_5 = v_LIST3373_1;
v_S3375_7 = ((LP) DEREF((v_LIST3373_1) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3375_7);
v_NAME_8 = v_VALUE3374_4;
if (v_NAME_8 != NIL) {
t0 = ICALL(s_lsp_SYMBOLP) (1, v_NAME_8);
} else {
t0 = LREF(s_lsp_NIL);
}
if (t0 == NIL) {
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2230), v_NAME_8);
}
v_G3376_9 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DBEFORE_2DLOOP));
if (v_G3376_9 != NIL) {
t1 = v_G3376_9;
} else {
v_G3377_10 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DBODY));
if (v_G3377_10 != NIL) {
t1 = v_G3377_10;
} else {
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DAFTER_2DEPILOGUE));
}
}
if (t1 != NIL) {
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2231), v_NAME_8);
}
v_Y_12 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DPROG_2DNAMES));
t3 = (c_cons((v_NAME_8), (v_Y_12)));
v_X_14 = ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DPROG_2DNAMES), t3);
t4 = ((LP) DEREF((v_X_14) + 1 * 4));
if (t4 != NIL) {
t5 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DPROG_2DNAMES));
t2 = ICALL(s_lsp_ERROR) (MV_CALL(argc,3), LREF(k2204), LREF(k2232), t5);
return(t2);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_LOOP_2DDO_2DINITIALLY(argc)
      ARGC argc; 
{
LP v_S3379_5; LP v_Y_3; LP v_X_2; 
LP v_VALUE3378_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; 
if (argc != 0) wna(argc,0);
v_VALUE3378_1 = ICALL(s_lsp_LOOP_2DGET_2DPROGN) (0);
v_Y_3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DPROLOGUE));
v_S3379_5 = (c_cons((v_VALUE3378_1), (v_Y_3)));
t0 = ICALL(s_lsp_SET) (MV_CALL(argc,2), LREF(s_lsp_LOOP_2DPROLOGUE), v_S3379_5);
return(t0);
}

LP p_lsp_LOOP_2DNODECLARE(argc)
      ARGC argc; 
{
LP v_G3384_10; LP v_G3383_9; LP v_VARLIST_7; 
LP v_S3382_6; LP v_X_4; LP v_VALUE3381_3; 
LP v_X_1; LP v_LIST3380_0; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; 
if (argc != 0) wna(argc,0);
v_LIST3380_0 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_1 = v_LIST3380_0;
v_VALUE3381_3 = ((LP) DEREF((v_LIST3380_0) + 0 * 4));
v_X_4 = v_LIST3380_0;
v_S3382_6 = ((LP) DEREF((v_LIST3380_0) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3382_6);
v_VARLIST_7 = v_VALUE3381_3;
v_G3383_9 = ICALL(s_lsp_NULL) (1, v_VARLIST_7);
if (v_G3383_9 != NIL) {
} else {
v_G3384_10 = ICALL(s_lsp_CONSP) (1, v_VARLIST_7);
if (v_G3384_10 != NIL) {
} else {
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2233), v_VARLIST_7);
}
}
t2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DNODECLARE));
t1 = ICALL(s_lsp_APPEND_2F2) (2, v_VARLIST_7, t2);
t0 = ICALL(s_lsp_SET) (MV_CALL(argc,2), LREF(s_lsp_LOOP_2DNODECLARE), t1);
return(t0);
}

LP p_lsp_LOOP_2DDO_2DFINALLY(argc)
      ARGC argc; 
{
LP v_S3386_5; LP v_Y_3; LP v_X_2; 
LP v_VALUE3385_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; 
if (argc != 0) wna(argc,0);
v_VALUE3385_1 = ICALL(s_lsp_LOOP_2DGET_2DPROGN) (0);
v_Y_3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DEPILOGUE));
v_S3386_5 = (c_cons((v_VALUE3385_1), (v_Y_3)));
t0 = ICALL(s_lsp_SET) (MV_CALL(argc,2), LREF(s_lsp_LOOP_2DEPILOGUE), v_S3386_5);
return(t0);
}

LP p_lsp_LOOP_2DDO_2DDO(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 0) wna(argc,0);
t1 = ICALL(s_lsp_LOOP_2DGET_2DPROGN) (0);
t0 = ICALL(s_lsp_LOOP_2DEMIT_2DBODY) (MV_CALL(argc,1), t1);
return(t0);
}

LP p_lsp_LOOP_2DDO_2DRETURN(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; 
if (argc != 0) wna(argc,0);
t2 = ICALL(s_lsp_LOOP_2DGET_2DFORM) (1, LREF(s_lsp_RETURN));
t1 = ICALL(s_lsp_LOOP_2DCONSTRUCT_2DRETURN) (1, t2);
t0 = ICALL(s_lsp_LOOP_2DPSEUDO_2DBODY) (MV_CALL(argc,1), t1);
return(t0);
}

LP p_lsp_LOOP_2DDO_2DCOLLECT(argc, v_TYPE_0)
      ARGC argc;  LP v_TYPE_0;
{
LP v_X_304; LP v_X_302; LP v_Y_300; 
LP v_X_299; LP v_Y_297; LP v_X_296; 
LP v_Y_294; LP v_X_293; LP v_Y_291; 
LP v_X_290; LP v_Y_288; LP v_X_287; 
LP v_Y_285; LP v_X_284; LP v_Y_282; 
LP v_X_281; LP v_Y_279; LP v_X_278; 
LP v_Y_276; LP v_X_275; LP v_Y_273; 
LP v_X_272; LP v_Y_270; LP v_X_269; 
LP v_X_267; LP v_X_265; LP v_C_263; 
LP v_Q_262; LP v_Y_260; LP v_X_259; 
LP v_Y_257; LP v_X_256; LP v_Y_254; 
LP v_X_253; LP v_Y_251; LP v_X_250; 
LP v_Y_248; LP v_X_247; LP v_Y_245; 
LP v_X_244; LP v_Y_242; LP v_X_241; 
LP v_Y_239; LP v_X_238; LP v_Y_236; 
LP v_X_235; LP v_Y_233; LP v_X_232; 
LP v_G3409_231; LP v_X_229; LP v_Y_227; 
LP v_X_226; LP v_Y_224; LP v_X_223; 
LP v_KEY3408_222; LP v_X_220; LP v_X_218; 
LP v_Y_216; LP v_X_215; LP v_S3407_214; 
LP v_Y_212; LP v_X_211; LP v_VALUE3406_210; 
LP v_Y_208; LP v_X_207; LP v_Y_205; 
LP v_X_204; LP v_Y_202; LP v_X_201; 
LP v_Y_199; LP v_X_198; LP v_Y_196; 
LP v_X_195; LP v_Y_193; LP v_X_192; 
LP v_Y_190; LP v_X_189; LP v_Y_187; 
LP v_X_186; LP v_Y_184; LP v_X_183; 
LP v_Y_181; LP v_X_180; LP v_Y_178; 
LP v_X_177; LP v_Y_175; LP v_X_174; 
LP v_Y_172; LP v_X_171; LP v_Y_169; 
LP v_X_168; LP v_Y_166; LP v_X_165; 
LP v_Y_163; LP v_X_162; LP v_Y_160; 
LP v_X_159; LP v_Y_157; LP v_X_156; 
LP v_Y_154; LP v_X_153; LP v_Y_151; 
LP v_X_150; LP v_Y_148; LP v_X_147; 
LP v_Y_145; LP v_X_144; LP v_Y_142; 
LP v_X_141; LP v_Y_139; LP v_X_138; 
LP v_Y_136; LP v_X_135; LP v_ARGLIST_134; 
LP v_FORMS_133; LP v_Y_131; LP v_X_130; 
LP v_Y_128; LP v_X_127; LP v_Y_125; 
LP v_X_124; LP v_Y_122; LP v_X_121; 
LP v_Y_119; LP v_X_118; LP v_Y_116; 
LP v_X_115; LP v_G3405_114; LP v_Y_112; 
LP v_X_111; LP v_Y_109; LP v_X_108; 
LP v_Y_106; LP v_X_105; LP v_Y_103; 
LP v_X_102; LP v_Y_100; LP v_X_99; 
LP v_Y_97; LP v_X_96; LP v_KEY3404_95; 
LP v_S3403_94; LP v_Y_92; LP v_X_91; 
LP v_VALUE3402_90; LP v_S3401_89; LP v_Y_87; 
LP v_X_86; LP v_VALUE3400_85; LP v_KEY3399_84; 
LP v_V_82; LP v_X_81; LP v_NEW_2DCAR_79; 
LP v_C_78; LP v_X_76; LP v_X_74; 
LP v_X_72; LP v_C_70; LP v_X_68; 
LP v_X_66; LP v_X_64; LP v_X_62; 
LP v_X_60; LP v_X_58; LP v_X_56; 
LP v_X_54; LP v_X_52; LP v_X_50; 
LP v_C_48; LP v_X_46; LP v_X_44; 
LP v_X_42; LP v_C_40; LP v_Y_38; 
LP v_X_37; LP v_Y_35; LP v_X_34; 
LP v_X_32; LP v_X_30; LP v_S3398_29; 
LP v_X_27; LP v_VALUE3397_26; LP v_X_24; 
LP v_LIST3396_23; LP v_S3395_22; LP v_X_20; 
LP v_VALUE3394_19; LP v_X_17; LP v_LIST3393_16; 
LP v_CTYPE_15; LP v_RVAR_14; LP v_CRUFT_13; 
LP v_DTYPE_12; LP v_TAIL_11; LP v_TEM_10; 
LP v_FORM_9; LP v_VAR_8; LP v_KEY3387_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; LP t145; LP t146; LP t147; LP t148; LP t149; 
LP t150; LP t151; LP t152; LP t153; LP t154; LP t155; 
LP t156; LP t157; LP t158; LP t159; LP t160; LP t161; 
LP t162; LP t163; LP t164; LP t165; LP t166; LP t167; 
LP t168; LP t169; LP t170; LP t171; LP t172; LP t173; 
LP t174; LP t175; LP t176; LP t177; LP t178; LP t179; 
LP t180; LP t181; LP t182; LP t183; LP t184; LP t185; 
LP t186; LP t187; LP t188; LP t189; LP t190; LP t191; 
LP t192; LP t193; LP t194; LP t195; LP t196; LP t197; 
LP t198; LP t199; LP t200; LP t201; LP t202; LP t203; 
LP t204; LP t205; LP t206; LP t207; LP t208; LP t209; 
LP t210; LP t211; LP t212; LP t213; LP t214; LP t215; 
LP t216; LP t217; LP t218; LP t219; LP t220; LP t221; 
LP t222; LP t223; LP t224; LP t225; LP t226; LP t227; 
LP t228; LP t229; LP t230; LP t231; LP t232; LP t233; 
LP t234; LP t235; LP t236; LP t237; LP t238; LP t239; 
LP t240; LP t241; LP t242; LP t243; LP t244; LP t245; 
LP t246; LP t247; LP t248; LP t249; LP t250; LP t251; 
LP t252; LP t253; LP t254; LP t255; LP t256; LP t257; 
LP t258; LP t259; LP t260; LP t261; LP t262; LP t263; 
LP t264; LP t265; LP t266; LP t267; LP t268; LP t269; 
LP t270; LP t271; LP t272; LP t273; LP t274; LP t275; 
LP t276; LP t277; LP t278; LP t279; LP t280; LP t281; 
LP t282; LP t283; LP t284; LP t285; LP t286; LP t287; 
LP t288; LP t289; LP t290; LP t291; LP t292; LP t293; 
LP t294; LP t295; LP t296; LP t297; LP t298; LP t299; 
LP t300; LP t301; LP t302; LP t303; LP t304; LP t305; 
LP t306; LP t307; LP t308; LP t309; LP t310; LP t311; 
LP t312; LP t313; LP t314; LP t315; LP t316; LP t317; 
LP t318; LP t319; LP t320; LP t321; LP t322; LP t323; 
LP t324; LP t325; LP t326; LP t327; LP t328; LP t329; 
LP t330; LP t331; LP t332; LP t333; LP t334; LP t335; 
LP t336; LP t337; LP t338; LP t339; LP t340; LP t341; 
LP t342; LP t343; LP t344; LP t345; LP t346; LP t347; 
LP t348; LP t349; LP t350; LP t351; LP t352; LP t353; 
LP t354; LP t355; LP t356; LP t357; LP t358; LP t359; 
LP t360; LP t361; LP t362; LP t363; LP t364; LP t365; 
LP t366; LP t367; LP t368; LP t369; LP t370; LP t371; 
LP t372; LP t373; LP t374; LP t375; LP t376; LP t377; 
LP t378; LP t379; LP t380; LP t381; LP t382; LP t383; 
LP t384; LP t385; LP t386; LP t387; LP t388; LP t389; 
LP t390; LP t391; LP t392; LP t393; LP t394; LP t395; 
LP t396; LP t397; LP t398; LP t399; LP t400; LP t401; 
LP t402; LP t403; LP t404; LP t405; LP t406; LP t407; 
LP t408; LP t409; LP t410; LP t411; LP t412; LP t413; 
LP t414; LP t415; LP t416; LP t417; LP t418; LP t419; 
LP t420; LP t421; LP t422; LP t423; LP t424; LP t425; 
LP t426; LP t427; LP t428; LP t429; LP t430; LP t431; 
LP t432; LP t433; LP t434; LP t435; LP t436; LP t437; 
LP t438; LP t439; LP t440; LP t441; LP t442; 
if (argc != 1) wna(argc,1);
v_VAR_8 = LREF(s_lsp_NIL);
v_FORM_9 = LREF(s_lsp_NIL);
v_TEM_10 = LREF(s_lsp_NIL);
v_TAIL_11 = LREF(s_lsp_NIL);
v_DTYPE_12 = LREF(s_lsp_NIL);
v_CRUFT_13 = LREF(s_lsp_NIL);
v_RVAR_14 = LREF(s_lsp_NIL);
v_KEY3387_3 = v_TYPE_0;
t0 = ICALL(s_lsp_SYMBOLP) (1, v_KEY3387_3);
if (t0 != NIL) {
t3 = ICALL(s_lsp_SYMBOL_2DHASH_2DCODE) (1, v_KEY3387_3);
t2 = ((LP) ((int) (t3) % (int) ((LP) 32)));
switch ((int) t2) {
case 12:
t4 = ICALL(s_lsp_EQ) (2, v_KEY3387_3, LREF(s_lsp_COUNT));
if (t4 != NIL) {
goto t_C3392_5;
} else {
goto t_DEFAULT_2DTAG3388_4;
}
break;
case 16:
t5 = ICALL(s_lsp_EQ) (2, v_KEY3387_3, LREF(s_lsp_SUM));
if (t5 != NIL) {
goto t_C3392_5;
} else {
goto t_DEFAULT_2DTAG3388_4;
}
break;
case 28:
t6 = ICALL(s_lsp_EQ) (2, v_KEY3387_3, LREF(s_lsp_NCONC));
if (t6 != NIL) {
goto t_C3391_6;
} else {
goto t_DEFAULT_2DTAG3388_4;
}
break;
case 8:
t7 = ICALL(s_lsp_EQ) (2, v_KEY3387_3, LREF(s_lsp_LIST));
if (t7 != NIL) {
goto t_C3391_6;
} else {
goto t_DEFAULT_2DTAG3388_4;
}
break;
case 4:
t8 = ICALL(s_lsp_EQ) (2, v_KEY3387_3, LREF(s_lsp_APPEND));
if (t8 != NIL) {
goto t_C3391_6;
} else {
goto t_DEFAULT_2DTAG3388_4;
}
break;
case 18:
t9 = ICALL(s_lsp_EQ) (2, v_KEY3387_3, LREF(s_lsp_MAX));
if (t9 != NIL) {
goto t_C3390_7;
} else {
goto t_DEFAULT_2DTAG3388_4;
}
break;
case 14:
t10 = ICALL(s_lsp_EQ) (2, v_KEY3387_3, LREF(s_lsp_MIN));
if (t10 != NIL) {
goto t_C3390_7;
} else {
goto t_DEFAULT_2DTAG3388_4;
}
break;
default:
goto t_DEFAULT_2DTAG3388_4;
break;
}
v_CTYPE_15 = t1;
goto b_CASE3389_2;
}
t_DEFAULT_2DTAG3388_4:;
t11 = ICALL(s_lsp_ERROR) (2, LREF(k2234), v_TYPE_0);
v_CTYPE_15 = t11;
goto b_CASE3389_2;
t_C3392_5:;
v_CTYPE_15 = LREF(s_lsp_SUM);
goto b_CASE3389_2;
t_C3391_6:;
v_CTYPE_15 = LREF(s_lsp_LIST);
goto b_CASE3389_2;
t_C3390_7:;
v_CTYPE_15 = LREF(s_lsp_MAXMIN);
goto b_CASE3389_2;
v_CTYPE_15 = NIL;
v_CTYPE_15 = v_CTYPE_15;
b_CASE3389_2:;
v_FORM_9 = ICALL(s_lsp_LOOP_2DGET_2DFORM) (1, v_TYPE_0);
v_DTYPE_12 = ICALL(s_lsp_LOOP_2DOPTIONAL_2DTYPE) (0);
v_X_30 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
t13 = ((LP) DEREF((v_X_30) + 0 * 4));
t12 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, t13, LREF(s_lsp_INTO));
if (t12 != NIL) {
v_LIST3393_16 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_17 = v_LIST3393_16;
v_VALUE3394_19 = ((LP) DEREF((v_LIST3393_16) + 0 * 4));
v_X_20 = v_LIST3393_16;
v_S3395_22 = ((LP) DEREF((v_LIST3393_16) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3395_22);
v_LIST3396_23 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_24 = v_LIST3396_23;
v_VALUE3397_26 = ((LP) DEREF((v_LIST3396_23) + 0 * 4));
v_X_27 = v_LIST3396_23;
v_S3398_29 = ((LP) DEREF((v_LIST3396_23) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3398_29);
v_VAR_8 = v_VALUE3397_26;
v_RVAR_14 = v_VAR_8;
}
t14 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DCOLLECT_2DCRUFT));
v_CRUFT_13 = ICALL(s_lsp_ASSQL) (2, v_VAR_8, t14);
if (v_CRUFT_13 != NIL) {
v_X_54 = v_CRUFT_13;
v_CRUFT_13 = ((LP) DEREF((v_X_54) + 1 * 4));
v_X_56 = v_CRUFT_13;
t16 = ((LP) DEREF((v_X_56) + 0 * 4));
t15 = ICALL(s_lsp_EQ) (2, v_CTYPE_15, t16);
if (t15 != NIL) {
if (v_DTYPE_12 != NIL) {
v_C_48 = v_CRUFT_13;
v_X_50 = v_C_48;
v_X_52 = ((LP) DEREF((v_C_48) + 1 * 4));
t19 = ((LP) DEREF((v_X_52) + 0 * 4));
t18 = ICALL(s_lsp_EQ) (2, v_DTYPE_12, t19);
t17 = ICALL(s_lsp_NOT) (1, t18);
} else {
t17 = LREF(s_lsp_NIL);
}
if (t17 != NIL) {
v_C_40 = v_CRUFT_13;
v_X_42 = v_C_40;
v_X_44 = ((LP) DEREF((v_C_40) + 1 * 4));
t20 = ((LP) DEREF((v_X_44) + 0 * 4));
v_X_46 = v_CRUFT_13;
t21 = ((LP) DEREF((v_X_46) + 0 * 4));
ICALL(s_lsp_ERROR) (4, LREF(k2235), v_DTYPE_12, t20, t21);
}
} else {
v_X_32 = v_CRUFT_13;
v_X_34 = ((LP) DEREF((v_X_32) + 0 * 4));
v_Y_38 = (c_cons((v_X_34), (LREF(s_lsp_NIL))));
t22 = (c_cons((v_CTYPE_15), (v_Y_38)));
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2236), t22);
}
v_X_58 = v_CRUFT_13;
v_CRUFT_13 = ((LP) DEREF((v_X_58) + 1 * 4));
v_X_60 = v_CRUFT_13;
v_DTYPE_12 = ((LP) DEREF((v_X_60) + 0 * 4));
v_X_62 = v_CRUFT_13;
v_CRUFT_13 = ((LP) DEREF((v_X_62) + 1 * 4));
v_X_64 = v_CRUFT_13;
v_VAR_8 = ((LP) DEREF((v_X_64) + 0 * 4));
v_X_66 = v_CRUFT_13;
v_CRUFT_13 = ((LP) DEREF((v_X_66) + 1 * 4));
v_X_68 = v_CRUFT_13;
v_TAIL_11 = ((LP) DEREF((v_X_68) + 0 * 4));
v_C_70 = v_CRUFT_13;
v_X_72 = v_C_70;
v_X_74 = ((LP) DEREF((v_C_70) + 1 * 4));
v_TEM_10 = ((LP) DEREF((v_X_74) + 0 * 4));
t23 = ICALL(s_lsp_EQ) (2, v_CTYPE_15, LREF(s_lsp_MAXMIN));
if (t23 != NIL) {
t24 = ICALL(s_lsp_ATOM) (1, v_FORM_9);
if (t24 == NIL) {
if (v_TEM_10 == NIL) {
v_X_76 = v_CRUFT_13;
v_C_78 = ((LP) DEREF((v_X_76) + 1 * 4));
t26 = ICALL(s_lsp_SYMBOL_2DNAME) (1, LREF(s_lsp_LOOP_2DMAXMIN_2D));
t25 = ICALL(s_lsp_GENTEMP) (1, t26);
v_TEM_10 = ICALL(s_lsp_LOOP_2DMAKE_2DVARIABLE) (3, t25, LREF(s_lsp_NIL), v_DTYPE_12);
v_NEW_2DCAR_79 = v_TEM_10;
v_V_82 = v_NEW_2DCAR_79;
((LP) (DEREF((v_C_78) + 0 * 4) = (LD) (v_V_82)));
}
}
}
} else {
if (v_DTYPE_12 == NIL) {
v_KEY3399_84 = v_TYPE_0;
t27 = ICALL(s_lsp_EQL) (2, v_KEY3399_84, LREF(s_lsp_COUNT));
if (t27 != NIL) {
v_DTYPE_12 = LREF(s_lsp_FIXNUM);
} else {
t28 = ICALL(s_lsp_MEMQL) (2, v_KEY3399_84, LREF(k2237));
if (t28 != NIL) {
v_DTYPE_12 = LREF(s_lsp_NUMBER);
} else {
v_DTYPE_12 = LREF(s_lsp_NIL);
}
}
}
if (v_VAR_8 == NIL) {
t29 = ICALL(s_lsp_SYMBOL_2DNAME) (1, LREF(s_lsp_LOOPVAR_2D));
v_VAR_8 = ICALL(s_lsp_GENTEMP) (1, t29);
v_VALUE3400_85 = ICALL(s_lsp_LOOP_2DCONSTRUCT_2DRETURN) (1, v_VAR_8);
v_Y_87 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DAFTER_2DEPILOGUE));
v_S3401_89 = (c_cons((v_VALUE3400_85), (v_Y_87)));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DAFTER_2DEPILOGUE), v_S3401_89);
}
ICALL(s_lsp_LOOP_2DMAKE_2DITERATION_2DVARIABLE) (3, v_VAR_8, LREF(s_lsp_NIL), v_DTYPE_12);
t30 = ICALL(s_lsp_EQ) (2, v_CTYPE_15, LREF(s_lsp_MAXMIN));
if (t30 != NIL) {
t31 = ICALL(s_lsp_ATOM) (1, v_FORM_9);
if (t31 == NIL) {
t33 = ICALL(s_lsp_SYMBOL_2DNAME) (1, LREF(s_lsp_LOOPVAR_2D));
t32 = ICALL(s_lsp_GENTEMP) (1, t33);
v_TEM_10 = ICALL(s_lsp_LOOP_2DMAKE_2DVARIABLE) (3, t32, LREF(s_lsp_NIL), v_DTYPE_12);
}
t35 = ICALL(s_lsp_SYMBOL_2DNAME) (1, LREF(s_lsp_LOOP_2DMAXMIN_2DFL_2D));
t34 = ICALL(s_lsp_GENTEMP) (1, t35);
v_TAIL_11 = ICALL(s_lsp_LOOP_2DMAKE_2DVARIABLE) (3, t34, LREF(s_lsp_T), LREF(s_lsp_NIL));
} else {
t36 = ICALL(s_lsp_EQ) (2, v_CTYPE_15, LREF(s_lsp_LIST));
if (t36 != NIL) {
t38 = ICALL(s_lsp_SYMBOL_2DNAME) (1, LREF(s_lsp_LOOPVAR_2D));
t37 = ICALL(s_lsp_GENTEMP) (1, t38);
v_TAIL_11 = ICALL(s_lsp_LOOP_2DMAKE_2DVARIABLE) (3, t37, LREF(s_lsp_NIL), LREF(s_lsp_NIL));
t40 = ICALL(s_lsp_SYMBOL_2DNAME) (1, LREF(s_lsp_LOOPVAR_2D));
t39 = ICALL(s_lsp_GENTEMP) (1, t40);
v_TEM_10 = ICALL(s_lsp_LOOP_2DMAKE_2DVARIABLE) (3, t39, LREF(s_lsp_NIL), LREF(s_lsp_NIL));
}
}
v_VALUE3402_90 = ICALL(s_lsp_LIST) (6, v_RVAR_14, v_CTYPE_15, v_DTYPE_12, v_VAR_8, v_TAIL_11, v_TEM_10);
v_Y_92 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DCOLLECT_2DCRUFT));
v_S3403_94 = (c_cons((v_VALUE3402_90), (v_Y_92)));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DCOLLECT_2DCRUFT), v_S3403_94);
}
v_KEY3404_95 = v_TYPE_0;
t43 = ICALL(s_lsp_EQL) (2, v_KEY3404_95, LREF(s_lsp_COUNT));
if (t43 != NIL) {
v_X_99 = v_VAR_8;
v_X_96 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp__2B), v_VAR_8, LREF(k2240));
v_Y_100 = (c_cons((v_X_96), (LREF(s_lsp_NIL))));
v_Y_103 = (c_cons((v_X_99), (v_Y_100)));
v_TEM_10 = (c_cons((LREF(s_lsp_SETQ)), (v_Y_103)));
v_G3405_114 = ICALL(s_lsp_EQ) (2, v_FORM_9, LREF(s_lsp_T));
if (v_G3405_114 != NIL) {
t44 = v_G3405_114;
} else {
t44 = ICALL(s_lsp_EQUAL) (2, v_FORM_9, LREF(k2241));
}
if (t44 != NIL) {
t42 = v_TEM_10;
} else {
v_X_108 = v_FORM_9;
v_X_105 = v_TEM_10;
v_Y_109 = (c_cons((v_X_105), (LREF(s_lsp_NIL))));
v_Y_112 = (c_cons((v_X_108), (v_Y_109)));
t42 = (c_cons((LREF(s_lsp_WHEN)), (v_Y_112)));
}
} else {
t45 = ICALL(s_lsp_EQL) (2, v_KEY3404_95, LREF(s_lsp_SUM));
if (t45 != NIL) {
v_X_127 = v_VAR_8;
v_X_121 = ICALL(s_lsp_LOOP_2DTYPED_2DARITH) (2, LREF(s_lsp__2B), v_DTYPE_12);
v_X_118 = v_FORM_9;
v_X_115 = v_VAR_8;
v_Y_119 = (c_cons((v_X_115), (LREF(s_lsp_NIL))));
v_Y_122 = (c_cons((v_X_118), (v_Y_119)));
v_X_124 = (c_cons((v_X_121), (v_Y_122)));
v_Y_128 = (c_cons((v_X_124), (LREF(s_lsp_NIL))));
v_Y_131 = (c_cons((v_X_127), (v_Y_128)));
t42 = (c_cons((LREF(s_lsp_SETQ)), (v_Y_131)));
} else {
t46 = ICALL(s_lsp_MEMQL) (2, v_KEY3404_95, LREF(k2243));
if (t46 != NIL) {
v_FORMS_133 = LREF(s_lsp_NIL);
v_ARGLIST_134 = LREF(s_lsp_NIL);
if (v_TEM_10 != NIL) {
v_X_138 = v_TEM_10;
v_X_135 = v_FORM_9;
v_Y_139 = (c_cons((v_X_135), (LREF(s_lsp_NIL))));
v_Y_142 = (c_cons((v_X_138), (v_Y_139)));
v_X_144 = (c_cons((LREF(s_lsp_SETQ)), (v_Y_142)));
v_FORMS_133 = (c_cons((v_X_144), (LREF(s_lsp_NIL))));
v_FORM_9 = v_TEM_10;
}
v_X_150 = v_VAR_8;
v_X_147 = v_FORM_9;
v_Y_151 = (c_cons((v_X_147), (LREF(s_lsp_NIL))));
v_ARGLIST_134 = (c_cons((v_X_150), (v_Y_151)));
t47 = ICALL(s_lsp_LOOP_2DTMEMBER) (2, v_DTYPE_12, LREF(k2245));
if (t47 != NIL) {
v_X_159 = v_TAIL_11;
t49 = ICALL(s_lsp_EQ) (2, v_TYPE_0, LREF(s_lsp_MAX));
if (t49 != NIL) {
t48 = LREF(s_lsp__3C);
} else {
t48 = LREF(s_lsp__3E);
}
v_X_153 = ICALL(s_lsp_LOOP_2DTYPED_2DARITH) (2, t48, v_DTYPE_12);
v_Y_154 = v_ARGLIST_134;
v_X_156 = (c_cons((v_X_153), (v_Y_154)));
v_Y_160 = (c_cons((v_X_156), (LREF(s_lsp_NIL))));
v_Y_163 = (c_cons((v_X_159), (v_Y_160)));
v_X_168 = (c_cons((LREF(s_lsp_OR)), (v_Y_163)));
v_X_165 = ICALL(s_lsp_LIST_2A) (4, LREF(s_lsp_SETQ), v_TAIL_11, LREF(s_lsp_NIL), v_ARGLIST_134);
v_Y_169 = (c_cons((v_X_165), (LREF(s_lsp_NIL))));
v_Y_172 = (c_cons((v_X_168), (v_Y_169)));
v_VALUE3406_210 = (c_cons((LREF(s_lsp_WHEN)), (v_Y_172)));
} else {
v_X_204 = v_VAR_8;
v_X_180 = v_TAIL_11;
v_X_177 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_SETQ), v_TAIL_11, LREF(k2202));
v_X_174 = v_FORM_9;
v_Y_178 = (c_cons((v_X_174), (LREF(s_lsp_NIL))));
v_Y_181 = (c_cons((v_X_177), (v_Y_178)));
v_X_195 = (c_cons((v_X_180), (v_Y_181)));
v_Y_184 = v_ARGLIST_134;
v_X_186 = (c_cons((v_TYPE_0), (v_Y_184)));
v_Y_190 = (c_cons((v_X_186), (LREF(s_lsp_NIL))));
v_X_192 = (c_cons((LREF(s_lsp_T)), (v_Y_190)));
v_Y_196 = (c_cons((v_X_192), (LREF(s_lsp_NIL))));
v_Y_199 = (c_cons((v_X_195), (v_Y_196)));
v_X_201 = (c_cons((LREF(s_lsp_COND)), (v_Y_199)));
v_Y_205 = (c_cons((v_X_201), (LREF(s_lsp_NIL))));
v_Y_208 = (c_cons((v_X_204), (v_Y_205)));
v_VALUE3406_210 = (c_cons((LREF(s_lsp_SETQ)), (v_Y_208)));
}
v_Y_212 = v_FORMS_133;
v_S3407_214 = (c_cons((v_VALUE3406_210), (v_Y_212)));
v_FORMS_133 = v_S3407_214;
v_X_220 = v_FORMS_133;
t50 = ((LP) DEREF((v_X_220) + 1 * 4));
if (t50 != NIL) {
v_Y_216 = ICALL(s_lsp_NREVERSE) (1, v_FORMS_133);
t42 = (c_cons((LREF(s_lsp_PROGN)), (v_Y_216)));
} else {
v_X_218 = v_FORMS_133;
t42 = ((LP) DEREF((v_X_218) + 0 * 4));
}
} else {
v_KEY3408_222 = v_TYPE_0;
t51 = ICALL(s_lsp_EQL) (2, v_KEY3408_222, LREF(s_lsp_LIST));
if (t51 != NIL) {
v_X_223 = v_FORM_9;
v_Y_227 = (c_cons((v_X_223), (LREF(s_lsp_NIL))));
v_FORM_9 = (c_cons((LREF(s_lsp_LIST)), (v_Y_227)));
} else {
t52 = ICALL(s_lsp_EQL) (2, v_KEY3408_222, LREF(s_lsp_APPEND));
if (t52 != NIL) {
t53 = ICALL(s_lsp_ATOM) (1, v_FORM_9);
if (t53 != NIL) {
v_G3409_231 = LREF(s_lsp_NIL);
} else {
v_X_229 = v_FORM_9;
t54 = ((LP) DEREF((v_X_229) + 0 * 4));
v_G3409_231 = ICALL(s_lsp_EQ) (2, t54, LREF(s_lsp_LIST));
}
if (v_G3409_231 != NIL) {
} else {
v_X_232 = v_FORM_9;
v_Y_236 = (c_cons((v_X_232), (LREF(s_lsp_NIL))));
v_FORM_9 = (c_cons((LREF(s_lsp_COPY_2DLIST)), (v_Y_236)));
}
} else {
}
}
v_X_241 = v_TAIL_11;
v_X_238 = v_TEM_10;
v_Y_242 = (c_cons((v_X_238), (LREF(s_lsp_NIL))));
v_Y_245 = (c_cons((v_X_241), (v_Y_242)));
v_X_247 = (c_cons((LREF(s_lsp_RPLACD)), (v_Y_245)));
v_Y_251 = (c_cons((v_X_247), (LREF(s_lsp_NIL))));
t55 = (c_cons((LREF(s_lsp_CDR)), (v_Y_251)));
v_X_256 = v_VAR_8;
v_X_253 = v_TEM_10;
v_Y_257 = (c_cons((v_X_253), (LREF(s_lsp_NIL))));
v_Y_260 = (c_cons((v_X_256), (v_Y_257)));
t56 = (c_cons((LREF(s_lsp_SETQ)), (v_Y_260)));
v_Q_262 = ICALL(s_lsp_LIST) (4, LREF(s_lsp_IF), v_TAIL_11, t55, t56);
t58 = ICALL(s_lsp_ATOM) (1, v_FORM_9);
if (t58 != NIL) {
t57 = LREF(s_lsp_NIL);
} else {
v_X_304 = v_FORM_9;
t60 = ((LP) DEREF((v_X_304) + 0 * 4));
t59 = ICALL(s_lsp_EQ) (2, t60, LREF(s_lsp_LIST));
if (t59 != NIL) {
v_X_302 = v_FORM_9;
t57 = ((LP) DEREF((v_X_302) + 1 * 4));
} else {
t57 = LREF(s_lsp_NIL);
}
}
if (t57 != NIL) {
v_C_263 = v_FORM_9;
v_X_265 = v_C_263;
v_X_267 = ((LP) DEREF((v_C_263) + 1 * 4));
t62 = ((LP) DEREF((v_X_267) + 1 * 4));
t61 = ICALL(s_lsp_LOOP_2DCDRIFY) (2, t62, v_Q_262);
t42 = ICALL(s_lsp_LIST) (5, LREF(s_lsp_SETQ), v_TEM_10, v_FORM_9, v_TAIL_11, t61);
} else {
v_X_272 = v_TEM_10;
v_X_269 = v_FORM_9;
v_Y_273 = (c_cons((v_X_269), (LREF(s_lsp_NIL))));
v_Y_276 = (c_cons((v_X_272), (v_Y_273)));
v_X_296 = (c_cons((LREF(s_lsp_SETQ)), (v_Y_276)));
v_X_287 = v_TAIL_11;
v_X_278 = v_Q_262;
v_Y_279 = LREF(s_lsp_NIL);
v_Y_282 = (c_cons((v_Q_262), (LREF(s_lsp_NIL))));
v_X_284 = (c_cons((LREF(s_lsp_LAST)), (v_Y_282)));
v_Y_288 = (c_cons((v_X_284), (LREF(s_lsp_NIL))));
v_Y_291 = (c_cons((v_X_287), (v_Y_288)));
v_X_293 = (c_cons((LREF(s_lsp_SETQ)), (v_Y_291)));
v_Y_297 = (c_cons((v_X_293), (LREF(s_lsp_NIL))));
v_Y_300 = (c_cons((v_X_296), (v_Y_297)));
t42 = (c_cons((LREF(s_lsp_WHEN)), (v_Y_300)));
}
}
}
}
t41 = ICALL(s_lsp_LOOP_2DEMIT_2DBODY) (MV_CALL(argc,1), t42);
return(t41);
}

LP p_lsp_LOOP_2DCDRIFY(argc, v_ARGLIST_0, v_FORM_1)
      ARGC argc;  LP v_ARGLIST_0; LP v_FORM_1;
{
LP v_Y_18; LP v_X_17; LP v_Y_15; 
LP v_X_14; LP v_Y_12; LP v_X_11; 
LP v_Y_9; LP v_X_8; LP v_TMP3412_7; 
LP v_SIZE_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; 
if (argc != 2) wna(argc,2);
v_SIZE_4 = ICALL(s_lsp_LENGTH) (1, v_ARGLIST_0);
goto t_TEST3410_6;
t_LOOP3411_5:;
v_TMP3412_7 = (subtract((v_SIZE_4), ((LP) 8)));
v_SIZE_4 = v_TMP3412_7;
t_TEST3410_6:;
if (((int) (v_SIZE_4) < (int) ((LP) 8))) {
t3 = ICALL(s_lsp_ZEROP) (1, v_SIZE_4);
if (t3 != NIL) {
return(v_FORM_1);
} else {
if (((int) (v_SIZE_4) == (int) ((LP) 2))) {
v_X_11 = LREF(s_lsp_CDR);
} else {
if (((int) (v_SIZE_4) == (int) ((LP) 4))) {
v_X_11 = LREF(s_lsp_CDDR);
} else {
v_X_11 = LREF(s_lsp_CDDDR);
}
}
v_X_8 = v_FORM_1;
v_Y_12 = (c_cons((v_X_8), (LREF(s_lsp_NIL))));
t2 = (c_cons((v_X_11), (v_Y_12)));
return(t2);
}
return(t2);
}
v_X_14 = v_FORM_1;
v_Y_18 = (c_cons((v_X_14), (LREF(s_lsp_NIL))));
v_FORM_1 = (c_cons((LREF(s_lsp_CDDDDR)), (v_Y_18)));
goto t_LOOP3411_5;
return(NIL);
}

LP p_lsp_LOOP_2DDO_2DWHILE(argc, v_NEGATE_3F_0, v_KWD_1)
      ARGC argc;  LP v_NEGATE_3F_0; LP v_KWD_1;
{
LP v_Y_8; LP v_X_7; LP v_Y_5; 
LP v_X_4; LP v_FORM_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; 
if (argc != 2) wna(argc,2);
v_FORM_2 = ICALL(s_lsp_LOOP_2DGET_2DFORM) (1, v_KWD_1);
t0 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DCONDITIONALS));
if (t0 != NIL) {
v_X_4 = v_FORM_2;
v_Y_5 = LREF(s_lsp_NIL);
v_Y_8 = (c_cons((v_FORM_2), (LREF(s_lsp_NIL))));
t1 = (c_cons((v_KWD_1), (v_Y_8)));
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2247), t1);
}
if (v_NEGATE_3F_0 != NIL) {
t4 = LREF(s_lsp_WHEN);
} else {
t4 = LREF(s_lsp_UNLESS);
}
t3 = ICALL(s_lsp_LIST_2A) (3, t4, v_FORM_2, LREF(k2199));
t2 = ICALL(s_lsp_LOOP_2DPSEUDO_2DBODY) (MV_CALL(argc,1), t3);
return(t2);
}

LP p_lsp_LOOP_2DDO_2DWHEN(argc, v_NEGATE_3F_0, v_KWD_1)
      ARGC argc;  LP v_NEGATE_3F_0; LP v_KWD_1;
{
LP v_Y_44; LP v_X_43; LP v_Y_41; 
LP v_X_40; LP v_Y_38; LP v_X_37; 
LP v_Y_35; LP v_X_34; LP v_Y_32; 
LP v_X_31; LP v_Y_29; LP v_X_28; 
LP v_X_26; LP v_X_24; LP v_C_22; 
LP v_X_20; LP v_X_18; LP v_C_16; 
LP v_X_14; LP v_Y_12; LP v_X_11; 
LP v_Y_9; LP v_X_8; LP v_Y_6; 
LP v_X_5; LP v_COND_4; LP v_FORM_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; 
if (argc != 2) wna(argc,2);
v_FORM_3 = ICALL(s_lsp_LOOP_2DGET_2DFORM) (1, v_KWD_1);
v_COND_4 = LREF(s_lsp_NIL);
v_C_22 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_24 = v_C_22;
v_X_26 = ((LP) DEREF((v_C_22) + 1 * 4));
t1 = ((LP) DEREF((v_X_26) + 0 * 4));
t0 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, t1, LREF(s_lsp_IT));
if (t0 != NIL) {
v_X_8 = ICALL(s_lsp_LOOP_2DWHEN_2DIT_2DVARIABLE) (0);
v_X_5 = v_FORM_3;
v_Y_6 = LREF(s_lsp_NIL);
v_Y_9 = (c_cons((v_FORM_3), (LREF(s_lsp_NIL))));
v_Y_12 = (c_cons((v_X_8), (v_Y_9)));
v_COND_4 = (c_cons((LREF(s_lsp_SETQ)), (v_Y_12)));
v_X_14 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
t3 = ((LP) DEREF((v_X_14) + 0 * 4));
t4 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DWHEN_2DIT_2DVARIABLE));
v_C_16 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_18 = v_C_16;
v_X_20 = ((LP) DEREF((v_C_16) + 1 * 4));
t5 = ((LP) DEREF((v_X_20) + 1 * 4));
t2 = ICALL(s_lsp_LIST_2A) (3, t3, t4, t5);
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), t2);
} else {
v_COND_4 = v_FORM_3;
}
if (v_NEGATE_3F_0 != NIL) {
v_X_28 = v_COND_4;
v_Y_32 = (c_cons((v_X_28), (LREF(s_lsp_NIL))));
v_COND_4 = (c_cons((LREF(s_lsp_NOT)), (v_Y_32)));
}
t8 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DCONDITIONALS));
v_X_34 = v_COND_4;
v_X_37 = (c_cons((v_X_34), (LREF(s_lsp_NIL))));
v_Y_41 = (c_cons((v_X_37), (LREF(s_lsp_NIL))));
v_X_43 = (c_cons((LREF(s_lsp_COND)), (v_Y_41)));
t9 = (c_cons((v_X_43), (LREF(s_lsp_NIL))));
t7 = ICALL(s_lsp_NCONC_2F2) (2, t8, t9);
t6 = ICALL(s_lsp_SET) (MV_CALL(argc,2), LREF(s_lsp_LOOP_2DCONDITIONALS), t7);
return(t6);
}

LP p_lsp_LOOP_2DDO_2DWITH(argc)
      ARGC argc; 
{
LP v_X_51; LP v_S3428_50; LP v_X_48; 
LP v_VALUE3427_47; LP v_X_45; LP v_LIST3426_44; 
LP v_G3425_43; LP v_G3424_42; LP v_S3423_41; 
LP v_X_39; LP v_VALUE3422_38; LP v_X_36; 
LP v_LIST3421_35; LP v_X_33; LP v_Y_31; 
LP v_X_30; LP v_Y_28; LP v_X_27; 
LP v_Y_25; LP v_X_24; LP v_S3420_23; 
LP v_X_21; LP v_VALUE3419_20; LP v_X_18; 
LP v_LIST3418_17; LP v_X_15; LP v_S3417_14; 
LP v_X_12; LP v_VALUE3416_11; LP v_X_9; 
LP v_LIST3415_8; LP v_DTYPE_5; LP v_VAL_4; 
LP v_EQUALS_3; LP v_VAR_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; 
if (argc != 0) wna(argc,0);
v_VAR_2 = LREF(s_lsp_NIL);
v_EQUALS_3 = LREF(s_lsp_NIL);
v_VAL_4 = LREF(s_lsp_NIL);
v_DTYPE_5 = LREF(s_lsp_NIL);
goto t_TEST3413_7;
t_LOOP3414_6:;
t_TEST3413_7:;
v_LIST3415_8 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_9 = v_LIST3415_8;
v_VALUE3416_11 = ((LP) DEREF((v_LIST3415_8) + 0 * 4));
v_X_12 = v_LIST3415_8;
v_S3417_14 = ((LP) DEREF((v_LIST3415_8) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3417_14);
v_VAR_2 = v_VALUE3416_11;
v_X_15 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_EQUALS_3 = ((LP) DEREF((v_X_15) + 0 * 4));
t0 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, v_EQUALS_3, LREF(s_lsp__3D));
if (t0 != NIL) {
v_LIST3418_17 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_18 = v_LIST3418_17;
v_VALUE3419_20 = ((LP) DEREF((v_LIST3418_17) + 0 * 4));
v_X_21 = v_LIST3418_17;
v_S3420_23 = ((LP) DEREF((v_LIST3418_17) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3420_23);
v_X_27 = v_VAR_2;
v_X_24 = LREF(s_lsp__3D);
v_Y_25 = LREF(s_lsp_NIL);
v_Y_28 = (c_cons((LREF(s_lsp__3D)), (LREF(s_lsp_NIL))));
v_Y_31 = (c_cons((v_X_27), (v_Y_28)));
t1 = (c_cons((LREF(s_lsp_WITH)), (v_Y_31)));
v_VAL_4 = ICALL(s_lsp_LOOP_2DGET_2DFORM) (1, t1);
v_DTYPE_5 = LREF(s_lsp_NIL);
} else {
v_G3424_42 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, v_EQUALS_3, LREF(s_lsp_AND));
if (v_G3424_42 != NIL) {
t2 = v_G3424_42;
} else {
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DKEYWORD_2DALIST));
v_G3425_43 = ICALL(s_lsp_LOOP_2DTASSOC) (2, v_EQUALS_3, t3);
if (v_G3425_43 != NIL) {
t2 = v_G3425_43;
} else {
t4 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DITERATION_2DKEYWORD_2DALIST));
t2 = ICALL(s_lsp_LOOP_2DTASSOC) (2, v_EQUALS_3, t4);
}
}
if (t2 != NIL) {
v_VAL_4 = LREF(s_lsp_NIL);
v_DTYPE_5 = LREF(s_lsp_NIL);
} else {
v_DTYPE_5 = ICALL(s_lsp_LOOP_2DOPTIONAL_2DTYPE) (0);
v_X_33 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_EQUALS_3 = ((LP) DEREF((v_X_33) + 0 * 4));
t5 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, v_EQUALS_3, LREF(s_lsp__3D));
if (t5 != NIL) {
v_LIST3421_35 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_36 = v_LIST3421_35;
v_VALUE3422_38 = ((LP) DEREF((v_LIST3421_35) + 0 * 4));
v_X_39 = v_LIST3421_35;
v_S3423_41 = ((LP) DEREF((v_LIST3421_35) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3423_41);
t6 = ICALL(s_lsp_LIST) (4, LREF(s_lsp_WITH), v_VAR_2, v_DTYPE_5, LREF(s_lsp__3D));
v_VAL_4 = ICALL(s_lsp_LOOP_2DGET_2DFORM) (1, t6);
} else {
t9 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
t8 = ICALL(s_lsp_NULL) (1, t9);
if (t8 != NIL) {
t7 = LREF(s_lsp_NIL);
} else {
t11 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DKEYWORD_2DALIST));
t10 = ICALL(s_lsp_LOOP_2DTASSOC) (2, v_EQUALS_3, t11);
if (t10 != NIL) {
t7 = LREF(s_lsp_NIL);
} else {
t13 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DITERATION_2DKEYWORD_2DALIST));
t12 = ICALL(s_lsp_LOOP_2DTASSOC) (2, v_EQUALS_3, t13);
if (t12 != NIL) {
t7 = LREF(s_lsp_NIL);
} else {
t14 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, v_EQUALS_3, LREF(s_lsp_AND));
t7 = ICALL(s_lsp_NOT) (1, t14);
}
}
}
if (t7 != NIL) {
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2248), v_EQUALS_3);
} else {
v_VAL_4 = LREF(s_lsp_NIL);
}
}
}
}
ICALL(s_lsp_LOOP_2DMAKE_2DVARIABLE) (3, v_VAR_2, v_VAL_4, v_DTYPE_5);
v_X_51 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
t16 = ((LP) DEREF((v_X_51) + 0 * 4));
t15 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, t16, LREF(s_lsp_AND));
if (t15 != NIL) {
v_LIST3426_44 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_45 = v_LIST3426_44;
v_VALUE3427_47 = ((LP) DEREF((v_LIST3426_44) + 0 * 4));
v_X_48 = v_LIST3426_44;
v_S3428_50 = ((LP) DEREF((v_LIST3426_44) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3428_50);
} else {
goto b_NIL_1;
}
goto t_LOOP3414_6;
b_NIL_1:;
t17 = ICALL(s_lsp_LOOP_2DBIND_2DBLOCK) (MV_CALL(argc,0));
return(t17);
}

LP p_lsp_LOOP_2DDO_2DALWAYS(argc, v_NEGATE_3F_0)
      ARGC argc;  LP v_NEGATE_3F_0;
{
LP v_S3430_16; LP v_Y_14; LP v_X_13; 
LP v_VALUE3429_12; LP v_Y_10; LP v_X_9; 
LP v_Y_7; LP v_X_6; LP v_Y_4; 
LP v_X_3; LP v_FORM_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 

if (argc != 1) wna(argc,1);
v_FORM_2 = ICALL(s_lsp_LOOP_2DGET_2DFORM) (1, LREF(s_lsp_ALWAYS));
if (v_NEGATE_3F_0 != NIL) {
v_X_9 = LREF(s_lsp_WHEN);
} else {
v_X_9 = LREF(s_lsp_UNLESS);
}
v_X_3 = ICALL(s_lsp_LOOP_2DCONSTRUCT_2DRETURN) (1, LREF(s_lsp_NIL));
v_Y_7 = (c_cons((v_X_3), (LREF(s_lsp_NIL))));
v_Y_10 = (c_cons((v_FORM_2), (v_Y_7)));
t0 = (c_cons((v_X_9), (v_Y_10)));
ICALL(s_lsp_LOOP_2DEMIT_2DBODY) (1, t0);
v_VALUE3429_12 = ICALL(s_lsp_LOOP_2DCONSTRUCT_2DRETURN) (1, LREF(s_lsp_T));
v_Y_14 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DAFTER_2DEPILOGUE));
v_S3430_16 = (c_cons((v_VALUE3429_12), (v_Y_14)));
t1 = ICALL(s_lsp_SET) (MV_CALL(argc,2), LREF(s_lsp_LOOP_2DAFTER_2DEPILOGUE), v_S3430_16);
return(t1);
}

LP p_lsp_LOOP_2DDO_2DTHEREIS(argc)
      ARGC argc; 
{
LP v_Y_17; LP v_X_16; LP v_Y_14; 
LP v_X_13; LP v_Y_11; LP v_X_10; 
LP v_Y_8; LP v_X_7; LP v_Y_5; 
LP v_X_4; LP v_Y_2; LP v_X_1; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; 
if (argc != 0) wna(argc,0);
v_X_4 = ICALL(s_lsp_LOOP_2DWHEN_2DIT_2DVARIABLE) (0);
v_X_1 = ICALL(s_lsp_LOOP_2DGET_2DFORM) (1, LREF(s_lsp_THEREIS));
v_Y_5 = (c_cons((v_X_1), (LREF(s_lsp_NIL))));
v_Y_8 = (c_cons((v_X_4), (v_Y_5)));
v_X_13 = (c_cons((LREF(s_lsp_SETQ)), (v_Y_8)));
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DWHEN_2DIT_2DVARIABLE));
v_X_10 = ICALL(s_lsp_LOOP_2DCONSTRUCT_2DRETURN) (1, t1);
v_Y_14 = (c_cons((v_X_10), (LREF(s_lsp_NIL))));
v_Y_17 = (c_cons((v_X_13), (v_Y_14)));
t2 = (c_cons((LREF(s_lsp_WHEN)), (v_Y_17)));
t0 = ICALL(s_lsp_LOOP_2DEMIT_2DBODY) (MV_CALL(argc,1), t2);
return(t0);
}

LP p_lsp_LOOP_2DSIMPLEP(argc, v_EXPR_0)
      ARGC argc;  LP v_EXPR_0;
{
LP v_ANS_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 1) wna(argc,1);
if (v_EXPR_0 != NIL) {
BEGIN_CATCH(LREF(s_lsp_LOOP_2DSIMPLEP),argc);
v_ANS_2 = ICALL(s_lsp_LOOP_2DSIMPLEP_2D1) (1, v_EXPR_0);
if (((int) (v_ANS_2) < (int) ((LP) 40))) {
t0 = v_ANS_2;
} else {
t0 = LREF(s_lsp_NIL);
}
END_CATCH(t0);
return(t0);
} else {
return((LP) 0);
}
}

LP p_lsp_LOOP_2DSIMPLEP_2D1(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{
LP v_X_43; LP v_X_41; LP v_X_39; 
LP v_TMP3440_38; LP v_X_36; LP v_L_33; 
LP v_X_31; LP v_EXPANDED_2DP_29; LP v_NEW_2DFORM_28; 
LP v_TEST3437_27; LP v_TEM_26; LP v_FN_25; 
LP v_X_23; LP v_X_21; LP v_TMP3436_20; 
LP v_X_18; LP v_F_15; LP v_X_13; 
LP v_TMP3433_11; LP v_X_9; LP v_CL_6; 
LP v_X_4; LP v_Z_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; 
if (argc != 1) wna(argc,1);
v_Z_2 = (LP) 0;
t1 = ICALL(s_lsp_LOOP_2DCONSTANTP) (1, v_X_0);
if (t1 != NIL) {
return((LP) 0);
} else {
t2 = ICALL(s_lsp_ATOM) (1, v_X_0);
if (t2 != NIL) {
return((LP) 2);
} else {
v_X_43 = v_X_0;
t4 = ((LP) DEREF((v_X_43) + 0 * 4));
t3 = ICALL(s_lsp_EQ) (2, t4, LREF(s_lsp_COND));
if (t3 != NIL) {
v_X_4 = v_X_0;
v_CL_6 = ((LP) DEREF((v_X_4) + 1 * 4));
goto t_TEST3431_8;
t_LOOP3432_7:;
v_X_9 = v_CL_6;
v_TMP3433_11 = ((LP) DEREF((v_X_9) + 1 * 4));
v_CL_6 = v_TMP3433_11;
t_TEST3431_8:;
if (v_CL_6 == NIL) {
goto b_NIL_3;
}
v_X_13 = v_CL_6;
v_F_15 = ((LP) DEREF((v_X_13) + 0 * 4));
goto t_TEST3434_17;
t_LOOP3435_16:;
v_X_18 = v_F_15;
v_TMP3436_20 = ((LP) DEREF((v_X_18) + 1 * 4));
v_F_15 = v_TMP3436_20;
t_TEST3434_17:;
if (v_F_15 == NIL) {
goto b_NIL_12;
}
v_X_21 = v_F_15;
t7 = ((LP) DEREF((v_X_21) + 0 * 4));
t6 = ICALL(s_lsp_LOOP_2DSIMPLEP_2D1) (1, t7);
t5 = (add((t6), (v_Z_2)));
v_Z_2 = (add((t5), ((LP) 2)));
goto t_LOOP3435_16;
b_NIL_12:;
goto t_LOOP3432_7;
b_NIL_3:;
return(v_Z_2);
} else {
v_X_41 = v_X_0;
t9 = ((LP) DEREF((v_X_41) + 0 * 4));
t8 = ICALL(s_lsp_SYMBOLP) (1, t9);
if (t8 != NIL) {
v_X_23 = v_X_0;
v_FN_25 = ((LP) DEREF((v_X_23) + 0 * 4));
v_TEM_26 = LREF(s_lsp_NIL);
v_TEM_26 = ICALL(s_lsp_GET) (2, v_FN_25, LREF(s_lsp_LOOP_2DSIMPLEP));
if (v_TEM_26 != NIL) {
t10 = ICALL(s_lsp_FIXNUMP) (1, v_TEM_26);
if (t10 != NIL) {
v_Z_2 = v_TEM_26;
} else {
v_Z_2 = CODE_PTR(COERCE_TO_FUNCTION(v_TEM_26))(1, v_X_0);
v_X_0 = LREF(s_lsp_NIL);
}
} else {
v_TEST3437_27 = ICALL(s_lsp_MEMQL) (2, v_FN_25, LREF(k2252));
if (v_TEST3437_27 != NIL) {
} else {
t11 = ICALL(s_lsp_MEMQL) (2, v_FN_25, LREF(k2258));
if (t11 != NIL) {
v_Z_2 = (LP) 2;
} else {
t12 = ICALL(s_lsp_MEMQL) (2, v_FN_25, LREF(k2260));
if (t12 != NIL) {
v_Z_2 = (LP) 4;
} else {
t13 = ICALL(s_lsp_MEMQL) (2, v_FN_25, LREF(k2264));
if (t13 != NIL) {
v_Z_2 = (LP) 6;
} else {
t14 = ICALL(s_lsp_MEMQL) (2, v_FN_25, LREF(k2272));
if (t14 != NIL) {
v_Z_2 = (LP) 8;
} else {
t16 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSIMPLEP));
t15 = ICALL(s_lsp_MEMQL) (2, v_FN_25, t16);
if (t15 != NIL) {
v_Z_2 = (LP) 4;
} else {
{
int real_argc;
BEGIN_MV_CALL(mv_holder2249,0);
t18 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DMACRO_2DENVIRONMENT));
t17 = ICALL(s_lsp_MACROEXPAND_2D1) (MV_CALL(mv_holder2249,2), v_X_0, t18);
SET_MV_RETURN_VALUE(mv_holder2249,0,t17);
if SV_RETURN_P(mv_holder2249) SET_MV_RETURN_COUNT(mv_holder2249,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder2249);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_NEW_2DFORM_28 = NIL;
} else {
v_NEW_2DFORM_28 = NEXT_VAR_VALUE(mv_holder2249);
}
if (real_argc < 2) {
v_EXPANDED_2DP_29 = NIL;
} else {
v_EXPANDED_2DP_29 = NEXT_VAR_VALUE(mv_holder2249);
}
END_VAR_VALUES;
END_MV_CALL;
if (v_EXPANDED_2DP_29 != NIL) {
v_Z_2 = ICALL(s_lsp_LOOP_2DSIMPLEP_2D1) (1, v_NEW_2DFORM_28);
v_X_0 = LREF(s_lsp_NIL);
} else {
BEGIN_MV_CALL(throw_mv_holder2250,0);
THROW(LREF(s_lsp_LOOP_2DSIMPLEP),LREF(s_lsp_NIL),throw_mv_holder2250);
END_MV_CALL;
}
}
}
}
}
}
}
}
}
v_X_31 = v_X_0;
v_L_33 = ((LP) DEREF((v_X_31) + 1 * 4));
goto t_TEST3438_35;
t_LOOP3439_34:;
v_X_36 = v_L_33;
v_TMP3440_38 = ((LP) DEREF((v_X_36) + 1 * 4));
v_L_33 = v_TMP3440_38;
t_TEST3438_35:;
if (v_L_33 == NIL) {
goto b_NIL_30;
}
v_X_39 = v_L_33;
t21 = ((LP) DEREF((v_X_39) + 0 * 4));
t20 = ICALL(s_lsp_LOOP_2DSIMPLEP_2D1) (1, t21);
t19 = (add((t20), ((LP) 2)));
v_Z_2 = (add((t19), (v_Z_2)));
goto t_LOOP3439_34;
b_NIL_30:;
return(v_Z_2);
} else {
BEGIN_MV_CALL(throw_mv_holder2251,0);
THROW(LREF(s_lsp_LOOP_2DSIMPLEP),LREF(s_lsp_NIL),throw_mv_holder2251);
END_MV_CALL;
}
}
}
}
}

LP p_lsp_LOOP_2DHACK_2DITERATION(argc, v_ENTRY_0)
      ARGC argc;  LP v_ENTRY_0;
{
LP v_X_211; LP v_S3469_210; LP v_X_208; 
LP v_VALUE3468_207; LP v_X_205; LP v_LIST3467_204; 
LP v_S3466_203; LP v_X_201; LP v_VALUE3465_200; 
LP v_X_198; LP v_LIST3464_197; LP v_X_195; 
LP v_X_193; LP v_C_191; LP v_G3463_190; 
LP v_X_188; LP v_S3462_187; LP v_Y_185; 
LP v_X_184; LP v_VALUE3461_183; LP v_Y_181; 
LP v_X_180; LP v_S3460_179; LP v_Y_177; 
LP v_X_176; LP v_VALUE3459_175; LP v_Y_173; 
LP v_X_172; LP v_LOOP_2DCONDITIONALS_171; LP v_X_169; 
LP v_V_167; LP v_X_166; LP v_NEW_2DCDR_164; 
LP v_C_163; LP v_Y_161; LP v_X_160; 
LP v_Y_158; LP v_X_157; LP v_X_155; 
LP v_V_153; LP v_X_152; LP v_NEW_2DCDR_150; 
LP v_C_149; LP v_Y_147; LP v_X_146; 
LP v_X_145; LP v_X_143; LP v_X_141; 
LP v_LOOPVAR_2D894_137; LP v_LOOPVAR_2D893_136; LP v_LOOPVAR_2D892_135; 
LP v_LOOP_2DLIST_2D891_134; LP v_L3458_133; LP v_X_131; 
LP v_X_129; LP v_X_128; LP v_X_126; 
LP v_X_124; LP v_LOOPVAR_2D890_120; LP v_LOOPVAR_2D889_119; 
LP v_LOOPVAR_2D888_118; LP v_LOOP_2DLIST_2D887_117; LP v_L3457_116; 
LP v_X_114; LP v_X_112; LP v_C_110; 
LP v_X_108; LP v_X_106; LP v_S3456_105; 
LP v_Y_103; LP v_X_102; LP v_VALUE3455_101; 
LP v_X_99; LP v_X_97; LP v_X_95; 
LP v_X_93; LP v_S3454_92; LP v_Y_90; 
LP v_X_89; LP v_VALUE3453_88; LP v_X_86; 
LP v_G3452_85; LP v_G3451_84; LP v_G3450_83; 
LP v_G3449_82; LP v_G3448_81; LP v_CRUFT_80; 
LP v_X_78; LP v_X_76; LP v_X_74; 
LP v_C_72; LP v_X_70; LP v_X_68; 
LP v_C_66; LP v_X_64; LP v_X_62; 
LP v_X_60; LP v_X_58; LP v_X_56; 
LP v_X_54; LP v_X_52; LP v_S3447_51; 
LP v_Y_49; LP v_X_48; LP v_VALUE3446_47; 
LP v_X_45; LP v_X_43; LP v_X_41; 
LP v_X_39; LP v_S3445_38; LP v_Y_36; 
LP v_X_35; LP v_VALUE3444_34; LP v_X_32; 
LP v_X_30; LP v_X_28; LP v_C_26; 
LP v_X_24; LP v_X_22; LP v_C_20; 
LP v_TMP3443_19; LP v_BAR_16; LP v_FOO_15; 
LP v_DATA_14; LP v_TEM_13; LP v_PRE_2DLOOP_2DPSEUDO_2DSTEPS_12; 
LP v_PRE_2DLOOP_2DPOST_2DSTEP_2DTESTS_11; LP v_PRE_2DLOOP_2DSTEPS_10; LP v_PRE_2DLOOP_2DPRE_2DSTEP_2DTESTS_9; 
LP v_PSEUDO_2DSTEPS_8; LP v_POST_2DSTEP_2DTESTS_7; LP v_STEPS_6; 
LP v_PRE_2DSTEP_2DTESTS_5; LP v_SOURCE_4; LP v_LAST_2DENTRY_3; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; LP t145; LP t146; LP t147; LP t148; LP t149; 
LP t150; LP t151; LP t152; LP t153; LP t154; LP t155; 
LP t156; LP t157; LP t158; LP t159; LP t160; LP t161; 
LP t162; LP t163; LP t164; LP t165; LP t166; LP t167; 
LP t168; LP t169; LP t170; LP t171; LP t172; LP t173; 
LP t174; LP t175; LP t176; LP t177; LP t178; LP t179; 
LP t180; LP t181; LP t182; LP t183; LP t184; LP t185; 
LP t186; LP t187; LP t188; LP t189; LP t190; LP t191; 
LP t192; LP t193; LP t194; LP t195; LP t196; LP t197; 
LP t198; LP t199; LP t200; LP t201; LP t202; LP t203; 
LP t204; LP t205; LP t206; LP t207; LP t208; LP t209; 
LP t210; LP t211; LP t212; LP t213; LP t214; LP t215; 
LP t216; LP t217; LP t218; LP t219; LP t220; LP t221; 
LP t222; LP t223; LP t224; LP t225; LP t226; LP t227; 
LP t228; LP t229; LP t230; LP t231; LP t232; LP t233; 
LP t234; LP t235; LP t236; LP t237; LP t238; LP t239; 
LP t240; LP t241; LP t242; LP t243; LP t244; LP t245; 
LP t246; LP t247; LP t248; LP t249; LP t250; LP t251; 
LP t252; LP t253; LP t254; LP t255; LP t256; LP t257; 
LP t258; LP t259; LP t260; LP t261; LP t262; LP t263; 
LP t264; LP t265; LP t266; LP t267; LP t268; LP t269; 
LP t270; LP t271; LP t272; LP t273; LP t274; LP t275; 
LP t276; LP t277; LP t278; LP t279; LP t280; LP t281; 
LP t282; LP t283; LP t284; LP t285; LP t286; LP t287; 
LP t288; LP t289; LP t290; LP t291; LP t292; LP t293; 
LP t294; LP t295; LP t296; LP t297; LP t298; LP t299; 
LP t300; LP t301; LP t302; LP t303; LP t304; LP t305; 
LP t306; 
if (argc != 1) wna(argc,1);
v_LAST_2DENTRY_3 = v_ENTRY_0;
v_SOURCE_4 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_PRE_2DSTEP_2DTESTS_5 = LREF(s_lsp_NIL);
v_STEPS_6 = LREF(s_lsp_NIL);
v_POST_2DSTEP_2DTESTS_7 = LREF(s_lsp_NIL);
v_PSEUDO_2DSTEPS_8 = LREF(s_lsp_NIL);
v_PRE_2DLOOP_2DPRE_2DSTEP_2DTESTS_9 = LREF(s_lsp_NIL);
v_PRE_2DLOOP_2DSTEPS_10 = LREF(s_lsp_NIL);
v_PRE_2DLOOP_2DPOST_2DSTEP_2DTESTS_11 = LREF(s_lsp_NIL);
v_PRE_2DLOOP_2DPSEUDO_2DSTEPS_12 = LREF(s_lsp_NIL);
v_TEM_13 = LREF(s_lsp_NIL);
v_DATA_14 = LREF(s_lsp_NIL);
v_FOO_15 = LREF(s_lsp_NIL);
v_BAR_16 = LREF(s_lsp_NIL);
goto t_TEST3441_18;
t_LOOP3442_17:;
v_TMP3443_19 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_SOURCE_4 = v_TMP3443_19;
t_TEST3441_18:;
v_C_20 = v_ENTRY_0;
v_X_22 = v_C_20;
v_X_24 = ((LP) DEREF((v_C_20) + 1 * 4));
t1 = ((LP) DEREF((v_X_24) + 1 * 4));
v_C_26 = v_ENTRY_0;
v_X_28 = v_C_26;
v_X_30 = ((LP) DEREF((v_C_26) + 1 * 4));
t2 = ((LP) DEREF((v_X_30) + 0 * 4));
v_DATA_14 = p_lsp_APPLY(2, COERCE_TO_FUNCTION(t2), t1);
v_TEM_13 = v_DATA_14;
v_X_39 = v_TEM_13;
t3 = ((LP) DEREF((v_X_39) + 0 * 4));
if (t3 != NIL) {
v_X_32 = v_TEM_13;
v_VALUE3444_34 = ((LP) DEREF((v_X_32) + 0 * 4));
v_Y_36 = v_PRE_2DSTEP_2DTESTS_5;
v_S3445_38 = (c_cons((v_VALUE3444_34), (v_Y_36)));
v_PRE_2DSTEP_2DTESTS_5 = v_S3445_38;
}
v_X_41 = v_TEM_13;
v_TEM_13 = ((LP) DEREF((v_X_41) + 1 * 4));
v_X_43 = v_TEM_13;
t5 = ((LP) DEREF((v_X_43) + 0 * 4));
t4 = ICALL(s_lsp_COPY_2DLIST) (1, t5);
v_STEPS_6 = ICALL(s_lsp_NCONC_2F2) (2, v_STEPS_6, t4);
v_X_52 = v_TEM_13;
v_TEM_13 = ((LP) DEREF((v_X_52) + 1 * 4));
v_X_54 = v_TEM_13;
t6 = ((LP) DEREF((v_X_54) + 0 * 4));
if (t6 != NIL) {
v_X_45 = v_TEM_13;
v_VALUE3446_47 = ((LP) DEREF((v_X_45) + 0 * 4));
v_Y_49 = v_POST_2DSTEP_2DTESTS_7;
v_S3447_51 = (c_cons((v_VALUE3446_47), (v_Y_49)));
v_POST_2DSTEP_2DTESTS_7 = v_S3447_51;
}
v_X_56 = v_TEM_13;
v_TEM_13 = ((LP) DEREF((v_X_56) + 1 * 4));
v_X_58 = v_TEM_13;
t8 = ((LP) DEREF((v_X_58) + 0 * 4));
t7 = ICALL(s_lsp_COPY_2DLIST) (1, t8);
v_PSEUDO_2DSTEPS_8 = ICALL(s_lsp_NCONC_2F2) (2, v_PSEUDO_2DSTEPS_8, t7);
v_X_60 = v_TEM_13;
v_TEM_13 = ((LP) DEREF((v_X_60) + 1 * 4));
v_G3451_84 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DCONDITIONALS));
if (v_G3451_84 != NIL) {
t9 = v_G3451_84;
} else {
t9 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DEMITTED_2DBODY_3F));
}
if (t9 != NIL) {
v_G3448_81 = v_TEM_13;
if (v_G3448_81 != NIL) {
t10 = v_G3448_81;
} else {
v_G3449_82 = v_PRE_2DSTEP_2DTESTS_5;
if (v_G3449_82 != NIL) {
t10 = v_G3449_82;
} else {
v_G3450_83 = v_POST_2DSTEP_2DTESTS_7;
if (v_G3450_83 != NIL) {
t10 = v_G3450_83;
} else {
t10 = v_PSEUDO_2DSTEPS_8;
}
}
}
if (t10 != NIL) {
v_X_62 = v_ENTRY_0;
t11 = ((LP) DEREF((v_X_62) + 0 * 4));
v_X_64 = v_SOURCE_4;
t12 = ((LP) DEREF((v_X_64) + 0 * 4));
v_C_66 = v_SOURCE_4;
v_X_68 = v_C_66;
v_X_70 = ((LP) DEREF((v_C_66) + 1 * 4));
t13 = ((LP) DEREF((v_X_70) + 0 * 4));
v_C_72 = v_SOURCE_4;
v_X_74 = v_C_72;
v_X_76 = ((LP) DEREF((v_C_72) + 1 * 4));
v_X_78 = ((LP) DEREF((v_X_76) + 1 * 4));
t14 = ((LP) DEREF((v_X_78) + 0 * 4));
v_CRUFT_80 = ICALL(s_lsp_LIST) (4, t11, t12, t13, t14);
t15 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DEMITTED_2DBODY_3F));
if (t15 != NIL) {
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2288), v_CRUFT_80);
} else {
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2289), v_CRUFT_80);
}
}
}
v_G3452_85 = v_TEM_13;
if (v_G3452_85 != NIL) {
} else {
v_TEM_13 = v_DATA_14;
}
v_X_93 = v_TEM_13;
t16 = ((LP) DEREF((v_X_93) + 0 * 4));
if (t16 != NIL) {
v_X_86 = v_TEM_13;
v_VALUE3453_88 = ((LP) DEREF((v_X_86) + 0 * 4));
v_Y_90 = v_PRE_2DLOOP_2DPRE_2DSTEP_2DTESTS_9;
v_S3454_92 = (c_cons((v_VALUE3453_88), (v_Y_90)));
v_PRE_2DLOOP_2DPRE_2DSTEP_2DTESTS_9 = v_S3454_92;
}
v_X_95 = v_TEM_13;
v_TEM_13 = ((LP) DEREF((v_X_95) + 1 * 4));
v_X_97 = v_TEM_13;
t18 = ((LP) DEREF((v_X_97) + 0 * 4));
t17 = ICALL(s_lsp_COPY_2DLIST) (1, t18);
v_PRE_2DLOOP_2DSTEPS_10 = ICALL(s_lsp_NCONC_2F2) (2, v_PRE_2DLOOP_2DSTEPS_10, t17);
v_X_106 = v_TEM_13;
v_TEM_13 = ((LP) DEREF((v_X_106) + 1 * 4));
v_X_108 = v_TEM_13;
t19 = ((LP) DEREF((v_X_108) + 0 * 4));
if (t19 != NIL) {
v_X_99 = v_TEM_13;
v_VALUE3455_101 = ((LP) DEREF((v_X_99) + 0 * 4));
v_Y_103 = v_PRE_2DLOOP_2DPOST_2DSTEP_2DTESTS_11;
v_S3456_105 = (c_cons((v_VALUE3455_101), (v_Y_103)));
v_PRE_2DLOOP_2DPOST_2DSTEP_2DTESTS_11 = v_S3456_105;
}
v_C_110 = v_TEM_13;
v_X_112 = v_C_110;
v_X_114 = ((LP) DEREF((v_C_110) + 1 * 4));
t21 = ((LP) DEREF((v_X_114) + 0 * 4));
t20 = ICALL(s_lsp_COPY_2DLIST) (1, t21);
v_PRE_2DLOOP_2DPSEUDO_2DSTEPS_12 = ICALL(s_lsp_NCONC_2F2) (2, v_PRE_2DLOOP_2DPSEUDO_2DSTEPS_12, t20);
v_X_188 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
t23 = ((LP) DEREF((v_X_188) + 0 * 4));
t22 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, t23, LREF(s_lsp_AND));
v_G3463_190 = ICALL(s_lsp_NOT) (1, t22);
if (v_G3463_190 != NIL) {
t24 = v_G3463_190;
} else {
t25 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DCONDITIONALS));
if (t25 != NIL) {
v_C_191 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_193 = v_C_191;
v_X_195 = ((LP) DEREF((v_C_191) + 1 * 4));
t27 = ((LP) DEREF((v_X_195) + 0 * 4));
t28 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DITERATION_2DKEYWORD_2DALIST));
t26 = ICALL(s_lsp_LOOP_2DTASSOC) (2, t27, t28);
t24 = ICALL(s_lsp_NOT) (1, t26);
} else {
t24 = LREF(s_lsp_NIL);
}
}
if (t24 != NIL) {
t29 = ICALL(s_lsp_LOOP_2DEND_2DTESTIFY) (1, v_PRE_2DLOOP_2DPRE_2DSTEP_2DTESTS_9);
t30 = ICALL(s_lsp_LOOP_2DMAKE_2DPSETQ) (1, v_PRE_2DLOOP_2DSTEPS_10);
t31 = ICALL(s_lsp_LOOP_2DEND_2DTESTIFY) (1, v_PRE_2DLOOP_2DPOST_2DSTEP_2DTESTS_11);
t32 = ICALL(s_lsp_LOOP_2DMAKE_2DSETQ) (1, v_PRE_2DLOOP_2DPSEUDO_2DSTEPS_12);
v_FOO_15 = ICALL(s_lsp_LIST) (4, t29, t30, t31, t32);
t33 = ICALL(s_lsp_LOOP_2DEND_2DTESTIFY) (1, v_PRE_2DSTEP_2DTESTS_5);
t34 = ICALL(s_lsp_LOOP_2DMAKE_2DPSETQ) (1, v_STEPS_6);
t35 = ICALL(s_lsp_LOOP_2DEND_2DTESTIFY) (1, v_POST_2DSTEP_2DTESTS_7);
t36 = ICALL(s_lsp_LOOP_2DMAKE_2DSETQ) (1, v_PSEUDO_2DSTEPS_8);
v_BAR_16 = ICALL(s_lsp_LIST) (4, t33, t34, t35, t36);
t37 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DCONDITIONALS));
if (t37 != NIL) {
v_L3457_116 = LREF(s_lsp_NIL);
v_LOOP_2DLIST_2D887_117 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DCONDITIONALS));
v_LOOPVAR_2D888_118 = LREF(s_lsp_NIL);
v_LOOPVAR_2D889_119 = LREF(s_lsp_NIL);
v_LOOPVAR_2D890_120 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_122:;
if (v_LOOP_2DLIST_2D887_117 == NIL) {
goto t_END_2DLOOP_123;
}
v_X_124 = v_LOOP_2DLIST_2D887_117;
v_L3457_116 = ((LP) DEREF((v_X_124) + 0 * 4));
v_X_126 = v_LOOP_2DLIST_2D887_117;
v_LOOP_2DLIST_2D887_117 = ((LP) DEREF((v_X_126) + 1 * 4));
v_X_128 = v_L3457_116;
v_X_129 = v_X_128;
v_X_157 = ((LP) DEREF((v_X_128) + 0 * 4));
v_L3458_133 = LREF(s_lsp_NIL);
v_X_131 = v_X_128;
v_LOOP_2DLIST_2D891_134 = ((LP) DEREF((v_X_128) + 1 * 4));
v_LOOPVAR_2D892_135 = LREF(s_lsp_NIL);
v_LOOPVAR_2D893_136 = LREF(s_lsp_NIL);
v_LOOPVAR_2D894_137 = LREF(s_lsp_NIL);
t_NEXT_2DLOOP_139:;
if (v_LOOP_2DLIST_2D891_134 == NIL) {
goto t_END_2DLOOP_140;
}
v_X_141 = v_LOOP_2DLIST_2D891_134;
v_L3458_133 = ((LP) DEREF((v_X_141) + 0 * 4));
v_X_143 = v_LOOP_2DLIST_2D891_134;
v_LOOP_2DLIST_2D891_134 = ((LP) DEREF((v_X_143) + 1 * 4));
v_X_145 = v_L3458_133;
v_X_146 = ICALL(s_lsp_COPY_2DLIST) (1, v_X_145);
v_LOOPVAR_2D894_137 = (c_cons((v_X_146), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D893_136 != NIL) {
v_C_149 = v_LOOPVAR_2D893_136;
v_NEW_2DCDR_150 = v_LOOPVAR_2D894_137;
v_V_153 = v_NEW_2DCDR_150;
((LP) (DEREF((v_C_149) + 1 * 4) = (LD) (v_V_153)));
v_X_155 = v_C_149;
v_LOOPVAR_2D893_136 = ((LP) DEREF((v_X_155) + 1 * 4));
} else {
v_LOOPVAR_2D892_135 = v_LOOPVAR_2D894_137;
v_LOOPVAR_2D893_136 = v_LOOPVAR_2D892_135;
}
goto t_NEXT_2DLOOP_139;
goto t_END_2DLOOP_140;
t_END_2DLOOP_140:;
v_Y_158 = v_LOOPVAR_2D892_135;
goto b_NIL_138;
v_Y_158 = NIL;
v_Y_158 = v_Y_158;
b_NIL_138:;
v_X_160 = (c_cons((v_X_157), (v_Y_158)));
v_LOOPVAR_2D890_120 = (c_cons((v_X_160), (LREF(s_lsp_NIL))));
if (v_LOOPVAR_2D889_119 != NIL) {
v_C_163 = v_LOOPVAR_2D889_119;
v_NEW_2DCDR_164 = v_LOOPVAR_2D890_120;
v_V_167 = v_NEW_2DCDR_164;
((LP) (DEREF((v_C_163) + 1 * 4) = (LD) (v_V_167)));
v_X_169 = v_C_163;
v_LOOPVAR_2D889_119 = ((LP) DEREF((v_X_169) + 1 * 4));
} else {
v_LOOPVAR_2D888_118 = v_LOOPVAR_2D890_120;
v_LOOPVAR_2D889_119 = v_LOOPVAR_2D888_118;
}
goto t_NEXT_2DLOOP_122;
goto t_END_2DLOOP_123;
t_END_2DLOOP_123:;
v_LOOP_2DCONDITIONALS_171 = v_LOOPVAR_2D888_118;
goto b_NIL_121;
v_LOOP_2DCONDITIONALS_171 = NIL;
v_LOOP_2DCONDITIONALS_171 = v_LOOP_2DCONDITIONALS_171;
b_NIL_121:;
BEGIN_SPEC_BIND(s_lsp_LOOP_2DCONDITIONALS,v_LOOP_2DCONDITIONALS_171);
v_Y_173 = ICALL(s_lsp_DELETE) (2, LREF(s_lsp_NIL), v_FOO_15);
t38 = (c_cons((LREF(s_lsp_PROGN)), (v_Y_173)));
v_VALUE3459_175 = ICALL(s_lsp_LOOP_2DMAKE_2DCONDITIONALIZATION) (1, t38);
v_Y_177 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DBEFORE_2DLOOP));
v_S3460_179 = (c_cons((v_VALUE3459_175), (v_Y_177)));
t39 = ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DBEFORE_2DLOOP), v_S3460_179);
END_SPEC_BIND(s_lsp_LOOP_2DCONDITIONALS);
v_Y_181 = ICALL(s_lsp_DELETE) (2, LREF(s_lsp_NIL), v_BAR_16);
t40 = (c_cons((LREF(s_lsp_PROGN)), (v_Y_181)));
v_VALUE3461_183 = ICALL(s_lsp_LOOP_2DMAKE_2DCONDITIONALIZATION) (1, t40);
v_Y_185 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DAFTER_2DBODY));
v_S3462_187 = (c_cons((v_VALUE3461_183), (v_Y_185)));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DAFTER_2DBODY), v_S3462_187);
} else {
t42 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DBEFORE_2DLOOP));
t41 = ICALL(s_lsp_NRECONC) (2, v_FOO_15, t42);
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DBEFORE_2DLOOP), t41);
t44 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DAFTER_2DBODY));
t43 = ICALL(s_lsp_NRECONC) (2, v_BAR_16, t44);
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DAFTER_2DBODY), t43);
}
ICALL(s_lsp_LOOP_2DBIND_2DBLOCK) (0);
return(LREF(s_lsp_NIL));
return(NIL);
}
v_LIST3464_197 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_198 = v_LIST3464_197;
v_VALUE3465_200 = ((LP) DEREF((v_LIST3464_197) + 0 * 4));
v_X_201 = v_LIST3464_197;
v_S3466_203 = ((LP) DEREF((v_LIST3464_197) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3466_203);
v_X_211 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
t45 = ((LP) DEREF((v_X_211) + 0 * 4));
t46 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DITERATION_2DKEYWORD_2DALIST));
v_TEM_13 = ICALL(s_lsp_LOOP_2DTASSOC) (2, t45, t46);
if (v_TEM_13 != NIL) {
v_LIST3467_204 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_205 = v_LIST3467_204;
v_VALUE3468_207 = ((LP) DEREF((v_LIST3467_204) + 0 * 4));
v_X_208 = v_LIST3467_204;
v_S3469_210 = ((LP) DEREF((v_LIST3467_204) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3469_210);
v_LAST_2DENTRY_3 = v_TEM_13;
v_ENTRY_0 = v_LAST_2DENTRY_3;
} else {
v_ENTRY_0 = v_LAST_2DENTRY_3;
}
goto t_LOOP3442_17;
return(NIL);
}

LP p_lsp_LOOP_2DDO_2DFOR(argc)
      ARGC argc; 
{
LP v_X_49; LP v_X_47; LP v_C_45; 
LP v_X_43; LP v_X_41; LP v_C_39; 
LP v_Y_37; LP v_X_36; LP v_Y_34; 
LP v_X_33; LP v_Y_31; LP v_X_30; 
LP v_G3476_29; LP v_Y_27; LP v_X_26; 
LP v_Y_24; LP v_X_23; LP v_Y_21; 
LP v_X_20; LP v_TEM_19; LP v_FIRST_2DARG_18; 
LP v_KEYWORD_17; LP v_DATA_2DTYPE_3F_16; LP v_VAR_15; 
LP v_S3475_14; LP v_X_12; LP v_VALUE3474_11; 
LP v_X_9; LP v_LIST3473_8; LP v_S3472_7; 
LP v_X_5; LP v_VALUE3471_4; LP v_X_2; 
LP v_LIST3470_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; 
if (argc != 0) wna(argc,0);
v_LIST3470_1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_2 = v_LIST3470_1;
v_VALUE3471_4 = ((LP) DEREF((v_LIST3470_1) + 0 * 4));
v_X_5 = v_LIST3470_1;
v_S3472_7 = ((LP) DEREF((v_LIST3470_1) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3472_7);
v_VAR_15 = v_VALUE3471_4;
v_DATA_2DTYPE_3F_16 = ICALL(s_lsp_LOOP_2DOPTIONAL_2DTYPE) (0);
v_LIST3473_8 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_9 = v_LIST3473_8;
v_VALUE3474_11 = ((LP) DEREF((v_LIST3473_8) + 0 * 4));
v_X_12 = v_LIST3473_8;
v_S3475_14 = ((LP) DEREF((v_LIST3473_8) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3475_14);
v_KEYWORD_17 = v_VALUE3474_11;
v_FIRST_2DARG_18 = LREF(s_lsp_NIL);
v_TEM_19 = LREF(s_lsp_NIL);
v_X_20 = v_KEYWORD_17;
v_Y_21 = LREF(s_lsp_NIL);
v_Y_24 = (c_cons((v_KEYWORD_17), (LREF(s_lsp_NIL))));
v_Y_27 = (c_cons((v_VAR_15), (v_Y_24)));
t0 = (c_cons((LREF(s_lsp_FOR)), (v_Y_27)));
v_FIRST_2DARG_18 = ICALL(s_lsp_LOOP_2DGET_2DFORM) (1, t0);
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DFOR_2DKEYWORD_2DALIST));
v_TEM_19 = ICALL(s_lsp_LOOP_2DTASSOC) (2, v_KEYWORD_17, t1);
v_G3476_29 = v_TEM_19;
if (v_G3476_29 != NIL) {
} else {
v_X_30 = v_KEYWORD_17;
v_Y_31 = LREF(s_lsp_NIL);
v_Y_34 = (c_cons((v_KEYWORD_17), (LREF(s_lsp_NIL))));
v_Y_37 = (c_cons((v_VAR_15), (v_Y_34)));
t2 = (c_cons((LREF(s_lsp_FOR)), (v_Y_37)));
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2290), t2);
}
v_C_39 = v_TEM_19;
v_X_41 = v_C_39;
v_X_43 = ((LP) DEREF((v_C_39) + 1 * 4));
t4 = ((LP) DEREF((v_X_43) + 1 * 4));
v_C_45 = v_TEM_19;
v_X_47 = v_C_45;
v_X_49 = ((LP) DEREF((v_C_45) + 1 * 4));
t5 = ((LP) DEREF((v_X_49) + 0 * 4));
t3 = p_lsp_APPLY(MV_CALL(argc,5), COERCE_TO_FUNCTION(t5), v_VAR_15, v_FIRST_2DARG_18, v_DATA_2DTYPE_3F_16, t4);
return(t3);
}

LP p_lsp_LOOP_2DDO_2DREPEAT(argc)
      ARGC argc; 
{
LP v_Y_24; LP v_X_23; LP v_Y_21; 
LP v_X_20; LP v_Y_18; LP v_X_17; 
LP v_Y_15; LP v_X_14; LP v_Y_12; 
LP v_X_11; LP v_Y_9; LP v_X_8; 
LP v_Y_6; LP v_X_5; LP v_Y_3; 
LP v_X_2; LP v_VAR_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; 
if (argc != 0) wna(argc,0);
t1 = ICALL(s_lsp_SYMBOL_2DNAME) (1, LREF(s_lsp_LOOP_2DREPEAT_2D));
t0 = ICALL(s_lsp_GENTEMP) (1, t1);
t2 = ICALL(s_lsp_LOOP_2DGET_2DFORM) (1, LREF(s_lsp_REPEAT));
v_VAR_1 = ICALL(s_lsp_LOOP_2DMAKE_2DVARIABLE) (3, t0, t2, LREF(s_lsp_FIXNUM));
v_X_5 = ICALL(s_lsp_LOOP_2DTYPED_2DARITH) (2, LREF(s_lsp_PLUSP), LREF(s_lsp_FIXNUM));
v_X_2 = v_VAR_1;
v_Y_3 = LREF(s_lsp_NIL);
v_Y_6 = (c_cons((v_VAR_1), (LREF(s_lsp_NIL))));
v_X_8 = (c_cons((v_X_5), (v_Y_6)));
v_Y_12 = (c_cons((v_X_8), (LREF(s_lsp_NIL))));
t4 = (c_cons((LREF(s_lsp_NOT)), (v_Y_12)));
v_X_17 = ICALL(s_lsp_LOOP_2DTYPED_2DARITH) (2, LREF(s_lsp_1_2D), LREF(s_lsp_FIXNUM));
v_X_14 = v_VAR_1;
v_Y_15 = LREF(s_lsp_NIL);
v_Y_18 = (c_cons((v_VAR_1), (LREF(s_lsp_NIL))));
v_X_20 = (c_cons((v_X_17), (v_Y_18)));
v_Y_24 = (c_cons((v_X_20), (LREF(s_lsp_NIL))));
t5 = (c_cons((v_VAR_1), (v_Y_24)));
t3 = ICALL(s_lsp_LIST) (MV_CALL(argc,4), t4, LREF(s_lsp_NIL), LREF(s_lsp_NIL), t5);
return(t3);
}

LP p_lsp_LOOP_2DWHEN_2DIT_2DVARIABLE(argc)
      ARGC argc; 
{
LP v_G3477_1; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 0) wna(argc,0);
v_G3477_1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DWHEN_2DIT_2DVARIABLE));
if (v_G3477_1 != NIL) {
return(v_G3477_1);
} else {
t3 = ICALL(s_lsp_SYMBOL_2DNAME) (1, LREF(s_lsp_LOOP_2DIT_2D));
t2 = ICALL(s_lsp_GENTEMP) (1, t3);
t1 = ICALL(s_lsp_LOOP_2DMAKE_2DVARIABLE) (3, t2, LREF(s_lsp_NIL), LREF(s_lsp_NIL));
t0 = ICALL(s_lsp_SET) (MV_CALL(argc,2), LREF(s_lsp_LOOP_2DWHEN_2DIT_2DVARIABLE), t1);
return(t0);
}
}

LP p_lsp_LOOP_2DFOR_2DEQUALS(argc, v_VAR_0, v_VAL_1, v_DATA_2DTYPE_3F_2)
      ARGC argc;  LP v_VAR_0; LP v_VAL_1; LP v_DATA_2DTYPE_3F_2;
{
LP v_X_25; LP v_TEST3481_24; LP v_VARVAL_23; 
LP v_Y_21; LP v_X_20; LP v_Y_18; 
LP v_X_17; LP v_Y_15; LP v_X_14; 
LP v_Y_12; LP v_X_11; LP v_S3480_10; 
LP v_X_8; LP v_VALUE3479_7; LP v_X_5; 
LP v_LIST3478_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; 
if (argc != 3) wna(argc,3);
v_X_25 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
t2 = ((LP) DEREF((v_X_25) + 0 * 4));
t1 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, t2, LREF(s_lsp_THEN));
if (t1 != NIL) {
v_LIST3478_4 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_5 = v_LIST3478_4;
v_VALUE3479_7 = ((LP) DEREF((v_LIST3478_4) + 0 * 4));
v_X_8 = v_LIST3478_4;
v_S3480_10 = ((LP) DEREF((v_LIST3478_4) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3480_10);
ICALL(s_lsp_LOOP_2DMAKE_2DITERATION_2DVARIABLE) (3, v_VAR_0, v_VAL_1, v_DATA_2DTYPE_3F_2);
t3 = ICALL(s_lsp_LIST) (5, LREF(s_lsp_FOR), v_VAR_0, LREF(s_lsp__3D), v_VAL_1, LREF(s_lsp_THEN));
v_X_11 = ICALL(s_lsp_LOOP_2DGET_2DFORM) (1, t3);
v_Y_15 = (c_cons((v_X_11), (LREF(s_lsp_NIL))));
t4 = (c_cons((v_VAR_0), (v_Y_15)));
t0 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,3), LREF(s_lsp_NIL), t4, LREF(k2291));
return(t0);
} else {
ICALL(s_lsp_LOOP_2DMAKE_2DITERATION_2DVARIABLE) (3, v_VAR_0, LREF(s_lsp_NIL), v_DATA_2DTYPE_3F_2);
v_X_17 = v_VAL_1;
v_Y_18 = LREF(s_lsp_NIL);
v_Y_21 = (c_cons((v_VAL_1), (LREF(s_lsp_NIL))));
v_VARVAL_23 = (c_cons((v_VAR_0), (v_Y_21)));
t5 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DEMITTED_2DBODY_3F));
if (t5 != NIL) {
t6 = ICALL(s_lsp_LOOP_2DMAKE_2DSETQ) (1, v_VARVAL_23);
ICALL(s_lsp_LOOP_2DEMIT_2DBODY) (1, t6);
return(LREF(k2293));
} else {
v_TEST3481_24 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_NIL), v_VARVAL_23, LREF(k2295));
if (v_TEST3481_24 != NIL) {
return(v_TEST3481_24);
} else {
return(LREF(s_lsp_NIL));
}
}
}
}

LP p_lsp_LOOP_2DFOR_2DFIRST(argc, v_VAR_0, v_VAL_1, v_DATA_2DTYPE_3F_2)
      ARGC argc;  LP v_VAR_0; LP v_VAL_1; LP v_DATA_2DTYPE_3F_2;
{
LP v_Y_26; LP v_X_25; LP v_Y_23; 
LP v_X_22; LP v_Y_20; LP v_X_19; 
LP v_Y_17; LP v_X_16; LP v_S3485_15; 
LP v_X_13; LP v_VALUE3484_12; LP v_X_10; 
LP v_LIST3483_9; LP v_X_7; LP v_G3482_6; 
LP v_X_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; 
if (argc != 3) wna(argc,3);
v_X_4 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
t0 = ((LP) DEREF((v_X_4) + 0 * 4));
v_G3482_6 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, t0, LREF(s_lsp_THEN));
if (v_G3482_6 != NIL) {
} else {
v_X_7 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
t1 = ((LP) DEREF((v_X_7) + 0 * 4));
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2296), t1);
}
v_LIST3483_9 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_10 = v_LIST3483_9;
v_VALUE3484_12 = ((LP) DEREF((v_LIST3483_9) + 0 * 4));
v_X_13 = v_LIST3483_9;
v_S3485_15 = ((LP) DEREF((v_LIST3483_9) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3485_15);
ICALL(s_lsp_LOOP_2DMAKE_2DITERATION_2DVARIABLE) (3, v_VAR_0, LREF(s_lsp_NIL), v_DATA_2DTYPE_3F_2);
t3 = ICALL(s_lsp_LIST) (5, LREF(s_lsp_FOR), v_VAR_0, LREF(s_lsp_FIRST), v_VAL_1, LREF(s_lsp_THEN));
v_X_16 = ICALL(s_lsp_LOOP_2DGET_2DFORM) (1, t3);
v_Y_20 = (c_cons((v_X_16), (LREF(s_lsp_NIL))));
t4 = (c_cons((v_VAR_0), (v_Y_20)));
v_X_22 = v_VAL_1;
v_Y_23 = LREF(s_lsp_NIL);
v_Y_26 = (c_cons((v_VAL_1), (LREF(s_lsp_NIL))));
t5 = (c_cons((v_VAR_0), (v_Y_26)));
t2 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,7), LREF(s_lsp_NIL), t4, LREF(s_lsp_NIL), LREF(s_lsp_NIL), LREF(s_lsp_NIL), t5, LREF(k2295));
return(t2);
}

LP p_lsp_LOOP_2DLIST_2DSTEPPER(argc, v_VAR_0, v_VAL_1, v_DATA_2DTYPE_3F_2, v_FN_3)
      ARGC argc;  LP v_VAR_0; LP v_VAL_1; LP v_DATA_2DTYPE_3F_2; LP v_FN_3;
{
LP v_X_80; LP v_Y_78; LP v_X_77; 
LP v_Y_75; LP v_X_74; LP v_Y_72; 
LP v_X_71; LP v_Y_69; LP v_X_68; 
LP v_Y_66; LP v_X_65; LP v_Y_63; 
LP v_X_62; LP v_Y_60; LP v_X_59; 
LP v_V_57; LP v_X_56; LP v_NEW_2DCDR_54; 
LP v_C_53; LP v_Y_51; LP v_X_50; 
LP v_Y_48; LP v_X_47; LP v_Y_45; 
LP v_X_44; LP v_Y_42; LP v_X_41; 
LP v_Y_39; LP v_X_38; LP v_X_36; 
LP v_G3489_35; LP v_Y_33; LP v_X_32; 
LP v_X_30; LP v_X_28; LP v_C_26; 
LP v_Y_24; LP v_X_23; LP v_Y_21; 
LP v_X_20; LP v_PSEUDO_19; LP v_ET_18; 
LP v_STEP_17; LP v_STEPVAR_16; LP v_VAR1_15; 
LP v_STEPPER_14; LP v_X_12; LP v_S3488_11; 
LP v_X_9; LP v_VALUE3487_8; LP v_X_6; 
LP v_LIST3486_5; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; 
if (argc != 4) wna(argc,4);
v_X_12 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
t1 = ((LP) DEREF((v_X_12) + 0 * 4));
t0 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, t1, LREF(s_lsp_BY));
if (t0 != NIL) {
v_LIST3486_5 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_6 = v_LIST3486_5;
v_VALUE3487_8 = ((LP) DEREF((v_LIST3486_5) + 0 * 4));
v_X_9 = v_LIST3486_5;
v_S3488_11 = ((LP) DEREF((v_LIST3486_5) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3488_11);
t4 = ICALL(s_lsp_EQ) (2, v_FN_3, LREF(s_lsp_CAR));
if (t4 != NIL) {
t3 = LREF(s_lsp_IN);
} else {
t3 = LREF(s_lsp_ON);
}
t2 = ICALL(s_lsp_LIST) (5, LREF(s_lsp_FOR), v_VAR_0, t3, v_VAL_1, LREF(s_lsp_BY));
v_STEPPER_14 = ICALL(s_lsp_LOOP_2DGET_2DFORM) (1, t2);
} else {
v_STEPPER_14 = LREF(k2297);
}
v_VAR1_15 = LREF(s_lsp_NIL);
v_STEPVAR_16 = LREF(s_lsp_NIL);
v_STEP_17 = LREF(s_lsp_NIL);
v_ET_18 = LREF(s_lsp_NIL);
v_PSEUDO_19 = LREF(s_lsp_NIL);
v_G3489_35 = ICALL(s_lsp_ATOM) (1, v_STEPPER_14);
if (v_G3489_35 != NIL) {
t5 = v_G3489_35;
} else {
v_X_36 = v_STEPPER_14;
t7 = ((LP) DEREF((v_X_36) + 0 * 4));
t6 = ICALL(s_lsp_MEMQL) (2, t7, LREF(k2298));
t5 = ICALL(s_lsp_NOT) (1, t6);
}
if (t5 != NIL) {
t8 = ICALL(s_lsp_SYMBOL_2DNAME) (1, LREF(s_lsp_LOOP_2DFN_2D));
v_STEPVAR_16 = ICALL(s_lsp_GENTEMP) (1, t8);
v_X_20 = v_STEPVAR_16;
v_Y_24 = (c_cons((v_X_20), (LREF(s_lsp_NIL))));
v_STEP_17 = (c_cons((LREF(s_lsp_FUNCALL)), (v_Y_24)));
} else {
v_C_26 = v_STEPPER_14;
v_X_28 = v_C_26;
v_X_30 = ((LP) DEREF((v_C_26) + 1 * 4));
v_X_32 = ((LP) DEREF((v_X_30) + 0 * 4));
v_STEP_17 = (c_cons((v_X_32), (LREF(s_lsp_NIL))));
}
t10 = ICALL(s_lsp_ATOM) (1, v_VAR_0);
if (t10 != NIL) {
t9 = ICALL(s_lsp_NOT) (1, v_FN_3);
} else {
t9 = LREF(s_lsp_NIL);
}
if (t9 != NIL) {
v_VAR1_15 = ICALL(s_lsp_LOOP_2DMAKE_2DITERATION_2DVARIABLE) (3, v_VAR_0, v_VAL_1, v_DATA_2DTYPE_3F_2);
} else {
ICALL(s_lsp_LOOP_2DMAKE_2DITERATION_2DVARIABLE) (3, v_VAR_0, LREF(s_lsp_NIL), v_DATA_2DTYPE_3F_2);
t12 = ICALL(s_lsp_SYMBOL_2DNAME) (1, LREF(s_lsp_LOOP_2DLIST_2D));
t11 = ICALL(s_lsp_GENTEMP) (1, t12);
v_VAR1_15 = ICALL(s_lsp_LOOP_2DMAKE_2DVARIABLE) (3, t11, v_VAL_1, LREF(s_lsp_NIL));
if (v_FN_3 != NIL) {
v_X_38 = v_VAR1_15;
v_Y_42 = (c_cons((v_X_38), (LREF(s_lsp_NIL))));
v_X_44 = (c_cons((v_FN_3), (v_Y_42)));
} else {
v_X_44 = v_VAR1_15;
}
v_Y_48 = (c_cons((v_X_44), (LREF(s_lsp_NIL))));
v_PSEUDO_19 = (c_cons((v_VAR_0), (v_Y_48)));
}
v_C_53 = ICALL(s_lsp_LAST) (1, v_STEP_17);
v_X_50 = v_VAR1_15;
v_NEW_2DCDR_54 = (c_cons((v_X_50), (LREF(s_lsp_NIL))));
v_V_57 = v_NEW_2DCDR_54;
((LP) (DEREF((v_C_53) + 1 * 4) = (LD) (v_V_57)));
if (v_STEPVAR_16 != NIL) {
ICALL(s_lsp_LOOP_2DMAKE_2DVARIABLE) (3, v_STEPVAR_16, v_STEPPER_14, LREF(s_lsp_NIL));
}
v_X_62 = v_VAR1_15;
v_X_59 = v_STEP_17;
v_Y_63 = (c_cons((v_X_59), (LREF(s_lsp_NIL))));
v_STEPPER_14 = (c_cons((v_X_62), (v_Y_63)));
v_X_65 = v_VAR1_15;
v_Y_69 = (c_cons((v_X_65), (LREF(s_lsp_NIL))));
v_ET_18 = (c_cons((LREF(s_lsp_NULL)), (v_Y_69)));
if (v_PSEUDO_19 != NIL) {
v_X_80 = v_STEP_17;
t15 = ((LP) DEREF((v_X_80) + 0 * 4));
t14 = ICALL(s_lsp_EQ) (2, t15, LREF(s_lsp_CDR));
if (t14 != NIL) {
t13 = ICALL(s_lsp_LIST) (MV_CALL(argc,4), v_ET_18, v_PSEUDO_19, LREF(s_lsp_NIL), v_STEPPER_14);
return(t13);
} else {
v_Y_72 = v_STEPPER_14;
v_X_74 = (c_cons((LREF(s_lsp_SETQ)), (v_Y_72)));
v_Y_78 = (c_cons((v_X_74), (LREF(s_lsp_NIL))));
t16 = (c_cons((LREF(s_lsp_NULL)), (v_Y_78)));
t13 = ICALL(s_lsp_LIST) (MV_CALL(argc,8), t16, LREF(s_lsp_NIL), LREF(s_lsp_NIL), v_PSEUDO_19, v_ET_18, LREF(s_lsp_NIL), LREF(s_lsp_NIL), v_PSEUDO_19);
return(t13);
}
} else {
t13 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,8), LREF(s_lsp_NIL), v_STEPPER_14, v_ET_18, LREF(s_lsp_NIL), LREF(s_lsp_NIL), LREF(s_lsp_NIL), v_ET_18, LREF(k2202));
return(t13);
}
}

LP p_lsp_LOOP_2DFOR_2DARITHMETIC(argc, v_VAR_0, v_VAL_1, v_DATA_2DTYPE_3F_2, v_KWD_3)
      ARGC argc;  LP v_VAR_0; LP v_VAL_1; LP v_DATA_2DTYPE_3F_2; LP v_KWD_3;
{
LP v_Y_13; LP v_X_12; LP v_Y_10; 
LP v_X_9; LP v_Y_7; LP v_X_6; 
LP v_G3490_5; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 

if (argc != 4) wna(argc,4);
v_G3490_5 = v_DATA_2DTYPE_3F_2;
if (v_G3490_5 != NIL) {
t1 = v_G3490_5;
} else {
t1 = LREF(s_lsp_FIXNUM);
}
t2 = ICALL(s_lsp_LIST) (4, LREF(s_lsp_FOR), v_VAR_0, v_KWD_3, v_VAL_1);
v_X_6 = v_VAL_1;
v_Y_7 = LREF(s_lsp_NIL);
v_Y_10 = (c_cons((v_VAL_1), (LREF(s_lsp_NIL))));
v_X_12 = (c_cons((v_KWD_3), (v_Y_10)));
v_Y_13 = ICALL(s_lsp_LOOP_2DGATHER_2DPREPS) (2, LREF(k2300), LREF(s_lsp_NIL));
t3 = (c_cons((v_X_12), (v_Y_13)));
t0 = ICALL(s_lsp_LOOP_2DSEQUENCER) (MV_CALL(argc,10), v_VAR_0, t1, LREF(s_lsp_NIL), LREF(s_lsp_NIL), LREF(s_lsp_NIL), LREF(s_lsp_NIL), LREF(s_lsp_NIL), LREF(s_lsp_NIL), t2, t3);
return(t0);
}

LP p_lsp_LOOP_2DNAMED_2DVARIABLE(argc, v_NAME_0)
      ARGC argc;  LP v_NAME_0;
{
LP v_X_3; LP v_TEM_2; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 

if (argc != 1) wna(argc,1);
t0 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DNAMED_2DVARIABLES));
v_TEM_2 = ICALL(s_lsp_LOOP_2DTASSOC) (2, v_NAME_0, t0);
if (v_TEM_2 != NIL) {
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DNAMED_2DVARIABLES));
t2 = ICALL(s_lsp_DELETE) (2, v_TEM_2, t3);
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DNAMED_2DVARIABLES), t2);
v_X_3 = v_TEM_2;
t1 = ((LP) DEREF((v_TEM_2) + 1 * 4));
return(t1);
} else {
t4 = ICALL(s_lsp_SYMBOL_2DNAME) (1, LREF(s_lsp_LOOPVAR_2D));
t1 = ICALL(s_lsp_GENTEMP) (MV_CALL(argc,1), t4);
return(t1);
}
}

LP p_lsp_LOOP_2DFOR_2DBEING(argc, v_VAR_0, v_VAL_1, v_DATA_2DTYPE_3F_2)
      ARGC argc;  LP v_VAR_0; LP v_VAL_1; LP v_DATA_2DTYPE_3F_2;
{
LP v_X_182; LP v_X_180; LP v_C_178; 
LP v_X_176; LP v_X_174; LP v_C_172; 
LP v_X_170; LP v_X_168; LP v_X_166; 
LP v_X_164; LP v_C_162; LP v_X_160; 
LP v_X_158; LP v_C_156; LP v_X_154; 
LP v_TMP3517_153; LP v_X_151; LP v_X_148; 
LP v_L_147; LP v_X_145; LP v_X_142; 
LP v_X_140; LP v_C_138; LP v_X_136; 
LP v_X_134; LP v_X_132; LP v_C_130; 
LP v_X_128; LP v_X_126; LP v_X_124; 
LP v_C_122; LP v_X_120; LP v_X_118; 
LP v_X_116; LP v_C_114; LP v_X_112; 
LP v_X_110; LP v_X_108; LP v_C_106; 
LP v_TEST3514_105; LP v_X_103; LP v_X_101; 
LP v_C_99; LP v_G3513_98; LP v_X_96; 
LP v_X_94; LP v_S3512_93; LP v_X_91; 
LP v_VALUE3511_90; LP v_X_88; LP v_LIST3510_87; 
LP v_Y_85; LP v_X_84; LP v_Y_82; 
LP v_X_81; LP v_Y_79; LP v_X_78; 
LP v_X_76; LP v_S3509_75; LP v_Y_73; 
LP v_X_72; LP v_VALUE3508_71; LP v_Y_69; 
LP v_X_68; LP v_Y_66; LP v_X_65; 
LP v_S3507_64; LP v_X_62; LP v_VALUE3506_61; 
LP v_X_59; LP v_LIST3505_58; LP v_G3501_57; 
LP v_S3504_56; LP v_X_54; LP v_VALUE3503_53; 
LP v_X_51; LP v_LIST3502_50; LP v_S3500_49; 
LP v_X_47; LP v_VALUE3499_46; LP v_X_44; 
LP v_LIST3498_43; LP v_Y_41; LP v_X_40; 
LP v_Y_38; LP v_X_37; LP v_Y_35; 
LP v_X_34; LP v_G3497_33; LP v_Y_31; 
LP v_X_30; LP v_Y_28; LP v_X_27; 
LP v_Y_25; LP v_X_24; LP v_S3496_23; 
LP v_X_21; LP v_VALUE3495_20; LP v_X_18; 
LP v_LIST3494_17; LP v_G3493_16; LP v_S3492_15; 
LP v_Y_13; LP v_X_12; LP v_VALUE3491_11; 
LP v_X_9; LP v_ATTACHMENT_8; LP v_EACH_3F_7; 
LP v_IPPS_6; LP v_INCLUSIVE_3F_5; LP v_TEM_4; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; LP t145; LP t146; LP t147; LP t148; LP t149; 
LP t150; LP t151; LP t152; LP t153; LP t154; LP t155; 
LP t156; LP t157; LP t158; LP t159; LP t160; LP t161; 
LP t162; LP t163; LP t164; LP t165; LP t166; LP t167; 
LP t168; LP t169; LP t170; LP t171; LP t172; LP t173; 
LP t174; LP t175; LP t176; LP t177; LP t178; LP t179; 
LP t180; LP t181; LP t182; LP t183; LP t184; LP t185; 
LP t186; LP t187; LP t188; LP t189; LP t190; LP t191; 
LP t192; LP t193; LP t194; LP t195; LP t196; LP t197; 
LP t198; LP t199; LP t200; LP t201; LP t202; LP t203; 
LP t204; LP t205; LP t206; LP t207; LP t208; LP t209; 
LP t210; LP t211; LP t212; LP t213; LP t214; LP t215; 
LP t216; LP t217; LP t218; LP t219; LP t220; LP t221; 
LP t222; LP t223; LP t224; LP t225; LP t226; LP t227; 
LP t228; LP t229; LP t230; LP t231; LP t232; LP t233; 
LP t234; LP t235; LP t236; LP t237; LP t238; LP t239; 
LP t240; LP t241; LP t242; LP t243; LP t244; LP t245; 
LP t246; LP t247; LP t248; LP t249; LP t250; LP t251; 
LP t252; LP t253; LP t254; LP t255; LP t256; LP t257; 
LP t258; LP t259; LP t260; LP t261; LP t262; LP t263; 
LP t264; LP t265; LP t266; LP t267; LP t268; LP t269; 
LP t270; LP t271; LP t272; LP t273; LP t274; LP t275; 
LP t276; LP t277; LP t278; LP t279; LP t280; LP t281; 
LP t282; LP t283; LP t284; 
if (argc != 3) wna(argc,3);
v_TEM_4 = LREF(s_lsp_NIL);
v_INCLUSIVE_3F_5 = LREF(s_lsp_NIL);
v_IPPS_6 = LREF(s_lsp_NIL);
v_EACH_3F_7 = LREF(s_lsp_NIL);
v_ATTACHMENT_8 = LREF(s_lsp_NIL);
v_G3493_16 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, v_VAL_1, LREF(s_lsp_EACH));
if (v_G3493_16 != NIL) {
t0 = v_G3493_16;
} else {
t0 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, v_VAL_1, LREF(s_lsp_THE));
}
if (t0 != NIL) {
v_EACH_3F_7 = LREF(s_lsp_T);
v_X_9 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_VAL_1 = ((LP) DEREF((v_X_9) + 0 * 4));
} else {
v_VALUE3491_11 = v_VAL_1;
v_Y_13 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_S3492_15 = (c_cons((v_VALUE3491_11), (v_Y_13)));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3492_15);
}
t2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DPATH_2DKEYWORD_2DALIST));
v_TEM_4 = ICALL(s_lsp_LOOP_2DTASSOC) (2, v_VAL_1, t2);
if (v_TEM_4 != NIL) {
v_G3513_98 = v_EACH_3F_7;
if (v_G3513_98 != NIL) {
t1 = v_G3513_98;
} else {
v_C_99 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_101 = v_C_99;
v_X_103 = ((LP) DEREF((v_C_99) + 1 * 4));
t4 = ((LP) DEREF((v_X_103) + 0 * 4));
t3 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, t4, LREF(s_lsp_AND));
t1 = ICALL(s_lsp_NOT) (1, t3);
}
} else {
t1 = LREF(s_lsp_NIL);
}
if (t1 != NIL) {
v_LIST3494_17 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_18 = v_LIST3494_17;
v_VALUE3495_20 = ((LP) DEREF((v_LIST3494_17) + 0 * 4));
v_X_21 = v_LIST3494_17;
v_S3496_23 = ((LP) DEREF((v_LIST3494_17) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3496_23);
} else {
v_X_24 = LREF(s_lsp_BEING);
v_Y_25 = LREF(s_lsp_NIL);
v_Y_28 = (c_cons((LREF(s_lsp_BEING)), (LREF(s_lsp_NIL))));
v_Y_31 = (c_cons((v_VAR_0), (v_Y_28)));
t5 = (c_cons((LREF(s_lsp_FOR)), (v_Y_31)));
v_VAL_1 = ICALL(s_lsp_LOOP_2DGET_2DFORM) (1, t5);
v_X_96 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
t7 = ((LP) DEREF((v_X_96) + 0 * 4));
t6 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, t7, LREF(s_lsp_AND));
if (t6 != NIL) {
v_G3497_33 = ICALL(s_lsp_NULL) (1, v_EACH_3F_7);
if (v_G3497_33 != NIL) {
} else {
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2309), v_VAR_0);
}
v_X_34 = v_VAL_1;
v_Y_38 = (c_cons((v_X_34), (LREF(s_lsp_NIL))));
v_X_40 = (c_cons((LREF(s_lsp_OF)), (v_Y_38)));
v_IPPS_6 = (c_cons((v_X_40), (LREF(s_lsp_NIL))));
v_INCLUSIVE_3F_5 = LREF(s_lsp_T);
v_LIST3498_43 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_44 = v_LIST3498_43;
v_VALUE3499_46 = ((LP) DEREF((v_LIST3498_43) + 0 * 4));
v_X_47 = v_LIST3498_43;
v_S3500_49 = ((LP) DEREF((v_LIST3498_43) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3500_49);
v_LIST3502_50 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_51 = v_LIST3502_50;
v_VALUE3503_53 = ((LP) DEREF((v_LIST3502_50) + 0 * 4));
v_X_54 = v_LIST3502_50;
v_S3504_56 = ((LP) DEREF((v_LIST3502_50) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3504_56);
v_TEM_4 = v_VALUE3503_53;
v_G3501_57 = ICALL(s_lsp_LOOP_2DTMEMBER) (2, v_TEM_4, LREF(k2310));
if (v_G3501_57 != NIL) {
} else {
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2315), v_TEM_4);
}
v_X_76 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
t8 = ((LP) DEREF((v_X_76) + 0 * 4));
t9 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DPATH_2DKEYWORD_2DALIST));
v_TEM_4 = ICALL(s_lsp_LOOP_2DTASSOC) (2, t8, t9);
if (v_TEM_4 != NIL) {
v_LIST3505_58 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_59 = v_LIST3505_58;
v_VALUE3506_61 = ((LP) DEREF((v_LIST3505_58) + 0 * 4));
v_X_62 = v_LIST3505_58;
v_S3507_64 = ((LP) DEREF((v_LIST3505_58) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3507_64);
} else {
t10 = ICALL(s_lsp_LIST_2A) (3, LREF(s_lsp_FOR), v_VAR_0, LREF(k2316));
v_X_65 = ICALL(s_lsp_LOOP_2DGET_2DFORM) (1, t10);
v_Y_69 = (c_cons((v_X_65), (LREF(s_lsp_NIL))));
v_ATTACHMENT_8 = (c_cons((LREF(s_lsp_IN)), (v_Y_69)));
v_VALUE3508_71 = v_ATTACHMENT_8;
v_Y_73 = v_IPPS_6;
v_S3509_75 = (c_cons((v_VALUE3508_71), (v_Y_73)));
v_IPPS_6 = v_S3509_75;
}
} else {
v_X_94 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
t11 = ((LP) DEREF((v_X_94) + 0 * 4));
t12 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DPATH_2DKEYWORD_2DALIST));
v_TEM_4 = ICALL(s_lsp_LOOP_2DTASSOC) (2, t11, t12);
if (v_TEM_4 != NIL) {
v_LIST3510_87 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_88 = v_LIST3510_87;
v_VALUE3511_90 = ((LP) DEREF((v_LIST3510_87) + 0 * 4));
v_X_91 = v_LIST3510_87;
v_S3512_93 = ((LP) DEREF((v_LIST3510_87) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3512_93);
} else {
v_X_78 = v_VAL_1;
v_Y_82 = (c_cons((v_X_78), (LREF(s_lsp_NIL))));
v_ATTACHMENT_8 = (c_cons((LREF(s_lsp_IN)), (v_Y_82)));
v_X_84 = v_ATTACHMENT_8;
v_IPPS_6 = (c_cons((v_X_84), (LREF(s_lsp_NIL))));
}
}
}
t13 = ICALL(s_lsp_NULL) (1, v_TEM_4);
v_TEST3514_105 = ICALL(s_lsp_NOT) (1, t13);
if (v_TEST3514_105 != NIL) {
} else {
t14 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DPATH_2DKEYWORD_2DALIST));
v_TEM_4 = ICALL(s_lsp_LOOP_2DTASSOC) (2, LREF(s_lsp_DEFAULT_2DLOOP_2DPATH), t14);
if (v_TEM_4 != NIL) {
} else {
v_C_106 = v_ATTACHMENT_8;
v_X_108 = v_C_106;
v_X_110 = ((LP) DEREF((v_C_106) + 1 * 4));
t15 = ((LP) DEREF((v_X_110) + 0 * 4));
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2320), t15);
}
}
v_X_112 = v_TEM_4;
t16 = ((LP) DEREF((v_X_112) + 0 * 4));
v_C_114 = v_TEM_4;
v_X_116 = v_C_114;
v_X_118 = ((LP) DEREF((v_C_114) + 1 * 4));
v_X_120 = ((LP) DEREF((v_X_118) + 1 * 4));
t19 = ((LP) DEREF((v_X_120) + 0 * 4));
t18 = ICALL(s_lsp_LOOP_2DGATHER_2DPREPS) (2, t19, LREF(s_lsp_T));
t17 = ICALL(s_lsp_NRECONC) (2, v_IPPS_6, t18);
v_C_122 = v_TEM_4;
v_X_124 = v_C_122;
v_X_126 = ((LP) DEREF((v_C_122) + 1 * 4));
v_X_128 = ((LP) DEREF((v_X_126) + 1 * 4));
t20 = ((LP) DEREF((v_X_128) + 0 * 4));
v_C_130 = v_TEM_4;
v_X_132 = v_C_130;
v_X_134 = ((LP) DEREF((v_C_130) + 1 * 4));
v_X_136 = ((LP) DEREF((v_X_134) + 1 * 4));
t21 = ((LP) DEREF((v_X_136) + 1 * 4));
v_C_138 = v_TEM_4;
v_X_140 = v_C_138;
v_X_142 = ((LP) DEREF((v_C_138) + 1 * 4));
t22 = ((LP) DEREF((v_X_142) + 0 * 4));
v_TEM_4 = CODE_PTR(COERCE_TO_FUNCTION(t22))(7, t16, v_VAR_0, v_DATA_2DTYPE_3F_2, t17, v_INCLUSIVE_3F_5, t20, t21);
t23 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DNAMED_2DVARIABLES));
if (t23 != NIL) {
t24 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DNAMED_2DVARIABLES));
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2321), t24);
}
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DNAMED_2DVARIABLES), LREF(s_lsp_NIL));
v_X_145 = v_TEM_4;
v_L_147 = ((LP) DEREF((v_X_145) + 0 * 4));
v_X_148 = LREF(s_lsp_NIL);
goto t_TEST3515_150;
t_LOOP3516_149:;
v_X_151 = v_L_147;
v_TMP3517_153 = ((LP) DEREF((v_X_151) + 1 * 4));
v_L_147 = v_TMP3517_153;
t_TEST3515_150:;
if (v_L_147 == NIL) {
goto b_NIL_144;
}
v_X_170 = v_L_147;
v_X_148 = ((LP) DEREF((v_X_170) + 0 * 4));
t25 = ICALL(s_lsp_ATOM) (1, v_X_148);
if (t25 != NIL) {
ICALL(s_lsp_LOOP_2DMAKE_2DITERATION_2DVARIABLE) (3, v_X_148, LREF(s_lsp_NIL), LREF(s_lsp_NIL));
} else {
v_X_154 = v_X_148;
t26 = ((LP) DEREF((v_X_154) + 0 * 4));
v_C_156 = v_X_148;
v_X_158 = v_C_156;
v_X_160 = ((LP) DEREF((v_C_156) + 1 * 4));
t27 = ((LP) DEREF((v_X_160) + 0 * 4));
v_C_162 = v_X_148;
v_X_164 = v_C_162;
v_X_166 = ((LP) DEREF((v_C_162) + 1 * 4));
v_X_168 = ((LP) DEREF((v_X_166) + 1 * 4));
t28 = ((LP) DEREF((v_X_168) + 0 * 4));
ICALL(s_lsp_LOOP_2DMAKE_2DITERATION_2DVARIABLE) (3, t26, t27, t28);
}
goto t_LOOP3516_149;
b_NIL_144:;
v_C_172 = v_TEM_4;
v_X_174 = v_C_172;
v_X_176 = ((LP) DEREF((v_C_172) + 1 * 4));
t31 = ((LP) DEREF((v_X_176) + 0 * 4));
t30 = ICALL(s_lsp_REVERSE) (1, t31);
t32 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DPROLOGUE));
t29 = ICALL(s_lsp_NCONC_2F2) (2, t30, t32);
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DPROLOGUE), t29);
v_C_178 = v_TEM_4;
v_X_180 = v_C_178;
v_X_182 = ((LP) DEREF((v_C_178) + 1 * 4));
t33 = ((LP) DEREF((v_X_182) + 1 * 4));
return(t33);
}

LP p_lsp_LOOP_2DGATHER_2DPREPS(argc, v_PREPS_2DALLOWED_0, v_CROCKP_1)
      ARGC argc;  LP v_PREPS_2DALLOWED_0; LP v_CROCKP_1;
{
LP v_S3540_118; LP v_X_116; LP v_VALUE3539_115; 
LP v_X_113; LP v_LIST3538_112; LP v_X_110; 
LP v_X_108; LP v_C_106; LP v_S3537_105; 
LP v_Y_103; LP v_X_102; LP v_VALUE3536_101; 
LP v_Y_99; LP v_X_98; LP v_X_96; 
LP v_X_94; LP v_C_92; LP v_X_90; 
LP v_X_88; LP v_Y_86; LP v_X_85; 
LP v_Y_83; LP v_X_82; LP v_X_80; 
LP v_X_78; LP v_C_76; LP v_X_74; 
LP v_X_72; LP v_C_70; LP v_G3535_69; 
LP v_X_67; LP v_G3534_66; LP v_X_64; 
LP v_X_62; LP v_C_60; LP v_G3533_59; 
LP v_X_57; LP v_TMP3532_56; LP v_X_54; 
LP v_TEM_51; LP v_Z_50; LP v_X_48; 
LP v_Y_45; LP v_X_44; LP v_Y_42; 
LP v_X_41; LP v_X_39; LP v_G3529_38; 
LP v_S3528_37; LP v_X_35; LP v_VALUE3527_34; 
LP v_X_32; LP v_LIST3526_31; LP v_S3525_30; 
LP v_Y_28; LP v_X_27; LP v_VALUE3521_26; 
LP v_Y_24; LP v_X_23; LP v_Y_21; 
LP v_X_20; LP v_S3524_19; LP v_X_17; 
LP v_VALUE3523_16; LP v_X_14; LP v_LIST3522_13; 
LP v_TMP3520_12; LP v_X_10; LP v_PREPS_7; 
LP v_TOKEN_6; LP v_X_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; LP t145; LP t146; LP t147; LP t148; LP t149; 
LP t150; LP t151; LP t152; LP t153; LP t154; LP t155; 
LP t156; LP t157; LP t158; LP t159; LP t160; LP t161; 
LP t162; LP t163; LP t164; LP t165; LP t166; LP t167; 
LP t168; LP t169; LP t170; LP t171; LP t172; LP t173; 
LP t174; LP t175; LP t176; LP t177; LP t178; 
if (argc != 2) wna(argc,2);
v_X_4 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_TOKEN_6 = ((LP) DEREF((v_X_4) + 0 * 4));
v_PREPS_7 = LREF(s_lsp_NIL);
goto t_TEST3518_9;
t_LOOP3519_8:;
v_X_10 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_TMP3520_12 = ((LP) DEREF((v_X_10) + 0 * 4));
v_TOKEN_6 = v_TMP3520_12;
t_TEST3518_9:;
t1 = ICALL(s_lsp_LOOP_2DTMEMBER) (2, v_TOKEN_6, v_PREPS_2DALLOWED_0);
if (t1 != NIL) {
v_LIST3522_13 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_14 = v_LIST3522_13;
v_VALUE3523_16 = ((LP) DEREF((v_LIST3522_13) + 0 * 4));
v_X_17 = v_LIST3522_13;
v_S3524_19 = ((LP) DEREF((v_LIST3522_13) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3524_19);
v_X_23 = v_VALUE3523_16;
t2 = ICALL(s_lsp_LIST) (5, LREF(s_lsp_FOR), LREF(k2318), LREF(s_lsp_BEING), LREF(k2318), v_TOKEN_6);
v_X_20 = ICALL(s_lsp_LOOP_2DGET_2DFORM) (1, t2);
v_Y_24 = (c_cons((v_X_20), (LREF(s_lsp_NIL))));
v_VALUE3521_26 = (c_cons((v_X_23), (v_Y_24)));
v_Y_28 = v_PREPS_7;
v_S3525_30 = (c_cons((v_VALUE3521_26), (v_Y_28)));
v_PREPS_7 = v_S3525_30;
} else {
t3 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, v_TOKEN_6, LREF(s_lsp_USING));
if (t3 != NIL) {
v_LIST3526_31 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_32 = v_LIST3526_31;
v_VALUE3527_34 = ((LP) DEREF((v_LIST3526_31) + 0 * 4));
v_X_35 = v_LIST3526_31;
v_S3528_37 = ((LP) DEREF((v_LIST3526_31) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3528_37);
v_G3529_38 = v_CROCKP_1;
if (v_G3529_38 != NIL) {
} else {
v_X_39 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_41 = ((LP) DEREF((v_X_39) + 0 * 4));
v_Y_45 = (c_cons((v_X_41), (LREF(s_lsp_NIL))));
t4 = (c_cons((LREF(s_lsp_USING)), (v_Y_45)));
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2322), t4);
}
v_X_48 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_Z_50 = ((LP) DEREF((v_X_48) + 0 * 4));
v_TEM_51 = LREF(s_lsp_NIL);
goto t_TEST3530_53;
t_LOOP3531_52:;
v_X_54 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_TMP3532_56 = ((LP) DEREF((v_X_54) + 0 * 4));
v_Z_50 = v_TMP3532_56;
t_TEST3530_53:;
t5 = ICALL(s_lsp_ATOM) (1, v_Z_50);
if (t5 != NIL) {
goto b_NIL_47;
}
v_X_57 = v_Z_50;
t6 = ((LP) DEREF((v_X_57) + 1 * 4));
v_G3533_59 = ICALL(s_lsp_ATOM) (1, t6);
if (v_G3533_59 != NIL) {
t7 = v_G3533_59;
} else {
v_C_60 = v_Z_50;
v_X_62 = v_C_60;
v_X_64 = ((LP) DEREF((v_C_60) + 1 * 4));
t9 = ((LP) DEREF((v_X_64) + 1 * 4));
t8 = ICALL(s_lsp_NULL) (1, t9);
v_G3534_66 = ICALL(s_lsp_NOT) (1, t8);
if (v_G3534_66 != NIL) {
t7 = v_G3534_66;
} else {
v_X_67 = v_Z_50;
t11 = ((LP) DEREF((v_X_67) + 0 * 4));
t10 = ICALL(s_lsp_SYMBOLP) (1, t11);
v_G3535_69 = ICALL(s_lsp_NOT) (1, t10);
if (v_G3535_69 != NIL) {
t7 = v_G3535_69;
} else {
v_C_76 = v_Z_50;
v_X_78 = v_C_76;
v_X_80 = ((LP) DEREF((v_C_76) + 1 * 4));
t12 = ((LP) DEREF((v_X_80) + 0 * 4));
if (t12 != NIL) {
v_C_70 = v_Z_50;
v_X_72 = v_C_70;
v_X_74 = ((LP) DEREF((v_C_70) + 1 * 4));
t14 = ((LP) DEREF((v_X_74) + 0 * 4));
t13 = ICALL(s_lsp_SYMBOLP) (1, t14);
t7 = ICALL(s_lsp_NOT) (1, t13);
} else {
t7 = LREF(s_lsp_NIL);
}
}
}
}
if (t7 != NIL) {
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2323), v_Z_50);
}
v_C_106 = v_Z_50;
v_X_108 = v_C_106;
v_X_110 = ((LP) DEREF((v_C_106) + 1 * 4));
t16 = ((LP) DEREF((v_X_110) + 0 * 4));
t15 = ICALL(s_lsp_NULL) (1, t16);
if (t15 == NIL) {
v_X_88 = v_Z_50;
t17 = ((LP) DEREF((v_X_88) + 0 * 4));
t18 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DNAMED_2DVARIABLES));
v_TEM_51 = ICALL(s_lsp_LOOP_2DTASSOC) (2, t17, t18);
if (v_TEM_51 != NIL) {
v_X_85 = v_TEM_51;
v_X_82 = v_Z_50;
v_Y_86 = (c_cons((v_X_82), (LREF(s_lsp_NIL))));
t19 = (c_cons((v_X_85), (v_Y_86)));
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2324), t19);
}
v_X_90 = v_Z_50;
v_X_98 = ((LP) DEREF((v_X_90) + 0 * 4));
v_C_92 = v_Z_50;
v_X_94 = v_C_92;
v_X_96 = ((LP) DEREF((v_C_92) + 1 * 4));
v_Y_99 = ((LP) DEREF((v_X_96) + 0 * 4));
v_VALUE3536_101 = (c_cons((v_X_98), (v_Y_99)));
v_Y_103 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DNAMED_2DVARIABLES));
v_S3537_105 = (c_cons((v_VALUE3536_101), (v_Y_103)));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DNAMED_2DVARIABLES), v_S3537_105);
}
v_LIST3538_112 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DSOURCE_2DCODE));
v_X_113 = v_LIST3538_112;
v_VALUE3539_115 = ((LP) DEREF((v_LIST3538_112) + 0 * 4));
v_X_116 = v_LIST3538_112;
v_S3540_118 = ((LP) DEREF((v_LIST3538_112) + 1 * 4));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DSOURCE_2DCODE), v_S3540_118);
goto t_LOOP3531_52;
b_NIL_47:;
} else {
t20 = ICALL(s_lsp_NREVERSE) (MV_CALL(argc,1), v_PREPS_7);
return(t20);
return(NIL);
}
}
goto t_LOOP3519_8;
return(NIL);
}

LP p_lsp_LOOP_2DADD_2DPATH(argc, v_NAME_0, v_DATA_1)
      ARGC argc;  LP v_NAME_0; LP v_DATA_1;
{
LP v_Y_7; LP v_X_6; LP v_Y_4; 
LP v_X_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; 
if (argc != 2) wna(argc,2);
v_X_3 = v_NAME_0;
v_Y_4 = v_DATA_1;
v_X_6 = (c_cons((v_NAME_0), (v_DATA_1)));
t1 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DPATH_2DKEYWORD_2DALIST));
t0 = ICALL(s_lsp_LOOP_2DTASSOC) (2, v_NAME_0, t1);
t2 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DPATH_2DKEYWORD_2DALIST));
t3 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DFUNCTION) (1, LREF(s_lsp_EQ));
v_Y_7 = ICALL(s_lsp_DELETE) (4, t0, t2, LREF(s_key_TEST), t3);
t4 = (c_cons((v_X_6), (v_Y_7)));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DPATH_2DKEYWORD_2DALIST), t4);
return(LREF(s_lsp_NIL));
}

LP p_lsp_LOOP_2DSEQUENCER(argc, v_INDEXV_0, v_INDEXV_2DTYPE_1, v_VARIABLE_3F_2, v_VTYPE_3F_3, v_SEQUENCEV_3F_4, v_SEQUENCE_2DTYPE_3F_5, v_STEPHACK_3F_6, v_DEFAULT_2DTOP_3F_7, v_CRAP_8, v_PREP_2DPHRASES_9)
      ARGC argc;  LP v_INDEXV_0; LP v_INDEXV_2DTYPE_1; LP v_VARIABLE_3F_2; LP v_VTYPE_3F_3; LP v_SEQUENCEV_3F_4; LP v_SEQUENCE_2DTYPE_3F_5; LP v_STEPHACK_3F_6; LP v_DEFAULT_2DTOP_3F_7; LP v_CRAP_8; LP v_PREP_2DPHRASES_9;
{
LP v_Y_129; LP v_X_128; LP v_Y_126; 
LP v_X_125; LP v_Y_123; LP v_X_122; 
LP v_Y_120; LP v_X_119; LP v_Y_117; 
LP v_X_116; LP v_Y_114; LP v_X_113; 
LP v_V_111; LP v_X_110; LP v_NEW_2DCAR_108; 
LP v_C_107; LP v_X_105; LP v_S3555_104; 
LP v_Y_102; LP v_X_101; LP v_VALUE3554_100; 
LP v_S3553_99; LP v_Y_97; LP v_X_96; 
LP v_VALUE3552_95; LP v_Y_93; LP v_X_92; 
LP v_Y_90; LP v_X_89; LP v_Y_87; 
LP v_X_86; LP v_Y_84; LP v_X_83; 
LP v_Y_81; LP v_X_80; LP v_G3551_79; 
LP v_S3550_78; LP v_Y_76; LP v_X_75; 
LP v_VALUE3549_74; LP v_S3548_73; LP v_Y_71; 
LP v_X_70; LP v_VALUE3547_69; LP v_Y_67; 
LP v_X_66; LP v_Y_64; LP v_X_63; 
LP v_Y_61; LP v_X_60; LP v_G3546_59; 
LP v_G3545_58; LP v_Y_56; LP v_X_55; 
LP v_Y_53; LP v_X_52; LP v_Y_50; 
LP v_X_49; LP v_Y_47; LP v_X_46; 
LP v_X_44; LP v_X_42; LP v_X_40; 
LP v_X_38; LP v_C_36; LP v_X_34; 
LP v_X_32; LP v_C_30; LP v_TMP3544_29; 
LP v_X_27; LP v_ODIR_24; LP v_FORM_23; 
LP v_PREP_22; LP v_L_21; LP v_LIMIT_2DGIVEN_3F_19; 
LP v_START_2DGIVEN_3F_18; LP v_INCLUSIVE_2DITERATION_3F_17; LP v_DIR_16; 
LP v_STEP_15; LP v_TEST_14; LP v_SEQUENCEP_13; 
LP v_ENDFORM_12; LP v_G3541_11; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; LP t145; LP t146; LP t147; LP t148; LP t149; 
LP t150; LP t151; LP t152; LP t153; LP t154; LP t155; 
LP t156; LP t157; LP t158; LP t159; LP t160; LP t161; 
LP t162; LP t163; LP t164; LP t165; LP t166; LP t167; 
LP t168; LP t169; LP t170; LP t171; LP t172; LP t173; 
LP t174; LP t175; LP t176; LP t177; LP t178; LP t179; 
LP t180; LP t181; LP t182; LP t183; LP t184; LP t185; 
LP t186; LP t187; LP t188; LP t189; LP t190; LP t191; 
LP t192; LP t193; LP t194; 
if (argc != 10) wna(argc,10);
v_ENDFORM_12 = LREF(s_lsp_NIL);
v_SEQUENCEP_13 = LREF(s_lsp_NIL);
v_TEST_14 = LREF(s_lsp_NIL);
v_G3541_11 = ICALL(s_lsp_LOOP_2DTYPED_2DINIT) (1, v_INDEXV_2DTYPE_1);
if (v_G3541_11 != NIL) {
t0 = v_G3541_11;
} else {
t0 = (LP) 0;
}
v_STEP_15 = ICALL(s_lsp_1_2B) (1, t0);
v_DIR_16 = LREF(s_lsp_NIL);
v_INCLUSIVE_2DITERATION_3F_17 = LREF(s_lsp_NIL);
v_START_2DGIVEN_3F_18 = LREF(s_lsp_NIL);
v_LIMIT_2DGIVEN_3F_19 = LREF(s_lsp_NIL);
if (v_VARIABLE_3F_2 != NIL) {
ICALL(s_lsp_LOOP_2DMAKE_2DITERATION_2DVARIABLE) (3, v_VARIABLE_3F_2, LREF(s_lsp_NIL), v_VTYPE_3F_3);
}
v_L_21 = v_PREP_2DPHRASES_9;
v_PREP_22 = LREF(s_lsp_NIL);
v_FORM_23 = LREF(s_lsp_NIL);
v_ODIR_24 = LREF(s_lsp_NIL);
goto t_TEST3542_26;
t_LOOP3543_25:;
v_X_27 = v_L_21;
v_TMP3544_29 = ((LP) DEREF((v_X_27) + 1 * 4));
v_L_21 = v_TMP3544_29;
t_TEST3542_26:;
if (v_L_21 == NIL) {
goto b_NIL_20;
}
v_C_30 = v_L_21;
v_X_32 = v_C_30;
v_X_34 = ((LP) DEREF((v_C_30) + 0 * 4));
v_PREP_22 = ((LP) DEREF((v_X_34) + 0 * 4));
v_C_36 = v_L_21;
v_X_38 = v_C_36;
v_X_40 = ((LP) DEREF((v_C_36) + 0 * 4));
v_X_42 = ((LP) DEREF((v_X_40) + 1 * 4));
v_FORM_23 = ((LP) DEREF((v_X_42) + 0 * 4));
t1 = ICALL(s_lsp_LOOP_2DTMEMBER) (2, v_PREP_22, LREF(k2325));
if (t1 != NIL) {
if (v_SEQUENCEP_13 != NIL) {
v_X_44 = v_L_21;
v_X_46 = ((LP) DEREF((v_X_44) + 0 * 4));
v_Y_50 = (c_cons((v_X_46), (LREF(s_lsp_NIL))));
t2 = (c_cons((v_VARIABLE_3F_2), (v_Y_50)));
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2326), t2);
}
v_SEQUENCEP_13 = LREF(s_lsp_T);
ICALL(s_lsp_LOOP_2DMAKE_2DVARIABLE) (3, v_SEQUENCEV_3F_4, v_FORM_23, v_SEQUENCE_2DTYPE_3F_5);
} else {
t3 = ICALL(s_lsp_LOOP_2DTMEMBER) (2, v_PREP_22, LREF(k2327));
if (t3 != NIL) {
if (v_START_2DGIVEN_3F_18 != NIL) {
t4 = ICALL(s_lsp_APPEND_2F2) (2, v_CRAP_8, v_L_21);
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2330), t4);
}
v_START_2DGIVEN_3F_18 = LREF(s_lsp_T);
t5 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, v_PREP_22, LREF(s_lsp_DOWNFROM));
if (t5 != NIL) {
v_DIR_16 = LREF(s_lsp_DOWN);
} else {
t6 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, v_PREP_22, LREF(s_lsp_UPFROM));
if (t6 != NIL) {
v_DIR_16 = LREF(s_lsp_UP);
}
}
ICALL(s_lsp_LOOP_2DMAKE_2DITERATION_2DVARIABLE) (3, v_INDEXV_0, v_FORM_23, v_INDEXV_2DTYPE_1);
} else {
t8 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, v_PREP_22, LREF(s_lsp_UPTO));
if (t8 != NIL) {
v_DIR_16 = LREF(s_lsp_UP);
v_INCLUSIVE_2DITERATION_3F_17 = v_DIR_16;
t7 = v_INCLUSIVE_2DITERATION_3F_17;
} else {
t9 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, v_PREP_22, LREF(s_lsp_TO));
if (t9 != NIL) {
v_INCLUSIVE_2DITERATION_3F_17 = LREF(s_lsp_T);
t7 = v_INCLUSIVE_2DITERATION_3F_17;
} else {
t10 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, v_PREP_22, LREF(s_lsp_DOWNTO));
if (t10 != NIL) {
v_DIR_16 = LREF(s_lsp_DOWN);
v_INCLUSIVE_2DITERATION_3F_17 = v_DIR_16;
t7 = v_INCLUSIVE_2DITERATION_3F_17;
} else {
t11 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, v_PREP_22, LREF(s_lsp_ABOVE));
if (t11 != NIL) {
v_DIR_16 = LREF(s_lsp_DOWN);
t7 = v_DIR_16;
} else {
t12 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, v_PREP_22, LREF(s_lsp_BELOW));
if (t12 != NIL) {
v_DIR_16 = LREF(s_lsp_UP);
t7 = v_DIR_16;
} else {
t7 = LREF(s_lsp_NIL);
}
}
}
}
}
if (t7 != NIL) {
if (v_LIMIT_2DGIVEN_3F_19 != NIL) {
t13 = ICALL(s_lsp_APPEND_2F2) (2, v_CRAP_8, v_L_21);
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2331), t13);
}
v_LIMIT_2DGIVEN_3F_19 = LREF(s_lsp_T);
v_ENDFORM_12 = ICALL(s_lsp_LOOP_2DMAYBE_2DBIND_2DFORM) (2, v_FORM_23, v_INDEXV_2DTYPE_1);
} else {
t14 = ICALL(s_lsp_LOOP_2DTEQUAL) (2, v_PREP_22, LREF(s_lsp_BY));
if (t14 != NIL) {
t15 = ICALL(s_lsp_LOOP_2DCONSTANTP) (1, v_FORM_23);
if (t15 != NIL) {
v_STEP_15 = v_FORM_23;
} else {
t17 = ICALL(s_lsp_SYMBOL_2DNAME) (1, LREF(s_lsp_LOOP_2DSTEP_2DBY_2D));
t16 = ICALL(s_lsp_GENTEMP) (1, t17);
v_STEP_15 = ICALL(s_lsp_LOOP_2DMAKE_2DVARIABLE) (3, t16, v_FORM_23, LREF(s_lsp_FIXNUM));
}
} else {
t18 = ICALL(s_lsp_APPEND_2F2) (2, v_CRAP_8, v_L_21);
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2332), t18);
}
}
}
}
if (v_ODIR_24 != NIL) {
if (v_DIR_16 != NIL) {
t19 = ICALL(s_lsp_EQ) (2, v_DIR_16, v_ODIR_24);
if (t19 == NIL) {
t20 = ICALL(s_lsp_APPEND_2F2) (2, v_CRAP_8, v_L_21);
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2333), t20);
}
}
}
v_ODIR_24 = v_DIR_16;
goto t_LOOP3543_25;
b_NIL_20:;
if (v_SEQUENCEV_3F_4 != NIL) {
if (v_SEQUENCEP_13 == NIL) {
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2334), v_CRAP_8);
}
}
v_X_52 = v_STEP_15;
v_Y_56 = (c_cons((v_X_52), (LREF(s_lsp_NIL))));
v_STEP_15 = (c_cons((v_INDEXV_0), (v_Y_56)));
t21 = ICALL(s_lsp_MEMQL) (2, v_DIR_16, LREF(k2335));
if (t21 != NIL) {
v_G3545_58 = v_START_2DGIVEN_3F_18;
if (v_G3545_58 != NIL) {
} else {
ICALL(s_lsp_LOOP_2DMAKE_2DITERATION_2DVARIABLE) (3, v_INDEXV_0, (LP) 0, v_INDEXV_2DTYPE_1);
}
v_G3546_59 = v_LIMIT_2DGIVEN_3F_19;
if (v_G3546_59 != NIL) {
t22 = v_G3546_59;
} else {
if (v_DEFAULT_2DTOP_3F_7 != NIL) {
t23 = ICALL(s_lsp_SYMBOL_2DNAME) (1, LREF(s_lsp_LOOP_2DSEQ_2DLIMIT_2D));
v_ENDFORM_12 = ICALL(s_lsp_GENTEMP) (1, t23);
ICALL(s_lsp_LOOP_2DMAKE_2DVARIABLE) (3, v_ENDFORM_12, LREF(s_lsp_NIL), v_INDEXV_2DTYPE_1);
v_X_63 = v_ENDFORM_12;
v_X_60 = v_DEFAULT_2DTOP_3F_7;
v_Y_61 = LREF(s_lsp_NIL);
v_Y_64 = (c_cons((v_DEFAULT_2DTOP_3F_7), (LREF(s_lsp_NIL))));
v_Y_67 = (c_cons((v_X_63), (v_Y_64)));
v_VALUE3547_69 = (c_cons((LREF(s_lsp_SETQ)), (v_Y_67)));
v_Y_71 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DPROLOGUE));
v_S3548_73 = (c_cons((v_VALUE3547_69), (v_Y_71)));
t22 = ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DPROLOGUE), v_S3548_73);
} else {
t22 = LREF(s_lsp_NIL);
}
}
if (t22 != NIL) {
if (v_INCLUSIVE_2DITERATION_3F_17 != NIL) {
v_TEST_14 = LREF(k2337);
} else {
v_TEST_14 = LREF(k2338);
}
}
v_VALUE3549_74 = LREF(s_lsp__2B);
v_Y_76 = v_STEP_15;
v_S3550_78 = (c_cons((LREF(s_lsp__2B)), (v_Y_76)));
v_STEP_15 = v_S3550_78;
} else {
if (v_START_2DGIVEN_3F_18 == NIL) {
v_G3551_79 = v_DEFAULT_2DTOP_3F_7;
if (v_G3551_79 != NIL) {
} else {
t24 = ICALL(s_lsp_APPEND_2F2) (2, v_CRAP_8, v_PREP_2DPHRASES_9);
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2339), t24);
}
ICALL(s_lsp_LOOP_2DMAKE_2DITERATION_2DVARIABLE) (3, v_INDEXV_0, (LP) 0, v_INDEXV_2DTYPE_1);
v_X_83 = ICALL(s_lsp_LOOP_2DTYPED_2DARITH) (2, LREF(s_lsp_1_2D), v_INDEXV_2DTYPE_1);
v_X_80 = v_DEFAULT_2DTOP_3F_7;
v_Y_81 = LREF(s_lsp_NIL);
v_Y_84 = (c_cons((v_DEFAULT_2DTOP_3F_7), (LREF(s_lsp_NIL))));
v_X_86 = (c_cons((v_X_83), (v_Y_84)));
v_Y_90 = (c_cons((v_X_86), (LREF(s_lsp_NIL))));
v_Y_93 = (c_cons((v_INDEXV_0), (v_Y_90)));
v_VALUE3552_95 = (c_cons((LREF(s_lsp_SETQ)), (v_Y_93)));
v_Y_97 = ICALL(s_lsp_UNSAFE_2DSYMBOL_2DVALUE) (1, LREF(s_lsp_LOOP_2DPROLOGUE));
v_S3553_99 = (c_cons((v_VALUE3552_95), (v_Y_97)));
ICALL(s_lsp_SET) (2, LREF(s_lsp_LOOP_2DPROLOGUE), v_S3553_99);
}
if (v_DEFAULT_2DTOP_3F_7 != NIL) {
t25 = ICALL(s_lsp_NOT) (1, v_ENDFORM_12);
} else {
t25 = LREF(s_lsp_NIL);
}
if (t25 != NIL) {
v_ENDFORM_12 = ICALL(s_lsp_LOOP_2DTYPED_2DINIT) (1, v_INDEXV_2DTYPE_1);
v_INCLUSIVE_2DITERATION_3F_17 = LREF(s_lsp_T);
}
t26 = ICALL(s_lsp_NULL) (1, v_ENDFORM_12);
if (t26 == NIL) {
if (v_INCLUSIVE_2DITERATION_3F_17 != NIL) {
v_TEST_14 = LREF(k2340);
} else {
v_TEST_14 = LREF(k2341);
}
}
v_VALUE3554_100 = LREF(s_lsp__2D);
v_Y_102 = v_STEP_15;
v_S3555_104 = (c_cons((LREF(s_lsp__2D)), (v_Y_102)));
v_STEP_15 = v_S3555_104;
}
v_C_107 = v_STEP_15;
v_X_105 = v_STEP_15;
t27 = ((LP) DEREF((v_X_105) + 0 * 4));
v_NEW_2DCAR_108 = ICALL(s_lsp_LOOP_2DTYPED_2DARITH) (2, t27, v_INDEXV_2DTYPE_1);
v_V_111 = v_NEW_2DCAR_108;
((LP) (DEREF((v_C_107) + 0 * 4) = (LD) (v_V_111)));
v_X_113 = v_STEP_15;
v_Y_117 = (c_cons((v_X_113), (LREF(s_lsp_NIL))));
v_STEP_15 = (c_cons((v_INDEXV_0), (v_Y_117)));
v_TEST_14 = ICALL(s_lsp_LOOP_2DTYPED_2DARITH) (2, v_TEST_14, v_INDEXV_2DTYPE_1);
v_X_119 = v_ENDFORM_12;
v_Y_123 = (c_cons((v_X_119), (LREF(s_lsp_NIL))));
t28 = (c_cons((v_INDEXV_0), (v_Y_123)));
v_TEST_14 = ICALL(s_lsp_SUBST) (3, t28, LREF(s_lsp_ARGS), v_TEST_14);
if (v_STEPHACK_3F_6 != NIL) {
v_X_125 = v_STEPHACK_3F_6;
v_Y_129 = (c_cons((v_X_125), (LREF(s_lsp_NIL))));
v_STEPHACK_3F_6 = (c_cons((v_VARIABLE_3F_2), (v_Y_129)));
}
t29 = ICALL(s_lsp_LIST) (MV_CALL(argc,8), LREF(s_lsp_NIL), v_STEP_15, v_TEST_14, v_STEPHACK_3F_6, LREF(s_lsp_NIL), LREF(s_lsp_NIL), v_TEST_14, v_STEPHACK_3F_6);
return(t29);
}

LP p_lsp_LOOP_2DSEQUENCE_2DELEMENTS_2DPATH(argc, v_PATH_0, v_VARIABLE_1, v_DATA_2DTYPE_2, v_PREP_2DPHRASES_3, v_INCLUSIVE_3F_4, v_ALLOWED_2DPREPS_5, v_DATA_6)
      ARGC argc;  LP v_PATH_0; LP v_VARIABLE_1; LP v_DATA_2DTYPE_2; LP v_PREP_2DPHRASES_3; LP v_INCLUSIVE_3F_4; LP v_ALLOWED_2DPREPS_5; LP v_DATA_6;
{
LP v_Y_65; LP v_X_64; LP v_Y_62; 
LP v_X_61; LP v_Y_59; LP v_X_58; 
LP v_Y_56; LP v_X_55; LP v_Y_53; 
LP v_X_52; LP v_G3556_51; LP v_X_49; 
LP v_X_47; LP v_C_45; LP v_X_43; 
LP v_X_41; LP v_X_39; LP v_X_37; 
LP v_X_35; LP v_V_33; LP v_X_32; 
LP v_NEW_2DCDR_30; LP v_C_29; LP v_X_27; 
LP v_X_25; LP v_X_23; LP v_C_21; 
LP v_X_19; LP v_X_17; LP v_C_15; 
LP v_CRAP_14; LP v_DEFAULT_2DVAR_2DTYPE_13; LP v_TYPE_12; 
LP v_SIZEFUN_11; LP v_FETCHFUN_10; LP v_SEQUENCEV_9; 
LP v_INDEXV_8; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; 
if (argc != 7) wna(argc,7);
v_INDEXV_8 = ICALL(s_lsp_LOOP_2DNAMED_2DVARIABLE) (1, LREF(s_lsp_INDEX));
v_SEQUENCEV_9 = ICALL(s_lsp_LOOP_2DNAMED_2DVARIABLE) (1, LREF(s_lsp_SEQUENCE));
v_FETCHFUN_10 = LREF(s_lsp_NIL);
v_SIZEFUN_11 = LREF(s_lsp_NIL);
v_TYPE_12 = LREF(s_lsp_NIL);
v_DEFAULT_2DVAR_2DTYPE_13 = LREF(s_lsp_NIL);
v_CRAP_14 = ICALL(s_lsp_LIST) (5, LREF(s_lsp_FOR), v_VARIABLE_1, LREF(s_lsp_BEING), LREF(s_lsp_THE), v_PATH_0);
t0 = ICALL(s_lsp_NULL) (1, v_INCLUSIVE_3F_4);
if (t0 == NIL) {
v_C_15 = v_CRAP_14;
v_X_17 = v_CRAP_14;
v_X_19 = ((LP) DEREF((v_CRAP_14) + 1 * 4));
v_C_29 = ((LP) DEREF((v_X_19) + 1 * 4));
v_C_21 = v_PREP_2DPHRASES_3;
v_X_23 = v_PREP_2DPHRASES_3;
v_X_25 = ((LP) DEREF((v_PREP_2DPHRASES_3) + 0 * 4));
v_X_27 = ((LP) DEREF((v_X_25) + 1 * 4));
t1 = ((LP) DEREF((v_X_27) + 0 * 4));
v_NEW_2DCDR_30 = ICALL(s_lsp_LIST) (4, t1, LREF(s_lsp_AND), LREF(s_lsp_ITS), v_PATH_0);
v_V_33 = v_NEW_2DCDR_30;
((LP) (DEREF((v_C_29) + 1 * 4) = (LD) (v_V_33)));
ICALL(s_lsp_ERROR) (3, LREF(k2204), LREF(k2342), v_CRAP_14);
}
v_X_35 = v_DATA_6;
v_FETCHFUN_10 = ((LP) DEREF((v_X_35) + 0 * 4));
v_X_37 = v_DATA_6;
v_DATA_6 = ((LP) DEREF((v_X_37) + 1 * 4));
v_X_39 = v_DATA_6;
v_SIZEFUN_11 = ((LP) DEREF((v_X_39) + 0 * 4));
v_X_41 = v_DATA_6;
v_DATA_6 = ((LP) DEREF((v_X_41) + 1 * 4));
v_X_43 = v_DATA_6;
v_TYPE_12 = ((LP) DEREF((v_X_43) + 0 * 4));
v_C_45 = v_DATA_6;
v_X_47 = v_C_45;
v_X_49 = ((LP) DEREF((v_C_45) + 1 * 4));
v_DEFAULT_2DVAR_2DTYPE_13 = ((LP) DEREF((v_X_49) + 0 * 4));
v_G3556_51 = v_DATA_2DTYPE_2;
if (v_G3556_51 != NIL) {
t4 = v_G3556_51;
} else {
t4 = v_DEFAULT_2DVAR_2DTYPE_13;
}
v_X_58 = v_FETCHFUN_10;
v_X_52 = v_INDEXV_8;
v_Y_53 = LREF(s_lsp_NIL);
v_Y_56 = (c_cons((v_INDEXV_8), (LREF(s_lsp_NIL))));
v_Y_59 = (c_cons((v_SEQUENCEV_9), (v_Y_56)));
t5 = (c_cons((v_X_58), (v_Y_59)));
v_X_64 = v_SIZEFUN_11;
v_X_61 = v_SEQUENCEV_9;
v_Y_62 = LREF(s_lsp_NIL);
v_Y_65 = (c_cons((v_SEQUENCEV_9), (LREF(s_lsp_NIL))));
t6 = (c_cons((v_X_64), (v_Y_65)));
t3 = ICALL(s_lsp_LOOP_2DSEQUENCER) (10, v_INDEXV_8, LREF(s_lsp_FIXNUM), v_VARIABLE_1, t4, v_SEQUENCEV_9, v_TYPE_12, t5, t6, v_CRAP_14, v_PREP_2DPHRASES_3);
t2 = ICALL(s_lsp_LIST_2A) (MV_CALL(argc,3), LREF(s_lsp_NIL), LREF(s_lsp_NIL), t3);
return(t2);
}

LP p_lsp_INITIAL_2DVALUE(argc, v_X_0)
      ARGC argc;  LP v_X_0;
{

LP t0; 
if (argc != 1) wna(argc,1);
return(LREF(s_lsp_NIL));
}

LP p_lsp_VARIABLE_2DDECLARATIONS(va_alist) va_dcl
{
LP v_TYPE_0; LP v_VARS_1; 
LP t0; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_TYPE_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
RESTIFY(v_VARS_1,2,NEXT_VAR_ARG);
END_VAR_ARGS;
return(LREF(s_lsp_NIL));
}

