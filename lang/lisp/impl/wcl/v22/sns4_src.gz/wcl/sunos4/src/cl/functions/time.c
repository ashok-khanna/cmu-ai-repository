/*
:comment "Compiled at 4:21:19 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: Debug Library"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O2 -fPIC"
:version 0
:end-package-info 0
:sym GET-UNIVERSAL-TIME
:sym DECODE-UNIVERSAL-TIME
:sf GET-DECODED-TIME "p_lsp_GET_2DDECODED_2DTIME"
:sf GET-INTERNAL-REAL-TIME "p_lsp_GET_2DINTERNAL_2DREAL_2DTIME"
:sf GET-INTERNAL-RUN-TIME "p_lsp_GET_2DINTERNAL_2DRUN_2DTIME"
:sf GET-UNIVERSAL-TIME "p_lsp_GET_2DUNIVERSAL_2DTIME"
:sym GC-CALL-COUNT
:sym GET-INTERNAL-REAL-TIME
:sym T
:sym FORMAT
:sym VALUES-LIST
:sf PRINT-RUNTIME-STATISTICS "p_lsp_PRINT_2DRUNTIME_2DSTATISTICS"
:sf TIME-ZONE "p_lsp_TIME_2DZONE"
:sf UNIX->UNIVERSAL-TIME "p_lsp_UNIX_2D_3EUNIVERSAL_2DTIME"
:sym APRIL-1
:sym NIL
:sym EQ
:sym OCTOBER-31
:sym NOT
:sf DST-CHECK "p_lsp_DST_2DCHECK"
:sym TIME-ZONE
:sym SECONDS-IN-WEEK
:sym TRUNCATE/2
:sym MINUTES-PER-DAY
:sym MOD
:sym QUARTER-DAYS-PER-YEAR
:sym DST-CHECK
:sf DECODE-UNIVERSAL-TIME "p_lsp_DECODE_2DUNIVERSAL_2DTIME"
:sf MAKE-UNIVERSAL-TIME "p_lsp_MAKE_2DUNIVERSAL_2DTIME"
:sym GET-DECODED-TIME
:sym ABS
:sym MAKE-UNIVERSAL-TIME
:sf ENCODE-UNIVERSAL-TIME "p_lsp_ENCODE_2DUNIVERSAL_2DTIME"
:pinfo TIME-ZONE NIL NIL NIL NIL NIL NIL NIL T
:pinfo GET-INTERNAL-RUN-TIME NIL NIL NIL NIL NIL NIL NIL T
:pinfo GET-DECODED-TIME NIL NIL NIL NIL NIL NIL NIL T
:pinfo GET-UNIVERSAL-TIME NIL NIL NIL NIL NIL NIL NIL T
:pinfo DECODE-UNIVERSAL-TIME (UNIVERSAL-TIME &OPTIONAL (TIME-ZONE (TIME-ZONE))) NIL NIL NIL NIL NIL NIL T
:pinfo MAKE-UNIVERSAL-TIME (WEEKS MSEC) NIL NIL NIL NIL NIL NIL T
:pinfo ENCODE-UNIVERSAL-TIME (SECOND MINUTE HOUR DATE MONTH YEAR &OPTIONAL (TIME-ZONE (TIME-ZONE))) NIL NIL NIL NIL NIL NIL T
:pinfo GET-INTERNAL-REAL-TIME NIL NIL NIL NIL NIL NIL NIL T
:pinfo DST-CHECK (DAY HOUR WEEKDAY) NIL NIL NIL NIL NIL NIL T
:pinfo PRINT-RUNTIME-STATISTICS (FORM) NIL NIL NIL NIL NIL NIL T
:pinfo UNIX->UNIVERSAL-TIME (TIME) NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_lsp_GET_2DDECODED_2DTIME();
extern SYMBOL s_lsp_GET_2DUNIVERSAL_2DTIME; 
extern SYMBOL s_lsp_DECODE_2DUNIVERSAL_2DTIME; 
extern LP p_lsp_GET_2DINTERNAL_2DREAL_2DTIME();
extern LP p_lsp_GET_2DINTERNAL_2DRUN_2DTIME();
extern LP p_lsp_GET_2DUNIVERSAL_2DTIME();
static struct {unsigned long header; unsigned long len; int sign; unsigned long digits[1];} k3704 = 
{0xC01, 1, 1, {0x83AA7E80}};
extern LP p_lsp_PRINT_2DRUNTIME_2DSTATISTICS();
extern SYMBOL s_lsp_GC_2DCALL_2DCOUNT; 
extern SYMBOL s_lsp_GET_2DINTERNAL_2DREAL_2DTIME; 
MAKE_FLOAT(k3706,100.0);
extern SYMBOL s_lsp_T; 
MAKE_SIMPLE_STRING(k3707,22,"~&User run time = ~A~%");
extern SYMBOL s_lsp_FORMAT; 
MAKE_SIMPLE_STRING(k3708,22,"System run time = ~A~%");
MAKE_SIMPLE_STRING(k3709,21,"Total run time = ~A~%");
MAKE_SIMPLE_STRING(k3710,24,"Elapsed real time = ~A~%");
MAKE_SIMPLE_STRING(k3711,25,"~D Garbage Collection~P~%");
extern SYMBOL s_lsp_VALUES_2DLIST; 
extern LP p_lsp_TIME_2DZONE();
extern LP p_lsp_UNIX_2D_3EUNIVERSAL_2DTIME();
extern LP p_lsp_DST_2DCHECK();
extern SYMBOL s_lsp_APRIL_2D1; 
extern SYMBOL s_lsp_NIL; 
extern SYMBOL s_lsp_EQ; 
extern SYMBOL s_lsp_OCTOBER_2D31; 
extern SYMBOL s_lsp_NOT; 
extern LP p_lsp_DECODE_2DUNIVERSAL_2DTIME();
extern SYMBOL s_lsp_TIME_2DZONE; 
extern SYMBOL s_lsp_SECONDS_2DIN_2DWEEK; 
extern SYMBOL s_lsp_TRUNCATE_2F2; 
extern SYMBOL s_lsp_MINUTES_2DPER_2DDAY; 
extern SYMBOL s_lsp_MOD; 
extern SYMBOL s_lsp_QUARTER_2DDAYS_2DPER_2DYEAR; 
extern SYMBOL s_lsp_DST_2DCHECK; 
extern LP p_lsp_MAKE_2DUNIVERSAL_2DTIME();
extern LP p_lsp_ENCODE_2DUNIVERSAL_2DTIME();
extern SYMBOL s_lsp_GET_2DDECODED_2DTIME; 
extern SYMBOL s_lsp_ABS; 
extern SYMBOL s_lsp_MAKE_2DUNIVERSAL_2DTIME; 


extern LP leq_p();
extern LP greaterp();
extern LP geq_p();
extern LP lessp();
extern LP multiply();
extern int unix_timezone();
extern LP divide();
extern LP subtract();
extern int internal_system_run_time();
extern LP add();
extern int unix_time_of_day();
extern int internal_user_run_time();
extern int internal_real_time();


LP p_lsp_GET_2DDECODED_2DTIME(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 0) wna(argc,0);
t1 = ICALL(s_lsp_GET_2DUNIVERSAL_2DTIME) (0);
t0 = ICALL(s_lsp_DECODE_2DUNIVERSAL_2DTIME) (MV_CALL(argc,1), t1);
return(t0);
}

LP p_lsp_GET_2DINTERNAL_2DREAL_2DTIME(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
t0 = INT_TO_FX(internal_real_time());
return(t0);
}

LP p_lsp_GET_2DINTERNAL_2DRUN_2DTIME(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
t0 = INT_TO_FX(internal_user_run_time());
return(t0);
}

LP p_lsp_GET_2DUNIVERSAL_2DTIME(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 

if (argc != 0) wna(argc,0);
t1 = INT_TO_FX(unix_time_of_day());
t0 = (add((t1), (LREF(k3704))));
return(t0);
}

LP p_lsp_PRINT_2DRUNTIME_2DSTATISTICS(argc, v_FORM_0)
      ARGC argc;  LP v_FORM_0;
{
LP v_GC_2DCOUNT_10; LP v_ELAPSED_2DREAL_9; LP v_ELAPSED_2DSYSTEM_8; 
LP v_ELAPSED_2DUSER_7; LP v_MV5293_6; LP v_SYSTEM_2DSTART_5; 
LP v_USER_2DSTART_4; LP v_REAL_2DSTART_3; LP v_START_2DGC_2DCOUNT_2; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 

if (argc != 1) wna(argc,1);
v_START_2DGC_2DCOUNT_2 = ICALL(s_lsp_GC_2DCALL_2DCOUNT) (0);
v_REAL_2DSTART_3 = ICALL(s_lsp_GET_2DINTERNAL_2DREAL_2DTIME) (0);
v_USER_2DSTART_4 = INT_TO_FX(internal_user_run_time());
v_SYSTEM_2DSTART_5 = INT_TO_FX(internal_system_run_time());
{
int real_argc;
BEGIN_MV_CALL(mv_holder3705,0);
t0 = CODE_PTR(COERCE_TO_FUNCTION(v_FORM_0))(MV_CALL(mv_holder3705,0));
SET_MV_RETURN_VALUE(mv_holder3705,0,t0);
if SV_RETURN_P(mv_holder3705) SET_MV_RETURN_COUNT(mv_holder3705,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder3705);
BEGIN_VAR_VALUES;
RESTIFY(v_MV5293_6,1,NEXT_VAR_VALUE(mv_holder3705));
END_VAR_VALUES;
END_MV_CALL;
t2 = INT_TO_FX(internal_user_run_time());
t1 = (subtract((t2), (v_USER_2DSTART_4)));
v_ELAPSED_2DUSER_7 = (divide((t1), (LREF(k3706))));
t4 = INT_TO_FX(internal_system_run_time());
t3 = (subtract((t4), (v_SYSTEM_2DSTART_5)));
v_ELAPSED_2DSYSTEM_8 = (divide((t3), (LREF(k3706))));
t6 = ICALL(s_lsp_GET_2DINTERNAL_2DREAL_2DTIME) (0);
t5 = (subtract((t6), (v_REAL_2DSTART_3)));
v_ELAPSED_2DREAL_9 = (divide((t5), (LREF(k3706))));
t7 = ICALL(s_lsp_GC_2DCALL_2DCOUNT) (0);
v_GC_2DCOUNT_10 = (subtract((t7), (v_START_2DGC_2DCOUNT_2)));
ICALL(s_lsp_FORMAT) (3, LREF(s_lsp_T), LREF(k3707), v_ELAPSED_2DUSER_7);
ICALL(s_lsp_FORMAT) (3, LREF(s_lsp_T), LREF(k3708), v_ELAPSED_2DSYSTEM_8);
t8 = (add((v_ELAPSED_2DUSER_7), (v_ELAPSED_2DSYSTEM_8)));
ICALL(s_lsp_FORMAT) (3, LREF(s_lsp_T), LREF(k3709), t8);
ICALL(s_lsp_FORMAT) (3, LREF(s_lsp_T), LREF(k3710), v_ELAPSED_2DREAL_9);
ICALL(s_lsp_FORMAT) (4, LREF(s_lsp_T), LREF(k3711), v_GC_2DCOUNT_10, v_GC_2DCOUNT_10);
t9 = ICALL(s_lsp_VALUES_2DLIST) (MV_CALL(argc,1), v_MV5293_6);
return(t9);
}
}

LP p_lsp_TIME_2DZONE(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 0) wna(argc,0);
t0 = INT_TO_FX(unix_timezone());
return(t0);
}

LP p_lsp_UNIX_2D_3EUNIVERSAL_2DTIME(argc, v_TIME_0)
      ARGC argc;  LP v_TIME_0;
{

LP t0; LP t1; LP t2; LP t3; LP t4; 
if (argc != 1) wna(argc,1);
t0 = (add((v_TIME_0), (LREF(k3704))));
return(t0);
}

LP p_lsp_DST_2DCHECK(argc, v_DAY_0, v_HOUR_1, v_WEEKDAY_2)
      ARGC argc;  LP v_DAY_0; LP v_HOUR_1; LP v_WEEKDAY_2;
{
LP v_S5337_15; LP v_S5336_14; LP v_S5335_13; 
LP v_S5334_12; LP v_SYMBOL_10; LP v_S5333_9; 
LP v_S5332_8; LP v_S5331_7; LP v_S5330_6; 
LP v_SYMBOL_4; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; 
if (argc != 3) wna(argc,3);
v_S5334_12 = v_DAY_0;
v_S5336_14 = v_WEEKDAY_2;
v_SYMBOL_10 = LREF(s_lsp_APRIL_2D1);
v_S5337_15 = ((LP) DEREF((LREF(s_lsp_APRIL_2D1)) + 0 * 4));
if (((int) (v_S5334_12) < (int) (v_S5337_15))) {
t1 = LREF(s_lsp_NIL);
} else {
t4 = (((LP) ((int) (v_S5334_12) - (int) (v_S5336_14))));
if (((int) (t4) > (int) (v_S5337_15))) {
t1 = LREF(s_lsp_T);
} else {
t6 = ICALL(s_lsp_EQ) (2, v_S5336_14, (LP) 12);
if (t6 != NIL) {
t5 = (((int) (v_HOUR_1) > (int) ((LP) 0)) ? T : NIL);
} else {
t5 = LREF(s_lsp_NIL);
}
if (t5 != NIL) {
t1 = LREF(s_lsp_T);
} else {
t1 = LREF(s_lsp_NIL);
}
}
}
if (t1 != NIL) {
v_S5330_6 = v_DAY_0;
v_S5332_8 = v_WEEKDAY_2;
v_SYMBOL_4 = LREF(s_lsp_OCTOBER_2D31);
v_S5333_9 = ((LP) DEREF((LREF(s_lsp_OCTOBER_2D31)) + 0 * 4));
t9 = (((LP) ((int) (v_S5330_6) + (int) ((LP) 12))));
if (((int) (t9) < (int) (v_S5333_9))) {
t7 = LREF(s_lsp_NIL);
} else {
t12 = (((LP) ((int) (v_S5330_6) + (int) ((LP) 12))));
t11 = (((LP) ((int) (t12) - (int) (v_S5332_8))));
if (((int) (t11) > (int) (v_S5333_9))) {
t7 = LREF(s_lsp_T);
} else {
t14 = ICALL(s_lsp_EQ) (2, v_S5332_8, (LP) 12);
if (t14 != NIL) {
t13 = (((int) (v_HOUR_1) > (int) ((LP) 0)) ? T : NIL);
} else {
t13 = LREF(s_lsp_NIL);
}
if (t13 != NIL) {
t7 = LREF(s_lsp_T);
} else {
t7 = LREF(s_lsp_NIL);
}
}
}
t0 = ICALL(s_lsp_NOT) (MV_CALL(argc,1), t7);
return(t0);
} else {
return(LREF(s_lsp_NIL));
}
}

LP p_lsp_DECODE_2DUNIVERSAL_2DTIME(va_alist) va_dcl
{
LP v_DIVISOR_113; LP v_N_112; LP v_SYMBOL_110; 
LP v_N_108; LP v_DIVISOR_109; LP v_DIVISOR_106; 
LP v_N_105; LP v_N_103; LP v_DIVISOR_104; 
LP v_DIVISOR_101; LP v_N_100; LP v_N_98; 
LP v_DIVISOR_99; LP v_X_96; LP v_DIVISOR_94; 
LP v_N_93; LP v_N_91; LP v_DIVISOR_92; 
LP v_DIVISOR_89; LP v_N_88; LP v_N_86; 
LP v_DIVISOR_87; LP v_TMP5343_85; LP v_TMP5342_84; 
LP v_X_82; LP v_T3_81; LP v_X_79; 
LP v_G5341_78; LP v_X_76; LP v_G5340_75; 
LP v_X_73; LP v_X_71; LP v_DAYS_2DSINCE_2DMAR0_70; 
LP v_X_68; LP v_DIVISOR_66; LP v_N_65; 
LP v_SYMBOL_63; LP v_N_61; LP v_DIVISOR_62; 
LP v_DIVISOR_59; LP v_N_58; LP v_SYMBOL_56; 
LP v_N_54; LP v_DIVISOR_55; LP v_TCENT_53; 
LP v_DIVISOR_51; LP v_N_50; LP v_N_48; 
LP v_DIVISOR_49; LP v_T2_47; LP v_X_45; 
LP v_DIVISOR_43; LP v_N_42; LP v_SYMBOL_40; 
LP v_N_38; LP v_DIVISOR_39; LP v_TMP5339_37; 
LP v_TMP5338_36; LP v_TDAY_35; LP v_DIVISOR_33; 
LP v_N_32; LP v_SYMBOL_30; LP v_N_28; 
LP v_DIVISOR_29; LP v_X_26; LP v_DIVISOR_24; 
LP v_N_23; LP v_SYMBOL_21; LP v_X_19; 
LP v_N_17; LP v_DIVISOR_18; LP v_SECONDS_16; 
LP v_T1_15; LP v_TIMEZONE_14; LP v_DAYLIGHT_13; 
LP v_DAY_12; LP v_YEAR_11; LP v_MONTH_10; 
LP v_DATE_9; LP v_HOUR_8; LP v_MINUTE_7; 
LP v_SECOND_6; LP v_WEEKS_5; LP v_SECS_4; 
LP v_WEEKS_3; LP v_UNIVERSAL_2DTIME_0; LP v_TIME_2DZONE_1; 

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 
LP t102; LP t103; LP t104; LP t105; LP t106; LP t107; 
LP t108; LP t109; LP t110; LP t111; LP t112; LP t113; 
LP t114; LP t115; LP t116; LP t117; LP t118; LP t119; 
LP t120; LP t121; LP t122; LP t123; LP t124; LP t125; 
LP t126; LP t127; LP t128; LP t129; LP t130; LP t131; 
LP t132; LP t133; LP t134; LP t135; LP t136; LP t137; 
LP t138; LP t139; LP t140; LP t141; LP t142; LP t143; 
LP t144; 
int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_UNIVERSAL_2DTIME_0 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 1) wna_low(real_argc,1);
if (real_argc > 2) wna_high(real_argc,2);
if (real_argc < 2) {
t0 = ICALL(s_lsp_TIME_2DZONE) (0);
v_TIME_2DZONE_1 = t0;
} else {
v_TIME_2DZONE_1 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
{
int real_argc;
BEGIN_MV_CALL(mv_holder3712,0);
v_N_112 = (add((v_UNIVERSAL_2DTIME_0), ((LP) 864000)));
v_SYMBOL_110 = LREF(s_lsp_SECONDS_2DIN_2DWEEK);
v_DIVISOR_113 = ((LP) DEREF((LREF(s_lsp_SECONDS_2DIN_2DWEEK)) + 0 * 4));
t1 = ICALL(s_lsp_TRUNCATE_2F2) (MV_CALL(mv_holder3712,2), v_N_112, v_DIVISOR_113);
SET_MV_RETURN_VALUE(mv_holder3712,0,t1);
if SV_RETURN_P(mv_holder3712) SET_MV_RETURN_COUNT(mv_holder3712,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder3712);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_WEEKS_3 = NIL;
} else {
v_WEEKS_3 = NEXT_VAR_VALUE(mv_holder3712);
}
if (real_argc < 2) {
v_SECS_4 = NIL;
} else {
v_SECS_4 = NEXT_VAR_VALUE(mv_holder3712);
}
END_VAR_VALUES;
END_MV_CALL;
v_WEEKS_5 = (add((v_WEEKS_3), ((LP) 4290)));
v_SECOND_6 = LREF(s_lsp_NIL);
v_MINUTE_7 = LREF(s_lsp_NIL);
v_HOUR_8 = LREF(s_lsp_NIL);
v_DATE_9 = LREF(s_lsp_NIL);
v_MONTH_10 = LREF(s_lsp_NIL);
v_YEAR_11 = LREF(s_lsp_NIL);
v_DAY_12 = LREF(s_lsp_NIL);
v_DAYLIGHT_13 = LREF(s_lsp_NIL);
v_TIMEZONE_14 = (multiply((v_TIME_2DZONE_1), ((LP) 120)));
{
int real_argc;
BEGIN_MV_CALL(mv_holder3713,0);
v_N_100 = v_SECS_4;
v_DIVISOR_101 = (LP) 120;
t2 = ICALL(s_lsp_TRUNCATE_2F2) (MV_CALL(mv_holder3713,2), v_SECS_4, (LP) 120);
SET_MV_RETURN_VALUE(mv_holder3713,0,t2);
if SV_RETURN_P(mv_holder3713) SET_MV_RETURN_COUNT(mv_holder3713,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder3713);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_T1_15 = NIL;
} else {
v_T1_15 = NEXT_VAR_VALUE(mv_holder3713);
}
if (real_argc < 2) {
v_SECONDS_16 = NIL;
} else {
v_SECONDS_16 = NEXT_VAR_VALUE(mv_holder3713);
}
END_VAR_VALUES;
END_MV_CALL;
v_SECOND_6 = v_SECONDS_16;
v_T1_15 = (subtract((v_T1_15), (v_TIMEZONE_14)));
t3 = (lessp((v_T1_15), ((LP) 0)));
if (t3 != NIL) {
v_X_19 = v_T1_15;
v_N_23 = (add((v_X_19), ((LP) 2)));
v_SYMBOL_21 = LREF(s_lsp_MINUTES_2DPER_2DDAY);
v_DIVISOR_24 = ((LP) DEREF((LREF(s_lsp_MINUTES_2DPER_2DDAY)) + 0 * 4));
v_X_26 = ICALL(s_lsp_TRUNCATE_2F2) (2, v_N_23, v_DIVISOR_24);
v_TDAY_35 = (subtract((v_X_26), ((LP) 2)));
} else {
v_N_32 = v_T1_15;
v_SYMBOL_30 = LREF(s_lsp_MINUTES_2DPER_2DDAY);
v_DIVISOR_33 = ((LP) DEREF((LREF(s_lsp_MINUTES_2DPER_2DDAY)) + 0 * 4));
v_TDAY_35 = ICALL(s_lsp_TRUNCATE_2F2) (2, v_N_32, v_DIVISOR_33);
}
{
int real_argc;
BEGIN_MV_CALL(mv_holder3714,0);
v_SYMBOL_40 = LREF(s_lsp_MINUTES_2DPER_2DDAY);
t5 = ((LP) DEREF((LREF(s_lsp_MINUTES_2DPER_2DDAY)) + 0 * 4));
t4 = (multiply((v_TDAY_35), (t5)));
v_N_42 = (subtract((v_T1_15), (t4)));
t6 = ICALL(s_lsp_TRUNCATE_2F2) (MV_CALL(mv_holder3714,2), v_N_42, (LP) 120);
SET_MV_RETURN_VALUE(mv_holder3714,0,t6);
if SV_RETURN_P(mv_holder3714) SET_MV_RETURN_COUNT(mv_holder3714,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder3714);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_TMP5338_36 = NIL;
} else {
v_TMP5338_36 = NEXT_VAR_VALUE(mv_holder3714);
}
if (real_argc < 2) {
v_TMP5339_37 = NIL;
} else {
v_TMP5339_37 = NEXT_VAR_VALUE(mv_holder3714);
}
END_VAR_VALUES;
END_MV_CALL;
v_HOUR_8 = v_TMP5338_36;
v_MINUTE_7 = v_TMP5339_37;
}
t9 = (multiply((v_WEEKS_5), ((LP) 14)));
t8 = (add((t9), (v_TDAY_35)));
t7 = (add((t8), ((LP) 1357764)));
v_X_45 = (multiply((t7), ((LP) 8)));
v_T2_47 = (subtract((v_X_45), ((LP) 2)));
v_N_50 = v_T2_47;
v_TCENT_53 = ICALL(s_lsp_TRUNCATE_2F2) (2, v_N_50, (LP) 292194);
v_T2_47 = ICALL(s_lsp_MOD) (2, v_T2_47, (LP) 292194);
t11 = ICALL(s_lsp_MOD) (2, v_T2_47, (LP) 8);
t10 = (subtract((v_T2_47), (t11)));
v_T2_47 = (add((t10), ((LP) 6)));
t12 = (multiply((v_TCENT_53), ((LP) 200)));
v_N_58 = v_T2_47;
v_SYMBOL_56 = LREF(s_lsp_QUARTER_2DDAYS_2DPER_2DYEAR);
v_DIVISOR_59 = ((LP) DEREF((LREF(s_lsp_QUARTER_2DDAYS_2DPER_2DYEAR)) + 0 * 4));
t13 = ICALL(s_lsp_TRUNCATE_2F2) (2, v_N_58, v_DIVISOR_59);
v_YEAR_11 = (add((t12), (t13)));
v_SYMBOL_63 = LREF(s_lsp_QUARTER_2DDAYS_2DPER_2DYEAR);
t14 = ((LP) DEREF((LREF(s_lsp_QUARTER_2DDAYS_2DPER_2DYEAR)) + 0 * 4));
v_N_65 = ICALL(s_lsp_MOD) (2, v_T2_47, t14);
v_X_68 = ICALL(s_lsp_TRUNCATE_2F2) (2, v_N_65, (LP) 8);
v_DAYS_2DSINCE_2DMAR0_70 = (add((v_X_68), ((LP) 2)));
t15 = (add((v_TDAY_35), ((LP) 4)));
v_DAY_12 = ICALL(s_lsp_MOD) (2, t15, (LP) 14);
v_DAYLIGHT_13 = ICALL(s_lsp_DST_2DCHECK) (3, v_DAYS_2DSINCE_2DMAR0_70, v_HOUR_8, v_DAY_12);
if (v_DAYLIGHT_13 != NIL) {
t16 = ICALL(s_lsp_EQ) (2, v_HOUR_8, (LP) 46);
if (t16 != NIL) {
v_HOUR_8 = (LP) 0;
v_X_71 = v_DAY_12;
t17 = (add((v_X_71), ((LP) 2)));
v_DAY_12 = ICALL(s_lsp_MOD) (2, t17, (LP) 14);
v_X_73 = v_DAYS_2DSINCE_2DMAR0_70;
v_DAYS_2DSINCE_2DMAR0_70 = (add((v_X_73), ((LP) 2)));
t18 = (geq_p((v_DAYS_2DSINCE_2DMAR0_70), ((LP) 732)));
if (t18 != NIL) {
v_G5340_75 = (greaterp((v_DAYS_2DSINCE_2DMAR0_70), ((LP) 732)));
if (v_G5340_75 != NIL) {
t19 = v_G5340_75;
} else {
v_X_76 = v_YEAR_11;
v_G5341_78 = (add((v_X_76), ((LP) 2)));
t21 = ICALL(s_lsp_MOD) (2, v_G5341_78, (LP) 8);
t20 = ICALL(s_lsp_EQ) (2, t21, (LP) 0);
if (t20 != NIL) {
t23 = ICALL(s_lsp_MOD) (2, v_G5341_78, (LP) 200);
t22 = ICALL(s_lsp_EQ) (2, t23, (LP) 0);
if (t22 != NIL) {
t25 = ICALL(s_lsp_MOD) (2, v_G5341_78, (LP) 800);
t24 = ICALL(s_lsp_EQ) (2, t25, (LP) 0);
t19 = ICALL(s_lsp_NOT) (1, t24);
} else {
t19 = LREF(s_lsp_NIL);
}
} else {
t19 = LREF(s_lsp_T);
}
}
if (t19 != NIL) {
v_DAYS_2DSINCE_2DMAR0_70 = (LP) 736;
}
}
} else {
v_X_79 = v_HOUR_8;
v_HOUR_8 = (add((v_X_79), ((LP) 2)));
}
}
t26 = (multiply((v_DAYS_2DSINCE_2DMAR0_70), ((LP) 10)));
v_T3_81 = (add((t26), ((LP) 912)));
t27 = (geq_p((v_T3_81), ((LP) 3978)));
if (t27 != NIL) {
v_T3_81 = (subtract((v_T3_81), ((LP) 3672)));
v_X_82 = v_YEAR_11;
v_YEAR_11 = (add((v_X_82), ((LP) 2)));
}
{
int real_argc;
BEGIN_MV_CALL(mv_holder3715,0);
v_N_88 = v_T3_81;
t28 = ICALL(s_lsp_TRUNCATE_2F2) (MV_CALL(mv_holder3715,2), v_N_88, (LP) 306);
SET_MV_RETURN_VALUE(mv_holder3715,0,t28);
if SV_RETURN_P(mv_holder3715) SET_MV_RETURN_COUNT(mv_holder3715,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder3715);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_TMP5342_84 = NIL;
} else {
v_TMP5342_84 = NEXT_VAR_VALUE(mv_holder3715);
}
if (real_argc < 2) {
v_TMP5343_85 = NIL;
} else {
v_TMP5343_85 = NEXT_VAR_VALUE(mv_holder3715);
}
END_VAR_VALUES;
END_MV_CALL;
v_MONTH_10 = v_TMP5342_84;
v_T3_81 = v_TMP5343_85;
}
v_N_93 = v_T3_81;
v_X_96 = ICALL(s_lsp_TRUNCATE_2F2) (2, v_N_93, (LP) 10);
v_DATE_9 = (add((v_X_96), ((LP) 2)));
}
v_N_105 = v_TIMEZONE_14;
v_DIVISOR_106 = (LP) 120;
t29 = ICALL(s_lsp_TRUNCATE_2F2) (2, v_TIMEZONE_14, (LP) 120);
if (MV_HOLDER_P(argc)) {
SET_MV_RETURN_FLAG(argc);
SET_MV_RETURN_COUNT(argc,9);
SET_MV_RETURN_VALUE(argc,1,v_MINUTE_7);
SET_MV_RETURN_VALUE(argc,2,v_HOUR_8);
SET_MV_RETURN_VALUE(argc,3,v_DATE_9);
SET_MV_RETURN_VALUE(argc,4,v_MONTH_10);
SET_MV_RETURN_VALUE(argc,5,v_YEAR_11);
SET_MV_RETURN_VALUE(argc,6,v_DAY_12);
SET_MV_RETURN_VALUE(argc,7,v_DAYLIGHT_13);
SET_MV_RETURN_VALUE(argc,8,t29);
}
return(v_SECOND_6);
}
}

LP p_lsp_MAKE_2DUNIVERSAL_2DTIME(argc, v_WEEKS_0, v_MSEC_1)
      ARGC argc;  LP v_WEEKS_0; LP v_MSEC_1;
{
LP v_DIVISOR_8; LP v_N_7; LP v_N_5; 
LP v_DIVISOR_6; LP v_SYMBOL_3; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; 
if (argc != 2) wna(argc,2);
t2 = (subtract((v_WEEKS_0), ((LP) 4290)));
v_SYMBOL_3 = LREF(s_lsp_SECONDS_2DIN_2DWEEK);
t3 = ((LP) DEREF((LREF(s_lsp_SECONDS_2DIN_2DWEEK)) + 0 * 4));
t1 = (multiply((t2), (t3)));
v_N_7 = v_MSEC_1;
v_DIVISOR_8 = (LP) 2000;
t5 = ICALL(s_lsp_TRUNCATE_2F2) (2, v_MSEC_1, (LP) 2000);
t4 = (subtract((t5), ((LP) 864000)));
t0 = (add((t1), (t4)));
return(t0);
}

LP p_lsp_ENCODE_2DUNIVERSAL_2DTIME(va_alist) va_dcl
{
LP v_DIVISOR_86; LP v_N_85; LP v_N_83; 
LP v_DIVISOR_84; LP v_DIVISOR_81; LP v_N_80; 
LP v_N_78; LP v_DIVISOR_79; LP v_SYMBOL_76; 
LP v_DPART_75; LP v_WEEKS_74; LP v_S5354_73; 
LP v_SYMBOL_71; LP v_TMP5353_70; LP v_SYMBOL_68; 
LP v_I_65; LP v_S5350_63; LP v_TMP5349_62; 
LP v_SYMBOL_60; LP v_I_57; LP v_TMINUTES_55; 
LP v_DAYLIGHT_54; LP v_X_52; LP v_TDAY_51; 
LP v_DIVISOR_49; LP v_N_48; LP v_SYMBOL_46; 
LP v_N_44; LP v_DIVISOR_45; LP v_DIVISOR_42; 
LP v_N_41; LP v_N_39; LP v_DIVISOR_40; 
LP v_TYEAR_38; LP v_TCENT_37; LP v_DAYS_2DSINCE_2DMAR0_36; 
LP v_DIVISOR_34; LP v_N_33; LP v_N_31; 
LP v_DIVISOR_32; LP v_X_29; LP v_TMONTH_28; 
LP v_ZONE_27; LP v_YEAR_26; LP v_TMP5346_25; 
LP v_Y_22; LP v_X_20; LP v_DIVISOR_18; 
LP v_N_17; LP v_N_15; LP v_DIVISOR_16; 
LP v_NOW_2DYEAR_13; LP v_MONTH_12; LP v_DAY_11; 
LP v_HOUR_10; LP v_MIN_9; LP v_SEC_8; 
LP v_YEAR_5; LP v_MONTH_4; LP v_DATE_3; 
LP v_HOUR_2; LP v_MINUTE_1; LP v_SECOND_0; 
LP v_TIME_2DZONE_6; 
LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; LP t10; LP t11; 
LP t12; LP t13; LP t14; LP t15; LP t16; LP t17; 
LP t18; LP t19; LP t20; LP t21; LP t22; LP t23; 
LP t24; LP t25; LP t26; LP t27; LP t28; LP t29; 
LP t30; LP t31; LP t32; LP t33; LP t34; LP t35; 
LP t36; LP t37; LP t38; LP t39; LP t40; LP t41; 
LP t42; LP t43; LP t44; LP t45; LP t46; LP t47; 
LP t48; LP t49; LP t50; LP t51; LP t52; LP t53; 
LP t54; LP t55; LP t56; LP t57; LP t58; LP t59; 
LP t60; LP t61; LP t62; LP t63; LP t64; LP t65; 
LP t66; LP t67; LP t68; LP t69; LP t70; LP t71; 
LP t72; LP t73; LP t74; LP t75; LP t76; LP t77; 
LP t78; LP t79; LP t80; LP t81; LP t82; LP t83; 
LP t84; LP t85; LP t86; LP t87; LP t88; LP t89; 
LP t90; LP t91; LP t92; LP t93; LP t94; LP t95; 
LP t96; LP t97; LP t98; LP t99; LP t100; LP t101; 

int real_argc;
ARGC argc;
BEGIN_NON_ANSI_VAR_ARGS;
argc = (ARGC) NEXT_VAR_ARG;
v_SECOND_0 = NEXT_VAR_ARG;
v_MINUTE_1 = NEXT_VAR_ARG;
v_HOUR_2 = NEXT_VAR_ARG;
v_DATE_3 = NEXT_VAR_ARG;
v_MONTH_4 = NEXT_VAR_ARG;
v_YEAR_5 = NEXT_VAR_ARG;


real_argc = REAL_ARGC(argc);
if (real_argc < 6) wna_low(real_argc,6);
if (real_argc > 7) wna_high(real_argc,7);
if (real_argc < 7) {
t0 = ICALL(s_lsp_TIME_2DZONE) (0);
v_TIME_2DZONE_6 = t0;
} else {
v_TIME_2DZONE_6 = NEXT_VAR_ARG;
}
END_VAR_ARGS;
t1 = (lessp((v_YEAR_5), ((LP) 200)));
if (t1 != NIL) {
{
int real_argc;
BEGIN_MV_CALL(mv_holder3716,0);
t2 = ICALL(s_lsp_GET_2DDECODED_2DTIME) (MV_CALL(mv_holder3716,0));
SET_MV_RETURN_VALUE(mv_holder3716,0,t2);
if SV_RETURN_P(mv_holder3716) SET_MV_RETURN_COUNT(mv_holder3716,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder3716);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_SEC_8 = NIL;
} else {
v_SEC_8 = NEXT_VAR_VALUE(mv_holder3716);
}
if (real_argc < 2) {
v_MIN_9 = NIL;
} else {
v_MIN_9 = NEXT_VAR_VALUE(mv_holder3716);
}
if (real_argc < 3) {
v_HOUR_10 = NIL;
} else {
v_HOUR_10 = NEXT_VAR_VALUE(mv_holder3716);
}
if (real_argc < 4) {
v_DAY_11 = NIL;
} else {
v_DAY_11 = NEXT_VAR_VALUE(mv_holder3716);
}
if (real_argc < 5) {
v_MONTH_12 = NIL;
} else {
v_MONTH_12 = NEXT_VAR_VALUE(mv_holder3716);
}
if (real_argc < 6) {
v_NOW_2DYEAR_13 = NIL;
} else {
v_NOW_2DYEAR_13 = NEXT_VAR_VALUE(mv_holder3716);
}
END_VAR_VALUES;
END_MV_CALL;
v_N_17 = v_NOW_2DYEAR_13;
v_DIVISOR_18 = (LP) 200;
v_X_20 = ICALL(s_lsp_TRUNCATE_2F2) (2, v_NOW_2DYEAR_13, (LP) 200);
t4 = (subtract((v_X_20), ((LP) 2)));
t3 = (multiply(((LP) 200), (t4)));
v_Y_22 = (add((v_YEAR_5), (t3)));
goto t_TEST5344_24;
t_LOOP5345_23:;
v_TMP5346_25 = (add((v_Y_22), ((LP) 200)));
v_Y_22 = v_TMP5346_25;
t_TEST5344_24:;
t7 = (subtract((v_Y_22), (v_NOW_2DYEAR_13)));
t6 = ICALL(s_lsp_ABS) (1, t7);
t5 = (leq_p((t6), ((LP) 100)));
if (t5 != NIL) {
v_YEAR_26 = v_Y_22;
goto b_NIL_14;
}
goto t_LOOP5345_23;
v_YEAR_26 = NIL;
v_YEAR_26 = v_YEAR_26;
b_NIL_14:;
}
} else {
v_YEAR_26 = v_YEAR_5;
}
v_ZONE_27 = (multiply((v_TIME_2DZONE_6), ((LP) 120)));
v_TMONTH_28 = (subtract((v_MONTH_4), ((LP) 6)));
t8 = (lessp((v_TMONTH_28), ((LP) 0)));
if (t8 != NIL) {
v_TMONTH_28 = (add((v_TMONTH_28), ((LP) 24)));
v_X_29 = v_YEAR_26;
v_YEAR_26 = (subtract((v_X_29), ((LP) 2)));
}
t9 = (multiply((v_TMONTH_28), ((LP) 306)));
v_N_33 = (add((t9), ((LP) 4)));
t10 = ICALL(s_lsp_TRUNCATE_2F2) (2, v_N_33, (LP) 10);
v_DAYS_2DSINCE_2DMAR0_36 = (add((t10), (v_DATE_3)));
{
int real_argc;
BEGIN_MV_CALL(mv_holder3717,0);
v_N_85 = v_YEAR_26;
t11 = ICALL(s_lsp_TRUNCATE_2F2) (MV_CALL(mv_holder3717,2), v_N_85, (LP) 200);
SET_MV_RETURN_VALUE(mv_holder3717,0,t11);
if SV_RETURN_P(mv_holder3717) SET_MV_RETURN_COUNT(mv_holder3717,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder3717);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_TCENT_37 = NIL;
} else {
v_TCENT_37 = NEXT_VAR_VALUE(mv_holder3717);
}
if (real_argc < 2) {
v_TYEAR_38 = NIL;
} else {
v_TYEAR_38 = NEXT_VAR_VALUE(mv_holder3717);
}
END_VAR_VALUES;
END_MV_CALL;
v_N_41 = (multiply((v_TCENT_37), ((LP) 292194)));
t14 = ICALL(s_lsp_TRUNCATE_2F2) (2, v_N_41, (LP) 8);
v_SYMBOL_46 = LREF(s_lsp_QUARTER_2DDAYS_2DPER_2DYEAR);
t15 = ((LP) DEREF((LREF(s_lsp_QUARTER_2DDAYS_2DPER_2DYEAR)) + 0 * 4));
v_N_48 = (multiply((v_TYEAR_38), (t15)));
t16 = ICALL(s_lsp_TRUNCATE_2F2) (2, v_N_48, (LP) 8);
t13 = (add((t14), (t16)));
t12 = (add((t13), (v_DAYS_2DSINCE_2DMAR0_36)));
v_TDAY_51 = (subtract((t12), ((LP) 1357764)));
v_X_52 = v_HOUR_2;
t17 = (subtract((v_HOUR_2), ((LP) 2)));
t19 = (add((v_TDAY_51), ((LP) 4)));
t18 = ICALL(s_lsp_MOD) (2, t19, (LP) 14);
v_DAYLIGHT_54 = ICALL(s_lsp_DST_2DCHECK) (3, v_DAYS_2DSINCE_2DMAR0_36, t17, t18);
t21 = (multiply((v_HOUR_2), ((LP) 120)));
t20 = (add((t21), (v_MINUTE_1)));
v_TMINUTES_55 = (add((t20), (v_ZONE_27)));
if (v_DAYLIGHT_54 != NIL) {
v_TMINUTES_55 = (subtract((v_TMINUTES_55), ((LP) 120)));
}
v_I_57 = v_TMINUTES_55;
goto t_TEST5347_59;
t_LOOP5348_58:;
v_SYMBOL_60 = LREF(s_lsp_MINUTES_2DPER_2DDAY);
t22 = ((LP) DEREF((LREF(s_lsp_MINUTES_2DPER_2DDAY)) + 0 * 4));
v_TMP5349_62 = (add((v_I_57), (t22)));
v_I_57 = v_TMP5349_62;
t_TEST5347_59:;
if (((int) (v_I_57) >= (int) ((LP) 0))) {
v_TMINUTES_55 = v_I_57;
goto b_NIL_56;
}
v_S5350_63 = (subtract((v_TDAY_51), ((LP) 2)));
v_TDAY_51 = v_S5350_63;
goto t_LOOP5348_58;
b_NIL_56:;
v_I_65 = v_TMINUTES_55;
goto t_TEST5351_67;
t_LOOP5352_66:;
v_SYMBOL_68 = LREF(s_lsp_MINUTES_2DPER_2DDAY);
t24 = ((LP) DEREF((LREF(s_lsp_MINUTES_2DPER_2DDAY)) + 0 * 4));
v_TMP5353_70 = (subtract((v_I_65), (t24)));
v_I_65 = v_TMP5353_70;
t_TEST5351_67:;
v_SYMBOL_71 = LREF(s_lsp_MINUTES_2DPER_2DDAY);
t26 = ((LP) DEREF((LREF(s_lsp_MINUTES_2DPER_2DDAY)) + 0 * 4));
t25 = (lessp((v_I_65), (t26)));
if (t25 != NIL) {
v_TMINUTES_55 = v_I_65;
goto b_NIL_64;
}
v_S5354_73 = (add((v_TDAY_51), ((LP) 2)));
v_TDAY_51 = v_S5354_73;
goto t_LOOP5352_66;
b_NIL_64:;
{
int real_argc;
BEGIN_MV_CALL(mv_holder3718,0);
v_N_80 = v_TDAY_51;
t27 = ICALL(s_lsp_TRUNCATE_2F2) (MV_CALL(mv_holder3718,2), v_N_80, (LP) 14);
SET_MV_RETURN_VALUE(mv_holder3718,0,t27);
if SV_RETURN_P(mv_holder3718) SET_MV_RETURN_COUNT(mv_holder3718,1);
real_argc = GET_MV_RETURN_COUNT(mv_holder3718);
BEGIN_VAR_VALUES;
if (real_argc < 1) {
v_WEEKS_74 = NIL;
} else {
v_WEEKS_74 = NEXT_VAR_VALUE(mv_holder3718);
}
if (real_argc < 2) {
v_DPART_75 = NIL;
} else {
v_DPART_75 = NEXT_VAR_VALUE(mv_holder3718);
}
END_VAR_VALUES;
END_MV_CALL;
v_SYMBOL_76 = LREF(s_lsp_MINUTES_2DPER_2DDAY);
t34 = ((LP) DEREF((LREF(s_lsp_MINUTES_2DPER_2DDAY)) + 0 * 4));
t33 = (multiply((v_DPART_75), (t34)));
t32 = (add((t33), (v_TMINUTES_55)));
t31 = (multiply((t32), ((LP) 120)));
t30 = (add((t31), (v_SECOND_0)));
t29 = (multiply((t30), ((LP) 2000)));
t28 = ICALL(s_lsp_MAKE_2DUNIVERSAL_2DTIME) (MV_CALL(argc,2), v_WEEKS_74, t29);
return(t28);
}
}
}

