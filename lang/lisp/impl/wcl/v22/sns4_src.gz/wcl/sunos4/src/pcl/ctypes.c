/*
:comment "Compiled at 6:25:00 pm on Tuesday, June 21, 1994"
:comment "Compiler Configuration: DEFAULT"
:comment "Machine Configuration: SparcStation (gcc)"
:comment "cc command: gcc -w  -g -O "
:version 0
:package (IN-PACKAGE (QUOTE PCL)) 
:end-package-info 0
:sym +
:sym T
:sym LOAD-SHORT-DEFCOMBIN
:sym AND
:sym APPEND
:sym NIL
:sym LIST
:sym MAX
:sym MIN
:sym NCONC
:sym OR
:sym PROGN
:sf CTYPES_INIT1517 "p_pcl_CTYPES_5FINIT1517"
:init CTYPES_INIT1517
:pinfo PCL::CTYPES_INIT1517 NIL NIL NIL NIL NIL NIL NIL T
:end
*/

#include "lisp.h"

extern LP p_pcl_CTYPES_5FINIT1517();
extern SYMBOL s_lsp__2B; 
extern SYMBOL s_lsp_T; 
MAKE_SIMPLE_STRING(k4837,0,"");
extern SYMBOL s_pcl_LOAD_2DSHORT_2DDEFCOMBIN; 
extern SYMBOL s_lsp_AND; 
extern SYMBOL s_lsp_APPEND; 
extern SYMBOL s_lsp_NIL; 
extern SYMBOL s_lsp_LIST; 
extern SYMBOL s_lsp_MAX; 
extern SYMBOL s_lsp_MIN; 
extern SYMBOL s_lsp_NCONC; 
extern SYMBOL s_lsp_OR; 
extern SYMBOL s_lsp_PROGN; 




LP p_pcl_CTYPES_5FINIT1517(argc)
      ARGC argc; 
{

LP t0; LP t1; LP t2; LP t3; LP t4; LP t5; 
LP t6; LP t7; LP t8; LP t9; 
if (argc != 0) wna(argc,0);
ICALL(s_pcl_LOAD_2DSHORT_2DDEFCOMBIN) (4, LREF(s_lsp__2B), LREF(s_lsp__2B), LREF(s_lsp_T), LREF(k4837));
ICALL(s_pcl_LOAD_2DSHORT_2DDEFCOMBIN) (4, LREF(s_lsp_AND), LREF(s_lsp_AND), LREF(s_lsp_T), LREF(k4837));
ICALL(s_pcl_LOAD_2DSHORT_2DDEFCOMBIN) (4, LREF(s_lsp_APPEND), LREF(s_lsp_APPEND), LREF(s_lsp_NIL), LREF(k4837));
ICALL(s_pcl_LOAD_2DSHORT_2DDEFCOMBIN) (4, LREF(s_lsp_LIST), LREF(s_lsp_LIST), LREF(s_lsp_NIL), LREF(k4837));
ICALL(s_pcl_LOAD_2DSHORT_2DDEFCOMBIN) (4, LREF(s_lsp_MAX), LREF(s_lsp_MAX), LREF(s_lsp_T), LREF(k4837));
ICALL(s_pcl_LOAD_2DSHORT_2DDEFCOMBIN) (4, LREF(s_lsp_MIN), LREF(s_lsp_MIN), LREF(s_lsp_T), LREF(k4837));
ICALL(s_pcl_LOAD_2DSHORT_2DDEFCOMBIN) (4, LREF(s_lsp_NCONC), LREF(s_lsp_NCONC), LREF(s_lsp_T), LREF(k4837));
ICALL(s_pcl_LOAD_2DSHORT_2DDEFCOMBIN) (4, LREF(s_lsp_OR), LREF(s_lsp_OR), LREF(s_lsp_T), LREF(k4837));
t0 = ICALL(s_pcl_LOAD_2DSHORT_2DDEFCOMBIN) (MV_CALL(argc,4), LREF(s_lsp_PROGN), LREF(s_lsp_PROGN), LREF(s_lsp_T), LREF(k4837));
return(t0);
}

