/* This administrivia gets added to the beginning of limits.h
   if the system has its own version of limits.h.  */

#include_next <limits.h>

