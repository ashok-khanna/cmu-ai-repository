#define REAL_VALUE_ATOF(x) strtod ((x), (char **)0)
extern double strtod ();

#include "xm-i386v.h"
