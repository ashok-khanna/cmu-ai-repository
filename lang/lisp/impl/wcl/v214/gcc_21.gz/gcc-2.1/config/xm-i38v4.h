/* Configuration for GCC for Intel i386 running System V Release 4.  */

#include "xm-i386.h"
#include "xm-svr4.h"
