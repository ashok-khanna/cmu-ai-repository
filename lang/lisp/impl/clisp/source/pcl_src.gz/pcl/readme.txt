Please read the file get-pcl.text carefully, it contains the most up to
date version of the message you received when you first asked about PCL.
You should read it when you get each new release because it will contain
any new information about PCL distribution or documentation.

Also whenever there is a new release, you should read the notes.text
file carefully.

To install PCL at your site, follow the instructions in the defsys.lisp
file.

