
#include "window.h"

void
wmenuattach(win, pm)
WINDOW *win;
void *pm;
{
	addtobar(&win->mbar, pm);
	if ( win == active ) barchanged = TRUE;
}

