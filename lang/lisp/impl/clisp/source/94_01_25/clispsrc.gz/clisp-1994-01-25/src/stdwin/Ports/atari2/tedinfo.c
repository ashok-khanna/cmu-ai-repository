
#include "window.h"

TEDINFO *
tedinfo(buf, len)
char *buf;
int len;
{
	TEDINFO *e = ALLOC (TEDINFO);
	char *tmpl = malloc (len);
	char *valid = malloc (len);
/*
	int str_len = strlen (buf);
*/
	int i;

	len--;
	for (i = 0; i < len; i++) {
/*
		if ( i >= str_len ) buf[i] = '@';
*/
		tmpl[i] = '_';
		valid[i] = 'X';
	}
	buf[len] = tmpl[len] = valid[len] = '\0';

	e->te_ptext = buf;
	e->te_ptmplt = tmpl;
	e->te_pvalid = valid;
	e->te_font = IBM;
	e->te_junk1 = 0;
	e->te_just = TE_LEFT;
	e->te_color = 0x01f0;
	e->te_junk2 = 0;
	e->te_thickness = 0;
	e->te_txtlen = len;
	e->te_tmplen = len;

	return (e);
}

