
#include "window.h"

int
intersect(src, dest)
int *src;
int *dest;
{
	if ( src[0] > dest[0] ) dest[0] = src[0];
	if ( src[1] > dest[1] ) dest[1] = src[1];
	if ( src[2] < dest[2] ) dest[2] = src[2];
	if ( src[3] < dest[3] ) dest[3] = src[3];

	if ( dest[0] >= dest[2] || dest[1] >= dest[3] ) return FALSE;
	return TRUE;
}
