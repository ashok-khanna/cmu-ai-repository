
#include "window.h"

void
menuupdate ()
{
	if (barchanged && active != NULL) {
		if (menu != NULL) {
			menu_bar (menu, 0);
			FREE (menu);
		}
		menu = buildbar (active);
		menu_bar (menu, 1);
		barchanged = FALSE;
	}
}

