
#include "window.h"

void
wshow(win, left, top, right, bottom)
WINDOW *win;
int left;
int top;
int right;
int bottom;
{
	int width;
	int height;
	int orgh = win->orgh;
	int orgv = win->orgv;
	int extrah;
	int extrav;

	if ( mousedown[1] || mousedown[2] ) return;
	
	wgetwinsize (win, &width, &height);

	if ( (left >= orgh) &&
		(top >= orgv) &&
		(right <= orgh + width) &&
		(bottom <= orgv + height) ) return;		 /* Already visible */

	extrah = (width - (right - left)) / 2;
	if (extrah < 0) extrah = 0;

	extrav = (height - (bottom - top)) / 2;
	if (extrav < 0) extrav = 0;

	if ( left < orgh )               orgh = left - extrah;
	else if ( right > orgh + width ) orgh = right - width + extrah;

	if ( top < orgv )                  orgv = top - extrav;
	else if ( bottom > orgv + height ) orgv = bottom - height + extrav;

	wsetorigin(win, orgh, orgv);
}

