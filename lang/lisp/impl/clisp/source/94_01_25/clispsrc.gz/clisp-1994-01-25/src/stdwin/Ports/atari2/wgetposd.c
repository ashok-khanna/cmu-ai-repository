
#include "window.h"

void
wgetposdefwin(h, v)
int	*h;
int	*v;
{
	*h = x_def;
	*v = y_def;
}

