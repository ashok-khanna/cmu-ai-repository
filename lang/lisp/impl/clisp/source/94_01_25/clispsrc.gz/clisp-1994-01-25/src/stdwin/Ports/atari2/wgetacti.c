
#include "window.h"

WINDOW *
wgetactive()
{
	return(active);
}

