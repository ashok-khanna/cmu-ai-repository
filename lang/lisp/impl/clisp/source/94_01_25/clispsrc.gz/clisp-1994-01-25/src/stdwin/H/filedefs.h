/* File name parsing details: */
#define SEP '/'         /* Separator in path names */
#define CURDIR  "."     /* Current directory */

/* Flags for access(2) system call: */
#define RMODE   4
#define WMODE   2
#define XMODE   1
#define NOMODE  0
