
#include "window.h"

void
wsetdocsize(win, width, height)
WINDOW *win;
int width;
int height;
{
	if ( win == NULL ) return;

	win->doc_width = width;
	win->doc_height = height;

	setscrollbars(win);
}

