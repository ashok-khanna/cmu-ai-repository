
#include "window.h"

void
wsettimer (win, dtime)
WINDOW	*win;
int	dtime;
{
	if (win == NULL) return;
	win->alarm = ( dtime > 0 ) ? mclock() + (dtime * 100L): 0L;
}

