
#include "window.h"

void
wsetactive(win)
WINDOW *win;
{
	int	dummy = 0;

	if (win == NULL || win == active) return;
	rmcaret();
	wind_set(win->handle, WF_TOP, win->handle, dummy, dummy, dummy);
	active = win;
	showcaret();
}

