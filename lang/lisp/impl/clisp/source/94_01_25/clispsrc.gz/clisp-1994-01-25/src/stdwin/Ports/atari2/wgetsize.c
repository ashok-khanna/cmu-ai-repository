extern int w_def, h_def;

void
wgetsizedefwin(width, height)
int	*width;
int	*height;
{
	*width = w_def;
	*height = h_def;
}

