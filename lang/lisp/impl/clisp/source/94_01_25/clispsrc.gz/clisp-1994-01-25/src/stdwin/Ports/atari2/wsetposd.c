
#include "window.h"

void
wsetposdefwin(h, v)
int	h;
int	v;
{
/*
	Pop the stack of closed window positions.
*/
	num_w_pile = 0;

	if ( h < 0 ) h = 0;
	else if ( h >= scr_width ) h = scr_width - 1;

	if ( v < (BAR_HEIGHT+w_min_v_pos) ) v = BAR_HEIGHT+w_min_v_pos;
	if ( v > scr_height ) v = scr_height - 1;

	x_def = h;
	y_def = v;
}

