
#include "window.h"

/*
	Creates a new menu with a given title.
*/

void *
wmenucreate(id, title)
int id;
register char *title;
{
	register MENU *pm;
	char buf[20];
	register char *s;
	register int n = 17;

	pm = ALLOC(MENU);

	if ( pm == NULL ) return (NULL);

	pm->id = id;
	s = buf;
	*s++ = ' ';
	while ( n > 0 && *title ) { n--; *s++ = *title++; }
	*s++ = ' '; *s = 0;
	pm->title = strdup (buf);
	pm->local = deflocal;
	pm->maxlen = 0;
	L_INIT(pm->nritems, pm->itemlist);
	if ( !pm->local ) addtoall((void *)pm);
	return((void *)pm);
}

