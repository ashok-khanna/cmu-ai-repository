
#include "window.h"

int
wdrawchar(h, v, c)
int h;
int v;
int c;
{
	char buf[2];

	buf[0] = c;
	buf[1] = '\0';
	return(wdrawtext (h, v, buf, 1));
}

