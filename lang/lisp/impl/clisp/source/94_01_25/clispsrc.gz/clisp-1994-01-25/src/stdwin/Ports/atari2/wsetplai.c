
#include "stdwin.h"
#include "style.h"

void
wsetplain()
{
	wattr.style = PLAIN;
	setattr ();
}

