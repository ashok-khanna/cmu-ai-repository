
#include "window.h"

void
wnocaret(win)
WINDOW *win;
{
	if ( win == active ) rmcaret();

	win->caret_h = win->caret_v = -1;
}
