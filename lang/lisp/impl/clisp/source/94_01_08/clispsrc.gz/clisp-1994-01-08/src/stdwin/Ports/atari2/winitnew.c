void winit(void);

void
winitnew(pargc, pargv)
int *pargc;
char **pargv[];
{
	winit();
}

