
#include "stdwin.h"
#include "style.h"

void
wsetinverse()
{
	wattr.style |= INVERSE;
	setattr ();
}

