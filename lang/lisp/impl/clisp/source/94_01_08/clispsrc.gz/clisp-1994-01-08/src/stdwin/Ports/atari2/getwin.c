
#include "window.h"

WINDOW *
getwin(handle)
int handle;
{
	register WINDOW **w = winlist;
	register int	i   = nrwin;

	while ( --i >= 0 ) {
		if ( (*w)->handle == handle ) return(*w);
		w++;
	}

	return (NULL);
}

