
#include "window.h"

/*
	We need the special test on 0x800 because there are sometimes
	funny values like 1. Anything below 800 would give an access
	violation anyway, because that region is protected by the
	supervisor mode.
*/

void
resetfonts()
{
	WORKPARM w = vdiworkparams;
	if ( oldfont ) {
		do {
			w->font = oldfont;
		} while ( ( w = w->next ) >= (WORKPARM)0x800 );
		free(fontbuffer);
		fontbuffer = 0;
	}
}
