
#include "window.h"

void
wmessage(str)
char *str;
{
	char buf[256];
    char *s;

	strcpy(buf, "[1][");
	strcat(buf, str);
	strcat(buf, "][ Ok ]");

	s = buf;
	while ( *s ) {
		if ( *s == '\n' ) *s = '|';
		s++;
	}

	rmcaret();
	wind_update(BEG_UPDATE);
	(void)form_alert(1, buf);
	wind_update(END_UPDATE);
	showcaret();

	return;
}

