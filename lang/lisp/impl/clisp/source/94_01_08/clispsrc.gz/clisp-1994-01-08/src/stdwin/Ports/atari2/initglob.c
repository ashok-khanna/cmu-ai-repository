
#include "window.h"

int deflocal;
struct menubar globmenus;
int barchanged;
struct ln m_link[256];
OBJECT *menu;
struct key__tab keytab[256];

void
initglobmenus()
{
	void *pm;
	int i;

	deflocal = FALSE;
	barchanged = FALSE;
	menu = NULL;

	L_INIT (globmenus.nrmenus, globmenus.menulist);

	wmenusetdeflocal(FALSE);

	pm = wmenucreate(0, "Desk");
	wmenuadditem (pm, w_about, -1);
	wmenuadditem (pm, "", -1);

	for (i = 0; i < 6; i++) wmenuadditem(pm, "Desk Acc. Slot", -1);
	w_rootmenu = pm;
}

