
#include "window.h"

void
wgetwinorigin(win, ph, pv)
WINDOW *win;
int *ph;
int *pv;
{
	*ph = win->orgh;
	*pv = win->orgv;
}

