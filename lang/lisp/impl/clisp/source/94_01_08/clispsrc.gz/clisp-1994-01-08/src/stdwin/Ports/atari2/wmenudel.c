
#include "window.h"

void
wmenudelete(pm)
void *pm;
{
	int	i;

	delofbar(&globmenus, pm);

	for (i = 0; i < nrwin; i++) wmenudetach (winlist[i], pm);

	for (i = 0; i < ((MENU *)pm)->nritems; i++) {
		FREE (((MENU *)pm)->itemlist[i]->ittext);
		FREE (((MENU *)pm)->itemlist[i]->sctext);
		FREE (((MENU *)pm)->itemlist[i]->line);
	}
	L_DEALLOC (((MENU *)pm)->nritems, ((MENU *)pm)->itemlist);
	FREE (pm);
}

