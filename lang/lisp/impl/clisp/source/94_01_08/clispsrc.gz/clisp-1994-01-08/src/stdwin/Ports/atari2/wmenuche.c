
#include "window.h"

void
wmenucheck(pm, item, flag)
void *pm;
int item;
bool flag;
{
	struct m_item *it;

	if ( item < 0 || item >= ((MENU *)pm)->nritems ) return;

	it = ((MENU *)pm)->itemlist[item];

	if ( it->checked == flag ) return;

	it->checked = flag;

	if (menu != NULL) {
		int	obj = 4;
		int	i;

		for (i = 0; i < active->mbar.nrmenus; ++i) {
			MENU *mp = active->mbar.menulist[i];

			if (((MENU *)pm) == mp) break;

			obj += mp->nritems + 1;
		}

		obj += item + 1 + active->mbar.nrmenus;
		menu_icheck(menu, obj, it->checked);
	}
}

