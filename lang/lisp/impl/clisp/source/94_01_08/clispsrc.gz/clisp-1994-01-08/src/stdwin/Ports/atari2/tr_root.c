
#include "trees.h"

bool
tr_root(t)
TREE *t;
{
	t->focus = 0;
	return t->nobjs > 0;
}

