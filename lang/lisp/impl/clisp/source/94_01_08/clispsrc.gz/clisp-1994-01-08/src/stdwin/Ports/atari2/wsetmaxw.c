
#include "window.h"

void
wsetmaxwinsize(width, height)
int width;
int height;
{
	register int a;
	if ( width < MIN_WIDTH ) width = MIN_WIDTH;
	if ( width > ( a = scr_width - w_l_border - w_r_border ) ) width = a;

	if ( height < w_min_height ) height = w_min_height;
	if ( height > ( a = scr_height - BAR_HEIGHT - w_t_border - w_b_border ) ) height = a;

	max_width = width;
	max_height = height;

	if ( w_def > ( a = max_width + w_l_border + w_r_border ) ) w_def = a;
	if ( h_def > ( a = max_height + w_t_border + w_b_border ) ) h_def = a;
}

