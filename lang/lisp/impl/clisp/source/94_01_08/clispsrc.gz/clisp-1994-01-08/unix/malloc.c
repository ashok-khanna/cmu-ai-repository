/* compile:  cc -o malloc malloc.c
   try:      malloc 50000
             malloc 100000
             malloc 1000000
*/
#include <stdio.h>
int main (argc,argv)
  int argc;
  char** argv;
{ int arg = (argc>1 ? atoi(argv[1]) : 10000);
  unsigned long result = (unsigned long)malloc(arg);
  if (sizeof(unsigned long) <= 4)
    printf ("malloc(%d) = #x%8X\n",arg,
            (unsigned int)result
           );
  else
    printf ("malloc(%d) = #x%8X%08X\n",arg,
            (unsigned int)(result>>32),(unsigned int)(result&0xFFFFFFFF)
           );
  exit(0);
}
