/*
 * Corout.h -- Declarations for Scheme Coroutines
 *
 * (C) m.b (Matthias Blume); HUB; Sep 1993 PU/CS
 *         Princeton University, Dept. of Computer Science
 *
 * ident "@(#) Corout.h (C) M.Blume, Princeton University, 2.2"
 */

# ifndef COROUT_H_
# define COROUT_H_

# include "storage.h"

typedef
struct ScmCorout {
  MEM_descriptor _;
  void *state;
} ScmCorout;

DCL_MEM_TYPE (Corout);

extern ScmCorout *ScmMainCorout, *ScmCurrentCorout;

extern void ScmInitCoroutines (void);
extern ScmCorout *ScmNewCorout (void *cr_proc);

# endif
