/*
 * noreturn.h -- Declaration of never-returning functions...
 *
 * (C) m.b (Matthias Blume); HUB; Nov 1993 PU/CS
 *         Princeton University, Dept. of Computer Science
 *
 * ident "@(#) noreturn.h (C) M.Blume, Princeton University, 2.1"
 */

# ifndef NORETURN_H_
# define NORETURN_H_

# if defined (GNUC_ATTRIB)

# define NORETURN
# define NRUTERON __attribute__ ((noreturn))

# elif defined (GNUC_VOLATILE)

# define NORETURN volatile
# define NRUTERON

# else

# define NORETURN
# define NRUTERON

# endif

# endif
