/*
 * Character.h -- Declarations for Scheme Characters
 *
 * (C) m.b (Matthias Blume); Mar 1992, HUB; Jan 1993 PU/CS
 *         Humboldt-University of Berlin
 *         Princeton University, Dept. of Computer Science
 *
 * ident "@(#) Character.h (C) M.Blume, Princeton University, 2.2"
 */

# ifndef CHARACTER_H_
# define CHARACTER_H_

# include "storage.h"

typedef
struct ScmCharacter {
  MEM_descriptor _;
} ScmCharacter;

DCL_MEM_TYPE (Character);

extern ScmCharacter ScmCharacter_array[];

# define C_CHAR(c) ((ScmCharacter *) (c) - ScmCharacter_array)

# endif
