/*
 * Cons.h -- Declarations for Scheme Cons
 *
 * (C) m.b (Matthias Blume); Mar 1992, HUB; Jan 1993 PU/CS
 *         Humboldt-University of Berlin
 *         Princeton University, Dept. of Computer Science
 *
 * ident "@(#) Cons.h (C) M.Blume, Princeton University, 2.2"
 */

# ifndef CONS_H_
# define CONS_H_

# include "storage.h"

typedef
struct ScmCons {
  MEM_descriptor _;
  void *car;
  void *cdr;
} ScmCons;

DCL_MEM_TYPE (Cons);

# endif
