/*
 * fileno.c -- Implementation of a ``default'' fileno
 *
 * (C) m.b (Matthias Blume); Jan 1993 PU/CS
 *         Princeton University, Dept. of Computer Science
 *
 * ident "@(#) fileno.c (C) M.Blume, Princeton University, 2.1"
 */
# ident "@(#)fileno.c	(C) M.Blume, Princeton University, 2.1"

extern int fileno (void *file);

int fileno (void *file)
{
  return 9999;			/* Cannot figure out more */
}
