/*
 * Cell.h -- Declarations for Scheme Value Cells
 *
 * (C) m.b (Matthias Blume); Jan 1993 PU/CS
 *         Princeton University, Dept. of Computer Science
 *
 * ident "@(#) Cell.h (C) M.Blume, Princeton University, 2.2"
 */

# ifndef CELL_H_
# define CELL_H_

# include "storage.h"

typedef
struct ScmCell {
  MEM_descriptor _;
  void *item;
} ScmCell;

DCL_MEM_TYPE (Cell);

# endif
