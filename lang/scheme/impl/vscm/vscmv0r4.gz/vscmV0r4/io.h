/*
 * io.h -- Declarations for Schem's input/output
 *
 * (C) m.b (Matthias Blume); May 1992, HUB; Jan 1993 PU/CS
 *         Humboldt-University of Berlin
 *         Princeton University, Dept. of Computer Science
 *
 * ident "@(#) io.h (C) M.Blume, Princeton University, 2.1"
 */

# ifndef IO_H_
# define IO_H_

extern int file_getc (void *);
extern void file_ungetc (int, void *);
extern void file_putc (int, void *);

# endif
