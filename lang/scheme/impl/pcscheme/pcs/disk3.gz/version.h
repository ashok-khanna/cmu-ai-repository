#ifdef REGMEM
   #define VERSION "\n PC Scheme 3.03  07 June 88"
#endif
				       
#ifdef EXPMEM
   #define VERSION "\n PC Scheme 3.03  Expanded Memory Version   07 June 88"
#endif

#ifdef EXTMEM
   #define VERSION "\n PC Scheme 3.03  Extended Memory Version   07 June 88"
#endif

#ifdef PROMEM
   #define VERSION "\n PC Scheme 4.0   Protected Memory Version  24 June 88"
#endif
