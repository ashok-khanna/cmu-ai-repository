/*                                                      =====> SCHEME.H      */
#include "memtype.h"
#include "schmdefs.h"
