/* A list of DEFINES's for the various types of PCs */
#define UNKNOWN 0
#define TIPC    1
#define IBMPC   0x0ff
#define IBMXT   0x0fe
#define IBMJR   0x0fd
#define IBMAT   0x0fc
#define IBM80	0xf8h		;IBM PS/2 Model 80
#define IBMTYPE 0xf0h		;IBM machine types >= this value
