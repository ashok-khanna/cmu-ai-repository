#include "scheme.h"

#include <iostream.h>

class C {
public:
    int i;
    C() {
       cerr << "[invoking constructor]" << endl;
       i = 3;
    }
    ~C() { cerr << "[invoking destructor]" << endl; }
};

C c;

Object P_Test() {
    return Make_Integer(c.i);
}

void init_test() {
    Define_Primitive((Object (*)(...))P_Test, "test", 0, 0, EVAL);
}
