#include <scheme.h>

Object P_Set_Current_Input_Port(port) Object port; {
    Object old = Curr_Input_Port;
    Check_Input_Port(port);
    Curr_Input_Port = port;
    return old;
}

Object P_Set_Current_Output_Port(port) Object port; {
    Object old = Curr_Output_Port;
    Check_Output_Port(port);
    Curr_Output_Port = port;
    return old;
}

init_io_plus() {
    Define_Primitive(P_Set_Current_Input_Port, "set-current-input-port!",
		     1, 1, EVAL);
    Define_Primitive(P_Set_Current_Output_Port, "set-current-output-port!",
		     1, 1, EVAL);
}
