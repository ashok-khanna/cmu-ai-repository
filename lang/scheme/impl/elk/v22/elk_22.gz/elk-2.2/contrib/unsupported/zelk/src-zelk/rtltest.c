/* rtltest.c - sample, test, and template of a 'foreign library'
 * mod
 * 12nov
 */

#include <rtlpkg.h>

/*%%%%%%%%%%%%%%%% entries %%%%%%%%%%%%%%%%*/

#define FDEF_Mysub \
{  "Mysub",	(vfunction *)Mysub,	"SRI", },

static int Mysub(s) char *s;
{
   int len = strlen(s);
   printf("Mysub will return %d\n",len);
   return len;
} /*Mysub*/

/*%%%%%%%%%%%%%%%% scheme link %%%%%%%%%%%%%%%%*/

local struct fordef ftab[] = {
  FDEF_Mysub
  0
};

global FORPKG0 pkg_My = {
    0,					/*packagetype. 0=current*/
    (int (*)())0,			/*init_*/
    0,					/*stab,*/
    (struct fordef *)ftab,		/*ftab,*/
    (struct fordef_usage *)0		/*futab,*/
};

/* nov/92 - when this .o file is loaded, the routine below
   will be called; it returns the address of the table containing
   information to link the C routines in this file to scheme.
   There are no references to elk internals, however,
   so this file can also be used as an ordinary C library. 
 */
FORPKG0 *PKGrtn_My() { return &pkg_My; }
