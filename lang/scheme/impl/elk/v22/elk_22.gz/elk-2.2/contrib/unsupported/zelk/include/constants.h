/* envconstants.h zilla 
 */

#ifndef CONSTANTS_H
#define CONSTANTS_H

/* max desired size for a pathname */
#if Eunix
# define CMAXPATH 256
#endif
#if Emac
# define CMAXPATH 128
#endif

extern char Ctmpbuf[];
extern int Ctmpbuflen;

extern Efloat Cflt0,Cflt05,Cflt1,Cflt_1,Cflt2;
extern Efloat CfltPI,Cflt2PI,CfltPIo2;

#if Efloatconst
# define Cflt(x) x/**/F
#else
# define Cflt(x) ((float)x)
#endif

/* try to choose values which can be used on all machines.
 */

#if (1)
# if Empw
# define CMAXFLT	inf()
# define CBADFLT	nan()
#else
# define CMAXFLT	((float)1.0e37)
# define CBADFLT	((float)2.0e37)
#endif
# define MAXFLT	((float)1.0e37)
# define BADFLT ((float)2.0e37)
# define CMINFLT	((float)-1.0e37)
# define MINFLT	((float)-1.0e37)
#else
 : error :
#endif

#if	(Emips|Esparc|Empw)
# define CMAXINT	2147483647
# define CMININT	-2147483648
# define MAXINT		2147483647
# define MININT		-2147483648
#endif
#if	(Emac&&Elsc)
# define CMAXINT	2147483647L
# define CMININT	-2147483648L
#endif

#endif /*CONSTANTS_H*/
