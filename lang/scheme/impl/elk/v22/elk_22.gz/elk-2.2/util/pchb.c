extern char *sbrk();

#define VALMASK  ((1 << 24) - 1)

main() {
    char *p = sbrk(0);

    if ((unsigned long)p & ~VALMASK)
	printf("pointer_constant_high_bits=0x%lx\n",
	    (unsigned long)p & ~VALMASK);
    else
	printf("no pointer_constant_high_bits on this architecture.\n");
    return 0;
}
