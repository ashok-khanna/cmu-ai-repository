/* Definitions that were used in older versions of Elk, but are now
 * obsolete and should not be used any longer.
 */

#define Declare_C_Strings   Alloca_Begin
#define Make_C_String       Get_Strsym_Stack
#define Dispose_C_Strings   Alloca_End

#define Val(x)              Cdr(x)
