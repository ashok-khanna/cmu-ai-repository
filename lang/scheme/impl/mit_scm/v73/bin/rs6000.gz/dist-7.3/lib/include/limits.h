/* limits.h */
/* Produced by hard-params version 4.1, CWI, Amsterdam */


#ifndef CHAR_BIT
#define CHAR_BIT 8
#endif /* CHAR_BIT */

#ifndef CHAR_MAX
#define CHAR_MAX 255
#endif /* CHAR_MAX */

#ifndef CHAR_MIN
#define CHAR_MIN 0
#endif /* CHAR_MIN */

#ifndef UCHAR_MAX
#define UCHAR_MAX 255
#endif /* UCHAR_MAX */

#ifndef SHRT_MAX
#define SHRT_MAX 32767
#endif /* SHRT_MAX */

#ifndef SHRT_MIN
#define SHRT_MIN (-32768)
#endif /* SHRT_MIN */

#ifndef INT_MAX
#define INT_MAX 2147483647
#endif /* INT_MAX */

#ifndef INT_MIN
#define INT_MIN (-2147483648)
#endif /* INT_MIN */

#ifndef LONG_MAX
#define LONG_MAX 2147483647
#endif /* LONG_MAX */

#ifndef LONG_MIN
#define LONG_MIN (-2147483648)
#endif /* LONG_MIN */

#ifndef USHRT_MAX
#define USHRT_MAX 65535
#endif /* USHRT_MAX */

#ifndef UINT_MAX
#define UINT_MAX 4294967295
#endif /* UINT_MAX */

#ifndef ULONG_MAX
#define ULONG_MAX 4294967295
#endif /* ULONG_MAX */
