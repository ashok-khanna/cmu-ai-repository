#include <sys/times.h>

long
process_time ()
{
  struct tms buffer;
  times (&buffer);
  return (buffer . tms_utime);
}
