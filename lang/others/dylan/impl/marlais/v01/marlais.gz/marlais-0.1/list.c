/*

   list.c

   Copyright, 1993, Brent Benson.  All Rights Reserved.

   Permission to use, copy, and modify this software and its
   documentation is hereby granted only under the following terms and
   conditions.  Both the above copyright notice and this permission
   notice must appear in all copies of the software, derivative works
   or modified version, and both notices must appear in supporting
   documentation.  Users of this software agree to the terms and
   conditions set forth in this notice and agree to inform the author,
   Brent Benson, of any noteworthy uses of this software.

*/

#include "list.h"
#include "prim.h"
#include "apply.h"
#include "number.h"
#include "symbol.h"
#include "boolean.h"

/* primitives */

/* local function prototypes */
static Object set_car (Object pair, Object val);
static Object set_cdr (Object pair, Object val);
static Object list_element (Object pair, Object index);
static Object list_element_setter (Object pair, Object index, Object obj);
static Object list_length_int (Object lst);
static Object list_reverse_bang (Object lst);
static Object list_reverse (Object lst);
static Object list_last (Object lst);

static struct primitive list_prims[] =
{
  {"%pair", prim_2, cons},
  {"%head", prim_1, car},
  {"%tail", prim_1, cdr},
  {"%head-setter", prim_2, set_car},
  {"%tail-setter", prim_2, set_cdr}, 
  {"%list-element", prim_2, list_element},
  {"%list-element-setter", prim_3, list_element_setter}, 
  {"%list-map1", prim_2, list_map1},
  {"%list-append", prim_2, append},
  {"%list-member?", prim_3, member_p},
  {"%list-reduce", prim_3, list_reduce},
  {"%list-reduce1", prim_2, list_reduce1},
  {"%list-length", prim_1, list_length_int},
  {"%list-reverse!", prim_1, list_reverse_bang},
  {"%list-reverse", prim_1, list_reverse},
  {"%list-last", prim_1, list_last},
};

void 
init_list_prims (void)
{
  int num;

  num = sizeof (list_prims) / sizeof (struct primitive);
  init_prims (num, list_prims);
}

Object 
make_empty_list (void)
{
#ifndef SMALL_OBJECTS
  Object obj;

  obj = allocate_object (sizeof (struct object));
  TYPE (obj) = EmptyList;
  return (obj);
#else
  return (EMPTYLISTVAL);
#endif
}

/* This gets called with (make <list> args)
*/
Object 
make_list_driver (Object args)
{
  int size;
  Object size_obj, fill_obj, res;
  Object size_keyword, fill_keyword;

  size = 0;
  size_obj = NULL;
  fill_obj = NULL;
  size_keyword = make_keyword ("size:");
  fill_keyword = make_keyword ("fill:");
  while (! NULLP (args))
    {
      if (FIRST (args) == size_keyword)
	{
	  size_obj = SECOND (args);
	}
      else if (FIRST (args) == fill_keyword)
	{
	  fill_obj = SECOND (args);
	}
      else
	{
	  error ("make: unsupported keyword for <list> class", FIRST (args), NULL);
	}
      args = CDR (CDR (args));
    }
  if (size_obj)
    {
      if (! INTEGERP (size_obj))
	{
	  error ("make: value of size: argument must be an integer", size_obj, NULL);
	}
      size = INTVAL (size_obj);
    }
  if (! fill_obj)
    {
      fill_obj = false_object;
    }
  
  /* actually fabricate the list */
  if (size == 0)
    {
      return (empty_list);
    }
  else
    {
      res = empty_list;
      while (size)
	{
	  res = cons (fill_obj, res);
	  size--; 
	}
      return (res);
    }
}

Object 
cons (Object car, Object cdr)
{
  Object obj;

  obj = allocate_object (sizeof (struct pair));
  PAIRTYPE (obj) = Pair;
  CAR (obj) = car;
  CDR (obj) = cdr;
  return (obj);
}

Object 
car (Object lst)
{
  return (CAR (lst));
}

Object 
cdr (Object lst)
{
  return (CDR (lst));
}

Object
second (Object lst)
{
  return (SECOND (lst));
}

Object 
third (Object lst)
{
  return (THIRD (lst));
}

Object 
map (Object (*fun)(Object), Object lst)
{
  if (lst == empty_list)
    {
      return (empty_list);
    }
  else
    {
      return (cons ((*fun)(CAR(lst)), map (fun, CDR(lst))));
    }
}

Object 
map2 (Object (*fun)(Object, Object), Object l1, Object l2)
{
  if ((l1 == empty_list) || (l2 == empty_list))
    {
      return (empty_list);
    }
  else
    {
      return (cons ((*fun)(CAR(l1), CAR(l2)), map2 (fun, CDR(l1), CDR(l2))));
    }
}

Object
list_map1 (Object fun, Object lst)
{
  if (lst == empty_list)
    {
      return (empty_list);
    }
  else
    {
      return (cons (apply (fun, cons (CAR (lst), empty_list)),
		    list_map1 (fun, (CDR (lst)))));
    }
}

Object
list_map2 (Object fun, Object l1, Object l2)
{
  if ((l1 == empty_list) || (l2 == empty_list))
    {
      return (empty_list);
    }
  else
    {
      return (cons (apply (fun, listem (CAR (l1), CAR (l2), NULL)),
		    list_map2 (fun, CDR (l1), CDR (l2))));
    }
}

static Object 
list_length_int (Object lst)
{
  return (make_integer (list_length (lst)));
}

Object 
append (Object l1, Object l2)
{
  if (NULLP(l1))
    {
      return (l2);
    }
  else
    {
      return (cons (CAR(l1), append (CDR(l1), l2)));
    }
}

Object 
member_p (Object obj, Object lst, Object test)
{
  Object l;

  l = lst;
  while (! NULLP (l))
    {
      if ( test )
	{
	  if (apply (test, listem (obj, CAR (l), NULL)) != false_object)
	    {
	      return (true_object);
	    }
	}
      else
	{
	  if (id_p (obj, CAR(l), empty_list) != false_object)
	    {
	      return (true_object);
	    }
	}
      l = CDR (l);
    }
  return (false_object);
}

Object 
listem (Object car, ...)
{
  Object lst, fst, el, acons, cur;
  va_list args;
  
  fst = cur = acons = cons (car, empty_list);
  va_start (args, car);
  el = va_arg (args, Object);
  while ( el )
    {
      acons = cons (el, empty_list);
      CDR (cur) = acons;
      cur = acons;
      el = va_arg (args, Object);
    }
  return (fst);
}

Object 
list_reduce (Object fun, Object init, Object lst)
{
  Object val, vals;

  val = init;
  while (! NULLP(lst))
    {
      val = apply (fun, listem (val, CAR(lst), NULL));
      lst = CDR (lst);
    }
  return (val);
}

Object 
list_reduce1 (Object fun, Object lst)
{
  Object val, vals;

  val = CAR (lst);
  lst = CDR (lst);
  while (! NULLP (lst))
    {
      val = apply (fun, listem (val, CAR (lst), NULL));
      lst = CDR (lst);
    }
  return (val);
}

int 
list_length (Object lst)
{
  int len;

  len = 0;
  while ( lst != empty_list )
    {
      len++;
      lst = CDR (lst);
    }
  return (len);
}

static Object 
set_car (Object pair, Object val)
{
  CAR(pair) = val;
  return (val);
}

static Object 
set_cdr (Object pair, Object val)
{
  CDR(pair) = val;
  return (val);
}

static Object 
list_element (Object pair, Object index)
{
  int i;
  Object lst;

  i = INTVAL(index);
  lst = pair;
  while ( i )
    {
      i--;
      lst = CDR (lst);
      if (NULLP (lst))
	{
	  error ("element: no such element", index, pair, NULL);
	}
    }
  return (CAR (lst));
}

static Object 
list_element_setter (Object pair, Object index, Object obj)
{
  int i, el;
  Object lst;

  i = 0;
  el = INTVAL (index);
  lst = pair;
  while (! NULLP (lst))
    {
      if ( i == el )
	{
	  CAR (lst) = obj;
	  return (obj);
	}
      i++;
      lst = CDR (lst);
    }
  error ("element-setter: index to large for list", pair, index, NULL);
}

static Object 
list_reverse_bang (Object lst)
{
  Object cur, next;

  cur = empty_list;
  while ( ! NULLP (lst))
    {
      next = CDR (lst);
      CDR (lst) = cur;
      cur = lst;
      lst = next;
    }
  return (cur);
}

static Object
list_reverse (Object lst)
{
  Object cur, last;

  last = empty_list;
  while ( ! NULLP (lst))
    {
      last = cons (CAR (lst), last);
      lst = CDR (lst);
    }
  return (last);
}

static Object
list_last (Object lst)
{
  Object last;

  while (! NULLP (lst))
    {
      last = CAR (lst);
      lst = CDR (lst);
    }
  return (last);
}

int 
list_equal (Object l1, Object l2)
{
  if (id_p (l1, l2, empty_list) != false_object)
    {
      return (1);
    }
  if (PAIRP (l1) && PAIRP (l2))
    {
      return (list_equal (CAR (l1), CAR (l2)) &&
	      list_equal (CDR (l1), CDR (l2)));
    }
  else
    {
      return (0);
    }
}
