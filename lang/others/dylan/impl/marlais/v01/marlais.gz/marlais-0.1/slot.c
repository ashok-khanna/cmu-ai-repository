/*

   slot.c

   Copyright, 1993, Brent Benson.  All Rights Reserved.

   Permission to use, copy, and modify this software and its
   documentation is hereby granted only under the following terms and
   conditions.  Both the above copyright notice and this permission
   notice must appear in all copies of the software, derivative works
   or modified version, and both notices must appear in supporting
   documentation.  Users of this software agree to the terms and
   conditions set forth in this notice and agree to inform the author,
   Brent Benson, of any noteworthy uses of this software.

*/

#include "slot.h"
#include "keyword.h"

/* primitives */

static struct primitive slot_prims[] =
{
  {"slot-value", prim_2, slot_value},
  {"set-slot-value!", prim_3, set_slot_value},
};

/* function definitions */

void
init_slot_prims (void)
{
  int num;

  num = sizeof (slot_prims) / sizeof (struct primitive);
  init_prims (num, slot_prims);
}

Object 
slot_name (Object slot)
{
  if (! PAIRP(slot))
    {
      return (slot);
    }
  else
    {
      return (CAR (slot));
    }
}

Object 
slot_getter (Object slot)
{
  Object get_list;

  if (! PAIRP (slot))
    {
      return (NULL);
    }
  else
    {
      return (find_keyword_val (getter_keyword, slot));
    }
}

Object 
slot_setter (Object slot)
{
  Object set_list;

  if (! PAIRP (slot))
    {
      return (NULL);
    }
  else
    {
      return (find_keyword_val (setter_keyword, slot));
    }
}

Object 
slot_type (Object slot)
{
  Object type_list;

  if (! PAIRP (slot))
    {
      return (NULL);
    }
  else
    {
      return (find_keyword_val (type_keyword, slot));
    }
}

Object 
slot_init_value (Object slot)
{
  Object init_list;

  if (! PAIRP (slot))
    {
      return (NULL);
    }
  else
    {
      return (find_keyword_val (init_value_keyword, slot));
    }
}

Object 
slot_init_function (Object slot)
{
  Object init_list;

  if (! PAIRP (slot))
    {
      return (NULL);
    }
  else
    {
      return (find_keyword_val (init_function_keyword, slot));
    }
}

Object 
slot_init_keyword (Object slot)
{
  Object init_list;

  if (! PAIRP (slot))
    {
      return (NULL);
    }
  else
    {
      return (find_keyword_val (init_keyword_keyword, slot));
    }
}

Object 
slot_required_init_keyword (Object slot)
{
  Object init_list;

  if (! PAIRP (slot))
    {
      return (NULL);
    }
  else
    {
      return (find_keyword_val (required_init_keyword_keyword, slot));
    }
}

Object 
slot_allocation (Object slot)
{
  Object alloc_list;

  if (! PAIRP (slot))
    {
      return (NULL);
    }
  else
    {
      return (find_keyword_val (allocation_keyword, slot));
    }
}

Object 
slot_value (Object instance, Object sname)
{
  Object slots, slot;

  slots = INSTSLOTS (instance);
  while (! NULLP (slots))
    {
      slot = CAR (slots);
      if (sname == CAR (slot))
	{
	  return (CDR (slot));
	}
      slots = CDR (slots);
    }
  error ("slot-value: no value for slot in instance", sname, instance, NULL);
}

Object
set_slot_value (Object instance, Object name, Object val)
{
  Object slots, slot;

  slots = INSTSLOTS (instance);
  while (! NULLP (slots))
    {
      slot = CAR (slots);
      if (name == CAR (slot))
	{
	  CDR (slot) = val;
	  return (val);
	}
      slots = CDR (slots);
    }
  error ("set-slot-value!: no such slot in instance", name, instance, NULL);
}
