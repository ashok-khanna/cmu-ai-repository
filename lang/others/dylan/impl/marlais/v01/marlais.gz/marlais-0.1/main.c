/*

   main.c

   Copyright, 1993, Brent Benson.  All Rights Reserved.

   Permission to use, copy, and modify this software and its
   documentation is hereby granted only under the following terms and
   conditions.  Both the above copyright notice and this permission
   notice must appear in all copies of the software, derivative works
   or modified version, and both notices must appear in supporting
   documentation.  Users of this software agree to the terms and
   conditions set forth in this notice and agree to inform the author,
   Brent Benson, of any noteworthy uses of this software.

*/

#include "object.h"
#include "alloc.h"
#include "read.h"
#include "eval.h"
#include "print.h"
#include "boolean.h"
#include "symbol.h"
#include "list.h"
#include "class.h"
#include "slot.h"
#include "file.h"
#include "function.h"
#include "values.h"
#include "print.h"
#include "number.h"
#include "apply.h"
#include "string.h"
#include "keyword.h"
#include "vector.h"
#include "error.h"
#include "syntax.h"
#include "stream.h"
#include "table.h"
#include "misc.h"

void initialize_marlais (void);

#ifndef INIT_FILE
#define INIT_FILE "init.dyl"
#endif 

#ifndef VERSION
#define VERSION "0.1"
#endif

static int do_not_load_init_file = 0;
static char *optstring = "n";

main(int argc, char *argv[])
{
  Object obj, eobj;
  char *init_file;
  int err, c;
  extern char *optarg;
  extern int optind;

  /* banner */
  printf ("Marlais %s\n", VERSION);

  /* initialization */
  initialize_marlais ();

  /* process command line parameters except source files */
  while ((c = getopt (argc, argv, optstring)) != EOF)
    {
      switch (c)
	{
	case 'n':
	  do_not_load_init_file = 1;
	  break;
	default:
	  fatal ("fatal: unrecognized option");
	}
    } 

  /* load initialization code */
  if (! do_not_load_init_file)
    {
      init_file = getenv ("MARLAIS_INIT");
      if (init_file)
	{
	  load (make_byte_string (init_file));
	}
      else
	{
	  load (make_byte_string (INIT_FILE));
	}
    }

  /* load any source files specified on command line */
  while (optind < argc)
    {
      load (make_byte_string (argv[optind]));
      optind++;
    }

  /* errors reset to here */
  err = setjmp (error_return);
  /* things to do on an error reset */ 
  if ( err )
    {
      if (trace_functions)
	{
	  printf ("; reset\n");
	  trace_level = 0;
	}
    }

  /* read-eval-print loop */
  printf ("? ");
  while ((obj = read_object (stdin)) && (obj != eof_object))
    {
      eobj = eval (obj);
      print_obj (eobj);
      printf ("? ");
    }
}

void 
initialize_marlais (void)
{
  /* intialize garbage collector
   */
  initialize_gc ();

  /* intialize global objects 
   */
  true_object = make_true ();
  false_object = make_false ();
  empty_list = make_empty_list ();
  key_symbol = make_symbol ("#key");
  rest_symbol = make_symbol ("#rest");
  next_symbol = make_symbol ("#next");
  quote_symbol = make_symbol ("quote");
  eof_object = make_eof_object ();
  unspecified_object = make_unspecified_object ();
  unwind_symbol = make_symbol ("%unwind");
  next_method_symbol = make_symbol ("next-method");
  initialize_symbol = make_symbol ("initialize");
  equal_hash_symbol = make_symbol ("=hash");
  uninit_slot_object = make_uninit_slot ();
  standard_input_stream = make_stream (Input, stdin);
  standard_output_stream = make_stream (Output, stdout);
  standard_error_stream = make_stream (Output, stderr);

  /* often used keywords
   */
  getter_keyword = make_keyword ("getter:");
  setter_keyword = make_keyword ("setter:");
  else_keyword = make_keyword ("else:");
  type_keyword = make_keyword ("type:");
  init_value_keyword = make_keyword ("init-value:");
  init_function_keyword = make_keyword ("init-function:");
  init_keyword_keyword = make_keyword ("init-keyword:");
  required_init_keyword_keyword = make_keyword ("required-init-keyword:");
  allocation_keyword = make_keyword ("allocation:");

  /* initialize table of syntax operators and functions
   */
  init_syntax_table ();

  /* initialize builtin classes
   */
  init_class_hierarchy ();

  /* initialize primitives
   */
  init_list_prims ();
  init_class_prims ();
  init_slot_prims ();
  init_file_prims ();
  init_function_prims ();
  init_values_prims ();
  init_print_prims ();
  init_number_prims ();
  init_apply_prims ();
  init_boolean_prims ();
  init_keyword_prims ();
  init_string_prims ();
  init_vector_prims ();
  init_error_prims ();
  init_stream_prims ();
  init_read_prims ();
  init_table_prims ();
  init_misc_prims ();
  init_char_prims ();
}

