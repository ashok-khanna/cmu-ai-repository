/* This module implements garbage collected storage for C programs using a
   generational version of the "mostly-copying" garbage collection algorithm.

   Copyright (c) 1989, Digital Equipment Corp.  All rights reserved.

   For a discussion of the interface, see the .h file.

   For a discussion of the "mostly copying" garbage collection algorithm, see
   "Compacting Garbage Collection with Ambiguous Roots", WRL Research Report
   88/2, February 1988, and "Mostly-Copying Garbage Collection Picks Up
   Generations and C++", WRL Technical Note TN-12, October 1989.
*/

/*
 *              Copyright 1990 Digital Equipment Corporation
 *                         All Rights Reserved
 *
 * Permission to use, copy, and modify this software and its documentation is
 * hereby granted only under the following terms and conditions.  Both the
 * above copyright notice and this permission notice must appear in all copies
 * of the software, derivative works or modified versions, and any portions
 * thereof, and both notices must appear in supporting documentation.
 *
 * Users of this software agree to the terms and conditions set forth herein,
 * and hereby grant back to Digital a non-exclusive, unrestricted, royalty-free
 * right and license under any changes, enhancements or extensions made to the
 * core functions of the software, including but not limited to those affording
 * compatibility with other hardware or software environments, but excluding
 * applications which incorporate this software.  Users further agree to use
 * their best efforts to return to Digital any such changes, enhancements or
 * extensions that they make and inform Digital of noteworthy uses of this
 * software.  Correspondence should be provided to Digital at:
 *
 *                       Director of Licensing
 *                       Western Research Laboratory
 *                       Digital Equipment Corporation
 *                       250 University Avenue
 *                       Palo Alto, California  94301
 *
 * This software may be distributed (but not offered for sale or transferred
 * for compensation) to third parties, provided such third parties agree to
 * abide by the terms and conditions of this notice.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND DIGITAL EQUIPMENT CORP. DISCLAIMS ALL
 * WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS.   IN NO EVENT SHALL DIGITAL EQUIPMENT
 * CORPORATION BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL
 * DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
 * PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS
 * ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
 * SOFTWARE.
 */

/* Version tag */

char*  gcalloc_version = { "gcalloc_12jun92jfb" };

/* External definitions */

#include <stdio.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#if defined (mips) || defined (vax)
#include <machine/param.h>
#endif

extern char  *getenv( /* char* name */ );

extern void  bzero( /* char* string, int length */ );

extern char *malloc( /* unsigned size */ );

#define NEW_CHAR( x ) malloc( (x) )

#define NEW_INT( x ) (int*)malloc( (x)*sizeof( int ) )

       /***********************************
	* Processor Dependnt Definitions *
	***********************************/

/* MIPS */
#ifdef mips
#include <machine/vmparam.h>

#define  STACKINC  4 /* Assume stack alignment on 32-bit words. */
#define  REGISTER_COUNT 9 /* Need to save and examine registers s0-s8. */

/* Static area bounds */
extern unsigned  end;
#define STATIC_0 ((unsigned*)USRDATA)
#define STATIC_1 (&end)

/* Objects must be double aligned */
#ifndef MISALIGN
#define	DOUBLE_ALIGN 1
#endif
static char*  gcstackbase = (char*)USRSTACK;
#endif /* mips */


/* VAX */
#ifdef vax
#include <machine/vmparam.h>
o
#define  STACKINC  4 /* Assume stack alignment on 32-bit words. */
#define  REGISTER_COUNT 10 /* Need to save and examine registers 2-10. */

/* Static area bounds */
extern unsigned  etext, end;
#define STATIC_0 ((unsigned*)(((((int)&etext)+NBPG-1)/NBPG)*NBPG))
#define STATIC_1 (&end)

static char*  gcstackbase = (char*)USRSTACK;

#endif /* vax */

/* Harris Nighthawk */
#if defined(_CX_UX) && defined (_M88K)
#define STACKINC 4         /* stack alignment on 32-bit words */
#define REGISTER_COUNT 11  /* need to save and examine r14 to r25 */

extern unsigned end, edata;

#define STATIC_0 (&edata)
#define STATIC_1 (&end)

#define DOUBLE_ALIGN 1
static char*  gcstackbase = ((char*)0xefffffff);

#endif

/* Linux PC */
#ifdef linux
#define STACKINC 4
#define REGISTER_COUNT 0

extern unsigned etext, edata;

#define STATIC_0 (&etext)
#define STATIC_1 (&edata)

static char* gcstackbase = ((char*)0xbfffffff);

#endif

/* RS/6000 */
#ifdef rs6000
#define STACKINC 4      /* stack alignment on 32-bit words */
#define REGISTER_COUNT  /* need to save and examine r13-r31 */

extern unsigned etext, end;
#define STATIC_0 (&etext)
#define STATIC_1 (&end)
#endif

/* Copys registers into the static area and returns the top of stack. */

extern unsigned*  gcregisters( /* unsigned* registers */ );

       /**************************************
	* Garbage Collected Heap Definitions *
	**************************************/

/* The heap consists of a discontiguous set of pages of memory, where each
   page is PAGEBYTES long.  N.B.  the page size for garbage collection is
   independent of the processor's virtual memory page size.  */

static int  firstheappage,	/* Page # of first heap page */
	    lastheappage,	/* Page # of last heap page */
	    heappages,		/* # of pages in the heap */
	    heapspanpages,	/* # of pages that span the heap */
	    freewords,		/* # words left on the current page */
	    *freep,		/* Ptr to the first free word on the current
				   page */
	    allocatedpages,	/* # of pages currently allocated for
				   storage */
	    stablepages,	/* # of pages in the stable set */
	    freepage,		/* First possible free page */
	    *space,		/* Space number for each page */
	    *plink,		/* Page link for each page */
	    *type,		/* Type of object allocated on the page */
	    *firstword,		/* Bitmap of 1st words of user objects */
	    queue_head,		/* Head of list of stable set of pages */
	    queue_tail,     	/* Tail of list of stable set of pages */
	    current_space,	/* Current space number */
	    next_space;		/* Next space number */

/* Page types */

#define OBJECT 0
#define CONTINUED 1

/* Space values */

#define UNALLOCATEDPAGE -2
#define FREEPAGE 1
#define STABLE( x ) 	((~space[ (x) ]) & 1)
#define UNSTABLE( x ) 	(space[ (x) ] & 1)

/* PAGEBYTES controls the number of bytes/page */

#define PAGEBYTES 512
#define PAGEWORDS (PAGEBYTES/sizeof(int))
#define WORDBYTES (sizeof(int))
#define HEAPPERCENT( x ) (((x)*100)/heappages)

/* Page number <--> pointer conversion is done by the following defines */

#define PAGE_to_GCP( p ) ((GCP)((p)*PAGEBYTES))
#define GCP_to_PAGE( p ) (((int)p)/PAGEBYTES)

/* Objects that are allocated in the heap have a one word header.  The form
   of the header is:

	 31           22 21 	        1 0
	+---------------+----------------+-+  
	| callback indx	| # words in obj |1|
	+---------------+----------------+-+
	|	   user data		   |  <-- user data starts here.
		       .		
		       .
		       .
	|				   |
	+----------------------------------+

   The number of words in the object count INCLUDES one word for the header.

   When an object is forwarded, the header is replaced by the pointer to
   the new object that will have bit 0 equal to 0.
*/

#define MAKE_CALLBACK( index ) ((index)<<22 | 1)
#define MAKE_HEADER( words, callback ) ((words)<<1 | (callback))
#define FORWARDED( header ) (((header) & 1) == 0)
#define HEADER_CALLBACK( header ) ((header)>>22 & 0x3FF)
#define HEADER_WORDS( header ) ((header)>>1 &0x1FFFFF )
#define HEADER_BYTES( header ) (((header)>>1 & 0x1FFFFF)*WORDBYTES)
#ifdef DOUBLE_ALIGN
#define ONEPAGEOBJ_WORDS (PAGEWORDS-1)
#define HEADER_PAGES( header ) ((HEADER_WORDS( header )+PAGEWORDS)/PAGEWORDS)
#else
#define ONEPAGEOBJ_WORDS PAGEWORDS
#define HEADER_PAGES( header ) ((HEADER_WORDS( header )+PAGEWORDS-1)/PAGEWORDS)
#endif
#define MAX_HEADER_WORDS 0x1FFFFF		/* 2,097,151 = ~8MB */
#define MAX_HEADER_CALLBACK 0x3FF		/* 1023 */

/* The first word of user objects is noted in the firstword bit map.  This 
   allows gcmove to rapidly detect a derived pointer and convert it into an
   object and an offset.
*/

#define BIT_BYTES (PAGEWORDS/8)
#define	BIT_WORDS (PAGEWORDS/32)
#define ISA_FIRSTWORD( p ) (firstword[ ((int)p)/(PAGEBYTES/BIT_WORDS) ] &     \
			    1<<( ((int)p)>>2 & 0x1F ))
#define SET_FIRSTWORD( p ) (firstword[ ((int)p)/(PAGEBYTES/BIT_WORDS) ] |=    \
			    1<<( ((int)p)>>2 & 0x1F ))

/* The heap map is maintained using ezd.  Objects are drawn on display. */

static FILE*  display;

       /************************************
        * Exported Initializer Definitions *
	************************************/

#include "gcalloc.h"

/* gcheap is called to configure the size of the initial heap, the expansion
   increment, the maximum size of the heap, the allocation percentage to force
   a total collection, the allocation percentage to force heap expansion, and
   garbage collection options.
*/

/* Default heap configuration */

#define	GCMINBYTES	1048576		/* # of bytes of initial heap */
#define GCMAXBYTES	2147483647	/* # of bytes of the final heap */
#define GCINCBYTES	1048576		/* # of bytes of each increment */
#define GCALLPERCENT	35		/* % allocated to force total gc */
#define GCINCPERCENT	25		/* % allocated to force expansion */
#define GCFLAGS		0		/* option flags */

/* Actual heap configuration */

static int  gcminbytes = GCMINBYTES,	/* # of bytes of initial heap */
	    gcmaxbytes = GCMAXBYTES,	/* # of bytes of the final heap */
	    gcincbytes = GCINCBYTES,	/* # of bytes of each increment */
	    gcallpercent = GCALLPERCENT,/* % allocated to force total
					   collection */
	    gcincpercent = GCINCPERCENT,/* % allocated to force expansion */
	    gcflags = GCFLAGS,		/* option flags */
	    gcdefaults = 1,		/* default setting in force */
	    gcheapcreated = 0;		/* boolean indicating heap created */

void  gcheap( minheapbytes, maxheapbytes, incheapbytes, allpercent,
	      incpercent, flags )
	int minheapbytes,
	    maxheapbytes,
	    incheapbytes,
	    allpercent,
	    incpercent,
	    flags;
{
	if  (gcheapcreated == 0  &&  minheapbytes > 0  &&
	     (gcdefaults || maxheapbytes >= gcmaxbytes))  {
	   gcdefaults = 0;
	   gcminbytes = minheapbytes;
	   gcmaxbytes = maxheapbytes;
	   gcincbytes = incheapbytes;
	   gcallpercent = allpercent;
	   gcincpercent = incpercent;
	   if  (gcminbytes < 4*PAGEBYTES)  gcminbytes = 4*PAGEBYTES;
	   if  (gcmaxbytes < gcminbytes)  gcmaxbytes = gcminbytes;
	   if  (gcallpercent < 0  ||  gcallpercent > 50)
	      gcallpercent = GCALLPERCENT;
	   if  (gcincpercent < 0  ||  gcincpercent > 50)
	      gcincpercent = GCINCPERCENT;
	}
	gcflags = gcflags | flags;
}

/* The following structure contains the callback procedures registered with
   the garbage collector.  It is allocated from the non-garbage collected
   heap.
*/

static int  callbacks_count = 0;
static int  callbacks_size = 0;
#define callbacks_inc 100

static struct  callback_struct  {
	GCCALLBACKPROC  proc;	/* GCPointers method */
	char*  type;		/* Type name */
	int  number;		/* Number of the type in heap */
	int  bytes;		/* Number of bytes of the type in heap */ 
}  *callbacks;

/* Freespace objects have a null callback that stored in callbacks[ 0 ].  Pad
   objects for double alignment have a null callback in callbacks[ 1 ].  The
   header for a one-word double alignment pad is kept in doublepad.
*/

static int  freespace_callback = MAKE_CALLBACK( 0 );

static  void freespace_pointers( /* GCP dummy */ ) {};

#ifdef DOUBLE_ALIGN
static int  doublepad;
#endif

/* Callback procedures are "registered" with the garbage collector by the
   following procedure.
*/

GCCB  gcregistercallback( proc, type )
	GCCALLBACKPROC  proc;
	char* type;
{
	struct callback_struct  *np;
	int  i;

	if  (callbacks_count > MAX_HEADER_CALLBACK)  {
	   fprintf( stderr,
	   	    "\n***** gcalloc  %d user classes already defined\n",
	   	    MAX_HEADER_CALLBACK-1 );
	   abort();
	}
	if  (callbacks_count == callbacks_size)  {
	   np = (struct callback_struct*)malloc( (callbacks_size+callbacks_inc)
		   			*sizeof( struct callback_struct ) );
	   for  (i = 0; i < callbacks_count; i++)  np[ i ] = callbacks[ i ];
	   free( callbacks );
	   callbacks = np;
	   callbacks_size = callbacks_size+callbacks_inc;
	   if  (callbacks_count == 0)  {
	      callbacks[ 0 ].proc = freespace_pointers;
	      callbacks[ 0 ].type = "GCFreeSpace";
	      callbacks[ 1 ].proc = freespace_pointers;
	      callbacks[ 1 ].type = "GCDoublePad";
	      callbacks_count = 2;
	   }
	}
	callbacks[ callbacks_count ].proc = proc;
	callbacks[ callbacks_count ].type = type;
	return  MAKE_CALLBACK( callbacks_count++ );
}

/* The following structure contains the additional roots registered with
   the garbage collector.  It is allocated from the non-garbage collected
   heap.
*/

static int  roots_count = 0;
static int  roots_size = 0;
#define roots_inc 10

static struct  roots_struct  {
	unsigned*  addr;	/* Address of the roots */
	int  bytes;		/* Number of bytes in the roots */ 
}  *roots;

/* Additional roots are "registered" with the garbage collector by the
   following procedure.
*/

void  gcroots( addr, bytes )
	char*  addr;
	int  bytes;
{
	struct roots_struct  *np;
	int  i;

	if  (roots_count == roots_size)   {
	   np = (struct roots_struct*)malloc( (roots_size+roots_inc)*
	   				      sizeof( struct roots_struct ) );
	   for  (i = 0; i < roots_count; i++)  np[ i ] = roots[ i ];
	   free( roots );
	   roots = np;
	   roots_size = roots_size+roots_inc;
	}
	roots[ roots_count ].addr = (unsigned*)addr;
	roots[ roots_count ].bytes = bytes;
	roots_count = roots_count+1;
}

       /****************************
	* Mostly Copying Collector *
	****************************/

/* Get heap configuration information from the environment.  Return true if
   the value is provided.
*/

static int  environment_value( name, value )
	char*  name;
	int*  value;
{
	char* valuestring = getenv( name );

	if (valuestring != NULL)  {
	   *value = atoi( valuestring );
	   return  1;
	}
	return  0;
}

/* Colors to use for free storage. */

static  char* freecolors[16] =
	{ 0, "red", 0, "turquoise", 0, "green", 0, "yellow",
          0, "red", 0, "turquoise", 0, "green", 0, "yellow" };

/* The following procedure writes the header on the heap display. */
	
static void  display_headers( phase )
	char*  phase;
{
	fputs( "(object header", display );
	fprintf( display, "(fill-rectangle 10 0 10 10 %s)",
		 freecolors[ (current_space % 8)+2 ] );
	fprintf( display, "(fill-rectangle 22 0 10 10 %s)",
		 freecolors[ (current_space % 8)+4 ] );
	fprintf( display, "(fill-rectangle 34 0 10 10 %s)",
		 freecolors[ (current_space % 8)+6 ] );
	fputs( "(text 50 1 \"Free space\" \"8x13\")", display );
	fprintf( display, "(fill-rectangle 140 0 10 10 %s)",
		 freecolors[ (current_space % 8) ] );
	fputs( "(text 156 1 \"Recently Allocated\" \"8x13\")", display );
	fputs( "(fill-rectangle 310 0 10 10 black)", display );
	fputs( "(text 326 1 \"Stable set\" \"8x13\")", display );
	fprintf( display, "(text 420 1 \"%s\" \"8x13\")", phase );
	fputs( ")", display );
	fputs( "(step #t)", display );
	fflush( display );
}

/* Each page is represented by a square of the following size.  */

#define  PAGE_PIXELS  5

/* The following procedure is called to create the heap display as required.
   Press button 1 for a popup menu to control the display.  
*/

static void  displayinit()
{
        int  toezd[ 2 ];

	if  ((gcflags & GCHEAPMAP) == 0)  return;
	/* Spawn off an ezd process */
        pipe( toezd );
        if  (fork() == 0)  {
           close( 0 );
           dup( toezd[ 0 ] );
           close( toezd[ 0 ] );
           close( toezd[ 1 ] );
           execlp( "ezd", "ezd", 0 );
           exit( 1 );
	}
	display = fdopen( toezd[ 1 ], "w" );
	/* Initialize the display */
	fprintf( display,
	        "(window heap 0 0 %d 220 \"C Garbage Collected Heap\")\n",
		PAGE_PIXELS*128 );
	fputs( "(set-drawing heap) (overlay heap heap)", display );
	fputs( "(object back (fill-rectangle 0 0 2000 2000 clear))", display );
	fputs( "(define-popup POPUP \"NEXT-STEP\" (next-step)", display );
	fputs( "  (if *stepper* \"STEPPING OFF\" \"STEPPING ON\")", display );
	fputs( "  (ezd `(stepper ,(not *stepper*)))", display );
	fputs( "  \"POSTSCRIPT\" (ezd '(postscript heap \"gcheap.PSF\")))",
	       display );
	fputs( "(when * button1down (popup))", display );
	display_headers( "Application Allocation" );
}

/* A page is colored on the heap map by the following function. */

static void  page_map( page )
	int  page;
{
        char*  color;

        if  (STABLE( page ))
           color = "BLACK";
	else  
	   color = freecolors[ space[ page ] % 8 ];    
        page = page-firstheappage;
        fprintf( display, "(object p%x (fill-rectangle %d %d %d %d %s))",
                 page, (page & 127)*PAGE_PIXELS,
		 PAGE_PIXELS*(page/2048)+(page/128)*PAGE_PIXELS+20, 
		 PAGE_PIXELS, PAGE_PIXELS, color );
	if  (current_space == next_space)  {
	   fflush( display );
	}
}

/* The heap is allocated and the appropriate data structures are initialized
   by the following function.  It is called the first time any storage is
   allocated from the heap.
*/

static void  gcinit( )
{
	char  *heap;
	int  i;

	/* Log actual heap parameters if from environment or logging */
	if  ((environment_value( "GCMINBYTES", &gcminbytes ) |
	      environment_value( "GCMAXBYTES", &gcmaxbytes ) |
	      environment_value( "GCINCBYTES", &gcincbytes ) |
	      environment_value( "GCALLPERCENT", &gcallpercent ) |
	      environment_value( "GCINCPERCENT", &gcincpercent ) |
	      environment_value( "GCFLAGS", &gcflags ))  ||
	      gcflags & GCSTATS)  {
	   fprintf( stderr,
	   	    "***** gcalloc  gcheap( %d, %d, %d, %d, %d, %d )\n",
	   	    gcminbytes, gcmaxbytes, gcincbytes, gcallpercent,
		    gcincpercent, gcflags );
	}

	/* Allocate heap and side tables.  Exit on allocation failure. */
	heapspanpages = heappages = gcminbytes/PAGEBYTES;
	if  ((heap = NEW_CHAR( heappages*PAGEBYTES+PAGEBYTES-1 )) == NULL)
	   goto fail;
	if ((unsigned)heap & (PAGEBYTES-1))
	   heap = heap+(PAGEBYTES-((unsigned)heap & (PAGEBYTES-1)));
	firstheappage = GCP_to_PAGE( heap );
	lastheappage = firstheappage+heapspanpages-1;
	if  ((space = NEW_INT( heapspanpages )) == NULL  ||
	     (plink = NEW_INT( heapspanpages)) == NULL  ||
	     (type = NEW_INT( heapspanpages )) == NULL  ||
	     (firstword = NEW_INT( heapspanpages*BIT_WORDS )) == NULL)  {
fail:	   fprintf( stderr, 
		    "\n****** gcalloc  Unable to allocate %d byte heap\n",
		    gcminbytes );
	   abort();
	}
	space = space-firstheappage;
	plink = plink-firstheappage;
	type = type-firstheappage;
	firstword = firstword-firstheappage*BIT_WORDS;

	/* Initialize tables */
	for (i = firstheappage ; i <= lastheappage ; i++)
	   space[ i ] = FREEPAGE;
	current_space = 3;
	next_space = 3;
	freepage = firstheappage;
	allocatedpages = 0;
	stablepages = 0;
	queue_head = 0;
	gcheapcreated = 1;
#ifdef DOUBLE_ALIGN
	doublepad = MAKE_HEADER( 1, MAKE_CALLBACK( 1 ) );
#endif
	displayinit();
}

/* Once the heap has been allocated, it is automatically expanded after garbage
   collection until the maximum size is reached.  If space cannot be allocated
   to expand the heap, then the heap will be left it's current size and no
   further expansions will be attempted.  SHOULDEXPANDHEAP is a boolean that
   returns true when the heap should be expanded.  EXPANDHEAP is called to
   expand the heap.  It return true when the heap could be expanded.
*/

static int  shouldexpandheap()
{
	if  (HEAPPERCENT( allocatedpages ) < gcincpercent  ||
	     heappages >= gcmaxbytes/PAGEBYTES  ||  gcincbytes == 0)
	   return  0;
	else
	   return  1;
}

static  expandfailed = 0;

static int  expandheap()  {
	int  incheappages = (gcincbytes/PAGEBYTES),
	     new_firstheappage = firstheappage,
	     inc_firstheappage,
	     new_lastheappage = lastheappage,
	     inc_lastheappage,
	     new_heappages,
	     new_heapspanpages,
	     *new_space = NULL,
	     *new_plink = NULL,
	     *new_type = NULL,
	     *new_firstword = NULL,
	     i;
	char*  heap;

	/* Check for previous expansion failure */
	if  (expandfailed)  return  0;

	/* Allocate additional heap and determine page span */
	heap = NEW_CHAR( incheappages*PAGEBYTES+PAGEBYTES-1 );
	if  (heap == NULL)  goto fail;
	if ((unsigned)heap & (PAGEBYTES-1))
	   heap = heap+(PAGEBYTES-((unsigned)heap & (PAGEBYTES-1)));	
	inc_firstheappage = GCP_to_PAGE( heap );
	inc_lastheappage = inc_firstheappage+incheappages-1;
	if  (inc_firstheappage < firstheappage)
	   new_firstheappage = inc_firstheappage;
	if  (inc_lastheappage > lastheappage)
	   new_lastheappage = inc_lastheappage;
	new_heappages = heappages+incheappages;
	new_heapspanpages = new_lastheappage-new_firstheappage+1;

	/* Allocate contiguous space for each side table, recover gracefully
	   from allocation failure.  */
	if  ((new_space = NEW_INT( new_heapspanpages )) == NULL  ||
	     (new_plink = NEW_INT( new_heapspanpages )) == NULL  ||
	     (new_type = NEW_INT( new_heapspanpages )) == NULL  ||
	     (new_firstword = NEW_INT( new_heapspanpages*BIT_WORDS ))
	     	== NULL)  {
fail:	   if  (heap)  free( heap );
	   if  (new_space)  free( new_space );
	   if  (new_plink)  free( new_plink );
	   if  (new_type)  free( new_type );
	   if  (new_firstword)  free( new_firstword );
	   expandfailed = 1;
	   if  (gcflags & GCSTATS)
	      fprintf( stderr, "\n***** gcalloc  Heap expansion failed\n" );
	   return  0;
	}
	new_space = new_space-new_firstheappage;
	new_plink = new_plink-new_firstheappage;
	new_type = new_type-new_firstheappage;
	new_firstword = new_firstword-new_firstheappage*BIT_WORDS;

	/* Initialize new side tables, delete the old ones */
	for (i = new_firstheappage ; i < firstheappage ; i++)
	   new_space[ i ] = UNALLOCATEDPAGE;
	for (i = firstheappage ; i <= lastheappage ; i++)
	   new_space[ i ] = space[ i ];
	for (i = lastheappage+1 ; i < new_lastheappage ; i++)
	   new_space[ i ] = UNALLOCATEDPAGE;
	for (i = inc_firstheappage ; i <= inc_lastheappage ; i++)
	   new_space[ i ] = FREEPAGE;
	free( space+firstheappage );
	space = new_space;
	for  (i = firstheappage; i <= lastheappage; i++)  {
	   new_plink[ i ] = plink[ i ];
	   new_type[ i ] = type[ i ];
	}
	free( plink+firstheappage );
	plink = new_plink;
	free( type+firstheappage );
	type = new_type;
	for  (i = firstheappage*BIT_WORDS;
	      i <= lastheappage*BIT_WORDS+BIT_WORDS-1; i++)
	   new_firstword[ i+(firstheappage-new_firstheappage)*BIT_WORDS ] =
	      firstword[ i ];
	free( firstword+firstheappage*BIT_WORDS );
	firstword = new_firstword;
	firstheappage = new_firstheappage;
	lastheappage = new_lastheappage;
	heappages = new_heappages;
	heapspanpages = new_heapspanpages;
	if  (gcflags & GCSTATS)
	   fprintf( stderr, "\n***** gcalloc  Heap expanded to %d bytes\n",
		    heappages*PAGEBYTES );
	return  1;
}

/* A pointer pointing to the header of an object is stepped to the next header
   by the following function.  Forwarded headers are correctly handled.
*/

static GCP  next_object( xp )
	GCP  xp;
{
	if  (FORWARDED( *xp ))
	   return  xp+HEADER_WORDS( *((int*)(*xp)-1) );
	else
	   return  xp+HEADER_WORDS( *xp );
}

/* A pointer can be verified to point to an object in the heap by the following
   function.  An invalid pointer will be logged and the program will abort.
*/

static void  verify_object( cp, old )
	GCP  cp;
	int  old;
{
	int  page = GCP_to_PAGE( cp );
	GCP  xp = PAGE_to_GCP( page ); /* Ptr to start of page */
	int  error = 0;

	if  (page < firstheappage)  goto fail;
	error = 1;
	if  (page > lastheappage)  goto fail;
        error = 2;
	if  (space[ page ] == UNALLOCATEDPAGE)  goto fail;
	error = 3;
	if  (old  &&  UNSTABLE( page )  &&  space[ page ] != current_space)
	   goto fail;
	error = 4;
	if  (old == 0  &&  space[ page ] != next_space)  goto fail; 
        error = 5;
	while  (cp > xp+1)  xp = next_object( xp );
	if  (cp == xp+1)  return;
fail:
	fprintf( stderr,
	        "\n***** gcalloc  invalid pointer  error: %d  pointer: 0x%x\n",
		 error, cp );
	abort();
}

/* An object's header is verified by the following function.  An invalid
   header will be logged and the program will abort.
*/

static void  verify_header( cp )
	GCP  cp;
{
	int  size = HEADER_WORDS( cp[ -1 ] ),
	     page = GCP_to_PAGE( cp ),
	     error = 0,
	     pages,
	     pagex;

	if  FORWARDED( cp[ -1 ] )  goto fail;
	error = 1;
	if  ((unsigned)HEADER_CALLBACK( cp[ -1 ] ) >=
	     (unsigned)callbacks_count)  goto fail;
	if  (size <= ONEPAGEOBJ_WORDS)  {
	   error = 2;
	   if  (cp-1+size > PAGE_to_GCP( page+1 ))  goto fail;
	} else  {
	   error = 3;
	   pages = HEADER_PAGES( cp[ -1 ] );
	   pagex = page;
	   while  (--pages)  {
	      pagex++;
	      if  (pagex > lastheappage  ||
	           type[ pagex ] != CONTINUED  ||
	           space[ pagex ] != space[ page ])
	         goto fail;
	   }
	}
	return;
fail:	fprintf( stderr,
                 "\n***** gcalloc  invalid header  error: %d  object&: 0x%x  header: 0x%x\n",
		 error, cp, cp[ -1 ] );
	abort();
}

/* The following variable holds the number of pointers guessed in an object
   by guess_pointer.  Note that cp points to the object header.
*/

static int  guess_pointer_count;

static int  guess_pointers( cp )
	GCP  cp;
{
	int  i;

	guess_pointer_count = 0;
	if  (HEADER_CALLBACK( *cp ) != 0)  {
	   for  (i = 1; i < HEADER_WORDS( *cp ); i++)  {
	      int  page = GCP_to_PAGE( (GCP)cp[ i ] );
	      if  (page >= firstheappage  &&  page <= lastheappage  &&
		   space[ page ] != UNALLOCATEDPAGE)
	         guess_pointer_count++;
	   }
	}
	return  guess_pointer_count;
}

/* The stable set is moved into the current_generation by the following
   function.  A total collection is performed by calling this before calling
   gccollect.  When generational collection is not desired, this is called
   after collection to empty the stable set.
*/

static void  makecurrentstableset()
{
	stablepages = 0;
	while  (queue_head)  {
#ifdef DOUBLE_ALIGN
	   int  pagecount = HEADER_PAGES( *(PAGE_to_GCP( queue_head )+1) ),
#else
	   int  pagecount = HEADER_PAGES( *PAGE_to_GCP( queue_head ) ),
#endif
	        i = queue_head;
	   while  (pagecount--)  {
	      space[ i++ ] = current_space;
	      if  (gcflags & GCHEAPMAP)  page_map( i-1 );
	   }
	   queue_head = plink[ queue_head ];
	}
}

/* A page index is advanced by the following function */

static int  next_page( page )
	int  page;
{
	return  (page == lastheappage) ? firstheappage : page+1;
}

/* A page is added to the stable set page queue by the following function. */

static void  queue( page )
	int  page;
{
	if  (queue_head != 0)
	   plink[ queue_tail ] = page;
	else 
	   queue_head = page;
	plink[ page ] = 0;
	queue_tail = page;
}

/* Pages that have might have references in the stack or the registers are
   promoted to the stable set by the following function.
*/

static void  promote_page( page )
	int  page;
{
	int  i, pagecount;

	if  (page >= firstheappage  &&  page <= lastheappage  &&
	     space[ page ] == current_space)  {
	   if  (type[ page ] == CONTINUED)  {
	      while  (type[ --page ] == CONTINUED);
	   }
#ifdef DOUBLE_ALIGN
	   pagecount = HEADER_PAGES( *(PAGE_to_GCP( page )+1) );
#else
	   pagecount = HEADER_PAGES( *PAGE_to_GCP( page ) );
#endif
	   if  (gcflags & GCDEBUGLOG)
	      fprintf( stderr, "promoted 0x%x\n", PAGE_to_GCP( page ) );
	   queue( page );
	   if  (gcflags & GCHEAPMAP)  {
	      for  (i = 0; i < pagecount; i++)  {
	         space[ page+i ] = next_space;
	         page_map( page+i );
	      }
	   }
	   allocatedpages = allocatedpages+pagecount;
	   do  {
	      space[ page++ ] = next_space;
	   }  while (--pagecount);
	}
}
	   
/* A pointer is moved by the following function. */

static void  allocatepage( /* int pagecount */ );

GCP gcmove( cp )
	GCP  cp;
{
	int  header,			/* Object header */
	     page = GCP_to_PAGE( cp ),	/* Page number */
	     words;
	GCP  np,			/* Pointer to the new object */
	     p1, p2;
	
	/* If out of heap then ok */
	if  (page < firstheappage  ||  page > lastheappage  ||
	     space[ page ] == UNALLOCATEDPAGE)
	   return( cp );

	/* Check for a derived pointer */
	if  (((int)cp) & 3  ||  ISA_FIRSTWORD( cp ) == 0)  {
	   while  (type[ page ] == CONTINUED)  page--;
	   p2 = PAGE_to_GCP( page );
	   while  (p2 < cp)  {
	      p1 = p2;
	      p2 = next_object( p2 );
	   }
	   if  (gcflags & GCTSTOBJ)  verify_object( p1+1, 1 );
	   return (GCP)((char*)gcmove( p1+1 )+((char*)cp-(char*)(p1+1)));
	}

	/* Verify that the object is a valid pointer and decrement ptr cnt */
	if  (gcflags)  {
	   if  (gcflags & GCTSTOBJ)  verify_object( cp, 1 );
	   if  (gcflags & GCGUESSPTRS)  guess_pointer_count--;
	}

	/*  If object in stable storage then ok */
	if  (STABLE( page ))  return( cp );

	/* If cell is already forwarded, return forwarding pointer */
	header = cp[-1];
	if  (FORWARDED( header ))  {
	   if  (gcflags & GCTSTOBJ)  {
	      verify_object( (GCP)header, 0 );
	      verify_header( (GCP)header );
	   }
	   return( (GCP)header );
	}

	/* Move the object */
	if  (gcflags & GCTSTOBJ)  {
	   verify_header( cp );
	}
	/* Forward or promote object */
	words = HEADER_WORDS( header );
	if  (words >= freewords)  {
	   /* Promote objects >= a page to stable set */
	   if  (words >= ONEPAGEOBJ_WORDS)  {
	      promote_page( page );
	      return( cp );
	   }
	   /* Discard any partial page and allocate a new one */
	   if  (freewords != 0)  {
	      *freep = MAKE_HEADER( freewords, freespace_callback );
	      freewords = 0;
	   }
	   allocatepage( 1 );
#ifdef DOUBLE_ALIGN
	   *freep = doublepad;
	   freewords = freewords-1;
	   freep = freep+1;
#endif
	}
	/* Forward object, leave forwarding pointer in old object header */
	*freep++ = header;
	np = freep;
	SET_FIRSTWORD( freep );
	cp[-1] = (int)np;
	freewords = freewords-words;
	while  (--words)  *freep++ = *cp++;
#ifdef DOUBLE_ALIGN
	if  ((freewords & 1) == 0  &&  freewords)  {
	   *freep = doublepad;
	   freewords = freewords-1;
	   freep = freep+1;
	}
#endif
	return( np );
}

/* Output a newline to stderr if logging is enabled. */

void  newline_if_logging()
{
	if  (gcflags & (GCDEBUGLOG | GCROOTLOG | GCHEAPLOG | GCGUESSPTRS))
	   fprintf( stderr, "\n" );
}

/* A root is logged to stderr by the following function. */

static void  log_root( fp )
	unsigned*  fp;
{
	int  page = GCP_to_PAGE( fp );
	GCP  p1, p2;

	if  (page < firstheappage  ||  page > lastheappage  ||
	     space[ page ] == UNALLOCATEDPAGE  ||
	     (UNSTABLE( page )  &&  space[ page ] != current_space))
	   return;
	while  (type[ page ] == CONTINUED)  page--;
	p2 = PAGE_to_GCP( page );
	while  (p2 < (GCP)fp)  {
	   p1 = p2;
	   p2 = next_object( p2 );
	}
	fprintf( stderr, "***** gcalloc  root&: 0x%x  object&: 0x%x  %s\n",
		 fp, p1, callbacks[ HEADER_CALLBACK( *(p1) ) ].type );
}

/* Log the memory use statistics on stderr. */

static void  memory_stats()
{
	GCP  cp;
	int  page = firstheappage-1,
	     i, x, words, free;

	for  (i = 0; i < callbacks_count; i++)  {
	   callbacks[ i ].number = 0;
	   callbacks[ i ].bytes = 0;
	}
	while  (++page <= lastheappage)  {
	   if  ((space[ page ] == current_space  ||  
	      	 (STABLE( page )  &&  space[ page ] != UNALLOCATEDPAGE))
		&&  type[ page ] == OBJECT)  {
	      cp = PAGE_to_GCP( page );
	      while  (GCP_to_PAGE( cp ) == page  &&
		      (cp != freep  || freewords == 0))  {
	 	 x = HEADER_CALLBACK( *cp );
		 words = HEADER_WORDS( *cp );
		 callbacks[ x ].number++;
		 callbacks[ x ].bytes += HEADER_BYTES( *cp );
		 if  (words > ONEPAGEOBJ_WORDS)  {
		    free = HEADER_PAGES( *cp )*PAGEBYTES-HEADER_BYTES( *cp );
		    if  (free)  {
		       callbacks[ 0 ].number++;
		       callbacks[ 0 ].bytes += free;
		    }
		 }
		 cp = cp+words;
	      }
	   }
	}
	fprintf( stderr, "***** gcalloc  number     bytes  type\n" );
	for  (i = 0; i < callbacks_count; i++)  {
	   fprintf( stderr, "               %6d  %8d  %s\n",
	            callbacks[ i ].number, callbacks[ i ].bytes,
		    callbacks[ i ].type );
	}
}

/* The following procedure is called on the completion of garbage collection,
   before free memory is zeroed (iff that option is set).  It provides a
   handy place to put a breakpoint.
*/

static void  gcdone() {};

/* Garbage collection is done by the following procedure.  It is typically
   called when half the pages in the heap have been allocated.  It may also
   be directly called.
*/

static unsigned  registers[ REGISTER_COUNT ];	/* Ambiguous registers */

void  gccollect()
{
	unsigned  *fp,		/* Pointer for checking the stack */
		  *heapend,
		  *firstheapp,
	 	  *lastheapp;
	int  page,		/* Page number while walking page list */
	     i, j,
	     save_gcallpercent;
	GCP  cp,		/* Pointers to move constituent objects */
	     nextcp;		

	/* Check for heap not yet allocated */
	if  (gcheapcreated == 0)  {
	   gcinit();
	   return;
	}
	/* Log entry to the collector */
	if  (gcflags & GCSTATS)  {
	   fprintf( stderr, "***** gcalloc  Collecting - %d%% allocated  ->  ",
	            HEAPPERCENT( allocatedpages ) );
	   newline_if_logging();
	}
	/* Allocate rest of the current page */
	if  (freewords != 0)  {
	   *freep = MAKE_HEADER( freewords, freespace_callback );
	   freewords = 0;
	}
	/* Advance space */
	allocatedpages = 0;
	next_space = current_space+1;

	/* Change headers on heap display */
	if  (gcflags & GCHEAPMAP)
	   display_headers( "Starting Garbage Collection" );

	/* Examine stack, registers, static area and possibly the non-garbage
           collected heap for possible pointers */
	if  (gcflags & GCROOTLOG)  fprintf( stderr, "stack roots:\n" );
	for (fp = gcregisters( registers ) ;
	     fp < (unsigned*)gcstackbase ;
	     fp = (unsigned*)(((char*)fp)+STACKINC) )  {
	   if  (gcflags & GCROOTLOG)  log_root( fp );
	   promote_page( GCP_to_PAGE( *fp ) );
	}
	if  (gcflags & GCROOTLOG)
	   fprintf( stderr, "static, register, and user roots:\n" );
	for  (fp = STATIC_0 ; fp < STATIC_1 ; fp++)  {
	   if  (gcflags & GCROOTLOG)  log_root( fp );
	   promote_page( GCP_to_PAGE( *fp ) );
	}
	for  (i = 0; i < roots_count; i++)  {
	   fp = roots[ i ].addr;
	   for  (j = roots[ i ].bytes; j > 0; j = j-STACKINC)  {
	      promote_page( GCP_to_PAGE( *fp ) );
	      fp++;
	   }
	}
	if  (gcflags & GCHEAPROOTS  ||  gcflags & GCHEAPLOG)  {
	   if  (gcflags & GCHEAPLOG)
	      fprintf( stderr, "non-GC heap roots:\n" );
	   heapend = (unsigned*)sbrk( 0 );
	   firstheapp = (unsigned*)PAGE_to_GCP( firstheappage );
	   lastheapp = (unsigned*)PAGE_to_GCP( lastheappage );
	   while  (fp < heapend)  {
	      if  (fp < firstheapp  ||  fp > lastheapp  ||
	           space[ GCP_to_PAGE( fp ) ] == UNALLOCATEDPAGE)  {
	         if  (gcflags & GCHEAPLOG)  log_root( fp );
		 if  (gcflags & GCHEAPROOTS)
		    promote_page( GCP_to_PAGE( *fp ) );
		 fp++;
	      }
	      else  {
		 fp = fp+PAGEWORDS;
	      }
	   }
	}
	if  (gcflags & GCSTATS)  {
	   fprintf( stderr, "%d%% locked  ", HEAPPERCENT( allocatedpages ) );
	   newline_if_logging();
	}

	/* Sweep across stable pages and move their constituent items.  Since
  	   a lot of time is spent in this loop, there are two versions:  one
	   that is traced, and one that is not.
	*/
	if  (gcflags & GCHEAPMAP)
	   display_headers( "Copying Retained Storage" );
	page = queue_head;
	if  (gcflags & (GCDEBUGLOG | GCGUESSPTRS | GCTSTOBJ))  {
	   while  (page)  {
	      cp = PAGE_to_GCP( page );
	      nextcp = PAGE_to_GCP( page+1 );
	      if  (gcflags & GCDEBUGLOG)
	         fprintf( stderr, "sweeping 0x%x\n", cp );
	      while  (cp < nextcp  &&  (cp != freep  || freewords == 0))  {
	         if  (gcflags & GCTSTOBJ)  verify_header( cp+1 );
	         if  (gcflags & GCGUESSPTRS)  {
		    int  guess = guess_pointers( cp );
	            (*callbacks[ HEADER_CALLBACK( *cp ) ].proc)( cp+1 );
		    if  (guess_pointer_count)  {
		       fprintf( stderr, "***** gcalloc  guess: %d  actual: %d  %s  object&: 0x%x\n", guess, guess-guess_pointer_count,
			        callbacks[ HEADER_CALLBACK(*cp) ].type, cp+1 );
		    }
	         }
	         else
	            (*callbacks[ HEADER_CALLBACK( *cp ) ].proc)( cp+1 );
	         cp = cp+HEADER_WORDS( *cp );
	      }
	      page = plink[ page ];
              if  (cp == freep  &&  freewords != 0  &&  page)  {
                 *freep = MAKE_HEADER( freewords, freespace_callback );
                 freewords = 0;
              }
	   }
	}  else  {
	   while  (page)  {
	      cp = PAGE_to_GCP( page );
	      nextcp = PAGE_to_GCP( page+1 );
	      while  (cp < nextcp  &&  (cp != freep  || freewords == 0))  {
	         (*callbacks[ HEADER_CALLBACK( *cp ) ].proc)( cp+1 );
	         cp = cp+HEADER_WORDS( *cp );
	      }
	      page = plink[ page ];
              if  (cp == freep  &&  freewords != 0  &&  page)  {
                 *freep = MAKE_HEADER( freewords, freespace_callback );
                 freewords = 0;
              }
	   }
	}
	
	/* Finished, all retained pages are now part of the stable set */
	current_space = current_space+2;
	next_space = current_space;
	stablepages = stablepages+allocatedpages;
	allocatedpages = stablepages;
	if  (gcflags & GCSTATS)  {
	   fprintf( stderr, "%d%% stable.\n", HEAPPERCENT( stablepages ) );
	}

	/* Print memory use statistics if required */
	if  (gcflags & GCMEM)  memory_stats();

	/* Change headers on heap display */
	if  (gcflags & GCHEAPMAP)  display_headers( "Application Allocation" );

	/* Check for total collection and heap expansion.  */
	if  (gcallpercent)  {
	   /* Performing generational collection */
	   if  (HEAPPERCENT( allocatedpages ) >= gcallpercent)  {
	      /* Perform a total collection and then expand the heap */
	      makecurrentstableset();
	      save_gcallpercent = gcallpercent;
	      gcallpercent = 100;
	      gccollect();
	      if  (shouldexpandheap())  expandheap();
	      gcallpercent = save_gcallpercent;
	   }
	}
	else  {
	   /* Not performing generational collection */
	   if  (shouldexpandheap())  expandheap();
	   makecurrentstableset();
	}

	gcdone();
	/* Zero free memory if required */
	if  (gcflags & GCZERO)  {
	   int  page = firstheappage-1;
	   while  (++page <= lastheappage)  {
	      if  (space[ page ] != current_space  &&  UNSTABLE( page ))
		 bzero( (char*)PAGE_to_GCP( page ), PAGEBYTES );
	   }
	}
}

/* When gcalloc is unable to allocate storage, it calls this routine to
   allocate one or more pages.  If space is not available then the garbage
   collector is called and/or the heap is expanded.
*/

static void  allocatepage( pages )
	int  pages;
{
	int  free,		/* # contiguous free pages */
	     firstpage,		/* Page # of first free page */
	     allpages,		/* # of pages in the heap */
	     i;

	/* Garbage collect if more than 50% of the space will be allocated. */
	if  (allocatedpages+pages >= heappages/2  && 
	     current_space == next_space)  {
	   gccollect();
	   if  (freewords != 0)  {
	      *freep = MAKE_HEADER( freewords, freespace_callback );
	      freewords = 0;
	   }
	}
	/* Try to allocate space */
	free = 0;
	allpages = heapspanpages;
	while  (allpages--)  {
	   if  (space[ freepage ] != current_space  &&
		UNSTABLE( freepage ))  {
	      if  (free++ == 0)  firstpage = freepage;
	      if  (free == pages)  {
	         freep = PAGE_to_GCP( firstpage );
		 if  (current_space != next_space)  {
		    if  (gcflags & GCDEBUGLOG)
		       fprintf( stderr, "queued   0x%x\n", freep );
		    queue( firstpage );
		 }
		 if  (gcflags & GCHEAPMAP)  {
		    for  (i = 0; i < pages; i++)  {
		       space[ firstpage+i ] = next_space;
		       page_map( firstpage+i );
		    }
		 }
		 freewords = pages*PAGEWORDS;
		 allocatedpages = allocatedpages+pages;
		 freepage = next_page( freepage );
		 space[ firstpage ] = next_space;
		 type[ firstpage ] = OBJECT;
		 bzero( (char*)&firstword[ firstpage*BIT_WORDS ],
		 	BIT_BYTES*pages );
		 while (--pages)  {
		    space[ ++firstpage ] = next_space;
		    type[ firstpage ] = CONTINUED;
		 }
	         return;
	      }
	   }
	   else  free = 0;
	   freepage = next_page( freepage );
	   if  (freepage == firstheappage)  free = 0;
	}
	/* Failed to allocate space, keep trying iff heap can expand.  Assure
	   that minimum increment size is at least the size of this object.
	*/
	if  (gcincbytes/PAGEBYTES < pages)  gcincbytes = pages*PAGEBYTES;
	if  (expandheap())  {
	   allocatepage( pages );
	   return;
	}
	/* Can't do it */
	fprintf( stderr,
	    "\n***** gcalloc  Unable to allocate %d bytes in a %d byte heap\n",
		 pages*PAGEBYTES, heappages*PAGEBYTES );
	abort();
}

       /**********************
	* Storage Allocation *
	**********************/
	
/* Storage is allocated by the following function.  It returns a pointer
   to the object.  It is up to the specific constructor procedure to assure
   that all pointer slots are correctly initialized.
*/

GCP  gcalloc( bytes, callback )
	int  bytes, callback;
{
	GCP  object;	/* Pointer to the object */
	int  words = (bytes+(WORDBYTES+WORDBYTES-1))/WORDBYTES;

	/* Try to allocate from current page */
	if  (words <= freewords)  {
	   *freep = MAKE_HEADER( words, callback );
	   object = freep+1;
	   freewords = freewords-words;
	   freep = freep+words;
#ifdef DOUBLE_ALIGN
	   if  ((freewords & 1) == 0  &&  freewords)  {
	     *freep = doublepad;
	     freewords = freewords-1;
	     freep = freep+1;
	   }
#endif
	   SET_FIRSTWORD( object );
	   return( object );
	}
	/* Discard any remaining portion of current page */
	if  (freewords != 0)  {
	   *freep = MAKE_HEADER( freewords, freespace_callback );
	   freewords = 0;
	}
	/* Object fits in one page with left over free space*/
	if  (words < ONEPAGEOBJ_WORDS)  {
	   allocatepage( 1 );
#ifdef DOUBLE_ALIGN
	   *freep = doublepad;
	   freewords = freewords-1;
	   freep = freep+1;
#endif
	   *freep = MAKE_HEADER( words, callback );
	   object = freep+1;
	   freewords = freewords-words;
	   freep = freep+words;
#ifdef DOUBLE_ALIGN
	   if  ((freewords & 1) == 0)  {
	      *freep = doublepad;
	      freewords = freewords-1;
	      freep = freep+1;
	   }
#endif
	   SET_FIRSTWORD( object );
	   return( object );
	}
	/* Object >= 1 page in size */	
	if  (words > MAX_HEADER_WORDS)  {
	   fprintf( stderr,
	  "\n***** gcalloc  Unable to allocate objects larger than %d bytes\n",
	           MAX_HEADER_WORDS*WORDBYTES-WORDBYTES );
	   abort();
	}
#ifdef DOUBLE_ALIGN
	allocatepage( (words+PAGEWORDS)/PAGEWORDS );
	*freep = doublepad;
	freewords = freewords-1;
	freep = freep+1;
#else
	allocatepage( (words+PAGEWORDS-1)/PAGEWORDS );
#endif

	*freep = MAKE_HEADER( words, callback );
	object = freep+1;
	freewords = 0;
	freep = NULL;
	SET_FIRSTWORD( object );
	return( object );
}
