/*

   string.h

   Copyright, 1993, Brent Benson.  All Rights Reserved.

   Permission to use, copy, and modify this software and its
   documentation is hereby granted only under the following terms and
   conditions.  Both the above copyright notice and this permission
   notice must appear in all copies of the software, derivative works
   or modified version, and both notices must appear in supporting
   documentation.  Users of this software agree to the terms and
   conditions set forth in this notice and agree to inform the author,
   Brent Benson, of any noteworthy uses of this software.

*/
#ifndef STRING_H
#define STRING_H

#include "object.h"

void init_string_prims (void);
Object make_byte_string (char *str);
Object make_string_driver (Object args);

#if !defined(_CX_UX) && !defined(linux) 
#define NO_STRDUP 1
#endif

#ifdef NO_STRDUP
char *strdup (char *);
#endif /* NO_STRDUP */

#endif
