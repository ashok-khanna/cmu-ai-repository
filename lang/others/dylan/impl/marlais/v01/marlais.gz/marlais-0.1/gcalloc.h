/* This module implements garbage collected storage for C programs using
   a generational version of the "mostly-copying" garbage collection algorithm.

   Copyright (c) 1989, Digital Equipment Corp.  All rights reserved.
*/

/*
 *              Copyright 1990 Digital Equipment Corporation
 *                         All Rights Reserved
 *
 * Permission to use, copy, and modify this software and its documentation is
 * hereby granted only under the following terms and conditions.  Both the
 * above copyright notice and this permission notice must appear in all copies
 * of the software, derivative works or modified versions, and any portions
 * thereof, and both notices must appear in supporting documentation.
 *
 * Users of this software agree to the terms and conditions set forth herein,
 * and hereby grant back to Digital a non-exclusive, unrestricted, royalty-free
 * right and license under any changes, enhancements or extensions made to the
 * core functions of the software, including but not limited to those affording
 * compatibility with other hardware or software environments, but excluding
 * applications which incorporate this software.  Users further agree to use
 * their best efforts to return to Digital any such changes, enhancements or
 * extensions that they make and inform Digital of noteworthy uses of this
 * software.  Correspondence should be provided to Digital at:
 *
 *                       Director of Licensing
 *                       Western Research Laboratory
 *                       Digital Equipment Corporation
 *                       250 University Avenue
 *                       Palo Alto, California  94301
 *
 * This software may be distributed (but not offered for sale or transferred
 * for compensation) to third parties, provided such third parties agree to
 * abide by the terms and conditions of this notice.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND DIGITAL EQUIPMENT CORP. DISCLAIMS ALL
 * WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS.   IN NO EVENT SHALL DIGITAL EQUIPMENT
 * CORPORATION BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL
 * DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
 * PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS
 * ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
 * SOFTWARE.
 */

#ifndef GCALLOCH
#define GCALLOCH 1

/* Defining garbage collected classes
   ----------------------------------
   Classes allocated in the garbage collected heap are best shown by example.
   Here, a class that holds a fixed length string, a reference count, and
   pointers to strings that are greater or lesser than it can be defined as
   follows:

	struct  word  {
		struct word* lesser;
		struct word* greater;
		int  count;
		char  symbol[ 12 ];
	};

   An instance of this class is created by the following procedure.  The code
   is similar to that that would be used to allocate storage using the normal
   C heap, with a call to gcalloc replacing the call the malloc.

	word*  new_word( chars )
		char*  chars;
	{
		struct word*  wp=(word*)gcalloc(sizeof( word ),word_callback);

		wp->lesser = NULL;
		wp->greater = NULL;
		wp->count = 1;
		strcpy( wp->symbol, chars );
		return  wp;
	}

   The second argument to gcalloc is a "garbage collector callback", GCCB.  One
   must be defined for each class of garbage collected storage before it can be
   allocated.  A GCCB is constructed by calling gcregistercallback with the
   class' "pointer locator" procedure and a string containing the class name.

   The "pointer locator" procedure, word_pointers, is used by the garbage
   collector to identify all pointers in the object.  This is done by
   having the procedure call GCPOINTER with each pointer in the object that
   could point to a garbage collected object.  In this example, the GCCB could
   be initialized by:

	GCCB  word_callback;

	void  word_pointers( wp )
		struct word*  wp;
	{
		GCPOINTER( wp->lesser );
		GCPOINTER( wp->greater );
	}

	main( argc, argv )
	{
			.
			.
			.
		word_callback = gcregistercallback( word_pointers, "word" );
			.
			.
			.
	}

   Caveats
   -------
   When the garbage collector is invoked, it searches the processor's
   registers, the stack, and the program's static area for "hints" as to what
   storage is still accessible.  These hints are used to identify objects that
   are the "roots" and are to be left in place.  Objects that the roots point
   to will be moved to compact the heap.  Because of this:

   Objects allocated in the garbage collected heap MAY MOVE.

   Pointers to garbage collected objects MAY BE passed as arguments or stored
   in static storage.

   Pointers to garbage collected objects MAY NOT be stored in dynamically 
   allocated objects that are not garbage collected, UNLESS one has specified
   the GCHEAPROOTS flag in a gcheap declaration, or one has registered the
   area with the garbage collector by calling gcroots.

   Pointers to garbage collected objects contained in garbage collected objects
   MUST always point outside the garbage collected heap or to a garbage
   collected object.

   The garbage collector needs to know the bottom of the stack.  It will assume
   it is the value found in USRSTACK in <machine/vmparam.h>, unless the user
   sets gcstackbase to some other value.

   NEVER try to explicitly free a garbage collected object by calling free.

   Sizing the heap
   ---------------
   In order to make heap allocated storage as painless as possible, the user
   does not have to do anything to configure the heap.  This default is an
   initial heap of 1 megabyte that is expanded in 1 megabyte increments
   whenever the heap is more than 25% full after a total garbage collection.
   Total garbage collections are done when the heap is more than 35% full.

   However, if this is not the desired behavior, then it is possible to "tune"
   the collector by including one or more calls to gcheap in the program.  In
   order to understand the parameters supplied to gcheap, one needs an
   overview of the storage allocation and garbage collection algorithm.

   Storage is allocated from the heap until 50% of the heap has been allocated.
   All accessible objects allocated since the last collection are retained and
   made a part of the stable set.  If less than <collect all percent> of the
   heap is allocated, then the collection process is finished.  Otherwise, the
   entire heap (including the stable set) is garbage collected.  If the amount
   allocated following the total collection is greater than <increment heap
   percent>, then an attempt is made to expand the heap.

	gcheap( <initial heap size>, <maximum heap size>,
		<increment size>, <collect all percent>,
		<increment heap percent>, <heap log> )

   The arguments are defined as follows:

	<initial heap size>	 initial size of the heap in bytes.
				 DEFAULT: 1048576.
	<maximum heap size>	 maximum heap size in bytes.
				 DEFAULT: 2147483647.
	<increment size>	 # of bytes to add to each heap on each
				 expansion.  DEFAULT: 1048576.
	<collect all percent>	 number between 0 and 50 that is the percent
				 allocated after a partial collection that will
				 force a total collection.  A value of 0 will
				 disable generational collection.  DEFAULT: 35.
	<increment heap percent> number between 0 and 50 that is the percent
				 allocated after a total collection that will
				 force heap expansion.  DEFAULT: 25.
	<flags>			 controls logging on stderr, error checking,
				 and root finding:
				   & GCSTATS =  log collection statistics
				   & GCMEM =  log memory usage statistics
				   & GCROOTLOG = log roots found in the stack,
						 registers, and static area
				   & GCHEAPROOTS = treat non-GC heap as roots
				   & GCHEAPLOG = log possible roots in non-GC
						 heap
				   & GCTSTOBJ = perform object consistency
					        tests
				   & GCGUESSPTRS = guess number of pointers in
						   objects
				   & GCZERO = zero free memory after GC
			 	   & GCDEBUGLOG = log events internal to the
						  garbage collector
			           & GCHEAPMAP = maintain memory allocation
					         map
				 DEFAULT: 0.

   When multiple gcheap calls occur, the one that specifies the largest
   <maximum heap size> value will control all factors except flags which is
   the inclusive-or of all <flags> values.

   Configured values may be overridden by values supplied from environment
   variables.  The user must set these variables in a consistent manner.  The
   variables and the values they set are:

	GCMINBYTES	<initial heap size>
	GCMAXBYTES	<maximum heap size>
	GCINCBYTES	<increment size>
	GCALLPERCENT	<collect all percent>
	GCINCPERCENT	<increment heap percent>
	GCFLAGS		<flags>

   If any of these variables are supplied, then the actual values used to
   configure the garbage collector are logged on stderr.

   Limits
   ------
   No more than 1022 user defined garbage collected classes.
   Individual objects no larger than 8,388,600 bytes.
*/

       /*****************************************************
 	* C Garbage Collected Storage Interface Definitions *
 	*****************************************************/

/* Garbage collector callback objects are created by calling
   gcregistercallback with the object's pointer procedure and the name of
   the object.
*/

typedef int *GCP;		/* Pointer to a garbage collected object. */

typedef int GCCB;		/* Garbage collector callback object. */

typedef void (*GCCALLBACKPROC)( /* GCP */ );
				/* Callback procedure type */

extern GCCB  gcregistercallback( /* GCCALLBACKPROC pointers, char* type */ );

/* The object class' pointer procedure moves each pointer by calling
   GCPOINTER on the pointer.
*/

extern  GCP gcmove( /* GCP ptr */ );
				/* Objects are moved by this function. */

#define GCPOINTER( x ) *((GCP*)(&x)) = gcmove( (GCP)(x) )

/* Garbage collection may be explicitly invoked by calling gccollect. */

extern void  gccollect();

/* Storage is allocated by calling gcalloc with object's size and callback. */

extern  GCP gcalloc( /* int bytes, GCCB callback */ );

/* Additional roots may be registered with the garbage collector by calling
   the procedure gcroots with a pointer to the area and the size of the area.
*/

extern void  gcroots( /* char* area, int bytes */ );
 
/* The garbage collected heap is configured by calls to gcheap as previously
   described.
*/

extern void  gcheap( /* int minheapbytes, int maxheapbytes,
		        int incheapbytes, int allpercent,
			int incpercent, int flags */ );

/* Constants for specifying the flags value in calls to gcheap. */

#define	GCSTATS		1	/* Log garbage collector info */
#define	GCMEM		2	/* Log memory usage information */
#define	GCROOTLOG	4	/* Log roots found in registers, stack and
				   static area */
#define	GCHEAPROOTS	8	/* Treat non-GC heap as roots */
#define	GCHEAPLOG      16	/* Log possible non-GC heap roots */
#define	GCTSTOBJ       32	/* Extensively test objects */
#define	GCGUESSPTRS    64	/* Guess pointers in objects */
#define	GCZERO        128	/* Zero free memory after GC */
#define	GCDEBUGLOG    256	/* Log events internal to collector */
#define	GCHEAPMAP     512	/* X-window display showing allocation */

/* To override the compile time value for the stack base, set gcstackbase to a
   new value.
*/

extern char*  gcstackbase;

#endif
