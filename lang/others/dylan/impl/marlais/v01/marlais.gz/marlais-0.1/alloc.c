/*
   
   alloc.c

   Copyright, 1993, Brent Benson.  All Rights Reserved.

   Permission to use, copy, and modify this software and its
   documentation is hereby granted only under the following terms and
   conditions.  Both the above copyright notice and this permission
   notice must appear in all copies of the software, derivative works
   or modified version, and both notices must appear in supporting
   documentation.  Users of this software agree to the terms and
   conditions set forth in this notice and agree to inform the author,
   Brent Benson, of any noteworthy uses of this software.

*/

#include "alloc.h"
#include "env.h"
#include "symbol.h"
#include "gcalloc.h"

/* garbage collection callbacks */

GCCB object_callback;
GCCB frame_callback;
GCCB binding_callback;
GCCB symtab_callback;

/* pointer locators for garbage collected objects */

static void object_pointers (Object obj);
static void frame_pointers (struct frame *frame);
static void binding_pointers (struct binding *binding);
static void symtab_pointers (struct symtab *entry);

/* function definitions */

void
initialize_gc (void)
{
  object_callback = gcregistercallback (object_pointers, "object");
  frame_callback = gcregistercallback (frame_pointers, "frame");
  binding_callback = gcregistercallback (binding_pointers, "binding");
}

Object
allocate_object (size_t size)
{
  Object obj;

#ifndef SMALL_OBJECTS
  obj = (Object) gcalloc (sizeof (struct object), object_callback);
#else
  obj = (Object) gcalloc (size, object_callback);
#endif
  if (! obj)
    {
      fatal ("internal error: memory allocation failure.");
    }
  return (obj);
}

struct frame *
allocate_frame (void)
{
  struct frame *frame;

  frame = (struct frame *) gcalloc (sizeof (struct frame), frame_callback);
  if (! frame)
    {
      fatal ("internal error: memory allocation failure.");
    }
  return (frame);
}

struct binding *
allocate_binding (void)
{
  struct binding *binding;

  binding = (struct binding *) gcalloc (sizeof (struct binding), binding_callback);
  if (! binding)
    {
      fatal ("internal error: memory allocation failure.");
    }
  return (binding);
}

struct symtab *
allocate_symtab (void)
{
  struct symtab *entry;

  entry = (struct symtab *) gcalloc (sizeof (struct symtab), symtab_callback);
  if (! entry)
    {
      fatal ("internal error: memory allocation failure.");
    }
  return (entry);
}

void *
checking_malloc (size_t size)
{
  void *ptr;

  ptr = (void *) malloc (size);
  if ( ! ptr )
    {
      fatal ("internal error: memory allocation failure");
    }
  return (ptr);
}

void *
checking_realloc (void *ptr, size_t total_size)
{
  ptr = (void *) realloc (ptr, total_size);
  if ( ! ptr )
    {
      fatal ("internal error: memory allocation failure");
    }
  return (ptr);
}

/* pointer locators */

static void 
object_pointers (Object obj)
{
  int i;

  if (POINTERP (obj))
    {
      switch (PAIRTYPE (obj))
	{
	  /* booleans */
	case True:
	case False:
	  return;

	  /* numbers */
	case Integer:
	case Ratio:
	case SingleFloat:
	case DoubleFloat:
	  return;

	  /* collections */
	case EmptyList:
	  return;
	case Pair:
	  GCPOINTER (CAR (obj));
	  GCPOINTER (CDR (obj));
	  return;
	case ByteString:
	  return;
	case SimpleObjectVector:
	  for ( i=0 ; i < SOVSIZE(obj) ; ++i )
	    {
	      GCPOINTER (SOVELS(obj)[i]);
	    }
	  return;
	case Table:
	  for ( i=0 ; i < TABLESIZE (obj) ; ++i )
	    {
	      GCPOINTER (TABLETABLE(obj)[i]);
	    }
	  return;

	  /* conditions */
	case Condition:
	  return;

	  /* keywords and symbols */
	case Symbol:
	case Keyword:
	  return;

	  /* characters */
	case Character:
	  return;

	  /* classes */
	case Class:
	  GCPOINTER (CLASSNAME (obj));
	  GCPOINTER (CLASSSUPERS (obj));
	  GCPOINTER (CLASSSLOTS (obj));
	  return;
	case Instance:
	  GCPOINTER (INSTCLASS (obj));
	  GCPOINTER (INSTSLOTS (obj));
	  return;
	case Singleton:
	  GCPOINTER (SINGLEVAL (obj));
	  return;

	  /* functions */
	case Primitive:
	  return;
	case GenericFunction:
	  GCPOINTER (GFNAME (obj));
	  GCPOINTER (GFPARAMS (obj));
	  GCPOINTER (GFMETHODS (obj));
	  return;
	case Function:
	case Method:
	  GCPOINTER (METHNAME (obj));
	  GCPOINTER (METHPARAMS (obj));
	  GCPOINTER (METHBODY (obj));
	  return;
	case NextMethod:
	  GCPOINTER (NMREST (obj));
	  GCPOINTER (NMARGS (obj));
	  return;

	  /* misc */
	case EndOfFile:
	  return;
	case Values:
	  for ( i=0 ; i < VALUESNUM(obj) ; ++i )
	    {
	      GCPOINTER (VALUESELS(obj)[i]);
	    }
	  return;
	case Unspecified:
	  return;
	case Exit:
	  GCPOINTER (EXITSYM (obj));
	  return;
	case Unwind:
	  GCPOINTER (UNWINDBODY (obj));
	  return;
	case Stream:
	  return;
	case TableEntry:
	  GCPOINTER (TEKEY (obj));
	  GCPOINTER (TEVALUE (obj));
	  GCPOINTER (TENEXT (obj));
	  return;
	case UninitializedSlotValue:
	  return;
	default:
	  error ("gc: unknown object type", obj, NULL);
	}
    }
}

static void 
frame_pointers (struct frame *frame)
{
  int i;

  for ( i=0 ; i < frame->size ; ++i )
    {
      GCPOINTER (frame->bindings[i]);
    }
  GCPOINTER (frame->next);
}

static void 
binding_pointers (struct binding *binding)
{
  GCPOINTER (binding->sym);
  GCPOINTER (binding->val);
  GCPOINTER (binding->next);
}

static void 
symtab_pointers (struct symtab *entry)
{
  GCPOINTER (entry->sym);
  GCPOINTER (entry->next);
}

