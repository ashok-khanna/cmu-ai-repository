/*

   class.h

   Copyright, 1993, Brent Benson.  All Rights Reserved.

   Permission to use, copy, and modify this software and its
   documentation is hereby granted only under the following terms and
   conditions.  Both the above copyright notice and this permission
   notice must appear in all copies of the software, derivative works
   or modified version, and both notices must appear in supporting
   documentation.  Users of this software agree to the terms and
   conditions set forth in this notice and agree to inform the author,
   Brent Benson, of any noteworthy uses of this software.

*/

#ifndef CLASS_H
#define CLASS_H

#include "object.h"

void init_class_prims (void);
void init_class_hierarchy (void);
Object make_class (char *name, Object supers, Object slots);
Object make_instance (Object class, Object slots);
Object make_singleton (Object val);
Object make (Object class, Object rest);
Object instance_p (Object obj, Object class);
Object subclass_p (Object class1, Object class2);
Object objectclass (Object obj);
Object singleton (Object val);
Object same_class_p (Object class1, Object class2);

#endif
