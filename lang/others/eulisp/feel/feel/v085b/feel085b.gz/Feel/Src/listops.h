/* ******************************************************************** */
/* listops.h         Copyright (C) Codemist and University of Bath 1989 */
/*                                                                      */
/* extra list operations prototypes	                                */
/* ******************************************************************** */

void initialise_listops(LispObject*);

