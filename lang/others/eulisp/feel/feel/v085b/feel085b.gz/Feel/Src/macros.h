extern void initialise_macros(LispObject*);
