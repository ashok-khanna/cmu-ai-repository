/* Header file for malloc stuff */

#ifndef FEEL_MALLOC

#define FEEL_MALLOC 1

extern char *feel_malloc(int);
extern void feel_free(char *);

#endif
