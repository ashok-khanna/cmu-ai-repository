extern LispObject Fn_eq(LispObject*);
extern LispObject Fn_equal(LispObject*);
extern LispObject Fn_copy(LispObject*);

extern void initialise_ccc(LispObject*);
