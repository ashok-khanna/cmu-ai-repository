/**
  * Reader for feel. 
  * Just reads tokens(via lex), and does some mangling...
  ***/

#include <string.h>
#include <ctype.h>
#include "defs.h"
#include "structs.h"
#include "funcalls.h"
#include "global.h"
#include "symboot.h"
#include "error.h"

#include "lex_global.h"

#define READBUG(x) 

static LispObject start_list(LispObject *stacktop, LispObject stream, int *len);
static void end_list(LispObject *stacktop, LispObject stream, LispObject first, int *len);
static LispObject this_object(LispObject *stacktop, int token);
static LispObject read2(LispObject *stacktop,LispObject stream,int *len);
static LispObject list2vector(LispObject *stacktop,int len, LispObject lst);

LispObject q_eof;
LispObject current_input;

EUFUN_1(Fn_read, stream)
{
  int dummy;
  LispObject obj;
  READBUG(extern LispObject Md_generic_prin_Object(LispObject *));
  
  if (stream==nil)
    stream=StdIn;

  yy_set_stream(stream->STREAM.handle);
  obj =  (read2(stackbase,stream,&dummy));
  
  READBUG(EUCALL_2(Md_generic_prin_Object,obj,StdErr));
  return obj;
}
EUFUN_CLOSE


static LispObject read2(LispObject *stacktop,LispObject stream,int *len)
{
  LispObject result, first,tmp;
  int mylen, token;
  
  STACK_TMP(stream);
  token=yylex(stacktop);
  switch(token)
    {
    case OPEN_PAIR:
      return(start_list(stacktop,stream,len));
      break;

    case EXTENSION:		
      UNSTACK_TMP(stream);
      first = read2(stacktop,stream,&mylen);
      if (first==nil || is_cons(first))
	return(list2vector(stacktop,mylen,first));
      else
	{
	  CallError(stacktop,"Bad extension syntax",nil,NONCONTINUABLE);
	  return nil;
	}
      break;

    case CLOSE_PAIR:
      fprintf(stderr,"Spurious closing parenthisis ignored");
      return nil;
      break;

    case WRAPPER:
      UNSTACK_TMP(stream);
      STACK_TMP(pptok.lispval);
      first=read2(stacktop,stream,&mylen);
      first=EUCALL_2(Fn_cons,first,nil);
      UNSTACK_TMP(tmp);
      first=EUCALL_2(Fn_cons,tmp,first);
      return first;
      break;
      
    case DOT:
      CallError(stacktop,"Bad list..",nil,NONCONTINUABLE);
      return nil; /* Never */
      break;

    default:
      return(this_object(stacktop,token));
    }
  
}

static LispObject start_list(LispObject *stacktop, LispObject stream, int *len)
{
  LispObject next;
  int mylen, next_token;

  *len=0;
  STACK_TMP(stream);
  next_token=yylex(stacktop);
  UNSTACK_TMP(stream);

  switch (next_token)
    {
    case OPEN_PAIR:
      next=start_list(stacktop,stream,&mylen);
      next=EUCALL_2(Fn_cons,next,nil);
      *len=1;
      STACK_TMP(next);
      end_list(stacktop,stream,next,len);
      UNSTACK_TMP(next);
      return next;

    case EXTENSION:
      next=read2(stacktop,stream,&mylen);
      if  (next!=nil && !is_cons(next))
	CallError(stacktop,"Bad extension syntax",nil,NONCONTINUABLE);
      else
	{
	  STACK_TMP(stream);
	  next=list2vector(stacktop,mylen,next);
	  next=EUCALL_2(Fn_cons,next,nil);
	  UNSTACK_TMP(stream);
	  STACK_TMP(next);
	  end_list(stacktop,stream,next,len);
	  UNSTACK_TMP(next);
	  return next;
	}
      break;

    case CLOSE_PAIR:
      return nil;

    case WRAPPER:
      STACK_TMP(stream);
      STACK_TMP(pptok.lispval);
      next=read2(stacktop,stream,&mylen);
      next=EUCALL_2(Fn_cons,next,nil);
      UNSTACK_TMP(pptok.lispval);
      next=EUCALL_2(Fn_cons,pptok.lispval,next);
      next=EUCALL_2(Fn_cons,next,nil);
      UNSTACK_TMP(stream);
      STACK_TMP(next);
      end_list(stacktop,stream,next,len);
      UNSTACK_TMP(next);
      return next;
      break;


    case DOT:
      CallError(stacktop,"Misplaced dot",nil,NONCONTINUABLE);
      break;

    case END_OF_STREAM:
      CallError(stacktop,"Unexpected end of file",nil,NONCONTINUABLE);
      break;
 
   default:
      next = this_object(stacktop,next_token);
      next= EUCALL_2(Fn_cons,next,nil);
      ++*len;
      STACK_TMP(next);
      end_list(stacktop,stream,next,len); 
      UNSTACK_TMP(next);
      return next;
    }
}

static void end_list(LispObject *stacktop, LispObject stream, LispObject first, int *len)
{
  LispObject *stackbase;
  int token;
  LispObject next,tmp;
  int mylen;
  
  stackbase=stacktop;

  ARG_0(stackbase)=stream; stacktop++;
  ARG_1(stackbase)=first; stacktop++;
  STACK_TMP(first);
  while ( (token=yylex(stacktop))!=CLOSE_PAIR)
    {
      switch (token)
	{
	case OPEN_PAIR:
	  next=start_list(stacktop,ARG_0(stackbase)/*stream*/,&mylen);
	  next=EUCALL_2(Fn_cons,next,nil);	
	  UNSTACK_TMP(first);
	  CDR(first)=next;
	  first=next;
	  ++*len;
	  break;

	case EXTENSION:
	  next=read2(stacktop,ARG_0(stackbase)/*stream*/,&mylen);
	  UNSTACK_TMP(first); 
	  STACK_TMP(first);
	  if  (first!=nil && !is_cons(first))
	    CallError(stacktop,"Bad extension syntax",nil,NONCONTINUABLE);
	  else
	    {
	      next=list2vector(stacktop,mylen,next);
	      next=EUCALL_2(Fn_cons,next,nil);
	      UNSTACK_TMP(first);
	      CDR(first)=next;
	      first=next;
	      ++*len;
	    }
	  break;

	case CLOSE_PAIR:
	  return ;

	case WRAPPER:
	  STACK_TMP(pptok.lispval);
	  next=read2(stacktop,ARG_0(stackbase)/*stream*/,&mylen);
	  next=EUCALL_2(Fn_cons,next,nil);
	  UNSTACK_TMP(tmp);
	  next=EUCALL_2(Fn_cons,tmp,next);
	  next=EUCALL_2(Fn_cons,next,nil);
	  UNSTACK_TMP(first);
	  CDR(first)=next;
	  first=next;
	  ++*len;
	  break;

	case DOT:
	  next=read2(stacktop,ARG_0(stackbase)/*stream*/,&mylen);
	  if (is_cons(next))
	    CallError(stacktop,"Junk after dot",nil,NONCONTINUABLE);
	  else
	    {
	      UNSTACK_TMP(first);
	      CDR(first)=next;
	      *len= -*len;
	    }
	  break;

	case END_OF_STREAM:
	  CallError(stacktop,"Unexpected end of file",nil,NONCONTINUABLE);
	  break;

	default:
	  next=this_object(stacktop,token);
	  next=EUCALL_2(Fn_cons,next,nil);
	  UNSTACK_TMP(first);
	  CDR(first)=next;
	  first=next;
	  ++*len;
	  break;
	}	
      STACK_TMP(first);
    }
}

static LispObject this_object(LispObject *stacktop, int token)
{
  switch (token)
    {
      /** Literal objects **/
    case CHARACTER:	
    case INTEGER:
    case FLOAT:
    case RATIONAL: /* XXX: Still need to fix this */
    case STRING:
    case IDENTIFIER:
      return pptok.lispval;
      break;
      
    case END_OF_STREAM:
      return q_eof;
      break;

    default:
      CallError(stacktop,"Bad token type",allocate_integer(stacktop,token),NONCONTINUABLE);
    }
}

static LispObject list2vector(LispObject *stacktop,int len, LispObject lst)
{
  LispObject new;
  int i;

  if (len<0)
    CallError(stacktop,"bad vector syntax",lst,NONCONTINUABLE);
  
  new=allocate_vector(stacktop,len);

  for (i=0 ; i<len ; i++)
    {	
      vref(new,i)=CAR(lst);
      lst=CDR(lst);
    }	
  return new;
}

/*
 * Binary stream functions 
 */

EUFUN_1(Fn_read_char,stream)
{
  int ch;

  ch=fgetc(stream->STREAM.handle);
  
  if (ch==-1)
    return q_eof;
  else
    return allocate_char(stacktop,ch);
}
EUFUN_CLOSE


void initialise_input(LispObject *stacktop)
{
  q_eof=allocate_char(stacktop,256);
  add_root(&q_eof);

  (void) make_module_function(stacktop,"read",Fn_read,1);
  current_input=nil;
  add_root(&current_input);
}
