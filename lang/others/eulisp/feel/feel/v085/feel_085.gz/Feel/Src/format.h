/* ******************************************************************** */
/* format.c          Copyright (C) Codemist and University of Bath 1989 */
/*                                                                      */
/* Formatted IO   							*/
/* ******************************************************************** */

extern void initialise_formatted_io(LispObject*);

