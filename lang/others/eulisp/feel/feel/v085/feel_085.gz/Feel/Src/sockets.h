#ifdef WITH_SOCKETS

#include "sio.h"

extern void initialise_sockets(LispObject *);

#endif
