/* ******************************************************************** */
/* lists.h           Copyright (C) Codemist and University of Bath 1989 */
/*                                                                      */
/* basic list operations prototypes	                                */
/* ******************************************************************** */

LispObject Fn_memq(LispObject*);
LispObject Fn_append(LispObject*);

void initialise_lists(LispObject*);

