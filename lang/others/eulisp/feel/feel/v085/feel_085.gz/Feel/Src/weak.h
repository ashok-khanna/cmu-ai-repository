/* 
  * Header for weak ptr stuff 
  * defined in others.c
 */

#define weak_ptr_chain(o)	(slotref(o,1))
#define weak_ptr_val(o)		(slotref(o,0))

#define WEAK_PTR_SIZE 2
extern LispObject Cb_GC_hook;

