/* ******************************************************************** */
/*  bootstrap.h      Copyright (C) Codemist and University of Bath 1989 */
/*                                                                      */
/* C-bootstrapping prototypes and defines                               */
/* ******************************************************************** */

/*
 * Change Log:
 *   Version 1, December 1989
 */

#ifndef BOOTSTRAP_H
#define BOOTSTRAP_H

/* Cbstracted class accessors (not used averywhere...) */

#define CLASS_NAME(class)          (class->CLASS.name)
#define CLASS_SUPER(class)         (class->CLASS.superclass)
#define CLASS_SUB(class)           (class->CLASS.subclasses)
#define CLASS_DESCS(class)         (class->CLASS.slot_table)

extern LispObject symbol_name;
extern LispObject symbol_superclass;
extern LispObject symbol_slot_descriptions;

extern void make_class(LispObject *,
		       LispObject,char *,LispObject,LispObject, int);
extern void gen_class(LispObject *,
		      LispObject *,char *,LispObject,LispObject);

extern LispObject make_list_2(LispObject*,LispObject,LispObject);

extern LispObject Null;

#endif
