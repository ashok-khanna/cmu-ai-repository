/* ******************************************************************** */
/*  root.h           Copyright (C) Codemist and University of Bath 1989 */
/*                                                                      */
/* The root level operations protos                                     */
/* ******************************************************************** */

extern void initialise_module_operators(LispObject *);
