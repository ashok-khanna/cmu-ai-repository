/*
  * Header file for reader
  */

extern void initialise_input(LispObject *);
extern LispObject q_eof; /* end of file character */
