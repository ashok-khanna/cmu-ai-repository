/* search.h: Header file for exterior hash table implementation.
 *	Copyright (c) August 5, 1993 by Darren Senn
 *					(sinster@scintilla.santa-clara.ca.us)
 *	Permission granted for any use.
 */

#include "conf.h"

typedef enum {
	FIND,
	ENTER,
	DELETE
} ACTION;
typedef struct {
	void *key;
	void *data;
} ENTRY;

#ifdef __STDC__
extern int hcreate(int);
extern ENTRY *hsearch(ENTRY, ACTION);
#else
extern int hcreate();
extern ENTRY *hsearch();
#endif
