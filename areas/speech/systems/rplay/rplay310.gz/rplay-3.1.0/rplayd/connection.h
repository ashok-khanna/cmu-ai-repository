/* 
 * Copyright (C) 1993 Mark Boyns (boyns@sdsu.edu)
 *
 * This file is part of rplay.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef _connection_h
#define _connection_h

#include "conf.h"
#include <sys/param.h>
#include "sound.h"
#include "server.h"
#include "buffer.h"

/*
 * event types
 */
#define EVENT_NULL			0
#define EVENT_READ_COMMAND	        1 /* read an RPTP command (client) */
#define EVENT_CONNECT			2 /* connect to a server (server) */
#define EVENT_READ_CONNECT_REPLY	3 /* read a connect reply (server) */
#define EVENT_WRITE_FIND		4 /* write a find command (server) */
#define EVENT_READ_FIND_REPLY		5 /* read a find reply (server) */
#define EVENT_WRITE_GET			6 /* write a get command (server) */
#define EVENT_READ_GET_REPLY		7 /* read a get reply (server) */
#define EVENT_READ_SOUND		8 /* read a sound (both) */
#define EVENT_WRITE			9 /* write buffers (client) */
#define EVENT_WRITE_SOUND		10 /* write a sound (client) */
#define EVENT_WRITE_TIMEOUT		11 /* write connection timeout message (both) */

/*
 * connection types
 */
#define CONNECTION_NULL			0
#define CONNECTION_CLIENT		1
#define CONNECTION_SERVER		2

typedef struct _event
{
	struct _event	*next;
	int		type;
	int		nleft;
	int		nbytes;
	char		*start;
	char		*ptr;
	BUFFER		*buffer;
	SOUND		*sound;
	int		fd;
	int		nconnects;
	long		time;
	int		success;
} EVENT;

typedef struct _connection
{
	struct _connection	*next;
	struct _connection	*prev;
	struct sockaddr_in	sin;
	int			type;
	int			fd;
	EVENT			*event;
	EVENT			**ep;
	SERVER			*server;
	long			time;
} CONNECTION;

extern CONNECTION	*connections;

#ifdef __STDC__
extern CONNECTION	*connection_create(int type);
extern void		connection_destroy(CONNECTION *c);
extern void		connection_client_open();
extern void		connection_update(fd_set *read_fds, fd_set *write_fds);
extern void		connection_close(CONNECTION *c);
extern void		connection_cleanup();
extern void		connection_update_fdset(CONNECTION *c);
extern void		connection_reply(CONNECTION *c, char *fmt, ...);
extern CONNECTION	*connection_server_open(SERVER *server, SOUND *sound);
extern void		connection_server_reopen(CONNECTION *c);
extern void		connection_server_ping(CONNECTION *c);
extern void		connection_check_timeout();
extern void		connection_timeout(CONNECTION *c);
extern void		connection_server_forward_sound(CONNECTION *c, SOUND *s);
extern void		connection_server_foward(CONNECTION *c);
extern BUFFER		*connection_list_create();
extern EVENT		*event_create(int event_type, ...);
extern void		event_insert(CONNECTION *c, EVENT *e);
extern void		event_delete(CONNECTION *c);
extern void		event_update(CONNECTION *c);
extern void		event_destroy(EVENT *e);
extern void		event_replace(CONNECTION *c, EVENT *e);
#else
extern CONNECTION	*connection_create(/* int type */);
extern void		connection_destroy(/* CONNECTION *c */);
extern void		connection_client_open();
extern void		connection_update(/* fd_set *read_fds, fd_set *write_fds */);
extern void		connection_close(/* CONNECTION *c */);
extern void		connection_cleanup();
extern void		connection_update_fdset(/* CONNECTION *c */);
extern void		connection_reply(/* CONNECTION *c, char *fmt, ... */);
extern CONNECTION	*connection_server_open(/* SERVER *server, SOUND *sound */);
extern void		connection_server_ping(/* CONNECTION *c */);
extern void		connection_check_timeout();
extern void		connection_timeout(/* CONNECTION *c */);
extern void		connection_server_forward_sound(/* CONNECTION *c, SOUND *s */);
extern void		connection_server_foward(/* CONNECTION *c */);
extern BUFFER		*connection_list_create();
extern EVENT		*event_create(/* int event_type, ... */);
extern void		event_insert(/* CONNECTION *c, EVENT *e */);
extern void		event_delete(/* CONNECTION *c */);
extern void		event_update(/* CONNECTION *c */);
extern void		event_destroy(/* EVENT *e */);
extern void		event_replace(/* CONNECTION *c, EVENT *e */);
#endif

#endif /* _connection_h */

