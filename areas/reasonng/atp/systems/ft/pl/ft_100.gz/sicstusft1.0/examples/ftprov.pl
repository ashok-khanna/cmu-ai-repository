

% fteasy runs through some easy test examples. fthard takes on the hard ones.
% ftprov(N) tries example N.


ftprov(N,Qi,Qu) :- ftest(N,F),warn(F,G),ft(G,Qi,Qu).
ftprov(N) :- ftprov(N,1,1).
ftprov(N,f) :- ftest(N,F),warn(F,F1),f(F1).
ftprov(N,fu) :- ftest(N,F),warn(F,F1),fu(F1).
ftprov(N,fi) :- ftest(N,F),warn(F,F1),fi(F1).


warn(hard(F),F) :- !,nl,write('hard:').
warn(F,F).


fteasy(M) :- ftest(N,F),N>=M,
    (F=hard(G) -> fail;write(N),once(ftprov(N,f)),nl,fail).
fteasy(M).

fteasy :- fteasy(1).

fthard :- ftest(N,F),
    (F=hard(G) -> (write(N),once(ftprov(N,f)),nl,fail);fail).
fthard.

ftfalse(M) :- ftestf(N,F),nl,write(N),nl,ft(F,M,M),write('WRONG').
ftfalse(M).

once(X) :- X,!.
once(X) :- write(' WRONG'),abort.

ftest(1,e(x,a(y,p(x,y))) imp a(y,e(x,p(x,y)))).
ftest(2,a(x,e(y,p(x) and q(y))) iff e(y,a(x,p(x) and q(y)))). % 2u
ftest(3,a(x,a(y,p(x,y))) iff a(y,a(x,p(x,y)))).
ftest(4,e(x,e(y,p(x,y))) iff e(y,e(x,p(x,y)))).
ftest(5,a(x,p(x) and q(x)) iff a(x,p(x)) and a(x,q(x))).
ftest(6,e(x,p(x) or q(x)) iff e(x,p(x)) or e(x,q(x))).
ftest(7,a(x,p(x) imp q(x)) and e(x,p(x)) imp e(x,q(x))).
ftest(8,a(x,a(y,p(x) imp q(y))) iff (e(x,p(x)) imp a(x,q(x)))).
ftest(9,neg e(x,p(x)) iff a(x,neg p(x))).
ftest(10,(p imp q) imp (neg neg p imp neg neg q)).
ftest(11,neg neg(neg p1 or neg p2 or (p1 and p2))). % 3i
ftest(1100,neg a(x,neg(neg p1(x) or neg p2(x) or (p1(x) and p2(x))))).
ftest(12,a(x,e(y,p(x,y) and q(y))) imp e(x,e(y,q(x) and p(x,y)))). % 2u
ftest(13,e(x,e(y,a(z,p(x,y,z)))) and e(z,a(x,a(y,neg p(x,y,z)))) imp q).
ftest(14,(p iff neg q) imp neg neg (p or q)).
ftest(15,a(x,p(x) iff e(y,q(y) and r(x,y))) imp 
         a(x,neg p(x) iff a(y,neg (q(y) and r(x,y))))).
ftest(16,a(x,p(x) iff q(x)) and a(x,r(x) iff s(x)) imp
         a(x,p(x) and neg r(x) iff q(x) and neg s(x))).
ftest(17,a(x,p(x) imp q(x)) and a(x,q(x) imp s(x)) imp
         a(x,neg neg p(x) imp neg neg s(x))).
ftest(18,e(x,p(x)) and a(x,a(y,p(y) and q(x) imp neg r(x)))
         imp a(x,q(x) and r(x) imp s(x))).
ftest(19,hard(a(x,a(y,p(x) and q(y) iff r(x))) and e(x,p(x) or r(x)) and
         a(x,q(x) or neg q(x)) imp e(x,p(x) and neg q(x)) or a(x,q(x)))).
ftest(20,neg neg ((p iff q iff r) iff (p iff (q iff r)))).
ftest(21,a(x,p(x) imp e(y,q(x,y) and r(y))) and
                e(x,e(y,q(x,y) or p(x))) imp e(x,e(y,q(x,y)))).
ftest(22,a(x,p(x) imp r(x) or e(y,q(x,y))) and
        a(x,r(x) imp neg e(x,p(x))) and e(x,p(x)) imp
        e(x,e(y,q(x,y)))).
ftest(23,e(x,p(x) and a(y,q(y) imp r(x,y) or r(y,x))) and
        e(x,q(x) and a(y,p(y) imp neg r(x,y))) imp
        e(x,e(y,p(x) and q(y) and r(x,y)))).
ftest(24,neg e(x,a(y,q(y) imp r(x,y))) and
        e(x,a(y,s(y) imp r(x,y))) imp
        neg a(x,q(x) imp s(x))).
ftest(25,a(x,p(x) imp p(g(x))) and (p(a) or p(b))
         imp e(x,p(g(g(g(g(g(x)))))))). % 3u sufficient!
ftest(26,e(x,a(y,p(y) imp q(x,y))) and a(x,e(y,q(y,x)) imp
        r(x) or a(y,q(y,x) imp q(x,x))) and e(x,p(x)) imp
        e(x,r(x)) or e(x,q(x,x))).
ftest(27,hard(a(x,p(x) imp p(h(x)) or p(g(x))) and (p(a) or p(b))
         and a(x,neg p(h(x))) imp e(x,p(g(g(g(g(g(x))))))))).
ftest(28,(p1 iff neg q1) and (p2 iff neg q2) imp neg neg(p1 or p2 or 
         (q1 and q2))).
ftest(29,hard(a(x,p(x) iff q1(x) or r(x)) and
        e(x,s(x) and a(y,p(y) imp q(x,y))) and
        e(x,a(y,s(y) iff a(z,h(z) imp b(x,y,z)))) and
        a(x,p(x) or q(x,x)) imp
        a(x,e(y,q(y,x))))).
ftest(30,a(x,a(y,a(z,p(x,y) and p(y,z) imp p(x,z)))) and
        a(x,a(y,p(x,y) imp p(y,x))) imp
        a(x,e(y,p(x,y) or p(y,x)) imp p(x,x))).
ftest(31,a(x,p(x,f(x)) or p(f(x),f(f(x)))) imp e(x,e(y,p(f(y),x)))).
ftest(32,hard(a(x,e(y,a(z,e(w,p(x) and q(y) and r(z) and s(w))))) iff
         e(y,a(x,e(w,a(z,p(x) and r(z) and s(w) and q(y))))))).
ftest(33,(p iff neg q) imp neg neg (p or q)).
ftest(34,a(x,a(y,a(z,a(w,p(x,y,z,w))))) iff a(w,a(z,a(y,a(x,p(x,y,z,w)))))).
ftest(35,e(x,e(y,e(z,e(w,p(x,y,z,w))))) iff e(w,e(z,e(y,e(x,p(x,y,z,w)))))).
ftest(36,e(x,a(y,e(z,a(w,p(x,y,z,w))))) imp a(y,e(x,a(w,e(z,p(x,y,z,w)))))).
ftest(37,a(x,p(x) iff q(x)) imp a(x,p(x)) iff a(x,q(x))).
ftest(38,a(x,p(x) iff q(x)) and e(x,r(x) or p(x)) imp e(x,r(x) or q(x))).
ftest(39,a(x,p(x) iff q(x) or r(x) or e(y,s(x,y))) and
         e(x,e(y,s(y,x) or p(x))) imp 
         e(x,q(x)) or e(x,r(x)) or e(x,e(y,s(x,y)))).
ftest(40,a(x,p(x) iff q(x) or r(x) or e(y,s(x,y))) and
         e(x,e(y,s(y,x) or g(x))) and
         a(x,g(x) iff e(y,s(x,y)) or e(z,r(z) or q(z) or s(y,z))) imp 
         e(x,q(x)) or e(x,r(x)) or e(x,e(y,s(x,y)))).
ftest(41,a(x,p(x) iff t(x) or q(x) or r(x) or e(y,s(x,y))) and
         e(x,e(y,s(y,x) or p(x) or t(x))) imp 
         e(x,q(x)) or e(x,r(x)) or e(x,e(y,s(x,y))) or e(x,t(x))).
ftest(42,a(x,p(x) iff r(x) or e(y,s(x,y))) and
         e(x,e(y,s(y,x) or p(x))) imp 
         e(x,r(x)) or e(x,e(y,s(x,y)))).
ftest(43,a(x,p(x) iff h(x) or t(x) or q(x) or r(x) or e(y,s(x,y))) and
         e(x,e(y,s(y,x) or p(x) or t(x))) imp 
         e(x,h(x)) or e(x,q(x)) or e(x,r(x)) or e(x,e(y,s(x,y))) or e(x,t(x))).
ftest(44,a(x,p(x) iff t(x) or q(x) or r(x) or e(y,s(x,y))) and
            a(x,a(y,(s(x,y) imp q(x)) and (t(x) imp r(x)))) and
            e(x,e(y,s(y,x) or p(x) or t(x))) imp
            e(x,q(x)) or e(x,r(x)) or e(x,e(y,s(x,y))) or e(x,t(x))).
ftest(45,p(a) and neg p(f(f(f(a)))) imp neg neg e(x,p(x) and neg p(f(x)))).
ftest(46,p(a) and neg p(f(f(f(f(f(a)))))) imp  
                          neg neg e(x,p(x) and neg p(f(x)))).
ftest(47,F) :- apphalf(AH),F=(AH imp e(x,append([1,2,3],[],x))).
ftest(48,a(x,(p(x) imp p(g(x))) and neg h) and p(a) imp p(g(g(g(g(a)))))).
ftest(49,hard(a(x,p(x) imp p(h(x)) or p(g(x))) and p(a) and 
          a(x,neg p(h(x))) imp e(x,p(g(g(g(g(g(x))))))))).


apphalf( a(1,x,append([],x,x)) and 
         a(x,a(y,a(z,a(w,append(y,z,w) imp append([x|y],z,[x|w])))))).

