fruitproblem(X) :- 
ft(
a(x,apple(x) imp fruit(x))
and
a(x,pear(x) imp fruit(x))
and
neg e(x,pear(x) and apple(x))
and
a(x,food(x) iff fruit(x) or bread(x) or cheese(x))
and
pear(moltke) and apple(grannysmith) and apple(reddelicious) and cheese(stilton)
imp
food(X)
).

