longprop :- pd(neg neg ((((p imp q) imp zz0)and
((q imp p) imp zz1)and
(zz0 and zz1 imp zz2)and
(zz4 and zz2 imp r)and
(zz6 and p imp q)and
(zz8 and q imp p)and
(zz10 imp zz6)and
(zz10 imp zz8)and
(zz12 and r imp zz10)and
(zz14 imp zz4)and
(zz14 imp zz12)and
((q imp r) imp zz15)and
((r imp q) imp zz16)and
(zz15 and zz16 imp zz17)and
((p imp zz17) imp zz18)and
(zz20 and q imp r)and
(zz22 and r imp q)and
(zz24 imp zz20)and
(zz24 imp zz22)and
((zz24 imp p) imp zz25)and
(zz18 and zz25 imp zz26)and
((zz14 imp zz26) imp zz27)and
(zz29 and q imp r)and
(zz31 and r imp q)and
(zz33 imp zz29)and
(zz33 imp zz31)and
(zz35 and p imp zz33)and
((q imp r) imp zz36)and
((r imp q) imp zz37)and
(zz36 and zz37 imp zz38)and
(zz40 and zz38 imp p)and
(zz42 imp zz35)and
(zz42 imp zz40)and
(zz44 and p imp q)and
(zz46 and q imp p)and
(zz48 imp zz44)and
(zz48 imp zz46)and
((zz48 imp r) imp zz49)and
((p imp q) imp zz50)and
((q imp p) imp zz51)and
(zz50 and zz51 imp zz52)and
((r imp zz52) imp zz53)and
(zz49 and zz53 imp zz54)and
((zz42 imp zz54) imp zz55)and
(zz27 and zz55 imp zz56))
 imp zz56)).
