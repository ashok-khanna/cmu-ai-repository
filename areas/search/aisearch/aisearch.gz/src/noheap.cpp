#include <stdio.h>
#include <stdlib.h>
#include <new.h>

#ifdef MSC
int no_mem(size_t size)
{
    puts("Out of memory");
    exit(1);
    return(0);
}
#else
void no_mem()
{
    puts("Out of memory");
    exit(1);
}
#endif
