#include "tree.h"

/*			AODEPTH_TREE_

    The constructor passes the start node and number of operators on
    to AOSEARCH_

*/

AODEPTH_TREE_::AODEPTH_TREE_(AONODE_ *start, int op)
    :AOSEARCH_(start, op)
{
}



/*			ADD

    This routine adds nodes to the search tree (it adds them to
    the HEAD of open). Nodes of type AND get special treatment: they
    are not meant to be stored on open, but each of its successors is.

*/

void AODEPTH_TREE_::add(AONODE_ *succ)
{
    AONODE_
	*node;
    int
	i;

    if (succ->gettype() == AND)
    {
        i = ((ANDNODE_ *)succ)->getn_nodes() - 1;
	for ( ;i >= 0; i--)	    /* put all successor nodes on open */
	{
	    node = ((ANDNODE_ *)succ)->getsucc(i);
	    node->setparent(succ);
	    open.addtohead(*node);
	}
    }
    else
	open.addtohead(*succ);
}
