#include "tree.h"

/*			AOBREADTH_TREE_

    The constructor just passes the start node and number of operators
    on to AOSEARCH_.

*/

AOBREADTH_TREE_::AOBREADTH_TREE_(AONODE_ *start, int op)
    :AOSEARCH_(start, op)
{
}



/*                    ADD

    This routine adds nodes to the search tree (it adds them to
    the TAIL of open). Nodes of type AND get special treatment: they
    are not meant to be stored on open, but each of its successors is.

*/  

void AOBREADTH_TREE_::add(AONODE_ *succ)
{
    AONODE_
	*node;
    int
	i,
	num;

    if (succ->gettype() == AND)
    {
        num = ((ANDNODE_ *)succ)->getn_nodes();
	for (i = 0 ;i < num; i++)	/* put all successors on open */
	{
	    node = ((ANDNODE_ *)succ)->getsucc(i);
	    node->setparent(succ);
	    open.addtotail(*node);
	}
    }
    else
	open.addtotail(*succ);
}
