#include "object.h" 

VOBJECT_::~VOBJECT_()
{
}
