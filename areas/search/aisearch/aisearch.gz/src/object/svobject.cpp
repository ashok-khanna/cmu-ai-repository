#include "object.h"

SVOBJECT_::~SVOBJECT_()
{
}

