#include "nodes.h"

/*			ORNODE_

    The constructor calls AONODE_ to set type of node to OR
    and initializes node's successor pointer to NULL.

*/

ORNODE_::ORNODE_()
    :AONODE_(OR)
{
    succ = NULL;
}


/*			SETSUCC

    Makes node point to given successor.

*/

void ORNODE_::setsucc(AONODE_ *node)
{
    succ = node;
}


/*			GETSUCC

    Returns node's successor.

*/

AONODE_ *ORNODE_::getsucc() const
{
    return(succ);
}

