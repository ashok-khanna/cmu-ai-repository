#include "graph.h"

/*			BIBREADTH_GRAPH_

    The constructor passes the start node, goal node and the number
    of operators to BISEARCH_.

*/

BIBREADTH_GRAPH_::BIBREADTH_GRAPH_(NODE_ *start, NODE_ *goal, int op)
    :BISEARCH_(start, goal, op)
{
}



/*			ADD

    Adds a node to one of the search graphs, only if it's not
    already in the graph.

*/

int BIBREADTH_GRAPH_::add(SORTEDLIST_ *x_open, SORTEDLIST_ *x_closed, NODE_ *succ)
{
    if (!x_closed->lookup(*succ) && !x_open->lookup(*succ))
// if successor is neither on x_open nor x_closed add it to the TAIL of x_open
    {
        x_open->addtotail(*succ);
        return(1);
    }
    return(0);
}
