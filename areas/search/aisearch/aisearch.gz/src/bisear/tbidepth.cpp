#include "tree.h"

/*                      BIDEPTH_TREE_

    The constructor passes the start node, goal node and the number
    of operators to BISEARCH_.

*/

BIDEPTH_TREE_::BIDEPTH_TREE_(NODE_ *start, NODE_ *goal, int op)
    :BISEARCH_(start, goal, op)
{
}



/*                      ADD

      Adds a node to one of the search graphs, without checking if it's
      already in the graph.

*/

int BIDEPTH_TREE_::add(SORTEDLIST_ *x_open, SORTEDLIST_ *, NODE_ *succ)
{
    x_open->addtohead(*succ);
    return(1);
}
