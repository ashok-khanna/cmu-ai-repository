#include "tree.h"

/*                      BIBREADTH_TREE_

    The constructor passes the start node, goal node and the number
    of operators to BISEARCH_.

*/

BIBREADTH_TREE_::BIBREADTH_TREE_(NODE_ *start, NODE_ *goal, int op)
    :BISEARCH_(start, goal, op)
{
}



/*                      ADD

    Adds a node to one of the search graphs, without checking if it's
    already in the graph.

*/

int BIBREADTH_TREE_::add(SORTEDLIST_ *x_open, SORTEDLIST_ *, NODE_ *succ)
{
    x_open->addtotail(*succ);
    return(1);
}
