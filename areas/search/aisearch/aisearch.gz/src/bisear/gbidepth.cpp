#include "graph.h"

/*                      BIDEPTH_GRAPH_

    The constructor passes the start node, goal node and the number
    of operators to BISEARCH_.

*/

BIDEPTH_GRAPH_::BIDEPTH_GRAPH_(NODE_ *start, NODE_ *goal, int op)
    :BISEARCH_(start, goal, op)
{
}



/*                      ADD

    Adds a node to one of the search graphs, only if it's not
    already in the graph.

*/

int BIDEPTH_GRAPH_::add(SORTEDLIST_ *x_open, SORTEDLIST_ *x_closed, NODE_ *succ)
{
    if (!x_closed->lookup(*succ) && !x_open->lookup(*succ))
// if successor is neither on x_open nor x_closed add it to the HEAD of x_open
    {
        x_open->addtohead(*succ);
        return(1);
    }
    return(0);
}
