#include "list.h"

SORTEDLIST_::SORTEDLIST_(int dstr)
    : LIST_(dstr)
{
}


void SORTEDLIST_::insert(SVOBJECT_ &obj)
{
    LIST_NODE_
        *cur;

    if (!head || obj.eval(*(SVOBJECT_ *)head->getdata()) < 0)
        addtohead(obj);

    else
    {
        for (cur = head->getnext(); cur; cur = cur->getnext())
            if (obj.eval(*(SVOBJECT_ *)cur->getdata()) <= 0)
            {
                cur->setprev(new LIST_NODE_(obj, cur, cur->getprev()));
                cur->getprev()->getprev()->setnext(cur->getprev());
		nodecount++;
                break;
            }
        if (!cur)
            addtotail(obj);
    }
}
