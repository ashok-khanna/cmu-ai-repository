#include "list.h"

int LIST_NODE_::destroy = NODEALLOC;


LIST_NODE_::LIST_NODE_()
{
    data = NULL;
    next = NULL;
    prev = NULL;
}


LIST_NODE_::LIST_NODE_(VOBJECT_ &obj)
{
    data = &obj;
    next = NULL;
    prev = NULL;
}


LIST_NODE_::LIST_NODE_(VOBJECT_ &obj, LIST_NODE_ *list, LIST_NODE_ *list2)
{
    data = &obj;
    next = list;
    prev = list2;
}


LIST_NODE_::~LIST_NODE_()
{
    if (destroy == DEALLOC)
        delete(data);
}


void LIST_NODE_::setdata(VOBJECT_ &obj)
{
    delete(data);
    data = &obj;
}


void LIST_NODE_::setnext(LIST_NODE_ *list)
{
    next = list;
}


void LIST_NODE_::setprev(LIST_NODE_ *list)
{
    prev = list;
}


VOBJECT_ *LIST_NODE_::getdata() const
{
    return(data);
}


LIST_NODE_ *LIST_NODE_::getnext() const
{
    return(next);
}


LIST_NODE_ *LIST_NODE_:: getprev() const
{
    return(prev);
}

