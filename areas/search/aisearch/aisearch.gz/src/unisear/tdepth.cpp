#include "tree.h"

/*                      DEPTH_TREE_

    The constructor passes the start node, goal node and the number of
    operators to SEARCH_.

*/

DEPTH_TREE_::DEPTH_TREE_(NODE_ *start, NODE_ *goal, int op)
    :SEARCH_(start, goal, op)
{
}



/*                      ADD

    Adds a node to the search graph, without checking if it's already
    in the graph.

*/

int DEPTH_TREE_::add(NODE_ *succ)
{
    open.addtohead(*succ);
    return(1);
}
