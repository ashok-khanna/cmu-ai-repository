#include "tree.h"

/*                      UNICOST_TREE_

    The constructor passes the start node, goal node and number of
    operators to SEARCH_.

*/

UNICOST_TREE_::UNICOST_TREE_(UNI_NODE_ *start, UNI_NODE_ *goal, int op)
    :SEARCH_(start, goal, op)
{
}



int UNICOST_TREE_::add(NODE_ *succ)
{
    const UNI_NODE_
        *parent;
    UNI_NODE_
        *bsucc = (UNI_NODE_ *) succ;

    int
        g;

    parent = (UNI_NODE_ *) bsucc->getparent();

    g = parent->get_g() + compute_g(*bsucc);
    bsucc->set_g(g);

    open.insert(*bsucc);
    return(1);
}
