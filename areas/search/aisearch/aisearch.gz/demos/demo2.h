#include <stdio.h>
#include "graph.h"

/*                  DEMO2

    The object of this problem is to find a path leading from
    x1, y1 to x2, y2 on an empty chessboard by moving a knight
    around. We perform a breadth first search.

*/

class KNODE_ : public NODE_
{
    public:
        KNODE_(int x, int y);
        int get_x() const;
        int get_y() const;

// implementation of virtual functions
        int equal(const VOBJECT_ &) const;
        void display() const;
        NODE_ *do_operator(int) const;
    private:
        int
            x,
            y;
};


class KNIGHT_ : public BREADTH_GRAPH_
{
    public:
        KNIGHT_(KNODE_ *start, KNODE_ *goal);
};

