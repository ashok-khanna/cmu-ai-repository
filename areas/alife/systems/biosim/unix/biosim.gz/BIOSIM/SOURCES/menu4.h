/************************************************************************************************************************

	PROGRAM:	BIOSIM

	FILENAME:	menu4.h

	PURPOSE:	definitions for menu4.c

************************************************************************************************************************/

#define DIALOG_TEXT_TT 		1000
#define DIALOG_TEXT_STR 	1001
#define DIALOG_TEXT_SLOPE	1002
#define DIALOG_TEXT_STM		1003
#define DIALOG_TEXT_LTT		1004
#define DIALOG_TEXT_LTM		1005
#define DIALOG_TEXT_HI		1006
#define DIALOG_TEXT_HLF		1007
#define DIALOG_TEXT_COMPLF	1008
#define DIALOG_TEXT_KLF		1009
#define DIALOG_TEXT_CLF		1010
#define DIALOG_TEXT_TRT		1011
#define DIALOG_TEXT_TRS		1012
#define DIALOG_TEXT_AMAXSTR 	1013

#define DIALOG_SCALE_TT 	1050
#define DIALOG_SCALE_STR	1051
#define DIALOG_SCALE_SLOPE	1052
#define DIALOG_SCALE_STM	1053
#define DIALOG_SCALE_LTT	1054
#define DIALOG_SCALE_LTM	1055
#define DIALOG_SCALE_HI		1056
#define DIALOG_SCALE_HLF	1057
#define DIALOG_SCALE_COMPLF	1058
#define DIALOG_SCALE_KLF	1059
#define DIALOG_SCALE_CLF	1060
#define DIALOG_SCALE_TRT	1061
#define DIALOG_SCALE_TRS	1062
#define DIALOG_SCALE_AMAXSTR	1063

#define DIALOG_DEF_TT 		1100
#define DIALOG_DEF_STR 		1101
#define DIALOG_DEF_SLOPE	1102
#define DIALOG_DEF_STM		1103
#define DIALOG_DEF_LTT		1104
#define DIALOG_DEF_LTM		1105
#define DIALOG_DEF_HI		1106
#define DIALOG_DEF_HLF		1107
#define DIALOG_DEF_COMPLF	1108
#define DIALOG_DEF_KLF		1109
#define DIALOG_DEF_CLF		1110
#define DIALOG_DEF_TRT		1111
#define DIALOG_DEF_TRS		1112
#define DIALOG_DEF_AMAXSTR 	1113

#define DIALOG_AXOSYNAPSE 	1050
#define DIALOG_LEARNPARAM	1151

#define DIALOG_SELECT_LEARNPARAM	1160

struct SynapseSelection
{
	double	SLOPE;
	double	STM;
	double	LTT;
	double	LTM;
	double	HI;
	double	HLF;
	double	COMPLF;
	double	KLF;
	double	CLF;
};
