//			GSTREAM.HPP
// DESCRIPTIONS: class that turns gnuplot into a stream, into which you can print
// as any other

// CAVEATS: Only for UNIX!!!!

// LOG :
// 11-May-94	: Creacion
// 19-may-94	: alteracion de los nombres de los ficheros; y correccion del
//		    error, lo dejaba todo perdido de gnus...

#ifndef __GSTREAM_HPP
#define __GSTREAM_HPP


#include <stdio.h>

class gstream {
    FILE *gnuFile;
    char tempGnu[17];
    
    friend gstream& operator << ( gstream&, float );
    friend gstream& operator << ( gstream&, float* );
    rePlot();				// private func
    
public:
    gstream( char* _initStr);
    ~gstream();
    const char* getTemp() const { return tempGnu; };
};

#endif
