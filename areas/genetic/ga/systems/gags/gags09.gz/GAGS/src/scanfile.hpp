#include <fstream.h>
#include <strstream.h>


template <class T>
void scanFile(  T * _rgStart, T * _rgEnd ,		
		char* _fileN,		
		char* _inputFile, 
		unsigned& _popSize,
		double& _mutRate,
		unsigned& _gens,
		unsigned& _locusSize,
		unsigned _genSize ) {	    // number of generations
		
    char line[40],  foo[40];
    ifstream fin( _fileN );
    while (!fin.eof()) {
	unsigned i;
	fin.getline( line, 40);
	istrstream istr( line, 40 );
	switch ( line[0] ) {
	    case 'i':
	    case 'I':	    // input file
		istr >> foo>> _inputFile;
		break;
	    case 's':	    // startRange
	    case 'S':
		istr >> foo;
		for (  i = 0; i < genSize; i ++ )
		    istr >> _rgStart[i];
		 break;
	    case 'e':
	    case 'E':	    // endRange
		istr >> foo;
		for (  i = 0; i < genSize; i ++ )
		    istr >> _rgEnd[i];
		break;
	    case 'p':
	    case 'P':	    // popSize
		istr>> foo >> _popSize;
		break;
	    case 'm':
	    case 'M':	    // mutation Rate
		istr>> foo >> _mutRate;
		break;
	    case 'G':
	    case 'g':	    // Generations
		istr >> foo >> _gens;
		break;
	    case 'L':
	    case 'l':	    // Generations
		istr >> foo >> _locusSize;
		break;
	}
    }	// while
};
