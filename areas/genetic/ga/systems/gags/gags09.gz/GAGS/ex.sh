#!/bin/csh
set perle=`which perl`
if ( $#perle > 1 ) then
    echo Perl does not exist or is not in your path
else
    echo \#\!$perle >__perlfile    
endif

set gnue=`which gnuplot`
if ( $#gnue > 1 ) then
    echo Gnuplot does not exist or is not in your path
endif

