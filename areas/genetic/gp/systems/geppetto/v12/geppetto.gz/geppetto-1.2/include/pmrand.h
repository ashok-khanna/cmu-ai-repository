#ifndef PMRAND_H
#define PMRAND_H

#include "compiler.h"

#ifdef THINK_C
typedef long		rndint;
typedef unsigned long	urndint;
#else
typedef int		rndint;
typedef unsigned int	urndint;
#endif

void srnd P((rndint seed));
urndint grnd P((NOARGS));
double drnd P((NOARGS));
rndint irnd P((NOARGS));
rndint irndrng P((rndint low, rndint high));
double drndrng P((double low, double high));

#endif /* PMRAND_H */
