/*
 * Copyright (C) 1993 by Dave Glowacki
 *
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for any purpose and without fee is hereby granted, provided
 * that the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation.  This software is provided "as is" without express or
 * implied warranty.
 */

#include <stdio.h>
#include "blob.h"
#include "object.h"

blob *
blobCreate(dtype)
datatype dtype;
{
  fprintf(stderr, "You need to write your own blobCreate() routine!\n");
  return(0);
}

blob *
blobCopy(bbp, dtype)
const blob *bbp;
datatype dtype;
{
  fprintf(stderr, "You need to write your own blobCopy() routine!\n");
  return(0);
}

int
blobCompare(bbp1, bbp2, dtype)
const blob *bbp1, *bbp2;
datatype dtype;
{
  fprintf(stderr, "You need to write your own blobCompare() routine!\n");
  return(0);
}

blob *
blobParse(sp, dtp)
const char **sp;
datatype *dtp;
{
  fprintf(stderr, "You need to write your own blobParse() routine!\n");
  return(0);
}

int
blobToString(bbp, dtype, cstr)
const blob *bbp;
datatype dtype;
charString *cstr;
{
  fprintf(stderr, "You need to write your own blobToString() routine!\n");
  return(0);
}

void
blobFree(bbp, dtype)
blob *bbp;
datatype dtype;
{
  fprintf(stderr, "You need to write your own blobFree() routine!\n");
}
