#ifndef GEPPETTO_H
#define GEPPETTO_H

/* all the header files an application could ever want */
#include "pmrand.h"
#include "objectlist.h"
#include "constntsrc.h"
#include "constant.h"
#include "variable.h"
#include "operatrsrc.h"
#include "operator.h"
#include "result.h"
#include "resultlist.h"
#include "interface.h"

void appInitialize P((interface *ip));

#endif /* GEPPETTO_H */
