#!/bin/sh

for i in pmrand charstring genlist objtypes result resultlist constant  variable constntsrc operator operatrsrc objectlist program interface  population; do
  echo $i
  ./$i > /tmp/debug.out 2>&1
  if [ ! -f debug/$i.out ]; then
    mv /tmp/debug.out debug/$i.out
  else
    diff debug/$i.out /tmp/debug.out > /tmp/diff.out 2>&1
    if [ $? -eq 0 ]; then
      echo "$i OK"
    else
      echo $i
      cat /tmp/diff.out
    fi
  fi
done
rm -f /tmp/debug.out /tmp/diff.out
