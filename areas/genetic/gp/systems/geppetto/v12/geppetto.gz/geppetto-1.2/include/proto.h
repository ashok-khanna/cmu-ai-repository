#include "compiler.h"

#ifdef THINK_C
#include <stdlib.h>
#include <unix.h>
#else
#include <sys/types.h>
#endif /* THINK_C */

double atof P((const char *));
int atoi P((const char *));
#ifndef _DEBUG_MALLOC_INC
int bcmp P((const void *, const void *, size_t));
void *bcopy P((const void *, void *, size_t));
void bzero P((const void *, size_t));
#endif /* !_DEBUG_MALLOC_INC */
#ifdef SOCK_STREAM
int bind P((int, struct sockaddr *, int));
#endif /* SOCK_STREAM */
void *bsearch P((const void *, const void *, size_t, size_t,
			  int (*)(const void *, const void *)));
int close P((int));
#ifdef SOCK_STREAM
int connect P((int, struct sockaddr *, int));
#endif /* SOCK_STREAM */
double cos P((double));
double drand48 P((NOARGS));
void exit P((int));
double exp P((double));
#ifdef FILE
int _flsbuf P((unsigned char, FILE *));
int fclose P((FILE *));
int fflush P((FILE *));
int fprintf P((FILE *, const char *, ...));
int fputc P((char, FILE *));
int fputs P((const char *, FILE *));
#endif /* FILE */
#ifndef _DEBUG_MALLOC_INC
#if defined(THINK_C) || defined(__osf__)
void free P((void *));
#endif /* THINK_C */
#endif /* !_DEBUG_MALLOC_INC */
char *getenv P((const char *));
#ifdef __osf__
int getopt P((int, char *[], char *));
#else
int getopt P((int, char * const [], const char *));
#endif
#ifdef SOCK_STREAM
int getsockname P((int, struct sockaddr *, int *));
#endif /* SOCK_STREAM */
#ifdef DST_NONE
int gettimeofday P((struct timeval *, struct timezone *));
#endif
#ifndef THINK_C
int ioctl P((int, int, ...));
#endif /* !THINK_C */
#ifndef isspace
int isspace P((int));
#endif /* !isspace */
double log P((double));
long lrand48 P((NOARGS));
#ifndef _DEBUG_MALLOC_INC
#if defined(THINK_C) || defined(__osf__)
void *malloc P((size_t));
#endif /* THINK_C */
int memcmp P((const void *, const void *, size_t));
#if defined(__osf__) && !defined(__STDC__)
char *memcpy P((void *, const void *, size_t));
#else /* __osf && !__STDC__ */
void *memcpy P((void *, const void *, size_t));
#endif /* __OSF__ && !__STDC__ */
#endif /* !_DEBUG_MALLOC_INC */
#if defined(THINK_C) || defined(ultrix) || defined(hpux) || defined(__osf__)
void perror P((const char *));
#else /* !THINK_C && !ultrix && !hpux */
int perror P((const char *));
#endif /* THINK_C || ultrix || hpux */
#ifndef MIPSEB
int printf P((const char *, ...));
#endif
#ifndef putchar
#if defined(ultrix) || defined(hpux)
int putchar P((int));
#else
int putchar P((char));
#endif
#endif /* putchar */
int puts P((const char *));
#if defined(THINK_C) || defined(ultrix) || defined(hpux) || defined(__osf__)
void qsort P((void *, size_t, size_t, int (*)(const void *, const void *)));
int rand P((NOARGS));
int random P((NOARGS));
#ifdef hpux
ssize_t read P((int, void *, size_t));
#else
int read P((int, char *, unsigned));
#endif
void *realloc P((void *, size_t));
#else /* !THINK_C && !ultrix && !hpux */
int qsort P((char *, int, int, int (*)(const void *, const void *)));
long rand P((NOARGS));
long random P((NOARGS));
int read P((int, char *, int));
#endif /* THINK_C || ultrix || hpux */
int shutdown P((int, int));
double sin P((double));
int socket P((int, int, int));
#if defined(THINK_C) || defined(__osf__)
int sprintf P((char *, const char *, ...));
void srand P((unsigned int));
#else /* !THINK_C */
#ifndef __GNUC__
char *sprintf P((char *, const char *, ...));
void srand P((int));
#endif /* __GNUC__ */
void srand48 P((long));
void srandom P((int));
#endif /* THINK_C */
#ifndef _DEBUG_MALLOC_INC
char *strcat P((char *, const char *));
char *strchr P((const char *, int));
int strcmp P((const char *, const char *));
char *strcpy P((char *, const char *));
#if defined(THINK_C) || defined(ultrix) || defined(hpux) || \
       (defined(__osf__) && defined(__GNUC__))
size_t strlen P((const char *));
int strncmp P((const char *, const char *, size_t));
#else /* !THINK_C && !ultrix && !hpux && !(__osf_ && __GNUC__) */
int strlen P((const char *));
int strncmp P((const char *, const char *, int));
#endif /* THINK_C || ultrix || hpux */
char *strrchr P((const char *, int));
char *strstr P((const char *, const char *));
#endif /* !_DEBUG_MALLOC_INC */
long strtol P((const char *, char **, int));
double strtod P((const char *, char **));
int tgetent P((const char *, const char *));
int tgetflag P((const char *));
int tgetnum P((const char *));
char *tgetstr P((const char *, char **));
char *tgoto P((const char *, int, int));
#ifndef THINK_C
time_t time P((time_t *));
#endif /* !THINK_C */
char *tmpnam P((char *));
#ifndef tolower
int tolower P((int));
#endif /* tolower */
int tputs P((const char *, int, int (*)(int)));
int unlink P((const char *));
#ifdef THINK_C
int write P((int, char *, unsigned));
#else /* !THINK_C */
#ifdef hpux
ssize_t write P((int, const void *, size_t));
#else /* !hpux */
int write P((int, const char *, int));
#endif /* hpux */
#endif /* THINK_C */

#ifdef WINDOW
int delwin P((WINDOW *));
int endwin P((NOARGS));
int stty P((int, SGTTY *));
int waddch P((WINDOW *, int));
int waddstr P((WINDOW *, const char *));
int wclear P((WINDOW *));
int werase P((WINDOW *));
int wgetch P((WINDOW *));
int wmove P((WINDOW *, unsigned, unsigned));
int wrefresh P((WINDOW *));
int wstandout P((WINDOW *));
int wstandend P((WINDOW *));
#endif /* WINDOW */
