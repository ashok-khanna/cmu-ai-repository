#ifndef OPTRIVIAL_H
#define OPTRIVIAL_H

result *opAdd P((const result **, void *));
result *opSubtract P((const result **, void *));
result *opComplexAdd P((int, const object **, void *));
result *opComplexSubtract P((int, const object **, void *));

#endif /* OPTRIVIAL_H */
