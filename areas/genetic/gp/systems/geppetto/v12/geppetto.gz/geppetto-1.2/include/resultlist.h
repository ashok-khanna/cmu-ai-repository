#ifndef RESULTLIST_H
#define RESULTLIST_H

#include "compiler.h"
#include "genlist.h"
#include "charstring.h"

typedef genericList resultList;

#include "result.h"

#define resultListCreate(len)	genericListCreate(sizeof(result *), len)
#define resultListAdd(rlp, rp)	genericListAdd(rlp, &rp)
#define resultListCopy(rlp)	genericListCopy(rlp)
#define resultListEntry(rlp, i)	*(result **)genericListEntry(rlp, i)
#define resultListLength(rlp)	genericListLength(rlp)

int resultListCompare P((const resultList *rlp1, const resultList *rlp2));
int resultListToString P((const resultList *rlp, charString *cstr));
void resultListFree P((resultList *rlp));

#endif /* RESULTLIST_H */
