#ifndef COMPILER_H
#define COMPILER_H

#ifdef __STDC__
#define P(a) a
#define NOARGS  void
#else
#define P(a) ()
#define NOARGS
#define const
#endif

#if defined(THINK_C) || defined(hpux)
#include <stdlib.h>
#endif

#endif /* COMPILER_H */
