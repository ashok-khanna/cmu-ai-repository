// Cross.cpp -> crosses two gps together to produce resulting child

// 10/11/93 apf

/* Genetic Programming System using the C++ programming language

 Input is of the form gp <pop> <gen> <output file>

 A Potted History:

	 Version 1.00 BETA (sometime March 1993). Very Buggy,...
	 Version 2.00 C++ version very easy language 16 July 1993
								ERRORS in load and saving a genetic program.
											 No capacity for extended memory in DOS.
											 No differing creation mechanism.
											 No touranment selection
											 No capacity for encapsulation
	 Version 3.00 C++ Version.( Uncompatible with previous versions )
											 Robust with full use of OOP techniques.
											 Compatibility with ANSI standard.
											 Ramped half and half implemented.
											 Tournament selection implemented.
											 Changing variables does not require recompiling.
											 BUT STILL
											 No capacity for expanded or extended memory in DOS.
											 No capacity for encapsulation.

	 C version in progress
	 Windows version in progress but its all gobblydegook.


	 Version 3.00 can be compiled in the DOS and UNIX domain
	 but NOT in Windows. This was not made clear in previous programs.

 Genetic programming in C++ was designed and choreographed by Adam P.Fraser

		Food parcels, cash and trashy sci-fi novels to:

					 a.fraser@eee.salford.ac.uk
					snail:
					 A.Fraser
					 PostGraduate Section,
					 Maxwell Building,
					 Elec & Elec Eng,
					 University Of Salford,
					 Salford,
					 M5 4WT.
					 England


		Your comments, improvements and complaints are welcome.


 This code is intended as a base for C++ GPers. Please if you adapt the code
 send me a msg. Also could you please keeps these comments and my address in
 the code.

							regards,
											Adam Fraser ;-)
											16 November 1993

	' and one day there shall come an artificial ant who can complete the santa
	fe trail in 400 evaluation steps and on that day there shall be oink flap'
*/


#include "gp.hpp"

// NB if we did not need to check on the maximum depth of the GP created it
//   would be unnecessary for the dummy variable pgpNew which would make this
//   function inherently simple.... apf

void GP::Cross( GP *dad, int maxdepthforcrossover )
{
	Gene *cutmum, *cutdad;
	GP *pgpNew = new GP;

	do
	{
		pgpNew->Copy( this );

		cutmum = pgpNew->Choose();
		cutdad = dad->Choose();

// Basically these next components are a splice operation for the GP

		if ( cutmum->pgChild ) delete cutmum->pgChild;

		if ( cutdad->pgChild )
		{
			if ( !(cutmum->pgChild = new Gene(cutdad->pgChild)) )
				ExitSystem( "GP::Cross" );
		}
		else cutmum->pgChild = NULL;

		cutmum->iValue = cutdad->iValue;

// Note we do not change mums next value as this must stay the same...

	} while ( ( pgpNew->Depth() > maxdepthforcrossover )
																&& ( pgpNew->pgHeader ) );

// want to continue looping if we get a NULL string or a Gp greater than
// the max depth of crossover....

	pgpNew->Length();

	Copy( pgpNew );

	delete pgpNew;
}




