#include <iostream.h>
#include <stdlib.h>

// Function Prototype

void ExitSystem( char * );

// The code

void ExitSystem( char *msg )
{
	cout << msg << endl;

	cout << "Genetic Programming in C++: An Evolutionary Solution by Adam P.Fraser" << endl;

	exit(EXIT_FAILURE);
}
