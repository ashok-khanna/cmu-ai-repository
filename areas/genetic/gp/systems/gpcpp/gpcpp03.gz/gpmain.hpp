// gpmain.hpp
// By Adam Fraser 7/06/93

#ifndef __GPMAIN

#define __GPMAIN

enum BOOL { FALSE = 0, TRUE = 1 };


#include "pop.hpp"

#endif

//gpmain.hpp