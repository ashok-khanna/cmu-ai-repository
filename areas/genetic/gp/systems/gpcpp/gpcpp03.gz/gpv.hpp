#ifndef __GPV

#define __GPV

#include "gp.hpp"
#include <fstream.h>

struct GPVariables
{
  unsigned int PopulationSize,
							 NumberOfGenerations,
							 NumberOfEvaluations,
							 MaximumFitness,
							 MaximumDepthForCreation,
							 MaximumDepthForCrossover,
							 NumberToReproduce,
							 NumberToCrossover;

	unsigned long MaximumSumFitness;

	CREATIONTYPE CreationType;

// Functions

  friend ostream& operator << (ostream&, GPVariables* );

	GPVariables(int, int);
  void Save( ostream& );
  void Load( istream& );
};

#endif