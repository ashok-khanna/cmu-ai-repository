/* trail.h */

/* #define ANALYSIS */


#ifndef TRAIL

#define TRAIL

#define World_Horizontal 32       		/* defined in trail.cpp */
#define World_Vertical  32

extern unsigned char World[World_Horizontal][World_Vertical];
extern void CreateWorld( void );
extern void CreateTrail( void );

#ifdef ANALYSIS
#include <graphics.h>
#include <conio.h>
extern void World_Drawer( void );
extern void GetKey( void );
#endif

#endif
