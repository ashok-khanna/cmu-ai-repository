/*                        Santa Fe Trail Builder
													\\\\\\\\\\\//////////

	 This is the trail in John Koza's paper in ALife II.....

	 Designs and builds santa fe trail so there........................
*/

/* Genetic Programming System using the C++ programming language

 Input is of the form gp <pop> <gen> <output file>

 A Potted History:

	 Version 1.00 BETA (sometime March 1993). Very Buggy,...
	 Version 2.00 C++ version very easy language 16 July 1993
								ERRORS in load and saving a genetic program.
											 No capacity for extended memory in DOS.
											 No differing creation mechanism.
											 No touranment selection
											 No capacity for encapsulation
	 Version 3.00 C++ Version.( Uncompatible with previous versions )
											 Robust with full use of OOP techniques.
											 Compatibility with ANSI standard.
											 Ramped half and half implemented.
											 Tournament selection implemented.
											 Changing variables does not require recompiling.
											 BUT STILL
											 No capacity for expanded or extended memory in DOS.
											 No capacity for encapsulation.

	 C version in progress
	 Windows version in progress but its all gobblydegook.


	 Version 3.00 can be compiled in the DOS and UNIX domain
	 but NOT in Windows. This was not made clear in previous programs.

 Genetic programming in C++ was designed and choreographed by Adam P.Fraser

		Food parcels, cash and trashy sci-fi novels to:

					 a.fraser@eee.salford.ac.uk
					snail:
					 A.Fraser
					 PostGraduate Section,
					 Maxwell Building,
					 Elec & Elec Eng,
					 University Of Salford,
					 Salford,
					 M5 4WT.
					 England


		Your comments, improvements and complaints are welcome.


 This code is intended as a base for C++ GPers. Please if you adapt the code
 send me a msg. Also could you please keeps these comments and my address in
 the code.

							regards,
											Adam Fraser ;-)
											16 November 1993

	' and one day there shall come an artificial ant who can complete the santa
	fe trail in 400 evaluation steps and on that day there shall be oink flap'
*/


#include "trail.h"


#ifdef ANALYSIS

	#include <stdio.h>              /* Needed for test and debugger */
	#include <stdlib.h>
	#include <graphics.h>
	#include <conio.h>

	const int Wall_Colour = YELLOW;
	const int Space_Colour = RED;

	void Wall_Drawer( void );
#endif


/*  Function Prototypes..............................................*/

void CreateWorld( void );
void CreateTrail( void );

/* GLOBAL variables..................................................*/

unsigned char World[World_Horizontal][World_Vertical];




/* Making the array sub routine......................................*/

void CreateWorld( void )
{
	int i,j;

	for (i=1; i<World_Horizontal; i++)
	{
		for (j=1; j<World_Vertical; j++)
		{
			World[i][j]=0;
		}
	}
}

void CreateTrail( void )
{
	int i,j;

	for (i=1; i<4; i++)                     /* Horizontal Components */
		World[i][0]=1;

	for (i=24; i<30; i++)
		World[i][2]=1;

	for (i=3; i<14; i++)
		World[i][5]=1;

	for (i=20; i<25; i++)
		World[i][5]=1;

	for (i=23; i<30; i++)
		World[i][14]=1;

	for (i=16; i<21; i++)
		World[i][15]=1;

	for (i=23; i<28; i++)
		World[i][18]=1;

	for (i=23; i<28; i++)
		World[i][22]=1;

	for (i=1; i<14; i++)
		World[i][24]=1;

	for (i=7; i<17; i++)
		World[i][27]=1;

	for (i=1; i<8; i++)
		World[i][30]=1;



	for (j=1; j<5; j++)                          /* Vertical Components */
		World[3][j]=1;

	for (j=6; j<24; j++)
		World[13][j]=1;

	for (j=25; j<30; j++)
		World[1][j]=1;

	for (j=28; j<30; j++)
		World[7][j]=1;

	for (j=16; j<27; j++)
		World[16][j]=1;

	for (j=6; j<15; j++)
		World[20][j]=1;

	for (j=3; j<5; j++)
		World[24][j]=1;

	for (j=3; j<14; j++)
		World[29][j]=1;

	for (j=15; j<18; j++)
		World[23][j]=1;

	for (j=19; j<22; j++)
		World[27][j]=1;

	for (j=23; j<24; j++)
		World[23][j]=1;


	World[24][2]=2;
	World[28][2]=2;   													/* The Blanks!!! */
	World[29][2]=2;
	World[8][5]=2;
	World[20][5]=2;
	World[23][5]=2;
	World[24][5]=2;
	World[29][5]=2;
	World[29][7]=2;
	World[29][8]=2;
	World[29][10]=2;
	World[29][11]=2;
	World[29][13]=2;
	World[29][14]=2;
	World[20][6]=2;
	World[20][11]=2;
	World[20][12]=2;
	World[13][10]=2;
	World[13][15]=2;
	World[13][16]=2;
	World[13][24]=2;
	World[1][24]=2;
	World[2][24]=2;
	World[5][24]=2;
	World[6][24]=2;
	World[1][29]=2;
	World[1][30]=2;
	World[6][30]=2;
	World[7][30]=2;
	World[7][27]=2;
	World[15][27]=2;
	World[16][27]=2;
	World[16][23]=2;
	World[16][22]=2;
	World[16][17]=2;
	World[16][16]=2;
	World[16][15]=2;
	World[18][15]=2;
	World[19][15]=2;
	World[20][15]=2;
	World[23][14]=2;
	World[24][14]=2;
	World[25][14]=2;
	World[23][16]=2;
	World[23][17]=2;
	World[23][18]=2;
	World[25][18]=2;
	World[26][18]=2;
	World[27][18]=2;
	World[27][20]=2;
	World[27][21]=2;
	World[27][22]=2;
	World[25][22]=2;
	World[24][22]=2;
	World[23][22]=2;

}





#ifdef ANALYSIS

/* DOS only */



/* Moving array to screen.............................................*/

void World_Drawer( void )
{
	int i,j;

	for (i=0; i<World_Horizontal; i++)
	{
		for (j=0; j<World_Vertical; j++)
		{
			if (World[i][j]==1)
			{
				int m,n,p,q;

				m=14*i+100;
				n=14*j+20;

				for (p=n; p<=n+13;p+=2)
				{
					for (q=m; q<=m+13; q+=2)
					{
						putpixel(q,p,Wall_Colour);
					}
				}

			}
			if (World[i][j]==2)
			{
				int m,n,p,q;

				m=14*i+100;
				n=14*j+20;

				for (p=n; p<=n+13;p+=2)
				{
					for (q=m; q<=m+13; q+=2)
					{
						putpixel(q,p,Space_Colour);
					}
				}

			}
		}
	}
}

#endif

/* trail.c */