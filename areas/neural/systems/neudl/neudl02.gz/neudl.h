//----------------------------------------------------------------------
// Program: neudl.h  -  Neural-Network Description Language Header
//
// Author : Joey Rogers
// Date   : July 30, 1993
//
// Purpose: This is the header file for the NeuDL parser.  The maximum
//          network parameters are here as well as the default training
//          parameters.
//----------------------------------------------------------------------

#ifndef NEUDL
#define NEUDL

#define MAX_MIDDLE_LAYERS 10
#define MAX_DATA_LISTS 10

#define DEFAULT_LEARNING_RATE 0.45
#define DEFAULT_MOMENTUM 0.90
#define DEFAULT_CHECK_TEST_SET 1
#define DEFAULT_MIN_ITERATIONS 100
#define DEFAULT_MAX_ITERATIONS 1000
#define DEFAULT_DISPLAY_RATE 1
#define DEFAULT_TOLERANCE 0.25

#define EXECUTE 0
#define DEBUG 1
#define TRANSLATE 2

#endif






