// program.h

#define MAX_VARIABLES 50

#include<stdio.h>
#include<iostream.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#include"nndl.h"
#include"state.h"
#include"double_express.h"
#include"instruct.h"

//---------------------------------------------------------------------------
class Program
	{
	public:
		void Dump( State &s );
		void Execute( State &s, Instruction *inst );
		
	private:
		void Error( char s1[], char s2[]=NULL );
	};




