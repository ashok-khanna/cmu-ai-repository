/*******************************************************************************

Program: bpmem.h  -  Memory Allocation function for backprop.c
Author : Joey Rogers
Date   : April 10, 1993

********************************************************************************
   Memory Allocation -

      The following sections contain the necessary functions to
allocate memory for the network.  These functions are implemented to
help manage memory allocation in a more controlled method.  These
functions are the only way memory is allocated in this program.

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
 Create Layers -

	This section contains a function to allocate the LAYER nodes.  The
function is supplied the number of layers to create and returns a
pointer to an array of LAYER nodes.

	LAYER nodes contain an integer count of how many nodes the
layer contains and a pointer to an array of network NODEs.                    */

LAYER *Create_Layers( int number )
	{
	LAYER *temp;
	int i;

	temp=(LAYER *)malloc(sizeof(LAYER)*number);
	if (temp==NULL)
		{
		fprintf(stderr,"Cannot Allocate Layers.\n");
		exit(-1);
		}

	for (i=0; i<number; i++)
	    {
	    temp[i].node=NULL;
	    temp[i].node_count=0;
	    }

	return(temp);
	}

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
   Create Node -

	This section contains a function to allocate a network NODE.  Each
layer has a given number of nodes, and they are allocated by calling
this function with the number of nodes desired in the layer.  The
function returns a pointer to an array of network NODEs.

Network |NODE|s include storage for the node's value, the node's error,
the head of the linked list of |WEIGHT| nodes the network |NODE| is
associated with, and a working value used in the computation of
middle layer errors.							      */

NODE *Create_Nodes( int number )
	{
	NODE *temp;
	int i;

	temp=(NODE *)malloc(sizeof(NODE)*number);
	if (temp==NULL)
		{
		fprintf(stderr,"Cannot Allocate Network Nodes.\n");
		exit(-1);
		}

	for (i=0; i<number; i++)
	    {
	    temp[i].id=node_counter;

	    node_counter++;
	    temp[i].value=0;
	    temp[i].error=0;
	    temp[i].work=0;
	    temp[i].bias=0;
	    temp[i].first_weight=NULL;
	    }
	return(temp);
	}
/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
   Create Weight -

	This section contains a function to allocate a WEIGHT node.  Since
this implementation is designed to accomodate the future use of user
defined weight connections, network weights are stored as linked-lists
of WEIGHT nodes.

	Each WEIGHT node contains two identifier values, layer and
node, so that the node the weight is connected to can be easily
identified.  The WEIGHT node also includes a pointer to the specific
network NODE it is connected to, a value, a previous delta value
(used by the momentum term computation), and a pointer to the next
WEIGHT node.								      */

WEIGHT *Create_Weight( void )
	{
	WEIGHT *temp;

	temp=(WEIGHT *)malloc(sizeof(WEIGHT));
	if (temp==NULL)
		{
		fprintf(stderr,"Cannot Allocate Weight Node.\n");
		exit(-1);
		}

	temp->layer=-999;
	temp->node=-999;
	temp->input_node=NULL;
	temp->next=NULL;
	temp->value=Random();
	temp->prev_delta=0;
	return(temp);
	}
/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
   Create Data -

	This section contains a function to allocate a training/test set
DATA node.  The DATA nodes are also stored as linked-lists to
facilitate certain features, such as unlimited training set size and
efficient DATA node order rotation.

	Each DATA node contains an identification value (provided by the user
in the input file), a pointer to an array of input values, a pointer
to an array of desired output values, and a pointer to the next DATA
item.

	These DATA nodes are used for both the training and the testing sets
because the structure of each is identical.  A separate head pointer
is simply maintained to each set.					      */


DATA *Create_Data( void )
     {
     DATA *temp;

     temp=(DATA *)malloc(sizeof(DATA));
     if (temp==NULL)
	{
	fprintf(stderr,"Cannot allocate Data Node.\n");
	exit(-1);
	}

     temp->id=0;
     temp->in=NULL;
     temp->out=NULL;
     temp->next=NULL;

     return(temp);
     }

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    Create Array -

	This section contains a function to allocate an array of doubles of
a user specified size.  This function is used to create the input and
output vectors stored in the DATA nodes.				      */

double *Create_Array( int size, double init_value )
	{
	double *temp;
	int i;

	temp=(double *)malloc(sizeof(double)*size);
	if (temp==NULL)
	   {
	   fprintf(stderr,"Cannot allocate a double array.\n");
	   exit(-1);
	   }

	for (i=0; i<size; i++)      /* Initialize Array */
	    temp[i]=init_value;

	return(temp);
	}
