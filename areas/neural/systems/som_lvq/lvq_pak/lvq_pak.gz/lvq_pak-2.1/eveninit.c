/************************************************************************
 *                                                                      *
 *  Program package 'lvq_pak':                                          *
 *                                                                      *
 *  eveninit.c                                                          *
 *  -initializes the codebook vectors evenly to all classes             *
 *                                                                      *
 *  Version 2.1                                                         *
 *  Date: 9 Oct 1992                                                    *
 *                                                                      *
 *  NOTE: This program package is copyrighted in the sense that it      *
 *  may be used for scientific purposes. The package as a whole, or     *
 *  parts thereof, cannot be included or used in any commercial         *
 *  application without written permission granted by its producents.   *
 *  No programs contained in this package may be copied for commercial  *
 *  distribution.                                                       *
 *                                                                      *
 *  All comments  concerning this program package may be sent to the    *
 *  e-mail address 'lvq@cochlea.hut.fi'.                                *
 *                                                                      *
 ************************************************************************/

#include <stdio.h>
#include "lvq_pak.h"

struct entries *eveninit_codes(int number_of_codes, struct entries *data,
                               int knn)
{
  int nol, i;
  int nic;
  int emp, nom;
  struct entries *entr;
  struct entries *entr2;
  struct entries *temp;
  int *noe;
  float frac, err;

  nol = number_of_labels();
  if (nol > number_of_codes) {
    errormsg("There are more different classes than requested codes");
  }

  /* how many entries for each class */
  nic = number_of_codes / nol;

  if (verbose(-1) > 1)
    fprintf(stdout, "The codebook vectors for each class are picked\n");

  /* pick even number of codebook vectors for each class */
  noe = (int *) oalloc(sizeof(int) * nol);
  for (i = 0; i < nol; i++) {
    noe[i] = nic;
  }
  entr = pick_inside_codes(noe, data, nol, knn);

  /* check if all required codebook vectors were found */
  emp = 0;
  for (i = 0; i < nol; i++) {
    if (noe[i] == 0)
      emp++;
  }
  if (verbose(-1) > 1)
    fprintf(stdout, "For %d classes all found\n", emp);
  temp = entr;
  nom = 0;
  while (temp != NULL) {
    nom++;
    temp = temp->next;
  }
  if (verbose(-1) > 1)
    fprintf(stdout, "Found %d vectors in first pass\n", nom);

  if (nom < number_of_codes) {
    frac = 0.0;
    err = 0.0;
    if (emp != 0)
      frac = (number_of_codes - nom) / (float) emp;
    for (i = 0; i < nol; i++) {
      if (noe[i] == 0) {
        noe[i] = (int) (frac + err);
        err = frac + err - noe[i];
      }
      else {
        noe[i] = 0;
      }
    }

    /* pick more codes from those classes where you got all */
    entr2 = pick_inside_codes(noe, data, nol, knn);

    temp = entr;
    if (temp != NULL) {
      while (temp->next != NULL) {
        temp = temp->next;
      }
      temp->next = entr2;
    }
    else {
      entr = entr2;
    }
  }

  return(entr);
}

main(int argc, char **argv)
{
  int number_of_codes;
  int knn;
  int randomize;
  char *in_data_file;
  char *out_code_file;
  struct entries *data, *codes;

  in_data_file = extract_parameter(argc, argv, IN_DATA_FILE, ALWAYS);
  out_code_file = extract_parameter(argc, argv, OUT_CODE_FILE, ALWAYS);
  verbose((int) oatoi(extract_parameter(argc, argv, VERBOSE, OPTION), 1));
  number_of_codes = (int) oatoi(extract_parameter(argc, argv,
				NUMBER_OF_CODES, ALWAYS), 1);
  knn = (int) oatoi(extract_parameter(argc, argv, KNN_NEIGHBORS, OPTION), 5);
  randomize = (int) oatoi(extract_parameter(argc, argv, RANDOM, OPTION), 0);

  if (verbose(-1) > 1)
    fprintf(stdout, "Input entries are read from file %s\n", in_data_file);
  data = read_entries(in_data_file);

  init_random(randomize);

  codes = eveninit_codes(number_of_codes, data, knn);

  if (verbose(-1) > 1)
    fprintf(stdout, "Codebook entries are saved to file %s\n", out_code_file);
  save_entries(codes, out_code_file);
  invalidate_alphafile(out_code_file);

  return(0);
}
