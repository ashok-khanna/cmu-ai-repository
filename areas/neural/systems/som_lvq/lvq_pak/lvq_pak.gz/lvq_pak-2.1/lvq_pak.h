/************************************************************************
 *                                                                      *
 *  Program packages 'lvq_pak' and 'som_pak' :                          *
 *                                                                      *
 *  lvq_pak.h                                                           *
 *  -definitions needed in programs                                     *
 *                                                                      *
 *  Version 2.1                                                         *
 *  Date: 9 Oct 1992                                                    *
 *                                                                      *
 *  NOTE: This program package is copyrighted in the sense that it      *
 *  may be used for scientific purposes. The package as a whole, or     *
 *  parts thereof, cannot be included or used in any commercial         *
 *  application without written permission granted by its producents.   *
 *  No programs contained in this package may be copied for commercial  *
 *  distribution.                                                       *
 *                                                                      *
 *  All comments  concerning this program package may be sent to the    *
 *  e-mail address 'lvq@cochlea.hut.fi'.                                *
 *                                                                      *
 ************************************************************************/

#define ALWAYS 1
#define OPTION 0

#define IN_DATA_FILE            "-din"
#define OUT_DATA_FILE           "-dout"
#define IN_CODE_FILE            "-cin"
#define OUT_CODE_FILE           "-cout"
#define NUMBER_OF_CODES         "-noc"
#define RUNNING_LENGTH          "-rlen"
#define TRAINING_ALPHA          "-alpha"
#define TRAINING_EPSILON        "-epsilon"
#define TRAINING_RADIUS         "-radius"
#define WINDOW_WIDTH            "-win"
#define KNN_NEIGHBORS           "-knn"
#define LABEL                   "-label"
#define OUT_CLASSIFICATION_FILE "-cfout"
#define VERBOSE                 "-v"
#define RANDOM                  "-rand"
#define SILENT                  "-silent"
#define XDIM                    "-xdim"
#define YDIM                    "-ydim"
#define TOPOLOGY                "-topol"
#define NEIGHBORHOOD            "-neigh"
#define PLANE                   "-plane"
#define FIXPOINTS      	        "-fixed"
#define WEIGHTS                 "-weights"


struct fixpoint {
    int xfix;
    int yfix;
  };

/* every entry (either input data or code vector) is stored
   in linked lists consisting of following objects          */
struct entries {
           /* dimension of the entry */
    int    dimension;
           /* actual values of the entry */
    float  *points;
           /* index to label data base */
    int    index;
           /* pointer to next entry in list */
    struct entries *next;
           /* unique identifier for this entry */
    int    ident;

    int    topol;
    int    neigh;
    int    xdim;
    int    ydim;
    int    weight;
    struct fixpoint *fixed;
  };


/* useful general routines */
void errormsg(char *msg);
void debugmsg(char *msg);
void *oalloc(unsigned int len);
void ofree(void *ptr);
struct entries *ecopy(struct entries *data);
void efree(struct entries *data);

void mprint(long rlen);
int verbose(int level);

void osrand(int i);
int orand();
void init_random(int i);

int find_conv_to_ind(char *str);
char *find_conv_to_lab(int ind);
int number_of_labels();
void free_labels();
char *nolab();

int oatoi(char *str, int def);
float oatof(char *str, float def);
char *extract_parameter(int argc, char **argv, char *param, int when);

struct entries *read_entries(char *in_data_file);
void save_entries(struct entries *codes, char *out_code_file);

int alpha_read(float *alphas, int noc, char *infile);
void alpha_write(float *alphas, int noc, char *outfile);
void invalidate_alphafile(char *outfile);

struct entries *new_entry_order(struct entries *data);


struct entries *extract_codes(int ind, struct entries *data);
struct entries *pick_codes(int num, struct entries *data);
struct entries *pick_known_codes(int num, struct entries *data, int index);
struct entries *pick_inside_codes(int *num, struct entries *data, int nol,
                                  int knn);
struct entries *force_pick_code(struct entries *data, int ind);
struct entries *kmeans_training(struct entries *data,
			struct entries *codes, int length);
struct entries *kmeans_known_training(struct entries *data,
			struct entries *codes, int length);
float *min_distances(struct entries *codes);
float *med_distances(struct entries *codes);
float *deviations(struct entries *codes);

struct entries *olvq1_training(struct entries *data, struct entries *codes,
			long rlen, float alpha, char *in, char *out);
struct entries *lvq1_training(struct entries *data, struct entries *codes,
			long rlen, float alpha);
struct entries *lvq2_training(struct entries *data, struct entries *codes,
			long rlen, float alpha, float winlen);
struct entries *lvq3_training(struct entries *data, struct entries *codes,
			long rlen, float alpha, float epsilon, float winlen);

struct entries *som_training(struct entries *data, struct entries *codes,
			long rlen, float alpha, float radius);

extern struct entries *randinit_codes(int number_of_codes, struct entries *data,
              int topol, int neigh, int xdim, int ydim);
extern struct entries *lininit_codes(int number_of_codes, struct entries *data,
              int topol, int neigh, int xdim, int ydim);
float find_qerror(struct entries *data, struct entries *codes);

