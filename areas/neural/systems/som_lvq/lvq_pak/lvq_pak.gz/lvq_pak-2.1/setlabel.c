/************************************************************************
 *                                                                      *
 *  Program package 'lvq_pak':                                          *
 *                                                                      *
 *  setlabel.c                                                          *
 *  -sets the labels of entries by the majority voting                  *
 *                                                                      *
 *  Version 2.1                                                         *
 *  Date: 9 Oct 1992                                                    *
 *                                                                      *
 *  NOTE: This program package is copyrighted in the sense that it      *
 *  may be used for scientific purposes. The package as a whole, or     *
 *  parts thereof, cannot be included or used in any commercial         *
 *  application without written permission granted by its producents.   *
 *  No programs contained in this package may be copied for commercial  *
 *  distribution.                                                       *
 *                                                                      *
 *  All comments  concerning this program package may be sent to the    *
 *  e-mail address 'lvq@cochlea.hut.fi'.                                *
 *                                                                      *
 ************************************************************************/

#include <stdio.h>
#include <float.h>
#include "lvq_pak.h"

struct entries *find_labels(struct entries *data, struct entries *codes,
                            int knn)
{
  int *res;
  int nol, noc, i, j;
  int *index;
  float diff, difference, *diffsf;
  struct entries *codetmp;
  struct entries *datatmp;

  /* Number of different classes */
  nol = number_of_labels();

  /* Number of codebook vectors */
  noc = 0;
  codetmp = codes;
  while (codetmp != NULL) {
    noc++;
    codetmp = codetmp->next;
  }

  res = (int *) oalloc(sizeof(int)*nol);
  if (knn < 1) knn = 1;
  index = (int *) oalloc(sizeof(int)*knn);
  diffsf = (float *) oalloc(sizeof(float)*knn);

  /* Initialize all tables */
  for (i = 0; i < nol; i++) {
    res[i] = 0;
  }

  /* Scan all codebook entries */
  codetmp = codes;
  while (codetmp != NULL) {

    datatmp = data;
    for (i = 0; i < knn; i++)
      diffsf[i] = FLT_MAX;

    /* Compare all data entries against the codebook entry */
    while (datatmp != NULL) {

      difference = 0.0;

      /* Compute the distance between codebook and input entry */
      for (i = 0; i < data->dimension; i++) {
	diff = codetmp->points[i] - datatmp->points[i];
	difference += diff * diff;
        if (difference > diffsf[knn-1]) break;
      }

      /* If distance is smaller than previous distances */
      i = 0;
      while ((i < knn) && (difference > diffsf[i]))
	i++;
      if (i < knn) {
	j = knn-1;
	while (j > i) {
	  diffsf[j] = diffsf[j-1];
	  index[j] = index[j-1];
	  j--;
	}
	diffsf[i] = difference;
	index[i] = datatmp->index;
      }

      /* Take the next code entry */
      datatmp = datatmp->next;
    }

    /* Find the majority of votes */
    for (i = 0; i < nol; i++) {
      res[i] = 0;
    }
    for (i = 0; i < knn; i++) {
      res[index[i]]++;
    }
    j = 0;
    for (i = 1; i < nol; i++) {
      if (res[i] > res[j])
	j = i;
    }
    codetmp->index = j;

    /* Take the next code entry */
    codetmp = codetmp->next;

    if (verbose(-1) > 0)
      mprint((long) noc--);
  }
  if (verbose(-1) > 0)
    mprint((long) 0);
  if (verbose(-1) > 0)
    fprintf(stdout, "\n");

  return(codes);
}

main(int argc, char **argv)
{
  int knn;
  char *in_data_file;
  char *in_code_file;
  char *out_code_file;
  struct entries *data, *codes;

  in_data_file = extract_parameter(argc, argv, IN_DATA_FILE, ALWAYS);
  in_code_file = extract_parameter(argc, argv, IN_CODE_FILE, ALWAYS);
  out_code_file = extract_parameter(argc, argv, OUT_CODE_FILE, ALWAYS);
  verbose((int) oatoi(extract_parameter(argc, argv, VERBOSE, OPTION), 1));
  knn = (int) oatoi(extract_parameter(argc, argv, KNN_NEIGHBORS, OPTION), 5);

  if (verbose(-1) > 1)
    fprintf(stdout, "Input entries are read from file %s\n", in_data_file);
  data = read_entries(in_data_file);
  if (verbose(-1) > 1)
    fprintf(stdout, "Codebook entries are read from file %s\n", in_code_file);
  codes = read_entries(in_code_file);

  if (data->dimension != codes->dimension) {
    errormsg("Data and codebook vectors have different dimensions");
    exit(0);
  }

  codes = find_labels(data, codes, knn);

  if (verbose(-1) > 1)
    fprintf(stdout, "Codebook entries are saved to file %s\n", out_code_file);
  save_entries(codes, out_code_file);

  return(0);
}
