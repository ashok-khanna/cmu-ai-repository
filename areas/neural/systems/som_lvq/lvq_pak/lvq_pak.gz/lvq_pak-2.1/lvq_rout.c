/************************************************************************
 *                                                                      *
 *  Program package 'lvq_pak':                                          *
 *                                                                      *
 *  lvq_rout.c                                                          *
 *  -routines needed in some programs                                   *
 *    -training routines                                                *
 *    -classification routines                                          *
 *    -etc.                                                             *
 *                                                                      *
 *  Version 2.1                                                         *
 *  Date: 9 Oct 1992                                                    *
 *                                                                      *
 *  NOTE: This program package is copyrighted in the sense that it      *
 *  may be used for scientific purposes. The package as a whole, or     *
 *  parts thereof, cannot be included or used in any commercial         *
 *  application without written permission granted by its producents.   *
 *  No programs contained in this package may be copied for commercial  *
 *  distribution.                                                       *
 *                                                                      *
 *  All comments  concerning this program package may be sent to the    *
 *  e-mail address 'lvq@cochlea.hut.fi'.                                *
 *                                                                      *
 ************************************************************************/

#include <stdio.h>
#include <float.h>
#include <math.h>
#include <stdlib.h>
#include "lvq_pak.h"


/* Check whether the vector 'code' (codebook vector) is correctly
   classified by knn-classification with respect to the codebook 'data'.
   Return 1 if correct, 0 if incorrect
*/
int correct_by_knn(struct entries *data, struct entries *code, int knn)
{
  int corr = 0;
  int *res;
  int *tot;
  int nol, i, j;
  int *index;
  int *hits;
  float diff, difference, *diffsf;
  struct entries *datatmp;

  /* Number of different labels in usage */
  nol = number_of_labels();

  hits = (int *) oalloc(sizeof(int)*nol);
  res = (int *) oalloc(sizeof(int)*nol);
  tot = (int *) oalloc(sizeof(int)*nol);
  if (knn < 1) knn = 1;
  index = (int *) oalloc(sizeof(int)*knn);
  diffsf = (float *) oalloc(sizeof(float)*knn);

  /* Initialize all tables */
  for (i = 0; i < nol; i++) {
    res[i] = 0;
    tot[i] = 0;
  }

  for (i = 0; i < knn; i++)
    diffsf[i] = FLT_MAX;

  datatmp = data;
  while (datatmp != NULL) {

    difference = 0.0;

    /* Compute distance between codebook vector and input entry */
    for (i = 0; i < datatmp->dimension; i++) {
      diff = code->points[i] - datatmp->points[i];
      difference += diff * diff;
      if (difference > diffsf[knn-1]) break;
    }

    /* If distance is smaller than the previous distances */
    i = 0;
    while ((i < knn) && (difference > diffsf[i]))
      i++;
    if (i < knn) {
      j = knn-1;
      while (j > i) {
        diffsf[j] = diffsf[j-1];
        index[j] = index[j-1];
        j--;
      }
      diffsf[i] = difference;
      index[i] = datatmp->index;
    }

    /* Take next data entry */
    datatmp = datatmp->next;
  }

  /* If classification was correct */
  for (i = 0; i < nol; i++) {
    hits[i] = 0;
  }
  for (i = 0; i < knn; i++) {
    hits[index[i]]++;
  }
  j = 0;
  for (i = 0; i < nol; i++) {
    if (i != code->index)
      if (j < hits[i])
        j = hits[i];
  }
  if (hits[code->index] > j) {
    corr = 1;
  }

  return(corr);
}

/* Extract those vectors (entries) that belong to same class
   as given index
*/
struct entries *extract_codes(int ind, struct entries *data)
{
  struct entries tmp;
  struct entries *loca;
  struct entries *datac;
  struct entries *prev;

  /* Those entries are saved that have the same index as given */

  loca = data;
  prev = &tmp;
  tmp.next = NULL;
  while (loca != NULL) {
    if (loca->index == ind) {
      prev->next = ecopy(loca);
      prev = prev->next;
    }
    loca = loca->next;
  }

  datac = tmp.next;

  return(datac);
}

/* Pick a given number of entries from the beginning of the entry list
*/
struct entries *pick_codes(int num, struct entries *data)
{
  struct entries tmp;
  struct entries *loca;
  struct entries *datac;
  struct entries *prev;

  /* Pick (at most) 'num' entries from beginning */

  loca = data;
  prev = &tmp;
  tmp.next = NULL;
  while ((loca != NULL) && (num--)) {
    prev->next = ecopy(loca);
    prev = prev->next;
    loca = loca->next;
  }

  datac = tmp.next;

  return(datac);
}

/* Pick a given number of entries of given class from entry list
*/
struct entries *pick_known_codes(int num, struct entries *data, int index)
{
  struct entries tmp;
  struct entries *loca;
  struct entries *datac;
  struct entries *prev;

  /* Pick (at most) 'num' entries from the beginning of the class 'index' */

  loca = data;
  prev = &tmp;
  tmp.next = NULL;
  while ((loca != NULL) && (num)) {
    if (loca->index == index) {
      prev->next = ecopy(loca);
      prev = prev->next;
      num--;
    }
    loca = loca->next;
  }

  datac = tmp.next;

  return(datac);
}

/* Pick a given number of entries of each class from entry list.
   The numbers of entries are given in an array.
   The selected entries should fall inside class borders
*/
struct entries *pick_inside_codes(int *topick, struct entries *data,
                                  int nol, int knn)
{
  struct entries tmp;
  struct entries *loca;
  struct entries *datac;
  struct entries *prev;
  int i, still;
  int total = 0;

  /* Pick (at most) 'topick' entries from the beginning of each class
     so that they are also correctly classified by KNN */

  for (i = 0; i < nol; i++) {
    total += topick[i];
  }

  loca = data;
  prev = &tmp;
  tmp.next = NULL;
  still = 1;
  if (verbose(-1) > 0)
    mprint((long) total);
  while ((still) && (loca != NULL)) {
    if (topick[loca->index]) {
      /* test if it is correctly classified */
      if (correct_by_knn(data, loca, knn)) {
	if (verbose(-1) > 0)
	  mprint((long) total);
	total--;
	prev->next = ecopy(loca);
	prev = prev->next;
	
	topick[loca->index]--;
	if (topick[loca->index] == 0) {
	  still = 0;
	  for (i = 0; i < nol; i++) {
	    if (topick[i] != 0)
	      still = 1;
	  }
	}
      }
    }
    loca = loca->next;
  }

  if (verbose(-1) > 0)
    mprint((long) 0);
  if (verbose(-1) > 0)
    fprintf(stdout, "\n");

  datac = tmp.next;

  return(datac);
}

/* Pick one entry from a given class.
*/
struct entries *force_pick_code(struct entries *data, int ind)
{
  struct entries tmp;
  struct entries *loca;
  struct entries *datac;
  struct entries *prev;
  int still;

  /* pick one entry from a given class */

  still = 1;
  loca = data;
  prev = &tmp;
  tmp.next = NULL;
  while ((still) && (loca != NULL)) {
    if (loca->index == ind) {
      prev->next = ecopy(loca);
      prev = prev->next;
      still = 0;
    }
    loca = loca->next;
  }

  datac = tmp.next;

  return(datac);
}

/* Compute the average shortest distances
*/
float *min_distances(struct entries *codes)
{
  int i, j;
  int nol;
  int note, fou;
  float *dists;
  float dissf, dist, dis;
  struct entries *entr;
  struct entries *ensu;

  nol = number_of_labels();
  dists = (float *) oalloc(sizeof(float) * nol);
  for (i = 0; i < nol; i++) {
    dists[i] = 0.0;
  }

  for (i = 0; i < nol; i++) {
    entr = codes;
    note = 0;
    while (entr != NULL) {
      if (entr->index == i) {
	ensu = entr->next;
	dissf = FLT_MAX;
	fou = 0;
	while (ensu != NULL) {
	  if (ensu->index == i) {
	    dist = 0.0;
	    fou = 1;
	    for (j = 0; j < ensu->dimension; j++) {
	      dis = ensu->points[j] - entr->points[j];
	      dist += dis*dis;
	    }
	    if (dist < dissf) {
	      dissf = dist;
	    }
	  }
	  ensu = ensu->next;
	}
	if (fou) {
	  dists[i] += sqrt(dissf);
	  note++;
	}
      }
      entr = entr->next;
    }
    if (note > 0)
      dists[i] /= note;
  }

  return(dists);
}

/* Comparison routine for the distances (used in qsort)
*/
int compar(const void *a, const void *b)
{
  if (*(float *)a < *(float *)b)
    return(-1);
  if (*(float *)a > *(float *)b)
    return(1);
  return(0);
}

/* Compute the median of shortest distances
*/
float *med_distances(struct entries *codes)
{
  int i, j;
  int nol, not, mnoe;
  int fou;
  float *dists;
  float dissf, dist, dis;
  float *meds;
  struct entries *entr;
  struct entries *ensu;

  nol = number_of_labels();
  dists = (float *) oalloc(sizeof(float) * nol);
  for (i = 0; i < nol; i++) {
    dists[i] = 0.0;
  }

  /* Find the max number of entries in one class */
  mnoe = 0;
  for (i = 0; i < nol; i++) {
    entr = codes;
    not = 0;
    while (entr != NULL) {
      if (entr->index == i)
        not++;
      entr = entr->next;
    }
    if (not > mnoe)
      mnoe = not;
  }
  /* Allocate space for the distances (to find the median) */
  meds = (float *) oalloc(sizeof(float) * mnoe);
  
  for (i = 0; i < nol; i++) {
    not = 0;
    entr = codes;
    while (entr != NULL) {
      if (entr->index == i) {
	ensu = entr->next;
	dissf = FLT_MAX;
	fou = 0;
	while (ensu != NULL) {
	  if (ensu->index == i) {
	    dist = 0.0;
	    fou = 1;
	    for (j = 0; j < ensu->dimension; j++) {
	      dis = ensu->points[j] - entr->points[j];
	      dist += dis*dis;
	    }
	    if (dist < dissf) {
	      dissf = dist;
	    }
	  }
	  ensu = ensu->next;
	}
	if (fou) {
          meds[not] = sqrt(dissf);
	  not++;
	}
      }
      entr = entr->next;
    }
    if (not > 0) {
      /* find the median */
      qsort((void *) meds, not, sizeof(float), compar);
      dists[i] = meds[not/2];
    }
  }

  ofree(meds);

  return(dists);
}

/* Train by lvq1; the nearest codebook vector is modified.
   If classification is correct, move it towards the input entry;
   if classification is incorrect, move it away from the input entry
*/
struct entries *lvq1_training(struct entries *data,
			struct entries *codes, long length, float alpha)
{
  long i;
  int index;
  int numofe, entno;
  float subdis, distance, shortest;
  float total_length;
  float talpha;
  struct entries *datatmp;
  struct entries *codetmp;
  struct entries *best;
  
  total_length = length;

  numofe = 0;
  datatmp = data;
  while (datatmp != NULL) {
    numofe++;
    datatmp = datatmp->next;
  }

  while (length--) {

    /* Pick the next input entry at random from the training set*/
    datatmp = data;
    entno = orand() % numofe;
    i = 0;
    while ((i < entno) && (datatmp != NULL)) {
      i++;
      datatmp = datatmp->next;
    }

    codetmp = codes;
    shortest = FLT_MAX;

    /* Compare the input entry against all codebook entries 
       to find the nearest one                                 */
    while (codetmp != NULL) {

      /* Compute the distance */
      distance = 0.0;
      for (i = 0; i < datatmp->dimension; i++) {
	subdis = datatmp->points[i] - codetmp->points[i];
	distance += subdis * subdis;
        if (distance > shortest) break;
      }

      /* If distance is smaller than previous ones */
      if (distance < shortest) {
	shortest = distance;
	index = codetmp->index;
	best = codetmp;
      }

      /* Consider the next codebook entry */
      codetmp = codetmp->next;
    }

    /* Was the classification correct? */
    talpha = alpha * (float) length / total_length;
    if (index == datatmp->index) {
      
      /* It was orrect classification; move towards */
      for (i = 0; i < datatmp->dimension; i++) {
	best->points[i] += talpha *
	  (datatmp->points[i] - best->points[i]);
      }
    }
    else {
      
      /* It was incorrect classification; move away */
      for (i = 0; i < datatmp->dimension; i++) {
	best->points[i] -= talpha *
	  (datatmp->points[i] - best->points[i]);
      }
    }

    if (verbose(-1) > 0) 
      mprint(length);
  }
  if (verbose(-1) > 0) 
    fprintf(stdout, "\n");

  return(codes);
}

/* Train by olvq1, whereby optimized alpha values are used.
   The nearest code vector is modified;
   If classification is correct, move it towards the input entry,
   if classification is incorrect, move it away from the input entry
*/
struct entries *olvq1_training(struct entries *data,
			struct entries *codes, long length, float alpha,
                        char *infile, char *outfile)
{
  long i;
  int index;
  int numofe, entno;
  int noc, potobe, pointer;
  float subdis, distance, shortest;
  float *talpha;
  struct entries *datatmp;
  struct entries *codetmp;
  struct entries *best;
  
  numofe = 0;
  datatmp = data;
  while (datatmp != NULL) {
    numofe++;
    datatmp = datatmp->next;
  }

  noc = 0;
  codetmp = codes;
  while (codetmp != NULL) {
    noc++;
    codetmp = codetmp->next;
  }

  /* Get the alpha values:                                      */
  /* There are several possibilities: the user may define them; */
  /* if not, then they may be read from file;                   */
  /* if no file exists, then default values are used.           */ 
  talpha = (float *) oalloc(sizeof(float) * noc);
  if (alpha == 0.0) {
    if (!alpha_read(talpha, noc, infile)) {
      alpha = 0.3;
      for (i = 0; i < noc; i++) {
	talpha[i] = alpha;
      }
    }
  }
  else {
    for (i = 0; i < noc; i++) {
      talpha[i] = alpha;
    }
  }

  while (length--) {

    /* Take the next input entry at random from the training set*/
    datatmp = data;
    entno = orand() % numofe;
    i = 0;
    while ((i < entno) && (datatmp != NULL)) {
      i++;
      datatmp = datatmp->next;
    }

    codetmp = codes;
    shortest = FLT_MAX;
    potobe = 0;
    pointer = 0;

    /* Compare the input entry against all codebook entries 
       to find the nearest one                           */
    while (codetmp != NULL) {

      /* Compute the distance */
      distance = 0.0;
      for (i = 0; i < datatmp->dimension; i++) {
	subdis = datatmp->points[i] - codetmp->points[i];
	distance += subdis * subdis;
        if (distance > shortest) break;
      }

      /* If distance is smaller than previous ones */
      if (distance < shortest) {
	shortest = distance;
	index = codetmp->index;
	best = codetmp;
        potobe = pointer;
      }

      /* Consider the next codebook entry */
      codetmp = codetmp->next;
      pointer++;
    }

    /* Individual alphas for every codebook vector; */
    /* Was the classification correct?              */
    if (index == datatmp->index) {
      
      /* If classification was correct, move towards */
      for (i = 0; i < datatmp->dimension; i++) {
	best->points[i] += talpha[potobe] *
	  (datatmp->points[i] - best->points[i]);
      }
      talpha[potobe] = talpha[potobe] / (1 + talpha[potobe]);
    }
    else {
      
      /* If classification was incorrect, move away */
      for (i = 0; i < datatmp->dimension; i++) {
	best->points[i] -= talpha[potobe] *
	  (datatmp->points[i] - best->points[i]);
      }
      talpha[potobe] = talpha[potobe] / (1 - talpha[potobe]);
      if (talpha[potobe] > alpha)
	talpha[potobe] = alpha;
    }
    
    if (verbose(-1) > 0)
      mprint(length);
  }
  if (verbose(-1) > 0)
    fprintf(stdout, "\n");

  /* Store the alphas */
  alpha_write(talpha, noc, outfile);

  return(codes);
}

/* Train by lvq2.
   Two nearest codebook vectors are modified under specified conditions */
struct entries *lvq2_training(struct entries *data,
			struct entries *codes, long length, float alpha,
			float winlen)
{
  long i;
  int index;
  int nindex;
  int numofe, entno;
  float subdis, distance;
  float shortest, nshortest;
  float total_length;
  float talpha;
  struct entries *datatmp;
  struct entries *codetmp;
  struct entries *best;
  struct entries *nbest;
  struct entries *ntmp;
  
  total_length = length;

  numofe = 0;
  datatmp = data;
  while (datatmp != NULL) {
    numofe++;
    datatmp = datatmp->next;
  }

  while (length--) {

    /* Take the next input entry at random from the training set*/
    datatmp = data;
    entno = orand() % numofe;
    i = 0;
    while ((i < entno) && (datatmp != NULL)) {
      i++;
      datatmp = datatmp->next;
    }

    /* True alpha is decreasing linearly during the training */
    talpha = alpha * ((float) length / total_length);

    codetmp = codes;
    shortest = FLT_MAX;
    nshortest = FLT_MAX;
    index = 0;
    best = codetmp;

    /* Compare the input entry against all codebook entries 
       to find the two nearest ones  */
    while (codetmp != NULL) {

      /* Compute the distance */
      distance = 0.0;
      for (i = 0; i < datatmp->dimension; i++) {
	subdis = datatmp->points[i] - codetmp->points[i];
	distance += subdis * subdis;
        if (distance > nshortest) break;
      }

      /* Find the two nearest entries */
      if (distance < shortest) {
	nshortest = shortest;
	nindex = index;
	nbest = best;
 	shortest = distance;
	index = codetmp->index;
        best = codetmp;
      }
      else {
        if (distance < nshortest) {
          nshortest = distance;
          nindex = codetmp->index;
          nbest = codetmp;
        }
      }

      /* Consider the next code entry */
      codetmp = codetmp->next;
    }

    /* Corrections are made only if the two nearest codebook vectors
       belong to different classes, one of them correct, and if the
       input entry is located inside a window between the nearest codebook
       vectors           */
    if (index != nindex) {
      if ((index == datatmp->index) || (nindex == datatmp->index)) {

	/* If the ration of distances to the two nearest codebook vectors
           satisfies a condition */
	if ((shortest/nshortest) > ((1-winlen)/(1+winlen))) {
	  /* If the second best is correct swap the entries */
	  if (nindex == datatmp->index) {
	    ntmp = best;
	    best = nbest;
	    nbest = ntmp;
	  }

	  /* Move the entries */
	  for (i = 0; i < datatmp->dimension; i++) {
	    best->points[i] +=
	      talpha * (datatmp->points[i] - best->points[i]);
	    nbest->points[i] -=
	      talpha * (datatmp->points[i] - nbest->points[i]);
	  }
	}
      }
    }

    if (verbose(-1) > 0)
      mprint(length);
  }
  if (verbose(-1) > 0)
    fprintf(stdout, "\n");

  return(codes);
}

/* Train by lvq3.
   Two nearest codebook vectors are modified under specified conditions */
struct entries *lvq3_training(struct entries *data,
			struct entries *codes, long length, float alpha,
			float epsilon, float winlen)
{
  long i;
  int index;
  int nindex;
  int numofe, entno;
  float subdis, distance;
  float shortest, nshortest;
  float total_length;
  float talpha;
  struct entries *datatmp;
  struct entries *codetmp;
  struct entries *best;
  struct entries *nbest;
  struct entries *ntmp;
  
  total_length = length;

  numofe = 0;
  datatmp = data;
  while (datatmp != NULL) {
    numofe++;
    datatmp = datatmp->next;
  }

  while (length--) {

    /* Take the next input entry at random from the training set*/
    datatmp = data;
    entno = orand() % numofe;
    i = 0;
    while ((i < entno) && (datatmp != NULL)) {
      i++;
      datatmp = datatmp->next;
    }

    /* True alpha is decreasing linearly during the training */
    talpha = alpha * ((float) length / total_length);

    codetmp = codes;
    shortest = FLT_MAX;
    nshortest = FLT_MAX;
    index = 0;
    best = codetmp;

    /* Compare the input entry against all codebook entries 
       to find the two nearest ones  */
    while (codetmp != NULL) {

      /* Compute the distance */
      distance = 0.0;
      for (i = 0; i < datatmp->dimension; i++) {
	subdis = datatmp->points[i] - codetmp->points[i];
	distance += subdis * subdis;
        if (distance > nshortest) break;
      }

      /* Find the two nearest entries */
      if (distance < shortest) {
	nshortest = shortest;
	nindex = index;
	nbest = best;
 	shortest = distance;
	index = codetmp->index;
        best = codetmp;
      }
      else {
        if (distance < nshortest) {
          nshortest = distance;
          nindex = codetmp->index;
          nbest = codetmp;
        }
      }

      /* Consider the next code entry */
      codetmp = codetmp->next;
    }

    /* Corrections are made if the two nearest codebook vectors
       belong to different classes, one of them correct, and if the
       input entry is located inside a window between the nearest codebook
       vectors OR the two nearest codebook vectors both belong to the
       correct class */
    if (index != nindex) {
      if ((index == datatmp->index) || (nindex == datatmp->index)) {

	/* If the ration of distances to the two nearest codebook vectors
           satisfies a condition */
	if ((shortest/nshortest) > ((1-winlen)/(1+winlen))) {
	  /* If the second best is correct swap the entries */
	  if (nindex == datatmp->index) {
	    ntmp = best;
	    best = nbest;
	    nbest = ntmp;
	  }

	  /* Move the entries */
	  for (i = 0; i < datatmp->dimension; i++) {
	    best->points[i] +=
	      talpha * (datatmp->points[i] - best->points[i]);
	    nbest->points[i] -=
	      talpha * (datatmp->points[i] - nbest->points[i]);
	  }
	}
      }
    }
    else {
      if (index == datatmp->index) {
	/* Move the entries, both toward */
	for (i = 0; i < datatmp->dimension; i++) {
	  best->points[i] +=
	    epsilon * talpha * (datatmp->points[i] - best->points[i]);
	  nbest->points[i] +=
	    epsilon * talpha * (datatmp->points[i] - nbest->points[i]);
        }
      }
    }

    if (verbose(-1) > 0)
      mprint(length);
  }
  if (verbose(-1) > 0)
    fprintf(stdout, "\n");

  return(codes);
}

float devdist( float *v1, float *v2, int dim)
{
	float diff, d;
	d = 0.0;
	while (dim-- > 0) {
		diff = *v1++ - *v2++;
		d += diff*diff;
	}
	return(d);
}


float *deviations(struct entries *codes)
{
  int i, j;
  int nol, dim;
  int *count;
  float *dists;
  float *avers;
  struct entries *entr;

  nol = number_of_labels();
  dim = codes->dimension;
  count = (int *) oalloc(sizeof(int) * nol);
  dists = (float *) oalloc(sizeof(float) * nol);
  avers = (float *) oalloc(sizeof(float) * nol * dim);
  for (i = 0; i < nol; i++) {
    dists[i] = 0.0;
    for (j = 0; j < dim; j++) {
      avers[i*dim+j] = 0.0;
    }
    count[i] = 0;
  }

  /* Compute averages */
  entr = codes;
  while (entr != NULL) {
    for (j = 0; j < dim; j++) {
      avers[entr->index*dim+j] += entr->points[j];
    }
    count[entr->index]++;
    entr = entr->next;
  }
  for (i = 0; i < nol; i++) {
    for (j = 0; j < dim; j++) {
      avers[i*dim+j] /= count[i];
    }
  }

  /* Compute deviations */
  entr = codes;
  while (entr != NULL) {
    dists[entr->index] += devdist(entr->points,
          &(avers[entr->index*dim]), dim);
    entr = entr->next;
  }
  for (i = 0; i < nol; i++) {
    dists[i] = sqrt(dists[i]/count[i]);
  }

  return(dists);
}



