/************************************************************************
 *                                                                      *
 *  Program package 'lvq_pak':                                          *
 *                                                                      *
 *  elimin.c                                                            *
 *  -eliminates those entries that are incorrectly classified by knn    *
 *                                                                      *
 *  Version 2.1                                                         *
 *  Date: 9 Oct 1992                                                    *
 *                                                                      *
 *  NOTE: This program package is copyrighted in the sense that it      *
 *  may be used for scientific purposes. The package as a whole, or     *
 *  parts thereof, cannot be included or used in any commercial         *
 *  application without written permission granted by its producents.   *
 *  No programs contained in this package may be copied for commercial  *
 *  distribution.                                                       *
 *                                                                      *
 *  All comments  concerning this program package may be sent to the    *
 *  e-mail address 'lvq@cochlea.hut.fi'.                                *
 *                                                                      *
 ************************************************************************/

#include <stdio.h>
#include <float.h>
#include "lvq_pak.h"

#define KNN 10

struct entries *eliminate_codes(int knn, struct entries *data)
{
  int i, j;
  int index[KNN];
  int correct, incorrect;
  int noe;
  float dist, distance, shortest[KNN];
  struct entries *entr;
  struct entries tmp;
  struct entries *loca;
  struct entries *datac;
  char str[100];

  if (knn > KNN) {
    sprintf(str, "Can use only %d neighbors", KNN);
    errormsg(str);
    knn = KNN;
  }
  
  /* Count the number of entries in data set */
  loca = data;
  noe = 0;
  while (loca != NULL) {
    loca = loca->next;
    noe++;
  }

  /* Those entries are removed from datac that are not
     correctly classified using the knn-classification */
  loca = data;
  datac = &tmp;
  while (loca != NULL) {
    entr = data;
    correct = 0; 
    incorrect = 0;
    for (j = 0; j < knn; j++) {
      shortest[j] = FLT_MAX;
    }

    /* Find the K best matching units in data */
    while (entr != NULL) {
      distance = 0.0;
      for (i = 0; i < entr->dimension; i++) {
	dist = entr->points[i] - loca->points[i];
	distance += dist * dist;
        if (distance > shortest[knn-1]) break;
      }
      j = 0;
      while ((j < knn) && (distance > shortest[j])) 
	j++;
      if (j < knn) {
	for (i = knn-2; i >= j; i--) {
	  shortest[i+1] = shortest[i];
	  index[i+1] = index[i];
	}
	shortest[j] = distance;
	index[j] = entr->index;
      }
      entr = entr->next;
    }

    /* Count the correctly classified items against
       the incorrectly classified ones */
    for (j = 0; j < knn; j++) {
      if (index[j] == loca->index) 
	correct++;
      else
	incorrect++;
    }

    /* The entry is saved only if there are more correct hits
       than there are incorrect ones  (one hit is for sure because
       the sample is compared to itself also)                            */
    if (correct > incorrect) {
      datac->next = ecopy(loca);
      datac = datac->next;
    }

    /* Consider the next entry */
    loca = loca->next;
    mprint((long) --noe);
  }
  fprintf(stdout, "\n");

  datac = tmp.next;

  return(datac);
}

main(int argc, char **argv)
{
  int knn;
  char *in_data_file;
  char *out_code_file;
  struct entries *data, *codes;

  in_data_file = extract_parameter(argc, argv, IN_DATA_FILE, ALWAYS);
  out_code_file = extract_parameter(argc, argv, OUT_CODE_FILE, ALWAYS);
  knn = (int) oatoi(extract_parameter(argc, argv, KNN_NEIGHBORS, OPTION), 5);
  verbose((int) oatoi(extract_parameter(argc, argv, VERBOSE, OPTION), 1));

  if (verbose(-1) > 1)
    fprintf(stdout, "Input entries are read from file %s\n", in_data_file);
  data = read_entries(in_data_file);

  if (verbose(-1) > 1)
    fprintf(stdout, "Extra codes are eliminated\n");
  codes = eliminate_codes(knn, data);

  if (verbose(-1) > 1)
    fprintf(stdout, "Codebook entries are saved to file %s\n", out_code_file);
  save_entries(codes, out_code_file);
  invalidate_alphafile(out_code_file);

  return(0);
}
