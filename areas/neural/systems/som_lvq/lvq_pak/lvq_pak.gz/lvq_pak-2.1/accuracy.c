/************************************************************************
 *                                                                      *
 *  Program package 'lvq_pak':                                          *
 *                                                                      *
 *  accuracy.c                                                          *
 *  -computes the recognition accuracy by the nearest-neighbor rule     *
 *                                                                      *
 *  Version 2.1                                                         *
 *  Date: 9 Oct 1992                                                    *
 *                                                                      *
 *  NOTE: This program package is copyrighted in the sense that it      *
 *  may be used for scientific purposes. The package as a whole, or     *
 *  parts thereof, cannot be included or used in any commercial         *
 *  application without written permission granted by its producents.   *
 *  No programs contained in this package may be copied for commercial  *
 *  distribution.                                                       *
 *                                                                      *
 *  All comments  concerning this program package may be sent to the    *
 *  e-mail address 'lvq@cochlea.hut.fi'.                                *
 *                                                                      *
 ************************************************************************/

#include <stdio.h>
#include <float.h>
#include "lvq_pak.h"

void compute_accuracy(struct entries *data, struct entries *codes, FILE *ocf)
{
  int *res;
  int *tot;
  int nol, i, noc;
  int index;
  int total, stotal;
  float diff, difference, diffsf;
  struct entries *codetmp;

  /* Number of different classes */
  nol = number_of_labels();

  /* Number of data vectors */
  noc = 0;
  codetmp = data;
  while (codetmp != NULL) {
    noc++;
    codetmp = codetmp->next;
  }

  res = (int *) oalloc(sizeof(int)*nol);
  tot = (int *) oalloc(sizeof(int)*nol);

  /* Initialize all tables */
  for (i = 0; i < nol; i++) {
    res[i] = 0;
    tot[i] = 0;
  }
  stotal = 0;
  total = 0;

  /* Scan all input entries */
  while (data != NULL) {

    codetmp = codes;
    diffsf = FLT_MAX;

    /* Compare all codebook entries against the input entry */
    while (codetmp != NULL) {

      difference = 0.0;

      /* Compute the distance between the input and codebook entries */
      for (i = 0; i < data->dimension; i++) {
	diff = data->points[i] - codetmp->points[i];
	difference += diff * diff;
        if (difference > diffsf) break;
      }

      /* If distance is smaller than the previous distances */
      if (difference < diffsf) {
	diffsf = difference;
	index = codetmp->index;
      }

      /* Take the next codebook entry */
      codetmp = codetmp->next;
    }

    /* If classification was correct */
    if (index == data->index) {
      /* Number of correct classifications */
      stotal++;

      /* Number of correct classifications in that class */
      res[data->index]++;

      /* Write '1' to classification description file */
      if (ocf != NULL) fprintf(ocf,"1\n");

    } else {
      /* Write '0' to classification description file */
      if (ocf != NULL) fprintf(ocf,"0\n");
    }
     
    /* Total number of entries in that class */
    tot[data->index]++;

    /* Total number of entries */
    total++;

    /* Take the next input entry */
    data = data->next;

    if (verbose(-1) > 0)
      mprint((long) noc--);
  }
  if (verbose(-1) > 0)
    mprint((long) 0);
  if (verbose(-1) > 0)
    fprintf(stdout, "\n");

  fprintf(stdout, "\nRecognition accuracy:\n\n");
  for (i = 0; i < nol; i++) {
    if (tot[i] > 0) {
      fprintf(stdout, "%9s: %4d entries ", find_conv_to_lab(i), tot[i]);
      fprintf(stdout, "%6.2f %%\n", 100.0 * (float) res[i] / tot[i]);
    }
  }
  fprintf(stdout, "\nTotal accuracy: %5d entries %6.2f %%\n\n", total,
          100.0 * (float) stotal / total);
}

main(int argc, char **argv)
{
  char *in_data_file;
  char *in_code_file;
  char *out_classification_file;
  struct entries *data, *codes;
  FILE *ocf=NULL;

  in_data_file = extract_parameter(argc, argv, IN_DATA_FILE, ALWAYS);
  in_code_file = extract_parameter(argc, argv, IN_CODE_FILE, ALWAYS);
  out_classification_file = 
	extract_parameter(argc, argv, OUT_CLASSIFICATION_FILE, OPTION);
  verbose((int) oatoi(extract_parameter(argc, argv, VERBOSE, OPTION), 1));

  if (verbose(-1) > 1)
    fprintf(stdout, "Input entries are read from file %s\n", in_data_file);
  data = read_entries(in_data_file);
  if (verbose(-1) > 1)
    fprintf(stdout, "Codebook entries are read from file %s\n", in_code_file);
  codes = read_entries(in_code_file);

  if (data->dimension != codes->dimension) {
    errormsg("Data and codebook vectors have different dimensions");
    exit(0);
  }

  if (out_classification_file != (char *) NULL) {
    if (verbose(-1) > 1)
      fprintf(stdout, "Classifications are saved to file %s\n",
              out_classification_file);

    if ( (ocf = fopen(out_classification_file,"w")) == NULL) {
      fprintf(stdout, "\nCannot write to %s\n",out_classification_file);
      exit(-1);
    }
  }
  
  compute_accuracy(data, codes, ocf);
  if (ocf!=NULL)
    fclose(ocf);

  return(0);
}
