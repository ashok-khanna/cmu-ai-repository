/************************************************************************
 *                                                                      *
 *  Program package 'lvq_pak':                                          *
 *                                                                      *
 *  classify.c                                                          *
 *  -finds out the classifications against a given codebook             *
 *                                                                      *
 *  Version 2.1                                                         *
 *  Date: 9 Oct 1992                                                    *
 *                                                                      *
 *  NOTE: This program package is copyrighted in the sense that it      *
 *  may be used for scientific purposes. The package as a whole, or     *
 *  parts thereof, cannot be included or used in any commercial         *
 *  application without written permission granted by its producents.   *
 *  No programs contained in this package may be copied for commercial  *
 *  distribution.                                                       *
 *                                                                      *
 *  All comments  concerning this program package may be sent to the    *
 *  e-mail address 'lvq@cochlea.hut.fi'.                                *
 *                                                                      *
 ************************************************************************/

#include <stdio.h>
#include <float.h>
#include "lvq_pak.h"

void compute_classifications(struct entries *data, struct entries *codes,
                             FILE *ocf)
{
  int *res;
  int *tot;
  int i, noc;
  int index;
  float diff, difference, diffsf;
  struct entries *codetmp;
  struct entries *datatmp;

  /* Number of data vectors */
  noc = 0;
  codetmp = data;
  while (codetmp != NULL) {
    noc++;
    codetmp = codetmp->next;
  }

  datatmp = data;
  /* Scan all input entries */
  while (datatmp != NULL) {

    codetmp = codes;
    diffsf = FLT_MAX;

    /* Compare all codebook entries against the input entry */
    while (codetmp != NULL) {

      difference = 0.0;

      /* Compute the distance between the input and codebook entries */
      for (i = 0; i < datatmp->dimension; i++) {
	diff = datatmp->points[i] - codetmp->points[i];
	difference += diff * diff;
        if (difference > diffsf) break;
      }

      /* If distance is smaller than the previous distances */
      if (difference < diffsf) {
	diffsf = difference;
	index = codetmp->index;
      }

      /* Take the next codebook entry */
      codetmp = codetmp->next;
    }

    /* Save the classification */
    datatmp->index = index;

    /* Save to file if required */
    if (ocf != NULL) {
      fprintf(ocf, "%s\n", find_conv_to_lab(index));
    }

    /* Take the next input entry */
    datatmp = datatmp->next;

    if (verbose(-1) > 0)
      mprint((long) noc--);
  }
  if (verbose(-1) > 0)
    mprint((long) 0);
  if (verbose(-1) > 0)
    fprintf(stdout, "\n");
}

main(int argc, char **argv)
{
  char *in_data_file;
  char *out_data_file;
  char *out_classification_file;
  char *in_code_file;
  struct entries *data, *codes;
  FILE *ocf=NULL;

  in_data_file = extract_parameter(argc, argv, IN_DATA_FILE, ALWAYS);
  in_code_file = extract_parameter(argc, argv, IN_CODE_FILE, ALWAYS);
  out_classification_file = 
	extract_parameter(argc, argv, OUT_CLASSIFICATION_FILE, OPTION);
  out_data_file = extract_parameter(argc, argv, OUT_DATA_FILE, ALWAYS);
  verbose((int) oatoi(extract_parameter(argc, argv, VERBOSE, OPTION), 1));

  label_not_needed(1);
  if (verbose(-1) > 1)
    fprintf(stdout, "Input entries are read from file %s\n", in_data_file);
  data = read_entries(in_data_file);
  label_not_needed(0);

  if (verbose(-1) > 1)
    fprintf(stdout, "Codebook entries are read from file %s\n", in_code_file);
  codes = read_entries(in_code_file);

  if (data->dimension != codes->dimension) {
    errormsg("Data and codebook vectors have different dimensions");
    exit(0);
  }

  if (out_classification_file != (char *) NULL) {
    if (verbose(-1) > 1)
      fprintf(stdout, "Classifications are saved to file %s\n",
              out_classification_file);

    if ( (ocf = fopen(out_classification_file,"w")) == NULL) {
      fprintf(stdout, "\nCannot write to %s\n",out_classification_file);
      exit(-1);
    }
  }
  
  compute_classifications(data, codes, ocf);
  if (ocf!=NULL)
    fclose(ocf);

  if (verbose(-1) > 1)
    fprintf(stdout, "Output entries are saved to file %s\n", out_data_file);
  save_entries(data, out_data_file);

  return(0);
}
