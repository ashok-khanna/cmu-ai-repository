/************************************************************************
 *                                                                      *
 *  Program package 'lvq_pak':                                          *
 *                                                                      *
 *  pick.c                                                              *
 *  -picks a given number of entries from list                          *
 *                                                                      *
 *  Version 2.1                                                         *
 *  Date: 9 Oct 1992                                                    *
 *                                                                      *
 *  NOTE: This program package is copyrighted in the sense that it      *
 *  may be used for scientific purposes. The package as a whole, or     *
 *  parts thereof, cannot be included or used in any commercial         *
 *  application without written permission granted by its producents.   *
 *  No programs contained in this package may be copied for commercial  *
 *  distribution.                                                       *
 *                                                                      *
 *  All comments  concerning this program package may be sent to the    *
 *  e-mail address 'lvq@cochlea.hut.fi'.                                *
 *                                                                      *
 ************************************************************************/

#include <stdio.h>
#include "lvq_pak.h"

main(int argc, char **argv)
{
  int num;
  char *in_data_file;
  char *out_code_file;
  struct entries *data, *codes;

  in_data_file = extract_parameter(argc, argv, IN_DATA_FILE, ALWAYS);
  out_code_file = extract_parameter(argc, argv, OUT_CODE_FILE, ALWAYS);
  num = (int) oatoi(extract_parameter(argc, argv, NUMBER_OF_CODES, ALWAYS), 1);
  verbose((int) oatoi(extract_parameter(argc, argv, VERBOSE, OPTION), 1));

  if (verbose(-1) > 1)
    fprintf(stdout, "Input entries are read from file %s\n", in_data_file);
  data = read_entries(in_data_file);

  codes = pick_codes(num, data);

  if (verbose(-1) > 1)
    fprintf(stdout, "Codebook entries are saved to file %s\n", out_code_file);
  save_entries(codes, out_code_file);
  invalidate_alphafile(out_code_file);

  return(0);
}
