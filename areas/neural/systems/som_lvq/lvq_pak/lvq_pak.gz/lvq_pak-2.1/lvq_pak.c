/************************************************************************
 *                                                                      *
 *  Program packages 'lvq_pak' and 'som_pak' :                          *
 *                                                                      *
 *  lvq_pak.c                                                           *
 *  -very general routines needed in many places                        *
 *                                                                      *
 *  Version 2.1                                                         *
 *  Date: 9 Oct 1992                                                    *
 *                                                                      *
 *  NOTE: This program package is copyrighted in the sense that it      *
 *  may be used for scientific purposes. The package as a whole, or     *
 *  parts thereof, cannot be included or used in any commercial         *
 *  application without written permission granted by its producents.   *
 *  No programs contained in this package may be copied for commercial  *
 *  distribution.                                                       *
 *                                                                      *
 *  All comments  concerning this program package may be sent to the    *
 *  e-mail address 'lvq@cochlea.hut.fi'.                                *
 *                                                                      *
 ************************************************************************/

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include "lvq_pak.h"

#define STR_LNG 100

  
/******************************************************************* 
 * Routines for general usage                                      * 
 *******************************************************************/

void errormsg(char *msg)
{
  fprintf(stderr, "%s\n", msg);
}

/* My own free routine */
void ofree(void *data)
{
  if (data != (void *) NULL)
    free(data);
}

/* My own allocation routine with some error checking */
void *oalloc(unsigned int len)
{
  void *tmp;

  if ((tmp = (void *) malloc(len)) == NULL) {
    errormsg("Can't allocate memory");
    exit(-1);
  }

  return(tmp);
}

/* Free a list of entries */
void efree(struct entries *data)
{
  struct entries *tmp;

  while (data != NULL) {
    ofree(data->points);
    ofree(data->fixed);
    tmp = data->next;
    ofree(data);
    data = tmp;
  }
}

/* Copy one entry (next==NULL) */
struct entries *ecopy(struct entries *data)
{
  int i;
  struct entries *tmp;

  tmp = (struct entries *) oalloc(sizeof(struct entries));
  tmp->points = (float *) oalloc(sizeof(float)*data->dimension);
  for (i = 0; i < data->dimension; i++) {
    tmp->points[i] = data->points[i];
  }
  tmp->index = data->index;
  tmp->ident = data->ident;
  tmp->dimension = data->dimension;
  tmp->topol = data->topol;
  tmp->neigh = data->neigh;
  tmp->xdim = data->xdim;
  tmp->ydim = data->ydim;
  tmp->weight = data->weight;
  tmp->fixed = data->fixed;
  tmp->next = NULL;

  return(tmp);
}


/* Print dots indicating that a job is in progress */
void mprint(long rlen)
{
#ifndef time_t
#define time_t long
#endif
  static time_t startt, prevt;
  time_t currt;
  static long totlen;
  long t1, t2;
  int i;

  currt=time(NULL);

  if (!totlen) {
    totlen=rlen;
    startt=currt;
    fprintf(stdout, "               ");
    for (i=0; i<10; i++) fprintf(stdout, "------");
  }

  if (currt!=prevt || !rlen) {
    t1=currt-startt;
    if (rlen!=totlen) t2=(currt-startt)*(float)totlen/(totlen-rlen);
    else t2=0;
    if (t2>9999) {
      t1/=60;
      t2/=60;
      i=0;
    } else i=1;
    fprintf(stdout, "\r%4u/%4u %4s ", (int)t1, (int)t2, i?"sec.":"min.");
    if (totlen) {
      i=(int) (60*(float)(totlen-rlen)/totlen);
      while (i--) fprintf(stdout, ".");
    }
    fflush(stdout);
    prevt=currt;
  }
  if (!rlen) totlen=0;
}


static unsigned long next = 1;
#define RND_MAX 32767L

/* May define my own random generator */
void osrand(int i)
{
  next = i;
}

int orand()
{
  return((int) ((next = (next * 23) % 100000001) % RND_MAX));
}

void init_random(int i)
{
  if (!i)
    osrand((int) time(NULL));
  else
    osrand(i);
}

int verbose(int level)
{
  static int verbose_level = 1;

  if (level >= 0) {
    verbose_level = level;
  }

  return(verbose_level);
}
  
int silent(int level)
{
  static int silent_level = 0;

  if (level >= 0) {
    silent_level = level;
  }

  return(silent_level);
}
  
int label_not_needed(int level)
{
  static int label_level = 0;

  if (level >= 0) {
    label_level = level;
  }

  return(label_level);
}
  
int use_fixed(int level)
{
  static int fixed_level = 0;

  if (level >= 0) {
    fixed_level = level;
  }

  return(fixed_level);
}
  
int use_weights(int level)
{
  static int weights_level = 0;

  if (level >= 0) {
    weights_level = level;
  }

  return(weights_level);
}
  
/******************************************************************* 
 * Conversion between labels and indices                           * 
 *******************************************************************/
  
struct conv_array {
  char *label;
  struct conv_array *next;
};
static struct conv_array conv_begin;

/* Initialize conversion table */
void conv_init(char *lab)
{
  conv_begin.label = (char *) oalloc(strlen(lab)+1);
  strcpy(conv_begin.label, lab);
  conv_begin.next = NULL;
}

/* Free all the memory used by label list */
void free_labels()
{
  struct conv_array *clab;
  struct conv_array *olab;

  if (conv_begin.label == NULL)
    return;

  clab = &conv_begin;
  ofree(clab->label);
  clab = clab->next;
  while (clab != NULL) {
    ofree(clab->label);
    olab = clab->next;
    ofree(clab);
    clab = olab;
  }
  conv_begin.label = NULL;
}

/* Give the corresponding index;
   if the label is not yet there, add it to table */
int find_conv_to_ind(char *lab)
{
  int	i;
  struct conv_array *clab;

  if (conv_begin.label == NULL)
    conv_init(lab);

  clab = &conv_begin;  
  i = 0;

  while (strcmp(clab->label, lab)) {
    if (clab->next != NULL) {
      i++;
      clab = clab->next;
    }
    else break;
  }

  if (strcmp(clab->label, lab)) {
    clab->next = (struct conv_array *) oalloc(sizeof(struct conv_array));
    clab->next->label = (char *) oalloc(strlen(lab)+1);
    strcpy(clab->next->label, lab);
    clab->next->next = NULL;
    i++;
  }

  return(i);
}

/* Give the corresponding label;
   if the index is not yet there, return a pointer to NULL */
char *find_conv_to_lab(int ind)
{
  char *tmp;
  struct conv_array *clab;

  if (conv_begin.label == NULL) {
    tmp = (char *) oalloc(1);
    tmp[0] = NULL;
    return(tmp);
  }

  clab = &conv_begin;

  while ((clab->next != NULL) && (ind > 0)) {
    ind--;
    clab = clab->next;
  }

  if (ind == 0) {
    tmp = (char *) oalloc(strlen(clab->label)+1);
    strcpy(tmp, clab->label);
  }
  else {
    tmp = (char *) oalloc(1);
    tmp[0] = NULL;
  }
    
  return(tmp);
}

/* Give the number of entries in the label table */
int number_of_labels()
{
  int i;
  struct conv_array *clab;

  if (conv_begin.label == NULL)
    return(0);

  clab = &conv_begin;
  i = 1;
  while (clab->next != NULL) {
    clab = clab->next;
    i++;
  }

  return(i);
}


/******************************************************************* 
 * Routines to get the parameter values                            * 
 *******************************************************************/

int oatoi(char *str, int def)
{
  if (str == (char *) NULL)
    return(def);
  else
    return((int) atoi(str));
}

float oatof(char *str, float def)
{
  if (str == (char *) NULL)
    return(def);
  else
    return((float) atof(str));
}

char *extract_parameter(int argc, char **argv, char *param, int when)
{
  int i = 0;
  char str[100];

  while ((i < argc) && (strcmp(param, argv[i]))) {
    i++;
  }
  if (i < argc-1) {
    return(argv[i+1]);
  }
  else {
    if (when == ALWAYS) {
      sprintf(str, "Can't find asked option %s", param);
      errormsg(str);
      exit(-1);
    }
  }

  return((char *) NULL);
}

/******************************************************************* 
 * Routines to read data and codebook vectors from files           * 
 *******************************************************************/

char *nolab()
{
  static char nol[] = "_nolab_";

  return(nol);
}

int get_weight(char *str)
{
  return(atoi(&(str[7])));
}

struct fixpoint *get_fixed(char *str)
{
  char *dup, *sav;
  struct fixpoint *tmp;

  tmp = (struct fixpoint *) oalloc(sizeof(struct fixpoint));
  dup = strdup(str);

  tmp->xfix = atoi(&(dup[6]));
  sav = strchr(dup, ',');
  tmp->yfix = atoi(&(sav[1]));

  ofree(dup);

  if ((tmp->xfix < 0) || (tmp->yfix < 0)) {
    sprintf(str, "Fixed point incorrect");
    errormsg(str);
    ofree(tmp);
    tmp = NULL;
  }

  return(tmp);
}

struct entries *scan_entry(char *iline, int dim, int *id, int row,
                   int topol, int neigh, int xdim, int ydim)
{
  int i;
  float ent;
  struct entries *entr;
  char str[STR_LNG];
  char lab[STR_LNG];
  char *toke;

  entr = (struct entries *) oalloc(sizeof(struct entries));
  entr->dimension = dim;
  entr->topol = topol;
  entr->neigh = neigh;
  entr->xdim = xdim;
  entr->ydim = ydim;
  entr->weight = 0;
  entr->fixed = NULL;

  entr->points = (float *) oalloc(sizeof(float)*dim);
  toke = strtok(iline, " ");
  if (toke == NULL) {
    sprintf(str, "Can't read entry on line %d", row);
    errormsg(str);
    exit(-1);
  }

  /* Read the first vector value */
  if (sscanf(toke, "%f", &ent) <= 0) {
    sprintf(str, "Can't read entry on line %d", row);
    errormsg(str);
    exit(-1);
  }
  entr->points[0] = ent;

  /* Read the other vector values */
  for (i = 1; i < dim; i++) {
    toke = strtok(NULL, " ");
    if (toke == NULL) {
      sprintf(str, "Can't read entry on line %d", row);
      errormsg(str);
      exit(-1);
    }
    if (sscanf(toke, "%f", &ent) <= 0) {
      sprintf(str, "Can't read entry on line %d", row);
      errormsg(str);
      exit(-1);
    }
    entr->points[i] = ent;
  }

  /* Now the following tokens (if any) are label,
     weight term and fixed point description.
     Sometimes label is not needed. Other terms are never
     needed */
  {
    int label_found;

    label_found = 0;

    while (1) {
      toke = strtok(NULL, " ");
    
      if (toke != NULL) {
	if (strncmp(toke, "weight=", 7) == 0) {
          entr->weight = get_weight(toke);
	}
	else if (strncmp(toke, "fixed=", 6) == 0) {
          entr->fixed = get_fixed(toke);
	}
	else {
          if (label_found) {
            sprintf(str, "Extra labels on line %d", row);
            errormsg(str);
          }
	  if (sscanf(toke, "%s", lab) <= 0) {
	    sprintf(str, "Can't read entry label on line %d", row);
	    errormsg(str);
	    exit(-1);
	  }
	  label_found = 1;
	}
      }
    
      if (toke == NULL) {
	if (label_found)
	  break;
  
	if (label_not_needed(-1)) {
	  toke = nolab();
	  if (sscanf(toke, "%s", lab) <= 0) {
	    sprintf(str, "Can't read entry label on line %d", row);
	    errormsg(str);
	    exit(-1);
	  }
	  label_found = 1;
	}
	else {
	  sprintf(str, "Can't read entry label on line %d", row);
	  errormsg(str);
	  exit(-1);
	}
      }
    }
  }

  entr->index = find_conv_to_ind(lab);
  entr->ident = (*id)++;
  entr->next = NULL;

  return(entr);
}

int topol_type(char *str)
{
  if (strcmp(str, "data") == 0)
    return(0);
  else if (strcmp(str, "lvq") == 0)
    return(1);
  else if (strcmp(str, "hexa") == 0)
    return(2);
  else if (strcmp(str, "rect") == 0)
    return(3);
  else
    return(-1);
}

char *topol_str(int val)
{
  char *str;

  if (val == 0)
    str = strdup("data");
  else if (val == 1)
    str = strdup("lvq");
  else if (val == 2)
    str = strdup("hexa");
  else if (val == 3)
    str = strdup("rect");
  else
    str = strdup("data");

  return(str);
}

int get_topol(char *str)
{
  int ret = topol_type("data");
  char *dup;
  char *tok;

  dup = strdup(str);
  strtok(dup, " ");
  tok = strtok(NULL, " ");

  if (tok != NULL) {
    ret = topol_type(tok);
  }

  free(dup);
  return(ret);
}

int neigh_type(char *str)
{
  if (strcmp(str, "bubble") == 0)
    return(0);
  else if (strcmp(str, "gaussian") == 0)
    return(1);
  else
    return(-1);
}

char *neigh_str(int val)
{
  char *str;

  if (val == 0)
    str = strdup("bubble");
  else if (val == 1)
    str = strdup("gaussian");
  else
    str = strdup("bubble");

  return(str);
}

int get_neigh(char *str)
{
  int ret = neigh_type("bubble");
  char *dup;
  char *tok;

  dup = strdup(str);
  strtok(dup, " ");
  strtok(NULL, " ");
  strtok(NULL, " ");
  strtok(NULL, " ");
  tok = strtok(NULL, " ");

  if (tok != NULL) {
    ret = neigh_type(tok);
  }

  free(dup);
  return(ret);
}

int get_xdim(char *str)
{
  int ret = 0;
  char *dup;
  char *tok;

  dup = strdup(str);
  strtok(dup, " ");
  strtok(NULL, " ");
  tok = strtok(NULL, " ");

  if (tok != NULL) {
    ret = atoi(tok);
  }

  free(dup);
  return(ret);
}

int get_ydim(char *str)
{
  int ret = 0;
  char *dup;
  char *tok;

  dup = strdup(str);
  strtok(dup, " ");
  strtok(NULL, " ");
  strtok(NULL, " ");
  tok = strtok(NULL, " ");

  if (tok != NULL) {
    ret = atoi(tok);
  }

  free(dup);
  return(ret);
}

int getline(FILE *fp, char *str, int len)
{
  int ret;
  char *tstr;

  tstr = fgets(str, len, fp);
  if (tstr == NULL)
    ret = -1;
  else if (str[strlen(str)-1] != '\n')
  {
    printf("Too long line\n");
    ret = -1;
  }
  else {
    str[strlen(str)-1] = '\0';
    ret = strlen(str);
  }

  return(ret);
}

struct entries *read_entries(char *in_data_file)
{
  int dim, sta;
  int row = 0;
  int id = 0;
  int topol;
  int neigh;
  int xdim;
  int ydim;
  int noc;
  char str[STR_LNG];
  char iline[10*STR_LNG];
  struct entries *root;
  struct entries *entr;
  struct entries *ptmp;
  FILE *fp;

  fp = fopen(in_data_file, "r");
  if (fp == NULL) {
    sprintf(str, "Can't open file %s", in_data_file);
    errormsg(str);
    exit(-1);
  }

  /* Find the first not-comment line */
  {
    str[0] = '#';

    while (str[0] == '#') {
      sta = getline(fp, str, STR_LNG);
      row++;
      if (sta <= 0) {
        sprintf(str, "Can't read file %s", in_data_file);
        errormsg(str);
        fclose(fp);
        exit(-1);
      }
    }
  }

  sta = sscanf(str, "%d", &dim);
  if (sta <= 0) {
    errormsg("Can't read dimension parameter");
    fclose(fp);
    exit(-1);
  }

  topol = get_topol(str);
  neigh = get_neigh(str);
  xdim = get_xdim(str);
  ydim = get_ydim(str);

  /* Scan all lines for entries, skip comment lines (begin with #) */
  {
    int first = 1;
  
    while (getline(fp, iline, 10*STR_LNG) > 0) {
      row++;
      if (iline[0] != '#') {
	if (first) {
	  root = scan_entry(iline, dim, &id, row, topol,
			      neigh, xdim, ydim);
	  entr = root;
	  first = 0;
	}
	else {
	  entr->next = scan_entry(iline, dim, &id, row, topol,
				    neigh, xdim, ydim);
	  entr = entr->next;
	}
      }
    }
  }

  /* If this was map file check the number of entries */
  if (topol > topol_type("lvq")) {
    noc = 0;
    ptmp = root;
    while (ptmp != NULL) {
      noc++;
      ptmp = ptmp->next;
    }

    if ((xdim * ydim) != noc) {
      sprintf(str, "Not correct number of entries in %s", in_data_file);
      errormsg(str);
      fclose(fp);
      exit(-1);
    }
  }

  fclose(fp);
  return(root);
}

 /****************************************************************** 
 * Routines to store codebook vectors                              * 
 *******************************************************************/

void save_entries(struct entries *codes, char *out_code_file)
{
  int i;
  char str[STR_LNG];
  FILE *fp;

  fp = fopen(out_code_file, "w+");
  if (fp == NULL) {
    sprintf(str, "Can't open file %s", out_code_file);
    errormsg(str);
    exit(-1);
  }

  if (codes != NULL) {
    fprintf(fp, "%d", codes->dimension);
    if (codes->topol > get_topol("data")) {
      fprintf(fp, " %s", topol_str(codes->topol));
      fprintf(fp, " %d", codes->xdim);
      fprintf(fp, " %d", codes->ydim);
      fprintf(fp, " %s", neigh_str(codes->neigh));
    }
    fprintf(fp, "\n");
  }

  while (codes != NULL) {
    for (i = 0; i < codes->dimension; i++) {
      fprintf(fp, "%g ", codes->points[i]);
    }
    if (codes->index != find_conv_to_ind(nolab())) {
      fprintf(fp, "%s", find_conv_to_lab(codes->index));
    }
    fprintf(fp, "\n");
    codes = codes->next;
  }

  fclose(fp);
}


/******************************************************************* 
 * Routines to handle files that contain the learning rate values  *
 *******************************************************************/

int alpha_read(float *alpha, int noc, char *infile)
{
  int i;
  char basename[STR_LNG];
  char str[STR_LNG];
  FILE *fp;

  strcpy(basename, infile);
  strtok(basename, ".");
  strcat(basename, ".lra");

  fp = fopen(basename, "r");
  if (fp == NULL) {
    if (verbose(-1) > 0) {
      sprintf(str, "Can't open file %s", basename);
      errormsg(str);
    }
    return(0);
  }
  
  for (i = 0; i < noc; i++) {
    if (fscanf(fp, "%g\n", &(alpha[i])) < 0)
      return(0);
  }

  fclose(fp);

  return(1);
}

void alpha_write(float *alpha, int noc, char *outfile)
{
  int i;
  char basename[STR_LNG];
  char str[STR_LNG];
  FILE *fp;

  strcpy(basename, outfile);
  strtok(basename, ".");
  strcat(basename, ".lra");

  fp = fopen(basename, "w+");
  if (fp == NULL) {
    sprintf(str, "Can't open file %s", basename);
    errormsg(str);
    exit(-1);
  }

  for (i = 0; i < noc; i++) {
    fprintf(fp, "%g\n", alpha[i]);
  }

  fclose(fp);
}

void invalidate_alphafile(char *outfile)
{
  int i;
  char basename[STR_LNG];
  char str[STR_LNG];
  FILE *fp;

  strcpy(basename, outfile);
  strtok(basename, ".");
  strcat(basename, ".lra");

  fp = fopen(basename, "r");
  if (fp != NULL) {
    if (verbose(-1) > 0)
      fprintf(stdout, "Removing the learning rate file %s\n", basename);
    fclose(fp);
    i = remove(basename);
    if (i) {
      sprintf(str, "Can not remove %s", basename);
      errormsg(str);
    }
  }
}


/******************************************************************* 
 * Other routines                                                  *
 *******************************************************************/

struct entries *new_entry_order(struct entries *data)
{
  int i;
  int nol;
  struct entries *temp;
  struct entries *endi;

  if (data == NULL)
    return(data);

  temp = data;
  nol = 0;
  while (temp != NULL) {
    temp = temp->next;
    nol++;
  }
  
  i = orand() % nol;

  temp = data;
  while ((i-- > 0) && (temp->next != NULL)) {
    temp = temp->next;
  }
  endi = temp;
  while (endi->next != NULL) {
    endi = endi->next;
  }
  endi->next = data;
  data = temp->next;
  temp->next = NULL;

  return(data);
}

