/************************************************************************
 *                                                                      *
 *  Program package 'lvq_pak':                                          *
 *                                                                      *
 *  mindist.c                                                           *
 *  -displays the medians of the shortest distances in each class       *
 *                                                                      *
 *  Version 2.1                                                         *
 *  Date: 9 Oct 1992                                                    *
 *                                                                      *
 *  NOTE: This program package is copyrighted in the sense that it      *
 *  may be used for scientific purposes. The package as a whole, or     *
 *  parts thereof, cannot be included or used in any commercial         *
 *  application without written permission granted by its producents.   *
 *  No programs contained in this package may be copied for commercial  *
 *  distribution.                                                       *
 *                                                                      *
 *  All comments  concerning this program package may be sent to the    *
 *  e-mail address 'lvq@cochlea.hut.fi'.                                *
 *                                                                      *
 ************************************************************************/

#include <stdio.h>
#include <float.h>
#include <math.h>
#include "lvq_pak.h"

#define BAL 1.3




main(int argc, char **argv)
{
  int nol;
  int i;
  int *noe;
  float *dists, *dists2;
  char *in_code_file;
  char *in_data_file;
  struct entries *codes;
  struct entries *data;
  struct entries *entr;


  in_code_file = extract_parameter(argc, argv, IN_CODE_FILE, ALWAYS);
  in_data_file = extract_parameter(argc, argv, IN_DATA_FILE, OPTION);
  verbose((int) oatoi(extract_parameter(argc, argv, VERBOSE, OPTION), 1));

  if (verbose(-1) > 1)
    fprintf(stdout, "Codebook entries are read from file %s\n", in_code_file);
  codes = read_entries(in_code_file);
  if (in_data_file != (char *) NULL) {
    if (verbose(-1) > 1)
      fprintf(stdout, "Input entries are read from file %s\n", in_data_file);
    data = read_entries(in_data_file);
  }

  nol = number_of_labels();
  noe = (int *) oalloc(sizeof(int) * nol);
  for (i = 0; i < nol; i++) {
    noe[i] = 0;
  }
  entr = codes;
  while (entr != NULL) {
    noe[entr->index]++;
    entr = entr->next;
  }

  if (verbose(-1) > 1)
    fprintf(stdout, "The medians of the shortest distances are computed\n");
  dists = med_distances(codes);
  if (in_data_file != (char *) NULL) {
    if (verbose(-1) > 1)
      fprintf(stdout, "The standard deviations are computed\n");
    dists2 = deviations(data);
  }
  for (i = 0; i < nol; i++) {
    fprintf(stdout, "In class %9s %3d units, min dist.: %6.3f",
          find_conv_to_lab(i), noe[i], dists[i]);
    if (in_data_file != (char *) NULL) {
      fprintf(stdout, ", stand. dev.: %6.3f \n", dists2[i]);
    }
    else
      fprintf(stdout, "\n");
  }

  return(0);
}
