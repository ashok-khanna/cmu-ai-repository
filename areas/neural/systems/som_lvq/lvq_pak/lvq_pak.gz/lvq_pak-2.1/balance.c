/************************************************************************
 *                                                                      *
 *  Program package 'lvq_pak':                                          *
 *                                                                      *
 *  balance.c                                                           *
 *  -balances the number of entries in codebook by shortest distances   *
 *                                                                      *
 *  Version 2.1                                                         *
 *  Date: 9 Oct 1992                                                    *
 *                                                                      *
 *  NOTE: This program package is copyrighted in the sense that it      *
 *  may be used for scientific purposes. The package as a whole, or     *
 *  parts thereof, cannot be included or used in any commercial         *
 *  application without written permission granted by its producents.   *
 *  No programs contained in this package may be copied for commercial  *
 *  distribution.                                                       *
 *                                                                      *
 *  All comments  concerning this program package may be sent to the    *
 *  e-mail address 'lvq@cochlea.hut.fi'.                                *
 *                                                                      *
 ************************************************************************/

#include <stdio.h>
#include <float.h>
#include "lvq_pak.h"

#define BAL 1.3


struct entries *balance_codes(struct entries *data, struct entries *codes,
                              int knn, char *outfile)
{
  int nol;
  long nod;
  int i;
  int *noe, *diff;
  int note;
  float aver;
  float *dists;
  struct entries *entr;
  struct entries *tlab;

  nol = number_of_labels();
  noe = (int *) oalloc(sizeof(int) * nol);
  diff = (int *) oalloc(sizeof(int) * nol);
  for (i = 0; i < nol; i++) {
    noe[i] = 0;
    diff[i] = 0;
  }

  nod = 0;
  entr = data;
  while (entr != NULL) {
    nod++;
    entr = entr->next;
  }

  /* How many codebook vectors per class initially? */
  entr = codes;
  while (entr != NULL) {
    noe[entr->index]++;
    entr = entr->next;
  }

  /* Compute the medians of the shortest distances from each entry to
     its nearest entry of the same class */
  if (verbose(-1) > 1)
    fprintf(stdout, "Medians of the shortest distances are computed\n");
  dists = med_distances(codes);

  /* If serious imbalance exists, add entries to classes where
     distances are large, and remove them from classes where distances
     are small                                                         */
  aver = 0.0;
  note = 0;
  for (i = 0; i < nol; i++) {
    if (noe[i] > 1) {
      aver += dists[i];
      note++;
    }
  }
  aver /= note;

  note = 0;
  if (verbose(-1) > 1)
    fprintf(stdout, "Medians of different classes are compared\n");
  for (i = 0; i < nol; i++) {
    if ((aver > BAL * dists[i]) && (noe[i] > 1)) {
      diff[i]--;
      note++;
    }
    if (BAL * aver < dists[i]) {
      diff[i]++;
      note--;
    }
  }

  /* Force-pick one codebook vector for each missing class */
  for (i = 0; i < nol; i++) {
    if (noe[i] == 0) {
      entr = force_pick_code(data, i);

      tlab = codes;
      while (tlab->next != NULL)
        tlab = tlab ->next;
      tlab->next = entr;

      noe[i] = 1;
      note--;
    }
  }

  /* If there was net increase or decrease in number of entries */
  for (i = 0; i < nol; i++) {
    if ((aver > BAL * dists[i]) && ((noe[i]+diff[i]) > 1)) {
      if (note < 0) {
        diff[i]--;
        note++;
      }
    }
    if (BAL * aver < dists[i]) {
      if (note > 0) {
        diff[i]++;
        note--;
      }
    }
  }

  if (verbose(-1) > 0)
    fprintf(stdout, "Some codebook vectors are removed\n");
  /* Now remove entries from those classes where diff shows negative */
  entr = codes;
  while (entr->next != NULL) {
    if (diff[entr->next->index] < 0) {
      diff[entr->next->index]++;
      tlab = entr->next;
      entr->next = entr->next->next;
      tlab->next = NULL;
      efree(tlab);
    }
    else
      entr = entr->next;
  }
  if (diff[codes->index] < 0) {
    diff[codes->index]++;
    tlab = codes;
    codes = codes->next;
    tlab->next = NULL;
    efree(tlab);
  }

  if (verbose(-1) > 0)
    fprintf(stdout, "Some new codebook vectors are picked\n");
  /* Pick the requested number of additional codes for each class */
  entr = pick_inside_codes(diff, data, nol, knn);

  /* Add new entries to the list */
  tlab = codes;
  while (tlab->next != NULL)
    tlab = tlab ->next;
  tlab->next = entr;

  if (verbose(-1) > 0)
    fprintf(stdout, "Codebook vectors are redistributed\n");
  entr = olvq1_training(data, codes, nod, 0.3, (char *) NULL, outfile);

  /* How many codebook vectors per class now? */
  for (i = 0; i < nol; i++)
    noe[i] = 0;
  codes = entr;
  while (entr != NULL) {
    noe[entr->index]++;
    entr = entr->next;
  }

  /* Display the medians of the shortest distances */
  if (verbose(-1) > 1)
    fprintf(stdout, "Medians of the shortest distances are computed\n");
  dists = med_distances(codes);
  for (i = 0; i < nol; i++) {
    if (verbose(-1) > 0)
      fprintf(stdout, "In class %9s %3d units, min dist.: %.3f\n",
	     find_conv_to_lab(i), noe[i], dists[i]);
  }

  return(codes);
}

main(int argc, char **argv)
{
  char *in_data_file;
  char *in_code_file;
  char *out_code_file;
  struct entries *data, *codes;
  int knn;
  int randomize;

  in_data_file = extract_parameter(argc, argv, IN_DATA_FILE, ALWAYS);
  in_code_file = extract_parameter(argc, argv, IN_CODE_FILE, ALWAYS);
  out_code_file = extract_parameter(argc, argv, OUT_CODE_FILE, ALWAYS);
  verbose((int) oatoi(extract_parameter(argc, argv, VERBOSE, OPTION), 1));
  knn = (int) oatoi(extract_parameter(argc, argv, KNN_NEIGHBORS, OPTION), 5);
  randomize = (int) oatoi(extract_parameter(argc, argv, RANDOM, OPTION), 0);

  if (verbose(-1) > 1)
    fprintf(stdout, "Input entries are read from file %s\n", in_data_file);
  data = read_entries(in_data_file);
  if (verbose(-1) > 1)
    fprintf(stdout, "Codebook entries are read from file %s\n", in_code_file);
  codes = read_entries(in_code_file);

  if (data->dimension != codes->dimension) {
    fprintf(stderr, "Data and codes have different dimensions\n");
    exit(0);
  }

  init_random(randomize);

  codes = balance_codes(data, codes, knn, out_code_file);

  if (verbose(-1) > 1)
    fprintf(stdout, "Codebook entries are saved to file %s\n", out_code_file);
  save_entries(codes, out_code_file);

  return(0);
}

