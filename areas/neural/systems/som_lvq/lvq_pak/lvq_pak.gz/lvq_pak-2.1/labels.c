/************************************************************************
 *                                                                      *
 *  Program package 'lvq_pak':                                          *
 *                                                                      *
 *  labels.c                                                            *
 *  -displays the number of entries in each class                       *
 *                                                                      *
 *  Version 2.1                                                         *
 *  Date: 9 Oct 1992                                                    *
 *                                                                      *
 *  NOTE: This program package is copyrighted in the sense that it      *
 *  may be used for scientific purposes. The package as a whole, or     *
 *  parts thereof, cannot be included or used in any commercial         *
 *  application without written permission granted by its producents.   *
 *  No programs contained in this package may be copied for commercial  *
 *  distribution.                                                       *
 *                                                                      *
 *  All comments  concerning this program package may be sent to the    *
 *  e-mail address 'lvq@cochlea.hut.fi'.                                *
 *                                                                      *
 ************************************************************************/

#include <stdio.h>
#include "lvq_pak.h"

void labels(struct entries *data)
{
  int i;
  int nol;
  int *noe;

  /* Number of different classes */
  nol = number_of_labels();
  noe = (int *) oalloc(sizeof(int) * nol);
  for (i = 0; i < nol; i++) {
    noe[i] = 0;
  }
  while (data != NULL) {
    noe[data->index]++;
    data = data->next;
  }

  for (i = 0; i < nol; i++) {
    fprintf(stdout, "In class %9s are %3d units\n",
          find_conv_to_lab(i), noe[i]);
  }
}

main(int argc, char **argv)
{
  char *in_code_file;
  struct entries *codes;

  in_code_file = extract_parameter(argc, argv, IN_CODE_FILE, ALWAYS);
  verbose((int) oatoi(extract_parameter(argc, argv, VERBOSE, OPTION), 1));

  if (verbose(-1) > 1)
    fprintf(stdout, "Code entries are read from file %s\n", in_code_file);
  codes = read_entries(in_code_file);

  labels(codes);

  return(0);
}
