# $Id: expert.ex,v 1.1 93/01/15 14:00:53 drew Exp $
tag: First
1 0 0 0,
1 0 0 0;
tag: Second
0 1 0 0,
0 1 0 0;
tag: Third
0 0 1 0,
0 0 1 0;
tag: Fourth
0 0 0 1,
0 0 0 1;
tag: Fifth
1 0 0 1,
1 0 0 1;
tag: Sixth
0 1 0 1,
0 1 0 1;
tag: Seventh
0 1 1 0,
0 1 1 0;
tag: Eighth
0 0 1 1,
0 0 1 1;
tag: Ninth
1 0 0 1,
1 0 0 1;
tag: Tenth
1 1 0 0,
1 1 0 0;

