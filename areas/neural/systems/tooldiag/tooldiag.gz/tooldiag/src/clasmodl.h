/* ---------  CLASSIFIER MODELS -----------*/

#define NEAREST_NEIGHBOR 0
#define MULTIVARIATE_GAUSSIAN 1
