typedef struct hypersphere_kernel_ {
	double thresh, inverseVol;
	} hypersphere_kernel;
