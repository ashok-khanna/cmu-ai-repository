typedef double MatElem;

typedef struct Matrix_ {
         int row, col;
         MatElem *Elem;
       } Matrix;
