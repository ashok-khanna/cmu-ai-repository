/************************************************************************
 *                                                                      *
 *  Program package "tooldiag":                                         *
 *                                                                      *
 *                                                                      *
 *  Version 1.3                                                         *
 *  Date: 15 November 1993                                              *
 *                                                                      *
 *  NOTE: This program package is copyrighted in the sense that it      *
 *  may be used for scientific purposes. The package as a whole, or     *
 *  parts thereof, cannot be included or used in any commercial         *
 *  application without written permission granted by the author.       *
 *  No programs contained in this package may be copied for commercial  *
 *  distribution.                                                       *
 *                                                                      *
 *  All comments  concerning this program package may be sent to the    *
 *  e-mail address 'tr@fct.unl.pt'.                                     *
 *                                                                      *
 ************************************************************************/

#include <stdio.h>
#include <string.h>
#include "def.h"

extern universe *U;

static bool done;
static str80 buf;


void statLoop()
{
 printf("\n>>>>>----- STATISTICAL ANALYSIS -----<<<<<<\n");
 printf("(1) Correlation between 2 features\n");
 printf("(Q)uit\n\n");
 printf("Choice: ");

 gets(buf); done = FALSE;
 switch( buf[0] )
  {
   case '?': help( LOOP_STATS, buf ); break;
   case '1': correlation(); break;
   case 'q': case 'Q': done = TRUE; break;
   default: showUniv( stdout ); break;
  }
}


void statistics()
{
 if( U->nrClass > 1 )
   do
   {
     statLoop();
   }
   while( !done );
 else
   { printf(" Please load universe or select features first !..." );
     gets( buf ); }
}
