/****************************************************************************/
/*                           mbpval.c                                       */
/****************************************************************************/
/* Written by: Davide Anguita                                               */
/*             University of Genova                                         */
/*             DIBE - Department of Biophysical and Electronic Engineering  */
/*             Via all'Opera Pia 11a                                        */
/*             16145 Genova, ITALY                                          */
/*             e-mail: anguita@dibe.unige.it                                */
/*             Tel:    +39-10-3532192                                       */
/*             Fax:    +39-10-3532175                                       */
/****************************************************************************/
/*                                                                          */
/* Matrix Back Propagation Validation:                                      */
/* validates a learned network generated with MBP.                          */ 
/*                                                                          */
/* USAGE:  MBPVAL <configuration file>                                      */
/*                                                                          */ 
/* REVISION 1.1 - August 1993                                               */
/*                                                                          */
/****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <malloc.h>
#include "random.h"
#include "mm.h"
#include "mbpval.h"

/****************************************************************************/
/*                           main()                                         */
/****************************************************************************/

main(int argc, char* argv[])
 {

  REAL   Sat   = 0.9;     /* [-1,+1] -> [-Sat,+Sat]                         */

  int    RunTh;           /* Threshold on # of runs                         */
  int    nRun;            /* Actual run                                     */

  int    nPrints;         /* # of iterations/prints  0=no output            */
  long   aSeed;           /* Initial seed of the random number generator    */

  REAL   AnaCost;         /* Analog cost                    (t-o)^2         */
  REAL   MaxCost;         /* Maximum absolute cost          max|t-o|        */
  REAL   DigCost;         /* Digital cost                   sign(t*o) %     */
  REAL   TotAnaCost;      /* Total analog cost                              */
  REAL   TotMaxCost;      /* Total maximum absolute cost                    */
  REAL   TotDigCost;      /* Total digital cost                             */
  long   nIter;           /* Iteration #                                    */

  REAL   BestAnaCost;    /* Best analog cost                                */
  REAL   BestMaxCost;    /* Best maximum absolute cost                      */
  REAL   BestDigCost;    /* Best digital cost                               */
  int    nBestAna;       /* Run # with best analog cost                     */
  int    nBestMax;       /* Run # with best max abs cost                    */
  int    nBestDig;       /* Run # with best digital cost                    */
  int    nSuccRun;       /* # of successfull runs                           */
  long   nSuccIter;      /* # of iterations of successfull runs             */        
  long   nTotIter;       /* # of total iterations                           */

  REAL** Status;         /* Neurons status for validation patterns          */
  REAL** Weight;         /* Weights                                         */
  REAL** Bias;           /* Biases                                          */
  REAL*  TargetVal;      /* Target of validation patterns                   */
/*  REAL** StepWeight; */    /* Weight updating step                            */
/*  REAL** StepBias;   */    /* Bias updating step                              */

  int    nLayer;         /* # of layers                                     */
  int*   nUnit;          /* # of neurons per layer                          */
  int    nVPattern;      /* # of validation patterns                        */

  FILE*  fWeight;        /* File of weights and biases                      */
  FILE*  fInputVal;      /* File of validation patterns                     */
  FILE*  fTargetVal;     /* File of targets for validation patterns         */

  int    i;              


  Init (&Status,    &Weight,    &Bias,       &TargetVal, &nLayer, &nUnit,
	&nVPattern, &fInputVal, &fTargetVal, &fWeight,   &RunTh,  Sat,
	argc,       argv);

  for (nRun = 1; nRun LE RunTh; nRun++)
   {
    TotAnaCost = 0.0;
    TotMaxCost = 0.0;
    TotDigCost = 0.0;

    ReadNet (fWeight, Weight, Bias, nLayer, nUnit);

    for (i=1; i LE nLayer; i++)
     {
      FeedForward (Status[i],   nVPattern,  nUnit[i],
		   Status[i-1], nVPattern,  nUnit[i-1],
		   Weight[i],   nUnit[i-1], nUnit[i],
		   Bias[i],     nUnit[i]);
     }

    OutPattern(TargetVal, Status[nLayer], nVPattern, nUnit[nLayer], Sat);

    TotDigCost = ComputeDigitalCost (TargetVal,      nVPattern, nUnit[nLayer],
				     Status[nLayer], nVPattern, nUnit[nLayer]);

    TotAnaCost = ComputeAnalogCost (TargetVal,      nVPattern, nUnit[nLayer],
				    Status[nLayer], nVPattern, nUnit[nLayer]);

    TotMaxCost = ComputeMaximumCost (TargetVal,      nVPattern, nUnit[nLayer],
				     Status[nLayer], nVPattern, nUnit[nLayer]);

    OutTot(nRun, TotAnaCost, TotMaxCost, TotDigCost);

   }
  return 0;
 }


/****************************************************************************/
/*                           FeedForward()                                  */
/****************************************************************************/

void FeedForward (REAL *NewStatus, int nRowsNS, int nColsNS,
		  REAL *OldStatus, int nRowsOS, int nColsOS,
		  REAL *Weight,    int nRowsW,  int nColsW,
		  REAL *Bias,      int nElem)

 {
  int i,j;

  /* Keep the compiler happy */

  IGNORE(nRowsW);
  IGNORE(nRowsOS);
  IGNORE(nElem);

  /* Fast matrix multiplication routine to compute neurons' net input */

  MM2x2PB (NewStatus, OldStatus, Weight, nRowsNS, nColsNS, nColsOS,
	   nColsOS,   nColsW, BLOCK_DIMENSION);

  /* Compute neurons' output */
  
  for (i=0; i<nRowsNS; i++)
   {
    for (j=0; j<nColsNS; j++)
     {
      NewStatus[i*nColsNS+j] = f(NewStatus[i*nColsNS+j]+Bias[j]);
     }
   }
 }


/****************************************************************************/
/*                              f()                                         */
/****************************************************************************/

REAL f (REAL x)
{
 return (REAL)tanh((double)x);                                  /* Tanh */
 
 /* IF YOU WANT TO USE THE APPROXIMATION USE THE FOLLOWING CODE INSTEAD */
 /*
 REAL Lambda = 0.26037;
 REAL Xs     = 1.92033;
 REAL Ys     = 0.96016;

 if ( x GT Xs )
  return Ys;
 else if ( x LT -Xs )
  return -Ys;
 else if ( x GE 0.0 )
  return Ys-Lambda*(x-Xs)*(x-Xs);
 else
  return Lambda*(x+Xs)*(x+Xs)-Ys;
 */

}


/****************************************************************************/
/*                           ComputeDigitalCost()                           */
/****************************************************************************/

REAL ComputeDigitalCost (REAL *Target, int nRowsT, int nColsT,
    REAL *Status, int nRowsS, int nColsS)
 {
  int  i;
  REAL result = 0.0;

  /* Keep the compiler happy */
  
  IGNORE(nRowsS);
  IGNORE(nColsS);

  /* Compute the % of wrong answers of the net */

  for ( i=0; i LT nRowsT*nColsT; i++ )
   {
    if (Target[i]*Status[i] LE 0.0)
     {
      result += 100.0/(REAL)(nRowsT*nColsT);
     }
   }

  return result;
 
 }

/****************************************************************************/
/*                           ComputeAnalogCost()                            */
/****************************************************************************/

REAL ComputeAnalogCost  (REAL *Target, int nRowsT, int nColsT,
			 REAL *Status, int nRowsS, int nColsS)
 {
  int  i;
  REAL result = 0.0;

  /* Keep the compiler happy */

  IGNORE(nRowsS);
  IGNORE(nColsS);

  /* Compute the quadratic error of the net */

  for ( i=0; i LT nRowsT*nColsT; i++)
   {
    result += (Target[i]-Status[i])*(Target[i]-Status[i]);
   }
  result /= (REAL) (nRowsT*nColsT);

  return result;
 }

/****************************************************************************/
/*                           ComputeMaximumCost()                           */
/****************************************************************************/

REAL ComputeMaximumCost (REAL *Target, int nRowsT, int nColsT,
			 REAL *Status, int nRowsS, int nColsS)
 {
  int  i;
  REAL result = 0.0;
  REAL diff;

  /* Keep the compiler happy */

  IGNORE(nRowsS);
  IGNORE(nColsS);

  /* Compute the maximum abs error of the net */

  for ( i=0; i LT nRowsT*nColsT; i++)
   {
    diff = Target[i] - Status[i];
    if (diff LT 0.0)
     {
      diff = -diff;
     }
    result = (result GT diff) ? result : diff;
   }

  return result;
 }

/****************************************************************************/
/*                         END OF FILE                                      */
/****************************************************************************/
