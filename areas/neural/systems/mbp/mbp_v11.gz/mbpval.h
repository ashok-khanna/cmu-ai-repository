/************************************************************************/
/*                             MBPVAL.H                                 */
/************************************************************************/
/* Written by: Davide Anguita                                               */
/*             University of Genova                                         */
/*             DIBE - Department of Biophysical and Electronic Engineering  */
/*             Via all'Opera Pia 11a                                        */
/*             16145 Genova, ITALY                                          */
/*             e-mail: anguita@dibe.unige.it                                */
/*             Tel:    +39-10-3532192                                       */
/*             Fax:    +39-10-3532175                                       */
/****************************************************************************/
/*                                                                          */
/* Matrix Back Propagation Validation:                                      */
/* validates a learned network generated with MBP.                          */ 
/*                                                                          */
/* USAGE:  MBPVAL <configuration file>                                      */
/*                                                                          */ 
/* REVISION 1.1 - August 1993                                               */
/*                                                                          */
/****************************************************************************/


#ifndef _H_MBPVAL
#define _H_MBPVAL

/****************************************************************************/
/*                            DEFINES                                       */
/****************************************************************************/
/*                                                                          */
/* Some useful defines..                                                    */
/*                                                                          */
/****************************************************************************/

typedef int   BOOL;

#define OR      ||
#define AND     &&
#define NOT     !

#define EQ      ==
#define GE      >=
#define GT      >
#define LE      <=
#define LT      <
#define NE      !=

#define ERROR   -1
#define NO_ERROR 0

#define TEXT_LINE 81

#ifndef TRUE
#define TRUE    -1
#endif

#ifndef FALSE
#define FALSE    0
#endif

#ifndef MAXFLOAT
#define MAXFLOAT 1.0e38
#endif

#define ERROR_MSG(x)    {\
			 printf("ERROR: %s\n",x);\
			 exit(-1);\
			}

#define DEBUG(x) printf("***DEBUG*** %s\n",x);\
		 getch();

#define WRITE_MAT(Mat,Rows,Cols,Name) {\
					printf("*** MATRIX %s ***\n",Name);\
					for (ii=0; ii LT (Rows); ii++)\
					 {\
					  for (jj=0; jj LT (Cols); jj++)\
					   printf(" %4.2f ",Mat[ii*(Cols)+jj]);\
					  printf("\n");\
					 }\
				      }

#define CHECK_PTR(x) if (x EQ NULL)\
		      {\
		       printf("Insufficient memory\n");\
		      }

#define IGNORE(x) if(x);

/***************************************************************************/
/*                            Init()                                       */
/***************************************************************************/
/*                                                                         */
/* Matrix allocation and initialization (from files).                      */
/*                                                                         */
/***************************************************************************/


void Init (REAL ***Status,    REAL ***Weight,    REAL ***Bias, 	   
	   REAL  **TargetVal, int    *nLayer,    int   **nUnit,
	   int    *nVPattern, FILE  **fInputVal, FILE  **fTargetVal,
	   FILE  **fWeight,   int    *RunTh,     REAL    Sat,
	   int     argc,      char   *argv[]);

/****************************************************************************/
/*                         GetInt()                                         */
/*                         GetReal()                                        */
/*                         GetName()                                        */
/****************************************************************************/
/*                                                                          */
/* Read respectively int, long, real and char* values from the network      */
/* configuration file                                                       */
/*                                                                          */
/****************************************************************************/

void GetInt  (FILE *File, char *Name, int  *x);
void GetReal (FILE *File, char *Name, REAL *x);
void GetName (FILE *File, char *Name, char *x);

/****************************************************************************/
/*                         FeedForward()                                    */
/****************************************************************************/
/*                                                                          */
/* Feed-forward phase of BP. Computes:                                      */
/*                                                        t                 */
/*   [Status](n) = f([Weight](n)*[Status](n-1)+Bias(n-1)*1)                 */
/*                                                                          */
/* for each layer.                                                          */
/*                                                                          */
/****************************************************************************/

void FeedForward (REAL *NewStatus, int nRowsNS, int nColsNS,
                  REAL *Weight,    int nRowsW,  int nColsW,
                  REAL *OldStatus, int nRowsOS, int nColsOS,
                  REAL *Bias,      int nElem);

/****************************************************************************/
/*                         ComputeDigitalCost()                             */
/*                         ComputeAnalogCost()                              */
/*                         ComputeMaximumCost()                             */
/****************************************************************************/
/*                                                                          */
/* Compute different errors of the net.                                     */
/*                                                                          */
/* - Digital                                                                */
/*   % of wrong outputs of the network                                      */
/*                                                                          */
/* - Analog                                                                 */
/*   quadratic error                                                        */
/*                                                                          */
/* - Maximum                                                                */
/*   maximum absolute error                                                 */
/*                                                                          */
/****************************************************************************/

REAL ComputeDigitalCost  (REAL *Target, int nRowsT, int nColsT,
                          REAL *Status, int nRowsS, int nColsS);

REAL ComputeAnalogCost   (REAL *Target, int nRowsT, int nColsT,
                          REAL *Status, int nRowsS, int nColsS);

REAL ComputeMaximumCost  (REAL *Target, int nRowsT, int nColsT,
                          REAL *Status, int nRowsS, int nColsS);


/****************************************************************************/
/*                         ReadNet()                                	    */
/****************************************************************************/
/*									    */
/* Read the weights and biases of the net from file.                        */
/*									    */
/****************************************************************************/

void ReadNet (FILE *fWeight, REAL **Weight, REAL **Bias, int nLayer,
              int *nUnit);


/****************************************************************************/
/*                         OutPattern()                               	    */
/*			   OutTot()					    */
/****************************************************************************/
/* 								      	    */
/* Output results.				                            */
/* OutPattern prints the output pattern of the net and the corresponding    */
/* target.                                                                  */                                
/* OutTot prints the total costs for each run.				    */
/*								      	    */
/****************************************************************************/

void OutPattern (REAL *Target, REAL *Status, int nRows, int nCols, REAL Sat);

void OutTot (int nRun, REAL TotAnaCost, REAL TotMaxCost, REAL TotDigCost);

/****************************************************************************/
/*                             f()                                          */
/*                             df()                                         */
/****************************************************************************/
/*                                                                          */
/* Activation function of the neurons.                                      */
/*                                                                          */
/****************************************************************************/

REAL f  (REAL x);

#endif

/****************************************************************************/
/*                            END OF FILE                             	    */
/****************************************************************************/
