#include "stdplt.h"

_drrect(double x1, double y1, double x2, double y2, double x3, double y3, 
	double x4, double y4, int fill)
           
/*
 * Draw rectangle in current coordinate frame.
 */

  {
	_move(STDSIZ,STDSIZ);
	putc(_CMD| 'l',stdplt);
	putc(fill, stdplt);
	_move(x1,y1);
	_draw(x2,y2);
	_draw(x3,y3);
	_draw(x4,y4);
  }
