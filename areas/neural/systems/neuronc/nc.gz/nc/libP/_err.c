/* _err.c */

#include "stdplt.h"

#undef BYTESWAP
#ifdef BYTESWAP

_err(fmt, args)
  char *fmt;

#else

_err(char *fmt, int arg1, int arg2, int arg3, int arg4)
            
                          

#endif

/*
 * Simulate printf on stderr, followed by abort().
 */
  {
	fflush(stdplt);
/*	fputs("\n",stderr);		/* force Tektronix to ascii */
#ifdef BYTESWAP
	_doprnt(fmt, &args, stderr); */		/*  instead of doprnt */
#else
	fprintf(stderr,fmt, arg1,arg2,arg3,arg4); /* use fprintf to calc len*/
#endif
	_cleanup();
	abort();			/* cause core dump */
	_exit(0177);
  }



#ifdef BYTESWAP

_warn(fmt, args)
  char *fmt;

#else

_warn(char *fmt, int arg1, int arg2, int arg3, int arg4)
            
                          

#endif

/*
 * Simulate printf on stderr.
 */
  {
	fflush(stdplt);
/*	fputs("\n",stderr);		/* force Tektronix to ascii */
#ifdef BYTESWAP
	_doprnt(fmt, &args, stderr); */		/*  instead of doprnt */
#else
	fprintf(stderr,fmt, arg1,arg2,arg3,arg4); /* use fprintf to calc len*/
#endif
	_cleanup();
  }
