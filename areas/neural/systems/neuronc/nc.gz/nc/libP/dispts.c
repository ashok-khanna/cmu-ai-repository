# include "graph.h"
# include "stdplt.h"
dispts(char *strp, int args)
{
	argp = (union ptr *)&args;
	_dispts(strp,1);
  }
_dispts(char *strp, int doscale)
{
	char astring[100];
	extern xyflg;	/* is this needed? */

	zinit("%$ %D",strp,astring);
	yyparse();
	pair();
	Do_disp();
  }
