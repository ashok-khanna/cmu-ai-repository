#include "stdplt.h"

_drtri(double x1, double y1, double x2, double y2, double x3, double y3, 
	 int fill)
           
/*
 * Draw triangle in current coordinate frame.
 */

  {
	_move(STDSIZ,STDSIZ);
	putc(_CMD| 'v',stdplt);
	putc(fill, stdplt);
	_move(x1,y1);
	_draw(x2,y2);
	_draw(x3,y3);
  }
