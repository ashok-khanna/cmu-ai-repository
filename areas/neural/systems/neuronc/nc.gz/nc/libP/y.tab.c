#ifndef lint
static char yysccsid[] = "@(#)yaccpar	1.8 (Berkeley) 01/20/90";
#endif
#define YYBYACC 1
#line 2 "graph.y"
# include "graph.h"
# include "stdio.h"
struct axtype *_axptr;
struct _data *_datptr;
int starflg;
int yyline;
int xyflg;
int oxyflg;
int i,j;
char *charp,*chrp;
char *sp;
int frag;
double atof(const char *);
#line 20 "y.tab.c"
#define YYERRCODE 256
short yylhs[] = {                                        -1,
    0,    0,    0,    0,    1,    2,    2,    6,    8,    8,
    9,    9,    9,    7,    7,    7,    7,    3,    3,   13,
   14,   14,   10,   10,   10,   10,   10,   10,   10,   10,
   10,   10,   11,   11,   11,    4,    4,   20,   21,   21,
   21,   21,   21,   21,   12,   12,   12,   12,   12,   12,
   18,   15,   15,   15,   15,   15,   15,   15,   15,   16,
   16,   19,   17,    5,   22,   22,   23,   23,   23,   23,
   23,
};
short yylen[] = {                                         2,
    4,    4,    4,    4,    0,    2,    1,    2,    2,    0,
    1,    1,    1,    1,    1,    1,    1,    2,    1,    2,
    2,    0,    1,    1,    1,    1,    1,    1,    1,    1,
    1,    1,    1,    1,    1,    2,    1,    2,    2,    2,
    2,    2,    2,    0,    1,    1,    1,    1,    1,    1,
    1,    1,    1,    1,    1,    1,    1,    1,    1,    1,
    1,    1,    1,    4,    2,    0,    1,    1,    1,    1,
    1,
};
short yydefred[] = {                                      5,
    0,    0,    0,    0,    0,    0,    0,   14,   15,   16,
   17,    0,    7,   10,    0,   22,   19,    0,   44,   37,
    4,   66,    6,    0,   18,    0,   36,    0,    0,   62,
   58,   26,   27,   28,   29,   30,   31,   34,   35,   45,
   46,   47,   48,   49,   50,   51,   52,   53,   54,   55,
   56,   57,   59,   60,   61,   63,    9,   11,   12,   13,
   23,   24,   25,   32,   33,   21,   39,   41,   42,   43,
   40,   66,   71,   67,   69,   68,   70,   65,    0,
};
short yydgoto[] = {                                       1,
    2,   12,   15,   18,   21,   13,   14,   24,   57,   58,
   59,   60,   17,   26,   61,   62,   63,   64,   77,   20,
   28,   29,   78,
};
short yysindex[] = {                                      0,
    0,  -36,  -50,  -39,  -39,  -39,  -39,    0,    0,    0,
    0,  -39,    0,    0,  -39,    0,    0,  -39,    0,    0,
    0,    0,    0,  -64,    0,   60,    0,   41,   -5,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,  110,
};
short yyrindex[] = {                                      0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    8,    0,    0,   14,    0,    0,   22,    0,    0,
    0,    0,    0,    1,    0,    3,    0,    5,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,   28,
};
short yygindex[] = {                                      0,
    0,    0,    0,    0,    0,   17,  167,    0,    0,    4,
    0,   11,   16,    0,  -18,  -12,   -4,   -2,    9,   24,
    0,  -29,    0,
};
#define YYTABLESIZE 227
short yytable[] = {                                       3,
    8,   43,   20,   31,   38,   50,   30,    1,   53,   68,
   73,   37,   55,    2,    5,   69,   74,    6,   39,   34,
    4,    3,   36,   70,   75,   71,   76,   64,   23,   66,
   25,    7,   65,   41,   40,   47,   42,   49,   67,   52,
   48,   27,   79,   32,   54,   46,   56,   44,    8,   10,
   38,   33,   51,   45,   35,    0,    0,    0,    0,    0,
   73,    0,   31,    0,   50,   30,   74,   53,    0,    0,
    0,   55,    0,    0,   75,    0,   76,    0,    0,    0,
    9,   11,    8,   10,    0,    0,    0,    0,    8,    8,
   20,   20,   38,   38,   47,    0,   49,    0,   52,   48,
    0,    0,    0,   54,   46,   56,   43,    0,   31,    0,
   50,   51,    0,   53,    9,   11,    0,   55,    0,    0,
    8,    8,   20,   20,   38,   38,    0,   31,    0,   50,
    0,    0,   53,    0,    0,   37,   55,    0,   41,   40,
   47,   42,   49,   34,   52,   48,   36,    0,    0,   54,
   46,   56,   44,    0,    0,    0,    0,   51,   45,   47,
    0,   49,    0,   52,   48,    0,    0,   32,   54,   46,
   56,   16,   19,   22,    0,   33,   51,   31,   35,   50,
   30,   16,   53,    0,   19,    0,   55,    0,    0,    0,
    0,    0,    0,    0,    0,   72,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,   47,
    0,   49,    0,   52,   48,    0,    0,    0,   54,   46,
   56,    0,    0,    0,    0,    0,   51,
};
short yycheck[] = {                                      36,
    0,   66,    0,   68,    0,   70,   71,    0,   73,   28,
   29,   76,   77,    0,   65,   28,   29,   68,   83,   84,
   71,    0,   87,   28,   29,   28,   29,    0,   12,   26,
   15,   82,   24,   98,   99,  100,  101,  102,   28,  104,
  105,   18,   72,  108,  109,  110,  111,  112,   88,   89,
  115,  116,  117,  118,  119,   -1,   -1,   -1,   -1,   -1,
   79,   -1,   68,   -1,   70,   71,   79,   73,   -1,   -1,
   -1,   77,   -1,   -1,   79,   -1,   79,   -1,   -1,   -1,
  120,  121,   88,   89,   -1,   -1,   -1,   -1,   88,   89,
   88,   89,   88,   89,  100,   -1,  102,   -1,  104,  105,
   -1,   -1,   -1,  109,  110,  111,   66,   -1,   68,   -1,
   70,  117,   -1,   73,  120,  121,   -1,   77,   -1,   -1,
  120,  121,  120,  121,  120,  121,   -1,   68,   -1,   70,
   -1,   -1,   73,   -1,   -1,   76,   77,   -1,   98,   99,
  100,  101,  102,   84,  104,  105,   87,   -1,   -1,  109,
  110,  111,  112,   -1,   -1,   -1,   -1,  117,  118,  100,
   -1,  102,   -1,  104,  105,   -1,   -1,  108,  109,  110,
  111,    5,    6,    7,   -1,  116,  117,   68,  119,   70,
   71,   15,   73,   -1,   18,   -1,   77,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   29,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,  100,
   -1,  102,   -1,  104,  105,   -1,   -1,   -1,  109,  110,
  111,   -1,   -1,   -1,   -1,   -1,  117,
};
#define YYFINAL 1
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 121
#if YYDEBUG
char *yyname[] = {
"end-of-file",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,"'$'",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"'A'","'B'",0,
"'D'",0,"'F'","'G'",0,"'I'",0,0,"'L'","'M'",0,0,0,0,"'R'","'S'","'T'",0,0,"'W'",
"'X'","'Y'",0,0,0,0,0,0,0,0,"'b'","'c'","'d'","'e'","'f'",0,"'h'","'i'",0,0,
"'l'","'m'","'n'","'o'","'p'",0,0,"'s'","'t'","'u'","'v'","'w'","'x'","'y'",
};
char *yyrule[] = {
"$accept : root",
"root : init '$' 'G' sgraph",
"root : init '$' 'A' ssaxis",
"root : init '$' 'D' sdisplay",
"root : init '$' 'R' grid",
"init :",
"sgraph : sgraph graph",
"sgraph : graph",
"graph : xyd graf",
"graf : graf des",
"graf :",
"des : ax",
"des : shift",
"des : disp",
"xyd : 'X'",
"xyd : 'x'",
"xyd : 'Y'",
"xyd : 'y'",
"ssaxis : ssaxis saxis",
"ssaxis : saxis",
"saxis : xyd axis",
"axis : axis ax",
"axis :",
"ax : datatype",
"ax : minmax",
"ax : logax",
"ax : 'l'",
"ax : 't'",
"ax : 'T'",
"ax : 'w'",
"ax : 'W'",
"ax : 'L'",
"ax : numpts",
"shift : gridtype",
"shift : 's'",
"shift : 'S'",
"sdisplay : sdisplay display",
"sdisplay : display",
"display : xyd dis",
"dis : dis disp",
"dis : dis numpts",
"dis : dis datatype",
"dis : dis minmax",
"dis : dis logax",
"dis :",
"disp : 'c'",
"disp : 'b'",
"disp : 'e'",
"disp : 'B'",
"disp : 'p'",
"disp : 'v'",
"numpts : 'n'",
"datatype : 'd'",
"datatype : 'i'",
"datatype : 'f'",
"datatype : 'F'",
"datatype : 'u'",
"datatype : 'h'",
"datatype : 'D'",
"datatype : 'I'",
"minmax : 'm'",
"minmax : 'M'",
"gridtype : 'G'",
"logax : 'o'",
"grid : xyd ggrid xyd ggrid",
"ggrid : ggrid rgrid",
"ggrid :",
"rgrid : minmax",
"rgrid : numpts",
"rgrid : logax",
"rgrid : gridtype",
"rgrid : datatype",
};
#endif
#ifndef YYSTYPE
typedef int YYSTYPE;
#endif
#define yyclearin (yychar=(-1))
#define yyerrok (yyerrflag=0)
#ifdef YYSTACKSIZE
#ifndef YYMAXDEPTH
#define YYMAXDEPTH YYSTACKSIZE
#endif
#else
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 500
#define YYMAXDEPTH 500
#endif
#endif
int yydebug;
int yynerrs;
int yyerrflag;
int yychar;
short *yyssp;
YYSTYPE *yyvsp;
YYSTYPE yyval;
YYSTYPE yylval;
short yyss[YYSTACKSIZE];
YYSTYPE yyvs[YYSTACKSIZE];
#define yystacksize YYSTACKSIZE
#line 370 "graph.y"


yylex(void)
{
	extern int yylval;
	starflg = 0;
	while((*scanp != '%') && (*scanp != '\0'))
	  {
		ychar++;
		scanp++;
	  }
	if(*scanp++ == '\0')
		return(0);
	ychar++;
	*(scanp - 1) = 0;	/* To make previous string null terminated */
	if(*scanp == '*')
	  {
		(starflg)++;
		scanp++;
		ychar++;
	  }
	if(starflg)
		yylval = (int)(scanp + 1); /* pointer to string after token */
	else
		yylval = (int)argp;
	ychar++;
	return((int)*scanp++);
  }
yyerror(char *s)
{
	char *str;

	ychar -= 5;
	str = strbeg;
	fprintf(stderr,"\n%s\n:  ",s);
	fprintf(stderr,"error near underbar\n");
	while(str - strbeg < ychar)
		putc(*str++,stderr);
	fprintf(stderr,"_%s\n",scanp);
  }
#line 290 "y.tab.c"
#define YYABORT goto yyabort
#define YYACCEPT goto yyaccept
#define YYERROR goto yyerrlab
int
yyparse()
{
    register int yym, yyn, yystate;
#if YYDEBUG
    register char *yys;
    extern char *getenv();

    if (yys = getenv("YYDEBUG"))
    {
        yyn = *yys;
        if (yyn >= '0' && yyn <= '9')
            yydebug = yyn - '0';
    }
#endif

    yynerrs = 0;
    yyerrflag = 0;
    yychar = (-1);

    yyssp = yyss;
    yyvsp = yyvs;
    *yyssp = yystate = 0;

yyloop:
    if (yyn = yydefred[yystate]) goto yyreduce;
    if (yychar < 0)
    {
        if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("yydebug: state %d, reading %d (%s)\n", yystate,
                    yychar, yys);
        }
#endif
    }
    if ((yyn = yysindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
#if YYDEBUG
        if (yydebug)
            printf("yydebug: state %d, shifting to state %d\n",
                    yystate, yytable[yyn]);
#endif
        if (yyssp >= yyss + yystacksize - 1)
        {
            goto yyoverflow;
        }
        *++yyssp = yystate = yytable[yyn];
        *++yyvsp = yylval;
        yychar = (-1);
        if (yyerrflag > 0)  --yyerrflag;
        goto yyloop;
    }
    if ((yyn = yyrindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
        yyn = yytable[yyn];
        goto yyreduce;
    }
    if (yyerrflag) goto yyinrecovery;
#ifdef lint
    goto yynewerror;
#endif
yynewerror:
    yyerror("syntax error");
#ifdef lint
    goto yyerrlab;
#endif
yyerrlab:
    ++yynerrs;
yyinrecovery:
    if (yyerrflag < 3)
    {
        yyerrflag = 3;
        for (;;)
        {
            if ((yyn = yysindex[*yyssp]) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
#if YYDEBUG
                if (yydebug)
                    printf("yydebug: state %d, error recovery shifting\
 to state %d\n", *yyssp, yytable[yyn]);
#endif
                if (yyssp >= yyss + yystacksize - 1)
                {
                    goto yyoverflow;
                }
                *++yyssp = yystate = yytable[yyn];
                *++yyvsp = yylval;
                goto yyloop;
            }
            else
            {
#if YYDEBUG
                if (yydebug)
                    printf("yydebug: error recovery discarding state %d\n",
                            *yyssp);
#endif
                if (yyssp <= yyss) goto yyabort;
                --yyssp;
                --yyvsp;
            }
        }
    }
    else
    {
        if (yychar == 0) goto yyabort;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("yydebug: state %d, error recovery discards token %d (%s)\n",
                    yystate, yychar, yys);
        }
#endif
        yychar = (-1);
        goto yyloop;
    }
yyreduce:
#if YYDEBUG
    if (yydebug)
        printf("yydebug: state %d, reducing by rule %d (%s)\n",
                yystate, yyn, yyrule[yyn]);
#endif
    yym = yylen[yyn];
    yyval = yyvsp[1-yym];
    switch (yyn)
    {
case 5:
#line 22 "graph.y"
{ i = j = 0;}
break;
case 14:
#line 35 "graph.y"
 {	
		nary[X]++;
		xyflg = X;
		_datptr = _xdata[i++] = (struct _data *)calloc(1,sizeof(struct _data));
		if(_datptr == 0)
			_feror("No space available: calloc");
		_datptr->flgs |= MINMAX;
		if(starflg)
			_datptr->flgs |= NODATA;
		else
			_datptr->dptr = (argp++)->dp;
		_axptr = &_ax[xyflg];
		}
break;
case 15:
#line 48 "graph.y"
 {	
		nary[X]++;
		xyflg = X;
		_datptr = _xdata[i++] = (struct _data *)calloc(1,sizeof(struct _data));
		if(_datptr == 0)
			_feror("No space available: calloc");
		if(starflg)
			_datptr->flgs |= NODATA;
		else
			_datptr->dptr = (argp++)->dp;
		_axptr = &_ax[xyflg];
		}
break;
case 16:
#line 60 "graph.y"
 {
		nary[Y]++;
		xyflg = Y;
		_datptr = _ydata[j++] = (struct _data *)calloc(1,sizeof(struct _data));
		if(_datptr == 0)
			_feror("No space available: calloc");
		_datptr->flgs |= MINMAX;
		if(starflg)
			_datptr->flgs |= NODATA;
		else
			_datptr->dptr = (argp++)->dp;
		_axptr = &_ax[xyflg];
		}
break;
case 17:
#line 73 "graph.y"
 {
		nary[Y]++;
		xyflg = Y;
		_datptr = _ydata[j++] = (struct _data *)calloc(1,sizeof(struct _data));
		if(_datptr == 0)
			_feror("No space available: calloc");
		if(starflg)
			_datptr->flgs |= NODATA;
		else
			_datptr->dptr = (argp++)->dp;
		_axptr = &_ax[xyflg];
		}
break;
case 21:
#line 91 "graph.y"
{
		if(first)
		  {
			if(xyflg != oxyflg)
			  {
				yyerror("Saxis: Non matching xy descriptor");
				exit();
			  }
		  }
		first = 1;
		oxyflg = xyflg;
		}
break;
case 22:
#line 103 "graph.y"
 {
		if(first)
		  {
			if(xyflg != oxyflg)
			  {
				yyerror("Saxis: Non matching xy descriptor");
				exit();
			  }
		  }
		first = 1;
		oxyflg = xyflg;
	  }
break;
case 26:
#line 120 "graph.y"
{	chrp = (char *)yyvsp[0];
		if(starflg)
		  {
			if(xyflg == X)
				charp = _axptr->lab = xlabbuf;
			else
				charp = _axptr->lab = ylabbuf;
			while((*chrp == ' ') || (*chrp == '\t'))
				chrp++;
			while((*chrp != '%') && (*chrp != '\0'))
				*charp++ = *chrp++;
			*charp = '\0';
		  }
		else
			_axptr->lab = (argp++)->cp;}
break;
case 27:
#line 135 "graph.y"
{	
		if(starflg)
			frag = atoi(yyvsp[0]);
		else
			frag = *(argp++)->ip;
		if((frag >= 0) && (frag <= 3))
			_axptr->flags |= frag;
		else
			printf("Bad Tic (%t) type %d\n",frag); }
break;
case 28:
#line 144 "graph.y"
{	
		if(starflg)
			frag = atoi(yyvsp[0]);
		else
			frag = *(argp++)->ip;
		if((frag >= 0) && (frag <= 3))
			_axptr->flags |= frag << 2;
		else
			printf("Bad Tic (%t) type %d\n",frag); }
break;
case 29:
#line 153 "graph.y"
{	
		if(starflg)
			frag = atoi(yyvsp[0]);
		else
			frag = *(argp++)->ip;
		if((frag >= 0) && (frag <= 7))
			_axptr->dflags |= frag;
		else
			printf("Bad size (%s) type %d\n",frag); }
break;
case 30:
#line 162 "graph.y"
{	
		if(starflg)
			frag = atoi(yyvsp[0]);
		else
			frag = *(argp++)->ip;
		if((frag >= 0) && (frag <= 7))
			_axptr->dflags |= frag << 3;
		else
			printf("Bad size (%S) type %d\n",frag); }
break;
case 31:
#line 171 "graph.y"
{	chrp = (char *)yyvsp[0];
		_axptr->flags |= NAME;
		if(starflg)
		  {
			if(xyflg == X)
				charp = _axptr->lab = xlabbuf;
			else
				charp = _axptr->lab = ylabbuf;
			while((*chrp == ' ') || (*chrp == '\t'))
				chrp++;
			while((*chrp != '%') && (*chrp != '\0'))
				*charp++ = *chrp++;
			*charp = '\0';
		  }
		else
			_axptr->lab = (argp++)->cp;}
break;
case 34:
#line 190 "graph.y"
 {
		if(starflg)
		  {
			if(xyflg == X)
				_axptr->y = atof(yyvsp[0]);	
			else
				_axptr->x = atof(yyvsp[0]);
		  }
		else
		  {
			if(xyflg == X)
				_axptr->y = *((double *)argp); /*argp->dv;*/
			else
				_axptr->x = *((double *)argp); /* argp->dv; */
			argp += 4;
		  }
		_axptr->flags |= SHIFT;
	  }
break;
case 35:
#line 208 "graph.y"
 {
		if(starflg)
		  {
			if(xyflg == X)
				_axptr->y = atof(yyvsp[0]);	
			else
				_axptr->x = atof(yyvsp[0]);
		  }
		else
		  {
			if(xyflg == X)
				_axptr->y = *((double *)argp); /*argp->dv; */
			else
				_axptr->x = *((double *)argp); /*argp->dv; */
			argp += 4;
		  }
		_axptr->flags |= SHIFT1;
	  }
break;
case 45:
#line 243 "graph.y"
 {
		if(starflg)
		  {
			for(sp = (char *)yyvsp[0];*sp != '%';sp++)
				if(*sp == ' ')
					continue;
				else
					break;
			_datptr->symble = *sp;
		  }
		else
			_datptr->symble = *(argp++)->cp;
		}
break;
case 46:
#line 256 "graph.y"
 {
		if(starflg)
			_datptr->blubber = atoi(yyvsp[0]);
		else
			_datptr->blubber = *(argp++)->ip;
		}
break;
case 47:
#line 262 "graph.y"
{	chrp = (char *)yyvsp[0];
		if(starflg)
		  {
			charp = _datptr->labl = (char *)calloc(1,30);
			if(charp == 0)
				_feror("No space available: calloc");
			while((*chrp == ' ') || (*chrp == '\t'))
				chrp++;
			while((*chrp != '%') && (*chrp != '\0'))
				*charp++ = *chrp++;
			*charp = '\0';
		  }
		else
			_datptr->labl = (argp++)->cp;}
break;
case 48:
#line 276 "graph.y"
 {
		if(starflg)
		  {
		_datptr->ddash = (float *)calloc(1,16);
		if(_datptr->ddash == 0)
			_feror("No space available: calloc");
		if(sscanf(yyvsp[0],"%f%f%f%f",_datptr->ddash,_datptr->ddash+1,
		  _datptr->ddash + 2,_datptr->ddash + 3) != 4)
		  {
		   fprintf(stderr,"Not enough arguments for 'B' command\n");	
		   fprintf(stderr,"%f %f %f %f\n",*_datptr->ddash
			,*(_datptr->ddash+1),
			*(_datptr->ddash + 2),*(_datptr->ddash + 3));
			_datptr->ddash = 0;
		  }
		  }
		else
			_datptr->ddash = (argp++)->fp;
		}
break;
case 49:
#line 295 "graph.y"
{					/* pen changes */
		if(starflg)
			frag = atoi(yyvsp[0]);
		else
			frag = *(argp++)->ip;
		if((frag >= 0) && (frag <= 3))
			_datptr->flgs |= frag << 4; /* shift 3 left 4 for 060 */
	    }
break;
case 50:
#line 303 "graph.y"
{					/* char size for point label */
		if(starflg)
			frag = atoi(yyvsp[0]);
		else
			frag = *(argp++)->ip;
		if((frag >= 0) && (frag <= 7))
			_datptr->flgs |= frag; 
	    }
break;
case 51:
#line 311 "graph.y"
{
		if(starflg)
			_datptr->npts = atoi(yyvsp[0]);
		else
			_datptr->npts = *(argp++)->ip; }
break;
case 52:
#line 318 "graph.y"
{_datptr->flgs |= INTEGER;}
break;
case 53:
#line 319 "graph.y"
{_datptr->flgs |= INTEGER;}
break;
case 54:
#line 320 "graph.y"
{_datptr->flgs |= FLOAT;}
break;
case 55:
#line 321 "graph.y"
{_datptr->flgs |= DOUBLE;}
break;
case 56:
#line 322 "graph.y"
{_datptr->flgs |= UNSIGNED;}
break;
case 57:
#line 323 "graph.y"
{_datptr->flgs |= SHORT;}
break;
case 58:
#line 324 "graph.y"
{_datptr->flgs |= LONG;}
break;
case 59:
#line 325 "graph.y"
{_datptr->flgs |= LONG;}
break;
case 60:
#line 327 "graph.y"
{
		_axptr->flags |= MINSET;
		if(starflg)
			min[xyflg] = atof(yyvsp[0]);
		else
		  {
			min[xyflg] = *(double *)argp;  /* argp->dv; */
			argp += 4;
		  }
	     }
break;
case 61:
#line 338 "graph.y"
{	_axptr->flags |= MAXSET;
		if(starflg)
			max[xyflg] = atof(yyvsp[0]);
		else
		  {
			max[xyflg] = *(double *)argp;  /* argp->dv; */
			argp += 4;
		  }
	   }
break;
case 62:
#line 347 "graph.y"
{
		if(starflg)
			frag = atoi(yyvsp[0]);
		else
			frag = *(argp++)->ip;
		if((frag >= 0) && (frag <= 3))
			_axptr->flags |= frag << 5;
		else
			printf("Bad Gridtype (%%G) type %o\n",frag);
	   }
break;
case 63:
#line 357 "graph.y"
{
		_axptr->flags |= LOGAXIS;
	    }
break;
#line 823 "y.tab.c"
    }
    yyssp -= yym;
    yystate = *yyssp;
    yyvsp -= yym;
    yym = yylhs[yyn];
    if (yystate == 0 && yym == 0)
    {
#if YYDEBUG
        if (yydebug)
            printf("yydebug: after reduction, shifting from state 0 to\
 state %d\n", YYFINAL);
#endif
        yystate = YYFINAL;
        *++yyssp = YYFINAL;
        *++yyvsp = yyval;
        if (yychar < 0)
        {
            if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
            if (yydebug)
            {
                yys = 0;
                if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
                if (!yys) yys = "illegal-symbol";
                printf("yydebug: state %d, reading %d (%s)\n",
                        YYFINAL, yychar, yys);
            }
#endif
        }
        if (yychar == 0) goto yyaccept;
        goto yyloop;
    }
    if ((yyn = yygindex[yym]) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn];
    else
        yystate = yydgoto[yym];
#if YYDEBUG
    if (yydebug)
        printf("yydebug: after reduction, shifting from state %d \
to state %d\n", *yyssp, yystate);
#endif
    if (yyssp >= yyss + yystacksize - 1)
    {
        goto yyoverflow;
    }
    *++yyssp = yystate;
    *++yyvsp = yyval;
    goto yyloop;
yyoverflow:
    yyerror("yacc stack overflow");
yyabort:
    return (1);
yyaccept:
    return (0);
}
