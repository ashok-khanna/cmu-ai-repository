/* Routines to ext} "libP" library */


#include <stdio.h>
#include "stdplt.h"

/****************************************/

cpen(int num)
{
   static int oldpen = -1;

 if (num == oldpen) return;
 else oldpen = num;
 putc ('c' | _CMD,stdplt);
 putc (num,stdplt);
 fflush(stdplt);
}

/****************************************/

hidinit(void)
{
 putc ('i' | _CMD,stdplt);
 fflush(stdplt);
}

/****************************************/

hidstart(void)
{
 putc ('h' | _CMD,stdplt);
 fflush(stdplt);
}


/****************************************/

hidstop(void)
{
 putc ('j' | _CMD,stdplt);
 fflush(stdplt);
}

/****************************************/

ctext(void)
{
 putc ('a' | _CMD,stdplt);
 putc ('p' | _CMD,stdplt);
 fflush(stdplt);
}

/****************************************/

cgraphics(void)
{
 putc ('g' | _CMD,stdplt);
 putc ('p' | _CMD,stdplt);
 fflush(stdplt);
}

/****************************************/
