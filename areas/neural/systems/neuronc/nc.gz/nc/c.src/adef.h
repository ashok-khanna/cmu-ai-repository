
/* ADEF: GLOBAL DEFINITIONS */

/*  Latest Mod	17-Jan-84		R.G.Smith	*/

/* the pseudo types */

typedef char TEXT;
typedef int BOOL, VOID;

/*	macros
 */

#ifndef abs
#define abs(x)		((x) < 0 ? -(x) : (x))
#endif

#ifndef _CTYPE_H


/* #define isalpha(c)	(islower(c) || isupper(c)) */
/* #define isdigit(c)	('0' <= (c) && (c) <= '9') */
/* #define islower(c)	('a' <= (c) && (c) <= 'z') */
/* #define isupper(c)	('A' <= (c) && (c) <= 'Z') */
/* */
#define iswhite(c)	((c) > 0 && ((c) <= ' ' || 0177 <= (c)))
#define tolower(c)	(isupper(c) ? ((c) + ('a' - 'A')) : (c))
#define toupper(c)	(islower(c) ? ((c) - ('a' - 'A')) : (c))
#endif

#define isnum(c)  (isdigit(c)||(c)=='+'||(c)=='-'||(c)=='.'||(c)=='e'||(c)=='E')

#define max(x, y)	(((x) < (y)) ? (y) : (x))
#define min(x, y)	(((x) < (y)) ? (x) : (y))
#define limit(v,M,m) ((M>m)?max(min((v),(M)),(m)):max(min((v),(m)),(M)))

/*	Convenience definitions
*/

#define T 1
#define F 0

/* Logical operators - not bitwise!! */

/* #define not !	/* */
/* #define and &&	/* */
/* #define or  ||	/* */

/* #define begin { */
/* #define end } */
/* #define NULL 0 */

