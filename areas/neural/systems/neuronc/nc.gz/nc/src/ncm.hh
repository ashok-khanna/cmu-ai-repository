int     ncerror = 0;	/* set by warning() for plotinit() */
#define isfname(c)      (isalnum(c) || (c) == '.' || (c) == '/') 
int c;  /* global for use by warning() */
int getcx(FILE *fil)
 ch = getc(fil);
 if (ch != EOF) ch &= ~0x80;		/* mask out upper bit for word-star */
 if (ch == '\n') {
return (ch);
int getcy(FILE *fil)
 ch = getc(fil);
 if (ch != EOF) ch &= ~0x80;		/* mask out upper bit for word-star */
 if (ch == '\n') {
return (ch);
ungetcx(int ch, FILE *fil)
  if(charpos>0) charpos--;
  ungetc(ch,fil);
int pushfil (void)
  ifil = (char *)*pc++;
  if ((tfin=fopen(ifil,"r")) == NULL)
      fprintf(stderr,"%s: can't open %s\n", progname, ifil);
      return (0); 
  if (numfiles < FSTACKSIZ)
      fstack[numfiles][1] = (FILE *)einfile;
      fstack[numfiles][2] = (FILE *)lineno;
      return (numfiles);
      fprintf (stderr,"%s: too many reentrant files\n",progname);
      return (0);
FILE *popfil (void)
   if (numfiles > 0)
       fclose (fin);            /* close old file */
       einfile = (char *)fstack[numfiles][1];
       lineno  =    (int)fstack[numfiles][2];
       return (fin=     (fstack[numfiles][0])); 
   else return (NULL);
int yylex(void)         /* interp */
        for (c=getcx(fin); c == ' ' || c == '\t'; c=getcx(fin))
        while (c == EOF) {
           if (popfil()!=NULL) {
        	for (c=getcx(fin); c == ' ' || c == '\t'; c=getcx(fin))
        if (c == '/') {                   /* comment */ 
          if ((ch = getcx(fin)) != '*') {
                ungetcx(ch,fin);
           for (ch=getcx(fin); ch != EOF; ch=getcx(fin))
             if (ch == '*')
                if ((ch = getcx(fin)) == '/') {
                   while ((c=getcx(fin)) == ' ' || c == '\t')
                   while (c == EOF)
                    if (popfil())
                        while ((c=getcx(fin)) == ' ' || c == '\t')
                   break;       /* out of for (ch=getcx ; ; ) */
        } while (c == '/' && (ungetcx(ch=getcx(fin),fin),ch=='*'));
        if (c=='.'||isdigit(c)) {           /* number */
                ungetcx(c, fin);	/* look for num with exponent: */
		c= *num++ =getcx(fin);
		if (c=='+'||c=='-')	{c= *num++ =getcx(fin);}
		while (isdigit(c))	{c= *num++ =getcx(fin);}
		if (c=='.')		{c= *num++ =getcx(fin);}
		while (isdigit(c))	{c= *num++ =getcx(fin);}
		if (c=='e'||c=='E')	{c= *num++ =getcx(fin);
		   if (c=='+'||c=='-')	{c= *num++ =getcx(fin);}
		   while (isdigit(c))	{c= *num++ =getcx(fin);}
		ungetcx(c,fin);
		*(--num) = 0;
                sscanf(numbuf,"%lf",&d);
                if ((s=lookup(numbuf)) == 0)
                   s = install(numbuf, NUMBER, d);
        if (fname) {
           if (c == '"') { /* quoted string */
                for (p = sbuf; (c=getcx(fin)) != '"'; p++) {
                        if (c == '\n' || c == EOF)
                                execerror("missing quote", "");
                        if (p >= sbuf + sizeof(sbuf) - 1) {
                                execerror ("string too long",sbuf);
                        *p = backslash(c);
                yylval.sym = install (sbuf,STRING,0);
           else if (isfname(c)) {
                        if (p >= sbuf + sizeof(sbuf) - 1) {
                                execerror("name too long", sbuf);
                        *p++ = backslash(c);
                } while ((c=getcx(fin)) != EOF && isfname(c));
                ungetcx(c,fin);
                if ((s=lookup(sbuf)) == 0)
                        s = install(sbuf,FNAME,LARGENUM);
        if (isalpha(c)) {
                        if (p >= sbuf + sizeof(sbuf) - 1) {
                                execerror("name too long", sbuf);
                } while ((c=getcx(fin)) != EOF && (isalnum(c) || c=='_'));
                ungetcx(c,fin);
                if ((s=lookup(sbuf)) == 0)
                        s = install(sbuf,UNDEF,LARGENUM);
                if (formal) {
                  if (s->type != UNDEF)             /* if formal param def */
                        s = install(sbuf,ARG,LARGENUM);
                  else if (s->type == UNDEF) s->type = ARG;
		else if (inlocal) {
                  if (s->type != UNDEF)             /* if local variable def */
                        s = install(sbuf,LOCALVAR,LARGENUM);
                  else if (s->type == UNDEF) s->type = LOCALVAR;
		if (indef) {
                    if      ((tsym=lookupnt(sbuf,ARG)) != 0)      s = tsym; 
		    else if ((tsym=lookupnt(sbuf,LOCALVAR)) != 0) s = tsym;
        if (c == '\'') { /* quoted char */
		c = getcx(fin);		/* get literal char */
		c = backslash(c);
                yylval.sym = install("", LITCHAR, (double)(int) c);
		c = getcx(fin);		/* move through end quote */
        if (c == '"') { /* quoted string */
                for (p = sbuf; (c=getcx(fin)) != '"'; p++) {
                        if (c == '\n' || c == EOF)
                                execerror("missing quote", "");
                        if (p >= sbuf + sizeof(sbuf) - 1) {
                                execerror ("string too long",sbuf);
                        *p = backslash(c);
                yylval.sym = install (sbuf,STRING,0);
        if (c == '`') { /* command line */
                char *p, *emalloc();
                for (p = sbuf; (c=getcy(fin)) != '\n' && c != '`'; p++) {
                        if (c == EOF) break;
                        if (p >= sbuf + sizeof(sbuf) - 1) {
                                execerror ("command line too long",sbuf);
                        *p = backslash(c);
                p = emalloc(strlen(sbuf)+1);
                yylval.sym = (Symbol *)p;
                strcpy(p, sbuf);
        switch (c) {
        case '+':       return follow('=', ADDEQ, follow ('+', INCROP, '+'));
			 			  follow ('>', PFIELD, '-')));
	case '*':       return follow('=', MULEQ, '*');
        case '/':       return follow('=', DIVEQ, '/');
        case '>':       return follow('=', GE, GT);
        case '<':       return follow('=', LE, LT);
        case '=':       return follow('=', EQ, '=');
        case '!':       return follow('=', NE, NOT);
        case '|':       return follow('|', OR, BITOR);
        case '&':       return follow('&', AND, BITAND);
backslash(int c)    /* get next char with \'s interpreted */
        char *strchr(const char *, int); /* `index()' in some systems */
        if (c != '\\')
        c = getcx(fin);
        if (islower(c) && strchr(transtab, c))
                return strchr(transtab, c)[1];
follow(int expect, int ifyes, int ifno)     /* look ahead for >=, etc. */
        c = getcx(fin);
        if (c == expect)
        ungetcx(c, fin);
defnonly(char *s)     /* warn if illegal definition */
        if (!indef)
                execerror(s, "used outside definition");
yyerror(char *s)      /* report compile-time error */
        warning (s, (char *)0);
execerror(char *s, char *t) /* recover from run-time error */
        warning(s, t);
/*        fseek(fin, 0L, 2);              /* flush rest of file */
        longjmp(ncbegin, 0);
fpecatch(void)      /* floating point exceptions */
        execerror ("floating point exception", (char *)0);
buserr()
   execerror("bus error",0);
onintr(void)
        signal (SIGINT, onintr);
        if (++iflag >= 1) exit(0);
/*      longjmp(ncbegin,0);               /* */
run(void)   /* execute until EOF */
	initcode();
        if (istat != (int)SIG_IGN) signal (SIGINT, onintr);
        if (setjmp(ncbegin)>0) {
/*  	   bexit();		/* */
/*	   exit (1);
        signal(SIGFPE, fpecatch);
/*        signal(SIGBUS, buserr);
        signal(SIGSEGV, buserr);
        for (resetcode(); yyparse() && !iflag; resetcode()) {
                execute(progbase);
warning(char *s, char *t)   /* print warning message */
	disperr();				/* display error message */
        if (strcmp(einfile,"stdin") == 0) {
          for (i=0; i<charpos-1; i++)           /* print arrow under error */
            fprintf (stderr," ");
          fprintf (stderr,"^\n");
        fprintf(stderr, "%s: %s", progname, s); /* print lineno with error */
        if (t)
                fprintf(stderr, " %s", t);
        if (einfile)
                fprintf(stderr," in %s", einfile);
        fprintf (stderr, " near line %d char %d.\n", lineno,charpos);
/*        while (c != '\n' && c != EOF)
                c = getcy(fin);  /* flush rest of input line */
