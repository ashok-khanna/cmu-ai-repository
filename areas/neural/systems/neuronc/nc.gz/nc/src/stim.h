/* file stim.h in program stim.c */

#define NODENUM 200

typedef struct  RECNOD {
	short int recnm1;
	short int recnm2;
	short int recnm3;
	float xpos;
	float ypos;
	float actual;
	float curval;
	float wavel;
	float stim;
	float backgnd;
	struct RECNOD *next;
	} recnod;

/* #define CONVSIZE 256  	/* for 16 bit machines */
#define CONVSIZE 512		/* for large machines */
