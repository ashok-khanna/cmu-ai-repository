

#include <stdio.h>
#include <math.h>

main  (int argc, int argv)
{
double a;

a = pow (2.,3.);
fprintf (stderr,"pow(2,3) = %g\n",a);
}


