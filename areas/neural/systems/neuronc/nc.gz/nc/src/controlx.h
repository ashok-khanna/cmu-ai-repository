/* control.h */

int nrecrd;
int nstim;
int silent;
int vidmode;
int disp;
int prmap;
int stim_elem;

/* default values for some constants */

double vk;
double vna;
double vcl;
double dcap;
double ddia;
double dlen;
double dri;			/* axial resistance */
double drg;			/* gap junction resistance */
double drm;			/* membrane resistance */
double dsfa;			/* synaptic filters 1 */
double dfta;			/* synaptic time constant */
double dsfb;			/* synaptic filters 2 */
double dftb;			/* synaptic time constant */
double dscn;			/* number of channel sites */
double dscd;			/* duration of channel events */
double dsvn;			/* number of vesicle release sites */
double dvsz;			/* size of vesicles released */
double dscq;			/* channel quantal size */
double dsvq;			/* vesicle quantal size */
double dst;			/* synaptic threshold */
double dsc;			/* synaptic curve */
double dmaxsyn;			/* maximum cond for synapse */
double dskd;			/* half-max saturation gain */
double dse;			/* synaptic gain exponent */
double dsi;			/* synaptic input gain */
double dsei;			/* synaptic input gain for expon */
double dmaxrod;			/* maximum cond for rod           */
double dmaxcon;			/* maximum cond for cone          */
double dnadens;			/* density for Na chan (S/cm2)  */
double dkdens;			/* density for K chan (S/cm2)  */
double dcadens;			/* density for Ca chan (S/cm2)  */
double dmaxna;			/* maximum cond for Na channel */ 
double dnathr;			/* activation voltage for Na channel */ 
double dmaxk;			/* maximum cond for K channel */ 
double dkthr;			/* activation voltage for K channel */ 
float dnataum;			/* act. tau for Na channel (must be float)*/ 
float dnatauh;			/* inactivation tau for Na channel */ 
float dktau;			/* activation tau for K channel */ 
float dcatau;			/* Time const for Ca c3 conductance */
float dkcatau;			/* Time const for KCa conductance */
double dcao;			/* external calcium concentration */
double dcai;			/* internal calcium concentration */
double dcapkm;			/* 1/2 sat. conc. for Ca pump */
double dcavmax;			/* Vmax for Ca pump */
double dcaekm;			/* 1/2 sat. conc. for Ca exch */
double dcakex;			/* Rate for Na/Ca exchanger */
double dcabnd;			/* Ratio of bound to free calcium */
double dmaxca;			/* maximum cond for Ca channel */ 
double dcathr;			/* Voltage activation threshold for ca chan */
double dd1;			/* default d1 for KCa channel    */ 
double dd2;			/* default d2 for KCa channel    */ 
double dk1;			/* default k1 for KCa channel    */ 
double dk2;			/* default k2 for KCa channel    */ 

double complam;
double lamcrit;
double xtime;
double timinc;
double tempcel;
double ktemp;
double endexp;
double psplen;
double recrd;
double ploti;
double plmax;
double plmin;
double rate;
double stloc;
double crit;
double relax;
double relincr;
double ncversion;
double synaptau;
int    debug;
int    debugz;
int    poisfl;
int    scatter;
int    plsep;
int    multyax;
int    rightYax;
int    dashfl;
int    euler;
int    implicit;
int    stimelem;
long int rseed;
extern long int drseed;

