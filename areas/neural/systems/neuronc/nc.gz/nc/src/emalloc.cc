/* segment emalloc in program nc */

#include <sys/types.h>

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>
char *malloc(unsigned int size);

#ifdef __cplusplus
}
#endif

char *emalloc(unsigned int n)	/* check return from malloc() */
	           
{
	char *p, *tp;
	int i;
	long int x;

	p = malloc((size_t)n);	

	if (p==NULL) fprintf(stderr,"emalloc: out of memory.\n");
	else {
	  for (tp=p,i=0; i<n; i++)		/* zero the allocated space */
	   	*tp++ = 0; 
	}
	 return p;

}

/*------------------------------------------------*/

/* #define MODSIZ 10000

static char modarr[MODSIZ]=0;
static char *modfree = 0;
*/

/* char *emalloc(len)
   unsigned len;

/* return pointer to newly allocated space.
   Works like malloc() and emalloc().
*/

/*	version which doesn't use library version of malloc()  */
/*
{
     char *tfree;

    if (modfree+len >= modarr+MODSIZ) {
	fprintf (stderr,"out of space\n");
        return (NULL);
    }
   else {
    tfree = modfree;
    modfree += len;
    return tfree;
   }
}
*/

/*------------------------------------------------*/
	
