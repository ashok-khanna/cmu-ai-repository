
main(void)
{
   double rate,dur;
   double pois(double rate, double dur),poidev(double xm);
   int i;

rate = 1e4; dur = 1e-2;

for (i=0; i<100; i++) {
   printf ("pois %g pois2 %g\n",pois(rate,dur),poidev(rate*dur));
}

}


double poidev (double xm)
{
   static double sq,alxm,g,oldm= -1.0;
   double em,t,y;
   double drand48(void), exp(double);

  if (xm < 1000) {
     if (xm != oldm) {
  	oldm = xm;
	g = exp(-xm);
     }
     em = -1;
     t = 1.0;
     do {
       em += 1.0;
       t *= drand48();
     } while (t > g);
  }
return em;
}

double pois(double rate, double dur)
                   

/* return the number of photons received in 
   time "dur", at intensity "rate".
   Normally, "rate" for photons is calibrated in terms of
   quanta / um2 / sec.
*/

{
  static double elaptim,randnum;
  double drand48(void),log(double);
  double count;

#ifdef DEBUG
  if (debug & 1) fprintf (stderr,"pois\n");
#endif

  if (rate < 1e-30) return (0);

  for (elaptim=0,count=0; elaptim<dur; )
   {
    elaptim -= log(drand48()) / rate;               /* */
    if (elaptim < dur) count++;
   }
 return (count);
}

/*------------------------------------*/

