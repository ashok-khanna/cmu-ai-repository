/* module gprim.h in program nc */

/* graphics primitives for video and text modes */

void gtext(char *s);
void gmove (double x, double y);
void gdraw (double x, double y);
void grmove (double x, double y);
void grdraw (double x, double y);
void gpen (int x);
void gcrotate (double x);
void grotate (double x);
void gorigin(double x, double y);
void gframe (char *s);
void grmframe (char *s);
void gcwidth (double x);
void gsize (double x);
void gdash (int x);
void gcirc (double rad, int fill);
void grect (double x1, double y1, double x2, double y2, double x3, double y3,
		double x4, double y4, int fill);
void gpurge (void);
void gctext (void);
void gcgraphics (void);
void ghinit (void);
void ghstart (void);
void ghend (void);
