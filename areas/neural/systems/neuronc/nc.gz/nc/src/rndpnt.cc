
#include "stdplt.h"

main(void)
{
  double x,y,drand();
  int i;


  for (i=0; i<20000; i++) {

    x = drand();
    y = drand();
 
   move (x,y);
   draw (x,y);
  }  


}

