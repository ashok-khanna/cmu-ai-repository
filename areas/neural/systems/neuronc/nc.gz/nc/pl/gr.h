/*  Routines in graphics library libP.a */

void cgraphics(void);
void ctext(void);
void _move(double x, double y);
void _draw(double x, double y);
void _drcirc(double rad, int fill);
void _drrect(double x1, double y1, double x2, double y2, double x3, double y3,
		double x4, double y4, int fill);
void _rotate(double x);
void crotate(double x);
void *_scale(double x, double y);
struct _frame *frame(char *f);
void rmframe(char *f);
void _origin(double x, double y);
double cwidth(double width, char *fname);
void purge(void);
void textf(...);
void cpen (int color);
void dash(int pattern);
void hidinit(void);
void hidstart(void);
void hidstop(void);
