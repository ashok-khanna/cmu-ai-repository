

#include <stdio.h>
#include "../h/mdef.h"


main ()

{

vidstart();

scr_xy(10,10);
printf ("Hello");

getchar();
vidret();
}

