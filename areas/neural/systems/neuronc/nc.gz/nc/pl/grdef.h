/*	Standard video screen definitions:	*/

#define STDSIZ 16384
#define GXCENT  (STDSIZ/2)
#define GYCENT  (STDSIZ/2)

