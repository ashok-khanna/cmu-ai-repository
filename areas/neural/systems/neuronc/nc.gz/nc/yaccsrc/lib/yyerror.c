#include <stdio.h>

yyerror(s) char *s;{
fpprint(stderr, "%s\n",s);
	}

