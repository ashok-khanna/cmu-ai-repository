main(){
	return(yyparse());
	}

