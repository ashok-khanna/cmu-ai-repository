# common block with error checking and convergence parameters

      common / errcom / egoal, gwgoal, errdel, oklvl, nfreq, nokdel

# goal for RMS error
#      real egoal			
# goal for RMS g / RMS w
#      real gwgoal			
# Required reduction factor in RMS error every nfreq iterations
#      real errdel
# Activation level for accepting output as okay
#      real oklvl
# frequency for checking convergence, printing progress
#      integer nfreq		
# Required improvement in number OK every nfreq iterations
#      integer nokdel
