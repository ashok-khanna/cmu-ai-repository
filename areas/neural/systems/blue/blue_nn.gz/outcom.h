# common block with output items

      common /outcom/ vinp, vout, target, idpat, idres, codes, trans, chtrans

# input values
      real vinp(MAXPAT, MAXINS+1)      
# output values
      real vout(MAXPAT, MAXOUT)            
# target output values
      real target(MAXPAT, MAXOUT)            
# identifier for each stored pattern (1, 2, 3, ..., nout)
      integer idpat(MAXPAT)            
# result for each stored pattern (-1 means unknown)
      integer idres(MAXPAT)            
# code string for identifier index ('A', '3v12', 'funny character', etc.)
      character*32 codes(MAXOUT)
# character translation of identifier index ('A', '3v12', etc.)
      character*3 chtrans(MAXOUT)
# Do we need to print a translation table?
      logical trans
