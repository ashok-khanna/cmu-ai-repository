# common block containing network parameters

      common /netcom/ eta, alpha, npats, ninp, nhid, nout, ncalls, num1,
			num2, numw

# the usual BP parameters: learning rate, momentum factor
      real eta, alpha
# number of input patterns being used
      integer npats
# number of input nodes
      integer ninp
# number of hidden nodes
      integer nhid
# number of output nodes
      integer nout
# number of calls to subroutine forward
      integer ncalls
# number of weights on first and second layers
      integer num1, num2
# total number of weights = num1 + num2
      integer numw
