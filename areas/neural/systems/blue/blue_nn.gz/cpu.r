# cpu.r 14-Feb-92 15:38

########################################################################
# cputim.r 14-Feb-92 15:38
#		UNIX version of CPU time routine
#		Returns CPU time in seconds minus its argument.
########################################################################
real function cputim ( time )
	real*4 time
real tmp(2)
external etime
 
call etime( tmp )
cputim = tmp(1) + tmp(2) - time

return
end

