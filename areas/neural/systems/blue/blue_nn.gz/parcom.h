# common block containing parameters

      common /parcom/ hscale, wfactor, hfactor, e1, e2

