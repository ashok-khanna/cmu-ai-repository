# common block with file numbers

      common /filcom/ fpspec, fppat, fpgetw, fpputw, fpout, fprun, fpstd

# input:  file names and run parameters
      integer fpspec		
# input:  input patterns
      integer fppat
# input:  initial weights
      integer fpgetw		
# output: final weights
      integer fpputw		
# output: activation levels
      integer fpout	
# output: summary and error messages
      integer fprun		
# output: standard output
      integer fpstd

