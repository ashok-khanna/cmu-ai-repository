# Standard parameters. NOTE: These must be the same everywhere.

# maximum allowed input patterns
      parameter (MAXPAT = 3500)
# maximum allowed input nodes
      parameter (MAXINS = 32)
# maximum allowed hidden nodes
      parameter (MAXHID = 48)
# maximum allowed output nodes
      parameter (MAXOUT = 26)

      parameter (MAXWSIZE = MAXHID*(MAXINS+1) + MAXOUT*(MAXHID+1))

      parameter(MAXHIST = 20)
