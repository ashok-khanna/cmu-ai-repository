/**********************  definitions  *************************************/
   
#include <stdio.h>
#include <math.h>

#ifdef hp
#include <starbase.c.h>
#endif

#define snapshotend 999999999
#define maxdistance 999999999.9

#define maxnx 100            /* maximum network size is nx*ny units */
#define maxny 100
#define maxsnaps 100         /* maximum number of snapshots */
#define maxphase 100
#define maxvectors 100        /* maximum number of input vectors */
#define maxlabell 30          /* maximum length of lables */
#define maxdim 100             /* maximum dimension of input vectors */

#define frame_color 1          /* 1 = green in color, black in bw */
#define bestvector_color 63    /* 63= white in color, black in bw */
#define bestunit_color 1       
#define clear_color 0          /* 0 = black in color, white in bw */
#define labelsize=(hght/4.0)
#define expansion=0.5

/* in t_, nc_, and alpha_: [-1] = initial value */
int nx, ny, t, t_array[maxphase+1], *t_, tend, seed,
  nc_array[maxphase+1], *nc_,
  fildes, besti, bestj, nextsnapshot, snapshots[maxsnaps],
  displaying, continuing, testing, cmapsize, startt, phase,
  nvectors, dim;
int shuffletable[maxvectors];
float alpha_array[maxphase+1], *alpha_, hght, wdth, low, left, high, right;
float colors[256][3];
char simufile[100], vectorfile[100], labelfile[100], 
     cmapfile[100], sb_outdev[100], sb_outdriver[100];
FILE *fp, *fp2;

struct inputvectors {
  char label[maxlabell+1];
  float comp[maxdim];
} vectors[maxvectors];

struct unitdata {
  int   labelcount;
  int   labels[maxvectors+1];
  float bestvalue;
  float value;
  float comp[maxdim];
} units[maxnx][maxny];

/* random number functions */
double drand48();
void srand48();
long lrand48();
