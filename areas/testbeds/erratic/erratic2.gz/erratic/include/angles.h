/* 
 * Definitions of some common angular operations
 */

#define add-ang(a,b) norm-angle(a+b)
#define add2-ang(a,b) norm2-angle(a+b)
#define sub-ang(a,b) norm-angle(a-b)
#define sub2-ang(a,b) norm2-angle(a-b)

