/*
 * top-level communication routines for the TCP/socket server
 *
 */


startup_flakey_server(type, host) /* start up tcp connection */
     char *host;
{
  shutdown_flakey_server();
  printf("\nStarting connection...");
  switch(type)
    {
    case TCP:
      open_tcp_line(host);
      break;
    case UNIX:
      open_unix_line(host);
      break;
    }
  sync_client();		/* synchronize with client */
  printf("succeeded!");
}

