/* #########################################
 * ptrs.c
 *
 * ptr buffer manipulation routines
 *
 *#########################################
 */

#include <malloc.h>
#include <stdio.h>
#include "structures.h"
#include "parameters.h"

/* add a pointer; returns 0 if succesful, -1 if not */

int push_ptr(p, plist)
     char *p; 
     ptrlist *plist;
{
  char **pp;
  if (plist->n >= plist->max)	/* full, error */
    { printf("\n  *** Plist full: push_ptr"); fflush(stdout);
      return(-1);
    }
  else
    {
      pp = ((plist->arr) + (plist->n)++); /* ptr array entry */
      *pp = p;
      return(0);
    }
}


int push_aptr(p, plist)
     char *p; 
     buclist *plist;
{
  if (plist->n >= plist->max)	/* full, error */
    { printf("\n  *** Plist full: push_aptr"); fflush(stdout);
      return(-1);
    }
  else
    {
      *((plist->segs) + (plist->n)++) = p;
      return(0);
    }
}


