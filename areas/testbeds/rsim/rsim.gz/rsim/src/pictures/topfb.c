/* makes a white border around image */

#include<stdio.h>
#include<malloc.h>
#include<sys/types.h>
#include<string.h>
#include<stdlib.h>

void main(argc,argv)
int argc;
char **argv;
{
	int x,y,xx,yy;
	FILE *out,*in;
	int count;
	int i,j,di,dj;
	char *r,*g,*b;
	int *dr,*dg,*db,*n;

	if(argc!=7) {
		printf("Usage: topf x y xx yy <infile> <outfile>\n");
		exit(0);
	}	
	x=atoi(argv[1]);
	y=atoi(argv[2]);
	xx=atoi(argv[3]);
	yy=atoi(argv[4]);
	in=fopen(argv[5],"r");
	out=fopen(argv[6],"w");

	r=malloc(x*y);
	g=malloc(x*y);
	b=malloc(x*y);
    dr=(int *)calloc(xx*yy,sizeof(int));
    dg=(int *)calloc(xx*yy,sizeof(int));
    db=(int *)calloc(xx*yy,sizeof(int));
	n=(int *)calloc(xx*yy,sizeof(int));

	count=0;
	for(j=0;j<y;j++) {
		for(i=0;i<x;i++) {
			r[i+x*j]=fgetc(in);
			g[i+x*j]=fgetc(in);
			b[i+x*j]=fgetc(in);
		}
	}
	fclose(in);

	for(j=0;j<y;j++) {
		for(i=0;i<x;i++) {
			di=(i*xx)/x;
			dj=(j*yy)/y;
			dr[di+xx*dj]+=(int)r[i+x*j];
			dg[di+xx*dj]+=(int)g[i+x*j];
			db[di+xx*dj]+=(int)b[i+x*j];
			n[di+xx*dj]++;
		}
	}
	for(i=0;i<xx;i++) {
		n[i]=1;
		dr[i]=255;	
		dg[i]=255;
		db[i]=255;
		n[i+xx*(yy-1)]=1;
		dr[i+xx*(yy-1)]=255;
		
	for(j=0;j<yy;j++) {
		for(i=0;i<xx;i++) {
			dr[i+xx*j]/=n[i+xx*j];
			dg[i+xx*j]/=n[i+xx*j];
			db[i+xx*j]/=n[i+xx*j];
			fprintf(out,"%ld ",dr[i+xx*j]+256*dg[i+xx*j]+65536*db[i+xx*j]);
			count++;
			if((count%5)==0) fprintf(out,"\n");
		}
	}
	fclose(out);
}
