int main()
{
	init_links();
	return 0;
}
