/*
 * High joint velocity and acceleration.
 */
#define FAST_DQ		20.0
#define FAST_DDQ	20.0

/*
 * Standard joint velocity and acceleration.
 */
#define SLOW_DQ		3.0
#define SLOW_DDQ	1.0

#undef DEF_EXTERN
#endif
