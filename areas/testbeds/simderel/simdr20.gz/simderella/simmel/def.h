/**************************************************************************/
/* def.h                                                        /\/\      */
/*                                                              \  /      */
/*                                                              /  \      */
/* Author: P. Patrick van der Smagt                          _  \/\/  _   */
/*         University of Amsterdam                          | |      | |  */
/*         Dept. of Computer Systems                        | | /\/\ | |  */
/*         Amsterdam                                        | | \  / | |  */
/*         THE NETHERLANDS                                  | | /  \ | |  */
/*         smagt@fwi.uva.nl                                 | | \/\/ | |  */
/*                                                          | \______/ |  */
/* This software has been written with financial             \________/   */
/* support of the Dutch Foundation for Neural Networks                    */
/* and is therefore owned by the mentioned foundation.          /\/\      */
/*                                                              \  /      */
/*                                                              /  \      */
/*                                                              \/\/      */
/**************************************************************************/
#ifndef _def_h
#define _def_h

#include "config.h"

#include "matrix.h"

#ifndef DEF_EXTERN
#	define DEF_EXTERN extern
#endif


/*
 * The distance between the camera's CCD and the finger tips of
 * OSCAR is approximately 7cm.  Change this value also in
 * the bemmel robotfile and in the neural network def.h file.
 */
#define CCD_FINGER_DISTANCE     7


#undef DEF_EXTERN
#endif
