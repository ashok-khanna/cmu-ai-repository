/**************************************************************************/
/* io.h --- almost identical to a version by F. J. Jungen       /\/\      */
/*                                                              \  /      */
/*                                                              /  \      */
/* Author: P. Patrick van der Smagt                          _  \/\/  _   */
/*         University of Amsterdam                          | |      | |  */
/*         Dept. of Computer Systems                        | | /\/\ | |  */
/*         Amsterdam                                        | | \  / | |  */
/*         THE NETHERLANDS                                  | | /  \ | |  */
/*         smagt@fwi.uva.nl                                 | | \/\/ | |  */
/*                                                          | \______/ |  */
/* This software has been written with financial             \________/   */
/* support of the Dutch Foundation for Neural Networks                    */
/* and is therefore owned by the mentioned foundation.          /\/\      */
/*                                                              \  /      */
/*                                                              /  \      */
/*                                                              \/\/      */
/**************************************************************************/

#ifndef _io_h
#define _io_h

#include "config.h"


#define		NR_DH_PARAMS		4
#define		MAX_NR_LINKS		20

#define		NO_VAR			(-1)
#define		DH_THETA		0
#define		DH_D			1
#define		DH_A			2
#define		DH_ALFA			3

#define		VARIABLE		"*"


int get_variable(int link);
REAL get_param(int link, int par);
void read_definition(char filename[]);
void substitute(REAL buffer[]);
void print_robot(void);

#endif
