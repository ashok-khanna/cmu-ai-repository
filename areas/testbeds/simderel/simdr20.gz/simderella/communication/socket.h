/**************************************************************************/
/* socket.h - socket setup definition file                      /\/\      */
/*                                                              \  /      */
/*                                                              /  \      */
/* Author: P. Patrick van der Smagt                          _  \/\/  _   */
/*         University of Amsterdam                          | |      | |  */
/*         Dept. of Computer Systems                        | | /\/\ | |  */
/*         Amsterdam                                        | | \  / | |  */
/*         THE NETHERLANDS                                  | | /  \ | |  */
/*         smagt@fwi.uva.nl                                 | | \/\/ | |  */
/*                                                          | \______/ |  */
/* This software has been written with financial             \________/   */
/* support of the Dutch Foundation for Neural Networks                    */
/* and is therefore owned by the mentioned foundation.          /\/\      */
/*                                                              \  /      */
/*                                                              /  \      */
/*                                                              \/\/      */
/**************************************************************************/

#include "config.h"

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/errno.h>
#include <netinet/in.h>
#include <netdb.h>


int setup_client_socket(int socket_address, int *sock, char *host_name, int wait);
int setup_server_socket(int socket_address, int *sock, int n_clients);


#define ERROR		(-1)

#ifdef SYSV
#	define bzero(s, n)	memset(s, 0, n)
#	define bcopy(s1, s2, n)	memcpy(s2, s1, n)
#endif
