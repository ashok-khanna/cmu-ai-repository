/**************************************************************************/
/* matrices.h                                                   /\/\      */
/*                                                              \  /      */
/*                                                              /  \      */
/* Author: A. Jansen                                         _  \/\/  _   */
/*         University of Amsterdam                          | |      | |  */
/*         Dept. of Computer Systems                        | | /\/\ | |  */
/*         Amsterdam                                        | | \  / | |  */
/*         THE NETHERLANDS                                  | | /  \ | |  */
/*         ajansen@fwi.uva.nl                               | | \/\/ | |  */
/*                                                          | \______/ |  */
/*                                                           \________/   */
/*                                                                        */
/*                                                              /\/\      */
/*                                                              \  /      */
/*                                                              /  \      */
/*                                                              \/\/      */
/**************************************************************************/
#ifndef _matrices_h
#define _matrices_h

#include "config.h"

REAL *alloc_vector(void);
REAL **alloc_matrix(void);
void delete_vector(REAL *vp);
void delete_matrix(REAL **mp);
void mm_prod(REAL **m1, REAL **m2, REAL **m);
void mv_prod(REAL **m, REAL *v1, REAL *v);
void cp_matrix(REAL **m, REAL **cm);
void invert_h_matrix(REAL **m, REAL **im);

#endif
