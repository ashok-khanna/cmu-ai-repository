/*************************************************************************
*  PDSS (PIMOS Development Support System)  Version 2.52		 *
*  (C) Copyright 1988,1989,1990,1992.					 *
*  Institute for New Generation Computer Technology (ICOT), Japan.	 *
*  Read "../COPYRIGHT" for detailed information.			 *
**************************************************************************

  $B$3$N%U%!%$%k$K;XDj$5$l$?L>A0$N%^%/%m$rDj5A$9$k$H!"E}7W>pJs$r=87W$9$k0Y$N(B
$B%W%m!<%V$r=hM}7O$KA^F~$9$k;v$,$G$-$^$9!#%W%m!<%V$K$O!"ICC10L!"%j%@%/%7%g%s(B
$BC10L!"(BKL1B$BL?NaC10L$G>pJs$r<}=8$9$k$b$N$,$"$j$^$9!#DL>o$O3F%^%/%m$K>pJs<}=8(B
$B$N0Y$K<B9T$9$Y$-=hM}(B($B4X?t8F$S=P$7Ey(B)$B$rDj5A$7$^$9!#$J$*!">pJs<}=8$N0Y$K4X?t(B
$B$rDj5A$7$?>l9g$K$O(B Makefile $B$rJQ99$7$F!"$=$N4X?t$r%j%s%/$9$kI,MW$,$"$j$^$9!#(B

(1) STATISTICS_START
    $B=hM}7O$,<B9T$r;O$a$?;~$K<B9T$9$Y$-=hM}!#(B

(2) STATISTICS_END
    $B=hM}7O$,<B9T$r=*N;$7$?;~$K<B9T$9$Y$-=hM}!#(B

(3) STATISTICS_SECOND
    1$BIC$4$H$K<B9T$9$k=hM}!#%"%i!<%`%/%m%C%/$K$h$k3d$j9~$_$rMxMQ$7$F$$$^$9!#(B

(4) STATISTICS_REDUCTION
    1$B%j%@%/%7%g%s$4$H$K<B9T$9$k=hM}!#(B

(5) STATISTICS_INSTRUCTION
    KL1B$B$N(B1$BL?Na$4$H$K<B9T$9$k=hM}!#(B

*************************************************************************/

/**
$B0J2<$O%5%s%W%k$G!"0lDj;~4V(B(10$BIC(B)$B$4$H$K0l3g(BGC$B$r5/F0$7$F!"%R!<%W$N;HMQ>u67$r(B
$BD4$Y$k$b$N$G$9!#(B
**
EXTERN int __count;
#define STATISTICS_START  __count=0
#define STATISTICS_SECOND if(++__count==10){ SetHeapGcFlag(); __count=0; }
**/
