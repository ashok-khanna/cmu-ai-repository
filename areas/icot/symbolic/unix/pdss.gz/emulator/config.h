/*************************************************************************
*  PDSS (PIMOS Development Support System)  Version 2.52		 *
*  (C) Copyright 1988,1989,1990,1992.					 *
*  Institute for New Generation Computer Technology (ICOT), Japan.	 *
*  Read "../COPYRIGHT" for detailed information.			 *
*************************************************************************/


/*************************************************************************
PDSS$B$N0Y$N%G%#%l%/%H%j(B/$B%U%!%$%k4D6-$N;XDj!#(B
>> PDSS_LIBDIR: PDSS$B$,N)$A>e$,$k;~$K!"%i%s%?%$%`%i%$%V%i%j$rC5$7$K$$$/%G%#(B
      $B%l%/%H%j$N%Q%9L>!#DL>o$O(BPDSS$B$N%H%C%W%l%Y%k$N%G%#%l%/%H%j$HF1$8!#(B
>> PDSS_SUPDIR: $BN)$A>e$2MQ%U%!%$%k(B STARTUP $B$,CV$$$F$"$k%G%#%l%/%H%j$N%Q%9L>!#(B
      STARTUP $B%U%!%$%k$K$O!"N)$A>e$2;~$KFI$_9~$`$Y$-(B KL1 $B%b%8%e!<%k$N%U%!(B
      $B%$%kL>$H!":G=i$N%4!<%kL>$,5-=R$7$F$"$k!#(B
>> PDSS_OBJECT_FILE: $B%(%_%e%l!<%?K\BN$N%Q%9L>!#(BNative Code Module $B$rF0E*$K(B
      $B%j%s%/$9$k;~$K;H$o$l$k!#(B ($B$7$+$7!"8=:_(B Native Code Generator $B$O(B
      $B%5%]!<%H$5$l$F$$$J$$!#(B)
Configuration of the directory/file environment for PDSS.
>> PDSS_LIBDIR: A path name of the directory which PDSS search for runtime
      libraries at initial startup time. Normally, this is equal to the
      PDSS toplevel directory.
>> PDSS_SUPDIR: A path name of the directory which contains STARTUP file.
      STARTUP file describes path names (relative path from PDSS_LIBDIR)
      of the runtime library which are read at initial startup time, and
      initial goal name.
>> PDSS_OBJECT_FILE: A path name of the PDSS byte-code interpreter executable
      object. It is uesd by dynamic native code module linker.
      (But, native code generator is not supported yet.)
*************************************************************************/
#define PDSS_LIBDIR      "/usr/local/src/pdss"
#define PDSS_SUPDIR      "/usr/local/src/pdss/emulator"
#define PDSS_OBJECT_FILE "/usr/local/src/pdss/emulator/pdss"


/*************************************************************************
PDSS $B$N%3!<%I$N7A<0$K4X$9$k;XDj!#(B
>> KLB_PACKED_CODE: $B$3$l$,(B YES $B$N>l9g$K$O!"(BKL1-B $B$N%3!<%I$O5M$a9~$^$l$?(B
      $B>uBV$GJ];}$5$l$k!#$3$N>l9g!"@0?tEy$NJ#?t%P%$%H$N%G!<%?$b%o!<%I$N6-3&(B
      $B$K9g$o$;$:$K5M$a$F=q$-9~$^$l$k!#(B)  $B%^%7%s$N(B CPU $B$,(B RISC $B%?%$%W$N>l9g(B
      $B$K$O!"$3$l$r(B NO $B$K$7$F$*$/I,MW$,$"$k!#(B
>> KLB_4BYTE_REL_ADDR: $B$3$l$,(B YES $B$N>l9g$K$O!"(BKL1-B $B$N%3!<%I$K$*$1$kAjBP(B
      $B%"%I%l%9$O(B 4byte $B$GI=8=$5$l$k!#$=$&$G$J$1$l$P(B 2byte $B$GI=8=$5$l$k!#(B
Configuration for instruction trace.
>> KLB_PACKED_CODE: If this switch's value is `YES', KL1-B instruction
      code (byte-code) is filled in continuously. In this case, multiple
      byte data (e.g. integer) is written not in word alignment. If your
      machine uses RISC type CPU, you must define this switch `NO'.
>> KLB_4BYTE_REL_ADDR: If this switch's value is `YES', PDSS use 4 byte
      relative address instead of 2 byte one.
*************************************************************************/
#define KLB_PACKED_CODE    NO
#define KLB_4BYTE_REL_ADDR YES


/*************************************************************************
PDSS $B$,;HMQ$9$k%a%b%j$N%G%U%)%k%H$NBg$-$5$N;XDj!#(B
>> HEAP_SIZE: $B%R!<%WNN0h$NBg$-$5!#C10L$O%?%0IU$-%o!<%I(B(8 $B%P%$%H(B)$B!#(B
      PDSS $B$G$O%3%T!<J}<0$N(B GC $B$r9T$&$N$G!"$3$3$G$OA4%R!<%WNN0h$NH>J,$N(B
      $BBg$-$5$r;XDj$9$k!#(B
>> CODE_SIZE: $B%3!<%INN0h$NBg$-$5!#C10L$O%P%$%H!#$3$3$G;XDj$9$k$N$O%3!<%IA4BN(B
      $B$NBg$-$5$G$"$k!#(BPDSS $B$ON)$A>e$2;~$K!"%i%s%?%$%`%i%$%V%i%j$rFI$_9~$`(B
      $B$?$a$K@hF,$+$i;HMQ$7!"$=$N;D$j$rH>J,$KJ,$1$F%f!<%6!<MQ$H$7$F;HMQ$9$k!#(B
Configuration for the default memory size.
>> HEAP_SIZE: Size of head area. This specifies the number of tagged-words
      (8 byte) in the HALF of heap area, since PDSS use copying GC.
>> CODE_AREA: Size of code area. This specifies the number of bytes in the
      whole code area. PDSS loads runtime libraries into top of the code
      area at initial startup time, then PDSS divide code area into 2
      parts and use divided one for user codes.
*************************************************************************/
#define HEAP_SIZE  200000
#define CODE_SIZE 1000000


/*************************************************************************
MRB-GC $B$K4X$9$k@_Dj!#(B
>> MRBGC_SWITCH: $B$3$l$,(B YES $B$N>l9g$K(B MRB $B$K$h$k<B;~4V(B GC $B$r9T$&!#(B
>> MRBGC_COLLECT_VALUE_DEPTH: Collect Value $BL?Na$G2s<}$9$k9=B$BN$N?<$5!#(B
>> MRBGC_DEREF_TYPE: $B%G%l%U;~$N2s<}$N%?%$%W!#(B
       0 --> $B;2>H%Q%9$G0lC6(B MRB=ON $B$K$J$C$?@h$N2s<}$r9T$o$J$$!#(B
       1 --> $B;2>H%Q%9$G0lC6(B MRB=ON $B$K$J$C$?@h$N2s<}$b9T$&!#(B
>> MRBGC_FREE_LIST_TYPE: $B%a%b%j:FMxMQ$N0Y$N%U%j!<%j%9%H$N<oN`!#(B
       0 --> 1W,2W,3W, ... ,7W,8W,16W,32W $B$N(B10$B<oN`$rMQ0U$9$k!#(B
       1 --> 1W,2W,4W,8W,16W,32W,64W,128W $B$N(B8$B<oN`$rMQ0U$9$k!#(B
>> MRBGC_STATISTICS: MRB-GC$B$K4X$9$kE}7W>pJs$N=87W!#(B
       0 --> $B=87W$O9T$o$J$$!#(B
       1 --> $B%U%j!<%j%9%H$N;HMQ>u67$N=87W$r9T$&!#(B
       2 --> 1 + $BL?Na$4$H$N2s<}>u67$N=87W$b9T$&!#(B
Configuration for MRB-GC.
>> MRBGC_SWITCH: If this switch's value is `YES', PDSS collect garbage
      incrementally by the MRB scheme in real time.
>> MRBGC_COLLECT_VALUE_DEPTH: The maximum depth of the nested data structure
      which collected by collect_value instruction.
>> MRBGC_DEREF_TYPE: The switch of garbage collection in dereference routine.
      0 -> If MRB-ON pointer is found in reference path, PDSS don't try
           to collect garbage in the forward path of this pointer.
      1 -> In spite of MRB-ON pointer is found in reference path, PDSS
           try to collect garbage in the forward path of this pointer.
>> MRBGC_FREE_LIST_TYPE: The variation of free lists.
      0 -> Use 10 kinds (1W,2W,3W,...,7W,8W,16W and 32W) of free lists.
      1 -> Use 8 kinds (1W,2W,4W,8W,16W,32W,64W and 128W) of free lists.
>> MRBGC_STATISTICS: The switch of statistics of MRB-GC.
      0 -> PDSS don't collect statistics information of MRB-GC.
      1 -> PDSS collect statistics information about free list only.
      2 -> PDSS collect statistics information about free list and
           incremental garbage collecting instructions.
*************************************************************************/
#define MRBGC_SWITCH		  YES
#define MRBGC_COLLECT_VALUE_DEPTH 100
#define MRBGC_DEREF_TYPE	    1
#define MRBGC_FREE_LIST_TYPE	    0
#define MRBGC_STATISTICS	    0


/*************************************************************************
MRB $B$rMxMQ$7$?%G%C%I%m%C%/(B($BL58BBT$A(B)$B$N(B eager detection $B$K4X$9$k@_Dj!#(B
>> EAGER_DEADLOCK_DETECTION:
      $B$3$l$,(B YES $B$N>l9g$K$O(B eager detection $B$r9T$J$&!#(B
Configuration for eager detection of deadlock (perpetual suspension).
>> EAGER_DEADLOCK_DETECTION:
      If this switch's value is `YES', PDSS deetect deadlock eagerly.
*************************************************************************/
#define EAGER_DEADLOCK_DETECTION YES


/*************************************************************************
Ready Goal Pool $B$K4X$9$k@_Dj!#(B
>> TWO_WAY_READY_GOAL_POOL: $B$3$l$,(B YES $B$N>l9g$K$O!"@hF,$H:G8e$N(B2$B$D$NF~8}$r(B
      $B;}$C$?(B Ready Goal Pool $B$r;HMQ$9$k!#B($A!"%9%?%C%/$H%-%e!<$NN>J}$K(B
      $B;H$($k$N$G!"$3$N;~$K$O!"%4!<%k$N%9%1%8%e!<%j%s%0$r(B Breadth First
      $B$KJQ99$9$k;v$b$G$-$k!#(BNO $B$N>l9g$K$O!"%9%?%C%/J}<0$N$_$K$J$k!#(B
Configuration for ready goal pool.
>> TWO_WAY_READY_GOAL_POOL: If this switch's value is `YES', PDSS use ready
      goal pool with two entry point: top and last. In this case, ready
      goal pool can be used as stack or queue, and user can select depth
      first or breadth first scheduling. If it's value is `NO', reday goal
      pool is stack and scheduling is depth first only.
*************************************************************************/
#define TWO_WAY_READY_GOAL_POOL YES


/*************************************************************************
$B%3%T!<(BGC $B;~$K0[>o;vBV$K$J$C$?;~$N=hM}$K4X$9$k@_Dj!#(B
>> GC_SWAP_GOALS_WHEN_PANIC: $B$3$l$,(B YES $B$N>l9g$K$O!"%3%T!<(B GC $B$G%R!<%WNN0h(B
      $B$,$"$^$j2s<}$G$-$J$+$C$?;~$K!"%4!<%k!&%9%?%C%/$N(B highest $B%W%i%$%*%j%F%#(B
      $B$NCf$N%4!<%k$N=gHV$rF~$lBX$($k!#$3$l$K$h$j!"<B9T=g=x$,JQ$o$k$N$G(B
      $B%R!<%W$,2s<}$G$-$k$h$&$K$J$k2DG=@-$,$"$k!#(B
>> GC_ABORT_TASK_WHEN_PANIC: $B$3$l$,(B YES $B$N>l9g$K$O!"%3%T!<(B GC $B$G%R!<%WNN0h(B
      $B$,$[$H$s$I2s<}$G$-$J$+$C$?(B(GC$BD>8e$J$N$K(BGC$BMW5a%U%i%0$,N)$C$F$$$k(B)$B;~$K!"(B
      $B%f!<%6!<$N%?%9%/$r%"%\!<%H$9$k!#$3$l$K$h$j!"(BPDSS$BA4BN$,0[>o=*N;$9$k(B
      $B$N$rKI$0!#(B
Configuration for emergency measures of copying GC.
>> GC_SWAP_GOALS_WHEN_PANIC: If this switch's value is `YES', PDSS swap
      goals in ready goal pool when copying GC get only small gain.
      By this goal swapping, the sequence of goal execution is changed and
      some data on heap may be consumed and collected.
>> GC_ABORT_TASK_WHEN_PANIC: If this switch's value is `YES', PDSS abort
      user task when copying GC get little gain. By this abortion, many
      heap uesd by user task are released and whole PDSS may not abort.
*************************************************************************/
#define GC_SWAP_GOALS_WHEN_PANIC YES
#define GC_ABORT_TASK_WHEN_PANIC YES


/*************************************************************************
$B%"%H%`%F!<%V%k$K4X$9$k@_Dj!#(B
>> MAX_ATOMS: PDSS $B$G;HMQ$G$-$k%"%H%`$N?t!#(B
Configuration for atom table.
>> MAX_ATOMS: Maximum number of atoms.
*************************************************************************/
#define MAX_ATOMS 20000


/*************************************************************************
$B@0?t1i;;$K4X$9$k@_Dj!#(B
>> IGNORE_INTEGER_OVERFLOW: $B$3$NCM$,(B YES $B$J$i$P!"AH9~=R8l$K$*$1$k@0?t1i;;(B
      $B$N%*!<%P!<%U%m!<$rL5;k$9$k!#(B
>> IGNORE_INTEGER_OVERFLOW: If this value is `YES', PDSS ignores integer
      overflow in builtin predicates.
*************************************************************************/
#define IGNORE_INTEGER_OVERFLOW NO


/*************************************************************************
$B%Q%C%7%V%f%K%U%#%1!<%7%g%s$K4X$9$k@_Dj!#(B
>> PASSIVE_UNIFY_DEPTH: $B$3$NCM$O(B Passive Unification (wait_value, diff)
      $B$G9=B$BNF1;N$rHf3S$9$k?<$5$r;XDj$9$k!#$3$N?<$5$^$GD4$Y$F$b@.8y$,3NDj(B
      $B$7$J$$>l9g$K$O<:GT$H8+Pv$9!#(B
Configuration for passive unification.
>> PASSIVE_UNIFY_DEPTH: This is the maximum depth of the nested structures
      which compare in passive unification (wait_value, diff). If PDSS
      can't confirm the result of unification while PDSS compare until
      this depth, PDSS regards the unification as failure.
*************************************************************************/
#define PASSIVE_UNIFY_DEPTH 100


/*************************************************************************
$B%3%s%=!<%k=PNO$K4X$9$k@_Dj!#(B
>> PRINT_LENGTH, PRINT_DEPTH: $B%3%s%=!<%k$X$N%?!<%`=PNO$K$*$1$k!"D9$5$H?<$5(B
      $B$N@)8B$N=i4|CM!#$3$l$r1[$($kItJ,$O(B "..." $B$G=PNO$9$k!#(B 
Configuration for console outputs.
>> PRINT_LENGTH, PRINT_DEPTH: These are initial maximum length and depth
      of structure which can be displayed in the console. PDSS print the
      part over this limitation link "...".
*************************************************************************/
#define PRINT_LENGTH 12
#define PRINT_DEPTH  6


/*************************************************************************
$B%Q!<%6!<$K4X$9$k@_Dj!#(B
>> MAX_PRINTABLE_STRING_ATOM_LENGTH: $B%&%#%s%I%&(B/$B%U%!%$%kEy$K=PNO2DG=$JJ8;z(B
      $BNs(B/$B%"%H%`$ND9$5$N:GBgD9!#J8;zNs(B --> $B%"%H%`(B $B$NJQ49$b$3$N@)8B$r<u$1$k!#(B
Configuration for parser.
>> MAX_PRINTABLE_STRING_ATOM_LENGTH: The maximum length of atom/string
      which can be displayed into window/file.  This limitation is also
      used for atom-string conversion.
*************************************************************************/
#define MAX_PRINTABLE_STRING_ATOM_LENGTH 10000


/*************************************************************************
$BAH9~=R8l$N%5%9%Z%s%I$K4X$9$k@_Dj!#(B
>> COUNT_DCODE_REDUCTION: $B$3$NCM$,(B `YES' $B$J$i$P!"AH9~=R8l$,%5%9%Z%s%I$7!"(B
      $B%4!<%k(B(D-Code)$B$,%(%s%-%e!<$5$l$?;~$K!"$=$N%4!<%k$NJ,$N%j%@%/%7%g%s?t(B
      $B$rIaDL$N%4!<%k$HF1MM$K?t$($k!#(B
Configuration for builtin predicate suspension.
>> COUNT_DCODE_REDUCTION: If this switch's value is `YES', PDSS count
      reductions by D-code goals which are generated by builtin predicate
      suspension.
*************************************************************************/
#define COUNT_DCODE_REDUCTION NO


/*************************************************************************
$B%$%s%9%H%i%/%7%g%s%H%l!<%9$K4X$9$k@_Dj!#(B
>> INSTRUCTION_TRACE: $B$3$l$,(B YES $B$N>l9g$K$O!"(BKL1-B $B$N%$%s%9%H%i%/%7%g%s(B
      $BC10L$N%H%l!<%9$,2DG=$H$J$k!#(B
>> INSTRUCTION_COUNT: $B$3$l$,(B YES $B$N>l9g$K$O!"(BKL1-B $B$NL?Na<oN`$4$H$N<B9T(B
      $B2s?t$N=87W$r9T$&!#(B
>> INSTRUCTION_BRANCH_COUNT: $B$3$l$H(B INSTRUCTION_COUNT $B$,N>J}$H$b(B YES $B$N(B
      $B>l9g$K$O!"(BKL1-B $B$NL?Na<oN`$4$H$KJ,4t2s?t$N=87W$r9T$&!#(B
Configuration for instruction trace.
>> INSTRUCTION_TRACE: If this switch's value is `YES', PDSS can trace
      KL1-B instructions.
>> INSTRUCTION_COUNT: If this switch's value is `YES', PDSS counts the
      number of times each KL1-B instuction is executed.
>> INSTRUCTION_BRANCH_COUNT: If both this switch's value and
      INSTRUCTION_COUNT's value are `YES', PDSS counts the number of
      branches in each KL1-B instuction.
*************************************************************************/
#define INSTRUCTION_TRACE        NO
#define INSTRUCTION_COUNT        NO
#define INSTRUCTION_BRANCH_COUNT NO
