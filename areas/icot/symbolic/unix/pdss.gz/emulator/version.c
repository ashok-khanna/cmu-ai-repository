/*************************************************************************
*  PDSS (PIMOS Development Support System)  Version 2.52		 *
*  (C) Copyright 1988,1989,1990,1991,1992.				 *
*  Institute for New Generation Computer Technology (ICOT), Japan.	 *
*  Read "../COPYRIGHT" for detailed information.			 *
*************************************************************************/

#define VERSION "V2.52.21"

unsigned char  *version  = (unsigned char *)VERSION;
unsigned char  *makedate = (unsigned char *)MAKEDATE;
