/*********************************** xmenu.h *********************************/
/*                                                                           */
/*****************************************************************************/
/*                                                                           */
/*        Authors:  BeBe Ly - NASA/Johnson Space Center                      */
/*                  Daniel J. McCoy - University of Houston-Downtown         */
/*                                  & Loral Space Information Systems        */
/*                                                                           */
/*****************************************************************************/

String about_info[] =
  {
  "XCLIPS for CLIPS version 6.0",
  "",
  "Developed at NASA/Johnson Space Center",
  "             Software Technology Branch",
  "",
  "Developers:",
  "",
  "     XCLIPS:  BeBe Ly - NASA",
  "              Daniel McCoy - University of Houston-Downtown",
  "                           & Loral Space Information Systems",
  "",
  "     CLIPS:   Gary Riley - NASA",
  "              Brian Donnell - NASA",
  NULL,
  };
