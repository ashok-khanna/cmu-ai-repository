OBJS = agenda.o analysis.o argacces.o bload.o bmathfun.o bsave.o classcom.o \
 classexm.o classfun.o classinf.o classini.o classpsr.o clsltpsr.o commline.o \
 conscomp.o constrct.o constrnt.o crstrtgy.o cstrcbin.o cstrccom.o cstrcpsr.o \
 cstrnbin.o cstrnchk.o cstrncmp.o cstrnops.o cstrnpsr.o cstrnutl.o default.o \
 defins.o developr.o dffctbin.o dffctbsc.o dffctcmp.o dffctdef.o dffctpsr.o \
 dffnxbin.o dffnxcmp.o dffnxexe.o dffnxfun.o dffnxpsr.o dfinsbin.o dfinscmp.o \
 drive.o edbasic.o edmain.o edmisc.o edstruct.o edterm.o emathfun.o engine.o \
 evaluatn.o expressn.o exprnbin.o exprnops.o exprnpsr.o extnfunc.o factbin.o \
 factbld.o factcmp.o factcom.o factgen.o facthsh.o factlhs.o factmch.o \
 factmngr.o factprt.o factrete.o factrhs.o filecom.o filertr.o generate.o \
 genrcbin.o genrccmp.o genrccom.o genrcexe.o genrcfun.o genrcpsr.o globlbin.o \
 globlbsc.o globlcmp.o globlcom.o globldef.o globlpsr.o immthpsr.o incrrset.o \
 inherpsr.o inscom.o insfile.o insfun.o insmngr.o insmoddp.o insmult.o \
 inspsr.o insquery.o insqypsr.o iofun.o lgcldpnd.o main.o memory.o miscfun.o \
 modulbin.o modulbsc.o modulcmp.o moduldef.o modulpsr.o modulutl.o msgcom.o \
 msgfun.o msgpass.o msgpsr.o multifld.o multifun.o objbin.o objcmp.o \
 objrtbin.o objrtbld.o objrtcmp.o objrtfnx.o objrtgen.o objrtmch.o pattern.o \
 pprint.o prccode.o prcdrfun.o prcdrpsr.o prdctfun.o prntutil.o reorder.o \
 reteutil.o retract.o router.o rulebin.o rulebld.o rulebsc.o rulecmp.o \
 rulecom.o rulecstr.o ruledef.o ruledlt.o rulelhs.o rulepsr.o scanner.o \
 strngfun.o strngrtr.o symblbin.o symblcmp.o symbol.o sysdep.o textpro.o \
 tmpltbin.o tmpltbsc.o tmpltcmp.o tmpltcom.o tmpltdef.o tmpltfun.o \
 tmpltlhs.o tmpltpsr.o tmpltrhs.o utility.o watch.o

.c.o :
	cc -c $<

clips : $(OBJS)
	cc -o clips $(OBJS) -lm -ltermcap

agenda.o : agenda.c setup.h constant.h clipsmem.h sysdep.h router.h prntutil.h \
  moduldef.h symbol.h evaluatn.h expressn.h exprnops.h constrct.h scanner.h pprint.h \
  strngrtr.h reteutil.h match.h network.h ruledef.h constrnt.h factmngr.h pattern.h \
  reorder.h multifld.h tmpltdef.h cstrccom.h retract.h extnfunc.h argacces.h crstrtgy.h \
  agenda.h watch.h engine.h rulebsc.h 
analysis.o : analysis.c setup.h constant.h symbol.h clipsmem.h exprnpsr.h extnfunc.h \
  expressn.h exprnops.h scanner.h pprint.h reorder.h ruledef.h evaluatn.h constrct.h \
  moduldef.h constrnt.h factmngr.h pattern.h match.h network.h multifld.h tmpltdef.h \
  cstrccom.h generate.h router.h prntutil.h cstrnchk.h cstrnutl.h cstrnops.h rulecstr.h \
  analysis.h globldef.h 
argacces.o : argacces.c setup.h extnfunc.h symbol.h expressn.h exprnops.h router.h \
  prntutil.h moduldef.h evaluatn.h constant.h constrct.h scanner.h pprint.h cstrnchk.h \
  constrnt.h argacces.h 
bload.o : bload.c setup.h clipsmem.h exprnpsr.h extnfunc.h symbol.h expressn.h \
  exprnops.h scanner.h pprint.h argacces.h evaluatn.h constant.h router.h prntutil.h \
  moduldef.h constrct.h bsave.h cstrnbin.h constrnt.h utility.h bload.h exprnbin.h \
  sysdep.h symblbin.h 
bmathfun.o : bmathfun.c setup.h exprnpsr.h extnfunc.h symbol.h expressn.h exprnops.h \
  scanner.h pprint.h argacces.h evaluatn.h constant.h router.h prntutil.h moduldef.h \
  constrct.h bmathfun.h 
bsave.o : bsave.c setup.h clipsmem.h exprnpsr.h extnfunc.h symbol.h expressn.h \
  exprnops.h scanner.h pprint.h argacces.h evaluatn.h constant.h router.h prntutil.h \
  moduldef.h constrct.h cstrnbin.h constrnt.h symblbin.h bload.h exprnbin.h sysdep.h \
  bsave.h 
classcom.o : classcom.c setup.h bload.h exprnbin.h expressn.h exprnops.h symbol.h \
  sysdep.h symblbin.h argacces.h evaluatn.h constant.h classfun.h object.h constrct.h \
  moduldef.h scanner.h pprint.h constrnt.h multifld.h match.h network.h ruledef.h \
  factmngr.h pattern.h reorder.h tmpltdef.h cstrccom.h classini.h modulutl.h msgcom.h \
  router.h prntutil.h classcom.h 
classexm.o : classexm.c setup.h argacces.h expressn.h exprnops.h evaluatn.h \
  constant.h symbol.h classcom.h cstrccom.h moduldef.h constrct.h scanner.h pprint.h \
  object.h constrnt.h multifld.h match.h network.h ruledef.h factmngr.h pattern.h \
  reorder.h tmpltdef.h classfun.h classini.h insfun.h msgcom.h msgfun.h msgpass.h \
  router.h prntutil.h strngrtr.h classexm.h 
classfun.o : classfun.c setup.h bload.h exprnbin.h expressn.h exprnops.h symbol.h \
  sysdep.h symblbin.h classcom.h cstrccom.h moduldef.h evaluatn.h constant.h constrct.h \
  scanner.h pprint.h object.h constrnt.h multifld.h match.h network.h ruledef.h \
  factmngr.h pattern.h reorder.h tmpltdef.h classini.h clipsmem.h cstrcpsr.h inscom.h \
  insfun.h insmngr.h modulutl.h msgfun.h msgpass.h router.h prntutil.h utility.h \
  classfun.h 
classinf.o : classinf.c setup.h argacces.h expressn.h exprnops.h evaluatn.h \
  constant.h symbol.h classcom.h cstrccom.h moduldef.h constrct.h scanner.h pprint.h \
  object.h constrnt.h multifld.h match.h network.h ruledef.h factmngr.h pattern.h \
  reorder.h tmpltdef.h classexm.h classfun.h classini.h clipsmem.h insfun.h msgfun.h \
  msgpass.h prntutil.h classinf.h 
classini.o : classini.c setup.h classcom.h cstrccom.h moduldef.h symbol.h evaluatn.h \
  constant.h expressn.h exprnops.h constrct.h scanner.h pprint.h object.h constrnt.h \
  multifld.h match.h network.h ruledef.h factmngr.h pattern.h reorder.h tmpltdef.h \
  classexm.h classfun.h classinf.h classpsr.h clipsmem.h cstrcpsr.h extnfunc.h \
  inscom.h modulpsr.h modulutl.h msgcom.h watch.h defins.h insquery.h objbin.h \
  objcmp.h objrtbld.h classini.h 
classpsr.o : classpsr.c setup.h bload.h exprnbin.h expressn.h exprnops.h symbol.h \
  sysdep.h symblbin.h classcom.h cstrccom.h moduldef.h evaluatn.h constant.h constrct.h \
  scanner.h pprint.h object.h constrnt.h multifld.h match.h network.h ruledef.h \
  factmngr.h pattern.h reorder.h tmpltdef.h classfun.h clipsmem.h cstrcpsr.h inherpsr.h \
  modulpsr.h modulutl.h msgpsr.h clsltpsr.h router.h prntutil.h classpsr.h 
clsltpsr.o : clsltpsr.c setup.h classfun.h object.h constrct.h moduldef.h symbol.h \
  evaluatn.h constant.h expressn.h exprnops.h scanner.h pprint.h constrnt.h multifld.h \
  match.h network.h ruledef.h factmngr.h pattern.h reorder.h tmpltdef.h cstrccom.h \
  clipsmem.h cstrnchk.h cstrnpsr.h cstrnutl.h default.h insfun.h prntutil.h router.h \
  clsltpsr.h 
commline.o : commline.c setup.h constant.h commline.h symbol.h clipsmem.h scanner.h \
  pprint.h exprnpsr.h extnfunc.h expressn.h exprnops.h argacces.h evaluatn.h router.h \
  prntutil.h moduldef.h constrct.h strngrtr.h prcdrfun.h prcdrpsr.h constrnt.h \
  utility.h filecom.h cstrcpsr.h 
conscomp.o : conscomp.c setup.h symbol.h clipsmem.h constant.h exprnpsr.h extnfunc.h \
  expressn.h exprnops.h scanner.h pprint.h cstrccom.h moduldef.h evaluatn.h constrct.h \
  argacces.h cstrncmp.h constrnt.h router.h prntutil.h conscomp.h symblcmp.h utility.h \
  modulcmp.h dffnxcmp.h dffnxfun.h tmpltcmp.h globlcmp.h genrccmp.h genrcfun.h \
  object.h multifld.h match.h network.h ruledef.h factmngr.h pattern.h reorder.h \
  tmpltdef.h objcmp.h 
constrct.o : constrct.c setup.h constant.h clipsmem.h router.h prntutil.h moduldef.h \
  symbol.h evaluatn.h expressn.h exprnops.h constrct.h scanner.h pprint.h watch.h \
  prcdrfun.h prcdrpsr.h constrnt.h argacces.h exprnpsr.h extnfunc.h multifld.h \
  utility.h 
constrnt.o : constrnt.c setup.h constant.h clipsmem.h router.h prntutil.h moduldef.h \
  symbol.h evaluatn.h expressn.h exprnops.h constrct.h scanner.h pprint.h extnfunc.h \
  multifld.h constrnt.h argacces.h 
crstrtgy.o : crstrtgy.c setup.h constant.h reteutil.h evaluatn.h symbol.h expressn.h \
  exprnops.h match.h network.h ruledef.h constrct.h moduldef.h scanner.h pprint.h \
  constrnt.h factmngr.h pattern.h reorder.h multifld.h tmpltdef.h cstrccom.h argacces.h \
  agenda.h crstrtgy.h 
cstrcbin.o : cstrcbin.c setup.h bload.h exprnbin.h expressn.h exprnops.h symbol.h \
  sysdep.h symblbin.h bsave.h moduldef.h evaluatn.h constant.h constrct.h scanner.h \
  pprint.h cstrcbin.h 
cstrccom.o : cstrccom.c setup.h constant.h clipsmem.h moduldef.h symbol.h evaluatn.h \
  expressn.h exprnops.h constrct.h scanner.h pprint.h argacces.h multifld.h modulutl.h \
  router.h prntutil.h bload.h exprnbin.h sysdep.h symblbin.h cstrcpsr.h cstrccom.h 
cstrcpsr.o : cstrcpsr.c setup.h router.h prntutil.h moduldef.h symbol.h evaluatn.h \
  constant.h expressn.h exprnops.h constrct.h scanner.h pprint.h watch.h prcdrpsr.h \
  constrnt.h exprnpsr.h extnfunc.h modulutl.h cstrcpsr.h 
cstrnbin.o : cstrnbin.c setup.h constant.h clipsmem.h router.h prntutil.h moduldef.h \
  symbol.h evaluatn.h expressn.h exprnops.h constrct.h scanner.h pprint.h bload.h \
  exprnbin.h sysdep.h symblbin.h bsave.h cstrnbin.h constrnt.h 
cstrnchk.o : cstrnchk.c setup.h router.h prntutil.h moduldef.h symbol.h evaluatn.h \
  constant.h expressn.h exprnops.h constrct.h scanner.h pprint.h multifld.h extnfunc.h \
  cstrnutl.h constrnt.h cstrnchk.h 
cstrncmp.o : cstrncmp.c setup.h constant.h clipsmem.h router.h prntutil.h moduldef.h \
  symbol.h evaluatn.h expressn.h exprnops.h constrct.h scanner.h pprint.h conscomp.h \
  extnfunc.h symblcmp.h cstrncmp.h constrnt.h 
cstrnops.o : cstrnops.c setup.h constant.h clipsmem.h router.h prntutil.h moduldef.h \
  symbol.h evaluatn.h expressn.h exprnops.h constrct.h scanner.h pprint.h extnfunc.h \
  multifld.h constrnt.h cstrnchk.h cstrnutl.h cstrnops.h 
cstrnpsr.o : cstrnpsr.c setup.h constant.h clipsmem.h router.h prntutil.h moduldef.h \
  symbol.h evaluatn.h expressn.h exprnops.h constrct.h scanner.h pprint.h cstrnutl.h \
  constrnt.h cstrnpsr.h 
cstrnutl.o : cstrnutl.c setup.h constant.h clipsmem.h router.h prntutil.h moduldef.h \
  symbol.h evaluatn.h expressn.h exprnops.h constrct.h scanner.h pprint.h extnfunc.h \
  multifld.h argacces.h cstrnutl.h constrnt.h 
default.o : default.c setup.h constant.h constrnt.h evaluatn.h symbol.h expressn.h \
  exprnops.h cstrnchk.h multifld.h inscom.h object.h constrct.h moduldef.h scanner.h \
  pprint.h match.h network.h ruledef.h factmngr.h pattern.h reorder.h tmpltdef.h \
  cstrccom.h exprnpsr.h extnfunc.h router.h prntutil.h cstrnutl.h default.h 
defins.o : defins.c setup.h bload.h exprnbin.h expressn.h exprnops.h symbol.h \
  sysdep.h symblbin.h dfinsbin.h dfinscmp.h argacces.h evaluatn.h constant.h classcom.h \
  cstrccom.h moduldef.h constrct.h scanner.h pprint.h object.h constrnt.h multifld.h \
  match.h network.h ruledef.h factmngr.h pattern.h reorder.h tmpltdef.h classfun.h \
  clipsmem.h cstrcpsr.h extnfunc.h insfun.h inspsr.h modulpsr.h router.h prntutil.h \
  utility.h defins.h 
developr.o : developr.c setup.h router.h prntutil.h moduldef.h symbol.h evaluatn.h \
  constant.h expressn.h exprnops.h constrct.h scanner.h pprint.h argacces.h extnfunc.h \
  modulutl.h tmpltdef.h constrnt.h factmngr.h pattern.h match.h network.h ruledef.h \
  cstrccom.h reorder.h multifld.h factbld.h facthsh.h classcom.h object.h classfun.h \
  objrtmch.h developr.h 
dffctbin.o : dffctbin.c setup.h clipsmem.h dffctdef.h symbol.h expressn.h exprnops.h \
  evaluatn.h constant.h constrct.h moduldef.h scanner.h pprint.h cstrccom.h bload.h \
  exprnbin.h sysdep.h symblbin.h bsave.h dffctbin.h modulbin.h cstrcbin.h 
dffctbsc.o : dffctbsc.c setup.h argacces.h expressn.h exprnops.h evaluatn.h \
  constant.h symbol.h clipsmem.h scanner.h pprint.h router.h prntutil.h moduldef.h \
  constrct.h extnfunc.h cstrccom.h factrhs.h tmpltdef.h constrnt.h factmngr.h \
  pattern.h match.h network.h ruledef.h reorder.h multifld.h cstrcpsr.h dffctpsr.h \
  dffctdef.h dffctbin.h modulbin.h cstrcbin.h dffctcmp.h dffctbsc.h 
dffctcmp.o : dffctcmp.c setup.h conscomp.h extnfunc.h symbol.h expressn.h exprnops.h \
  symblcmp.h moduldef.h evaluatn.h constant.h constrct.h scanner.h pprint.h dffctdef.h \
  cstrccom.h dffctcmp.h 
dffctdef.o : dffctdef.c setup.h clipsmem.h dffctbin.h modulbin.h moduldef.h \
  symbol.h evaluatn.h constant.h expressn.h exprnops.h constrct.h scanner.h pprint.h \
  cstrcbin.h dffctpsr.h dffctcmp.h dffctbsc.h bload.h exprnbin.h sysdep.h symblbin.h \
  dffctdef.h cstrccom.h 
dffctpsr.o : dffctpsr.c setup.h clipsmem.h router.h prntutil.h moduldef.h symbol.h \
  evaluatn.h constant.h expressn.h exprnops.h constrct.h scanner.h pprint.h cstrcpsr.h \
  factrhs.h bload.h exprnbin.h sysdep.h symblbin.h dffctdef.h cstrccom.h dffctbsc.h \
  dffctpsr.h 
dffnxbin.o : dffnxbin.c setup.h bload.h exprnbin.h expressn.h exprnops.h symbol.h \
  sysdep.h symblbin.h bsave.h clipsmem.h cstrcbin.h constrct.h moduldef.h evaluatn.h \
  constant.h scanner.h pprint.h modulbin.h dffnxbin.h dffnxfun.h cstrccom.h 
dffnxcmp.o : dffnxcmp.c setup.h conscomp.h extnfunc.h symbol.h expressn.h exprnops.h \
  symblcmp.h moduldef.h evaluatn.h constant.h constrct.h scanner.h pprint.h dffnxcmp.h \
  dffnxfun.h cstrccom.h 
dffnxexe.o : dffnxexe.c setup.h constrct.h moduldef.h symbol.h evaluatn.h constant.h \
  expressn.h exprnops.h scanner.h pprint.h prcdrfun.h prccode.h router.h prntutil.h \
  utility.h watch.h dffnxexe.h dffnxfun.h cstrccom.h 
dffnxfun.o : dffnxfun.c setup.h bload.h exprnbin.h expressn.h exprnops.h symbol.h \
  sysdep.h symblbin.h dffnxbin.h dffnxfun.h cstrccom.h moduldef.h evaluatn.h constant.h \
  constrct.h scanner.h pprint.h dffnxcmp.h cstrcpsr.h dffnxpsr.h modulpsr.h extnfunc.h \
  dffnxexe.h watch.h argacces.h clipsmem.h router.h prntutil.h 
dffnxpsr.o : dffnxpsr.c setup.h bload.h exprnbin.h expressn.h exprnops.h symbol.h \
  sysdep.h symblbin.h genrccom.h constrct.h moduldef.h evaluatn.h constant.h scanner.h \
  pprint.h cstrccom.h genrcfun.h object.h constrnt.h multifld.h match.h network.h \
  ruledef.h factmngr.h pattern.h reorder.h tmpltdef.h clipsmem.h cstrcpsr.h dffnxfun.h \
  exprnpsr.h extnfunc.h prccode.h router.h prntutil.h dffnxpsr.h 
dfinsbin.o : dfinsbin.c setup.h bload.h exprnbin.h expressn.h exprnops.h symbol.h \
  sysdep.h symblbin.h bsave.h clipsmem.h cstrcbin.h constrct.h moduldef.h evaluatn.h \
  constant.h scanner.h pprint.h defins.h cstrccom.h object.h constrnt.h multifld.h \
  match.h network.h ruledef.h factmngr.h pattern.h reorder.h tmpltdef.h modulbin.h \
  dfinsbin.h 
dfinscmp.o : dfinscmp.c setup.h conscomp.h extnfunc.h symbol.h expressn.h exprnops.h \
  symblcmp.h moduldef.h evaluatn.h constant.h constrct.h scanner.h pprint.h defins.h \
  cstrccom.h object.h constrnt.h multifld.h match.h network.h ruledef.h factmngr.h \
  pattern.h reorder.h tmpltdef.h dfinscmp.h 
drive.o : drive.c setup.h constant.h clipsmem.h reteutil.h evaluatn.h symbol.h \
  expressn.h exprnops.h match.h network.h ruledef.h constrct.h moduldef.h scanner.h \
  pprint.h constrnt.h factmngr.h pattern.h reorder.h multifld.h tmpltdef.h cstrccom.h \
  prntutil.h router.h agenda.h retract.h lgcldpnd.h incrrset.h drive.h 
edbasic.o : edbasic.c setup.h ed.h argacces.h expressn.h exprnops.h evaluatn.h \
  constant.h symbol.h constrct.h moduldef.h scanner.h pprint.h clipsmem.h router.h \
  prntutil.h 
edmain.o : edmain.c setup.h ed.h argacces.h expressn.h exprnops.h evaluatn.h \
  constant.h symbol.h constrct.h moduldef.h scanner.h pprint.h clipsmem.h router.h \
  prntutil.h sysdep.h extnfunc.h 
edmisc.o : edmisc.c setup.h ed.h argacces.h expressn.h exprnops.h evaluatn.h \
  constant.h symbol.h constrct.h moduldef.h scanner.h pprint.h clipsmem.h router.h \
  prntutil.h cstrcpsr.h 
edstruct.o : edstruct.c setup.h ed.h argacces.h expressn.h exprnops.h evaluatn.h \
  constant.h symbol.h constrct.h moduldef.h scanner.h pprint.h clipsmem.h router.h \
  prntutil.h 
edterm.o : edterm.c setup.h ed.h argacces.h expressn.h exprnops.h evaluatn.h \
  constant.h symbol.h constrct.h moduldef.h scanner.h pprint.h clipsmem.h router.h \
  prntutil.h 
emathfun.o : emathfun.c setup.h argacces.h expressn.h exprnops.h evaluatn.h \
  constant.h symbol.h extnfunc.h router.h prntutil.h moduldef.h constrct.h scanner.h \
  pprint.h 
engine.o : engine.c setup.h constant.h clipsmem.h watch.h expressn.h exprnops.h \
  router.h prntutil.h moduldef.h symbol.h evaluatn.h constrct.h scanner.h pprint.h \
  argacces.h reteutil.h match.h network.h ruledef.h constrnt.h factmngr.h pattern.h \
  reorder.h multifld.h tmpltdef.h cstrccom.h utility.h retract.h ruledlt.h prccode.h \
  prcdrfun.h inscom.h object.h sysdep.h agenda.h engine.h 
evaluatn.o : evaluatn.c setup.h constant.h clipsmem.h router.h prntutil.h moduldef.h \
  symbol.h evaluatn.h expressn.h exprnops.h constrct.h scanner.h pprint.h extnfunc.h \
  prcdrfun.h multifld.h factmngr.h pattern.h match.h network.h ruledef.h constrnt.h \
  cstrccom.h reorder.h tmpltdef.h exprnpsr.h dffnxfun.h genrccom.h genrcfun.h \
  object.h 
expressn.o : expressn.c setup.h clipsmem.h router.h prntutil.h moduldef.h symbol.h \
  evaluatn.h constant.h expressn.h exprnops.h constrct.h scanner.h pprint.h extnfunc.h 
exprnbin.o : exprnbin.c setup.h clipsmem.h dffctdef.h symbol.h expressn.h exprnops.h \
  evaluatn.h constant.h constrct.h moduldef.h scanner.h pprint.h cstrccom.h extnfunc.h \
  bload.h exprnbin.h sysdep.h symblbin.h bsave.h genrcbin.h genrcfun.h object.h \
  constrnt.h multifld.h match.h network.h ruledef.h factmngr.h pattern.h reorder.h \
  tmpltdef.h dffnxbin.h dffnxfun.h tmpltbin.h cstrcbin.h modulbin.h globlbin.h \
  globldef.h objbin.h insfun.h inscom.h 
exprnops.o : exprnops.c setup.h clipsmem.h router.h prntutil.h moduldef.h symbol.h \
  evaluatn.h constant.h expressn.h exprnops.h constrct.h scanner.h pprint.h extnfunc.h \
  cstrnchk.h constrnt.h cstrnutl.h cstrnops.h 
exprnpsr.o : exprnpsr.c setup.h constant.h router.h prntutil.h moduldef.h symbol.h \
  evaluatn.h expressn.h exprnops.h constrct.h scanner.h pprint.h strngrtr.h clipsmem.h \
  argacces.h cstrnchk.h constrnt.h extnfunc.h exprnpsr.h modulutl.h genrccom.h \
  cstrccom.h genrcfun.h object.h multifld.h match.h network.h ruledef.h factmngr.h \
  pattern.h reorder.h tmpltdef.h dffnxfun.h 
extnfunc.o : extnfunc.c setup.h constant.h router.h prntutil.h moduldef.h symbol.h \
  evaluatn.h expressn.h exprnops.h constrct.h scanner.h pprint.h clipsmem.h extnfunc.h 
factbin.o : factbin.c setup.h clipsmem.h tmpltdef.h symbol.h expressn.h exprnops.h \
  evaluatn.h constant.h constrct.h moduldef.h scanner.h pprint.h constrnt.h factmngr.h \
  pattern.h match.h network.h ruledef.h cstrccom.h reorder.h multifld.h bload.h \
  exprnbin.h sysdep.h symblbin.h bsave.h rulebin.h modulbin.h cstrcbin.h factbin.h \
  factbld.h 
factbld.o : factbld.c setup.h clipsmem.h reteutil.h evaluatn.h constant.h symbol.h \
  expressn.h exprnops.h match.h network.h ruledef.h constrct.h moduldef.h scanner.h \
  pprint.h constrnt.h factmngr.h pattern.h reorder.h multifld.h tmpltdef.h cstrccom.h \
  router.h prntutil.h factcmp.h factmch.h factbld.h factgen.h factlhs.h argacces.h \
  modulutl.h 
factcmp.o : factcmp.c setup.h factbld.h pattern.h evaluatn.h constant.h symbol.h \
  expressn.h exprnops.h scanner.h pprint.h match.h network.h ruledef.h constrct.h \
  moduldef.h constrnt.h factmngr.h multifld.h tmpltdef.h cstrccom.h reorder.h \
  conscomp.h extnfunc.h symblcmp.h factcmp.h 
factcom.o : factcom.c setup.h clipsmem.h exprnpsr.h extnfunc.h symbol.h expressn.h \
  exprnops.h scanner.h pprint.h factmngr.h pattern.h evaluatn.h constant.h match.h \
  network.h ruledef.h constrct.h moduldef.h constrnt.h cstrccom.h reorder.h multifld.h \
  tmpltdef.h argacces.h router.h prntutil.h factrhs.h factmch.h factbld.h tmpltpsr.h \
  facthsh.h modulutl.h tmpltfun.h bload.h exprnbin.h sysdep.h symblbin.h factcom.h 
factgen.o : factgen.c setup.h constant.h clipsmem.h router.h prntutil.h moduldef.h \
  symbol.h evaluatn.h expressn.h exprnops.h constrct.h scanner.h pprint.h exprnpsr.h \
  extnfunc.h network.h match.h ruledef.h constrnt.h factmngr.h pattern.h reorder.h \
  multifld.h tmpltdef.h cstrccom.h reteutil.h factmch.h factbld.h factrete.h factprt.h \
  tmpltlhs.h factgen.h 
facthsh.o : facthsh.c setup.h constant.h clipsmem.h router.h prntutil.h moduldef.h \
  symbol.h evaluatn.h expressn.h exprnops.h constrct.h scanner.h pprint.h lgcldpnd.h \
  match.h network.h ruledef.h constrnt.h factmngr.h pattern.h reorder.h multifld.h \
  tmpltdef.h cstrccom.h facthsh.h 
factlhs.o : factlhs.c setup.h router.h prntutil.h moduldef.h symbol.h evaluatn.h \
  constant.h expressn.h exprnops.h constrct.h scanner.h pprint.h reorder.h ruledef.h \
  constrnt.h factmngr.h pattern.h match.h network.h multifld.h tmpltdef.h cstrccom.h \
  tmpltpsr.h tmpltlhs.h modulutl.h factlhs.h 
factmch.o : factmch.c setup.h clipsmem.h extnfunc.h symbol.h expressn.h exprnops.h \
  router.h prntutil.h moduldef.h evaluatn.h constant.h constrct.h scanner.h pprint.h \
  incrrset.h ruledef.h constrnt.h factmngr.h pattern.h match.h network.h reorder.h \
  multifld.h tmpltdef.h cstrccom.h reteutil.h drive.h factgen.h factrete.h factmch.h \
  factbld.h 
factmngr.o : factmngr.c setup.h constant.h symbol.h clipsmem.h exprnpsr.h extnfunc.h \
  expressn.h exprnops.h scanner.h pprint.h argacces.h evaluatn.h router.h prntutil.h \
  moduldef.h constrct.h strngrtr.h match.h network.h ruledef.h constrnt.h factmngr.h \
  pattern.h reorder.h multifld.h tmpltdef.h cstrccom.h factbld.h reteutil.h retract.h \
  filecom.h factrhs.h factmch.h watch.h utility.h factbin.h facthsh.h engine.h \
  lgcldpnd.h drive.h ruledlt.h tmpltbsc.h tmpltcom.h tmpltfun.h 
factprt.o : factprt.c setup.h symbol.h router.h prntutil.h moduldef.h evaluatn.h \
  constant.h expressn.h exprnops.h constrct.h scanner.h pprint.h factgen.h reorder.h \
  ruledef.h constrnt.h factmngr.h pattern.h match.h network.h multifld.h tmpltdef.h \
  cstrccom.h factprt.h 
factrete.o : factrete.c setup.h clipsmem.h extnfunc.h symbol.h expressn.h exprnops.h \
  router.h prntutil.h moduldef.h evaluatn.h constant.h constrct.h scanner.h pprint.h \
  incrrset.h ruledef.h constrnt.h factmngr.h pattern.h match.h network.h reorder.h \
  multifld.h tmpltdef.h cstrccom.h reteutil.h drive.h factgen.h factmch.h factbld.h \
  factrete.h 
factrhs.o : factrhs.c setup.h constant.h prntutil.h moduldef.h symbol.h evaluatn.h \
  expressn.h exprnops.h constrct.h scanner.h pprint.h extnfunc.h pattern.h match.h \
  network.h ruledef.h constrnt.h factmngr.h multifld.h tmpltdef.h cstrccom.h reorder.h \
  modulutl.h bload.h exprnbin.h sysdep.h symblbin.h tmpltpsr.h tmpltrhs.h exprnpsr.h \
  strngrtr.h router.h factrhs.h 
filecom.o : filecom.c setup.h clipsmem.h argacces.h expressn.h exprnops.h evaluatn.h \
  constant.h symbol.h router.h prntutil.h moduldef.h constrct.h scanner.h pprint.h \
  strngrtr.h extnfunc.h cstrcpsr.h utility.h filecom.h bsave.h bload.h exprnbin.h \
  sysdep.h symblbin.h 
filertr.o : filertr.c setup.h constant.h clipsmem.h router.h prntutil.h moduldef.h \
  symbol.h evaluatn.h expressn.h exprnops.h constrct.h scanner.h pprint.h filertr.h 
generate.o : generate.c setup.h constant.h clipsmem.h symbol.h exprnpsr.h extnfunc.h \
  expressn.h exprnops.h scanner.h pprint.h argacces.h evaluatn.h router.h prntutil.h \
  moduldef.h constrct.h ruledef.h constrnt.h factmngr.h pattern.h match.h network.h \
  reorder.h multifld.h tmpltdef.h cstrccom.h generate.h globlpsr.h 
genrcbin.o : genrcbin.c setup.h constant.h clipsmem.h bload.h exprnbin.h expressn.h \
  exprnops.h symbol.h sysdep.h symblbin.h bsave.h cstrcbin.h constrct.h moduldef.h \
  evaluatn.h scanner.h pprint.h objbin.h object.h constrnt.h multifld.h match.h \
  network.h ruledef.h factmngr.h pattern.h reorder.h tmpltdef.h cstrccom.h genrccom.h \
  genrcfun.h modulbin.h genrcbin.h router.h prntutil.h 
genrccmp.o : genrccmp.c setup.h genrccom.h constrct.h moduldef.h symbol.h evaluatn.h \
  constant.h expressn.h exprnops.h scanner.h pprint.h cstrccom.h genrcfun.h object.h \
  constrnt.h multifld.h match.h network.h ruledef.h factmngr.h pattern.h reorder.h \
  tmpltdef.h conscomp.h extnfunc.h symblcmp.h objcmp.h genrccmp.h 
genrccom.o : genrccom.c setup.h bload.h exprnbin.h expressn.h exprnops.h symbol.h \
  sysdep.h symblbin.h genrcbin.h genrcfun.h constrct.h moduldef.h evaluatn.h constant.h \
  scanner.h pprint.h object.h constrnt.h multifld.h match.h network.h ruledef.h \
  factmngr.h pattern.h reorder.h tmpltdef.h cstrccom.h genrccmp.h genrcpsr.h classcom.h \
  inscom.h watch.h argacces.h clipsmem.h cstrcpsr.h extnfunc.h genrcexe.h modulpsr.h \
  router.h prntutil.h genrccom.h 
genrcexe.o : genrcexe.c setup.h classcom.h cstrccom.h moduldef.h symbol.h evaluatn.h \
  constant.h expressn.h exprnops.h constrct.h scanner.h pprint.h object.h constrnt.h \
  multifld.h match.h network.h ruledef.h factmngr.h pattern.h reorder.h tmpltdef.h \
  classfun.h insfun.h argacces.h genrccom.h genrcfun.h prcdrfun.h prccode.h router.h \
  prntutil.h utility.h genrcexe.h 
genrcfun.o : genrcfun.c setup.h bload.h exprnbin.h expressn.h exprnops.h symbol.h \
  sysdep.h symblbin.h classcom.h cstrccom.h moduldef.h evaluatn.h constant.h constrct.h \
  scanner.h pprint.h object.h constrnt.h multifld.h match.h network.h ruledef.h \
  factmngr.h pattern.h reorder.h tmpltdef.h classfun.h argacces.h clipsmem.h cstrcpsr.h \
  genrccom.h genrcfun.h genrcexe.h prccode.h router.h prntutil.h 
genrcpsr.o : genrcpsr.c setup.h bload.h exprnbin.h expressn.h exprnops.h symbol.h \
  sysdep.h symblbin.h dffnxfun.h cstrccom.h moduldef.h evaluatn.h constant.h constrct.h \
  scanner.h pprint.h classfun.h object.h constrnt.h multifld.h match.h network.h \
  ruledef.h factmngr.h pattern.h reorder.h tmpltdef.h classcom.h clipsmem.h cstrcpsr.h \
  exprnpsr.h extnfunc.h genrccom.h genrcfun.h immthpsr.h modulutl.h prcdrpsr.h \
  prccode.h router.h prntutil.h genrcpsr.h 
globlbin.o : globlbin.c setup.h clipsmem.h multifld.h evaluatn.h constant.h \
  symbol.h expressn.h exprnops.h globldef.h constrct.h moduldef.h scanner.h pprint.h \
  cstrccom.h bload.h exprnbin.h sysdep.h symblbin.h bsave.h globlbsc.h globlbin.h \
  modulbin.h cstrcbin.h 
globlbsc.o : globlbsc.c setup.h constrct.h moduldef.h symbol.h evaluatn.h constant.h \
  expressn.h exprnops.h scanner.h pprint.h extnfunc.h watch.h globlcom.h globldef.h \
  cstrccom.h globlbin.h modulbin.h cstrcbin.h globlcmp.h globlbsc.h 
globlcmp.o : globlcmp.c setup.h conscomp.h extnfunc.h symbol.h expressn.h exprnops.h \
  symblcmp.h moduldef.h evaluatn.h constant.h constrct.h scanner.h pprint.h globldef.h \
  cstrccom.h globlcmp.h 
globlcom.o : globlcom.c setup.h extnfunc.h symbol.h expressn.h exprnops.h argacces.h \
  evaluatn.h constant.h prntutil.h moduldef.h constrct.h scanner.h pprint.h router.h \
  globldef.h cstrccom.h globlcom.h 
globldef.o : globldef.c setup.h clipsmem.h modulpsr.h symbol.h evaluatn.h constant.h \
  expressn.h exprnops.h multifld.h router.h prntutil.h moduldef.h constrct.h scanner.h \
  pprint.h strngrtr.h modulutl.h bload.h exprnbin.h sysdep.h symblbin.h globlbsc.h \
  globlpsr.h globlcom.h globlbin.h modulbin.h cstrcbin.h globldef.h cstrccom.h \
  globlcmp.h 
globlpsr.o : globlpsr.c setup.h pprint.h router.h prntutil.h moduldef.h symbol.h \
  evaluatn.h constant.h expressn.h exprnops.h constrct.h scanner.h clipsmem.h \
  exprnpsr.h extnfunc.h multifld.h watch.h modulutl.h cstrcpsr.h globldef.h cstrccom.h \
  globlbsc.h bload.h exprnbin.h sysdep.h symblbin.h globlpsr.h 
immthpsr.o : immthpsr.c setup.h classcom.h cstrccom.h moduldef.h symbol.h evaluatn.h \
  constant.h expressn.h exprnops.h constrct.h scanner.h pprint.h object.h constrnt.h \
  multifld.h match.h network.h ruledef.h factmngr.h pattern.h reorder.h tmpltdef.h \
  classfun.h clipsmem.h cstrnutl.h extnfunc.h genrcpsr.h genrcfun.h prccode.h \
  immthpsr.h 
incrrset.o : incrrset.c setup.h constant.h agenda.h ruledef.h symbol.h expressn.h \
  exprnops.h evaluatn.h constrct.h moduldef.h scanner.h pprint.h constrnt.h factmngr.h \
  pattern.h match.h network.h reorder.h multifld.h tmpltdef.h cstrccom.h router.h \
  prntutil.h drive.h argacces.h incrrset.h 
inherpsr.o : inherpsr.c setup.h classcom.h cstrccom.h moduldef.h symbol.h evaluatn.h \
  constant.h expressn.h exprnops.h constrct.h scanner.h pprint.h object.h constrnt.h \
  multifld.h match.h network.h ruledef.h factmngr.h pattern.h reorder.h tmpltdef.h \
  classfun.h clipsmem.h modulutl.h router.h prntutil.h inherpsr.h 
inscom.o : inscom.c setup.h argacces.h expressn.h exprnops.h evaluatn.h constant.h \
  symbol.h classcom.h cstrccom.h moduldef.h constrct.h scanner.h pprint.h object.h \
  constrnt.h multifld.h match.h network.h ruledef.h factmngr.h pattern.h reorder.h \
  tmpltdef.h classfun.h clipsmem.h exprnpsr.h extnfunc.h insfile.h insfun.h insmngr.h \
  insmoddp.h insmult.h inspsr.h msgfun.h msgpass.h router.h prntutil.h strngrtr.h \
  utility.h inscom.h 
insfile.o : insfile.c setup.h argacces.h expressn.h exprnops.h evaluatn.h constant.h \
  symbol.h classcom.h cstrccom.h moduldef.h constrct.h scanner.h pprint.h object.h \
  constrnt.h multifld.h match.h network.h ruledef.h factmngr.h pattern.h reorder.h \
  tmpltdef.h classfun.h clipsmem.h extnfunc.h inscom.h insfun.h insmngr.h inspsr.h \
  router.h prntutil.h symblbin.h sysdep.h insfile.h 
insfun.o : insfun.c setup.h argacces.h expressn.h exprnops.h evaluatn.h constant.h \
  symbol.h classcom.h cstrccom.h moduldef.h constrct.h scanner.h pprint.h object.h \
  constrnt.h multifld.h match.h network.h ruledef.h factmngr.h pattern.h reorder.h \
  tmpltdef.h classfun.h clipsmem.h cstrnchk.h inscom.h insmngr.h modulutl.h msgfun.h \
  msgpass.h router.h prntutil.h utility.h drive.h objrtmch.h insfun.h 
insmngr.o : insmngr.c setup.h drive.h expressn.h exprnops.h match.h evaluatn.h \
  constant.h symbol.h network.h ruledef.h constrct.h moduldef.h scanner.h pprint.h \
  constrnt.h factmngr.h pattern.h reorder.h multifld.h tmpltdef.h cstrccom.h objrtmch.h \
  object.h lgcldpnd.h classcom.h classfun.h clipsmem.h extnfunc.h insfun.h modulutl.h \
  msgfun.h msgpass.h router.h prntutil.h utility.h insmngr.h 
insmoddp.o : insmoddp.c setup.h objrtmch.h evaluatn.h constant.h symbol.h expressn.h \
  exprnops.h match.h network.h ruledef.h constrct.h moduldef.h scanner.h pprint.h \
  constrnt.h factmngr.h pattern.h reorder.h multifld.h tmpltdef.h cstrccom.h object.h \
  argacces.h clipsmem.h extnfunc.h insfun.h insmngr.h inspsr.h msgfun.h msgpass.h \
  router.h prntutil.h insmoddp.h 
insmult.o : insmult.c setup.h argacces.h expressn.h exprnops.h evaluatn.h constant.h \
  symbol.h extnfunc.h insfun.h object.h constrct.h moduldef.h scanner.h pprint.h \
  constrnt.h multifld.h match.h network.h ruledef.h factmngr.h pattern.h reorder.h \
  tmpltdef.h cstrccom.h msgfun.h msgpass.h multifun.h router.h prntutil.h insmult.h 
inspsr.o : inspsr.c setup.h classcom.h cstrccom.h moduldef.h symbol.h evaluatn.h \
  constant.h expressn.h exprnops.h constrct.h scanner.h pprint.h object.h constrnt.h \
  multifld.h match.h network.h ruledef.h factmngr.h pattern.h reorder.h tmpltdef.h \
  classfun.h classinf.h exprnpsr.h extnfunc.h prntutil.h router.h inspsr.h 
insquery.o : insquery.c setup.h argacces.h expressn.h exprnops.h evaluatn.h \
  constant.h symbol.h classcom.h cstrccom.h moduldef.h constrct.h scanner.h pprint.h \
  object.h constrnt.h multifld.h match.h network.h ruledef.h factmngr.h pattern.h \
  reorder.h tmpltdef.h classfun.h clipsmem.h exprnpsr.h extnfunc.h insfun.h insmngr.h \
  insqypsr.h prcdrfun.h router.h prntutil.h insquery.h 
insqypsr.o : insqypsr.c setup.h classcom.h cstrccom.h moduldef.h symbol.h evaluatn.h \
  constant.h expressn.h exprnops.h constrct.h scanner.h pprint.h object.h constrnt.h \
  multifld.h match.h network.h ruledef.h factmngr.h pattern.h reorder.h tmpltdef.h \
  exprnpsr.h extnfunc.h insquery.h prcdrpsr.h prntutil.h router.h strngrtr.h insqypsr.h 
iofun.o : iofun.c setup.h router.h prntutil.h moduldef.h symbol.h evaluatn.h \
  constant.h expressn.h exprnops.h constrct.h scanner.h pprint.h strngrtr.h filertr.h \
  argacces.h extnfunc.h clipsmem.h commline.h sysdep.h utility.h 
lgcldpnd.o : lgcldpnd.c setup.h clipsmem.h router.h prntutil.h moduldef.h symbol.h \
  evaluatn.h constant.h expressn.h exprnops.h constrct.h scanner.h pprint.h engine.h \
  ruledef.h constrnt.h factmngr.h pattern.h match.h network.h reorder.h multifld.h \
  tmpltdef.h cstrccom.h reteutil.h argacces.h insfun.h object.h lgcldpnd.h 
main.o : main.c setup.h sysdep.h commline.h 
memory.o : memory.c setup.h constant.h clipsmem.h router.h prntutil.h moduldef.h \
  symbol.h evaluatn.h expressn.h exprnops.h constrct.h scanner.h pprint.h utility.h 
miscfun.o : miscfun.c setup.h clipsmem.h sysdep.h multifld.h evaluatn.h constant.h \
  symbol.h expressn.h exprnops.h exprnpsr.h extnfunc.h scanner.h pprint.h argacces.h \
  router.h prntutil.h moduldef.h constrct.h dffnxfun.h cstrccom.h miscfun.h 
modulbin.o : modulbin.c setup.h clipsmem.h constrct.h moduldef.h symbol.h evaluatn.h \
  constant.h expressn.h exprnops.h scanner.h pprint.h bload.h exprnbin.h sysdep.h \
  symblbin.h bsave.h modulbin.h 
modulbsc.o : modulbsc.c setup.h constrct.h moduldef.h symbol.h evaluatn.h constant.h \
  expressn.h exprnops.h scanner.h pprint.h extnfunc.h modulbin.h prntutil.h modulcmp.h \
  router.h argacces.h bload.h exprnbin.h sysdep.h symblbin.h modulbsc.h 
modulcmp.o : modulcmp.c setup.h conscomp.h extnfunc.h symbol.h expressn.h exprnops.h \
  symblcmp.h moduldef.h evaluatn.h constant.h constrct.h scanner.h pprint.h modulcmp.h 
moduldef.o : moduldef.c setup.h clipsmem.h constant.h router.h prntutil.h moduldef.h \
  symbol.h evaluatn.h expressn.h exprnops.h constrct.h scanner.h pprint.h extnfunc.h \
  argacces.h modulpsr.h modulcmp.h modulbsc.h utility.h bload.h exprnbin.h sysdep.h \
  symblbin.h modulbin.h 
modulpsr.o : modulpsr.c setup.h clipsmem.h constant.h router.h prntutil.h moduldef.h \
  symbol.h evaluatn.h expressn.h exprnops.h constrct.h scanner.h pprint.h extnfunc.h \
  argacces.h cstrcpsr.h modulutl.h utility.h bload.h exprnbin.h sysdep.h symblbin.h \
  modulpsr.h 
modulutl.o : modulutl.c setup.h clipsmem.h router.h prntutil.h moduldef.h symbol.h \
  evaluatn.h constant.h expressn.h exprnops.h constrct.h scanner.h pprint.h modulutl.h 
msgcom.o : msgcom.c setup.h argacces.h expressn.h exprnops.h evaluatn.h constant.h \
  symbol.h classcom.h cstrccom.h moduldef.h constrct.h scanner.h pprint.h object.h \
  constrnt.h multifld.h match.h network.h ruledef.h factmngr.h pattern.h reorder.h \
  tmpltdef.h classfun.h classinf.h insfun.h insmoddp.h insmult.h msgfun.h msgpass.h \
  prccode.h router.h prntutil.h bload.h exprnbin.h sysdep.h symblbin.h extnfunc.h \
  msgpsr.h watch.h msgcom.h 
msgfun.o : msgfun.c setup.h classcom.h cstrccom.h moduldef.h symbol.h evaluatn.h \
  constant.h expressn.h exprnops.h constrct.h scanner.h pprint.h object.h constrnt.h \
  multifld.h match.h network.h ruledef.h factmngr.h pattern.h reorder.h tmpltdef.h \
  classfun.h clipsmem.h extnfunc.h insfun.h prccode.h router.h prntutil.h msgfun.h \
  msgpass.h 
msgpass.o : msgpass.c setup.h argacces.h expressn.h exprnops.h evaluatn.h constant.h \
  symbol.h classcom.h cstrccom.h moduldef.h constrct.h scanner.h pprint.h object.h \
  constrnt.h multifld.h match.h network.h ruledef.h factmngr.h pattern.h reorder.h \
  tmpltdef.h classfun.h clipsmem.h exprnpsr.h extnfunc.h insfun.h msgfun.h msgpass.h \
  prcdrfun.h prccode.h router.h prntutil.h utility.h 
msgpsr.o : msgpsr.c setup.h bload.h exprnbin.h expressn.h exprnops.h symbol.h \
  sysdep.h symblbin.h classcom.h cstrccom.h moduldef.h evaluatn.h constant.h constrct.h \
  scanner.h pprint.h object.h constrnt.h multifld.h match.h network.h ruledef.h \
  factmngr.h pattern.h reorder.h tmpltdef.h classfun.h clipsmem.h cstrcpsr.h cstrnchk.h \
  exprnpsr.h extnfunc.h insfun.h msgfun.h msgpass.h prccode.h router.h prntutil.h \
  strngrtr.h msgpsr.h 
multifld.o : multifld.c setup.h constant.h clipsmem.h evaluatn.h symbol.h expressn.h \
  exprnops.h scanner.h pprint.h router.h prntutil.h moduldef.h constrct.h strngrtr.h \
  utility.h multifld.h 
multifun.o : multifun.c setup.h clipsmem.h argacces.h expressn.h exprnops.h \
  evaluatn.h constant.h symbol.h multifld.h router.h prntutil.h moduldef.h constrct.h \
  scanner.h pprint.h multifun.h exprnpsr.h extnfunc.h prcdrpsr.h constrnt.h prcdrfun.h \
  object.h match.h network.h ruledef.h factmngr.h pattern.h reorder.h tmpltdef.h \
  cstrccom.h 
objbin.o : objbin.c setup.h bload.h exprnbin.h expressn.h exprnops.h symbol.h \
  sysdep.h symblbin.h bsave.h classcom.h cstrccom.h moduldef.h evaluatn.h constant.h \
  constrct.h scanner.h pprint.h object.h constrnt.h multifld.h match.h network.h \
  ruledef.h factmngr.h pattern.h reorder.h tmpltdef.h classfun.h classini.h clipsmem.h \
  cstrcbin.h cstrnbin.h insfun.h modulbin.h msgfun.h msgpass.h prntutil.h router.h \
  objbin.h 
objcmp.o : objcmp.c setup.h conscomp.h extnfunc.h symbol.h expressn.h exprnops.h \
  symblcmp.h moduldef.h evaluatn.h constant.h constrct.h scanner.h pprint.h classcom.h \
  cstrccom.h object.h constrnt.h multifld.h match.h network.h ruledef.h factmngr.h \
  pattern.h reorder.h tmpltdef.h classfun.h classini.h cstrncmp.h objcmp.h 
objrtbin.o : objrtbin.c setup.h bload.h exprnbin.h expressn.h exprnops.h symbol.h \
  sysdep.h symblbin.h bsave.h clipsmem.h insfun.h evaluatn.h constant.h object.h \
  constrct.h moduldef.h scanner.h pprint.h constrnt.h multifld.h match.h network.h \
  ruledef.h factmngr.h pattern.h reorder.h tmpltdef.h cstrccom.h objrtmch.h rulebin.h \
  modulbin.h cstrcbin.h objrtbin.h 
objrtbld.o : objrtbld.c setup.h classcom.h cstrccom.h moduldef.h symbol.h evaluatn.h \
  constant.h expressn.h exprnops.h constrct.h scanner.h pprint.h object.h constrnt.h \
  multifld.h match.h network.h ruledef.h factmngr.h pattern.h reorder.h tmpltdef.h \
  classfun.h clipsmem.h cstrnutl.h cstrnchk.h cstrnops.h drive.h exprnpsr.h extnfunc.h \
  insfun.h insmngr.h reteutil.h rulepsr.h utility.h objrtmch.h objrtgen.h objrtfnx.h \
  router.h prntutil.h objrtcmp.h objrtbin.h objrtbld.h 
objrtcmp.o : objrtcmp.c setup.h conscomp.h extnfunc.h symbol.h expressn.h exprnops.h \
  symblcmp.h moduldef.h evaluatn.h constant.h constrct.h scanner.h pprint.h objrtmch.h \
  match.h network.h ruledef.h constrnt.h factmngr.h pattern.h reorder.h multifld.h \
  tmpltdef.h cstrccom.h object.h objrtcmp.h 
objrtfnx.o : objrtfnx.c setup.h classcom.h cstrccom.h moduldef.h symbol.h evaluatn.h \
  constant.h expressn.h exprnops.h constrct.h scanner.h pprint.h object.h constrnt.h \
  multifld.h match.h network.h ruledef.h factmngr.h pattern.h reorder.h tmpltdef.h \
  classfun.h drive.h objrtmch.h reteutil.h router.h prntutil.h objrtfnx.h 
objrtgen.o : objrtgen.c setup.h classfun.h object.h constrct.h moduldef.h symbol.h \
  evaluatn.h constant.h expressn.h exprnops.h scanner.h pprint.h constrnt.h multifld.h \
  match.h network.h ruledef.h factmngr.h pattern.h reorder.h tmpltdef.h cstrccom.h \
  objrtfnx.h objrtgen.h 
objrtmch.o : objrtmch.c setup.h classfun.h object.h constrct.h moduldef.h symbol.h \
  evaluatn.h constant.h expressn.h exprnops.h scanner.h pprint.h constrnt.h multifld.h \
  match.h network.h ruledef.h factmngr.h pattern.h reorder.h tmpltdef.h cstrccom.h \
  clipsmem.h drive.h lgcldpnd.h incrrset.h reteutil.h ruledlt.h retract.h router.h \
  prntutil.h objrtfnx.h objrtmch.h 
pattern.o : pattern.c setup.h constant.h clipsmem.h match.h evaluatn.h symbol.h \
  expressn.h exprnops.h network.h ruledef.h constrct.h moduldef.h scanner.h pprint.h \
  constrnt.h factmngr.h pattern.h reorder.h multifld.h tmpltdef.h cstrccom.h reteutil.h \
  exprnpsr.h extnfunc.h router.h prntutil.h cstrnchk.h cstrnutl.h rulecmp.h conscomp.h \
  symblcmp.h 
pprint.o : pprint.c setup.h constant.h clipsmem.h utility.h pprint.h 
prccode.o : prccode.c setup.h clipsmem.h constant.h globlpsr.h expressn.h exprnops.h \
  exprnpsr.h extnfunc.h symbol.h scanner.h pprint.h multifld.h evaluatn.h object.h \
  constrct.h moduldef.h constrnt.h match.h network.h ruledef.h factmngr.h pattern.h \
  reorder.h tmpltdef.h cstrccom.h prcdrpsr.h router.h prntutil.h utility.h prccode.h 
prcdrfun.o : prcdrfun.c setup.h clipsmem.h router.h prntutil.h moduldef.h symbol.h \
  evaluatn.h constant.h expressn.h exprnops.h constrct.h scanner.h pprint.h argacces.h \
  constrnt.h cstrnchk.h cstrnops.h multifld.h exprnpsr.h extnfunc.h utility.h \
  prcdrpsr.h prcdrfun.h globldef.h cstrccom.h 
prcdrpsr.o : prcdrpsr.c setup.h clipsmem.h router.h prntutil.h moduldef.h symbol.h \
  evaluatn.h constant.h expressn.h exprnops.h constrct.h scanner.h pprint.h argacces.h \
  constrnt.h cstrnchk.h cstrnops.h multifld.h exprnpsr.h extnfunc.h utility.h \
  modulutl.h cstrnutl.h prcdrpsr.h globldef.h cstrccom.h 
prdctfun.o : prdctfun.c setup.h exprnpsr.h extnfunc.h symbol.h expressn.h exprnops.h \
  scanner.h pprint.h argacces.h evaluatn.h constant.h multifld.h router.h prntutil.h \
  moduldef.h constrct.h 
prntutil.o : prntutil.c setup.h constant.h symbol.h utility.h evaluatn.h expressn.h \
  exprnops.h argacces.h object.h constrct.h moduldef.h scanner.h pprint.h constrnt.h \
  multifld.h match.h network.h ruledef.h factmngr.h pattern.h reorder.h tmpltdef.h \
  cstrccom.h insmngr.h router.h prntutil.h 
reorder.o : reorder.c setup.h clipsmem.h cstrnutl.h constrnt.h evaluatn.h constant.h \
  symbol.h expressn.h exprnops.h extnfunc.h rulelhs.h reorder.h ruledef.h constrct.h \
  moduldef.h scanner.h pprint.h factmngr.h pattern.h match.h network.h multifld.h \
  tmpltdef.h cstrccom.h prntutil.h router.h 
reteutil.o : reteutil.c setup.h clipsmem.h router.h prntutil.h moduldef.h symbol.h \
  evaluatn.h constant.h expressn.h exprnops.h constrct.h scanner.h pprint.h retract.h \
  match.h network.h ruledef.h constrnt.h factmngr.h pattern.h reorder.h multifld.h \
  tmpltdef.h cstrccom.h drive.h incrrset.h reteutil.h 
retract.o : retract.c setup.h constant.h clipsmem.h symbol.h argacces.h expressn.h \
  exprnops.h evaluatn.h router.h prntutil.h moduldef.h constrct.h scanner.h pprint.h \
  network.h match.h ruledef.h constrnt.h factmngr.h pattern.h reorder.h multifld.h \
  tmpltdef.h cstrccom.h agenda.h drive.h lgcldpnd.h retract.h 
router.o : router.c setup.h constant.h clipsmem.h filertr.h strngrtr.h extnfunc.h \
  symbol.h expressn.h exprnops.h argacces.h evaluatn.h sysdep.h router.h prntutil.h \
  moduldef.h constrct.h scanner.h pprint.h 
rulebin.o : rulebin.c setup.h clipsmem.h bload.h exprnbin.h expressn.h exprnops.h \
  symbol.h sysdep.h symblbin.h bsave.h reteutil.h evaluatn.h constant.h match.h \
  network.h ruledef.h constrct.h moduldef.h scanner.h pprint.h constrnt.h factmngr.h \
  pattern.h reorder.h multifld.h tmpltdef.h cstrccom.h agenda.h engine.h rulebsc.h \
  rulebin.h modulbin.h cstrcbin.h 
rulebld.o : rulebld.c setup.h constant.h clipsmem.h router.h prntutil.h moduldef.h \
  symbol.h evaluatn.h expressn.h exprnops.h constrct.h scanner.h pprint.h watch.h \
  drive.h match.h network.h ruledef.h constrnt.h factmngr.h pattern.h reorder.h \
  multifld.h tmpltdef.h cstrccom.h reteutil.h incrrset.h rulebld.h 
rulebsc.o : rulebsc.c setup.h argacces.h expressn.h exprnops.h evaluatn.h constant.h \
  symbol.h constrct.h moduldef.h scanner.h pprint.h router.h prntutil.h watch.h \
  extnfunc.h ruledef.h constrnt.h factmngr.h pattern.h match.h network.h reorder.h \
  multifld.h tmpltdef.h cstrccom.h rulebin.h modulbin.h cstrcbin.h rulecmp.h conscomp.h \
  symblcmp.h engine.h rulebsc.h 
rulecmp.o : rulecmp.c setup.h factbld.h pattern.h evaluatn.h constant.h symbol.h \
  expressn.h exprnops.h scanner.h pprint.h match.h network.h ruledef.h constrct.h \
  moduldef.h constrnt.h factmngr.h multifld.h tmpltdef.h cstrccom.h reorder.h \
  reteutil.h rulecmp.h conscomp.h extnfunc.h symblcmp.h 
rulecom.o : rulecom.c setup.h constant.h clipsmem.h evaluatn.h symbol.h expressn.h \
  exprnops.h extnfunc.h engine.h ruledef.h constrct.h moduldef.h scanner.h pprint.h \
  constrnt.h factmngr.h pattern.h match.h network.h reorder.h multifld.h tmpltdef.h \
  cstrccom.h watch.h crstrtgy.h agenda.h argacces.h router.h prntutil.h reteutil.h \
  ruledlt.h rulebin.h modulbin.h cstrcbin.h lgcldpnd.h incrrset.h rulecom.h 
rulecstr.o : rulecstr.c setup.h router.h prntutil.h moduldef.h symbol.h evaluatn.h \
  constant.h expressn.h exprnops.h constrct.h scanner.h pprint.h reorder.h ruledef.h \
  constrnt.h factmngr.h pattern.h match.h network.h multifld.h tmpltdef.h cstrccom.h \
  cstrnchk.h cstrnops.h extnfunc.h analysis.h prcdrpsr.h cstrnutl.h rulepsr.h \
  rulecstr.h 
ruledef.o : ruledef.c setup.h clipsmem.h engine.h ruledef.h symbol.h expressn.h \
  exprnops.h evaluatn.h constant.h constrct.h moduldef.h scanner.h pprint.h constrnt.h \
  factmngr.h pattern.h match.h network.h reorder.h multifld.h tmpltdef.h cstrccom.h \
  rulebsc.h rulecom.h rulecmp.h conscomp.h extnfunc.h symblcmp.h drive.h rulepsr.h \
  ruledlt.h rulebin.h modulbin.h cstrcbin.h agenda.h bload.h exprnbin.h sysdep.h \
  symblbin.h 
ruledlt.o : ruledlt.c setup.h clipsmem.h engine.h ruledef.h symbol.h expressn.h \
  exprnops.h evaluatn.h constant.h constrct.h moduldef.h scanner.h pprint.h constrnt.h \
  factmngr.h pattern.h match.h network.h reorder.h multifld.h tmpltdef.h cstrccom.h \
  reteutil.h agenda.h drive.h retract.h bload.h exprnbin.h sysdep.h symblbin.h \
  ruledlt.h 
rulelhs.o : rulelhs.c setup.h constant.h symbol.h clipsmem.h exprnpsr.h extnfunc.h \
  expressn.h exprnops.h scanner.h pprint.h argacces.h evaluatn.h reorder.h ruledef.h \
  constrct.h moduldef.h constrnt.h factmngr.h pattern.h match.h network.h multifld.h \
  tmpltdef.h cstrccom.h router.h prntutil.h cstrnchk.h agenda.h rulelhs.h 
rulepsr.o : rulepsr.c setup.h constant.h clipsmem.h symbol.h scanner.h pprint.h \
  router.h prntutil.h moduldef.h evaluatn.h expressn.h exprnops.h constrct.h engine.h \
  ruledef.h constrnt.h factmngr.h pattern.h match.h network.h reorder.h multifld.h \
  tmpltdef.h cstrccom.h rulelhs.h rulebld.h cstrnchk.h cstrnops.h exprnpsr.h extnfunc.h \
  analysis.h prcdrpsr.h prccode.h incrrset.h rulecstr.h watch.h ruledlt.h cstrcpsr.h \
  rulebsc.h lgcldpnd.h tmpltfun.h bload.h exprnbin.h sysdep.h symblbin.h rulepsr.h 
scanner.o : scanner.c setup.h constant.h router.h prntutil.h moduldef.h symbol.h \
  evaluatn.h expressn.h exprnops.h constrct.h scanner.h pprint.h utility.h clipsmem.h 
strngfun.o : strngfun.c setup.h clipsmem.h extnfunc.h symbol.h expressn.h exprnops.h \
  argacces.h evaluatn.h constant.h router.h prntutil.h moduldef.h constrct.h scanner.h \
  pprint.h strngrtr.h prcdrpsr.h constrnt.h cstrcpsr.h exprnpsr.h drive.h match.h \
  network.h ruledef.h factmngr.h pattern.h reorder.h multifld.h tmpltdef.h cstrccom.h \
  strngfun.h 
strngrtr.o : strngrtr.c setup.h constant.h clipsmem.h router.h prntutil.h moduldef.h \
  symbol.h evaluatn.h expressn.h exprnops.h constrct.h scanner.h pprint.h strngrtr.h 
symblbin.o : symblbin.c setup.h clipsmem.h exprnpsr.h extnfunc.h symbol.h expressn.h \
  exprnops.h scanner.h pprint.h argacces.h evaluatn.h constant.h router.h prntutil.h \
  moduldef.h constrct.h cstrnbin.h constrnt.h bload.h exprnbin.h sysdep.h symblbin.h \
  bsave.h 
symblcmp.o : symblcmp.c setup.h symbol.h clipsmem.h constant.h exprnpsr.h extnfunc.h \
  expressn.h exprnops.h scanner.h pprint.h cstrccom.h moduldef.h evaluatn.h constrct.h \
  argacces.h cstrncmp.h constrnt.h router.h prntutil.h conscomp.h symblcmp.h utility.h 
symbol.o : symbol.c setup.h constant.h clipsmem.h router.h prntutil.h moduldef.h \
  symbol.h evaluatn.h expressn.h exprnops.h constrct.h scanner.h pprint.h utility.h \
  argacces.h 
sysdep.o : sysdep.c setup.h sysdep.h constrct.h moduldef.h symbol.h evaluatn.h \
  constant.h expressn.h exprnops.h scanner.h pprint.h filecom.h clipsmem.h argacces.h \
  utility.h router.h prntutil.h dffctdef.h cstrccom.h ruledef.h constrnt.h factmngr.h \
  pattern.h match.h network.h reorder.h multifld.h tmpltdef.h genrccom.h genrcfun.h \
  object.h dffnxfun.h globldef.h extobj.h bmathfun.h 
textpro.o : textpro.c setup.h commline.h clipsmem.h argacces.h expressn.h exprnops.h \
  evaluatn.h constant.h symbol.h extnfunc.h router.h prntutil.h moduldef.h constrct.h \
  scanner.h pprint.h 
tmpltbin.o : tmpltbin.c setup.h clipsmem.h bload.h exprnbin.h expressn.h exprnops.h \
  symbol.h sysdep.h symblbin.h bsave.h factbin.h factbld.h pattern.h evaluatn.h \
  constant.h scanner.h pprint.h match.h network.h ruledef.h constrct.h moduldef.h \
  constrnt.h factmngr.h multifld.h tmpltdef.h cstrccom.h reorder.h cstrnbin.h \
  tmpltpsr.h tmpltbin.h cstrcbin.h modulbin.h 
tmpltbsc.o : tmpltbsc.c setup.h argacces.h expressn.h exprnops.h evaluatn.h \
  constant.h symbol.h clipsmem.h scanner.h pprint.h router.h prntutil.h moduldef.h \
  constrct.h extnfunc.h cstrccom.h factrhs.h cstrcpsr.h tmpltpsr.h tmpltdef.h \
  constrnt.h factmngr.h pattern.h match.h network.h ruledef.h reorder.h multifld.h \
  tmpltbin.h cstrcbin.h modulbin.h tmpltcmp.h tmpltbsc.h 
tmpltcmp.o : tmpltcmp.c setup.h conscomp.h extnfunc.h symbol.h expressn.h exprnops.h \
  symblcmp.h moduldef.h evaluatn.h constant.h constrct.h scanner.h pprint.h factcmp.h \
  pattern.h match.h network.h ruledef.h constrnt.h factmngr.h multifld.h tmpltdef.h \
  cstrccom.h reorder.h cstrncmp.h tmpltcmp.h 
tmpltcom.o : tmpltcom.c setup.h extnfunc.h symbol.h expressn.h exprnops.h constrct.h \
  moduldef.h evaluatn.h constant.h scanner.h pprint.h router.h prntutil.h argacces.h \
  tmpltfun.h factmngr.h pattern.h match.h network.h ruledef.h constrnt.h cstrccom.h \
  reorder.h multifld.h tmpltdef.h tmpltpsr.h bload.h exprnbin.h sysdep.h symblbin.h \
  tmpltbin.h cstrcbin.h modulbin.h tmpltcmp.h tmpltcom.h 
tmpltdef.o : tmpltdef.c setup.h clipsmem.h tmpltbin.h cstrcbin.h constrct.h \
  moduldef.h symbol.h evaluatn.h constant.h expressn.h exprnops.h scanner.h pprint.h \
  modulbin.h tmpltdef.h constrnt.h factmngr.h pattern.h match.h network.h ruledef.h \
  cstrccom.h reorder.h multifld.h tmpltpsr.h tmpltbsc.h tmpltcom.h tmpltcmp.h \
  router.h prntutil.h modulpsr.h modulutl.h bload.h exprnbin.h sysdep.h symblbin.h 
tmpltfun.o : tmpltfun.c setup.h constant.h clipsmem.h symbol.h scanner.h pprint.h \
  exprnpsr.h extnfunc.h expressn.h exprnops.h argacces.h evaluatn.h router.h prntutil.h \
  moduldef.h constrct.h cstrnchk.h constrnt.h default.h factmngr.h pattern.h match.h \
  network.h ruledef.h cstrccom.h reorder.h multifld.h tmpltdef.h commline.h factrhs.h \
  modulutl.h tmpltlhs.h tmpltrhs.h tmpltfun.h 
tmpltlhs.o : tmpltlhs.c setup.h constant.h clipsmem.h symbol.h scanner.h pprint.h \
  exprnpsr.h extnfunc.h expressn.h exprnops.h router.h prntutil.h moduldef.h evaluatn.h \
  constrct.h constrnt.h reorder.h ruledef.h factmngr.h pattern.h match.h network.h \
  multifld.h tmpltdef.h cstrccom.h factrhs.h modulutl.h tmpltlhs.h 
tmpltpsr.o : tmpltpsr.c setup.h constant.h clipsmem.h symbol.h scanner.h pprint.h \
  exprnpsr.h extnfunc.h expressn.h exprnops.h router.h prntutil.h moduldef.h evaluatn.h \
  constrct.h factmngr.h pattern.h match.h network.h ruledef.h constrnt.h cstrccom.h \
  reorder.h multifld.h tmpltdef.h cstrnchk.h cstrnpsr.h cstrcpsr.h default.h watch.h \
  cstrnutl.h tmpltbsc.h tmpltpsr.h 
tmpltrhs.o : tmpltrhs.c setup.h clipsmem.h prntutil.h moduldef.h symbol.h evaluatn.h \
  constant.h expressn.h exprnops.h constrct.h scanner.h pprint.h router.h tmpltfun.h \
  factmngr.h pattern.h match.h network.h ruledef.h constrnt.h cstrccom.h reorder.h \
  multifld.h tmpltdef.h factrhs.h extnfunc.h modulutl.h default.h tmpltlhs.h tmpltrhs.h 
utility.o : utility.c setup.h clipsmem.h evaluatn.h constant.h symbol.h expressn.h \
  exprnops.h multifld.h utility.h 
watch.o : watch.c setup.h constant.h clipsmem.h router.h prntutil.h moduldef.h \
  symbol.h evaluatn.h expressn.h exprnops.h constrct.h scanner.h pprint.h argacces.h \
  extnfunc.h watch.h 
