#include "confint.h"

int main()

{
   float fValue1;
   float fValue2;
   ConfInt ciArray[ 2];

   cout << "\n\n\tConfidence interval type\n"
	<< "\tOverloaded subscripting operator test\n";

   cout << "\nFirst interval: lower bound = ";
   cin >> fValue1;
   cout << "First interval: upper bound = ";
   cin >> fValue2;
   ciArray[ 0] = ConfInt( fValue1, fValue2);

   cout << "\nSecond interval: lower bound = ";
   cin >> fValue1;
   cout << "Second interval: upper bound = ";
   cin >> fValue2;
   ciArray[ 1] = ConfInt( fValue1, fValue2);

   cout << "\nSingleton value = ";
   cin >> fValue1;

   cout << "\n" << fValue1 << " is "
        << ( ciArray[ 0][ fValue1] ? "" : "not ")
        << "in " << ciArray[ 0] << "\n";

   cout << "\n" << fValue1 << " is "
        << ( ciArray[ 1][ fValue1] ? "" : "not ")
        << "in " << ciArray[ 1] << "\n";

   cout << "\n\n";

   return 0;
}

