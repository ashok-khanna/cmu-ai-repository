#include "confint.h"

int main()

{
   float fValue1;
   float fValue2;

   cout << "\n\n\tConfidence interval type test\n"
      << "\nFirst interval: lower bound = ";
   cin >> fValue1;
   cout << "First interval: upper bound = ";
   cin >> fValue2;
   ConfInt ciItem1( fValue1, fValue2);
   cout << "\nSecond interval: lower boud = ";
   cin >> fValue1;
   cout << "Second interval: upper bound = ";
   cin >> fValue2;
   ConfInt ciItem2( fValue1, fValue2);
   cout << "\nSingleton value = ";
   cin >> fValue1;

   cout << "\nFirst interval = " << ciItem1
      << "\nSecond interval = " << ciItem2;

   cout << "\n+" << ciItem1 << " = " << +ciItem1
      << "\n-" << ciItem1 << " = " << -ciItem1;

   cout << "\n" << ciItem1 << "+" << fValue1 << " = " << ( ciItem1 + fValue1)
      << "\n" << fValue1 << "+" << ciItem1 << " = " << ( fValue1 + ciItem1)
      << "\n" << ciItem1 << "+" << ciItem2 << " = " << ( ciItem1 + ciItem2);

   cout << "\n" << ciItem1 << "-" << fValue1 << " = " << ( ciItem1 - fValue1)
      << "\n" << fValue1 << "-" << ciItem1 << " = " << ( fValue1 - ciItem1)
      << "\n" << ciItem1 << "-" << ciItem2 << " = " << ( ciItem1 - ciItem2);

   cout << "\n" << ciItem1 << "*" << fValue1 << " = " << ( ciItem1 * fValue1)
      << "\n" << fValue1 << "*" << ciItem1 << " = " << ( fValue1 * ciItem1)
      << "\n" << ciItem1 << "*" << ciItem2 << " = " << ( ciItem1 * ciItem2);

   cout << "\n" << ciItem1 << "/" << fValue1 << " = " << ( ciItem1 / fValue1)
      << "\n" << fValue1 << "/" << ciItem1 << " = " << ( fValue1 / ciItem1)
      << "\n" << ciItem1 << "/" << ciItem2 << " = " << ( ciItem1 / ciItem2);

   cout << "\n" << ciItem1 << "+=" << fValue1 << " = " << ( ciItem1 += fValue1)
      << "\n" << ciItem1 << "-=" << fValue1 << " = " << ( ciItem1 -= fValue1)
      << "\n" << ciItem1 << "+=" << ciItem2 << " = " << ( ciItem1 += ciItem2)
      << "\n" << ciItem1 << "-=" << ciItem2 << " = " << ( ciItem1 -= ciItem2)
      << "\n" << ciItem1 << "*=" << fValue1 << " = " << ( ciItem1 *= fValue1)
      << "\n" << ciItem1 << "/=" << fValue1 << " = " << ( ciItem1 /= fValue1)
      << "\n" << ciItem1 << "*=" << ciItem2 << " = " << ( ciItem1 *= ciItem2)
      << "\n" << ciItem1 << "/=" << ciItem2 << " = " << ( ciItem1 /= ciItem2);

   cout << "\nmin( " << ciItem1 << ", " << ciItem2 << ") = " << min( ciItem1, ciItem2)
      << "\nmax( " << ciItem1 << ", " << ciItem2 << ") = " << max( ciItem1, ciItem2);

   cout << "\n";

   return 0;
}

