#include "fznum.h"

#include <ctype.h>

void fzRead( FzNum& fzValue)

{
   float flLeft;
   float flMiddle;
   float flRight;

   cout << "\n\tInsert fuzzy value:    lower bound: ";
   cin >> flLeft;

   cout << "\t            maximum of presumption: ";
   cin >> flMiddle;

   cout << "\t                       upper bound: ";
   cin >> flRight;

   fzValue = FzNum( flLeft, flMiddle, flRight);
}

int main()

{
   FzNum fzOpnd1;
   FzNum fzOpnd2;
   char cOp;

   cout << "\n\n\t\tFUZZY NUMBER TYPE TEST\n\n";

   fzRead( fzOpnd1);
   fzRead( fzOpnd2);

   do {

      cout << "\nInsert operation (+ - * / q): ";
      cin >> cOp;

      switch ( cOp) {

         case '+':
            cout << "\nThe resulting fuzzy number is:\n\n"
               << ( fzOpnd1 + fzOpnd2);
            break;

         case '-':
            cout << "\nThe resulting fuzzy number is:\n\n"
               << ( fzOpnd1 - fzOpnd2);
            break;

         case '*':
            cout << "\nThe resulting fuzzy number is:\n\n"
               << ( fzOpnd1 * fzOpnd2);
            break;

         case '/':
            cout << "\nThe resulting fuzzy number is:\n\n"
               << ( fzOpnd1 / fzOpnd2);
            break;

      }

   } while ( tolower( cOp) != 'q');

   return 0;
}
