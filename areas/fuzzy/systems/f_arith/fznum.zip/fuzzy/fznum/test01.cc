#include "fznum.h"

int main()

{
   float v1;
   float v2;
   float v3;
   float v4;

   cout << "\n\n\tFUZZY NUMBER TYPE\n"
        << "\tOverloaded subscribing operator test\n";

   cout << "\nInsert a trapezoidal fuzzy value:\n";

   cout << "\tbase lower bound: ";
   cin >> v1;

   cout << "\ttop lower bound:  ";
   cin >> v2;

   cout << "\ttop upper bound:  ";
   cin >> v3;

   cout << "\tbase upper bound: ";
   cin >> v4;

   FzNum fuzzy( v1, v2, v3, v4);

   cout << "\nInsert a singleton value: ";
   cin >> v1;

   v2 = fuzzy[ v1];

   if ( v2)

      cout << "\nThe given fuzzy number represents " << v1
           << " at a presumption level of " << v2;

   else

      cout << "\nThe given fuzzy number does not represent " << v1;

   cout << "\n\n\n";

   return 0;
}
