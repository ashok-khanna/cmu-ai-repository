// -*- C++ -*-

#include <CNCL/FVar.h>
#include <CNCL/FSetTrapez.h>



main()
{
    CNFVar temp("Temperatur", 0, 100);
    enum { KALT, MITTEL, WARM, HEISS };

    temp.add_value_set(KALT,   new CNFSetTrapez("kalt",    0, 10,  0, 10));
    temp.add_value_set(MITTEL, new CNFSetTrapez("mittel", 20, 20, 10, 10));
    temp.add_value_set(WARM,   new CNFSetTrapez("warm",   30, 40, 10,  5));
    temp.add_value_set(HEISS,  new CNFSetTrapez("heiss",  40,100, 10,  0));

    temp.print();

    temp.value(0);
    temp.print_membership();
    temp.value(17.5);
    temp.print_membership();
    temp.value(25);
    temp.print_membership();
    temp.value(35);
    temp.print_membership();
    temp.value(45);
    temp.print_membership();
    
}


