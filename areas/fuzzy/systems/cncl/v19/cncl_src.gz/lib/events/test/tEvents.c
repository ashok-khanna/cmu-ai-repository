// -*- C++ -*-

#include <iostream.h>

#include <CNCL/EventScheduler.h>



class TestEH : public CNEventHandler
{
public:
    virtual void event_handler(const CNEvent *ev);
};



void TestEH::event_handler(const CNEvent *ev)
{
    cout << "event_handler() called - now=" << now() << endl << ev;
}



main()
{
    CNEventScheduler sched;
    TestEH test;
    
    sched.send_event(new CNEvent(0, &test, 100));
    sched.send_event(new CNEvent(0, &test, 300));
    sched.send_event(new CNEvent(0, &test, 200));
    
    sched.start();
}
