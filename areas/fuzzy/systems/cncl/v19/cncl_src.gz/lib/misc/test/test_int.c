// -*- C++ -*-
#include <CNCL/String.h>
#include <CNCL/FormInt.h>

main()
{
    CNFormInt c(0,10,'>');
    int x;
    char m;
    
    CNFormInt b(1234,11,'.', CNFormInt::left);
    cout<<b;
    cout << "value" << endl;
    cin >> x;
    
    b.set_value(x);
    cout<<b;
    cout << "fill" <<endl;
    cin >> m;
    
    b.set_fill(m);
    cout<<b;
    b.set_format(CNFormInt::right);
    cout<<b;
    cout << "width"<<endl;
    cin >> x;
    
    b.set_width(x);
    cout<<b;
    

    cout <<c<<endl;
    
}



