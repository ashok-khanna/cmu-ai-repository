// -*- C++ -*-

#include <CNCL/Pipe.h>
#include <CNCL/String.h>

int main()
{
    CNPipe p;
    CNString s, dat;

{
    p.open("date");
    istream &in  = p.in();
    
    while(in.good() && !in.eof())
    {
	in >> s;
	if(in.fail())
	    break;
	else
	    dat = s;
	cout << s << endl;
    }
    
    p.close();
}

{
    p.open("head");
    istream &in  = p.in();
    ostream &out = p.out();

    out << "Date: " << dat << endl;
    out << "Test 1" << endl;
    out << "Test 2" << endl;
    out << "Test 3" << endl;
    out << "Test 4" << endl;
    out << "Test 5" << endl;
    out << "Test 6" << endl;
    out << "Test 7" << endl;
    out << "Test 8" << endl;
    out << "Test 9" << endl;
    
    while(in.good() && !in.eof())
    {
	in >> s;
	if(in.fail())
	    break;
	cout << s << endl;
    }
    
    p.close();
}


}



