//*BHEADER* :ts=8  -*- C++ -*-
/*****************************************************************************
 *
 *   |_|_|_  |_|_    |_    |_|_|_  |_		     C O M M U N I C A T I O N
 * |_        |_  |_  |_  |_        |_		               N E T W O R K S
 * |_        |_  |_  |_  |_        |_		                     C L A S S
 *   |_|_|_  |_    |_|_    |_|_|_  |_|_|_|_	                 L I B R A R Y
 *
 * Class: CNArrayInt  --- int array class
 *
 * Created from
 * $Id: T_array.hP,v 0.19 1994/01/28 18:55:33 cncl-adm Exp cncl-adm $
 *
 *****************************************************************************
 * Copyright (C) 1992/1993   Communication Networks
 *                           Aachen University of Technology
 *                           Kopernikusstr. 16
 *                           W-5100 Aachen
 *                           Germany
 *                           Email: mj@dfv.rwth-aachen.de (Martin Junius)
 *****************************************************************************
 * This file is part of the CN class library. All files marked with
 * this header are free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.  This library is
 * distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Library General Public
 * License for more details.  You should have received a copy of the GNU
 * Library General Public License along with this library; if not, write
 * to the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139,
 * USA.
 **EHEADER********************************************************************/

#ifndef __CNArrayInt_h
#define __CNArrayInt_h


#include <CNCL/Class.h>
#include <CNCL/Param.h>
#include <CNCL/Array.h>

extern CNClassDesc CN_ARRAYINT;	// CNClass CNArrayInt description


/*
 * The class CNArrayInt
 */


class CNArrayInt : public CNArray
{
  public:	/***** Public interface **************************************/
    virtual void size(int sz=0);		// Set size of array

    void put(int index, int value)	// Put value into array
    {
#   ifndef NO_RANGE_CHECK
	if(index<0 || asize<=index)
	    range_error(index);
	else
#   endif
	    array[index] = value;
    }

    int get(int index) const		// Get value from array
    {
#   ifndef NO_RANGE_CHECK
	if (index<0 || asize<=index)
	{   range_error(index); return 0; }
	else
#   endif
	    return array[index];
    }

    int& operator[] (int index)	// Operator []
    {
#   ifndef NO_RANGE_CHECK
	if (index<0 || asize<=index)
	    range_error(index);
#   endif
	return array[index];
    }

  private:	/***** Internal private members ******************************/
    int *array;			// Array of int
    int def_val;			// Default value
    
    void init(int sz);			// Initialize array
    void delete_array();                // Delete array

  public:	/***** Constructors ******************************************/
    CNArrayInt()               : CNArray((unsigned)0), array(NIL), def_val(0) {}
    CNArrayInt(CNParam *param) : CNArray((unsigned)0), array(NIL), def_val(0) {}
    CNArrayInt(int sz, int def=0);
    CNArrayInt(const CNArrayInt &a);		// Copy constructor

    ~CNArrayInt();

    CNArrayInt &operator = (const CNArrayInt &a);
    

  public:	/***** Member functions required by CNCL *********************/
    virtual CNClassDesc class_desc() const	// CNClass description
    { return CN_ARRAYINT; }
            
    virtual bool is_a(CNClassDesc desc) const	// Type checking
    { return desc == CN_ARRAYINT ? TRUE : CNArray::is_a(desc); }
        
    static CNArrayInt *cast_from_object(CNObject *obj) // Safe type cast
    {
#   ifdef NO_TYPE_CHECK
	return (CNArrayInt *)obj;
#   else
	return (CNArrayInt *)( !obj || obj->is_a(CN_ARRAYINT)
	       ? obj : fatal_type(obj->class_desc(), CN_ARRAYINT) );
#   endif
    }
    
    static CNObject *new_object(CNParam *param = NIL) // Object creation
    { return param ? new CNArrayInt(param) : new CNArrayInt; }
    
    // Print/debug output
    virtual void print(ostream &strm = cout) const;
    virtual void dump (ostream &strm = cout) const;
};

#endif /**__CNArrayInt_h**/
