// -*- C++ -*-

#include <CNCL/ArrayInt.h>



main()
{
    CNArrayInt a(5, 99);
    CNArrayInt b(a);
    CNArrayInt c;
    
    c = b;
    
    a.dump();
    b.dump();
    c.dump();

    return 0;
}

