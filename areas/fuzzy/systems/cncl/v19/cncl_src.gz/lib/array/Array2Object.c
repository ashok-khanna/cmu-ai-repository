//*BHEADER* :ts=8  -*- C++ -*-
/*****************************************************************************
 *
 *   |_|_|_  |_|_    |_    |_|_|_  |_		     C O M M U N I C A T I O N
 * |_        |_  |_  |_  |_        |_		               N E T W O R K S
 * |_        |_  |_  |_  |_        |_		                     C L A S S
 *   |_|_|_  |_    |_|_    |_|_|_  |_|_|_|_	                 L I B R A R Y
 *
 * Class: CNArray2Object  --- CNObjPtr array class
 *
 * Created from
 * $Id: T_array2.cP,v 0.19 1994/01/28 18:55:33 cncl-adm Exp cncl-adm $
 *
 *****************************************************************************
 * Copyright (C) 1992/1993   Communication Networks
 *                           Aachen University of Technology
 *                           Kopernikusstr. 16
 *                           W-5100 Aachen
 *                           Germany
 *                           Email: mj@dfv.rwth-aachen.de (Martin Junius)
 *****************************************************************************
 * This file is part of the CN class library. All files marked with
 * this header are free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.  This library is
 * distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Library General Public
 * License for more details.  You should have received a copy of the GNU
 * Library General Public License along with this library; if not, write
 * to the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139,
 * USA.
 **EHEADER********************************************************************/

#include "Array2Object.h"



/***** Private functions *****************************************************/

void CNArray2Object::init(int r, int c)
{
    int i, j;
    
    arows = r;
    acols = c;
    
    array = new CNArrayObject[r];
    for (i = 0; i < r; i++)
    {
	array[i].size(c);
	for(j = 0; j < c; j++)
	    array[i][j] = def_val;
    }
}



void CNArray2Object::delete_array()
{
    arows = acols = 0;
    if(array)
	delete [] array;
    array = NIL;
}



/***** Constructors **********************************************************/

CNArray2Object::CNArray2Object(int r, int c, CNObjPtr def)
{
    if (r<0 || c<0)
	fatal(NIL, "CNArray2Object: ", "invalid size < 0");
    
    def_val = def;
    init(r, c);
}



CNArray2Object::CNArray2Object(const CNArray2Object &a)
{
    int i, j;
    
    init(a.arows, a.acols);
    for (i = 0; i < arows; i++)
	for (j = 0; j < acols; j++)
	    array[i][j] = a.array[i][j];
}


CNArray2Object::~CNArray2Object()
{
    CNArray2Object::delete_array();
}



CNArray2Object &CNArray2Object::operator = (const CNArray2Object &a)
{
    int i, j;
    
    delete_array();
    init(a.arows, a.acols);
    for (i = 0; i < arows; i++)
	for (j = 0; j < acols; j++)
	    array[i][j] = a.array[i][j];

    return *this;
}
    


/***** public functions ******************************************************/

void CNArray2Object::size(int r, int c)  // Set size of array
{
    int i, j;
    
    if (r<0 || c<0)
	fatal(NIL, "CNArray2Object: ", "invalid size < 0");

    if (array == NIL)
    {
	init(r, c);
	return;
    }
    if(r == arows && c == acols)	// Nothing to do
	return;
    if(r == arows)			// Resize rows only
    {
	for(i = 0; i < arows; i++)
	    array[i].size(c);
	acols = c;
	return;
    }
    
    CNArrayObject *temp = array;

    array = new CNArrayObject[r];
    for (i = 0; i < r; i++)
    {
	array[i].size(c);
	for(j = 0; j < c; j++)
	    if(i<arows && j<acols)
		array[i][j] = temp[i][j];
	    else
		array[i][j] = def_val;
    }
    delete [] temp;
    arows = r;
    acols = c;
}



/***** Default I/O member function for CNCL classes **************************/

// CNNormal output
void CNArray2Object::print(ostream &strm) const
{
    strm << "[ " << endl;
    for(int i=0; i<arows; i++)
    {
	strm << "  " << array[i];
	if(i != arows-1)
	    strm << " ,";
	strm << endl;
    }
    strm << "]" << endl;
}

// Debug output
void CNArray2Object::dump(ostream &strm) const
{
    strm << "CNArray2Object { $Revision: 0.19 $" << endl;
    strm << "rows=" << arows << " cols=" << acols
	 << " array=" << hex << (unsigned long)(array) << dec << endl;
    strm << "values=" << endl << this << endl;
    strm << "}" << endl;
}



/***** CNCL stuff for type ***************************************************/

// Describing object for class CNArray2Object
static CNClass CNArray2Object_desc("CNArray2Object", "$Revision: 0.19 $",
			    CNArray2Object::new_object);

// "Type" for type checking functions
CNClassDesc CN_ARRAY2OBJECT = &CNArray2Object_desc;
