// -*- C++ -*-


#include <CNCL/Object.h>


enum { MEMSIZE=1024*1024 };


int main()
{
    char *p;

    for(int i=0; i<1024; i++)
    {
	p = new char [MEMSIZE];	// Allocate memory
	cerr << "Allocated " << i << " MB of memory" << endl;
    }
}
