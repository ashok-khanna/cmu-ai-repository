#include <iostream.h>

#include <CNCL/Moments.h>


main()
{
    double x;
    CNMoments stat("tCNMoments");
    
    for(;;)
    {
	cin >> x;
	if(!cin.good())
	    break;
	stat.put(x);
    }
    
    cout << stat;
}
