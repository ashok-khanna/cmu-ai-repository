//*BHEADER* :ts=8  -*- C++ -*-
/*****************************************************************************
 *
 *   |_|_|_  |_|_    |_    |_|_|_  |_		     C O M M U N I C A T I O N
 * |_        |_  |_  |_  |_        |_		               N E T W O R K S
 * |_        |_  |_  |_  |_        |_		                     C L A S S
 *   |_|_|_  |_    |_|_    |_|_|_  |_|_|_|_	                 L I B R A R Y
 *
 * $Id: Array.c,v 0.22 1994/07/22 09:21:11 cncl-adm Exp cncl-adm $
 *
 * CNClass: CNArray --- Abstract array base class
 *
 *****************************************************************************
 * Copyright (C) 1992/1993   Communication Networks
 *                           Aachen University of Technology
 *                           Kopernikusstr. 16
 *                           W-5100 Aachen
 *                           Germany
 *                           Email: mj@dfv.rwth-aachen.de (Martin Junius)
 *****************************************************************************
 * This file is part of the CN class library. All files marked with
 * this header are free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.  This library is
 * distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Library General Public
 * License for more details.  You should have received a copy of the GNU
 * Library General Public License along with this library; if not, write
 * to the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139,
 * USA.
 **EHEADER********************************************************************/

#include "Array.h"

#include <strstream.h>



/*
 * Index out of range error message
 */
void CNArray::range_error(int index) const
{
    char buffer[16];
    ostrstream str(buffer, sizeof(buffer));
    
    str << index << ends;
    
    fatal(NIL, class_desc()->name(), ": index [", buffer, "] out of range");
}



/***** CNCL stuff for type information and exemplar objects ******************/

// Describing object for class CNArray
static CNClass CNArray_desc("CNArray", "$Revision: 0.22 $", NIL);

// "Type" for type checking functions
CNClassDesc CN_ARRAY = &CNArray_desc;




