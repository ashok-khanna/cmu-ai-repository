//*BHEADER* :ts=8  -*- C++ -*-
/*****************************************************************************
 *
 *   |_|_|_  |_|_    |_    |_|_|_  |_		     C O M M U N I C A T I O N
 * |_        |_  |_  |_  |_        |_		               N E T W O R K S
 * |_        |_  |_  |_  |_        |_		                     C L A S S
 *   |_|_|_  |_    |_|_    |_|_|_  |_|_|_|_	                 L I B R A R Y
 *
 * $Id: HyperExp.h,v 0.22 1994/07/22 09:20:28 cncl-adm Exp cncl-adm $
 *
 * CNClass: CNHyperExp --- Hyper exponential (H2) distributed random numbers
 *
 *****************************************************************************
 * Copyright (C) 1992/1993   Communication Networks
 *                           Aachen University of Technology
 *                           Kopernikusstr. 16
 *                           W-5100 Aachen
 *                           Germany
 *                           Email: mj@dfv.rwth-aachen.de (Martin Junius)
 *****************************************************************************
 * This file is part of the CN class library. All files marked with
 * this header are free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.  This library is
 * distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Library General Public
 * License for more details.  You should have received a copy of the GNU
 * Library General Public License along with this library; if not, write
 * to the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139,
 * USA.
 **EHEADER********************************************************************/

#ifndef __HyperExp_h
#define __HyperExp_h


#include <CNCL/Class.h>
#include <CNCL/Param.h>

#include <CNCL/Random.h>		// Base class

extern CNClassDesc CN_HYPEREXP;	// CNClass CNHyperExp description


/*
 * The class CNHyperExp
 */

class CNHyperExp : public CNRandom
{
protected:
    double percent;
    double tau1,tau2;

public:
    virtual double operator()();

    /***** Constructors ******************************************************/
public:
    CNHyperExp(); 				// Default constructor
    CNHyperExp(CNParam *param); 			// CNParam constructor
    CNHyperExp(double p, double m1, double m2, CNRNG *gen);

    /***** Member functions required by CNCL *********************************/
public:
    virtual CNClassDesc class_desc() const	// CNClass description
    {
	return CN_HYPEREXP;
    };
            
    virtual bool is_a(CNClassDesc desc) const	// Type checking
    {
	return desc == CN_HYPEREXP ? TRUE : CNRandom::is_a(desc);
    };
        
    static CNHyperExp *cast_from_object(CNObject *obj) // Safe type cast
    {
#   ifdef NO_TYPE_CHECK
	return (CNHyperExp *)obj;
#   else
	return (CNHyperExp *)( !obj || obj->is_a(CN_HYPEREXP)
	       ? obj : fatal_type(obj->class_desc(), CN_HYPEREXP) );
#   endif
    }
    
    static CNObject *new_object(CNParam *param = NIL) // Object creation
    { return param ? new CNHyperExp(param) : new CNHyperExp; }
    
    // Print/debug output
    virtual void print(ostream &strm = cout) const;
    virtual void dump (ostream &strm = cout) const;
};



inline CNHyperExp::CNHyperExp(double p, double m1, double m2, CNRNG *gen)
    : CNRandom(gen)
{
    assert((m1>0) && (m2>0));
    percent = p;
    tau1 = 1 / m1;
    tau2 = 1 / m2;
}

inline CNHyperExp::CNHyperExp()
	 : CNRandom((CNRNG*)NIL)
{
    percent = 0;
    tau1 = 0;
    tau2 = 0;
}     

inline CNHyperExp::CNHyperExp(CNParam *param)
	 : CNRandom((CNRNG*)NIL)
{
    percent = 0;
    tau1 = 0;
    tau2 = 0;
}     
    
#endif /**__HyperExp_h**/
