// -*- C++ -*-

#include <iostream.h>

#include <CNCL/QueueFIFO.h>

#include "Test.h"



int main()
{
    CNQueueFIFO queue;
    
    cout << queue;

    queue.put(new Test(111));
    queue.put(new Test(222));
    queue.put(new Test(333));
    queue.put(new Test(444));
    queue.put(new Test(555));
    queue.put(new Test(666));
    queue.put(new Test(777));
    queue.put(new Test(888));
    queue.put(new Test(999));

    cout << queue;

    CNObject *p;

    while(p = queue.get())
	cout << p;
}
