#include <CNCL/Int.h>


int main() {
    CNInt alpha;
    CNInt beta(100);	
    CNInt gamma(beta); 
    CNInt delta = beta;
    CNInt epsilon = 1000;

    cout << "alpha[0] = " << alpha << endl;
    cout << "beta[100] = " << beta << endl;
    cout << "gamma[100] = " << gamma << endl;
    cout << "delta[100] = " << delta << endl;
    cout << "epsilon[1000] = " << epsilon << endl;
    
    alpha = epsilon;
    delta = gamma + beta;
    beta = gamma + 5;
    gamma = gamma - 1;
    epsilon = 2 * beta;

    cout << "alpha[1000] = " << alpha << endl;
    cout << "beta[105] = " << beta << endl;
    cout << "gamma[99] = " << gamma << endl;
    cout << "delta[200] = " << delta << endl;
    cout << "epsilon[210] = " << epsilon << endl;

    int hallo = int( gamma );
    double hello = double( long(alpha) );

    cout << "hallo[99] = " << hallo << endl;
    cout << "hello[1000] = " << hello << endl;

    alpha++;
    beta = ++delta;
    ++gamma;
    delta += 78;
    epsilon *= 3;

    cout << "alpha[1001] = " << alpha << endl;
    cout << "beta[201] = " << beta << endl;
    cout << "gamma[100] = " << gamma << endl;
    cout << "delta[279] = " << delta << endl;
    cout << "epsilon[630] = " << epsilon << endl;

    hallo = (epsilon << 5) - (delta | 48);
    hello = 4.5 * --gamma;

    cout << "hallo[19849] = " << hallo << endl;
    cout << "hello[445.5] = " << hello << endl;

    epsilon = 3 * gamma / (delta - beta);
    alpha = beta % gamma;
    beta >>= 2;
    delta = -gamma;
    gamma = beta & alpha | 33;

    cout << "alpha[3] = " << alpha << endl;
    cout << "beta[50] = " << beta << endl;
    cout << "gamma[35] = " << gamma << endl;
    cout << "delta[-99] = " << delta << endl;
    cout << "epsilon[3] = " << epsilon << endl;

    if (alpha == epsilon) cout << "comparison' equal' ok" << endl;
    if (alpha != beta) cout << "'nonequal' comparison ok" << endl;
    if (gamma < beta) cout << "'less than' comparison ok" << endl;
    if (epsilon > 2) cout << "comparison 'greater than constant' ok" << endl;
    if (delta == -99) cout << "comparison 'equal to constant' ok" << endl;
 
    alpha += beta;
    beta -= gamma;
    gamma *= epsilon;
    delta /= epsilon;
    epsilon %= alpha;

    cout << "alpha[53] = " << alpha << endl;
    cout << "beta[15] = " << beta << endl;
    cout << "gamma[105] = " << gamma << endl;
    cout << "delta[-33] = " << delta << endl;
    cout << "epsilon[3] = " << epsilon << endl;

    exit(0);
}

 
