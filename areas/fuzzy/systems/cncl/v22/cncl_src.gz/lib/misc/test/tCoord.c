//:ts=8 -*-C++-*-
/*****************************************************************************
 *
 * Test fuer CNCoord/CNICoord
 *
 * $Id: test_coord.C,v 1.0 1992/05/26 16:35:10 mj Exp mj $
 *
 * $Log: test_coord.C,v $
 *****************************************************************************/

#include <iostream.h>

#include <CNCL/Coord.h>



int main(int argc, char *argv[])
{
    CNCoord x, y(3.5, 7.5);
    CNICoord a, b;
    
    CNCoord::set_scale(0.01);
    
    x.x = 4.25;
    x.y = -0.25;
    
    cout << "x = " << x << "\n"
	 << "y = " << y << "\n"
	 << "x + y = " << x + y << "\n"
	 << "x - y = " << x - y << "\n";

    x -= y;
    cout << "x -= y; x = " << x << "\n";

    x += y;
    cout << "x += y; x = " << x << "\n";

    a = CNICoord(x);
    b = CNICoord(y);
    
    cout << "a = " << a << "\n"
	 << "b = " << b << "\n"
	 << "a + b = " << a + b << "\n"
	 << "a - (9,9) = " << a - CNICoord(9,9) << "\n";

    return 0;
}
