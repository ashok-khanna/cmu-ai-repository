//*BHEADER* :ts=8  -*- C++ -*-
/*****************************************************************************
 *
 *   |_|_|_  |_|_    |_    |_|_|_  |_		     C O M M U N I C A T I O N
 * |_        |_  |_  |_  |_        |_		               N E T W O R K S
 * |_        |_  |_  |_  |_        |_		                     C L A S S
 *   |_|_|_  |_    |_|_    |_|_|_  |_|_|_|_	                 L I B R A R Y
 *
 * $Id: EZDText.h,v 0.22 1994/07/22 09:21:19 cncl-adm Exp cncl-adm $
 *
 * Class: EZDText --- ezd object with text
 *
 *****************************************************************************
 * Copyright (C) 1992/1993   Communication Networks
 *                           Aachen University of Technology
 *                           Kopernikusstr. 16
 *                           W-5100 Aachen
 *                           Germany
 *                           Email: mj@dfv.rwth-aachen.de (Martin Junius)
 *****************************************************************************
 * This file is part of the CN class library. All files marked with
 * this header are free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.  This library is
 * distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Library General Public
 * License for more details.  You should have received a copy of the GNU
 * Library General Public License along with this library; if not, write
 * to the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139,
 * USA.
 **EHEADER********************************************************************/

#ifndef __EZDText_h
#define __EZDText_h


#include <CNCL/Class.h>
#include <CNCL/Param.h>

#include <CNCL/EZDObject.h>		// Base class

extern CNClassDesc CN_EZDTEXT;	// Class EZDText description


/*
 * The class EZDText
 */

class EZDText : public EZDObject
{
public:
    virtual void redraw();
    
    void set_text    (const CNString &t) { txt=t; redraw(); }
    void set_text_val(int x);
    void set_text_val(const CNString &t, int x);
    void set_text_val(double x);
    void set_text_val(const CNString &t, double x);
    
    // Private members
private:
    CNString txt;
    CNString fnt;
    
    /***** Constructors ******************************************************/
public:
    EZDText()
	: EZDObject("text", 0, 0), txt(""),   fnt("")   {}
    EZDText(CNParam *param)
	: EZDObject("text", 0, 0), txt(""),   fnt("")   {}
    EZDText(int x, int y, const CNString &text)
	: EZDObject("text", x, y), txt(text), fnt("")   {}
    EZDText(const CNString &name, int x, int y, const CNString &text)
	: EZDObject(name, x, y),   txt(text), fnt("")   {}
    EZDText(int x, int y, const CNString &text, const CNString &font)
	: EZDObject("text", x, y), txt(text), fnt(font) {}
    EZDText(const CNString &name, int x, int y, const CNString &text,
	    const CNString &font)
	: EZDObject(name, x, y),   txt(text), fnt(font) {}

    /***** Member functions required by CNCL *********************************/
public:
    virtual CNClassDesc class_desc() const	// CNClass description
    {
	return CN_EZDTEXT;
    };
            
    virtual bool is_a(CNClassDesc desc) const	// Type checking
    {
	return desc == CN_EZDTEXT ? TRUE : EZDObject::is_a(desc);
    };
        
    static EZDText *cast_from_object(CNObject *obj) // Safe type cast
    {
#   ifdef NO_TYPE_CHECK
	return (EZDText *)obj;
#   else
	return (EZDText *)( !obj || obj->is_a(CN_EZDTEXT)
	       ? obj : fatal_type(obj->class_desc(), CN_EZDTEXT) );
#   endif
    }
    
    static CNObject *new_object(CNParam *param = NIL) // Object creation
    { return param ? new EZDText(param) : new EZDText; }
    
    // Print/debug output
    virtual void print(ostream &strm = cout) const;
    virtual void dump (ostream &strm = cout) const;
};


#endif /**__EZDText_h**/
