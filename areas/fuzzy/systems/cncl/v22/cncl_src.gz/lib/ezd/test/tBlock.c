// -*- C++ -*-

#include <unistd.h>

#include <CNCL/String.h>

#include <CNCL/FiboG.h>
#include <CNCL/RndInt.h>

#include <CNCL/EZD.h>
#include <CNCL/EZDWindow.h>
#include <CNCL/EZDDrawing.h>
#include <CNCL/EZDBlock.h>


int main()
{
    EZDWindow win(400, 400);
    EZDDrawing draw;
    CNString in; 
    CNFiboG *g = new CNFiboG;
    CNRndInt rnd(0, 24, g);
    int i;
	
    win.overlay(&draw);

    EZD::draw_fill_rectangle(50,150,300,50, "Green");

    EZDBlock block("test", 100, 100, 5, 5, 10);
    block.redraw();

    for(i=0; i<100; i++)
    {
	block.on(rnd());
	usleep(100000);
    }
    
    for(i=0; i<100; i++)
    {
	block.off(rnd());
	usleep(100000);
    }
}


