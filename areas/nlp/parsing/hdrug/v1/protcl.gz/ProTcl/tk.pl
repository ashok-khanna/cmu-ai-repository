%
% SICStus version of ProTcl
%
% Author: Micha Meier
% Date:   September 93
%

%
% sccsid("@(#)stk.pl	1.2          93/12/16").
% sccscr("@(#)  Copyright 1993 ECRC GmbH ").
%

:- module(tk, [
	tcl_eval/1,
	tk_demo/0,
	tk_test/0,
	tk_file/2,
	tk/1,
	tk_do_one_event/1,
	tk_main_loop/0]).

tk(Opts) :-
    tk_init('', Opts),
    tcl_eval(update).

:- ensure_loaded('./dirs').
:- ensure_loaded('./tk_common').
:- ensure_loaded('./foreign').
