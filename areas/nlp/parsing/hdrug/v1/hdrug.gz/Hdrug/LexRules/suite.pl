user_max(_,1000000).

sentence(a,[marie,slaapt]).

sentence(b,[jan,heeft,geslapen]).

sentence(c,[jan,kust,vandaag,marie]).

sentence(d,[vandaag,wil,jan,marie,kussen]).

sentence(e,[jan,heeft,marie,willen,kussen]).

sentence(f,[marie,gekust,heeft,jan,vandaag]).


