:- module(gram, []).

:- use_module(library(flags)).

:- add_flag(parser_mode,gram).
:- add_flag(generator_mode,gram).

clean.
count.
count(0).

parse(o(Obj,_,_)) :-
	call(Obj).

generate(o(Obj,_,_)) :-
	call(Obj).

s/s(NP,VP) --> 
	np/NP,
	vp/VP.

vp/vp(V,NP) --> 
	v/V,
	np/NP.

v/kisses --> [kisses].
v/kisses --> [kissed].
vp/sleeps --> [sleeps].
np/john --> [john].
np/mary --> [mary].

