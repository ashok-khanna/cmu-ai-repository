:- ensure_loaded(start).

:- x.

