:- module(td,[]).
:- use_module(library(flags)).
:- add_flag(parser_mode,td).
:- add_flag(generator_mode,td).

clean.
count.
count(0).

parse(o(Cat,_,_)) :-
	user:Cat.

