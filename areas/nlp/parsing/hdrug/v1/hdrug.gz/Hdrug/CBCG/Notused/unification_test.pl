

test(Case0) :-
	choose_any(Case),
	unify_with_cut(Case0,Case).



:- block choose_any(-).


choose_any(case(nom)).
choose_any(case(acc)).

unify_with_cut(X,X) :- !.
unify_with_cut(X,X).

